"""
Microsoft Graph API authentication helper.

Supports two MSAL flows:
- Client credentials (app-level, requires client_secret)
- Device code (user-level, interactive)

Requires: pip install sentinel-security[microsoft]
"""

import json
import logging
import os
from typing import Optional

from .config import GRAPH_DEFAULT_SCOPES, MS_LOGIN_BASE_URL

logger = logging.getLogger(__name__)


def get_graph_client(
    tenant_id: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    scopes: Optional[list] = None,
    credentials_path: Optional[str] = None,
):
    """
    Get an authenticated requests.Session for Microsoft Graph API.

    Args:
        tenant_id: Azure AD tenant ID.
        client_id: Azure AD application (client) ID.
        client_secret: Client secret for confidential app flow.
                       If None, uses device code (interactive) flow.
        scopes: OAuth scopes. Default: ["https://graph.microsoft.com/.default"]
        credentials_path: Path to JSON file with tenant_id, client_id,
                         client_secret keys.

    Returns:
        requests.Session with Authorization header set.

    Raises:
        ImportError: If msal or requests is not installed.
        ValueError: If tenant_id or client_id cannot be resolved.
        RuntimeError: If token acquisition fails.
    """
    try:
        import msal
        import requests
    except ImportError:
        raise ImportError(
            "MSAL and requests required. Install with: "
            "pip install sentinel-security[microsoft]"
        )

    # Load from credentials file if provided
    if credentials_path:
        creds = _load_ms_credentials(credentials_path)
        tenant_id = tenant_id or creds.get('tenant_id')
        client_id = client_id or creds.get('client_id')
        client_secret = client_secret or creds.get('client_secret')

    # Fall back to environment variables
    tenant_id = tenant_id or os.environ.get('SENTINEL_MS_TENANT_ID')
    client_id = client_id or os.environ.get('SENTINEL_MS_CLIENT_ID')
    client_secret = client_secret or os.environ.get('SENTINEL_MS_CLIENT_SECRET')

    if not tenant_id:
        raise ValueError(
            "tenant_id required. Pass directly, set SENTINEL_MS_TENANT_ID, "
            "or provide credentials_path."
        )
    if not client_id:
        raise ValueError(
            "client_id required. Pass directly, set SENTINEL_MS_CLIENT_ID, "
            "or provide credentials_path."
        )

    if scopes is None:
        scopes = list(GRAPH_DEFAULT_SCOPES)

    authority = f"{MS_LOGIN_BASE_URL}/{tenant_id}"

    if client_secret:
        # Confidential client (app-level)
        app = msal.ConfidentialClientApplication(
            client_id,
            authority=authority,
            client_credential=client_secret,
        )
        result = app.acquire_token_silent(scopes, account=None)
        if not result:
            result = app.acquire_token_for_client(scopes=scopes)
    else:
        # Public client (device code, interactive)
        app = msal.PublicClientApplication(
            client_id,
            authority=authority,
        )
        flow = app.initiate_device_flow(scopes=scopes)
        if 'user_code' not in flow:
            raise RuntimeError(
                f"Failed to initiate device flow: {flow.get('error_description', 'unknown error')}"
            )
        logger.info(flow['message'])
        result = app.acquire_token_by_device_flow(flow)

    if 'access_token' not in result:
        error = result.get('error_description', result.get('error', 'unknown error'))
        raise RuntimeError(f"Token acquisition failed: {error}")

    session = requests.Session()
    session.headers.update({
        'Authorization': f"Bearer {result['access_token']}",
        'Content-Type': 'application/json',
    })
    return session


def _load_ms_credentials(credentials_path: str) -> dict:
    """
    Load Microsoft credentials from a JSON file.

    Args:
        credentials_path: Path to JSON file.

    Returns:
        dict with tenant_id, client_id, client_secret keys.

    Raises:
        FileNotFoundError: If file doesn't exist.
    """
    if not os.path.exists(credentials_path):
        raise FileNotFoundError(f"Credentials not found at {credentials_path}")

    with open(credentials_path) as f:
        return json.load(f)
