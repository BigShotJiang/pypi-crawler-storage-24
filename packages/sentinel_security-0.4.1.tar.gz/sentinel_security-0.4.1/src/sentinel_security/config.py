"""
Sentinel Security configuration module.

All configurable values are read from environment variables with sensible
defaults. Import from here rather than hardcoding values in individual modules.

Environment variables:
    SENTINEL_MS_TENANT_ID       - Azure AD tenant ID for Microsoft Graph
    SENTINEL_MS_CLIENT_ID       - Azure AD application (client) ID
    SENTINEL_MS_CLIENT_SECRET   - Client secret for confidential app flow
    SENTINEL_RISK_WEIGHTS       - JSON string overriding the default threat
                                  risk weights used by the scorer, e.g.
                                  '{"injection_pattern": 6, "homoglyph": 3}'
                                  Partial overrides are merged with defaults.
"""

import json
import os

# Microsoft Graph API
GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"
GRAPH_DEFAULT_SCOPES = ["https://graph.microsoft.com/.default"]
MS_LOGIN_BASE_URL = "https://login.microsoftonline.com"

# Microsoft credentials from environment (fallback values)
MS_TENANT_ID = os.environ.get("SENTINEL_MS_TENANT_ID", "")
MS_CLIENT_ID = os.environ.get("SENTINEL_MS_CLIENT_ID", "")
MS_CLIENT_SECRET = os.environ.get("SENTINEL_MS_CLIENT_SECRET", "")

# HTTP timeouts (seconds)
HTTP_TIMEOUT = int(os.environ.get("SENTINEL_HTTP_TIMEOUT", "30"))

# Risk weights for threat scoring (used by sentinel_security.sanitiser.scorer).
# Each key is a threat type; the value is added to the cumulative risk score.
_DEFAULT_RISK_WEIGHTS = {
    'injection_pattern': 4,
    'post_strip_injection': 5,
    'pdf_javascript': 5,
    'invisible_text': 4,
    'formula_injection': 4,
    'hidden_html': 3,
    'css_class_hiding': 3,
    'attribute_injection': 3,
    'markdown_injection': 3,
    'repo_metadata_injection': 3,
    'text_injection': 3,
    'comment_injection': 3,
    'cdata_injection': 3,
    'processing_instruction_injection': 3,
    'base64_block': 2,
    'base64_shard_exfil': 7,
    'rtl_override': 2,
    'homoglyph': 2,
    'invisible_unicode': 1,
}

_env_weights_raw = os.environ.get("SENTINEL_RISK_WEIGHTS")
if _env_weights_raw:
    try:
        _env_weights = json.loads(_env_weights_raw)
        RISK_WEIGHTS = {**_DEFAULT_RISK_WEIGHTS, **_env_weights}
    except (json.JSONDecodeError, TypeError):
        RISK_WEIGHTS = _DEFAULT_RISK_WEIGHTS
else:
    RISK_WEIGHTS = _DEFAULT_RISK_WEIGHTS
