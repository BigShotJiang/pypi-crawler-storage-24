"""Word (.docx) scanner for hidden content and prompt injection."""

import logging
import re
import zipfile
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

from lxml import etree

from .patterns import SHEET_INJECTION_PATTERNS
from .sanitiser.scorer import risk_level

WORD_NS = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
}


def scan_word(file_path: str) -> dict:
    logger.debug("scan_word: start file=%s", file_path)
    threats: List[Dict[str, Any]] = []

    try:
        from docx import Document
        doc = Document(file_path)
    except Exception as e:
        raise ValueError(f"Failed to load Word file: {e}")

    info = {
        'file_path': file_path,
        'paragraph_count': len(doc.paragraphs),
        'section_count': len(doc.sections),
    }

    # Hidden text & paragraph injection
    for i, para in enumerate(doc.paragraphs):
        text = para.text
        if text.strip():
            for pattern in SHEET_INJECTION_PATTERNS:
                if re.search(pattern, text, re.IGNORECASE):
                    threats.append({'type': 'injection_in_paragraph', 'severity': 'CRITICAL',
                                    'detail': f'Injection pattern in paragraph {i+1}.', 'paragraph': i + 1,
                                    'value_preview': text[:100]})
                    break
        for run in para.runs:
            if run.font.hidden:
                threats.append({'type': 'hidden_text', 'severity': 'HIGH',
                                'detail': f'Hidden text in paragraph {i+1}.', 'paragraph': i + 1,
                                'value_preview': run.text[:100]})

    # Headers/footers
    for si, section in enumerate(doc.sections):
        for hf_type in ['header', 'footer', 'even_page_header', 'even_page_footer',
                         'first_page_header', 'first_page_footer']:
            try:
                hf = getattr(section, hf_type)
                if not hf.is_linked_to_previous:
                    for para in hf.paragraphs:
                        if para.text.strip():
                            for pattern in SHEET_INJECTION_PATTERNS:
                                if re.search(pattern, para.text, re.IGNORECASE):
                                    threats.append({'type': 'injection_in_header_footer', 'severity': 'CRITICAL',
                                                    'detail': f'Injection in {hf_type} of section {si+1}.',
                                                    'value_preview': para.text[:100]})
                                    break
            except Exception as e:
                logger.warning("Failed to scan Word document element: %s", e)

    # Document properties
    props = doc.core_properties
    for prop_name in ['title', 'subject', 'comments', 'keywords', 'category']:
        val = getattr(props, prop_name, None)
        if val and isinstance(val, str) and val.strip():
            for pattern in SHEET_INJECTION_PATTERNS:
                if re.search(pattern, val, re.IGNORECASE):
                    threats.append({'type': 'injection_in_property', 'severity': 'CRITICAL',
                                    'detail': f'Injection in document property "{prop_name}".',
                                    'property': prop_name, 'value_preview': val[:100]})
                    break

    # XML-level checks via zipfile
    try:
        with zipfile.ZipFile(file_path, 'r') as zf:
            if 'word/comments.xml' in zf.namelist():
                tree = etree.parse(zf.open('word/comments.xml'))
                for comment in tree.findall('.//w:comment', WORD_NS):
                    texts = [t.text for t in comment.findall('.//w:t', WORD_NS) if t.text]
                    comment_text = ' '.join(texts)
                    if comment_text:
                        injection = False
                        for pattern in SHEET_INJECTION_PATTERNS:
                            if re.search(pattern, comment_text, re.IGNORECASE):
                                threats.append({'type': 'injection_in_comment', 'severity': 'CRITICAL',
                                                'detail': 'Injection in document comment.',
                                                'value_preview': comment_text[:100]})
                                injection = True
                                break
                        if not injection:
                            threats.append({'type': 'comment', 'severity': 'LOW',
                                            'detail': 'Document contains a comment.',
                                            'value_preview': comment_text[:100]})

            if 'word/document.xml' in zf.namelist():
                tree = etree.parse(zf.open('word/document.xml'))
                dels = tree.findall('.//w:del', WORD_NS)
                ins = tree.findall('.//w:ins', WORD_NS)
                if dels or ins:
                    threats.append({'type': 'tracked_changes', 'severity': 'MEDIUM',
                                    'detail': f'Document has tracked changes ({len(ins)} insertions, {len(dels)} deletions).',
                                    'insertions': len(ins), 'deletions': len(dels)})

                fields = tree.findall('.//w:instrText', WORD_NS)
                for field in fields:
                    if field.text:
                        threats.append({'type': 'field_code', 'severity': 'MEDIUM',
                                        'detail': f'Field code found: {field.text.strip()[:80]}',
                                        'value_preview': field.text.strip()[:100]})

                hyperlinks = tree.findall('.//w:hyperlink', WORD_NS)
                if hyperlinks:
                    threats.append({'type': 'hyperlinks', 'severity': 'LOW',
                                    'detail': f'Document contains {len(hyperlinks)} hyperlink(s).',
                                    'count': len(hyperlinks)})

            for part_name, label in [('word/footnotes.xml', 'footnote'), ('word/endnotes.xml', 'endnote')]:
                if part_name in zf.namelist():
                    tree = etree.parse(zf.open(part_name))
                    ns_w = WORD_NS['w']
                    for note in tree.findall(f'.//w:{label}', WORD_NS):
                        note_type = note.get(f'{{{ns_w}}}type')
                        if note_type in ('separator', 'continuationSeparator'):
                            continue
                        texts = [t.text for t in note.findall('.//w:t', WORD_NS) if t.text]
                        note_text = ' '.join(texts)
                        if note_text.strip():
                            for pattern in SHEET_INJECTION_PATTERNS:
                                if re.search(pattern, note_text, re.IGNORECASE):
                                    threats.append({'type': f'injection_in_{label}', 'severity': 'CRITICAL',
                                                    'detail': f'Injection in {label}.',
                                                    'value_preview': note_text[:100]})
                                    break
    except zipfile.BadZipFile:
        pass

    logger.debug("scan_word: end file=%s threats=%d", file_path, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_word: threats detected count=%d types=%s file=%s", len(threats), types, file_path)
    risk_score = _calculate_risk(threats)
    return {
        'info': info, 'threats': threats, 'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }


def _calculate_risk(threats):
    score = 0
    for t in threats:
        s = t.get('severity', 'LOW')
        if s == 'CRITICAL':
            score += 5
        elif s == 'HIGH':
            score += 3
        elif s == 'MEDIUM':
            score += 1
    return min(10, score)
