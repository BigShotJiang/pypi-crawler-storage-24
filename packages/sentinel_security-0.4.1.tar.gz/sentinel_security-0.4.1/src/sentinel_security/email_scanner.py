"""
Email (.eml) scanner for prompt injection in email content.

Uses the built-in email module to detect:
- Subject line injection
- From display name injection
- Body text/HTML injection
- X-header and custom header injection
- Attachment filename injection
- Reply chain / forwarded message injection
- Embedded .ics calendar invites
"""

import email
import email.policy
import logging
import re

logger = logging.getLogger(__name__)
from typing import Any, Dict, List, Optional

from .patterns import INJECTION_PATTERNS
from .sanitiser import calculate_risk_score, sanitise_content


def scan_eml(file_path: str) -> dict:
    """
    Scan an .eml file for prompt injection threats.

    Args:
        file_path: Path to the .eml file.

    Returns:
        dict with keys:
            file (str): File path.
            subject (str): Email subject.
            from (str): From address.
            threats (list): Detected threats with type, severity, detail, source.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
            scanned_surfaces (dict): Count of each surface type scanned.
    """
    try:
        with open(file_path, "r", errors="replace") as f:
            raw = f.read()
        msg = email.message_from_string(raw, policy=email.policy.default)
    except Exception as e:
        raise ValueError(f"Failed to parse email file: {e}")

    return _scan_email_message(msg, file_path)


def _scan_email_message(msg, file_path: str) -> dict:
    """Core scanning logic for an email.Message object."""
    logger.debug("_scan_email_message: start file=%s", file_path)
    threats: List[Dict[str, Any]] = []
    scanned_surfaces = {
        "headers": 0,
        "body_parts": 0,
        "attachments": 0,
        "embedded_calendars": 0,
    }

    subject = str(msg.get("Subject", ""))
    from_addr = str(msg.get("From", ""))

    # --- 1. Subject line ---
    if subject.strip():
        scanned_surfaces["headers"] += 1
        result = sanitise_content(subject, format="text")
        for t in result["threats"]:
            t["source"] = "subject"
            threats.append(t)

    # --- 2. From display name ---
    if from_addr.strip():
        scanned_surfaces["headers"] += 1
        result = sanitise_content(from_addr, format="text")
        for t in result["threats"]:
            t["source"] = "from_display_name"
            threats.append(t)

    # --- 3 & 4. Body text and HTML ---
    body_parts = _extract_body_parts(msg)
    for part_info in body_parts:
        scanned_surfaces["body_parts"] += 1
        fmt = "html" if part_info["content_type"] == "text/html" else "text"
        result = sanitise_content(part_info["content"], format=fmt)
        for t in result["threats"]:
            t["source"] = f"body_{part_info['content_type']}_{part_info['index']}"
            threats.append(t)

    # --- 5. X-headers and custom headers ---
    for key in msg.keys():
        if key.lower().startswith("x-") or key.lower() not in _STANDARD_HEADERS:
            value = str(msg[key])
            if value.strip():
                scanned_surfaces["headers"] += 1
                result = sanitise_content(value, format="text")
                for t in result["threats"]:
                    t["source"] = f"header_{key}"
                    threats.append(t)

    # --- 6. Attachment filenames ---
    for part in msg.walk():
        filename = part.get_filename()
        if filename:
            scanned_surfaces["attachments"] += 1
            result = sanitise_content(str(filename), format="text")
            for t in result["threats"]:
                t["source"] = f"attachment_filename_{filename}"
                threats.append(t)

    # --- 7. Reply chain (forwarded / replied content) ---
    # Already covered by body scanning since forwarded content is inline

    # --- 8. Embedded .ics ---
    for part in msg.walk():
        ct = part.get_content_type()
        if ct == "text/calendar":
            scanned_surfaces["embedded_calendars"] += 1
            try:
                ics_content = part.get_content()
                if isinstance(ics_content, bytes):
                    ics_content = ics_content.decode("utf-8", errors="replace")
                from .ics_scanner import _scan_ics_content
                ics_result = _scan_ics_content(ics_content)
                for t in ics_result["threats"]:
                    t["source"] = f"embedded_ics_{t.get('source', '')}"
                    threats.append(t)
            except Exception as e:
                logger.warning("Failed to scan embedded ICS calendar: %s", e)

    logger.debug("_scan_email_message: end file=%s threats=%d", file_path, len(threats))
    if threats:
        types = list({t.get("source") for t in threats})
        logger.info("_scan_email_message: threats detected count=%d", len(threats))
    risk_score = calculate_risk_score(threats)
    return {
        "file": file_path,
        "subject": subject,
        "from": from_addr,
        "threats": threats,
        "threat_count": len(threats),
        "risk_score": risk_score,
        "risk_level": (
            "CLEAN" if risk_score == 0 else
            "LOW" if risk_score <= 2 else
            "MEDIUM" if risk_score <= 5 else
            "HIGH" if risk_score <= 8 else
            "CRITICAL"
        ),
        "scanned_surfaces": scanned_surfaces,
    }


def _extract_body_parts(msg) -> List[Dict[str, Any]]:
    """Extract all text/plain and text/html body parts from an email."""
    parts = []
    text_idx = 0
    html_idx = 0

    for part in msg.walk():
        ct = part.get_content_type()
        # Skip attachments
        if part.get_content_disposition() == "attachment":
            continue

        if ct == "text/plain":
            try:
                content = part.get_content()
                if isinstance(content, bytes):
                    content = content.decode("utf-8", errors="replace")
                parts.append({
                    "content_type": "text/plain",
                    "content": content,
                    "index": text_idx,
                })
                text_idx += 1
            except Exception as e:
                logger.warning("Failed to extract text/plain body part: %s", e)
        elif ct == "text/html":
            try:
                content = part.get_content()
                if isinstance(content, bytes):
                    content = content.decode("utf-8", errors="replace")
                parts.append({
                    "content_type": "text/html",
                    "content": content,
                    "index": html_idx,
                })
                html_idx += 1
            except Exception as e:
                logger.warning("Failed to extract text/html body part: %s", e)

    return parts


# Standard headers that we don't need to scan (only scan X-headers and unusual ones)
_STANDARD_HEADERS = {
    "from", "to", "cc", "bcc", "subject", "date", "message-id",
    "mime-version", "content-type", "content-transfer-encoding",
    "content-disposition", "in-reply-to", "references", "reply-to",
    "return-path", "received", "sender", "delivered-to",
}


