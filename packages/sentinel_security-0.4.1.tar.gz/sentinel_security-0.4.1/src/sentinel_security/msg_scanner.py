"""
Outlook .msg file scanner for prompt injection.

Uses extract-msg to parse .msg files, then delegates threat detection
to the email_scanner module.
"""

import logging
import email
import email.mime.multipart

logger = logging.getLogger(__name__)
import email.mime.text
import email.policy
from typing import Any, Dict, List

try:
    import extract_msg  # type: ignore
except ImportError:  # pragma: no cover
    extract_msg = None

from .email_scanner import _scan_email_message
from .sanitiser import sanitise_content


def scan_msg(file_path: str) -> dict:
    """
    Scan an Outlook .msg file for prompt injection threats.

    Extracts content using extract-msg, converts to a standard email.Message,
    and delegates to the email scanning logic.

    Args:
        file_path: Path to the .msg file.

    Returns:
        dict with same format as scan_eml().
    """
    if extract_msg is None:
        raise ImportError(
            "extract-msg required for Outlook .msg scanning. "
            "Install with: pip install sentinel-security[msg]"
        )

    logger.debug("scan_msg: start file=%s", file_path)
    try:
        msg_file = extract_msg.Message(file_path)
    except Exception as e:
        raise ValueError(f"Failed to parse .msg file: {e}")

    try:
        # Build a standard email.Message from extracted data
        em = email.mime.multipart.MIMEMultipart("mixed")

        # Set headers
        em["Subject"] = msg_file.subject or ""
        em["From"] = msg_file.sender or ""
        em["To"] = msg_file.to or ""
        em["Date"] = msg_file.date or ""

        # Copy any custom / X-headers from the msg
        try:
            for header_name in (msg_file.header or {}).keys():
                if header_name.lower().startswith("x-"):
                    em[header_name] = msg_file.header[header_name]
        except Exception as e:
            logger.warning("Failed to copy X-headers from .msg file: %s", e)

        # Add body text
        body = msg_file.body
        if body:
            text_part = email.mime.text.MIMEText(body, "plain")
            em.attach(text_part)

        # Add HTML body if available
        html_body = msg_file.htmlBody
        if html_body:
            if isinstance(html_body, bytes):
                html_body = html_body.decode("utf-8", errors="replace")
            html_part = email.mime.text.MIMEText(html_body, "html")
            em.attach(html_part)

        # Add attachment info (filenames only, for injection scanning)
        for attachment in (msg_file.attachments or []):
            filename = getattr(attachment, "longFilename", None) or getattr(attachment, "shortFilename", None)
            if filename:
                att_part = email.mime.text.MIMEText("")
                att_part.add_header("Content-Disposition", "attachment", filename=filename)
                em.attach(att_part)

        # Re-parse with the new EmailPolicy so .get_content() works
        # (email.mime.* uses legacy Compat32 policy which lacks it)
        em_str = em.as_string()
        em_new = email.message_from_string(em_str, policy=email.policy.default)
        result = _scan_email_message(em_new, file_path)
    finally:
        msg_file.close()

    return result
