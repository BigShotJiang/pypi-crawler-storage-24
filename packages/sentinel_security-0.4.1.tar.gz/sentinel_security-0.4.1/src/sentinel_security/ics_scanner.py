"""
Calendar invite (.ics) scanner for prompt injection.

Uses the icalendar package to detect injection in:
- SUMMARY fields
- DESCRIPTION fields (most common injection vector)
- LOCATION fields
- COMMENT fields
- VALARM descriptions
"""

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

try:
    from icalendar import Calendar  # type: ignore
except ImportError:  # pragma: no cover
    Calendar = None

from .sanitiser import calculate_risk_score, sanitise_content


def scan_ics(file_path: str) -> dict:
    """
    Scan a .ics calendar file for prompt injection threats.

    Args:
        file_path: Path to the .ics file.

    Returns:
        dict with keys:
            file (str): File path.
            threats (list): Detected threats.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.
            events_scanned (int): Number of VEVENT components scanned.
            scanned_surfaces (dict): Count of each surface type scanned.
    """
    logger.debug("scan_ics: start file=%s", file_path)
    try:
        with open(file_path, "rb") as f:
            content = f.read()
    except Exception as e:
        raise ValueError(f"Failed to read ICS file: {e}")

    result = _scan_ics_content(content)
    result["file"] = file_path
    return result


def _scan_ics_content(content) -> dict:
    """
    Core ICS scanning logic, usable from both scan_ics() and email_scanner.

    Args:
        content: ICS content as bytes or string.

    Returns:
        dict with threats, counts, and risk information.
    """
    if Calendar is None:
        raise ImportError(
            "icalendar required for ICS scanning. "
            "Install with: pip install sentinel-security[ics]"
        )

    threats: List[Dict[str, Any]] = []
    scanned_surfaces = {
        "summaries": 0,
        "descriptions": 0,
        "locations": 0,
        "alarms": 0,
    }
    events_scanned = 0

    try:
        if isinstance(content, str):
            content = content.encode("utf-8")
        cal = Calendar.from_ical(content)
    except Exception as e:
        raise ValueError(f"Failed to parse ICS content: {e}")

    for component in cal.walk():
        if component.name == "VEVENT":
            events_scanned += 1
            event_idx = events_scanned

            # SUMMARY
            summary = component.get("SUMMARY")
            if summary:
                scanned_surfaces["summaries"] += 1
                text = str(summary)
                result = sanitise_content(text, format="text")
                for t in result["threats"]:
                    t["source"] = f"event_{event_idx}_summary"
                    threats.append(t)

            # DESCRIPTION
            description = component.get("DESCRIPTION")
            if description:
                scanned_surfaces["descriptions"] += 1
                text = str(description)
                result = sanitise_content(text, format="text")
                for t in result["threats"]:
                    t["source"] = f"event_{event_idx}_description"
                    threats.append(t)

            # LOCATION
            location = component.get("LOCATION")
            if location:
                scanned_surfaces["locations"] += 1
                text = str(location)
                result = sanitise_content(text, format="text")
                for t in result["threats"]:
                    t["source"] = f"event_{event_idx}_location"
                    threats.append(t)

            # COMMENT
            comment = component.get("COMMENT")
            if comment:
                text = str(comment)
                result = sanitise_content(text, format="text")
                for t in result["threats"]:
                    t["source"] = f"event_{event_idx}_comment"
                    threats.append(t)

            # VALARM descriptions
            for sub in component.subcomponents:
                if sub.name == "VALARM":
                    alarm_desc = sub.get("DESCRIPTION")
                    if alarm_desc:
                        scanned_surfaces["alarms"] += 1
                        text = str(alarm_desc)
                        result = sanitise_content(text, format="text")
                        for t in result["threats"]:
                            t["source"] = f"event_{event_idx}_alarm"
                            threats.append(t)

    risk_score = calculate_risk_score(threats)
    logger.debug("scan_ics_content: end events=%d threats=%d", events_scanned, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_ics_content: threats detected count=%d types=%s", len(threats), types)
    return {
        "threats": threats,
        "threat_count": len(threats),
        "risk_score": risk_score,
        "risk_level": (
            "CLEAN" if risk_score == 0 else
            "LOW" if risk_score <= 2 else
            "MEDIUM" if risk_score <= 5 else
            "HIGH" if risk_score <= 8 else
            "CRITICAL"
        ),
        "events_scanned": events_scanned,
        "scanned_surfaces": scanned_surfaces,
    }


