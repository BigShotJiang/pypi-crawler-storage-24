"""Tests for Microsoft Graph API authentication helper."""

import json
import os
import pytest
from unittest.mock import Mock, patch, MagicMock

from sentinel_security.ms_auth import get_graph_client, _load_ms_credentials


def test_load_ms_credentials(tmp_path):
    """Test loading credentials from JSON file."""
    creds = {'tenant_id': 't1', 'client_id': 'c1', 'client_secret': 's1'}
    cred_file = tmp_path / 'creds.json'
    cred_file.write_text(json.dumps(creds))

    result = _load_ms_credentials(str(cred_file))
    assert result == creds


def test_load_ms_credentials_not_found():
    """Test FileNotFoundError for missing credentials."""
    with pytest.raises(FileNotFoundError):
        _load_ms_credentials('/nonexistent/path.json')


@patch.dict(os.environ, {}, clear=True)
def test_get_graph_client_no_tenant():
    """Test ValueError when tenant_id is missing."""
    with pytest.raises(ValueError, match="tenant_id required"):
        get_graph_client()


@patch.dict(os.environ, {'SENTINEL_MS_TENANT_ID': 'tenant1'}, clear=True)
def test_get_graph_client_no_client():
    """Test ValueError when client_id is missing."""
    with pytest.raises(ValueError, match="client_id required"):
        get_graph_client()


@patch('sentinel_security.ms_auth.msal', create=True)
@patch('sentinel_security.ms_auth.requests', create=True)
def test_get_graph_client_confidential(mock_requests, mock_msal):
    """Test confidential client flow with client_secret."""
    # Mock MSAL
    import sentinel_security.ms_auth as mod

    mock_app = MagicMock()
    mock_app.acquire_token_silent.return_value = None
    mock_app.acquire_token_for_client.return_value = {'access_token': 'test-token'}

    with patch.object(mod, 'get_graph_client', wraps=mod.get_graph_client):
        with patch('msal.ConfidentialClientApplication', return_value=mock_app):
            with patch('requests.Session') as mock_session_cls:
                mock_session = MagicMock()
                mock_session_cls.return_value = mock_session

                result = get_graph_client(
                    tenant_id='t1', client_id='c1', client_secret='s1'
                )
                mock_session.headers.update.assert_called_once()
                call_args = mock_session.headers.update.call_args[0][0]
                assert call_args['Authorization'] == 'Bearer test-token'


@patch('msal.PublicClientApplication')
@patch('requests.Session')
def test_get_graph_client_device_code(mock_session_cls, mock_pub_app_cls):
    """Test device code flow without client_secret."""
    mock_app = MagicMock()
    mock_app.initiate_device_flow.return_value = {
        'user_code': 'ABC123',
        'message': 'Go to https://microsoft.com/devicelogin',
    }
    mock_app.acquire_token_by_device_flow.return_value = {'access_token': 'user-token'}
    mock_pub_app_cls.return_value = mock_app

    mock_session = MagicMock()
    mock_session_cls.return_value = mock_session

    result = get_graph_client(tenant_id='t1', client_id='c1')
    call_args = mock_session.headers.update.call_args[0][0]
    assert call_args['Authorization'] == 'Bearer user-token'


@patch('msal.ConfidentialClientApplication')
@patch('requests.Session')
def test_get_graph_client_token_failure(mock_session_cls, mock_conf_app_cls):
    """Test RuntimeError when token acquisition fails."""
    mock_app = MagicMock()
    mock_app.acquire_token_silent.return_value = None
    mock_app.acquire_token_for_client.return_value = {'error': 'invalid_client', 'error_description': 'Bad secret'}
    mock_conf_app_cls.return_value = mock_app

    with pytest.raises(RuntimeError, match="Token acquisition failed"):
        get_graph_client(tenant_id='t1', client_id='c1', client_secret='bad')


def test_get_graph_client_from_env():
    """Test loading from environment variables."""
    env = {
        'SENTINEL_MS_TENANT_ID': 'env-tenant',
        'SENTINEL_MS_CLIENT_ID': 'env-client',
        'SENTINEL_MS_CLIENT_SECRET': 'env-secret',
    }
    with patch.dict(os.environ, env, clear=True):
        with patch('msal.ConfidentialClientApplication') as mock_cls:
            mock_app = MagicMock()
            mock_app.acquire_token_silent.return_value = None
            mock_app.acquire_token_for_client.return_value = {'access_token': 'tok'}
            mock_cls.return_value = mock_app

            with patch('requests.Session') as mock_sess:
                mock_sess.return_value = MagicMock()
                get_graph_client()
                mock_cls.assert_called_once_with(
                    'env-client',
                    authority='https://login.microsoftonline.com/env-tenant',
                    client_credential='env-secret',
                )


def test_get_graph_client_from_file(tmp_path):
    """Test loading from credentials file."""
    creds = {'tenant_id': 'ft', 'client_id': 'fc', 'client_secret': 'fs'}
    cred_file = tmp_path / 'creds.json'
    cred_file.write_text(json.dumps(creds))

    with patch('msal.ConfidentialClientApplication') as mock_cls:
        mock_app = MagicMock()
        mock_app.acquire_token_silent.return_value = None
        mock_app.acquire_token_for_client.return_value = {'access_token': 'tok'}
        mock_cls.return_value = mock_app

        with patch('requests.Session') as mock_sess:
            mock_sess.return_value = MagicMock()
            get_graph_client(credentials_path=str(cred_file))
            mock_cls.assert_called_once_with(
                'fc',
                authority='https://login.microsoftonline.com/ft',
                client_credential='fs',
            )
