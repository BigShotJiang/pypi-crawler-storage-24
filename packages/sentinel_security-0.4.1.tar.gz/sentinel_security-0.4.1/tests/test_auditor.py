"""
Tests for the prompt auditor module.

Port of tests from prompt-auditor JavaScript tests.
"""

import pytest
import json
from pathlib import Path
from sentinel_security.auditor import scan, compute_score, generate_patches, audit


def _load_fixture(name):
    """Load a test fixture from prompt-auditor/tests/fixtures/."""
    fixture_path = Path(__file__).parent.parent.parent / "prompt-auditor" / "tests" / "fixtures" / f"{name}.txt"
    with open(fixture_path, 'r', encoding='utf-8') as f:
        return f.read()


def test_scan_bare_minimum():
    """Test scan with bare-minimum fixture (all rules should fail)."""
    prompt = _load_fixture("bare-minimum")
    results = scan(prompt)
    
    assert len(results) > 0
    # All rules should fail for bare minimum prompt
    for result in results:
        assert result['status'] == 'fail'
        assert len(result['matched_patterns']) == 0
        assert len(result['matched_keywords']) == 0


def test_scan_well_hardened():
    """Test scan with well-hardened fixture (all rules should pass)."""
    prompt = _load_fixture("well-hardened")
    results = scan(prompt)
    
    assert len(results) > 0
    # All rules should pass for well-hardened prompt
    for result in results:
        assert result['status'] == 'pass'
        # Should have matched patterns or keywords
        assert len(result['matched_patterns']) >= 2 or len(result['matched_keywords']) >= 4


def test_scan_partial():
    """Test scan with partial fixture (mix of statuses)."""
    prompt = _load_fixture("partial")
    results = scan(prompt)
    
    assert len(results) > 0
    # Should have at least some partial or pass results
    statuses = [r['status'] for r in results]
    assert 'partial' in statuses or 'pass' in statuses
    # Should also have some fails
    assert 'fail' in statuses


def test_scan_type_error():
    """Test scan raises TypeError on non-string input."""
    with pytest.raises(TypeError, match='prompt_text must be a string'):
        scan(123)
    
    with pytest.raises(TypeError, match='prompt_text must be a string'):
        scan(None)
    
    with pytest.raises(TypeError, match='prompt_text must be a string'):
        scan([])


def test_compute_score_all_fail():
    """Test score computation when all rules fail."""
    prompt = _load_fixture("bare-minimum")
    results = scan(prompt)
    score = compute_score(results)
    
    assert score['score'] == 0
    assert score['grade'] == 'F'
    assert score['max_score'] == 100
    assert score['breakdown']['critical'] == '0/60'
    assert score['breakdown']['high'] == '0/24'
    assert score['breakdown']['medium'] == '0/12'
    assert score['breakdown']['low'] == '0/4'


def test_compute_score_all_pass():
    """Test score computation when all rules pass."""
    prompt = _load_fixture("well-hardened")
    results = scan(prompt)
    score = compute_score(results)
    
    assert score['score'] == 100
    assert score['grade'] == 'A'
    assert score['max_score'] == 100
    # All points should be earned
    assert score['breakdown']['critical'] == '60/60'
    assert score['breakdown']['high'] == '24/24'
    assert score['breakdown']['medium'] == '12/12'
    assert score['breakdown']['low'] == '4/4'


def test_compute_score_grades():
    """Test grade boundaries."""
    # Mock scan results for grade testing
    mock_results = [
        {'rule_id': 'test1', 'severity': 'critical', 'status': 'pass'},
        {'rule_id': 'test2', 'severity': 'high', 'status': 'partial'},
    ]
    
    # We need to mock the rules data for this test
    # Since we can't easily mock the loaded rules, we'll test with actual fixtures
    prompt = _load_fixture("partial")
    results = scan(prompt)
    score = compute_score(results)
    
    # Score should be between 0 and 100
    assert 0 <= score['score'] <= 100
    # Grade should be one of A, B, C, D, F
    assert score['grade'] in ['A', 'B', 'C', 'D', 'F']
    
    # Verify grade matches score
    if score['score'] >= 90:
        assert score['grade'] == 'A'
    elif score['score'] >= 75:
        assert score['grade'] == 'B'
    elif score['score'] >= 60:
        assert score['grade'] == 'C'
    elif score['score'] >= 40:
        assert score['grade'] == 'D'
    else:
        assert score['grade'] == 'F'


def test_compute_score_breakdown_format():
    """Test score breakdown format."""
    prompt = _load_fixture("well-hardened")
    results = scan(prompt)
    score = compute_score(results)
    
    breakdown = score['breakdown']
    assert 'critical' in breakdown
    assert 'high' in breakdown
    assert 'medium' in breakdown
    assert 'low' in breakdown
    
    # Format should be "earned/max"
    for key in breakdown:
        parts = breakdown[key].split('/')
        assert len(parts) == 2
        earned, max_points = parts
        assert earned.isdigit()
        assert max_points.isdigit()
        assert int(earned) <= int(max_points)


def test_generate_patches_all_pass():
    """Test patcher generates no patches when all rules pass."""
    prompt = _load_fixture("well-hardened")
    results = scan(prompt)
    patches = generate_patches(results)
    
    # No patches should be generated for passing rules
    assert len(patches) == 0


def test_generate_patches_all_fail():
    """Test patcher generates patches for all failing rules."""
    prompt = _load_fixture("bare-minimum")
    results = scan(prompt)
    patches = generate_patches(results)
    
    # Should have patches for all failing rules
    assert len(patches) > 0
    
    # All patches should be for fail or partial status
    for patch in patches:
        assert patch['current_status'] in ['fail', 'partial']
        assert 'rule_id' in patch
        assert 'severity' in patch
        assert 'suggested_text' in patch
        assert 'insertion_hint' in patch
    
    # Patches should be sorted by severity (critical first)
    severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
    for i in range(len(patches) - 1):
        assert severity_order[patches[i]['severity']] <= severity_order[patches[i + 1]['severity']]


def test_generate_patches_mixed():
    """Test patcher generates patches only for fail/partial rules."""
    prompt = _load_fixture("partial")
    results = scan(prompt)
    patches = generate_patches(results)
    
    # Count fail/partial results
    fail_partial_count = sum(1 for r in results if r['status'] in ['fail', 'partial'])
    
    # Should have patches for all fail/partial rules (if fixes exist)
    assert len(patches) <= fail_partial_count
    
    # No patches for passing rules
    for patch in patches:
        assert patch['current_status'] in ['fail', 'partial']


def test_audit_complete_report():
    """Test audit() returns complete report."""
    prompt = _load_fixture("well-hardened")
    report = audit(prompt)
    
    assert 'scan_results' in report
    assert 'score' in report
    assert 'patches' in report
    assert 'audited_at' in report
    
    # Score should be a dict with expected keys
    assert 'score' in report['score']
    assert 'grade' in report['score']
    assert 'max_score' in report['score']
    assert 'breakdown' in report['score']
    
    # Patches should be a list
    assert isinstance(report['patches'], list)
    
    # Audit timestamp should be ISO format ending with Z
    assert report['audited_at'].endswith('Z')
    # Should be parseable as ISO datetime
    from datetime import datetime
    datetime.fromisoformat(report['audited_at'].rstrip('Z'))


def test_audit_bare_minimum():
    """Test audit with bare-minimum prompt."""
    prompt = _load_fixture("bare-minimum")
    report = audit(prompt)
    
    assert report['score']['score'] == 0
    assert report['score']['grade'] == 'F'
    assert len(report['patches']) > 0


def test_audit_partial():
    """Test audit with partial prompt."""
    prompt = _load_fixture("partial")
    report = audit(prompt)
    
    # Score should be between 0 and 100
    assert 0 <= report['score']['score'] <= 100
    # Should have some patches
    assert len(report['patches']) > 0


def test_scan_empty_string():
    """Test scan with empty string."""
    results = scan("")
    
    assert len(results) > 0
    # Empty string should fail all rules
    for result in results:
        assert result['status'] == 'fail'


def test_scan_whitespace_only():
    """Test scan with whitespace-only string."""
    results = scan("   \n\t  ")
    
    assert len(results) > 0
    # Whitespace-only should fail all rules
    for result in results:
        assert result['status'] == 'fail'


def test_scan_case_insensitive():
    """Test that scan is case-insensitive for keywords."""
    # Test with uppercase version of keywords
    test_prompt = "This prompt has BOUNDARY and UNTRUSTED keywords."
    results = scan(test_prompt)
    
    # Check if keywords were matched case-insensitively
    for result in results:
        if 'boundary' in [k.lower() for k in result['matched_keywords']]:
            assert 'BOUNDARY' in test_prompt or 'boundary' in test_prompt.lower()
        if 'untrusted' in [k.lower() for k in result['matched_keywords']]:
            assert 'UNTRUSTED' in test_prompt or 'untrusted' in test_prompt.lower()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
