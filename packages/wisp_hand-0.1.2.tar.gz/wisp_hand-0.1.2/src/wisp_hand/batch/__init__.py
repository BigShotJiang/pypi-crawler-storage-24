"""Batch domain package."""
