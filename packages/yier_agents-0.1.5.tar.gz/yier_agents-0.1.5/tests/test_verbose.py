"""Tests for verbose parameter."""

import pytest
from io import StringIO
import sys

from yier_agents.src.agent import Agent
from yier_agents.src.llm import LLM


def test_verbose_disabled_by_default():
    """Test that verbose is disabled by default."""
    llm = LLM(
        base_url="https://api.openai.com/v1",
        api_key="test-key",
        model="gpt-4"
    )

    agent = Agent(llm=llm, tools=[])

    assert agent.verbose is False


def test_verbose_can_be_enabled():
    """Test that verbose can be enabled."""
    llm = LLM(
        base_url="https://api.openai.com/v1",
        api_key="test-key",
        model="gpt-4"
    )

    agent = Agent(llm=llm, tools=[], verbose=True)

    assert agent.verbose is True


def test_log_method_disabled():
    """Test that _log doesn't print when verbose=False."""
    llm = LLM(
        base_url="https://api.openai.com/v1",
        api_key="test-key",
        model="gpt-4"
    )

    agent = Agent(llm=llm, tools=[], verbose=False)

    # Capture stdout
    captured_output = StringIO()
    sys.stdout = captured_output

    agent._log("Test message", "info")

    # Reset stdout
    sys.stdout = sys.__stdout__

    # Should have no output
    output = captured_output.getvalue()
    assert output == ""


def test_log_method_enabled():
    """Test that _log prints when verbose=True."""
    llm = LLM(
        base_url="https://api.openai.com/v1",
        api_key="test-key",
        model="gpt-4"
    )

    agent = Agent(llm=llm, tools=[], verbose=True)

    # Capture stdout
    captured_output = StringIO()
    sys.stdout = captured_output

    agent._log("Test message", "info")

    # Reset stdout
    sys.stdout = sys.__stdout__

    # Should have output with icon and message
    output = captured_output.getvalue()
    assert "Test message" in output
    assert "ℹ" in output  # info icon


def test_log_levels():
    """Test different log levels."""
    llm = LLM(
        base_url="https://api.openai.com/v1",
        api_key="test-key",
        model="gpt-4"
    )

    agent = Agent(llm=llm, tools=[], verbose=True)

    levels = ["info", "success", "warning", "tool"]

    for level in levels:
        # Capture stdout
        captured_output = StringIO()
        sys.stdout = captured_output

        agent._log(f"Test {level} message", level)

        # Reset stdout
        sys.stdout = sys.__stdout__

        # Should have output
        output = captured_output.getvalue()
        assert f"Test {level} message" in output

        # Check icons
        expected_icons = {
            "info": "ℹ",
            "success": "✓",
            "warning": "⚠",
            "tool": "⚙"
        }
        assert expected_icons[level] in output
