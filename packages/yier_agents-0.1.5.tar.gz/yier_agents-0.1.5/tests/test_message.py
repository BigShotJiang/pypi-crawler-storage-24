"""测试消息类型定义"""
import pytest
from yier_agents.src.message import ToolCall, ToolResult, Message, LLMResponse


def test_tool_call_creation():
    """测试 ToolCall 创建"""
    tc = ToolCall(
        id="call_123",
        name="read_file",
        arguments={"file_path": "/tmp/test.txt"}
    )
    assert tc.id == "call_123"
    assert tc.name == "read_file"
    assert tc.arguments["file_path"] == "/tmp/test.txt"


def test_tool_result_creation():
    """测试 ToolResult 创建"""
    tr = ToolResult(
        call_id="call_123",
        name="read_file",
        content="file content here",
        metadata={"path": "demo.txt"},
        raw={"kind": "shell_command"},
    )
    assert tr.call_id == "call_123"
    assert tr.name == "read_file"
    assert tr.content == "file content here"
    assert tr.metadata["path"] == "demo.txt"
    assert tr.raw["kind"] == "shell_command"


def test_user_message():
    """测试用户消息"""
    msg = Message(role="user", content="Hello")
    assert msg.role == "user"
    assert msg.content == "Hello"
    assert msg.tool_calls is None
    assert msg.tool_call_id is None


def test_assistant_message_with_tool_calls():
    """测试带工具调用的助手消息"""
    msg = Message(
        role="assistant",
        content="Let me check that file",
        tool_calls=[
            ToolCall(id="call_1", name="read_file", arguments={"path": "test.txt"})
        ]
    )
    assert msg.role == "assistant"
    assert msg.content == "Let me check that file"
    assert len(msg.tool_calls) == 1
    assert msg.tool_calls[0].name == "read_file"


def test_tool_message():
    """测试工具消息"""
    msg = Message(
        role="tool",
        content="File content",
        tool_call_id="call_1"
    )
    assert msg.role == "tool"
    assert msg.tool_call_id == "call_1"


def test_llm_response_stop():
    """测试 LLM 响应 - stop"""
    response = LLMResponse(
        message=Message(role="assistant", content="Done!"),
        finish_reason="stop",
        usage=15  # Total tokens
    )
    assert response.finish_reason == "stop"
    assert response.message.content == "Done!"
    assert response.usage == 15


def test_llm_response_tool_calls():
    """测试 LLM 响应 - tool_calls"""
    response = LLMResponse(
        message=Message(
            role="assistant",
            tool_calls=[ToolCall(id="c1", name="tool", arguments={})]
        ),
        finish_reason="tool_calls"
    )
    assert response.finish_reason == "tool_calls"
    assert len(response.message.tool_calls) == 1
