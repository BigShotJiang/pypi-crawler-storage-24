"""消息和类型定义"""

from typing import Any, Literal

from pydantic import BaseModel, Field


class ToolCall(BaseModel):
    """工具调用"""
    id: str
    name: str
    arguments: dict[str, Any]


class ToolResult(BaseModel):
    """工具执行结果"""
    call_id: str
    name: str
    content: str
    is_error: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)
    raw: dict[str, Any] = Field(default_factory=dict)


class Message(BaseModel):
    """消息基类"""
    role: Literal["system", "user", "assistant", "tool"]
    content: str | None = None
    reasoning_content: str | None = None  # 思考过程内容 (用于支持 o1, Claude thinking 等)
    tool_calls: list[ToolCall] | None = None
    tool_call_id: str | None = None


class LLMResponse(BaseModel):
    """LLM 调用响应"""
    message: Message
    finish_reason: Literal["stop", "tool_calls", "length"]
    usage: int | None = None  # Total tokens used
