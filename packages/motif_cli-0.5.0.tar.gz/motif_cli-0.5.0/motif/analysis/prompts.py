"""
Analysis prompt for Motif CLI.

Contains the core prompt that instructs the host agent (Cursor/Claude Code)
what to look for when analyzing conversation data.
"""


def get_prompt_version() -> str:
    """Return the version string for this prompt."""
    return "0.3.0"


def get_analysis_prompt() -> str:
    """Return the full analysis prompt for the host agent."""
    return """---

## Analysis Instructions

You are analyzing AI coding assistant conversation history to discover the user's patterns, workflows, and preferences. Your goal is to surface actionable insights that can be turned into Cursor skills, rules, and personalized guidance.

### What to discover

1. **Recurring workflows / skills** (3+ occurrences)
   - Look for: trigger phrases, consistent step sequences, repeated file paths
   - Rate confidence: high (5+ occurrences), medium (3-4), low (2)
   - Only recommend skills for patterns that repeat meaningfully
   - For each skill, provide a rich outline:
     - `name`: kebab-case slug
     - `trigger`: when to activate
     - `purpose`: 1-2 sentences (why this skill exists, what it prevents)
     - `when_to_use`: specific trigger conditions including "especially when..." and "don't skip when..." patterns
     - `instructions`: 5-10 step-by-step instructions with decision points and error handling (not just 3-5)
     - `best_practices`: do/don't patterns observed from conversations
     - `common_pitfalls`: what goes wrong when workflow isn't followed (problem + solution)
     - `key_constraints`: non-negotiable rules for this workflow

2. **Correction-derived rules**
   - Where the user pushes back on agent output
   - "don't do X", explicit instructions, user rewrites
   - These reveal implicit preferences and constraints

3. **Communication style**
   - Terse vs detailed, structured feedback patterns, correction style
   - Proactivity expectations (does the user want the agent to anticipate or wait for instructions?)

4. **Session-level patterns**
   - How sessions start and end
   - Rituals (e.g., always deploys at end, always refreshes on project state)

5. **Improvement areas**
   - Repeated corrections on same issue = missing rule
   - "Did you actually check X?" = missing verification step

6. **Project context**
   - What is this project, key entities, tools used

7. **Scope classification** (IMPORTANT)
   - For every skill and rule, classify its scope as `"project"` or `"user"`.
   - **project**: References specific file paths, deployment targets, project-specific tools/services, tech stack, domain entities. Only useful inside this codebase.
   - **user**: Communication preferences, session rituals, general coding habits, correction patterns not tied to a specific codebase. Useful across all projects.
   - Include a `scope_reason` explaining the classification.
   - When analyzing data from multiple projects (`--all` mode), patterns appearing across 3+ projects are strong `user` signals. Patterns only in one project default to `project`.
   - When analyzing a single project, use content analysis: does it reference project-specific entities?

8. **Existing CLAUDE.md awareness** (IMPORTANT)
   - If an `## Existing CLAUDE.md` section appears in this document, the user already has rules and configuration.
   - **Do NOT suggest rules that duplicate what already exists.** If an existing rule covers the same concern, skip it or suggest a refinement instead.
   - **Do NOT suggest skills that duplicate existing workflow triggers.** Check the existing CLAUDE.md for workflow trigger tables or skill references.
   - For rules that would enhance or refine existing ones, mark them with `"existing_overlap": "rule name or section it overlaps with"` and explain the delta.
   - Your output should be **additive**   only new patterns the existing config doesn't already cover, or specific refinements to what's there.

### What NOT to do

- Don't impose rigid categories; let the data drive the structure
- Don't recommend skills for one-off occurrences
- Don't generate complete skill files   provide structured outlines with purpose, instructions (5-10 steps), best practices, and pitfalls
- Don't recommend skills for things too varied to templatize
- Don't suggest rules that already exist in the user's CLAUDE.md (if provided)

### Data notes

- **Pasted data:** Some messages contain pasted data (profiles, email threads, JSON) below the user's instruction. Focus on the instruction, not the pasted data.
- **Minimum data:** If fewer than 20 user messages are available, note that findings may be thin and recommend the user accumulate more conversation history.
- **Existing CLAUDE.md:** If present in the prepared data, use it as context to avoid duplicating existing rules and to suggest targeted edits rather than a full rewrite.

### Output format

Respond with valid JSON in this structure:

```json
{
  "skills": [
    {
      "name": "string",
      "trigger": "string",
      "purpose": "string (why this skill exists, what it prevents)",
      "when_to_use": ["condition1", "condition2"],
      "instructions": ["step1 with decision points", "step2", "..."],
      "best_practices": ["do X because Y", "don't do Z because W"],
      "common_pitfalls": [{"problem": "string", "solution": "string"}],
      "key_constraints": ["non-negotiable rule 1"],
      "evidence": ["quote or summary from conversation"],
      "confidence": "high|medium|low",
      "frequency": "string",
      "scope": "project|user",
      "scope_reason": "string"
    }
  ],
  "rules": [
    {
      "name": "string",
      "enforces": "string",
      "evidence": ["quote or summary"],
      "confidence": "high|medium|low",
      "scope": "project|user",
      "scope_reason": "string"
    }
  ],
  "communication_style": {
    "brevity": "string",
    "feedback_pattern": "string",
    "correction_style": "string",
    "proactivity_expectation": "string"
  },
  "session_patterns": {
    "startup": "string",
    "wrapup": "string",
    "evidence": ["quote or summary"]
  },
  "improvement_areas": [
    {
      "problem": "string",
      "evidence": ["quote or summary"],
      "proposed_rule": "string"
    }
  ],
  "project_context": {
    "description": "string",
    "key_entities": ["string"],
    "tools_used": ["string"]
  }
}
```
"""


def get_vibe_report_prompt() -> str:
    """Return a lightweight analysis prompt for qualitative vibe report enrichment.

    Produces personality/narrative content   no skills or rules.
    Designed for a ~20k token budget (much cheaper than full analysis).
    """
    return """---

## Vibe Report Analysis Instructions

You are analyzing AI coding conversation history to produce **qualitative insights for a shareable vibe report**. This is NOT the full skills/rules analysis   focus only on personality, narrative, and strengths.

Read the conversation data above and produce a JSON with these sections:

### Output format

Respond with valid JSON in this structure:

```json
{
  "archetype": {
    "name": "string   a punchy 2-4 word title (e.g., 'The Architect', 'The Speed Demon', 'The Methodical Builder')",
    "description": "string   1-2 sentences explaining the archetype based on evidence"
  },
  "superpowers": [
    {
      "name": "string   short label (e.g., 'Decomposition', 'Recovery', 'Parallel Thinking')",
      "description": "string   1 sentence with evidence from conversations"
    }
  ],
  "communication_style": "string   2-3 punchy sentences. How do they talk to AI? Terse or verbose? Structured or freeform? How do they give feedback?",
  "growth_narrative": "string   3-5 sentences. How has this person evolved? Compare early sessions to recent ones. What changed in how they work with AI?",
  "notable_moments": [
    {
      "quote": "string   exact or near-exact quote from the user (keep it short, punchy)",
      "context": "string   1 sentence explaining when/why they said it"
    }
  ],
  "blind_spots": [
    {
      "name": "string   short label",
      "description": "string   1 sentence, framed constructively (growth opportunity, not criticism)"
    }
  ]
}
```

### Guidelines

- **Superpowers**: Identify 2-3. These should be genuinely impressive things, not generic compliments. Use evidence.
- **Notable moments**: Pick 2-3 quotes that are funny, revealing, or show personality. Prefer the user's actual words.
- **Blind spots**: Identify 1-2. Frame as growth opportunities. Be honest but constructive.
- **Growth narrative**: If early vs late sessions show clear evolution, highlight it. If data is limited, say so briefly.
- **Communication style**: Be specific. "Terse" is too vague   "Leads with the desired outcome in 1 sentence, adds constraints as bullet points" is better.
- **Archetype**: Should feel earned, not forced. If the data doesn't clearly suggest one, pick the closest fit and note it in the description.
- **Keep it real**: This is a shareable report. The user will show it to others. Be honest and specific, not flattering and generic.

### What NOT to do

- Don't produce skills, rules, or actionable config   that's a separate flow
- Don't analyze pasted data (JSON blobs, email threads)   focus on the user's own words
- Don't invent quotes   use actual phrases from the conversations, or paraphrase closely
- Don't be generic   "good at problem solving" is useless. "Consistently breaks 3-day features into 20-minute agent sprints by writing detailed specs upfront" is useful.
"""
