"""
Sovereign Shield Adaptive Security Plugin
==========================================
Self-improving security filter for AI applications.

Reports missed attacks, sandbox-tests new rules against historical data,
and auto-deploys validated filters — all locally with zero cloud dependencies.

Usage:
    from adaptive_shield import AdaptiveShield

    shield = AdaptiveShield()                        # uses ./data/adaptive.db
    result = shield.scan("some user input")          # scan input
    shield.report(result["scan_id"], "missed this")  # report false negative
"""

from adaptive_shield.core import AdaptiveShield

__version__ = "1.3.1"
__all__ = ["AdaptiveShield"]
