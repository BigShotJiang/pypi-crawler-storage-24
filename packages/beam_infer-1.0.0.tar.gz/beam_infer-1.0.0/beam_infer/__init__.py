"""Beam-Infer: Beam simulation and parameter inference package.

Supported public API
--------------------
- ``estimate_with_optimizer``  -- full pipeline (preprocess + optimize)
- ``run_minimization_inference`` -- single L-BFGS-B run
- ``run_multistart_minimization`` -- multistart L-BFGS-B
- ``run_mcmc_inference`` -- Metropolis-Hastings MCMC
- ``run_parallel_tempering`` -- replica-exchange (parallel tempering) MCMC
- ``build_beta_ladder``, ``sample_from_prior`` -- helpers for PT

Configuration and results are controlled via dataclasses:
``Metadata``, ``OptimizerConfig``, ``OptimizerResult``,
``MinimizationConfig``, ``MinimizationResult``, ``MultistartResult``,
``MCMCConfig``, ``MCMCResult``.
"""

__version__ = "0.1.0"

# Optimizer interface (full pipeline)
from beam_infer.minimization.optimizer_interface import (
    Metadata,
    OptimizerConfig,
    OptimizerResult,
    estimate_with_optimizer,
)

# Minimization interface (lower-level control)
from beam_infer.minimization.minimization_interface import (
    MinimizationConfig,
    MinimizationResult,
    MultistartResult,
    run_minimization_inference,
    run_multistart_minimization,
)

# MCMC interface
from beam_infer.mcmc.mcmc_interface import (
    MCMCConfig,
    MCMCResult,
    run_mcmc_inference,
)

# Parallel tempering (replica-exchange MCMC)
from beam_infer.mcmc.parallel_tempering import (
    build_beta_ladder,
    sample_from_prior,
    run_parallel_tempering,
)

__all__ = [
    "__version__",
    # Optimizer
    "estimate_with_optimizer",
    "Metadata",
    "OptimizerConfig",
    "OptimizerResult",
    # Minimization
    "run_minimization_inference",
    "run_multistart_minimization",
    "MinimizationConfig",
    "MinimizationResult",
    "MultistartResult",
    # MCMC
    "run_mcmc_inference",
    "MCMCConfig",
    "MCMCResult",
    # Parallel tempering
    "build_beta_ladder",
    "sample_from_prior",
    "run_parallel_tempering",
]
