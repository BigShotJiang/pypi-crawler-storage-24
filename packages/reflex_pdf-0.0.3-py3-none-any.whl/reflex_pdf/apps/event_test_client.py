"""Helpers for testing Reflex events without Swagger UI."""

from __future__ import annotations

import time

import socketio

from reflex_pdf.apps.viewer import State


def post_pdf_url_event(app_url: str, pdf_url: str, token: str = "test-token") -> None:
    """Post the ``State.set_pdf_url`` Reflex event to a running app.

    Args:
        app_url: Base URL where the Reflex app is running (for example ``http://127.0.0.1:3000``).
        pdf_url: PDF URL to send to ``State.set_pdf_url``.
        token: Reflex token to associate with the event.
    """
    event_spec = State.set_pdf_url(pdf_url)
    event_name = f"{event_spec.handler.state_full_name}.set_pdf_url"

    client = socketio.SimpleClient()
    try:
        client.connect(
            f"{app_url}?token={token}",
            namespace="/_event",
            socketio_path="/_event/socket.io",
            transports=["websocket"],
        )
        client.emit(
            "event",
            {
                "token": token,
                "name": event_name,
                "router_data": {},
                "payload": {"url": pdf_url},
            },
        )
        time.sleep(0.05)
    finally:
        client.disconnect()
