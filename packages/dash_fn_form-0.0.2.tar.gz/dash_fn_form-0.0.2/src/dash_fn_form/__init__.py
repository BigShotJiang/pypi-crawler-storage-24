# Copyright (c) Simon Niederberger.
# Distributed under the terms of the MIT License.

"""dash-fn-form — introspect a typed callable into a Dash form."""

from dash_fn_form._field_components import (
    FieldMaker,
    make_dbc_field,
    make_dcc_field,
    make_dmc_field,
)
from dash_fn_form._forms import FieldRef, FnForm, Form, field_id
from dash_fn_form._renderers import register_renderer
from dash_fn_form._spec import Field, FieldHook, FromComponent, fixed
from dash_fn_form.fn_interact import FnPanel, build_fn_panel
from dash_fn_form.layout import Accordion, Section, Tabs

__all__ = [
    "Accordion",
    "Field",
    "FieldHook",
    "FieldMaker",
    "FieldRef",
    "FnPanel",
    "FnForm",
    "Form",
    "FromComponent",
    "Section",
    "Tabs",
    "build_fn_panel",
    "field_id",
    "fixed",
    "make_dbc_field",
    "make_dcc_field",
    "make_dmc_field",
    "register_renderer",
]
