# Sessions

Record MCP session open/close events for connection lifecycle tracking.

## Usage

```python
from mcp_observability import create_mcp_observability_easy

obs = create_mcp_observability_easy(service_name="my-mcp")

# When a client connects
obs.record_session("open", "sess-abc-123", platform="claude")

# When a client disconnects
obs.record_session("close", "sess-abc-123", platform="claude")
```

## Emitted event fields

| Field | Type | Description |
|---|---|---|
| `type` | `"mcp_session"` | Event discriminator |
| `timestamp` | `float` | Auto-set (milliseconds since epoch) |
| `service` | `str` | From config |
| `service_version` | `str \| None` | From config |
| `environment` | `str \| None` | From config |
| `action` | `"open" \| "close"` | Session lifecycle action |
| `session_id` | `str` | Your session identifier |
| `platform` | `str \| None` | AI platform that initiated the session (e.g., `"claude"`, `"chatgpt"`, `"other"`) |

> **Note:** Session events **always bypass sampling**. Even at `sample_rate=0`, every session open/close is captured. This ensures accurate session counts in analytics.

## Metrics

The `InMemorySink.get_metrics()` method includes session counts:

```python
metrics = sink.get_metrics()
# metrics["sessions"] → {"open": 5, "close": 3}
```

## Detecting the platform automatically

Use `detect_platform()` to identify which AI platform initiated the session:

```python
from mcp_observability import detect_platform, PlatformHints

platform = detect_platform(PlatformHints(headers=request_headers))
obs.record_session("open", session_id, platform=platform)
```

See [Platform Detection](./platform-detection.md) for full details.

## Next steps

- [Platform Detection](./platform-detection.md)
- [Business events](./business-events.md)
- [UI events](./ui-events.md)
