# Troubleshooting

Common issues and how to resolve them.

## No events appearing

**Symptom:** `sink.get_events()` returns an empty list.

**Causes:**
1. **Sample rate is 0** — Check your `sample_rate` config. At `0`, only errors and sessions pass through.
2. **No sinks configured** — If `sinks` is an empty list, the SDK falls back to a console sink. Ensure you're checking the right sink instance.
3. **Easy setup not called** — `create_telemetry_routes()` reads from module globals. Call `create_mcp_observability_easy()` before mounting the routes.

## Dashboard shows "Local telemetry not enabled"

**Cause:** No `InMemorySink` was registered in the module globals.

**Fix:** Either:
- Use `create_mcp_observability_easy()` with `enable_local_dashboard=True` (default in dev)
- Or manually configure sinks and use the `InMemorySink` directly

## RemoteSink not sending events

**Checklist:**
1. Verify `endpoint` and `api_key` are set
2. Check for client errors (4xx) in console
3. Ensure `destroy()` is called on shutdown to flush remaining events

```python
from mcp_observability import create_remote_sink, RemoteSinkOptions

sink = create_remote_sink(RemoteSinkOptions(
    endpoint="https://api.listoai.co/v1/events/batch",
    api_key="your-key",
))
```

## POST `/telemetry/event` returns 400

The endpoint validates:
- Body must be a JSON object
- `name` must be a non-empty string
- `category` must be a valid `EventCategory` if provided
- Body must be under 8 KB

Check your request with:

```bash
curl -X POST http://localhost:8000/telemetry/event \
  -H 'Content-Type: application/json' \
  -d '{"name": "test_event", "action": "click"}'
```

## Starlette not found

`create_telemetry_routes()` requires Starlette. If you see `ImportError`, install it:

```bash
pip install "listo-mcp-observability[starlette]"
```

Starlette is an optional dependency, not a core dependency of this package.

## Upgrade from v0.0.x

The following breaking changes were made in v0.1.0:

| Change | Migration |
|---|---|
| `UserLocation` removed | Delete all `UserLocation` usage |
| `user_id` removed from all events | Remove `user_id` from event construction and tracking context |
| `record_business_event` now keyword-only | Change `record_business_event("x", {...}, "ok")` → `record_business_event("x", properties={...}, status="ok")` |
| `record_ui_event` keyword-only, `user_id` removed | Remove `user_id=`, add `category=`/`device_id=` if needed |
| Env vars renamed | Use `LISTO_API_URL`/`LISTO_API_KEY` (`INSIGHTS_*` still works as fallback) |
| Default redact keys expanded | If you relied on NOT redacting `userid`/`email`/`phone` etc., pass explicit `redact_keys` |
| Max event body size 64KB → 8KB | Reduce payload sizes |
| Endpoint validation added | Ensure events have `name` field and valid `category` |

## Error messages contain sensitive data

The SDK captures error messages verbatim. If your handlers raise errors containing PII or secrets, those strings will appear in events. Wrap sensitive operations:

```python
try:
    await risky_operation()
except Exception:
    raise RuntimeError("Operation failed")  # Generic message, no PII
```

## Next steps

- [Configuration](./configuration.md)
- [Sampling & privacy](./sampling-privacy.md)
