# Easy Setup

`create_mcp_observability_easy()` is the quickest way to get started. It applies environment-based defaults so you don't need to configure sinks, sampling, or redaction manually.

## Usage

```python
from mcp_observability import create_mcp_observability_easy

obs = create_mcp_observability_easy(
    service_name="my-mcp-server",
    service_version="1.0.0",
)
```

## What it does

Based on your environment, easy setup automatically:

| Behavior | Dev | Production |
|---|---|---|
| Console logging | Yes (errors only) | No |
| In-memory dashboard | Yes | No (opt-in) |
| Remote sink | If API key set | If API key set |
| Sample rate | `1.0` (100%) | `0.1` (10%) |
| Payload capture | Yes | Yes |
| Redact keys | `password`, `token`, `apiKey`, `secret`, `authorization`, `userId`, `userLocation`, `email`, `userEmail`, `phone`, `phoneNumber` | Same |

## Parameters

| Name | Type | Default | Description |
|---|---|---|---|
| `service_name` | `str` | *required* | Service identifier |
| `service_version` | `str` | `"1.0.0"` | Semantic version |
| `environment` | `str \| None` | Auto-detected | `"dev"`, `"staging"`, `"production"` |
| `listo_api_url` | `str \| None` | `LISTO_API_URL` env var | Remote API endpoint |
| `listo_api_key` | `str \| None` | `LISTO_API_KEY` env var | API key for remote sink |
| `insights_api_url` | `str \| None` | `INSIGHTS_API_URL` env var | Deprecated, use `listo_api_url` |
| `insights_api_key` | `str \| None` | `INSIGHTS_API_KEY` env var | Deprecated, use `listo_api_key` |
| `enable_local_dashboard` | `bool \| None` | `True` in dev | Enable in-memory sink + dashboard |
| `sample_rate` | `float \| None` | `1.0` dev, `0.1` prod | Event sampling rate |

## Environment variables

| Variable | Description |
|---|---|
| `LISTO_API_URL` | Remote telemetry endpoint (primary) |
| `LISTO_API_KEY` | Enable remote telemetry ingestion (primary) |
| `INSIGHTS_API_URL` | Deprecated, fallback for `LISTO_API_URL` |
| `INSIGHTS_API_KEY` | Deprecated, fallback for `LISTO_API_KEY` |
| `ENVIRONMENT` or `PYTHON_ENV` | `"production"` → production mode, else dev |

> **Note:** `LISTO_*` env vars take precedence over `INSIGHTS_*`. If no API key is configured in non-dev environments, a warning is logged suggesting you set `LISTO_API_KEY`.

## Pairing with the telemetry router

Easy setup stores instances in module-level globals so the Starlette routes can access them:

```python
from mcp_observability import create_mcp_observability_easy, create_telemetry_routes
from starlette.routing import Mount

obs = create_mcp_observability_easy(service_name="my-mcp")
routes = [Mount("/", routes=create_telemetry_routes())]
```

## Next steps

- [Configuration](./configuration.md) — for manual setup with full control
- [Endpoints](./endpoints.md) — dashboard and event ingestion
