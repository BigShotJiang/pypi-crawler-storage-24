# UI Events

Capture frontend interactions — clicks, impressions, form submissions — from browser clients or server-side rendering.

## Server-side

```python
from mcp_observability import create_mcp_observability_easy

obs = create_mcp_observability_easy(service_name="my-app")

obs.record_ui_event(
    "widget_click",
    action="click",
    category="engagement",
    widget_id="cta-primary",
    tool_name="search",
    session_id="sess-abc",
    device_id="device-xyz",
    tenant_id="tenant-1",
    locale="en-GB",
    properties={"itemId": "i-123", "label": "Get Started"},
)
```

All parameters after `name` are **keyword-only**.

## Browser (POST endpoint)

When the telemetry routes are mounted, browsers can POST events directly:

```javascript
fetch('/telemetry/event', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'cta_click',
    action: 'click',
    category: 'engagement',
    widgetId: 'signup-btn',
    sessionId: 'sess-abc',
    properties: { itemId: 'i-123' },
  }),
});
```

See [Endpoints](./endpoints.md) for setup.

## Method signature

```python
record_ui_event(
    name: str,
    *,
    action: str | None = None,
    category: EventCategory | None = None,
    widget_id: str | None = None,
    tool_name: str | None = None,
    session_id: str | None = None,
    device_id: str | None = None,
    tenant_id: str | None = None,
    locale: str | None = None,
    properties: dict[str, Any] | None = None,
) -> None
```

## UiEvent fields

| Name | Type | Required | Description |
|---|---|---|---|
| `name` | `str` | Yes | Event name (`widget_click`, `item_viewed`, etc.) |
| `action` | `str \| None` | No | Action type (`click`, `view`, `submit`) |
| `category` | `EventCategory \| None` | No | Event classification: `conversion`, `engagement`, `impression`, `navigation`, or `system` |
| `widget_id` | `str \| None` | No | Widget identifier |
| `tool_name` | `str \| None` | No | Associated MCP tool |
| `session_id` | `str \| None` | No | Session identifier |
| `device_id` | `str \| None` | No | Device identifier for cross-session tracking |
| `tenant_id` | `str \| None` | No | Tenant identifier |
| `locale` | `str \| None` | No | Client locale |
| `properties` | `dict \| None` | No | Arbitrary metadata (sanitized) |

## POST body validation

The `/telemetry/event` and `/telemetry/events` endpoints enforce:

- Body must be a JSON object (not array, not null)
- `name` field must be a non-empty string
- `category`, if provided, must be one of: `conversion`, `engagement`, `impression`, `navigation`, `system` — invalid values reject the event
- Only the fields listed above are accepted — unknown fields are stripped
- Maximum body size: 8 KB per event

## Next steps

- [Endpoints](./endpoints.md)
- [Sampling & privacy](./sampling-privacy.md)
