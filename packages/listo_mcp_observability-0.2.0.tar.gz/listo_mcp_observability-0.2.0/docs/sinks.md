# Sinks

Sinks are where events go after sanitization and sampling. The SDK ships three built-in sinks and a combiner.

## InMemorySink

Stores events in a circular buffer for local dashboards and metrics.

```python
from mcp_observability import InMemorySink

sink = InMemorySink(limit=2000)  # default: 2000
```

| Method | Returns | Description |
|---|---|---|
| `emit(event)` | `None` | Add event to buffer |
| `get_events()` | `list[ObservabilityEvent]` | Returns a **copy** of all buffered events |
| `get_metrics()` | `dict` | Computed latency summaries, tool stats, session counts, analytics |

> **Note:** `get_events()` returns a copy. Mutating the returned list does not affect the sink.

## RemoteSink

Batches events and sends them to a remote API endpoint.

```python
from mcp_observability import create_remote_sink, RemoteSinkOptions

sink = create_remote_sink(RemoteSinkOptions(
    endpoint="https://api.listoai.co/v1/events/batch",
    api_key="your-api-key",
    batch_size=50,
    flush_interval=5.0,
    max_retries=3,
))
```

### RemoteSinkOptions

| Name | Type | Default | Description |
|---|---|---|---|
| `endpoint` | `str` | *required* | POST endpoint URL |
| `api_key` | `str` | *required* | Sent as `X-API-Key` header |
| `batch_size` | `int` | `50` | Events per batch |
| `flush_interval` | `float` | `5.0` | Timer-based flush interval (seconds) |
| `max_retries` | `int` | `3` | Retry count for server errors |

### Cleanup

Call `destroy()` to stop the flush timer and send remaining events:

```python
sink.destroy()
```

## ConsoleSink

Logs events to stdout/stderr. Useful for development.

```python
from mcp_observability import ConsoleSink

sink = ConsoleSink(log_success=False)  # default: False
```

By default, only errors are logged. Set `log_success=True` to also log successful requests.

## combine_sinks

Fan out events to multiple sinks:

```python
from mcp_observability import combine_sinks, InMemorySink, ConsoleSink

combined = combine_sinks(
    InMemorySink(),
    ConsoleSink(log_success=True),
)
```

Each sink receives every event independently. If one sink raises, the others still receive the event. Errors from individual sinks are caught and logged to stderr.

## Custom sinks

Implement the `EventSink` protocol:

```python
from mcp_observability import EventSink, ObservabilityEvent

class MySink:
    def emit(self, event: ObservabilityEvent) -> None:
        # Send to your system
        ...
```

Any object with an `emit(event)` method satisfies the `EventSink` protocol.

## Next steps

- [Endpoints](./endpoints.md)
- [Advanced](./advanced.md)
