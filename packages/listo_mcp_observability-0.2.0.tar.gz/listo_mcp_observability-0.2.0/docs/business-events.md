# Business Events

Record domain-specific events like searches, conversions, and transactions.

## Usage

```python
from mcp_observability import create_mcp_observability_easy

obs = create_mcp_observability_easy(service_name="my-mcp")

# Simple event (name only)
obs.record_business_event("product_search")

# With properties and status
obs.record_business_event("checkout", properties={"amount": 299}, status="ok")

# With session tracking, category, and tenant
obs.record_business_event(
    "purchase",
    properties={"item": "widget", "amount": 99},
    status="ok",
    category="conversion",
    session_id="sess-abc",
    device_id="device-xyz",
    tenant_id="tenant-1",
)

# Error event (always bypasses sampling)
obs.record_business_event("payment", properties={"provider": "stripe"}, status="error")
```

## Method signature

```python
record_business_event(
    name: str,
    *,
    properties: dict[str, Any] | None = None,
    status: EventStatus | None = None,
    category: EventCategory | None = None,
    session_id: str | None = None,
    device_id: str | None = None,
    tenant_id: str | None = None,
) -> None
```

All parameters after `name` are **keyword-only**.

| Parameter | Type | Description |
|---|---|---|
| `name` | `str` | Event name (e.g., `"product_search"`, `"checkout"`) |
| `properties` | `dict \| None` | Arbitrary key-value metadata (sanitized) |
| `status` | `"ok" \| "error" \| None` | Optional status. Error events bypass sampling |
| `category` | `EventCategory \| None` | Event classification for funnel analytics |
| `session_id` | `str \| None` | Session identifier for user journey tracking |
| `device_id` | `str \| None` | Device identifier for cross-session user identification |
| `tenant_id` | `str \| None` | Tenant identifier for multi-tenant applications |

### EventCategory

Events can be classified using one of these standard categories:

| Category | Use for |
|---|---|
| `"conversion"` | Purchase, signup, booking |
| `"engagement"` | Click, search, share |
| `"impression"` | View, render, display |
| `"navigation"` | Page transition, tab switch |
| `"system"` | Errors, lifecycle events |

```python
from mcp_observability import EventCategory
# EventCategory = Literal["conversion", "engagement", "impression", "navigation", "system"]
```

## Property sanitization

The `properties` dict is sanitized through the configured redact keys before emission. Sensitive keys like `password`, `token`, `email`, etc. are replaced with `[redacted]`.

## Emitted event fields

| Field | Type | Description |
|---|---|---|
| `type` | `"business_event"` | Event discriminator |
| `timestamp` | `float` | Auto-set |
| `service` | `str` | From config |
| `name` | `str` | Your event name |
| `properties` | `dict \| None` | Your metadata (sanitized) |
| `status` | `"ok" \| "error" \| None` | If provided |
| `category` | `EventCategory \| None` | If provided |
| `session_id` | `str \| None` | If provided |
| `device_id` | `str \| None` | If provided |
| `tenant_id` | `str \| None` | If provided |

> **Note:** Business events with `status="error"` always bypass sampling. Events without a status are subject to the configured `sample_rate`.

## Migration from v0.0.x

The `record_business_event` signature changed from positional arguments to keyword-only in v0.1.0:

```python
# Before (v0.0.x)
obs.record_business_event("checkout", {"amount": 99}, "ok")

# After (v0.1.0)
obs.record_business_event("checkout", properties={"amount": 99}, status="ok")
```

## Next steps

- [UI events](./ui-events.md)
- [Endpoints](./endpoints.md)
