# Advanced

Custom sinks, the metrics API, and architectural notes for power users.

## EventSink protocol

```python
from mcp_observability import ObservabilityEvent

class EventSink:
    def emit(self, event: ObservabilityEvent) -> None: ...
```

The SDK uses Python's `Protocol` for structural typing — any object with an `emit(event)` method works as a sink.

### Example: webhook sink

```python
import json
import urllib.request

from mcp_observability import EventSink, ObservabilityEvent

class WebhookSink:
    def __init__(self, url: str) -> None:
        self._url = url

    def emit(self, event: ObservabilityEvent) -> None:
        from dataclasses import asdict
        data = json.dumps(asdict(event)).encode()
        req = urllib.request.Request(
            self._url,
            data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req)
```

### Example: filtering sink

```python
from mcp_observability import ObservabilityEvent

class FilterSink:
    def __init__(self, inner, predicate):
        self._inner = inner
        self._predicate = predicate

    def emit(self, event: ObservabilityEvent) -> None:
        if self._predicate(event):
            self._inner.emit(event)

# Only forward errors
error_only = FilterSink(remote_sink, lambda e: getattr(e, "status", None) == "error")
```

## Metrics API

`InMemorySink.get_metrics()` returns a comprehensive metrics dict:

```python
metrics = sink.get_metrics()
```

### Structure

```python
{
    "totals": {"events": int, "http": int, "mcp": int, "sessions": int, "ui": int, "business": int},
    "http": {
        "overall": {"count": int, "errors": int, "avgMs": float, "p50": float, "p95": float, "p99": float},
        "byRoute": {route: {"count": int, "errors": int, "avgMs": float, ...}},
    },
    "mcp": {
        "byKind": {kind: {"count": int, "errors": int, "avgMs": float, ...}},
        "tools": {tool_name: {"count": int, "errors": int, "avgMs": float, ...}},
    },
    "sessions": {"open": int, "close": int},
    "ui": {"byName": dict, "byAction": dict, "byWidget": dict, "byCategory": dict, "total": int},
    "business": {
        "byName": {name: {"count": int, "ok": int, "error": int}},
        "byCategory": {category: {"count": int, "ok": int, "error": int}},
    },
}
```

The `byCategory` dimensions enable funnel analytics by grouping events into standard categories (`conversion`, `engagement`, `impression`, `navigation`, `system`). Events without a category are excluded from `byCategory`.

Latency summaries include p50, p95, p99 percentiles computed from raw event data.

## ObservabilityEvent union

All event types form a union:

```python
ObservabilityEvent = HttpRequestEvent | McpRequestEvent | McpSessionEvent | BusinessEvent | UiEvent
```

Use the `type` field or `isinstance()` for narrowing:

```python
if isinstance(event, McpRequestEvent):
    print(event.tool_name)
```

## Next steps

- [Sinks](./sinks.md)
- [Troubleshooting](./troubleshooting.md)
