# Installation

Install the SDK from PyPI.

```bash
pip install listo-mcp-observability
```

Or with uv:

```bash
uv add listo-mcp-observability
```

## Prerequisites

- **Python 3.10+** — the SDK uses modern type annotations (`X | Y`, `dict[str, Any]`).

## Optional dependencies

```bash
# MCP SDK support
pip install "listo-mcp-observability[mcp]"

# Starlette dashboard endpoints
pip install "listo-mcp-observability[starlette]"
```

## Zero runtime dependencies

The core SDK has **zero production dependencies**. It uses only the Python standard library. Starlette is required only for the dashboard endpoints and must be installed separately.

## Type annotations

Full type annotations are included. The SDK passes `mypy --strict`.

```python
from mcp_observability import ObservabilityEvent, EventSink, EventCategory
```

## Next steps

- [Configuration](./configuration.md)
- [Easy setup](./easy-setup.md)
