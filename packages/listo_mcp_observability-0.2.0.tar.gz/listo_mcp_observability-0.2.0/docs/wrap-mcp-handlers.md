# Wrap MCP Handlers

Instrument MCP tool calls, resource reads, and prompt fetches with automatic timing and payload capture.

## Decorator usage

The simplest approach for FastMCP:

```python
from mcp.server.fastmcp import FastMCP
from mcp_observability import create_mcp_observability_easy

mcp = FastMCP("my-server")
obs = create_mcp_observability_easy(service_name="my-server")

@mcp.tool()
@obs.track_tool("search_hotels")
async def search_hotels(query: str) -> str:
    return f"Results for {query}"
```

## Programmatic wrapping

For more control, use `wrap_mcp_handler()`:

```python
from mcp_observability import McpTrackingContext

wrapped = obs.wrap_mcp_handler(
    "CallTool",
    original_handler,
    context=lambda request: McpTrackingContext(
        tool_name="search",
        args=request,
        session_id="sess-abc",
    ),
)

result = await wrapped({"query": "boutique hotels"})
```

The wrapper automatically records latency, status, args hash, input/output sizes, and optional payload previews.

## McpTrackingContext

The context function receives the request and returns metadata:

| Name | Type | Default | Description |
|---|---|---|---|
| `session_id` | `str \| None` | `None` | MCP session identifier |
| `platform` | `str \| None` | `None` | AI platform (from `detect_platform()`) |
| `tenant_id` | `str \| None` | `None` | Tenant identifier |
| `locale` | `str \| None` | `None` | Client locale (e.g., `en-GB`) |
| `user_agent` | `str \| None` | `None` | Client user agent string |
| `request_id` | `str \| None` | auto UUID | Override the auto-generated request ID |
| `tool_name` | `str \| None` | `None` | Tool name (for CallTool requests) |
| `resource_uri` | `str \| None` | `None` | Resource URI (for ReadResource requests) |
| `args` | `Any` | `None` | Tool arguments (sanitized before emission) |
| `conversation_id` | `str \| None` | `None` | Conversation thread ID |
| `user_query` | `str \| None` | `None` | User's search text (truncated to 240 chars, hashed) |
| `result_preview` | `Callable \| None` | `None` | Transform result for preview capture |

### Result preview

The `result_preview` field accepts a callable that transforms the handler result into a preview:

```python
obs.wrap_mcp_handler(
    "CallTool",
    handler,
    context=lambda req: McpTrackingContext(
        tool_name="search",
        result_preview=lambda result: {"count": len(result.get("items", []))},
    ),
)
```

The preview is sanitized and included as `result_preview` in the emitted event. A SHA-256 hash is also emitted as `result_hash`.

> **Note:** `user_query` is truncated to 240 characters in the emitted event. A SHA-256 hash of the sanitized query is also emitted as `user_query_hash` for deduplication without storing full text.

## Emitted event fields

| Field | Type | Description |
|---|---|---|
| `type` | `"mcp_request"` | Event discriminator |
| `request_kind` | `str` | `"CallTool"`, `"ReadResource"`, `"GetPrompt"`, etc. |
| `tool_name` | `str \| None` | From context |
| `status` | `"ok" \| "error"` | Based on whether handler raised |
| `latency_ms` | `float` | High-resolution timing |
| `args_hash` | `str \| None` | SHA-256 of sanitized args |
| `input_bytes` | `int \| None` | Estimated JSON size of args |
| `output_bytes` | `int \| None` | Estimated JSON size of result |
| `args_preview` | `Any` | Sanitized + truncated args |
| `result_preview` | `Any` | Output of `result_preview()` callback |
| `result_hash` | `str \| None` | SHA-256 of sanitized result preview |
| `sample_payload` | `Any` | Full sanitized args (only if `capture_payloads=True`) |
| `platform` | `str \| None` | AI platform from context |
| `error` | `str \| None` | Error message if handler raised |

## Error handling

If the wrapped handler raises, the error is recorded in the event and **re-raised** so your existing error handling continues to work.

## Next steps

- [Sessions](./sessions.md)
- [Business events](./business-events.md)
- [Sampling & privacy](./sampling-privacy.md)
