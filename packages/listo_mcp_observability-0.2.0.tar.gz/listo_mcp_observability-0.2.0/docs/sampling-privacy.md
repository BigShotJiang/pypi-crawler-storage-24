# Sampling & Privacy

The SDK is designed to minimize data collection while providing actionable telemetry.

## Sampling

Control what percentage of events are recorded with `sample_rate`:

```python
from mcp_observability import create_mcp_observability, ObservabilityOptions

obs = create_mcp_observability(ObservabilityOptions(
    service_name="my-service",
    sample_rate=0.1,  # 10% of events
    sinks=[sink],
))
```

### Sampling rules

| Event type | Behavior |
|---|---|
| Error events (`status="error"`) | **Always captured**, regardless of sample rate |
| Session events (`mcp_session`) | **Always captured**, regardless of sample rate |
| All other events | Subject to `sample_rate` (random per-event) |

This ensures you never miss errors or lose session counts even at low sample rates.

## Key redaction

Sensitive keys are automatically replaced with `[redacted]` in sanitized payloads:

```python
obs = create_mcp_observability(ObservabilityOptions(
    service_name="my-service",
    redact_keys=[
        "password", "token", "apiKey", "secret", "authorization",
        "userId", "userLocation", "email", "userEmail", "phone", "phoneNumber",
    ],
    sinks=[sink],
))
```

Redaction is:
- **Case-insensitive** — `apiKey`, `APIKEY`, and `ApiKey` all match
- **Recursive** — nested objects are traversed up to depth 6
- **Applied consistently** to all event properties: MCP handler args (`args_preview`, `sample_payload`), business event `properties`, and UI event `properties`

Arrays are sliced to 20 items during sanitization to prevent large payloads.

## Data minimization

The SDK follows data minimization principles:

| Practice | Detail |
|---|---|
| No PII fields | No `user_id`, `user_location`, or similar fields exist in event types. PII keys are redacted from all `properties` dicts by default |
| Hashing over storage | Args and results are SHA-256 hashed (`args_hash`, `result_hash`, `user_query_hash`) for deduplication without storing raw content |
| Truncation | `user_query_preview` is truncated to 240 characters |
| Depth limits | Object traversal stops at depth 6 with `[truncated]` |
| Array limits | Arrays are sliced to 20 items during sanitization |
| Payload opt-in | Full args are only included in `sample_payload` when `capture_payloads=True` |

## user_query handling

The `user_query` field in `McpTrackingContext` contains user search text. It is:

1. Truncated to 240 characters → `user_query_preview`
2. Sanitized through `redact_keys` then SHA-256 hashed → `user_query_hash`

> **Note:** `user_query_preview` may contain user-typed content. If your use case requires full redaction of user input, do not pass `user_query` in your tracking context.

## Error messages

The `to_error_message()` function captures error messages verbatim from raised exceptions. If your application raises errors containing sensitive data, those messages will appear in events.

> **Note:** Ensure your error messages do not contain PII or secrets. Consider wrapping sensitive operations to sanitize error messages before they propagate.

## Next steps

- [Configuration](./configuration.md)
- [Advanced](./advanced.md)
