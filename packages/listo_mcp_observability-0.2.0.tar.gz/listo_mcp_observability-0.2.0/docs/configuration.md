# Configuration

The SDK offers two initialization paths: **easy setup** (convention-based) and **manual setup** (full control).

## Easy setup

```python
from mcp_observability import create_mcp_observability_easy

obs = create_mcp_observability_easy(
    service_name="my-mcp-server",
    service_version="1.0.0",
)
```

See [Easy setup deep-dive](./easy-setup.md) for the full config table.

## Manual setup

```python
from mcp_observability import (
    create_mcp_observability,
    ObservabilityOptions,
    InMemorySink,
    ConsoleSink,
)

obs = create_mcp_observability(ObservabilityOptions(
    service_name="my-mcp-server",
    service_version="1.0.0",
    environment="production",
    sinks=[InMemorySink(), ConsoleSink(log_success=True)],
    sample_rate=0.1,
    capture_payloads=True,
    redact_keys=["password", "token", "apiKey", "secret", "authorization"],
))
```

### ObservabilityOptions

| Name | Type | Default | Description |
|---|---|---|---|
| `service_name` | `str` | *required* | Identifies your service in events |
| `service_version` | `str \| None` | `None` | Semantic version string |
| `environment` | `str \| None` | `None` | `"dev"`, `"staging"`, `"production"`, etc. |
| `sinks` | `list[EventSink] \| None` | `[ConsoleSink()]` | Where events are sent |
| `sample_rate` | `float` | `1.0` | `0`–`1`. Errors and sessions always pass |
| `redact_keys` | `list[str] \| None` | See below | Keys to replace with `[redacted]` in all event properties |
| `capture_payloads` | `bool` | `False` | Include full sanitized args in `sample_payload` |
| `platform` | `str \| None` | `None` | Default platform label (for TypeScript SDK parity) |

### Default redact keys

When `redact_keys` is `None`, the SDK uses these defaults:

`authorization`, `apikey`, `password`, `token`, `secret`, `userid`, `userlocation`, `email`, `useremail`, `phone`, `phonenumber`

> **Note:** `sample_rate` is clamped to `[0, 1]`. Values outside that range are silently clamped. Error events and session events always bypass sampling.

## Next steps

- [Wrap MCP handlers](./wrap-mcp-handlers.md)
- [Sinks](./sinks.md)
