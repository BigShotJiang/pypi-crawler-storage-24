# Platform Detection

Identify which AI platform (Claude, ChatGPT, etc.) initiated each MCP session and tool call.

## Why

When the same MCP server is deployed across multiple AI platforms, you need to know which platform each request came from to filter analytics, debug platform-specific issues, and understand usage patterns.

## Usage

```python
from mcp_observability import detect_platform, PlatformHints, McpClientInfo

# From HTTP headers
platform = detect_platform(PlatformHints(
    headers={"User-Agent": "Claude-Desktop/2.0"},
))
# → "claude"

# From _meta key prefixes
platform = detect_platform(PlatformHints(
    meta={"openai/model": "gpt-4"},
))
# → "chatgpt"

# From clientInfo
platform = detect_platform(PlatformHints(
    client_info=McpClientInfo(name="claude-desktop", version="1.2.3"),
))
# → "claude"
```

## Detection tiers

Detection is three-tier, first match wins:

| Priority | Signal | Logic |
|----------|--------|-------|
| 1 (highest) | HTTP headers | user-agent contains `"openai"` or `x-openai-*` headers → `"chatgpt"`; user-agent contains `"claude"`/`"anthropic"` or `x-anthropic-*` headers → `"claude"` |
| 2 | `_meta` key prefixes | `"openai/"` → `"chatgpt"`, `"anthropic/"` or `"claude/"` → `"claude"` |
| 3 (lowest) | `clientInfo.name` | Exact match (`"claude-desktop"`, `"claude"` → `"claude"`, `"chatgpt"` → `"chatgpt"`) or prefix match (`"claude-*"` → `"claude"`). Ignores names like `"unavailable"`, `"unknown"`, `"n/a"`, `"none"`, `""` |
| Fallback | — | Returns `"other"` |

All string comparisons are case-insensitive.

## Wiring into events

Pass the detected platform through `McpTrackingContext` or `record_session()`:

```python
from mcp_observability import (
    create_mcp_observability_easy,
    detect_platform,
    PlatformHints,
    McpTrackingContext,
)

obs = create_mcp_observability_easy(service_name="my-mcp")

# Sessions
platform = detect_platform(PlatformHints(headers=request_headers))
obs.record_session("open", session_id, platform=platform)

# Tool calls via context callback
@mcp.tool()
@obs.track_tool(
    "search",
    context=lambda **kwargs: McpTrackingContext(
        platform=platform,
        args=kwargs,
    ),
)
async def search(query: str) -> str:
    ...
```

The `platform` field appears on emitted `McpRequestEvent` and `McpSessionEvent` objects and flows through to your sinks automatically.

## Types

```python
from mcp_observability import Platform, KnownPlatform, PlatformHints, McpClientInfo

# Platform = KnownPlatform = Literal["claude", "chatgpt", "other"]
```

### `PlatformHints`

| Field | Type | Default | Description |
|---|---|---|---|
| `headers` | `dict[str, str] \| None` | `None` | HTTP request headers |
| `meta` | `dict[str, str] \| None` | `None` | MCP `_meta` keys |
| `client_info` | `McpClientInfo \| None` | `None` | MCP `clientInfo` |

### `McpClientInfo`

| Field | Type | Default | Description |
|---|---|---|---|
| `name` | `str` | *required* | Client name from MCP handshake |
| `version` | `str \| None` | `None` | Client version |

## Next steps

- [Sessions](./sessions.md)
- [Wrap MCP handlers](./wrap-mcp-handlers.md)
- [Configuration](./configuration.md)
