# mcp-observability (Python)

Lightweight, zero-dependency telemetry SDK for Python MCP servers.

## What it does

mcp-observability captures MCP tool invocations, HTTP requests, sessions, business events, and UI interactions. Events are sanitized, sampled, and routed to one or more **sinks** (in-memory, remote API, console).

## Architecture

```
┌──────────────────────────────────────────────────────┐
│  Your Application                                     │
│                                                       │
│  MCP handler wraps ──┐                                │
│  track_tool() ───────┤──▶ McpObservability            │
│  Business events ────┤      │                         │
│  UI events ──────────┘      │ sanitize → sample       │
│                             ▼                         │
│                        EventSink[]                    │
│                        ┌──────────┬──────────┐        │
│                        │ InMemory │ Remote   │ Console│
│                        │ Sink     │ Sink     │ Sink   │
│                        └────┬─────┴────┬─────┘        │
│                             │          │              │
└─────────────────────────────┼──────────┼──────────────┘
                              │          │
                     Local dashboard   Listo API
```

## Quick start

```python
from mcp_observability import create_mcp_observability_easy

obs = create_mcp_observability_easy(service_name="my-mcp-server", service_version="1.0.0")
```

That single call sets up console logging in dev, an in-memory dashboard, and remote ingestion when `LISTO_API_KEY` is set.

For full control, use `create_mcp_observability()` directly — see [Configuration](./configuration.md).

## Event types

| Type | Description |
|---|---|
| `http_request` | HTTP request lifecycle |
| `mcp_request` | MCP tool call, resource read, prompt get |
| `mcp_session` | Session open/close |
| `business_event` | Domain-specific events (search, checkout) with optional category, sessionId, tenantId |
| `ui_event` | Frontend interactions (clicks, impressions) with optional category |

Both `business_event` and `ui_event` support an `EventCategory` field (`conversion`, `engagement`, `impression`, `navigation`, `system`) for funnel analytics.

## Next steps

- [Installation](./installation.md)
- [Configuration](./configuration.md)
- [Easy setup](./easy-setup.md)
- [Platform Detection](./platform-detection.md)
- [Wrap MCP handlers](./wrap-mcp-handlers.md)
