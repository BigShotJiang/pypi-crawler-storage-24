# Endpoints

The SDK provides Starlette routes with a JSON API, HTML dashboard, and event ingestion endpoints.

## Setup

```python
from mcp_observability import create_mcp_observability_easy, create_telemetry_routes
from starlette.applications import Starlette
from starlette.routing import Mount

obs = create_mcp_observability_easy(
    service_name="my-mcp",
    enable_local_dashboard=True,
)

app = Starlette(routes=[Mount("/", routes=create_telemetry_routes())])
```

> **Note:** Starlette must be installed (`pip install "listo-mcp-observability[starlette]"`). It is an optional dependency, not a core dependency.

## Routes

### GET `/telemetry`

Returns JSON with all buffered events and computed metrics.

```json
{
  "events": [...],
  "metrics": {
    "totals": { "events": 42, "http": 10, "mcp": 20, "sessions": 5, "ui": 5, "business": 2 },
    "http": { "overall": { "count": 10, "errors": 1, "avgMs": 45.2, "p50": 30, "p95": 120, "p99": 200 }, "byRoute": {...} },
    "mcp": { "byKind": {...}, "tools": {...} },
    "sessions": { "open": 5, "close": 3 },
    "ui": { "byName": {...}, "byAction": {...}, "byWidget": {...}, "byCategory": {...}, "total": 5 },
    "business": { "byName": {...}, "byCategory": {...} }
  }
}
```

### GET `/telemetry/dashboard`

HTML dashboard with auto-refresh (5 seconds). Shows:

- Total event counts
- HTTP performance by route (count, errors, avg/p95/p99 latency)
- MCP tool usage (count, errors, latency)

### POST `/telemetry/event`

Ingests a single UI event from browser clients.

**Request:**

```
POST /telemetry/event
Content-Type: application/json

{ "name": "widget_click", "action": "click", "widgetId": "cta-1" }
```

**Response:** `201 { "ok": true }` or `400 { "error": "..." }`

**Validation:**
- Max body size: 8 KB
- `name` must be a non-empty string
- `category`, if provided, must be one of: `conversion`, `engagement`, `impression`, `navigation`, `system`
- Only allowlisted fields are accepted (see [UI events](./ui-events.md))

### POST `/telemetry/events`

Ingests a batch of UI events.

**Request:**

```
POST /telemetry/events
Content-Type: application/json

{ "events": [{ "name": "widget_click", "action": "click" }, { "name": "page_view" }] }
```

**Response:** `201 { "ok": true, "accepted": 2, "rejected": 0 }` or `400 { "error": "..." }`

**Validation:**
- Maximum 100 events per batch
- Each event is validated individually (same rules as `/telemetry/event`)
- Invalid events are skipped (not rejected outright) — the response reports accepted/rejected counts

## Global state

The easy setup stores the `InMemorySink` and `McpObservability` instance in module-level globals. This allows the telemetry routes to access them without explicit wiring.

## Next steps

- [Easy setup](./easy-setup.md)
- [UI events](./ui-events.md)
