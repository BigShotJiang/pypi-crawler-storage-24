import pytest

from mcp_observability.core import McpObservability, ObservabilityOptions
from mcp_observability.sinks import InMemorySink
from mcp_observability.types import McpRequestEvent, McpTrackingContext


@pytest.fixture
def sink():
    return InMemorySink()


@pytest.fixture
def obs(sink):
    return McpObservability(
        ObservabilityOptions(
            service_name="test-service",
            service_version="1.0.0",
            environment="test",
            sinks=[sink],
            sample_rate=1.0,
            capture_payloads=True,
        )
    )


def test_record_business_event(obs, sink):
    obs.record_business_event("purchase", properties={"amount": 99}, status="ok")
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].name == "purchase"
    assert events[0].properties["amount"] == 99
    assert events[0].service == "test-service"


def test_record_business_event_with_category(obs, sink):
    obs.record_business_event(
        "signup",
        category="conversion",
        session_id="s1",
        device_id="d1",
        tenant_id="t1",
    )
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].category == "conversion"
    assert events[0].session_id == "s1"
    assert events[0].device_id == "d1"
    assert events[0].tenant_id == "t1"


def test_record_business_event_sanitizes_properties(obs, sink):
    obs.record_business_event("test", properties={"password": "secret", "name": "alice"})
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].properties["password"] == "[redacted]"
    assert events[0].properties["name"] == "alice"


def test_record_business_event_keyword_only(obs, sink):
    """Verify that args after name are keyword-only."""
    # This should work
    obs.record_business_event("test", properties={"a": 1}, status="ok")
    # This should raise TypeError (positional arg after name)
    with pytest.raises(TypeError):
        obs.record_business_event("test", {"a": 1}, "ok")  # type: ignore[misc]


def test_record_ui_event(obs, sink):
    obs.record_ui_event("click", action="press", widget_id="w1")
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].name == "click"
    assert events[0].widget_id == "w1"


def test_record_ui_event_with_category_and_device_id(obs, sink):
    obs.record_ui_event(
        "view",
        category="impression",
        device_id="dev-1",
        locale="en-US",
    )
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].category == "impression"
    assert events[0].device_id == "dev-1"
    assert events[0].locale == "en-US"


def test_record_ui_event_sanitizes_properties(obs, sink):
    obs.record_ui_event("test", properties={"token": "secret", "label": "ok"})
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].properties["token"] == "[redacted]"
    assert events[0].properties["label"] == "ok"


def test_record_ui_event_keyword_only(obs, sink):
    """Verify that args after name are keyword-only."""
    obs.record_ui_event("test", action="click")
    with pytest.raises(TypeError):
        obs.record_ui_event("test", "click")  # type: ignore[misc]


def test_record_session(obs, sink):
    obs.record_session("open", "sess-123")
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].action == "open"
    assert events[0].session_id == "sess-123"


def test_record_session_with_platform(obs, sink):
    obs.record_session("open", "s1", platform="claude")
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].platform == "claude"
    assert events[0].session_id == "s1"


def test_record_session_without_platform(obs, sink):
    obs.record_session("open", "s2")
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].platform is None


@pytest.mark.asyncio
async def test_wrap_mcp_handler_success(obs, sink):
    async def my_handler(query):
        return f"result for {query}"

    wrapped = obs.wrap_mcp_handler(
        "CallTool",
        my_handler,
        context=lambda q: McpTrackingContext(tool_name="search", args={"query": q}),
    )

    result = await wrapped("test query")
    assert result == "result for test query"

    events = sink.get_events()
    assert len(events) == 1
    event = events[0]
    assert isinstance(event, McpRequestEvent)
    assert event.request_kind == "CallTool"
    assert event.tool_name == "search"
    assert event.status == "ok"
    assert event.latency_ms > 0


@pytest.mark.asyncio
async def test_wrap_mcp_handler_with_platform(obs, sink):
    async def handler():
        return "ok"

    wrapped = obs.wrap_mcp_handler(
        "CallTool",
        handler,
        context=lambda: McpTrackingContext(platform="claude"),
    )
    await wrapped()

    events = sink.get_events()
    assert len(events) == 1
    assert events[0].platform == "claude"


@pytest.mark.asyncio
async def test_wrap_mcp_handler_error_with_platform(obs, sink):
    async def handler():
        raise ValueError("fail")

    wrapped = obs.wrap_mcp_handler(
        "CallTool",
        handler,
        context=lambda: McpTrackingContext(platform="chatgpt"),
    )
    with pytest.raises(ValueError):
        await wrapped()

    events = sink.get_events()
    assert len(events) == 1
    assert events[0].platform == "chatgpt"
    assert events[0].status == "error"


@pytest.mark.asyncio
async def test_wrap_mcp_handler_error(obs, sink):
    async def failing_handler():
        raise ValueError("something broke")

    wrapped = obs.wrap_mcp_handler("CallTool", failing_handler)

    with pytest.raises(ValueError, match="something broke"):
        await wrapped()

    events = sink.get_events()
    assert len(events) == 1
    assert events[0].status == "error"
    assert events[0].error == "something broke"


@pytest.mark.asyncio
async def test_wrap_mcp_handler_result_preview(obs, sink):
    async def my_handler():
        return {"data": "long result", "secret": "hidden"}

    wrapped = obs.wrap_mcp_handler(
        "CallTool",
        my_handler,
        context=lambda: McpTrackingContext(
            tool_name="preview_test",
            result_preview=lambda r: {"summary": r.get("data")},
        ),
    )

    result = await wrapped()
    assert result["data"] == "long result"

    events = sink.get_events()
    assert len(events) == 1
    assert events[0].result_preview == {"summary": "long result"}
    assert events[0].result_hash is not None


@pytest.mark.asyncio
async def test_track_tool_decorator(obs, sink):
    @obs.track_tool("greet")
    async def greet(name: str) -> str:
        return f"Hello {name}"

    result = await greet(name="Alice")
    assert result == "Hello Alice"

    events = sink.get_events()
    assert len(events) == 1
    event = events[0]
    assert event.request_kind == "CallTool"
    assert event.tool_name == "greet"
    assert event.status == "ok"


@pytest.mark.asyncio
async def test_track_tool_with_platform(obs, sink):
    @obs.track_tool(
        "my_tool",
        context=lambda: McpTrackingContext(platform="claude"),
    )
    async def my_tool() -> str:
        return "result"

    await my_tool()
    events = sink.get_events()
    assert len(events) == 1
    assert events[0].platform == "claude"


@pytest.mark.asyncio
async def test_track_tool_error_with_platform(obs, sink):
    @obs.track_tool(
        "fail_tool",
        context=lambda: McpTrackingContext(platform="chatgpt"),
    )
    async def fail_tool() -> str:
        raise RuntimeError("oops")

    with pytest.raises(RuntimeError):
        await fail_tool()

    events = sink.get_events()
    assert len(events) == 1
    assert events[0].platform == "chatgpt"
    assert events[0].status == "error"


@pytest.mark.asyncio
async def test_track_tool_decorator_error(obs, sink):
    @obs.track_tool("fail_tool")
    async def fail_tool() -> str:
        raise RuntimeError("oops")

    with pytest.raises(RuntimeError, match="oops"):
        await fail_tool()

    events = sink.get_events()
    assert len(events) == 1
    assert events[0].status == "error"
    assert events[0].tool_name == "fail_tool"
    assert events[0].error == "oops"


def test_sampling_rate_zero():
    sink = InMemorySink()
    obs = McpObservability(
        ObservabilityOptions(
            service_name="test",
            sinks=[sink],
            sample_rate=0.0,
        )
    )
    # OK events should be dropped with rate 0
    obs.record_business_event("test", status="ok")
    # But errors should always be captured
    obs.record_business_event("error_test", status="error")

    events = sink.get_events()
    # error events always sampled
    assert any(e.name == "error_test" for e in events)


def test_session_always_sampled():
    sink = InMemorySink()
    obs = McpObservability(
        ObservabilityOptions(
            service_name="test",
            sinks=[sink],
            sample_rate=0.0,
        )
    )
    obs.record_session("open", "s1")
    events = sink.get_events()
    assert len(events) == 1


def test_expanded_default_redact_keys():
    sink = InMemorySink()
    obs = McpObservability(
        ObservabilityOptions(
            service_name="test",
            sinks=[sink],
            capture_payloads=True,
        )
    )
    obs.record_business_event(
        "test",
        properties={
            "userId": "u1",
            "email": "test@example.com",
            "phone": "555-1234",
            "name": "alice",
        },
    )
    events = sink.get_events()
    props = events[0].properties
    assert props["userId"] == "[redacted]"
    assert props["email"] == "[redacted]"
    assert props["phone"] == "[redacted]"
    assert props["name"] == "alice"


@pytest.mark.asyncio
async def test_wrap_mcp_handler_no_pii_in_emitted_event(obs, sink):
    """Emitted McpRequestEvent should not have user_id or user_location fields."""

    async def handler():
        return "ok"

    wrapped = obs.wrap_mcp_handler("CallTool", handler)
    await wrapped()

    events = sink.get_events()
    assert len(events) == 1
    event = events[0]
    assert not hasattr(event, "user_id")
    assert not hasattr(event, "user_location")


@pytest.mark.asyncio
async def test_track_tool_no_pii_in_emitted_event(obs, sink):
    """Emitted McpRequestEvent from track_tool should not have user_id or user_location."""

    @obs.track_tool("my_tool")
    async def my_tool() -> str:
        return "result"

    await my_tool()

    events = sink.get_events()
    assert len(events) == 1
    event = events[0]
    assert not hasattr(event, "user_id")
    assert not hasattr(event, "user_location")


@pytest.mark.asyncio
async def test_track_tool_result_preview(obs, sink):
    """track_tool decorator should support result_preview via context."""

    @obs.track_tool(
        "preview_tool",
        context=lambda: McpTrackingContext(
            result_preview=lambda r: {"length": len(r)},
        ),
    )
    async def my_tool() -> str:
        return "hello world"

    result = await my_tool()
    assert result == "hello world"

    events = sink.get_events()
    assert len(events) == 1
    assert events[0].result_preview == {"length": 11}
    assert events[0].result_hash is not None
