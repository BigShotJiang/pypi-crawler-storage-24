import os
from unittest.mock import patch

from mcp_observability.core import McpObservability
from mcp_observability.easy_setup import create_mcp_observability_easy, get_telemetry_sink


def test_easy_setup_dev_defaults():
    with patch.dict(os.environ, {}, clear=True):
        obs = create_mcp_observability_easy(service_name="test-svc")
        assert isinstance(obs, McpObservability)
        # In dev mode, local dashboard should be enabled
        sink = get_telemetry_sink()
        assert sink is not None


def test_easy_setup_production():
    with patch.dict(os.environ, {"ENVIRONMENT": "production"}, clear=True):
        obs = create_mcp_observability_easy(service_name="test-svc")
        assert isinstance(obs, McpObservability)


def test_easy_setup_custom_sample_rate():
    obs = create_mcp_observability_easy(
        service_name="test-svc",
        sample_rate=0.5,
    )
    assert isinstance(obs, McpObservability)


def test_easy_setup_with_listo_api_key():
    with patch.dict(
        os.environ,
        {
            "LISTO_API_URL": "https://api.listo.com",
            "LISTO_API_KEY": "listo-key-123",
        },
        clear=True,
    ):
        obs = create_mcp_observability_easy(service_name="test-svc")
        assert isinstance(obs, McpObservability)


def test_easy_setup_with_insights_fallback():
    """INSIGHTS_* env vars should work as fallback when LISTO_* not set."""
    with patch.dict(
        os.environ,
        {
            "INSIGHTS_API_URL": "https://api.test.com",
            "INSIGHTS_API_KEY": "test-key-123",
        },
        clear=True,
    ):
        obs = create_mcp_observability_easy(service_name="test-svc")
        assert isinstance(obs, McpObservability)


def test_easy_setup_listo_takes_precedence_over_insights():
    """LISTO_* env vars should take precedence over INSIGHTS_*."""
    with patch.dict(
        os.environ,
        {
            "LISTO_API_URL": "https://listo.com",
            "LISTO_API_KEY": "listo-key",
            "INSIGHTS_API_URL": "https://insights.com",
            "INSIGHTS_API_KEY": "insights-key",
        },
        clear=True,
    ):
        obs = create_mcp_observability_easy(service_name="test-svc")
        assert isinstance(obs, McpObservability)


def test_easy_setup_param_takes_precedence_over_env():
    """Direct params should take precedence over env vars."""
    with patch.dict(
        os.environ,
        {
            "LISTO_API_URL": "https://env.com",
            "LISTO_API_KEY": "env-key",
        },
        clear=True,
    ):
        obs = create_mcp_observability_easy(
            service_name="test-svc",
            listo_api_url="https://param.com",
            listo_api_key="param-key",
        )
        assert isinstance(obs, McpObservability)


def test_easy_setup_deprecated_param_as_fallback():
    """Deprecated insights_api_* params should work as fallback."""
    with patch.dict(os.environ, {}, clear=True):
        obs = create_mcp_observability_easy(
            service_name="test-svc",
            insights_api_url="https://deprecated.com",
            insights_api_key="deprecated-key",
        )
        assert isinstance(obs, McpObservability)


def test_easy_setup_uses_expanded_redact_keys():
    """Easy setup should use expanded default redact keys (not just the old 5)."""
    from mcp_observability.sinks import InMemorySink

    with patch.dict(os.environ, {}, clear=True):
        obs = create_mcp_observability_easy(service_name="test-svc")
        # Create a temporary sink to capture events
        sink = InMemorySink()
        obs._sinks.append(sink)
        obs.record_business_event(
            "test",
            properties={
                "email": "test@test.com",
                "phone": "555-1234",
                "userId": "u1",
                "name": "alice",
            },
        )
        events = sink.get_events()
        assert len(events) == 1
        props = events[0].properties
        assert props["email"] == "[redacted]"
        assert props["phone"] == "[redacted]"
        assert props["userId"] == "[redacted]"
        assert props["name"] == "alice"


def test_easy_setup_production_warning_says_listo():
    """Warning in production mode should reference LISTO_API_KEY, not INSIGHTS_API_KEY."""
    import warnings

    with patch.dict(os.environ, {"ENVIRONMENT": "production"}, clear=True):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            create_mcp_observability_easy(service_name="test-svc")
            # Find the relevant warning
            listo_warnings = [x for x in w if "LISTO_API_KEY" in str(x.message)]
            assert len(listo_warnings) > 0
            # Should NOT reference the old INSIGHTS_API_KEY name in warning
            for warning in w:
                assert "INSIGHTS_API_KEY" not in str(warning.message)
