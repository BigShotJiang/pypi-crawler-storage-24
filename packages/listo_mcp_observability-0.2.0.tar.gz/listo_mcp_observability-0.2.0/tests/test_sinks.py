from mcp_observability.sinks import ConsoleSink, InMemorySink, combine_sinks
from mcp_observability.types import (
    BusinessEvent,
    HttpRequestEvent,
    McpRequestEvent,
    McpSessionEvent,
    UiEvent,
)


def test_in_memory_sink_emit():
    sink = InMemorySink(limit=5)
    for i in range(3):
        sink.emit(HttpRequestEvent(latency_ms=float(i)))
    events = sink.get_events()
    assert len(events) == 3


def test_in_memory_sink_circular_buffer():
    sink = InMemorySink(limit=3)
    for i in range(5):
        sink.emit(HttpRequestEvent(latency_ms=float(i), request_id=str(i)))
    events = sink.get_events()
    assert len(events) == 3
    assert events[0].request_id == "2"
    assert events[2].request_id == "4"


def test_in_memory_sink_get_metrics():
    sink = InMemorySink()
    sink.emit(HttpRequestEvent(method="GET", route="/api", latency_ms=10.0, status="ok"))
    sink.emit(
        McpRequestEvent(
            request_kind="CallTool",
            tool_name="search",
            latency_ms=50.0,
            status="ok",
        )
    )
    sink.emit(McpSessionEvent(action="open", session_id="s1"))
    sink.emit(BusinessEvent(name="purchase", status="ok"))
    sink.emit(UiEvent(name="click", action="press"))

    metrics = sink.get_metrics()
    assert metrics["totals"]["events"] == 5
    assert metrics["totals"]["http"] == 1
    assert metrics["totals"]["mcp"] == 1
    assert metrics["totals"]["sessions"] == 1
    assert metrics["totals"]["ui"] == 1
    assert metrics["totals"]["business"] == 1
    assert metrics["sessions"]["open"] == 1


def test_in_memory_sink_metrics_http_by_route():
    sink = InMemorySink()
    sink.emit(HttpRequestEvent(method="GET", route="/api/a", latency_ms=10.0, status="ok"))
    sink.emit(HttpRequestEvent(method="GET", route="/api/a", latency_ms=20.0, status="ok"))
    sink.emit(HttpRequestEvent(method="GET", route="/api/b", latency_ms=30.0, status="error"))

    metrics = sink.get_metrics()
    assert "/api/a" in metrics["http"]["byRoute"]
    assert metrics["http"]["byRoute"]["/api/a"]["count"] == 2
    assert metrics["http"]["byRoute"]["/api/b"]["errors"] == 1


def test_console_sink_error_output(capsys):
    sink = ConsoleSink(log_success=False)
    sink.emit(
        HttpRequestEvent(
            method="GET",
            route="/fail",
            status="error",
            status_code=500,
            latency_ms=100.0,
            error="boom",
        )
    )
    captured = capsys.readouterr()
    assert "[telemetry]" in captured.err
    assert "error" in captured.err
    assert "boom" in captured.err


def test_console_sink_suppresses_ok():
    sink = ConsoleSink(log_success=False)
    # This should produce no output
    sink.emit(
        HttpRequestEvent(
            method="GET",
            route="/ok",
            status="ok",
            status_code=200,
            latency_ms=5.0,
        )
    )


def test_console_sink_log_success(capsys):
    sink = ConsoleSink(log_success=True)
    sink.emit(
        HttpRequestEvent(
            method="GET",
            route="/ok",
            status="ok",
            status_code=200,
            latency_ms=5.0,
        )
    )
    captured = capsys.readouterr()
    assert "[telemetry]" in captured.out


def test_combine_sinks_routes_to_all():
    sink1 = InMemorySink()
    sink2 = InMemorySink()
    combined = combine_sinks(sink1, sink2)

    event = BusinessEvent(name="test")
    combined.emit(event)

    assert len(sink1.get_events()) == 1
    assert len(sink2.get_events()) == 1


def test_combine_sinks_error_isolation():
    """A failing sink should not prevent other sinks from receiving events."""

    class FailingSink:
        def emit(self, event):
            raise RuntimeError("sink error")

    good_sink = InMemorySink()
    combined = combine_sinks(FailingSink(), good_sink)

    event = BusinessEvent(name="test")
    combined.emit(event)  # Should not raise

    assert len(good_sink.get_events()) == 1


def test_combine_sinks_empty():
    combined = combine_sinks()
    # Should not raise when emitting with no sinks
    combined.emit(BusinessEvent(name="test"))
