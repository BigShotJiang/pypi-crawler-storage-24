from mcp_observability.platform import (
    McpClientInfo,
    PlatformHints,
    detect_platform,
)


class TestDetectPlatformHeaders:
    def test_openai_user_agent(self):
        hints = PlatformHints(headers={"User-Agent": "OpenAI-Client/1.0"})
        assert detect_platform(hints) == "chatgpt"

    def test_x_openai_header(self):
        hints = PlatformHints(headers={"X-OpenAI-Key": "abc"})
        assert detect_platform(hints) == "chatgpt"

    def test_claude_user_agent(self):
        hints = PlatformHints(headers={"User-Agent": "Claude-Desktop/2.0"})
        assert detect_platform(hints) == "claude"

    def test_anthropic_user_agent(self):
        hints = PlatformHints(headers={"User-Agent": "Anthropic-SDK/1.0"})
        assert detect_platform(hints) == "claude"

    def test_x_anthropic_header(self):
        hints = PlatformHints(headers={"X-Anthropic-Version": "2024-01"})
        assert detect_platform(hints) == "claude"

    def test_case_insensitive_headers(self):
        hints = PlatformHints(headers={"user-agent": "OPENAI-something"})
        assert detect_platform(hints) == "chatgpt"

    def test_unknown_user_agent(self):
        hints = PlatformHints(headers={"User-Agent": "Mozilla/5.0"})
        assert detect_platform(hints) == "other"


class TestDetectPlatformMeta:
    def test_openai_meta_prefix(self):
        hints = PlatformHints(meta={"openai/model": "gpt-4"})
        assert detect_platform(hints) == "chatgpt"

    def test_anthropic_meta_prefix(self):
        hints = PlatformHints(meta={"anthropic/version": "2024-01"})
        assert detect_platform(hints) == "claude"

    def test_claude_meta_prefix(self):
        hints = PlatformHints(meta={"claude/session": "s1"})
        assert detect_platform(hints) == "claude"

    def test_unknown_meta(self):
        hints = PlatformHints(meta={"custom/key": "value"})
        assert detect_platform(hints) == "other"


class TestDetectPlatformClientInfo:
    def test_claude_desktop(self):
        hints = PlatformHints(client_info=McpClientInfo(name="claude-desktop"))
        assert detect_platform(hints) == "claude"

    def test_claude_exact(self):
        hints = PlatformHints(client_info=McpClientInfo(name="claude"))
        assert detect_platform(hints) == "claude"

    def test_chatgpt_exact(self):
        hints = PlatformHints(client_info=McpClientInfo(name="chatgpt"))
        assert detect_platform(hints) == "chatgpt"

    def test_claude_prefix(self):
        hints = PlatformHints(client_info=McpClientInfo(name="claude-mobile"))
        assert detect_platform(hints) == "claude"

    def test_ignored_names(self):
        for name in ["unavailable", "unknown", "n/a", "none", ""]:
            hints = PlatformHints(client_info=McpClientInfo(name=name))
            assert detect_platform(hints) == "other", f"Expected 'other' for name={name!r}"

    def test_unknown_client(self):
        hints = PlatformHints(client_info=McpClientInfo(name="my-custom-client"))
        assert detect_platform(hints) == "other"

    def test_case_insensitive_client_name(self):
        hints = PlatformHints(client_info=McpClientInfo(name="Claude-Desktop"))
        assert detect_platform(hints) == "claude"


class TestDetectPlatformPriority:
    def test_headers_beat_meta(self):
        hints = PlatformHints(
            headers={"User-Agent": "OpenAI-Client"},
            meta={"anthropic/version": "2024-01"},
        )
        assert detect_platform(hints) == "chatgpt"

    def test_headers_beat_client_info(self):
        hints = PlatformHints(
            headers={"X-Anthropic-Version": "2024-01"},
            client_info=McpClientInfo(name="chatgpt"),
        )
        assert detect_platform(hints) == "claude"

    def test_meta_beats_client_info(self):
        hints = PlatformHints(
            meta={"openai/model": "gpt-4"},
            client_info=McpClientInfo(name="claude-desktop"),
        )
        assert detect_platform(hints) == "chatgpt"


class TestDetectPlatformEdgeCases:
    def test_none_hints(self):
        assert detect_platform(None) == "other"

    def test_no_args(self):
        assert detect_platform() == "other"

    def test_empty_hints(self):
        assert detect_platform(PlatformHints()) == "other"

    def test_empty_headers(self):
        assert detect_platform(PlatformHints(headers={})) == "other"

    def test_empty_meta(self):
        assert detect_platform(PlatformHints(meta={})) == "other"

    def test_client_info_with_version(self):
        hints = PlatformHints(client_info=McpClientInfo(name="claude-desktop", version="1.2.3"))
        assert detect_platform(hints) == "claude"
