from mcp_observability._utils import (
    clamp_sample_rate,
    estimate_size,
    hash_payload,
    percentile,
    sanitize_payload,
    should_sample,
    summarize_business_events,
    summarize_latency,
    summarize_ui_events,
    truncate_preview,
    truncate_string,
)
from mcp_observability.types import BusinessEvent, HttpRequestEvent, McpSessionEvent, UiEvent


def test_hash_payload_string():
    h = hash_payload("hello")
    assert h is not None
    assert len(h) == 64  # SHA256 hex


def test_hash_payload_dict():
    h = hash_payload({"key": "value"})
    assert h is not None


def test_hash_payload_none():
    h = hash_payload(None)
    assert h is not None  # json.dumps(None) == "null"


def test_estimate_size():
    size = estimate_size({"a": 1})
    assert size is not None
    assert size > 0


def test_estimate_size_none_input():
    size = estimate_size(None)
    assert size == 4  # "null"


def test_sanitize_payload_redacts_keys():
    redact = {"password", "token"}
    result = sanitize_payload({"password": "secret123", "name": "test"}, redact)
    assert result["password"] == "[redacted]"
    assert result["name"] == "test"


def test_sanitize_payload_case_insensitive():
    redact = {"apikey"}
    result = sanitize_payload({"ApiKey": "abc"}, redact)
    assert result["ApiKey"] == "[redacted]"


def test_sanitize_payload_nested():
    redact = {"token"}
    result = sanitize_payload({"user": {"token": "xyz", "name": "alice"}}, redact)
    assert result["user"]["token"] == "[redacted]"
    assert result["user"]["name"] == "alice"


def test_sanitize_payload_depth_limit():
    redact: set[str] = set()
    deeply_nested: dict = {"a": {"b": {"c": {"d": {"e": {"f": {"g": "deep"}}}}}}}
    result = sanitize_payload(deeply_nested, redact)
    # At depth 7, should be truncated
    assert result["a"]["b"]["c"]["d"]["e"]["f"]["g"] == "[truncated]"


def test_sanitize_payload_array():
    redact = {"secret"}
    result = sanitize_payload([{"secret": "x"}, {"name": "y"}], redact)
    assert result[0]["secret"] == "[redacted]"
    assert result[1]["name"] == "y"


def test_sanitize_payload_array_limit():
    redact: set[str] = set()
    big_list = list(range(30))
    result = sanitize_payload(big_list, redact)
    assert len(result) == 20


def test_truncate_string_short():
    assert truncate_string("hello") == "hello"


def test_truncate_string_long():
    long_str = "a" * 300
    result = truncate_string(long_str, 240)
    assert len(result) == 241  # 240 + ellipsis char
    assert result.endswith("\u2026")


def test_truncate_preview_dict():
    result = truncate_preview({"key": "a" * 300})
    assert len(result["key"]) == 241


def test_truncate_preview_list():
    result = truncate_preview(["a" * 300, 42])
    assert len(result[0]) == 241
    assert result[1] == 42


def test_clamp_sample_rate():
    assert clamp_sample_rate(None) == 1.0
    assert clamp_sample_rate(0.5) == 0.5
    assert clamp_sample_rate(-1.0) == 0.0
    assert clamp_sample_rate(2.0) == 1.0
    assert clamp_sample_rate(float("nan")) == 1.0


def test_should_sample_errors_always():
    event = HttpRequestEvent(status="error")
    assert should_sample(event, 0.0) is True


def test_should_sample_sessions_always():
    event = McpSessionEvent(action="open", session_id="s1")
    assert should_sample(event, 0.0) is True


def test_should_sample_rate_1():
    event = HttpRequestEvent(status="ok")
    assert should_sample(event, 1.0) is True


def test_percentile_empty():
    assert percentile([], 0.5) is None


def test_percentile_values():
    values = [1.0, 2.0, 3.0, 4.0, 5.0]
    assert percentile(values, 0.5) == 3.0
    assert percentile(values, 0.0) == 1.0


def test_summarize_latency_empty():
    result = summarize_latency([])
    assert result["count"] == 0
    assert result["errors"] == 0


def test_summarize_latency_events():
    events = [
        HttpRequestEvent(latency_ms=10.0, status="ok"),
        HttpRequestEvent(latency_ms=20.0, status="ok"),
        HttpRequestEvent(latency_ms=30.0, status="error"),
    ]
    result = summarize_latency(events)
    assert result["count"] == 3
    assert result["errors"] == 1
    assert result["avgMs"] == 20.0


def test_summarize_ui_events_by_category():
    events = [
        UiEvent(name="click", category="engagement"),
        UiEvent(name="view", category="impression"),
        UiEvent(name="tap", category="engagement"),
        UiEvent(name="scroll"),  # no category
    ]
    result = summarize_ui_events(events)
    assert result["byCategory"]["engagement"] == 2
    assert result["byCategory"]["impression"] == 1
    assert "total" in result
    assert result["total"] == 4
    # Events without category should NOT appear in byCategory
    assert len(result["byCategory"]) == 2  # only engagement and impression


def test_summarize_business_events_by_category():
    events = [
        BusinessEvent(name="purchase", category="conversion", status="ok"),
        BusinessEvent(name="signup", category="conversion", status="ok"),
        BusinessEvent(name="view", category="engagement", status="error"),
        BusinessEvent(name="other"),  # no category
    ]
    result = summarize_business_events(events)
    assert result["byCategory"]["conversion"]["count"] == 2
    assert result["byCategory"]["conversion"]["ok"] == 2
    assert result["byCategory"]["engagement"]["count"] == 1
    assert result["byCategory"]["engagement"]["error"] == 1
    assert result["byName"]["purchase"]["count"] == 1
    assert result["byName"]["other"]["count"] == 1
