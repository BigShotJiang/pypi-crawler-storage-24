import html
import json

import pytest

from mcp_observability.easy_setup import create_mcp_observability_easy


@pytest.fixture(autouse=True)
def _setup_observability():
    """Ensure easy_setup globals are initialized for endpoint tests."""
    create_mcp_observability_easy(
        service_name="test-svc",
        enable_local_dashboard=True,
    )


def test_dashboard_escapes_tool_names():
    """XSS: tool names with HTML should be escaped in dashboard output."""
    from mcp_observability.easy_setup import get_telemetry_sink

    sink = get_telemetry_sink()
    assert sink is not None

    from mcp_observability.types import McpRequestEvent

    xss_payload = '<img src=x onerror="alert(1)">'
    sink.emit(
        McpRequestEvent(
            request_kind="CallTool",
            tool_name=xss_payload,
            latency_ms=10.0,
            status="ok",
        )
    )

    metrics = sink.get_metrics()
    tools = metrics["mcp"]["tools"]
    assert xss_payload in tools

    # Verify the dashboard HTML escapes the tool name
    from mcp_observability.endpoints import _telemetry_dashboard_handler

    class FakeRequest:
        pass

    import asyncio

    response = asyncio.get_event_loop().run_until_complete(
        _telemetry_dashboard_handler(FakeRequest())
    )
    body = response.body.decode()
    # Raw XSS payload must NOT appear unescaped
    assert xss_payload not in body
    # Escaped version must appear
    assert html.escape(xss_payload) in body


def test_dashboard_escapes_route_names():
    """XSS: route names with HTML should be escaped in dashboard output."""
    from mcp_observability.easy_setup import get_telemetry_sink

    sink = get_telemetry_sink()
    assert sink is not None

    from mcp_observability.types import HttpRequestEvent

    xss_payload = '<script>alert("xss")</script>'
    sink.emit(
        HttpRequestEvent(
            method="GET",
            route=xss_payload,
            latency_ms=5.0,
            status="ok",
        )
    )

    from mcp_observability.endpoints import _telemetry_dashboard_handler

    class FakeRequest:
        pass

    import asyncio

    response = asyncio.get_event_loop().run_until_complete(
        _telemetry_dashboard_handler(FakeRequest())
    )
    body = response.body.decode()
    assert xss_payload not in body
    assert html.escape(xss_payload) in body


@pytest.mark.asyncio
async def test_post_event_rejects_oversized_body():
    """POST /telemetry/event should reject bodies > 8 KB."""
    from mcp_observability.endpoints import _telemetry_event_handler

    class FakeRequest:
        headers = {"content-length": str(100 * 1024)}  # 100 KB

        async def body(self):
            return b"x" * (100 * 1024)

    response = await _telemetry_event_handler(FakeRequest())
    assert response.status_code == 413


@pytest.mark.asyncio
async def test_post_event_accepts_normal_body():
    """POST /telemetry/event should accept normal-sized bodies."""
    from mcp_observability.endpoints import _telemetry_event_handler

    payload = json.dumps({"name": "click", "action": "press"}).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_event_handler(FakeRequest())
    assert response.status_code == 201


@pytest.mark.asyncio
async def test_post_event_requires_name():
    """POST /telemetry/event should return 400 when name is missing."""
    from mcp_observability.endpoints import _telemetry_event_handler

    payload = json.dumps({"action": "press"}).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_event_handler(FakeRequest())
    assert response.status_code == 400


@pytest.mark.asyncio
async def test_post_event_rejects_invalid_category():
    """POST /telemetry/event should return 400 for invalid category."""
    from mcp_observability.endpoints import _telemetry_event_handler

    payload = json.dumps({"name": "click", "category": "invalid_cat"}).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_event_handler(FakeRequest())
    assert response.status_code == 400


@pytest.mark.asyncio
async def test_post_event_accepts_valid_category():
    """POST /telemetry/event should accept valid categories."""
    from mcp_observability.endpoints import _telemetry_event_handler

    payload = json.dumps({"name": "click", "category": "engagement"}).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_event_handler(FakeRequest())
    assert response.status_code == 201


@pytest.mark.asyncio
async def test_post_event_strips_unknown_fields():
    """POST /telemetry/event should strip unknown fields from events."""
    from mcp_observability.easy_setup import get_telemetry_sink
    from mcp_observability.endpoints import _telemetry_event_handler

    sink = get_telemetry_sink()
    assert sink is not None
    initial_count = len(sink.get_events())

    payload = json.dumps(
        {
            "name": "click",
            "action": "press",
            "unknownField": "should be stripped",
            "anotherBad": 123,
        }
    ).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_event_handler(FakeRequest())
    assert response.status_code == 201

    events = sink.get_events()
    assert len(events) > initial_count
    last_event = events[-1]
    assert last_event.name == "click"
    assert last_event.action == "press"


# --- Batch endpoint tests ---


@pytest.mark.asyncio
async def test_batch_events_endpoint():
    """POST /telemetry/events should accept batch events."""
    from mcp_observability.endpoints import _telemetry_events_handler

    payload = json.dumps(
        {
            "events": [
                {"name": "click", "action": "press"},
                {"name": "view", "category": "impression"},
            ]
        }
    ).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_events_handler(FakeRequest())
    assert response.status_code == 201
    body = json.loads(response.body)
    assert body["ok"] is True
    assert body["accepted"] == 2
    assert body["rejected"] == 0


@pytest.mark.asyncio
async def test_batch_events_partial_validation():
    """POST /telemetry/events should accept valid events and reject invalid ones."""
    from mcp_observability.endpoints import _telemetry_events_handler

    payload = json.dumps(
        {
            "events": [
                {"name": "click"},  # valid
                {"action": "press"},  # invalid: no name
                {"name": "view", "category": "bad_cat"},  # invalid: bad category
            ]
        }
    ).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_events_handler(FakeRequest())
    assert response.status_code == 201
    body = json.loads(response.body)
    assert body["accepted"] == 1
    assert body["rejected"] == 2


@pytest.mark.asyncio
async def test_batch_events_max_100():
    """POST /telemetry/events should reject batches over 100 events."""
    from mcp_observability.endpoints import _telemetry_events_handler

    payload = json.dumps({"events": [{"name": f"event-{i}"} for i in range(101)]}).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_events_handler(FakeRequest())
    assert response.status_code == 400
    body = json.loads(response.body)
    assert "Maximum 100" in body["error"]


@pytest.mark.asyncio
async def test_batch_events_requires_events_array():
    """POST /telemetry/events should return 400 if events array is missing."""
    from mcp_observability.endpoints import _telemetry_events_handler

    payload = json.dumps({"data": "not an events array"}).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_events_handler(FakeRequest())
    assert response.status_code == 400


@pytest.mark.asyncio
async def test_post_event_camel_to_snake_mapping():
    """POST /telemetry/event should convert camelCase fields to snake_case on UiEvent."""
    from mcp_observability.easy_setup import get_telemetry_sink
    from mcp_observability.endpoints import _telemetry_event_handler

    sink = get_telemetry_sink()
    assert sink is not None
    initial_count = len(sink.get_events())

    payload = json.dumps(
        {
            "name": "click",
            "widgetId": "btn-1",
            "deviceId": "dev-99",
            "category": "engagement",
            "sessionId": "sess-abc",
            "tenantId": "t-xyz",
            "toolName": "my_tool",
            "locale": "en-GB",
        }
    ).encode()

    class FakeRequest:
        headers = {"content-length": str(len(payload))}

        async def body(self):
            return payload

    response = await _telemetry_event_handler(FakeRequest())
    assert response.status_code == 201

    events = sink.get_events()
    assert len(events) > initial_count
    last_event = events[-1]
    assert last_event.name == "click"
    assert last_event.widget_id == "btn-1"
    assert last_event.device_id == "dev-99"
    assert last_event.category == "engagement"
    assert last_event.session_id == "sess-abc"
    assert last_event.tenant_id == "t-xyz"
    assert last_event.tool_name == "my_tool"
    assert last_event.locale == "en-GB"
