from dataclasses import asdict

from mcp_observability.types import (
    BusinessEvent,
    EventCategory,
    HttpRequestEvent,
    McpRequestEvent,
    McpSessionEvent,
    McpTrackingContext,
    UiEvent,
)


def test_http_request_event_defaults():
    event = HttpRequestEvent()
    assert event.type == "http_request"
    assert event.timestamp == 0.0
    assert event.status == "ok"
    assert event.error is None


def test_http_request_event_custom():
    event = HttpRequestEvent(
        service="test-svc",
        method="GET",
        path="/api/foo",
        route="/api/foo",
        status_code=200,
        latency_ms=42.5,
    )
    assert event.method == "GET"
    assert event.latency_ms == 42.5


def test_mcp_request_event_defaults():
    event = McpRequestEvent()
    assert event.type == "mcp_request"
    assert event.tool_name is None


def test_mcp_session_event():
    event = McpSessionEvent(action="open", session_id="sess-1")
    assert event.type == "mcp_session"
    assert event.action == "open"


def test_business_event():
    event = BusinessEvent(name="purchase", properties={"amount": 99.99}, status="ok")
    assert event.name == "purchase"
    assert event.properties["amount"] == 99.99


def test_business_event_with_category():
    event = BusinessEvent(
        name="signup",
        category="conversion",
        session_id="s1",
        device_id="d1",
        tenant_id="t1",
    )
    assert event.category == "conversion"
    assert event.session_id == "s1"
    assert event.device_id == "d1"
    assert event.tenant_id == "t1"


def test_ui_event():
    event = UiEvent(name="click", action="button_press", widget_id="w1")
    assert event.type == "ui_event"
    assert event.widget_id == "w1"


def test_ui_event_with_category_and_device_id():
    event = UiEvent(name="view", category="impression", device_id="dev-1")
    assert event.category == "impression"
    assert event.device_id == "dev-1"


def test_event_category_type():
    cat: EventCategory = "conversion"
    assert cat == "conversion"


def test_event_serialization():
    event = HttpRequestEvent(service="svc", method="POST", status_code=201)
    data = asdict(event)
    assert data["type"] == "http_request"
    assert data["method"] == "POST"
    assert isinstance(data, dict)


def test_mcp_tracking_context_result_preview():
    ctx = McpTrackingContext(result_preview=lambda r: str(r)[:10])
    assert ctx.result_preview is not None
    assert ctx.result_preview("hello world") == "hello worl"


def test_mcp_tracking_context_no_pii_fields():
    ctx = McpTrackingContext()
    assert not hasattr(ctx, "user_id")
    assert not hasattr(ctx, "user_location")


def test_http_request_event_no_user_id():
    event = HttpRequestEvent()
    assert not hasattr(event, "user_id")


def test_mcp_request_event_no_pii_fields():
    event = McpRequestEvent()
    assert not hasattr(event, "user_id")
    assert not hasattr(event, "user_location")


def test_ui_event_no_pii_fields():
    event = UiEvent()
    assert not hasattr(event, "user_id")
    assert not hasattr(event, "user_location")


def test_ui_event_has_locale():
    event = UiEvent(name="click", locale="en-US")
    assert event.locale == "en-US"


def test_business_event_new_fields_default_none():
    event = BusinessEvent(name="test")
    assert event.category is None
    assert event.session_id is None
    assert event.device_id is None
    assert event.tenant_id is None


def test_user_location_not_importable():
    """UserLocation should no longer exist in the types module."""
    import mcp_observability.types as types_mod

    assert not hasattr(types_mod, "UserLocation")


def test_event_category_importable_from_package():
    """EventCategory should be importable from the top-level package."""
    import mcp_observability

    assert hasattr(mcp_observability, "EventCategory")


def test_combine_sinks_importable_from_package():
    """combine_sinks should be importable from the top-level package."""
    import mcp_observability

    assert hasattr(mcp_observability, "combine_sinks")
    assert callable(mcp_observability.combine_sinks)


def test_user_location_not_importable_from_package():
    """UserLocation should NOT be importable from the top-level package."""
    import mcp_observability

    assert not hasattr(mcp_observability, "UserLocation")
