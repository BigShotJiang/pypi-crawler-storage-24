import json
from unittest.mock import MagicMock, patch

from mcp_observability.remote_sink import RemoteSink, RemoteSinkOptions
from mcp_observability.types import BusinessEvent


def _make_sink(**overrides):
    defaults = {
        "endpoint": "https://example.com/events",
        "api_key": "test-key",
        "batch_size": 3,
        "flush_interval": 999.0,  # Don't auto-flush during tests
    }
    defaults.update(overrides)
    opts = RemoteSinkOptions(**defaults)
    sink = RemoteSink(opts)
    return sink


def test_emit_buffers_events():
    sink = _make_sink()
    try:
        sink.emit(BusinessEvent(name="e1"))
        sink.emit(BusinessEvent(name="e2"))
        assert len(sink._buffer) == 2
    finally:
        sink.destroy()


def test_flush_empties_buffer():
    sink = _make_sink()
    try:
        sink.emit(BusinessEvent(name="e1"))
        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_response = MagicMock()
            mock_response.status = 200
            mock_response.__enter__ = MagicMock(return_value=mock_response)
            mock_response.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_response

            sink.flush()
            assert len(sink._buffer) == 0
            mock_urlopen.assert_called_once()
    finally:
        sink.destroy()


def test_flush_sends_correct_payload():
    sink = _make_sink()
    try:
        sink.emit(BusinessEvent(name="test_event", status="ok"))
        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_response = MagicMock()
            mock_response.status = 200
            mock_response.__enter__ = MagicMock(return_value=mock_response)
            mock_response.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_response

            sink.flush()

            call_args = mock_urlopen.call_args
            req = call_args[0][0]
            assert req.get_header("X-api-key") == "test-key"
            assert req.get_header("Content-type") == "application/json"
            body = json.loads(req.data)
            assert "events" in body
            assert len(body["events"]) == 1
    finally:
        sink.destroy()


def test_batch_size_triggers_flush():
    sink = _make_sink(batch_size=2)
    try:
        with patch.object(sink, "_flush_in_thread") as mock_flush:
            sink.emit(BusinessEvent(name="e1"))
            mock_flush.assert_not_called()
            sink.emit(BusinessEvent(name="e2"))
            mock_flush.assert_called_once()
    finally:
        sink.destroy()


def test_camel_case_conversion():
    sink = _make_sink()
    try:
        result = sink._to_camel_case({"tool_name": "search", "latency_ms": 42})
        assert result == {"toolName": "search", "latencyMs": 42}
    finally:
        sink.destroy()


def test_destroy_cancels_timer():
    sink = _make_sink()
    assert sink._timer is not None
    sink.destroy()
    assert sink._timer is None


def test_max_buffer_size_drops_oldest():
    sink = _make_sink(max_buffer_size=3, batch_size=100)
    try:
        for i in range(5):
            sink.emit(BusinessEvent(name=f"e{i}"))
        assert len(sink._buffer) == 3
        # Oldest events (e0, e1) should have been dropped
        names = [e.name for e in sink._buffer]
        assert names == ["e2", "e3", "e4"]
    finally:
        sink.destroy()


def test_http_timeout_is_passed():
    sink = _make_sink(http_timeout=10.0)
    try:
        sink.emit(BusinessEvent(name="e1"))
        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_response = MagicMock()
            mock_response.status = 200
            mock_response.__enter__ = MagicMock(return_value=mock_response)
            mock_response.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_response

            sink.flush()

            call_args = mock_urlopen.call_args
            assert call_args[1].get("timeout") == 10.0 or call_args[0][1] is not None
    finally:
        sink.destroy()
