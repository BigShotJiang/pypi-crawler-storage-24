# Changelog

## [0.2.0] - 2026-03-20

### Added

- **Platform detection** — new `detect_platform()` function identifies the AI platform (Claude, ChatGPT, or other) from HTTP headers, `_meta` key prefixes, and `clientInfo.name`. Three-tier detection with first-match-wins priority.
- **`platform` field** on `McpRequestEvent`, `McpSessionEvent`, and `McpTrackingContext` — enables filtering analytics by platform in the dashboard.
- `record_session()` now accepts an optional `platform` keyword argument.
- New exports: `Platform`, `KnownPlatform`, `PlatformHints`, `McpClientInfo`, `detect_platform`.
- New `platform` field on `ObservabilityOptions` for TypeScript SDK parity.

### Notes

- No breaking changes. All new fields default to `None`.
- `remote_sink` picks up the new field automatically via `dataclasses.asdict()`.

## [0.1.0] - 2025-02-25

### Added

- Full TypeScript SDK feature parity (v0.1.0).
- `track_tool()` decorator, `wrap_mcp_handler()`, `record_session()`, `record_business_event()`, `record_ui_event()`.
- Payload sanitization with configurable redact keys.
- `InMemorySink`, `RemoteSink`, `ConsoleSink`, `combine_sinks()`.
- Starlette dashboard and event ingestion endpoints.
- Sampling with guaranteed error and session capture.

## [0.0.2] - 2025-02-25

### Changed

- Security hardening and PyPI publish readiness.

## [0.0.1] - 2025-02-25

### Added

- Initial commit.
