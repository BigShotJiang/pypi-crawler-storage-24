from __future__ import annotations

import os
import warnings

from mcp_observability.core import McpObservability, ObservabilityOptions
from mcp_observability.remote_sink import RemoteSinkOptions, create_remote_sink
from mcp_observability.sinks import ConsoleSink, EventSink, InMemorySink

# Module-level globals for dashboard endpoint access
_telemetry_sink: InMemorySink | None = None
_observability: McpObservability | None = None


def get_telemetry_sink() -> InMemorySink | None:
    return _telemetry_sink


def get_observability() -> McpObservability | None:
    return _observability


def create_mcp_observability_easy(
    service_name: str,
    service_version: str = "1.0.0",
    environment: str | None = None,
    listo_api_url: str | None = None,
    listo_api_key: str | None = None,
    insights_api_url: str | None = None,
    insights_api_key: str | None = None,
    enable_local_dashboard: bool | None = None,
    sample_rate: float | None = None,
) -> McpObservability:
    """Create an observability instance with environment-based defaults.

    This is the easiest way to get started. It automatically:
    - Configures RemoteSink if LISTO_API_KEY is provided
    - Configures InMemorySink + local dashboard in development
    - Applies sensible defaults (sampling, redaction, etc.)

    Environment variables used:
    - LISTO_API_URL: Remote telemetry API endpoint (primary)
    - LISTO_API_KEY: API key for authentication (primary)
    - INSIGHTS_API_URL: Deprecated, use LISTO_API_URL
    - INSIGHTS_API_KEY: Deprecated, use LISTO_API_KEY
    - ENVIRONMENT or PYTHON_ENV: Determines dev/production mode
    """
    global _telemetry_sink, _observability

    if environment is None:
        env_val = os.environ.get("ENVIRONMENT") or os.environ.get("PYTHON_ENV", "")
        environment = "production" if env_val.lower() == "production" else "dev"

    # Resolve API URL: param > LISTO_* env > deprecated param > INSIGHTS_* env
    api_url = (
        listo_api_url
        or os.environ.get("LISTO_API_URL")
        or insights_api_url
        or os.environ.get("INSIGHTS_API_URL")
    )

    # Resolve API key: param > LISTO_* env > deprecated param > INSIGHTS_* env
    api_key = (
        listo_api_key
        or os.environ.get("LISTO_API_KEY")
        or insights_api_key
        or os.environ.get("INSIGHTS_API_KEY")
    )

    if enable_local_dashboard is None:
        enable_local_dashboard = environment == "dev"

    if sample_rate is None:
        sample_rate = 0.1 if environment == "production" else 1.0

    sinks: list[EventSink] = []

    # Console logging in dev only
    if environment == "dev":
        sinks.append(ConsoleSink(log_success=False))

    # Local in-memory dashboard for development
    if enable_local_dashboard:
        telemetry_sink = InMemorySink(limit=2000)
        sinks.append(telemetry_sink)
        _telemetry_sink = telemetry_sink

    # Remote sink
    if api_url and api_key:
        sinks.append(
            create_remote_sink(
                RemoteSinkOptions(
                    endpoint=f"{api_url}/v1/events/batch",
                    api_key=api_key,
                    batch_size=50,
                    flush_interval=5.0,
                    max_retries=3,
                )
            )
        )
    elif environment != "dev":
        warnings.warn(
            "[mcp-observability] No API key configured. "
            "Set LISTO_API_KEY environment variable to enable remote telemetry.",
            stacklevel=2,
        )

    options = ObservabilityOptions(
        service_name=service_name,
        service_version=service_version,
        environment=environment,
        sample_rate=sample_rate,
        capture_payloads=True,
        sinks=sinks if sinks else [ConsoleSink(log_success=False)],
    )

    observability = McpObservability(options)
    _observability = observability
    return observability
