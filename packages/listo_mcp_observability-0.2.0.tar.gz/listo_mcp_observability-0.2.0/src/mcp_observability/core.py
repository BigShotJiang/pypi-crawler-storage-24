from __future__ import annotations

import functools
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, TypeVar

from mcp_observability._utils import (
    clamp_sample_rate,
    estimate_size,
    hash_payload,
    sanitize_payload,
    should_sample,
    to_error_message,
    truncate_preview,
    truncate_string,
)
from mcp_observability.sinks import ConsoleSink, EventSink
from mcp_observability.types import (
    BusinessEvent,
    EventCategory,
    EventStatus,
    McpRequestEvent,
    McpSessionEvent,
    McpTrackingContext,
    ObservabilityEvent,
    UiEvent,
)

T = TypeVar("T")

_DEFAULT_REDACT_KEYS = frozenset(
    [
        "authorization",
        "apikey",
        "password",
        "token",
        "secret",
        "userid",
        "userlocation",
        "email",
        "useremail",
        "phone",
        "phonenumber",
    ]
)


@dataclass
class ObservabilityOptions:
    service_name: str
    service_version: str | None = None
    environment: str | None = None
    sinks: list[EventSink] | None = None
    sample_rate: float = 1.0
    redact_keys: list[str] | None = None
    capture_payloads: bool = False
    platform: str | None = None


class McpObservability:
    def __init__(self, options: ObservabilityOptions) -> None:
        self._service_name = options.service_name
        self._service_version = options.service_version
        self._environment = options.environment
        self._sinks: list[EventSink] = (
            options.sinks if options.sinks else [ConsoleSink(log_success=False)]
        )
        self._sample_rate = clamp_sample_rate(options.sample_rate)
        self._redact_keys: set[str] = {
            k.lower() for k in (options.redact_keys or list(_DEFAULT_REDACT_KEYS))
        }
        self._capture_payloads = options.capture_payloads

    def _base_mcp_fields(self) -> dict[str, Any]:
        return {
            "service": self._service_name,
            "service_version": self._service_version,
            "environment": self._environment,
        }

    def _sanitize(self, payload: Any) -> Any:
        return sanitize_payload(payload, self._redact_keys)

    def _safe_emit(self, event: ObservabilityEvent) -> None:
        if not should_sample(event, self._sample_rate):
            return
        for sink in self._sinks:
            try:
                sink.emit(event)
            except Exception as exc:
                import sys

                print(f"Telemetry sink failed: {exc}", file=sys.stderr)

    def wrap_mcp_handler(
        self,
        request_kind: str,
        handler: Callable[..., Any],
        context: Callable[..., McpTrackingContext] | None = None,
    ) -> Callable[..., Any]:
        async def wrapped(*args: Any, **kwargs: Any) -> Any:
            metadata = context(*args, **kwargs) if context else McpTrackingContext()
            request_id = metadata.request_id or str(uuid.uuid4())
            start = time.perf_counter()
            try:
                result = await handler(*args, **kwargs)
                latency_ms = (time.perf_counter() - start) * 1000
                sanitized_args = self._sanitize(metadata.args) if metadata.args else None
                sanitized_result = (
                    self._sanitize(metadata.result_preview(result))
                    if metadata.result_preview
                    else None
                )
                self._safe_emit(
                    McpRequestEvent(
                        timestamp=time.time() * 1000,
                        service=self._service_name,
                        service_version=self._service_version,
                        environment=self._environment,
                        request_id=request_id,
                        request_kind=request_kind,
                        tool_name=metadata.tool_name,
                        resource_uri=metadata.resource_uri,
                        status="ok",
                        latency_ms=latency_ms,
                        tenant_id=metadata.tenant_id,
                        session_id=metadata.session_id,
                        platform=metadata.platform,
                        locale=metadata.locale,
                        user_agent=metadata.user_agent,
                        conversation_id=metadata.conversation_id,
                        args_hash=hash_payload(sanitized_args) if sanitized_args else None,
                        input_bytes=estimate_size(metadata.args),
                        output_bytes=estimate_size(result),
                        sample_payload=sanitized_args if self._capture_payloads else None,
                        args_preview=(truncate_preview(sanitized_args) if sanitized_args else None),
                        result_preview=(
                            truncate_preview(sanitized_result) if sanitized_result else None
                        ),
                        result_hash=(hash_payload(sanitized_result) if sanitized_result else None),
                        user_query_hash=(
                            hash_payload(self._sanitize(metadata.user_query))
                            if metadata.user_query
                            else None
                        ),
                        user_query_preview=(
                            truncate_string(metadata.user_query, 240)
                            if metadata.user_query
                            else None
                        ),
                    )
                )
                return result
            except Exception as error:
                latency_ms = (time.perf_counter() - start) * 1000
                sanitized_args = self._sanitize(metadata.args) if metadata.args else None
                self._safe_emit(
                    McpRequestEvent(
                        timestamp=time.time() * 1000,
                        service=self._service_name,
                        service_version=self._service_version,
                        environment=self._environment,
                        request_id=request_id,
                        request_kind=request_kind,
                        tool_name=metadata.tool_name,
                        resource_uri=metadata.resource_uri,
                        status="error",
                        latency_ms=latency_ms,
                        tenant_id=metadata.tenant_id,
                        session_id=metadata.session_id,
                        platform=metadata.platform,
                        locale=metadata.locale,
                        user_agent=metadata.user_agent,
                        conversation_id=metadata.conversation_id,
                        args_hash=hash_payload(sanitized_args) if sanitized_args else None,
                        input_bytes=estimate_size(metadata.args),
                        error=to_error_message(error),
                    )
                )
                raise

        return wrapped

    def track_tool(
        self,
        tool_name: str,
        context: Callable[..., McpTrackingContext] | None = None,
    ) -> Callable[..., Any]:
        """Decorator for tracking MCP tool invocations.

        Usage with FastMCP:
            @mcp.tool()
            @obs.track_tool("my_tool")
            async def my_tool(query: str) -> str:
                ...
        """

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            @functools.wraps(fn)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                metadata = context(*args, **kwargs) if context else McpTrackingContext()
                metadata.tool_name = tool_name
                if not metadata.args:
                    metadata.args = kwargs if kwargs else (args[0] if args else None)
                request_id = metadata.request_id or str(uuid.uuid4())
                start = time.perf_counter()
                try:
                    result = await fn(*args, **kwargs)
                    latency_ms = (time.perf_counter() - start) * 1000
                    sanitized_args = self._sanitize(metadata.args) if metadata.args else None
                    sanitized_result = (
                        self._sanitize(metadata.result_preview(result))
                        if metadata.result_preview
                        else None
                    )
                    self._safe_emit(
                        McpRequestEvent(
                            timestamp=time.time() * 1000,
                            service=self._service_name,
                            service_version=self._service_version,
                            environment=self._environment,
                            request_id=request_id,
                            request_kind="CallTool",
                            tool_name=tool_name,
                            status="ok",
                            latency_ms=latency_ms,
                            tenant_id=metadata.tenant_id,
                            session_id=metadata.session_id,
                            platform=metadata.platform,
                            locale=metadata.locale,
                            user_agent=metadata.user_agent,
                            conversation_id=metadata.conversation_id,
                            args_hash=hash_payload(sanitized_args) if sanitized_args else None,
                            input_bytes=estimate_size(metadata.args),
                            output_bytes=estimate_size(result),
                            sample_payload=sanitized_args if self._capture_payloads else None,
                            args_preview=(
                                truncate_preview(sanitized_args) if sanitized_args else None
                            ),
                            result_preview=(
                                truncate_preview(sanitized_result) if sanitized_result else None
                            ),
                            result_hash=(
                                hash_payload(sanitized_result) if sanitized_result else None
                            ),
                            user_query_hash=(
                                hash_payload(self._sanitize(metadata.user_query))
                                if metadata.user_query
                                else None
                            ),
                            user_query_preview=(
                                truncate_string(metadata.user_query, 240)
                                if metadata.user_query
                                else None
                            ),
                        )
                    )
                    return result
                except Exception as error:
                    latency_ms = (time.perf_counter() - start) * 1000
                    sanitized_args = self._sanitize(metadata.args) if metadata.args else None
                    self._safe_emit(
                        McpRequestEvent(
                            timestamp=time.time() * 1000,
                            service=self._service_name,
                            service_version=self._service_version,
                            environment=self._environment,
                            request_id=request_id,
                            request_kind="CallTool",
                            tool_name=tool_name,
                            status="error",
                            latency_ms=latency_ms,
                            tenant_id=metadata.tenant_id,
                            session_id=metadata.session_id,
                            platform=metadata.platform,
                            args_hash=hash_payload(sanitized_args) if sanitized_args else None,
                            input_bytes=estimate_size(metadata.args),
                            error=to_error_message(error),
                        )
                    )
                    raise

            return wrapper

        return decorator

    def record_session(
        self,
        action: str,
        session_id: str,
        *,
        platform: str | None = None,
    ) -> None:
        self._safe_emit(
            McpSessionEvent(
                timestamp=time.time() * 1000,
                service=self._service_name,
                service_version=self._service_version,
                environment=self._environment,
                action=action,  # type: ignore[arg-type]
                session_id=session_id,
                platform=platform,
            )
        )

    def record_business_event(
        self,
        name: str,
        *,
        properties: dict[str, Any] | None = None,
        status: EventStatus | None = None,
        category: EventCategory | None = None,
        session_id: str | None = None,
        device_id: str | None = None,
        tenant_id: str | None = None,
    ) -> None:
        self._safe_emit(
            BusinessEvent(
                timestamp=time.time() * 1000,
                service=self._service_name,
                service_version=self._service_version,
                environment=self._environment,
                name=name,
                properties=(self._sanitize(properties) if properties else None),
                status=status,
                category=category,
                session_id=session_id,
                device_id=device_id,
                tenant_id=tenant_id,
            )
        )

    def record_ui_event(
        self,
        name: str,
        *,
        action: str | None = None,
        category: EventCategory | None = None,
        widget_id: str | None = None,
        tool_name: str | None = None,
        session_id: str | None = None,
        device_id: str | None = None,
        tenant_id: str | None = None,
        locale: str | None = None,
        properties: dict[str, Any] | None = None,
    ) -> None:
        self._safe_emit(
            UiEvent(
                timestamp=time.time() * 1000,
                service=self._service_name,
                service_version=self._service_version,
                environment=self._environment,
                name=name,
                action=action,
                category=category,
                widget_id=widget_id,
                tool_name=tool_name,
                session_id=session_id,
                device_id=device_id,
                tenant_id=tenant_id,
                locale=locale,
                properties=(self._sanitize(properties) if properties else None),
            )
        )


def create_mcp_observability(options: ObservabilityOptions) -> McpObservability:
    return McpObservability(options)
