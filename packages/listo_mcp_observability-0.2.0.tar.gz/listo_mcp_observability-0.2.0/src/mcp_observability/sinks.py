from __future__ import annotations

import sys
from collections import deque
from typing import Any, Protocol, runtime_checkable

from mcp_observability._utils import (
    summarize_business_events,
    summarize_by,
    summarize_latency,
    summarize_session_events,
    summarize_ui_events,
)
from mcp_observability.types import (
    BusinessEvent,
    HttpRequestEvent,
    McpRequestEvent,
    McpSessionEvent,
    ObservabilityEvent,
    UiEvent,
)


@runtime_checkable
class EventSink(Protocol):
    def emit(self, event: ObservabilityEvent) -> None: ...


class _CombinedSink:
    """Routes events to multiple sinks with error isolation."""

    def __init__(self, sinks: list[EventSink]) -> None:
        self._sinks = sinks

    def emit(self, event: ObservabilityEvent) -> None:
        for sink in self._sinks:
            try:
                sink.emit(event)
            except Exception as exc:
                print(f"Telemetry sink failed: {exc}", file=sys.stderr)


def combine_sinks(*sinks: EventSink) -> EventSink:
    """Combine multiple sinks into one that routes events to all with error isolation."""
    return _CombinedSink(list(sinks))


class ConsoleSink:
    def __init__(self, *, log_success: bool = False) -> None:
        self._log_success = log_success

    def emit(self, event: ObservabilityEvent) -> None:
        if isinstance(event, HttpRequestEvent):
            if event.status == "ok" and not self._log_success:
                return
            label = f"{event.method} {event.route}"
            msg = (
                f"[telemetry] {label} status={event.status} "
                f"code={event.status_code} latency={event.latency_ms:.1f}ms"
            )
            if event.error:
                msg += f" error={event.error}"
            dest = sys.stderr if event.status == "error" else sys.stdout
            print(msg, file=dest)
            return

        if isinstance(event, McpRequestEvent):
            if event.status == "ok" and not self._log_success:
                return
            tool_suffix = f":{event.tool_name}" if event.tool_name else ""
            label = f"{event.request_kind}{tool_suffix}"
            msg = f"[telemetry] {label} status={event.status} latency={event.latency_ms:.1f}ms"
            if event.error:
                msg += f" error={event.error}"
            dest = sys.stderr if event.status == "error" else sys.stdout
            print(msg, file=dest)
            return

        if isinstance(event, (McpSessionEvent, BusinessEvent)):
            print(f"[telemetry] {event}", file=sys.stdout)


class InMemorySink:
    def __init__(self, *, limit: int = 2000) -> None:
        self._events: deque[ObservabilityEvent] = deque(maxlen=limit)

    def emit(self, event: ObservabilityEvent) -> None:
        self._events.append(event)

    def get_events(self) -> list[ObservabilityEvent]:
        return list(self._events)

    def get_metrics(self) -> dict[str, Any]:
        events = list(self._events)
        http_events = [e for e in events if isinstance(e, HttpRequestEvent)]
        mcp_events = [e for e in events if isinstance(e, McpRequestEvent)]
        session_events = [e for e in events if isinstance(e, McpSessionEvent)]
        ui_events = [e for e in events if isinstance(e, UiEvent)]
        business_events = [e for e in events if isinstance(e, BusinessEvent)]

        return {
            "totals": {
                "events": len(events),
                "http": len(http_events),
                "mcp": len(mcp_events),
                "sessions": len(session_events),
                "ui": len(ui_events),
                "business": len(business_events),
            },
            "http": {
                "overall": summarize_latency(http_events),
                "byRoute": summarize_by(http_events, lambda e: e.route),
            },
            "mcp": {
                "byKind": summarize_by(mcp_events, lambda e: e.request_kind),
                "tools": summarize_by(
                    [e for e in mcp_events if e.request_kind == "CallTool"],
                    lambda e: e.tool_name or "unknown",
                ),
            },
            "sessions": summarize_session_events(session_events),
            "ui": summarize_ui_events(ui_events),
            "business": summarize_business_events(business_events),
        }
