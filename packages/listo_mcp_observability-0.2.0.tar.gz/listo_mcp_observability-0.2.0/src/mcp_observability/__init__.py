from mcp_observability.core import (
    McpObservability,
    ObservabilityOptions,
    create_mcp_observability,
)
from mcp_observability.easy_setup import create_mcp_observability_easy
from mcp_observability.platform import (
    KnownPlatform,
    McpClientInfo,
    Platform,
    PlatformHints,
    detect_platform,
)
from mcp_observability.remote_sink import RemoteSink, RemoteSinkOptions, create_remote_sink
from mcp_observability.sinks import ConsoleSink, EventSink, InMemorySink, combine_sinks
from mcp_observability.types import (
    BusinessEvent,
    EventCategory,
    EventStatus,
    HttpRequestEvent,
    McpRequestEvent,
    McpSessionEvent,
    McpTrackingContext,
    ObservabilityEvent,
    UiEvent,
)

__all__ = [
    "McpObservability",
    "ObservabilityOptions",
    "create_mcp_observability",
    "create_mcp_observability_easy",
    "RemoteSink",
    "RemoteSinkOptions",
    "create_remote_sink",
    "ConsoleSink",
    "EventSink",
    "InMemorySink",
    "combine_sinks",
    "HttpRequestEvent",
    "McpRequestEvent",
    "McpSessionEvent",
    "BusinessEvent",
    "UiEvent",
    "ObservabilityEvent",
    "EventStatus",
    "EventCategory",
    "McpTrackingContext",
    "Platform",
    "KnownPlatform",
    "PlatformHints",
    "McpClientInfo",
    "detect_platform",
    "create_telemetry_routes",
]


def create_telemetry_routes():  # type: ignore[no-untyped-def]
    from mcp_observability.endpoints import create_telemetry_routes as _create

    return _create()
