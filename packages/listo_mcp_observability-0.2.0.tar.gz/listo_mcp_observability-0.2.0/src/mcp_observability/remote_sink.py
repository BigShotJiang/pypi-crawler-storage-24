from __future__ import annotations

import json
import random
import sys
import threading
import time
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any

from mcp_observability.types import ObservabilityEvent

_DEFAULT_HTTP_TIMEOUT = 30  # seconds
_DEFAULT_MAX_BUFFER_SIZE = 10_000


@dataclass
class RemoteSinkOptions:
    endpoint: str
    api_key: str
    batch_size: int = 50
    flush_interval: float = 5.0
    max_retries: int = 3
    max_buffer_size: int = _DEFAULT_MAX_BUFFER_SIZE
    http_timeout: float = _DEFAULT_HTTP_TIMEOUT
    debug: bool = False
    on_error: Callable[[Exception, list[ObservabilityEvent]], None] | None = None


class RemoteSink:
    def __init__(self, options: RemoteSinkOptions) -> None:
        self._endpoint = options.endpoint
        self._api_key = options.api_key
        self._batch_size = options.batch_size
        self._flush_interval = options.flush_interval
        self._max_retries = options.max_retries
        self._max_buffer_size = options.max_buffer_size
        self._http_timeout = options.http_timeout
        self._debug = options.debug
        self._on_error = options.on_error or self._default_on_error
        self._buffer: list[ObservabilityEvent] = []
        self._lock = threading.Lock()
        self._flushing = False
        self._timer: threading.Timer | None = None
        self._start_flush_timer()

    @staticmethod
    def _default_on_error(err: Exception, events: list[ObservabilityEvent]) -> None:
        print(f"[RemoteSink] Error: {err}", file=sys.stderr)

    def emit(self, event: ObservabilityEvent) -> None:
        if self._debug:
            name = getattr(event, "name", "")
            extra = f" name={name}" if name else ""
            print(f"[RemoteSink] Buffering event: type={event.type}{extra}")
        with self._lock:
            self._buffer.append(event)
            if len(self._buffer) > self._max_buffer_size:
                dropped = len(self._buffer) - self._max_buffer_size
                self._buffer = self._buffer[dropped:]
                if self._debug:
                    print(f"[RemoteSink] Buffer full, dropped {dropped} oldest events")
            should_flush = len(self._buffer) >= self._batch_size
        if should_flush:
            self._flush_in_thread()

    def flush(self) -> None:
        with self._lock:
            if not self._buffer or self._flushing:
                return
            self._flushing = True
            events = self._buffer[: self._batch_size]
            self._buffer = self._buffer[self._batch_size :]

        try:
            self._send_batch(events)
        except Exception as exc:
            self._on_error(exc, events)
        finally:
            with self._lock:
                self._flushing = False

    def _transform_event(self, event: ObservabilityEvent) -> dict[str, Any]:
        data = asdict(event)
        ts = data.get("timestamp")
        if isinstance(ts, (int, float)):
            data["timestamp"] = datetime.fromtimestamp(ts / 1000, tz=timezone.utc).isoformat()
        latency = data.get("latency_ms")
        if isinstance(latency, (int, float)):
            data["latencyMs"] = round(latency)
            del data["latency_ms"]
        # Convert snake_case keys to camelCase for API compatibility
        result: dict[str, Any] = self._to_camel_case(data)
        return result

    def _to_camel_case(self, data: Any) -> Any:
        if isinstance(data, dict):
            result: dict[str, Any] = {}
            for key, value in data.items():
                parts = key.split("_")
                camel = parts[0] + "".join(p.capitalize() for p in parts[1:])
                result[camel] = self._to_camel_case(value)
            return result
        if isinstance(data, list):
            return [self._to_camel_case(item) for item in data]
        return data

    def _send_batch(self, events: list[ObservabilityEvent]) -> None:
        transformed = [self._transform_event(e) for e in events]

        if self._debug:
            types = {e.type for e in events}
            print(
                f"[RemoteSink] Sending batch of {len(transformed)} events "
                f"to {self._endpoint}: types={','.join(types)}"
            )

        body = json.dumps({"events": transformed}).encode("utf-8")

        for attempt in range(self._max_retries):
            try:
                req = urllib.request.Request(
                    self._endpoint,
                    data=body,
                    headers={
                        "Content-Type": "application/json",
                        "X-API-Key": self._api_key,
                    },
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=self._http_timeout) as response:
                    if 200 <= response.status < 300:
                        if self._debug:
                            print("[RemoteSink] Batch sent successfully")
                        return
            except urllib.error.HTTPError as e:
                if 400 <= e.code < 500:
                    body_text = e.read().decode("utf-8", errors="replace")
                    raise Exception(f"Client error {e.code}: {body_text}") from e
                if attempt < self._max_retries - 1:
                    time.sleep((2**attempt) + random.uniform(0, 1))
                else:
                    raise
            except Exception:
                if attempt < self._max_retries - 1:
                    time.sleep((2**attempt) + random.uniform(0, 1))
                else:
                    raise

    def _flush_in_thread(self) -> None:
        threading.Thread(target=self.flush, daemon=True).start()

    def _start_flush_timer(self) -> None:
        def tick() -> None:
            self.flush()
            self._start_flush_timer()

        self._timer = threading.Timer(self._flush_interval, tick)
        self._timer.daemon = True
        self._timer.start()

    def destroy(self) -> None:
        if self._timer:
            self._timer.cancel()
            self._timer = None
        self.flush()


def create_remote_sink(options: RemoteSinkOptions) -> RemoteSink:
    return RemoteSink(options)
