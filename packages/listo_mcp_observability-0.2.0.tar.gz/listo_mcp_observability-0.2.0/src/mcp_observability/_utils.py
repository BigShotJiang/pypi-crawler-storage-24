from __future__ import annotations

import hashlib
import json
import math
import random
from collections.abc import Callable, Sequence
from typing import Any

from mcp_observability.types import (
    BusinessEvent,
    HttpRequestEvent,
    McpRequestEvent,
    McpSessionEvent,
    ObservabilityEvent,
    UiEvent,
)


def hash_payload(payload: Any) -> str | None:
    try:
        raw = json.dumps(payload, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode()).hexdigest()
    except Exception:
        return None


def estimate_size(payload: Any) -> int | None:
    try:
        raw = json.dumps(payload, default=str)
        return len(raw.encode("utf-8"))
    except Exception:
        return None


def to_error_message(error: BaseException | Any) -> str:
    if isinstance(error, BaseException):
        return str(error)
    if isinstance(error, str):
        return error
    try:
        return json.dumps(error, default=str)
    except Exception:
        return str(error)


def clamp_sample_rate(rate: float | None) -> float:
    if rate is None or math.isnan(rate):
        return 1.0
    return min(1.0, max(0.0, rate))


def should_sample(event: ObservabilityEvent, sample_rate: float) -> bool:
    if hasattr(event, "status") and getattr(event, "status", None) == "error":
        return True
    if isinstance(event, McpSessionEvent):
        return True
    if sample_rate >= 1.0:
        return True
    return random.random() < sample_rate


def sanitize_payload(payload: Any, redact_keys: set[str], depth: int = 0) -> Any:
    if payload is None:
        return payload
    if depth > 6:
        return "[truncated]"
    if isinstance(payload, list):
        return [sanitize_payload(item, redact_keys, depth + 1) for item in payload[:20]]
    if isinstance(payload, dict):
        output: dict[str, Any] = {}
        for key, value in payload.items():
            if key.lower() in redact_keys:
                output[key] = "[redacted]"
            else:
                output[key] = sanitize_payload(value, redact_keys, depth + 1)
        return output
    return payload


def truncate_string(value: str, max_len: int = 240) -> str:
    if len(value) <= max_len:
        return value
    return value[:max_len] + "\u2026"


def truncate_preview(value: Any) -> Any:
    if isinstance(value, list):
        return [truncate_string(item) if isinstance(item, str) else item for item in value]
    if isinstance(value, dict):
        return {k: truncate_string(v) if isinstance(v, str) else v for k, v in value.items()}
    if isinstance(value, str):
        return truncate_string(value)
    return value


# --- Metrics / analytics helpers ---


def percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    sorted_vals = sorted(values)
    idx = min(len(sorted_vals) - 1, max(0, int((len(sorted_vals) - 1) * p)))
    return sorted_vals[idx]


def summarize_latency(events: Sequence[HttpRequestEvent | McpRequestEvent]) -> dict[str, Any]:
    if not events:
        return {"count": 0, "errors": 0}
    latencies = [e.latency_ms for e in events]
    errors = sum(1 for e in events if e.status == "error")
    total = sum(latencies)
    return {
        "count": len(events),
        "errors": errors,
        "avgMs": total / len(latencies),
        "p50": percentile(latencies, 0.5),
        "p95": percentile(latencies, 0.95),
        "p99": percentile(latencies, 0.99),
    }


def summarize_by(
    events: Sequence[HttpRequestEvent | McpRequestEvent],
    key_fn: Callable[[Any], str],
) -> dict[str, dict[str, Any]]:
    groups: dict[str, list[Any]] = {}
    for event in events:
        key = key_fn(event) or "unknown"
        groups.setdefault(key, []).append(event)
    return {key: summarize_latency(group) for key, group in groups.items()}


def summarize_session_events(events: list[McpSessionEvent]) -> dict[str, int]:
    counts = {"open": 0, "close": 0}
    for event in events:
        counts[event.action] += 1
    return counts


def summarize_ui_events(events: list[UiEvent]) -> dict[str, Any]:
    by_name: dict[str, int] = {}
    by_action: dict[str, int] = {}
    by_widget: dict[str, int] = {}
    by_category: dict[str, int] = {}
    for event in events:
        name_key = event.name or "unknown"
        action_key = event.action or "unspecified"
        widget_key = event.widget_id or "unknown"
        by_name[name_key] = by_name.get(name_key, 0) + 1
        by_action[action_key] = by_action.get(action_key, 0) + 1
        by_widget[widget_key] = by_widget.get(widget_key, 0) + 1
        if event.category:
            by_category[event.category] = by_category.get(event.category, 0) + 1
    return {
        "byName": by_name,
        "byAction": by_action,
        "byWidget": by_widget,
        "byCategory": by_category,
        "total": len(events),
    }


def summarize_business_events(events: list[BusinessEvent]) -> dict[str, Any]:
    by_name: dict[str, dict[str, int]] = {}
    by_category: dict[str, dict[str, int]] = {}
    for event in events:
        key = event.name or "unknown"
        if key not in by_name:
            by_name[key] = {"count": 0, "ok": 0, "error": 0}
        by_name[key]["count"] += 1
        if event.status == "error":
            by_name[key]["error"] += 1
        if event.status == "ok":
            by_name[key]["ok"] += 1
        if event.category:
            if event.category not in by_category:
                by_category[event.category] = {"count": 0, "ok": 0, "error": 0}
            by_category[event.category]["count"] += 1
            if event.status == "error":
                by_category[event.category]["error"] += 1
            if event.status == "ok":
                by_category[event.category]["ok"] += 1
    return {"byName": by_name, "byCategory": by_category}
