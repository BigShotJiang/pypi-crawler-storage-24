from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

KnownPlatform = Literal["claude", "chatgpt", "other"]
Platform = KnownPlatform

_IGNORED_CLIENT_NAMES = frozenset(["unavailable", "unknown", "n/a", "none", ""])


@dataclass
class McpClientInfo:
    name: str
    version: str | None = None


@dataclass
class PlatformHints:
    headers: dict[str, str] | None = field(default=None)
    meta: dict[str, str] | None = field(default=None)
    client_info: McpClientInfo | None = field(default=None)


def detect_platform(hints: PlatformHints | None = None) -> Platform:
    """Detect the AI platform from available hints.

    Three-tier detection, first match wins:
    1. HTTP headers (user-agent, vendor-specific headers)
    2. _meta key prefixes
    3. clientInfo.name exact/prefix match
    Fallback: "other"
    """
    if hints is None:
        return "other"

    # Tier 1: HTTP headers
    if hints.headers:
        lower_headers = {k.lower(): v.lower() for k, v in hints.headers.items()}

        user_agent = lower_headers.get("user-agent", "")
        has_openai_headers = any(k.startswith("x-openai-") for k in lower_headers)
        has_anthropic_headers = any(k.startswith("x-anthropic-") for k in lower_headers)

        if "openai" in user_agent or has_openai_headers:
            return "chatgpt"
        if "claude" in user_agent or "anthropic" in user_agent or has_anthropic_headers:
            return "claude"

    # Tier 2: _meta key prefixes
    if hints.meta:
        for key in hints.meta:
            lower_key = key.lower()
            if lower_key.startswith("openai/"):
                return "chatgpt"
            if lower_key.startswith("anthropic/") or lower_key.startswith("claude/"):
                return "claude"

    # Tier 3: clientInfo.name
    if hints.client_info:
        name = hints.client_info.name.strip().lower()
        if name in _IGNORED_CLIENT_NAMES:
            return "other"
        if name in ("claude-desktop", "claude"):
            return "claude"
        if name == "chatgpt":
            return "chatgpt"
        if name.startswith("claude-"):
            return "claude"

    return "other"
