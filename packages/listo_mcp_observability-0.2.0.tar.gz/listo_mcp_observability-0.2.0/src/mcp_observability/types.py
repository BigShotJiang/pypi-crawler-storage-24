from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Literal

EventStatus = Literal["ok", "error"]

EventCategory = Literal["conversion", "engagement", "impression", "navigation", "system"]


@dataclass
class HttpRequestEvent:
    type: Literal["http_request"] = "http_request"
    timestamp: float = 0.0
    service: str = ""
    service_version: str | None = None
    environment: str | None = None
    request_id: str = ""
    method: str = ""
    path: str = ""
    route: str = ""
    status_code: int = 0
    status: EventStatus = "ok"
    latency_ms: float = 0.0
    tenant_id: str | None = None
    session_id: str | None = None
    bytes_out: int | None = None
    error: str | None = None


@dataclass
class McpRequestEvent:
    type: Literal["mcp_request"] = "mcp_request"
    timestamp: float = 0.0
    service: str = ""
    service_version: str | None = None
    environment: str | None = None
    request_id: str = ""
    request_kind: str = ""
    tool_name: str | None = None
    resource_uri: str | None = None
    status: EventStatus = "ok"
    latency_ms: float = 0.0
    tenant_id: str | None = None
    session_id: str | None = None
    platform: str | None = None
    locale: str | None = None
    user_agent: str | None = None
    args_hash: str | None = None
    input_bytes: int | None = None
    output_bytes: int | None = None
    sample_payload: Any = None
    args_preview: Any = None
    result_preview: Any = None
    result_hash: str | None = None
    conversation_id: str | None = None
    user_query_hash: str | None = None
    user_query_preview: str | None = None
    error: str | None = None


@dataclass
class McpSessionEvent:
    type: Literal["mcp_session"] = "mcp_session"
    timestamp: float = 0.0
    service: str = ""
    service_version: str | None = None
    environment: str | None = None
    action: Literal["open", "close"] = "open"
    session_id: str = ""
    platform: str | None = None


@dataclass
class BusinessEvent:
    type: Literal["business_event"] = "business_event"
    timestamp: float = 0.0
    service: str = ""
    service_version: str | None = None
    environment: str | None = None
    name: str = ""
    status: EventStatus | None = None
    category: EventCategory | None = None
    session_id: str | None = None
    device_id: str | None = None
    tenant_id: str | None = None
    properties: dict[str, Any] | None = None


@dataclass
class UiEvent:
    type: Literal["ui_event"] = "ui_event"
    timestamp: float = 0.0
    service: str = ""
    service_version: str | None = None
    environment: str | None = None
    name: str = ""
    action: str | None = None
    category: EventCategory | None = None
    widget_id: str | None = None
    tool_name: str | None = None
    session_id: str | None = None
    device_id: str | None = None
    tenant_id: str | None = None
    locale: str | None = None
    properties: dict[str, Any] | None = None


ObservabilityEvent = HttpRequestEvent | McpRequestEvent | McpSessionEvent | BusinessEvent | UiEvent


@dataclass
class McpTrackingContext:
    session_id: str | None = None
    platform: str | None = None
    tenant_id: str | None = None
    locale: str | None = None
    user_agent: str | None = None
    request_id: str | None = None
    tool_name: str | None = None
    resource_uri: str | None = None
    args: Any = None
    conversation_id: str | None = None
    user_query: str | None = None
    result_preview: Callable[..., Any] | None = None
