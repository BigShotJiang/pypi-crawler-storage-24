from __future__ import annotations

import html
from dataclasses import asdict
from datetime import datetime
from typing import Any

from mcp_observability.easy_setup import get_observability, get_telemetry_sink

UI_EVENT_FIELDS = {
    "name",
    "action",
    "category",
    "widgetId",
    "toolName",
    "sessionId",
    "deviceId",
    "tenantId",
    "locale",
    "properties",
}

VALID_CATEGORIES = {"conversion", "engagement", "impression", "navigation", "system"}

_MAX_EVENT_BODY_BYTES = 8 * 1024  # 8 KB


def _validate_ui_event_body(body: Any) -> dict[str, Any] | None:
    """Validate and clean a UI event body, returning None if invalid."""
    if not body or not isinstance(body, dict):
        return None
    if not isinstance(body.get("name"), str) or len(body["name"]) == 0:
        return None
    category = body.get("category")
    if category is not None and (not isinstance(category, str) or category not in VALID_CATEGORIES):
        return None
    cleaned: dict[str, Any] = {}
    for key in UI_EVENT_FIELDS:
        if key in body:
            cleaned[key] = body[key]
    return cleaned


# camelCase -> snake_case mapping for UI event fields
_CAMEL_TO_SNAKE = {
    "widgetId": "widget_id",
    "toolName": "tool_name",
    "sessionId": "session_id",
    "deviceId": "device_id",
    "tenantId": "tenant_id",
}


def _record_validated_event(validated: dict[str, Any]) -> None:
    """Record a validated UI event via the global observability instance."""
    observability = get_observability()
    if not observability:
        return
    kwargs: dict[str, Any] = {}
    for key, value in validated.items():
        if key == "name":
            continue
        snake_key = _CAMEL_TO_SNAKE.get(key, key)
        kwargs[snake_key] = value
    observability.record_ui_event(validated["name"], **kwargs)


async def _telemetry_json_handler(request: Any) -> Any:
    """Starlette endpoint for GET /telemetry — returns JSON metrics."""
    from starlette.responses import JSONResponse

    sink = get_telemetry_sink()
    if sink is None:
        return JSONResponse(
            {
                "error": "Local telemetry not enabled",
                "hint": "Set enable_local_dashboard=True in create_mcp_observability_easy",
            },
            status_code=404,
        )

    events = sink.get_events()
    metrics = sink.get_metrics()
    return JSONResponse({"events": [asdict(e) for e in events], "metrics": metrics})


async def _telemetry_dashboard_handler(request: Any) -> Any:
    """Starlette endpoint for GET /telemetry/dashboard — returns HTML dashboard."""
    from starlette.responses import HTMLResponse

    sink = get_telemetry_sink()
    if sink is None:
        return HTMLResponse(
            """<!DOCTYPE html>
<html><head><title>Telemetry</title>
<style>body{font-family:system-ui,sans-serif;padding:20px}.error{color:#d32f2f}</style>
</head><body>
<h1>Telemetry Dashboard</h1>
<p class="error">Local telemetry is not enabled.</p>
<p>Set enable_local_dashboard=True in create_mcp_observability_easy config.</p>
</body></html>""",
            status_code=404,
        )

    metrics = sink.get_metrics()
    totals = metrics["totals"]

    http_rows = ""
    if metrics["http"]["overall"].get("count", 0) > 0:
        for route, stats in metrics["http"]["byRoute"].items():
            err_color = "#d32f2f" if stats.get("errors", 0) > 0 else "#4caf50"
            http_rows += (
                f"<tr><td><code>{html.escape(str(route))}</code></td>"
                f"<td>{int(stats['count'])}</td>"
                f'<td style="color:{err_color}">{int(stats.get("errors", 0))}</td>'
                f"<td>{float(stats.get('avgMs', 0)):.1f}</td>"
                f"<td>{float(stats.get('p95') or 0):.1f}</td>"
                f"<td>{float(stats.get('p99') or 0):.1f}</td></tr>"
            )

    http_section = ""
    if http_rows:
        http_section = f"""<h2>HTTP Performance</h2>
<table><tr><th>Route</th><th>Requests</th><th>Errors</th>
<th>Avg (ms)</th><th>P95 (ms)</th><th>P99 (ms)</th></tr>{http_rows}</table>"""

    mcp_rows = ""
    tools = metrics["mcp"].get("tools", {})
    if tools:
        for tool, stats in tools.items():
            err_color = "#d32f2f" if stats.get("errors", 0) > 0 else "#4caf50"
            mcp_rows += (
                f"<tr><td><code>{html.escape(str(tool))}</code></td>"
                f"<td>{int(stats['count'])}</td>"
                f'<td style="color:{err_color}">{int(stats.get("errors", 0))}</td>'
                f"<td>{float(stats.get('avgMs', 0)):.1f}</td>"
                f"<td>{float(stats.get('p95') or 0):.1f}</td>"
                f"<td>{float(stats.get('p99') or 0):.1f}</td></tr>"
            )

    mcp_section = ""
    if mcp_rows:
        mcp_section = f"""<h2>MCP Tools</h2>
<table><tr><th>Tool</th><th>Calls</th><th>Errors</th>
<th>Avg (ms)</th><th>P95 (ms)</th><th>P99 (ms)</th></tr>{mcp_rows}</table>"""

    now = datetime.now().strftime("%H:%M:%S")
    page = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Telemetry Dashboard</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:system-ui,-apple-system,sans-serif;background:#f5f5f5;color:#333}}
.container{{max-width:1200px;margin:0 auto;padding:20px}}
h1{{font-size:28px;margin-bottom:20px}}
h2{{font-size:18px;margin-top:30px;margin-bottom:10px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:15px;margin-bottom:20px}}
.card{{background:white;border-radius:8px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,0.1)}}
.metric-value{{font-size:32px;font-weight:bold;margin-top:10px}}
.metric-label{{font-size:12px;color:#666;text-transform:uppercase}}
table{{width:100%;border-collapse:collapse;background:white;border-radius:8px;overflow:hidden}}
th,td{{padding:12px;text-align:left}}
th{{background:#f5f5f5;font-weight:600}}
tr:hover{{background:#fafafa}}
.refresh{{margin-bottom:20px}}
button{{padding:10px 15px;background:#1976d2;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px}}
button:hover{{background:#1565c0}}
</style></head>
<body><div class="container">
<div class="refresh">
<button onclick="location.reload()">Refresh</button>
<small style="margin-left:10px;color:#666">Auto-refreshes every 5 seconds</small>
</div>
<h1>Telemetry Dashboard</h1>
<div class="grid">
<div class="card"><div class="metric-label">Total Events</div><div class="metric-value">{int(totals["events"])}</div></div>
<div class="card"><div class="metric-label">HTTP Requests</div><div class="metric-value">{int(totals["http"])}</div></div>
<div class="card"><div class="metric-label">MCP Requests</div><div class="metric-value">{int(totals["mcp"])}</div></div>
<div class="card"><div class="metric-label">Sessions</div><div class="metric-value">{int(totals["sessions"])}</div></div>
</div>
{http_section}
{mcp_section}
<p style="margin-top:40px;color:#999;font-size:12px">
Last updated: {now}
</p>
</div>
<script>setTimeout(()=>location.reload(),5000)</script>
</body></html>"""

    return HTMLResponse(page)


async def _telemetry_event_handler(request: Any) -> Any:
    """Starlette endpoint for POST /telemetry/event — ingest UI events."""
    import json
    import sys

    from starlette.responses import JSONResponse

    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > _MAX_EVENT_BODY_BYTES:
        return JSONResponse({"error": "Payload too large"}, status_code=413)

    try:
        body = await request.body()
        if len(body) > _MAX_EVENT_BODY_BYTES:
            return JSONResponse({"error": "Payload too large"}, status_code=413)
        data = json.loads(body)
    except Exception as exc:
        print(f"[telemetry] Failed to parse event body: {exc}", file=sys.stderr)
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    validated = _validate_ui_event_body(data)
    if not validated:
        return JSONResponse({"error": 'Invalid event: "name" string required'}, status_code=400)

    _record_validated_event(validated)
    return JSONResponse({"ok": True}, status_code=201)


async def _telemetry_events_handler(request: Any) -> Any:
    """Starlette endpoint for POST /telemetry/events — batch UI event ingestion."""
    import json
    import sys

    from starlette.responses import JSONResponse

    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > _MAX_EVENT_BODY_BYTES * 100:
        return JSONResponse({"error": "Payload too large"}, status_code=413)

    try:
        body = await request.body()
        data = json.loads(body)
    except Exception as exc:
        print(f"[telemetry] Failed to parse batch body: {exc}", file=sys.stderr)
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    if not isinstance(data, dict) or not isinstance(data.get("events"), list):
        return JSONResponse({"error": "Expected { events: [...] } array"}, status_code=400)

    events = data["events"]
    if len(events) > 100:
        return JSONResponse({"error": "Maximum 100 events per batch"}, status_code=400)

    accepted = 0
    rejected = 0
    for raw in events:
        validated = _validate_ui_event_body(raw)
        if validated:
            _record_validated_event(validated)
            accepted += 1
        else:
            rejected += 1

    return JSONResponse({"ok": True, "accepted": accepted, "rejected": rejected}, status_code=201)


def create_telemetry_routes() -> list[Any]:
    """Create Starlette routes for the telemetry dashboard.

    Usage:
        from starlette.routing import Mount
        from mcp_observability import create_telemetry_routes

        routes = [
            Mount("/", routes=create_telemetry_routes()),
            ...
        ]
    """
    try:
        from starlette.routing import Route
    except ImportError as exc:
        raise ImportError(
            "starlette is required for dashboard endpoints. "
            "Install it with: pip install listo-mcp-observability[starlette]"
        ) from exc

    return [
        Route("/telemetry", endpoint=_telemetry_json_handler, methods=["GET"]),
        Route("/telemetry/dashboard", endpoint=_telemetry_dashboard_handler, methods=["GET"]),
        Route("/telemetry/event", endpoint=_telemetry_event_handler, methods=["POST"]),
        Route("/telemetry/events", endpoint=_telemetry_events_handler, methods=["POST"]),
    ]
