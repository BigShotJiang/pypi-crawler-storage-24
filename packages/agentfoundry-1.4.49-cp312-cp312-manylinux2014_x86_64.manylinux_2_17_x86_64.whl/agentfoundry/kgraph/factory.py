"""
Singleton factory class to manage kgraph provider instances.
"""

from __future__ import annotations

import inspect
import logging
import threading
from typing import Any, Dict, Optional

from agentfoundry.kgraph.base import KGraphBase

try:
    from agentfoundry.utils.module_config import get_module_config
except ImportError:
    get_module_config = lambda: None  # noqa: E731

logger = logging.getLogger(__name__)


_REDACT_CACHE_KEYS = {
    "ssh_key_passphrase",
    "secret_access_key",
    "session_token",
    "aws_secret_access_key",
    "aws_session_token",
    "token",
    "password",
}


def _build_cache_key(backend: str, kwargs: Dict[str, Any]) -> str:
    cache_key = backend.lower()
    if not kwargs:
        return cache_key
    parts: list[str] = []
    for key in sorted(kwargs):
        value = kwargs[key]
        if key == "config":
            parts.append(f"{key}=org:{getattr(value, 'org_id', '')}")
        elif key in _REDACT_CACHE_KEYS:
            parts.append(f"{key}=********")
        else:
            parts.append(f"{key}={value}")
    return f"{cache_key}|{'|'.join(parts)}"


def _get_override(override: Dict[str, Any], dotted_key: str, default: Any = None) -> Any:
    underscored_key = dotted_key.replace(".", "_")
    return override.get(dotted_key, override.get(underscored_key, default))


def _as_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on")


def _secret_value(value: Any) -> Any:
    if hasattr(value, "get_secret_value"):
        try:
            return value.get_secret_value()
        except Exception:
            return value
    return value


class KGraphFactory:
    """Singleton registry-backed factory for KGraph providers."""

    _instance: Optional["KGraphFactory"] = None
    _instance_lock = threading.Lock()
    _registry: dict[str, type] = {}
    _cache: dict[str, KGraphBase] = {}
    _lock = threading.Lock()

    def __init__(self):
        logger.debug("KGraphFactory initialized.")

    @classmethod
    def get_instance(cls) -> "KGraphFactory":
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def register_provider(cls, name: str):
        def decorator(provider_cls):
            if not isinstance(provider_cls, type):
                raise TypeError(f"Expected a class (type), got {type(provider_cls).__name__}")
            if inspect.isabstract(provider_cls):
                logger.warning("Skipping registration of abstract KGraph provider class: %s", provider_cls.__name__)
                return provider_cls
            lower = name.lower()
            if lower in cls._registry:
                logger.warning("KGraph provider '%s' already registered; skipping duplicate", name)
                return provider_cls
            cls._registry[lower] = provider_cls
            logger.debug("Registered KGraph provider '%s' -> %s", lower, provider_cls)
            return provider_cls

        return decorator

    @classmethod
    def get_provider_cls(cls, name: str):
        return cls._registry.get(name.lower())

    @classmethod
    def _lazy_import_provider(cls, name: str) -> None:
        from importlib import import_module as _import_module

        mod_name = f"agentfoundry.kgraph.providers.{name.lower()}_provider"
        try:
            _import_module(mod_name)
            logger.info("Lazy-imported KGraph provider module '%s'", mod_name)
        except ModuleNotFoundError as err:
            logger.warning("KGraph provider module '%s' not found: %s", mod_name, err)
        except Exception as err:
            logger.warning("KGraph provider module '%s' failed to import: %s", mod_name, err, exc_info=True)

    @classmethod
    def available_providers(cls):
        return list(cls._registry.keys())

    @staticmethod
    def _resolve_agent_config(config_override: Dict[str, Any] | None):
        if config_override and config_override.get("AGENT_CONFIG") is not None:
            return config_override["AGENT_CONFIG"]
        return get_module_config()

    @staticmethod
    def _resolve_backend(config_override: Dict[str, Any] | None, agent_config) -> str:
        if config_override:
            override_backend = _get_override(config_override, "KGRAPH.BACKEND")
            if override_backend:
                return str(override_backend).lower()
        if agent_config is not None:
            backend = getattr(getattr(agent_config, "kgraph", None), "backend", None)
            if backend:
                return str(backend).lower()
            extra_backend = getattr(agent_config, "extra", {}).get("kgraph_backend")
            if extra_backend:
                return str(extra_backend).lower()
        return "duckdb_sqlite"

    @staticmethod
    def _provider_kwargs(backend: str, config_override: Dict[str, Any] | None, agent_config) -> Dict[str, Any]:
        override = config_override or {}
        kwargs: Dict[str, Any] = {}
        if agent_config is not None:
            kwargs["config"] = agent_config

        if backend == "duckdb_sqlite":
            persist_path = _get_override(override, "DATA_DIR")
            if persist_path is None and agent_config is not None and getattr(agent_config, "data_dir", None):
                persist_path = str(agent_config.data_dir)
            kwargs["persist_path"] = persist_path or "./data"
            return kwargs

        if backend == "neptune":
            neptune_cfg = getattr(getattr(agent_config, "kgraph", None), "neptune", None)
            kwargs["endpoint"] = _get_override(override, "NEPTUNE.ENDPOINT") or getattr(neptune_cfg, "endpoint", None)
            kwargs["reader_endpoint"] = _get_override(override, "NEPTUNE.READER_ENDPOINT") or getattr(neptune_cfg, "reader_endpoint", None)
            kwargs["region"] = _get_override(override, "NEPTUNE.REGION") or getattr(neptune_cfg, "region", None)
            kwargs["port"] = int(_get_override(override, "NEPTUNE.PORT", getattr(neptune_cfg, "port", 8182)))
            kwargs["use_https"] = _as_bool(
                _get_override(override, "NEPTUNE.USE_HTTPS"),
                getattr(neptune_cfg, "use_https", True),
            )
            kwargs["iam_auth"] = _as_bool(
                _get_override(override, "NEPTUNE.IAM_AUTH"),
                getattr(neptune_cfg, "iam_auth", True),
            )
            kwargs["query_language"] = _get_override(
                override,
                "NEPTUNE.QUERY_LANGUAGE",
                getattr(neptune_cfg, "query_language", "opencypher"),
            )
            kwargs["timeout"] = float(_get_override(override, "NEPTUNE.TIMEOUT", getattr(neptune_cfg, "timeout", 10.0)))
            kwargs["use_ssh_tunnel"] = _as_bool(
                _get_override(override, "NEPTUNE.USE_SSH_TUNNEL"),
                getattr(neptune_cfg, "use_ssh_tunnel", False),
            )
            kwargs["ssh_host"] = _get_override(override, "NEPTUNE.SSH_HOST") or getattr(neptune_cfg, "ssh_host", None)
            kwargs["ssh_user"] = _get_override(override, "NEPTUNE.SSH_USER") or getattr(neptune_cfg, "ssh_user", None)
            kwargs["ssh_key_path"] = _get_override(override, "NEPTUNE.SSH_KEY_PATH") or getattr(neptune_cfg, "ssh_key_path", None)
            kwargs["ssh_key_passphrase"] = _secret_value(
                _get_override(override, "NEPTUNE.SSH_KEY_PASSPHRASE")
                or getattr(neptune_cfg, "ssh_key_passphrase", None)
            )
            aws_cfg = getattr(agent_config, "aws", None)
            kwargs["aws_access_key_id"] = _get_override(override, "AWS.ACCESS_KEY_ID") or getattr(aws_cfg, "access_key_id", None)
            kwargs["aws_secret_access_key"] = _secret_value(
                _get_override(override, "AWS.SECRET_ACCESS_KEY")
                or getattr(aws_cfg, "secret_access_key", None)
            )
            kwargs["aws_session_token"] = _secret_value(
                _get_override(override, "AWS.SESSION_TOKEN")
                or getattr(aws_cfg, "session_token", None)
            )
            kwargs["aws_profile"] = _get_override(override, "AWS.PROFILE") or getattr(aws_cfg, "profile", None)
            return kwargs

        return kwargs

    def get_kgraph(self, config_override: Dict[str, Any] | None = None) -> KGraphBase:
        agent_config = self._resolve_agent_config(config_override)
        backend = self._resolve_backend(config_override, agent_config)

        provider_cls = self.get_provider_cls(backend)
        if provider_cls is None:
            self._lazy_import_provider(backend)
            provider_cls = self.get_provider_cls(backend)
        if provider_cls is None:
            raise ValueError(f"Unknown kgraph backend '{backend}'. Available providers: {self.available_providers()}")

        kwargs = self._provider_kwargs(backend, config_override, agent_config)
        cache_key = _build_cache_key(backend, kwargs)

        if cache_key not in self._cache:
            with self._lock:
                if cache_key not in self._cache:
                    logger.info("Instantiating KGraph provider backend=%s cache_key=%s", backend, cache_key)
                    self._cache[cache_key] = provider_cls(**kwargs)
        return self._cache[cache_key]

    @classmethod
    def reset(cls) -> None:
        with cls._lock:
            cls._cache.clear()
        logger.info("KGraphFactory: cleared all cached providers")

    @classmethod
    def reset_provider(cls, name: str) -> None:
        lower = name.lower()
        with cls._lock:
            keys = [k for k in cls._cache if k == lower or k.startswith(f"{lower}|")]
            for key in keys:
                del cls._cache[key]
        logger.info("KGraphFactory: cleared %d cached instance(s) for backend '%s'", len(keys), lower)


def get_graph(config_override: Dict[str, Any] | None = None) -> KGraphBase:
    return KGraphFactory.get_instance().get_kgraph(config_override=config_override)


from importlib import import_module as _import_module  # noqa: E402

for _mod in (
    "agentfoundry.kgraph.providers.duckdb_sqlite_provider",
    "agentfoundry.kgraph.providers.neptune_provider",
):
    try:
        _import_module(_mod)
    except ModuleNotFoundError as err:
        logger.warning("Optional KGraph provider '%s' could not be imported: %s", _mod, err)
    except Exception as err:
        logger.warning("Optional KGraph provider '%s' failed to import: %s", _mod, err, exc_info=True)
