"""
Pure-Python fallback for AgentFoundry license verification.

This mirrors the logic in ``_license_core.pyx`` so that development and
non-compiled environments can import and validate licenses without requiring
the Cython-built extension.
"""

from __future__ import annotations

import base64
import json
import os
import platform
import uuid
from binascii import unhexlify
from datetime import datetime
import hashlib
import hmac

from agentfoundry.crypto.factory import PQCFactory

# Must match the value embedded in the Cython module and packaged public key.
EXPECTED_PUBKEY_SHA256_HEX = "84a8c887c9e7f87a87ce8043d7e612771864ad56434da62a2c8c8605702771d5"
_EXPECTED_PUBKEY_SHA256 = unhexlify(EXPECTED_PUBKEY_SHA256_HEX)


def _load_license_json(license_path: str) -> dict:
    with open(license_path, "r", encoding="utf-8") as fp:
        return json.load(fp)


def _resolve_public_key_bytes(public_key_path: str) -> bytes:
    with open(public_key_path, "rb") as fp:
        data = fp.read()
    digest = hashlib.sha256(data).digest()
    if not hmac.compare_digest(digest, _EXPECTED_PUBKEY_SHA256):
        raise RuntimeError("Public key integrity check failed — unexpected fingerprint.")
    return data


def _current_machine_id() -> str:
    return f"{uuid.getnode()}{platform.node()}"


def validate_license(license_path: str, public_key_path: str, client_private_key_path: str = None, enforce_machine: bool = True) -> tuple[bool, bytes]:
    """
    Validate the license at ``license_path`` with ``public_key_path`` (vendor Dilithium public key).
    Decrypt the decryption key using ``client_private_key_path`` (client Kyber private key).

    Returns ``(True, decryption_key_bytes)`` if validation succeeds; raises
    ``FileNotFoundError`` or ``RuntimeError`` on failure.
    """
    if not os.path.exists(license_path):
        raise FileNotFoundError(f"License file not found: {license_path}")
    if not os.path.exists(public_key_path):
        raise FileNotFoundError(f"Public key file not found: {public_key_path}")

    provider = PQCFactory.get_provider("kyber")

    license_data = _load_license_json(license_path)
    content = license_data.get("content")
    signature_b64 = license_data.get("signature")
    if not isinstance(content, dict) or not signature_b64:
        raise RuntimeError("Invalid license format: missing content or signature")

    try:
        signature = base64.b64decode(signature_b64, validate=True)
    except Exception as exc:
        raise RuntimeError("Invalid license signature encoding") from exc

    public_key_bytes = _resolve_public_key_bytes(public_key_path)

    content_str = json.dumps(content, sort_keys=True).encode()
    try:
        is_valid = provider.verify(content_str, signature, public_key_bytes)
    except Exception as exc:
        raise RuntimeError(
            "License verification failed due to a PQC runtime error. "
            f"{exc}"
        ) from exc
    if not is_valid:
        raise RuntimeError("Invalid, tampered, or expired AgentFoundry license.")

    expiry = content.get("expiry")
    if not expiry:
        raise RuntimeError("License missing expiry field")
    try:
        exp_date = datetime.strptime(expiry, "%Y-%m-%d").date()
    except Exception as exc:
        raise RuntimeError("Invalid license expiry value") from exc
    if datetime.today().date() > exp_date:
        raise RuntimeError("AgentFoundry license has expired")

    lic_machine = content.get("machine_id")
    if enforce_machine and lic_machine not in (None, "", "*", "any", "unbound"):
        current_mid = _current_machine_id()
        if lic_machine != current_mid:
            raise RuntimeError("AgentFoundry license is not valid for this machine")

    decrypt_b64 = content.get("decryption_key")
    if not decrypt_b64:
        raise RuntimeError("License missing decryption key")

    try:
        encrypted_key_bytes = base64.b64decode(decrypt_b64, validate=True)
    except Exception as exc:
        raise RuntimeError("Invalid decryption key encoding") from exc

    key_bytes = b""
    if client_private_key_path and os.path.exists(client_private_key_path):
        with open(client_private_key_path, "rb") as fp:
            client_priv = fp.read()
        try:
            key_bytes = provider.decrypt(encrypted_key_bytes, client_priv)
        except Exception as exc:
            raise RuntimeError("Failed to decrypt the license payload. Is the client Kyber private key correct?") from exc
    else:
        # If no client private key provided, we can't decrypt it, but the license is valid.
        pass

    return True, key_bytes


def current_machine_id() -> bytes:
    """Expose the machine identifier used for machine binding (bytes)."""
    return _current_machine_id().encode()
