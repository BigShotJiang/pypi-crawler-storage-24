import logging
from collections.abc import Callable, Iterable
from dataclasses import dataclass

import numpy as np
from PyQt6.QtCore import Qt
from PyQt6.QtCore import pyqtSlot as Slot
from PyQt6.QtWidgets import QFormLayout, QLabel, QWidget
from typing_extensions import override

from ert.config import ErrorInfo
from ert.gui.ertnotifier import ErtNotifier
from ert.gui.ertwidgets import (
    ActiveRealizationsModel,
    CopyableLabel,
    EnsembleSelector,
    StringBox,
    Suggestor,
)
from ert.gui.experiments.experiment_config_panel import ExperimentConfigPanel
from ert.mode_definitions import EVALUATE_ENSEMBLE_MODE
from ert.run_models.evaluate_ensemble import EvaluateEnsemble
from ert.storage import Ensemble, RealizationStorageState
from ert.validation import EnsembleRealizationsArgument

logger = logging.getLogger(__name__)


@dataclass
class Arguments:
    mode: str
    realizations: str
    ensemble_id: str


class EvaluateEnsemblePanel(ExperimentConfigPanel):
    def __init__(self, run_path: str, notifier: ErtNotifier) -> None:
        self.notifier = notifier
        super().__init__(EvaluateEnsemble)
        self.setObjectName("Evaluate_parameters_panel")

        layout = QFormLayout()
        lab = QLabel(" ".join(EvaluateEnsemble.__doc__.split()))  # type: ignore
        lab.setWordWrap(True)
        lab.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addRow(lab)

        def show_only_no_children_filter(
            ensembles: Iterable[Ensemble],
        ) -> Iterable[Ensemble]:
            parents = [
                ens.parent for ens in self.notifier.storage.ensembles if ens.parent
            ]
            return (ensemble for ensemble in ensembles if ensemble.id not in parents)

        # Filter out any ensembles which have children.
        # One use case is if a user wants to rerun because of failures
        # not related to parameterization. We can allow that, but only
        # if the ensemble has not been used in an update, as that would
        # invalidate the result
        filters: list[Callable[[Iterable[Ensemble]], Iterable[Ensemble]]] = [
            show_only_no_children_filter
        ]
        self._ensemble_selector = EnsembleSelector(notifier, filters=filters)
        layout.addRow("Ensemble:", self._ensemble_selector)
        runpath_label = CopyableLabel(text=run_path)
        layout.addRow("Runpath:", runpath_label)

        ensemble_size = 0
        if self._ensemble_selector.selected_ensemble:
            ensemble_size = self._ensemble_selector.selected_ensemble.ensemble_size

        self._number_of_realizations_label = QLabel(f"<b>{ensemble_size}</b>")
        layout.addRow(
            QLabel("Number of realizations:"), self._number_of_realizations_label
        )

        self._active_realizations_field = StringBox(
            ActiveRealizationsModel(ensemble_size, show_default=False),  # type: ignore
            continuous_update=True,
        )
        self._realizations_validator = EnsembleRealizationsArgument(
            lambda: self._ensemble_selector.selected_ensemble,
            required_realization_storage_states=[
                RealizationStorageState.PARAMETERS_LOADED
            ],
        )
        self._active_realizations_field.setValidator(self._realizations_validator)
        self._realizations_from_fs()
        layout.addRow("Active realizations", self._active_realizations_field)

        self.setLayout(layout)

        self._active_realizations_field.getValidationSupport().validationChanged.connect(
            self.experiment_configuration_changed
        )
        self._ensemble_selector.ensemble_populated.connect(self._realizations_from_fs)
        self._ensemble_selector.ensemble_populated.connect(
            self.experiment_configuration_changed
        )
        self._ensemble_selector.currentIndexChanged.connect(self._realizations_from_fs)

    @override
    def isConfigurationValid(self) -> bool:
        return (
            self._active_realizations_field.isValid()
            and self._ensemble_selector.currentIndex() != -1
        )

    @override
    def get_experiment_arguments(self) -> Arguments:
        assert self._ensemble_selector.selected_ensemble is not None
        return Arguments(
            mode=EVALUATE_ENSEMBLE_MODE,
            ensemble_id=str(self._ensemble_selector.selected_ensemble.id),
            realizations=self._active_realizations_field.text(),
        )

    def _realizations_from_fs(self) -> None:
        ensemble = self._ensemble_selector.selected_ensemble
        self._active_realizations_field.setEnabled(ensemble is not None)
        try:
            if ensemble:
                parameters = ensemble.get_realization_mask_with_parameters()
                missing_responses = ~ensemble.get_realization_mask_with_responses()
                failures = ~ensemble.get_realization_mask_without_failure()
                mask = np.logical_and(
                    parameters, np.logical_or(missing_responses, failures)
                )
                if not any(mask):
                    mask = parameters
                self._active_realizations_field.model.setValueFromMask(mask)  # type: ignore
                self._number_of_realizations_label.setText(
                    f"<b>{ensemble.ensemble_size}</b>"
                )
        except OSError as err:
            logger.error(str(err))
            Suggestor(
                errors=[ErrorInfo(str(err))],
                widget_info='<p style="font-size: 28px;">Error reading storage</p>',
                parent=self,
            ).show()

    @override
    @Slot(QWidget)
    def experimentTypeChanged(self, w: QWidget) -> None:
        if isinstance(w, EvaluateEnsemblePanel):
            self._realizations_from_fs()
