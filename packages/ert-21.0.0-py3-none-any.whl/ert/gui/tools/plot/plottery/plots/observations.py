from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from pandas import DataFrame

    from ert.gui.tools.plot.plottery import PlotConfig, PlotContext


def plotObservations(
    observation_data: DataFrame, plot_context: PlotContext, axes: Axes
) -> None:
    key = plot_context.key()
    config = plot_context.plotConfig()
    ensemble_list = plot_context.ensembles()

    if (
        config.isObservationsEnabled()
        and len(ensemble_list) > 0
        and observation_data is not None
        and not observation_data.empty
    ):
        _plotObservations(axes, config, observation_data, value_column=key)


def _plotObservations(
    axes: Axes,
    plot_config: PlotConfig,
    data: DataFrame,
    value_column: str,
) -> None:
    """
    Observations are always plotted on top. z-order set to 1000

    Since it is not possible to apply different linestyles to the errorbar, the
    line_style / fmt is used to toggle visibility of the solid errorbar, by
    using the elinewidth parameter.
    """

    style = plot_config.observationsStyle()

    # adjusting the top and bottom bar, according to the line width/thickness
    def cap_size(line_with: float) -> float:
        return 0 if line_with == 0 else math.log(line_with, 1.2) + 3

    # line style set to 'off' toggles errorbar visibility
    if not style.line_style:
        style.width = 0

    if plot_config.flip_response_axis:
        errorbar_data = {
            "x": data.loc["OBS"].to_numpy(),
            "y": data.loc["key_index"].to_numpy(),
            "xerr": data.loc["STD"].to_numpy(),
        }
        axes.yaxis.set_inverted(True)
    elif plot_config.flip_observation_axis:
        errorbar_data = {
            "x": np.array(
                [np.datetime64(time) for time in data.loc["key_index"].to_list()]
            ),
            "y": data.loc["OBS"].to_numpy(),
            "xerr": np.array(
                [np.timedelta64(int(time), "h") for time in data.loc["STD"].to_list()]
            ),
        }
    else:
        errorbar_data = {
            "x": data.loc["key_index"].to_numpy(),
            "y": data.loc["OBS"].to_numpy(),
            "yerr": data.loc["STD"].to_numpy(),
        }

    axes.errorbar(
        **errorbar_data,
        fmt=style.line_style,
        ecolor=style.color,
        color=style.color,
        capsize=cap_size(style.width),
        capthick=style.width,  # same as width/thickness on error line
        alpha=style.alpha,
        linewidth=0,
        marker=style.marker,
        ms=style.size,
        elinewidth=style.width,
        zorder=1000,
    )
