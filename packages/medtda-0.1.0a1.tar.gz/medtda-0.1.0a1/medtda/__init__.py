"""
Med-TDA: Medical Imaging Topological Data Analysis

Extract TDA-based features from medical images (2D, 3D, and 4D) for machine learning 
applications in medical imaging.

Supported Formats
-----------------
- 2D images: PNG, JPG, JPEG, TIFF
- 3D/4D images: NIfTI (.nii, .nii.gz), NRRD (.nrrd), MHA (.mha), MHD (.mhd)

Main modules:
- ph_computer: Persistent homology computation
- vectorizers: Vectorization methods for persistence diagrams
- utils: Helper functions

Main classes:
- FeatureExtractor: Extract vectorized TDA features from medical images
- BarcodeExtractor: Extract raw persistence barcodes
- Preprocessor: Standalone image preprocessing

Example:
    >>> from medtda.ph_computer import compute_ph
    >>> from medtda.vectorizers import persistence_stats
    >>> import numpy as np
    >>> image = np.random.rand(50, 50)
    >>> ph_array, diagrams = compute_ph(image, maxdim=1)
    >>> features = persistence_stats(diagrams[1])
"""

from .__version__ import __version__, __author__, __license__

# Core modules available for import
from . import ph_computer
from . import vectorizers
from . import base
from . import utils
from . import loaders
from . import preprocessor
from . import barcodeextractor
from . import featureextractor
from . import plotting

# Import main classes
from .preprocessor import Preprocessor
from .barcodeextractor import BarcodeExtractor
from .featureextractor import FeatureExtractor

# Import main plotting functions
from .plotting import (
    plot_persistence_diagram,
    plot_barcode,
    plot_betti_curve,
    plot_landscape,
    plot_entropy_summary,
    plot_lifespan,
    plot_silhouette,
    plot_tropical_coordinates,
)

__all__ = [
    '__version__',
    '__author__',
    '__license__',
    'ph_computer',
    'vectorizers',
    'base',
    'utils',
    'loaders',
    'preprocessor',
    'barcodeextractor',
    'featureextractor',
    'plotting',
    'Preprocessor',
    'BarcodeExtractor',
    'FeatureExtractor',
    'plot_persistence_diagram',
    'plot_barcode',
    'plot_betti_curve',
    'plot_landscape',
    'plot_entropy_summary',
    'plot_lifespan',
    'plot_silhouette',
    'plot_tropical_coordinates',
]
