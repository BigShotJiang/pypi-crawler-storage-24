"""
Entry point for running MedTDA as a module: python -m medtda
"""
from medtda.cli import main

if __name__ == '__main__':
    main()
