# Med-TDA version information
__version__ = "0.1.0a1"
__author__ = "Dashti Ali"
__license__ = "MIT"
