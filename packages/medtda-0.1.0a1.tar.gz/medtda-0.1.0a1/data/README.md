# Sample Data

This folder holds small sample files used by the tutorial notebook
(`tutorials/medtda_tutorial.ipynb`).

## Folder structure

```
data/
├── 3d/
│   ├── scan.nii.gz      ← 3D medical image (NIfTI)
│   └── mask.nii.gz      ← Corresponding segmentation mask (NIfTI)
└── 2d/
    └── image.jpg        ← 2D grayscale image (JPEG/PNG)
```

## File requirements

| File | Format | Notes |
|------|--------|-------|
| `3d/scan.nii.gz` | NIfTI (.nii / .nii.gz) | Any 3D volumetric image (CT, MRI, etc.) |
| `3d/mask.nii.gz` | NIfTI (.nii / .nii.gz) | Binary or label mask; same spatial dimensions as scan |
| `2d/image.jpg` | JPEG or PNG | Grayscale or RGB image; will be converted to grayscale internally |

## Sample Data Sources

The sample files used in the tutorial were taken from the following publicly available datasets:

**3D sample — MCT-LTDiag Dataset**
Wu, X., Su, H., Hua, Y., Xu, Y., Wang, L., Wang, X., Wang, S., Jin, B., Liu, X., Wan, X., Sun, Q., Wang, X., & Du, S. (2025). MCT-LTDIAG [Dataset]. Harvard Dataverse. https://doi.org/10.7910/dvn/s3rw15

**2D sample — BUSI Dataset**
Al-Dhabyani, W., Gomaa, M., Khaled, H., & Fahmy, A. (2020). Dataset of breast ultrasound images. *Data in Brief*, 28, 104863. https://doi.org/10.1016/j.dib.2019.104863

## Notes

- Keep files small (< 10 MB each) to stay within GitHub file size limits.
  For larger datasets, consider using [Git LFS](https://git-lfs.github.com/).
- These files are **not** included in the repository by default.
  Add your own sample files following the naming convention above,
  or edit the path variables at the top of each notebook section.
- Supported 3D formats: `.nii`, `.nii.gz`, `.nrrd`, `.mha`, `.mhd`
  (anything readable by SimpleITK).
- Supported 2D formats: `.jpg`, `.jpeg`, `.png`, `.tif`, `.tiff`
  (anything readable by `matplotlib.pyplot.imread`).
