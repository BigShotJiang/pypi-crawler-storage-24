"""
Tests for base module.
"""

import pytest
import numpy as np
from medtda.base import validate_barcode, get_background_value


class TestValidateBarcode:
    """Tests for validate_barcode function."""

    def test_valid_barcode(self):
        """Test validation of valid barcode."""
        barcode = np.array([[0.0, 1.0], [0.5, 2.0]])
        result = validate_barcode(barcode)
        np.testing.assert_array_equal(result, barcode)

    def test_empty_barcode(self):
        """Test validation of empty barcode."""
        barcode = np.array([]).reshape(0, 2)
        result = validate_barcode(barcode)
        assert result.shape == (0, 2)

    def test_none_barcode(self):
        """Test validation of None barcode."""
        result = validate_barcode(None)
        assert result.shape == (0, 2)

    def test_invalid_dimensions_raises_error(self):
        """Test that 1D array raises ValueError."""
        barcode = np.array([1, 2, 3])
        with pytest.raises(ValueError, match="must be 2D array"):
            validate_barcode(barcode)

    def test_invalid_columns_raises_error(self):
        """Test that array with wrong number of columns raises ValueError."""
        barcode = np.array([[1, 2, 3], [4, 5, 6]])
        with pytest.raises(ValueError, match="must have 2 columns"):
            validate_barcode(barcode)

    def test_invalid_birth_death_raises_error(self):
        """Test that death < birth raises ValueError."""
        barcode = np.array([[1.0, 0.5], [2.0, 1.0]])  # death < birth
        with pytest.raises(ValueError, match="death values must be >= birth"):
            validate_barcode(barcode)


class TestGetBackgroundValue:
    """Tests for get_background_value function."""

    def test_normalized_image(self):
        """Test background value for normalized image."""
        image = np.random.rand(50, 50)
        result = get_background_value(image, normalize=True)
        assert result == -1

    def test_2d_unnormalized_image(self):
        """Test background value for 2D unnormalized image."""
        image = np.random.rand(50, 50)
        result = get_background_value(image, normalize=False)
        assert result == 0

    def test_3d_unnormalized_image(self):
        """Test background value for 3D unnormalized image."""
        image = np.random.rand(20, 20, 20)
        result = get_background_value(image, normalize=False)
        assert result == -3000

    def test_4d_unnormalized_image(self):
        """Test background value for 4D unnormalized image."""
        image = np.random.rand(10, 10, 10, 3)
        result = get_background_value(image, normalize=False)
        assert result == -3000
