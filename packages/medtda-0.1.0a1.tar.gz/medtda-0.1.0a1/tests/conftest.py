"""
Pytest fixtures and configuration for MedTDA tests
"""

import pytest
import numpy as np
import os
from pathlib import Path


@pytest.fixture
def test_data_dir():
    """Return the path to the test data directory"""
    return Path(__file__).parent / 'data'


@pytest.fixture
def sample_2d_image():
    """Create a simple 2D test image"""
    return np.random.rand(50, 50).astype(np.float32)


@pytest.fixture
def sample_3d_image():
    """Create a simple 3D test image"""
    return np.random.rand(20, 20, 20).astype(np.float32)


@pytest.fixture
def sample_2d_mask():
    """Create a simple 2D binary mask"""
    mask = np.zeros((50, 50), dtype=np.uint8)
    mask[10:40, 10:40] = 1
    return mask


@pytest.fixture
def sample_3d_mask():
    """Create a simple 3D binary mask"""
    mask = np.zeros((20, 20, 20), dtype=np.uint8)
    mask[5:15, 5:15, 5:15] = 1
    return mask


@pytest.fixture
def sample_2d_multilabel_mask():
    """Create a simple 2D multi-label mask"""
    mask = np.zeros((50, 50), dtype=np.uint8)
    mask[10:20, 10:20] = 1  # Label 1
    mask[25:35, 25:35] = 2  # Label 2
    mask[35:45, 10:20] = 3  # Label 3
    return mask


@pytest.fixture
def sample_3d_multilabel_mask():
    """Create a simple 3D multi-label mask"""
    mask = np.zeros((20, 20, 20), dtype=np.uint8)
    mask[5:10, 5:10, 5:10] = 1   # Label 1
    mask[10:15, 10:15, 10:15] = 2  # Label 2
    mask[5:10, 10:15, 5:10] = 3  # Label 3
    return mask


@pytest.fixture
def sample_barcode():
    """Create a sample persistence barcode"""
    return np.array([
        [0.0, 0.5],
        [0.1, 0.8],
        [0.2, 1.2],
        [0.3, 0.7],
    ])


@pytest.fixture
def empty_barcode():
    """Create an empty barcode"""
    return np.array([]).reshape(0, 2)
