"""
MedTDA test suite
"""
