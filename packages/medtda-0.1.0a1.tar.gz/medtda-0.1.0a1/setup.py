"""
Setup.py for MedTDA package.
For modern packaging, see pyproject.toml.
"""
from setuptools import setup

# Configuration is in pyproject.toml
# This file exists for backward compatibility
if __name__ == "__main__":
    setup()
