Med-TDA Documentation
=====================

.. image:: https://img.shields.io/pypi/v/medtda.svg
   :target: https://pypi.org/project/medtda/
   :alt: PyPI version

.. image:: https://img.shields.io/pypi/pyversions/medtda.svg
   :target: https://pypi.org/project/medtda/
   :alt: Python versions

.. image:: https://img.shields.io/github/license/dashtiali/medtda.svg
   :target: https://github.com/dashtiali/medtda/blob/main/LICENSE
   :alt: License

Welcome to **Med-TDA** (Medical Imaging Topological Data Analysis), a comprehensive Python library for extracting TDA features from medical images. Med-TDA provides a complete pipeline from image preprocessing to persistence barcode computation and feature vectorization, designed specifically for medical imaging applications in machine learning and radiomics research.

Key Features
------------

* **🎯 Easy-to-use**: Simple scikit-learn-style API with sensible defaults
* **🔧 Flexible**: Support for 2D, 3D, and 4D medical images with comprehensive preprocessing
* **⚡ Efficient**: Optimized persistent homology computation using cripser and GUDHI
* **📊 Comprehensive**: 8 vectorization methods for different use cases
* **🏥 Medical Image Support**: Built-in support for NIfTI, NRRD, MHA, MHD, and common 2D formats
* **💻 CLI Support**: Command-line interface for batch processing and integration with pipelines
* **⚙️ Configurable**: YAML configuration files with extensive parameter control

Quick Example
-------------

Extract TDA features from a medical image in just a few lines:

.. code-block:: python

   from medtda import FeatureExtractor

   # Initialize with desired settings
   extractor = FeatureExtractor(
       normalize=True,
       vectorization_method='PersStats'
   )

   # Extract features
   features = extractor.execute('image.nii.gz', 'mask.nii.gz')
   
   # Use features in your ML pipeline
   print(f"Extracted {len(features)} TDA features")

Or use the command-line interface:

.. code-block:: bash

   # Single file processing
   medtda image.nii.gz --mask mask.nii.gz --output-dir ./results --normalize
   
   # Batch processing with parallel workers
   medtda cases.csv --output-dir ./results --workers 4 --verbose

Getting Started
---------------

.. toctree::
   :maxdepth: 2
   
   installation
   quickstart

User Guide
----------

Comprehensive guides for using MedTDA:

.. toctree::
   :maxdepth: 2
   
   user_guide
   cli

API Reference
-------------

Detailed API documentation for all modules and classes:

.. toctree::
   :maxdepth: 2
   
   api/index

TDA Theory
----------

Background on topological data analysis concepts:

.. toctree::
   :maxdepth: 2
   
   theory/index

Examples
--------

Practical examples and tutorials:

.. toctree::
   :maxdepth: 2
   
   examples/index

Additional Resources
--------------------

.. toctree::
   :maxdepth: 1
   
   faq
   changelog
   contributing
   references

Indices and Tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
