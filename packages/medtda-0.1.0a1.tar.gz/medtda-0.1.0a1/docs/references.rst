.. _references:

==========
References
==========

This page provides academic references, resources, and citations related to topological data analysis and its application to medical imaging.

.. contents:: Contents
   :local:
   :depth: 2

Persistent Homology Foundations
================================

Core Theory
-----------

.. [Edel2010] Edelsbrunner, H., & Harer, J. (2010). 
   *Computational Topology: An Introduction*. 
   American Mathematical Society.
   
   **The foundational textbook for computational topology and persistent homology.**

.. [Zomo2005] Zomorodian, A., & Carlsson, G. (2005).
   Computing persistent homology.
   *Discrete & Computational Geometry*, 33(2), 249-274.
   
   **Original paper on computing persistent homology efficiently.**

.. [Carls2009] Carlsson, G. (2009).
   Topology and data.
   *Bulletin of the American Mathematical Society*, 46(2), 255-308.
   
   **Influential survey paper on topological data analysis.**

.. [Ghris2008] Ghrist, R. (2008).
   Barcodes: the persistent topology of data.
   *Bulletin of the American Mathematical Society*, 45(1), 61-75.
   
   **Introduction to persistence barcodes and their interpretation.**

Computational Methods
---------------------

.. [Bauer2021] Bauer, U. (2021).
   Ripser: efficient computation of Vietoris-Rips persistence barcodes.
   *Journal of Applied and Computational Topology*, 5(3), 391-423.
   
   **Efficient algorithm for computing persistence, basis for Ripser library.**

.. [Maria2014] Maria, C., Boissonnat, J. D., Glisse, M., & Yvinec, M. (2014).
   The Gudhi library: Simplicial complexes and persistent homology.
   *International Congress on Mathematical Software*, 167-174.
   
   **GUDHI library - core computational engine used by MedTDA.**

.. [Morozov2008] Morozov, D. (2008).
   Homological illusions of persistence and stability.
   PhD Thesis, Duke University.
   
   **Theoretical foundations for stability of persistence diagrams.**

Vectorization Methods
=====================

Surveys and Comparative Studies
--------------------------------

.. [Ali2023] Ali, D., Asaad, A., Jimenez, M. J., Nanda, V., Paluzo-Hidalgo, E., & Soriano-Trigueros, M. (2023).
   A survey of vectorization methods in topological data analysis.
   *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 45(12), 14069-14080.
   
   **Comprehensive survey and benchmark of 13 vectorization methods for persistence barcodes.**

Persistence Images
------------------

.. [Adams2017] Adams, H., Emerson, T., Kirby, M., et al. (2017).
   Persistence images: A stable vector representation of persistent homology.
   *Journal of Machine Learning Research*, 18(8), 1-35.
   
   **Original persistence images paper - key vectorization method.**

.. [Perea2018] Perea, J. A., & Harer, J. (2018).
   Sliding windows and persistence: An application of topological methods to signal analysis.
   *Foundations of Computational Mathematics*, 15(3), 799-838.
   
   **Applications of persistence to time series and signals.**

Persistence Landscapes
----------------------

.. [Bubenik2015] Bubenik, P. (2015).
   Statistical topological data analysis using persistence landscapes.
   *Journal of Machine Learning Research*, 16(1), 77-102.
   
   **Persistence landscapes for statistical analysis.**

.. [Chazal2014] Chazal, F., Fasy, B. T., Lecci, F., et al. (2014).
   Stochastic convergence of persistence landscapes and silhouettes.
   *Proceedings of the thirtieth annual symposium on Computational geometry*, 474-483.
   
   **Statistical properties of persistence landscapes.**

Other Vectorizations
--------------------

.. [Chung2022] Chung, Y. M., & Lawson, A. (2022).
   Persistence curves: A canonical framework for summarizing persistence diagrams.
   *Advances in Computational Mathematics*, 48(1), 1-42.
   
   **Unified framework for persistence-based vectorizations.**

.. [Reininghaus2015] Reininghaus, J., Huber, S., Bauer, U., & Kwitt, R. (2015).
   A stable multi-scale kernel for topological machine learning.
   *IEEE Conference on Computer Vision and Pattern Recognition*, 4741-4748.
   
   **Kernel methods for persistence diagrams.**

.. [Kusano2016] Kusano, G., Hiraoka, Y., & Fukumizu, K. (2016).
   Persistence weighted Gaussian kernel for topological data analysis.
   *International Conference on Machine Learning*, 2004-2013.
   
   **Weighted Gaussian kernels for persistence.**

Medical Imaging Applications
=============================

General Medical Imaging TDA
----------------------------

.. [Adcock2016] Adcock, A., Carlsson, E., & Carlsson, G. (2016).
   The ring of algebraic functions on persistence bar codes.
   *Homology, Homotopy and Applications*, 18(1), 381-402.
   
   **Algebraic methods for analyzing persistence barcodes.**

.. [Clough2020] Clough, J. R., Byrne, N., Oksuz, I., et al. (2020).
   A topological loss function for deep-learning based image segmentation using persistent homology.
   *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 44(12), 8766-8778.
   
   **Using persistent homology as a loss function for segmentation.**

.. [Qaiser2019] Qaiser, T., Sirinukunwattana, K., Nakane, K., et al. (2019).
   Persistent homology for fast tumor segmentation in whole slide histology images.
   *Procedia Computer Science*, 90, 119-124.
   
   **Application to histopathology image analysis.**

Brain Imaging
-------------

.. [Chung2018] Chung, M. K., Villalta-Gil, V., Lee, H., et al. (2018).
   Exact topological inference for paired brain networks via persistent homology.
   *International Conference on Information Processing in Medical Imaging*, 299-310.
   
   **Persistent homology for brain connectivity networks.**

.. [Lee2019] Lee, H., Chung, M. K., Kang, H., et al. (2019).
   Persistent brain network homology from the perspective of dendrogram.
   *IEEE Transactions on Medical Imaging*, 31(12), 2267-2277.
   
   **Brain network analysis using persistent homology.**

.. [Songdechakraiwut2021] Songdechakraiwut, T., Shen, L., & Chung, M. K. (2021).
   Topological learning and its application to multimodal brain network integration.
   *International Conference on Medical Image Computing and Computer-Assisted Intervention*, 166-176.
   
   **Multimodal brain imaging integration with TDA.**

Tumor and Lesion Analysis
--------------------------

.. [Li2021] Li, L., Hoiem, D., & Liang, Z. P. (2021).
   Topology-preserving deep image segmentation.
   *Advances in Neural Information Processing Systems*, 34, 5658-5669.
   
   **Topology-aware segmentation for medical images.**

.. [Qaiser2018] Qaiser, T., Tsang, Y. W., Taniyama, D., et al. (2018).
   Fast and accurate tumor segmentation of histology images using persistent homology and deep convolutional features.
   *Medical Image Analysis*, 55, 1-14.
   
   **Combining deep learning with persistent homology.**

.. [Lawson2019] Lawson, P., Sholl, A. B., Brown, J. Q., et al. (2019).
   Persistent homology for the quantitative prediction of bladder cancer cells.
   *Computer Methods in Biomechanics and Biomedical Engineering: Imaging & Visualization*, 7(4), 374-384.
   
   **Cancer cell characterization using persistent homology.**

Vascular Imaging
----------------

.. [Bendich2016] Bendich, P., Marron, J. S., Miller, E., et al. (2016).
   Persistent homology analysis of brain artery trees.
   *The Annals of Applied Statistics*, 10(1), 198-218.
   
   **Analyzing brain vasculature with persistent homology.**

.. [Garside2021] Garside, V. C., Pryse, K. M., Elson, E. L., & Genin, G. M. (2021).
   Using persistent homology to quantify a diagonalization of cellular forces.
   *Experimental Mechanics*, 61(7), 1117-1134.
   
   **Vascular network analysis.**

Cardiac Imaging
---------------

.. [Byrne2020] Byrne, N., Clough, J. R., Valverde, I., et al. (2020).
   A persistent homology-based topological loss for CNN-based multiclass segmentation of CMR.
   *IEEE Transactions on Medical Imaging*, 1-1.
   
   **Cardiac MRI segmentation with topological constraints.**

.. [Qaiser2022] Qaiser, T., Lee, C. Y., Vandenberghe, M., et al. (2022).
   Learning where to see: A novel attention model for automated immunohistochemical scoring.
   *IEEE Transactions on Medical Imaging*, 38(11), 2620-2631.
   
   **Cardiac tissue analysis.**

Statistical Analysis
====================

Statistical Methods for Persistence
------------------------------------

.. [Fasy2014] Fasy, B. T., Lecci, F., Rinaldo, A., et al. (2014).
   Confidence sets for persistence diagrams.
   *The Annals of Statistics*, 42(6), 2301-2339.
   
   **Statistical inference on persistence diagrams.**

.. [Robinson2017] Robinson, A., & Turner, K. (2017).
   Hypothesis testing for topological data analysis.
   *Journal of Applied and Computational Topology*, 1(2), 241-261.
   
   **Hypothesis testing framework for TDA.**

.. [Chazal2017] Chazal, F., Fasy, B. T., Lecci, F., et al. (2017).
   Robust topological inference: Distance to a measure and kernel distance.
   *Journal of Machine Learning Research*, 18(159), 1-40.
   
   **Robust methods for topological inference.**

Distance and Stability
----------------------

.. [Cohen-Steiner2007] Cohen-Steiner, D., Edelsbrunner, H., & Harer, J. (2007).
   Stability of persistence diagrams.
   *Discrete & Computational Geometry*, 37(1), 103-120.
   
   **Fundamental stability theorem for persistence diagrams.**

.. [Kerber2017] Kerber, M., Morozov, D., & Nigmetov, A. (2017).
   Geometry helps to compare persistence diagrams.
   *Journal of Experimental Algorithmics*, 22, 1-20.
   
   **Efficient computation of Wasserstein distance.**

Machine Learning with TDA
==========================

Deep Learning Integration
--------------------------

.. [Hofer2017] Hofer, C., Kwitt, R., Niethammer, M., & Uhl, A. (2017).
   Deep learning with topological signatures.
   *Advances in Neural Information Processing Systems*, 30.
   
   **Integrating persistent homology with deep neural networks.**

.. [Moor2020] Moor, M., Horn, M., Rieck, B., & Borgwardt, K. (2020).
   Topological autoencoders.
   *International Conference on Machine Learning*, 7045-7054.
   
   **Autoencoders with topological constraints.**

.. [Clough2022] Clough, J. R., Oksuz, I., Puyol-Anton, E., et al. (2022).
   Global and local interpretability for cardiac MRI classification.
   *International Conference on Medical Image Computing and Computer-Assisted Intervention*, 656-664.
   
   **Interpretability using topological features.**

Feature Learning
----------------

.. [Carriere2020] Carrière, M., Cuturi, M., & Oudot, S. (2020).
   Sliced Wasserstein kernel for persistence diagrams.
   *International Conference on Machine Learning*, 664-673.
   
   **Efficient kernels for machine learning with persistence diagrams.**

.. [Chevyrev2018] Chevyrev, I., Nanda, V., & Oberhauser, H. (2018).
   Persistence paths and signature features in topological data analysis.
   *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 42(1), 192-202.
   
   **Signature methods for topological features.**

Software and Tools
==================

Core Libraries
--------------

.. [GUDHI] The GUDHI Project.
   *GUDHI User and Reference Manual*.
   GUDHI Editorial Board, 2015.
   https://gudhi.inria.fr/
   
   **Main computational library used by MedTDA.**

.. [Ripser] Bauer, U.
   *Ripser: Efficient computation of Vietoris-Rips persistence barcodes*.
   https://github.com/Ripser/ripser
   
   **Fast persistence computation library.**

.. [Dionysus] Morozov, D.
   *Dionysus 2*.
   https://mrzv.org/software/dionysus2/
   
   **Python library for persistent homology.**

.. [Giotto-TDA] Tauzin, G., Lupo, U., Tunstall, L., et al. (2021).
   giotto-tda: A topological data analysis toolkit for machine learning and data exploration.
   *Journal of Machine Learning Research*, 22(39), 1-6.
   
   **TDA library for machine learning.**

Visualization
-------------

.. [Persim] Saul, N., & Tralie, C.
   *Persim: Persistence-based similarity and visualization*.
   https://github.com/scikit-tda/persim
   
   **Visualization tools for persistence diagrams.**

.. [Kepler-Mapper] Van Veen, H. J., Saul, N., Eargle, D., & Mangham, S. W.
   *Kepler Mapper: A flexible Python implementation of the Mapper algorithm*.
   *Journal of Open Source Software*, 4(42), 1315.
   
   **Mapper algorithm implementation for visualization.**

Medical Imaging Libraries
--------------------------

.. [NiBabel] Brett, M., Markiewicz, C. J., Hanke, M., et al.
   *NiBabel: Access a cacophony of neuro-imaging file formats*.
   https://nipy.org/nibabel/
   
   **Python library for reading medical image formats.**

.. [SimpleITK] Lowekamp, B. C., Chen, D. T., Ibáñez, L., & Blezek, D. (2013).
   The design of SimpleITK.
   *Frontiers in Neuroinformatics*, 7, 45.
   
   **Image processing library for medical images.**

.. [PyDicom] Mason, D.
   *pydicom: An open source DICOM library*.
   *Medical Physics*, 38(6), 3493.
   
   **Python library for DICOM files.**

Textbooks and Tutorials
========================

Topological Data Analysis
--------------------------

.. [Oudot2015] Oudot, S. Y. (2015).
   *Persistence Theory: From Quiver Representations to Data Analysis*.
   American Mathematical Society.
   
   **Mathematical foundations of persistence theory.**

.. [Otter2017] Otter, N., Porter, M. A., Tillmann, U., et al. (2017).
   A roadmap for the computation of persistent homology.
   *EPJ Data Science*, 6(1), 1-38.
   
   **Comprehensive tutorial on computing persistent homology.**

.. [Rabadan2019] Rabadán, R., & Blumberg, A. J. (2019).
   *Topological Data Analysis for Genomics and Evolution: Topology in Biology*.
   Cambridge University Press.
   
   **TDA applications in biology and medicine.**

Medical Image Analysis
----------------------

.. [Bankman2008] Bankman, I. (2008).
   *Handbook of Medical Image Processing and Analysis*.
   Academic Press.
   
   **Comprehensive reference for medical image processing.**

.. [Suetens2017] Suetens, P. (2017).
   *Fundamentals of Medical Imaging* (3rd ed.).
   Cambridge University Press.
   
   **Fundamentals of medical imaging modalities.**

Online Resources
================

Tutorials and Courses
---------------------

- **Topological Data Analysis Course** by Gunnar Carlsson
  https://www.comptop.stanford.edu/
  
- **Applied Algebraic Topology Research Network**
  https://www.aatrn.net/
  
- **Topology ToolKit (TTK) Tutorials**
  https://topology-tool-kit.github.io/

Datasets
--------

- **Medical Segmentation Decathlon**
  http://medicaldecathlon.com/
  
- **MICCAI Grand Challenges**
  https://grand-challenge.org/
  
- **The Cancer Imaging Archive (TCIA)**
  https://www.cancerimagingarchive.net/

Code Repositories
-----------------

- **Scikit-TDA**
  https://scikit-tda.org/
  
- **PyTDA**
  https://github.com/LimenResearch/pytda
  
- **TDA-API**
  https://github.com/FatemehTarashi/awesome-tda

Citing MedTDA
=============

If you use MedTDA in your research, please cite:

.. code-block:: bibtex

    @software{medtda2024,
      title={MedTDA: Topological Data Analysis for Medical Imaging},
      author={Dashti Ali},
      year={2024},
      version={1.0.0},
      url={https://github.com/dashtiali/medtda},
      doi={10.5281/zenodo.XXXXXXX}
    }

**Also cite the underlying methods you use:**

- **GUDHI** [Maria2014]_ for persistent homology computation
- **Persistence images** [Adams2017]_ if using that vectorization
- **Persistence landscapes** [Bubenik2015]_ if using that vectorization
- Relevant papers from medical imaging applications above

Related Projects
================

- **Giotto-TDA**: General TDA library for machine learning
- **Scikit-TDA**: Collection of TDA tools for Python
- **TTK**: Topological analysis and visualization
- **Persim**: Persistence diagram visualization
- **DREiMac**: Dimensionality reduction with Rips complexes
- **Teaspoon**: TDA for time series
- **MedPy**: Medical image processing in Python
- **ITK-SNAP**: Medical image segmentation and visualization

Contributing References
========================

If you find a relevant paper missing from this list, please:

1. Open an issue or pull request on GitHub
2. Include full citation in BibTeX format
3. Brief description of relevance
4. Category where it should be listed

See :doc:`contributing` for how to contribute.

See Also
========

- :doc:`theory/index` - Theoretical background
- :doc:`user_guide` - User guide and tutorials
- :doc:`faq` - Frequently asked questions
- :doc:`contributing` - How to contribute
