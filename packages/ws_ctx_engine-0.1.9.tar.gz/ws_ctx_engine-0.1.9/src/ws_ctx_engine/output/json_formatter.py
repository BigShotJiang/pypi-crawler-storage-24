"""JSON formatter for agent-native context pack output."""

from __future__ import annotations

import json
from typing import Any


class JSONFormatter:
    def render(self, metadata: dict[str, Any], files: list[dict[str, Any]]) -> str:
        payload = {
            "metadata": metadata,
            "files": files,
        }
        return json.dumps(payload, ensure_ascii=False, indent=2)
