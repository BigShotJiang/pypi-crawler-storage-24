"""Interface to Figlinq's /v2/flowcharts endpoints."""

from figlinq.api.v2.utils import build_url, make_params, request

RESOURCE = "flowcharts"


def create(
    content,
    filename,
    parent_path=None,
    world_readable="false",
):
    """
    Create a new flowchart file.

    :param content: Flowchart content (dict).
    :param filename: File name.
    :param parent_path: Parent path for the file.
    :param world_readable: If True, the file is public.
    :return: dict with file metadata
    """

    url = build_url(RESOURCE, route="upload")
    import json
    data = {"content": content if isinstance(content, str) else json.dumps(content)}

    headers = {
        "X-File-Name": filename,
        "plotly-world-readable": world_readable,
    }
    # Only set parent-path header if explicitly provided (not None)
    # This allows PARENT_FOLDER_ID/PARENT_FOLDER_PATH env vars to take effect
    if parent_path is not None:
        headers["plotly-parent-path"] = parent_path

    response = request("post", url, json=data, headers=headers)
    if hasattr(response, "json"):
        return response.json()
    return response


def update(fid, content=None, filename=None, world_readable=None):
    """
    Update an existing flowchart file.

    :param fid: The file ID (username:idlocal) of the flowchart to update.
    :param content: New flowchart content (dict, optional).
    :param filename: New filename (optional).
    :param world_readable: New visibility setting (optional).
    :return: Response object
    """
    url = build_url(RESOURCE, id=fid)
    import json
    body = {}
    if content is not None:
        body["content"] = content if isinstance(content, str) else json.dumps(content)
    if filename is not None:
        body["filename"] = filename
    if world_readable is not None:
        body["world_readable"] = world_readable
    return request("put", url, json=body)


def content(fid, share_key=None):
    """
    Retrieve full content

    :param (str) fid: The `{username}:{idlocal}` identifier. E.g. `foo:88`.
    :param (str) share_key: The secret key granting 'read' access if private.
    :returns: (requests.Response) Returns response directly from requests.

    """
    url = build_url(RESOURCE, id=fid)
    params = make_params(share_key=share_key)
    return request("get", url, params=params)
