import base64
import io
import logging

from PIL import ExifTags, Image

logger = logging.getLogger(__name__)


def fix_image_orientation(image_str: str):
    """
    Fix an image's orientation using EXIF metadata.

    This function expects a base64-encoded image string, decodes it into bytes,
    opens it with Pillow (PIL), checks EXIF Orientation (if present), rotates
    the image to the correct upright orientation, then returns the corrected
    image as a base64-encoded string.

    Args:
        image_str (str): Base64-encoded image data (no data URI prefix).

    Returns:
        str | None: Base64-encoded corrected image, or None if processing fails.
    """
    logger.info("Starting image orientation fix")
    try:
        image_data = base64.b64decode(image_str)
        img = Image.open(io.BytesIO(image_data))
    except Exception as e:
        logger.error(f"Invalid base64 image input: {e}")
        return None

    rotation = 0

    try:
        exif = img._getexif()

        if exif:
            logger.info("EXIF data found")
            for tag, val in exif.items():
                if ExifTags.TAGS.get(tag) == "Orientation":
                    orientation = val

                    rotation_map = {3: 180, 6: 270, 8: 90}

                    rotation = rotation_map.get(orientation, 0)
                    logger.info(
                        f"EXIF orientation: {orientation}, rotation needed: {rotation}"
                    )
                    break

        if rotation:
            img = img.rotate(rotation, expand=True)
            logger.info(f"Rotated image by {rotation} degrees")
        else:
            logger.info("Image already correct orientation or no EXIF")

    except Exception as e:
        logger.error(f"EXIF read error: {e}")

    try:
        buffer = io.BytesIO()

        # After rotate/copy, format can be None; default to JPEG
        out_format = img.format if img.format else "JPEG"

        img.save(buffer, format=out_format)
        base64_output = base64.b64encode(buffer.getvalue()).decode("utf-8")

        logger.info(f"type after conversion: {type(base64_output)}")
        return base64_output

    except Exception as e:
        logger.error(f"Base64 conversion error: {e}")
        return None

    finally:
        try:
            img.close()
        except Exception:
            pass
        try:
            buffer.close()
        except Exception:
            pass
        del img, buffer
