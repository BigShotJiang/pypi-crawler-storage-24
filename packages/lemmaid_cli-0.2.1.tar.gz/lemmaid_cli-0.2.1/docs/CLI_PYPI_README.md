# lemma-cli

`lemma-cli` is the command-line interface for integrating Lemma.id authentication and running launch-grade auth checks.

## Install

```bash
pipx install lemma-cli
```

## OpenClaw Starter Path

```bash
lemma setup-openclaw --api-base https://lemma.id --json
lemma safety-status --firewall-url http://127.0.0.1:8787 --json
```

`lemma setup-openclaw` is the public starter-safe path. It:

- opens one browser approval
- issues a starter-safe OpenClaw proof
- connects the runtime
- starts the local firewall
- verifies one protected allow
- kills the runtime and verifies deny

## Other Core Commands

```bash
lemma session start --api-base https://lemma.id
lemma session status --api-base https://lemma.id --json
lemma setup-firewall --api-base https://lemma.id --json
lemma setup --site-id site_demo --site-domain example.com --framework flask --json
lemma audit --project-dir . --framework flask --skip-health --json
lemma fix --project-dir . --framework flask --safe --skip-health --json
lemma ci --project-dir . --framework flask --skip-health --skip-smoke --json
```

## Authentication for Sensitive Operations

Local interactive browser flow:

```bash
lemma login --api-base https://lemma.id
lemma auth-status --api-base https://lemma.id --json
```

Headless/CI flow:

```bash
lemma login --api-base https://lemma.id --non-interactive --platform-api-key "$LEMMA_API_KEY" --user-email "$LEMMA_ADMIN_EMAIL" --json
```

## Sensitive Management Commands

```bash
lemma site-create --domain demo.example --environment development --json
lemma key-bootstrap --site-id site_demo --name "CI Key" --permissions read,write --json
lemma iam-type-create --site-id site_demo --name admin_access --iam-type role --json
lemma iam-type-list --site-id site_demo --json
```

## Contract

All machine-oriented commands support `--json` and emit:
- `schema_version`
- `command`
- `ok`
- `error_code`

## Documentation

- OpenClaw Personal Quickstart: `docs/openclaw/PERSONAL_QUICKSTART.md`
- Quickstart: <https://lemma.id/docs/quickstart>
- Release checklist: `docs/operations/CLI_RELEASE_CHECKLIST.md`
