"""
Canonical revocation verification helpers.

All runtime revocation checks should route through this module so behavior
stays consistent across auth entry points.
"""

from __future__ import annotations

from typing import Optional
import logging

logger = logging.getLogger(__name__)


def is_credential_revoked(credential_id: Optional[str]) -> bool:
    """
    Canonical revocation check.

    Strategy:
    1) Check in-memory bloom verifier (fast path) when available.
    2) Confirm against authoritative DB revocation registry.
    """
    if not credential_id:
        return False

    # Fast path: in-process verifier (if initialized)
    try:
        from api.permission_verification import get_global_verifier

        verifier = get_global_verifier()
        if verifier and verifier.is_revoked(credential_id):
            return True
    except Exception as e:
        logger.debug(f"Bloom revocation check unavailable for {credential_id}: {e}")

    # Canonical source of truth: revocation_list table
    try:
        from api.database import get_db_connection

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                SELECT 1
                FROM revocation_list
                WHERE COALESCE(credential_id, lemma_id) = %s
                LIMIT 1
                """,
                (credential_id,),
            )
            return cursor.fetchone() is not None
        finally:
            cursor.close()
            conn.close()
    except Exception as e:
        logger.warning(f"DB revocation check unavailable for {credential_id}: {e}")
        return False
