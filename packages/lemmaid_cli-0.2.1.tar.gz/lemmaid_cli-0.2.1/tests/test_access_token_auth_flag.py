import sys
import types

from flask import Flask, g

from auth import decorators

# pylint: disable=protected-access


def _stub_access_tokens_module(validate_fn):
    return types.SimpleNamespace(validate_access_token=validate_fn)


def test_access_token_auth_enabled_by_default(monkeypatch):
    app = Flask(__name__)
    monkeypatch.delenv("LEMMA_ENABLE_ACCESS_TOKEN_AUTH", raising=False)
    monkeypatch.setitem(
        sys.modules,
        "api.access_tokens",
        _stub_access_tokens_module(
            lambda token, required_scope=None: (
                {
                    "sub": "ppid_test",
                    "permission_id": "perm_test",
                    "scope": ["admin"],
                    "is_admin": True,
                },
                None,
            )
        ),
    )

    with app.test_request_context(headers={"Authorization": "Bearer lm_at_enabled"}):
        handled, response = decorators._try_authenticate_access_token(required_scope="admin")
        assert handled is True
        assert response is None
        assert g.auth_method == "access_token"
        assert g.ppid == "ppid_test"
        assert g.is_admin is True


def test_access_token_auth_ignored_when_flag_disabled(monkeypatch):
    app = Flask(__name__)
    monkeypatch.setenv("LEMMA_ENABLE_ACCESS_TOKEN_AUTH", "0")
    monkeypatch.setitem(
        sys.modules,
        "api.access_tokens",
        _stub_access_tokens_module(
            lambda token, required_scope=None: (_ for _ in ()).throw(AssertionError("should not be called"))
        ),
    )

    with app.test_request_context(headers={"Authorization": "Bearer lm_at_disabled"}):
        handled, response = decorators._try_authenticate_access_token(required_scope="admin")
        assert handled is False
        assert response is None
