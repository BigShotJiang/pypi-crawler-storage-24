import pytest

from index_inclusion._rules import evaluate_eligibility, evaluate_rule
from index_inclusion._types import Candidate, HardRule, IndexCode, Operator, RuleVerdict
from tests.conftest import make_candidate


class TestEvaluateRule:
    def test_ge_pass(self):
        rule = HardRule("MCap", "market_cap_usd", Operator.GE, 10_000_000_000)
        c = make_candidate(market_cap_usd=50_000_000_000)
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.PASS

    def test_ge_fail(self):
        rule = HardRule("MCap", "market_cap_usd", Operator.GE, 100_000_000_000)
        c = make_candidate(market_cap_usd=50_000_000_000)
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.FAIL

    def test_le_pass(self):
        rule = HardRule("MCap Upper", "market_cap_usd", Operator.LE, 100_000_000_000)
        c = make_candidate(market_cap_usd=50_000_000_000)
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.PASS

    def test_le_fail(self):
        rule = HardRule("MCap Upper", "market_cap_usd", Operator.LE, 10_000_000_000)
        c = make_candidate(market_cap_usd=50_000_000_000)
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.FAIL

    def test_gt_pass(self):
        rule = HardRule("Earnings", "sum_4q_gaap_earnings", Operator.GT, 0)
        c = make_candidate(sum_4q_gaap_earnings=1_000_000)
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.PASS

    def test_gt_fail(self):
        rule = HardRule("Earnings", "sum_4q_gaap_earnings", Operator.GT, 0)
        c = make_candidate(sum_4q_gaap_earnings=-1_000_000)
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.FAIL

    def test_eq_pass(self):
        rule = HardRule("Domicile", "domicile", Operator.EQ, "US")
        c = make_candidate(domicile="US")
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.PASS

    def test_eq_fail(self):
        rule = HardRule("Domicile", "domicile", Operator.EQ, "US")
        c = make_candidate(domicile="UK")
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.FAIL

    def test_in_pass(self):
        rule = HardRule("Exchange", "exchange", Operator.IN, ("NYSE", "NASDAQ Global Select"))
        c = make_candidate(exchange="NYSE")
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.PASS

    def test_in_fail(self):
        rule = HardRule("Exchange", "exchange", Operator.IN, ("NYSE",))
        c = make_candidate(exchange="LSE Main Market")
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.FAIL

    def test_not_in_pass(self):
        rule = HardRule("Sector", "gics_sector", Operator.NOT_IN, ("Financials",))
        c = make_candidate(gics_sector="Technology")
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.PASS

    def test_not_in_fail(self):
        rule = HardRule("Sector", "gics_sector", Operator.NOT_IN, ("Technology",))
        c = make_candidate(gics_sector="Technology")
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.FAIL

    def test_skip_on_none(self):
        rule = HardRule("MCap", "market_cap_usd", Operator.GE, 10_000_000_000)
        c = make_candidate(market_cap_usd=None)
        r = evaluate_rule(rule, c)
        assert r.verdict is RuleVerdict.SKIP

    def test_skip_does_not_fail_eligibility(self):
        """SKIP results do not cause failure per spec."""
        c = make_candidate(files_10K_10Q=None)  # will SKIP the SEC filing rule
        eligible, results = evaluate_eligibility(IndexCode.SP500, c)
        skips = [r for r in results if r.verdict is RuleVerdict.SKIP]
        assert len(skips) >= 1
        assert eligible  # still eligible despite SKIPs


class TestEvaluateEligibility:
    def test_sp500_eligible(self):
        c = make_candidate()
        eligible, results = evaluate_eligibility(IndexCode.SP500, c)
        assert eligible
        assert all(r.verdict is RuleVerdict.PASS for r in results)

    def test_sp500_ineligible_earnings(self):
        c = make_candidate(sum_4q_gaap_earnings=-1_000_000)
        eligible, results = evaluate_eligibility(IndexCode.SP500, c)
        assert not eligible
        fails = [r for r in results if r.verdict is RuleVerdict.FAIL]
        assert any("Earnings" in r.rule_name for r in fails)

    def test_sp500_ineligible_domicile(self):
        c = make_candidate(domicile="UK")
        eligible, _ = evaluate_eligibility(IndexCode.SP500, c)
        assert not eligible

    def test_sp400_market_cap_band(self):
        # In range
        c = make_candidate(market_cap_usd=15_000_000_000, float_market_cap_usd=10_000_000_000)
        eligible, _ = evaluate_eligibility(IndexCode.SP400, c)
        assert eligible

        # Above upper bound
        c2 = make_candidate(market_cap_usd=30_000_000_000)
        eligible2, _ = evaluate_eligibility(IndexCode.SP400, c2)
        assert not eligible2

    def test_ndx_no_financials(self):
        c = make_candidate(
            exchange="NASDAQ Global Select",
            icb_sector="Financials",
            months_listed=6,
            free_float_pct=50,
            in_bankruptcy=False,
            pending_disqualifying_event=False,
            sec_filings_current=True,
        )
        eligible, _ = evaluate_eligibility(IndexCode.NDX, c)
        assert not eligible

    def test_djia_requires_sp500(self):
        c = make_candidate(in_sp500=False)
        eligible, _ = evaluate_eligibility(IndexCode.DJIA, c)
        assert not eligible

        c2 = make_candidate(in_sp500=True)
        eligible2, _ = evaluate_eligibility(IndexCode.DJIA, c2)
        assert eligible2

    def test_aapl_like_sp500_eligible(self):
        """Spec test case: Large US tech, Nasdaq-listed."""
        c = make_candidate(
            ticker="AAPL",
            market_cap_usd=3_000_000_000_000,
            float_market_cap_usd=2_800_000_000_000,
            domicile="US",
            exchange="NASDAQ Global Select",
            security_type="Common Stock",
        )
        eligible, _ = evaluate_eligibility(IndexCode.SP500, c)
        assert eligible

    def test_small_stock_sp500_ineligible(self):
        """Spec test case: $500M US stock."""
        c = make_candidate(
            ticker="TINY",
            market_cap_usd=500_000_000,
            float_market_cap_usd=400_000_000,
        )
        eligible, _ = evaluate_eligibility(IndexCode.SP500, c)
        assert not eligible

    def test_spac_ineligible(self):
        """Spec test case: SPACs excluded by security type."""
        c = make_candidate(security_type="SPAC")
        eligible, _ = evaluate_eligibility(IndexCode.SP500, c)
        assert not eligible
