from unittest.mock import MagicMock

from index_inclusion._scanner import scan
from index_inclusion._types import IndexCode


class MockScannerClient:
    """Mock FMP client for scanner tests."""

    def screener(self, **kwargs):
        return [
            {"symbol": "PLTR"},
            {"symbol": "UBER"},
            {"symbol": "COIN"},
        ]

    def sp500_constituent(self):
        return [{"symbol": "AAPL"}, {"symbol": "MSFT"}]

    def nasdaq_constituent(self):
        return [{"symbol": "AAPL"}]

    def dowjones_constituent(self):
        return [{"symbol": "AAPL"}]

    def profile(self, symbol):
        return [
            {
                "symbol": symbol,
                "companyName": f"{symbol} Inc.",
                "country": "US",
                "exchange": "NYSE",
                "sector": "Technology",
                "ipoDate": "2015-01-01",
                "isEtf": False,
            }
        ]

    def quote(self, symbol):
        return [{"symbol": symbol, "price": 100.0, "marketCap": 50_000_000_000}]

    def shares_float(self, symbol):
        return [{"floatShares": 400_000_000, "outstandingShares": 500_000_000}]

    def income_statement(self, symbol, *, period="annual", limit=4):
        return [
            {"date": "2025-12-31", "netIncome": 500_000_000},
            {"date": "2025-09-30", "netIncome": 400_000_000},
            {"date": "2025-06-30", "netIncome": 300_000_000},
            {"date": "2025-03-31", "netIncome": 200_000_000},
        ]

    def historical_price_eod_full(self, symbol, *, from_date=None, to_date=None):
        return []

    def historical_market_capitalization(self, symbol, *, from_date=None, to_date=None):
        return []

    def stock_list(self):
        return []


class TestScan:
    def test_excludes_constituents(self):
        client = MockScannerClient()
        result = scan(client, IndexCode.SP500)
        tickers = [r.ticker for r in result.results]
        assert "AAPL" not in tickers
        assert "MSFT" not in tickers

    def test_results_sorted_by_probability(self):
        client = MockScannerClient()
        result = scan(client, IndexCode.SP500)
        probs = [r.probability for r in result.results]
        assert probs == sorted(probs, reverse=True)

    def test_scan_result_fields(self):
        client = MockScannerClient()
        result = scan(client, IndexCode.SP500)
        assert result.index_code is IndexCode.SP500
        assert result.scan_date is not None
        assert isinstance(result.universe_size, int)
        assert isinstance(result.eligible_count, int)
        assert "AAPL" in result.current_constituents
