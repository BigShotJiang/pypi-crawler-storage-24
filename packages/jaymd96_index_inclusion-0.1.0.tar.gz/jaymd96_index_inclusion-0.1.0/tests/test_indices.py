from index_inclusion._indices import INDEX_CONFIGS, get_index_config
from index_inclusion._types import IndexCode


class TestIndexConfigs:
    def test_all_seven_indices_present(self):
        assert len(INDEX_CONFIGS) == 7
        for code in IndexCode:
            assert code in INDEX_CONFIGS

    def test_sp500_rule_count(self):
        config = get_index_config(IndexCode.SP500)
        assert len(config.hard_rules) == 12

    def test_sp400_rule_count(self):
        config = get_index_config(IndexCode.SP400)
        # 3 market cap rules + 10 common = 13
        assert len(config.hard_rules) == 13

    def test_sp600_rule_count(self):
        config = get_index_config(IndexCode.SP600)
        assert len(config.hard_rules) == 13

    def test_ndx_rule_count(self):
        config = get_index_config(IndexCode.NDX)
        assert len(config.hard_rules) == 8

    def test_ftse100_rule_count(self):
        config = get_index_config(IndexCode.FTSE100)
        assert len(config.hard_rules) == 7

    def test_djia_rule_count(self):
        config = get_index_config(IndexCode.DJIA)
        assert len(config.hard_rules) == 3

    def test_r3000_rule_count(self):
        config = get_index_config(IndexCode.R3000)
        assert len(config.hard_rules) == 5

    def test_sp500_market_cap_threshold(self):
        config = get_index_config(IndexCode.SP500)
        mcap_rule = next(r for r in config.hard_rules if r.name == "Market Capitalisation")
        assert mcap_rule.threshold == 22_700_000_000

    def test_sp400_market_cap_band(self):
        config = get_index_config(IndexCode.SP400)
        lower = next(r for r in config.hard_rules if r.name == "Market Cap (Lower)")
        upper = next(r for r in config.hard_rules if r.name == "Market Cap (Upper)")
        assert lower.threshold == 8_000_000_000
        assert upper.threshold == 22_700_000_000

    def test_sp600_market_cap_band(self):
        config = get_index_config(IndexCode.SP600)
        lower = next(r for r in config.hard_rules if r.name == "Market Cap (Lower)")
        upper = next(r for r in config.hard_rules if r.name == "Market Cap (Upper)")
        assert lower.threshold == 1_200_000_000
        assert upper.threshold == 8_000_000_000

    def test_vacancy_mechanics_sp500(self):
        config = get_index_config(IndexCode.SP500)
        assert config.vacancy.fixed_count is True
        assert config.vacancy.target_count == 500
        assert config.vacancy.requires_vacancy is True
        assert config.vacancy.can_displace is False
        assert config.vacancy.base_rate_fallback == 0.45

    def test_vacancy_mechanics_ftse100(self):
        config = get_index_config(IndexCode.FTSE100)
        assert config.vacancy.requires_vacancy is False
        assert config.vacancy.can_displace is True
        assert config.vacancy.default_vacancy_score == 0.80

    def test_vacancy_mechanics_r3000(self):
        config = get_index_config(IndexCode.R3000)
        assert config.vacancy.requires_vacancy is False
        assert config.vacancy.default_vacancy_score == 0.90

    def test_vacancy_mechanics_djia(self):
        config = get_index_config(IndexCode.DJIA)
        assert config.vacancy.requires_vacancy is True
        assert config.vacancy.base_rate_fallback == 0.10

    def test_selection_types(self):
        assert get_index_config(IndexCode.SP500).selection_type == "committee"
        assert get_index_config(IndexCode.FTSE100).selection_type == "rank"
        assert get_index_config(IndexCode.R3000).selection_type == "rules"

    def test_ml_applicable(self):
        assert get_index_config(IndexCode.SP500).ml_applicable is True
        assert get_index_config(IndexCode.FTSE100).ml_applicable is False
        assert get_index_config(IndexCode.R3000).ml_applicable is False
        assert get_index_config(IndexCode.DJIA).ml_applicable is False

    def test_get_index_config_by_string(self):
        config = get_index_config("SP500")
        assert config.code is IndexCode.SP500

    def test_no_duplicate_rule_names_per_index(self):
        for code, config in INDEX_CONFIGS.items():
            names = [r.name for r in config.hard_rules]
            # Some indices share rule names (e.g., "Exchange Listing"),
            # but within an index they should be unique
            assert len(names) == len(set(names)), f"Duplicate rule names in {code.value}"
