from index_inclusion._scorer import score, score_many
from index_inclusion._types import IndexCode, ProbabilityLabel
from tests.conftest import make_candidate


class TestScore:
    def test_ineligible_returns_zero(self):
        c = make_candidate(market_cap_usd=1_000_000)  # too small for SP500
        result = score(c, IndexCode.SP500)
        assert not result.eligible
        assert result.probability == 0.0
        assert result.probability_label == ProbabilityLabel.INELIGIBLE.value
        assert result.signals is None
        assert result.ml_applied is False

    def test_eligible_returns_nonzero(self):
        c = make_candidate()
        result = score(c, IndexCode.SP500)
        assert result.eligible
        assert 0.0 < result.probability <= 1.0
        assert result.signals is not None
        assert result.probability_label != ProbabilityLabel.INELIGIBLE.value

    def test_signals_populated(self):
        c = make_candidate()
        result = score(c, IndexCode.SP500)
        assert result.signals is not None
        assert 0.0 <= result.signals.margin_of_safety <= 1.0
        assert 0.0 <= result.signals.vacancy_likelihood <= 1.0
        assert 0.0 <= result.signals.queue_position <= 1.0
        assert 0.0 <= result.signals.momentum <= 1.0
        assert 0.0 <= result.signals.sector_fit <= 1.0

    def test_base_probability_equals_final_without_ml(self):
        c = make_candidate()
        result = score(c, IndexCode.SP500)
        assert result.base_probability == result.probability
        assert result.ml_applied is False
        assert result.ml_adjustment == 0.0

    def test_vacancy_context(self):
        c = make_candidate()
        result = score(c, IndexCode.SP500)
        assert result.vacancy_context.fixed_count is True
        assert result.vacancy_context.target_count == 500
        assert result.vacancy_context.requires_vacancy is True

    def test_notes_include_vacancy_info(self):
        c = make_candidate()
        result = score(c, IndexCode.SP500)
        assert any("vacancy" in n.lower() for n in result.notes)

    def test_confidence_high_with_full_data(self):
        c = make_candidate()
        result = score(c, IndexCode.SP500)
        assert result.confidence == "High"

    def test_confidence_medium_with_some_missing(self):
        c = make_candidate(files_10K_10Q=None)
        result = score(c, IndexCode.SP500)
        assert result.confidence in ("Medium", "High")

    def test_probability_labels(self):
        # Very High
        assert score(make_candidate(market_cap_usd=500_000_000_000), IndexCode.SP500).probability_label in (
            "Very High", "High", "Medium"
        )

    def test_rule_results_populated(self):
        c = make_candidate()
        result = score(c, IndexCode.SP500)
        assert len(result.rule_results) > 0
        assert result.rules_passed > 0

    def test_string_index_code(self):
        c = make_candidate()
        result = score(c, "SP500")
        assert result.index_code == "SP500"


class TestScoreMany:
    def test_sorted_descending(self):
        c1 = make_candidate(ticker="BIG", market_cap_usd=200_000_000_000)
        c2 = make_candidate(ticker="SMALL", market_cap_usd=1_000_000)  # ineligible
        c3 = make_candidate(ticker="MED", market_cap_usd=50_000_000_000)

        results = score_many([c1, c2, c3], IndexCode.SP500)
        probs = [r.probability for r in results]
        assert probs == sorted(probs, reverse=True)

    def test_multiple_indices(self):
        c = make_candidate()
        results = score_many([c], [IndexCode.SP500, IndexCode.SP400])
        assert len(results) == 2
        codes = {r.index_code for r in results}
        assert "SP500" in codes
        assert "SP400" in codes

    def test_single_index_as_string(self):
        c = make_candidate()
        results = score_many([c], "SP500")
        assert len(results) == 1
