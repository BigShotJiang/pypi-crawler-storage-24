from datetime import date
from unittest.mock import MagicMock

from index_inclusion._backtest import _filter_additions
from index_inclusion._types import IndexCode


class TestFilterAdditions:
    def test_filters_by_year(self):
        changes = [
            {"dateAdded": "2020-06-15", "symbol": "A", "removedTicker": "B", "reason": "M&A"},
            {"dateAdded": "2018-03-01", "symbol": "C", "removedTicker": "D", "reason": ""},
            {"dateAdded": "2025-01-10", "symbol": "E", "removedTicker": "F", "reason": ""},
        ]
        result = _filter_additions(changes, 2019, 2024)
        assert len(result) == 1
        assert result[0]["added"] == "A"

    def test_sorts_chronologically(self):
        changes = [
            {"dateAdded": "2022-12-01", "symbol": "B", "removedTicker": "", "reason": ""},
            {"dateAdded": "2022-01-01", "symbol": "A", "removedTicker": "", "reason": ""},
            {"dateAdded": "2022-06-01", "symbol": "C", "removedTicker": "", "reason": ""},
        ]
        result = _filter_additions(changes, 2022, 2022)
        tickers = [r["added"] for r in result]
        assert tickers == ["A", "C", "B"]

    def test_skips_empty_dates(self):
        changes = [
            {"dateAdded": "", "symbol": "A", "removedTicker": "", "reason": ""},
            {"dateAdded": "2022-01-01", "symbol": "B", "removedTicker": "", "reason": ""},
        ]
        result = _filter_additions(changes, 2020, 2025)
        assert len(result) == 1

    def test_skips_entries_without_added_symbol(self):
        changes = [
            {"dateAdded": "2022-01-01", "symbol": "", "removedTicker": "X", "reason": ""},
        ]
        result = _filter_additions(changes, 2020, 2025)
        assert len(result) == 0


class TestBacktestResult:
    def test_precision_calculation(self):
        from index_inclusion._types import BacktestEvent, BacktestResult

        events = (
            BacktestEvent(
                event_date=date(2022, 1, 1), added_ticker="A", removed_ticker="B",
                vacancy_cause="M&A", predicted_rank=1, top_k_predictions=("A", "C", "D"),
                actual_in_top_3=True, actual_in_top_5=True, actual_in_top_10=True,
                predicted_probability=0.8, num_eligible=50,
            ),
            BacktestEvent(
                event_date=date(2022, 6, 1), added_ticker="E", removed_ticker="F",
                vacancy_cause="delisting", predicted_rank=7, top_k_predictions=("X", "Y", "Z"),
                actual_in_top_3=False, actual_in_top_5=False, actual_in_top_10=True,
                predicted_probability=0.3, num_eligible=60,
            ),
        )

        result = BacktestResult(
            index_code=IndexCode.SP500,
            start_year=2022, end_year=2022,
            events=events, total_events=2,
            precision_at_3=0.5, precision_at_5=0.5, precision_at_10=1.0,
            mean_predicted_rank=4.0, median_predicted_rank=4.0,
        )
        assert result.precision_at_3 == 0.5
        assert result.precision_at_10 == 1.0
