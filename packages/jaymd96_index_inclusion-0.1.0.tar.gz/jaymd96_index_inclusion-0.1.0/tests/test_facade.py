"""Tests for the IndexInclusion facade.

These tests mock the FMP client to avoid real API calls.
"""

from unittest.mock import MagicMock, patch

import pytest

from index_inclusion._facade import IndexInclusion
from index_inclusion._types import IndexCode


class MockFMPClientForFacade:
    def __init__(self, **kwargs):
        pass

    def profile(self, symbol):
        return [
            {
                "symbol": symbol,
                "companyName": f"{symbol} Inc.",
                "country": "US",
                "exchange": "NYSE",
                "sector": "Technology",
                "ipoDate": "2015-01-01",
                "isEtf": False,
            }
        ]

    def quote(self, symbol):
        return [{"symbol": symbol, "price": 100.0, "marketCap": 50_000_000_000}]

    def shares_float(self, symbol):
        return [{"floatShares": 400_000_000, "outstandingShares": 500_000_000}]

    def income_statement(self, symbol, *, period="annual", limit=4):
        return [
            {"date": "2025-12-31", "netIncome": 500_000_000},
            {"date": "2025-09-30", "netIncome": 400_000_000},
            {"date": "2025-06-30", "netIncome": 300_000_000},
            {"date": "2025-03-31", "netIncome": 200_000_000},
        ]

    def historical_price_eod_full(self, symbol, *, from_date=None, to_date=None):
        return []

    def historical_market_capitalization(self, symbol, *, from_date=None, to_date=None):
        return []

    def sp500_constituent(self):
        return [{"symbol": "AAPL"}, {"symbol": "MSFT"}]

    def nasdaq_constituent(self):
        return [{"symbol": "AAPL"}]

    def dowjones_constituent(self):
        return [{"symbol": "AAPL"}]

    def screener(self, **kwargs):
        return [{"symbol": "PLTR"}, {"symbol": "COIN"}]

    def stock_list(self):
        return []


@pytest.fixture
def facade():
    with patch("fmp.FMPClient", MockFMPClientForFacade):
        return IndexInclusion(fmp_api_key="test-key")


class TestFacade:
    def test_check_returns_scoring_result(self, facade):
        result = facade.check("PLTR", "SP500")
        assert result.ticker == "PLTR"
        assert result.index_code == "SP500"
        assert isinstance(result.probability, float)

    def test_check_with_index_code_enum(self, facade):
        result = facade.check("PLTR", IndexCode.SP500)
        assert result.index_code == "SP500"

    def test_check_many(self, facade):
        results = facade.check_many(["PLTR", "COIN"], ["SP500"])
        assert len(results) == 2

    def test_check_many_multiple_indices(self, facade):
        results = facade.check_many(["PLTR"], ["SP500", "SP400"])
        assert len(results) == 2

    def test_ml_not_applied_without_training(self, facade):
        result = facade.check("PLTR", "SP500")
        assert result.ml_applied is False

    def test_model_health_none_without_training(self, facade):
        assert facade.model_health("SP500") is None
