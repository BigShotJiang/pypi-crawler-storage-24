import pytest

from index_inclusion._ml import MLCalibrator
from index_inclusion._types import Candidate, IndexCode, SignalValues


class TestMLCalibrator:
    def test_not_available_initially(self):
        ml = MLCalibrator()
        assert ml.is_available(IndexCode.SP500) is False

    def test_calibrate_passthrough_when_no_model(self):
        ml = MLCalibrator()
        signals = SignalValues(0.8, 0.5, 0.7, 0.6, 0.5)
        candidate = Candidate(ticker="TEST")

        prob, applied, adj = ml.calibrate(IndexCode.SP500, 0.65, signals, candidate)
        assert prob == 0.65
        assert applied is False
        assert adj == 0.0

    def test_health_none_when_no_model(self):
        ml = MLCalibrator()
        assert ml.health(IndexCode.SP500) is None

    def test_save_load_empty(self, tmp_path):
        ml = MLCalibrator()
        save_path = str(tmp_path / "models")
        ml.save(save_path)

        loaded = MLCalibrator.load(save_path)
        assert not loaded.is_available(IndexCode.SP500)

    def test_string_index_code(self):
        ml = MLCalibrator()
        assert ml.is_available("SP500") is False
