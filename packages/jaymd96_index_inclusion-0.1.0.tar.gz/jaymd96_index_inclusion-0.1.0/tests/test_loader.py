from unittest.mock import MagicMock

import pytest

from index_inclusion._loader import load_candidate, load_candidates, load_constituent_symbols


class MockFMPClient:
    """Minimal mock of FMPClient for testing the loader."""

    def __init__(self):
        self.profile_data = [
            {
                "symbol": "AAPL",
                "companyName": "Apple Inc.",
                "country": "US",
                "exchange": "NASDAQ Global Select Market",
                "sector": "Technology",
                "ipoDate": "1980-12-12",
                "isEtf": False,
            }
        ]
        self.quote_data = [
            {
                "symbol": "AAPL",
                "price": 175.50,
                "marketCap": 2_800_000_000_000,
            }
        ]
        self.shares_float_data = [
            {
                "symbol": "AAPL",
                "floatShares": 15_000_000_000,
                "outstandingShares": 15_500_000_000,
            }
        ]
        self.income_data = [
            {"date": "2025-12-31", "netIncome": 25_000_000_000, "period": "Q4"},
            {"date": "2025-09-30", "netIncome": 23_000_000_000, "period": "Q3"},
            {"date": "2025-06-30", "netIncome": 22_000_000_000, "period": "Q2"},
            {"date": "2025-03-31", "netIncome": 21_000_000_000, "period": "Q1"},
        ]
        self.eod_data = []
        self.sp500_data = [{"symbol": "AAPL"}, {"symbol": "MSFT"}, {"symbol": "GOOG"}]

    def profile(self, symbol):
        return self.profile_data

    def quote(self, symbol):
        return self.quote_data

    def shares_float(self, symbol):
        return self.shares_float_data

    def income_statement(self, symbol, *, period="annual", limit=4):
        return self.income_data

    def historical_price_eod_full(self, symbol, *, from_date=None, to_date=None):
        return self.eod_data

    def historical_market_capitalization(self, symbol, *, from_date=None, to_date=None):
        return [{"date": "2025-01-01", "marketCap": 2_500_000_000_000}]

    def sp500_constituent(self):
        return self.sp500_data

    def nasdaq_constituent(self):
        return [{"symbol": "AAPL"}]

    def dowjones_constituent(self):
        return [{"symbol": "AAPL"}]

    def stock_list(self):
        return [{"symbol": "AAPL"}, {"symbol": "TSLA"}]


class TestLoadCandidate:
    def test_basic_mapping(self):
        client = MockFMPClient()
        c = load_candidate(client, "AAPL")
        assert c.ticker == "AAPL"
        assert c.company_name == "Apple Inc."
        assert c.domicile == "US"
        assert c.gics_sector == "Technology"
        assert c.share_price == 175.50
        assert c.market_cap_usd == 2_800_000_000_000

    def test_exchange_mapping(self):
        client = MockFMPClient()
        c = load_candidate(client, "AAPL")
        assert c.exchange == "NASDAQ Global Select"

    def test_iwf_computation(self):
        client = MockFMPClient()
        c = load_candidate(client, "AAPL")
        assert c.iwf is not None
        assert abs(c.iwf - 15_000_000_000 / 15_500_000_000) < 0.001

    def test_free_float_pct(self):
        client = MockFMPClient()
        c = load_candidate(client, "AAPL")
        assert c.free_float_pct is not None
        assert c.free_float_pct > 90.0

    def test_earnings_summation(self):
        client = MockFMPClient()
        c = load_candidate(client, "AAPL")
        assert c.sum_4q_gaap_earnings == 91_000_000_000
        assert c.latest_quarter_earnings == 25_000_000_000

    def test_months_listed(self):
        client = MockFMPClient()
        c = load_candidate(client, "AAPL")
        assert c.months_listed is not None
        assert c.months_listed > 400  # IPO in 1980

    def test_in_sp500(self):
        client = MockFMPClient()
        c = load_candidate(client, "AAPL")
        assert c.in_sp500 is True

    def test_missing_profile_graceful(self):
        client = MockFMPClient()
        client.profile = lambda s: None
        c = load_candidate(client, "UNKNOWN")
        assert c.ticker == "UNKNOWN"
        assert c.company_name is None

    def test_missing_quote_graceful(self):
        client = MockFMPClient()
        client.quote = lambda s: None
        c = load_candidate(client, "AAPL")
        assert c.share_price is None

    def test_security_type_etf(self):
        client = MockFMPClient()
        client.profile_data[0]["isEtf"] = True
        c = load_candidate(client, "SPY")
        assert c.security_type == "ETF"


class TestLoadCandidates:
    def test_multiple_symbols(self):
        client = MockFMPClient()
        results = load_candidates(client, ["AAPL", "MSFT"])
        assert len(results) == 2

    def test_graceful_failure(self):
        """When all endpoints fail for a symbol, it still returns a partial Candidate."""
        client = MockFMPClient()
        # Even if profile fails, load_candidate catches it and returns a Candidate with Nones
        # So test that the result has None fields when profile fails
        client_bad = MockFMPClient()
        client_bad.profile = lambda s: (_ for _ in ()).throw(Exception("fail"))
        client_bad.quote = lambda s: (_ for _ in ()).throw(Exception("fail"))
        client_bad.shares_float = lambda s: (_ for _ in ()).throw(Exception("fail"))
        client_bad.income_statement = lambda s, **kw: (_ for _ in ()).throw(Exception("fail"))
        client_bad.historical_price_eod_full = lambda s, **kw: (_ for _ in ()).throw(Exception("fail"))
        client_bad.sp500_constituent = lambda: (_ for _ in ()).throw(Exception("fail"))
        c = load_candidate(client_bad, "BAD")
        assert c.ticker == "BAD"
        assert c.company_name is None
        assert c.market_cap_usd is None


class TestLoadConstituentSymbols:
    def test_sp500(self):
        client = MockFMPClient()
        symbols = load_constituent_symbols(client, "SP500")
        assert "AAPL" in symbols

    def test_ndx(self):
        client = MockFMPClient()
        symbols = load_constituent_symbols(client, "NDX")
        assert "AAPL" in symbols

    def test_unknown_index(self):
        client = MockFMPClient()
        symbols = load_constituent_symbols(client, "FTSE100")
        assert symbols == []
