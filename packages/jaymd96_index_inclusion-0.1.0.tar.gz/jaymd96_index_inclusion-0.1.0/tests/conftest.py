from __future__ import annotations

import pytest

from index_inclusion._types import Candidate, IndexCode


def make_candidate(**overrides) -> Candidate:
    """Factory for creating Candidate instances with realistic SP500-eligible defaults."""
    defaults = dict(
        ticker="TEST",
        company_name="Test Corp",
        domicile="US",
        exchange="NYSE",
        security_type="Common Stock",
        gics_sector="Technology",
        market_cap_usd=50_000_000_000,
        float_market_cap_usd=40_000_000_000,
        share_price=150.0,
        iwf=0.80,
        free_float_pct=80.0,
        float_adj_liquidity_ratio=1.5,
        min_monthly_volume_6m=500_000,
        avg_daily_traded_value_3m=20_000_000,
        avg_daily_dollar_volume=20_000_000,
        sum_4q_gaap_earnings=2_000_000_000,
        latest_quarter_earnings=600_000_000,
        months_listed=36.0,
        trading_days_since_listing=750,
        in_sp500=False,
        in_bankruptcy=False,
        pending_disqualifying_event=False,
        sec_filings_current=True,
        files_10K_10Q=True,
        market_cap_growth_1y=0.25,
    )
    defaults.update(overrides)
    return Candidate(**defaults)


@pytest.fixture
def sp500_eligible() -> Candidate:
    return make_candidate(ticker="ELIG")


@pytest.fixture
def ndx_eligible() -> Candidate:
    return make_candidate(
        ticker="NDXE",
        exchange="NASDAQ Global Select",
        icb_sector="Technology",
        gics_sector=None,
        months_listed=6.0,
        free_float_pct=50.0,
        in_bankruptcy=False,
        pending_disqualifying_event=False,
        sec_filings_current=True,
    )


@pytest.fixture
def ftse100_eligible() -> Candidate:
    return make_candidate(
        ticker="FTSE",
        domicile="UK",
        exchange="LSE Main Market",
        ftse_nationality="UK",
        trading_currency="GBP",
        free_float_pct=30.0,
        monthly_median_turnover_pct=0.05,
        trading_days_since_listing=100,
        unrestricted_voting_pct=20.0,
    )


@pytest.fixture
def ineligible_earnings() -> Candidate:
    return make_candidate(
        ticker="NOEAR",
        sum_4q_gaap_earnings=-500_000_000,
        latest_quarter_earnings=-100_000_000,
    )


@pytest.fixture
def ineligible_mcap() -> Candidate:
    return make_candidate(
        ticker="SMALL",
        market_cap_usd=5_000_000_000,
        float_market_cap_usd=3_000_000_000,
    )
