import pytest

from index_inclusion._indices import get_index_config
from index_inclusion._rules import evaluate_eligibility
from index_inclusion._signals import (
    margin_of_safety,
    momentum,
    queue_position,
    sector_fit,
    vacancy_likelihood,
)
from index_inclusion._types import IndexCode
from tests.conftest import make_candidate


class TestMarginOfSafety:
    def _margin_for_mcap(self, mcap: float, threshold: float = 22_700_000_000) -> float:
        c = make_candidate(market_cap_usd=mcap)
        config = get_index_config(IndexCode.SP500)
        _, results = evaluate_eligibility(IndexCode.SP500, c)
        return margin_of_safety(config.hard_rules, results)

    def test_at_threshold_gives_0_5(self):
        """ratio=1.0 → 0.500 per spec."""
        score = self._margin_for_mcap(22_700_000_000)
        # margin_of_safety is the mean of ALL rules, so we can't check exact 0.5
        # for the whole score, but the underlying formula should produce 0.5
        # for the market cap rule specifically. Test the full score is reasonable.
        assert 0.4 < score < 1.0

    def test_higher_mcap_higher_margin(self):
        low = self._margin_for_mcap(23_000_000_000)
        high = self._margin_for_mcap(100_000_000_000)
        assert high > low

    def test_formula_ge_ratios(self):
        """Verify the log curve formula directly."""
        from index_inclusion._signals import _margin_score_for_rule
        from index_inclusion._types import HardRule, Operator, RuleResult, RuleVerdict

        rule = HardRule("Test", "market_cap_usd", Operator.GE, 100)

        def score_at(value: float) -> float:
            result = RuleResult("Test", RuleVerdict.PASS, value, 100, "")
            s = _margin_score_for_rule(rule, result)
            assert s is not None
            return s

        assert abs(score_at(100) - 0.500) < 0.001  # 1.0x
        assert abs(score_at(150) - 0.667) < 0.001  # 1.5x
        assert abs(score_at(200) - 0.750) < 0.001  # 2.0x
        assert abs(score_at(500) - 0.900) < 0.001  # 5.0x
        assert abs(score_at(1000) - 0.950) < 0.001  # 10.0x

    def test_formula_le(self):
        """Test <= operator scoring."""
        from index_inclusion._signals import _margin_score_for_rule
        from index_inclusion._types import HardRule, Operator, RuleResult, RuleVerdict

        rule = HardRule("Cap", "market_cap_usd", Operator.LE, 100)

        # At threshold: ratio=1.0, score = 0.5 + 0.5*(1-1.0) = 0.5
        result = RuleResult("Cap", RuleVerdict.PASS, 100, 100, "")
        assert abs(_margin_score_for_rule(rule, result) - 0.5) < 0.001

        # Well below: ratio=0.5, score = 0.5 + 0.5*(1-0.5) = 0.75
        result2 = RuleResult("Cap", RuleVerdict.PASS, 50, 100, "")
        assert abs(_margin_score_for_rule(rule, result2) - 0.75) < 0.001

    def test_eq_in_not_in_score_1(self):
        from index_inclusion._signals import _margin_score_for_rule
        from index_inclusion._types import HardRule, Operator, RuleResult, RuleVerdict

        for op in (Operator.EQ, Operator.IN, Operator.NOT_IN):
            rule = HardRule("Test", "domicile", op, "US")
            result = RuleResult("Test", RuleVerdict.PASS, "US", "US", "")
            assert _margin_score_for_rule(rule, result) == 1.0

    def test_threshold_zero(self):
        from index_inclusion._signals import _margin_score_for_rule
        from index_inclusion._types import HardRule, Operator, RuleResult, RuleVerdict

        rule = HardRule("Earn", "sum_4q_gaap_earnings", Operator.GT, 0)
        pos = RuleResult("Earn", RuleVerdict.PASS, 1_000_000, 0, "")
        neg = RuleResult("Earn", RuleVerdict.FAIL, -1_000_000, 0, "")
        assert _margin_score_for_rule(rule, pos) == 1.0
        assert _margin_score_for_rule(rule, neg) == 0.0


class TestVacancyLikelihood:
    def test_ftse100_static_default(self):
        assert vacancy_likelihood(IndexCode.FTSE100) == 0.80

    def test_ndx_static_default(self):
        assert vacancy_likelihood(IndexCode.NDX) == 0.65

    def test_r3000_static_default(self):
        assert vacancy_likelihood(IndexCode.R3000) == 0.90

    def test_sp500_base_rate(self):
        assert vacancy_likelihood(IndexCode.SP500) == 0.45

    def test_djia_base_rate(self):
        assert vacancy_likelihood(IndexCode.DJIA) == 0.10

    def test_sp500_with_at_risk_constituents(self):
        # 2 of 10 constituents failing rules → risk_ratio = 0.2
        # score = min(0.95, 0.30 + 0.2 * 3.0) = min(0.95, 0.90) = 0.90
        good = [make_candidate(ticker=f"G{i}") for i in range(8)]
        bad = [
            make_candidate(ticker="B1", market_cap_usd=1_000_000),  # too small
            make_candidate(ticker="B2", domicile="UK"),  # wrong country
        ]
        score = vacancy_likelihood(IndexCode.SP500, good + bad)
        assert 0.5 < score <= 0.95


class TestQueuePosition:
    def test_with_pool_first(self):
        target = make_candidate(ticker="T1", market_cap_usd=100_000_000_000)
        others = [
            make_candidate(ticker="T2", market_cap_usd=80_000_000_000),
            make_candidate(ticker="T3", market_cap_usd=50_000_000_000),
        ]
        pool = [target] + others
        score = queue_position(target, pool)
        assert score > 0.8  # #1 of 3

    def test_with_pool_last(self):
        target = make_candidate(ticker="T1", market_cap_usd=10_000_000_000)
        others = [
            make_candidate(ticker="T2", market_cap_usd=80_000_000_000),
            make_candidate(ticker="T3", market_cap_usd=50_000_000_000),
        ]
        pool = [target] + others
        score = queue_position(target, pool)
        assert score < 0.5  # #3 of 3

    def test_single_candidate(self):
        c = make_candidate()
        assert queue_position(c, [c]) == 0.90

    def test_proxy_100b(self):
        c = make_candidate(market_cap_usd=150_000_000_000)
        assert queue_position(c) == 0.85

    def test_proxy_50b(self):
        c = make_candidate(market_cap_usd=60_000_000_000)
        assert queue_position(c) == 0.70

    def test_proxy_small(self):
        c = make_candidate(market_cap_usd=5_000_000_000)
        assert queue_position(c) == 0.25


class TestMomentum:
    def test_high_growth(self):
        assert momentum(make_candidate(market_cap_growth_1y=0.60)) == 0.95

    def test_moderate_growth(self):
        assert momentum(make_candidate(market_cap_growth_1y=0.25)) == 0.80

    def test_slight_growth(self):
        assert momentum(make_candidate(market_cap_growth_1y=0.10)) == 0.65

    def test_flat(self):
        assert momentum(make_candidate(market_cap_growth_1y=0.0)) == 0.50

    def test_moderate_decline(self):
        assert momentum(make_candidate(market_cap_growth_1y=-0.10)) == 0.30

    def test_severe_decline(self):
        assert momentum(make_candidate(market_cap_growth_1y=-0.30)) == 0.10

    def test_unknown(self):
        assert momentum(make_candidate(market_cap_growth_1y=None)) == 0.50


class TestSectorFit:
    def test_no_constituents_neutral(self):
        c = make_candidate(gics_sector="Technology")
        assert sector_fit(c, IndexCode.SP500) == 0.50

    def test_under_represented(self):
        c = make_candidate(gics_sector="Energy")
        # 10 constituents, 9 Technology, 1 Healthcare → Energy is 0%, avg = 50%
        constituents = [make_candidate(ticker=f"T{i}", gics_sector="Technology") for i in range(9)]
        constituents.append(make_candidate(ticker="H1", gics_sector="Healthcare"))
        score = sector_fit(c, IndexCode.SP500, constituents)
        assert score == 0.85  # significantly under-represented

    def test_over_represented(self):
        c = make_candidate(gics_sector="Technology")
        constituents = [make_candidate(ticker=f"T{i}", gics_sector="Technology") for i in range(9)]
        constituents.append(make_candidate(ticker="H1", gics_sector="Healthcare"))
        score = sector_fit(c, IndexCode.SP500, constituents)
        assert score == 0.30  # over-represented

    def test_uses_icb_for_ndx(self):
        c = make_candidate(icb_sector="Technology", gics_sector=None)
        constituents = [
            make_candidate(ticker=f"T{i}", icb_sector="Technology") for i in range(5)
        ] + [
            make_candidate(ticker=f"H{i}", icb_sector="Healthcare") for i in range(5)
        ]
        score = sector_fit(c, IndexCode.NDX, constituents)
        # 50% tech, avg = 50% → roughly balanced
        assert score == 0.50
