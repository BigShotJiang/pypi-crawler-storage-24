from index_inclusion._types import (
    Candidate,
    Confidence,
    HardRule,
    IndexCode,
    Operator,
    ProbabilityLabel,
    RuleResult,
    RuleVerdict,
    SignalValues,
)


def test_candidate_defaults():
    c = Candidate(ticker="AAPL")
    assert c.ticker == "AAPL"
    assert c.market_cap_usd is None
    assert c.domicile is None


def test_candidate_frozen():
    c = Candidate(ticker="AAPL")
    try:
        c.ticker = "MSFT"  # type: ignore[misc]
        assert False, "Should raise"
    except AttributeError:
        pass


def test_index_code_values():
    assert IndexCode.SP500.value == "SP500"
    assert IndexCode.NDX.value == "NDX"
    assert IndexCode("FTSE100") is IndexCode.FTSE100


def test_operator_values():
    assert Operator.GE.value == ">="
    assert Operator.NOT_IN.value == "not_in"


def test_rule_verdict():
    assert RuleVerdict.PASS.value == "PASS"
    assert RuleVerdict.SKIP.value == "SKIP"


def test_probability_labels():
    assert ProbabilityLabel.VERY_HIGH.value == "Very High"
    assert ProbabilityLabel.INELIGIBLE.value == "Ineligible"


def test_signal_values_frozen():
    s = SignalValues(0.9, 0.5, 0.8, 0.7, 0.6)
    assert s.margin_of_safety == 0.9
    try:
        s.momentum = 0.0  # type: ignore[misc]
        assert False
    except AttributeError:
        pass
