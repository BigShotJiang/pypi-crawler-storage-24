# jaymd96-index-inclusion

Stock index inclusion probability prediction. Screens stocks against eligibility rules for 7 major indices (S&P 500, S&P 400, S&P 600, NASDAQ-100, FTSE 100, DJIA, Russell 3000), scores candidates with heuristic signals, and optionally refines predictions with ML.

## Install

```bash
pip install jaymd96-index-inclusion
```

## Quick Start

```python
from index_inclusion import IndexInclusion

ii = IndexInclusion(fmp_api_key="your-key")

# Check a single stock
result = ii.check("PLTR", "SP500")
print(f"{result.ticker}: {result.probability:.1%} ({result.probability_label})")

# Find top candidates for an index
candidates = ii.candidates("SP500", top_n=10)
for c in candidates:
    print(f"{c.ticker}: {c.probability:.1%}")

# Backtest prediction accuracy
report = ii.backtest("SP500", start=2016, end=2025)
print(f"Precision@3: {report.precision_at_3:.1%}")

# Train ML models
ii.train("SP500", start=2016, end=2023)
candidates = ii.candidates("SP500")  # now uses ML calibration
```

## License

MIT
