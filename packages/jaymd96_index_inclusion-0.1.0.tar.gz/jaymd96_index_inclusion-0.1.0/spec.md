# Index Inclusion Candidate Selector — Complete Implementation Specification

**Version 1.1 — March 2026**

Everything a programmer needs to build an automated system that: (1) screens stocks against real index eligibility rules, (2) models vacancy mechanics, (3) ranks candidates by probability of inclusion, and (4) optionally refines predictions with machine learning.

---

## Table of Contents

- [Part 1: Architecture Overview](#part-1-architecture-overview)
- [Part 2: Data Schema](#part-2-data-schema)
- [Part 3: Index Eligibility Rules](#part-3-index-eligibility-rules)
  - [3.1 S&P 500](#31-sp-500)
  - [3.2 S&P MidCap 400](#32-sp-midcap-400)
  - [3.3 S&P SmallCap 600](#33-sp-smallcap-600)
  - [3.4 NASDAQ-100](#34-nasdaq-100-ndx)
  - [3.5 FTSE 100](#35-ftse-100)
  - [3.6 Dow Jones Industrial Average](#36-dow-jones-industrial-average-djia)
  - [3.7 Russell 3000 / 1000 / 2000](#37-russell-3000--1000--2000)
- [Part 4: Vacancy Mechanics](#part-4-vacancy-mechanics)
- [Part 5: Probability Model](#part-5-probability-model)
  - [5.1 Three-Stage Architecture](#51-three-stage-architecture)
  - [5.2 Signal 1 — Margin of Safety](#52-signal-1--margin-of-safety-30-weight)
  - [5.3 Signal 2 — Vacancy Likelihood](#53-signal-2--vacancy-likelihood-25-weight)
  - [5.4 Signal 3 — Queue Position](#54-signal-3--queue-position-25-weight)
  - [5.5 Signal 4 — Momentum](#55-signal-4--momentum-10-weight)
  - [5.6 Signal 5 — Sector Fit](#56-signal-5--sector-fit-10-weight)
  - [5.7 Final Score Calculation](#57-final-score-calculation)
  - [5.8 Confidence Rating](#58-confidence-rating)
  - [5.9 Probability Labels](#59-probability-labels)
- [Part 6: Output Schema](#part-6-output-schema)
- [Part 7: Source Documents](#part-7-source-documents)
- [Part 8: Comparative Quick Reference](#part-8-comparative-quick-reference)
- [Part 9: Implementation Notes](#part-9-implementation-notes)
- [Part 10: Machine Learning Layer](#part-10-machine-learning-layer)
  - [10.1 Where ML Adds Value vs. Where It Doesn't](#101-where-ml-adds-value-vs-where-it-doesnt)
  - [10.2 ML Use Case 1 — Committee Decision Prediction](#102-ml-use-case-1--committee-decision-prediction)
  - [10.3 ML Use Case 2 — Vacancy Timing Prediction](#103-ml-use-case-2--vacancy-timing-prediction)
  - [10.4 ML Use Case 3 — Signal Weight Optimisation](#104-ml-use-case-3--signal-weight-optimisation)
  - [10.5 Three-Stage Hybrid Architecture](#105-three-stage-hybrid-architecture)
  - [10.6 Training Data Construction](#106-training-data-construction)
  - [10.7 Model Selection Guidance](#107-model-selection-guidance)
  - [10.8 Evaluation & Backtesting](#108-evaluation--backtesting)
  - [10.9 When NOT to Use ML](#109-when-not-to-use-ml)

---

## Part 1: Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                  CANDIDATE UNIVERSE                      │
│         (all stocks from exchanges / data feed)          │
└──────────────────────┬──────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────┐
│              STAGE 1: ELIGIBILITY GATE                    │
│                                                          │
│  For each (candidate, target_index) pair:                │
│    1. Load the index's hard rules                        │
│    2. Evaluate every rule against candidate data          │
│    3. Verdict: ALL hard rules pass → eligible             │
│               ANY hard rule fails → ineligible (prob=0)   │
│                                                          │
│  Output: eligible (bool), rule_results[]                  │
└──────────────────────┬──────────────────────────────────┘
                       │ eligible candidates only
                       ▼
┌─────────────────────────────────────────────────────────┐
│            STAGE 2: HEURISTIC SCORING                    │
│                                                          │
│  Five weighted signals:                                   │
│    ┌─────────────────────┬────────┐                      │
│    │ Margin of Safety    │  30%   │                      │
│    │ Vacancy Likelihood  │  25%   │                      │
│    │ Queue Position      │  25%   │                      │
│    │ Momentum            │  10%   │                      │
│    │ Sector Fit          │  10%   │                      │
│    └─────────────────────┴────────┘                      │
│                                                          │
│  base_prob = Σ(weight_i × signal_i), clamped [0, 1]      │
│                                                          │
│  Output: base_probability, signal_values[]                │
└──────────────────────┬──────────────────────────────────┘
                       │
                       ▼
┌ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─┐
│    STAGE 3: ML CALIBRATION LAYER  (optional)             │
│                                                          │
│  Three targeted ML models:                                │
│    1. Committee prediction  (S&P 500, DJIA only)         │
│    2. Vacancy timing        (vacancy-required indices)   │
│    3. Weight optimisation   (all indices)                 │
│                                                          │
│  Input: 5 signal values + additional ML features          │
│  Output: calibrated_probability (float)                   │
│                                                          │
│  Falls back to Stage 2 output if ML models not trained    │
└ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┬ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────┐
│                 RANKED OUTPUT                             │
│  Candidates sorted by probability (descending)           │
│  With: eligibility details, signal breakdown,             │
│        vacancy context, confidence rating,                │
│        ML adjustment (if applied)                         │
└─────────────────────────────────────────────────────────┘
```

---

## Part 2: Data Schema

### 2.1 Candidate Input Fields

Every candidate stock must be represented as a flat key-value record. All fields are optional — missing fields cause the corresponding rule to be `SKIP`ped (not failed), and reduce the confidence rating.

| Field | Type | Unit | Definition |
|-------|------|------|-----------|
| `ticker` | string | — | Stock ticker symbol |
| `company_name` | string | — | Full company name |
| `domicile` | string | — | Country of domicile as determined by the index provider ("US", "UK", etc.) |
| `exchange` | string | — | Primary exchange listing. Must match exact values used in rules (see §3) |
| `security_type` | string | — | "Common Stock", "REIT", etc. |
| `gics_sector` | string | — | GICS sector classification (for S&P/DJIA indices) |
| `icb_sector` | string | — | ICB sector classification (for NASDAQ/FTSE indices) |
| `ftse_nationality` | string | — | Nationality assigned by FTSE Russell (for FTSE 100) |
| `trading_currency` | string | — | Currency the stock trades in on its primary exchange |
| `market_cap_usd` | float | USD | Total company-level market capitalisation (all share classes combined) |
| `float_market_cap_usd` | float | USD | Security-level float-adjusted market cap = price × float-adjusted shares |
| `share_price` | float | USD | Last closing price |
| `iwf` | float | ratio 0–1 | Investable Weight Factor: float shares ÷ total shares outstanding |
| `free_float_pct` | float | % | Percentage of shares available to ordinary investors (= IWF × 100) |
| `float_adj_liquidity_ratio` | float | ratio | Annual dollar value traded ÷ float-adjusted market cap |
| `min_monthly_volume_6m` | int | shares | Minimum shares traded in any single month of the prior 6 months |
| `avg_daily_traded_value_3m` | float | USD | 3-month average of (daily close × daily volume) |
| `avg_daily_dollar_volume` | float | USD | Average daily dollar volume (for Russell: vs global median) |
| `monthly_median_turnover_pct` | float | % | Monthly median of (daily volume ÷ free-float shares) × 100 |
| `sum_4q_gaap_earnings` | float | USD | Sum of most recent 4 quarters' GAAP net income (excl. discontinued ops) |
| `latest_quarter_earnings` | float | USD | Most recent single quarter's GAAP net income |
| `months_listed` | float | months | Months since first trading day on an eligible exchange |
| `trading_days_since_listing` | int | days | Business days since first trading on an eligible exchange |
| `unrestricted_voting_pct` | float | % | % of total voting rights held by unrestricted shareholders |
| `in_sp500` | bool | — | Is the stock currently an S&P 500 constituent? |
| `in_bankruptcy` | bool | — | Currently in bankruptcy proceedings? |
| `pending_disqualifying_event` | bool | — | Definitive agreement to be acquired, delist, etc.? |
| `sec_filings_current` | bool | — | Are SEC filings up to date (no delinquencies)? |
| `files_10K_10Q` | bool | — | Does the company file domestic-issuer forms (10-K, 10-Q, 8-K)? |
| `market_cap_growth_1y` | float | ratio | 1-year market cap change as decimal (0.25 = +25%, -0.10 = -10%) |

### 2.2 Eligible Exchange Values

Use these exact strings when populating the `exchange` field:

| Index Family | Eligible Exchange Values |
|-------------|------------------------|
| S&P 500/400/600 | `"NYSE"`, `"NYSE Arca"`, `"NYSE American"`, `"NASDAQ Global Select"`, `"NASDAQ Global Market"`, `"NASDAQ Capital Market"`, `"Cboe BZX"`, `"Cboe BYX"`, `"Cboe EDGA"`, `"Cboe EDGX"` |
| NASDAQ-100 | `"NASDAQ Global Select"`, `"NASDAQ Global Market"` (only — Capital Market is NOT eligible) |
| FTSE 100 | `"LSE Main Market"` |
| Russell | Same as S&P (all major US exchanges) |

### 2.3 Security Type Values

| Eligible | Ineligible |
|----------|-----------|
| `"Common Stock"`, `"REIT"` | `"BDC"`, `"LP"`, `"MLP"`, `"LLC"`, `"Closed-end fund"`, `"ETF"`, `"ETN"`, `"Royalty trust"`, `"SPAC"`, `"Preferred stock"`, `"ADR"`, `"Warrant"`, `"Convertible preferred"`, `"Unit trust"`, `"Right"`, `"Tracking stock"` |

---

## Part 3: Index Eligibility Rules

### Rule Evaluation Logic

Each hard rule has:
- `field`: which candidate data field to read
- `operator`: one of `>=`, `<=`, `>`, `<`, `==`, `in`, `not_in`, `between`
- `threshold`: the value to compare against

Evaluation pseudocode:
```
function evaluate_rule(rule, candidate):
    value = candidate[rule.field]
    if value is null:
        return SKIP                    # data not available

    if rule.operator == ">=":  return value >= rule.threshold ? PASS : FAIL
    if rule.operator == "<=":  return value <= rule.threshold ? PASS : FAIL
    if rule.operator == ">":   return value > rule.threshold ? PASS : FAIL
    if rule.operator == "<":   return value < rule.threshold ? PASS : FAIL
    if rule.operator == "==":  return value == rule.threshold ? PASS : FAIL
    if rule.operator == "in":  return value in rule.threshold ? PASS : FAIL
    if rule.operator == "not_in": return value not in rule.threshold ? PASS : FAIL

function is_eligible(index_code, candidate):
    for rule in index_rules[index_code].hard_rules:
        result = evaluate_rule(rule, candidate)
        if result == FAIL:
            return false
    return true    # SKIP results do NOT cause failure
```

---

### 3.1 S&P 500

**Code:** `SP500` · **Provider:** S&P Dow Jones Indices · **Country:** US · **Count:** 500 (fixed) · **Weighting:** Float-adjusted market cap · **Review:** As-needed (no schedule) · **Selection:** Committee-driven

#### Hard Rules

| # | Rule Name | Field | Op | Threshold | Unit | Notes |
|---|-----------|-------|----|-----------|------|-------|
| 1 | Market Capitalisation | `market_cap_usd` | `>=` | `22,700,000,000` | USD | As of July 2025. Was $18B (pre-2025), $20.5B (Jan 2025). Reviewed quarterly; targets 85th percentile of S&P TMI. |
| 2 | Float-Adjusted Market Cap | `float_market_cap_usd` | `>=` | `11,350,000,000` | USD | Must be ≥ 50% of the min market cap ($22.7B × 0.50). |
| 3 | Investable Weight Factor | `iwf` | `>=` | `0.10` | ratio | Proportion of shares publicly available. |
| 4 | Liquidity — FALR | `float_adj_liquidity_ratio` | `>=` | `0.75` | ratio | Annual dollar value traded ÷ float-adjusted market cap. 365-day lookback. |
| 5 | Liquidity — Monthly Volume | `min_monthly_volume_6m` | `>=` | `250,000` | shares | Each of the 6 prior months must individually meet this. |
| 6 | Earnings — Trailing 4Q | `sum_4q_gaap_earnings` | `>` | `0` | USD | GAAP net income excl. discontinued ops. Equity REITs: FFO may substitute. |
| 7 | Earnings — Latest Quarter | `latest_quarter_earnings` | `>` | `0` | USD | Most recent single quarter must also be positive. |
| 8 | IPO Seasoning | `months_listed` | `>=` | `12` | months | No fast-track. Spin-offs from constituents exempt. Former SPACs: 12 months post de-SPAC. |
| 9 | Domicile | `domicile` | `==` | `"US"` | — | Per S&P DJI domicile rules. |
| 10 | Exchange Listing | `exchange` | `in` | See §2.2 (S&P list) | — | OTC excluded. |
| 11 | Security Type | `security_type` | `in` | `["Common Stock", "REIT"]` | — | See §2.3 for exclusions. |
| 12 | SEC Filing Type | `files_10K_10Q` | `==` | `true` | — | Must file 10-K, 10-Q, 8-K. Foreign filers (20-F/6-K) ineligible. |

#### Soft Rules (informational — cannot be auto-tested)

- **Sector Balance:** Sector weight should approximate that sector's weight in S&P TMI for the large-cap range.
- **Committee Discretion:** Meeting all hard rules does not guarantee inclusion.
- **Multiple Share Classes:** Company-level market cap for eligibility; each share line's FMC for its own weight.

---

### 3.2 S&P MidCap 400

**Code:** `SP400` · **Count:** 400 (fixed) · Identical to S&P 500 **except** for market cap band.

#### Market Cap Rules (replacing S&P 500 rules #1–2)

| # | Rule Name | Field | Op | Threshold | Notes |
|---|-----------|-------|----|-----------|-------|
| 1 | Market Cap (Lower) | `market_cap_usd` | `>=` | `8,000,000,000` | Targets 85th–93rd percentile of S&P TMI. |
| 2 | Market Cap (Upper) | `market_cap_usd` | `<=` | `22,700,000,000` | Upper bound = S&P 500 lower bound. |
| 3 | FMC ≥ 50% of Min | `float_market_cap_usd` | `>=` | `4,000,000,000` | 50% of $8.0B. |

All other rules (IWF, FALR, volume, earnings, seasoning, domicile, exchange, security type, filing) are identical to S&P 500.

---

### 3.3 S&P SmallCap 600

**Code:** `SP600` · **Count:** 600 (fixed) · Identical to S&P 500 **except** for market cap band.

#### Market Cap Rules (replacing S&P 500 rules #1–2)

| # | Rule Name | Field | Op | Threshold | Notes |
|---|-----------|-------|----|-----------|-------|
| 1 | Market Cap (Lower) | `market_cap_usd` | `>=` | `1,200,000,000` | Targets 93rd–99th percentile of S&P TMI. |
| 2 | Market Cap (Upper) | `market_cap_usd` | `<=` | `8,000,000,000` | Upper bound = S&P MidCap 400 lower bound. |
| 3 | FMC ≥ 50% of Min | `float_market_cap_usd` | `>=` | `600,000,000` | 50% of $1.2B. |

#### Migration Rule

Existing S&P 1500 constituents migrating between 500/400/600 only need to meet the market cap threshold for the new index. They are **exempt** from earnings, liquidity, and FMC-50% rules.

---

### 3.4 NASDAQ-100 (NDX)

**Code:** `NDX` · **Provider:** Nasdaq Inc. · **Country:** US + international non-financials · **Count:** 100 · **Weighting:** Modified market cap (capped) · **Review:** Quarterly rebalance · **Reconstitution:** Annual (December)

#### Hard Rules

| # | Rule Name | Field | Op | Threshold | Notes |
|---|-----------|-------|----|-----------|-------|
| 1 | Exchange Listing | `exchange` | `in` | `["NASDAQ Global Select", "NASDAQ Global Market"]` | Must be exclusively Nasdaq-listed. Dual-listing on NYSE disqualifies. Capital Market NOT eligible. |
| 2 | No Financials | `icb_sector` | `not_in` | `["Financials", "Banks", "Insurance", "Financial Services"]` | Per ICB classification. |
| 3 | IPO Seasoning | `months_listed` | `>=` | `3` | Full calendar months. Proposed fast-entry (Feb 2026): top-40 by mcap exempt. |
| 4 | Avg Daily Traded Value | `avg_daily_traded_value_3m` | `>=` | `5,000,000` | USD. Changed from volume-based to dollar-based June 2024. |
| 5 | Free Float | `free_float_pct` | `>=` | `10.0` | %. Proposed (Feb 2026): 10–20% weighted at reduced rate; <10% ineligible. |
| 6 | Not in Bankruptcy | `in_bankruptcy` | `==` | `false` | — |
| 7 | No Pending Disqualification | `pending_disqualifying_event` | `==` | `false` | No agreement to be acquired, delist, reorganise, or cease operations. |
| 8 | Current Filings | `sec_filings_current` | `==` | `true` | No delinquent SEC filings. |

#### Reconstitution (Annual — December)

1. All eligible companies ranked by combined market cap of eligible share classes.
2. Top 75 by rank are auto-selected (regardless of current membership).
3. Current members ranked 76–100 retained if they were top-100 at prior reconstitution.
4. Current members ranked 101–125 retained if previously top-100, or added as replacement/spin-off.
5. Remaining slots filled by highest-ranked non-members.

#### Weight Caps

- Single company: max 24%.
- Companies above 4.5% individually: collectively max 48%.

#### Removal Between Reconstitutions

- **Current rule:** Constituent with < 0.10% weight for 2 consecutive month-ends AND ranked outside top 100 → removed. Replaced by largest eligible non-member.
- **Proposed (Feb 2026):** Replace with quarterly rank-based removal if outside top 125.

---

### 3.5 FTSE 100

**Code:** `FTSE100` · **Provider:** FTSE Russell (LSEG) · **Country:** UK · **Count:** 100 (fixed) · **Weighting:** Free-float-adjusted market cap · **Review:** Quarterly (Mar, Jun, Sep, Dec) · **Reconstitution:** Annual full review (June)

#### Hard Rules

| # | Rule Name | Field | Op | Threshold | Notes |
|---|-----------|-------|----|-----------|-------|
| 1 | UK Nationality | `ftse_nationality` | `==` | `"UK"` | UK-incorporated + LSE eligible listing + ≥10% free float + pass liquidity → UK. Non-UK sole LSE listings: ≥25% float + UK Governance Code. |
| 2 | Exchange Listing | `exchange` | `in` | `["LSE Main Market"]` | Equity Shares (Commercial Companies) or Closed-ended investment fund categories. |
| 3 | Trading Currency | `trading_currency` | `in` | `["GBP", "EUR", "USD"]` | From Sept 2025. Previously GBP only. |
| 4 | Free Float | `free_float_pct` | `>=` | `10.0` | For UK-incorporated. Non-UK sole listings: ≥25%. |
| 5 | Liquidity — Turnover | `monthly_median_turnover_pct` | `>=` | `0.025` | % of free-float shares. Must pass ≥10 of 12 months before annual review. |
| 6 | Min Trading Record | `trading_days_since_listing` | `>=` | `20` | Trading days before a quarterly review for new issues. |
| 7 | Voting Rights | `unrestricted_voting_pct` | `>` | `5.0` | % across all equity securities. Non-voting shares = zero power. |

#### Rank-Based Inclusion / Exclusion (Quarterly)

Ranking uses **FULL (unadjusted) market cap**, not float-adjusted.

| Trigger | Rank | Action |
|---------|------|--------|
| Auto-Include | ≤ 90 | Non-constituent is ADDED |
| Buffer Zone | 91–110 | No change forced |
| Auto-Exclude | ≥ 111 | Constituent is REMOVED |

The count is maintained at exactly 100. If more qualify to enter than leave, the lowest-ranking current members are removed to balance (and vice versa).

#### Fast Entry (IPO) — from September 2025

IPO ranking **225th or above** by full market cap on first day + investable market cap **≥ GBP 1 billion**:
- Rank ≤ 90 → enters FTSE 100 after close on 5th trading day
- Rank 91–225 → enters FTSE 250 after close on 5th trading day

Lowest-ranked constituent is concurrently removed.

---

### 3.6 Dow Jones Industrial Average (DJIA)

**Code:** `DJIA` · **Provider:** S&P Dow Jones Indices · **Count:** 30 (fixed) · **Weighting:** Price-weighted · **Review:** As-needed · **Selection:** 5-member Averages Committee (3 S&P DJI + 2 WSJ)

#### Hard Rules

| # | Rule Name | Field | Op | Threshold | Notes |
|---|-----------|-------|----|-----------|-------|
| 1 | S&P 500 Membership | `in_sp500` | `==` | `true` | Implicitly requires passing all S&P 500 hard rules. |
| 2 | Sector Exclusion | `gics_sector` | `not_in` | `["Transportation", "Utilities"]` | Covered by DJ Transportation/Utility Averages. |
| 3 | Domicile | `domicile` | `==` | `"US"` | Incorporated and HQ'd in US; plurality of revenues from US. |

#### Soft Rules (entirely qualitative)

- Excellent reputation
- Sustained growth
- Broad investor interest
- Stock price level suitable for a price-weighted index
- Sector representation across 30 stocks
- **Full committee discretion** — the methodology explicitly states selection is "NOT governed by quantitative rules"

---

### 3.7 Russell 3000 / 1000 / 2000

**Code:** `R3000` · **Provider:** FTSE Russell (LSEG) · **Country:** US · **Count:** ~4,000 (3000E) / 1,000 (R1000) / 2,000 (R2000) · **Weighting:** Float-adjusted market cap · **Reconstitution:** Semi-annual from 2026 (rank day: last trading day of May) · **Selection:** 100% rules-based — NO committee

#### Hard Rules

| # | Rule Name | Field | Op | Threshold | Notes |
|---|-----------|-------|----|-----------|-------|
| 1 | Minimum Market Cap | `market_cap_usd` | `>=` | `30,000,000` | Absolute floor. Effective min = mcap of ~4,000th largest US company on rank day. |
| 2 | Share Price | `share_price` | `>=` | `1.00` | On primary exchange, last trading day of May. |
| 3 | Free Float | `free_float_pct` | `>` | `5.0` | Strict: 5% or less = excluded. |
| 4 | Liquidity (ADDTV) | `avg_daily_dollar_volume` | `>=` | `0` | RELATIVE threshold: must exceed global median ADDTV, recalculated each rank day. No fixed dollar value. |
| 5 | US Domicile | `domicile` | `==` | `"US"` | Incorporation + HQ + exchange in same country. If ambiguous: plurality of assets/revenues. |

#### Segmentation

On rank day, all eligible companies ranked by total market cap:
- **Russell 3000E:** Top ~4,000 (broadest, ~99% of investable US equity)
- **Russell 3000:** Top 3,000 (~98%)
- **Russell 1000:** Top 1,000 (large-cap)
- **Russell 2000:** Ranks 1,001–3,000 (small-cap)

#### Banding (R1000 ↔ R2000)

A 5-percentile band around the breakpoint prevents churn. Existing members only move if market cap shifts >2.5 percentile points past the breakpoint. No band at the bottom of R2000.

#### Key Differences from S&P

- **No committee.** Purely mechanical.
- **No earnings requirement.** Unprofitable companies can be included.
- **Dynamic breakpoints.** The R1000/R2000 boundary moves with the market.

---

## Part 4: Vacancy Mechanics

This is critical for the probability model. The question: **does someone need to leave before a new stock can join?**

| Index | Fixed Count | Requires Vacancy? | Primary Mechanism | Turnover Rate |
|-------|------------|-------------------|-------------------|---------------|
| **S&P 500** | Yes (500) | **YES** | Committee fills vacancies from M&A, delistings, bankruptcies, migrations. Additions are *reactive*. | ~20–25 changes/year |
| **S&P 400** | Yes (400) | **YES** | Same + migrations up to 500 or down to 600 | ~30/year |
| **S&P 600** | Yes (600) | **YES** | Same + migrations up to 400 | ~35/year |
| **NDX** | Yes (100) | **NO** (at reconstitution) | Annual December reconstitution re-ranks top 75 auto-select; weaker members displaced. Between reconstitutions: vacancy required. | ~5–10/year |
| **FTSE 100** | Yes (100) | **NO** | Quarterly rank-based displacement: rank ≤90 enters, rank ≥111 exits. Most transparent system. | ~5–10/year |
| **DJIA** | Yes (30) | **YES** | Fully discretionary committee. Changes are rare. | ~1–2/year |
| **Russell** | ~Fixed | **NO** | Semi-annual reconstitution re-ranks all US equities. You either make the top ~4,000 or you don't. | Hundreds/year |

### Vacancy Detail per Index

#### S&P 500 / 400 / 600

Vacancy sources: M&A (target removed), delistings, bankruptcy, migration between 500↔400↔600, reclassification to ineligible type. Spin-offs may temporarily push count above target. **The committee maintains an unofficial watch-list.** Additions are reactive (fill a vacancy), not proactive (displace a weak member). A stock can underperform for years without removal.

#### NASDAQ-100

Dual model: (a) Annual reconstitution in December is a displacement mechanism — top 75 auto-selected regardless of current membership. (b) Between reconstitutions, removal only via the 10bp rule or delisting, and the largest eligible non-member replaces. Spin-offs added without removal (count temporarily >100). Proposed fast-entry (Feb 2026): top-40 mcap IPOs added without removal.

#### FTSE 100

Explicit rank-based displacement every quarter. Equal adds and deletes to maintain exactly 100. Fast-entry IPOs explicitly displace the lowest-ranked constituent on the 5th trading day. No committee discretion in this process.

#### DJIA

Fully discretionary. The 5-member committee decides when and what to swap. They often replace multiple stocks at once. Stock price level matters because the index is price-weighted. Changes average 1–2 per year but can be 0 in a quiet year.

#### Russell

Pure ranking. At reconstitution, the top ~4,000 US companies form the Russell 3000E. No buffer at the bottom — you're either big enough or not. IPOs added quarterly if they rank within the established breakpoints. Count can vary by a few dozen. No committee.

---

## Part 5: Probability Model

### 5.1 Three-Stage Architecture

```
STAGE 1: is_eligible(index_code, candidate) → bool
    If false → probability = 0.0, label = "Ineligible"
    If true  → proceed to Stage 2

STAGE 2: score(index_code, candidate, context) → float [0.0, 1.0]
    base_probability = clamp(
        0.30 × margin_score
      + 0.25 × vacancy_score
      + 0.25 × queue_score
      + 0.10 × momentum_score
      + 0.10 × sector_score
    , 0.0, 1.0)

STAGE 3 (optional): ml_calibrate(base_probability, signals, features) → float [0.0, 1.0]
    If ML models are trained and available:
        calibrated_probability = ml_model.predict(features)
    Else:
        calibrated_probability = base_probability   # graceful fallback
```

> **Stage 3 is optional.** The system produces useful results with Stages 1–2 alone. Stage 3 adds value primarily for committee-driven indices (S&P 500, DJIA). See [Part 10: Machine Learning Layer](#part-10-machine-learning-layer) for full implementation details.

### 5.2 Signal 1 — Margin of Safety (30% weight)

**Question:** How comfortably does the candidate exceed each hard threshold?

**Algorithm:** For each numeric hard rule, compute a ratio and apply a logarithmic curve.

```
For each hard rule where operator is >= or > and threshold is numeric:

    if threshold == 0:
        score_i = 1.0 if value > 0 else 0.0
    else:
        ratio = value / threshold
        if ratio < 1.0:
            score_i = 0.0          # below threshold
        else:
            score_i = min(1.0, 0.5 + 0.5 × (1 - 1/ratio))

For each hard rule where operator is <= or < and threshold is numeric:

    if threshold == 0:
        score_i = 1.0 if value <= 0 else 0.0
    else:
        ratio = value / threshold
        if ratio > 1.0:
            score_i = 0.0          # above cap
        else:
            score_i = min(1.0, 0.5 + 0.5 × (1 - ratio))

For each hard rule where operator is ==, in, or not_in:
    score_i = 1.0              # binary — already passed eligibility

margin_score = mean(all score_i values)
    If no numeric rules evaluated: margin_score = 0.5
```

**Resulting curve for `>=` rules:**

| ratio (value / threshold) | margin score |
|--------------------------|-------------|
| 1.0× (exactly at threshold) | 0.500 |
| 1.5× | 0.667 |
| 2.0× | 0.750 |
| 5.0× | 0.900 |
| 10.0× | 0.950 |
| 100.0× | 0.995 |

### 5.3 Signal 2 — Vacancy Likelihood (25% weight)

**Question:** How likely is a slot to open in the next review cycle?

**Algorithm:** Depends on the index's vacancy mechanics.

#### For indices that do NOT require a vacancy (displacement / reconstitution):

| Index | Default Vacancy Score | Rationale |
|-------|----------------------|-----------|
| `FTSE100` | 0.80 | Quarterly rank displacement is structural |
| `NDX` | 0.65 | Annual reconstitution guarantees some turnover |
| `R3000` | 0.90 | Semi-annual full re-ranking |
| Other | 0.70 | Default for displacement indices |

#### For indices that DO require a vacancy:

**If current constituent data IS provided:**
```
at_risk = count of current constituents failing ≥1 hard rule
risk_ratio = at_risk / total_constituents
vacancy_score = min(0.95, 0.30 + risk_ratio × 3.0)
```

**If current constituent data is NOT provided (fallback base rates):**

| Index | Base Rate | Rationale |
|-------|-----------|-----------|
| `SP500` | 0.45 | ~20–25 changes/year in 500-stock index |
| `SP400` | 0.50 | Higher turnover from migration |
| `SP600` | 0.55 | Highest S&P turnover |
| `DJIA` | 0.10 | ~1–2 changes/year in 30-stock index |
| Other | 0.40 | Conservative default |

### 5.4 Signal 3 — Queue Position (25% weight)

**Question:** Where does the candidate rank among all eligible non-members?

#### If a list of eligible non-members IS provided:

```
Sort all eligible non-members by market_cap_usd descending.
Find the candidate's 1-indexed position in this sorted list.

queue_score = max(0.05, 1.0 - (position - 1) / total_in_pool)

If pool has only 1 candidate: queue_score = 0.90
```

#### If no eligible non-member list provided (market-cap proxy):

| Market Cap | Queue Score |
|-----------|-------------|
| ≥ $100B | 0.85 |
| ≥ $50B | 0.70 |
| ≥ $25B | 0.55 |
| ≥ $10B | 0.40 |
| < $10B | 0.25 |

### 5.5 Signal 4 — Momentum (10% weight)

**Question:** Is the candidate's market cap growing or shrinking?

**Field:** `market_cap_growth_1y` (decimal: 0.25 = +25%)

| 1-Year Market Cap Growth | Momentum Score |
|-------------------------|---------------|
| > +50% | 0.95 |
| > +20% | 0.80 |
| > +5% | 0.65 |
| -5% to +5% (flat) | 0.50 |
| > -20% | 0.30 |
| ≤ -20% | 0.10 |
| Unknown (field missing) | 0.50 |

### 5.6 Signal 5 — Sector Fit (10% weight)

**Question:** Does the candidate fill an under-represented sector in the current index?

**Field:** `gics_sector` (for S&P/DJIA) or `icb_sector` (for NDX/FTSE)

#### If current constituent data IS provided:

```
Count each sector's representation among current constituents.
sector_weight = count_of_sector / total_constituents
avg_weight = 1 / number_of_distinct_sectors

if sector_weight < avg_weight × 0.5:   return 0.85   # significantly under-represented
if sector_weight < avg_weight:          return 0.65   # somewhat under-represented
if sector_weight < avg_weight × 1.5:   return 0.50   # roughly balanced
else:                                    return 0.30   # over-represented
```

#### If no constituent data provided:

```
sector_score = 0.50    # neutral
```

### 5.7 Final Score Calculation

```
probability = clamp(
    0.30 × margin_score
  + 0.25 × vacancy_score
  + 0.25 × queue_score
  + 0.10 × momentum_score
  + 0.10 × sector_score
, 0.0, 1.0)
```

### 5.8 Confidence Rating

Based on data completeness:

```
skipped_rules = count of hard rules that returned SKIP (data missing)
total_hard_rules = count of hard rules for this index

if skipped_rules > total_hard_rules × 0.3:   confidence = "Low"
elif skipped_rules > 0:                        confidence = "Medium"
else:                                          confidence = "High"
```

### 5.9 Probability Labels

| Probability Range | Label |
|-------------------|-------|
| ≥ 0.80 | Very High |
| 0.60 – 0.79 | High |
| 0.40 – 0.59 | Medium |
| 0.20 – 0.39 | Low |
| < 0.20 | Very Low |
| 0.00 (failed eligibility) | Ineligible |

---

## Part 6: Output Schema

The scoring function should return a structured result per (candidate, index) pair:

```json
{
  "index_code": "SP500",
  "index_name": "S&P 500",
  "ticker": "PLTR",

  "eligible": true,
  "rules_passed": 11,
  "rules_failed": 0,
  "rules_skipped": 0,
  "failing_rules": [],

  "probability": 0.758,
  "probability_label": "High",
  "confidence": "High",

  "signals": {
    "margin_of_safety": 0.962,
    "vacancy_likelihood": 0.450,
    "queue_position": 0.850,
    "momentum": 0.950,
    "sector_fit": 0.500
  },

  "vacancy_context": {
    "fixed_count": true,
    "target_count": 500,
    "requires_vacancy": true,
    "can_displace": false
  },

  "rule_results": [
    {
      "rule_name": "Market Capitalisation",
      "verdict": "PASS",
      "actual_value": 250000000000,
      "threshold": 22700000000,
      "detail": "market_cap_usd=250B meets >= 22.7B"
    }
  ],

  "notes": [
    "S&P 500 requires a vacancy before additions."
  ]
}
```

---

## Part 7: Source Documents

All rules were verified against these official methodology documents (accessed February–March 2026):

| Index | Document | Publisher | Date |
|-------|----------|-----------|------|
| S&P 500/400/600 | S&P U.S. Indices Methodology | S&P Dow Jones Indices | October 2025 |
| S&P 500 market cap | Press release: Market cap guidelines update | S&P Dow Jones Indices | July 1, 2025 |
| NASDAQ-100 | NDX Index Methodology | Nasdaq Inc. | 2025 |
| NASDAQ-100 | NDX Consultation (proposed changes) | Nasdaq Inc. | February 2026 |
| FTSE 100 | FTSE UK Index Series Ground Rules v17.0 | FTSE Russell / LSEG | January 2026 |
| FTSE 100 | FAQ: Fast Entry Thresholds & Sterling v1.1 | FTSE Russell / LSEG | July 2025 |
| DJIA | Dow Jones Averages Methodology | S&P Dow Jones Indices | February 2025 |
| Russell | Russell US Indexes Construction & Methodology | FTSE Russell / LSEG | March 2026 |

---

## Part 8: Comparative Quick Reference

| Criterion | S&P 500 | S&P 400 | S&P 600 | NDX-100 | FTSE 100 | DJIA | Russell |
|-----------|---------|---------|---------|---------|----------|------|---------|
| **Min Market Cap** | $22.7B | $8.0B | $1.2B | None* | Rank-based | In S&P 500 | $30M |
| **Earnings** | 4Q pos. | 4Q pos. | 4Q pos. | No | No | Implicit | No |
| **Liquidity** | FALR≥0.75 | FALR≥0.75 | FALR≥0.75 | $5M/day | Turnover test | Implicit | ADDTV>med |
| **Free Float** | IWF≥0.10 | IWF≥0.10 | IWF≥0.10 | ≥10% | ≥10%–25% | Implicit | >5% |
| **Seasoning** | 12 months | 12 months | 12 months | 3 months | 20 days | Implicit | By rank day |
| **Selection** | Committee | Committee | Committee | Rules+rank | Rules+rank | Committee | Pure rules |
| **Vacancy?** | Required | Required | Required | At recon: no | No (rank) | Required | No (rank) |
| **Reconstitution** | As-needed | As-needed | As-needed | Dec annual | Quarterly | As-needed | Semi-annual |
| **Financials OK?** | Yes | Yes | Yes | **NO** | Yes | Yes | Yes |
| **Country** | US only | US only | US only | US + intl | UK only | US only | US only |

\* NDX has no explicit minimum market cap; in practice only the top ~100 non-financial Nasdaq-listed companies qualify.

---

## Part 9: Implementation Notes

### 9.1 Dynamic Thresholds

These values are NOT fixed and must be refreshed:

- **S&P 500/400/600 market cap thresholds:** Reviewed quarterly by S&P DJI. Check [spglobal.com/spdji](https://www.spglobal.com/spdji) for current values.
- **Russell ADDTV median:** Recalculated each rank day. Cannot be hardcoded — must be computed from the full universe.
- **FTSE 100 rank thresholds:** The 90/111 rule is fixed, but the market cap implied by rank 90 changes every quarter.

### 9.2 Addition vs Continued Membership

For ALL indices: eligibility criteria apply to **new additions only**. An existing constituent falling below a threshold is not automatically removed. Implement this distinction if tracking both candidates and current members.

### 9.3 Pending Methodology Changes (as of March 2026)

These may take effect after the March 2026 quarterly rebalance:

- **NDX Fast Entry:** Top-40 market cap new listings (~$100B+) may enter after 15 trading days, exempt from seasoning/liquidity.
- **NDX Low-Float Weighting:** 10–20% float → weighted at float × 5; <10% remains ineligible.
- **NDX Removal:** 10bp rule may be replaced by quarterly removal if ranked outside top 125.
- **Russell Semi-Annual:** Reconstitution moves from annual to semi-annual starting 2026.

### 9.4 Data Sources

Recommended data providers for populating the candidate schema:

| Data Point | Free Sources | Commercial Sources |
|-----------|-------------|-------------------|
| Market cap, price, volume | Yahoo Finance (yfinance), Alpha Vantage | Bloomberg, Refinitiv, FactSet |
| Float shares, IWF | yfinance (approximate) | S&P Capital IQ, Bloomberg |
| GAAP earnings (quarterly) | SEC EDGAR (10-Q filings) | Bloomberg, FactSet |
| GICS sector | Wikipedia, SEC filings | S&P Capital IQ |
| ICB sector | FTSE Russell website | Refinitiv |
| Current index membership | Index provider websites | Bloomberg, FactSet |
| FTSE nationality | FTSE Russell constituent files | FTSE Russell |

### 9.5 Suggested Test Cases

Use these to validate your implementation:

| Ticker | Expected: SP500 | Expected: NDX | Expected: FTSE100 | Rationale |
|--------|-----------------|---------------|-------------------|-----------|
| AAPL | Eligible ✅ (already in) | Eligible ✅ (already in) | Ineligible ❌ (wrong exchange) | Large US tech, Nasdaq-listed |
| RIVN | Ineligible ❌ (earnings, mcap) | Eligible ✅ (no earnings rule) | Ineligible ❌ (wrong country) | Unprofitable, below $22.7B |
| SHEL | Ineligible ❌ (not US) | Ineligible ❌ (not Nasdaq) | Eligible ✅ | UK-domiciled, LSE-listed |
| A random SPAC | Ineligible ❌ (security type) | Ineligible ❌ (security type) | Ineligible ❌ | SPACs excluded everywhere |
| A $500M US stock | Ineligible ❌ (market cap) | Ineligible ❌ (not top 100) | Ineligible ❌ (not UK) | Too small for most large-cap indices |

### 9.6 Limitations

- This specification is for educational and informational purposes. It is not investment advice.
- Index methodologies are proprietary and may change without notice.
- Soft rules (committee discretion, sector balance) cannot be modelled deterministically — the ML layer (Part 10) improves but does not eliminate this uncertainty.
- Always consult official methodology documents for production systems.

---

## Part 10: Machine Learning Layer

This section specifies an optional ML layer that wraps the heuristic scoring engine (Parts 1–5). The design principle is: **ML refines the heuristic, it does not replace the rules engine.** Stage 1 (eligibility) and Stage 2 (heuristic scoring) remain deterministic and explainable. Stage 3 (ML calibration) adjusts the probability where there is genuine predictive signal — primarily for committee-driven indices.

### 10.1 Where ML Adds Value vs. Where It Doesn't

#### ML does NOT help here (keep deterministic)

| Component | Why ML is unnecessary |
|-----------|----------------------|
| **Hard rule evaluation** | `if market_cap >= 22.7e9` is better as an if-statement than a learned classifier. A neural network that learns to compare two numbers is a worse if-statement. |
| **FTSE 100 inclusion** | Purely rank-based (rank ≤ 90 enters, ≥ 111 exits). Predicting inclusion = predicting relative market cap, which reduces to price forecasting — a problem ML does not reliably solve at short horizons. |
| **Russell indices** | 100% mechanical reconstitution by market cap ranking. No committee, no subjective decisions, nothing to learn. |
| **Margin of safety signal** | Ratio math with a log curve. Deterministic and optimal by construction. |
| **Queue position signal** | A sort operation. The #1 candidate by market cap is the #1 candidate. |

#### ML DOES help here (genuine predictive signal)

| Component | Why ML adds value | Applicable indices |
|-----------|------------------|-------------------|
| **Committee decision prediction** | When a vacancy opens, the S&P committee chooses *which* eligible candidate to add. That choice has learnable patterns: sector gaps, media prominence, time in queue, market-cap rank among candidates. ~20 years of decisions × ~25/year = ~500 labelled examples. | S&P 500, S&P 400, S&P 600, DJIA |
| **Vacancy timing prediction** | Predicting *when* a slot will open: which current constituent will be acquired, delisted, or migrated. Survival analysis with signals from M&A activity, earnings deterioration, market cap decline. | S&P 500, S&P 400, S&P 600, DJIA |
| **Signal weight optimisation** | The heuristic uses hand-tuned 30/25/25/10/10 weights. With historical ground-truth, logistic regression can learn per-index optimal weights from data. | All indices |

---

### 10.2 ML Use Case 1 — Committee Decision Prediction

**Problem:** When a vacancy opens in the S&P 500, which eligible non-member does the committee select?

**Framing:** Binary classification. At each historical addition event, the positive example is the stock that was actually added. Negative examples are all other eligible non-members at that point in time.

#### Feature Set

| Feature | Type | Definition | Signal |
|---------|------|-----------|--------|
| `mcap_rank_among_eligible` | int | Candidate's market-cap rank among all eligible non-members at the time of the vacancy | Lower rank = higher probability |
| `mcap_ratio_to_median` | float | Candidate market cap ÷ median market cap of current index constituents | Larger = more natural fit |
| `sector_gap` | float | (Sector weight in S&P TMI) − (sector weight in current index) for the candidate's sector | Positive gap = under-represented = boost |
| `months_eligible` | float | How many months the candidate has been continuously eligible without being added | Longer wait = slight boost (committee aware) |
| `months_since_ipo` | float | Months since IPO | Very recent IPOs less likely despite eligibility |
| `falr` | float | Float-adjusted liquidity ratio | Higher = more tradeable |
| `earnings_margin` | float | Trailing 4Q earnings ÷ market cap (earnings yield) | Stronger profitability = committee preference |
| `analyst_coverage` | int | Number of sell-side analysts covering the stock | Proxy for investor interest |
| `index_vacancy_cause` | categorical | What caused the vacancy (M&A, delisting, migration, bankruptcy) | Some causes correlate with replacement sector |
| `num_eligible_candidates` | int | Total number of eligible non-members at vacancy time | More competition = lower per-candidate probability |

#### Target Variable

```
y = 1 if this candidate was the one actually added at this vacancy event
y = 0 otherwise
```

#### Sample Construction

For each historical S&P 500 addition (source: S&P DJI announcements, ~25/year × 20 years ≈ 500 events):

1. Identify the date of the addition announcement.
2. Reconstruct the state of the index on that date (which stocks were constituents).
3. Screen the full US equity universe against the S&P 500 hard rules *as they existed at that time* (note: market cap thresholds have changed over the years — use the historical thresholds from Appendix A of the S&P methodology).
4. For each eligible non-member, compute all features.
5. The candidate actually added gets `y=1`. All others get `y=0`.

This produces approximately 500 positive examples and ~500 × 50 (average eligible pool size) ≈ 25,000 negative examples. Severely imbalanced — address with class weights or stratified sampling.

#### Recommended Model

**Gradient-Boosted Trees (XGBoost or LightGBM)**

Rationale:
- Dataset is small (~500 positive examples). Tree ensembles handle small datasets better than neural networks.
- Features are a mix of continuous and categorical. Trees handle this natively.
- Feature importance is interpretable (critical for explaining *why* a stock was predicted).
- Handles class imbalance with `scale_pos_weight`.

```python
import xgboost as xgb

model = xgb.XGBClassifier(
    n_estimators=200,
    max_depth=4,              # shallow trees — small dataset
    learning_rate=0.05,
    scale_pos_weight=50,      # ≈ neg/pos ratio
    subsample=0.8,
    colsample_bytree=0.8,
    eval_metric="aucpr",      # area under precision-recall curve (better for imbalanced)
    early_stopping_rounds=20,
)

model.fit(X_train, y_train, eval_set=[(X_val, y_val)])

# Output: predicted probability per candidate
probabilities = model.predict_proba(X_candidates)[:, 1]
```

**Do NOT use:**
- Neural networks (insufficient data, no spatial/sequential structure to exploit)
- Linear models alone (non-linear interactions between sector gap and market cap rank matter)
- Random forests (XGBoost/LightGBM consistently outperform on structured tabular data)

---

### 10.3 ML Use Case 2 — Vacancy Timing Prediction

**Problem:** Which current index constituents are most likely to leave the index in the next N months, creating a vacancy?

**Framing:** Survival analysis / time-to-event prediction. For each current constituent, predict the probability of removal within the next 3, 6, and 12 months.

#### Feature Set

| Feature | Type | Definition | Signal |
|---------|------|-----------|--------|
| `mcap_percentile_in_index` | float | Where the constituent ranks by market cap within the current index (0 = smallest, 1 = largest) | Bottom decile = higher removal risk |
| `mcap_change_6m` | float | 6-month market cap change (decimal) | Declining stocks more likely to be migrated down |
| `mcap_change_12m` | float | 12-month market cap change | Longer-term decline signal |
| `earnings_negative_streak` | int | Consecutive quarters of negative GAAP earnings | Prolonged losses → committee attention |
| `below_mcap_threshold` | bool | Is the constituent's current market cap below the index's addition threshold? | True = at-risk (though not auto-removed) |
| `pending_ma_rumour` | bool | Has the company been the subject of M&A speculation in financial news? | Acquisition = removal |
| `days_since_addition` | int | Days since the stock was added to the index | Recently added stocks rarely removed quickly |
| `credit_spread_change_6m` | float | Change in the company's credit spread (CDS or bond spread) | Widening = financial distress signal |
| `sector` | categorical | GICS sector of the constituent | Some sectors (energy, retail) have historically higher turnover |
| `exchange_warning` | bool | Has the exchange issued a compliance warning? | Potential delisting risk |

#### Target Variable

```
y = 1 if this constituent was removed from the index within the next N months
y = 0 if it remained
```

#### Recommended Model

**Cox Proportional Hazards or XGBoost Survival**

```python
from lifelines import CoxPHFitter

# For each constituent, at each quarter-end, compute features
# Event = removal from index, duration = quarters until removal (or censored)

cph = CoxPHFitter(penalizer=0.1)
cph.fit(df, duration_col='quarters_to_removal', event_col='was_removed')

# Predict hazard for current constituents
hazard_scores = cph.predict_partial_hazard(current_constituents)
# Higher hazard = more likely to leave = higher vacancy probability
```

Alternatively, use `xgbse` (XGBoost Survival Embeddings) for a non-parametric approach that handles non-linear interactions.

#### Integration with Vacancy Signal

The vacancy timing model replaces the static base-rate fallback in Signal 2:

```
if vacancy_model is trained:
    # Probability that ANY constituent leaves in next review cycle
    individual_hazards = vacancy_model.predict(current_constituents)
    vacancy_score = 1 - product(1 - h for h in individual_hazards)
    # = probability of at least one departure
else:
    vacancy_score = base_rate_fallback[index_code]  # 0.45 for SP500, etc.
```

---

### 10.4 ML Use Case 3 — Signal Weight Optimisation

**Problem:** The heuristic uses hand-tuned weights (30/25/25/10/10). Can we learn better weights from historical data?

**Framing:** Logistic regression where the 5 signal values are features and the target is whether the candidate was actually added.

#### Implementation

```python
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV

# For each historical addition event:
#   Compute the 5 signal values for all eligible candidates at that time
#   Label the actually-added candidate as y=1, others as y=0

X = df[['margin_score', 'vacancy_score', 'queue_score', 'momentum_score', 'sector_score']]
y = df['was_added']

# Logistic regression learns optimal linear combination of signals
base_model = LogisticRegression(class_weight='balanced', max_iter=1000)

# Platt scaling ensures output is a well-calibrated probability
model = CalibratedClassifierCV(base_model, cv=5, method='sigmoid')
model.fit(X, y)

# The learned coefficients replace the hand-tuned weights
# model.predict_proba(signals)[:, 1] → calibrated probability
```

#### Interpretation

After fitting, extract the learned weights:

```python
# The logistic regression coefficients indicate relative importance
coefs = base_model.coef_[0]
weight_names = ['margin', 'vacancy', 'queue', 'momentum', 'sector']
for name, coef in zip(weight_names, coefs):
    print(f"{name}: {coef:.3f}")

# Compare to hand-tuned: 0.30, 0.25, 0.25, 0.10, 0.10
# If learned weights diverge significantly, the data is telling you
# something the heuristic missed
```

#### Per-Index Models

Train separate weight models for each index — the relative importance of signals differs:

| Index | Expected weight shift | Rationale |
|-------|----------------------|-----------|
| S&P 500 | Sector fit weight likely increases | Committee explicitly considers sector balance |
| DJIA | Queue position weight likely decreases | Committee ignores market-cap ranking; reputation dominates |
| NDX | Vacancy weight likely decreases | Annual reconstitution is predictable; queue position matters most |
| FTSE 100 | Margin weight likely increases | Rank is everything — being far above rank 90 is the strongest signal |

---

### 10.5 Three-Stage Hybrid Architecture

```
┌──────────────┐     ┌──────────────────┐     ┌──────────────────┐     ┌────────────┐
│  STAGE 1     │     │  STAGE 2         │     │  STAGE 3 (opt.)  │     │  OUTPUT    │
│  Rules       │────▶│  Heuristic       │────▶│  ML Calibration  │────▶│  Ranked    │
│  Engine      │     │  5-Signal Score  │     │  Layer           │     │  Results   │
│              │     │                  │     │                  │     │            │
│  Deterministic     │  Deterministic   │     │  Learned         │     │  Explainable
│  Pass/Fail   │     │  base_prob       │     │  calibrated_prob │     │  Traceable │
└──────────────┘     └──────────────────┘     └──────────────────┘     └────────────┘
      ▲                     ▲                        ▲
      │                     │                        │
 Always runs           Always runs            Only if trained,
 No ML                 No ML                  only for applicable
                                              indices
```

#### Integration pseudocode

```python
def score_candidate(index_code, candidate, context):

    # Stage 1: Eligibility (always deterministic)
    eligible, rule_results = evaluate_hard_rules(index_code, candidate)
    if not eligible:
        return Result(probability=0.0, label="Ineligible", ...)

    # Stage 2: Heuristic scoring (always deterministic)
    signals = {
        'margin':  compute_margin(index_code, candidate),
        'vacancy': compute_vacancy(index_code, context.current_constituents),
        'queue':   compute_queue(candidate, context.eligible_non_members),
        'momentum': compute_momentum(candidate),
        'sector':  compute_sector(index_code, candidate, context.current_constituents),
    }
    base_prob = (0.30 * signals['margin']
               + 0.25 * signals['vacancy']
               + 0.25 * signals['queue']
               + 0.10 * signals['momentum']
               + 0.10 * signals['sector'])
    base_prob = clamp(base_prob, 0.0, 1.0)

    # Stage 3: ML calibration (optional, graceful fallback)
    if ml_models_available(index_code):
        ml_features = build_ml_features(candidate, signals, context)
        calibrated_prob = ml_predict(index_code, ml_features)
        final_prob = calibrated_prob
        ml_applied = True
    else:
        final_prob = base_prob
        ml_applied = False

    return Result(
        probability=final_prob,
        base_probability=base_prob,        # always available for comparison
        ml_applied=ml_applied,
        ml_adjustment=final_prob - base_prob if ml_applied else 0.0,
        signals=signals,
        rule_results=rule_results,
        ...
    )
```

#### Key design decisions

1. **Stage 2 always runs**, even when ML is available. The base probability is always included in the output for transparency and debugging.
2. **ML is per-index.** The committee prediction model only applies to S&P 500/400/600/DJIA. The vacancy model only to vacancy-required indices. Weight optimisation can apply to all.
3. **Graceful fallback.** If no ML model is trained for an index, the system returns the Stage 2 heuristic score. No degraded-mode errors.
4. **The output always shows `ml_adjustment`** — the difference between the ML-calibrated probability and the heuristic base. This makes it obvious when and how ML is changing the score.

---

### 10.6 Training Data Construction

#### Historical S&P 500 Changes Dataset

This is the primary training set. Each row represents a candidate at the time of an index change event.

| Column | Type | Source |
|--------|------|--------|
| `event_date` | date | S&P DJI announcement archive |
| `event_type` | categorical | "addition", "deletion" |
| `ticker` | string | The stock added or removed |
| `vacancy_cause` | categorical | What caused the vacancy ("M&A", "delisting", "migration", "bankruptcy", "committee") |
| `was_added` | bool | True for the stock actually added (positive label) |
| `market_cap_usd` | float | Market cap at event date |
| `mcap_rank_eligible` | int | Rank among all eligible non-members |
| `sector_gap` | float | Sector under/over representation |
| `months_eligible` | float | Duration of continuous eligibility |
| All 5 signal values | float | Computed at event date |
| All ML features from §10.2 | various | Computed at event date |

**Sources for historical data:**

| Data | Source | Access |
|------|--------|--------|
| S&P 500 addition/deletion history | S&P DJI press releases, Wikipedia "List of S&P 500 companies" revision history | Free |
| Historical market cap thresholds | Appendix A of the S&P U.S. Indices Methodology | Free (PDF) |
| Historical constituent lists | CRSP, Compustat, S&P Capital IQ | Commercial |
| Historical price/volume/market cap | Yahoo Finance (yfinance), CRSP | Free / Commercial |
| Historical earnings | SEC EDGAR (10-Q XBRL), Compustat | Free / Commercial |
| Historical GICS sectors | S&P Capital IQ | Commercial |

#### Minimum Viable Training Set

| Model | Min. positive examples | Min. total examples | Feasibility |
|-------|----------------------|--------------------|----|
| Committee prediction (SP500) | ~500 (20yr × 25/yr) | ~25,000 | Achievable |
| Committee prediction (DJIA) | ~30 (20yr × 1.5/yr) | ~900 | Marginal — use with caution |
| Vacancy timing (SP500) | ~500 removals | ~10,000 constituent-quarters | Achievable |
| Weight optimisation | Same as committee | Same | Achievable |

> **The DJIA has insufficient data for reliable ML.** With ~30 positive examples over 20 years, any model will overfit. For the DJIA, stick with the heuristic (Stage 2) only.

---

### 10.7 Model Selection Guidance

| Use Case | Recommended Model | Alternatives | Avoid |
|----------|------------------|-------------|-------|
| Committee prediction | XGBoost (`XGBClassifier`) | LightGBM, CatBoost | Neural networks, SVMs, random forests |
| Vacancy timing | Cox PH (`lifelines.CoxPHFitter`) | XGBoost Survival (`xgbse`), Random Survival Forest | Standard classification (ignores censoring) |
| Weight optimisation | Logistic Regression + Platt scaling | Elastic net | Complex models (only 5 features — LR is optimal) |

#### Hyperparameter Ranges

**XGBoost (committee prediction):**

```python
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [3, 4, 5],           # keep shallow — small dataset
    'learning_rate': [0.03, 0.05, 0.1],
    'scale_pos_weight': [30, 50, 70],  # adjust to class imbalance ratio
    'subsample': [0.7, 0.8, 0.9],
    'colsample_bytree': [0.7, 0.8, 0.9],
    'min_child_weight': [3, 5, 10],    # regularisation for small data
}
```

Use time-series cross-validation (not random k-fold) — see §10.8.

---

### 10.8 Evaluation & Backtesting

#### Critical: Time-Series Cross-Validation

Index additions are temporal events. **Never use random k-fold cross-validation** — it leaks future information into the training set. Use expanding-window time-series splits:

```
Split 1: Train on 2005–2010, test on 2011–2012
Split 2: Train on 2005–2012, test on 2013–2014
Split 3: Train on 2005–2014, test on 2015–2016
Split 4: Train on 2005–2016, test on 2017–2018
Split 5: Train on 2005–2018, test on 2019–2020
Split 6: Train on 2005–2020, test on 2021–2022
Split 7: Train on 2005–2022, test on 2023–2024
Final:   Train on 2005–2024, deploy for 2025+
```

#### Metrics

| Metric | Use for | Target |
|--------|---------|--------|
| **Precision@k** | Committee prediction — "of the top k candidates we predicted, how many were actually added?" | ≥ 0.40 at k=3 (the top-3 prediction includes the actual addition 40%+ of the time) |
| **AUROC** | Overall discrimination — can the model distinguish adds from non-adds? | ≥ 0.75 |
| **AUPRC** | Imbalanced classification — area under precision-recall curve | ≥ 0.20 (with 1:50 imbalance, random = 0.02) |
| **Brier Score** | Calibration — are predicted probabilities accurate? | ≤ 0.05 |
| **Concordance Index** | Vacancy timing (survival model) — does the model rank higher-risk constituents correctly? | ≥ 0.70 |
| **Lift over heuristic** | Does ML improve on Stage 2? Compare precision@k with ML vs. without. | ≥ 1.2× lift |

#### Backtesting Protocol

```
For each test period:
    1. At each historical vacancy event:
        a. Reconstruct the index state (constituent list, eligible pool)
        b. Compute Stage 2 heuristic scores for all eligible candidates
        c. Compute Stage 3 ML scores for all eligible candidates
        d. Record which candidate was actually added
    2. Compare:
        - Heuristic: was the actual addition in the top-3 by heuristic score?
        - ML: was the actual addition in the top-3 by ML score?
    3. Aggregate precision@3 across all events in the test period

If ML precision@3 > heuristic precision@3 by ≥ 10pp across all test splits:
    → ML adds value, deploy Stage 3
Else:
    → ML does not reliably improve, stick with Stage 2
```

---

### 10.9 When NOT to Use ML

| Situation | Recommendation |
|-----------|---------------|
| **FTSE 100 / Russell indices** | Do not use ML. These are purely rank-based — predicting inclusion reduces to predicting market cap, which is price forecasting. ML does not reliably beat simple heuristics here. |
| **DJIA** | Do not use ML for committee prediction (~30 data points in 20 years = certain overfitting). Use Stage 2 heuristic only. |
| **Fewer than 200 positive examples** | Do not train a committee prediction model. The signal-to-noise ratio is too low. |
| **No access to historical constituent lists** | Cannot construct training data. Use Stage 2 only. |
| **ML precision@3 is not ≥ 10pp above heuristic** | The ML layer is not earning its keep. Disable Stage 3 for that index. |
| **Real-time requirements** | Stage 1 + 2 run in milliseconds. Stage 3 adds inference latency (typically <100ms for tree models, but adds deployment complexity). If speed matters more than marginal accuracy, skip Stage 3. |

#### The Explainability Rule

The system must always be able to answer: **"Why did this stock score X%?"**

With Stage 2 alone, the answer is trivial — show the 5 signal values and their weights. With Stage 3, the answer requires SHAP values or feature importance from the ML model. If you cannot explain the ML adjustment, do not deploy it.

```python
import shap

explainer = shap.TreeExplainer(xgb_model)
shap_values = explainer.shap_values(X_candidate)

# Top 3 features driving this prediction:
# 1. mcap_rank_among_eligible = 2  → +12pp
# 2. sector_gap = +3.2%           → +8pp
# 3. months_eligible = 18         → +4pp
```