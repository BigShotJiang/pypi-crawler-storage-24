from __future__ import annotations

from index_inclusion._indices import get_index_config
from index_inclusion._rules import evaluate_eligibility
from index_inclusion._types import (
    Candidate,
    HardRule,
    IndexCode,
    Operator,
    RuleResult,
    RuleVerdict,
    VacancyMechanics,
)


# ---------------------------------------------------------------------------
# Signal 1 — Margin of Safety (30% weight)
# ---------------------------------------------------------------------------


def _margin_score_for_rule(rule: HardRule, result: RuleResult) -> float | None:
    """Compute a per-rule margin score.  Returns ``None`` for non-numeric rules."""
    if result.verdict is RuleVerdict.SKIP:
        return None

    op = rule.operator

    # Boolean / set operators — already passed eligibility → score 1.0
    if op in (Operator.EQ, Operator.IN, Operator.NOT_IN):
        return 1.0

    value = result.actual_value
    threshold = rule.threshold

    if op in (Operator.GE, Operator.GT):
        if threshold == 0:
            return 1.0 if value > 0 else 0.0
        ratio = value / threshold
        if ratio < 1.0:
            return 0.0
        return min(1.0, 0.5 + 0.5 * (1.0 - 1.0 / ratio))

    if op in (Operator.LE, Operator.LT):
        if threshold == 0:
            return 1.0 if value <= 0 else 0.0
        ratio = value / threshold
        if ratio > 1.0:
            return 0.0
        return min(1.0, 0.5 + 0.5 * (1.0 - ratio))

    return None


def margin_of_safety(
    hard_rules: tuple[HardRule, ...],
    rule_results: tuple[RuleResult, ...],
) -> float:
    """Compute the margin-of-safety signal from rule evaluation results."""
    scores: list[float] = []
    for rule, result in zip(hard_rules, rule_results):
        s = _margin_score_for_rule(rule, result)
        if s is not None:
            scores.append(s)
    return sum(scores) / len(scores) if scores else 0.5


# ---------------------------------------------------------------------------
# Signal 2 — Vacancy Likelihood (25% weight)
# ---------------------------------------------------------------------------


def vacancy_likelihood(
    index_code: IndexCode | str,
    current_constituents: list[Candidate] | None = None,
) -> float:
    """How likely is a slot to open in the next review cycle?"""
    config = get_index_config(index_code)
    vacancy = config.vacancy

    # Displacement / reconstitution indices — static defaults
    if not vacancy.requires_vacancy:
        return vacancy.default_vacancy_score

    # Vacancy-required indices — compute from at-risk constituents if available
    if current_constituents:
        at_risk = 0
        for c in current_constituents:
            eligible, _ = evaluate_eligibility(index_code, c)
            if not eligible:
                at_risk += 1
        risk_ratio = at_risk / len(current_constituents)
        return min(0.95, 0.30 + risk_ratio * 3.0)

    # Fallback base rate
    return vacancy.base_rate_fallback


# ---------------------------------------------------------------------------
# Signal 3 — Queue Position (25% weight)
# ---------------------------------------------------------------------------

_MCAP_PROXY_BUCKETS: list[tuple[float, float]] = [
    (100_000_000_000, 0.85),
    (50_000_000_000, 0.70),
    (25_000_000_000, 0.55),
    (10_000_000_000, 0.40),
]
_MCAP_PROXY_DEFAULT = 0.25


def queue_position(
    candidate: Candidate,
    eligible_non_members: list[Candidate] | None = None,
) -> float:
    """Where does the candidate rank among eligible non-members?"""
    if eligible_non_members:
        pool = sorted(
            eligible_non_members,
            key=lambda c: c.market_cap_usd or 0.0,
            reverse=True,
        )
        total = len(pool)
        if total == 1:
            return 0.90
        position = next(
            (i + 1 for i, c in enumerate(pool) if c.ticker == candidate.ticker),
            total,
        )
        return max(0.05, 1.0 - (position - 1) / total)

    # Fallback: market-cap proxy
    mcap = candidate.market_cap_usd
    if mcap is None:
        return _MCAP_PROXY_DEFAULT
    for threshold, score in _MCAP_PROXY_BUCKETS:
        if mcap >= threshold:
            return score
    return _MCAP_PROXY_DEFAULT


# ---------------------------------------------------------------------------
# Signal 4 — Momentum (10% weight)
# ---------------------------------------------------------------------------

_MOMENTUM_BUCKETS: list[tuple[float, float]] = [
    (0.50, 0.95),
    (0.20, 0.80),
    (0.05, 0.65),
    (-0.05, 0.50),
    (-0.20, 0.30),
]
_MOMENTUM_FLOOR = 0.10
_MOMENTUM_UNKNOWN = 0.50


def momentum(candidate: Candidate) -> float:
    """Is the candidate's market cap growing or shrinking?"""
    growth = candidate.market_cap_growth_1y
    if growth is None:
        return _MOMENTUM_UNKNOWN
    for threshold, score in _MOMENTUM_BUCKETS:
        if growth > threshold:
            return score
    return _MOMENTUM_FLOOR


# ---------------------------------------------------------------------------
# Signal 5 — Sector Fit (10% weight)
# ---------------------------------------------------------------------------

_SECTOR_NEUTRAL = 0.50


def _sector_field_for_index(index_code: IndexCode | str) -> str:
    """Which candidate field holds the sector for this index family?"""
    if isinstance(index_code, str):
        index_code = IndexCode(index_code)
    if index_code in (IndexCode.NDX, IndexCode.FTSE100):
        return "icb_sector"
    return "gics_sector"


def sector_fit(
    candidate: Candidate,
    index_code: IndexCode | str,
    current_constituents: list[Candidate] | None = None,
) -> float:
    """Does the candidate fill an under-represented sector?"""
    if not current_constituents:
        return _SECTOR_NEUTRAL

    sector_field = _sector_field_for_index(index_code)
    candidate_sector = getattr(candidate, sector_field, None)
    if candidate_sector is None:
        return _SECTOR_NEUTRAL

    # Count sector representation
    sector_counts: dict[str, int] = {}
    for c in current_constituents:
        s = getattr(c, sector_field, None)
        if s is not None:
            sector_counts[s] = sector_counts.get(s, 0) + 1

    total = sum(sector_counts.values())
    if total == 0:
        return _SECTOR_NEUTRAL

    num_sectors = len(sector_counts)
    if num_sectors == 0:
        return _SECTOR_NEUTRAL

    sector_weight = sector_counts.get(candidate_sector, 0) / total
    avg_weight = 1.0 / num_sectors

    if sector_weight < avg_weight * 0.5:
        return 0.85
    if sector_weight < avg_weight:
        return 0.65
    if sector_weight < avg_weight * 1.5:
        return 0.50
    return 0.30
