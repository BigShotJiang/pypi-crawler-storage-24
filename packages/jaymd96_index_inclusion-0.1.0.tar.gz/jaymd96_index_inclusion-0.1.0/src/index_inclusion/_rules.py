from __future__ import annotations

from index_inclusion._indices import get_index_config
from index_inclusion._types import Candidate, HardRule, IndexCode, Operator, RuleResult, RuleVerdict


def _apply_operator(value: object, operator: Operator, threshold: object) -> bool:
    """Apply a comparison operator and return True if the value passes."""
    if operator is Operator.GE:
        return value >= threshold  # type: ignore[operator]
    if operator is Operator.LE:
        return value <= threshold  # type: ignore[operator]
    if operator is Operator.GT:
        return value > threshold  # type: ignore[operator]
    if operator is Operator.LT:
        return value < threshold  # type: ignore[operator]
    if operator is Operator.EQ:
        return value == threshold
    if operator is Operator.IN:
        return value in threshold  # type: ignore[operator]
    if operator is Operator.NOT_IN:
        return value not in threshold  # type: ignore[operator]
    raise ValueError(f"Unknown operator: {operator}")


def evaluate_rule(rule: HardRule, candidate: Candidate) -> RuleResult:
    """Evaluate a single hard rule against a candidate.

    Returns SKIP if the candidate field is ``None`` (data not available).
    """
    value = getattr(candidate, rule.field, None)

    if value is None:
        return RuleResult(
            rule_name=rule.name,
            verdict=RuleVerdict.SKIP,
            actual_value=None,
            threshold=rule.threshold,
            detail=f"{rule.field} data not available",
        )

    passed = _apply_operator(value, rule.operator, rule.threshold)
    verdict = RuleVerdict.PASS if passed else RuleVerdict.FAIL
    verb = "meets" if passed else "fails"
    detail = f"{rule.field}={value!r} {verb} {rule.operator.value} {rule.threshold!r}"

    return RuleResult(
        rule_name=rule.name,
        verdict=verdict,
        actual_value=value,
        threshold=rule.threshold,
        detail=detail,
    )


def evaluate_eligibility(
    index_code: IndexCode | str,
    candidate: Candidate,
) -> tuple[bool, tuple[RuleResult, ...]]:
    """Evaluate all hard rules for an index.

    Returns ``(eligible, rule_results)``.  A candidate is eligible when no
    rule returns FAIL — SKIP results do *not* cause failure.
    """
    config = get_index_config(index_code)
    results = tuple(evaluate_rule(rule, candidate) for rule in config.hard_rules)
    eligible = all(r.verdict is not RuleVerdict.FAIL for r in results)
    return eligible, results
