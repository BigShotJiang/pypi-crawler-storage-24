from __future__ import annotations

import os
from collections.abc import Sequence
from pathlib import Path

from index_inclusion._backtest import backtest as _backtest
from index_inclusion._backtest import build_training_data as _build_training_data
from index_inclusion._loader import load_candidate, load_candidates
from index_inclusion._ml import MLCalibrator
from index_inclusion._scanner import scan as _scan
from index_inclusion._scanner import scan_all as _scan_all
from index_inclusion._scorer import score as _score
from index_inclusion._scorer import score_many as _score_many
from index_inclusion._types import (
    BacktestResult,
    IndexCode,
    ScanResult,
    ScoringContext,
    ScoringResult,
)

_DEFAULT_CACHE_DIR = os.path.expanduser("~/.index_inclusion/cache.db")
_DEFAULT_MODELS_DIR = os.path.expanduser("~/.index_inclusion/models")


def _resolve_index(index: str | IndexCode) -> IndexCode:
    return IndexCode(index) if isinstance(index, str) else index


class IndexInclusion:
    """Workflow-optimised entry point for index inclusion prediction.

    Manages the FMP client and ML models internally so consumers can focus
    on the analysis, not the plumbing.

    Parameters
    ----------
    fmp_api_key:
        FMP API key.  Falls back to the ``FMP_API_KEY`` environment variable.
    cache_dir:
        Path for the FMP DuckDB cache.  Defaults to
        ``~/.index_inclusion/cache.db``.
    models_dir:
        Directory for persisted ML models.  Defaults to
        ``~/.index_inclusion/models/``.
    """

    def __init__(
        self,
        fmp_api_key: str | None = None,
        *,
        cache_dir: str | None = None,
        models_dir: str | None = None,
    ) -> None:
        from fmp import FMPClient

        api_key = fmp_api_key or os.environ.get("FMP_API_KEY", "")
        self._client = FMPClient(
            api_key=api_key,
            cache_path=cache_dir or _DEFAULT_CACHE_DIR,
        )

        self._models_dir = models_dir or _DEFAULT_MODELS_DIR

        # Load persisted models if available
        if Path(self._models_dir).exists():
            self._ml = MLCalibrator.load(self._models_dir)
        else:
            self._ml = MLCalibrator()

    # ── Workflow 1: Single stock check ────────────────────────────────────

    def check(self, ticker: str, index: str | IndexCode) -> ScoringResult:
        """Is this stock likely to join this index?

        Loads data from FMP, evaluates eligibility, computes signals, and
        optionally applies ML calibration.
        """
        code = _resolve_index(index)
        candidate = load_candidate(self._client, ticker)
        ml = self._ml if self._ml.is_available(code) else None
        return _score(candidate, code, ml_calibrator=ml)

    # ── Workflow 2: Check multiple stocks ─────────────────────────────────

    def check_many(
        self,
        tickers: Sequence[str],
        indices: Sequence[str | IndexCode],
    ) -> list[ScoringResult]:
        """Score multiple stocks across multiple indices."""
        codes = [_resolve_index(i) for i in indices]
        candidates = load_candidates(self._client, tickers)
        ml = self._ml if any(self._ml.is_available(c) for c in codes) else None
        return _score_many(candidates, codes, ml_calibrator=ml)

    # ── Workflow 3: Find candidates ───────────────────────────────────────

    def candidates(
        self,
        index: str | IndexCode,
        *,
        top_n: int = 50,
    ) -> list[ScoringResult]:
        """Find the top N most likely candidates for index inclusion.

        Scans the stock universe, scores all eligible candidates, and returns
        them ranked by probability descending.
        """
        code = _resolve_index(index)
        ml = self._ml if self._ml.is_available(code) else None
        result = _scan(self._client, code, ml_calibrator=ml)
        return list(result.results[:top_n])

    def candidates_all(
        self,
        *,
        top_n: int = 20,
    ) -> dict[str, list[ScoringResult]]:
        """Scan all 7 indices and return top candidates for each."""
        ml = self._ml
        results = _scan_all(self._client, ml_calibrator=ml)
        return {
            code.value: list(sr.results[:top_n])
            for code, sr in results.items()
        }

    # ── Workflow 4: Backtest ──────────────────────────────────────────────

    def backtest(
        self,
        index: str | IndexCode,
        *,
        start: int = 2016,
        end: int = 2025,
    ) -> BacktestResult:
        """Evaluate prediction accuracy against actual historical index changes."""
        code = _resolve_index(index)
        ml = self._ml if self._ml.is_available(code) else None
        return _backtest(self._client, code, start_year=start, end_year=end, ml_calibrator=ml)

    # ── Workflow 5: Train ML models ───────────────────────────────────────

    def train(
        self,
        index: str | IndexCode,
        *,
        start: int = 2016,
        end: int = 2023,
    ) -> None:
        """Train ML models for an index from historical data.

        After training, subsequent calls to ``check()``, ``check_many()``,
        and ``candidates()`` automatically use ML calibration.  Models are
        persisted to ``models_dir``.
        """
        code = _resolve_index(index)
        training_data = _build_training_data(
            self._client, code, start_year=start, end_year=end,
        )

        if training_data:
            self._ml.train_committee_model(code, training_data)
            self._ml.train_weight_model(code, training_data)
            self._ml.save(self._models_dir)

    # ── Model health ──────────────────────────────────────────────────────

    def model_health(self, index: str | IndexCode) -> dict | None:
        """Check health metrics for trained ML models.

        Returns calibration p-values, feature stability, and coverage
        metrics from the jaymd-winnow health monitoring system.
        """
        code = _resolve_index(index)
        return self._ml.health(code)
