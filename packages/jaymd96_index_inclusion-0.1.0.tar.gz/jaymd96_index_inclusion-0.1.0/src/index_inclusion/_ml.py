from __future__ import annotations

import logging
import pickle
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import numpy as np

from index_inclusion._types import (
    Candidate,
    IndexCode,
    ScoringContext,
    SignalValues,
    TrainingEvent,
)

logger = logging.getLogger(__name__)


def _to_index_code(code: IndexCode | str) -> IndexCode:
    return IndexCode(code) if isinstance(code, str) else code


# ---------------------------------------------------------------------------
# ML Calibrator — all models use AdaptivePipeline from jaymd-winnow
# ---------------------------------------------------------------------------


class MLCalibrator:
    """Stage 3: ML calibration layer.

    All three model types use ``AdaptivePipeline`` from ``jaymd-winnow`` to
    get leak-free temporal training, stability selection, conformal prediction,
    health monitoring, and adaptive retraining.
    """

    def __init__(self) -> None:
        self._committee_pipelines: dict[IndexCode, Any] = {}
        self._weight_pipelines: dict[IndexCode, Any] = {}
        self._vacancy_pipelines: dict[IndexCode, Any] = {}

    # ── Committee decision prediction ─────────────────────────────────────

    def train_committee_model(
        self,
        index_code: IndexCode | str,
        training_data: Sequence[TrainingEvent],
        *,
        min_history: int = 200,
    ) -> None:
        """Train a committee decision model from historical addition events.

        Uses ``AdaptivePipeline.classification()`` with features: mcap_rank,
        sector_gap, months_eligible, num_eligible_candidates, and the 5
        signal values.
        """
        from jaymd_winnow import AdaptivePipeline

        code = _to_index_code(index_code)
        pipeline = AdaptivePipeline.classification(min_history=min_history)

        # Group events by date to step chronologically
        events_by_date: dict[Any, list[TrainingEvent]] = {}
        for ev in training_data:
            events_by_date.setdefault(ev.event_date, []).append(ev)

        for event_date in sorted(events_by_date):
            group = events_by_date[event_date]
            for ev in group:
                features = np.array([
                    ev.mcap_rank_among_eligible,
                    ev.sector_gap,
                    ev.months_eligible,
                    ev.num_eligible_candidates,
                    ev.signals.margin_of_safety,
                    ev.signals.vacancy_likelihood,
                    ev.signals.queue_position,
                    ev.signals.momentum,
                    ev.signals.sector_fit,
                ], dtype=np.float64)

                target = np.array([float(ev.was_added)])

                try:
                    pipeline.step(event_date, features, target)
                except Exception:
                    logger.debug("Pipeline step failed for %s on %s", ev.ticker, event_date)

        self._committee_pipelines[code] = pipeline
        logger.info("Committee model trained for %s (%d events)", code.value, len(training_data))

    # ── Weight optimisation ───────────────────────────────────────────────

    def train_weight_model(
        self,
        index_code: IndexCode | str,
        training_data: Sequence[TrainingEvent],
        *,
        min_history: int = 200,
    ) -> None:
        """Train a weight optimisation model from historical events.

        Uses ``AdaptivePipeline.classification()`` with the 5 signal values
        as features.  AdaptivePipeline gives us leak-free temporal CV, regime
        detection, and calibrated prediction sets even for just 5 features.
        """
        from jaymd_winnow import AdaptivePipeline

        code = _to_index_code(index_code)
        pipeline = AdaptivePipeline.classification(min_history=min_history)

        events_by_date: dict[Any, list[TrainingEvent]] = {}
        for ev in training_data:
            events_by_date.setdefault(ev.event_date, []).append(ev)

        for event_date in sorted(events_by_date):
            group = events_by_date[event_date]
            for ev in group:
                features = np.array([
                    ev.signals.margin_of_safety,
                    ev.signals.vacancy_likelihood,
                    ev.signals.queue_position,
                    ev.signals.momentum,
                    ev.signals.sector_fit,
                ], dtype=np.float64)

                target = np.array([float(ev.was_added)])

                try:
                    pipeline.step(event_date, features, target)
                except Exception:
                    logger.debug("Weight pipeline step failed for %s", ev.ticker)

        self._weight_pipelines[code] = pipeline
        logger.info("Weight model trained for %s", code.value)

    # ── Vacancy timing ────────────────────────────────────────────────────

    def train_vacancy_model(
        self,
        index_code: IndexCode | str,
        training_data: Sequence[TrainingEvent],
        *,
        min_history: int = 200,
    ) -> None:
        """Train a vacancy timing model.

        Uses ``AdaptivePipeline.classification()`` with constituent-level
        features.  Binary target: was this constituent removed within N months?
        """
        from jaymd_winnow import AdaptivePipeline

        code = _to_index_code(index_code)
        pipeline = AdaptivePipeline.classification(min_history=min_history)

        # For vacancy timing, training_data represents constituent observations
        # with was_added repurposed as was_removed
        events_by_date: dict[Any, list[TrainingEvent]] = {}
        for ev in training_data:
            events_by_date.setdefault(ev.event_date, []).append(ev)

        for event_date in sorted(events_by_date):
            group = events_by_date[event_date]
            for ev in group:
                mcap = ev.candidate.market_cap_usd or 0.0
                features = np.array([
                    ev.mcap_rank_among_eligible,
                    mcap,
                    ev.candidate.market_cap_growth_1y or 0.0,
                    ev.signals.margin_of_safety,
                    ev.months_eligible,
                ], dtype=np.float64)

                target = np.array([float(ev.was_added)])

                try:
                    pipeline.step(event_date, features, target)
                except Exception:
                    pass

        self._vacancy_pipelines[code] = pipeline
        logger.info("Vacancy model trained for %s", code.value)

    # ── Calibration ───────────────────────────────────────────────────────

    def calibrate(
        self,
        index_code: IndexCode | str,
        base_probability: float,
        signals: SignalValues,
        candidate: Candidate,
        context: ScoringContext | None = None,
    ) -> tuple[float, bool, float]:
        """Calibrate a base probability using trained ML models.

        Returns ``(calibrated_probability, ml_applied, ml_adjustment)``.
        Falls back to ``(base_probability, False, 0.0)`` when no model is
        available.
        """
        code = _to_index_code(index_code)

        if not self.is_available(code):
            return base_probability, False, 0.0

        predictions: list[float] = []
        weights: list[float] = []

        # Committee model (higher weight — richer features)
        committee = self._committee_pipelines.get(code)
        if committee is not None and committee.is_warm:
            features = np.array([
                0,  # mcap_rank — not available at prediction time without pool
                0.0,  # sector_gap
                candidate.months_listed or 0.0,
                0,  # num_eligible
                signals.margin_of_safety,
                signals.vacancy_likelihood,
                signals.queue_position,
                signals.momentum,
                signals.sector_fit,
            ], dtype=np.float64)

            try:
                result = committee.predict(None, features)
                pred = result.predictions.get("target")
                if pred is not None and pred.point is not None:
                    prob = float(np.clip(pred.point[0], 0.0, 1.0))
                    predictions.append(prob)
                    weights.append(2.0)  # committee gets double weight
            except Exception:
                logger.debug("Committee prediction failed for %s", candidate.ticker)

        # Weight model
        weight_model = self._weight_pipelines.get(code)
        if weight_model is not None and weight_model.is_warm:
            features = np.array([
                signals.margin_of_safety,
                signals.vacancy_likelihood,
                signals.queue_position,
                signals.momentum,
                signals.sector_fit,
            ], dtype=np.float64)

            try:
                result = weight_model.predict(None, features)
                pred = result.predictions.get("target")
                if pred is not None and pred.point is not None:
                    prob = float(np.clip(pred.point[0], 0.0, 1.0))
                    predictions.append(prob)
                    weights.append(1.0)
            except Exception:
                logger.debug("Weight prediction failed for %s", candidate.ticker)

        if not predictions:
            return base_probability, False, 0.0

        # Weighted average of model predictions
        total_weight = sum(weights)
        calibrated = sum(p * w for p, w in zip(predictions, weights)) / total_weight
        calibrated = float(np.clip(calibrated, 0.0, 1.0))
        adjustment = calibrated - base_probability

        return calibrated, True, adjustment

    # ── Availability & health ─────────────────────────────────────────────

    def is_available(self, index_code: IndexCode | str) -> bool:
        """Check if any ML model is trained and warm for this index."""
        code = _to_index_code(index_code)

        committee = self._committee_pipelines.get(code)
        if committee is not None and committee.is_warm:
            return True

        weight = self._weight_pipelines.get(code)
        if weight is not None and weight.is_warm:
            return True

        return False

    def health(self, index_code: IndexCode | str) -> dict | None:
        """Get health metrics for trained models.

        Returns a dict with per-model health snapshots from jaymd-winnow,
        or ``None`` if no models are trained for this index.
        """
        code = _to_index_code(index_code)
        result: dict[str, Any] = {}

        for name, store in [
            ("committee", self._committee_pipelines),
            ("weight", self._weight_pipelines),
            ("vacancy", self._vacancy_pipelines),
        ]:
            pipeline = store.get(code)
            if pipeline is not None and pipeline.is_warm:
                # Get the last step result's health snapshot
                try:
                    last_result = pipeline.predict(None, np.zeros(5))
                    if last_result.health is not None:
                        result[name] = {
                            "worst_calibration": last_result.health.worst_calibration,
                            "worst_stability": last_result.health.worst_stability,
                        }
                except Exception:
                    result[name] = {"status": "error"}

        return result if result else None

    # ── Persistence ───────────────────────────────────────────────────────

    def save(self, path: str) -> None:
        """Save all trained models to a directory."""
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)

        for name, store in [
            ("committee", self._committee_pipelines),
            ("weight", self._weight_pipelines),
            ("vacancy", self._vacancy_pipelines),
        ]:
            for code, pipeline in store.items():
                filepath = save_dir / f"{name}_{code.value}.pkl"
                try:
                    pipeline.save(str(filepath))
                except Exception:
                    # Fallback to pickle
                    with open(filepath, "wb") as f:
                        pickle.dump(pipeline, f)

        logger.info("Models saved to %s", save_dir)

    @classmethod
    def load(cls, path: str) -> MLCalibrator:
        """Load trained models from a directory."""
        load_dir = Path(path)
        calibrator = cls()

        if not load_dir.exists():
            return calibrator

        for filepath in load_dir.glob("*.pkl"):
            name = filepath.stem
            parts = name.split("_", 1)
            if len(parts) != 2:
                continue

            model_type, code_str = parts

            try:
                code = IndexCode(code_str)
            except ValueError:
                continue

            store_map = {
                "committee": calibrator._committee_pipelines,
                "weight": calibrator._weight_pipelines,
                "vacancy": calibrator._vacancy_pipelines,
            }
            store = store_map.get(model_type)
            if store is None:
                continue

            try:
                from jaymd_winnow import AdaptivePipeline
                pipeline = AdaptivePipeline.load(str(filepath))
                store[code] = pipeline
            except Exception:
                try:
                    with open(filepath, "rb") as f:
                        store[code] = pickle.load(f)  # noqa: S301
                except Exception:
                    logger.warning("Failed to load model from %s", filepath)

        logger.info("Models loaded from %s", load_dir)
        return calibrator
