"""Stock index inclusion probability prediction."""

from __future__ import annotations

__version__ = "0.1.0"

# Primary consumer API
from index_inclusion._facade import IndexInclusion

# Lower-level API
from index_inclusion._backtest import backtest, build_training_data
from index_inclusion._loader import load_candidate, load_candidates, load_constituents
from index_inclusion._ml import MLCalibrator
from index_inclusion._scanner import scan, scan_all
from index_inclusion._scorer import score, score_many

# Types
from index_inclusion._types import (
    BacktestEvent,
    BacktestResult,
    Candidate,
    Confidence,
    HardRule,
    IndexCode,
    IndexConfig,
    Operator,
    ProbabilityLabel,
    RuleResult,
    RuleVerdict,
    ScanResult,
    ScoringContext,
    ScoringResult,
    SignalValues,
    TrainingEvent,
    VacancyContext,
    VacancyMechanics,
)

# Index definitions
from index_inclusion._indices import INDEX_CONFIGS, get_index_config

__all__ = [
    # Facade
    "IndexInclusion",
    # Functions
    "score",
    "score_many",
    "scan",
    "scan_all",
    "backtest",
    "build_training_data",
    "load_candidate",
    "load_candidates",
    "load_constituents",
    # ML
    "MLCalibrator",
    # Types
    "BacktestEvent",
    "BacktestResult",
    "Candidate",
    "Confidence",
    "HardRule",
    "IndexCode",
    "IndexConfig",
    "Operator",
    "ProbabilityLabel",
    "RuleResult",
    "RuleVerdict",
    "ScanResult",
    "ScoringContext",
    "ScoringResult",
    "SignalValues",
    "TrainingEvent",
    "VacancyContext",
    "VacancyMechanics",
    # Index data
    "INDEX_CONFIGS",
    "get_index_config",
]
