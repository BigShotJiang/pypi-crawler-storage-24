from __future__ import annotations

from collections.abc import Sequence

from index_inclusion._indices import get_index_config
from index_inclusion._rules import evaluate_eligibility
from index_inclusion._signals import (
    margin_of_safety,
    momentum,
    queue_position,
    sector_fit,
    vacancy_likelihood,
)
from index_inclusion._types import (
    Candidate,
    Confidence,
    IndexCode,
    ProbabilityLabel,
    RuleVerdict,
    ScoringContext,
    ScoringResult,
    SignalValues,
    VacancyContext,
)

# Avoid circular import — MLCalibrator is passed as a duck-typed object
# with a `calibrate` method and an `is_available` method.


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


def _probability_label(prob: float, eligible: bool) -> str:
    if not eligible:
        return ProbabilityLabel.INELIGIBLE.value
    if prob >= 0.80:
        return ProbabilityLabel.VERY_HIGH.value
    if prob >= 0.60:
        return ProbabilityLabel.HIGH.value
    if prob >= 0.40:
        return ProbabilityLabel.MEDIUM.value
    if prob >= 0.20:
        return ProbabilityLabel.LOW.value
    return ProbabilityLabel.VERY_LOW.value


def _confidence_rating(skipped: int, total: int) -> str:
    if total == 0:
        return Confidence.LOW.value
    if skipped > total * 0.3:
        return Confidence.LOW.value
    if skipped > 0:
        return Confidence.MEDIUM.value
    return Confidence.HIGH.value


def score(
    candidate: Candidate,
    index_code: IndexCode | str,
    *,
    context: ScoringContext | None = None,
    ml_calibrator: object | None = None,
) -> ScoringResult:
    """Score a single candidate for a single index.

    Parameters
    ----------
    candidate:
        The stock to evaluate.
    index_code:
        Which index to evaluate against.
    context:
        Optional current constituents and eligible pool for richer signals.
    ml_calibrator:
        Optional ``MLCalibrator`` instance for Stage 3 calibration.
    """
    config = get_index_config(index_code)
    ctx = context or ScoringContext()

    # ── Stage 1: Eligibility ──────────────────────────────────────────────
    eligible, rule_results = evaluate_eligibility(index_code, candidate)

    passed = sum(1 for r in rule_results if r.verdict is RuleVerdict.PASS)
    failed = sum(1 for r in rule_results if r.verdict is RuleVerdict.FAIL)
    skipped = sum(1 for r in rule_results if r.verdict is RuleVerdict.SKIP)
    failing_names = tuple(r.rule_name for r in rule_results if r.verdict is RuleVerdict.FAIL)

    vacancy_ctx = VacancyContext(
        fixed_count=config.vacancy.fixed_count,
        target_count=config.vacancy.target_count,
        requires_vacancy=config.vacancy.requires_vacancy,
        can_displace=config.vacancy.can_displace,
    )

    notes: list[str] = []
    if config.vacancy.requires_vacancy:
        notes.append(f"{config.name} requires a vacancy before additions.")

    if not eligible:
        return ScoringResult(
            index_code=config.code.value,
            index_name=config.name,
            ticker=candidate.ticker,
            eligible=False,
            rules_passed=passed,
            rules_failed=failed,
            rules_skipped=skipped,
            failing_rules=failing_names,
            probability=0.0,
            base_probability=0.0,
            probability_label=ProbabilityLabel.INELIGIBLE.value,
            confidence=_confidence_rating(skipped, len(rule_results)),
            ml_applied=False,
            ml_adjustment=0.0,
            signals=None,
            vacancy_context=vacancy_ctx,
            rule_results=rule_results,
            notes=tuple(notes),
        )

    # ── Stage 2: Heuristic scoring ────────────────────────────────────────
    margin = margin_of_safety(config.hard_rules, rule_results)
    vacancy = vacancy_likelihood(index_code, ctx.current_constituents)
    queue = queue_position(candidate, ctx.eligible_non_members)
    mom = momentum(candidate)
    sector = sector_fit(candidate, index_code, ctx.current_constituents)

    signals = SignalValues(
        margin_of_safety=margin,
        vacancy_likelihood=vacancy,
        queue_position=queue,
        momentum=mom,
        sector_fit=sector,
    )

    base_prob = _clamp(
        0.30 * margin + 0.25 * vacancy + 0.25 * queue + 0.10 * mom + 0.10 * sector
    )

    # ── Stage 3: ML calibration (optional) ────────────────────────────────
    ml_applied = False
    ml_adjustment = 0.0
    final_prob = base_prob

    if ml_calibrator is not None and hasattr(ml_calibrator, "is_available"):
        if ml_calibrator.is_available(index_code):  # type: ignore[union-attr]
            calibrated, ml_applied, ml_adjustment = ml_calibrator.calibrate(  # type: ignore[union-attr]
                index_code, base_prob, signals, candidate, ctx
            )
            final_prob = _clamp(calibrated)

    return ScoringResult(
        index_code=config.code.value,
        index_name=config.name,
        ticker=candidate.ticker,
        eligible=True,
        rules_passed=passed,
        rules_failed=failed,
        rules_skipped=skipped,
        failing_rules=failing_names,
        probability=final_prob,
        base_probability=base_prob,
        probability_label=_probability_label(final_prob, True),
        confidence=_confidence_rating(skipped, len(rule_results)),
        ml_applied=ml_applied,
        ml_adjustment=ml_adjustment,
        signals=signals,
        vacancy_context=vacancy_ctx,
        rule_results=rule_results,
        notes=tuple(notes),
    )


def score_many(
    candidates: Sequence[Candidate],
    index_codes: Sequence[IndexCode | str] | IndexCode | str,
    *,
    context: ScoringContext | None = None,
    ml_calibrator: object | None = None,
) -> list[ScoringResult]:
    """Score multiple candidates across one or more indices.

    Returns results sorted by probability descending.
    """
    if isinstance(index_codes, (str, IndexCode)):
        index_codes = [index_codes]

    results: list[ScoringResult] = []
    for idx in index_codes:
        for cand in candidates:
            results.append(score(cand, idx, context=context, ml_calibrator=ml_calibrator))

    results.sort(key=lambda r: r.probability, reverse=True)
    return results
