from __future__ import annotations

import logging
from collections.abc import Sequence
from datetime import date
from statistics import mean, median

from index_inclusion._loader import load_candidates, load_constituent_symbols
from index_inclusion._rules import evaluate_eligibility
from index_inclusion._scorer import score, score_many
from index_inclusion._signals import (
    margin_of_safety,
    momentum,
    queue_position,
    sector_fit,
    vacancy_likelihood,
)
from index_inclusion._indices import get_index_config
from index_inclusion._types import (
    BacktestEvent,
    BacktestResult,
    Candidate,
    IndexCode,
    ScoringContext,
    SignalValues,
    TrainingEvent,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Historical change retrieval
# ---------------------------------------------------------------------------


def _historical_changes(
    client: object,
    index_code: IndexCode,
) -> list[dict]:
    """Fetch historical constituent changes from FMP."""
    method_map: dict[IndexCode, str] = {
        IndexCode.SP500: "historical_sp500_constituent",
        IndexCode.NDX: "historical_nasdaq_constituent",
        IndexCode.DJIA: "historical_dowjones_constituent",
    }
    method_name = method_map.get(index_code)
    if method_name is None:
        return []
    try:
        return getattr(client, method_name)() or []
    except Exception:
        logger.warning("Failed to fetch historical changes for %s", index_code.value)
        return []


def _filter_additions(
    changes: list[dict],
    start_year: int,
    end_year: int,
) -> list[dict]:
    """Filter to addition events within the year range."""
    additions = []
    for ch in changes:
        date_str = ch.get("dateAdded") or ch.get("date") or ""
        if not date_str:
            continue
        try:
            event_date = date.fromisoformat(date_str[:10])
        except (ValueError, TypeError):
            continue
        if start_year <= event_date.year <= end_year:
            added = ch.get("symbol") or ch.get("addedSecurity") or ""
            removed = ch.get("removedTicker") or ch.get("removedSecurity") or ""
            reason = ch.get("reason") or ""
            if added:
                additions.append({
                    "event_date": event_date,
                    "added": added,
                    "removed": removed,
                    "reason": reason,
                })
    # Sort chronologically
    additions.sort(key=lambda x: x["event_date"])
    return additions


# ---------------------------------------------------------------------------
# Candidate pool construction
# ---------------------------------------------------------------------------


def _build_candidate_pool(
    client: object,
    index_code: IndexCode,
    event_date: date,
    constituent_symbols: set[str],
    *,
    max_pool: int = 200,
    max_workers: int = 10,
) -> list[Candidate]:
    """Build a pool of non-constituent candidates as of a historical date.

    Uses the current stock list filtered by IPO date and loads historical data
    via ``as_of``.
    """
    try:
        stock_list = client.stock_list()  # type: ignore[union-attr]
    except Exception:
        return []

    if not stock_list:
        return []

    config = get_index_config(index_code)

    # Pre-filter: exclude constituents, ETFs, and clearly ineligible
    pool_symbols: list[str] = []
    for s in stock_list:
        sym = s.get("symbol", "")
        if not sym or sym in constituent_symbols:
            continue
        # Skip obvious non-candidates
        if s.get("type") and s["type"] not in ("stock", ""):
            continue
        pool_symbols.append(sym)
        if len(pool_symbols) >= max_pool * 3:  # fetch more, will filter after loading
            break

    # Load candidates with historical data
    candidates = load_candidates(
        client,
        pool_symbols[:max_pool],
        as_of=event_date,
        max_workers=max_workers,
    )

    return candidates


# ---------------------------------------------------------------------------
# Backtest
# ---------------------------------------------------------------------------


def backtest(
    client: object,
    index_code: IndexCode | str,
    *,
    start_year: int = 2016,
    end_year: int = 2025,
    ml_calibrator: object | None = None,
    max_pool: int = 200,
    max_workers: int = 10,
) -> BacktestResult:
    """Evaluate prediction accuracy against actual historical index changes.

    For each historical addition event, reconstructs the state at that date,
    scores all candidates, and records where the actual addition ranked.
    """
    if isinstance(index_code, str):
        index_code = IndexCode(index_code)

    changes = _historical_changes(client, index_code)
    additions = _filter_additions(changes, start_year, end_year)

    if not additions:
        return BacktestResult(
            index_code=index_code,
            start_year=start_year,
            end_year=end_year,
            events=(),
            total_events=0,
            precision_at_3=0.0,
            precision_at_5=0.0,
            precision_at_10=0.0,
            mean_predicted_rank=0.0,
            median_predicted_rank=0.0,
        )

    # Build constituent set (walk forward)
    current_members: set[str] = set()
    try:
        initial = load_constituent_symbols(client, index_code)
        current_members = set(initial)
    except Exception:
        pass

    # Process changes before our window to build initial state
    all_changes = _historical_changes(client, index_code)
    pre_changes = _filter_additions(all_changes, 2000, start_year - 1)
    for ch in pre_changes:
        if ch["added"]:
            current_members.add(ch["added"])
        if ch["removed"]:
            current_members.discard(ch["removed"])

    events: list[BacktestEvent] = []

    for i, addition in enumerate(additions):
        event_date = addition["event_date"]
        added_ticker = addition["added"]
        removed_ticker = addition["removed"]
        reason = addition["reason"]

        logger.info(
            "Backtesting event %d/%d: %s added to %s on %s",
            i + 1, len(additions), added_ticker, index_code.value, event_date,
        )

        # Update constituent set
        if removed_ticker:
            current_members.discard(removed_ticker)

        # Build candidate pool
        pool = _build_candidate_pool(
            client, index_code, event_date, current_members,
            max_pool=max_pool, max_workers=max_workers,
        )

        # Ensure the actually-added stock is in the pool
        added_in_pool = any(c.ticker == added_ticker for c in pool)
        if not added_in_pool:
            try:
                added_candidate = load_candidates(
                    client, [added_ticker], as_of=event_date, max_workers=1
                )
                if added_candidate:
                    pool.extend(added_candidate)
            except Exception:
                pass

        if not pool:
            current_members.add(added_ticker)
            continue

        # Score all candidates
        context = ScoringContext(eligible_non_members=pool)
        results = score_many(
            pool, index_code, context=context, ml_calibrator=ml_calibrator
        )

        # Find where the actual addition ranked
        ranked_tickers = [r.ticker for r in results]
        predicted_rank: int | None = None
        predicted_prob = 0.0
        if added_ticker in ranked_tickers:
            predicted_rank = ranked_tickers.index(added_ticker) + 1
            predicted_prob = results[predicted_rank - 1].probability

        top_k = tuple(ranked_tickers[:10])

        events.append(BacktestEvent(
            event_date=event_date,
            added_ticker=added_ticker,
            removed_ticker=removed_ticker,
            vacancy_cause=reason,
            predicted_rank=predicted_rank,
            top_k_predictions=top_k,
            actual_in_top_3=predicted_rank is not None and predicted_rank <= 3,
            actual_in_top_5=predicted_rank is not None and predicted_rank <= 5,
            actual_in_top_10=predicted_rank is not None and predicted_rank <= 10,
            predicted_probability=predicted_prob,
            num_eligible=len([r for r in results if r.eligible]),
        ))

        current_members.add(added_ticker)

    # Aggregate metrics
    total = len(events)
    ranks = [e.predicted_rank for e in events if e.predicted_rank is not None]

    return BacktestResult(
        index_code=index_code,
        start_year=start_year,
        end_year=end_year,
        events=tuple(events),
        total_events=total,
        precision_at_3=sum(1 for e in events if e.actual_in_top_3) / total if total else 0.0,
        precision_at_5=sum(1 for e in events if e.actual_in_top_5) / total if total else 0.0,
        precision_at_10=sum(1 for e in events if e.actual_in_top_10) / total if total else 0.0,
        mean_predicted_rank=mean(ranks) if ranks else 0.0,
        median_predicted_rank=median(ranks) if ranks else 0.0,
    )


# ---------------------------------------------------------------------------
# Training data construction
# ---------------------------------------------------------------------------


def build_training_data(
    client: object,
    index_code: IndexCode | str,
    *,
    start_year: int = 2016,
    end_year: int = 2025,
    max_pool: int = 200,
    max_workers: int = 10,
) -> list[TrainingEvent]:
    """Build ML training data from historical index change events.

    For each addition event, the actually-added stock is labelled
    ``was_added=True`` and all other eligible candidates are ``was_added=False``.
    """
    if isinstance(index_code, str):
        index_code = IndexCode(index_code)

    changes = _historical_changes(client, index_code)
    additions = _filter_additions(changes, start_year, end_year)
    config = get_index_config(index_code)

    training_events: list[TrainingEvent] = []

    current_members: set[str] = set()
    try:
        initial = load_constituent_symbols(client, index_code)
        current_members = set(initial)
    except Exception:
        pass

    all_changes = _historical_changes(client, index_code)
    pre_changes = _filter_additions(all_changes, 2000, start_year - 1)
    for ch in pre_changes:
        if ch["added"]:
            current_members.add(ch["added"])
        if ch["removed"]:
            current_members.discard(ch["removed"])

    for i, addition in enumerate(additions):
        event_date = addition["event_date"]
        added_ticker = addition["added"]
        removed_ticker = addition["removed"]
        reason = addition["reason"]

        logger.info(
            "Building training data %d/%d: %s on %s",
            i + 1, len(additions), added_ticker, event_date,
        )

        if removed_ticker:
            current_members.discard(removed_ticker)

        pool = _build_candidate_pool(
            client, index_code, event_date, current_members,
            max_pool=max_pool, max_workers=max_workers,
        )

        # Ensure the added stock is in pool
        added_in_pool = any(c.ticker == added_ticker for c in pool)
        if not added_in_pool:
            try:
                added_candidate = load_candidates(
                    client, [added_ticker], as_of=event_date, max_workers=1
                )
                if added_candidate:
                    pool.extend(added_candidate)
            except Exception:
                pass

        if not pool:
            current_members.add(added_ticker)
            continue

        # Score to get signals
        context = ScoringContext(eligible_non_members=pool)
        results = score_many(pool, index_code, context=context)

        # Rank by market cap
        pool_sorted = sorted(pool, key=lambda c: c.market_cap_usd or 0, reverse=True)
        mcap_ranks = {c.ticker: i + 1 for i, c in enumerate(pool_sorted)}

        # Compute sector gap (simplified)
        sector_field = "gics_sector" if index_code not in (IndexCode.NDX, IndexCode.FTSE100) else "icb_sector"
        sector_counts: dict[str, int] = {}
        for c in pool:
            s = getattr(c, sector_field, None)
            if s:
                sector_counts[s] = sector_counts.get(s, 0) + 1
        total_sectors = sum(sector_counts.values()) or 1
        avg_sector_weight = 1.0 / max(len(sector_counts), 1)

        for scored in results:
            if not scored.eligible or scored.signals is None:
                continue

            candidate = next((c for c in pool if c.ticker == scored.ticker), None)
            if candidate is None:
                continue

            cand_sector = getattr(candidate, sector_field, None)
            sector_weight = sector_counts.get(cand_sector or "", 0) / total_sectors
            sector_gap = avg_sector_weight - sector_weight

            training_events.append(TrainingEvent(
                event_date=event_date,
                index_code=index_code,
                ticker=scored.ticker,
                was_added=(scored.ticker == added_ticker),
                candidate=candidate,
                signals=scored.signals,
                mcap_rank_among_eligible=mcap_ranks.get(scored.ticker, len(pool)),
                sector_gap=sector_gap,
                months_eligible=candidate.months_listed or 0.0,
                num_eligible_candidates=len([r for r in results if r.eligible]),
                vacancy_cause=reason,
            ))

        current_members.add(added_ticker)

    return training_events
