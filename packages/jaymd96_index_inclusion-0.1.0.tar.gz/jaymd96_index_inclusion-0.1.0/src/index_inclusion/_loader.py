from __future__ import annotations

import logging
from collections.abc import Sequence
from datetime import date, timedelta

from index_inclusion._types import Candidate, IndexCode

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Exchange name mapping (FMP → spec)
# ---------------------------------------------------------------------------

_EXCHANGE_MAP: dict[str, str] = {
    "New York Stock Exchange": "NYSE",
    "NYSE": "NYSE",
    "NASDAQ Global Select Market": "NASDAQ Global Select",
    "NASDAQ Global Market": "NASDAQ Global Market",
    "NASDAQ Capital Market": "NASDAQ Capital Market",
    "NYSE American": "NYSE American",
    "NYSE MKT": "NYSE American",
    "NYSE Arca": "NYSE Arca",
    "AMEX": "NYSE American",
    "Cboe BZX Exchange": "Cboe BZX",
    "Cboe BYX Exchange": "Cboe BYX",
    "Cboe EDGA Exchange": "Cboe EDGA",
    "Cboe EDGX Exchange": "Cboe EDGX",
    "London Stock Exchange": "LSE Main Market",
    "LSE": "LSE Main Market",
}


def _map_exchange(raw: str | None) -> str | None:
    if raw is None:
        return None
    return _EXCHANGE_MAP.get(raw, raw)


def _months_since(ipo_date_str: str | None, ref: date) -> float | None:
    if not ipo_date_str:
        return None
    try:
        ipo = date.fromisoformat(ipo_date_str)
    except (ValueError, TypeError):
        return None
    delta = ref - ipo
    return max(0.0, delta.days / 30.44)


def _safe_get(data: list[dict] | dict | None, key: str, default: object = None) -> object:
    """Safely extract a value from an FMP response (list-of-dicts or dict)."""
    if data is None:
        return default
    if isinstance(data, list):
        if not data:
            return default
        data = data[0]
    return data.get(key, default)


# ---------------------------------------------------------------------------
# Core loader
# ---------------------------------------------------------------------------


def load_candidate(
    client: object,
    symbol: str,
    *,
    as_of: date | None = None,
    _sp500_members: set[str] | None = None,
) -> Candidate:
    """Load a single candidate from FMP data.

    Parameters
    ----------
    client:
        An ``FMPClient`` instance from ``jaymd96-fmp``.
    symbol:
        Ticker symbol to load.
    as_of:
        If ``None`` (default), loads current data.  If a date, reconstructs
        the candidate's approximate state at that historical date.
    _sp500_members:
        Pre-fetched set of SP500 member tickers (avoids repeated API calls).
    """
    ref_date = as_of or date.today()

    # --- Profile (static fields) ---
    try:
        profile = client.profile(symbol)  # type: ignore[union-attr]
    except Exception:
        profile = None

    company_name = _safe_get(profile, "companyName")
    domicile = _safe_get(profile, "country")
    raw_exchange = _safe_get(profile, "exchange")
    exchange = _map_exchange(raw_exchange)  # type: ignore[arg-type]
    gics_sector = _safe_get(profile, "sector")
    ipo_date_str = _safe_get(profile, "ipoDate")
    months_listed = _months_since(ipo_date_str, ref_date)  # type: ignore[arg-type]
    is_etf = _safe_get(profile, "isEtf", False)

    # Infer security type
    security_type: str | None = None
    if is_etf:
        security_type = "ETF"
    elif gics_sector == "Real Estate":
        security_type = "REIT"
    else:
        security_type = "Common Stock"

    # --- Price / Market cap ---
    market_cap_usd: float | None = None
    share_price: float | None = None

    if as_of is None:
        try:
            quote = client.quote(symbol)  # type: ignore[union-attr]
            share_price = _safe_get(quote, "price")  # type: ignore[assignment]
            market_cap_usd = _safe_get(quote, "marketCap")  # type: ignore[assignment]
        except Exception:
            pass
    else:
        try:
            hist_mcap = client.historical_market_capitalization(  # type: ignore[union-attr]
                symbol, from_date=str(as_of), to_date=str(as_of)
            )
            market_cap_usd = _safe_get(hist_mcap, "marketCap")  # type: ignore[assignment]
        except Exception:
            pass
        try:
            hist_price = client.historical_price_eod_full(  # type: ignore[union-attr]
                symbol, from_date=str(as_of - timedelta(days=5)), to_date=str(as_of)
            )
            if hist_price:
                share_price = hist_price[0].get("close") if isinstance(hist_price, list) else None
        except Exception:
            pass

    # --- Float data ---
    iwf: float | None = None
    free_float_pct: float | None = None
    float_market_cap_usd: float | None = None

    try:
        sf = client.shares_float(symbol)  # type: ignore[union-attr]
        float_shares = _safe_get(sf, "floatShares")
        outstanding = _safe_get(sf, "outstandingShares")
        if float_shares and outstanding and outstanding > 0:
            iwf = float(float_shares) / float(outstanding)  # type: ignore[arg-type]
            free_float_pct = iwf * 100.0
            if market_cap_usd is not None:
                float_market_cap_usd = market_cap_usd * iwf
    except Exception:
        pass

    # --- Earnings ---
    sum_4q_gaap_earnings: float | None = None
    latest_quarter_earnings: float | None = None

    try:
        stmts = client.income_statement(symbol, period="quarter", limit=8)  # type: ignore[union-attr]
        if stmts:
            # Filter to quarters before as_of if historical
            if as_of is not None:
                stmts = [
                    s for s in stmts
                    if s.get("date") and s["date"] <= str(as_of)
                ]
            if stmts:
                latest_quarter_earnings = stmts[0].get("netIncome")
                quarters = stmts[:4]
                net_incomes = [q.get("netIncome") for q in quarters if q.get("netIncome") is not None]
                if net_incomes:
                    sum_4q_gaap_earnings = sum(net_incomes)
    except Exception:
        pass

    # --- Volume / liquidity metrics ---
    min_monthly_volume_6m: int | None = None
    avg_daily_traded_value_3m: float | None = None
    float_adj_liquidity_ratio: float | None = None
    market_cap_growth_1y: float | None = None

    try:
        price_from = ref_date - timedelta(days=400)  # ~13 months for both 6mo vol and 1yr growth
        eod = client.historical_price_eod_full(  # type: ignore[union-attr]
            symbol, from_date=str(price_from), to_date=str(ref_date)
        )
        if eod:
            # Monthly volumes (last 6 months)
            six_mo_ago = ref_date - timedelta(days=183)
            monthly_vols: dict[str, int] = {}
            daily_dv_3m: list[float] = []
            three_mo_ago = ref_date - timedelta(days=91)
            annual_dollar_volume = 0.0

            for bar in eod:
                bar_date_str = bar.get("date", "")
                close = bar.get("close", 0) or 0
                volume = bar.get("volume", 0) or 0
                dollar_vol = close * volume
                annual_dollar_volume += dollar_vol

                if bar_date_str >= str(six_mo_ago):
                    month_key = bar_date_str[:7]
                    monthly_vols[month_key] = monthly_vols.get(month_key, 0) + volume

                if bar_date_str >= str(three_mo_ago):
                    daily_dv_3m.append(dollar_vol)

            if monthly_vols:
                min_monthly_volume_6m = min(monthly_vols.values())

            if daily_dv_3m:
                avg_daily_traded_value_3m = sum(daily_dv_3m) / len(daily_dv_3m)

            if float_market_cap_usd and float_market_cap_usd > 0:
                float_adj_liquidity_ratio = annual_dollar_volume / float_market_cap_usd

            # Market cap growth (1yr)
            one_yr_ago = ref_date - timedelta(days=365)
            old_bars = [b for b in eod if b.get("date", "") <= str(one_yr_ago + timedelta(days=10))]
            if old_bars and market_cap_usd is not None:
                old_close = old_bars[-1].get("close", 0) or 0
                new_close = eod[0].get("close", 0) or 0
                if old_close > 0:
                    market_cap_growth_1y = (new_close - old_close) / old_close
    except Exception:
        logger.debug("Failed to load price history for %s", symbol, exc_info=True)

    # --- SP500 membership ---
    in_sp500: bool | None = None
    if _sp500_members is not None:
        in_sp500 = symbol in _sp500_members
    elif as_of is None:
        try:
            members = client.sp500_constituent()  # type: ignore[union-attr]
            if members:
                in_sp500 = any(m.get("symbol") == symbol for m in members)
        except Exception:
            pass

    return Candidate(
        ticker=symbol,
        company_name=company_name,  # type: ignore[arg-type]
        domicile=domicile,  # type: ignore[arg-type]
        exchange=exchange,
        security_type=security_type,
        gics_sector=gics_sector,  # type: ignore[arg-type]
        market_cap_usd=market_cap_usd,
        float_market_cap_usd=float_market_cap_usd,
        share_price=share_price,
        iwf=iwf,
        free_float_pct=free_float_pct,
        float_adj_liquidity_ratio=float_adj_liquidity_ratio,
        min_monthly_volume_6m=min_monthly_volume_6m,
        avg_daily_traded_value_3m=avg_daily_traded_value_3m,
        sum_4q_gaap_earnings=sum_4q_gaap_earnings,
        latest_quarter_earnings=latest_quarter_earnings,
        months_listed=months_listed,
        in_sp500=in_sp500,
        market_cap_growth_1y=market_cap_growth_1y,
    )


def load_candidates(
    client: object,
    symbols: Sequence[str],
    *,
    as_of: date | None = None,
    max_workers: int = 10,
) -> list[Candidate]:
    """Load multiple candidates, using concurrent fetching where possible."""
    # Pre-fetch SP500 membership once
    sp500_members: set[str] | None = None
    if as_of is None:
        try:
            members = client.sp500_constituent()  # type: ignore[union-attr]
            sp500_members = {m.get("symbol", "") for m in (members or [])}
        except Exception:
            pass

    results: list[Candidate] = []
    for sym in symbols:
        try:
            c = load_candidate(client, sym, as_of=as_of, _sp500_members=sp500_members)
            results.append(c)
        except Exception:
            logger.warning("Failed to load candidate %s", sym, exc_info=True)
    return results


def load_constituent_symbols(
    client: object,
    index_code: IndexCode | str,
) -> list[str]:
    """Get the current constituent ticker symbols for an index."""
    if isinstance(index_code, str):
        index_code = IndexCode(index_code)

    method_map: dict[IndexCode, str] = {
        IndexCode.SP500: "sp500_constituent",
        IndexCode.NDX: "nasdaq_constituent",
        IndexCode.DJIA: "dowjones_constituent",
    }

    method_name = method_map.get(index_code)
    if method_name is None:
        return []

    try:
        data = getattr(client, method_name)()
        return [d.get("symbol", "") for d in (data or []) if d.get("symbol")]
    except Exception:
        logger.warning("Failed to load constituents for %s", index_code.value, exc_info=True)
        return []


def load_constituents(
    client: object,
    index_code: IndexCode | str,
    *,
    max_workers: int = 10,
) -> list[Candidate]:
    """Load full candidate data for all current constituents of an index."""
    symbols = load_constituent_symbols(client, index_code)
    if not symbols:
        return []
    return load_candidates(client, symbols, max_workers=max_workers)
