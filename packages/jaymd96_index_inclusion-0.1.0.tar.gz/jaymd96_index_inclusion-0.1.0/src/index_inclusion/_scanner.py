from __future__ import annotations

import logging
from collections.abc import Sequence
from datetime import date

from index_inclusion._loader import load_candidates, load_constituent_symbols
from index_inclusion._scorer import score_many
from index_inclusion._types import IndexCode, ScanResult, ScoringContext

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pre-filter configs per index
# ---------------------------------------------------------------------------

_SCREENER_FILTERS: dict[IndexCode, dict] = {
    IndexCode.SP500: dict(market_cap_more_than=15_000_000_000, is_etf=False),
    IndexCode.SP400: dict(
        market_cap_more_than=5_000_000_000,
        market_cap_lower_than=25_000_000_000,
        is_etf=False,
    ),
    IndexCode.SP600: dict(
        market_cap_more_than=800_000_000,
        market_cap_lower_than=10_000_000_000,
        is_etf=False,
    ),
    IndexCode.NDX: dict(market_cap_more_than=5_000_000_000, is_etf=False),
    IndexCode.FTSE100: dict(is_etf=False),
    IndexCode.DJIA: dict(),  # uses SP500 members directly
    IndexCode.R3000: dict(market_cap_more_than=20_000_000, is_etf=False),
}


def _screener_symbols(client: object, index_code: IndexCode) -> list[str]:
    """Get pre-filtered symbols from the FMP screener."""
    filters = _SCREENER_FILTERS.get(index_code, {})
    if not filters:
        return []
    try:
        results = client.screener(**filters)  # type: ignore[union-attr]
        return [r.get("symbol", "") for r in (results or []) if r.get("symbol")]
    except Exception:
        logger.warning("Screener failed for %s, falling back to empty", index_code.value)
        return []


def scan(
    client: object,
    index_code: IndexCode | str,
    *,
    ml_calibrator: object | None = None,
    max_candidates: int = 500,
    max_workers: int = 10,
) -> ScanResult:
    """Scan the stock universe and rank candidates for an index.

    Parameters
    ----------
    client:
        An ``FMPClient`` instance.
    index_code:
        Which index to scan for.
    ml_calibrator:
        Optional trained ``MLCalibrator`` for Stage 3 calibration.
    max_candidates:
        Maximum number of candidates to score (for performance).
    max_workers:
        Concurrency for data loading.
    """
    if isinstance(index_code, str):
        index_code = IndexCode(index_code)

    # 1. Get current constituents
    constituent_symbols = load_constituent_symbols(client, index_code)
    constituent_set = set(constituent_symbols)

    # 2. Pre-filter universe
    if index_code is IndexCode.DJIA:
        # DJIA candidates must be SP500 members
        universe_symbols = load_constituent_symbols(client, IndexCode.SP500)
    else:
        universe_symbols = _screener_symbols(client, index_code)

    # Exclude current constituents
    candidate_symbols = [s for s in universe_symbols if s not in constituent_set]

    # Cap for performance
    if len(candidate_symbols) > max_candidates:
        candidate_symbols = candidate_symbols[:max_candidates]

    universe_size = len(candidate_symbols)

    # 3. Load full candidate data
    candidates = load_candidates(client, candidate_symbols, max_workers=max_workers)

    # 4. Load constituent data for context (if we have constituent symbols)
    constituent_candidates = load_candidates(
        client, constituent_symbols[:50], max_workers=max_workers  # sample for performance
    ) if constituent_symbols else []

    # 5. Score all candidates
    context = ScoringContext(
        current_constituents=constituent_candidates or None,
        eligible_non_members=candidates or None,
    )

    results = score_many(
        candidates,
        index_code,
        context=context,
        ml_calibrator=ml_calibrator,
    )

    eligible_results = [r for r in results if r.eligible]

    return ScanResult(
        index_code=index_code,
        scan_date=date.today(),
        universe_size=universe_size,
        eligible_count=len(eligible_results),
        results=tuple(results),
        current_constituents=tuple(constituent_symbols),
    )


def scan_all(
    client: object,
    index_codes: Sequence[IndexCode | str] | None = None,
    *,
    ml_calibrator: object | None = None,
    max_candidates: int = 500,
    max_workers: int = 10,
) -> dict[IndexCode, ScanResult]:
    """Scan all indices (or a subset) for candidates.

    Shares the same ``client`` across all scans so the DuckDB cache is reused.
    """
    if index_codes is None:
        codes = list(IndexCode)
    else:
        codes = [IndexCode(c) if isinstance(c, str) else c for c in index_codes]

    return {
        code: scan(
            client,
            code,
            ml_calibrator=ml_calibrator,
            max_candidates=max_candidates,
            max_workers=max_workers,
        )
        for code in codes
    }
