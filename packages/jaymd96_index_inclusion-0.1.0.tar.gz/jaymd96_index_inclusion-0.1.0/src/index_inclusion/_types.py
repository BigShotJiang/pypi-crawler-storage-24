from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from enum import Enum
from typing import Any


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class IndexCode(str, Enum):
    SP500 = "SP500"
    SP400 = "SP400"
    SP600 = "SP600"
    NDX = "NDX"
    FTSE100 = "FTSE100"
    DJIA = "DJIA"
    R3000 = "R3000"


class Operator(str, Enum):
    GE = ">="
    LE = "<="
    GT = ">"
    LT = "<"
    EQ = "=="
    IN = "in"
    NOT_IN = "not_in"


class RuleVerdict(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    SKIP = "SKIP"


class ProbabilityLabel(str, Enum):
    VERY_HIGH = "Very High"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    VERY_LOW = "Very Low"
    INELIGIBLE = "Ineligible"


class Confidence(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


# ---------------------------------------------------------------------------
# Index configuration
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HardRule:
    """A single eligibility rule for an index."""

    name: str
    field: str
    operator: Operator
    threshold: Any
    notes: str = ""


@dataclass(frozen=True)
class VacancyMechanics:
    """How an index creates openings for new members."""

    fixed_count: bool
    target_count: int
    requires_vacancy: bool
    can_displace: bool
    default_vacancy_score: float
    base_rate_fallback: float


@dataclass(frozen=True)
class IndexConfig:
    """Complete configuration for a single index."""

    code: IndexCode
    name: str
    hard_rules: tuple[HardRule, ...]
    vacancy: VacancyMechanics
    selection_type: str  # "committee", "rank", "rules"
    ml_applicable: bool


# ---------------------------------------------------------------------------
# Candidate data
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Candidate:
    """Flat record representing a candidate stock.

    All fields except ``ticker`` are optional.  Missing fields cause the
    corresponding rule to be SKIPped (not failed) and reduce the confidence
    rating.
    """

    ticker: str
    company_name: str | None = None
    domicile: str | None = None
    exchange: str | None = None
    security_type: str | None = None
    gics_sector: str | None = None
    icb_sector: str | None = None
    ftse_nationality: str | None = None
    trading_currency: str | None = None
    market_cap_usd: float | None = None
    float_market_cap_usd: float | None = None
    share_price: float | None = None
    iwf: float | None = None
    free_float_pct: float | None = None
    float_adj_liquidity_ratio: float | None = None
    min_monthly_volume_6m: int | None = None
    avg_daily_traded_value_3m: float | None = None
    avg_daily_dollar_volume: float | None = None
    monthly_median_turnover_pct: float | None = None
    sum_4q_gaap_earnings: float | None = None
    latest_quarter_earnings: float | None = None
    months_listed: float | None = None
    trading_days_since_listing: int | None = None
    unrestricted_voting_pct: float | None = None
    in_sp500: bool | None = None
    in_bankruptcy: bool | None = None
    pending_disqualifying_event: bool | None = None
    sec_filings_current: bool | None = None
    files_10K_10Q: bool | None = None
    market_cap_growth_1y: float | None = None


# ---------------------------------------------------------------------------
# Rule evaluation results
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RuleResult:
    """Result of evaluating a single hard rule against a candidate."""

    rule_name: str
    verdict: RuleVerdict
    actual_value: Any
    threshold: Any
    detail: str


# ---------------------------------------------------------------------------
# Signal values
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SignalValues:
    """The five heuristic signal scores from Stage 2."""

    margin_of_safety: float
    vacancy_likelihood: float
    queue_position: float
    momentum: float
    sector_fit: float


# ---------------------------------------------------------------------------
# Scoring context & output
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class VacancyContext:
    """Vacancy information included in the scoring output."""

    fixed_count: bool
    target_count: int
    requires_vacancy: bool
    can_displace: bool


@dataclass(frozen=True)
class ScoringContext:
    """External context for more accurate scoring.

    Without this the scorer uses fallbacks (base rates, market-cap proxy,
    neutral sector score).
    """

    current_constituents: list[Candidate] | None = None
    eligible_non_members: list[Candidate] | None = None


@dataclass(frozen=True)
class ScoringResult:
    """Complete output for a (candidate, index) pair."""

    index_code: str
    index_name: str
    ticker: str

    eligible: bool
    rules_passed: int
    rules_failed: int
    rules_skipped: int
    failing_rules: tuple[str, ...]

    probability: float
    base_probability: float
    probability_label: str
    confidence: str

    ml_applied: bool
    ml_adjustment: float

    signals: SignalValues | None
    vacancy_context: VacancyContext
    rule_results: tuple[RuleResult, ...]
    notes: tuple[str, ...]


# ---------------------------------------------------------------------------
# Scanner output
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ScanResult:
    """Result of scanning an entire universe for one index."""

    index_code: IndexCode
    scan_date: date
    universe_size: int
    eligible_count: int
    results: tuple[ScoringResult, ...]
    current_constituents: tuple[str, ...]


# ---------------------------------------------------------------------------
# Backtesting
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BacktestEvent:
    """One historical addition event and how our model performed."""

    event_date: date
    added_ticker: str
    removed_ticker: str
    vacancy_cause: str
    predicted_rank: int | None
    top_k_predictions: tuple[str, ...]
    actual_in_top_3: bool
    actual_in_top_5: bool
    actual_in_top_10: bool
    predicted_probability: float
    num_eligible: int


@dataclass(frozen=True)
class BacktestResult:
    """Aggregate metrics from a backtest run."""

    index_code: IndexCode
    start_year: int
    end_year: int
    events: tuple[BacktestEvent, ...]
    total_events: int
    precision_at_3: float
    precision_at_5: float
    precision_at_10: float
    mean_predicted_rank: float
    median_predicted_rank: float


# ---------------------------------------------------------------------------
# ML training data
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TrainingEvent:
    """One row of ML training data from a historical index change event."""

    event_date: date
    index_code: IndexCode
    ticker: str
    was_added: bool
    candidate: Candidate
    signals: SignalValues
    mcap_rank_among_eligible: int
    sector_gap: float
    months_eligible: float
    num_eligible_candidates: int
    vacancy_cause: str
