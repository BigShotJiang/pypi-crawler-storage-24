from __future__ import annotations

from index_inclusion._types import HardRule, IndexCode, IndexConfig, Operator, VacancyMechanics

# ---------------------------------------------------------------------------
# Shared exchange lists
# ---------------------------------------------------------------------------

_SP_ELIGIBLE_EXCHANGES: tuple[str, ...] = (
    "NYSE",
    "NYSE Arca",
    "NYSE American",
    "NASDAQ Global Select",
    "NASDAQ Global Market",
    "NASDAQ Capital Market",
    "Cboe BZX",
    "Cboe BYX",
    "Cboe EDGA",
    "Cboe EDGX",
)

_NDX_ELIGIBLE_EXCHANGES: tuple[str, ...] = (
    "NASDAQ Global Select",
    "NASDAQ Global Market",
)

_FTSE_ELIGIBLE_EXCHANGES: tuple[str, ...] = ("LSE Main Market",)

_ELIGIBLE_SECURITY_TYPES: tuple[str, ...] = ("Common Stock", "REIT")

_FTSE_ELIGIBLE_CURRENCIES: tuple[str, ...] = ("GBP", "EUR", "USD")

_NDX_EXCLUDED_SECTORS: tuple[str, ...] = (
    "Financials",
    "Banks",
    "Insurance",
    "Financial Services",
)

_DJIA_EXCLUDED_SECTORS: tuple[str, ...] = ("Transportation", "Utilities")

# ---------------------------------------------------------------------------
# Shared S&P rules (everything except market-cap thresholds)
# ---------------------------------------------------------------------------

_SP_COMMON_RULES: tuple[HardRule, ...] = (
    HardRule("Investable Weight Factor", "iwf", Operator.GE, 0.10),
    HardRule(
        "Liquidity — FALR",
        "float_adj_liquidity_ratio",
        Operator.GE,
        0.75,
        "Annual dollar value traded / float-adjusted market cap",
    ),
    HardRule(
        "Liquidity — Monthly Volume",
        "min_monthly_volume_6m",
        Operator.GE,
        250_000,
        "Each of the 6 prior months must individually meet this",
    ),
    HardRule(
        "Earnings — Trailing 4Q",
        "sum_4q_gaap_earnings",
        Operator.GT,
        0,
        "GAAP net income excl. discontinued ops",
    ),
    HardRule("Earnings — Latest Quarter", "latest_quarter_earnings", Operator.GT, 0),
    HardRule("IPO Seasoning", "months_listed", Operator.GE, 12),
    HardRule("Domicile", "domicile", Operator.EQ, "US"),
    HardRule("Exchange Listing", "exchange", Operator.IN, _SP_ELIGIBLE_EXCHANGES),
    HardRule("Security Type", "security_type", Operator.IN, _ELIGIBLE_SECURITY_TYPES),
    HardRule("SEC Filing Type", "files_10K_10Q", Operator.EQ, True),
)

# ---------------------------------------------------------------------------
# S&P 500
# ---------------------------------------------------------------------------

_SP500_RULES: tuple[HardRule, ...] = (
    HardRule(
        "Market Capitalisation",
        "market_cap_usd",
        Operator.GE,
        22_700_000_000,
        "As of July 2025. Reviewed quarterly.",
    ),
    HardRule(
        "Float-Adjusted Market Cap",
        "float_market_cap_usd",
        Operator.GE,
        11_350_000_000,
        "Must be >= 50% of min market cap",
    ),
    *_SP_COMMON_RULES,
)

# ---------------------------------------------------------------------------
# S&P MidCap 400
# ---------------------------------------------------------------------------

_SP400_RULES: tuple[HardRule, ...] = (
    HardRule("Market Cap (Lower)", "market_cap_usd", Operator.GE, 8_000_000_000),
    HardRule("Market Cap (Upper)", "market_cap_usd", Operator.LE, 22_700_000_000),
    HardRule("Float-Adjusted Market Cap", "float_market_cap_usd", Operator.GE, 4_000_000_000),
    *_SP_COMMON_RULES,
)

# ---------------------------------------------------------------------------
# S&P SmallCap 600
# ---------------------------------------------------------------------------

_SP600_RULES: tuple[HardRule, ...] = (
    HardRule("Market Cap (Lower)", "market_cap_usd", Operator.GE, 1_200_000_000),
    HardRule("Market Cap (Upper)", "market_cap_usd", Operator.LE, 8_000_000_000),
    HardRule("Float-Adjusted Market Cap", "float_market_cap_usd", Operator.GE, 600_000_000),
    *_SP_COMMON_RULES,
)

# ---------------------------------------------------------------------------
# NASDAQ-100
# ---------------------------------------------------------------------------

_NDX_RULES: tuple[HardRule, ...] = (
    HardRule(
        "Exchange Listing",
        "exchange",
        Operator.IN,
        _NDX_ELIGIBLE_EXCHANGES,
        "Must be exclusively Nasdaq-listed. Capital Market NOT eligible.",
    ),
    HardRule("No Financials", "icb_sector", Operator.NOT_IN, _NDX_EXCLUDED_SECTORS),
    HardRule("IPO Seasoning", "months_listed", Operator.GE, 3),
    HardRule(
        "Avg Daily Traded Value",
        "avg_daily_traded_value_3m",
        Operator.GE,
        5_000_000,
    ),
    HardRule("Free Float", "free_float_pct", Operator.GE, 10.0),
    HardRule("Not in Bankruptcy", "in_bankruptcy", Operator.EQ, False),
    HardRule("No Pending Disqualification", "pending_disqualifying_event", Operator.EQ, False),
    HardRule("Current Filings", "sec_filings_current", Operator.EQ, True),
)

# ---------------------------------------------------------------------------
# FTSE 100
# ---------------------------------------------------------------------------

_FTSE100_RULES: tuple[HardRule, ...] = (
    HardRule("UK Nationality", "ftse_nationality", Operator.EQ, "UK"),
    HardRule("Exchange Listing", "exchange", Operator.IN, _FTSE_ELIGIBLE_EXCHANGES),
    HardRule("Trading Currency", "trading_currency", Operator.IN, _FTSE_ELIGIBLE_CURRENCIES),
    HardRule("Free Float", "free_float_pct", Operator.GE, 10.0),
    HardRule(
        "Liquidity — Turnover",
        "monthly_median_turnover_pct",
        Operator.GE,
        0.025,
        "% of free-float shares. Must pass >= 10 of 12 months.",
    ),
    HardRule("Min Trading Record", "trading_days_since_listing", Operator.GE, 20),
    HardRule("Voting Rights", "unrestricted_voting_pct", Operator.GT, 5.0),
)

# ---------------------------------------------------------------------------
# DJIA
# ---------------------------------------------------------------------------

_DJIA_RULES: tuple[HardRule, ...] = (
    HardRule(
        "S&P 500 Membership",
        "in_sp500",
        Operator.EQ,
        True,
        "Implicitly requires passing all S&P 500 hard rules.",
    ),
    HardRule("Sector Exclusion", "gics_sector", Operator.NOT_IN, _DJIA_EXCLUDED_SECTORS),
    HardRule("Domicile", "domicile", Operator.EQ, "US"),
)

# ---------------------------------------------------------------------------
# Russell 3000
# ---------------------------------------------------------------------------

_R3000_RULES: tuple[HardRule, ...] = (
    HardRule("Minimum Market Cap", "market_cap_usd", Operator.GE, 30_000_000),
    HardRule("Share Price", "share_price", Operator.GE, 1.00),
    HardRule("Free Float", "free_float_pct", Operator.GT, 5.0),
    HardRule(
        "Liquidity (ADDTV)",
        "avg_daily_dollar_volume",
        Operator.GE,
        0,
        "Relative threshold: must exceed global median ADDTV. Cannot be hardcoded.",
    ),
    HardRule("US Domicile", "domicile", Operator.EQ, "US"),
)

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

INDEX_CONFIGS: dict[IndexCode, IndexConfig] = {
    IndexCode.SP500: IndexConfig(
        code=IndexCode.SP500,
        name="S&P 500",
        hard_rules=_SP500_RULES,
        vacancy=VacancyMechanics(
            fixed_count=True,
            target_count=500,
            requires_vacancy=True,
            can_displace=False,
            default_vacancy_score=0.45,
            base_rate_fallback=0.45,
        ),
        selection_type="committee",
        ml_applicable=True,
    ),
    IndexCode.SP400: IndexConfig(
        code=IndexCode.SP400,
        name="S&P MidCap 400",
        hard_rules=_SP400_RULES,
        vacancy=VacancyMechanics(
            fixed_count=True,
            target_count=400,
            requires_vacancy=True,
            can_displace=False,
            default_vacancy_score=0.50,
            base_rate_fallback=0.50,
        ),
        selection_type="committee",
        ml_applicable=True,
    ),
    IndexCode.SP600: IndexConfig(
        code=IndexCode.SP600,
        name="S&P SmallCap 600",
        hard_rules=_SP600_RULES,
        vacancy=VacancyMechanics(
            fixed_count=True,
            target_count=600,
            requires_vacancy=True,
            can_displace=False,
            default_vacancy_score=0.55,
            base_rate_fallback=0.55,
        ),
        selection_type="committee",
        ml_applicable=True,
    ),
    IndexCode.NDX: IndexConfig(
        code=IndexCode.NDX,
        name="NASDAQ-100",
        hard_rules=_NDX_RULES,
        vacancy=VacancyMechanics(
            fixed_count=True,
            target_count=100,
            requires_vacancy=False,
            can_displace=True,
            default_vacancy_score=0.65,
            base_rate_fallback=0.65,
        ),
        selection_type="rank",
        ml_applicable=True,
    ),
    IndexCode.FTSE100: IndexConfig(
        code=IndexCode.FTSE100,
        name="FTSE 100",
        hard_rules=_FTSE100_RULES,
        vacancy=VacancyMechanics(
            fixed_count=True,
            target_count=100,
            requires_vacancy=False,
            can_displace=True,
            default_vacancy_score=0.80,
            base_rate_fallback=0.80,
        ),
        selection_type="rank",
        ml_applicable=False,
    ),
    IndexCode.DJIA: IndexConfig(
        code=IndexCode.DJIA,
        name="Dow Jones Industrial Average",
        hard_rules=_DJIA_RULES,
        vacancy=VacancyMechanics(
            fixed_count=True,
            target_count=30,
            requires_vacancy=True,
            can_displace=False,
            default_vacancy_score=0.10,
            base_rate_fallback=0.10,
        ),
        selection_type="committee",
        ml_applicable=False,
    ),
    IndexCode.R3000: IndexConfig(
        code=IndexCode.R3000,
        name="Russell 3000",
        hard_rules=_R3000_RULES,
        vacancy=VacancyMechanics(
            fixed_count=False,
            target_count=3000,
            requires_vacancy=False,
            can_displace=True,
            default_vacancy_score=0.90,
            base_rate_fallback=0.90,
        ),
        selection_type="rules",
        ml_applicable=False,
    ),
}


def get_index_config(code: IndexCode | str) -> IndexConfig:
    """Look up the configuration for an index by code."""
    if isinstance(code, str):
        code = IndexCode(code)
    return INDEX_CONFIGS[code]
