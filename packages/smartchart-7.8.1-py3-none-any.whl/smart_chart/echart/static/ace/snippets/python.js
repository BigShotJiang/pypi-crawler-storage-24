ace.define("ace/snippets/python",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText = "snippet datax\n\
	datax  任务名  参数名  --备注\n\
snippet from\n\
	from ${1:package} import ${2:module}\n\
# Module Docstring\n\
snippet docs\n\
	'''\n\
	File: ${1:FILENAME:file_name}\n\
	Author: ${2:author}\n\
	Description: ${3}\n\
	'''\n\
";
exports.scope = "python";

});
                (function() {
                    ace.require(["ace/snippets/python"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            