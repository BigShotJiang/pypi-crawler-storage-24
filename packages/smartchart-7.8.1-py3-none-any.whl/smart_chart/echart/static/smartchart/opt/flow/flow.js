async function load_flow(){
    if(typeof Core === 'undefined'){
    await ds_loadjs('/static/smartchart/opt/flow/logicflow.js',True);
    ds_loadcss('/static/smartchart/opt/flow/logicflow.css');
    await ds_loadjs('/static/smartchart/opt/flow/logicflowext.js',True);
    ds_loadcss('/static/smartchart/opt/flow/logicflowext.css');
}
}
function createFlow(eid,edit=true,ds=null){
    let container = document.getElementById(eid);
    class CustomApprovalNode extends Core.RectNode {
      getShape() {
        const { x, y, width, height } = this.props.model;
       // const style = this.props.model.getNodeStyle();
        // 从properties中获取左上角的属性文本
        const propertyText = this.props.model.properties?.assignee || '未选择';
        const h=Core.h;
        return h('g', {}, [
          // 1. 绘制节点主矩形
          h('rect', {
            x: x - width / 2,
            y: y - height / 2,
            width,
            height,
            rx: 5,
            ry: 5,
            fill: '#ffffff',
            stroke: '#409EFF',
            strokeWidth: 1
          }),
          // 3. 左上角属性文本
          h('text', {
            x: x - width / 2 + 15,
            y: y - height / 2 + 16,
            fill: '#67C23A',
            'text-anchor': 'middle',
            'font-weight': 'bold',
            style: {
              fontSize: '10px',
              userSelect: 'none'
            }
          }, propertyText),
        ]);
      }
    }
    class RejectEdgeModel extends Core.PolylineEdgeModel {
      initEdgeData(data) {
        super.initEdgeData(data);
        this.type = 'reject-edge';
      }
      getEdgeStyle() {
        const style = super.getEdgeStyle();
        return { ...style,
                stroke: '#F56A7B', // 驳回色：红色
                strokeWidth: 2,
                strokeDasharray: '4 2', // 虚线：4px实线+2px空白
                lineAppendWidth: 5, // 增加点击选中区域
                arrow: { fill: '#F56A7B', stroke: '#F56A7B' } // 红色箭头
             };
      }
    }
    // 注册自定义节点
    const StartNode = {type: 'start', view: Core.CircleNode, model: Core.CircleNodeModel};
    const ApprovalNode = {type: 'approval', view:CustomApprovalNode, model: Core.RectNodeModel};
    const RobotNode = {type: 'robot', view: Core.PolygonNode, model: Core.PolygonNodeModel};
    const EndNode = {type: 'end', view: Core.CircleNode, model: Core.CircleNodeModel};
    const RejectEdge = { type: 'reject-edge', view: Core.PolylineEdge, model: RejectEdgeModel };

    const Icons = {
    start: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTAiIGN5PSIxMCIgcj0iOSIgc3Ryb2tlPSIjNjdDMjNBIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9IndoaXRlIi8+Cjwvc3ZnPg==',
    approval: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjE4IiBoZWlnaHQ9IjE4IiB4PSIxIiB5PSIxIiByeD0iNiIgc3Ryb2tlPSIjNDA5RUVGIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9IndoaXRlIi8+Cjwvc3ZnPg==',
    end: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTAiIGN5PSIxMCIgcj0iOSIgc3Ryb2tlPSIjRjU2QTdCIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9IndoaXRlIi8+Cjwvc3ZnPg==',
    robot: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBvbHlnb24gcG9pbnRzPSI1LDQgMTUsNCAxOCw4IDE4LDE1IDE1LDE4IDUsMTggMiwxNSAyLDgiIHN0cm9rZT0iIzkwOTM5OSIgc3Ryb2tlLXdpZHRoPSIyIiBmaWxsPSJ3aGl0ZSIvPgo8Y2lyY2xlIGN4PSI3IiBjeT0iMTEiIHI9IjEiIGZpbGw9IiM5MDkzOTkiLz4KPGNpcmNsZSBjeD0iMTMiIGN5PSIxMSIgcj0iMSIgZmlsbD0iIzkwOTM5OSIvPgo8cmVjdCB4PSI4IiB5PSI1IiB3aWR0aD0iNCIgaGVpZ2h0PSIyIiByeD0iMSIgZmlsbD0iIzkwOTM5OSIvPgo8L3N2Zz4='
    };
    const Patterns = [
        {
            type: 'start',
            text: '开始',
            label: '开始',
            icon: Icons.start,
            properties:{r: 25,style:{stroke:'#2eb824'}},
        },
        {
            type: 'approval',
            text: '审批',
            label: '审批',
            icon: Icons.approval,
            className: 'import_icon',
        },
        {
            type: 'robot',
            text: '机器人',
            label: '机器人',
            icon: Icons.robot,
        },
        {
            type: 'end',
            text: '结束',
            label: '结束',
            icon: Icons.end,
            properties:{r: 25,style:{stroke:'#cd386b'}}
        },
    ];
    const LFThemes = {
        circle: {
            strokeWidth: 2,
        },
        rect: {
            stroke: '#409EFF',
            strokeWidth: 2
        },
        polygon: {
            stroke: '#909399',
            strokeWidth: 2
        },
        polyline: {
            stroke: '#409EFF',
            strokeWidth: 2,
        },
        nodeText: {
            color: '#303133',
            fontSize: 14
        },
        edgeText: {
            color: '#409EFF',
            fontSize: 12,
            background: {
                fill: '#fff'
            }
        },
    };

    let lf;
    if(edit){
        Core.LogicFlow.use(Extension.Control);
        Core.LogicFlow.use(Extension.Menu);
        Core.LogicFlow.use(Extension.DndPanel);
        lf = new Core.LogicFlow({
            container,
            grid: true,
            isSilentMode: false,
            stopScrollGraph: true,
            stopZoomGraph: true,
            width: container.clientWidth,
            height: container.clientHeight,
            edgeTextDraggable: true,
            nodeTextDraggable: true,
            metaKeyMultipleSelected: true,
            allowResize: true,
            allowRotate: true,
            keyboard: {
                enabled: true,
            },

        });
        // 设置菜单
        lf.addMenuConfig({
            edgeMenu: [
                {
                    text: '设为驳回连线',
                    callback(edge) {
                        lf.changeEdgeType(edge.id, "reject-edge");
                    },
                },
                {
                    text: '设为通过连线',
                    callback(edge) {
                        lf.changeEdgeType(edge.id, "polyline");
                    },
                },
                {
                    text: '设为曲线',
                    callback(edge) {
                        lf.changeEdgeType(edge.id, "bezier");
                    },
                },
            ]
        });

        // 设置面板元素
        lf.setPatternItems(Patterns);

    }else{
         lf = new Core.LogicFlow({
            container,
            grid: false,
            isSilentMode: true,  // 只读模式
            stopScrollGraph: false,
            stopZoomGraph: false,
            width: container.clientWidth,
            height: container.clientHeight,
            metaKeyMultipleSelected: false
          });
    }
        lf.register(StartNode);
        lf.register(ApprovalNode);
        lf.register(RobotNode);
        lf.register(EndNode);
        lf.register(RejectEdge);
        // 设置样式
        lf.setTheme(LFThemes,'radius');
        if(ds){lf.render(getDefinition(ds));}
        return lf
}

// 获取指定流程定义
function getDefinition(ds){
      if(ds.length<2){return}
      let definition = ds_createMap_all(ds)[0];
      let flow = JSON.parse(definition.flow)||{nodes:[],edges:[]};
      delete definition.flow;
      definition.nodes = flow.nodes;
      definition.edges = flow.edges;
      return definition;
}

// 处理审批节点
function handleApproveNode(task, definition, ds_insid, ds_taskid) {
  // 保存任务状态（如果任务有id）
  if(task.id){
    ds_save(ds_taskid, {status: task.status, comment: task.comment, id: task.id}, 1);
  }
  let t_instance = {uuid: task.instanceId};

  // 获取当前节点的所有出边
  const outgoingEdges = definition.edges.filter(e => e.sourceNodeId === task.nodeId && (task.status === "已驳回" ? e.type === "reject-edge" : e.type !== "reject-edge"));
  // 没有出边，流程直接结束
  if (outgoingEdges.length === 0) {
    t_instance.status = task.status;
    t_instance.currentNodeId = '';
    return ds_save(ds_insid, t_instance, 1);
  }
  // 根据条件选择正确的边
  let selectedEdges = [];
  for (const edge of outgoingEdges) {
    if (evaluateCondition(edge.properties?.condition, task.variables)) {
      selectedEdges.push(edge);
    }
  }

  // 为每条符合条件的出边创建任务
  for (const edge of selectedEdges) {
    const targetNode = definition.nodes.find(n => n.id === edge.targetNodeId);
    if (targetNode) {
      // 如果是开始节点，不检查上游任务
      const isStartNode = task.nodeId === definition.nodes.find(n => n.type === 'start')?.id;
      const canProceed = isStartNode||task.status === "已驳回" ? true : checkAllUpstreamTasksCompleted(definition, targetNode.id, task.instanceId,task.nodeId);

      if (canProceed) {
        if(targetNode.type === 'end'){
          t_instance.status = '已批准';
          t_instance.currentNodeId = '';
        } else {
          // 创建新任务
          const newTask = {
            uuid: ds_generateUUID(),
            instanceId: task.instanceId,
            nodeId: targetNode.id,
            nodeName: targetNode.properties?.name||targetNode.type,
            assignee: targetNode.properties?.assignee||task.applicant,
            instructions: targetNode.properties?.instructions,
            status: "进行中",
          };

          if(targetNode.type === 'robot'){
            newTask.status = '已批准';
            if(targetNode.properties?.name) {
                ds_save(7, newTask);
            }
            handleApproveNode(newTask, definition, ds_insid, ds_taskid);
          } else {t_instance.currentNodeId = targetNode.id;}
          ds_save(ds_taskid, newTask);
        }
      } else {
        console.log(`节点 ${targetNode.id} 的上游节点尚未全部完成，等待中...`);
      }
    }
  }
  return ds_save(ds_insid, t_instance, 1);
}

// 检查目标节点的所有上游任务是否都已完成
function checkAllUpstreamTasksCompleted(definition, targetNodeId, instanceId,nodeId) {
  // 获取目标节点的所有上游节点
  const upstreamNodeIds = getUpstreamNodeIds(definition, targetNodeId,nodeId);
  if (upstreamNodeIds.length ===0) return true;

  // 从数据库查询这些节点的任务状态
  const tasks = ds_refresh(5,{instanceId:instanceId},r='map');
  if (!tasks || tasks.length === 0) return false;

  // 检查每个上游节点是否都有已批准的任务
  for (const upstreamNodeId of upstreamNodeIds) {
    const upstreamTask = tasks.find(t => t.nodeId === upstreamNodeId);
    if (!upstreamTask || upstreamTask.status !== "已批准") {
      return false;
    }
  }
  return true;
}

// 获取节点的所有上游节点ID
function getUpstreamNodeIds(definition, currentNodeId,nodeId) {
  const upstreamNodeIds = [];
    // 查找指向当前节点的边
    const incomingEdges = definition.edges.filter(edge => edge.type!=="reject-edge"&&edge.targetNodeId === currentNodeId);
    for (const edge of incomingEdges) {
        if(edge.sourceNodeId!==nodeId){
            upstreamNodeIds.push(edge.sourceNodeId);
        }
    }
  return upstreamNodeIds;
}

// 评估条件表达式
function evaluateCondition(condition, variables) {
  if (!condition || !variables) return true; // 没有条件默认通过
  try {
    let v = JSON.parse(variables);
    return eval(condition)
  } catch (e) {
    console.error("条件解析错误:", e);
    return true; // 解析错误默认通过
  }
}

function startInstance(definition, config, ds_insid, ds_taskid) {
  const newId = ds_generateUUID();
  const newInstance = {
    uuid: newId,
    status: "进行中",
    definitionId: definition.uuid,
    currentNodeId: "",
    ...config
  };

  //保存实例
  let res = ds_save(ds_insid, newInstance);
  if(res.status !== 200){
    console.error(res.msg)
    return false
  }

  // 查找开始节点
  const startNode = definition.nodes.find(n => n.type === "start");
  if (!startNode) {
    console.error("未找到开始节点");
    return false;
  }

  // 使用统一的处理函数处理开始节点
  const startTask = {
    uuid: ds_generateUUID(),
    instanceId: newId,
    nodeId: startNode.id,
    nodeName: "开始",
    status: "已批准", // 开始节点自动批准
    instanceTitle: newInstance.title
  };

  // 处理开始节点，这会触发后续的并行处理
  handleApproveNode(startTask, definition, ds_insid, ds_taskid);
  return newInstance
}

//审批页面
async function init_approve(eid='vue_app',dsids={}){
    await load_flow();
    ds_loadcss('/static/smartchart/opt/flow/flow.css');
    await loadVue();
    const flowhtml=`<div class="flow_body">
<div class="header">
  <div class="header-title">流程审批</div>
</div>
<div class="tabs">
  <div class="tab" :class="{active: currentTab === 'flow'}" @click="switchTab('flow')">
    <i class="el-icon-tickets"></i> 流程发起
  </div>
  <div class="tab" :class="{active: currentTab === 'instances'}" @click="switchTab('instances')">
    <i class="el-icon-tickets"></i> 我的流程
  </div>
    <div class="tab" :class="{active: currentTab === 'oldtasks'}" @click="switchTab('oldtasks')">
    <i class="el-icon-finished"></i> 已完成任务
  </div>
  <div class="tab" :class="{active: currentTab === 'tasks'}" @click="switchTab('tasks')">
    <i class="el-icon-finished"></i> 审批任务
  </div>
</div>

<div class="app-container">
  <div class="panel-left">
    <div class="panel-content">
          <!-- 流程实例面板 -->
      <template v-if="currentTab === 'flow'">
        <div class="section">
          <div class="list-item" 
               v-for="def in definitions" 
               :key="def.uuid" 
               :class="{active: selectedDef === def.uuid}"
               @click="selectDefinition(def)">
            <div class="instance-header">
              <div class="instance-title">{[ def.name ]}</div>
              <span class="status-tag DRAFT">{[def.category]}</span>
            </div>
            <div class="instance-meta">
              <div class="meta-item">
                <i class="el-icon-document"></i>
                <span>{[def.description]}</span>
              </div>
            </div>
          </div>
        </div>
        <div v-if="selectedDef" class="form-container">
          <div class="section-title">
            <i class="el-icon-circle-plus"></i> 启动新流程
          </div>
          <el-form label-position="top">
            <el-form-item label="流程名称" required>
              <el-input 
                v-model="newInstance.title" 
                placeholder="输入流程名称"
                size="small"
              ></el-input>
            </el-form-item>
            
            <el-form-item label="关联表单">
              <el-input 
                v-model="newInstance.formId" 
                placeholder="填写关联表单"
                size="small"
                style="width: 100%;"
              >
              </el-input>
            </el-form-item>
            
            <el-form-item label="备注">
              <el-input 
                type="textarea" 
                v-model="newInstance.remark" 
                placeholder="添加流程说明或备注"
                rows="2"
                size="small"
              ></el-input>
            </el-form-item>
            
            <el-button 
              type="primary" 
              style="width: 100%;" 
              :disabled="!newInstance.title"
              @click="startNewInstance"
              size="small"
            >
              启动流程
            </el-button>
          </el-form>
        </div>
      </template>
      <!-- 流程实例面板 -->
      <template v-if="currentTab === 'instances'">
        <div class="section">
          <div class="section-title">
            <i class="el-icon-timer"></i>最近的流程
            <span><el-input size="small" v-model="fvalue" placeholder="关键字查询" @input="filter_data"></el-input></span>
          </div>
          <div v-if="instances.length === 0" class="no-data">
            <i class="el-icon-document"></i>
            <div>暂无流程实例</div>
          </div> 
          <div class="list-item" v-for="instance in instances2" :key="instance.uuid" @click="viewInstance(instance)">
            <div class="instance-header">
              <div class="instance-title">{[ instance.title ]}</div>
                  <el-tag :type="getStatusTagType(instance.status)" size="small" effect="light">{[ instance.status ]}</el-tag>
            </div>
            <div class="instance-meta">
              <div class="meta-item">
                <i class="el-icon-user"></i>
                <span>{[ instance.updater ]}</span>
              </div>   
              <div class="meta-item">
                <i class="el-icon-time"></i>
                <span>{[ formatTime(instance.update_time) ]}</span>
              </div>
            </div>
          </div>
        </div>
      </template>
      <!-- 已完成的任务 -->
      <template v-else-if="currentTab === 'oldtasks'">
      <div class="section">
          <div class="section-title">
            <i class="el-icon-timer"></i> 最近完成的任务
            <span><el-input size="small" v-model="fvalue" placeholder="关键字查询" @input="filter_data"></el-input></span>
          </div>
          <div v-if="oldtasks.length === 0" class="no-data">
            <i class="el-icon-document"></i>
            <div>暂无任务实例</div>
          </div> 
          <div class="list-item" v-for="task in oldtasks2" :key="task.uuid" @click="loadTaskDetail(task)">
            <div class="instance-header">
              <div class="instance-title">{[task.instanceTitle]}{[task.nodeName]}</div>
                  <el-tag :type="getStatusTagType(task.status)" size="small" effect="light">{[task.status]}</el-tag>
            </div>
            
            <div class="instance-meta">
              <div class="meta-item">
                <i class="el-icon-user-solid"></i>
                <span>{[ task.applicant ]}</span>
              </div>
              <div class="meta-item">
                <i class="el-icon-user"></i>
                <span>{[ task.updater ]}</span>
              </div>  
              <div class="meta-item">
                <i class="el-icon-time"></i>
                <span>{[ formatTime(task.update_time) ]}</span>
              </div>
            </div>
          </div>
        </div>
      </template>
      <!-- 审批任务面板 -->
      <template v-else-if="currentTab === 'tasks'">
        <div class="section">
          <div class="section-title">
            <i class="el-icon-notebook-2"></i>待办任务
            <span><el-input size="small" v-model="fvalue" placeholder="关键字查询" @input="filter_data"></el-input></span>
          </div>
          <div v-if="tasks.length === 0" class="no-data">
            <i class="el-icon-finished"></i>
            <div>暂无待办任务</div>
          </div>
          
          <div class="task-item" v-for="task in tasks2" :key="task.uuid" :class="{active: activeTask === task.uuid}"
               @click="loadTaskDetail(task)">
            <div class="task-header">
              <div class="task-title">{[task.instanceTitle]}{[task.nodeName]}</div>
              <span class="priority-tag" :class="'priority-'+task.priority">
                {[task.priority==='high'?'紧急':'普通']}
              </span>
            </div>
            <div class="task-meta">
              <div class="meta-item">
                <i class="el-icon-user-solid"></i>
                <span>{[ task.applicant ]}</span>
              </div> 
              <div class="meta-item">
                <i class="el-icon-user"></i>
                <span>{[ task.updater ]}</span>
              </div>              
              <div class="meta-item">
                <i class="el-icon-warning-outline"></i>
                <span>{[ task.instructions ]}</span>
              </div>              
              <div class="meta-item">
                <i class="el-icon-time"></i>
                <span>{[ formatTime(task.update_time) ]}</span>
              </div>
            </div>
            <el-button type="success" size="small" @click.stop="approveTask(task)">
                <i class="el-icon-check"></i> 批准
              </el-button>
              <el-button type="danger" size="small" @click.stop="rejectTask(task)">
                <i class="el-icon-close"></i> 驳回
              </el-button>
              <el-button type="info" size="small" @click.stop="delegateTask(task)">
                <i class="el-icon-more"></i> 转办
              </el-button>
          </div>
        </div>
      </template>
    </div>
  </div>
</div>

 <el-dialog title="任务转办" :visible.sync="delegateDialog.visible" width="400px" center>
  <div style="text-align: center;">
    <p style="margin-bottom: 20px; color: #606266;">请选择转办人员</p>
    <el-select v-model="delegateDialog.selectedUser" placeholder="请选择" style="width: 100%;" clearable filterable>
      <el-option v-for="user in users" :key="user.id" :label="user.name" :value="user.id"></el-option>
    </el-select>
    <el-input v-model="delegateDialog.comment" placeholder="备注"></el-input>
  </div>
  <span slot="footer" class="dialog-footer">
    <el-button @click="delegateDialog.visible = false">取消</el-button>
    <el-button type="primary" @click="confirmDelegate">确定</el-button>
  </span>
</el-dialog>
<!-- 抽屉式流程图容器 -->
<div class="overlay" :class="{active: drawerOpen}" @click="toggleDrawer"></div>
<div class="drawer-container" :class="{open: drawerOpen}">
  <div class="drawer-header">
    <div class="drawer-title">流程审批详情</div>
    <button class="drawer-close" @click="toggleDrawer">
      <i class="el-icon-close"></i>
    </button>
  </div>
  
  <div class="drawer-content">
    <div class="drawer-viewer">
      <div style="height:40%">
        <div id="instance-viewer" style="height:100%;width:100%;"></div>
      </div>
      <div class="section">
        <div>
          {[activeInstance.remark]} {[activeInstance.formId]}
        </div>
        
        <div class="approval-timeline" v-if="taskList.length > 0">
          <div class="timeline-header">
            <div class="header-item" style="flex: 2.5">审批节点</div>
            <div class="header-item" style="flex: 2">审批人</div>
            <div class="header-item" style="flex: 2">状态</div>
            <div class="header-item" style="flex: 3.5">审批意见</div>
            <div class="header-item" style="flex: 2">操作时间</div>
          </div>
          
          <div class="timeline-content">
            <el-timeline>
              <el-timeline-item
                v-for="(task, index) in taskList"
                :key="index"
                :timestamp="task.update_time"
                placement="top"
                :color="getStatusColor(task.status)"
              >
                <div class="timeline-card">
                  <div class="timeline-node">{[task.nodeName]}</div>
                  <div class="timeline-user">
                    <i class="el-icon-user"></i>
                    <span>{[task.assignee]}</span>
                  </div>
                  <div class="timeline-status">
                    <el-tag 
                      :type="getStatusTagType(task.status)" 
                      size="small" 
                      effect="light"
                    >
                      {[task.status]}
                    </el-tag>
                  </div>
                  <div class="timeline-comment">
                    <i class="el-icon-chat-dot-round"></i>
                    {[task.comment || '暂无意见']}
                  </div>
                  <div class="timeline-time">
                    <i class="el-icon-time"></i>
                    {[formatTime(task.update_time)]}
                  </div>
                </div>
              </el-timeline-item>
            </el-timeline>
          </div>
        </div>
        
        <div class="no-records" v-else>
          <i class="el-icon-document-delete"></i>
          <p>暂无审批记录</p>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>`;
    document.getElementById(eid).innerHTML=flowhtml;
    return new Vue({
   el: '#'+eid,
   delimiters: ['{[', ']}'],
   data: {
    currentTab: "tasks", // 默认显示审批任务
    selectedDef: null,
    activeInstance: {}, //选中的实例
    activeTask: null,
    drawerOpen: false, // 控制抽屉显示状态

    ds_insid:dsids.ds_insid||0, //写入流程实例
    ds_taskid:dsids.ds_taskid||1, //写入任务实例
    ds_proclistid:dsids.ds_proclistid||2, //初始化流程定义和流程实例
    ds_tasksid:dsids.ds_tasksid||3, //任务清单和人员清单
    ds_deflistid:dsids.ds_deflistid||4, //按uuid查询流程详情
    users: null,
    definitions: [],
    instances: [],
    instances2: [],
    tasks: [],
    tasks2: [],
    oldtasks: [],
    oldtasks2: [],
    lfViewer: null,  // 只读查看器
    newInstance: {
        title: "",
        applicant: filter_param.username,
        formId: null,
        remark: ""
  },

    taskDetail: {},
    taskList:[],

    delegateDialog: {
      visible: false,
      selectedUser: '',
      task: null,
      comment:''
    },
    fvalue:'',
  },
  mounted() {
    this.get_tasks();
  },
  methods: {
      // 时间格式化方法
     formatTime(timeStr) {
        if (!timeStr) return "";
        const time = new Date(timeStr);
        const now = new Date();
        const diff = Math.floor((now - time) / 1000);

        if (diff < 60) return "刚刚";
        if (diff < 3600) return `${Math.floor(diff/60)}分钟前`;
        if (diff < 86400) return `${Math.floor(diff/3600)}小时前`;

        return time.toLocaleDateString();
      },

  // 获取状态颜色
  getStatusColor(status) {
    switch(status) {
      case '已批准': return '#67c23a';
      case '已驳回': return '#f56c6c';
      case '进行中': return '#409eff';
      default: return '#909399';
    }
  },

  // 获取状态标签类型
  getStatusTagType(status) {
    switch(status) {
      case '已批准': return 'success';
      case '已驳回': return 'danger';
      case '进行中': return 'primary';
      default: return 'info';
    }
  },
    // 获取指定流程定义
    get_definition(uuid){
        let ds = ds_refresh(this.ds_deflistid,{uuid:uuid},'list');
        return getDefinition(ds);
    },

    // 流程管理
    get_processes() {
      let dataset = ds_refresh(this.ds_proclistid,null,'list');
      this.instances = ds_createMap_all(dataset.df1);
      this.instances2 = this.instances;
      this.definitions = ds_createMap_all(dataset.df0);
    },

    // 获取流程实例和任务
    get_tasks(t=null) {
      if(t){this.oldtasks = ds_refresh(this.ds_tasksid, {t:'!'},'map');this.oldtasks2=this.oldtasks;}
      else{this.tasks = ds_refresh(this.ds_tasksid,null,'map');this.tasks2=this.tasks}
    },

    // 选项卡切换
    switchTab(tab) {
      this.currentTab = tab;
      if (tab === 'tasks') {
        this.get_tasks();
      }else if(tab === 'oldtasks'){
          this.get_tasks(1)
      }
      else{this.get_processes()}
      this.fvalue = '';
    },
      //过滤
    filter_data(){
         if(this.currentTab==='instances'){
             this.instances2 = this.instances.filter(item=>{
                 for(k in item){if(String(item[k]).includes(this.fvalue)){return True}}return False;
             })
         }else if(this.currentTab==='tasks'){
           this.tasks2 = this.tasks.filter(item=>{
                 for(k in item){if(String(item[k]).includes(this.fvalue)){return True}}return False;
             })
         }else if(this.currentTab==='oldtasks'){
           this.oldtasks2= this.oldtasks.filter(item=>{
                 for(k in item){if(String(item[k]).includes(this.fvalue)){return True}}return False;
             })
         }
      },

    // 选择流程定义
    selectDefinition(definition) {
      this.selectedDef = definition.uuid;
      this.newInstance.title = `[${filter_param.username}][${definition.name}]`;
    },

    // 启动新流程实例
    startNewInstance() {
      if (!this.selectedDef) {
        this.$message.warning("请先选择流程");
        return;
      }

      let definition = this.get_definition(this.selectedDef);
      let newInstance = startInstance(definition, {
        title: this.newInstance.title,
        applicant: this.newInstance.applicant,
        remark:this.newInstance.remark,
        formId:this.newInstance.formId
      }, this.ds_insid,this.ds_taskid);

      if (newInstance) {
        this.$message.success(`流程 [${newInstance.title}] 已启动！`);
        this.newInstance.title = "";
      }
    },

    // 查看流程实例
    viewInstance(instance) {
      this.activeInstance = instance;
      this.renderInstanceFlow(instance);
      this.taskList=ds_refresh(5,{instanceId:instance.uuid},r='map');
      this.drawerOpen = true; // 显示抽屉
    },

    // 渲染流程实例图
    renderInstanceFlow(instance) {
         if(!this.lfViewer){
             this.lfViewer = createFlow('instance-viewer', false);
         }
        const definition = this.get_definition(instance.definitionId);
        this.lfViewer.render(definition);
        this.lfViewer.fitView(20);
        // 高亮当前节点
        if (instance.currentNodeId) {
          this.lfViewer.selectElementById(instance.currentNodeId);
        }
    },

    // 加载任务详情
    loadTaskDetail(task) {
      this.activeTask = task;
      const instance = {
          uuid:task.instanceId,
          definitionId:task.definitionId,
          currentNodeId:task.nodeId,
          remark:task.remark,
      }
      this.viewInstance(instance);
    },

    // 切换抽屉显示状态
    toggleDrawer() {
      this.drawerOpen = !this.drawerOpen;
    },

    // 批准任务
    approveTask(task) {
        this.updateTaskStatus(task, "已批准");
    },

    // 拒绝任务
    rejectTask(task) {
      this.updateTaskStatus(task, "已驳回");
    },

      // 转办确认方法
    confirmDelegate() {
      if (!this.delegateDialog.selectedUser) {
        this.$message.warning('请选择转办人员');
        return;
      }

      const task = this.delegateDialog.task;
      const assignee = this.delegateDialog.selectedUser;
      const comment = this.delegateDialog.comment;

      // 执行转办
      ds_save(this.ds_taskid, {id: task.id, comment:comment, status: '已转办'}, 1);

      let newTask = {
        uuid: ds_generateUUID(),
        instanceId: task.instanceId,
        nodeId: task.nodeId,
        nodeName: task.nodeName,
        assignee: assignee,
        instructions: task.instructions,
        status: task.status,
        instanceTitle: task.instanceTitle
      };

      ds_save(this.ds_taskid, newTask);

      this.$message({
        type: 'success',
        message: `已成功转办给 ${assignee}`
      });

      // 关闭对话框
      this.delegateDialog.visible = false;
      this.delegateDialog.selectedUser = '';

      this.get_tasks();
    },
    delegateTask(task) {
      if(!this.users){
         this.users = ds_refresh(6,null,'map');
      }
      this.delegateDialog = {
        visible: true,
        selectedUser: '',
        task: task,
        comment:''
      };
    },

    // 更新任务状态
    updateTaskStatus(task, status) {
      this.$prompt('审批意见', '审批', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
        }).then(({ value }) => {
              task.comment = value;
              task.status = status;
              const definition = this.get_definition(task.definitionId);
              // 执行审批逻辑
              const success = handleApproveNode(task, definition, this.ds_insid,this.ds_taskid);
              if (success.status==200) {
                this.$message.success(`任务 [${task.nodeName}]`+ status);
                // 刷新数据
                this.activeTask = null;
                this.taskDetail = {};
                this.get_tasks();
              }
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消提交'
          });
        });
    },

  }
});
}