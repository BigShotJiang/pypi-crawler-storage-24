from importlib.metadata import PackageNotFoundError, version as pkg_version


def _detect_version() -> str:
    for dist_name in ("pty-mcp", "pty_mcp"):
        try:
            return pkg_version(dist_name)
        except PackageNotFoundError:
            continue
        except Exception:
            break
    return "unknown"


__version__ = _detect_version()

__all__ = ["__version__"]
