"""Knowledge Graph components."""
