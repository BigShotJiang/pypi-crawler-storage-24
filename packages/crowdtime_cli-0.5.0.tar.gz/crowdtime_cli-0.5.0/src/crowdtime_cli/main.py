"""CrowdTime CLI - Main entry point.

Registers all command groups, handles magic default routing,
and provides short aliases for common commands.
"""

from __future__ import annotations

import sys
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional

import typer
from rich.console import Console

from . import __version__
from .client import APIError, CrowdTimeClient
from .formatters import format_error, format_status, format_timer, print_json
from .models import TimeEntry, User

from .commands import (
    ai_cmd,
    auth_cmd,
    billing_cmd,
    clients_cmd,
    config_cmd,
    expense_cmd,
    favorites_cmd,
    invoice_cmd,
    log_cmd,
    org_cmd,
    projects_cmd,
    report_cmd,
    skill_cmd,
    tasks_cmd,
    timesheet_cmd,
    timer_cmd,
)

console = Console()

app = typer.Typer(
    name="crowdtime",
    help="CrowdTime - AI-powered time tracking from the command line.",
    rich_markup_mode="rich",
    no_args_is_help=False,
    invoke_without_command=True,
)

# Register command groups
app.add_typer(auth_cmd.app, name="auth")
app.add_typer(billing_cmd.app, name="billing")
app.add_typer(timer_cmd.app, name="timer")
app.add_typer(log_cmd.app, name="log")
app.add_typer(projects_cmd.app, name="projects")
app.add_typer(clients_cmd.app, name="clients")
app.add_typer(tasks_cmd.app, name="tasks")
app.add_typer(report_cmd.app, name="report")
app.add_typer(ai_cmd.app, name="ai")
app.add_typer(org_cmd.app, name="org")
app.add_typer(config_cmd.app, name="config")
app.add_typer(favorites_cmd.app, name="favorites")
app.add_typer(skill_cmd.app, name="skill")
app.add_typer(timesheet_cmd.app, name="timesheet")
app.add_typer(invoice_cmd.app, name="invoice")
app.add_typer(expense_cmd.app, name="expense")


# ─── Status command (default when no subcommand given) ──────────────────────


def _show_status(output_json: bool = False) -> None:
    """Show the full status dashboard."""
    try:
        client = CrowdTimeClient(require_auth=True, require_org=True)
    except SystemExit:
        return

    # Fetch user info
    try:
        user_data = client.get("/api/v1/auth/me/", org_scoped=False)
        user = User(**user_data)
        user_name = user.display_name
    except (APIError, SystemExit):
        user_name = "Unknown"

    org_name = client.org_slug or "No org"

    # Fetch running timer
    running_entry: TimeEntry | None = None
    try:
        running_data = client.get("/time/running/")
        running_entry = TimeEntry(**running_data)
    except APIError:
        pass

    # Fetch today's entries
    today = date.today()
    today_entries: list[TimeEntry] = []
    try:
        today_data = client.get("/time/daily/{}/".format(today.isoformat()))
        if isinstance(today_data, list):
            today_list = today_data
        elif isinstance(today_data, dict):
            today_list = today_data.get("entries", today_data.get("results", []))
        else:
            today_list = []
        today_entries = [TimeEntry(**item) for item in today_list]
    except APIError:
        pass

    # Fetch this week's entries
    week_entries: list[TimeEntry] | None = None
    try:
        monday = today - timedelta(days=today.weekday())
        week_data = client.get("/time/weekly/{}/".format(monday.isoformat()))
        if isinstance(week_data, list):
            week_list = week_data
        elif isinstance(week_data, dict):
            week_list = week_data.get("entries", week_data.get("results", []))
        else:
            week_list = []
        week_entries = [TimeEntry(**item) for item in week_list]
    except APIError:
        pass

    if output_json:
        print_json({
            "user": user_name,
            "organization": org_name,
            "running_timer": running_entry.model_dump(mode="json") if running_entry else None,
            "today_entries": [e.model_dump(mode="json") for e in today_entries],
            "today_total": str(sum((e.duration or Decimal("0")) for e in today_entries if not e.is_running)),
        })
        return

    format_status(
        user_name=user_name,
        org_name=org_name,
        running_entry=running_entry,
        today_entries=today_entries,
        daily_target=client.config.daily_target,
        week_entries=week_entries,
    )


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-v", help="Show version."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """CrowdTime - AI-powered time tracking from the command line."""
    if version:
        console.print(f"crowdtime-cli {__version__}")
        raise typer.Exit()

    if ctx.invoked_subcommand is None:
        _show_status(output_json=output_json)


# ─── Short alias commands ───────────────────────────────────────────────────


@app.command("status", hidden=False)
def status_cmd(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show current status dashboard."""
    _show_status(output_json=output_json)


@app.command("s", hidden=True)
def status_alias(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Alias for 'status'."""
    _show_status(output_json=output_json)


@app.command("t", hidden=True)
def timer_status_alias(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Alias for 'timer status'."""
    timer_cmd.status(output_json=output_json)


@app.command("ts", hidden=True)
def timer_start_alias(
    description: str = typer.Argument("", help="What are you working on?"),
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    task: Optional[str] = typer.Option(None, "--task", "-t"),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B"),
    output_json: bool = typer.Option(False, "--json"),
) -> None:
    """Alias for 'timer start'."""
    timer_cmd.start(
        description=description, project=project, task=task,
        billable=billable, output_json=output_json,
    )


@app.command("tx", hidden=True)
def timer_stop_alias(
    note: Optional[str] = typer.Option(None, "--note", "-n"),
    output_json: bool = typer.Option(False, "--json"),
) -> None:
    """Alias for 'timer stop'."""
    timer_cmd.stop(note=note, output_json=output_json)


@app.command("l", hidden=True)
def log_alias(
    duration: str = typer.Argument(..., help="Duration (e.g. 2h, 2h30m, 2:30)."),
    description: Optional[str] = typer.Argument(None),
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    task: Optional[str] = typer.Option(None, "--task", "-t"),
    date: Optional[str] = typer.Option(None, "--date", "-d"),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B"),
    output_json: bool = typer.Option(False, "--json"),
) -> None:
    """Alias for 'log create'."""
    log_cmd.create(
        duration=duration, description=description, project=project,
        task=task, date=date, billable=billable, output_json=output_json,
    )


@app.command("ll", hidden=True)
def log_list_alias(
    date: Optional[str] = typer.Option(None, "--date", "-d"),
    week: bool = typer.Option(False, "--week", "-w"),
    month: bool = typer.Option(False, "--month", "-m"),
    from_date: Optional[str] = typer.Option(None, "--from"),
    to_date: Optional[str] = typer.Option(None, "--to"),
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    format_output: str = typer.Option("table", "--format"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Alias for 'log list'."""
    log_cmd.list_entries(
        date=date, week=week, month=month,
        from_date=from_date, to_date=to_date, project=project,
        format_output=format_output, output_json=output_json,
    )


@app.command("r", hidden=True)
def report_alias(
    ctx: typer.Context,
    today_flag: bool = typer.Option(False, "--today"),
    yesterday_flag: bool = typer.Option(False, "--yesterday"),
    week: bool = typer.Option(False, "--week", "-w"),
    last_week: bool = typer.Option(False, "--last-week"),
    month: bool = typer.Option(False, "--month", "-m"),
    from_date: Optional[str] = typer.Option(None, "--from"),
    to_date: Optional[str] = typer.Option(None, "--to"),
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    group_by: str = typer.Option("project", "--group-by", "-g"),
    format_output: str = typer.Option("table", "--format", "-f"),
) -> None:
    """Alias for 'report'."""
    report_cmd.report(
        ctx=ctx,
        today_flag=today_flag, yesterday_flag=yesterday_flag, week=week,
        last_week=last_week, month=month, from_date=from_date, to_date=to_date,
        project=project, group_by=group_by, format_output=format_output,
    )


@app.command("p", hidden=True)
def projects_list_alias(
    archived: bool = typer.Option(False, "--archived", "-a"),
    output_json: bool = typer.Option(False, "--json"),
) -> None:
    """Alias for 'projects list'."""
    projects_cmd.list_projects(archived=archived, output_json=output_json)


@app.command("b", hidden=True)
def billing_alias(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Alias for 'billing status'."""
    billing_cmd.status(output_json=output_json)


@app.command("ex", hidden=True)
def expense_list_alias(
    from_date: Optional[str] = typer.Option(None, "--from"),
    to_date: Optional[str] = typer.Option(None, "--to"),
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    category: Optional[str] = typer.Option(None, "--category", "-c"),
    billable: Optional[bool] = typer.Option(None, "--billable/--non-billable"),
    invoiced: Optional[bool] = typer.Option(None, "--invoiced/--uninvoiced"),
    output_json: bool = typer.Option(False, "--json"),
) -> None:
    """Alias for 'expense list'."""
    expense_cmd.list_expenses(
        from_date=from_date, to_date=to_date, project=project,
        category=category, billable=billable, invoiced=invoiced,
        output_json=output_json,
    )


# ─── Magic routing: unrecognized text -> ai parse ────────────────────────────


def _is_known_command(arg: str) -> bool:
    """Check if an argument is a known command or subcommand."""
    known = {
        "auth", "billing", "timer", "log", "projects", "clients", "tasks", "report",
        "ai", "org", "config", "favorites", "skill", "timesheet", "invoice", "expense",
        "status", "s", "t", "ts", "tx",
        "l", "ll", "r", "p", "b", "ex", "--help", "-h", "--version", "-v", "--json",
    }
    return arg in known


_LOG_SUBCOMMANDS = {"list", "edit", "delete", "create", "--help", "-h", "--json"}


def _fix_log_routing() -> None:
    """Auto-insert 'create' for `ct log -p ... 2h "work"` style invocations.

    When `ct log` is followed by args that aren't a known log subcommand,
    the user intends `ct log create ...`. Insert 'create' so Typer routes
    correctly without the callback needing positional args (which would
    break subcommand routing).
    """
    if len(sys.argv) > 2 and sys.argv[1] == "log":
        second = sys.argv[2]
        if second not in _LOG_SUBCOMMANDS:
            sys.argv = [sys.argv[0], "log", "create"] + sys.argv[2:]


def _original_main() -> None:
    """CLI entry point with magic routing and error handling.

    If the first argument is not a known command, treat the entire
    argument string as natural language and route to 'ai parse'.
    """
    if len(sys.argv) > 1:
        first_arg = sys.argv[1]
        # If it's not a known command and doesn't start with --, route to ai parse
        if not first_arg.startswith("-") and not _is_known_command(first_arg):
            text = " ".join(sys.argv[1:])
            sys.argv = [sys.argv[0], "ai", "parse", text]

    _fix_log_routing()

    try:
        app()
    except APIError as e:
        format_error(e.message)
        raise SystemExit(1)
    except SystemExit:
        raise
    except KeyboardInterrupt:
        raise SystemExit(0)
    except Exception as e:
        format_error(f"Unexpected error: {e}")
        raise SystemExit(1)


if __name__ == "__main__":
    _original_main()
