# CrowdTime CLI — Common Workflows

Multi-step workflow patterns for real-world time tracking scenarios.

## Table of Contents

- [Daily Routines](#daily-routines)
- [End of Week](#end-of-week)
- [Project Setup](#project-setup)
- [Backfilling Time](#backfilling-time)
- [Team Management](#team-management)
- [Reporting and Export](#reporting-and-export)
- [Timesheet Submission and Approval](#timesheet-submission-and-approval)
- [Expense Tracking](#expense-tracking)
- [Client Contact Management](#client-contact-management)
- [Project Budget Tracking](#project-budget-tracking)
- [Invoicing and Billing](#invoicing-and-billing)
- [Subscription and Billing](#subscription-and-billing)
- [Troubleshooting](#troubleshooting)

---

## Daily Routines

### Morning Start

```bash
# Check what's going on
ct s

# Start working
ct ts "morning standup" -p team-meetings
```

### Switch Between Tasks

```bash
# Atomic switch — stops current timer and starts new one
ct timer switch "API endpoint work" -p backend

# Or stop and start separately
ct tx
ct ts "design review" -p frontend
```

### End of Day

```bash
# Stop running timer
ct tx

# Check today's log
ct ll --date today

# See total hours
ct s
```

### Quick Entry Without Timer

If you forgot to use a timer, log directly:

```bash
ct l -p acme-project 1h30m "client call with Acme"
ct l -p backend 45m "code review for PR #234"
```

---

## End of Week

### Weekly Review

```bash
# See the full week at a glance
ct s

# Detailed report grouped by project
ct report --week -g project

# Report grouped by day to spot gaps
ct report --week -g day

# Get AI summary for standup
ct ai summarize --week --for standup

# Get AI summary for Slack, auto-copied
ct ai summarize --week --for slack --copy
```

### Fill In Missing Days

```bash
# Check what days are light
ct report --week -g day

# Backfill entries
ct l -p project-alpha -d monday 6h "feature development"
ct l -p project-alpha -d monday 2h "code review"
ct l -p project-beta -d tuesday 7h "API integration"
```

### Export for Invoicing

```bash
# CSV export for spreadsheet
ct report --month -p client-project -f csv > march-2026-hours.csv

# Markdown for docs/email
ct report --month -g project -f markdown

# JSON for programmatic use
ct report --month -f json
```

---

## Project Setup

### Create a New Project with Tasks

```bash
# Create the project (client is auto-created if it doesn't exist)
ct projects create "Website Redesign" --client "Acme Corp" --budget 200 --code WR -b

# Create tasks for the project (use project slug, not display name)
ct tasks create "Design" -p website-redesign -b
ct tasks create "Development" -p website-redesign -b
ct tasks create "QA Testing" -p website-redesign -b
ct tasks create "Meetings" -p website-redesign -B  # non-billable

# Set as default if it's your main project
ct projects switch website-redesign
```

### Create Favorites for Recurring Work

```bash
# Create templates for things you do every day
ct favorites create "Daily standup" -p team-meetings -t standup
ct favorites create "Code review" -p engineering -t review -b
ct favorites create "Sprint planning" -p team-meetings -t planning

# Start a timer from a favorite
ct favorites list    # find the ID
ct favorites start <id>
```

---

## Backfilling Time

### Log a Full Past Day

```bash
# Log multiple entries for yesterday (options MUST come before duration/description)
ct l -p team -d yesterday 1h "standup + planning"
ct l -p project-alpha -d yesterday -b 4h "feature implementation"
ct l -p project-alpha -d yesterday -b 2h "code review"
ct l -p project-alpha -d yesterday -B 1h "documentation"
```

### Log for a Specific Past Date

```bash
ct l -p training -d "last wednesday" 8h "workshop"
ct l -p acme -d 2026-03-05 3h "client meeting"
```

---

## Team Management

### Onboard a New Team Member

```bash
# Invite a regular team member
ct org invite newdev@company.com -r member

# Invite a project manager (can manage projects/tasks/timesheets, no financial access)
ct org invite pm@company.com -r project_manager

# Invite an account manager (full financial access: invoices, rates, clients)
ct org invite billing@company.com -r manager

# Invite an external client stakeholder (read-only, scoped to their projects)
ct org invite client@acme.com -r viewer

# They receive an email with an "Accept Invitation" link
# New users can sign up with email/password or Google OAuth
```

### Manage Invitations

```bash
# List pending invitations
ct org invitations

# Resend an invitation email
ct org resend-invite <invitation-id>
```

### Role Reference

| Role | Description |
|------|-------------|
| `viewer` | External client: read-only, scoped to assigned projects |
| `member` | Logs time, manages own entries |
| `project_manager` | Manages projects, tasks, timesheets, team time. No financial data |
| `manager` | Account Manager: everything above + invoices, rates, clients, billing |
| `admin` | Manages org settings, members, integrations |
| `owner` | Full control including org deletion |

### Check Team Activity

```bash
# Team utilization this week
ct report team --week

# Specific member
ct report team --month --member john@company.com

# List all members
ct org members
```

---

## Reporting and Export

### Client Billing Report

```bash
# Monthly billable hours for a specific project
ct report --month -p client-project -f csv > invoice-data.csv

# Project breakdown across all projects
ct report projects --month

# Detailed with day-by-day breakdown
ct report --from 2026-03-01 --to 2026-03-31 -g day -p client-project
```

### Personal Productivity

```bash
# How did I spend my week?
ct report --week -g project

# Daily breakdown
ct report --week -g day

# Get AI insights
ct ai summarize --week
```

### Custom Date Ranges

```bash
# Last two weeks
ct report --from 2026-02-24 --to 2026-03-09

# Specific sprint (2 weeks)
ct report --from 2026-03-01 --to 2026-03-14 -g task

# Quarter to date
ct report --from 2026-01-01 --to 2026-03-31 -g project -f markdown
```

---

## Timesheet Submission and Approval

### Submit a Weekly Timesheet

```bash
# Review your week first
ct report --week -g day

# Fill any gaps
ct l -p project-alpha -d monday 6h "feature development"

# Submit the timesheet
ct timesheet submit --from 2026-03-09 --to 2026-03-15

# Check submission status
ct timesheet list
```

### Manager: Review Team Timesheets

```bash
# See team overview for this week
ct timesheet team

# Or a custom period
ct timesheet team --from 2026-03-09 --to 2026-03-15

# Last week
ct timesheet team --last-week

# Approve a submitted timesheet
ct timesheet approve <timesheet-id>

# Reject with feedback
ct timesheet reject <timesheet-id> --notes "Missing entries for Wednesday — please add your standup and dev hours"
```

### End-of-Week Timesheet Routine

```bash
# 1. Check your hours
ct report --week

# 2. Fill gaps
ct report --week -g day   # spot light days

# 3. Submit
ct timesheet submit --from 2026-03-09 --to 2026-03-15

# 4. (Manager) Review team
ct timesheet team
```

---

## Expense Tracking

### Logging an Expense

```bash
# Log a billable expense to a project
ct expense create --amount 49.99 "Domain renewal" --project acme-website --category "Software" --vendor "Namecheap" --billable

# Log a non-billable internal expense
ct expense create --amount 29.99 "Team Slack subscription" --category "Software"

# Log a past expense
ct ex create --amount 85 "Client dinner" --category "Meals" --vendor "La Trattoria" -d yesterday --billable -p acme-project
```

### Setting Up Expense Categories

```bash
# Check existing categories
ct expense categories

# Add categories for your organization
ct expense add-category "Software"
ct expense add-category "Travel"
ct expense add-category "Meals"
ct expense add-category "Office Supplies"
ct expense add-category "Hardware"
```

### Reviewing Expenses

```bash
# List expenses for a period
ct expense list --from 2026-03-01 --to 2026-03-31

# Filter by project and billable status
ct expense list --project acme-website --billable

# Check which expenses have been invoiced
ct expense list --invoiced

# Check uninvoiced billable expenses
ct expense list --billable --from 2026-03-01 --to 2026-03-31
```

### Editing and Deleting Expenses

```bash
# Fix an amount
ct expense edit <expense-id> --amount 59.99

# Change the category
ct expense edit <expense-id> --category "Travel"

# Delete an incorrect expense
ct expense delete <expense-id>
```

---

## Client Contact Management

### Adding Contacts to a Client

```bash
# List existing contacts
ct clients contacts <client-id>

# Add a primary contact
ct clients add-contact <client-id> --name "Jane Smith" --email jane@acme.com --phone "+1-555-0123" --role "CEO" --primary

# Add additional contacts
ct clients add-contact <client-id> --name "Bob Johnson" --email bob@acme.com --role "Billing Manager"
ct clients add-contact <client-id> --name "Alice Chen" --email alice@acme.com --role "Project Lead"
```

### Removing a Contact

```bash
# List contacts to find the ID
ct clients contacts <client-id>

# Remove a contact
ct clients remove-contact <client-id> <contact-id>
```

---

## Project Budget Tracking

### Checking Project Budget

```bash
# View budget status for a project
ct projects budget acme-website

# Refresh the snapshot (recalculates from latest time entries)
ct projects budget acme-website --refresh

# Check multiple projects
ct projects budget acme-website
ct projects budget internal-tools
```

### Budget Monitoring Routine

```bash
# 1. Check all project budgets
ct report projects --month

# 2. Drill into projects that look close to budget
ct projects budget acme-website --refresh

# 3. If over budget, review recent entries
ct report --month -p acme-website -g task
```

---

## Invoicing and Billing

### Create and Send an Invoice

```bash
# 1. Create a draft invoice with period preset (auto-imports time + expenses)
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30

# The output shows how many time entries and expenses were included.
# Billable expenses from the period are automatically added as line items.

# 2. Or create manually and import separately
ct invoice create --client "Acme Corp" --due 2026-04-15
ct invoice import-time <invoice-id> --from 2026-03-01 --to 2026-03-31

# 3. Add manual line items if needed
ct invoice add-line <invoice-id> --description "Setup fee" --quantity 1 --rate 500

# 4. Review the invoice (includes time entries + expenses as line items)
ct invoice show <invoice-id>

# 5. Send it
ct invoice send <invoice-id>
```

### Invoice with Period Presets

```bash
# Last week's billable time + expenses
ct invoice create --client "Acme Corp" --period last-week --payment-terms receipt

# Last two weeks
ct invoice create --client "Acme Corp" --period last-2-weeks --payment-terms net15

# Last month
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30

# This month so far
ct invoice create --client "Acme Corp" --period this-month --payment-terms 45
```

### Invoice for a Specific Project

```bash
# Import time for just one project
ct invoice create --client "Acme Corp" --due 2026-04-15
ct invoice import-time <invoice-id> --from 2026-03-01 --to 2026-03-31 -p acme-website

# Review and send — note: billable expenses for the project are included
ct invoice show <invoice-id>
ct invoice send <invoice-id>
```

### Creating Invoice with Expenses

```bash
# 1. Make sure billable expenses are logged with the right project
ct expense list --billable --from 2026-03-01 --to 2026-03-31

# 2. Create invoice with period preset — expenses are auto-included
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30

# 3. Review — expenses appear as separate line items
ct invoice show <invoice-id>

# 4. Send
ct invoice send <invoice-id>
```

### Record Payment

```bash
# Full payment
ct invoice mark-paid <invoice-id> --method "bank_transfer" --reference "TXN-12345"

# Check invoice status
ct invoice show <invoice-id>
```

### Monthly Invoicing Routine

```bash
# 1. Review all projects for the month
ct report --month -g project

# 2. Check billable expenses for the month
ct expense list --billable --from 2026-03-01 --to 2026-03-31

# 3. List clients that need invoicing
ct clients list

# 4. Create invoices per client (period preset auto-imports time + expenses)
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30
ct invoice create --client "Beta Inc" --period last-month --payment-terms net30

# 5. Review and send all drafts
ct invoice list --status draft
ct invoice show <invoice-id-1>    # Verify time entries + expenses look correct
ct invoice send <invoice-id-1>
ct invoice show <invoice-id-2>
ct invoice send <invoice-id-2>
```

### Duplicate a Recurring Invoice

```bash
# Find a previous invoice to base on
ct invoice list --client "Acme Corp" --status paid

# Duplicate it
ct invoice duplicate <invoice-id>

# Update the new draft as needed
ct invoice show <new-invoice-id>
```

---

## Retainer Management

### Set Up a Retainer and Track Balance

```bash
# 1. List retainers
ct invoice retainer list

# 2. View retainer details and balance
ct invoice retainer show <retainer-id>
```

### Apply Retainer Credit to an Invoice

```bash
# 1. Check retainer balance
ct invoice retainer show <retainer-id>

# 2. Find the invoice to pay
ct invoice list --status sent --client "Acme Corp"

# 3. Apply retainer credit
ct invoice retainer withdraw <retainer-id> --invoice <invoice-id> --amount 2000 --notes "March credit"

# 4. Verify the invoice payment
ct invoice show <invoice-id>
```

### View Withdrawal History

```bash
# List all withdrawals for a retainer
ct invoice retainer withdrawals <retainer-id>
```

### Reverse a Withdrawal

```bash
# If a withdrawal was applied incorrectly
ct invoice retainer reverse-withdrawal <retainer-id> --withdrawal <withdrawal-id> --reason "Applied to wrong invoice"

# Verify the reversal
ct invoice retainer show <retainer-id>    # Balance restored
ct invoice show <invoice-id>               # Payment removed
```

### Monthly Retainer Routine

```bash
# 1. Generate retainer invoice for the period
#    (done via web UI or API — generates draft with retainer fee + overage)

# 2. Review and send the retainer invoice
ct invoice list --type retainer --status draft
ct invoice show <retainer-invoice-id>
ct invoice send <retainer-invoice-id>

# 3. Record payment when client pays the retainer invoice
ct invoice pay <retainer-invoice-id> --amount 5000 --method bank_transfer --reference "TXN-456"

# 4. Now the retainer balance increases — apply to standard invoices
ct invoice retainer show <retainer-id>
ct invoice retainer withdraw <retainer-id> --invoice <standard-invoice-id> --amount 3000
```

---

## Subscription and Billing

### Check Subscription Status

```bash
# Quick check
ct billing

# Machine-readable
ct billing --json
```

### Start a Subscription

```bash
# Start a free trial (opens Stripe Checkout in browser)
ct billing checkout

# Start with annual plan (20% savings)
ct billing checkout annual
```

### Manage Subscription via Stripe Portal

```bash
# Open Stripe billing portal (admin+ only)
ct billing portal

# From the portal you can:
# - Update payment method
# - View past Stripe invoices
# - Cancel subscription
```

### Switch Billing Plan

```bash
# Switch to annual billing (saves 20%)
ct billing plan annual

# Switch back to monthly
ct billing plan monthly

# Change takes effect immediately with prorated credit
```

### Reactivate a Canceled Subscription

```bash
# If subscription is set to cancel at period end:
ct billing reactivate

# Verify it's active again
ct billing
```

### View Billing Event History

```bash
# Show recent billing events (webhook audit log)
ct billing events

# Show more events
ct billing events -n 50

# Machine-readable
ct billing events --json
```

### Handle Subscription Issues

```bash
# If you see "subscription is inactive" errors on other commands:
ct billing                # Check current status
ct billing portal         # Open portal to update payment or resubscribe

# If subscription is canceled but still within billing period:
ct billing reactivate     # Undo the cancellation

# If you get "permission denied":
# - billing portal requires admin+ role
# - plan changes and reactivation require owner role
# Ask your org owner to manage the subscription.
```

---

## Troubleshooting

### "Not authenticated" Error

```bash
ct auth whoami           # Check current auth status
ct auth login            # Re-authenticate (opens browser)
ct auth login --token <your-token>  # Or use a token directly
```

### "No organization selected" Error

```bash
ct org list              # See available orgs
ct org switch <slug>     # Select one
```

### "Timer already running" Error

```bash
ct t                     # See what's running
ct timer switch "new task" -p project   # Switch to new task
# or
ct tx                    # Stop current timer first
```

### Wrong Default Project

```bash
ct config get defaults.project      # Check current default
ct projects switch <correct-slug>   # Change it
```

### Server Connection Issues

```bash
ct config get server.url            # Check configured URL
ct config set server.url https://api.crowdtime.lat   # Fix if needed
```

### Check Current Configuration

```bash
ct config list                      # See all settings
ct config edit                      # Edit in your editor
```
