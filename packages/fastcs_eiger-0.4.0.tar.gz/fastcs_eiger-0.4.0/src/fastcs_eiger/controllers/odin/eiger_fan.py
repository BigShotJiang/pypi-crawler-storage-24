from fastcs.attributes import AttrR, AttrRW
from fastcs.datatypes import Bool
from fastcs_odin.controllers import OdinSubController
from fastcs_odin.io import StatusSummaryAttributeIORef
from fastcs_odin.util import create_attribute


class EigerFanAdapterController(OdinSubController):
    """Controller for an EigerFan adapter in an odin control server"""

    state: AttrR[str]
    acqid: AttrRW[str]
    block_size: AttrRW[int]
    ready: AttrR[bool]

    async def initialise(self):
        for parameter in self.parameters:
            # Remove 0 index and status/config
            match parameter.uri:
                case ["0", "status" | "config", *_]:
                    parameter.set_path(parameter.path[2:])
            self.add_attribute(
                parameter.name,
                create_attribute(parameter=parameter, api_prefix=self._api_prefix),
            )

        # Manually validate `state` to get a nicer error message if not introspected
        self._validate_hinted_attribute("state")

        self.ready = AttrR(
            Bool(),
            io_ref=StatusSummaryAttributeIORef(
                [], "", lambda states: states[0] == "DSTR_HEADER", [self.state]
            ),
        )
