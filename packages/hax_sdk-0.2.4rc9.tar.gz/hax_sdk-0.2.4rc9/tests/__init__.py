"""HAX SDK test suite."""
