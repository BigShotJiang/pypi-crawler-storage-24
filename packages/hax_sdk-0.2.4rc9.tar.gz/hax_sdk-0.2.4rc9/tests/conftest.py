"""Pytest fixtures for HAX SDK tests."""

import pytest


@pytest.fixture
def sample_webhook_payload() -> dict:
    """Sample webhook event payload."""
    return {
        "type": "request.completed",
        "timestamp": "2024-01-01T01:00:00Z",
        "data": {
            "id": "req_abc123",
            "projectId": "proj_xyz789",
            "type": "text-approval-v1",
            "status": "completed",
            "metadata": {"source": "test"},
            "response": {"decision": "approve"},
            "respondedBy": "user_123",
            "respondedAt": "2024-01-01T01:00:00Z",
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": "2024-01-01T01:00:00Z",
            "payload": {"text": "Approve?"},
        },
    }
