"""Delivery models for HAX SDK."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict


class DeliveryConfig(BaseModel):
    """Configuration for delivering a request URL via email or SMS."""

    model_config = ConfigDict(populate_by_name=True)

    channel: Literal["email", "sms"]
    """The channel to use for delivery."""

    recipient: str
    """The recipient email address or phone number (E.164 format for SMS)."""

    subject: str | None = None
    """Optional email subject (email only)."""

    message: str | None = None
    """Optional custom message to include."""


class DeliveryResult(BaseModel):
    """Result of a delivery attempt."""

    model_config = ConfigDict(populate_by_name=True)

    success: bool
    """Whether the delivery was successful."""

    channel: str
    """The channel used (email or sms)."""

    error: str | None = None
    """Error message if delivery failed."""
