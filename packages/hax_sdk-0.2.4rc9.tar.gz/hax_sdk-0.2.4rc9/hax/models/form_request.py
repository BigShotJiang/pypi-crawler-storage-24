"""Form request models for typed form responses."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass
class FormRequestResponse(Generic[T]):
    """A typed response from a completed form request."""

    values: T
    """The typed form values."""

    submitted_at: datetime | None
    """When the form was submitted."""

    responded_by: str | None = None
    """User ID who responded (if available)."""

    responded_at: datetime | None = None
    """When the response was submitted."""


@dataclass
class FormRequestStatus(Generic[T]):
    """Current status of a form request."""

    status: str
    """The request status (pending, opened, completed, expired, cancelled)."""

    completed: bool
    """Whether the form has been completed."""

    response: FormRequestResponse[T] | None = None
    """The response if completed."""
