"""HAX Python SDK - Human Approval eXchange.

A minimal, stable interface for interacting with the HAX API.
Enables agents and automated systems to programmatically collect human input.

Example:
    >>> from hax import HaxClient
    >>>
    >>> client = HaxClient(api_key="hax_live_...")
    >>> request = client.create_request(
    ...     type="text-approval-v1",
    ...     payload={"text": "Approve deployment?"},
    ...     webhook_url="https://myapp.com/webhook",
    ... )
    >>> print(f"Share this URL: {request.url}")

With encryption:
    >>> from hax import HaxClient
    >>>
    >>> client = HaxClient(
    ...     api_key="hax_live_...",
    ...     encryption_key="my-secret-passphrase",
    ... )
    >>> # Public key is automatically sent with requests
    >>> # Responses are automatically decrypted when retrieved
"""

from hax.client import FormRequestHandle, HaxClient
from hax.crypto import decrypt_response, generate_key_pair, is_encrypted_response
from hax.exceptions import (
    AuthenticationError,
    DecryptionError,
    HaxError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from hax.form_builder import FormBuilder
from hax.models import CreatedRequest, Request, RequestStatus, RequestSummary
from hax.models.delivery import DeliveryConfig, DeliveryResult
from hax.models.form_request import FormRequestResponse, FormRequestStatus
from hax.webhooks import WebhookEvent, parse_event, verify_signature

__version__ = "0.2.4-rc.9"

__all__ = [
    # Client
    "HaxClient",
    # Form Builder
    "FormBuilder",
    "FormRequestHandle",
    "FormRequestResponse",
    "FormRequestStatus",
    # Models
    "Request",
    "CreatedRequest",
    "RequestStatus",
    "RequestSummary",
    # Delivery
    "DeliveryConfig",
    "DeliveryResult",
    # Webhooks
    "WebhookEvent",
    "verify_signature",
    "parse_event",
    # Encryption (RSA-OAEP)
    "generate_key_pair",
    "decrypt_response",
    "is_encrypted_response",
    # Exceptions
    "HaxError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "DecryptionError",
]
