"""
Tests for load_skill tool functionality (AgentSkills with markdown files).
"""

import sys
import tempfile
from pathlib import Path

import pytest

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.agent import Agent
from em_agent_framework.core.tools.registry import SkillLibrary


class TestSkillLibrary:
    """Unit tests for SkillLibrary parsing and loading."""

    @pytest.fixture
    def skills_dir(self, tmp_path):
        """Create a temporary skills directory with sample .md files."""
        (tmp_path / "code-review.md").write_text(
            "---\nname: code-review\ndescription: Instructions for code review\n---\n"
            "When reviewing code, focus on:\n1) correctness\n2) efficiency\n3) readability\n",
            encoding="utf-8",
        )
        (tmp_path / "debugging.md").write_text(
            "---\nname: debugging\ndescription: Instructions for debugging\n---\n"
            "When debugging, follow these steps:\n1) Reproduce the issue\n2) Isolate the problem\n",
            encoding="utf-8",
        )
        (tmp_path / "documentation.md").write_text(
            "---\nname: documentation\ndescription: Instructions for writing documentation\n---\n"
            "Write clear documentation with:\n1) Purpose/overview\n2) Usage examples\n",
            encoding="utf-8",
        )
        # A file without proper frontmatter — should be skipped
        (tmp_path / "no-frontmatter.md").write_text(
            "This file has no YAML frontmatter and should be ignored.\n",
            encoding="utf-8",
        )
        return str(tmp_path)

    def test_load_skills_from_directory(self, skills_dir):
        """Test that SkillLibrary loads all valid .md skills."""
        lib = SkillLibrary(skills_dir)
        names = lib.list_available_names()

        assert "code-review" in names
        assert "debugging" in names
        assert "documentation" in names
        assert len(names) == 3  # no-frontmatter.md should be skipped

    def test_get_short_descriptions(self, skills_dir):
        """Test short descriptions include all skills."""
        lib = SkillLibrary(skills_dir)
        desc = lib.get_short_descriptions()

        assert "code-review" in desc
        assert "debugging" in desc
        assert "documentation" in desc
        assert "load_skill" in desc

    def test_get_skill_content(self, skills_dir):
        """Test loading full skill content strips frontmatter."""
        lib = SkillLibrary(skills_dir)
        content = lib.get_skill_content("code-review")

        assert content is not None
        assert "correctness" in content
        assert "---" not in content  # frontmatter should be stripped
        assert lib.is_loaded("code-review")

    def test_get_skill_content_not_found(self, skills_dir):
        """Test that missing skill returns None."""
        lib = SkillLibrary(skills_dir)
        assert lib.get_skill_content("nonexistent") is None

    def test_is_loaded_tracking(self, skills_dir):
        """Test that loaded state is tracked correctly."""
        lib = SkillLibrary(skills_dir)
        assert not lib.is_loaded("debugging")
        lib.get_skill_content("debugging")
        assert lib.is_loaded("debugging")
        assert not lib.is_loaded("code-review")

    def test_empty_directory(self, tmp_path):
        """Test SkillLibrary with an empty directory."""
        lib = SkillLibrary(str(tmp_path))
        assert lib.list_available_names() == []
        assert "No agent skills available" in lib.get_short_descriptions()

    def test_nonexistent_directory(self, tmp_path):
        """Test SkillLibrary with a nonexistent directory."""
        lib = SkillLibrary(str(tmp_path / "does_not_exist"))
        assert lib.list_available_names() == []


class TestLoadSkillAgent:
    """Integration tests for load_skill in Agent."""

    @pytest.fixture
    def skills_dir(self, tmp_path):
        """Create a temporary skills directory."""
        (tmp_path / "code-review.md").write_text(
            "---\nname: code-review\ndescription: Instructions for code review\n---\n"
            "When reviewing code, focus on:\n1) correctness\n2) efficiency\n3) readability\n",
            encoding="utf-8",
        )
        (tmp_path / "debugging.md").write_text(
            "---\nname: debugging\ndescription: Instructions for debugging\n---\n"
            "When debugging:\n1) Reproduce the issue\n2) Isolate the problem\n3) Identify the root cause\n",
            encoding="utf-8",
        )
        return str(tmp_path)

    @pytest.fixture
    def agent_config(self):
        return AgentConfig(max_turns=10, max_retries_per_model=2, verbose=True)

    @pytest.fixture
    def model_configs(self):
        return [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

    @pytest.mark.asyncio
    async def test_agent_with_skills_dir(self, skills_dir, agent_config, model_configs):
        """Test agent creation with skills_dir adds load_skill and descriptions."""
        agent = Agent(
            name="skill_agent",
            system_instruction="You are a helpful coding assistant.",
            tools=[],
            skills_dir=skills_dir,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Should have load_skill tool
        assert any(tool.__name__ == "load_skill" for tool in agent.tools)

        # System instruction should mention available skills
        assert "code-review" in agent.system_instruction
        assert "debugging" in agent.system_instruction

    @pytest.mark.asyncio
    async def test_load_skill_tool(self, skills_dir, agent_config, model_configs):
        """Test loading a skill via the tool."""
        agent = Agent(
            name="loadable_agent",
            system_instruction="You are a helpful assistant.",
            tools=[],
            skills_dir=skills_dir,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message(
            "Please load the 'code-review' skill using the load_skill tool."
        )

        assert isinstance(response, str)
        assert "correctness" in agent.system_instruction or "efficiency" in agent.system_instruction
        print(f"\nLoad skill response: {response}")

    @pytest.mark.asyncio
    async def test_load_multiple_skills(self, skills_dir, agent_config, model_configs):
        """Test loading multiple skills."""
        agent = Agent(
            name="multi_skill_agent",
            system_instruction="You are a software engineering assistant.",
            tools=[],
            skills_dir=skills_dir,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        await agent.send_message("Load the 'code-review' skill.")
        await agent.send_message("Load the 'debugging' skill.")

        assert "correctness" in agent.system_instruction or "efficiency" in agent.system_instruction
        assert "Reproduce the issue" in agent.system_instruction or "debugging" in agent.system_instruction

    @pytest.mark.asyncio
    async def test_invalid_skill_name(self, skills_dir, agent_config, model_configs):
        """Test loading a non-existent skill."""
        agent = Agent(
            name="invalid_skill_agent",
            system_instruction="You are a helpful assistant.",
            tools=[],
            skills_dir=skills_dir,
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message(
            "Load the 'nonexistent-skill' using load_skill."
        )

        assert isinstance(response, str)
        print(f"\nInvalid skill response: {response}")
