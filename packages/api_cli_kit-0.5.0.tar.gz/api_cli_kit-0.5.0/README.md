# GabungV2 Client (v0.5.0)

GabungV2 Multi-Stage Activation Client - Python package for API authentication and device management.

## Installation

### From PyPI (recommended)
```bash
pip install gabungv2-client
```

### From source
```bash
pip install .
```

### Editable install (development)
```bash
pip install -e .
```

## CLI Usage

After installation, run:
```bash
gabungv2-client
```

Or use the module directly:
```bash
python -m gabungv2_client
```

## Python API Usage

```python
from gabungv2_client import APIClient, APIConfig, DeviceManager

# Create configuration
config = APIConfig(base_url="http://your-server.com/api/api_v3.php")

# Create client
client = APIClient(config)

# Get device info
device_mgr = DeviceManager()
drive_id = device_mgr.get_drive_id()
uuid = device_mgr.get_device_uuid()
fingerprint = device_mgr.get_fingerprint()

# Login
response = client.login(
    username="your_username",
    password="your_password",
    drive_id=drive_id,
    device_uuid=uuid,
    device_fingerprint=fingerprint
)

if response.is_success():
    print(f"Login successful: {response.user_details}")
```

## Package Structure

```
gabungv2_client/
├── __init__.py      # Public API exports
├── __main__.py      # CLI entry point
├── config.py        # APIConfig class
├── models.py        # Data models (UserDetails, DriveDetails, etc.)
├── exceptions.py    # Custom exceptions
├── device.py       # DeviceManager class
├── client.py       # APIClient class + create_client()
└── app.py          # ClientApp CLI application
```

## Requirements

- Python >= 3.8
- requests >= 2.28.0
- rich >= 13.0.0

## License

MIT License - see LICENSE file.