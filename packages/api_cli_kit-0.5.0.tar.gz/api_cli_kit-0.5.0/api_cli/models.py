from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class UserDetails:
    user_id: Optional[int] = None
    username: Optional[str] = None
    uuid: Optional[str] = None
    email: Optional[str] = None
    user_type: Optional[str] = None
    account_created: Optional[str] = None
    last_login: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "UserDetails":
        return cls(
            user_id=data.get("user_id"),
            username=data.get("username"),
            uuid=data.get("uuid"),
            email=data.get("email"),
            user_type=data.get("user_type"),
            account_created=data.get("account_created") or data.get("created_at"),
            last_login=data.get("last_login"),
        )


@dataclass
class DriveDetails:
    drive_id: Optional[str] = None
    status: Optional[str] = None
    last_used: Optional[str] = None
    assigned_to: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "DriveDetails":
        return cls(
            drive_id=data.get("drive_id"),
            status=data.get("status"),
            last_used=data.get("last_used"),
            assigned_to=data.get("assigned_to"),
        )


@dataclass
class PlanInfo:
    has_plan: bool = False
    plan_name: Optional[str] = None
    expiry_date: Optional[str] = None
    is_active: int = 0
    max_drive: int = 0
    remaining_days: Optional[int] = None
    remaining_hours: Optional[int] = None
    remaining_minutes: Optional[int] = None
    message: Optional[str] = None
    action_required: Optional[str] = None
    is_unlimited: bool = False
    available_plans: list = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "PlanInfo":
        return cls(
            has_plan=data.get("has_plan", False),
            plan_name=data.get("plan_name"),
            expiry_date=data.get("expiry_date"),
            is_active=data.get("is_active", 0),
            max_drive=data.get("max_drive", 0),
            remaining_days=data.get("remaining_days"),
            remaining_hours=data.get("remaining_hours"),
            remaining_minutes=data.get("remaining_minutes"),
            message=data.get("message"),
            action_required=data.get("action_required"),
            is_unlimited=data.get("is_unlimited", False),
            available_plans=data.get("available_plans", []),
        )


@dataclass
class APIResponse:
    status: str = ""
    message: str = ""
    timestamp: Optional[str] = None
    reference_id: Optional[str] = None
    raw: dict = field(default_factory=dict)
    session_id: Optional[str] = None
    user_details: Optional[UserDetails] = None
    drive_details: Optional[DriveDetails] = None
    plan_info: Optional[PlanInfo] = None
    additional_info: Optional[dict] = None
    plan_details: Optional[dict] = None
    solutions: Optional[dict] = None
    server_info: Optional[dict] = None

    @classmethod
    def from_dict(cls, data: dict) -> "APIResponse":
        resp = cls(
            status=data.get("status", ""),
            message=data.get("message", ""),
            timestamp=data.get("timestamp"),
            reference_id=data.get("reference_id"),
            raw=data,
        )
        inner = data.get("data", {})
        if resp.status == "success" and inner:
            resp.session_id = inner.get("session_id")
            resp.user_details = UserDetails.from_dict(inner.get("user_details", {}))
            resp.drive_details = DriveDetails.from_dict(inner.get("drive_details", {}))
            resp.plan_info = PlanInfo.from_dict(inner.get("plan_info", {}))
            resp.additional_info = inner.get("additional_info")
            resp.server_info = inner.get("server_info")
        elif resp.status in ("new_user", "existing_no_plan", "plan_inactive", "plan_expired",
                             "payment_required", "drive_required") and inner:
            resp.user_details = UserDetails.from_dict(inner.get("user_details", {}))
            resp.plan_details = inner.get("plan_details")
            resp.solutions = inner.get("solutions")
            resp.additional_info = inner.get("additional_info")
            resp.server_info = inner.get("server_info")
            if resp.plan_details and not resp.plan_info:
                resp.plan_info = PlanInfo.from_dict(resp.plan_details)
        return resp

    def is_success(self) -> bool:
        return self.status == "success"

    def is_plan_issue(self) -> bool:
        return self.status in ("plan_inactive", "plan_expired", "payment_required", "drive_required")

    def is_new_user(self) -> bool:
        return self.status in ("new_user", "existing_no_plan")

    def is_rate_limited(self) -> bool:
        return self.status == "rate_limit_exceeded"

    def is_error(self) -> bool:
        return self.status in (
            "error", "server_error", "invalid_credentials", "missing_credentials",
            "drive_not_found", "drive_inactive", "suspended", "banned",
            "account_inactive", "too_many_attempts", "invalid_api_key", "missing_drive_id",
            "drive_exists", "invalid_format", "no_plan",
            "device_info_missing", "device_token_missing", "device_token_invalid",
            "device_already_used", "fingerprint_mismatch"
        )