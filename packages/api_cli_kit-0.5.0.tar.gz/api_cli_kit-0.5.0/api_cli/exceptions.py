from typing import Optional

from api_cli.models import APIResponse


class APIException(Exception):
    def __init__(self, message: str, response: Optional[APIResponse] = None):
        super().__init__(message)
        self.response = response


class RateLimitException(APIException):
    pass


class AuthenticationException(APIException):
    pass


class DriveException(APIException):
    pass


class PlanException(APIException):
    pass