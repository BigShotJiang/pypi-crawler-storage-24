import os
import json
from typing import Optional


class APIConfig:
    base_url: str = "http://localhost:8080/gabungv2.23/api/api_v3.php"
    api_key: Optional[str] = None
    timeout: int = 30
    max_retries: int = 3
    retry_delay: float = 2.0
    rate_limit_delay: float = 60.0
    log_file: Optional[str] = "api_client.log"
    log_level: str = "INFO"
    verify_ssl: bool = True
    debug: bool = True

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: int = 30,
        max_retries: int = 3,
        retry_delay: float = 2.0,
        rate_limit_delay: float = 60.0,
        log_file: Optional[str] = "api_client.log",
        log_level: str = "INFO",
        verify_ssl: bool = True,
        debug: bool = True,
    ):
        self.base_url = base_url or self.base_url
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.rate_limit_delay = rate_limit_delay
        self.log_file = log_file
        self.log_level = log_level
        self.verify_ssl = verify_ssl
        self.debug = debug

    @classmethod
    def load(cls) -> "APIConfig":
        cfg = cls()
        if os.path.exists("config.json"):
            try:
                with open("config.json", "r") as f:
                    data = json.load(f)
                    if data.get("base_url"):
                        cfg.base_url = data["base_url"]
                    if data.get("api_key"):
                        cfg.api_key = data["api_key"]
            except Exception:
                pass
        return cfg

    def save(self):
        try:
            with open("config.json", "w") as f:
                json.dump({"base_url": self.base_url, "api_key": self.api_key}, f, indent=2)
        except Exception:
            pass

    def to_dict(self):
        return {
            "base_url": self.base_url,
            "api_key": self.api_key,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "retry_delay": self.retry_delay,
            "rate_limit_delay": self.rate_limit_delay,
            "log_file": self.log_file,
            "log_level": self.log_level,
            "verify_ssl": self.verify_ssl,
            "debug": self.debug,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "APIConfig":
        valid_keys = {
            "base_url", "api_key", "timeout", "max_retries", "retry_delay",
            "rate_limit_delay", "log_file", "log_level", "verify_ssl", "debug"
        }
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered)