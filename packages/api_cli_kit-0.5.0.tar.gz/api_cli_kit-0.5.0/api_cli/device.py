import hashlib
import json
import os
import platform
import re
import subprocess
from datetime import datetime
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

ALLOWED_PREFIXES = ["five", "didi", "mzpy", "mysg"]


class DeviceManager:
    FILENAME = "device_id.txt"
    UUID_FILENAME = ".device_uuid"
    TOKEN_FILENAME = ".device_token"
    TAMPER_LOG_FILENAME = ".tamper_log"

    def __init__(self):
        self._tampered = False
        self._tampered_value = None

    def _get_android_hardware_id(self) -> str:
        sources = []
        cmds = [
            ["getprop", "ro.serialno"],
            ["getprop", "ro.boot.serialno"],
            ["getprop", "ro.product.board"],
            ["getprop", "ro.build.fingerprint"],
            ["getprop", "ro.product.model"],
        ]
        for cmd in cmds:
            try:
                val = subprocess.check_output(cmd, stderr=subprocess.DEVNULL).decode().strip()
                if val and val != "unknown":
                    sources.append(val)
            except Exception:
                pass

        try:
            aid = subprocess.check_output(
                ["settings", "get", "secure", "android_id"],
                stderr=subprocess.DEVNULL
            ).decode().strip()
            if aid and aid != "null":
                sources.append(aid)
        except Exception:
            pass

        return "|".join(sources)

    def _get_windows_hardware_id(self) -> str:
        sources = []
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Cryptography"
            )
            guid, _ = winreg.QueryValueEx(key, "MachineGuid")
            sources.append(guid)
            winreg.CloseKey(key)
        except Exception:
            pass

        try:
            result = subprocess.check_output(
                ["vol", "C:"], shell=True, stderr=subprocess.DEVNULL
            ).decode()
            serial = re.search(r"[\w]{4}-[\w]{4}", result)
            if serial:
                sources.append(serial.group())
        except Exception:
            pass

        return "|".join(sources)

    def _get_linux_hardware_id(self) -> str:
        sources = []

        for path in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
            try:
                with open(path, "r") as f:
                    val = f.read().strip()
                    if val:
                        sources.append(val)
                        break
            except Exception:
                pass

        try:
            with open("/proc/cpuinfo", "r") as f:
                for line in f:
                    if "Serial" in line or "Hardware" in line:
                        sources.append(line.split(":")[-1].strip())
        except Exception:
            pass

        return "|".join(sources)

    def get_hardware_fingerprint(self) -> str:
        system = platform.system()
        hw_id = ""

        if os.path.exists("/proc/version"):
            try:
                with open("/proc/version") as f:
                    if "android" in f.read().lower():
                        hw_id = self._get_android_hardware_id()
            except Exception:
                pass

        if not hw_id:
            if system == "Windows":
                hw_id = self._get_windows_hardware_id()
            else:
                hw_id = self._get_linux_hardware_id()

        if not hw_id:
            hw_id = "|".join([
                platform.node(),
                platform.machine(),
                platform.processor(),
            ])

        return hashlib.sha256(hw_id.encode()).hexdigest()

    def get_drive_id(self) -> str:
        if os.path.exists(self.FILENAME):
            try:
                with open(self.FILENAME, "r") as f:
                    cached = f.read().strip()

                if cached and self._is_valid_drive_id_format(cached):
                    expected = self._generate_from_hardware()
                    if cached != expected:
                        self._log_tamper(cached, expected)
                        self._tampered = True
                        self._tampered_value = expected
                    return cached

            except Exception:
                pass

        expected = self._generate_from_hardware()
        self.save_drive_id(expected)
        return expected

    def _is_valid_drive_id_format(self, drive_id: str) -> bool:
        parts = drive_id.split("-")
        return (
            len(parts) == 5
            and parts[0] in ALLOWED_PREFIXES
            and all(len(p) == 4 for p in parts[1:])
            and all(c in "0123456789abcdef" for p in parts[1:] for c in p)
        )

    def _log_tamper(self, cached: str, expected: str):
        try:
            entry = {
                "timestamp": datetime.now().isoformat(),
                "cached_drive_id": cached,
                "expected_drive_id": expected,
                "hw_fingerprint_hint": self.get_hardware_fingerprint()[:16] + "...",
            }
            with open(self.TAMPER_LOG_FILENAME, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass

    def _generate_from_hardware(self, prefix: Optional[str] = None) -> str:
        hw_hash = self.get_hardware_fingerprint()
        segments = [hw_hash[i:i+4] for i in range(0, 16, 4)]

        if prefix is None:
            idx = int(hw_hash[-1], 16) % len(ALLOWED_PREFIXES)
            prefix = ALLOWED_PREFIXES[idx]

        return f"{prefix}-{'-'.join(segments)}"

    def save_drive_id(self, drive_id: str):
        try:
            with open(self.FILENAME, "w") as f:
                f.write(drive_id)
        except Exception:
            pass

    def delete_drive_id(self):
        if os.path.exists(self.FILENAME):
            try:
                os.remove(self.FILENAME)
            except OSError:
                pass

    def get_device_uuid(self) -> str:
        if os.path.exists(self.UUID_FILENAME):
            try:
                with open(self.UUID_FILENAME, "r") as f:
                    v = f.read().strip()
                    if v:
                        return v
            except Exception:
                pass

        hw_hash = self.get_hardware_fingerprint()
        uuid_str = f"{hw_hash[0:8]}-{hw_hash[8:12]}-4{hw_hash[13:16]}-{hw_hash[16:20]}-{hw_hash[20:32]}"

        try:
            with open(self.UUID_FILENAME, "w") as f:
                f.write(uuid_str)
        except Exception:
            pass

        return uuid_str

    def get_device_token(self):
        if os.path.exists(self.TOKEN_FILENAME):
            try:
                with open(self.TOKEN_FILENAME, "r") as f:
                    return f.read().strip()
            except Exception:
                pass
        return None

    def save_device_token(self, token: str):
        try:
            with open(self.TOKEN_FILENAME, "w") as f:
                f.write(token)
        except Exception:
            pass

    def get_fingerprint(self) -> str:
        return self.get_hardware_fingerprint()

    def get_drive_id_hardware(self) -> str:
        return self._generate_from_hardware()

    def create_drive_id(self, interactive: bool = True) -> str:
        console = Console()

        if not interactive:
            return self.get_drive_id()

        console.print()
        console.print(Panel("DEVICE SETUP", title="📱", border_style="cyan", width=60))
        console.print("\n  [cyan]Drive ID belum ditemukan.[/cyan]")
        console.print("  [cyan]Pilih metode:[/cyan]\n")
        console.print("  [bold][1][/bold] ✨ Auto-generate dari hardware perangkat (Direkomendasikan)")
        console.print("  [bold][2][/bold] ⌨️  Input Manual (Jika punya Drive ID lama)\n")
        choice = Prompt.ask("  ➤ Pilihan kamu", choices=["1", "2"], default="1")

        if choice == "2":
            drive_id = Prompt.ask("\n  ➤ Masukkan Drive ID lama kamu")
            self.save_drive_id(drive_id)
            console.print("\n  [green]✅ Drive ID disimpan.[/green]")
            return drive_id

        drive_id = self._generate_from_hardware()
        self.save_drive_id(drive_id)
        console.print(f"\n  [green]✅ Drive ID: [bold]{drive_id}[/bold][/green]")
        console.print(f"  [dim](Dari hardware perangkat ini — tidak akan berubah)[/dim]")
        return drive_id