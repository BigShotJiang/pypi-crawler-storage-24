import json
import logging
import os
import select
import sys
import threading
import time
from typing import Any, Optional

import requests

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table
from rich.text import Text

from api_cli import create_client
from api_cli.config import APIConfig
from api_cli.device import DeviceManager
from api_cli.exceptions import (
    APIException,
    AuthenticationException,
    DriveException,
)

console = Console()


def _header(title: str, icon: str = ""):
    console.clear()
    console.print()
    console.print(Panel(
        Text(f"{icon} {title}", justify="center", style="bold cyan"),
        title="🔐 API v2 Client v0.5.0",
        border_style="cyan",
        width=60
    ))


def _field(label: str, value: Any, icon: str = ""):
    console.print(f"  {icon}  [bold]{label:<18}[/bold] {str(value) if value else '—'}")


def show_available_plans(plan_details: Optional[dict]) -> None:
    if not plan_details:
        console.print("\n  [yellow]⚠️  Tidak ada data plan tersedia.[/yellow]")
        return
    available = plan_details.get("available_plans", [])
    if not available:
        console.print("\n  [yellow]⚠️  Belum ada plan tersedia saat ini.[/yellow]")
        return
    table = Table(title="Daftar Plan Tersedia", show_header=True, header_style="bold magenta")
    table.add_column("No", style="dim", width=4)
    table.add_column("Nama Plan", style="bold")
    table.add_column("Harga", justify="right")
    table.add_column("Durasi (Hari)", justify="center")
    table.add_column("Keterangan")
    for i, p in enumerate(available, 1):
        raw_price = p.get("price", "-")
        try:
            price_str = f"Rp {float(raw_price):,.0f}".replace(",", ".")
        except (ValueError, TypeError):
            price_str = str(raw_price)
        desc = str(p.get("description", "-"))
        if len(desc) > 50:
            desc = desc[:47] + "..."
        table.add_row(
            str(i),
            str(p.get("plan_name", "-")),
            price_str,
            str(p.get("duration_days", "-")),
            desc
        )
    console.print(table)


class ClientApp:
    PLAN_LEVELS = {"trial": 1, "trial_plus": 2, "trial plus": 2, "basic": 3, "vip": 4, "premium": 5}
    PLAN_FEATURES = [
        {"name": "Fitur Basic", "min_level": 1, "desc": "Akses fitur dasar"},
        {"name": "Fitur Plus", "min_level": 2, "desc": "Akses fitur tambahan"},
        {"name": "Fitur Standar", "min_level": 3, "desc": "Akses fitur standar berbayar"},
        {"name": "Fitur VIP", "min_level": 4, "desc": "Akses fitur eksklusif"},
        {"name": "Fitur Premium", "min_level": 5, "desc": "Akses prioritas utama"},
    ]

    def __init__(self):
        self._config = APIConfig.load()
        self.url = self._config.base_url
        self.api_key = self._config.api_key
        self.username = None
        self.password = None
        self.drive_id = None
        self.client = create_client(base_url=self.url, api_key=self.api_key)
        self.response = None
        self.device_manager = DeviceManager()
        self.logger = logging.getLogger("ClientApp")
        self.stop_heartbeat = threading.Event()
        self.heartbeat_thread = None

    def start_heartbeat_loop(self):
        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            return
        self.stop_heartbeat.clear()
        self.heartbeat_thread = threading.Thread(target=self._heartbeat_worker, daemon=True)
        self.heartbeat_thread.start()

    def _heartbeat_worker(self):
        while not self.stop_heartbeat.is_set():
            if self.stop_heartbeat.wait(600):
                break
            try:
                if self.username and self.drive_id:
                    self.client.heartbeat(self.username, self.drive_id)
            except Exception:
                pass

    def stop_heartbeat_loop(self):
        self.stop_heartbeat.set()
        if self.heartbeat_thread:
            self.heartbeat_thread.join(timeout=2.0)

    def _silent_check_status(self):
        try:
            if not self.username or not self.password:
                return None, None
            resp = self.client.login(
                self.username,
                self.password,
                self.drive_id,
                device_uuid=self.device_manager.get_device_uuid(),
                device_token=self.device_manager.get_device_token(),
                device_fingerprint=self.device_manager.get_fingerprint(),
                drive_id_hardware=self.device_manager.get_drive_id_hardware(),
                raise_on_error=False,
                raise_on_plan_issue=False,
            )
            self._update_token(resp)
            return resp.status, resp
        except Exception:
            return None, None

    def start_auto_detect(self, interval: int = 30):
        active_event = threading.Event()
        stop_event = threading.Event()

        def _worker():
            elapsed = 0
            while not stop_event.wait(1):
                elapsed += 1
                if elapsed >= interval:
                    elapsed = 0
                    status, resp = self._silent_check_status()
                    if status == "success":
                        self.response = resp
                        self.save_credentials(self.username, self.password)
                        self.start_heartbeat_loop()
                        active_event.set()
                        return

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        active_event._stop_event = stop_event
        return active_event

    def stop_auto_detect(self, event: threading.Event):
        try:
            if hasattr(event, '_stop_event'):
                event._stop_event.set()
        except Exception:
            pass

    def _wait_for_input_or_event(self, prompt_text: str, choices: list, active_event: threading.Event, interval: int = 30):
        console.print(f"  [dim]⏱  Auto-check otomatis tiap {interval}s berjalan di background...[/dim]")
        sys.stdout.write(f"  {prompt_text} [{'/'.join(choices)}]: ")
        sys.stdout.flush()

        while True:
            if active_event.is_set():
                sys.stdout.write("\n")
                sys.stdout.flush()
                return "__ACTIVE__"
            try:
                ready, _, _ = select.select([sys.stdin], [], [], 0.5)
                if ready:
                    line = sys.stdin.readline().strip()
                    if line in choices:
                        return line
                    console.print(f"  [red]Pilihan tidak valid. Masukkan: {', '.join(choices)}[/red]")
                    sys.stdout.write(f"  {prompt_text} [{'/'.join(choices)}]: ")
                    sys.stdout.flush()
            except (OSError, Exception):
                if active_event.wait(timeout=0.5):
                    return "__ACTIVE__"

    def save_credentials(self, username, password):
        try:
            with open("credentials.json", "w") as f:
                json.dump({"username": username, "password": password}, f)
        except Exception:
            pass

    def load_credentials(self):
        if os.path.exists("credentials.json"):
            try:
                with open("credentials.json", "r") as f:
                    d = json.load(f)
                    return d.get("username"), d.get("password")
            except Exception:
                pass
        return None, None

    def delete_credentials(self):
        if os.path.exists("credentials.json"):
            try:
                os.remove("credentials.json")
            except OSError:
                pass

    def run(self):
        self.main_menu()

    def do_login(self, interactive=True):
        if not self.username and not self.password:
            saved_u, saved_p = self.load_credentials()
            if saved_u and saved_p:
                self.username, self.password = saved_u, saved_p
                console.print(f"  [cyan]🔄 Menggunakan kredensial tersimpan: [bold]{self.username}[/bold][/cyan]")
        if not self.username:
            self.username = Prompt.ask("  [bold]Username[/bold]            ")
        if not self.password:
            self.password = Prompt.ask("  [bold]Password[/bold]            ", password=True)

        device_uuid = self.device_manager.get_device_uuid()
        device_token = self.device_manager.get_device_token()
        device_fingerprint = self.device_manager.get_fingerprint()
        drive_id_hardware = self.device_manager.get_drive_id_hardware()
        if not self.drive_id:
            self.drive_id = self.device_manager.get_drive_id()

        _tampered = self.device_manager._tampered
        _tampered_value = self.device_manager._tampered_value

        if not self.drive_id:
            console.print("\n  [cyan]🔄 Memeriksa status paket...[/cyan]")
            try:
                probe_resp = self.client.login(
                    self.username,
                    self.password,
                    drive_id=None,
                    device_uuid=device_uuid,
                    device_token=device_token,
                    device_fingerprint=device_fingerprint,
                    drive_id_hardware=drive_id_hardware,
                    drive_id_tampered=_tampered,
                    drive_id_original=_tampered_value,
                    raise_on_error=True,
                    raise_on_plan_issue=False,
                )
                self._update_token(probe_resp)
                self.save_credentials(self.username, self.password)
                if probe_resp.status in ("new_user", "existing_no_plan", "plan_inactive", "plan_expired", "payment_required", "drive_required"):
                    if probe_resp.status != "drive_required":
                        self.handle_response(probe_resp)
                        return
            except DriveException as e:
                self._update_token(e.response)
                if not (e.response and e.response.status == "missing_drive_id"):
                    self._handle_login_error(e)
                    return
            except Exception as e:
                self._handle_login_error(e)
                return
            self.drive_id = self.device_manager.create_drive_id(interactive=True)

        console.print(f"[dim]  Using Drive ID      : {self.drive_id}[/dim]")
        console.print("\n[cyan]  🔄 Menghubungi server...[/cyan]\n")
        try:
            device_token = self.device_manager.get_device_token()
            self.response = self.client.login(
                self.username,
                self.password,
                self.drive_id,
                device_uuid=device_uuid,
                device_token=device_token,
                device_fingerprint=device_fingerprint,
                drive_id_hardware=drive_id_hardware,
                drive_id_tampered=_tampered,
                drive_id_original=_tampered_value,
                raise_on_error=True,
                raise_on_plan_issue=False,
            )
            self._update_token(self.response)
            self.save_credentials(self.username, self.password)
            if self.response.status == "success":
                self.start_heartbeat_loop()
            self.handle_response(self.response)

        except DriveException as e:
            if e.response and e.response.status == "drive_not_found":
                console.print("\n  [yellow]⚠️  Drive ID ini belum terdaftar di server.[/yellow]")
                if Confirm.ask("  ➤ Daftar otomatis sekarang?", default=True):
                    self._do_register_drive()
                    return
                else:
                    console.print(f"  [yellow]ℹ️  Daftarkan ID ini via Web Dashboard.\n      ID: [bold]{self.drive_id}[/bold][/yellow]\n")
                    Prompt.ask("  [dim]Tekan Enter untuk kembali ke menu utama...[/dim]")
                    return
            if e.response and e.response.status == "drive_mismatch":
                self.handle_response(e.response)
                return
            self._handle_login_error(e)
        except AuthenticationException as e:
            self._update_token(e.response)
            self.delete_credentials()
            self._handle_login_error(e)
            self.username, self.password = None, None
        except APIException as e:
            self._update_token(e.response)
            self._handle_login_error(e)

    def _update_token(self, response):
        if not response or not response.raw:
            return
        token = None
        if isinstance(response.raw.get("data"), dict):
            token = response.raw["data"].get("device_token")
        if not token:
            token = response.raw.get("device_token")
        if token:
            self.device_manager.save_device_token(token)

    def _do_register_drive(self):
        console.print("\n  [cyan]🔄 Mendaftarkan Drive ID...[/cyan]")
        try:
            resp = self.client.register_drive(
                self.username,
                self.password,
                self.drive_id,
                device_uuid=self.device_manager.get_device_uuid(),
                device_token=self.device_manager.get_device_token(),
                device_fingerprint=self.device_manager.get_fingerprint(),
            )
            console.print(f"  [green]✅ {resp.message}[/green]")
            time.sleep(1)
            console.print("\n  [cyan]🔄 Login ulang...[/cyan]")
            self.do_login(interactive=False)
        except APIException as e:
            console.print(f"\n  [red]❌ Gagal mendaftar: {e}[/red]")
            Prompt.ask("  [dim]Tekan Enter untuk kembali...[/dim]")

    def _handle_login_error(self, e):
        status = e.response.status if hasattr(e, 'response') and e.response else None
        device_errors = {
            "device_info_missing": "Identitas perangkat tidak lengkap. UUID tidak ditemukan — coba login ulang atau hubungi admin.",
            "device_token_missing": "Perangkat baru terdeteksi. Token sesi hilang (mungkin akibat reinstall / hapus data).\n  ➜ Hubungi admin untuk reset perangkat.",
            "device_mismatch": "Akun ini tertaut dengan perangkat lain. Hubungi Admin untuk RESET DEVICE.",
            "device_token_invalid": "Sesi perangkat kadaluarsa. Silakan login ulang.",
            "device_already_used": "Perangkat ini sudah digunakan akun lain. Hubungi admin jika ini kesalahan.",
            "fingerprint_mismatch": "Keamanan perangkat berubah (update OS / root?). Hubungi Admin untuk reset.",
            "device_reset_required": "Perangkat tidak dikenali (UUID & token tidak cocok).\n  ➜ Hubungi Admin untuk RESET DEVICE.",
        }
        if status in device_errors:
            _header("DEVICE SECURITY", "🔒")
            console.print(f"\n  [red]❌ {device_errors[status]}[/red]\n")
        else:
            console.print(f"\n  [red]❌ Error: {e}[/red]\n")
        Prompt.ask("  [dim]Tekan Enter untuk kembali ke menu utama...[/dim]")

    def handle_response(self, response):
        MAP = {
            "success": self.dashboard_menu,
            "new_user": self.show_new_user_menu,
            "existing_no_plan": self.show_no_plan_menu,
            "plan_inactive": self.show_plan_issue_menu,
            "plan_expired": self.show_plan_issue_menu,
            "payment_required": self.show_payment_required_menu,
            "drive_required": self.show_drive_required_menu,
            "limit_reached": self.show_limit_reached_menu,
            "drive_mismatch": self.show_drive_mismatch_menu,
            "multi_device": self.show_multi_device_menu,
            "multi_device_detected": self.show_multi_device_detected_menu,
        }
        handler = MAP.get(response.status)
        if handler:
            handler(response)
        else:
            _header("TERJADI KESALAHAN", "❌")
            console.print(f"\n  [red]Status  : {response.status}[/red]\n  [red]Pesan   : {response.message}[/red]\n")
            Prompt.ask("  [dim]Tekan Enter untuk kembali...[/dim]")

    def main_menu(self):
        while True:
            _header("MAIN MENU", "🏠")
            console.print(
                "  [bold][1][/bold] 🔑 Login\n"
                "  [bold][2][/bold] ⚙️  Config Info\n"
                "  [bold][3][/bold] ℹ️  About\n"
                "  [bold][4][/bold] 🚪 Exit\n"
            )
            c = Prompt.ask("  ➤ Pilihan kamu", choices=["1", "2", "3", "4"], default="1")
            if c == "1":
                self.do_login()
            elif c == "2":
                self.show_config_info()
            elif c == "3":
                self.show_about()
            elif c == "4":
                sys.exit(0)

    def dashboard_menu(self, response):
        while True:
            _header("DASHBOARD", "✅")
            u, plan = response.user_details, response.plan_info
            if u:
                console.print(f"  👤 User: [bold]{u.username}[/bold]")
            if plan:
                console.print(f"  📋 Plan: [bold]{plan.plan_name}[/bold] ([green]Active[/green])")
            console.print(
                "\n  [bold][1][/bold] 👤 Show All Info\n"
                "  [bold][2][/bold] 🔄 Refresh Data\n"
                "  [bold][3][/bold] 🌟 Menu Plan\n"
                "  [bold][4][/bold] 🚪 Exit App\n"
            )
            c = Prompt.ask("  ➤ Pilihan kamu", choices=["1", "2", "3", "4"], default="1")
            if c == "1":
                self.show_full_dashboard(response)
            elif c == "2":
                self.do_login(interactive=False)
                return
            elif c == "3":
                self.show_plan_features_menu(response)
            elif c == "4":
                self.stop_heartbeat_loop()
                sys.exit(0)

    def show_full_dashboard(self, response):
        _header("FULL INFO", "📊")
        u, d, p = response.user_details, response.drive_details, response.plan_info
        console.print("\n  [cyan][bold]👤 INFO AKUN[/bold][/cyan]")
        if u:
            _field("Username", u.username, "👤")
            _field("Email", u.email, "📧")
            _field("UUID", u.uuid, "🆔")
            _field("Tipe", u.user_type, "🏷️")
            _field("Dibuat", u.account_created, "📅")
            _field("Login Terakhir", u.last_login, "🕐")
        console.print("\n  [cyan][bold]💾 INFO DRIVE[/bold][/cyan]")
        if d:
            _field("Drive ID", d.drive_id, "💾")
            _field("Status", d.status, "📶")
            _field("Terakhir Dipakai", d.last_used, "🕐")
        console.print("\n  [cyan][bold]📋 INFO PLAN[/bold][/cyan]")
        if p:
            _field("Nama Plan", p.plan_name, "📋")
            _field("Aktif", "Ya" if p.is_active else "Tidak", "✅")
            _field("Expired", p.expiry_date, "📅")
            _field("Max Drive", p.max_drive, "💾")
            _field("Sisa Waktu", f"{p.remaining_days}h {p.remaining_hours}j {p.remaining_minutes}m", "⏳")
        Prompt.ask("\n  [dim]Tekan Enter untuk kembali...[/dim]")

    def show_plan_features_menu(self, response):
        plan_info = response.plan_info
        user_level = self.PLAN_LEVELS.get(plan_info.plan_name if plan_info else "", 0)
        while True:
            _header(f"MENU {plan_info.plan_name.upper() if plan_info else 'PLAN'}", "🌟")
            for i, f in enumerate(self.PLAN_FEATURES, 1):
                if user_level >= f["min_level"]:
                    console.print(f"  [bold][{i}][/bold] ✅ {f['name']} [dim]({f['desc']})[/dim]")
                else:
                    console.print(f"  [bold][{i}][/bold] 🔒 {f['name']} [red](Locked)[/red]")
            console.print(f"\n  [bold][{len(self.PLAN_FEATURES)+1}][/bold] 🔙 Kembali\n")
            c = Prompt.ask(
                "  ➤ Pilihan kamu",
                choices=[str(i) for i in range(1, len(self.PLAN_FEATURES) + 2)],
                default=str(len(self.PLAN_FEATURES) + 1)
            )
            if c == str(len(self.PLAN_FEATURES) + 1):
                return
            f = self.PLAN_FEATURES[int(c) - 1]
            if user_level >= f["min_level"]:
                console.print(f"\n  [green]✨ Akses Diberikan: {f['name']}[/green]")
            else:
                console.print(f"\n  [red]⛔ Akses Ditolak![/red]")
            Prompt.ask("  [dim]Tekan Enter...[/dim]")

    def show_payment_required_menu(self, response):
        AUTO_INTERVAL = 30
        active_event = self.start_auto_detect(interval=AUTO_INTERVAL)
        try:
            while True:
                _header("MENUNGGU PEMBAYARAN", "💰")
                console.print(f"\n  [yellow]⚠️  {response.message}[/yellow]")
                console.print(
                    "\n  [bold][1][/bold] 📞 Hubungi Admin\n"
                    "  [bold][2][/bold] 🔄 Refresh Manual\n"
                    "  [bold][3][/bold] 🚪 Keluar\n"
                )
                c = self._wait_for_input_or_event("  ➤ Pilihan", ["1", "2", "3"], active_event, AUTO_INTERVAL)
                if c == "__ACTIVE__":
                    self.stop_auto_detect(active_event)
                    console.print("\n\n  [bold green]🎉 PAKET AKTIF! Redirect ke Dashboard...[/bold green]")
                    time.sleep(1.5)
                    self.dashboard_menu(self.response)
                    return
                elif c == "1":
                    console.print("\n  WhatsApp: +628123456789\n  Telegram: @admin_support")
                    Prompt.ask("\n  [dim]Enter...[/dim]")
                elif c == "2":
                    self.stop_auto_detect(active_event)
                    self.do_login(interactive=False)
                    return
                elif c == "3":
                    self.stop_auto_detect(active_event)
                    sys.exit(0)
        except Exception:
            self.stop_auto_detect(active_event)
            raise

    def show_drive_required_menu(self, response):
        while True:
            _header("AKTIVASI DRIVE", "💾")
            console.print(f"\n  [cyan]ℹ️  {response.message}[/cyan]")
            console.print(
                "\n  [bold][1][/bold] 💾 Daftarkan Drive ID Sekarang\n"
                "  [bold][2][/bold] 🔄 Refresh\n"
                "  [bold][3][/bold] 🚪 Keluar\n"
            )
            c = Prompt.ask("  ➤ Pilihan", choices=["1", "2", "3"], default="1")
            if c == "1":
                if not self.drive_id:
                    self.drive_id = self.device_manager.create_drive_id(interactive=True)
                self._do_register_drive()
                return
            elif c == "2":
                self.do_login(interactive=False)
                return
            elif c == "3":
                sys.exit(0)

    def show_new_user_menu(self, response):
        AUTO_INTERVAL = 30
        active_event = self.start_auto_detect(interval=AUTO_INTERVAL)
        try:
            while True:
                _header("AKUN BARU", "👋")
                show_available_plans(response.plan_details)
                console.print(
                    "\n  [bold][1][/bold] 📞 Cara Aktivasi\n"
                    "  [bold][2][/bold] 🔄 Refresh Manual\n"
                    "  [bold][3][/bold] 🚪 Keluar\n"
                )
                c = self._wait_for_input_or_event("  ➤ Pilihan", ["1", "2", "3"], active_event, AUTO_INTERVAL)
                if c == "__ACTIVE__":
                    self.stop_auto_detect(active_event)
                    console.print("\n\n  [bold green]🎉 PAKET AKTIF! Redirect ke Dashboard...[/bold green]")
                    time.sleep(1.5)
                    self.dashboard_menu(self.response)
                    return
                elif c == "1":
                    console.print("\n  Hubungi admin untuk membeli paket.")
                    Prompt.ask("\n  [dim]Enter...[/dim]")
                elif c == "2":
                    self.stop_auto_detect(active_event)
                    self.do_login(interactive=False)
                    return
                elif c == "3":
                    self.stop_auto_detect(active_event)
                    sys.exit(0)
        except Exception:
            self.stop_auto_detect(active_event)
            raise

    def show_no_plan_menu(self, response):
        self.show_new_user_menu(response)

    def show_plan_issue_menu(self, response):
        AUTO_INTERVAL = 30
        active_event = self.start_auto_detect(interval=AUTO_INTERVAL)
        try:
            while True:
                _header("MASALAH PAKET", "⚠️")
                console.print(f"\n  [red]⚠️  {response.message}[/red]")
                console.print(
                    "\n  [bold][1][/bold] 📋 Lihat Plan\n"
                    "  [bold][2][/bold] 🔄 Refresh Manual\n"
                    "  [bold][3][/bold] 🚪 Keluar\n"
                )
                c = self._wait_for_input_or_event("  ➤ Pilihan", ["1", "2", "3"], active_event, AUTO_INTERVAL)
                if c == "__ACTIVE__":
                    self.stop_auto_detect(active_event)
                    console.print("\n\n  [bold green]🎉 PAKET AKTIF! Redirect ke Dashboard...[/bold green]")
                    time.sleep(1.5)
                    self.dashboard_menu(self.response)
                    return
                elif c == "1":
                    show_available_plans(response.plan_details)
                    Prompt.ask("\n  [dim]Enter...[/dim]")
                elif c == "2":
                    self.stop_auto_detect(active_event)
                    self.do_login(interactive=False)
                    return
                elif c == "3":
                    self.stop_auto_detect(active_event)
                    sys.exit(0)
        except Exception:
            self.stop_auto_detect(active_event)
            raise

    def show_limit_reached_menu(self, response):
        AUTO_INTERVAL = 30
        active_event = self.start_auto_detect(interval=AUTO_INTERVAL)
        try:
            while True:
                _header("BATAS DRIVE TERCAPAI", "🚫")
                console.print(f"\n  [red]⚠️  {response.message}[/red]")
                console.print(
                    "\n  [dim]Akun ini sudah dipakai di jumlah drive maksimal.[/dim]"
                    "\n  [dim]Hubungi admin untuk reset drive lama atau upgrade plan.[/dim]"
                )
                console.print(
                    "\n  [bold][1][/bold] 📞 Hubungi Admin\n"
                    "  [bold][2][/bold] 🔄 Refresh Manual\n"
                    "  [bold][3][/bold] 🚪 Keluar\n"
                )
                c = self._wait_for_input_or_event("  ➤ Pilihan", ["1", "2", "3"], active_event, AUTO_INTERVAL)
                if c == "__ACTIVE__":
                    self.stop_auto_detect(active_event)
                    console.print("\n\n  [bold green]🎉 AKSES DIBERIKAN! Redirect ke Dashboard...[/bold green]")
                    time.sleep(1.5)
                    self.dashboard_menu(self.response)
                    return
                elif c == "1":
                    console.print("\n  WhatsApp: +628123456789\n  Telegram: @admin_support")
                    Prompt.ask("\n  [dim]Enter...[/dim]")
                elif c == "2":
                    self.stop_auto_detect(active_event)
                    self.do_login(interactive=False)
                    return
                elif c == "3":
                    self.stop_auto_detect(active_event)
                    sys.exit(0)
        except Exception:
            self.stop_auto_detect(active_event)
            raise

    def show_drive_mismatch_menu(self, response):
        AUTO_INTERVAL = 30
        active_event = self.start_auto_detect(interval=AUTO_INTERVAL)
        try:
            while True:
                _header("DRIVE ID TIDAK COCOK", "🔒")
                console.print(f"\n  [red]⚠️  {response.message}[/red]")
                console.print(
                    "\n  [dim]Drive ID perangkat ini tidak sesuai dengan yang terdaftar[/dim]"
                    "\n  [dim]di server untuk akun kamu.[/dim]"
                    "\n\n  [dim]Kemungkinan penyebab:[/dim]"
                    "\n  [dim]  • Akun pernah login di perangkat lain[/dim]"
                    "\n  [dim]  • Drive ID lama masih terdaftar di server[/dim]"
                    "\n  [dim]  • Hubungi admin untuk RESET DRIVE[/dim]"
                )
                console.print(
                    "\n  [bold][1][/bold] 📞 Hubungi Admin (Reset Drive)\n"
                    "  [bold][2][/bold] 🔄 Refresh Manual\n"
                    "  [bold][3][/bold] 🚪 Keluar\n"
                )
                c = self._wait_for_input_or_event("  ➤ Pilihan", ["1", "2", "3"], active_event, AUTO_INTERVAL)
                if c == "__ACTIVE__":
                    self.stop_auto_detect(active_event)
                    console.print("\n\n  [bold green]🎉 DRIVE DIRESET! Redirect ke Dashboard...[/bold green]")
                    time.sleep(1.5)
                    self.dashboard_menu(self.response)
                    return
                elif c == "1":
                    console.print(
                        f"\n  [bold]Drive ID kamu:[/bold] [cyan]{self.drive_id}[/cyan]"
                        "\n  Kirimkan ID ini ke admin untuk reset."
                        "\n\n  WhatsApp: +628123456789\n  Telegram: @admin_support"
                    )
                    Prompt.ask("\n  [dim]Enter...[/dim]")
                elif c == "2":
                    self.stop_auto_detect(active_event)
                    self.do_login(interactive=False)
                    return
                elif c == "3":
                    self.stop_auto_detect(active_event)
                    sys.exit(0)
        except Exception:
            self.stop_auto_detect(active_event)
            raise

    def show_multi_device_menu(self, response):
        _header("MULTI-DEVICE TERDETEKSI", "🚨")
        console.print(f"\n  [red]⚠️  {response.message}[/red]")
        console.print(
            "\n  [dim]Aktivitas mencurigakan terdeteksi pada akun ini.[/dim]"
            "\n  [dim]Kemungkinan penyebab:[/dim]"
            "\n  [dim]  • Credentials digunakan di lebih dari 1 perangkat[/dim]"
            "\n  [dim]  • UUID atau token dimanipulasi[/dim]"
            "\n  [dim]  • Hardware perangkat berbeda dari yang terdaftar[/dim]"
        )
        console.print(
            "\n  [bold][1][/bold] 📞 Hubungi Admin\n"
            "  [bold][2][/bold] 🚪 Keluar\n"
        )
        c = Prompt.ask("  ➤ Pilihan", choices=["1", "2"], default="2")
        if c == "1":
            console.print(
                f"\n  [bold]Drive ID kamu:[/bold] [cyan]{self.drive_id}[/cyan]"
                "\n  Kirimkan info ini ke admin untuk investigasi."
                "\n\n  WhatsApp: +628123456789\n  Telegram: @admin_support"
            )
            Prompt.ask("\n  [dim]Enter...[/dim]")
        sys.exit(0)

    def show_multi_device_detected_menu(self, response):
        drive_id_correct = None
        if response.raw:
            drive_id_correct = response.raw.get("data", {}).get("drive_id_correct")

        _header("DRIVE ID DIPERBARUI", "🔄")
        console.print(f"\n  [red]⚠️  {response.message}[/red]")

        if drive_id_correct:
            self.device_manager.save_drive_id(drive_id_correct)
            self.drive_id = drive_id_correct
            console.print(
                f"\n  [yellow]Drive ID lokal telah diperbarui ke nilai hardware:[/yellow]"
                f"\n  [bold cyan]  {drive_id_correct}[/bold cyan]"
                "\n\n  [dim]Silakan coba login kembali.[/dim]"
            )
            console.print(
                "\n  [bold][1][/bold] 🔄 Coba Login Ulang\n"
                "  [bold][2][/bold] 🚪 Keluar\n"
            )
            c = Prompt.ask("  ➤ Pilihan", choices=["1", "2"], default="1")
            if c == "1":
                self.do_login(interactive=False)
                return
            else:
                sys.exit(0)
        else:
            console.print("\n  [dim]Tidak ada Drive ID pengganti dari server.[/dim]")
            Prompt.ask("\n  [dim]Enter...[/dim]")

    def show_config_info(self):
        while True:
            _header("CONFIG", "⚙️")
            _field("Base URL", self.url)
            _field("Drive ID", self.drive_id or "Not Set")
            _field("UUID", self.device_manager.get_device_uuid())
            console.print(
                "\n  [bold][1][/bold] ✏️  Ubah Base URL\n"
                "  [bold][2][/bold] 🔌 Test Koneksi\n"
                "  [bold][3][/bold] 🔙 Kembali\n"
            )
            c = Prompt.ask("  ➤ Pilihan", choices=["1", "2", "3"], default="3")
            if c == "1":
                new_url = Prompt.ask("  ➤ Masukkan Base URL baru", default=self.url).strip()
                if new_url:
                    self.url = new_url
                    self._config.base_url = new_url
                    self._config.save()
                    self.client = create_client(base_url=self.url, api_key=self.api_key)
                    console.print("  [green]✅ URL disimpan ke config.json[/green]")
                time.sleep(1)
            elif c == "2":
                console.print("  [cyan]🔄 Test koneksi...[/cyan]")
                try:
                    import requests as req
                    r = req.get(self.url, timeout=5, headers={"User-Agent": "Mozilla/5.0"})
                    console.print(f"  [green]✅ Server merespons: HTTP {r.status_code}[/green]")
                except Exception as ex:
                    console.print(f"  [red]❌ Gagal: {ex}[/red]")
                Prompt.ask("\n  [dim]Enter...[/dim]")
            elif c == "3":
                return

    def show_about(self):
        _header("ABOUT", "ℹ️")
        console.print(
            "\n  Client Version : v0.5.0\n"
            "  Description    : GabungV2 Multi-Stage Activation Client\n\n"
            "  [bold]Changelog v0.5.0:[/bold]\n"
            "  • NEW: Drive ID + Device Binding Matrix Check\n"
            "    Generate vs Server → File vs Server → UUID + Token\n"
            "  • NEW: drive_id_hardware dikirim ke server setiap login\n"
            "  • NEW: status multi_device → layar keamanan + opsi admin\n"
            "  • NEW: status multi_device_detected → overwrite device_id.txt + retry\n"
            "  • NEW: status device_reset_required → pesan khusus\n\n"
            "  [bold]Changelog v0.4.0:[/bold]\n"
            "  • FIX KRITIS: get_drive_id() tidak lagi override device_id.txt\n"
            "  • Sebelumnya: file di-reset ke Drive ID hardware → merusak use case\n"
            "    copy data dari HP lama ke HP baru (Drive ID lama terdaftar di server,\n"
            "    Drive ID hardware baru belum → drive_not_found loop)\n"
            "  • Sekarang: nilai file TETAP dipakai; server yang validasi final\n"
            "  • Tamper flag tetap dikirim ke server sebagai info admin\n"
            "  • _tampered_value kini = Drive ID hardware (sebelumnya = Drive ID file)\n\n"
            "  [bold]Changelog v0.3.9:[/bold]\n"
            "  • FIX: Handler khusus HTTP 500 di _post()\n"
            "  • Pesan error 500 kini jelas: server error / db down / konfigurasi server\n\n"
            "  [bold]Changelog v0.3.8:[/bold]\n"
            "  • FIX: save_credentials dipanggil segera setelah login berhasil\n"
            "  • Sebelumnya hanya tersimpan jika status == 'success'\n"
            "  • Sekarang: semua status valid (new_user, plan_inactive, limit_reached, dll)\n"
            "    → credentials langsung disimpan\n\n"
            "  [bold]Changelog v0.3.7:[/bold]\n"
            "  • Auto-deteksi tamper pada device_id.txt\n"
            "  • Flag tamper dikirim ke server → notif Telegram admin\n"
            "  • _log_tamper() simpan log lokal di .tamper_log\n\n"
            "  [bold]Changelog v0.3.6:[/bold]\n"
            "  • limit_reached kini punya layar tunggu + auto-detect polling 30s\n"
            "  • drive_mismatch kini punya layar tunggu + auto-detect polling 30s\n"
            "  • Keduanya otomatis redirect ke Dashboard setelah admin reset\n\n"
            "  [bold]Changelog v0.3.5:[/bold]\n"
            "  • Fix pesan error device: pisah device_info_missing vs device_token_missing\n"
            "  • device_token_missing → pesan spesifik untuk kasus reinstall HP\n"
            "  • Semua pesan error device kini lebih informatif & arahkan ke admin\n\n"
            "  [bold]Changelog v0.3.4:[/bold]\n"
            "  • Fix KRITIS: _post() selalu parse JSON dulu untuk semua HTTP error\n"
            "  • Hapus print debug yang tertinggal\n"
        )
        Prompt.ask("  [dim]Enter...[/dim]")


def main():
    try:
        app = ClientApp()
        os.system("cls" if os.name == "nt" else "clear")
        app.run()
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()