import logging
import time
from typing import Optional

import requests

from api_cli.config import APIConfig
from api_cli.exceptions import (
    APIException,
    AuthenticationException,
    DriveException,
    RateLimitException,
)
from api_cli.models import APIResponse


class APIClient:
    def __init__(self, config: APIConfig):
        if not config.base_url:
            raise ValueError("base_url tidak boleh None atau kosong")
        self.config = config
        self.session = requests.Session()
        self._setup_logging()

    def _setup_logging(self):
        self.logger = logging.getLogger("APIClient")
        level = getattr(logging, self.config.log_level.upper(), logging.INFO)
        self.logger.setLevel(level)
        if self.config.log_file and not self.logger.handlers:
            fh = logging.FileHandler(self.config.log_file)
            fh.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
            self.logger.addHandler(fh)

    def _post(self, payload: dict) -> APIResponse:
        headers = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8",
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": self.config.base_url.rsplit("/", 1)[0],
            "Referer": self.config.base_url,
            "X-Requested-With": "XMLHttpRequest",
        }
        if self.config.api_key:
            headers["X-API-KEY"] = self.config.api_key

        for attempt in range(self.config.max_retries):
            try:
                resp = self.session.post(
                    self.config.base_url,
                    data=payload,
                    headers=headers,
                    timeout=self.config.timeout,
                    verify=self.config.verify_ssl,
                )

                if not resp.ok:
                    try:
                        data = resp.json()
                        if "status" in data:
                            return APIResponse.from_dict(data)
                    except Exception:
                        pass
                    resp.raise_for_status()

                return APIResponse.from_dict(resp.json())

            except requests.exceptions.Timeout:
                if attempt < self.config.max_retries - 1:
                    time.sleep(self.config.retry_delay)
                else:
                    raise APIException("Request timeout setelah beberapa percobaan.")

            except requests.exceptions.ConnectionError:
                if attempt < self.config.max_retries - 1:
                    time.sleep(self.config.retry_delay)
                else:
                    raise APIException("Tidak dapat terhubung ke server. Pastikan server aktif.")

            except requests.exceptions.HTTPError as e:
                sc = e.response.status_code if e.response is not None else "?"
                if sc == 403:
                    raise APIException(
                        "Akses ditolak server (403 Forbidden).\n"
                        "  Kemungkinan: IP diblokir, API key salah, atau firewall server."
                    )
                if sc == 404:
                    raise APIException(
                        f"Endpoint tidak ditemukan (404 Not Found).\n"
                        f"  URL saat ini: {self.config.base_url}\n"
                        f"  → Pergi ke menu [2] Config Info → [1] Ubah Base URL"
                    )
                if sc == 500:
                    raise APIException(
                        "Server mengalami kesalahan internal (500).\n"
                        "  Kemungkinan: bug di server, database down, atau konfigurasi server bermasalah.\n"
                        "  → Hubungi admin / cek log server."
                    )
                raise APIException(f"HTTP error {sc}: {e}")

            except Exception as e:
                raise APIException(f"Error tidak terduga: {e}")

    def login(
        self,
        username: str,
        password: str,
        drive_id: Optional[str] = None,
        device_uuid: Optional[str] = None,
        device_token: Optional[str] = None,
        device_fingerprint: Optional[str] = None,
        drive_id_hardware: Optional[str] = None,
        drive_id_tampered: bool = False,
        drive_id_original: Optional[str] = None,
        raise_on_error: bool = True,
        raise_on_plan_issue: bool = True,
    ) -> APIResponse:
        payload = {"action": "login", "username": username, "password": password}
        if drive_id:
            payload["drive_id"] = drive_id
        if device_uuid:
            payload["device_uuid"] = device_uuid
        if device_token:
            payload["device_token"] = device_token
        if device_fingerprint:
            payload["device_fingerprint"] = device_fingerprint
        if drive_id_hardware:
            payload["drive_id_hardware"] = drive_id_hardware
        if drive_id_tampered:
            payload["drive_id_tampered"] = "1"
            payload["drive_id_original"] = drive_id_original or ""
        response = self._post(payload)
        if raise_on_error:
            self._raise_if_error(response)
        return response

    def register_drive(
        self,
        username: str,
        password: str,
        drive_id: str,
        device_uuid: Optional[str] = None,
        device_token: Optional[str] = None,
        device_fingerprint: Optional[str] = None,
    ) -> APIResponse:
        payload = {
            "action": "register_drive",
            "username": username,
            "password": password,
            "drive_id": drive_id,
        }
        if device_uuid:
            payload["device_uuid"] = device_uuid
        if device_token:
            payload["device_token"] = device_token
        if device_fingerprint:
            payload["device_fingerprint"] = device_fingerprint
        response = self._post(payload)
        self._raise_if_error(response)
        return response

    def heartbeat(self, username: str, drive_id: str) -> APIResponse:
        try:
            return self._post({"action": "heartbeat", "username": username, "drive_id": drive_id})
        except Exception as e:
            return APIResponse(status="error", message=str(e))

    def _raise_if_error(self, response: APIResponse) -> None:
        auth_errors = {
            "invalid_credentials",
            "missing_credentials",
            "account_inactive",
            "too_many_attempts",
        }
        drive_errors = {
            "drive_not_found",
            "drive_mismatch",
            "drive_inactive",
            "suspended",
            "banned",
            "missing_drive_id",
        }
        device_errors = {
            "device_info_missing",
            "device_token_missing",
            "device_token_invalid",
            "device_already_used",
            "fingerprint_mismatch",
            "device_reset_required",
        }
        if response.status in auth_errors:
            raise AuthenticationException(response.message, response)
        if response.status in drive_errors:
            raise DriveException(response.message, response)
        if response.status in device_errors:
            raise APIException(response.message, response)
        if response.status == "rate_limit_exceeded":
            raise RateLimitException(response.message, response)
        if response.is_error():
            raise APIException(response.message, response)


def create_client(
    base_url=None,
    api_key=None,
    timeout=30,
    verify_ssl=True,
    log_file="api_client.log",
    verbose=False,
) -> APIClient:
    cfg = APIConfig(
        base_url=base_url or APIConfig().base_url,
        api_key=api_key,
        timeout=timeout,
        verify_ssl=verify_ssl,
        log_file=log_file,
        log_level="DEBUG" if verbose else "INFO",
    )
    return APIClient(cfg)