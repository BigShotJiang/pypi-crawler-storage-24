import logging

from ..model import PyMcaXrfConfiguration

logger = logging.getLogger(__name__)


def force_fast_fitting(configuration: PyMcaXrfConfiguration):
    fit = configuration.fit

    if fit.linearfitflag != 1:
        fit.linearfitflag = 1
        logger.warning("PyMca configuration: force linear fitting")

    if fit.strategyflag:
        fit.strategyflag = 0
        logger.warning("PyMca configuration: disable fit strategy")

    if fit.stripflag and fit.stripalgorithm != 1:
        logger.warning(
            "PyMca configuration: disable background stripping (use SNIP if you want to take background into account)"
        )
        fit.stripflag = 0
