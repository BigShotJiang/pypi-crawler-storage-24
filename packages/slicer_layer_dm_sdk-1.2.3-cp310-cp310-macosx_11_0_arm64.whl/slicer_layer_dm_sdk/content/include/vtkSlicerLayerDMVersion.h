#pragma once

#include <string>

static constexpr int vtkSlicerLayerDM_VERSION_MAJOR { 1 };
static constexpr int vtkSlicerLayerDM_VERSION_MINOR { 2 };
static constexpr int vtkSlicerLayerDM_VERSION_PATCH { 3 };
static const std::string vtkSlicerLayerDM_VERSION { "1.2.3" };
