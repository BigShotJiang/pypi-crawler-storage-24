cmake_policy(PUSH)
cmake_policy(VERSION 3.12)

# CMAKE_FIND_PACKAGE_NAME:
#   name used to call this script, typically VTKSDK_PROJECT_NAME but maybe something else if a jumppad is used
# ---
# VTKSDK_PACKAGE_NAME:
#   equivalent to package_name, e.g. "basic-project"
# VTKSDK_PACKAGE_NAMESPACE:
#   equivalent to modules full namespace, e.g. "Dummy::" (with ::)
# VTKSDK_EXTERNAL_PACKAGE_DEPENDS:
#   list of given dependencies to search, only used for find_packages done without vtk_module_find_package
# VTKSDK_EXTERNAL_PACKAGE_CMAKE_PREFIX:
#   list of prefixes to look for third parties

set(slicer_layer_dm_sdk_AVAILABLE_COMPONENTS "Logic;MRML;MRMLDisplayableManager")
set(real_components)
foreach(component IN LISTS "${CMAKE_FIND_PACKAGE_NAME}_FIND_COMPONENTS")
  # Handle component requests that are not VTK.
  if(NOT component IN_LIST "slicer_layer_dm_sdk_AVAILABLE_COMPONENTS")
    set("${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND" 0)
    list(APPEND "${CMAKE_FIND_PACKAGE_NAME}_${component}_NOT_FOUND_MESSAGE"
      "The ${component} component is not recognized.")
  endif()
  list(APPEND real_components "${component}")
endforeach ()
unset(component)
set(${CMAKE_FIND_PACKAGE_NAME}_FIND_COMPONENTS ${real_components})
unset(real_components)

list(PREPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}")

set(_external_cmake_modules "")
foreach(module IN LISTS _external_cmake_modules)
  include("${CMAKE_CURRENT_LIST_DIR}/${module}")
endforeach()
unset(_external_cmake_modules)

# include targets
include("${CMAKE_CURRENT_LIST_DIR}/slicer_layer_dm_sdk-targets.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/slicer_layer_dm_sdk-vtk-module-properties.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/slicer_layer_dm_sdk-vtk-find-package-helpers.cmake" OPTIONAL)

# This defines ${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX to the install prefix of this package
get_filename_component(${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX "${CMAKE_CURRENT_LIST_FILE}" PATH)
get_filename_component(${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX "${${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX}" PATH)
get_filename_component(${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX "${${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX}" PATH)
get_filename_component(${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX "${${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX}" PATH)
get_filename_component(${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX "${${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX}" PATH)


# Add user defined prefix paths
set(_external_cmake_prefix "")
foreach(path IN LISTS _external_cmake_prefix)
  list(PREPEND CMAKE_PREFIX_PATH "${${CMAKE_FIND_PACKAGE_NAME}_INSTALL_PREFIX}/${path}")
endforeach()
unset(_external_cmake_prefix)

# Additionnal find packages
include(CMakeFindDependencyMacro)
set(_external_package_depends "Slicer")
foreach(_vtk_external_package_depend IN LISTS _external_package_depends)
  find_dependency(${_vtk_external_package_depend})
endforeach()
unset(_external_package_depends)

include("${CMAKE_CURRENT_LIST_DIR}/slicer_layer_dm_sdk-vtk-module-find-packages.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/slicer_layer_dm_sdk-vtk-python-module-properties.cmake")

set("${CMAKE_FIND_PACKAGE_NAME}_PYTHON_VERSION" "1.2.3")

# No COMPONENTS == All available COMPONENTS
set(search_components ${${CMAKE_FIND_PACKAGE_NAME}_FIND_COMPONENTS})
if(NOT search_components)
  set(search_components ${${CMAKE_FIND_PACKAGE_NAME}_AVAILABLE_COMPONENTS})
endif()

# Verify every module asked and their dependencies exists at this point!
set(components_to_check)
foreach(component IN LISTS search_components)
  if(DEFINED "${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND")
    # It was already not-found (likely due to `find-package` failures).
  elseif(TARGET "SlicerLayerDM::${component}")
    list(APPEND components_to_check "${component}")
  else()
    set("${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND" 0)
    list(APPEND "${CMAKE_FIND_PACKAGE_NAME}_${component}_NOT_FOUND_MESSAGE"
      "The ${component} component is not available.")
  endif()
endforeach()
unset(component)
unset(search_components)

while(components_to_check)
  list(GET components_to_check 0 component)
  list(REMOVE_AT components_to_check 0)
  if(DEFINED "${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND")
    # We've already made a determiniation.
    continue()
  endif()

  get_property(public_dependencies
    TARGET    "SlicerLayerDM::${component}"
    PROPERTY  "INTERFACE_vtk_module_depends")
  get_property(private_dependencies
    TARGET    "SlicerLayerDM::${component}"
    PROPERTY  "INTERFACE_vtk_module_private_depends")
  get_property(optional_dependencies
    TARGET    "SlicerLayerDM::${component}"
    PROPERTY  "INTERFACE_vtk_module_optional_depends")
  set(dependencies ${public_dependencies} ${private_dependencies})
  foreach(optional_dependency IN LISTS optional_dependencies)
    if(TARGET "${optional_dependency}")
      list(APPEND dependencies "${optional_dependency}")
    endif()
  endforeach()
  unset(public_dependencies)
  unset(private_dependencies)
  unset(optional_dependency)
  unset(optional_dependencies)

  string(REPLACE "SlicerLayerDM::" "" dependencies "${dependencies}")
  set(all_dependencies_checked TRUE)
  foreach(dependency IN LISTS dependencies)
    if(DEFINED "${CMAKE_FIND_PACKAGE_NAME}_${dependency}_FOUND")
      if(NOT ${CMAKE_FIND_PACKAGE_NAME}_${dependency}_FOUND)
        set("${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND" 0)
        list(APPEND "${CMAKE_FIND_PACKAGE_NAME}_${component}_NOT_FOUND_MESSAGE"
          "Failed to find the ${dependency} component.")
      endif()
    else()
      # Check its dependencies.
      list(APPEND components_to_check "${dependency}")
      set(all_found FALSE)
    endif()
  endforeach()
  if(NOT DEFINED "${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND")
    if(all_dependencies_checked)
      set("${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND" 1)
    else()
      list(APPEND components_to_check "${component}")
    endif()
  endif()
  unset(all_dependencies_checked)
  unset(dependency)
  unset(dependencies)
endwhile ()
unset(component)
unset(components_to_check)

set(missing_components)
foreach(component IN LISTS "${CMAKE_FIND_PACKAGE_NAME}_FIND_COMPONENTS")
  if(NOT ${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND AND ${CMAKE_FIND_PACKAGE_NAME}_FIND_REQUIRED_${component})
    list(APPEND missing_components "${component}")
  endif()
endforeach()

if (missing_components)
  list(REMOVE_DUPLICATES missing_components)
  list(SORT missing_components)
  string(REPLACE ";" ", " missing_components "${missing_components}")
  set("${CMAKE_FIND_PACKAGE_NAME}_FOUND" 0)
  set("${CMAKE_FIND_PACKAGE_NAME}_NOT_FOUND_MESSAGE"
    "Could not find the ${CMAKE_FIND_PACKAGE_NAME} package with the following required components: ${missing_components}.")
endif ()
unset(missing_components)

set("${CMAKE_FIND_PACKAGE_NAME}_LIBRARIES")
if(NOT DEFINED "${CMAKE_FIND_PACKAGE_NAME}_FOUND")
  # If nothing went wrong, we've successfully found the package.
  set("${CMAKE_FIND_PACKAGE_NAME}_FOUND" 1)
  set(found_components ${${CMAKE_FIND_PACKAGE_NAME}_FIND_COMPONENTS})
  if(NOT found_components)
    set(found_components ${${CMAKE_FIND_PACKAGE_NAME}_AVAILABLE_COMPONENTS})
  endif()
  # Build the `_LIBRARIES` variable.
  foreach(component IN LISTS found_components)
    if(TARGET SlicerLayerDM::${component})
      list(APPEND ${CMAKE_FIND_PACKAGE_NAME}_LIBRARIES SlicerLayerDM::${component})
    endif()
  endforeach()
  unset(component)
  unset(found_components)
endif ()

cmake_policy(POP)
