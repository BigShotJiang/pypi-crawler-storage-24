"""Agent execution framework for Wafer.

Full agent framework for tool-use and multi-turn interactions.
Uses lazy imports so submodules can be imported without pulling in all dependencies.
"""

import importlib
from typing import TYPE_CHECKING

# For type checkers, import everything eagerly
if TYPE_CHECKING:
    from wafer.core.dtypes import (
        Actor,
        AgentCheckpoint,
        AgentSession,
        AgentState,
        ChatCompletion,
        Choice,
        ContentBlock,
        Endpoint,
        Environment,
        EnvironmentConfig,
        ImageContent,
        Logprob,
        Logprobs,
        Message,
        Metric,
        RunConfig,
        Sample,
        Score,
        ScoreFn,
        SessionStatus,
        StopReason,
        TextContent,
        ThinkingContent,
        Tool,
        ToolCall,
        ToolCallContent,
        ToolConfirmResult,
        ToolFormatter,
        ToolFunction,
        ToolFunctionParameter,
        ToolResult,
        Trajectory,
        Usage,
        default_confirm_tool,
    )

    from .agent_session import AgentSessionConfig, AgentSessionResult, run_agent_session
    from .agents import (
        confirm_tool_with_feedback,
        handle_stop_max_turns,
        handle_tool_error,
        inject_tool_reminder,
        inject_turn_warning,
        rollout,
        run_agent,
        stdout_handler,
    )
    from .models import (
        ApiType,
        ModelCost,
        ModelMetadata,
        Provider,
        get_api_type,
        get_model,
    )
    from .providers import (
        get_provider_function,
        rollout_anthropic,
        rollout_google,
        rollout_openai,
        rollout_openai_responses,
        rollout_sglang,
    )
    from .store import FileSessionStore, SessionStore, SupabaseSessionStore, generate_session_id
    from .transform_messages import transform_messages


# Lazy import mappings: attribute -> (module, name)
_LAZY_IMPORTS = {
    # agent_session
    "AgentSessionConfig": (".agent_session", "AgentSessionConfig"),
    "AgentSessionResult": (".agent_session", "AgentSessionResult"),
    "run_agent_session": (".agent_session", "run_agent_session"),
    # agents
    "confirm_tool_with_feedback": (".agents", "confirm_tool_with_feedback"),
    "handle_stop_max_turns": (".agents", "handle_stop_max_turns"),
    "handle_tool_error": (".agents", "handle_tool_error"),
    "inject_tool_reminder": (".agents", "inject_tool_reminder"),
    "inject_turn_warning": (".agents", "inject_turn_warning"),
    "rollout": (".agents", "rollout"),
    "run_agent": (".agents", "run_agent"),
    "stdout_handler": (".agents", "stdout_handler"),
    # store
    "FileSessionStore": (".store", "FileSessionStore"),
    "SessionStore": (".store", "SessionStore"),
    "SupabaseSessionStore": (".store", "SupabaseSessionStore"),
    "generate_session_id": (".store", "generate_session_id"),
    # dtypes
    "Actor": ("wafer.core.dtypes", "Actor"),
    "AgentSession": ("wafer.core.dtypes", "AgentSession"),
    "AgentState": ("wafer.core.dtypes", "AgentState"),
    "ChatCompletion": ("wafer.core.dtypes", "ChatCompletion"),
    "Choice": ("wafer.core.dtypes", "Choice"),
    "ContentBlock": ("wafer.core.dtypes", "ContentBlock"),
    "Endpoint": ("wafer.core.dtypes", "Endpoint"),
    "Environment": ("wafer.core.dtypes", "Environment"),
    "EnvironmentConfig": ("wafer.core.dtypes", "EnvironmentConfig"),
    "ImageContent": ("wafer.core.dtypes", "ImageContent"),
    "Logprob": ("wafer.core.dtypes", "Logprob"),
    "Logprobs": ("wafer.core.dtypes", "Logprobs"),
    "Message": ("wafer.core.dtypes", "Message"),
    "RunConfig": ("wafer.core.dtypes", "RunConfig"),
    "SessionStatus": ("wafer.core.dtypes", "SessionStatus"),
    "StopReason": ("wafer.core.dtypes", "StopReason"),
    "AgentCheckpoint": ("wafer.core.dtypes", "AgentCheckpoint"),
    "TextContent": ("wafer.core.dtypes", "TextContent"),
    "ThinkingContent": ("wafer.core.dtypes", "ThinkingContent"),
    "Tool": ("wafer.core.dtypes", "Tool"),
    "ToolCall": ("wafer.core.dtypes", "ToolCall"),
    "ToolCallContent": ("wafer.core.dtypes", "ToolCallContent"),
    "ToolConfirmResult": ("wafer.core.dtypes", "ToolConfirmResult"),
    "ToolFormatter": ("wafer.core.dtypes", "ToolFormatter"),
    "ToolFunction": ("wafer.core.dtypes", "ToolFunction"),
    "ToolFunctionParameter": ("wafer.core.dtypes", "ToolFunctionParameter"),
    "ToolResult": ("wafer.core.dtypes", "ToolResult"),
    "Trajectory": ("wafer.core.dtypes", "Trajectory"),
    "Usage": ("wafer.core.dtypes", "Usage"),
    "default_confirm_tool": ("wafer.core.dtypes", "default_confirm_tool"),
    # Evaluation types
    "Metric": ("wafer.core.dtypes", "Metric"),
    "Score": ("wafer.core.dtypes", "Score"),
    "Sample": ("wafer.core.dtypes", "Sample"),
    "ScoreFn": ("wafer.core.dtypes", "ScoreFn"),
    # models
    "ApiType": (".models", "ApiType"),
    "ModelCost": (".models", "ModelCost"),
    "ModelMetadata": (".models", "ModelMetadata"),
    "Provider": (".models", "Provider"),
    "get_api_type": (".models", "get_api_type"),
    "get_model": (".models", "get_model"),
    # providers
    "get_provider_function": (".providers", "get_provider_function"),
    "rollout_anthropic": (".providers", "rollout_anthropic"),
    "rollout_google": (".providers", "rollout_google"),
    "rollout_openai": (".providers", "rollout_openai"),
    "rollout_openai_responses": (".providers", "rollout_openai_responses"),
    "rollout_sglang": (".providers", "rollout_sglang"),
    # transform_messages
    "transform_messages": (".transform_messages", "transform_messages"),
}


def __getattr__(name: str) -> object:
    """Lazy import attributes on first access."""
    if name in _LAZY_IMPORTS:
        module_name, attr_name = _LAZY_IMPORTS[name]
        module = importlib.import_module(module_name, __package__)
        return getattr(module, attr_name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Agent session
    "AgentSessionConfig",
    "AgentSessionResult",
    "run_agent_session",
    # Core types
    "Endpoint",
    "Actor",
    "AgentState",
    "RunConfig",
    "Environment",
    "Usage",
    "Logprob",
    "Logprobs",
    "Choice",
    "ChatCompletion",
    # Message types
    "Message",
    "ToolCall",
    "ToolResult",
    "Trajectory",
    # ContentBlock types
    "ContentBlock",
    "TextContent",
    "ThinkingContent",
    "ToolCallContent",
    "ImageContent",
    # Tool types
    "Tool",
    "ToolFunction",
    "ToolFunctionParameter",
    "ToolFormatter",
    "StopReason",
    "ToolConfirmResult",
    # Stream handling
    "AgentCheckpoint",
    "stdout_handler",
    # Agent execution
    "run_agent",
    "rollout",
    # Tool handlers
    "confirm_tool_with_feedback",
    "handle_tool_error",
    "inject_turn_warning",
    "handle_stop_max_turns",
    "inject_tool_reminder",
    "default_confirm_tool",
    # Sessions
    "SessionStore",
    "FileSessionStore",
    "SupabaseSessionStore",
    "generate_session_id",
    "AgentSession",
    "SessionStatus",
    "EnvironmentConfig",
    # Providers
    "rollout_openai",
    "rollout_sglang",
    "rollout_anthropic",
    "get_provider_function",
    # Message transformation
    "transform_messages",
    # Model registry
    "get_model",
    "get_api_type",
    "Provider",
    "ApiType",
    "ModelMetadata",
    "ModelCost",
    "Metric",
    "Score",
    "Sample",
    "ScoreFn",
    "rollout_google",
    "rollout_openai_responses",
]

__version__ = "0.3.0"  # Added configuration protocols and base configs
