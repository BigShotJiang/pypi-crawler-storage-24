"""Backward-compat re-export. Canonical location: wafer.eval.helpers."""
from wafer.eval.helpers import load_tasks

__all__ = ["load_tasks"]
