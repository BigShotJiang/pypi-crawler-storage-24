# Core agent execution framework
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import replace

import trio

from wafer.core.dtypes import (
    Actor,
    AgentCheckpoint,
    AgentState,
    Environment,
    EnvironmentConfig,
    LLMCallEnd,
    Message,
    RunConfig,
    SemaphoreAcquired,
    SemaphoreWaitStart,
    SessionStatus,
    StopReason,
    StreamEvent,
    TextDelta,
    ThinkingDelta,
    ToolCall,
    ToolCallEnd,
    ToolConfirmResult,
    ToolExecutionEnd,
    ToolExecutionStart,
    ToolResult,
    ToolResultReceived,
)

from .progress import tqdm
from .tool_execution import (
    _apply_tool_outcome,
    _build_tool_result_summary,
    _fresh_env_from_snapshot,
    _tool_result_to_message,
)

logger = logging.getLogger(__name__)


# ── Core Design Philosophy ────────────────────────────────────────────────────
#
# FULL STATE PASSING: Pass full state everywhere rather than using globals.
# Benefits: testable, checkpointable, parallelizable. Cost: verbose signatures.
# Pattern: Always return new state, never mutate in place.
#
# STATE IMMUTABILITY: All core data structures are frozen dataclasses.
# Benefits: time-travel debugging, safe concurrency, easy rollback.
# Cost: O(n) allocations per turn. Assumption: allocation cheaper than debugging.
#
# PROFILING EVENTS: We emit LLMCallEnd and ToolExecutionEnd events with timing data
# for profiling eval throughput. Currently this is inline in the agent logic.
# TODO: Consider a decorator or context manager pattern to separate timing/logging
# concerns from core agent logic while keeping the code easy to read. The current
# inline approach is explicit but adds noise to the control flow.
#
# TODO: Document scaffold versioning for reproducibility
# Article quote: "On SWE-bench Verified, a popular agentic coding benchmark, simply switching
# the scaffold makes up to an 11% difference for GPT-5 and up to a 15% difference for Kimi K2
# Thinking. We cover the effect of the scaffold in our SWE-bench Verified review. The choice
# of scaffold has the single biggest impact on the overall performance."
#
# Article quote: "Customizing the harness for each model risks hill-climbing on the evaluation
# and makes direct comparisons between models difficult."
#
# Problem: Our scaffold (run_agent → run_agent_step → process_pending_tools) has implicit
# design choices that affect benchmark scores:
# - Tool execution is parallel when possible (falls back to sequential if confirmation needed)
# - All tools execute before next LLM turn (turn atomicity)
# - Tool confirmation flow
# - System prompt injection points
#
# Fix: Add SCAFFOLD_VERSION constant and include in eval outputs:
#     SCAFFOLD_VERSION = "1.0.0"  # Bump when changing tool execution, prompts, etc.
# Include in eval report for reproducibility.
# Core types (Endpoint, Actor, AgentState, RunConfig, Environment) are now imported from dtypes
# ── Utility functions ────────────────────────────────────────────────────────
async def handle_checkpoint_event(
    state: "AgentState", event: str, run_config: "RunConfig", session_id: str | None = None
) -> None:
    """Handle checkpoint event - emits via on_chunk"""
    assert state is not None
    assert isinstance(state, AgentState)
    assert event is not None
    assert isinstance(event, str)
    assert run_config is not None
    await run_config.on_chunk(
        AgentCheckpoint(
            checkpoint=event,
            turn=state.turn_idx,
            session_id=session_id,
        )
    )


async def stdout_handler(event: StreamEvent) -> None:
    """Simple stdout handler for granular streaming events"""
    if isinstance(event, TextDelta):
        print(event.delta, end="", flush=True)
    elif isinstance(event, ThinkingDelta):
        # Magenta color for thinking
        print(f"\033[95m{event.delta}\033[0m", end="", flush=True)
    elif isinstance(event, ToolCallEnd):
        print(f"\nCalling {event.tool_call.name}({event.tool_call.args})")
    # Note: tool_result events are emitted separately by the agent loop, not by stream aggregators


# ── Core agent functions ──────────────────────────────────────────────────────
async def confirm_tool_with_feedback(
    tc: ToolCall, state: AgentState, run_config: "RunConfig"
) -> tuple[AgentState, ToolConfirmResult]:
    """Confirm tool execution, returning state and confirmation result"""
    assert tc is not None
    assert isinstance(tc, ToolCall)
    assert state is not None
    assert isinstance(state, AgentState)
    assert run_config is not None
    assert state.environment is not None
    if not state.environment.requires_confirmation(tc):
        return state, ToolConfirmResult(proceed=True)
    print(f"\n> Execute `{tc.name}({tc.args})`?")
    print("  [y] Yes, execute")
    print("  [n] No, provide feedback")
    print("  [s] No, skip silently")
    # Intentionally blocking - this is interactive terminal input
    resp = input("Choice: ").strip().lower()  # noqa: ASYNC250
    if resp == "y":
        return state, ToolConfirmResult(proceed=True)
    elif resp == "n":
        # Intentionally blocking - this is interactive terminal input
        feedback = input("Why not? Provide guidance: \n").strip()  # noqa: ASYNC250
        result_with_feedback = ToolConfirmResult(
            proceed=False,
            tool_result=ToolResult(tool_call_id=tc.id, is_error=True, error="Rejected by user"),
            user_message=feedback,
        )
        assert result_with_feedback.tool_result is not None
        return state, result_with_feedback
    else:  # Skip silently
        result_skip = ToolConfirmResult(
            proceed=False,
            tool_result=ToolResult(tool_call_id=tc.id, is_error=True, error="Skipped by user"),
        )
        assert result_skip.tool_result is not None
        return state, result_skip


def handle_tool_error(result: ToolResult, state: AgentState) -> AgentState:
    """Handle tool execution errors - currently a no-op"""
    assert result is not None
    assert isinstance(result, ToolResult)
    assert state is not None
    assert isinstance(state, AgentState)
    return state


def inject_turn_warning(max_turns: int, warning_at: int = 2) -> Callable[[AgentState], AgentState]:
    """Inject warning when N turns remaining.
    Args:
        max_turns: Total turns available
        warning_at: Warn when this many turns remaining (default: 2)
    Returns:
        Handler function that injects warning message
    Example:
        run_config = RunConfig(
            on_step_start=inject_turn_warning(max_turns=5, warning_at=2),
        )
    """
    assert max_turns > 0
    assert warning_at > 0
    assert warning_at < max_turns

    def handler(state: AgentState) -> AgentState:
        assert state is not None
        assert isinstance(state, AgentState)
        assert state.turn_idx >= 0
        turns_left = max_turns - state.turn_idx
        if turns_left == warning_at:
            warning = Message(
                role="user",
                content=f"[warn] You have {warning_at} turns remaining. Please complete your task quickly.",
            )
            new_trajectory = replace(
                state.actor.trajectory, messages=state.actor.trajectory.messages + [warning]
            )
            result_state = replace(state, actor=replace(state.actor, trajectory=new_trajectory))
            assert result_state is not None
            return result_state
        return state
    return handler


def handle_stop_max_turns(max_turns: int) -> Callable[[AgentState], AgentState]:
    """Stop when max turns reached.
    Args:
        max_turns: Maximum number of turns before stopping
    Returns:
        Handler function that stops when turn_idx >= max_turns
    Example:
        run_config = RunConfig(
            handle_stop=handle_stop_max_turns(5),  # Stop after 5 turns
        )
    """
    assert max_turns > 0, "max_turns must be positive"

    def handler(state: AgentState) -> AgentState:
        assert state is not None
        assert isinstance(state, AgentState)
        assert state.turn_idx >= 0
        if state.turn_idx >= max_turns:
            result_state = replace(state, stop=StopReason.MAX_TURNS)
            assert result_state.stop is not None
            return result_state
        return state
    return handler


async def inject_tool_reminder(state: AgentState, run_config: "RunConfig") -> AgentState:
    """Remind the agent to use tools"""
    assert state is not None
    assert isinstance(state, AgentState)
    assert run_config is not None
    reminder = Message(
        role="user",
        content="Please use the available tools to complete the task. What calculation would you like to perform?",
    )
    new_trajectory = replace(
        state.actor.trajectory, messages=state.actor.trajectory.messages + [reminder]
    )
    result_state = replace(state, actor=replace(state.actor, trajectory=new_trajectory))
    assert result_state is not None
    return result_state


async def rollout(  # noqa: PLR0913 - args grouped by mode (core, anthropic)
    actor: Actor,
    on_chunk: Callable[[StreamEvent], Awaitable[None]] = stdout_handler,
    user_message_for_thinking: str | None = None,
    turn_idx: int = 0,
    inline_thinking: str | None = None,
    cancel_scope: trio.CancelScope | None = None,
) -> Actor:
    """Route to appropriate provider function using unified API type abstraction.
    This function uses the provider registry to automatically select the correct
    streaming implementation based on the provider and model. Multiple providers
    (e.g., OpenAI, Groq, xAI) may share the same implementation if they use
    compatible APIs.
    Args:
        actor: Current actor state with endpoint and trajectory
        on_chunk: Callback for streaming events
        user_message_for_thinking: Anthropic-specific parameter for thinking context
        turn_idx: Anthropic-specific parameter for turn tracking
        inline_thinking: Anthropic-specific parameter for thinking template
        cancel_scope: Optional Trio cancel scope for graceful cancellation
    Returns:
        Updated actor with new message in trajectory
    """
    assert actor is not None
    assert on_chunk is not None
    assert callable(on_chunk)
    # Standard mode: use text-based providers
    from .providers import get_provider_function
    provider = actor.endpoint.provider
    model_id = actor.endpoint.model
    provider_func = get_provider_function(provider, model_id)
    # Call with provider-specific kwargs if needed
    # Anthropic needs extra params, others don't - but **kwargs makes this flexible
    # Note: Provider functions don't yet support cancel_scope, but we pass it for future support
    new_actor = await provider_func(
        actor,
        on_chunk,
        user_message_for_thinking=user_message_for_thinking,
        turn_idx=turn_idx,
        inline_thinking=inline_thinking,
    )
    return new_actor


async def run_agent_step(  # noqa: PLR0915
    state: AgentState,
    rcfg: RunConfig,
) -> AgentState:
    """Execute one complete turn: LLM call → ALL tool executions → next turn.
    Turn atomicity: Execute ALL tools before giving control back to LLM.
    Tools execute in parallel when possible (>1 tool, none needing confirmation).
    Cancellation is handled automatically by Trio - any await will raise
    trio.Cancelled if the cancel_scope was cancelled.
    Args:
        state: Current agent state
        rcfg: Run configuration (contains cancel_scope for cancellation)
    """
    assert state is not None
    assert rcfg is not None

    from ._debug import debug_ctx
    debug_ctx.turn = state.turn_idx
    debug_ctx.set_phase("agent_step")
    state = rcfg.handle_stop(state)
    if state.stop:
        return state
    # If we have pending tools, resume processing them
    if state.pending_tool_calls:
        return await process_pending_tools(state, rcfg)
    state = rcfg.on_step_start(state)
    # Otherwise, do a new rollout
    available_tools = state.environment.get_tools() if state.environment else []
    updated_actor = replace(state.actor, tools=available_tools)
    # Inject stop-and-think nudge after 2 consecutive failures
    if state.consecutive_failures >= 2:
        nudge_msg = Message(
            role="user",
            content="You have had 2 consecutive tool failures. Explain the root cause before continuing.",
        )
        updated_actor = replace(
            updated_actor,
            trajectory=replace(
                updated_actor.trajectory,
                messages=updated_actor.trajectory.messages + [nudge_msg],
            ),
        )
        state = replace(state, consecutive_failures=0)
    # Make LLM call (with cancellation support)
    # If api_limiter is set, acquire slot before making the call
    # This enables two-level concurrency: samples waiting for tools don't hold API slots

    async def do_rollout() -> Actor:
        return await rollout(
            updated_actor,
            rcfg.on_chunk,
            rcfg.user_message_for_thinking,
            state.turn_idx,
            rcfg.inline_thinking,
            cancel_scope=rcfg.cancel_scope,
        )
    # Wide event: time the full LLM call including retries
    llm_start_time = time.perf_counter()
    llm_error: str | None = None
    next_actor = None
    try:
        if rcfg.api_limiter is not None:
            # Emit semaphore wait event for observability
            await rcfg.on_chunk(SemaphoreWaitStart(limiter_type="api"))
            wait_start = time.perf_counter()
            async with rcfg.api_limiter:
                wait_duration_ms = (time.perf_counter() - wait_start) * 1000
                await rcfg.on_chunk(
                    SemaphoreAcquired(limiter_type="api", wait_duration_ms=wait_duration_ms)
                )
                next_actor = await do_rollout()
        else:
            next_actor = await do_rollout()
    except Exception as e:
        llm_error = f"{type(e).__name__}: {e}"
        raise
    finally:
        llm_duration_ms = (time.perf_counter() - llm_start_time) * 1000
        tokens_in: int | None = None
        tokens_out: int | None = None
        cache_read: int | None = None
        cache_write: int | None = None
        if next_actor is not None and next_actor.trajectory.completions:
            last_completion = next_actor.trajectory.completions[-1]
            if hasattr(last_completion, "usage") and last_completion.usage:
                tokens_in = getattr(last_completion.usage, "input_tokens", None)
                tokens_out = getattr(last_completion.usage, "output_tokens", None)
                cache_read = getattr(last_completion.usage, "cache_read_tokens", None)
                cache_write = getattr(last_completion.usage, "cache_write_tokens", None)
        await rcfg.on_chunk(
            LLMCallEnd(
                duration_ms=llm_duration_ms,
                provider=updated_actor.endpoint.provider,
                model=updated_actor.endpoint.model,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                cache_read_tokens=cache_read,
                cache_write_tokens=cache_write,
                status="error" if llm_error else "success",
                error=llm_error,
            )
        )
    last_message = next_actor.trajectory.messages[-1] if next_actor.trajectory.messages else None
    tool_calls = []
    if last_message and last_message.role == "assistant":
        tool_calls = last_message.get_tool_calls()

    current_state = replace(state, actor=next_actor, pending_tool_calls=tool_calls, next_tool_idx=0)
    # Persist assistant message immediately after rollout
    if rcfg.session_store and state.session_id and last_message:
        await rcfg.session_store.append_message(state.session_id, last_message)
    # Let environment respond to assistant message (e.g., execute code, provide feedback)
    # This happens AFTER updating state but BEFORE tool processing
    # Only call if we actually have an assistant message
    if state.environment and last_message and last_message.role == "assistant":
        try:
            current_state = await state.environment.on_assistant_message(
                last_message, current_state
            )
        except Exception:
            logger.exception("environment on_assistant_message failed env=%s", type(state.environment).__name__)
            raise
    # If no tools, check for max_tokens truncation before normal no-tool handling
    if not tool_calls:
        last_completion = (
            next_actor.trajectory.completions[-1]
            if next_actor.trajectory.completions
            else None
        )
        if (
            last_completion
            and last_completion.choices
            and last_completion.choices[0].finish_reason == "max_tokens"
        ):
            logger.warning("Response truncated by max_tokens limit - injecting continuation")
            continuation_msg = Message(
                role="user",
                content=(
                    "Your previous response was truncated because it hit the output token limit. "
                    "Continue where you left off. Keep individual tool calls concise -- "
                    "write each source file separately instead of embedding code in shell heredocs."
                ),
            )
            truncated_trajectory = replace(
                current_state.actor.trajectory,
                messages=current_state.actor.trajectory.messages + [continuation_msg],
            )
            current_state = replace(
                current_state,
                actor=replace(current_state.actor, trajectory=truncated_trajectory),
                turn_idx=current_state.turn_idx + 1,
                pending_tool_calls=[],
            )
            if rcfg.session_store and state.session_id:
                await rcfg.session_store.append_message(state.session_id, continuation_msg)
            return current_state
        current_state = await rcfg.handle_no_tool(current_state, rcfg)
        if current_state.stop:
            return current_state
        # Otherwise increment turn and continue
        return replace(current_state, turn_idx=current_state.turn_idx + 1, pending_tool_calls=[])
    # Process the pending tools
    return await process_pending_tools(current_state, rcfg)


# TODO: Checkpoint granularity for multi-tool calls
#
# Current behavior: When LLM returns multiple tool calls in one response,
# we execute ALL tools before creating a checkpoint. This means:
#   - add(10) → multiply(3) → divide(5) all execute, THEN checkpoint
#   - If crash occurs during multiply(), we restart from turn beginning
#
# This is usually fine because tool execution is fast, but consider finer
# checkpointing if:
#   - Tools make slow external API calls
#   - Tools have expensive side effects (can't safely re-run)
#   - Running very long tool chains (10+ tools per turn)
#
# Implementation approach: Modify process_pending_tools to yield intermediate
# states after each tool, then checkpoint each yielded state in run_agent.
# See next_tool_idx which already tracks progress within a tool batch.


async def process_pending_tools(
    state: AgentState,
    rcfg: RunConfig,
) -> AgentState:
    """Route to parallel or sequential tool processing.

    Parallel: when >1 tool and none require confirmation.
    Sequential: single tool or when any tool needs user confirmation.
    """
    assert state.environment is not None, "process_pending_tools requires environment"
    assert state is not None
    assert rcfg is not None

    tools_remaining = state.pending_tool_calls[state.next_tool_idx:]
    any_needs_confirm = any(
        state.environment.requires_confirmation(tc)
        for tc in tools_remaining
        if not tc.parse_error
    )

    if len(tools_remaining) > 1 and not any_needs_confirm:
        return await _process_tools_parallel(state, rcfg)
    return await _process_tools_sequential(state, rcfg)


async def _process_tools_sequential(  # noqa: PLR0915
    state: AgentState,
    rcfg: RunConfig,
) -> AgentState:
    """Execute pending tools one at a time.
    Used when there's a single tool or when any tool requires confirmation.
    """
    assert state.environment is not None
    current_state = state
    assert current_state.environment is not None
    env_data = await current_state.environment.serialize()
    for i in range(state.next_tool_idx, len(state.pending_tool_calls)):
        tool_call = state.pending_tool_calls[i]
        current_state = replace(current_state, next_tool_idx=i)
        # (like verifiers pattern: send parse errors back so model can retry)

        tool_duration_ms: float | None = None
        if tool_call.parse_error:
            tool_result = ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                error=tool_call.parse_error,
                content="",
            )
            confirm_result = None  # No confirmation for parse errors
        else:
            current_state, confirm_result = await rcfg.confirm_tool(tool_call, current_state, rcfg)
            if confirm_result.proceed:
                assert current_state.environment is not None  # Maintained through loop
                fresh_env = await _fresh_env_from_snapshot(
                    current_state.environment.__class__, env_data, current_state.environment,
                )

                from ._debug import debug_ctx
                debug_ctx.set_tool(tool_call.name)
                # Wide event: time the full tool execution
                tool_start_time = time.perf_counter()
                # Emit tool execution start event (for TUI spinner)
                await rcfg.on_chunk(
                    ToolExecutionStart(
                        tool_call_id=tool_call.id,
                        tool_name=tool_call.name,
                    )
                )
                # Execute tool on fresh environment with cancellation support
                # If tool_limiter is set, acquire slot before executing
                # This enables two-level concurrency: samples waiting for API don't hold tool slots

                async def do_exec_tool(
                    env: Environment = fresh_env,
                    tc: ToolCall = tool_call,
                    state: AgentState = current_state,
                ) -> ToolResult:
                    return await env.exec_tool(
                        tc,
                        state,
                        rcfg,
                        cancel_scope=rcfg.cancel_scope,
                    )
                if rcfg.tool_limiter is not None:
                    # Emit semaphore wait event for observability
                    await rcfg.on_chunk(SemaphoreWaitStart(limiter_type="tool"))
                    wait_start = time.perf_counter()
                    async with rcfg.tool_limiter:
                        wait_duration_ms = (time.perf_counter() - wait_start) * 1000
                        await rcfg.on_chunk(
                            SemaphoreAcquired(
                                limiter_type="tool", wait_duration_ms=wait_duration_ms
                            )
                        )
                        tool_result = await do_exec_tool()
                else:
                    tool_result = await do_exec_tool()
                tool_duration_ms = (time.perf_counter() - tool_start_time) * 1000

                env_data = await fresh_env.serialize()
                assert current_state.environment is not None  # Maintained through loop
                new_env = await _fresh_env_from_snapshot(
                    current_state.environment.__class__, env_data, current_state.environment,
                )
                current_state = replace(current_state, environment=new_env)
            else:
                tool_result = confirm_result.tool_result
                # TODO: handle None on tool results
        # Emit tool result
        assert tool_result
        await rcfg.on_chunk(
            ToolResultReceived(
                tool_call_id=tool_call.id,
                content=tool_result.content,
                is_error=tool_result.is_error,
                error=tool_result.error,
                details=tool_result.details,
            )
        )

        if tool_duration_ms is not None:
            result_summary = _build_tool_result_summary(tool_call, tool_result)
            await rcfg.on_chunk(
                ToolExecutionEnd(
                    tool_call_id=tool_call.id,
                    tool_name=tool_call.name,
                    duration_ms=tool_duration_ms,
                    status="error" if tool_result.is_error else "success",
                    is_error=tool_result.is_error,
                    result_summary=result_summary if result_summary else None,
                )
            )
        result_message = _tool_result_to_message(tool_call, tool_result)
        messages_to_add = [result_message]
        if confirm_result and confirm_result.user_message:
            user_msg = Message(
                role="user",
                content=confirm_result.user_message,
            )
            messages_to_add.append(user_msg)

        current_state = _apply_tool_outcome(current_state, tool_result, messages_to_add)
        # Persist each message after tool execution
        if rcfg.session_store and state.session_id:
            for msg in messages_to_add:
                await rcfg.session_store.append_message(state.session_id, msg)
        current_state = rcfg.handle_tool_error(tool_result, current_state)
        if tool_result.stop_reason:
            current_state = replace(current_state, stop=tool_result.stop_reason)
            break
    return replace(
        current_state, turn_idx=current_state.turn_idx + 1, pending_tool_calls=[], next_tool_idx=0
    )


async def _process_tools_parallel(
    state: AgentState,
    rcfg: RunConfig,
) -> AgentState:
    """Execute all pending tools concurrently via trio nursery.

    Each tool gets an independent environment snapshot. Results are added to
    the trajectory in the original tool-call order regardless of finish order.
    """
    assert state.environment is not None
    current_state = state
    env = current_state.environment

    env_data = await env.serialize()
    tools = state.pending_tool_calls[state.next_tool_idx:]
    assert len(tools) > 1

    outcomes: list[tuple[ToolResult, dict | None, float | None] | None] = [None] * len(tools)

    async def _execute_one(idx: int, tool_call: ToolCall) -> None:
        if tool_call.parse_error:
            outcomes[idx] = (
                ToolResult(
                    tool_call_id=tool_call.id, is_error=True,
                    error=tool_call.parse_error, content="",
                ),
                None,
                None,
            )
            return

        tool_start = time.perf_counter()
        await rcfg.on_chunk(
            ToolExecutionStart(tool_call_id=tool_call.id, tool_name=tool_call.name)
        )

        fresh_env = await _fresh_env_from_snapshot(env.__class__, env_data, env)

        async def _do_exec() -> ToolResult:
            return await fresh_env.exec_tool(
                tool_call, current_state, rcfg, cancel_scope=rcfg.cancel_scope,
            )

        if rcfg.tool_limiter is not None:
            await rcfg.on_chunk(SemaphoreWaitStart(limiter_type="tool"))
            wait_start = time.perf_counter()
            async with rcfg.tool_limiter:
                wait_ms = (time.perf_counter() - wait_start) * 1000
                await rcfg.on_chunk(
                    SemaphoreAcquired(limiter_type="tool", wait_duration_ms=wait_ms)
                )
                result = await _do_exec()
        else:
            result = await _do_exec()

        duration_ms = (time.perf_counter() - tool_start) * 1000
        tool_env_data = await fresh_env.serialize()

        await rcfg.on_chunk(
            ToolResultReceived(
                tool_call_id=tool_call.id,
                content=result.content,
                is_error=result.is_error,
                error=result.error,
                details=result.details,
            )
        )
        summary = _build_tool_result_summary(tool_call, result)
        await rcfg.on_chunk(
            ToolExecutionEnd(
                tool_call_id=tool_call.id,
                tool_name=tool_call.name,
                duration_ms=duration_ms,
                status="error" if result.is_error else "success",
                is_error=result.is_error,
                result_summary=summary or None,
            )
        )

        outcomes[idx] = (result, tool_env_data, duration_ms)

    async with trio.open_nursery() as nursery:
        for i, tc in enumerate(tools):
            nursery.start_soon(_execute_one, i, tc)

    # Build trajectory in tool-call order
    final_env_data = env_data
    for i, tc in enumerate(tools):
        outcome = outcomes[i]
        assert outcome is not None, f"Tool {tc.name} (index {i}) produced no outcome"
        result, tool_env_data, _duration = outcome

        result_message = _tool_result_to_message(tc, result)
        current_state = _apply_tool_outcome(current_state, result, [result_message])
        if rcfg.session_store and state.session_id:
            await rcfg.session_store.append_message(state.session_id, result_message)
        current_state = rcfg.handle_tool_error(result, current_state)
        if tool_env_data is not None:
            final_env_data = tool_env_data
        if result.stop_reason:
            current_state = replace(current_state, stop=result.stop_reason)

    new_env = await _fresh_env_from_snapshot(env.__class__, final_env_data, env)
    current_state = replace(current_state, environment=new_env)

    return replace(
        current_state,
        turn_idx=current_state.turn_idx + 1,
        pending_tool_calls=[],
        next_tool_idx=0,
    )


def _environment_to_config(
    environment: "Environment | None", confirm_tools: bool = False
) -> "EnvironmentConfig":
    """Convert Environment to serializable EnvironmentConfig."""
    from wafer.core.dtypes import EnvironmentConfig
    config = {"confirm_tools": confirm_tools}
    if environment is None:
        return EnvironmentConfig(type="none", config=config)
    return EnvironmentConfig(
        type=type(environment).__name__,
        config=config,  # Config details stored in environment_state
    )


async def run_agent(
    state: AgentState,
    run_config: RunConfig,
) -> list[AgentState]:
    """Run agent until stop condition, checkpointing each state.
    If run_config.cancel_scope is provided and cancelled, raises trio.Cancelled.
    Caller is responsible for handling cancellation at their boundary.
    Session persistence:
    - If run_config.session_store is set, session lifecycle is managed automatically:
      - If state.session_id is None, a new session is created
      - If state.session_id is set, that session is resumed
    - Messages are persisted after each turn
    - Final status and environment state are saved when agent stops
    - The session_id is set on state and available via returned states
    Args:
        state: Initial agent state (set session_id to resume existing session)
        run_config: Run configuration (set session_store for persistence)
    Returns:
        List of agent states. Access session_id via states[-1].session_id
    """
    session_store = run_config.session_store
    current_state = state
    # Session creation: if session_store but no session_id, create one
    if session_store and not current_state.session_id:
        session = await session_store.create(
            endpoint=current_state.actor.endpoint,  # Endpoint stored with secrets excluded
            environment=_environment_to_config(
                current_state.environment, current_state.confirm_tools
            ),
            parent_id=current_state.parent_session_id,
            branch_point=current_state.branch_point,
        )
        current_state = replace(current_state, session_id=session.session_id)
        if run_config.on_session_created:
            await run_config.on_session_created(session.session_id)
        if current_state.parent_session_id:
            logger.info(
                f"Created child session: {session.session_id} (forked from {current_state.parent_session_id} at message {current_state.branch_point})"
            )
        else:
            logger.info(f"Created session: {session.session_id}")
        # Persist initial messages (system prompt, user message, etc.)
        for msg in current_state.actor.trajectory.messages:
            await session_store.append_message(session.session_id, msg)
    elif session_store and current_state.session_id:
        # Resuming existing session - check for messages added since last persist
        # (e.g., user added a new message before calling run_agent)
        session, _ = await session_store.get(current_state.session_id)
        if session:
            persisted_count = len(session.messages)
            current_count = len(current_state.actor.trajectory.messages)
            if current_count > persisted_count:
                # Persist the gap messages
                for msg in current_state.actor.trajectory.messages[persisted_count:]:
                    await session_store.append_message(current_state.session_id, msg)
    # Notify environment of session start (for setup like git worktrees)
    if current_state.environment and current_state.session_id:
        if hasattr(current_state.environment, "on_session_start"):
            logger.info(
                "Calling on_session_start (env=%s, session=%s)",
                type(current_state.environment).__name__,
                current_state.session_id,
            )
            _session_start_t = time.perf_counter()
            await current_state.environment.on_session_start(current_state.session_id)
            logger.info(
                "on_session_start completed in %.1fs", time.perf_counter() - _session_start_t
            )
    states = [current_state]
    turn_pbar = None
    if run_config.show_progress:
        turn_pbar = tqdm(desc="Turns", unit="turn", disable=False)
    try:
        while not current_state.stop:
            current_state = run_config.handle_stop(current_state)
            if current_state.stop:
                # Append final state with stop reason before breaking
                states.append(current_state)
                break
            # Tiger Style: Centralize control flow - emit start/end in same scope for clarity
            await handle_checkpoint_event(
                current_state, "turn_start", run_config, current_state.session_id
            )
            # Run one step - this is where HTTP calls happen
            # Trio will raise Cancelled if cancel_scope.cancel() was called
            next_state = await run_agent_step(current_state, run_config)
            current_state = next_state
            states.append(current_state)

            if turn_pbar:
                turn_pbar.update(1)
                postfix = {}
                if current_state.stop:
                    postfix["stop"] = str(current_state.stop).split(".")[-1]
                turn_pbar.set_postfix(postfix)
            # Checkpoint after each turn completes
            await handle_checkpoint_event(
                current_state, "turn_end", run_config, current_state.session_id
            )
    except trio.Cancelled:
        aborted_state = replace(current_state, stop=StopReason.ABORTED)
        states.append(aborted_state)
        current_state = aborted_state
        # Simple cleanup - just save status, let resume handle incomplete state
        with trio.CancelScope(shield=True):
            if session_store and current_state.session_id:
                await session_store.update(
                    current_state.session_id,
                    status=SessionStatus.STOPPED,
                )
        return states
    # Save final state
    await handle_checkpoint_event(current_state, "final", run_config, current_state.session_id)
    # Save final session status and environment state
    if session_store and current_state.session_id:
        if current_state.stop == StopReason.TASK_COMPLETED:
            status = SessionStatus.COMPLETED
        elif current_state.stop == StopReason.ABORTED:
            status = SessionStatus.STOPPED
        elif current_state.stop == StopReason.MAX_TURNS:
            status = SessionStatus.FAILED
        elif current_state.stop == StopReason.NEEDS_INPUT:
            status = SessionStatus.WAITING
        else:
            status = SessionStatus.COMPLETED
        env_state = None
        if current_state.environment is not None:
            env_state = await current_state.environment.serialize()
        await session_store.update(
            current_state.session_id,
            status=status,
            environment_state=env_state,
        )
    if turn_pbar:
        turn_pbar.close()
    return states
