"""Run a command on a GPU sandbox with optional workspace sync."""
from __future__ import annotations

import logging
import os
import shlex
from pathlib import Path

import trio

from wafer.core.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)

logger = logging.getLogger(__name__)

MAX_OUTPUT_SIZE = 30_000

SANDBOX_RUN_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="sandbox_run",
        description=(
            "Run a command on a GPU sandbox. Syncs your workspace to the target, "
            "executes the command with full GPU access, and returns stdout/stderr. "
            "Use for compilation, benchmarks, profiling, and any GPU work. "
            "Prefer this over bash('wafer sandbox run ...')."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "command": {
                    "type": "string",
                    "description": "Command to execute on the GPU (e.g. 'nvcc -O3 -o main main.cu && ./main')",
                },
                "target": {
                    "type": "string",
                    "description": "GPU target name (e.g. 'b200', 'mi355x'). Omit to use the default target.",
                },
                "sync": {
                    "type": "boolean",
                    "description": "Sync workspace to sandbox before running (default: true)",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default: 1200)",
                },
            },
        ),
        required=["command"],
    ),
)


def _resolve_target_name(explicit: str | None) -> str:
    """Resolve target name from explicit arg, env vars, or fail."""
    if explicit:
        return explicit
    from_env = os.environ.get("WAFER_TARGET_NAME") or os.environ.get("WAFER_DEFAULT_TARGET")
    assert from_env, (
        "No target specified and WAFER_TARGET_NAME / WAFER_DEFAULT_TARGET not set. "
        "Pass target='b200' or similar."
    )
    return from_env


async def exec_sandbox_run(
    tool_call: ToolCall,
    working_dir: Path,
) -> ToolResult:
    """Execute a command on a GPU sandbox."""
    command = tool_call.args.get("command", "")
    assert command, "command is required"

    target_arg: str | None = tool_call.args.get("target")
    do_sync: bool = tool_call.args.get("sync", True)
    timeout: int = tool_call.args.get("timeout", 1200)
    idle_timeout: int = 600

    target_name = _resolve_target_name(target_arg)

    def _sync_and_run() -> tuple[str, int]:
        from wafer.core.sandbox.operations import resolve_or_create_sandbox, db_touch_sandbox

        sandbox = resolve_or_create_sandbox(target_name, json_output=True)
        work_dir: str | None = None

        if do_sync and working_dir.is_dir():
            from wafer.core.targets.operations import load_target, get_target_ssh_info, sync_to_target

            target_config = load_target(sandbox.target_name)

            async def _get_info():
                return await get_target_ssh_info(target_config)

            import trio as _trio
            ssh_info = _trio.run(_get_info)

            resolved = working_dir.resolve()
            work_dir = f"/tmp/{resolved.name}"
            sync_to_target(ssh_info, resolved, remote_path=work_dir)
            logger.info("sandbox_run synced %s to %s:%s", resolved, ssh_info.host, work_dir)

        cmd_str = command
        if work_dir:
            cmd_str = f"cd {shlex.quote(work_dir)} && {command}"

        from wafer.core.sandbox import SandboxSession

        async def _run():
            session = SandboxSession(sandbox)
            await session.connect()
            try:
                output, exit_code, _meta = await session.run_command(
                    cmd_str, timeout, no_change_timeout=idle_timeout,
                )
            finally:
                if session._client is not None:
                    await session._client.close()
            return output, exit_code

        import trio as _trio
        output, exit_code = _trio.run(_run)
        db_touch_sandbox(sandbox.id, sandbox.timeout_hours)
        return output, exit_code

    output, exit_code = await trio.to_thread.run_sync(_sync_and_run)

    if len(output) > MAX_OUTPUT_SIZE:
        output = output[:MAX_OUTPUT_SIZE] + "\n\n... (output truncated)"

    if exit_code != 0:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=output or "(no output)",
            error=f"Command exited with code {exit_code}",
        )
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=output or "(no output)",
    )
