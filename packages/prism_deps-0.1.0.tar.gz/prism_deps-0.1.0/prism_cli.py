#!/usr/bin/env python3
"""Prism CLI — dependency scan, tree view, snapshot export, and web UI."""
import argparse
import sys
import time
from pathlib import Path
from collections import defaultdict, deque

DEFAULT_MAX_TOKENS = 800_000


def parse_args():
    p = argparse.ArgumentParser(
        prog="prism",
        description="Python dependency analyzer — scan, visualize, and export.",
    )
    sub = p.add_subparsers(dest="command")

    # --- scan ---
    scan_p = sub.add_parser("scan", help="Scan dependencies from an entry point.")
    scan_p.add_argument(
        "entry_point",
        help="Entry point file (e.g. backend/main.py). Absolute or relative to --project.",
    )
    scan_p.add_argument("-p", "--project", help="Project root directory. Default: auto-detected from .git.")
    scan_p.add_argument("-o", "--output", help="Write snapshot (code with separators) to this file.")
    scan_p.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS,
                        help=f"Max tokens for child dependencies. Default: {DEFAULT_MAX_TOKENS:,}.")
    scan_p.add_argument("--depth", type=int, default=0, help="Max child depth. 0 = unlimited BFS (default).")
    scan_p.add_argument("--parent-depth", type=int, default=1, help="Levels of parent (imported-by) files. Default: 1.")
    scan_p.add_argument("--frontend", action="store_true", help="Include frontend files (HTML/JS/CSS).")
    scan_p.add_argument("--no-tree", action="store_true", help="Skip the dependency tree printout.")
    scan_p.add_argument("--orphans", action="store_true", help="List orphan files.")
    scan_p.add_argument("--dry-run", action="store_true", help="Show full scan stats without writing output.")
    scan_p.add_argument("-q", "--quiet", action="store_true", help="Suppress tree/stats — only write output file.")
    scan_p.add_argument("-x", "--exclude", action="append", default=[], help="Exclude directory patterns (repeatable).")

    # --- serve ---
    serve_p = sub.add_parser("serve", help="Start the Prism web UI.")
    serve_p.add_argument("--host", default="0.0.0.0", help="Host to bind to. Default: 0.0.0.0.")
    serve_p.add_argument("--port", type=int, default=5042, help="Port to serve on. Default: 5042.")
    serve_p.add_argument("--debug", action="store_true", help="Enable Flask debug mode.")

    # If first arg isn't a known subcommand, treat it as `scan <args>`
    if len(sys.argv) > 1 and sys.argv[1] not in ("scan", "serve", "-h", "--help"):
        return scan_p.parse_args(sys.argv[1:])

    args = p.parse_args()

    if args.command is None:
        p.print_help()
        sys.exit(0)

    return args


def resolve_paths(args):
    """Figure out project root and relative entry point path."""
    ep_raw = Path(args.entry_point)

    if ep_raw.is_absolute():
        ep_abs = ep_raw.resolve()
        if args.project:
            project_root = Path(args.project).resolve()
        else:
            candidate = ep_abs.parent
            while candidate != candidate.parent:
                if (candidate / ".git").exists():
                    break
                candidate = candidate.parent
            else:
                candidate = ep_abs.parent
            project_root = candidate
        try:
            ep_rel = str(ep_abs.relative_to(project_root))
        except ValueError:
            print(f"Error: entry point {ep_abs} is not inside project root {project_root}", file=sys.stderr)
            sys.exit(1)
    else:
        project_root = Path(args.project).resolve() if args.project else Path.cwd().resolve()
        ep_rel = str(ep_raw)
        ep_abs = (project_root / ep_raw).resolve()

    if not ep_abs.exists():
        print(f"Error: entry point not found: {ep_abs}", file=sys.stderr)
        sys.exit(1)

    if not project_root.exists():
        print(f"Error: project root not found: {project_root}", file=sys.stderr)
        sys.exit(1)

    return project_root, ep_rel


def bfs_full(graph, root_node, include_frontend=False):
    """Full BFS with no limits. Returns list of (node, depth) tuples."""
    from prism.models import NodeType
    visited = {root_node.path}
    queue = deque([(root_node, 0)])
    result = []

    while queue:
        node, depth = queue.popleft()
        result.append((node, depth))

        children_paths = graph._forward_index.get(node.path, set())
        for cp in sorted(children_paths):
            cn = graph._nodes.get(cp)
            if cn and cn.path not in visited:
                if not include_frontend and cn.node_type not in (NodeType.PYTHON, NodeType.HTML):
                    continue
                visited.add(cn.path)
                queue.append((cn, depth + 1))

    return result


def build_tree_lines(graph, root_node, include_frontend=False, max_tokens=0, depth_limit=0):
    """BFS the graph and return (ordered_nodes, tree_display_lines, token_total)."""
    from prism.models import NodeType
    visited = {root_node.path}
    queue = deque([(root_node, 0)])
    levels = []

    while queue:
        node, depth = queue.popleft()
        if depth_limit > 0 and depth > depth_limit:
            continue

        children_paths = graph._forward_index.get(node.path, set())
        children = []
        for cp in sorted(children_paths):
            cn = graph._nodes.get(cp)
            if cn and cn.path not in visited:
                if not include_frontend and cn.node_type not in (NodeType.PYTHON, NodeType.HTML):
                    continue
                visited.add(cn.path)
                children.append(cn)

        levels.append((node, depth, children))

        for child in children:
            queue.append((child, depth + 1))

    lines = []
    nodes_ordered = []
    token_total = 0

    for node, depth, children in levels:
        if max_tokens > 0 and token_total + node.tokens > max_tokens and depth > 0:
            remaining_tokens = sum(
                n.tokens for n, d, _ in levels
                if n not in set(nodes_ordered) and n != levels[0][0]
            )
            remaining_files = len(levels) - len(nodes_ordered)
            lines.append(
                f"{'    ' * depth}... truncated ({remaining_files} more files, "
                f"~{remaining_tokens:,} more tokens exceed {max_tokens:,} limit)"
            )
            break

        token_total += node.tokens
        nodes_ordered.append(node)

        type_char = {
            NodeType.PYTHON: "py",
            NodeType.HTML: "html",
            NodeType.JAVASCRIPT: "js",
            NodeType.TYPESCRIPT: "ts",
            NodeType.CSS: "css",
        }.get(node.node_type, "?")

        indent = "    " * depth
        connector = "-> " if depth > 0 else ""
        meta = f"[{type_char}] {node.lines}L {node.tokens}tok"
        lines.append(f"{indent}{connector}{node.relative_path}  ({meta})")

    return nodes_ordered, lines, token_total


def print_tree(lines, token_total, file=sys.stdout):
    print("\nDependency Tree (BFS):", file=file)
    print("-" * 60, file=file)
    for line in lines:
        print(line, file=file)
    print("-" * 60, file=file)
    print(f"Total tokens: {token_total:,}", file=file)


def print_dry_run(graph, root_node, include_frontend, max_tokens):
    """Print full scan overview: depth breakdown, totals, then what the cap keeps."""
    all_nodes = bfs_full(graph, root_node, include_frontend)

    depth_stats = defaultdict(lambda: {"files": 0, "tokens": 0, "lines": 0})
    type_counts = defaultdict(int)
    max_depth = 0

    for node, depth in all_nodes:
        depth_stats[depth]["files"] += 1
        depth_stats[depth]["tokens"] += node.tokens
        depth_stats[depth]["lines"] += node.lines
        type_counts[node.node_type.value] += 1
        max_depth = max(max_depth, depth)

    total_files = len(all_nodes)
    total_tokens = sum(d["tokens"] for d in depth_stats.values())
    total_lines = sum(d["lines"] for d in depth_stats.values())

    print("\n" + "=" * 64)
    print("  DRY RUN — Full Scan Overview")
    print("=" * 64)
    print(f"  Total reachable files:  {total_files}")
    print(f"  Total tokens:           {total_tokens:,}")
    print(f"  Total lines:            {total_lines:,}")
    print(f"  Max depth:              {max_depth}")
    types_str = ", ".join(f"{v} {k}" for k, v in sorted(type_counts.items(), key=lambda x: -x[1]))
    print(f"  Types:                  {types_str}")

    print(f"\n  {'Depth':<7} {'Files':>6} {'Tokens':>10} {'Lines':>8}  {'Cumulative Tokens':>18}")
    print("  " + "-" * 55)
    cumulative_tokens = 0
    for d in range(max_depth + 1):
        s = depth_stats[d]
        cumulative_tokens += s["tokens"]
        marker = ""
        if max_tokens > 0 and cumulative_tokens > max_tokens:
            prev_cum = cumulative_tokens - s["tokens"]
            if prev_cum <= max_tokens:
                marker = "  <-- cap hits here"
        print(f"  {d:<7} {s['files']:>6} {s['tokens']:>10,} {s['lines']:>8,}  {cumulative_tokens:>18,}{marker}")

    if max_tokens > 0:
        print(f"\n  Token cap: {max_tokens:,}")
        kept_files = 0
        kept_tokens = 0
        kept_lines = 0
        kept_max_depth = 0
        for node, depth in all_nodes:
            if kept_tokens + node.tokens > max_tokens and kept_files > 0:
                break
            kept_files += 1
            kept_tokens += node.tokens
            kept_lines += node.lines
            kept_max_depth = max(kept_max_depth, depth)

        cut_files = total_files - kept_files
        cut_tokens = total_tokens - kept_tokens

        print(f"  Keeping:  {kept_files} files, {kept_tokens:,} tokens, {kept_lines:,} lines (depth 0-{kept_max_depth})")
        print(f"  Cutting:  {cut_files} files, {cut_tokens:,} tokens")
        pct = (kept_tokens / total_tokens * 100) if total_tokens else 0
        print(f"  Coverage: {pct:.1f}% of reachable code")
    else:
        print(f"\n  No token cap — all {total_files} files included.")

    sorted_by_size = sorted(all_nodes, key=lambda x: -x[0].tokens)
    print(f"\n  Top 10 largest files:")
    for node, depth in sorted_by_size[:10]:
        print(f"    {node.tokens:>7,} tok  d{depth}  {node.relative_path}")

    print("=" * 64)


def write_snapshot(session, ep_rel, nodes, project_root, output_path, args):
    """Write the snapshot file using the same format as the web app."""
    from prism.models import SnapshotConfig

    config = SnapshotConfig(
        target_path=ep_rel,
        parent_depth=args.parent_depth,
        child_depth=args.depth if args.depth > 0 else 0,
        child_max_tokens=args.max_tokens,
        include_frontend=args.frontend,
    )

    result = session.create_snapshot(config)

    if "error" in result:
        print(f"Snapshot error: {result['error']}", file=sys.stderr)
        return False

    out = Path(output_path)
    out.write_text(result["content"], encoding="utf-8")

    metrics = result["metrics"]
    print(f"\nSnapshot written to: {out}")
    print(f"  Files: {metrics['total_files']}")
    print(f"  Lines: {metrics['total_lines']:,}")
    print(f"  Tokens: ~{metrics['token_estimate']:,}")

    return True


def cmd_scan(args):
    """Handle the scan subcommand."""
    from prism.session import PrismSession

    project_root, ep_rel = resolve_paths(args)

    if not args.quiet:
        print(f"Project:     {project_root}")
        print(f"Entry point: {ep_rel}")

    t0 = time.perf_counter()
    session = PrismSession(str(project_root), exclude_patterns=args.exclude or None)
    session.scan(parallel=True)
    scan_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    trace = session.trace_from_entry_point(ep_rel)
    trace_ms = (time.perf_counter() - t0) * 1000

    if "error" in trace:
        print(f"Error: {trace['error']}", file=sys.stderr)
        sys.exit(1)

    connected = trace["total_connected"]

    type_counts = defaultdict(int)
    for f in trace["connected_files"]:
        type_counts[f["type"]] += 1

    if not args.quiet:
        types_str = ", ".join(f"{v} {k}" for k, v in sorted(type_counts.items(), key=lambda x: -x[1]))
        print(f"\nScan: {scan_ms:.0f}ms | Trace: {trace_ms:.0f}ms | {connected} files reachable ({types_str})")

    ep_path = (project_root / ep_rel).resolve()
    ep_node = session.graph.get_node(ep_path)

    if args.dry_run:
        print_dry_run(session.graph, ep_node, args.frontend, args.max_tokens)
        return

    if not args.no_tree and not args.quiet:
        nodes, tree_lines, token_total = build_tree_lines(
            session.graph, ep_node,
            include_frontend=args.frontend,
            max_tokens=args.max_tokens,
            depth_limit=args.depth,
        )
        print_tree(tree_lines, token_total)

    if args.orphans and not args.quiet:
        orphans = session.get_orphans([{"path": ep_rel, "label": "main"}])
        total = len(session.graph.get_nodes())
        print(f"\nOrphans: {orphans['total_orphans']}/{total} files ({orphans['orphan_rate']}%)")
        for o in sorted(orphans["orphans"], key=lambda x: x["relative_path"]):
            print(f"  {o['relative_path']}")

    if args.output:
        nodes, _, _ = build_tree_lines(
            session.graph, ep_node,
            include_frontend=args.frontend,
            max_tokens=args.max_tokens,
            depth_limit=args.depth,
        )
        write_snapshot(session, ep_rel, nodes, project_root, args.output, args)


def cmd_serve(args):
    """Handle the serve subcommand — start the web UI."""
    from zdeps2.api.app_prism import app
    from zdeps2.core.config import get_project_root, get_config_path

    print()
    print("=" * 55)
    print("  Prism — Dependency Viewer (Web UI)")
    print("=" * 55)
    print(f"\n  Project Root: {get_project_root()}")
    print(f"  Config File:  {get_config_path()}")
    print(f"\n  Open in browser: http://localhost:{args.port}")
    print("\n  Press Ctrl+C to stop\n")

    app.run(host=args.host, port=args.port, debug=args.debug)


def main():
    args = parse_args()

    if getattr(args, "command", None) == "serve":
        cmd_serve(args)
    else:
        # scan (explicit or implicit)
        cmd_scan(args)


if __name__ == "__main__":
    main()
