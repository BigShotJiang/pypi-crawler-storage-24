# kronicle/connectors/channel/kronicle_writer.py


from kronicle_sdk.conf.read_conf import Settings
from kronicle_sdk.connectors.rbac.rbac_connector import KronicleRbacConnector
from kronicle_sdk.models.rbac.kronicle_user import KronicleUser
from kronicle_sdk.utils.log import log_d, log_w

if __name__ == "__main__":  # pragma: no-cover
    here = "abstract Kronicle connector"
    log_d(here)
    conf = Settings()
    co = conf.connection_su
    assert co
    kronicle_rbac = KronicleRbacConnector(co.url, co.usr, co.pwd)
    log_d(here, "jwt", kronicle_rbac.jwt)

    usr_list = kronicle_rbac.get_all_users()
    [log_d(here, usr) for usr in usr_list]
    # usr1 = usr_list[0]
    # log_d(here, "usr1 obj", usr1)
    # log_d(here, "usr1.email", usr1.email)

    # log_d("get by email", kronicle_rbac.get_user_by(email=usr1.email))
    # log_d("get by name", kronicle_rbac.get_user_by(name=usr1.name))
    # log_d("get fake name", kronicle_rbac.get_user_by(name=f"{usr1.name}3"))
    usr1 = KronicleUser(
        email="omartine@irisa.fr",
        name=conf.connection.usr,
        orcid="0009-0007-1629-1921",
        full_name="Olivier Martineau",
        password=conf.connection.pwd,
    )
    # usr2 = KronicleUser(
    #     email="myburgh.talon@gmail.com",
    #     name="Talon",
    #     orcid="0000-0003-0804-9362",
    #     full_name="Talon Myburgh",
    #     password="Talon-0003-0804-9362",
    # )
    try:
        res = kronicle_rbac.create_user(usr1)
        log_d(here, "Created", res)
    except Exception as e:
        log_w(here, e)
