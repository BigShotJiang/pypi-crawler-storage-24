"""Data package for PyDebugAI."""
