__version__ = "0.3.0"


def register_steps():
    """Entry point for cogniflow step package discovery."""
    return None


__all__ = ["__version__", "register_steps"]
