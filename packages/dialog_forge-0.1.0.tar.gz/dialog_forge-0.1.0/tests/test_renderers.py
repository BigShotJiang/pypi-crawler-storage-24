"""Tests for platform renderers."""

import pytest

from dialog_forge.models import Conversation
from dialog_forge.renderer import RendererRegistry


SAMPLE_CONVERSATION = {
    "platform": "whatsapp",
    "title": "Test Chat",
    "me": "me",
    "participants": {
        "me": {"name": "You"},
        "friend": {"name": "Friend"},
    },
    "messages": [
        {"sender": "friend", "text": "Hello!", "timestamp": "10:00", "status": "read"},
        {"sender": "me", "text": "Hi there!", "timestamp": "10:01", "status": "delivered"},
        {"sender": "friend", "text": "How are you?", "timestamp": "10:02", "status": "read"},
    ],
}


class TestRendererRegistry:
    def test_available_platforms(self):
        platforms = RendererRegistry.available_platforms()
        assert "whatsapp" in platforms
        assert "instagram" in platforms
        assert "facebook" in platforms

    def test_get_unknown_platform_raises(self):
        with pytest.raises(ValueError, match="No renderer registered"):
            RendererRegistry.get("telegram")


class TestWhatsAppRenderer:
    def test_render_produces_html(self):
        conv = Conversation.from_dict(SAMPLE_CONVERSATION)
        renderer = RendererRegistry.get("whatsapp")
        html = renderer.render(conv)
        assert "<!DOCTYPE html>" in html
        assert "wa-bubble" in html
        assert "Hello!" in html
        assert "Hi there!" in html

    def test_render_contains_status_marks(self):
        conv = Conversation.from_dict(SAMPLE_CONVERSATION)
        renderer = RendererRegistry.get("whatsapp")
        html = renderer.render(conv)
        assert "wa-status" in html
        assert "✓✓" in html

    def test_render_contains_timestamps(self):
        conv = Conversation.from_dict(SAMPLE_CONVERSATION)
        renderer = RendererRegistry.get("whatsapp")
        html = renderer.render(conv)
        assert "10:00" in html
        assert "10:01" in html


class TestInstagramRenderer:
    def test_render_produces_html(self):
        data = {**SAMPLE_CONVERSATION, "platform": "instagram"}
        conv = Conversation.from_dict(data)
        renderer = RendererRegistry.get("instagram")
        html = renderer.render(conv)
        assert "<!DOCTYPE html>" in html
        assert "ig-bubble" in html
        assert "Hello!" in html

    def test_render_contains_seen(self):
        data = {**SAMPLE_CONVERSATION, "platform": "instagram"}
        # Make the last outgoing message "read" to trigger "Seen"
        data["messages"] = [
            {"sender": "friend", "text": "Hello!", "timestamp": "10:00", "status": "read"},
            {"sender": "me", "text": "Hi!", "timestamp": "10:01", "status": "read"},
        ]
        conv = Conversation.from_dict(data)
        renderer = RendererRegistry.get("instagram")
        html = renderer.render(conv)
        assert "Seen" in html


class TestFacebookRenderer:
    def test_render_produces_html(self):
        data = {**SAMPLE_CONVERSATION, "platform": "facebook"}
        conv = Conversation.from_dict(data)
        renderer = RendererRegistry.get("facebook")
        html = renderer.render(conv)
        assert "<!DOCTYPE html>" in html
        assert "fb-bubble" in html
        assert "Hello!" in html

    def test_render_contains_delivery_status(self):
        data = {**SAMPLE_CONVERSATION, "platform": "facebook"}
        conv = Conversation.from_dict(data)
        renderer = RendererRegistry.get("facebook")
        html = renderer.render(conv)
        assert "fb-delivery-status" in html
