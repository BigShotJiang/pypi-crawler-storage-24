"""Tests for dialog_forge.models"""

import pytest

from dialog_forge.models import Conversation, Message, Sender


class TestSender:
    def test_from_dict_minimal(self):
        data = {"name": "Alice"}
        sender = Sender.from_dict(data)
        assert sender.name == "Alice"
        assert sender.avatar is None
        assert sender.gender is None

    def test_from_dict_full(self):
        data = {"name": "Bob", "avatar": "https://example.com/bob.jpg", "gender": "male"}
        sender = Sender.from_dict(data)
        assert sender.name == "Bob"
        assert sender.avatar == "https://example.com/bob.jpg"
        assert sender.gender == "male"


class TestMessage:
    def test_from_dict_minimal(self):
        data = {"sender": "alice", "text": "Hello!"}
        msg = Message.from_dict(data)
        assert msg.sender == "alice"
        assert msg.text == "Hello!"
        assert msg.timestamp == ""
        assert msg.status == "sent"
        assert msg.type == "text"

    def test_from_dict_full(self):
        data = {
            "sender": "bob",
            "text": "Hi there",
            "timestamp": "18:30",
            "status": "read",
            "type": "text",
        }
        msg = Message.from_dict(data)
        assert msg.sender == "bob"
        assert msg.text == "Hi there"
        assert msg.timestamp == "18:30"
        assert msg.status == "read"


class TestConversation:
    SAMPLE_DATA = {
        "platform": "whatsapp",
        "title": "Test Chat",
        "me": "me",
        "participants": {
            "me": {"name": "You"},
            "alice": {"name": "Alice", "avatar": "https://example.com/a.jpg"},
        },
        "messages": [
            {"sender": "alice", "text": "Hello!", "timestamp": "10:00", "status": "read"},
            {"sender": "me", "text": "Hi!", "timestamp": "10:01", "status": "delivered"},
        ],
    }

    def test_from_dict(self):
        conv = Conversation.from_dict(self.SAMPLE_DATA)
        assert conv.platform == "whatsapp"
        assert conv.title == "Test Chat"
        assert conv.me == "me"
        assert len(conv.participants) == 2
        assert len(conv.messages) == 2

    def test_sender_objects_resolved(self):
        conv = Conversation.from_dict(self.SAMPLE_DATA)
        assert conv.messages[0]._sender_obj is not None
        assert conv.messages[0]._sender_obj.name == "Alice"

    def test_default_me(self):
        data = {
            "platform": "instagram",
            "participants": {"me": {"name": "Me"}},
            "messages": [],
        }
        conv = Conversation.from_dict(data)
        assert conv.me == "me"
        assert conv.title == "Chat"

    def test_empty_messages(self):
        data = {
            "platform": "facebook",
            "title": "Empty",
            "participants": {},
            "messages": [],
        }
        conv = Conversation.from_dict(data)
        assert conv.messages == []
        assert conv.participants == {}
