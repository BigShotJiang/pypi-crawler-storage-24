"""Tests for the public API (render_chat)."""

import pytest

from dialog_forge import render_chat


SAMPLE_DATA = {
    "platform": "whatsapp",
    "title": "API Test",
    "me": "me",
    "participants": {
        "me": {"name": "You"},
        "bob": {"name": "Bob"},
    },
    "messages": [
        {"sender": "bob", "text": "Test message", "timestamp": "12:00", "status": "read"},
        {"sender": "me", "text": "Reply", "timestamp": "12:01", "status": "sent"},
    ],
}


class TestRenderChat:
    def test_html_output(self):
        result = render_chat(SAMPLE_DATA, format="html")
        assert isinstance(result, str)
        assert "<!DOCTYPE html>" in result
        assert "Test message" in result

    def test_html_debug_mode(self, capsys):
        result = render_chat(SAMPLE_DATA, format="html", debug=True)
        captured = capsys.readouterr()
        assert "[dialog_forge debug]" in captured.out
        assert isinstance(result, str)

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="Unsupported format"):
            render_chat(SAMPLE_DATA, format="pdf")

    def test_unknown_platform_raises(self):
        data = {**SAMPLE_DATA, "platform": "telegram"}
        with pytest.raises(ValueError, match="No renderer registered"):
            render_chat(data)

    def test_all_platforms_produce_html(self):
        for platform in ("whatsapp", "instagram", "facebook"):
            data = {**SAMPLE_DATA, "platform": platform}
            result = render_chat(data, format="html")
            assert isinstance(result, str)
            assert "<!DOCTYPE html>" in result

    def test_minimal_data(self):
        data = {
            "platform": "whatsapp",
            "participants": {"me": {"name": "Me"}},
            "messages": [{"sender": "me", "text": "Solo message"}],
        }
        result = render_chat(data, format="html")
        assert "Solo message" in result
