"""
Public API for dialog_forge.

Provides the main entry point: render_chat()
"""

from __future__ import annotations

import tempfile
import os

from dialog_forge.models import Conversation
from dialog_forge.renderer import RendererRegistry

# Ensure built-in platforms are registered on first import
import dialog_forge.platforms  # noqa: F401


def render_chat(
    data: dict,
    format: str = "html",
    debug: bool = False,
) -> str | bytes:
    """
    Render a chat conversation mock from a dict/JSON input.

    Args:
        data: Dictionary describing the conversation (see README for schema).
        format: Output format — "html", "png", or "jpg".
        debug: When True and format is an image, saves the intermediate HTML
               to a temp file and prints its path for visual tuning.

    Returns:
        str: The HTML document (when format="html").
        bytes: Image data (when format="png" or "jpg").

    Raises:
        ValueError: If the platform is not recognized or format is invalid.
        ImportError: If image export is requested but Playwright is not installed.
    """
    fmt = format.lower()
    if fmt not in ("html", "png", "jpg", "jpeg"):
        raise ValueError(
            f"Unsupported format '{format}'. Use 'html', 'png', or 'jpg'."
        )

    # Parse input into a Conversation model
    conversation = Conversation.from_dict(data)

    # Select the renderer for the given platform
    renderer = RendererRegistry.get(conversation.platform)

    # Render to HTML
    html = renderer.render(conversation)

    # HTML output mode
    if fmt == "html":
        if debug:
            path = _save_debug_html(html)
            print(f"[dialog_forge debug] HTML saved to: {path}")
        return html

    # Image output mode
    if debug:
        path = _save_debug_html(html)
        print(f"[dialog_forge debug] Intermediate HTML saved to: {path}")

    from dialog_forge.exporters import export_to_image

    return export_to_image(html, fmt=fmt)


def _save_debug_html(html: str) -> str:
    """Save HTML to a temporary file and return its path."""
    fd, path = tempfile.mkstemp(suffix=".html", prefix="dialog_forge_debug_")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(html)
    return path
