"""
Data models for dialog_forge.

Defines the core dataclasses used to represent a chat conversation:
- Sender: a participant in the conversation
- Message: a single chat message
- Conversation: the full conversation container
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Sender:
    """Represents a chat participant."""

    name: str
    avatar: Optional[str] = None  # URL or base64 data URI
    gender: Optional[str] = None  # "male", "female", or None

    @classmethod
    def from_dict(cls, data: dict) -> Sender:
        """Create a Sender from a raw dictionary."""
        return cls(
            name=data["name"],
            avatar=data.get("avatar"),
            gender=data.get("gender"),
        )


@dataclass
class Message:
    """Represents a single chat message."""

    sender: str  # Key referencing a participant in the conversation
    text: str
    timestamp: str = ""  # Display string like "18:30"
    status: str = "sent"  # "sent", "delivered", "read"
    type: str = "text"  # "text" (extensible for future types)

    # Resolved at render time — not expected from user input
    _sender_obj: Optional[Sender] = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: dict) -> Message:
        """Create a Message from a raw dictionary."""
        return cls(
            sender=data["sender"],
            text=data["text"],
            timestamp=data.get("timestamp", ""),
            status=data.get("status", "sent"),
            type=data.get("type", "text"),
        )


@dataclass
class Conversation:
    """
    Represents a full chat conversation.

    Attributes:
        platform: Target platform for styling ("whatsapp", "instagram", "facebook").
        title: Display title of the chat (e.g. contact name or group name).
        participants: Mapping of participant IDs to Sender objects.
        messages: Ordered list of Message objects.
        me: The participant ID representing the local/owner user. Defaults to "me".
    """

    platform: str
    title: str
    participants: dict[str, Sender]
    messages: list[Message]
    me: str = "me"  # Which participant ID is "us" (outgoing messages)

    @classmethod
    def from_dict(cls, data: dict) -> Conversation:
        """
        Parse a raw dictionary (or deserialized JSON) into a Conversation.

        Expected schema:
            {
                "platform": "whatsapp",
                "title": "Chat Title",
                "me": "alice",          # optional, defaults to "me"
                "participants": {
                    "alice": {"name": "Alice", "avatar": null},
                    "bob":   {"name": "Bob",   "avatar": null},
                },
                "messages": [
                    {"sender": "bob", "text": "Hello!", "timestamp": "18:30", "status": "read"},
                    ...
                ]
            }
        """
        participants = {
            pid: Sender.from_dict(pdata)
            for pid, pdata in data.get("participants", {}).items()
        }

        messages = [Message.from_dict(m) for m in data.get("messages", [])]

        # Resolve sender objects on each message for convenience
        for msg in messages:
            msg._sender_obj = participants.get(msg.sender)

        return cls(
            platform=data["platform"],
            title=data.get("title", "Chat"),
            participants=participants,
            messages=messages,
            me=data.get("me", "me"),
        )
