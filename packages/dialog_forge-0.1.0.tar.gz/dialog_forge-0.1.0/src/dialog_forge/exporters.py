"""
Image export functionality for dialog_forge.

Uses Playwright (headless Chromium) to render HTML to PNG or JPG.
Playwright is an optional dependency — install with:
    pip install dialog-forge[export]
"""

from __future__ import annotations

import asyncio
import sys


def _check_playwright_available() -> None:
    """Raise a helpful error if Playwright is not installed."""
    try:
        import playwright  # noqa: F401
    except ImportError:
        raise ImportError(
            "Image export requires Playwright. "
            "Install it with: pip install dialog-forge[export]\n"
            "Then run: python -m playwright install chromium"
        )


async def _render_html_to_image(
    html: str,
    fmt: str = "png",
    width: int = 420,
) -> bytes:
    """
    Render an HTML string to image bytes using Playwright.

    Args:
        html: Complete HTML document string.
        fmt: Image format — "png" or "jpg"/"jpeg".
        width: Viewport width in pixels (height auto-adjusts to content).

    Returns:
        Image bytes in the requested format.
    """
    from playwright.async_api import async_playwright

    fmt_lower = fmt.lower()
    if fmt_lower in ("jpg", "jpeg"):
        screenshot_type = "jpeg"
    else:
        screenshot_type = "png"

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": width, "height": 800})

        await page.set_content(html, wait_until="networkidle")

        # Auto-size the viewport height to fit the content
        content_height = await page.evaluate(
            "() => document.documentElement.scrollHeight"
        )
        await page.set_viewport_size({"width": width, "height": content_height})

        screenshot_bytes = await page.screenshot(
            type=screenshot_type,
            full_page=True,
            quality=95 if screenshot_type == "jpeg" else None,
        )

        await browser.close()

    return screenshot_bytes


def export_to_image(
    html: str,
    fmt: str = "png",
    width: int = 420,
) -> bytes:
    """
    Synchronous wrapper to export HTML to an image.

    Args:
        html: Complete HTML document string.
        fmt: Image format — "png" or "jpg"/"jpeg".
        width: Viewport width in pixels.

    Returns:
        Image file bytes.
    """
    _check_playwright_available()

    # Handle event loop — if one is already running, use it; otherwise create one
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # We're inside an async context; run in a new thread to avoid deadlock
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor() as pool:
            future = pool.submit(
                asyncio.run,
                _render_html_to_image(html, fmt, width),
            )
            return future.result()
    else:
        return asyncio.run(_render_html_to_image(html, fmt, width))
