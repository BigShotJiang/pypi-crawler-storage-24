"""
Base rendering infrastructure for dialog_forge.

Provides:
- BaseRenderer: abstract base class for platform-specific renderers.
- RendererRegistry: global registry mapping platform names to renderer classes.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Type

from dialog_forge.models import Conversation


class BaseRenderer(ABC):
    """
    Abstract base class for chat conversation renderers.

    Subclasses must implement `render()` to produce a self-contained
    HTML string (with embedded CSS) for a given Conversation.
    """

    # Subclasses should set this to their platform identifier
    platform: str = ""

    @abstractmethod
    def render(self, conversation: Conversation) -> str:
        """
        Render a Conversation to a self-contained HTML string.

        Args:
            conversation: The parsed Conversation object.

        Returns:
            A complete HTML document as a string.
        """
        ...


class RendererRegistry:
    """
    Registry that maps platform names to renderer classes.

    Usage:
        RendererRegistry.register("whatsapp", WhatsAppRenderer)
        renderer = RendererRegistry.get("whatsapp")
    """

    _renderers: dict[str, Type[BaseRenderer]] = {}

    @classmethod
    def register(cls, platform: str, renderer_class: Type[BaseRenderer]) -> None:
        """Register a renderer class for a given platform name."""
        cls._renderers[platform.lower()] = renderer_class

    @classmethod
    def get(cls, platform: str) -> BaseRenderer:
        """
        Get an instantiated renderer for the given platform.

        Raises:
            ValueError: If no renderer is registered for the platform.
        """
        key = platform.lower()
        if key not in cls._renderers:
            available = ", ".join(sorted(cls._renderers.keys()))
            raise ValueError(
                f"No renderer registered for platform '{platform}'. "
                f"Available platforms: {available}"
            )
        return cls._renderers[key]()

    @classmethod
    def available_platforms(cls) -> list[str]:
        """Return a sorted list of registered platform names."""
        return sorted(cls._renderers.keys())
