"""
Dialog Forge — Generate realistic chat conversation mocks.

Public API:
    render_chat(data, format="html", debug=False) -> str | bytes
"""

from dialog_forge.api import render_chat
from dialog_forge.models import Conversation, Message, Sender

__all__ = ["render_chat", "Conversation", "Message", "Sender"]
__version__ = "0.1.0"
