"""
Instagram DM renderer.

Produces a self-contained HTML document that closely mimics the Instagram
Direct Messages interface, with gradient purple/pink outgoing bubbles,
light grey incoming bubbles, circular avatars, and "Seen" labels.
"""

from __future__ import annotations

import html as html_module

from dialog_forge.models import Conversation, Message
from dialog_forge.renderer import BaseRenderer

# -- Instagram CSS ---------------------------------------------------------

INSTAGRAM_CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
                 Helvetica, Arial, sans-serif;
    font-size: 14px;
    line-height: 1.4;
    background: #ffffff;
    color: #262626;
    -webkit-font-smoothing: antialiased;
}

/* Header */
.ig-header {
    position: sticky; top: 0; z-index: 10;
    display: flex; align-items: center; gap: 12px;
    background: #ffffff;
    border-bottom: 1px solid #efefef;
    padding: 12px 16px;
    min-height: 60px;
}

.ig-back {
    font-size: 22px; cursor: pointer; color: #262626;
    text-decoration: none;
}

.ig-header-avatar {
    width: 32px; height: 32px;
    border-radius: 50%;
    background: linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045);
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; font-weight: 600; color: #fff;
    flex-shrink: 0;
    overflow: hidden;
}

.ig-header-avatar img {
    width: 100%; height: 100%; object-fit: cover;
}

.ig-header-avatar .ig-avatar-inner {
    width: 28px; height: 28px;
    border-radius: 50%;
    background: #fff;
    display: flex; align-items: center; justify-content: center;
}

.ig-header-name {
    font-size: 16px; font-weight: 600; color: #262626;
}

.ig-header-active {
    font-size: 12px; color: #8e8e8e;
}

/* Chat container */
.ig-chat {
    max-width: 480px;
    margin: 0 auto;
    padding: 16px;
    min-height: calc(100vh - 60px);
    display: flex;
    flex-direction: column;
    gap: 4px;
}

/* Message row */
.ig-msg-row {
    display: flex;
    align-items: flex-end;
    gap: 8px;
}

.ig-msg-row.outgoing {
    justify-content: flex-end;
}

.ig-msg-row.incoming {
    justify-content: flex-start;
}

/* Small avatar next to incoming messages */
.ig-msg-avatar {
    width: 24px; height: 24px;
    border-radius: 50%;
    background: #dbdbdb;
    display: flex; align-items: center; justify-content: center;
    font-size: 11px; font-weight: 600; color: #8e8e8e;
    flex-shrink: 0;
    overflow: hidden;
}

.ig-msg-avatar img {
    width: 100%; height: 100%; object-fit: cover;
}

/* Spacer when avatar is hidden (consecutive messages from same sender) */
.ig-avatar-spacer {
    width: 24px; flex-shrink: 0;
}

/* Bubble */
.ig-bubble {
    max-width: 70%;
    padding: 10px 14px;
    border-radius: 22px;
    word-wrap: break-word;
    position: relative;
}

.ig-bubble.outgoing {
    background: linear-gradient(135deg, #833ab4 0%, #c13584 25%, #e1306c 50%, #fd1d1d 75%, #f56040 100%);
    color: #ffffff;
    border-bottom-right-radius: 4px;
}

.ig-bubble.incoming {
    background: #efefef;
    color: #262626;
    border-bottom-left-radius: 4px;
}

/* Consecutive same-direction bubbles get full radius */
.ig-msg-row.outgoing + .ig-msg-row.outgoing .ig-bubble.outgoing {
    border-radius: 22px;
    border-bottom-right-radius: 4px;
    border-top-right-radius: 4px;
}

.ig-msg-row.incoming + .ig-msg-row.incoming .ig-bubble.incoming {
    border-radius: 22px;
    border-bottom-left-radius: 4px;
    border-top-left-radius: 4px;
}

/* Text */
.ig-text {
    white-space: pre-wrap;
    font-size: 14px;
}

/* Timestamp & status */
.ig-meta {
    text-align: right;
    font-size: 11px;
    color: #8e8e8e;
    margin-top: 2px;
    padding: 0 4px;
}

.ig-meta.outgoing-meta {
    text-align: right;
}

.ig-meta.incoming-meta {
    text-align: left;
    padding-left: 36px;
}

/* Seen label */
.ig-seen {
    font-size: 11px;
    color: #8e8e8e;
    text-align: right;
    padding: 2px 4px 0;
}

/* Input bar */
.ig-input-bar {
    max-width: 480px;
    margin: 0 auto;
    padding: 8px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    border-top: 1px solid #efefef;
}

.ig-input-field {
    flex: 1;
    border: 1px solid #dbdbdb;
    border-radius: 22px;
    padding: 10px 16px;
    font-size: 14px;
    outline: none;
    color: #262626;
}

.ig-input-field::placeholder { color: #8e8e8e; }
"""


class InstagramRenderer(BaseRenderer):
    """Renders a conversation in Instagram Direct style."""

    platform = "instagram"

    def render(self, conversation: Conversation) -> str:
        messages_html = self._render_messages(conversation)
        title = html_module.escape(conversation.title)

        # Resolve the other participant for the header
        other_participants = [
            s for pid, s in conversation.participants.items()
            if pid != conversation.me
        ]
        other = other_participants[0] if other_participants else None
        avatar_html = self._avatar_header(other)
        name = html_module.escape(other.name) if other else title

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} — Instagram</title>
<style>{INSTAGRAM_CSS}</style>
</head>
<body>
<div class="ig-header">
    <span class="ig-back">‹</span>
    <div class="ig-header-avatar">{avatar_html}</div>
    <div>
        <div class="ig-header-name">{name}</div>
        <div class="ig-header-active">Active now</div>
    </div>
</div>
<div class="ig-chat">
{messages_html}
</div>
<div class="ig-input-bar">
    <input class="ig-input-field" placeholder="Message..." disabled>
</div>
</body>
</html>"""

    def _render_messages(self, conversation: Conversation) -> str:
        parts: list[str] = []
        messages = conversation.messages
        last_seen_index = None

        # Find the last outgoing message with status "read" for the "Seen" label
        for i, msg in enumerate(messages):
            if msg.sender == conversation.me and msg.status == "read":
                last_seen_index = i

        for i, msg in enumerate(messages):
            direction = "outgoing" if msg.sender == conversation.me else "incoming"
            text = html_module.escape(msg.text)
            sender_obj = msg._sender_obj

            # Show avatar only for first message in a sequence from the same sender
            prev_same = (i > 0 and messages[i - 1].sender == msg.sender)

            if direction == "incoming":
                if prev_same:
                    avatar_el = '<div class="ig-avatar-spacer"></div>'
                else:
                    avatar_el = (
                        f'<div class="ig-msg-avatar">'
                        f'{self._avatar_small(sender_obj)}</div>'
                    )
                parts.append(f"""    <div class="ig-msg-row {direction}">
        {avatar_el}
        <div class="ig-bubble {direction}">
            <span class="ig-text">{text}</span>
        </div>
    </div>""")
            else:
                parts.append(f"""    <div class="ig-msg-row {direction}">
        <div class="ig-bubble {direction}">
            <span class="ig-text">{text}</span>
        </div>
    </div>""")

            # Add timestamp for the last message in a sequence
            next_same = (
                i + 1 < len(messages) and messages[i + 1].sender == msg.sender
            )
            if not next_same and msg.timestamp:
                align = "outgoing-meta" if direction == "outgoing" else "incoming-meta"
                parts.append(
                    f'    <div class="ig-meta {align}">'
                    f'{html_module.escape(msg.timestamp)}</div>'
                )

            # "Seen" indicator on the very last read outgoing message
            if i == last_seen_index:
                parts.append('    <div class="ig-seen">Seen</div>')

        return "\n".join(parts)

    @staticmethod
    def _avatar_header(sender=None) -> str:
        if sender and sender.avatar:
            return f'<img src="{html_module.escape(sender.avatar)}" alt="">'
        initial = sender.name[0].upper() if sender and sender.name else "?"
        return f'<div class="ig-avatar-inner">{initial}</div>'

    @staticmethod
    def _avatar_small(sender=None) -> str:
        if sender and sender.avatar:
            return f'<img src="{html_module.escape(sender.avatar)}" alt="">'
        initial = sender.name[0].upper() if sender and sender.name else "?"
        return initial
