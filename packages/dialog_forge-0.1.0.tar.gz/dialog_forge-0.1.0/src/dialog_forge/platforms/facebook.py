"""
Facebook Messenger renderer.

Produces a self-contained HTML document that closely mimics the Facebook
Messenger chat interface, with blue outgoing bubbles, light grey incoming
bubbles, small avatars, and delivery status indicators.
"""

from __future__ import annotations

import html as html_module

from dialog_forge.models import Conversation, Message
from dialog_forge.renderer import BaseRenderer

# -- Facebook Messenger CSS -------------------------------------------------

FACEBOOK_CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: 'Segoe UI', Helvetica, Arial, sans-serif;
    font-size: 15px;
    line-height: 1.36;
    background: #ffffff;
    color: #050505;
    -webkit-font-smoothing: antialiased;
}

/* Header */
.fb-header {
    position: sticky; top: 0; z-index: 10;
    display: flex; align-items: center; gap: 12px;
    background: #ffffff;
    border-bottom: 1px solid #e4e6eb;
    padding: 8px 16px;
    min-height: 56px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.fb-back {
    font-size: 22px; cursor: pointer; color: #0084ff;
    text-decoration: none; font-weight: 600;
}

.fb-header-avatar {
    width: 36px; height: 36px;
    border-radius: 50%;
    background: #0084ff;
    display: flex; align-items: center; justify-content: center;
    font-size: 15px; font-weight: 600; color: #fff;
    flex-shrink: 0;
    overflow: hidden;
    position: relative;
}

.fb-header-avatar img {
    width: 100%; height: 100%; object-fit: cover;
}

/* Online dot */
.fb-online-dot {
    width: 10px; height: 10px;
    background: #31a24c;
    border: 2px solid #fff;
    border-radius: 50%;
    position: absolute;
    bottom: 0; right: 0;
}

.fb-header-name {
    font-size: 15px; font-weight: 700; color: #050505;
}

.fb-header-active {
    font-size: 12px; color: #65676b;
}

/* Chat container */
.fb-chat {
    max-width: 480px;
    margin: 0 auto;
    padding: 16px;
    min-height: calc(100vh - 56px);
    display: flex;
    flex-direction: column;
    gap: 2px;
}

/* Message row */
.fb-msg-row {
    display: flex;
    align-items: flex-end;
    gap: 8px;
}

.fb-msg-row.outgoing { justify-content: flex-end; }
.fb-msg-row.incoming { justify-content: flex-start; }

/* Small avatar */
.fb-msg-avatar {
    width: 28px; height: 28px;
    border-radius: 50%;
    background: #e4e6eb;
    display: flex; align-items: center; justify-content: center;
    font-size: 12px; font-weight: 600; color: #65676b;
    flex-shrink: 0;
    overflow: hidden;
}

.fb-msg-avatar img {
    width: 100%; height: 100%; object-fit: cover;
}

.fb-avatar-spacer {
    width: 28px; flex-shrink: 0;
}

/* Bubble */
.fb-bubble {
    max-width: 70%;
    padding: 8px 12px;
    border-radius: 18px;
    word-wrap: break-word;
}

.fb-bubble.outgoing {
    background: #0084ff;
    color: #ffffff;
}

.fb-bubble.incoming {
    background: #e4e6eb;
    color: #050505;
}

/* Radius adjustments for consecutive messages */
.fb-bubble.outgoing {
    border-bottom-right-radius: 4px;
}

.fb-bubble.incoming {
    border-bottom-left-radius: 4px;
}

.fb-msg-row.outgoing + .fb-msg-row.outgoing .fb-bubble.outgoing {
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}

.fb-msg-row.incoming + .fb-msg-row.incoming .fb-bubble.incoming {
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
}

/* Last in sequence gets full bottom radius */
.fb-msg-row.outgoing:has(+ .fb-msg-row.incoming) .fb-bubble.outgoing,
.fb-msg-row.outgoing:last-child .fb-bubble.outgoing {
    border-bottom-right-radius: 18px;
}

.fb-msg-row.incoming:has(+ .fb-msg-row.outgoing) .fb-bubble.incoming,
.fb-msg-row.incoming:last-child .fb-bubble.incoming {
    border-bottom-left-radius: 18px;
}

/* Text */
.fb-text {
    white-space: pre-wrap;
}

/* Sender name (group chats) */
.fb-sender-name {
    font-size: 12px;
    color: #65676b;
    padding-left: 40px;
    margin-bottom: 2px;
}

/* Timestamp */
.fb-meta {
    font-size: 11px;
    color: #65676b;
    margin-top: 2px;
    padding: 0 4px;
}

.fb-meta.outgoing-meta { text-align: right; }
.fb-meta.incoming-meta { text-align: left; padding-left: 40px; }

/* Status — small avatar or text indicator */
.fb-delivery-status {
    display: flex;
    justify-content: flex-end;
    padding: 2px 4px 0;
}

.fb-delivery-icon {
    width: 14px; height: 14px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 8px;
}

.fb-delivery-icon.sent {
    border: 1.5px solid #0084ff;
    color: #0084ff;
    background: #fff;
}

.fb-delivery-icon.delivered {
    border: 1.5px solid #0084ff;
    color: #fff;
    background: #0084ff;
}

.fb-delivery-icon.read {
    background: #e4e6eb;
    overflow: hidden;
}

.fb-delivery-icon.read img {
    width: 100%; height: 100%; object-fit: cover;
}

/* Input bar */
.fb-input-bar {
    max-width: 480px;
    margin: 0 auto;
    padding: 8px 16px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.fb-input-field {
    flex: 1;
    border: none;
    background: #f0f2f5;
    border-radius: 20px;
    padding: 10px 16px;
    font-size: 15px;
    outline: none;
    color: #050505;
}

.fb-input-field::placeholder { color: #65676b; }

.fb-send-btn {
    width: 36px; height: 36px;
    border: none; background: none;
    color: #0084ff;
    font-size: 22px;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
}
"""


class FacebookRenderer(BaseRenderer):
    """Renders a conversation in Facebook Messenger style."""

    platform = "facebook"

    def render(self, conversation: Conversation) -> str:
        messages_html = self._render_messages(conversation)
        title = html_module.escape(conversation.title)

        # Resolve the other participant for the header
        other_participants = [
            s for pid, s in conversation.participants.items()
            if pid != conversation.me
        ]
        other = other_participants[0] if other_participants else None
        avatar_html = self._avatar_header(other)
        name = html_module.escape(other.name) if other else title

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} — Messenger</title>
<style>{FACEBOOK_CSS}</style>
</head>
<body>
<div class="fb-header">
    <span class="fb-back">‹</span>
    <div class="fb-header-avatar">
        {avatar_html}
        <div class="fb-online-dot"></div>
    </div>
    <div>
        <div class="fb-header-name">{name}</div>
        <div class="fb-header-active">Active now</div>
    </div>
</div>
<div class="fb-chat">
{messages_html}
</div>
<div class="fb-input-bar">
    <input class="fb-input-field" placeholder="Aa" disabled>
    <button class="fb-send-btn" disabled>➤</button>
</div>
</body>
</html>"""

    def _render_messages(self, conversation: Conversation) -> str:
        parts: list[str] = []
        messages = conversation.messages

        # Find the last outgoing message for each status to show delivery indicator
        last_outgoing_idx = None
        for i, msg in enumerate(messages):
            if msg.sender == conversation.me:
                last_outgoing_idx = i

        for i, msg in enumerate(messages):
            direction = "outgoing" if msg.sender == conversation.me else "incoming"
            text = html_module.escape(msg.text)
            sender_obj = msg._sender_obj

            prev_same = (i > 0 and messages[i - 1].sender == msg.sender)
            next_same = (
                i + 1 < len(messages) and messages[i + 1].sender == msg.sender
            )

            # Sender name for group chats (incoming, first in sequence)
            if (
                direction == "incoming"
                and not prev_same
                and sender_obj
                and len(conversation.participants) > 2
            ):
                parts.append(
                    f'    <div class="fb-sender-name">'
                    f'{html_module.escape(sender_obj.name)}</div>'
                )

            if direction == "incoming":
                if next_same:
                    avatar_el = '<div class="fb-avatar-spacer"></div>'
                else:
                    avatar_el = (
                        f'<div class="fb-msg-avatar">'
                        f'{self._avatar_small(sender_obj)}</div>'
                    )
                parts.append(f"""    <div class="fb-msg-row {direction}">
        {avatar_el}
        <div class="fb-bubble {direction}">
            <span class="fb-text">{text}</span>
        </div>
    </div>""")
            else:
                parts.append(f"""    <div class="fb-msg-row {direction}">
        <div class="fb-bubble {direction}">
            <span class="fb-text">{text}</span>
        </div>
    </div>""")

            # Timestamp between direction changes or at end of sequence
            if not next_same and msg.timestamp:
                align = (
                    "outgoing-meta" if direction == "outgoing"
                    else "incoming-meta"
                )
                parts.append(
                    f'    <div class="fb-meta {align}">'
                    f'{html_module.escape(msg.timestamp)}</div>'
                )

            # Delivery status on the last outgoing message
            if direction == "outgoing" and i == last_outgoing_idx:
                status_icon = self._delivery_icon(msg.status, conversation)
                parts.append(
                    f'    <div class="fb-delivery-status">{status_icon}</div>'
                )

        return "\n".join(parts)

    @staticmethod
    def _delivery_icon(status: str, conversation: Conversation) -> str:
        """Build the small delivery status icon for Messenger."""
        if status == "read":
            # Show the recipient's mini avatar as "seen" indicator
            others = [
                s for pid, s in conversation.participants.items()
                if pid != conversation.me
            ]
            other = others[0] if others else None
            if other and other.avatar:
                return (
                    f'<div class="fb-delivery-icon read">'
                    f'<img src="{html_module.escape(other.avatar)}" alt=""></div>'
                )
            initial = other.name[0].upper() if other and other.name else "?"
            return (
                f'<div class="fb-delivery-icon read"'
                f' style="background:#e4e6eb;color:#65676b;font-size:8px;">'
                f'{initial}</div>'
            )
        elif status == "delivered":
            return '<div class="fb-delivery-icon delivered">✓</div>'
        else:  # sent
            return '<div class="fb-delivery-icon sent">✓</div>'

    @staticmethod
    def _avatar_header(sender=None) -> str:
        if sender and sender.avatar:
            return f'<img src="{html_module.escape(sender.avatar)}" alt="">'
        initial = sender.name[0].upper() if sender and sender.name else "?"
        return initial

    @staticmethod
    def _avatar_small(sender=None) -> str:
        if sender and sender.avatar:
            return f'<img src="{html_module.escape(sender.avatar)}" alt="">'
        initial = sender.name[0].upper() if sender and sender.name else "?"
        return initial
