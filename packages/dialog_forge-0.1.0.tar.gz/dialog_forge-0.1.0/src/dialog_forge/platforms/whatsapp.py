"""
WhatsApp chat renderer.

Produces a self-contained HTML document that closely mimics the WhatsApp
chat interface, with green outgoing bubbles, white incoming bubbles,
double-check status indicators, and realistic typography.
"""

from __future__ import annotations

import html as html_module

from dialog_forge.models import Conversation, Message
from dialog_forge.renderer import BaseRenderer

# -- WhatsApp CSS ----------------------------------------------------------

WHATSAPP_CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: 'Segoe UI', Helvetica, Arial, sans-serif;
    font-size: 14.2px;
    line-height: 1.35;
    background: #efeae2;
    color: #111b21;
    -webkit-font-smoothing: antialiased;
}

/* Wallpaper doodle overlay */
.wa-wallpaper {
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background-color: #efeae2;
    background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d5cfc6' fill-opacity='0.35'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    z-index: 0;
}

/* Header bar */
.wa-header {
    position: sticky; top: 0; z-index: 10;
    display: flex; align-items: center; gap: 12px;
    background: #008069;
    color: #fff;
    padding: 10px 16px;
    min-height: 56px;
}

.wa-header-avatar {
    width: 40px; height: 40px;
    border-radius: 50%;
    background: #00a884;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px; font-weight: 600; color: #fff;
    flex-shrink: 0;
    overflow: hidden;
}

.wa-header-avatar img {
    width: 100%; height: 100%; object-fit: cover;
}

.wa-header-info { flex: 1; }
.wa-header-title { font-size: 16px; font-weight: 500; }
.wa-header-status { font-size: 13px; opacity: 0.85; }

/* Back arrow */
.wa-back {
    font-size: 22px; cursor: pointer; margin-right: 4px;
}

/* Chat container */
.wa-chat {
    position: relative; z-index: 1;
    max-width: 480px;
    margin: 0 auto;
    padding: 8px 16px 24px;
    min-height: calc(100vh - 56px);
}

/* Message row */
.wa-msg-row {
    display: flex;
    margin-bottom: 2px;
}

.wa-msg-row.outgoing { justify-content: flex-end; }
.wa-msg-row.incoming { justify-content: flex-start; }

/* Bubble */
.wa-bubble {
    max-width: 75%;
    padding: 6px 7px 8px 9px;
    border-radius: 7.5px;
    position: relative;
    word-wrap: break-word;
    box-shadow: 0 1px 0.5px rgba(11,20,26,0.13);
}

.wa-bubble.outgoing {
    background: #d9fdd3;
    border-top-right-radius: 0;
}

.wa-bubble.incoming {
    background: #ffffff;
    border-top-left-radius: 0;
}

/* Sender name for group chats (incoming only) */
.wa-sender-name {
    font-size: 12.8px;
    font-weight: 600;
    color: #1fa855;
    margin-bottom: 2px;
}

/* Message text */
.wa-text {
    white-space: pre-wrap;
}

/* Metadata row (timestamp + status) */
.wa-meta {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 3px;
    margin-top: 2px;
    float: right;
    margin-left: 12px;
    position: relative;
    top: 5px;
}

.wa-time {
    font-size: 11px;
    color: #667781;
}

/* Check marks */
.wa-status {
    font-size: 15px;
    line-height: 1;
    display: inline-flex;
    align-items: center;
}

.wa-status.sent { color: #8696a0; }
.wa-status.delivered { color: #8696a0; }
.wa-status.read { color: #53bdeb; }

/* Tail shapes (CSS triangles) */
.wa-bubble.outgoing::before {
    content: '';
    position: absolute;
    top: 0; right: -8px;
    width: 0; height: 0;
    border-style: solid;
    border-width: 0 0 10px 8px;
    border-color: transparent transparent transparent #d9fdd3;
}

.wa-bubble.incoming::before {
    content: '';
    position: absolute;
    top: 0; left: -8px;
    width: 0; height: 0;
    border-style: solid;
    border-width: 0 8px 10px 0;
    border-color: transparent #ffffff transparent transparent;
}

/* Spacing for first message in a group */
.wa-msg-row + .wa-msg-row.incoming > .wa-bubble.incoming { border-top-left-radius: 7.5px; }
.wa-msg-row + .wa-msg-row.incoming > .wa-bubble.incoming::before { display: none; }
.wa-msg-row + .wa-msg-row.outgoing > .wa-bubble.outgoing { border-top-right-radius: 7.5px; }
.wa-msg-row + .wa-msg-row.outgoing > .wa-bubble.outgoing::before { display: none; }

/* Date chip */
.wa-date-chip {
    text-align: center;
    margin: 12px 0;
}

.wa-date-chip span {
    display: inline-block;
    background: #e1f2fb;
    color: #54656f;
    font-size: 12.5px;
    padding: 5px 12px;
    border-radius: 7.5px;
    box-shadow: 0 1px 0.5px rgba(11,20,26,0.13);
}
"""


class WhatsAppRenderer(BaseRenderer):
    """Renders a conversation in WhatsApp style."""

    platform = "whatsapp"

    def render(self, conversation: Conversation) -> str:
        messages_html = self._render_messages(conversation)
        title = html_module.escape(conversation.title)

        # Build avatar for the header
        other_participants = [
            s for pid, s in conversation.participants.items()
            if pid != conversation.me
        ]
        avatar_html = self._avatar(
            other_participants[0] if other_participants else None
        )

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} — WhatsApp</title>
<style>{WHATSAPP_CSS}</style>
</head>
<body>
<div class="wa-wallpaper"></div>
<div class="wa-header">
    <span class="wa-back">←</span>
    <div class="wa-header-avatar">{avatar_html}</div>
    <div class="wa-header-info">
        <div class="wa-header-title">{title}</div>
        <div class="wa-header-status">online</div>
    </div>
</div>
<div class="wa-chat">
{messages_html}
</div>
</body>
</html>"""

    def _render_messages(self, conversation: Conversation) -> str:
        parts: list[str] = []
        for msg in conversation.messages:
            direction = "outgoing" if msg.sender == conversation.me else "incoming"
            text = html_module.escape(msg.text)
            sender_obj = msg._sender_obj

            # Sender name label (for incoming messages in groups)
            sender_label = ""
            if direction == "incoming" and sender_obj and len(conversation.participants) > 2:
                sender_label = (
                    f'<div class="wa-sender-name">'
                    f'{html_module.escape(sender_obj.name)}</div>'
                )

            # Status indicator (only for outgoing)
            status_html = ""
            if direction == "outgoing":
                status_html = self._status_icon(msg.status)

            # Timestamp
            time_html = ""
            if msg.timestamp:
                time_html = f'<span class="wa-time">{html_module.escape(msg.timestamp)}</span>'

            parts.append(f"""    <div class="wa-msg-row {direction}">
        <div class="wa-bubble {direction}">
            {sender_label}<span class="wa-text">{text}</span><span class="wa-meta">{time_html}{status_html}</span>
        </div>
    </div>""")

        return "\n".join(parts)

    @staticmethod
    def _status_icon(status: str) -> str:
        """Return the double-check icon HTML for a message status."""
        if status == "read":
            return '<span class="wa-status read">✓✓</span>'
        elif status == "delivered":
            return '<span class="wa-status delivered">✓✓</span>'
        else:  # sent
            return '<span class="wa-status sent">✓</span>'

    @staticmethod
    def _avatar(sender=None) -> str:
        """Build avatar HTML — image or initial letter."""
        if sender and sender.avatar:
            return f'<img src="{html_module.escape(sender.avatar)}" alt="">'
        initial = sender.name[0].upper() if sender and sender.name else "?"
        return initial
