"""
Platform renderer registration.

Importing this module registers all built-in platform renderers
with the global RendererRegistry.
"""

from dialog_forge.renderer import RendererRegistry
from dialog_forge.platforms.whatsapp import WhatsAppRenderer
from dialog_forge.platforms.instagram import InstagramRenderer
from dialog_forge.platforms.facebook import FacebookRenderer

# Register all built-in renderers
RendererRegistry.register("whatsapp", WhatsAppRenderer)
RendererRegistry.register("instagram", InstagramRenderer)
RendererRegistry.register("facebook", FacebookRenderer)
