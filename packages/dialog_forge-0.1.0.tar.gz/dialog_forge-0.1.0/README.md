# Dialog Forge

Generate realistic chat conversation mocks from dict/JSON input with platform-specific styling.

## Supported Platforms

- **WhatsApp** — green bubbles, double-check marks, timestamps
- **Instagram** — gradient bubbles, circular avatars, "Seen" labels
- **Facebook Messenger** — blue bubbles, rounded UI, delivery indicators

## Installation

```bash
pip install dialog-forge

# With image export support (PNG/JPG via Playwright)
pip install dialog-forge[export]
```

## Quick Start

```python
from dialog_forge import render_chat

conversation = {
    "platform": "whatsapp",
    "title": "Family Group",
    "participants": {
        "me": {"name": "Alice", "avatar": None},
        "friend": {"name": "Bob", "avatar": None},
    },
    "messages": [
        {
            "sender": "friend",
            "text": "Hey! Are you coming tonight?",
            "timestamp": "18:30",
            "status": "read",
        },
        {
            "sender": "me",
            "text": "Yes! On my way 🚗",
            "timestamp": "18:32",
            "status": "delivered",
        },
    ],
}

# Get HTML string
html = render_chat(conversation)

# Get PNG bytes
png_bytes = render_chat(conversation, format="png")

# Debug mode — prints the intermediate HTML path
html_debug = render_chat(conversation, format="png", debug=True)
```

## API

### `render_chat(data, format="html", debug=False)`

| Parameter | Type   | Default | Description |
|-----------|--------|---------|-------------|
| `data`    | `dict` | —       | Conversation data (see schema below) |
| `format`  | `str`  | `"html"` | Output format: `"html"`, `"png"`, or `"jpg"` |
| `debug`   | `bool` | `False` | When `True`, saves intermediate HTML to a temp file and prints its path |

**Returns:** `str` (HTML) or `bytes` (image data)

### Conversation Schema

```json
{
  "platform": "whatsapp | instagram | facebook",
  "title": "Chat Title",
  "participants": {
    "sender_id": {
      "name": "Display Name",
      "avatar": "https://url-to-avatar.png (optional)",
      "gender": "male | female (optional)"
    }
  },
  "messages": [
    {
      "sender": "sender_id",
      "text": "Message content",
      "timestamp": "HH:MM",
      "status": "sent | delivered | read",
      "type": "text"
    }
  ]
}
```

## Adding a New Platform

1. Create `src/dialog_forge/platforms/your_platform.py`
2. Subclass `BaseRenderer` and implement `render(conversation) -> str`
3. Register it in `src/dialog_forge/platforms/__init__.py`

## License

MIT
