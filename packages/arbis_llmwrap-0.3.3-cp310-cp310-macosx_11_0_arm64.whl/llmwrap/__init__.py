"""
llmwrap: decorator utilities for wrapping LLM-calling functions.

Public API: only wrap_llm_call.
"""
from .core import wrap_llm_call

__all__ = ["wrap_llm_call"]
