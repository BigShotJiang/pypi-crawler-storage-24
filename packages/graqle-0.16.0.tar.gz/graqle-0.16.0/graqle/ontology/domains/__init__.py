"""Domain ontology registrations."""
