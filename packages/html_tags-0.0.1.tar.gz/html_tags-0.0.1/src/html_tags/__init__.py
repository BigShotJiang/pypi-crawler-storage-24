"""concise html tag generation"""
__version__ = '0.0.1'
__author__ = 'Deufel'
from .core import status
__all__ = [
    "status",
]
