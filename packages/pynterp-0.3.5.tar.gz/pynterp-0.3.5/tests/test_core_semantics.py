from __future__ import annotations

import ast
import asyncio
import builtins
import concurrent.futures
import sys
from pathlib import Path

import pytest

from pynterp import Interpreter, expose_class

HAS_TEMPLATE_STR = hasattr(ast, "TemplateStr")
HAS_TYPE_ALIAS = hasattr(ast, "TypeAlias")
HAS_TYPE_PARAMS = hasattr(ast.parse("def f():\n    pass").body[0], "type_params")
HAS_ASYNCIO_PRIVATE_ISCOROUTINEFUNCTION = hasattr(asyncio.coroutines, "_iscoroutinefunction")
HAS_FRAME_F_GENERATOR = hasattr(sys._getframe(), "f_generator")
HAS_INTERPRETER_POOL_EXECUTOR = hasattr(concurrent.futures, "InterpreterPoolExecutor")
if HAS_TEMPLATE_STR:
    import string.templatelib as templatelib

EXPECTED_KITCHEN_RESULT = {
    "flag": "module",
    "sqrt": 9.0,
    "counter": [11, 13, 14],
    "box_scaled": 21,
    "trace": ["enter", "exit"],
    "with_total": 12,
    "pairs": [(0, 1), (0, 2), (2, 1), (2, 2)],
    "squares": {0: 0, 1: 1, 2: 4, 4: 16},
    "unique_mod": {0, 1, 2},
    "gen_values": [100, 101, 102, 103],
    "loop_total": 9,
    "del_error": "NameError",
    "exc_name": "ZeroDivisionError",
    "final_flag": "finally",
    "cascade": [0, 1, 2, "done"],
}


def test_kitchen_sink_fixture_runs(run_interpreter):
    source = (Path(__file__).parent / "fixtures" / "kitchen_sink.py").read_text()
    env = run_interpreter(source, allowed_imports={"math"}, filename="<kitchen_sink>")
    assert env["RESULT"] == EXPECTED_KITCHEN_RESULT


def test_nonlocal_closure(run_interpreter):
    source = """
def outer():
    value = 1
    def inner():
        nonlocal value
        value = value + 1
        return value
    return inner(), inner()

RESULT = outer()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (2, 3)


def test_lambda_closure_and_defaults(run_interpreter):
    source = """
def outer():
    factor = 2
    fn = lambda x, y=3, *, z=4: (x + y) * factor + z
    factor = 5
    return fn(1), fn(1, z=1)

RESULT = outer()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (24, 21)


def test_multiple_lambdas_on_same_line(run_interpreter):
    source = """
f, g = (lambda x: x + 1, lambda y: y * 2)
RESULT = (f(3), g(4))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (4, 8)


def test_nested_same_line_lambdas_with_defaults_bind_correct_scope(run_interpreter):
    source = """
outer = lambda x = lambda y = lambda z=1 : z : y() : x()
RESULT = outer()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == 1


def test_lambda_missing_required_argument_name(run_interpreter):
    source = """
fn = lambda value: value
fn()
"""
    with pytest.raises(TypeError, match=r"<lambda>\(\) missing required argument 'value'"):
        run_interpreter(source)


def test_single_comparison_returns_rich_result_without_bool_coercion(run_interpreter):
    source = """
class Token:
    def __bool__(self):
        raise AssertionError("single comparison should not coerce to bool")

token = Token()

class C:
    def __lt__(self, other):
        return token

RESULT = (C() < C()) is token
"""
    env = run_interpreter(source)
    assert env["RESULT"] is True


def test_chained_comparison_short_circuits_with_first_false_rich_result(run_interpreter):
    source = """
events = []

class Token:
    def __init__(self, name, truth):
        self.name = name
        self.truth = truth

    def __bool__(self):
        events.append(("bool", self.name))
        return self.truth

t1 = Token("t1", False)
t2 = Token("t2", True)

class C:
    def __init__(self, name, result):
        self.name = name
        self.result = result

    def __lt__(self, other):
        events.append(("lt", self.name, other.name))
        return self.result

a = C("a", t1)
b = C("b", t2)
c = C("c", t2)
result = a < b < c
RESULT = (result is t1, events)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, [("lt", "a", "b"), ("bool", "t1")])


def test_user_function_defaults_attributes_drive_call_binding(run_interpreter):
    source = """
def f(a, b=2, /, c=3, *, d=4):
    return (a, b, c, d)

BEFORE = (f.__defaults__, f.__kwdefaults__)
f.__defaults__ = (10, 20, 30)
f.__kwdefaults__ = {"d": 40}
AFTER = (f.__defaults__, f.__kwdefaults__)
RESULT = (f(), f(1), f(1, 2), f(1, 2, 3))
"""
    env = run_interpreter(source)
    assert env["BEFORE"] == ((2, 3), {"d": 4})
    assert env["AFTER"] == ((10, 20, 30), {"d": 40})
    assert env["RESULT"] == (
        (10, 20, 30, 40),
        (1, 20, 30, 40),
        (1, 2, 30, 40),
        (1, 2, 3, 40),
    )


def test_positional_only_name_can_flow_into_kwargs_mapping(run_interpreter):
    source = """
def f(something, /, **kwargs):
    return (something, kwargs)

RESULT = (f(42, something=99), f(42))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ((42, {"something": 99}), (42, {}))


def test_user_function_call_binding_survives_builtin_len_rebind(run_interpreter):
    source = """
def foo():
    return len([1, 2, 3])

def fake_len(_value):
    return 7
"""
    env = run_interpreter(source)
    foo = env["foo"]
    fake_len = env["fake_len"]

    assert foo() == 3
    original_len = builtins.len
    try:
        builtins.len = fake_len
        rebound_result = foo()
    finally:
        builtins.len = original_len
    assert rebound_result == 3


def test_runtime_module_patch_avoids_user_class_descriptor_side_effects(run_interpreter):
    source = """
class C(object):
    def __getattribute__(self, name):
        if name == "__class__":
            raise RuntimeError
        return object.__getattribute__(self, name)

def assert_raises(exc_type, func, *args):
    try:
        func(*args)
    except exc_type:
        return True
    raise AssertionError

def run_case():
    c = C()
    assert_raises(RuntimeError, isinstance, c, bool)
    class D:
        pass
    assert_raises(RuntimeError, isinstance, c, D)
    return True

RESULT = run_case()
"""
    env = run_interpreter(source)
    assert env["RESULT"] is True


def test_globals_builtin_returns_interpreted_module_namespace() -> None:
    source = """
def foo():
    return len([1, 2, 3])

def use_globals():
    ns = globals()
    had_len = "len" in ns
    old_len = ns.get("len")
    ns["len"] = lambda _value: 7
    try:
        return foo()
    finally:
        if had_len:
            ns["len"] = old_len
        else:
            del ns["len"]

RESULT = use_globals()
"""
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<test_globals_builtin>",
        "__builtins__": builtins,
    }
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    interpreter.run(source, env=env, filename="<test_globals_builtin>")
    assert env["RESULT"] == 7


def test_locals_builtin_returns_interpreted_function_locals() -> None:
    source = """
def run():
    local_timer = []
    ns = locals()
    exec("def inner():\\n"
         "    local_timer.append(1)\\n", ns, ns)
    ns["inner"]()
    return len(local_timer)

RESULT = run()
"""
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<test_locals_builtin>",
        "__builtins__": builtins,
    }
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    interpreter.run(source, env=env, filename="<test_locals_builtin>")
    assert env["RESULT"] == 1


def test_exec_builtin_uses_interpreted_function_scope_locals() -> None:
    source = """
def run():
    x = []
    exec("x.append(12)")
    return x

RESULT = run()
"""
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<test_exec_builtin>",
        "__builtins__": builtins,
    }
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    interpreter.run(source, env=env, filename="<test_exec_builtin>")
    assert env["RESULT"] == [12]


def test_exec_with_explicit_globals_locals_uses_runtime_annotation_thunk() -> None:
    source = """
def run():
    gns = {}
    lns = {}
    exec("'docstring'\\n"
         "x: int = 5\\n", gns, lns)
    keys = ("__annotate__" in gns, "__annotate__" in lns, "__annotations__" in lns)
    if "__annotate__" in lns:
        gns.update(lns)  # __annotate__ resolves names from globals.
        annotations = lns["__annotate__"](1)
    else:
        annotations = lns["__annotations__"]
    return keys, annotations, lns["x"]

RESULT = run()
"""
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<test_exec_builtin_explicit_namespaces>",
        "__builtins__": builtins,
    }
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    interpreter.run(source, env=env, filename="<test_exec_builtin_explicit_namespaces>")
    assert env["RESULT"] == ((False, True, False), {"x": int}, 5)


def test_eval_builtin_uses_interpreted_function_scope_locals() -> None:
    source = """
def run():
    x = 7
    return eval("x + 5")

RESULT = run()
"""
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<test_eval_builtin>",
        "__builtins__": builtins,
    }
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    interpreter.run(source, env=env, filename="<test_eval_builtin>")
    assert env["RESULT"] == 12


def test_recursive_user_function_can_build_deep_fstring_shape(run_interpreter) -> None:
    source = """
def create_nested_fstring(n):
    if n == 0:
        return "1+1"
    prev = create_nested_fstring(n - 1)
    return f'f"{{{prev}}}"'

RESULT = create_nested_fstring(160)
"""
    env = run_interpreter(source)
    assert env["RESULT"].startswith('f"{')


def test_module_code_handles_symtable_keyword_incompatibility(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from pynterp import code as code_mod

    called = False

    def raises_keyword_typeerror(_source: str, _filename: str, _mode: str):
        nonlocal called
        called = True
        raise TypeError("_symtable.symtable() takes no keyword arguments")

    monkeypatch.setattr(code_mod.symtable, "symtable", raises_keyword_typeerror)

    module_code = code_mod.ModuleCode("value = 1", filename="<symtable-compat>")
    assert called is True
    assert module_code.sym_root.get_type() == "module"


def test_namedexpr_assigns_and_returns_value(run_interpreter):
    source = """
total = (value := 40) + 2
RESULT = (total, value)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (42, 40)


def test_namedexpr_in_comprehension_binds_outer_scope(run_interpreter):
    source = """
marker = -1
values = [(marker := i) for i in range(4) if (marker := i) % 2 == 0]
nested = [[(marker := j) for j in range(2)] for _ in range(1)]
RESULT = (values, nested, marker)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ([0, 2], [[0, 1]], 1)


def test_typing_runtime_factories_use_interpreted_module_name(run_interpreter):
    source = """
from typing import NewType, ParamSpec, TypeVar, TypeVarTuple

T = TypeVar("T")
P = ParamSpec("P")
Ts = TypeVarTuple("Ts")
Alias = NewType("Alias", int)
RESULT = (T.__module__, P.__module__, Ts.__module__, Alias.__module__)
"""
    env = run_interpreter(source, env={"__name__": "demo_typing_module"})
    assert env["RESULT"] == ("demo_typing_module",) * 4


def test_genericalias_pickle_with_typevar_succeeds(run_interpreter):
    source = """
import pickle
from typing import TypeVar

T = TypeVar("T")
PAYLOAD = pickle.dumps(list[T], protocol=0)
ROUNDTRIP = pickle.loads(PAYLOAD)
RESULT = (isinstance(PAYLOAD, (bytes, bytearray)), str(ROUNDTRIP))
"""
    import sys
    import types

    module_name = "test_pickle_genericalias_mod"
    module = types.ModuleType(module_name)
    env = module.__dict__
    env.update(
        {
            "__name__": module_name,
            "__package__": None,
            "__file__": "<test_pickle_genericalias>",
            "__builtins__": dict(builtins.__dict__),
        }
    )

    previous = sys.modules.get(module_name)
    sys.modules[module_name] = module
    try:
        interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
        interpreter.run(source, env=env, filename="<test_pickle_genericalias>")
    finally:
        if previous is None:
            sys.modules.pop(module_name, None)
        else:
            sys.modules[module_name] = previous
    assert env["RESULT"] == (True, "list[~T]")


def test_user_function_pickle_roundtrip_succeeds():
    source = """
import pickle

def global_pos_only_f(a, b, /):
    return a, b

PAYLOAD = pickle.dumps(global_pos_only_f, protocol=0)
ROUNDTRIP = pickle.loads(PAYLOAD)
RESULT = (
    isinstance(PAYLOAD, (bytes, bytearray)),
    ROUNDTRIP is global_pos_only_f,
    ROUNDTRIP(1, 2),
)
"""
    import sys
    import types

    module_name = "test_pickle_user_function_mod"
    module = types.ModuleType(module_name)
    env = module.__dict__
    env.update(
        {
            "__name__": module_name,
            "__package__": None,
            "__file__": "<test_pickle_user_function>",
            "__builtins__": dict(builtins.__dict__),
        }
    )

    previous = sys.modules.get(module_name)
    sys.modules[module_name] = module
    try:
        interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
        interpreter.run(source, env=env, filename="<test_pickle_user_function>")
    finally:
        if previous is None:
            sys.modules.pop(module_name, None)
        else:
            sys.modules[module_name] = previous

    assert env["RESULT"] == (True, True, (1, 2))


def test_generic_alias_base_resolves_to_origin_type(run_interpreter):
    source = """
class C(list[int]):
    pass

RESULT = (issubclass(C, list), isinstance(C([1]), list), C.__class__ is type)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, True, True)


def test_starred_generic_alias_class_base_unpacks_and_tracks_orig_bases(run_interpreter):
    source = """
bases = (list[int],)

class C(*bases):
    pass

RESULT = (issubclass(C, list), C.__orig_bases__)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, (list[int],))


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_class_with_starred_bases_exposes_type_params(run_interpreter):
    source = """
class Base:
    pass

bases = (Base,)

class C[T](*bases):
    pass

T_param, = C.__type_params__
RESULT = (
    T_param.__name__,
    issubclass(C, Base),
    C.__orig_bases__[0] is Base,
    C.__orig_bases__[1].__name__,
)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("T", True, True, "Generic")


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_class_with_typevartuple_param_is_subscriptable(run_interpreter):
    source = """
class C[*Ts]:
    pass

RESULT = (C[int, str].__args__, C.__type_params__[0].__name__)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ((int, str), "Ts")


def test_local_class_qualname_in_method_scope(run_interpreter):
    source = """
class Outer:
    def make(self):
        class Local(list):
            pass
        return Local.__qualname__

RESULT = Outer().make()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == "Outer.make.<locals>.Local"


def test_init_subclass_defined_in_interpreted_class_is_implicitly_classmethod(run_interpreter):
    source = """
class Base:
    seen = None
    def __init_subclass__(cls):
        Base.seen = cls.__name__
        cls.marker = "ok"

class Child(Base):
    pass

RESULT = (Base.seen, Child.marker)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("Child", "ok")


def test_class_getitem_defined_in_interpreted_class_is_implicitly_classmethod(run_interpreter):
    source = """
class Box:
    def __class_getitem__(cls, item):
        return (cls.__name__, item.__name__)

RESULT = Box[int]
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("Box", "int")


def test_metaclass_prepare_namespace_object_is_used_for_class_body(run_interpreter):
    source = """
class PreparedNamespace(dict):
    def __init__(self):
        super().__init__()
        self.assignment_order = []

    def __setitem__(self, key, value):
        self.assignment_order.append(key)
        return super().__setitem__(key, value)

class Meta(type):
    @classmethod
    def __prepare__(mcls, name, bases, **kwargs):
        ns = PreparedNamespace()
        ns.prepared_flag = "ok"
        return ns

    def __new__(mcls, name, bases, ns, **kwargs):
        cls = super().__new__(mcls, name, bases, dict(ns), **kwargs)
        cls.ns_type = type(ns).__name__
        cls.prepared_flag = ns.prepared_flag
        cls.assignment_order = tuple(ns.assignment_order)
        return cls

class C(metaclass=Meta):
    VALUE = 42

RESULT = (
    C.ns_type,
    C.prepared_flag,
    "__module__" in C.assignment_order,
    "__qualname__" in C.assignment_order,
    "VALUE" in C.assignment_order,
)
"""
    env = run_interpreter(source, env={"classmethod": expose_class(classmethod)})
    assert env["RESULT"] == ("PreparedNamespace", "ok", True, True, True)


def test_enum_intenum_class_uses_enumdict_prepare_namespace():
    source = """
import enum

class Status(enum.IntEnum):
    OK = 200
    NOT_FOUND = 404

RESULT = (
    Status.OK.value,
    Status.__members__["NOT_FOUND"] is Status.NOT_FOUND,
    tuple(Status.__members__.keys()),
)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<enum_intenum_prepare_namespace>",
        "__builtins__": builtins,
    }
    interpreter.run(source, env=env, filename="<enum_intenum_prepare_namespace>")
    assert env["RESULT"] == (200, True, ("OK", "NOT_FOUND"))


def test_class_private_slot_attribute_access_is_name_mangled(run_interpreter):
    source = """
class Rat:
    __slots__ = ["_Rat__num"]

    def __init__(self, value):
        self.__num = value

    def num(self):
        return self.__num

    def bump(self):
        self.__num += 1
        return self.__num

r = Rat(2)
RESULT = (r.num(), r.bump(), hasattr(r, "_Rat__num"), hasattr(r, "__num"))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (2, 3, True, False)


def test_class_private_with_target_name_is_mangled(run_interpreter):
    source = """
class C:
    def f(self):
        class CM:
            def __enter__(self):
                return 7
            def __exit__(self, exc_type, exc, tb):
                return False

        with CM() as __x:
            return __x

RESULT = C().f()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == 7


def test_class_private_augassign_and_namedexpr_targets_are_mangled(run_interpreter):
    source = """
class C:
    def f(self):
        __x = 1
        __x += 2
        (__x := __x + 3)
        return __x

RESULT = C().f()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == 6


def test_class_private_method_definition_name_is_mangled(run_interpreter):
    source = """
class Vector:
    def __cast(self, value):
        return value + 1

    def apply(self, value):
        return self.__cast(value)

v = Vector()
RESULT = (v.apply(2), hasattr(Vector, "_Vector__cast"), hasattr(Vector, "__cast"))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (3, True, False)


@pytest.mark.skipif(not HAS_TYPE_ALIAS, reason="TypeAlias requires Python 3.12+")
def test_typealias_statement_builds_runtime_alias_with_params(run_interpreter):
    source = """
from typing import Callable
type X[**P] = Callable[P, int]
generic = X[[str]]
RESULT = (
    type(X).__name__,
    X.__module__,
    len(X.__type_params__),
    generic.__args__,
    generic.__parameters__,
)
"""
    env = run_interpreter(source, env={"__name__": "demo_typealias_module"})
    assert env["RESULT"] == (
        "TypeAliasType",
        "demo_typealias_module",
        1,
        ([str],),
        (),
    )


@pytest.mark.skipif(not HAS_TYPE_ALIAS, reason="TypeAlias requires Python 3.12+")
def test_typealias_type_params_do_not_leak_to_scope(run_interpreter):
    source = """
type Alias[T] = tuple[T]
try:
    T
except NameError:
    leaked = False
else:
    leaked = True
RESULT = (Alias[int].__args__, leaked)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ((int,), False)


@pytest.mark.skipif(not HAS_TYPE_ALIAS, reason="TypeAlias requires Python 3.12+")
def test_typevartuple_default_star_unpack_is_supported(run_interpreter):
    source = """
default = tuple[int, str]
type Alias[*Ts = *default] = Ts
Ts, = Alias.__type_params__
RESULT = Ts.__default__
"""
    env = run_interpreter(source)
    assert env["RESULT"] == next(iter(tuple[int, str]))


def test_user_function_exposes_empty_type_params_by_default(run_interpreter):
    source = """
def f():
    return 42

RESULT = f.__type_params__
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ()


def test_user_function_exposes_empty_annotations_by_default(run_interpreter):
    source = """
def f(value):
    return value

RESULT = f.__annotations__
"""
    env = run_interpreter(source)
    assert env["RESULT"] == {}


def test_user_function_exposes_annotate_callable(run_interpreter):
    source = """
def f(value: int):
    return value

RESULT = (callable(f.__annotate__), f.__annotate__(1))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, {"value": int})


def test_user_function_annotations_assignment_remains_allowed(run_interpreter):
    source = """
def f(value: int):
    return value

f.__annotations__ = {"value": str, "return": bytes}
RESULT = f.__annotations__
"""
    env = run_interpreter(source)
    assert env["RESULT"] == {"value": str, "return": bytes}


def test_unresolved_function_annotations_are_deferred_as_source_strings(run_interpreter):
    source = """
def f(value: MissingType):
    return value

RESULT = (f.__annotations__, f.__annotate__(1))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ({"value": "MissingType"}, {"value": "MissingType"})


def test_user_defined_class_annotations_assignment_remains_allowed(run_interpreter):
    source = """
class Box:
    pass

Box.__annotations__ = {"value": int}
RESULT = Box.__annotations__
"""
    env = run_interpreter(source)
    assert env["RESULT"] == {"value": int}


def test_function_local_annassign_does_not_evaluate_annotation_expression(run_interpreter):
    source = """
def f():
    x: MissingType
    x: AnotherMissingType = 1
    return x

RESULT = f()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == 1


def test_generator_local_annassign_does_not_evaluate_annotation_expression(run_interpreter):
    source = """
def gen():
    value: MissingType = 7
    yield value

RESULT = list(gen())
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [7]


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_function_records_type_params_without_scope_leak(run_interpreter):
    source = """
def f[T](value: T):
    return value

T_param, = f.__type_params__
try:
    T
except NameError:
    leaked = False
else:
    leaked = True

RESULT = (T_param.__name__, f(7), leaked)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("T", 7, False)


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_function_annotations_capture_type_params(run_interpreter):
    source = """
def func[T](a: T = "a", *, b: T = "b"):
    return (a, b)

T_param, = func.__type_params__
RESULT = (
    func.__annotations__["a"] is T_param,
    func.__annotations__["b"] is T_param,
    func(),
    func(1),
    func(b=2),
)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, True, ("a", "b"), (1, "b"), ("a", 2))


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_nested_generic_function_can_capture_outer_type_param(run_interpreter):
    source = """
def make_generator[A]():
    def generator[B]():
        yield A
        yield B
    return generator

gen = make_generator()
a, b = [value for value in gen()]
RESULT = (a.__name__, b.__name__, gen.__type_params__[0].__name__)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("A", "B", "B")


@pytest.mark.skipif(not HAS_TYPE_ALIAS, reason="TypeAlias requires Python 3.12+")
def test_typealias_lambda_can_capture_type_param(run_interpreter):
    source = """
type Alias[T] = lambda: T
T_param, = Alias.__type_params__
RESULT = Alias.__value__() is T_param
"""
    env = run_interpreter(source)
    assert env["RESULT"] is True


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_class_type_param_is_visible_in_body_and_method_closure(run_interpreter):
    source = """
class C[T]:
    marker = T
    def method(self):
        return T

T_param, = C.__type_params__
RESULT = (C.marker is T_param, C().method() is T_param)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, True)


@pytest.mark.skipif(
    not (HAS_TYPE_ALIAS and HAS_TYPE_PARAMS),
    reason="TypeAlias and type params require Python 3.12+",
)
def test_typealias_lambda_in_generic_class_captures_class_type_param(run_interpreter):
    source = """
class C[T]:
    T = "class"
    type Alias = lambda: T

RESULT = C.Alias.__value__() is C.__type_params__[0]
"""
    env = run_interpreter(source)
    assert env["RESULT"] is True


@pytest.mark.skipif(
    not (HAS_TYPE_ALIAS and HAS_TYPE_PARAMS),
    reason="TypeAlias and type params require Python 3.12+",
)
def test_generic_typealias_lambda_in_generic_class_captures_outer_type_param(run_interpreter):
    source = """
class C[T, U]:
    T = "class"
    U = "class"
    type Alias[T] = lambda: (T, U)

inner_t, outer_u = C.Alias.__value__()
RESULT = (
    inner_t is C.Alias.__type_params__[0],
    outer_u is C.__type_params__[1],
)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, True)


@pytest.mark.skipif(
    not (HAS_TYPE_ALIAS and HAS_TYPE_PARAMS),
    reason="TypeAlias and type params require Python 3.12+",
)
def test_typealias_constraint_comprehension_sees_current_type_param(run_interpreter):
    source = """
type Alias[T: ([T for T in (T, [1])[1]], T)] = [T for T in T.__name__]
T, = Alias.__type_params__
constraint_0, constraint_1 = T.__constraints__
RESULT = (Alias.__value__, constraint_0, constraint_1.__name__)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (["T"], [1], "T")


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_method_private_type_param_capture_uses_mangled_name(run_interpreter):
    source = """
class Foo[__T]:
    def meth[__U](self, arg: __T, arg2: __U):
        return arg

RESULT = (
    Foo.__type_params__[0].__name__,
    Foo.meth.__type_params__[0].__name__,
    Foo.meth.__annotations__["arg"].__name__,
    Foo.meth.__annotations__["arg2"].__name__,
)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("__T", "__U", "__T", "__U")


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_method_body_private_type_params_resolve_in_runtime_scope(run_interpreter):
    source = """
class Foo[__T]:
    def meth[__U](self):
        return (__T, __U)

t, u = Foo().meth()
RESULT = (t is Foo.__type_params__[0], u is Foo.meth.__type_params__[0])
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, True)


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_nested_class_body_skips_outer_class_locals_for_name_loads(run_interpreter):
    source = """
def f():
    T = str
    class C:
        T = int
        class D[U](T):
            marker = T
    return C

C = f()
RESULT = (issubclass(C.D, int), C.D.marker is str)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, True)


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_nested_class_body_prefers_outer_type_params_over_shadowed_class_name(run_interpreter):
    source = """
class Outer[T]:
    T = "class"
    class Inner:
        marker = T

RESULT = Outer.Inner.marker is Outer.__type_params__[0]
"""
    env = run_interpreter(source)
    assert env["RESULT"] is True


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_class_typevar_bounds_are_lazily_evaluated(run_interpreter):
    source = """
def build():
    class Foo[T: Foo, U: (Foo, Foo)]:
        pass

    T, U = Foo.__type_params__
    return (
        T.__bound__ is Foo,
        U.__constraints__ == (Foo, Foo),
    )

RESULT = build()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (True, True)


@pytest.mark.skipif(not HAS_TYPE_PARAMS, reason="Type params require Python 3.12+")
def test_generic_class_typevar_lazy_name_errors_can_resolve_later(run_interpreter):
    source = """
def build():
    class Foo[T: Undefined, U: (Undefined,)]:
        pass

    T, U = Foo.__type_params__
    try:
        T.__bound__
    except NameError:
        bound_before = "NameError"
    else:
        bound_before = "ok"

    try:
        U.__constraints__
    except NameError:
        constraints_before = "NameError"
    else:
        constraints_before = "ok"

    Undefined = "defined"
    return (
        bound_before,
        constraints_before,
        T.__bound__,
        U.__constraints__,
    )

RESULT = build()
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("NameError", "NameError", "defined", ("defined",))


def test_async_function_def_returns_coroutine(run_interpreter):
    source = """
async def add(x, y=3):
    return x + y

CORO = add(4)
"""
    env = run_interpreter(source)
    coro = env["CORO"]
    assert hasattr(coro, "__await__")
    with pytest.raises(StopIteration) as exc_info:
        coro.send(None)
    assert exc_info.value.value == 7


def test_async_user_function_is_detected_as_coroutinefunction() -> None:
    checker_name = (
        "_iscoroutinefunction" if HAS_ASYNCIO_PRIVATE_ISCOROUTINEFUNCTION else "iscoroutinefunction"
    )
    source = f"""
import inspect
from asyncio import coroutines

async def callback():
    return 1

RESULT = (
    inspect.iscoroutinefunction(callback),
    coroutines.{checker_name}(callback),
)
"""
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<async_coro_marker>",
        "__builtins__": builtins,
    }
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    interpreter.run(source, env=env, filename="<async_coro_marker>")
    assert env["RESULT"] == (True, True)


def test_await_expression_uses_custom_awaitable(run_interpreter):
    source = """
class Ready:
    def __init__(self, value):
        self.value = value

    def __await__(self):
        if False:
            yield None
        return self.value

async def run():
    value = await Ready(41)
    return value + 1

CORO = run()
"""
    env = run_interpreter(source)
    coro = env["CORO"]
    with pytest.raises(StopIteration) as exc_info:
        coro.send(None)
    assert exc_info.value.value == 42


def test_await_exception_can_be_handled_in_async_function(run_interpreter):
    source = """
class Boom:
    def __await__(self):
        raise ValueError("boom")
        yield None

async def run():
    try:
        await Boom()
    except ValueError as exc:
        return str(exc)
    return "miss"

CORO = run()
"""
    env = run_interpreter(source)
    coro = env["CORO"]
    with pytest.raises(StopIteration) as exc_info:
        coro.send(None)
    assert exc_info.value.value == "boom"


def test_async_function_def_works_in_generator_execution_path(run_interpreter):
    source = """
def outer():
    async def inner(value):
        return value + 1
    yield inner

INNER = next(outer())
CORO = INNER(9)
"""
    env = run_interpreter(source)
    coro = env["CORO"]
    with pytest.raises(StopIteration) as exc_info:
        coro.send(None)
    assert exc_info.value.value == 10


def test_async_with_calls_aenter_and_aexit(run_interpreter):
    source = """
EVENTS = []

class Manager:
    async def __aenter__(self):
        EVENTS.append(("enter", 5))
        return 5

    async def __aexit__(self, exc_type, exc, tb):
        EVENTS.append(("exit", exc_type.__name__ if exc_type else None))
        return False

async def run():
    async with Manager() as value:
        return value + 1

CORO = run()
"""
    env = run_interpreter(source)
    coro = env["CORO"]
    with pytest.raises(StopIteration) as exc_info:
        coro.send(None)
    assert exc_info.value.value == 6
    assert env["EVENTS"] == [("enter", 5), ("exit", None)]


def test_async_with_can_suppress_exception(run_interpreter):
    source = """
EVENTS = []

class Suppressor:
    async def __aenter__(self):
        EVENTS.append("enter")
        return "token"

    async def __aexit__(self, exc_type, exc, tb):
        EVENTS.append(exc_type.__name__ if exc_type else None)
        return exc_type is ValueError

async def run():
    async with Suppressor():
        raise ValueError("boom")
    return "ok"

CORO = run()
"""
    env = run_interpreter(source)
    coro = env["CORO"]
    with pytest.raises(StopIteration) as exc_info:
        coro.send(None)
    assert exc_info.value.value == "ok"
    assert env["EVENTS"] == ["enter", "ValueError"]


def test_async_with_requires_aexit_method(run_interpreter):
    source = """
BODY = None

class MissingExit:
    async def __aenter__(self):
        return "token"

async def run():
    global BODY
    BODY = False
    async with MissingExit():
        BODY = True

CORO = run()
"""
    env = run_interpreter(source)
    coro = env["CORO"]
    with pytest.raises(TypeError, match=r"asynchronous context manager.*__aexit__"):
        coro.send(None)
    assert env["BODY"] is False


def test_async_with_requires_aenter_method(run_interpreter):
    source = """
BODY = None

class MissingEnter:
    async def __aexit__(self, exc_type, exc, tb):
        return False

async def run():
    global BODY
    BODY = False
    async with MissingEnter():
        BODY = True

CORO = run()
"""
    env = run_interpreter(source)
    coro = env["CORO"]
    with pytest.raises(TypeError, match=r"asynchronous context manager.*__aenter__"):
        coro.send(None)
    assert env["BODY"] is False


def test_async_with_rejects_non_awaitable_enter_and_exit_values(run_interpreter):
    source = """
class BadEnter:
    def __aenter__(self):
        return 123

    async def __aexit__(self, exc_type, exc, tb):
        return False

class BadExit:
    async def __aenter__(self):
        return "ok"

    def __aexit__(self, exc_type, exc, tb):
        return 456

async def run_enter():
    async with BadEnter():
        return "body"

async def run_exit():
    async with BadExit():
        return "body"

CORO_ENTER = run_enter()
CORO_EXIT = run_exit()
"""
    env = run_interpreter(source)

    with pytest.raises(
        TypeError,
        match=r"'async with' received an object from __aenter__ that does not implement __await__: int",
    ):
        env["CORO_ENTER"].send(None)

    with pytest.raises(
        TypeError,
        match=r"'async with' received an object from __aexit__ that does not implement __await__: int",
    ):
        env["CORO_EXIT"].send(None)


def test_async_for_supports_loop_control_and_else(run_interpreter):
    source = """
class AsyncCounter:
    def __init__(self, values):
        self.values = list(values)
        self.aiter_calls = 0

    def __aiter__(self):
        self.aiter_calls += 1
        return self._iterate()

    async def _iterate(self):
        for value in self.values:
            yield value

async def run_break():
    counter = AsyncCounter([1, 2, 3, 4])
    total = 0
    async for value in counter:
        if value == 2:
            continue
        total += value
        if value == 3:
            break
    else:
        total += 100
    return (total, counter.aiter_calls)

async def run_else():
    counter = AsyncCounter([1, 2, 3])
    total = 0
    async for value in counter:
        total += value
    else:
        total += 100
    return (total, counter.aiter_calls)

CORO_BREAK = run_break()
CORO_ELSE = run_else()
"""
    env = run_interpreter(source)
    with pytest.raises(StopIteration) as break_info:
        env["CORO_BREAK"].send(None)
    with pytest.raises(StopIteration) as else_info:
        env["CORO_ELSE"].send(None)
    assert break_info.value.value == (4, 1)
    assert else_info.value.value == (106, 1)


def test_async_for_requires_aiter_method(run_interpreter):
    source = """
async def run():
    async for _ in (1, 2, 3):
        pass

CORO = run()
"""
    env = run_interpreter(source)
    with pytest.raises(TypeError, match="async for'.*__aiter__.*tuple"):
        env["CORO"].send(None)


def test_async_for_invalid_anext_awaitable_sets_cause(run_interpreter):
    source = """
class Bad:
    def __aiter__(self):
        return self

    def __anext__(self):
        return self

    def __await__(self):
        1 / 0
        yield None

async def run():
    async for _ in Bad():
        pass

CORO = run()
"""
    env = run_interpreter(source)
    with pytest.raises(TypeError, match="invalid object from __anext__") as exc_info:
        env["CORO"].send(None)
    assert isinstance(exc_info.value.__cause__, ZeroDivisionError)


def test_async_list_set_dict_comprehensions(run_interpreter):
    source = """
class AsyncCounter:
    def __init__(self, values):
        self.values = list(values)
        self.aiter_calls = 0

    def __aiter__(self):
        self.aiter_calls += 1
        return self._iterate()

    async def _iterate(self):
        for value in self.values:
            yield value

class Ready:
    def __init__(self, value):
        self.value = value

    def __await__(self):
        if False:
            yield None
        return self.value

async def run():
    counter = AsyncCounter([1, 2, 3, 4])
    list_result = [await Ready(value * 2) async for value in counter if value % 2 == 0]
    set_result = {value async for value in AsyncCounter([1, 2, 2, 3])}
    dict_result = {value: await Ready(value + 10) async for value in AsyncCounter([1, 3])}
    return (list_result, set_result, dict_result, counter.aiter_calls)

CORO = run()
"""
    env = run_interpreter(source)
    with pytest.raises(StopIteration) as exc_info:
        env["CORO"].send(None)
    assert exc_info.value.value == ([4, 8], {1, 2, 3}, {1: 11, 3: 13}, 1)


def test_async_generator_expression_produces_async_iterator(run_interpreter):
    source = """
class AsyncCounter:
    def __init__(self, values):
        self.values = list(values)

    def __aiter__(self):
        return self._iterate()

    async def _iterate(self):
        for value in self.values:
            yield value

async def run():
    gen = (value * 3 async for value in AsyncCounter([1, 2, 3]) if value != 2)
    values = []
    async for value in gen:
        values.append(value)
    return (values, hasattr(gen, "__aiter__"), hasattr(gen, "__anext__"))

CORO = run()
"""
    env = run_interpreter(source)
    with pytest.raises(StopIteration) as exc_info:
        env["CORO"].send(None)
    assert exc_info.value.value == ([3, 9], True, True)


def test_generator_expression_with_nested_async_comprehension_is_async(run_interpreter):
    source = """
class AsyncCounter:
    def __init__(self, values):
        self.values = list(values)

    def __aiter__(self):
        return self._iterate()

    async def _iterate(self):
        for value in self.values:
            yield value

async def run():
    gen = ([value + offset async for value in AsyncCounter([1, 2])] for offset in [10, 20])
    buckets = []
    async for values in gen:
        buckets.append(values)
    return (buckets, hasattr(gen, "__aiter__"), hasattr(gen, "__anext__"))

CORO = run()
"""
    env = run_interpreter(source)
    with pytest.raises(StopIteration) as exc_info:
        env["CORO"].send(None)
    assert exc_info.value.value == ([[11, 12], [21, 22]], True, True)


def test_generator_expression_yielding_async_generators_stays_sync_iterable(run_interpreter):
    source = """
class AsyncCounter:
    def __init__(self, values):
        self.values = list(values)

    def __aiter__(self):
        return self._iterate()

    async def _iterate(self):
        for value in self.values:
            yield value

async def run():
    gens = ((value async for value in AsyncCounter(range(limit))) for limit in [3, 5])
    values = [item for gen in gens async for item in gen]
    return (values, hasattr(gens, "__iter__"), hasattr(gens, "__aiter__"))

CORO = run()
"""
    env = run_interpreter(source)
    with pytest.raises(StopIteration) as exc_info:
        env["CORO"].send(None)
    assert exc_info.value.value == ([0, 1, 2, 0, 1, 2, 3, 4], True, False)


def test_async_comprehension_works_in_generator_execution_path(run_interpreter):
    source = """
class AsyncCounter:
    def __init__(self, values):
        self.values = list(values)

    def __aiter__(self):
        return self._iterate()

    async def _iterate(self):
        for value in self.values:
            yield value

def outer():
    async def run():
        return [value async for value in AsyncCounter([1, 2, 3])]
    yield run

RUN = next(outer())
CORO = RUN()
"""
    env = run_interpreter(source)
    with pytest.raises(StopIteration) as exc_info:
        env["CORO"].send(None)
    assert exc_info.value.value == [1, 2, 3]


def test_async_generator_produces_values(run_interpreter):
    source = """
async def numbers():
    yield 1
    yield 2

AGEN = numbers()
"""
    env = run_interpreter(source)
    agen = env["AGEN"]
    assert agen.__aiter__() is agen
    with pytest.raises(StopIteration) as first:
        agen.__anext__().send(None)
    assert first.value.value == 1
    with pytest.raises(StopIteration) as second:
        agen.__anext__().send(None)
    assert second.value.value == 2
    with pytest.raises(StopAsyncIteration):
        agen.__anext__().send(None)


def test_async_generator_asend_passes_values_to_yield_expression(run_interpreter):
    source = """
async def echo():
    incoming = yield "start"
    yield incoming

AGEN = echo()
"""
    env = run_interpreter(source)
    agen = env["AGEN"]
    with pytest.raises(StopIteration) as first:
        agen.__anext__().send(None)
    assert first.value.value == "start"
    with pytest.raises(StopIteration) as second:
        agen.asend("next").send(None)
    assert second.value.value == "next"
    with pytest.raises(StopAsyncIteration):
        agen.__anext__().send(None)


def test_async_generator_supports_await_in_body(run_interpreter):
    source = """
class Ready:
    def __init__(self, value):
        self.value = value

    def __await__(self):
        if False:
            yield None
        return self.value

async def values():
    yield await Ready(3)
    yield await Ready(4)

AGEN = values()
"""
    env = run_interpreter(source)
    agen = env["AGEN"]
    with pytest.raises(StopIteration) as first:
        agen.__anext__().send(None)
    assert first.value.value == 3
    with pytest.raises(StopIteration) as second:
        agen.__anext__().send(None)
    assert second.value.value == 4
    with pytest.raises(StopAsyncIteration):
        agen.__anext__().send(None)


def test_async_generator_wraps_stopasynciteration_as_runtimeerror(run_interpreter):
    source = """
class BadTarget:
    def __setitem__(self, key, value):
        raise StopAsyncIteration(42)

TARGET = BadTarget()

async def source():
    yield 10

async def run():
    gen = (0 async for TARGET[0] in source())
    await gen.asend(None)

CORO = run()
"""
    env = run_interpreter(source, env={"StopAsyncIteration": expose_class(StopAsyncIteration)})
    with pytest.raises(RuntimeError, match="async generator raised StopAsyncIteration") as exc_info:
        env["CORO"].send(None)
    assert isinstance(exc_info.value.__cause__, StopAsyncIteration)
    assert exc_info.value.__cause__.args == (42,)


def test_async_generator_aclose_runs_finally_block(run_interpreter):
    source = """
EVENTS = []

async def stream():
    try:
        yield 1
        yield 2
    finally:
        EVENTS.append("closed")

AGEN = stream()
"""
    env = run_interpreter(source)
    agen = env["AGEN"]
    with pytest.raises(StopIteration) as first:
        agen.__anext__().send(None)
    assert first.value.value == 1
    with pytest.raises(StopIteration) as close_result:
        agen.aclose().send(None)
    assert close_result.value.value is None
    assert env["EVENTS"] == ["closed"]
    with pytest.raises(StopAsyncIteration):
        agen.__anext__().send(None)


def test_namedexpr_works_in_generator_execution_path(run_interpreter):
    source = """
def run():
    total = 0
    yield (total := total + 1)
    yield total

RESULT = list(run())
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [1, 1]


def test_bare_raise_without_active_exception_raises_runtimeerror(run_interpreter):
    with pytest.raises(RuntimeError, match="No active exception to reraise"):
        run_interpreter("raise")


def test_bare_raise_reraises_caught_exception(run_interpreter):
    source = """
try:
    raise ValueError("boom")
except ValueError:
    raise
"""
    with pytest.raises(ValueError, match="boom"):
        run_interpreter(source)


def test_bare_raise_reraises_caught_exception_in_generator_path(run_interpreter):
    source = """
def run():
    try:
        raise ValueError("boom")
    except ValueError:
        raise
    yield "unreachable"

GEN = run()
"""
    env = run_interpreter(source)
    with pytest.raises(ValueError, match="boom"):
        next(env["GEN"])


def test_nested_function_bare_raise_reraises_caught_exception(run_interpreter):
    source = """
def nested():
    raise

def run():
    try:
        raise TypeError("boom")
    except TypeError:
        nested()

run()
"""
    with pytest.raises(TypeError, match="boom"):
        run_interpreter(source)


def test_bare_raise_in_finally_reraises_current_try_exception(run_interpreter):
    source = """
def run():
    try:
        raise TypeError("outer")
    except TypeError:
        try:
            raise KeyError("inner")
        finally:
            raise

run()
"""
    with pytest.raises(KeyError, match="inner"):
        run_interpreter(
            source,
            env={"TypeError": expose_class(TypeError), "KeyError": expose_class(KeyError)},
        )


def test_bare_raise_in_finally_after_except_return_has_no_active_exception(run_interpreter):
    source = """
def run():
    try:
        raise ValueError("boom")
    except ValueError:
        return "handled"
    finally:
        raise

run()
"""
    with pytest.raises(RuntimeError, match="No active exception to reraise"):
        run_interpreter(source)


def test_raise_from_none_suppresses_context(run_interpreter):
    source = """
try:
    try:
        raise TypeError("inner")
    except TypeError:
        raise ValueError("outer") from None
except ValueError as exc:
    RESULT = (
        exc.__cause__,
        exc.__suppress_context__,
        type(exc.__context__).__name__,
    )
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (None, True, "TypeError")


def test_raise_from_invalid_cause_raises_typeerror(run_interpreter):
    with pytest.raises(TypeError, match="exception cause"):
        run_interpreter("raise IndexError from 5", env={"IndexError": expose_class(IndexError)})


def test_raise_from_class_cause_sets_exception_cause(run_interpreter):
    source = """
try:
    raise IndexError from KeyError
except IndexError as exc:
    RESULT = isinstance(exc.__cause__, KeyError)
"""
    env = run_interpreter(
        source,
        env={"IndexError": expose_class(IndexError), "KeyError": expose_class(KeyError)},
    )
    assert env["RESULT"] is True


def test_raise_from_invalid_cause_in_generator_path(run_interpreter):
    source = """
def run():
    raise IndexError from 5
    yield "unreachable"

GEN = run()
"""
    env = run_interpreter(source, env={"IndexError": expose_class(IndexError)})
    with pytest.raises(TypeError, match="exception cause"):
        next(env["GEN"])


def test_trystar_wraps_single_exception_in_group(run_interpreter):
    source = """
try:
    raise ValueError("boom")
except* ValueError as exc:
    RESULT = (
        type(exc).__name__,
        len(exc.exceptions),
        type(exc.exceptions[0]).__name__,
        str(exc.exceptions[0]),
    )
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("ExceptionGroup", 1, "ValueError", "boom")


def test_trystar_splits_and_reraises_unhandled_group_members(run_interpreter):
    source = """
try:
    try:
        raise ExceptionGroup("group", [ValueError("a"), TypeError("b")])
    except* ValueError as exc:
        handled = [type(item).__name__ for item in exc.exceptions]
except ExceptionGroup as exc:
    remaining = [type(item).__name__ for item in exc.exceptions]

RESULT = (handled, remaining)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (["ValueError"], ["TypeError"])


def test_trystar_works_in_generator_execution_path(run_interpreter):
    source = """
def run():
    try:
        raise ExceptionGroup("group", [ValueError("a"), TypeError("b")])
    except* ValueError as exc:
        yield ("value", [type(item).__name__ for item in exc.exceptions])
    except* TypeError as exc:
        yield ("type", [type(item).__name__ for item in exc.exceptions])

RESULT = list(run())
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [("value", ["ValueError"]), ("type", ["TypeError"])]


def test_trystar_sys_exception_tracks_matched_subgroup(run_interpreter):
    source = """
try:
    raise ExceptionGroup("mmu", [Exception("ex"), ValueError("v")])
except* ValueError:
    first = sys.exception()
except* Exception:
    second = sys.exception()

RESULT = (
    [type(item).__name__ for item in first.exceptions],
    [type(item).__name__ for item in second.exceptions],
)
"""
    env = run_interpreter(source, env={"sys": sys})
    assert env["RESULT"] == (["ValueError"], ["Exception"])


def test_trystar_generator_sys_exception_tracks_matched_subgroup(run_interpreter):
    source = """
def run():
    try:
        raise ExceptionGroup("mmu", [Exception("ex"), ValueError("v")])
    except* ValueError:
        first = sys.exception()
        yield [type(item).__name__ for item in first.exceptions]
    except* Exception:
        second = sys.exception()
        yield [type(item).__name__ for item in second.exceptions]

RESULT = list(run())
"""
    env = run_interpreter(source, env={"sys": sys})
    assert env["RESULT"] == [["ValueError"], ["Exception"]]


def test_trystar_rejects_exceptiongroup_handler_type(run_interpreter):
    source = """
try:
    raise ExceptionGroup("group", [ValueError("x")])
except* ExceptionGroup:
    pass
    """
    with pytest.raises(TypeError, match=r"catching ExceptionGroup with except\* is not allowed"):
        run_interpreter(source)


def test_trystar_validates_exception_group_split_contract(run_interpreter):
    source = """
class BadEG1(ExceptionGroup):
    def split(self, *args):
        return "NOT A 2-TUPLE!"

class BadEG2(ExceptionGroup):
    def split(self, *args):
        return ("NOT A 2-TUPLE!",)

RESULT = []
for value in (
    BadEG1("eg", [TypeError(1), ValueError(2)]),
    BadEG2("eg", [TypeError(1), ValueError(2)]),
):
    try:
        try:
            raise value
        except* ValueError:
            pass
        except* TypeError:
            pass
    except TypeError as exc:
        RESULT.append((str(exc), type(exc.__context__).__name__))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [
        ("BadEG1.split must return a tuple, not str", "BadEG1"),
        ("BadEG2.split must return a 2-tuple, got tuple of size 1", "BadEG2"),
    ]


def test_trystar_allows_exception_group_split_with_extra_tuple_members(run_interpreter):
    source = """
class WeirdEG(ExceptionGroup):
    def split(self, *args):
        return super().split(*args) + ("anything", 123456, None)

try:
    raise WeirdEG("eg", [TypeError(1), ValueError(2)])
except* TypeError as exc:
    TYPE_RESULT = [type(item).__name__ for item in exc.exceptions]
except* ValueError as exc:
    VALUE_RESULT = [type(item).__name__ for item in exc.exceptions]

RESULT = (TYPE_RESULT, VALUE_RESULT)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (["TypeError"], ["ValueError"])


def test_match_supports_common_pattern_forms(run_interpreter):
    source = """
class Point:
    __match_args__ = ("x", "y")

    def __init__(self, x, y):
        self.x = x
        self.y = y

subjects = [
    None,
    (0, 1, 2),
    {"a": 1, "b": 2},
    Point(3, 4),
    2,
    "abc",
]
results = []
for item in subjects:
    match item:
        case None:
            results.append("none")
        case [0, *tail]:
            results.append(("seq", tail))
        case {"a": value, **rest}:
            results.append(("map", value, rest))
        case Point(x, y):
            results.append(("class", x + y))
        case 1 | 2 | 3 as number:
            results.append(("or", number))
        case str(text):
            results.append(("str", text))

RESULT = results
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [
        "none",
        ("seq", [1, 2]),
        ("map", 1, {"b": 2}),
        ("class", 7),
        ("or", 2),
        ("str", "abc"),
    ]


def test_match_guard_false_keeps_capture_bindings(run_interpreter):
    source = """
class A:
    VALUE = 0

match 0:
    case x if x:
        outcome = "first"
    case _ as y if y == x and y:
        outcome = "second"
    case A.VALUE:
        outcome = "third"

RESULT = (x, y, outcome)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (0, 0, "third")


def test_match_works_in_generator_execution_path(run_interpreter):
    source = """
def classify(values):
    for item in values:
        match item:
            case 0:
                yield "zero"
            case _:
                yield "other"

RESULT = list(classify([0, 1, 0]))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ["zero", "other", "zero"]


def test_augassign_supports_attribute_and_subscript_targets(run_interpreter):
    source = """
class Box:
    def __init__(self):
        self.items = [1, 2]

box = Box()
alias = box.items
box.items += [3]

nums = [10]
nums[0] += 5

RESULT = (box.items, alias, nums, alias is box.items)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ([1, 2, 3], [1, 2, 3], [15], True)


def test_augassign_works_in_generator_execution_path(run_interpreter):
    source = """
class Box:
    def __init__(self):
        self.total = 1

def run():
    box = Box()
    values = [4]
    box.total += 2
    values[0] += 3
    yield box.total, values[0]

RESULT = list(run())
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [(3, 7)]


def test_starred_expression_supports_collection_literals(run_interpreter):
    source = """
values = (2, 3)
RESULT = (
    [1, *values, 4],
    (0, *values, 5),
    {1, *values, 6},
)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ([1, 2, 3, 4], (0, 2, 3, 5), {1, 2, 3, 6})


def test_starred_assignment_target_unpacks_values(run_interpreter):
    source = """
first, *middle, last = range(6)
[left, *rest] = [10, 20, 30, 40]
RESULT = (first, middle, last, left, rest)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (0, [1, 2, 3, 4], 5, 10, [20, 30, 40])


def test_starred_assignment_works_in_generator_execution_path(run_interpreter):
    source = """
def run():
    head, *body, tail = [1, 2, 3, 4]
    yield head, body, tail

RESULT = list(run())
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [(1, [2, 3], 4)]


def test_attr_guard_blocks_module_loader_metadata_and_allows_bound_method_func(run_interpreter):
    source = """
import math

class Box:
    def value(self):
        return 42

box = Box()
try:
    math.__spec__
except Exception as blocked:
    blocked_spec = (type(blocked).__name__, str(blocked))

try:
    math.__loader__
except Exception as blocked:
    blocked_loader = (type(blocked).__name__, str(blocked))

RESULT = (blocked_spec, blocked_loader, box.value.__func__.__name__)
"""
    env = run_interpreter(source, allowed_imports={"math"})
    assert env["RESULT"] == (
        ("AttributeError", "attribute access to '__spec__' is blocked in this environment"),
        (
            "AttributeError",
            "attribute access to '__loader__' is blocked in this environment",
        ),
        "value",
    )


def test_attr_guard_allows_getattribute_call_but_still_blocks_sensitive_names(run_interpreter):
    source = """
class Box:
    def __init__(self):
        self.value = 42

box = Box()
bound = box.__getattribute__
unbound = object.__getattribute__
SAFE = (bound("value"), unbound(box, "value"))

try:
    bound("__dict__")
except Exception as blocked:
    BLOCKED_BOUND = (type(blocked).__name__, str(blocked))

try:
    unbound(box, "__dict__")
except Exception as blocked:
    BLOCKED_UNBOUND = (type(blocked).__name__, str(blocked))

RESULT = (SAFE, BLOCKED_BOUND, BLOCKED_UNBOUND)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (
        (42, 42),
        (
            "AttributeError",
            "attribute access to '__dict__' is blocked in this environment",
        ),
        (
            "AttributeError",
            "attribute access to '__dict__' is blocked in this environment",
        ),
    )


def test_object_getattribute_delegate_in_user_function_does_not_recurse(run_interpreter):
    source = """
class Box:
    def __init__(self):
        self.value = 42

    def __getattribute__(self, name):
        return object.__getattribute__(self, name)

box = Box()
RESULT = box.value
"""
    env = run_interpreter(source)
    assert env["RESULT"] == 42


def test_bound_method_allows_keyword_named_self(run_interpreter):
    source = """
class Box:
    def capture(instance, **kwargs):
        return (instance.value, kwargs["self"])

box = Box()
box.value = "bound"
RESULT = box.capture(self="keyword")
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("bound", "keyword")


def test_attr_guard_blocks_traceback_frame(run_interpreter):
    source = """
try:
    1 / 0
except Exception as exc:
    tb = exc.__traceback__
    try:
        _ = tb.tb_frame
    except Exception as blocked_tb_frame_exc:
        blocked_tb_frame_info = (
            type(blocked_tb_frame_exc).__name__,
            str(blocked_tb_frame_exc),
        )
    else:
        blocked_tb_frame_info = None

    RESULT = (tb is not None, blocked_tb_frame_info)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (
        True,
        (
            "AttributeError",
            "attribute access to 'tb_frame' is blocked in this environment",
        ),
    )


def test_attr_guard_blocks_traceback_chain_navigation_with_tb_next(run_interpreter):
    source = """
def boom():
    1 / 0

def run():
    boom()

try:
    run()
except Exception as exc:
    tb = exc.__traceback__
    try:
        _ = tb.tb_next
    except Exception as blocked_tb_next_exc:
        RESULT = (type(blocked_tb_next_exc).__name__, str(blocked_tb_next_exc))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (
        "AttributeError",
        "attribute access to 'tb_next' is blocked in this environment",
    )


def test_attr_guard_blocks_coroutine_frame(run_interpreter):
    source = """
async def compute():
    return 1

co = compute()
try:
    _ = co.cr_frame
except Exception as blocked:
    BLOCKED = (type(blocked).__name__, str(blocked))
else:
    BLOCKED = None
co.close()
RESULT = BLOCKED
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (
        "AttributeError",
        "attribute access to 'cr_frame' is blocked in this environment",
    )


def test_attr_guard_blocks_coroutine_frame_in_generator_execution_path(run_interpreter):
    source = """
async def compute():
    return 1

def run():
    co = compute()
    try:
        _ = co.cr_frame
    except Exception as blocked:
        blocked_info = (type(blocked).__name__, str(blocked))
    else:
        blocked_info = None
    co.close()
    yield blocked_info

RESULT = list(run())
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [
        (
            "AttributeError",
            "attribute access to 'cr_frame' is blocked in this environment",
        )
    ]


def test_attr_guard_blocks_async_generator_frame(run_interpreter):
    source = """
async def produce():
    yield 1

ag = produce()
try:
    _ = ag.ag_frame
except Exception as blocked:
    blocked_info = (type(blocked).__name__, str(blocked))
else:
    blocked_info = None

RESULT = (ag.ag_running, blocked_info)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (
        False,
        (
            "AttributeError",
            "attribute access to 'ag_frame' is blocked in this environment",
        ),
    )


def test_attr_guard_blocks_async_generator_ag_code(run_interpreter):
    source = """
async def gen():
    yield 1

ag = gen()
try:
    _ = ag.ag_code
except Exception as blocked:
    RESULT = (type(blocked).__name__, str(blocked))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (
        "AttributeError",
        "attribute access to 'ag_code' is blocked in this environment",
    )


def test_attr_guard_blocks_class_bases_and_subclasses(run_interpreter):
    source = """
class Derived(list):
    pass

try:
    _ = Derived.__bases__
except Exception as blocked_bases:
    BLOCKED_BASES = (type(blocked_bases).__name__, str(blocked_bases))

try:
    _ = list.__subclasses__
except Exception as blocked_subclasses:
    BLOCKED_SUBCLASSES = (type(blocked_subclasses).__name__, str(blocked_subclasses))

RESULT = (BLOCKED_BASES, BLOCKED_SUBCLASSES)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (
        (
            "AttributeError",
            "attribute access to '__bases__' is blocked in this environment",
        ),
        (
            "AttributeError",
            "attribute access to '__subclasses__' is blocked in this environment",
        ),
    )


def test_comprehension_target_does_not_leak(run_interpreter):
    source = """
x = 99
_ = [x for x in range(3)]
RESULT = x
"""
    env = run_interpreter(source)
    assert env["RESULT"] == 99


def test_list_comprehension_lambda_closure_uses_shared_iteration_cell(run_interpreter):
    source = """
items = [(lambda: i) for i in range(5)]
RESULT = [fn() for fn in items]
"""
    env = run_interpreter(source)
    assert env["RESULT"] == [4, 4, 4, 4, 4]


def test_class_scope_comprehension_lambda_closure_and_class_cell(run_interpreter):
    source = """
class C:
    def method(self):
        super()
        return __class__

    items = [(lambda: i) for i in range(5)]
    y = [fn() for fn in items]

RESULT = (C.y, C().method() is C)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ([4, 4, 4, 4, 4], True)


def test_import_restriction(run_interpreter):
    source = """
import os
"""
    with pytest.raises(ImportError):
        run_interpreter(source, allowed_imports={"math"})


def test_import_dotted_module_as_alias_binds_leaf_module():
    source = """
import unittest.mock as mock
import xml.parsers.expat.errors as ERRORS
RESULT = (
    mock.__name__,
    hasattr(mock, "patch"),
    ERRORS.__name__.endswith(".errors"),
    hasattr(ERRORS, "codes"),
)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename="<import_asname>")
    assert env["RESULT"] == ("unittest.mock", True, True, True)


def test_import_dotted_module_without_alias_binds_top_level_name():
    source = """
import xml.parsers.expat.errors
RESULT = (xml.__name__, hasattr(xml, "parsers"))
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename="<import_top_level>")
    assert env["RESULT"] == ("xml", True)


def test_importlib_metadata_available_without_importlib_import_module(run_interpreter):
    source = """
import importlib.metadata
import importlib.metadata as metadata_alias

RESULT = (
    importlib.__name__,
    importlib.metadata.__name__,
    metadata_alias is importlib.metadata,
    hasattr(importlib.metadata, "version"),
    hasattr(importlib, "import_module"),
)
"""
    env = run_interpreter(source)
    assert env["RESULT"] == ("importlib", "importlib.metadata", True, True, False)


def test_user_function_exposes_inspect_signature_with_full_parameter_kinds(run_interpreter):
    source = """
def sample(a, /, b, c=3, *args, d, e=5, **kwargs):
    return (a, b, c, args, d, e, kwargs)

fn = lambda x, y=2, *, z=3: (x, y, z)

RESULT = (str(sample.__signature__), str(fn.__signature__))
"""
    env = run_interpreter(source)
    assert env["RESULT"] == (
        "(a, /, b, c=3, *args, d, e=5, **kwargs)",
        "(x, y=2, *, z=3)",
    )


def test_xmlrpc_server_html_doc_handles_user_function_lambda_signature():
    import xmlrpc.server

    source = """
fn = lambda: 1
signature_text = str(fn.__signature__)
doc = XMLRPC_DOC.docroutine(fn, "fn")
RESULT = (signature_text, "()</dt>" in doc)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<xmlrpc_user_function_signature>",
        "__builtins__": dict(builtins.__dict__),
        "XMLRPC_DOC": xmlrpc.server.ServerHTMLDoc(),
    }
    interpreter.run(source, env=env, filename="<xmlrpc_user_function_signature>")
    assert env["RESULT"] == ("()", True)


def test_user_function_supports_weakref(run_interpreter):
    import weakref

    source = """
def f():
    return 42

ref = WEAKREF.ref(f)
RESULT = (ref() is f, ref()())
"""
    env = run_interpreter(source, env={"WEAKREF": weakref})
    assert env["RESULT"] == (True, 42)


def test_functools_wraps_keeps_wrapper_behavior_for_user_function():
    source = """
import functools

events = []

def dec(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        events.append("wrapper")
        return fn(*args, **kwargs)
    return wrapper

@dec
def target():
    events.append("target")

target()
RESULT = (tuple(events), target.__name__, target.__wrapped__.__name__)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<functools_wraps_user_function>",
        "__builtins__": builtins,
    }
    interpreter.run(source, env=env, filename="<functools_wraps_user_function>")
    assert env["RESULT"] == (("wrapper", "target"), "target", "target")


def test_functools_wraps_copies_user_function_annotate_thunk():
    source = """
import functools

def f(value: MissingType):
    return value

def wrapper(*args, **kwargs):
    return f(*args, **kwargs)

functools.update_wrapper(wrapper, f)
RESULT = (
    hasattr(f, "__annotate__"),
    hasattr(wrapper, "__annotate__"),
    wrapper.__annotate__ is f.__annotate__,
)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<functools_wraps_user_function_annotate>",
        "__builtins__": builtins,
    }
    interpreter.run(source, env=env, filename="<functools_wraps_user_function_annotate>")
    assert env["RESULT"] == (True, True, True)


def test_unittest_loader_loads_user_function_test_method_without_calling_it():
    source = """
import types
import unittest

m = types.ModuleType("m")

class MyTestCase(unittest.TestCase):
    test = lambda: 1

m.testcase_1 = MyTestCase
loader = unittest.TestLoader()
suite = loader.loadTestsFromNames(["testcase_1.test"], m)
inner = list(suite)[0]
tests = list(inner)
RESULT = (
    isinstance(suite, loader.suiteClass),
    len(tests),
    type(tests[0]).__name__,
    tests[0]._testMethodName,
)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<unittest_loader_user_function_method>",
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename="<unittest_loader_user_function_method>")
    assert env["RESULT"] == (True, 1, "MyTestCase", "test")


def test_unittest_loader_keeps_staticmethod_callable_path():
    source = """
import types
import unittest

m = types.ModuleType("m")

class Test1(unittest.TestCase):
    def test(self):
        pass

testcase_1 = Test1("test")

class Foo(unittest.TestCase):
    @staticmethod
    def foo():
        return testcase_1

m.Foo = Foo
loader = unittest.TestLoader()
suite = loader.loadTestsFromNames(["Foo.foo"], m)
inner = list(suite)[0]
tests = list(inner)
RESULT = (len(tests), tests[0] is testcase_1)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<unittest_loader_user_function_staticmethod>",
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename="<unittest_loader_user_function_staticmethod>")
    assert env["RESULT"] == (1, True)


def test_unittest_expected_failure_marker_on_user_function_method_is_honored():
    source = """
import io
import unittest

class MyTestCase(unittest.TestCase):
    @unittest.expectedFailure
    def test_expected(self):
        self.fail("boom")

suite = unittest.defaultTestLoader.loadTestsFromTestCase(MyTestCase)
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=0).run(suite)
RESULT = (
    len(result.failures),
    len(result.errors),
    len(result.expectedFailures),
    len(result.unexpectedSuccesses),
)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<unittest_expected_failure_user_function_method>",
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename="<unittest_expected_failure_user_function_method>")
    assert env["RESULT"] == (0, 0, 1, 0)


def test_asyncio_format_helpers_resolves_user_function_source():
    source = (
        "from asyncio import format_helpers\n\n"
        "def _fakefunc(f):\n"
        "    return f\n\n"
        "SOURCE = format_helpers._get_function_source(_fakefunc)\n"
        "TEXT = format_helpers._format_callback_source(_fakefunc, ())\n"
    )
    filename = "<asyncio_user_function_source>"
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": filename,
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename=filename)
    assert env["SOURCE"] == (filename, 3)
    assert env["TEXT"] == f"_fakefunc() at {filename}:3"


def test_interpreters_run_func_accepts_interpreted_function():
    pytest.importorskip("_interpreters")
    source = """
import os

import _interpreters
interp = _interpreters.create()
r, w = os.pipe()

def script():
    global w
    import contextlib
    with open(w, "w", encoding="utf-8") as spipe:
        with contextlib.redirect_stdout(spipe):
            print("it worked!", end="")

try:
    _interpreters.set___main___attrs(interp, dict(w=w))
    _interpreters.run_func(interp, script)
    with open(r, encoding="utf-8") as outfile:
        RESULT = outfile.read()
finally:
    _interpreters.destroy(interp)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<interpreters_run_func_ok>",
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename="<interpreters_run_func_ok>")
    assert env["RESULT"] == "it worked!"


def test_interpreters_run_func_rejects_interpreted_function_with_args():
    pytest.importorskip("_interpreters")
    source = """
import _interpreters
interp = _interpreters.create()

def script(arg):
    return arg

try:
    _interpreters.run_func(interp, script)
except Exception as exc:
    RESULT = (type(exc).__name__, str(exc))
finally:
    _interpreters.destroy(interp)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<interpreters_run_func_args>",
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename="<interpreters_run_func_args>")
    assert env["RESULT"][0] == "ValueError"


def test_interpreters_run_func_lambda_preserves_shared_encoding_errors():
    pytest.importorskip("_interpreters")
    if sys.version_info[:2] == (3, 13):
        pytest.skip("CPython 3.13 _interpreters.run_func segfaults on invalid shared dict keys")
    source = """
import _interpreters
interp = _interpreters.create()
bad_shared = {"\\ud82a": 0}

try:
    _interpreters.run_func(interp, lambda: None, shared=bad_shared)
except Exception as exc:
    RESULT = (type(exc).__name__, str(exc))
finally:
    _interpreters.destroy(interp)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "__main__",
        "__package__": None,
        "__file__": "<interpreters_run_func_lambda_shared_encoding>",
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename="<interpreters_run_func_lambda_shared_encoding>")
    assert env["RESULT"][0] == "UnicodeEncodeError"
    assert "surrogates not allowed" in env["RESULT"][1]


@pytest.mark.skipif(
    not HAS_INTERPRETER_POOL_EXECUTOR,
    reason="InterpreterPoolExecutor is not available on this Python runtime",
)
def test_interpreter_pool_initializer_accepts_interpreted_functions(tmp_path: Path, monkeypatch):
    pytest.importorskip("_interpreters")
    module_name = "pynterp_interpreter_pool_fixture"
    module_path = tmp_path / f"{module_name}.py"
    module_source = """
STATE = "uninitialized"

def init(value):
    global STATE
    STATE = value
    STATE

def get_state():
    return STATE

"""
    source = """
from concurrent.futures import InterpreterPoolExecutor

STATE = "uninitialized"

def init(value):
    global STATE
    STATE = value
    STATE

def get_state():
    return STATE

with InterpreterPoolExecutor(max_workers=1, initializer=init, initargs=("initialized",)) as ex:
    RESULT = ex.submit(get_state).result(timeout=5)
"""
    module_path.write_text(module_source)
    monkeypatch.syspath_prepend(str(tmp_path))
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": module_name,
        "__package__": None,
        "__file__": str(module_path),
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(
        source,
        env=env,
        filename=str(module_path),
    )
    assert env["RESULT"] == "initialized"


@pytest.mark.skipif(not HAS_TEMPLATE_STR, reason="TemplateStr requires Python 3.14+")
def test_templatestr_builds_template_with_interpolation_metadata(run_interpreter):
    source = """
name = "Bob"
width = 5
RESULT = t"hello {name!r:{width}}!"
"""
    env = run_interpreter(source)
    template = env["RESULT"]
    assert isinstance(template, templatelib.Template)
    assert template.strings == ("hello ", "!")
    assert template.values == ("Bob",)
    assert len(template.interpolations) == 1
    interpolation = template.interpolations[0]
    assert isinstance(interpolation, templatelib.Interpolation)
    assert interpolation.value == "Bob"
    assert interpolation.expression == "name"
    assert interpolation.conversion == "r"
    assert interpolation.format_spec == "5"


@pytest.mark.skipif(not HAS_TEMPLATE_STR, reason="TemplateStr requires Python 3.14+")
def test_templatestr_works_in_generator_execution_path(run_interpreter):
    source = """
def run():
    value = 42
    yield t"{value=}"

RESULT = list(run())
"""
    env = run_interpreter(source)
    [template] = env["RESULT"]
    assert isinstance(template, templatelib.Template)
    assert template.strings == ("value=", "")
    assert template.values == (42,)
    [interpolation] = template.interpolations
    assert interpolation.expression == "value"
    assert interpolation.conversion == "r"
    assert interpolation.format_spec == ""


@pytest.mark.skipif(not HAS_TEMPLATE_STR, reason="TemplateStr requires Python 3.14+")
def test_template_constructor_positional_call_without_empty_kwargs(run_interpreter):
    source = """
from string.templatelib import Template, Interpolation
RESULT = Template(Interpolation("Maria", "name", None, ""))
"""
    env = run_interpreter(source)
    template = env["RESULT"]
    assert isinstance(template, templatelib.Template)
    assert template.strings == ("", "")
    assert template.values == ("Maria",)


def test_from_import_relative_without_module_name_level_one(monkeypatch, tmp_path):
    package = tmp_path / "pkg_relimport_level_one"
    package.mkdir()
    (package / "__init__.py").write_text("")
    (package / "helper.py").write_text("VALUE = 42\n")
    monkeypatch.syspath_prepend(str(tmp_path))

    source = """
from . import helper
from .helper import VALUE as COPIED
RESULT = (helper.VALUE, COPIED)
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "pkg_relimport_level_one.consumer",
        "__package__": "pkg_relimport_level_one",
        "__file__": str(package / "consumer.py"),
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename=str(package / "consumer.py"))

    assert env["RESULT"] == (42, 42)


def test_from_import_relative_without_module_name_level_two(monkeypatch, tmp_path):
    package = tmp_path / "pkg_relimport_level_two"
    subpackage = package / "subpkg"
    package.mkdir()
    subpackage.mkdir()
    (package / "__init__.py").write_text("")
    (subpackage / "__init__.py").write_text("")
    (package / "helper.py").write_text("FLAG = 'ok'\n")
    monkeypatch.syspath_prepend(str(tmp_path))

    source = """
from .. import helper
RESULT = helper.FLAG
"""
    interpreter = Interpreter(allowed_imports=None, allow_relative_imports=True)
    env = {
        "__name__": "pkg_relimport_level_two.subpkg.consumer",
        "__package__": "pkg_relimport_level_two.subpkg",
        "__file__": str(subpackage / "consumer.py"),
        "__builtins__": dict(builtins.__dict__),
    }
    interpreter.run(source, env=env, filename=str(subpackage / "consumer.py"))

    assert env["RESULT"] == "ok"
