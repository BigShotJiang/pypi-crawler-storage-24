# SPDX-License-Identifier: GPL-3.0-or-later
"""Local AI Agent Orchestrator -- multi-phase LM Studio coding pipeline."""

__version__ = "2.2.1"
