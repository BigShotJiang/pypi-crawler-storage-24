"""Animus Bootstrap — install daemon, onboarding wizard, and local dashboard."""

__version__ = "0.8.0"
