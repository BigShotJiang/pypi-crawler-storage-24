from .clear_terminal import (
    clear_terminal,
)