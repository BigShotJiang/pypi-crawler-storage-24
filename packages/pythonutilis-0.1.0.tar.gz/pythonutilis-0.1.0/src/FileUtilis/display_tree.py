import os
from colorama import init, Fore, Style

init(autoreset=True)

def display_tree(root_dir, max_level=1, extension_colors=None, dir_color=Fore.YELLOW, name_colors=None, dir_name_colors=None):
    """Displays a colored directory tree.
    
    Priority for file coloring:
    1. name_colors (exact match)
    2. dir_name_colors (based on parent directory name)
    3. extension_colors (based on file extension)
    """

    # Initialize default dictionaries if None
    if extension_colors is None:
        extension_colors = {'.py': Fore.BLUE}
    if name_colors is None:
        name_colors = {}
    if dir_name_colors is None:
        dir_name_colors = {}
    
    root_dir = os.path.abspath(root_dir)
    start_level = root_dir.count(os.sep)

    for root, dirs, files in os.walk(root_dir):
        current_level = root.count(os.sep) - start_level
        
        if current_level >= max_level:
            dirs.clear()
            
        # Custom sorting function
        def sort_key(item):
            # Try to get the filename without extension
            name = os.path.splitext(item)[0]
            try:
                # If it's a number, return it as an integer
                return (0, int(name))
                
            except ValueError:
                # If not a number, return it as a string
                return (1, name.lower())
        
        # Sort directories and files with custom key
        dirs.sort(key=sort_key)
        files.sort(key=sort_key)
            
        indent = ' ' * 4 * current_level
        print(f'{indent}{Style.BRIGHT}{dir_color}{os.path.basename(root)}/')
        
        sub_indent = ' ' * 4 * (current_level + 1)
        
        # Get the current directory name for dir_name_colors matching
        current_dir_name = os.path.basename(root)

        for f in files:
            # 1. Priority: Check name_colors (exact file name)
            if f in name_colors:
                color = name_colors[f]

            # 2. Priority: Check dir_name_colors (based on parent directory name)
            elif current_dir_name in dir_name_colors:
                color = dir_name_colors[current_dir_name]
                
            # 3. Priority: Check extension_colors
            else:
                ext = os.path.splitext(f)[1].lower()
                color = extension_colors.get(ext, Fore.WHITE)
                
            print(f'{sub_indent}{color}{f}')