from pathlib import Path
import os

def find_project_root(current_file_path):
    """
    Traverse up directories to find the project root.
    It looks for common indicators like .git, setup.py, or pyproject.toml.
    If none are found, it falls back to the current working directory.
    """
    current_path = Path(current_file_path).resolve().parent
    root_markers = ('.git', 'setup.py', 'pyproject.toml', '.project_root')
    
    # Start searching from the current file's directory
    search_path = current_path
    
    while True:
        if any((search_path / marker).exists() for marker in root_markers):
            return search_path
        if search_path.parent == search_path:
            # Fallback to current working directory if no markers found
            return Path(os.getcwd()) 
        search_path = search_path.parent