"""Portolan CLI - Command-line interface for managing cloud-native geospatial data.

The CLI is a thin wrapper around the Python API (see catalog.py).
All business logic lives in the library; the CLI handles user interaction.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

import click

from portolan_cli.catalog import find_catalog_root
from portolan_cli.check import check_directory
from portolan_cli.dataset import (
    DatasetInfo,
    add_files,
    get_dataset_info,
    get_sidecars,
    list_datasets,
    remove_files,
    resolve_collection_id,
)
from portolan_cli.json_output import ErrorDetail, error_envelope, success_envelope
from portolan_cli.metadata import check_directory_metadata, fix_metadata
from portolan_cli.metadata.fix import FixReport
from portolan_cli.output import detail, error, success, warn
from portolan_cli.output import info as info_output
from portolan_cli.scan import (
    ScanIssue,
    ScanOptions,
    ScanResult,
    scan_directory,
)
from portolan_cli.scan import (
    Severity as ScanSeverity,
)
from portolan_cli.scan_fix import ProposedFix, apply_safe_fixes
from portolan_cli.scan_infer import infer_collections
from portolan_cli.scan_output import (
    format_collection_suggestion,
    generate_next_steps,
    get_category_display_name,
    get_fixability,
    group_skipped_files,
    render_tree_view,
)
from portolan_cli.status import get_catalog_status
from portolan_cli.validation import Severity
from portolan_cli.validation import check as validate_catalog


def format_size(size_bytes: int) -> str:
    """Format a file size in human-readable format.

    Args:
        size_bytes: Size in bytes.

    Returns:
        Human-readable size string (e.g., "4.2MB", "100B").
    """
    if size_bytes < 1024:
        return f"{size_bytes}B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f}KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f}MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f}GB"


def should_output_json(ctx: click.Context, json_flag: bool = False) -> bool:
    """Determine if JSON output should be used.

    Checks both the global --format option and per-command --json flags.
    Global --format=json takes precedence, but per-command flags also work
    for backward compatibility.

    Args:
        ctx: Click context containing the format preference.
        json_flag: Per-command --json flag value.

    Returns:
        True if JSON output should be used, False for text output.
    """
    # Get format from context (set by global --format option)
    obj = ctx.find_root().obj or {}
    global_format = obj.get("format", "text")

    # Global format takes precedence, but per-command --json also works
    return global_format == "json" or json_flag


def output_json_envelope(envelope: Any) -> None:
    """Output a JSON envelope to stdout.

    Args:
        envelope: OutputEnvelope instance to output.
    """
    click.echo(envelope.to_json())


@click.group()
@click.version_option()
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["json", "text"]),
    default="text",
    help="Output format (json for machine parsing, text for humans).",
)
@click.pass_context
def cli(ctx: click.Context, output_format: str) -> None:
    """Portolan - Publish and manage cloud-native geospatial data catalogs."""
    # Store format in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["format"] = output_format


@cli.command()
@click.argument("path", type=click.Path(path_type=Path), default=".")
@click.option(
    "--auto",
    "auto_mode",  # Rename to avoid vulture unused variable warning
    is_flag=True,
    default=False,
    help="Skip interactive prompts and use auto-extracted/default values.",
)
@click.option(
    "--title",
    "-t",
    type=str,
    default=None,
    help="Human-readable title for the catalog.",
)
@click.option(
    "--description",
    "-d",
    type=str,
    default=None,
    help="Description of the catalog.",
)
@click.pass_context
def init(
    ctx: click.Context, path: Path, auto_mode: bool, title: str | None, description: str | None
) -> None:
    """Initialize a new Portolan catalog.

    Creates a catalog.json at the root level and a .portolan directory with
    management files (config.yaml, state.json, versions.json).

    Auto-extracts the catalog ID from the directory name.

    PATH is the directory where the catalog should be created (default: current directory).

    Use --auto to skip all prompts and use default values. Use --title and
    --description to set catalog metadata directly.

    \b
    Examples:
        portolan init                       # Initialize in current directory
        portolan init --auto                # Skip prompts, use defaults
        portolan init --title "My Catalog"  # Set title
        portolan init /path/to/data --auto  # Initialize in specific directory
    """
    import json

    from portolan_cli.catalog import init_catalog
    from portolan_cli.errors import CatalogAlreadyExistsError, UnmanagedStacCatalogError

    use_json = should_output_json(ctx)

    # Interactive prompting (unless --auto or JSON mode)
    if not auto_mode and not use_json:
        if title is None:
            title_input = click.prompt(
                "Catalog title (optional, press Enter to skip)",
                default="",
                show_default=False,
            )
            if title_input:
                title = title_input

        if description is None:
            description = click.prompt(
                "Catalog description",
                default="A Portolan-managed STAC catalog",
            )

    try:
        catalog_file, warnings = init_catalog(
            path,
            title=title,
            description=description,
        )

        # Read back catalog ID for display
        catalog_data = json.loads(catalog_file.read_text())
        catalog_id = catalog_data.get("id", "unknown")

        if use_json:
            envelope = success_envelope(
                "init",
                {
                    "path": str(path.resolve()),
                    "catalog_file": "catalog.json",
                    "catalog_id": catalog_id,
                    "warnings": warnings,
                },
            )
            output_json_envelope(envelope)
        else:
            success(f"Initialized Portolan catalog in {path.resolve()}")
            info_output(f"Catalog ID: {catalog_id}")
            for w in warnings:
                warn(w)

    except CatalogAlreadyExistsError as err:
        if use_json:
            envelope = error_envelope(
                "init",
                [ErrorDetail(type="CatalogAlreadyExistsError", message=str(err), code=err.code)],
            )
            output_json_envelope(envelope)
        else:
            error(f"Already a Portolan catalog at {path.resolve()}")
        raise SystemExit(1) from err
    except UnmanagedStacCatalogError as err:
        if use_json:
            envelope = error_envelope(
                "init",
                [ErrorDetail(type="UnmanagedStacCatalogError", message=str(err), code=err.code)],
            )
            output_json_envelope(envelope)
        else:
            error(f"Existing STAC catalog found at {path.resolve()}")
            info_output(
                "Use 'portolan adopt' to bring it under Portolan management (not yet implemented)"
            )
        raise SystemExit(1) from err


# =============================================================================
# List command (top-level, ADR-0022)
# =============================================================================


def _get_format_display_name(format_type: Any) -> str:
    """Get human-readable format name.

    Args:
        format_type: FormatType enum value.

    Returns:
        Human-readable format name (e.g., "GeoParquet", "COG").
    """
    from portolan_cli.formats import FormatType

    if format_type == FormatType.VECTOR:
        return "GeoParquet"
    elif format_type == FormatType.RASTER:
        return "COG"
    else:
        return "Unknown"


def _get_asset_file_size(catalog_path: Path, collection_id: str, asset_href: str) -> int | None:
    """Get the file size for an asset.

    Args:
        catalog_path: Path to catalog root.
        collection_id: Collection ID.
        asset_href: Asset href (relative path).

    Returns:
        File size in bytes, or None if file not found.
    """
    # Asset hrefs are relative to the item, which is in collection/item/
    # The href looks like "./data.parquet" or "../shared/data.parquet"
    # Try to resolve it relative to the collection directory
    clean_href = asset_href.removeprefix("./")

    # Check if the href contains a subdirectory (e.g., "./item/data.parquet")
    if "/" in clean_href:
        # Full path from collection
        asset_path = catalog_path / collection_id / clean_href
    else:
        # Just a filename, try different locations
        asset_path = catalog_path / collection_id / clean_href

    if asset_path.exists():
        return asset_path.stat().st_size

    return None


def _list_tree_output(datasets: list[DatasetInfo], catalog_path: Path) -> None:
    """Output datasets in tree view format per ADR-0022.

    Format:
        demographics/
          census.parquet (GeoParquet, 4.2MB)
          boundaries.parquet (GeoParquet, 1.1MB)
        imagery/
          satellite.tif (COG, 120MB)

    Args:
        datasets: List of DatasetInfo objects.
        catalog_path: Path to catalog root for file size lookups.
    """
    from collections import defaultdict

    # Group datasets by collection
    by_collection: dict[str, list[DatasetInfo]] = defaultdict(list)
    for ds in datasets:
        by_collection[ds.collection_id].append(ds)

    # Sort collections alphabetically
    for collection_id in sorted(by_collection.keys()):
        # Print collection header
        info_output(f"{collection_id}/")

        # Print items under collection
        items = by_collection[collection_id]
        for ds in sorted(items, key=lambda d: d.item_id):
            # Get the primary asset (first one)
            asset_name = ds.item_id
            size_str = ""

            if ds.asset_paths:
                # Get filename from first asset
                first_asset = ds.asset_paths[0]
                asset_name = Path(first_asset).name

                # Try to get file size
                file_size = _get_asset_file_size(catalog_path, ds.collection_id, first_asset)
                if file_size is not None:
                    size_str = f", {format_size(file_size)}"

            format_name = _get_format_display_name(ds.format_type)
            detail(f"  {asset_name} ({format_name}{size_str})")


@cli.command("list")
@click.option(
    "--collection",
    "-c",
    help="Filter by collection ID.",
)
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=".",
    help="Path to catalog root (default: current directory).",
)
@click.option("--json", "json_output", is_flag=True, help="Output as JSON.")
@click.pass_context
def list_cmd(
    ctx: click.Context, collection: str | None, catalog_path: Path, json_output: bool
) -> None:
    """List items in the catalog.

    Shows all items organized by collection in a tree view format.
    Each item displays its filename, format type, and file size.

    \b
    Example output:
        demographics/
          census.parquet (GeoParquet, 4.2MB)
          boundaries.parquet (GeoParquet, 1.1MB)
        imagery/
          satellite.tif (COG, 120MB)

    \b
    Examples:
        portolan list                           # List all items
        portolan list --collection demographics # Filter by collection
        portolan list --json                    # JSON output
    """
    use_json = should_output_json(ctx, json_output)

    datasets = list_datasets(catalog_path, collection_id=collection)

    if use_json:
        envelope = success_envelope(
            "list",
            {
                "items": [
                    {
                        "item_id": ds.item_id,
                        "collection_id": ds.collection_id,
                        "format": ds.format_type.value,
                        "title": ds.title,
                        "assets": ds.asset_paths,
                    }
                    for ds in datasets
                ],
                "count": len(datasets),
            },
        )
        output_json_envelope(envelope)
    else:
        if not datasets:
            info_output("No tracked items")
            info_output("")
            detail("To get started:")
            detail("  portolan scan .      Discover files in this directory")
            detail("  portolan add <path>  Track a specific file or directory")
            return

        _list_tree_output(datasets, catalog_path)


# =============================================================================
# Info command (top-level, ADR-0022)
# =============================================================================


@cli.command("info")
@click.argument("target", type=click.Path(path_type=Path), required=False)
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=".",
    help="Path to catalog root (default: current directory).",
)
@click.option("--json", "json_output", is_flag=True, help="Output as JSON.")
@click.pass_context
def info_cmd(
    ctx: click.Context,
    target: Path | None,
    catalog_path: Path,
    json_output: bool,
) -> None:
    """Show information about a file, collection, or catalog.

    TARGET can be:
    - A file path (e.g., demographics/census.parquet) - shows file metadata
    - A collection directory (e.g., demographics/) - shows collection metadata
    - Omitted - shows catalog-level metadata

    Per ADR-0022, the output format for files is:
        Format: GeoParquet
        CRS: EPSG:4326
        Bbox: [-122.5, 37.7, -122.3, 37.9]
        Features: 4,231
        Version: v1.2.0

    \b
    Examples:
        portolan info demographics/census.parquet  # File info
        portolan info demographics/                # Collection info
        portolan info                              # Catalog info
        portolan info demographics/census.parquet --json  # JSON output
    """
    from portolan_cli.inspect import (
        inspect_catalog,
        inspect_collection,
        inspect_file,
    )

    use_json = should_output_json(ctx, json_output)

    try:
        if target is None:
            # Catalog-level info
            catalog_result = inspect_catalog(catalog_path)
            _output_catalog_info(catalog_result, use_json=use_json)
        elif target.is_file():
            # File-level info
            file_result = inspect_file(target, catalog_root=catalog_path)
            _output_file_info(file_result, use_json=use_json)
        elif target.is_dir():
            # Collection-level info
            collection_result = inspect_collection(target)
            _output_collection_info(collection_result, use_json=use_json)
        else:
            # Path doesn't exist
            raise FileNotFoundError(f"Path not found: {target}")

    except FileNotFoundError as err:
        if use_json:
            envelope = error_envelope(
                "info",
                [ErrorDetail(type="FileNotFoundError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(str(err))
        raise SystemExit(1) from err
    except ValueError as err:
        if use_json:
            envelope = error_envelope(
                "info",
                [ErrorDetail(type="ValueError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(str(err))
        raise SystemExit(1) from err


def _output_file_info(result: Any, *, use_json: bool) -> None:
    """Output file info in human or JSON format."""
    if use_json:
        envelope = success_envelope("info", result.to_dict())
        output_json_envelope(envelope)
    else:
        for line in result.format_human():
            info_output(line)


def _output_collection_info(result: Any, *, use_json: bool) -> None:
    """Output collection info in human or JSON format."""
    if use_json:
        envelope = success_envelope("info", result.to_dict())
        output_json_envelope(envelope)
    else:
        for line in result.format_human():
            info_output(line)


def _output_catalog_info(result: Any, *, use_json: bool) -> None:
    """Output catalog info in human or JSON format."""
    if use_json:
        envelope = success_envelope("info", result.to_dict())
        output_json_envelope(envelope)
    else:
        for line in result.format_human():
            info_output(line)


# =============================================================================
# Status command (top-level, ADR-0022)
# =============================================================================


@cli.command()
@click.option("--json", "json_output", is_flag=True, help="Output as JSON.")
@click.pass_context
def status(ctx: click.Context, json_output: bool) -> None:
    """Show tracking status of files in the catalog.

    Compares filesystem contents against versions.json for each collection
    to show which files are untracked, modified, or deleted.

    \b
    Output format (per ADR-0022):
        # Untracked: demographics/new-file.parquet
        # Modified: imagery/satellite.tif
        # Deleted: boundaries/old-data.parquet
        (or "Nothing to commit, working tree clean" if all synced)

    \b
    Examples:
        portolan status                     # Show status from current directory
        portolan status --json              # Output as JSON
    """
    use_json = should_output_json(ctx, json_output)

    # Find catalog root from current directory
    catalog_root = find_catalog_root(Path.cwd())

    if catalog_root is None:
        if use_json:
            envelope = error_envelope(
                "status",
                [
                    ErrorDetail(
                        type="NoCatalogError",
                        message="No catalog found in current directory or parents",
                    )
                ],
            )
            output_json_envelope(envelope)
        else:
            error("No catalog found in current directory or parents")
            detail("Run 'portolan init' to create a catalog, or cd into one")
        raise SystemExit(1)

    try:
        result = get_catalog_status(catalog_root)

        if use_json:
            data = {
                "catalog_root": str(catalog_root),
                "untracked": [f.path for f in result.untracked],
                "modified": [f.path for f in result.modified],
                "deleted": [f.path for f in result.deleted],
                "is_clean": result.is_clean(),
            }
            envelope = success_envelope("status", data)
            output_json_envelope(envelope)
        else:
            if result.is_clean():
                success("Nothing to commit, working tree clean")
            else:
                if result.untracked:
                    for f in result.untracked:
                        detail(f"# Untracked: {f.path}")
                if result.modified:
                    for f in result.modified:
                        detail(f"# Modified: {f.path}")
                if result.deleted:
                    for f in result.deleted:
                        detail(f"# Deleted: {f.path}")

    except FileNotFoundError as err:
        if use_json:
            envelope = error_envelope(
                "status",
                [ErrorDetail(type="FileNotFoundError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(str(err))
        raise SystemExit(1) from err


def _output_check_json(report: Any, *, mode: str = "all") -> None:
    """Output check results as JSON envelope.

    Args:
        report: ValidationReport from metadata validation.
        mode: Check mode ("metadata", "format", or "all").
    """
    data = report.to_dict()
    data["mode"] = mode
    data["summary"] = {
        "total": len(report.results),
        "passed": sum(1 for r in report.results if r.passed),
        "errors": len(report.errors),
        "warnings": len(report.warnings),
    }

    if report.passed:
        envelope = success_envelope("check", data)
    else:
        errors = [ErrorDetail(type="ValidationError", message=r.message) for r in report.errors]
        envelope = error_envelope("check", errors, data=data)

    output_json_envelope(envelope)


def _print_validation_result(result: Any) -> None:
    """Print a single validation result with appropriate formatting."""
    msg = f"{result.rule_name}: {result.message}"
    if result.passed:
        success(msg)
    elif result.severity == Severity.ERROR:
        error(msg)
    elif result.severity == Severity.WARNING:
        warn(msg)
    else:
        info_output(msg)

    if not result.passed and result.fix_hint:
        detail(f"  Hint: {result.fix_hint}")


def _print_check_summary(report: Any) -> None:
    """Print check summary message."""
    if report.passed:
        success("All validation checks passed")
        return

    error_count = len(report.errors)
    warning_count = len(report.warnings)
    parts = []
    if error_count:
        parts.append(f"{error_count} error{'s' if error_count != 1 else ''}")
    if warning_count:
        parts.append(f"{warning_count} warning{'s' if warning_count != 1 else ''}")
    error(f"Validation failed: {', '.join(parts)}")


def _print_format_check_results(report: Any, *, verbose: bool = False) -> None:
    """Print format check results (not conversion, just status check).

    Args:
        report: CheckReport with file statuses.
        verbose: If True, show all files including cloud-native.
    """
    from portolan_cli.formats import CloudNativeStatus

    if report.total == 0:
        info_output("No geospatial files found")
        return

    cloud_native = [f for f in report.files if f.status == CloudNativeStatus.CLOUD_NATIVE]
    convertible = [f for f in report.files if f.status == CloudNativeStatus.CONVERTIBLE]
    unsupported = [f for f in report.files if f.status == CloudNativeStatus.UNSUPPORTED]

    # Summary
    if cloud_native:
        success(f"{len(cloud_native)} file(s) already cloud-native")
    if convertible:
        warn(f"{len(convertible)} file(s) need conversion")
    if unsupported:
        detail(f"{len(unsupported)} file(s) unsupported")

    # Details if verbose
    if verbose:
        for f in cloud_native:
            success(f"  {f.relative_path} ({f.display_name})")
        for f in convertible:
            warn(f"  {f.relative_path} ({f.display_name}) → {f.target_format}")
        for f in unsupported:
            detail(f"  {f.relative_path} ({f.display_name})")


def _output_combined_check_json(
    metadata_report: Any | None,
    format_report: Any | None,
    *,
    mode: str = "all",
) -> None:
    """Output combined check results as JSON envelope.

    Args:
        metadata_report: Optional ValidationReport from metadata validation.
        format_report: Optional CheckReport from format checking.
        mode: Check mode ("metadata", "format", or "all").
    """
    data: dict[str, Any] = {"mode": mode}
    errors: list[ErrorDetail] = []

    if metadata_report is not None:
        data["metadata"] = metadata_report.to_dict()
        data["metadata"]["summary"] = {
            "total": len(metadata_report.results),
            "passed": sum(1 for r in metadata_report.results if r.passed),
            "errors": len(metadata_report.errors),
            "warnings": len(metadata_report.warnings),
        }
        if metadata_report.errors:
            errors.extend(
                [
                    ErrorDetail(type="ValidationError", message=r.message)
                    for r in metadata_report.errors
                ]
            )

    if format_report is not None:
        data["format"] = format_report.to_dict()

    # Determine overall success
    has_errors = bool(errors)

    if has_errors:
        envelope = error_envelope("check", errors, data=data)
    else:
        envelope = success_envelope("check", data)

    output_json_envelope(envelope)


@cli.command()
@click.argument("path", type=click.Path(path_type=Path), default=".")
@click.option("--json", "json_output", is_flag=True, help="Output results as JSON")
@click.option("--verbose", "-v", is_flag=True, help="Show all validation rules, not just failures")
@click.option(
    "--fix",
    is_flag=True,
    help="Fix issues: convert geo-assets to cloud-native, update stale metadata",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Preview what would be fixed (use with --fix)",
)
@click.option(
    "--metadata",
    is_flag=True,
    help="Only check/fix STAC metadata (links, schema, staleness)",
)
@click.option(
    "--geo-assets",
    "geo_assets",
    is_flag=True,
    help="Only check/fix geospatial assets (cloud-native status, convertibility)",
)
@click.pass_context
def check(
    ctx: click.Context,
    path: Path,
    json_output: bool,
    verbose: bool,
    fix: bool,
    dry_run: bool,
    metadata: bool,
    geo_assets: bool,
) -> None:
    """Validate a Portolan catalog or check files for cloud-native status.

    Runs validation rules against the catalog and reports any issues.
    With --fix, applies fixes based on selected scope.

    PATH is the directory to check (default: current directory).

    Use --metadata or --geo-assets to limit scope:
    - --metadata: Only check/fix STAC metadata (staleness, missing items)
    - --geo-assets: Only check/fix geospatial assets (cloud-native status)
    - Neither: Check/fix both (default)

    Examples:

        portolan check                        # Validate all (metadata + geo-assets)

        portolan check --metadata             # Validate metadata only

        portolan check --geo-assets           # Check geo-assets only

        portolan check --fix                  # Fix both metadata and geo-assets

        portolan check --metadata --fix       # Fix only metadata (create/update items)

        portolan check --geo-assets --fix     # Fix only geo-assets (convert files)

        portolan check --fix --dry-run        # Preview all fixes
    """
    use_json = should_output_json(ctx, json_output)

    # Validate path exists
    if not path.exists():
        _handle_path_not_found(path, use_json)

    # Warn if --dry-run is used without --fix
    if dry_run and not fix:
        warn("--dry-run has no effect without --fix")

    # Determine which checks to run based on scope flags
    run_metadata, run_geo_assets, mode = _determine_check_mode(metadata, geo_assets)

    # Execute the appropriate check workflow
    _execute_check_workflow(
        path=path,
        run_metadata=run_metadata,
        run_geo_assets=run_geo_assets,
        mode=mode,
        fix=fix,
        dry_run=dry_run,
        use_json=use_json,
        verbose=verbose,
    )


def _output_fix_json(
    *,
    mode: str,
    metadata_fix_report: FixReport | None,
    format_fix_report: Any,
    has_failures: bool,
) -> None:
    """Output combined fix results as JSON.

    Args:
        mode: Check mode string.
        metadata_fix_report: Results from metadata fix (if run).
        format_fix_report: Results from geo-asset fix (if run).
        has_failures: Whether any fix operation failed.
    """
    data: dict[str, Any] = {"mode": mode}

    if metadata_fix_report is not None:
        if not isinstance(metadata_fix_report, FixReport):
            raise TypeError(f"Expected FixReport, got {type(metadata_fix_report).__name__}")
        data["metadata_fix"] = metadata_fix_report.to_dict()

    if format_fix_report is not None:
        # Use "conversion" key for backward compatibility with existing tests
        data["conversion"] = format_fix_report.to_dict()

    # Use error_envelope if there were failures
    if has_failures:
        envelope = error_envelope(
            "check",
            [ErrorDetail(type="FixError", message="Some fixes failed")],
            data=data,
        )
    else:
        envelope = success_envelope("check", data)
    output_json_envelope(envelope)


def _output_fix_human(
    *,
    mode: str,
    metadata_fix_report: FixReport | None,
    format_fix_report: Any,
    verbose: bool,
    dry_run: bool,
) -> None:
    """Output combined fix results in human-readable format.

    Args:
        mode: Check mode string.
        metadata_fix_report: Results from metadata fix (if run).
        format_fix_report: Results from geo-asset fix (if run).
        verbose: Show detailed output.
        dry_run: Whether this was a dry run.
    """
    # Output metadata fix results
    if metadata_fix_report is not None:
        if not isinstance(metadata_fix_report, FixReport):
            raise TypeError(f"Expected FixReport, got {type(metadata_fix_report).__name__}")

        if metadata_fix_report.total_count > 0:
            action = "create/update" if dry_run else "Created/updated"
            success(
                f"{action} {metadata_fix_report.total_count} metadata "
                f"item{'s' if metadata_fix_report.total_count != 1 else ''}"
            )
        if metadata_fix_report.skipped_count > 0:
            info_output(f"Skipped {metadata_fix_report.skipped_count} items (already fresh)")
        if metadata_fix_report.failure_count > 0:
            error(f"Failed to fix {metadata_fix_report.failure_count} metadata items")

        # Show details if verbose or failures
        if verbose or metadata_fix_report.failure_count > 0:
            for result in metadata_fix_report.results:
                status_char = "✓" if result.success else "✗"
                msg = f"{status_char} {result.file_path}: {result.action.value} ({result.message})"
                if result.success:
                    detail(msg)
                else:
                    error(msg)

    # Output format fix results (conversion)
    if format_fix_report is not None:
        if dry_run:
            _print_check_fix_preview(format_fix_report)
        else:
            _print_check_fix_results(format_fix_report, verbose=verbose)


def _handle_path_not_found(path: Path, use_json: bool) -> None:
    """Handle path not found error and exit."""
    if use_json:
        envelope = error_envelope(
            "check",
            [ErrorDetail(type="PathNotFoundError", message=f"Path does not exist: {path}")],
        )
        output_json_envelope(envelope)
    else:
        error(f"Path does not exist: {path}")
    raise SystemExit(1)


def _determine_check_mode(metadata: bool, geo_assets: bool) -> tuple[bool, bool, str]:
    """Determine which checks to run and the mode string.

    The scope flags (--metadata, --geo-assets) determine WHAT to check/fix:
    - Neither flag: check/fix both (default)
    - --metadata: check/fix metadata only
    - --geo-assets: check/fix geo-assets only
    - Both flags: check/fix both (explicit)

    The --fix flag separately controls WHETHER to apply fixes (orthogonal).

    Returns:
        Tuple of (run_metadata, run_geo_assets, mode_string).
    """
    explicit_flags = metadata or geo_assets

    if explicit_flags:
        run_metadata = metadata
        run_geo_assets = geo_assets
    else:
        # No explicit flags: run both
        run_metadata = True
        run_geo_assets = True

    # Determine mode string
    if run_metadata and not run_geo_assets:
        mode = "metadata"
    elif run_geo_assets and not run_metadata:
        mode = "geo-assets"
    else:
        mode = "all"

    return run_metadata, run_geo_assets, mode


def _execute_check_workflow(
    *,
    path: Path,
    run_metadata: bool,
    run_geo_assets: bool,
    mode: str,
    fix: bool,
    dry_run: bool,
    use_json: bool,
    verbose: bool,
) -> None:
    """Execute the check workflow based on flags.

    The workflow varies based on scope (--metadata, --geo-assets) and --fix:
    - Without --fix: run validation and report issues
    - With --fix: run validation AND apply fixes for the selected scope
    """
    # Handle fix workflows (may exit early)
    if fix:
        _run_fix_workflow(
            path=path,
            run_metadata=run_metadata,
            run_geo_assets=run_geo_assets,
            mode=mode,
            dry_run=dry_run,
            use_json=use_json,
            verbose=verbose,
        )
        return

    # Check-only workflows (no --fix)
    if run_metadata and not run_geo_assets:
        # Metadata only
        metadata_report = validate_catalog(path)
        _output_metadata_only(metadata_report, mode, use_json, verbose)
    elif run_geo_assets and not run_metadata:
        # Geo-assets only
        _output_format_only(path, mode, use_json, verbose)
    else:
        # Both (combined)
        metadata_report = validate_catalog(path)
        _output_combined(path, metadata_report, mode, use_json, verbose)


def _run_fix_workflow(
    *,
    path: Path,
    run_metadata: bool,
    run_geo_assets: bool,
    mode: str,
    dry_run: bool,
    use_json: bool,
    verbose: bool,
) -> None:
    """Execute the fix workflow for selected scope.

    Args:
        path: Directory to check/fix.
        run_metadata: Whether to fix metadata issues.
        run_geo_assets: Whether to fix geo-asset format issues.
        mode: Mode string for JSON output.
        dry_run: Preview changes without applying them.
        use_json: Output JSON envelope.
        verbose: Show detailed output.
    """
    metadata_fix_report: FixReport | None = None
    format_fix_report = None
    has_failures = False

    # Fix metadata if in scope
    if run_metadata:
        metadata_check_report = check_directory_metadata(path)
        metadata_fix_report = fix_metadata(path, metadata_check_report, dry_run=dry_run)
        if metadata_fix_report.failure_count > 0:
            has_failures = True

    # Fix geo-assets if in scope
    if run_geo_assets:
        format_fix_report = check_directory(path, fix=True, dry_run=dry_run, catalog_path=path)

    # Output results
    if use_json:
        _output_fix_json(
            mode=mode,
            metadata_fix_report=metadata_fix_report,
            format_fix_report=format_fix_report,
            has_failures=has_failures,
        )
    else:
        _output_fix_human(
            mode=mode,
            metadata_fix_report=metadata_fix_report,
            format_fix_report=format_fix_report,
            verbose=verbose,
            dry_run=dry_run,
        )

    # Exit with error if any failures
    if has_failures:
        raise SystemExit(1)
    # Also exit with error if format conversion had failures
    if (
        format_fix_report
        and format_fix_report.conversion_report
        and format_fix_report.conversion_report.failed > 0
    ):
        raise SystemExit(1)


def _output_metadata_only(report: Any, mode: str, use_json: bool, verbose: bool) -> None:
    """Output metadata-only check results."""
    if use_json:
        _output_check_json(report, mode=mode)
    else:
        for result in report.results:
            if verbose or not result.passed:
                _print_validation_result(result)
        _print_check_summary(report)
    if report.errors:
        raise SystemExit(1)


def _output_format_only(path: Path, mode: str, use_json: bool, verbose: bool) -> None:
    """Output format-only check results."""
    format_report = check_directory(path, fix=False, dry_run=False, catalog_path=path)
    if use_json:
        data = format_report.to_dict()
        data["mode"] = mode
        envelope = success_envelope("check", data)
        output_json_envelope(envelope)
    else:
        _print_format_check_results(format_report, verbose=verbose)


def _output_combined(
    path: Path, metadata_report: Any, mode: str, use_json: bool, verbose: bool
) -> None:
    """Output combined metadata + format check results.

    Args:
        path: Directory that was checked.
        metadata_report: ValidationReport from metadata validation.
        mode: Check mode string for JSON output.
        use_json: Whether to output JSON envelope.
        verbose: Whether to show detailed output.

    Raises:
        SystemExit: If metadata validation has errors.
    """
    format_report = check_directory(path, fix=False, dry_run=False, catalog_path=path)
    has_metadata_errors = metadata_report is not None and bool(metadata_report.errors)

    if use_json:
        _output_combined_check_json(metadata_report, format_report, mode=mode)
    else:
        if metadata_report:
            info_output("Metadata validation:")
            for result in metadata_report.results:
                if verbose or not result.passed:
                    _print_validation_result(result)
            _print_check_summary(metadata_report)
        if format_report:
            info_output("\nFormat check:")
            _print_format_check_results(format_report, verbose=verbose)

    # Exit with error if metadata validation failed
    if has_metadata_errors:
        raise SystemExit(1)


def _print_check_fix_preview(report: Any) -> None:
    """Print preview of what would be converted."""
    from portolan_cli.formats import CloudNativeStatus

    convertible = [f for f in report.files if f.status == CloudNativeStatus.CONVERTIBLE]

    if not convertible:
        info_output("No files need conversion")
        return

    info_output(f"Dry run: {len(convertible)} file(s) would be converted")
    for f in convertible:
        detail(f"  {f.relative_path} ({f.display_name}) -> {f.target_format}")


def _print_check_fix_results(report: Any, *, verbose: bool = False) -> None:
    """Print conversion results.

    Args:
        report: CheckReport with conversion results.
        verbose: If True, show details for all files including skipped.
    """
    from portolan_cli.convert import ConversionStatus

    conv = report.conversion_report
    if conv is None:
        return

    if conv.total == 0:
        info_output("No files to convert")
        return

    # Summary
    if conv.succeeded > 0:
        success(f"Converted {conv.succeeded} file(s)")
    if conv.skipped > 0:
        detail(f"  {conv.skipped} file(s) skipped (already cloud-native)")
    if conv.failed > 0:
        error(f"  {conv.failed} file(s) failed")
    if conv.invalid > 0:
        warn(f"  {conv.invalid} file(s) invalid after conversion")

    # Show details for failures (always) and successes/skipped (if verbose)
    for r in conv.results:
        if r.status == ConversionStatus.FAILED:
            error(f"  {r.source.name}: {r.error}")
        elif r.status == ConversionStatus.SUCCESS:
            detail(f"  {r.source.name} -> {r.output.name if r.output else 'N/A'}")
        elif verbose and r.status == ConversionStatus.SKIPPED:
            detail(f"  {r.source.name} (skipped - already cloud-native)")


# ─────────────────────────────────────────────────────────────────────────────
# Scan command
# ─────────────────────────────────────────────────────────────────────────────


def _handle_fix_mode(
    result: ScanResult,
    *,
    dry_run: bool,
    use_json: bool,
) -> tuple[list[ProposedFix], list[ProposedFix]]:
    """Handle --fix mode for scan command.

    Args:
        result: Scan result with issues to fix.
        dry_run: If True, preview fixes without applying.
        use_json: If True, suppress human output.

    Returns:
        Tuple of (proposed_fixes, applied_fixes).
    """
    # Dry-run mode: compute and show what would be done
    if dry_run:
        proposed, _ = apply_safe_fixes(result.issues, dry_run=True)
        if not use_json:
            if not proposed:
                info_output("No issues to fix")
            else:
                info_output(f"Dry run: {len(proposed)} fix(es) would be applied")
                for fix in proposed:
                    detail(f"  {fix.preview}")
        return proposed, []

    # Apply fixes
    proposed, applied = apply_safe_fixes(result.issues, dry_run=False)

    if not use_json:
        if not proposed:
            info_output("No issues to fix")
        else:
            # Show successful fixes
            if applied:
                success(f"Applied {len(applied)} fix(es)")
                for fix in applied:
                    detail(f"  {fix.preview}")

            # Show any that failed to apply (collisions)
            failed = [p for p in proposed if p not in applied]
            if failed:
                warn(f"{len(failed)} fix(es) could not be applied (collision):")
                for fix in failed:
                    detail(f"  {fix.preview}")

    return proposed, applied


@cli.command()
@click.argument("path", type=click.Path(path_type=Path))
@click.option("--json", "json_output", is_flag=True, help="Output results as JSON")
@click.option(
    "--no-recursive",
    is_flag=True,
    help="Scan only the target directory (no subdirectories)",
)
@click.option(
    "--max-depth",
    type=int,
    default=None,
    help="Maximum recursion depth (0 = target directory only)",
)
@click.option(
    "--include-hidden",
    is_flag=True,
    help="Include hidden files (starting with .)",
)
@click.option(
    "--follow-symlinks",
    is_flag=True,
    help="Follow symbolic links (may cause loops)",
)
@click.option(
    "--all",
    "show_all",
    is_flag=True,
    help="Show all issues without truncation (default: show first 10 per severity)",
)
@click.option(
    "--tree",
    "show_tree",
    is_flag=True,
    help="Show directory tree view with file status markers",
)
@click.option(
    "--suggest-collections",
    "suggest_collections",
    is_flag=True,
    help="Suggest collection groupings based on filename patterns",
)
@click.option(
    "--manual",
    "manual_only",
    is_flag=True,
    help="Show only issues requiring manual resolution",
)
@click.option(
    "--fix",
    is_flag=True,
    help="Apply safe fixes (rename files with invalid characters, Windows reserved names, or long paths)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Preview fixes without applying them (use with --fix)",
)
@click.pass_context
def scan(
    ctx: click.Context,
    path: Path,
    json_output: bool,
    no_recursive: bool,
    max_depth: int | None,
    include_hidden: bool,
    follow_symlinks: bool,
    show_all: bool,
    show_tree: bool,
    suggest_collections: bool,
    manual_only: bool,
    fix: bool,
    dry_run: bool,
) -> None:
    """Scan a directory for geospatial files and potential issues.

    Discovers files by extension, validates shapefile completeness,
    and reports issues that may cause problems during import.

    PATH is the directory to scan.

    \b
    Fix Mode:
        Use --fix to auto-rename files with:
        - Invalid characters (spaces, parentheses, non-ASCII)
        - Windows reserved names (CON, PRN, AUX, etc.)
        - Long paths (> 200 characters)

        Use --dry-run to preview changes without applying.

    Examples:

        portolan scan /data/geospatial

        portolan scan . --json

        portolan scan /large/tree --max-depth=2

        portolan scan /data --no-recursive

        portolan scan /data --fix --dry-run

        portolan scan /data --fix
    """
    use_json = should_output_json(ctx, json_output)

    # Validate path exists and is a directory (handle in code for JSON envelope support)
    if not path.exists():
        if use_json:
            envelope = error_envelope(
                "scan",
                [
                    ErrorDetail(
                        type="PathNotFoundError", message=f"Directory does not exist: {path}"
                    )
                ],
            )
            output_json_envelope(envelope)
        else:
            error(f"Directory does not exist: {path}")
        raise SystemExit(1)

    if not path.is_dir():
        if use_json:
            envelope = error_envelope(
                "scan",
                [
                    ErrorDetail(
                        type="NotADirectoryError", message=f"Path is not a directory: {path}"
                    )
                ],
            )
            output_json_envelope(envelope)
        else:
            error(f"Path is not a directory: {path}")
        raise SystemExit(1)

    # Build options from CLI flags
    options = ScanOptions(
        recursive=not no_recursive,
        max_depth=max_depth,
        include_hidden=include_hidden,
        follow_symlinks=follow_symlinks,
        show_all=show_all,
        suggest_collections=suggest_collections,
    )

    try:
        result = scan_directory(path, options)
    except FileNotFoundError as err:
        if use_json:
            envelope = error_envelope(
                "scan",
                [ErrorDetail(type="FileNotFoundError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(str(err))
        raise SystemExit(1) from err
    except NotADirectoryError as err:
        if use_json:
            envelope = error_envelope(
                "scan",
                [ErrorDetail(type="NotADirectoryError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(str(err))
        raise SystemExit(1) from err

    # Run collection inference if requested
    if suggest_collections and result.ready:
        result.collection_suggestions = infer_collections(result.ready)

    # Warn if --dry-run is used without --fix (no effect)
    if dry_run and not fix:
        warn("--dry-run has no effect without --fix")

    # Handle fix mode
    if fix:
        proposed, applied = _handle_fix_mode(
            result,
            dry_run=dry_run,
            use_json=use_json,
        )
        result.proposed_fixes = proposed
        result.applied_fixes = applied

    if use_json:
        # JSON output with envelope
        data = result.to_dict()
        data["summary"] = {
            "ready_count": len(result.ready),
            "error_count": result.error_count,
            "warning_count": result.warning_count,
            "skipped_count": len(result.skipped),
        }

        if result.has_errors:
            # Still return data, but mark as not successful
            errors = [
                ErrorDetail(type=issue.issue_type.value, message=issue.message)
                for issue in result.issues
                if issue.severity == ScanSeverity.ERROR
            ]
            envelope = error_envelope("scan", errors, data=data)
        else:
            envelope = success_envelope("scan", data)

        output_json_envelope(envelope)
    elif manual_only:
        # Show only issues requiring manual resolution
        from portolan_cli.scan_output import format_scan_output

        output = format_scan_output(result, manual_only=True)
        click.echo(output)
    else:
        # Human-readable output per FR-018
        _print_scan_summary_enhanced(result, show_all=show_all, show_tree=show_tree)

    # Scan is informational — always exit 0 on success


def _print_scan_header(result: ScanResult) -> None:
    """Print scan header with file counts."""
    ready_count = len(result.ready)
    if ready_count == 0:
        info_output(f"Scanned {result.directories_scanned} directories")
        warn("No geo-assets found")
    else:
        success(f"{ready_count} geo-asset{'s' if ready_count != 1 else ''} found")


def _print_format_breakdown(result: ScanResult) -> None:
    """Print breakdown of files by format."""
    if not result.ready:
        return
    formats: dict[str, int] = {}
    for f in result.ready:
        formats[f.extension] = formats.get(f.extension, 0) + 1
    for ext, count in sorted(formats.items()):
        detail(f"  {count} {ext} file{'s' if count != 1 else ''}")


# Default maximum issues to show per severity before truncation
DEFAULT_ISSUE_LIMIT = 10


def _print_issue_group(
    issues: list[ScanIssue],
    severity: ScanSeverity,
    header_fn: Callable[[str], None],
    count: int,
    label: str,
    *,
    show_all: bool = False,
    limit: int = DEFAULT_ISSUE_LIMIT,
) -> None:
    """Print a group of issues with the same severity.

    Args:
        issues: List of all issues.
        severity: Severity level to filter for.
        header_fn: Function to print header (error/warn/info).
        count: Total count of issues with this severity.
        label: Label for the issue type (e.g., "error", "warning").
        show_all: If True, show all issues without truncation.
        limit: Maximum issues to show per severity (default: 10).
    """
    if count == 0:
        return
    header_fn(f"{count} {label}{'s' if count != 1 else ''}")

    # Filter issues by severity
    severity_issues = [i for i in issues if i.severity == severity]

    # Apply truncation if needed
    displayed = severity_issues if show_all else severity_issues[:limit]
    truncated_count = len(severity_issues) - len(displayed)

    for issue in displayed:
        header_fn(f"  {issue.relative_path}: {issue.message}")
        if issue.suggestion is not None:
            detail(f"    Hint: {issue.suggestion}")

    # Show truncation message if issues were hidden
    if truncated_count > 0:
        detail(f"  ... and {truncated_count} more (use --all to see all)")


def _print_issues_by_severity(result: ScanResult, *, show_all: bool = False) -> None:
    """Print issues grouped by severity.

    Args:
        result: The scan result containing issues.
        show_all: If True, show all issues without truncation.
    """
    if not result.issues:
        return

    _print_issue_group(
        result.issues, ScanSeverity.ERROR, error, result.error_count, "error", show_all=show_all
    )
    _print_issue_group(
        result.issues,
        ScanSeverity.WARNING,
        warn,
        result.warning_count,
        "warning",
        show_all=show_all,
    )
    _print_issue_group(
        result.issues,
        ScanSeverity.INFO,
        info_output,
        result.info_count,
        "info message",
        show_all=show_all,
    )


def _print_scan_summary(result: ScanResult, *, show_all: bool = False) -> None:
    """Print human-readable scan summary (legacy).

    Args:
        result: The scan result to print.
        show_all: If True, show all issues without truncation.
    """
    _print_scan_header(result)
    _print_format_breakdown(result)
    _print_issues_by_severity(result, show_all=show_all)

    if result.skipped:
        detail(f"{len(result.skipped)} files skipped (unrecognized format)")


def _print_scan_summary_enhanced(
    result: ScanResult,
    *,
    show_all: bool = False,
    show_tree: bool = False,
) -> None:
    """Print enhanced human-readable scan summary.

    Includes:
    - Summary header
    - Format breakdown
    - Tree view (if --tree)
    - Issues with fixability labels
    - Skipped files by category
    - Collection suggestions
    - Actionable next steps

    Args:
        result: The scan result to print.
        show_all: If True, show all issues without truncation.
        show_tree: If True, show directory tree view.
    """
    # Header
    _print_scan_header(result)
    _print_format_breakdown(result)

    # Tree view (if requested)
    if show_tree:
        click.echo()
        tree_output = render_tree_view(result, show_missing=True)
        click.echo(tree_output)

    # Issues with fixability labels
    _print_issues_with_fixability(result, show_all=show_all)

    # Skipped files by category
    _print_skipped_by_category(result)

    # Collection suggestions
    _print_collection_suggestions(result)

    # Next steps
    _print_next_steps(result)


def _print_issues_with_fixability(result: ScanResult, *, show_all: bool = False) -> None:
    """Print issues grouped by severity with fixability labels.

    Args:
        result: The scan result containing issues.
        show_all: If True, show all issues without truncation.
    """
    if not result.issues:
        return

    limit = None if show_all else DEFAULT_ISSUE_LIMIT

    # Group by severity
    for severity, header_fn, label in [
        (ScanSeverity.ERROR, error, "error"),
        (ScanSeverity.WARNING, warn, "warning"),
        (ScanSeverity.INFO, info_output, "info message"),
    ]:
        severity_issues = [i for i in result.issues if i.severity == severity]
        if not severity_issues:
            continue

        count = len(severity_issues)
        header_fn(f"{count} {label}{'s' if count != 1 else ''}")

        # Apply truncation if needed
        displayed = severity_issues if limit is None else severity_issues[:limit]
        truncated_count = len(severity_issues) - len(displayed)

        for issue in displayed:
            fix_label = get_fixability(issue.issue_type).label
            header_fn(f"  {fix_label} {issue.relative_path}: {issue.message}")
            if issue.suggestion is not None:
                detail(f"    Hint: {issue.suggestion}")

        if truncated_count > 0:
            detail(f"  ... and {truncated_count} more (use --all to see all)")


def _print_skipped_by_category(result: ScanResult) -> None:
    """Print skipped files grouped by category.

    Args:
        result: The scan result containing skipped files.
    """
    if not result.skipped:
        return

    grouped = group_skipped_files(result.skipped)
    if not grouped:
        # Fallback for legacy Path objects
        detail(f"{len(result.skipped)} files skipped (unrecognized format)")
        return

    # Check if any files are truly unknown
    from portolan_cli.scan_classify import FileCategory

    unknown_count = len(grouped.get(FileCategory.UNKNOWN, []))
    recognized_count = len(result.skipped) - unknown_count

    # If all files are recognized (no unknowns), show a concise summary
    if unknown_count == 0:
        # Build a compact list: "5 catalog files, 4 tabular, 2 thumbnails, ..."
        parts = []
        for category, files in sorted(grouped.items(), key=lambda x: len(x[1]), reverse=True):
            display_name = get_category_display_name(category)
            parts.append(f"{len(files)} {display_name}")
        detail(f"  {', '.join(parts)}")
    else:
        # Some unknown files - show the detailed breakdown
        click.echo()
        if unknown_count > 0:
            warn(f"{unknown_count} files with unrecognized format")
        detail(f"Other files ({recognized_count} recognized):")
        for category, files in sorted(grouped.items(), key=lambda x: len(x[1]), reverse=True):
            display_name = get_category_display_name(category)
            detail(f"  {len(files)} {display_name}")


def _print_collection_suggestions(result: ScanResult) -> None:
    """Print collection suggestions if available.

    Args:
        result: The scan result with collection suggestions.
    """
    if not result.collection_suggestions:
        return

    click.echo()
    info_output("Suggested collections:")
    for suggestion in result.collection_suggestions:
        click.echo(format_collection_suggestion(suggestion))


def _print_next_steps(result: ScanResult) -> None:
    """Print actionable next steps.

    Args:
        result: The scan result to analyze for next steps.
    """
    steps = generate_next_steps(result)
    if not steps:
        return

    click.echo()
    info_output("Next steps:")
    for step in steps:
        detail(f"  \u2192 {step}")


# ─────────────────────────────────────────────────────────────────────────────
# Top-level add/rm commands (per ADR-0022)
# ─────────────────────────────────────────────────────────────────────────────


def _handle_cmd_error(cmd: str, err_type: str, message: str, use_json: bool) -> None:
    """Handle error output for add/rm commands (standardized)."""
    if use_json:
        envelope = error_envelope(cmd, [ErrorDetail(type=err_type, message=message)])
        output_json_envelope(envelope)
    else:
        error(message)


def _output_add_results(
    added: list[DatasetInfo],
    skipped: list[Path],
    collection_id: str | None,
    verbose: bool,
    use_json: bool,
) -> None:
    """Output results for add command."""
    if use_json:
        data = {
            "added": [
                {
                    "item_id": ds.item_id,
                    "collection_id": ds.collection_id,
                    "format_type": ds.format_type.value,
                    "bbox": ds.bbox,
                }
                for ds in added
            ],
            "skipped": [str(p) for p in skipped],
        }
        envelope = success_envelope("add", data)
        output_json_envelope(envelope)
        return

    # Human-readable output
    if not added:
        # No files to add - don't print confusing "Adding 0 files to catalog"
        if not skipped:
            info_output("No geospatial files found to add")
        return

    # Group by collection for multi-collection catalog-root adds
    collections: dict[str, list[DatasetInfo]] = {}
    for ds in added:
        collections.setdefault(ds.collection_id, []).append(ds)

    if len(collections) == 1:
        # Single collection - use compact output
        coll = next(iter(collections))
        count = len(added)
        info_output(f"Adding {count} file{'s' if count != 1 else ''} to {coll}")
        for ds in added:
            sidecars = get_sidecars(Path(ds.asset_paths[0])) if ds.asset_paths else []
            sidecar_note = f" (+ {len(sidecars)} sidecars)" if sidecars else ""
            success(f"  + {ds.item_id}{sidecar_note}")
    else:
        # Multiple collections - group output by collection
        total = len(added)
        info_output(
            f"Adding {total} file{'s' if total != 1 else ''} to {len(collections)} collections"
        )
        for coll, datasets in sorted(collections.items()):
            info_output(f"  {coll}:")
            for ds in datasets:
                sidecars = get_sidecars(Path(ds.asset_paths[0])) if ds.asset_paths else []
                sidecar_note = f" (+ {len(sidecars)} sidecars)" if sidecars else ""
                success(f"    + {ds.item_id}{sidecar_note}")

    if verbose and skipped:
        for p in skipped:
            detail(f"Skipping {p.name} (unchanged)")


@cli.command("add")
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Show detailed output including skipped unchanged files.",
)
@click.option(
    "--item-id",
    default=None,
    help="Override automatic item ID derivation. Must be a single path segment.",
)
@click.option(
    "--portolan-dir",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Path to Portolan catalog root (default: auto-detect by walking up from cwd).",
)
@click.pass_context
def add_cmd(
    ctx: click.Context,
    path: Path,
    verbose: bool,
    item_id: str | None,
    catalog_path: Path | None,
) -> None:
    """Track files in the catalog.

    Adds files to the Portolan catalog with automatic collection inference.
    The collection ID is determined from the first directory component of
    the path relative to the catalog root.

    Works like git: run from anywhere inside a catalog and it auto-detects
    the catalog root. Use --portolan-dir to override.

    \b
    Item ID derivation:
        By default, the item ID is derived from the parent directory name.
        For example, adding 'census/2020/data.parquet' creates an item
        named '2020'. Use --item-id to override this automatic derivation.
        All other files in the item directory are tracked as companion
        assets (per ADR-0028).

    \b
    Examples:
        cd my-catalog && portolan add demographics/census.parquet
        portolan add imagery/                      # Add all files in directory
        portolan add .                             # Add all files in catalog
        portolan add data.geojson --item-id my-custom-id  # Override item ID

    Smart behavior:
    - Unchanged files are silently skipped (use --verbose to see them)
    - Changed files are re-extracted with new metadata
    - Sidecar files (.dbf, .shx, .prj for shapefiles) are auto-detected
    - All files in the item directory are tracked, not just geo files (ADR-0028)
    """
    use_json = should_output_json(ctx)
    target_path = path.resolve()

    # Auto-detect catalog root (git-style)
    catalog_root: Path
    if catalog_path is not None:
        catalog_root = catalog_path.resolve()
    else:
        detected_root = find_catalog_root()
        if detected_root is None:
            _handle_cmd_error(
                "add",
                "NotACatalogError",
                "Not inside a Portolan catalog (no .portolan/config.yaml found)",
                use_json,
            )
            if not use_json:
                detail("Run 'portolan init' to create a catalog, or cd into one")
            raise SystemExit(1)
        catalog_root = detected_root

    # Validate catalog exists (when explicitly specified)
    # Per ADR-0029, use .portolan/config.yaml as the single sentinel
    if catalog_path is not None and not (catalog_root / ".portolan" / "config.yaml").exists():
        _handle_cmd_error("add", "NotACatalogError", f"Not a catalog: {catalog_root}", use_json)
        if not use_json:
            detail("Run 'portolan init' to create a catalog")
        raise SystemExit(1)

    # Validate --item-id is only used with single files, not directories.
    # Applying the same item_id to multiple geo files in a directory would cause
    # them to overwrite each other's STAC items. (Issue #136)
    if item_id is not None and target_path.is_dir():
        _handle_cmd_error(
            "add",
            "ValueError",
            "--item-id can only be used with a single file, not a directory",
            use_json,
        )
        raise SystemExit(1)

    # Determine collection ID from path.
    # Special case: when the user runs `add .` (or `add <catalog-root>`), target_path
    # equals catalog_root. In this case we cannot determine a single collection—instead
    # we let add_files infer the collection for each file individually by passing
    # collection_id=None.  This implements Issue #137.
    #
    # NOTE: Use samefile() not == for robust comparison across:
    # - Case-insensitive filesystems (macOS HFS+, Windows NTFS)
    # - Symlinks that resolve to the same path
    # - Trailing slash inconsistencies
    collection_id: str | None
    if target_path.samefile(catalog_root):
        # Catalog-root add: infer collection per-file from directory structure
        collection_id = None
    else:
        try:
            collection_id = resolve_collection_id(target_path, catalog_root)
        except ValueError as err:
            _handle_cmd_error("add", "PathError", str(err), use_json)
            raise SystemExit(1) from err

    # Add files
    try:
        added, skipped = add_files(
            paths=[target_path],
            catalog_root=catalog_root,
            collection_id=collection_id,
            item_id=item_id,
            verbose=verbose,
        )
        _output_add_results(added, skipped, collection_id, verbose, use_json)
    except (ValueError, FileNotFoundError) as err:
        err_type = type(err).__name__
        _handle_cmd_error("add", err_type, str(err), use_json)
        raise SystemExit(1) from err


@cli.command("rm")
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--keep",
    is_flag=True,
    help="Untrack file but preserve it on disk.",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Force deletion without safety check. Required for destructive rm.",
)
@click.option(
    "--dry-run",
    "-n",
    is_flag=True,
    help="Show what would be removed without actually removing.",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Show detailed output including skipped files.",
)
@click.option(
    "--portolan-dir",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Path to Portolan catalog root (default: auto-detect by walking up from cwd).",
)
@click.pass_context
def rm_cmd(
    ctx: click.Context,
    path: Path,
    keep: bool,
    force: bool,
    dry_run: bool,
    verbose: bool,
    catalog_path: Path | None,
) -> None:
    """Remove files from tracking.

    By default, removes the file from disk AND untracks it from the catalog.
    Requires --force for destructive operations (deleting files).

    Works like git: run from anywhere inside a catalog and it auto-detects
    the catalog root. Use --portolan-dir to override.

    \b
    Safety flags:
    - --keep: Untrack file but preserve it on disk (safe, no --force needed)
    - --force: Required for destructive rm (when not using --keep)
    - --dry-run: Preview what would be removed without actually removing

    \b
    Examples:
        portolan rm --keep imagery/old_data.tif     # Safe: untrack only
        portolan rm --dry-run vectors/              # Preview what would be removed
        portolan rm -f demographics/census.parquet  # Force delete and untrack
        portolan rm -f vectors/                     # Force remove entire directory
    """
    use_json = should_output_json(ctx)

    # Require --force for destructive operations (unless --keep or --dry-run)
    if not keep and not dry_run and not force:
        _handle_cmd_error(
            "rm",
            "SafetyError",
            "Destructive rm requires --force flag. Use --keep to preserve files, or --dry-run to preview.",
            use_json,
        )
        if not use_json:
            detail("Examples:")
            detail("  portolan rm --keep myfile.parquet  # Untrack but keep file")
            detail("  portolan rm --dry-run myfile.parquet  # Preview removal")
            detail("  portolan rm -f myfile.parquet  # Force delete")
        raise SystemExit(1)

    # Auto-detect catalog root (git-style)
    catalog_root: Path
    if catalog_path is not None:
        catalog_root = catalog_path.resolve()
    else:
        detected_root = find_catalog_root()
        if detected_root is None:
            _handle_cmd_error(
                "rm",
                "NotACatalogError",
                "Not inside a Portolan catalog (no .portolan/config.yaml found)",
                use_json,
            )
            if not use_json:
                detail("Run 'portolan init' to create a catalog, or cd into one")
            raise SystemExit(1)
        catalog_root = detected_root

    try:
        target_path = path.resolve()

        removed, skipped = remove_files(
            paths=[target_path],
            catalog_root=catalog_root,
            keep=keep,
            dry_run=dry_run,
        )

        if use_json:
            data = {
                "removed": [str(p) for p in removed],
                "skipped": [str(p) for p in skipped],
                "kept_on_disk": keep,
                "dry_run": dry_run,
            }
            envelope = success_envelope("rm", data)
            output_json_envelope(envelope)
        else:
            if dry_run:
                info_output("Dry run - no files were actually removed:")
            for p in removed:
                if dry_run:
                    detail(f"  Would remove: {p.name}")
                elif keep:
                    success(f"Untracked {p.name} (file preserved)")
                else:
                    success(f"Removed {p.name}")

            # Show skipped files in verbose mode
            if verbose and skipped:
                for p in skipped:
                    warn(f"Skipped {p.name} (not in catalog or outside catalog)")

    except ValueError as err:
        _handle_cmd_error("rm", "ValueError", str(err), use_json)
        raise SystemExit(1) from err
    except FileNotFoundError as err:
        _handle_cmd_error("rm", "FileNotFoundError", str(err), use_json)
        raise SystemExit(1) from err


# ─────────────────────────────────────────────────────────────────────────────
# Dataset commands (legacy - list/info only, add/remove moved to top-level)
# ─────────────────────────────────────────────────────────────────────────────


@cli.group()
@click.pass_context
def dataset(ctx: click.Context) -> None:
    """Manage datasets in the catalog."""
    # Ensure context is passed through to subcommands
    ctx.ensure_object(dict)


@dataset.command("list")
@click.option(
    "--collection",
    "-c",
    help="Filter by collection ID.",
)
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=".",
    help="Path to catalog root (default: current directory).",
)
@click.pass_context
def dataset_list(ctx: click.Context, collection: str | None, catalog_path: Path) -> None:
    """List datasets in the catalog (DEPRECATED).

    This command is deprecated. Use 'portolan list' instead.

    Examples:

        portolan list                           # New command
        portolan list --collection demographics # Filter by collection
    """
    use_json = should_output_json(ctx)

    # Show deprecation warning (unless JSON output)
    if not use_json:
        warn("'portolan dataset list' is deprecated. Use 'portolan list' instead.")

    datasets = list_datasets(catalog_path, collection_id=collection)

    if use_json:
        envelope = success_envelope(
            "dataset_list",
            {
                "datasets": [
                    {
                        "item_id": ds.item_id,
                        "collection_id": ds.collection_id,
                        "format": ds.format_type.value,
                        "title": ds.title,
                    }
                    for ds in datasets
                ],
                "count": len(datasets),
            },
        )
        output_json_envelope(envelope)
    else:
        if not datasets:
            info_output("No datasets found")
            return

        # Use the new tree view output
        _list_tree_output(datasets, catalog_path)


@dataset.command("info")
@click.argument("dataset_id")
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=".",
    help="Path to catalog root (default: current directory).",
)
@click.option("--json", "json_output", is_flag=True, help="Output as JSON.")
@click.pass_context
def dataset_info(
    ctx: click.Context, dataset_id: str, catalog_path: Path, json_output: bool
) -> None:
    """Show information about a dataset (DEPRECATED).

    This command is deprecated. Use 'portolan info' instead.

    DATASET_ID is in the format 'collection/item'.

    Examples:

        portolan info demographics/census          # New command
        portolan info imagery/satellite-2024 --json
    """
    use_json = should_output_json(ctx, json_output)

    # Show deprecation warning (unless JSON output)
    if not use_json:
        warn("'portolan dataset info' is deprecated. Use 'portolan info' instead.")

    try:
        ds = get_dataset_info(catalog_path, dataset_id)

        if use_json:
            envelope = success_envelope(
                "dataset_info",
                {
                    "item_id": ds.item_id,
                    "collection_id": ds.collection_id,
                    "format": ds.format_type.value,
                    "bbox": ds.bbox,
                    "assets": ds.asset_paths,
                    "title": ds.title,
                    "description": ds.description,
                },
            )
            output_json_envelope(envelope)
        else:
            info_output(f"Dataset: {ds.collection_id}/{ds.item_id}")
            if ds.title:
                detail(f"  Title: {ds.title}")
            if ds.description:
                detail(f"  Description: {ds.description}")
            detail(f"  Format: {ds.format_type.value}")
            detail(f"  Bbox: {ds.bbox}")
            if ds.asset_paths:
                detail(f"  Assets: {', '.join(ds.asset_paths)}")
    except KeyError as err:
        if use_json:
            envelope = error_envelope(
                "dataset_info",
                [ErrorDetail(type="KeyError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(str(err))
        raise SystemExit(1) from err


# ─────────────────────────────────────────────────────────────────────────────
# Push command
# ─────────────────────────────────────────────────────────────────────────────


@cli.command()
@click.argument("destination", required=False, default=None)
@click.option(
    "--collection",
    "-c",
    required=True,
    help="Collection to push (required).",
)
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite remote even if it has diverged.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be pushed without uploading.",
)
@click.option(
    "--profile",
    help="AWS profile name (for S3 destinations).",
)
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=".",
    help="Path to catalog root (default: current directory).",
)
@click.pass_context
def push(
    ctx: click.Context,
    destination: str | None,
    collection: str,
    force: bool,
    dry_run: bool,
    profile: str | None,
    catalog_path: Path,
) -> None:
    """Push local catalog changes to cloud object storage.

    Syncs a collection's versions to a remote destination (S3, GCS, Azure).
    Uses optimistic locking to detect concurrent modifications.

    DESTINATION is the object store URL (e.g., s3://mybucket/my-catalog).
    If not provided, uses the 'remote' configured via `portolan config set remote`.

    \b
    Examples:
        portolan push s3://mybucket/catalog --collection demographics
        portolan push gs://mybucket/catalog -c imagery --dry-run
        portolan push s3://mybucket/catalog -c data --force --profile prod
        portolan push --collection demographics  # Uses configured remote
    """
    from portolan_cli.config import get_setting
    from portolan_cli.push import PushConflictError
    from portolan_cli.push import push as push_fn

    use_json = should_output_json(ctx)

    # Resolve destination: CLI arg > env var > config file
    resolved_destination = get_setting(
        "remote",
        cli_value=destination,
        catalog_path=catalog_path,
        collection=collection,
    )

    if resolved_destination is None:
        if use_json:
            envelope = error_envelope(
                "push",
                [
                    ErrorDetail(
                        type="UsageError",
                        message="No destination provided and no 'remote' configured. "
                        "Provide a DESTINATION argument or run: portolan config set remote <url>",
                    )
                ],
            )
            output_json_envelope(envelope)
        else:
            error(
                "No destination provided and no 'remote' configured. "
                "Provide a DESTINATION argument or run: portolan config set remote <url>"
            )
        raise SystemExit(1)

    try:
        result = push_fn(
            catalog_root=catalog_path,
            collection=collection,
            destination=resolved_destination,
            force=force,
            dry_run=dry_run,
            profile=profile,
        )

        if use_json:
            envelope = success_envelope(
                "push",
                {
                    "files_uploaded": result.files_uploaded,
                    "versions_pushed": result.versions_pushed,
                    "conflicts": result.conflicts,
                    "errors": result.errors,
                },
            )
            output_json_envelope(envelope)
        else:
            if result.success:
                if result.versions_pushed > 0:
                    success(
                        f"Pushed {result.versions_pushed} version(s), {result.files_uploaded} file(s)"
                    )
                elif dry_run:
                    # Dry-run mode: push.py already printed what would be done
                    info_output("[DRY RUN] Complete - no files were uploaded")
                else:
                    info_output("Nothing to push - local and remote are in sync")
            else:
                for err_msg in result.errors:
                    error(err_msg)
                raise SystemExit(1)

    except PushConflictError as err:
        if use_json:
            envelope = error_envelope(
                "push",
                [ErrorDetail(type="PushConflictError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(f"Push conflict: {err}")
            info_output("Use --force to overwrite, or pull remote changes first")
        raise SystemExit(1) from err

    except FileNotFoundError as err:
        if use_json:
            envelope = error_envelope(
                "push",
                [ErrorDetail(type="FileNotFoundError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(str(err))
        raise SystemExit(1) from err

    except ValueError as err:
        if use_json:
            envelope = error_envelope(
                "push",
                [ErrorDetail(type="ValueError", message=str(err))],
            )
            output_json_envelope(envelope)
        else:
            error(str(err))
        raise SystemExit(1) from err


# ─────────────────────────────────────────────────────────────────────────────
# Pull command
# ─────────────────────────────────────────────────────────────────────────────


@cli.command()
@click.argument("remote_url")
@click.option(
    "--collection",
    "-c",
    required=True,
    help="Collection to pull.",
)
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=".",
    help="Path to local catalog root (default: current directory).",
)
@click.option(
    "--force",
    is_flag=True,
    help="Discard uncommitted local changes and overwrite with remote.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be downloaded without actually downloading.",
)
@click.option(
    "--profile",
    type=str,
    default=None,
    help="AWS profile name (for S3).",
)
@click.pass_context
def pull_command(
    ctx: click.Context,
    remote_url: str,
    collection: str,
    catalog_path: Path,
    force: bool,
    dry_run: bool,
    profile: str | None,
) -> None:
    """Pull updates from a remote catalog.

    Fetches changes from a remote catalog and downloads updated files.
    Similar to `git pull`, this checks for uncommitted local changes before
    overwriting.

    REMOTE_URL is the remote catalog URL (e.g., s3://bucket/catalog).

    \b
    Examples:
        portolan pull s3://mybucket/my-catalog --collection demographics
        portolan pull s3://mybucket/catalog -c imagery --dry-run
        portolan pull s3://bucket/catalog -c data --force
        portolan pull s3://bucket/catalog -c data --profile myprofile
    """
    from portolan_cli.pull import pull as pull_fn

    use_json = should_output_json(ctx)

    result = pull_fn(
        remote_url=remote_url,
        local_root=catalog_path,
        collection=collection,
        force=force,
        dry_run=dry_run,
        profile=profile,
    )

    if use_json:
        data = {
            "files_downloaded": result.files_downloaded,
            "files_skipped": result.files_skipped,
            "local_version": result.local_version,
            "remote_version": result.remote_version,
            "up_to_date": result.up_to_date,
        }

        if result.success:
            envelope = success_envelope("pull", data)
        else:
            errors = []
            if result.uncommitted_changes:
                errors.append(
                    ErrorDetail(
                        type="UncommittedChangesError",
                        message=f"Uncommitted changes: {', '.join(result.uncommitted_changes)}",
                    )
                )
            else:
                errors.append(ErrorDetail(type="PullError", message="Pull failed"))
            envelope = error_envelope("pull", errors, data=data)

        output_json_envelope(envelope)
    else:
        # Human-readable output
        if result.up_to_date:
            info_output("Already up to date")
        elif result.success:
            if dry_run:
                info_output(f"[DRY RUN] Would pull {result.files_downloaded} file(s)")
            else:
                success(f"Pulled {result.files_downloaded} file(s)")
                detail(f"  Local: {result.local_version} -> {result.remote_version}")
        else:
            if result.uncommitted_changes:
                error("Pull blocked by uncommitted changes:")
                for filename in result.uncommitted_changes:
                    detail(f"  {filename}")
                warn("Use --force to discard local changes")
            else:
                error("Pull failed")

    if not result.success:
        raise SystemExit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Sync command
# ─────────────────────────────────────────────────────────────────────────────


@cli.command()
@click.argument("destination", required=False, default=None)
@click.option(
    "--collection",
    "-c",
    required=True,
    help="Collection to sync (required).",
)
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite conflicts on both pull and push.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would happen without making changes.",
)
@click.option(
    "--fix",
    is_flag=True,
    help="Convert non-cloud-native formats during check.",
)
@click.option(
    "--profile",
    help="AWS profile name (for S3 destinations).",
)
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path),
    default=".",
    help="Path to catalog root (default: current directory).",
)
@click.pass_context
def sync(
    ctx: click.Context,
    destination: str | None,
    collection: str,
    force: bool,
    dry_run: bool,
    fix: bool,
    profile: str | None,
    catalog_path: Path,
) -> None:
    """Sync local catalog with remote storage (pull + push).

    Orchestrates a full sync workflow: Pull -> Init -> Scan -> Check -> Push.
    This is the recommended way to keep a local catalog in sync with remote.

    DESTINATION is the object store URL (e.g., s3://mybucket/my-catalog).

    \b
    Examples:
        portolan sync s3://mybucket/catalog --collection demographics
        portolan sync s3://mybucket/catalog -c imagery --dry-run
        portolan sync s3://mybucket/catalog -c data --fix --force
        portolan sync s3://mybucket/catalog -c data --profile prod
        portolan sync --collection demographics  # Uses configured remote
    """
    from portolan_cli.config import get_setting
    from portolan_cli.sync import sync as sync_fn

    use_json = should_output_json(ctx)

    # Resolve destination: CLI arg > env var > config file
    resolved_destination = get_setting(
        "remote",
        cli_value=destination,
        catalog_path=catalog_path,
        collection=collection,
    )

    if resolved_destination is None:
        if use_json:
            envelope = error_envelope(
                "sync",
                [
                    ErrorDetail(
                        type="UsageError",
                        message="No destination provided and no 'remote' configured. "
                        "Provide a DESTINATION argument or run: portolan config set remote <url>",
                    )
                ],
            )
            output_json_envelope(envelope)
        else:
            error(
                "No destination provided and no 'remote' configured. "
                "Provide a DESTINATION argument or run: portolan config set remote <url>"
            )
        raise SystemExit(1)

    result = sync_fn(
        catalog_root=catalog_path,
        collection=collection,
        destination=resolved_destination,
        force=force,
        dry_run=dry_run,
        fix=fix,
        profile=profile,
    )

    if use_json:
        data: dict[str, Any] = {
            "init_performed": result.init_performed,
            "errors": result.errors,
        }

        # Include pull results if available
        if result.pull_result is not None:
            data["pull"] = {
                "files_downloaded": result.pull_result.files_downloaded,
                "files_skipped": result.pull_result.files_skipped,
                "up_to_date": result.pull_result.up_to_date,
                "local_version": result.pull_result.local_version,
                "remote_version": result.pull_result.remote_version,
            }

        # Include push results if available
        if result.push_result is not None:
            data["push"] = {
                "files_uploaded": result.push_result.files_uploaded,
                "versions_pushed": result.push_result.versions_pushed,
                "conflicts": result.push_result.conflicts,
            }

        if result.success:
            envelope = success_envelope("sync", data)
        else:
            errors = [ErrorDetail(type="SyncError", message=err_msg) for err_msg in result.errors]
            envelope = error_envelope("sync", errors, data=data)

        output_json_envelope(envelope)
    else:
        # Human-readable output is already printed by sync()
        # Just handle the final status
        if result.success:
            if dry_run:
                info_output("[DRY RUN] Sync completed successfully")
            else:
                success("Sync completed successfully")
        else:
            # Errors already logged by sync() - just emit final status
            error("Sync failed")

    if not result.success:
        raise SystemExit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Clone command
# ─────────────────────────────────────────────────────────────────────────────


@cli.command()
@click.argument("remote_url")
@click.argument(
    "local_path",
    type=click.Path(path_type=Path),
    required=False,
    default=None,
)
@click.option(
    "--collection",
    "-c",
    required=False,
    default=None,
    help="Collection to clone. If not specified, clones all collections.",
)
@click.option(
    "--profile",
    help="AWS profile name (for S3 sources).",
)
@click.pass_context
def clone(
    ctx: click.Context,
    remote_url: str,
    local_path: Path | None,
    collection: str | None,
    profile: str | None,
) -> None:
    """Clone a remote catalog to a local directory.

    This is essentially "pull to an empty directory" with guardrails.
    Creates the target directory and pulls collections from remote storage.

    REMOTE_URL is the object store URL (e.g., s3://mybucket/my-catalog).

    LOCAL_PATH is optional - if not provided, it will be inferred from the
    catalog name in the URL (git clone style).

    --collection is optional - if not provided, all collections in the remote
    catalog will be cloned.

    \b
    Examples:
        # Infer directory from URL, clone all collections
        portolan clone s3://mybucket/my-catalog

        # Clone to current directory (must be empty)
        portolan clone s3://mybucket/my-catalog .

        # Clone specific collection
        portolan clone s3://mybucket/catalog -c demographics

        # Clone all collections to specific directory
        portolan clone s3://mybucket/catalog ./local-copy

        # Clone specific collection with profile
        portolan clone s3://mybucket/catalog ./data -c imagery --profile prod
    """
    from portolan_cli.sync import clone as clone_fn
    from portolan_cli.sync import infer_local_path_from_url

    use_json = should_output_json(ctx)

    # Infer local_path from URL if not provided
    if local_path is None:
        try:
            local_path = infer_local_path_from_url(remote_url)
            if not use_json:
                info_output(f"Inferred local path: {local_path}")
        except ValueError as e:
            if use_json:
                envelope = error_envelope(
                    "clone",
                    [ErrorDetail(type="CloneError", message=str(e), code="INVALID_URL")],
                )
                click.echo(json.dumps(envelope, indent=2))
            else:
                error(str(e))
            raise SystemExit(1) from None

    result = clone_fn(
        remote_url=remote_url,
        local_path=local_path,
        collection=collection,
        profile=profile,
    )

    if use_json:
        data: dict[str, Any] = {
            "local_path": str(result.local_path),
            "collections_cloned": result.collections_cloned,
            "total_files_downloaded": result.total_files_downloaded,
        }

        if result.pull_result is not None:
            data["pull"] = {
                "files_downloaded": result.pull_result.files_downloaded,
                "remote_version": result.pull_result.remote_version,
            }

        if result.success:
            envelope = success_envelope("clone", data)
        else:
            errors = [
                ErrorDetail(type="CloneError", message=err, code="CLONE_FAILED")
                for err in result.errors
            ]
            envelope = error_envelope("clone", errors)

        click.echo(json.dumps(envelope, indent=2))
    else:
        if result.success:
            if result.collections_cloned:
                success(
                    f"Clone completed: {result.local_path} "
                    f"({len(result.collections_cloned)} collection(s), "
                    f"{result.total_files_downloaded} file(s))"
                )
            else:
                success(f"Clone completed: {result.local_path}")
        else:
            if result.errors:
                for err_msg in result.errors:
                    error(err_msg)
            error("Clone failed")

    if not result.success:
        raise SystemExit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Config Commands
# ─────────────────────────────────────────────────────────────────────────────


@cli.group()
def config() -> None:
    """Manage catalog configuration.

    Configuration is stored in .portolan/config.yaml and follows this precedence:

    \b
    1. CLI argument (highest)
    2. Environment variable (PORTOLAN_<KEY>)
    3. Collection-level config
    4. Catalog-level config
    5. Built-in default (lowest)

    \b
    Examples:
        portolan config set remote s3://my-bucket/catalog/
        portolan config get remote
        portolan config list
        portolan config unset remote
    """


@config.command("set")
@click.argument("key")
@click.argument("value")
@click.option(
    "--collection",
    "-c",
    type=str,
    default=None,
    help="Set config for a specific collection instead of catalog-level.",
)
@click.pass_context
def config_set(ctx: click.Context, key: str, value: str, collection: str | None) -> None:
    """Set a configuration value.

    KEY is the setting name (e.g., remote, aws_profile).
    VALUE is the value to set.

    \b
    Examples:
        portolan config set remote s3://my-bucket/
        portolan config set aws_profile production
        portolan config set remote s3://public/ --collection demographics
    """
    from portolan_cli.config import set_setting

    use_json = should_output_json(ctx)

    # Find catalog root
    catalog_path = find_catalog_root()
    if catalog_path is None:
        if use_json:
            envelope = error_envelope(
                "config set",
                [ErrorDetail(type="CatalogNotFoundError", message="Not in a Portolan catalog")],
            )
            output_json_envelope(envelope)
        else:
            error("Not in a Portolan catalog")
            info_output("Run 'portolan init' to create one")
        raise SystemExit(1)

    try:
        set_setting(catalog_path, key, value, collection=collection)

        if use_json:
            data = {"key": key, "value": value}
            if collection:
                data["collection"] = collection
            envelope = success_envelope("config set", data)
            output_json_envelope(envelope)
        else:
            if collection:
                success(f"Set {key}={value} for collection '{collection}'")
            else:
                success(f"Set {key}={value}")

    except Exception as e:
        if use_json:
            envelope = error_envelope(
                "config set",
                [ErrorDetail(type=type(e).__name__, message=str(e))],
            )
            output_json_envelope(envelope)
        else:
            error(f"Failed to set config: {e}")
        raise SystemExit(1) from e


@config.command("get")
@click.argument("key")
@click.option(
    "--collection",
    "-c",
    type=str,
    default=None,
    help="Get config for a specific collection.",
)
@click.pass_context
def config_get(ctx: click.Context, key: str, collection: str | None) -> None:
    """Get a configuration value.

    Shows the resolved value and its source (env, catalog, collection, or not set).

    KEY is the setting name (e.g., remote, aws_profile).

    \b
    Examples:
        portolan config get remote
        portolan config get aws_profile --collection restricted
    """
    from portolan_cli.config import get_setting, get_setting_source

    use_json = should_output_json(ctx)

    # Find catalog root
    catalog_path = find_catalog_root()
    if catalog_path is None:
        if use_json:
            envelope = error_envelope(
                "config get",
                [ErrorDetail(type="CatalogNotFoundError", message="Not in a Portolan catalog")],
            )
            output_json_envelope(envelope)
        else:
            error("Not in a Portolan catalog")
            info_output("Run 'portolan init' to create one")
        raise SystemExit(1)

    value = get_setting(key, catalog_path=catalog_path, collection=collection)
    source = get_setting_source(key, catalog_path, collection)

    if use_json:
        data = {
            "key": key,
            "value": value,
            "source": source,
        }
        if collection:
            data["collection"] = collection
        envelope = success_envelope("config get", data)
        output_json_envelope(envelope)
    else:
        if value is not None:
            source_label = f"(from {source})"
            success(f"{key}={value} {source_label}")
        else:
            info_output(f"{key} is not set")
            detail(f"  Set via: portolan config set {key} <value>")
            detail(f"  Or set:  PORTOLAN_{key.upper()}=<value>")


@config.command("list")
@click.option(
    "--collection",
    "-c",
    type=str,
    default=None,
    help="Show config for a specific collection.",
)
@click.pass_context
def config_list(ctx: click.Context, collection: str | None) -> None:
    """List all configuration settings.

    Shows all settings with their values and sources.

    \b
    Examples:
        portolan config list
        portolan config list --collection demographics
    """
    from portolan_cli.config import list_settings

    use_json = should_output_json(ctx)

    # Find catalog root
    catalog_path = find_catalog_root()
    if catalog_path is None:
        if use_json:
            envelope = error_envelope(
                "config list",
                [ErrorDetail(type="CatalogNotFoundError", message="Not in a Portolan catalog")],
            )
            output_json_envelope(envelope)
        else:
            error("Not in a Portolan catalog")
            info_output("Run 'portolan init' to create one")
        raise SystemExit(1)

    settings = list_settings(catalog_path, collection=collection)

    if use_json:
        data: dict[str, Any] = {"settings": settings}
        if collection:
            data["collection"] = collection
        envelope = success_envelope("config list", data)
        output_json_envelope(envelope)
    else:
        if not settings:
            info_output("No configuration settings found")
            detail("  Set values with: portolan config set <key> <value>")
        else:
            if collection:
                info_output(f"Configuration for collection '{collection}':")
            else:
                info_output("Configuration:")
            for key, setting_info in settings.items():
                value = setting_info["value"]
                source = setting_info["source"]
                success(f"  {key}={value} (from {source})")


@config.command("unset")
@click.argument("key")
@click.option(
    "--collection",
    "-c",
    type=str,
    default=None,
    help="Unset config for a specific collection.",
)
@click.pass_context
def config_unset(ctx: click.Context, key: str, collection: str | None) -> None:
    """Remove a configuration value.

    Removes the setting from the config file. Does not affect environment variables.

    KEY is the setting name to remove.

    \b
    Examples:
        portolan config unset remote
        portolan config unset aws_profile --collection restricted
    """
    from portolan_cli.config import unset_setting

    use_json = should_output_json(ctx)

    # Find catalog root
    catalog_path = find_catalog_root()
    if catalog_path is None:
        if use_json:
            envelope = error_envelope(
                "config unset",
                [ErrorDetail(type="CatalogNotFoundError", message="Not in a Portolan catalog")],
            )
            output_json_envelope(envelope)
        else:
            error("Not in a Portolan catalog")
            info_output("Run 'portolan init' to create one")
        raise SystemExit(1)

    removed = unset_setting(catalog_path, key, collection=collection)

    if use_json:
        data = {"key": key, "removed": removed}
        if collection:
            data["collection"] = collection
        envelope = success_envelope("config unset", data)
        output_json_envelope(envelope)
    else:
        if removed:
            if collection:
                success(f"Removed {key} from collection '{collection}' config")
            else:
                success(f"Removed {key} from config")
        else:
            if collection:
                info_output(f"{key} was not set in collection '{collection}' config")
            else:
                info_output(f"{key} was not set in config")


# ─────────────────────────────────────────────────────────────────────────────
# Clean Command
# ─────────────────────────────────────────────────────────────────────────────


def _print_clean_preview(
    catalog_path: Path,
    files_to_remove: list[Path],
    dirs_to_remove: list[Path],
    data_files: int,
) -> None:
    """Print clean preview in text mode (dry-run)."""
    if files_to_remove or dirs_to_remove:
        info_output("Would remove:", dry_run=True)
        for dir_path in dirs_to_remove:
            detail(f"  {dir_path.relative_to(catalog_path)}/", dry_run=True)
        for file_path in files_to_remove:
            detail(f"  {file_path.relative_to(catalog_path)}", dry_run=True)
        click.echo()
        dir_label = "directory" if len(dirs_to_remove) == 1 else "directories"
        info_output(
            f"{len(files_to_remove)} files, {len(dirs_to_remove)} {dir_label} would be removed.",
            dry_run=True,
        )
        info_output(f"Data files preserved: {data_files}", dry_run=True)
    else:
        info_output("Nothing to clean - no metadata files found", dry_run=True)


@cli.command()
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview what would be removed without actually deleting.",
)
@click.pass_context
def clean(ctx: click.Context, dry_run: bool) -> None:
    """Remove all Portolan metadata while preserving data files.

    Removes catalog.json, collection.json, item.json (STAC metadata),
    versions.json, and the .portolan/ directory. Preserves all data files
    (.parquet, .tif, .gpkg, .geojson, etc.).

    Use --dry-run to preview what would be removed without deleting anything.

    \b
    Examples:
        portolan clean           # Remove all metadata
        portolan clean --dry-run # Preview what would be removed
    """
    from portolan_cli.clean import clean_catalog

    use_json = should_output_json(ctx)

    # Find catalog root
    catalog_path = find_catalog_root()
    if catalog_path is None:
        if use_json:
            envelope = error_envelope(
                "clean",
                [
                    ErrorDetail(
                        type="CatalogNotFoundError",
                        message="Not inside a Portolan catalog. Run 'portolan init' first.",
                    )
                ],
            )
            output_json_envelope(envelope)
        else:
            error("Not inside a Portolan catalog")
            info_output("Run 'portolan init' to create one")
        raise SystemExit(1)

    try:
        if dry_run:
            # Preview mode - use clean_catalog with dry_run=True
            files_to_remove, dirs_to_remove, data_files = clean_catalog(catalog_path, dry_run=True)

            if use_json:
                data: dict[str, Any] = {
                    "would_remove_files": [
                        str(f.relative_to(catalog_path)) for f in files_to_remove
                    ],
                    "would_remove_directories": [
                        str(d.relative_to(catalog_path)) for d in dirs_to_remove
                    ],
                    "data_files_preserved": data_files,
                    "dry_run": True,
                }
                envelope = success_envelope("clean", data)
                output_json_envelope(envelope)
            else:
                _print_clean_preview(catalog_path, files_to_remove, dirs_to_remove, data_files)
        else:
            # Actually clean
            files_removed, dirs_removed, data_files = clean_catalog(catalog_path)

            if use_json:
                data = {
                    "files_removed": [str(f.relative_to(catalog_path)) for f in files_removed],
                    "directories_removed": [str(d.relative_to(catalog_path)) for d in dirs_removed],
                    "data_files_preserved": data_files,
                }
                envelope = success_envelope("clean", data)
                output_json_envelope(envelope)
            else:
                if files_removed or dirs_removed:
                    success(f"Removed {len(files_removed)} files, {len(dirs_removed)} directories")
                    detail(f"  Data files preserved: {data_files}")
                else:
                    info_output("Nothing to clean - no metadata files found")

    except OSError as e:
        if use_json:
            envelope = error_envelope(
                "clean",
                [ErrorDetail(type="OSError", message=str(e))],
            )
            output_json_envelope(envelope)
        else:
            error(f"Failed to clean catalog: {e}")
        raise SystemExit(1) from e
