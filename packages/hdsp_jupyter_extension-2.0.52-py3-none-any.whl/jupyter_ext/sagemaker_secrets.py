"""Load secrets from AWS Secrets Manager in SageMaker environments."""

from __future__ import annotations

import json
import os

SECRET_NAME = "WDP-BDP-SCM-JUPYTER-AGENT"

_ALLOWED_KEYS = frozenset({
    "VLLM_ENDPOINT", "VLLM_API_KEY", "VLLM_MODEL",
    "HDSP_ENV", "JUPYTERHUB_USER",
    "SUMMARIZATION_ENABLED", "SUMMARIZATION_ENDPOINT",
    "SUMMARIZATION_API_KEY", "SUMMARIZATION_MODEL",
    "EMBEDDING_ENDPOINT", "EMBEDDING_API_KEY", "EMBEDDING_MODEL",
    "AGENT_SERVER_URL", "AGENT_SERVER_TIMEOUT",
})


def _parse_project_id(space_name: str) -> str | None:
    """Extract HDSP_PRJ_ID from SAGEMAKER_SPACE_NAME.

    Example: 'sm-space-pl2gazuadmu422352-01' → 'pl2gazuadm'
    """
    try:
        parts = space_name.split("-")
        if len(parts) >= 3:
            return parts[2][:10]
    except Exception:
        pass
    return None


def load_sagemaker_secrets():
    """If running in SageMaker, load secrets into os.environ."""
    space_name = os.environ.get("SAGEMAKER_SPACE_NAME")
    if not space_name:
        return

    # Parse HDSP_PRJ_ID from space name
    project_id = _parse_project_id(space_name)
    if project_id and not os.environ.get("HDSP_PRJ_ID"):
        os.environ["HDSP_PRJ_ID"] = project_id

    # Load secrets from AWS Secrets Manager
    try:
        import boto3
    except ImportError:
        print("[HDSP] Warning: boto3 not available, skipping Secrets Manager")
        return

    try:
        client = boto3.client("secretsmanager")
        response = client.get_secret_value(SecretId=SECRET_NAME)
        secrets = json.loads(response["SecretString"])
    except Exception as e:
        print(f"[HDSP] Warning: Failed to load secrets from {SECRET_NAME}: {e}")
        return

    # Inject into os.environ (only allowed keys, skip if already set)
    loaded = 0
    for key, value in secrets.items():
        if key in _ALLOWED_KEYS and not os.environ.get(key):
            os.environ[key] = str(value)
            loaded += 1

    print(f"[HDSP] SageMaker secrets: {loaded} keys loaded from {SECRET_NAME}")
