#!/usr/bin/env bash
###############################################################################
# run.sh — Proxym Simple Example: 3 Tickets with Sequential Analysis
#
# The simplest proxym workflow:
#   1. Register a project
#   2. Create 3 tickets
#   3. Dispatch each one to an AI tool
#   4. Analyze each ticket's result after completion
#
# Usage:
#   bash examples/simple-3-tickets/run.sh
#   bash examples/simple-3-tickets/run.sh --dry-run
#   bash examples/simple-3-tickets/run.sh --tool claude-code
#
# Prerequisites:
#   - proxym server running (proxym serve)
###############################################################################
set -euo pipefail

# ── Configuration ────────────────────────────────────────────────────────────

PROXYM_URL="${PROXYM_URL:-http://localhost:4000}"
PROJECT_DIR="${PROJECT_DIR:-$HOME/projects/simple-demo}"
PROJECT_NAME="simple-demo"
TOOL="${TOOL:-aider}"
DRY_RUN=false
WAIT_TIMEOUT=120  # seconds per job

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run)       DRY_RUN=true; shift ;;
    --project-dir)   PROJECT_DIR="$2"; shift 2 ;;
    --tool)          TOOL="$2"; shift 2 ;;
    --proxy)         PROXYM_URL="$2"; shift 2 ;;
    --help|-h)
      sed -n '2,/^###/p' "$0" | head -n -1 | sed 's/^# \?//'
      exit 0
      ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

CLI="proxym --proxy $PROXYM_URL"

# ── Helpers ──────────────────────────────────────────────────────────────────

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m'; BOLD='\033[1m'; DIM='\033[2m'; RESET='\033[0m'

_hdr()  { echo -e "\n${BOLD}${CYAN}═══ $1 ═══${RESET}"; }
_ok()   { echo -e "  ${GREEN}✓${RESET} $1"; }
_warn() { echo -e "  ${YELLOW}⚠${RESET} $1"; }
_fail() { echo -e "  ${RED}✗${RESET} $1"; }
_info() { echo -e "  ${DIM}$1${RESET}"; }

# Extract ticket ID from proxym output
_extract_tid() {
  grep -oE 'TKT-[A-F0-9]+' | head -1
}

# Wait for all running/queued jobs to finish
_wait_for_jobs() {
  local max_wait="$1"
  local elapsed=0
  while [[ $elapsed -lt $max_wait ]]; do
    local active
    active=$($CLI q 2>&1 | grep -cE "running|queued" || echo 0)
    [[ "$active" -eq 0 ]] && return 0
    sleep 3
    elapsed=$((elapsed + 3))
    printf "\r  ${DIM}⏳ Waiting for job... (%ds/${max_wait}s)${RESET}" "$elapsed"
  done
  echo ""
  _warn "Timeout after ${max_wait}s"
  return 1
}

# ── Main flow ────────────────────────────────────────────────────────────────

echo -e "${BOLD}${CYAN}"
echo "  ╔═══════════════════════════════════════════════════════════╗"
echo "  ║  Proxym: Simple 3-Ticket Example                        ║"
echo "  ║  Create → Dispatch → Analyze (one by one)               ║"
echo "  ╚═══════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

# ── Step 1: Check prerequisites ──────────────────────────────────────────────

_hdr "Step 1 · Prerequisites"

if ! $CLI status >/dev/null 2>&1; then
  _fail "Proxym server not reachable at ${PROXYM_URL}"
  echo "    Start it with: proxym serve"
  exit 1
fi
_ok "Proxym server running at ${PROXYM_URL}"

$CLI tools show "$TOOL" >/dev/null 2>&1 \
  && _ok "Tool '${TOOL}' available" \
  || _warn "Tool '${TOOL}' not found — will use LLM fallback"

# ── Step 2: Create project directory & register ──────────────────────────────

_hdr "Step 2 · Register Project"

if $DRY_RUN; then
  _info "[dry-run] Would create ${PROJECT_DIR} and register as '${PROJECT_NAME}'"
else
  mkdir -p "${PROJECT_DIR}"
  _ok "Directory: ${PROJECT_DIR}"

  $CLI project add "${PROJECT_DIR}" --name "$PROJECT_NAME" --tool "$TOOL" 2>&1 \
    && _ok "Project registered: ${PROJECT_NAME}" \
    || _warn "Project may already exist (continuing)"
fi

# ── Step 3: Create and process 3 tickets sequentially ────────────────────────

# Define the 3 tickets
TICKET_1_DESC="Create a Python module utils.py with three string helper functions: slugify(text) that converts text to URL-friendly slugs, truncate(text, max_len) that truncates with ellipsis, and snake_case(text) that converts to snake_case. Include type hints and docstrings."
TICKET_2_DESC="Write pytest tests for utils.py in test_utils.py. Test each function (slugify, truncate, snake_case) with at least 3 test cases each, including edge cases like empty strings and special characters."
TICKET_3_DESC="Create a CLI entry point cli.py using argparse that exposes the utils.py functions as subcommands: slugify, truncate, snake-case. Each reads from stdin or accepts a positional argument. Include --help for each subcommand."

TICKET_1_TITLE="Create utils.py with string helper functions"
TICKET_2_TITLE="Write pytest tests for utils.py"
TICKET_3_TITLE="Add CLI entry point cli.py using argparse"

declare -a ALL_TITLES=("$TICKET_1_TITLE" "$TICKET_2_TITLE" "$TICKET_3_TITLE")
declare -a ALL_DESCS=("$TICKET_1_DESC" "$TICKET_2_DESC" "$TICKET_3_DESC")
declare -a ALL_TYPES=("feature" "test" "feature")
declare -a ALL_PRIORITIES=("high" "high" "medium")
declare -a ALL_TIDS=()

for i in 0 1 2; do
  local_num=$((i + 1))
  _hdr "Ticket ${local_num}/3 · ${ALL_TITLES[$i]}"

  if $DRY_RUN; then
    _info "[dry-run] Would create: ${ALL_TITLES[$i]}"
    _info "[dry-run] Would dispatch to ${TOOL}"
    _info "[dry-run] Would analyze result"
    continue
  fi

  # ── Create ticket ──
  _info "Creating ticket..."
  local_output=$($CLI ticket add "${ALL_TITLES[$i]}" \
    -p "$PROJECT_NAME" \
    -t "$TOOL" \
    --priority "${ALL_PRIORITIES[$i]}" \
    --type "${ALL_TYPES[$i]}" 2>&1)
  local_tid=$(echo "$local_output" | _extract_tid)

  if [[ -z "$local_tid" ]]; then
    _fail "Failed to create ticket: ${ALL_TITLES[$i]}"
    _info "Output: ${local_output}"
    continue
  fi
  ALL_TIDS+=("$local_tid")
  _ok "Created: ${local_tid}"

  # ── Dispatch ──
  _info "Dispatching ${local_tid} to ${TOOL}..."
  if $CLI tools dispatch --ticket "$local_tid" --tool "$TOOL" --project-dir "$PROJECT_DIR" 2>&1; then
    _ok "Dispatched to ${TOOL}"
  else
    _warn "Dispatch failed — skipping to next ticket"
    continue
  fi

  # ── Wait for completion ──
  _info "Waiting for job to complete..."
  if _wait_for_jobs "$WAIT_TIMEOUT"; then
    echo ""
    _ok "Job completed"
  else
    _warn "Job may still be running"
  fi

  # ── Analyze ──
  echo ""
  _info "Analyzing ticket ${local_tid}..."
  echo ""
  $CLI analyze "$local_tid" 2>/dev/null || _warn "Could not analyze ${local_tid}"
done

# ── Final summary ────────────────────────────────────────────────────────────

_hdr "Summary"

if $DRY_RUN; then
  _info "[dry-run] Would have created and analyzed 3 tickets"
  _info "Run without --dry-run to execute"
else
  echo ""
  _ok "All 3 tickets processed"
  echo ""

  # Show the board
  $CLI board 2>/dev/null || true

  echo ""
  echo -e "${BOLD}Useful commands:${RESET}"
  echo -e "  proxym board                     ${DIM}# kanban board${RESET}"
  echo -e "  proxym ticket list               ${DIM}# all tickets${RESET}"
  for tid in "${ALL_TIDS[@]}"; do
    echo -e "  proxym analyze ${tid}       ${DIM}# check result${RESET}"
  done
  echo -e "  proxym q                         ${DIM}# job queue${RESET}"
  echo ""

  # Show project files if any were created
  if ls "${PROJECT_DIR}"/*.py 2>/dev/null | head -1 >/dev/null 2>&1; then
    _ok "Files created in ${PROJECT_DIR}:"
    ls -la "${PROJECT_DIR}"/*.py 2>/dev/null | sed 's/^/    /'
  fi
fi

echo ""
_ok "Done!"
