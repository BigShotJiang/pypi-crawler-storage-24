#!/usr/bin/env bash
set -e

echo "=== Proxym CLI Shell Scenario ==="

echo "1. Checking server status..."
proxym status

echo "2. Creating project directory on host..."
mkdir -p examples/todo_list_project

echo "3. Registering project in Proxym..."
proxym project add examples/todo_list_project --name "todo-app" --tool "claude-code"

echo "4. Creating initial setup ticket..."
proxym project task "todo-app" "Initialize a basic Node.js TypeScript testing environment with package.json, jest, and tsconfig.json." -t "claude-code" --priority "high"

echo "5. Creating implementation ticket..."
proxym project task "todo-app" "Implement a simple TodoList class in TypeScript with add, remove, and list methods. Add Jest tests for it." -t "claude-code" --priority "medium"

echo "6. Checking board..."
proxym board

echo "7. Starting background executor..."
proxym tools start

echo "8. Checking job queue status..."
sleep 2
proxym q
proxym tools jobs

echo "9. Analyzing tickets (after jobs finish)..."
echo "   Use: proxym analyze <TKT-ID> to check each ticket's result"

echo "=== Scenario Submitted Successfully ==="
echo "The tools are now executing the tasks in the background."
echo "If any tool fails, a ticket for a 'human' will be automatically created in the dashboard."
