"""Brainpack — turn creator content into queryable expert memory."""

__version__ = "0.1.0"
