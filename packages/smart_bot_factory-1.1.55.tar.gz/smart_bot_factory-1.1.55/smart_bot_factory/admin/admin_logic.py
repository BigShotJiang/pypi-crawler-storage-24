# Исправленный admin_logic.py с правильной обработкой диалогов

import logging
from typing import cast

from aiogram import F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from ..handlers.helpers.utils import send_message_parts_with_markup_on_last
from ..i18n.translator import translate
from ..utils.context import ctx

# Импортируем состояния
from .states import AdminStates

logger = logging.getLogger(__name__)

# Создаем роутер для админских обработчиков
admin_router = Router()

HISTORY_PAGE_SIZE = 10


def _history_pagination_keyboard(user_id: int, page: int, total_pages: int) -> InlineKeyboardMarkup | None:
    """Клавиатура пагинации истории: В начало | Назад/Вперёд | В конец."""
    if total_pages <= 1:
        return None
    rows = []
    if page > 0:
        rows.append([InlineKeyboardButton(text="⏪ В начало", callback_data=f"admin_history_{user_id}_0")])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"admin_history_{user_id}_{page - 1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton(text="Вперёд ▶️", callback_data=f"admin_history_{user_id}_{page + 1}"))
    if nav:
        rows.append(nav)
    if page < total_pages - 1:
        rows.append([InlineKeyboardButton(text="В конец ⏩", callback_data=f"admin_history_{user_id}_{total_pages - 1}")])
    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None


@admin_router.message(Command(commands=["отмена", "cancel"]))
async def cancel_handler(message: Message, state: FSMContext):
    """Отмена текущего действия и очистка state"""
    # Получаем текущий state
    current_state = await state.get_state()

    # Очищаем временные файлы если это создание события
    if current_state and current_state.startswith("AdminStates:create_event"):
        from .admin_events import cleanup_temp_files

        await cleanup_temp_files(state)

    # Очищаем state
    await state.clear()

    if current_state:
        logger.info(f"State очищен для пользователя {message.from_user.id}: {current_state}")

        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")

        # Если это админ, возвращаем в админ режим
        if ctx.admin_manager.is_admin(message.from_user.id):
            await state.set_state(AdminStates.admin_mode)
            await message.answer(
                translate("admin.cancel.done_admin", lang=lang),
                parse_mode="Markdown",
            )
        else:
            await message.answer(
                translate("admin.cancel.done_user", lang=lang),
                parse_mode="Markdown",
            )
    else:
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.cancel.no_active", lang=lang), parse_mode="Markdown")


async def admin_start_handler(message: Message, state: FSMContext):
    """Обработчик /start для админов в режиме администратора"""
    await state.set_state(AdminStates.admin_mode)

    # Основное меню админа
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=translate("admin.menu.stats", lang=getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")),
                    callback_data="admin_stats",
                )
            ],
            [
                InlineKeyboardButton(
                    text=translate(
                        "admin.menu.active_chats", lang=getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                    ),
                    callback_data="admin_active_chats",
                )
            ],
            [
                InlineKeyboardButton(
                    text=translate(
                        "admin.menu.toggle_mode", lang=getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                    ),
                    callback_data="admin_toggle_mode",
                )
            ],
        ]
    )

    lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
    welcome_text = translate("admin.panel.welcome", lang=lang).format(
        mode_text=ctx.admin_manager.get_admin_mode_text(message.from_user.id)
    )

    await message.answer(welcome_text, reply_markup=keyboard, parse_mode="Markdown")


@admin_router.message(Command(commands=["стат", "stats"]))
async def admin_stats_handler(message: Message, state: FSMContext):
    """Статистика воронки"""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    try:
        # Показываем кнопки выбора периода
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="📅 7 дней", callback_data="admin_stats_7"),
                    InlineKeyboardButton(text="📅 30 дней", callback_data="admin_stats_30"),
                ]
            ]
        )

        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.stats.choose_period", lang=lang), reply_markup=keyboard)

    except Exception as e:
        logger.error(f"Ошибка получения статистики: {e}")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.stats.error", lang=lang))


async def _send_history_page(
    message: Message,
    user_id: int,
    journey: list,
    page: int,
    state: FSMContext,
) -> None:
    """Форматирует и отправляет одну страницу истории частями, последняя с клавиатурой. Сохраняет message_ids в state."""
    text, total_pages = ctx.analytics_manager.format_user_journey_page(user_id, journey, page, page_size=HISTORY_PAGE_SIZE)
    keyboard = _history_pagination_keyboard(user_id, page, total_pages)
    message_ids = await send_message_parts_with_markup_on_last(message, text, reply_markup_on_last=keyboard)
    await state.update_data(history_message_ids=message_ids, history_user_id=user_id)


@admin_router.message(Command(commands=["история", "history"]))
async def admin_history_handler(message: Message, state: FSMContext):
    """История пользователя (постранично)."""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    try:
        parts = message.text.split()
        if len(parts) < 2:
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("admin.history.usage", lang=lang))
            return

        user_id = int(parts[1])
        journey = await ctx.analytics_manager.get_user_journey(user_id)

        if not journey:
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("admin.history.no_active_session", lang=lang).format(user_id=user_id))
            return

        await _send_history_page(message, user_id, journey, 0, state)

    except ValueError:
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.history.bad_id", lang=lang))
    except Exception as e:
        logger.error(f"Ошибка получения истории: {e}")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.history.error", lang=lang))


@admin_router.message(Command(commands=["чат", "chat"]))
async def admin_chat_handler(message: Message, state: FSMContext):
    """Начать диалог с пользователем"""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    try:
        # Парсим user_id из команды
        parts = message.text.split()
        if len(parts) < 2:
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("admin.chat.usage", lang=lang))
            return

        user_id = int(parts[1])
        admin_id = message.from_user.id

        logger.info(f"👑 Админ {admin_id} хочет начать диалог с пользователем {user_id}")

        # Проверяем, есть ли активная сессия у пользователя
        session_info = await ctx.supabase_client.get_active_session(user_id)
        if not session_info:
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("admin.history.no_active_session", lang=lang).format(user_id=user_id))
            logger.warning(f"❌ У пользователя {user_id} нет активной сессии")
            return

        session_id = getattr(session_info, "id", None) or (session_info.get("id") if isinstance(session_info, dict) else None)
        if not session_id:
            raise ValueError("get_active_session returned object without id")
        logger.info("✅ У пользователя %s есть активная сессия: %s", user_id, session_id)

        # Начинаем диалог
        logger.info("🚀 Запускаем создание диалога...")
        success = await ctx.conversation_manager.start_admin_conversation(admin_id, user_id)

        if success:
            # ✅ ИСПРАВЛЕНИЕ: Правильно переключаем состояние админа
            await state.set_state(AdminStates.in_conversation)
            await state.update_data(conversation_user_id=user_id)

            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("admin.chat.started_long", lang=lang).format(user_id=user_id))
            logger.info("✅ Диалог успешно создан, админ переключен в состояние in_conversation")
        else:
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("admin.chat.start_failed", lang=lang).format(user_id=user_id))
            logger.error("❌ Не удалось создать диалог")

    except ValueError:
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.history.bad_id", lang=lang))
        logger.error(f"❌ Неверный формат ID пользователя: {message.text}")
    except Exception as e:
        logger.error(f"❌ Ошибка начала диалога: {e}")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.chat.error", lang=lang))


@admin_router.message(Command(commands=["чаты", "chats"]))
async def admin_active_chats_command(message: Message, state: FSMContext):
    """Показать активные диалоги админов"""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    try:
        conversations = await ctx.conversation_manager.get_active_conversations()

        # ✅ ИСПРАВЛЕНИЕ: Убираем parse_mode='Markdown' чтобы избежать ошибок парсинга
        await message.answer(ctx.conversation_manager.format_active_conversations(conversations))

    except Exception as e:
        logger.error(f"Ошибка получения активных чатов: {e}")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.chats.error", lang=lang))


@admin_router.message(Command(commands=["стоп", "stop"]))
async def admin_stop_handler(message: Message, state: FSMContext):
    """Завершить диалог"""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    try:
        admin_id = message.from_user.id

        # Проверяем есть ли активный диалог
        conversation = await ctx.conversation_manager.get_admin_active_conversation(admin_id)

        if conversation:
            user_id = conversation["user_id"]
            logger.info(f"🛑 Завершаем диалог админа {admin_id} с пользователем {user_id}")

            success = await ctx.conversation_manager.end_admin_conversation(admin_id)

            # ✅ ДОПОЛНИТЕЛЬНО: Закрываем диалог по user_id для гарантии
            await ctx.supabase_client.end_admin_conversations(user_id=user_id)

            if success:
                # ✅ ИСПРАВЛЕНИЕ: Правильно переключаем состояние обратно
                await state.set_state(AdminStates.admin_mode)
                await state.update_data(conversation_user_id=None)

                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                await message.answer(translate("admin.stop.done", lang=lang).format(user_id=user_id))
                logger.info("✅ Диалог завершен, админ переключен в admin_mode")
            else:
                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                await message.answer(translate("admin.stop.error", lang=lang))
        else:
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("admin.stop.no_active", lang=lang))
            logger.info(f"❌ У админа {admin_id} нет активного диалога")

    except Exception as e:
        logger.error(f"Ошибка завершения диалога: {e}")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.stop.error", lang=lang))


@admin_router.message(Command(commands=["админ", "admin"]))
async def admin_toggle_handler(message: Message, state: FSMContext):
    """Переключение режима админа"""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    if ctx.admin_manager.toggle_admin_mode(message.from_user.id):
        # Переключились в режим админа
        await admin_start_handler(message, state)
    else:
        # Переключились в режим пользователя
        await state.clear()
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.toggle.user_mode", lang=lang))


@admin_router.message(Command(commands=["дашборд", "dashboard"]))
async def admin_dashboard_handler(message: Message, state: FSMContext):
    """Отправка ссылки на дашборд"""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    dashboard_url = "https://dshb.lemifar.ru"
    lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
    dashboard_text = translate("admin.dashboard.text", lang=lang).format(dashboard_url=dashboard_url)

    await message.answer(dashboard_text, parse_mode="Markdown")


@admin_router.message(Command("debug_chat"))
async def debug_chat_handler(message: Message, state: FSMContext):
    """Отладка диалогов админов"""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    parts = message.text.split()
    if len(parts) < 2:
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.debug.usage", lang=lang))
        return

    try:
        user_id = int(parts[1])

        # 1. Проверяем запись в БД
        conversation = await ctx.conversation_manager.is_user_in_admin_chat(user_id)

        debug_info = [
            f"🔍 ОТЛАДКА ДИАЛОГА С {user_id}",
            "",
            f"📊 Диалог в БД: {'✅' if conversation else '❌'}",
        ]

        if conversation:
            debug_info.extend(
                [
                    f"👑 Админ: {conversation['admin_id']}",
                    f"🕐 Начат: {conversation['started_at']}",
                ]
            )

        # 2. Проверяем активную сессию пользователя
        session_info = await ctx.supabase_client.get_active_session(user_id)
        debug_info.append(f"🎯 Активная сессия: {'✅' if session_info else '❌'}")

        if session_info:
            debug_info.append(f"📝 ID сессии: {session_info['id']}")

        # 3. Проверяем состояние пользователя (если он онлайн)
        debug_info.append("")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        debug_info.append(translate("admin.debug.user_must_write", lang=lang))

        await message.answer("\n".join(debug_info))

    except Exception as e:
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("admin.command_error", lang=lang))
        logger.error(f"Ошибка отладки: {e}")


@admin_router.callback_query(F.data.startswith("admin_"))
async def admin_callback_handler(callback: CallbackQuery, state: FSMContext):
    """Обработчик callback кнопок админов"""
    if not ctx.admin_manager.is_admin(callback.from_user.id):
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await callback.answer(translate("admin.access_denied", lang=lang))
        return

    data = callback.data

    try:
        if data == "admin_stats_7" or data == "admin_stats_30":
            # Определяем период
            days = 7 if data == "admin_stats_7" else 30

            # Получаем статистику (фильтрация по bot_id происходит внутри get_funnel_stats)
            funnel_stats = await ctx.analytics_manager.get_funnel_stats(days)
            events_stats = await ctx.analytics_manager.get_events_stats(days)

            # Форматируем ответ
            funnel_text = ctx.analytics_manager.format_funnel_stats(funnel_stats)
            events_text = ctx.analytics_manager.format_events_stats(events_stats)

            full_text = f"{funnel_text}\n\n{events_text}"

            await callback.message.answer(full_text)

        elif data == "admin_toggle_mode":
            # Переключаем режим
            new_mode = ctx.admin_manager.toggle_admin_mode(callback.from_user.id)
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await callback.answer(
                translate("admin.toggle.mode_switched", lang=lang).format(mode=("администратор" if new_mode else "пользователь"))
            )

            if not new_mode:
                await state.clear()
                await callback.message.answer(translate("admin.toggle.now_user_mode", lang=lang))

        elif data == "admin_active_chats":
            # Показываем активные диалоги
            conversations = await ctx.conversation_manager.get_active_conversations()

            # ✅ ИСПРАВЛЕНИЕ: Убираем parse_mode='Markdown'
            await callback.message.answer(ctx.conversation_manager.format_active_conversations(conversations))

        elif data.startswith("admin_history_"):
            parts_data = data.split("_")
            user_id = int(parts_data[2])
            page = int(parts_data[3]) if len(parts_data) > 3 else 0

            state_data = await state.get_data()
            stored_ids = state_data.get("history_message_ids") or []
            stored_user_id = state_data.get("history_user_id")
            if stored_user_id == user_id and stored_ids and ctx.bot:
                chat_id = callback.message.chat.id
                for mid in reversed(stored_ids):
                    try:
                        await ctx.bot.delete_message(chat_id=chat_id, message_id=mid)
                    except TelegramBadRequest:
                        logger.debug(
                            "Failed to delete history message (TelegramBadRequest)",
                            extra={"chat_id": chat_id, "message_id": mid},
                            exc_info=True,
                        )
                    except Exception:
                        logger.warning(
                            "Failed to delete history message",
                            extra={"chat_id": chat_id, "message_id": mid},
                            exc_info=True,
                        )

            journey = await ctx.analytics_manager.get_user_journey(user_id)
            if not journey:
                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                await callback.answer(translate("admin.history.unavailable", lang=lang))
                return

            if callback.message is None:
                await callback.answer()
                return
            await _send_history_page(cast(Message, callback.message), user_id, journey, page, state)

        elif data.startswith("admin_end_"):
            user_id = int(data.split("_")[2])

            # Проверяем есть ли активный диалог
            conversation = await ctx.conversation_manager.get_admin_active_conversation(callback.from_user.id)

            if conversation and conversation["user_id"] == user_id:
                # ✅ ИСПРАВЛЕНИЕ: Закрываем диалог и по admin_id, и по user_id
                await ctx.conversation_manager.end_admin_conversation(callback.from_user.id)

                # ✅ ДОПОЛНИТЕЛЬНО: Закрываем диалог по user_id для гарантии
                await ctx.supabase_client.end_admin_conversations(user_id=user_id)

                # ✅ ИСПРАВЛЕНИЕ: Правильно переключаем состояние
                await state.set_state(AdminStates.admin_mode)
                await state.update_data(conversation_user_id=None)

                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                await callback.answer(translate("admin.chat.ended", lang=lang))
                await callback.message.answer(translate("admin.stop.done", lang=lang).format(user_id=user_id))
                logger.info("✅ Диалог завершен через кнопку, админ переключен в admin_mode")
            else:
                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                await callback.answer(translate("admin.chat.not_found", lang=lang))

        elif data.startswith("admin_chat_"):
            user_id = int(data.split("_")[2])
            admin_id = callback.from_user.id

            success = await ctx.conversation_manager.start_admin_conversation(admin_id, user_id)
            if success:
                # ✅ ИСПРАВЛЕНИЕ: Правильно переключаем состояние
                await state.set_state(AdminStates.in_conversation)
                await state.update_data(conversation_user_id=user_id)

                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                await callback.answer(translate("admin.chat.started", lang=lang))
                await callback.message.answer(translate("admin.chat.started", lang=lang))
                logger.info("✅ Диалог начат через кнопку, админ переключен в in_conversation")
            else:
                lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
                await callback.answer(translate("admin.chat.start_failed_short", lang=lang))

        await callback.answer()

    except Exception as e:
        logger.error(f"Ошибка обработки callback {data}: {e}")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await callback.answer(translate("admin.generic_error", lang=lang))


@admin_router.message(
    StateFilter(AdminStates.admin_mode, AdminStates.in_conversation),
    F.text,
    lambda message: not message.text.startswith("/"),
)
async def admin_message_handler(message: Message, state: FSMContext):
    """Обработчик сообщений админов"""
    if not ctx.admin_manager.is_admin(message.from_user.id):
        return

    try:
        logger.info(f"👑 Получено сообщение от админа {message.from_user.id}: '{message.text}'")

        # Пытаемся обработать как админское сообщение
        handled = await ctx.conversation_manager.route_admin_message(message, state)

        if handled:
            logger.info("✅ Сообщение админа обработано и переслано пользователю")
        else:
            # Не админское сообщение - показываем справку
            logger.info("❌ Сообщение админа не обработано, показываем справку")
            await message.answer(
                """
👑 **Режим администратора**

Доступные команды:
• `/stats` - статистика воронки
• `/dashboard` - ссылка на дашборд аналитики
• `/history user_id` - история пользователя
• `/chat user_id` - начать диалог
• `/chats` - активные диалоги
• `/stop` - завершить диалог
• `/admin` - переключить режим
• `/cancel` - отменить текущее действие

📅 **Управление событиями:**
• `/create_event` - создать новое событие
• `/list_events` - список активных событий
• `/cancel_event название` - отменить событие
• `/edit_event` - редактировать событие

💡 Если вы в диалоге с пользователем, просто напишите сообщение - оно будет переслано пользователю.
""",
                parse_mode="Markdown",
            )

    except Exception as e:
        logger.error(f"Ошибка обработки сообщения админа: {e}")
        await message.answer("❌ Ошибка обработки команды")
