"""
Обработка админских событий и подготовка данных для дашборда.
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, TypedDict

from aiogram.types import FSInputFile, Message
from pydantic import BaseModel, ConfigDict
from telegramify_markdown import standardize

from ...admin.admin_events_utils import (
    create_media_group_from_files,
    send_additional_files_grouped,
)
from ...utils.context import ctx
from .utils import get_bot_or_raise, get_supabase_client_or_raise

logger = logging.getLogger(__name__)


class AdminFileStage(str, Enum):
    WITH_MESSAGE = "with_message"
    AFTER_MESSAGE = "after_message"


class AdminFileType(str, Enum):
    PHOTO = "photo"
    VIDEO = "video"
    DOCUMENT = "document"


class AdminEventFile(BaseModel):
    """
    Описание одного файла, связанного с админским событием.
    """

    model_config = ConfigDict(extra="allow")

    storage_path: str
    original_name: str
    stage: AdminFileStage
    type: AdminFileType
    order: Optional[int] = None
    name: Optional[str] = None


class AdminEventPayload(BaseModel):
    """
    Данные из поля event_data админского события.
    """

    model_config = ConfigDict(extra="allow")

    segment: Optional[str] = None
    message: str
    files: List[AdminEventFile] = []


class AdminEvent(BaseModel):
    """
    Полное описание админского события, приходящего из БД.
    """

    id: int
    event_type: str
    event_data: AdminEventPayload


class AdminEventResult(TypedDict, total=False):
    """
    Структура результата обработки админского события.
    """

    success_count: int
    failed_count: int
    total_users: int
    segment: str
    files_count: int
    message_ids: Dict[int, int]
    error: Optional[str]
    warning: Optional[str]


@dataclass
class DownloadedFilesBundle:
    """
    Набор локальных путей к файлам события, разделённых по этапам отправки.
    """

    with_message: List[AdminEventFile]
    after_message: List[AdminEventFile]
    temp_with_msg_dir: Path
    temp_after_msg_dir: Path


class AdminEventError(Exception):
    """
    Базовая ошибка для обработки админских событий.
    """


class AdminEventParsingError(AdminEventError):
    """
    Ошибка при парсинге исходного события или его payload.
    """


class AdminEventDownloadError(AdminEventError):
    """
    Ошибка при скачивании файлов админского события.
    """


class AdminEventSendError(AdminEventError):
    """
    Ошибка при отправке сообщений или медиа пользователю.
    """


class AdminEventUserSelectionError(AdminEventError):
    """
    Ошибка при получении или подготовке списка пользователей для рассылки.
    """


def _parse_admin_event(raw_event: Mapping[str, Any]) -> AdminEvent:
    """
    Приводит сырой dict события из БД к структурированной модели AdminEvent.
    """
    try:
        event_id_raw = raw_event["id"]
        event_type = raw_event["event_type"]
        event_data_str = raw_event["event_data"]
    except KeyError as exc:
        raise AdminEventParsingError(f"Missing required event field: {exc!s}") from exc

    if not isinstance(event_data_str, str):
        raise AdminEventParsingError("event_data must be a JSON string")

    try:
        event_data_dict = json.loads(event_data_str)
    except Exception as exc:
        raise AdminEventParsingError(f"Failed to parse event_data JSON for event {event_id_raw}") from exc

    try:
        payload = AdminEventPayload.model_validate(event_data_dict)
    except Exception as exc:
        raise AdminEventParsingError(f"Failed to validate AdminEventPayload for event {event_id_raw}") from exc

    try:
        event_id = int(event_id_raw)
    except (TypeError, ValueError) as exc:
        raise AdminEventParsingError(f"Event id must be int-compatible, got {event_id_raw!r}") from exc

    return AdminEvent(id=event_id, event_type=str(event_type), event_data=payload)


async def _download_event_files(event: AdminEvent) -> DownloadedFilesBundle:
    """
    Скачивает все файлы события и возвращает структуру с путями.
    """
    supabase_client = get_supabase_client_or_raise()

    base_temp_dir = Path("temp") / "admin_events" / str(event.id)
    temp_with_msg = base_temp_dir / "with_msg"
    temp_after_msg = base_temp_dir / "after_msg"
    temp_with_msg.mkdir(exist_ok=True)
    temp_after_msg.mkdir(exist_ok=True)

    import asyncio

    async def download_file(file_model: AdminEventFile) -> None:
        try:
            file_bytes = await supabase_client.download_event_file(
                event_id=event.id,
                storage_path=file_model.storage_path,
            )
        except Exception as exc:
            logger.error(
                "Admin event file download failed",
                extra={
                    "event_id": event.id,
                    "storage_path": file_model.storage_path,
                    "error_type": type(exc).__name__,
                },
                exc_info=True,
            )
            raise AdminEventDownloadError(f"Failed to download file from storage_path={file_model.storage_path}") from exc

        if file_model.stage is AdminFileStage.WITH_MESSAGE:
            file_path = temp_with_msg / file_model.original_name
        else:
            file_path = temp_after_msg / file_model.original_name

        with open(file_path, "wb") as file_obj:
            file_obj.write(file_bytes)

        logger.info("📥 Скачан файл", extra={"event_id": event.id, "file_path": str(file_path)})

    download_tasks = [download_file(file_model) for file_model in event.event_data.files]
    await asyncio.gather(*download_tasks)

    with_message_files: List[AdminEventFile] = []
    after_message_files: List[AdminEventFile] = []

    for file_model in event.event_data.files:
        if file_model.stage is AdminFileStage.WITH_MESSAGE:
            with_message_files.append(file_model)
        elif file_model.stage is AdminFileStage.AFTER_MESSAGE:
            after_message_files.append(file_model)

    return DownloadedFilesBundle(
        with_message=with_message_files,
        after_message=after_message_files,
        temp_with_msg_dir=temp_with_msg,
        temp_after_msg_dir=temp_after_msg,
    )


async def _get_target_user_ids(segment: Optional[str], single_user_id: Optional[int]) -> List[int]:
    """
    Определяет список целевых пользователей для рассылки.
    """
    if single_user_id is not None:
        logger.info("Admin event: test broadcast to single user", extra={"telegram_id": single_user_id})
        return [single_user_id]

    if not ctx.supabase_client:
        raise AdminEventUserSelectionError("Supabase client is not initialized for user selection")

    users = await ctx.supabase_client.get_users_by_segment(segment)

    if not users:
        logger.info(
            "Admin event: no users for segment",
            extra={"segment": segment},
        )
        return []

    return [user.telegram_id for user in users]


async def _send_broadcast_to_user(
    telegram_id: int,
    event: AdminEvent,
    downloaded_files: DownloadedFilesBundle,
) -> Optional[Message]:
    """
    Отправляет основное сообщение и связанные с ним файлы одному пользователю.
    """
    if not ctx.bot:
        raise AdminEventSendError("Bot instance is not initialized for admin event sending")

    message_text_raw = event.event_data.message or ""
    message_text = standardize(message_text_raw) if message_text_raw else ""

    files_with_msg = [file_model for file_model in downloaded_files.with_message]

    message: Optional[Message] = None

    if files_with_msg:
        files_for_media_group: List[Dict[str, Any]] = []
        for file_model in files_with_msg:
            file_path = downloaded_files.temp_with_msg_dir / file_model.original_name
            files_for_media_group.append(
                {
                    "file_path": str(file_path),
                    "type": file_model.type.value,
                    "stage": file_model.stage.value,
                    "order": file_model.order,
                    "name": file_model.name,
                }
            )

        media_group = create_media_group_from_files(files_for_media_group, message_text)

        if media_group:
            try:
                messages = await ctx.bot.send_media_group(chat_id=telegram_id, media=media_group)
            except Exception as exc:
                logger.error(
                    "Admin event: failed to send media group",
                    extra={
                        "telegram_id": telegram_id,
                        "event_id": event.id,
                        "error_type": type(exc).__name__,
                    },
                    exc_info=True,
                )
                raise AdminEventSendError("Failed to send media group in admin event") from exc

            if messages:
                message = messages[0]
    else:
        try:
            message = await ctx.bot.send_message(
                chat_id=telegram_id,
                text=message_text,
                parse_mode="MarkdownV2",
            )
        except Exception as exc:
            logger.error(
                "Admin event: failed to send text message",
                extra={
                    "telegram_id": telegram_id,
                    "event_id": event.id,
                    "error_type": type(exc).__name__,
                },
                exc_info=True,
            )
            raise AdminEventSendError("Failed to send text message in admin event") from exc

    files_after = [file_model for file_model in downloaded_files.after_message]

    if files_after:
        files_for_additional: List[Dict[str, Any]] = []
        for file_model in files_after:
            file_path = downloaded_files.temp_after_msg_dir / file_model.original_name
            files_for_additional.append(
                {
                    "file_path": str(file_path),
                    "type": file_model.type.value,
                    "stage": file_model.stage.value,
                    "order": file_model.order,
                    "name": file_model.name,
                }
            )

        try:
            await send_additional_files_grouped(ctx.bot, files_for_additional, telegram_id)
        except Exception as exc:
            logger.error(
                "Admin event: failed to send additional files",
                extra={
                    "telegram_id": telegram_id,
                    "event_id": event.id,
                    "error_type": type(exc).__name__,
                },
                exc_info=True,
            )
            raise AdminEventSendError("Failed to send additional files in admin event") from exc

    return message


async def _finalize_admin_event(event: AdminEvent, downloaded_files: DownloadedFilesBundle) -> None:
    """
    Удаляет временные файлы и записи в хранилище после успешной обработки события.
    """
    shutil.rmtree(downloaded_files.temp_with_msg_dir, ignore_errors=True)
    shutil.rmtree(downloaded_files.temp_after_msg_dir, ignore_errors=True)

    try:
        supabase_client = get_supabase_client_or_raise()
    except RuntimeError:
        # Если Supabase не инициализирован, удаляем только локальные файлы.
        return

    try:
        await supabase_client.delete_event_files(event.id)
    except Exception:
        logger.debug(
            "Failed to delete event files after broadcast",
            extra={"event_id": str(event.id)},
            exc_info=True,
        )


async def process_admin_event_internal(event: AdminEvent, single_user_id: Optional[int]) -> AdminEventResult:
    """
    Оркестратор обработки админского события с использованием строгих типов.
    """
    get_supabase_client_or_raise()
    get_bot_or_raise()

    downloaded_files = await _download_event_files(event)

    try:
        user_ids = await _get_target_user_ids(event.event_data.segment, single_user_id)

        if not user_ids:
            return AdminEventResult(
                success_count=0,
                failed_count=0,
                total_users=0,
                segment=event.event_data.segment or "Все",
                files_count=len(event.event_data.files),
                message_ids={},
                warning="Нет пользователей",
            )

        success_count = 0
        failed_count = 0
        message_ids: Dict[int, int] = {}

        for telegram_id in user_ids:
            try:
                message = await _send_broadcast_to_user(
                    telegram_id=telegram_id,
                    event=event,
                    downloaded_files=downloaded_files,
                )

                if message and hasattr(message, "message_id"):
                    message_ids[telegram_id] = message.message_id

                success_count += 1
                logger.info(
                    "Admin event: message sent to user",
                    extra={"telegram_id": telegram_id, "event_id": event.id},
                )
            except AdminEventSendError as exc:
                logger.error(
                    "Admin event: failed to send to user",
                    extra={
                        "telegram_id": telegram_id,
                        "event_id": event.id,
                        "error_type": type(exc).__name__,
                    },
                    exc_info=True,
                )
                failed_count += 1

        logger.info(
            "Admin event: broadcast result",
            extra={
                "event_name": event.event_type,
                "event_id": event.id,
                "success_count": success_count,
                "failed_count": failed_count,
            },
        )

        return AdminEventResult(
            success_count=success_count,
            failed_count=failed_count,
            total_users=len(user_ids),
            segment=event.event_data.segment or "Все пользователи",
            files_count=len(event.event_data.files),
            message_ids=message_ids,
        )
    finally:
        await _finalize_admin_event(event, downloaded_files)


async def process_admin_event(event: Mapping[str, Any], single_user_id: Optional[int] = None) -> AdminEventResult:
    """
    Обрабатывает одно админское событие - скачивает файлы из Storage и отправляет пользователям.

    Сигнатура оставлена совместимой (Dict -> Mapping, параметр single_user_id с дефолтом),
    но основная логика реализована в строго типизированной функции process_admin_event_internal.
    """
    try:
        typed_event = _parse_admin_event(event)
    except AdminEventParsingError as exc:
        logger.error(
            "Admin event: parsing failed",
            extra={"raw_event": event, "error_type": type(exc).__name__},
            exc_info=True,
        )
        return AdminEventResult(
            success_count=0,
            failed_count=0,
            total_users=0,
            segment="",
            files_count=0,
            message_ids={},
            error=str(exc),
        )

    try:
        result_model = await process_admin_event_internal(typed_event, single_user_id)
    except AdminEventError as exc:
        logger.error(
            "Admin event: processing failed",
            extra={
                "event_id": typed_event.id,
                "event_type": typed_event.event_type,
                "error_type": type(exc).__name__,
            },
            exc_info=True,
        )
        return AdminEventResult(
            success_count=0,
            failed_count=0,
            total_users=0,
            segment=typed_event.event_data.segment or "",
            files_count=len(typed_event.event_data.files),
            message_ids={},
            error=str(exc),
        )

    return result_model


class DashboardInfo(TypedDict):
    title: str
    description: str
    created_at: str


async def prepare_dashboard_info(description_template: str, title: str, user_id: int) -> DashboardInfo:
    """
    Подготавливает данные для дашборда (БЕЗ записи в БД)

    Возвращаемый dict нужно поместить в поле 'info' результата обработчика.
    bot_utils.py автоматически запишет его в столбец info_dashboard таблицы.

    Args:
        description_template: Строка с {username}, например "{username} купил подписку"
        title: Заголовок для дашборда
        user_id: Telegram ID

    Returns:
        Dict с данными для дашборда

    Example:
        @event_router.event_handler("collect_phone", notify=True)
        async def handle_phone_collection(user_id: int, phone_number: str):
            # ... бизнес-логика ...

            return {
                "status": "success",
                "phone": phone_number,
                "info": await prepare_dashboard_info(
                    description_template="{username} оставил телефон",
                    title="Новый контакт",
                    user_id=user_id
                )
            }
    """
    username = f"user_{user_id}"
    if ctx.supabase_client:
        try:
            query = ctx.supabase_client.client.table("sales_users").select("username").eq("telegram_id", user_id)
            query = ctx.supabase_client._with_bot_id(query)
            response = query.execute()
            if response.data:
                username = response.data[0].get("username") or username
        except Exception as e:
            logger.warning(f"⚠️ Не удалось получить username для дашборда: {e}")

    description = description_template.format(username=username)

    moscow_tz = timezone(timedelta(hours=3))
    moscow_time = datetime.now(moscow_tz)

    return {
        "title": title,
        "description": description,
        "created_at": moscow_time.isoformat(),
    }
