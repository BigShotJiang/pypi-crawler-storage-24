"""
Декораторы для регистрации обработчиков и работа с реестрами.

Legacy decorators (@event_handler, @schedule_task, @global_handler) delegate
to an internal EventRouter, so there is only one storage/wrapper mechanism.
"""

import logging
from typing import Any, Callable, Dict, Tuple, Union

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Internal EventRouter that backs the legacy decorator API
# ---------------------------------------------------------------------------
from ..router import EventRouter as _EventRouter

_legacy_router = _EventRouter(name="__legacy__")

_event_handlers: Dict[str, Dict[str, Any]] = _legacy_router._event_handlers
_scheduled_tasks: Dict[str, Dict[str, Any]] = _legacy_router._scheduled_tasks
_global_handlers: Dict[str, Dict[str, Any]] = _legacy_router._global_handlers

# Глобальный менеджер роутеров
_router_manager = None


# ---------------------------------------------------------------------------
# Public decorator API (unchanged signatures)
# ---------------------------------------------------------------------------

def event_handler(
    event_type: str,
    notify: bool = False,
    once_only: bool = True,
    send_ai_response: bool = True,
):
    """
    Декоратор для регистрации обработчика события

    Args:
        event_type: Тип события (например, 'appointment_booking', 'phone_collection')
        notify: Уведомлять ли админов о выполнении события (по умолчанию False)
        once_only: Обрабатывать ли событие только один раз (по умолчанию True)
        send_ai_response: Отправлять ли сообщение от ИИ после обработки события (по умолчанию True)

    Example:
        @event_handler("appointment_booking", notify=True)
        async def book_appointment(user_id: int, appointment_data: dict):
            return {"status": "success", "appointment_id": "123"}

        @event_handler("phone_collection", once_only=False, send_ai_response=False)
        async def collect_phone(user_id: int, phone_data: dict):
            return {"status": "phone_collected"}
    """
    return _legacy_router.event_handler(
        name=event_type,
        notify=notify,
        once_only=once_only,
        send_ai_response=send_ai_response,
    )


def schedule_task(
    task_name: str,
    notify: bool = False,
    notify_time: str = "after",
    smart_check: bool = True,
    once_only: bool = True,
    delay: Union[str, int] = None,
    event_type: Union[str, Callable] = None,
    send_ai_response: bool = True,
):
    """
    Декоратор для регистрации задачи, которую можно запланировать на время

    Args:
        task_name: Название задачи (например, 'send_reminder', 'follow_up')
        notify: Уведомлять ли админов о выполнении задачи (по умолчанию False)
        smart_check: Использовать ли умную проверку активности пользователя (по умолчанию True)
        once_only: Выполнять ли задачу только один раз (по умолчанию True)
        delay: Время задержки в удобном формате (например, "1h 30m", "45m", 3600) - ОБЯЗАТЕЛЬНО
        event_type: Источник времени события - ОПЦИОНАЛЬНО:
            - str: Тип события для поиска в БД (например, 'appointment_booking')
            - Callable: Функция для получения datetime
        send_ai_response: Отправлять ли сообщение от ИИ после выполнения задачи (по умолчанию True)

    Example:
        @schedule_task("send_reminder", delay="1h 30m")
        async def send_reminder(user_id: int, user_data: str):
            return {"status": "sent", "message": user_data}

        @schedule_task("appointment_reminder", delay="2h", event_type="appointment_booking")
        async def appointment_reminder(user_id: int, user_data: str):
            return {"status": "sent", "message": user_data}
    """
    return _legacy_router.schedule_task(
        task_name=task_name,
        notify=notify,
        notify_time=notify_time,
        smart_check=smart_check,
        once_only=once_only,
        delay=delay,
        event_type=event_type,
        send_ai_response=send_ai_response,
    )


def global_handler(
    handler_type: str,
    notify: bool = False,
    once_only: bool = True,
    delay: Union[str, int] = None,
    event_type: Union[str, Callable] = None,
    send_ai_response: bool = True,
):
    """
    Декоратор для регистрации глобального обработчика (для всех пользователей)

    Args:
        handler_type: Тип глобального обработчика
        notify: Уведомлять ли админов о выполнении (по умолчанию False)
        once_only: Выполнять ли обработчик только один раз (по умолчанию True)
        delay: Время задержки - ОБЯЗАТЕЛЬНО
        event_type: Источник времени события - ОПЦИОНАЛЬНО
        send_ai_response: Отправлять ли сообщение от ИИ (по умолчанию True)

    Example:
        @global_handler("global_announcement", delay="2h", notify=True)
        async def send_global_announcement(announcement_text: str):
            return {"status": "sent", "recipients_count": 150}
    """
    return _legacy_router.global_handler(
        name=handler_type,
        notify=notify,
        once_only=once_only,
        delay=delay,
        event_type=event_type,
        send_ai_response=send_ai_response,
    )


# ---------------------------------------------------------------------------
# Getters (unchanged)
# ---------------------------------------------------------------------------

def get_event_handlers() -> Dict[str, Dict[str, Any]]:
    """Возвращает все зарегистрированные обработчики событий"""
    return _event_handlers.copy()


def get_scheduled_tasks() -> Dict[str, Dict[str, Any]]:
    """Возвращает все зарегистрированные задачи"""
    return _scheduled_tasks.copy()


def get_global_handlers() -> Dict[str, Dict[str, Any]]:
    """Возвращает все зарегистрированные глобальные обработчики"""
    return _global_handlers.copy()


def set_router_manager(router_manager):
    """Устанавливает глобальный менеджер роутеров"""
    global _router_manager
    _router_manager = router_manager
    logger.info("🔄 RouterManager установлен в decorators")


def get_router_manager():
    """Получает глобальный менеджер роутеров"""
    return _router_manager


def _get_registry(kind: str) -> Tuple[Dict[str, Any], str]:
    """
    Унифицированный доступ к реестрам (events / tasks / global).
    Возвращает (registry_dict, source) где source: 'router' или 'legacy'.
    """
    router_manager = get_router_manager()

    if router_manager:
        if kind == "event":
            return router_manager.get_event_handlers(), "router"
        if kind == "task":
            return router_manager.get_scheduled_tasks(), "router"
        if kind == "global":
            return router_manager.get_global_handlers(), "router"

    if kind == "event":
        return _event_handlers, "legacy"
    if kind == "task":
        return _scheduled_tasks, "legacy"
    if kind == "global":
        return _global_handlers, "legacy"

    raise ValueError(f"Неизвестный тип реестра: {kind}")


def get_handlers_for_prompt() -> str:
    """Возвращает описание всех обработчиков для добавления в промпт"""
    if _router_manager:
        return _router_manager.get_handlers_for_prompt()

    if not _event_handlers and not _scheduled_tasks and not _global_handlers:
        return ""

    prompt_parts = []

    if _event_handlers:
        prompt_parts.append("ДОСТУПНЫЕ ОБРАБОТЧИКИ СОБЫТИЙ:")
        for event_type, handler_info in _event_handlers.items():
            prompt_parts.append(f"- {event_type}: {handler_info['name']}")

    if _scheduled_tasks:
        prompt_parts.append("\nДОСТУПНЫЕ ЗАДАЧИ ДЛЯ ПЛАНИРОВАНИЯ:")
        for task_name, task_info in _scheduled_tasks.items():
            prompt_parts.append(f"- {task_name}: {task_info['name']}")

    if _global_handlers:
        prompt_parts.append("\nДОСТУПНЫЕ ГЛОБАЛЬНЫЕ ОБРАБОТЧИКИ:")
        for handler_type, handler_info in _global_handlers.items():
            prompt_parts.append(f"- {handler_type}: {handler_info['name']}")

    return "\n".join(prompt_parts)
