# Исправленный handlers.py с отладкой маршрутизации

import logging
import os
import inspect
from typing import Optional

from aiogram import F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from ...utils.bot_utils import send_message
from ...utils.context import ctx
from ...i18n.translator import translate
from ..middlewares.admin import AdminMiddleware
from ..middlewares.rate_limit import RateLimitMiddleware
from ..middlewares.conditional_chat_action import ConditionalChatActionMiddleware
from .admin_chat import check_and_handle_admin_chat
from .commands import commands_router, user_start_handler

# Some unit tests patch async methods with MagicMock. This helper keeps runtime behavior
# (await real coroutines) while tolerating non-awaitable mocks.
async def _maybe_await(value):
    return await value if inspect.isawaitable(value) else value

# Импорты из созданных модулей
from ..helpers.file_handlers import (
    collect_files_for_message,
    send_chat_action_for_files,
    send_files_after_message,
    send_files_before_message,
    send_message_with_files,
)
from ..processing.message_processing import (
    _build_context,
    _enrich_prompt,
    _process_ai_response,
    _process_metadata,
    _validate_message,
)
from ..helpers.utils import (
    apply_send_filters,
    get_parse_mode_and_fix_html,
    prepare_final_response,
    send_critical_error_message,
)
from ..types.constants import MessageRole
from ..types.states import UserStates
from .voice import voice_router

logger = logging.getLogger(__name__)

# ============ РОУТЕР И MIDDLEWARE ============

# Создаем основной роутер и подключаем подроутеры (PARENT для вложенных)
router = Router()
router.include_router(commands_router)
router.include_router(voice_router)

# Rate limit + фильтр не-текстовых сообщений (первым в цепочке)
router.message.middleware(
    RateLimitMiddleware(
        max_messages=int(os.environ.get("RATE_LIMIT_MAX_MESSAGES", "3")),
        window_seconds=int(os.environ.get("RATE_LIMIT_WINDOW_SECONDS", "10")),
    )
)

# Middleware для обновления информации об админах
router.message.middleware(AdminMiddleware())

# Middleware для отправки chat action (typing отключён в admin_chat)
router.message.middleware(ConditionalChatActionMiddleware())


async def admin_middleware(handler, event, data):
    """Обратная совместимость: функция-обертка вокруг AdminMiddleware."""
    middleware = AdminMiddleware()
    return await middleware(handler, event, data)


# ============ ОБРАБОТЧИКИ КОМАНД ============


@router.message(Command(commands=["start", "старт", "ст"]))
async def start_handler(message: Message, state: FSMContext):
    """Обработчик команды /start - сброс сессии и начало заново"""
    from ...admin.admin_logic import admin_start_handler
    from ...utils.debug_routing import debug_user_state

    try:
        await debug_user_state(message, state, "START_COMMAND")

        # Проверяем, админ ли это и в каком режиме
        if ctx.admin_manager.is_admin(message.from_user.id):
            if ctx.admin_manager.is_in_admin_mode(message.from_user.id):
                # Админ в режиме администратора - работаем как админ
                await admin_start_handler(message, state)
                return
            # Админ в режиме пользователя - работаем как обычный пользователь

        await user_start_handler(message, state)

    except Exception as e:
        logger.error(f"Ошибка при обработке /start: {e}")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await send_message(message, translate("user.start.init_error", lang=lang))


# ============ ОБРАБОТЧИКИ СООБЩЕНИЙ БЕЗ СОСТОЯНИЯ ============


@router.message(StateFilter(None))
async def message_without_state_handler(message: Message, state: FSMContext):
    """Обработчик сообщений без состояния (после перезапуска бота)"""
    from ...admin.admin_logic import AdminStates as AdminLogicStates
    from ...utils.debug_routing import debug_user_state

    try:
        await debug_user_state(message, state, "NO_STATE")

        if await check_and_handle_admin_chat(message, state):
            return

        # Проверяем, админ ли это
        if ctx.admin_manager.is_admin(message.from_user.id):
            logger.info("👑 Админ в режиме администратора без состояния")
            await state.set_state(AdminLogicStates.admin_mode)
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await message.answer(translate("user.no_state.admin_mode", lang=lang))
            return

        logger.info("👤 Обычный пользователь без состояния, ищем активную сессию")

        # Ищем активную сессию в БД
        session_info = await ctx.supabase_client.get_active_session(message.from_user.id)

        if session_info:
            session_id = getattr(session_info, "id", None) or (session_info.get("id") if isinstance(session_info, dict) else None)
            if not session_id:
                raise ValueError("get_active_session returned object without id")
            logger.info("📝 Восстанавливаем сессию %s", session_id)
            # Восстанавливаем сессию из БД (без системного промпта)
            session_id = session_id

            # Сохраняем в состояние (без system_prompt)
            await state.update_data(session_id=session_id)
            await state.set_state(UserStates.waiting_for_message)

            logger.info("✅ Сессия восстановлена, обрабатываем сообщение")

            # Теперь обрабатываем сообщение как обычно (системный промпт загрузится из временного файла)
            await process_user_message(message, state, session_id)
        else:
            logger.info("❌ Нет активной сессии, просим написать /start")
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await send_message(message, translate("user.no_state.start_prompt", lang=lang))

    except Exception as e:
        logger.error(f"❌ Ошибка при обработке сообщения без состояния: {e}")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await send_message(message, translate("user.no_state.error_start_prompt", lang=lang))


# ✅ ИСПРАВЛЕНИЕ: Обработчик admin_chat должен быть ПЕРВЫМ и более приоритетным
@router.message(StateFilter(UserStates.admin_chat))
async def user_in_admin_chat_handler(message: Message, state: FSMContext):
    """ПРИОРИТЕТНЫЙ обработчик сообщений пользователей в диалоге с админом"""
    from ...utils.debug_routing import debug_user_state

    await debug_user_state(message, state, "ADMIN_CHAT_HANDLER")

    user_id = message.from_user.id
    logger.info(f"🎯 ADMIN_CHAT HANDLER: сообщение от {user_id}: '{message.text}'")

    if await check_and_handle_admin_chat(message, state):
        return

    logger.info("💬 Диалог завершен или недоступен, возвращаем к обычному режиму")
    await state.set_state(UserStates.waiting_for_message)

    data = await state.get_data()
    session_id = data.get("session_id")
    if not session_id:
        session_info = await _maybe_await(ctx.supabase_client.get_active_session(user_id))
        if session_info:
            session_id = getattr(session_info, "id", None) or (session_info.get("id") if isinstance(session_info, dict) else None)
            await state.update_data(session_id=session_id)
            logger.info("📝 Сессия восстановлена из БД после завершения диалога с админом: %s", session_id)
    if session_id:
        await process_user_message(message, state, session_id)
    else:
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await send_message(message, translate("user.session_not_found_start", lang=lang))


# Обработчик для обычных сообщений (НЕ в admin_chat)
@router.message(StateFilter(UserStates.waiting_for_message), ~F.text.startswith("/"))
async def user_message_handler(message: Message, state: FSMContext):
    """Обработчик сообщений пользователей (исключая admin_chat)"""
    from ...utils.debug_routing import debug_user_state

    try:
        await debug_user_state(message, state, "USER_MESSAGE_HANDLER")

        if await check_and_handle_admin_chat(message, state):
            return

        logger.info("🤖 Обычный диалог с ботом")
        data = await state.get_data()
        session_id = data.get("session_id")

        if not session_id:
            logger.warning("❌ Нет session_id в состоянии")
            lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
            await send_message(message, translate("user.session_not_found_start", lang=lang))
            return

        logger.info(f"📝 Обрабатываем сообщение с session_id: {session_id}")
        await process_user_message(message, state, session_id)

    except Exception as e:
        logger.error(f"❌ Ошибка при обработке сообщения пользователя: {e}")
        await send_message(
            message,
            translate("user.error.try_again_or_start", lang=getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")),
        )


@router.message()
async def catch_all_handler(message: Message, state: FSMContext):
    """Перехватчик всех необработанных сообщений"""
    from ...utils.debug_routing import debug_user_state

    await debug_user_state(message, state, "CATCH_ALL")

    current_state = await state.get_state()
    logger.warning(f"⚠️ НЕОБРАБОТАННОЕ СООБЩЕНИЕ от {message.from_user.id}: '{message.text}', состояние: {current_state}")

    # Проверяем, админ ли это
    if ctx.admin_manager.is_admin(message.from_user.id):
        logger.info("👑 Необработанное сообщение админа")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("user.unknown_command_help", lang=lang))
    else:
        logger.info("👤 Необработанное сообщение пользователя")
        lang = getattr(getattr(ctx, "config", None), "UI_LANGUAGE", "ru")
        await message.answer(translate("user.unknown_message_start", lang=lang))


# ============ PROCESS_USER_MESSAGE ============


async def process_user_message(message: Message, state: FSMContext, session_id: str, recognized_text: Optional[str] = None):
    """Общая функция для обработки сообщений пользователя (текстовых и голосовых)"""
    from ...error_handling import error_boundary

    context = {
        "user_id": message.from_user.id,
        "session_id": session_id,
        "function": "process_user_message",
        "has_recognized_text": bool(recognized_text),
    }

    try:
        async with error_boundary(context=context, suppress=False):
            # ============ ПОДГОТОВКА И ВАЛИДАЦИЯ СООБЩЕНИЯ ============
            user_message_text = recognized_text if recognized_text else message.text

            if not user_message_text or not await _validate_message(user_message_text, message, ctx.message_hooks or {}):
                return

            # ============ СОХРАНЕНИЕ СООБЩЕНИЯ ПОЛЬЗОВАТЕЛЯ ============
            # Пропускаем обновление аналитики, будем обновлять в конце батчем
            if recognized_text:
                await ctx.supabase_client.add_message(
                    session_id=session_id,
                    role=MessageRole.USER,
                    content=recognized_text,
                    message_type="text",
                    metadata={
                        "original_type": "voice",
                        "duration": message.voice.duration if message.voice else 0,
                    },
                    skip_analytics_update=True,
                )
                logger.debug("Распознанное голосовое сообщение сохранено в БД")
            elif message.text:
                await ctx.supabase_client.add_message(
                    session_id=session_id,
                    role=MessageRole.USER,
                    content=message.text,
                    message_type="text",
                    skip_analytics_update=True,
                )
                logger.debug("Сообщение пользователя сохранено в БД")

            # ============ ПОДГОТОВКА ПРОМПТА И КОНТЕКСТА ============
            system_prompt = await ctx.prompt_loader.load_system_prompt()
            logger.debug(f"Системный промпт загружен ({len(system_prompt)} символов)")

            system_prompt_with_time, time_info = await _enrich_prompt(system_prompt, message.from_user.id, ctx.message_hooks or {})

            messages = await _build_context(
                system_prompt_with_time,
                session_id,
                ctx.prompt_loader,
                ctx.memory_manager,
                ctx.message_hooks or {},
                time_info,
            )

            # ============ ПОЛУЧЕНИЕ ОТВЕТА ОТ AI ============
            response_text, ai_metadata, processing_time, ai_response = await _process_ai_response(
                messages, ctx.openai_client, ctx.message_hooks or {}, message.from_user.id
            )

            # ============ ОБРАБОТКА МЕТАДАННЫХ И ФАЙЛОВ ============
            should_send_response, file_senders = await _process_metadata(
                ai_metadata, session_id, message.from_user.id, ctx.supabase_client, response_text, message.chat.id
            )

            await send_chat_action_for_files(message, file_senders)

            # ============ СОХРАНЕНИЕ ОТВЕТА АССИСТЕНТА ============
            tokens_used = ctx.openai_client.estimate_tokens(response_text) if response_text else 0

            db_message_id = None
            try:
                db_message_id = await ctx.supabase_client.add_message(
                    session_id=session_id,
                    role=MessageRole.ASSISTANT,
                    content=response_text,
                    message_type="text",
                    tokens_used=tokens_used,
                    processing_time_ms=processing_time,
                    ai_metadata=ai_metadata,
                    skip_analytics_update=True,
                )
                logger.debug(f"Ответ ассистента сохранен в БД с ID: {db_message_id}")
            except Exception as e:
                logger.error(f"❌ Ошибка сохранения ответа в БД: {e}")

            # ============ БАТЧ-ОБНОВЛЕНИЕ АНАЛИТИКИ ============
            try:
                await ctx.supabase_client.update_session_analytics_batch(
                    session_id=session_id,
                    messages_count=2,
                    tokens_used=tokens_used,
                    processing_time_ms=processing_time,
                )
                logger.debug("Аналитика сессии обновлена (батч)")
            except Exception as e:
                logger.error(f"❌ Ошибка обновления аналитики: {e}")

            # ============ ПОДГОТОВКА ФИНАЛЬНОГО ОТВЕТА ============
            import json

            ai_response_str = json.dumps(ai_response, ensure_ascii=False, indent=2) if isinstance(ai_response, dict) else str(ai_response)
            debug_mode = ctx.config.DEBUG_MODE if ctx.config else False
            final_response = prepare_final_response(response_text, ai_response_str, debug_mode)
            logger.debug(f"Отправляем пользователю: {len(final_response)} символов")

            # ============ ПРОВЕРКА РАЗРЕШЕНИЯ НА ОТПРАВКУ ============
            if not should_send_response:
                logger.info("События запретили отправку сообщения от ИИ, пропускаем отправку")
                return

            await send_files_before_message(file_senders)

            # ============ ПРИМЕНЕНИЕ ФИЛЬТРОВ ОТПРАВКИ ============
            if await apply_send_filters(message.from_user.id):
                return

            # ============ ФОРМАТИРОВАНИЕ И ОТПРАВКА ============
            parse_mode, final_response = get_parse_mode_and_fix_html(final_response)

            file_sender_with_message_files, file_sender_with_message_dirs = collect_files_for_message(file_senders)

            telegram_message_id = await send_message_with_files(
                message,
                final_response,
                file_senders,
                file_sender_with_message_files,
                file_sender_with_message_dirs,
                parse_mode,
            )

            if telegram_message_id and db_message_id:
                try:
                    await ctx.supabase_client.update_message_telegram_id(db_message_id, telegram_message_id)
                    logger.debug(f"✅ Обновлен telegram_message_id={telegram_message_id} для сообщения {db_message_id}")
                except Exception as e:
                    logger.error(f"❌ Ошибка обновления telegram_message_id: {e}")

            await send_files_after_message(file_senders)

    except Exception as e:
        logger.error(f"❌ КРИТИЧЕСКАЯ ОШИБКА в process_user_message: {e}")
        logger.exception("Полный стек ошибки:")
        await send_critical_error_message(message)
