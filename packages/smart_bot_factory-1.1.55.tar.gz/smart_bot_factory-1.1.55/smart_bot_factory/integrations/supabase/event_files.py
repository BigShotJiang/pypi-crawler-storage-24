"""Event files in Supabase Storage (admin-events bucket)."""

import logging
from typing import Dict

from supabase import Client

logger = logging.getLogger(__name__)


class EventFilesRepo:
    def __init__(self, client: Client, bot_id: object) -> None:
        self._client = client
        self._bot_id = bot_id

    async def upload_event_file(
        self,
        event_id: str,
        file_data: bytes,
        original_name: str,
        file_id: str,
    ) -> Dict[str, str]:
        try:
            import mimetypes

            bucket_name = "admin-events"
            extension = original_name.split(".")[-1] if "." in original_name else ""
            storage_name = f"{file_id}.{extension}" if extension else file_id
            storage_path = f"events/{event_id}/files/{storage_name}"

            content_type, _ = mimetypes.guess_type(original_name)
            if not content_type:
                content_type = "application/octet-stream"

            self._client.storage.from_(bucket_name).upload(
                storage_path, file_data, file_options={"content-type": content_type}
            )
            logger.info("File uploaded to Storage: %s", storage_path)
            return {"storage_path": storage_path}
        except Exception as e:
            logger.error("Error uploading file to Storage: %s", e)
            raise

    async def download_event_file(self, event_id: str, storage_path: str) -> bytes:
        try:
            bucket_name = "admin-events"
            file_data = self._client.storage.from_(bucket_name).download(storage_path)
            logger.info("File downloaded from Storage: %s", storage_path)
            return file_data
        except Exception as e:
            logger.error("Error downloading file from Storage: %s", e)
            raise

    async def delete_event_files(self, event_id: str) -> None:
        try:
            bucket_name = "admin-events"
            event_path = f"events/{event_id}/files"
            files_list = self._client.storage.from_(bucket_name).list(event_path)
            if not files_list:
                logger.info("No files to delete for event %s", event_id)
                return
            file_paths = [f"{event_path}/{f['name']}" for f in files_list]
            self._client.storage.from_(bucket_name).remove(file_paths)
            logger.info("Deleted %s files for event %s from Storage", len(file_paths), event_id)
        except Exception as e:
            logger.error("Error deleting event files from Storage: %s", e)
