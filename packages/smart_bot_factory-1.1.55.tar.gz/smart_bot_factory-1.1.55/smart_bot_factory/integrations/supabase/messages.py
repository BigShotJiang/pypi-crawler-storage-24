"""Messages repository (sales_messages)."""

import asyncio
import logging
from typing import Any, Dict, List, Optional

from postgrest.exceptions import APIError
from supabase import Client

from ...error_handling import SUPABASE_RETRY_STRATEGY, SupabaseError, with_retry
from ...utils.performance import measure_time
from ._batch_metrics import get_metrics_instance
from .models import MessageRecord

logger = logging.getLogger(__name__)


class MessagesRepo:
    def __init__(self, client: Client, bot_id: Optional[str]) -> None:
        self._client = client
        self._bot_id = bot_id

    @with_retry(SUPABASE_RETRY_STRATEGY)
    @measure_time(custom_name="Supabase:add_message")
    async def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        message_type: str = "text",
        tokens_used: int = 0,
        processing_time_ms: int = 0,
        metadata: Optional[Dict[str, Any]] = None,
        ai_metadata: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Insert message; caller is responsible for analytics update if needed."""
        try:
            response = (
                self._client.table("sales_messages")
                .insert(
                    {
                        "session_id": session_id,
                        "role": role,
                        "content": content,
                        "message_type": message_type,
                        "tokens_used": tokens_used,
                        "processing_time_ms": processing_time_ms,
                        "metadata": metadata or {},
                        "ai_metadata": ai_metadata or {},
                    }
                )
                .execute()
            )
            message_id = response.data[0]["id"]
            logger.debug("Added message %s to session %s", message_id, session_id)
            return message_id

        except APIError as e:
            logger.error("Error adding message: %s", e)
            raise SupabaseError(f"Failed to add message: {e}", session_id=session_id)

    async def update_message_telegram_id(self, db_message_id: int, telegram_message_id: int) -> None:
        try:
            self._client.table("sales_messages").update({"message_id": telegram_message_id}).eq(
                "id", db_message_id
            ).execute()
            logger.debug("Updated telegram_message_id=%s for message %s", telegram_message_id, db_message_id)
        except APIError as e:
            logger.error("Error updating telegram_message_id: %s", e)
            raise

    @with_retry(SUPABASE_RETRY_STRATEGY)
    @measure_time(custom_name="Supabase:get_chat_history")
    async def get_chat_history(self, session_id: str, limit: int = 50) -> List[MessageRecord]:
        try:
            response = (
                self._client.table("sales_messages")
                .select(
                    "id",
                    "role",
                    "content",
                    "message_type",
                    "created_at",
                    "metadata",
                    "ai_metadata",
                )
                .eq("session_id", session_id)
                .neq("role", "system")
                .order("created_at", desc=True)
                .limit(limit)
                .execute()
            )
            messages = response.data if response.data else []
            if not isinstance(messages, list):
                messages = list(messages) if messages else []
            messages.reverse()
            logger.debug("Got %s messages for session %s", len(messages), session_id)
            return [MessageRecord.model_validate(m) for m in messages]

        except APIError as e:
            logger.error("Error getting chat history: %s", e)
            raise SupabaseError(f"Failed to get chat history: {e}", session_id=session_id)

    async def update_messages_batch(self, updates: List[Dict[str, Any]]) -> bool:
        if not updates:
            logger.debug("update_messages_batch called with empty list")
            return True

        valid_updates = [u for u in updates if u.get("id") and isinstance(u.get("data"), dict)]
        if not valid_updates:
            logger.warning("update_messages_batch: no valid updates (expected {'id': ..., 'data': {...}})")
            return False

        async def _execute_update(message_id: int, data: Dict[str, Any]) -> bool:
            try:
                query = self._client.table("sales_messages").update(data).eq("id", message_id)
                await asyncio.to_thread(query.execute)
                return True
            except APIError as e:
                logger.error("Error updating message %s: %s", message_id, e)
                return False
            except Exception as e:
                logger.error("Unexpected error updating message %s: %s", message_id, e)
                return False

        tasks = [_execute_update(int(u["id"]), u["data"]) for u in valid_updates]  # type: ignore[arg-type]
        results = await asyncio.gather(*tasks, return_exceptions=False)
        success_count = sum(1 for r in results if r)
        all_ok = all(results)

        estimated_saved = max(0, (len(valid_updates) - 1) * 20)
        get_metrics_instance().record_batch(len(valid_updates), estimated_saved)

        logger.info(
            "update_messages_batch: total=%s, success=%s, all_ok=%s",
            len(valid_updates),
            success_count,
            all_ok,
        )
        return all_ok
