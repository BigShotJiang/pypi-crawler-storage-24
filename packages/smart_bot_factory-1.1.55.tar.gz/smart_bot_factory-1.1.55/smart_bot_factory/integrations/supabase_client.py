# Supabase client facade: delegates to repositories. See docs/supabase-repos-refactor-plan.md

import asyncio
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

from supabase import Client, create_client

from .supabase._batch_metrics import get_batch_metrics as _get_batch_metrics, get_metrics_instance
from .supabase.admin_conversations import AdminConversationsRepo
from .supabase.admin_events import AdminEventsRepo
from .supabase.analytics import AnalyticsRepo
from .supabase.event_files import EventFilesRepo
from .supabase.events import SessionEventsRepo
from .supabase.messages import MessagesRepo
from .supabase.models import MessageRecord, SessionRecord, UserRecord
from .supabase.sessions import SessionsRepo
from .supabase.user_files import UserFilesRepo
from .supabase.users import UsersRepo

logger = logging.getLogger(__name__)


def get_batch_metrics() -> Dict[str, Any]:
    """Return current batch operation metrics. Public API."""
    return _get_batch_metrics()


class SupabaseClient:
    """Supabase client facade: delegates to domain repositories. Supports bot_id for multi-bot isolation."""

    def __init__(self, url: str, key: str, bot_id: Optional[str] = None) -> None:
        self.url = url
        self.key = key
        self.bot_id = bot_id
        self.client: Optional[Client] = None
        self._users: Optional[UsersRepo] = None
        self._sessions: Optional[SessionsRepo] = None
        self._messages: Optional[MessagesRepo] = None
        self._analytics: Optional[AnalyticsRepo] = None
        self._events: Optional[SessionEventsRepo] = None
        self._admin_conversations: Optional[AdminConversationsRepo] = None
        self._user_files: Optional[UserFilesRepo] = None
        self._event_files: Optional[EventFilesRepo] = None
        self._admin_events: Optional[AdminEventsRepo] = None

        if self.bot_id:
            logger.debug("Initializing SupabaseClient for bot_id: %s", self.bot_id)
        else:
            logger.warning("SupabaseClient initialized WITHOUT bot_id - multi-bot isolation disabled")

    async def initialize(self) -> None:
        if self.client is not None:
            return
        try:
            self.client = create_client(self.url, self.key)
            self._ensure_repos()
            logger.debug("Supabase client initialized%s", f" for bot_id: {self.bot_id}" if self.bot_id else "")
        except Exception as e:
            logger.error("Supabase client initialization error: %s", e)
            raise

    def _ensure_repos(self) -> None:
        if self.client is None:
            raise RuntimeError("Supabase client not initialized; call await initialize() first")
        if self._users is None:
            self._users = UsersRepo(self.client, self.bot_id)
            self._sessions = SessionsRepo(self.client, self.bot_id)
            self._messages = MessagesRepo(self.client, self.bot_id)
            self._analytics = AnalyticsRepo(self.client, self.bot_id)
            self._events = SessionEventsRepo(self.client, self.bot_id)
            self._admin_conversations = AdminConversationsRepo(self.client, self.bot_id)
            self._user_files = UserFilesRepo(self.client, self.bot_id)
            self._event_files = EventFilesRepo(self.client, self.bot_id)
            self._admin_events = AdminEventsRepo(self.client, self.bot_id)

    def _with_bot_id(self, query: Any) -> Any:
        """Append .eq('bot_id', self.bot_id) to query when bot_id is set. Used by event decorators, analytics, etc."""
        if self.bot_id:
            return query.eq("bot_id", self.bot_id)
        return query

    # -------------------------------------------------------------------------
    # Users
    # -------------------------------------------------------------------------

    async def create_or_get_user(self, user_data: Dict[str, Any]) -> int:
        self._ensure_repos()
        return await self._users.create_or_get_user(user_data)

    async def mark_user_blocked(self, user_id: int) -> bool:
        self._ensure_repos()
        return await self._users.mark_user_blocked(user_id)

    async def get_all_segments(self) -> List[str]:
        self._ensure_repos()
        return await self._users.get_all_segments()

    async def get_users_by_segment(self, segment: Optional[str] = None) -> List[UserRecord]:
        self._ensure_repos()
        return await self._users.get_users_by_segment(segment)

    # -------------------------------------------------------------------------
    # Sessions (create_chat_session orchestration in facade)
    # -------------------------------------------------------------------------

    async def create_chat_session(self, user_data: Dict[str, Any], system_prompt: str = "") -> str:
        self._ensure_repos()
        user_id = await self._users.create_or_get_user(user_data)
        await self._sessions.close_active_sessions(user_id)
        session_data: Dict[str, Any] = {
            "user_id": user_id,
            "system_prompt": "",
            "status": "active",
            "current_stage": "introduction",
            "lead_quality_score": 5,
            "metadata": {
                "user_agent": user_data.get("user_agent", ""),
                "start_timestamp": datetime.now().isoformat(),
            },
        }
        if self.bot_id:
            session_data["bot_id"] = self.bot_id
            session_data["metadata"] = {**session_data["metadata"], "bot_id": self.bot_id}
        session_id = await self._sessions.create_session(session_data)
        await self._analytics.create_session_analytics(session_id)
        logger.info("Created session %s for user %s", session_id, user_id)
        return session_id

    async def close_active_sessions(self, user_id: int) -> None:
        self._ensure_repos()
        await self._sessions.close_active_sessions(user_id)

    async def get_active_session(self, telegram_id: int) -> Optional[Dict[str, Any]]:
        self._ensure_repos()
        session = await self._sessions.get_active_session(telegram_id)
        return session.model_dump() if session else None

    async def create_session_analytics(self, session_id: str) -> None:
        self._ensure_repos()
        await self._analytics.create_session_analytics(session_id)

    # -------------------------------------------------------------------------
    # Messages (add_message: insert + optional analytics in facade)
    # -------------------------------------------------------------------------

    async def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        message_type: str = "text",
        tokens_used: int = 0,
        processing_time_ms: int = 0,
        metadata: Optional[Dict[str, Any]] = None,
        ai_metadata: Optional[Dict[str, Any]] = None,
        skip_analytics_update: bool = False,
    ) -> int:
        self._ensure_repos()
        message_id = await self._messages.add_message(
            session_id=session_id,
            role=role,
            content=content,
            message_type=message_type,
            tokens_used=tokens_used,
            processing_time_ms=processing_time_ms,
            metadata=metadata,
            ai_metadata=ai_metadata,
        )
        if not skip_analytics_update:
            await self._analytics.update_session_analytics(session_id, tokens_used, processing_time_ms)
        return message_id

    async def update_message_telegram_id(self, db_message_id: int, telegram_message_id: int) -> None:
        self._ensure_repos()
        await self._messages.update_message_telegram_id(db_message_id, telegram_message_id)

    async def get_chat_history(self, session_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        self._ensure_repos()
        messages = await self._messages.get_chat_history(session_id, limit)
        return [m.model_dump() for m in messages]

    async def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        self._ensure_repos()
        session = await self._sessions.get_session_info(session_id)
        return session.model_dump() if session else None

    async def get_session_service_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        self._ensure_repos()
        return await self._sessions.get_session_service_info(session_id)

    async def update_session_service_info(self, session_id: str, service_info: Dict[str, Any]) -> bool:
        self._ensure_repos()
        return await self._sessions.update_session_service_info(session_id, service_info)

    async def update_session_all(
        self,
        session_id: str,
        stage: Optional[str] = None,
        quality_score: Optional[int] = None,
        service_info: Optional[Dict[str, Any]] = None,
    ) -> bool:
        self._ensure_repos()
        return await self._sessions.update_session_all(session_id, stage, quality_score, service_info)

    async def batch_check_events_executed(self, event_types: List[str], user_id: int) -> Set[str]:
        self._ensure_repos()
        return await self._events.batch_check_events_executed(event_types, user_id)

    async def batch_insert_events(self, events: List[Dict[str, Any]]) -> List[str]:
        self._ensure_repos()
        return await self._events.batch_insert_events(events)

    async def get_session_processed_events(self, session_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        self._ensure_repos()
        return await self._events.get_session_processed_events(session_id, limit)

    async def update_session(self, session_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        self._ensure_repos()
        return await self._sessions.update_session(session_id, updates)

    async def update_session_stage(
        self,
        session_id: str,
        stage: Optional[str] = None,
        quality_score: Optional[int] = None,
    ) -> None:
        self._ensure_repos()
        await self._sessions.update_session_stage(session_id, stage, quality_score)

    async def get_user_sessions(self, telegram_id: int) -> List[Dict[str, Any]]:
        self._ensure_repos()
        return await self._sessions.get_user_sessions(telegram_id)

    async def add_session_event(self, session_id: str, event_type: str, event_info: str) -> int:
        self._ensure_repos()
        return await self._sessions.add_session_event(session_id, event_type, event_info)

    async def sync_admin(self, admin_data: Dict[str, Any]) -> None:
        self._ensure_repos()
        await self._admin_conversations.sync_admin(admin_data)

    async def start_admin_conversation(self, admin_id: int, user_id: int, session_id: str) -> int:
        self._ensure_repos()
        return await self._admin_conversations.start_admin_conversation(admin_id, user_id, session_id)

    async def end_admin_conversations(
        self,
        admin_id: Optional[int] = None,
        user_id: Optional[int] = None,
    ) -> int:
        self._ensure_repos()
        return await self._admin_conversations.end_admin_conversations(admin_id, user_id)

    async def get_admin_active_conversation(self, admin_id: int) -> Optional[Dict[str, Any]]:
        self._ensure_repos()
        return await self._admin_conversations.get_admin_active_conversation(admin_id)

    async def get_user_conversation(self, user_id: int) -> Optional[Dict[str, Any]]:
        self._ensure_repos()
        return await self._admin_conversations.get_user_conversation(user_id)

    async def cleanup_expired_conversations(self) -> int:
        self._ensure_repos()
        return await self._admin_conversations.cleanup_expired_conversations()

    async def end_expired_conversations(self) -> int:
        self._ensure_repos()
        return await self._admin_conversations.end_expired_conversations()

    async def get_user_admin_conversation(self, user_id: int) -> Optional[Dict[str, Any]]:
        self._ensure_repos()
        return await self._admin_conversations.get_user_admin_conversation(user_id)

    async def get_analytics_summary(self, days: int = 7) -> Dict[str, Any]:
        self._ensure_repos()
        return await self._analytics.get_analytics_summary(days)

    async def update_session_analytics(
        self,
        session_id: str,
        tokens_used: int = 0,
        processing_time_ms: int = 0,
    ) -> None:
        self._ensure_repos()
        await self._analytics.update_session_analytics(session_id, tokens_used, processing_time_ms)

    async def update_session_analytics_batch(
        self,
        session_id: str,
        messages_count: int = 1,
        tokens_used: int = 0,
        processing_time_ms: int = 0,
    ) -> None:
        self._ensure_repos()
        await self._analytics.update_session_analytics_batch(
            session_id, messages_count, tokens_used, processing_time_ms
        )

    async def update_conversion_stage(
        self,
        session_id: str,
        stage: str,
        quality_score: Optional[int] = None,
    ) -> None:
        self._ensure_repos()
        await self._sessions.update_session_stage(session_id, stage, quality_score)

    async def archive_old_sessions(self, days: int = 7) -> None:
        self._ensure_repos()
        await self._sessions.archive_old_sessions(days)

    async def get_sent_files(self, user_id: int) -> List[str]:
        self._ensure_repos()
        return await self._user_files.get_sent_files(user_id)

    async def get_sent_directories(self, user_id: int) -> List[str]:
        self._ensure_repos()
        return await self._user_files.get_sent_directories(user_id)

    async def add_sent_files(self, user_id: int, files_list: List[str]) -> None:
        self._ensure_repos()
        await self._user_files.add_sent_files(user_id, files_list)

    async def add_sent_directories(self, user_id: int, dirs_list: List[str]) -> None:
        self._ensure_repos()
        await self._user_files.add_sent_directories(user_id, dirs_list)

    async def get_sessions_batch(self, session_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        self._ensure_repos()
        return await self._sessions.get_sessions_batch(session_ids)

    async def get_session_with_history(
        self,
        session_id: str,
        history_limit: int = 50,
    ) -> Dict[str, Any]:
        self._ensure_repos()
        tasks = [
            asyncio.create_task(self.get_session_info(session_id)),
            asyncio.create_task(self.get_chat_history(session_id, limit=history_limit)),
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        session_info: Optional[SessionRecord]
        history: List[MessageRecord]
        if isinstance(results[0], Exception):
            logger.error("Error getting session info for %s: %s", session_id, results[0])
            session_info = None
        else:
            session_info = results[0]  # type: ignore[assignment]
        if isinstance(results[1], Exception):
            logger.error("Error getting history for %s: %s", session_id, results[1])
            history = []
        else:
            raw = results[1] or []
            history = list(raw) if isinstance(raw, list) else []
        get_metrics_instance().record_batch(2, 30)
        logger.info("get_session_with_history: session_id=%s, found=%s, history_len=%s", session_id, bool(session_info), len(history))
        return {"session": session_info, "history": history}

    async def update_messages_batch(self, updates: List[Dict[str, Any]]) -> bool:
        self._ensure_repos()
        return await self._messages.update_messages_batch(updates)

    async def get_funnel_stats(self, days: int = 7) -> Dict[str, Any]:
        self._ensure_repos()
        return await self._analytics.get_funnel_stats(days)

    async def get_events_stats(self, days: int = 7) -> Dict[str, int]:
        self._ensure_repos()
        return await self._events.get_events_stats(days)

    async def get_user_last_message_info(self, user_id: int) -> Optional[Dict[str, Any]]:
        self._ensure_repos()
        return await self._sessions.get_user_last_message_info(user_id)

    async def check_user_stage_changed(self, user_id: int, original_session_id: str) -> bool:
        self._ensure_repos()
        return await self._events.check_user_stage_changed(user_id, original_session_id)

    async def get_last_event_info_by_user_and_type(self, user_id: int, event_type: str) -> Optional[str]:
        self._ensure_repos()
        return await self._events.get_last_event_info_by_user_and_type(user_id, event_type)

    async def upload_event_file(
        self,
        event_id: str,
        file_data: bytes,
        original_name: str,
        file_id: str,
    ) -> Dict[str, str]:
        self._ensure_repos()
        return await self._event_files.upload_event_file(event_id, file_data, original_name, file_id)

    async def download_event_file(self, event_id: str, storage_path: str) -> bytes:
        self._ensure_repos()
        return await self._event_files.download_event_file(event_id, storage_path)

    async def delete_event_files(self, event_id: str) -> None:
        self._ensure_repos()
        await self._event_files.delete_event_files(event_id)

    async def save_admin_event(
        self,
        event_name: str,
        event_data: Dict[str, Any],
        scheduled_datetime: datetime,
    ) -> Dict[str, Any]:
        self._ensure_repos()
        return await self._admin_events.save_admin_event(event_name, event_data, scheduled_datetime)

    async def get_admin_events(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        self._ensure_repos()
        return await self._admin_events.get_admin_events(status)

    async def check_event_name_exists(self, event_name: str) -> bool:
        self._ensure_repos()
        return await self._admin_events.check_event_name_exists(event_name)
