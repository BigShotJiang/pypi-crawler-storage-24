"""
Строитель ботов для Smart Bot Factory
"""

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ._builder.detect import detect_bot_id_from_filename
from ._builder.hooks import (
    enrich_context as _enrich_context,
    enrich_prompt as _enrich_prompt,
    filter_send as _filter_send,
    get_message_hooks as _get_message_hooks,
    process_response as _process_response,
    validate_message as _validate_message,
)
from ._builder.init import init_clients, init_config, init_managers
from ._builder.registry import (
    get_start_handlers as _get_start_handlers,
    get_utm_triggers as _get_utm_triggers,
    on_start as _on_start,
    register_rag as _register_rag,
    register_rag_routers as _register_rag_routers,
    register_router as _register_router,
    register_routers as _register_routers,
    register_start_task as _register_start_task,
    register_tool as _register_tool,
    register_tool_set as _register_tool_set,
    register_tool_sets as _register_tool_sets,
    register_tools as _register_tools,
    register_utm_trigger as _register_utm_trigger,
)
from ._builder.tools import (
    register_tools_in_client,
    update_prompts_with_tools,
    update_tools_description_in_prompt_loader,
)
from ._builder.startup import (
    cleanup_resources as _cleanup_resources,
    setup_bot_commands as _setup_bot_commands,
    setup_context as _setup_context,
    start as _start,
)
from ._builder.test_integration import run_tests as _run_tests
from ..admin.admin_manager import AdminManager
from ..analytics.analytics_manager import AnalyticsManager
from ..config import Config
from ..event.decorators.registry import get_handlers_for_prompt
from ..event.router_manager import RouterManager
from ..integrations.openai.langchain_openai import LangChainOpenAIClient
from ..integrations.openai.prompt_loader import PromptLoader
from ..integrations.supabase_client import SupabaseClient
from ..memory.memory_manager import MemoryManager
from ..utils.context import ctx
from ..utils.conversation_manager import ConversationManager
from ..utils.performance import measure_time
from ..utils.prompt_watcher import PromptWatcher

if TYPE_CHECKING:
    from ..rag.router import RagRouter
    from ..utils.tool_router import ToolRouter

logger = logging.getLogger(__name__)


class BotBuilder:
    """
    Строитель ботов, который использует существующие файлы проекта
    и добавляет новые возможности через декораторы
    """

    def __init__(self, bot_id: Optional[str] = None, config_dir: Optional[Path] = None):
        """
        Инициализация строителя бота

        Args:
            bot_id: Идентификатор бота (опционально, если не указан - определяется из имени файла или переменной окружения)
            config_dir: Путь к директории конфигурации (по умолчанию bots/bot_id)
        """
        # Если bot_id не указан, пытаемся определить
        if bot_id is None:
            # Сначала проверяем переменную окружения (устанавливается в cli.py)
            bot_id = os.environ.get("BOT_ID")
            if bot_id:
                logger.info(f"🔍 bot_id получен из переменной окружения: {bot_id}")
            else:
                bot_env_vars = [k for k in os.environ.keys() if "BOT" in k.upper()]
                logger.debug(f"🔍 BOT_ID не найден в переменных окружения. Доступные переменные с 'BOT': {bot_env_vars}")
                # Пытаемся определить из имени файла
                bot_id = self._detect_bot_id_from_filename()
                if bot_id:
                    logger.info(f"🔍 bot_id автоматически определен из имени файла: {bot_id}")
                else:
                    raise ValueError("bot_id не указан и не может быть определен автоматически. Укажите bot_id явно: BotBuilder(bot_id='my-bot')")

        self.bot_id = bot_id
        self.config_dir = config_dir or Path("bots") / bot_id

        # Компоненты бота
        self.config: Optional[Config] = None
        self.openai_client: Optional[LangChainOpenAIClient] = None
        self.supabase_client: Optional[SupabaseClient] = None
        self.conversation_manager: Optional[ConversationManager] = None
        self.admin_manager: Optional[AdminManager] = None
        self.analytics_manager: Optional[AnalyticsManager] = None
        self.prompt_loader: Optional[PromptLoader] = None
        self.router_manager: Optional[RouterManager] = None
        self.memory_manager: Optional[MemoryManager] = None
        self.prompt_watcher: Optional[PromptWatcher] = None
        self._telegram_routers: List = []  # Список Telegram роутеров
        self._start_handlers: List = []  # Список обработчиков on_start
        self._start_tasks: List = []  # Корутины для фонового запуска при start() (например periodic RAG refresh)
        self.rag_pipeline: Optional[Any] = None  # ParserRagPipeline для команды /refresh_rag и периодического обновления
        self._utm_triggers: List = []  # Список UTM-триггеров
        self._tools: List = []  # Список инструментов для ChatOpenAI
        self._tool_routers: List = []  # Зарегистрированные роутеры инструментов
        self._rag_routers: List = []  # Зарегистрированные RAG-роутеры

        # Хуки для кастомизации process_user_message
        self._message_validators: List = []  # Валидация ДО обработки
        self._prompt_enrichers: List = []  # Обогащение системного промпта
        self._context_enrichers: List = []  # Обогащение контекста для AI
        self._response_processors: List = []  # Обработка ответа AI
        self._send_filters: List = []  # Фильтры перед отправкой пользователю

        # Кастомный PromptLoader
        self._custom_prompt_loader = None

        # Кастомный процессор событий
        self._custom_event_processor = None

        # Флаги инициализации
        self._initialized = False

        logger.info(f"🏗️ Создан BotBuilder для бота: {bot_id}")

    @staticmethod
    def _detect_bot_id_from_filename() -> Optional[str]:
        """
        Автоматически определяет bot_id из имени файла, который создает BotBuilder

        Returns:
            bot_id если удалось определить, None в противном случае
        """
        return detect_bot_id_from_filename()

    @measure_time(min_ms=50, custom_name="bot_build")
    async def build(self, force: bool = False) -> "BotBuilder":
        """
        Строит и инициализирует все компоненты бота

        Идемпотентный метод: можно вызывать многократно без побочных эффектов.
        При повторном вызове без force=True просто возвращает self.

        Args:
            force: Если True, принудительно пересобирает бота даже если уже инициализирован

        Returns:
            BotBuilder: Возвращает self для цепочки вызовов
        """
        if self._initialized and not force:
            # Идемпотентность: тихо возвращаем без warning
            return self

        if force and self._initialized:
            logger.info(f"🔄 Принудительная пересборка бота {self.bot_id}")
            self._initialized = False
            # Сбрасываем состояние компонентов для пересборки
            self.config = None
            self.openai_client = None
            self.supabase_client = None
            self.conversation_manager = None
            self.admin_manager = None
            self.analytics_manager = None
            self.prompt_loader = None
            self.memory_manager = None

        try:
            logger.info(f"🚀 Начинаем сборку бота {self.bot_id}")

            # 1. Инициализируем конфигурацию
            await self._init_config()

            # 2. Инициализируем клиенты
            await self._init_clients()

            # 3. Инициализируем менеджеры
            await self._init_managers()

            # 4. Регистрируем инструменты в OpenAI клиенте
            await self._register_tools_in_client()

            # 5. Обновляем промпты с информацией о доступных инструментах
            await self._update_prompts_with_tools()

            # 6. Обновляем описание инструментов в промпт-лоадере
            await self._update_tools_description_in_prompt_loader()

            self._initialized = True
            logger.info(f"✅ Бот {self.bot_id} успешно собран и готов к работе")

            return self

        except Exception as e:
            logger.error(f"❌ Ошибка при сборке бота {self.bot_id}: {e}")
            raise

    async def _init_config(self):
        """Инициализация конфигурации"""
        await init_config(self, Config)

    async def _init_clients(self):
        """Инициализация клиентов"""
        await init_clients(self, LangChainOpenAIClient, SupabaseClient)

    async def _register_tools_in_client(self):
        """Регистрирует зарегистрированные инструменты в OpenAI клиенте"""
        await register_tools_in_client(self)

    async def _update_tools_description_in_prompt_loader(self):
        """Обновляет описание инструментов в PromptLoader"""
        await update_tools_description_in_prompt_loader(self)

    async def _init_managers(self):
        """Инициализация менеджеров"""
        await init_managers(
            self,
            AdminManager,
            AnalyticsManager,
            ConversationManager,
            RouterManager,
            PromptLoader,
            PromptWatcher,
            MemoryManager,
        )

    async def _update_prompts_with_tools(self):
        """
        Обновляет промпты информацией о доступных обработчиках событий
        """
        await update_prompts_with_tools(self)

    def get_tools_prompt(self) -> str:
        """Возвращает промпт с информацией об инструментах"""
        return getattr(self, "_tools_prompt", "")

    def get_status(self) -> Dict[str, Any]:
        """Возвращает статус бота"""
        return {
            "bot_id": self.bot_id,
            "initialized": self._initialized,
            "config_dir": str(self.config_dir),
            "components": {
                "config": self.config is not None,
                "openai_client": self.openai_client is not None,
                "supabase_client": self.supabase_client is not None,
                "conversation_manager": self.conversation_manager is not None,
                "admin_manager": self.admin_manager is not None,
                "analytics_manager": self.analytics_manager is not None,
                "prompt_loader": self.prompt_loader is not None,
            },
            "tools": {
                "event_handlers": (len(get_handlers_for_prompt().split("\n")) if get_handlers_for_prompt() else 0),
                "chatopenai_tools": len(self._tools),
            },
        }

    def register_router(self, router):
        """
        Регистрирует роутер событий в менеджере роутеров

        Args:
            router: EventRouter для регистрации
        """
        _register_router(self, router)

    def register_routers(self, *routers):
        """
        Универсальный метод для регистрации роутеров любого типа.
        Автоматически определяет тип роутера и регистрирует его в нужном месте.

        Поддерживаемые типы роутеров:
        - EventRouter (включая FileRouter) -> регистрируется как роутер событий
        - RagRouter -> регистрируется как RAG-роутер
        - ToolRouter (но не RagRouter) -> регистрируется как набор инструментов
        - aiogram.Router -> регистрируется как Telegram роутер

        Args:
            *routers: Произвольное количество роутеров любого поддерживаемого типа

        Example:
            # EventRouter
            bot_builder.register_routers(event_router)

            # FileRouter (наследуется от EventRouter)
            bot_builder.register_routers(file_router)

            # RAG роутер
            bot_builder.register_routers(rag_router)

            # Telegram роутер
            from aiogram import Router
            telegram_router = Router(name="commands")
            bot_builder.register_routers(telegram_router)

            # Можно регистрировать несколько роутеров разных типов одновременно
            bot_builder.register_routers(event_router, file_router, rag_router, telegram_router)
        """
        # Keep Telegram router detection in this file (tests patch isinstance here)
        if not routers:
            logger.warning("⚠️ register_routers вызван без аргументов")
            return

        AiogramRouter: Optional[type] = None
        try:
            from aiogram import Router as AiogramRouterType

            AiogramRouter = AiogramRouterType
        except ImportError:
            AiogramRouter = None

        telegram_routers = []
        non_telegram_routers = []
        for router in routers:
            if AiogramRouter and isinstance(router, AiogramRouter):
                telegram_routers.append(router)
            else:
                non_telegram_routers.append(router)

        if non_telegram_routers:
            _register_routers(self, tuple(non_telegram_routers))
        if telegram_routers:
            for tr in telegram_routers:
                self.register_telegram_router(tr)
            logger.info("✅ Зарегистрировано %s Telegram роутеров", len(telegram_routers))

    def register_telegram_router(self, telegram_router):
        """
        Регистрирует Telegram роутер для обработки команд и сообщений

        Args:
            telegram_router: aiogram.Router для регистрации

        Example:
            from aiogram import Router
            from aiogram.filters import Command

            # Создаем обычный aiogram Router
            my_router = Router(name="my_commands")

            @my_router.message(Command("price"))
            async def price_handler(message: Message):
                await message.answer("Наши цены...")

            # Регистрируем в боте
            bot_builder.register_telegram_router(my_router)
        """
        from aiogram import Router as AiogramRouter

        if not isinstance(telegram_router, AiogramRouter):
            raise TypeError(f"Ожидается aiogram.Router, получен {type(telegram_router)}")

        self._telegram_routers.append(telegram_router)
        router_name = getattr(telegram_router, "name", "unnamed")
        logger.info(f"✅ Telegram роутер '{router_name}' зарегистрирован в боте {self.bot_id}")

    def register_telegram_routers(self, *telegram_routers):
        """
        Регистрирует несколько Telegram роутеров одновременно

        Args:
            *telegram_routers: Произвольное количество aiogram.Router

        Example:
            from aiogram import Router

            router1 = Router(name="commands")
            router2 = Router(name="callbacks")

            bot_builder.register_telegram_routers(router1, router2)
        """
        if not telegram_routers:
            logger.warning("⚠️ register_telegram_routers вызван без аргументов")
            return

        for router in telegram_routers:
            self.register_telegram_router(router)

        logger.info(f"✅ Зарегистрировано {len(telegram_routers)} Telegram роутеров")

    def register_tool(self, tool):
        """
        Регистрирует инструмент для ChatOpenAI

        Args:
            tool: Инструмент LangChain (например, StructuredTool, FunctionTool и т.д.)

        Example:
            from langchain_core.tools import StructuredTool
            from pydantic import BaseModel, Field

            class CalculatorInput(BaseModel):
                a: float = Field(description="Первое число")
                b: float = Field(description="Второе число")

            def add(a: float, b: float) -> float:
                return a + b

            calculator_tool = StructuredTool.from_function(
                func=add,
                name="calculator",
                description="Складывает два числа",
                args_schema=CalculatorInput
            )

            bot_builder.register_tool(calculator_tool)
        """
        _register_tool(self, tool)

    def register_tools(self, *tools):
        """
        Регистрирует несколько инструментов для ChatOpenAI одновременно

        Args:
            *tools: Произвольное количество инструментов LangChain или список(ы) инструментов

        Example:
            from langchain_core.tools import StructuredTool

            tool1 = StructuredTool.from_function(...)
            tool2 = StructuredTool.from_function(...)
            tool3 = StructuredTool.from_function(...)

            # Отдельные инструменты
            bot_builder.register_tools(tool1, tool2, tool3)

            # Список инструментов
            bot_builder.register_tools([tool1, tool2, tool3])
        """
        _register_tools(self, tools)

    def register_tool_set(self, tool_router: "ToolRouter"):
        """
        Регистрирует роутер обычных инструментов LangChain.
        """
        return _register_tool_set(self, tool_router)

    def register_tool_sets(self, *tool_routers: "ToolRouter"):
        """
        Регистрирует несколько роутеров обычных инструментов.
        """
        _register_tool_sets(self, tool_routers)

    def register_rag(self, rag_router: "RagRouter"):
        """
        Регистрирует RAG-роутер и все его инструменты.

        Args:
            rag_router: Экземпляр RagRouter с описанными инструментами.
        """
        return _register_rag(self, rag_router)

    def register_rag_routers(self, *rag_routers: "RagRouter"):
        """
        Регистрирует несколько RAG-роутеров.
        """
        _register_rag_routers(self, rag_routers)

    def on_start(self, handler):
        """
        Регистрирует обработчик, который вызывается после стандартной логики /start

        Обработчик получает доступ к:
        - user_id: int - ID пользователя Telegram
        - session_id: str - ID созданной сессии
        - message: Message - Объект сообщения от aiogram
        - state: FSMContext - Контекст состояния

        Args:
            handler: Async функция с сигнатурой:
                     async def handler(user_id: int, session_id: str, message: Message, state: FSMContext)

        Example:
            @bot_builder.on_start
            async def my_start_handler(user_id, session_id, message, state):
                keyboard = InlineKeyboardMarkup(...)
                await message.answer("Выберите действие:", reply_markup=keyboard)
        """
        return _on_start(self, handler)

    def get_start_handlers(self) -> List:
        """Получает список обработчиков on_start"""
        return _get_start_handlers(self)

    def register_start_task(self, coro_fn: Any) -> None:
        """
        Регистрирует асинхронную задачу для запуска при start() (например периодическое обновление RAG).
        coro_fn должна быть корутиной без аргументов (или вызываемой без аргументов), например:
          bot_builder.register_start_task(lambda: periodic_rag_refresh(pipeline, 3600))
        """
        _register_start_task(self, coro_fn)

    def register_utm_trigger(
        self,
        message: str,
        source: Optional[str] = None,
        medium: Optional[str] = None,
        campaign: Optional[str] = None,
        content: Optional[str] = None,
        term: Optional[str] = None,
        segment: Optional[str] = None,
    ):
        """
        Регистрирует UTM-триггер для обработки /start с определенными UTM параметрами

        Если UTM данные совпадают с указанными значениями, отправляется сообщение из файла
        и вся стандартная логика /start пропускается.

        Args:
            message: Имя файла с сообщением, которое будет отправлено при совпадении.
                    Файл должен находиться в директории bots/bot_id/utm_message/.
                    Содержимое файла будет прочитано и использовано как сообщение.
            source: Целевое значение utm_source (или None для игнорирования)
            medium: Целевое значение utm_medium (или None для игнорирования)
            campaign: Целевое значение utm_campaign (или None для игнорирования)
            content: Целевое значение utm_content (или None для игнорирования)
            term: Целевое значение utm_term (или None для игнорирования)
            segment: Целевое значение segment (или None для игнорирования)

        Example:
            # Триггер для конкретной кампании
            # Файл должен находиться в bots/mdclinica/utm_message/summer_campaign.txt
            bot_builder.register_utm_trigger(
                message='summer_campaign.txt',
                source='vk',
                campaign='summer2025'
            )

            # Триггер для сегмента
            # Файл должен находиться в bots/mdclinica/utm_message/premium_welcome.txt
            bot_builder.register_utm_trigger(
                message='premium_welcome.txt',
                segment='premium'
            )

            # Триггер с несколькими параметрами
            # Файл должен находиться в bots/mdclinica/utm_message/new_year.txt
            bot_builder.register_utm_trigger(
                message='new_year.txt',
                source='instagram',
                medium='story',
                campaign='new_year'
            )
        """
        _register_utm_trigger(self, message, source, medium, campaign, content, term, segment)

    def get_utm_triggers(self) -> List:
        """Получает список UTM-триггеров"""
        return _get_utm_triggers(self)

    def set_prompt_loader(self, prompt_loader):
        """
        Устанавливает кастомный PromptLoader

        Должен быть вызван ДО build()

        Args:
            prompt_loader: Экземпляр PromptLoader или его наследника (например UserPromptLoader)

        Example:
            from smart_bot_factory.utils import UserPromptLoader

            # Использовать UserPromptLoader с автопоиском prompts_dir
            custom_loader = UserPromptLoader("my-bot")
            bot_builder.set_prompt_loader(custom_loader)

            # Или кастомный наследник
            class MyPromptLoader(UserPromptLoader):
                def __init__(self, bot_id):
                    super().__init__(bot_id)
                    self.extra_file = self.prompts_dir / 'extra.txt'

            my_loader = MyPromptLoader("my-bot")
            bot_builder.set_prompt_loader(my_loader)
        """
        self._custom_prompt_loader = prompt_loader
        logger.info(f"✅ Установлен кастомный PromptLoader: {type(prompt_loader).__name__}")

    def set_event_processor(self, custom_processor):
        """
        Устанавливает кастомную функцию для обработки событий

        Полностью заменяет стандартную process_events из bot_utils

        Args:
            custom_processor: async def(session_id: str, events: list, user_id: int)

        Example:
            from smart_bot_factory.message import get_bot
            from smart_bot_factory.core.decorators import execute_event_handler

            async def my_process_events(session_id, events, user_id):
                '''Моя кастомная обработка событий'''
                bot = get_bot()

                for event in events:
                    event_type = event.get('тип')
                    event_info = event.get('инфо')

                    if event_type == 'запись':
                        # Кастомная логика для бронирования
                        telegram_user = await bot.get_chat(user_id)
                        name = telegram_user.first_name or 'Клиент'
                        # ... ваша обработка
                    else:
                        # Для остальных - стандартная обработка
                        await execute_event_handler(event_type, user_id, event_info)

            bot_builder.set_event_processor(my_process_events)
        """
        if not callable(custom_processor):
            raise TypeError(f"Процессор должен быть callable, получен {type(custom_processor)}")

        self._custom_event_processor = custom_processor
        logger.info(f"✅ Установлена кастомная функция обработки событий: {custom_processor.__name__}")

    # ========== ХУКИ ДЛЯ КАСТОМИЗАЦИИ ОБРАБОТКИ СООБЩЕНИЙ ==========

    def validate_message(self, handler):
        """
        Регистрирует валидатор сообщений (вызывается ДО обработки AI)

        Если валидатор возвращает False, обработка прерывается

        Args:
            handler: async def(message: Message, supabase_client) -> bool

        Example:
            @bot_builder.validate_message
            async def check_service_names(message, supabase_client):
                if "неправильное название" in message.text:
                    await message.answer("Пожалуйста, уточните название услуги")
                    return False  # Прерываем обработку
                return True  # Продолжаем
        """
        return _validate_message(self, handler)

    def enrich_prompt(self, handler):
        """
        Регистрирует обогатитель системного промпта

        Args:
            handler: async def(system_prompt: str, user_id: int, session_id: str, supabase_client) -> str

        Example:
            @bot_builder.enrich_prompt
            async def add_client_info(system_prompt, user_id, session_id, supabase_client):
                session = await supabase_client.get_active_session(user_id)
                phone = (session.metadata or {}).get("phone") if session else None
                if phone:
                    return f"{system_prompt}\\n\\nТелефон клиента: {phone}"
                return system_prompt
        """
        return _enrich_prompt(self, handler)

    def enrich_context(self, handler):
        """
        Регистрирует обогатитель контекста для AI (messages array)

        Args:
            handler: async def(messages: List[dict], user_id: int, session_id: str) -> List[dict]

        Example:
            @bot_builder.enrich_context
            async def add_external_data(messages, user_id, session_id):
                # Добавляем данные из внешнего API
                messages.append({
                    "role": "system",
                    "content": "Дополнительная информация..."
                })
                return messages
        """
        return _enrich_context(self, handler)

    def process_response(self, handler):
        """
        Регистрирует обработчик ответа AI (ПОСЛЕ получения ответа)

        Args:
            handler: async def(response_text: str, ai_metadata: dict, user_id: int) -> tuple[str, dict]

        Example:
            @bot_builder.process_response
            async def modify_response(response_text, ai_metadata, user_id):
                # Модифицируем ответ
                if "цена" in response_text.lower():
                    response_text += "\\n\\n💰 Актуальные цены на сайте"
                return response_text, ai_metadata
        """
        return _process_response(self, handler)

    def filter_send(self, handler):
        """
        Регистрирует фильтр отправки (может блокировать отправку пользователю)

        Если фильтр возвращает True, сообщение НЕ отправляется

        Args:
            handler: async def(user_id: int) -> bool

        Example:
            @bot_builder.filter_send
            async def block_during_process(user_id):
                if is_processing(user_id):
                    return True  # Блокируем отправку
                return False  # Разрешаем отправку

            # Или совместимый с should_block_ai_response
            @bot_builder.filter_send
            async def should_block_ai_response(user_id):
                # Ваша логика проверки
                return user_is_blocked(user_id)  # True = блокировать
        """
        return _filter_send(self, handler)

    def get_message_hooks(self) -> Dict[str, List]:
        """Получает все хуки для обработки сообщений"""
        return _get_message_hooks(self)

    def get_router_manager(self) -> RouterManager:
        """Получает менеджер роутеров событий"""
        if not self.router_manager:
            from ..event.router_manager import RouterManager

            self.router_manager = RouterManager()
        return self.router_manager

    async def _setup_bot_commands(self, bot):
        """Устанавливает меню команд для бота (разные для админов и пользователей)"""
        await _setup_bot_commands(self, bot)

    async def test(self, scenario_file: Optional[str] = None, max_concurrent: int = 5, verbose: bool = False):
        """
        Запускает тестирование бота с использованием настроенных компонентов

        Args:
            scenario_file: Конкретный файл сценариев (без расширения или с .yaml)
            max_concurrent: Максимальное количество параллельных тестов
            verbose: Подробный вывод

        Returns:
            int: Код возврата (0 - успех, 1 - ошибки)
        """
        return await _run_tests(self, scenario_file, max_concurrent, verbose)

    def _setup_context(self, bot=None, dp=None):
        """
        Устанавливает все компоненты в глобальный контекст ctx

        Args:
            bot: Экземпляр Bot (опционально, если None - не устанавливается)
            dp: Экземпляр Dispatcher (опционально, если None - не устанавливается)
        """
        if bot is not None and dp is not None:
            _setup_context(self, bot=bot, dp=dp)
            return
        # Preserve old behavior: allow partial set of bot/dp.
        if bot is not None:
            ctx.bot = bot
        if dp is not None:
            ctx.dp = dp

    async def _cleanup_resources(self, bot=None, dp=None):
        """Централизованная очистка всех ресурсов бота"""
        await _cleanup_resources(self, bot=bot, dp=dp)

    @measure_time(min_ms=50, custom_name="bot_start")
    async def start(self):
        """
        Запускает бота (аналог main.py)

        Автоматически вызывает build() если бот еще не инициализирован.
        Можно вызвать build() явно для проверки без запуска.
        """
        await _start(self)
