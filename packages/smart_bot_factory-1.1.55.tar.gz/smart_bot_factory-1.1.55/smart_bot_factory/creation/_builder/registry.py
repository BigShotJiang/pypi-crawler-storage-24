"""
Internal helpers for BotBuilder registration APIs (routers, tools, rag, utm).
"""

import logging
from datetime import datetime
from typing import Any, List, Optional

logger = logging.getLogger(__name__)


def register_router(builder: Any, router: Any) -> None:
    """
    Registers an EventRouter in RouterManager.

    This is an internal implementation for BotBuilder.register_router().
    """
    if hasattr(router, "set_bot_id"):
        router.set_bot_id(builder.bot_id)

    if not builder.router_manager:
        from ...event.router_manager import RouterManager

        builder.router_manager = RouterManager()
        logger.info("✅ Router Manager создан для регистрации роутера '%s'", getattr(router, "name", "?"))

    builder.router_manager.register_router(router)
    logger.info("✅ Роутер событий '%s' зарегистрирован в боте %s", getattr(router, "name", "?"), builder.bot_id)


def register_routers(builder: Any, routers: tuple[Any, ...]) -> None:
    """
    Internal implementation for BotBuilder.register_routers().

    NOTE: aiogram.Router detection is intentionally kept in BotBuilder itself
    (tests patch builtins used there). This helper handles all non-telegram routers.
    """
    if not routers:
        logger.warning("⚠️ register_routers вызван без аргументов")
        return

    from ...event.router import EventRouter
    from ...rag.router import RagRouter
    from ...utils.tool_router import ToolRouter

    event_count = 0
    rag_count = 0
    tool_count = 0
    unknown_count = 0

    for router in routers:
        if isinstance(router, EventRouter):
            register_router(builder, router)
            event_count += 1
        elif isinstance(router, RagRouter):
            register_rag(builder, router)
            rag_count += 1
        elif isinstance(router, ToolRouter):
            register_tool_set(builder, router)
            tool_count += 1
        else:
            unknown_count += 1

    total_registered = event_count + rag_count + tool_count
    if total_registered > 0:
        parts: List[str] = []
        if event_count > 0:
            parts.append(f"{event_count} событий")
        if rag_count > 0:
            parts.append(f"{rag_count} RAG")
        if tool_count > 0:
            parts.append(f"{tool_count} инструментов")
        logger.info("✅ Зарегистрировано роутеров: %s", ", ".join(parts))

    if unknown_count > 0:
        logger.warning(
            "⚠️ register_routers: %s роутеров неизвестного типа пропущено (Telegram роутеры обрабатываются в BotBuilder)",
            unknown_count,
        )


def register_tool(builder: Any, tool: Any) -> None:
    """Internal implementation for BotBuilder.register_tool()."""
    if tool not in builder._tools:
        builder._tools.append(tool)
        if builder.openai_client:
            builder.openai_client.add_tool(tool)
        tool_name = getattr(tool, "name", str(tool))
        logger.info("✅ Инструмент '%s' зарегистрирован в боте %s", tool_name, builder.bot_id)

        if builder.prompt_loader and builder.openai_client:
            tools_description = builder.openai_client.get_tools_description_for_prompt()
            if tools_description:
                builder.prompt_loader.set_tools_description(tools_description)
        return

    tool_name = getattr(tool, "name", str(tool))
    logger.warning("⚠️ Инструмент '%s' уже зарегистрирован", tool_name)


def register_tools(builder: Any, tools: tuple[Any, ...]) -> None:
    """Internal implementation for BotBuilder.register_tools()."""
    if not tools:
        logger.warning("⚠️ register_tools вызван без аргументов")
        return

    unpacked_tools: List[Any] = []
    for tool in tools:
        if isinstance(tool, (list, tuple)):
            unpacked_tools.extend(tool)
        else:
            unpacked_tools.append(tool)

    for tool in unpacked_tools:
        register_tool(builder, tool)

    if builder.openai_client and builder.prompt_loader:
        tools_description = builder.openai_client.get_tools_description_for_prompt()
        if tools_description:
            builder.prompt_loader.set_tools_description(tools_description)

    logger.info("✅ Зарегистрировано %s инструментов для ChatOpenAI", len(unpacked_tools))


def register_tool_set(builder: Any, tool_router: Any) -> Any:
    """Internal implementation for BotBuilder.register_tool_set()."""
    if hasattr(tool_router, "set_bot_id"):
        tool_router.set_bot_id(builder.bot_id)

    if tool_router in builder._tool_routers:
        logger.warning("⚠️ ToolRouter %s уже зарегистрирован", getattr(tool_router, "name", tool_router))
        return tool_router

    tools = getattr(tool_router, "get_tools", lambda: [])()
    if not tools:
        logger.warning("⚠️ ToolRouter %s не содержит инструментов для регистрации", getattr(tool_router, "name", tool_router))
    else:
        register_tools(builder, (tools,))

    builder._tool_routers.append(tool_router)
    logger.info("✅ Зарегистрирован ToolRouter: %s", getattr(tool_router, "name", tool_router))
    return tool_router


def register_rag(builder: Any, rag_router: Any) -> Any:
    """Internal implementation for BotBuilder.register_rag()."""
    if hasattr(rag_router, "set_bot_id"):
        rag_router.set_bot_id(builder.bot_id)

    if rag_router in builder._rag_routers:
        logger.warning("⚠️ RAG-роутер %s уже зарегистрирован", getattr(rag_router, "name", rag_router))
        return rag_router

    tools = getattr(rag_router, "get_tools", lambda: [])()
    if not tools:
        logger.warning("⚠️ RAG-роутер %s не содержит инструментов для регистрации", getattr(rag_router, "name", rag_router))
    else:
        register_tools(builder, (tools,))

    builder._rag_routers.append(rag_router)
    logger.info("✅ Зарегистрирован RAG-роутер: %s", getattr(rag_router, "name", rag_router))
    return rag_router


def register_rag_routers(builder: Any, rag_routers: tuple[Any, ...]) -> None:
    """Internal implementation for BotBuilder.register_rag_routers()."""
    if not rag_routers:
        logger.warning("⚠️ register_rag_routers вызван без аргументов")
        return
    for router in rag_routers:
        register_rag(builder, router)


def register_tool_sets(builder: Any, tool_routers: tuple[Any, ...]) -> None:
    """Internal implementation for BotBuilder.register_tool_sets()."""
    if not tool_routers:
        logger.warning("⚠️ register_tool_sets вызван без аргументов")
        return
    for router in tool_routers:
        register_tool_set(builder, router)


def on_start(builder: Any, handler: Any) -> Any:
    """Internal implementation for BotBuilder.on_start()."""
    if not callable(handler):
        raise TypeError(f"Обработчик должен быть callable, получен {type(handler)}")

    builder._start_handlers.append(handler)
    logger.info("✅ Зарегистрирован обработчик on_start: %s", getattr(handler, "__name__", "?"))
    return handler


def get_start_handlers(builder: Any) -> List[Any]:
    """Internal implementation for BotBuilder.get_start_handlers()."""
    return builder._start_handlers.copy()


def register_start_task(builder: Any, coro_fn: Any) -> None:
    """Internal implementation for BotBuilder.register_start_task()."""
    if not callable(coro_fn):
        raise TypeError("coro_fn должна быть callable")
    builder._start_tasks.append(coro_fn)
    logger.info("✅ Зарегистрирована стартовая задача: %s", getattr(coro_fn, "__name__", "?"))


def register_utm_trigger(
    builder: Any,
    message: str,
    source: Optional[str],
    medium: Optional[str],
    campaign: Optional[str],
    content: Optional[str],
    term: Optional[str],
    segment: Optional[str],
) -> None:
    """Internal implementation for BotBuilder.register_utm_trigger()."""
    utm_targets: dict[str, str] = {}
    if source is not None:
        utm_targets["source"] = source
    if medium is not None:
        utm_targets["medium"] = medium
    if campaign is not None:
        utm_targets["campaign"] = campaign
    if content is not None:
        utm_targets["content"] = content
    if term is not None:
        utm_targets["term"] = term
    if segment is not None:
        utm_targets["segment"] = segment

    trigger = {
        "utm_targets": utm_targets,
        "message": message,
        "registered_at": datetime.now().isoformat(),
    }
    builder._utm_triggers.append(trigger)
    logger.info("✅ Зарегистрирован UTM-триггер: %s -> '%s...'", utm_targets, message[:50])


def get_utm_triggers(builder: Any) -> List[Any]:
    """Internal implementation for BotBuilder.get_utm_triggers()."""
    return builder._utm_triggers.copy()

