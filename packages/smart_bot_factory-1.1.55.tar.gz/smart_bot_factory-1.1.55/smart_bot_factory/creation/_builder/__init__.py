"""
Internal BotBuilder implementation helpers.

This package is intentionally private (underscored) and not part of public API.
"""

