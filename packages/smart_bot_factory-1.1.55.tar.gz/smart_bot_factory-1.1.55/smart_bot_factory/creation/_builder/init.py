"""
Internal helpers for BotBuilder initialization.
"""

import asyncio
import logging
import os
from typing import Any, Type

logger = logging.getLogger(__name__)


async def init_config(builder: Any, config_cls: Type[Any]) -> None:
    """Implementation of BotBuilder._init_config()."""
    logger.info("⚙️ Инициализация конфигурации для %s", builder.bot_id)

    os.environ["BOT_ID"] = builder.bot_id

    env_file = builder.config_dir / ".env"
    if env_file.exists():
        from dotenv import load_dotenv

        load_dotenv(env_file)
        logger.info("📄 Загружен .env файл: %s", env_file)

    prompts_subdir = os.environ.get("PROMPT_FILES_DIR", "prompts")
    logger.info("🔍 PROMPT_FILES_DIR из .env: %s", prompts_subdir)

    prompts_dir = builder.config_dir / prompts_subdir
    logger.info("🔍 Путь к промптам: %s", prompts_dir)
    logger.info("🔍 Существует ли папка: %s", prompts_dir.exists())

    os.environ["PROMPT_FILES_DIR"] = str(prompts_dir)
    logger.info("📁 Установлен путь к промптам: %s", prompts_dir)

    logger.info("🔍 PROMPT_FILES_DIR перед созданием Config: %s", os.environ.get("PROMPT_FILES_DIR"))
    builder.config = config_cls()
    logger.info("✅ Конфигурация инициализирована")


async def init_clients(builder: Any, openai_client_cls: Type[Any], supabase_client_cls: Type[Any]) -> None:
    """Implementation of BotBuilder._init_clients()."""
    logger.info("🔌 Инициализация клиентов для %s", builder.bot_id)

    if not builder.config:
        raise RuntimeError("Config не инициализирован. Вызовите _init_config() перед _init_clients()")

    builder.openai_client = openai_client_cls(
        api_key=builder.config.OPENAI_API_KEY,
        model=builder.config.OPENAI_MODEL,
        max_tokens=builder.config.OPENAI_MAX_TOKENS,
        temperature=builder.config.OPENAI_TEMPERATURE,
    )
    logger.info("✅ OpenAI клиент инициализирован")

    builder.supabase_client = supabase_client_cls(
        url=builder.config.SUPABASE_URL,
        key=builder.config.SUPABASE_KEY,
        bot_id=builder.bot_id,
    )
    await builder.supabase_client.initialize()
    logger.info("✅ Supabase клиент инициализирован")


async def init_managers(
    builder: Any,
    admin_manager_cls: Type[Any],
    analytics_manager_cls: Type[Any],
    conversation_manager_cls: Type[Any],
    router_manager_cls: Type[Any],
    prompt_loader_cls: Type[Any],
    prompt_watcher_cls: Type[Any],
    memory_manager_cls: Type[Any],
) -> None:
    """Implementation of BotBuilder._init_managers()."""
    logger.info("👥 Инициализация менеджеров для %s", builder.bot_id)

    builder.admin_manager = admin_manager_cls(builder.config, builder.supabase_client)
    await builder.admin_manager.sync_admins_from_config()
    logger.info("✅ Admin Manager инициализирован")

    builder.analytics_manager = analytics_manager_cls(builder.supabase_client)
    logger.info("✅ Analytics Manager инициализирован")

    parse_mode = os.environ.get("MESSAGE_PARSE_MODE", "Markdown")
    admin_session_timeout_minutes = int(os.environ.get("ADMIN_SESSION_TIMEOUT_MINUTES", "30"))

    builder.conversation_manager = conversation_manager_cls(
        builder.supabase_client,
        builder.admin_manager,
        parse_mode,
        admin_session_timeout_minutes,
    )
    logger.info("✅ Conversation Manager инициализирован")

    if not builder.router_manager:
        builder.router_manager = router_manager_cls()
        logger.info("✅ Router Manager инициализирован")
    else:
        logger.info("✅ Router Manager уже был создан ранее")

    if not builder.config:
        raise RuntimeError("Config не инициализирован. Вызовите _init_config() перед _init_managers()")

    if builder._custom_prompt_loader:
        builder.prompt_loader = builder._custom_prompt_loader
        logger.info("✅ Используется кастомный Prompt Loader: %s", type(builder.prompt_loader).__name__)
    else:
        builder.prompt_loader = prompt_loader_cls(prompts_dir=builder.config.PROMPT_FILES_DIR)
        logger.info("✅ Используется стандартный Prompt Loader")

    await builder.prompt_loader.validate_prompts()
    logger.info("✅ Prompt Loader инициализирован")

    if builder.config.ENABLE_PROMPT_HOT_RELOAD:
        try:
            loop = asyncio.get_running_loop()
            builder.prompt_watcher = prompt_watcher_cls(
                prompts_dir=builder.prompt_loader.prompts_dir,
                prompt_loader=builder.prompt_loader,
                loop=loop,
            )
            builder.prompt_watcher.start()
            if builder.prompt_watcher.is_running():
                logger.info("✅ Hot Reload для промптов активирован")
            else:
                logger.warning("⚠️ Hot Reload для промптов не активирован (проверьте папку промптов)")
        except Exception as e:
            logger.error("❌ Ошибка активации Hot Reload: %s", e)
            logger.warning("⚠️ Бот продолжит работу без Hot Reload")
    else:
        logger.info("ℹ️ Hot Reload для промптов отключен в конфигурации")

    builder.memory_manager = memory_manager_cls(supabase_client=builder.supabase_client, config=builder.config)
    logger.info("✅ Memory Manager инициализирован")

