"""
Internal helpers for BotBuilder tools/prompt wiring.
"""

import logging
from typing import Any

from ...event.decorators.registry import get_handlers_for_prompt

logger = logging.getLogger(__name__)


async def register_tools_in_client(builder: Any) -> None:
    """Implementation of BotBuilder._register_tools_in_client()."""
    if builder._tools and builder.openai_client:
        logger.info("🔧 Регистрация %s инструментов в ChatOpenAI", len(builder._tools))
        builder.openai_client.add_tools(builder._tools)
        logger.info("✅ Инструменты зарегистрированы в ChatOpenAI")


async def update_tools_description_in_prompt_loader(builder: Any) -> None:
    """Implementation of BotBuilder._update_tools_description_in_prompt_loader()."""
    if builder.openai_client and builder.prompt_loader:
        tools_description = builder.openai_client.get_tools_description_for_prompt()
        if tools_description:
            builder.prompt_loader.set_tools_description(tools_description)
            logger.info("✅ Описание инструментов обновлено в PromptLoader")
        else:
            logger.debug("Нет инструментов для добавления в промпт")


async def update_prompts_with_tools(builder: Any) -> None:
    """Implementation of BotBuilder._update_prompts_with_tools()."""
    logger.info("🔧 Обновление промптов с информацией об обработчиках")

    if builder.router_manager:
        event_handlers_info = builder.router_manager.get_handlers_for_prompt()
    else:
        event_handlers_info = get_handlers_for_prompt()

    if event_handlers_info:
        builder._tools_prompt = event_handlers_info
        logger.info("✅ Промпты обновлены с информацией об обработчиках")
    else:
        builder._tools_prompt = ""
        logger.info("ℹ️ Нет зарегистрированных обработчиков")

