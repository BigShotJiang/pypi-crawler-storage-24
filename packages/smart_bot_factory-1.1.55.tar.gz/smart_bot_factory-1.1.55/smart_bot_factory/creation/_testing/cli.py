import argparse
import asyncio
import logging
import sys

from .project_root import get_project_root
from .reporting import ReportGenerator
from .runner import TestRunner
from .scenario_loader import ScenarioLoader


async def main() -> int:
    """Главная функция CLI"""
    parser = argparse.ArgumentParser(description="Система тестирования ботов")
    parser.add_argument(
        "bot_id",
        nargs="?",
        default="growthmed-october-24",
        help="ID бота для тестирования",
    )
    parser.add_argument(
        "scenario_file",
        nargs="?",
        default=None,
        help="Название файла сценариев (без расширения или с .yaml)",
    )
    parser.add_argument(
        "--scenario-file",
        dest="scenario_file_legacy",
        help="Конкретный файл сценариев (устаревший параметр)",
    )
    parser.add_argument(
        "--max-concurrent",
        type=int,
        default=5,
        help="Максимальное количество параллельных тестов",
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Подробный вывод")

    args = parser.parse_args()

    log_level = logging.INFO if args.verbose else logging.INFO
    logging.basicConfig(level=log_level, format="%(message)s")

    try:
        scenario_file = args.scenario_file or args.scenario_file_legacy
        project_root = get_project_root()

        if scenario_file:
            if not scenario_file.endswith(".yaml"):
                scenario_file += ".yaml"

            bots_dir = project_root / "bots" / args.bot_id
            if not bots_dir.exists():
                print(f"Папка bots/{args.bot_id} не найдена в проекте: {bots_dir}")
                return 1

            scenario_path = project_root / "bots" / args.bot_id / "tests" / scenario_file
            scenarios = ScenarioLoader.load_scenarios_from_file(str(scenario_path))

            if not scenarios:
                print(f"Файл сценариев '{scenario_file}' не найден или пуст")
                return 1
        else:
            scenarios = ScenarioLoader.load_all_scenarios_for_bot(args.bot_id, project_root)

            if not scenarios:
                print(f"Сценарии для бота '{args.bot_id}' не найдены")
                return 1

        print(f"🚀 Запуск тестирования бота: {args.bot_id}")
        if scenario_file:
            print(f"📋 Тестируется файл: {scenario_file}")
        else:
            print("📋 Тестируются все файлы сценариев")
        print(f"📋 Найдено сценариев: {len(scenarios)}")

        test_runner = TestRunner(args.bot_id, args.max_concurrent, project_root)
        results = await test_runner.run_tests(scenarios)

        ReportGenerator.generate_console_report(args.bot_id, results)
        report_file = ReportGenerator.save_report(args.bot_id, results, project_root)

        print(f"\n📄 Подробный отчет сохранен: {report_file}")

        failed_count = sum(1 for r in results if not r.passed)
        return 0 if failed_count == 0 else 1

    except Exception as e:
        logging.error(f"Критическая ошибка: {e}")
        return 1


def run_cli() -> None:
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n⏹️ Тестирование прервано пользователем")
        sys.exit(130)

