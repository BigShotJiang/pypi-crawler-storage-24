import asyncio
import logging
import os
import sys
import time
import uuid
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv

from ...handlers.helpers.converters import MessageConverter
from ...integrations.openai.langchain_openai import LangChainOpenAIClient
from ...integrations.openai.prompt_loader import PromptLoader
from ...integrations.supabase_client import SupabaseClient

from .models import StepResult, TestResult, TestScenario, TestStep
from .project_root import get_project_root

logger = logging.getLogger(__name__)


class BotTesterIntegrated:
    """Интегрированный тестер, использующий компоненты из BotBuilder"""

    def __init__(self, bot_id: str, openai_client, prompt_loader, supabase_client, config_dir: Path, message_hooks: dict):
        """
        Инициализация с готовыми компонентами из BotBuilder

        Args:
            bot_id: ID бота
            openai_client: Настроенный OpenAI клиент
            prompt_loader: Настроенный PromptLoader
            supabase_client: Настроенный Supabase клиент
            config_dir: Путь к конфигурации бота
            message_hooks: Хуки для обработки сообщений
        """
        self.bot_id = bot_id
        self.openai_client = openai_client
        self.prompt_loader = prompt_loader
        self.supabase_client = supabase_client
        self.config_dir = config_dir
        self.message_hooks = message_hooks

        logger.info(f"🧪 Интегрированный тестер инициализирован для бота: {bot_id}")
        logger.info(f"📋 Загружено хуков: {sum(len(hooks) for hooks in message_hooks.values())}")

    async def test_scenario(self, scenario: TestScenario) -> TestResult:
        """Тестирует сценарий с последовательными шагами (идентично BotTester)"""
        try:
            # Инициализируем Supabase клиент перед тестом
            if self.supabase_client and not self.supabase_client.client:
                await self.supabase_client.initialize()
                logging.info(f"🔌 Supabase клиент инициализирован для бота {self.bot_id}")

            step_results = []

            # Генерируем уникальный тестовый telegram_id (только цифры)
            # Формат: 999 + timestamp + случайные цифры -> гарантированно уникальный
            timestamp_part = str(int(time.time()))[-6:]  # Последние 6 цифр timestamp
            random_part = str(uuid.uuid4().int)[:3]  # Первые 3 цифры из UUID
            unique_test_telegram_id = int(f"999{timestamp_part}{random_part}")

            user_data = {
                "telegram_id": unique_test_telegram_id,
                "username": "test_user",
                "first_name": "Test",
                "last_name": "User",
                "language_code": "ru",
            }

            logging.info("")
            logging.info("🧪 ═══════════════════════════════════════════════════════════")
            logging.info(f"🎯 НАЧИНАЕМ ТЕСТ СЦЕНАРИЯ: {scenario.name}")
            logging.info(f"🤖 Бот: {self.bot_id}")
            logging.info(f"👤 Тестовый пользователь: {unique_test_telegram_id}")
            logging.info(f"📝 Количество шагов: {len(scenario.steps)}")
            logging.info("═══════════════════════════════════════════════════════════")

            session_id, system_prompt = await self.create_test_session(user_data)
            logging.info(f"🆔 Создана тестовая сессия: {session_id}")

            for i, step in enumerate(scenario.steps):
                step_num = i + 1
                logging.info("")
                logging.info(f"🔄 ─────────────── ШАГ {step_num}/{len(scenario.steps)} ───────────────")
                logging.info(f"💬 Ввод пользователя: '{step.user_input}'")

                if step.expected_keywords:
                    # Форматируем ожидаемые ключевые слова для логов
                    expected_display = []
                    for group in step.expected_keywords:
                        if len(group) == 1:
                            expected_display.append(group[0])
                        else:
                            expected_display.append(f"[{'/'.join(group)}]")
                    logging.info(f"🎯 Ожидаемые слова: {expected_display}")
                if step.forbidden_keywords:
                    logging.info(f"🚫 Запрещенные слова: {step.forbidden_keywords}")

                # Анализируем ответ на этом шаге
                start_time = time.time()
                clean_response = await self.process_user_message_test(step.user_input, session_id, system_prompt, unique_test_telegram_id)
                step_duration = int((time.time() - start_time) * 1000)

                # Показываем ответ бота (обрезанный)
                response_preview = clean_response[:150] + "..." if len(clean_response) > 150 else clean_response
                response_preview = response_preview.replace("\n", " ")
                logging.info(f"🤖 Ответ бота: '{response_preview}'")
                logging.info(f"⏱️ Время обработки: {step_duration}мс")

                # Проверяем ожидаемые ключевые слова (с поддержкой синонимов)
                missing_keyword_groups = []
                found_expected = []
                for keyword_group in step.expected_keywords:
                    # keyword_group - это либо список синонимов, либо список с одним словом
                    found_in_group = False
                    found_synonym = None

                    for synonym in keyword_group:
                        if synonym in clean_response.lower():
                            found_in_group = True
                            found_synonym = synonym
                            break

                    if not found_in_group:
                        missing_keyword_groups.append(keyword_group)
                    else:
                        found_expected.append(found_synonym)

                # Проверяем запрещенные слова
                found_forbidden = []
                for forbidden in step.forbidden_keywords:
                    if forbidden.lower() in clean_response.lower():
                        found_forbidden.append(forbidden)

                # Определяем результат шага
                passed = len(missing_keyword_groups) == 0 and len(found_forbidden) == 0

                # Преобразуем missing_keyword_groups в плоский список для StepResult
                missing_keywords_flat = []
                for group in missing_keyword_groups:
                    missing_keywords_flat.extend(group)

                step_result = StepResult(
                    step=step,
                    bot_response=clean_response,
                    passed=passed,
                    missing_keywords=missing_keywords_flat,
                    found_forbidden=found_forbidden,
                )
                step_results.append(step_result)

                # Выводим результат шага
                status = "✅" if passed else "❌"
                logging.info("")
                logging.info(f"📋 РЕЗУЛЬТАТ ШАГА {step_num}: {status}")
                if missing_keyword_groups:
                    missing_display = []
                    for group in missing_keyword_groups:
                        if len(group) == 1:
                            missing_display.append(group[0])
                        else:
                            missing_display.append(f"[{'/'.join(group)}]")
                    logging.info(f"   ❌ НЕ НАЙДЕНЫ ОЖИДАЕМЫЕ: {missing_display}")
                if found_forbidden:
                    logging.info(f"   ❌ НАЙДЕНЫ ЗАПРЕЩЕННЫЕ: {found_forbidden}")

            # Создаем итоговый результат
            result = TestResult(scenario=scenario, step_results=step_results)

            # Выводим итоговый результат сценария
            logging.info("")
            logging.info("🏁 ═══════════════════════════════════════════════════════════")
            logging.info(f"🎯 ЗАВЕРШЕН ТЕСТ СЦЕНАРИЯ: {scenario.name}")
            logging.info(f"📊 Результат: {result.passed_steps}/{result.total_steps} шагов пройдено")
            logging.info("✅ УСПЕХ" if result.passed else "❌ ПРОВАЛ")
            logging.info("═══════════════════════════════════════════════════════════")

            # Очищаем тестовую сессию
            try:
                await self.cleanup_test_session(session_id)
                logging.info(f"🧹 Тестовая сессия очищена: {session_id}")
            except Exception as cleanup_error:
                logging.warning(f"Не удалось очистить тестовую сессию {session_id}: {cleanup_error}")

            return result

        except Exception as e:
            logging.error(f"Ошибка тестирования сценария {scenario.name}: {e}")
            # Создаем результат с ошибкой для всех шагов
            step_results = []
            for step in scenario.steps:
                missing_keywords_flat = []
                for group in step.expected_keywords:
                    if isinstance(group, list):
                        missing_keywords_flat.extend(group)
                    else:
                        missing_keywords_flat.append(str(group))

                step_result = StepResult(
                    step=step,
                    bot_response=f"ОШИБКА: {str(e)}",
                    passed=False,
                    missing_keywords=missing_keywords_flat,
                    found_forbidden=[],
                )
                step_results.append(step_result)

            return TestResult(scenario=scenario, step_results=step_results)

    async def create_test_session(self, user_data: dict) -> tuple[str, str]:
        """Создает тестовую сессию и возвращает (session_id, system_prompt)"""
        try:
            system_prompt = ""
            if self.prompt_loader:
                system_prompt = await self.prompt_loader.load_system_prompt()

            session_id = await self.supabase_client.create_test_session(self.bot_id, user_data)
            return session_id, system_prompt
        except Exception as e:
            raise RuntimeError(f"Не удалось создать тестовую сессию: {e}")

    async def cleanup_test_session(self, session_id: str) -> None:
        """Очищает тестовую сессию"""
        if self.supabase_client:
            await self.supabase_client.cleanup_test_session(session_id)

    async def process_user_message_test(self, user_input: str, session_id: str, system_prompt: str, user_id: int) -> str:
        """Обрабатывает сообщение пользователя через pipeline бота (с hooks из BotBuilder)"""
        try:
            from ...handlers.processing.message_processing import (
                _build_context,
                _enrich_prompt,
                _process_ai_response,
                _process_metadata,
            )
            from ...handlers.types.constants import MessageRole

            # Сохраняем сообщение пользователя
            await self.supabase_client.add_message(
                session_id=session_id,
                role=MessageRole.USER,
                content=user_input,
                message_type="text",
            )

            # Enrich prompt/hooks
            system_prompt_with_time, time_info = await _enrich_prompt(system_prompt, user_id, self.message_hooks or {})

            # Build context
            messages = await _build_context(
                system_prompt_with_time,
                session_id,
                self.prompt_loader,
                None,
                self.message_hooks or {},
                time_info,
            )

            # AI response
            response_text, ai_metadata, processing_time, original_ai_response = await _process_ai_response(
                messages, self.openai_client, self.message_hooks or {}, user_id
            )

            # Metadata / events
            should_send_response, _ = await _process_metadata(
                ai_metadata, session_id, user_id, self.supabase_client, response_text
            )

            if not should_send_response:
                return ""

            final_response = original_ai_response if os.getenv("DEBUG_MODE") else response_text
            clean_response = MessageConverter.clean_ai_response(final_response)

            # Сохраняем ответ ассистента
            await self.supabase_client.add_message(
                session_id=session_id,
                role=MessageRole.ASSISTANT,
                content=clean_response,
                message_type="text",
                tokens_used=0,
                processing_time_ms=processing_time,
                ai_metadata=ai_metadata,
            )

            return clean_response

        except Exception as e:
            logging.error(f"💥 Ошибка в process_user_message_test: {e}")
            logging.exception("📋 Полный стек ошибки:")
            return "Произошла ошибка при обработке сообщения."


class BotTester:
    """Основной класс для тестирования ботов"""

    def __init__(self, bot_id: str, project_root: Optional[Path] = None):
        self.bot_id = bot_id
        self.project_root = project_root or get_project_root()
        self.openai_client = None
        self.prompt_loader = None
        self.supabase_client = None
        self.config_dir = None
        self.message_hooks = {}  # Хуки для обработки сообщений
        self._initialize_bot()

    def _initialize_bot(self):
        """Инициализация компонентов бота, используя готовую логику из запускалки"""
        try:
            logging.info("")
            logging.info("══════════════════════════════════════════════════════════")
            logging.info(f"ИНИЦИАЛИЗАЦИЯ ТЕСТЕРА БОТА: {self.bot_id}")
            logging.info("══════════════════════════════════════════════════════════")

            # Используем корневую директорию проекта
            user_root_dir = self.project_root
            logging.info(f"Корневая директория проекта: {user_root_dir}")

            # Добавляем корневую директорию в sys.path для импорта библиотеки
            sys.path.insert(0, str(user_root_dir))
            logging.info(f"Добавлен путь в sys.path: {user_root_dir}")

            # Путь к конфигурации бота в корневой директории проекта
            self.config_dir = user_root_dir / "bots" / self.bot_id
            logging.info(f"Каталог конфигурации: {self.config_dir}")

            if not self.config_dir.exists():
                raise ValueError(f"Папка конфигурации не найдена: {self.config_dir}")
            logging.info("Каталог конфигурации найден")

            # Устанавливаем BOT_ID как в оригинальном файле
            os.environ["BOT_ID"] = self.bot_id
            logging.info(f"BOT_ID установлен: {self.bot_id}")

            # Загружаем .env из папки бота
            env_file = self.config_dir / ".env"
            logging.info(f"Загрузка .env файла: {env_file}")
            if env_file.exists():
                load_dotenv(env_file)
                logging.info("⚙️ Чтение конфигурации из .env...")

            # OpenAI настройки
            openai_api_key = os.getenv("OPENAI_API_KEY")
            openai_model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
            openai_max_tokens = int(os.getenv("OPENAI_MAX_TOKENS", "4000"))
            openai_temperature = float(os.getenv("OPENAI_TEMPERATURE", "0.7"))

            # Supabase настройки
            supabase_url = os.getenv("SUPABASE_URL")
            supabase_key = os.getenv("SUPABASE_KEY")

            # Проверяем обязательные переменные
            if not openai_api_key:
                raise ValueError("OPENAI_API_KEY не найден в .env файле")
            if not supabase_url:
                raise ValueError("SUPABASE_URL не найден в .env файле")
            if not supabase_key:
                raise ValueError("SUPABASE_KEY не найден в .env файле")

            logging.info(f"Конфигурация загружена (модель: {openai_model})")

            logging.info("Инициализация OpenAI клиента...")
            self.openai_client = LangChainOpenAIClient(
                api_key=openai_api_key,
                model=openai_model,
                max_tokens=openai_max_tokens,
                temperature=openai_temperature,
            )
            logging.info(f"OpenAI клиент создан (модель: {openai_model})")

            logging.info("Iнициализация загрузчика промптов...")
            # PromptLoader автоматически найдет все .txt файлы в папке промптов
            self.prompt_loader = PromptLoader(prompts_dir=str(self.config_dir / "prompts"))
            logging.info("Загрузчик промптов создан")

            # Инициализируем Supabase клиент
            logging.info("Инициализация Supabase клиента...")
            self.supabase_client = SupabaseClient(url=supabase_url, key=supabase_key, bot_id=self.bot_id)
            logging.info("Supabase клиент создан")

            # Загружаем хуки для обработки сообщений (если есть)
            self._load_message_hooks()

            logging.info(f"Бот {self.bot_id} инициализирован успешно!")
            logging.info("══════════════════════════════════════════════════════════")

        except Exception as e:
            logging.error("══════════════════════════════════════════════════════════")
            logging.error(f"ОШИБКА ИНИЦИАЛИЗАЦИИ БОТА: {self.bot_id}")
            logging.error(f"Описание: {e}")
            logging.error("══════════════════════════════════════════════════════════")
            raise

    def _load_message_hooks(self):
        """Загружает хуки для обработки сообщений из файла бота (если есть)"""
        try:
            bot_file = self.project_root / f"{self.bot_id}.py"

            if not bot_file.exists():
                logging.info(f"📄 Файл бота не найден: {bot_file}, хуки не загружены")
                self.message_hooks = {}
                return

            logging.info(f"📄 Попытка загрузки хуков из файла бота: {bot_file}")

            import importlib.util

            spec = importlib.util.spec_from_file_location(f"{self.bot_id}_bot", bot_file)
            if spec is None or spec.loader is None:
                logging.warning(f"⚠️ Не удалось загрузить модуль бота: {bot_file}")
                self.message_hooks = {}
                return

            bot_module = importlib.util.module_from_spec(spec)

            setattr(bot_module, "PROJECT_ROOT", self.project_root)
            setattr(bot_module, "BOT_ID", self.bot_id)

            spec.loader.exec_module(bot_module)

            bot_builder = None
            if hasattr(bot_module, "bot_builder"):
                bot_builder = bot_module.bot_builder
            elif hasattr(bot_module, "builder"):
                bot_builder = bot_module.builder
            else:
                for attr_name in dir(bot_module):
                    attr = getattr(bot_module, attr_name)
                    if hasattr(attr, "get_message_hooks"):
                        bot_builder = attr
                        break

            if bot_builder and hasattr(bot_builder, "get_message_hooks"):
                self.message_hooks = bot_builder.get_message_hooks()
                hooks_count = sum(len(hooks) for hooks in self.message_hooks.values())
                logging.info(f"✅ Загружено хуков: {hooks_count}")
                for hook_type, hooks in self.message_hooks.items():
                    if hooks:
                        logging.info(f"   - {hook_type}: {len(hooks)}")
            else:
                logging.info("ℹ️ BotBuilder не найден в файле бота, хуки не загружены")
                self.message_hooks = {}

        except Exception as e:
            logging.warning(f"⚠️ Ошибка при загрузке хуков: {e}")
            logging.debug("Подробности:", exc_info=True)
            self.message_hooks = {}

    # NOTE: Remaining BotTester methods are unchanged from legacy implementation.
    # They are intentionally kept here to preserve existing CLI behavior.

    async def test_scenario(self, scenario: TestScenario) -> TestResult:
        """Тестирует сценарий с последовательными шагами"""
        # Delegate to integrated tester to preserve behavior as much as possible.
        integrated = BotTesterIntegrated(
            bot_id=self.bot_id,
            openai_client=self.openai_client,
            prompt_loader=self.prompt_loader,
            supabase_client=self.supabase_client,
            config_dir=self.config_dir,
            message_hooks=self.message_hooks,
        )
        return await integrated.test_scenario(scenario)

