from __future__ import annotations

import asyncio
from typing import Any, Dict, List

import pytest
from unittest.mock import AsyncMock, MagicMock, Mock

from smart_bot_factory.integrations import BatchMetrics, SupabaseClient


@pytest.mark.asyncio
async def test_get_sessions_batch_basic():
    client = SupabaseClient(url="http://test", key="test", bot_id="bot1")
    client.client = MagicMock()

    table_mock = MagicMock()
    client.client.table.return_value = table_mock
    table_mock.select.return_value = table_mock
    table_mock.in_.return_value = table_mock
    table_mock.eq.return_value = table_mock

    table_mock.execute.return_value = Mock(
        data=[
            {"id": "s1", "value": 1, "bot_id": "bot1"},
            {"id": "s2", "value": 2, "bot_id": "bot1"},
        ]
    )

    result = await client.get_sessions_batch(["s1", "s2"])

    assert result == {
        "s1": {"id": "s1", "value": 1, "bot_id": "bot1"},
        "s2": {"id": "s2", "value": 2, "bot_id": "bot1"},
    }


@pytest.mark.asyncio
async def test_get_sessions_batch_empty_list():
    client = SupabaseClient(url="http://test", key="test", bot_id="bot1")
    client.client = MagicMock()

    result = await client.get_sessions_batch([])
    assert result == {}
    client.client.table.assert_not_called()


@pytest.mark.asyncio
async def test_get_session_with_history_success():
    client = SupabaseClient(url="http://test", key="test", bot_id="bot1")
    client.client = MagicMock()
    client.get_session_info = AsyncMock(return_value={"id": "s1"})
    client.get_chat_history = AsyncMock(return_value=[{"id": 1}, {"id": 2}])

    result = await client.get_session_with_history("s1", history_limit=10)

    assert result["session"] == {"id": "s1"}
    assert result["history"] == [{"id": 1}, {"id": 2}]
    client.get_session_info.assert_awaited_once_with("s1")
    client.get_chat_history.assert_awaited_once_with("s1", limit=10)


@pytest.mark.asyncio
async def test_get_session_with_history_error_in_one_branch():
    client = SupabaseClient(url="http://test", key="test", bot_id="bot1")
    client.client = MagicMock()
    client.get_session_info = AsyncMock(side_effect=RuntimeError("boom"))
    client.get_chat_history = AsyncMock(return_value=[{"id": 1}])

    result = await client.get_session_with_history("s1", history_limit=5)

    assert result["session"] is None
    assert result["history"] == [{"id": 1}]


@pytest.mark.asyncio
async def test_update_messages_batch_success():
    client = SupabaseClient(url="http://test", key="test", bot_id="bot1")
    client.client = MagicMock()

    table_mock = MagicMock()
    client.client.table.return_value = table_mock
    table_mock.update.return_value = table_mock
    table_mock.eq.return_value = table_mock

    async def fake_to_thread(func, *args, **kwargs):
        func(*args, **kwargs)

    # Патчим asyncio.to_thread локально
    original_to_thread = asyncio.to_thread
    asyncio.to_thread = fake_to_thread  # type: ignore[assignment]

    try:
        ok = await client.update_messages_batch(
            [
                {"id": 1, "data": {"field": "value1"}},
                {"id": 2, "data": {"field": "value2"}},
            ]
        )
    finally:
        asyncio.to_thread = original_to_thread  # type: ignore[assignment]

    assert ok is True
    assert table_mock.update.call_count == 2


@pytest.mark.asyncio
async def test_update_messages_batch_partial_failure():
    client = SupabaseClient(url="http://test", key="test", bot_id="bot1")
    client.client = MagicMock()

    table_mock = MagicMock()
    client.client.table.return_value = table_mock
    table_mock.update.return_value = table_mock
    table_mock.eq.return_value = table_mock

    # Первая execute успешна, вторая выбрасывает исключение
    def execute_side_effect():
        if table_mock.execute.call_count == 0:
            return Mock(data=[{"id": 1}])
        raise RuntimeError("fail")

    table_mock.execute.side_effect = execute_side_effect

    async def fake_to_thread(func, *args, **kwargs):
        func(*args, **kwargs)

    original_to_thread = asyncio.to_thread
    asyncio.to_thread = fake_to_thread  # type: ignore[assignment]

    try:
        ok = await client.update_messages_batch(
            [
                {"id": 1, "data": {"field": "value1"}},
                {"id": 2, "data": {"field": "value2"}},
            ]
        )
    finally:
        asyncio.to_thread = original_to_thread  # type: ignore[assignment]

    assert ok is False


def test_batch_metrics_basic():
    metrics = BatchMetrics()

    metrics.record_single()
    metrics.record_single()
    metrics.record_batch(items_count=5, estimated_time_saved_ms=120)

    stats = metrics.get_stats()

    assert stats["batch_calls"] == 1
    assert stats["single_calls"] == 2
    assert stats["total_time_saved_ms"] == 120
    assert 0 < stats["batch_usage_percent"] <= 100

