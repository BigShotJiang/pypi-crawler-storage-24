# CLI Command Reference

```{toctree}
:maxdepth: 1
:hidden:

add_elem_info
all
define_layer
dft
energy_diagram
extract
fix_altloc
freq
irc
mm_parm
oniom_export
oniom_import
opt
path_opt
path_search
pysis
scan
scan2d
scan3d
trj2fig
tsopt
```

| Command | Page |
|---|---|
| `mlmm add-elem-info` | [add-elem-info](add_elem_info.md) |
| `mlmm all` | [all](all.md) |
| `mlmm define-layer` | [define-layer](define_layer.md) |
| `mlmm dft` | [dft](dft.md) |
| `mlmm energy-diagram` | [energy-diagram](energy_diagram.md) |
| `mlmm extract` | [extract](extract.md) |
| `mlmm fix-altloc` | [fix-altloc](fix_altloc.md) |
| `mlmm freq` | [freq](freq.md) |
| `mlmm irc` | [irc](irc.md) |
| `mlmm mm-parm` | [mm-parm](mm_parm.md) |
| `mlmm oniom-export` | [oniom-export](oniom_export.md) |
| `mlmm oniom-import` | [oniom-import](oniom_import.md) |
| `mlmm opt` | [opt](opt.md) |
| `mlmm path-opt` | [path-opt](path_opt.md) |
| `mlmm path-search` | [path-search](path_search.md) |
| `mlmm pysis` | [pysis](pysis.md) |
| `mlmm scan` | [scan](scan.md) |
| `mlmm scan2d` | [scan2d](scan2d.md) |
| `mlmm scan3d` | [scan3d](scan3d.md) |
| `mlmm trj2fig` | [trj2fig](trj2fig.md) |
| `mlmm tsopt` | [tsopt](tsopt.md) |
