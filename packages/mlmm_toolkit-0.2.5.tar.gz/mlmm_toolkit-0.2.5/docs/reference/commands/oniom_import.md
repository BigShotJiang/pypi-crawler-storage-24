# `mlmm oniom-import`

```text

Usage: mlmm oniom-import [OPTIONS]

  Import ONIOM input (Gaussian g16 or ORCA) and reconstruct XYZ + B-factor
  layered PDB.

Options:
  --help-advanced        Show all options (including advanced settings) and
                         exit.
  -i, --input FILE       Input ONIOM file (.gjf/.com for g16, .inp for ORCA).
                         [required]
  --mode [g16|orca]      Input mode. If omitted, inferred from input suffix.
  -o, --out-prefix PATH  Output prefix. Defaults to input stem in the current
                         working directory.
  --ref-pdb FILE         Reference PDB to preserve atom naming/residue metadata
                         (atom count must match).
  -h, --help             Show this message and exit.
```
