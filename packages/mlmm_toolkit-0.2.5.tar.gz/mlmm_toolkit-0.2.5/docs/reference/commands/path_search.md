# `mlmm path-search`

```text

Usage: mlmm path-search [OPTIONS]

  Multistep MEP search via recursive GSM segmentation.

Options:
  --help-advanced                 Show all options (including advanced settings)
                                  and exit.
  -i, --input FILE                Two or more structures in reaction order.
                                  Either repeat '-i' (e.g., '-i A -i B -i C') or
                                  use a single '-i' followed by multiple space-
                                  separated paths (e.g., '-i A B C').
                                  [required]
  --parm FILE                     Amber parm7 topology covering the full enzyme
                                  complex.  [required]
  --model-pdb FILE                PDB describing atoms that belong to the ML
                                  (high-level) region. Optional when --detect-
                                  layer is enabled.
  --model-indices TEXT            Comma-separated atom indices for the ML region
                                  (ranges allowed like 1-5). Used when --model-
                                  pdb is omitted.
  --model-indices-one-based / --model-indices-zero-based
                                  Interpret --model-indices as 1-based (default)
                                  or 0-based.  [default: model-indices-one-
                                  based]
  --detect-layer / --no-detect-layer
                                  Detect ML/MM layers from input PDB B-factors
                                  (ML=0, MovableMM=10, FrozenMM=20). If
                                  disabled, you must provide --model-pdb or
                                  --model-indices.  [default: detect-layer]
  -q, --charge INTEGER            Total system charge. Required unless --ligand-
                                  charge is provided.
  -l, --ligand-charge TEXT        Total charge or per-resname mapping (e.g.,
                                  GPP:-3,SAM:1) used to derive charge when -q is
                                  omitted (requires PDB input or --ref-pdb).
  -m, --multiplicity INTEGER      Spin multiplicity (2S+1). Defaults to 1 when
                                  omitted.
  --mep-mode [gsm|dmf]            MEP method: gsm (GrowingString) or dmf (Direct
                                  Max Flux).  [default: gsm]
  --refine-mode [peak|minima]     Refinement seed around the highest-energy
                                  image: 'peak' uses HEI±1, 'minima' uses
                                  nearest local minima. Defaults to peak for gsm
                                  and minima for dmf.
  --freeze-atoms TEXT             Comma-separated 1-based atom indices to freeze
                                  (e.g., '1,3,5').
  --hess-cutoff FLOAT             Distance cutoff (Å) from ML region for MM
                                  atoms to include in Hessian calculation.
                                  Applied to movable MM atoms and can be
                                  combined with --detect-layer.
  --movable-cutoff FLOAT          Distance cutoff (Å) from ML region for movable
                                  MM atoms. MM atoms beyond this are frozen.
                                  Providing --movable-cutoff disables --detect-
                                  layer.
  --max-nodes INTEGER             Number of internal nodes (string has
                                  max_nodes+2 images including endpoints). Used
                                  for *segment* GSM unless overridden by YAML
                                  search.max_nodes_segment.  [default: 10]
  --max-cycles INTEGER            Maximum GSM optimization cycles.  [default:
                                  300]
  --climb / --no-climb            Enable transition-state search after path
                                  growth.  [default: climb]
  --dump / --no-dump              Dump GSM/single-optimization trajectories
                                  during the run.  [default: no-dump]
  --opt-mode [grad|hess]          Single-structure optimizer: grad (=LBFGS) or
                                  hess (=RFO).  [default: grad]
  -o, --out-dir TEXT              Output directory.  [default:
                                  ./result_path_search/]
  --thresh [gau_loose|gau|gau_tight|gau_vtight|baker|never]
                                  Convergence preset for GSM/StringOptimizer and
                                  single LBFGS runs.
  --config FILE                   Base YAML configuration file applied before
                                  explicit CLI options.
  --show-config / --no-show-config
                                  Print resolved configuration and continue
                                  execution.  [default: no-show-config]
  --dry-run / --no-dry-run        Validate options and print the execution plan
                                  without running path search.  [default: no-
                                  dry-run]
  --preopt / --no-preopt          If True, run initial single-structure
                                  optimizations of inputs.  [default: no-preopt]
  --align / --no-align            After pre-optimization, align all inputs to
                                  the *first* input and match freeze_atoms using
                                  the align_freeze_atoms API.  [default: align]
  --ref-pdb FILE                  Full-size template PDBs in the same reaction
                                  order as --input. Required when using XYZ
                                  inputs to provide topology and B-factor
                                  information.
  --convert-files / --no-convert-files
                                  Convert XYZ/TRJ outputs into PDB companions
                                  based on the input format.  [default: convert-
                                  files]
  -b, --backend [uma|orb|mace|aimnet2]
                                  ML backend for the ONIOM high-level region
                                  (default: uma).
  --embedcharge / --no-embedcharge
                                  Enable xTB point-charge embedding correction
                                  for MM→ML environmental effects.  [default:
                                  no-embedcharge]
  --embedcharge-cutoff FLOAT      Distance cutoff (Å) from ML region for MM
                                  point charges in xTB embedding. Default: 12.0
                                  Å. Only used when --embedcharge is enabled.
  --link-atom-method [scaled|fixed]
                                  Link-atom position mode: scaled (g-factor,
                                  default) or fixed (legacy 1.09/1.01 Å).
  --mm-backend [hessian_ff|openmm]
                                  MM backend: hessian_ff (analytical Hessian,
                                  default) or openmm (finite-difference Hessian,
                                  slower).
  --cmap / --no-cmap              Enable CMAP (backbone cross-map) terms in
                                  model parm7. Default: disabled (Gaussian
                                  ONIOM-compatible).
  -h, --help                      Show this message and exit.
```
