class SegfaultException(Exception):
    pass
