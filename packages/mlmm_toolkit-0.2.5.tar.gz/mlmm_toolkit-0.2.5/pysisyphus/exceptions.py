class HEIIsFirstOrLastException(Exception):
    pass
