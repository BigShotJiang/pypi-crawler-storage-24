# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## v1.18.0 (2026-03-21)

### Feat

- **v3.0**: Memory and Hardening milestone (#118)

## v1.17.1 (2026-03-21)

### Fix

- **docs**: resolve rendering issues in mkdocs-shadcn theme (#117)

## v1.17.0 (2026-03-21)

## v2.1 (2026-03-20)

### Feat

- **docs**: doc search CLI/MCP + Actions artifact deploy (Phases 12-13) (#114)
- **docs**: developer guide, API reference, plugin authoring + user guide content (Phases 10-11) (#113)
- **docs**: two-track navigation + llms.txt agent accessibility (Phase 9) (#111)

## v1.16.0 (2026-03-20)

### Feat

- **docs**: migrate to MkDocs + mkdocs-shadcn, add deploy workflow (Phase 8) (#110)

## v1.15.0 (2026-03-20)

### Feat

- **v2**: complete Phase 7 wiring fixes and v2.0 milestone (#109)

## v1.14.0 (2026-03-20)

### Feat

- **agentic**: add error recovery, orchestration recipes, progressive disclosure, and plugin security (Phase 6) (#108)

## v1.13.0 (2026-03-20)

### Feat

- **plugins**: formalize plugin API with versioning, hooks, config, custom types, and rendering (Phase 5) (#107)

## v1.12.0 (2026-03-20)

### Feat

- **actions**: auto-generate MCP and CLI surfaces from ActionRegistry (Phases 3-4) (#106)

## v1.11.0 (2026-03-19)

### Feat

- **actions**: add ActionRegistry, controller layer, and core hardening (Phases 1-2) (#104)

## v1.10.0 (2026-03-03)

### Feat

- implement phase 3 obsidian starter kit (#100)

## v1.9.0 (2026-03-02)

### Feat

- implement phase 2 profile discovery (#99)

## v1.8.0 (2026-03-02)

### Feat

- implement phase 1 workspace profiles (#98)

## v1.7.2 (2026-03-02)

### Fix

- **workspace**: reconcile phase 0 client and viewer truth (#97)

## v1.7.1 (2026-03-02)

### Fix

- make homebrew formula generation release-safe (#93)

## v1.7.0 (2026-03-02)

### Feat

- add homebrew install support (#92)

## v1.6.0 (2026-03-01)

### Feat

- add agent source bundles and capture workflows (#91)

## v1.5.0 (2026-03-01)

### Feat

- add conversational enrichment viewer workflows (#90)

## v1.4.0 (2026-03-01)

### Feat

- add foundation ingest platform (#89)

## v1.3.0 (2026-03-01)

### Feat

- **mcp**: enrich MCP layer with agentic documentation (#88)

## v1.2.0 (2026-03-01)

### Feat

- **plugin**: add Claude Code plugin with MCP parity (#86)

## v1.1.3 (2026-03-01)

### Refactor

- **session**: remove JSONL dual-write from session logs (#85)

## v1.1.2 (2026-02-28)

### Fix

- pyproject formatting (#84)

## v1.1.1 (2026-02-28)

### Fix

- **build**: remove force-include causing duplicate files in wheel (#82)

## v1.1.0 (2026-02-28)

### Feat

- ZettelControl v1.1.0 — documentation upgrade and community health (#81)

## v1.0.0 (2026-02-26)

### Feat

- ztlctl v0.1.0 — initial release with full CLI, services, and MCP adapter (#49)

## v0.1.0 (2026-02-24)

### Feat

- Project skeleton
- init commit
