from setuptools import setup

# Delegate to pyproject.toml
if __name__ == "__main__":
    setup()
