"""
ICSF Command-Line Interface entrypoint.

This module exposes a small CLI wrapper around the core `cli_api` helpers.
Users install the package and then run:

    icsf run --credentials backend/credentials.yaml --csv report.csv --auto-pr --run-tests

to execute an end-to-end flow that mirrors the web application:
mapping → baseline testing → fixing → validation testing → PR creation.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
from pathlib import Path
from typing import Optional

from . import cli_api


def _configure_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="icsf",
        description="ICSF – Intelligent Code Security & Fixing Platform (CLI)",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # End-to-end command: map → baseline → fix → validate → PR.
    run_parser = subparsers.add_parser(
        "run",
        help="Run end-to-end mapping, fixing, testing, and PR creation.",
    )
    run_parser.add_argument(
        "--credentials",
        type=str,
        default=None,
        help=(
            "Path to credentials YAML containing GitHub token/username/email. "
            "If omitted, backend/credentials.yaml is used."
        ),
    )
    run_parser.add_argument(
        "--csv",
        type=str,
        required=True,
        help="Path to vulnerability CSV report.",
    )
    run_parser.add_argument(
        "--auto-pr",
        action="store_true",
        help="Automatically create a single batch PR per repository.",
    )
    run_parser.add_argument(
        "--no-auto-pr",
        dest="auto_pr",
        action="store_false",
        help="Do not create PRs (default is off unless --auto-pr is set).",
    )
    run_parser.set_defaults(auto_pr=False)

    run_parser.add_argument(
        "--run-tests",
        action="store_true",
        help="Run baseline + validation testing via Atlas.",
    )
    run_parser.add_argument(
        "--no-run-tests",
        dest="run_tests",
        action="store_false",
        help="Skip all testing (baseline & validation).",
    )
    run_parser.set_defaults(run_tests=True)

    run_parser.add_argument(
        "--repo-filter",
        type=str,
        default=None,
        help=(
            "Only process repositories whose name or full_name contains this "
            "substring (case-insensitive)."
        ),
    )
    run_parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Optional path to write a full JSON report of the run.",
    )
    run_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging for debugging.",
    )

    return parser


def _handle_run(args: argparse.Namespace) -> int:
    _configure_logging(verbose=args.verbose)
    logger = logging.getLogger("icsf.cli")

    credentials_path: Optional[Path]
    if args.credentials:
        credentials_path = Path(args.credentials).resolve()
    else:
        # Fallback to backend/credentials.yaml relative to this file.
        credentials_path = (
            Path(__file__).resolve().parent / "credentials.yaml"
        )

    csv_path = Path(args.csv).resolve()
    if not csv_path.exists():
        logger.error("CSV file not found: %s", csv_path)
        return 1

    logger.info("ICSF CLI – end-to-end run starting")
    logger.info("Credentials: %s", credentials_path)
    logger.info("CSV report: %s", csv_path)

    async def _run() -> int:
        try:
            summary = await cli_api.run_end_to_end_cli(
                credentials_path=credentials_path,
                csv_path=csv_path,
                auto_create_pr=args.auto_pr,
                run_tests=args.run_tests,
                repo_filter=args.repo_filter,
                min_severity=None,  # TODO: wire severity filtering if desired
            )
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception("End-to-end run failed: %s", exc)
            return 1

        total_repos = summary.get("total_repos_with_vulns", 0)
        processed = summary.get("total_repos_processed", 0)
        logger.info(
            "End-to-end run completed – mapped repos: %d, processed repos: %d",
            total_repos,
            processed,
        )

        # Print a very small human-readable summary to stdout.
        print("\n=== ICSF CLI Summary ===")
        print(f"Repositories with vulnerabilities: {total_repos}")
        print(f"Repositories processed:           {processed}")

        # Surface PR URLs if present.
        results = summary.get("results", []) or []
        pr_count = 0
        for repo_result in results:
            repo = repo_result.get("repo", {}) or {}
            full_name = repo.get("full_name") or repo.get("name")
            batch_results = repo_result.get("batch_results") or {}
            batch_pr = batch_results.get("batch_pr_result") or {}
            if batch_pr.get("success"):
                pr_count += 1
                pr_url = batch_pr.get("pr_url", "N/A")
                pr_number = batch_pr.get("pr_number", "N/A")
                print(f"- {full_name}: PR #{pr_number} -> {pr_url}")

        if pr_count == 0 and args.auto_pr:
            print("No PRs were created (auto-pr enabled but none succeeded).")

        # Optionally write full JSON report.
        if args.output:
            out_path = Path(args.output).resolve()
            out_path.write_text(cli_api.to_pretty_json(summary), encoding="utf-8")
            print(f"\nFull report written to: {out_path}")

        return 0

    return asyncio.run(_run())


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "run":
        return _handle_run(args)

    # Fallback – should not be reached because subparsers are required.
    parser.print_help()
    return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())

