"""
ICSF backend package.

This file makes the `backend` directory importable as a Python package so we
can expose a first-class CLI entrypoint (`icsf`) via `backend.cli:main`.
"""

