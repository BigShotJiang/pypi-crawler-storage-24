import os
import yaml
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
# This is usually done at the project level, but main.py and tests also do it.
# We do it here as well to ensure attributes are populated when imported.
load_dotenv(override=True)

class Config:
    # AWS Credentials
    AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID", "").strip() or None
    AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "").strip() or None
    AWS_REGION = os.getenv("AWS_REGION", "us-east-1").strip() or "us-east-1"
    AWS_SESSION_TOKEN = os.getenv("AWS_SESSION_TOKEN", "").strip() or None
    
    # Model IDs
    BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "").strip() or "anthropic.claude-3-5-sonnet-20240620-v1:0"
    BEDROCK_EMBED_MODEL_ID = os.getenv("BEDROCK_EMBED_MODEL_ID", "").strip() or "amazon.titan-embed-text-v1"

    @staticmethod
    def get_github_credentials(force_reload=False):
        """
        Load GitHub credentials from credentials.yaml.
        """
        import logging
        logger = logging.getLogger(__name__)
        
        # In a real scenario, force_reload might clear a cache, but here we just read the file.
        credentials_path = Path(__file__).parent / "credentials.yaml"
        
        if not credentials_path.exists():
            logger.warning(f"GitHub credentials file not found at: {credentials_path}")
            return {"token": None, "username": None, "email": None}
        
        try:
            with open(credentials_path, "r") as f:
                data = yaml.safe_load(f)
                github_data = data.get("github", {})
                token = github_data.get("token")
                logger.info(f"Successfully loaded GitHub credentials from {credentials_path}")
                if token:
                    logger.info(f"GitHub token loaded (ends with: ...{token[-4:] if len(token) > 4 else '***'})")
                else:
                    logger.warning("GitHub token is missing in credentials.yaml")
                
                return {
                    "token": token,
                    "username": github_data.get("username"),
                    "email": github_data.get("email")
                }
        except Exception as e:
            logger.error(f"Error loading GitHub credentials from {credentials_path}: {str(e)}")
            return {"token": None, "username": None, "email": None}

    @staticmethod
    def validate_bedrock_credentials():
        """
        Validate that AWS credentials are provided.
        Returns (is_valid, error_msg).
        """
        if not Config.AWS_ACCESS_KEY_ID or not Config.AWS_SECRET_ACCESS_KEY:
            return False, "Missing AWS credentials. Please check your .env file."
        return True, ""

    @staticmethod
    def get_bedrock_config():
        """
        Return Bedrock configuration as a dictionary.
        """
        return {
            "access_key": Config.AWS_ACCESS_KEY_ID,
            "secret_key": Config.AWS_SECRET_ACCESS_KEY,
            "region": Config.AWS_REGION
        }
