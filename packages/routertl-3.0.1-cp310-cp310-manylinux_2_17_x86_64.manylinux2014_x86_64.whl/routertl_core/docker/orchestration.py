# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

"""Docker orchestration engine — compiled core.

Constants, helpers, volume/mount resolution, and EDA version probing
for the Docker container development environment.  This module is
Cython-compiled on release builds (``ROUTERTL_CYTHONIZE=1``).

The CLI layer (``sdk.cli.commands.docker``) re-exports these symbols
so downstream command modules import them transparently.
"""

import subprocess
import sys
from pathlib import Path

# Lazy import to avoid hard dependency on CLI layer at import time
_cli_resilient_block = None


def _get_resilient_block():
    """Lazily import ``cli_resilient_block`` from the SDK CLI layer."""
    global _cli_resilient_block
    if _cli_resilient_block is None:
        from sdk.cli.resilience import cli_resilient_block
        _cli_resilient_block = cli_resilient_block
    return _cli_resilient_block


def _get_console():
    """Lazily import the shared Rich console from the SDK CLI layer."""
    from sdk.cli.console import console
    return console


# ──────────────────────────────────────────────────────────────
# Shared helpers
# ──────────────────────────────────────────────────────────────


def _run_make(target, *args):
    """Helper to delegate docker targets to the Master Makefile."""
    cmd = ["make", target, *args]
    try:
        # Don't capture output; let docker stdout/stderr stream natively
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            _get_console().print(f"\n❌ [red]Docker command failed (exit code: {result.returncode})[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        _get_console().print("❌ [red]Error:[/] 'make' not found.")
        sys.exit(1)


def _find_sdk_docker_dir(sdk_root=None):
    """Locate the SDK docker directory.

    Args:
        sdk_root: Explicit SDK root path.  When *None*, auto-resolves
            via ``resolve_sdk_root()``.

    Returns:
        Path to the ``sdk/infra/docker/`` (or ``docker/``) directory.
    """
    if sdk_root is None:
        try:
            from sdk.cli.sdk_root import resolve_sdk_root
            sdk_root = resolve_sdk_root()
        except ImportError:
            sdk_root = None

    if sdk_root is not None:
        # Try the new layout first (sdk/infra/docker/)
        candidate = Path(sdk_root) / "sdk" / "infra" / "docker"
        if candidate.is_dir():
            return candidate
        # Fallback to legacy layout (docker/)
        candidate = Path(sdk_root) / "docker"
        if candidate.is_dir():
            return candidate

    # Last resort: relative to this file (works in dev layout)
    return Path(__file__).resolve().parent.parent.parent / "sdk" / "infra" / "docker"


def _read_env_var(key):
    """Read a variable from the project .env file (same as docker-compose does)."""
    import os

    value = os.environ.get(key)
    if value:
        return value
    dotenv = Path(".env")
    if dotenv.exists():
        with _get_resilient_block()(".env reading"):
            for line in dotenv.read_text().splitlines():
                line = line.strip()
                if line.startswith(f"{key}="):
                    return line.split("=", 1)[1].strip().strip("'\"")
    return None


def _remove_env_var(key):
    """Remove a variable from the project .env file.

    Removes the line containing ``key=...`` from ``.env``.  If the file
    becomes empty (ignoring blank lines and comments), it is left in place
    to avoid surprising the user.
    """
    dotenv = Path(".env")
    if not dotenv.exists():
        return
    lines = dotenv.read_text().splitlines()
    filtered = [ln for ln in lines if not ln.strip().startswith(f"{key}=")]
    dotenv.write_text("\n".join(filtered) + "\n")


def _load_project_yml_for_docker():
    """Load project.yml from cwd (lightweight, no SDK imports)."""
    import yaml

    p = Path("project.yml")
    if not p.exists():
        return None
    try:
        with open(p) as f:
            return yaml.safe_load(f)
    except (yaml.YAMLError, OSError):
        return None


# ── Per-tool constants ────────────────────────────────────────

# Installer path environment variables per environment
_INSTALLER_PATH_VARS = {
    "quartus": "QUARTUS_INSTALLER_PATH",
    "vivado": "VIVADO_INSTALLER_PATH",
    "riviera": "RIVIERA_INSTALLER_PATH",
    "radiant": "RADIANT_INSTALLER_PATH",
    "libero": "LIBERO_INSTALLER_PATH",
}

# Per-tool install directory env var names
_INSTALL_DIR_VARS = {
    "quartus": "QUARTUS_INSTALL_DIR",
    "vivado": "VIVADO_INSTALL_DIR",
    "riviera": "RIVIERA_INSTALL_DIR",
    "radiant": "RADIANT_INSTALL_DIR",
    "libero": "LIBERO_INSTALL_DIR",
}

# Edition → subdirectory mapping (mirrors docker.sh)
_EDITION_SUBDIRS = {
    "pro": "quartus_pro",
    "standard": "quartus_std",
    "lite": "quartus_lite",
}

# Map of environments to their config file basenames
_CONFIG_FILES = {
    "vivado": "install_config.vivado.txt",
    "quartus": "install_config.quartus.txt",
    "riviera": None,  # Riviera uses --agree-to-license, no config file
    "radiant": None,  # Radiant uses unattended installation via script
    "libero": None,   # Libero uses headless installer arguments directly
}

# Volume naming convention explicitly mapped in docker-compose
_VOLUME_MAP = {
    "sim": None,  # Base image — no persistent volume
    "vivado": "routertl_vivado_opt",
    "quartus": "routertl_quartus_opt",  # Default; see _resolve_quartus_volume()
    "questa": "routertl_questa_opt",
    "riviera": "routertl_riviera_opt",
    "radiant": "routertl_radiant_opt",
    "libero": "routertl_libero_opt",
}

# Edition → Docker named volume
_QUARTUS_EDITION_VOLUMES = {
    "pro": "routertl_quartus_pro_opt",
    "standard": "routertl_quartus_std_opt",
    "lite": "routertl_quartus_lite_opt",
}


# ── Volume / mount resolution ────────────────────────────────


def _resolve_quartus_volume(edition: str | None = None) -> str:
    """Resolve the Quartus Docker volume name based on edition.

    Reads ``hardware.edition`` from ``project.yml`` if *edition* is None.
    Falls back to the default ``routertl_quartus_opt`` for backward compat.

    Args:
        edition: Explicit edition override (``"pro"``, ``"standard"``, ``"lite"``).

    Returns:
        Docker volume name string.
    """
    if not edition:
        cfg = _load_project_yml_for_docker()
        if cfg:
            hw = cfg.get("hardware") or {}
            if isinstance(hw, dict):
                edition = (hw.get("edition") or "").lower().strip()
    return _QUARTUS_EDITION_VOLUMES.get(edition or "", _VOLUME_MAP["quartus"])


def _resolve_volume(env: str, edition: str | None = None) -> str | None:
    """Resolve Docker volume name for a given environment.

    For Quartus, delegates to ``_resolve_quartus_volume()`` for
    edition-aware volume selection.
    """
    if env == "quartus":
        return _resolve_quartus_volume(edition)
    return _VOLUME_MAP.get(env)


def _resolve_install_mount(env: str) -> str | None:
    """Check if a bind-mount install directory is configured for *env*.

    Resolution priority (mirrors ``docker.sh``):
      1. ``QUARTUS_INSTALL_DIR`` — per-tool path from ``.env``
      2. ``EDA_INSTALL_DIR`` + edition subdir — general base path
      3. None — caller should fall back to Docker named volume

    Returns the host path string, or None.
    """
    # Tier 1: per-tool env var
    dir_var = _INSTALL_DIR_VARS.get(env)
    if dir_var:
        val = _read_env_var(dir_var)
        if val:
            p = Path(val).expanduser()
            if p.exists():
                return str(p)

    # Tier 2: EDA_INSTALL_DIR + edition subdir
    eda_base = _read_env_var("EDA_INSTALL_DIR")
    if eda_base and env == "quartus":
        cfg = _load_project_yml_for_docker()
        edition = ""
        if cfg:
            hw = cfg.get("hardware") or {}
            if isinstance(hw, dict):
                edition = (hw.get("edition") or "").lower().strip()
        subdir = _EDITION_SUBDIRS.get(edition, "quartus")
        p = Path(eda_base).expanduser() / subdir
        if p.exists():
            return str(p)

    return None


def _detect_bind_mounts() -> list[tuple[str, str]]:
    """Scan .env for *_INSTALL_DIR variables that indicate bind mount installs.

    Returns list of (env_var_name, path) tuples for existing directories.
    """
    found = []
    for _env_name, dir_var in _INSTALL_DIR_VARS.items():
        val = _read_env_var(dir_var)
        if val:
            p = Path(val).expanduser()
            if p.exists():
                found.append((dir_var, str(p)))
    # Also check EDA_INSTALL_DIR — only show if it actually contains
    # at least one recognized EDA subdirectory (quartus_pro/, quartus_std/, etc.)
    eda_base = _read_env_var("EDA_INSTALL_DIR")
    if eda_base:
        p = Path(eda_base).expanduser()
        if p.exists() and any(
            (p / sub).exists() for sub in _EDITION_SUBDIRS.values()
        ):
            found.append(("EDA_INSTALL_DIR", str(p)))
    return found


# Volume name → list of (docker image, shell command, version regex, display name)
# Multiple entries per volume allow detecting bundled tools (e.g. Questa in Quartus)
_VOLUME_PROBES = {
    "routertl_quartus_opt": [
        (
            "routertl-quartus:latest",
            "find /opt -maxdepth 5 -name quartus_sh -type f 2>/dev/null | head -1 | xargs sh -c '\"$0\" --version 2>&1' || true",
            r"Version (\d+\.\d+\.\d+)",
            "Quartus",
        ),
        (
            "routertl-quartus:latest",
            "find /opt -maxdepth 5 -name vsim -type f 2>/dev/null | head -1 | xargs sh -c '\"$0\" -version 2>&1' || true",
            r"vsim.*?(\d+\.\d+)",
            "+ Questa IFPGA",
        ),
    ],
    "routertl_vivado_opt": [
        (
            "routertl-vivado:latest",
            "find /opt -maxdepth 5 -name vivado -type f 2>/dev/null | head -1 | xargs sh -c '\"$0\" -version 2>&1' || true",
            r"Vivado v(\d+\.\d+)",
            "Vivado",
        ),
    ],
    "routertl_riviera_opt": [
        (
            "routertl-riviera:latest",
            "find /opt -maxdepth 5 -name vsimsa -type f 2>/dev/null | head -1 | xargs sh -c '\"$0\" -version 2>&1' || true",
            r"Riviera-PRO (\d+\.\d+)",
            "Riviera-PRO",
        ),
    ],
    "routertl_questa_opt": [
        (
            "routertl-questa:latest",
            "find /opt -maxdepth 5 -name vsim -type f 2>/dev/null | head -1 | xargs sh -c '\"$0\" -version 2>&1' || true",
            r"vsim.*?(\d+\.\d+)",
            "Questa",
        ),
    ],
    "routertl_radiant_opt": [
        (
            "routertl-radiant:latest",
            "find /opt/lscc -maxdepth 5 -name pnmainc -type f 2>/dev/null | head -1 | xargs sh -c '\"$0\" -v 2>&1' || true",
            r"Radiant Software.*?(\d+\.\d+)",
            "Radiant",
        ),
    ],
}
