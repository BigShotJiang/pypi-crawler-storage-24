# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

"""Workspace orchestration engine — compiled core.

Makefile fixing, configuration regeneration, venv environment
injection, and shell completion injection for project workspaces.
This module is Cython-compiled on release builds
(``ROUTERTL_CYTHONIZE=1``).

The CLI layer (``sdk.cli.commands.workspace``) re-exports these
symbols so downstream command modules import them transparently.
"""

import subprocess
import sys
from pathlib import Path


def _get_console():
    """Lazily import the shared Rich console from the SDK CLI layer."""
    from sdk.cli.console import console
    return console


# ──────────────────────────────────────────────────────────────
# Shared helpers
# ──────────────────────────────────────────────────────────────


def _run_make(target, *args):
    """Helper to delegate workspace targets to the Master Makefile."""
    cmd = ["make", target, *args]
    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            _get_console().print(f"\n❌ [red]Command failed (Make exit code: {result.returncode})[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        _get_console().print("❌ [red]Error:[/] 'make' not found. Ensure build-essential is installed.")
        sys.exit(1)


def _fix_makefile_include(sdk_path):
    """Fix stale SDK include path in the client Makefile.

    After a rebrand (rapidrtl → routertl) the Makefile may still reference
    the old submodule path.  This helper detects and fixes it.
    """
    import re

    makefile = Path("Makefile")
    if not makefile.exists():
        return

    content = makefile.read_text()
    correct_include = str(sdk_path / "sdk" / "Common.mk")

    # Match any -include or include line pointing to a Common.mk under vendor/
    pattern = re.compile(
        r"^(-?include\s+)(vendor/\S+/sdk/Common\.mk)",
        re.MULTILINE,
    )
    match = pattern.search(content)
    if not match:
        return  # No vendor include found — custom Makefile, leave it alone

    current_path = match.group(2)
    if current_path == correct_include:
        return  # Already correct

    new_content = content.replace(current_path, correct_include)
    makefile.write_text(new_content)
    _get_console().print(
        f"🔧 [green]Makefile updated:[/] "
        f"[dim]{current_path}[/] → "
        f"[cyan]{correct_include}[/]"
    )


def _run_update_config(*, exit_on_error=True):
    """Regenerate build_env.mk from project.yml.

    Shared helper used by both the ``update-config`` command and the
    ``update-sdk`` post-pull step.  When *exit_on_error* is False the
    function prints warnings instead of calling ``sys.exit`` — this
    keeps ``update-sdk`` alive even if config regeneration fails (e.g.
    when running inside the SDK repo itself which has no project.yml).
    """
    import rich_click as click

    _get_console().print("🔄 [blue]Regenerating build environment configuration...[/]")

    # Locate project.yml
    project_yml = Path("project.yml")
    if not project_yml.exists():
        msg = "❌ [red]project.yml not found in current directory.[/]"
        if exit_on_error:
            click.echo(msg)
            sys.exit(1)
        _get_console().print("  [dim](no project.yml — skipping config regeneration)[/]")
        return

    # Find SDK root (project_manager.py lives in sdk/engine/)
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_root = resolve_sdk_root()
    pm_script = None
    if sdk_root:
        candidate = sdk_root / "sdk" / "engine" / "project_manager.py"
        if candidate.exists():
            pm_script = candidate

    if pm_script is None:
        # Fallback: try via make
        _get_console().print("  [dim](SDK not found locally, falling back to make)[/]")
        _run_make("update-config")
        return

    try:
        result = subprocess.run(
            [sys.executable, str(pm_script), str(project_yml)],
            check=False,
        )
        if result.returncode == 0:
            _get_console().print("✅ [green]build_env.mk updated.[/]")
        else:
            msg = f"❌ [red]Failed to regenerate config (exit {result.returncode}).[/]"
            if exit_on_error:
                click.echo(msg)
                sys.exit(result.returncode)
            _get_console().print(f"⚠️  [yellow]Config regeneration failed (exit {result.returncode}).[/]")
    except FileNotFoundError:
        msg = "❌ [red]Python interpreter not found.[/]"
        if exit_on_error:
            click.echo(msg)
            sys.exit(1)
        _get_console().print("⚠️  [yellow]Could not regenerate config: Python not found.[/]")


# ──────────────────────────────────────────────────────────────
# Venv environment injection (P1.19)
# ──────────────────────────────────────────────────────────────

_ENV_SENTINEL_START = "# --- RouteRTL project environment ---"
_ENV_SENTINEL_END = "# --- end RouteRTL project environment ---"


def _inject_venv_environment():
    """Read ``environment:`` from project.yml and inject into .venv/bin/activate.

    Uses an idempotent sentinel block so repeated calls replace rather
    than duplicate the export lines.  If the ``environment:`` key is
    absent or empty, any existing sentinel block is removed.
    """
    import yaml

    project_yml = Path("project.yml")
    activate = Path(".venv/bin/activate")
    if not project_yml.exists() or not activate.exists():
        return

    cfg = yaml.safe_load(project_yml.read_text()) or {}
    env_vars = cfg.get("environment") or {}

    content = activate.read_text()

    # Strip any existing sentinel block
    if _ENV_SENTINEL_START in content:
        lines = content.splitlines(keepends=True)
        new_lines = []
        inside = False
        for line in lines:
            if line.rstrip() == _ENV_SENTINEL_START:
                inside = True
                continue
            if inside and line.rstrip() == _ENV_SENTINEL_END:
                inside = False
                continue
            if not inside:
                new_lines.append(line)
        content = "".join(new_lines)

    if not env_vars:
        # Clean up only — no new vars to inject
        activate.write_text(content)
        return

    # Build new sentinel block
    block_lines = [_ENV_SENTINEL_START]
    for key, value in env_vars.items():
        # Expand ~ to $HOME for portability across machines
        value = str(value).replace("~", "$HOME")
        block_lines.append(f'export {key}="{value}"')
    block_lines.append(_ENV_SENTINEL_END)
    block = "\n".join(block_lines) + "\n"

    # Append to activate script
    if not content.endswith("\n"):
        content += "\n"
    content += "\n" + block
    activate.write_text(content)

    count = len(env_vars)
    _get_console().print(
        f"🔧 [green]Injected {count} environment variable{'s' if count != 1 else ''}"
        f" into .venv/bin/activate[/]"
    )


# ──────────────────────────────────────────────────────────────
# Venv shell completion injection (P3.19)
# ──────────────────────────────────────────────────────────────

_COMP_SENTINEL_START = "# --- RouteRTL shell completion ---"
_COMP_SENTINEL_END = "# --- end RouteRTL shell completion ---"


def _detect_shell():
    """Return 'bash', 'zsh', or 'fish' based on $SHELL (default: bash)."""
    import os

    shell_path = os.environ.get("SHELL", "")
    base = os.path.basename(shell_path)
    if base == "zsh":
        return "zsh"
    if base == "fish":
        return "fish"
    return "bash"


def _inject_venv_completion():
    """Inject shell completion hook into .venv/bin/activate.

    Uses an idempotent sentinel block so repeated calls replace rather
    than duplicate the hook.  Auto-detects the user's shell from $SHELL.
    If ``rr`` is not on PATH (e.g. first install before activation),
    the ``eval`` line is still injected — it has a ``2>/dev/null`` guard.
    """
    activate = Path(".venv/bin/activate")
    if not activate.exists():
        return

    content = activate.read_text()

    # Strip any existing sentinel block
    if _COMP_SENTINEL_START in content:
        lines = content.splitlines(keepends=True)
        new_lines = []
        inside = False
        for line in lines:
            if line.rstrip() == _COMP_SENTINEL_START:
                inside = True
                continue
            if inside and line.rstrip() == _COMP_SENTINEL_END:
                inside = False
                continue
            if not inside:
                new_lines.append(line)
        content = "".join(new_lines)

    # Build new sentinel block
    shell = _detect_shell()
    if shell == "fish":
        eval_line = "rr completion fish | source 2>/dev/null"
    else:
        eval_line = f'eval "$(rr completion {shell})" 2>/dev/null'

    block_lines = [_COMP_SENTINEL_START, eval_line, _COMP_SENTINEL_END]
    block = "\n".join(block_lines) + "\n"

    if not content.endswith("\n"):
        content += "\n"
    content += "\n" + block
    activate.write_text(content)

    _get_console().print(
        f"🐚 [green]Shell completion ({shell}) hooked into .venv/bin/activate[/]"
    )
