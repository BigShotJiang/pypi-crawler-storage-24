# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Simulation result collector for the RouteRTL SDK.

Parses Cocotb's JUnit XML results, generates JSON summaries,
and maintains a persistent history of simulation runs.

No external dependencies — uses only the Python standard library
(xml.etree.ElementTree, json, shutil).
"""

import json
import shutil
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# Maximum number of history entries to keep
MAX_HISTORY_ENTRIES = 100

# History filename
HISTORY_FILENAME = "history.jsonl"


def parse_junit_xml(results_xml: Path) -> Optional[Dict[str, Any]]:
    """
    Parse a Cocotb-generated JUnit XML results file.

    Args:
        results_xml: Path to the results.xml file.

    Returns:
        Dictionary with parsed results, or None if the file doesn't exist
        or can't be parsed.
    """
    if not results_xml.exists():
        return None

    try:
        tree = ET.parse(str(results_xml))
        root = tree.getroot()
    except ET.ParseError:
        return None

    # Extract test suite properties
    seed = None
    tests = []
    passed = 0
    failed = 0
    errors = 0

    for testsuite in root.iter("testsuite"):
        # Extract seed from property elements
        for prop in testsuite.iter("property"):
            if prop.get("name") == "random_seed":
                try:
                    seed = int(prop.get("value", "0"))
                except ValueError:
                    seed = None

        # Extract individual test cases
        for testcase in testsuite.iter("testcase"):
            name = testcase.get("name", "unknown")
            classname = testcase.get("classname", "")
            time_s = float(testcase.get("time", "0"))
            sim_time_ns = float(testcase.get("sim_time_ns", "0"))
            source_file = testcase.get("file", "")
            lineno = testcase.get("lineno", "")

            # Determine status from child elements
            failure = testcase.find("failure")
            error = testcase.find("error")
            skipped = testcase.find("skipped")

            if failure is not None:
                status = "fail"
                message = failure.get("message", "")
                failed += 1
            elif error is not None:
                status = "error"
                message = error.get("message", "")
                errors += 1
            elif skipped is not None:
                status = "skip"
                message = skipped.get("message", "")
            else:
                status = "pass"
                message = ""
                passed += 1

            test_entry = {
                "name": name,
                "classname": classname,
                "status": status,
                "time_s": round(time_s, 4),
                "sim_time_ns": sim_time_ns,
            }
            if message:
                test_entry["message"] = message
            if source_file:
                test_entry["file"] = source_file
            if lineno:
                test_entry["lineno"] = lineno

            tests.append(test_entry)

    total_time = sum(t["time_s"] for t in tests)

    return {
        "seed": seed,
        "tests": tests,
        "passed": passed,
        "failed": failed,
        "errors": errors,
        "total": len(tests),
        "duration_s": round(total_time, 4),
    }


def generate_json_summary(
    parsed: Dict[str, Any],
    module: str,
    simulator: str,
    wave_dir: Optional[str] = None,
    timestamp: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate a structured JSON summary from parsed JUnit results.

    Args:
        parsed: Output from parse_junit_xml().
        module: Test module name (e.g., 'test_uart_sniffer').
        simulator: Simulator name (e.g., 'nvc').
        wave_dir: Path to the waveform directory, if any.
        timestamp: ISO timestamp. Defaults to now.

    Returns:
        A structured dictionary ready for JSON serialization.
    """
    if timestamp is None:
        timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")

    summary = {
        "timestamp": timestamp,
        "module": module,
        "simulator": simulator,
        "seed": parsed.get("seed"),
        "duration_s": parsed.get("duration_s", 0),
        "passed": parsed.get("passed", 0),
        "failed": parsed.get("failed", 0),
        "errors": parsed.get("errors", 0),
        "total": parsed.get("total", 0),
        "tests": parsed.get("tests", []),
    }

    if wave_dir:
        summary["wave_dir"] = str(wave_dir)

    return summary


def append_to_history(
    summary: Dict[str, Any],
    results_dir: Path,
    max_entries: int = MAX_HISTORY_ENTRIES,
) -> Path:
    """
    Append a run summary to the JSONL history file.

    Maintains a capped history (default 100 entries). When the cap is
    exceeded, the oldest entries are dropped.

    Args:
        summary: Output from generate_json_summary().
        results_dir: Directory for history.jsonl.
        max_entries: Maximum history entries to retain.

    Returns:
        Path to the history file.
    """
    results_dir.mkdir(parents=True, exist_ok=True)
    history_path = results_dir / HISTORY_FILENAME

    # Create a compact entry with per-test durations for regression tracking
    entry = {
        "timestamp": summary["timestamp"],
        "module": summary["module"],
        "simulator": summary["simulator"],
        "seed": summary["seed"],
        "duration_s": summary["duration_s"],
        "passed": summary["passed"],
        "failed": summary["failed"],
        "errors": summary["errors"],
        "total": summary["total"],
    }
    if "wave_dir" in summary:
        entry["wave_dir"] = summary["wave_dir"]

    # Include per-test durations for time-series regression detection
    test_durations = {}
    for test in summary.get("tests", []):
        if "name" in test and "time_s" in test:
            test_durations[test["name"]] = test["time_s"]
    if test_durations:
        entry["test_durations"] = test_durations

    # Read existing entries
    entries = []
    if history_path.exists():
        try:
            with open(history_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            entries.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
        except OSError:
            entries = []

    # Append new entry
    entries.append(entry)

    # Cap at max_entries (drop oldest)
    if len(entries) > max_entries:
        entries = entries[-max_entries:]

    # Write back atomically
    tmp_path = history_path.with_suffix(".tmp")
    try:
        with open(tmp_path, "w") as f:
            for e in entries:
                f.write(json.dumps(e, separators=(",", ":")) + "\n")
        tmp_path.replace(history_path)
    except OSError:
        if tmp_path.exists():
            tmp_path.unlink()
        raise

    return history_path


def read_history(
    results_dir: Path,
    limit: int = 20,
) -> List[Dict[str, Any]]:
    """
    Read the most recent N entries from the simulation history.

    Args:
        results_dir: Directory containing history.jsonl.
        limit: Maximum number of entries to return (most recent first).

    Returns:
        List of history entries, most recent first.
    """
    history_path = results_dir / HISTORY_FILENAME
    if not history_path.exists():
        return []

    entries = []
    try:
        with open(history_path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    except OSError:
        return []

    # Return most recent first, capped at limit
    return list(reversed(entries[-limit:]))


# ── Time-Series Regression Detection ──

# Configuration constants
REGRESSION_WINDOW = 10
"""Number of recent runs used for the rolling average."""

REGRESSION_THRESHOLD = 0.40
"""Flag runs that exceed the rolling average by more than this fraction (40%)."""


def detect_regression(
    results_dir: Path,
    module: str,
    window: int = REGRESSION_WINDOW,
    threshold: float = REGRESSION_THRESHOLD,
) -> Dict[str, Any]:
    """
    Detect time-series regressions for a module.

    Reads the history for a given module, computes a rolling average of
    the last ``window`` runs, and flags the latest run if it exceeds
    the average by more than ``threshold`` (as a fraction).

    Returns a dictionary with:
        - ``regressed``: True if a regression was detected.
        - ``module``: The module name.
        - ``latest_s``: Duration of the latest run (seconds).
        - ``avg_s``: Rolling average of the window (seconds).
        - ``pct_over``: Percentage the latest run exceeds the average.
        - ``window_size``: Actual number of entries used.
        - ``regressed_tests``: List of individual test regressions.

    If there are fewer than 3 history entries for the module, regression
    detection is skipped (``regressed`` is False, ``reason`` = "insufficient_history").
    """
    all_history = read_history(results_dir, limit=200)

    # Filter entries for this module (most-recent first)
    module_entries = [e for e in all_history if e.get("module") == module]

    result: Dict[str, Any] = {
        "regressed": False,
        "module": module,
        "latest_s": 0.0,
        "avg_s": 0.0,
        "pct_over": 0.0,
        "window_size": 0,
        "regressed_tests": [],
    }

    if len(module_entries) < 3:
        result["reason"] = "insufficient_history"
        return result

    latest = module_entries[0]
    # Use up to `window` previous entries (excluding the latest)
    previous = module_entries[1 : window + 1]

    if not previous:
        result["reason"] = "insufficient_history"
        return result

    result["window_size"] = len(previous)
    result["latest_s"] = latest.get("duration_s", 0.0)

    # Module-level regression check
    avg_duration = sum(e.get("duration_s", 0.0) for e in previous) / len(previous)
    result["avg_s"] = round(avg_duration, 4)

    if avg_duration > 0:
        pct_over = (result["latest_s"] - avg_duration) / avg_duration
        result["pct_over"] = round(pct_over * 100, 1)
        if pct_over > threshold:
            result["regressed"] = True

    # Per-test regression check (if test_durations are available)
    latest_tests = latest.get("test_durations", {})
    if latest_tests:
        for test_name, latest_dur in latest_tests.items():
            prev_durs = []
            for entry in previous:
                td = entry.get("test_durations", {})
                if test_name in td:
                    prev_durs.append(td[test_name])

            if len(prev_durs) < 3:
                continue

            test_avg = sum(prev_durs) / len(prev_durs)
            if test_avg > 0:
                test_pct = (latest_dur - test_avg) / test_avg
                if test_pct > threshold:
                    result["regressed_tests"].append(
                        {
                            "name": test_name,
                            "latest_s": latest_dur,
                            "avg_s": round(test_avg, 4),
                            "pct_over": round(test_pct * 100, 1),
                        }
                    )

    # If any individual test regressed, mark overall as regressed
    if result["regressed_tests"]:
        result["regressed"] = True

    return result


def collect_results(
    module: str,
    simulator: str,
    build_dir: str,
    wave_dir: Optional[str] = None,
    verbose: bool = False,
) -> Optional[Dict[str, Any]]:
    """
    Post-simulation hook: parse results.xml, generate JSON, update history.

    This is the main entry point called by run_simulation() after the
    simulator process completes.

    Args:
        module: Test module name.
        simulator: Simulator name.
        build_dir: Path to the simulator's build directory (contains results.xml).
        wave_dir: Path to waveform output directory, if any.
        verbose: Enable verbose logging.

    Returns:
        The JSON summary, or None if results.xml wasn't found.
    """
    from .paths import RESULTS_DIR, ensure_dir

    results_xml = Path(build_dir) / "results.xml"
    parsed = parse_junit_xml(results_xml)

    if parsed is None:
        if verbose:
            print(f"[Results] No results.xml found in {build_dir}")
        return None

    # Generate JSON summary
    summary = generate_json_summary(
        parsed,
        module=module,
        simulator=simulator,
        wave_dir=wave_dir,
    )

    # Save per-module JSON
    module_dir = RESULTS_DIR / module
    ensure_dir(module_dir)

    json_path = module_dir / "latest.json"
    try:
        with open(json_path, "w") as f:
            json.dump(summary, f, indent=2)
        if verbose:
            print(f"[Results] JSON summary saved to {json_path}")
    except OSError as e:
        if verbose:
            print(f"[Results] Warning: could not write JSON: {e}")

    # Copy JUnit XML to results directory
    xml_dest = module_dir / "results.xml"
    try:
        shutil.copy2(str(results_xml), str(xml_dest))
        if verbose:
            print(f"[Results] JUnit XML copied to {xml_dest}")
    except OSError as e:
        if verbose:
            print(f"[Results] Warning: could not copy XML: {e}")

    # Append to history
    try:
        history_path = append_to_history(summary, RESULTS_DIR)
        if verbose:
            print(f"[Results] History updated: {history_path}")
    except OSError as e:
        if verbose:
            print(f"[Results] Warning: could not update history: {e}")

    # Time-series regression detection
    try:
        regression = detect_regression(RESULTS_DIR, module)
        if regression["regressed"]:
            print(
                f"\n⚠️  Performance regression detected for {module}:\n"
                f"    Latest: {regression['latest_s']:.2f}s  |  "
                f"Avg ({regression['window_size']} runs): {regression['avg_s']:.2f}s  |  "
                f"+{regression['pct_over']:.1f}%"
            )
            for t in regression.get("regressed_tests", []):
                print(f"    └─ {t['name']}: {t['latest_s']:.4f}s (avg {t['avg_s']:.4f}s, +{t['pct_over']:.1f}%)")
            print()
        summary["regression"] = regression
    except Exception:
        # Regression detection is advisory — never break the build
        pass

    return summary
