# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Simulator backend registry and factory.

Provides pluggable support for different VHDL simulators (GHDL, NVC, etc.)
through a common interface.
"""

from .activehdl_backend import ActiveHDLBackend
from .backend_base import SimulatorBackend
from .ghdl_backend import GHDLBackend
from .nvc_backend import NVCBackend
from .questa_backend import QuestaBackend
from .riviera_backend import RivieraBackend
from .verilator_backend import VerilatorBackend
from .xcelium_backend import XceliumBackend

__all__ = [
    "SimulatorBackend",
    "GHDLBackend",
    "NVCBackend",
    "RivieraBackend",
    "QuestaBackend",
    "XceliumBackend",
    "ActiveHDLBackend",
    "VerilatorBackend",
    "get_backend",
]

_BACKENDS = {
    "ghdl": GHDLBackend,
    "nvc": NVCBackend,
    "riviera": RivieraBackend,
    "questa": QuestaBackend,
    "xcelium": XceliumBackend,
    "activehdl": ActiveHDLBackend,
    "verilator": VerilatorBackend,
}


def get_backend(name: str, verbose: bool = False) -> SimulatorBackend:
    """
    Get a simulator backend instance.

    Args:
        name: Simulator name ('ghdl' or 'nvc')
        verbose: Enable verbose logging

    Returns:
        Backend instance implementing SimulatorBackend interface

    Raises:
        ValueError: If simulator not supported
    """
    name = name.lower()
    if name not in _BACKENDS:
        supported = ", ".join(_BACKENDS.keys())
        raise ValueError(f"Unknown simulator: {name}. Supported: {supported}")

    backend_class = _BACKENDS[name]
    return backend_class(verbose=verbose)
