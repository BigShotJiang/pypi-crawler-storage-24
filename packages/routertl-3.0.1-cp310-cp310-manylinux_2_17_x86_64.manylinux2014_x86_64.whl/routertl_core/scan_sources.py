#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

import argparse
import glob
import logging
import os
import re

import yaml

# Vendor → constraint/ip file extensions
VENDOR_CONSTRAINT_EXT = {}
VENDOR_IP_EXT = {}

vendor_db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "supported_vendors.yml")
if os.path.exists(vendor_db_path):
    with open(vendor_db_path, "r") as f:
        vdb = yaml.safe_load(f)
        if vdb:
            for vendor, data in vdb.items():
                exts = data.get("extensions", {})
                constraints_raw = exts.get("constraints", "*.xdc")
                # ensure it's a list since YAML might provide a string
                VENDOR_CONSTRAINT_EXT[vendor] = (
                    [constraints_raw] if isinstance(constraints_raw, str) else constraints_raw
                )

                ip_raw = exts.get("ip", "*.xci")
                VENDOR_IP_EXT[vendor] = [ip_raw] if isinstance(ip_raw, str) else ip_raw
else:
    # Fallback if DB is missing
    VENDOR_CONSTRAINT_EXT = {"xilinx": ["*.xdc"]}
    VENDOR_IP_EXT = {"xilinx": ["*.xci"]}

# Open-source constraint format accepted for all vendors
COMMON_CONSTRAINT_EXT = ["*.pcf"]


def detect_vhdl_libraries(files, project_root):
    """
    Parses VHDL files for 'library <name>;' declarations.
    Filters out standard libraries and returns a dict mapping lib_name -> [files].
    """
    lib_map = {}
    standard_libs = {"ieee", "std", "work", "xpm", "utils", "unisim", "unimacro"}

    # Regex to find library declarations: library <name>;
    LIB_RE = re.compile(r"(?i)\blibrary\s+(\w+)\s*;", re.MULTILINE)
    # Regex to find package declarations: package <name> is
    PKG_RE = re.compile(r"(?i)\bpackage\s+(\w+)\s+is", re.MULTILINE)
    # Regex to find package bodies: package body <name> is
    PKG_BODY_RE = re.compile(r"(?i)\bpackage\s+body\s+(\w+)\s+is", re.MULTILINE)

    # 1. First pass: find which libraries are used
    used_libs = set()
    for f in files:
        if not f.endswith((".vhd", ".vhdl")):
            continue
        try:
            with open(os.path.join(project_root, f), "r", encoding="utf-8", errors="ignore") as vhd:
                content = vhd.read()
                for match in LIB_RE.finditer(content):
                    lib_name = match.group(1).lower()
                    if lib_name not in standard_libs:
                        used_libs.add(lib_name)
        except Exception:
            logging.debug("Failed to read VHDL file %s", f, exc_info=True)
            continue

    if not used_libs:
        return {}

    # 2. Second pass: find which files define packages that belong to these libraries
    # This is a bit of a heuristic: we check if a file defines a package
    # used in a 'use <lib>.<pkg>.all' statement.

    # To keep it generic and simple for scan_sources:
    # We look for all 'package <name> is' in the source files.
    # If a library <lib> is used, and a file defines a package <pkg>,
    # and some OTHER file has 'use <lib>.<pkg>.all', then <pkg> belongs to <lib>.

    # Optimization: Let's see if we can find 'library <lib>; use <lib>.<pkg>...' in the same file
    # or if we need to scan others. Most users put the package in the library.

    pkg_to_file = {}
    for f in files:
        if not f.endswith((".vhd", ".vhdl")):
            continue
        try:
            with open(os.path.join(project_root, f), "r", encoding="utf-8", errors="ignore") as vhd:
                content = vhd.read()
                # Find packages defined in this file
                for match in PKG_RE.finditer(content):
                    pkg_name = match.group(1).lower()
                    pkg_to_file[pkg_name] = f
                # Also check for package body to ensure it's included
                for match in PKG_BODY_RE.finditer(content):
                    pkg_name = match.group(1).lower()
                    # We might already have it from PKG_RE, but ensure it's recorded
                    pkg_to_file[pkg_name] = f
        except Exception:
            logging.debug("Failed to read VHDL file %s", f, exc_info=True)
            continue

    # 3. Third pass: Map packages to libraries based on 'use <lib>.<pkg>' statements
    for f in files:
        if not f.endswith((".vhd", ".vhdl")):
            continue
        try:
            with open(os.path.join(project_root, f), "r", encoding="utf-8", errors="ignore") as vhd:
                content = vhd.read()
                for lib in used_libs:
                    # Match use <lib>.<pkg>.all or use <lib>.<pkg>
                    USE_RE = re.compile(r"(?i)use\s+" + re.escape(lib) + r"\.(\w+)", re.MULTILINE)
                    for match in USE_RE.finditer(content):
                        pkg_used = match.group(1).lower()
                        if pkg_used in pkg_to_file:
                            pkg_file = pkg_to_file[pkg_used]
                            if lib not in lib_map:
                                lib_map[lib] = set()
                            lib_map[lib].add(pkg_file)
        except Exception:
            logging.debug("Failed to read VHDL file %s", f, exc_info=True)
            continue

    # Conver sets to sorted lists
    return {lib: sorted(list(files)) for lib, files in lib_map.items()}


def get_source_files(src_dir, prefix_filter=None, extensions=None):
    """Recursively find all supported source files."""
    if extensions is None:
        extensions = ["*.vhd", "*.v", "*.sv"]
    files = []

    if not os.path.exists(src_dir):
        return []

    for root, dirs, filenames in os.walk(src_dir):
        for ext in extensions:
            for filename in glob.fnmatch.filter(filenames, ext):
                if prefix_filter and not filename.startswith(prefix_filter):
                    continue
                files.append(os.path.join(root, filename))
    return sorted(files)


def get_rel_files(files, project_file):
    """Return relative file paths matching given extensions."""
    rel_files = []
    project_root = os.path.abspath(os.path.dirname(project_file))
    for f in files:
        try:
            rel = os.path.relpath(f, project_root)
            rel_files.append(rel)
        except ValueError:
            pass
    return rel_files


def insert_files_into_section(lines, new_files, section_name, parent_section="sources"):
    """
    Inserts files into the specific section (e.g., 'syn:', 'sim:')
    under a parent section (default 'sources:'). Returns modified lines.
    """
    if not new_files:
        return lines

    print(f"[{section_name}] Found {len(new_files)} new files to add.")

    sources_idx = -1
    section_idx = -1
    last_item_idx = -1

    # scan for section locations
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith(f"{parent_section}:"):
            sources_idx = i
        elif s.startswith(f"{section_name}:") and sources_idx != -1:
            section_idx = i
            last_item_idx = i
        elif section_idx != -1:
            # indent check
            indent = len(line) - len(line.lstrip())
            section_indent = len(lines[section_idx]) - len(lines[section_idx].lstrip())

            if indent > section_indent and s.startswith("-"):
                last_item_idx = i
            elif indent <= section_indent and s:
                # End of section
                if last_item_idx != -1:
                    break

    if section_idx == -1:
        print(f"Warning: Could not find '{parent_section}: -> {section_name}:' section. Skipping.")
        return lines

    # Determine indentation
    if last_item_idx == section_idx:
        # Section empty
        base_indent = lines[section_idx][: len(lines[section_idx]) - len(lines[section_idx].lstrip())]
        insertion_indent = base_indent + "  "
    else:
        last_line = lines[last_item_idx]
        insertion_indent = last_line[: len(last_line) - len(last_line.lstrip())]

    # Insert
    count = 0
    # Check if the section line ends with [] and replace it if we are adding items
    if section_idx != -1 and lines[section_idx].strip().endswith(": []"):
        lines[section_idx] = lines[section_idx].replace(" []", "")
        # And because last_item_idx WAS section_idx, we are good to insert after it

    for f in new_files:
        lines.insert(last_item_idx + 1, f"{insertion_indent}- {f}\n")
        last_item_idx += 1
        print(f"  Added: {f}")
        count += 1

    return lines


def remove_stale_entries(lines, project_root):
    """
    Remove entries from project.yml that reference files which no longer exist.
    This covers sources (syn, sim, xdc, ip) as well as hooks.pre_commit.exclude.lint.
    Returns the modified lines and count of removed entries.
    """
    removed_count = 0
    new_lines = []

    # Track context: are we inside a specific section?
    in_exclude_lint = False
    exclude_lint_indent = 0

    for i, line in enumerate(lines):
        stripped = line.strip()

        # Detect hooks.pre_commit.exclude.lint section
        if "lint:" in stripped and i > 0:
            # Check if we might be in hooks.pre_commit.exclude context
            # Look back a few lines to see if we're in exclude section
            for j in range(max(0, i - 5), i):
                if "exclude:" in lines[j]:
                    in_exclude_lint = True
                    exclude_lint_indent = len(line) - len(line.lstrip())
                    break
        elif in_exclude_lint and stripped and not stripped.startswith("-"):
            # We've left the lint section
            current_indent = len(line) - len(line.lstrip())
            if current_indent <= exclude_lint_indent:
                in_exclude_lint = False

        # Process list items
        if stripped.startswith("-"):
            # Extract the file path
            entry = stripped[1:].strip().strip("'").strip('"')
            # Strip inline YAML comments (e.g., "path/to/file.vhd # comment")
            if "#" in entry:
                entry = entry.split("#")[0].strip()
            # Check if it looks like a file path (has extension)
            if "." in entry and not entry.startswith("#"):
                full_path = os.path.join(project_root, entry)
                if not os.path.exists(full_path):
                    if in_exclude_lint:
                        print(f"  Removed (excluded file not found): {entry}")
                    else:
                        print(f"  Removed (file not found): {entry}")
                    removed_count += 1
                    continue  # Skip this line - don't add to new_lines
        new_lines.append(line)

    return new_lines, removed_count


def get_constraint_extensions(vendor):
    """Return constraint file extensions for the given FPGA vendor."""
    exts = VENDOR_CONSTRAINT_EXT.get(vendor, ["*.xdc"])
    return exts + COMMON_CONSTRAINT_EXT


def update_project_yml(project_file, src_dir, sim_dir, xdc_dir, ip_dir, tcl_dir=None, vendor="xilinx"):
    """Update project.yml with discovered source files."""
    if not os.path.exists(project_file):
        print(f"Error: {project_file} not found.")
        return

    project_root = os.path.dirname(os.path.abspath(project_file))

    # 1. Read existing project.yml
    with open(project_file, "r") as f:
        lines = f.readlines()

    # 2. Remove stale entries (files that no longer exist)
    lines, removed_count = remove_stale_entries(lines, project_root)

    # 3. Identify existing files in project.yml to avoid duplicates
    existing_entries = set()
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("-"):
            entry = stripped[1:].strip().strip("'").strip('"')
            existing_entries.add(entry)

    # 2. Prepare Syn files
    syn_files = []
    if src_dir:
        found_total = []
        for path in src_dir:
            full_src = os.path.abspath(path)
            found = get_source_files(full_src)
            if not found:
                print(f"INFO: No source files found recursively in {path}", flush=True)
            found_total.extend(found)
        rel = get_rel_files(found_total, project_file)
        syn_files = [f for f in rel if f not in existing_entries]

    # 3. Prepare Sim files
    sim_files = []
    sim_files = []
    if sim_dir:
        found_sim_total = []
        for path in sim_dir:
            full_sim = os.path.abspath(path)
            found_sim = get_source_files(full_sim, prefix_filter="tb_")
            if not found_sim:
                print(f"INFO: No testbench files found recursively in {path}", flush=True)
            found_sim_total.extend(found_sim)
        rel_sim = get_rel_files(found_sim_total, project_file)
        sim_files = [f for f in rel_sim if f not in existing_entries]
        # Also ensure we don't double add if it was in syn_files (unlikely given filters)
        sim_files = [f for f in sim_files if f not in syn_files]

    # 4. Prepare design constraint files (vendor-aware)
    dc_extensions = get_constraint_extensions(vendor)
    xdc_files = []
    if xdc_dir:
        found_xdc_total = []
        for path in xdc_dir:
            full_xdc = os.path.abspath(path)
            found_xdc = get_source_files(full_xdc, extensions=dc_extensions)
            if not found_xdc:
                print(f"INFO: No constraint files ({', '.join(dc_extensions)}) found in {path}", flush=True)
            found_xdc_total.extend(found_xdc)
        rel_xdc = get_rel_files(found_xdc_total, project_file)
        xdc_files = [f for f in rel_xdc if f not in existing_entries]

    # 4.5 Prepare IP files
    ip_files = []
    if ip_dir:
        found_ip_total = []
        for path in ip_dir:
            full_ip = os.path.abspath(path)
            # Scan for XCI and IPXACT
            found_ip = get_source_files(full_ip, extensions=["*.xci", "*.ipxact", "*.xml"])
            if not found_ip:
                print(f"INFO: No IP files found recursively in {path}", flush=True)
            found_ip_total.extend(found_ip)
        rel_ip = get_rel_files(found_ip_total, project_file)
        ip_files = [f for f in rel_ip if f not in existing_entries]

    # 4.6 Prepare TCL files
    tcl_files = []
    if tcl_dir:
        found_tcl_total = []
        for path in tcl_dir:
            full_tcl = os.path.abspath(path)
            found_tcl = get_source_files(full_tcl, extensions=["*.tcl"])
            if not found_tcl:
                print(f"INFO: No TCL files found recursively in {path}", flush=True)
            found_tcl_total.extend(found_tcl)
        rel_tcl = get_rel_files(found_tcl_total, project_file)
        tcl_files = [f for f in rel_tcl if f not in existing_entries]

    if not syn_files and not sim_files and not xdc_files and not tcl_files and removed_count == 0:
        print("INFO: No changes detected (no new or stale files index).", flush=True)

    # 4.7 Prepare Custom Libraries
    # Always scan all current syn files (existing + new) for library dependencies
    all_current_syn = [entry for entry in existing_entries if entry.endswith((".vhd", ".vhdl"))]
    all_current_syn.extend([f for f in syn_files if f.endswith((".vhd", ".vhdl"))])

    lib_map = detect_vhdl_libraries(all_current_syn, project_root)

    # Ensure tcl_hooks section exists if we have TCL files
    if tcl_files:
        has_tcl_hooks = False
        for line in lines:
            if line.strip().startswith("tcl_hooks:"):
                has_tcl_hooks = True
                break

        if not has_tcl_hooks:
            print("[tcl_hooks] Section missing, appending to project.yml...")
            lines.extend(["\n", "# TCL Hooks\n", "tcl_hooks:\n", "  gen_project: []\n"])

    # 5. Insert
    if syn_files:
        lines = insert_files_into_section(lines, syn_files, "syn")

    if sim_files:
        lines = insert_files_into_section(lines, sim_files, "sim")

    if xdc_files:
        lines = insert_files_into_section(lines, xdc_files, "xdc")

    if ip_files:
        lines = insert_files_into_section(lines, ip_files, "ip")

    if tcl_files:
        lines = insert_files_into_section(lines, tcl_files, "gen_project", parent_section="tcl_hooks")

    # Handle Libraries section
    if lib_map:
        # Check if libraries section exists
        has_libraries = False
        libraries_idx = -1
        sources_idx = -1
        for i, line in enumerate(lines):
            if line.strip().startswith("sources:"):
                sources_idx = i
            if line.strip().startswith("libraries:") and sources_idx != -1:
                has_libraries = True
                libraries_idx = i
                break

        if not has_libraries and sources_idx != -1:
            # Append libraries section under sources
            # Find the end of sources section
            end_sources = sources_idx + 1
            for i in range(sources_idx + 1, len(lines)):
                indent = len(lines[i]) - len(lines[i].lstrip())
                if indent == 0 and lines[i].strip():
                    end_sources = i
                    break
                end_sources = i + 1

            lines.insert(end_sources, "  libraries: {}\n")
            libraries_idx = end_sources
            has_libraries = True

        if has_libraries:
            # Strategy: Find libraries section, remove everything under it, and re-insert.
            start = libraries_idx
            end = start + 1
            lib_indent = len(lines[start]) - len(lines[start].lstrip())

            for i in range(start + 1, len(lines)):
                indent = len(lines[i]) - len(lines[i].lstrip())
                if indent <= lib_indent and lines[i].strip():
                    break
                end = i + 1

            # Remove old
            del lines[start:end]

            # Insert new
            new_lib_lines = ["  libraries:\n"]
            for lib, lib_files in sorted(lib_map.items()):
                new_lib_lines.append(f"    {lib}:\n")
                for lf in lib_files:
                    new_lib_lines.append(f"      - {lf}\n")

            lines[start:start] = new_lib_lines

    with open(project_file, "w") as f:
        f.writelines(lines)

    # Sanity check: validate YAML after writing
    try:
        with open(project_file, "r") as f:
            yaml.safe_load(f)
        print("project.yml updated. ✓ YAML syntax OK")
    except yaml.YAMLError as e:
        print("⚠️  WARNING: project.yml was updated but has YAML syntax errors!")
        print(f"   {e}")


def update_ip_manifests(project_file):
    """
    Scan RTL-mode IP manifests referenced in project.yml and
    auto-populate their synthesis.sources lists.
    """
    if not os.path.exists(project_file):
        print(f"Error: {project_file} not found.")
        return

    project_root = os.path.dirname(os.path.abspath(project_file))

    with open(project_file, "r") as f:
        config = yaml.safe_load(f) or {}

    ip_paths = config.get("sources", {}).get("ips", [])
    if not ip_paths:
        print("INFO: No IPs found in sources.ips. Nothing to update.", flush=True)
        return

    updated_count = 0
    for ip_rel in ip_paths:
        ip_abs = os.path.join(project_root, ip_rel)
        if not os.path.exists(ip_abs):
            print(f"WARNING: IP manifest not found: {ip_abs}")
            continue

        with open(ip_abs, "r") as f:
            ip_data = yaml.safe_load(f) or {}

        mode = ip_data.get("synthesis", {}).get("mode", "rtl")
        if mode != "rtl":
            print(f"  [{ip_rel}] mode={mode} — skipping (non-RTL)", flush=True)
            continue

        # Determine scan directory
        scan_dir = ip_data.get("paths", {}).get("sources")
        if not scan_dir:
            print(f"  [{ip_rel}] no paths.sources defined — skipping", flush=True)
            continue

        ip_dir = os.path.dirname(ip_abs)
        full_scan = os.path.abspath(os.path.join(ip_dir, scan_dir))
        if not os.path.exists(full_scan):
            print(f"  [{ip_rel}] scan dir {full_scan} not found — skipping", flush=True)
            continue

        # Find source files
        found = get_source_files(full_scan)
        if not found:
            print(f"  [{ip_rel}] no source files in {scan_dir}", flush=True)
            continue

        # Convert to ip.yml-relative paths
        rel_files = []
        for f_path in found:
            try:
                rel = os.path.relpath(f_path, ip_dir)
                rel_files.append(rel)
            except ValueError:
                pass

        # Read current ip.yml lines and get existing entries
        with open(ip_abs, "r") as f:
            lines = f.readlines()

        existing = set()
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("-"):
                entry = stripped[1:].strip().strip("'").strip('"')
                existing.add(entry)

        new_files = [fp for fp in rel_files if fp not in existing]

        # Remove stale entries
        lines, removed = remove_stale_entries(lines, ip_dir)

        if new_files:
            lines = insert_files_into_section(lines, new_files, "sources", parent_section="synthesis")
            updated_count += 1

        if new_files or removed > 0:
            with open(ip_abs, "w") as f:
                f.writelines(lines)

            # Validate YAML
            try:
                with open(ip_abs, "r") as f:
                    yaml.safe_load(f)
                print(f"  [{ip_rel}] updated ({len(new_files)} added, {removed} removed) ✓", flush=True)
            except yaml.YAMLError as e:
                print(f"  [{ip_rel}] ⚠️ YAML syntax error after update: {e}", flush=True)
        else:
            print(f"  [{ip_rel}] up to date", flush=True)

    if updated_count > 0:
        print(f"\n{updated_count} IP manifest(s) updated.", flush=True)
    else:
        print("All IP manifests are up to date.", flush=True)


def main():
    """CLI entry point for source scanner."""
    parser = argparse.ArgumentParser(description="Scan folders and add new files to project.yml")
    parser.add_argument("--project", default="project.yml", help="Path to project.yml")
    parser.add_argument("--src", nargs="+", help="Path to source directory (for syn)")
    parser.add_argument("--sim", nargs="+", help="Path to simulation directory (for sim)")
    parser.add_argument(
        "--dc", "--xdc", nargs="+", dest="dc", help="Path to design constraints directory (vendor-aware)"
    )
    parser.add_argument("--vendor", default="xilinx", help="FPGA vendor (determines constraint extensions)")
    parser.add_argument("--ip", nargs="+", help="Path to IP directory (for ip)")
    parser.add_argument("--tcl", nargs="+", help="Path to TCL directory (for tcl_hooks.gen_project)")
    parser.add_argument(
        "--ip-update", action="store_true", help="Scan RTL-mode IP manifests and update their synthesis.sources"
    )
    args = parser.parse_args()

    update_project_yml(args.project, args.src, args.sim, args.dc, args.ip, args.tcl, vendor=args.vendor)

    if args.ip_update:
        print("\n── IP Manifest Source Scan ──")
        update_ip_manifests(args.project)


if __name__ == "__main__":
    main()
