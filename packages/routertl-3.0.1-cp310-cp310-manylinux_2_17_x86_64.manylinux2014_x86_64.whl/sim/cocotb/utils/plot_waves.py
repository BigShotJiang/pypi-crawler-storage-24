# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import matplotlib
import pandas as pd

matplotlib.use("Agg")  # Use headless backend
import argparse
import os

import matplotlib.pyplot as plt


def estimate_frequency(csv_path="wave_log.csv", signal="SINE_OUT"):
    """Estimate signal frequency from zero-crossing analysis.

    Parameters
    ----------
    csv_path : str
        Path to CSV with ``time_ns`` and signal columns.
    signal : str
        Column name to analyze. Default ``"SINE_OUT"``.

    Returns
    -------
    float or None
        Estimated frequency in Hz, or ``None`` if too few crossings.
    """
    df = pd.read_csv(csv_path)

    time = df["time_ns"].values
    wave = df[signal].values

    zero_crossings = []
    for i in range(1, len(wave)):
        if wave[i - 1] < 0 and wave[i] >= 0:
            # Linear interpolation to estimate crossing more precisely
            t1, t2 = time[i - 1], time[i]
            y1, y2 = wave[i - 1], wave[i]
            t_zero = t1 - y1 * (t2 - t1) / (y2 - y1)
            zero_crossings.append(t_zero)

    if len(zero_crossings) < 2:
        print("Not enough zero crossings found.")
        return None

    # Take average period
    periods = [zero_crossings[i + 1] - zero_crossings[i] for i in range(len(zero_crossings) - 1)]
    avg_period_ns = sum(periods) / len(periods)
    freq_hz = 1e9 / avg_period_ns  # convert ns to Hz

    print(f"[✓] Estimated frequency from {signal}: {freq_hz:.2f} Hz (avg period: {avg_period_ns:.2f} ns)")
    return freq_hz


def plot_waveform(csv_path="wave_log.csv", output_path="waveform_plot.png"):
    """Plot DDS sine/cosine waveforms from a CSV log file.

    Parameters
    ----------
    csv_path : str
        Path to CSV with ``time_ns``, ``SINE_OUT``, ``COS_OUT`` columns.
    output_path : str
        Destination path for the PNG plot. Default ``"waveform_plot.png"``.
    """
    df = pd.read_csv(csv_path)

    freq_hz = estimate_frequency(csv_path, "SINE_OUT")

    plt.figure(figsize=(12, 6))
    plt.plot(df["time_ns"], df["SINE_OUT"], label="SINE")
    plt.plot(df["time_ns"], df["COS_OUT"], label="COSINE")
    plt.xlabel("Time (ns)")
    plt.ylabel("Amplitude")

    # Title and frequency as subtitle
    plt.title("DDS Output", fontsize=14)
    if freq_hz:
        plt.suptitle(f"Estimated SINE_OUT Frequency: {freq_hz:.2f} Hz", fontsize=10, y=0.94)

    plt.legend()
    plt.grid(True)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])  # Leave room for suptitle

    plt.savefig(output_path)
    print(f"[✓] Saved waveform plot to: {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plot waveform from CSV")
    parser.add_argument(
        "--csv", type=str, default="wave_log.csv", help="Path to input CSV file (default: wave_log.csv)"
    )
    parser.add_argument(
        "--out", type=str, default=None, help="Path to output PNG file (default: same name as CSV with .png)"
    )
    args = parser.parse_args()

    output_path = args.out or os.path.splitext(args.csv)[0] + ".png"
    plot_waveform(args.csv, output_path)
