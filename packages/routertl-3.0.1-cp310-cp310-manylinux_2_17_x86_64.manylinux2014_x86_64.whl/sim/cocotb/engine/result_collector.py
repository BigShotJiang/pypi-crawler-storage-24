# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Backward-compatibility proxy for ``routertl_core.sim.result_collector``.

The real implementation was moved to ``routertl_core/sim/`` in P4.7
so it can be Cython-compiled for distribution.  This proxy re-exports
all public symbols so that existing imports continue to work.
"""

import sys
from pathlib import Path

_REPO_ROOT = str(Path(__file__).resolve().parents[3])
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from routertl_core.sim.result_collector import (  # noqa: E402, F401
    HISTORY_FILENAME,
    MAX_HISTORY_ENTRIES,
    REGRESSION_THRESHOLD,
    REGRESSION_WINDOW,
    append_to_history,
    collect_results,
    detect_regression,
    generate_json_summary,
    parse_junit_xml,
    read_history,
)

__all__ = [
    "HISTORY_FILENAME",
    "MAX_HISTORY_ENTRIES",
    "REGRESSION_THRESHOLD",
    "REGRESSION_WINDOW",
    "append_to_history",
    "collect_results",
    "detect_regression",
    "generate_json_summary",
    "parse_junit_xml",
    "read_history",
]
