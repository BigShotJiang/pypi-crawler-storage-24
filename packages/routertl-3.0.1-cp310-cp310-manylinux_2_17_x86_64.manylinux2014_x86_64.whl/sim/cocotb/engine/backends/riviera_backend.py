# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Proxy — real implementation in routertl_core.sim.backends.riviera_backend."""
import sys
from pathlib import Path

_REPO_ROOT = str(Path(__file__).resolve().parents[4])
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import routertl_core.sim.backends.riviera_backend as _mod  # noqa: E402

globals().update({k: v for k, v in vars(_mod).items() if not k.startswith("__")})
