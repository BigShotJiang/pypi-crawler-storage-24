# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Backward-compatibility proxy for ``routertl_core.sim.default_libraries``.

The real implementation was moved to ``routertl_core/sim/`` in P4.7
so it can be Cython-compiled for distribution.  This proxy re-exports
all public symbols so that existing imports continue to work.
"""

import sys
from pathlib import Path

_REPO_ROOT = str(Path(__file__).resolve().parents[3])
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from routertl_core.sim.default_libraries import (  # noqa: E402, F401
    DEFAULT_LIBRARIES,
    SRC_PATH,
    XPM_PATH,
)

__all__ = [
    "DEFAULT_LIBRARIES",
    "SRC_PATH",
    "XPM_PATH",
]
