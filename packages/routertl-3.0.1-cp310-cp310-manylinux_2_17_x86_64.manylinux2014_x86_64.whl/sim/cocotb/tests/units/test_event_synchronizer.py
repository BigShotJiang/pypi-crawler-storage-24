# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity event_synchronizer is
#   port (
#     CLK_SRC   : in  std_logic;
#     CLK_DST   : in  std_logic;
#     EVENT_IN  : in  std_logic;
#     EVENT_OUT : out std_logic
#     );
# end entity event_synchronizer;


def main():
    """Run simulation for event_synchronizer"""
    run_simulation(
        top_level="event_synchronizer",
        module="tests.units.test_event_synchronizer",
        custom_libraries={"tich": [f"{SRC_PATH}/units/event_synchronizer.vhd"]},
        generics={},
        waves=True,
        simulator="nvc",
        extra_env={"COCOTB_CLEAN": "1"},
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify event_synchronizer propagates pulses across clock domains."""
    PERIOD_SRC = 10
    PERIOD_DST = 12.5
    cocotb.start_soon(Clock(dut.CLK_SRC, PERIOD_SRC, unit="ns").start())
    cocotb.start_soon(Clock(dut.CLK_DST, PERIOD_DST, unit="ns").start())
    dut._log.info("Starting event_synchronizer test...")

    dut.EVENT_IN.value = 0
    await ClockCycles(dut.CLK_SRC, 10)

    # Verify no spurious output
    assert int(dut.EVENT_OUT.value) == 0, "EVENT_OUT should be 0 with no input"
    dut._log.info("  No spurious output before pulse ✓")

    # Send a 1-cycle pulse on SRC domain
    dut.EVENT_IN.value = 1
    await RisingEdge(dut.CLK_SRC)
    dut.EVENT_IN.value = 0

    # Wait for synchronization to DST domain (toggle → 2 sync stages → XOR)
    # Needs ~5 DST cycles for the full pipeline
    pulse_seen = False
    for i in range(15):
        await RisingEdge(dut.CLK_DST)
        if int(dut.EVENT_OUT.value) == 1:
            pulse_seen = True
            dut._log.info(f"  EVENT_OUT pulse detected at DST cycle {i} ✓")
            break

    assert pulse_seen, "EVENT_OUT pulse not detected after sending EVENT_IN"

    # Wait for output to return to 0
    await ClockCycles(dut.CLK_DST, 5)
    assert int(dut.EVENT_OUT.value) == 0, "EVENT_OUT should return to 0 after pulse"
    dut._log.info("  EVENT_OUT returned to 0 ✓")

    dut._log.info("Test PASSED")


@cocotb.test()
async def test_back_to_back_pulses(dut):
    """Verify two rapid pulses are both propagated to DST domain."""
    PERIOD_SRC = 10
    PERIOD_DST = 12.5
    cocotb.start_soon(Clock(dut.CLK_SRC, PERIOD_SRC, unit="ns").start())
    cocotb.start_soon(Clock(dut.CLK_DST, PERIOD_DST, unit="ns").start())
    dut._log.info("Starting back-to-back pulse test...")

    dut.EVENT_IN.value = 0
    await ClockCycles(dut.CLK_SRC, 10)

    pulse_count = 0

    for pulse_num in range(2):
        # Send a 1-cycle pulse on SRC domain
        dut.EVENT_IN.value = 1
        await RisingEdge(dut.CLK_SRC)
        dut.EVENT_IN.value = 0

        # Wait for this pulse to appear in DST domain
        pulse_seen = False
        for i in range(20):
            await RisingEdge(dut.CLK_DST)
            if int(dut.EVENT_OUT.value) == 1:
                pulse_seen = True
                pulse_count += 1
                dut._log.info(f"  Pulse {pulse_num + 1} detected at DST cycle {i} ✓")
                break

        assert pulse_seen, f"EVENT_OUT pulse #{pulse_num + 1} not detected"

        # Wait for output to return to 0 before next pulse
        await ClockCycles(dut.CLK_DST, 5)

    assert pulse_count == 2, f"Expected 2 pulses, only saw {pulse_count}"
    dut._log.info("Back-to-back pulse test PASSED")


if __name__ == "__main__":
    main()
