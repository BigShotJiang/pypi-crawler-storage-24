# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity infilter_array is
#   generic(
#     G_DEB_CYCLES          : integer := 32;
#     G_ARRAY_SIZE          : integer := 32
#     );
#   port (
#     CLK       : in  std_logic;
#     CE        : in  std_logic;
#     PULSE_IN  : in  std_logic_vector(G_ARRAY_SIZE-1 downto 0);
#     PULSE_OUT : out std_logic_vector(G_ARRAY_SIZE-1 downto 0)
#     );
# end infilter_array;

# Default generics - modify as needed for your test
GENERICS = {"G_DEB_CYCLES": 32, "G_ARRAY_SIZE": 32}


def main():
    """Run simulation for infilter_array"""
    run_simulation(
        top_level="infilter_array",
        module="tests.units.test_infilter_array",
        custom_libraries={"tich": [f"{SRC_PATH}/units/infilter_array.vhd"]},
        generics=GENERICS,
        waves=True,
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify infilter_array filters glitches across all channels."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting infilter_array test (G_DEB_CYCLES=32, G_ARRAY_SIZE=32)...")

    # Initialize
    dut.CE.value = 1
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 40)

    # Verify all outputs start low
    assert int(dut.PULSE_OUT.value) == 0, "All PULSE_OUT channels should start at 0"
    dut._log.info("  Initial PULSE_OUT = 0x00000000 ✓")

    # Test 1: Apply 1-clock glitch on all channels — should be filtered
    dut.PULSE_IN.value = 0xFFFFFFFF
    await RisingEdge(dut.CLK)
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 40)
    assert int(dut.PULSE_OUT.value) == 0, "1-cycle glitch should be filtered on all channels"
    dut._log.info("  1-cycle glitch filtered on all channels ✓")

    # Test 2: Sustained input on alternating channels
    dut.PULSE_IN.value = 0xAAAAAAAA  # channels 1,3,5,...,31
    await ClockCycles(dut.CLK, 50)  # >> G_DEB_CYCLES=32
    out_val = int(dut.PULSE_OUT.value)
    assert out_val == 0xAAAAAAAA, f"Expected 0xAAAAAAAA, got 0x{out_val:08X}"
    dut._log.info(f"  Sustained alternating channels passed: 0x{out_val:08X} ✓")

    # Test 3: Release — all channels return to 0
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 50)
    assert int(dut.PULSE_OUT.value) == 0, "All channels should return to 0"
    dut._log.info("  Release → all channels 0 ✓")

    dut._log.info("Test PASSED")


@cocotb.test()
async def test_single_channel_independence(dut):
    """Verify activating one channel does not affect adjacent channels."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting single-channel independence test...")

    # Initialize
    dut.CE.value = 1
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 10)

    # Drive only channel 0 (bit 0) sustained
    dut.PULSE_IN.value = 0x00000001
    await ClockCycles(dut.CLK, 50)  # >> G_DEB_CYCLES=32

    out_val = int(dut.PULSE_OUT.value)
    assert out_val == 0x00000001, (
        f"Expected only channel 0 active (0x00000001), got 0x{out_val:08X}"
    )
    dut._log.info(f"  Channel 0 only: PULSE_OUT=0x{out_val:08X} ✓")

    # Drive only channel 31 (MSB)
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 50)  # Let channel 0 deassert
    dut.PULSE_IN.value = 0x80000000
    await ClockCycles(dut.CLK, 50)

    out_val = int(dut.PULSE_OUT.value)
    assert out_val == 0x80000000, (
        f"Expected only channel 31 active (0x80000000), got 0x{out_val:08X}"
    )
    dut._log.info(f"  Channel 31 only: PULSE_OUT=0x{out_val:08X} ✓")

    dut._log.info("Single-channel independence test PASSED")


if __name__ == "__main__":
    main()
