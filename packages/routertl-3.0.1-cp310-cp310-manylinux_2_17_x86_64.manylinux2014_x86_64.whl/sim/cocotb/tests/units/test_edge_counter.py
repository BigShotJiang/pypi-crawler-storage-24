# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge, Timer

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity edge_counter is
#   generic (
#     G_CNT_WIDTH : integer := 32;
#     G_EDGE_TYPE : integer := 0          -- 0: rising,  1: falling, 2: both
#     );
#   port (
#     CLK        : in  std_logic;
#     RST        : in  std_logic;
#     D          : in  std_logic;         -- signal to monitor
#     EDGE_COUNT : out std_logic_vector(G_CNT_WIDTH-1 downto 0)
#     );
# end entity edge_counter;

# Default generics - modify as needed for your test
GENERICS = {"G_CNT_WIDTH": 32, "G_EDGE_TYPE": 0}


def main():
    """Run simulation for edge_counter"""
    run_simulation(
        top_level="edge_counter",
        module="tests.units.test_edge_counter",
        custom_libraries={"tich": [f"{SRC_PATH}/units/edge_counter.vhd"]},
        generics=GENERICS,
        waves=True,
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Basic test for edge_counter"""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting basic test for edge_counter...")

    # Initialize reset
    dut.RST.value = 1
    dut.D.value = 0
    await ClockCycles(dut.CLK, 3)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    dut._log.info("Reset complete. Starting stimulus...")

    # Generate edges on D input
    expected_count = 0
    for i in range(10):
        # Create a pulse
        dut.D.value = 1
        await Timer(PERIOD * 3, unit="ns")  # Hold high for a bit
        dut.D.value = 0
        await Timer(PERIOD * 3, unit="ns")  # Hold low for a bit
        expected_count += 1

        # Check count (delayed check to allow propagation)
        await RisingEdge(dut.CLK)

    # Final check
    await Timer(100, unit="ns")
    current_count = int(dut.EDGE_COUNT.value)
    dut._log.info(f"Final Count: {current_count}, Expected: {expected_count}")

    assert current_count == expected_count, f"Count mismatch! Got {current_count}, expected {expected_count}"

    dut._log.info("Test completed successfully.")


@cocotb.test()
async def test_falling_edge_not_counted(dut):
    """Verify falling edges are NOT counted when G_EDGE_TYPE=0 (rising only)."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting falling-edge negative test (G_EDGE_TYPE=0)...")

    # Reset
    dut.RST.value = 1
    dut.D.value = 1  # Start high so we can create falling edges
    await ClockCycles(dut.CLK, 3)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Create 5 toggle cycles: each cycle does D=0 then D=1
    for _ in range(5):
        dut.D.value = 0
        await Timer(PERIOD * 3, unit="ns")
        dut.D.value = 1
        await Timer(PERIOD * 3, unit="ns")

    await Timer(100, unit="ns")
    count = int(dut.EDGE_COUNT.value)
    dut._log.info(f"Count after 5 toggle cycles: {count}")

    # RTL rising-edge mode counts D_r='0' → D='1' transitions.
    # RST clears D_r to '0' (edge_counter.vhd:72), so the first clock
    # after reset release sees D_r='0', D='1' → 1 extra rising edge.
    # Total = 1 (initial) + 5 (loop 0→1 transitions) = 6.
    # Falling edges (1→0) are NOT counted — only rising edges contribute.
    assert count == 6, f"Expected 6 rising edges (1 initial + 5 loop), got {count}"
    dut._log.info("Falling-edge negative test PASSED")


@cocotb.test()
async def test_reset_clears_count(dut):
    """Verify RST clears the accumulated edge count to zero."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting reset-clears-count test...")

    # Reset
    dut.RST.value = 1
    dut.D.value = 0
    await ClockCycles(dut.CLK, 3)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Generate some edges
    for _ in range(5):
        dut.D.value = 1
        await Timer(PERIOD * 3, unit="ns")
        dut.D.value = 0
        await Timer(PERIOD * 3, unit="ns")

    await Timer(50, unit="ns")
    count_before = int(dut.EDGE_COUNT.value)
    assert count_before > 0, f"Expected non-zero count before reset, got {count_before}"
    dut._log.info(f"Count before reset: {count_before}")

    # Apply reset
    dut.RST.value = 1
    await ClockCycles(dut.CLK, 2)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    count_after = int(dut.EDGE_COUNT.value)
    assert count_after == 0, f"Expected count=0 after reset, got {count_after}"
    dut._log.info(f"Count after reset: {count_after} ✓")

    dut._log.info("Reset-clears-count test PASSED")


if __name__ == "__main__":
    main()
