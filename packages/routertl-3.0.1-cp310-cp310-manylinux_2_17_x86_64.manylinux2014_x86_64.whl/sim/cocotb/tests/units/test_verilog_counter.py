# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge, Timer


@cocotb.test()
async def test_counter(dut):
    """Test the Verilog counter."""

    # Start clock
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    # Reset
    dut.rst.value = 1
    await Timer(20, unit="ns")
    dut.rst.value = 0
    await RisingEdge(dut.clk)

    # Check initial value
    assert dut.count.value == 0, f"Expected 0, got {dut.count.value}"

    # Wait for count
    for i in range(1, 10):
        await RisingEdge(dut.clk)
        assert dut.count.value == i, f"Expected {i}, got {dut.count.value}"

    dut._log.info("Verilog Counter Test Passed!")


@cocotb.test()
async def test_counter_rollover(dut):
    """Verify 8-bit counter wraps from 255 to 0."""
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    dut._log.info("Starting rollover test (WIDTH=8)...")

    # Reset
    dut.rst.value = 1
    await Timer(20, unit="ns")
    dut.rst.value = 0
    await RisingEdge(dut.clk)

    # Run counter to 254
    await ClockCycles(dut.clk, 254)
    count_val = int(dut.count.value)
    assert count_val == 254, f"Expected 254 before rollover, got {count_val}"
    dut._log.info(f"  count = {count_val} (pre-rollover) ✓")

    # Next cycle should be 255
    await RisingEdge(dut.clk)
    count_val = int(dut.count.value)
    assert count_val == 255, f"Expected 255, got {count_val}"
    dut._log.info(f"  count = {count_val} (max value) ✓")

    # Next cycle should wrap to 0
    await RisingEdge(dut.clk)
    count_val = int(dut.count.value)
    assert count_val == 0, f"Expected 0 after rollover, got {count_val}"
    dut._log.info(f"  count = {count_val} (rolled over) ✓")

    # And continue counting from 1
    await RisingEdge(dut.clk)
    count_val = int(dut.count.value)
    assert count_val == 1, f"Expected 1 after rollover, got {count_val}"
    dut._log.info(f"  count = {count_val} (post-rollover) ✓")

    dut._log.info("Rollover test PASSED")


if __name__ == "__main__":
    import os

    from sim.cocotb.engine.simulation import run_simulation

    # Locate files relative to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(script_dir, "../../../../"))
    verilog_src = os.path.join(project_root, "src/units/verilog_counter.v")

    os.environ["COCOTB_CLEAN"] = "1"
    run_simulation(
        top_level="verilog_counter",
        module="sim.cocotb.tests.units.test_verilog_counter",  # Fully qualified
        hdl_sources=[verilog_src],
        custom_libraries={},  # Avoid DEFAULT_LIBRARIES (VHDL)
        generics={"WIDTH": 8},
        waves=True,
    )
