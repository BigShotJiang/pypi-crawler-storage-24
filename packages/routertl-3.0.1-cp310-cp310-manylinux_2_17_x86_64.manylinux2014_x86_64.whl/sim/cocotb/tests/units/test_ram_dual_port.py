# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity ram_dual_port is -- dual port
#   generic(
#     G_WIDTH     : natural := 32; -- Data width
#     G_DEPTH     : natural := 6;  -- Ram depth = 2^G_DEPTH
#     G_REG_OUT   : string  := "false";
#     G_RAM_STYLE : string  := "auto" -- distributed, block, ultra
#     );
#   port(
#     CLKA  : in  std_logic;
#     CLKB  : in  std_logic;
#     WEA   : in  std_logic;
#     ADDRA : in  std_logic_vector(G_DEPTH-1 downto 0);
#     ADDRB : in  std_logic_vector(G_DEPTH-1 downto 0);
#     DIA   : in  std_logic_vector(G_WIDTH-1 downto 0);
#     DOA   : out std_logic_vector(G_WIDTH-1 downto 0);
#     DOB   : out std_logic_vector(G_WIDTH-1 downto 0)
#     );
# end ram_dual_port;

GENERICS = {"G_WIDTH": 32, "G_DEPTH": 6}


def main():
    """Run simulation for ram_dual_port."""
    os.environ["COCOTB_CLEAN"] = "1"

    # Force delete build dir
    import shutil

    build_dir = Path("sim/build/nvc/tich")
    if build_dir.exists():
        shutil.rmtree(build_dir, ignore_errors=True)

    run_simulation(
        top_level="ram_dual_port",
        module="tests.units.test_ram_dual_port",
        custom_libraries={"tich": [f"{SRC_PATH}/units/ram_dual_port.vhd"]},
        generics=GENERICS,
        waves=True,
        simulator="nvc",
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Basic test for ram_dual_port"""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLKA, PERIOD, unit="ns").start())
    cocotb.start_soon(Clock(dut.CLKB, PERIOD, unit="ns").start())

    dut._log.info("Starting basic test for ram_dual_port...")

    # Initialize
    dut.WEA.value = 0
    dut.ADDRA.value = 0
    dut.ADDRB.value = 0
    dut.DIA.value = 0

    await ClockCycles(dut.CLKA, 5)

    # Write data to address 0 on port A
    test_data = 0xDEADBEEF
    dut.ADDRA.value = 0
    dut.DIA.value = test_data
    dut.WEA.value = 1
    await RisingEdge(dut.CLKA)
    dut.WEA.value = 0

    # Read back from port B
    dut.ADDRB.value = 0
    await ClockCycles(dut.CLKB, 2)  # Wait for read latency

    read_data = int(dut.DOB.value)
    dut._log.info(f"Read from port B addr 0: {hex(read_data)}")

    assert read_data == test_data, f"Expected {hex(test_data)}, got {hex(read_data)}"

    dut._log.info("Test completed successfully.")


@cocotb.test()
async def test_multi_address_sweep(dut):
    """Write 8 different addresses on port A, read back all 8 from port B."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLKA, PERIOD, unit="ns").start())
    cocotb.start_soon(Clock(dut.CLKB, PERIOD, unit="ns").start())
    dut._log.info("Starting multi-address sweep test...")

    # Initialize
    dut.WEA.value = 0
    dut.ADDRA.value = 0
    dut.ADDRB.value = 0
    dut.DIA.value = 0
    await ClockCycles(dut.CLKA, 5)

    # Write 8 addresses with unique data
    test_map = {i: 0xA0000000 | (i << 16) | (i * 0x1111) for i in range(8)}
    for addr, data in test_map.items():
        dut.ADDRA.value = addr
        dut.DIA.value = data
        dut.WEA.value = 1
        await RisingEdge(dut.CLKA)
        dut._log.info(f"  Write: addr={addr} data=0x{data:08X}")
    dut.WEA.value = 0
    await RisingEdge(dut.CLKA)

    # Read back all 8 from port B
    for addr, expected in test_map.items():
        dut.ADDRB.value = addr
        await ClockCycles(dut.CLKB, 2)  # Read latency
        read_val = int(dut.DOB.value)
        dut._log.info(f"  Read:  addr={addr} got=0x{read_val:08X} exp=0x{expected:08X}")
        assert read_val == expected, (
            f"Port B mismatch at addr {addr}: got 0x{read_val:08X}, expected 0x{expected:08X}"
        )

    dut._log.info("Multi-address sweep test PASSED")


@cocotb.test()
async def test_port_a_readback(dut):
    """Verify DOA reflects data written via port A."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLKA, PERIOD, unit="ns").start())
    cocotb.start_soon(Clock(dut.CLKB, PERIOD, unit="ns").start())
    dut._log.info("Starting port A readback test...")

    # Initialize
    dut.WEA.value = 0
    dut.ADDRA.value = 0
    dut.ADDRB.value = 0
    dut.DIA.value = 0
    await ClockCycles(dut.CLKA, 5)

    # Write to address 5
    test_data = 0xBEEFCAFE
    dut.ADDRA.value = 5
    dut.DIA.value = test_data
    dut.WEA.value = 1
    await RisingEdge(dut.CLKA)
    dut.WEA.value = 0

    # Read back from port A (same address)
    dut.ADDRA.value = 5
    await ClockCycles(dut.CLKA, 2)  # Read latency

    read_val = int(dut.DOA.value)
    dut._log.info(f"DOA at addr 5: 0x{read_val:08X} (exp=0x{test_data:08X})")
    assert read_val == test_data, (
        f"DOA mismatch: got 0x{read_val:08X}, expected 0x{test_data:08X}"
    )

    dut._log.info("Port A readback test PASSED")


if __name__ == "__main__":
    main()
