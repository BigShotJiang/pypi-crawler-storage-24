# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.default_libraries import DEFAULT_LIBRARIES
from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity fifo_xpm_sync is
#   generic (
#     G_FIFO_DEPTH   : integer := 6;
#     G_FIFO_WIDTH   : integer := 32;
#     G_FIFO_FWFT    : integer := 1;
#     G_FULL_SLACK   : integer := 6;
#     G_EMPTY_SLACK  : integer := 6;
#     G_DEBUG_TRACES : integer := 0; -- 0 = no debug traces, 1 = debug traces
#     G_CALLER_NAME  : string := "not defined" -- Used for assert messages
#   );
#   port (
#     -- Clock and Reset
#     CLK : in std_logic;
#     RST : in std_logic;
#     -- FIFO Interface
#     DIN        : in std_logic_vector(G_FIFO_WIDTH - 1 downto 0);
#     WR_EN      : in std_logic;
#     RD_EN      : in std_logic;
#     DOUT       : out std_logic_vector(G_FIFO_WIDTH - 1 downto 0);
#     FULL       : out std_logic;
#     EMPTY      : out std_logic;
#     PROG_FULL  : out std_logic;
#     PROG_EMPTY : out std_logic;
#     DATA_CNT   : out std_logic_vector(G_FIFO_DEPTH + 1 - 1 downto 0) := (others => '0');
#     RST_BUSY   : out std_logic
#   );
# end entity fifo_xpm_sync;

# Default generics - modify as needed for your test
GENERICS = {
    "G_FIFO_DEPTH": 6,
    "G_FIFO_WIDTH": 32,
    "G_FIFO_FWFT": 1,
    "G_FULL_SLACK": 6,
    "G_EMPTY_SLACK": 6,
    "G_DEBUG_TRACES": 0,
}


def main():
    """Run simulation for fifo_xpm_sync"""
    libs = {"xpm": DEFAULT_LIBRARIES["xpm"], "tich": [f"{SRC_PATH}/units/fifo_xpm_sync.vhd"]}

    os.environ["COCOTB_CLEAN"] = "1"
    run_simulation(
        top_level="fifo_xpm_sync",
        module="tests.units.test_fifo_xpm_sync",
        custom_libraries=libs,
        generics=GENERICS,
        waves=True,
        simulator="nvc",
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify fifo_xpm_sync push/pop ordering and EMPTY flag."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting fifo_xpm_sync test...")

    # Reset
    dut.RST.value = 1
    dut.WR_EN.value = 0
    dut.RD_EN.value = 0
    dut.DIN.value = 0
    await ClockCycles(dut.CLK, 10)
    dut.RST.value = 0
    # Wait for RST_BUSY to deassert
    for _ in range(20):
        await RisingEdge(dut.CLK)
        if int(dut.RST_BUSY.value) == 0:
            break
    await ClockCycles(dut.CLK, 5)

    # Verify FIFO is empty after reset
    assert int(dut.EMPTY.value) == 1, "FIFO should be empty after reset"
    dut._log.info("  EMPTY = 1 after reset ✓")

    # Push 5 known values
    test_data = [0xAAAA0001, 0xBBBB0002, 0xCCCC0003, 0xDDDD0004, 0xEEEE0005]
    for val in test_data:
        dut.DIN.value = val
        dut.WR_EN.value = 1
        await RisingEdge(dut.CLK)
        dut._log.info(f"  Push: 0x{val:08X}")
    dut.WR_EN.value = 0
    await ClockCycles(dut.CLK, 3)

    # FIFO should not be empty
    assert int(dut.EMPTY.value) == 0, "FIFO should not be empty after writes"
    dut._log.info("  EMPTY = 0 after writes ✓")

    # Pop and verify ordering — FWFT mode: first value already on DOUT
    read_data = []

    # In FWFT mode, DOUT already holds the first value (no RD_EN needed)
    val = int(dut.DOUT.value)
    read_data.append(val)
    dut._log.info(f"  Pop:  0x{val:08X} (exp=0x{test_data[0]:08X})")

    # Pop remaining values: each RD_EN pulse advances to next value
    for i in range(1, len(test_data)):
        dut.RD_EN.value = 1
        await RisingEdge(dut.CLK)
        dut.RD_EN.value = 0
        await RisingEdge(dut.CLK)
        val = int(dut.DOUT.value)
        read_data.append(val)
        dut._log.info(f"  Pop:  0x{val:08X} (exp=0x{test_data[i]:08X})")

    await ClockCycles(dut.CLK, 5)

    # Verify FIFO ordering
    assert read_data == test_data, f"FIFO ordering broken: got {[hex(x) for x in read_data]}"

    dut._log.info("Test PASSED — 5 values pushed/popped in order")


@cocotb.test()
async def test_full_flag(dut):
    """Verify FULL flag asserts when FIFO is filled to capacity.

    In FWFT mode, the XPM FIFO pre-reads the first entry into an output
    register, effectively consuming one slot from the write depth. We fill
    the FIFO until FULL asserts, then verify FULL deasserts after a read.
    """
    PERIOD = 10
    DEPTH = 2 ** GENERICS["G_FIFO_DEPTH"]  # 64 entries (write depth)
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info(f"Starting FULL flag test (depth={DEPTH})...")

    # Reset
    dut.RST.value = 1
    dut.WR_EN.value = 0
    dut.RD_EN.value = 0
    dut.DIN.value = 0
    await ClockCycles(dut.CLK, 10)
    dut.RST.value = 0
    for _ in range(20):
        await RisingEdge(dut.CLK)
        if int(dut.RST_BUSY.value) == 0:
            break
    await ClockCycles(dut.CLK, 5)

    # Fill FIFO — write one entry at a time and poll FULL after each.
    # In FWFT mode the internal storage may differ from DEPTH, so we
    # detect the actual fill point rather than assuming a fixed count.
    fill_count = 0
    for i in range(DEPTH + 2):  # +2 headroom for FWFT pipeline depth
        dut.DIN.value = i
        dut.WR_EN.value = 1
        await RisingEdge(dut.CLK)
        dut.WR_EN.value = 0
        # Allow XPM internal pipeline to settle after each write
        await ClockCycles(dut.CLK, 3)
        fill_count += 1
        full_val = int(dut.FULL.value)
        if full_val == 1:
            break

    dut._log.info(f"  FULL asserted after {fill_count} writes ✓")
    assert int(dut.FULL.value) == 1, (
        f"FULL never asserted after {fill_count} writes (max tried: {DEPTH+2})"
    )

    # Read one entry — FULL should deassert
    dut.RD_EN.value = 1
    await RisingEdge(dut.CLK)
    dut.RD_EN.value = 0
    await ClockCycles(dut.CLK, 5)

    full_val = int(dut.FULL.value)
    assert full_val == 0, f"FULL should be 0 after reading one entry, got {full_val}"
    dut._log.info("  FULL = 0 after one read ✓")

    dut._log.info("FULL flag test PASSED")


if __name__ == "__main__":
    main()
