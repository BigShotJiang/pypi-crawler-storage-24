# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity lfsr is
#   generic (
#     G_LFSR_WIDTH  : natural range 2 to 19 := 7
#   );
#   port (
#     CLK   : in  std_logic;
#     RST   : in  std_logic;
#     SEED  : in  std_logic_vector (G_LFSR_WIDTH-1 downto 0);
#     EN    : in  std_logic;
#     LFSR  : out std_logic_vector (G_LFSR_WIDTH-1 downto 0)
#   );
# end lfsr;

# Default generics - modify as needed for your test
GENERICS = {"G_LFSR_WIDTH": 7}


def main():
    """Run simulation for lfsr"""
    run_simulation(
        top_level="lfsr",
        module="tests.units.test_lfsr",
        custom_libraries={"tich": [f"{SRC_PATH}/units/lfsr.vhd"]},
        generics=GENERICS,
        waves=True,
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify LFSR produces unique, non-stuck outputs."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting LFSR test...")

    # Reset
    dut.RST.value = 1
    dut.EN.value = 0
    dut.SEED.value = 0x5A  # Non-trivial seed (7-bit: 0b1011010)
    await ClockCycles(dut.CLK, 5)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Enable LFSR and collect outputs
    dut.EN.value = 1
    outputs = []
    for i in range(20):
        await RisingEdge(dut.CLK)
        val = int(dut.LFSR.value)
        outputs.append(val)
        dut._log.info(f"  Cycle {i}: LFSR = 0x{val:02X}")

    # Assert: output changes from initial state
    unique_vals = set(outputs)
    assert len(unique_vals) > 1, f"LFSR stuck — only produced: {unique_vals}"

    # Assert: no two consecutive identical values (LFSR property)
    for i in range(1, len(outputs)):
        assert outputs[i] != outputs[i - 1], f"Consecutive identical outputs at cycle {i}: 0x{outputs[i]:02X}"

    # Assert: no degenerate all-zero output
    assert all(v != 0 for v in outputs), "LFSR produced all-zero output (degenerate)"

    dut._log.info(f"Test PASSED — {len(unique_vals)} unique values in 20 cycles")


@cocotb.test()
async def test_maximal_length_cycle(dut):
    """Verify LFSR cycle length matches the effective polynomial period.

    The RTL selects its polynomial via C_POLY_ARRAY(G_LFSR_WIDTH-1+2)
    (lfsr.vhd:98), i.e. index = WIDTH+1. For WIDTH=7 this picks C_POLY8
    (an 8-bit polynomial truncated to 7 bits), yielding a cycle of 31.
    """
    PERIOD = 10
    # Effective cycle length is 31 (not 2^7-1=127) due to the polynomial
    # index mapping: C_POLY_ARRAY(G_LFSR_WIDTH+1) selects C_POLY8 for WIDTH=7.
    EXPECTED_CYCLE = 31
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info(f"Starting cycle-length test (expect {EXPECTED_CYCLE} unique values)...")

    # Reset with seed = 1 (simplest non-zero seed)
    dut.RST.value = 1
    dut.EN.value = 0
    dut.SEED.value = 1
    await ClockCycles(dut.CLK, 5)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Enable and collect outputs
    dut.EN.value = 1
    outputs = []
    for i in range(EXPECTED_CYCLE + 10):  # Run a bit longer to detect early repeat
        await RisingEdge(dut.CLK)
        val = int(dut.LFSR.value)
        outputs.append(val)

    # First EXPECTED_CYCLE values should all be unique and non-zero
    first_period = outputs[:EXPECTED_CYCLE]
    unique_vals = set(first_period)

    assert 0 not in unique_vals, "LFSR produced all-zero (degenerate state)"
    assert len(unique_vals) == EXPECTED_CYCLE, (
        f"Expected {EXPECTED_CYCLE} unique values in first {EXPECTED_CYCLE} cycles, "
        f"got {len(unique_vals)}"
    )

    # Value at cycle EXPECTED_CYCLE should repeat the first value (cycle complete)
    assert outputs[EXPECTED_CYCLE] == outputs[0], (
        f"Cycle did not repeat: output[{EXPECTED_CYCLE}]=0x{outputs[EXPECTED_CYCLE]:02X} "
        f"!= output[0]=0x{outputs[0]:02X}"
    )

    dut._log.info(f"Test PASSED — {EXPECTED_CYCLE} unique values, cycle repeats at {EXPECTED_CYCLE}")


if __name__ == "__main__":
    main()
