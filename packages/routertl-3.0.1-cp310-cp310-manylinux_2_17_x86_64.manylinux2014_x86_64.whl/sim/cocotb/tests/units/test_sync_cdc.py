# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity sync_cdc is
#   generic (
#     G_NUM_STAGES : integer := 3;
#     G_OR_REDUCE  : boolean := FALSE
#     );
#   port (
#     CLK : in  std_logic;
#     R   : in  std_logic;
#     S   : in  std_logic;
#     D   : in  std_logic;
#     Q   : out std_logic
#     );
# end sync_cdc;

# Default generics - modify as needed for your test
GENERICS = {"G_NUM_STAGES": 3, "G_OR_REDUCE": False}


def main():
    """Run simulation for sync_cdc"""
    run_simulation(
        top_level="sync_cdc",
        module="tests.units.test_sync_cdc",
        custom_libraries={"tich": [f"{SRC_PATH}/units/sync_cdc.vhd"]},
        generics=GENERICS,
        waves=True,
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify sync_cdc propagates input after synchronization delay."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting sync_cdc test...")

    # Reset
    dut.R.value = 1
    dut.S.value = 0
    dut.D.value = 0
    await ClockCycles(dut.CLK, 5)
    dut.R.value = 0
    await RisingEdge(dut.CLK)

    # Verify output is low after reset
    assert int(dut.Q.value) == 0, f"Q should be 0 after reset, got {int(dut.Q.value)}"
    dut._log.info("  Q = 0 after reset ✓")

    # Drive input high and wait for sync stages + margin
    dut.D.value = 1
    await ClockCycles(dut.CLK, 5)

    q_val = int(dut.Q.value)
    assert q_val == 1, f"Q should be 1 after sync delay, got {q_val}"
    dut._log.info("  Q = 1 after D=1 propagation ✓")

    # Drive input low
    dut.D.value = 0
    await ClockCycles(dut.CLK, 5)

    q_val = int(dut.Q.value)
    assert q_val == 0, f"Q should be 0 after D=0 propagation, got {q_val}"
    dut._log.info("  Q = 0 after D=0 propagation ✓")

    dut._log.info("Test PASSED")


@cocotb.test()
async def test_set_overrides_input(dut):
    """Verify S (set) forces Q high even when D is low.

    sync_cdc's S is a synchronous preset, not an SR latch (sync_cdc.vhd:57-58).
    S=1 jams all stages to '1' on that clock edge, but once S is released,
    D=0 immediately starts shifting through the pipeline. Q returns to 0
    after G_NUM_STAGES cycles. We must hold S asserted to observe Q=1.
    """
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting set-override test...")

    # Reset
    dut.R.value = 1
    dut.S.value = 0
    dut.D.value = 0
    await ClockCycles(dut.CLK, 5)
    dut.R.value = 0
    await RisingEdge(dut.CLK)

    # Confirm Q is 0 with D=0
    assert int(dut.Q.value) == 0, f"Q should be 0 after reset, got {int(dut.Q.value)}"
    dut._log.info("  Q = 0 with D=0 ✓")

    # Hold S=1 while D stays 0 — S is a synchronous preset, so it must
    # remain asserted for Q to stay high (it is NOT latched).
    dut.S.value = 1
    await ClockCycles(dut.CLK, 3)

    q_val = int(dut.Q.value)
    assert q_val == 1, f"Q should be 1 while S is held high, got {q_val}"
    dut._log.info("  Q = 1 while S held ✓")

    # Release S — D=0 shifts through, Q should return to 0 after NUM_STAGES
    dut.S.value = 0
    await ClockCycles(dut.CLK, 5)
    q_val = int(dut.Q.value)
    assert q_val == 0, f"Q should be 0 after S released with D=0, got {q_val}"
    dut._log.info("  Q = 0 after S released ✓")

    dut._log.info("Set-override test PASSED")


@cocotb.test()
async def test_reset_during_active_d(dut):
    """Verify R clears Q even while D is actively high."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting reset-during-active-D test...")

    # Reset
    dut.R.value = 1
    dut.S.value = 0
    dut.D.value = 0
    await ClockCycles(dut.CLK, 5)
    dut.R.value = 0
    await RisingEdge(dut.CLK)

    # Drive D high and wait for Q to go high
    dut.D.value = 1
    await ClockCycles(dut.CLK, 5)
    assert int(dut.Q.value) == 1, f"Q should be 1 with D=1, got {int(dut.Q.value)}"
    dut._log.info("  Q = 1 with D=1 ✓")

    # Assert R while D is still high
    dut.R.value = 1
    await RisingEdge(dut.CLK)
    # R clears stages_r synchronously (sync_cdc.vhd:60-61). Wait one
    # additional cycle for the registered clear to propagate to Q output.
    await RisingEdge(dut.CLK)

    q_val = int(dut.Q.value)
    assert q_val == 0, f"Q should be 0 after R with D=1, got {q_val}"
    dut._log.info("  Q = 0 after R override ✓")

    # Release R — Q should eventually return to 1 since D is still high
    dut.R.value = 0
    await ClockCycles(dut.CLK, 5)
    q_val = int(dut.Q.value)
    assert q_val == 1, f"Q should recover to 1 after R released, got {q_val}"
    dut._log.info("  Q = 1 after R released ✓")

    dut._log.info("Reset-during-active-D test PASSED")


if __name__ == "__main__":
    main()
