# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity phase_accumulator is
#   generic (
#     G_ACC_WIDTH : integer := 32
#   );
#   port (
#     CLK          : in std_logic;
#     RST          : in std_logic;
#     PHASE_IN     : in std_logic_vector(G_ACC_WIDTH - 1 downto 0);
#     PHASE_OUT    : out std_logic_vector(G_ACC_WIDTH - 1 downto 0)
#   );
# end entity phase_accumulator;

# Default generics - modify as needed for your test
GENERICS = {"G_ACC_WIDTH": 32}


def main():
    """Run simulation for phase_accumulator"""
    run_simulation(
        top_level="phase_accumulator",
        module="tests.units.test_phase_accumulator",
        custom_libraries={"tich": [f"{SRC_PATH}/units/phase_accumulator.vhd"]},
        generics=GENERICS,
        waves=True,
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify phase_accumulator increments by PHASE_IN every clock."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting phase_accumulator test...")

    # Reset
    dut.RST.value = 1
    dut.PHASE_IN.value = 0
    await ClockCycles(dut.CLK, 5)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Verify output is 0 after reset
    assert int(dut.PHASE_OUT.value) == 0, f"PHASE_OUT should be 0 after reset, got {int(dut.PHASE_OUT.value)}"
    dut._log.info("  PHASE_OUT = 0 after reset ✓")

    # Set phase increment and run
    STEP = 100
    dut.PHASE_IN.value = STEP

    # Wait one clock for the pipeline to register the new PHASE_IN value
    await RisingEdge(dut.CLK)

    prev_val = 0
    for i in range(10):
        await RisingEdge(dut.CLK)
        cur_val = int(dut.PHASE_OUT.value)
        expected = ((i + 1) * STEP) & 0xFFFFFFFF  # 32-bit wrap
        dut._log.info(f"  Cycle {i + 1}: PHASE_OUT=0x{cur_val:08X} (exp=0x{expected:08X})")
        assert cur_val == expected, f"Cycle {i + 1}: got 0x{cur_val:08X}, expected 0x{expected:08X}"
        prev_val = cur_val

    dut._log.info("Test PASSED — accumulator increments correctly")


@cocotb.test()
async def test_wrap_around(dut):
    """Verify phase_accumulator wraps correctly at 32-bit boundary."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting wrap-around test...")

    # Reset
    dut.RST.value = 1
    dut.PHASE_IN.value = 0
    await ClockCycles(dut.CLK, 5)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Set a large step that will overflow quickly
    # 0x40000000 = 1/4 of full range → overflows after 4 steps
    BIG_STEP = 0x40000000
    dut.PHASE_IN.value = BIG_STEP

    # Pipeline: wait one clock for PHASE_IN to register
    await RisingEdge(dut.CLK)

    expected_vals = []
    acc = 0
    for i in range(6):
        acc = (acc + BIG_STEP) & 0xFFFFFFFF
        expected_vals.append(acc)

    for i in range(6):
        await RisingEdge(dut.CLK)
        cur_val = int(dut.PHASE_OUT.value)
        expected = expected_vals[i]
        dut._log.info(f"  Cycle {i + 1}: PHASE_OUT=0x{cur_val:08X} (exp=0x{expected:08X})")
        assert cur_val == expected, (
            f"Cycle {i + 1}: got 0x{cur_val:08X}, expected 0x{expected:08X}"
        )

    # The values should have wrapped: cycle 4 should be 0x00000000
    assert expected_vals[3] == 0x00000000, "Expected wrap to 0 at cycle 4"
    dut._log.info("  Confirmed wrap at cycle 4 (0x00000000) ✓")

    dut._log.info("Wrap-around test PASSED")


if __name__ == "__main__":
    main()
