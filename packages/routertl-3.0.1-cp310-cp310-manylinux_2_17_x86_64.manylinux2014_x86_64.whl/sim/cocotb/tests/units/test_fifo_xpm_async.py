# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.default_libraries import DEFAULT_LIBRARIES
from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity fifo_xpm_async is
#   generic (
#     G_FIFO_DEPTH   : integer := 6;
#     G_FIFO_WIDTH   : integer := 32;
#     G_FIFO_FWFT    : integer := 1;
#     G_DEBUG_TRACES : integer := 0; -- 0 = no debug traces, 1 = debug traces
#     G_CALLER_NAME  : string := "not defined" -- Used for assert messages
#   );
#   port (
#     -- Clock and Reset
#     RST           : in std_logic;
#     WR_CLK        : in std_logic;
#     RD_CLK        : in std_logic;
#     DIN           : in std_logic_vector(G_FIFO_WIDTH - 1 downto 0);
#     WR_EN         : in std_logic;
#     RD_EN         : in std_logic;
#     DOUT          : out std_logic_vector(G_FIFO_WIDTH - 1 downto 0);
#     FULL          : out std_logic;
#     EMPTY         : out std_logic;
#     RD_DATA_COUNT : out std_logic_vector(G_FIFO_DEPTH + G_FIFO_FWFT + 1 - 1 downto 0) := (others => '0');
#     WR_DATA_COUNT : out std_logic_vector(G_FIFO_DEPTH + G_FIFO_FWFT + 1 - 1 downto 0) := (others => '0');
#     PROG_FULL     : out std_logic;
#     PROG_EMPTY    : out std_logic;
#     WR_RST_BUSY   : out std_logic;
#     RD_RST_BUSY   : out std_logic
#   );
# end entity fifo_xpm_async;

# Default generics - modify as needed for your test
GENERICS = {"G_FIFO_DEPTH": 6, "G_FIFO_WIDTH": 32, "G_FIFO_FWFT": 1, "G_DEBUG_TRACES": 0}


def main():
    """Run simulation for fifo_xpm_async"""
    libs = {"xpm": DEFAULT_LIBRARIES["xpm"], "tich": [f"{SRC_PATH}/units/fifo_xpm_async.vhd"]}

    os.environ["COCOTB_CLEAN"] = "1"
    run_simulation(
        top_level="fifo_xpm_async",
        module="tests.units.test_fifo_xpm_async",
        custom_libraries=libs,
        generics=GENERICS,
        waves=True,
        simulator="nvc",
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify fifo_xpm_async ordering across clock domains."""
    PERIOD_WR = 10
    PERIOD_RD = 13  # Different frequency for async test
    cocotb.start_soon(Clock(dut.WR_CLK, PERIOD_WR, unit="ns").start())
    cocotb.start_soon(Clock(dut.RD_CLK, PERIOD_RD, unit="ns").start())
    dut._log.info("Starting fifo_xpm_async test (WR=10ns, RD=13ns)...")

    # Reset
    dut.RST.value = 1
    dut.WR_EN.value = 0
    dut.RD_EN.value = 0
    dut.DIN.value = 0
    await ClockCycles(dut.WR_CLK, 10)
    dut.RST.value = 0
    # Wait for both RST_BUSY signals to deassert
    for _ in range(30):
        await RisingEdge(dut.WR_CLK)
        wr_busy = int(dut.WR_RST_BUSY.value)
        rd_busy = int(dut.RD_RST_BUSY.value)
        if wr_busy == 0 and rd_busy == 0:
            break
    await ClockCycles(dut.WR_CLK, 5)

    # Verify FIFO is empty
    assert int(dut.EMPTY.value) == 1, "FIFO should be empty after reset"
    dut._log.info("  EMPTY = 1 after reset ✓")

    # Write 5 values on WR_CLK domain
    test_data = [0x1111AAAA, 0x2222BBBB, 0x3333CCCC, 0x4444DDDD, 0x5555EEEE]
    for val in test_data:
        dut.DIN.value = val
        dut.WR_EN.value = 1
        await RisingEdge(dut.WR_CLK)
        dut._log.info(f"  WR Push: 0x{val:08X}")
    dut.WR_EN.value = 0

    # Wait for data to cross to RD domain
    await ClockCycles(dut.RD_CLK, 10)

    # Read on RD_CLK domain — FWFT mode: first value already on DOUT
    read_data = []

    # In FWFT mode, DOUT already holds the first value (no RD_EN needed)
    val = int(dut.DOUT.value)
    read_data.append(val)
    dut._log.info(f"  RD Pop:  0x{val:08X} (exp=0x{test_data[0]:08X})")

    # Pop remaining values: each RD_EN pulse advances to next value
    for i in range(1, len(test_data)):
        dut.RD_EN.value = 1
        await RisingEdge(dut.RD_CLK)
        dut.RD_EN.value = 0
        await RisingEdge(dut.RD_CLK)
        val = int(dut.DOUT.value)
        read_data.append(val)
        dut._log.info(f"  RD Pop:  0x{val:08X} (exp=0x{test_data[i]:08X})")

    await ClockCycles(dut.RD_CLK, 5)

    # Verify FIFO ordering preserved across clock domains
    assert read_data == test_data, f"Async FIFO ordering broken: got {[hex(x) for x in read_data]}"

    dut._log.info("Test PASSED — 5 values preserved across clock domains")


@cocotb.test()
async def test_full_flag_async(dut):
    """Verify FULL flag asserts when async FIFO is filled to capacity.

    In FWFT mode with Gray-code CDC (CDC_SYNC_STAGES=2), both the internal
    storage depth and the FULL flag propagation differ from standard mode.
    We fill one entry at a time and poll FULL with CDC settling time.
    """
    PERIOD_WR = 10
    PERIOD_RD = 13
    DEPTH = 2 ** GENERICS["G_FIFO_DEPTH"]  # 64 entries
    cocotb.start_soon(Clock(dut.WR_CLK, PERIOD_WR, unit="ns").start())
    cocotb.start_soon(Clock(dut.RD_CLK, PERIOD_RD, unit="ns").start())
    dut._log.info(f"Starting async FULL flag test (depth={DEPTH})...")

    # Reset
    dut.RST.value = 1
    dut.WR_EN.value = 0
    dut.RD_EN.value = 0
    dut.DIN.value = 0
    await ClockCycles(dut.WR_CLK, 10)
    dut.RST.value = 0
    for _ in range(30):
        await RisingEdge(dut.WR_CLK)
        if int(dut.WR_RST_BUSY.value) == 0 and int(dut.RD_RST_BUSY.value) == 0:
            break
    await ClockCycles(dut.WR_CLK, 5)

    # Fill FIFO — write one entry at a time and poll FULL.
    # FWFT output register + CDC pipeline may affect usable depth.
    fill_count = 0
    for i in range(DEPTH + 2):  # +2 headroom for FWFT/CDC pipeline
        dut.DIN.value = i
        dut.WR_EN.value = 1
        await RisingEdge(dut.WR_CLK)
        dut.WR_EN.value = 0
        # CDC-aware settling: Gray-code pointers need extra cycles
        await ClockCycles(dut.WR_CLK, 5)
        fill_count += 1
        full_val = int(dut.FULL.value)
        if full_val == 1:
            break

    dut._log.info(f"  FULL asserted after {fill_count} writes ✓")
    assert int(dut.FULL.value) == 1, (
        f"FULL never asserted after {fill_count} writes (max tried: {DEPTH+2})"
    )

    # Read one entry from RD domain — FULL should deassert
    dut.RD_EN.value = 1
    await RisingEdge(dut.RD_CLK)
    dut.RD_EN.value = 0
    await ClockCycles(dut.WR_CLK, 10)  # Wait for CDC propagation

    full_val = int(dut.FULL.value)
    assert full_val == 0, f"FULL should be 0 after reading one entry, got {full_val}"
    dut._log.info("  FULL = 0 after one read ✓")

    dut._log.info("Async FULL flag test PASSED")


if __name__ == "__main__":
    main()
