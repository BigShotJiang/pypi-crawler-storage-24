# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity mux_cdc_er is
#   generic (
#     G_BUS_WIDTH : integer := 32
#     );
#   port (
#     CLK_SRC   : in  std_logic;
#     CLK_DST   : in  std_logic;
#     VALID_IN  : in  std_logic;
#     BUS_IN    : in  std_logic_vector(G_BUS_WIDTH-1 downto 0);
#     BUS_OUT   : out std_logic_vector(G_BUS_WIDTH-1 downto 0);
#     VALID_OUT : out  std_logic
#     );
# end entity mux_cdc_er;

# Default generics - modify as needed for your test
GENERICS = {"G_BUS_WIDTH": 32}


def main():
    """Run simulation for mux_cdc_er"""
    run_simulation(
        top_level="mux_cdc_er",
        module="tests.units.test_mux_cdc_er",
        custom_libraries={"tich": [f"{SRC_PATH}/units/event_synchronizer.vhd", f"{SRC_PATH}/units/mux_cdc_er.vhd"]},
        generics=GENERICS,
        waves=True,
        simulator="nvc",
        extra_env={"COCOTB_CLEAN": "1"},
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify mux_cdc_er transfers data correctly across clock domains."""
    PERIOD_SRC = 10
    PERIOD_DST = 12.5
    cocotb.start_soon(Clock(dut.CLK_SRC, PERIOD_SRC, unit="ns").start())
    cocotb.start_soon(Clock(dut.CLK_DST, PERIOD_DST, unit="ns").start())
    dut._log.info("Starting mux_cdc_er test...")

    dut.VALID_IN.value = 0
    dut.BUS_IN.value = 0
    await ClockCycles(dut.CLK_SRC, 10)

    # Send data word across domains
    test_values = [0xDEADBEEF, 0x12345678]
    for expected in test_values:
        dut.BUS_IN.value = expected
        dut.VALID_IN.value = 1
        await RisingEdge(dut.CLK_SRC)
        dut.VALID_IN.value = 0

        # Wait for valid pulse in DST domain
        valid_seen = False
        for i in range(20):
            await RisingEdge(dut.CLK_DST)
            if int(dut.VALID_OUT.value) == 1:
                valid_seen = True
                received = int(dut.BUS_OUT.value)
                dut._log.info(f"  VALID_OUT at DST cycle {i}: BUS_OUT=0x{received:08X} (exp=0x{expected:08X})")
                assert received == expected, f"Data mismatch: got 0x{received:08X}, expected 0x{expected:08X}"
                break

        assert valid_seen, f"VALID_OUT never asserted for data 0x{expected:08X}"

        # Wait for cooldown before next transfer
        await ClockCycles(dut.CLK_SRC, 10)

    dut._log.info("Test PASSED — both transfers verified")


@cocotb.test()
async def test_burst_transfer(dut):
    """Verify 5 consecutive transfers all arrive in order with correct data."""
    PERIOD_SRC = 10
    PERIOD_DST = 12.5
    cocotb.start_soon(Clock(dut.CLK_SRC, PERIOD_SRC, unit="ns").start())
    cocotb.start_soon(Clock(dut.CLK_DST, PERIOD_DST, unit="ns").start())
    dut._log.info("Starting burst transfer test (5 values)...")

    dut.VALID_IN.value = 0
    dut.BUS_IN.value = 0
    await ClockCycles(dut.CLK_SRC, 10)

    test_values = [0x11110001, 0x22220002, 0x33330003, 0x44440004, 0x55550005]
    received_count = 0

    for idx, expected in enumerate(test_values):
        dut.BUS_IN.value = expected
        dut.VALID_IN.value = 1
        await RisingEdge(dut.CLK_SRC)
        dut.VALID_IN.value = 0

        # Wait for valid pulse in DST domain
        valid_seen = False
        for i in range(25):
            await RisingEdge(dut.CLK_DST)
            if int(dut.VALID_OUT.value) == 1:
                valid_seen = True
                received = int(dut.BUS_OUT.value)
                dut._log.info(
                    f"  Transfer {idx + 1}: BUS_OUT=0x{received:08X} (exp=0x{expected:08X})"
                )
                assert received == expected, (
                    f"Transfer {idx + 1} mismatch: got 0x{received:08X}, expected 0x{expected:08X}"
                )
                received_count += 1
                break

        assert valid_seen, f"VALID_OUT never asserted for transfer {idx + 1}"

        # Cooldown before next transfer
        await ClockCycles(dut.CLK_SRC, 10)

    assert received_count == 5, f"Expected 5 transfers, received {received_count}"
    dut._log.info("Burst transfer test PASSED — all 5 transfers verified")


if __name__ == "__main__":
    main()
