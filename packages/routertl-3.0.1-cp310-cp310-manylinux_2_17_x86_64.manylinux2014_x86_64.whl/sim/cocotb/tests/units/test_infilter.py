# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity infilter is
#   generic(
#     G_DEB_CYCLES : integer := 3
#     );
#   port (
#     CLK       : in  std_logic;
#     CE        : in  std_logic;
#     PULSE_IN  : in  std_logic;
#     PULSE_OUT : out std_logic
#     );
# end infilter;

# Default generics - modify as needed for your test
GENERICS = {"G_DEB_CYCLES": 3}


def main():
    """Run simulation for infilter"""
    run_simulation(
        top_level="infilter",
        module="tests.units.test_infilter",
        custom_libraries={"tich": [f"{SRC_PATH}/units/infilter.vhd"]},
        generics=GENERICS,
        waves=True,
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify infilter rejects glitches and passes sustained signals."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting infilter test (G_DEB_CYCLES=3)...")

    # Initialize
    dut.CE.value = 1
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 10)

    # Verify output starts low
    assert int(dut.PULSE_OUT.value) == 0, "PULSE_OUT should start at 0"
    dut._log.info("  Initial PULSE_OUT = 0 ✓")

    # Test 1: Apply 1-clock glitch — should be filtered
    dut.PULSE_IN.value = 1
    await RisingEdge(dut.CLK)
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 5)
    assert int(dut.PULSE_OUT.value) == 0, "1-cycle glitch should be filtered"
    dut._log.info("  1-cycle glitch filtered ✓")

    # Test 2: Apply sustained input — should pass after debounce delay
    dut.PULSE_IN.value = 1
    await ClockCycles(dut.CLK, 10)  # Well beyond G_DEB_CYCLES=3
    assert int(dut.PULSE_OUT.value) == 1, f"Sustained input should pass, got PULSE_OUT={int(dut.PULSE_OUT.value)}"
    dut._log.info("  Sustained high passed through ✓")

    # Test 3: Release input — output should return to 0
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 10)
    assert int(dut.PULSE_OUT.value) == 0, f"Output should return to 0, got {int(dut.PULSE_OUT.value)}"
    dut._log.info("  Return to 0 after release ✓")

    dut._log.info("Test PASSED")


@cocotb.test()
async def test_ce_disabled_blocks_output(dut):
    """Verify PULSE_OUT stays 0 when CE is disabled, even with sustained input."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting CE-disabled test (G_DEB_CYCLES=3)...")

    # Initialize with CE disabled
    dut.CE.value = 0
    dut.PULSE_IN.value = 0
    await ClockCycles(dut.CLK, 5)

    # Drive sustained input while CE is off
    dut.PULSE_IN.value = 1
    await ClockCycles(dut.CLK, 20)  # Well beyond G_DEB_CYCLES=3

    assert int(dut.PULSE_OUT.value) == 0, (
        f"PULSE_OUT should be 0 with CE disabled, got {int(dut.PULSE_OUT.value)}"
    )
    dut._log.info("  PULSE_OUT stays 0 with CE=0 ✓")

    # Now enable CE — output should eventually assert
    dut.CE.value = 1
    await ClockCycles(dut.CLK, 10)

    assert int(dut.PULSE_OUT.value) == 1, (
        f"PULSE_OUT should be 1 after CE enabled, got {int(dut.PULSE_OUT.value)}"
    )
    dut._log.info("  PULSE_OUT = 1 after CE re-enabled ✓")

    dut._log.info("CE-disabled test PASSED")


if __name__ == "__main__":
    main()
