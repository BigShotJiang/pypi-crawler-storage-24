# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# entity ram_lut is
#   generic(
#     G_BITS    : natural := 32;          -- Bits
#     G_DEPTH   : natural := 6           -- Wide
#     );
#   port(
#     CLK  : in  std_logic;
#     RST  : in  std_logic;
#     WE   : in  std_logic;
#     ADDR : in  std_logic_vector(G_DEPTH-1 downto 0);
#     DIA  : in  std_logic_vector(G_BITS-1 downto 0);
#     DOA  : out std_logic_vector(G_BITS-1 downto 0)
#     );
# end ram_lut;

# Default generics - modify as needed for your test
GENERICS = {"G_BITS": 32}


def main():
    """Run simulation for ram_lut"""
    run_simulation(
        top_level="ram_lut",
        module="tests.units.test_ram_lut",
        custom_libraries={"tich": [f"{SRC_PATH}/units/ram_lut.vhd"]},
        generics=GENERICS,
        waves=True,
    )


@cocotb.test()
async def test_basic_behavior(dut):
    """Verify ram_lut write-then-read returns stored data."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting ram_lut test...")

    # Reset
    dut.RST.value = 1
    dut.WE.value = 0
    dut.ADDR.value = 0
    dut.DIA.value = 0
    await ClockCycles(dut.CLK, 5)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Write test data to 4 addresses
    test_data = {0: 0xDEADBEEF, 1: 0xCAFEBABE, 2: 0x12345678, 3: 0xA5A5A5A5}
    for addr, data in test_data.items():
        dut.ADDR.value = addr
        dut.DIA.value = data
        dut.WE.value = 1
        await RisingEdge(dut.CLK)
        dut._log.info(f"  Write: addr={addr} data=0x{data:08X}")
    dut.WE.value = 0
    await RisingEdge(dut.CLK)

    # Read back and verify
    for addr, expected in test_data.items():
        dut.ADDR.value = addr
        dut.WE.value = 0
        await RisingEdge(dut.CLK)
        await RisingEdge(dut.CLK)  # Extra cycle for read latency
        read_val = int(dut.DOA.value)
        dut._log.info(f"  Read:  addr={addr} got=0x{read_val:08X} exp=0x{expected:08X}")
        assert read_val == expected, f"Mismatch at addr {addr}: got 0x{read_val:08X}, expected 0x{expected:08X}"

    dut._log.info("Test PASSED — all write-readback checks passed")


@cocotb.test()
async def test_overwrite_same_address(dut):
    """Verify writing twice to the same address returns the latest value."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting overwrite test...")

    # Reset
    dut.RST.value = 1
    dut.WE.value = 0
    dut.ADDR.value = 0
    dut.DIA.value = 0
    await ClockCycles(dut.CLK, 5)
    dut.RST.value = 0
    await RisingEdge(dut.CLK)

    # Write value A to address 0
    first_val = 0x11111111
    dut.ADDR.value = 0
    dut.DIA.value = first_val
    dut.WE.value = 1
    await RisingEdge(dut.CLK)
    dut._log.info(f"  First write: addr=0 data=0x{first_val:08X}")

    # Overwrite with value B
    second_val = 0x22222222
    dut.DIA.value = second_val
    await RisingEdge(dut.CLK)
    dut._log.info(f"  Overwrite:   addr=0 data=0x{second_val:08X}")
    dut.WE.value = 0

    # Read back
    dut.ADDR.value = 0
    await RisingEdge(dut.CLK)
    await RisingEdge(dut.CLK)  # Read latency
    read_val = int(dut.DOA.value)
    dut._log.info(f"  Read:        addr=0 got=0x{read_val:08X}")

    assert read_val == second_val, (
        f"Expected latest value 0x{second_val:08X}, got 0x{read_val:08X}"
    )

    dut._log.info("Overwrite test PASSED")


if __name__ == "__main__":
    main()
