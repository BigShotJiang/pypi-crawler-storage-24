# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Test suite for edge_detector unit.

edge_detector detects rising, falling, or both edges based on G_EDGE_TYPE generic:
  - G_EDGE_TYPE = 0: Rising edge detection
  - G_EDGE_TYPE = 1: Falling edge detection
  - G_EDGE_TYPE = 2: Both edges detection

Ports:
  - CLK: Clock input
  - R  : Reset (optional, defaults to '0')
  - CE : Clock enable
  - D  : Signal to monitor
  - Q  : Detected edge pulse (1 clock cycle)
"""

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

from engine.paths import SRC_PATH
from engine.simulation import run_simulation

# =============================================================================
# Test Configuration
# =============================================================================

GENERICS = {
    "G_EDGE_TYPE": 0  # 0: rising, 1: falling, 2: both
}


# =============================================================================
# Helper Functions
# =============================================================================


async def reset_dut(dut):
    """Apply reset to the DUT."""
    dut.R.value = 1
    dut.CE.value = 0
    dut.D.value = 0
    await ClockCycles(dut.CLK, 3)
    dut.R.value = 0
    await RisingEdge(dut.CLK)


# =============================================================================
# Tests
# =============================================================================


@cocotb.test()
async def test_rising_edge_detection(dut):
    """Test rising edge detection (G_EDGE_TYPE = 0)."""
    PERIOD = 10  # ns

    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting rising edge detection test...")

    # Initialize
    await reset_dut(dut)

    # Enable clock enable
    dut.CE.value = 1
    await RisingEdge(dut.CLK)

    # D is low, Q should remain 0
    q_val = int(dut.Q.value)
    dut._log.info(f"Initial Q with D=0: {q_val}")
    assert q_val == 0, f"Expected Q=0 when D is stable low, got {q_val}"

    # Create rising edge: D goes from 0 to 1
    dut.D.value = 1
    await RisingEdge(dut.CLK)  # D_r gets old D (0), D is now 1

    # On next clock: D=1, D_r=1, so (D and not D_r) = 0
    # But Q_r was set on previous clock when D=1 and D_r=0
    await RisingEdge(dut.CLK)
    q_val = int(dut.Q.value)
    dut._log.info(f"After rising edge on D: Q = {q_val}")
    assert q_val == 1, "Expected Q=1 for rising edge"

    # Q should return to 0 since D is now stable
    await RisingEdge(dut.CLK)
    q_after = int(dut.Q.value)
    dut._log.info(f"After stable high: Q = {q_after}")
    assert q_after == 0, f"Expected Q=0 after D is stable, got {q_after}"

    # Test another rising edge by toggling D
    dut.D.value = 0
    await ClockCycles(dut.CLK, 2)  # Let it settle

    dut.D.value = 1
    await RisingEdge(dut.CLK)
    await RisingEdge(dut.CLK)
    q_second = int(dut.Q.value)
    dut._log.info(f"After second rising edge: Q = {q_second}")
    assert q_second == 1, "Expected Q=1 for second rising edge"

    dut._log.info("Rising edge detection test PASSED")


@cocotb.test()
async def test_clock_enable(dut):
    """Test that CE (clock enable) gates the edge detection."""
    PERIOD = 10  # ns

    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting clock enable test...")

    # Initialize
    await reset_dut(dut)

    # Keep CE disabled
    dut.CE.value = 0
    dut.D.value = 0
    await RisingEdge(dut.CLK)

    # Create rising edge on D while CE is disabled
    dut.D.value = 1
    await ClockCycles(dut.CLK, 3)

    # Q should remain 0 because CE is disabled
    q_val = int(dut.Q.value)
    assert q_val == 0, f"Expected Q=0 when CE disabled, got {q_val}"
    dut._log.info(f"Q with CE=0: {q_val} (expected 0)")

    dut._log.info("Clock enable test PASSED")


@cocotb.test()
async def test_reset(dut):
    """Test that R (reset) clears internal state."""
    PERIOD = 10  # ns

    cocotb.start_soon(Clock(dut.CLK, PERIOD, unit="ns").start())
    dut._log.info("Starting reset test...")

    # Initialize with CE enabled
    dut.R.value = 0
    dut.CE.value = 1
    dut.D.value = 1  # Set D high
    await ClockCycles(dut.CLK, 3)

    # Now apply reset
    dut.R.value = 1
    await RisingEdge(dut.CLK)

    # Q should be 0 after reset
    q_val = int(dut.Q.value)
    assert q_val == 0, f"Expected Q=0 after reset, got {q_val}"
    dut._log.info(f"Q after reset: {q_val} (expected 0)")

    # Release reset
    dut.R.value = 0
    await RisingEdge(dut.CLK)

    dut._log.info("Reset test PASSED")


# =============================================================================
# Main Entry Point
# =============================================================================


def main():
    """Run simulation for edge_detector."""
    run_simulation(
        top_level="edge_detector",
        module="tests.units.test_edge_detector",
        custom_libraries={"tich": [f"{SRC_PATH}/units/edge_detector.vhd"]},
        generics=GENERICS,
        waves=True,
        simulator="nvc",
        extra_env={"COCOTB_CLEAN": "1"},
    )


if __name__ == "__main__":
    main()
