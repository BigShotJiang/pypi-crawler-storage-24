# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import random

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer

# -----------------------------------------------------------------------------
#  Phase Accumulator Tuning Word Calculation for DDS
# -----------------------------------------------------------------------------
#  Overview:
#  The tuning word determines the step size added to the phase accumulator on
#  each clock cycle, which defines the output frequency of the Direct Digital
#  Synthesizer (DDS). The tuning word is computed using the following formula:
#
#               Tuning_Word = (f_out * 2^N) / f_clk
#
#  Where:
#    - f_out  = Desired output frequency (Hz)
#    - f_clk  = System clock frequency driving the phase accumulator (Hz)
#    - N      = Width of the phase accumulator (bits)
#    - 2^N    = Full-scale range of the accumulator (phase resolution)
#
#  The tuning word controls how fast the phase accumulator overflows, which
#  determines the frequency of the generated waveform.
# ------------------------------------------------------------------------------
# Example Calculation:
#   Given:
#      f_out  = 1 MHz
#      f_clk  = 100 MHz
#      N      = 32 bits
#
#   The tuning word is computed as:
#
#      Tuning_Word = (1M * 2^32) / 100M
#                  = (1,000,000 * 4,294,967,296) / 100,000,000
#                  = 42,949,672  (rounded)
#
#   In binary, this would be:  0010_1010_0110_0000_0000_0000_0000_0000
#


async def reset_dut(dut):
    """Reset the DUT"""
    dut.RST.value = 1  # Reset active
    await Timer(100, unit="ns")
    await RisingEdge(dut.CLK)
    dut.RST.value = 0  # Release reset
    await RisingEdge(dut.CLK)


async def write_fifo(dut, data):
    """Write data to the FIFO"""
    dut.DATAIN_VLD.value = 1
    dut.DATAIN.value = data
    await RisingEdge(dut.CLK)
    dut.DATAIN_VLD.value = 0
    await RisingEdge(dut.CLK)


async def write_fifo_stream(dut, datastream, length):
    """Write data to the FIFO"""
    for i in range(length):
        dut.DATAIN_VLD.value = 1
        dut.DATAIN.value = datastream[i]
        await RisingEdge(dut.CLK)

    dut.DATAIN_VLD.value = 0


@cocotb.test()
async def test_spi_injector(dut):
    """Basic functionality test."""

    for name in dir(dut):
        print(name)

    PERIOD_SYS = 10.0
    FIFO_DEPTH = 64
    LENGTH_CONTROL_LSB_BIT = 24
    START_BIT = 4

    cocotb.start_soon(Clock(dut.CLK, PERIOD_SYS, unit="ns").start())

    # Reset the DUT
    await reset_dut(dut)
    await Timer(100, unit="ns")

    dut.TUNING_WORD.value = 0
    dut.CONTROL.value = 0
    datastream = random.sample(range(0, 2**32), FIFO_DEPTH)
    await write_fifo_stream(dut, datastream, FIFO_DEPTH)

    injection_lentgh = 0x2
    start_bit = 0x1
    load_bit = 0x1

    control_value = (injection_lentgh << LENGTH_CONTROL_LSB_BIT) | load_bit

    # TW = 2^32 * 1MHz / 100MHz = 42,949,672
    dut.TUNING_WORD.value = 0x28F5C28  # 1MHz
    dut.CONTROL.value = control_value
    await RisingEdge(dut.CLK)

    control_value = start_bit << START_BIT
    dut.CONTROL.value = control_value

    await Timer(35, unit="us")  # Wait for the SPI transfer
    # Enable configuration
    # dut.CONTROL.value = 0

    await Timer(PERIOD_SYS * 6, unit="ns")

    dut.log.info("Testbench finished")
