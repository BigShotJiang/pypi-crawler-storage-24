# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Shared test configuration — path setup for standalone execution."""

import sys
from pathlib import Path

# Ensure sim/cocotb/ is on sys.path for `from engine.X import Y`
_cocotb_root = Path(__file__).resolve().parent.parent
if str(_cocotb_root) not in sys.path:
    sys.path.insert(0, str(_cocotb_root))
