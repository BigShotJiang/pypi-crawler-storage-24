# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Test for MMCME2_ADV — Xilinx Mixed-Mode Clock Manager primitive.

Verifies:
1. MMCM locks within a reasonable time after reset release
2. Output clock produces stable edges after lock
3. MMCM can be reset and re-locks successfully
"""

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer

from engine.paths import SRC_PATH
from engine.simulation import run_simulation


def main():
    """Run simulation for unisim_mmcm_wrap."""
    run_simulation(
        top_level="unisim_mmcm_wrap",
        module="tests.xilinx.test_unisim_mmcm",
        custom_libraries={"tich": [f"{SRC_PATH}/units/unisim_mmcm_wrap.vhd"]},
        generics={},
        waves=True,
        simulator="nvc",
        extra_env={"COCOTB_CLEAN": "1"},
    )


@cocotb.test()
async def test_mmcm_lock(dut):
    """Verify MMCM locks after reset release."""
    PERIOD = 10  # 100 MHz
    cocotb.start_soon(Clock(dut.CLK_IN, PERIOD, unit="ns").start())
    dut._log.info("Starting MMCM lock test...")

    # Hold in reset
    dut.RST.value = 1
    await Timer(100, unit="ns")

    # Verify not locked while in reset
    assert int(dut.LOCKED.value) == 0, "MMCM should not be locked during reset"
    dut._log.info("  LOCKED = 0 during reset ✓")

    # Release reset
    dut.RST.value = 0
    dut._log.info("  Reset released, waiting for lock...")

    # Wait for lock
    locked = False
    for i in range(2000):
        await Timer(10, unit="ns")
        if int(dut.LOCKED.value) == 1:
            locked = True
            dut._log.info(f"  LOCKED = 1 at ~{(i + 10) * 10} ns ✓")
            break

    assert locked, "MMCM failed to lock within 20 µs"

    # Verify output clock produces stable edges after lock
    edges = 0
    for _ in range(50):
        await RisingEdge(dut.CLK_OUT)
        edges += 1

    assert edges == 50, f"Expected 50 CLK_OUT edges after lock, got {edges}"
    dut._log.info(f"  CLK_OUT produced {edges} stable edges after lock ✓")

    dut._log.info("Test PASSED — MMCM lock verified")


@cocotb.test()
async def test_mmcm_reset_relock(dut):
    """Verify MMCM can be reset and re-locks successfully."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK_IN, PERIOD, unit="ns").start())
    dut._log.info("Starting MMCM reset/re-lock test...")

    # Initial lock
    dut.RST.value = 0
    for _ in range(2000):
        await Timer(10, unit="ns")
        if int(dut.LOCKED.value) == 1:
            break
    assert int(dut.LOCKED.value) == 1, "Initial lock failed"
    dut._log.info("  Initial lock acquired ✓")

    # Assert reset — LOCKED should drop
    dut.RST.value = 1
    await Timer(200, unit="ns")
    assert int(dut.LOCKED.value) == 0, "LOCKED should drop during reset"
    dut._log.info("  LOCKED dropped during reset ✓")

    # Release reset — should re-lock
    dut.RST.value = 0
    relocked = False
    for i in range(2000):
        await Timer(10, unit="ns")
        if int(dut.LOCKED.value) == 1:
            relocked = True
            dut._log.info(f"  Re-locked at ~{i * 10} ns ✓")
            break

    assert relocked, "MMCM failed to re-lock after reset"

    # Verify output clock after re-lock
    edges = 0
    for _ in range(20):
        await RisingEdge(dut.CLK_OUT)
        edges += 1
    assert edges == 20, f"Expected 20 edges after re-lock, got {edges}"
    dut._log.info(f"  CLK_OUT stable after re-lock ({edges} edges) ✓")

    dut._log.info("Test PASSED — MMCM reset/re-lock verified")


if __name__ == "__main__":
    main()
