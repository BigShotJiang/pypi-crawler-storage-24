# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Test for IBUFDS — Xilinx Differential Input Buffer primitive.

Verifies that IBUFDS converts a differential clock pair (CLK_P/CLK_N)
into a single-ended output that follows the positive input.
"""

import cocotb
from cocotb.triggers import FallingEdge, RisingEdge, Timer

from engine.paths import SRC_PATH
from engine.simulation import run_simulation


def main():
    """Run simulation for unisim_ibufds_wrap."""
    run_simulation(
        top_level="unisim_ibufds_wrap",
        module="tests.xilinx.test_unisim_ibufds",
        custom_libraries={"tich": [f"{SRC_PATH}/units/unisim_ibufds_wrap.vhd"]},
        generics={},
        waves=True,
        simulator="nvc",
        extra_env={"COCOTB_CLEAN": "1"},
    )


async def _drive_diff_clock(dut, period_ns=10):
    """Drive complementary differential clock pair."""
    half = period_ns / 2
    while True:
        dut.CLK_P.value = 1
        dut.CLK_N.value = 0
        await Timer(half, unit="ns")
        dut.CLK_P.value = 0
        dut.CLK_N.value = 1
        await Timer(half, unit="ns")


@cocotb.test()
async def test_ibufds_differential_to_single(dut):
    """Verify IBUFDS converts differential pair to single-ended output."""
    dut._log.info("Starting IBUFDS differential-to-single test...")

    # Drive differential clock at 100 MHz
    cocotb.start_soon(_drive_diff_clock(dut, period_ns=10))

    # Wait for initial settle
    await Timer(30, unit="ns")

    # Verify CLK_OUT follows CLK_P (positive input)
    rising = 0
    for _ in range(20):
        await RisingEdge(dut.CLK_OUT)
        rising += 1
        # At each rising edge of CLK_OUT, CLK_P should be high
        assert int(dut.CLK_P.value) == 1, "CLK_OUT rising edge should coincide with CLK_P = 1"

    assert rising == 20, f"Expected 20 rising edges, got {rising}"
    dut._log.info(f"  CLK_OUT produced {rising} rising edges tracking CLK_P ✓")

    # Verify complementarity: at falling edge, CLK_P should be low
    falling = 0
    for _ in range(20):
        await FallingEdge(dut.CLK_OUT)
        falling += 1
        assert int(dut.CLK_P.value) == 0, "CLK_OUT falling edge should coincide with CLK_P = 0"

    dut._log.info("  CLK_OUT falling edges track CLK_P=0 ✓")
    dut._log.info("Test PASSED — IBUFDS differential conversion verified")


if __name__ == "__main__":
    main()
