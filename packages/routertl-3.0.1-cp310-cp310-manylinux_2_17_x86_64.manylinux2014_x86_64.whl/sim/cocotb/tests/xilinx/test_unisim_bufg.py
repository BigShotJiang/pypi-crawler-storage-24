# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Test for BUFG — Xilinx Global Clock Buffer primitive.

Verifies that BUFG transparently passes the input clock to the output
with no functional alteration (buffering is a physical-only effect).
"""

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import FallingEdge, RisingEdge, Timer

from engine.paths import SRC_PATH
from engine.simulation import run_simulation


def main():
    """Run simulation for unisim_bufg_wrap."""
    run_simulation(
        top_level="unisim_bufg_wrap",
        module="tests.xilinx.test_unisim_bufg",
        custom_libraries={"tich": [f"{SRC_PATH}/units/unisim_bufg_wrap.vhd"]},
        generics={},
        waves=True,
        simulator="nvc",
        extra_env={"COCOTB_CLEAN": "1"},
    )


@cocotb.test()
async def test_bufg_passthrough(dut):
    """Verify BUFG passes clock from input to output."""
    PERIOD = 10
    cocotb.start_soon(Clock(dut.CLK_IN, PERIOD, unit="ns").start())
    dut._log.info("Starting BUFG passthrough test...")

    # Wait a few cycles for the buffer to settle
    await Timer(50, unit="ns")

    # Verify CLK_OUT tracks CLK_IN over 20 edges
    edges = 0
    for _ in range(20):
        await RisingEdge(dut.CLK_OUT)
        edges += 1

    assert edges == 20, f"Expected 20 rising edges on CLK_OUT, got {edges}"
    dut._log.info(f"  CLK_OUT produced {edges} rising edges ✓")

    # Verify falling edges too (full toggling)
    falling = 0
    for _ in range(20):
        await FallingEdge(dut.CLK_OUT)
        falling += 1

    assert falling == 20, f"Expected 20 falling edges on CLK_OUT, got {falling}"
    dut._log.info(f"  CLK_OUT produced {falling} falling edges ✓")

    dut._log.info("Test PASSED — BUFG clock passthrough verified")


if __name__ == "__main__":
    main()
