# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Test suite for unisim_smoke — validates unisim primitive simulation.

Proves the SDK can simulate IBUFDS → MMCME2_ADV → BUFG using
NVC with precompiled unisim libraries.
"""

import cocotb
from cocotb.triggers import RisingEdge, Timer

from engine.paths import SRC_PATH
from engine.simulation import run_simulation


def main():
    """Run simulation for unisim_smoke."""
    run_simulation(
        top_level="unisim_smoke",
        module="tests.xilinx.test_unisim_smoke",
        custom_libraries={"tich": [f"{SRC_PATH}/units/unisim_smoke.vhd"]},
        generics={},
        waves=True,
        simulator="nvc",
        extra_env={"COCOTB_CLEAN": "1"},
    )


async def _drive_diff_clock(dut, period_ns=10):
    """Drive a differential clock pair (CLK_P/CLK_N)."""
    half = period_ns / 2
    while True:
        dut.CLK_P.value = 1
        dut.CLK_N.value = 0
        await Timer(half, unit="ns")
        dut.CLK_P.value = 0
        dut.CLK_N.value = 1
        await Timer(half, unit="ns")


@cocotb.test()
async def test_unisim_smoke(dut):
    """Verify IBUFDS → MMCME2_ADV → BUFG chain produces locked output clock."""
    dut._log.info("Starting unisim smoke test (BUFG + IBUFDS + MMCME2_ADV)...")

    # Drive differential clock at 100 MHz
    cocotb.start_soon(_drive_diff_clock(dut, period_ns=10))

    # Wait for MMCM to lock (may take hundreds of cycles)
    locked = False
    for i in range(2000):
        await Timer(10, unit="ns")
        if int(dut.LOCKED.value) == 1:
            locked = True
            dut._log.info(f"  MMCM locked at ~{i * 10} ns ✓")
            break

    assert locked, "MMCM failed to lock within 20 µs"

    # Verify CLK_OUT toggles after lock
    edges = 0
    for _ in range(50):
        await RisingEdge(dut.CLK_OUT)
        edges += 1

    assert edges == 50, f"Expected 50 CLK_OUT rising edges, got {edges}"
    dut._log.info(f"  CLK_OUT produced {edges} edges after MMCM lock ✓")

    dut._log.info("Test PASSED — all 3 unisim primitives functional")


if __name__ == "__main__":
    main()
