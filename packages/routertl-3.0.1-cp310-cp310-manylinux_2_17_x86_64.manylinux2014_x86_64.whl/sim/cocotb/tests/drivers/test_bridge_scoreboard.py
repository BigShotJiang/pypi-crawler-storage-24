# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_bridge_scoreboard.py — Unit tests for BridgeScoreboard
============================================================

Pure-Python tests (no simulation needed).  Validates write-tracking,
read-verification, byte-strobe masking, and reporting.

Run with:
    python -m pytest sim/cocotb/tests/drivers/test_bridge_scoreboard.py -v
"""

import os
import sys

# ---------------------------------------------------------------------------
# Ensure the SDK tb package is importable without cocotb runtime.
# BridgeScoreboard itself is pure Python, but it lives in a module that
# imports cocotb.  We mock cocotb at the module level so the import works
# outside of simulation.
# ---------------------------------------------------------------------------
from unittest import mock

import pytest

_cocotb_mock = mock.MagicMock()
_cocotb_mock.utils.get_sim_time = mock.MagicMock(return_value=0)

sys.modules.setdefault("cocotb", _cocotb_mock)
sys.modules.setdefault("cocotb.triggers", mock.MagicMock())
sys.modules.setdefault("cocotb.queue", mock.MagicMock())
sys.modules.setdefault("cocotb.utils", _cocotb_mock.utils)

# Now we can import the scoreboard
# Add the sim/cocotb directory to path (tb is a package under sim/cocotb/)
_SIM_COCOTB = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _SIM_COCOTB not in sys.path:
    sys.path.insert(0, _SIM_COCOTB)

from tb.scoreboard import BridgeScoreboard, ScoreboardMismatch

# ===========================================================================
# Construction
# ===========================================================================


class TestConstruction:
    def test_default_32bit(self) -> None:
        sb = BridgeScoreboard()
        assert sb.data_width == 32
        assert sb.passed is True
        assert sb.num_writes == 0
        assert sb.num_reads == 0

    def test_8bit(self) -> None:
        sb = BridgeScoreboard(data_width=8)
        assert sb.data_width == 8

    def test_64bit(self) -> None:
        sb = BridgeScoreboard(data_width=64)
        assert sb.data_width == 64

    def test_128bit(self) -> None:
        sb = BridgeScoreboard(data_width=128)
        assert sb.data_width == 128

    def test_invalid_width_raises(self) -> None:
        with pytest.raises(ValueError, match="data_width must be"):
            BridgeScoreboard(data_width=24)


# ===========================================================================
# Write + Read — basic round-trip
# ===========================================================================


class TestWriteReadMatch:
    def test_single_write_read(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xDEADBEEF)
        assert sb.check_read(0x100, 0xDEADBEEF) is True
        assert sb.passed
        assert sb.num_writes == 1
        assert sb.num_reads == 1

    def test_multiple_addresses(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x000, 0x11111111)
        sb.record_write(0x004, 0x22222222)
        sb.record_write(0x008, 0x33333333)

        assert sb.check_read(0x000, 0x11111111) is True
        assert sb.check_read(0x004, 0x22222222) is True
        assert sb.check_read(0x008, 0x33333333) is True
        assert sb.passed

    def test_overwrite(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xAAAAAAAA)
        sb.record_write(0x100, 0xBBBBBBBB)
        assert sb.check_read(0x100, 0xBBBBBBBB) is True

    def test_uninitialized_reads_as_zero(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        assert sb.check_read(0x200, 0x00000000) is True

    def test_data_masking(self) -> None:
        """Data wider than data_width should be masked."""
        sb = BridgeScoreboard(data_width=8, strict=False)
        sb.record_write(0x00, 0x1FF)  # 9 bits, but 8-bit bus
        assert sb.check_read(0x00, 0xFF) is True


# ===========================================================================
# Read mismatch detection
# ===========================================================================


class TestReadMismatch:
    def test_mismatch_detected_non_strict(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xDEADBEEF)
        assert sb.check_read(0x100, 0xCAFEBABE) is False
        assert not sb.passed
        assert sb.num_mismatches == 1

    def test_mismatch_strict_raises(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=True)
        sb.record_write(0x100, 0xDEADBEEF)
        with pytest.raises(AssertionError, match="Mismatch"):
            sb.check_read(0x100, 0xCAFEBABE)

    def test_mismatch_record_details(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xDEADBEEF)
        sb.check_read(0x100, 0xCAFEBABE)

        assert len(sb.mismatches) == 1
        mm = sb.mismatches[0]
        assert mm.addr == 0x100
        assert mm.expected == 0xDEADBEEF
        assert mm.actual == 0xCAFEBABE

    def test_multiple_mismatches(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x000, 0x11111111)
        sb.record_write(0x004, 0x22222222)
        sb.check_read(0x000, 0xFFFFFFFF)
        sb.check_read(0x004, 0x00000000)
        assert sb.num_mismatches == 2
        assert not sb.passed


# ===========================================================================
# Byte-strobe masking
# ===========================================================================


class TestStrobeMasking:
    def test_full_strobe(self) -> None:
        """strb=0xF with 32-bit bus = full-word write."""
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xDEADBEEF, strb=0xF)
        assert sb.check_read(0x100, 0xDEADBEEF) is True

    def test_partial_strobe_low_byte(self) -> None:
        """Write only byte 0 of a 32-bit word."""
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xAABBCCDD)  # init
        sb.record_write(0x100, 0x000000FF, strb=0x1)  # overwrite byte 0 only
        assert sb.check_read(0x100, 0xAABBCCFF) is True

    def test_partial_strobe_high_byte(self) -> None:
        """Write only byte 3 of a 32-bit word."""
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0x00000000)  # init
        sb.record_write(0x100, 0xFF000000, strb=0x8)  # overwrite byte 3 only
        assert sb.check_read(0x100, 0xFF000000) is True

    def test_partial_strobe_middle_bytes(self) -> None:
        """Write bytes 1 and 2 of a 32-bit word."""
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0x11223344)  # init
        sb.record_write(0x100, 0x00AABB00, strb=0x6)  # overwrite bytes 1,2
        assert sb.check_read(0x100, 0x11AABB44) is True

    def test_strobe_on_uninitialized(self) -> None:
        """Partial write to an address that hasn't been written yet (default 0)."""
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x200, 0x000000FF, strb=0x1)
        assert sb.check_read(0x200, 0x000000FF) is True

    def test_16bit_strobe(self) -> None:
        """Byte-strobe on a 16-bit bus."""
        sb = BridgeScoreboard(data_width=16, strict=False)
        sb.record_write(0x00, 0xAABB)  # init
        sb.record_write(0x00, 0x00FF, strb=0x1)  # overwrite low byte
        assert sb.check_read(0x00, 0xAAFF) is True


# ===========================================================================
# Address alignment
# ===========================================================================


class TestAddressAlignment:
    def test_32bit_alignment(self) -> None:
        """Misaligned addresses should be auto-aligned to word boundary."""
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x102, 0xDEADBEEF)  # auto-aligns to 0x100
        assert sb.check_read(0x100, 0xDEADBEEF) is True

    def test_64bit_alignment(self) -> None:
        sb = BridgeScoreboard(data_width=64, strict=False)
        sb.record_write(0x105, 0xDEADBEEFCAFEBABE)  # auto-aligns to 0x100
        assert sb.check_read(0x100, 0xDEADBEEFCAFEBABE) is True


# ===========================================================================
# Predict
# ===========================================================================


class TestPredict:
    def test_predict_after_write(self) -> None:
        sb = BridgeScoreboard(data_width=32)
        sb.record_write(0x100, 0xDEADBEEF)
        assert sb.predict(0x100) == 0xDEADBEEF

    def test_predict_uninitialized(self) -> None:
        sb = BridgeScoreboard(data_width=32)
        assert sb.predict(0x300) == 0


# ===========================================================================
# Reset
# ===========================================================================


class TestReset:
    def test_reset_clears_all(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xDEADBEEF)
        sb.check_read(0x100, 0xCAFEBABE)
        sb.reset()
        assert sb.num_writes == 0
        assert sb.num_reads == 0
        assert sb.num_mismatches == 0
        assert sb.passed
        assert sb.predict(0x100) == 0


# ===========================================================================
# Report
# ===========================================================================


class TestReport:
    def test_report_passed(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xDEADBEEF)
        sb.check_read(0x100, 0xDEADBEEF)
        report = sb.report()
        assert "PASSED" in report
        assert "1 writes" in report
        assert "1 reads" in report
        assert "0 mismatches" in report

    def test_report_failed(self) -> None:
        sb = BridgeScoreboard(data_width=32, strict=False)
        sb.record_write(0x100, 0xDEADBEEF)
        sb.check_read(0x100, 0xCAFEBABE)
        report = sb.report()
        assert "FAILED" in report
        assert "1 mismatches" in report
        assert "0xDEADBEEF" in report
        assert "0xCAFEBABE" in report

    def test_empty_scoreboard_passes(self) -> None:
        sb = BridgeScoreboard(data_width=32)
        assert sb.passed
        assert "PASSED" in sb.report()


# ===========================================================================
# ScoreboardMismatch __str__
# ===========================================================================


class TestScoreboardMismatch:
    def test_str_format(self) -> None:
        mm = ScoreboardMismatch(
            addr=0x100,
            expected=0xDEADBEEF,
            actual=0xCAFEBABE,
            transaction_id=42,
        )
        s = str(mm)
        assert "#42" in s
        assert "0x00000100" in s
        assert "0xDEADBEEF" in s
        assert "0xCAFEBABE" in s


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
