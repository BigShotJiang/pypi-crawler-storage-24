# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tests/drivers/test_axi_lite.py
"""
Unit tests for the native AXI-Lite Master/Slave BFMs.

Tests verify AXI-Lite protocol handshaking, data integrity,
byte strobes, error responses, and configurable latency.

Run with:
    SIM=nvc python tests/drivers/test_axi_lite.py
"""

import random
import sys
from pathlib import Path

import cocotb
from cocotb.triggers import ClockCycles

# Ensure SDK path is available
current_dir = Path(__file__).resolve().parent
sdk_cocotb_path = current_dir.parents[1]
sys.path.insert(0, str(sdk_cocotb_path))

from tb.drivers.axi_lite import (
    AxiLiteBus,
    AxiLiteMaster,
    AxiLiteSlave,
    AxiResp,
    AxiRespError,
)
from tb.env import TbEnv

# =============================================================================
# Helpers
# =============================================================================


async def setup(dut, read_latency=0, write_latency=0, error_addresses=None):
    """Create TbEnv, master, and slave; start clock and reset."""
    env = TbEnv(dut, clk="CLK", rst="RST", period_ns=10)
    await env.start_clock()
    await env.reset(cycles=5)

    master = AxiLiteMaster(env, prefix="S_AXI")
    slave = AxiLiteSlave(
        env,
        prefix="S_AXI",
        read_latency=read_latency,
        write_latency=write_latency,
        error_addresses=error_addresses,
    )
    await slave.start()

    # Let everything settle after reset
    await ClockCycles(dut.CLK, 2)

    return env, master, slave


# =============================================================================
# Test Cases
# =============================================================================


@cocotb.test()
async def test_bus_signal_discovery(dut):
    """Verify AxiLiteBus resolves all 19 signals from the DUT."""
    dut._log.info("Testing AXI-Lite bus signal discovery...")

    bus = AxiLiteBus.from_prefix(dut, "S_AXI")

    # Check all signals are resolved (not None)
    assert bus.awaddr is not None
    assert bus.awprot is not None
    assert bus.awvalid is not None
    assert bus.awready is not None
    assert bus.wdata is not None
    assert bus.wstrb is not None
    assert bus.wvalid is not None
    assert bus.wready is not None
    assert bus.bresp is not None
    assert bus.bvalid is not None
    assert bus.bready is not None
    assert bus.araddr is not None
    assert bus.arprot is not None
    assert bus.arvalid is not None
    assert bus.arready is not None
    assert bus.rdata is not None
    assert bus.rresp is not None
    assert bus.rvalid is not None
    assert bus.rready is not None
    dut._log.info("✓ All 19 AXI-Lite signals resolved")


@cocotb.test()
async def test_single_write_read(dut):
    """Write one word, read it back, verify data integrity."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0xDEADBEEF)
    data, resp = await master.read(0x0000)

    assert data == 0xDEADBEEF, f"Expected 0xDEADBEEF, got 0x{data:08X}"
    assert resp == AxiResp.OKAY

    env.log.info("✓ Single write/read verified")


@cocotb.test()
async def test_sequential_writes(dut):
    """Write 16 sequential addresses, read all back."""
    env, master, slave = await setup(dut)

    test_data = {i * 4: 0x1000 + i for i in range(16)}

    # Write all
    for addr, data in test_data.items():
        await master.write(addr, data)

    # Read back and verify
    for addr, expected in test_data.items():
        data, resp = await master.read(addr)
        assert data == expected, f"@0x{addr:04X}: expected 0x{expected:08X}, got 0x{data:08X}"
        assert resp == AxiResp.OKAY

    env.log.info("✓ 16 sequential write/read pairs verified")


@cocotb.test()
async def test_random_access(dut):
    """Random address/data patterns."""
    env, master, slave = await setup(dut)

    rng = random.Random(42)  # deterministic seed
    test_data = {}

    # Write 32 random locations
    for _ in range(32):
        addr = rng.randint(0, 0xFFFC) & ~0x3  # word-aligned
        data = rng.randint(0, 0xFFFFFFFF)
        test_data[addr] = data
        await master.write(addr, data)

    # Read back (in different order)
    addrs = list(test_data.keys())
    rng.shuffle(addrs)
    for addr in addrs:
        data, resp = await master.read(addr)
        assert data == test_data[addr], f"@0x{addr:04X}: expected 0x{test_data[addr]:08X}, got 0x{data:08X}"

    env.log.info(f"✓ {len(test_data)} random write/read pairs verified")


@cocotb.test()
async def test_write_strobe_byte0(dut):
    """Write with byte strobe enabling only byte 0."""
    env, master, slave = await setup(dut)

    # Pre-fill with known data
    await master.write(0x0000, 0xAABBCCDD)

    # Write only byte 0 (LSB)
    await master.write_masked(0x0000, 0x000000FF, strb=0x01)

    data, _ = await master.read(0x0000)
    assert data == 0xAABBCCFF, f"Expected 0xAABBCCFF, got 0x{data:08X}"

    env.log.info("✓ Byte strobe (byte 0) verified")


@cocotb.test()
async def test_write_strobe_byte3(dut):
    """Write with byte strobe enabling only byte 3 (MSB)."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0xAABBCCDD)

    # Write only byte 3 (MSB)
    await master.write_masked(0x0000, 0x11000000, strb=0x08)

    data, _ = await master.read(0x0000)
    assert data == 0x11BBCCDD, f"Expected 0x11BBCCDD, got 0x{data:08X}"

    env.log.info("✓ Byte strobe (byte 3) verified")


@cocotb.test()
async def test_write_strobe_halfword(dut):
    """Write with byte strobe for lower halfword only."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0xAABBCCDD)

    # Write lower halfword
    await master.write_masked(0x0000, 0x00001234, strb=0x03)

    data, _ = await master.read(0x0000)
    assert data == 0xAABB1234, f"Expected 0xAABB1234, got 0x{data:08X}"

    env.log.info("✓ Byte strobe (lower halfword) verified")


@cocotb.test()
async def test_error_response_write(dut):
    """Slave returns SLVERR on write to error address."""
    env, master, slave = await setup(dut, error_addresses={0x0BAD})

    # Configure master to not raise
    master.raise_on_resp = False

    resp = await master.write(0x0BAD, 0x12345678)
    assert resp == AxiResp.SLVERR, f"Expected SLVERR, got {resp.name}"

    env.log.info("✓ Write SLVERR response verified")


@cocotb.test()
async def test_error_response_read(dut):
    """Slave returns SLVERR on read from error address."""
    env, master, slave = await setup(dut, error_addresses={0x0BAD})

    master.raise_on_resp = False

    _, resp = await master.read(0x0BAD)
    assert resp == AxiResp.SLVERR, f"Expected SLVERR, got {resp.name}"

    env.log.info("✓ Read SLVERR response verified")


@cocotb.test()
async def test_error_raises_exception(dut):
    """AxiRespError is raised when raise_on_resp is True."""
    env, master, slave = await setup(dut, error_addresses={0xDEAD})

    try:
        await master.write(0xDEAD, 0x00)
        assert False, "Should have raised AxiRespError"
    except AxiRespError as e:
        assert e.resp == AxiResp.SLVERR
        assert "0x0000DEAD" in str(e)

    env.log.info("✓ AxiRespError exception verified")


@cocotb.test()
async def test_read_latency(dut):
    """Slave with extra read latency cycles."""
    env, master, slave = await setup(dut, read_latency=3)

    await master.write(0x0000, 0xCAFEBABE)
    data, resp = await master.read(0x0000)

    assert data == 0xCAFEBABE
    assert resp == AxiResp.OKAY

    env.log.info("✓ Read with 3 cycles latency verified")


@cocotb.test()
async def test_write_latency(dut):
    """Slave with extra write response latency."""
    env, master, slave = await setup(dut, write_latency=2)

    resp = await master.write(0x0000, 0xFEEDFACE)
    assert resp == AxiResp.OKAY

    data, _ = await master.read(0x0000)
    assert data == 0xFEEDFACE

    env.log.info("✓ Write with 2 cycles response latency verified")


@cocotb.test()
async def test_back_to_back_writes(dut):
    """Rapid consecutive writes without gaps."""
    env, master, slave = await setup(dut)

    for i in range(8):
        await master.write(i * 4, i * 0x11111111)

    for i in range(8):
        data, _ = await master.read(i * 4)
        assert data == i * 0x11111111, f"@{i * 4}: mismatch"

    env.log.info("✓ 8 back-to-back writes verified")


@cocotb.test()
async def test_back_to_back_reads(dut):
    """Rapid consecutive reads without gaps."""
    env, master, slave = await setup(dut)

    # Pre-populate via slave API
    for i in range(8):
        slave.set_memory(i * 4, (i + 1) * 0x10000)

    for i in range(8):
        data, _ = await master.read(i * 4)
        assert data == (i + 1) * 0x10000

    env.log.info("✓ 8 back-to-back reads from pre-populated memory verified")


@cocotb.test()
async def test_slave_memory_api(dut):
    """Verify set_memory/get_memory/dump API."""
    env, master, slave = await setup(dut)

    slave.set_memory(0x100, 0xAAAAAAAA)
    assert slave.get_memory(0x100) == 0xAAAAAAAA
    assert slave.get_memory(0x200) == 0  # default value

    data, _ = await master.read(0x100)
    assert data == 0xAAAAAAAA

    await master.write(0x200, 0xBBBBBBBB)
    assert slave.get_memory(0x200) == 0xBBBBBBBB

    mem = slave.dump()
    assert 0x100 in mem
    assert 0x200 in mem

    env.log.info("✓ Slave memory API verified")


@cocotb.test()
async def test_unwritten_address_returns_default(dut):
    """Reading an unwritten address returns 0 (default)."""
    env, master, slave = await setup(dut)

    data, resp = await master.read(0x8000)
    assert data == 0, f"Expected 0, got 0x{data:08X}"
    assert resp == AxiResp.OKAY

    env.log.info("✓ Unwritten address default (0) verified")


@cocotb.test()
async def test_overwrite(dut):
    """Writing same address twice overwrites correctly."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0x11111111)
    await master.write(0x0000, 0x22222222)

    data, _ = await master.read(0x0000)
    assert data == 0x22222222

    env.log.info("✓ Overwrite verified")


@cocotb.test()
async def test_address_boundary(dut):
    """Write/read at min and max addresses."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0xAAAAAAAA)
    await master.write(0xFFFC, 0x55555555)

    data_min, _ = await master.read(0x0000)
    data_max, _ = await master.read(0xFFFC)

    assert data_min == 0xAAAAAAAA
    assert data_max == 0x55555555

    env.log.info("✓ Address boundary (min/max) verified")


# =============================================================================
# Standalone Execution Entry Point
# =============================================================================

if __name__ == "__main__":
    from pathlib import Path

    from engine.simulation import run_simulation

    run_simulation(
        top_level="axi_lite_loopback_tb",
        module="test_axi_lite",
        top_level_lang="vhdl",
        waves=True,
        verbose=True,
        work_lib="work",
        custom_libraries={
            "work": [
                str(Path(__file__).parent / "axi_lite_loopback_tb.vhd"),
            ]
        },
    )
