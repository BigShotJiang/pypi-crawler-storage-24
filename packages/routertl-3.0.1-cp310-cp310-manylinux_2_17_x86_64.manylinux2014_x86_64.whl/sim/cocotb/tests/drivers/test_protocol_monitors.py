#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Unit tests for Protocol Monitor classes.

These are pure-Python tests (no simulator needed) that exercise the
ProtocolViolation dataclass, module imports, and class instantiation.

Simulation-level testing of violation detection is done through the
bridge integration tests (test_axilite_avalon_bridge.py) which attach
monitors to the live DUT.
"""

import sys
import unittest
from dataclasses import asdict
from pathlib import Path

# Ensure SDK path is available
sdk_root = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(sdk_root / "sim" / "cocotb"))
sys.path.insert(0, str(sdk_root))


class TestProtocolViolation(unittest.TestCase):
    """Test the ProtocolViolation dataclass."""

    def test_creation(self):
        from tb.monitors import ProtocolViolation

        v = ProtocolViolation(
            check_id="AXI_STAB_AW",
            channel="AW",
            timestamp_ns=1234,
            message="AWADDR changed while AWVALID=1 & AWREADY=0",
        )
        self.assertEqual(v.check_id, "AXI_STAB_AW")
        self.assertEqual(v.channel, "AW")
        self.assertEqual(v.timestamp_ns, 1234)
        self.assertIn("AWADDR", v.message)

    def test_frozen(self):
        from tb.monitors import ProtocolViolation

        v = ProtocolViolation("AXI_RST", "W", 0, "test")
        with self.assertRaises(AttributeError):
            v.check_id = "modified"

    def test_asdict(self):
        from tb.monitors import ProtocolViolation

        v = ProtocolViolation("AVL_OVERLAP", "bus", 500, "overlap")
        d = asdict(v)
        self.assertEqual(d["check_id"], "AVL_OVERLAP")
        self.assertEqual(d["timestamp_ns"], 500)


class TestMonitorImports(unittest.TestCase):
    """Verify all public symbols are importable from the package."""

    def test_all_public_symbols(self):
        from tb.monitors import (
            AvalonMMMonitor,
            AxiLiteMonitor,
            StreamMonitor,
            bv_to_int,
        )

        # Just verify they are callable / classes
        self.assertTrue(callable(bv_to_int))
        self.assertTrue(callable(AxiLiteMonitor))
        self.assertTrue(callable(AvalonMMMonitor))
        self.assertTrue(callable(StreamMonitor))

    def test_backward_compat_stream_monitor(self):
        """StreamMonitor and Sample should still be importable."""
        from tb.monitors import Sample, StreamMonitor

        self.assertTrue(hasattr(StreamMonitor, "__init__"))
        s = Sample(ts_ns=100, value=42)
        self.assertEqual(s.ts_ns, 100)
        self.assertEqual(s.value, 42)


class TestAxiLiteMonitorInstantiation(unittest.TestCase):
    """Test AxiLiteMonitor can be instantiated with mock objects."""

    def test_instantiation(self):
        import logging

        from tb.monitors import AxiLiteMonitor

        # Minimal mock bus
        class MockBus:
            awvalid = awready = awaddr = None
            wvalid = wready = wdata = wstrb = None
            bvalid = bready = bresp = None
            arvalid = arready = araddr = None
            rvalid = rready = rdata = rresp = None

        log = logging.getLogger("test_axi_mon")
        mon = AxiLiteMonitor(MockBus(), None, None, log=log)
        self.assertEqual(mon.violation_count, 0)
        self.assertIn("0 violations", mon.report())

    def test_report_format(self):
        import logging

        from tb.monitors import AxiLiteMonitor, ProtocolViolation

        class MockBus:
            awvalid = awready = awaddr = None
            wvalid = wready = wdata = wstrb = None
            bvalid = bready = bresp = None
            arvalid = arready = araddr = None
            rvalid = rready = rdata = rresp = None

        log = logging.getLogger("test_axi_report")
        mon = AxiLiteMonitor(MockBus(), None, None, log=log)
        # Manually inject a violation
        mon._violations.append(ProtocolViolation("AXI_STAB_AW", "AW", 100, "test violation"))
        self.assertEqual(mon.violation_count, 1)
        self.assertIn("AXI_STAB_AW", mon.report())
        self.assertIn("100ns", mon.report())


class TestAvalonMMMonitorInstantiation(unittest.TestCase):
    """Test AvalonMMMonitor can be instantiated with mock objects."""

    def test_instantiation(self):
        import logging

        from tb.monitors import AvalonMMMonitor

        class MockBus:
            address = read = write = writedata = None
            byteenable = readdata = waitrequest = None
            readdatavalid = None

        log = logging.getLogger("test_avl_mon")
        mon = AvalonMMMonitor(MockBus(), None, None, log=log)
        self.assertEqual(mon.violation_count, 0)
        self.assertIn("0 violations", mon.report())

    def test_report_format(self):
        import logging

        from tb.monitors import AvalonMMMonitor, ProtocolViolation

        class MockBus:
            address = read = write = writedata = None
            byteenable = readdata = waitrequest = None
            readdatavalid = None

        log = logging.getLogger("test_avl_report")
        mon = AvalonMMMonitor(MockBus(), None, None, log=log)
        mon._violations.append(ProtocolViolation("AVL_OVERLAP", "bus", 200, "read+write overlap"))
        self.assertEqual(mon.violation_count, 1)
        self.assertIn("AVL_OVERLAP", mon.report())


class TestCheckMonitors(unittest.TestCase):
    """Test env.check_monitors() logic purely with injected violations.

    These tests exercise the aggregation and AssertionError formatting that
    TbEnv.check_monitors() performs — without needing a simulator.
    """

    def _make_monitor(self, n_violations: int):
        """Return an AxiLiteMonitor with n_violations pre-injected."""
        import logging

        from tb.monitors import AxiLiteMonitor, ProtocolViolation

        class MockBus:
            awvalid = awready = awaddr = None
            wvalid = wready = wdata = wstrb = None
            bvalid = bready = bresp = None
            arvalid = arready = araddr = None
            rvalid = rready = rdata = rresp = None

        mon = AxiLiteMonitor(MockBus(), None, None, log=logging.getLogger("check_mon_test"))
        for i in range(n_violations):
            mon._violations.append(ProtocolViolation(f"AXI_TEST_{i}", "AW", i * 10, f"violation {i}"))
        return mon

    def _check_monitors(self, monitors):
        """Replicate TbEnv.check_monitors() logic for pure-Python testing."""
        import logging

        log = logging.getLogger("fake_check")
        all_violations = []
        for mon in monitors:
            log.info(mon.report())
            all_violations.extend(mon.violations)
        if all_violations:
            lines = [f"{len(all_violations)} protocol violation(s) detected:"]
            for v in all_violations:
                lines.append(f"  [{v.check_id}] {v.channel} @ {v.timestamp_ns}ns: {v.message}")
            raise AssertionError("\n".join(lines))

    def test_no_violations_passes(self):
        """check_monitors() must not raise when all monitors are clean."""
        self._check_monitors([self._make_monitor(0)])

    def test_single_violation_raises(self):
        """check_monitors() must raise AssertionError on a violation."""
        with self.assertRaises(AssertionError) as ctx:
            self._check_monitors([self._make_monitor(1)])
        self.assertIn("1 protocol violation(s)", str(ctx.exception))
        self.assertIn("AXI_TEST_0", str(ctx.exception))

    def test_multiple_monitors_aggregated(self):
        """Violations from multiple monitors are aggregated into one report."""
        mon_a = self._make_monitor(2)
        mon_b = self._make_monitor(1)
        with self.assertRaises(AssertionError) as ctx:
            self._check_monitors([mon_a, mon_b])
        self.assertIn("3 protocol violation(s)", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
