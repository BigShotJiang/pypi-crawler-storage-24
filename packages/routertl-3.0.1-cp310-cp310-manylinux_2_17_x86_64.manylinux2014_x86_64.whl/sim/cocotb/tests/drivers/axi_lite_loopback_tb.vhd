-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-- tests/drivers/axi_lite_loopback_tb.vhd
-- Minimal AXI-Lite register file testbench for BFM verification.
--
-- Exposes a 13-signal AXI-Lite slave interface. The cocotb testbench
-- instantiates our AxiLiteSlave in Python, so this entity only needs
-- to provide the wired-up ports; all behavior lives in Python.

library ieee;
use ieee.std_logic_1164.all;

entity axi_lite_loopback_tb is
  generic (
    G_DATA_WIDTH : integer := 32;
    G_ADDR_WIDTH : integer := 16
  );
  port (
    CLK          : in    std_logic;
    RST          : in    std_logic;

    -- Write Address Channel
    S_AXI_AWADDR  : inout std_logic_vector(G_ADDR_WIDTH-1 downto 0) := (others => '0');
    S_AXI_AWPROT  : inout std_logic_vector(2 downto 0) := (others => '0');
    S_AXI_AWVALID : inout std_logic := '0';
    S_AXI_AWREADY : inout std_logic := '0';

    -- Write Data Channel
    S_AXI_WDATA   : inout std_logic_vector(G_DATA_WIDTH-1 downto 0) := (others => '0');
    S_AXI_WSTRB   : inout std_logic_vector(G_DATA_WIDTH/8-1 downto 0) := (others => '0');
    S_AXI_WVALID  : inout std_logic := '0';
    S_AXI_WREADY  : inout std_logic := '0';

    -- Write Response Channel
    S_AXI_BRESP   : inout std_logic_vector(1 downto 0) := (others => '0');
    S_AXI_BVALID  : inout std_logic := '0';
    S_AXI_BREADY  : inout std_logic := '0';

    -- Read Address Channel
    S_AXI_ARADDR  : inout std_logic_vector(G_ADDR_WIDTH-1 downto 0) := (others => '0');
    S_AXI_ARPROT  : inout std_logic_vector(2 downto 0) := (others => '0');
    S_AXI_ARVALID : inout std_logic := '0';
    S_AXI_ARREADY : inout std_logic := '0';

    -- Read Data Channel
    S_AXI_RDATA   : inout std_logic_vector(G_DATA_WIDTH-1 downto 0) := (others => '0');
    S_AXI_RRESP   : inout std_logic_vector(1 downto 0) := (others => '0');
    S_AXI_RVALID  : inout std_logic := '0';
    S_AXI_RREADY  : inout std_logic := '0'
  );
end entity axi_lite_loopback_tb;

architecture rtl of axi_lite_loopback_tb is
begin
  -- All AXI-Lite behavior is driven from the cocotb Python testbench.
  -- This entity simply provides the signal wiring.
end architecture rtl;
