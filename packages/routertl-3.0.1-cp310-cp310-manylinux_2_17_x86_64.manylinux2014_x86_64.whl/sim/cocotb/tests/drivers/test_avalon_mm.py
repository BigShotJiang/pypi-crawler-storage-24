# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tests/drivers/test_avalon_mm.py
"""
Unit tests for the native Avalon-MM Master/Slave BFMs.

Tests verify Avalon-MM protocol handshaking, data integrity,
byte enables, waitrequest back-pressure, error responses,
and configurable read latency.

Run with:
    SIM=nvc python tests/drivers/test_avalon_mm.py
"""

import random
import sys
from pathlib import Path

import cocotb
from cocotb.triggers import ClockCycles

# Ensure SDK path is available
current_dir = Path(__file__).resolve().parent
sdk_cocotb_path = current_dir.parents[1]
sys.path.insert(0, str(sdk_cocotb_path))

from tb.drivers.avalon_mm import (
    AvalonMMBus,
    AvalonMMMaster,
    AvalonMMSlave,
    AvalonResp,
    AvalonRespError,
)
from tb.env import TbEnv

# =============================================================================
# Helpers
# =============================================================================


async def setup(dut, read_latency=0, waitrequest_cycles=0, error_addresses=None):
    """Create TbEnv, master, and slave; start clock and reset."""
    env = TbEnv(dut, clk="CLK", rst="RST", period_ns=10)
    await env.start_clock()
    await env.reset(cycles=5)

    master = AvalonMMMaster(env, prefix="AVL")
    slave = AvalonMMSlave(
        env,
        prefix="AVL",
        read_latency=read_latency,
        waitrequest_cycles=waitrequest_cycles,
        error_addresses=error_addresses,
    )
    cocotb.start_soon(slave.start())

    # Let everything settle after reset
    await ClockCycles(dut.CLK, 2)

    return env, master, slave


# =============================================================================
# Test Cases
# =============================================================================


@cocotb.test()
async def test_bus_signal_discovery(dut):
    """Verify AvalonMMBus resolves all 9 signals from the DUT."""
    dut._log.info("Testing Avalon-MM bus signal discovery...")

    bus = AvalonMMBus.from_prefix(dut, "AVL")

    # Check all signals are resolved (not None)
    assert bus.address is not None
    assert bus.read is not None
    assert bus.write is not None
    assert bus.writedata is not None
    assert bus.byteenable is not None
    assert bus.readdata is not None
    assert bus.readdatavalid is not None
    assert bus.waitrequest is not None
    assert bus.response is not None
    dut._log.info("✓ All 9 Avalon-MM signals resolved")


@cocotb.test()
async def test_single_write_read(dut):
    """Write one word, read it back, verify data integrity."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0xDEADBEEF)
    data, resp = await master.read(0x0000)

    assert data == 0xDEADBEEF, f"Expected 0xDEADBEEF, got 0x{data:08X}"
    assert resp == AvalonResp.OKAY

    env.log.info("✓ Single write/read verified")


@cocotb.test()
async def test_sequential_writes(dut):
    """Write 16 sequential addresses, read all back."""
    env, master, slave = await setup(dut)

    test_data = {i: 0x1000 + i for i in range(16)}

    # Write all
    for addr, data in test_data.items():
        await master.write(addr, data)

    # Read back and verify
    for addr, expected in test_data.items():
        data, resp = await master.read(addr)
        assert data == expected, f"@0x{addr:04X}: expected 0x{expected:08X}, got 0x{data:08X}"
        assert resp == AvalonResp.OKAY

    env.log.info("✓ 16 sequential write/read pairs verified")


@cocotb.test()
async def test_random_access(dut):
    """Random address/data patterns."""
    env, master, slave = await setup(dut)

    rng = random.Random(42)  # deterministic seed
    test_data = {}

    # Write 32 random locations (word-addressed for Avalon)
    for _ in range(32):
        addr = rng.randint(0, 0xFFFF)
        data = rng.randint(0, 0xFFFFFFFF)
        test_data[addr] = data
        await master.write(addr, data)

    # Read back (in different order)
    addrs = list(test_data.keys())
    rng.shuffle(addrs)
    for addr in addrs:
        data, resp = await master.read(addr)
        assert data == test_data[addr], f"@0x{addr:04X}: expected 0x{test_data[addr]:08X}, got 0x{data:08X}"

    env.log.info(f"✓ {len(test_data)} random write/read pairs verified")


@cocotb.test()
async def test_byteenable_byte0(dut):
    """Write with byte enable enabling only byte 0."""
    env, master, slave = await setup(dut)

    # Pre-fill with known data
    await master.write(0x0010, 0xFFFFFFFF)

    # Overwrite only byte 0
    await master.write(0x0010, 0x000000AA, byteenable=0x01)

    data, _ = await master.read(0x0010)
    assert data == 0xFFFFFFAA, f"Expected 0xFFFFFFAA, got 0x{data:08X}"

    env.log.info("✓ Byte enable (byte 0 only) verified")


@cocotb.test()
async def test_byteenable_partial(dut):
    """Write with byte enable enabling bytes 1 and 3."""
    env, master, slave = await setup(dut)

    # Pre-fill
    await master.write(0x0020, 0x11111111)

    # Overwrite bytes 1 and 3
    await master.write(0x0020, 0xAA00BB00, byteenable=0x0A)

    data, _ = await master.read(0x0020)
    assert data == 0xAA11BB11, f"Expected 0xAA11BB11, got 0x{data:08X}"

    env.log.info("✓ Byte enable (bytes 1,3) verified")


@cocotb.test()
async def test_waitrequest_backpressure(dut):
    """Verify write/read work with waitrequest stalls."""
    env, master, slave = await setup(dut, waitrequest_cycles=3)

    await master.write(0x0000, 0xCAFEBABE, timeout_ns=5000)
    data, resp = await master.read(0x0000, timeout_ns=5000)

    assert data == 0xCAFEBABE, f"Expected 0xCAFEBABE, got 0x{data:08X}"
    assert resp == AvalonResp.OKAY

    env.log.info("✓ Waitrequest backpressure (3 cycles) verified")


@cocotb.test()
async def test_read_latency(dut):
    """Verify reads with configurable latency."""
    env, master, slave = await setup(dut, read_latency=5)

    await master.write(0x0000, 0x12345678)
    data, resp = await master.read(0x0000, timeout_ns=5000)

    assert data == 0x12345678, f"Expected 0x12345678, got 0x{data:08X}"
    assert resp == AvalonResp.OKAY

    env.log.info("✓ Read latency (5 cycles) verified")


@cocotb.test()
async def test_combined_latency_and_backpressure(dut):
    """Waitrequest + read latency together."""
    env, master, slave = await setup(
        dut,
        read_latency=3,
        waitrequest_cycles=2,
    )

    await master.write(0x0040, 0xBEEFCAFE, timeout_ns=5000)
    data, resp = await master.read(0x0040, timeout_ns=5000)

    assert data == 0xBEEFCAFE, f"Expected 0xBEEFCAFE, got 0x{data:08X}"
    assert resp == AvalonResp.OKAY

    env.log.info("✓ Combined latency + backpressure verified")


@cocotb.test()
async def test_error_response(dut):
    """Verify SLVERR response from error addresses."""
    env, master, slave = await setup(
        dut,
        error_addresses={0x0BAD},
    )

    # Write to error address — should get SLVERR
    master.raise_on_resp = False
    resp = await master.write(0x0BAD, 0xDEAD)
    assert resp == AvalonResp.SLVERR, f"Expected SLVERR, got {resp.name}"

    # Read from error address — should get SLVERR
    _, resp = await master.read(0x0BAD)
    assert resp == AvalonResp.SLVERR, f"Expected SLVERR, got {resp.name}"

    env.log.info("✓ Error response (SLVERR) verified")


@cocotb.test()
async def test_error_raises(dut):
    """Verify AvalonRespError is raised when raise_on_resp=True."""
    env, master, slave = await setup(
        dut,
        error_addresses={0x0BAD},
    )

    try:
        await master.write(0x0BAD, 0xDEAD)
        assert False, "Should have raised AvalonRespError"
    except AvalonRespError as e:
        assert e.kind == "WR"
        assert e.addr == 0x0BAD
        assert e.resp == AvalonResp.SLVERR

    env.log.info("✓ AvalonRespError raised correctly")


@cocotb.test()
async def test_stats_tracking(dut):
    """Verify transaction statistics are tracked correctly."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0x1111)
    await master.write(0x0004, 0x2222)
    await master.read(0x0000)

    stats = master.get_stats()
    assert stats["num_writes"] == 2, f"Expected 2 writes, got {stats['num_writes']}"
    assert stats["num_reads"] == 1, f"Expected 1 read, got {stats['num_reads']}"
    assert stats["total_latency_ns"] > 0

    env.log.info(f"✓ Stats verified: {stats}")


@cocotb.test()
async def test_overwrite(dut):
    """Write to the same address twice, verify last write wins."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0x11111111)
    await master.write(0x0000, 0x22222222)

    data, _ = await master.read(0x0000)
    assert data == 0x22222222, f"Expected 0x22222222, got 0x{data:08X}"

    env.log.info("✓ Overwrite verified")


@cocotb.test()
async def test_address_boundary(dut):
    """Write/read at min and max addresses."""
    env, master, slave = await setup(dut)

    await master.write(0x0000, 0xAAAAAAAA)
    await master.write(0xFFFF, 0x55555555)

    data_min, _ = await master.read(0x0000)
    data_max, _ = await master.read(0xFFFF)

    assert data_min == 0xAAAAAAAA
    assert data_max == 0x55555555

    env.log.info("✓ Address boundary (min/max) verified")


# =============================================================================
# Standalone Execution Entry Point
# =============================================================================

if __name__ == "__main__":
    from pathlib import Path

    from engine.simulation import run_simulation

    run_simulation(
        top_level="avalon_loopback_tb",
        module="test_avalon_mm",
        top_level_lang="vhdl",
        waves=True,
        verbose=True,
        work_lib="work",
        custom_libraries={
            "work": [
                str(Path(__file__).parent / "avalon_loopback_tb.vhd"),
            ]
        },
    )
