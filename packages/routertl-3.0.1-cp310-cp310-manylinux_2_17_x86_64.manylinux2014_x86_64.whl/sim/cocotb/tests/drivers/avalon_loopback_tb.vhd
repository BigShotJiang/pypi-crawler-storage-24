-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-- tests/drivers/avalon_loopback_tb.vhd
-- Minimal Avalon-MM interface testbench for BFM verification.
--
-- Exposes a 9-signal Avalon-MM slave interface. The cocotb testbench
-- instantiates our AvalonMMSlave in Python, so this entity only needs
-- to provide the wired-up ports; all behavior lives in Python.

library ieee;
use ieee.std_logic_1164.all;

entity avalon_loopback_tb is
  generic (
    G_DATA_WIDTH : integer := 32;
    G_ADDR_WIDTH : integer := 16
  );
  port (
    CLK              : in    std_logic;
    RST              : in    std_logic;

    -- Command channel (master → slave)
    AVL_ADDRESS      : inout std_logic_vector(G_ADDR_WIDTH-1 downto 0)   := (others => '0');
    AVL_READ         : inout std_logic := '0';
    AVL_WRITE        : inout std_logic := '0';
    AVL_WRITEDATA    : inout std_logic_vector(G_DATA_WIDTH-1 downto 0)   := (others => '0');
    AVL_BYTEENABLE   : inout std_logic_vector(G_DATA_WIDTH/8-1 downto 0) := (others => '1');

    -- Response channel (slave → master)
    AVL_READDATA     : inout std_logic_vector(G_DATA_WIDTH-1 downto 0) := (others => '0');
    AVL_READDATAVALID: inout std_logic := '0';
    AVL_WAITREQUEST  : inout std_logic := '0';
    AVL_RESPONSE     : inout std_logic_vector(1 downto 0) := (others => '0')
  );
end entity avalon_loopback_tb;

architecture rtl of avalon_loopback_tb is
begin
  -- All Avalon-MM behavior is driven from the cocotb Python testbench.
  -- This entity simply provides the signal wiring.
end architecture rtl;
