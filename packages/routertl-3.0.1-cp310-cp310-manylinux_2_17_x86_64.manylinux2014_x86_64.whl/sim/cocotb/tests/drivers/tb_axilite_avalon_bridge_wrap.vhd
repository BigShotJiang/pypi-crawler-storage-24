-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-- tests/drivers/tb_axilite_avalon_bridge_wrap.vhd
-- Testbench wrapper for AXI-Lite → Avalon-MM bridge.
--
-- Instantiates the generated bridge DUT and exposes all I/O
-- signals as top-level inout ports for cocotb to drive/sample.
--
-- IMPORTANT: No default values on inout ports! The port's default
-- drive would conflict with cocotb's drive through std_logic
-- resolution ('0' and '1' → 'X').

library ieee;
use ieee.std_logic_1164.all;

entity tb_axilite_avalon_bridge_wrap is
  port (
    CLK              : in    std_logic;
    RST_N            : in    std_logic;

    -- === AXI-Lite interface ===
    -- Master → Bridge (driven by cocotb)
    S_AWADDR         : inout std_logic_vector(15 downto 0);
    S_AWPROT         : inout std_logic_vector(2 downto 0);
    S_AWVALID        : inout std_logic;
    S_WDATA          : inout std_logic_vector(31 downto 0);
    S_WSTRB          : inout std_logic_vector(3 downto 0);
    S_WVALID         : inout std_logic;
    S_BREADY         : inout std_logic;
    S_ARADDR         : inout std_logic_vector(15 downto 0);
    S_ARPROT         : inout std_logic_vector(2 downto 0);
    S_ARVALID        : inout std_logic;
    S_RREADY         : inout std_logic;

    -- Bridge → Master (driven by bridge DUT, read by cocotb)
    S_AWREADY        : inout std_logic;
    S_WREADY         : inout std_logic;
    S_BRESP          : inout std_logic_vector(1 downto 0);
    S_BVALID         : inout std_logic;
    S_ARREADY        : inout std_logic;
    S_RDATA          : inout std_logic_vector(31 downto 0);
    S_RRESP          : inout std_logic_vector(1 downto 0);
    S_RVALID         : inout std_logic;

    -- === Avalon-MM interface ===
    -- Bridge → Slave (driven by bridge DUT, read by cocotb)
    M_AVL_ADDRESS       : inout std_logic_vector(13 downto 0);
    M_AVL_READ          : inout std_logic;
    M_AVL_WRITE         : inout std_logic;
    M_AVL_WRITEDATA     : inout std_logic_vector(31 downto 0);
    M_AVL_BYTEENABLE    : inout std_logic_vector(3 downto 0);

    -- Slave → Bridge (driven by cocotb)
    M_AVL_READDATA      : inout std_logic_vector(31 downto 0);
    M_AVL_READDATAVALID : inout std_logic;
    M_AVL_WAITREQUEST   : inout std_logic;
    M_AVL_RESPONSE      : inout std_logic_vector(1 downto 0)
  );
end entity tb_axilite_avalon_bridge_wrap;

architecture rtl of tb_axilite_avalon_bridge_wrap is

  -- Internal signals for bridge DUT outputs
  signal s_awready_i     : std_logic;
  signal s_wready_i      : std_logic;
  signal s_bresp_i       : std_logic_vector(1 downto 0);
  signal s_bvalid_i      : std_logic;
  signal s_arready_i     : std_logic;
  signal s_rdata_i       : std_logic_vector(31 downto 0);
  signal s_rresp_i       : std_logic_vector(1 downto 0);
  signal s_rvalid_i      : std_logic;
  signal m_avl_address_i    : std_logic_vector(13 downto 0);
  signal m_avl_read_i       : std_logic;
  signal m_avl_write_i      : std_logic;
  signal m_avl_writedata_i  : std_logic_vector(31 downto 0);
  signal m_avl_byteenable_i : std_logic_vector(3 downto 0);

begin

  u_bridge : entity work.tb_axilite_avalon_bridge
    port map (
      clk                 => CLK,
      rst_n               => RST_N,
      -- AXI-Lite slave side inputs (cocotb → bridge)
      s_awaddr            => S_AWADDR,
      s_awprot            => S_AWPROT,
      s_awvalid           => S_AWVALID,
      s_wdata             => S_WDATA,
      s_wstrb             => S_WSTRB,
      s_wvalid            => S_WVALID,
      s_bready            => S_BREADY,
      s_araddr            => S_ARADDR,
      s_arprot            => S_ARPROT,
      s_arvalid           => S_ARVALID,
      s_rready            => S_RREADY,
      -- AXI-Lite slave side outputs (bridge → internal)
      s_awready           => s_awready_i,
      s_wready            => s_wready_i,
      s_bresp             => s_bresp_i,
      s_bvalid            => s_bvalid_i,
      s_arready           => s_arready_i,
      s_rdata             => s_rdata_i,
      s_rresp             => s_rresp_i,
      s_rvalid            => s_rvalid_i,
      -- Avalon-MM master side outputs (bridge → internal)
      m_avl_address       => m_avl_address_i,
      m_avl_read          => m_avl_read_i,
      m_avl_write         => m_avl_write_i,
      m_avl_writedata     => m_avl_writedata_i,
      m_avl_byteenable    => m_avl_byteenable_i,
      -- Avalon-MM master side inputs (cocotb → bridge)
      m_avl_readdata      => M_AVL_READDATA,
      m_avl_readdatavalid => M_AVL_READDATAVALID,
      m_avl_waitrequest   => M_AVL_WAITREQUEST,
      m_avl_response      => M_AVL_RESPONSE
    );

  -- Forward bridge outputs to top-level inout ports
  S_AWREADY        <= s_awready_i;
  S_WREADY         <= s_wready_i;
  S_BRESP          <= s_bresp_i;
  S_BVALID         <= s_bvalid_i;
  S_ARREADY        <= s_arready_i;
  S_RDATA          <= s_rdata_i;
  S_RRESP          <= s_rresp_i;
  S_RVALID         <= s_rvalid_i;
  M_AVL_ADDRESS    <= m_avl_address_i;
  M_AVL_READ       <= m_avl_read_i;
  M_AVL_WRITE      <= m_avl_write_i;
  M_AVL_WRITEDATA  <= m_avl_writedata_i;
  M_AVL_BYTEENABLE <= m_avl_byteenable_i;

end architecture rtl;
