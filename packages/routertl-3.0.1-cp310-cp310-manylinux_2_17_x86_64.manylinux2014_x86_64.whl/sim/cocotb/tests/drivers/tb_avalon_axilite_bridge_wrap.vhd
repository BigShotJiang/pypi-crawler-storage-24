-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-- tests/drivers/tb_avalon_axilite_bridge_wrap.vhd
-- Testbench wrapper for Avalon-MM → AXI-Lite bridge.
--
-- Instantiates the generated bridge DUT and exposes all I/O
-- signals as top-level inout ports for cocotb to drive/sample.
--
-- IMPORTANT: No default values on inout ports! The port's default
-- drive would conflict with cocotb's drive through std_logic
-- resolution ('0' and '1' → 'X').

library ieee;
use ieee.std_logic_1164.all;

entity tb_avalon_axilite_bridge_wrap is
  port (
    CLK              : in    std_logic;
    RST_N            : in    std_logic;

    -- === Avalon-MM interface (slave side — driven by cocotb master) ===
    S_AVL_ADDRESS       : inout std_logic_vector(13 downto 0);
    S_AVL_READ          : inout std_logic;
    S_AVL_WRITE         : inout std_logic;
    S_AVL_WRITEDATA     : inout std_logic_vector(31 downto 0);
    S_AVL_BYTEENABLE    : inout std_logic_vector(3 downto 0);

    -- Bridge → Avalon master (driven by DUT, read by cocotb)
    S_AVL_READDATA      : inout std_logic_vector(31 downto 0);
    S_AVL_READDATAVALID : inout std_logic;
    S_AVL_WAITREQUEST   : inout std_logic;
    S_AVL_RESPONSE      : inout std_logic_vector(1 downto 0);

    -- === AXI-Lite interface (master side — driven by DUT) ===
    -- Bridge → AXI slave (driven by DUT, read by cocotb slave BFM)
    M_AXI_AWADDR        : inout std_logic_vector(15 downto 0);
    M_AXI_AWPROT        : inout std_logic_vector(2 downto 0);
    M_AXI_AWVALID       : inout std_logic;
    M_AXI_WDATA         : inout std_logic_vector(31 downto 0);
    M_AXI_WSTRB         : inout std_logic_vector(3 downto 0);
    M_AXI_WVALID        : inout std_logic;
    M_AXI_BREADY        : inout std_logic;
    M_AXI_ARADDR        : inout std_logic_vector(15 downto 0);
    M_AXI_ARPROT        : inout std_logic_vector(2 downto 0);
    M_AXI_ARVALID       : inout std_logic;
    M_AXI_RREADY        : inout std_logic;

    -- AXI slave → Bridge (driven by cocotb slave BFM)
    M_AXI_AWREADY       : inout std_logic;
    M_AXI_WREADY        : inout std_logic;
    M_AXI_BRESP         : inout std_logic_vector(1 downto 0);
    M_AXI_BVALID        : inout std_logic;
    M_AXI_ARREADY       : inout std_logic;
    M_AXI_RDATA         : inout std_logic_vector(31 downto 0);
    M_AXI_RRESP         : inout std_logic_vector(1 downto 0);
    M_AXI_RVALID        : inout std_logic
  );
end entity tb_avalon_axilite_bridge_wrap;

architecture rtl of tb_avalon_axilite_bridge_wrap is

  -- Internal signals for bridge DUT outputs
  -- Avalon slave outputs
  signal s_avl_readdata_i      : std_logic_vector(31 downto 0);
  signal s_avl_readdatavalid_i : std_logic;
  signal s_avl_waitrequest_i   : std_logic;
  signal s_avl_response_i      : std_logic_vector(1 downto 0);
  -- AXI master outputs
  signal m_axi_awaddr_i    : std_logic_vector(15 downto 0);
  signal m_axi_awprot_i    : std_logic_vector(2 downto 0);
  signal m_axi_awvalid_i   : std_logic;
  signal m_axi_wdata_i     : std_logic_vector(31 downto 0);
  signal m_axi_wstrb_i     : std_logic_vector(3 downto 0);
  signal m_axi_wvalid_i    : std_logic;
  signal m_axi_bready_i    : std_logic;
  signal m_axi_araddr_i    : std_logic_vector(15 downto 0);
  signal m_axi_arprot_i    : std_logic_vector(2 downto 0);
  signal m_axi_arvalid_i   : std_logic;
  signal m_axi_rready_i    : std_logic;

begin

  u_bridge : entity work.tb_avalon_axilite_bridge
    port map (
      clk                 => CLK,
      rst_n               => RST_N,
      -- Avalon-MM slave side inputs (cocotb → bridge)
      s_avl_address       => S_AVL_ADDRESS,
      s_avl_read          => S_AVL_READ,
      s_avl_write         => S_AVL_WRITE,
      s_avl_writedata     => S_AVL_WRITEDATA,
      s_avl_byteenable    => S_AVL_BYTEENABLE,
      -- Avalon-MM slave side outputs (bridge → internal)
      s_avl_readdata      => s_avl_readdata_i,
      s_avl_readdatavalid => s_avl_readdatavalid_i,
      s_avl_waitrequest   => s_avl_waitrequest_i,
      s_avl_response      => s_avl_response_i,
      -- AXI-Lite master side outputs (bridge → internal)
      m_axi_awaddr        => m_axi_awaddr_i,
      m_axi_awprot        => m_axi_awprot_i,
      m_axi_awvalid       => m_axi_awvalid_i,
      m_axi_wdata         => m_axi_wdata_i,
      m_axi_wstrb         => m_axi_wstrb_i,
      m_axi_wvalid        => m_axi_wvalid_i,
      m_axi_bready        => m_axi_bready_i,
      m_axi_araddr        => m_axi_araddr_i,
      m_axi_arprot        => m_axi_arprot_i,
      m_axi_arvalid       => m_axi_arvalid_i,
      m_axi_rready        => m_axi_rready_i,
      -- AXI-Lite master side inputs (cocotb slave BFM → bridge)
      m_axi_awready       => M_AXI_AWREADY,
      m_axi_wready        => M_AXI_WREADY,
      m_axi_bresp         => M_AXI_BRESP,
      m_axi_bvalid        => M_AXI_BVALID,
      m_axi_arready       => M_AXI_ARREADY,
      m_axi_rdata         => M_AXI_RDATA,
      m_axi_rresp         => M_AXI_RRESP,
      m_axi_rvalid        => M_AXI_RVALID
    );

  -- Forward bridge outputs to top-level inout ports
  S_AVL_READDATA      <= s_avl_readdata_i;
  S_AVL_READDATAVALID <= s_avl_readdatavalid_i;
  S_AVL_WAITREQUEST   <= s_avl_waitrequest_i;
  S_AVL_RESPONSE      <= s_avl_response_i;
  M_AXI_AWADDR        <= m_axi_awaddr_i;
  M_AXI_AWPROT        <= m_axi_awprot_i;
  M_AXI_AWVALID       <= m_axi_awvalid_i;
  M_AXI_WDATA         <= m_axi_wdata_i;
  M_AXI_WSTRB         <= m_axi_wstrb_i;
  M_AXI_WVALID        <= m_axi_wvalid_i;
  M_AXI_BREADY        <= m_axi_bready_i;
  M_AXI_ARADDR        <= m_axi_araddr_i;
  M_AXI_ARPROT        <= m_axi_arprot_i;
  M_AXI_ARVALID       <= m_axi_arvalid_i;
  M_AXI_RREADY        <= m_axi_rready_i;

end architecture rtl;
