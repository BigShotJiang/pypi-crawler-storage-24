# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import sys
from pathlib import Path

import cocotb
from cocotbext.axi import AxiLiteBus as ExternalAxiLiteBus
from cocotbext.axi import AxiLiteMaster as ExternalAxiLiteMaster
from cocotbext.axi import AxiLiteRam as ExternalAxiLiteRam

# Ensure SDK path is available
current_dir = Path(__file__).resolve().parent
sdk_cocotb_path = current_dir.parents[1]
sys.path.insert(0, str(sdk_cocotb_path))

from tb.drivers.axi_lite import AxiLiteMaster, AxiLiteSlave
from tb.env import TbEnv


async def setup_crosscheck(dut):
    """Setup a TbEnv and a clock."""
    env = TbEnv(dut, clk="CLK", rst="RST", period_ns=10)
    await env.start_clock()
    await env.reset(cycles=5)
    return env


@cocotb.test()
async def test_our_master_external_slave(dut):
    """Cross-check: Our AxiLiteMaster driving cocotbext-axi AxiLiteRam."""
    env = await setup_crosscheck(dut)

    # 1. Instantiate cocotbext-axi RAM
    # It needs its own Bus object. We use the same signals via DUT handle.
    ext_bus = ExternalAxiLiteBus.from_prefix(dut, "S_AXI")
    ram = ExternalAxiLiteRam(ext_bus, dut.CLK, dut.RST, size=1024)

    # 2. Instantiate our Master
    master = AxiLiteMaster(env, prefix="S_AXI")

    # 3. Perform transactions
    await master.write(0x10, 0x12345678)
    data, resp = await master.read(0x10)

    assert data == 0x12345678
    assert resp.name == "OKAY"

    # Partial write
    await master.write_masked(0x10, 0x0000ABCD, strb=0x3)  # lower halfword
    data, _ = await master.read(0x10)
    assert data == 0x1234ABCD

    env.log.info("✓ Cross-check: Our Master -> External RAM passed")


@cocotb.test()
async def test_external_master_our_slave(dut):
    """Cross-check: cocotbext-axi AxiLiteMaster driving our AxiLiteSlave."""
    env = await setup_crosscheck(dut)

    # 1. Instantiate our Slave
    slave = AxiLiteSlave(env, prefix="S_AXI")
    cocotb.start_soon(slave.start())

    # 2. Instantiate cocotbext-axi Master
    ext_bus = ExternalAxiLiteBus.from_prefix(dut, "S_AXI")
    master = ExternalAxiLiteMaster(ext_bus, dut.CLK, dut.RST)

    # 3. Perform transactions using external master
    await master.write(0x20, b"\xde\xad\xbe\xef")
    data = await master.read(0x20, 4)
    assert data.data == b"\xde\xad\xbe\xef"

    # Check slave memory directly
    assert slave.get_memory(0x20) == 0xEFBEADDE  # cocotbext-axi uses bytes

    env.log.info("✓ Cross-check: External Master -> Our Slave passed")


@cocotb.test()
async def test_simultaneous_masters(dut):
    """Mixed: Verify our master and external master can exist (though not simultaneously driving same signals)."""
    # This is more of a sanity check that they don't fight over the same DUT signals
    # if we are careful. Actually, they WILL fight if we attach both to "S_AXI".
    # So we don't do that. We already verified interoperability above.
    pass


if __name__ == "__main__":
    from pathlib import Path

    from engine.simulation import run_simulation

    run_simulation(
        top_level="axi_lite_loopback_tb",
        module="test_axi_lite_crosscheck",
        top_level_lang="vhdl",
        waves=True,
        verbose=True,
        work_lib="work",
        custom_libraries={
            "work": [
                str(Path(__file__).parent / "axi_lite_loopback_tb.vhd"),
            ]
        },
    )
