# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tests/drivers/test_spi_driver.py
"""
Unit tests for the native SPI Master/Slave drivers.

Tests verify SPI protocol timing, all 4 modes (CPOL/CPHA combinations),
and data integrity for various word widths.

Run with:
    SIM=nvc python tests/drivers/test_spi_driver.py
"""

import sys
from pathlib import Path

import cocotb
from cocotb.triggers import Timer

# Ensure SDK path is available
current_dir = Path(__file__).resolve().parent
sdk_cocotb_path = current_dir.parents[1]
sys.path.insert(0, str(sdk_cocotb_path))

from tb.drivers.spi_master import SpiBus, SpiConfig, SpiMaster

# =============================================================================
# Test Cases
# =============================================================================


@cocotb.test()
async def test_spi_config_timing(dut):
    """Verify SpiConfig timing calculations."""
    dut._log.info("Testing SpiConfig timing calculations...")

    # 1 MHz
    cfg_1mhz = SpiConfig(sclk_freq=1_000_000)
    assert cfg_1mhz.period_ns == 1000, f"Expected 1000ns period, got {cfg_1mhz.period_ns}"
    assert cfg_1mhz.half_period_ns == 500, f"Expected 500ns half-period, got {cfg_1mhz.half_period_ns}"

    # 10 MHz
    cfg_10mhz = SpiConfig(sclk_freq=10_000_000)
    assert cfg_10mhz.period_ns == 100, f"Expected 100ns period, got {cfg_10mhz.period_ns}"
    assert cfg_10mhz.half_period_ns == 50, f"Expected 50ns half-period, got {cfg_10mhz.half_period_ns}"

    # 25 MHz
    cfg_25mhz = SpiConfig(sclk_freq=25_000_000)
    assert cfg_25mhz.period_ns == 40, f"Expected 40ns period, got {cfg_25mhz.period_ns}"

    dut._log.info("✓ SpiConfig timing calculations verified")


@cocotb.test()
async def test_spi_config_cs_polarity(dut):
    """Verify CS polarity settings."""
    dut._log.info("Testing CS polarity...")

    # Active low (default)
    cfg_low = SpiConfig(cs_active_low=True)
    assert cfg_low.cs_assert_value == 0, "CS active low should assert to 0"
    assert cfg_low.cs_deassert_value == 1, "CS active low should deassert to 1"

    # Active high
    cfg_high = SpiConfig(cs_active_low=False)
    assert cfg_high.cs_assert_value == 1, "CS active high should assert to 1"
    assert cfg_high.cs_deassert_value == 0, "CS active high should deassert to 0"

    dut._log.info("✓ CS polarity verified")


@cocotb.test()
async def test_spi_bus_creation(dut):
    """Verify SpiBus can be created from entity."""
    dut._log.info("Testing SpiBus creation...")

    # Create from entity (should find SCLK, MOSI, MISO, CS)
    try:
        bus = SpiBus.from_entity(dut)
        dut._log.info(f"Created SpiBus: sclk={bus.sclk}, mosi={bus.mosi}, miso={bus.miso}, cs={bus.cs}")
        assert bus.sclk is not None, "SCLK should be found"
    except AttributeError as e:
        dut._log.info(f"Expected: Could not create SpiBus from minimal TB: {e}")

    dut._log.info("✓ SpiBus creation test completed")


@cocotb.test()
async def test_spi_master_mode0_single_byte(dut):
    """Test SPI Mode 0 (CPOL=0, CPHA=0) single byte transfer."""
    dut._log.info("Testing SPI Mode 0 single byte...")

    # Create bus manually
    bus = SpiBus(
        sclk=dut.SCLK,
        mosi=dut.MOSI,
        miso=dut.MISO,
        cs=dut.CS,
    )

    config = SpiConfig(
        word_width=8,
        sclk_freq=1_000_000,
        cpol=False,
        cpha=False,
        msb_first=True,
    )

    master = SpiMaster(bus, config)

    # Verify initial state
    assert dut.SCLK.value == 0, "SCLK should be idle low (CPOL=0)"
    assert dut.CS.value == 1, "CS should be deasserted (high)"

    # Write a byte
    await master.write([0xA5])

    # Verify return to idle
    assert dut.SCLK.value == 0, "SCLK should return to idle low"
    assert dut.CS.value == 1, "CS should be deasserted"

    dut._log.info("✓ SPI Mode 0 single byte transfer completed")


@cocotb.test()
async def test_spi_master_mode1(dut):
    """Test SPI Mode 1 (CPOL=0, CPHA=1)."""
    dut._log.info("Testing SPI Mode 1...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=8,
        sclk_freq=1_000_000,
        cpol=False,
        cpha=True,  # Mode 1
    )

    master = SpiMaster(bus, config)

    # SCLK should still be idle low
    assert dut.SCLK.value == 0, "SCLK should be idle low (CPOL=0)"

    await master.write([0x55])

    assert dut.SCLK.value == 0, "SCLK should return to idle low"

    dut._log.info("✓ SPI Mode 1 transfer completed")


@cocotb.test()
async def test_spi_master_mode2(dut):
    """Test SPI Mode 2 (CPOL=1, CPHA=0)."""
    dut._log.info("Testing SPI Mode 2...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=8,
        sclk_freq=1_000_000,
        cpol=True,  # Mode 2
        cpha=False,
    )

    master = SpiMaster(bus, config)
    await Timer(1, "ns")  # Wait for signal initialization to propagate

    # SCLK should be idle high
    assert dut.SCLK.value == 1, "SCLK should be idle high (CPOL=1)"

    await master.write([0xAA])

    assert dut.SCLK.value == 1, "SCLK should return to idle high"

    dut._log.info("✓ SPI Mode 2 transfer completed")


@cocotb.test()
async def test_spi_master_mode3(dut):
    """Test SPI Mode 3 (CPOL=1, CPHA=1)."""
    dut._log.info("Testing SPI Mode 3...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=8,
        sclk_freq=1_000_000,
        cpol=True,
        cpha=True,  # Mode 3
    )

    master = SpiMaster(bus, config)
    await Timer(1, "ns")  # Wait for signal initialization to propagate

    assert dut.SCLK.value == 1, "SCLK should be idle high (CPOL=1)"

    await master.write([0x33])

    assert dut.SCLK.value == 1, "SCLK should return to idle high"

    dut._log.info("✓ SPI Mode 3 transfer completed")


@cocotb.test()
async def test_spi_master_16bit(dut):
    """Test 16-bit word width."""
    dut._log.info("Testing 16-bit SPI transfer...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=16,
        sclk_freq=1_000_000,
        cpol=False,
        cpha=False,
    )

    master = SpiMaster(bus, config)

    await master.write([0xABCD])

    dut._log.info("✓ 16-bit SPI transfer completed")


@cocotb.test()
async def test_spi_master_18bit(dut):
    """Test 18-bit word width (as used in test_system_top.py)."""
    dut._log.info("Testing 18-bit SPI transfer...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=18,
        sclk_freq=5_000_000,
        cpol=False,
        cpha=False,
        msb_first=True,
    )

    master = SpiMaster(bus, config)

    # Test with max 18-bit value
    await master.write([0x1FFFF])

    # Test with negative (2's complement)
    await master.write([0x20001])

    dut._log.info("✓ 18-bit SPI transfer completed")


@cocotb.test()
async def test_spi_master_multi_word(dut):
    """Test multi-word transfer."""
    dut._log.info("Testing multi-word SPI transfer...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=8,
        sclk_freq=1_000_000,
    )

    master = SpiMaster(bus, config)

    # Multiple bytes
    await master.write([0xDE, 0xAD, 0xBE, 0xEF])

    dut._log.info("✓ Multi-word SPI transfer completed")


@cocotb.test()
async def test_spi_master_write_nowait(dut):
    """Test non-blocking write."""
    dut._log.info("Testing non-blocking write_nowait...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=8,
        sclk_freq=1_000_000,
    )

    master = SpiMaster(bus, config)

    # Queue writes
    master.write_nowait([0xAA, 0x55])

    # Wait for completion
    await Timer(50, unit="us")

    dut._log.info("✓ Non-blocking write completed")


@cocotb.test()
async def test_spi_master_lsb_first(dut):
    """Test LSB-first transmission."""
    dut._log.info("Testing LSB-first transmission...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=8,
        sclk_freq=1_000_000,
        msb_first=False,  # LSB first
    )

    master = SpiMaster(bus, config)

    await master.write([0x01])  # Should shift out LSB (1) first

    dut._log.info("✓ LSB-first transmission completed")


@cocotb.test()
async def test_spi_master_cs_active_high(dut):
    """Test CS active high polarity."""
    dut._log.info("Testing CS active high...")

    bus = SpiBus(sclk=dut.SCLK, mosi=dut.MOSI, miso=dut.MISO, cs=dut.CS)

    config = SpiConfig(
        word_width=8,
        sclk_freq=1_000_000,
        cs_active_low=False,  # Active high
    )

    master = SpiMaster(bus, config)
    await Timer(1, "ns")  # Wait for signal initialization to propagate

    # CS should be deasserted (0 for active high)
    assert dut.CS.value == 0, "CS should be deasserted (0) for active high"

    await master.write([0xFF])

    assert dut.CS.value == 0, "CS should return to deasserted"

    dut._log.info("✓ CS active high test completed")


# =============================================================================
# Standalone Execution Entry Point
# =============================================================================

if __name__ == "__main__":
    from pathlib import Path

    from engine.simulation import run_simulation

    run_simulation(
        top_level="spi_loopback_tb",
        module="test_spi_master",
        top_level_lang="vhdl",
        waves=True,
        verbose=True,
        work_lib="work",
        custom_libraries={
            "work": [
                str(Path(__file__).parent / "spi_loopback_tb.vhd"),
            ]
        },
    )
