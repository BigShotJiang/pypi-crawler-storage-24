# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import subprocess
import sys
from pathlib import Path

# Ensure SDK path is available
current_dir = Path(__file__).resolve().parent
# current_dir is .../sim/cocotb/tests/drivers
sdk_root = current_dir.parent.parent.parent.parent

# Fix namespace shadowing: the SDK's sim/ directory contains cocotb/__init__.py
# which shadows the real cocotb package. Remove ONLY the SDK sim/ path.
sdk_sim_dir = str((sdk_root / "sim").resolve())
sys.path = [p for p in sys.path if str(Path(p).resolve()) != sdk_sim_dir]
sys.path.insert(0, str(current_dir))  # Ensure we can find sister test files

# Reuse the test cases from the VHDL version
from test_axilite_avalon_bridge import *

if __name__ == "__main__":
    from engine.simulation import run_simulation

    # 1. Generate the SV bridge
    bridge_gen_py = sdk_root / "sdk" / "generators" / "bridge" / "main.py"
    generated_sv = current_dir / "tb_axilite_avalon_bridge.sv"

    print(f"Generating SV bridge: {generated_sv}")
    subprocess.run(
        [
            sys.executable,
            str(bridge_gen_py),
            "--protocol",
            "axilite",
            "--target-protocol",
            "avalon",
            "--addr-width",
            "16",
            "--data-width",
            "32",
            "--lang",
            "sv",
            "--output",
            str(generated_sv),
        ],
        check=True,
    )

    # 2. Run simulation with Verilator
    run_simulation(
        top_level="tb_axilite_avalon_bridge_wrap",
        module="test_axilite_avalon_bridge",
        top_level_lang="verilog",  # Verilator uses Verilog/SV
        waves=True,
        verbose=True,
        simulator="verilator",
        custom_libraries={},  # Clear default VHDL libraries for Verilator
        hdl_sources=[
            str(generated_sv),
            str(current_dir / "tb_axilite_avalon_bridge_wrap.sv"),
        ],
    )
