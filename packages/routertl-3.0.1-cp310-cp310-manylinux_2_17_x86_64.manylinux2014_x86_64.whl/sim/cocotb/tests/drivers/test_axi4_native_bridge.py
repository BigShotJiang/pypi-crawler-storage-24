# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tests/drivers/test_axi4_native_bridge.py
"""
End-to-end cocotb simulation for the AXI4 -> Native Memory bridge.

Wires an Axi4Master on the AXI4 side and a NativeMemSlave on the Memory side.
"""

import subprocess
import sys
from pathlib import Path

import cocotb
from cocotb.triggers import ClockCycles

current_dir = Path(__file__).resolve().parent
sdk_cocotb_path = current_dir.parents[1]
sys.path.insert(0, str(sdk_cocotb_path))

from tb.drivers.axi4 import Axi4Master, AxiResp
from tb.drivers.native_mem import NativeMemSlave
from tb.env import TbEnv


async def setup(dut, read_latency=0):
    env = TbEnv(dut, clk="CLK", rst="RST_N", period_ns=10)
    await env.start_clock()

    import logging

    env.log.setLevel(logging.DEBUG)

    await env.reset(cycles=5, active_low=True)

    master = Axi4Master(env, prefix="S", raise_on_resp=False)
    slave = NativeMemSlave(
        env,
        prefix="M_MEM",
        read_latency=read_latency,
    )
    cocotb.start_soon(slave.start())

    await ClockCycles(dut.CLK, 2)
    return env, master, slave


@cocotb.test()
async def test_single_write_read(dut):
    dut._log.info("=== test_single_write_read ===")
    env, master, slave = await setup(dut)

    await master.write(0x100, [0xDEADBEEF])
    data, resp = await master.read(0x100, beats=1)

    assert data[0] == 0xDEADBEEF, f"Got 0x{data[0]:08X}"
    assert resp == AxiResp.OKAY


@cocotb.test()
async def test_burst_write_read(dut):
    dut._log.info("=== test_burst_write_read ===")
    env, master, slave = await setup(dut)

    test_data = [0xA1B2C3D4, 0x11223344, 0x55667788, 0x99AABBCC]
    # Write a burst of 4 to address 0x200
    await master.write(0x200, test_data)

    # Read burst of 4 from 0x200
    data, resp = await master.read(0x200, beats=4)

    assert resp == AxiResp.OKAY
    for i in range(4):
        assert data[i] == test_data[i]


@cocotb.test()
async def test_byte_strobe(dut):
    dut._log.info("=== test_byte_strobe ===")
    env, master, slave = await setup(dut)

    await master.write(0x300, [0xFFFFFFFF])
    await master.write(0x300, [0x000000AA], strb=[0x1])

    data, _ = await master.read(0x300, beats=1)
    assert data[0] == 0xFFFFFFAA


@cocotb.test()
async def test_read_latency(dut):
    dut._log.info("=== test_read_latency ===")
    env, master, slave = await setup(dut, read_latency=1)

    test_data = [0x54545454, 0x65656565]
    await master.write(0x400, test_data)
    data, resp = await master.read(0x400, beats=2)

    assert resp == AxiResp.OKAY
    assert len(data) == 2
    assert data[0] == 0x54545454
    assert data[1] == 0x65656565


if __name__ == "__main__":
    from engine.simulation import run_simulation

    sdk_root = current_dir.parent.parent.parent.parent
    bridge_gen_py = sdk_root / "sdk" / "generators" / "bridge" / "main.py"
    generated_sv = current_dir / "tb_axi4_native_bridge.sv"

    print(f"Generating SV bridge: {generated_sv}")
    subprocess.run(
        [
            sys.executable,
            str(bridge_gen_py),
            "--protocol",
            "axi4",
            "--target-protocol",
            "native",
            "--addr-width",
            "16",
            "--data-width",
            "32",
            "--id-width",
            "4",
            "--prefix",
            "s_axi",
            "--lang",
            "sv",
            "--output",
            str(generated_sv),
        ],
        check=True,
    )

    run_simulation(
        top_level="tb_axi4_native_bridge_wrap",
        module="test_axi4_native_bridge",
        top_level_lang="verilog",
        waves=True,
        verbose=True,
        simulator="verilator",
        custom_libraries={},
        hdl_sources=[
            str(generated_sv),
            str(current_dir / "tb_axi4_native_bridge_wrap.sv"),
        ],
    )
