-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-- ====================================================================
-- Auto-generated VHDL — DO NOT EDIT
-- Generated: 2026-02-19 16:47:53 UTC
-- Parameters:
--   Base Address: 0
--   Data Width: 32
--   Protocol: avalon
-- ====================================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_avalon_axilite_bridge is
    port (
        clk                     : in  std_logic;
        rst_n                   : in  std_logic;
        s_avl_address           : in  std_logic_vector(13 downto 0);
        s_avl_read              : in  std_logic;
        s_avl_write             : in  std_logic;
        s_avl_writedata         : in  std_logic_vector(31 downto 0);
        s_avl_byteenable        : in  std_logic_vector(3 downto 0);
        m_axi_awready           : in  std_logic;
        m_axi_wready            : in  std_logic;
        m_axi_bresp             : in  std_logic_vector(1 downto 0);
        m_axi_bvalid            : in  std_logic;
        m_axi_arready           : in  std_logic;
        m_axi_rdata             : in  std_logic_vector(31 downto 0);
        m_axi_rresp             : in  std_logic_vector(1 downto 0);
        m_axi_rvalid            : in  std_logic;
        s_avl_readdata          : out std_logic_vector(31 downto 0);
        s_avl_readdatavalid     : out std_logic;
        s_avl_waitrequest       : out std_logic;
        s_avl_response          : out std_logic_vector(1 downto 0);
        m_axi_awaddr            : out std_logic_vector(15 downto 0);
        m_axi_awprot            : out std_logic_vector(2 downto 0);
        m_axi_awvalid           : out std_logic;
        m_axi_wdata             : out std_logic_vector(31 downto 0);
        m_axi_wstrb             : out std_logic_vector(3 downto 0);
        m_axi_wvalid            : out std_logic;
        m_axi_bready            : out std_logic;
        m_axi_araddr            : out std_logic_vector(15 downto 0);
        m_axi_arprot            : out std_logic_vector(2 downto 0);
        m_axi_arvalid           : out std_logic;
        m_axi_rready            : out std_logic
    );
end entity tb_avalon_axilite_bridge;

architecture rtl of tb_avalon_axilite_bridge is

    -- Internal signals
    signal state : std_logic_vector(2 downto 0);
    signal addr_reg : std_logic_vector(15 downto 0);
    signal wdata_reg : std_logic_vector(31 downto 0);
    signal wstrb_reg : std_logic_vector(3 downto 0);
    signal rdata_reg : std_logic_vector(31 downto 0);
    signal resp_reg : std_logic_vector(1 downto 0);
    signal is_write_reg : std_logic;

begin

    proc_clk_1 : process(clk, rst_n)
    begin
        if rst_n = '0' then
            state <= (others => '0');
            addr_reg <= (others => '0');
            wdata_reg <= (others => '0');
            wstrb_reg <= (others => '0');
            rdata_reg <= (others => '0');
            resp_reg <= (others => '0');
            is_write_reg <= '0';
            m_axi_awvalid <= '0';
            m_axi_awaddr <= (others => '0');
            m_axi_awprot <= (others => '0');
            m_axi_wvalid <= '0';
            m_axi_wdata <= (others => '0');
            m_axi_wstrb <= (others => '0');
            m_axi_bready <= '0';
            m_axi_arvalid <= '0';
            m_axi_araddr <= (others => '0');
            m_axi_arprot <= (others => '0');
            m_axi_rready <= '0';
            s_avl_waitrequest <= '1';
            s_avl_readdata <= (others => '0');
            s_avl_readdatavalid <= '0';
            s_avl_response <= (others => '0');
        elsif rising_edge(clk) then
            case state is
                when "000" =>
                    s_avl_waitrequest <= '1';
                    s_avl_readdatavalid <= '0';
                    m_axi_awvalid <= '0';
                    m_axi_wvalid <= '0';
                    m_axi_bready <= '0';
                    m_axi_arvalid <= '0';
                    m_axi_rready <= '0';
                    if s_avl_write then
                        addr_reg <= s_avl_address(13 downto 0) & "00";
                        wdata_reg <= s_avl_writedata;
                        wstrb_reg <= s_avl_byteenable;
                        is_write_reg <= '1';
                        state <= "001";
                    else
                        if s_avl_read then
                            addr_reg <= s_avl_address(13 downto 0) & "00";
                            is_write_reg <= '0';
                            state <= "001";
                        end if;
                    end if;
                when "001" =>
                    s_avl_waitrequest <= '0';
                    if is_write_reg then
                        state <= "010";
                    else
                        state <= "101";
                    end if;
                when "010" =>
                    s_avl_waitrequest <= '1';
                    m_axi_awvalid <= '1';
                    m_axi_awaddr <= addr_reg;
                    m_axi_awprot <= (others => '0');
                    if m_axi_awready then
                        state <= "011";
                    end if;
                when "011" =>
                    m_axi_awvalid <= '0';
                    m_axi_wvalid <= '1';
                    m_axi_wdata <= wdata_reg;
                    m_axi_wstrb <= wstrb_reg;
                    if m_axi_wready then
                        state <= "100";
                    end if;
                when "100" =>
                    m_axi_wvalid <= '0';
                    m_axi_bready <= '1';
                    if m_axi_bvalid then
                        resp_reg <= m_axi_bresp;
                        s_avl_response <= m_axi_bresp;
                        state <= (others => '0');
                    end if;
                when "101" =>
                    s_avl_waitrequest <= '1';
                    m_axi_arvalid <= '1';
                    m_axi_araddr <= addr_reg;
                    m_axi_arprot <= (others => '0');
                    if m_axi_arready then
                        state <= "110";
                    end if;
                when "110" =>
                    m_axi_arvalid <= '0';
                    m_axi_rready <= '1';
                    if m_axi_rvalid then
                        rdata_reg <= m_axi_rdata;
                        resp_reg <= m_axi_rresp;
                        state <= "111";
                    end if;
                when "111" =>
                    s_avl_readdatavalid <= '1';
                    s_avl_readdata <= rdata_reg;
                    s_avl_response <= resp_reg;
                    state <= (others => '0');
                when others =>
                    state <= (others => '0');
            end case;
        end if;
    end process proc_clk_1;

end architecture rtl;
