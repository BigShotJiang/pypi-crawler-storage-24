# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tests/drivers/test_native_avalon_bridge.py
"""
End-to-end cocotb simulation for the Native Memory → Avalon-MM bridge.

Wires a NativeMemMaster on the native side and a simple Avalon-MM
memory responder (in the SV wrapper) on the Avalon side.
"""

import logging
import subprocess
import sys
from pathlib import Path

import cocotb
from cocotb.triggers import ClockCycles

current_dir = Path(__file__).resolve().parent
sdk_cocotb_path = current_dir.parents[1]
sys.path.insert(0, str(sdk_cocotb_path))

from tb.drivers.native_mem import NativeMemMaster
from tb.env import TbEnv


async def setup(dut):
    env = TbEnv(dut, clk="CLK", rst="RST_N", period_ns=10)
    await env.start_clock()

    env.log.setLevel(logging.DEBUG)

    await env.reset(cycles=5, active_low=True)

    master = NativeMemMaster(env, prefix="S_MEM")

    await ClockCycles(dut.CLK, 2)
    return env, master


@cocotb.test()
async def test_single_write_read(dut):
    """Basic write/read round-trip through the bridge."""
    dut._log.info("=== test_single_write_read ===")
    env, master = await setup(dut)

    await master.write(0x100, 0xDEADBEEF)
    data = await master.read(0x100)

    assert data == 0xDEADBEEF, f"Expected 0xDEADBEEF, got 0x{data:08X}"


@cocotb.test()
async def test_byte_strobe(dut):
    """Verify partial writes with byte strobes."""
    dut._log.info("=== test_byte_strobe ===")
    env, master = await setup(dut)

    # Write all bytes
    await master.write(0x200, 0xFFFFFFFF)
    # Overwrite only byte 0
    await master.write(0x200, 0x000000AA, strb=0x1)

    data = await master.read(0x200)
    assert data == 0xFFFFFFAA, f"Expected 0xFFFFFFAA, got 0x{data:08X}"


@cocotb.test()
async def test_sequential_access(dut):
    """Multiple sequential writes then reads to verify no state corruption."""
    dut._log.info("=== test_sequential_access ===")
    env, master = await setup(dut)

    test_data = {
        0x000: 0x11223344,
        0x001: 0x55667788,
        0x002: 0x99AABBCC,
        0x003: 0xDDEEFF00,
    }

    # Write all
    for addr, data in test_data.items():
        await master.write(addr, data)

    # Read all and verify
    for addr, expected in test_data.items():
        data = await master.read(addr)
        assert data == expected, f"@0x{addr:04X}: expected 0x{expected:08X}, got 0x{data:08X}"


if __name__ == "__main__":
    from engine.simulation import run_simulation

    sdk_root = current_dir.parent.parent.parent.parent
    bridge_gen_py = sdk_root / "sdk" / "generators" / "bridge" / "main.py"
    generated_sv = current_dir / "tb_native_avalon_bridge.sv"

    print(f"Generating SV bridge: {generated_sv}")
    subprocess.run(
        [
            sys.executable,
            str(bridge_gen_py),
            "--protocol",
            "native",
            "--target-protocol",
            "avalon",
            "--addr-width",
            "14",
            "--data-width",
            "32",
            "--prefix",
            "s_mem",
            "--lang",
            "sv",
            "--output",
            str(generated_sv),
        ],
        check=True,
    )

    run_simulation(
        top_level="tb_native_avalon_bridge_wrap",
        module="test_native_avalon_bridge",
        top_level_lang="verilog",
        waves=True,
        verbose=True,
        simulator="verilator",
        custom_libraries={},
        hdl_sources=[
            str(generated_sv),
            str(current_dir / "tb_native_avalon_bridge_wrap.sv"),
        ],
    )
