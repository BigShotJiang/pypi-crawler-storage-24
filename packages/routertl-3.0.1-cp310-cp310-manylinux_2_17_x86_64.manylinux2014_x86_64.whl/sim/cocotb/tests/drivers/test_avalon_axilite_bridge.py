# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tests/drivers/test_avalon_axilite_bridge.py
"""
End-to-end cocotb simulation for the Avalon-MM → AXI-Lite bridge.

Wires an AvalonMMMaster on the Avalon slave side and an AxiLiteSlave
on the AXI master side.  Traffic flows:

    AvalonMMMaster → [Bridge DUT] → AxiLiteSlave

Tests verify data integrity, address transformation (word→byte),
byte strobes, backpressure propagation, and error response mapping.

Run with:
    SIM=nvc python tests/drivers/test_avalon_axilite_bridge.py
"""

import sys
from pathlib import Path

import cocotb
from cocotb.triggers import ClockCycles

# Ensure SDK path is available
current_dir = Path(__file__).resolve().parent
sdk_cocotb_path = current_dir.parents[1]
sys.path.insert(0, str(sdk_cocotb_path))

from tb.drivers.avalon_mm import (
    AvalonMMMaster,
    AvalonResp,
)
from tb.drivers.axi_lite import (
    AxiLiteSlave,
)
from tb.env import TbEnv

# =============================================================================
# Helpers
# =============================================================================


async def setup(dut, read_latency=0, write_latency=0, error_addresses=None):
    """Create TbEnv, Avalon-MM master, AXI-Lite slave, and protocol monitors."""
    env = TbEnv(dut, clk="CLK", rst="RST_N", period_ns=10)
    await env.start_clock()

    # Active-low reset: assert rst_n low then release
    await env.reset(cycles=5, active_low=True)

    # Avalon-MM master drives the bridge's slave side
    master = AvalonMMMaster(env, prefix="S_AVL", raise_on_resp=False)

    # AXI-Lite slave responds on the bridge's master side
    slave = AxiLiteSlave(
        env,
        prefix="M_AXI",
        read_latency=read_latency,
        write_latency=write_latency,
        error_addresses=error_addresses,
    )
    cocotb.start_soon(slave.start())

    # Attach passive protocol monitors via SDK API
    env.attach_monitors(
        avalon_mm={"S_AVL": {"rst_active_low": True}},
        axi_lite={"M_AXI": {"rst_active_low": True}},
    )

    # Let everything settle after reset
    await ClockCycles(dut.CLK, 2)

    return env, master, slave


# =============================================================================
# Test Cases
# =============================================================================


@cocotb.test()
async def test_single_write_read(dut):
    """Write 0xDEADBEEF to word address 0x40, read it back through the bridge."""
    dut._log.info("=== test_single_write_read ===")

    env, master, slave = await setup(dut)

    # Write via Avalon-MM (word address 0x40 → AXI byte address 0x100)
    await master.write(0x40, 0xDEADBEEF)
    dut._log.info("Write completed")

    # Read back via Avalon-MM
    data, resp = await master.read(0x40)
    dut._log.info(f"Read back: 0x{data:08X}, resp={resp}")

    assert data == 0xDEADBEEF, f"Data mismatch: got 0x{data:08X}, expected 0xDEADBEEF"
    assert resp == AvalonResp.OKAY, f"Expected OKAY, got {resp}"
    env.check_monitors()


@cocotb.test()
async def test_sequential_writes(dut):
    """Write 16 sequential words, read all back, verify data integrity."""
    dut._log.info("=== test_sequential_writes ===")

    env, master, slave = await setup(dut)

    test_data = {}
    for i in range(16):
        addr = i  # Word addresses: 0x00, 0x01, 0x02, ...
        value = 0xA0000000 | (i << 16) | i
        await master.write(addr, value)
        test_data[addr] = value
        dut._log.info(f"Wrote 0x{value:08X} to word addr 0x{addr:04X}")

    # Read all back
    for addr, expected in test_data.items():
        data, resp = await master.read(addr)
        dut._log.info(f"Read 0x{data:08X} from word addr 0x{addr:04X}")
        assert data == expected, f"Addr 0x{addr:04X}: got 0x{data:08X}, expected 0x{expected:08X}"
        assert resp == AvalonResp.OKAY
    env.check_monitors()


@cocotb.test()
async def test_byte_strobe(dut):
    """Write with partial byte enables, verify only selected bytes change."""
    dut._log.info("=== test_byte_strobe ===")

    env, master, slave = await setup(dut)

    # First: write all 0xFF to word address 0x80
    await master.write(0x80, 0xFFFFFFFF)
    data, _ = await master.read(0x80)
    assert data == 0xFFFFFFFF, f"Initial write failed: 0x{data:08X}"

    # Now write with only byte 0 enabled (byteenable=0x1): overwrite lowest byte
    await master.write(0x80, 0x000000AA, byteenable=0x1)
    data, _ = await master.read(0x80)

    # Expected: byte 0 = 0xAA, bytes 1-3 = 0xFF
    expected = 0xFFFFFFAA
    dut._log.info(f"After partial strobe: 0x{data:08X}, expected 0x{expected:08X}")
    assert data == expected, f"Byte strobe failed: got 0x{data:08X}, expected 0x{expected:08X}"
    env.check_monitors()


@cocotb.test()
async def test_backpressure(dut):
    """AXI slave with latency, verify bridge handles stalls correctly."""
    dut._log.info("=== test_backpressure ===")

    env, master, slave = await setup(dut, read_latency=3, write_latency=3)

    # Write and read should still succeed despite AXI-side latency
    await master.write(0xC0, 0xCAFEBABE)
    data, resp = await master.read(0xC0)

    dut._log.info(f"With backpressure: 0x{data:08X}, resp={resp}")
    assert data == 0xCAFEBABE, f"Backpressure data mismatch: got 0x{data:08X}"
    assert resp == AvalonResp.OKAY

    # Multiple writes with backpressure
    for i in range(4):
        addr = 0x100 + i
        value = 0xBEEF0000 | i
        await master.write(addr, value)

    for i in range(4):
        addr = 0x100 + i
        expected = 0xBEEF0000 | i
        data, resp = await master.read(addr)
        assert data == expected, f"Addr 0x{addr:04X}: got 0x{data:08X}, expected 0x{expected:08X}"
    env.check_monitors()


@cocotb.test()
async def test_error_response(dut):
    """AXI slave returns SLVERR on specific address, verify Avalon response maps."""
    dut._log.info("=== test_error_response ===")

    # AXI byte address 0xFF0 (word address 0x3FC in Avalon space)
    # The bridge converts word addr 0x3FC → byte addr 0xFF0
    axi_error_addr = 0xFF0
    avl_word_addr = axi_error_addr >> 2  # = 0x3FC

    env, master, slave = await setup(dut, error_addresses={axi_error_addr})

    # Write to error address — should get SLVERR mapped to Avalon response
    await master.write(avl_word_addr, 0x12345678)
    dut._log.info(f"Write to error word address 0x{avl_word_addr:04X} completed")

    # Read from error address — should get error response
    data, resp = await master.read(avl_word_addr)
    dut._log.info(f"Read from error address: data=0x{data:08X}, resp={resp}")

    assert resp == AvalonResp.SLVERR, f"Expected SLVERR (0x2), got {resp}"
    env.check_monitors()


@cocotb.test()
@cocotb.parametrize(
    write_latency=[0, 1, 3],
    read_latency=[0, 1, 3],
)
async def test_timing_sweep(dut, write_latency, read_latency):
    """Parametric timing sweep: write+read under all AXI-Lite latency combos.

    Generates 9 variants (3 write_latency × 3 read_latency values).
    Exercises the AXI-Lite slave response timing paths across the full
    timing envelope without requiring DUT recompilation.
    """
    dut._log.info(f"=== test_timing_sweep [wr_lat={write_latency}, rd_lat={read_latency}] ===")

    env, master, slave = await setup(
        dut,
        write_latency=write_latency,
        read_latency=read_latency,
    )

    # Round-trip: unique sentinel value derived from the parameters
    sentinel = 0xC0DE0000 | (write_latency << 8) | read_latency
    await master.write(0x200, sentinel)
    data, resp = await master.read(0x200)

    assert resp == AvalonResp.OKAY, f"Expected OKAY, got {resp}"
    assert data == sentinel, (
        f"Data mismatch [wr_lat={write_latency}, rd_lat={read_latency}]: got 0x{data:08X}, expected 0x{sentinel:08X}"
    )
    env.check_monitors()


# =============================================================================
# Standalone Execution Entry Point
# =============================================================================

if __name__ == "__main__":
    from engine.simulation import run_simulation

    run_simulation(
        top_level="tb_avalon_axilite_bridge_wrap",
        module="test_avalon_axilite_bridge",
        top_level_lang="vhdl",
        waves=True,
        verbose=True,
        work_lib="work",
        custom_libraries={
            "work": [
                str(Path(__file__).parent / "tb_avalon_axilite_bridge.vhd"),
                str(Path(__file__).parent / "tb_avalon_axilite_bridge_wrap.vhd"),
            ]
        },
    )
