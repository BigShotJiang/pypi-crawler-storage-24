-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-- tests/drivers/spi_loopback_tb.vhd
-- Minimal testbench for SPI driver unit testing
--
-- Provides SPI signals for the Python driver to control.

library ieee;
use ieee.std_logic_1164.all;

entity spi_loopback_tb is
  port (
    CLK   : in    std_logic;
    RST   : in    std_logic;
    SCLK  : inout std_logic := '0';
    MOSI  : inOut std_logic := '1';
    MISO  : inout std_logic := '1';
    CS    : inout std_logic := '1'
  );
end entity spi_loopback_tb;

architecture rtl of spi_loopback_tb is
begin

  -- Simple loopback: MISO mirrors MOSI
  MISO <= MOSI;

end architecture rtl;
