# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tests/drivers/test_axilite_avalon_bridge.py
"""
End-to-end cocotb simulation for the AXI-Lite → Avalon-MM bridge.

Wires an AxiLiteMaster on the AXI slave side and an AvalonMMSlave
on the Avalon master side.  Traffic flows:

    AxiLiteMaster → [Bridge DUT] → AvalonMMSlave

Tests verify data integrity, address transformation, byte strobes,
backpressure propagation, and error response mapping.

Run with:
    SIM=nvc python tests/drivers/test_axilite_avalon_bridge.py
"""

import sys
from pathlib import Path

import cocotb
from cocotb.triggers import ClockCycles

# Ensure SDK path is available
current_dir = Path(__file__).resolve().parent
sdk_cocotb_path = current_dir.parents[1]
sys.path.insert(0, str(sdk_cocotb_path))

from tb.drivers.avalon_mm import (
    AvalonMMSlave,
)
from tb.drivers.axi_lite import (
    AxiLiteMaster,
    AxiResp,
)
from tb.env import TbEnv

# =============================================================================
# Helpers
# =============================================================================


async def setup(dut, waitrequest_cycles=0, read_latency=0, error_addresses=None):
    """Create TbEnv, AXI-Lite master, Avalon-MM slave, and protocol monitors."""
    env = TbEnv(dut, clk="CLK", rst="RST_N", period_ns=10)
    await env.start_clock()

    # Active-low reset: assert rst_n low then release
    await env.reset(cycles=5, active_low=True)

    master = AxiLiteMaster(env, prefix="S", raise_on_resp=False)

    slave = AvalonMMSlave(
        env,
        prefix="M_AVL",
        read_latency=read_latency,
        waitrequest_cycles=waitrequest_cycles,
        error_addresses=error_addresses,
    )
    cocotb.start_soon(slave.start())

    # Attach passive protocol monitors via SDK API
    env.attach_monitors(
        axi_lite={"S": {"rst_active_low": True}},
        avalon_mm={"M_AVL": {"rst_active_low": True}},
    )

    # Let everything settle after reset
    await ClockCycles(dut.CLK, 2)

    return env, master, slave


# =============================================================================
# Test Cases
# =============================================================================


@cocotb.test()
async def test_single_write_read(dut):
    """Write 0xDEADBEEF to address 0x100, read it back through the bridge."""
    dut._log.info("=== test_single_write_read ===")

    env, master, slave = await setup(dut)

    # Write via AXI-Lite (byte address 0x100 → Avalon word address 0x40)
    await master.write(0x100, 0xDEADBEEF)
    dut._log.info("Write completed")

    # Read back via AXI-Lite
    data, resp = await master.read(0x100)
    dut._log.info(f"Read back: 0x{data:08X}, resp={resp}")

    assert data == 0xDEADBEEF, f"Data mismatch: got 0x{data:08X}, expected 0xDEADBEEF"
    assert resp == AxiResp.OKAY, f"Expected OKAY, got {resp}"
    env.check_monitors()


@cocotb.test()
async def test_sequential_writes(dut):
    """Write 16 sequential words, read all back, verify data integrity."""
    dut._log.info("=== test_sequential_writes ===")

    env, master, slave = await setup(dut)

    test_data = {}
    for i in range(16):
        addr = i * 4  # Byte addresses: 0x00, 0x04, 0x08, ...
        value = 0xA0000000 | (i << 16) | i
        await master.write(addr, value)
        test_data[addr] = value
        dut._log.info(f"Wrote 0x{value:08X} to byte addr 0x{addr:04X}")

    # Read all back
    for addr, expected in test_data.items():
        data, resp = await master.read(addr)
        dut._log.info(f"Read 0x{data:08X} from byte addr 0x{addr:04X}")
        assert data == expected, f"Addr 0x{addr:04X}: got 0x{data:08X}, expected 0x{expected:08X}"
        assert resp == AxiResp.OKAY
    env.check_monitors()


@cocotb.test()
async def test_byte_strobe(dut):
    """Write with partial byte enables, verify only selected bytes change."""
    dut._log.info("=== test_byte_strobe ===")

    env, master, slave = await setup(dut)

    # First: write all 0xFF to address 0x200
    await master.write(0x200, 0xFFFFFFFF)
    data, _ = await master.read(0x200)
    assert data == 0xFFFFFFFF, f"Initial write failed: 0x{data:08X}"

    # Now write with only byte 0 enabled (wstrb=0x1): overwrite lowest byte
    await master.write(0x200, 0x000000AA, strb=0x1)
    data, _ = await master.read(0x200)

    # Expected: byte 0 = 0xAA, bytes 1-3 = 0xFF
    expected = 0xFFFFFFAA
    dut._log.info(f"After partial strobe: 0x{data:08X}, expected 0x{expected:08X}")
    assert data == expected, f"Byte strobe failed: got 0x{data:08X}, expected 0x{expected:08X}"
    env.check_monitors()


@cocotb.test()
async def test_backpressure(dut):
    """Avalon slave with waitrequest_cycles=3, verify bridge stalls correctly."""
    dut._log.info("=== test_backpressure ===")

    env, master, slave = await setup(dut, waitrequest_cycles=3)

    # Write and read should still succeed despite backpressure
    await master.write(0x300, 0xCAFEBABE)
    data, resp = await master.read(0x300)

    dut._log.info(f"With backpressure: 0x{data:08X}, resp={resp}")
    assert data == 0xCAFEBABE, f"Backpressure data mismatch: got 0x{data:08X}"
    assert resp == AxiResp.OKAY

    # Multiple writes with backpressure
    for i in range(4):
        addr = 0x400 + i * 4
        value = 0xBEEF0000 | i
        await master.write(addr, value)

    for i in range(4):
        addr = 0x400 + i * 4
        expected = 0xBEEF0000 | i
        data, resp = await master.read(addr)
        assert data == expected, f"Addr 0x{addr:04X}: got 0x{data:08X}, expected 0x{expected:08X}"
    env.check_monitors()


@cocotb.test()
async def test_error_response(dut):
    """Avalon slave returns SLVERR on specific address, verify AXI bresp/rresp maps."""
    dut._log.info("=== test_error_response ===")

    # Avalon word address 0x3FC corresponds to AXI byte address 0xFF0
    # (0xFF0 >> 2 = 0x3FC)
    avl_error_addr = 0x3FC
    axi_error_addr = avl_error_addr << 2  # = 0xFF0

    env, master, slave = await setup(dut, error_addresses={avl_error_addr})

    # Write to error address — should get SLVERR in bresp
    await master.write(axi_error_addr, 0x12345678)
    dut._log.info(f"Write to error address 0x{axi_error_addr:04X} completed")

    # Read from error address — should get SLVERR in rresp
    data, resp = await master.read(axi_error_addr)
    dut._log.info(f"Read from error address: data=0x{data:08X}, resp={resp}")

    assert resp == AxiResp.SLVERR, f"Expected SLVERR (0x2), got {resp}"
    env.check_monitors()


@cocotb.test()
@cocotb.parametrize(
    waitrequest_cycles=[0, 1, 3],
    read_latency=[0, 1, 3],
)
async def test_timing_sweep(dut, waitrequest_cycles, read_latency):
    """Parametric timing sweep: write+read under all backpressure/latency combos.

    Generates 9 variants (3 waitrequest_cycles × 3 read_latency values).
    Exercises the bridge's handshake logic across the full timing envelope
    without requiring DUT recompilation.
    """
    dut._log.info(f"=== test_timing_sweep [wr_cycles={waitrequest_cycles}, rd_lat={read_latency}] ===")

    env, master, slave = await setup(
        dut,
        waitrequest_cycles=waitrequest_cycles,
        read_latency=read_latency,
    )

    # Round-trip: unique sentinel value derived from the parameters
    sentinel = 0xC0DE0000 | (waitrequest_cycles << 8) | read_latency
    await master.write(0x500, sentinel)
    data, resp = await master.read(0x500)

    assert resp == AxiResp.OKAY, f"Expected OKAY, got {resp}"
    assert data == sentinel, (
        f"Data mismatch [wr_cyc={waitrequest_cycles}, rd_lat={read_latency}]: "
        f"got 0x{data:08X}, expected 0x{sentinel:08X}"
    )
    env.check_monitors()


# =============================================================================
# Standalone Execution Entry Point
# =============================================================================

if __name__ == "__main__":
    from engine.simulation import run_simulation

    run_simulation(
        top_level="tb_axilite_avalon_bridge_wrap",
        module="test_axilite_avalon_bridge",
        top_level_lang="vhdl",
        waves=True,
        verbose=True,
        work_lib="work",
        custom_libraries={
            "work": [
                str(Path(__file__).parent / "tb_axilite_avalon_bridge.vhd"),
                str(Path(__file__).parent / "tb_axilite_avalon_bridge_wrap.vhd"),
            ]
        },
    )
