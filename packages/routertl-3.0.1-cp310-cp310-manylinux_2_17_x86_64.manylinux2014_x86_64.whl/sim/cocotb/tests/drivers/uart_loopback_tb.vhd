-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-- tests/drivers/uart_loopback_tb.vhd
-- Minimal testbench for UART driver unit testing
--
-- Provides a simple passthrough signal that allows the Python UART driver
-- to generate and monitor UART waveforms without any VHDL logic.

library ieee;
use ieee.std_logic_1164.all;

entity uart_loopback_tb is
  port (
    CLK       : in  std_logic;
    RST       : in  std_logic;
    UART_LOOP : inout std_logic := '1'  -- Bidirectional UART line (default idle high)
  );
end entity uart_loopback_tb;

architecture rtl of uart_loopback_tb is
begin

  -- No logic needed - the Python driver controls the UART_LOOP signal directly
  -- This entity exists solely to give cocotb a DUT to instantiate

end architecture rtl;
