# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import sys

import cocotb
from cocotb.triggers import Timer

# Ensure we can import from engine (if not installed as package)
# This mimics the behavior of the engine migration pattern
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from cocotb.handle import HierarchyArrayObject

from engine.paths import SRC_PATH
from engine.simulation import run_simulation


def ensure_signal(sig):
    """
    Workaround for GHDL issue where scalar ports are sometimes exposed as HierarchyArrayObject.
    """
    if isinstance(sig, HierarchyArrayObject):
        return sig[0]
    return sig


@cocotb.test()
async def test_edges(dut):
    """Test edge detection functionality - Minimal Engine Verification."""
    dut._log.info("Starting minimal engine verification test.")
    dut._log.info("If this runs, the engine correctly compiled and launched the simulator.")

    # We avoid touching ports due to GHDL VPI scalar-as-array issues in this env.
    await Timer(100, unit="ns")

    dut._log.info("Test passed!")


if __name__ == "__main__":
    # Run simulation using the new engine
    # Run simulation using the new engine
    # We provide a minimal custom_libraries dict to avoid trying to compile
    # the entire project (which currently has missing/broken files).
    # This verifies the engine logic itself.
    run_simulation(
        top_level="edge_detector",
        module="test_engine_demo",
        custom_libraries={"tich": [f"{SRC_PATH}/units/edge_detector.vhd"]},
        # Empty libraries to avoid default broken ones.
        # engine/simulation.py fix allows empty dict.
        generics={"G_EDGE_TYPE": 0},
        waves=True,
        # simulator="ghdl"  <-- Removed to allow SIM env var override
    )
