-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use IEEE.MATH_REAL.all;
library tich;

entity wrapper_spi_top is
    generic (
        G_SIM_ARCH : integer := 0
    );
    port (
        CLK       : in std_logic;
        RST       : in std_logic;
        SCLK      : in std_logic;
        MISO      : inout std_logic;
        MOSI      : in std_logic;
        CS        : in std_logic;
        FVDCO      : out std_logic;
        FOUT       : out std_logic;
        FSYNC      : out std_logic
    );
end entity;


architecture rtl of wrapper_spi_top is


begin

    MISO <= '1';

    -- Instantiate the system_top entity, which an SPI slave
    i_system_top : entity tich.system_top
    generic (
        G_SIM_ARCH : integer := 0
    );
    port map (
        CLK      => CLK,
        SPI_SCLK => SCLK,
        SPI_MOSI => MISO,
        FVDCO    => FVDCO,
        FOUT     => FOUT,
        FSYNC    => FSYNC
    );


end architecture;