-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use ieee.std_logic_textio.all;

library tich;
use tich.system_pkg.all;
use tich.system_regbank_pkg.all;

package sim_utils_pkg is

  -----------------------------------------------------------------------------
  -- In Record (h2c)
  -----------------------------------------------------------------------------
  type t_NativMem_out is record
    ADDR   : std_logic_vector(C_REGBANK_DEPTH - 1 downto 0);  -- in
    DATAIN : std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);  -- in 
    WE     : std_logic;                                       --in
    RD     : std_logic;                                       --in
  end record t_NativMem_out;

  constant C_NATIVE_MEM_OUT_INIT : t_NativMem_out := (
    ADDR   => (others => '0'),
    DATAIN => (others => '0'),
    WE     => '0',
    RD     => '0'
    );

  function PadString(
    input_string  : in string;
    output_length : in integer
    ) return string;

  -----------------------------------------------------------------------------
  -- Constants
  -----------------------------------------------------------------------------
  constant C_READ_FROM_BLOCK_PIPE_OUT_INSTR : integer := 1;
  constant C_READ_FROM_PIPE_OUT_INSTR       : integer := 2;
  constant C_UPDATE_WIRE_OUTS_INSTR         : integer := 3;
  constant C_SET_WIRE_IN_VALUE_INSTR        : integer := 4;
  constant C_GET_WIRE_OUT_VALUE_INSTR       : integer := 5;
  constant C_UPDATE_WIRE_INS_INSTR          : integer := 6;
  constant C_WRITE_TO_PIPE_IN_INSTR         : integer := 7;
  constant C_READ_REGISTER_INSTR            : integer := 8;
  constant C_WRITE_REGISTER_INSTR           : integer := 9;

  constant C_READ_FROM_BLOCK_PIPE_OUT_STR : string(1 to 20) := PadString("ReadBlockPipeOut", 20);
  constant C_READ_FROM_PIPE_OUT_STR       : string(1 to 20) := PadString("ReadFromPipeOut", 20);
  constant C_UPDATE_WIRE_OUTS_STR         : string(1 to 20) := PadString("UpdateWireOuts", 20);
  constant C_SET_WIRE_IN_VALUE_STR        : string(1 to 20) := PadString("SetWireInValue", 20);
  constant C_GET_WIRE_OUT_VALUE_STR       : string(1 to 20) := PadString("GetWireOutValue", 20);
  constant C_UPDATE_WIRE_INS_STR          : string(1 to 20) := PadString("UpdateWireIns", 20);
  constant C_WRITE_TO_PIPE_IN_STR         : string(1 to 20) := PadString("WriteToPipeIn", 20);
  constant C_READ_REGISTER_STR            : string(1 to 20) := PadString("ReadRegister", 20);
  constant C_WRITE_REGISTER_STR           : string(1 to 20) := PadString("WriteRegister", 20);

  -----------------------------------------------------------------------------
  -- Types
  -----------------------------------------------------------------------------

  type t_instruction_record is record
    name        : string(1 to 20);
    id          : integer;
    device_addr : std_logic_vector(7 downto 0);
    valid       : std_logic;
    datain      : std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
    address     : std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
    block_size  : std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
    length      : std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
    error       : std_logic;
  end record t_instruction_record;

  -----------------------------------------------------------------------------
  -- Out Record (c2h)
  -----------------------------------------------------------------------------
  type t_NativMem_in is record
    DATAOUT : std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
  end record t_NativMem_in;

  constant C_NATIVE_MEM_IN_INIT : t_NativMem_in := (
    DATAOUT => (others => '0')
    );

  -----------------------------------------------------------------------------
  -- Procedure declaration
  -----------------------------------------------------------------------------
  procedure NativMemWrite
    (
      signal CLK          : in  std_logic;
      signal ADDR         : in  std_logic_vector(C_REGBANK_DEPTH - 1 downto 0);
      signal WDATA        : in  std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
      signal NativMem_out : out t_NativMem_out
      );

  procedure NativMemRead
    (
      signal CLK          : in  std_logic;
      signal ADDR         : in  std_logic_vector(C_REGBANK_DEPTH - 1 downto 0);
      signal RDATA        : out std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
      signal NativMem_out : out t_NativMem_out;
      signal NativMem_in  : in  t_NativMem_in
      );

  procedure generate_instruction (
    signal CLK         : in    std_logic;
    signal INSTRUCTION : in    t_instruction_record;
    signal OKUHU       : out std_logic_vector(31 downto 0);
    signal OKUH        : out std_logic_vector(4 downto 1); -- id
    signal OKAA        : out std_logic  -- valid
    );
  -----------------------------------------------------------------------------
  -- To be used by the FP model as part as the SYSTEM_TOP simulation environment
  -----------------------------------------------------------------------------
  procedure decode_instruction (
    signal CLK         : in  std_logic;
    signal OKUH        : in  std_logic_vector(4 downto 1);
    signal OKUHU       : in  std_logic_vector(31 downto 0);
    signal OKAA        : in  std_logic;
    signal INSTRUCTION : out t_instruction_record;
    signal DONE        : out std_logic
    );

end sim_utils_pkg;

package body sim_utils_pkg is

  procedure NativMemWrite
    (
      signal CLK          : in  std_logic;
      signal ADDR         : in  std_logic_vector(C_REGBANK_DEPTH - 1 downto 0);
      signal WDATA        : in  std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
      signal NativMem_out : out t_NativMem_out
      ) is

  begin
    wait until rising_edge(CLK);
    NativMem_out        <= C_NATIVE_MEM_OUT_INIT;
    wait until rising_edge(CLK);
    ---------------------------------------------------------------------------
    -- Prepare transfer
    ---------------------------------------------------------------------------
    NativMem_out.ADDR   <= ADDR;
    NativMem_out.DATAIN <= WDATA;
    NativMem_out.WE     <= '1';
    NativMem_out.RD     <= '0';
    wait until rising_edge(CLK);
    NativMem_out.WE     <= '0';
    wait until rising_edge(CLK);
  end NativMemWrite;

  procedure NativMemRead
    (
      signal CLK          : in  std_logic;
      signal ADDR         : in  std_logic_vector(C_REGBANK_DEPTH - 1 downto 0);
      signal RDATA        : out std_logic_vector(C_REGBANK_WIDTH - 1 downto 0);
      signal NativMem_out : out t_NativMem_out;
      signal NativMem_in  : in  t_NativMem_in
      ) is

  begin
    wait until rising_edge(CLK);
    NativMem_out      <= C_NATIVE_MEM_OUT_INIT;
    wait until rising_edge(CLK);
---------------------------------------------------------------------------
-- Prepare transfer
---------------------------------------------------------------------------
    NativMem_out.ADDR <= ADDR;
    NativMem_out.WE   <= '0';
    NativMem_out.RD   <= '1';
    wait until rising_edge(CLK);
    RDATA             <= NativMem_in.DATAOUT;
    NativMem_out.RD   <= '0';
    wait until rising_edge(CLK);

  end NativMemRead;

  -----------------------------------------------------------------------------
  -- Procedures
  -----------------------------------------------------------------------------
  -- To be used by the TB, that moves the FP OK signals
  procedure generate_instruction (
    signal CLK         : in    std_logic;
    signal INSTRUCTION : in    t_instruction_record;
    signal OKUHU       : out std_logic_vector(31 downto 0);
    signal OKUH        : out std_logic_vector(4 downto 1); -- id
    signal OKAA        : out std_logic -- valid
    
    ) is
    variable okuhuInstr_v : std_logic_vector(4 downto 1);

  begin
    OKUHU <= (others => '0');
    wait until rising_edge(CLK);    
    if INSTRUCTION.valid = '1' then
      OKAA  <= '1';
      OKUH <= std_logic_vector(to_unsigned(INSTRUCTION.id, 4));
      -- Pass the different fields, one per cycle
      OKUHU(7 downto 0) <= INSTRUCTION.device_addr;
      wait until rising_edge(CLK);
      OKUHU <= INSTRUCTION.datain;
      wait until rising_edge(CLK);
      OKUHU <= INSTRUCTION.address;
      wait until rising_edge(CLK);
      OKUHU <= INSTRUCTION.block_size;
      wait until rising_edge(CLK);
      OKUHU <= INSTRUCTION.length;
      wait until rising_edge(CLK);
      OKAA  <= '0';
    end if;


  end procedure generate_instruction;

  -----------------------------------------------------------------------------
  -- To be used by the FP model as part as the SYSTEM_TOP simulation environment
  -----------------------------------------------------------------------------
  procedure decode_instruction (
    signal CLK         : in    std_logic;
    signal OKUH        : in    std_logic_vector(4 downto 1);
    signal OKUHU       : in    std_logic_vector(31 downto 0);
    signal OKAA        : in   std_logic;
    signal INSTRUCTION : out   t_instruction_record;
    signal DONE        : out   std_logic
    ) is
    variable okuhuInstr_v : unsigned(4 downto 1);
  begin  -- procedure decode_instruction

    wait until rising_edge(CLK);
      
    DONE         <= '0';
    okuhuInstr_v := unsigned(OKUH);

    case to_integer(okuhuInstr_v) is
      when C_READ_FROM_BLOCK_PIPE_OUT_INSTR =>
        INSTRUCTION.name <= PadString("ReadFromBlockPipeOut", INSTRUCTION.name'length);
      when C_READ_FROM_PIPE_OUT_INSTR =>
        INSTRUCTION.name <= PadString("ReadFromPipeOut", INSTRUCTION.name'length);
      when C_UPDATE_WIRE_OUTS_INSTR =>
        INSTRUCTION.name <= PadString("UpdateWireOuts", INSTRUCTION.name'length);
      when C_GET_WIRE_OUT_VALUE_INSTR =>
        INSTRUCTION.name <= PadString("GetWireOutValue", INSTRUCTION.name'length);
      when C_SET_WIRE_IN_VALUE_INSTR =>
        INSTRUCTION.name <= PadString("SetWireInValue", INSTRUCTION.name'length);
      when C_UPDATE_WIRE_INS_INSTR =>
        INSTRUCTION.name <= PadString("UpdateWireIns", INSTRUCTION.name'length);
      when C_WRITE_TO_PIPE_IN_INSTR =>
        INSTRUCTION.name <= PadString("WriteToPipeIn", INSTRUCTION.name'length);
      when C_READ_REGISTER_INSTR =>
        INSTRUCTION.name <= PadString("ReadRegister", INSTRUCTION.name'length);
      when C_WRITE_REGISTER_INSTR =>
        INSTRUCTION.name <= PadString("WriteRegister", INSTRUCTION.name'length);
      when others =>
        null;
    end case;
    if OKAA = '1' then
    INSTRUCTION.id <= to_integer(unsigned(okuhuInstr_v));

    INSTRUCTION.device_addr <= OKUHU(7 downto 0);
    wait until rising_edge(CLK);
    INSTRUCTION.datain      <= OKUHU;
    wait until rising_edge(CLK);
    INSTRUCTION.address     <= OKUHU;
    wait until rising_edge(CLK);
    INSTRUCTION.block_size  <= OKUHU;
    wait until rising_edge(CLK);
    INSTRUCTION.length      <= OKUHU;
    INSTRUCTION.valid       <= '1';
    DONE                    <= '1';
    wait until rising_edge(CLK);
    DONE                    <= '0';
    end if;
  end procedure decode_instruction;

  function PadString(
    input_string  : in string;
    output_length : in integer
    ) return string is
    variable padded_string : string(1 to output_length);
    variable i             : integer;
  begin
    -- Initialize the padded string with spaces
    for i in 1 to output_length loop
      padded_string(i) := ' ';
    end loop;

    -- Copy the original string into the padded string
    for i in 1 to input_string'length loop
      if i <= output_length then
        padded_string(i) := input_string(i);
      else
        exit;  -- Exit if input is larger than output length
      end if;
    end loop;

    return padded_string;
  end function PadString;

end sim_utils_pkg;
