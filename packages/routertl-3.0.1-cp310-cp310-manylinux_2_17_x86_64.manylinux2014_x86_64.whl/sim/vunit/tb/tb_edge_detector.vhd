-- SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
-- SPDX-License-Identifier: MIT

-------------------------------------------------------------------------------
-- Title      : VUnit Testbench for edge_detector
-- Project    : RouteRTL SDK
-------------------------------------------------------------------------------
-- File       : tb_edge_detector.vhd
-- Author     : RouteRTL SDK
-- Created    : 2026-01-27
-- Standard   : VHDL 2008
-------------------------------------------------------------------------------
-- Description: Self-checking testbench using VUnit's check library.
--              Tests rising, falling, and both edge detection modes.
-------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library vunit_lib;
context vunit_lib.vunit_context;

entity tb_edge_detector is
  generic (
    runner_cfg   : string;               -- VUnit runner configuration
    G_EDGE_TYPE  : integer := 0          -- 0: rising, 1: falling, 2: both
  );
end entity tb_edge_detector;

architecture tb of tb_edge_detector is

  -- Constants
  constant C_CLK_PERIOD : time := 10 ns;

  -- DUT signals
  signal clk  : std_logic := '0';
  signal rst  : std_logic := '0';
  signal ce   : std_logic := '1';
  signal d    : std_logic := '0';
  signal q    : std_logic;

  -- Test control
  signal test_done : boolean := false;

begin

  -- Clock generation
  clk <= not clk after C_CLK_PERIOD / 2 when not test_done else '0';

  -- DUT instantiation (use 'work' since TB and DUT are in the same library)
  dut : entity work.edge_detector
    generic map (
      G_EDGE_TYPE => G_EDGE_TYPE
    )
    port map (
      CLK => clk,
      R   => rst,
      CE  => ce,
      D   => d,
      Q   => q
    );

  -- Main test process
  main : process
    -- Helper procedure: wait for N clock cycles
    procedure wait_cycles(n : positive) is
    begin
      for i in 1 to n loop
        wait until rising_edge(clk);
      end loop;
    end procedure;

    -- Helper procedure: apply rising edge on D
    procedure apply_rising_edge is
    begin
      d <= '0';
      wait_cycles(2);
      d <= '1';
      wait_cycles(1);
    end procedure;

    -- Helper procedure: apply falling edge on D
    procedure apply_falling_edge is
    begin
      d <= '1';
      wait_cycles(2);
      d <= '0';
      wait_cycles(1);
    end procedure;

  begin
    -- VUnit test runner setup
    test_runner_setup(runner, runner_cfg);

    info("Starting edge_detector testbench");
    info("Configuration: G_EDGE_TYPE = " & integer'image(G_EDGE_TYPE));

    -- Reset sequence
    rst <= '1';
    wait_cycles(3);
    rst <= '0';
    wait_cycles(2);

    -- =========================================================================
    -- Test: Rising Edge Detection
    -- =========================================================================
    while test_suite loop
      if run("test_rising_edge") then
        info("Testing rising edge detection");
        
        -- Apply rising edge
        apply_rising_edge;
        wait_cycles(1);
        
        if G_EDGE_TYPE = 0 or G_EDGE_TYPE = 2 then
          check_equal(q, '1', "Rising edge should be detected");
        else
          check_equal(q, '0', "Rising edge should NOT be detected in falling mode");
        end if;
        
        -- Wait and check Q returns to 0
        wait_cycles(2);
        check_equal(q, '0', "Q should return to 0 after one cycle");

      -- =========================================================================
      -- Test: Falling Edge Detection
      -- =========================================================================
      elsif run("test_falling_edge") then
        info("Testing falling edge detection");
        
        -- Start high, then apply falling edge
        d <= '1';
        wait_cycles(3);
        apply_falling_edge;
        wait_cycles(1);
        
        if G_EDGE_TYPE = 1 or G_EDGE_TYPE = 2 then
          check_equal(q, '1', "Falling edge should be detected");
        else
          check_equal(q, '0', "Falling edge should NOT be detected in rising mode");
        end if;
        
        wait_cycles(2);
        check_equal(q, '0', "Q should return to 0 after one cycle");

      -- =========================================================================
      -- Test: Clock Enable Functionality
      -- =========================================================================
      elsif run("test_clock_enable") then
        info("Testing clock enable functionality");
        
        -- Disable clock enable
        ce <= '0';
        wait_cycles(2);
        
        -- Apply edge while CE is low
        d <= '0';
        wait_cycles(2);
        d <= '1';
        wait_cycles(2);
        
        -- Edge should not be detected
        check_equal(q, '0', "Edge should not be detected when CE=0");
        
        -- Re-enable and verify operation
        -- Need to let edge detector register current D value first
        ce <= '1';
        d <= '0';
        wait_cycles(2);  -- Allow D_r to update with D=0
        d <= '1';
        wait_cycles(2);  -- One cycle for edge, one for output
        
        if G_EDGE_TYPE = 0 or G_EDGE_TYPE = 2 then
          check_equal(q, '1', "Edge should be detected when CE=1");
        end if;

      -- =========================================================================
      -- Test: Reset Functionality
      -- =========================================================================
      elsif run("test_reset") then
        info("Testing reset functionality");
        
        -- Apply edge
        apply_rising_edge;
        wait_cycles(1);
        
        -- Assert reset
        rst <= '1';
        wait_cycles(1);
        check_equal(q, '0', "Q should be cleared on reset");
        
        rst <= '0';
        wait_cycles(2);

      end if;
    end loop;

    info("All tests completed successfully!");
    test_done <= true;
    test_runner_cleanup(runner);
  end process main;

  -- Watchdog timer
  test_runner_watchdog(runner, 10 ms);

end architecture tb;
