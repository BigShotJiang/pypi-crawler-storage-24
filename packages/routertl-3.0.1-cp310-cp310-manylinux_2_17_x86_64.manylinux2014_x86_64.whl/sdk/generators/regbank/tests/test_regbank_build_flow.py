#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
End-to-end regression test for the complete regbank build flow.

This test simulates the full build chain:
1. project_regbank.yml → generate_regbank_pkg.py → system_regbank_pkg.vhd
2. project_regbank.yml → payload_encoder.py → regbank_schema.hex
3. create_rom.sh → misc/rom.data
4. gen_info_pkg.py → rom_info_pkg.vhd

Validates that all constants are correctly generated and mapped.
"""

import subprocess
import tempfile
import unittest
from pathlib import Path

import yaml

# Tool paths
TOOLS_DIR = Path(__file__).parent.parent.absolute()
GEN_PKG = TOOLS_DIR / "generate_regbank_pkg.py"
ENCODER = TOOLS_DIR / "payload_encoder.py"
GEN_INFO = TOOLS_DIR / "gen_info_pkg.py"

# Test YAML content with the new naming
TEST_REGBANK_YAML = {
    "name": "test_system_regs",
    "version": "1.2.3",
    "registers": [
        {"name": "GIT_HASH_VALUE", "address": "0x0000", "access": "ROM", "description": "Git commit hash"},
        {"name": "SYSTEM_FW_VERSION", "address": "0x0004", "access": "ROM", "description": "System firmware version"},
        {"name": "BUILD_DATE", "address": "0x0008", "access": "ROM", "description": "Build timestamp"},
        {"name": "REGISTER_BANK_VERSION", "address": "0x000C", "access": "ROM", "description": "Register bank version"},
        {
            "name": "REGBANK_NUM_WORDS",
            "address": "0x0010",
            "access": "ROM",
            "description": "Number of words in regbank schema",
        },
        {"name": "TEST_CONTROL", "address": "0x0014", "access": "RW", "description": "Test control register"},
    ],
}


class TestRegbankBuildFlow(unittest.TestCase):
    """End-to-end test for the complete regbank build flow."""

    def setUp(self):
        """Create temporary test environment."""
        self._temp_dir_obj = tempfile.TemporaryDirectory()
        self.test_dir = Path(self._temp_dir_obj.name)

        # Create directory structure
        (self.test_dir / "src" / "pkg").mkdir(parents=True)
        (self.test_dir / "src" / "regbank").mkdir(parents=True)
        (self.test_dir / "misc").mkdir(parents=True)

        # Write test regbank YAML
        self.regbank_yaml = self.test_dir / "project_regbank.yml"
        with open(self.regbank_yaml, "w") as f:
            yaml.dump(TEST_REGBANK_YAML, f)

        # Create VERSION file
        with open(self.test_dir / "VERSION", "w") as f:
            f.write("system_major=2\nsystem_minor=5\n")

        # Initialize git repo (needed for create_rom.sh)
        subprocess.run(["git", "init"], cwd=self.test_dir, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=self.test_dir, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test User"], cwd=self.test_dir, capture_output=True)
        subprocess.run(["git", "add", "."], cwd=self.test_dir, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=self.test_dir, capture_output=True)

    def tearDown(self):
        """Cleanup temporary directory."""
        self._temp_dir_obj.cleanup()

    def run_command(self, cmd, cwd=None):
        """Run a command and return the result."""
        if cwd is None:
            cwd = self.test_dir
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
        if result.returncode != 0:
            print(f"❌ Command failed: {' '.join(str(c) for c in cmd)}")
            print(f"   Working dir: {cwd}")
            print(f"   STDOUT: {result.stdout}")
            print(f"   STDERR: {result.stderr}")
        return result

    def test_01_vhdl_package_generation(self):
        """Test VHDL package generation from project_regbank.yml."""
        output_pkg = self.test_dir / "src" / "pkg" / "system_regbank_pkg.vhd"

        result = self.run_command(["python3", str(GEN_PKG), str(self.regbank_yaml), str(output_pkg)])

        self.assertEqual(result.returncode, 0, "VHDL package generation failed")
        self.assertTrue(output_pkg.exists(), "VHDL package not created")

        content = output_pkg.read_text()
        # Verify new naming conventions
        self.assertIn("C_SYSTEM_VERSION", content, "C_SYSTEM_VERSION constant not found")
        self.assertIn("C_REGBANK_NWORDS", content, "C_REGBANK_NWORDS constant not found")
        self.assertIn("C_REGBANK_WORDS", content, "C_REGBANK_WORDS constant referenced")

        # Verify register indices
        self.assertIn("C_INDEX_GIT_HASH_VALUE", content)
        self.assertIn("C_INDEX_SYSTEM_FW_VERSION", content)
        self.assertIn("C_INDEX_REGBANK_NUM_WORDS", content)

        print("✅ VHDL package generation successful")

    def test_02_hex_file_generation(self):
        """Test regbank schema hex file generation."""
        result = self.run_command(["python3", str(ENCODER), str(self.regbank_yaml)])

        self.assertEqual(result.returncode, 0, "Hex file generation failed")

        hex_file = self.test_dir / "regbank_manifest.hex"
        self.assertTrue(hex_file.exists(), "Hex file not created")

        # Verify hex file has content
        content = hex_file.read_text()
        lines = content.strip().split("\n")
        self.assertGreater(len(lines), 0, "Hex file is empty")

        print(f"✅ Hex file generated with {len(lines)} lines")

    def test_03_rom_data_generation(self):
        """Test rom.data generation (simulated create_rom.sh flow)."""
        # First generate hex file
        self.test_02_hex_file_generation()

        # Create mock regbank_schema.hex and config_schema.hex
        regbank_hex = self.test_dir / "src" / "regbank" / "regbank_schema.hex"
        config_hex = self.test_dir / "src" / "regbank" / "config_schema.hex"

        # Copy generated hex file
        import shutil

        shutil.copy(self.test_dir / "regbank_manifest.hex", regbank_hex)

        # Create empty config
        config_hex.write_text("00000000\n")

        # Manually create rom.data (simulating create_rom.sh)
        rom_data = self.test_dir / "misc" / "rom.data"
        with open(rom_data, "w") as f:
            # 1. Build date (hex timestamp)
            f.write("678a1234\n")
            # 2. Git hash
            f.write("abcd1234\n")
            # 3. System version (2.5.1.0 in hex)
            f.write("02050100\n")
            # 4. Regbank version (1.2.3.0 from YAML)
            f.write("01020300\n")
            # 5. Regbank words (from hex file)
            hex_lines = regbank_hex.read_text().strip().split("\n")
            f.write(f"{len(hex_lines):08x}\n")
            # 6. Config words
            config_lines = config_hex.read_text().strip().split("\n")
            f.write(f"{len(config_lines):08x}\n")

        self.assertTrue(rom_data.exists(), "rom.data not created")

        lines = rom_data.read_text().strip().split("\n")
        self.assertEqual(len(lines), 6, "rom.data should have 6 lines")

        print("✅ rom.data generated successfully")

    def test_04_rom_info_pkg_generation(self):
        """Test rom_info_pkg.vhd generation with correct constants."""
        # Setup: generate all prerequisites
        self.test_03_rom_data_generation()

        rom_data = self.test_dir / "misc" / "rom.data"
        regbank_hex = self.test_dir / "src" / "regbank" / "regbank_schema.hex"
        config_hex = self.test_dir / "src" / "regbank" / "config_schema.hex"

        result = self.run_command(["python3", str(GEN_INFO), str(self.test_dir), str(regbank_hex), str(config_hex)])

        self.assertEqual(result.returncode, 0, "rom_info_pkg generation failed")

        rom_info_pkg = self.test_dir / "src" / "pkg" / "rom_info_pkg.vhd"
        self.assertTrue(rom_info_pkg.exists(), "rom_info_pkg.vhd not created")

        content = rom_info_pkg.read_text()

        # Verify new naming conventions
        self.assertIn("constant C_SYSTEM_VERSION", content, "C_SYSTEM_VERSION not found")
        self.assertIn("constant C_REGBANK_WORDS", content, "C_REGBANK_WORDS not found")
        self.assertIn("constant C_REGBANK_HEX", content, "C_REGBANK_HEX not found")

        # Verify old names are NOT present
        self.assertNotIn("C_SNIFFER_VERSION", content, "Old C_SNIFFER_VERSION found (should be C_SYSTEM_VERSION)")
        self.assertNotIn("C_MANIFEST_WORDS", content, "Old C_MANIFEST_WORDS found (should be C_REGBANK_WORDS)")

        # Verify expected values
        self.assertIn('x"02050100"', content, "System version value not correct")
        self.assertIn('x"01020300"', content, "Regbank version value not correct")

        print("✅ rom_info_pkg.vhd generated with correct constants")

    def test_05_end_to_end_integration(self):
        """Full end-to-end integration test."""
        print("\n🔄 Running full end-to-end integration test...")

        # Step 1: Generate VHDL package
        pkg_result = self.run_command(
            [
                "python3",
                str(GEN_PKG),
                str(self.regbank_yaml),
                str(self.test_dir / "src" / "pkg" / "system_regbank_pkg.vhd"),
            ]
        )
        self.assertEqual(pkg_result.returncode, 0)

        # Step 2: Generate hex files
        enc_result = self.run_command(["python3", str(ENCODER), str(self.regbank_yaml)])
        self.assertEqual(enc_result.returncode, 0)

        # Step 3: Setup files for rom_info generation
        import shutil

        shutil.copy(self.test_dir / "regbank_manifest.hex", self.test_dir / "src" / "regbank" / "regbank_schema.hex")
        (self.test_dir / "src" / "regbank" / "config_schema.hex").write_text("00000000\n")

        # Create rom.data
        self.test_03_rom_data_generation()

        # Step 4: Generate rom_info_pkg
        info_result = self.run_command(
            [
                "python3",
                str(GEN_INFO),
                str(self.test_dir),
                str(self.test_dir / "src" / "regbank" / "regbank_schema.hex"),
                str(self.test_dir / "src" / "regbank" / "config_schema.hex"),
            ]
        )
        self.assertEqual(info_result.returncode, 0)

        # Verify all artifacts exist
        self.assertTrue((self.test_dir / "src" / "pkg" / "system_regbank_pkg.vhd").exists())
        self.assertTrue((self.test_dir / "src" / "pkg" / "rom_info_pkg.vhd").exists())
        self.assertTrue((self.test_dir / "src" / "regbank" / "regbank_schema.hex").exists())
        self.assertTrue((self.test_dir / "misc" / "rom.data").exists())

        print("✅ Full end-to-end integration successful")


if __name__ == "__main__":
    unittest.main(verbosity=2)
