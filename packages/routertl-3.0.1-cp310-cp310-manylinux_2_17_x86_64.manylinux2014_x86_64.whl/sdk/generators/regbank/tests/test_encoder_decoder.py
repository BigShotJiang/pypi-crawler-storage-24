# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import json
import shutil
import subprocess
import unittest
from pathlib import Path

import yaml

# Paths to tools (Relative to this test file: ../)
CURRENT_DIR = Path(__file__).parent.absolute()
TOOLS_DIR = CURRENT_DIR.parent

ENCODER = TOOLS_DIR / "payload_encoder.py"
DECODER = TOOLS_DIR / "payload_decoder.py"

# Test Data
MOCK_YAML = "mock_roundtrip.yml"
MOCK_YAML_CONTENT = {
    "version": "1.0.0",
    "registers": [
        {"name": "REG_A", "address": 0, "access": "rw", "description": "Test A"},
        {"name": "REG_B", "address": 4, "access": "ro", "description": "Test B"},
    ],
}


class TestEncoderDecoderRoundtrip(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory for outputs
        self.test_dir = CURRENT_DIR / "roundtrip_output"
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.test_dir.mkdir()

        # Write mock YAML
        self.yaml_path = self.test_dir / MOCK_YAML
        with open(self.yaml_path, "w") as f:
            yaml.dump(MOCK_YAML_CONTENT, f)

    def tearDown(self):
        # Cleanup
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

    def run_command(self, cmd):
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=self.test_dir)
        if result.returncode != 0:
            print(f"Command failed: {' '.join(str(c) for c in cmd)}")
            print("STDOUT:", result.stdout)
            print("STDERR:", result.stderr)
        self.assertEqual(result.returncode, 0)
        return result

    def test_raw_roundtrip(self):
        """Test YAML -> Raw Hex -> Decode -> Match text"""
        # 1. Encode to raw hex (default)
        self.run_command(["python3", str(ENCODER), MOCK_YAML])

        # 2. Decode from hex back to text
        self.run_command(["python3", str(DECODER), "regbank_manifest.hex", "--out", "decoded.txt"])

        decoded_text = (self.test_dir / "decoded.txt").read_text()
        original_text = self.yaml_path.read_text()

        # Clean up whitespace for comparison
        self.assertEqual(decoded_text.strip(), original_text.strip())

    def test_raw_roundtrip_with_json(self):
        """Test YAML -> Raw Hex -> Decode -> JSON -> Match dict"""
        # 1. Encode to raw hex (default)
        self.run_command(["python3", str(ENCODER), MOCK_YAML])

        # 2. Decode from hex to JSON (decoder parses YAML text internally)
        self.run_command(["python3", str(DECODER), "regbank_manifest.hex", "--json", "decoded.json"])

        with open(self.test_dir / "decoded.json", "r") as f:
            decoded_data = json.load(f)

        # Compare with original content
        self.assertEqual(decoded_data["version"], MOCK_YAML_CONTENT["version"])
        self.assertEqual(len(decoded_data["registers"]), len(MOCK_YAML_CONTENT["registers"]))
        self.assertEqual(decoded_data["registers"][0]["name"], "REG_A")


if __name__ == "__main__":
    unittest.main()
