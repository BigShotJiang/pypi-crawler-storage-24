# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import subprocess
import tempfile
import unittest
from pathlib import Path

import yaml

# Paths to tools (Relative to this test file: ../)
CURRENT_DIR = Path(__file__).parent.absolute()
TOOLS_DIR = CURRENT_DIR.parent

ENCODER = TOOLS_DIR / "payload_encoder.py"
DECODER = TOOLS_DIR / "payload_decoder.py"
GEN_PKG = TOOLS_DIR / "generate_regbank_pkg.py"
GEN_INFO = TOOLS_DIR / "gen_info_pkg.py"
MD_GEN = TOOLS_DIR / "markdown_encoder.py"
YML_CSV = TOOLS_DIR / "yml_to_csv.py"
BIN_HEX = TOOLS_DIR / "bin_to_hex.py"

# Test Data
MOCK_YAML = "mock_regs.yml"
MOCK_YAML_CONTENT = {
    "version": "1.2.3",
    "registers": [
        {"name": "TEST_REG_1", "address": "0x0", "access": "rw", "description": "Simple RW register", "format": "hex"},
        {
            "name": "TEST_REG_2",
            "address": "0x4",
            "access": "ro",
            "description": "Read only register",
            "fields": [
                {"name": "FIELD_A", "bits": [0], "description": "Bit 0"},
                {"name": "FIELD_B", "bits": [31, 16], "description": "Upper half"},
            ],
        },
        {
            "name": "SYSTEM_FW_VERSION",
            "address": "0x8",
            "access": "ro",
            "description": "Version constant from external",
        },
    ],
}


class TestRegbankUtils(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory for outputs
        self._temp_dir_obj = tempfile.TemporaryDirectory()
        self.test_dir = Path(self._temp_dir_obj.name)

        # Write mock YAML
        with open(self.test_dir / MOCK_YAML, "w") as f:
            yaml.dump(MOCK_YAML_CONTENT, f)

    def tearDown(self):
        # Cleanup matches setUp
        self._temp_dir_obj.cleanup()

    def run_command(self, cmd):
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=self.test_dir)
        if result.returncode != 0:
            print(f"Command failed: {' '.join(str(c) for c in cmd)}")
            print("STDOUT:", result.stdout)
            print("STDERR:", result.stderr)
        self.assertEqual(result.returncode, 0)
        return result

    def test_encoding_decoding_defaults(self):
        """Test default raw encoding and decoding"""
        # Encode (defaults to raw)
        self.run_command(["python3", str(ENCODER), MOCK_YAML])

        hex_file = self.test_dir / "regbank_manifest.hex"
        bin_file = self.test_dir / "regbank_manifest.bin"

        self.assertTrue(hex_file.exists())
        self.assertTrue(bin_file.exists())

        # Decode (defaults to raw)
        res = self.run_command(["python3", str(DECODER), "regbank_manifest.bin", "--out", "decoded.txt"])
        decoded_txt = self.test_dir / "decoded.txt"
        self.assertTrue(decoded_txt.exists())

    def test_vhdl_generation(self):
        """Test VHDL package generation and System naming"""
        output_vhd = "system_regbank_pkg.vhd"
        self.run_command(["python3", str(GEN_PKG), MOCK_YAML, output_vhd])

        vhd_path = self.test_dir / output_vhd
        self.assertTrue(vhd_path.exists())

        content = vhd_path.read_text()
        self.assertIn("package system_regbank_pkg is", content)
        self.assertIn("constant C_REGBANK_DEPTH", content)
        self.assertIn("constant C_NUM_USER_REGS", content)
        # Check for external constant mapping
        self.assertIn("C_SYSTEM_VERSION", content)  # From EXTERNAL_CONSTANTS

    def test_markdown_generation(self):
        """Test Markdown generation"""
        self.run_command(["python3", str(MD_GEN), MOCK_YAML])
        md_path = self.test_dir / "register_bank.md"  # Default name
        self.assertTrue(md_path.exists())
        content = md_path.read_text()
        self.assertIn("|Name|Address|Access|Description|", content.replace(" ", ""))
        self.assertIn("TEST_REG_1", content)

    def test_csv_export(self):
        """Test CSV export tool"""
        csv_out = "regs.csv"
        self.run_command(["python3", str(YML_CSV), MOCK_YAML, csv_out])
        csv_path = self.test_dir / csv_out
        self.assertTrue(csv_path.exists())
        content = csv_path.read_text()
        self.assertIn("TEST_REG_1,0x0,rw", content)

    def test_real_schema_schema(self):
        """Test that the real regbank_schema.yml in the repo is valid"""
        real_schema = TOOLS_DIR / "regbank_schema.yml"
        if not real_schema.exists():
            self.skipTest(f"Real schema not found at {real_schema}")

        # Test encoding (this validates the schema structure and logic)
        self.run_command(["python3", str(ENCODER), str(real_schema)])


if __name__ == "__main__":
    unittest.main()
