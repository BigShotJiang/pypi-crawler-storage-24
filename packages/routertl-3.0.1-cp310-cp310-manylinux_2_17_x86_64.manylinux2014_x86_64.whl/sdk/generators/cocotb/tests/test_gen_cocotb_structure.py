#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Regression tests for cocotb-testgen (gen_cocotb_structure.py).
Tests that the tool correctly generates test stubs in configurable paths.
"""

import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
TESTGEN_SCRIPT = REPO_ROOT / "tools" / "cocotb-testgen" / "gen_cocotb_structure.py"

# Minimal VHDL entity for testing
SAMPLE_VHDL = """
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity sample_module is
    generic (
        WIDTH : integer := 8
    );
    port (
        clk   : in  std_logic;
        rst   : in  std_logic;
        data  : in  std_logic_vector(WIDTH-1 downto 0);
        valid : out std_logic
    );
end entity sample_module;

architecture rtl of sample_module is
begin
    valid <= '1';
end architecture rtl;
"""


class TestCocotbTestgen(unittest.TestCase):
    def setUp(self):
        """Create a temporary directory structure."""
        self.test_dir = tempfile.mkdtemp()

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.test_dir)

    def test_default_paths(self):
        """Test with default paths (src -> sim/cocotb/tests)."""
        src_dir = Path(self.test_dir) / "src"
        out_dir = Path(self.test_dir) / "sim" / "cocotb" / "tests"
        src_dir.mkdir(parents=True)

        # Create sample VHDL file
        (src_dir / "sample_module.vhd").write_text(SAMPLE_VHDL)

        # Run testgen
        result = subprocess.run(
            ["python3", str(TESTGEN_SCRIPT), "--src", str(src_dir), "--out", str(out_dir)],
            capture_output=True,
            text=True,
            cwd=self.test_dir,
        )

        self.assertEqual(result.returncode, 0, f"testgen failed: {result.stderr}")

        # Verify output - testgen creates test_<module>.py directly in out_dir
        expected_test = out_dir / "test_sample_module.py"
        self.assertTrue(expected_test.exists(), f"Expected test file not found: {expected_test}")

    def test_custom_paths(self):
        """Test with custom paths (hw/rtl -> hw/tests)."""
        src_dir = Path(self.test_dir) / "hw" / "rtl"
        out_dir = Path(self.test_dir) / "hw" / "tests"
        src_dir.mkdir(parents=True)

        # Create sample VHDL file in custom location
        (src_dir / "custom_module.vhd").write_text(SAMPLE_VHDL.replace("sample_module", "custom_module"))

        # Run testgen with custom paths
        result = subprocess.run(
            ["python3", str(TESTGEN_SCRIPT), "--src", str(src_dir), "--out", str(out_dir)],
            capture_output=True,
            text=True,
            cwd=self.test_dir,
        )

        self.assertEqual(result.returncode, 0, f"testgen failed: {result.stderr}")

        # Verify output in custom location
        expected_test = out_dir / "test_custom_module.py"
        self.assertTrue(expected_test.exists(), f"Expected test file not found at custom path: {expected_test}")

    def test_nested_directory_structure(self):
        """Test that nested source directories are handled correctly."""
        src_dir = Path(self.test_dir) / "src"
        out_dir = Path(self.test_dir) / "tests"
        nested_src = src_dir / "subsystem" / "protocol"
        nested_src.mkdir(parents=True)

        # Create VHDL in nested location
        (nested_src / "uart_rx.vhd").write_text(SAMPLE_VHDL.replace("sample_module", "uart_rx"))

        result = subprocess.run(
            ["python3", str(TESTGEN_SCRIPT), "--src", str(src_dir), "--out", str(out_dir)],
            capture_output=True,
            text=True,
            cwd=self.test_dir,
        )

        self.assertEqual(result.returncode, 0, f"testgen failed: {result.stderr}")

        # The tool should create tests preserving some structure
        # Check that a test file was created somewhere under out_dir
        test_files = list(out_dir.rglob("test_uart_rx.py"))
        self.assertGreater(len(test_files), 0, "No test file found for nested module")

    def test_idempotency(self):
        """Test that running twice doesn't duplicate content."""
        src_dir = Path(self.test_dir) / "src"
        out_dir = Path(self.test_dir) / "tests"
        src_dir.mkdir(parents=True)

        (src_dir / "idempotent_module.vhd").write_text(SAMPLE_VHDL.replace("sample_module", "idempotent_module"))

        # Run twice
        for _ in range(2):
            result = subprocess.run(
                ["python3", str(TESTGEN_SCRIPT), "--src", str(src_dir), "--out", str(out_dir)],
                capture_output=True,
                text=True,
                cwd=self.test_dir,
            )
            self.assertEqual(result.returncode, 0)

        # Check that only one test file exists (not duplicated)
        test_files = list(out_dir.rglob("test_idempotent_module.py"))
        self.assertEqual(len(test_files), 1, "Test file was duplicated")


if __name__ == "__main__":
    unittest.main()
