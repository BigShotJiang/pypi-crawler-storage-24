# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import sys
import tempfile
import zipfile
from pathlib import Path

import pytest
import yaml

# Add linux-utils to sys.path
TOOLS_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(TOOLS_DIR))

from xsa_parser import XSAParser, cross_check

MOCK_HWH_XML = """<?xml version="1.0" encoding="UTF-8"?>
<EDKSYSTEM>
  <MODULESMAP>
    <MODULE INSTANCE="system_regs">
      <PARAMETERS>
        <PARAMETER NAME="C_BASEADDR" VALUE="0x43C00000"/>
        <PARAMETER NAME="C_HIGHADDR" VALUE="0x43C00FFF"/>
      </PARAMETERS>
      <PORTS>
        <PORT DIR="O" NAME="irq" SIGIS="INTERRUPT"/>
      </PORTS>
    </MODULE>
    <MODULE INSTANCE="axi_dma_0">
      <MEMORYMAP>
        <ADDRESSBLOCK BASEVALUE="0x43C20000" HIGHVALUE="0x43C2FFFF"/>
      </MEMORYMAP>
    </MODULE>
  </MODULESMAP>
</EDKSYSTEM>
"""


@pytest.fixture
def mock_env():
    # 1. Create a dummy memory map
    data = {
        "version": "1.0.0",
        "target": "zynq-7000",
        "devices": [
            {"name": "system_regs", "base_addr": "0x43C00000", "span": "0x1000"},
            {"name": "axi_dma_0", "base_addr": "0x43C20000", "span": "0x10000"},
        ],
    }

    with tempfile.TemporaryDirectory() as temp_dir:
        yaml_path = os.path.join(temp_dir, "mmap.yml")
        with open(yaml_path, "w") as f:
            yaml.dump(data, f)

        # 2. Create a dummy XSA (ZIP wrapping the HWH)
        hwh_path = os.path.join(temp_dir, "design_1.hwh")
        with open(hwh_path, "w") as f:
            f.write(MOCK_HWH_XML)

        xsa_path = os.path.join(temp_dir, "design_1.xsa")
        with zipfile.ZipFile(xsa_path, "w") as z:
            z.write(hwh_path, arcname="design_1.hwh")

        yield yaml_path, xsa_path


def test_xsa_parser_extraction(mock_env):
    yaml_path, xsa_path = mock_env

    parser = XSAParser(xsa_path)
    # Check parameters-style parsing + interrupts
    info1 = parser.get_module_info("system_regs")
    assert info1 is not None
    assert info1["base_addr"] == 0x43C00000
    assert info1["high_addr"] == 0x43C00FFF
    assert "irq" in info1["interrupts"]

    # Check addressblock-style parsing
    info2 = parser.get_module_info("axi_dma_0")
    assert info2 is not None
    assert info2["base_addr"] == 0x43C20000
    assert info2["interrupts"] == []

    # Check non-existent
    assert parser.get_module_info("does_not_exist") is None


def test_cross_check_success(mock_env, capsys):
    yaml_path, xsa_path = mock_env
    # Should return True because addresses match
    assert cross_check(yaml_path, xsa_path) is True

    captured = capsys.readouterr()
    assert "Verification Passed" in captured.out
    assert "Address match: 'system_regs'" in captured.out


def test_cross_check_failure(mock_env, capsys):
    yaml_path, xsa_path = mock_env

    # Corrupt the YAML
    with open(yaml_path, "r") as f:
        data = yaml.safe_load(f)
    data["devices"][0]["base_addr"] = "0x12345678"  # Wrong!
    with open(yaml_path, "w") as f:
        yaml.dump(data, f)

    assert cross_check(yaml_path, xsa_path) is False

    captured = capsys.readouterr()
    assert "Verification Failed" in captured.out
    assert "Address Mismatch for 'system_regs'" in captured.out
