# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

# Add linux-utils to sys.path so we can import directly
TOOLS_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(TOOLS_DIR))

from generate_dtbo import generate_dts
from generate_uio_bindings import generate_python
from generate_uio_header import generate_header
from memory_map_parser import MemoryMapParser


@pytest.fixture
def sample_yaml():
    data = {
        "version": "1.0.0",
        "target": "zynq-7000",
        "devices": [
            {"name": "ctrl_regs", "base_addr": "0x43C00000", "span": "0x1000", "compatible": "generic-uio"},
            {"name": "data_buffer", "base_addr": 0x43C10000, "span": 4096, "uio": False},
        ],
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
        yaml.dump(data, f)
        temp_path = f.name
    yield temp_path
    os.remove(temp_path)


def test_parser_basic(sample_yaml):
    parser = MemoryMapParser(sample_yaml)
    assert parser.target == "zynq-7000"
    assert len(parser.devices) == 2
    assert parser.devices[0]["base_addr"] == 0x43C00000
    assert parser.devices[1]["span"] == 4096


def test_parser_uio_filter(sample_yaml):
    parser = MemoryMapParser(sample_yaml)
    uio_devs = parser.get_uio_devices()
    assert len(uio_devs) == 1
    assert uio_devs[0]["name"] == "ctrl_regs"


def test_generate_dts(sample_yaml):
    parser = MemoryMapParser(sample_yaml)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".dts", delete=False) as f:
        temp_dts = f.name

    generate_dts(parser, temp_dts)

    with open(temp_dts, "r") as f:
        content = f.read()
        assert "/dts-v1/;" in content
        assert "/plugin/;" in content
        assert "ctrl_regs@43c00000" in content
        assert "reg = <0x43c00000 0x1000>;" in content
        assert "data_buffer" not in content  # Should be skipped (uio: false)

    os.remove(temp_dts)


def test_generate_header(sample_yaml):
    parser = MemoryMapParser(sample_yaml)
    dev = parser.devices[0]  # ctrl_regs

    with tempfile.TemporaryDirectory() as temp_dir:
        generate_header(dev, None, temp_dir)
        header_path = os.path.join(temp_dir, "ctrl_regs_uio.h")
        assert os.path.exists(header_path)
        with open(header_path, "r") as f:
            content = f.read()
            assert "#define CTRL_REGS_BASE_ADDR 0x43c00000" in content
            assert "#define CTRL_REGS_SPAN      0x1000" in content


def test_generate_python(sample_yaml):
    parser = MemoryMapParser(sample_yaml)
    dev = parser.devices[0]  # ctrl_regs

    with tempfile.TemporaryDirectory() as temp_dir:
        generate_python(dev, None, temp_dir)
        py_path = os.path.join(temp_dir, "ctrl_regs_uio.py")
        assert os.path.exists(py_path)
        with open(py_path, "r") as f:
            content = f.read()
            assert "class CtrlRegsUIO:" in content
            assert "self.REGMAP = {}" in content  # No regbank provided
            assert "self.fd = os.open(self.dev_path" in content
