# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import shutil
import subprocess
import unittest
from pathlib import Path

HAS_RADIANTC = shutil.which("radiantc") is not None
HAS_QUARTUS = shutil.which("quartus_sh") is not None

# Setup paths
CURRENT_DIR = Path(__file__).parent.absolute()
REPO_ROOT = CURRENT_DIR.parent.parent.parent
MOCKS_DIR = CURRENT_DIR / "mocks"


class TestMakefile(unittest.TestCase):
    def setUp(self):
        """Set up the test fixture with project paths."""
        # Clean previous runs
        log_file = CURRENT_DIR / "call_log.txt"
        if log_file.exists():
            log_file.unlink()

        # Clean build artifacts using Common.mk (consumer-facing targets)
        subprocess.run(
            ["make", "-f", "sdk/Common.mk", "clean"],
            cwd=REPO_ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

        # Add mocks to PATH
        self.env = os.environ.copy()
        self.env["PATH"] = str(MOCKS_DIR) + os.pathsep + self.env["PATH"]

        # Unset PYTHONHOME and PYTHONPATH to prevent conflicts with system python
        if "PYTHONHOME" in self.env:
            del self.env["PYTHONHOME"]
        if "PYTHONPATH" in self.env:
            del self.env["PYTHONPATH"]

        # Backup project.yml
        self.project_yml = REPO_ROOT / "project.yml"
        self.project_yml_backup = None
        if self.project_yml.exists():
            self.project_yml_backup = self.project_yml.read_text()

    def tearDown(self):
        """Restore environment after testing."""
        if hasattr(self, "project_yml_backup") and self.project_yml_backup is not None:
            self.project_yml.write_text(self.project_yml_backup)
        elif self.project_yml.exists():
            self.project_yml.unlink()

    def run_make(self, target, extra_args=None):
        """Run a make target and return the result."""
        cmd = ["make", target]
        if extra_args:
            cmd.extend(extra_args)

        # We override tool paths to point to our PATH-based mocks
        # This assumes 'vivado' and 'radiantc' are in the mocked PATH
        overrides = ["VIVADO_XLNX=vivado", "RADIANT_LATTICE=radiantc"]
        cmd.extend(overrides)

        result = subprocess.run(cmd, cwd=REPO_ROOT, env=self.env, capture_output=True, text=True)
        return result

    def test_synthesis_xilinx(self):
        """Test Xilinx synthesis flow (Common.mk consumer target)"""
        # Set xilinx vendor in project.yml
        (REPO_ROOT / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\nhardware:\n  vendor: xilinx\n  part: xc7z020clg400-1\n"
        )
        res = self.run_make("synthesis", ["-f", "sdk/Common.mk", "VENDOR=xilinx"])

        if res.returncode != 0:
            print("STDOUT:", res.stdout)
            print("STDERR:", res.stderr)

        self.assertEqual(res.returncode, 0)

        # Verify call log
        log_content = (CURRENT_DIR / "call_log.txt").read_text()
        self.assertIn("CALLED: vivado", log_content)
        self.assertIn("gen_synthesis.tcl", log_content)

        # Verify artifact creation (mock should have created it)
        self.assertTrue((REPO_ROOT / "dcp" / "synthesis.dcp").exists())

    @unittest.skipUnless(HAS_RADIANTC, "radiantc not installed")
    def test_synthesis_lattice(self):
        """Test Lattice synthesis flow"""
        # Set lattice vendor in project.yml
        (REPO_ROOT / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\nhardware:\n  vendor: lattice\n  part: iCE40UP5K-SG48I\n"
        )
        res = self.run_make("synthesis", ["VENDOR=lattice"])
        self.assertEqual(res.returncode, 0)

        log_file = CURRENT_DIR / "call_log.txt"
        if log_file.exists():
            log_content = log_file.read_text()
            self.assertIn("CALLED: radiantc", log_content)
            self.assertIn("gen_synthesis.tcl", log_content)

        self.assertTrue((REPO_ROOT / "dcp" / "synthesis.udp").exists())

    @unittest.skipUnless(
        (REPO_ROOT / ".git" / "hooks").is_dir(),
        "Not inside a Git repo with .git/hooks",
    )
    def test_install_hooks(self):
        """Test install-hooks target"""
        hook_path = REPO_ROOT / ".git" / "hooks" / "pre-commit"
        if hook_path.exists():
            hook_path.unlink()

        res = self.run_make("install-hooks")
        self.assertEqual(res.returncode, 0)

        self.assertTrue(hook_path.exists())
        self.assertTrue(os.access(hook_path, os.X_OK))

    def test_linting(self):
        """Test linting target (Common.mk consumer target)"""
        # We need to mock ghdl for the linting script to work
        ghdl_mock = MOCKS_DIR / "ghdl"
        if not ghdl_mock.exists():
            ghdl_mock.write_text("#!/bin/bash\necho 'Mock GHDL called'\nexit 0")
            ghdl_mock.chmod(0o755)

        res = self.run_make("linting", ["-f", "sdk/Common.mk"])
        self.assertEqual(res.returncode, 0)
        # Smart Linter replaced the old GHDL-based linting
        self.assertIn("RouteRTL Smart Linter", res.stdout)

    @unittest.skipUnless(HAS_QUARTUS, "quartus_sh not installed")
    def test_synthesis_altera(self):
        """Test Altera synthesis flow (Common.mk consumer target)"""
        # Set altera vendor in project.yml
        (REPO_ROOT / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\nhardware:\n  vendor: altera\n  part: 10M50DAF484C7G\n"
        )

        # Mock quartus_sh
        quartus_mock = MOCKS_DIR / "quartus_sh"
        if not quartus_mock.exists():
            quartus_mock.write_text(
                '#!/bin/bash\nLOG_FILE=$(cd $(dirname $0)/.. && pwd)/call_log.txt\necho "CALLED: quartus_sh $@" >> "$LOG_FILE"\nexit 0'
            )
            quartus_mock.chmod(0o755)

        res = self.run_make("synthesis", ["-f", "sdk/Common.mk", "VENDOR=altera", "TOOL_CMD=quartus_sh"])
        self.assertEqual(res.returncode, 0)

        # Altera synthesis should invoke quartus_sh via call_log
        log_file = CURRENT_DIR / "call_log.txt"
        if log_file.exists():
            log_content = log_file.read_text()
            self.assertIn("CALLED: quartus_sh", log_content)

    def test_sources_target(self):
        """Test 'make sources' target (in Common.mk)"""
        # We must point to Common.mk explicitly since it's checking client-facing targets
        res = self.run_make("sources", extra_args=["-f", "sdk/Common.mk"])
        if res.returncode != 0:
            print("STDOUT:", res.stdout)
            print("STDERR:", res.stderr)
        self.assertEqual(res.returncode, 0)

        # We expect specific headers from the output
        self.assertIn("--- Project Source Manifest ---", res.stdout)
        self.assertIn("Synthesis Files (SYN_FILES):", res.stdout)
        self.assertIn("Simulation Files (SIM_FILES):", res.stdout)
        self.assertIn("Constraint Files (XDC_FILES):", res.stdout)
        self.assertIn("Linting Files (LIN_FILES):", res.stdout)


if __name__ == "__main__":
    unittest.main()
