# === RouteRTL SDK — Simulation & Testing Targets ===
# Requires: platform.mk (SDK_ROOT, ROOT_DIR, SIM_DIR, etc.)

# ====================================================================================
# 🧪 Simulation & Testing
# ====================================================================================
WAVES ?= 1 # Default to generating waveforms
.PHONY: sim generate-tests waves

# --- Simulation Variables ---
# SIM_PATTERNS: User-friendly test selector. Each space-separated token is auto-
#   wrapped with --pattern <token>.py.  Example:
#     make simulation SIM_PATTERNS="test_smoke test_precommit"
#
# SIM_EXTRA_ARGS: Raw argparse flags passed verbatim to run_tests.py.
#   For power users and hooks that need --exclude or other flags.  Example:
#     make simulation SIM_EXTRA_ARGS="--exclude test_slow.py"
SIM_PATTERNS   ?=
SIM_EXTRA_ARGS ?=


# Convert SIM_PATTERNS tokens into --pattern flags for run_tests.py
_SIM_PATTERN_FLAGS := $(foreach p,$(SIM_PATTERNS),--pattern $(p).py)

# --- Dependency Sentinel ---
# project_manager.py writes .deps.ok after ensure_dependencies() succeeds.
# If missing, dependencies may not have been fetched yet.
.PHONY: check-deps
check-deps:
	@if [ ! -f "$(ROOT_DIR)/.deps.ok" ] && [ -f "$(ROOT_DIR)/$(PROJECT_YML)" ]; then \
		echo "⚠️  Dependencies may not be resolved (.deps.ok missing). Running update-config..."; \
		$(MAKE) update-config; \
	fi

scan-tests: ## List available Cocotb tests (Usage: make scan-tests)
	@echo "🔍 Scanning for tests..."
	@python3 $(SDK_ROOT)/sdk/engine/scan_tests.py --dirs $(SIM_DIR)

update-cicd: ## Update CI/CD pipeline configuration from project.yml
	@echo "🔄 Updating CI/CD configuration..."
	@python3 $(SDK_ROOT)/sdk/engine/update_cicd.py --project $(PROJECT_YML)

sim: | check-deps ## Run simulation (Usage: make sim MODULE=tb_name)
	@if [ -z "$(MODULE)" ]; then \
		echo "❌ Error: MODULE not specified. Use 'make sim MODULE=tb_my_test'"; \
		exit 1; \
	fi
	@# Guard: check NVC availability (generate sdk_env.mk if missing)
	@if [ ! -f "$(SDK_ROOT)/sdk_env.mk" ]; then \
		python3 $(SDK_ROOT)/sdk/engine/check_env.py --generate-mk -q 2>/dev/null || true; \
	fi
	@if [ -f "$(SDK_ROOT)/sdk_env.mk" ] && grep -q 'SDK_HAS_NVC := false' $(SDK_ROOT)/sdk_env.mk; then \
		echo "❌ NVC simulator not found or outdated. Run 'make check-env' for details."; \
		exit 1; \
	fi
	@echo "🚀 Running $(MODULE)..."
	@# Assumes Cocotb/GHDL setup. We can invoke the SDK's sim engine or local logic.
	@# For now, we assume user has a sim/cocotb folder that works, OR we use SDK engine.
	@# We export SDK paths so cocotb can find them.
	@export PYTHONPATH=$(SDK_ROOT)/sim/cocotb/engine:$(PYTHONPATH); \
	export ROUTERTL_ROOT=$(SDK_ROOT); \
	export ROUTERTL_WAVES_DIR=$(SIM_WAVES_DIR); \
	export ROUTERTL_LOGS_DIR=$(SIM_LOGS_DIR); \
	export CLIENT_PROJECT_ROOT=$(ROOT_DIR); \
	export CLIENT_SIM_WORK=$(SIM_DIR)/../../work; \
	export SIM="$${SIM:-$(SIM_BACKEND)}"; \
	export WAVES=$(WAVES); \
	PYTHONPATH=$(ROOT_DIR):$(SDK_ROOT)/sim/cocotb python3 $(SDK_ROOT)/sdk/engine/run_tests.py --dir $(SIM_DIR) --pattern $(MODULE).py

waves: ## Open waveform viewer for a module (Usage: make waves TOP=tb_name)
	@if [ -z "$(TOP)" ]; then echo "❌ Error: TOP not specified."; exit 1; fi
	@# Try to find common waveform formats
	@WAVE_FILE=$$(find sim_build -name "$(TOP).ghw" -o -name "$(TOP).vcd" -o -name "$(TOP).fst" | head -1); \
	if [ -n "$$WAVE_FILE" ]; then \
		echo "🌊 Opening wave file: $$WAVE_FILE"; \
		gtkwave $$WAVE_FILE & \
	else \
		echo "❌ No waveform found for $(TOP). Run simulation first."; \
	fi

.PHONY: sim-waves
sim-waves: ## Run simulation and open waveform viewer (Usage: make sim-waves MODULE=tb_name)
	@$(MAKE) sim MODULE=$(MODULE) WAVES=1
	@$(MAKE) waves TOP=$(MODULE)

# --- Schematic ---
.PHONY: schematic
schematic: ## Generate SVG schematic from RTL (Usage: make schematic TOP=module)
	@if [ -z "$(TOP)" ]; then echo "❌ Error: TOP not specified. Use 'make schematic TOP=my_entity'"; exit 1; fi
	@echo "🔍 Generating schematic for $(TOP)..."
	@python3 $(SDK_ROOT)/sdk/engine/gen_schematic.py --top $(TOP) --src $(SRC_DIR) --out sim/schematics


generate-tests: build_env.mk ## Generate Cocotb test boilerplates for sources
	@echo "Generating tests..."
	@python3 $(COCOTB_TESTGEN)/gen_cocotb_structure.py --src $(SRC_DIR) --out $(SIM_DIR)

.PHONY: testgen
testgen: generate-tests ## Alias for generate-tests

simulation: build_env.mk | check-deps ## Auto-discover and run tests from configured test directory
	@echo "Running tests in $(SIM_DIR)..."
	@export ROUTERTL_ROOT=$(SDK_ROOT); \
	export ROUTERTL_WAVES_DIR=$(SIM_WAVES_DIR); \
	export ROUTERTL_LOGS_DIR=$(SIM_LOGS_DIR); \
	export CLIENT_PROJECT_ROOT=$(ROOT_DIR); \
	export CLIENT_SIM_WORK=$(SIM_DIR)/../../work; \
	export SIM="$${SIM:-$(SIM_BACKEND)}"; \
	export WAVES=$(WAVES); \
	PYTHONPATH=$(ROOT_DIR):$(SDK_ROOT)/sim/cocotb python3 $(SDK_ROOT)/sdk/engine/run_tests.py --dir $(SIM_DIR) $(_SIM_PATTERN_FLAGS) $(SIM_EXTRA_ARGS)

.PHONY: regression
regression: ## Run Project Manager Regression Tests
	@echo "Running Project Manager Regression Tests..."
	@PYTHONPATH=$(ROOT_DIR):$(SDK_ROOT):$(SDK_ROOT)/sim/cocotb python3 $(SDK_ROOT)/sdk/engine/run_tests.py --dir $(SDK_ROOT)/sdk/engine/tests --pattern "test_*.py" $(if $(HOOK_EXCLUDE_TESTS),$(foreach t,$(HOOK_EXCLUDE_TESTS),--exclude $(t)),)
	@echo "Running Linux Utils Unit Tests..."
	@PYTHONPATH=$(ROOT_DIR) python3 -m pytest $(LINUX_UTILS)/tests -v

.PHONY: sim-regression
sim-regression: simulation ## Alias for simulation
