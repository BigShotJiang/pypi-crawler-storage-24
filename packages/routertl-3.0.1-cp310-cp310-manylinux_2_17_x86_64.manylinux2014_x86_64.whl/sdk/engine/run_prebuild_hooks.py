#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Pre-Build Hook Runner

Executes pre-build hooks defined in project.yml before project generation.
Each hook is a script with arguments, with optional output validation.

Usage:
    python run_prebuild_hooks.py [--project project.yml] [--root ROOT_DIR]
"""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

import yaml


def load_project_config(project_path: Path) -> dict:
    """Load project.yml configuration."""
    if not project_path.exists():
        print(f"⚠️  No project.yml found at {project_path}")
        return {}

    with open(project_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def run_hook(hook: dict, root_dir: Path) -> bool:
    """
    Execute a single pre-build hook.

    Returns True if successful, False otherwise.
    """
    name = hook.get("name", "unnamed")
    script = hook.get("script")
    args = hook.get("args", [])
    expected_outputs = hook.get("expected_outputs", [])

    if not script:
        print(f"❌ Hook '{name}' has no script defined")
        return False

    script_path = root_dir / script
    if not script_path.exists():
        print(f"❌ Hook '{name}': Script not found: {script_path}")
        return False

    # ── Clean stale outputs before running ──────────────────────
    clean_before_run = hook.get("clean_before_run", True)
    if clean_before_run and expected_outputs:
        for output in expected_outputs:
            output_path = (root_dir / output).resolve()
            artifact_dir = output_path.parent
            # Safety: never delete root_dir itself or paths outside it
            if artifact_dir == root_dir.resolve():
                continue
            if not artifact_dir.is_relative_to(root_dir.resolve()):
                print(f"   ⚠️  Skipping cleanup of '{output}' — outside project root")
                continue
            if artifact_dir.exists():
                shutil.rmtree(artifact_dir)
                print(
                    f"   🗑  Cleaned stale output: "
                    f"{artifact_dir.relative_to(root_dir.resolve())}"
                )
    elif not clean_before_run and expected_outputs:
        print("   ℹ️  Skipping stale output cleanup (clean_before_run: false)")

    # Build command
    cmd = [sys.executable, str(script_path)] + [str(a) for a in args]

    print(f"🔧 Running hook: {name}")
    print(f"   Command: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            cwd=str(root_dir),
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            print(f"❌ Hook '{name}' failed with exit code {result.returncode}")
            if result.stderr:
                print(f"   stderr: {result.stderr.strip()}")
            return False

        if result.stdout:
            for line in result.stdout.strip().split("\n"):
                print(f"   {line}")

    except OSError as e:
        import logging
        import traceback as _tb

        logging.debug("Pre-build hook '%s' failed:\n%s", name, _tb.format_exc())
        print(f"❌ Hook '{name}' raised exception: {e}")
        return False

    # Validate expected outputs
    if expected_outputs:
        for output in expected_outputs:
            output_path = root_dir / output
            if not output_path.exists():
                print(f"❌ Hook '{name}': Expected output missing: {output}")
                return False
        print(f"   ✓ All {len(expected_outputs)} expected outputs verified")

    return True


def main():
    """CLI entry point for running pre-build hooks."""
    parser = argparse.ArgumentParser(description="Run pre-build hooks from project.yml")
    parser.add_argument("--project", default="project.yml", help="Path to project.yml")
    parser.add_argument("--root", default=".", help="Project root directory")
    args = parser.parse_args()

    root_dir = Path(args.root).resolve()
    project_path = root_dir / args.project

    config = load_project_config(project_path)
    hooks = config.get("hooks", {}).get("pre_build", [])

    if not hooks:
        print("ℹ️  No pre-build hooks configured")
        return 0

    print(f"🔨 Running {len(hooks)} pre-build hook(s)...")

    failed = 0
    for hook in hooks:
        if not run_hook(hook, root_dir):
            failed += 1

    if failed:
        print(f"\n❌ {failed}/{len(hooks)} hook(s) failed")
        return 1

    print(f"\n✅ All {len(hooks)} hook(s) completed successfully")
    return 0


if __name__ == "__main__":
    sys.exit(main())
