# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
IP Manifest Resolver for RouteRTL SDK.

Parses ip.yml manifests, validates vendor compatibility, resolves
recursive IP-to-IP dependencies, and classifies files by synthesis mode.
"""

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

import yaml

logger = logging.getLogger(__name__)

# ── Valid synthesis modes ──────────────────────────────────────
VALID_MODES = {"rtl", "xci", "qsys", "ipx", "cxz", "netlist", "ooc_dcp"}

# Vendor → which modes are legal
VENDOR_MODES = {
    "xilinx": {"rtl", "xci", "netlist", "ooc_dcp"},
    "altera": {"rtl", "qsys", "netlist"},
    "lattice": {"rtl", "ipx", "netlist"},
    "microchip": {"rtl", "cxz", "netlist"},
}

# Mode → human-readable description
MODE_DESCRIPTIONS = {
    "rtl": "RTL sources (compiled with top)",
    "xci": "Xilinx IP Catalog entry (.xci)",
    "qsys": "Intel Platform Designer entry (.qsys)",
    "ipx": "Lattice Radiant IP entry (.ipx)",
    "cxz": "Microchip Libero SmartDesign (.cxz)",
    "netlist": "Pre-compiled netlist (.edf/.ngc)",
    "ooc_dcp": "Xilinx Out-of-Context checkpoint (.dcp)",
}


@dataclass
class IpManifest:
    """Parsed representation of a single ip.yml file."""

    name: str
    path: Path  # Absolute path to the ip.yml file
    ip_dir: Path  # Absolute path to the directory containing ip.yml
    mode: str  # Synthesis mode
    library: str  # VHDL library name
    language: str  # vhdl | systemverilog | mixed
    sources: List[str]  # Absolute paths to source/IP files
    source_scan_dir: Optional[str]  # Relative scan dir from paths.sources
    children: List["IpManifest"] = field(default_factory=list)

    @property
    def source_count(self) -> int:
        """Return the number of source files in this IP."""
        return len(self.sources)


@dataclass
class IpResolutionResult:
    """Result of resolving all IPs from project.yml."""

    syn_files: List[str] = field(default_factory=list)
    xci_files: List[str] = field(default_factory=list)
    netlist_files: List[str] = field(default_factory=list)
    ooc_dcp_files: List[str] = field(default_factory=list)
    libraries: Dict[str, List[str]] = field(default_factory=dict)
    manifests: List[IpManifest] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class IpResolver:
    """
    Resolves ip.yml manifests referenced from project.yml.

    Validates vendor compatibility, resolves recursive IP dependencies,
    and classifies files into SYN_FILES, XCI_FILES, NETLIST_FILES, etc.
    """

    def __init__(self, project_root: Path, vendor: str):
        """Create an IP resolver for the given IP directory."""
        self.project_root = Path(project_root).resolve()
        self.vendor = vendor.lower()
        self._resolved_paths: Set[str] = set()  # Cycle detection (absolute paths)
        self._resolution_stack: List[str] = []  # For error messages

    def resolve(self, ip_yml_paths: List[str]) -> IpResolutionResult:
        """
        Resolve a list of ip.yml paths (relative to project root).

        Returns an IpResolutionResult with classified files and any errors.
        """
        result = IpResolutionResult()

        for ip_path_str in ip_yml_paths:
            ip_path = (self.project_root / ip_path_str).resolve()
            self._resolution_stack = []
            self._resolve_one(ip_path, result)

        return result

    def _resolve_one(self, ip_path: Path, result: IpResolutionResult) -> Optional[IpManifest]:
        """Resolve a single ip.yml, recursing into child IPs."""

        abs_key = str(ip_path)

        # ── Cycle detection ──
        if abs_key in self._resolution_stack:
            cycle = " → ".join(self._resolution_stack + [abs_key])
            result.errors.append(f"Circular IP dependency detected: {cycle}")
            return None

        # ── Deduplication ──
        if abs_key in self._resolved_paths:
            return None  # Already resolved, skip silently

        self._resolution_stack.append(abs_key)

        # ── Load YAML ──
        if not ip_path.exists():
            result.errors.append(
                f"IP manifest not found: {ip_path} "
                f"(referenced from {self._resolution_stack[-2] if len(self._resolution_stack) > 1 else 'project.yml'})"
            )
            self._resolution_stack.pop()
            return None

        try:
            with open(ip_path, "r") as f:
                data = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            result.errors.append(f"Failed to parse {ip_path}: {e}")
            self._resolution_stack.pop()
            return None

        # ── Validate schema ──
        manifest = self._validate_and_build(ip_path, data, result)
        if manifest is None:
            self._resolution_stack.pop()
            return None

        # ── Resolve child IPs first (depth-first) ──
        child_ips = data.get("ips", [])
        for child_path_str in child_ips:
            child_path = (manifest.ip_dir / child_path_str).resolve()
            child = self._resolve_one(child_path, result)
            if child is not None:
                manifest.children.append(child)

        # ── Classify this IP's files ──
        self._classify(manifest, result)

        self._resolved_paths.add(abs_key)
        result.manifests.append(manifest)
        self._resolution_stack.pop()
        return manifest

    def _validate_and_build(self, ip_path: Path, data: dict, result: IpResolutionResult) -> Optional[IpManifest]:
        """Validate ip.yml schema and build an IpManifest."""

        ip_dir = ip_path.parent
        ip_section = data.get("ip", {})

        # ── Required: ip.name ──
        name = ip_section.get("name")
        if not name:
            result.errors.append(f"Missing 'ip.name' in {ip_path}")
            return None

        # ── Synthesis section ──
        syn_section = data.get("synthesis", {})
        mode = syn_section.get("mode", "rtl")

        if mode not in VALID_MODES:
            result.errors.append(
                f"IP '{name}': invalid synthesis.mode '{mode}'. Valid modes: {', '.join(sorted(VALID_MODES))}"
            )
            return None

        # ── Vendor compatibility ──
        allowed = VENDOR_MODES.get(self.vendor, set())
        if mode not in allowed:
            result.errors.append(
                f"❌ IP '{name}' uses mode '{mode}' which is incompatible "
                f"with vendor '{self.vendor}'. "
                f"Allowed modes for {self.vendor}: {', '.join(sorted(allowed))}"
            )
            return None

        # ── Optional fields ──
        library = ip_section.get("library", "work")
        language = ip_section.get("language", "vhdl")

        # ── Paths ──
        paths_section = data.get("paths", {})
        source_scan_dir = paths_section.get("sources")

        # ── Sources ──
        raw_sources = syn_section.get("sources", [])
        abs_sources = []
        for src in raw_sources:
            abs_src = (ip_dir / src).resolve()
            abs_sources.append(str(abs_src))

        return IpManifest(
            name=name,
            path=ip_path,
            ip_dir=ip_dir,
            mode=mode,
            library=library,
            language=language,
            sources=abs_sources,
            source_scan_dir=source_scan_dir,
        )

    def _classify(self, manifest: IpManifest, result: IpResolutionResult):
        """Route an IP's sources into the correct output list."""

        # Convert absolute paths to project-relative for Make variables
        rel_sources = []
        for src in manifest.sources:
            try:
                rel = os.path.relpath(src, self.project_root)
                rel_sources.append(rel)
            except ValueError:
                rel_sources.append(src)

        mode = manifest.mode
        if mode == "rtl":
            result.syn_files.extend(rel_sources)
            # Register library mapping
            if manifest.library != "work":
                if manifest.library not in result.libraries:
                    result.libraries[manifest.library] = []
                result.libraries[manifest.library].extend(rel_sources)

        elif mode in ("xci", "qsys", "ipx", "cxz"):
            result.xci_files.extend(rel_sources)

        elif mode == "netlist":
            result.netlist_files.extend(rel_sources)

        elif mode == "ooc_dcp":
            result.ooc_dcp_files.extend(rel_sources)


def print_ip_list(result: IpResolutionResult):
    """Print a summary table of resolved IPs."""
    if not result.manifests:
        print("  No IPs found in project.yml sources.ips")
        return

    print(f"\n🧩 IP Manifest Summary ({len(result.manifests)} IPs)\n")
    for m in result.manifests:
        lib_info = f"library={m.library}" if m.library != "work" else "—"
        count = f"{m.source_count} {'source' if m.source_count == 1 else 'sources'}"
        if m.mode in ("xci", "qsys", "ipx", "cxz"):
            count = f"{m.source_count} IP {'file' if m.source_count == 1 else 'files'}"
        elif m.mode in ("netlist", "ooc_dcp"):
            count = f"{m.source_count} {'netlist' if m.source_count == 1 else 'netlists'}"

        print(f"  ✅ {m.name:<25} {m.mode:<10} {lib_info:<20} {count}")
    print()


def print_ip_hierarchy(result: IpResolutionResult, indent: int = 0):
    """Print a tree view of IP dependencies."""
    if not result.manifests:
        print("  No IPs found in project.yml sources.ips")
        return

    if indent == 0:
        print("\n🌳 IP Dependency Tree\n")

    # Build a set of all child paths so we only print top-level roots
    child_paths = set()
    for m in result.manifests:
        for c in m.children:
            child_paths.add(str(c.path))

    roots = [m for m in result.manifests if str(m.path) not in child_paths]

    for i, m in enumerate(roots):
        is_last = i == len(roots) - 1
        _print_tree_node(m, "", is_last)
    print()


def _print_tree_node(manifest: IpManifest, prefix: str, is_last: bool):
    """Recursively print a tree node."""
    connector = "└── " if is_last else "├── "
    count_label = f"{manifest.source_count} file{'s' if manifest.source_count != 1 else ''}"
    print(f"{prefix}{connector}{manifest.name} ({manifest.mode}, {count_label})")

    new_prefix = prefix + ("    " if is_last else "│   ")
    for i, child in enumerate(manifest.children):
        child_is_last = i == len(manifest.children) - 1
        _print_tree_node(child, new_prefix, child_is_last)


def load_ips_from_project(project_yml_path: str) -> tuple:
    """
    Load IP paths and vendor from a project.yml.

    Returns (ip_paths, vendor, project_root) or raises on error.
    """
    project_root = Path(project_yml_path).resolve().parent

    with open(project_yml_path, "r") as f:
        config = yaml.safe_load(f) or {}

    vendor = config.get("hardware", {}).get("vendor", "xilinx")
    ip_paths = config.get("sources", {}).get("ips", [])

    return ip_paths, vendor, project_root
