# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

# Paths
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()


class TestClientIntegration(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory for the client project
        self.test_dir = tempfile.mkdtemp(prefix="routertl_client_test_")
        self.client_dir = Path(self.test_dir)

        # Scrub env
        # Scrub env - DISABLED for OSS CAD Suite compatibility
        self.env = os.environ.copy()
        # if "PYTHONHOME" in self.env: del self.env["PYTHONHOME"]
        # if "PYTHONPATH" in self.env: del self.env["PYTHONPATH"]

        # ── Guard: snapshot the real submodule's git config ──
        # `git submodule add file://<repo>` rewrites core.worktree and sets
        # core.bare=true in the *source* repo's submodule git config.  We
        # snapshot these values here and restore them in tearDown to prevent
        # this side-effect from breaking the real repo.
        self._submod_config = REPO_ROOT / ".git" / "modules" / "vendor" / "routertl" / "config"
        self._saved_worktree = None
        self._saved_bare = None  # None means "was not set"
        if self._submod_config.exists():
            try:
                r = subprocess.run(
                    ["git", "config", "--file", str(self._submod_config), "core.worktree"],
                    capture_output=True,
                    text=True,
                )
                if r.returncode == 0:
                    self._saved_worktree = r.stdout.strip()
                r = subprocess.run(
                    ["git", "config", "--file", str(self._submod_config), "core.bare"], capture_output=True, text=True
                )
                if r.returncode == 0:
                    self._saved_bare = r.stdout.strip()
            except Exception:
                pass

    def tearDown(self):
        # ── Restore the real submodule's git config ──
        if self._submod_config.exists():
            if self._saved_worktree:
                subprocess.run(
                    ["git", "config", "--file", str(self._submod_config), "core.worktree", self._saved_worktree],
                    capture_output=True,
                )
            # Restore core.bare to its original state
            if self._saved_bare is None:
                # Was not set before → remove if the test added it
                subprocess.run(
                    ["git", "config", "--file", str(self._submod_config), "--unset", "core.bare"], capture_output=True
                )
            else:
                subprocess.run(
                    ["git", "config", "--file", str(self._submod_config), "core.bare", self._saved_bare],
                    capture_output=True,
                )
        # Cleanup
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def run_cmd(self, cmd, cwd=None):
        if cwd is None:
            cwd = self.client_dir
        print(f"Running: {' '.join(cmd)} in {cwd}")
        res = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, env=self.env)
        if res.returncode != 0:
            print(f"STDOUT: {res.stdout}")
            print(f"STDERR: {res.stderr}")
        return res

    def check_tool(self, tool_name):
        try:
            # Using --version is more robust than "which"
            subprocess.run([tool_name, "-version"], capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def _setup_client_project(self):
        """Shared setup: git init + submodule add + init_project.

        Returns True if setup succeeded, False if skipped.
        Sets up self.client_dir with a full SDK submodule project.
        """
        if "GIT_DIR" in os.environ:
            self.skipTest("git submodule unavailable in pre-commit hook context (GIT_DIR is set)")

        # 1. Initialize Client Repo
        self.run_cmd(["git", "init"])

        # 2. Add SDK as Submodule
        sdk_url = f"file://{REPO_ROOT}"
        res = self.run_cmd(["git", "-c", "protocol.file.allow=always", "submodule", "add", sdk_url, "vendor/routertl"])
        self.assertEqual(res.returncode, 0, f"Failed to add SDK submodule:\n{res.stderr}")

        # 3. Run Init Project
        init_script = self.client_dir / "vendor/routertl/sdk/engine/init_project.py"
        self.assertTrue(init_script.exists(), "Init script not found in submodule")

        # PATCH: Overwrite submodule version with local version to test uncommitted changes
        local_init = REPO_ROOT / "sdk" / "engine" / "init_project.py"
        shutil.copy2(local_init, init_script)

        # Also patch Common.mk and its includes so we test the latest split
        local_common_mk = REPO_ROOT / "sdk" / "Common.mk"
        target_common_mk = self.client_dir / "vendor/routertl/sdk/Common.mk"
        shutil.copy2(local_common_mk, target_common_mk)
        # Copy the sdk/mk/ include directory
        local_mk_dir = REPO_ROOT / "sdk" / "mk"
        target_mk_dir = self.client_dir / "vendor/routertl/sdk/mk"
        if local_mk_dir.is_dir():
            if target_mk_dir.exists():
                shutil.rmtree(target_mk_dir)
            shutil.copytree(local_mk_dir, target_mk_dir)

        cmd = [
            "python3",
            str(init_script),
            "--name",
            "demo_client",
            "--top",
            "demo_top",
            "--vendor",
            "xilinx",
            "--part",
            "xc7z020clg400-1",
            "--non-interactive",
            "--no-venv",
        ]
        res = self.run_cmd(cmd)
        self.assertEqual(res.returncode, 0, "init_project.py failed")

        return True

    def test_full_client_flow(self):
        """Simulate a user seamlessly integrating the SDK."""
        self._setup_client_project()

        # Verify Files Created
        self.assertTrue((self.client_dir / "project.yml").exists())
        self.assertTrue((self.client_dir / "Makefile").exists())
        self.assertTrue((self.client_dir / "VERSION").exists())
        self.assertTrue((self.client_dir / "project_regbank.yml").exists())

        # 4. Run Make Project (requires Vivado for vendor=xilinx)
        vivado_bin = shutil.which("vivado")
        if vivado_bin:
            # Resolve the Vivado root deterministically so sub-make inherits it
            vivado_root = str(Path(vivado_bin).resolve().parent.parent)
            self.env["VIVADO_PATH"] = vivado_root
            # Ensure the binary is on PATH in subprocesses
            self.env["PATH"] = str(Path(vivado_bin).parent) + ":" + self.env.get("PATH", "")

            # Pass VIVADO_PATH as a make arg to override any Makefile guards
            vivado_args = [f"VIVADO_PATH={vivado_root}", "SDK_HAS_VIVADO=true"]

            print(f"Vivado found at {vivado_root}, running make project...")
            res = self.run_cmd(["make", "project"] + vivado_args)
            self.assertEqual(res.returncode, 0, "make project failed")

            # Verify Vivado Project Created
            xpr_path = self.client_dir / "project" / "demo_client.xpr"
            self.assertTrue(xpr_path.exists(), "Vivado .xpr was not created")
        else:
            print("Vivado not found, skipping make project.")

    def test_scan_tests_client_perspective(self):
        """Verify `make scan-tests` scans the CLIENT's tests, not the SDK's.

        This is a regression test for the bug where scan-tests hardcoded
        $(SDK_ROOT)/sim/cocotb/tests, causing all users to see the SDK's
        internal tests (test_dds, test_spi_rcv, etc.) instead of their own.
        """
        self._setup_client_project()

        # Create a dummy test in the client's standard test directory
        client_test_dir = self.client_dir / "sim" / "cocotb" / "tests"
        client_test_dir.mkdir(parents=True, exist_ok=True)
        (client_test_dir / "__init__.py").touch()
        (client_test_dir / "test_my_uart.py").write_text("# Dummy test file for scan-tests regression\nimport cocotb\n")

        # Run make scan-tests from the client directory
        res = self.run_cmd(["make", "scan-tests"])
        self.assertEqual(res.returncode, 0, f"make scan-tests failed:\n{res.stderr}")

        output = res.stdout

        # Extract only the scan-tests table block (between the "---" delimiter
        # lines).  This makes the test immune to Makefile noise: $(info) messages,
        # make[N]: Entering/Leaving directory, auto-config banners, etc.
        lines = output.splitlines()
        in_table = False
        table_lines = []
        for line in lines:
            if line.startswith("---") or line.startswith("-" * 20):
                if in_table:
                    break  # hit the closing delimiter
                in_table = True
                continue
            if in_table:
                table_lines.append(line)
        scan_output = "\n".join(table_lines)

        # ✅ Client's test MUST appear in the table
        self.assertIn("test_my_uart", scan_output, "Client test not found in scan-tests output")

        # ❌ SDK-internal tests MUST NOT appear
        self.assertNotIn("test_dds", scan_output, "SDK internal test_dds leaked into client scan-tests")
        self.assertNotIn("test_engine_demo", scan_output, "SDK internal test_engine_demo leaked into client scan-tests")
        self.assertNotIn("test_spi_rcv", scan_output, "SDK internal test_spi_rcv leaked into client scan-tests")

        # Verify the scan path resolves to the client directory, not vendor/routertl
        self.assertNotIn("vendor/routertl", scan_output, "Scan path incorrectly points to SDK directory")


if __name__ == "__main__":
    unittest.main()
