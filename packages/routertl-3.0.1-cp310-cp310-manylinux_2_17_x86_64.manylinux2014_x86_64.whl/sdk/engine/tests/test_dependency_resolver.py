# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

# Add project root to path
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.append(str(PM_DIR))

from dependency_resolver import DependencyResolver


class TestDependencyResolverRegression(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory for test files
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str):
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def test_vhdl_resolution(self):
        """Test basic VHDL entity and package resolution."""
        # pkg.vhd
        self.create_file(
            "pkg.vhd",
            """
package my_pkg is
end package my_pkg;
""",
        )
        # leaf.vhd
        self.create_file(
            "leaf.vhd",
            """
library ieee;
use work.my_pkg.all;
entity leaf is
end entity leaf;
""",
        )
        # top.vhd
        self.create_file(
            "top.vhd",
            """
entity top is
end entity top;
architecture rtl of top is
begin
    u_leaf: entity work.leaf;
end architecture;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("top")

        # Expected order: pkg.vhd -> leaf.vhd -> top.vhd
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["pkg.vhd", "leaf.vhd", "top.vhd"])

    def test_verilog_resolution(self):
        """Test Verilog module and include resolution."""
        # params.vh
        self.create_file("params.vh", "`define WIDTH 8")

        # sub.v
        self.create_file(
            "sub.v",
            """
`include "params.vh"
module sub(input clk);
endmodule
""",
        )
        # top.v
        self.create_file(
            "top.v",
            """
module top;
    sub u_sub(.clk(1'b0));
endmodule
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("top")

        # Expected order: params.vh -> sub.v -> top.v
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["params.vh", "sub.v", "top.v"])

    def test_mixed_language_resolution(self):
        """Test VHDL top instantiating Verilog module."""
        # sub_verilog.v
        self.create_file("sub_verilog.v", "module sub_verilog; endmodule")

        # top_vhdl.vhd
        # Note: VHDL instantiating Verilog often uses component or direct entity if mixed-sim supported
        # Our resolver treats them roughly same name-wise
        self.create_file(
            "top_vhdl.vhd",
            """
entity top_vhdl is
end entity;
architecture rtl of top_vhdl is
begin
    u_sub: entity work.sub_verilog;
end architecture;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("top_vhdl")

        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["sub_verilog.v", "top_vhdl.vhd"])

    def test_missing_dependency(self):
        """Test graceful handling of missing dependencies."""
        self.create_file(
            "broken.vhd",
            """
entity broken is
end entity;
architecture rtl of broken is
begin
    u_missing: entity work.does_not_exist;
end architecture;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("broken")

        # Should return just broken.vhd (as it exists) but missing deps are logged/ignored in list
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["broken.vhd"])

    def test_sv_package(self):
        """Test SystemVerilog package import."""
        self.create_file("common_pkg.sv", "package common_pkg; endpackage")
        self.create_file(
            "logic.sv",
            """
import common_pkg::*;
module logic;
endmodule
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("logic")

        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["common_pkg.sv", "logic.sv"])

    def test_verilog_comment_line_no_false_dep(self):
        """BUG-004: module names in // comments must not create false edges."""
        self.create_file("phantom.sv", "module phantom; endmodule")
        self.create_file(
            "real_top.sv",
            """\
// This file replaces phantom.sv in the new architecture
module real_top;
endmodule
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("real_top")
        filenames = [p.name for p in order]
        # phantom should NOT appear — it's only mentioned in a comment
        self.assertEqual(filenames, ["real_top.sv"])

    def test_verilog_comment_block_no_false_dep(self):
        """BUG-004: module names in /* */ comments must not create false edges."""
        self.create_file("other_mod.sv", "module other_mod; endmodule")
        self.create_file(
            "wrapper.sv",
            """\
/*
 * Legacy wrapper — previously instantiated other_mod
 * but that was removed in v2.
 */
module wrapper;
endmodule
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("wrapper")
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["wrapper.sv"])


if __name__ == "__main__":
    unittest.main()
