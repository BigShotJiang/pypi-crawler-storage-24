# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for the Cython build pipeline.

Guards the Phase 2 build infrastructure:
- setup.py must contain cythonize call
- pyproject.toml must have cibuildwheel config
- When .so files exist, imports must work through compiled modules
- Proxy scripts must work with compiled .so modules
"""

import importlib
import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

CORE_DIR = REPO_ROOT / "routertl_core"

# The 4 crown-jewel modules that get compiled
CORE_MODULES = [
    "dependency_resolver",
    "smart_linter",
    "scan_sources",
    "project_manager",
]

# P4.7: Sim engine modules (also compiled)
SIM_MODULES = [
    "sim.simulation",
    "sim.library_compiler",
    "sim.result_collector",
    "sim.vendor_libraries",
    "sim.default_libraries",
]

SIM_BACKEND_MODULES = [
    "sim.backends.backend_base",
    "sim.backends.nvc_backend",
    "sim.backends.ghdl_backend",
    "sim.backends.questa_backend",
    "sim.backends.riviera_backend",
    "sim.backends.verilator_backend",
    "sim.backends.xcelium_backend",
    "sim.backends.activehdl_backend",
]


class TestBuildInfrastructure(unittest.TestCase):
    """Guard: build files must contain Cython configuration."""

    def test_setup_py_has_cythonize(self):
        """setup.py must reference cythonize for compiled builds."""
        setup_py = REPO_ROOT / "setup.py"
        content = setup_py.read_text()
        self.assertIn("cythonize", content, "setup.py must contain cythonize call")
        self.assertIn(
            "ROUTERTL_CYTHONIZE",
            content,
            "setup.py must gate compilation on ROUTERTL_CYTHONIZE env var",
        )

    def test_setup_py_excludes_init(self):
        """setup.py must exclude __init__.py from cythonize."""
        setup_py = REPO_ROOT / "setup.py"
        content = setup_py.read_text()
        self.assertIn(
            "__init__.py",
            content,
            "setup.py must exclude __init__.py from cythonize",
        )

    def test_pyproject_has_cibuildwheel_config(self):
        """pyproject.toml must have cibuildwheel configuration."""
        pyproject = REPO_ROOT / "pyproject.toml"
        content = pyproject.read_text()
        self.assertIn(
            "[tool.cibuildwheel]",
            content,
            "pyproject.toml must have cibuildwheel config",
        )
        self.assertIn(
            "ROUTERTL_CYTHONIZE",
            content,
            "cibuildwheel must set ROUTERTL_CYTHONIZE=1",
        )

    def test_pyproject_includes_routertl_core(self):
        """pyproject.toml must include routertl_core in packages."""
        pyproject = REPO_ROOT / "pyproject.toml"
        content = pyproject.read_text()
        self.assertIn(
            "routertl_core",
            content,
            "pyproject.toml must include routertl_core in packages",
        )

    def test_pyproject_has_cython_build_requires(self):
        """pyproject.toml build-system requires must include Cython."""
        pyproject = REPO_ROOT / "pyproject.toml"
        content = pyproject.read_text()
        self.assertIn(
            "Cython",
            content,
            "pyproject.toml build-system requires must include Cython",
        )

    def test_build_wheels_workflow_exists(self):
        """GitHub Actions workflow for building wheels must exist."""
        workflow = REPO_ROOT / ".github" / "workflows" / "build-wheels.yml"
        self.assertTrue(
            workflow.exists(),
            f"CI workflow not found: {workflow}",
        )

    def test_gitignore_has_cython_patterns(self):
        """The .gitignore must exclude Cython build artifacts."""
        gitignore = REPO_ROOT / ".gitignore"
        content = gitignore.read_text()
        for pattern in ["*.so", "*.pyd", "routertl_core/*.c"]:
            with self.subTest(pattern=pattern):
                self.assertIn(
                    pattern,
                    content,
                    f".gitignore must exclude {pattern}",
                )


class TestCompiledModuleImport(unittest.TestCase):
    """Guard: when .so files exist, imports must use them correctly."""

    def _has_compiled_modules(self):
        """Check if any .so/.pyd files exist in routertl_core/."""
        so_files = list(CORE_DIR.glob("*.so")) + list(CORE_DIR.glob("*.pyd"))
        return len(so_files) > 0

    def test_core_modules_importable(self):
        """All 4 core modules must be importable (compiled or pure Python)."""
        for mod_name in CORE_MODULES:
            with self.subTest(module=mod_name):
                mod = importlib.import_module(f"routertl_core.{mod_name}")
                self.assertIsNotNone(mod)

    @unittest.skipUnless(
        list((Path(__file__).parent.parent.parent.parent / "routertl_core").glob("*.so"))
        or list((Path(__file__).parent.parent.parent.parent / "routertl_core").glob("*.pyd")),
        "No compiled .so/.pyd files present — skipping compiled-only tests",
    )
    def test_compiled_modules_are_extension(self):
        """When .so files exist, imported modules must be extension modules."""
        for mod_name in CORE_MODULES:
            with self.subTest(module=mod_name):
                mod = importlib.import_module(f"routertl_core.{mod_name}")
                mod_file = getattr(mod, "__file__", "")
                self.assertTrue(
                    mod_file.endswith(".so") or mod_file.endswith(".pyd"),
                    f"Expected compiled module for {mod_name}, got: {mod_file}",
                )

    def test_key_symbols_accessible(self):
        """Key public symbols must be importable from core modules."""
        from routertl_core.dependency_resolver import DependencyResolver

        self.assertTrue(callable(DependencyResolver))

        from routertl_core.dependency_resolver import main

        self.assertTrue(callable(main))

    def test_proxy_compat_after_build(self):
        """Proxy scripts must re-export names from compiled modules."""
        pm_dir = str(REPO_ROOT / "sdk" / "engine")
        if pm_dir not in sys.path:
            sys.path.insert(0, pm_dir)

        import smart_linter as proxy_sl

        self.assertTrue(
            hasattr(proxy_sl, "_partition_files"),
            "Proxy must re-export _partition_files after Cython build",
        )


class TestPhase3Infrastructure(unittest.TestCase):
    """Guard: Phase 3 PyPI + GitHub split infrastructure."""

    def test_manifest_public_exists(self):
        """MANIFEST.public must exist and contain entries."""
        manifest = REPO_ROOT / "MANIFEST.public"
        self.assertTrue(manifest.exists(), "MANIFEST.public not found at repo root")
        lines = [
            ln.strip()
            for ln in manifest.read_text().splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]
        self.assertGreater(len(lines), 10, "MANIFEST.public should list at least 10 paths")

    def test_manifest_excludes_proprietary_source(self):
        """MANIFEST.public must NOT list routertl_core/*.py (except __init__.py)."""
        manifest = REPO_ROOT / "MANIFEST.public"
        if not manifest.exists():
            self.skipTest("MANIFEST.public not found")

        content = manifest.read_text()
        for mod in CORE_MODULES:
            self.assertNotIn(
                f"routertl_core/{mod}.py",
                content,
                f"MANIFEST.public must NOT list proprietary source: routertl_core/{mod}.py",
            )

    def test_manifest_excludes_internal_files(self):
        """MANIFEST.public must NOT list internal/private files."""
        manifest = REPO_ROOT / "MANIFEST.public"
        if not manifest.exists():
            self.skipTest("MANIFEST.public not found")

        content = manifest.read_text()
        private_patterns = [
            "GEMINI.md",
            "bitbucket-pipelines.yml",
            "docs/strategy/",
            "docs/roasts/",
        ]
        for pattern in private_patterns:
            self.assertNotIn(
                pattern,
                content,
                f"MANIFEST.public must NOT list internal file: {pattern}",
            )

    def test_build_wheels_has_publish_job(self):
        """build-wheels.yml must contain a publish-pypi job."""
        workflow = REPO_ROOT / ".github" / "workflows" / "build-wheels.yml"
        content = workflow.read_text()
        self.assertIn(
            "publish-pypi",
            content,
            "build-wheels.yml must contain a publish-pypi job",
        )
        self.assertIn(
            "gh-action-pypi-publish",
            content,
            "build-wheels.yml publish job must use pypa/gh-action-pypi-publish",
        )

    def test_sync_public_workflow_exists(self):
        """sync-public.yml workflow must exist."""
        workflow = REPO_ROOT / ".github" / "workflows" / "sync-public.yml"
        self.assertTrue(
            workflow.exists(),
            f"Sync public workflow not found: {workflow}",
        )
        content = workflow.read_text()
        self.assertIn(
            "MANIFEST.public",
            content,
            "sync-public.yml must reference MANIFEST.public",
        )

    def test_pyproject_urls_point_to_public_repo(self):
        """pyproject.toml URLs must point to the public GitHub repo."""
        pyproject = REPO_ROOT / "pyproject.toml"
        content = pyproject.read_text()
        self.assertIn(
            "github.com/djmazure/routertl",
            content,
            "pyproject.toml URLs must point to djmazure/routertl",
        )
        # Must NOT point to bitbucket
        self.assertNotIn(
            "bitbucket.org",
            content,
            "pyproject.toml URLs must not point to bitbucket (private repo)",
        )

    def test_manifest_entries_resolve_to_existing_paths(self):
        """Non-directory manifest entries must exist on the filesystem."""
        manifest = REPO_ROOT / "MANIFEST.public"
        if not manifest.exists():
            self.skipTest("MANIFEST.public not found")

        lines = [
            ln.strip()
            for ln in manifest.read_text().splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]
        missing = []
        for entry in lines:
            path = REPO_ROOT / entry
            # Directories end with / — check they exist as dirs
            if entry.endswith("/"):
                if not path.is_dir():
                    missing.append(entry)
            else:
                # Individual files — must exist
                if not path.exists():
                    missing.append(entry)

        self.assertEqual(
            missing,
            [],
            f"MANIFEST.public entries not found on disk: {missing}",
        )


class TestSimEnginePackageSeparation(unittest.TestCase):
    """Guard: P4.7 — sim engine modules in routertl_core/sim/."""

    def test_sim_core_modules_importable(self):
        """All 5 sim engine modules must be importable from routertl_core.sim."""
        for mod_name in SIM_MODULES:
            with self.subTest(module=mod_name):
                mod = importlib.import_module(f"routertl_core.{mod_name}")
                self.assertIsNotNone(mod)

    def test_sim_backends_importable(self):
        """All 8 sim backend modules must be importable from routertl_core.sim.backends."""
        for mod_name in SIM_BACKEND_MODULES:
            with self.subTest(module=mod_name):
                mod = importlib.import_module(f"routertl_core.{mod_name}")
                self.assertIsNotNone(mod)

    def test_sim_proxy_reexports_run_simulation(self):
        """Proxy at engine/simulation.py must re-export run_simulation."""
        cocotb_dir = str(REPO_ROOT / "sim" / "cocotb")
        if cocotb_dir not in sys.path:
            sys.path.insert(0, cocotb_dir)

        import engine.simulation as proxy_sim

        self.assertTrue(
            hasattr(proxy_sim, "run_simulation"),
            "Proxy must re-export run_simulation from routertl_core.sim.simulation",
        )

    def test_sim_proxy_reexports_get_backend(self):
        """Proxy at engine/backends/__init__.py must re-export get_backend."""
        cocotb_dir = str(REPO_ROOT / "sim" / "cocotb")
        if cocotb_dir not in sys.path:
            sys.path.insert(0, cocotb_dir)

        import engine.backends as proxy_backends

        self.assertTrue(
            hasattr(proxy_backends, "get_backend"),
            "Proxy must re-export get_backend from routertl_core.sim.backends",
        )

    def test_manifest_excludes_sim_source(self):
        """MANIFEST.public must NOT list any routertl_core/sim/ source files."""
        manifest = REPO_ROOT / "MANIFEST.public"
        if not manifest.exists():
            self.skipTest("MANIFEST.public not found")

        content = manifest.read_text()
        self.assertNotIn(
            "routertl_core/sim",
            content,
            "MANIFEST.public must NOT list routertl_core/sim/ (proprietary source)",
        )

    def test_sim_proxy_scripts_exist_at_original_locations(self):
        """Backward-compat: proxy .py files must still exist in sim/cocotb/engine/."""
        engine_dir = REPO_ROOT / "sim" / "cocotb" / "engine"
        for name in ["simulation.py", "library_compiler.py", "result_collector.py",
                      "vendor_libraries.py", "default_libraries.py"]:
            with self.subTest(file=name):
                self.assertTrue(
                    (engine_dir / name).exists(),
                    f"Proxy {name} missing from {engine_dir}",
                )
        # Backend proxies
        backends_dir = engine_dir / "backends"
        for name in ["__init__.py", "backend_base.py", "nvc_backend.py",
                      "ghdl_backend.py", "questa_backend.py", "riviera_backend.py",
                      "verilator_backend.py", "xcelium_backend.py", "activehdl_backend.py"]:
            with self.subTest(file=f"backends/{name}"):
                self.assertTrue(
                    (backends_dir / name).exists(),
                    f"Proxy backends/{name} missing from {backends_dir}",
                )


if __name__ == "__main__":
    unittest.main()
