# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Unit tests for the Questa simulator backend enhancements.

Tests:
- ENH-001: test_args passthrough to runner.test()
- ENH-002: Named VHDL library pre-compilation via vlib/vcom
- ENH-003: custom_libraries wiring from run_simulation() → backend

These tests mock the cocotb runner and subprocess calls since
Questa (vsim) is not available in the CI environment.
"""

import os
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch


class TestQuestaTestArgs(unittest.TestCase):
    """ENH-001: Verify test_args flows through to runner.test()."""

    def _make_backend(self):
        """Create a QuestaBackend with vsim check bypassed."""
        with patch("shutil.which", return_value="/usr/bin/vsim"):
            from sim.cocotb.engine.backends.questa_backend import QuestaBackend

            return QuestaBackend(verbose=False)

    def _run_elaborate(self, backend, test_args=None, custom_libraries=None):
        """Call elaborate_and_run with mocked runner."""
        mock_runner = MagicMock()
        mock_get_runner = MagicMock(return_value=mock_runner)

        with patch.dict("sys.modules", {
            "cocotb_tools": MagicMock(),
            "cocotb_tools.runner": MagicMock(get_runner=mock_get_runner),
        }):
            backend.elaborate_and_run(
                top_level="tb_top",
                module="test_example",
                work_lib="work",
                build_dir="/tmp/questa_test_build",
                wave_dir=None,
                top_level_lang="vhdl",
                generics={},
                hdl_sources=["src/design.vhd"],
                extra_env={},
                verbose=False,
                test_args=test_args,
                custom_libraries=custom_libraries,
            )

        return mock_runner

    def test_test_args_forwarded(self):
        """test_args=['-t', '1ps'] must reach runner.test()."""
        backend = self._make_backend()
        runner = self._run_elaborate(backend, test_args=["-t", "1ps"])

        runner.test.assert_called_once()
        call_kwargs = runner.test.call_args
        self.assertEqual(call_kwargs.kwargs.get("test_args"), ["-t", "1ps"])

    def test_test_args_default_empty(self):
        """When test_args is None, runner.test() gets an empty list."""
        backend = self._make_backend()
        runner = self._run_elaborate(backend)

        runner.test.assert_called_once()
        call_kwargs = runner.test.call_args
        self.assertEqual(call_kwargs.kwargs.get("test_args"), [])

    def test_test_args_multiple_flags(self):
        """Multiple test_args flags are forwarded correctly."""
        backend = self._make_backend()
        args = ["-t", "1ps", "-suppress", "3839"]
        runner = self._run_elaborate(backend, test_args=args)

        call_kwargs = runner.test.call_args
        self.assertEqual(call_kwargs.kwargs.get("test_args"), args)


class TestQuestaCustomLibraries(unittest.TestCase):
    """ENH-002: Verify custom_libraries triggers vlib/vcom pre-compilation."""

    def _make_backend(self):
        """Create a QuestaBackend with vsim check bypassed."""
        with patch("shutil.which", return_value="/usr/bin/vsim"):
            from sim.cocotb.engine.backends.questa_backend import QuestaBackend

            return QuestaBackend(verbose=False)

    @patch("routertl_core.sim.backends.questa_backend.subprocess.run")
    def test_vlib_vcom_called_for_custom_library(self, mock_subprocess):
        """vlib and vcom must be called for each custom library entry."""
        backend = self._make_backend()

        mock_runner = MagicMock()
        mock_get_runner = MagicMock(return_value=mock_runner)

        custom_libs = {"dskop": ["/src/frame_drop_pkg.vhd"]}

        with patch.dict("sys.modules", {
            "cocotb_tools": MagicMock(),
            "cocotb_tools.runner": MagicMock(get_runner=mock_get_runner),
        }):
            backend.elaborate_and_run(
                top_level="tb_top",
                module="test_example",
                work_lib="work",
                build_dir="/tmp/questa_test_build",
                wave_dir=None,
                top_level_lang="vhdl",
                generics={},
                hdl_sources=["/src/frame_drop_pkg.vhd", "/src/top.vhd"],
                extra_env={},
                verbose=False,
                custom_libraries=custom_libs,
            )

        # Extract subprocess.run calls
        sub_calls = mock_subprocess.call_args_list

        # Should have at least 2 calls: vlib + vcom
        self.assertGreaterEqual(len(sub_calls), 2)

        # First call: vlib dskop
        vlib_call = sub_calls[0]
        self.assertEqual(vlib_call.args[0][:2], ["vlib", "dskop"])

        # Second call: vcom -work dskop <source>
        vcom_call = sub_calls[1]
        self.assertEqual(vcom_call.args[0][:3], ["vcom", "-work", "dskop"])
        self.assertIn("frame_drop_pkg.vhd", vcom_call.args[0][3])

    @patch("routertl_core.sim.backends.questa_backend.subprocess.run")
    def test_custom_sources_excluded_from_runner_build(self, mock_subprocess):
        """Sources in custom_libraries must NOT appear in runner.build(sources=)."""
        backend = self._make_backend()

        mock_runner = MagicMock()
        mock_get_runner = MagicMock(return_value=mock_runner)

        custom_libs = {"dskop": ["/src/frame_drop_pkg.vhd"]}

        with patch.dict("sys.modules", {
            "cocotb_tools": MagicMock(),
            "cocotb_tools.runner": MagicMock(get_runner=mock_get_runner),
        }):
            backend.elaborate_and_run(
                top_level="tb_top",
                module="test_example",
                work_lib="work",
                build_dir="/tmp/questa_test_build",
                wave_dir=None,
                top_level_lang="vhdl",
                generics={},
                hdl_sources=["/src/frame_drop_pkg.vhd", "/src/top.vhd"],
                extra_env={},
                verbose=False,
                custom_libraries=custom_libs,
            )

        # runner.build() must have been called
        mock_runner.build.assert_called_once()
        build_sources = mock_runner.build.call_args.kwargs.get("sources", [])

        # The custom library source must not be in the flat source list
        resolved_custom = str(Path("/src/frame_drop_pkg.vhd").resolve())
        for src in build_sources:
            self.assertNotEqual(
                str(Path(src).resolve()),
                resolved_custom,
                f"Custom library source should not appear in runner.build(): {src}",
            )

        # But top.vhd SHOULD be there
        top_found = any("top.vhd" in s for s in build_sources)
        self.assertTrue(top_found, "Non-custom source 'top.vhd' should be in runner.build()")

    @patch("routertl_core.sim.backends.questa_backend.subprocess.run")
    def test_multiple_custom_libraries(self, mock_subprocess):
        """Multiple custom libraries each get their own vlib/vcom calls."""
        backend = self._make_backend()

        mock_runner = MagicMock()
        mock_get_runner = MagicMock(return_value=mock_runner)

        custom_libs = {
            "dskop": ["/src/dskop_pkg.vhd"],
            "utils": ["/src/utils_pkg.vhd"],
        }

        with patch.dict("sys.modules", {
            "cocotb_tools": MagicMock(),
            "cocotb_tools.runner": MagicMock(get_runner=mock_get_runner),
        }):
            backend.elaborate_and_run(
                top_level="tb_top",
                module="test_example",
                work_lib="work",
                build_dir="/tmp/questa_test_build",
                wave_dir=None,
                top_level_lang="vhdl",
                generics={},
                hdl_sources=[],
                extra_env={},
                verbose=False,
                custom_libraries=custom_libs,
            )

        sub_calls = mock_subprocess.call_args_list

        # Should have 4 calls: vlib dskop, vcom dskop, vlib utils, vcom utils
        self.assertEqual(len(sub_calls), 4)

        # Verify library names appear in the vlib calls
        vlib_names = [c.args[0][1] for c in sub_calls if c.args[0][0] == "vlib"]
        self.assertIn("dskop", vlib_names)
        self.assertIn("utils", vlib_names)

    @patch("routertl_core.sim.backends.questa_backend.subprocess.run")
    def test_no_custom_libraries_skips_precompile(self, mock_subprocess):
        """When custom_libraries is None, no subprocess calls are made."""
        backend = self._make_backend()

        mock_runner = MagicMock()
        mock_get_runner = MagicMock(return_value=mock_runner)

        with patch.dict("sys.modules", {
            "cocotb_tools": MagicMock(),
            "cocotb_tools.runner": MagicMock(get_runner=mock_get_runner),
        }):
            backend.elaborate_and_run(
                top_level="tb_top",
                module="test_example",
                work_lib="work",
                build_dir="/tmp/questa_test_build",
                wave_dir=None,
                top_level_lang="vhdl",
                generics={},
                hdl_sources=["src/top.vhd"],
                extra_env={},
                verbose=False,
                custom_libraries=None,
            )

        # No subprocess calls should have been made (vlib/vcom)
        mock_subprocess.assert_not_called()


class TestSimulationQuestaWiring(unittest.TestCase):
    """ENH-003: Verify run_simulation() forwards test_args and custom_libraries."""

    def test_test_args_reaches_backend(self):
        """test_args passed to run_simulation() must reach the backend."""
        from sim.cocotb.engine.simulation import run_simulation

        mock_backend = MagicMock()

        with (
            patch.dict(os.environ, {"SIM": "questa"}, clear=False),
            patch("routertl_core.sim.simulation.get_backend", return_value=mock_backend),
            patch("routertl_core.sim.simulation.LibraryCompiler"),
            patch(
                "routertl_core.sim.simulation.get_build_dir_for_simulator",
                return_value="/tmp/test_build",
            ),
            patch("routertl_core.sim.simulation.ensure_dir"),
            patch("routertl_core.sim.simulation.PROJECT_ROOT", Path("/fake/project")),
        ):
            try:
                run_simulation(
                    top_level="tb_top",
                    module="test_example",
                    simulator="questa",
                    hdl_sources=["top.vhd"],
                    test_args=["-t", "1ps"],
                )
            except Exception:
                pass  # Backend mock may raise; we only care about the call

        mock_backend.elaborate_and_run.assert_called_once()
        kwargs = mock_backend.elaborate_and_run.call_args.kwargs
        self.assertEqual(kwargs.get("test_args"), ["-t", "1ps"])

    def test_custom_libraries_reaches_backend(self):
        """custom_libraries passed to run_simulation() must reach the backend."""
        from sim.cocotb.engine.simulation import run_simulation

        mock_backend = MagicMock()
        custom_libs = {"dskop": ["pkg.vhd"]}

        with (
            patch.dict(os.environ, {"SIM": "questa"}, clear=False),
            patch("routertl_core.sim.simulation.get_backend", return_value=mock_backend),
            patch("routertl_core.sim.simulation.LibraryCompiler"),
            patch(
                "routertl_core.sim.simulation.get_build_dir_for_simulator",
                return_value="/tmp/test_build",
            ),
            patch("routertl_core.sim.simulation.ensure_dir"),
            patch("routertl_core.sim.simulation.PROJECT_ROOT", Path("/fake/project")),
        ):
            try:
                run_simulation(
                    top_level="tb_top",
                    module="test_example",
                    simulator="questa",
                    custom_libraries=custom_libs,
                )
            except Exception:
                pass

        mock_backend.elaborate_and_run.assert_called_once()
        kwargs = mock_backend.elaborate_and_run.call_args.kwargs
        self.assertEqual(kwargs.get("custom_libraries"), custom_libs)

    def test_no_test_args_sends_none(self):
        """When test_args is omitted, None is forwarded to the backend."""
        from sim.cocotb.engine.simulation import run_simulation

        mock_backend = MagicMock()

        with (
            patch.dict(os.environ, {"SIM": "questa"}, clear=False),
            patch("routertl_core.sim.simulation.get_backend", return_value=mock_backend),
            patch("routertl_core.sim.simulation.LibraryCompiler"),
            patch(
                "routertl_core.sim.simulation.get_build_dir_for_simulator",
                return_value="/tmp/test_build",
            ),
            patch("routertl_core.sim.simulation.ensure_dir"),
            patch("routertl_core.sim.simulation.PROJECT_ROOT", Path("/fake/project")),
        ):
            try:
                run_simulation(
                    top_level="tb_top",
                    module="test_example",
                    simulator="questa",
                    hdl_sources=["top.vhd"],
                )
            except Exception:
                pass

        kwargs = mock_backend.elaborate_and_run.call_args.kwargs
        self.assertIsNone(kwargs.get("test_args"))


if __name__ == "__main__":
    unittest.main()
