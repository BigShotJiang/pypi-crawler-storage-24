# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Unit tests for the simulation result collector.

Tests XML parsing, JSON summary generation, history accumulation,
and the history cap mechanism.
"""

import os

# Support running from SDK root
import sys
import tempfile
import unittest
from pathlib import Path

_sdk_root = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_sdk_root / "sim" / "cocotb"))

from engine.result_collector import (
    append_to_history,
    detect_regression,
    generate_json_summary,
    parse_junit_xml,
    read_history,
)

# ── Test Fixtures ──

SAMPLE_RESULTS_XML_PASS = """\
<testsuites name="results">
  <testsuite name="all" package="all">
    <property name="random_seed" value="1771827292" />
    <testcase name="test_basic_behavior" classname="tests.units.test_sync_cdc" file="/path/to/test.py" lineno="65" time="0.0036" sim_time_ns="530.0" />
    <testcase name="test_sweep_baud" classname="tests.units.test_sync_cdc" file="/path/to/test.py" lineno="120" time="1.8042" sim_time_ns="15000.0" />
  </testsuite>
</testsuites>
"""

SAMPLE_RESULTS_XML_FAIL = """\
<testsuites name="results">
  <testsuite name="all" package="all">
    <property name="random_seed" value="42" />
    <testcase name="test_pass" classname="test_mod" time="0.5" sim_time_ns="100.0" />
    <testcase name="test_fail" classname="test_mod" time="1.2" sim_time_ns="200.0">
      <failure message="AssertionError: expected 1 got 0">Traceback...</failure>
    </testcase>
    <testcase name="test_error" classname="test_mod" time="0.1" sim_time_ns="50.0">
      <error message="RuntimeError: VPI crash">Traceback...</error>
    </testcase>
  </testsuite>
</testsuites>
"""

SAMPLE_RESULTS_XML_NO_SEED = """\
<testsuites name="results">
  <testsuite name="all" package="all">
    <testcase name="test_one" classname="mod" time="0.1" sim_time_ns="10.0" />
  </testsuite>
</testsuites>
"""


class TestParseJunitXml(unittest.TestCase):
    """Tests for parse_junit_xml()."""

    def _write_xml(self, content):
        """Write XML content to a temp file and return its Path."""
        fd, path = tempfile.mkstemp(suffix=".xml")
        with os.fdopen(fd, "w") as f:
            f.write(content)
        return Path(path)

    def tearDown(self):
        # Cleanup temp files
        for attr in ("_tmp",):
            path = getattr(self, attr, None)
            if path and Path(path).exists():
                os.unlink(path)

    def test_parse_passing_tests(self):
        path = self._write_xml(SAMPLE_RESULTS_XML_PASS)
        self._tmp = path

        result = parse_junit_xml(path)
        self.assertIsNotNone(result)
        self.assertEqual(result["seed"], 1771827292)
        self.assertEqual(result["passed"], 2)
        self.assertEqual(result["failed"], 0)
        self.assertEqual(result["errors"], 0)
        self.assertEqual(result["total"], 2)
        self.assertEqual(len(result["tests"]), 2)
        self.assertEqual(result["tests"][0]["name"], "test_basic_behavior")
        self.assertEqual(result["tests"][0]["status"], "pass")
        self.assertEqual(result["tests"][1]["name"], "test_sweep_baud")

    def test_parse_with_failures(self):
        path = self._write_xml(SAMPLE_RESULTS_XML_FAIL)
        self._tmp = path

        result = parse_junit_xml(path)
        self.assertIsNotNone(result)
        self.assertEqual(result["seed"], 42)
        self.assertEqual(result["passed"], 1)
        self.assertEqual(result["failed"], 1)
        self.assertEqual(result["errors"], 1)
        self.assertEqual(result["total"], 3)

        # Verify failure details
        fail_test = [t for t in result["tests"] if t["name"] == "test_fail"][0]
        self.assertEqual(fail_test["status"], "fail")
        self.assertIn("AssertionError", fail_test["message"])

        error_test = [t for t in result["tests"] if t["name"] == "test_error"][0]
        self.assertEqual(error_test["status"], "error")

    def test_parse_no_seed(self):
        path = self._write_xml(SAMPLE_RESULTS_XML_NO_SEED)
        self._tmp = path

        result = parse_junit_xml(path)
        self.assertIsNotNone(result)
        self.assertIsNone(result["seed"])
        self.assertEqual(result["total"], 1)

    def test_parse_nonexistent_file(self):
        result = parse_junit_xml(Path("/nonexistent/file.xml"))
        self.assertIsNone(result)

    def test_parse_invalid_xml(self):
        path = self._write_xml("not valid xml {{{")
        self._tmp = path
        result = parse_junit_xml(path)
        self.assertIsNone(result)


class TestGenerateJsonSummary(unittest.TestCase):
    """Tests for generate_json_summary()."""

    def test_basic_summary(self):
        parsed = {
            "seed": 12345,
            "tests": [
                {"name": "t1", "status": "pass", "time_s": 0.5, "sim_time_ns": 100},
            ],
            "passed": 1,
            "failed": 0,
            "errors": 0,
            "total": 1,
            "duration_s": 0.5,
        }
        summary = generate_json_summary(
            parsed,
            module="test_uart",
            simulator="nvc",
            wave_dir="/tmp/waves",
            timestamp="2026-02-23T14:00:00+00:00",
        )
        self.assertEqual(summary["module"], "test_uart")
        self.assertEqual(summary["simulator"], "nvc")
        self.assertEqual(summary["seed"], 12345)
        self.assertEqual(summary["passed"], 1)
        self.assertEqual(summary["wave_dir"], "/tmp/waves")
        self.assertEqual(summary["timestamp"], "2026-02-23T14:00:00+00:00")


class TestHistoryAccumulation(unittest.TestCase):
    """Tests for append_to_history() and read_history()."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.results_dir = Path(self.tmpdir)

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _make_summary(self, module, passed=1, seed=42):
        return {
            "timestamp": "2026-02-23T14:00:00+00:00",
            "module": module,
            "simulator": "nvc",
            "seed": seed,
            "duration_s": 1.0,
            "passed": passed,
            "failed": 0,
            "errors": 0,
            "total": passed,
            "tests": [],
        }

    def test_append_single(self):
        summary = self._make_summary("test_a")
        path = append_to_history(summary, self.results_dir)
        self.assertTrue(path.exists())

        entries = read_history(self.results_dir)
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["module"], "test_a")

    def test_append_multiple(self):
        for name in ["test_a", "test_b", "test_c"]:
            append_to_history(self._make_summary(name), self.results_dir)

        entries = read_history(self.results_dir)
        self.assertEqual(len(entries), 3)
        # Most recent first
        self.assertEqual(entries[0]["module"], "test_c")
        self.assertEqual(entries[2]["module"], "test_a")

    def test_history_cap(self):
        """Verify that history is capped at MAX_HISTORY_ENTRIES."""
        max_cap = 10  # Use a small cap for testing
        for i in range(15):
            append_to_history(
                self._make_summary(f"test_{i}"),
                self.results_dir,
                max_entries=max_cap,
            )

        entries = read_history(self.results_dir, limit=100)
        self.assertEqual(len(entries), max_cap)
        # Most recent should be test_14 (last written)
        self.assertEqual(entries[0]["module"], "test_14")
        # Oldest should be test_5 (first 5 were dropped)
        self.assertEqual(entries[-1]["module"], "test_5")

    def test_read_empty_history(self):
        entries = read_history(self.results_dir)
        self.assertEqual(entries, [])

    def test_read_with_limit(self):
        for i in range(10):
            append_to_history(self._make_summary(f"test_{i}"), self.results_dir)

        entries = read_history(self.results_dir, limit=3)
        self.assertEqual(len(entries), 3)
        self.assertEqual(entries[0]["module"], "test_9")


class TestDetectRegression(unittest.TestCase):
    """Tests for detect_regression()."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.results_dir = Path(self.tmpdir)

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _make_summary(self, module, duration, tests=None, seed=42):
        summary = {
            "timestamp": "2026-02-23T14:00:00+00:00",
            "module": module,
            "simulator": "nvc",
            "seed": seed,
            "duration_s": duration,
            "passed": 1,
            "failed": 0,
            "errors": 0,
            "total": 1,
            "tests": tests or [{"name": "test_basic", "time_s": duration, "status": "pass"}],
        }
        return summary

    def test_no_regression(self):
        """Normal speed run — no regression flagged."""
        # Build 5 history entries at ~1.0s
        for i in range(5):
            append_to_history(
                self._make_summary("test_uart", 1.0 + i * 0.01),
                self.results_dir,
            )
        # Latest at 1.1s — only 10% over average, below 40% threshold
        append_to_history(
            self._make_summary("test_uart", 1.1),
            self.results_dir,
        )

        result = detect_regression(self.results_dir, "test_uart")
        self.assertFalse(result["regressed"])

    def test_regression_detected(self):
        """Slow run — regression flagged."""
        for i in range(5):
            append_to_history(
                self._make_summary("test_uart", 1.0),
                self.results_dir,
            )
        # Latest at 2.0s — 100% over average, above 40% threshold
        append_to_history(
            self._make_summary("test_uart", 2.0),
            self.results_dir,
        )

        result = detect_regression(self.results_dir, "test_uart")
        self.assertTrue(result["regressed"])
        self.assertGreater(result["pct_over"], 40.0)

    def test_insufficient_history(self):
        """Only 2 entries — regression detection skipped."""
        for i in range(2):
            append_to_history(
                self._make_summary("test_uart", 1.0),
                self.results_dir,
            )

        result = detect_regression(self.results_dir, "test_uart")
        self.assertFalse(result["regressed"])
        self.assertEqual(result.get("reason"), "insufficient_history")

    def test_per_test_regression(self):
        """Individual test regression detection."""
        tests = [
            {"name": "test_fast", "time_s": 0.1, "status": "pass"},
            {"name": "test_slow", "time_s": 0.5, "status": "pass"},
        ]
        for i in range(5):
            append_to_history(
                self._make_summary("test_suite", 0.6, tests=tests),
                self.results_dir,
            )
        # Latest: test_slow is now 2x its average
        slow_tests = [
            {"name": "test_fast", "time_s": 0.1, "status": "pass"},
            {"name": "test_slow", "time_s": 1.0, "status": "pass"},
        ]
        append_to_history(
            self._make_summary("test_suite", 1.1, tests=slow_tests),
            self.results_dir,
        )

        result = detect_regression(self.results_dir, "test_suite")
        self.assertTrue(result["regressed"])
        test_names = [t["name"] for t in result["regressed_tests"]]
        self.assertIn("test_slow", test_names)
        self.assertNotIn("test_fast", test_names)

    def test_custom_threshold(self):
        """Configurable threshold."""
        for i in range(5):
            append_to_history(
                self._make_summary("test_uart", 1.0),
                self.results_dir,
            )
        # 1.3s is 30% over — below default 40% but above 20%
        append_to_history(
            self._make_summary("test_uart", 1.3),
            self.results_dir,
        )

        default = detect_regression(self.results_dir, "test_uart")
        self.assertFalse(default["regressed"])

        strict = detect_regression(self.results_dir, "test_uart", threshold=0.20)
        self.assertTrue(strict["regressed"])


if __name__ == "__main__":
    unittest.main()
