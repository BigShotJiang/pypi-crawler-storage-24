# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Unit tests for generate_hook_config() in project_manager.py."""

import os
import sys
import unittest
from pathlib import Path

# Add project-manager to sys.path so we can import directly
TOOLS_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(TOOLS_DIR))

from project_manager import generate_hook_config


class TestHookConfig(unittest.TestCase):
    """Tests for the generate_hook_config() function."""

    def _parse_config(self, output):
        """Parse shell variable output into a dict."""
        result = {}
        for line in output.strip().splitlines():
            if "=" in line:
                key, _, value = line.partition("=")
                # Strip surrounding quotes
                result[key] = value.strip('"')
        return result

    # ── Baseline ───────────────────────────────────────────────

    def test_basic_hook_config(self):
        """Existing variables (HOOK_ENABLED, HOOK_LINT, etc.) are emitted correctly."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "lint": True,
                    "check_yaml": True,
                    "tests": ["test_a", "test_b"],
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_ENABLED"], "true")
        self.assertEqual(out["HOOK_LINT"], "true")
        self.assertEqual(out["HOOK_CHECK_YAML"], "true")
        self.assertEqual(out["HOOK_TESTS"], "test_a test_b")

    def test_hooks_disabled_when_section_missing(self):
        """HOOK_ENABLED=false when hooks section is entirely absent."""
        config = {"project": {"name": "test"}}
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_ENABLED"], "false")

    # ── Frozen Dirs ────────────────────────────────────────────

    def test_frozen_dirs_emitted(self):
        """HOOK_FROZEN_DIRS contains the declared directories."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "frozen_dirs": [
                        "src/ip/digital_blocks_rtp",
                        "hw/rtl/legacy",
                    ],
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertIn("HOOK_FROZEN_DIRS", out)
        self.assertEqual(
            out["HOOK_FROZEN_DIRS"],
            "src/ip/digital_blocks_rtp hw/rtl/legacy",
        )

    def test_frozen_dirs_empty_list(self):
        """HOOK_FROZEN_DIRS is empty when list is explicitly empty."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "frozen_dirs": [],
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_FROZEN_DIRS"], "")

    def test_frozen_dirs_key_absent(self):
        """HOOK_FROZEN_DIRS is empty when frozen_dirs key is missing."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "lint": False,
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_FROZEN_DIRS"], "")

    def test_frozen_dirs_single_entry(self):
        """HOOK_FROZEN_DIRS works with a single directory."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "frozen_dirs": ["vendor/locked_ip"],
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_FROZEN_DIRS"], "vendor/locked_ip")

    # ── Exclusion Lists (regression guard) ─────────────────────

    def test_exclude_lint_emitted(self):
        """Existing HOOK_EXCLUDE_LINT still works alongside frozen_dirs."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "frozen_dirs": ["src/frozen"],
                    "exclude": {
                        "lint": ["file_a.vhd", "file_b.vhd"],
                    },
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_EXCLUDE_LINT"], "file_a.vhd file_b.vhd")
        self.assertEqual(out["HOOK_FROZEN_DIRS"], "src/frozen")

    # ── MkDocs Documentation Build ─────────────────────────────

    def test_check_docs_true(self):
        """HOOK_CHECK_DOCS=true when check_docs is explicitly enabled."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "check_docs": True,
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_CHECK_DOCS"], "true")

    def test_check_docs_default_false(self):
        """HOOK_CHECK_DOCS=false when check_docs key is absent."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "lint": False,
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_CHECK_DOCS"], "false")

    # ── Auto-Discovery Mode ─────────────────────────────────────

    def test_auto_discovers_tests(self):
        """tests: auto discovers test_*.py files from simulation.test_dir."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create fake test files
            units = Path(tmpdir) / "units"
            units.mkdir()
            (Path(tmpdir) / "test_top.py").touch()
            (units / "test_edge.py").touch()
            (units / "test_fifo.py").touch()
            (units / "helper.py").touch()  # Should NOT be discovered

            config = {
                "simulation": {"test_dir": tmpdir},
                "hooks": {
                    "pre_commit": {
                        "enabled": True,
                        "tests": "auto",
                    }
                },
            }
            out = self._parse_config(generate_hook_config(config))
            tests = out["HOOK_TESTS"].split()
            self.assertIn("tests.test_top", tests)
            self.assertIn("tests.units.test_edge", tests)
            self.assertIn("tests.units.test_fifo", tests)
            self.assertNotIn("tests.units.helper", tests)
            self.assertEqual(len(tests), 3)

    def test_auto_with_exclusions(self):
        """tests: auto respects exclude.tests and pre-filters the discovered set."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / "test_a.py").touch()
            (Path(tmpdir) / "test_b.py").touch()
            (Path(tmpdir) / "test_c.py").touch()

            config = {
                "simulation": {"test_dir": tmpdir},
                "hooks": {
                    "pre_commit": {
                        "enabled": True,
                        "tests": "auto",
                        "exclude": {
                            "tests": ["tests.test_b"],
                        },
                    }
                },
            }
            out = self._parse_config(generate_hook_config(config))
            tests = out["HOOK_TESTS"].split()
            self.assertIn("tests.test_a", tests)
            self.assertIn("tests.test_c", tests)
            self.assertNotIn("tests.test_b", tests)
            self.assertEqual(len(tests), 2)
            # Exclusions already applied — HOOK_EXCLUDE_TESTS should be empty
            self.assertEqual(out["HOOK_EXCLUDE_TESTS"], "")

    def test_explicit_list_unchanged(self):
        """Explicit tests: [list] still works identically to before."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "tests": ["test_x", "test_y"],
                    "exclude": {
                        "tests": ["test_y"],
                    },
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_TESTS"], "test_x test_y")
        self.assertEqual(out["HOOK_EXCLUDE_TESTS"], "test_y")

    # ── Python Linting (ruff) ──────────────────────────────────

    def test_lint_python_true(self):
        """HOOK_LINT_PYTHON=true when lint_python is explicitly enabled."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "lint_python": True,
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_LINT_PYTHON"], "true")

    def test_lint_python_default_false(self):
        """HOOK_LINT_PYTHON=false when lint_python key is absent."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "lint": False,
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_LINT_PYTHON"], "false")

    def test_lint_python_explicit_false(self):
        """HOOK_LINT_PYTHON=false when lint_python is explicitly disabled."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "lint_python": False,
                }
            }
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_LINT_PYTHON"], "false")

    # ── Test List DRY (P1.36) ──────────────────────────────────

    def test_tests_inherit_from_cicd(self):
        """tests: inherit resolves from cicd.tests."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "tests": "inherit",
                }
            },
            "cicd": {
                "tests": ["test_a", "test_b"],
            },
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_TESTS"], "test_a test_b")

    def test_tests_inherit_no_cicd_section(self):
        """tests: inherit with no cicd section yields empty test list."""
        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "tests": "inherit",
                }
            },
        }
        out = self._parse_config(generate_hook_config(config))
        self.assertEqual(out["HOOK_TESTS"], "")

    def test_divergence_warning_emitted(self):
        """Warning emitted when both test lists are explicit and differ."""
        import logging as _logging

        config = {
            "hooks": {
                "pre_commit": {
                    "enabled": True,
                    "tests": ["test_a"],
                }
            },
            "cicd": {
                "tests": ["test_a", "test_b"],
            },
        }
        with self.assertLogs(level=_logging.WARNING) as cm:
            generate_hook_config(config)
        self.assertTrue(
            any("differ" in msg for msg in cm.output),
            f"Expected divergence warning, got: {cm.output}",
        )


class TestGitTrackedFilter(unittest.TestCase):
    """Tests for git_utils.filter_git_tracked().

    Validates that untracked (WIP) test files are excluded from discovery
    while tracked files pass through. Also verifies fail-open behaviour.
    """

    def setUp(self):
        """Import filter_git_tracked from the shared utility."""
        from git_utils import _clean_git_env, filter_git_tracked

        self.filter_git_tracked = filter_git_tracked
        # Strip GIT_DIR/GIT_INDEX_FILE/GIT_WORK_TREE so subprocess calls
        # to create temp git repos don't inherit the hook environment and
        # try to operate on the real repo instead of the temp one.
        self._git_env = _clean_git_env()

    # ── Core filtering ──────────────────────────────────────────

    def test_untracked_files_excluded(self):
        """Untracked test_*.py files are filtered out in a real git repo."""
        import subprocess
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            repo = Path(tmpdir)
            # Initialise a throwaway git repo
            subprocess.run(
                ["git", "init"], cwd=str(repo),
                capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "config", "user.email", "test@test.com"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "config", "user.name", "Test"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )

            # Create two test files
            tracked = repo / "test_tracked.py"
            untracked = repo / "test_wip.py"
            tracked.write_text("# tracked\n")
            untracked.write_text("# WIP — not committed\n")

            # Stage and commit only the tracked file
            subprocess.run(
                ["git", "add", "test_tracked.py"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "commit", "-m", "init"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )

            # Filter should keep only the tracked file
            result = self.filter_git_tracked(
                [tracked, untracked], repo_root=repo,
            )
            result_names = [f.name for f in result]
            self.assertIn("test_tracked.py", result_names)
            self.assertNotIn("test_wip.py", result_names)

    def test_staged_but_uncommitted_included(self):
        """Staged (git-added) files ARE included — they are tracked."""
        import subprocess
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            repo = Path(tmpdir)
            subprocess.run(
                ["git", "init"], cwd=str(repo),
                capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "config", "user.email", "test@test.com"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "config", "user.name", "Test"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )

            staged = repo / "test_staged.py"
            staged.write_text("# staged\n")
            subprocess.run(
                ["git", "add", "test_staged.py"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )

            result = self.filter_git_tracked([staged], repo_root=repo)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0].name, "test_staged.py")

    # ── Fail-open behaviour ─────────────────────────────────────

    def test_fallback_outside_git_repo(self):
        """Outside a git repo, all files pass through (fail-open)."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            f1 = Path(tmpdir) / "test_a.py"
            f2 = Path(tmpdir) / "test_b.py"
            f1.touch()
            f2.touch()

            # tmpdir is NOT a git repo — filter should return all
            result = self.filter_git_tracked([f1, f2], repo_root=Path(tmpdir))
            self.assertEqual(len(result), 2)

    def test_empty_input(self):
        """Empty input returns empty output."""
        self.assertEqual(self.filter_git_tracked([]), [])

    # ── Integration: auto-discovery + git filter ────────────────

    def test_auto_discovery_excludes_untracked(self):
        """End-to-end: generate_hook_config(tests='auto') skips untracked files."""
        import subprocess
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            repo = Path(tmpdir)
            sim_dir = repo / "sim" / "cocotb" / "tests"
            sim_dir.mkdir(parents=True)

            # Initialise git repo
            subprocess.run(
                ["git", "init"], cwd=str(repo),
                capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "config", "user.email", "test@test.com"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "config", "user.name", "Test"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )

            # Create tracked and untracked test files
            (sim_dir / "test_committed.py").write_text("# ok\n")
            (sim_dir / "test_wip.py").write_text("# WIP\n")
            subprocess.run(
                ["git", "add", "sim/cocotb/tests/test_committed.py"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "commit", "-m", "add test"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )

            config = {
                "simulation": {"test_dir": str(sim_dir)},
                "hooks": {
                    "pre_commit": {
                        "enabled": True,
                        "tests": "auto",
                    }
                },
            }
            out = TestHookConfig._parse_config(None, generate_hook_config(config))
            tests = out["HOOK_TESTS"].split()
            self.assertIn("tests.test_committed", tests)
            self.assertNotIn("tests.test_wip", tests)

    # ── GIT_DIR poisoning regression (conv 66) ──────────────────

    def test_git_dir_env_does_not_poison_discovery(self):
        """filter_git_tracked() works even when GIT_DIR is set (hook env).

        Bug: git sets GIT_DIR when running pre-commit hooks.  This caused
        ``git rev-parse --show-toplevel`` to return the subprocess CWD
        instead of the real repo root, silently dropping all test files.
        Regression for commit 2a363f2 (2026-03-03).
        """
        import subprocess
        import tempfile
        from unittest.mock import patch

        with tempfile.TemporaryDirectory() as tmpdir:
            repo = Path(tmpdir)
            tests_dir = repo / "tests"
            tests_dir.mkdir()

            # Initialise a throwaway git repo
            subprocess.run(
                ["git", "init"], cwd=str(repo),
                capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "config", "user.email", "test@test.com"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "config", "user.name", "Test"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )

            # Create and commit a test file inside a subdirectory
            tracked = tests_dir / "test_real.py"
            tracked.write_text("# tracked\n")
            subprocess.run(
                ["git", "add", "tests/test_real.py"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )
            subprocess.run(
                ["git", "commit", "-m", "init"],
                cwd=str(repo), capture_output=True, check=True, env=self._git_env,
            )

            # Resolve the absolute gitdir (what git sets GIT_DIR to)
            gitdir = subprocess.run(
                ["git", "rev-parse", "--absolute-git-dir"],
                capture_output=True, text=True, cwd=str(repo),
                env=self._git_env,
            ).stdout.strip()

            # Simulate the hook environment: GIT_DIR set, no repo_root
            poisoned_env = {**dict(os.environ), "GIT_DIR": gitdir}
            with patch.dict(os.environ, poisoned_env, clear=True):
                # Call WITHOUT repo_root — exercises auto-detection
                result = self.filter_git_tracked([tracked])

            result_names = [f.name for f in result]
            self.assertIn(
                "test_real.py", result_names,
                "filter_git_tracked() dropped tracked files when GIT_DIR was set "
                "(the bug from conv 66 / commit 2a363f2)",
            )

class TestPrebuildHookRunner(unittest.TestCase):
    """Tests for run_hook() stale-output cleanup in run_prebuild_hooks.py."""

    def setUp(self):
        """Import run_hook from the engine module."""
        from run_prebuild_hooks import run_hook

        self.run_hook = run_hook

    def _write_dummy_script(self, path: Path, outputs: list[Path]):
        """Create a tiny Python script that touches expected output files."""
        lines = ["import sys", "from pathlib import Path"]
        for out in outputs:
            lines.append(f'Path("{out}").parent.mkdir(parents=True, exist_ok=True)')
            lines.append(f'Path("{out}").write_text("generated")')
        lines.append("sys.exit(0)")
        path.write_text("\n".join(lines))

    # ── Default: stale outputs cleaned ──────────────────────────

    def test_stale_outputs_cleaned_before_run(self):
        """Stale output files are removed before the hook runs."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            out_dir = root / "gen" / "ip"
            out_dir.mkdir(parents=True)
            stale_file = out_dir / "wrapper.vhd"
            stale_file.write_text("broken empty wrapper")

            # Script that recreates the file
            script = root / "gen_hook.py"
            expected = root / "gen" / "ip" / "wrapper.vhd"
            self._write_dummy_script(script, [expected])

            hook = {
                "name": "test-hook",
                "script": "gen_hook.py",
                "expected_outputs": ["gen/ip/wrapper.vhd"],
            }

            result = self.run_hook(hook, root)
            self.assertTrue(result)
            # File should exist (recreated by hook), but NOT contain stale data
            self.assertTrue(expected.exists())
            self.assertEqual(expected.read_text(), "generated")

    # ── Opt-out: clean_before_run: false ────────────────────────

    def test_clean_before_run_false_preserves_outputs(self):
        """Stale outputs are preserved when clean_before_run is false."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            out_dir = root / "gen" / "ip"
            out_dir.mkdir(parents=True)
            stale_file = out_dir / "wrapper.vhd"
            stale_file.write_text("broken empty wrapper")

            # Script that skips if file exists (mimics real hook behavior)
            script = root / "gen_hook.py"
            script.write_text(
                "import sys\nfrom pathlib import Path\n"
                f'f = Path("{stale_file}")\n'
                "if f.exists(): sys.exit(0)\n"
                'f.write_text("fresh")\n'
            )

            hook = {
                "name": "test-hook",
                "script": "gen_hook.py",
                "expected_outputs": ["gen/ip/wrapper.vhd"],
                "clean_before_run": False,
            }

            result = self.run_hook(hook, root)
            self.assertTrue(result)
            # Stale content should still be there — hook skipped because file existed
            self.assertEqual(stale_file.read_text(), "broken empty wrapper")

    # ── Safety: path traversal blocked ──────────────────────────

    def test_path_traversal_blocked(self):
        """expected_outputs with ../../ escapes are silently skipped."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "project"
            root.mkdir()
            sibling = Path(tmpdir) / "sibling"
            sibling.mkdir()
            victim = sibling / "important.txt"
            victim.write_text("do not delete")

            script = root / "noop.py"
            script.write_text("import sys; sys.exit(0)")

            hook = {
                "name": "escape-hook",
                "script": "noop.py",
                "expected_outputs": ["../../sibling/important.txt"],
            }

            self.run_hook(hook, root)
            # Sibling file must survive
            self.assertTrue(victim.exists())
            self.assertEqual(victim.read_text(), "do not delete")

    # ── Safety: root_dir never deleted ──────────────────────────

    def test_root_dir_never_deleted(self):
        """expected_outputs in root_dir do not trigger rmtree on root."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            sentinel = root / "project.yml"
            sentinel.write_text("# must survive")

            script = root / "gen_hook.py"
            script.write_text(
                "import sys; from pathlib import Path; "
                f'Path("{root / "output.txt"}").write_text("ok"); sys.exit(0)'
            )

            hook = {
                "name": "root-hook",
                "script": "gen_hook.py",
                "expected_outputs": ["output.txt"],
            }

            result = self.run_hook(hook, root)
            self.assertTrue(result)
            # root_dir and its contents must survive
            self.assertTrue(root.exists())
            self.assertTrue(sentinel.exists())


if __name__ == "__main__":
    unittest.main()
