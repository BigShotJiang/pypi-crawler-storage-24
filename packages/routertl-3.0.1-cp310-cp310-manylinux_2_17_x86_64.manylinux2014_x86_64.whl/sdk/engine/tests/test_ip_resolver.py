# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Unit tests for ip_resolver.py — IP Manifest Resolution.

Tests cover:
- Schema validation
- Vendor compatibility matrix
- Recursive dependency resolution with cycle detection
- File classification by synthesis mode
- Library tagging
"""

import os
import sys
import unittest
from pathlib import Path

import yaml

# ── Path setup ──────────────────────────────────────────────────
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
TOOLS_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.insert(0, str(TOOLS_DIR))

import shutil
import tempfile

from ip_resolver import VALID_MODES, VENDOR_MODES, IpResolver


class TestIpResolverBase(unittest.TestCase):
    """Base class with helpers for creating temporary IP structures."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.project_root = self.tmp

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _make_ip(
        self, rel_dir, name, mode="rtl", library="work", language="vhdl", sources=None, child_ips=None, scan_dir="src"
    ):
        """Create an ip.yml in a temp directory and return its relative path."""
        ip_dir = self.tmp / rel_dir
        ip_dir.mkdir(parents=True, exist_ok=True)

        data = {
            "ip": {
                "name": name,
                "library": library,
                "language": language,
            },
            "paths": {
                "sources": scan_dir,
            },
            "synthesis": {
                "mode": mode,
                "sources": sources or [],
            },
        }
        if child_ips:
            data["ips"] = child_ips

        yml_path = ip_dir / "ip.yml"
        with open(yml_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False)

        return str(ip_dir.relative_to(self.tmp) / "ip.yml")

    def _create_stub_files(self, rel_dir, filenames):
        """Create empty stub files for source references."""
        for name in filenames:
            p = self.tmp / rel_dir / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.touch()


class TestRtlMode(TestIpResolverBase):
    """Tests for mode=rtl IPs."""

    def test_rtl_ip_basic(self):
        """Single RTL IP with 3 sources → all appear in syn_files."""
        sources = ["src/uart_tx.vhd", "src/uart_rx.vhd", "src/uart_pkg.vhd"]
        self._create_stub_files("ip/uart", sources)
        ip_path = self._make_ip("ip/uart", "uart_core", mode="rtl", sources=sources)

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0, f"Errors: {result.errors}")
        self.assertEqual(len(result.syn_files), 3)
        self.assertEqual(len(result.manifests), 1)
        self.assertEqual(result.manifests[0].name, "uart_core")

    def test_rtl_ip_with_library(self):
        """RTL IP with library=uart_lib → library mapping correct."""
        sources = ["src/uart_tx.vhd"]
        self._create_stub_files("ip/uart", sources)
        ip_path = self._make_ip("ip/uart", "uart_core", library="uart_lib", sources=sources)

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0)
        self.assertIn("uart_lib", result.libraries)
        self.assertEqual(len(result.libraries["uart_lib"]), 1)

    def test_rtl_ip_work_library_not_in_map(self):
        """RTL IP with library=work → NOT added to library mapping."""
        sources = ["src/top.vhd"]
        self._create_stub_files("ip/top", sources)
        ip_path = self._make_ip("ip/top", "top_ip", library="work", sources=sources)

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0)
        self.assertNotIn("work", result.libraries)


class TestVendorIpModes(TestIpResolverBase):
    """Tests for vendor-specific IP modes."""

    def test_xci_ip_xilinx(self):
        """XCI + vendor=xilinx → xci_files populated."""
        sources = ["fifo_gen.xci"]
        self._create_stub_files("ip/fifo", sources)
        ip_path = self._make_ip("ip/fifo", "fifo_ip", mode="xci", sources=sources)

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0)
        self.assertEqual(len(result.xci_files), 1)
        self.assertIn("fifo_gen.xci", result.xci_files[0])

    def test_xci_ip_wrong_vendor(self):
        """XCI + vendor=altera → error."""
        ip_path = self._make_ip("ip/fifo", "fifo_ip", mode="xci", sources=["f.xci"])
        self._create_stub_files("ip/fifo", ["f.xci"])

        resolver = IpResolver(self.project_root, "altera")
        result = resolver.resolve([ip_path])

        self.assertTrue(len(result.errors) > 0)
        self.assertIn("incompatible", result.errors[0].lower())

    def test_qsys_ip_altera(self):
        """QSYS + vendor=altera → xci_files populated."""
        sources = ["pll.qsys"]
        self._create_stub_files("ip/pll", sources)
        ip_path = self._make_ip("ip/pll", "pll_ip", mode="qsys", sources=sources)

        resolver = IpResolver(self.project_root, "altera")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0)
        self.assertEqual(len(result.xci_files), 1)

    def test_qsys_ip_wrong_vendor(self):
        """QSYS + vendor=xilinx → error."""
        ip_path = self._make_ip("ip/pll", "pll_ip", mode="qsys", sources=["p.qsys"])
        self._create_stub_files("ip/pll", ["p.qsys"])

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path])

        self.assertTrue(len(result.errors) > 0)
        self.assertIn("incompatible", result.errors[0].lower())

    def test_ipx_ip_lattice(self):
        """IPX + vendor=lattice → correct."""
        sources = ["pll.ipx"]
        self._create_stub_files("ip/pll", sources)
        ip_path = self._make_ip("ip/pll", "pll_ip", mode="ipx", sources=sources)

        resolver = IpResolver(self.project_root, "lattice")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0)
        self.assertEqual(len(result.xci_files), 1)

    def test_cxz_ip_microchip(self):
        """CXZ + vendor=microchip → correct."""
        sources = ["dsp.cxz"]
        self._create_stub_files("ip/dsp", sources)
        ip_path = self._make_ip("ip/dsp", "dsp_ip", mode="cxz", sources=sources)

        resolver = IpResolver(self.project_root, "microchip")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0)
        self.assertEqual(len(result.xci_files), 1)


class TestNetlistAndDcp(TestIpResolverBase):
    """Tests for mode=netlist and mode=ooc_dcp."""

    def test_netlist_ip_any_vendor(self):
        """Netlist mode accepted for all 4 vendors."""
        for vendor in ("xilinx", "altera", "lattice", "microchip"):
            sources = ["crypto.edf"]
            # Fresh resolver per vendor
            self._create_stub_files(f"ip/crypto_{vendor}", sources)
            ip_path = self._make_ip(f"ip/crypto_{vendor}", f"crypto_{vendor}", mode="netlist", sources=sources)
            resolver = IpResolver(self.project_root, vendor)
            result = resolver.resolve([ip_path])

            self.assertEqual(len(result.errors), 0, f"Failed for vendor={vendor}: {result.errors}")
            self.assertEqual(len(result.netlist_files), 1, f"No netlist_files for vendor={vendor}")

    def test_ooc_dcp_xilinx(self):
        """OOC DCP + vendor=xilinx → ooc_dcp_files populated."""
        sources = ["dsp_block.dcp"]
        self._create_stub_files("ip/dsp", sources)
        ip_path = self._make_ip("ip/dsp", "dsp_ip", mode="ooc_dcp", sources=sources)

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0)
        self.assertEqual(len(result.ooc_dcp_files), 1)

    def test_ooc_dcp_wrong_vendor(self):
        """OOC DCP + vendor=altera → error."""
        ip_path = self._make_ip("ip/dsp", "dsp_ip", mode="ooc_dcp", sources=["d.dcp"])
        self._create_stub_files("ip/dsp", ["d.dcp"])

        resolver = IpResolver(self.project_root, "altera")
        result = resolver.resolve([ip_path])

        self.assertTrue(len(result.errors) > 0)


class TestDependencyChains(TestIpResolverBase):
    """Tests for IP-to-IP dependencies."""

    def test_ip_chain_rtl_depends_xci(self):
        """IP-A (rtl) → IP-B (xci) → both resolved correctly."""
        # Create IP-B (xci) first
        sources_b = ["fifo.xci"]
        self._create_stub_files("ip/fifo", sources_b)
        self._make_ip("ip/fifo", "fifo_ip", mode="xci", sources=sources_b)

        # Create IP-A (rtl) depending on IP-B
        sources_a = ["src/uart.vhd"]
        self._create_stub_files("ip/uart", sources_a)
        ip_a = self._make_ip("ip/uart", "uart_core", mode="rtl", sources=sources_a, child_ips=["../fifo/ip.yml"])

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_a])

        self.assertEqual(len(result.errors), 0, f"Errors: {result.errors}")
        self.assertEqual(len(result.syn_files), 1)  # uart.vhd
        self.assertEqual(len(result.xci_files), 1)  # fifo.xci
        self.assertEqual(len(result.manifests), 2)

    def test_ip_chain_three_levels(self):
        """A → B → C → all resolved in correct order."""
        # C: netlist
        self._create_stub_files("ip/crypto", ["core.edf"])
        self._make_ip("ip/crypto", "crypto", mode="netlist", sources=["core.edf"])

        # B: xci, depends on C
        self._create_stub_files("ip/fifo", ["fifo.xci"])
        self._make_ip("ip/fifo", "fifo_ip", mode="xci", sources=["fifo.xci"], child_ips=["../crypto/ip.yml"])

        # A: rtl, depends on B
        self._create_stub_files("ip/uart", ["src/uart.vhd"])
        ip_a = self._make_ip("ip/uart", "uart", mode="rtl", sources=["src/uart.vhd"], child_ips=["../fifo/ip.yml"])

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_a])

        self.assertEqual(len(result.errors), 0, f"Errors: {result.errors}")
        self.assertEqual(len(result.manifests), 3)
        self.assertEqual(len(result.syn_files), 1)
        self.assertEqual(len(result.xci_files), 1)
        self.assertEqual(len(result.netlist_files), 1)

    def test_circular_dependency(self):
        """A → B → A → cycle detection error."""
        # A references B
        self._create_stub_files("ip/a", ["src/a.vhd"])
        self._make_ip("ip/a", "ip_a", mode="rtl", sources=["src/a.vhd"], child_ips=["../b/ip.yml"])

        # B references A
        self._create_stub_files("ip/b", ["src/b.vhd"])
        self._make_ip("ip/b", "ip_b", mode="rtl", sources=["src/b.vhd"], child_ips=["../a/ip.yml"])

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve(["ip/a/ip.yml"])

        self.assertTrue(len(result.errors) > 0)
        self.assertIn("circular", result.errors[0].lower())


class TestValidation(TestIpResolverBase):
    """Tests for schema validation and error handling."""

    def test_missing_ip_yml(self):
        """Reference to non-existent ip.yml → error."""
        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve(["ip/nonexistent/ip.yml"])

        self.assertTrue(len(result.errors) > 0)
        self.assertIn("not found", result.errors[0].lower())

    def test_invalid_mode(self):
        """synthesis.mode: garbage → validation error."""
        ip_path = self._make_ip("ip/bad", "bad_ip", mode="garbage")

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path])

        self.assertTrue(len(result.errors) > 0)
        self.assertIn("invalid", result.errors[0].lower())

    def test_missing_name(self):
        """ip.yml without ip.name → validation error."""
        ip_dir = self.tmp / "ip" / "noname"
        ip_dir.mkdir(parents=True, exist_ok=True)

        data = {"synthesis": {"mode": "rtl", "sources": []}}
        with open(ip_dir / "ip.yml", "w") as f:
            yaml.dump(data, f)

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve(["ip/noname/ip.yml"])

        self.assertTrue(len(result.errors) > 0)
        self.assertIn("ip.name", result.errors[0].lower())

    def test_vendor_compat_matrix_parametrized(self):
        """All 4 vendors × all 7 modes → correct accept/reject."""
        for vendor, allowed in VENDOR_MODES.items():
            for mode in VALID_MODES:
                # Create a fresh IP for each combination
                dir_name = f"ip/test_{vendor}_{mode}"
                ip_path = self._make_ip(dir_name, f"test_{vendor}_{mode}", mode=mode)

                resolver = IpResolver(self.project_root, vendor)
                result = resolver.resolve([ip_path])

                if mode in allowed:
                    self.assertEqual(
                        len(result.errors),
                        0,
                        f"Expected success for vendor={vendor}, mode={mode}, got errors: {result.errors}",
                    )
                else:
                    self.assertTrue(len(result.errors) > 0, f"Expected error for vendor={vendor}, mode={mode}")


class TestPathResolution(TestIpResolverBase):
    """Tests for path handling."""

    def test_relative_paths_resolved(self):
        """Sources in ip.yml are resolved relative to ip.yml, not project root."""
        sources = ["src/deep/module.vhd"]
        self._create_stub_files("ip/nested/deep", sources)
        ip_path = self._make_ip("ip/nested/deep", "deep_ip", sources=sources)

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path])

        self.assertEqual(len(result.errors), 0, f"Errors: {result.errors}")
        self.assertEqual(len(result.syn_files), 1)
        # Should be relative to project root, not to ip.yml
        for f in result.syn_files:
            self.assertFalse(os.path.isabs(f), f"Path should be relative: {f}")

    def test_duplicate_ip_reference(self):
        """Same ip.yml referenced twice → deduplicated, no error."""
        sources = ["src/top.vhd"]
        self._create_stub_files("ip/shared", sources)
        ip_path = self._make_ip("ip/shared", "shared_ip", sources=sources)

        resolver = IpResolver(self.project_root, "xilinx")
        result = resolver.resolve([ip_path, ip_path])

        self.assertEqual(len(result.errors), 0)
        self.assertEqual(len(result.syn_files), 1)  # Only once
        self.assertEqual(len(result.manifests), 1)  # Only once


if __name__ == "__main__":
    unittest.main()
