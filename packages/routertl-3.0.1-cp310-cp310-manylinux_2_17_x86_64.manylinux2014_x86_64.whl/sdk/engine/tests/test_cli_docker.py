# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for Docker-related CLI commands: docker uninstall, docker setup,
bind mount detection, env var cleanup, trailing help, and docker status.

Split from test_cli.py as part of P2.66.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli


class TestDockerUninstall(unittest.TestCase):
    """Tests for the routertl docker uninstall command."""

    def setUp(self):
        self.runner = CliRunner()

    def test_invalid_env(self):
        """Passing an unsupported env should error via Click's Choice validation."""
        result = self.runner.invoke(cli, ["docker", "uninstall", "unknown"])
        self.assertNotEqual(result.exit_code, 0)

    @patch("subprocess.run")
    def test_volume_not_found(self, mock_run):
        from unittest.mock import MagicMock

        mock_res = MagicMock()
        mock_res.returncode = 1
        mock_run.return_value = mock_res

        result = self.runner.invoke(cli, ["docker", "uninstall", "vivado", "--volume"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("does not exist", result.output)
        mock_run.assert_called_once_with(
            ["docker", "volume", "inspect", "routertl_vivado_opt"], capture_output=True, text=True
        )

    @patch("subprocess.run")
    def test_aborted_by_user(self, mock_run):
        from unittest.mock import MagicMock

        mock_res = MagicMock()
        mock_res.returncode = 0
        mock_run.return_value = mock_res

        result = self.runner.invoke(cli, ["docker", "uninstall", "quartus", "--volume"], input="n\n")
        self.assertEqual(result.exit_code, 0)
        self.assertIn("skipped", result.output)
        self.assertEqual(mock_run.call_count, 1)

    @patch("subprocess.run")
    def test_successful_removal(self, mock_run):
        from unittest.mock import MagicMock

        def run_side_effect(cmd, **kwargs):
            mock_res = MagicMock()
            mock_res.returncode = 0
            return mock_res

        mock_run.side_effect = run_side_effect

        result = self.runner.invoke(cli, ["docker", "uninstall", "vivado", "--volume"], input="y\n")
        self.assertEqual(result.exit_code, 0)
        self.assertIn("removed", result.output)
        self.assertEqual(mock_run.call_count, 2)
        mock_run.assert_any_call(["docker", "volume", "inspect", "routertl_vivado_opt"], capture_output=True, text=True)
        mock_run.assert_any_call(["docker", "volume", "rm", "routertl_vivado_opt"])

    @patch("subprocess.run")
    def test_status_no_docker_resources(self, mock_run):
        """docker status should show inventory sections even when empty."""
        from unittest.mock import MagicMock

        mock_res = MagicMock()
        mock_res.returncode = 0
        mock_res.stdout = ""
        mock_run.return_value = mock_res

        result = self.runner.invoke(cli, ["docker", "status"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("RouteRTL Docker Status", result.output)
        self.assertIn("Volumes:", result.output)
        self.assertIn("Images:", result.output)
        self.assertIn("Containers:", result.output)
        # Health section was removed — license checks live in rr doctor
        self.assertNotIn("Health:", result.output)


class TestDetectBindMounts(unittest.TestCase):
    """Tests for _detect_bind_mounts() EDA_INSTALL_DIR validation."""

    def test_eda_dir_without_eda_subdirs_is_skipped(self):
        """EDA_INSTALL_DIR pointing to a dir with no quartus_*/etc. should be ignored."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            # tmp exists but has no quartus_std/ quartus_pro/ etc.
            env_content = f"EDA_INSTALL_DIR={tmp}\n"
            with CliRunner().isolated_filesystem():
                Path(".env").write_text(env_content)
                from sdk.cli.commands.docker import _detect_bind_mounts

                result = _detect_bind_mounts()
                env_names = [name for name, _path in result]
                self.assertNotIn("EDA_INSTALL_DIR", env_names)

    def test_eda_dir_with_valid_subdir_is_included(self):
        """EDA_INSTALL_DIR with a recognized quartus_std/ subdir should appear."""
        import os
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            os.makedirs(os.path.join(tmp, "quartus_std"))
            env_content = f"EDA_INSTALL_DIR={tmp}\n"
            with CliRunner().isolated_filesystem():
                Path(".env").write_text(env_content)
                from sdk.cli.commands.docker import _detect_bind_mounts

                result = _detect_bind_mounts()
                env_names = [name for name, _path in result]
                self.assertIn("EDA_INSTALL_DIR", env_names)

    def test_per_tool_dir_missing_is_skipped(self):
        """QUARTUS_INSTALL_DIR pointing to non-existent dir should be skipped."""
        env_content = "QUARTUS_INSTALL_DIR=/nonexistent/path/quartus_std\n"
        with CliRunner().isolated_filesystem():
            Path(".env").write_text(env_content)
            from sdk.cli.commands.docker import _detect_bind_mounts

            result = _detect_bind_mounts()
            env_names = [name for name, _path in result]
            self.assertNotIn("QUARTUS_INSTALL_DIR", env_names)


class TestRemoveEnvVar(unittest.TestCase):
    """Tests for _remove_env_var() helper."""

    def test_removes_key_preserves_others(self):
        """Removing a key should leave other .env entries intact."""
        with CliRunner().isolated_filesystem():
            Path(".env").write_text(
                "# comment\nFOO=bar\nQUARTUS_INSTALL_DIR=/mnt/d/quartus\nBAZ=qux\n"
            )
            from sdk.cli.commands.docker import _remove_env_var

            _remove_env_var("QUARTUS_INSTALL_DIR")
            content = Path(".env").read_text()
            self.assertNotIn("QUARTUS_INSTALL_DIR", content)
            self.assertIn("FOO=bar", content)
            self.assertIn("BAZ=qux", content)
            self.assertIn("# comment", content)

    def test_noop_when_key_absent(self):
        """Removing a non-existent key should leave file unchanged."""
        original = "FOO=bar\nBAZ=qux\n"
        with CliRunner().isolated_filesystem():
            Path(".env").write_text(original)
            from sdk.cli.commands.docker import _remove_env_var

            _remove_env_var("NONEXISTENT_KEY")
            content = Path(".env").read_text()
            self.assertIn("FOO=bar", content)
            self.assertIn("BAZ=qux", content)

    def test_noop_when_no_env_file(self):
        """Should not crash when .env doesn't exist."""
        with CliRunner().isolated_filesystem():
            from sdk.cli.commands.docker import _remove_env_var

            _remove_env_var("ANYTHING")  # Should not raise


class TestUninstallEnvCleanup(unittest.TestCase):
    """Tests for .env bind-mount cleanup during docker uninstall."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("subprocess.run")
    def test_offers_cleanup_for_stale_bind_mount(self, mock_run):
        """Uninstall should offer to remove stale .env entries."""
        from unittest.mock import MagicMock

        mock_res = MagicMock()
        mock_res.returncode = 1  # volume doesn't exist, image doesn't exist
        mock_run.return_value = mock_res

        with self.runner.isolated_filesystem():
            # .env with a bind mount pointing to non-existent path
            Path(".env").write_text(
                "QUARTUS_INSTALL_DIR=/nonexistent/quartus_std\n"
                "OTHER_VAR=keep_me\n"
            )

            result = self.runner.invoke(
                cli, ["docker", "uninstall", "quartus"], input="y\n"
            )
            self.assertEqual(result.exit_code, 0)
            self.assertIn("QUARTUS_INSTALL_DIR", result.output)
            self.assertIn("Remove QUARTUS_INSTALL_DIR from .env?", result.output)
            # After accepting, .env should no longer have the key
            content = Path(".env").read_text()
            self.assertNotIn("QUARTUS_INSTALL_DIR", content)
            self.assertIn("OTHER_VAR=keep_me", content)

    @patch("subprocess.run")
    def test_skips_cleanup_when_dir_exists(self, mock_run):
        """Uninstall should NOT offer cleanup when bind-mount dir still exists."""
        import tempfile
        from unittest.mock import MagicMock

        mock_res = MagicMock()
        mock_res.returncode = 1  # volume/image don't exist
        mock_run.return_value = mock_res

        with tempfile.TemporaryDirectory() as existing_dir:
            with self.runner.isolated_filesystem():
                Path(".env").write_text(
                    f"QUARTUS_INSTALL_DIR={existing_dir}\n"
                )

                result = self.runner.invoke(
                    cli, ["docker", "uninstall", "quartus"]
                )
                self.assertEqual(result.exit_code, 0)
                # Should NOT prompt about .env cleanup
                self.assertNotIn("no longer exists", result.output)
                # .env should still have the key
                content = Path(".env").read_text()
                self.assertIn("QUARTUS_INSTALL_DIR", content)


class TestTrailingHelp(unittest.TestCase):
    """Trailing 'help' word should work like --help everywhere."""

    def setUp(self):
        self.runner = CliRunner()

    def test_docker_help_shows_group_help(self):
        """'rr docker help' should show the docker group help."""
        # Simulate the interceptor: rewrite 'help' → '--help' before invoke
        result = self.runner.invoke(cli, ["docker", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Docker", result.output)

    def test_no_duplicate_help_entries(self):
        """Visible commands in --help must have unique names (no duplicates)."""
        from collections import Counter

        from sdk.cli.commands.docker import docker_group

        visible = [
            name
            for name, cmd in docker_group.commands.items()
            if not getattr(cmd, "hidden", False)
        ]
        dupes = {k: v for k, v in Counter(visible).items() if v > 1}
        self.assertEqual(
            dupes,
            {},
            f"Duplicate visible commands in 'rr docker --help': {dupes}",
        )

    def test_help_interceptor_rewrites_argv(self):
        """The sys.argv interceptor should replace trailing 'help'."""
        import sys

        original = sys.argv[:]
        try:
            sys.argv = ["routertl", "docker", "help"]
            # Re-trigger the interceptor logic
            if len(sys.argv) > 1 and sys.argv[-1] == "help":
                sys.argv[-1] = "--help"
            self.assertEqual(sys.argv[-1], "--help")
        finally:
            sys.argv = original

    def test_help_interceptor_ignores_single_arg(self):
        """Interceptor should not fire with only 'routertl' (no args)."""
        import sys

        original = sys.argv[:]
        try:
            sys.argv = ["routertl"]
            if len(sys.argv) > 1 and sys.argv[-1] == "help":
                sys.argv[-1] = "--help"
            # Should remain unchanged
            self.assertEqual(sys.argv, ["routertl"])
        finally:
            sys.argv = original


class TestDockerSetup(unittest.TestCase):
    """Test the 'docker setup' interactive wizard."""

    def setUp(self):
        self.runner = CliRunner()

    def test_setup_help_exits_cleanly(self):
        result = self.runner.invoke(cli, ["docker", "setup", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("wizard", result.output.lower())

    def test_setup_writes_env_file(self):
        """Wizard should write .env with prompted values."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(
                cli,
                ["docker", "setup"],
                input="2100@my-server\n\n\n\n\n\n",  # QUARTUS, ALDEC, installer paths (2x), eda_dir, MAC
            )
            self.assertEqual(result.exit_code, 0, f"Output:\n{result.output}")
            self.assertIn("Written to", result.output)

            from pathlib import Path

            env_content = Path(".env").read_text()
            self.assertIn("QUARTUS_LICENSE=2100@my-server", env_content)

    def test_setup_preserves_existing_env(self):
        """Existing .env content should be preserved."""
        with self.runner.isolated_filesystem():
            from pathlib import Path

            Path(".env").write_text("# My comment\nFOO=bar\n")

            result = self.runner.invoke(
                cli,
                ["docker", "setup"],
                input="2100@srv\n\n\n\n\n\n",
            )
            self.assertEqual(result.exit_code, 0, f"Output:\n{result.output}")

            env_content = Path(".env").read_text()
            self.assertIn("# My comment", env_content)
            self.assertIn("FOO=bar", env_content)
            self.assertIn("QUARTUS_LICENSE=2100@srv", env_content)

    def test_setup_updates_existing_keys(self):
        """Existing license values should be updated in-place."""
        with self.runner.isolated_filesystem():
            from pathlib import Path

            Path(".env").write_text("QUARTUS_LICENSE=old-value\n")

            result = self.runner.invoke(
                cli,
                ["docker", "setup"],
                input="2100@new-server\n\n\n\n\n\n",
            )
            self.assertEqual(result.exit_code, 0, f"Output:\n{result.output}")

            env_content = Path(".env").read_text()
            self.assertIn("QUARTUS_LICENSE=2100@new-server", env_content)
            self.assertNotIn("old-value", env_content)

    def test_setup_empty_input_skips_write(self):
        """Pressing Enter on everything should not create .env."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(
                cli,
                ["docker", "setup"],
                input="\n\n\n\n\n\n",
            )
            self.assertEqual(result.exit_code, 0)
            self.assertIn("No values entered", result.output)

            from pathlib import Path

            self.assertFalse(Path(".env").exists())

    def test_setup_enter_preserves_existing(self):
        """Pressing Enter on a field with an existing value must keep it."""
        with self.runner.isolated_filesystem():
            from pathlib import Path

            Path(".env").write_text("QUARTUS_LICENSE=2100@my-server\n")

            # Press Enter on all 6 prompts (keeping the existing value)
            result = self.runner.invoke(
                cli,
                ["docker", "setup"],
                input="\n\n\n\n\n\n",
            )
            self.assertEqual(result.exit_code, 0, f"Output:\n{result.output}")

            env_content = Path(".env").read_text()
            # Original value must still be there, unmodified
            self.assertIn("QUARTUS_LICENSE=2100@my-server", env_content)

    def test_setup_none_clears_value(self):
        """Typing 'none' should remove an existing key from .env."""
        with self.runner.isolated_filesystem():
            from pathlib import Path

            Path(".env").write_text("QUARTUS_LICENSE=2100@old-server\n")

            # Type 'none' for QUARTUS, Enter for rest
            result = self.runner.invoke(
                cli,
                ["docker", "setup"],
                input="none\n\n\n\n\n\n",
            )
            self.assertEqual(result.exit_code, 0, f"Output:\n{result.output}")

            env_content = Path(".env").read_text()
            # Key should be gone
            self.assertNotIn("QUARTUS_LICENSE", env_content)


if __name__ == "__main__":
    unittest.main()
