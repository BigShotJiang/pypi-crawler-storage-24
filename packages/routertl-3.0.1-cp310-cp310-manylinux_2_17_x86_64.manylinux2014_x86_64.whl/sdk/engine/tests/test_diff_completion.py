# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Unit tests for the diff and completion CLI commands."""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli


class TestDiffCommand(unittest.TestCase):
    def setUp(self):
        self.runner = CliRunner()

    @patch("sdk.cli.commands.diff._parse_git_diff")
    def test_no_changes(self, mock_diff):
        """Diff with no changes should print success message."""
        mock_diff.return_value = []
        result = self.runner.invoke(cli, ["diff"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("No changes", result.output)

    @patch("sdk.cli.commands.diff._parse_git_diff")
    def test_no_rtl_files(self, mock_diff):
        """Diff with only non-RTL files should skip analysis."""
        mock_diff.return_value = ["README.md", "scripts/build.sh"]
        result = self.runner.invoke(cli, ["diff"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("No RTL files", result.output)

    @patch("sdk.cli.commands.diff._parse_git_diff")
    def test_rtl_files_no_src_dir(self, mock_diff):
        """Diff with RTL files but missing src dir should warn."""
        mock_diff.return_value = ["src/top.vhd"]
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["diff"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("not found", result.output)


class TestCompletionCommand(unittest.TestCase):
    def setUp(self):
        self.runner = CliRunner()

    def test_bash_completion(self):
        """Bash completion should emit a valid script with rr alias."""
        result = self.runner.invoke(cli, ["completion", "bash"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("_routertl_completion", result.output)
        self.assertIn("complete", result.output)
        # P2.73: rr alias must also have completion
        self.assertIn("_rr_completion", result.output)
        self.assertIn("complete -o default -F _rr_completion rr", result.output)

    def test_zsh_completion(self):
        """Zsh completion should emit a valid script with rr alias."""
        result = self.runner.invoke(cli, ["completion", "zsh"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("compdef", result.output)
        self.assertIn("_routertl", result.output)
        # P2.73: rr alias must also have compdef
        self.assertIn("compdef _rr rr", result.output)

    def test_fish_completion(self):
        """Fish completion should emit a valid script with rr alias."""
        result = self.runner.invoke(cli, ["completion", "fish"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("_routertl_completion", result.output)
        self.assertIn("complete -c routertl", result.output)
        # P2.73: rr alias must also have completion
        self.assertIn("_rr_completion", result.output)
        self.assertIn("complete -c rr", result.output)

    def test_invalid_shell(self):
        """Invalid shell name should fail."""
        result = self.runner.invoke(cli, ["completion", "powershell"])
        self.assertNotEqual(result.exit_code, 0)


if __name__ == "__main__":
    unittest.main()
