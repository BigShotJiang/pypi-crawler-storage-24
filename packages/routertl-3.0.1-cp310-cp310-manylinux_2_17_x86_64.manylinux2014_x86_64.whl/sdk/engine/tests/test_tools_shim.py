# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Regression tests for the tools → sdk backward-compatibility shim.

The `tools/` package was renamed to `sdk/` in v3.1.  The shim in
``tools/__init__.py`` installs a meta-path finder that redirects
``import tools.X`` to ``import sdk.X`` with a DeprecationWarning.

Bug (2026-03-11): The original finder only implemented the legacy
``find_module``/``load_module`` protocol.  Python 3.10's ``runpy``
calls ``loader.get_code()`` — which did not exist — crashing
``python3 -m sdk.cli.main`` inside Docker containers.

Fix: Upgraded to PEP 451 ``find_spec`` + ``_ToolsDeprecationLoader``.
"""

import importlib
import sys
import unittest
import warnings
from pathlib import Path

# Ensure repo root is on sys.path
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


class TestToolsShimFinderProtocol(unittest.TestCase):
    """Validate the _ToolsDeprecationFinder uses the modern import protocol."""

    def setUp(self):
        """Ensure the tools shim is loaded."""
        # Force-import tools to install the finder
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            importlib.import_module("tools")

    def _get_finder(self):
        """Return the _ToolsDeprecationFinder from sys.meta_path."""
        for f in sys.meta_path:
            if type(f).__name__ == "_ToolsDeprecationFinder":
                return f
        self.fail("_ToolsDeprecationFinder not found on sys.meta_path")

    def test_finder_is_installed(self):
        """The finder must be on sys.meta_path after importing tools."""
        finder = self._get_finder()
        self.assertIsNotNone(finder)

    def test_find_spec_returns_none_for_non_tools(self):
        """find_spec must return None for modules not starting with 'tools'."""
        finder = self._get_finder()
        self.assertIsNone(finder.find_spec("sdk"))
        self.assertIsNone(finder.find_spec("sdk.cli.main"))
        self.assertIsNone(finder.find_spec("os"))
        self.assertIsNone(finder.find_spec("toolsmith"))  # prefix trap

    def test_find_spec_returns_spec_for_tools(self):
        """find_spec must return a valid ModuleSpec for 'tools' modules."""
        finder = self._get_finder()
        spec = finder.find_spec("tools")
        self.assertIsNotNone(spec)
        self.assertEqual(spec.name, "tools")

        spec2 = finder.find_spec("tools.cli.main")
        self.assertIsNotNone(spec2)
        self.assertEqual(spec2.name, "tools.cli.main")

    def test_loader_has_get_code(self):
        """The loader must have get_code() for runpy compatibility."""
        finder = self._get_finder()
        spec = finder.find_spec("tools.cli.main")
        self.assertIsNotNone(spec)
        self.assertTrue(hasattr(spec.loader, "get_code"))
        # get_code returns None (no code object to execute directly)
        self.assertIsNone(spec.loader.get_code("tools.cli.main"))

    def test_loader_has_exec_module(self):
        """The loader must implement the modern exec_module protocol."""
        finder = self._get_finder()
        spec = finder.find_spec("tools")
        self.assertTrue(hasattr(spec.loader, "create_module"))
        self.assertTrue(hasattr(spec.loader, "exec_module"))


class TestToolsShimRedirection(unittest.TestCase):
    """Verify that importing tools.X actually loads sdk.X."""

    def test_import_tools_cli_redirects_to_sdk_cli(self):
        """'import tools.cli' must resolve to the sdk.cli module."""
        # Clean up any cached tools.cli to force fresh import
        for key in list(sys.modules.keys()):
            if key.startswith("tools.cli"):
                del sys.modules[key]

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always", DeprecationWarning)
            import tools.cli  # noqa: F401, F811

        # Should have emitted a deprecation warning
        dep_warnings = [x for x in w if issubclass(x.category, DeprecationWarning)]
        self.assertGreater(len(dep_warnings), 0, "No DeprecationWarning emitted")
        self.assertIn("sdk", str(dep_warnings[0].message))


class TestRunpyCompatibility(unittest.TestCase):
    """The exact crash scenario: runpy._get_module_details('sdk.cli.main')."""

    def test_runpy_get_module_details_does_not_crash(self):
        """runpy must resolve sdk.cli.main without AttributeError."""
        import runpy

        # This was the exact call that crashed in Docker
        try:
            mod_name, mod_spec, code = runpy._get_module_details("sdk.cli.main")
        except AttributeError as e:
            if "get_code" in str(e):
                self.fail(
                    f"runpy._get_module_details crashed with: {e}\n"
                    "The _ToolsDeprecationFinder is missing get_code()."
                )
            raise  # Re-raise unexpected AttributeErrors

        self.assertEqual(mod_name, "sdk.cli.main")
        self.assertIsNotNone(mod_spec)


if __name__ == "__main__":
    unittest.main()
