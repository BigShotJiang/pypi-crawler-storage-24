# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Exhaustive pattern-coverage tests for the dependency resolver.

Each test targets a specific VHDL or SystemVerilog instantiation/dependency
pattern identified in the VHDL/SV Instantiation Audit
(conv12_vhdl_sv_instantiation_audit.md).

Test numbering follows the audit table:
  V3  -- VHDL-93 default-binding component instantiation (port map)
  V4  -- VHDL-93 default-binding component instantiation (generic map)
  V3- -- Negative: no false positives on VHDL keywords
  V6  -- Instantiation inside for-generate
  V7  -- Instantiation inside if-generate
  V12 -- use without .all
  V13 -- package body not captured as package name
  V14 -- Multiple entities/packages per file
  S2  -- SV parameterized instantiation
  S6  -- Recursive include chains
  S10 -- SV interface definition
  M3  -- VHDL default-binding of SV module
  Forest -- Forest mode captures default-binding edges
"""

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

# Add project root to path
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.append(str(PM_DIR))

from dependency_resolver import DependencyResolver


class TestResolverPatterns(unittest.TestCase):
    """Exhaustive coverage of VHDL/SV instantiation pattern detection."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    # ------------------------------------------------------------------
    # V3: Default-binding component instantiation (port map)
    # ------------------------------------------------------------------
    def test_vhdl_default_binding_port_map(self):
        """V3: label : ComponentName port map (...) is detected."""
        self.create_file("leaf.vhd", (
            "entity leaf is\n"
            "end entity leaf;\n"
        ))
        self.create_file("top.vhd", (
            "entity top is\n"
            "end entity top;\n"
            "architecture rtl of top is\n"
            "begin\n"
            "    u_leaf : leaf\n"
            "        port map (\n"
            "            clk => clk,\n"
            "            rst => rst\n"
            "        );\n"
            "end architecture;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("top")
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["leaf.vhd", "top.vhd"])

    # ------------------------------------------------------------------
    # V4: Default-binding with generic map
    # ------------------------------------------------------------------
    def test_vhdl_default_binding_generic_map(self):
        """V4: label : ComponentName generic map (...) port map (...) is detected."""
        self.create_file("fifo.vhd", (
            "entity fifo is\n"
            "    generic (DEPTH : natural := 16);\n"
            "end entity fifo;\n"
        ))
        self.create_file("wrapper.vhd", (
            "entity wrapper is\n"
            "end entity wrapper;\n"
            "architecture rtl of wrapper is\n"
            "begin\n"
            "    u_fifo : fifo\n"
            "        generic map (DEPTH => 32)\n"
            "        port map (clk => clk);\n"
            "end architecture;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("wrapper")
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["fifo.vhd", "wrapper.vhd"])

    # ------------------------------------------------------------------
    # V3 Negative: no false positives on VHDL keywords
    # ------------------------------------------------------------------
    def test_vhdl_default_binding_no_false_positive(self):
        """V3 negative: keywords like 'process', 'signal' must not be caught."""
        self.create_file("solo.vhd", (
            "entity solo is\n"
            "end entity solo;\n"
            "architecture rtl of solo is\n"
            "    signal my_sig : std_logic;\n"
            "begin\n"
            "    my_proc : process (clk)\n"
            "    begin\n"
            "        null;\n"
            "    end process;\n"
            "end architecture;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        deps = resolver.find_instantiated_entities_vhdl(self.src_dir / "solo.vhd")
        # Should find zero instantiations (process is not a component)
        self.assertEqual(deps, [])

    # ------------------------------------------------------------------
    # V6: Instantiation inside for-generate
    # ------------------------------------------------------------------
    def test_vhdl_for_generate_instantiation(self):
        """V6: entity instantiation inside for-generate is captured."""
        self.create_file("cell.vhd", (
            "entity cell is\n"
            "end entity cell;\n"
        ))
        self.create_file("array_top.vhd", (
            "entity array_top is\n"
            "end entity array_top;\n"
            "architecture rtl of array_top is\n"
            "begin\n"
            "    GEN: for i in 0 to 3 generate\n"
            "        u_cell : entity work.cell;\n"
            "    end generate;\n"
            "end architecture;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("array_top")
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["cell.vhd", "array_top.vhd"])

    # ------------------------------------------------------------------
    # V7: Instantiation inside if-generate
    # ------------------------------------------------------------------
    def test_vhdl_if_generate_instantiation(self):
        """V7: entity instantiation inside if-generate is captured."""
        self.create_file("gadget.vhd", (
            "entity gadget is\n"
            "end entity gadget;\n"
        ))
        self.create_file("cond_top.vhd", (
            "entity cond_top is\n"
            "    generic (G_ENABLE : boolean := true);\n"
            "end entity cond_top;\n"
            "architecture rtl of cond_top is\n"
            "begin\n"
            "    GEN_COND: if G_ENABLE generate\n"
            "        u_gadget : entity work.gadget;\n"
            "    end generate;\n"
            "end architecture;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("cond_top")
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["gadget.vhd", "cond_top.vhd"])

    # ------------------------------------------------------------------
    # V12: use without .all
    # ------------------------------------------------------------------
    def test_vhdl_use_without_all(self):
        """V12: 'use work.pkg.some_item;' is detected as a package dependency."""
        self.create_file("defs_pkg.vhd", (
            "package defs_pkg is\n"
            "    constant WIDTH : natural := 8;\n"
            "end package defs_pkg;\n"
        ))
        self.create_file("consumer.vhd", (
            "use work.defs_pkg.WIDTH;\n"
            "entity consumer is\n"
            "end entity consumer;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("consumer")
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["defs_pkg.vhd", "consumer.vhd"])

    # ------------------------------------------------------------------
    # V13: Package body not captured as package name
    # ------------------------------------------------------------------
    def test_vhdl_package_body_not_captured(self):
        """V13: 'package body foo is' must NOT register 'body' as a package."""
        self.create_file("math_pkg.vhd", (
            "package math_pkg is\n"
            "    function add(a, b : integer) return integer;\n"
            "end package math_pkg;\n"
            "\n"
            "package body math_pkg is\n"
            "    function add(a, b : integer) return integer is\n"
            "    begin\n"
            "        return a + b;\n"
            "    end function;\n"
            "end package body math_pkg;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        self.assertIn("math_pkg", resolver.package_map)
        self.assertNotIn("body", resolver.package_map)

    # ------------------------------------------------------------------
    # V14: Multiple entities in one file
    # ------------------------------------------------------------------
    def test_vhdl_multi_entity_per_file(self):
        """V14: Two entities in one .vhd file are both discovered."""
        self.create_file("utils.vhd", (
            "entity edge_detector is\n"
            "end entity edge_detector;\n"
            "\n"
            "architecture rtl of edge_detector is\n"
            "begin\n"
            "end architecture;\n"
            "\n"
            "entity glitch_filter is\n"
            "end entity glitch_filter;\n"
            "\n"
            "architecture rtl of glitch_filter is\n"
            "begin\n"
            "end architecture;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        self.assertIn("edge_detector", resolver.entity_map)
        self.assertIn("glitch_filter", resolver.entity_map)

    # ------------------------------------------------------------------
    # V14 variant: Multiple packages in one file
    # ------------------------------------------------------------------
    def test_vhdl_multi_package_per_file(self):
        """V14 variant: Two packages in one .vhd file are both discovered."""
        self.create_file("pkgs.vhd", (
            "package alpha_pkg is\n"
            "    constant A : natural := 1;\n"
            "end package alpha_pkg;\n"
            "\n"
            "package beta_pkg is\n"
            "    constant B : natural := 2;\n"
            "end package beta_pkg;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        self.assertIn("alpha_pkg", resolver.package_map)
        self.assertIn("beta_pkg", resolver.package_map)

    # ------------------------------------------------------------------
    # S2: SV parameterized instantiation
    # ------------------------------------------------------------------
    def test_sv_parameterized_instantiation(self):
        """S2: Parameterized SV instantiation foo #(.W(8)) u_foo (...) is caught."""
        self.create_file("adder.sv", (
            "module adder #(parameter W = 8) (input [W-1:0] a, b, output [W-1:0] s);\n"
            "    assign s = a + b;\n"
            "endmodule\n"
        ))
        self.create_file("top.sv", (
            "module top;\n"
            "    adder #(.W(16)) u_add (.a(a), .b(b), .s(s));\n"
            "endmodule\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("top")
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["adder.sv", "top.sv"])

    # ------------------------------------------------------------------
    # S6: Recursive include chains
    # ------------------------------------------------------------------
    def test_sv_recursive_include(self):
        """S6: a.vh -> b.vh -> c.vh chain is fully resolved."""
        self.create_file("c.vh", "`define C_VAL 42")
        self.create_file("b.vh", '`include "c.vh"\n`define B_VAL 7')
        self.create_file("a.sv", (
            '`include "b.vh"\n'
            "module a;\n"
            "endmodule\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("a")
        filenames = [p.name for p in order]
        # c.vh must come before b.vh, both before a.sv
        self.assertIn("c.vh", filenames)
        self.assertIn("b.vh", filenames)
        self.assertIn("a.sv", filenames)
        self.assertLess(filenames.index("c.vh"), filenames.index("b.vh"))
        self.assertLess(filenames.index("b.vh"), filenames.index("a.sv"))

    # ------------------------------------------------------------------
    # S10: SV interface definition
    # ------------------------------------------------------------------
    def test_sv_interface_definition(self):
        """S10: 'interface axi_if; ... endinterface' is registered in entity_map."""
        self.create_file("axi_if.sv", (
            "interface axi_if (input logic clk);\n"
            "    logic valid;\n"
            "    logic ready;\n"
            "endinterface\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        self.assertIn("axi_if", resolver.entity_map)

    # ------------------------------------------------------------------
    # M3: VHDL default-binding of SV module
    # ------------------------------------------------------------------
    def test_mixed_language_default_binding(self):
        """M3: VHDL default-binding of a SV module is detected."""
        self.create_file("sv_core.sv", "module sv_core; endmodule")
        self.create_file("vhdl_wrap.vhd", (
            "entity vhdl_wrap is\n"
            "end entity vhdl_wrap;\n"
            "architecture rtl of vhdl_wrap is\n"
            "begin\n"
            "    u_core : sv_core\n"
            "        port map (\n"
            "            clk => clk\n"
            "        );\n"
            "end architecture;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order("vhdl_wrap")
        filenames = [p.name for p in order]
        self.assertEqual(filenames, ["sv_core.sv", "vhdl_wrap.vhd"])

    # ------------------------------------------------------------------
    # Forest: Default-binding edges appear in forest graph
    # ------------------------------------------------------------------
    def test_forest_captures_default_binding(self):
        """Forest mode includes default-binding instantiation edges."""
        self.create_file("sub.vhd", (
            "entity sub is\n"
            "end entity sub;\n"
        ))
        self.create_file("top2.vhd", (
            "entity top2 is\n"
            "end entity top2;\n"
            "architecture rtl of top2 is\n"
            "begin\n"
            "    u_sub : sub\n"
            "        port map (dummy => '0');\n"
            "end architecture;\n"
        ))
        resolver = DependencyResolver([self.src_dir], verbose=False)
        forest = resolver.resolve_forest()

        # Find the top2 tree
        top2_tree = None
        for tree in forest["trees"]:
            if tree["top"] == "top2":
                top2_tree = tree
                break

        self.assertIsNotNone(top2_tree, "top2 should appear as a root in the forest")
        # The graph should show top2 -> sub
        self.assertIn("sub", forest["graph"].get("top2", []))


if __name__ == "__main__":
    unittest.main()
