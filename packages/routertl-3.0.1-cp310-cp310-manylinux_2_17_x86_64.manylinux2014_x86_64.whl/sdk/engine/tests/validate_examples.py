#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
CI-style validation of all RouteRTL SDK example projects.

Discovers all examples/ directories with project.yml and runs
`make linting` and `make simulation` in each.
"""

import subprocess
import sys
from pathlib import Path

EXAMPLES_DIR = Path(__file__).resolve().parents[3] / "examples"
MAKE_TARGETS = ["linting", "simulation"]


def discover_examples():
    """Discover example directories with project.yml."""
    if not EXAMPLES_DIR.is_dir():
        print(f"❌ Examples directory not found: {EXAMPLES_DIR}")
        return []
    examples = []
    for d in sorted(EXAMPLES_DIR.iterdir()):
        if d.is_dir() and (d / "project.yml").exists():
            examples.append(d)
    return examples


def run_target(example_dir, target):
    """Run a Make target in the given example directory."""
    cmd = ["make", target]
    result = subprocess.run(
        cmd, cwd=str(example_dir), capture_output=True, text=True
    )
    return result.returncode == 0, result.stdout, result.stderr


def main():
    """Validate all examples pass lint and sim."""
    examples = discover_examples()
    if not examples:
        print("No examples found!")
        sys.exit(1)

    print(f"📋 Found {len(examples)} example(s): {', '.join(e.name for e in examples)}")
    print("=" * 60)

    results = {}
    for ex in examples:
        results[ex.name] = {}
        for target in MAKE_TARGETS:
            print(f"  ▶ {ex.name}/{target}...", end=" ", flush=True)
            passed, stdout, stderr = run_target(ex, target)
            status = "✅ PASS" if passed else "❌ FAIL"
            print(status)
            results[ex.name][target] = passed
            if not passed:
                # Show last 10 lines of output on failure
                output = (stdout + stderr).strip().splitlines()
                for line in output[-10:]:
                    print(f"    | {line}")

    # Summary
    print("=" * 60)
    total = sum(1 for ex in results.values() for t in ex.values() if t)
    total_tests = sum(len(ex) for ex in results.values())
    failed = total_tests - total
    print(f"TOTAL: {total}/{total_tests} passed, {failed} failed")

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
