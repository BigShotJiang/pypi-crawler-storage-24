# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import subprocess
import unittest
from pathlib import Path

import yaml

REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
TOOLS_DIR = REPO_ROOT / "sdk" / "engine"
TEST_YAML = REPO_ROOT / "regression_test.yml"
LINUX_DIR = REPO_ROOT / "linux"


class TestLinuxBindingsRegression(unittest.TestCase):
    def setUp(self):
        self.env = os.environ.copy()
        for k in ["PYTHONHOME", "PYTHONPATH"]:
            if k in self.env:
                del self.env[k]

        # Clean up existing test yaml
        if TEST_YAML.exists():
            TEST_YAML.unlink()

        # Clean up existing linux generation output
        if LINUX_DIR.exists():
            import shutil

            shutil.rmtree(LINUX_DIR)

    def tearDown(self):
        if TEST_YAML.exists():
            TEST_YAML.unlink()
        if LINUX_DIR.exists():
            import shutil

            shutil.rmtree(LINUX_DIR)

        # Clean up dummy project_regbank.yml
        dummy_regbank = REPO_ROOT / "src" / "linux_binding_dummy_regbank.yml"
        if dummy_regbank.exists():
            dummy_regbank.unlink()

        sys_mmap = REPO_ROOT / "system_memory_map.yml"
        if sys_mmap.exists():
            sys_mmap.unlink()

    def test_client_submodule_path_resolution(self):
        """
        Tests that when RouteRTL is used as a submodule (i.e., we call `make` from
        a client `ROOT_DIR`), the deeply nested `generate_uio_bindings.py` and
        `generate_uio_header.py` scripts correctly resolve `regbank_ref` relative to the client project root.
        """

        # 1. Create a dummy regbank in the client's src directory
        src_dir = REPO_ROOT / "src"
        src_dir.mkdir(parents=True, exist_ok=True)
        dummy_regbank = src_dir / "linux_binding_dummy_regbank.yml"

        with open(dummy_regbank, "w") as f:
            f.write("name: dummy_regs\n")
            f.write("version: 1.0.0\n")
            f.write("registers:\n")
            f.write("  - name: CONTROL\n")
            f.write("    address: 0x0000\n")
            f.write("    access: RW\n")
            f.write("    fields:\n")
            f.write("      - name: ENABLE\n")
            f.write("        width: 1\n")
            f.write("        lsb: 0\n")

        # 2. Create system_memory_map.yml referencing the dummy regbank
        # NOTE: the path is relative to the system_memory_map.yml
        sys_mmap = REPO_ROOT / "system_memory_map.yml"
        with open(sys_mmap, "w") as f:
            f.write("version: 1.0.0\n")
            f.write("target: zynq-7000\n")
            f.write("devices:\n")
            f.write("  - name: my_dummy_ip\n")
            f.write("    base_addr: 0x43C00000\n")
            f.write("    span: 0x1000\n")
            f.write("    regbank_ref: src/linux_binding_dummy_regbank.yml\n")

        # 3. Create a dummy project.yml to satisfy Makefile build_env.mk requirement
        with open(TEST_YAML, "w") as f:
            yaml.dump({"project": {"name": "test_linux_proj"}, "hardware": {"vendor": "xilinx"}}, f)

        # 4. Invoke "make gen-linux-all" explicitly using our test yaml
        # gen-linux-all invokes gen-dtbo gen-uio-header gen-uio-bindings
        cmd = ["make", "PROJECT_YML=regression_test.yml", "gen-linux-all"]
        res = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)

        if res.returncode != 0:
            print(f"\nSTDOUT:\n{res.stdout}")
            print(f"\nSTDERR:\n{res.stderr}")

        self.assertEqual(res.returncode, 0, "Make gen-linux-all failed")

        # 5. Assert the files were created in the correct client-root location
        header_path = LINUX_DIR / "include" / "my_dummy_ip_uio.h"
        python_path = LINUX_DIR / "python" / "my_dummy_ip_uio.py"

        self.assertTrue(header_path.exists(), f"Header file not found at {header_path}")
        self.assertTrue(python_path.exists(), f"Python bindings not found at {python_path}")

        # 6. Assert content is enriched thanks to successful path resolution
        with open(header_path, "r") as f:
            header_content = f.read()
            self.assertIn(
                "REG_CONTROL_OFFSET", header_content, "Header missing register offset! Path resolution failed."
            )
            self.assertIn(
                "CONTROL_ENABLE_MASK", header_content, "Header missing bitfield mask! Path resolution failed."
            )

        with open(python_path, "r") as f:
            py_content = f.read()
            self.assertIn("'CONTROL'", py_content, "Python REGMAP missing register! Path resolution failed.")
            self.assertIn("'mask': 1", py_content, "Python REGMAP missing bitfield mask! Path resolution failed.")
            self.assertIn("def read_field", py_content, "Python missing read_field helper function")


if __name__ == "__main__":
    unittest.main()
