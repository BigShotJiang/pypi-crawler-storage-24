# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Unit tests for sdk/cli/sync_version.py and version import chain."""

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[2] / "cli" / "sync_version.py"
SDK_ROOT = Path(__file__).resolve().parents[3]


class TestVersionSync(unittest.TestCase):
    """Tests for the version sync script."""

    def test_sync_generates_version_file(self):
        """Running sync in a temp dir with pyproject.toml creates VERSION."""
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            (root / "pyproject.toml").write_text(
                '[project]\nname = "test"\nversion = "2.5.1"\n'
            )

            result = subprocess.run(
                [
                    sys.executable, "-c",
                    f"import sys; sys.path.insert(0, {str(SCRIPT.parent)!r}); "
                    f"from sync_version import main; "
                    f"from pathlib import Path; "
                    f"sys.exit(main(Path({str(root)!r})))",
                ],
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, f"stderr: {result.stderr}")

            version_file = root / "VERSION"
            self.assertTrue(version_file.exists(), "VERSION file was not created")
            content = version_file.read_text()
            self.assertIn("system_major=2", content)
            self.assertIn("system_minor=5", content)

    def test_sync_updates_stale_version(self):
        """Stale VERSION is overwritten with values from pyproject.toml."""
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            (root / "pyproject.toml").write_text(
                '[project]\nname = "test"\nversion = "4.2.0"\n'
            )
            # Write a stale VERSION
            (root / "VERSION").write_text("system_major=1\nsystem_minor=0\n")

            result = subprocess.run(
                [
                    sys.executable, "-c",
                    f"import sys; sys.path.insert(0, {str(SCRIPT.parent)!r}); "
                    f"from sync_version import main; "
                    f"from pathlib import Path; "
                    f"sys.exit(main(Path({str(root)!r})))",
                ],
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, f"stderr: {result.stderr}")

            content = (root / "VERSION").read_text()
            self.assertIn("system_major=4", content)
            self.assertIn("system_minor=2", content)
            self.assertNotIn("system_major=1", content)

    def test_live_repo_version_matches(self):
        """Running against the live repo: VERSION should match pyproject.toml."""
        result = subprocess.run(
            [sys.executable, str(SCRIPT)],
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, f"stderr: {result.stderr}")
        self.assertIn("synced", result.stdout.lower())


class TestVersionImport(unittest.TestCase):
    """Tests for the runtime version import chain."""

    def test_routertl_core_version_matches_pyproject(self):
        """routertl_core.__version__ should match pyproject.toml at runtime."""
        import re

        from routertl_core import __version__

        pyproject = SDK_ROOT / "pyproject.toml"
        text = pyproject.read_text()
        match = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
        self.assertIsNotNone(match, "Could not parse version from pyproject.toml")

        pyproject_version = match.group(1)
        self.assertEqual(
            __version__,
            pyproject_version,
            f"routertl_core.__version__ ({__version__}) != pyproject.toml ({pyproject_version})",
        )


if __name__ == "__main__":
    unittest.main()
