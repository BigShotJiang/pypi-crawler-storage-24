# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Docker smoke test — validates CLI functionality inside the container.

Skips gracefully if:
  - Docker is not available
  - The routertl-sim image hasn't been built yet
  - The image is stale (built before .pth / wrapper / completion changes)

Does NOT build the image — uses whatever is already available.
"""

import subprocess
import unittest


def _docker_available():
    """Check if Docker is available and the sim image exists."""
    try:
        result = subprocess.run(
            ["docker", "image", "inspect", "routertl-sim:latest"],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _image_has_feature(feature_cmd):
    """Probe whether the Docker image supports a specific feature."""
    try:
        result = subprocess.run(
            ["docker", "run", "--rm", "routertl-sim:latest", "bash", "-c", feature_cmd],
            capture_output=True,
            text=True,
            timeout=15,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


# Feature probe: check for .pth file (added in the namespace fix commit)
_HAS_PTH = None


def _image_has_pth():
    global _HAS_PTH
    if _HAS_PTH is None:
        _HAS_PTH = _image_has_feature(
            'python3 -c "import site, os; '
            "exit(0 if os.path.exists(os.path.join(site.getsitepackages()[0], 'routertl.pth')) else 1)\""
        )
    return _HAS_PTH


@unittest.skipUnless(_docker_available(), "Docker not available or routertl-sim image not built")
class TestDockerSmoke(unittest.TestCase):
    """End-to-end smoke test running inside the routertl-sim container."""

    IMAGE = "routertl-sim:latest"
    TIMEOUT = 30

    def _run(self, cmd):
        """Run a command inside the Docker container."""
        return subprocess.run(
            ["docker", "run", "--rm", self.IMAGE, "bash", "-c", cmd],
            capture_output=True,
            text=True,
            timeout=self.TIMEOUT,
        )

    # ── Always-valid tests (present in all image versions) ──

    def test_python_version(self):
        """Python 3.9+ should be available."""
        result = self._run("python3 --version")
        self.assertEqual(result.returncode, 0)
        self.assertIn("Python 3.", result.stdout)

    def test_simulator_available(self):
        """At least one simulator (nvc or verilator) should be installed."""
        result = self._run("which nvc || which verilator")
        self.assertEqual(result.returncode, 0, "No simulator found in Docker image")

    # ── Feature-gated tests (require recent image rebuild) ──

    @unittest.skipUnless(_image_has_pth(), "Image stale — rebuild with: routertl docker install sim")
    def test_pth_file_content(self):
        """The .pth file should point to /home/runner/work/vendor."""
        result = self._run(
            "python3 -c \"import site; print(open(site.getsitepackages()[0] + '/routertl.pth').read().strip())\""
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("/home/runner/work/vendor", result.stdout)

    @unittest.skipUnless(_image_has_pth(), "Image stale — rebuild with: routertl docker install sim")
    def test_routertl_wrapper_exists(self):
        """The routertl wrapper script should be installed at /usr/local/bin."""
        result = self._run("test -x /usr/local/bin/routertl && echo OK")
        self.assertEqual(result.returncode, 0)
        self.assertIn("OK", result.stdout)

    @unittest.skipUnless(_image_has_pth(), "Image stale — rebuild with: routertl docker install sim")
    def test_routertl_wrapper_content(self):
        """The wrapper should reference the SDK path and sdk.cli.main."""
        result = self._run("cat /usr/local/bin/routertl")
        self.assertEqual(result.returncode, 0)
        self.assertIn("sdk.cli.main", result.stdout)
        self.assertIn("vendor/routertl", result.stdout)

    @unittest.skipUnless(_image_has_pth(), "Image stale — rebuild with: routertl docker install sim")
    def test_shell_completion_hooked(self):
        """Shell completion should be configured in /etc/bash.bashrc."""
        result = self._run("grep -c 'completion bash' /etc/bash.bashrc")
        self.assertEqual(result.returncode, 0)
        count = int(result.stdout.strip())
        self.assertGreaterEqual(count, 1)


class TestQuartusVolumeResolution(unittest.TestCase):
    """Verify edition-aware Quartus Docker volume resolution.

    These are unit tests — they don't require Docker.
    """

    def test_default_volume_no_edition(self):
        """No edition in project.yml → default volume name."""
        from sdk.cli.commands.docker import _resolve_quartus_volume

        result = _resolve_quartus_volume(edition=None)
        # Without a project.yml in cwd, falls back to default
        self.assertEqual(result, "routertl_quartus_opt")

    def test_pro_edition_volume(self):
        """Explicit pro edition → pro-specific volume."""
        from sdk.cli.commands.docker import _resolve_quartus_volume

        self.assertEqual(
            _resolve_quartus_volume(edition="pro"),
            "routertl_quartus_pro_opt",
        )

    def test_standard_edition_volume(self):
        """Explicit standard edition → standard-specific volume."""
        from sdk.cli.commands.docker import _resolve_quartus_volume

        self.assertEqual(
            _resolve_quartus_volume(edition="standard"),
            "routertl_quartus_std_opt",
        )

    def test_lite_edition_volume(self):
        """Explicit lite edition → lite-specific volume."""
        from sdk.cli.commands.docker import _resolve_quartus_volume

        self.assertEqual(
            _resolve_quartus_volume(edition="lite"),
            "routertl_quartus_lite_opt",
        )

    def test_unknown_edition_falls_back(self):
        """Unknown edition string → default volume."""
        from sdk.cli.commands.docker import _resolve_quartus_volume

        self.assertEqual(
            _resolve_quartus_volume(edition="enterprise"),
            "routertl_quartus_opt",
        )

    def test_empty_edition_falls_back(self):
        """Empty edition string → default volume."""
        from sdk.cli.commands.docker import _resolve_quartus_volume

        self.assertEqual(
            _resolve_quartus_volume(edition=""),
            "routertl_quartus_opt",
        )

    def test_resolve_volume_quartus_delegates(self):
        """_resolve_volume('quartus') delegates to edition-aware resolver."""
        from sdk.cli.commands.docker import _resolve_volume

        # With explicit edition
        self.assertEqual(
            _resolve_volume("quartus", edition="pro"),
            "routertl_quartus_pro_opt",
        )

    def test_resolve_volume_non_quartus_static(self):
        """_resolve_volume for non-Quartus envs returns static map value."""
        from sdk.cli.commands.docker import _resolve_volume

        self.assertEqual(_resolve_volume("vivado"), "routertl_vivado_opt")
        self.assertEqual(_resolve_volume("riviera"), "routertl_riviera_opt")
        self.assertIsNone(_resolve_volume("sim"))

    def test_edition_from_project_yml(self):
        """Edition read from project.yml when no explicit edition given."""
        import os
        import tempfile

        from sdk.cli.commands.docker import _resolve_quartus_volume

        with tempfile.TemporaryDirectory() as tmpdir:
            yml = os.path.join(tmpdir, "project.yml")
            with open(yml, "w") as f:
                f.write(
                    "project:\n  name: test\n  top_module: top\n"
                    "hardware:\n  vendor: altera\n  edition: pro\n"
                )
            old_cwd = os.getcwd()
            os.chdir(tmpdir)
            try:
                result = _resolve_quartus_volume()
                self.assertEqual(result, "routertl_quartus_pro_opt")
            finally:
                os.chdir(old_cwd)

    def test_compose_file_uses_parameterized_volume(self):
        """docker-compose.quartus.yml must use ${QUARTUS_VOLUME_NAME} variable."""
        from pathlib import Path
        compose = Path(__file__).resolve().parent.parent.parent / "infra" / "docker" / "docker-compose.quartus.yml"
        self.assertTrue(compose.exists(), "docker-compose.quartus.yml not found")
        content = compose.read_text()
        self.assertIn(
            "${QUARTUS_VOLUME_NAME:-routertl_quartus_opt}",
            content,
            "Compose file must use parameterized volume name for edition support",
        )

    def test_no_direct_volume_map_in_commands(self):
        """Commands must use _resolve_volume(), not _VOLUME_MAP directly.

        Regression test for P2.47 — add-device, add-patch, and uninstall
        previously bypassed edition-aware volume resolution.
        """
        import inspect
        import re

        from sdk.cli.commands.docker.device import docker_add_device, docker_add_patch
        from sdk.cli.commands.docker.uninstall import docker_uninstall

        # Functions that must NOT use _VOLUME_MAP directly for volume lookup
        # Click wraps functions into RichCommand — unwrap via .callback
        command_fns = [
            docker_add_device.callback,
            docker_add_patch.callback,
            docker_uninstall.callback,
        ]
        # Match direct lookups (_VOLUME_MAP[ or _VOLUME_MAP.get) but not
        # _VOLUME_MAP.keys() which is fine for CLI argument choices.
        pattern = re.compile(r"_VOLUME_MAP\s*(?:\[|\.get\()")
        for fn in command_fns:
            src = inspect.getsource(fn)
            matches = pattern.findall(src)
            self.assertEqual(
                len(matches), 0,
                f"{fn.__name__} uses _VOLUME_MAP directly — "
                f"use _resolve_volume() for edition-aware resolution",
            )


if __name__ == "__main__":
    unittest.main()
