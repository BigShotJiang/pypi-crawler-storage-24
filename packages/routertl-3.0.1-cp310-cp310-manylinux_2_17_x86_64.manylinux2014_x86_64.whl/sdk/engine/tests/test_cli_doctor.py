# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for the rr doctor CLI command: health checks, fix suggestions,
LFS checks, build_env staleness, vendor-aware checks, and license checks.

Split from test_cli.py as part of P2.66.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli


class TestDoctorCommand(unittest.TestCase):
    """Tests for the rr doctor command and its individual checks."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("sdk.cli.checks.vendor_tools._load_project_yml")
    @patch("sdk.cli.commands.license.resolve_tool_binary")
    def test_doctor_vendor_aware_checks_quartus(self, mock_resolve, mock_yml):
        """Doctor should check quartus_sh when vendor is altera."""
        mock_yml.return_value = {"hardware": {"vendor": "altera"}}
        mock_resolve.return_value = "/opt/altera/bin/quartus_sh"

        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.vendor_tools import check_vendor_tool

        result = check_vendor_tool()
        self.assertEqual(result.title, "Quartus")
        self.assertEqual(result.status, CheckResult.OK)
        # Verify it checked for quartus_sh (not vivado)
        mock_resolve.assert_called_with("quartus_sh")

    @patch("sdk.cli.checks.vendor_tools._load_project_yml")
    @patch("sdk.cli.commands.license.resolve_tool_binary")
    def test_doctor_defaults_to_vivado_for_xilinx(self, mock_resolve, mock_yml):
        """Doctor should check vivado when vendor is xilinx or missing."""
        mock_yml.return_value = {"hardware": {"vendor": "xilinx"}}
        mock_resolve.return_value = None

        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.vendor_tools import check_vendor_tool

        result = check_vendor_tool()
        self.assertEqual(result.title, "Vivado")
        self.assertEqual(result.status, CheckResult.WARN)
        mock_resolve.assert_called_with("vivado")

    def test_doctor_with_valid_project(self):
        """Doctor should run cleanly with a valid project.yml."""
        with self.runner.isolated_filesystem():
            import yaml

            config = {
                "project": {"name": "test_proj", "top_module": "my_top"},
                "hardware": {"vendor": "xilinx", "part": "xc7z020clg400-1"},
            }
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["doctor"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("Doctor", result.output)
            self.assertIn("Python", result.output)
            self.assertIn("project.yml", result.output)

    def test_doctor_without_project_yml(self):
        """Doctor should warn about missing project.yml but not crash."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["doctor"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("project.yml", result.output)
            self.assertIn("not found", result.output)

    def test_doctor_with_malformed_project_yml(self):
        """Doctor should report YAML parse errors."""
        with self.runner.isolated_filesystem():
            with open("project.yml", "w") as f:
                f.write(":\n  - :\n    bad: [unmatched")

            result = self.runner.invoke(cli, ["doctor"])
            self.assertEqual(result.exit_code, 0)
            # Should report an error for project.yml, not crash
            self.assertIn("project.yml", result.output)

    def test_doctor_check_functions(self):
        """Individual check functions should return CheckResult objects."""
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.environment import check_python, check_venv

        # Python check should always succeed in test environment
        r = check_python()
        self.assertIsInstance(r, CheckResult)
        self.assertEqual(r.status, CheckResult.OK)
        self.assertIn("v3", r.detail)

        # Venv check (may vary by environment, just verify it doesn't crash)
        r = check_venv()
        self.assertIsInstance(r, CheckResult)
        self.assertIn(r.status, [CheckResult.OK, CheckResult.WARN])

    def test_doctor_build_env_staleness(self):
        """build_env.mk staleness check should detect stale configs."""

        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.workspace import check_build_env_staleness

        with self.runner.isolated_filesystem():
            # No project.yml — should warn
            r = check_build_env_staleness()
            self.assertEqual(r.status, CheckResult.WARN)

            # project.yml exists, build_env.mk missing — should fail
            with open("project.yml", "w") as f:
                f.write("project:\n  name: test\n")
            r = check_build_env_staleness()
            self.assertEqual(r.status, CheckResult.FAIL)

            # Both exist, build_env.mk newer — should be OK
            with open("build_env.mk", "w") as f:
                f.write("# auto-generated\n")
            r = check_build_env_staleness()
            self.assertEqual(r.status, CheckResult.OK)

    # ──────────────────────────────────────────────────────────
    # Feature: Doctor fix suggestions (P2)
    # ──────────────────────────────────────────────────────────
    def test_doctor_fix_cmd_build_env_missing(self):
        """build_env.mk missing should include fix_cmd with 'ws update-config'."""
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.workspace import check_build_env_staleness

        with self.runner.isolated_filesystem():
            with open("project.yml", "w") as f:
                f.write("project:\n  name: test\n")
            r = check_build_env_staleness()
            self.assertEqual(r.status, CheckResult.FAIL)
            self.assertIsNotNone(r.fix_cmd)
            self.assertIn("ws update-config", r.fix_cmd)

    @patch("sdk.cli.checks.workspace._run")
    def test_doctor_fix_cmd_hooks_missing(self, mock_run):
        """Missing hooks should include fix_cmd with 'ws install-hooks'."""
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.workspace import check_git_hooks

        # Simulate: in a git repo, no core.hooksPath, no hooks/pre-commit
        def side_effect(cmd, **kwargs):
            if cmd == ["git", "rev-parse", "--git-dir"]:
                return 0, ".git"
            if cmd == ["git", "config", "core.hooksPath"]:
                return 1, ""
            return 0, ""

        mock_run.side_effect = side_effect

        with self.runner.isolated_filesystem():
            r = check_git_hooks()
            self.assertEqual(r.status, CheckResult.WARN)
            self.assertIsNotNone(r.fix_cmd)
            self.assertIn("ws install-hooks", r.fix_cmd)

    def test_doctor_fix_cmd_venv_missing(self):
        """Missing venv should include fix_cmd with 'ws install'."""
        import os

        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.environment import check_venv

        with self.runner.isolated_filesystem():
            env = os.environ.copy()
            env.pop("VIRTUAL_ENV", None)
            with patch.dict("os.environ", env, clear=True):
                r = check_venv()
                if r.status == CheckResult.WARN and ".venv" not in r.detail:
                    self.assertIsNotNone(r.fix_cmd)
                    self.assertIn("ws install", r.fix_cmd)

    def test_doctor_fix_cmd_rendered_cyan(self):
        """Doctor output should contain cyan fix commands when checks fail."""
        with self.runner.isolated_filesystem():
            # No project.yml, no build_env.mk → several fix_cmds should appear
            result = self.runner.invoke(cli, ["doctor"])
            self.assertEqual(result.exit_code, 0)
            # The rendered fix command prefix
            self.assertIn("$ ", result.output)

    def test_doctor_ok_no_fix_cmd(self):
        """Passing checks should have fix_cmd = None."""
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.environment import check_python

        r = check_python()
        self.assertEqual(r.status, CheckResult.OK)
        self.assertIsNone(r.fix_cmd)

    # ──────────────────────────────────────────────────────────
    # Feature: Doctor LFS health check (P1)
    # ──────────────────────────────────────────────────────────
    @patch("sdk.cli.checks.workspace._run")
    def test_doctor_lfs_not_installed(self, mock_run):
        """LFS check should WARN when git-lfs is not installed."""
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.workspace import check_lfs

        def side_effect(cmd, **kwargs):
            if cmd == ["git", "rev-parse", "--git-dir"]:
                return 0, ".git"
            if cmd == ["git", "lfs", "version"]:
                return 1, "git: 'lfs' is not a git command"
            return 0, ""

        mock_run.side_effect = side_effect
        r = check_lfs()
        self.assertEqual(r.status, CheckResult.WARN)
        self.assertIn("not installed", r.detail)
        self.assertIsNotNone(r.fix_cmd)
        self.assertIn("git-lfs", r.fix_cmd)

    @patch("sdk.cli.checks.workspace._run")
    def test_doctor_lfs_all_pulled(self, mock_run):
        """LFS check should be OK when all files are smudged."""
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.workspace import check_lfs

        def side_effect(cmd, **kwargs):
            if cmd == ["git", "rev-parse", "--git-dir"]:
                return 0, ".git"
            if cmd == ["git", "lfs", "version"]:
                return 0, "git-lfs/3.5.1 (GitHub; linux amd64)"
            if cmd == ["git", "lfs", "ls-files"]:
                return 0, "abc1234567 * hw/netlists/my_ip.qxp\ndef7890123 * hw/netlists/other.edf\n"
            return 0, ""

        mock_run.side_effect = side_effect
        r = check_lfs()
        self.assertEqual(r.status, CheckResult.OK)
        self.assertIn("2 files pulled", r.detail)

    @patch("sdk.cli.checks.workspace._run")
    def test_doctor_lfs_unpulled_files(self, mock_run):
        """LFS check should WARN when pointer stubs are detected."""
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.workspace import check_lfs

        def side_effect(cmd, **kwargs):
            if cmd == ["git", "rev-parse", "--git-dir"]:
                return 0, ".git"
            if cmd == ["git", "lfs", "version"]:
                return 0, "git-lfs/3.5.1 (GitHub; linux amd64)"
            if cmd == ["git", "lfs", "ls-files"]:
                return 0, "abc1234567 * hw/netlists/good.qxp\ndef7890123 - hw/netlists/bad.qxp\n"
            return 0, ""

        mock_run.side_effect = side_effect
        r = check_lfs()
        self.assertEqual(r.status, CheckResult.WARN)
        self.assertIn("1 file not pulled", r.detail)
        self.assertIn("bad.qxp", r.detail)
        self.assertEqual(r.fix_cmd, "git lfs pull")

    @patch("sdk.cli.checks.workspace._run")
    def test_doctor_lfs_not_in_git_repo(self, mock_run):
        """LFS check should WARN gracefully when not in a git repo."""
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.workspace import check_lfs

        mock_run.return_value = (128, "fatal: not a git repository")
        r = check_lfs()
        self.assertEqual(r.status, CheckResult.WARN)
        self.assertIn("not in a git repository", r.detail)


class TestDoctorLicenseCheck(unittest.TestCase):
    """Tests for license server checks in rr doctor."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("sdk.cli.commands.docker.status._probe_license_server", return_value=True)
    @patch.dict("os.environ", {"LM_LICENSE_FILE": "2100@lic-server"})
    def test_license_server_reachable(self, mock_probe):
        """Doctor should report reachable when probe succeeds."""
        from sdk.cli.checks.vendor_tools import _check_license_server

        results = _check_license_server()
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0].title, "License Server")
        self.assertIn("reachable", results[0].detail)
        mock_probe.assert_called_once_with("2100@lic-server")

    @patch.dict("os.environ", {}, clear=True)
    def test_license_server_not_configured(self):
        """Doctor should warn when LM_LICENSE_FILE is not set."""
        from sdk.cli.checks.vendor_tools import _check_license_server

        with self.runner.isolated_filesystem():
            # No .env file, no env var
            results = _check_license_server()
            self.assertTrue(len(results) > 0)
            self.assertEqual(results[0].title, "License Server")
            self.assertIn("not set", results[0].detail)


if __name__ == "__main__":
    unittest.main()
