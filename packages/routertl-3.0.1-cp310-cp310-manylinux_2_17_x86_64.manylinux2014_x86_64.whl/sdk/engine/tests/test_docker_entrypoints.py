# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for Docker shell entrypoints and container environment.

Validates that Docker entrypoint scripts correctly:
1. Preserve PATH and SIM environment variables through 'su'
2. Suppress bash terminal noise with stderr redirection
3. Avoid login shell (-) which resets environment via PAM
4. Show the active simulator on entry

Also validates sdk_requirements.yml correctness and check_env.py
Docker PATH augmentation logic.
"""

import os
import re
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

# ── sys.path setup (test may run from different CWDs) ──
TESTS_DIR = Path(__file__).resolve().parent
PROJECT_MANAGER_DIR = TESTS_DIR.parent
TOOLS_DIR = PROJECT_MANAGER_DIR.parent
SDK_ROOT = TOOLS_DIR.parent
sys.path.insert(0, str(PROJECT_MANAGER_DIR))
sys.path.insert(0, str(SDK_ROOT))

DOCKER_DIR = SDK_ROOT / "sdk" / "infra" / "docker"
REQUIREMENTS_FILE = SDK_ROOT / "sdk_requirements.yml"


class TestEntrypointScripts(unittest.TestCase):
    """Static validation of Docker entrypoint shell scripts.

    These tests catch the recurring bugs:
    - PATH not preserved through 'su' (rr not found)
    - SIM not set (wrong simulator used)
    - bash terminal noise (cannot set terminal process group)
    """

    ENTRYPOINTS = {
        "riviera": DOCKER_DIR / "install_riviera.sh",
        "quartus": DOCKER_DIR / "install_quartus.sh",
        "questa": DOCKER_DIR / "install_questa.sh",
    }

    # Expected SIM value for each container
    EXPECTED_SIM = {
        "riviera": "riviera",
        "quartus": "questa",
        "questa": "questa",
    }

    def _load_script(self, name):
        path = self.ENTRYPOINTS[name]
        self.assertTrue(path.exists(), f"{path} does not exist")
        return path.read_text()

    def test_riviera_su_embeds_path_in_command_string(self):
        """PATH must be set INSIDE the su -c string, not before it.

        'su' goes through PAM which resets environment variables.
        Exporting before 'su' does NOT work.
        """
        content = self._load_script("riviera")
        # Find su -c command strings
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        self.assertTrue(len(su_calls) > 0, "No 'su -c' calls found in riviera script")

        for cmd in su_calls:
            self.assertIn("PATH", cmd, "su -c command must set PATH inside the string (PAM resets env)")

    def test_riviera_su_embeds_sim_in_command_string(self):
        """SIM must be set INSIDE the su -c string."""
        content = self._load_script("riviera")
        # The main handover (last su call) must set SIM
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        last_su = su_calls[-1] if su_calls else ""
        self.assertIn("SIM=riviera", last_su, "su -c command must set SIM=riviera inside the string")

    def test_riviera_no_login_shell_flag(self):
        """Must NOT use 'su -' (login shell) — it resets PATH via PAM."""
        content = self._load_script("riviera")
        # Match 'su -' but not 'su -s' or 'su -c'
        login_shells = re.findall(r"su\s+-\s+(?!s\b|c\b)", content)
        self.assertEqual(len(login_shells), 0, f"Found login shell 'su -' usage (resets env): {login_shells}")

    def test_riviera_no_stderr_suppression(self):
        """su stderr must NOT be redirected — bash writes PS1 to stderr!"""
        content = self._load_script("riviera")
        # Find lines with exec su that also have 2>/dev/null
        bad_lines = [l.strip() for l in content.splitlines() if "exec su" in l and "2>/dev/null" in l]
        self.assertEqual(len(bad_lines), 0, f"Found exec su with 2>/dev/null (kills PS1 prompt): {bad_lines}")

    def test_riviera_includes_usr_local_bin(self):
        """PATH must include /usr/local/bin for the rr symlink."""
        content = self._load_script("riviera")
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        last_su = su_calls[-1] if su_calls else ""
        self.assertIn("/usr/local/bin", last_su, "PATH inside su -c must include /usr/local/bin (rr symlink location)")

    def test_all_entrypoints_set_sim(self):
        """Every entrypoint must export SIM for auto-simulator selection."""
        for name, expected_sim in self.EXPECTED_SIM.items():
            content = self._load_script(name)
            self.assertIn(f"SIM={expected_sim}", content, f"{name} entrypoint must set SIM={expected_sim}")

    def test_all_entrypoints_show_simulator_banner(self):
        """Every entrypoint must show the active simulator on entry."""
        for name in self.ENTRYPOINTS:
            content = self._load_script(name)
            self.assertIn("Active simulator", content, f"{name} entrypoint must show active simulator banner")

    # ── Quartus su pattern tests (mirrors Riviera) ──

    def test_quartus_su_embeds_path_in_command_string(self):
        """PATH must be set INSIDE the su -c string (PAM resets env)."""
        content = self._load_script("quartus")
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        self.assertTrue(len(su_calls) > 0, "No 'su -c' calls found in quartus script")
        for cmd in su_calls:
            self.assertIn("PATH", cmd, "su -c command must set PATH inside the string (PAM resets env)")

    def test_quartus_su_embeds_sim_in_command_string(self):
        """SIM must be set INSIDE the su -c string."""
        content = self._load_script("quartus")
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        last_su = su_calls[-1] if su_calls else ""
        self.assertIn("SIM=questa", last_su, "su -c command must set SIM=questa inside the string")

    def test_quartus_no_login_shell_flag(self):
        """Must NOT use 'su -' (login shell) — it resets PATH via PAM."""
        content = self._load_script("quartus")
        login_shells = re.findall(r"su\s+-\s+(?!s\b|c\b)", content)
        self.assertEqual(len(login_shells), 0, f"Found login shell 'su -' usage (resets env): {login_shells}")

    def test_quartus_no_stderr_suppression(self):
        """su stderr must NOT be redirected — bash writes PS1 to stderr!"""
        content = self._load_script("quartus")
        bad_lines = [l.strip() for l in content.splitlines() if "exec su" in l and "2>/dev/null" in l]
        self.assertEqual(len(bad_lines), 0, f"Found exec su with 2>/dev/null (kills PS1 prompt): {bad_lines}")

    def test_quartus_includes_usr_local_bin(self):
        """PATH must include /usr/local/bin for the rr symlink."""
        content = self._load_script("quartus")
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        last_su = su_calls[-1] if su_calls else ""
        self.assertIn("/usr/local/bin", last_su, "PATH inside su -c must include /usr/local/bin (rr symlink location)")

    # ── Quartus device support tests ──

    def test_quartus_has_device_inventory_function(self):
        """install_quartus.sh must contain the device_inventory function."""
        content = self._load_script("quartus")
        self.assertIn("device_inventory()", content, "install_quartus.sh must define device_inventory()")

    def test_quartus_checks_quartus_devices_env(self):
        """Script must reference QUARTUS_DEVICES for expected-device validation."""
        content = self._load_script("quartus")
        self.assertIn("QUARTUS_DEVICES", content, "install_quartus.sh must reference QUARTUS_DEVICES env var")

    def test_quartus_has_installer_selection(self):
        """Script must handle multiple .tar files with selection logic."""
        content = self._load_script("quartus")
        self.assertIn("select_installer", content, "install_quartus.sh must have select_installer function")

    def test_quartus_ci_uses_installer_index(self):
        """Script must reference QUARTUS_INSTALLER_INDEX for CI headless mode."""
        content = self._load_script("quartus")
        self.assertIn("QUARTUS_INSTALLER_INDEX", content, "install_quartus.sh must support QUARTUS_INSTALLER_INDEX")

    def test_quartus_device_inventory_filters_admin_dirs(self):
        """device_inventory must use admin dir deny-list for filtering.

        Regression: Quartus Standard puts admin directories (configuration,
        dev_install, legacy, programmer) in quartus/common/devinfo/. Without
        filtering, these appear as 'Installed Device Families'.
        Also: Quartus Standard names device dirs by process node (20nm, 28nm)
        not family name — an allowlist approach misses these.
        """
        content = self._load_script("quartus")
        func_match = re.search(
            r"device_inventory\(\)\s*\{(.*?)^\}", content, re.DOTALL | re.MULTILINE
        )
        self.assertIsNotNone(func_match, "Could not find device_inventory function body")
        func_body = func_match.group(1)
        # Must use deny-list (admin_dirs) to filter device entries
        self.assertIn("admin_dirs", func_body,
                       "device_inventory must use admin_dirs deny-list to filter device entries")

    def test_quartus_device_inventory_supports_pro_layout(self):
        """device_inventory must detect Pro edition devices/ directory.

        Pro edition stores device families in {root}/devices/ instead of
        quartus/common/devinfo/. The function must check for this path.
        """
        content = self._load_script("quartus")
        func_match = re.search(
            r"device_inventory\(\)\s*\{(.*?)^\}", content, re.DOTALL | re.MULTILINE
        )
        self.assertIsNotNone(func_match, "Could not find device_inventory function body")
        func_body = func_match.group(1)
        self.assertIn("devices", func_body,
                       "device_inventory must support Pro layout (devices/ dir)")

    def test_quartus_no_top_level_scan(self):
        """device_inventory must NOT scan top-level dirs as device families.

        Regression: The old Strategy 2 scanned ${install_dir}/*/ and
        reported non-device dirs (licenses, niosv, questa_fse, riscfree)
        as installed device families.
        """
        content = self._load_script("quartus")
        func_match = re.search(
            r"device_inventory\(\)\s*\{(.*?)^\}", content, re.DOTALL | re.MULTILINE
        )
        self.assertIsNotNone(func_match, "Could not find device_inventory function body")
        func_body = func_match.group(1)
        # Must NOT have a top-level scan pattern (Strategy 2 was removed)
        self.assertNotIn("top_skip", func_body,
                          "device_inventory must NOT use top_skip (Strategy 2 removed)")

    # ── Quartus add-device script tests ──

    def test_add_device_script_exists(self):
        """add_device_quartus.sh must exist alongside other entrypoints."""
        script = DOCKER_DIR / "add_device_quartus.sh"
        self.assertTrue(script.exists(), f"{script} does not exist")

    def test_add_device_checks_existing_install(self):
        """Script must validate Quartus is already installed before adding devices."""
        content = (DOCKER_DIR / "add_device_quartus.sh").read_text()
        self.assertIn("not installed", content.lower(),
                      "add_device_quartus.sh must check for existing Quartus install")

    def test_add_device_uses_unzip(self):
        """Script must use unzip for direct .qdz extraction (ZIP format)."""
        content = (DOCKER_DIR / "add_device_quartus.sh").read_text()
        self.assertIn("unzip", content,
                      "add_device_quartus.sh must use unzip for .qdz extraction")

    def test_add_device_shows_post_install_inventory(self):
        """Script must show device inventory after installation."""
        content = (DOCKER_DIR / "add_device_quartus.sh").read_text()
        self.assertIn("post-install", content.lower(),
                      "add_device_quartus.sh must show post-install device inventory")

    # ── Quartus add-patch script tests ──

    def test_add_patch_script_exists(self):
        """add_patch_quartus.sh must exist alongside other entrypoints."""
        script = DOCKER_DIR / "add_patch_quartus.sh"
        self.assertTrue(script.exists(), f"{script} does not exist")

    def test_add_patch_checks_existing_install(self):
        """Script must validate Quartus is already installed before patching."""
        content = (DOCKER_DIR / "add_patch_quartus.sh").read_text()
        self.assertIn("not installed", content.lower(),
                      "add_patch_quartus.sh must check for existing Quartus install")

    def test_add_patch_uses_run_installer(self):
        """Script must extract and execute a .run patch installer."""
        content = (DOCKER_DIR / "add_patch_quartus.sh").read_text()
        self.assertIn("-linux.run", content,
                      "add_patch_quartus.sh must handle *-linux.run patch files")

    def test_add_patch_shows_version_after(self):
        """Script must show Quartus version after patching."""
        content = (DOCKER_DIR / "add_patch_quartus.sh").read_text()
        self.assertIn("after patching", content.lower(),
                      "add_patch_quartus.sh must show version after patching")

    # ── Questa su pattern tests (mirrors Riviera) ──

    def test_questa_su_embeds_path_in_command_string(self):
        """PATH must be set INSIDE the su -c string (PAM resets env)."""
        content = self._load_script("questa")
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        self.assertTrue(len(su_calls) > 0, "No 'su -c' calls found in questa script")
        for cmd in su_calls:
            self.assertIn("PATH", cmd, "su -c command must set PATH inside the string (PAM resets env)")

    def test_questa_su_embeds_sim_in_command_string(self):
        """SIM must be set INSIDE the su -c string."""
        content = self._load_script("questa")
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        last_su = su_calls[-1] if su_calls else ""
        self.assertIn("SIM=questa", last_su, "su -c command must set SIM=questa inside the string")

    def test_questa_no_login_shell_flag(self):
        """Must NOT use 'su -' (login shell) — it resets PATH via PAM."""
        content = self._load_script("questa")
        login_shells = re.findall(r"su\s+-\s+(?!s\b|c\b)", content)
        self.assertEqual(len(login_shells), 0, f"Found login shell 'su -' usage (resets env): {login_shells}")

    def test_questa_no_stderr_suppression(self):
        """su stderr must NOT be redirected — bash writes PS1 to stderr!"""
        content = self._load_script("questa")
        bad_lines = [l.strip() for l in content.splitlines() if "exec su" in l and "2>/dev/null" in l]
        self.assertEqual(len(bad_lines), 0, f"Found exec su with 2>/dev/null (kills PS1 prompt): {bad_lines}")

    def test_questa_includes_usr_local_bin(self):
        """PATH must include /usr/local/bin for the rr symlink."""
        content = self._load_script("questa")
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        last_su = su_calls[-1] if su_calls else ""
        self.assertIn("/usr/local/bin", last_su, "PATH inside su -c must include /usr/local/bin (rr symlink location)")

    # ── Progress indicator stale-watchdog tests ──

    def test_progress_uses_setsid(self):
        """install_progress.sh must launch the installer via setsid.

        Regression: Without setsid, orphan child processes (Quartus DDM
        daemon etc.) keep the PID alive and the spinner loops forever.
        setsid gives the installer its own process group so we can kill
        the entire group when the watchdog fires.
        """
        progress_path = DOCKER_DIR / "install_progress.sh"
        self.assertTrue(progress_path.exists(), f"{progress_path} does not exist")
        content = progress_path.read_text()
        self.assertIn("setsid", content,
                       "install_progress.sh must use setsid for process group isolation")

    def test_progress_has_stale_watchdog(self):
        """install_progress.sh must detect stale progress and kill the installer.

        Regression: The spinner kept running forever when the installer
        finished but left orphan processes. The watchdog must track disk
        size changes and kill the process group after a configurable
        timeout (INSTALL_STALE_TIMEOUT).
        """
        progress_path = DOCKER_DIR / "install_progress.sh"
        content = progress_path.read_text()
        self.assertIn("INSTALL_STALE_TIMEOUT", content,
                       "install_progress.sh must have configurable INSTALL_STALE_TIMEOUT")
        self.assertIn("stale_since", content,
                       "install_progress.sh must track stale progress duration")
        # Must contain process group kill (negative PID)
        self.assertIn("-- -", content,
                       "install_progress.sh must kill the process group (kill -- -PID)")

    def test_quartus_kills_ddm_after_install(self):
        """install_quartus.sh must kill orphan DDM processes after installation.

        Regression: The Quartus 24.1+ installer spawns a DDM daemon via
        double-fork, which escapes the setsid process group kill.  The
        entrypoint must explicitly kill ddm/ddm_daemon/qddm processes.
        """
        content = self._load_script("quartus")
        # Must reference DDM cleanup
        self.assertIn("ddm", content.lower(),
                       "install_quartus.sh must clean up DDM daemon processes")
        self.assertIn("pkill", content,
                       "install_quartus.sh must use pkill to kill orphan processes")

    def test_device_inventory_uses_dynamic_quartus_discovery(self):
        """device_inventory() must use 'find' to locate the quartus directory.

        Regression: Quartus Standard installs into a versioned subdir
        (e.g., 24.1std/quartus/) but device_inventory() originally hardcoded
        the flat path. The function must dynamically locate the quartus dir
        via find to handle versioned layouts.
        """
        content = self._load_script("quartus")
        # Find the device_inventory function body
        func_match = re.search(
            r"device_inventory\(\)\s*\{(.*?)^\}", content, re.DOTALL | re.MULTILINE
        )
        self.assertIsNotNone(func_match, "Could not find device_inventory function body")
        func_body = func_match.group(1)
        # Must use find to discover the quartus directory dynamically
        self.assertIn("find", func_body,
                       "device_inventory must use 'find' to locate quartus directory dynamically")

    def test_run_installer_uses_components_subdir(self):
        """`.run` qdz injection must use components/ subdirectory.

        Regression: .run installers are self-extracting and look for .qdz
        files in components/ relative to their working dir — NOT alongside
        the .run binary. Symlinks next to the .run file are invisible to
        the extracted setup script.
        """
        content = self._load_script("quartus")
        # Find the .run handler section
        run_match = re.search(
            r'if \[\[ "\$\{TAR_FILE\}" == \*\.run \]\].*?elif \[\[', content, re.DOTALL
        )
        self.assertIsNotNone(run_match, "Could not find .run handler section")
        run_section = run_match.group(0)
        self.assertIn("components", run_section,
                       ".run qdz injection must use components/ subdirectory")
        self.assertIn("mkdir", run_section,
                       ".run handler must create components/ directory")

    def test_handover_path_uses_dynamic_quartus_bin(self):
        """The exec su handover PATH must not hardcode /opt/altera/quartus/bin.

        Regression: Quartus Standard installs quartus/bin under a versioned
        subdirectory (e.g., /opt/altera/24.1std/quartus/bin).  The handover
        must dynamically discover the path.
        """
        content = self._load_script("quartus")
        # Find the QUARTUS_BIN_DIR dynamic discovery
        self.assertIn("QUARTUS_BIN_DIR", content,
                       "install_quartus.sh must dynamically discover QUARTUS_BIN_DIR")
        # The exec su line must use the variable, not hardcoded path
        su_calls = re.findall(r'exec su .*?-c\s+"([^"]+)"', content, re.DOTALL)
        last_su = su_calls[-1] if su_calls else ""
        self.assertIn("QUARTUS_BIN_DIR", last_su,
                       "su -c PATH must use dynamic QUARTUS_BIN_DIR, not hardcoded /opt/altera/quartus/bin")

    def test_progress_uses_byte_precision(self):
        """install_progress.sh must use byte-level du for stale detection.

        Regression: du -sh rounds to human-readable units (e.g., "12G"),
        hiding sub-GB disk changes during device extraction.  The stale
        watchdog compared strings and couldn't see progress, causing
        premature kills of the installer process group.
        """
        progress_path = DOCKER_DIR / "install_progress.sh"
        content = progress_path.read_text()
        self.assertIn("du -sb", content,
                       "install_progress.sh must use 'du -sb' (byte precision) for stale detection")

    def test_stale_kill_warns_incomplete(self):
        """install_progress.sh must warn about incomplete installs on stale-kill.

        Regression: Stale-kills silently reported success, hiding the fact
        that device families were never extracted.  After a stale-kill,
        the script must check for device families and warn if none found.
        """
        progress_path = DOCKER_DIR / "install_progress.sh"
        content = progress_path.read_text()
        self.assertIn("device", content.lower(),
                       "install_progress.sh must check/warn about device families after stale-kill")
        self.assertIn("add-device", content,
                       "install_progress.sh must suggest 'rr docker add-device' as recovery")


class TestSdkRequirements(unittest.TestCase):
    """Validate sdk_requirements.yml correctness."""

    @classmethod
    def setUpClass(cls):
        try:
            import yaml
        except ImportError:
            raise unittest.SkipTest("PyYAML not installed")
        with open(REQUIREMENTS_FILE) as f:
            cls.reqs = yaml.safe_load(f)

    def test_riviera_check_cmd_uses_vsimsa(self):
        """Riviera-PRO binary is vsimsa, NOT vsim (which is Questa)."""
        riviera = self.reqs["tools"]["riviera-pro"]
        binary = riviera["check_cmd"].split()[0]
        self.assertEqual(
            binary, "vsimsa", f"riviera-pro check_cmd must use 'vsimsa' (got '{binary}'). 'vsim' is the Questa binary!"
        )

    def test_all_parse_regex_compile(self):
        """All parse_regex patterns must be valid regex."""
        for name, spec in self.reqs["tools"].items():
            pattern = spec.get("parse_regex", "")
            if pattern:
                try:
                    re.compile(pattern)
                except re.error as e:
                    self.fail(f"{name}: invalid parse_regex '{pattern}': {e}")

    def test_all_check_cmd_have_binary(self):
        """All check_cmd must specify a binary name."""
        for name, spec in self.reqs["tools"].items():
            check_cmd = spec.get("check_cmd", "")
            self.assertTrue(check_cmd.strip(), f"{name}: check_cmd is empty")
            binary = check_cmd.split()[0]
            self.assertTrue(len(binary) > 0, f"{name}: check_cmd has no binary")

    def test_riviera_install_hint_mentions_docker_shell(self):
        """Install hint should reference 'docker shell', not 'docker start'."""
        riviera = self.reqs["tools"]["riviera-pro"]
        hint = riviera.get("install_hint", "")
        self.assertIn("docker shell", hint, f"Install hint should say 'docker shell' (got: {hint})")


class TestCheckEnvDockerAugmentation(unittest.TestCase):
    """Test the _augment_path_for_docker() function."""

    def _import_augment(self):
        """Import the function under test."""
        # We need to import carefully since it runs on import
        import importlib

        spec = importlib.util.spec_from_file_location("check_env", PROJECT_MANAGER_DIR / "check_env.py")
        module = importlib.util.module_from_spec(spec)
        # Don't execute the module (it calls _augment_path_for_docker on import)
        # Instead, just read the source and extract the function
        return module

    @patch("socket.gethostname", return_value="routertl-riviera")
    def test_detects_docker_by_hostname(self, mock_hostname):
        """Should detect Docker when hostname starts with 'routertl-'."""
        from check_env import _augment_path_for_docker

        original_path = os.environ.get("PATH", "")
        try:
            _augment_path_for_docker()
            # Function ran without error — that's the main test
            # PATH might not change if /opt dirs don't exist on the host
        finally:
            os.environ["PATH"] = original_path

    @patch("socket.gethostname", return_value="my-laptop")
    def test_noop_on_non_docker(self, mock_hostname):
        """Should NOT modify PATH on non-Docker hosts."""
        from check_env import _augment_path_for_docker

        original_path = os.environ.get("PATH", "")
        _augment_path_for_docker()
        self.assertEqual(os.environ.get("PATH", ""), original_path, "PATH should not change on non-Docker hosts")


if __name__ == "__main__":
    unittest.main()
