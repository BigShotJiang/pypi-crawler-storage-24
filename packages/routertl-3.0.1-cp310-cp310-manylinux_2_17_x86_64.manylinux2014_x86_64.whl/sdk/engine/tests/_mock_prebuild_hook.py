#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Mock Pre-Build Hook for Testing

A simple generator that creates a marker file, used to test
the pre-build hook mechanism in routeRTL.

Usage:
    python mock_prebuild_hook.py --out path/to/output.vhd [--marker test]
"""

import argparse
from datetime import datetime
from pathlib import Path


def main():
    """Mock pre-build hook for testing."""
    parser = argparse.ArgumentParser(description="Mock pre-build hook for testing")
    parser.add_argument("--out", required=True, help="Output file path")
    parser.add_argument("--marker", default="test", help="Marker string to embed")
    args = parser.parse_args()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    content = f"""\
-- Mock Pre-Build Hook Output
-- Generated: {datetime.today().strftime("%Y-%m-%d %H:%M:%S")}
-- Marker: {args.marker}
-- DO NOT EDIT - Generated for testing purposes

library ieee;
use ieee.std_logic_1164.all;

package mock_generated_pkg is
    constant C_MARKER : string := "{args.marker}";
end package mock_generated_pkg;
"""

    out_path.write_text(content, encoding="utf-8")
    print(f"✅ Mock hook generated {out_path}")


if __name__ == "__main__":
    main()
