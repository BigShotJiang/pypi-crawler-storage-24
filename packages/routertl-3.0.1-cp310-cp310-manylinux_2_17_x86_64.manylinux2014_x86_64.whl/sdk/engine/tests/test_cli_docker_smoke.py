# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Docker CLI Smoke Test — end-to-end validation of pip install + CLI entry points.

Builds a lightweight Docker image (python:3.10-slim + git + make) and runs
the full "new user" flow inside a clean container:

  1. git submodule add (SDK)
  2. init_project.py
  3. python3 -m venv + pip install -e
  4. Verify every CLI command resolves and runs without tracebacks
  5. Verify workspace rebrand creates shortcuts
  6. Verify Makefile integration

Skipped automatically when Docker is not available.
"""

import os
import subprocess
import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
IMAGE_NAME = "routertl-cli-test:latest"
DOCKERFILE = REPO_ROOT / "sdk" / "infra" / "docker" / "Dockerfile.cli-test"


def _docker_available():
    """Check if Docker daemon is reachable."""
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


@unittest.skipUnless(_docker_available(), "Docker not available")
@unittest.skipIf(
    os.environ.get("GIT_DIR"),
    "Cannot run Docker smoke test inside pre-commit hook (GIT_DIR is set)",
)
class TestCLIDockerSmoke(unittest.TestCase):
    """Build the CLI smoke-test image and run the full validation suite."""

    @classmethod
    def setUpClass(cls):
        """Build the Docker image once for all tests in this class."""
        print(f"\n🐳 Building CLI smoke-test image from {DOCKERFILE}...")
        result = subprocess.run(
            [
                "docker",
                "build",
                "-f",
                str(DOCKERFILE),
                "-t",
                IMAGE_NAME,
                str(REPO_ROOT),
            ],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            print(f"STDOUT:\n{result.stdout}")
            print(f"STDERR:\n{result.stderr}")
            raise RuntimeError(f"Failed to build Docker image (exit {result.returncode})")
        print(f"✅ Image built: {IMAGE_NAME}")

    def test_smoke(self):
        """Run cli_smoke_test.sh inside the container."""
        result = subprocess.run(
            [
                "docker",
                "run",
                "--rm",
                "-v",
                f"{REPO_ROOT}:/sdk:ro",
                IMAGE_NAME,
            ],
            capture_output=True,
            text=True,
            timeout=180,
        )

        # Always print the output for CI visibility
        print(result.stdout)
        if result.stderr:
            print(result.stderr, file=sys.stderr)

        self.assertEqual(
            result.returncode,
            0,
            f"CLI smoke test failed (exit {result.returncode}).\nOutput:\n{result.stdout}\n{result.stderr}",
        )

        # Verify we actually ran checks (sanity)
        self.assertIn("PASSED:", result.stdout)
        self.assertIn("FAILED: 0", result.stdout)


if __name__ == "__main__":
    unittest.main()
