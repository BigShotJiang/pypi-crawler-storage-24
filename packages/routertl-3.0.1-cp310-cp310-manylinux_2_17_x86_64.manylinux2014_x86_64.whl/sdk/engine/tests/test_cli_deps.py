# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for dependency, source listing, entity info, FPGA device, and
help renderer CLI commands.

Split from test_cli.py as part of P2.66.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli


class TestDepsCommand(unittest.TestCase):
    """Tests for the deps command and its graph output formats."""

    def setUp(self):
        self.runner = CliRunner()

    def test_deps_help(self):
        """Deps command should display help cleanly."""
        result = self.runner.invoke(cli, ["deps", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("--graph", result.output)
        self.assertIn("mermaid", result.output)

    def test_deps_graph_json_with_sources(self):
        """Deps --graph json should produce valid JSON for a minimal source tree."""
        import json

        with self.runner.isolated_filesystem():
            import os

            import yaml

            os.makedirs("src", exist_ok=True)
            with open("src/my_mod.vhd", "w") as f:
                f.write("entity my_mod is\nend entity my_mod;\n")
            config = {"paths": {"sources": "src"}}
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["deps", "--graph", "json"])
            self.assertEqual(result.exit_code, 0)
            # Extract JSON portion (skip any logging preamble)
            json_start = result.output.index("{")
            decoder = json.JSONDecoder()
            data, _ = decoder.raw_decode(result.output[json_start:])
            self.assertIn("nodes", data)
            self.assertIn("roots", data)

    def test_deps_graph_mermaid_with_sources(self):
        """Deps --graph mermaid should produce a graph TD block."""
        with self.runner.isolated_filesystem():
            import os

            import yaml

            os.makedirs("src", exist_ok=True)
            with open("src/my_mod.vhd", "w") as f:
                f.write("entity my_mod is\nend entity my_mod;\n")
            config = {"paths": {"sources": "src"}}
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["deps", "--graph", "mermaid"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("graph TD", result.output)

    def test_export_graph_method(self):
        """DependencyResolver.export_graph should produce all three formats."""
        import json
        import sys
        from pathlib import Path

        sys.path.insert(0, str(Path(__file__).parent.parent))
        from dependency_resolver import DependencyResolver

        with self.runner.isolated_filesystem():
            import os

            os.makedirs("src", exist_ok=True)
            with open("src/top.vhd", "w") as f:
                f.write("entity top is\nend entity top;\n")
            with open("src/sub.vhd", "w") as f:
                f.write("entity sub is\nend entity sub;\n")

            resolver = DependencyResolver([Path("src")], verbose=False)

            # Mermaid
            mmd = resolver.export_graph("mermaid")
            self.assertIn("graph TD", mmd)

            # JSON
            js = resolver.export_graph("json")
            data = json.loads(js)
            self.assertIn("nodes", data)

            # HTML
            html = resolver.export_graph("html")
            self.assertIn("<!DOCTYPE html>", html)
            self.assertIn("mermaid", html)


class TestDepsOrphans(unittest.TestCase):
    """Tests for deps command with orphan files (Fore.DIM regression)."""

    def setUp(self):
        self.runner = CliRunner()

    def test_deps_forest_with_orphans(self):
        """Deps forest summary should handle orphan files without crashing."""
        with self.runner.isolated_filesystem():
            import os

            import yaml

            os.makedirs("src", exist_ok=True)
            # Create a top-level entity
            with open("src/top.vhd", "w") as f:
                f.write("entity top is\nend entity top;\narchitecture rtl of top is\nbegin\nend architecture;\n")
            # Create an orphan (no entity references it)
            with open("src/orphan_pkg.vhd", "w") as f:
                f.write("package orphan_pkg is\nend package orphan_pkg;\n")
            config = {"paths": {"sources": "src"}}
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["deps"])
            self.assertEqual(result.exit_code, 0)
            # Should display forest without AttributeError
            self.assertIn("Dependency Forest", result.output)


class TestSources(unittest.TestCase):
    """Tests for the routertl sources command."""

    def setUp(self):
        self.runner = CliRunner()

    def _make_project_yml(self):
        import yaml

        config = {
            "sources": {
                "syn": ["src/top.vhd", "src/sub.vhd", "src/lib/pkg.vhd"],
                "sim": ["sim/test_top.py"],
                "xdc": ["constraints/timing.xdc"],
                "ip": [],
            }
        }
        with open("project.yml", "w") as f:
            yaml.dump(config, f)

    def test_sources_all(self):
        """Sources without flags should list all categories."""
        with self.runner.isolated_filesystem():
            self._make_project_yml()
            result = self.runner.invoke(cli, ["sources"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("Project Sources", result.output)
            self.assertIn("top.vhd", result.output)
            self.assertIn("test_top.py", result.output)
            self.assertIn("timing.xdc", result.output)

    def test_sources_syn_filter(self):
        """--syn should show only synthesis files."""
        with self.runner.isolated_filesystem():
            self._make_project_yml()
            result = self.runner.invoke(cli, ["sources", "--syn"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("top.vhd", result.output)
            self.assertNotIn("test_top.py", result.output)

    def test_sources_count(self):
        """--count should show file counts only."""
        with self.runner.isolated_filesystem():
            self._make_project_yml()
            result = self.runner.invoke(cli, ["sources", "--count"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("3 files", result.output)  # 3 syn files
            self.assertIn("Total:", result.output)

    def test_sources_no_project_yml(self):
        """Sources without project.yml should error cleanly."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["sources"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("No project.yml", result.output)


class TestInfo(unittest.TestCase):
    """Tests for the routertl info command."""

    def setUp(self):
        self.runner = CliRunner()

    def test_info_entity_found(self):
        """Info should display entity details when found."""
        with self.runner.isolated_filesystem():
            import os

            import yaml

            os.makedirs("src", exist_ok=True)
            with open("src/top.vhd", "w") as f:
                f.write(
                    "entity top is\nport(\n  CLK : in std_logic;\n  DOUT : out std_logic\n);\nend entity top;\narchitecture rtl of top is\nbegin\nend architecture;\n"
                )
            config = {"paths": {"sources": "src"}}
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["info", "top"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("Entity:", result.output)
            self.assertIn("top", result.output)

    def test_info_entity_not_found(self):
        """Info for nonexistent entity should error cleanly."""
        with self.runner.isolated_filesystem():
            import os

            import yaml

            os.makedirs("src", exist_ok=True)
            with open("src/top.vhd", "w") as f:
                f.write("entity top is\nend entity top;\narchitecture rtl of top is\nbegin\nend architecture;\n")
            config = {"paths": {"sources": "src"}}
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["info", "nonexistent"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("not found", result.output)


class TestFpgaDevices(unittest.TestCase):
    """Tests for the routertl fpga devices command."""

    def setUp(self):
        self.runner = CliRunner()

    # ── Unit tests for _validate_regex ──

    def test_validate_regex_valid(self):
        """Valid regex patterns should compile without error."""
        from sdk.cli.commands.fpga import _validate_regex

        compiled, err = _validate_regex("xc7z020")
        self.assertIsNotNone(compiled)
        self.assertIsNone(err)

    def test_validate_regex_case_insensitive(self):
        """Regex should be case-insensitive by default."""
        from sdk.cli.commands.fpga import _validate_regex

        compiled, _ = _validate_regex("XC7Z")
        self.assertIsNotNone(compiled)
        self.assertTrue(compiled.search("xc7z020clg400-1"))

    def test_validate_regex_malformed(self):
        """Malformed regex should return error, not crash."""
        from sdk.cli.commands.fpga import _validate_regex

        compiled, err = _validate_regex("[invalid")
        self.assertIsNone(compiled)
        self.assertIn("Invalid regex", err)

    def test_validate_regex_catastrophic(self):
        """Catastrophic backtracking patterns should still compile (re handles this)."""
        from sdk.cli.commands.fpga import _validate_regex

        # Deeply nested groups — valid regex, just pathological
        compiled, err = _validate_regex("(a+)+b")
        self.assertIsNotNone(compiled)
        self.assertIsNone(err)

    def test_validate_regex_unbalanced_parens(self):
        """Unbalanced parentheses should return a clear error."""
        from sdk.cli.commands.fpga import _validate_regex

        compiled, err = _validate_regex("(((((")
        self.assertIsNone(compiled)
        self.assertIn("Invalid regex", err)

    def test_validate_regex_empty_string(self):
        """Empty string is a valid regex (matches everything)."""
        from sdk.cli.commands.fpga import _validate_regex

        compiled, err = _validate_regex("")
        self.assertIsNotNone(compiled)
        self.assertIsNone(err)

    # ── CLI integration tests ──

    @patch("sdk.cli.commands.fpga._query_vendor_devices")
    @patch("sdk.cli.commands.fpga._load_project_config")
    def test_devices_family_listing(self, mock_config, mock_query):
        """fpga devices should list families from mock vendor output."""
        mock_config.return_value = ("xilinx", "xc7z020clg400-1")
        mock_query.return_value = (
            ["Artix-7", "Kintex-7", "Zynq"],
            {
                "Artix-7": ["xc7a35t", "xc7a100t"],
                "Kintex-7": ["xc7k325t"],
                "Zynq": ["xc7z020clg400-1", "xc7z045ffg900-2"],
            },
            None,
        )

        result = self.runner.invoke(cli, ["fpga", "devices"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Artix-7", result.output)
        self.assertIn("Kintex-7", result.output)
        self.assertIn("Zynq", result.output)
        # Current target should be highlighted
        self.assertIn("project target", result.output)
        self.assertIn("xc7z020clg400-1", result.output)

    @patch("sdk.cli.commands.fpga._query_vendor_devices")
    @patch("sdk.cli.commands.fpga._load_project_config")
    def test_devices_family_filter(self, mock_config, mock_query):
        """--family should list only parts in that family."""
        mock_config.return_value = ("xilinx", "xc7z020clg400-1")
        mock_query.return_value = (
            ["Artix-7", "Zynq"],
            {
                "Artix-7": ["xc7a35t", "xc7a100t"],
                "Zynq": ["xc7z020clg400-1", "xc7z045ffg900-2"],
            },
            None,
        )

        result = self.runner.invoke(cli, ["fpga", "devices", "--family", "Zynq"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("xc7z020clg400-1", result.output)
        self.assertIn("xc7z045ffg900-2", result.output)
        # Should NOT show Artix parts
        self.assertNotIn("xc7a35t", result.output)

    @patch("sdk.cli.commands.fpga._query_vendor_devices")
    @patch("sdk.cli.commands.fpga._load_project_config")
    def test_devices_regexp_filter(self, mock_config, mock_query):
        """--regexp should filter parts by regex pattern."""
        mock_config.return_value = ("altera", "10AX115S2F45I1SG")
        mock_query.return_value = (
            ["Arria 10", "Cyclone V"],
            {
                "Arria 10": ["10AX115S2F45I1SG", "10AX115N2F45E2SG"],
                "Cyclone V": ["5CGXFC7C7F23C8", "5CEBA4F23C7"],
            },
            None,
        )

        result = self.runner.invoke(cli, ["fpga", "devices", "--regexp", "10AX"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("10AX115S2F45I1SG", result.output)
        self.assertIn("10AX115N2F45E2SG", result.output)
        # Cyclone parts should NOT appear
        self.assertNotIn("5CGXFC7C7F23C8", result.output)

    def test_devices_invalid_regexp(self):
        """Invalid regex should fail early with a clear message."""
        with self.runner.isolated_filesystem():
            import yaml

            config = {"hardware": {"vendor": "xilinx", "part": "xc7z020"}}
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["fpga", "devices", "--regexp", "[invalid"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("Invalid regex", result.output)

    @patch("sdk.cli.commands.fpga._query_vendor_devices")
    @patch("sdk.cli.commands.fpga._load_project_config")
    def test_devices_vendor_tool_error(self, mock_config, mock_query):
        """Vendor tool failure should show the error message."""
        mock_config.return_value = ("xilinx", "xc7z020")
        mock_query.return_value = ([], {}, "Vendor tool 'vivado' not found on PATH.")

        result = self.runner.invoke(cli, ["fpga", "devices"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("not found on PATH", result.output)

    def test_devices_no_project_yml(self):
        """fpga devices without project.yml should error."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["fpga", "devices"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("No project.yml", result.output)


class TestHelpRenderer(unittest.TestCase):
    """Tests for the help markdown renderer."""

    def setUp(self):
        self.runner = CliRunner()

    def test_help_renders_fenced_code_blocks(self):
        """Fenced code blocks should be rendered, not shown as raw markdown."""
        result = self.runner.invoke(cli, ["help", "sim"])
        self.assertEqual(result.exit_code, 0)
        # Raw fence markers should NOT appear in rendered output
        self.assertNotIn("```", result.output)
        # The actual content should still be present
        self.assertIn("routertl sim", result.output)

    def test_help_renders_inline_code(self):
        """Inline backtick code should render without raw backticks."""
        result = self.runner.invoke(cli, ["help", "sim"])
        self.assertEqual(result.exit_code, 0)
        # No raw backticks should remain
        self.assertNotIn("`", result.output)

    def test_help_unknown_command(self):
        """Help for unknown command should exit with error."""
        result = self.runner.invoke(cli, ["help", "nonexistent_command_xyz"])
        self.assertNotEqual(result.exit_code, 0)


if __name__ == "__main__":
    unittest.main()
