# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Regression tests for simulation engine auto-detection logic.

Tests the simulator selection precedence:
  $SIM env var → project.yml → language-based default → 'nvc'

Bug that prompted this test:
  simulation.py hardcoded 'verilator' for Verilog/SV sources, ignoring
  $SIM=riviera set by Docker containers. This caused simulations inside
  the Riviera Docker to silently use Verilator.
"""

import os
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch


class TestSimulatorAutoDetect(unittest.TestCase):
    """Test run_simulation() simulator selection logic."""

    def _get_simulator(self, *, env_sim=None, has_verilog=False, has_vhdl=False, explicit=None, yml_simulator=None):
        """
        Reproduce the auto-detection logic from simulation.py without
        actually running a simulation. This mirrors the precedence chain.
        """
        from sim.cocotb.engine.simulation import run_simulation

        # Build minimal source lists to trigger language detection
        hdl_sources = []
        if has_verilog:
            hdl_sources.append("dummy.sv")
        if has_vhdl:
            hdl_sources.append("dummy.vhd")

        env = os.environ.copy()
        if env_sim:
            env["SIM"] = env_sim
        else:
            env.pop("SIM", None)

        # Build a fake project.yml content
        yml_content = {}
        if yml_simulator:
            yml_content = {"simulation": {"simulator": yml_simulator}}

        with (
            patch.dict(os.environ, env, clear=False),
            patch("routertl_core.sim.simulation.get_backend") as mock_backend,
            patch("routertl_core.sim.simulation.LibraryCompiler"),
            patch("routertl_core.sim.simulation.get_build_dir_for_simulator", return_value="/tmp/test_build"),
            patch("routertl_core.sim.simulation.ensure_dir"),
            patch("builtins.open", create=True) as mock_open,
            patch("routertl_core.sim.simulation.PROJECT_ROOT", Path("/fake/project")),
        ):
            # Mock yaml.safe_load to return our fake project.yml
            import yaml as _yaml

            original_safe_load = _yaml.safe_load

            def fake_safe_load(f):
                # If reading our fake project.yml, return mock content
                return yml_content

            mock_be = MagicMock()
            mock_backend.return_value = mock_be

            # Patch Path.exists for project.yml
            original_exists = Path.exists

            def fake_exists(self_path):
                if str(self_path).endswith("project.yml"):
                    return bool(yml_content)
                return original_exists(self_path)

            with patch.object(Path, "exists", fake_exists), patch("yaml.safe_load", side_effect=fake_safe_load):
                try:
                    run_simulation(
                        top_level="dummy_top",
                        module="test_dummy",
                        hdl_sources=hdl_sources if hdl_sources else None,
                        simulator=explicit,
                    )
                except Exception:
                    pass

            if mock_backend.called:
                return mock_backend.call_args[0][0]
            return None

    # ── $SIM env var always wins (highest priority) ──

    def test_env_sim_overrides_verilog_default(self):
        """$SIM=riviera must override the Verilog→verilator default."""
        sim = self._get_simulator(env_sim="riviera", has_verilog=True)
        self.assertEqual(sim, "riviera")

    def test_env_sim_overrides_vhdl_default(self):
        """$SIM=ghdl must override the VHDL→nvc default."""
        sim = self._get_simulator(env_sim="ghdl", has_vhdl=True)
        self.assertEqual(sim, "ghdl")

    def test_env_sim_overrides_project_yml(self):
        """$SIM env var must override project.yml simulator."""
        sim = self._get_simulator(env_sim="riviera", yml_simulator="verilator", has_verilog=True)
        self.assertEqual(sim, "riviera")

    def test_env_sim_used_when_no_sources(self):
        """$SIM should be used even when no sources are detected."""
        sim = self._get_simulator(env_sim="questa")
        self.assertEqual(sim, "questa")

    # ── project.yml is second priority ──

    def test_project_yml_used_when_no_env_sim(self):
        """project.yml simulator should be used when $SIM is not set."""
        sim = self._get_simulator(yml_simulator="riviera", has_verilog=True)
        self.assertEqual(sim, "riviera")

    def test_project_yml_overrides_language_default(self):
        """project.yml 'nvc' should override language-based 'verilator' default."""
        sim = self._get_simulator(yml_simulator="nvc", has_verilog=True)
        self.assertEqual(sim, "nvc")

    # ── Language-based defaults (lowest priority) ──

    def test_verilog_defaults_to_verilator(self):
        """Without $SIM or project.yml, Verilog sources default to verilator."""
        sim = self._get_simulator(has_verilog=True)
        self.assertEqual(sim, "verilator")

    def test_vhdl_defaults_to_nvc(self):
        """Without $SIM or project.yml, VHDL sources default to nvc."""
        sim = self._get_simulator(has_vhdl=True)
        self.assertEqual(sim, "nvc")

    # ── Explicit simulator= kwarg always wins ──

    def test_explicit_simulator_wins_over_env(self):
        """simulator= kwarg should bypass all auto-detection."""
        sim = self._get_simulator(env_sim="riviera", has_verilog=True, explicit="nvc")
        self.assertEqual(sim, "nvc")

    # ── Docker scenario ──

    def test_docker_riviera_with_systemverilog(self):
        """Exact Docker scenario: SIM=riviera must be used for SV sources."""
        sim = self._get_simulator(env_sim="riviera", has_verilog=True)
        self.assertEqual(sim, "riviera", "Docker Riviera container should use riviera, not verilator")


class TestMixedLanguageValidation(unittest.TestCase):
    """Test mixed VHDL+Verilog source handling."""

    def _run_with_mixed(self, simulator, env_sim=None):
        """Attempt to run with both VHDL and Verilog sources."""
        from sim.cocotb.engine.simulation import run_simulation

        env = os.environ.copy()
        if env_sim:
            env["SIM"] = env_sim
        else:
            env.pop("SIM", None)

        with (
            patch.dict(os.environ, env, clear=False),
            patch("routertl_core.sim.simulation.get_backend") as mock_backend,
            patch("routertl_core.sim.simulation.LibraryCompiler"),
            patch("routertl_core.sim.simulation.get_build_dir_for_simulator", return_value="/tmp/test_build"),
            patch("routertl_core.sim.simulation.ensure_dir"),
            patch("routertl_core.sim.simulation.PROJECT_ROOT", Path("/fake")),
        ):
            mock_be = MagicMock()
            mock_backend.return_value = mock_be

            run_simulation(
                top_level="dummy_top",
                module="test_dummy",
                hdl_sources=["a.vhd", "b.sv"],
                simulator=simulator,
            )

    def test_mixed_allowed_for_riviera(self):
        """Riviera should accept mixed VHDL+SV sources."""
        try:
            self._run_with_mixed("riviera")
        except ValueError as e:
            if "Mixed" in str(e):
                self.fail("Riviera should support mixed-language, but got ValueError")

    def test_mixed_allowed_for_questa(self):
        """Questa should accept mixed VHDL+SV sources."""
        try:
            self._run_with_mixed("questa")
        except ValueError as e:
            if "Mixed" in str(e):
                self.fail("Questa should support mixed-language, but got ValueError")

    def test_mixed_rejected_for_nvc(self):
        """NVC should reject mixed sources with clear error."""
        with self.assertRaises(ValueError) as ctx:
            self._run_with_mixed("nvc")
        self.assertIn("mixed-language", str(ctx.exception).lower())

    def test_mixed_rejected_for_verilator(self):
        """Verilator should reject mixed sources (no VHDL support)."""
        with self.assertRaises(ValueError) as ctx:
            self._run_with_mixed("verilator")
        self.assertIn("mixed", str(ctx.exception).lower())

    def test_mixed_rejected_for_ghdl(self):
        """GHDL should reject mixed sources (no Verilog support)."""
        with self.assertRaises(ValueError) as ctx:
            self._run_with_mixed("ghdl")
        self.assertIn("mixed", str(ctx.exception).lower())


if __name__ == "__main__":
    unittest.main()
