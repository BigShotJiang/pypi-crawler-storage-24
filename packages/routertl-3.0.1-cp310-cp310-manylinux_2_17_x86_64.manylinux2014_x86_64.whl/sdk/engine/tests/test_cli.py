# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Cross-cutting CLI smoke tests that don't belong to a single command area.

The bulk of the CLI tests have been split into per-command modules:
  test_cli_hardware.py   — synth, hierarchy, schematic, bitstream, impl, aliases
  test_cli_sim.py        — sim, view-log, watch, summary aggregation
  test_cli_doctor.py     — doctor checks, fix suggestions, LFS, license
  test_cli_workspace.py  — workspace, rebrand, init_project, update-sdk, pyproject
  test_cli_docker.py     — docker uninstall, setup, bind mounts, env cleanup
  test_cli_deps.py       — deps, sources, info, fpga devices, help renderer

This file retains only universal / uncategorized tests.
P2.66 — Split test_cli.py into per-command test modules.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli


class TestRouteRTLCLI(unittest.TestCase):
    """Universal CLI smoke tests."""

    def setUp(self):
        self.runner = CliRunner()

    def test_all_commands_accept_help(self):
        """Smoke test: every registered CLI command should accept --help."""
        for name, cmd in cli.commands.items():
            result = self.runner.invoke(cli, [name, "--help"])
            self.assertEqual(
                result.exit_code,
                0,
                f"Command '{name}' failed --help with exit code {result.exit_code}: {result.output}",
            )

    @patch("subprocess.run")
    def test_linux_commands(self, mock_run):
        mock_run.return_value.returncode = 0

        result = self.runner.invoke(cli, ["linux", "kernel"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "build-kernel"], check=False)

        result = self.runner.invoke(cli, ["linux", "crosscheck"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "crosscheck-hw"], check=False)

    @patch("subprocess.run")
    def test_ip_commands(self, mock_run):
        mock_run.return_value.returncode = 0

        result = self.runner.invoke(cli, ["regbank", "parse"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "parse_regbank"], check=False)

        result = self.runner.invoke(cli, ["rom"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "rom_info"], check=False)

    def test_status_without_project_yml(self):
        """Status command should exit cleanly when no project.yml exists."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["status"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("No project.yml", result.output)

    def test_status_with_project_yml(self):
        """Status command should display project info when project.yml exists."""
        with self.runner.isolated_filesystem():
            import yaml

            config = {
                "project": {"name": "test_proj", "top_module": "my_top"},
                "hardware": {"vendor": "xilinx", "part": "xc7z020clg400-1", "language": "vhdl"},
                "simulation": {"test_dir": "sim/cocotb/tests", "simulator": "nvc"},
                "sources": {"syn": ["src/a.vhd", "src/b.vhd"], "sim": [], "xdc": ["xdc/t.xdc"]},
                "features": {"regbank": True},
            }
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["status"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("test_proj", result.output)
            self.assertIn("xc7z020clg400-1", result.output)

    def test_status_with_yaml_null_values(self):
        """Regression: status must not crash when project.yml has YAML null values.

        When a field like 'tests:' or 'syn:' is present with no value,
        YAML parses it as None.  dict.get('tests', []) returns None
        (key exists), so len(None) would crash with TypeError.
        """
        with self.runner.isolated_filesystem():
            # Write project.yml with explicit null values (bare keys)
            with open("project.yml", "w") as f:
                f.write(
                    "project:\n"
                    "  name: null_test\n"
                    "  top_module: top\n"
                    "hardware:\n"
                    "  vendor: xilinx\n"
                    "  part: xc7z020clg400-1\n"
                    "  language: vhdl\n"
                    "simulation:\n"
                    "  test_dir: sim/cocotb/tests\n"
                    "sources:\n"
                    "  syn:\n"  # YAML null
                    "  sim:\n"  # YAML null
                    "  xdc:\n"  # YAML null
                    "hooks:\n"
                    "  pre_commit:\n"
                    "    enabled: true\n"
                    "    lint: true\n"
                    "    tests:\n"  # YAML null
                )

            result = self.runner.invoke(cli, ["status"])
            self.assertEqual(result.exit_code, 0, f"Crashed: {result.output}")
            self.assertIn("null_test", result.output)


class TestCompletion(unittest.TestCase):
    """Tests for the routertl completion command."""

    def setUp(self):
        self.runner = CliRunner()

    def test_completion_bash(self):
        """completion bash should produce a valid bash completion script."""
        result = self.runner.invoke(cli, ["completion", "bash"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("_completion()", result.output)
        self.assertIn("COMPREPLY", result.output)
        self.assertIn("complete -o default", result.output)

    def test_completion_zsh(self):
        """completion zsh should produce a valid zsh completion script."""
        result = self.runner.invoke(cli, ["completion", "zsh"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("compdef", result.output)

    def test_completion_fish(self):
        """completion fish should produce a valid fish completion script."""
        result = self.runner.invoke(cli, ["completion", "fish"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("complete", result.output)

    def test_completion_invalid_shell(self):
        """completion with invalid shell should error."""
        result = self.runner.invoke(cli, ["completion", "powershell"])
        self.assertNotEqual(result.exit_code, 0)


if __name__ == "__main__":
    unittest.main()
