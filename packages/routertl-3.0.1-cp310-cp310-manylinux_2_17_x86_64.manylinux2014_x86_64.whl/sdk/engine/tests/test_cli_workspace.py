# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for workspace-related CLI commands: workspace, rebrand,
init_project (shortcuts, branding, wrapper), update-sdk, and pyproject.toml.

Split from test_cli.py as part of P2.66.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli


class TestWorkspaceCommands(unittest.TestCase):
    """Tests for basic workspace commands."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("subprocess.run")
    def test_workspace_commands(self, mock_run):
        mock_run.return_value.returncode = 0

        result = self.runner.invoke(cli, ["workspace", "clean"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "clean"], check=False)

        result = self.runner.invoke(cli, ["workspace", "update", "--src"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "update-src"], check=False)


class TestDeepClean(unittest.TestCase):
    """Tests for rr ws clean --deep (P2.69)."""

    def setUp(self):
        self.runner = CliRunner()

    def test_deep_removes_pycache(self):
        """--deep should remove __pycache__/ directories."""
        with self.runner.isolated_filesystem():
            # Create nested __pycache__ directories
            Path("pkg/__pycache__").mkdir(parents=True)
            Path("pkg/__pycache__/mod.cpython-310.pyc").write_bytes(b"x" * 100)
            Path("pkg/sub/__pycache__").mkdir(parents=True)
            Path("pkg/sub/__pycache__/sub.cpython-310.pyc").write_bytes(b"x" * 50)

            result = self.runner.invoke(cli, ["workspace", "clean", "--deep"])
            self.assertEqual(result.exit_code, 0)
            self.assertFalse(Path("pkg/__pycache__").exists())
            self.assertFalse(Path("pkg/sub/__pycache__").exists())
            self.assertIn("items", result.output)

    def test_deep_removes_vivado_journals(self):
        """--deep should remove vivado*.log and vivado*.jou at root."""
        with self.runner.isolated_filesystem():
            Path("vivado_2024.1.log").write_text("log data")
            Path("vivado_2024.1.jou").write_text("journal data")
            Path("vivado_pid12345.str").write_text("pid")

            result = self.runner.invoke(cli, ["workspace", "clean", "--deep"])
            self.assertEqual(result.exit_code, 0)
            self.assertFalse(Path("vivado_2024.1.log").exists())
            self.assertFalse(Path("vivado_2024.1.jou").exists())
            self.assertFalse(Path("vivado_pid12345.str").exists())

    def test_deep_removes_cython_artifacts(self):
        """--deep should remove *.c and *.so from routertl_core/."""
        with self.runner.isolated_filesystem():
            Path("routertl_core").mkdir()
            Path("routertl_core/resolver.c").write_text("/* cython */")
            Path("routertl_core/resolver.cpython-310-x86_64-linux-gnu.so").write_bytes(b"\x7fELF")

            result = self.runner.invoke(cli, ["workspace", "clean", "--deep"])
            self.assertEqual(result.exit_code, 0)
            self.assertFalse(Path("routertl_core/resolver.c").exists())
            # .so removed
            self.assertEqual(list(Path("routertl_core").glob("*.so")), [])

    def test_deep_nothing_to_clean(self):
        """--deep on a clean workspace should say 'nothing to clean'."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["workspace", "clean", "--deep"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("tidy", result.output)


class TestWorkspaceCommandsExtra(unittest.TestCase):
    """Extra workspace tests (symlinks, wrappers, branding)."""

    def setUp(self):
        self.runner = CliRunner()

    def test_rr_shortcut_created_independently(self):
        """Regression: rr symlink must be created even without branding.

        Bug: _create_shortcut_alias was inside _create_branded_symlink
        after an early return, so it never executed for projects without
        custom branding.cli_name.
        """
        import sys
        import tempfile
        from pathlib import Path

        sys.path.insert(0, str(Path(__file__).parent.parent))
        from init_project import _create_branded_symlink, _create_shortcut_alias

        with tempfile.TemporaryDirectory() as tmp:
            venv = Path(tmp)
            bin_dir = venv / "bin"
            bin_dir.mkdir()
            # Create a fake routertl binary
            (bin_dir / "routertl").write_text("#!/bin/sh\necho ok")
            (bin_dir / "routertl").chmod(0o755)

            # branded symlink should return early (no project.yml)
            _create_branded_symlink(venv)
            # rr must still be created independently
            _create_shortcut_alias(venv)

            rr_link = bin_dir / "rr"
            self.assertTrue(rr_link.exists(), "rr symlink was not created")
            self.assertTrue(rr_link.is_symlink(), "rr should be a symlink")
            self.assertEqual(rr_link.resolve().name, "routertl")

    def test_branded_symlink_still_works(self):
        """Verify branded symlink creation still works after refactor."""
        import sys
        import tempfile
        from pathlib import Path

        sys.path.insert(0, str(Path(__file__).parent.parent))
        from init_project import _create_branded_symlink

        with tempfile.TemporaryDirectory() as tmp:
            venv = Path(tmp)
            bin_dir = venv / "bin"
            bin_dir.mkdir()
            (bin_dir / "routertl").write_text("#!/bin/sh\necho ok")
            (bin_dir / "routertl").chmod(0o755)

            # Create a project.yml with custom branding
            import yaml

            yml = Path(tmp) / "project.yml"
            yml.write_text(yaml.dump({"branding": {"cli_name": "myrtl"}}))

            # Need to cd to the temp dir for the function to find project.yml
            import os

            old_cwd = os.getcwd()
            try:
                os.chdir(tmp)
                _create_branded_symlink(venv)
            finally:
                os.chdir(old_cwd)

            branded = bin_dir / "myrtl"
            self.assertTrue(branded.exists(), "branded symlink was not created")
            self.assertTrue(branded.is_symlink())

    def test_resilient_wrapper_contains_rr_bootstrap(self):
        """The generated wrapper script must include rr auto-creation."""
        import sys
        import tempfile
        from pathlib import Path

        sys.path.insert(0, str(Path(__file__).parent.parent))
        from init_project import _install_resilient_wrapper

        with tempfile.TemporaryDirectory() as tmp:
            venv = Path(tmp)
            bin_dir = venv / "bin"
            bin_dir.mkdir()
            # Create python3 stub
            (bin_dir / "python3").write_text("#!/bin/sh")
            (bin_dir / "python3").chmod(0o755)

            _install_resilient_wrapper(venv)

            wrapper_content = (bin_dir / "routertl").read_text()
            self.assertIn("rr", wrapper_content, "Wrapper must contain rr symlink bootstrap code")


class TestWorkspaceRebrand(unittest.TestCase):
    """Tests for the routertl workspace rebrand command."""

    def setUp(self):
        self.runner = CliRunner()

    def test_rebrand_no_binary_anywhere(self):
        """Should fail cleanly when no routertl binary is found anywhere."""
        with patch.dict("os.environ", {}, clear=True), patch("shutil.which", return_value=None):
            result = self.runner.invoke(cli, ["workspace", "rebrand"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("No routertl binary found", result.output)

    def test_rebrand_creates_rr(self):
        """Should create the rr symlink."""
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as tmp:
            bin_dir = Path(tmp) / "bin"
            bin_dir.mkdir()
            (bin_dir / "routertl").write_text("#!/bin/sh\necho ok")
            (bin_dir / "routertl").chmod(0o755)

            with patch.dict("os.environ", {"VIRTUAL_ENV": tmp}):
                result = self.runner.invoke(cli, ["workspace", "rebrand"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("rr", result.output)
            self.assertTrue((bin_dir / "rr").is_symlink())

    def test_rebrand_creates_branded_alias(self):
        """Should create a branded alias from project.yml."""
        import tempfile
        from pathlib import Path

        import yaml

        with tempfile.TemporaryDirectory() as tmp:
            bin_dir = Path(tmp) / "bin"
            bin_dir.mkdir()
            (bin_dir / "routertl").write_text("#!/bin/sh\necho ok")
            (bin_dir / "routertl").chmod(0o755)

            with self.runner.isolated_filesystem():
                with open("project.yml", "w") as f:
                    yaml.dump({"branding": {"cli_name": "dskopsdk"}}, f)
                with patch.dict("os.environ", {"VIRTUAL_ENV": tmp}):
                    result = self.runner.invoke(cli, ["workspace", "rebrand"])

            self.assertEqual(result.exit_code, 0)
            self.assertIn("dskopsdk", result.output)
            self.assertTrue((bin_dir / "dskopsdk").is_symlink())
            self.assertTrue((bin_dir / "rr").is_symlink())

    def test_rebrand_help_shows_project_yml_example(self):
        """Help text should explain that branding comes from project.yml."""
        result = self.runner.invoke(cli, ["workspace", "rebrand", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("project.yml", result.output)
        self.assertIn("cli_name", result.output)
        self.assertIn("no arguments needed", result.output.lower())

    def test_rebrand_no_binary_shows_install_hint(self):
        """When no binary found anywhere, should suggest how to install."""
        with patch.dict("os.environ", {}, clear=True), patch("shutil.which", return_value=None):
            result = self.runner.invoke(cli, ["workspace", "rebrand"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("Activate .venv or install routertl", result.output)

    def test_rebrand_system_fallback(self):
        """Should fall back to shutil.which when no venv is active (Docker)."""
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as tmp:
            bin_dir = Path(tmp)
            (bin_dir / "routertl").write_text("#!/bin/sh\necho ok")
            (bin_dir / "routertl").chmod(0o755)

            with (
                patch.dict("os.environ", {}, clear=True),
                patch("shutil.which", return_value=str(bin_dir / "routertl")),
            ):
                result = self.runner.invoke(cli, ["workspace", "rebrand"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("rr", result.output)
            self.assertTrue((bin_dir / "rr").is_symlink())

    def test_rebrand_stale_venv_falls_through(self):
        """Stale VIRTUAL_ENV (binary missing) should fall through to which."""
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as stale_venv, tempfile.TemporaryDirectory() as system_dir:
            # Stale venv — bin/ exists but no routertl inside
            (Path(stale_venv) / "bin").mkdir()

            # System-wide routertl available via which
            system_bin = Path(system_dir) / "routertl"
            system_bin.write_text("#!/bin/sh\necho ok")
            system_bin.chmod(0o755)

            with (
                patch.dict("os.environ", {"VIRTUAL_ENV": stale_venv}),
                patch("shutil.which", return_value=str(system_bin)),
            ):
                result = self.runner.invoke(cli, ["workspace", "rebrand"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("rr", result.output)
            # rr should be created in the system dir, not the stale venv
            self.assertTrue((Path(system_dir) / "rr").is_symlink())


class TestUpdateSdkConfig(unittest.TestCase):
    """Tests for update-sdk → update-config delegation (P1 fix)."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("sdk.cli.commands.workspace.update._run_update_config")
    @patch("sdk.cli.commands.workspace.update._fix_makefile_include")
    @patch("sdk.cli.commands.workspace.update.subprocess.run")
    def test_update_sdk_calls_update_config(self, mock_run, mock_fix_mk, mock_update_cfg):
        """update-sdk should call _run_update_config after a successful pull."""
        # Simulate: git rev-parse → sha, git config → main, git checkout → ok,
        #           git pull → ok, git rev-parse → new sha, pip install → ok
        from unittest.mock import MagicMock

        def _make_result(stdout="", returncode=0):
            r = MagicMock()
            r.stdout = stdout
            r.stderr = ""
            r.returncode = returncode
            return r

        mock_run.side_effect = [
            _make_result("abc1234"),   # git rev-parse --short HEAD (before)
            _make_result("main"),      # git config submodule branch
            _make_result(),            # git checkout main
            _make_result("Already"),   # git pull --ff-only
            _make_result("abc1234"),   # git rev-parse --short HEAD (after)
            _make_result(),            # pip install -e
        ]

        with self.runner.isolated_filesystem():
            import os

            os.makedirs("vendor/routertl", exist_ok=True)
            Path("vendor/routertl/VERSION").write_text("3.0.0")

            result = self.runner.invoke(cli, ["workspace", "update-sdk"])
            self.assertEqual(result.exit_code, 0, f"Failed: {result.output}")

            # The key assertion: _run_update_config was called
            mock_update_cfg.assert_called_once_with(exit_on_error=False)

    @patch("sdk.cli.commands.workspace.update._run_update_config")
    @patch("sdk.cli.commands.workspace.update._fix_makefile_include")
    @patch("sdk.cli.commands.workspace.update.subprocess.run")
    def test_update_sdk_skips_config_on_pull_failure(self, mock_run, mock_fix_mk, mock_update_cfg):
        """update-sdk should NOT call _run_update_config when git pull fails."""
        from unittest.mock import MagicMock

        def _make_result(stdout="", returncode=0):
            r = MagicMock()
            r.stdout = stdout
            r.stderr = ""
            r.returncode = returncode
            return r

        mock_run.side_effect = [
            _make_result("abc1234"),   # git rev-parse --short HEAD
            _make_result("main"),      # git config submodule branch
            _make_result(),            # git checkout main
            _make_result("error", 1),  # git pull --ff-only FAILS
        ]

        with self.runner.isolated_filesystem():
            import os

            os.makedirs("vendor/routertl", exist_ok=True)
            Path("vendor/routertl/VERSION").write_text("3.0.0")

            result = self.runner.invoke(cli, ["workspace", "update-sdk"])
            self.assertNotEqual(result.exit_code, 0)

            # Should NOT have reached config regeneration
            mock_update_cfg.assert_not_called()


class TestPyprojectToml(unittest.TestCase):
    """Tests for pyproject.toml generation during init_project.py bootstrap."""

    def setUp(self):
        # Import the function under test
        pm_dir = Path(__file__).parent.parent
        if str(pm_dir) not in sys.path:
            sys.path.insert(0, str(pm_dir))
        from init_project import _generate_pyproject_toml

        self.generate = _generate_pyproject_toml

    def test_generates_valid_toml(self):
        """Generated pyproject.toml must be valid TOML with correct project name."""
        import tempfile
        try:
            import tomllib
        except ModuleNotFoundError:
            import tomli as tomllib

        with tempfile.TemporaryDirectory() as tmp:
            import os

            orig = os.getcwd()
            try:
                os.chdir(tmp)
                self.generate("my_fpga_project")
                pyproject = Path("pyproject.toml")
                self.assertTrue(pyproject.exists(), "pyproject.toml should be created")
                data = tomllib.loads(pyproject.read_text())
                self.assertEqual(data["project"]["name"], "my_fpga_project")
            finally:
                os.chdir(orig)

    def test_preserves_existing_pyproject(self):
        """Existing pyproject.toml must not be overwritten."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            import os

            orig = os.getcwd()
            try:
                os.chdir(tmp)
                Path("pyproject.toml").write_text("[project]\nname = \"custom\"\n")
                self.generate("should_not_appear")
                content = Path("pyproject.toml").read_text()
                self.assertIn("custom", content)
                self.assertNotIn("should_not_appear", content)
            finally:
                os.chdir(orig)

    def test_contains_ruff_config(self):
        """Generated file must include ruff config with the specified defaults."""
        import tempfile
        try:
            import tomllib
        except ModuleNotFoundError:
            import tomli as tomllib

        with tempfile.TemporaryDirectory() as tmp:
            import os

            orig = os.getcwd()
            try:
                os.chdir(tmp)
                self.generate("test_proj")
                data = tomllib.loads(Path("pyproject.toml").read_text())
                ruff = data["tool"]["ruff"]
                self.assertEqual(ruff["line-length"], 120)
                self.assertEqual(ruff["target-version"], "py310")
                lint_select = ruff["lint"]["select"]
                for rule in ["E", "F", "W"]:
                    self.assertIn(rule, lint_select)
                per_file = ruff["lint"]["per-file-ignores"]
                self.assertIn("**/test_*.py", per_file)
            finally:
                os.chdir(orig)


if __name__ == "__main__":
    unittest.main()
