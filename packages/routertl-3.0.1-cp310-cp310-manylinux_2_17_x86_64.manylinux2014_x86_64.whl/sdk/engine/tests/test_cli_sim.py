# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for simulation-related CLI commands: sim, view-log, watch,
sim summary aggregation, and clean sim.

Split from test_cli.py as part of P2.66.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli


class TestSimCommand(unittest.TestCase):
    """Tests for the sim command and its flags."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("subprocess.run")
    def test_sim_command(self, mock_run):
        mock_run.return_value.returncode = 0

        result = self.runner.invoke(cli, ["sim", "tb_uart"])
        self.assertEqual(result.exit_code, 0)
        called_args = mock_run.call_args[0][0]
        # The sim command now calls run_tests.py directly (or make as fallback)
        # Assert the test module is referenced in the command
        called_str = " ".join(str(a) for a in called_args)
        self.assertTrue(
            "tb_uart" in called_str,
            f"Expected 'tb_uart' in command: {called_args}",
        )

        # Test --all — should NOT include a pattern flag (runs all tests)
        result = self.runner.invoke(cli, ["sim", "--all"])
        self.assertEqual(result.exit_code, 0)

    @patch("subprocess.run")
    def test_sim_with_seed(self, mock_run):
        """Seed flag should be passed via env or command args."""
        mock_run.return_value.returncode = 0

        result = self.runner.invoke(cli, ["sim", "tb_uart", "--seed", "12345"])
        self.assertEqual(result.exit_code, 0)
        # Seed is now passed via RANDOM_SEED env var in direct mode,
        # or as a Make arg in fallback mode. Check either path.
        call_args = mock_run.call_args
        called_str = " ".join(str(a) for a in call_args[0][0])
        env = call_args[1].get("env", {}) if call_args[1] else {}
        seed_in_env = env.get("RANDOM_SEED") == "12345" if env else False
        seed_in_args = "RANDOM_SEED=12345" in called_str
        self.assertTrue(
            seed_in_env or seed_in_args,
            f"Seed 12345 not found in env or args: {call_args}",
        )

    def test_sim_history_empty(self):
        """--history should handle missing history gracefully."""
        with self.runner.isolated_filesystem():
            with patch("sdk.cli.commands.sim._get_results_dir", return_value=Path("nonexistent/results")):
                result = self.runner.invoke(cli, ["sim", "--history"])
                self.assertEqual(result.exit_code, 0)
                self.assertIn("No simulation history", result.output)

    # ──────────────────────────────────────────────────────────
    # Feature: routertl sim --tag
    # ──────────────────────────────────────────────────────────
    @patch("subprocess.run")
    def test_sim_tag_valid(self, mock_run):
        """--tag should run each test in the tag group sequentially."""
        mock_run.return_value.returncode = 0

        with self.runner.isolated_filesystem():
            import yaml

            config = {
                "simulation": {
                    "test_dir": "sim/cocotb/tests",
                    "tags": {
                        "smoke": ["test_a", "test_b"],
                        "full": ["test_a", "test_b", "test_c"],
                    },
                }
            }
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["sim", "--tag", "smoke"])
            self.assertEqual(result.exit_code, 0)
            # Two tests should have been run
            self.assertEqual(mock_run.call_count, 2)
            self.assertIn("smoke", result.output)
            self.assertIn("2 passed", result.output)

    def test_sim_tag_missing(self):
        """--tag with unknown tag name should exit with error."""
        with self.runner.isolated_filesystem():
            import yaml

            config = {"simulation": {"tags": {"smoke": ["test_a"]}}}
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["sim", "--tag", "nonexistent"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("not found", result.output)

    def test_sim_tag_no_tags_section(self):
        """--tag with no simulation.tags section should exit with error."""
        with self.runner.isolated_filesystem():
            import yaml

            config = {"simulation": {"test_dir": "sim/cocotb/tests"}}
            with open("project.yml", "w") as f:
                yaml.dump(config, f)

            result = self.runner.invoke(cli, ["sim", "--tag", "smoke"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("No simulation.tags", result.output)

    # ──────────────────────────────────────────────────────────
    # Feature: routertl watch
    # ──────────────────────────────────────────────────────────
    def test_watch_help(self):
        """Watch command should display help cleanly."""
        result = self.runner.invoke(cli, ["watch", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Auto-rerun", result.output)
        self.assertIn("--interval", result.output)

    def test_watch_help_shows_modes(self):
        """Watch --help should document sim and lint modes (P2.14)."""
        result = self.runner.invoke(cli, ["watch", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("sim", result.output)
        self.assertIn("lint", result.output)
        self.assertIn("--debounce", result.output)

    def test_watch_build_command_sim(self):
        """_build_command('sim', ...) should produce correct make command."""
        from sdk.cli.commands.watch import _build_command

        cmd, desc = _build_command("sim", "test_uart")
        self.assertEqual(cmd, ["make", "sim", "MODULE=test_uart"])
        self.assertIn("test_uart", desc)

    def test_watch_build_command_sim_all(self):
        """_build_command('sim', None) should run full simulation."""
        from sdk.cli.commands.watch import _build_command

        cmd, desc = _build_command("sim", None)
        self.assertEqual(cmd, ["make", "simulation"])
        self.assertIn("all", desc)

    def test_watch_build_command_lint(self):
        """_build_command('lint', ...) should produce make linting."""
        from sdk.cli.commands.watch import _build_command

        cmd, desc = _build_command("lint", None)
        self.assertEqual(cmd, ["make", "linting"])
        self.assertEqual(desc, "lint")

    def test_watch_detect_changes(self):
        """_detect_changes should detect new, modified, and deleted files."""
        from sdk.cli.commands.watch import _detect_changes

        prev = {Path("a.vhd"): 1.0, Path("b.vhd"): 2.0}
        curr = {Path("a.vhd"): 1.0, Path("b.vhd"): 3.0, Path("c.sv"): 4.0}

        changed = _detect_changes(prev, curr)
        names = {p.name for p in changed}
        # b.vhd was modified, c.sv is new
        self.assertIn("b.vhd", names)
        self.assertIn("c.sv", names)
        self.assertNotIn("a.vhd", names)


class TestViewLog(unittest.TestCase):
    """Tests for the routertl view-log command."""

    def setUp(self):
        self.runner = CliRunner()

    def test_view_log_with_test_name(self):
        """view-log <test> should display that specific test's log file."""
        with self.runner.isolated_filesystem():
            import os

            os.makedirs("sim/cocotb/logs", exist_ok=True)
            with open("sim/cocotb/logs/test_foo.log", "w") as f:
                f.write("PASS: test_foo completed successfully\n")

            result = self.runner.invoke(cli, ["view-log", "test_foo"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("PASS: test_foo completed successfully", result.output)

    def test_view_log_with_py_extension(self):
        """view-log should strip .py suffix from test name."""
        with self.runner.isolated_filesystem():
            import os

            os.makedirs("sim/cocotb/logs", exist_ok=True)
            with open("sim/cocotb/logs/test_bar.log", "w") as f:
                f.write("PASS: test_bar\n")

            result = self.runner.invoke(cli, ["view-log", "test_bar.py"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("PASS: test_bar", result.output)

    def test_view_log_not_found(self):
        """view-log for nonexistent test should error cleanly."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["view-log", "test_nonexistent"])
            self.assertNotEqual(result.exit_code, 0)
            self.assertIn("Log not found", result.output)

    def test_view_log_no_arg_latest_test(self):
        """view-log without arg should show most recent log (any type)."""
        import time

        with self.runner.isolated_filesystem():
            import os

            os.makedirs("sim/cocotb/logs", exist_ok=True)
            # Create an older log
            with open("sim/cocotb/logs/test_old.log", "w") as f:
                f.write("OLD RESULT\n")
            time.sleep(0.05)
            # Create a newer log (lint) — should be shown as most recent
            with open("sim/cocotb/logs/lint.log", "w") as f:
                f.write("LINT OUTPUT\n")

            result = self.runner.invoke(cli, ["view-log"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("LINT OUTPUT", result.output)
            self.assertNotIn("OLD RESULT", result.output)


class TestSimSummaryAggregation(unittest.TestCase):
    """Tests for _print_result_summary aggregation (counter bug regression)."""

    def setUp(self):
        self.runner = CliRunner()

    def test_regression_summary_aggregates_entries(self):
        """Summary should aggregate all entries from same run, not just last."""
        import json
        from datetime import datetime, timedelta, timezone
        from pathlib import Path
        from unittest.mock import patch as mock_patch

        with self.runner.isolated_filesystem():
            results_dir = Path("sim") / "results"
            results_dir.mkdir(parents=True, exist_ok=True)
            history_path = results_dir / "history.jsonl"

            # Simulate a regression with 3 test files finishing within 1 minute
            now = datetime.now(timezone.utc)
            entries = [
                {
                    "timestamp": (now - timedelta(seconds=30)).isoformat(timespec="seconds"),
                    "module": "test_a",
                    "passed": 5,
                    "failed": 0,
                    "errors": 0,
                    "seed": 123,
                    "duration_s": 1.0,
                },
                {
                    "timestamp": (now - timedelta(seconds=15)).isoformat(timespec="seconds"),
                    "module": "test_b",
                    "passed": 10,
                    "failed": 1,
                    "errors": 0,
                    "seed": 123,
                    "duration_s": 2.5,
                },
                {
                    "timestamp": now.isoformat(timespec="seconds"),
                    "module": "test_c",
                    "passed": 3,
                    "failed": 0,
                    "errors": 0,
                    "seed": 123,
                    "duration_s": 0.5,
                },
            ]
            with open(history_path, "w") as f:
                for e in entries:
                    f.write(json.dumps(e) + "\n")

            # Capture output — must mock at the module where click is imported
            from sdk.cli.commands import sim as sim_mod

            output_lines = []
            original_echo = sim_mod.click.echo
            sim_mod.click.echo = lambda msg="", **kw: output_lines.append(str(msg))
            try:
                with mock_patch.object(sim_mod, "_get_results_dir", return_value=results_dir):
                    sim_mod._print_result_summary(module=None)
            finally:
                sim_mod.click.echo = original_echo

            combined = "\n".join(output_lines)
            # Should show aggregated total: 18 passed, 1 failed
            self.assertIn("18 passed", combined)
            self.assertIn("1 failed", combined)

    def test_single_module_summary(self):
        """Single-module summary should show only that module's results."""
        import json
        from datetime import datetime, timezone
        from pathlib import Path
        from unittest.mock import patch as mock_patch

        with self.runner.isolated_filesystem():
            results_dir = Path("sim") / "results"
            results_dir.mkdir(parents=True, exist_ok=True)
            history_path = results_dir / "history.jsonl"

            now = datetime.now(timezone.utc)
            entry = {
                "timestamp": now.isoformat(timespec="seconds"),
                "module": "test_uart",
                "passed": 7,
                "failed": 0,
                "errors": 0,
                "seed": 42,
                "duration_s": 1.2,
            }
            with open(history_path, "w") as f:
                f.write(json.dumps(entry) + "\n")

            from sdk.cli.commands import sim as sim_mod

            output_lines = []
            original_echo = sim_mod.click.echo
            sim_mod.click.echo = lambda msg="", **kw: output_lines.append(str(msg))
            try:
                with mock_patch.object(sim_mod, "_get_results_dir", return_value=results_dir):
                    sim_mod._print_result_summary(module="test_uart")
            finally:
                sim_mod.click.echo = original_echo

            combined = "\n".join(output_lines)
            self.assertIn("7 passed", combined)
            self.assertIn("seed: 42", combined)


class TestCleanSim(unittest.TestCase):
    """Tests for workspace clean --sim."""

    def setUp(self):
        self.runner = CliRunner()

    def test_clean_sim_removes_sim_dirs(self):
        """--sim should remove simulation artifact directories."""
        with self.runner.isolated_filesystem():
            import os

            # Create simulation artifact dirs
            os.makedirs("sim/cocotb/logs", exist_ok=True)
            os.makedirs("sim/results", exist_ok=True)
            os.makedirs("sim_build", exist_ok=True)
            # Create a dummy file so dirs aren't empty
            with open("sim/cocotb/logs/test.log", "w") as f:
                f.write("log")

            result = self.runner.invoke(cli, ["workspace", "clean", "--sim"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("removed", result.output.lower())
            # Dirs should be removed
            self.assertFalse(os.path.exists("sim/cocotb/logs"))
            self.assertFalse(os.path.exists("sim_build"))

    def test_clean_sim_empty(self):
        """--sim with no artifacts should report nothing to clean."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["workspace", "clean", "--sim"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("tidy", result.output.lower())


if __name__ == "__main__":
    unittest.main()
