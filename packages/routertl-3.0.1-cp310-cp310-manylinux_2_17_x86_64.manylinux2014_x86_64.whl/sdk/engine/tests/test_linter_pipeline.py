# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for the linter pipeline logic — path normalization, topological sort, and edge cases.

These tests verify the exact bugs fixed in commit 9fcee52:
1. Absolute vs relative path mismatch between --sort-pkgs and libraries.json
2. Custom library files compiled in arbitrary order instead of dependency-sorted

Also includes Phase 2b Verilator SV linting tests.

All tests are pure-Python unit tests using synthetic VHDL fixtures
(no GHDL dependency required).
"""

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

# Add project root to path
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.append(str(PM_DIR))

from dependency_resolver import DependencyResolver


class TestPathNormalization(unittest.TestCase):
    """Tests for the path normalization contract between dependency_resolver
    and smart_linter.py.

    The dependency resolver emits absolute paths.  The library cache
    (libraries.json) stores relative paths.  smart_linter.py must normalize
    before comparing.
    """

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()
        self.cache_dir = self.test_dir / ".routertl_cache"
        self.cache_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def _build_exclusion_set(self, custom_libs: dict) -> set:
        """Replicate the smart_linter.py path normalization logic.

        This is the exact algorithm from smart_linter.py lines 132-144:
        load libraries.json, normalize each path to absolute via resolve().
        """
        custom_lib_files = set()
        for lib_files in custom_libs.values():
            for lf in lib_files:
                custom_lib_files.add(str(Path(lf).resolve()))
        return custom_lib_files

    def test_custom_lib_excluded_from_precompile_absolute_path(self):
        """Absolute paths in libraries.json correctly matched against --sort-pkgs output."""
        pkg_file = self.create_file(
            "pkg/my_pkg.vhd",
            """\
package my_pkg is
end package my_pkg;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        sorted_pkgs = resolver.resolve_packages()

        # Simulate libraries.json with absolute paths
        abs_path = str(pkg_file.resolve())
        custom_libs = {"mylib": [abs_path]}
        exclusion_set = self._build_exclusion_set(custom_libs)

        # The sorted_pkgs output is absolute — it should match
        for pkg_path in sorted_pkgs:
            if pkg_path.name == "my_pkg.vhd":
                self.assertIn(str(pkg_path), exclusion_set)
                break
        else:
            self.fail("my_pkg.vhd not found in resolve_packages() output")

    def test_custom_lib_excluded_from_precompile_relative_path(self):
        """Relative paths in libraries.json normalized to absolute before comparison.

        This is the exact bug fixed in commit 9fcee52: libraries.json had
        relative paths like 'hw/rtl/pkg/system_config_pkg.vhd' but
        --sort-pkgs output had '/full/path/hw/rtl/pkg/system_config_pkg.vhd'.
        """
        pkg_file = self.create_file(
            "pkg/my_pkg.vhd",
            """\
package my_pkg is
end package my_pkg;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        sorted_pkgs = resolver.resolve_packages()

        # Simulate libraries.json with RELATIVE paths (the bug scenario)
        rel_path = str(pkg_file.relative_to(Path.cwd())) if pkg_file.is_relative_to(Path.cwd()) else str(pkg_file)
        # Use a definitely-relative path constructed from components
        rel_from_test_dir = str(pkg_file.relative_to(self.test_dir))
        # The cache stores relative paths — simulate writing from test_dir context
        custom_libs = {"mylib": [str(self.test_dir / rel_from_test_dir)]}

        exclusion_set = self._build_exclusion_set(custom_libs)

        for pkg_path in sorted_pkgs:
            if pkg_path.name == "my_pkg.vhd":
                self.assertIn(str(pkg_path), exclusion_set)
                break
        else:
            self.fail("my_pkg.vhd not found in resolve_packages() output")


class TestTopologicalSort(unittest.TestCase):
    """Tests for topological sorting of custom library files."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def test_custom_lib_topological_sort_order(self):
        """Custom lib files sorted using --sort-pkgs order map.

        This tests the fix in commit 9fcee52: before the fix, custom
        library files were compiled in their libraries.json insertion
        order, not dependency order.
        """
        # base_pkg has no deps
        base_pkg = self.create_file(
            "pkg/base_pkg.vhd",
            """\
package base_pkg is
    constant BASE_VAL : integer := 1;
end package base_pkg;
""",
        )
        # derived_pkg depends on base_pkg
        derived_pkg = self.create_file(
            "pkg/derived_pkg.vhd",
            """\
use work.base_pkg.all;
package derived_pkg is
    constant DERIVED_VAL : integer := BASE_VAL + 1;
end package derived_pkg;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        sorted_pkgs = resolver.resolve_packages()
        sorted_list = [str(p) for p in sorted_pkgs]

        # Build the order map (same algorithm as smart_linter.py L196-197)
        order_map = {p: i for i, p in enumerate(sorted_list)}

        # Simulate libraries.json with files in WRONG order (derived first)
        lib_files = [str(derived_pkg), str(base_pkg)]

        # Apply the sorting algorithm from smart_linter.py L198-201
        lib_files_sorted = sorted(
            lib_files,
            key=lambda f: order_map.get(str(Path(f).resolve()), len(sorted_list)),
        )

        sorted_names = [Path(f).name for f in lib_files_sorted]
        # base_pkg must come before derived_pkg
        self.assertEqual(sorted_names, ["base_pkg.vhd", "derived_pkg.vhd"])

    def test_lib_file_not_in_sort_pkgs(self):
        """Library file absent from --sort-pkgs falls back to end-of-list position.

        If a library file isn't found in the sort-pkgs output (e.g. an
        entity file, not a package), it should sort to the end rather
        than crash.
        """
        pkg_file = self.create_file(
            "pkg/only_pkg.vhd",
            """\
package only_pkg is
end package only_pkg;
""",
        )
        entity_file = self.create_file(
            "units/helper.vhd",
            """\
entity helper is
end entity helper;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        sorted_pkgs = resolver.resolve_packages()
        sorted_list = [str(p) for p in sorted_pkgs]
        order_map = {p: i for i, p in enumerate(sorted_list)}

        # Both pkg and entity in the library
        lib_files = [str(entity_file), str(pkg_file)]

        lib_files_sorted = sorted(
            lib_files,
            key=lambda f: order_map.get(str(Path(f).resolve()), len(sorted_list)),
        )

        sorted_names = [Path(f).name for f in lib_files_sorted]
        # Package should come first (it's in the order map), entity falls to end
        self.assertEqual(sorted_names, ["only_pkg.vhd", "helper.vhd"])


class TestSortPkgsOutput(unittest.TestCase):
    """Tests for --sort-pkgs (resolve_packages) correctness with custom libraries."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def test_sort_pkgs_includes_custom_lib_files(self):
        """resolve_packages() returns packages from custom libraries."""
        self.create_file(
            "pkg/lib_pkg.vhd",
            """\
package lib_pkg is
end package lib_pkg;
""",
        )
        self.create_file(
            "pkg/work_pkg.vhd",
            """\
package work_pkg is
end package work_pkg;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        sorted_pkgs = resolver.resolve_packages()
        pkg_names = [p.name for p in sorted_pkgs]

        self.assertIn("lib_pkg.vhd", pkg_names)
        self.assertIn("work_pkg.vhd", pkg_names)


class TestForestFiltering(unittest.TestCase):
    """Tests for --forest hierarchy detection with custom library files."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def test_forest_excludes_package_only_roots(self):
        """resolve_forest() filters packages from root candidates.

        Package files should not appear as top-level hierarchy roots
        even if they have in-degree 0 in the dependency graph.
        """
        self.create_file(
            "pkg/standalone_pkg.vhd",
            """\
package standalone_pkg is
end package standalone_pkg;
""",
        )
        self.create_file(
            "units/top.vhd",
            """\
use work.standalone_pkg.all;
entity top is
end entity top;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        forest = resolver.resolve_forest()

        tree_tops = [t["top"] for t in forest["trees"]]
        # 'top' entity should be a root, standalone_pkg should NOT be
        self.assertIn("top", tree_tops)
        self.assertNotIn("standalone_pkg", tree_tops)

    def test_forest_includes_custom_lib_entity_deps(self):
        """Forest file lists include files from custom library paths."""
        self.create_file(
            "pkg/custom_pkg.vhd",
            """\
package custom_pkg is
end package custom_pkg;
""",
        )
        self.create_file(
            "units/top.vhd",
            """\
library mylib;
use mylib.custom_pkg.all;
entity top is
end entity top;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        forest = resolver.resolve_forest()

        for tree in forest["trees"]:
            if tree["top"] == "top":
                file_names = [Path(f).name for f in tree["files"]]
                self.assertIn("custom_pkg.vhd", file_names)
                break
        else:
            self.fail("'top' not found in forest trees")


class TestCompileLibCrossReference(unittest.TestCase):
    """Tests for files that cross-reference within the same custom library."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def test_intra_library_cross_reference(self):
        """Files within same library using cross-references are resolved."""
        # system_config_pkg is the base
        self.create_file(
            "pkg/system_config_pkg.vhd",
            """\
package system_config_pkg is
    constant SYS_CLK_FREQ : integer := 100_000_000;
end package system_config_pkg;
""",
        )
        # sniffer_pkg depends on system_config_pkg
        self.create_file(
            "pkg/sniffer_pkg.vhd",
            """\
use work.system_config_pkg.all;
package sniffer_pkg is
    constant SNIFFER_DEPTH : integer := SYS_CLK_FREQ / 1000;
end package sniffer_pkg;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        sorted_pkgs = resolver.resolve_packages()
        pkg_names = [p.name for p in sorted_pkgs]

        # system_config_pkg must appear before sniffer_pkg
        idx_sys = pkg_names.index("system_config_pkg.vhd")
        idx_sniff = pkg_names.index("sniffer_pkg.vhd")
        self.assertLess(idx_sys, idx_sniff, "system_config_pkg must be compiled before sniffer_pkg")


class TestEdgeCases(unittest.TestCase):
    """Edge cases for the library pipeline."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_empty_library_skipped(self):
        """Empty library list in libraries.json doesn't crash.

        The smart_linter.py Phase 1.5 loop skips libraries with empty file
        lists via 'if not lib_files: continue'.
        """
        custom_libs = {"empty_lib": []}

        # Replicate the Phase 1.5 loop guard
        for lib_name, lib_files in custom_libs.items():
            if not lib_files:
                continue
            self.fail("Empty library should have been skipped")

    def test_single_file_library(self):
        """Library with single file compiles correctly."""
        test_dir = Path(tempfile.mkdtemp())
        src_dir = test_dir / "src"
        src_dir.mkdir()

        try:
            pkg_file = src_dir / "single_pkg.vhd"
            pkg_file.write_text("""\
package single_pkg is
end package single_pkg;
""")
            resolver = DependencyResolver([src_dir], verbose=False)
            sorted_pkgs = resolver.resolve_packages()
            sorted_list = [str(p) for p in sorted_pkgs]
            order_map = {p: i for i, p in enumerate(sorted_list)}

            lib_files = [str(pkg_file)]
            lib_files_sorted = sorted(
                lib_files,
                key=lambda f: order_map.get(str(Path(f).resolve()), len(sorted_list)),
            )

            self.assertEqual(len(lib_files_sorted), 1)
            self.assertEqual(Path(lib_files_sorted[0]).name, "single_pkg.vhd")
        finally:
            shutil.rmtree(test_dir)

    def test_libraries_json_round_trip(self):
        """libraries.json can be written and read back correctly."""
        cache_dir = self.test_dir / ".routertl_cache"
        cache_dir.mkdir()
        lib_cache = cache_dir / "libraries.json"

        libraries = {
            "tich": ["hw/rtl/pkg/a.vhd", "hw/rtl/pkg/b.vhd"],
            "debug": ["hw/rtl/debug/d.vhd"],
        }

        with open(lib_cache, "w") as f:
            json.dump(libraries, f, indent=4)

        with open(lib_cache, "r") as f:
            loaded = json.load(f)

        self.assertEqual(loaded, libraries)


class TestParserErrorSurfacing(unittest.TestCase):
    """Tests for ghdl_output_parser.py error surfacing.

    Verifies that raw GHDL errors (file-not-found, missing library, etc.)
    are rendered in the formatted output instead of being silently dropped.
    """

    def setUp(self):
        # Import parser from project-manager directory
        sys.path.append(str(PM_DIR))
        from ghdl_output_parser import GHDLOutputParser, parse_and_format

        self.GHDLOutputParser = GHDLOutputParser
        self.parse_and_format = parse_and_format

    def test_parser_surfaces_raw_errors(self):
        """Parser renders 'cannot open' errors, doesn't say 'No issues found'."""
        raw = "/usr/bin/ghdl:error: cannot open /path/to/missing.vhd\n"
        formatted, exit_code = self.parse_and_format(raw)

        self.assertNotIn("No issues found", formatted)
        self.assertIn("cannot open", formatted)
        self.assertEqual(exit_code, 1)

    def test_parser_raw_errors_set_exit_code(self):
        """parse_and_format returns 1 when only raw_errors present."""
        raw = "/usr/bin/ghdl:error: cannot find resource library 'tich'\n"
        _, exit_code = self.parse_and_format(raw)

        self.assertEqual(exit_code, 1)

    def test_parser_catches_unrecognized_error_lines(self):
        """Lines matching neither regex but containing 'error' are captured."""
        raw = "some_tool: fatal error: unexpected EOF\n"
        parser = self.GHDLOutputParser()
        parsed = parser.parse(raw)

        self.assertTrue(
            len(parsed.raw_errors) > 0,
            "Unrecognized error line should be captured as raw_error",
        )
        self.assertIn("fatal error", parsed.raw_errors[0])

    def test_parser_mixed_lint_and_raw_errors(self):
        """Both standard lint errors and raw GHDL errors are rendered."""
        raw = (
            "/path/foo.vhd:16:9:error: unknown identifier 'bar'\n"
            "/usr/bin/ghdl:error: cannot open /path/missing.vhd\n"
        )
        formatted, exit_code = self.parse_and_format(raw)

        self.assertIn("unknown identifier", formatted)
        self.assertIn("cannot open", formatted)
        self.assertEqual(exit_code, 1)

    def test_parser_no_issues_on_clean_output(self):
        """Empty or non-error output still shows 'No issues found'."""
        raw = ""
        formatted, exit_code = self.parse_and_format(raw)

        self.assertIn("No issues found", formatted)
        self.assertEqual(exit_code, 0)


class TestEntityTopologicalSort(unittest.TestCase):
    """Tests for full topological sort of entity files in custom libraries.

    Verifies that entity files with inter-dependencies are correctly
    ordered by the dependency resolver, not by project.yml insertion order.
    """

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def test_entity_dependency_order(self):
        """Entity files sorted by dependency, not insertion order.

        mux_wrapper depends on helper_entity.  Even when mux_wrapper is
        listed first, the resolver should place helper_entity first.
        """
        helper = self.create_file(
            "helper_entity.vhd",
            """\
entity helper_entity is
end entity helper_entity;
""",
        )
        wrapper = self.create_file(
            "mux_wrapper.vhd",
            """\
entity mux_wrapper is
end entity mux_wrapper;
architecture rtl of mux_wrapper is
begin
  i_helper : entity work.helper_entity;
end architecture rtl;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        deps = resolver.resolve_dependencies("mux_wrapper")
        dep_names = [p.name for p in deps]

        self.assertIn("helper_entity.vhd", dep_names)
        self.assertIn("mux_wrapper.vhd", dep_names)
        idx_helper = dep_names.index("helper_entity.vhd")
        idx_wrapper = dep_names.index("mux_wrapper.vhd")
        self.assertLess(
            idx_helper,
            idx_wrapper,
            "helper_entity must be compiled before mux_wrapper",
        )

    def test_mixed_pkg_entity_dependency_order(self):
        """Mixed packages and entities sorted correctly.

        config_pkg -> helper_entity -> top_wrapper
        """
        self.create_file(
            "config_pkg.vhd",
            """\
package config_pkg is
    constant CFG_VAL : integer := 42;
end package config_pkg;
""",
        )
        self.create_file(
            "helper_entity.vhd",
            """\
use work.config_pkg.all;
entity helper_entity is
end entity helper_entity;
""",
        )
        self.create_file(
            "top_wrapper.vhd",
            """\
use work.config_pkg.all;
entity top_wrapper is
end entity top_wrapper;
architecture rtl of top_wrapper is
begin
  i_helper : entity work.helper_entity;
end architecture rtl;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        deps = resolver.resolve_dependencies("top_wrapper")
        dep_names = [p.name for p in deps]

        # config_pkg < helper_entity < top_wrapper
        self.assertLess(
            dep_names.index("config_pkg.vhd"),
            dep_names.index("helper_entity.vhd"),
        )
        self.assertLess(
            dep_names.index("helper_entity.vhd"),
            dep_names.index("top_wrapper.vhd"),
        )


class TestAutoLibraryDiscovery(unittest.TestCase):
    """Tests for discover_libraries() auto-discovery from VHDL source.

    Verifies that the resolver correctly identifies library memberships
    from entity instantiations and use clauses in the source code.
    """

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def test_discover_from_entity_instantiation(self):
        """Entities referenced via 'entity mylib.X' are discovered."""
        self.create_file(
            "helper.vhd",
            """\
entity helper is
end entity helper;
""",
        )
        self.create_file(
            "top.vhd",
            """\
entity top is
end entity top;
architecture rtl of top is
begin
  i_helper : entity mylib.helper;
end architecture rtl;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        libs = resolver.discover_libraries()

        self.assertIn("mylib", libs)
        self.assertTrue(
            any("helper.vhd" in f for f in libs["mylib"]),
            "helper.vhd should be auto-discovered in mylib",
        )

    def test_discover_from_use_clause(self):
        """Packages referenced via 'use mylib.pkg.all' are discovered."""
        self.create_file(
            "my_pkg.vhd",
            """\
package my_pkg is
    constant C : integer := 42;
end package my_pkg;
""",
        )
        self.create_file(
            "consumer.vhd",
            """\
use mylib.my_pkg.all;
entity consumer is
end entity consumer;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        libs = resolver.discover_libraries()

        self.assertIn("mylib", libs)
        self.assertTrue(
            any("my_pkg.vhd" in f for f in libs["mylib"]),
            "my_pkg.vhd should be auto-discovered in mylib",
        )

    def test_discover_excludes_standard_libs(self):
        """Standard libraries (ieee, std, work) are not reported."""
        self.create_file(
            "top.vhd",
            """\
use ieee.std_logic_1164.all;
use std.textio.all;
entity top is
end entity top;
architecture rtl of top is
begin
  i_sub : entity work.sub_entity;
end architecture rtl;
""",
        )
        self.create_file(
            "sub_entity.vhd",
            """\
entity sub_entity is
end entity sub_entity;
""",
        )

        resolver = DependencyResolver([self.src_dir], verbose=False)
        libs = resolver.discover_libraries()

        self.assertNotIn("ieee", libs)
        self.assertNotIn("std", libs)
        self.assertNotIn("work", libs)

    def test_discover_empty_project(self):
        """Empty project returns no libraries."""
        resolver = DependencyResolver([self.src_dir], verbose=False)
        libs = resolver.discover_libraries()
        self.assertEqual(libs, {})


class TestSummaryTableStatus(unittest.TestCase):
    """Excluded lint entries must render as SKIP, never PASS.

    Regression test for the bug where ``sniffer_gather`` was excluded from
    linting but the summary table still showed PASS | Cached.
    """

    def setUp(self):
        sys.path.append(str(PM_DIR))
        from smart_linter import print_summary_table

        self.print_summary_table = print_summary_table

    def _capture_table(self, results):
        """Capture the printed summary table output."""
        import io
        from contextlib import redirect_stdout

        buf = io.StringIO()
        with redirect_stdout(buf):
            self.print_summary_table(results)
        return buf.getvalue()

    def test_excluded_entry_shows_skip_not_pass(self):
        """An excluded hierarchy must say SKIP, not PASS."""
        results = [{"top": "sniffer_gather", "status": "SKIP", "details": "Excluded"}]
        output = self._capture_table(results)

        self.assertIn("SKIP", output)
        self.assertNotIn("PASS", output)
        self.assertNotIn("FAIL", output)

    def test_pass_entry_shows_pass(self):
        """Normal passing entry still shows PASS."""
        results = [{"top": "edge_detector", "status": "PASS", "details": "3 files"}]
        output = self._capture_table(results)

        self.assertIn("PASS", output)
        self.assertNotIn("SKIP", output)

    def test_mixed_results_render_correctly(self):
        """A mix of PASS, SKIP, and FAIL all render with distinct labels."""
        results = [
            {"top": "edge_detector", "status": "PASS", "details": "3 files"},
            {"top": "sniffer_gather", "status": "SKIP", "details": "Excluded"},
            {"top": "broken_unit", "status": "FAIL", "details": "Check Log"},
        ]
        output = self._capture_table(results)

        self.assertIn("PASS", output)
        self.assertIn("SKIP", output)
        self.assertIn("FAIL", output)


class TestWorkdirHealthCheck(unittest.TestCase):
    """Tests for workdir health check — auto-detect stale/missing GHDL work dirs.

    Regression test for the P0 hook-lint lifecycle gap: after clean, SDK
    update, or first clone the ``sim/work/`` tree may be absent or lack
    compiled ``.cf`` catalog files.  The smart linter must detect this and
    force a PRECOMPILE rebuild before Phase 1.5.

    These tests replicate the exact detection logic from smart_linter.py
    (workdir_healthy check) without requiring GHDL.
    """

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.workdir = self.test_dir / "sim" / "work"

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def _is_workdir_healthy(self):
        """Replicate the smart_linter.py workdir health check logic."""
        return (
            self.workdir.is_dir()
            and (self.workdir / "work").is_dir()
            and any((self.workdir / "work").glob("*.cf"))
        )

    def test_missing_workdir_detected(self):
        """Completely absent sim/work/ directory is detected as unhealthy.

        This is the first-clone scenario: the consumer has never run
        ``make linting`` before, so no work directory exists.
        """
        self.assertFalse(self._is_workdir_healthy())

    def test_empty_workdir_detected(self):
        """sim/work/work/ exists but has no .cf files (stale after clean).

        After ``rm -rf sim/work/work/*`` the directory exists but the GHDL
        catalog files are gone.  The health check must detect this.
        """
        (self.workdir / "work").mkdir(parents=True)
        self.assertFalse(self._is_workdir_healthy())

    def test_healthy_workdir_passes(self):
        """sim/work/work/ with .cf catalog files is detected as healthy."""
        (self.workdir / "work").mkdir(parents=True)
        (self.workdir / "work" / "work-obj08.cf").write_text("-- ghdl catalog\n")
        self.assertTrue(self._is_workdir_healthy())

    def test_stale_custom_lib_cleanup(self):
        """Stale custom library dirs are removed during rebuild.

        When the workdir is unhealthy and custom_libs contains ``tich``,
        the rebuild logic should remove ``sim/work/tich/`` to prevent
        artifact contamination from a previous incompatible compilation.
        """
        custom_libs = {"tich": ["some_file.vhd"]}

        # Create stale custom lib dir (simulating previous compilation)
        stale_lib = self.workdir / "tich"
        stale_lib.mkdir(parents=True)
        (stale_lib / "tich-obj08.cf").write_text("-- stale catalog\n")

        # Replicate the cleanup logic from smart_linter.py
        for lib_name in custom_libs:
            stale_path = self.workdir / lib_name
            if stale_path.is_dir():
                shutil.rmtree(stale_path)

        self.assertFalse(stale_lib.exists(), "Stale custom lib dir should be removed")

class TestVerilatorSVLinting(unittest.TestCase):
    """Tests for Phase 2b — Verilator SV/V file linting.

    Verifies that SV files are collected instead of skipped, Verilator
    is invoked with correct flags, and graceful fallback when Verilator
    is unavailable.
    """

    def setUp(self):
        sys.path.append(str(PM_DIR))
        from smart_linter import _has_verilator, run_verilator_lint

        self._has_verilator = _has_verilator
        self.run_verilator_lint = run_verilator_lint

        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_sv_files_collected_not_skipped(self):
        """SV files are partitioned into sv_files list, not silently dropped.

        Replicates the exact partition logic from smart_linter.py Phase 2
        to verify that .sv/.v files end up in sv_files instead of being
        skipped entirely.
        """
        files_list = [
            "/project/src/top.vhd",
            "/project/src/sub.sv",
            "/project/src/helper.v",
            "/project/src/pkg.vhd",
            "/project/src/inc.svh",
        ]
        compiled_set = set()
        exclude_set = set()

        new_files = []
        sv_files = []
        for f in files_list:
            if f in compiled_set:
                continue
            if f.endswith((".v", ".sv", ".vh", ".svh")):
                sv_files.append(f)
                continue
            new_files.append(f)

        # VHDL files in new_files
        self.assertEqual(len(new_files), 2)
        self.assertTrue(all(f.endswith(".vhd") for f in new_files))

        # SV/V files collected separately
        self.assertEqual(len(sv_files), 3)
        sv_names = [Path(f).name for f in sv_files]
        self.assertIn("sub.sv", sv_names)
        self.assertIn("helper.v", sv_names)
        self.assertIn("inc.svh", sv_names)

    def test_verilator_availability_check(self):
        """_has_verilator() returns a bool reflecting shutil.which."""
        from unittest.mock import patch

        with patch("shutil.which", return_value="/usr/bin/verilator"):
            self.assertTrue(self._has_verilator())

        with patch("shutil.which", return_value=None):
            self.assertFalse(self._has_verilator())

    def test_run_verilator_lint_invocation(self):
        """run_verilator_lint builds correct verilator command line."""
        from unittest.mock import MagicMock, patch

        sv_files = ["/src/mod_a.sv", "/src/mod_b.sv"]
        include_dirs = ["/src/inc", "/src"]

        mock_result = MagicMock()
        mock_result.stdout = ""
        mock_result.stderr = ""
        mock_result.returncode = 0

        log_handle = MagicMock()

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            ret, warn = self.run_verilator_lint(sv_files, include_dirs, log_handle)

            mock_run.assert_called_once()
            cmd = mock_run.call_args[0][0]

            # Verify command structure
            self.assertEqual(cmd[0], "verilator")
            self.assertEqual(cmd[1], "--lint-only")
            self.assertEqual(cmd[2], "-Wall")
            self.assertEqual(cmd[3], "-Wno-fatal")

            # Include flags present (sorted, deduplicated)
            inc_flags = [c for c in cmd if c.startswith("-I")]
            self.assertEqual(len(inc_flags), 2)
            self.assertIn("-I/src", inc_flags)
            self.assertIn("-I/src/inc", inc_flags)

            # SV files at the end
            self.assertIn("/src/mod_a.sv", cmd)
            self.assertIn("/src/mod_b.sv", cmd)

            # Return values
            self.assertEqual(ret, 0)
            self.assertFalse(warn)

    def test_sv_include_dirs_extracted(self):
        """Include directories are derived from parent paths of SV files."""
        sv_files = [
            "/project/src/ip/mod_a.sv",
            "/project/src/ip/mod_b.sv",
            "/project/src/adapters/adapter.sv",
            "/project/src/ip/mod_c.sv",
        ]

        # Replicate the exact logic from smart_linter.py Phase 2b
        inc_dirs = sorted({str(Path(f).parent) for f in sv_files})

        # Two unique directories
        self.assertEqual(len(inc_dirs), 2)
        self.assertIn("/project/src/adapters", inc_dirs)
        self.assertIn("/project/src/ip", inc_dirs)

    def test_run_verilator_lint_detects_warnings(self):
        """run_verilator_lint detects warning keywords in output."""
        from unittest.mock import MagicMock, patch

        sv_files = ["/src/mod.sv"]
        include_dirs = ["/src"]
        log_handle = MagicMock()

        mock_result = MagicMock()
        mock_result.stdout = ""
        mock_result.stderr = "%Warning-UNUSED: /src/mod.sv:5: Signal unused\n"
        mock_result.returncode = 0

        with patch("subprocess.run", return_value=mock_result):
            ret, warn = self.run_verilator_lint(sv_files, include_dirs, log_handle)
            self.assertEqual(ret, 0)
            self.assertTrue(warn)


class TestGitignoreFiltering(unittest.TestCase):
    """Tests for gitignore-aware HDL file discovery.

    Verifies that the dependency resolver respects ``.gitignore`` rules
    when scanning for HDL files, with graceful fallback for non-git
    directories and an explicit opt-out flag.
    """

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def _init_git_repo(self, gitignore_content: str):
        """Create a minimal git repo with a .gitignore."""
        (self.test_dir / ".git").mkdir()
        (self.test_dir / ".gitignore").write_text(gitignore_content)

    def _create_file(self, rel_path: str, content: str) -> Path:
        fp = self.test_dir / rel_path
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content)
        return fp

    def test_gitignored_files_excluded(self):
        """Gitignored VHDL and SV files are excluded from entity_map.

        Creates ``src/gen/wrapper.vhd`` and ``src/gen/stub.sv`` which
        match the ``.gitignore`` pattern ``src/gen/*``.  A non-ignored
        file ``src/top.vhd`` must still be discovered.
        """
        self._init_git_repo("src/gen/\n")

        self._create_file("src/gen/wrapper.vhd", """\
entity wrapper is
end entity wrapper;
""")
        self._create_file("src/gen/stub.sv", """\
module stub (input logic clk);
endmodule
""")
        self._create_file("src/top.vhd", """\
entity top is
end entity top;
""")

        src_dir = self.test_dir / "src"
        resolver = DependencyResolver([src_dir], verbose=False)

        self.assertIn("top", resolver.entity_map,
                      "Non-ignored entity must be discovered")
        self.assertNotIn("wrapper", resolver.entity_map,
                         "Gitignored VHDL entity must be excluded")
        self.assertNotIn("stub", resolver.entity_map,
                         "Gitignored SV module must be excluded")

    def test_no_git_repo_fallback(self):
        """All files are discovered when not inside a git repository.

        Without a ``.git/`` directory, gitignore filtering is disabled
        and every HDL file is included — graceful fallback.
        """
        self._create_file("src/gen/wrapper.vhd", """\
entity wrapper is
end entity wrapper;
""")
        self._create_file("src/top.vhd", """\
entity top is
end entity top;
""")

        src_dir = self.test_dir / "src"
        resolver = DependencyResolver([src_dir], verbose=False)

        self.assertIn("top", resolver.entity_map)
        self.assertIn("wrapper", resolver.entity_map,
                      "Files must be included when no git repo is present")

    def test_no_respect_gitignore_flag(self):
        """``respect_gitignore=False`` includes gitignored files.

        Same setup as ``test_gitignored_files_excluded`` but with the
        flag disabled — the ignored file must appear in entity_map.
        """
        self._init_git_repo("src/gen/\n")

        self._create_file("src/gen/wrapper.vhd", """\
entity wrapper is
end entity wrapper;
""")
        self._create_file("src/top.vhd", """\
entity top is
end entity top;
""")

        src_dir = self.test_dir / "src"
        resolver = DependencyResolver([src_dir], verbose=False,
                                      respect_gitignore=False)

        self.assertIn("top", resolver.entity_map)
        self.assertIn("wrapper", resolver.entity_map,
                      "Gitignored files must be included when flag is False")


if __name__ == "__main__":
    unittest.main()
