# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Unit tests for the reverse_dependents() method in DependencyResolver."""

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

# Add project root to path
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.insert(0, str(PM_DIR))

from dependency_resolver import DependencyResolver


class TestReverseDependents(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def _create(self, name: str, content: str) -> Path:
        p = self.src_dir / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        return p

    # ── VHDL tests ──

    def test_vhdl_leaf_returns_parent(self):
        """Changing a leaf entity should flag its parent as affected."""
        self._create(
            "leaf.vhd",
            """\
entity leaf is end entity leaf;
""",
        )
        self._create(
            "mid.vhd",
            """\
entity mid is end entity mid;
architecture rtl of mid is
begin
    u_leaf: entity work.leaf;
end architecture;
""",
        )
        self._create(
            "top.vhd",
            """\
entity top is end entity top;
architecture rtl of top is
begin
    u_mid: entity work.mid;
end architecture;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        leaf_path = (self.src_dir / "leaf.vhd").resolve()

        deps = resolver.reverse_dependents(leaf_path)
        self.assertIn("mid", deps)
        self.assertIn("top", deps)

    def test_top_has_no_reverse_dependents(self):
        """The top-level entity has nothing depending on it."""
        self._create("leaf.vhd", "entity leaf is end entity leaf;")
        self._create(
            "top.vhd",
            """\
entity top is end entity top;
architecture rtl of top is
begin
    u_leaf: entity work.leaf;
end architecture;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        top_path = (self.src_dir / "top.vhd").resolve()

        deps = resolver.reverse_dependents(top_path)
        self.assertEqual(deps, [])

    def test_package_change_flags_users(self):
        """Changing a shared package should flag all entities that use it."""
        self._create(
            "types_pkg.vhd",
            """\
package types_pkg is end package types_pkg;
""",
        )
        self._create(
            "a.vhd",
            """\
use work.types_pkg.all;
entity a is end entity a;
""",
        )
        self._create(
            "b.vhd",
            """\
use work.types_pkg.all;
entity b is end entity b;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        pkg_path = (self.src_dir / "types_pkg.vhd").resolve()

        deps = resolver.reverse_dependents(pkg_path)
        self.assertIn("a", deps)
        self.assertIn("b", deps)

    # ── Verilog/SV tests ──

    def test_verilog_module_dependents(self):
        """Changing a Verilog sub-module should flag its parent."""
        self._create("sub.v", "module sub; endmodule")
        self._create(
            "top.v",
            """\
module top;
    sub u_sub();
endmodule
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        sub_path = (self.src_dir / "sub.v").resolve()

        deps = resolver.reverse_dependents(sub_path)
        self.assertIn("top", deps)

    def test_unknown_path_returns_empty(self):
        """A path not in the source tree should return an empty list."""
        self._create("only.vhd", "entity only is end entity only;")
        resolver = DependencyResolver([self.src_dir], verbose=False)

        deps = resolver.reverse_dependents(Path("/tmp/does_not_exist.vhd"))
        self.assertEqual(deps, [])


if __name__ == "__main__":
    unittest.main()
