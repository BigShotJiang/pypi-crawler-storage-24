# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Unit tests for scan_tests.py — the scan-tests Makefile target backend."""

import shutil
import sys
import tempfile
import unittest
from io import StringIO
from pathlib import Path

# Locate the module under test
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
TOOLS_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.insert(0, str(TOOLS_DIR))

from scan_tests import scan_tests


class TestScanTests(unittest.TestCase):
    def setUp(self):
        """Create a temporary sim/cocotb/tests tree."""
        self.test_dir = tempfile.mkdtemp(prefix="routertl_scan_test_")
        self.tests_dir = Path(self.test_dir) / "sim" / "cocotb" / "tests"
        self.tests_dir.mkdir(parents=True)

        # Redirect stdout to capture scan_tests output
        self._orig_stdout = sys.stdout
        self.captured = StringIO()
        sys.stdout = self.captured

    def tearDown(self):
        sys.stdout = self._orig_stdout
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def _output(self):
        return self.captured.getvalue()

    # ─── Discovery ───

    def test_finds_test_files(self):
        """Verify basic test file discovery."""
        (self.tests_dir / "test_foo.py").touch()
        (self.tests_dir / "test_bar.py").touch()

        scan_tests([str(self.tests_dir)])
        out = self._output()

        self.assertIn("test_foo", out)
        self.assertIn("test_bar", out)
        self.assertIn("Found 2 tests", out)

    def test_ignores_non_test_files(self):
        """Verify that helper scripts and __init__ files are excluded."""
        (self.tests_dir / "test_real.py").touch()
        (self.tests_dir / "helper.py").touch()
        (self.tests_dir / "__init__.py").touch()
        (self.tests_dir / "conftest.py").touch()

        scan_tests([str(self.tests_dir)])
        out = self._output()

        self.assertIn("test_real", out)
        self.assertNotIn("helper", out)
        self.assertNotIn("conftest", out)
        self.assertIn("Found 1 tests", out)

    # ─── Module Paths ───

    def test_subdirectory_modules_use_short_name(self):
        """Verify that nested test files show the short module name."""
        sub = self.tests_dir / "spi"
        sub.mkdir()
        (sub / "__init__.py").touch()
        (sub / "test_spi_master.py").touch()

        scan_tests([str(self.tests_dir)])
        out = self._output()

        self.assertIn("test_spi_master", out)
        self.assertIn("routertl sim test_spi_master", out)

    def test_flat_test_module_path(self):
        """Verify that top-level test files show the short module name."""
        (self.tests_dir / "test_top.py").touch()

        scan_tests([str(self.tests_dir)])
        out = self._output()

        self.assertIn("test_top", out)
        self.assertIn("routertl sim test_top", out)

    # ─── Edge Cases ───

    def test_empty_directory(self):
        """Verify graceful handling of empty test directories."""
        scan_tests([str(self.tests_dir)])
        out = self._output()

        self.assertIn("Found 0 tests", out)

    def test_nonexistent_directory(self):
        """Verify that missing directories don't crash."""
        scan_tests(["/tmp/this_does_not_exist_routertl_test_abc"])
        out = self._output()
        self.assertIn("Found 0 tests", out)

    def test_deduplication_across_dirs(self):
        """If the same directory is passed twice, tests should not duplicate."""
        (self.tests_dir / "test_unique.py").touch()

        scan_tests([str(self.tests_dir), str(self.tests_dir)])
        out = self._output()

        # Module name should appear exactly once in the output
        entries = [l for l in out.split("\n") if "test_unique" in l and "routertl sim" in l]
        self.assertEqual(len(entries), 1, f"Expected 1 entry, got {len(entries)}: {entries}")


if __name__ == "__main__":
    unittest.main()
