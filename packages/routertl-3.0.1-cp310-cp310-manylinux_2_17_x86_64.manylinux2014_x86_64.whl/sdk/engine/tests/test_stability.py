# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import shutil
import subprocess
import unittest
from pathlib import Path

# Paths
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_TOOL = REPO_ROOT / "sdk" / "engine" / "project_manager.py"
REGBANK_TOOL = REPO_ROOT / "sdk" / "generators" / "regbank" / "generate_regbank_pkg.py"


class TestStability(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path("temp_stability_test")
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.test_dir.mkdir()

    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

    def run_pm(self, config_file):
        cmd = ["python3", str(PM_TOOL), str(config_file)]
        return subprocess.run(cmd, cwd=self.test_dir, capture_output=True, text=True)

    def test_pm_missing_file(self):
        """Test project_manager.py with a non-existent file."""
        res = self.run_pm("non_existent.yml")
        # Should fail gracefully (or just warn and exit 0 depending on impl which I know returns empty dict)
        # Checking stdout for warning
        self.assertIn("Warning: non_existent.yml not found", res.stdout)
        self.assertEqual(res.returncode, 1, "Should fail on error")

    def test_pm_empty_file(self):
        """Test project_manager.py with an empty file."""
        f = self.test_dir / "empty.yml"
        f.touch()
        res = self.run_pm("empty.yml")
        # Should run without error
        self.assertEqual(res.returncode, 1, "Should fail (or warn) on empty file")

    def test_pm_invalid_yaml_syntax(self):
        """Test project_manager.py with invalid YAML syntax."""
        f = self.test_dir / "invalid.yml"
        f.write_text(": invalid: yaml")
        res = self.run_pm("invalid.yml")
        # Expect error message
        self.assertIn("Error parsing YAML file", res.stdout)
        self.assertEqual(res.returncode, 1, "Should fail on invalid YAML")

    def test_pm_list_yaml(self):
        """Test project_manager.py with a YAML list (not a dict)."""
        f = self.test_dir / "list.yml"
        f.write_text("- item1\n- item2")
        res = self.run_pm("list.yml")
        # Expect warning
        self.assertIn("Warning: list.yml is not a valid YAML dictionary", res.stdout)
        self.assertEqual(res.returncode, 1, "Should fail on list YAML")

    def test_regbank_empty(self):
        """Test generate_regbank_pkg.py with an empty register list."""
        yaml_file = (self.test_dir / "regbank.yml").resolve()
        yaml_file.write_text("name: test\nversion: 0.1\nregisters: []")
        out_pkg = (self.test_dir / "pkg.vhd").resolve()

        # We run from test_dir, but we pass absolute paths to avoid confusion
        cmd = ["python3", str(REGBANK_TOOL), str(yaml_file), str(out_pkg)]
        res = subprocess.run(cmd, cwd=self.test_dir, capture_output=True, text=True)

        self.assertEqual(res.returncode, 0, f"Generator failed: {res.stderr}")
        self.assertTrue(out_pkg.exists())
        content = out_pkg.read_text()
        self.assertIn("C_REGBANK_DEPTH   : integer := 1;", content)  # Default depth behavior

    def test_vendor_tools_defined_in_all_platform_branches(self):
        """Regression: QUARTUS_SH must be defined in every platform branch.

        Bug: The Docker branch of Common.mk only defined Vivado paths,
        leaving QUARTUS_SH undefined. When build_env.mk set
        TOOL_CMD = $(QUARTUS_SH), it resolved to empty, breaking Altera
        synthesis inside Docker containers.
        """
        platform_mk = REPO_ROOT / "sdk" / "mk" / "platform.mk"
        self.assertTrue(platform_mk.exists(), "platform.mk not found")

        content = platform_mk.read_text()

        # Verify QUARTUS_SH is defined (with ?= or :=) in the file
        # at least twice: once in Docker branch, once in native Linux
        import re

        quartus_defs = re.findall(r"QUARTUS_SH\s*\?=", content)
        self.assertGreaterEqual(
            len(quartus_defs),
            2,
            f"QUARTUS_SH must be defined in at least 2 platform branches "
            f"(Docker + Native Linux), found {len(quartus_defs)}",
        )

    def test_docker_branch_sets_sdk_has_capability_flags(self):
        """Regression (BUG-006): Docker branch must probe PATH for SDK_HAS_* flags.

        sdk_env.mk is a host-generated cache that doesn't exist inside Docker
        containers. Without PATH probes, synthesis.mk's pre-flight gates block
        with "tool not found" even when the tool IS on PATH.
        """
        platform_mk = REPO_ROOT / "sdk" / "mk" / "platform.mk"
        self.assertTrue(platform_mk.exists(), "platform.mk not found")

        content = platform_mk.read_text()

        # Extract the Docker branch (between IS_DOCKER and the next 'else ifeq')
        import re

        docker_match = re.search(
            r"ifeq\s*\(\$\(IS_DOCKER\),true\)(.*?)(?=else\s+ifeq|^endif)",
            content,
            re.DOTALL | re.MULTILINE,
        )
        self.assertIsNotNone(docker_match, "Docker branch not found in platform.mk")
        docker_block = docker_match.group(1)

        for flag in [
            "SDK_HAS_QUARTUS_SH",
            "SDK_HAS_VIVADO",
            "SDK_HAS_RADIANTC",
            "SDK_HAS_LIBERO",
        ]:
            self.assertIn(
                flag,
                docker_block,
                f"{flag} probe missing from Docker branch of platform.mk "
                f"(BUG-006 regression)",
            )


if __name__ == "__main__":
    unittest.main()
