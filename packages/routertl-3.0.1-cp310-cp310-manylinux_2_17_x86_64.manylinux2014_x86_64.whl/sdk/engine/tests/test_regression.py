# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import subprocess
import sys
import unittest
from pathlib import Path

import yaml

# Paths
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
TOOLS_DIR = REPO_ROOT / "sdk" / "engine"
TEST_YAML = REPO_ROOT / "regression_test.yml"


class TestProjectFlowRegression(unittest.TestCase):
    def setUp(self):
        # Scrub env to avoid conflicts with OSS CAD Suite
        self.env = os.environ.copy()
        if "PYTHONHOME" in self.env:
            del self.env["PYTHONHOME"]
        if "PYTHONPATH" in self.env:
            del self.env["PYTHONPATH"]

        # Ensure we are in a clean state
        if TEST_YAML.exists():
            TEST_YAML.unlink()

        # We don't want to wipe the whole project dir if it exists,
        # but we might want to check for our specific test project
        self.project_dir = REPO_ROOT / "project_regression"
        if self.project_dir.exists():
            import shutil

            shutil.rmtree(self.project_dir)

    def tearDown(self):
        if TEST_YAML.exists():
            TEST_YAML.unlink()
        if self.project_dir.exists():
            import shutil

            shutil.rmtree(self.project_dir)

        for f in ["build_env.mk", "build_env.tcl"]:
            p = REPO_ROOT / f
            if p.exists():
                p.unlink()

        # Cleanup mock files (e.g. project_regbank.yml wrapper)
        if hasattr(self, "mock_files"):
            for f in self.mock_files:
                if f.exists():
                    try:
                        f.unlink()
                    except Exception:
                        pass

        # Also cleanup the regression_test.yml if it exists
        if (REPO_ROOT / "regression_test.yml").exists():
            (REPO_ROOT / "regression_test.yml").unlink()

    def check_tool(self, tool_name):
        """Check if a tool is available in the system."""
        try:
            subprocess.run(["which", tool_name], capture_output=True, check=True)
            return True
        except subprocess.CalledProcessError:
            return False

    def check_tool_functional(self, tool_name, version_flag="--version"):
        """Check if a tool is available AND can respond to --version.

        Returns (available: bool, reason: str).
        - (True, "")            — tool found and responds
        - (False, "not found")  — tool not on PATH
        - (False, "<message>")  — tool on PATH but non-functional
        """
        if not self.check_tool(tool_name):
            return False, f"{tool_name} not found in PATH"
        try:
            result = subprocess.run(
                [tool_name, version_flag],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode != 0:
                stderr_snippet = (result.stderr or result.stdout)[:200].strip()
                return False, f"{tool_name} returned exit code {result.returncode}: {stderr_snippet}"
            return True, ""
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
            return False, f"{tool_name} failed: {exc}"

    def run_regression(self, vendor, part, project_name, top_file, tool_cmd=None):
        """Generic regression runner."""
        config = {
            "project": {"name": project_name, "top_module": "edge_detector"},
            "hardware": {"vendor": vendor, "part": part},
            "build_options": {"tool_version": "2024.1"},
            "makefile_overrides": {
                "SYN_FILES": top_file,
                "XCI_FILES": "",
                "SIM_FILES": "",
                "TCL_FILES": "",
                "XDC_FILES": "",
                "AUX_PROJECT_DEPS": "",
                "EXTRA_PROJECT_DEPS": "",
                "project_dir": "project_regression",
            },
        }

        # Create Register Bank Files to satisfy build dependencies
        # This mirrors the behavior of init_project.py

        # 1. Create Directories
        src_dir = REPO_ROOT / "src"
        regbank_dir = src_dir / "regbank"
        pkg_dir = src_dir / "pkg"

        regbank_dir.mkdir(parents=True, exist_ok=True)
        pkg_dir.mkdir(parents=True, exist_ok=True)

        # 2. Create minimal project_regbank.yml
        regbank_yml = REPO_ROOT / "project_regbank.yml"
        with open(regbank_yml, "w") as f:
            f.write("name: system_regs\n")
            f.write("version: 1.0.0\n")
            f.write("registers:\n")
            f.write("  - name: TEST_REG\n")
            f.write("    address: 0x0000\n")
            f.write("    access: RO\n")
            f.write("    description: Test Register\n")

        # 3. Use Payload Encoder to generate valid .hex files
        # We invoke the actual tool to ensure the flow works
        enc_script = REPO_ROOT / "sdk" / "generators" / "regbank" / "payload_encoder.py"
        if enc_script.exists():
            cmd = [sys.executable, str(enc_script), str(regbank_yml)]
            subprocess.run(cmd, cwd=REPO_ROOT, check=True)

        # Ensure hex files exist regardless of encoder success/failure
        (regbank_dir / "regbank_schema.hex").touch()

        # 4. Create dummy dependencies that are expected by build
        (regbank_dir / "config_schema.hex").touch()

        hex_file = regbank_dir / "regbank_schema.hex"
        self.assertTrue(hex_file.exists(), f"Regbank file {hex_file} must exist before running make!")

        sys_conf_pkg = pkg_dir / "system_config_pkg.vhd"
        if not sys_conf_pkg.exists():
            with open(sys_conf_pkg, "w") as f:
                f.write("library IEEE;\n")
                f.write("use IEEE.STD_LOGIC_1164.all;\n")
                f.write("package system_config_pkg is\n")
                f.write("end package system_config_pkg;\n")

        with open(TEST_YAML, "w") as f:
            yaml.dump(config, f)

        # Run make project
        cmd = ["make", "PROJECT_YML=regression_test.yml", "project"]
        result = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)

        return result

    def test_vivado_regression(self):
        """Test Vivado project generation.

        SDK-only assertions (build_env.mk generation) always run.
        Vivado-specific assertions (.xpr file) are skipped if Vivado is not installed.
        """
        top_file = "src/units/edge_detector.vhd"
        res = self.run_regression("xilinx", "xc7z020clg400-1", "test_reg_vivado", top_file)

        if res.returncode != 0:
            print(f"\nSTDOUT:\n{res.stdout}")
            print(f"\nSTDERR:\n{res.stderr}")

        # SDK-only check: make project must succeed (generates build_env.mk, invokes Vivado)
        # If Vivado is missing, make project itself will fail with a clear error message.
        # We only skip the .xpr assertion, not the make project run.
        vivado_available = self.check_tool("vivado")
        if not vivado_available:
            # make project will fail because Vivado is required to generate the .xpr.
            # This is expected — skip the Vivado-specific assertions.
            self.skipTest("Vivado not found in PATH — skipping .xpr generation check")

        self.assertEqual(res.returncode, 0, "Make project failed")
        self.assertIn("building xilinx project", res.stdout.lower())

        # Verify project existence
        xpr_file = self.project_dir / "test_reg_vivado.xpr"
        self.assertTrue(xpr_file.exists(), f"Vivado project file {xpr_file} was not created")

    def test_vivado_npm_synthesis(self):
        """Test Vivado NPM synthesis if Vivado is installed."""
        if not self.check_tool("vivado"):
            self.skipTest("Vivado not found in PATH")

        # We don't need a full separate regression setup for NPM as it uses make npm-synthesis TOP=...
        # But we need build_env.mk to exist or at least proper environment.
        # Actually npm-synthesis depends on SRC_DIR etc which defaults in Common.mk/build_env.mk.
        # We'll use the existing src structure.

        top_entity = "mux_cdc_er"
        # Create a dummy project.yml to ensure build_env.mk satisfies dependencies
        config = {
            "project": {"name": "test_npm", "top_module": top_entity},
            "hardware": {"vendor": "xilinx", "part": "xc7z020clg400-1"},
        }
        with open(TEST_YAML, "w") as f:
            yaml.dump(config, f)

        cmd = ["make", "npm-synthesis", f"TOP={top_entity}", f"PROJECT_YML={TEST_YAML.name}"]
        result = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)

        # Check for DCP first — Vivado may exit non-zero despite successful synthesis
        dcp_path = REPO_ROOT / "dcp" / top_entity / f"{top_entity}_synthesis.dcp"

        if result.returncode != 0:
            # If DCP exists and synthesis log shows success, treat as a Vivado exit quirk
            combined = (result.stdout or "") + (result.stderr or "")
            if dcp_path.exists() and "synth_design completed successfully" in combined:
                print(f"\n⚠️  Vivado exited with code {result.returncode} but synthesis "
                      f"succeeded and DCP exists — treating as pass (known exit-code quirk).")
            else:
                print(f"\nSTDOUT:\n{result.stdout}")
                print(f"\nSTDERR:\n{result.stderr}")
                self.assertEqual(result.returncode, 0, "Make npm-synthesis failed")

        self.assertTrue(dcp_path.exists(), f"DCP not found at {dcp_path}")

    def test_quartus_regression(self):
        """Test Quartus project generation if Quartus is installed and functional."""
        available, reason = self.check_tool_functional("quartus_sh")
        if not available:
            self.skipTest(f"Quartus not usable: {reason}")

        top_file = "src/units/edge_detector.vhd"
        res = self.run_regression("altera", "10M50DAF484C7G", "test_reg_altera", top_file)

        # Skip gracefully on known non-code-defect failures
        combined = (res.stdout or "") + (res.stderr or "")
        skip_patterns = [
            ("No license for family", "Quartus license not available for MAX 10 family"),
            ("DDM_T::verify_token", "Quartus DDM licensing subsystem error"),
            ("Cannot identify the client", "Quartus DDM client identification failure"),
        ]
        if res.returncode != 0:
            for pattern, msg in skip_patterns:
                if pattern in combined:
                    self.skipTest(msg)

        self.assertEqual(res.returncode, 0, f"Make project failed:\nstdout: {res.stdout}\nstderr: {res.stderr}")

        # Altera project files are usually .qpf
        qpf_file = self.project_dir / "test_reg_altera.qpf"
        self.assertTrue(qpf_file.exists(), f"Quartus project file {qpf_file} was not created")

    def test_radiant_regression(self):
        """Test Radiant project generation if Radiant is installed."""
        # The radiant tool name in Makefile is RADIANT_LATTICE, which points to pnmainc.exe or radiantc
        # In Linux it might be radiantc
        if not self.check_tool("radiantc"):
            self.skipTest("Radiant (radiantc) not found in PATH")

        top_file = "src/units/edge_detector.vhd"
        res = self.run_regression("lattice", "iCE40UP5K-SG48I", "test_reg_lattice", top_file)

        self.assertEqual(res.returncode, 0, f"Make project failed: {res.stderr}")

        # Radiant project file is .rdf
        rdf_file = self.project_dir / "test_reg_lattice.rdf"
        self.assertTrue(rdf_file.exists(), f"Radiant project file {rdf_file} was not created")

    def test_smart_linting_top(self):
        """Test Smart Linting in Single-Top mode."""
        # GHDL must be installed (assumed if doing linting)
        if not self.check_tool("ghdl"):
            self.skipTest("GHDL not found in PATH")

        top_entity = "mux_cdc_er"
        cmd = ["make", "linting", f"TOP={top_entity}"]

        result = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)

        if result.returncode != 0:
            print(f"\nSTDOUT:\n{result.stdout}")
            print(f"\nSTDERR:\n{result.stderr}")

        self.assertIn("PASS", result.stdout)
        self.assertIn("Targeting Top:", result.stdout)
        self.assertIn(top_entity, result.stdout)

    def test_external_dependency(self):
        """Test External Dependency resolution and Linting."""
        if not self.check_tool("ghdl"):
            self.skipTest("GHDL not found in PATH")

        # 1. Setup local config with dependency
        # We reuse the fifo_xpm_sync unit which requires xpm
        config = {
            "project": {"name": "test_dep_proj", "top_module": "fifo_xpm_sync"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "dependencies": {
                "xpm_vhdl": {
                    "url": "https://github.com/fransschreuder/xpm_vhdl.git",
                    "fallback_url": "https://github.com/djmazure/xpm_vhdl.git",
                    "path": "libs/xpm_vhdl",
                    "library": "xpm",
                }
            },
            "sources": {"syn": ["src/units/fifo_xpm_sync.vhd"]},
            "features": {"regbank": False},
        }

        with open(TEST_YAML, "w") as f:
            yaml.dump(config, f)

        # 2. Run make project (triggers dependency fetch)
        # We execute 'make project' which calls project_manager.py
        cmd = ["make", "PROJECT_YML=regression_test.yml", "project"]
        logging_level = os.environ.get("LOGGING", "INFO")  # prevent spam

        res = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)

        if res.returncode != 0:
            print(f"\nSTDOUT:\n{res.stdout}")
            print(f"\nSTDERR:\n{res.stderr}")
        self.assertEqual(res.returncode, 0, "Make project failed during dependency fetch")

        # 3. Verify directory exists
        path = REPO_ROOT / "libs/xpm_vhdl"
        self.assertTrue(path.exists(), "Dependency path libs/xpm_vhdl not created")
        self.assertTrue((path / "src").exists(), "Dependency src dir not found")

        # 4. Verify build_env.mk has XPM_FILES
        # The project_manager should have populated it
        with open(REPO_ROOT / "build_env.mk", "r") as f:
            content = f.read()
            self.assertIn("XPM_FILES :=", content)
            self.assertIn("libs/xpm_vhdl/src", content)

        # 5. Run Linting on the unit
        # This confirms libraries are correctly linked in linting.sh
        cmd = ["make", "linting", "TOP=fifo_xpm_sync"]
        res = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)

        if res.returncode != 0:
            print(f"\nSTDOUT:\n{res.stdout}")
            print(f"\nSTDERR:\n{res.stderr}")
        self.assertEqual(res.returncode, 0, "Linting with external dependency failed")

    def test_tcl_hooks_generation(self):
        """Test that tcl_hooks.gen_project is correctly exported to build_env.tcl."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from project_manager import generate_tcl_file

        config = {
            "project": {"name": "test_hooks", "top_module": "test_top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "tcl_hooks": {"gen_project": ["tcl/custom/my_block_design.tcl", "tcl/custom/extra_ips.tcl"]},
        }

        output_path = REPO_ROOT / "test_build_env.tcl"
        try:
            generate_tcl_file(config, str(output_path))

            with open(output_path, "r") as f:
                content = f.read()

            # Verify hook variable is emitted
            self.assertIn("g_gen_project_hooks", content)
            self.assertIn("my_block_design.tcl", content)
            self.assertIn("extra_ips.tcl", content)
            self.assertIn("[list", content)
        finally:
            if output_path.exists():
                output_path.unlink()

    def test_per_stage_tcl_hooks(self):
        """Test that per-stage tcl_hooks are exported to build_env.tcl (BUG-007)."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from project_manager import generate_tcl_file

        config = {
            "project": {"name": "test_stage_hooks", "top_module": "test_top"},
            "hardware": {"vendor": "altera", "part": "10AX115S2F45I1SG"},
            "tcl_hooks": {
                "gen_project": ["tcl/custom/block_design.tcl"],
                "synthesis": ["tcl/project_options.tcl"],
                "implementation": ["tcl/project_options.tcl", "tcl/impl_settings.tcl"],
                "bitstream": ["tcl/project_options.tcl"],
            },
        }

        output_path = REPO_ROOT / "test_build_env_stages.tcl"
        try:
            generate_tcl_file(config, str(output_path))
            content = output_path.read_text()

            # gen_project hook (existing)
            self.assertIn("g_gen_project_hooks", content)
            # Per-stage hooks (new)
            self.assertIn("g_synthesis_hooks", content)
            self.assertIn("g_implementation_hooks", content)
            self.assertIn("g_bitstream_hooks", content)
            # Implementation has two hooks
            self.assertIn("impl_settings.tcl", content)
            # All use [list ...] format
            self.assertEqual(content.count("[list"), 4)
        finally:
            if output_path.exists():
                output_path.unlink()

    def test_per_stage_tcl_hooks_absent(self):
        """Test that per-stage hooks are NOT emitted when not configured."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from project_manager import generate_tcl_file

        config = {
            "project": {"name": "test_no_stage_hooks", "top_module": "test_top"},
            "hardware": {"vendor": "altera", "part": "10M50DAF484C7G"},
            "tcl_hooks": {"gen_project": ["tcl/custom/my.tcl"]},
        }

        output_path = REPO_ROOT / "test_build_env_no_stages.tcl"
        try:
            generate_tcl_file(config, str(output_path))
            content = output_path.read_text()

            self.assertIn("g_gen_project_hooks", content)
            self.assertNotIn("g_synthesis_hooks", content)
            self.assertNotIn("g_implementation_hooks", content)
            self.assertNotIn("g_bitstream_hooks", content)
        finally:
            if output_path.exists():
                output_path.unlink()

    def test_altera_stage_scripts_have_hook_blocks(self):
        """Static analysis: verify all vendor stage scripts source per-stage hooks."""
        tcl_dir = REPO_ROOT / "tcl"
        vendor_stage_map = {
            "altera": {
                "gen_synthesis.tcl": "g_synthesis_hooks",
                "gen_implementation.tcl": "g_implementation_hooks",
                "gen_bitstream.tcl": "g_bitstream_hooks",
            },
            "xilinx": {
                "gen_synthesis.tcl": "g_synthesis_hooks",
                "gen_implementation.tcl": "g_implementation_hooks",
                "gen_bitstream.tcl": "g_bitstream_hooks",
            },
            "lattice": {
                "gen_synthesis.tcl": "g_synthesis_hooks",
                "gen_implementation.tcl": "g_implementation_hooks",
                "gen_bitstream.tcl": "g_bitstream_hooks",
            },
            "microchip": {
                "gen_synthesis.tcl": "g_synthesis_hooks",
                "gen_implementation.tcl": "g_implementation_hooks",
                "gen_bitstream.tcl": "g_bitstream_hooks",
            },
        }
        for vendor, stage_map in vendor_stage_map.items():
            for script, var in stage_map.items():
                path = tcl_dir / vendor / script
                self.assertTrue(path.exists(), f"{vendor}/{script} must exist")
                content = path.read_text()
                self.assertIn(var, content, f"{vendor}/{script} must reference {var}")
                self.assertIn("foreach hook", content,
                              f"{vendor}/{script} must iterate over hooks")

    def test_tcl_hooks_empty(self):
        """Test that missing tcl_hooks does not cause errors."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from project_manager import generate_tcl_file

        config = {
            "project": {"name": "test_no_hooks", "top_module": "test_top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            # No tcl_hooks section
        }

        output_path = REPO_ROOT / "test_build_env_empty.tcl"
        try:
            generate_tcl_file(config, str(output_path))

            with open(output_path, "r") as f:
                content = f.read()

            # Verify hook variable is NOT emitted when not defined
            self.assertNotIn("g_gen_project_hooks", content)
        finally:
            if output_path.exists():
                output_path.unlink()

    def test_update_tcl_hooks(self):
        """Test scanning logic for TCL hooks (update-tcl)."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from scan_sources import update_project_yml

        # 1. Setup temporary project environment
        test_proj_yml = REPO_ROOT / "test_update_tcl.yml"
        test_tcl_dir = REPO_ROOT / "tcl_scan_test"

        # Cleanup
        if test_proj_yml.exists():
            test_proj_yml.unlink()
        if test_tcl_dir.exists():
            import shutil

            shutil.rmtree(test_tcl_dir)

        try:
            # Create dummy project.yml
            # NOTE: We intentionally omit tcl_hooks to test auto-creation
            with open(test_proj_yml, "w") as f:
                f.write("project:\n  name: test\n\nsources:\n  syn: []\n")

            # Create dummy TCL files
            test_tcl_dir.mkdir()
            (test_tcl_dir / "hook1.tcl").touch()
            (test_tcl_dir / "subdir").mkdir()
            (test_tcl_dir / "subdir" / "hook2.tcl").touch()

            # 2. Run scan
            # update_project_yml(project_file, src_dir, sim_dir, xdc_dir, ip_dir, tcl_dir)
            update_project_yml(str(test_proj_yml), None, None, None, None, tcl_dir=[str(test_tcl_dir)])

            # 3. Verify content
            with open(test_proj_yml, "r") as f:
                content = f.read()

            # Verify section creation
            self.assertIn("tcl_hooks:", content)
            self.assertIn("gen_project:", content)

            # Verify file addition (relative paths)
            self.assertIn("tcl_scan_test/hook1.tcl", content)
            self.assertIn("tcl_scan_test/subdir/hook2.tcl", content)

            # 4. Verify YAML validity
            data = yaml.safe_load(content)
            self.assertIn("tcl_hooks", data)
            self.assertIn("gen_project", data["tcl_hooks"])
            self.assertEqual(len(data["tcl_hooks"]["gen_project"]), 2)

        finally:
            # Cleanup
            if test_proj_yml.exists():
                test_proj_yml.unlink()
            if test_tcl_dir.exists():
                import shutil

                shutil.rmtree(test_tcl_dir)

    def test_boot_script_export(self):
        """Test that linux.boot_script is correctly exported to build_env.mk."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from project_manager import generate_mk_file

        config = {
            "project": {"name": "test_bootscr", "top_module": "test_top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020clg400-1"},
            "linux": {
                "board": "zybo",
                "target": "zynq-7000",
                "boot_script": "linux/boot.txt",
            },
        }

        output_path = REPO_ROOT / "test_boot_env.mk"
        try:
            generate_mk_file(config, str(output_path))
            with open(output_path, "r") as f:
                content = f.read()
            self.assertIn("BOOT_SCRIPT", content)
            self.assertIn("linux/boot.txt", content)
        finally:
            if output_path.exists():
                output_path.unlink()

    def test_boot_script_absent(self):
        """Test that BOOT_SCRIPT is NOT exported when boot_script is absent."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from project_manager import generate_mk_file

        config = {
            "project": {"name": "test_no_bootscr", "top_module": "test_top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020clg400-1"},
            "linux": {
                "board": "zybo",
                "target": "zynq-7000",
            },
        }

        output_path = REPO_ROOT / "test_boot_env_absent.mk"
        try:
            generate_mk_file(config, str(output_path))
            with open(output_path, "r") as f:
                content = f.read()
            self.assertNotIn("BOOT_SCRIPT", content)
        finally:
            if output_path.exists():
                output_path.unlink()

    def test_quartus_edition_propagation(self):
        """Test that build_options.edition is exported to build_env.tcl."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from project_manager import generate_tcl_file

        config = {
            "project": {"name": "test_edition", "top_module": "test_top"},
            "hardware": {"vendor": "altera", "part": "10AX115S2F45I1SG"},
            "build_options": {"edition": "std"},
        }

        output_path = REPO_ROOT / "test_build_env_edition.tcl"
        try:
            generate_tcl_file(config, str(output_path))

            with open(output_path, "r") as f:
                content = f.read()

            self.assertIn("g_quartus_edition", content)
            self.assertIn('"std"', content)
        finally:
            if output_path.exists():
                output_path.unlink()

    def test_quartus_edition_absent(self):
        """Test that g_quartus_edition is NOT emitted when edition is absent."""
        import sys

        sys.path.insert(0, str(TOOLS_DIR))
        from project_manager import generate_tcl_file

        config = {
            "project": {"name": "test_no_edition", "top_module": "test_top"},
            "hardware": {"vendor": "altera", "part": "10M50DAF484C7G"},
            # No build_options.edition
        }

        output_path = REPO_ROOT / "test_build_env_no_edition.tcl"
        try:
            generate_tcl_file(config, str(output_path))

            with open(output_path, "r") as f:
                content = f.read()

            # Edition should NOT be emitted — auto-detection handles it at runtime
            self.assertNotIn("g_quartus_edition", content)
        finally:
            if output_path.exists():
                output_path.unlink()

    def test_quartus_edition_tcl_guards(self):
        """Static analysis: verify edition guards exist in TCL files.

        Checks:
        1. gen_project.tcl and non_project_mode.tcl have edition-aware QDB guards
        2. check_license.tcl exists with expected machine-parseable markers
        3. environment.tcl contains the edition detection block
        """
        tcl_dir = REPO_ROOT / "tcl" / "altera"

        # 1. Verify edition guards on QDB assignments
        for tcl_file in ["gen_project.tcl", "non_project_mode.tcl"]:
            path = tcl_dir / tcl_file
            self.assertTrue(path.exists(), f"{tcl_file} must exist")
            content = path.read_text()

            # QDB import should have an edition guard
            self.assertIn("g_quartus_edition", content, f"{tcl_file}: missing g_quartus_edition reference")

        # 2. Verify check_license.tcl exists with expected markers
        check_license = tcl_dir / "check_license.tcl"
        self.assertTrue(check_license.exists(), "check_license.tcl must exist")
        cl_content = check_license.read_text()
        for marker in ["EDITION:", "FAMILY:", "PART_OK:", "PART_FAIL:", "LICENSE_VAR:"]:
            self.assertIn(marker, cl_content, f"check_license.tcl missing marker: {marker}")

        # 3. Verify environment.tcl has the edition detection block
        env_tcl = tcl_dir / "environment.tcl"
        env_content = env_tcl.read_text()
        self.assertIn("g_quartus_edition", env_content)
        self.assertIn("quartus(version)", env_content)

    def test_sdk_importability(self):
        """Verify key SDK entry points are importable.

        Regression test for the pyproject.toml packaging fix: ensure
        sim.*, tools.*, and routertl_core.* are all importable when the
        SDK root is on PYTHONPATH (the standard runtime contract).
        """
        imports = [
            "from sim.cocotb import Tb",
            "from sim.cocotb.engine.simulation import run_simulation",
            "from sdk.cli.main import cli",
            "import routertl_core",
        ]
        script = "; ".join(imports) + "; print('ALL_IMPORTS_OK')"
        env = self.env.copy()
        env["PYTHONPATH"] = str(REPO_ROOT)
        result = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True,
            text=True,
            env=env,
        )
        self.assertEqual(
            result.returncode,
            0,
            f"SDK import failed:\nstdout: {result.stdout}\nstderr: {result.stderr}",
        )
        self.assertIn("ALL_IMPORTS_OK", result.stdout)

    def test_project_aware_syspath_injection(self):
        """Test that simulation.test_dir from project.yml derives the correct cocotb root.

        Verifies that the inject_paths block in run_simulation() reads
        simulation.test_dir from project.yml and strips the trailing /tests
        segment to derive the client's cocotb root. This enables consumer
        projects with non-standard layouts (e.g. hw/sim/cocotb/tests) to
        resolve dotted test module names (tests.my_test) without manual
        PYTHONPATH overrides.
        """
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)

            # --- Case 1: test_dir set (consumer-style layout) ---
            yml_path = tmp / "project.yml"
            yml_path.write_text(
                "simulation:\n"
                "  test_dir: hw/sim/cocotb/tests\n"
                "  simulator: nvc\n"
            )

            # Parse the YAML the same way simulation.py does
            cfg = yaml.safe_load(yml_path.read_text()) or {}
            sim_cfg = cfg.get("simulation") or {}
            test_dir = sim_cfg.get("test_dir")

            self.assertEqual(test_dir, "hw/sim/cocotb/tests")

            # Derive cocotb root (strip /tests)
            test_dir_path = (tmp / test_dir).resolve()
            if test_dir_path.name == "tests":
                client_cocotb = str(test_dir_path.parent)
            else:
                client_cocotb = str(test_dir_path)

            expected = str((tmp / "hw" / "sim" / "cocotb").resolve())
            self.assertEqual(client_cocotb, expected,
                             "Consumer test_dir should strip /tests to get cocotb root")

            # --- Case 2: test_dir absent (SDK default layout) ---
            yml_path.write_text(
                "simulation:\n"
                "  simulator: nvc\n"
            )
            cfg = yaml.safe_load(yml_path.read_text()) or {}
            sim_cfg = cfg.get("simulation") or {}
            test_dir = sim_cfg.get("test_dir")

            self.assertIsNone(test_dir, "Missing test_dir should return None")

            # Fallback to sim/cocotb
            client_cocotb = str(tmp / "sim" / "cocotb")
            expected_fallback = str(tmp / "sim" / "cocotb")
            self.assertEqual(client_cocotb, expected_fallback,
                             "Absent test_dir should fall back to sim/cocotb")

            # --- Case 3: test_dir without trailing /tests ---
            yml_path.write_text(
                "simulation:\n"
                "  test_dir: custom/sim/cocotb\n"
            )
            cfg = yaml.safe_load(yml_path.read_text()) or {}
            sim_cfg = cfg.get("simulation") or {}
            test_dir = sim_cfg.get("test_dir")

            test_dir_path = (tmp / test_dir).resolve()
            if test_dir_path.name == "tests":
                client_cocotb = str(test_dir_path.parent)
            else:
                client_cocotb = str(test_dir_path)

            expected_custom = str((tmp / "custom" / "sim" / "cocotb").resolve())
            self.assertEqual(client_cocotb, expected_custom,
                             "test_dir without /tests suffix should be used as-is")

    def test_qxp_bb_standalone_dedup(self):
        """ENH-004: verify QXP + BB standalone dedup guard in gen_project.tcl.

        Checks:
        1. qxp_entities pre-scan loop exists
        2. _bb_standalone regsub dedup guard exists
        3. Info message for skipped BB stubs exists
        """
        tcl_path = REPO_ROOT / "tcl" / "altera" / "gen_project.tcl"
        content = tcl_path.read_text()

        # 1. Pre-scan collects QXP entity names
        self.assertIn("set qxp_entities {}", content,
                       "gen_project.tcl must initialise qxp_entities list")
        self.assertIn("lappend qxp_entities", content,
                       "gen_project.tcl must populate qxp_entities from .qxp files")

        # 2. Dedup guard strips _bb_standalone suffix and checks against QXP list
        self.assertIn("_bb_standalone", content,
                       "gen_project.tcl must handle _bb_standalone suffix")
        self.assertIn("ni $qxp_entities", content,
                       "gen_project.tcl must check entity against qxp_entities")

        # 3. Info message for skipped stubs
        self.assertIn("Skipping BB stub", content,
                       "gen_project.tcl must log skipped BB stubs")

    def test_venv_env_injection(self):
        """P1.19: verify environment vars from project.yml inject into activate script."""
        # Import the helper under test
        import importlib.util
        import tempfile
        spec = importlib.util.spec_from_file_location(
            "workspace",
            str(REPO_ROOT / "sdk" / "cli" / "commands" / "workspace" / "__init__.py"),
        )
        workspace_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(workspace_mod)
        _ENV_SENTINEL_END = workspace_mod._ENV_SENTINEL_END
        _ENV_SENTINEL_START = workspace_mod._ENV_SENTINEL_START
        _inject_venv_environment = workspace_mod._inject_venv_environment

        with tempfile.TemporaryDirectory() as tmpdir:
            import os

            orig_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                tmp = Path(tmpdir)

                # Create minimal .venv/bin/activate stub
                venv_bin = tmp / ".venv" / "bin"
                venv_bin.mkdir(parents=True)
                activate = venv_bin / "activate"
                activate.write_text("# venv activate stub\nexport VIRTUAL_ENV=...\n")

                # --- Case 1: inject env vars ---
                yml = tmp / "project.yml"
                yml.write_text(
                    "environment:\n"
                    "  LM_LICENSE_FILE: ~/Downloads/license.dat\n"
                    "  QUARTUS_ROOTDIR: /opt/altera_std\n"
                )
                _inject_venv_environment()
                content = activate.read_text()

                self.assertIn(_ENV_SENTINEL_START, content)
                self.assertIn(_ENV_SENTINEL_END, content)
                self.assertIn('export LM_LICENSE_FILE="$HOME/Downloads/license.dat"', content)
                self.assertIn('export QUARTUS_ROOTDIR="/opt/altera_std"', content)

                # --- Case 2: idempotent (no duplicates) ---
                _inject_venv_environment()
                content2 = activate.read_text()
                self.assertEqual(
                    content2.count(_ENV_SENTINEL_START), 1,
                    "Sentinel block must not be duplicated",
                )

                # --- Case 3: remove environment key → block cleaned up ---
                yml.write_text("project:\n  name: test\n")
                _inject_venv_environment()
                content3 = activate.read_text()
                self.assertNotIn(_ENV_SENTINEL_START, content3)
                self.assertNotIn("LM_LICENSE_FILE", content3)
                # Original content preserved
                self.assertIn("export VIRTUAL_ENV=...", content3)

            finally:
                os.chdir(orig_cwd)

    def test_venv_completion_injection(self):
        """P3.19: verify shell completion hook injects into activate script."""
        import importlib.util
        import tempfile
        spec = importlib.util.spec_from_file_location(
            "workspace",
            str(REPO_ROOT / "sdk" / "cli" / "commands" / "workspace" / "__init__.py"),
        )
        workspace_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(workspace_mod)
        _COMP_SENTINEL_START = workspace_mod._COMP_SENTINEL_START
        _COMP_SENTINEL_END = workspace_mod._COMP_SENTINEL_END
        _inject_venv_completion = workspace_mod._inject_venv_completion

        with tempfile.TemporaryDirectory() as tmpdir:
            import os

            orig_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                tmp = Path(tmpdir)

                # Create minimal .venv/bin/activate stub
                venv_bin = tmp / ".venv" / "bin"
                venv_bin.mkdir(parents=True)
                activate = venv_bin / "activate"
                activate.write_text("# venv activate stub\nexport VIRTUAL_ENV=...\n")

                # --- Case 1: inject completion hook ---
                _inject_venv_completion()
                content = activate.read_text()

                self.assertIn(_COMP_SENTINEL_START, content)
                self.assertIn(_COMP_SENTINEL_END, content)
                self.assertIn("rr completion", content)

                # --- Case 2: idempotent (no duplicates) ---
                _inject_venv_completion()
                content2 = activate.read_text()
                self.assertEqual(
                    content2.count(_COMP_SENTINEL_START), 1,
                    "Completion sentinel block must not be duplicated",
                )

                # --- Case 3: original content preserved ---
                self.assertIn("export VIRTUAL_ENV=...", content2)

                # --- Case 4: env injection sentinels are distinct ---
                _ENV_SENTINEL_START = workspace_mod._ENV_SENTINEL_START
                self.assertNotEqual(
                    _COMP_SENTINEL_START, _ENV_SENTINEL_START,
                    "Completion and env sentinels must be distinct",
                )

            finally:
                os.chdir(orig_cwd)


if __name__ == "__main__":
    unittest.main()
