# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Regression tests for the routertl_core package separation.

These tests guard against bugs introduced when moving crown-jewel modules
from sdk/engine/ into routertl_core/.  Each test covers an
exact failure scenario that was hit during the initial separation.
"""

import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

# Ensure imports resolve from repo root
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


class TestVendorDbResolution(unittest.TestCase):
    """Guard: project_manager must find supported_vendors.yml after move."""

    def test_tool_cmd_present_in_generated_build_env(self):
        """Regression: TOOL_CMD must appear in generated build_env.mk.

        Bug: After moving project_manager.py to routertl_core/, the
        supported_vendors.yml lookup used __file__ (now routertl_core/)
        instead of sdk/engine/, causing a silent miss.
        Without TOOL_CMD, synthesis.mk defaulted to bare 'vivado',
        which opened the GUI instead of running in batch mode.
        """
        from routertl_core.project_manager import generate_mk_file

        config = {
            "project": {"name": "test_proj", "top_module": "top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020clg400-1"},
        }

        with tempfile.NamedTemporaryFile(mode="w", suffix=".mk", delete=False) as f:
            out_path = f.name

        try:
            generate_mk_file(config, out_path)
            with open(out_path) as f:
                content = f.read()

            self.assertIn(
                "TOOL_CMD",
                content,
                "TOOL_CMD missing from build_env.mk — "
                "supported_vendors.yml lookup is broken",
            )
            self.assertIn(
                "VIVADO_XLNX",
                content,
                "TOOL_CMD should reference $(VIVADO_XLNX) for xilinx vendor",
            )
        finally:
            os.unlink(out_path)

    def test_tool_cmd_quartus_for_altera(self):
        """Altera vendor should produce TOOL_CMD = $(QUARTUS_SH)."""
        from routertl_core.project_manager import generate_mk_file

        config = {
            "project": {"name": "test_proj", "top_module": "top"},
            "hardware": {"vendor": "altera", "part": "10M50DAF484C7G"},
        }

        with tempfile.NamedTemporaryFile(mode="w", suffix=".mk", delete=False) as f:
            out_path = f.name

        try:
            generate_mk_file(config, out_path)
            with open(out_path) as f:
                content = f.read()

            self.assertIn("TOOL_CMD", content)
            self.assertIn("QUARTUS_SH", content)
        finally:
            os.unlink(out_path)

    def test_supported_vendors_yml_exists(self):
        """Guard: supported_vendors.yml must exist where project_manager expects it."""
        pm_dir = REPO_ROOT / "sdk" / "engine"
        vendor_yml = pm_dir / "supported_vendors.yml"
        self.assertTrue(
            vendor_yml.exists(),
            f"supported_vendors.yml not found at {vendor_yml} — "
            "project_manager.py won't generate TOOL_CMD",
        )


class TestProxyModuleContracts(unittest.TestCase):
    """Guard: proxy scripts must be able to call main() on core modules."""

    def test_dependency_resolver_has_main(self):
        """Regression: dependency_resolver.py must export main().

        Bug: The original code had inline 'if __name__' logic without
        a main() function.  The proxy script called _mod.main() which
        raised AttributeError.
        """
        from routertl_core import dependency_resolver

        self.assertTrue(
            hasattr(dependency_resolver, "main"),
            "dependency_resolver must have a main() function for proxy calls",
        )
        self.assertTrue(
            callable(dependency_resolver.main),
            "dependency_resolver.main must be callable",
        )

    def test_all_core_modules_importable(self):
        """All 4 core modules must be importable from routertl_core."""
        modules = [
            "routertl_core.dependency_resolver",
            "routertl_core.smart_linter",
            "routertl_core.scan_sources",
            "routertl_core.project_manager",
        ]
        for mod_name in modules:
            with self.subTest(module=mod_name):
                mod = importlib.import_module(mod_name)
                self.assertIsNotNone(mod)

    def test_proxy_reexports_private_names(self):
        """Regression: proxies must re-export _private names.

        Bug: 'from X import *' skips names starting with '_'.  Tests
        that imported _partition_files from smart_linter broke.
        """
        # Import via the proxy path (sdk/engine/)
        pm_dir = str(REPO_ROOT / "sdk" / "engine")
        if pm_dir not in sys.path:
            sys.path.insert(0, pm_dir)

        import smart_linter as proxy_sl

        # _partition_files is a private function that tests import
        self.assertTrue(
            hasattr(proxy_sl, "_partition_files"),
            "Proxy must re-export _partition_files (private name)",
        )

    def test_proxy_scripts_exist_at_original_locations(self):
        """Backward-compat: proxy .py files must still exist in sdk/engine/."""
        pm_dir = REPO_ROOT / "sdk" / "engine"
        for name in [
            "dependency_resolver.py",
            "smart_linter.py",
            "scan_sources.py",
            "project_manager.py",
        ]:
            with self.subTest(file=name):
                self.assertTrue(
                    (pm_dir / name).exists(),
                    f"Proxy {name} missing from {pm_dir}",
                )


class TestDoctorMockTargets(unittest.TestCase):
    """Guard: check_vendor_tool must use resolve_tool_binary, not _which."""

    def test_check_vendor_tool_calls_resolve_tool_binary(self):
        """Regression: doctor's check_vendor_tool must use license.resolve_tool_binary.

        Bug: Tests mocked doctor._which but the code switched to
        license.resolve_tool_binary. The mocks patched the wrong function,
        so the test saw 'ok' instead of 'warn'.
        """
        import inspect

        from sdk.cli.checks.vendor_tools import check_vendor_tool

        source = inspect.getsource(check_vendor_tool)
        self.assertIn(
            "resolve_tool_binary",
            source,
            "check_vendor_tool must call resolve_tool_binary, not _which",
        )
        # Ensure _which is NOT used for tool resolution
        # (it may still exist for other purposes, but check_vendor_tool
        #  should use the license module's resolver)
        self.assertNotIn(
            "_which(binary)",
            source,
            "check_vendor_tool should NOT call _which(binary) directly",
        )


if __name__ == "__main__":
    unittest.main()
