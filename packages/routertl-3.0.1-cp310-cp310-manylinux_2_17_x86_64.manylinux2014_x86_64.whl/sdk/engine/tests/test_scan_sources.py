# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

# Locate the script to test
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
TOOLS_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.append(str(TOOLS_DIR))

# Import the module under test
import scan_sources


class TestScanSources(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory
        self.test_dir = tempfile.mkdtemp()
        self.project_file = os.path.join(self.test_dir, "project.yml")
        self.src_dir = os.path.join(self.test_dir, "src")
        self.sim_dir = os.path.join(self.test_dir, "sim")

        os.makedirs(self.src_dir)
        os.makedirs(self.sim_dir)

        # Create a basic project.yml
        with open(self.project_file, "w") as f:
            f.write("project:\n")
            f.write("  name: test_proj\n")
            f.write("sources:\n")
            f.write("  syn:\n")
            f.write("    - existing_file.vhd\n")
            f.write("  sim:\n")
            f.write("    # A comment here\n")

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_add_syn_files(self):
        # Create dummy source files
        Path(self.src_dir, "new_file.vhd").touch()
        Path(self.src_dir, "ignored.txt").touch()
        # Create the 'existing' file so it's not removed by stale entry check
        Path(self.test_dir, "existing_file.vhd").touch()

        # Run update
        scan_sources.update_project_yml(self.project_file, [self.src_dir], None, None, None)

        with open(self.project_file, "r") as f:
            content = f.read()

        self.assertIn("- src/new_file.vhd", content)
        self.assertNotIn("ignored.txt", content)
        self.assertIn("existing_file.vhd", content)  # Preserved

    def test_add_sim_files(self):
        # Create dummy sim files
        Path(self.sim_dir, "tb_test.vhd").touch()
        Path(self.sim_dir, "other.vhd").touch()  # Should be filtered out by prefix check if run via script main,
        # BUT update_project_yml logic itself does filtering based on arguments.
        # Wait, the main() function in script calls update_project_yml with args.
        # inside scan_sources.py:
        # update_project_yml calls get_source_files(full_sim, prefix_filter="tb_")

        scan_sources.update_project_yml(self.project_file, None, [self.sim_dir], None, None)

        with open(self.project_file, "r") as f:
            content = f.read()

        self.assertIn("- sim/tb_test.vhd", content)
        self.assertNotIn("other.vhd", content)  # verify filtering of non-tb files in sim dir

    def test_idempotency(self):
        # Add file
        Path(self.src_dir, "file.v").touch()

        # Run once
        scan_sources.update_project_yml(self.project_file, [self.src_dir], None, None, None)
        with open(self.project_file, "r") as f:
            content_pass1 = f.read()

        self.assertEqual(content_pass1.count("src/file.v"), 1)

        # Run twice
        scan_sources.update_project_yml(self.project_file, [self.src_dir], None, None, None)
        with open(self.project_file, "r") as f:
            content_pass2 = f.read()

        self.assertEqual(content_pass2.count("src/file.v"), 1)  # Should still be 1

    def test_missing_sections(self):
        # Create project.yml WITHOUT sim section
        with open(self.project_file, "w") as f:
            f.write("project:\n  name: p\nsources:\n  syn:\n")

        Path(self.sim_dir, "tb_foo.v").touch()

        # Should gracefully handle missing section (log warning, not crash)
        # Note: current implementation prints warning and skips
        scan_sources.update_project_yml(self.project_file, None, [self.sim_dir], None, None)

        with open(self.project_file, "r") as f:
            content = f.read()

        # Since implementation skips if section is missing, we verify it didn't crash
        # and didn't add the file
        # and didn't add the file
        self.assertNotIn("tb_foo.v", content)

    def test_empty_list_expansion(self):
        """Test that 'syn: []' is correctly expanded to block style."""
        # Setup specific case with []
        with open(self.project_file, "w") as f:
            f.write("project:\n  name: t\nsources:\n  syn: []\n")

        Path(self.src_dir, "new.vhd").touch()
        scan_sources.update_project_yml(self.project_file, [self.src_dir], None, None, None)

        with open(self.project_file, "r") as f:
            content = f.read()

        # Should NOT contain 'syn: []' anymore
        self.assertNotIn("syn: []", content)
        # Should contain syn: and - src/new.vhd
        self.assertIn("syn:\n", content)
        self.assertIn("- src/new.vhd", content)

    def test_full_integrated_flow(self):
        """Test full workflow: create with [], update src, sim, and xdc sequentially."""
        # 1. Create initial Project with empty lists
        with open(self.project_file, "w") as f:
            f.write("project:\n  name: full_test\nsources:\n  syn: []\n  sim: []\n  xdc: []\n")

        # 2. Create files
        Path(self.src_dir, "rtl.vhd").touch()
        Path(self.sim_dir, "tb_top.vhd").touch()
        xdc_dir = os.path.join(self.test_dir, "xdc")
        os.makedirs(xdc_dir, exist_ok=True)
        Path(xdc_dir, "pins.xdc").touch()

        # 3. Update SRC (mimic 'make update-src')
        scan_sources.update_project_yml(self.project_file, [self.src_dir], None, None, None)
        with open(self.project_file, "r") as f:
            c1 = f.read()
        self.assertNotIn("syn: []", c1)
        self.assertIn("- src/rtl.vhd", c1)
        self.assertIn("sim: []", c1)  # Sim untouched

        # 4. Update SIM (mimic 'make update-sim')
        scan_sources.update_project_yml(self.project_file, None, [self.sim_dir], None, None)
        with open(self.project_file, "r") as f:
            c2 = f.read()
        self.assertNotIn("sim: []", c2)
        self.assertIn("- sim/tb_top.vhd", c2)
        self.assertIn("xdc: []", c2)  # XDC untouched

        # 5. Update XDC (mimic 'make update-xdc')
        scan_sources.update_project_yml(self.project_file, None, None, [xdc_dir], None)
        with open(self.project_file, "r") as f:
            c3 = f.read()
        self.assertNotIn("xdc: []", c3)
        self.assertIn("- xdc/pins.xdc", c3)

        # 6. Sanity check: ensure no content was lost or corrupted
        self.assertIn("- src/rtl.vhd", c3)
        self.assertIn("- sim/tb_top.vhd", c3)


if __name__ == "__main__":
    unittest.main()
