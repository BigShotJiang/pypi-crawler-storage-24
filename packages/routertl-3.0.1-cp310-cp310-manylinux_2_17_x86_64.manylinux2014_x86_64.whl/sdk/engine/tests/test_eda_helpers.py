# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for EDA helper functions.

Unit tests for the shared logic in sdk/cli/eda_helpers.py:
- Version compatibility checking
- Device family scanning
- Patch ZIP discovery
- QDZ extraction
"""

import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

# ── sys.path setup ──
TESTS_DIR = Path(__file__).resolve().parent
PROJECT_MANAGER_DIR = TESTS_DIR.parent
TOOLS_DIR = PROJECT_MANAGER_DIR.parent
SDK_ROOT = TOOLS_DIR.parent
sys.path.insert(0, str(SDK_ROOT))

from sdk.cli.eda_helpers import (
    check_version_compat,
    detect_tool,
    extract_qdz,
    find_patch_zips,
    load_sdk_requirements,
    scan_device_families,
)


class TestCheckVersionCompat(unittest.TestCase):
    """Test version and edition compatibility checking."""

    def test_matching_version_and_edition(self):
        """No warning when everything matches."""
        result = check_version_compat("23.1", "std", "arria10-23.1std.0.991.qdz")
        self.assertIsNone(result)

    def test_version_mismatch(self):
        """Warn when version differs."""
        result = check_version_compat("25.3", "pro", "arria10-23.1pro.0.991.qdz")
        self.assertIsNotNone(result)
        self.assertIn("version", result)

    def test_edition_mismatch(self):
        """Warn when edition differs (pro vs std)."""
        result = check_version_compat("23.1", "pro", "arria10-23.1std.0.991.qdz")
        self.assertIsNotNone(result)
        self.assertIn("edition", result)

    def test_both_mismatch(self):
        """Warn on both version and edition mismatch."""
        result = check_version_compat("25.3", "pro", "arria10-23.1std.0.991.qdz")
        self.assertIsNotNone(result)
        self.assertIn("version", result)
        self.assertIn("edition", result)

    def test_unknown_filename_skips(self):
        """No warning when filename can't be parsed."""
        result = check_version_compat("23.1", "pro", "unknown_device.qdz")
        self.assertIsNone(result)

    def test_unknown_quartus_skips(self):
        """No warning when Quartus version is unknown."""
        result = check_version_compat(None, None, "arria10-23.1std.0.991.qdz")
        self.assertIsNone(result)

    def test_no_edition_on_quartus_skips_edition_check(self):
        """Only version check when Quartus edition is unknown."""
        result = check_version_compat("23.1", None, "arria10-23.1std.0.991.qdz")
        self.assertIsNone(result)  # Version matches, edition unknown → OK


class TestDetectTool(unittest.TestCase):
    """Test generic EDA tool detection."""

    def test_detect_python3(self):
        """Python3 should always be detectable on the test system."""
        version, binary_path = detect_tool("python3 --version", r"Python (\d+\.\d+\.\d+)")
        self.assertIsNotNone(version)
        self.assertTrue(version.startswith("3."))
        self.assertIsNotNone(binary_path)

    def test_detect_missing_tool(self):
        """Nonexistent binary returns (None, None)."""
        version, binary_path = detect_tool("totally_fake_eda_tool_xyz --version", r"(\d+)")
        self.assertIsNone(version)
        self.assertIsNone(binary_path)

    def test_detect_tool_bad_regex(self):
        """Binary exists but regex doesn't match → version is None, path is set."""
        version, binary_path = detect_tool("python3 --version", r"NoMatch(\d+)")
        self.assertIsNone(version)
        self.assertIsNotNone(binary_path)


class TestLoadSdkRequirements(unittest.TestCase):
    """Test SDK requirements loading."""

    def test_loads_tools(self):
        """Requirements file should have 'tools' with known entries."""
        reqs = load_sdk_requirements()
        self.assertIn("tools", reqs)
        self.assertIn("nvc", reqs["tools"])
        self.assertIn("ghdl", reqs["tools"])
        self.assertIn("vivado", reqs["tools"])
        self.assertIn("questa", reqs["tools"])

    def test_tool_has_check_cmd(self):
        """Every tool must have a check_cmd."""
        reqs = load_sdk_requirements()
        for name, spec in reqs.get("tools", {}).items():
            self.assertIn("check_cmd", spec, f"{name} missing check_cmd")
            self.assertTrue(spec["check_cmd"].strip(), f"{name} has empty check_cmd")


class TestScanDeviceFamilies(unittest.TestCase):
    """Test device family scanning."""

    def test_empty_dir(self):
        """Returns empty list when no device metadata exists."""
        with tempfile.TemporaryDirectory() as tmp:
            result = scan_device_families(tmp)
            self.assertEqual(result, [])

    def test_finds_families_devinfo_layout(self):
        """Detects device families from Std/Lite devinfo layout with part counts."""
        with tempfile.TemporaryDirectory() as tmp:
            devinfo = Path(tmp) / "quartus" / "common" / "devinfo"
            # 20nm family with 2 part subdirectories
            fam1 = devinfo / "20nm"
            fam1.mkdir(parents=True)
            (fam1 / "nightfury1").mkdir()
            (fam1 / "nightfury2").mkdir()
            (fam1 / "file1.ddb").write_text("test")

            # cyclonev family with 1 part subdirectory
            fam2 = devinfo / "cyclonev"
            fam2.mkdir(parents=True)
            (fam2 / "cyclonev_sx120f").mkdir()
            (fam2 / "file1.ddb").write_text("test")

            result = scan_device_families(tmp)
            self.assertEqual(len(result), 2)
            names = [r[0] for r in result]
            self.assertIn("20nm", names)
            self.assertIn("cyclonev", names)
            # 20nm has 2 part subdirs
            nm20 = next(r for r in result if r[0] == "20nm")
            self.assertEqual(nm20[1], 2)

    def test_finds_families_pro_devices_layout(self):
        """Detects device families from Pro devices/ layout."""
        with tempfile.TemporaryDirectory() as tmp:
            devices = Path(tmp) / "devices"
            # 10nm family
            fam1 = devices / "10nm"
            fam1.mkdir(parents=True)
            (fam1 / "fm4").mkdir()
            (fam1 / "fm5").mkdir()
            (fam1 / "fm6").mkdir()
            # 14nm family
            fam2 = devices / "14nm"
            fam2.mkdir(parents=True)
            (fam2 / "nightfury1").mkdir()

            result = scan_device_families(tmp)
            self.assertEqual(len(result), 2)
            names = [r[0] for r in result]
            self.assertIn("10nm", names)
            self.assertIn("14nm", names)
            # 10nm has 3 parts
            nm10 = next(r for r in result if r[0] == "10nm")
            self.assertEqual(nm10[1], 3)

    def test_filters_admin_directories(self):
        """Admin dirs (configuration, legacy, programmer, etc.) are excluded."""
        with tempfile.TemporaryDirectory() as tmp:
            devinfo = Path(tmp) / "quartus" / "common" / "devinfo"
            # Real device
            (devinfo / "20nm").mkdir(parents=True)
            # Admin dirs that should be filtered
            for admin in ["configuration", "dev_install", "legacy", "programmer"]:
                (devinfo / admin).mkdir(parents=True)

            result = scan_device_families(tmp)
            names = [r[0] for r in result]
            self.assertEqual(names, ["20nm"])
            self.assertNotIn("configuration", names)
            self.assertNotIn("legacy", names)
            self.assertNotIn("programmer", names)

    def test_filters_admin_dirs_pro_layout(self):
        """Admin dirs are excluded in Pro devices/ layout too."""
        with tempfile.TemporaryDirectory() as tmp:
            devices = Path(tmp) / "devices"
            # Real devices
            (devices / "10nm").mkdir(parents=True)
            # Admin dirs
            for admin in ["configuration", "cdc_lib", "sim_lib", "sim_lib2"]:
                (devices / admin).mkdir(parents=True)

            result = scan_device_families(tmp)
            names = [r[0] for r in result]
            self.assertEqual(names, ["10nm"])

    def test_versioned_subdir_layout(self):
        """Handles Quartus Lite versioned layout (e.g. 25.1std/quartus/)."""
        with tempfile.TemporaryDirectory() as tmp:
            devinfo = Path(tmp) / "25.1std" / "quartus" / "common" / "devinfo"
            fam = devinfo / "cyclonev"
            fam.mkdir(parents=True)
            (fam / "cyclonev_sx120f").mkdir()

            result = scan_device_families(tmp)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0][0], "cyclonev")
            self.assertEqual(result[0][1], 1)

    def test_pro_takes_priority_over_devinfo(self):
        """When both devices/ and devinfo/ exist, Pro devices/ is preferred."""
        with tempfile.TemporaryDirectory() as tmp:
            # Pro layout
            (Path(tmp) / "devices" / "10nm").mkdir(parents=True)
            # Also create a devinfo (shouldn't happen, but test priority)
            (Path(tmp) / "quartus" / "common" / "devinfo" / "20nm").mkdir(parents=True)

            result = scan_device_families(tmp)
            names = [r[0] for r in result]
            self.assertIn("10nm", names)
            self.assertNotIn("20nm", names)

    def test_friendly_names_populated(self):
        """Known device families include a friendly product name."""
        with tempfile.TemporaryDirectory() as tmp:
            devinfo = Path(tmp) / "quartus" / "common" / "devinfo"
            (devinfo / "20nm").mkdir(parents=True)
            (devinfo / "cyclonev").mkdir(parents=True)

            result = scan_device_families(tmp)
            nm20 = next(r for r in result if r[0] == "20nm")
            cycv = next(r for r in result if r[0] == "cyclonev")
            self.assertEqual(nm20[2], "Arria 10, Cyclone 10 GX")
            self.assertEqual(cycv[2], "Cyclone V")

    def test_unknown_family_empty_friendly_name(self):
        """Unknown device families return empty friendly name."""
        with tempfile.TemporaryDirectory() as tmp:
            devinfo = Path(tmp) / "quartus" / "common" / "devinfo"
            (devinfo / "999nm").mkdir(parents=True)

            result = scan_device_families(tmp)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0][2], "")


class TestFindPatchZips(unittest.TestCase):
    """Test patch ZIP discovery."""

    def test_empty_dir(self):
        """Returns empty list when no ZIPs exist."""
        with tempfile.TemporaryDirectory() as tmp:
            result = find_patch_zips(tmp)
            self.assertEqual(result, [])

    def test_filters_non_patch_zips(self):
        """Only returns ZIPs containing *-linux.run files."""
        with tempfile.TemporaryDirectory() as tmp:
            # Create a non-patch ZIP
            non_patch = Path(tmp) / "random.zip"
            with zipfile.ZipFile(non_patch, "w") as z:
                z.writestr("readme.txt", "not a patch")

            # Create a patch ZIP
            patch = Path(tmp) / "quartus-25.3-0.27.zip"
            with zipfile.ZipFile(patch, "w") as z:
                z.writestr("quartus-25.3-0.27-linux.run", "#!/bin/bash")
                z.writestr("quartus-25.3-0.27-readme.txt", "patch notes")

            result = find_patch_zips(tmp)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0].name, "quartus-25.3-0.27.zip")

    def test_nonexistent_dir(self):
        """Returns empty list for nonexistent directory."""
        result = find_patch_zips("/nonexistent/path/xyz")
        self.assertEqual(result, [])


class TestExtractQdz(unittest.TestCase):
    """Test .qdz extraction."""

    def test_extracts_files(self):
        """Verifies extraction creates files in target dir."""
        with tempfile.TemporaryDirectory() as tmp:
            # Create a fake .qdz
            qdz = Path(tmp) / "test.qdz"
            with zipfile.ZipFile(qdz, "w") as z:
                z.writestr("quartus/common/devinfo/test/file1.ddb", "data1")
                z.writestr("quartus/common/devinfo/test/file2.ddb", "data2")

            target = Path(tmp) / "install"
            target.mkdir()

            count = extract_qdz(str(qdz), str(target), progress=False)
            self.assertEqual(count, 2)
            self.assertTrue((target / "quartus" / "common" / "devinfo" / "test" / "file1.ddb").exists())
            self.assertTrue((target / "quartus" / "common" / "devinfo" / "test" / "file2.ddb").exists())


if __name__ == "__main__":
    unittest.main()

