# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for manage_dependencies.ensure_dependencies."""

import logging
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

# Ensure manage_dependencies is importable when run standalone via run_tests.py
_TOOLS_DIR = Path(__file__).resolve().parent.parent
if str(_TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(_TOOLS_DIR))

from manage_dependencies import ensure_dependencies


class TestEnsureDependencies(unittest.TestCase):
    """Validate dependency fetch logic in ensure_dependencies."""

    def setUp(self):
        """Create a temporary project root for each test."""
        self.project_root = Path(tempfile.mkdtemp())
        self.dep_path = self.project_root / "libs" / "xpm_vhdl"

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.project_root, ignore_errors=True)

    def _make_config(self, path="libs/xpm_vhdl"):
        """Build a minimal project config with one dependency."""
        return {
            "dependencies": {
                "xpm_vhdl": {
                    "url": "https://github.com/example/xpm_vhdl.git",
                    "fallback_url": "https://github.com/fallback/xpm_vhdl.git",
                    "path": path,
                    "library": "xpm",
                },
            },
        }

    @patch("manage_dependencies.run_git_cmd", return_value=True)
    def test_empty_dir_triggers_clone(self, mock_git):
        """An empty directory (e.g. interrupted clone) should be removed
        and the dependency cloned fresh."""
        self.dep_path.mkdir(parents=True)
        assert self.dep_path.exists()
        assert not list(self.dep_path.iterdir())  # empty

        config = self._make_config()
        ensure_dependencies(config, str(self.project_root))

        # The empty dir should have been removed and git clone called
        mock_git.assert_called_once()
        clone_cmd = mock_git.call_args[0][0]
        self.assertEqual(clone_cmd[0], "git")
        self.assertEqual(clone_cmd[1], "clone")

    @patch("manage_dependencies.run_git_cmd", return_value=True)
    def test_non_empty_non_git_dir_skips(self, mock_git):
        """A non-empty directory without .git should NOT be removed."""
        self.dep_path.mkdir(parents=True)
        (self.dep_path / "dummy.txt").write_text("content")

        config = self._make_config()
        with self.assertLogs(level=logging.WARNING) as cm:
            ensure_dependencies(config, str(self.project_root))

        # Should NOT have called git clone
        mock_git.assert_not_called()
        # The directory (and content) must still exist
        self.assertTrue(self.dep_path.exists())
        self.assertTrue((self.dep_path / "dummy.txt").exists())
        # Should have logged a warning mentioning "content"
        self.assertTrue(
            any("exists with content" in msg for msg in cm.output),
        )

    @patch("manage_dependencies.run_git_cmd", return_value=True)
    def test_valid_git_repo_skips(self, mock_git):
        """A directory with .git should be accepted without cloning."""
        self.dep_path.mkdir(parents=True)
        (self.dep_path / ".git").mkdir()

        config = self._make_config()
        ensure_dependencies(config, str(self.project_root))

        mock_git.assert_not_called()

    @patch("manage_dependencies.run_git_cmd", return_value=True)
    def test_missing_dir_triggers_clone(self, mock_git):
        """If the dependency path doesn't exist at all, clone it."""
        assert not self.dep_path.exists()

        config = self._make_config()
        ensure_dependencies(config, str(self.project_root))

        mock_git.assert_called_once()
        clone_cmd = mock_git.call_args[0][0]
        self.assertEqual(clone_cmd[0], "git")
        self.assertEqual(clone_cmd[1], "clone")

    @patch("manage_dependencies.run_git_cmd", return_value=False)
    def test_clone_failure_tries_fallback(self, mock_git):
        """If primary URL fails, try fallback_url."""
        config = self._make_config()
        ensure_dependencies(config, str(self.project_root))

        # Should have been called twice: primary + fallback
        self.assertEqual(mock_git.call_count, 2)
        urls = [call[0][0][2] for call in mock_git.call_args_list]
        self.assertIn("https://github.com/example/xpm_vhdl.git", urls)
        self.assertIn("https://github.com/fallback/xpm_vhdl.git", urls)


if __name__ == "__main__":
    unittest.main()
