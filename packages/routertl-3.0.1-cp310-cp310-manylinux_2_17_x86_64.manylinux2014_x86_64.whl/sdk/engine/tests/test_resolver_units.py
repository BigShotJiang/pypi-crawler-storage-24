# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import sys
import unittest
from pathlib import Path

# Add project root to path
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.append(str(PM_DIR))

from dependency_resolver import DependencyResolver


class TestDependencyResolverUnits(unittest.TestCase):
    def setUp(self):
        self.units_dir = REPO_ROOT / "src" / "units"
        self.src_dirs = [REPO_ROOT / "src"]

        # Verify units directory exists
        if not self.units_dir.exists():
            self.skipTest(f"Units directory {self.units_dir} does not exist")

    def test_units_resolution(self):
        """Iterates over all VHDL files in src/units and checks if dependency resolution runs without error."""

        # Initialize resolver
        resolver = DependencyResolver(self.src_dirs, verbose=False)

        vhdl_files = list(self.units_dir.glob("*.vhd"))
        if not vhdl_files:
            self.fail("No VHDL files found in src/units")

        failed_units = []

        for vhdl_file in vhdl_files:
            entity_name = vhdl_file.stem

            # Skip testbenches if any are in units (though they typically aren't)
            if entity_name.startswith("tb_") or entity_name.startswith("test_") and entity_name != "test_pwm":
                # 'test_pwm' seems to be a unit, not a tb, based on file list, but usually tb_ prefixes are testbenches.
                continue

            try:
                # We expect that if the file exists, it should be resolvable
                # OR return an empty list if it's not a valid top entity (e.g. package only).
                # But assert_no_exception is basically what we want.

                start_lines = vhdl_file.read_text().lower()
                if "entity" not in start_lines:
                    # Skip package-only files or logic-only files
                    continue

                # We attempt to find the entity in the map first
                if entity_name not in resolver.entity_map:
                    # If file name doesn't match entity name, we might skip or warn
                    # But resolver scans content, so map keys are real entity names.
                    pass

                deps = resolver.resolve_dependencies(entity_name)
                # Just calling it is enough to verify it doesn't crash on regex errors

            except Exception as e:
                failed_units.append(f"{entity_name}: {str(e)}")

        if failed_units:
            self.fail("Dependency resolution failed for the following units:\n" + "\n".join(failed_units))


if __name__ == "__main__":
    unittest.main()
