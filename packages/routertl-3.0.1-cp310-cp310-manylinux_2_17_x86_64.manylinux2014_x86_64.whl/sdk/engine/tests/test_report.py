# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Unit tests for the report command aggregation logic.

Tests the data collection helpers without requiring actual project structure.
"""

import json

# Support running from SDK root
import sys
import tempfile
import unittest
from pathlib import Path

_sdk_root = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_sdk_root))

from sdk.cli.commands.report import (
    _collect_sim_results,
    _generate_markdown_report,
    _read_lint_status,
    _read_synthesis_status,
    _status_emoji,
)


class TestCollectSimResults(unittest.TestCase):
    """Tests for _collect_sim_results()."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.results_dir = Path(self.tmpdir) / "results"
        self.results_dir.mkdir()

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_collect_empty_dir(self):
        results = _collect_sim_results(self.results_dir)
        self.assertEqual(results, [])

    def test_collect_nonexistent_dir(self):
        results = _collect_sim_results(Path("/nonexistent/path"))
        self.assertEqual(results, [])

    def test_collect_single_module(self):
        mod_dir = self.results_dir / "test_uart"
        mod_dir.mkdir()
        data = {
            "module": "test_uart",
            "passed": 5,
            "failed": 0,
            "errors": 0,
            "duration_s": 2.5,
        }
        with open(mod_dir / "latest.json", "w") as f:
            json.dump(data, f)

        results = _collect_sim_results(self.results_dir)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["module"], "test_uart")
        self.assertEqual(results[0]["passed"], 5)

    def test_collect_multiple_modules(self):
        for name in ["test_a", "test_b", "test_c"]:
            mod_dir = self.results_dir / name
            mod_dir.mkdir()
            with open(mod_dir / "latest.json", "w") as f:
                json.dump({"module": name, "passed": 1, "failed": 0, "errors": 0, "duration_s": 1.0}, f)

        results = _collect_sim_results(self.results_dir)
        self.assertEqual(len(results), 3)

    def test_skip_invalid_json(self):
        mod_dir = self.results_dir / "test_bad"
        mod_dir.mkdir()
        with open(mod_dir / "latest.json", "w") as f:
            f.write("not valid json {{{")

        results = _collect_sim_results(self.results_dir)
        self.assertEqual(results, [])


class TestReadLintStatus(unittest.TestCase):
    """Tests for _read_lint_status()."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.project_root = Path(self.tmpdir)

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_no_lint_log(self):
        status, _ = _read_lint_status(self.project_root)
        self.assertEqual(status, "not_run")

    def test_lint_pass(self):
        sim_dir = self.project_root / "sim"
        sim_dir.mkdir()
        (sim_dir / "lint.log").write_text("Linting completed: PASS\nAll clear.")

        status, detail = _read_lint_status(self.project_root)
        self.assertEqual(status, "pass")
        self.assertIn("PASS", detail)

    def test_lint_fail(self):
        sim_dir = self.project_root / "sim"
        sim_dir.mkdir()
        (sim_dir / "lint.log").write_text("Linting completed: FAIL\nErrors found.")

        status, _ = _read_lint_status(self.project_root)
        self.assertEqual(status, "fail")


class TestReadSynthesisStatus(unittest.TestCase):
    """Tests for _read_synthesis_status()."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.project_root = Path(self.tmpdir)

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_no_synth_log(self):
        status, _ = _read_synthesis_status(self.project_root)
        self.assertEqual(status, "not_run")

    def test_synth_found(self):
        logs_dir = self.project_root / "logs"
        logs_dir.mkdir()
        (logs_dir / "regression_summary.txt").write_text("TOTAL: 7 PASSED, 0 FAILED")

        status, detail = _read_synthesis_status(self.project_root)
        self.assertEqual(status, "found")
        self.assertIn("PASSED", detail)


class TestStatusEmoji(unittest.TestCase):
    """Tests for _status_emoji()."""

    def test_known_statuses(self):
        self.assertEqual(_status_emoji("pass"), "✅")
        self.assertEqual(_status_emoji("fail"), "❌")
        self.assertEqual(_status_emoji("not_run"), "⏭️")

    def test_unknown_status(self):
        self.assertEqual(_status_emoji("bananas"), "❓")


class TestMarkdownReport(unittest.TestCase):
    """Tests for _generate_markdown_report()."""

    def test_generates_valid_markdown(self):
        sim_results = [
            {"module": "test_uart", "passed": 5, "failed": 0, "errors": 0, "duration_s": 1.5},
        ]
        report = _generate_markdown_report(sim_results, "pass", "", "not_run", "", [])

        self.assertIn("# RouteRTL Project Report", report)
        self.assertIn("test_uart", report)
        self.assertIn("PASS", report)

    def test_empty_results(self):
        report = _generate_markdown_report([], "not_run", "", "not_run", "", [])
        self.assertIn("No simulation results found", report)

    def test_regression_section(self):
        regressions = [
            {
                "regressed": True,
                "module": "test_slow",
                "latest_s": 5.0,
                "avg_s": 3.0,
                "pct_over": 66.7,
                "regressed_tests": [{"name": "test_x", "latest_s": 3.0, "avg_s": 1.5, "pct_over": 100.0}],
            }
        ]
        report = _generate_markdown_report([], "pass", "", "not_run", "", regressions)
        self.assertIn("Performance Regressions", report)
        self.assertIn("test_slow", report)
        self.assertIn("test_x", report)


if __name__ == "__main__":
    unittest.main()
