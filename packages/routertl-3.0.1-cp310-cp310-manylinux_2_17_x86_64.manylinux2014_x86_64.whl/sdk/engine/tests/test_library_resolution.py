# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

# Add project root to path
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.append(str(PM_DIR))

from dependency_resolver import DependencyResolver


class TestLibraryAwareResolution(unittest.TestCase):
    """Tests for get_compilation_order_with_libs and package_lib_map."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.test_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def create_file(self, filename: str, content: str) -> Path:
        file_path = self.src_dir / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return file_path

    def test_package_lib_map_from_use_clause(self):
        """use mylib.my_pkg.all should create package_lib_map[my_pkg] = mylib."""
        self.create_file(
            "my_pkg.vhd",
            """\
package my_pkg is
end package my_pkg;
""",
        )
        self.create_file(
            "top.vhd",
            """\
library mylib;
use mylib.my_pkg.all;
entity top is
end entity top;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        self.assertIn("my_pkg", resolver.package_lib_map)
        self.assertEqual(resolver.package_lib_map["my_pkg"], "mylib")

    def test_entity_lib_map_from_instantiation(self):
        """entity mylib.sub should create entity_lib_map[sub] = mylib."""
        self.create_file(
            "sub.vhd",
            """\
entity sub is
end entity sub;
""",
        )
        self.create_file(
            "top.vhd",
            """\
library mylib;
entity top is
end entity top;
architecture rtl of top is
begin
    u_sub: entity mylib.sub;
end architecture;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        self.assertIn("sub", resolver.entity_lib_map)
        self.assertEqual(resolver.entity_lib_map["sub"], "mylib")

    def test_compilation_order_with_libs_custom_library(self):
        """get_compilation_order_with_libs should tag files with correct libraries."""
        self.create_file(
            "my_pkg.vhd",
            """\
package my_pkg is
    constant VAL : integer := 42;
end package my_pkg;
""",
        )
        self.create_file(
            "top.vhd",
            """\
library dskop;
use dskop.my_pkg.all;
entity top is
end entity top;
architecture rtl of top is
begin
end architecture;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order_with_libs("top")

        # Should be [(dskop, my_pkg.vhd), (work, top.vhd)]
        libs = [lib for lib, _ in order]
        names = [p.name for _, p in order]
        self.assertEqual(names, ["my_pkg.vhd", "top.vhd"])
        self.assertEqual(libs[0], "dskop")
        self.assertEqual(libs[1], "work")

    def test_compilation_order_with_libs_entity_instantiation(self):
        """entity lib.ent should tag the entity file with the instantiating library."""
        self.create_file(
            "child.vhd",
            """\
entity child is
end entity child;
""",
        )
        self.create_file(
            "parent.vhd",
            """\
library mylib;
entity parent is
end entity parent;
architecture rtl of parent is
begin
    u_child: entity mylib.child;
end architecture;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order_with_libs("parent")

        libs = [lib for lib, _ in order]
        names = [p.name for _, p in order]
        self.assertEqual(names, ["child.vhd", "parent.vhd"])
        self.assertEqual(libs[0], "mylib")
        self.assertEqual(libs[1], "work")

    def test_standard_libs_not_captured(self):
        """use ieee.std_logic_1164.all should NOT create a package_lib_map entry."""
        self.create_file(
            "top.vhd",
            """\
library ieee;
use ieee.std_logic_1164.all;
entity top is
end entity top;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        self.assertNotIn("std_logic_1164", resolver.package_lib_map)

    def test_work_library_default(self):
        """Files with no custom library should default to 'work'."""
        self.create_file(
            "simple.vhd",
            """\
entity simple is
end entity simple;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order_with_libs("simple")
        self.assertEqual(len(order), 1)
        self.assertEqual(order[0][0], "work")

    def test_verilog_files_get_work_library(self):
        """Verilog files should always get 'work' library."""
        self.create_file("mod.v", "module mod; endmodule")
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order_with_libs("mod")
        self.assertEqual(len(order), 1)
        self.assertEqual(order[0][0], "work")

    def test_multi_library_chain(self):
        """Multiple libraries in a dependency chain should all be tagged correctly."""
        self.create_file(
            "base_pkg.vhd",
            """\
package base_pkg is
end package base_pkg;
""",
        )
        self.create_file(
            "mid.vhd",
            """\
library libA;
use libA.base_pkg.all;
entity mid is
end entity mid;
""",
        )
        self.create_file(
            "top.vhd",
            """\
library libB;
entity top is
end entity top;
architecture rtl of top is
begin
    u_mid: entity libB.mid;
end architecture;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        order = resolver.get_compilation_order_with_libs("top")

        result = {p.name: lib for lib, p in order}
        self.assertEqual(result["base_pkg.vhd"], "libA")
        self.assertEqual(result["mid.vhd"], "libB")
        self.assertEqual(result["top.vhd"], "work")

    def test_list_libs_backward_compat(self):
        """--list (old flag) should still produce flat paths without lib tags."""
        self.create_file(
            "simple.vhd",
            """\
entity simple is
end entity simple;
""",
        )
        resolver = DependencyResolver([self.src_dir], verbose=False)
        # Old method should still return just paths
        order = resolver.get_compilation_order("simple")
        self.assertIsInstance(order[0], Path)


class TestLibraryAwareResolutionLive(unittest.TestCase):
    """Tests against the actual SDK src/ directory."""

    def setUp(self):
        self.src_dirs = [REPO_ROOT / "src"]
        if not self.src_dirs[0].exists():
            self.skipTest("SDK src/ directory not found")

    def test_mux_cdc_er_libraries(self):
        """mux_cdc_er should resolve event_synchronizer into 'tich' library."""
        resolver = DependencyResolver(self.src_dirs, verbose=False)
        order = resolver.get_compilation_order_with_libs("mux_cdc_er")

        result = {p.name: lib for lib, p in order}
        self.assertIn("event_synchronizer.vhd", result)
        self.assertEqual(result["event_synchronizer.vhd"], "tich")
        self.assertEqual(result["mux_cdc_er.vhd"], "work")

    def test_infilter_array_libraries(self):
        """infilter_array should resolve infilter into 'tich' library."""
        resolver = DependencyResolver(self.src_dirs, verbose=False)
        order = resolver.get_compilation_order_with_libs("infilter_array")

        result = {p.name: lib for lib, p in order}
        self.assertIn("infilter.vhd", result)
        self.assertEqual(result["infilter.vhd"], "tich")
        self.assertEqual(result["infilter_array.vhd"], "work")


if __name__ == "__main__":
    unittest.main()
