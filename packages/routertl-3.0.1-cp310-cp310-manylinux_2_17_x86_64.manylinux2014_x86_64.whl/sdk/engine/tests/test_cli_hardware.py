# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for hardware-related CLI commands: synth, hierarchy, npm-synthesis,
schematic, bitstream, implementation, linting, aliases, clean flags, and
input sanitization.

Split from test_cli.py as part of P2.66.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import ANY, patch

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli


class TestHardwareCommands(unittest.TestCase):
    """Tests for basic hardware commands (synth, bitstream, implementation, project)."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("subprocess.run")
    def test_hardware_commands(self, mock_run):
        mock_run.return_value.returncode = 0

        # Test basic hardware commands
        for cmd in ["bitstream", "synth", "implementation", "project"]:
            if cmd == "synth":
                result = self.runner.invoke(cli, [cmd, "run"])
            else:
                result = self.runner.invoke(cli, [cmd])
            self.assertEqual(result.exit_code, 0, f"Command {cmd} failed")

            if cmd == "synth":
                mock_run.assert_called_with(["make", "synthesis"], check=False, env=ANY)
            else:
                mock_run.assert_called_with(["make", cmd], check=False, env=ANY)

        # Test command with argument
        result = self.runner.invoke(cli, ["hierarchy", "my_top"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "hierarchy", "TOP=my_top"], check=False, env=ANY)

        result = self.runner.invoke(cli, ["npm-synthesis", "my_top"])
        self.assertEqual(result.exit_code, 0)

    @patch("subprocess.run")
    def test_impl_and_bit_aliases(self, mock_run):
        """impl and bit should be shortcut aliases for implementation and bitstream."""
        mock_run.return_value.returncode = 0

        # rr impl run → make implementation
        result = self.runner.invoke(cli, ["impl", "run"])
        self.assertEqual(result.exit_code, 0, f"impl run failed: {result.output}")
        mock_run.assert_called_with(["make", "implementation"], check=False, env=ANY)

        # rr bit run → make bitstream
        result = self.runner.invoke(cli, ["bit", "run"])
        self.assertEqual(result.exit_code, 0, f"bit run failed: {result.output}")
        mock_run.assert_called_with(["make", "bitstream"], check=False, env=ANY)

        # Both should accept --help
        for alias in ["impl", "bit"]:
            result = self.runner.invoke(cli, [alias, "--help"])
            self.assertEqual(result.exit_code, 0, f"{alias} --help failed")

    @patch("subprocess.run")
    def test_hardware_strips_file_extension(self, mock_run):
        """Commands should strip .vhd/.sv extensions from entity names."""
        mock_run.return_value.returncode = 0

        # .vhd extension should be stripped — schematic calls gen_schematic.py directly
        result = self.runner.invoke(cli, ["schematic", "frame_drop.vhd"])
        self.assertEqual(result.exit_code, 0)
        called_args = mock_run.call_args[0][0]
        self.assertEqual(called_args[0], "python3")
        self.assertIn("gen_schematic.py", called_args[1])
        self.assertIn("--top", called_args)
        self.assertIn("frame_drop", called_args)

        # .sv extension should be stripped
        result = self.runner.invoke(cli, ["hierarchy", "my_top.sv"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "hierarchy", "TOP=my_top"], check=False, env=ANY)

        # No extension — should pass through unchanged
        result = self.runner.invoke(cli, ["hierarchy", "my_top"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "hierarchy", "TOP=my_top"], check=False, env=ANY)

    @patch("subprocess.run")
    def test_schematic_multi_path_src_dir(self, mock_run):
        """Regression: schematic must split space-separated SRC_DIR into multiple --src args.

        When build_env.mk contains:  SRC_DIR ?= hw/rtl vendor/routertl/src/units
        each path must be passed as a separate --src argument, NOT as one combined string.
        """
        mock_run.return_value.returncode = 0

        with self.runner.isolated_filesystem():
            # Simulate a consumer project's build_env.mk with multi-path SRC_DIR
            with open("build_env.mk", "w") as f:
                f.write("SRC_DIR      ?= hw/rtl vendor/routertl/src/units\n")

            result = self.runner.invoke(cli, ["schematic", "uart_sniffer"])
            self.assertEqual(result.exit_code, 0)

            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args[0], "python3")
            self.assertIn("gen_schematic.py", called_args[1])

            # Both source directories must appear after a single --src flag
            src_idx = called_args.index("--src")
            self.assertEqual(called_args[src_idx + 1], "hw/rtl")
            self.assertEqual(called_args[src_idx + 2], "vendor/routertl/src/units")

    def test_schematic_entity_resolution_integration(self):
        """Integration: gen_schematic.py must resolve entities across multiple source dirs.

        Creates real VHDL files in two directories and verifies that
        gen_schematic.py finds the entity and resolves dependencies correctly,
        exiting only when yosys is unavailable (expected on CI/host).
        """
        import subprocess

        with self.runner.isolated_filesystem():
            import os

            # Create two source directories mimicking the consumer layout
            os.makedirs("hw/rtl/uart", exist_ok=True)
            os.makedirs("vendor/sdk/src/units", exist_ok=True)

            # A utility entity in the SDK source dir
            with open("vendor/sdk/src/units/edge_detector.vhd", "w") as f:
                f.write(
                    "library ieee;\nuse ieee.std_logic_1164.all;\n"
                    "entity edge_detector is\n"
                    "  port(clk : in std_logic; d : in std_logic; edge_out : out std_logic);\n"
                    "end entity edge_detector;\n"
                    "architecture rtl of edge_detector is\nbegin\nend architecture rtl;\n"
                )

            # Top entity in project source dir that instantiates the utility
            with open("hw/rtl/uart/my_top.vhd", "w") as f:
                f.write(
                    "library ieee;\nuse ieee.std_logic_1164.all;\n"
                    "entity my_top is\n"
                    "  port(clk : in std_logic; data_in : in std_logic);\n"
                    "end entity my_top;\n"
                    "architecture rtl of my_top is\nbegin\n"
                    "  u_edge : entity work.edge_detector port map(clk => clk, d => data_in, edge_out => open);\n"
                    "end architecture rtl;\n"
                )

            # Locate gen_schematic.py
            script = Path(__file__).resolve().parent.parent / "gen_schematic.py"
            self.assertTrue(script.exists(), f"gen_schematic.py not found at {script}")

            # Run gen_schematic.py — it should find the entity and resolve deps,
            # then fail gracefully at the yosys step (not installed on host)
            result = subprocess.run(
                [
                    "python3", str(script), "--top", "my_top",
                    "--src", "hw/rtl", "vendor/sdk/src/units",
                    "--out", "sim/schematics",
                ],
                capture_output=True, text=True, timeout=10,
            )

            combined = result.stdout + result.stderr
            # Must NOT contain entity-not-found errors
            self.assertNotIn("Entity 'my_top' not found", combined)
            self.assertNotIn("No valid source directories", combined)

            # Should either succeed (yosys present) or fail with yosys hint
            if result.returncode != 0:
                self.assertIn("yosys", combined.lower(),
                              f"Expected yosys error, got: {combined}")

    @patch("subprocess.run")
    def test_npm_synthesis_no_args_lists_targets(self, mock_run):
        """npm-synthesis without TOP should list targets instead of erroring."""
        import json

        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = json.dumps(
            {
                "trees": [
                    {"top": "my_top", "weight": 5, "files": ["a.vhd"]},
                    {"top": "sub_mod", "weight": 2, "files": ["b.sv"]},
                ]
            }
        )
        mock_run.return_value.stderr = ""
        result = self.runner.invoke(cli, ["npm-synthesis"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Available Synthesis Targets", result.output)
        self.assertIn("my_top", result.output)
        self.assertIn("sub_mod", result.output)

    @patch("subprocess.run")
    def test_npm_synthesis_list_flag(self, mock_run):
        """npm-synthesis --list should list targets."""
        import json

        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = json.dumps({"trees": [{"top": "alpha", "weight": 3, "files": []}]})
        mock_run.return_value.stderr = ""
        result = self.runner.invoke(cli, ["npm-synthesis", "--list"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Available Synthesis Targets", result.output)
        self.assertIn("alpha", result.output)

    @patch("subprocess.run")
    def test_hierarchy_no_args_lists_targets(self, mock_run):
        """hierarchy without TOP should list targets instead of erroring."""
        import json

        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = json.dumps({"trees": [{"top": "my_top", "weight": 10, "files": []}]})
        mock_run.return_value.stderr = ""
        result = self.runner.invoke(cli, ["hierarchy"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Available Synthesis Targets", result.output)
        self.assertIn("my_top", result.output)

    @patch("sdk.cli.commands.synth.subprocess.run")
    def test_npm_synthesis_with_top_runs_make(self, mock_run):
        """npm-synthesis with TOP should delegate to synth_run and call make."""
        mock_run.return_value.returncode = 0
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["npm-synthesis", "pld03_top"])
            self.assertEqual(result.exit_code, 0)
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, ["make", "npm-synthesis", "TOP=pld03_top"])

    @patch("sdk.cli.commands.hardware.DependencyResolver", create=True)
    @patch("subprocess.run")
    def test_npm_synthesis_all_flag_shows_submodules(self, mock_run, mock_resolver_cls):
        """npm-synthesis --all should show submodule tags in output."""
        # Mock the DependencyResolver for --all mode
        mock_resolver = mock_resolver_cls.return_value
        mock_resolver.resolve_forest.return_value = {"trees": [{"top": "big_top", "weight": 10}]}
        mock_resolver.entity_map = {
            "big_top": "/path/big_top.vhd",
            "sub_a": "/path/sub_a.vhd",
            "sub_b": "/path/sub_b.sv",
        }
        result = self.runner.invoke(cli, ["npm-synthesis", "--all"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("All Synthesizable Modules", result.output)
        self.assertIn("submodule", result.output)

    @patch("sdk.cli.commands.hardware.DependencyResolver", create=True)
    @patch("subprocess.run")
    def test_hierarchy_all_flag_shows_submodules(self, mock_run, mock_resolver_cls):
        """hierarchy --all should show submodule tags in output."""
        mock_resolver = mock_resolver_cls.return_value
        mock_resolver.resolve_forest.return_value = {"trees": [{"top": "top_mod", "weight": 5}]}
        mock_resolver.entity_map = {
            "top_mod": "/path/top_mod.vhd",
            "child": "/path/child.vhd",
        }
        result = self.runner.invoke(cli, ["hierarchy", "--all"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("All Synthesizable Modules", result.output)
        self.assertIn("submodule", result.output)

    @patch("subprocess.run")
    def test_hierarchy_all_with_top_delegates_to_make(self, mock_run):
        """hierarchy --all my_top should ignore --all and delegate to make."""
        mock_run.return_value.returncode = 0
        result = self.runner.invoke(cli, ["hierarchy", "--all", "my_top"])
        self.assertEqual(result.exit_code, 0)
        mock_run.assert_called_with(["make", "hierarchy", "TOP=my_top"], check=False, env=ANY)


class TestCLIAliases(unittest.TestCase):
    """Verify all command aliases are registered and work."""

    def setUp(self):
        self.runner = CliRunner()

    def test_synth_alias(self):
        """'synth' should be registered as the synth status board group."""
        result = self.runner.invoke(cli, ["synth", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Synthesis", result.output)

    def test_lint_alias(self):
        """'lint' should be registered as alias for 'linting'."""
        result = self.runner.invoke(cli, ["lint", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Linter", result.output)

    def test_synth_targets_command(self):
        """'synth-targets' should be a registered command."""
        result = self.runner.invoke(cli, ["synth-targets", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("synthesis targets", result.output)

    @patch("sdk.cli.commands.synth.subprocess.run")
    def test_synth_alias_with_module(self, mock_run):
        """'synth run module' should invoke make npm-synthesis TOP=module."""
        mock_run.return_value.returncode = 0
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["synth", "run", "frame_drop"])
            self.assertEqual(result.exit_code, 0)
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, ["make", "npm-synthesis", "TOP=frame_drop"])

    def test_npm_synthesis_deprecated(self):
        """'npm-synthesis' should still work but show deprecation warning."""
        result = self.runner.invoke(cli, ["npm-synthesis", "--help"])
        self.assertEqual(result.exit_code, 0)

    @patch("sdk.cli.commands.synth.subprocess.run")
    def test_npm_synthesis_with_module_shows_warning(self, mock_run):
        """'npm-synthesis <module>' should emit deprecation warning and delegate."""
        mock_run.return_value.returncode = 0
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["npm-synthesis", "frame_drop"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("deprecated", result.output)
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, ["make", "npm-synthesis", "TOP=frame_drop"])


class TestCleanFlag(unittest.TestCase):
    """Tests for the --clean flag on build commands."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("sdk.cli.commands.synth.subprocess.run")
    def test_synth_run_clean_removes_dcp(self, mock_run):
        """synth run --clean should remove dcp/<module>/ before synthesis."""
        mock_run.return_value.returncode = 0
        with self.runner.isolated_filesystem():
            import os

            os.makedirs("dcp/frame_drop", exist_ok=True)
            with open("dcp/frame_drop/report.txt", "w") as f:
                f.write("old report")

            result = self.runner.invoke(cli, ["synth", "run", "frame_drop", "--clean"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("Removed", result.output)
            self.assertFalse(os.path.exists("dcp/frame_drop"))

    @patch("subprocess.run")
    def test_lint_clean_removes_cache(self, mock_run):
        """lint --clean should remove .routertl_cache/."""
        mock_run.return_value.returncode = 0
        with self.runner.isolated_filesystem():
            import os

            os.makedirs(".routertl_cache", exist_ok=True)
            with open(".routertl_cache/libraries.json", "w") as f:
                f.write("{}")

            result = self.runner.invoke(cli, ["lint", "my_mod", "--clean"])
            self.assertEqual(result.exit_code, 0)
            self.assertFalse(os.path.exists(".routertl_cache"))

    @patch("subprocess.run")
    def test_sim_clean_removes_sim_build(self, mock_run):
        """sim --clean should remove sim_build/."""
        mock_run.return_value.returncode = 0
        with self.runner.isolated_filesystem():
            import os

            os.makedirs("sim_build", exist_ok=True)
            with open("sim_build/output.log", "w") as f:
                f.write("build log")

            result = self.runner.invoke(cli, ["sim", "test_foo", "--clean"])
            self.assertEqual(result.exit_code, 0)
            self.assertFalse(os.path.exists("sim_build"))


class TestSynthCommand(unittest.TestCase):
    """Tests for the rr synth command group."""

    def setUp(self):
        self.runner = CliRunner()

    def test_synth_help(self):
        """rr synth --help should display subcommands."""
        result = self.runner.invoke(cli, ["synth", "--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("status", result.output)
        self.assertIn("discover", result.output)
        self.assertIn("run", result.output)

    def test_synth_status_no_project(self):
        """synth status should handle missing project.yml gracefully."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["synth", "status"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("No ip.yml targets", result.output)

    def test_synth_status_with_cache(self):
        """synth status should show cached results when no ip.yml targets exist."""
        import json

        with self.runner.isolated_filesystem():
            import os

            os.makedirs(".routertl_cache", exist_ok=True)
            cache = {
                "version": 1,
                "results": {
                    "edge_detector": {
                        "module": "edge_detector",
                        "status": "PASS",
                        "timestamp": "2026-03-01T12:00:00+00:00",
                        "duration_s": 15.2,
                        "resources": {"LUTs": 42},
                        "warnings": 0,
                        "vendor": "xilinx",
                        "part": "xc7z020",
                    }
                },
            }
            with open(".routertl_cache/synth_results.json", "w") as f:
                json.dump(cache, f)

            result = self.runner.invoke(cli, ["synth", "status"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("edge_detector", result.output)

    @patch("subprocess.run")
    def test_synth_run_delegates_to_make(self, mock_run):
        """synth run <module> should delegate to make npm-synthesis."""
        mock_run.return_value.returncode = 0
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["synth", "run", "uart_sniffer"])
            self.assertEqual(result.exit_code, 0)
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, ["make", "npm-synthesis", "TOP=uart_sniffer"])

    @patch("subprocess.run")
    def test_synth_run_records_result(self, mock_run):
        """synth run should update the cache file after synthesis."""
        import json

        mock_run.return_value.returncode = 0
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["synth", "run", "edge_detector"])
            self.assertEqual(result.exit_code, 0)

            # Verify cache was written
            cache_file = Path(".routertl_cache/synth_results.json")
            self.assertTrue(cache_file.exists(), "Cache file should be created")
            data = json.loads(cache_file.read_text())
            self.assertIn("edge_detector", data["results"])
            self.assertEqual(data["results"]["edge_detector"]["status"], "PASS")

    @patch("subprocess.run")
    def test_synth_run_fail_records_fail(self, mock_run):
        """synth run should record FAIL on non-zero exit code."""
        import json

        mock_run.return_value.returncode = 1
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["synth", "run", "broken_mod"])
            self.assertNotEqual(result.exit_code, 0)

            cache_file = Path(".routertl_cache/synth_results.json")
            self.assertTrue(cache_file.exists())
            data = json.loads(cache_file.read_text())
            self.assertEqual(data["results"]["broken_mod"]["status"], "FAIL")

    def test_synth_discover_no_sources(self):
        """synth discover should handle missing source tree gracefully."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["synth", "discover"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("No entities found", result.output)

    def test_synth_clear_all(self):
        """synth clear should remove all cached results."""
        import json

        with self.runner.isolated_filesystem():
            import os

            os.makedirs(".routertl_cache", exist_ok=True)
            cache = {
                "version": 1,
                "results": {
                    "mod_a": {
                        "module": "mod_a",
                        "status": "PASS",
                        "timestamp": "2026-03-01T12:00:00+00:00",
                        "duration_s": 10,
                        "resources": {},
                        "warnings": 0,
                        "vendor": "",
                        "part": "",
                    }
                },
            }
            with open(".routertl_cache/synth_results.json", "w") as f:
                json.dump(cache, f)

            result = self.runner.invoke(cli, ["synth", "clear"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("Cleared all", result.output)

            data = json.loads(Path(".routertl_cache/synth_results.json").read_text())
            self.assertEqual(len(data["results"]), 0)

    def test_synth_clear_single(self):
        """synth clear <module> should only remove that module."""
        import json

        with self.runner.isolated_filesystem():
            import os

            os.makedirs(".routertl_cache", exist_ok=True)
            cache = {
                "version": 1,
                "results": {
                    "mod_a": {
                        "module": "mod_a",
                        "status": "PASS",
                        "timestamp": "2026-03-01T12:00:00+00:00",
                        "duration_s": 10,
                        "resources": {},
                        "warnings": 0,
                        "vendor": "",
                        "part": "",
                    },
                    "mod_b": {
                        "module": "mod_b",
                        "status": "FAIL",
                        "timestamp": "2026-03-01T13:00:00+00:00",
                        "duration_s": 5,
                        "resources": {},
                        "warnings": 2,
                        "vendor": "",
                        "part": "",
                    },
                },
            }
            with open(".routertl_cache/synth_results.json", "w") as f:
                json.dump(cache, f)

            result = self.runner.invoke(cli, ["synth", "clear", "mod_a"])
            self.assertEqual(result.exit_code, 0)
            self.assertIn("mod_a", result.output)

            data = json.loads(Path(".routertl_cache/synth_results.json").read_text())
            self.assertNotIn("mod_a", data["results"])
            self.assertIn("mod_b", data["results"])

    def test_synth_status_json(self):
        """synth status --json should produce valid JSON output."""
        with self.runner.isolated_filesystem():
            result = self.runner.invoke(cli, ["synth", "status", "--json"])
            self.assertEqual(result.exit_code, 0)
            import json
            data = json.loads(result.output)
            self.assertIsInstance(data, dict)


class TestSynthTracker(unittest.TestCase):
    """Unit tests for SynthTracker staleness logic."""

    def test_staleness_unknown(self):
        """staleness_check returns UNKNOWN for unrecorded modules."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            sys.path.insert(0, str(Path(__file__).parent.parent.parent / "project-manager"))
            from synth_tracker import SynthTracker
            tracker = SynthTracker(project_root=tmp)
            self.assertEqual(tracker.staleness_check("nonexistent", []), "UNKNOWN")

    def test_staleness_pass_no_changes(self):
        """staleness_check returns PASS when no sources are newer."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            sys.path.insert(0, str(Path(__file__).parent.parent.parent / "project-manager"))
            from synth_tracker import SynthResult, SynthTracker

            # Create a source file first
            src = Path(tmp) / "src.vhd"
            src.write_text("entity e is end;")

            # Record a result with a timestamp far in the future
            tracker = SynthTracker(project_root=tmp)
            tracker.record(SynthResult(
                module="e",
                status="PASS",
                timestamp="2099-01-01T00:00:00+00:00",
            ))

            result = tracker.staleness_check("e", [str(src)])
            self.assertEqual(result, "PASS")

    def test_staleness_stale(self):
        """staleness_check returns STALE when sources are newer than result."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            sys.path.insert(0, str(Path(__file__).parent.parent.parent / "project-manager"))
            from synth_tracker import SynthResult, SynthTracker

            tracker = SynthTracker(project_root=tmp)
            tracker.record(SynthResult(
                module="e",
                status="PASS",
                timestamp="2020-01-01T00:00:00+00:00",
            ))

            # Source file created after the old timestamp
            src = Path(tmp) / "src.vhd"
            src.write_text("entity e is end;")

            result = tracker.staleness_check("e", [str(src)])
            self.assertEqual(result, "STALE")

    def test_staleness_fail(self):
        """staleness_check returns FAIL for failed results regardless of mtime."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            sys.path.insert(0, str(Path(__file__).parent.parent.parent / "project-manager"))
            from synth_tracker import SynthResult, SynthTracker

            tracker = SynthTracker(project_root=tmp)
            tracker.record(SynthResult(
                module="e",
                status="FAIL",
                timestamp="2026-03-01T00:00:00+00:00",
            ))

            result = tracker.staleness_check("e", [])
            self.assertEqual(result, "FAIL")


class TestInputSanitization(unittest.TestCase):
    """Tests for _clean_top input sanitization against injection attacks."""

    def setUp(self):
        self.runner = CliRunner()

    @patch("subprocess.run")
    def test_valid_entity_names(self, mock_run):
        """Valid VHDL/Verilog identifiers should pass through."""
        mock_run.return_value.returncode = 0
        for name in ["frame_drop", "my_top", "TestPatternGenerator", "db_rtp_udp_ip_tx_chn", "_private", "A"]:
            result = self.runner.invoke(cli, ["linting", name])
            self.assertEqual(result.exit_code, 0, f"Valid name '{name}' rejected: {result.output}")

    def test_shell_injection_semicolon(self):
        """Shell metacharacter ';' should be rejected."""
        result = self.runner.invoke(cli, ["linting", "foo; rm -rf /"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Invalid module name", result.output)

    def test_shell_injection_backtick(self):
        """Backtick command substitution should be rejected."""
        result = self.runner.invoke(cli, ["linting", "`whoami`"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Invalid module name", result.output)

    def test_shell_injection_dollar(self):
        """Dollar-sign expansion should be rejected."""
        result = self.runner.invoke(cli, ["linting", "$(cat /etc/passwd)"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Invalid module name", result.output)

    def test_shell_injection_pipe(self):
        """Pipe character should be rejected."""
        result = self.runner.invoke(cli, ["linting", "foo|cat"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Invalid module name", result.output)

    def test_path_traversal_forward_slash(self):
        """Forward slash (path traversal) should be rejected."""
        result = self.runner.invoke(cli, ["linting", "../../../etc/passwd"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("path separators", result.output)

    def test_path_traversal_backslash(self):
        """Backslash (Windows path traversal) should be rejected."""
        result = self.runner.invoke(cli, ["linting", "..\\..\\etc\\passwd"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("path separators", result.output)

    def test_name_too_long(self):
        """Names exceeding 128 chars should be rejected."""
        long_name = "a" * 129
        result = self.runner.invoke(cli, ["linting", long_name])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("too long", result.output)

    def test_name_starts_with_digit(self):
        """Names starting with a digit are invalid HDL identifiers."""
        result = self.runner.invoke(cli, ["linting", "123bad"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Invalid module name", result.output)

    def test_name_with_spaces(self):
        """Names with spaces should be rejected."""
        result = self.runner.invoke(cli, ["linting", "my module"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Invalid module name", result.output)

    def test_name_with_hyphen(self):
        """Hyphens are not valid in VHDL/Verilog identifiers."""
        result = self.runner.invoke(cli, ["linting", "my-module"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Invalid module name", result.output)

    @patch("subprocess.run")
    def test_top_prefix_stripped(self, mock_run):
        """TOP= prefix should be stripped before validation."""
        mock_run.return_value.returncode = 0
        result = self.runner.invoke(cli, ["linting", "TOP=frame_drop"])
        self.assertEqual(result.exit_code, 0)
        called_str = " ".join(str(a) for a in mock_run.call_args[0][0])
        self.assertIn("frame_drop", called_str)

    @patch("subprocess.run")
    def test_vhd_extension_stripped(self, mock_run):
        """File extensions should be stripped cleanly."""
        mock_run.return_value.returncode = 0
        result = self.runner.invoke(cli, ["linting", "frame_drop.vhd"])
        self.assertEqual(result.exit_code, 0)
        called_str = " ".join(str(a) for a in mock_run.call_args[0][0])
        self.assertIn("frame_drop", called_str)

    @patch("subprocess.run")
    def test_128_char_name_accepted(self, mock_run):
        """Exactly 128 chars should be accepted (boundary test)."""
        mock_run.return_value.returncode = 0
        name = "a" * 128
        result = self.runner.invoke(cli, ["linting", name])
        self.assertEqual(result.exit_code, 0)


if __name__ == "__main__":
    unittest.main()
