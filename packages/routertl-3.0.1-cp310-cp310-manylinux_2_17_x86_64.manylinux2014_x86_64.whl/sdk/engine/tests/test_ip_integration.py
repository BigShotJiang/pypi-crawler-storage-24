# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Integration tests for IP manifest system through project_manager.py.

Tests cover end-to-end flow: ip.yml → IpResolver → generate_mk_file → build_env.mk.
Also covers scan_sources.py --ip-update.
"""

import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

# ── Path setup ──────────────────────────────────────────────────
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
TOOLS_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.insert(0, str(TOOLS_DIR))

from project_manager import generate_mk_file
from scan_sources import update_ip_manifests


class TestBuildEnvIntegration(unittest.TestCase):
    """Test that generate_mk_file correctly processes IPs."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.output_mk = self.tmp / "build_env.mk"

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _make_ip_yml(self, rel_dir, name, mode="rtl", sources=None, library="work"):
        """Create an ip.yml in a temp subdirectory."""
        ip_dir = self.tmp / rel_dir
        ip_dir.mkdir(parents=True, exist_ok=True)
        data = {
            "ip": {"name": name, "library": library, "language": "vhdl"},
            "paths": {"sources": "src"},
            "synthesis": {"mode": mode, "sources": sources or []},
        }
        yml_path = ip_dir / "ip.yml"
        with open(yml_path, "w") as f:
            yaml.dump(data, f)
        # Create stub source files
        if sources:
            for src in sources:
                p = ip_dir / src
                p.parent.mkdir(parents=True, exist_ok=True)
                p.touch()
        return str(ip_dir.relative_to(self.tmp) / "ip.yml")

    def _gen_mk(self, config):
        """Generate build_env.mk and return its content."""
        # Temporarily chdir to tmp so relative paths work
        old_cwd = os.getcwd()
        os.chdir(self.tmp)
        try:
            generate_mk_file(config, str(self.output_mk))
            with open(self.output_mk, "r") as f:
                return f.read()
        finally:
            os.chdir(old_cwd)

    def test_build_env_mk_with_rtl_ip(self):
        """RTL IP sources appear in SYN_FILES in build_env.mk."""
        ip_path = self._make_ip_yml("ip/uart", "uart_core", mode="rtl", sources=["src/uart_tx.vhd", "src/uart_rx.vhd"])
        config = {
            "project": {"name": "test", "top_module": "top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "sources": {"ips": [ip_path]},
        }
        content = self._gen_mk(config)
        self.assertIn("SYN_FILES", content)
        self.assertIn("uart_tx.vhd", content)
        self.assertIn("uart_rx.vhd", content)

    def test_build_env_mk_with_xci_ip(self):
        """XCI IP appears in XCI_FILES in build_env.mk."""
        ip_path = self._make_ip_yml("ip/fifo", "fifo_ip", mode="xci", sources=["fifo_gen.xci"])
        config = {
            "project": {"name": "test", "top_module": "top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "sources": {"ips": [ip_path]},
        }
        content = self._gen_mk(config)
        self.assertIn("IP_IP_FILES", content)
        self.assertIn("fifo_gen.xci", content)
        self.assertIn("XCI_FILES", content)

    def test_build_env_mk_with_netlist_ip(self):
        """NETLIST_FILES emitted in build_env.mk."""
        ip_path = self._make_ip_yml("ip/crypto", "crypto", mode="netlist", sources=["crypto_core.edf"])
        config = {
            "project": {"name": "test", "top_module": "top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "sources": {"ips": [ip_path]},
        }
        content = self._gen_mk(config)
        self.assertIn("NETLIST_FILES", content)
        self.assertIn("crypto_core.edf", content)

    def test_build_env_mk_vendor_mismatch(self):
        """project_manager.py exits 1 on vendor mismatch."""
        ip_path = self._make_ip_yml("ip/pll", "pll_ip", mode="qsys", sources=["pll.qsys"])
        config = {
            "project": {"name": "test", "top_module": "top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "sources": {"ips": [ip_path]},
        }
        old_cwd = os.getcwd()
        os.chdir(self.tmp)
        try:
            with self.assertRaises(SystemExit) as cm:
                generate_mk_file(config, str(self.output_mk))
            self.assertEqual(cm.exception.code, 1)
        finally:
            os.chdir(old_cwd)

    def test_build_env_mk_mixed_ips(self):
        """RTL + XCI + netlist IPs → all correct variables."""
        rtl_ip = self._make_ip_yml("ip/uart", "uart", mode="rtl", sources=["src/uart.vhd"])
        xci_ip = self._make_ip_yml("ip/fifo", "fifo", mode="xci", sources=["fifo.xci"])
        net_ip = self._make_ip_yml("ip/crypto", "crypto", mode="netlist", sources=["crypto.edf"])
        config = {
            "project": {"name": "test", "top_module": "top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "sources": {"ips": [rtl_ip, xci_ip, net_ip]},
        }
        content = self._gen_mk(config)
        self.assertIn("uart.vhd", content)
        self.assertIn("fifo.xci", content)
        self.assertIn("crypto.edf", content)
        self.assertIn("NETLIST_FILES", content)


class TestIpUpdateScan(unittest.TestCase):
    """Test scan_sources.py --ip-update functionality."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_ip_update_scan(self):
        """mode:rtl IP with paths.sources → rr update populates synthesis.sources."""
        # Create IP directory with source files
        ip_dir = self.tmp / "ip" / "uart"
        src_dir = ip_dir / "src"
        src_dir.mkdir(parents=True)
        (src_dir / "uart_tx.vhd").touch()
        (src_dir / "uart_rx.vhd").touch()

        # Create ip.yml with empty sources
        ip_yml = ip_dir / "ip.yml"
        with open(ip_yml, "w") as f:
            f.write("ip:\n  name: uart_core\n\npaths:\n  sources: src\n\nsynthesis:\n  mode: rtl\n  sources: []\n")

        # Create project.yml referencing it
        proj_yml = self.tmp / "project.yml"
        with open(proj_yml, "w") as f:
            f.write("project:\n  name: test\nsources:\n  ips:\n    - ip/uart/ip.yml\n")

        # Run update
        update_ip_manifests(str(proj_yml))

        # Verify ip.yml was updated
        with open(ip_yml, "r") as f:
            content = f.read()

        self.assertIn("uart_tx.vhd", content)
        self.assertIn("uart_rx.vhd", content)

    def test_ip_update_prunes_stale(self):
        """--ip-update removes non-existent files from ip.yml."""
        # Create IP directory with only 1 source file
        ip_dir = self.tmp / "ip" / "uart"
        src_dir = ip_dir / "src"
        src_dir.mkdir(parents=True)
        (src_dir / "uart_tx.vhd").touch()

        # Create ip.yml with existing entry for a deleted file
        ip_yml = ip_dir / "ip.yml"
        with open(ip_yml, "w") as f:
            f.write(
                "ip:\n  name: uart_core\n\npaths:\n  sources: src\n\nsynthesis:\n  mode: rtl\n  sources:\n    - src/uart_tx.vhd\n    - src/uart_rx_deleted.vhd\n"
            )

        # Create project.yml
        proj_yml = self.tmp / "project.yml"
        with open(proj_yml, "w") as f:
            f.write("project:\n  name: test\nsources:\n  ips:\n    - ip/uart/ip.yml\n")

        # Run update
        update_ip_manifests(str(proj_yml))

        # Verify stale entry was removed
        with open(ip_yml, "r") as f:
            content = f.read()

        self.assertIn("uart_tx.vhd", content)
        self.assertNotIn("uart_rx_deleted.vhd", content)

    def test_ip_init_creates_scaffold(self):
        """init_ip.py creates directory, ip.yml, and src/."""
        old_cwd = os.getcwd()
        os.chdir(self.tmp)
        try:
            # Create minimal project.yml for vendor detection
            with open("project.yml", "w") as f:
                f.write("project:\n  name: test\nhardware:\n  vendor: xilinx\n")

            import subprocess

            init_script = str(TOOLS_DIR / "init_ip.py")
            result = subprocess.run(
                [sys.executable, init_script, "--name", "test_ip", "--non-interactive"], capture_output=True, text=True
            )

            self.assertEqual(result.returncode, 0, f"init_ip.py failed: {result.stderr}")

            # Verify scaffold
            self.assertTrue((self.tmp / "ip" / "test_ip" / "ip.yml").exists())
            self.assertTrue((self.tmp / "ip" / "test_ip" / "src").is_dir())

            # Verify ip.yml content
            with open(self.tmp / "ip" / "test_ip" / "ip.yml", "r") as f:
                data = yaml.safe_load(f)
            self.assertEqual(data["ip"]["name"], "test_ip")
            self.assertEqual(data["synthesis"]["mode"], "rtl")
        finally:
            os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()
