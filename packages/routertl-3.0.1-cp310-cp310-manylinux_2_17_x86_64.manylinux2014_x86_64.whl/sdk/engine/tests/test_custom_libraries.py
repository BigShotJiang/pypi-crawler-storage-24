# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import shutil
import subprocess
import unittest
from pathlib import Path

import yaml

# Paths
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_TOOL = REPO_ROOT / "sdk" / "engine" / "project_manager.py"
LINTER_TOOL = REPO_ROOT / "sdk" / "engine" / "smart_linter.py"


class TestCustomVhdlLibraries(unittest.TestCase):
    def setUp(self):
        self.env = os.environ.copy()
        # Clean up env
        for var in ["PYTHONHOME", "PYTHONPATH"]:
            if var in self.env:
                del self.env[var]

        self.test_dir = REPO_ROOT / "test_lib_workspace"
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.test_dir.mkdir()

        self.project_yml = self.test_dir / "project.yml"
        self.src_dir = self.test_dir / "src"
        self.pkg_dir = self.src_dir / "pkg"
        self.units_dir = self.src_dir / "units"

        self.pkg_dir.mkdir(parents=True)
        self.units_dir.mkdir(parents=True)

        # Mock Regbank files to satisfy Common.mk dependencies
        self.regbank_dir = self.src_dir / "regbank"
        self.regbank_dir.mkdir()
        (self.regbank_dir / "regbank_schema.hex").touch()
        (self.regbank_dir / "config_schema.hex").touch()
        (self.src_dir / "pkg" / "system_config_pkg.vhd").touch()

    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

        # Clean repository side-effects
        for f in ["build_env.mk", "build_env.tcl"]:
            p = REPO_ROOT / f
            if p.exists():
                p.unlink()

        cache_dir = REPO_ROOT / ".routertl_cache"
        if cache_dir.exists():
            lib_json = cache_dir / "libraries.json"
            if lib_json.exists():
                lib_json.unlink()

    def check_tool(self, tool_name):
        try:
            subprocess.run(["which", tool_name], capture_output=True, check=True)
            return True
        except subprocess.CalledProcessError:
            return False

    def test_custom_library_flow(self):
        """
        Tests the full flow:
        1. VHDL package in custom library
        2. Entity using that library
        3. project_manager serializes libraries
        4. smart_linter compiles and lints
        """
        if not self.check_tool("ghdl"):
            self.skipTest("GHDL not found")

        # 1. Create Mock VHDL Files
        mock_pkg = self.pkg_dir / "mock_pkg.vhd"
        with open(mock_pkg, "w") as f:
            f.write("""
library IEEE;
use IEEE.STD_LOGIC_1164.all;

package mock_pkg is
    constant MOCK_VAL : integer := 42;
end package mock_pkg;
""")

        mock_top = self.units_dir / "mock_top.vhd"
        with open(mock_top, "w") as f:
            f.write("""
library IEEE;
use IEEE.STD_LOGIC_1164.all;

library mocklib;
use mocklib.mock_pkg.all;

entity mock_top is
    port (
        clk : in std_logic;
        val : out integer
    );
end entity mock_top;

architecture rtl of mock_top is
begin
    val <= MOCK_VAL;
end architecture rtl;
""")

        # 2. Create project.yml
        config = {
            "project": {"name": "test_mock_lib", "top_module": "mock_top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "features": {"regbank": False},
            "sources": {
                "syn": [str(mock_pkg.relative_to(REPO_ROOT)), str(mock_top.relative_to(REPO_ROOT))],
                "libraries": {"mocklib": [str(mock_pkg.relative_to(REPO_ROOT))]},
            },
        }
        with open(self.project_yml, "w") as f:
            yaml.dump(config, f)

        # 3. Run project_manager to generate build_env.mk and libraries.json
        # We must point SRC_DIR to our temp workspace src so it finds the mock regbank
        cmd = [
            "make",
            f"PROJECT_YML={self.project_yml.relative_to(REPO_ROOT)}",
            f"SRC_DIR={self.src_dir.relative_to(REPO_ROOT)}",
            "project",
        ]
        res = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)
        self.assertEqual(res.returncode, 0, f"Make project failed (stdout: {res.stdout}): {res.stderr}")

        lib_json = REPO_ROOT / ".routertl_cache" / "libraries.json"
        self.assertTrue(lib_json.exists(), "libraries.json was not created")

        # 4. Run smart_linter
        # Also need SRC_DIR here so linter finds the files
        cmd = ["make", "linting", "TOP=mock_top", f"SRC_DIR={self.src_dir.relative_to(REPO_ROOT)}"]
        res = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)

        print(f"Linter STDOUT:\n{res.stdout}")
        print(f"Linter STDERR:\n{res.stderr}")

        self.assertEqual(res.returncode, 0, "Linting failed for custom library")
        self.assertIn("Compiling Custom Libraries", res.stdout)
        self.assertIn("mocklib", res.stdout)
        self.assertIn("PASS", res.stdout)

    def test_auto_detection_flow(self):
        """
        Tests the auto-detection logic in scan_sources.py
        """
        if not self.check_tool("ghdl"):
            self.skipTest("GHDL not found")

        # 1. Create Mock VHDL Files (without project.yml library entries)
        mock_pkg = self.pkg_dir / "auto_pkg.vhd"
        with open(mock_pkg, "w") as f:
            f.write("""
package auto_pkg is
end package auto_pkg;
""")

        mock_top = self.units_dir / "auto_top.vhd"
        with open(mock_top, "w") as f:
            f.write("""
library autolib;
use autolib.auto_pkg.all;
entity auto_top is end;
""")

        # 2. Create minimal project.yml
        config = {
            "project": {"name": "test_auto_lib", "top_module": "auto_top"},
            "hardware": {"vendor": "xilinx", "part": "xc7z020"},
            "features": {"regbank": False},
            "sources": {"syn": [str(mock_pkg.relative_to(REPO_ROOT)), str(mock_top.relative_to(REPO_ROOT))]},
        }
        with open(self.project_yml, "w") as f:
            yaml.dump(config, f)

        # 3. Run make update-src
        cmd = [
            "make",
            "update-src",
            f"PROJECT_YML={self.project_yml.relative_to(REPO_ROOT)}",
            f"SRC_DIR={self.test_dir.relative_to(REPO_ROOT)}",
        ]
        res = subprocess.run(cmd, cwd=REPO_ROOT, capture_output=True, text=True, env=self.env)
        self.assertEqual(res.returncode, 0, f"make update-src failed: {res.stderr}")

        # 4. Verify project.yml was updated with libraries
        with open(self.project_yml, "r") as f:
            updated_config = yaml.safe_load(f)

        self.assertIn("libraries", updated_config["sources"])
        self.assertIn("autolib", updated_config["sources"]["libraries"])
        # scan_sources makes paths relative to the project.yml file
        rel_pkg_path = str(mock_pkg.relative_to(self.test_dir))
        self.assertIn(rel_pkg_path, updated_config["sources"]["libraries"]["autolib"])


if __name__ == "__main__":
    unittest.main()
