# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Unit tests for smart_linter helper functions.

Tests the pure helper functions extracted from main() to eliminate
code duplication across --top and --forest code paths.
"""

import sys
from pathlib import Path

# Add project root to path
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
PM_DIR = REPO_ROOT / "sdk" / "engine"
sys.path.append(str(PM_DIR))

from smart_linter import _partition_files


class TestPartitionFiles:
    """Tests for _partition_files — the file filtering/partitioning helper."""

    ROOT = "/project"

    def test_partition_files_filters_compiled(self):
        """Files in compiled_set are removed from both VHDL and SV outputs."""
        files = ["/project/a.vhd", "/project/b.sv", "/project/c.vhd"]
        compiled = {"/project/a.vhd", "/project/b.sv"}
        vhdl, sv, skipped = _partition_files(files, compiled, set(), self.ROOT)
        assert vhdl == ["/project/c.vhd"]
        assert sv == []
        assert skipped == []

    def test_partition_files_separates_vhdl_sv(self):
        """.vhd → vhdl_files, .sv/.v/.vh/.svh → sv_files."""
        files = [
            "/project/top.vhd",
            "/project/mod.vhdl",
            "/project/alu.sv",
            "/project/fifo.v",
            "/project/defs.vh",
            "/project/pkg.svh",
        ]
        vhdl, sv, skipped = _partition_files(files, set(), set(), self.ROOT)
        assert vhdl == ["/project/top.vhd", "/project/mod.vhdl"]
        assert sv == ["/project/alu.sv", "/project/fifo.v",
                       "/project/defs.vh", "/project/pkg.svh"]
        assert skipped == []

    def test_partition_files_applies_excludes(self):
        """Both absolute and relative-to-root paths appear in skipped_files."""
        files = [
            "/project/hw/rtl/a.vhd",
            "/project/hw/rtl/b.sv",
            "/project/hw/rtl/c.vhd",
        ]
        # Exclude by relative path for a.vhd, by absolute path for b.sv
        exclude = {"hw/rtl/a.vhd", "/project/hw/rtl/b.sv"}
        vhdl, sv, skipped = _partition_files(files, set(), exclude, self.ROOT)
        assert vhdl == ["/project/hw/rtl/c.vhd"]
        assert sv == []
        assert sorted(skipped) == sorted([
            "/project/hw/rtl/a.vhd",
            "/project/hw/rtl/b.sv",
        ])

    def test_partition_files_empty_input(self):
        """Empty input → three empty lists."""
        vhdl, sv, skipped = _partition_files([], set(), set(), self.ROOT)
        assert vhdl == []
        assert sv == []
        assert skipped == []

    def test_partition_files_compiled_takes_priority_over_exclude(self):
        """A file in compiled_set is silently skipped, not added to skipped_files."""
        files = ["/project/a.vhd"]
        compiled = {"/project/a.vhd"}
        exclude = {"/project/a.vhd"}
        vhdl, sv, skipped = _partition_files(files, compiled, exclude, self.ROOT)
        assert vhdl == []
        assert sv == []
        assert skipped == []  # compiled takes priority, not reported as skipped

    def test_partition_files_non_relative_path_fallback(self):
        """Files outside root_dir still checked against exclude by abs path."""
        files = ["/other/path/x.sv"]
        exclude = {"/other/path/x.sv"}
        vhdl, sv, skipped = _partition_files(files, set(), exclude, self.ROOT)
        assert skipped == ["/other/path/x.sv"]
        assert sv == []
