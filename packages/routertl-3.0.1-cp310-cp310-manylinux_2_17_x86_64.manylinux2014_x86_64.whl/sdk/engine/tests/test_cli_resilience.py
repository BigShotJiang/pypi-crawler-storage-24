# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
CLI Resilience Tests — Bulletproof YAML handling.

Every command that reads project.yml must survive:
  1. Missing project.yml          → clean error message, no traceback
  2. Empty / null project.yml     → graceful handling
  3. YAML null values (bare keys) → no TypeError from len(None) / iter(None)
  4. Wrong types (str↔list↔dict)  → no AttributeError / TypeError
  5. Malformed YAML               → no unhandled yaml.YAMLError

If any CLI command prints a Python traceback for user-editable input,
that is a test failure.
"""

import sys
import unittest
from pathlib import Path

from click.testing import CliRunner

# Add repo root to path so `from sdk.*` resolves from any cwd
REPO_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sdk.cli.main import cli

# ── Poisoned YAML Configs ──────────────────────────────────────

# All top-level keys present but set to YAML null
YAML_ALL_NULLS = """\
project:
hardware:
simulation:
sources:
hooks:
features:
dependencies:
linux:
paths:
branding:
cicd:
"""

# Sources with null lists (the original crash)
YAML_NULL_SOURCES = """\
project:
  name: null_proj
  top_module: top
hardware:
  vendor: xilinx
  part: xc7z020clg400-1
  language: vhdl
simulation:
  test_dir: sim/cocotb/tests
sources:
  syn:
  sim:
  xdc:
  ip:
hooks:
  pre_commit:
    enabled: true
    lint: true
    tests:
"""

# Wrong types: scalars where dicts/lists expected
YAML_WRONG_TYPES = """\
project: "not_a_dict"
hardware: 42
simulation: true
sources: "flat_string"
hooks: []
features: "string_instead_of_dict"
dependencies: "also_string"
linux: 123
paths: false
"""

# Empty file (yaml.safe_load returns None)
YAML_EMPTY = ""

# Minimal valid project
YAML_MINIMAL = """\
project:
  name: mini
  top_module: mini_top
hardware:
  vendor: xilinx
  part: xc7z020clg400-1
  language: vhdl
"""


class TestCLIResilience(unittest.TestCase):
    """Every CLI command must exit cleanly (no Python traceback) under
    hostile project.yml content."""

    def setUp(self):
        self.runner = CliRunner()

    # ── Helpers ────────────────────────────────────────────────

    def _invoke_in_sandbox(self, args, yaml_content=None):
        """Run a CLI command inside an isolated filesystem.

        If yaml_content is not None, write it to project.yml first.
        Returns the CliRunner Result.
        """
        with self.runner.isolated_filesystem():
            if yaml_content is not None:
                with open("project.yml", "w") as f:
                    f.write(yaml_content)
            return self.runner.invoke(cli, args, catch_exceptions=False)

    def _assert_no_traceback(self, result, context=""):
        """Assert that the CLI output does not contain a raw Python traceback."""
        output = (result.output or "") + (getattr(result, "stderr", None) or "")
        self.assertNotIn(
            "Traceback (most recent call last)",
            output,
            f"CLI printed a Python traceback{' (' + context + ')' if context else ''}:\n{result.output}",
        )

    # ── Test Matrix ────────────────────────────────────────────
    # For every command that reads project.yml, test all poison configs.

    # ── status ─────────────────────────────────────────────────

    def test_status_missing_yml(self):
        r = self._invoke_in_sandbox(["status"])
        self._assert_no_traceback(r)

    def test_status_empty_yml(self):
        r = self._invoke_in_sandbox(["status"], YAML_EMPTY)
        self._assert_no_traceback(r)

    def test_status_all_nulls(self):
        r = self._invoke_in_sandbox(["status"], YAML_ALL_NULLS)
        self._assert_no_traceback(r)

    def test_status_null_sources(self):
        r = self._invoke_in_sandbox(["status"], YAML_NULL_SOURCES)
        self._assert_no_traceback(r)
        self.assertIn("null_proj", r.output)

    def test_status_wrong_types(self):
        r = self._invoke_in_sandbox(["status"], YAML_WRONG_TYPES)
        self._assert_no_traceback(r)

    def test_status_minimal(self):
        r = self._invoke_in_sandbox(["status"], YAML_MINIMAL)
        self._assert_no_traceback(r)
        self.assertIn("mini", r.output)

    # ── sources ────────────────────────────────────────────────

    def test_sources_missing_yml(self):
        r = self._invoke_in_sandbox(["sources"])
        self._assert_no_traceback(r)

    def test_sources_empty_yml(self):
        r = self._invoke_in_sandbox(["sources"], YAML_EMPTY)
        self._assert_no_traceback(r)

    def test_sources_all_nulls(self):
        r = self._invoke_in_sandbox(["sources"], YAML_ALL_NULLS)
        self._assert_no_traceback(r)

    def test_sources_null_sources(self):
        r = self._invoke_in_sandbox(["sources"], YAML_NULL_SOURCES)
        self._assert_no_traceback(r)

    def test_sources_wrong_types(self):
        r = self._invoke_in_sandbox(["sources"], YAML_WRONG_TYPES)
        self._assert_no_traceback(r)

    def test_sources_count_flag_with_nulls(self):
        r = self._invoke_in_sandbox(["sources", "--count"], YAML_NULL_SOURCES)
        self._assert_no_traceback(r)

    # ── doctor ─────────────────────────────────────────────────

    def test_doctor_missing_yml(self):
        r = self._invoke_in_sandbox(["doctor"])
        self._assert_no_traceback(r)

    def test_doctor_empty_yml(self):
        r = self._invoke_in_sandbox(["doctor"], YAML_EMPTY)
        self._assert_no_traceback(r)

    def test_doctor_all_nulls(self):
        r = self._invoke_in_sandbox(["doctor"], YAML_ALL_NULLS)
        self._assert_no_traceback(r)

    def test_doctor_wrong_types(self):
        r = self._invoke_in_sandbox(["doctor"], YAML_WRONG_TYPES)
        self._assert_no_traceback(r)

    # ── report ─────────────────────────────────────────────────

    def test_report_missing_yml(self):
        r = self._invoke_in_sandbox(["report"])
        self._assert_no_traceback(r)

    def test_report_empty_yml(self):
        r = self._invoke_in_sandbox(["report"], YAML_EMPTY)
        self._assert_no_traceback(r)

    def test_report_all_nulls(self):
        r = self._invoke_in_sandbox(["report"], YAML_ALL_NULLS)
        self._assert_no_traceback(r)

    def test_report_md_format(self):
        r = self._invoke_in_sandbox(["report", "--format", "md"], YAML_ALL_NULLS)
        self._assert_no_traceback(r)

    # ── sim (no-op checks, no make required) ──────────────────

    def test_sim_history_missing_yml(self):
        r = self._invoke_in_sandbox(["sim", "--history"])
        self._assert_no_traceback(r)

    def test_sim_history_all_nulls(self):
        r = self._invoke_in_sandbox(["sim", "--history"], YAML_ALL_NULLS)
        self._assert_no_traceback(r)

    def test_sim_tag_missing_yml(self):
        """--tag should fail cleanly when no tags section exists."""
        r = self._invoke_in_sandbox(["sim", "--tag", "smoke"], YAML_MINIMAL)
        self._assert_no_traceback(r)

    def test_sim_tag_null_tags(self):
        r = self._invoke_in_sandbox(
            ["sim", "--tag", "smoke"],
            YAML_MINIMAL + "  tags:\n",  # null tags
        )
        self._assert_no_traceback(r)

    # ── deps ───────────────────────────────────────────────────

    def test_deps_missing_yml(self):
        """deps should fall back to default src dir."""
        with self.runner.isolated_filesystem():
            import os

            os.makedirs("src", exist_ok=True)
            r = self.runner.invoke(cli, ["deps"], catch_exceptions=False)
            self._assert_no_traceback(r)

    def test_deps_null_paths(self):
        with self.runner.isolated_filesystem():
            import os

            os.makedirs("src", exist_ok=True)
            with open("project.yml", "w") as f:
                f.write("paths:\n")  # null
            r = self.runner.invoke(cli, ["deps"], catch_exceptions=False)
            self._assert_no_traceback(r)

    def test_deps_wrong_type_paths(self):
        with self.runner.isolated_filesystem():
            import os

            os.makedirs("src", exist_ok=True)
            with open("project.yml", "w") as f:
                f.write("paths: 42\n")
            r = self.runner.invoke(cli, ["deps"], catch_exceptions=False)
            self._assert_no_traceback(r)

    # ── info ───────────────────────────────────────────────────

    def test_info_missing_yml(self):
        r = self._invoke_in_sandbox(["info"])
        self._assert_no_traceback(r)

    def test_info_all_nulls(self):
        r = self._invoke_in_sandbox(["info"], YAML_ALL_NULLS)
        self._assert_no_traceback(r)

    def test_info_wrong_types(self):
        r = self._invoke_in_sandbox(["info"], YAML_WRONG_TYPES)
        self._assert_no_traceback(r)

    # ── watch (help only, actual watch requires inotify) ──────

    def test_watch_help(self):
        r = self._invoke_in_sandbox(["watch", "--help"])
        self._assert_no_traceback(r)
        self.assertEqual(r.exit_code, 0)

    # ── diff ───────────────────────────────────────────────────

    def test_diff_help(self):
        r = self._invoke_in_sandbox(["diff", "--help"])
        self._assert_no_traceback(r)
        self.assertEqual(r.exit_code, 0)

    # ── completion ─────────────────────────────────────────────

    def test_completion_bash_no_yml(self):
        r = self._invoke_in_sandbox(["completion", "bash"])
        self._assert_no_traceback(r)
        self.assertEqual(r.exit_code, 0)

    # ── All commands accept --help without project.yml ─────────

    def test_all_commands_help_no_project_yml(self):
        """Every registered command's --help must work without project.yml."""
        with self.runner.isolated_filesystem():
            for name in sorted(cli.commands.keys()):
                with self.subTest(command=name):
                    r = self.runner.invoke(cli, [name, "--help"], catch_exceptions=False)
                    self._assert_no_traceback(r, context=f"{name} --help")
                    self.assertEqual(
                        r.exit_code,
                        0,
                        f"'{name} --help' exited with code {r.exit_code}",
                    )

    # ── Malformed YAML ─────────────────────────────────────────

    def test_status_malformed_yaml(self):
        r = self._invoke_in_sandbox(["status"], ":\n  - :\n    bad: [unmatched")
        self._assert_no_traceback(r)

    def test_sources_malformed_yaml(self):
        r = self._invoke_in_sandbox(["sources"], ":\n  - :\n    bad: [unmatched")
        self._assert_no_traceback(r)

    def test_doctor_malformed_yaml(self):
        r = self._invoke_in_sandbox(["doctor"], ":\n  - :\n    bad: [unmatched")
        self._assert_no_traceback(r)


class TestMakefileAlignment(unittest.TestCase):
    """Every _run_make() target in CLI commands must exist in Common.mk.

    This prevents the class of bug where a CLI command delegates to a
    Makefile target that doesn't exist (e.g. the update-sdk incident).
    """

    @staticmethod
    def _parse_makefile_targets(makefile_path):
        """Extract all target names from a Makefile and its includes."""
        import re

        targets = set()
        # Scan Common.mk itself
        files_to_scan = [makefile_path]
        # Also scan the sdk/mk/ include directory
        mk_dir = makefile_path.parent / "mk"
        if mk_dir.is_dir():
            files_to_scan.extend(sorted(mk_dir.glob("*.mk")))
        for mk_file in files_to_scan:
            with open(mk_file, "r") as f:
                for line in f:
                    # Match lines like "target-name:" or "target-name: deps ## comment"
                    # Skip variable assignments and lines starting with whitespace
                    m = re.match(r"^([a-zA-Z_][a-zA-Z0-9_-]*)\s*:", line)
                    if m:
                        targets.add(m.group(1))
        return targets

    @staticmethod
    def _parse_run_make_calls(directory):
        """Extract all _run_make("target") calls from Python files."""
        import re
        from pathlib import Path

        calls = []  # list of (file, line_no, target)
        for py_file in Path(directory).glob("*.py"):
            with open(py_file) as f:
                for i, line in enumerate(f, 1):
                    for m in re.finditer(r'_run_make\(\s*["\']([^"\']+)["\']', line):
                        calls.append((py_file.name, i, m.group(1)))
        return calls

    def test_all_run_make_targets_exist_in_common_mk(self):
        """Every _run_make('target') must have a matching target in Common.mk."""
        from pathlib import Path

        # Locate files relative to this test
        test_dir = Path(__file__).resolve().parent
        sdk_root = test_dir.parent.parent.parent  # tests -> project-manager -> tools -> SDK root
        common_mk = sdk_root / "sdk" / "Common.mk"
        commands_dir = sdk_root / "sdk" / "cli" / "commands"

        self.assertTrue(common_mk.exists(), f"Common.mk not found at {common_mk}")
        self.assertTrue(commands_dir.exists(), f"Commands dir not found at {commands_dir}")

        makefile_targets = self._parse_makefile_targets(common_mk)
        run_make_calls = self._parse_run_make_calls(commands_dir)

        self.assertGreater(len(makefile_targets), 0, "No targets found in Common.mk")
        self.assertGreater(len(run_make_calls), 0, "No _run_make() calls found")

        missing = []
        for filename, line_no, target in run_make_calls:
            if target not in makefile_targets:
                missing.append(f'  {filename}:{line_no} → _run_make("{target}")')

        if missing:
            self.fail(
                f"{len(missing)} CLI _run_make() call(s) reference targets "
                f"not found in Common.mk:\n" + "\n".join(missing)
            )


class TestDockerEnvFile(unittest.TestCase):
    """Verify docker.sh always passes --env-file to docker compose.

    Without --env-file, docker compose reads .env from its working directory
    instead of the project root where rr docker config/setup writes variables
    like QUARTUS_INSTALLER_PATH and LM_LICENSE_FILE.  This caused a
    hard-to-debug failure where installer paths were silently ignored.
    """

    def test_all_docker_compose_calls_pass_env_file(self):
        """Every compose invocation in docker.sh must include $ENV_FILE_FLAG."""
        from pathlib import Path

        test_dir = Path(__file__).resolve().parent
        sdk_root = test_dir.parent.parent.parent
        docker_sh = sdk_root / "sdk" / "infra" / "docker" / "docker.sh"

        self.assertTrue(docker_sh.exists(), f"docker.sh not found at {docker_sh}")

        content = docker_sh.read_text()
        lines = content.splitlines()

        # Find all lines that invoke $COMPOSE_CMD (ignoring comments and echo)
        compose_calls = []
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            # Match $COMPOSE_CMD calls (the auto-detected compose command)
            if "$COMPOSE_CMD " in stripped:
                compose_calls.append((i, stripped))

        self.assertGreater(len(compose_calls), 0, "No $COMPOSE_CMD calls found in docker.sh")

        missing = []
        for line_no, line in compose_calls:
            if "$ENV_FILE_FLAG" not in line and "ENV_FILE_FLAG" not in line:
                missing.append(f"  line {line_no}: {line}")

        if missing:
            self.fail(
                f"{len(missing)} compose call(s) in docker.sh are "
                f"missing $ENV_FILE_FLAG:\n"
                + "\n".join(missing)
                + "\n\nThis means .env from the project root will NOT be read, "
                "breaking QUARTUS_INSTALLER_PATH, LM_LICENSE_FILE, etc."
            )

    def test_env_file_flag_is_defined(self):
        """docker.sh must define ENV_FILE_FLAG from PROJECT_ROOT/.env."""
        from pathlib import Path

        docker_sh = Path(__file__).resolve().parent.parent.parent.parent / "sdk" / "infra" / "docker" / "docker.sh"
        content = docker_sh.read_text()

        self.assertIn("ENV_FILE_FLAG", content, "docker.sh must define ENV_FILE_FLAG")
        self.assertIn("--env-file", content, "docker.sh must use --env-file to pass .env path")


class TestRichMarkupHygiene(unittest.TestCase):
    """click.confirm() and click.prompt() do NOT render Rich markup.

    Any Rich tags (e.g. [cyan], [/], [bold], [dim]) inside these calls
    will leak as raw text to the terminal.  This test statically scans
    all CLI command files and fails if any are found.

    Regression: 2026-03-10 — ``Build [cyan]sim[/] first?`` was printed
    verbatim by click.confirm() in docker.py.
    """

    @staticmethod
    def _scan_for_rich_in_click_prompts(directory):
        """Return list of (file, line_no, line) where click.confirm or
        click.prompt contains Rich markup tags."""
        import re
        from pathlib import Path

        # Matches Rich tags like [cyan], [/], [bold red], [dim], [green]…
        rich_tag_re = re.compile(r"\[/?[a-z_ ]+\]")
        # Matches click.confirm(...) or click.prompt(...)
        click_prompt_re = re.compile(r"click\.(confirm|prompt)\(")

        hits = []
        for py_file in sorted(Path(directory).rglob("*.py")):
            with open(py_file) as f:
                for i, line in enumerate(f, 1):
                    if click_prompt_re.search(line) and rich_tag_re.search(line):
                        hits.append((py_file.name, i, line.strip()))
        return hits

    def test_no_rich_markup_in_click_prompts(self):
        """click.confirm/click.prompt must never contain Rich tags."""
        from pathlib import Path

        sdk_root = Path(__file__).resolve().parent.parent.parent.parent
        commands_dir = sdk_root / "sdk" / "cli" / "commands"
        self.assertTrue(commands_dir.is_dir(), f"Commands dir missing: {commands_dir}")

        hits = self._scan_for_rich_in_click_prompts(commands_dir)
        if hits:
            details = "\n".join(f"  {f}:{ln}  {code}" for f, ln, code in hits)
            self.fail(
                f"{len(hits)} click.confirm/prompt call(s) contain Rich "
                f"markup that will leak as raw text:\n{details}\n\n"
                f"Fix: use plain text in click.confirm/prompt, or use "
                f"rich.prompt.Confirm instead."
            )

class TestStableIncludePath(unittest.TestCase):
    """Consumer Makefiles must use the root-level Common.mk shim.

    The SDK provides a stable ``Common.mk`` at its root that forwards
    to ``sdk/Common.mk``.  Consumer Makefiles must include THIS file,
    never the internal ``sdk/Common.mk`` or legacy ``tools/Common.mk``
    directly.  If they do, an internal directory rename (like
    tools/ → sdk/) silently breaks all consumers.

    Regression: 2026-03-11 — The tools/ → sdk/ rename broke the
    consumer Makefile inside Docker because ``-include`` silently
    ignores missing files.
    """

    def _sdk_root(self):
        from pathlib import Path

        return Path(__file__).resolve().parent.parent.parent.parent

    def test_root_common_mk_shim_exists(self):
        """The root-level Common.mk shim must exist."""
        shim = self._sdk_root() / "Common.mk"
        self.assertTrue(
            shim.exists(),
            "Root-level Common.mk shim is missing — consumers will break. "
            "Create a shim that includes sdk/Common.mk.",
        )

    def test_root_common_mk_shim_forwards(self):
        """The shim must include sdk/Common.mk."""
        shim = self._sdk_root() / "Common.mk"
        if not shim.exists():
            self.skipTest("Shim doesn't exist (covered by previous test)")
        content = shim.read_text()
        self.assertIn(
            "sdk/Common.mk",
            content,
            "Root Common.mk shim must forward to sdk/Common.mk",
        )

    def test_examples_use_stable_path(self):
        """No example Makefile should include sdk/Common.mk or tools/Common.mk."""
        import re

        examples_dir = self._sdk_root() / "examples"
        if not examples_dir.is_dir():
            self.skipTest("No examples/ directory")

        # Matches -include ... sdk/Common.mk or tools/Common.mk
        internal_re = re.compile(r"-?include\b.*(?:sdk|tools)/Common\.mk")

        violations = []
        for makefile in sorted(examples_dir.rglob("Makefile")):
            for i, line in enumerate(makefile.read_text().splitlines(), 1):
                if line.strip().startswith("#"):
                    continue
                if internal_re.search(line):
                    rel = makefile.relative_to(self._sdk_root())
                    violations.append(f"  {rel}:{i}  {line.strip()}")

        if violations:
            self.fail(
                f"{len(violations)} example Makefile(s) bypass the root "
                f"Common.mk shim by including internal paths:\n"
                + "\n".join(violations)
                + "\n\nFix: use -include $(SDK_SUBMODULE_PATH)/Common.mk"
            )

    def test_init_project_generates_stable_path(self):
        """init_project.py (or its scaffold sub-module) must generate Makefiles with the stable root path."""
        sdk_root = self._sdk_root()
        # P2.67: the Makefile template moved to sdk/engine/init/scaffold.py
        scaffold_py = sdk_root / "sdk" / "engine" / "init" / "scaffold.py"
        init_py = sdk_root / "sdk" / "engine" / "init_project.py"

        # At least one of these must exist
        candidates = [p for p in (scaffold_py, init_py) if p.exists()]
        self.assertTrue(candidates, "Neither scaffold.py nor init_project.py found")

        # Check all candidates for the stable path
        found_stable = False
        for path in candidates:
            content = path.read_text()
            if "-include $(SDK_ROOT)/Common.mk" in content:
                found_stable = True
                break

        self.assertTrue(
            found_stable,
            "init_project.py / scaffold.py must generate -include $(SDK_ROOT)/Common.mk "
            "(root-level shim), not sdk/Common.mk or tools/Common.mk.",
        )

        # Check that no candidate generates the internal path in template strings
        for path in candidates:
            content = path.read_text()
            lines = content.splitlines()
            in_replace = False
            for i, line in enumerate(lines, 1):
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                if ".replace(" in line:
                    in_replace = True
                if in_replace:
                    if ")" in line and ".replace(" not in line:
                        in_replace = False
                    continue
                if "sdk/Common.mk" in line and "-include" in line:
                    self.fail(
                        f"{path.name}:{i} generates an internal path "
                        f"'sdk/Common.mk' in an -include directive. "
                        f"Use the root-level Common.mk instead."
                    )

    def test_manifest_includes_common_mk(self):
        """MANIFEST.in must include Common.mk for pip sdist."""
        manifest = self._sdk_root() / "MANIFEST.in"
        if not manifest.exists():
            self.skipTest("No MANIFEST.in")
        content = manifest.read_text()
        self.assertIn(
            "Common.mk",
            content,
            "MANIFEST.in must include Common.mk so pip-installed "
            "SDK ships the stable Makefile entry point.",
        )

    def test_manifest_includes_mk_files(self):
        """MANIFEST.in must include *.mk for the build system."""
        manifest = self._sdk_root() / "MANIFEST.in"
        if not manifest.exists():
            self.skipTest("No MANIFEST.in")
        content = manifest.read_text()
        # Check that recursive-include sdk line has *.mk

        sdk_line = [l for l in content.splitlines() if l.startswith("recursive-include sdk")]
        self.assertTrue(sdk_line, "MANIFEST.in must have a recursive-include sdk line")
        self.assertIn(
            "*.mk",
            sdk_line[0],
            "MANIFEST.in recursive-include sdk must include *.mk "
            "so that Common.mk, platform.mk, sim.mk etc. ship in the sdist.",
        )


if __name__ == "__main__":
    unittest.main()
