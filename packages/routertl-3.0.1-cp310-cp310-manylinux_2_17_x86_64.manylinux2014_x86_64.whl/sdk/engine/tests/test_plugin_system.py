# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Unit tests for the RouteRTL plugin discovery system.

Tests _load_plugins() with mocked entry points to verify correct
loading, error handling, and type validation.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

_sdk_root = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(_sdk_root))

import click

from sdk.cli.main import _load_plugins


class TestPluginDiscovery(unittest.TestCase):
    """Tests for _load_plugins()."""

    def _make_entry_point(self, name, load_return, group="routertl.plugins"):
        """Create a mock entry point."""
        ep = MagicMock()
        ep.name = name
        ep.group = group
        ep.load.return_value = load_return
        return ep

    @patch("importlib.metadata.entry_points")
    def test_no_plugins(self, mock_eps):
        """No plugins installed — returns empty list."""
        mock_eps.return_value = {}
        result = _load_plugins("routertl.plugins")
        self.assertEqual(result, [])

    @patch("importlib.metadata.entry_points")
    def test_load_valid_command(self, mock_eps):
        """Valid Click command is loaded successfully."""

        @click.command()
        def hello():
            pass

        ep = self._make_entry_point("hello", hello)

        # Simulate Python 3.9-3.11 dict-style entry_points
        mock_eps.return_value = {"routertl.plugins": [ep]}

        result = _load_plugins("routertl.plugins")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0][0], "hello")
        self.assertIs(result[0][1], hello)

    @patch("importlib.metadata.entry_points")
    def test_load_valid_group(self, mock_eps):
        """Valid Click group is loaded successfully."""

        @click.group()
        def tools():
            pass

        ep = self._make_entry_point("tools", tools)
        mock_eps.return_value = {"routertl.plugins": [ep]}

        result = _load_plugins("routertl.plugins")
        self.assertEqual(len(result), 1)
        self.assertIsInstance(result[0][1], click.Command)

    @patch("importlib.metadata.entry_points")
    def test_skip_non_click_object(self, mock_eps):
        """Non-Click objects are skipped with a warning."""
        ep = self._make_entry_point("bad_plugin", "not_a_command")
        mock_eps.return_value = {"routertl.plugins": [ep]}

        result = _load_plugins("routertl.plugins")
        self.assertEqual(result, [])

    @patch("importlib.metadata.entry_points")
    def test_skip_on_import_error(self, mock_eps):
        """Import errors are caught and the plugin is skipped."""
        ep = self._make_entry_point("broken", None)
        ep.load.side_effect = ImportError("module not found")
        mock_eps.return_value = {"routertl.plugins": [ep]}

        result = _load_plugins("routertl.plugins")
        self.assertEqual(result, [])

    @patch("importlib.metadata.entry_points")
    def test_multiple_plugins(self, mock_eps):
        """Multiple valid plugins are all loaded."""

        @click.command()
        def cmd_a():
            pass

        @click.command()
        def cmd_b():
            pass

        eps = [
            self._make_entry_point("cmd_a", cmd_a),
            self._make_entry_point("cmd_b", cmd_b),
        ]
        mock_eps.return_value = {"routertl.plugins": eps}

        result = _load_plugins("routertl.plugins")
        self.assertEqual(len(result), 2)
        names = {r[0] for r in result}
        self.assertEqual(names, {"cmd_a", "cmd_b"})

    @patch("importlib.metadata.entry_points")
    def test_selectable_groups_api(self, mock_eps):
        """Test with Python 3.12+ select() API."""

        @click.command()
        def modern():
            pass

        ep = self._make_entry_point("modern", modern)

        # Simulate SelectableGroups with select() method
        mock_result = MagicMock()
        mock_result.select.return_value = [ep]
        mock_eps.return_value = mock_result

        result = _load_plugins("routertl.plugins")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0][0], "modern")

    @patch("importlib.metadata.entry_points")
    def test_entry_points_exception(self, mock_eps):
        """If entry_points() itself throws, return empty."""
        mock_eps.side_effect = Exception("metadata broken")
        result = _load_plugins("routertl.plugins")
        self.assertEqual(result, [])

    @patch("importlib.metadata.entry_points")
    def test_wrong_group_ignored(self, mock_eps):
        """Plugins in other groups are not loaded."""
        mock_eps.return_value = {"other.group": [MagicMock()]}
        result = _load_plugins("routertl.plugins")
        self.assertEqual(result, [])


if __name__ == "__main__":
    unittest.main()
