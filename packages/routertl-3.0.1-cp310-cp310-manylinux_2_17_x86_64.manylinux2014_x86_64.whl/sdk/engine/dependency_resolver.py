# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Proxy — real implementation in routertl_core.dependency_resolver."""
import sys
from pathlib import Path

# Ensure routertl_core is importable
_REPO_ROOT = str(Path(__file__).resolve().parents[2])
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

# Re-export ALL names (including _private) from the core module
import routertl_core.dependency_resolver as _mod  # noqa: E402

globals().update({k: v for k, v in vars(_mod).items() if not k.startswith("__")})

if __name__ == "__main__":
    _mod.main()
