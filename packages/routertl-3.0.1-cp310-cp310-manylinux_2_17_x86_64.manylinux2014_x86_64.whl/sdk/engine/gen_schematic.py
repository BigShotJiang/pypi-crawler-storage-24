#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""gen_schematic.py — Generate RTL schematics via Yosys+GHDL with library support.

Handles VHDL library declarations by pre-analyzing package files with
--work=<lib> before elaborating the top entity. This fixes 'cannot find
resource library' errors when entities use custom libraries.
"""

import subprocess
import sys
from pathlib import Path

# Resolve SDK paths relative to this script
SCRIPT_DIR = Path(__file__).parent.resolve()
SDK_ROOT = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(SCRIPT_DIR))

from dependency_resolver import DependencyResolver
from scan_sources import detect_vhdl_libraries


def main():
    """CLI entry point for schematic generator."""
    import argparse

    parser = argparse.ArgumentParser(description="Generate RTL schematic SVG")
    parser.add_argument("--top", required=True, help="Top entity/module name")
    parser.add_argument("--src", required=True, nargs="+", help="Source directories")
    parser.add_argument("--out", default="sim/schematics", help="Output directory")
    parser.add_argument("--skin", default=None, help="Beautifier CSS skin name")
    args = parser.parse_args()

    src_dirs = [Path(s) for s in args.src]
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Validate source directories exist
    valid_dirs = [d for d in src_dirs if d.exists()]
    if not valid_dirs:
        print(f"❌ No valid source directories found: {args.src}")
        sys.exit(1)

    # 1. Resolve dependencies (returns files in compilation order)
    resolver = DependencyResolver(valid_dirs, verbose=False)
    if args.top not in resolver.entity_map and args.top not in resolver.package_map:
        print(f"❌ Entity '{args.top}' not found in {', '.join(str(d) for d in valid_dirs)}")
        sys.exit(1)

    dep_files = resolver.resolve_dependencies(args.top)
    if not dep_files:
        print(f"❌ No source files resolved for '{args.top}'")
        sys.exit(1)

    # Early check: is yosys available?
    import shutil

    if not shutil.which("yosys"):
        print("❌ yosys not found on PATH.")
        print("   Schematic generation requires Yosys (+ GHDL plugin for VHDL).")
        print("   💡 Tip: run inside the Docker sim environment:")
        print("      rr docker shell")
        print("      rr schematic " + args.top)
        sys.exit(1)

    # Determine language
    is_vhdl = any(str(f).endswith((".vhd", ".vhdl")) for f in dep_files)

    if not is_vhdl:
        # Verilog/SV — simple path, no library issues
        src_list = " ".join(str(f) for f in dep_files)
        json_out = out_dir / f"{args.top}.json"
        cmd = f"read_verilog {src_list}; prep -top {args.top}; write_json {json_out}"
        result = subprocess.run(["yosys", "-q", "-p", cmd], check=False)
        if result.returncode != 0:
            print("❌ Yosys failed. Schematic generation aborted.")
            sys.exit(1)
    else:
        # VHDL — need library-aware compilation
        # Get all source files (relative to project root for library detection)
        project_root = Path.cwd()
        all_src_files = [str(f.relative_to(project_root)) if f.is_absolute() else str(f) for f in dep_files]

        # Detect library assignments
        lib_map = detect_vhdl_libraries(all_src_files, str(project_root))

        # Build GHDL command sequence:
        # 1. Analyze library files with --work=<lib>
        # 2. Elaborate top entity
        ghdl_cmds = []

        # Collect files that belong to a library
        lib_files = set()
        for lib_name, lib_file_list in lib_map.items():
            for lf in lib_file_list:
                abs_lf = str(project_root / lf)
                ghdl_cmds.append(f"ghdl --std=08 -a --work={lib_name} {abs_lf}")
                lib_files.add(Path(lf).resolve())

        # Analyze remaining files in default 'work' library (in dependency order)
        for f in dep_files:
            f_resolved = Path(f).resolve()
            if f_resolved not in lib_files and str(f).endswith((".vhd", ".vhdl")):
                ghdl_cmds.append(f"ghdl --std=08 -a {f}")

        # Elaborate
        ghdl_cmds.append(f"ghdl --std=08 -e {args.top}")

        # Write JSON
        json_out = out_dir / f"{args.top}.json"
        ghdl_cmds.append(f"prep -top {args.top}")
        ghdl_cmds.append(f"write_json {json_out}")

        # Join into a single Yosys script
        yosys_script = "; ".join(ghdl_cmds)
        result = subprocess.run(
            ["yosys", "-q", "-m", "ghdl", "-p", yosys_script],
            check=False,
        )
        if result.returncode != 0:
            print("❌ Yosys (GHDL plugin) failed. Schematic generation aborted.")
            # Show helpful hint about library errors
            print(f"   💡 Tip: check if '{args.top}' uses custom libraries.")
            print(f"   Detected libraries: {list(lib_map.keys()) if lib_map else '(none)'}")
            sys.exit(1)

    # 3. Convert JSON to SVG
    json_out = out_dir / f"{args.top}.json"
    svg_out = out_dir / f"{args.top}.svg"

    if not json_out.exists():
        print("❌ JSON netlist not generated.")
        sys.exit(1)

    # Check for netlistsvg
    try:
        subprocess.run(["netlistsvg", "--help"], capture_output=True, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        print("❌ netlistsvg not found. Please install: npm install -g netlistsvg")
        sys.exit(1)

    result = subprocess.run(
        ["netlistsvg", str(json_out), "-o", str(svg_out)],
        check=False,
    )
    if result.returncode != 0:
        print("❌ netlistsvg failed.")
        sys.exit(1)

    # 4. Beautify SVG
    try:
        from beautify_svg import beautify_svg

        beautify_svg(str(svg_out), skin=args.skin)
    except ImportError:
        pass

    print(f"✅ Schematic generated: {svg_out}")


if __name__ == "__main__":
    main()
