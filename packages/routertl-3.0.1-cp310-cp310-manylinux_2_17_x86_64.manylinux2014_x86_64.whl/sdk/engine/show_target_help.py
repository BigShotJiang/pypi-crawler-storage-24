#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
show_target_help.py
Extracts and renders detailed, man-page style help for a Make target
by parsing the SDK_USER_GUIDE.md and other Markdown files.
"""

import os
import re
import sys

from rich.console import Console as _Console

_help_con = _Console()


def render_help(target):
    """Render and display target-specific help text."""
    # Resolve absolute paths to the docs folder relative to this script
    script_dir = os.path.dirname(os.path.realpath(__file__))
    docs_path = os.path.abspath(os.path.join(script_dir, "..", "..", "docs"))

    # The documentation files we will search through for the target
    # We recursively find all .md files in docs/ to be resilient to directory changes
    doc_files = []
    for root, _, files in os.walk(docs_path):
        for f in files:
            if f.endswith(".md"):
                doc_files.append(os.path.join(root, f))

    found = False

    for doc in doc_files:
        if not os.path.exists(doc):
            continue

        with open(doc, "r", encoding="utf-8") as f:
            lines = f.readlines()

        in_section = False
        section_level = 0
        section_content = []

        for line in lines:
            # Match headers like:
            # "## make scan-tests"
            # "### scan-tests"
            # "## `make sim`"
            header_match = re.match(r"^(#{2,})\s+(?:`?make\s+)?([a-zA-Z0-9_-]+)`?\s*$", line)

            if header_match:
                level = len(header_match.group(1))
                h_target = header_match.group(2)

                if not in_section and h_target == target:
                    in_section = True
                    section_level = level
                    section_content.append(f"[bold blue]=== Help for target: {target} ===[/]\n")
                    continue
                elif in_section and level <= section_level:
                    # We reached the next section of the same or higher priority
                    break

            if in_section:
                section_content.append(line)

        if in_section:
            found = True
            rendered = "".join(section_content)

            # Extremely basic Markdown to Rich markup rendering
            # Fenced code blocks (```lang ... ```) — render as indented cyan
            def _render_code_block(m):
                code = m.group(1)
                lines = code.strip("\n").split("\n")
                rendered_lines = [f"  [cyan]{l}[/]" for l in lines]
                return "\n".join(rendered_lines)

            rendered = re.sub(r"```\w*\n(.*?)```", _render_code_block, rendered, flags=re.DOTALL)
            # Bold
            rendered = re.sub(r"\*\*(.*?)\*\*", r"[bold]\1[/]", rendered)
            # Inline code
            rendered = re.sub(r"`([^`\n]+)`", r"[cyan]\1[/]", rendered)
            # Headings (smaller ones inside)
            rendered = re.sub(r"^(#{3,})\s+(.*)$", r"[bold yellow]\2[/]", rendered, flags=re.MULTILINE)
            # Quotes/Tips
            rendered = re.sub(r"^>\s(.*)$", r"[magenta]  | \1[/]", rendered, flags=re.MULTILINE)

            _help_con.print(rendered.strip())
            break

    if not found:
        _help_con.print(f"[red]Error:[/] No detailed help found for target '[bold]{target}[/]'.")
        _help_con.print("Run 'make help' for a standard list of available targets, or ensure the target is documented.")
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        _help_con.print("Usage: python3 show_target_help.py <target_name>")
        sys.exit(1)

    for target in sys.argv[1:]:
        render_help(target)
        if target != sys.argv[-1]:
            _help_con.print("\n" + "-" * 50 + "\n")

