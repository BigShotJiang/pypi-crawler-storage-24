# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: diff — Impact analysis from git diff."""

from sdk.cli.resilience import cli_resilient, cli_resilient_block


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


import os
import subprocess
import sys
from pathlib import Path

import rich_click as click
from rich.table import Table

from sdk.cli.console import console

# RTL file extensions we care about
_RTL_EXTENSIONS = {".vhd", ".vhdl", ".v", ".sv", ".vh", ".svh"}


def _parse_git_diff(ref: str = None) -> list:
    """Run `git diff` and extract changed file paths.

    Parameters
    ----------
    ref : str, optional
        Git ref to diff against (e.g. ``HEAD~1``, ``main``).
        When *None* the unstaged working-tree diff is used.
    """
    cmd = ["git", "diff", "--name-only"]
    if ref:
        cmd.append(ref)

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return []

    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def _filter_rtl_files(paths: list) -> list:
    """Keep only files with RTL extensions."""
    return [p for p in paths if Path(p).suffix.lower() in _RTL_EXTENSIONS]


def _find_test_for_entity(entity: str, test_names: list) -> str | None:
    """Heuristic: match entity name to a test_<name>.py module."""
    entity_lower = entity.lower()
    for test in test_names:
        # test_uart_sniffer ↔ uart_sniffer
        test_stem = test.replace("test_", "", 1)
        if entity_lower == test_stem or entity_lower in test_stem or test_stem in entity_lower:
            return test
    return None


@click.command(name="diff")
@click.argument("ref", required=False, default=None)
@click.option("--src", "src_dir", default=None, help="Source directory to scan (default: from project.yml or 'src').")
def diff_command(ref, src_dir):
    """Analyze git diff and suggest which tests to re-run.

    Parses `git diff` output to find changed RTL files, walks the reverse
    dependency tree, and maps affected entities to their test modules.

    \\b
    Examples:
        routertl diff              # unstaged changes
        routertl diff HEAD~1       # last commit
        routertl diff main         # diff against main branch
    """

    # 1. Parse git diff
    changed = _parse_git_diff(ref)
    if not changed:
        console.print("✅ [green]No changes detected.[/]")
        return

    rtl_files = _filter_rtl_files(changed)
    if not rtl_files:
        console.print("ℹ️  [blue]No RTL files in diff — no tests to suggest.[/]")
        return

    console.print(f"\n🔍 [blue]Found {len(rtl_files)} changed RTL file(s):[/]")
    for f in rtl_files:
        console.print(f"   [cyan]{f}[/]")

    # 2. Build resolver
    import yaml

    if not src_dir:
        if os.path.exists("project.yml"):
            with cli_resilient_block("project.yml source dir parsing"):
                with open("project.yml", "r") as fh:
                    config = yaml.safe_load(fh)
                    src_dir = config.get("sources", {}).get("src_dir", "src")
        else:
            src_dir = "src"

    src_path = Path(src_dir)
    if not src_path.exists():
        console.print(
            f"⚠️  [yellow]Source directory '{src_dir}' not found — skipping dependency analysis.[/]"
        )
        return

    # Lazy import to avoid circular / heavy load when not needed
    sys.path.insert(0, str(Path(__file__).parent.parent.parent / "project-manager"))
    from dependency_resolver import DependencyResolver

    resolver = DependencyResolver([src_path], verbose=False)

    # 3. Get discovered tests for matching
    test_names = []
    with cli_resilient_block("test name discovery"):
        from sdk.cli.commands.sim import get_discovered_tests

        test_names = get_discovered_tests()

    # 4. Walk reverse dependencies
    affected_entities: set = set()
    for rtl in rtl_files:
        rtl_path = Path(rtl).resolve()
        if not rtl_path.exists():
            continue
        dependents = resolver.reverse_dependents(rtl_path)
        affected_entities.update(dependents)

        # Also add the entity defined in the changed file itself
        for name, p in {**resolver.entity_map, **resolver.package_map}.items():
            if p.resolve() == rtl_path:
                affected_entities.add(name)

    if not affected_entities:
        console.print(
            "\nℹ️  [blue]Changed files are not part of the scanned source tree — no impact detected.[/]"
        )
        return

    # 5. Map to tests
    console.print(
        f"\n📊 [blue]Impact analysis — {len(affected_entities)} affected entity/module(s):[/]"
    )

    table = Table(show_lines=False)
    table.add_column("Entity / Module", style="cyan", min_width=25)
    table.add_column("Suggested Test", min_width=30)
    table.add_column("Command", style="dim")

    suggested_tests: set = set()
    for entity in sorted(affected_entities):
        test = _find_test_for_entity(entity, test_names)
        if test:
            suggested_tests.add(test)
            table.add_row(entity, f"[green]{test}[/green]", f"{_cli_name()} sim {test}")
        else:
            table.add_row(entity, "[dim]—[/dim]", "")

    console.print(table)

    if suggested_tests:
        console.print("\n💡 [green]Suggested re-run:[/]")
        for t in sorted(suggested_tests):
            console.print(f"   [cyan]{_cli_name()} sim {t}[/]")
    else:
        console.print("\n⚠️  [yellow]No matching test modules found for affected entities.[/]")
        console.print(f"   Run [cyan]{_cli_name()} scan-tests[/] to verify your test inventory.")
