# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Status — Project Health Dashboard.

Provides a one-command overview of the project state: identity, SDK version,
test count, source counts, and configuration staleness warnings.
"""


from sdk.cli.resilience import cli_resilient, cli_resilient_block


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


import os
import subprocess
from datetime import datetime
from pathlib import Path

import rich_click as click
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


@cli_resilient("project YAML loading", default=None)
def _read_project_yml():
    """Load project.yml from the current directory."""
    yml_path = Path("project.yml")
    if not yml_path.exists():
        return None
    with open(yml_path, "r") as f:
        data = yaml.safe_load(f)
    return data if isinstance(data, dict) else None


def _get_sdk_version():
    """Read the SDK version from the VERSION file and git history."""
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_root = resolve_sdk_root()
    if sdk_root is None:
        # Last resort: check CWD
        if Path("VERSION").exists():
            sdk_root = Path(".")
        else:
            return "unknown", None

    # Read major.minor from VERSION file
    version_file = sdk_root / "VERSION"
    major = "0"
    minor = "0"
    with cli_resilient_block("VERSION file parsing"):
        for line in version_file.read_text().splitlines():
            line = line.strip()
            if line.startswith("#") or not line:
                continue
            if line.startswith("system_major="):
                major = line.split("=", 1)[1].strip()
            elif line.startswith("system_minor="):
                minor = line.split("=", 1)[1].strip()

    # Get patch version from git commit count
    patch = "0"
    with cli_resilient_block("git commit count"):
        result = subprocess.run(
            ["git", "-C", str(sdk_root), "rev-list", "--count", "HEAD"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            patch = result.stdout.strip()

    version_str = f"v{major}.{minor}.{patch}"

    # Check if we're behind remote
    behind = None
    with cli_resilient_block("SDK remote freshness check"):
        # Suppress SSH host key prompts (e.g. inside Docker containers)
        fetch_env = {**os.environ, "GIT_SSH_COMMAND": "ssh -o StrictHostKeyChecking=accept-new -o BatchMode=yes"}
        subprocess.run(["git", "-C", str(sdk_root), "fetch", "--quiet"], capture_output=True, timeout=10, env=fetch_env)
        result = subprocess.run(
            ["git", "-C", str(sdk_root), "rev-list", "--count", "HEAD..@{u}"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            count = int(result.stdout.strip())
            if count > 0:
                behind = count

    return version_str, behind


def _get_sdk_commit():
    """Get the current SDK commit hash."""
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_root = resolve_sdk_root() or Path(".")
    with cli_resilient_block("SDK commit hash"):
        result = subprocess.run(
            ["git", "-C", str(sdk_root), "log", "-1", "--format=%h"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return result.stdout.strip()
    return None


def _count_sources(config):
    """Count sources by category from project.yml."""
    sources = config.get("sources") or {}
    if not isinstance(sources, dict):
        sources = {}
    counts = {
        "syn": len(sources.get("syn") or []),
        "sim": len(sources.get("sim") or []),
        "xdc": len(sources.get("xdc") or []),
        "sdc": len(sources.get("sdc") or []),
        "ip": len(sources.get("ip") or []),
        "tcl": len(sources.get("tcl") or []),
    }
    return counts


def _discover_tests(config):
    """Discover cocotb test files from the configured directory."""
    sim_config = config.get("simulation") or {}
    if not isinstance(sim_config, dict):
        sim_config = {}
    test_dir = sim_config.get("test_dir", "sim/cocotb/tests")
    sim_path = Path(test_dir)
    if not sim_path.exists():
        return []
    tests = []
    for f in sim_path.rglob("test_*.py"):
        tests.append(f.stem)
    return sorted(set(tests))


def _check_build_env_staleness():
    """Check if build_env.mk is older than project.yml."""
    yml_path = Path("project.yml")
    env_path = Path("build_env.mk")
    if not yml_path.exists() or not env_path.exists():
        return None  # Can't determine

    yml_mtime = yml_path.stat().st_mtime
    env_mtime = env_path.stat().st_mtime

    if yml_mtime > env_mtime:
        delta = datetime.fromtimestamp(yml_mtime) - datetime.fromtimestamp(env_mtime)
        return delta
    return False  # Up to date


def _check_mmap(config):
    """Check if system_memory_map.yml exists and count devices."""
    # Check system_config path or standard location
    mmap_path = None
    for candidate in ["system_memory_map.yml", "hw/system_memory_map.yml"]:
        if Path(candidate).exists():
            mmap_path = Path(candidate)
            break

    if mmap_path is None:
        return None, 0

    with cli_resilient_block("memory map loading"):
        with open(mmap_path, "r") as f:
            mmap = yaml.safe_load(f)
        devices = mmap.get("devices") or []
        return str(mmap_path), len(devices)
    return str(mmap_path), 0


def _check_dependencies(config):
    """Check if dependencies are cloned."""
    deps = config.get("dependencies") or {}
    if not isinstance(deps, dict):
        return None
    if not deps:
        return None
    result = {}
    for name, dep_config in deps.items():
        dep_path = dep_config.get("path", "")
        result[name] = Path(dep_path).exists() if dep_path else False
    return result


@click.command(name="status")
def status():
    """
    Display a project health dashboard.

    Shows project identity, SDK version, discovered tests, source file counts,
    embedded Linux status, and configuration warnings.
    """
    console = Console()

    config = _read_project_yml()
    if config is None:
        console.print("[bold red]❌ No project.yml found in current directory.[/]")
        console.print(f"[dim]Run [bold]{_cli_name()} init[/bold] to create a project.[/dim]")
        return

    # ── Header ──
    project = config.get("project") or {}
    if not isinstance(project, dict):
        project = {}
    hardware = config.get("hardware") or {}
    if not isinstance(hardware, dict):
        hardware = {}
    project_name = project.get("name", "unnamed")
    top_module = project.get("top_module", "—")
    vendor = hardware.get("vendor", "—")
    part = hardware.get("part", "—")
    language = hardware.get("language", "vhdl")

    header = Text()
    header.append("📊 ", style="bold")
    header.append(f"{project_name}", style="bold cyan")
    header.append(f"  ({part}, {language.upper()})", style="dim")
    console.print(Panel(header, border_style="cyan", padding=(0, 1)))
    console.print()

    # ── Main Info Table ──
    info_table = Table(show_header=False, box=None, padding=(0, 2))
    info_table.add_column("Label", style="bold", min_width=14)
    info_table.add_column("Value")

    # SDK Version
    sdk_version, behind = _get_sdk_version()
    sdk_commit = _get_sdk_commit()
    sdk_str = f"[bold cyan]{sdk_version}[/]"
    if sdk_commit:
        sdk_str += f" [dim]({sdk_commit})[/dim]"
    if behind:
        sdk_str += f"  [yellow]⚠ {behind} commit{'s' if behind > 1 else ''} behind remote[/]"
    info_table.add_row("🔧 SDK", sdk_str)

    # Hardware
    info_table.add_row("🎯 Top Module", f"[cyan]{top_module}[/]")
    info_table.add_row("🏭 Vendor", f"{vendor}")

    # Simulator — $SIM env var takes priority over project.yml
    sim_config = config.get("simulation") or {}
    if not isinstance(sim_config, dict):
        sim_config = {}
    yml_sim = sim_config.get("simulator") or "nvc"
    env_sim = os.environ.get("SIM")
    if env_sim:
        sim_display = f"{env_sim}"
        if env_sim != yml_sim:
            sim_display += f"  [dim](overrides project.yml '{yml_sim}')[/dim]"
    else:
        sim_display = f"{yml_sim}"
    info_table.add_row("🔬 Simulator", sim_display)

    console.print(info_table)
    console.print()

    # ── EDA Tools ──
    import shutil

    _EDA_TOOLS = [
        ("nvc", "NVC", "nvc --version", r"nvc (\d+\.\d+\.\d+)"),
        ("ghdl", "GHDL", "ghdl --version", r"GHDL (\d+\.\d+\.\d+)"),
        ("verilator", "Verilator", "verilator --version", r"Verilator (\d+\.\d+)"),
        ("vivado", "Vivado", "vivado -version", r"Vivado v(\d+\.\d+)"),
        ("quartus_sh", "Quartus", "quartus_sh --version", r"Version (\d+\.\d+)"),
    ]
    import re as _re

    tool_parts = []
    for binary, label, ver_cmd, ver_re in _EDA_TOOLS:
        path = shutil.which(binary)
        if path:
            # Quick version grab (timeout 3s to avoid hangs)
            ver = ""
            with cli_resilient_block(f"EDA tool version: {label}"):
                proc = subprocess.run(
                    ver_cmd.split(),
                    capture_output=True,
                    text=True,
                    timeout=3,
                    env={**os.environ, "VERILATOR_ROOT": ""} if binary == "verilator" else None,
                )
                m = _re.search(ver_re, proc.stdout + proc.stderr)
                if m:
                    ver = f" {m.group(1)}"
            tool_parts.append(f"[green]✅ {label}{ver}[/]")
    if tool_parts:
        console.print(f"  [bold]🔧 EDA Tools[/] {', '.join(tool_parts)}")

    # ── Tests ──
    tests = _discover_tests(config)
    test_dir = sim_config.get("test_dir", "sim/cocotb/tests")
    test_str = f"[bold green]{len(tests)}[/] discovered"
    test_str += f"  [dim](in {test_dir})[/dim]"
    console.print(f"  [bold]🧪 Tests[/]     {test_str}")

    # ── Sources ──
    counts = _count_sources(config)
    parts = []
    if counts["syn"]:
        parts.append(f"[cyan]{counts['syn']}[/] syn")
    if counts["sim"]:
        parts.append(f"[cyan]{counts['sim']}[/] sim")
    xdc_count = counts["xdc"] + counts["sdc"]
    if xdc_count:
        parts.append(f"[cyan]{xdc_count}[/] constraints")
    if counts["ip"]:
        parts.append(f"[cyan]{counts['ip']}[/] IP")
    if counts["tcl"]:
        parts.append(f"[cyan]{counts['tcl']}[/] TCL")
    sources_str = ", ".join(parts) if parts else "[dim]none tracked[/dim]"
    console.print(f"  [bold]📁 Sources[/]   {sources_str}")

    # ── Dependencies ──
    deps = _check_dependencies(config)
    if deps:
        all_ok = all(deps.values())
        if all_ok:
            dep_str = f"[green]✅ {len(deps)} libraries present[/]"
        else:
            missing = [k for k, v in deps.items() if not v]
            dep_str = f"[yellow]⚠ Missing: {', '.join(missing)}[/]"
        console.print(f"  [bold]📚 Deps[/]      {dep_str}")

    # ── Embedded Linux ──
    mmap_path, device_count = _check_mmap(config)
    linux_config = config.get("linux") or {}
    if mmap_path or linux_config:
        if mmap_path:
            linux_str = f"[green]{mmap_path}[/] ({device_count} device{'s' if device_count != 1 else ''})"
        else:
            linux_str = "[dim]no system_memory_map.yml[/dim]"
        console.print(f"  [bold]🐧 Linux[/]     {linux_str}")

    # ── Features ──
    features = config.get("features") or {}
    if not isinstance(features, dict):
        features = {}
    if features:
        flags = []
        for feat, enabled in features.items():
            if enabled:
                flags.append(f"[green]✓ {feat}[/]")
            else:
                flags.append(f"[dim]✗ {feat}[/dim]")
        console.print(f"  [bold]🧩 Features[/]  {', '.join(flags)}")

    # ── Hooks ──
    hooks = config.get("hooks") or {}
    if not isinstance(hooks, dict):
        hooks = {}
    pre_commit = hooks.get("pre_commit") or {}
    if not isinstance(pre_commit, dict):
        pre_commit = {}
    if pre_commit.get("enabled"):
        hook_tests = pre_commit.get("tests") or []
        hook_str = f"[green]enabled[/] ({len(hook_tests)} test{'s' if len(hook_tests) != 1 else ''})"
        if pre_commit.get("lint"):
            hook_str += " + lint"
        console.print(f"  [bold]🪝 Hooks[/]     {hook_str}")

    console.print()

    # ── Warnings ──
    warnings = []

    staleness = _check_build_env_staleness()
    if staleness is None:
        if not Path("build_env.mk").exists() and Path("project.yml").exists():
            warnings.append(f"[yellow]⚠  build_env.mk missing[/] — run: [bold]{_cli_name()} workspace update-config[/]")
    elif staleness is not False:
        days = staleness.days
        if days > 0:
            warnings.append(
                f"[yellow]⚠  build_env.mk is {days} day{'s' if days != 1 else ''} stale[/] "
                f"— run: [bold]{_cli_name()} workspace update-config[/]"
            )
        else:
            hours = int(staleness.total_seconds() // 3600)
            if hours > 0:
                warnings.append(
                    f"[yellow]⚠  build_env.mk is {hours}h stale[/] "
                    f"— run: [bold]{_cli_name()} workspace update-config[/]"
                )

    if behind:
        warnings.append(
            f"[yellow]⚠  SDK is {behind} commit{'s' if behind > 1 else ''} behind[/] "
            f"— run: [bold]{_cli_name()} workspace update-sdk[/]"
        )

    if not tests:
        warnings.append(f"[yellow]⚠  No tests discovered[/] — run: [bold]{_cli_name()} testgen[/]")

    if warnings:
        for w in warnings:
            console.print(f"  {w}")
        console.print()
