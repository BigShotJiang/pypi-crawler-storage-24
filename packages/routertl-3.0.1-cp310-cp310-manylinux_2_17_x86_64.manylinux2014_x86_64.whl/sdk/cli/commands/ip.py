# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console


def _run_make(target, *args):
    """Helper to delegate IP targets to the Master Makefile"""
    cmd = ["make", target, *args]
    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            console.print(f"\n❌ [red]Command failed (Make exit code: {result.returncode})[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] 'make' not found. Ensure build-essential is installed.")
        sys.exit(1)


# ── Register Bank Group (existing) ────────────────────────────
@click.group(name="regbank")
def regbank_group():
    """Register Bank YAML Parsing and Management."""
    pass


@regbank_group.command(name="parse")
def parse():
    """Generate VHDL package from Regbank YAML."""
    console.print("📝 [blue]Parsing Register Bank...[/]")
    _run_make("parse_regbank")


@regbank_group.command(name="add")
def add_register():
    """Add a new register to the register bank (interactive)."""
    _run_make("add-register")


@regbank_group.command(name="remove")
@click.argument("name", required=True)
def remove_register(name):
    """Remove a register from the register bank."""
    console.print(f"🗑️ [blue]Removing register [cyan]{name}[/]...")
    _run_make("remove-register", f"NAME={name}")


@click.command(name="rom")
def rom():
    """Generate ROM Data & Package."""
    console.print("📝 [blue]Generating ROM Data...[/]")
    _run_make("rom_info")


# ── IP Manifest Group (new) ───────────────────────────────────
@click.group(name="ip")
def ip_group():
    """IP Manifest Management — init, list, hierarchy, update."""
    pass


def _get_resolver():
    """Load IpResolver with project context."""
    tools_dir = Path(__file__).resolve().parent.parent.parent / "engine"
    sys.path.insert(0, str(tools_dir))
    from ip_resolver import IpResolver, load_ips_from_project

    project_yml = "project.yml"
    if not os.path.exists(project_yml):
        console.print("❌ [red]No project.yml found in current directory.[/]")
        sys.exit(1)

    ip_paths, vendor, project_root = load_ips_from_project(project_yml)
    resolver = IpResolver(project_root, vendor)
    return resolver, ip_paths


@ip_group.command(name="init")
@click.argument("name", required=False)
@click.option("--mode", default="rtl", help="Synthesis mode (rtl, xci, qsys, ipx, cxz, netlist, ooc_dcp)")
@click.option("--language", default="vhdl", help="HDL language (vhdl, systemverilog, mixed)")
@click.option("--library", default="work", help="VHDL library name")
def ip_init(name, mode, language, library):
    """Initialize a new IP manifest (ip.yml) interactively.

    Creates an ip/<name>/ directory with a pre-filled ip.yml manifest
    and (for RTL mode) an empty src/ directory.
    """
    tools_dir = Path(__file__).resolve().parent.parent.parent / "engine"
    init_script = tools_dir / "init_ip.py"

    if not init_script.exists():
        console.print(f"❌ [red]Cannot locate init_ip.py at {init_script}[/]")
        sys.exit(1)

    cmd = [sys.executable, str(init_script)]
    if name:
        cmd.extend(["--name", name])
    if mode != "rtl":
        cmd.extend(["--mode", mode])
    if language != "vhdl":
        cmd.extend(["--language", language])
    if library != "work":
        cmd.extend(["--library", library])

    try:
        subprocess.run(cmd, check=False)
    except KeyboardInterrupt:
        console.print("\n[yellow]Initialization aborted.[/]")


@ip_group.command(name="list")
def ip_list():
    """Show all IPs referenced in project.yml with their modes and status."""
    resolver, ip_paths = _get_resolver()

    if not ip_paths:
        console.print("\n  [dim]No IPs found in project.yml sources.ips[/]\n")
        console.print("  [dim]Use 'rr ip init' to create one.[/]")
        return

    result = resolver.resolve(ip_paths)

    if result.errors:
        for err in result.errors:
            console.print(f"  [red]⚠ {err}[/]")
        click.echo()

    if not result.manifests:
        console.print("\n  [dim]No valid IPs resolved.[/]")
        return

    console.print(f"\n🧩 [cyan]IP Manifest Summary[/] ({len(result.manifests)} IPs)\n")
    for m in result.manifests:
        lib_info = f"library={m.library}" if m.library != "work" else "—"
        count = f"{m.source_count} {'source' if m.source_count == 1 else 'sources'}"
        if m.mode in ("xci", "qsys", "ipx", "cxz"):
            count = f"{m.source_count} IP {'file' if m.source_count == 1 else 'files'}"
        elif m.mode in ("netlist", "ooc_dcp"):
            count = f"{m.source_count} {'netlist' if m.source_count == 1 else 'netlists'}"

        console.print(
            f"  [green]✅[/] [cyan]{m.name:<25}[/] "
            f"{m.mode:<10} [dim]{lib_info:<20}[/] [dim]{count}[/]"
        )
    click.echo()


@ip_group.command(name="hierarchy")
def ip_hierarchy():
    """Show the IP dependency tree."""
    resolver, ip_paths = _get_resolver()

    if not ip_paths:
        console.print("\n  [dim]No IPs found in project.yml sources.ips[/]")
        return

    result = resolver.resolve(ip_paths)

    if result.errors:
        for err in result.errors:
            console.print(f"  [red]⚠ {err}[/]")
        click.echo()

    if not result.manifests:
        console.print("\n  [dim]No valid IPs resolved.[/]")
        return

    console.print("\n🌳 [cyan]IP Dependency Tree[/]\n")

    # Find roots (manifests not referenced as children of others)
    child_paths = set()
    for m in result.manifests:
        for c in m.children:
            child_paths.add(str(c.path))

    roots = [m for m in result.manifests if str(m.path) not in child_paths]

    for i, root in enumerate(roots):
        is_last = i == len(roots) - 1
        _print_tree(root, "", is_last)
    click.echo()


def _print_tree(manifest, prefix, is_last):
    """Recursively print an IP tree node with box-drawing characters."""
    connector = "└── " if is_last else "├── "
    count = f"{manifest.source_count} file{'s' if manifest.source_count != 1 else ''}"
    mode_color = "[green]" if manifest.mode == "rtl" else "[yellow]"
    console.print(
        f"{prefix}{connector}[cyan]{manifest.name}[/] "
        f"({mode_color}{manifest.mode}[/], [dim]{count}[/])"
    )

    new_prefix = prefix + ("    " if is_last else "│   ")
    for i, child in enumerate(manifest.children):
        child_last = i == len(manifest.children) - 1
        _print_tree(child, new_prefix, child_last)


@ip_group.command(name="update")
def ip_update():
    """Scan RTL-mode IP directories and update ip.yml source lists."""
    console.print("🔄 [blue]Updating IP manifest source lists...[/]")
    _run_make("update-ips")
