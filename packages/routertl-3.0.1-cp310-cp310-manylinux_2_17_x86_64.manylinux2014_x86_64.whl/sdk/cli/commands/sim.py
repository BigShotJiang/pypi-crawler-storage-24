# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import json
import os
import subprocess
import sys
from pathlib import Path

# Lazy import for git_utils — available when running from SDK root or when
# sdk/engine is on sys.path.  Fail-open: if unavailable, all
# discovered files pass through unfiltered.
try:
    from sdk.engine.git_utils import filter_git_tracked as _filter_tracked
except ImportError:
    try:
        # Direct import when project-manager is already on sys.path
        from git_utils import filter_git_tracked as _filter_tracked
    except ImportError:
        _filter_tracked = None

import rich_click as click
import yaml
from rich.prompt import IntPrompt
from rich.table import Table

from sdk.cli.console import console
from sdk.cli.env_setup import resolve_sdk_script, resolve_sim_dir, setup_sim_env
from sdk.cli.resilience import cli_resilient_block
from sdk.cli.sdk_root import resolve_sdk_root

# Waveform output directories — searched in priority order
_WAVE_DIRS = (
    Path("sim") / "waves",
    Path("sim") / "cocotb" / "waves",
    Path("sim_build"),
)


def get_discovered_tests():
    """Discover all cocotb test files from the configured simulation directory."""
    if not os.path.exists("project.yml"):
        return []

    with cli_resilient_block("simulation config loading"):
        with open("project.yml", "r") as f:
            config = yaml.safe_load(f) or {}
            if not isinstance(config, dict):
                config = {}
            sim_cfg = config.get("simulation") or {}
            if not isinstance(sim_cfg, dict):
                sim_cfg = {}
            sim_dir = sim_cfg.get("test_dir", "sim/cocotb/tests")

    sim_path = Path(sim_dir)
    if not sim_path.exists():
        return []

    candidates = list(sim_path.rglob("test_*.py"))

    # Filter out untracked files — prevents WIP test_*.py from appearing
    # in the interactive menu or fuzzy matching (fail-open)
    if _filter_tracked is not None:
        candidates = _filter_tracked(candidates)

    tests = []
    for file in candidates:
        tests.append(file.stem)  # get filename without extension
    return sorted(list(set(tests)))


def _complete_testbench(ctx, param, incomplete):
    """Shell completion callback: returns discovered test names."""
    tests = get_discovered_tests()
    return [t for t in tests if t.startswith(incomplete)]


def _resolve_tags() -> dict:
    """Read simulation.tags from project.yml.

    Returns
    -------
    dict[str, list[str]]
        Mapping of tag name to list of test module names.
    """
    if not os.path.exists("project.yml"):
        return {}
    with cli_resilient_block("simulation tags loading"):
        with open("project.yml", "r") as f:
            config = yaml.safe_load(f) or {}
        sim_cfg = config.get("simulation") or {}
        if not isinstance(sim_cfg, dict):
            sim_cfg = {}
        tags = sim_cfg.get("tags") or {}
        return tags if isinstance(tags, dict) else {}
    return {}


def _run_sim_direct(module: str | None = None, *, waves: bool = False, seed: int | None = None) -> int:
    """Run simulation by calling run_tests.py directly (no Make required).

    Returns the process exit code.
    """
    script = resolve_sdk_script("project-manager/run_tests.py")
    if script is None:
        # Fallback: delegate to Make
        return _run_sim_make(module, waves=waves, seed=seed)

    env = setup_sim_env(waves=waves, seed=seed)
    sim_dir = str(resolve_sim_dir())

    cmd = [sys.executable, str(script), "--dir", sim_dir]
    if module:
        cmd.extend(["--pattern", f"{module}.py"])

    try:
        result = subprocess.run(cmd, env=env, check=False)
        return result.returncode
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] Python interpreter not found.")
        sys.exit(1)


def _run_sim_make(module: str | None = None, *, waves: bool = False, seed: int | None = None) -> int:
    """Fallback: delegate simulation to Make."""
    if module:
        cmd = ["make", "sim", f"MODULE={module}"]
    else:
        cmd = ["make", "simulation"]
    if waves:
        cmd.append("WAVES=1")
    if seed is not None:
        cmd.append(f"RANDOM_SEED={seed}")
    try:
        result = subprocess.run(cmd, check=False)
        return result.returncode
    except FileNotFoundError:
        console.print("❌ [red]'make' not found.[/]")
        sys.exit(1)


def _run_make_fallback(target: str, *args):
    """Fallback: delegate a target to Make."""
    cmd = ["make", target, *args]
    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            console.print(f"\n❌ [red]Command failed (Make exit code: {result.returncode})[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] 'make' not found.")
        sys.exit(1)


def _run_tag(tag_name: str, waves: bool = False, seed: int = None):
    """Run all tests associated with *tag_name* from simulation.tags."""
    tags = _resolve_tags()

    if not tags:
        console.print("⚠️  [yellow]No simulation.tags section found in project.yml.[/]")
        click.echo("   Add a tags mapping under 'simulation' in project.yml:")
        console.print("   [dim]simulation:")
        click.echo("     tags:")
        console.print("       smoke: [test_a, test_b][/]")
        sys.exit(1)

    if tag_name not in tags:
        available = ", ".join(sorted(tags.keys())) if tags else "(none)"
        console.print(f"❌ [red]Tag '{tag_name}' not found.[/]")
        console.print(f"   Available tags: [cyan]{available}[/]")
        sys.exit(1)

    tests = tags[tag_name]
    if not tests:
        console.print(f"⚠️  [yellow]Tag '{tag_name}' is empty — no tests to run.[/]")
        return

    console.print(f"\n🏷️  [cyan]Running tag '{tag_name}' — {len(tests)} test(s)[/]\n")

    failures = []
    for i, module in enumerate(tests, 1):
        console.print(f"  [{i}/{len(tests)}] [blue]{module}[/]")
        rc = _run_sim_direct(module, waves=waves, seed=seed)
        if rc != 0:
            failures.append(module)
            console.print("        [red]❌ FAILED[/]")
        else:
            console.print("        [green]✅ PASSED[/]")

    # Summary
    click.echo(f"\n{'─' * 50}")
    passed = len(tests) - len(failures)
    console.print(
        f"🏷️  Tag '{tag_name}': [green]{passed} passed[/], [red]{len(failures)} failed[/]"
    )
    if failures:
        console.print(f"   Failed: [red]{', '.join(failures)}[/]")
        sys.exit(1)


@click.command(name="sim")
@click.argument("testbench", required=False, shell_complete=_complete_testbench)
@click.option("--view", is_flag=True, help="Open waveform viewer after simulation completes")
@click.option("--waves", is_flag=True, hidden=True, help="[Deprecated] Alias for --view")
@click.option("--all", "run_all", is_flag=True, help="Run all discovered tests")
@click.option("--seed", type=int, default=None, help="Set random seed for reproducible simulation")
@click.option("--history", "show_history", is_flag=True, help="Show recent simulation history")
@click.option("--tag", "tag_name", default=None, help="Run a group of tests defined in simulation.tags in project.yml.")
@click.option("--clean", "-c", is_flag=True, help="Remove cached simulation artifacts first.")
def sim_command(testbench, view, waves, run_all, seed, show_history, tag_name, clean):
    """
    Run a cocotb simulation testbench.

    If TESTBENCH is not provided, an interactive menu will appear allowing you to select
    from discovered tests in the project.
    """
    # Merge --view and --waves (deprecated alias)
    open_viewer = view or waves

    # ── Handle --clean flag ──
    if clean:
        import shutil

        for cache_dir in ["sim_build", "work"]:
            p = Path(cache_dir)
            if p.exists():
                shutil.rmtree(p, ignore_errors=True)
                console.print(f"🗑️  [dim]Removed {cache_dir}[/]")
        # GHDL entity directories
        for p in Path(".").glob("e~*"):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
                console.print(f"🗑️  [dim]Removed {p}[/]")
    # ── Handle --history flag ──
    if show_history:
        _show_sim_history()
        return

    # ── Handle --tag flag ──
    if tag_name:
        _run_tag(tag_name, open_viewer, seed)
        return

    # ── Determine the module to run ──
    module = None
    is_batch = False  # True when running all tests (selection 0, --all, --tag)

    if run_all:
        console.print("🧪 [blue]Running full simulation suite...[/]")
        is_batch = True
    elif not testbench:
        tests = get_discovered_tests()
        if not tests:
            console.print(
                "🧪 [blue]No specific testbench provided and no tests discovered. Running full simulation suite...[/]"
            )
            is_batch = True
        elif not sys.stdin.isatty():
            console.print("🧪 [blue]Non-interactive mode — running full simulation suite...[/]")
            is_batch = True
        else:
            console.print("\n[bold cyan]🧪 Discovered Simulation Testbenches:[/bold cyan]")
            console.print("  [0] [bold yellow]Run ALL Tests (Regression)[/bold yellow]")
            for idx, tb in enumerate(tests, start=1):
                console.print(f"  [{idx}] {tb}")

            choice = IntPrompt.ask("\nSelect a testbench to run", choices=[str(i) for i in range(len(tests) + 1)])

            if choice == 0:
                is_batch = True  # module stays None → run all
            else:
                module = tests[choice - 1]
                console.print(f"🧪 [blue]Starting simulation for [cyan]{module}[/]...")
    else:
        # Strip the .py extension if the user accidentally provided it
        if testbench.endswith(".py"):
            testbench = testbench[:-3]
        if testbench.startswith("MODULE="):
            testbench = testbench[7:]

        # ── Fuzzy test name resolution ──
        if not testbench.startswith("test_"):
            all_tests = get_discovered_tests()
            matches = [t for t in all_tests if testbench in t]
            if len(matches) == 1:
                console.print(f"   [dim]ℹ️  Resolved '{testbench}' → {matches[0]}[/]")
                testbench = matches[0]
            elif len(matches) > 1:
                if sys.stdin.isatty():
                    console.print(f"\n[bold cyan]🧪 Multiple tests match '{testbench}':[/bold cyan]")
                    for idx, m in enumerate(matches, start=1):
                        console.print(f"  [{idx}] {m}")
                    choice = IntPrompt.ask(
                        "\nSelect a test to run",
                        choices=[str(i) for i in range(1, len(matches) + 1)],
                    )
                    testbench = matches[choice - 1]
                else:
                    console.print(
                        f"   [dim]ℹ️  Resolved '{testbench}' → {matches[0]} (first of {len(matches)} matches)[/]"
                    )
                    testbench = matches[0]

        module = testbench
        console.print(f"🧪 [blue]Starting simulation for [cyan]{module}[/]...")

    if seed is not None:
        console.print(f"🎲 [blue]Random seed: [cyan]{seed}[/]")

    # ── Execute simulation directly (no Make required) ──
    rc = _run_sim_direct(module, waves=open_viewer, seed=seed)

    if rc != 0:
        console.print(f"\n❌ [red]Simulation failed (exit code: {rc})[/]")
        _print_result_summary(module)
        sys.exit(rc)

    console.print("\n✅ [green]Simulation completed successfully.[/]")
    _print_result_summary(module)

    # ── Auto-open waveform viewer after successful simulation ──
    if open_viewer:
        _open_viewer_after_sim(module, is_batch)


def _get_results_dir():
    """Locate the simulation results directory."""
    if os.path.exists("project.yml"):
        return Path("sim") / "results"
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk = resolve_sdk_root()
    if sdk:
        return sdk / "sim" / "cocotb" / "results"
    return Path("sim") / "results"


def _print_result_summary(module=None):
    """Print a one-line summary from the latest simulation results."""
    results_dir = _get_results_dir()
    history_path = results_dir / "history.jsonl"

    if not history_path.exists():
        return

    try:
        with open(history_path, "r") as f:
            lines = f.readlines()
        if not lines:
            return

        if module:
            # Single test mode — show the last matching entry
            entry = json.loads(lines[-1].strip())
            if entry.get("module") != module:
                return
            entries = [entry]
        else:
            # Regression mode — aggregate all entries from the same run.
            # Entries from a single regression share a similar timestamp
            # (within 5 minutes of the last entry).
            from datetime import datetime, timedelta

            last = json.loads(lines[-1].strip())
            last_ts = datetime.fromisoformat(last["timestamp"])
            cutoff = last_ts - timedelta(minutes=5)

            entries = []
            for line in reversed(lines):
                line = line.strip()
                if not line:
                    continue
                entry = json.loads(line)
                ts = datetime.fromisoformat(entry["timestamp"])
                if ts >= cutoff:
                    entries.append(entry)
                else:
                    break

        passed = sum(e.get("passed", 0) for e in entries)
        failed = sum(e.get("failed", 0) for e in entries)
        errors = sum(e.get("errors", 0) for e in entries)
        duration = sum(e.get("duration_s", 0) for e in entries)
        seed_val = entries[0].get("seed") if len(entries) == 1 else None

        parts = []
        if passed:
            parts.append(f"[green]{passed} passed[/]")
        if failed:
            parts.append(f"[red]{failed} failed[/]")
        if errors:
            parts.append(f"[red]{errors} errors[/]")

        summary = ", ".join(parts)
        meta = []
        if seed_val:
            meta.append(f"seed: {seed_val}")
        meta.append(f"{duration:.2f}s")

        click.echo(f"   📊 {summary} ({', '.join(meta)})")
    except (json.JSONDecodeError, OSError, KeyError, ValueError):
        pass


def _show_sim_history():
    """Display recent simulation history as a Rich table."""
    results_dir = _get_results_dir()
    history_path = results_dir / "history.jsonl"

    if not history_path.exists():
        console.print("📊 [yellow]No simulation history found.[/]")
        _cli_name = "routertl"
        with cli_resilient_block("CLI name resolution"):
            from sdk.cli.main import CLI_NAME as _cli_name
        console.print(f"   Run a simulation first: [cyan]{_cli_name} sim <testbench>[/]")
        return

    entries = []
    try:
        with open(history_path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    except OSError:
        console.print("❌ [red]Could not read history file.[/]")
        return

    if not entries:
        console.print("📊 [yellow]History file is empty.[/]")
        return

    # Show last 20 entries
    entries = entries[-20:]



    table = Table(title="📊 Simulation History", show_lines=False)
    table.add_column("Time", style="dim", min_width=19)
    table.add_column("Module", style="cyan")
    table.add_column("Sim", style="dim")
    table.add_column("Result", min_width=12)
    table.add_column("Duration", justify="right")
    table.add_column("Seed", style="dim", justify="right")

    for e in entries:
        # Format timestamp
        ts = e.get("timestamp", "—")
        if "T" in ts:
            ts = ts.replace("T", " ")[:19]

        module_name = e.get("module", "—")
        simulator = e.get("simulator", "—")

        passed = e.get("passed", 0)
        failed = e.get("failed", 0)
        errors = e.get("errors", 0)

        if failed or errors:
            result_str = f"[red]❌ {passed}P {failed}F {errors}E[/red]"
        else:
            result_str = f"[green]✅ {passed} passed[/green]"

        duration = f"{e.get('duration_s', 0):.2f}s"
        seed_val = str(e.get("seed", "—")) if e.get("seed") else "—"

        table.add_row(ts, module_name, simulator, result_str, duration, seed_val)

    console.print(table)
    console.print(f"\n  [dim]Showing last {len(entries)} of {len(entries)} runs[/dim]")


@click.command(name="testgen")
def testgen():
    """Generate Cocotb test boilerplates for sources."""
    from sdk.cli.env_setup import resolve_src_dirs

    console.print("📝 [blue]Generating test boilerplates...[/]")
    script = resolve_sdk_script("cocotb-testgen/gen_cocotb_structure.py")
    if script:
        src_dirs = resolve_src_dirs()
        sim_dir = str(resolve_sim_dir())
        cmd = [sys.executable, str(script), "--src"] + src_dirs + ["--out", sim_dir]
        try:
            result = subprocess.run(cmd, check=False)
            if result.returncode != 0:
                console.print(f"\n❌ [red]Test generation failed (exit code: {result.returncode})[/]")
                sys.exit(result.returncode)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] Python interpreter not found.")
            sys.exit(1)
    else:
        # Fallback to make
        _run_make_fallback("testgen")


@click.command(name="scan-tests")
def scan_tests():
    """List available Cocotb tests."""
    console.print("🔍 [blue]Scanning for tests...[/]")
    script = resolve_sdk_script("project-manager/scan_tests.py")
    if script:
        sim_dir = str(resolve_sim_dir())
        cmd = [sys.executable, str(script), "--dirs", sim_dir]
        try:
            result = subprocess.run(cmd, check=False)
            if result.returncode != 0:
                sys.exit(result.returncode)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] Python interpreter not found.")
            sys.exit(1)
    else:
        _run_make_fallback("scan-tests")


def _open_viewer_after_sim(module, is_batch):
    """Open the waveform viewer after a successful simulation.

    Single test: auto-launch logic-trace on the output waveform.
    Batch mode:  print a table of waveform paths (don't open N viewers).
    """
    from sdk.cli.viewer_manager import find_gtkwave, find_latest_waveform, get_viewer_path, launch_viewer

    # Discover waveform output directories
    wave_dirs = list(_WAVE_DIRS)

    if is_batch:
        # Batch mode: list all waveform files found
        all_waveforms = []
        for d in wave_dirs:
            if d.exists():
                for ext in (".fst", ".vcd", ".ghw"):
                    all_waveforms.extend(d.rglob(f"*{ext}"))

        if all_waveforms:
            # Sort by modification time (most recent first)
            all_waveforms.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            table = Table(title="🌊 Waveform Files", show_lines=False)
            table.add_column("File", style="cyan")
            table.add_column("Size", justify="right", style="dim")
            table.add_column("Modified", style="dim")
            for wf in all_waveforms[:20]:  # Limit to 20 files
                size = wf.stat().st_size
                if size > 1_000_000:
                    size_str = f"{size / 1_000_000:.1f} MB"
                elif size > 1_000:
                    size_str = f"{size / 1_000:.1f} KB"
                else:
                    size_str = f"{size} B"
                from datetime import datetime
                mtime = datetime.fromtimestamp(wf.stat().st_mtime).strftime("%H:%M:%S")
                table.add_row(str(wf), size_str, mtime)
            console.print(table)
            console.print("\n  [dim]Open a specific waveform with:[/] [cyan]rr waves <path>[/]")
        else:
            console.print("  [dim]No waveform files found in sim/waves/ or sim_build/[/]")
        return

    # Single test: find the latest waveform and open it
    waveform = None
    for d in wave_dirs:
        waveform = find_latest_waveform(d)
        if waveform:
            break

    if not waveform:
        console.print("  [dim]No waveform files found. Use --waves flag with your simulator config.[/]")
        return

    console.print(f"🌊 [blue]Waveform:[/] [cyan]{waveform}[/]")

    # Try logic-trace first, then fall back to GTKWave
    viewer = get_viewer_path()
    if viewer:
        console.print(f"  [dim]Launching logic-trace ({viewer.name})...[/]")
        launch_viewer(waveform, viewer_path=viewer)
    else:
        gtkwave = find_gtkwave()
        if gtkwave:
            console.print("  [dim]logic-trace not available, falling back to GTKWave...[/]")
            subprocess.Popen(
                [str(gtkwave), str(waveform)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        else:
            console.print(
                "  [yellow]No waveform viewer found.[/]\n"
                "  Install logic-trace: [cyan]rr ws update-viewer[/]\n"
                "  Or install GTKWave:  [cyan]sudo apt install gtkwave[/]"
            )


@click.command(name="waves")
@click.argument("waveform_path", required=False, default=None)
def waves(waveform_path):
    """Open the waveform viewer on a file or the latest waveform.

    \b
    If WAVEFORM_PATH is provided, opens that specific file.
    Otherwise, finds the most recent .fst/.vcd/.ghw file in
    the simulation output directories.

    \b
    Examples:
        rr waves                      # open latest waveform
        rr waves sim/waves/test.fst   # open specific file
    """
    from sdk.cli.viewer_manager import find_gtkwave, find_latest_waveform, get_viewer_path, launch_viewer

    # Resolve the waveform file
    if waveform_path:
        # Handle legacy TOP= syntax
        if waveform_path.startswith("TOP="):
            waveform_path = waveform_path[4:]
        wf = Path(waveform_path)
        if not wf.exists():
            # Maybe it's a module name — search for it
            for d in _WAVE_DIRS:
                candidates = list(d.rglob(f"*{waveform_path}*")) if d.exists() else []
                if candidates:
                    wf = max(candidates, key=lambda p: p.stat().st_mtime)
                    break
            else:
                console.print(f"❌ [red]Waveform not found:[/] {waveform_path}")
                sys.exit(1)
    else:
        # Find the latest waveform
        wf = None
        for d in _WAVE_DIRS:
            wf = find_latest_waveform(d)
            if wf:
                break
        if not wf:
            console.print("❌ [red]No waveform files found.[/]")
            console.print("   Run a simulation first: [cyan]rr sim <testbench> --view[/]")
            sys.exit(1)

    console.print(f"🌊 [blue]Opening waveform viewer for [cyan]{wf}[/]...")

    # Try logic-trace first, then GTKWave fallback
    viewer = get_viewer_path()
    if viewer:
        console.print(f"  [dim]Using logic-trace ({viewer.name})[/]")
        launch_viewer(wf, viewer_path=viewer)
        console.print("✅ [green]Viewer launched.[/]")
    else:
        gtkwave = find_gtkwave()
        if gtkwave:
            console.print("  [dim]logic-trace not available, using GTKWave...[/]")
            subprocess.Popen(
                [str(gtkwave), str(wf)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            console.print("✅ [green]GTKWave launched.[/]")
        else:
            console.print(
                "❌ [red]No waveform viewer available.[/]\n"
                "   Install logic-trace: [cyan]rr ws update-viewer[/]\n"
                "   Or install GTKWave:  [cyan]sudo apt install gtkwave[/]"
            )
            sys.exit(1)


@click.command(name="regression")
def regression():
    """Run SDK Internal Regression Tests."""
    console.print("🧪 [blue]Running SDK Regression Tests...[/]")
    script = resolve_sdk_script("project-manager/run_tests.py")
    if script:
        sdk_root = resolve_sdk_root()
        test_dir = str(sdk_root / "sdk" / "engine" / "tests")
        env = setup_sim_env()
        cmd = [sys.executable, str(script), "--dir", test_dir, "--pattern", "test_*.py"]
        try:
            result = subprocess.run(cmd, env=env, check=False)
            if result.returncode != 0:
                console.print(f"\n❌ [red]Regression failed (exit code: {result.returncode})[/]")
                sys.exit(result.returncode)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] Python interpreter not found.")
            sys.exit(1)
    else:
        _run_make_fallback("regression")


@click.command(name="view-log")
@click.argument("test_name", required=False, default=None)
def view_sim_log(test_name):
    """View a simulation log.

    If TEST_NAME is provided, shows that specific test's log.
    Otherwise opens the most recent simulation log.
    """
    if test_name:
        # Strip .py extension if provided
        if test_name.endswith(".py"):
            test_name = test_name[:-3]

        # Search for the log file
        log_candidates = [
            Path("sim") / "cocotb" / "logs" / f"{test_name}.log",
            Path("sim") / "logs" / f"{test_name}.log",
        ]
        for log_path in log_candidates:
            if log_path.exists():
                console.print(f"📄 [blue]Showing log: {log_path}[/]")
                click.echo(log_path.read_text())
                return

        console.print(f"❌ [red]Log not found for '{test_name}'.[/]")
        click.echo(f"   Searched: {', '.join(str(p) for p in log_candidates)}")
        sys.exit(1)
    else:
        # Find the most recent .log across all known log directories
        candidates = []

        # Primary: sim/cocotb/logs/ (simulation + regression logs)
        log_dir = Path("sim") / "cocotb" / "logs"
        if log_dir.exists():
            candidates.extend(log_dir.glob("*.log"))

        # Lint log lives at sim/lint.log
        lint_log = Path("sim") / "lint.log"
        if lint_log.exists():
            candidates.append(lint_log)

        if candidates:
            latest = max(candidates, key=lambda p: p.stat().st_mtime)
            console.print(f"📄 [blue]Showing latest log: {latest}[/]")
            click.echo(latest.read_text())
            return

        # Fallback to make target
        console.print("📄 [blue]Opening simulation log...[/]")
        cmd = ["make", "view-sim-log"]
        try:
            subprocess.run(cmd, check=False)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] 'make' not found.")
            sys.exit(1)
