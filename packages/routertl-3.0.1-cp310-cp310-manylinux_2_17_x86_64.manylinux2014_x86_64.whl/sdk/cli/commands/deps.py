# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: deps — Dependency inspection and graph export."""


from sdk.cli.resilience import cli_resilient, cli_resilient_block


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


import os
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console


@click.command(name="deps")
@click.argument("entity", required=False, default=None)
@click.option("--src", "src_dir", default=None, help="Source directory to scan (default: from project.yml or 'src').")
@click.option(
    "--graph",
    "graph_fmt",
    type=click.Choice(["mermaid", "html", "json"]),
    default=None,
    help="Export dependency graph in the given format.",
)
@click.option("-o", "--output", "output_file", default=None, help="Write graph output to a file instead of stdout.")
def deps_command(entity, src_dir, graph_fmt, output_file):
    """Inspect project dependencies or export the full dependency graph.

    Without --graph, prints the dependency tree for ENTITY.  With --graph,
    exports the entire dependency forest as Mermaid, HTML, or JSON.

    \\b
    Examples:
        routertl deps my_top                     # print tree for my_top
        routertl deps --graph mermaid            # export mermaid to stdout
        routertl deps --graph html -o deps.html  # save interactive HTML
        routertl deps --graph json               # JSON graph to stdout
    """
    import yaml

    # ── Resolve source directories ──
    if not src_dir:
        src_dirs = [Path("src")]
        if os.path.exists("project.yml"):
            with cli_resilient_block("project YAML source dirs"):
                with open("project.yml", "r") as f:
                    config = yaml.safe_load(f) or {}
                    paths_cfg = config.get("paths") or {}
                    src_raw = paths_cfg.get("sources", "src")
                    if isinstance(src_raw, list):
                        src_dirs = [Path(d) for d in src_raw]
                    else:
                        src_dirs = [Path(src_raw)]
    else:
        src_dirs = [Path(src_dir)]

    existing = [d for d in src_dirs if d.exists()]
    if not existing:
        console.print(f"⚠️  [yellow]No source directories found: {[str(d) for d in src_dirs]}[/]")
        sys.exit(1)

    # Lazy import
    sys.path.insert(0, str(Path(__file__).parent.parent.parent / "engine"))
    from dependency_resolver import DependencyResolver

    resolver = DependencyResolver(existing, verbose=False)

    # ── Graph export mode ──
    if graph_fmt:
        result = resolver.export_graph(fmt=graph_fmt)

        if output_file:
            Path(output_file).write_text(result, encoding="utf-8")
            console.print(f"✅ [green]Graph exported to [cyan]{output_file}[/][/]")
        else:
            click.echo(result)
        return

    # ── Single entity tree mode ──
    if not entity:
        # Show forest summary
        forest = resolver.resolve_forest()
        trees = forest.get("trees") or []
        orphans = forest.get("orphans") or []

        console.print("\n🌳 [cyan]Project Dependency Forest[/]")
        console.print(f"   {len(trees)} tree(s), {len(orphans)} orphan(s)\n")

        for t in trees:
            weight = t["weight"]
            console.print(
                f"   [green]▸[/] [cyan]{t['top']}[/]  ({weight} file{'s' if weight != 1 else ''})"
            )

        if orphans:
            console.print("\n   [yellow]Orphans:[/]")
            for o in orphans:
                console.print(f"     [dim]{Path(o).name}[/]")

        console.print(f"\n   [dim]Use: {_cli_name()} deps <entity> for detailed tree[/]")
        console.print(f"   [dim]Use: {_cli_name()} deps --graph mermaid|html|json[/]")
        return

    # Print tree for specific entity
    if entity not in resolver.entity_map and entity not in resolver.package_map:
        console.print(f"❌ [red]Entity/module '{entity}' not found in source tree.[/]")
        sys.exit(1)

    console.print(f"\n🌳 [cyan]Dependency Tree: {entity}[/]")
    click.echo("=" * 50)
    resolver.print_tree(entity)
    click.echo()
