# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Doctor — Environment Health Check.

A flutter-doctor-style diagnostic that validates the entire SDK toolchain,
project configuration, and workspace hygiene. Each check reports green,
yellow, or red with actionable fix suggestions.

This module is a thin orchestrator — individual health checks live in
``tools.cli.checks.*`` and register themselves via ``CheckRegistry``.
"""

import rich_click as click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from sdk.cli.checks import CheckRegistry, CheckResult
from sdk.cli.checks._helpers import _cli_name

# ──────────────────────────────────────────────────────────────
# Orchestrator
# ──────────────────────────────────────────────────────────────


def run_doctor():
    """Execute all health checks and return list of CheckResults."""
    return CheckRegistry.run_all()


# ──────────────────────────────────────────────────────────────
# CLI command
# ──────────────────────────────────────────────────────────────


@click.command(name="doctor")
def doctor():
    """
    Environment health check — validate SDK toolchain, project config, and workspace hygiene.

    Runs a comprehensive suite of checks and reports green/yellow/red status
    for each item with actionable fix suggestions.
    """
    console = Console()

    # Header
    header = Text()
    header.append("🩺 ", style="bold")
    header.append("RouteRTL Doctor", style="bold cyan")
    header.append("  — Environment Health Check", style="dim")
    console.print(Panel(header, border_style="cyan", padding=(0, 1)))
    console.print()

    results = run_doctor()

    # Render results
    _render_results(console, results)


# ──────────────────────────────────────────────────────────────
# Rendering
# ──────────────────────────────────────────────────────────────


def _render_results(console, results, show_summary=True):
    """Render a list of CheckResults to console."""
    ok_count = sum(1 for r in results if r.status == CheckResult.OK)
    warn_count = sum(1 for r in results if r.status == CheckResult.WARN)
    fail_count = sum(1 for r in results if r.status == CheckResult.FAIL)

    for r in results:
        title_style = {
            CheckResult.OK: "green",
            CheckResult.WARN: "yellow",
            CheckResult.FAIL: "red",
        }.get(r.status, "white")

        console.print(f"  {r.icon()} [{title_style}]{r.title:<16}[/] {r.detail}")
        if r.fix:
            console.print(f"       [dim]→ {r.fix}[/dim]")
        if r.fix_cmd:
            console.print(f"       [bold cyan]  $ {r.fix_cmd}[/bold cyan]")

    if show_summary:
        console.print()
        parts = []
        if ok_count:
            parts.append(f"[bold green]{ok_count} passed[/]")
        if warn_count:
            parts.append(f"[bold yellow]{warn_count} warning{'s' if warn_count != 1 else ''}[/]")
        if fail_count:
            parts.append(f"[bold red]{fail_count} issue{'s' if fail_count != 1 else ''}[/]")

        summary = " · ".join(parts)
        console.print(f"  {summary}")
        console.print()

        if fail_count:
            console.print(
                f"  [bold red]Some checks failed.[/] Fix the issues above and re-run [bold]{_cli_name()} doctor[/]."
            )
            console.print()
