# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Docker build, shell, and run commands."""

import sys

import rich_click as click

from sdk.cli.commands.docker import _run_make, docker_group
from sdk.cli.console import console


@docker_group.command(name="shell")
@click.argument("env", type=click.Choice(["sim", "vivado", "buildroot", "quartus", "radiant", "questa", "riviera", "libero"]), required=True)
def docker_shell(env):
    """Start interactive shell in Docker container."""
    console.print(f"🐳 [blue]Starting interactive shell in [cyan]{env}[blue] container...[/]")
    _run_make("docker-shell", f"DOCKER_ENV={env}")


@docker_group.command(name="install")
@click.argument("env", type=click.Choice(["sim", "vivado", "buildroot", "quartus", "radiant", "questa", "riviera", "libero"]), required=True)
def docker_install(env):
    """Install Docker image for a specific environment."""
    import subprocess as sp

    # Environments that depend on the sim base image
    _NEEDS_SIM = {"vivado", "quartus", "radiant", "questa", "riviera", "libero"}

    if env in _NEEDS_SIM:
        # Check if routertl-sim image exists locally
        result = sp.run(
            ["docker", "images", "-q", "routertl-sim:latest"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if not result.stdout.strip():
            console.print(
                f"📦 [yellow]{env}[/] requires the "
                f"[cyan]sim[/] base image, which is not built yet."
            )
            if click.confirm("   Build sim first?", default=True):
                console.print("\n🐳 [blue]Building base [cyan]sim[blue] image...[/]")
                _run_make("docker-build", "DOCKER_ENV=sim")
                click.echo()
            else:
                console.print("   [dim]Skipped. Install manually: rr docker install sim[/]")
                sys.exit(1)

    console.print(f"🐳 [blue]Building Docker image for [cyan]{env}[blue]...[/]")
    _run_make("docker-build", f"DOCKER_ENV={env}")


@docker_group.command(name="run")
@click.argument("env", type=click.Choice(["sim", "vivado", "buildroot", "quartus", "radiant", "questa", "riviera", "libero"]), required=True)
@click.argument("cmd", required=False, default=None)
def docker_run(env, cmd):
    """Run command in Docker (e.g. routertl docker run sim 'make simulation').

    If CMD is omitted, starts an interactive shell (same as 'docker shell').
    """
    if cmd:
        console.print(f"🐳 [blue]Running command in [cyan]{env}[blue] container...[/]")
        _run_make("docker-run", f"DOCKER_ENV={env}", f"CMD={cmd}")
    else:
        console.print(
            f"🐳 [blue]Starting interactive shell in [cyan]{env}[blue] container...[/]"
        )
        _run_make("docker-shell", f"DOCKER_ENV={env}")


# ── Deprecated aliases (hidden from --help, kept for backward compat) ──
# P2.29: 'build' was renamed to 'install' for verb symmetry with 'uninstall'.
# We create a proper hidden command that mirrors the install command.
@docker_group.command(name="build", hidden=True)
@click.argument("env", type=click.Choice(["sim", "vivado", "buildroot", "quartus", "radiant", "questa", "riviera", "libero"]), required=True)
def docker_build_alias(env):
    """Install Docker image (alias for 'install')."""
    docker_install.callback(env)
