# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Workspace install and environment check commands."""

import subprocess
import sys
from pathlib import Path

from sdk.cli.commands.workspace import (
    _inject_venv_completion,
    _inject_venv_environment,
    _run_make,
    workspace_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block


@workspace_group.command(name="install-hooks")
def install_hooks():
    """Install pre-commit hooks."""
    console.print("🪝 [blue]Installing Git hooks...[/]")
    _run_make("install-hooks")


@workspace_group.command(name="install")
def install():
    """Create venv (if needed) and install Python dependencies from requirements.txt."""
    import shutil

    console.print("📦 [blue]Installing project dependencies...[/]")
    _run_make("install")

    # Pull LFS objects if the repo uses Git LFS
    if Path(".gitattributes").exists() and shutil.which("git"):
        with cli_resilient_block("git lfs pull"):
            result = subprocess.run(
                ["git", "lfs", "pull"],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                pulled = result.stderr.strip() or result.stdout.strip()
                if pulled:
                    console.print(f"✅ [green]Git LFS:[/] {pulled}")
                else:
                    console.print("✅ [green]Git LFS:[/] all files up to date")

    # Inject environment variables and shell completion into .venv/bin/activate
    with cli_resilient_block("venv environment injection"):
        _inject_venv_environment()
    with cli_resilient_block("venv completion injection"):
        _inject_venv_completion()


@workspace_group.command(name="check-env")
def check_env():
    """Check SDK tool requirements and versions."""
    result = subprocess.run(["make", "check-env"], stderr=subprocess.DEVNULL)
    if result.returncode != 0:
        sys.exit(result.returncode)


@workspace_group.command(name="status")
def workspace_status():
    """Check SDK tool requirements and versions (alias for check-env)."""
    result = subprocess.run(["make", "check-env"], stderr=subprocess.DEVNULL)
    if result.returncode != 0:
        sys.exit(result.returncode)
