# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Workspace repair commands and helpers."""

import subprocess
import sys

import rich_click as click

from sdk.cli.commands.workspace import (
    _inject_venv_completion,
    _inject_venv_environment,
    _run_update_config,
    workspace_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block

# ──────────────────────────────────────────────────────────────
# Repair helpers
# ──────────────────────────────────────────────────────────────

_REPAIR_SKIP = "skip"
_REPAIR_FIXED = "fixed"
_REPAIR_FAILED = "failed"


def _repair_build_env(*, force=False):
    """Regenerate build_env.mk if stale or missing."""
    from pathlib import Path

    yml_path = Path("project.yml")
    env_path = Path("build_env.mk")

    if not yml_path.exists():
        return ("build_env", _REPAIR_SKIP, "no project.yml")

    if not force and env_path.exists():
        if yml_path.stat().st_mtime <= env_path.stat().st_mtime:
            return ("build_env", _REPAIR_SKIP, "already up to date")

    detail = "missing" if not env_path.exists() else "stale"
    console.print(f"🔧 [blue]Regenerating build_env.mk ({detail})...[/]")
    with cli_resilient_block("build_env repair"):
        _run_update_config(exit_on_error=False)
    # Verify it was created/updated
    if env_path.exists():
        return ("build_env", _REPAIR_FIXED, f"regenerated ({detail})")
    return ("build_env", _REPAIR_FAILED, "regeneration failed")


def _repair_deps(*, force=False):
    """Re-resolve dependencies by removing .deps.ok and triggering check-deps."""
    from pathlib import Path

    yml_path = Path("project.yml")
    deps_ok = Path(".deps.ok")

    if not yml_path.exists():
        return ("deps", _REPAIR_SKIP, "no project.yml")

    if not force and deps_ok.exists():
        return ("deps", _REPAIR_SKIP, ".deps.ok present")

    console.print("🔧 [blue]Re-resolving dependencies...[/]")
    if deps_ok.exists():
        deps_ok.unlink()

    # Trigger dependency resolution via make check-deps → update-config
    with cli_resilient_block("deps repair"):
        result = subprocess.run(
            ["make", "check-deps"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            # Ensure sentinel exists after resolution
            if not deps_ok.exists():
                _run_update_config(exit_on_error=False)
            if deps_ok.exists():
                return ("deps", _REPAIR_FIXED, "dependencies re-resolved")
            return ("deps", _REPAIR_FIXED, "check-deps ran (sentinel may require full build)")

    return ("deps", _REPAIR_FAILED, "dependency resolution failed")


def _repair_nvc_workdir(*, force=False):
    """Delete stale NVC work directory and trigger precompile rebuild."""
    import shutil
    from pathlib import Path

    workdir = Path("sim") / "work"
    work_work = workdir / "work"

    if not Path("project.yml").exists():
        return ("nvc_workdir", _REPAIR_SKIP, "no project.yml")

    # Health check: mirror _check_workdir_health() from smart_linter.py
    workdir_healthy = (
        work_work.is_dir()
        and any(work_work.glob("*.cf"))
    )

    if not force and workdir_healthy:
        return ("nvc_workdir", _REPAIR_SKIP, "work directory healthy")

    console.print("🔧 [blue]Rebuilding NVC work directory...[/]")

    # Remove stale work directory
    if work_work.exists():
        with cli_resilient_block("NVC workdir cleanup"):
            shutil.rmtree(work_work)
            console.print("  [dim]Deleted sim/work/work/[/]")

    # Run precompile to rebuild
    with cli_resilient_block("NVC precompile"):
        result = subprocess.run(
            ["make", "precompile"],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            return ("nvc_workdir", _REPAIR_FIXED, "work directory rebuilt")
        # Precompile target may not exist in all Makefiles — fall back to linting
        # which triggers its own workdir health check
        console.print("  [dim]precompile target not available, workdir cleared for next lint[/]")
        return ("nvc_workdir", _REPAIR_FIXED, "work directory cleared (will rebuild on next lint)")

    return ("nvc_workdir", _REPAIR_FAILED, "precompile failed")


_ALL_REPAIRS = {
    "build_env": _repair_build_env,
    "deps": _repair_deps,
    "nvc_workdir": _repair_nvc_workdir,
}


@workspace_group.command(name="repair-venv")
@click.option("--force", is_flag=True, help="Force repair even if .venv appears healthy.")
def repair_venv(force):
    """Nuke and rebuild .venv from scratch.

    \\b
    Desperate recovery for when the CLI or virtual environment is broken.
    Diagnoses common corruption issues, deletes the old .venv, creates
    a fresh one, re-installs the SDK, and rebuilds CLI shortcuts.

    \\b
    If the CLI itself is broken, use the standalone script instead:
        bash <sdk-root>/sdk/scripts/repair_venv.sh
    """
    from pathlib import Path

    # Locate the repair script relative to this file
    script = Path(__file__).resolve().parent.parent.parent.parent / "sh" / "repair_venv.sh"
    if not script.exists():
        console.print(f"❌ [red]Repair script not found at:[/] {script}")
        console.print("   Try running directly: bash <sdk-root>/sdk/scripts/repair_venv.sh")
        sys.exit(1)

    cmd = ["bash", str(script)]
    if force:
        cmd.append("--force")

    try:
        result = subprocess.run(cmd)
        if result.returncode == 0:
            # Re-inject environment variables into the fresh venv
            with cli_resilient_block("venv environment injection"):
                _inject_venv_environment()
            with cli_resilient_block("venv completion injection"):
                _inject_venv_completion()
        sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]bash not found on PATH.[/]")
        sys.exit(1)


@workspace_group.command(name="repair")
@click.option(
    "--only",
    type=click.Choice(["build_env", "deps", "nvc_workdir"]),
    default=None,
    help="Run only a specific repair (default: all).",
)
@click.option("--force", is_flag=True, help="Force repairs even if checks appear healthy.")
def repair(only, force):
    """Auto-fix common workspace issues.

    \\b
    Runs automated repairs for issues that ``rr doctor`` detects:
      • build_env   — regenerate stale/missing build_env.mk
      • deps        — re-resolve dependencies (.deps.ok sentinel)
      • nvc_workdir — rebuild NVC work directory (stale .cf catalogs)

    \\b
    Examples:
        rr ws repair                  # fix everything
        rr ws repair --only build_env # fix only build_env.mk
        rr ws repair --force          # force all repairs

    \\b
    For venv recovery, use: rr ws repair-venv
    """
    from rich.table import Table

    console.print()
    console.print("🔧 [bold cyan]Workspace Repair[/]")
    console.print()

    repairs_to_run = {only: _ALL_REPAIRS[only]} if only else _ALL_REPAIRS
    results = []

    for name, fn in repairs_to_run.items():
        with cli_resilient_block(f"repair {name}"):
            result = fn(force=force)
            results.append(result)

    # Summary table
    console.print()
    table = Table(title="Repair Summary", show_lines=False)
    table.add_column("Check", style="cyan", min_width=14)
    table.add_column("Status", min_width=8)
    table.add_column("Detail", style="dim")

    status_styles = {
        _REPAIR_SKIP: "[dim]skip[/]",
        _REPAIR_FIXED: "[bold green]fixed[/]",
        _REPAIR_FAILED: "[bold red]FAILED[/]",
    }

    for name, status, detail in results:
        table.add_row(name, status_styles.get(status, status), detail)

    console.print(table)
    console.print()

    fixed = sum(1 for _, s, _ in results if s == _REPAIR_FIXED)
    failed = sum(1 for _, s, _ in results if s == _REPAIR_FAILED)
    skipped = sum(1 for _, s, _ in results if s == _REPAIR_SKIP)

    parts = []
    if fixed:
        parts.append(f"[bold green]{fixed} fixed[/]")
    if skipped:
        parts.append(f"[dim]{skipped} skipped[/]")
    if failed:
        parts.append(f"[bold red]{failed} failed[/]")
    console.print("  " + " · ".join(parts))
    console.print()
