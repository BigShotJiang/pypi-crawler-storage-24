# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Workspace update commands — source scanning and SDK update."""

import subprocess
import sys

import rich_click as click

from sdk.cli.commands.workspace import (
    _fix_makefile_include,
    _inject_venv_completion,
    _inject_venv_environment,
    _run_make,
    _run_update_config,
    workspace_group,
)
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient, cli_resilient_block


@workspace_group.command(name="update")
@click.option("--all", "update_all", is_flag=True, help="Update all source lists")
@click.option("--src", is_flag=True, help="Update synthesis sources")
@click.option("--sim", is_flag=True, help="Update simulation testbenches")
@click.option("--xdc", is_flag=True, help="Update constraint files")
@click.option("--tcl", is_flag=True, help="Update TCL hooks")
@click.option("--mmap", is_flag=True, help="Update memory map from YAML")
@click.option("--ips", is_flag=True, help="Update IP manifest source lists")
def update(update_all, src, sim, xdc, tcl, mmap, ips):
    """Scan directories and update project.yml source lists."""
    if update_all or not any([src, sim, xdc, tcl, mmap, ips]):
        console.print("🔄 [blue]Updating all workspace sources...[/]")
        _run_make("update-all")
    else:
        if src:
            _run_make("update-src")
        if sim:
            _run_make("update-sim")
        if xdc:
            _run_make("update-xdc")
        if tcl:
            _run_make("update-tcl")
        if mmap:
            _run_make("update-mmap")
        if ips:
            _run_make("update-ips")


@workspace_group.command(name="update-config")
def update_config():
    """Update build_env.mk from project.yml"""
    _run_update_config(exit_on_error=True)
    # Refresh environment variables and completion in .venv/bin/activate
    with cli_resilient_block("venv environment injection"):
        _inject_venv_environment()
    with cli_resilient_block("venv completion injection"):
        _inject_venv_completion()


@workspace_group.command(name="update-sdk")
def update_sdk():
    """Update the RouteRTL SDK submodule to the latest remote commit.

    Pulls the latest changes from the SDK remote, shows a before/after
    version summary, and re-installs the package so the CLI is
    immediately up to date.
    """
    import os

    # ── Locate SDK submodule ──
    from sdk.cli.sdk_root import resolve_sdk_root

    sdk_path = resolve_sdk_root()

    if sdk_path is None:
        console.print("❌ [red]Could not find SDK submodule.[/]")
        click.echo("   Set ROUTERTL_ROOT or ensure vendor/routertl exists.")
        sys.exit(1)

    console.print(f"📦 [cyan]SDK location:[/] {sdk_path}")

    # ── Read current version (before) ──
    @cli_resilient("git short SHA", default="unknown")
    def _get_short_sha(path):
        r = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return r.stdout.strip() if r.returncode == 0 else "unknown"

    before_sha = _get_short_sha(sdk_path)

    # ── Ensure we're on a branch (submodules default to detached HEAD) ──
    console.print("🔄 [blue]Fetching latest SDK changes...[/]")

    # Determine the tracking branch (.gitmodules branch or default 'main')
    track_branch = "main"
    with cli_resilient_block("tracking branch detection"):
        r = subprocess.run(
            ["git", "config", "-f", ".gitmodules", f"submodule.{sdk_path}.branch"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0 and r.stdout.strip():
            track_branch = r.stdout.strip()

    # Checkout the tracking branch (no-op if already on it)
    with cli_resilient_block("SDK branch checkout"):
        subprocess.run(
            ["git", "-C", str(sdk_path), "checkout", track_branch],
            capture_output=True,
            text=True,
            timeout=10,
        )

    fetch_env = {
        **os.environ,
        "GIT_SSH_COMMAND": "ssh -o StrictHostKeyChecking=accept-new -o BatchMode=yes",
    }
    try:
        result = subprocess.run(
            ["git", "-C", str(sdk_path), "pull", "--ff-only"],
            capture_output=True,
            text=True,
            timeout=60,
            env=fetch_env,
        )
    except subprocess.TimeoutExpired:
        console.print("❌ [red]Timed out fetching from remote.[/]")
        sys.exit(1)
    except FileNotFoundError:
        console.print("❌ [red]git not found on PATH.[/]")
        sys.exit(1)

    if result.returncode != 0:
        console.print("❌ [red]git pull failed:[/]")
        click.echo(result.stderr.strip() or result.stdout.strip())
        sys.exit(1)

    after_sha = _get_short_sha(sdk_path)

    if before_sha == after_sha:
        console.print(f"✅ [green]Already up to date[/] ({before_sha})")
    else:
        # Count new commits
        count = "?"
        with cli_resilient_block("new commit count"):
            r = subprocess.run(
                ["git", "-C", str(sdk_path), "rev-list", "--count", f"{before_sha}..{after_sha}"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode == 0:
                count = r.stdout.strip()

        console.print(
            f"✅ [green]Updated:[/] "
            f"[yellow]{before_sha}[/] → "
            f"[cyan]{after_sha}[/] "
            f"({count} new commit{'s' if count != '1' else ''})"
        )

        # Show one-liner changelog
        with cli_resilient_block("SDK changelog display"):
            r = subprocess.run(
                ["git", "-C", str(sdk_path), "log", "--oneline", f"{before_sha}..{after_sha}"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode == 0 and r.stdout.strip():
                console.print("\n[dim]  Changelog:[/]")
                for line in r.stdout.strip().splitlines():
                    console.print(f"    [dim]{line}[/]")
                click.echo()

    # ── Re-install pip package ──
    console.print("📦 [blue]Re-installing SDK package...[/]")
    with cli_resilient_block("SDK package reinstall"):
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-e", str(sdk_path), "-q"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            console.print("✅ [green]SDK package re-installed successfully.[/]")
        else:
            console.print("⚠️  [yellow]pip install returned errors:[/]")
            click.echo(result.stderr.strip() or result.stdout.strip())

    # ── Fix Makefile include path if stale ──
    _fix_makefile_include(sdk_path)

    # ── Regenerate build_env.mk (may be stale against updated Common.mk) ──
    _run_update_config(exit_on_error=False)
