# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Project Workspace and Configuration Management — CLI commands.

This package replaces the former monolithic ``workspace.py`` (P2.42).
Core orchestration logic lives in ``routertl_core.workspace.orchestration``
(Cython-compiled on release builds, P2.59).  This module re-exports
those symbols and registers Click commands via submodule imports.
"""

import rich_click as click

# ──────────────────────────────────────────────────────────────
# Click group
# ──────────────────────────────────────────────────────────────


@click.group(name="workspace")
def workspace_group():
    """Project Workspace and Configuration Management."""
    pass


# ──────────────────────────────────────────────────────────────
# Re-export core orchestration symbols (P2.59)
#
# All helpers and injection functions are now in
# routertl_core.workspace.orchestration — compiled to .so on release.
# Command submodules import them from this __init__.py as before,
# keeping the existing API surface unchanged.
# ──────────────────────────────────────────────────────────────

from routertl_core.workspace.orchestration import (  # noqa: E402, F401
    _COMP_SENTINEL_END,
    _COMP_SENTINEL_START,
    _ENV_SENTINEL_END,
    _ENV_SENTINEL_START,
    _detect_shell,
    _fix_makefile_include,
    _inject_venv_completion,
    _inject_venv_environment,
    _run_make,
    _run_update_config,
)

# ── Import all submodules to register commands on workspace_group ──
from sdk.cli.commands.workspace import (  # noqa: E402, F401
    install,
    repair,
    tools,
    update,
)
