# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Simulator health checks — NVC, GHDL, Verilator, and commercial simulators.
"""

from __future__ import annotations

import os

from sdk.cli.checks import CheckRegistry, CheckResult
from sdk.cli.checks._helpers import (
    _cli_name,
    _detect_docker_container,
    _load_project_yml,
    _parse_version,
    _run,
    _ver_tuple,
    _which,
)

# ──────────────────────────────────────────────────────────────
# Generic simulator binary check (not registered — it's a helper)
# ──────────────────────────────────────────────────────────────


def check_simulator(name, cmd, regex, min_ver, required, role, hint):
    """Generic simulator binary check."""
    path = _which(cmd.split()[0])
    if not path:
        status = CheckResult.FAIL if required else CheckResult.WARN
        return CheckResult(
            name,
            status,
            "not found on PATH",
            fix=hint,
        )
    env = os.environ.copy()
    if name.lower() == "verilator":
        env.pop("VERILATOR_ROOT", None)
    rc, out = _run(cmd.split(), env=env)
    ver = _parse_version(out, regex)
    if ver and min_ver:
        if _ver_tuple(ver) >= _ver_tuple(min_ver):
            return CheckResult(name, CheckResult.OK, f"v{ver} ({path})")
        status = CheckResult.FAIL if required else CheckResult.WARN
        return CheckResult(
            name,
            status,
            f"v{ver} < required v{min_ver}",
            fix=hint,
        )
    if path:
        detail = f"v{ver}" if ver else "found"
        return CheckResult(name, CheckResult.OK, f"{detail} ({path})")
    return CheckResult(name, CheckResult.WARN, "could not determine version")


# ──────────────────────────────────────────────────────────────
# check_simulators  (order=11)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Simulators", order=11)
def check_simulators():
    """Check NVC, GHDL, Verilator, and commercial simulators.

    Commercial simulators (Riviera-PRO, Questa IFPGA) are only shown when
    relevant:  inside a matching Docker container, or when project.yml
    ``simulation.simulator`` explicitly requests them.  When shown, missing
    is a hard FAIL (not a soft warning).
    """
    results = []
    results.append(
        check_simulator(
            "NVC",
            "nvc --version",
            r"nvc (\d+\.\d+\.\d+)",
            "1.14.0",
            True,
            "VHDL simulator (primary)",
            "https://github.com/nickg/nvc — build from source (≥ 1.14.0)",
        )
    )
    results.append(
        check_simulator(
            "GHDL",
            "ghdl --version",
            r"GHDL (\d+\.\d+\.\d+)",
            "6.0.0",
            True,
            "VHDL analysis & elaboration",
            "Build from dev branch: https://github.com/ghdl/ghdl",
        )
    )
    results.append(
        check_simulator(
            "Verilator",
            "verilator --version",
            r"Verilator (\d+\.\d+)",
            "5.036",
            False,
            "Verilog simulator",
            "Run: sudo ./sdk/scripts/install_verilator.sh",
        )
    )

    # ── Commercial simulators: context-aware visibility ──
    # Only shown when: (a) inside a matching Docker container, or
    # (b) project.yml simulation.simulator requests them.
    # When shown, missing = FAIL (the user explicitly needs them).
    docker_env = _detect_docker_container()

    # Read project.yml simulator preference
    yml_sim = None
    cfg = _load_project_yml()
    if isinstance(cfg, dict):
        sim_cfg = cfg.get("simulation") or {}
        if isinstance(sim_cfg, dict):
            yml_sim = (sim_cfg.get("simulator") or "").lower()

    # Questa IFPGA — show if inside quartus/questa container or yml requests it
    show_questa = docker_env in ("quartus", "questa") or yml_sim in ("questa", "vsim", "questa_ifpga")
    if show_questa:
        if docker_env in ("quartus", "questa"):
            questa = check_simulator(
                "Questa IFPGA",
                "vsim -version",
                r"vsim.*?(\d+\.\d+)",
                None,
                True,
                "Intel FPGA Edition simulator",
                f"Mount via Docker: {_cli_name()} docker shell quartus",
            )
            if questa.status != CheckResult.OK:
                questa = CheckResult(
                    "Questa IFPGA",
                    CheckResult.OK,
                    "running in Docker container",
                )
        else:
            questa = check_simulator(
                "Questa IFPGA",
                "vsim -version",
                r"vsim.*?(\d+\.\d+)",
                None,
                True,
                "Intel FPGA Edition simulator",
                f"Mount via Docker: {_cli_name()} docker shell quartus",
            )
        results.append(questa)

    # Riviera-PRO — show if inside riviera container or yml requests it
    show_riviera = docker_env == "riviera" or yml_sim in ("riviera", "riviera-pro")
    if show_riviera:
        if docker_env == "riviera":
            riv = check_simulator(
                "Riviera-PRO",
                "vsim -version",
                r"Riviera-PRO (\d+\.\d+)",
                "2024.04",
                True,
                "Commercial mixed-language simulator",
                f"Mount via Docker: {_cli_name()} docker shell riviera",
            )
            if riv.status != CheckResult.OK:
                riv = CheckResult(
                    "Riviera-PRO",
                    CheckResult.OK,
                    "running in Docker container",
                )
        else:
            riv = check_simulator(
                "Riviera-PRO",
                "vsim -version",
                r"Riviera-PRO (\d+\.\d+)",
                "2024.04",
                True,
                "Commercial mixed-language simulator",
                f"Mount via Docker: {_cli_name()} docker shell riviera",
            )
        results.append(riv)

    return results
