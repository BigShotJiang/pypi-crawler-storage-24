# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Parametrized smoke tests: every CLI command responds to --help with exit 0.

This catches broken imports, typos in Click decorators, and missing
dependencies at the CLI layer — the part users actually interact with.
"""

import sys
from pathlib import Path

import pytest
from click.testing import CliRunner

# Ensure SDK root is on sys.path
SDK_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(SDK_ROOT))

from sdk.cli.main import cli  # noqa: E402

# ── Discover all top-level commands and groups ────────────────────────
# Click groups expose .commands; standalone commands don't.
_TOP_COMMANDS = []
for name, cmd in sorted(cli.commands.items()):
    _TOP_COMMANDS.append(name)
    # If it's a group, also test each subcommand's --help
    if hasattr(cmd, "commands"):
        for sub_name in sorted(cmd.commands.keys()):
            _TOP_COMMANDS.append(f"{name} {sub_name}")


@pytest.fixture()
def runner():
    """Click CliRunner."""
    return CliRunner()


@pytest.mark.parametrize("cmd_path", _TOP_COMMANDS)
def test_help_exits_zero(runner, cmd_path, tmp_path, monkeypatch):
    """Every command must respond to --help with exit code 0."""
    # Run from a temp dir so project.yml absence doesn't crash --help
    monkeypatch.chdir(tmp_path)
    args = cmd_path.split() + ["--help"]
    result = runner.invoke(cli, args, catch_exceptions=False)
    assert result.exit_code == 0, (
        f"`rr {cmd_path} --help` exited {result.exit_code}:\n{result.output}"
    )
    # --help should produce some output
    assert len(result.output) > 0, f"`rr {cmd_path} --help` produced no output"
