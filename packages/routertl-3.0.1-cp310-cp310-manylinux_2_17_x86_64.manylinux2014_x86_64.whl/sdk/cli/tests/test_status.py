# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Smoke tests for ``rr status``."""

from sdk.cli.main import cli


class TestStatusCommand:
    """Verify core behaviour of the status command."""

    def test_status_exits_zero(self, cli_runner, tmp_project, mock_git):
        """Status should exit 0 when a valid project.yml exists."""
        result = cli_runner.invoke(cli, ["status"], catch_exceptions=False)
        assert result.exit_code == 0, f"exit {result.exit_code}: {result.output}"

    def test_status_shows_project_name(self, cli_runner, tmp_project, mock_git):
        """The project name from project.yml must appear in output."""
        result = cli_runner.invoke(cli, ["status"], catch_exceptions=False)
        assert "test_project" in result.output

    def test_status_no_project_yml(self, cli_runner):
        """Running status without project.yml must show an error, not crash."""
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(cli, ["status"], catch_exceptions=False)
            # Should mention missing project or init command
            assert "project.yml" in result.output.lower() or "init" in result.output.lower()
            # Must never show a Python traceback
            assert "Traceback" not in result.output

    def test_status_sdk_version(self, cli_runner, tmp_project, mock_version_file, mock_git):
        """When a VERSION file exists, the version string should appear."""
        result = cli_runner.invoke(cli, ["status"], catch_exceptions=False)
        # The status command reads VERSION and builds "v3.0.<patch>"
        assert "v3.0" in result.output
