# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Smoke tests for ``rr info``."""

from sdk.cli.main import cli


class TestInfoCommand:
    """Verify core behaviour of the info command."""

    def test_info_no_args_error(self, cli_runner, tmp_project):
        """Info with no entity and no flags should show an error."""
        result = cli_runner.invoke(cli, ["info"], catch_exceptions=False)
        # Should fail with a helpful message (exit 1 via sys.exit)
        assert result.exit_code != 0
        assert "Traceback" not in result.output

    def test_info_forest_flag(self, cli_runner, tmp_project):
        """Info --forest should produce tree output when sources exist."""
        # Create a minimal VHDL source tree so the resolver has something
        src_dir = tmp_project / "src"
        src_dir.mkdir()
        vhdl_file = src_dir / "test_top.vhd"
        vhdl_file.write_text(
            "library ieee;\n"
            "use ieee.std_logic_1164.all;\n"
            "entity test_top is\n"
            "  port (\n"
            "    clk : in std_logic\n"
            "  );\n"
            "end entity test_top;\n"
            "architecture rtl of test_top is\n"
            "begin\n"
            "end architecture rtl;\n"
        )

        # Update project.yml to point sources at src/
        yml = tmp_project / "project.yml"
        yml.write_text(
            yml.read_text() + "paths:\n  sources: src\n"
        )

        result = cli_runner.invoke(cli, ["info", "--forest"], catch_exceptions=False)
        assert result.exit_code == 0, f"exit {result.exit_code}: {result.output}"
        assert "Traceback" not in result.output
        # Should show the forest header
        assert "Forest" in result.output or "forest" in result.output or "test_top" in result.output

    def test_info_unknown_entity(self, cli_runner, tmp_project):
        """Querying a non-existent entity should show a helpful error."""
        # Need a source dir so resolver initialises
        src_dir = tmp_project / "src"
        src_dir.mkdir()
        (src_dir / "dummy.vhd").write_text(
            "entity dummy is end entity dummy;\n"
            "architecture rtl of dummy is begin end architecture rtl;\n"
        )
        yml = tmp_project / "project.yml"
        yml.write_text(
            yml.read_text() + "paths:\n  sources: src\n"
        )

        result = cli_runner.invoke(
            cli, ["info", "nonexistent_entity_xyz"], catch_exceptions=False
        )
        assert result.exit_code != 0
        assert "not found" in result.output.lower()
        assert "Traceback" not in result.output
