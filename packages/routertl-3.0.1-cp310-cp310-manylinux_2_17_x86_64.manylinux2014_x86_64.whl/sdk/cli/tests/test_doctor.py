# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Smoke tests for ``rr doctor``."""

from sdk.cli.main import cli


class TestDoctorCommand:
    """Verify core behaviour of the doctor command."""

    def test_doctor_exits_zero(self, cli_runner, tmp_project, mock_git):
        """Doctor should exit 0 even when individual checks warn/fail."""
        result = cli_runner.invoke(cli, ["doctor"], catch_exceptions=False)
        assert result.exit_code == 0, f"exit {result.exit_code}: {result.output}"
        assert "Traceback" not in result.output

    def test_doctor_checks_listed(self, cli_runner, tmp_project, mock_git):
        """Known check names must appear in doctor output."""
        result = cli_runner.invoke(cli, ["doctor"], catch_exceptions=False)
        output = result.output
        # These checks always run regardless of environment
        assert "Python" in output, "Python check missing"
        assert "project.yml" in output, "project.yml check missing"

    def test_doctor_no_project_yml(self, cli_runner, mock_git):
        """Doctor in an empty dir should still run and report project.yml issue."""
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(cli, ["doctor"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Traceback" not in result.output
            # project.yml check should flag it as missing
            assert "project.yml" in result.output

    def test_doctor_fix_suggestions(self, cli_runner, mock_git):
        """When project.yml is missing, doctor should suggest a fix command."""
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(cli, ["doctor"], catch_exceptions=False)
            output = result.output
            # The check_project_yml function emits a fix_cmd containing "init"
            assert "init" in output.lower(), (
                "Expected fix suggestion containing 'init' for missing project.yml"
            )

class TestSubmoduleHealthCheck:
    """Verify check_submodules() detects uninitialized submodules recursively."""

    @staticmethod
    def _make_mock(submodule_output):
        """Create a subprocess mock that returns given output for git submodule status."""
        import subprocess
        from unittest.mock import patch

        _real_run = subprocess.run

        def fake_run(cmd, *a, **kw):
            str_cmd = [str(c) for c in cmd]
            if "rev-parse" in str_cmd and "--git-dir" in str_cmd:
                return subprocess.CompletedProcess(cmd, 0, stdout=".git\n", stderr="")
            if "submodule" in str_cmd and "status" in str_cmd:
                return subprocess.CompletedProcess(
                    cmd, 0, stdout=submodule_output, stderr=""
                )
            return _real_run(cmd, *a, **kw)

        return patch("subprocess.run", side_effect=fake_run)

    def test_submodule_healthy(self, tmp_path, monkeypatch):
        """All submodules initialized → single OK result."""
        from sdk.cli.checks.workspace import check_submodules

        monkeypatch.chdir(tmp_path)
        output = " abc1234 vendor/routertl (v3.0)\n"
        with self._make_mock(output):
            results = check_submodules()

        assert len(results) == 1
        assert results[0].status == "ok"
        assert "1 submodule" in results[0].detail

    def test_submodule_not_initialized(self, tmp_path, monkeypatch):
        """Uninitialized submodule ('-' prefix) → FAIL with fix cmd."""
        from sdk.cli.checks.workspace import check_submodules

        monkeypatch.chdir(tmp_path)
        output = "-0000000000000000000000000000000000000000 vendor/routertl\n"
        with self._make_mock(output):
            results = check_submodules()

        assert len(results) == 1
        assert results[0].status == "fail"
        assert "not initialized" in results[0].detail
        assert "vendor/routertl" in results[0].detail
        assert "git submodule update" in results[0].fix_cmd

    def test_nested_submodule_not_initialized(self, tmp_path, monkeypatch):
        """Nested submodule uninitialized → FAIL detected at depth."""
        from sdk.cli.checks.workspace import check_submodules

        monkeypatch.chdir(tmp_path)
        output = (
            " abc1234 ip/dsp_core (heads/main)\n"
            "-0000000000000000000000000000000000000000 ip/dsp_core/vendor/math_lib\n"
        )
        with self._make_mock(output):
            results = check_submodules()

        # One OK (dsp_core), one FAIL (math_lib)
        assert len(results) == 1  # Only issues returned when there are failures
        assert results[0].status == "fail"
        assert "math_lib" in results[0].title
        assert "ip/dsp_core/vendor/math_lib" in results[0].detail

    def test_no_submodules(self, tmp_path, monkeypatch):
        """No submodules → empty results (silently skipped)."""
        from sdk.cli.checks.workspace import check_submodules

        monkeypatch.chdir(tmp_path)
        # git submodule status returns empty when no submodules exist
        with self._make_mock(""):
            results = check_submodules()

        assert results == []



class TestDependencyHealthCheck:
    """Verify check_dependencies() detects missing/empty dependency clones."""

    def test_dependency_healthy(self, tmp_path, monkeypatch):
        """Populated dependency path → OK result."""
        from sdk.cli.checks.workspace import check_dependencies

        dep_dir = tmp_path / "libs" / "xpm_vhdl"
        dep_dir.mkdir(parents=True)
        (dep_dir / "xpm_VCOMP.vhd").write_text("-- XPM stub\n")
        (tmp_path / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: xilinx\n  part: xc7z020clg400-1\n"
            "dependencies:\n  xpm_vhdl:\n    url: https://example.com/xpm.git\n"
            "    path: libs/xpm_vhdl\n    library: xpm\n"
        )
        monkeypatch.chdir(tmp_path)
        results = check_dependencies()

        assert len(results) == 1
        assert results[0].status == "ok"
        assert "1 dependency clone" in results[0].detail

    def test_dependency_missing(self, tmp_path, monkeypatch):
        """Dependency path doesn't exist → WARN result."""
        from sdk.cli.checks.workspace import check_dependencies

        (tmp_path / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: xilinx\n  part: xc7z020clg400-1\n"
            "dependencies:\n  xpm_vhdl:\n    url: https://example.com/xpm.git\n"
            "    path: libs/xpm_vhdl\n    library: xpm\n"
        )
        monkeypatch.chdir(tmp_path)
        results = check_dependencies()

        assert len(results) == 1
        assert results[0].status == "warn"
        assert "not cloned" in results[0].detail
        assert "update-config" in results[0].fix_cmd

    def test_no_dependencies(self, tmp_path, monkeypatch):
        """project.yml has no dependencies key → empty results."""
        from sdk.cli.checks.workspace import check_dependencies

        (tmp_path / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: xilinx\n  part: xc7z020clg400-1\n"
        )
        monkeypatch.chdir(tmp_path)
        results = check_dependencies()

        assert results == []


class TestLfsNetlistCheck:
    """Verify check_lfs_netlists() detects unpulled LFS netlist stubs."""

    def test_no_netlists(self, tmp_path, monkeypatch):
        """Empty dir → empty results (no netlist files to scan)."""
        from sdk.cli.checks.workspace import check_lfs_netlists

        monkeypatch.chdir(tmp_path)
        results = check_lfs_netlists()
        assert results == []

    def test_real_netlist_not_flagged(self, tmp_path, monkeypatch):
        """Binary .qxp file (not an LFS stub) → empty results."""
        from sdk.cli.checks.workspace import check_lfs_netlists

        monkeypatch.chdir(tmp_path)
        netlist = tmp_path / "ip" / "core.qxp"
        netlist.parent.mkdir(parents=True)
        # Write binary content — not an LFS pointer
        netlist.write_bytes(b"\x00\x01\x02\x03QUARTUS_NETLIST_BINARY_DATA")
        results = check_lfs_netlists()
        assert results == []

    def test_stub_detected(self, tmp_path, monkeypatch):
        """LFS pointer stub .qxp → FAIL result with fix_cmd."""
        from sdk.cli.checks.workspace import check_lfs_netlists

        monkeypatch.chdir(tmp_path)
        netlist = tmp_path / "ip" / "encoder.qxp"
        netlist.parent.mkdir(parents=True)
        # Write a realistic LFS pointer stub
        netlist.write_text(
            "version https://git-lfs.github.com/spec/v1\n"
            "oid sha256:abc123def456789...\n"
            "size 52428800\n"
        )
        results = check_lfs_netlists()
        assert len(results) == 1
        assert results[0].status == "fail"
        assert "encoder.qxp" in results[0].detail
        assert results[0].fix_cmd == "git lfs pull"

    def test_stub_in_dotdir_ignored(self, tmp_path, monkeypatch):
        """LFS stubs inside dot-directories (e.g. .git) are skipped."""
        from sdk.cli.checks.workspace import check_lfs_netlists

        monkeypatch.chdir(tmp_path)
        hidden_netlist = tmp_path / ".cache" / "stale.qdb"
        hidden_netlist.parent.mkdir(parents=True)
        hidden_netlist.write_text(
            "version https://git-lfs.github.com/spec/v1\n"
            "oid sha256:abc123def456789...\n"
            "size 1024\n"
        )
        results = check_lfs_netlists()
        assert results == []

    def test_multiple_stubs(self, tmp_path, monkeypatch):
        """Multiple stub files → single FAIL result mentioning count."""
        from sdk.cli.checks.workspace import check_lfs_netlists

        monkeypatch.chdir(tmp_path)
        for name in ["a.qxp", "b.qdb"]:
            f = tmp_path / "ip" / name
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(
                "version https://git-lfs.github.com/spec/v1\n"
                "oid sha256:abc123...\n"
                "size 1024\n"
            )
        results = check_lfs_netlists()
        assert len(results) == 1
        assert results[0].status == "fail"
        assert "2 netlist stubs" in results[0].detail


class TestUnisimCheck:
    """Verify check_unisim() reports unisim availability correctly."""

    def test_unisim_precompiled_ok(self, tmp_path, monkeypatch):
        """NVC precompiled marker exists → OK result."""
        from unittest.mock import patch

        from sdk.cli.checks.vendor_tools import check_unisim

        monkeypatch.chdir(tmp_path)
        (tmp_path / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: xilinx\n  part: xc7z020clg400-1\n"
        )

        with patch(
            "routertl_core.sim.vendor_libraries.nvc_unisim_available",
            return_value=True,
        ):
            result = check_unisim()

        assert result.status == "ok"
        assert "NVC precompiled" in result.detail

    def test_unisim_sources_available(self, tmp_path, monkeypatch):
        """Cached VHDL sources exist → OK result."""
        from unittest.mock import patch

        from sdk.cli.checks.vendor_tools import check_unisim

        monkeypatch.chdir(tmp_path)
        (tmp_path / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: xilinx\n  part: xc7z020clg400-1\n"
        )
        cache_dir = tmp_path / "fake_cache"

        with patch(
            "routertl_core.sim.vendor_libraries.nvc_unisim_available",
            return_value=False,
        ), patch(
            "routertl_core.sim.vendor_libraries.ghdl_unisim_available",
            return_value=False,
        ), patch(
            "routertl_core.sim.vendor_libraries._resolve_unisim_path",
            return_value=cache_dir,
        ):
            result = check_unisim()

        assert result.status == "ok"
        assert "VHDL sources available" in result.detail

    def test_unisim_not_available(self, tmp_path, monkeypatch):
        """No cache, no precompiled → WARN with fix command."""
        from unittest.mock import patch

        from sdk.cli.checks.vendor_tools import check_unisim

        monkeypatch.chdir(tmp_path)
        (tmp_path / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: xilinx\n  part: xc7z020clg400-1\n"
        )

        with patch(
            "routertl_core.sim.vendor_libraries.nvc_unisim_available",
            return_value=False,
        ), patch(
            "routertl_core.sim.vendor_libraries.ghdl_unisim_available",
            return_value=False,
        ), patch(
            "routertl_core.sim.vendor_libraries._resolve_unisim_path",
            return_value=None,
        ):
            result = check_unisim()

        assert result.status == "warn"
        assert "install-unisim" in result.fix_cmd

    def test_unisim_non_xilinx_skip(self, tmp_path, monkeypatch):
        """Non-Xilinx vendor (lattice) → OK with 'not required'."""
        from sdk.cli.checks.vendor_tools import check_unisim

        monkeypatch.chdir(tmp_path)
        (tmp_path / "project.yml").write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: lattice\n  part: LIFCL-40-9BG400C\n"
        )
        result = check_unisim()

        assert result.status == "ok"
        assert "not required" in result.detail
        assert "lattice" in result.detail


class TestQuartusEditionDetection:
    """Verify _parse_quartus_edition() extracts edition from version strings."""

    def test_sc_pro_edition(self):
        """SC Pro Edition (modern Quartus) → 'Pro'."""
        from sdk.cli.checks.vendor_tools import _parse_quartus_edition

        out = (
            "Quartus Prime Shell\n"
            "Version 25.3.0 Build 109 09/24/2025 SC Pro Edition\n"
            "Copyright (C) 2025  Altera Corporation. All rights reserved.\n"
        )
        assert _parse_quartus_edition(out) == "Pro"

    def test_pro_edition(self):
        """Legacy Pro Edition (no SC prefix) → 'Pro'."""
        from sdk.cli.checks.vendor_tools import _parse_quartus_edition

        out = "Version 22.4.0 Build 94 Pro Edition\n"
        assert _parse_quartus_edition(out) == "Pro"

    def test_standard_edition(self):
        """Standard Edition → 'Standard'."""
        from sdk.cli.checks.vendor_tools import _parse_quartus_edition

        out = "Version 23.1std.1 Build 993 Standard Edition\n"
        assert _parse_quartus_edition(out) == "Standard"

    def test_lite_edition(self):
        """Lite Edition → 'Lite'."""
        from sdk.cli.checks.vendor_tools import _parse_quartus_edition

        out = "Version 23.1 Build 115 Lite Edition\n"
        assert _parse_quartus_edition(out) == "Lite"

    def test_unknown_format(self):
        """Unrecognized output → None."""
        from sdk.cli.checks.vendor_tools import _parse_quartus_edition

        assert _parse_quartus_edition("Some Unknown Tool v1.0") is None

    def test_empty_string(self):
        """Empty string → None."""
        from sdk.cli.checks.vendor_tools import _parse_quartus_edition

        assert _parse_quartus_edition("") is None

