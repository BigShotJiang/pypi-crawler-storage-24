# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for `rr config list` Rich panel display."""

import sys
from pathlib import Path

import pytest
from click.testing import CliRunner

SDK_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(SDK_ROOT))

from sdk.cli.commands.config import config_command  # noqa: E402

# ── Rich project.yml with multiple sections ──────────────────
RICH_PROJECT_YML = """\
project:
  name: test_project
  top_module: test_top
  top_sim: tb_test_top

hardware:
  vendor: xilinx
  part: "xc7z020clg400-1"
  language: vhdl

simulation:
  test_dir: sim/cocotb/tests
  simulator: nvc

paths:
  sources: [hw/rtl, vendor/routertl/src/units]
  simulation: hw/sim

build_options:
  tool_version: "2024.1"

features:
  regbank: true

sources:
  syn:
    - hw/rtl/pkg/system_config_pkg.vhd
    - hw/rtl/sniffer/uart/uart_sniffer.vhd
  sim: []
  xdc: []

dependencies:
  xpm_vhdl:
    url: https://github.com/fransschreuder/xpm_vhdl.git
    path: libs/xpm_vhdl
    library: xpm

hooks:
  pre_commit:
    enabled: true
    lint: true
    check_yaml: true
    tests:
      - test_uart_sniffer_smoke
    exclude:
      lint:
        - hw/rtl/sniffer/infra/sniffer_gather.vhd
      tests: []

system_config: tools/sniffer-builder/config/sniffer_config.yml
"""


@pytest.fixture()
def cli_runner():
    return CliRunner()


@pytest.fixture()
def tmp_project(tmp_path, monkeypatch):
    yml = tmp_path / "project.yml"
    yml.write_text(RICH_PROJECT_YML)
    monkeypatch.chdir(tmp_path)
    return tmp_path


class TestConfigListRich:
    """Tests for the enhanced Rich panel display."""

    def test_list_exits_zero(self, cli_runner, tmp_project):
        """Default config list (Rich panels) should exit 0."""
        result = cli_runner.invoke(config_command, ["list"])
        assert result.exit_code == 0, f"Exit {result.exit_code}:\n{result.output}"

    def test_list_shows_project_name(self, cli_runner, tmp_project):
        """Rich output should contain the project name."""
        result = cli_runner.invoke(config_command, ["list"])
        assert "test_project" in result.output

    def test_list_shows_hardware(self, cli_runner, tmp_project):
        """Rich output should contain hardware section data."""
        result = cli_runner.invoke(config_command, ["list"])
        assert "xilinx" in result.output
        assert "xc7z020clg400-1" in result.output

    def test_list_shows_sources_counts(self, cli_runner, tmp_project):
        """Sources section should show file counts."""
        result = cli_runner.invoke(config_command, ["list"])
        # syn has 2 files
        assert "2" in result.output
        assert "syn" in result.output

    def test_list_shows_features(self, cli_runner, tmp_project):
        """Features should be rendered as badges."""
        result = cli_runner.invoke(config_command, ["list"])
        assert "regbank" in result.output

    def test_list_shows_hooks(self, cli_runner, tmp_project):
        """Hooks section should show pre-commit summary."""
        result = cli_runner.invoke(config_command, ["list"])
        assert "pre_commit" in result.output
        assert "enabled" in result.output

    def test_list_shows_section_count(self, cli_runner, tmp_project):
        """Header should show the number of sections."""
        result = cli_runner.invoke(config_command, ["list"])
        assert "sections" in result.output


class TestConfigListRaw:
    """Tests for the --raw backward compatibility flag."""

    def test_raw_exits_zero(self, cli_runner, tmp_project):
        """--raw should exit 0."""
        result = cli_runner.invoke(config_command, ["list", "--raw"])
        assert result.exit_code == 0

    def test_raw_produces_yaml(self, cli_runner, tmp_project):
        """--raw should produce valid YAML-like output."""
        result = cli_runner.invoke(config_command, ["list", "--raw"])
        # YAML output has "key: value" patterns
        assert "project:" in result.output
        assert "name: test_project" in result.output


class TestConfigListFlat:
    """Ensure --flat behavior is unchanged."""

    def test_flat_exits_zero(self, cli_runner, tmp_project):
        result = cli_runner.invoke(config_command, ["list", "--flat"])
        assert result.exit_code == 0

    def test_flat_shows_dot_notation(self, cli_runner, tmp_project):
        result = cli_runner.invoke(config_command, ["list", "--flat"])
        assert "project.name" in result.output


class TestConfigListSection:
    """Tests for the --section filter."""

    def test_section_filter(self, cli_runner, tmp_project):
        """--section hardware should only show hardware."""
        result = cli_runner.invoke(config_command, ["list", "--section", "hardware"])
        assert result.exit_code == 0
        assert "xilinx" in result.output
        # Should NOT show other sections
        assert "pre_commit" not in result.output

    def test_section_filter_invalid(self, cli_runner, tmp_project):
        """--section with invalid name should fail with helpful error."""
        result = cli_runner.invoke(config_command, ["list", "--section", "nonexistent"])
        assert result.exit_code != 0
        assert "nonexistent" in result.output
        assert "Available sections" in result.output


class TestConfigListNoYml:
    """Tests for missing project.yml."""

    def test_no_yml_exits_nonzero(self, cli_runner, tmp_path, monkeypatch):
        """Without project.yml, should fail with helpful error."""
        monkeypatch.chdir(tmp_path)
        result = cli_runner.invoke(config_command, ["list"])
        assert result.exit_code != 0
