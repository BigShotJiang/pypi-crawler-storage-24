# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT
"""Tests for SPDX license header compliance across all SDK source files.

Ensures every source file carries the correct SPDX-License-Identifier
matching its classification:
  - routertl_core/*.py (excl __init__.py)  → LicenseRef-RouteRTL-Proprietary
  - everything else (.py, .vhd, .sv, .v)  → MIT
"""

import sys
from pathlib import Path

import pytest

# Ensure the SDK root is on sys.path so relative imports resolve.
SDK_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(SDK_ROOT))

MIT_TAG = "SPDX-License-Identifier: MIT"
PROP_TAG = "SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary"

# Directories to skip (not our source)
SKIP_DIRS = {".git", "__pycache__", ".venv", "node_modules", "logs", ".mypy_cache"}


def _walk_files(root: Path, extensions: set[str]):
    """Yield source files under root matching any extension in the set."""
    import os

    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fname in filenames:
            fpath = Path(dirpath) / fname
            if fpath.suffix.lower() in extensions:
                yield fpath


def _is_proprietary(path: Path) -> bool:
    """True if file is in routertl_core/ and not an __init__.py stub."""
    try:
        rel = path.relative_to(SDK_ROOT / "routertl_core")
    except ValueError:
        return False
    return path.name != "__init__.py"


class TestSpdxHeaders:
    """Verify SPDX headers on all SDK source files."""

    def test_mit_python_files_have_spdx(self):
        """Every MIT-licensed .py file must contain the MIT SPDX tag."""
        missing = []
        for fpath in _walk_files(SDK_ROOT, {".py"}):
            if _is_proprietary(fpath):
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace")
            if MIT_TAG not in content:
                missing.append(str(fpath.relative_to(SDK_ROOT)))
        assert (
            missing == []
        ), f"{len(missing)} MIT .py files missing SPDX header:\n" + "\n".join(
            missing[:20]
        )

    def test_proprietary_python_files_have_spdx(self):
        """Every proprietary .py file must contain the proprietary SPDX tag."""
        core_dir = SDK_ROOT / "routertl_core"
        if not core_dir.exists():
            pytest.skip("routertl_core/ not present")
        missing = []
        for fpath in _walk_files(core_dir, {".py"}):
            if fpath.name == "__init__.py":
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace")
            if PROP_TAG not in content:
                missing.append(str(fpath.relative_to(SDK_ROOT)))
        assert (
            missing == []
        ), f"{len(missing)} proprietary .py files missing SPDX header:\n" + "\n".join(
            missing[:20]
        )

    def test_hdl_files_have_spdx(self):
        """Every .vhd / .sv / .v file must contain an MIT SPDX tag."""
        missing = []
        for fpath in _walk_files(SDK_ROOT, {".vhd", ".sv", ".v"}):
            content = fpath.read_text(encoding="utf-8", errors="replace")
            if MIT_TAG not in content:
                missing.append(str(fpath.relative_to(SDK_ROOT)))
        assert (
            missing == []
        ), f"{len(missing)} HDL files missing SPDX header:\n" + "\n".join(
            missing[:20]
        )

    def test_license_files_exist(self):
        """All three license files must exist."""
        for name in ("LICENSE", "LICENSE-MIT", "LICENSE-PROPRIETARY"):
            lf = SDK_ROOT / name
            assert lf.exists(), f"{name} does not exist at {lf}"
            assert lf.stat().st_size > 100, f"{name} appears empty"

    def test_no_proprietary_mit_mismatch(self):
        """No file in routertl_core/ (excl __init__.py) should have MIT tag."""
        core_dir = SDK_ROOT / "routertl_core"
        if not core_dir.exists():
            pytest.skip("routertl_core/ not present")
        mismatched = []
        for fpath in _walk_files(core_dir, {".py"}):
            if fpath.name == "__init__.py":
                continue
            content = fpath.read_text(encoding="utf-8", errors="replace")
            if MIT_TAG in content:
                mismatched.append(str(fpath.relative_to(SDK_ROOT)))
        assert (
            mismatched == []
        ), f"{len(mismatched)} core files incorrectly tagged as MIT:\n" + "\n".join(
            mismatched[:20]
        )
