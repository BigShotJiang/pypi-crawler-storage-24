# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Shared fixtures for CLI command smoke tests."""

import sys
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

# Ensure the SDK root is on sys.path so `from sdk.*` resolves.
SDK_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(SDK_ROOT))


# ── Minimal project.yml content ──────────────────────────────

MINIMAL_PROJECT_YML = """\
project:
  name: test_project
  top_module: test_top
hardware:
  vendor: xilinx
  part: xc7z020clg400-1
  language: vhdl
"""


@pytest.fixture()
def cli_runner():
    """Return a CliRunner with separated stderr."""
    return CliRunner()


@pytest.fixture()
def tmp_project(tmp_path, monkeypatch):
    """Create a temp dir with a minimal project.yml and chdir into it.

    The fixture yields the tmp_path for further manipulation.
    """
    yml_path = tmp_path / "project.yml"
    yml_path.write_text(MINIMAL_PROJECT_YML)
    monkeypatch.chdir(tmp_path)
    return tmp_path


@pytest.fixture()
def mock_version_file(tmp_project):
    """Write a fake VERSION file in the tmp_project directory."""
    version_file = tmp_project / "VERSION"
    version_file.write_text("system_major=3\nsystem_minor=0\n")
    return version_file


@pytest.fixture()
def mock_git():
    """Patch subprocess.run to intercept git commands.

    Returns a dict that can be mutated to control git command responses.
    The patch intercepts calls whose first arg starts with 'git' and
    returns controlled CompletedProcess objects.  Non-git calls pass
    through to the real subprocess.run.
    """
    import subprocess

    responses = {
        "rev-list": subprocess.CompletedProcess([], 0, stdout="42\n", stderr=""),
        "log": subprocess.CompletedProcess([], 0, stdout="abc1234\n", stderr=""),
        "fetch": subprocess.CompletedProcess([], 0, stdout="", stderr=""),
        "rev-parse": subprocess.CompletedProcess([], 0, stdout="/tmp/fake-repo\n", stderr=""),
    }

    real_run = subprocess.run

    def fake_run(cmd, *args, **kwargs):
        if isinstance(cmd, (list, tuple)) and len(cmd) > 0:
            # Flatten to find git subcommand
            str_cmd = [str(c) for c in cmd]
            if str_cmd[0] == "git" or (len(str_cmd) > 1 and str_cmd[0] == "git"):
                # Find the git subcommand (skip -C <path> flags)
                subcmd = None
                i = 1
                while i < len(str_cmd):
                    if str_cmd[i] == "-C":
                        i += 2  # skip -C and its argument
                        continue
                    subcmd = str_cmd[i]
                    break
                if subcmd and subcmd in responses:
                    return responses[subcmd]
                # Default: succeed silently
                return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")
        return real_run(cmd, *args, **kwargs)

    with patch("subprocess.run", side_effect=fake_run):
        yield responses
