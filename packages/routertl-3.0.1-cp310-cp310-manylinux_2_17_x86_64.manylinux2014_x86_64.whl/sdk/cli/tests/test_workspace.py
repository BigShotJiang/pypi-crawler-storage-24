# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Smoke tests for ``rr workspace`` commands."""

from unittest.mock import patch

from sdk.cli.main import cli


class TestRepairCommand:
    """Verify core behaviour of the workspace repair command."""

    def test_repair_exits_zero(self, cli_runner, tmp_project, mock_git):
        """Repair should exit 0 in a project dir (all checks skip gracefully)."""
        # Patch subprocess.run to intercept make calls
        import subprocess

        real_run = subprocess.run

        def fake_run(cmd, *args, **kwargs):
            if isinstance(cmd, (list, tuple)):
                str_cmd = [str(c) for c in cmd]
                if str_cmd[0] == "make":
                    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")
                if str_cmd[0] == "git" or (len(str_cmd) > 1 and str_cmd[0] == "git"):
                    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")
            return real_run(cmd, *args, **kwargs)

        with patch("subprocess.run", side_effect=fake_run):
            result = cli_runner.invoke(cli, ["workspace", "repair"], catch_exceptions=False)
        assert result.exit_code == 0, f"exit {result.exit_code}: {result.output}"
        assert "Traceback" not in result.output
        # Summary table must appear
        assert "Repair Summary" in result.output

    def test_repair_only_flag(self, cli_runner, tmp_project, mock_git):
        """--only build_env should run only the build_env repair."""
        import subprocess

        real_run = subprocess.run

        def fake_run(cmd, *args, **kwargs):
            if isinstance(cmd, (list, tuple)):
                str_cmd = [str(c) for c in cmd]
                if str_cmd[0] == "make":
                    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")
                if str_cmd[0] == "git":
                    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")
            return real_run(cmd, *args, **kwargs)

        with patch("subprocess.run", side_effect=fake_run):
            result = cli_runner.invoke(
                cli, ["workspace", "repair", "--only", "build_env"],
                catch_exceptions=False,
            )
        assert result.exit_code == 0, f"exit {result.exit_code}: {result.output}"
        assert "build_env" in result.output
        # nvc_workdir and deps should NOT appear as rows in the summary
        # (they are not in repairs_to_run when --only is used)
        lines = result.output.splitlines()
        repair_rows = [ln for ln in lines if "nvc_workdir" in ln and ("skip" in ln or "fixed" in ln)]
        assert len(repair_rows) == 0, "nvc_workdir should not appear when --only build_env"

    def test_repair_no_project_yml(self, cli_runner, mock_git):
        """Repair without project.yml should skip all repairs gracefully."""
        import subprocess

        real_run = subprocess.run

        def fake_run(cmd, *args, **kwargs):
            if isinstance(cmd, (list, tuple)):
                str_cmd = [str(c) for c in cmd]
                if str_cmd[0] in ("make", "git"):
                    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")
            return real_run(cmd, *args, **kwargs)

        with cli_runner.isolated_filesystem():
            with patch("subprocess.run", side_effect=fake_run):
                result = cli_runner.invoke(cli, ["workspace", "repair"], catch_exceptions=False)
            assert result.exit_code == 0
            assert "Traceback" not in result.output
            # All repairs should skip (no project.yml)
            assert "skip" in result.output.lower()
