# SPDX-License-Identifier: MIT
# Copyright (c) 2024-2026 Daniel J. Mazure
"""Tests for the logic-trace viewer manager."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from sdk.cli.viewer_manager import (
    _binary_name,
    _detect_platform,
    _find_asset,
    find_gtkwave,
    find_latest_waveform,
    get_cached_version,
    get_viewer_path,
    launch_viewer,
)

# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------


class TestPlatformDetection:
    """Tests for _detect_platform()."""

    @patch("sdk.cli.viewer_manager.platform.system", return_value="Linux")
    @patch("sdk.cli.viewer_manager.platform.machine", return_value="x86_64")
    def test_linux_x86_64(self, _m, _s):
        assert _detect_platform() == "linux-x86_64"

    @patch("sdk.cli.viewer_manager.platform.system", return_value="Windows")
    @patch("sdk.cli.viewer_manager.platform.machine", return_value="AMD64")
    def test_windows_amd64(self, _m, _s):
        assert _detect_platform() == "windows-x86_64"

    @patch("sdk.cli.viewer_manager.platform.system", return_value="Darwin")
    @patch("sdk.cli.viewer_manager.platform.machine", return_value="arm64")
    def test_macos_arm64(self, _m, _s):
        assert _detect_platform() == "macos-arm64"

    @patch("sdk.cli.viewer_manager.platform.system", return_value="FreeBSD")
    @patch("sdk.cli.viewer_manager.platform.machine", return_value="riscv64")
    def test_unsupported_raises(self, _m, _s):
        with pytest.raises(RuntimeError, match="Unsupported platform"):
            _detect_platform()


class TestBinaryName:
    """Tests for _binary_name()."""

    @patch("sdk.cli.viewer_manager.platform.system", return_value="Linux")
    def test_linux_binary(self, _s):
        assert _binary_name() == "logic_gui"

    @patch("sdk.cli.viewer_manager.platform.system", return_value="Windows")
    def test_windows_binary(self, _s):
        assert _binary_name() == "logic_cli.exe"


# ---------------------------------------------------------------------------
# Asset finding
# ---------------------------------------------------------------------------


class TestFindAsset:
    """Tests for _find_asset()."""

    def test_finds_matching_asset(self):
        release = {
            "tag_name": "v0.1.0",
            "assets": [
                {"name": "logic-trace-0.1.0-linux-x86_64.tar.gz", "browser_download_url": "https://example.com/linux.tar.gz", "url": "https://api.github.com/repos/test/releases/assets/123"},
                {"name": "logic-trace-0.1.0-windows-x86_64.zip", "browser_download_url": "https://example.com/windows.zip", "url": "https://api.github.com/repos/test/releases/assets/456"},
            ],
        }
        url, api_url, version = _find_asset(release, "linux-x86_64")
        assert url == "https://example.com/linux.tar.gz"
        assert api_url == "https://api.github.com/repos/test/releases/assets/123"
        assert version == "v0.1.0"

    def test_raises_when_no_match(self):
        release = {
            "tag_name": "v0.1.0",
            "assets": [
                {"name": "logic-trace-0.1.0-linux-x86_64.tar.gz", "browser_download_url": "https://example.com/linux.tar.gz", "url": "https://api.github.com/repos/test/releases/assets/123"},
            ],
        }
        with pytest.raises(RuntimeError, match="No release asset found"):
            _find_asset(release, "macos-arm64")


# ---------------------------------------------------------------------------
# Version cache
# ---------------------------------------------------------------------------


class TestCachedVersion:
    """Tests for get_cached_version()."""

    def test_returns_none_when_no_file(self, tmp_path):
        with patch("sdk.cli.viewer_manager.VERSION_FILE", tmp_path / ".version"):
            assert get_cached_version() is None

    def test_returns_version_from_file(self, tmp_path):
        vfile = tmp_path / ".version"
        vfile.write_text("v0.1.0\n")
        with patch("sdk.cli.viewer_manager.VERSION_FILE", vfile):
            assert get_cached_version() == "v0.1.0"


# ---------------------------------------------------------------------------
# get_viewer_path
# ---------------------------------------------------------------------------


class TestGetViewerPath:
    """Tests for get_viewer_path()."""

    def test_returns_cached_binary_if_exists(self, tmp_path):
        cache = tmp_path / "logic-trace"
        cache.mkdir()
        binary = cache / "logic_gui"
        binary.touch()

        with (
            patch("sdk.cli.viewer_manager.CACHE_DIR", cache),
            patch("sdk.cli.viewer_manager._binary_name", return_value="logic_gui"),
        ):
            result = get_viewer_path()
            assert result == binary

    def test_returns_none_on_download_failure(self, tmp_path):
        cache = tmp_path / "logic-trace"
        with (
            patch("sdk.cli.viewer_manager.CACHE_DIR", cache),
            patch("sdk.cli.viewer_manager._binary_name", return_value="logic_gui"),
            patch("sdk.cli.viewer_manager._fetch_latest_release", side_effect=RuntimeError("Network error")),
            patch("sdk.cli.viewer_manager._detect_platform", return_value="linux-x86_64"),
        ):
            result = get_viewer_path()
            assert result is None


# ---------------------------------------------------------------------------
# launch_viewer
# ---------------------------------------------------------------------------


class TestLaunchViewer:
    """Tests for launch_viewer()."""

    def test_returns_none_when_no_viewer(self, tmp_path):
        waveform = tmp_path / "test.fst"
        waveform.touch()
        result = launch_viewer(waveform, viewer_path=tmp_path / "nonexistent")
        assert result is None

    def test_returns_none_when_no_waveform(self, tmp_path):
        viewer = tmp_path / "logic_gui"
        viewer.touch()
        result = launch_viewer(tmp_path / "nonexistent.fst", viewer_path=viewer)
        assert result is None

    @patch("sdk.cli.viewer_manager.subprocess.Popen")
    def test_launches_successfully(self, mock_popen, tmp_path):
        viewer = tmp_path / "logic_gui"
        viewer.touch()
        waveform = tmp_path / "test.fst"
        waveform.touch()

        mock_proc = MagicMock()
        mock_popen.return_value = mock_proc

        result = launch_viewer(waveform, viewer_path=viewer)
        assert result == mock_proc
        mock_popen.assert_called_once()
        call_args = mock_popen.call_args[0][0]
        assert str(viewer) in call_args[0]
        assert str(waveform.resolve()) in call_args[1]


# ---------------------------------------------------------------------------
# find_latest_waveform
# ---------------------------------------------------------------------------


class TestFindLatestWaveform:
    """Tests for find_latest_waveform()."""

    def test_returns_none_for_missing_dir(self, tmp_path):
        assert find_latest_waveform(tmp_path / "nonexistent") is None

    def test_returns_none_for_empty_dir(self, tmp_path):
        assert find_latest_waveform(tmp_path) is None

    def test_finds_most_recent_fst(self, tmp_path):
        old = tmp_path / "old.fst"
        old.touch()
        import time
        time.sleep(0.05)
        new = tmp_path / "new.fst"
        new.touch()
        result = find_latest_waveform(tmp_path)
        assert result == new

    def test_finds_across_extensions(self, tmp_path):
        vcd = tmp_path / "test.vcd"
        vcd.touch()
        import time
        time.sleep(0.05)
        fst = tmp_path / "test.fst"
        fst.touch()
        result = find_latest_waveform(tmp_path)
        assert result == fst

    def test_ignores_non_waveform_files(self, tmp_path):
        txt = tmp_path / "test.txt"
        txt.touch()
        assert find_latest_waveform(tmp_path) is None


# ---------------------------------------------------------------------------
# find_gtkwave
# ---------------------------------------------------------------------------


class TestFindGtkwave:
    """Tests for find_gtkwave()."""

    @patch("sdk.cli.viewer_manager.shutil.which", return_value="/usr/bin/gtkwave")
    def test_found(self, _w):
        result = find_gtkwave()
        assert result == Path("/usr/bin/gtkwave")

    @patch("sdk.cli.viewer_manager.shutil.which", return_value=None)
    def test_not_found(self, _w):
        assert find_gtkwave() is None
