# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for ``rr ci generate``."""

from sdk.cli.main import cli


class TestCiGenerate:
    """Verify CI blueprint generation for GitHub and GitLab."""

    def test_generate_github(self, cli_runner, tmp_project):
        """Generate GitHub Actions config — file exists with expected stages."""
        result = cli_runner.invoke(
            cli, ["ci", "generate", "--provider", "github"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0, f"exit {result.exit_code}: {result.output}"

        workflow = tmp_project / ".github" / "workflows" / "routertl.yml"
        assert workflow.exists(), "GitHub workflow file not created"

        content = workflow.read_text()
        assert "rr lint" in content, "Missing lint stage"
        assert "rr sim" in content, "Missing sim stage"
        assert "routertl/dev:" in content, "Missing Docker image reference"

    def test_generate_gitlab(self, cli_runner, tmp_project):
        """Generate GitLab CI config — file exists with expected stages."""
        result = cli_runner.invoke(
            cli, ["ci", "generate", "--provider", "gitlab"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0, f"exit {result.exit_code}: {result.output}"

        ci_file = tmp_project / ".gitlab-ci.yml"
        assert ci_file.exists(), "GitLab CI file not created"

        content = ci_file.read_text()
        assert "image:" in content, "Missing GitLab image: directive"
        assert "rr lint" in content, "Missing lint stage"
        assert "rr sim" in content, "Missing sim stage"
        assert "routertl/dev:" in content, "Missing Docker image reference"

    def test_generate_no_project_yml(self, cli_runner):
        """Without project.yml, generate should fail with a helpful message."""
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(
                cli, ["ci", "generate", "--provider", "github"],
            )
            assert result.exit_code != 0, "Should fail without project.yml"
            assert "project.yml" in result.output, "Error should mention project.yml"

    def test_generate_github_with_synth(self, cli_runner, tmp_project):
        """--synth flag adds the synthesis stage to generated config."""
        result = cli_runner.invoke(
            cli, ["ci", "generate", "--provider", "github", "--synth"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0

        workflow = tmp_project / ".github" / "workflows" / "routertl.yml"
        content = workflow.read_text()
        assert "rr synth all" in content, "Missing synth stage"
