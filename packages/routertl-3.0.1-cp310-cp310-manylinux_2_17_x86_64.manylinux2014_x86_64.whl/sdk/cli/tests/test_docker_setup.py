# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Regression tests for 'rr docker setup' wizard.

Validates:
- Rich markup tags never leak into click.prompt() output (BUG: [dim]/[/] visible)
- MAC address auto-normalization (Windows dashes → Docker colons + lowercase)
- Per-tool license variables (QUARTUS_LICENSE, ALDEC_LICENSE)
- Clearing previously-set values with 'none'
"""

import sys
from pathlib import Path

import pytest
from click.testing import CliRunner

# Ensure the SDK root is on sys.path so `from sdk.*` resolves.
SDK_ROOT = Path(__file__).parent.parent.parent.parent.absolute()
if str(SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(SDK_ROOT))

from sdk.cli.commands.docker.setup import docker_setup  # noqa: E402


@pytest.fixture()
def runner():
    return CliRunner()


class TestDockerSetupPrompts:
    """Regression: Rich markup must never appear in click.prompt() output."""

    def test_no_rich_markup_in_prompt_output(self, runner, tmp_path, monkeypatch):
        """[dim], [/], [cyan], etc. must not appear as literal text.

        BUG (P2.44): _prompt() appended Rich tags like '[dim](e.g. ...)][/]'
        directly to the click.prompt() text.  click.prompt() doesn't interpret
        Rich markup, so users saw literal '[dim]' in their terminal.
        """
        monkeypatch.chdir(tmp_path)

        # Provide empty input for all 6 prompts (skip all)
        result = runner.invoke(docker_setup, input="\n\n\n\n\n\n")

        # Rich markup tags that should NEVER appear in raw prompt output
        for tag in ["[dim]", "[/]", "[cyan]", "[green]", "[yellow]"]:
            prompt_lines = [
                line for line in result.output.splitlines()
                if "(e.g." in line
            ]
            for line in prompt_lines:
                assert tag not in line, (
                    f"Rich markup '{tag}' leaked into prompt text: {line!r}"
                )


class TestPerToolLicenseVars:
    """Per-tool license variables are written to .env correctly."""

    def test_quartus_and_aldec_separate(self, runner, tmp_path, monkeypatch):
        """QUARTUS_LICENSE and ALDEC_LICENSE should be independent."""
        monkeypatch.chdir(tmp_path)

        result = runner.invoke(
            docker_setup,
            input="27000@intel-lic\n27009@aldec-lic\n\n\n\n\n",
        )

        env_file = tmp_path / ".env"
        assert env_file.exists(), ".env file was not created"
        content = env_file.read_text()
        assert "QUARTUS_LICENSE=27000@intel-lic" in content
        assert "ALDEC_LICENSE=27009@aldec-lic" in content
        # Old vars should NOT be written
        assert "LM_LICENSE_FILE" not in content
        assert "MGLS_LICENSE_FILE" not in content

    def test_clear_value_with_none(self, runner, tmp_path, monkeypatch):
        """Typing 'none' should clear a previously-set value."""
        monkeypatch.chdir(tmp_path)
        # Pre-seed .env
        (tmp_path / ".env").write_text("QUARTUS_LICENSE=old-server\n")

        result = runner.invoke(
            docker_setup,
            input="none\n27009@aldec-lic\n\n\n\n\n",
        )

        content = (tmp_path / ".env").read_text()
        assert "QUARTUS_LICENSE" not in content, (
            f"'none' should have cleared QUARTUS_LICENSE: {content!r}"
        )
        assert "ALDEC_LICENSE=27009@aldec-lic" in content


class TestMacAddressNormalization:
    """MAC address input should be auto-normalized to Docker format."""

    def test_windows_dashes_normalized_to_colons(self, runner, tmp_path, monkeypatch):
        """Windows Get-NetAdapter outputs E4-46-B0-29-81-B2 (dashes, uppercase).
        Docker requires e4:46:b0:29:81:b2 (colons, lowercase).
        """
        monkeypatch.chdir(tmp_path)

        result = runner.invoke(
            docker_setup,
            input="\n\n\n\n\nE4-46-B0-29-81-B2\n",
        )

        env_file = tmp_path / ".env"
        assert env_file.exists(), ".env file was not created"
        content = env_file.read_text()
        assert "e4:46:b0:29:81:b2" in content, (
            f"MAC not normalized to Docker format in .env: {content!r}"
        )
        assert "E4-46-B0-29-81-B2" not in content, (
            f"Windows-format MAC should be normalized: {content!r}"
        )

    def test_already_correct_format_unchanged(self, runner, tmp_path, monkeypatch):
        """If user enters colons+lowercase, it should be preserved as-is."""
        monkeypatch.chdir(tmp_path)

        result = runner.invoke(
            docker_setup,
            input="\n\n\n\n\n00:1a:2b:3c:4d:5e\n",
        )

        env_file = tmp_path / ".env"
        assert env_file.exists()
        content = env_file.read_text()
        assert "00:1a:2b:3c:4d:5e" in content


class TestTargetFlag:
    """P2.56: --target filters the setup wizard to tool-specific prompts."""

    def test_target_quartus_writes_license_not_aldec(self, runner, tmp_path, monkeypatch):
        """--target quartus should prompt for QUARTUS_LICENSE but not ALDEC_LICENSE."""
        monkeypatch.chdir(tmp_path)

        # Quartus has 4 prompts: QUARTUS_LICENSE, QUARTUS_INSTALLER_PATH,
        # EDA_INSTALL_DIR, EDA_MAC_ADDRESS_OVERRIDE
        result = runner.invoke(
            docker_setup,
            args=["--target", "quartus"],
            input="27000@intel-lic\n\n\n\n",
        )

        assert result.exit_code == 0, f"CLI failed: {result.output}"
        env_file = tmp_path / ".env"
        assert env_file.exists(), ".env file was not created"
        content = env_file.read_text()
        assert "QUARTUS_LICENSE=27000@intel-lic" in content
        # Aldec should NOT be prompted or written
        assert "ALDEC_LICENSE" not in content

    def test_target_vivado_only_relevant_prompts(self, runner, tmp_path, monkeypatch):
        """--target vivado should only prompt for VIVADO_INSTALLER_PATH + EDA_INSTALL_DIR."""
        monkeypatch.chdir(tmp_path)

        # Vivado has 2 prompts: VIVADO_INSTALLER_PATH, EDA_INSTALL_DIR
        result = runner.invoke(
            docker_setup,
            args=["--target", "vivado"],
            input="/mnt/vivado\n\n",
        )

        assert result.exit_code == 0, f"CLI failed: {result.output}"
        env_file = tmp_path / ".env"
        assert env_file.exists()
        content = env_file.read_text()
        assert "VIVADO_INSTALLER_PATH=/mnt/vivado" in content
        # Quartus/Aldec/MAC should NOT appear
        assert "QUARTUS_LICENSE" not in content
        assert "ALDEC_LICENSE" not in content
        assert "EDA_MAC_ADDRESS_OVERRIDE" not in content

    def test_target_preserves_unrelated_env_vars(self, runner, tmp_path, monkeypatch):
        """--target should not clear unrelated existing .env vars."""
        monkeypatch.chdir(tmp_path)
        # Pre-seed with Aldec license
        (tmp_path / ".env").write_text("ALDEC_LICENSE=27009@aldec\n")

        # Run with --target quartus (does not manage ALDEC_LICENSE)
        result = runner.invoke(
            docker_setup,
            args=["--target", "quartus"],
            input="27000@intel\n\n\n\n",
        )

        assert result.exit_code == 0
        content = (tmp_path / ".env").read_text()
        # Aldec should still be there — we didn't prompt for it
        assert "ALDEC_LICENSE=27009@aldec" in content
        assert "QUARTUS_LICENSE=27000@intel" in content
