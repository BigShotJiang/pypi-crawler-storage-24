# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Tests for ``rr license`` command and doctor licensed-families check."""

from unittest.mock import patch

from sdk.cli.main import cli


class TestLicenseCommand:
    """Verify core behaviour of the license command."""

    def test_license_exits_zero(self, cli_runner, tmp_project, mock_git):
        """License command should exit 0 even when checks warn/fail."""
        with patch.dict("os.environ", {"LM_LICENSE_FILE": "27009@192.168.0.39"}):
            with patch(
                "tools.cli.commands.license._probe_server", return_value=True
            ):
                with patch(
                    "tools.cli.commands.license._query_licensed_families",
                    return_value=("Quartus", ["Cyclone 10 GX"]),
                ):
                    result = cli_runner.invoke(
                        cli, ["license"], catch_exceptions=False
                    )
        assert result.exit_code == 0, f"exit {result.exit_code}: {result.output}"
        assert "Traceback" not in result.output

    def test_license_shows_env_var(self, cli_runner, tmp_project, mock_git):
        """License output should display the LM_LICENSE_FILE value."""
        with patch.dict("os.environ", {"LM_LICENSE_FILE": "27009@10.0.0.1"}):
            with patch(
                "tools.cli.commands.license._probe_server", return_value=True
            ):
                with patch(
                    "tools.cli.commands.license._query_licensed_families",
                    return_value=("Quartus", ["Arria 10"]),
                ):
                    result = cli_runner.invoke(
                        cli, ["license"], catch_exceptions=False
                    )
        assert "27009@10.0.0.1" in result.output

    def test_license_target_missing(self, cli_runner, tmp_project, mock_git):
        """When target family is missing, show NOT LICENSED."""
        # tmp_project has xilinx as vendor, but we override with altera + Arria 10
        yml = tmp_project / "project.yml"
        yml.write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: altera\n  part: 10AX115S2F45I1SG\n"
            "  family: Arria 10\n"
        )
        with patch.dict("os.environ", {"LM_LICENSE_FILE": "27009@192.168.0.39"}):
            with patch(
                "tools.cli.commands.license._probe_server", return_value=True
            ):
                with patch(
                    "tools.cli.commands.license._query_licensed_families",
                    return_value=("Quartus", ["Cyclone 10 GX"]),
                ):
                    result = cli_runner.invoke(
                        cli, ["license"], catch_exceptions=False
                    )
        assert "NOT LICENSED" in result.output

    def test_license_target_found(self, cli_runner, tmp_project, mock_git):
        """When target family is licensed, show TARGET marker."""
        yml = tmp_project / "project.yml"
        yml.write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: altera\n  part: 10AX115S2F45I1SG\n"
            "  family: Arria 10\n"
        )
        with patch.dict("os.environ", {"LM_LICENSE_FILE": "27009@192.168.0.39"}):
            with patch(
                "tools.cli.commands.license._probe_server", return_value=True
            ):
                with patch(
                    "tools.cli.commands.license._query_licensed_families",
                    return_value=(
                        "Quartus",
                        ["Arria 10", "Cyclone 10 GX"],
                    ),
                ):
                    result = cli_runner.invoke(
                        cli, ["license"], catch_exceptions=False
                    )
        assert "TARGET" in result.output
        assert "All good" in result.output

    def test_license_no_env_var(self, cli_runner, tmp_project, mock_git):
        """When LM_LICENSE_FILE is not set, still runs family query."""
        with patch.dict("os.environ", {}, clear=True):
            result = cli_runner.invoke(cli, ["license"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "not set" in result.output

    def test_license_server_unreachable(self, cli_runner, tmp_project, mock_git):
        """When TCP probe fails, show failure and stop early."""
        with patch.dict("os.environ", {"LM_LICENSE_FILE": "27009@10.0.0.1"}):
            with patch(
                "tools.cli.commands.license._probe_server", return_value=False
            ):
                result = cli_runner.invoke(
                    cli, ["license"], catch_exceptions=False
                )
        assert "not reachable" in result.output.lower() or "no" in result.output.lower()

    def test_license_no_eda_tool(self, cli_runner, tmp_project, mock_git):
        """When no EDA tool on PATH, show graceful message."""
        with patch.dict("os.environ", {"LM_LICENSE_FILE": "27009@10.0.0.1"}):
            with patch(
                "tools.cli.commands.license._probe_server", return_value=True
            ):
                with patch(
                    "tools.cli.commands.license._query_licensed_families",
                    return_value=(None, []),
                ):
                    result = cli_runner.invoke(
                        cli, ["license"], catch_exceptions=False
                    )
        assert result.exit_code == 0
        assert "No EDA tool" in result.output or "cannot query" in result.output


class TestDoctorLicensedFamilies:
    """Verify the licensed families check in the doctor flow."""

    def test_doctor_licensed_families_ok(self, cli_runner, tmp_project, mock_git):
        """When target family is licensed, doctor reports OK."""
        yml = tmp_project / "project.yml"
        yml.write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: altera\n  part: 10AX115S2F45I1SG\n"
            "  family: Arria 10\n"
        )
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.vendor_tools import check_licensed_families

        with patch("shutil.which", return_value="/usr/bin/quartus_sh"):
            with patch(
                "tools.cli.commands.license._query_licensed_families",
                return_value=("Quartus", ["Arria 10", "Cyclone 10 GX"]),
            ):
                results = check_licensed_families()
        assert len(results) == 1
        assert results[0].status == CheckResult.OK
        assert "Arria 10" in results[0].detail

    def test_doctor_licensed_families_fail(self, cli_runner, tmp_project, mock_git):
        """When target family is NOT licensed, doctor reports FAIL."""
        yml = tmp_project / "project.yml"
        yml.write_text(
            "project:\n  name: test\n  top_module: top\n"
            "hardware:\n  vendor: altera\n  part: 10AX115S2F45I1SG\n"
            "  family: Arria 10\n"
        )
        from sdk.cli.checks import CheckResult
        from sdk.cli.checks.vendor_tools import check_licensed_families

        with patch("shutil.which", return_value="/usr/bin/quartus_sh"):
            with patch(
                "tools.cli.commands.license._query_licensed_families",
                return_value=("Quartus", ["Cyclone 10 GX"]),
            ):
                results = check_licensed_families()
        assert len(results) == 1
        assert results[0].status == CheckResult.FAIL
        assert "NOT licensed" in results[0].detail

    def test_doctor_licensed_families_no_tool(
        self, cli_runner, tmp_project, mock_git
    ):
        """When no vendor tool on PATH, check returns empty (skip)."""
        from sdk.cli.checks.vendor_tools import check_licensed_families

        with patch("shutil.which", return_value=None):
            results = check_licensed_families()
        assert results == []
