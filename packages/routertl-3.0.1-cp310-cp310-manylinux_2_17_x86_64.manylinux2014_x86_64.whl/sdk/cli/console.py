# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Shared Rich console instance for the RouteRTL CLI.

All CLI commands should import ``console`` from this module instead of
creating their own instances.

Usage::

    from sdk.cli.console import console, success, warning, error

    console.print(f"[cyan]Info:[/] something happened")
    success("Build passed")
    warning("Missing optional dependency")
    error("File not found")
"""

from rich.console import Console

console = Console()


def success(msg: str) -> None:
    """Print a green success message."""
    console.print(f"[green]{msg}[/]")


def warning(msg: str) -> None:
    """Print a yellow warning message."""
    console.print(f"[yellow]{msg}[/]")


def error(msg: str) -> None:
    """Print a red error message."""
    console.print(f"[red]{msg}[/]")
