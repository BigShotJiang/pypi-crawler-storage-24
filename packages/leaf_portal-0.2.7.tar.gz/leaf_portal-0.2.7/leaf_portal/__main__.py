"""Entry point for `leaf-portal` CLI and `python -m leaf_portal`."""

import sys
import runpy
from pathlib import Path


def main():
    pkg_dir = Path(__file__).parent
    if str(pkg_dir) not in sys.path:
        sys.path.insert(0, str(pkg_dir))
    runpy.run_path(str(pkg_dir / "main.py"), run_name="__main__")


if __name__ == "__main__":
    main()
