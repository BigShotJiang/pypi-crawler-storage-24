import os
import logging
from pathlib import Path
from nicegui import ui, app
from dotenv import set_key, find_dotenv
import db
import auth as auth_module
import mail


@ui.page("/")
async def index():
    ui.navigate.to("/dashboard" if auth_module.is_authenticated() else "/login")


@ui.page("/login")
async def login_page():
    if auth_module.is_authenticated():
        ui.navigate.to("/dashboard")
        return

    # First-run: redirect to setup if schema not applied or no users exist
    if not await db.schema_applied():
        ui.navigate.to("/setup")
        return
    count = await db.fetchval("SELECT COUNT(*) FROM user_account")
    if count == 0:
        ui.navigate.to("/setup")
        return

    _login_form()


@ui.page("/setup")
async def setup_page():
    """First-run setup: phase 1 establish DB connection, phase 2 create superadmin."""
    # If already connected, apply schema and check for existing superadmin
    show_step2 = False
    if db.is_connected():
        await db.apply_schema()
        count = await db.fetchval(
            "SELECT COUNT(*) FROM user_account WHERE is_superadmin = true"
        )
        if count > 0:
            ui.navigate.to("/login")
            return
        show_step2 = True

    ui.colors(primary="#f15b25", secondary="#6fd3f2")
    with ui.column().classes("w-full h-screen items-center justify-center bg-gray-50"):
        with ui.card().classes("w-96 p-8 gap-2"):
            with ui.row().classes("items-center gap-3 mb-4"):
                ui.image("/images/icon.svg").classes("w-10 h-10")
                ui.label("LEAF Portal Setup").classes("text-xl font-bold text-gray-800")

            # ── Step 1: Database connection ───────────────────────────────────
            step1 = ui.column().classes("w-full gap-2")
            with step1:
                ui.label("Step 1 — Database connection").classes(
                    "text-sm font-semibold text-gray-600"
                )
                db_host = ui.input(
                    "Host", value=os.environ.get("PGHOST", "localhost")
                ).classes("w-full")
                db_port = ui.input(
                    "Port", value=os.environ.get("PGPORT", "5432")
                ).classes("w-full")
                db_user = ui.input(
                    "User", value=os.environ.get("PGUSER", "postgres")
                ).classes("w-full")
                db_pass = ui.input(
                    "Password",
                    value=os.environ.get("PGPASSWORD", ""),
                    password=True,
                    password_toggle_button=True,
                ).classes("w-full")
                db_name = ui.input(
                    "Database", value=os.environ.get("PGDATABASE", "leaf")
                ).classes("w-full")
                conn_error = ui.label("").classes("text-red-500 text-sm")

            # ── Step 2: Admin account ─────────────────────────────────────────
            step2 = ui.column().classes("w-full gap-2")
            with step2:
                ui.label("Step 2 — Admin account").classes(
                    "text-sm font-semibold text-gray-600"
                )
                name = ui.input("Full name").classes("w-full")
                email = ui.input("Email").classes("w-full").props("type=email")
                pw1 = ui.input(
                    "Password", password=True, password_toggle_button=True
                ).classes("w-full")
                pw2 = ui.input(
                    "Confirm password", password=True, password_toggle_button=True
                ).classes("w-full")
                acct_error = ui.label("").classes("text-red-500 text-sm")

            # ── Callbacks ─────────────────────────────────────────────────────
            async def do_connect():
                conn_error.text = ""
                try:
                    await db.connect(
                        host=db_host.value,
                        port=int(db_port.value),
                        user=db_user.value,
                        password=db_pass.value,
                        database=db_name.value,
                    )
                    # Persist credentials so the next startup connects automatically
                    env_file = find_dotenv() or str(Path.cwd() / ".env")
                    set_key(env_file, "PGHOST", db_host.value)
                    set_key(env_file, "PGPORT", db_port.value)
                    set_key(env_file, "PGUSER", db_user.value)
                    set_key(env_file, "PGPASSWORD", db_pass.value)
                    set_key(env_file, "PGDATABASE", db_name.value)
                    await db.apply_schema()
                    count = await db.fetchval(
                        "SELECT COUNT(*) FROM user_account WHERE is_superadmin = true"
                    )
                    if count > 0:
                        ui.notify(
                            "Already configured — please sign in.", color="positive"
                        )
                        ui.navigate.to("/login")
                        return
                    step1.set_visibility(False)
                    step2.set_visibility(True)
                except Exception as e:
                    conn_error.text = f"Connection failed: {e}"

            async def create_account():
                acct_error.text = ""
                if not all([name.value, email.value, pw1.value, pw2.value]):
                    acct_error.text = "All fields are required."
                    return
                if pw1.value != pw2.value:
                    acct_error.text = "Passwords do not match."
                    return
                if len(pw1.value) < 8:
                    acct_error.text = "Password must be at least 8 characters."
                    return
                try:
                    hashed = await auth_module.hash_password(pw1.value)
                    await db.execute(
                        """
                        INSERT INTO user_account (email, name, password_hash, is_superadmin)
                        VALUES ($1, $2, $3, true)
                        """,
                        email.value.lower().strip(),
                        name.value.strip(),
                        hashed,
                    )
                    ui.notify("Account created — please sign in.", color="positive")
                    ui.navigate.to("/login")
                except Exception as e:
                    acct_error.text = f"Error: {e}"

            # ── Buttons ───────────────────────────────────────────────────────
            with step1:
                ui.button("Connect", icon="link", on_click=do_connect).classes(
                    "w-full mt-2"
                ).props("color=primary")
            with step2:
                ui.button(
                    "Create account", icon="person_add", on_click=create_account
                ).classes("w-full mt-2").props("color=primary")

            # ── Initial visibility ────────────────────────────────────────────
            step1.set_visibility(not show_step2)
            step2.set_visibility(show_step2)


def _login_form():
    ui.colors(primary="#f15b25", secondary="#6fd3f2")
    with ui.column().classes("w-full h-screen items-center justify-center bg-gray-50"):
        with ui.card().classes("w-96 p-8 gap-2"):
            with ui.row().classes("items-center gap-3 mb-4"):
                ui.image("/images/icon.svg").classes("w-10 h-10")
                ui.label("LEAF Portal").classes("text-2xl font-bold text-gray-800")

            email = ui.input("Email").classes("w-full").props("type=email")
            password = ui.input(
                "Password", password=True, password_toggle_button=True
            ).classes("w-full")
            error = ui.label("").classes("text-red-500 text-sm")

            async def do_login():
                error.text = ""
                user = await auth_module.verify_login(email.value, password.value)
                if user:
                    app.storage.user["user"] = {
                        "id": str(user["id"]),
                        "email": user["email"],
                        "name": user["name"],
                        "is_superadmin": user["is_superadmin"],
                    }
                    ui.navigate.to("/dashboard")
                else:
                    error.text = "Invalid email or password."

            ui.button("Sign in", on_click=do_login, icon="login").classes(
                "w-full mt-2"
            ).props("color=primary")
            password.on("keydown.enter", do_login)
            ui.link("Forgot password?", "/forgot-password").classes(
                "text-sm text-gray-400 mt-1 self-end"
            )


@ui.page("/forgot-password")
async def forgot_password_page():
    if auth_module.is_authenticated():
        ui.navigate.to("/dashboard")
        return

    ui.colors(primary="#f15b25", secondary="#6fd3f2")
    with ui.column().classes("w-full h-screen items-center justify-center bg-gray-50"):
        with ui.card().classes("w-96 p-8 gap-2"):
            with ui.row().classes("items-center gap-3 mb-2"):
                ui.image("/images/icon.svg").classes("w-10 h-10")
                ui.label("Reset password").classes("text-xl font-bold text-gray-800")

            ui.label(
                "Enter your email and we will send you a reset link (valid 1 hour)."
            ).classes("text-sm text-gray-500 mb-2")

            email_input = ui.input("Email").classes("w-full").props("type=email")
            msg = ui.label("").classes("text-sm")

            async def request_reset():
                addr = email_input.value.lower().strip()
                if not addr:
                    msg.classes(replace="text-sm text-red-500")
                    msg.text = "Enter your email address."
                    return
                try:
                    token = await auth_module.create_reset_token(addr)
                    if token:
                        portal_url = os.environ.get(
                            "PORTAL_URL", "http://localhost:8081"
                        )
                        reset_link = f"{portal_url}/reset-password?token={token}"
                        await mail.send_email(
                            to=addr,
                            subject="LEAF Portal — password reset",
                            body=(
                                f"Click the link below to reset your password (valid for 1 hour):\n\n"
                                f"{reset_link}\n\n"
                                f"If the link does not work, go to {portal_url}/reset-password\n"
                                f"and enter this code manually:\n\n"
                                f"{token}\n\n"
                                f"If you did not request this, you can ignore this email."
                            ),
                        )
                except Exception:
                    logging.exception("Password reset email failed")
                msg.classes(replace="text-sm").style("color: #f15b25")
                msg.text = "If you are registered, you will receive an email."

            ui.button("Send reset link", on_click=request_reset, icon="send").classes(
                "w-full mt-2"
            ).props("color=primary")
            ui.link("Back to login", "/login").classes("text-sm text-gray-400 mt-1")


@ui.page("/reset-password")
async def reset_password_page(token: str = ""):
    if auth_module.is_authenticated():
        ui.navigate.to("/dashboard")
        return

    ui.colors(primary="#f15b25", secondary="#6fd3f2")
    with ui.column().classes("w-full h-screen items-center justify-center bg-gray-50"):
        with ui.card().classes("w-96 p-8 gap-2"):
            with ui.row().classes("items-center gap-3 mb-2"):
                ui.image("/images/icon.svg").classes("w-10 h-10")
                ui.label("Set new password").classes("text-xl font-bold text-gray-800")

            if not token:
                # URL parameter was stripped — let the user paste the token manually
                ui.label("Paste the reset code from your email:").classes(
                    "text-sm text-gray-500"
                )
                token_input = ui.input("Reset code").classes("w-full")
                error_lbl = ui.label("").classes("text-red-500 text-sm")

                def go():
                    v = token_input.value.strip()
                    if not v:
                        error_lbl.text = "Paste the reset code from your email."
                        return
                    ui.navigate.to(f"/reset-password?token={v}")

                ui.button("Continue", on_click=go, icon="arrow_forward").classes(
                    "w-full mt-2"
                ).props("color=primary")
                ui.link("Back to login", "/login").classes("text-sm text-gray-400 mt-1")
                return

            user_info = await auth_module.verify_reset_token(token)
            if not user_info:
                ui.label(
                    "This reset link is invalid or has already been used."
                ).classes("text-red-500 text-sm")
                ui.link("Request a new one", "/forgot-password").classes(
                    "text-sm text-gray-400 mt-1"
                )
                return

            ui.label(f"Resetting password for {user_info['email']}").classes(
                "text-sm text-gray-500 mb-2"
            )

            pw1 = ui.input(
                "New password", password=True, password_toggle_button=True
            ).classes("w-full")
            pw2 = ui.input(
                "Confirm password", password=True, password_toggle_button=True
            ).classes("w-full")
            error = ui.label("").classes("text-red-500 text-sm")

            async def save():
                error.text = ""
                if pw1.value != pw2.value:
                    error.text = "Passwords do not match."
                    return
                if len(pw1.value) < 8:
                    error.text = "Password must be at least 8 characters."
                    return
                await auth_module.consume_reset_token(
                    str(user_info["token_id"]),
                    str(user_info["id"]),
                    pw1.value,
                )
                ui.notify("Password updated. Please sign in.", color="positive")
                ui.navigate.to("/login")

            ui.button("Set password", on_click=save, icon="lock_reset").classes(
                "w-full mt-2"
            ).props("color=primary")
            pw1.on("keydown.enter", save)
