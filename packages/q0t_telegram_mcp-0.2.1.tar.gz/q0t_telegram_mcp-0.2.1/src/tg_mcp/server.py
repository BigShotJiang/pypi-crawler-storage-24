from __future__ import annotations

import dataclasses
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp import Context

from .client import TelegramClientWrapper
from .config import Config


@dataclass
class AppContext:
    """Holds shared resources available to every MCP tool during a server session."""

    client: TelegramClientWrapper


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """Connect to Telegram on startup and disconnect on shutdown.

    Raises:
        EnvironmentError: If ``TG_APP_ID`` or ``TG_API_HASH`` is not set.
        RuntimeError: If no authorized session exists (run ``auth`` first).
    """
    config = Config.from_env()
    client = TelegramClientWrapper(config)
    await client.connect()
    try:
        yield AppContext(client=client)
    finally:
        await client.disconnect()


mcp = FastMCP("q0t-telegram-mcp", lifespan=lifespan)


@mcp.tool()
async def tg_me(ctx: Context) -> dict:
    """Get current Telegram account info."""
    client: TelegramClientWrapper = ctx.request_context.lifespan_context.client
    try:
        user_info = await client.get_me()
        return dataclasses.asdict(user_info)
    except ValueError as e:
        return {"error": str(e)}


@mcp.tool()
async def tg_dialogs(
    ctx: Context,
    unread_only: bool = False,
    limit: int = 20,
    offset: int = 0,
) -> list[dict]:
    """List Telegram dialogs (chats, groups, channels)."""
    client: TelegramClientWrapper = ctx.request_context.lifespan_context.client
    try:
        dialogs = await client.get_dialogs(unread_only=unread_only, limit=limit, offset=offset)
        return [dataclasses.asdict(d) for d in dialogs]
    except ValueError as e:
        return [{"error": str(e)}]


@mcp.tool()
async def tg_dialog(
    ctx: Context,
    dialog_id: int | None = None,
    username: str | None = None,
    name: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> list[dict]:
    """Get messages from a Telegram dialog.

    To identify the dialog, supply **exactly one** of the following (all three solve the same
    problem — pick the most specific one you have):

    - `dialog_id` (int) — numeric ID from `tg_dialogs`. Most reliable, no ambiguity.
    - `username` (str) — Telegram @handle, e.g. `adilet_c` or `@adilet_c` (leading @ is optional).
    - `name` (str) — display name, e.g. `"Adilet"`. Use only when dialog_id/username are unavailable;
      may resolve to the wrong contact when names are not unique.

    Priority when multiple are given: dialog_id > username > name.
    """
    if dialog_id is None and username is None and name is None:
        raise ValueError("One of dialog_id, username, or name must be provided")
    client: TelegramClientWrapper = ctx.request_context.lifespan_context.client
    try:
        messages = await client.get_messages(
            dialog_id=dialog_id, username=username, name=name, limit=limit, offset=offset
        )
        return [dataclasses.asdict(m) for m in messages]
    except ValueError as e:
        return [{"error": str(e)}]


@mcp.tool()
async def tg_send(
    ctx: Context,
    text: str,
    dialog_id: int | None = None,
    username: str | None = None,
    name: str | None = None,
) -> dict:
    """Send a message to a Telegram dialog.

    To identify the recipient, supply **exactly one** of the following (all three solve the same
    problem — pick the most specific one you have):

    - `dialog_id` (int) — numeric ID from `tg_dialogs`. Most reliable, no ambiguity.
    - `username` (str) — Telegram @handle, e.g. `adilet_c` or `@adilet_c` (leading @ is optional).
    - `name` (str) — display name, e.g. `"Adilet"`. Use only when dialog_id/username are unavailable;
      may resolve to the wrong contact when names are not unique.

    Priority when multiple are given: dialog_id > username > name.
    """
    if dialog_id is None and username is None and name is None:
        raise ValueError("One of dialog_id, username, or name must be provided")
    client: TelegramClientWrapper = ctx.request_context.lifespan_context.client
    try:
        await client.send_message(text=text, dialog_id=dialog_id, username=username, name=name)
        return {"ok": True}
    except ValueError as e:
        return {"error": str(e)}


@mcp.tool()
async def tg_read(
    ctx: Context,
    dialog_id: int | None = None,
    username: str | None = None,
    name: str | None = None,
) -> dict:
    """Mark all messages in a dialog as read.

    To identify the dialog, supply **exactly one** of the following (all three solve the same
    problem — pick the most specific one you have):

    - `dialog_id` (int) — numeric ID from `tg_dialogs`. Most reliable, no ambiguity.
    - `username` (str) — Telegram @handle, e.g. `adilet_c` or `@adilet_c` (leading @ is optional).
    - `name` (str) — display name, e.g. `"Adilet"`. Use only when dialog_id/username are unavailable;
      may resolve to the wrong contact when names are not unique.

    Priority when multiple are given: dialog_id > username > name.
    """
    if dialog_id is None and username is None and name is None:
        raise ValueError("One of dialog_id, username, or name must be provided")
    client: TelegramClientWrapper = ctx.request_context.lifespan_context.client
    try:
        await client.mark_read(dialog_id=dialog_id, username=username, name=name)
        return {"ok": True}
    except ValueError as e:
        return {"error": str(e)}


def run_server() -> None:
    """Start the MCP server. Blocks until the server is stopped."""
    mcp.run()
