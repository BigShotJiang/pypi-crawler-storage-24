from .core import ChyooView, extract_video_id
import os
from concurrent.futures import ThreadPoolExecutor

class XGenRunner:
    def __repr__(self):
        print("\n\033[95m★ X-Gen Automation Library ★\033[0m")
        url = input('- Enter your Video url : ')
        session_file = input('- Enter your file session : ')

        if not os.path.isfile(session_file):
            return f"[!] Error: {session_file} not found."

        video_id = extract_video_id(url)
        if not video_id:
            return "[!] Error: Invalid URL."

        sessions = [s.strip() for s in open(session_file) if s.strip()]
        print(f'[ # ] - Sessions: {len(sessions)} | Video ID: {video_id}\n')

        with ThreadPoolExecutor(max_workers=100) as executor:
            try:
                while True:
                    for sess in sessions:
                        executor.submit(ChyooView(sess, video_id).boost_view)
            except KeyboardInterrupt:
                return "\n[!] Stopped."
        return "Done."

xgen = XGenRunner()
