import os
import re
import requests
import time
import secrets
import binascii
import uuid
import random
import subprocess
from concurrent.futures import ThreadPoolExecutor
import SignerPy

# دالة استخراج معلومات الجهاز (الموديل، الماركة، الإصدار)
def get_device_info():
    try:    m = subprocess.getoutput("getprop ro.product.model").strip()
    except: m = "SM-A127F"
    try:    b = subprocess.getoutput("getprop ro.product.brand").strip()
    except: b = "samsung"
    try:    c = subprocess.getprop("ro.build.display.id").strip()
    except: c = "RP1A.200720.011"
    return m, b, c

MODEL, BRAND, BUILD = get_device_info()

# دالة استخراج معرف الفيديو من الرابط
def extract_video_id(url):
    url = url.strip()
    match = re.search(r'/(video|photo)/(\d+)', url)
    if match:
        return match.group(2)
    
    try:
        r = requests.get(url, allow_redirects=True, timeout=10)
        match = re.search(r'/(video|photo)/(\d+)', r.url)
        if match:
            return match.group(2)
    except:
        pass
    return None

# دالة بناء البارامترات المشتركة لطلبات تيك توك
def build_common_params():
    ts = int(time.time())
    return {
        "device_id":        str(random.randint(10**17, 10**19)),
        "iid":              str(random.randint(10**17, 10**19)),
        "openudid":         binascii.hexlify(os.urandom(8)).decode(),
        "cdid":             str(uuid.uuid4()),
        "app_name":         "musical_ly",
        "version_code":     "390603",
        "version_name":     "39.6.3",
        "app_version":      "39.6.3",
        "manifest_version_code": "2023906030",
        "update_version_code":   "2023906030",
        "ab_version":            "39.6.3",
        "resolution":            "1080*2220",
        "dpi":                   "440",
        "device_platform":       "android",
        "device_type":           MODEL,
        "device_brand":          BRAND,
        "os_api":                "30",
        "os_version":             "11",
        "os":                     "android",
        "host_abi":               "arm64-v8a",
        "language":               "ar",
        "locale":                 "ar",
        "region":                 "EG",
        "current_region":         "YE",
        "sys_region":             "EG",
        "carrier_region":         "YE",
        "residence":              "YE",
        "app_language":           "ar",
        "app_type":               "normal",
        "channel":                "googleplay",
        "aid":                    "1233",
        "ts":                   str(ts),
        "_rticket":            str(ts * 1000),
    }

# الكلاس الأساسي لزيادة المشاهدات
class ChyooView:
    def __init__(self, sessionid, video_id):
        self.sessionid = sessionid
        self.video_id = video_id
        self.csrf = secrets.token_hex(16)
        self.counter = 0 # عداد محلي لكل كائن
        self.cookies = {
            'sessionid': sessionid,
            'sid_tt':    sessionid,
            'passport_csrf_token':           self.csrf,
            'passport_csrf_token_default':   self.csrf,
        }
        self.headers = {
            'User-Agent': f'com.tiktok.lite.go/390054 (Linux; U; Android 13; en_GB; {MODEL}; Build/{BUILD};tt-ok/3.12.13.34-ul)',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        }

    def boost_view(self):
        params = build_common_params()
        params.update({
            'play_delta': '1',
            'stats_channel': 'play',
            'item_id':       self.video_id,
        })

        try:
            # استخدام مكتبة التشفير SignerPy
            sig = SignerPy.sign(params=params, cookie=self.cookies)
            
            hdr = self.headers.copy()
            hdr['x-tt-passport-csrf-token'] = self.csrf
            hdr.update(sig)
            hdr['Cookie'] = '; '.join(f'{k}={v}' for k, v in self.cookies.items())

            url = 'https://api16-core-c-alisg.tiktokv.com/aweme/v1/aweme/stats/'
            resp = requests.post(url, params=params, headers=hdr, cookies=self.cookies, timeout=10)
            data = resp.json()
            
            if data.get('status_code') == 0:
                print(f"\033[92m[ {self.sessionid[:10]}... ] [ Good ]\033[0m")
                return True
        except Exception as e:
            pass
        return False
