"""Allow running as `python -m clawsy`."""

from clawsy.cli import cli

cli()
