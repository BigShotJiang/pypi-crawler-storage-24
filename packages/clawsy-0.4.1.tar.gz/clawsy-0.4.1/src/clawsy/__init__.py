"""Clawsy CLI — distributed AI file optimization."""

__version__ = "0.1.1"
