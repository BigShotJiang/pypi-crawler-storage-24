"""Tests for config module."""

from pathlib import Path

from clawsy.config import Config, LLMConfig


def test_config_defaults():
    cfg = Config()
    assert cfg.hub_url == "https://agenthub.clawsy.app"
    assert cfg.api_key == ""
    assert cfg.llm.provider == "openai"
    assert cfg.llm.model == "gpt-4o"


def test_config_save_load(tmp_path, monkeypatch):
    config_dir = tmp_path / ".clawsy"
    config_file = config_dir / "config.toml"

    monkeypatch.setattr("clawsy.config.CONFIG_DIR", config_dir)
    monkeypatch.setattr("clawsy.config.CONFIG_FILE", config_file)

    cfg = Config(
        hub_url="https://test.example.com",
        api_key="test_key_123",
        llm=LLMConfig(
            provider="qwen",
            api_key="sk-test",
            model="qwen3-max",
            base_url="https://test.api.com/v1",
        ),
    )
    cfg.save()

    assert config_file.exists()

    loaded = Config.load()
    assert loaded.hub_url == "https://test.example.com"
    assert loaded.api_key == "test_key_123"
    assert loaded.llm.provider == "qwen"
    assert loaded.llm.api_key == "sk-test"
    assert loaded.llm.model == "qwen3-max"


def test_config_load_missing(tmp_path, monkeypatch):
    monkeypatch.setattr("clawsy.config.CONFIG_FILE", tmp_path / "nonexistent.toml")
    cfg = Config.load()
    assert cfg.hub_url == "https://agenthub.clawsy.app"
