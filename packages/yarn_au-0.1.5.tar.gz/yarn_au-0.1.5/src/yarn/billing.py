"""Billing operations — balance, usage, top-up, charges, invoices."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import Client


class Billing:
    def __init__(self, client: Client):
        self._client = client

    def balance(self) -> dict:
        """Get current balance in AUD."""
        return self._client.get("/v1/billing/balance")

    def usage(
        self,
        period: str = "daily",
        from_date: str = "",
        to_date: str = "",
    ) -> dict:
        """Get aggregated spend over a time period."""
        params: dict[str, str] = {"period": period}
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        return self._client.get("/v1/billing/usage", params=params)

    def top_up_suggestions(self) -> list[dict]:
        """List suggested top-up amounts."""
        return self._client.get("/v1/billing/top-up/suggestions")

    def top_up(self, amount: float) -> dict:
        """Add funds to balance.

        Args:
            amount: Dollar amount (AUD) to add.
        """
        return self._client.post("/v1/billing/top-up", json={"amount": amount})

    def charges(self, limit: int = 20) -> list[dict]:
        """List recent charges.

        Args:
            limit: Maximum number of charges to return.
        """
        return self._client.get("/v1/billing/charges", params={"limit": limit})

    def invoices(self, limit: int = 20) -> list[dict]:
        """List invoices.

        Args:
            limit: Maximum number of invoices to return.
        """
        return self._client.get("/v1/billing/invoices", params={"limit": limit})

    def itemised(
        self,
        from_date: str = "",
        to_date: str = "",
        limit: int = 50,
    ) -> dict:
        """Get per-workload cost breakdown.

        Args:
            from_date: Start date (YYYY-MM-DD).
            to_date: End date (YYYY-MM-DD).
            limit: Maximum items to return.
        """
        params: dict[str, str | int] = {"limit": limit}
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        return self._client.get("/v1/billing/usage/itemised", params=params)

    def tax_settings(self) -> dict:
        """Get tax/GST settings."""
        return self._client.get("/v1/billing/tax")

    def update_tax_settings(
        self,
        abn: str | None = None,
        gst_registered: bool = False,
        business_name: str | None = None,
    ) -> dict:
        """Update tax/GST settings.

        Args:
            abn: Australian Business Number (11 digits).
            gst_registered: Whether the entity is GST-registered.
            business_name: Registered business name.
        """
        payload: dict = {"gst_registered": gst_registered}
        if abn is not None:
            payload["abn"] = abn
        if business_name is not None:
            payload["business_name"] = business_name
        return self._client.put("/v1/billing/tax", json=payload)

    def annual_summary(self, fy: str) -> dict:
        """Get financial year summary for grant acquittal.

        Args:
            fy: Financial year in YYYY-YYYY format (e.g. '2025-2026').
        """
        return self._client.get("/v1/billing/annual-summary", params={"fy": fy})

    def annual_summary_csv(self, fy: str) -> str:
        """Download financial year summary as CSV.

        Args:
            fy: Financial year in YYYY-YYYY format (e.g. '2025-2026').

        Returns:
            CSV content as string.
        """
        resp = self._client._session.get(
            f"{self._client.base_url}/v1/billing/annual-summary/csv",
            params={"fy": fy},
            timeout=self._client.timeout,
        )
        resp.raise_for_status()
        return resp.text

    def create_project(self, name: str, description: str = "") -> dict:
        """Create a research project.

        Args:
            name: Project name (unique per account).
            description: Project description.
        """
        return self._client.post(
            "/v1/billing/projects",
            json={"name": name, "description": description},
        )

    def list_projects(self, include_archived: bool = False) -> list[dict]:
        """List research projects."""
        params = {}
        if include_archived:
            params["include_archived"] = "true"
        return self._client.get("/v1/billing/projects", params=params)

    def get_project(self, project_id: str) -> dict:
        """Get a project by ID."""
        return self._client.get(f"/v1/billing/projects/{project_id}")

    def update_project(
        self,
        project_id: str,
        name: str | None = None,
        description: str | None = None,
        archived: bool | None = None,
    ) -> dict:
        """Update a project.

        Args:
            project_id: Project UUID.
            name: New name.
            description: New description.
            archived: Archive/unarchive.
        """
        payload: dict = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if archived is not None:
            payload["archived"] = archived
        return self._client.patch(f"/v1/billing/projects/{project_id}", json=payload)

    def delete_project(self, project_id: str) -> None:
        """Delete a project."""
        self._client.delete(f"/v1/billing/projects/{project_id}")

    def project_spending(
        self,
        project_id: str,
        from_date: str = "",
        to_date: str = "",
    ) -> dict:
        """Get spending summary for a project.

        Args:
            project_id: Project UUID.
            from_date: Start date (YYYY-MM-DD).
            to_date: End date (YYYY-MM-DD).
        """
        params: dict[str, str] = {}
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        return self._client.get(f"/v1/billing/projects/{project_id}/spending", params=params)
