"""Research secret management."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import Client


class Secrets:
    def __init__(self, client: Client):
        self._client = client

    def create(self, name: str, value: str, description: str = "") -> dict:
        """Create or update a secret."""
        return self._client.post(
            "/v1/research/secrets",
            json={"name": name, "value": value, "description": description},
        )

    def list(self) -> list[dict]:
        """List secrets (names and descriptions only, never values)."""
        return self._client.get("/v1/research/secrets")

    def delete(self, name: str) -> None:
        """Delete a secret by name."""
        self._client.delete(f"/v1/research/secrets/{name}")
