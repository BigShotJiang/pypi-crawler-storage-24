"""Typed exceptions for Yarn API errors."""


class YarnError(Exception):
    """Base exception for Yarn SDK."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response: dict | None = None,
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response


class AuthenticationError(YarnError):
    """401 — invalid or missing API key."""


class PermissionError(YarnError):
    """403 — missing required role (e.g. researcher)."""


class InsufficientCredits(YarnError):
    """402 — not enough credit balance."""


class NotFoundError(YarnError):
    """404 — resource does not exist."""


class QuotaExceeded(YarnError):
    """413 — storage or compute quota exceeded."""


class RateLimitError(YarnError):
    """429 — too many requests."""


class ServiceUnavailable(YarnError):
    """502/503 — backend service unavailable."""
