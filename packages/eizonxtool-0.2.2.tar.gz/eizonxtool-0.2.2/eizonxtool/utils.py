import os
import hashlib
import uuid
import threading
import queue
import httpx
from colorama import Fore, Style, init
from pyfiglet import Figlet
from fake_useragent import UserAgent
from cfonts import render as cfont_render
try:
    from user_agent import generate_user_agent
except:
    generate_user_agent = None

init(autoreset=True)
ua = UserAgent()

def random_user_agent():
    return ua.random

def figlet_font(text, font='slant'):
    f = Figlet(font=font)
    return f.renderText(text)

def colored_print(text, color='green'):
    colors = {
        'green': Fore.GREEN,
        'red': Fore.RED,
        'blue': Fore.BLUE,
        'yellow': Fore.YELLOW,
        'cyan': Fore.CYAN,
        'magenta': Fore.MAGENTA,
        'white': Fore.WHITE,
    }
    print(colors.get(color, Fore.WHITE) + text + Style.RESET_ALL)

def cfont_text(text, font='block', colors=['cyan', 'white']):
    return cfont_render(text, font=font, colors=colors)

def generate_uuid():
    return str(uuid.uuid4())

def md5_hash(text):
    return hashlib.md5(text.encode()).hexdigest()

def sha256_hash(text):
    return hashlib.sha256(text.encode()).hexdigest()

def random_string(length=16, chars=None):
    import string, random
    if chars is None:
        chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))