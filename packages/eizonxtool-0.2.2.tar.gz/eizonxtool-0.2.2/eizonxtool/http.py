import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests_cache import CachedSession
from ratelimit import limits, sleep_and_retry
import aiohttp
from fake_useragent import UserAgent
import httpx

ua = UserAgent()

class EizonXSession(requests.Session):
    def __init__(self, retries=3, backoff_factor=0.3, timeout=10):
        super().__init__()
        self.timeout = timeout
        
        retry = Retry(total=retries, backoff_factor=backoff_factor, status_forcelist=[429, 500, 502, 503, 504])
        adapter = HTTPAdapter(max_retries=retry)
        self.mount("http://", adapter)
        self.mount("https://", adapter)
        
        self.headers.update({"User-Agent": ua.random})

    def request(self, method, url, **kwargs):
        if "timeout" not in kwargs:
            kwargs["timeout"] = self.timeout
        return super().request(method, url, **kwargs)

def cache_session(expire_after=300):
    session = CachedSession(expire_after=expire_after)
    session.headers.update({"User-Agent": ua.random})
    return session

@sleep_and_retry
@limits(calls=10, period=60)
def rate_limited_request(method, url, **kwargs):
    return requests.request(method, url, **kwargs)

async def async_get(url, **kwargs):
    async with aiohttp.ClientSession() as session:
        async with session.get(url, **kwargs) as response:
            return await response.text()

async def async_post(url, **kwargs):
    async with aiohttp.ClientSession() as session:
        async with session.post(url, **kwargs) as response:
            return await response.text()

from requests import (
    get, post, put, delete, head, patch, request,
    Request, Response, PreparedRequest,
    RequestException, HTTPError, ConnectionError, Timeout, TooManyRedirects,
    codes as status_codes,
)