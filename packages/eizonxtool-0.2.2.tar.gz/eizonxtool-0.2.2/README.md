# eizonxtool

#Kullanım
import eizonxtool as ex
ex.colored_print("Selam!", 'green')