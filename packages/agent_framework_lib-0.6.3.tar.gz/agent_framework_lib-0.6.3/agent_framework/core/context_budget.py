"""Context window budget management.

Provides model context window resolution and budget tracking
for managing LLM context window usage across agent sessions.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agent_framework.core.provider_calibration import ProviderCalibrationRegistry

if TYPE_CHECKING:
    from llama_index.core.llms import ChatMessage

    from agent_framework.core.context_summarizer import ContextSummarizer
    from agent_framework.monitoring.token_counter import TokenCounter

logger = logging.getLogger(__name__)


class ModelContextRegistry:
    """Registre des tailles de fenêtre de contexte par modèle.

    Résout la taille de la fenêtre de contexte (input tokens) pour un modèle donné
    via un lookup exact, puis un fallback par préfixe de provider, puis une valeur
    par défaut de 128 000 tokens.
    """

    CONTEXT_WINDOWS: dict[str, int] = {
        # Light tier
        "gpt-5.4-nano": 400_000,
        "gemini-2.5-flash-lite": 1_048_576,
        "gemini-3.1-flash-lite-preview": 1_048_576,
        # Standard tier
        "gpt-5.4-mini": 400_000,
        "claude-haiku-4-5-20251001": 200_000,
        "gemini-2.5-flash": 1_048_576,
        "gemini-3-flash-preview": 1_048_576,
        # Advanced tier
        "gpt-5.2": 272_000,
        "gpt-5.4": 1_050_000,
        "claude-opus-4-6": 200_000,
        "claude-sonnet-4-6": 1_000_000,
        "claude-opus-4-5-20251101": 200_000,
        "gemini-2.5-pro": 1_048_576,
        "gemini-3.1-pro-preview": 1_048_576,
    }

    PROVIDER_DEFAULTS: dict[str, int] = {
        "gpt-5": 272_000,
        "gpt-4": 128_000,
        "claude": 200_000,
        "gemini": 1_048_576,
        "o1": 128_000,
        "o3": 200_000,
        "o4": 200_000,
    }

    DEFAULT_CONTEXT_WINDOW: int = 128_000

    @classmethod
    def get_context_window(cls, model_name: str) -> int:
        """Résout la taille de la fenêtre de contexte pour un modèle.

        Stratégie de résolution :
        1. Lookup exact dans CONTEXT_WINDOWS
        2. Fallback par préfixe (le plus long d'abord) dans PROVIDER_DEFAULTS
        3. Valeur par défaut de 128 000 tokens

        Args:
            model_name: Nom du modèle LLM.

        Returns:
            Taille de la fenêtre de contexte en tokens.
        """
        if model_name in cls.CONTEXT_WINDOWS:
            return cls.CONTEXT_WINDOWS[model_name]

        # Préfixe le plus long d'abord pour éviter les faux positifs
        for prefix in sorted(cls.PROVIDER_DEFAULTS, key=len, reverse=True):
            if model_name.startswith(prefix):
                return cls.PROVIDER_DEFAULTS[prefix]

        logger.warning(
            "Modèle inconnu '%s', utilisation de la fenêtre par défaut de %d tokens",
            model_name,
            cls.DEFAULT_CONTEXT_WINDOW,
        )
        return cls.DEFAULT_CONTEXT_WINDOW


@dataclass(frozen=True)
class BudgetSnapshot:
    """Snapshot de l'état du budget de la fenêtre de contexte à un instant donné."""

    context_window: int
    sacred_zone_tokens: int
    conversation_zone_tokens: int
    recent_zone_tokens: int
    total_tokens: int
    usage_percent: float
    compression_triggered: bool
    model_name: str
    tool_definition_multiplier: float = 1.0
    raw_tool_tokens: int = 0
    estimated_tool_tokens: int = 0
    tool_fixed_overhead: int = 0


class ContextBudgetManager:
    """Gère le budget de la fenêtre de contexte pour un agent LLM.

    Découpe la fenêtre de contexte en zones (sacrée, conversation, récente),
    surveille l'utilisation, et fournit des snapshots de l'état du budget.
    """

    TRIGGER_THRESHOLD: float = 0.95
    TARGET_CONVERSATION_RATIO: float = 0.30
    RECENT_ZONE_RATIO: float = 0.05

    def __init__(
        self,
        model_name: str,
        token_counter: TokenCounter,
        summarizer: ContextSummarizer | None = None,
        trigger_threshold: float | None = None,
        target_conversation_ratio: float | None = None,
        recent_zone_ratio: float | None = None,
    ) -> None:
        import os

        self._model_name = model_name
        self._token_counter = token_counter
        self._summarizer = summarizer
        self._context_window = ModelContextRegistry.get_context_window(model_name)
        self._sacred_zone_tokens = 0
        self._prompt_tokens = 0
        self._tool_definition_tokens = 0
        self._raw_tool_tokens = 0
        self._tool_definition_multiplier = 1.0
        self._tool_fixed_overhead = 0

        # Resolution order: explicit parameter > env var > class constant
        def _resolve(param, env_key, default):
            if param is not None:
                return param
            env_val = os.getenv(env_key)
            if env_val is not None:
                try:
                    return float(env_val)
                except ValueError:
                    pass
            return default

        self._trigger_threshold = _resolve(
            trigger_threshold, "CONTEXT_BUDGET_TRIGGER_THRESHOLD", self.TRIGGER_THRESHOLD
        )
        self._target_conversation_ratio = _resolve(
            target_conversation_ratio,
            "CONTEXT_BUDGET_CONVERSATION_RATIO",
            self.TARGET_CONVERSATION_RATIO,
        )
        self._recent_zone_ratio = _resolve(
            recent_zone_ratio, "CONTEXT_BUDGET_RECENT_RATIO", self.RECENT_ZONE_RATIO
        )

        self._validate_ratios()

    def _validate_ratios(self) -> None:
        """Validate that all ratio values are within acceptable bounds.

        Raises:
            ValueError: If any ratio is outside ]0.0, 1.0[ or if the sum of
                        target_conversation_ratio and recent_zone_ratio >= 1.0.
        """
        for name, value in [
            ("trigger_threshold", self._trigger_threshold),
            ("target_conversation_ratio", self._target_conversation_ratio),
            ("recent_zone_ratio", self._recent_zone_ratio),
        ]:
            if not (0.0 < value < 1.0):
                raise ValueError(
                    f"Invalid ratio '{name}': {value!r} must be in ]0.0, 1.0[ (exclusive)"
                )

        ratio_sum = self._target_conversation_ratio + self._recent_zone_ratio
        if ratio_sum >= 1.0:
            raise ValueError(
                f"target_conversation_ratio ({self._target_conversation_ratio!r}) + "
                f"recent_zone_ratio ({self._recent_zone_ratio!r}) = {ratio_sum!r} "
                f"must be < 1.0"
            )

    @property
    def context_window(self) -> int:
        """Taille de la fenêtre de contexte résolue pour le modèle courant."""
        return self._context_window

    def _count_message_tokens(self, message: ChatMessage) -> int:
        """Compte les tokens d'un message en incluant TOUS les blocks.

        ChatMessage.content ne retourne que le texte des TextBlock.
        Les ToolCallBlock, ToolResultBlock, ImageBlock etc. contiennent
        aussi des tokens qui doivent être comptés pour un budget précis.

        Args:
            message: Le ChatMessage à compter.

        Returns:
            Nombre total de tokens du message.
        """
        total = 0
        if hasattr(message, 'blocks') and message.blocks:
            for block in message.blocks:
                block_type = type(block).__name__
                if hasattr(block, 'text'):
                    total += self._token_counter.count_tokens(block.text or "").count
                elif hasattr(block, 'tool_kwargs'):
                    # ToolCallBlock: compte le nom + les arguments
                    tool_name = getattr(block, 'tool_name', '') or ''
                    total += self._token_counter.count_tokens(tool_name).count
                    kwargs = getattr(block, 'tool_kwargs', None)
                    if kwargs:
                        import json
                        try:
                            kwargs_str = json.dumps(kwargs) if isinstance(kwargs, dict) else str(kwargs)
                        except (TypeError, ValueError):
                            kwargs_str = str(kwargs)
                        total += self._token_counter.count_tokens(kwargs_str).count
                elif hasattr(block, 'tool_output'):
                    # ToolResultBlock: compte le résultat
                    output = str(getattr(block, 'tool_output', '') or '')
                    total += self._token_counter.count_tokens(output).count
                elif block_type == 'ImageBlock':
                    # Approximation pour les images (Anthropic compte ~1600 tokens pour une image moyenne)
                    total += 1600
                else:
                    # Fallback: sérialise le block
                    try:
                        block_str = str(block)
                        if len(block_str) > 10:
                            total += self._token_counter.count_tokens(block_str).count
                    except Exception:
                        total += 100  # estimation conservatrice
        else:
            # Pas de blocks, utilise .content
            total = self._token_counter.count_tokens(message.content or "").count
        return total

    # Les providers sérialisent les tool definitions avec un wrapping qui ajoute
    # un overhead par rapport au JSON brut. Le modèle de calibration utilise :
    # estimated_tokens = raw_tokens * multiplier + fixed_overhead
    # Voir provider_calibration.py pour les valeurs par provider.
    TOOL_DEFINITION_MULTIPLIER = 1.4  # Anthropic default, overridden per-provider

    def set_sacred_zone(self, system_prompt: str, tool_definitions: str) -> int:
        """Compte et enregistre les tokens de la Zone Sacrée.

        Le system prompt est compté tel quel (tiktoken est fiable pour du texte).
        Les tool definitions reçoivent un multiplicateur calibré par provider
        (wrapping XML/JSON) plus un overhead fixe (system prompt tool-use injecté
        par le provider).

        Args:
            system_prompt: Prompt système complet (agent + skills + mémoire passive).
            tool_definitions: Définitions d'outils sérialisées.

        Returns:
            Nombre total estimé de tokens de la Zone Sacrée.
        """
        self._prompt_tokens = self._token_counter.count_tokens(system_prompt).count
        self._raw_tool_tokens = self._token_counter.count_tokens(tool_definitions).count
        self._tool_definition_multiplier = ProviderCalibrationRegistry.get_multiplier(
            self._model_name
        )
        self._tool_fixed_overhead = ProviderCalibrationRegistry.get_fixed_overhead(
            self._model_name
        )
        # estimated = raw * multiplier + fixed_overhead (only if tools are present)
        if self._raw_tool_tokens > 0:
            self._tool_definition_tokens = (
                int(self._raw_tool_tokens * self._tool_definition_multiplier)
                + self._tool_fixed_overhead
            )
        else:
            self._tool_definition_tokens = 0
        self._sacred_zone_tokens = self._prompt_tokens + self._tool_definition_tokens
        logger.info(
            "Sacred zone: %d tokens (prompt=%d, tools=%d raw * %.1fx + %d overhead = %d)",
            self._sacred_zone_tokens,
            self._prompt_tokens,
            self._raw_tool_tokens,
            self._tool_definition_multiplier,
            self._tool_fixed_overhead if self._raw_tool_tokens > 0 else 0,
            self._tool_definition_tokens,
        )
        if self._sacred_zone_tokens > 0.65 * self._context_window:
            logger.warning(
                "Sacred zone uses >65%% of context window: %d tokens",
                self._sacred_zone_tokens,
            )
        return self._sacred_zone_tokens

    def _identify_recent_zone(self, messages: list[ChatMessage]) -> int:
        """Retourne l'index du premier message de la Zone Récente.

        Parcourt les messages depuis la fin en accumulant les tokens
        jusqu'à dépasser le budget de la zone récente (5% de context_window).
        Si un seul dernier message dépasse le budget, il est conservé.

        Args:
            messages: Liste de messages de conversation.

        Returns:
            Index du premier message de la zone récente.
        """
        if not messages:
            return 0

        budget = int(self._context_window * self._recent_zone_ratio)
        total = 0
        idx = len(messages)

        for i in range(len(messages) - 1, -1, -1):
            msg_tokens = self._count_message_tokens(messages[i])
            if total + msg_tokens > budget and idx < len(messages):
                break
            total += msg_tokens
            idx = i

        return idx

    def compute_snapshot(self, messages: list[ChatMessage]) -> BudgetSnapshot:
        """Calcule le snapshot complet du budget.

        Args:
            messages: Liste de messages de conversation.

        Returns:
            Snapshot de l'état du budget.
        """
        conversation_tokens = sum(
            self._count_message_tokens(m) for m in messages
        )
        recent_idx = self._identify_recent_zone(messages)
        recent_tokens = sum(
            self._count_message_tokens(m) for m in messages[recent_idx:]
        )
        total = self._sacred_zone_tokens + conversation_tokens
        usage = (total / self._context_window * 100) if self._context_window > 0 else 0.0

        if usage > 80:
            logger.warning("Context usage at %.1f%%", usage)

        return BudgetSnapshot(
            context_window=self._context_window,
            sacred_zone_tokens=self._sacred_zone_tokens,
            conversation_zone_tokens=conversation_tokens,
            recent_zone_tokens=recent_tokens,
            total_tokens=total,
            usage_percent=usage,
            compression_triggered=False,
            model_name=self._model_name,
            tool_definition_multiplier=self._tool_definition_multiplier,
            raw_tool_tokens=self._raw_tool_tokens,
            estimated_tool_tokens=self._tool_definition_tokens,
            tool_fixed_overhead=self._tool_fixed_overhead,
        )

    async def enforce_budget(
        self, messages: list[ChatMessage],
    ) -> tuple[list[ChatMessage], BudgetSnapshot]:
        """Vérifie le budget et compresse si nécessaire.

        Gère deux cas :
        1. Cas normal : compresse old_messages, garde recent_messages intacts
        2. Cas extrême : si recent_messages seuls dépassent le budget,
           compresse TOUT (old + recent) en un seul résumé

        Args:
            messages: Liste de messages de conversation.

        Returns:
            Tuple (messages potentiellement compressés, snapshot du budget).
        """
        snapshot = self.compute_snapshot(messages)

        if snapshot.usage_percent < self._trigger_threshold * 100:
            return messages, snapshot

        recent_idx = self._identify_recent_zone(messages)
        recent_messages = messages[recent_idx:]
        old_messages = messages[:recent_idx]

        target_conversation_tokens = int(
            self._context_window * self._target_conversation_ratio
        )
        recent_tokens = sum(
            self._count_message_tokens(m) for m in recent_messages
        )
        available_for_conversation = self._context_window - self._sacred_zone_tokens

        logger.info(
            "Budget compression: %d total messages, %d old, %d recent (idx=%d), "
            "usage=%.1f%%, recent_tokens=%d, available=%d, target=%d",
            len(messages), len(old_messages), len(recent_messages), recent_idx,
            snapshot.usage_percent, recent_tokens, available_for_conversation,
            target_conversation_tokens,
        )

        # Cas extrême : recent_messages seuls dépassent le budget disponible
        # On doit tout compresser (old + recent) en un seul résumé
        if recent_tokens > available_for_conversation:
            logger.warning(
                "Recent messages alone (%d tokens) exceed available budget (%d tokens). "
                "Compressing ALL messages including recent zone.",
                recent_tokens, available_for_conversation,
            )
            return await self._compress_all_messages(
                messages, target_conversation_tokens, snapshot,
            )

        target_old_tokens = max(0, target_conversation_tokens - recent_tokens)

        compressed_messages: list[ChatMessage] = []
        try:
            if self._summarizer is not None and old_messages:
                summary_msg = await self._summarizer.summarize(
                    old_messages, target_old_tokens, self._model_name
                )
                compressed_messages = [summary_msg] + recent_messages
            elif not old_messages:
                # Pas de old_messages : le dépassement vient de la sacred zone.
                # On retourne les messages tels quels — on ne peut pas compresser
                # davantage sans perdre les messages récents.
                logger.info(
                    "No old messages to compress, usage at %.1f%%.",
                    snapshot.usage_percent,
                )
                final_snapshot = self._compute_snapshot_compressed(recent_messages)
                return list(recent_messages), final_snapshot
            else:
                raise RuntimeError("No summarizer available")
        except Exception:
            logger.warning("Summarizer failed, falling back to truncation", exc_info=True)
            from agent_framework.core.context_summarizer import ContextSummarizer

            truncated = ContextSummarizer.truncate(
                old_messages, target_old_tokens, self._token_counter
            )
            compressed_messages = truncated + recent_messages

        from llama_index.core.llms import MessageRole
        last_user = next(
            (m for m in reversed(messages) if m.role == MessageRole.USER), None
        )
        if last_user is not None and not any(
            m.role == MessageRole.USER and (m.content or "") == (last_user.content or "")
            for m in compressed_messages
        ):
            compressed_messages = list(compressed_messages) + [last_user]

        # Guard: ne jamais retourner une liste vide, sinon le LLM reçoit 0 messages
        if not compressed_messages:
            logger.error(
                "Budget compression produced empty message list! "
                "Returning original messages to avoid empty LLM call. "
                "old=%d, recent=%d, target_old_tokens=%d",
                len(old_messages), len(recent_messages), target_old_tokens,
            )
            return messages, snapshot

        # Vérification post-compression : si on dépasse encore et que la conversation
        # est réellement compressible (pas juste un dépassement dû à la sacred zone).
        post_snapshot = self._compute_snapshot_compressed(compressed_messages)
        if post_snapshot.usage_percent >= self._trigger_threshold * 100:
            threshold_tokens = int(self._context_window * self._trigger_threshold)
            excess_tokens = post_snapshot.total_tokens - threshold_tokens
            conv_tokens = post_snapshot.conversation_zone_tokens

            # Si la conversation est plus petite que l'excès, la compresser
            # davantage ne suffira pas (le dépassement vient de la sacred zone)
            if conv_tokens <= excess_tokens:
                logger.warning(
                    "Cannot compress below threshold: conversation=%d tokens, "
                    "excess=%d tokens (sacred zone too large).",
                    conv_tokens, excess_tokens,
                )
                return compressed_messages, post_snapshot

            if len(compressed_messages) > 2:
                logger.warning(
                    "Post-compression still at %.1f%% with %d messages, "
                    "compressing ALL messages.",
                    post_snapshot.usage_percent, len(compressed_messages),
                )
                return await self._compress_all_messages(
                    compressed_messages, target_conversation_tokens, snapshot,
                )

        return compressed_messages, post_snapshot

    async def _compress_all_messages(
        self,
        messages: list[ChatMessage],
        target_tokens: int,
        original_snapshot: BudgetSnapshot,
    ) -> tuple[list[ChatMessage], BudgetSnapshot]:
        """Compresse TOUS les messages (y compris la zone récente) en un résumé.

        Utilisé quand les recent_messages seuls dépassent le budget,
        ou quand la compression normale ne suffit pas.

        Args:
            messages: Tous les messages à compresser.
            target_tokens: Budget cible en tokens pour le résumé.
            original_snapshot: Snapshot avant compression (pour fallback).

        Returns:
            Tuple (messages compressés, snapshot).
        """
        compressed_messages: list[ChatMessage] = []
        try:
            if self._summarizer is not None and messages:
                summary_msg = await self._summarizer.summarize(
                    messages, target_tokens, self._model_name
                )
                compressed_messages = [summary_msg]
            else:
                raise RuntimeError("No summarizer available")
        except Exception:
            logger.warning(
                "Full summarization failed, falling back to truncation",
                exc_info=True,
            )
            from agent_framework.core.context_summarizer import ContextSummarizer

            compressed_messages = ContextSummarizer.truncate(
                messages, target_tokens, self._token_counter
            )

        from llama_index.core.llms import MessageRole
        last_user = next(
            (m for m in reversed(messages) if m.role == MessageRole.USER), None
        )
        if last_user is not None and not any(
            m.role == MessageRole.USER and (m.content or "") == (last_user.content or "")
            for m in compressed_messages
        ):
            compressed_messages = list(compressed_messages) + [last_user]

        if not compressed_messages:
            logger.error(
                "Full compression produced empty message list! "
                "Returning original messages.",
            )
            return messages, original_snapshot

        final_snapshot = self._compute_snapshot_compressed(compressed_messages)
        return compressed_messages, final_snapshot

    def update_model(self, new_model_name: str) -> None:
        """Met à jour le modèle et recalcule la fenêtre de contexte.

        Args:
            new_model_name: Nom du nouveau modèle LLM.
        """
        self._model_name = new_model_name
        self._context_window = ModelContextRegistry.get_context_window(new_model_name)

    def _compute_snapshot_compressed(
        self, messages: list[ChatMessage],
    ) -> BudgetSnapshot:
        """Calcule un snapshot avec le flag compression_triggered activé.

        Args:
            messages: Liste de messages après compression.

        Returns:
            Snapshot avec compression_triggered=True.
        """
        conversation_tokens = sum(
            self._count_message_tokens(m) for m in messages
        )
        recent_idx = self._identify_recent_zone(messages)
        recent_tokens = sum(
            self._count_message_tokens(m) for m in messages[recent_idx:]
        )
        total = self._sacred_zone_tokens + conversation_tokens
        usage = (total / self._context_window * 100) if self._context_window > 0 else 0.0

        if usage > 80:
            logger.warning("Context usage at %.1f%%", usage)

        return BudgetSnapshot(
            context_window=self._context_window,
            sacred_zone_tokens=self._sacred_zone_tokens,
            conversation_zone_tokens=conversation_tokens,
            recent_zone_tokens=recent_tokens,
            total_tokens=total,
            usage_percent=usage,
            compression_triggered=True,
            model_name=self._model_name,
            tool_definition_multiplier=self._tool_definition_multiplier,
            raw_tool_tokens=self._raw_tool_tokens,
            estimated_tool_tokens=self._tool_definition_tokens,
            tool_fixed_overhead=self._tool_fixed_overhead,
        )

    async def truncate_query_if_needed(
        self,
        query: str,
        memory_messages: list[ChatMessage],
    ) -> str:
        """Tronque ou résume le query si il dépasse le budget disponible.

        Calcule le budget restant après sacred_zone + mémoire existante,
        et si le query dépasse ce budget, le résume via le summarizer
        ou le tronque en fallback.

        Args:
            query: Le message user complet (peut contenir un PDF converti).
            memory_messages: Messages déjà en mémoire.

        Returns:
            Le query original si il rentre, ou une version résumée/tronquée.
        """
        query_tokens = self._token_counter.count_tokens(query).count
        memory_tokens = sum(
            self._count_message_tokens(m) for m in memory_messages
        )

        # Budget disponible pour le query = context_window - sacred - memory - marge de sécurité
        # On garde 10% de marge pour la réponse du LLM
        safety_margin = int(self._context_window * 0.10)
        available_for_query = (
            self._context_window - self._sacred_zone_tokens - memory_tokens - safety_margin
        )

        if available_for_query <= 0:
            available_for_query = int(self._context_window * 0.20)

        if query_tokens <= available_for_query:
            return query

        logger.warning(
            "Query too large: %d tokens, available budget: %d tokens "
            "(context_window=%d, sacred=%d, memory=%d, safety=%d). "
            "Truncating query.",
            query_tokens, available_for_query, self._context_window,
            self._sacred_zone_tokens, memory_tokens, safety_margin,
        )

        # Tenter un résumé LLM du contenu
        if self._summarizer is not None:
            try:
                from llama_index.core.llms import ChatMessage, MessageRole

                query_msg = ChatMessage(role=MessageRole.USER, content=query)
                summary_msg = await self._summarizer.summarize(
                    [query_msg], available_for_query, self._model_name,
                )
                summarized_query = summary_msg.content or ""
                # Retirer le préfixe "[Résumé de la conversation précédente]" si présent
                prefix = "[Résumé de la conversation précédente]\n"
                if summarized_query.startswith(prefix):
                    summarized_query = summarized_query[len(prefix):]

                summarized_tokens = self._token_counter.count_tokens(summarized_query).count
                logger.info(
                    "Query summarized: %d -> %d tokens (budget: %d)",
                    query_tokens, summarized_tokens, available_for_query,
                )
                return summarized_query
            except Exception:
                logger.warning(
                    "Query summarization failed, falling back to truncation",
                    exc_info=True,
                )

        # Fallback: troncature brute par ratio de caractères
        ratio = available_for_query / query_tokens
        max_chars = int(len(query) * ratio * 0.95)  # 5% de marge
        truncated = query[:max_chars]
        truncated += "\n\n[... contenu tronqué pour respecter la limite de contexte]"
        logger.info(
            "Query truncated: %d -> %d chars (ratio=%.2f)",
            len(query), len(truncated), ratio,
        )
        return truncated

