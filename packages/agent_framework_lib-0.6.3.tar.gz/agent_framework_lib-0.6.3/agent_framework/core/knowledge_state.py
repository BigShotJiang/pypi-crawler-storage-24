"""Knowledge state tracking for scratchpad compression.

Captures and structures knowledge acquired from tool calls,
preserving it across successive compressions.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from agent_framework.monitoring.token_counter import TokenCounter

logger = logging.getLogger(__name__)


@dataclass
class ToolCallSignature:
    """Unique identifier for a tool call based on name and argument hash."""

    tool_name: str
    args_hash: str

    @classmethod
    def from_tool_call(
        cls, tool_name: str, tool_kwargs: dict[str, Any]
    ) -> ToolCallSignature:
        """Compute a deterministic signature from tool name and arguments.

        Uses canonical JSON serialization (sorted keys, compact separators)
        for the hash. Falls back to str() if JSON serialization fails.

        Args:
            tool_name: Name of the tool.
            tool_kwargs: Dictionary of tool arguments.

        Returns:
            A ToolCallSignature with a SHA-256 hash of the arguments.
        """
        try:
            canonical = json.dumps(tool_kwargs, sort_keys=True, separators=(",", ":"))
        except (TypeError, ValueError):
            logger.warning(
                "JSON serialization failed for tool '%s' args, falling back to str()",
                tool_name,
            )
            canonical = str(tool_kwargs)

        args_hash = hashlib.sha256(canonical.encode()).hexdigest()
        return cls(tool_name=tool_name, args_hash=args_hash)

    def __hash__(self) -> int:
        return hash((self.tool_name, self.args_hash))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ToolCallSignature):
            return NotImplemented
        return self.tool_name == other.tool_name and self.args_hash == other.args_hash


@dataclass
class ToolResultEntry:
    """Structured result of a tool call."""

    signature: ToolCallSignature
    tool_name: str
    arguments: dict[str, Any]
    status: Literal["success", "error", "truncated"]
    key_data: dict[str, Any]
    numeric_values: dict[str, Any]
    raw_excerpt: str
    timestamp: float


class KnowledgeState:
    """Accumulated knowledge state, persisted across compressions."""

    def __init__(self) -> None:
        self._entries: dict[ToolCallSignature, ToolResultEntry] = {}

    def add_entry(self, entry: ToolResultEntry) -> None:
        """Add or update an entry in the registry.

        Args:
            entry: The tool result entry to store.
        """
        self._entries[entry.signature] = entry

    def get_entry(self, signature: ToolCallSignature) -> ToolResultEntry | None:
        """Retrieve an entry by its signature.

        Args:
            signature: The tool call signature to look up.

        Returns:
            The matching entry, or None if not found.
        """
        return self._entries.get(signature)

    def has_signature(self, signature: ToolCallSignature) -> bool:
        """Check whether a signature is already registered.

        Args:
            signature: The tool call signature to check.

        Returns:
            True if the signature exists in the registry.
        """
        return signature in self._entries

    def get_all_entries(self) -> list[ToolResultEntry]:
        """Return all entries in insertion order.

        Returns:
            List of all stored tool result entries.
        """
        return list(self._entries.values())

    def get_entries_by_tool(self, tool_name: str) -> list[ToolResultEntry]:
        """Return entries filtered by tool name.

        Args:
            tool_name: Name of the tool to filter by.

        Returns:
            List of entries matching the given tool name.
        """
        return [e for e in self._entries.values() if e.tool_name == tool_name]

    def to_structured_text(self) -> str:
        """Serialize the full knowledge state as structured text.

        Produces a human-readable representation with sections per tool call
        and tabular format for numeric data.

        Returns:
            Structured text representation of all entries.
        """
        if not self._entries:
            return ""

        sections: list[str] = []
        for entry in self._entries.values():
            lines: list[str] = []
            lines.append(f"[{entry.tool_name}] status={entry.status}")

            if entry.arguments:
                args_str = ", ".join(
                    f"{k}={v!r}" for k, v in entry.arguments.items()
                )
                lines.append(f"  args: {args_str}")

            if entry.numeric_values:
                lines.append("  numeric_data:")
                for k, v in entry.numeric_values.items():
                    lines.append(f"    {k}: {v}")

            if entry.key_data:
                lines.append("  key_data:")
                for k, v in entry.key_data.items():
                    lines.append(f"    {k}: {v}")

            if entry.raw_excerpt:
                lines.append(f"  excerpt: {entry.raw_excerpt}")

            sections.append("\n".join(lines))

        return "\n\n".join(sections)

    def to_compact_text(self, max_tokens: int, token_counter: TokenCounter) -> str:
        """Serialize a compact version that fits within a token budget.

        Prioritizes numeric data in tabular form (key: value).
        Progressively adds content until the budget is reached.

        Args:
            max_tokens: Maximum number of tokens allowed in the output.
            token_counter: Token counter instance for measuring output size.

        Returns:
            Compact text representation respecting the token budget.
        """
        if not self._entries or max_tokens <= 0:
            return ""

        # Phase 1: collect numeric lines (highest priority)
        numeric_lines: list[str] = []
        for entry in self._entries.values():
            if entry.numeric_values:
                for k, v in entry.numeric_values.items():
                    numeric_lines.append(f"{k}: {v}")

        # Phase 2: collect tool status headers
        header_lines: list[str] = []
        for entry in self._entries.values():
            header_lines.append(f"[{entry.tool_name}] status={entry.status}")

        # Phase 3: collect key_data lines
        key_data_lines: list[str] = []
        for entry in self._entries.values():
            if entry.key_data:
                for k, v in entry.key_data.items():
                    key_data_lines.append(f"{k}: {v}")

        # Phase 4: collect excerpt lines
        excerpt_lines: list[str] = []
        for entry in self._entries.values():
            if entry.raw_excerpt:
                excerpt_lines.append(f"excerpt: {entry.raw_excerpt}")

        # Build output incrementally, respecting the budget
        result_lines: list[str] = []

        for line_group in [numeric_lines, header_lines, key_data_lines, excerpt_lines]:
            for line in line_group:
                candidate = "\n".join(result_lines + [line]) if result_lines else line
                count = token_counter.count_tokens(candidate).count
                if count <= max_tokens:
                    result_lines.append(line)
                else:
                    # Budget exhausted — return what we have
                    return "\n".join(result_lines)

        return "\n".join(result_lines)
