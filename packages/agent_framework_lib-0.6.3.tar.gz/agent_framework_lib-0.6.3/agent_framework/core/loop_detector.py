"""Loop detection for repeated tool calls in the scratchpad.

Identifies when the agent is re-executing identical tool calls by
tracking deterministic signatures and flagging duplicates above a
configurable threshold.
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field

from llama_index.core.llms import ChatMessage, MessageRole

from agent_framework.core.knowledge_state import ToolCallSignature

logger = logging.getLogger(__name__)


@dataclass
class LoopDetectionResult:
    """Result of a loop detection analysis on the scratchpad."""

    is_loop: bool
    duplicate_signatures: list[tuple[ToolCallSignature, int]] = field(
        default_factory=list
    )
    total_duplicates: int = 0


class LoopDetector:
    """Detects tool call loops in the scratchpad.

    Traverses ASSISTANT messages containing tool calls, computes a
    ToolCallSignature for each call, and flags signatures that appear
    at or above the duplicate threshold.
    """

    DUPLICATE_THRESHOLD: int = 2

    def detect(self, scratchpad: list[ChatMessage]) -> LoopDetectionResult:
        """Analyse the scratchpad and detect duplicated tool call signatures.

        Args:
            scratchpad: List of ChatMessage from the tool loop.

        Returns:
            A LoopDetectionResult indicating whether a loop was found.
        """
        signatures = self._extract_signatures(scratchpad)

        if not signatures:
            return LoopDetectionResult(is_loop=False)

        counts: Counter[ToolCallSignature] = Counter(signatures)

        duplicate_signatures = [
            (sig, count)
            for sig, count in counts.items()
            if count >= self.DUPLICATE_THRESHOLD
        ]

        total_duplicates = sum(count for _, count in duplicate_signatures)

        if duplicate_signatures:
            for sig, count in duplicate_signatures:
                logger.warning(
                    "Duplicate tool call detected: tool='%s' args_hash='%s' repeated %d times",
                    sig.tool_name,
                    sig.args_hash,
                    count,
                )

        return LoopDetectionResult(
            is_loop=len(duplicate_signatures) > 0,
            duplicate_signatures=duplicate_signatures,
            total_duplicates=total_duplicates,
        )

    def _extract_signatures(
        self, scratchpad: list[ChatMessage]
    ) -> list[ToolCallSignature]:
        """Extract all ToolCallSignatures from ASSISTANT messages.

        Handles both dict-based tool calls in additional_kwargs and
        ToolCallBlock objects in message blocks.

        Args:
            scratchpad: List of ChatMessage to scan.

        Returns:
            List of ToolCallSignature found in the scratchpad.
        """
        signatures: list[ToolCallSignature] = []

        for msg in scratchpad:
            if msg.role != MessageRole.ASSISTANT:
                continue

            # Dict-based tool calls from additional_kwargs
            kwargs = msg.additional_kwargs or {}
            for tc in kwargs.get("tool_calls", []):
                if isinstance(tc, dict):
                    name = tc.get("name") or (tc.get("function") or {}).get(
                        "name", ""
                    )
                    arguments = tc.get("arguments") or (
                        tc.get("function") or {}
                    ).get("arguments", {})

                    if not name:
                        continue

                    # arguments may be a JSON string or a dict
                    if isinstance(arguments, str):
                        try:
                            import json

                            arguments = json.loads(arguments)
                        except (ValueError, TypeError):
                            arguments = {"_raw": arguments}

                    if not isinstance(arguments, dict):
                        arguments = {"_raw": str(arguments)}

                    signatures.append(
                        ToolCallSignature.from_tool_call(name, arguments)
                    )

            # Block-based tool calls
            if hasattr(msg, "blocks"):
                for block in msg.blocks or []:
                    if type(block).__name__ == "ToolCallBlock":
                        name = getattr(block, "tool_name", "")
                        tool_kwargs = getattr(block, "tool_kwargs", {})

                        if not name:
                            continue

                        if not isinstance(tool_kwargs, dict):
                            tool_kwargs = {}

                        signatures.append(
                            ToolCallSignature.from_tool_call(name, tool_kwargs)
                        )

        return signatures
