"""Scratchpad compression for tool loop budget enforcement.

Compresses old tool call/result entries in the scratchpad when the
context budget is exceeded, preserving the most recent tool pair
and summarizing or truncating older entries.
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import TYPE_CHECKING, Any

from llama_index.core.llms import ChatMessage, MessageRole

from agent_framework.core.knowledge_state import (
    KnowledgeState,
    ToolCallSignature,
    ToolResultEntry,
)

if TYPE_CHECKING:
    from agent_framework.core.context_summarizer import ContextSummarizer
    from agent_framework.monitoring.token_counter import TokenCounter

logger = logging.getLogger(__name__)

TRUNCATION_MARKER = "\n\n[... contenu tronqué ...]\n\n"


class ScratchpadCompressor:
    """Compresse le scratchpad de la boucle d'outils pour respecter le budget."""

    def __init__(
        self,
        token_counter: TokenCounter,
        summarizer: ContextSummarizer | None = None,
        default_model: str = "gpt-4o-mini",
    ) -> None:
        self._token_counter = token_counter
        self._summarizer = summarizer
        self._default_model = default_model
        self._knowledge_state: KnowledgeState = KnowledgeState()

    @property
    def knowledge_state(self) -> KnowledgeState:
        """Access the current KnowledgeState."""
        return self._knowledge_state

    def reset_knowledge_state(self) -> None:
        """Reset the KnowledgeState for a new query."""
        self._knowledge_state = KnowledgeState()

    def _count_tokens(self, messages: list[ChatMessage]) -> int:
        """Compte le total de tokens d'une liste de messages.

        Inclut tous les types de blocks (ToolCallBlock, ToolResultBlock, etc.)
        et pas seulement le texte de .content.

        Args:
            messages: Liste de ChatMessage.

        Returns:
            Nombre total de tokens.
        """
        from agent_framework.core.context_summarizer import ContextSummarizer

        total = 0
        for msg in messages:
            total += ContextSummarizer._count_msg_tokens(msg, self._token_counter)
        return total

    def _identify_last_tool_pair(
        self, scratchpad: list[ChatMessage]
    ) -> tuple[list[ChatMessage], list[ChatMessage]]:
        """Sépare le scratchpad en (anciennes entrées, dernière paire tool_call/tool_result).

        Parcourt le scratchpad depuis la fin pour trouver la dernière paire
        composée d'un message ASSISTANT (tool_call) suivi d'un message TOOL (tool_result).

        Args:
            scratchpad: Liste de messages du scratchpad.

        Returns:
            Tuple (anciennes entrées, dernière paire). Si le scratchpad est vide
            ou ne contient pas de paire complète, retourne ([], scratchpad).
        """
        if len(scratchpad) < 2:
            return [], list(scratchpad)

        # Chercher la dernière paire tool_call/tool_result depuis la fin
        # Les paires sont : ASSISTANT (avec tool_calls) + TOOL (résultat)
        for i in range(len(scratchpad) - 1, 0, -1):
            current = scratchpad[i]
            previous = scratchpad[i - 1]
            if (
                current.role == MessageRole.TOOL
                and previous.role == MessageRole.ASSISTANT
            ):
                old_entries = scratchpad[: i - 1]
                last_pair = scratchpad[i - 1 :]
                return old_entries, last_pair

        # Pas de paire trouvée, tout est considéré comme dernière paire
        return [], list(scratchpad)

    def _truncate_single_result(
        self, message: ChatMessage, target_tokens: int
    ) -> ChatMessage:
        """Tronque le contenu d'un tool_result en gardant début + marqueur + fin.

        Args:
            message: Message tool_result à tronquer.
            target_tokens: Nombre cible de tokens pour le message tronqué.

        Returns:
            Nouveau ChatMessage avec le contenu tronqué.
        """
        content = message.content or ""
        current_tokens = self._token_counter.count_tokens(content).count

        if current_tokens <= target_tokens or target_tokens <= 0:
            return message

        # Réserver des tokens pour le marqueur de troncature
        marker_tokens = self._token_counter.count_tokens(TRUNCATION_MARKER).count
        available_tokens = max(0, target_tokens - marker_tokens)

        # Répartir entre début et fin (60% début, 40% fin)
        begin_tokens = int(available_tokens * 0.6)
        end_tokens = available_tokens - begin_tokens

        # Approximation : ratio tokens/caractères pour découper le texte
        if current_tokens > 0:
            chars_per_token = len(content) / current_tokens
        else:
            chars_per_token = 4.0

        begin_chars = max(0, int(begin_tokens * chars_per_token))
        end_chars = max(0, int(end_tokens * chars_per_token))

        if begin_chars + end_chars >= len(content):
            return message

        begin_part = content[:begin_chars]
        end_part = content[-end_chars:] if end_chars > 0 else ""
        truncated_content = begin_part + TRUNCATION_MARKER + end_part

        return ChatMessage(
            role=message.role,
            content=truncated_content,
            additional_kwargs=message.additional_kwargs,
        )

    async def compress(
        self,
        scratchpad: list[ChatMessage],
        llm_input: list[ChatMessage],
        context_window: int,
        sacred_zone_tokens: int,
        model_name: str | None = None,
    ) -> list[ChatMessage]:
        """Compresse le scratchpad pour respecter le budget.

        Stratégie :
        1. Préserver la dernière paire tool_call/tool_result
        2. Résumer les entrées anciennes via LLM (ou tronquer en fallback)
        3. Si une seule paire existe, tronquer le contenu du tool_result

        Args:
            scratchpad: Entrées actuelles du scratchpad.
            llm_input: Messages d'historique (pour calculer le budget restant).
            context_window: Taille de la fenêtre de contexte.
            sacred_zone_tokens: Tokens de la zone sacrée.
            model_name: Modèle LLM à utiliser pour le résumé. Si None, utilise
                        le modèle par défaut configuré à l'initialisation.

        Returns:
            Scratchpad compressé.
        """
        effective_model = model_name or self._default_model
        if not effective_model:
            logger.warning(
                "model_name et default_model sont vides, utilisation de 'gpt-4o-mini' en dernier recours"
            )
            effective_model = "gpt-4o-mini"
        if not scratchpad:
            return scratchpad

        # Extract knowledge and pre-aggregate before compression
        self._extract_knowledge(scratchpad)
        self._pre_aggregate(scratchpad)

        # 80% du context window pour laisser une marge de sécurité
        # (écart de tokenisation entre tiktoken et le tokenizer du provider)
        budget_limit = int(context_window * 0.80)
        llm_input_tokens = self._count_tokens(llm_input)

        # Tokens disponibles pour le scratchpad
        available_for_scratchpad = max(0, budget_limit - sacred_zone_tokens - llm_input_tokens)

        old_entries, last_pair = self._identify_last_tool_pair(scratchpad)

        entries_before = len(scratchpad)
        tokens_before = self._count_tokens(scratchpad)

        # Cas 1 : pas d'anciennes entrées (une seule paire ou moins)
        if not old_entries:
            last_pair_tokens = self._count_tokens(last_pair)
            if last_pair_tokens > available_for_scratchpad:
                # Tronquer le tool_result de la dernière paire
                compressed_pair = self._truncate_last_pair(
                    last_pair, available_for_scratchpad
                )
                tokens_after = self._count_tokens(compressed_pair)
                self._log_compression(
                    entries_before, len(compressed_pair),
                    tokens_before, tokens_after,
                    "single_result_truncation",
                )
                tool_names = self._extract_tool_names(scratchpad)
                marker = self._build_summary_marker("single_result_truncation", entries_before, tool_names)
                return [marker] + compressed_pair
            return last_pair

        # Cas 2 : il y a des anciennes entrées à compresser
        last_pair_tokens = self._count_tokens(last_pair)
        target_old_tokens = max(0, available_for_scratchpad - last_pair_tokens)

        # Tenter le résumé LLM
        compressed_old = await self._try_summarize_old_entries(
            old_entries, target_old_tokens, effective_model
        )

        if compressed_old is not None:
            # LLM summary succeeded — include it in "Connaissances acquises"
            llm_summary_text = compressed_old[0].content if compressed_old else None
            result = compressed_old + last_pair
            tokens_after = self._count_tokens(result)
            self._log_compression(
                entries_before, len(result),
                tokens_before, tokens_after,
                "llm_summary",
            )
            tool_names = self._extract_tool_names(scratchpad)
            marker = self._build_summary_marker(
                "llm_summary", entries_before, tool_names,
                llm_summary_text=llm_summary_text,
            )
            return [marker] + last_pair

        # Fallback : troncature simple (supprimer les plus anciennes)
        # KnowledgeState from _extract_knowledge provides fallback data
        truncated_old = self._truncate_old_entries(old_entries, target_old_tokens)
        result = truncated_old + last_pair
        tokens_after = self._count_tokens(result)
        self._log_compression(
            entries_before, len(result),
            tokens_before, tokens_after,
            "truncation",
        )
        tool_names = self._extract_tool_names(old_entries)
        marker = self._build_summary_marker("truncation", entries_before, tool_names)
        return [marker] + last_pair

    async def _try_summarize_old_entries(
        self,
        old_entries: list[ChatMessage],
        target_tokens: int,
        model_name: str,
    ) -> list[ChatMessage] | None:
        """Tente de résumer les anciennes entrées via LLM.

        Args:
            old_entries: Messages anciens à résumer.
            target_tokens: Budget cible en tokens pour le résumé.
            model_name: Modèle LLM à utiliser pour le résumé.

        Returns:
            Liste contenant un unique message de résumé, ou None si échec.
        """
        if self._summarizer is None:
            return None

        try:
            summary_msg = await self._summarizer.summarize(
                old_entries, target_tokens, model_name
            )
            return [
                ChatMessage(
                    role=MessageRole.SYSTEM,
                    content=summary_msg.content or "",
                )
            ]
        except Exception:
            logger.warning("Résumé LLM du scratchpad échoué, fallback troncature")
            return None

    def _truncate_old_entries(
        self,
        old_entries: list[ChatMessage],
        target_tokens: int,
    ) -> list[ChatMessage]:
        """Supprime les entrées les plus anciennes jusqu'à respecter le budget.

        Args:
            old_entries: Messages anciens.
            target_tokens: Budget cible en tokens.

        Returns:
            Liste de messages dont le total est <= target_tokens.
        """
        total = self._count_tokens(old_entries)
        result = list(old_entries)
        while result and total > target_tokens:
            removed = result.pop(0)
            total -= self._token_counter.count_tokens(removed.content or "").count
        return result

    def _truncate_last_pair(
        self,
        last_pair: list[ChatMessage],
        available_tokens: int,
    ) -> list[ChatMessage]:
        """Tronque le tool_result dans la dernière paire pour respecter le budget.

        Args:
            last_pair: Dernière paire de messages (tool_call + tool_result).
            available_tokens: Tokens disponibles pour toute la paire.

        Returns:
            Paire avec le tool_result tronqué si nécessaire.
        """
        result = []
        tokens_used = 0

        for msg in last_pair:
            if msg.role == MessageRole.TOOL:
                remaining = max(0, available_tokens - tokens_used)
                result.append(self._truncate_single_result(msg, remaining))
            else:
                tokens_used += self._token_counter.count_tokens(msg.content or "").count
                result.append(msg)

        return result

    def _extract_tool_names(self, messages: list[ChatMessage]) -> list[str]:
        """Extrait les noms d'outils depuis les messages du scratchpad."""
        tool_names = []
        for msg in messages:
            kwargs = msg.additional_kwargs or {}
            for tc in kwargs.get("tool_calls", []):
                if isinstance(tc, dict):
                    name = tc.get("name") or (tc.get("function") or {}).get("name", "")
                    if name:
                        tool_names.append(name)
            if hasattr(msg, "blocks"):
                for block in (msg.blocks or []):
                    if type(block).__name__ == "ToolCallBlock":
                        name = getattr(block, "tool_name", "")
                        if name:
                            tool_names.append(name)
            if msg.role == MessageRole.TOOL:
                name = kwargs.get("name", "")
                if name:
                    tool_names.append(name)
        return tool_names

    def _extract_knowledge(self, messages: list[ChatMessage]) -> None:
        """Extract knowledge from tool results and update the KnowledgeState.

        Iterates over messages, finds TOOL messages, looks at the preceding
        ASSISTANT message for tool call info, and creates ToolResultEntry
        instances preserving all numeric values.

        Args:
            messages: List of scratchpad messages.
        """
        for i, msg in enumerate(messages):
            if msg.role != MessageRole.TOOL:
                continue

            # Find the preceding ASSISTANT message for tool call info
            tool_name = ""
            arguments: dict[str, Any] = {}

            # Check the TOOL message's own additional_kwargs for name
            tool_kwargs = msg.additional_kwargs or {}
            tool_name = tool_kwargs.get("name", "")

            # Look at the preceding ASSISTANT message
            if i > 0:
                prev = messages[i - 1]
                if prev.role == MessageRole.ASSISTANT:
                    prev_kwargs = prev.additional_kwargs or {}

                    # Extract from additional_kwargs tool_calls
                    for tc in prev_kwargs.get("tool_calls", []):
                        if isinstance(tc, dict):
                            name = tc.get("name") or (tc.get("function") or {}).get("name", "")
                            if name:
                                if not tool_name:
                                    tool_name = name
                                # Extract arguments
                                args_raw = tc.get("arguments") or (tc.get("function") or {}).get("arguments", "{}")
                                if isinstance(args_raw, str):
                                    try:
                                        arguments = json.loads(args_raw)
                                    except (json.JSONDecodeError, TypeError):
                                        arguments = {}
                                elif isinstance(args_raw, dict):
                                    arguments = args_raw
                                break

                    # Extract from blocks if no tool_calls found
                    if not tool_name and hasattr(prev, "blocks"):
                        for block in (prev.blocks or []):
                            if type(block).__name__ == "ToolCallBlock":
                                tool_name = getattr(block, "tool_name", "")
                                block_kwargs = getattr(block, "tool_kwargs", {})
                                if isinstance(block_kwargs, dict):
                                    arguments = block_kwargs
                                break

            if not tool_name:
                tool_name = "unknown_tool"

            content = msg.content or ""

            # Determine status from content
            content_lower = content.lower()
            if "error" in content_lower or "exception" in content_lower or "traceback" in content_lower:
                status: str = "error"
            elif len(content) > 1000:
                status = "truncated"
            else:
                status = "success"

            # Extract numeric values
            numeric_values = self._extract_numeric_values(content)

            # Build raw excerpt: first 500 + last 500 chars
            if len(content) > 1000:
                raw_excerpt = content[:500] + " ... " + content[-500:]
            else:
                raw_excerpt = content

            signature = ToolCallSignature.from_tool_call(tool_name, arguments)

            entry = ToolResultEntry(
                signature=signature,
                tool_name=tool_name,
                arguments=arguments,
                status=status,
                key_data={},
                numeric_values=numeric_values,
                raw_excerpt=raw_excerpt,
                timestamp=time.time(),
            )
            self._knowledge_state.add_entry(entry)

    def _extract_numeric_values(self, text: str) -> dict[str, Any]:
        """Extract numeric values from text using regex patterns.

        Finds amounts, percentages, scores, counters, and other numeric data.

        Args:
            text: Raw text content to extract numbers from.

        Returns:
            Dict mapping descriptive keys to numeric values.
        """
        if not text:
            return {}

        result: dict[str, Any] = {}
        idx = 0

        # Percentages: "45.2%" or "45%"
        for m in re.finditer(r"(\d+(?:,\d{3})*(?:\.\d+)?)\s*%", text):
            raw = m.group(1).replace(",", "")
            try:
                val = float(raw)
                result[f"percentage_{idx}"] = val
                idx += 1
            except ValueError:
                pass

        # Currency amounts: "$1,234.56" or "€100"
        for m in re.finditer(r"[$€£¥]\s*(\d+(?:,\d{3})*(?:\.\d+)?)", text):
            raw = m.group(1).replace(",", "")
            try:
                val = float(raw)
                result[f"amount_{idx}"] = val
                idx += 1
            except ValueError:
                pass

        # Key-value patterns: "count: 42", "total: 1234", "score: 98.5"
        for m in re.finditer(r"(\w+)\s*[:=]\s*(\d+(?:,\d{3})*(?:\.\d+)?)\b", text):
            key = m.group(1).lower()
            raw = m.group(2).replace(",", "")
            try:
                val = float(raw)
                # Use int if it's a whole number
                if val == int(val):
                    result[key] = int(val)
                else:
                    result[key] = val
            except ValueError:
                pass

        # Standalone numbers not already captured (e.g. in JSON or tables)
        # Only capture numbers that look significant (not single digits in prose)
        for m in re.finditer(r"(?<![.$€£¥\w])(\d+(?:,\d{3})*\.\d+)(?![%\w])", text):
            raw = m.group(1).replace(",", "")
            try:
                val = float(raw)
                key = f"value_{idx}"
                if key not in result:
                    result[key] = val
                    idx += 1
            except ValueError:
                pass

        return result

    def _pre_aggregate(self, entries: list[ChatMessage]) -> dict[str, list[ChatMessage]]:
        """Group scratchpad entries by tool name.

        Args:
            entries: List of ChatMessage entries from the scratchpad.

        Returns:
            Dict mapping tool names to their associated messages.
        """
        groups: dict[str, list[ChatMessage]] = {}

        i = 0
        while i < len(entries):
            msg = entries[i]
            tool_name = ""

            if msg.role == MessageRole.ASSISTANT:
                # Extract tool name from ASSISTANT message
                kwargs = msg.additional_kwargs or {}
                for tc in kwargs.get("tool_calls", []):
                    if isinstance(tc, dict):
                        tool_name = tc.get("name") or (tc.get("function") or {}).get("name", "")
                        if tool_name:
                            break

                if not tool_name and hasattr(msg, "blocks"):
                    for block in (msg.blocks or []):
                        if type(block).__name__ == "ToolCallBlock":
                            tool_name = getattr(block, "tool_name", "")
                            if tool_name:
                                break

                if tool_name:
                    groups.setdefault(tool_name, []).append(msg)
                    # Also add the following TOOL message if present
                    if i + 1 < len(entries) and entries[i + 1].role == MessageRole.TOOL:
                        groups[tool_name].append(entries[i + 1])
                        i += 2
                        continue
                else:
                    groups.setdefault("_other", []).append(msg)
            elif msg.role == MessageRole.TOOL:
                # Orphan TOOL message — use its name from kwargs
                kwargs = msg.additional_kwargs or {}
                tool_name = kwargs.get("name", "_other")
                groups.setdefault(tool_name, []).append(msg)
            else:
                groups.setdefault("_other", []).append(msg)

            i += 1

        return groups

    def _build_aggregate_summary(
        self,
        groups: dict[str, list[ChatMessage]],
        target_tokens: int,
    ) -> str:
        """Build an aggregated summary per tool group.

        For each group, counts calls, lists distinct arguments,
        and separates errors from successes.

        Args:
            groups: Dict mapping tool names to their messages.
            target_tokens: Token budget for the summary.

        Returns:
            Aggregated summary text.
        """
        sections: list[str] = []

        for tool_name, msgs in groups.items():
            # Separate ASSISTANT (call) and TOOL (result) messages
            calls = [m for m in msgs if m.role == MessageRole.ASSISTANT]
            results = [m for m in msgs if m.role == MessageRole.TOOL]

            call_count = len(calls)

            # Collect distinct arguments
            distinct_args: list[str] = []
            for call_msg in calls:
                kwargs = call_msg.additional_kwargs or {}
                for tc in kwargs.get("tool_calls", []):
                    if isinstance(tc, dict):
                        args_raw = tc.get("arguments") or (tc.get("function") or {}).get("arguments", "{}")
                        if isinstance(args_raw, str):
                            arg_str = args_raw
                        else:
                            arg_str = json.dumps(args_raw, sort_keys=True)
                        if arg_str not in distinct_args:
                            distinct_args.append(arg_str)

            # Separate errors from successes
            successes: list[str] = []
            errors: list[str] = []
            for res_msg in results:
                content = res_msg.content or ""
                content_lower = content.lower()
                if "error" in content_lower or "exception" in content_lower or "traceback" in content_lower:
                    errors.append(content[:200])
                else:
                    successes.append(content[:200])

            lines: list[str] = []
            lines.append(f"[{tool_name}] {call_count} appel(s)")
            if distinct_args:
                lines.append(f"  arguments distincts: {', '.join(distinct_args[:5])}")

            if successes:
                lines.append(f"  succès ({len(successes)}):")
                for s in successes[:3]:
                    lines.append(f"    - {s}")

            if errors:
                lines.append(f"  erreurs ({len(errors)}):")
                for e in errors[:3]:
                    lines.append(f"    - {e}")

            sections.append("\n".join(lines))

        full_summary = "\n\n".join(sections)

        # Check token budget and truncate if needed
        token_count = self._token_counter.count_tokens(full_summary).count
        if token_count <= target_tokens or target_tokens <= 0:
            return full_summary

        # Truncate: preserve first and last lines of each group
        truncated_sections: list[str] = []
        for section in sections:
            lines = section.split("\n")
            if len(lines) <= 4:
                truncated_sections.append(section)
            else:
                # Keep first 2 and last 2 lines
                kept = lines[:2] + ["  [...]"] + lines[-2:]
                truncated_sections.append("\n".join(kept))

        truncated_summary = "\n\n".join(truncated_sections)

        # If still over budget, progressively remove sections
        while truncated_sections:
            candidate = "\n\n".join(truncated_sections)
            if self._token_counter.count_tokens(candidate).count <= target_tokens:
                return candidate
            # Remove the largest section
            if len(truncated_sections) > 1:
                truncated_sections.pop(-2)
            else:
                break

        return truncated_summary

    def _build_summary_marker(
        self,
        method: str,
        entries_before: int,
        tool_names: list[str],
        llm_summary_text: str | None = None,
    ) -> ChatMessage:
        """Construit le Summary_Marker enrichi avec 3 sections.

        Sections:
        - Outils exécutés: liste des outils avec arguments et statut
        - Connaissances acquises: KnowledgeState ou résumé LLM
        - Prochaines étapes suggérées: recommandations basées sur les résultats

        Args:
            method: Méthode de compression utilisée.
            entries_before: Nombre d'entrées avant compression.
            tool_names: Noms des outils appelés.
            llm_summary_text: Texte du résumé LLM si disponible.
        """
        prefix = "[Résumé du scratchpad précédent]"

        # Section 1: Outils exécutés
        tools_section_lines: list[str] = []
        entries = self._knowledge_state.get_all_entries()
        if entries:
            for entry in entries:
                args_str = ", ".join(
                    f"{k}={v!r}" for k, v in entry.arguments.items()
                ) if entry.arguments else ""
                status_label = "succès" if entry.status == "success" else entry.status
                tools_section_lines.append(
                    f"- {entry.tool_name}({args_str}) → {status_label}"
                )
        elif tool_names:
            for name in tool_names:
                tools_section_lines.append(f"- {name}() → inconnu")

        if not tools_section_lines:
            tools_section_lines.append("- aucun outil exécuté")

        tools_section = "\n".join(tools_section_lines)

        # Section 2: Connaissances acquises
        if method == "llm_summary" and llm_summary_text:
            knowledge_section = llm_summary_text
        else:
            knowledge_text = self._knowledge_state.to_structured_text()
            if knowledge_text:
                knowledge_section = knowledge_text
            else:
                knowledge_section = f"{entries_before} entrées compressées, aucune donnée structurée extraite."

        # Section 3: Prochaines étapes suggérées
        failed_tools = [e for e in entries if e.status == "error"]
        next_steps_lines: list[str] = [
            "- Utiliser les données ci-dessus pour répondre à la question"
        ]
        if failed_tools:
            failed_names = ", ".join(e.tool_name for e in failed_tools)
            next_steps_lines.append(
                f"- Retenter les outils en erreur si nécessaire ({failed_names})"
            )

        next_steps = "\n".join(next_steps_lines)

        content = (
            f"{prefix}\n\n"
            f"## Outils exécutés\n{tools_section}\n\n"
            f"## Connaissances acquises\n{knowledge_section}\n\n"
            f"## Prochaines étapes suggérées\n{next_steps}"
        )

        return ChatMessage(
            role=MessageRole.SYSTEM,
            content=content,
        )

    def _log_compression(
        self,
        entries_before: int,
        entries_after: int,
        tokens_before: int,
        tokens_after: int,
        method: str,
    ) -> None:
        """Émet les logs de compression.

        Args:
            entries_before: Nombre d'entrées avant compression.
            entries_after: Nombre d'entrées après compression.
            tokens_before: Tokens avant compression.
            tokens_after: Tokens après compression.
            method: Méthode utilisée (llm_summary, truncation, single_result_truncation).
        """
        logger.info(
            "Scratchpad compressé : %d→%d entrées, %d→%d tokens, méthode=%s",
            entries_before,
            entries_after,
            tokens_before,
            tokens_after,
            method,
        )
        if entries_before > 10:
            logger.warning(
                "Boucle d'outils potentiellement excessive : %d entrées dans le scratchpad",
                entries_before,
            )
