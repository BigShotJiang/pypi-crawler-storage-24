# Docker Development Environment Setup

This guide explains how to use Docker Compose to run all external services required by the Agent Framework for local development.

The project provides three compose files:

| File | Purpose |
|------|---------|
| `docker-compose.yml` | Core services (storage, memory, file storage) |
| `docker-compose.observability.yml` | Observability stack (OTel Collector, Prometheus, Grafana, Jaeger) |
| `docker-compose.elastic-apm.yml` | Elastic APM native stack (Elasticsearch with security, APM Server, Kibana) |

## Available Services

### Core Services (`docker-compose.yml`)

| Service | Port(s) | Profile | Purpose | Default Credentials |
|---------|---------|---------|---------|---------------------|
| Elasticsearch | 9200 | storage, all | Session storage, logging, configuration | None (security disabled) |
| MongoDB | 27017 | storage, all | Alternative session storage | None (no auth) |
| PostgreSQL | 5432 | memory, all | Memori memory provider, A2A Task Store | postgres / postgres |
| FalkorDB | 6379 | memory, all | Graphiti memory provider (Redis-compatible) | None (no auth) |
| MinIO | 9000 (API), 9001 (Console) | storage, all | S3-compatible file storage | minioadmin / minioadmin |

### Observability Services (`docker-compose.observability.yml`)

| Service | Port(s) | Purpose | Default Credentials |
|---------|---------|---------|---------------------|
| OTel Collector | 4317 (gRPC), 4318 (HTTP), 8889 (Prometheus), 13133 (health), 55679 (zPages) | Central telemetry hub | None |
| Prometheus | 9090 | Metrics storage and querying | None |
| Jaeger | 16686 (UI), 14268 (HTTP collector) | Distributed tracing backend | None |
| Grafana | 3000 | Visualization and dashboards | admin / admin |

### Elastic APM Services (`docker-compose.elastic-apm.yml`)

| Service | Port(s) | Purpose | Default Credentials |
|---------|---------|---------|---------------------|
| Elasticsearch (APM) | 9201 | Elasticsearch with security enabled | elastic / changeme |
| APM Server | 8200 | Receives OTLP data (native support) | None |
| Kibana (APM) | 5601 | APM dashboards and visualization | elastic / changeme |

## Quick Start

### Start All Core Services

```bash
# Start all core services
docker compose --profile all up -d

# Check service status
docker compose ps

# View logs
docker compose logs -f
```

### Configure Your Application

```bash
# Copy the Docker environment template
cp .env.docker .env

# Edit .env to add your LLM API keys
# OPENAI_API_KEY=sk-your-key-here
```

### Stop Services

```bash
# Stop all services (preserves data)
docker compose down

# Stop and remove all data
docker compose down -v
```

## Using Profiles

Profiles allow you to start only the services you need, reducing resource usage.

### Storage Profile
Start session storage and file storage services:
```bash
docker compose --profile storage up -d
```
Services: Elasticsearch, MongoDB, MinIO

### Memory Profile
Start memory provider services:
```bash
docker compose --profile memory up -d
```
Services: PostgreSQL, FalkorDB

### All Profile
Start the complete core stack:
```bash
docker compose --profile all up -d
```
Services: All of the above

### Individual Services
Start specific services by name:
```bash
# Just Elasticsearch
docker compose up -d elasticsearch

# Elasticsearch and MongoDB
docker compose up -d elasticsearch mongodb
```

## Service Details

### Elasticsearch (Session Storage)

Primary backend for production deployments. Provides session storage, centralized logging, and dynamic configuration.

```bash
# Test connection
curl http://localhost:9200/_cluster/health

# View indices
curl http://localhost:9200/_cat/indices?v
```

Environment variables:
```env
SESSION_STORAGE_TYPE=elasticsearch
ELASTICSEARCH_URL=http://localhost:9200
ELASTICSEARCH_ENABLED=true
```

### MongoDB (Alternative Session Storage)

Simpler alternative to Elasticsearch for session storage.

```bash
# Test connection
mongosh --eval "db.adminCommand('ping')"
```

Environment variables:
```env
SESSION_STORAGE_TYPE=mongodb
MONGODB_CONNECTION_STRING=mongodb://localhost:27017
```

### PostgreSQL (Memory Provider & A2A Task Store)

PostgreSQL serves two purposes in the Agent Framework:

1. **Memori Memory Provider** — SQL-based memory provider for semantic memory features. Configured via the `MEMORI_DATABASE_URL` environment variable.
2. **A2A Task Store** — Persistent storage for A2A (Agent-to-Agent) task state. The `PostgresTaskProvider` is auto-detected at startup when the `asyncpg` package is installed (via the `postgresql` extra). It uses the same PostgreSQL instance.

```bash
# Test connection
pg_isready -h localhost -p 5432

# Connect to database
psql -h localhost -U postgres -d agent_memory
```

Environment variables for Memori:
```env
MEMORI_DATABASE_URL=postgresql://postgres:postgres@localhost:5432/agent_memory
```

Environment variables for A2A:
```env
A2A_ENABLED=true
# The A2A task store provider is auto-detected. If asyncpg is installed
# and Elasticsearch is not enabled, PostgreSQL is used automatically.
# See configuration.md for details on provider selection.
```

### FalkorDB (Graphiti Memory Provider)

Graph database for knowledge graph-based memory. Uses Redis-compatible protocol.

```bash
# Test connection
redis-cli -p 6379 ping
```

Environment variables:
```env
GRAPHITI_USE_FALKORDB=true
FALKORDB_HOST=localhost
FALKORDB_PORT=6379
```

### MinIO (File Storage)

S3-compatible object storage for file uploads and storage.

```bash
# Test API health
curl http://localhost:9000/minio/health/live

# Access web console
open http://localhost:9001
```

Environment variables:
```env
FILE_STORAGE_TYPE=minio
MINIO_ENDPOINT=localhost:9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET_NAME=agent-files
MINIO_SECURE=false
```

## Observability Stack

The observability stack is defined in `docker-compose.observability.yml` and provides metrics, tracing, and visualization for the Agent Framework.

**Prerequisite:** Elasticsearch must be running on the host (port 9200). Start it first:
```bash
docker compose -f docker-compose.yml --profile storage up -d elasticsearch
```

### Starting the Observability Stack

```bash
docker compose -f docker-compose.observability.yml up -d
```

### Services

- **OTel Collector** — Central telemetry hub that receives OTLP data (gRPC on port 4317, HTTP on port 4318) and exports to Prometheus and Jaeger.
- **Prometheus** — Metrics storage and querying (port 9090). Scrapes the OTel Collector's Prometheus exporter. Data retained for 15 days.
- **Jaeger** — Distributed tracing backend with a web UI on port 16686.
- **Grafana** — Visualization dashboards on port 3000. Pre-configured with Prometheus and Jaeger datasources. Default credentials: `admin` / `admin`.

### Configuration Files

The observability stack mounts configuration files from the `observability/` directory:

- `observability/otel-collector-config.yaml` — OTel Collector pipeline configuration
- `observability/prometheus.yml` — Prometheus scrape targets
- `observability/grafana/provisioning/` — Grafana datasource and dashboard provisioning
- `observability/grafana/dashboards/` — Pre-built Grafana dashboards

### Environment Variables

```env
OTEL_ENABLED=true
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
OTEL_ENVIRONMENT=development
```

## Elastic APM Stack

The Elastic APM stack is defined in `docker-compose.elastic-apm.yml` and provides an alternative observability solution using the Elastic ecosystem natively.

### Starting the Elastic APM Stack

```bash
docker compose -f docker-compose.elastic-apm.yml up -d
```

> **Note:** This stack uses port 9201 for Elasticsearch (instead of 9200) to avoid conflicts with the core Elasticsearch service.

### Services

- **Elasticsearch (APM)** — Elasticsearch 8.11.0 with security enabled. Credentials: `elastic` / `changeme`. Accessible on port 9201.
- **APM Server** — Elastic APM Server 8.11.0 with native OTLP support on port 8200. Receives traces and metrics from the application.
- **Kibana (APM)** — Kibana 8.11.0 with APM dashboards on port 5601. Credentials: `elastic` / `changeme`.
- **Setup** — One-shot container that configures the `kibana_system` password.

### URLs

| Service | URL | Credentials |
|---------|-----|-------------|
| Kibana | http://localhost:5601 | elastic / changeme |
| APM Server (OTLP) | http://localhost:8200 | — |
| Elasticsearch | http://localhost:9201 | elastic / changeme |

## Common Use Cases

### Development with Elasticsearch Only

For testing session storage and logging:
```bash
docker compose up -d elasticsearch
```

### Testing Memory Features

For testing Memori and Graphiti memory providers:
```bash
docker compose --profile memory up -d
```

### Testing A2A with PostgreSQL

For testing A2A endpoints with the PostgreSQL task store:
```bash
docker compose --profile memory up -d

# Ensure asyncpg is installed
uv run python -c "import asyncpg; print('asyncpg available')"
```

### Full Production-Like Environment

For comprehensive testing with all backends:
```bash
docker compose --profile all up -d
cp .env.docker .env
# Add your LLM API keys to .env
```

### Full Observability

For running the complete stack with observability:
```bash
# Start core services
docker compose --profile all up -d

# Start observability stack
docker compose -f docker-compose.observability.yml up -d
```

### Running Example Agents

```bash
# Start required services
docker compose --profile all up -d

# Configure environment
cp .env.docker .env
# Edit .env with your API keys

# Run an example agent
cd examples
uv run python simple_agent.py
```

## Troubleshooting

### Port Conflicts

If a port is already in use:

```bash
# Check what's using the port
lsof -i :9200

# Option 1: Stop the conflicting service
# Option 2: Create docker-compose.override.yml with different ports
```

Example `docker-compose.override.yml`:
```yaml
services:
  elasticsearch:
    ports:
      - "9201:9200"
```

### Service Won't Start

Check service logs:
```bash
docker compose logs elasticsearch
docker compose logs postgres
```

### Elasticsearch Memory Issues

If Elasticsearch fails with memory errors:

1. Increase Docker memory allocation (Docker Desktop → Settings → Resources)
2. Or reduce heap size in docker-compose.override.yml:
```yaml
services:
  elasticsearch:
    environment:
      - ES_JAVA_OPTS=-Xms256m -Xmx512m
```

### Health Check Failures

Services may take time to become healthy. Check status:
```bash
docker compose ps
```

Wait for all services to show "healthy" status before connecting.

### Data Persistence

Data is stored in named volumes. To reset:
```bash
# Remove specific volume
docker volume rm agentframework_elasticsearch_data

# Remove all project volumes
docker compose down -v
```

### Connection Refused Errors

Ensure services are running and healthy:
```bash
docker compose ps
docker compose logs <service-name>
```

For Elasticsearch, wait for the cluster to be ready:
```bash
curl http://localhost:9200/_cluster/health?wait_for_status=yellow&timeout=60s
```

## Default Credentials Summary

| Service | Username | Password | Notes |
|---------|----------|----------|-------|
| Elasticsearch (core) | — | — | Security disabled (`xpack.security.enabled=false`) |
| MongoDB | — | — | No authentication |
| PostgreSQL | postgres | postgres | Database: `agent_memory` |
| FalkorDB | — | — | No authentication (Redis protocol) |
| MinIO | minioadmin | minioadmin | Console on port 9001 |
| Grafana | admin | admin | Anonymous viewer access enabled |
| Elasticsearch (APM) | elastic | changeme | Security enabled |
| Kibana (APM) | elastic | changeme | Via Elastic APM stack |

## Resource Requirements

Minimum recommended resources for running all services:
- CPU: 4 cores
- RAM: 8 GB
- Disk: 10 GB free space

For limited resources, use profiles to run only needed services.

The observability stack requires additional resources:
- CPU: +2 cores
- RAM: +4 GB
