# Creating Agents Guide

This comprehensive guide explains how to create custom agents with the Agent Framework. Whether you're using LlamaIndex, Microsoft Agent Framework, or integrating a custom AI framework, this guide provides everything you need to build production-ready agents.

## Table of Contents

- [Quick Start](#quick-start)
- [Choosing Your Approach](#choosing-your-approach)
- [LlamaIndex Agent Creation](#llamaindex-agent-creation)
- [BaseAgent (Custom Framework) Creation](#baseagent-custom-framework-creation)
- [MicrosoftAgent Creation](#microsoftagent-creation)
- [Agent Tags and Image URL](#agent-tags-and-image-url)
- [Welcome Message](#welcome-message)
- [Public API Reference](#public-api-reference)
- [Adding Memory to Your Agent](#adding-memory-to-your-agent)
- [Skills Integration](#skills-integration)
- [Streaming Architecture](#streaming-architecture)
- [Tool Integration](#tool-integration)
- [A2A Integration](#a2a-integration)
- [State Management and Agent Lifecycle](#state-management-and-agent-lifecycle)
- [Best Practices](#best-practices)
- [Examples](#examples)

## Quick Start

The fastest way to create an agent is to inherit from `LlamaIndexAgent`:

```python
from agent_framework import LlamaIndexAgent, create_basic_agent_server

class MyAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="my_agent_v1",
            name="My Agent",
            description="A helpful assistant."
        )

    def get_agent_prompt(self) -> str:
        return "You are a helpful assistant."

    def get_agent_tools(self) -> list[callable]:
        return []

create_basic_agent_server(MyAgent, port=8000)
```

That's it! You now have a fully functional agent with automatic conversation memory, session management, streaming responses, and a web interface.

## Choosing Your Approach

The Agent Framework provides three ways to create agents:

### Decision Tree

```
Which AI framework do you want to use?
│
├─ LlamaIndex → Use LlamaIndexAgent
│   ├─ ✅ Fastest to implement (3 required methods)
│   ├─ ✅ Automatic memory management
│   ├─ ✅ Built-in streaming support
│   ├─ ✅ Rich ecosystem of tools
│   └─ 📖 See: LlamaIndex Agent Creation
│
├─ Microsoft Agent Framework → Use MicrosoftAgent
│   ├─ ✅ Azure AI integration
│   ├─ ✅ Built-in streaming support
│   ├─ ✅ Same 3 required methods as LlamaIndex
│   └─ 📖 See: MicrosoftAgent Creation
│
└─ Other (LangChain, Haystack, custom) → Use BaseAgent
    ├─ ✅ Framework-agnostic
    ├─ ✅ Full control over agent behavior
    ├─ ✅ Custom streaming implementation
    ├─ ⚠️  More methods to implement (7 required)
    └─ 📖 See: BaseAgent Creation
```

### Comparison Table

| Feature | LlamaIndexAgent | MicrosoftAgent | BaseAgent |
|---------|----------------|----------------|-----------|
| **Required Methods** | 3 | 3 | 7 |
| **Complexity** | Low | Low | Medium |
| **Framework** | LlamaIndex | Microsoft AI | Any framework |
| **Memory** | Automatic | Manual | Manual |
| **Streaming** | Built-in | Built-in | Custom implementation |
| **Best For** | Quick prototypes, LlamaIndex users | Azure AI users | Custom frameworks, full control |

---

## LlamaIndex Agent Creation

### Overview

`LlamaIndexAgent` is a concrete implementation that provides LlamaIndex-specific functionality with automatic memory management and streaming support.

### Required Methods

You must implement these 3 methods:

#### 1. `get_agent_prompt() -> str`

Define the agent's system prompt.

```python
def get_agent_prompt(self) -> str:
    return """You are a helpful calculator assistant.
    You can perform basic arithmetic operations.
    Always show your work and explain the calculation steps."""
```


#### 2. `get_agent_tools() -> list[callable]`

Define the tools available to the agent.

```python
def get_agent_tools(self) -> list[callable]:
    def add(a: float, b: float) -> float:
        """Add two numbers together."""
        return a + b

    def multiply(a: float, b: float) -> float:
        """Multiply two numbers together."""
        return a * b

    return [add, multiply]
```

Each tool must have:
- A clear function name
- A docstring (LLM reads this to understand the tool)
- Type hints (helps LLM understand parameters)
- A return value (sent back to LLM)

#### 3. `initialize_agent(model_name, system_prompt, tools, **kwargs) -> None`

Initialize the LlamaIndex agent.

```python
async def initialize_agent(
    self,
    model_name: str,
    system_prompt: str,
    tools: list[callable],
    **kwargs
) -> None:
    from llama_index.core.agent.workflow import FunctionAgent

    llm = self.create_llm(model_name)
    self._agent_instance = FunctionAgent(
        tools=tools,
        llm=llm,
        system_prompt=system_prompt,
        verbose=kwargs.get('verbose', True)
    )
```

Use `self.create_llm(model_name)` to automatically create the correct LLM client (OpenAI, Anthropic, or Gemini) based on the model name.

### Optional Methods

Override these methods for advanced customization:

#### Context Management

```python
def create_fresh_context(self) -> Any:
    from llama_index.core.workflow import Context
    return Context(self._agent_instance)

def serialize_context(self, ctx: Any) -> dict[str, Any]:
    from llama_index.core.workflow import JsonSerializer
    return ctx.to_dict(serializer=JsonSerializer())

def deserialize_context(self, state: dict[str, Any]) -> Any:
    from llama_index.core.workflow import Context, JsonSerializer
    return Context.from_dict(
        self._agent_instance,
        state,
        serializer=JsonSerializer()
    )
```

#### MCP Tools

```python
def get_mcp_server_params(self) -> list:
    from autogen_ext.tools.mcp import StdioServerParams
    from agent_framework import get_deno_command

    return [
        StdioServerParams(
            command=get_deno_command(),
            args=['run', '-N', 'jsr:@pydantic/mcp-run-python', 'stdio'],
            read_timeout_seconds=120
        )
    ]
```

#### Remote Configuration (Ops-Managed Agents)

```python
@classmethod
def get_use_remote_config(cls) -> bool:
    """Enable Elasticsearch-only configuration management."""
    return True
```

| Aspect | Code-Managed (`False`) | Ops-Managed (`True`) |
|--------|------------------------|----------------------|
| Config source | Hardcoded in Python | Elasticsearch only |
| Server startup | Pushes config to ES if different | Skips pushing to ES |
| Session init | Merges ES + hardcoded | Reads ES only |
| Use case | Developer-controlled agents | Runtime-configurable agents |

### Complete Example

See [examples/simple_agent.py](../examples/simple_agent.py) for a complete working example.

```python
from agent_framework import LlamaIndexAgent, create_basic_agent_server

class CalculatorAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="calculator_agent_v1",
            name="Calculator Agent",
            description="A helpful calculator assistant that can perform basic math operations."
        )

    def get_agent_prompt(self) -> str:
        return """You are a helpful calculator assistant.
        Use the provided tools to perform calculations."""

    def get_agent_tools(self) -> list[callable]:
        def add(a: int, b: int) -> int:
            """Add two numbers together."""
            return a + b

        def multiply(a: int, b: int) -> int:
            """Multiply two numbers together."""
            return a * b

        return [add, multiply]

    async def initialize_agent(
        self,
        model_name: str,
        system_prompt: str,
        tools: list[callable],
        **kwargs
    ) -> None:
        from llama_index.core.agent.workflow import FunctionAgent

        llm = self.create_llm(model_name)
        self._agent_instance = FunctionAgent(
            tools=tools,
            llm=llm,
            system_prompt=system_prompt,
            verbose=True
        )

if __name__ == "__main__":
    create_basic_agent_server(CalculatorAgent, port=8000)
```

---

## BaseAgent (Custom Framework) Creation

### Overview

`BaseAgent` is a framework-agnostic base class that allows you to integrate ANY AI framework (LangChain, Haystack, custom implementations, etc.) with the Agent Framework.

### Required Methods

You must implement these 7 methods:

#### 1. `get_agent_prompt() -> str`

Same as LlamaIndex — define the agent's system prompt.

#### 2. `get_agent_tools() -> list[callable]`

Same as LlamaIndex — define the tools available to the agent.

#### 3. `initialize_agent(model_name, system_prompt, tools, **kwargs) -> None`

Initialize your custom framework's agent.

```python
async def initialize_agent(
    self,
    model_name: str,
    system_prompt: str,
    tools: list[callable],
    **kwargs
) -> None:
    from agent_framework import client_factory

    self._llm_client = client_factory.create_client(model_name=model_name)
    self._system_prompt = system_prompt
    self._tools = {tool.__name__: tool for tool in tools}
```

Use `client_factory.create_client()` for automatic LLM provider detection.

#### 4. `create_fresh_context() -> Any`

Create a new conversation context.

```python
def create_fresh_context(self) -> Any:
    return {"messages": []}
```

#### 5. `serialize_context(ctx) -> dict[str, Any]`

Serialize context to dictionary for persistence.

```python
def serialize_context(self, ctx: Any) -> dict[str, Any]:
    return ctx
```

Must return JSON-serializable dict (str, int, float, bool, None, list, dict).

#### 6. `deserialize_context(state) -> Any`

Deserialize dictionary to context object.

```python
def deserialize_context(self, state: dict[str, Any]) -> Any:
    return state
```

Must return same type as `create_fresh_context()`.

#### 7. `run_agent(query, ctx, stream=False) -> str | AsyncGenerator`

Execute the agent with a query.

```python
async def run_agent(
    self,
    query: str,
    ctx: Any,
    stream: bool = False
) -> str | AsyncGenerator:
    if stream:
        return self._run_streaming(query, ctx)
    else:
        return await self._run_non_streaming(query, ctx)
```

- **Non-streaming** (`stream=False`): Return final response as string
- **Streaming** (`stream=True`): Return AsyncGenerator yielding RAW framework events

When streaming, yield RAW framework-specific events. They will be converted to unified format via `process_streaming_event()`.

### Optional Methods

#### `process_streaming_event(event) -> dict[str, Any] | None`

Convert framework-specific streaming events to unified format.

```python
async def process_streaming_event(self, event: Any) -> dict[str, Any] | None:
    if isinstance(event, dict) and "type" in event:
        return event
    return None
```

Unified format:
```python
{
    "type": "chunk" | "tool_call" | "tool_result" | "activity" | "error",
    "content": str,
    "metadata": {...}
}
```

#### `get_model_config() -> dict[str, Any]`

Return default model configuration (temperature, max_tokens, etc.).

```python
def get_model_config(self) -> dict[str, Any]:
    return {"temperature": 0.7, "max_tokens": 4096}
```

#### `get_mcp_server_params() -> dict[str, Any] | None`

Return MCP server configuration if MCP tools are needed. Returns `None` by default.

### Complete Example

See [examples/custom_framework_agent.py](../examples/custom_framework_agent.py) for a complete working example.

```python
from agent_framework import BaseAgent, client_factory
from typing import Any, AsyncGenerator

class CustomFrameworkAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            agent_id="custom_agent_v1",
            name="Custom Framework Agent",
            description="A helpful assistant using a custom AI framework."
        )

    def get_agent_prompt(self) -> str:
        return "You are a helpful assistant."

    def get_agent_tools(self) -> list[callable]:
        def add(a: float, b: float) -> float:
            """Add two numbers."""
            return a + b
        return [add]

    async def initialize_agent(
        self,
        model_name: str,
        system_prompt: str,
        tools: list[callable],
        **kwargs
    ) -> None:
        self._llm_client = client_factory.create_client(model_name=model_name)
        self._system_prompt = system_prompt
        self._tools = {tool.__name__: tool for tool in tools}

    def create_fresh_context(self) -> Any:
        return {"messages": []}

    def serialize_context(self, ctx: Any) -> dict[str, Any]:
        return ctx

    def deserialize_context(self, state: dict[str, Any]) -> Any:
        return state

    async def run_agent(
        self,
        query: str,
        ctx: Any,
        stream: bool = False
    ) -> str | AsyncGenerator:
        ctx["messages"].append({"role": "user", "content": query})
        messages = [
            {"role": "system", "content": self._system_prompt},
            *ctx["messages"]
        ]

        if stream:
            return self._stream_response(messages, ctx)
        else:
            response = await self._llm_client.create(messages=messages)
            final_text = response.choices[0].message.content
            ctx["messages"].append({"role": "assistant", "content": final_text})
            return final_text

    async def _stream_response(self, messages, ctx):
        stream = await self._llm_client.create(messages=messages, stream=True)
        accumulated = ""
        async for chunk in stream:
            delta = chunk.choices[0].delta
            if hasattr(delta, 'content') and delta.content:
                accumulated += delta.content
                yield {
                    "type": "chunk",
                    "content": delta.content,
                    "metadata": {}
                }
        ctx["messages"].append({"role": "assistant", "content": accumulated})

    async def process_streaming_event(self, event: Any) -> dict[str, Any] | None:
        if isinstance(event, dict) and "type" in event:
            return event
        return None
```


---

## MicrosoftAgent Creation

### Overview

`MicrosoftAgent` is a concrete implementation of `BaseAgent` for the Microsoft Agent Framework. It provides built-in streaming support and Azure AI integration.

`MicrosoftAgent` is exported from the top-level package:

```python
from agent_framework import MicrosoftAgent
```

### Required Methods

Same 3 methods as `LlamaIndexAgent`:

1. `get_agent_prompt() -> str`
2. `get_agent_tools() -> list[callable]`
3. `initialize_agent(model_name, system_prompt, tools, **kwargs) -> None`

Context management (`create_fresh_context`, `serialize_context`, `deserialize_context`) and streaming (`run_agent`, `process_streaming_event`) are handled by the base implementation.

### Example

```python
from agent_framework import MicrosoftAgent, create_basic_agent_server

class MyMicrosoftAgent(MicrosoftAgent):
    def __init__(self):
        super().__init__(
            agent_id="ms_agent_v1",
            name="Microsoft Agent",
            description="An agent using the Microsoft Agent Framework."
        )

    def get_agent_prompt(self) -> str:
        return "You are a helpful assistant."

    def get_agent_tools(self) -> list[callable]:
        return []

if __name__ == "__main__":
    create_basic_agent_server(MyMicrosoftAgent, port=8000)
```

---

## Agent Tags and Image URL

You can add visual metadata to your agents for better organization and UI display.

### The `Tag` Model

The `Tag` model is defined in `agent_framework.core.models`:

```python
from agent_framework.core.models import Tag
```

| Field | Type | Description |
|-------|------|-------------|
| `name` | `str` | Display name of the tag (non-empty, trimmed) |
| `color` | `str` | Hex color code in `#RGB` or `#RRGGBB` format (normalized to uppercase) |

Class methods:

| Method | Signature | Description |
|--------|-----------|-------------|
| `from_name` | `Tag.from_name(name: str) -> Tag` | Create a tag with a random color |
| `generate_random_color` | `Tag.generate_random_color() -> str` | Generate a random hex color (`#RRGGBB`) |

### Using Tags and Image URL

Tags can be passed as `Tag` objects, dicts, or strings in the `__init__` constructor of any agent:

```python
from agent_framework import LlamaIndexAgent
from agent_framework.core.models import Tag

class MyAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="my_agent_v1",
            name="My Agent",
            description="A helpful assistant.",
            tags=[
                Tag(name="production", color="#28A745"),  # Tag object with explicit color
                {"name": "support", "color": "#007BFF"},  # Dict with color
                {"name": "v2"},                           # Dict without color (random color)
                "experimental"                            # String only (random color)
            ],
            image_url="https://example.com/agents/my-agent.png"
        )

    def get_agent_prompt(self) -> str:
        return "You are a helpful assistant."

    def get_agent_tools(self) -> list[callable]:
        return []
```

Tags without colors automatically get random colors assigned via `Tag.generate_random_color()`.

Tags and `image_url` are included in the agent metadata returned by `get_metadata()` and displayed in the web UI.

---

## Welcome Message

### `get_welcome_message() -> str | None`

Override this method to provide a greeting message displayed when users start a new conversation.

```python
async def get_welcome_message(self) -> str | None:
    return f"Bonjour ! Je suis {self.name}.\n\n{self.description}"
```

**Behavior:**
- Called automatically when a new session is created via `/init`
- Message is saved as the first assistant message in the session
- Returned in `SessionInitResponse.welcome_message` field
- Default returns `None` (no welcome message)

**Defined in:** `AgentInterface` (inherited by `BaseAgent`, `LlamaIndexAgent`, `MicrosoftAgent`)

---

## Public API Reference

### `BaseAgent`

`BaseAgent` is the framework-agnostic abstract base class. All agents inherit from it.

```python
from agent_framework import BaseAgent
```

#### Constructor

```python
BaseAgent(
    agent_id: str,
    name: str,
    description: str,
    tags: list[Tag] | list[dict[str, str]] | None = None,
    image_url: str | None = None,
    hoover: str | None = None,
    short_description: str | None = None,
)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `agent_id` | `str` | Unique identifier for the agent (used for session isolation) |
| `name` | `str` | Human-readable name |
| `description` | `str` | Description of the agent's purpose and capabilities |
| `tags` | `list[Tag] \| list[dict] \| None` | Optional tags for categorization (see [Agent Tags](#agent-tags-and-image-url)) |
| `image_url` | `str \| None` | Optional URL to an image representing the agent |
| `hoover` | `str \| None` | Optional hover text displayed on agent card |
| `short_description` | `str \| None` | Optional short description for compact display |

Raises `ValueError` if `agent_id`, `name`, or `description` is empty.

#### Abstract Methods (must implement)

| Method | Signature | Description |
|--------|-----------|-------------|
| `get_agent_prompt` | `() -> str` | Return the default system prompt |
| `get_agent_tools` | `() -> list[callable]` | Return the list of tools available to the agent |
| `initialize_agent` | `async (model_name: str, system_prompt: str, tools: list[callable], **kwargs) -> None` | Initialize the agent with the underlying framework |
| `create_fresh_context` | `() -> Any` | Create a new empty context for the agent |
| `serialize_context` | `(ctx: Any) -> dict[str, Any]` | Serialize context to dictionary for persistence |
| `deserialize_context` | `(state: dict[str, Any]) -> Any` | Deserialize dictionary to context object |
| `run_agent` | `async (query: str, ctx: Any, stream: bool = False) -> str \| AsyncGenerator` | Execute the agent with a query |

#### Optional Methods (can override)

| Method | Signature | Default | Description |
|--------|-----------|---------|-------------|
| `get_mcp_server_params` | `() -> dict[str, Any] \| None` | `None` | Return MCP server configuration |
| `process_streaming_event` | `async (event: Any) -> dict[str, Any] \| None` | `None` | Convert framework events to unified format |
| `get_model_config` | `() -> dict[str, Any]` | `{}` | Return default model configuration |
| `get_welcome_message` | `async () -> str \| None` | `None` | Return greeting message for new sessions |

#### Lifecycle Methods (managed by framework)

| Method | Signature | Description |
|--------|-----------|-------------|
| `configure_session` | `async (session_configuration: dict[str, Any]) -> None` | Configure agent with session-level settings (system prompt, model config). Called by `AgentManager` before first use. |
| `get_system_prompt` | `async () -> str \| None` | Return the current system prompt with skills discovery capabilities injected |
| `get_current_model` | `async (session_id: str) -> str \| None` | Return the current model name |
| `get_metadata` | `async () -> dict[str, Any]` | Return agent metadata (id, name, description, tags, image_url, capabilities, tools) |
| `handle_message` | `async (session_id: str, agent_input: StructuredAgentInput) -> StructuredAgentOutput` | Handle a user message in non-streaming mode |
| `handle_message_stream` | `async (session_id: str, agent_input: StructuredAgentInput) -> AsyncGenerator` | Handle a user message in streaming mode. **Do not override** — orchestration is handled by the framework. |
| `get_state` | `async () -> dict[str, Any]` | Get the current agent state for persistence |
| `load_state` | `async (state: dict[str, Any]) -> None` | Load agent state from a dictionary |

### `LlamaIndexAgent`

`LlamaIndexAgent` extends `BaseAgent` with LlamaIndex-specific functionality.

```python
from agent_framework import LlamaIndexAgent
```

#### Constructor

```python
LlamaIndexAgent(
    agent_id: str,
    name: str,
    description: str,
    default_model: str | None = None,
    metrics_enabled: bool | None = None,
    tags: list | None = None,
    image_url: str | None = None,
    hoover: str | None = None,
    short_description: str | None = None,
)
```

Additional parameters beyond `BaseAgent`:

| Parameter | Type | Description |
|-----------|------|-------------|
| `default_model` | `str \| None` | Default model for backward compatibility. Bypasses ModelRouter when set. |
| `metrics_enabled` | `bool \| None` | Enable/disable LLM metrics collection. Defaults to `True` if available, overridable via `ENABLE_LLM_METRICS` env var. |

#### Additional Public Methods

| Method | Signature | Description |
|--------|-----------|-------------|
| `create_llm` | `(model_name: str = None, agent_config: AgentConfig = None, **override_params) -> Any` | Helper to create a LlamaIndex LLM using `ModelClientFactory`. Handles provider-specific imports automatically. |
| `set_session_storage` | `(session_storage: Any) -> None` | Set the session storage backend for memory management. Called by the server. |
| `configure_session_with_model` | `async (session_configuration: dict[str, Any], model_name: str) -> None` | Configure session with a specific model, handling model changes mid-session. |
| `set_model_for_session` | `async (session_id: str, model_name: str) -> None` | Set the model for a session (called by server before streaming). |
| `get_current_model` | `async (session_id: str = None) -> str \| None` | Get the current model being used. |
| `get_default_model` | `() -> str \| None` | Get the default model configured for this agent. |
| `get_llm_metrics` | `() -> LLMMetrics \| None` | Get the most recent LLM metrics from the last completed call. |
| `set_api_timing_tracker` | `(tracker: Any) -> None` | Set the API timing tracker for correlation with LLM metrics. |
| `set_display_config_manager` | `(manager: DisplayConfigManager \| None) -> None` | Set the display config manager for event enrichment. |
| `set_auto_instrumentor` | `(instrumentor: Any) -> None` | Set the LLM auto-instrumentor for accurate token tracking. |

#### Example: Using `create_llm`

```python
async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
    from llama_index.core.agent.workflow import FunctionAgent

    llm = self.create_llm(model_name)
    self._agent_instance = FunctionAgent(
        tools=tools, llm=llm, system_prompt=system_prompt
    )
```

#### Example: Retrieving LLM Metrics

```python
response = await agent.handle_message(session_id, agent_input)
metrics = agent.get_llm_metrics()
if metrics:
    print(f"Total tokens: {metrics.total_tokens}")
    print(f"Duration: {metrics.duration_ms}ms")
```

### `MicrosoftAgent`

`MicrosoftAgent` extends `BaseAgent` with Microsoft Agent Framework integration.

```python
from agent_framework import MicrosoftAgent
```

Same constructor as `BaseAgent`. Provides built-in implementations for context management, streaming, and `process_streaming_event`.

### `StateManager`

`StateManager` provides utilities for agent state compression, decompression, and history management.

```python
from agent_framework import StateManager
```

| Method | Signature | Description |
|--------|-----------|-------------|
| `compress_state` | `(state: dict[str, Any]) -> dict[str, Any]` | Compress agent state for storage (static method) |
| `decompress_state` | `(compressed_state: dict[str, Any]) -> dict[str, Any]` | Decompress agent state (static method) |
| `truncate_history` | `(state: dict, max_messages: int, ...) -> dict` | Truncate conversation history to limit size (static method) |
| `create_agent_identity` | `(agent_instance, ...) -> AgentIdentity` | Create an `AgentIdentity` from an agent instance (static method) |
| `validate_state_compatibility` | `(state: dict, agent_instance, ...) -> bool` | Validate state compatibility with an agent (static method) |

### `AgentIdentity`

`AgentIdentity` is a dataclass representing an agent's identity metadata.

```python
from agent_framework import AgentIdentity
```

| Field | Type | Description |
|-------|------|-------------|
| `agent_id` | `str` | Unique agent identifier |
| `name` | `str` | Human-readable name |
| `description` | `str` | Agent description |
| `framework` | `str` | Framework name (e.g., "LlamaIndex", "Microsoft") |
| `version` | `str` | Agent version |

Methods: `to_dict() -> dict`, `AgentIdentity.from_dict(data: dict) -> AgentIdentity`

### `AgentManager`

`AgentManager` manages agent lifecycle: creation, session configuration, state persistence, and observability.

```python
from agent_framework import AgentManager
```

| Method | Signature | Description |
|--------|-----------|-------------|
| `__init__` | `(storage: SessionStorageInterface)` | Initialize with a session storage backend |
| `get_agent` | `async (agent_class, session_id, user_id, ...) -> AgentInterface` | Get or create an agent instance for a session, handling configuration and state loading |
| `save_agent_state` | `async (session_id: str, agent_instance: AgentInterface) -> None` | Save agent state to session storage |


---

## Adding Memory to Your Agent

The Memory Module provides long-term semantic memory capabilities for your agents. It enables agents to remember information across conversations, extract facts automatically, and provide personalized, context-aware responses.

### Overview

Memory is **completely optional** — agents work perfectly without it. When enabled, memory provides:

- **Automatic fact extraction** from conversations
- **Passive context injection** — relevant memories injected into prompts automatically
- **Active memory tools** — agent can explicitly recall, store, and forget information
- **Multiple providers** — Memori (SQL-native) and Graphiti (knowledge graph)
- **Hybrid mode** — use both providers simultaneously

### Enabling Memory

Override the `get_memory_config()` method in your agent:

```python
from agent_framework import LlamaIndexAgent
from agent_framework.memory import MemoryConfig

class MyMemoryAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="memory_agent_v1",
            name="Memory Agent",
            description="An agent with long-term memory."
        )

    def get_agent_prompt(self) -> str:
        return "You are a helpful assistant with memory capabilities."

    def get_agent_tools(self) -> list:
        return []

    def get_memory_config(self):
        return MemoryConfig.memori_simple(
            database_url="sqlite:///agent_memory.db",
            passive_injection=True,
            auto_store_interactions=True
        )
```

### Memory Configuration Options

#### Memori (SQL-Native) — Simplest Setup

```python
def get_memory_config(self):
    return MemoryConfig.memori_simple(
        database_url="sqlite:///memory.db",
        passive_injection=True,
        auto_store_interactions=True
    )
```

#### Graphiti (Knowledge Graph) — Advanced Relationships

```python
def get_memory_config(self):
    return MemoryConfig.graphiti_simple(
        use_falkordb=True,
        falkordb_host="localhost",
        falkordb_port=6379,
        passive_injection=True,
        auto_store_interactions=True
    )
```

#### Hybrid Mode — Best of Both

```python
def get_memory_config(self):
    return MemoryConfig.hybrid(
        memori_database_url="sqlite:///memory.db",
        graphiti_use_falkordb=True,
        graphiti_falkordb_host="localhost",
        passive_injection=True,
        auto_store_interactions=True
    )
```

### Active Tools vs Passive Injection

#### Passive Injection (Automatic)

When `passive_injection=True`, the system automatically retrieves relevant facts before each message and injects them into the system prompt.

```python
MemoryConfig.memori_simple(
    passive_injection=True,
    passive_injection_max_facts=10,
    passive_injection_min_confidence=0.5
)
```

#### Active Tools (Agent-Controlled)

When memory is enabled, the agent automatically gets these tools:

- `recall_memory(query)` — Search memory for relevant facts
- `store_memory(fact, fact_type)` — Explicitly store a fact
- `forget_memory(query)` — Create a forget directive

### Installation

```bash
uv add agent-framework-lib[memory]

# Or install providers separately
uv add agent-framework-lib[memori]    # SQL-native memory
uv add agent-framework-lib[graphiti]  # Knowledge graph memory
```

### Database Setup

**Memori (SQLite — No Setup Required):**
```python
database_url="sqlite:///memory.db"
```

**Memori (PostgreSQL):**
```bash
docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=password postgres:15
```
```python
database_url="postgresql://postgres:password@localhost/memory"
```

**Graphiti (FalkorDB):**
```bash
docker run -d -p 6379:6379 falkordb/falkordb:latest
```
```python
MemoryConfig.graphiti_simple(
    use_falkordb=True,
    falkordb_host="localhost",
    falkordb_port=6379
)
```

### Environment Variables

```env
MEMORY_PRIMARY_PROVIDER=memori
MEMORY_SECONDARY_PROVIDER=graphiti
MEMORY_PASSIVE_INJECTION=true
MEMORY_AUTO_STORE_INTERACTIONS=true
MEMORI_DATABASE_URL=sqlite:///memory.db
GRAPHITI_USE_FALKORDB=true
FALKORDB_HOST=localhost
FALKORDB_PORT=6379
```

### More Information

- **[Memory Installation Guide](MEMORY_INSTALLATION.md)** — Detailed setup instructions
- **[Memory Examples](../examples/)** — Working code examples
  - `agent_with_memory_simple.py` — Memori with SQLite
  - `agent_with_memory_graphiti.py` — Graphiti with FalkorDB
  - `agent_with_memory_hybrid.py` — Both providers

---

## Skills Integration

The Skills System provides a modular way to organize agent capabilities into on-demand packages. Instead of loading all instructions into the system prompt (~3000 tokens), skills deliver instructions on-demand via tool responses, significantly reducing token consumption.

### Overview

Skills bundle together:
- **Metadata**: Lightweight info for discovery (~50 tokens per skill)
- **Instructions**: Detailed usage instructions (loaded on-demand)
- **Tools**: Associated tool functions (auto-loaded at initialization)
- **Dependencies**: Other skills required

### Key Insight: Auto-Loading

**Skill tools are automatically loaded at agent initialization.** You don't need to override `get_agent_tools()` to use skills — they work out of the box.

- **Tools are cheap** (~50-100 tokens each) — loaded automatically at init
- **Instructions are expensive** (~500 tokens each) — loaded on-demand via `load_skill()`

### Token Optimization

```
BEFORE (Rich Content Prompt):
  System Prompt = Base (~500 tokens) + Rich Content (~3000 tokens)
  Total per message: ~3500 tokens

AFTER (Skills System):
  System Prompt = Base (~500 tokens) + Skills Discovery (~200 tokens)
  Total per message: ~700 tokens

  When agent needs chart capability:
  → Skill tools already available (auto-loaded at init)
  → Agent calls load_skill("chart") for detailed instructions
  → Tool returns instructions (~500 tokens, ONE TIME)
```

### Enabling Skills in Your Agent

Skills are automatically available in all agents that inherit from `LlamaIndexAgent` or `BaseAgent`. **No special configuration is needed.**

```python
from agent_framework import LlamaIndexAgent

class MySkillsAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="my_skills_agent",
            name="Skills Agent",
            description="An agent with on-demand skills."
        )

    def get_agent_prompt(self) -> str:
        return """You are a helpful assistant with access to a Skills System.

        Use list_skills() to see available skills.
        Use load_skill("skill_name") to get detailed instructions."""

    def get_agent_tools(self) -> list:
        return []
```

What happens automatically:
1. Built-in skills are registered at `BaseAgent.__init__`
2. Skill management tools (`list_skills`, `load_skill`, `unload_skill`) are added
3. All skill tools from registered skills are added to the agent
4. Skills discovery prompt is appended to your system prompt

### Built-in Skills

| Category | Skills | Description |
|----------|--------|-------------|
| **Visualization** | chart, mermaid, table | Chart.js charts, Mermaid diagrams, table images |
| **Document** | file, pdf, pdf_with_images, file_access | File operations, PDF generation |
| **Web** | web_search | Web and news search |
| **Multimodal** | multimodal | Image analysis |
| **UI** | form, optionsblock, image_display | Forms, option buttons, image display |

### Creating Custom Skills

```python
from agent_framework.skills import Skill, SkillMetadata

WEATHER_INSTRUCTIONS = """
## Weather Skill Instructions

Use the get_weather() tool to fetch current weather.

**Parameters:**
- city: City name (e.g., "Paris", "New York")
- units: "celsius" or "fahrenheit" (default: celsius)
"""

def create_weather_skill() -> Skill:
    def get_weather(city: str, units: str = "celsius") -> str:
        """Get current weather for a city."""
        return f"Weather in {city}: Sunny, 22°{units[0].upper()}"

    return Skill(
        metadata=SkillMetadata(
            name="weather",
            description="Get current weather for any city",
            trigger_patterns=["weather", "temperature", "forecast"],
            category="web",
            version="1.0.0"
        ),
        instructions=WEATHER_INSTRUCTIONS,
        tools=[get_weather],
        dependencies=[],
        config={}
    )

# Register in your agent
custom_skill = create_weather_skill()
self.register_skill(custom_skill)
```

### File Storage Integration

Skills that use file storage (chart, pdf, file, etc.) need context injection during session configuration:

```python
async def configure_session(self, session_configuration):
    user_id = session_configuration.get('user_id', 'default_user')
    session_id = session_configuration.get('session_id')

    await self._ensure_file_storage()
    await super().configure_session(session_configuration)

    self.configure_skill_tools_context(
        file_storage=self.file_storage,
        user_id=user_id,
        session_id=session_id
    )
```

Call `configure_skill_tools_context()` **after** `super().configure_session()` because that's when the skill tool instances are collected.

### Skills + Memory Combined Usage

Skills and Memory work together seamlessly. Both systems add their tools automatically at initialization:

**Tool Loading Order:**
1. Agent's custom tools (from `get_agent_tools()`)
2. Skill management tools (`list_skills`, `load_skill`, `unload_skill`)
3. All skill tools (chart, pdf, mermaid, etc.)
4. Memory tools (`recall_memory`, `store_memory`, `forget_memory`)

### Environment Variable Control

```bash
# Disable skills entirely (default: true)
ENABLE_SKILLS=false
```

### More Information

- **[Tools and MCP Guide](TOOLS_AND_MCP_GUIDE.md#converting-tools-to-skills)** — Converting tools to skills
- **[Skills Demo Example](../examples/skills_demo_agent.py)** — Comprehensive skills demonstration
- **[Multi-Skills Example](../examples/agent_example_multi_skills.py)** — Automatic skill tools loading

---

## Streaming Architecture

### Overview

The Agent Framework uses a clear separation of concerns for streaming:

```
┌─────────────────────────────────────────────────────────────┐
│  Your Agent Implementation                                  │
│                                                             │
│  run_agent(stream=True)                                     │
│    └─> Yields RAW framework-specific events                │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  BaseAgent.handle_message_stream() [FINAL - DO NOT OVERRIDE]│
│                                                             │
│  Orchestrates the streaming flow:                           │
│    1. Calls run_agent(stream=True)                          │
│    2. For each event, calls process_streaming_event()       │
│    3. Converts to StructuredAgentOutput                     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Your Agent Implementation                                  │
│                                                             │
│  process_streaming_event(event)                             │
│    └─> Converts framework event to unified format          │
└─────────────────────────────────────────────────────────────┘
```

### Key Principles

1. **`run_agent()`** = Framework-specific logic, yields RAW events
2. **`process_streaming_event()`** = Conversion layer, framework-specific
3. **`handle_message_stream()`** = Orchestration, framework-agnostic (**do not override**)

### Unified Event Format

```python
{
    "type": "chunk" | "tool_call" | "tool_result" | "activity" | "error",
    "content": str,
    "metadata": {...}
}
```

| Type | Description |
|------|-------------|
| `chunk` | Text content being streamed to the user |
| `tool_call` | Agent is calling a tool |
| `tool_result` | Result from a tool execution |
| `activity` | General activity message (e.g., "thinking", "processing") |
| `error` | Error occurred during processing |

### Implementation Examples

#### Non-Streaming Mode

```python
async def run_agent(self, query, ctx, stream=False):
    if not stream:
        response = await my_framework.chat(query, ctx)
        return response.text
```

#### Streaming Mode

```python
async def run_agent(self, query, ctx, stream=False):
    if stream:
        async def event_generator():
            async for event in my_framework.stream_chat(query, ctx):
                yield event
        return event_generator()
```

#### Event Conversion

```python
async def process_streaming_event(self, event):
    if event.type == "text_chunk":
        return {
            "type": "chunk",
            "content": event.text,
            "metadata": {"source": "my_framework"}
        }
    elif event.type == "tool_request":
        return {
            "type": "tool_call",
            "content": "",
            "metadata": {
                "tool_name": event.tool_name,
                "tool_arguments": event.arguments
            }
        }
    return None
```

---

## Tool Integration

### Basic Tools

Tools are Python functions with clear docstrings and type hints:

```python
def calculate_total(items: list[dict[str, float]]) -> float:
    """Calculate the total price of items.

    Args:
        items: List of items with 'price' and 'quantity' keys

    Returns:
        Total price
    """
    return sum(item['price'] * item['quantity'] for item in items)
```

### MCP Tools (Model Context Protocol)

Add external tools via MCP servers:

```python
def get_mcp_server_params(self) -> list:
    from autogen_ext.tools.mcp import StdioServerParams
    from agent_framework import get_deno_command

    return [
        StdioServerParams(
            command=get_deno_command(),
            args=['run', '-N', 'jsr:@pydantic/mcp-run-python', 'stdio'],
            read_timeout_seconds=120
        )
    ]
```

See [agent_with_mcp.py](../examples/agent_with_mcp.py) for a complete example.

---

## A2A Integration

The Agent Framework supports the Agent-to-Agent (A2A) protocol, enabling agents to communicate with each other via JSON-RPC.

### Enabling A2A

A2A is activated via environment variable:

```bash
A2A_ENABLED=true
```

When enabled, the framework automatically:
1. Registers A2A JSON-RPC endpoints at `/a2a`
2. Builds an Agent Card from your agent's metadata
3. Handles task lifecycle (`submitted` → `working` → `completed` / `failed` / `canceled`)

### No Code Changes Required

Your existing agent works with A2A without modification. The A2A translation layer converts JSON-RPC requests into standard `handle_message` / `handle_message_stream` calls.

### Supported JSON-RPC Methods

| Method | Description |
|--------|-------------|
| `message/send` | Send a message and get a response |
| `message/stream` | Send a message and stream the response via SSE |
| `tasks/get` | Get the status and result of a task |
| `agent/authenticatedExtendedCard` | Get the agent's capability card |

### Task Store Providers

A2A requires a task store to persist task state:

| Provider | Configuration |
|----------|---------------|
| Elasticsearch | `ELASTICSEARCH_ENABLED=true` |
| PostgreSQL | `A2A_TASK_STORE_PROVIDER=postgres`, `A2A_POSTGRES_DSN=postgresql://...` |

### More Information

- **[A2A Guide](A2A_GUIDE.md)** — Complete A2A protocol documentation
- **[Configuration Guide](configuration.md)** — A2A environment variables

---

## State Management and Agent Lifecycle

### `AgentManager` Workflow

The `AgentManager` orchestrates the full agent lifecycle:

```
1. get_agent(agent_class, session_id, user_id, ...)
   ├─ Creates agent instance
   ├─ Calls configure_session() with system prompt, model config
   ├─ Loads saved state via load_state()
   └─ Returns ready-to-use agent

2. Agent handles messages
   ├─ handle_message() for non-streaming
   └─ handle_message_stream() for streaming

3. save_agent_state(session_id, agent_instance)
   ├─ Calls get_state() on the agent
   └─ Persists to session storage
```

### State Persistence

```python
async def get_state(self) -> dict[str, Any]:
    """Save only necessary state."""
    state = await super().get_state()
    state['user_preferences'] = self.user_preferences
    return state
```

---

## Best Practices

### System Prompts

```python
def get_agent_prompt(self) -> str:
    return """You are a financial advisor assistant.

    Your capabilities:
    - Calculate investment returns
    - Analyze portfolio risk

    Your guidelines:
    - Always show calculations step-by-step
    - Provide disclaimers for investment advice
    """
```

### Tool Design

```python
def calculate_roi(
    initial_investment: float,
    final_value: float,
    years: int
) -> dict[str, float]:
    """Calculate return on investment with annualized rate.

    Args:
        initial_investment: Initial investment amount in dollars
        final_value: Final value in dollars
        years: Number of years invested

    Returns:
        Dictionary with 'total_return' and 'annualized_return'
    """
    total_return = ((final_value - initial_investment) / initial_investment) * 100
    annualized_return = ((final_value / initial_investment) ** (1/years) - 1) * 100
    return {
        "total_return": round(total_return, 2),
        "annualized_return": round(annualized_return, 2)
    }
```

### Error Handling

```python
def divide(a: float, b: float) -> float | str:
    """Divide a by b with error handling."""
    try:
        if b == 0:
            return "Error: Cannot divide by zero"
        return a / b
    except Exception as e:
        return f"Error: {str(e)}"
```

---

## Examples

### LlamaIndex Examples

- **[simple_agent.py](../examples/simple_agent.py)** — Basic calculator agent
- **[agent_with_file_storage.py](../examples/agent_with_file_storage.py)** — Agent with file upload/download
- **[agent_with_mcp.py](../examples/agent_with_mcp.py)** — Agent with MCP tools

### Memory Examples

- **[agent_with_memory_simple.py](../examples/agent_with_memory_simple.py)** — Memori with SQLite (simplest setup)
- **[agent_with_memory_graphiti.py](../examples/agent_with_memory_graphiti.py)** — Graphiti with FalkorDB
- **[agent_with_memory_hybrid.py](../examples/agent_with_memory_hybrid.py)** — Both providers combined

### BaseAgent Examples

- **[custom_framework_agent.py](../examples/custom_framework_agent.py)** — Complete custom framework integration

### Running Examples

```bash
# Install dependencies
uv add agent-framework-lib[llamaindex]

# Set API key
export OPENAI_API_KEY=your-key-here

# Run an example
uv run python examples/simple_agent.py

# Open browser to http://localhost:8100/testapp
```

---

## Next Steps

- **[Tools and MCP Guide](TOOLS_AND_MCP_GUIDE.md)** — Advanced tool integration
- **[API Reference](api-reference.md)** — Complete API documentation
- **[Architecture Diagram](ARCHITECTURE_DIAGRAM.md)** — System architecture details
- **[A2A Guide](A2A_GUIDE.md)** — Agent-to-Agent protocol
- **[Configuration Guide](configuration.md)** — Environment variables reference

---

**Need Help?**

- Review the [examples](../examples/) directory
- Check the [API Reference](api-reference.md)
- Open an issue on GitHub
