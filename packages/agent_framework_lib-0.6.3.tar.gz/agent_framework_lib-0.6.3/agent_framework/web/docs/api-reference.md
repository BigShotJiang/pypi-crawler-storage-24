# API Reference

## Table of Contents

- [Health Check](#health-check)
- [Authentication](#authentication)
- [Session Management](#session-management)
- [Messaging](#messaging)
- [File Storage](#file-storage)
- [Configuration Management](#configuration-management)
- [Display Configuration](#display-configuration)
- [Feedback](#feedback)
- [Agent Management](#agent-management)
- [Admin](#admin)
- [Admin Observability](#admin-observability)
- [A2A Protocol](#a2a-protocol)
- [Framework Helper Agent](#framework-helper-agent)
- [UI Endpoints](#ui-endpoints)
- [Error Responses](#error-responses)

## Health Check

### GET /health

Health check endpoint for Docker and Kubernetes probes. Does not require authentication.

**Response:**
```json
{
  "status": "healthy"
}
```

## Authentication

The Agent Framework supports multiple authentication methods:

### Authentication Methods

1. **Basic Authentication**: Username and password
2. **Bearer Token (API Key)**: API key in Authorization header
3. **X-API-Key Header**: API key in custom header

### Configuration

Authentication is controlled by environment variables:

- `REQUIRE_AUTH`: Set to `"true"` to enable authentication (default: `"false"`)
- `BASIC_AUTH_USERNAME`: Username for basic auth (default: `"admin"`)
- `BASIC_AUTH_PASSWORD`: Password for basic auth (default: `"password"`)
- `API_KEYS`: Comma-separated list of valid API keys

### Example Requests

**Basic Authentication:**
```bash
curl -u admin:password http://localhost:8000/metadata
```

**Bearer Token:**
```bash
curl -H "Authorization: Bearer your-api-key" http://localhost:8000/metadata
```

**X-API-Key Header:**
```bash
curl -H "X-API-Key: your-api-key" http://localhost:8000/metadata
```

## Session Management

### POST /init

Initialize a new session with configuration and optional data.

**Request Body:**
```json
{
  "user_id": "user123",
  "correlation_id": "optional-correlation-id",
  "session_id": "optional-session-id",
  "data": {
    "key": "value"
  },
  "configuration": {
    "system_prompt": "You are a helpful assistant for {{data.key}}",
    "model_name": "gpt-4o-mini",
    "temperature": 0.7,
    "enable_rich_content": true
  }
}
```

**Response:**
```json
{
  "user_id": "user123",
  "correlation_id": "optional-correlation-id",
  "session_id": "generated-or-provided-session-id",
  "data": {"key": "value"},
  "configuration": {
    "system_prompt": "You are a helpful assistant for value",
    "model_name": "gpt-4o-mini",
    "temperature": 0.7
  },
  "agent_id": "agent-unique-id",
  "agent_type": "AgentClassName"
}
```

**Features:**
- Template system prompts with data using `{{data.key}}` or `{{key}}` syntax
- Supports nested data access: `{{data.key.subkey}}`
- Auto-generates session_id if not provided
- Tracks agent identity for multi-agent scenarios

### POST /end

End a session by marking it as closed.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Request Body:**
```json
{
  "session_id": "session-id-to-close"
}
```

**Response:**
```json
{
  "message": "Session session-id-to-close has been successfully closed",
  "session_id": "session-id-to-close"
}
```

### GET /sessions

List all active session IDs for a user, filtered by current agent.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
["session-id-1", "session-id-2", "session-id-3"]
```

### GET /sessions/info

List all sessions with detailed information including labels and metadata.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")
- `agent_id`: Filter by specific agent ID (optional)
- `agent_type`: Filter by specific agent type (optional)

**Response:**
```json
[
  {
    "session_id": "session-id-1",
    "session_label": "Customer Support Chat",
    "created_at": "2024-01-01T10:00:00Z",
    "updated_at": "2024-01-01T10:30:00Z",
    "correlation_id": "correlation-123",
    "metadata": {},
    "agent_id": "agent-unique-id",
    "agent_type": "AgentClassName",
    "session_configuration": {},
    "agent_lifecycle": []
  }
]
```

### GET /sessions/info/{session_id}

Get detailed information for a specific session by its ID.

**Path Parameters:**
- `session_id`: Session identifier

**Response:**
Returns a single `SessionInfo` object with the same structure as the items in `GET /sessions/info`:

```json
{
  "session_id": "session-id-1",
  "session_label": "Customer Support Chat",
  "created_at": "2024-01-01T10:00:00Z",
  "updated_at": "2024-01-01T10:30:00Z",
  "correlation_id": "correlation-123",
  "metadata": {},
  "agent_id": "agent-unique-id",
  "agent_type": "AgentClassName",
  "session_configuration": {},
  "agent_lifecycle": []
}
```

### GET /sessions/{session_id}/history

Retrieve message history for a specific session.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
[
  {
    "role": "user",
    "text_content": "Hello",
    "parts": [],
    "response_text_main": null,
    "timestamp": "2024-01-01T10:00:00Z",
    "interaction_id": "interaction-uuid",
    "processing_time_ms": null,
    "processed_at": null,
    "model_used": null
  },
  {
    "role": "assistant",
    "text_content": null,
    "parts": [{"type": "text", "text": "Hi! How can I help you?"}],
    "response_text_main": "Hi! How can I help you?",
    "timestamp": "2024-01-01T10:00:01Z",
    "interaction_id": "interaction-uuid",
    "processing_time_ms": 1234.5,
    "processed_at": "2024-01-01T10:00:01Z",
    "model_used": "gpt-4o-mini"
  }
]
```

### PUT /session/{session_id}/label

Update the label of a session.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Request Body:**
```json
{
  "session_id": "session-id",
  "label": "My Custom Label"
}
```

**Response:**
Returns updated SessionInfo object.

### GET /session/{session_id}/status

Get the status of a session (active, closed, or not found).

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
{
  "session_id": "session-id",
  "user_id": "user123",
  "status": "active",
  "created_at": "2024-01-01T10:00:00Z",
  "updated_at": "2024-01-01T10:30:00Z",
  "closed_at": null
}
```

### GET /sessions/by-correlation/{correlation_id}

Retrieve all sessions across users that share a correlation ID.

**Response:**
```json
{
  "correlation_id": "correlation-123",
  "sessions": [
    {
      "session_id": "session-id-1",
      "user_id": "user123",
      "agent_id": "agent-id",
      "created_at": "2024-01-01T10:00:00Z"
    }
  ]
}
```

### GET /users

List all user IDs who have at least one session.

**Response:**
```json
["user1", "user2", "user3"]
```

## Messaging

### POST /message

Send a message to an agent and receive a response.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")
- `session_id`: Session identifier (optional, can be in body)

**Request Body:**
```json
{
  "query": "What is the weather today?",
  "parts": [
    {
      "type": "text",
      "text": "Additional context"
    },
    {
      "type": "image_url",
      "image_url": {
        "url": "https://example.com/image.jpg"
      }
    },
    {
      "type": "file_data",
      "filename": "document.pdf",
      "mime_type": "application/pdf",
      "content": "base64-encoded-content"
    }
  ],
  "session_id": "optional-session-id",
  "correlation_id": "optional-correlation-id",
  "model_preference": "auto"
}
```

**Model Preference:**
- `"auto"`: Let the system choose the best model based on query complexity (default)
- `"gpt-4o"`, `"claude-sonnet-4-20250514"`, etc.: Use a specific model

Use `GET /api/models` to get available models grouped by tier.

**Response:**
```json
{
  "response_text": "The weather today is sunny with a high of 75°F.",
  "parts": [
    {
      "type": "text",
      "text": "The weather today is sunny with a high of 75°F."
    }
  ],
  "session_id": "session-id",
  "user_id": "user123",
  "correlation_id": "optional-correlation-id",
  "interaction_id": "interaction-uuid",
  "processing_time_ms": 1234.5,
  "model_used": "gpt-4o-mini",
  "agent_id": "agent-unique-id",
  "agent_type": "AgentClassName",
  "agent_metadata": {}
}
```

**Features:**
- Supports multimodal inputs (text, images, files)
- Automatic file processing and markdown conversion
- Creates session if it doesn't exist
- Prevents messaging to closed sessions

### POST /stream

Stream agent responses in real-time using Server-Sent Events (SSE).

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")
- `session_id`: Session identifier (optional, can be in body)

**Request Body:**
Same as `/message` endpoint (includes `model_preference`).

**Response:**
Server-Sent Events stream with JSON data:

```
event: routing
data: {"model": "gpt-4o-mini", "tier": "light", "reason": "trivial_message", "fallback_used": false}

data: {"response_text": "The", "parts": [...], "session_id": "...", ...}

data: {"response_text": "The weather", "parts": [...], "session_id": "...", ...}

data: {"response_text": "The weather today", "parts": [...], "session_id": "...", ...}

data: {"status": "done", "session_id": "...", "interaction_id": "..."}
```

**SSE Event Types:**
- `routing`: Model routing information (only in auto mode)
  - `model`: Selected model name
  - `tier`: Model tier (light/standard/advanced)
  - `reason`: Why this model was selected (trivial_message, complexity_light, complexity_standard, complexity_advanced)
  - `fallback_used`: Whether a fallback model was used
- `data`: Response chunks and final status

**Features:**
- Real-time streaming responses
- Same multimodal support as `/message`
- Automatic state persistence
- Model routing events in auto mode
- Final "done" message when complete

### GET /sessions/{session_id}/response-times

Get response times for all agent responses in a session.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
{
  "session_id": "session-id",
  "user_id": "user123",
  "response_times": [
    {
      "interaction_id": "interaction-uuid",
      "response_time_ms": 1234.5,
      "user_message_timestamp": "2024-01-01T10:00:00Z",
      "agent_response_timestamp": "2024-01-01T10:00:01Z"
    }
  ],
  "total_responses": 1,
  "average_response_time_ms": 1234.5
}
```

**Note:** Only available with MongoDB storage backend. The storage must implement `get_response_times_for_session`.

### GET /interactions/{interaction_id}/response-time

Get response time for a specific interaction.

**Response:**
```json
{
  "interaction_id": "interaction-uuid",
  "response_time_ms": 1234.5,
  "user_message_timestamp": "2024-01-01T10:00:00Z",
  "agent_response_timestamp": "2024-01-01T10:00:01Z"
}
```

**Note:** Only available with MongoDB storage backend. The storage must implement `get_response_times_for_interaction`.

## File Storage

### POST /files/upload

Upload a file to storage.

**Query Parameters:**
- `user_id`: User identifier (required)
- `session_id`: Session identifier (optional)

**Request:**
Multipart form data with file upload.

**Response:**
```json
{
  "file_id": "generated-file-id",
  "filename": "document.pdf",
  "size_bytes": 12345,
  "mime_type": "application/pdf"
}
```

### GET /files/{file_id}/download

Download a file from storage. Requires authentication.

**Response:**
Binary file content with appropriate Content-Type and `Content-Disposition: attachment` headers.

### GET /files/{file_id}/view

View a file inline in the browser. Does not require authentication.

This endpoint is public (no auth required) to allow images to be displayed directly in chat via `<img>` tags. Security is provided by the UUID file_id which is hard to guess.

Unlike `/files/{file_id}/download` which forces a file download, this endpoint displays the file directly in the browser using `Content-Disposition: inline`.

**Use cases:**
- Displaying generated images (charts, diagrams) in chat
- Viewing PDFs inline
- Any file that should be displayed rather than downloaded

**Response:**
Binary file content with appropriate Content-Type and `Content-Disposition: inline` headers.

### GET /files/{file_id}/metadata

Get metadata for a file.

**Response:**
```json
{
  "file_id": "file-id",
  "filename": "document.pdf",
  "mime_type": "application/pdf",
  "size_bytes": 12345,
  "created_at": "2024-01-01T10:00:00Z",
  "updated_at": "2024-01-01T10:00:00Z",
  "user_id": "user123",
  "session_id": "session-id",
  "agent_id": "agent-id",
  "is_generated": false,
  "tags": ["document", "pdf"],
  "storage_backend": "local"
}
```

### GET /files/{file_id}/preview

Preview file content optimized for UI display.

**Response:**
```json
{
  "file_id": "file-id",
  "filename": "document.txt",
  "mime_type": "text/plain",
  "size_bytes": 1234,
  "preview_type": "text",
  "preview_available": true,
  "message": "Preview ready",
  "content": "File content here...",
  "metadata": {
    "created_at": "2024-01-01T10:00:00Z",
    "is_generated": false,
    "tags": [],
    "session_id": "session-id"
  }
}
```

**Preview Types:**
- `text`: Plain text files (includes `content` field)
- `json`: JSON files (includes formatted `content` field)
- `markdown`: Markdown files (includes `content` and `html_preview` fields)
- `image`: Image files (includes `content_base64` field)
- `binary`: Binary files (preview not available)

### GET /files

List files with filtering.

**Query Parameters:**
- `user_id`: User identifier (required)
- `session_id`: Filter by session (optional)
- `is_generated`: Filter by generated status (optional)

**Response:**
```json
[
  {
    "file_id": "file-id",
    "filename": "document.pdf",
    "mime_type": "application/pdf",
    "size_bytes": 12345,
    "created_at": "2024-01-01T10:00:00Z",
    "is_generated": false,
    "session_id": "session-id",
    "tags": []
  }
]
```

### DELETE /files/{file_id}

Delete a file from storage.

**Response:**
```json
{
  "success": true,
  "message": "File file-id deleted successfully"
}
```

### GET /files/stats

Get file storage system statistics.

**Response:**
```json
{
  "backends": {
    "local": {
      "type": "local",
      "enabled": true,
      "path": "/path/to/storage"
    },
    "s3": {
      "type": "s3",
      "enabled": false
    }
  },
  "default_backend": "local"
}
```

## Configuration Management

### GET /api/models

Get available models grouped by tier for model selection UI.

**Response:**
```json
{
  "models_by_tier": {
    "light": [
      {"id": "gpt-4o-mini", "name": "gpt-4o-mini", "provider": "openai", "available": true},
      {"id": "gemini-2.0-flash", "name": "gemini-2.0-flash", "provider": "gemini", "available": true}
    ],
    "standard": [
      {"id": "gpt-4o", "name": "gpt-4o", "provider": "openai", "available": true},
      {"id": "claude-sonnet-4-20250514", "name": "claude-sonnet-4-20250514", "provider": "anthropic", "available": false}
    ],
    "advanced": [
      {"id": "o1", "name": "o1", "provider": "openai", "available": true},
      {"id": "gemini-2.5-pro", "name": "gemini-2.5-pro", "provider": "gemini", "available": true}
    ]
  },
  "default_mode": "auto",
  "classifier_model": "gpt-4o-mini"
}
```

**Tier Descriptions:**
- 💨 `light`: Fast, economical models for simple queries
- ⚖️ `standard`: Balanced models for general use
- 🧠 `advanced`: Powerful models for complex reasoning

**Usage:**
Use this endpoint to populate a model selection dropdown in your UI. Pass the selected model ID (or "auto") as `model_preference` in `/message` or `/stream` requests.

### GET /config/models

Get model configuration information (legacy endpoint).

**Response:**
```json
{
  "default_model": "gpt-4o-mini",
  "configuration_status": {
    "openai_configured": true,
    "anthropic_configured": false,
    "gemini_configured": true
  },
  "supported_models": [
    "gpt-4o",
    "gpt-4o-mini",
    "gpt-4-turbo",
    "gemini-1.5-pro",
    "gemini-1.5-flash"
  ],
  "supported_providers": ["openai", "anthropic", "gemini"],
  "fallback_provider": "openai"
}
```

### GET /config/agents/{agent_id}

Get current effective configuration for an agent.

**Response:**
```json
{
  "agent_id": "agent-id",
  "config": {
    "system_prompt": "You are a helpful assistant",
    "model_name": "gpt-4o-mini",
    "model_config": {
      "temperature": 0.7,
      "max_tokens": 2000
    }
  },
  "version": 1,
  "updated_at": "2024-01-01T10:00:00Z",
  "source": "elasticsearch",
  "agent_type": "AgentClassName",
  "metadata": {},
  "active": true
}
```

**Configuration Sources:**
- `elasticsearch`: From Elasticsearch configuration storage
- `hardcoded`: From agent class implementation
- `default`: Default fallback configuration

### PUT /config/agents/{agent_id}

Update agent configuration in Elasticsearch.

**Request Body:**
```json
{
  "config": {
    "system_prompt": "Updated prompt",
    "model_name": "gpt-4o",
    "model_config": {
      "temperature": 0.8
    }
  },
  "agent_type": "AgentClassName",
  "updated_by": "admin",
  "metadata": {
    "reason": "Performance improvement"
  },
  "active": true
}
```

**Response:**
Returns updated configuration with new version number.

**Features:**
- Creates new version, deactivates old versions
- Invalidates cache automatically
- Returns HTTP 503 if Elasticsearch unavailable

### GET /config/agents/{agent_id}/versions

Get configuration version history for an agent.

**Query Parameters:**
- `limit`: Maximum versions to return (default: 10, max: 100)

**Response:**
```json
[
  {
    "agent_id": "agent-id",
    "agent_type": "AgentClassName",
    "version": 2,
    "updated_at": "2024-01-01T11:00:00Z",
    "updated_by": "admin",
    "config": {},
    "metadata": {},
    "active": true
  },
  {
    "agent_id": "agent-id",
    "agent_type": "AgentClassName",
    "version": 1,
    "updated_at": "2024-01-01T10:00:00Z",
    "updated_by": "system",
    "config": {},
    "metadata": {},
    "active": false
  }
]
```

### DELETE /config/agents/{agent_id}

Delete all configurations for an agent.

**Response:**
```json
{
  "success": true,
  "message": "All configurations for agent agent-id have been deleted",
  "agent_id": "agent-id",
  "fallback_behavior": "Agent will now use hardcoded or default configuration"
}
```

**Note:** After deletion, agent falls back to hardcoded or default configuration.

## Display Configuration

### GET /config/display

Get display configuration for steps, tools, and events. Returns merged configuration (defaults + agent overrides if `agent_id` provided).

**Query Parameters:**
- `agent_id`: Optional agent ID for agent-specific overrides

**Response:**
```json
{
  "steps": {
    "step_name": {
      "label": "Step Label",
      "icon": "icon-name",
      "color": "#hexcolor"
    }
  },
  "tools": {
    "tool_name": {
      "label": "Tool Label",
      "icon": "icon-name",
      "color": "#hexcolor"
    }
  },
  "events": {
    "event_name": {
      "label": "Event Label",
      "icon": "icon-name",
      "color": "#hexcolor"
    }
  },
  "agent_id": "agent-id-or-null"
}
```

### POST /config/display

Update display configuration overrides for an agent. Accepts partial overrides that are merged with defaults.

**Query Parameters:**
- `agent_id`: Agent ID for scoped overrides (required)

**Request Body:**
```json
{
  "steps": {
    "step_name": {
      "label": "Custom Label",
      "icon": "custom-icon",
      "color": "#custom-color"
    }
  },
  "tools": {},
  "events": {}
}
```

**Response:**
Returns the updated merged `DisplayConfigResponse` (same structure as `GET /config/display`).

## Feedback

### POST /feedback/message

Submit feedback for a specific message.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Request Body:**
```json
{
  "session_id": "session-id",
  "message_id": "interaction-uuid",
  "feedback": "up"
}
```

**Feedback Values:**
- `up`: Positive feedback
- `down`: Negative feedback

**Response:**
```json
{
  "status": "success",
  "message": "Feedback 'up' recorded for message interaction-uuid",
  "session_id": "session-id",
  "message_id": "interaction-uuid",
  "feedback": "up",
  "previous_feedback": null,
  "feedback_changed": true
}
```

**Features:**
- Validates session exists and is open
- Validates message exists in session
- Tracks feedback changes
- Prevents feedback on closed sessions

### POST /feedback/session

Submit session-level feedback.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Request Body:**
```json
{
  "session_id": "session-id",
  "feedback": "positive",
  "comment": "Great conversation!"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Session feedback recorded",
  "session_id": "session-id",
  "feedback": "positive"
}
```

### POST /feedback/flag
### PUT /feedback/flag

Submit or update session-level flag.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Request Body:**
```json
{
  "session_id": "session-id",
  "flag_message": "This session needs review"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Session flag created",
  "session_id": "session-id",
  "flag_message": "This session needs review",
  "previous_flag": null,
  "flag_changed": true
}
```

**Features:**
- Editable while session is open
- Tracks flag changes
- Prevents editing on closed sessions

### GET /feedback/session/{session_id}

Retrieve all feedback data for a session.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
{
  "session_id": "session-id",
  "user_id": "user123",
  "session_status": "active",
  "flag_message": "Needs review",
  "flag_timestamp": "2024-01-01T10:00:00Z",
  "message_feedback": {
    "interaction-uuid-1": "up",
    "interaction-uuid-1_timestamp": "2024-01-01T10:01:00Z",
    "interaction-uuid-2": "down",
    "interaction-uuid-2_timestamp": "2024-01-01T10:02:00Z"
  }
}
```

### GET /feedback/message/{message_id}

Retrieve feedback for a specific message.

**Query Parameters:**
- `session_id`: Session identifier (required)
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
{
  "message_id": "interaction-uuid",
  "session_id": "session-id",
  "user_id": "user123",
  "feedback": "up",
  "feedback_timestamp": "2024-01-01T10:01:00Z"
}
```

## Agent Management

### GET /metadata

Get agent metadata card.

**Response:**
```json
{
  "name": "Personal Assistant",
  "description": "A helpful AI assistant",
  "version": "1.0.0",
  "capabilities": ["chat", "file_processing"],
  "supported_models": ["gpt-4o", "gpt-4o-mini"]
}
```

### GET /system-prompt

Get agent's default system prompt.

**Response:**
```json
{
  "system_prompt": "You are a helpful AI assistant..."
}
```

**Note:** Returns 404 if no default system prompt is configured.

### GET /agents

List all agent types and their usage statistics.

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "agent_type": "AgentClassName",
      "session_count": 42,
      "user_count": 10,
      "last_used": "2024-01-01T10:00:00Z"
    }
  ]
}
```

### GET /agents/{agent_type}/sessions

Get sessions for a specific agent type.

**Query Parameters:**
- `user_id`: Filter by specific user (optional)

**Response:**
```json
{
  "success": true,
  "agent_type": "AgentClassName",
  "user_id": null,
  "session_count": 42,
  "sessions": ["session-id-1", "session-id-2"]
}
```

### GET /agents/{agent_id}/lifecycle

Get lifecycle events for a specific agent instance.

**Response:**
```json
{
  "success": true,
  "agent_id": "agent-unique-id",
  "event_count": 3,
  "events": [
    {
      "lifecycle_id": "lifecycle-uuid",
      "agent_id": "agent-unique-id",
      "agent_type": "AgentClassName",
      "event_type": "created",
      "session_id": "session-id",
      "user_id": "user123",
      "timestamp": "2024-01-01T10:00:00Z",
      "metadata": {}
    }
  ]
}
```

### GET /endpoints

List all available API endpoints.

**Response:**
```json
[
  {
    "path": "/message",
    "methods": ["POST"],
    "summary": "Handle incoming messages",
    "description": "Handles incoming messages using the session storage backend.",
    "parameters": [
      {
        "name": "user_id",
        "in": "query",
        "required": false,
        "type": "str"
      }
    ],
    "request_body": {
      "model": "MessageRequest",
      "required": true
    }
  }
]
```

## Admin

### POST /admin/authenticate

Validate admin password for accessing admin features.

**Request Body:**
```json
{
  "password": "admin-password"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Admin authentication successful"
}
```

**Note:** This is a secondary authentication layer on top of base auth.

### GET /api/admin/status

Get admin panel availability status. Does not require authentication.

**Response:**
```json
{
  "elasticsearch_available": true,
  "admin_enabled": true
}
```

### POST /api/admin/auth/verify

Verify admin password and return authentication token.

**Request Body:**
```json
{
  "password": "admin-password"
}
```

**Response:**
```json
{
  "success": true,
  "token": "admin-auth-token",
  "message": "Authentication successful"
}
```

### GET /api/admin/users

List all users with sessions (paginated).

**Query Parameters:**
- `search`: Optional search string for partial user_id matching
- `page`: Page number (1-indexed, default: 1)
- `page_size`: Number of users per page (default: 20, max: 100)

**Response:**
```json
{
  "users": [
    {
      "user_id": "user123",
      "session_count": 5,
      "last_activity": "2024-01-01T10:00:00Z"
    }
  ],
  "total": 100,
  "page": 1,
  "page_size": 20
}
```

**Note:** Requires Elasticsearch and admin authentication.

### GET /api/admin/users/{user_id}

Get KPIs for a specific user.

**Query Parameters:**
- `period`: Time period for KPIs ("day", "week", "month", default: "week")
- `agent_id`: Optional agent ID to filter KPIs

**Response:**
```json
{
  "user_id": "user123",
  "message_count": 42,
  "last_connection": "2024-01-01T10:00:00Z"
}
```

### GET /api/admin/users/{user_id}/sessions

Get all sessions for a specific user.

**Query Parameters:**
- `agent_id`: Optional agent ID to filter sessions

**Response:**
```json
[
  {
    "session_id": "session-id",
    "agent_id": "agent-id",
    "created_at": "2024-01-01T10:00:00Z",
    "updated_at": "2024-01-01T10:30:00Z",
    "message_count": 10
  }
]
```

### GET /api/admin/users/{user_id}/agents

Get list of unique agent IDs used by a specific user.

**Response:**
```json
["agent-id-1", "agent-id-2"]
```

### GET /api/admin/sessions/{session_id}/messages

Get all messages for a specific session (read-only admin view).

**Response:**
```json
[
  {
    "message_id": "msg-uuid",
    "session_id": "session-id",
    "user_id": "user123",
    "interaction_id": "interaction-uuid",
    "sequence_number": 1,
    "message_type": "user_input",
    "role": "user",
    "text_content": "Hello",
    "timestamp": "2024-01-01T10:00:00Z"
  }
]
```

### GET /api/admin/configs

List all agent configurations.

**Response:**
```json
[
  {
    "config_id": "config-doc-id",
    "agent_id": "agent-id",
    "agent_type": "AgentClassName",
    "version": 2,
    "last_updated": "2024-01-01T10:00:00Z",
    "active": true
  }
]
```

### GET /api/admin/configs/{config_id}

Get full details of a specific configuration.

**Response:**
```json
{
  "config_id": "config-doc-id",
  "agent_id": "agent-id",
  "agent_type": "AgentClassName",
  "version": 2,
  "config": {
    "system_prompt": "You are a helpful assistant",
    "model_name": "gpt-4o-mini"
  },
  "metadata": {},
  "active": true,
  "created_at": "2024-01-01T09:00:00Z",
  "updated_at": "2024-01-01T10:00:00Z"
}
```

## Admin Observability

These endpoints manage the Kibana integration for LLM metrics dashboards. They require Elasticsearch availability and admin authentication.

### GET /api/admin/observability/status

Check Kibana configuration and dashboard status.

**Response:**
```json
{
  "configured": true,
  "dashboard_exists": true,
  "dashboard_url": "https://kibana.example.com/app/dashboards#/view/dashboard-id",
  "error": null
}
```

**Fields:**
- `configured`: Whether Kibana connection is configured
- `dashboard_exists`: Whether the LLM metrics dashboard exists in Kibana
- `dashboard_url`: URL to the dashboard (if it exists)
- `error`: Error message if the status check failed

### POST /api/admin/observability/config

Save Kibana connection configuration. Tests connectivity before storing.

**Request Body:**
```json
{
  "url": "https://kibana.example.com",
  "auth_method": "basic",
  "username": "kibana_user",
  "password": "kibana_password",
  "api_key": null,
  "dashboard_name": "my-agent-metrics"
}
```

**Fields:**
- `url` (required): Kibana base URL
- `auth_method` (required): `"basic"` or `"apikey"`
- `username` / `password`: Required when `auth_method` is `"basic"`
- `api_key`: Required when `auth_method` is `"apikey"`
- `dashboard_name` (optional): Custom dashboard name, defaults to `{agent_name}-metrics`

**Response:**
```json
{
  "success": true,
  "message": "Kibana configuration saved successfully. Connected to https://kibana.example.com"
}
```

### POST /api/admin/observability/setup-dashboard

Create the LLM metrics dashboard in Kibana. Creates all TSVB visualizations and the dashboard with panel references.

**Response:**
```json
{
  "success": true,
  "dashboard_url": "https://kibana.example.com/app/dashboards#/view/dashboard-id",
  "visualizations_created": 8,
  "error": null,
  "details": [
    "Created visualization: LLM Response Time",
    "Created visualization: Token Usage",
    "Created dashboard: my-agent-metrics"
  ]
}
```

## A2A Protocol

The Agent-to-Agent (A2A) protocol enables inter-agent communication using JSON-RPC 2.0. These endpoints are only available when `A2A_ENABLED=true`.

See [A2A Guide](./A2A_GUIDE.md) for detailed architecture and usage documentation.

### GET /.well-known/agent.json

Return the A2A Agent Card, the standard discovery document for the agent. This follows the A2A protocol specification for agent discovery.

**Response:**
```json
{
  "name": "My Agent",
  "description": "A helpful AI assistant",
  "url": "https://my-agent.example.com/a2a",
  "version": "1.0.0",
  "protocolVersion": "1.0",
  "provider": {
    "organization": "My Organization",
    "url": "https://example.com"
  },
  "capabilities": {
    "streaming": true,
    "pushNotifications": false,
    "stateTransitionHistory": true
  },
  "defaultInputModes": ["text"],
  "defaultOutputModes": ["text"],
  "skills": [
    {
      "id": "general-chat",
      "name": "General Chat",
      "description": "General conversation capabilities",
      "tags": ["chat"],
      "examples": ["Hello, how are you?"]
    }
  ]
}
```

**Notes:**
- The `url` field is determined by (in priority order): the injected URL from `POST /a2a/config`, the `A2A_PUBLIC_URL` environment variable, or auto-detected from the request.
- The agent card is built dynamically from the agent instance metadata.

### POST /a2a

JSON-RPC 2.0 entry point for the A2A protocol. Dispatches incoming requests to the appropriate handler based on the `method` field.

**Supported JSON-RPC Methods:**

#### message/send

Send a message to the agent and receive a complete response.

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-1",
  "method": "message/send",
  "params": {
    "message": {
      "role": "user",
      "parts": [
        {"kind": "text", "text": "What is the weather today?"}
      ],
      "messageId": "msg-uuid"
    },
    "configuration": {
      "acceptedOutputModes": ["text"],
      "historyLength": 10,
      "blocking": true
    }
  }
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-1",
  "result": {
    "id": "task-uuid",
    "contextId": "context-uuid",
    "status": {
      "state": "completed",
      "timestamp": "2024-01-01T10:00:01Z",
      "message": {
        "role": "agent",
        "parts": [{"kind": "text", "text": "The weather today is sunny."}]
      }
    },
    "artifacts": [
      {
        "artifactId": "artifact-uuid",
        "name": "response",
        "parts": [{"kind": "text", "text": "The weather today is sunny."}]
      }
    ]
  }
}
```

#### message/stream

Send a message and receive a streaming response via Server-Sent Events (SSE).

**Request:** Same structure as `message/send`.

**Response:** SSE stream with `TaskStatusUpdateEvent` and `TaskArtifactUpdateEvent` events:

```
data: {"id": "task-uuid", "contextId": "ctx-uuid", "status": {"state": "working", "timestamp": "..."}}

data: {"id": "task-uuid", "contextId": "ctx-uuid", "artifact": {"artifactId": "art-uuid", "parts": [{"kind": "text", "text": "The"}], "append": false}}

data: {"id": "task-uuid", "contextId": "ctx-uuid", "artifact": {"artifactId": "art-uuid", "parts": [{"kind": "text", "text": " weather"}], "append": true}}

data: {"id": "task-uuid", "contextId": "ctx-uuid", "status": {"state": "completed", "timestamp": "..."}}
```

#### tasks/get

Retrieve the current state of a task by its ID.

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-2",
  "method": "tasks/get",
  "params": {
    "id": "task-uuid",
    "historyLength": 5
  }
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-2",
  "result": {
    "id": "task-uuid",
    "contextId": "context-uuid",
    "status": {
      "state": "completed",
      "timestamp": "2024-01-01T10:00:01Z"
    },
    "artifacts": [],
    "history": []
  }
}
```

**Task States:** `submitted`, `working`, `completed`, `failed`, `canceled`

#### agent/authenticatedExtendedCard

Retrieve the extended agent card with additional details available only to authenticated callers.

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-3",
  "method": "agent/authenticatedExtendedCard",
  "params": {}
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-3",
  "result": {
    "name": "My Agent",
    "description": "A helpful AI assistant",
    "url": "https://my-agent.example.com/a2a",
    "version": "1.0.0",
    "protocolVersion": "1.0",
    "capabilities": {
      "streaming": true,
      "pushNotifications": false,
      "stateTransitionHistory": true
    },
    "skills": []
  }
}
```

#### JSON-RPC Error Responses

When a method fails, the response contains an `error` object:

```json
{
  "jsonrpc": "2.0",
  "id": "req-1",
  "error": {
    "code": -32601,
    "message": "Method not found",
    "data": null
  }
}
```

**Standard Error Codes:**
- `-32700`: Parse error (invalid JSON)
- `-32600`: Invalid request (missing required fields)
- `-32601`: Method not found
- `-32602`: Invalid params
- `-32603`: Internal error

**A2A-Specific Error Codes:**
- `-32001`: Task not found
- `-32002`: Task not cancelable

### POST /a2a/config

Update the injected URL for the Agent Card. Protected by API key authentication.

**Request Body:**
```json
{
  "url": "https://my-public-agent.example.com"
}
```

**Response:**
```json
{
  "status": "ok",
  "url": "https://my-public-agent.example.com"
}
```

## Framework Helper Agent

The framework includes a built-in AI assistant accessible at `/helper` endpoints.

### GET /helper

Serve the Framework Helper Agent UI.

**Response:**
HTML page with helper agent chat interface.

### GET /helper/status

Get helper agent status and indexed knowledge.

**Response:**
```json
{
  "status": "ready",
  "indexed_files": {
    "documentation": 12,
    "examples": 13,
    "source": 31
  },
  "memory_status": {
    "graphiti_connected": false,
    "memori_connected": true
  }
}
```

### POST /helper/chat

Send a message to the Framework Helper Agent.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Request Body:**
```json
{
  "message": "How do I create an agent with memory?",
  "session_id": "optional-session-id"
}
```

**Response:**
```json
{
  "response": "To create an agent with memory, override the get_memory_config() method...",
  "session_id": "helper-session-id",
  "warnings": []
}
```

**Helper Agent Tools:**
- `search_docs(query)` - Search framework documentation
- `search_examples(query)` - Find example agent implementations
- `get_code_relationships(class_name)` - Query class relationships and dependencies
- `web_search(query)` - Search the web using DuckDuckGo (free, no API key)

**Indexed Knowledge:**
- Documentation: `docs/*.md` (12+ files)
- Examples: `examples/*.py` (13+ files)
- Source code: Core framework files (31+ files including tools, storage, memory, session)

### POST /helper/stream

Stream a response from the Framework Helper Agent using Server-Sent Events.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Request Body:**
```json
{
  "message": "Explain the agent lifecycle",
  "session_id": "optional-session-id"
}
```

**Response:**
Server-Sent Events stream with JSON data (same format as `/stream` endpoint):

```
data: {"response_text": "The", "parts": [...], "session_id": "...", ...}

data: {"response_text": "The agent", "parts": [...], "session_id": "...", ...}

data: {"status": "done", "session_id": "...", "interaction_id": "..."}
```

### GET /helper/sessions

List all sessions for the Framework Helper Agent.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
[
  {
    "session_id": "helper-session-id",
    "session_label": "Memory Configuration Help",
    "created_at": "2024-01-01T10:00:00Z",
    "updated_at": "2024-01-01T10:30:00Z",
    "agent_id": "framework_helper_v2",
    "agent_type": "FrameworkHelperAgent",
    "metadata": {}
  }
]
```

### GET /helper/sessions/{session_id}/history

Retrieve conversation history for a specific helper agent session.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
[
  {
    "role": "user",
    "text_content": "How do I add memory to my agent?",
    "timestamp": "2024-01-01T10:00:00Z",
    "interaction_id": "interaction-uuid"
  },
  {
    "role": "assistant",
    "text_content": "To add memory to your agent...",
    "timestamp": "2024-01-01T10:00:05Z",
    "interaction_id": "interaction-uuid"
  }
]
```

### DELETE /helper/sessions/{session_id}

Delete a helper agent session and all its messages.

**Query Parameters:**
- `user_id`: User identifier (default: "default_user")

**Response:**
```json
{
  "success": true,
  "message": "Session helper-session-id deleted"
}
```

### POST /helper/reindex

Re-index framework documentation into the knowledge base.

This admin endpoint triggers a full re-indexing of all documentation, examples, and source files. The knowledge is stored in FalkorDB (if available) and persists across server restarts.

**Response:**
```json
{
  "success": true,
  "indexed_docs": 12,
  "indexed_examples": 13,
  "indexed_source": 31,
  "total_indexed": 56,
  "message": "Successfully re-indexed 56 files"
}
```

**Notes:**
- At server startup, the helper checks if the knowledge graph already exists in FalkorDB
- If data exists, indexing is skipped for faster startup
- Use this endpoint to force re-indexing after updating documentation or examples
- Indexing includes rate-limit protection with automatic retry and backoff

## UI Endpoints

### GET /

Root endpoint with welcome message.

**Response:**
```json
{
  "message": "Agent server is running. Visit /docs for API documentation or /ui for a interface human friendly with agent."
}
```

### GET /ui

Serve the modern HTML UI application.

**Response:**
HTML page with modern UI interface.

### GET /testapp

Serve the HTML test application.

**Response:**
HTML page with test application interface.

### GET /documentation

Serve the README documentation as formatted HTML.

**Response:**
HTML page with formatted documentation including syntax highlighting.

### GET /docs

OpenAPI documentation (Swagger UI).

### GET /redoc

ReDoc API documentation.

### GET /favicon.ico

Returns the application favicon.

**Response:**
ICO file or 204 No Content if not available.

## Error Responses

All endpoints may return the following error responses:

### 400 Bad Request
```json
{
  "detail": "Error message describing what went wrong"
}
```

### 401 Unauthorized
```json
{
  "detail": "Authentication required. Use Basic Auth (username/password) or API Key (Bearer token or X-API-Key header)."
}
```

### 403 Forbidden
```json
{
  "detail": "Access denied to this resource"
}
```

### 404 Not Found
```json
{
  "detail": "Resource not found"
}
```

### 409 Conflict
```json
{
  "detail": "Resource already exists"
}
```

### 500 Internal Server Error
```json
{
  "detail": "Internal server error: error details"
}
```

### 503 Service Unavailable
```json
{
  "detail": "Service is unavailable (e.g., Elasticsearch down)"
}
```

## Rate Limiting

Currently, no rate limiting is implemented. Consider implementing rate limiting for production deployments.

## Versioning

The API does not currently use versioning. Breaking changes will be documented in the CHANGELOG.

## CORS

CORS is enabled for all origins (`*`) by default. Configure CORS middleware for production deployments.
