# Tools and MCP Integration Guide

This guide explains how to add tools and MCP (Model Context Protocol) servers to your agents, including the reusable tools architecture and the Skills system.

**Related Documentation:**
- [Creating Agents Guide](CREATING_AGENTS.md) - Complete guide to creating agents
- [Skills Integration](CREATING_AGENTS.md#skills-integration) - Skills system in agents

## Table of Contents

1. [Reusable Tools Architecture](#reusable-tools-architecture)
2. [Available Tools](#available-tools)
3. [Using Reusable Tools in Your Agent](#using-reusable-tools-in-your-agent)
4. [Creating Custom Tools](#creating-custom-tools)
5. [Adding Tools to LlamaIndex Agents](#adding-tools-to-llamaindex-agents)
6. [Adding Tools to BaseAgent (Custom Framework)](#adding-tools-to-baseagent-custom-framework)
7. [Adding MCP Servers to LlamaIndex Agents](#adding-mcp-servers-to-llamaindex-agents)
8. [Adding MCP Servers to BaseAgent](#adding-mcp-servers-to-baseagent)
9. [Dependency Management](#dependency-management)
10. [Troubleshooting](#troubleshooting)
11. [Tool Best Practices](#tool-best-practices)
12. [Converting Tools to Skills](#converting-tools-to-skills)

---

## Reusable Tools Architecture

The Agent Framework provides a reusable tools architecture built around the `AgentTool` base class.

### Overview

The architecture provides:

- **Dependency Injection**: Tools receive dependencies (file storage, user context) via `set_context()`
- **Error Handling**: Consistent error handling with `ToolDependencyError` for missing dependencies
- **Type Safety**: Properly typed callable functions with complete docstrings
- **Reusability**: Tools can be used across different agents without modification
- **Testability**: Tools can be tested independently of agents

### Key Concepts

**AgentTool Base Class**: All reusable tools inherit from `AgentTool` and implement `get_tool_function()`.

**Context Injection**: Tools receive runtime dependencies via `set_context()`, called by the agent during session configuration.

**Tool Functions**: Callable functions returned by `get_tool_function()` with complete docstrings and type hints.

### Architecture Pattern

```python
from agent_framework.tools import AgentTool

class MyTool(AgentTool):
    """Tool description for LLM."""
    
    def get_tool_function(self) -> Callable:
        """Return the tool function."""
        
        async def my_function(param: str) -> str:
            """Function docstring that LLM sees."""
            self._ensure_initialized()
            
            result = await self.file_storage.some_operation(
                user_id=self.current_user_id,
                session_id=self.current_session_id
            )
            return "Success message"
        
        return my_function
```

---

## Available Tools

The framework provides the following built-in tools, all exported from `agent_framework.tools`:

### Summary

| Category | Tool | Description |
|----------|------|-------------|
| **PDF (Recommended)** | `CreateUnifiedPDFTool` | Create PDFs from HTML with image embedding and adaptive sizing |
| **PDF (Legacy)** | `CreatePDFFromMarkdownTool` | Create PDFs from Markdown (deprecated) |
| **PDF (Legacy)** | `CreatePDFFromHTMLTool` | Create PDFs from HTML (deprecated) |
| **PDF (Legacy)** | `CreatePDFWithImagesTool` | Create PDFs with embedded images (deprecated) |
| **File Storage** | `CreateFileTool` | Create new text files |
| **File Storage** | `ListFilesTool` | List all files for user/session |
| **File Storage** | `ReadFileTool` | Read file content by ID |
| **File Access** | `GetFilePathTool` | Get file paths or presigned URLs |
| **Chart Generation** | `ChartToImageTool` | Convert Chart.js configs to PNG images |
| **Table Generation** | `TableToImageTool` | Convert table data to PNG images |
| **Diagram Generation** | `MermaidToImageTool` | Convert Mermaid diagrams to PNG images |
| **Web Search** | `WebSearchTool` | Search the web using DuckDuckGo (free) |
| **Web Search** | `WebNewsSearchTool` | Search news articles using DuckDuckGo News (free) |
| **Adaptive Sizing** | `ImageSizingConfig` | Configuration for image sizing parameters |
| **Adaptive Sizing** | `ImageDimensionCalculator` | Calculate optimal image dimensions |
| **Adaptive Sizing** | `PDFImageScaler` | Handle image scaling for PDF embedding |
| **Adaptive Sizing** | `AdaptivePDFCSS` / `PDFImageConfig` | Generate CSS for PDF image display |

**Base Classes:**
- `AgentTool` — Abstract base class for all tools
- `ToolDependencyError` — Exception for missing dependencies

**Availability Flag:**
- `PDF_TOOLS_AVAILABLE` — Boolean indicating if PDF tools are available (depends on system libraries)

### Unified PDF Tool (Recommended)

#### CreateUnifiedPDFTool

The recommended tool for all PDF generation. Replaces the legacy `CreatePDFFromMarkdownTool`, `CreatePDFFromHTMLTool`, and `CreatePDFWithImagesTool` with a single, consistent pipeline.

```python
from agent_framework.tools import CreateUnifiedPDFTool

tool = CreateUnifiedPDFTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
create_pdf = tool.get_tool_function()

result = await create_pdf(
    title="My Report",
    html_content="<h1>Report</h1><p>Content here...</p>",
    template_style="professional",
    image_size="large",
    author="John Doe"
)
```

**Parameters:**
- `title` (str): Document title (used for filename and header)
- `html_content` (str): HTML content (fragment or complete document)
- `template_style` (str): Style template — `"professional"`, `"minimal"`, or `"modern"` (default: `"professional"`)
- `image_size` (str): Image sizing preference — `"small"`, `"medium"`, `"large"`, or `"full"` (default: `"large"`)
- `author` (str, optional): Author name

**Features:**
- Multiple template styles (professional, minimal, modern)
- Automatic image embedding from file storage via `file_id:UUID` syntax in `<img>` tags
- Adaptive image sizing with size preferences
- Automatic downsampling of large images (>4000px)
- Consistent CSS rendering across all generated PDFs

**Image Embedding:**
```html
<img src="file_id:YOUR_FILE_ID" alt="Description">
```

The tool automatically detects `file_id:` references, retrieves files from storage, converts them to base64 data URIs, and embeds them in the PDF.

**Returns:** Success message with download link, or error message

**Custom Sizing Configuration:**
```python
from agent_framework.tools import CreateUnifiedPDFTool, ImageSizingConfig

config = ImageSizingConfig()
tool = CreateUnifiedPDFTool(config=config)
```

### Legacy PDF Tools (Deprecated)

> **Note:** These tools are deprecated. Use `CreateUnifiedPDFTool` instead for consistent PDF rendering.

#### CreatePDFFromMarkdownTool

Create PDF documents from Markdown content with multiple template styles.

```python
from agent_framework.tools import CreatePDFFromMarkdownTool

tool = CreatePDFFromMarkdownTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
create_pdf = tool.get_tool_function()

result = await create_pdf(
    title="My Report",
    content="# Introduction\n\nThis is **bold** text...",
    template_style="professional",
    author="John Doe"
)
```

**Parameters:**
- `title` (str): Document title
- `content` (str): Markdown formatted content
- `author` (str, optional): Author name
- `template_style` (str): `"professional"`, `"minimal"`, or `"modern"` (default: `"professional"`)

#### CreatePDFFromHTMLTool

Create PDF documents from HTML content with optional custom CSS.

```python
from agent_framework.tools import CreatePDFFromHTMLTool

tool = CreatePDFFromHTMLTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
create_pdf_html = tool.get_tool_function()

result = await create_pdf_html(
    title="Custom Report",
    html_content="<h1>Hello</h1><p>This is a paragraph.</p>",
    custom_css="h1 { color: red; }",
    author="Jane Doe"
)
```

**Parameters:**
- `title` (str): Document title
- `html_content` (str): Full HTML document or HTML fragment
- `custom_css` (str, optional): Additional CSS to apply
- `author` (str, optional): Author name

#### CreatePDFWithImagesTool

Create PDF documents from HTML with automatic image embedding from file storage.

```python
from agent_framework.tools import CreatePDFWithImagesTool

tool = CreatePDFWithImagesTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
create_pdf_with_images = tool.get_tool_function()

html_content = '''
<h1>Sales Report</h1>
<img src="file_id:xyz-789" alt="Weekly Sales Chart">
'''

result = await create_pdf_with_images(
    title="Sales Report",
    html_content=html_content,
    author="Sales Team"
)
```

**Parameters:**
- `title` (str): Document title
- `html_content` (str): HTML content with `file_id:` syntax in img tags
- `author` (str, optional): Author name

### File Storage Tools

Tools for managing files in the file storage system.

#### CreateFileTool

Create new text files with specified content.

```python
from agent_framework.tools import CreateFileTool

tool = CreateFileTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
create_file = tool.get_tool_function()

result = await create_file("report.txt", "This is my report content...")
```

**Parameters:**
- `filename` (str): Name for the new file
- `content` (str): Text content to write

**Returns:** Success message with file ID or error message

#### ListFilesTool

List all files for the current user and session.

```python
from agent_framework.tools import ListFilesTool

tool = ListFilesTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
list_files = tool.get_tool_function()

result = await list_files()
```

**Parameters:** None

**Returns:** Formatted list of files with IDs and sizes

#### ReadFileTool

Read file content by file ID.

```python
from agent_framework.tools import ReadFileTool

tool = ReadFileTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
read_file = tool.get_tool_function()

result = await read_file("abc-123")
```

**Parameters:**
- `file_id` (str): Unique identifier of the file to read

**Returns:** Formatted string with filename and content

### File Access Tools

#### GetFilePathTool

Get an accessible path or presigned URL for a stored file.

```python
from agent_framework.tools import GetFilePathTool

tool = GetFilePathTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
get_path = tool.get_tool_function()

result = await get_path("abc-123")
```

**Parameters:**
- `file_id` (str): The file ID returned from file storage operations

**Returns:**
- For local storage: Absolute file path with `file://` protocol
- For S3/MinIO: Presigned URL for direct access

### Chart Generation Tools

Tools for creating chart visualizations and saving them as images.

> **Note:** Chart tools require Playwright. See [Dependency Management](#dependency-management).

#### ChartToImageTool

Convert Chart.js configurations to PNG images.

```python
from agent_framework.tools import ChartToImageTool

tool = ChartToImageTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
save_chart = tool.get_tool_function()

chart_config = '''
{
    "type": "bar",
    "data": {
        "labels": ["Mon", "Tue", "Wed", "Thu", "Fri"],
        "datasets": [{
            "label": "Sales",
            "data": [120, 150, 100, 180, 200],
            "backgroundColor": "rgba(54, 162, 235, 0.6)"
        }]
    }
}
'''

result = await save_chart(
    chart_config=chart_config,
    filename="weekly_sales",
    width=800,
    height=600,
    background_color="white"
)
```

**Parameters:**
- `chart_config` (str): JSON string with Chart.js configuration
- `filename` (str): Output PNG filename (without extension)
- `width` (int, optional): Width in pixels (default: 800)
- `height` (int, optional): Height in pixels (default: 600)
- `background_color` (str, optional): Background color (default: `"white"`)

**Supported Chart Types:** bar, line, pie, doughnut, radar, polarArea, bubble, scatter

#### TableToImageTool

Convert table data to PNG images with styled HTML rendering.

```python
from agent_framework.tools import TableToImageTool

tool = TableToImageTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
save_table = tool.get_tool_function()

table_data = [
    ["Product", "Q1", "Q2", "Q3", "Q4"],
    ["Widget A", "120", "150", "180", "200"],
    ["Widget B", "90", "110", "130", "140"],
]

result = await save_table(
    table_data=table_data,
    filename="quarterly_sales",
    width=800,
    height=400
)
```

**Parameters:**
- `table_data` (list): Table data as list of lists or list of dictionaries
- `filename` (str): Output PNG filename (without extension)
- `width` (int, optional): Width in pixels (default: 800)
- `height` (int, optional): Height in pixels (default: 600)

**Supported Data Formats:**
- **List of lists**: First row is treated as headers
- **List of dictionaries**: Dictionary keys become headers

#### MermaidToImageTool

Convert Mermaid diagram syntax to PNG images.

```python
from agent_framework.tools import MermaidToImageTool

tool = MermaidToImageTool()
tool.set_context(file_storage=storage, user_id="user123", session_id="session456")
save_diagram = tool.get_tool_function()

mermaid_code = '''
graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Process 1]
    B -->|No| D[Process 2]
    C --> E[End]
    D --> E
'''

result = await save_diagram(
    mermaid_code=mermaid_code,
    filename="workflow_diagram",
    width=1000,
    height=800,
    background_color="white"
)
```

**Parameters:**
- `mermaid_code` (str): Mermaid diagram syntax
- `filename` (str): Output PNG filename (without extension)
- `width` (int, optional): Width in pixels (default: 1200)
- `height` (int, optional): Height in pixels (default: 800)
- `background_color` (str, optional): Background color (default: `"white"`)

**Supported Diagram Types:** flowcharts, sequence diagrams, class diagrams, state diagrams, ER diagrams, Gantt charts, pie charts, git graphs

### Web Search Tools

Tools for searching the web using DuckDuckGo. No API key required.

> **Note:** Requires the `ddgs` package. Install with: `uv add ddgs` or `uv add agent-framework-lib[websearch]`

#### WebSearchTool

Search the web for information using DuckDuckGo.

```python
from agent_framework.tools import WebSearchTool

tool = WebSearchTool(max_results=5)
web_search = tool.get_tool_function()

result = web_search("Python async best practices")
```

**Constructor Parameters:**
- `max_results` (int): Default maximum number of results (default: 5)

**Function Parameters:**
- `query` (str): The search query to look up
- `max_results` (int | None, optional): Override max results per call (max: 10)

**Returns:** Formatted search results with titles, snippets, and URLs

> **Note:** Web search tools don't require file storage or user context — no need to call `set_context()`.

#### WebNewsSearchTool

Search for recent news articles using DuckDuckGo News.

```python
from agent_framework.tools import WebNewsSearchTool

tool = WebNewsSearchTool(max_results=5)
news_search = tool.get_tool_function()

result = news_search("AI developments")
```

**Constructor Parameters:**
- `max_results` (int): Default maximum number of results (default: 5)

**Function Parameters:**
- `query` (str): The news topic to search for
- `max_results` (int | None, optional): Override max results per call (max: 10)

**Returns:** Formatted news results with titles, dates, sources, and URLs

**Usage in an agent (no `set_context()` needed):**

```python
from agent_framework.implementations import LlamaIndexAgent
from agent_framework.tools import WebSearchTool, WebNewsSearchTool

class MyAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(...)
        self.web_search = WebSearchTool()
        self.news_search = WebNewsSearchTool()
    
    def get_agent_tools(self):
        return [
            self.web_search.get_tool_function(),
            self.news_search.get_tool_function(),
        ]
```

### Adaptive Image Sizing

The framework includes an adaptive image sizing system that calculates optimal dimensions for generated images (charts, diagrams, tables) and handles their integration into PDF documents.

```python
from agent_framework.tools import ImageSizingConfig, ImageDimensionCalculator

config = ImageSizingConfig()
calculator = ImageDimensionCalculator(config)

# Calculate optimal chart dimensions for 15 data points
width, height = calculator.calculate_chart_dimensions(data_point_count=15)

# Calculate optimal table dimensions
width, height = calculator.calculate_table_dimensions(rows=10, cols=5)

# Calculate optimal Mermaid diagram dimensions
width, height = calculator.calculate_mermaid_dimensions(mermaid_code="graph TD\n  A-->B")
```

**Components:**
- `ImageSizingConfig` — Configuration dataclass for all sizing parameters (page dimensions, min/max sizes, DPI)
- `ImageDimensionCalculator` — Calculates optimal dimensions based on content type and data volume
- `PDFImageScaler` — Handles image scaling for PDF embedding with proper aspect ratio
- `AdaptivePDFCSS` / `PDFImageConfig` — Generates CSS for proper image display in PDFs

---

## Using Reusable Tools in Your Agent

Complete example of using reusable tools in a LlamaIndex agent:

```python
from agent_framework.implementations import LlamaIndexAgent
from agent_framework.storage.file_system_management import FileStorageFactory
from agent_framework.tools import (
    CreateFileTool,
    ListFilesTool,
    ReadFileTool,
    CreateUnifiedPDFTool,
    ChartToImageTool,
    WebSearchTool,
)

class MyAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="my_agent_v1",
            name="My Agent",
            description="A helpful assistant with file storage and PDF generation."
        )
        self.file_storage = None
        self.current_user_id = "default_user"
        self.current_session_id = None
        
        self.tools = [
            CreateFileTool(),
            ListFilesTool(),
            ReadFileTool(),
            CreateUnifiedPDFTool(),
            ChartToImageTool(),
            WebSearchTool(),
        ]
    
    async def configure_session(self, session_configuration):
        self.current_user_id = session_configuration.get('user_id', 'default_user')
        self.current_session_id = session_configuration.get('session_id')
        
        if self.file_storage is None:
            self.file_storage = await FileStorageFactory.create_storage_manager()
        
        for tool in self.tools:
            tool.set_context(
                file_storage=self.file_storage,
                user_id=self.current_user_id,
                session_id=self.current_session_id
            )
        
        await super().configure_session(session_configuration)
    
    def get_agent_tools(self):
        return [tool.get_tool_function() for tool in self.tools]
    
    def get_agent_prompt(self):
        return "You are a helpful assistant with file and PDF capabilities."
```

### Key Steps

1. **Import Tools**: Import tool classes from `agent_framework.tools`
2. **Initialize Tools**: Create tool instances in `__init__()` and store them in a list
3. **Inject Context**: In `configure_session()`, call `set_context()` on each tool
4. **Return Functions**: In `get_agent_tools()`, return callables via `get_tool_function()`

---

## Creating Custom Tools

You can create your own reusable tools by inheriting from `AgentTool`.

### Basic Custom Tool

```python
from agent_framework.tools import AgentTool, ToolDependencyError
from typing import Callable

class MyCustomTool(AgentTool):
    """Tool for doing something custom."""
    
    def get_tool_function(self) -> Callable:
        async def my_custom_function(param1: str, param2: int) -> str:
            """
            Do something custom with the parameters.
            
            Args:
                param1: Description of first parameter
                param2: Description of second parameter
            
            Returns:
                Success message or error
            """
            self._ensure_initialized()
            
            if not param1:
                return "Error: param1 cannot be empty"
            
            if not self.file_storage:
                raise ToolDependencyError(
                    "File storage is required but not available"
                )
            
            try:
                file_id = await self.file_storage.store_file(
                    content=f"Processed {param1} with {param2}".encode('utf-8'),
                    filename=f"{param1}.txt",
                    user_id=self.current_user_id,
                    session_id=self.current_session_id
                )
                return f"Success! File ID: {file_id}"
            except Exception as e:
                return f"Error: {str(e)}"
        
        return my_custom_function
```

### Custom Tool Without File Storage

```python
class SimpleTool(AgentTool):
    """A simple tool that doesn't need file storage."""
    
    def get_tool_function(self) -> Callable:
        async def simple_function(text: str) -> str:
            """Process text without file storage."""
            return text.upper()
        
        return simple_function
    
    def get_tool_info(self):
        info = super().get_tool_info()
        info['requires_file_storage'] = False
        return info
```

### Custom Tool with External APIs

```python
import aiohttp
from agent_framework.tools import AgentTool

class WeatherTool(AgentTool):
    """Tool for fetching weather information."""
    
    def __init__(self, api_key: str):
        super().__init__()
        self.api_key = api_key
    
    def get_tool_function(self) -> Callable:
        async def get_weather(city: str) -> str:
            """
            Get current weather for a city.
            
            Args:
                city: City name
            
            Returns:
                Weather information or error
            """
            try:
                async with aiohttp.ClientSession() as session:
                    url = f"https://api.weather.com/v1/current?city={city}&key={self.api_key}"
                    async with session.get(url) as response:
                        data = await response.json()
                        return f"Weather in {city}: {data['temp']}°F, {data['conditions']}"
            except Exception as e:
                return f"Error fetching weather: {str(e)}"
        
        return get_weather
    
    def get_tool_info(self):
        info = super().get_tool_info()
        info['requires_file_storage'] = False
        info['requires_user_context'] = False
        return info
```

### Best Practices for Custom Tools

1. **Clear Docstrings**: Write detailed docstrings for the LLM to understand
2. **Type Hints**: Use type hints for all parameters and return values
3. **Error Handling**: Catch exceptions and return user-friendly error messages
4. **Validation**: Validate inputs before processing
5. **Async**: Use `async def` for I/O operations

---

## Adding Tools to LlamaIndex Agents

For a complete guide on creating LlamaIndex agents, see [CREATING_AGENTS.md](CREATING_AGENTS.md).

### Automatic FunctionTool Conversion

LlamaIndexAgent automatically converts Python functions to LlamaIndex `FunctionTool` instances:
- Function name → tool name
- Docstring → tool description
- Type hints → parameter schema

```python
from agent_framework.implementations import LlamaIndexAgent

class MyAgent(LlamaIndexAgent):
    def get_agent_tools(self) -> list[callable]:
        def add(a: int, b: int) -> int:
            """Add two numbers together."""
            return a + b
        
        def get_weather(city: str) -> str:
            """Get the current weather for a city."""
            return f"Weather in {city}: Sunny, 72°F"
        
        return [add, get_weather]
```

> **Note:** You can still use `FunctionTool.from_defaults()` for more control, but it's no longer required.

### Async Tools

LlamaIndex supports async tools natively:

```python
def get_agent_tools(self) -> list[callable]:
    async def fetch_data(url: str) -> str:
        """Fetch data from a URL."""
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                return await response.text()
    
    return [fetch_data]
```

### Tools with Session Context

```python
class MyAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__()
        self.current_user_id = "default_user"
    
    async def configure_session(self, session_configuration):
        self.current_user_id = session_configuration.get('user_id', 'default_user')
        self.current_session_id = session_configuration.get('session_id')
        await super().configure_session(session_configuration)
    
    def get_agent_tools(self) -> list[callable]:
        def get_user_info() -> str:
            """Get information about the current user."""
            return f"User: {self.current_user_id}, Session: {self.current_session_id}"
        
        return [get_user_info]
```

---

## Adding Tools to BaseAgent (Custom Framework)

For a complete guide on creating BaseAgent implementations, see [CREATING_AGENTS.md](CREATING_AGENTS.md).

### Basic Tool Integration

```python
from agent_framework.core.base_agent import BaseAgent

class MyCustomAgent(BaseAgent):
    def get_agent_tools(self) -> list[callable]:
        def calculate(expression: str) -> float:
            """Evaluate a mathematical expression."""
            return eval(expression)
        
        return [calculate]
    
    async def run_agent(self, query: str, ctx, stream: bool = False):
        """You handle tool calling in your framework."""
        pass
```

### Tool Execution Pattern

```python
async def run_agent(self, query: str, ctx, stream: bool = False):
    messages = [
        {"role": "system", "content": self._system_prompt},
        {"role": "user", "content": query}
    ]
    
    max_iterations = 5
    for iteration in range(max_iterations):
        response = await self._llm_client.create(
            messages=messages,
            tools=self._get_tool_schemas()
        )
        
        message = response.choices[0].message
        
        if hasattr(message, 'tool_calls') and message.tool_calls:
            for tool_call in message.tool_calls:
                tool_name = tool_call.function.name
                tool_args = json.loads(tool_call.function.arguments)
                
                if tool_name in self._tools:
                    result = self._tools[tool_name](**tool_args)
                    
                    messages.append({
                        "role": "assistant",
                        "tool_calls": [tool_call]
                    })
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": str(result)
                    })
            continue
        
        return message.content
    
    return "Max iterations reached"
```

---

## Adding MCP Servers to LlamaIndex Agents

### What is MCP?

MCP (Model Context Protocol) allows agents to connect to external tool servers, enabling file system operations, database access, API integrations, and custom tool servers.

### Important: Memory Tools Are Added Automatically

When you define `get_memory_config()` in your agent, the framework automatically adds memory tools (`recall_memory`, `store_memory`, `forget_memory`). These are combined with your tools in `_get_all_tools()`.

**⚠️ If you override `initialize_agent()`**, use the `tools` parameter (which already contains memory tools) instead of calling `get_agent_tools()` directly:

```python
# ❌ WRONG - loses memory tools
async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
    all_tools = self.get_agent_tools()
    await super().initialize_agent(model_name, system_prompt, all_tools, **kwargs)

# ✅ CORRECT - preserves memory tools
async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
    all_tools = list(tools) + self.mcp_tools
    await super().initialize_agent(model_name, system_prompt, all_tools, **kwargs)
```

### Basic MCP Integration

```python
from agent_framework.implementations import LlamaIndexAgent

class MyMCPAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__()
        self.mcp_tools = []
        self._mcp_initialized = False
    
    async def _initialize_mcp_tools(self):
        if self._mcp_initialized:
            return
        
        try:
            from llama_index.tools.mcp import BasicMCPClient, McpToolSpec
        except ImportError:
            print("Install: uv add llama-index-tools-mcp")
            return
        
        client = BasicMCPClient(
            command="uvx",
            args=["@modelcontextprotocol/server-filesystem", "/path/to/workspace"],
            env={}
        )
        
        mcp_tool_spec = McpToolSpec(client=client)
        function_tools = await mcp_tool_spec.to_tool_list_async()
        self.mcp_tools.extend(function_tools)
        self._mcp_initialized = True
    
    def get_agent_tools(self) -> list[callable]:
        def greet(name: str) -> str:
            """Greet a user."""
            return f"Hello, {name}!"
        return [greet]
    
    async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
        await self._initialize_mcp_tools()
        all_tools = list(tools) + self.mcp_tools
        await super().initialize_agent(model_name, system_prompt, all_tools, **kwargs)
```

### Multiple MCP Servers

```python
async def _initialize_mcp_tools(self):
    from llama_index.tools.mcp import BasicMCPClient, McpToolSpec
    
    fs_client = BasicMCPClient(
        command="uvx",
        args=["@modelcontextprotocol/server-filesystem", "/workspace"]
    )
    fs_tools = await McpToolSpec(client=fs_client).to_tool_list_async()
    self.mcp_tools.extend(fs_tools)
    
    gh_client = BasicMCPClient(
        command="uvx",
        args=["@modelcontextprotocol/server-github"],
        env={"GITHUB_TOKEN": os.getenv("GITHUB_TOKEN")}
    )
    gh_tools = await McpToolSpec(client=gh_client).to_tool_list_async()
    self.mcp_tools.extend(gh_tools)
    
    db_client = BasicMCPClient(
        command="uvx",
        args=["@modelcontextprotocol/server-postgres"],
        env={"DATABASE_URL": os.getenv("DATABASE_URL")}
    )
    db_tools = await McpToolSpec(client=db_client).to_tool_list_async()
    self.mcp_tools.extend(db_tools)
```

### MCP Server Configuration

Common MCP servers and their configurations:

```python
# Filesystem access
{"command": "uvx", "args": ["@modelcontextprotocol/server-filesystem", "/path/to/workspace"]}

# GitHub integration
{"command": "uvx", "args": ["@modelcontextprotocol/server-github"], "env": {"GITHUB_TOKEN": "your-token"}}

# PostgreSQL database
{"command": "uvx", "args": ["@modelcontextprotocol/server-postgres"], "env": {"DATABASE_URL": "postgresql://..."}}

# Web fetch/scraping
{"command": "uvx", "args": ["@modelcontextprotocol/server-fetch"]}

# Custom Python MCP server
{"command": "uv", "args": ["run", "python", "-m", "my_mcp_server"], "env": {"API_KEY": "your-key"}}
```

---

## Adding MCP Servers to BaseAgent

For BaseAgent, you handle MCP tool loading and execution manually:

```python
from agent_framework.core.base_agent import BaseAgent

class MyCustomMCPAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.mcp_tools = []
        self._mcp_clients = {}
    
    async def _initialize_mcp_tools(self):
        try:
            from llama_index.tools.mcp import BasicMCPClient, McpToolSpec
        except ImportError:
            print("Install: uv add llama-index-tools-mcp")
            return
        
        client = BasicMCPClient(
            command="uvx",
            args=["@modelcontextprotocol/server-filesystem", "/workspace"]
        )
        self._mcp_clients["filesystem"] = client
        
        mcp_tool_spec = McpToolSpec(client=client)
        function_tools = await mcp_tool_spec.to_tool_list_async()
        self.mcp_tools.extend(function_tools)
    
    def get_agent_tools(self) -> list[callable]:
        built_in_tools = [...]
        return built_in_tools + self.mcp_tools
    
    async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
        await self._initialize_mcp_tools()
        all_tools = self.get_agent_tools()
        # Initialize your framework with all tools
```

---

## Dependency Management

### Core Dependencies

```bash
# Install base framework
uv add agent-framework-lib

# With LlamaIndex support
uv add agent-framework-lib[llamaindex]
```

**Core dependencies** (always installed): `aiofiles`, `pydantic`

### Chart Generation Dependencies

Chart generation tools require Playwright for browser automation.

```bash
# Install Playwright
uv add playwright

# Install browser binaries (Chromium) — one-time setup (~100MB)
playwright install chromium
```

### PDF Generation Dependencies

PDF generation tools require additional Python packages and system libraries.

**Python Packages:**
```bash
uv add weasyprint>=60.0 markdown>=3.5
```

**System Dependencies (WeasyPrint):**

macOS:
```bash
brew install pango gdk-pixbuf libffi
export DYLD_LIBRARY_PATH="/opt/homebrew/lib:$DYLD_LIBRARY_PATH"
```

Ubuntu/Debian:
```bash
sudo apt-get install libpango-1.0-0 libpangoft2-1.0-0 libgdk-pixbuf2.0-0 libffi-dev
```

Fedora/RHEL:
```bash
sudo dnf install pango gdk-pixbuf2 libffi-devel
```

### Web Search Dependencies

```bash
uv add ddgs
# or
uv add agent-framework-lib[websearch]
```

### MCP Dependencies

```bash
uv add llama-index-tools-mcp
```

### Optional Dependencies

```bash
uv add agent-framework-lib[mongodb]       # MongoDB session storage
uv add agent-framework-lib[s3]            # AWS S3 file storage
uv add agent-framework-lib[minio]         # MinIO file storage
uv add agent-framework-lib[gcp]           # GCP file storage
uv add agent-framework-lib[multimodal]    # Multimodal processing
uv add agent-framework-lib[observability] # Observability stack
uv add agent-framework-lib[websearch]     # Web search (DuckDuckGo)
uv add agent-framework-lib[all]           # All optional dependencies
```

### Checking Tool Availability

```python
from agent_framework.tools import PDF_TOOLS_AVAILABLE

if PDF_TOOLS_AVAILABLE:
    from agent_framework.tools import CreateUnifiedPDFTool
    print("PDF tools are ready!")
else:
    print("PDF tools not available — install system dependencies")
```

---

## Troubleshooting

### PDF Tools Not Available

**Symptom:** Import warning about PDF tools not being available

**Solution:**
1. Install system dependencies for your platform (see [Dependency Management](#dependency-management))
2. On macOS, ensure `DYLD_LIBRARY_PATH` is set:
   ```bash
   export DYLD_LIBRARY_PATH="/opt/homebrew/lib:$DYLD_LIBRARY_PATH"
   ```
3. Restart your Python environment after installing dependencies
4. Verify:
   ```python
   from agent_framework.tools import PDF_TOOLS_AVAILABLE
   print(PDF_TOOLS_AVAILABLE)  # Should be True
   ```

### ToolDependencyError: Tool Not Initialized

**Symptom:** `ToolDependencyError: MyTool has not been initialized. Call set_context() before using this tool.`

**Solution:** Call `set_context()` in your agent's `configure_session()`:

```python
async def configure_session(self, session_configuration):
    self.file_storage = await FileStorageFactory.create_storage_manager()
    
    for tool in self.tools:
        tool.set_context(
            file_storage=self.file_storage,
            user_id=self.current_user_id,
            session_id=self.current_session_id
        )
    
    await super().configure_session(session_configuration)
```

### ToolDependencyError: File Storage Not Available

**Symptom:** `ToolDependencyError: File storage is required but was not provided`

**Solution:**
1. Initialize file storage before setting context:
   ```python
   from agent_framework.storage.file_system_management import FileStorageFactory
   self.file_storage = await FileStorageFactory.create_storage_manager()
   ```
2. Pass it to `set_context()`:
   ```python
   tool.set_context(file_storage=self.file_storage, ...)
   ```

### Tools Not Being Called

1. Check docstrings are clear and descriptive
2. Verify type hints are correct
3. Ensure tools are returned from `get_agent_tools()`
4. Check LLM model supports function calling

### MCP Tools Not Loading

1. Install MCP package: `uv add llama-index-tools-mcp`
2. Verify MCP server is installed: `uvx install @modelcontextprotocol/server-filesystem`
3. Check server command and args are correct
4. Ensure `_initialize_mcp_tools()` is called before agent initialization

---

## Tool Best Practices

### 1. Clear Docstrings

```python
def search_database(query: str, limit: int = 10) -> list[dict]:
    """
    Search the database for records matching the query.
    
    Args:
        query: The search query string
        limit: Maximum number of results to return (default: 10)
    
    Returns:
        List of matching records as dictionaries
    """
```

### 2. Type Hints

```python
def calculate_discount(price: float, discount_percent: int) -> float:
    """Calculate discounted price."""
    return price * (1 - discount_percent / 100)
```

### 3. Error Handling

```python
def divide(a: float, b: float) -> float | str:
    """Divide two numbers."""
    try:
        if b == 0:
            return "Error: Cannot divide by zero"
        return a / b
    except Exception as e:
        return f"Error: {str(e)}"
```

### 4. Async for I/O

```python
async def fetch_api_data(endpoint: str) -> dict:
    """Fetch data from API endpoint."""
    import aiohttp
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://api.example.com/{endpoint}") as response:
            return await response.json()
```

### 5. Tool Organization

```python
# tools/database.py
def search_users(query: str) -> list[dict]:
    """Search users in database."""
    pass

# tools/api.py
async def fetch_weather(city: str) -> dict:
    """Fetch weather data."""
    pass

# agent.py
from tools import database, api

class MyAgent(LlamaIndexAgent):
    def get_agent_tools(self) -> list[callable]:
        return [database.search_users, api.fetch_weather]
```

### 6. Tool Testing

```python
import pytest
from agent import MyAgent

def test_add_tool():
    agent = MyAgent()
    tools = agent.get_agent_tools()
    add_tool = next(t for t in tools if t.__name__ == "add")
    assert add_tool(2, 3) == 5

@pytest.mark.asyncio
async def test_async_tool():
    agent = MyAgent()
    tools = agent.get_agent_tools()
    fetch_tool = next(t for t in tools if t.__name__ == "fetch_data")
    result = await fetch_tool("https://api.example.com/data")
    assert isinstance(result, dict)
```

---

## Converting Tools to Skills

The Skills System provides a way to package tools with their instructions for on-demand loading. This reduces token consumption by only loading detailed instructions when needed.

### Why Convert Tools to Skills?

| Aspect | Standalone Tools | Skills |
|--------|------------------|--------|
| Instructions | In system prompt (always loaded) | Loaded on-demand |
| Token usage | ~3000 tokens always | ~50 tokens metadata + on-demand |
| Discovery | Manual documentation | Agent can search and discover |
| Dependencies | Manual management | Automatic resolution |

### Skill Structure

A skill bundles metadata, instructions, and tools:

```python
from agent_framework.skills import Skill, SkillMetadata

skill = Skill(
    metadata=SkillMetadata(
        name="my_skill",
        description="Short description",
        trigger_patterns=["keyword1", "keyword2"],
        category="visualization",
        version="1.0.0"
    ),
    instructions="## Detailed Instructions\n...",
    tools=[MyTool()],
    dependencies=["other_skill"],
    config={}
)
```

### Converting an Existing Tool

**Before (Standalone Tool):**

```python
from agent_framework.tools import ChartToImageTool

class MyAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(...)
        self.chart_tool = ChartToImageTool()
    
    def get_agent_prompt(self) -> str:
        return """You are a helpful assistant.
        
        ## Chart Generation
        Use save_chart_as_image() to create charts...
        [500 tokens of Chart.js instructions]
        """
    
    def get_agent_tools(self):
        return [self.chart_tool.get_tool_function()]
```

**After (Skill-Based):**

```python
from agent_framework.implementations import LlamaIndexAgent

class MyAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(...)
    
    def get_agent_prompt(self) -> str:
        return "You are a helpful assistant."
    
    def get_agent_tools(self):
        return []
```

> **Note**: `BaseAgent` (and therefore `LlamaIndexAgent`) already inherits from `SkillsMixin`, so all skills methods are automatically available. Built-in skills and their tools are auto-loaded at initialization — no need to add them manually.

### Creating a Custom Skill from a Tool

```python
from agent_framework.skills import Skill, SkillMetadata
from agent_framework.tools import ChartToImageTool

CHART_INSTRUCTIONS = """
## Chart Generation Instructions

Use the `save_chart_as_image` tool to create Chart.js charts.

**Supported Chart Types:**
- bar, line, pie, doughnut, polarArea, radar, scatter, bubble

**CRITICAL: NO JAVASCRIPT FUNCTIONS**
The chartConfig must be PURE JSON.

**Example Configuration:**
```json
{
  "type": "bar",
  "data": {
    "labels": ["Mon", "Tue", "Wed"],
    "datasets": [{"label": "Sales", "data": [120, 150, 100]}]
  }
}
```
"""

def create_chart_skill() -> Skill:
    return Skill(
        metadata=SkillMetadata(
            name="chart",
            description="Generate Chart.js charts as PNG images",
            trigger_patterns=["chart", "graph", "plot", "bar chart", "pie chart"],
            category="visualization",
            version="1.0.0"
        ),
        instructions=CHART_INSTRUCTIONS,
        tools=[ChartToImageTool()],
        dependencies=[],
        config={}
    )
```

### Skill Best Practices

1. **Keep metadata lightweight** (~50 tokens) — short name, one-line description, relevant trigger patterns
2. **Write comprehensive instructions** — include usage details, examples, parameters, common pitfalls
3. **Group related tools** — one skill can have multiple tools (e.g., `file` skill has create, list, read)
4. **Use dependencies wisely** — declare required skills, avoid circular dependencies
5. **Choose appropriate categories**: `visualization`, `document`, `web`, `multimodal`, `ui`, `general`

### Built-in Skills Reference

| Skill | Tools | Category |
|-------|-------|----------|
| `chart` | `ChartToImageTool` | visualization |
| `mermaid` | `MermaidToImageTool` | visualization |
| `table` | `TableToImageTool` | visualization |
| `file` | `CreateFileTool`, `ListFilesTool`, `ReadFileTool` | document |
| `pdf` | `CreatePDFFromMarkdownTool`, `CreatePDFFromHTMLTool` | document |
| `pdf_with_images` | `CreatePDFWithImagesTool` | document |
| `file_access` | `GetFilePathTool` | document |
| `web_search` | `WebSearchTool`, `WebNewsSearchTool` | web |
| `multimodal` | `ImageAnalysisTool` | multimodal |
| `form` | (instructions only) | ui |
| `optionsblock` | (instructions only) | ui |
| `image_display` | (instructions only) | ui |

### More Information

- [Creating Agents Guide — Skills Integration](CREATING_AGENTS.md#skills-integration)

---

## Additional Resources

- [LlamaIndex Tools Documentation](https://docs.llamaindex.ai/en/stable/module_guides/deploying/agents/tools/)
- [Model Context Protocol](https://modelcontextprotocol.io/)
- [MCP Server List](https://github.com/modelcontextprotocol/servers)
- [Agent Framework Examples](../examples/)
- [WeasyPrint Documentation](https://doc.courtbouillon.org/weasyprint/)
