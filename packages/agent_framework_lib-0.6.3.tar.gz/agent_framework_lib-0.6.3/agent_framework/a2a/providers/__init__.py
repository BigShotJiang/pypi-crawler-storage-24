"""A2A Task Store provider implementations."""

ELASTICSEARCH_PROVIDER_AVAILABLE = False
POSTGRES_PROVIDER_AVAILABLE = False

try:
    from .elasticsearch_provider import ElasticsearchTaskProvider
    ELASTICSEARCH_PROVIDER_AVAILABLE = True
except ImportError:
    ElasticsearchTaskProvider = None  # type: ignore[assignment,misc]

try:
    from .postgres_provider import PostgresTaskProvider
    POSTGRES_PROVIDER_AVAILABLE = True
except ImportError:
    PostgresTaskProvider = None  # type: ignore[assignment,misc]

__all__ = [
    "ElasticsearchTaskProvider",
    "PostgresTaskProvider",
    "ELASTICSEARCH_PROVIDER_AVAILABLE",
    "POSTGRES_PROVIDER_AVAILABLE",
]
