"""Elasticsearch implementation of A2ATaskProvider."""

import logging
from datetime import datetime, timezone, timedelta

from ..base import (
    A2ATaskProvider,
    TaskNotCancelableError,
    TaskNotFoundError,
    TaskTerminalStateError,
)
from ..models import A2ATask, TaskStatus


logger = logging.getLogger(__name__)


INDEX_MAPPING = {
    "mappings": {
        "properties": {
            "id":             {"type": "keyword"},
            "context_id":     {"type": "keyword"},
            "session_id":     {"type": "keyword"},
            "message_id":     {"type": "keyword"},
            "agent_id":       {"type": "keyword"},
            "status":         {"type": "keyword"},
            "status_message": {"type": "object", "enabled": False},
            "artifact_refs":  {"type": "nested"},
            "metadata":       {"type": "object", "enabled": False},
            "created_at":     {"type": "date"},
            "updated_at":     {"type": "date"},
        }
    },
    "settings": {
        "number_of_shards": 1,
        "number_of_replicas": 1,
    },
}


class ElasticsearchTaskProvider(A2ATaskProvider):
    """Stores A2A tasks in an Elasticsearch index."""

    def __init__(
        self,
        index_name: str = "a2a-tasks",
        es_client=None,
    ):
        """
        Args:
            index_name: ES index name.
            es_client: Optional pre-configured AsyncElasticsearch client.
                       If None, the shared framework client is used.
        """
        self._index = index_name
        self._client = es_client
        self._initialized = False

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    async def initialize(self) -> bool:
        try:
            if self._client is None:
                from agent_framework.session.session_storage import (
                    get_shared_elasticsearch_client,
                )
                self._client = await get_shared_elasticsearch_client()

            if self._client is None:
                logger.error("No Elasticsearch client available for A2A task store")
                return False

            if not await self._client.indices.exists(index=self._index):
                await self._client.indices.create(index=self._index, body=INDEX_MAPPING)
                logger.info(f"Created A2A tasks index: {self._index}")
            else:
                logger.debug(f"A2A tasks index already exists: {self._index}")

            self._initialized = True
            return True
        except Exception as e:
            logger.error(f"Failed to initialize ES task provider: {e}")
            return False

    async def create_task(
        self,
        task_id: str,
        context_id: str,
        session_id: str,
        message_id: str,
        agent_id: str,
        metadata: dict | None = None,
    ) -> A2ATask:
        task = A2ATask(
            id=task_id,
            context_id=context_id,
            session_id=session_id,
            message_id=message_id,
            agent_id=agent_id,
            metadata=metadata or {},
        )
        await self._client.index(
            index=self._index,
            id=task_id,
            document=task.to_dict(),
            refresh="wait_for",
        )
        logger.debug(f"Created A2A task {task_id} in ES")
        return task

    async def get_task(self, task_id: str) -> A2ATask | None:
        try:
            resp = await self._client.get(index=self._index, id=task_id)
            return A2ATask.from_dict(resp["_source"])
        except Exception:
            return None

    async def update_status(
        self,
        task_id: str,
        state: str,
        status_message: dict | None = None,
    ) -> A2ATask:
        task = await self.get_task(task_id)
        if task is None:
            raise TaskNotFoundError(task_id)
        if task.status.is_terminal:
            raise TaskTerminalStateError(task_id, task.status.value)

        new_status = TaskStatus(state)
        now = datetime.now(timezone.utc).isoformat()

        doc: dict = {"status": new_status.value, "updated_at": now}
        if status_message is not None:
            doc["status_message"] = status_message

        await self._client.update(
            index=self._index,
            id=task_id,
            doc=doc,
            refresh="wait_for",
        )

        task.status = new_status
        task.updated_at = datetime.fromisoformat(now)
        if status_message is not None:
            task.status_message = status_message
        return task

    async def add_artifact_ref(
        self,
        task_id: str,
        artifact_id: str,
        name: str,
        parts_summary: list[dict],
    ) -> A2ATask:
        task = await self.get_task(task_id)
        if task is None:
            raise TaskNotFoundError(task_id)

        ref = {"artifact_id": artifact_id, "name": name, "parts_summary": parts_summary}
        task.artifact_refs.append(ref)
        now = datetime.now(timezone.utc).isoformat()

        await self._client.update(
            index=self._index,
            id=task_id,
            doc={
                "artifact_refs": task.artifact_refs,
                "updated_at": now,
            },
            refresh="wait_for",
        )
        task.updated_at = datetime.fromisoformat(now)
        return task

    async def list_tasks(
        self,
        context_id: str | None = None,
        state: str | None = None,
        agent_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[A2ATask]:
        filters: list[dict] = []
        if context_id:
            filters.append({"term": {"context_id": context_id}})
        if state:
            filters.append({"term": {"status": state}})
        if agent_id:
            filters.append({"term": {"agent_id": agent_id}})

        query = {"bool": {"filter": filters}} if filters else {"match_all": {}}

        resp = await self._client.search(
            index=self._index,
            query=query,
            size=limit,
            from_=offset,
            sort=[{"created_at": {"order": "desc"}}],
        )
        return [A2ATask.from_dict(hit["_source"]) for hit in resp["hits"]["hits"]]

    async def cancel_task(self, task_id: str) -> A2ATask:
        task = await self.get_task(task_id)
        if task is None:
            raise TaskNotFoundError(task_id)
        if task.status.is_terminal:
            raise TaskNotCancelableError(task_id, task.status.value)

        return await self.update_status(task_id, TaskStatus.CANCELED.value)

    async def cleanup_expired(self, ttl_hours: int = 24) -> int:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=ttl_hours)).isoformat()
        terminal_states = [s.value for s in TaskStatus if s.is_terminal]

        resp = await self._client.delete_by_query(
            index=self._index,
            query={
                "bool": {
                    "filter": [
                        {"terms": {"status": terminal_states}},
                        {"range": {"updated_at": {"lt": cutoff}}},
                    ]
                }
            },
            refresh=True,
        )
        deleted = resp.get("deleted", 0)
        logger.info(f"Cleaned up {deleted} expired A2A tasks (TTL={ttl_hours}h)")
        return deleted

    async def close(self) -> None:
        pass
