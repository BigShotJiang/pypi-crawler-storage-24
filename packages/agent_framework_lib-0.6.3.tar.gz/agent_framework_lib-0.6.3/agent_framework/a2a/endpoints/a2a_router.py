"""FastAPI router for A2A protocol endpoints."""

from __future__ import annotations

import logging
import os
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse

from .agent_card_builder import AgentCardBuilder
from .jsonrpc_dispatcher import JSONRPCDispatcher
from .models_jsonrpc import A2AConfigRequest
from .sse_wrapper import SSEWrapperA2A
from .translation_layer import A2ATranslationLayer

logger = logging.getLogger(__name__)


async def require_a2a_enabled() -> None:
    """FastAPI dependency that blocks access when A2A is disabled."""
    enabled = os.getenv("A2A_ENABLED", "false").lower() == "true"
    if not enabled:
        raise HTTPException(status_code=404, detail="Not Found")


def create_a2a_router(app_state: Any, task_provider: Any) -> APIRouter:
    """Create the A2A APIRouter with all endpoints wired.

    Args:
        app_state: FastAPI app.state with agent_manager, session_storage, agent_class.
        task_provider: Initialized A2ATaskProvider instance.

    Returns:
        Configured APIRouter.
    """
    router = APIRouter(dependencies=[Depends(require_a2a_enabled)])

    agent_instance = app_state.agent_class()
    agent_card_builder = AgentCardBuilder()

    sse_wrapper = SSEWrapperA2A()
    translation_layer = A2ATranslationLayer(
        agent_instance=agent_instance,
        task_provider=task_provider,
        session_storage=app_state.session_storage,
        sse_wrapper=sse_wrapper,
    )
    dispatcher = JSONRPCDispatcher(translation_layer=translation_layer)

    # Mutable container for the injected URL from /a2a/config
    injected_url_store: dict[str, str | None] = {"url": None}

    @router.get("/.well-known/agent.json")
    async def get_agent_card() -> dict:
        """Return the A2A Agent Card."""
        env_url = os.getenv("A2A_PUBLIC_URL")
        return agent_card_builder.build(
            agent_instance,
            injected_url=injected_url_store["url"],
            env_url=env_url,
        )

    @router.post("/a2a")
    async def handle_jsonrpc(request: Request) -> JSONResponse:
        """Dispatch incoming JSON-RPC 2.0 requests."""
        raw_body = await request.body()
        return await dispatcher.dispatch(raw_body, app_state)

    # Lazy import of auth dependency to avoid circular imports with server.py
    from agent_framework.web.server import get_current_user

    @router.post("/a2a/config")
    async def update_config(
        body: A2AConfigRequest,
        _user: str = Depends(get_current_user),
    ) -> dict:
        """Update the injected URL for the Agent Card. Protected by API key."""
        injected_url_store["url"] = body.url
        logger.info(f"[A2A] Injected URL updated: {body.url}")
        return {"status": "ok", "url": body.url}

    return router
