"""Builds the A2A Agent Card JSON from agent attributes."""

from __future__ import annotations

from typing import Any

from agent_framework.a2a.endpoints.agent_card_skill_builder import AgentCardSkillBuilder


class AgentCardBuilder:
    """Constructs the Agent Card describing an agent's identity and capabilities."""

    def build(
        self,
        agent_instance: Any,
        injected_url: str | None = None,
        env_url: str | None = None,
    ) -> dict:
        """Constructs the complete Agent Card.

        Args:
            agent_instance: The agent whose attributes populate the card.
            injected_url: URL injected via /a2a/config (highest priority).
            env_url: URL from A2A_PUBLIC_URL env var (second priority).

        Returns:
            Agent Card as a dictionary.
        """
        a2a_config = agent_instance.get_a2a_config()
        url = self._resolve_url(injected_url, env_url)
        skills = AgentCardSkillBuilder().build_skills(agent_instance)

        card = {
            "name": getattr(agent_instance, "agent_id", "unknown"),
            "description": getattr(agent_instance, "description", ""),
            "url": url,
            "version": getattr(agent_instance, "version", "1.0.0"),
            "protocolVersion": "1.0",
            "provider": a2a_config.get("provider"),
            "capabilities": {
                "streaming": True,
                "pushNotifications": False,
                "stateTransitionHistory": True,
            },
            "defaultInputModes": a2a_config.get("input_modes", ["text"]),
            "defaultOutputModes": a2a_config.get("output_modes", ["text"]),
            "skills": skills,
        }
        return card


    def _resolve_url(
        self,
        injected_url: str | None = None,
        env_url: str | None = None,
    ) -> str:
        """Resolves the agent URL with strict priority.

        Priority: injected_url > env_url > localhost fallback.

        Args:
            injected_url: URL injected via /a2a/config.
            env_url: URL from A2A_PUBLIC_URL env var.

        Returns:
            Resolved URL string.
        """
        if injected_url:
            return injected_url
        if env_url:
            return env_url
        return "http://localhost:8000/a2a"
