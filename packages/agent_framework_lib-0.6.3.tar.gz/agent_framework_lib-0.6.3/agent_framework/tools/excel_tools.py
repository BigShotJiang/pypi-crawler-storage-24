"""
Excel file generation tool for creating .xlsx spreadsheets.
"""

import logging
from collections.abc import Callable
from io import BytesIO

from .base import AgentTool, ToolDependencyError


try:
    import openpyxl
    from openpyxl.styles import Font
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False

logger = logging.getLogger(__name__)


class CreateExcelTool(AgentTool):
    """Tool for creating Excel .xlsx spreadsheet files."""

    def get_tool_function(self) -> Callable:
        """Return the Excel file creation function."""

        async def create_excel_file(filename: str, sheets: list[dict]) -> str:
            """
            Create an Excel .xlsx file with one or more sheets.

            Each sheet definition supports:
            - name (str): Sheet tab name
            - headers (list[str]): Column header strings
            - rows (list[list]): Data rows, each a list of cell values
            - bold_header (bool, optional): Apply bold formatting to the header row (default False)

            Args:
                filename: Target filename for the .xlsx file (e.g. "report.xlsx")
                sheets: List of sheet definitions

            Returns:
                Markdown download link on success, or an error string on failure.
            """
            self._ensure_initialized()

            if not filename or not filename.strip():
                return "Error: Filename cannot be empty"

            if not sheets:
                return "Error: Sheets list cannot be empty"

            if not OPENPYXL_AVAILABLE:
                raise ToolDependencyError(
                    "openpyxl is not installed. Install it with: uv add openpyxl"
                )

            if not self.file_storage:
                raise ToolDependencyError(
                    "File storage is not available. Ensure set_context() was called "
                    "with a valid file_storage instance."
                )

            try:
                wb = openpyxl.Workbook()
                wb.remove(wb.active)  # remove default empty sheet

                for sheet_def in sheets:
                    sheet_name = sheet_def.get("name", "Sheet")
                    headers = sheet_def.get("headers", [])
                    rows = sheet_def.get("rows", [])
                    bold_header = sheet_def.get("bold_header", False)

                    ws = wb.create_sheet(title=sheet_name)

                    if headers:
                        ws.append(headers)
                        if bold_header:
                            bold_font = Font(bold=True)
                            for cell in ws[1]:
                                cell.font = bold_font

                    for row in rows:
                        ws.append(row)

                buffer = BytesIO()
                wb.save(buffer)
                content_bytes = buffer.getvalue()

                file_id = await self.file_storage.store_file(
                    content=content_bytes,
                    filename=filename,
                    user_id=self.current_user_id,
                    session_id=self.current_session_id,
                    is_generated=True,
                    mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    tags=["agent-created"],
                )

                if hasattr(self.file_storage, "get_download_url"):
                    try:
                        download_url = await self.file_storage.get_download_url(file_id)
                    except Exception as url_error:
                        logger.warning(f"Failed to get download URL: {url_error}")
                        download_url = f"/files/{file_id}/download"
                else:
                    download_url = f"/files/{file_id}/download"

                logger.info(f"Created Excel file '{filename}' with ID: {file_id}")
                return f"File '{filename}' created!\n\n[{filename}]({download_url})"

            except ToolDependencyError:
                raise
            except Exception as e:
                error_msg = f"Failed to create Excel file '{filename}': {e}"
                logger.error(error_msg)
                return f"Error: {error_msg}"

        return create_excel_file


__all__ = ["CreateExcelTool"]
