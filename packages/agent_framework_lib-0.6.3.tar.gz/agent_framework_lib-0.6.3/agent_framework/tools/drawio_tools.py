"""
Draw.io diagram generation tool for creating .drawio XML files.
"""

import logging
import os
import tempfile
from collections.abc import Callable

from .base import AgentTool, ToolDependencyError


try:
    import drawpyo
    DRAWPYO_AVAILABLE = True
except ImportError:
    DRAWPYO_AVAILABLE = False

logger = logging.getLogger(__name__)

# Mapping from user-facing shape names to drawpyo style attributes
SHAPE_STYLES: dict[str, dict] = {
    "rectangle": {},
    "rounded": {"rounded": 1},
    "ellipse": {"shape": "ellipse"},
    "diamond": {"shape": "rhombus"},
    "parallelogram": {"shape": "parallelogram"},
}

DEFAULT_SHAPE = "rectangle"
DEFAULT_NODE_WIDTH = 120
DEFAULT_NODE_HEIGHT = 60
DEFAULT_X_STEP = 160
DEFAULT_Y = 100


class CreateDrawioTool(AgentTool):
    """Tool for creating Draw.io .drawio diagram files."""

    def get_tool_function(self) -> Callable:
        """Return the Draw.io file creation function."""

        async def create_drawio_file(
            filename: str,
            title: str,
            nodes: list[dict],
            edges: list[dict],
        ) -> str:
            """
            Create a Draw.io .drawio diagram file.

            Node definition fields:
            - id (str): Unique node identifier
            - label (str): Display text
            - shape (str, optional): rectangle|rounded|ellipse|diamond|parallelogram (default: rectangle)
            - x (int, optional): X position
            - y (int, optional): Y position

            Edge definition fields:
            - source (str): Source node id
            - target (str): Target node id
            - label (str, optional): Edge label text

            Args:
                filename: Target filename for the .drawio file (e.g. "diagram.drawio")
                title: Diagram title / page name
                nodes: List of node definitions
                edges: List of edge definitions

            Returns:
                Markdown download link on success, or an error string on failure.
            """
            self._ensure_initialized()

            if not filename or not filename.strip():
                return "Error: Filename cannot be empty"

            if not nodes:
                return "Error: Nodes list cannot be empty"

            # Validate edge references
            node_ids = {n["id"] for n in nodes}
            for edge in edges:
                for field in ("source", "target"):
                    ref = edge.get(field)
                    if ref not in node_ids:
                        return f"Error: Edge references unknown node id '{ref}'"

            if not DRAWPYO_AVAILABLE:
                raise ToolDependencyError(
                    "drawpyo is not installed. Install it with: uv add drawpyo"
                )

            if not self.file_storage:
                raise ToolDependencyError(
                    "File storage is not available. Ensure set_context() was called "
                    "with a valid file_storage instance."
                )

            try:
                with tempfile.TemporaryDirectory() as tmpdir:
                    f = drawpyo.File()
                    f.file_path = tmpdir
                    f.file_name = filename
                    page = drawpyo.Page(file=f, name=title or "Page-1")

                    node_objects: dict[str, object] = {}
                    for idx, node_def in enumerate(nodes):
                        obj = drawpyo.diagram.Object(
                            value=node_def.get("label", ""),
                            page=page,
                        )
                        obj.geometry.width = DEFAULT_NODE_WIDTH
                        obj.geometry.height = DEFAULT_NODE_HEIGHT
                        obj.geometry.x = node_def.get("x", idx * DEFAULT_X_STEP)
                        obj.geometry.y = node_def.get("y", DEFAULT_Y)

                        shape = node_def.get("shape", DEFAULT_SHAPE)
                        style_attrs = SHAPE_STYLES.get(shape, SHAPE_STYLES[DEFAULT_SHAPE])
                        for attr, val in style_attrs.items():
                            setattr(obj, attr, val)

                        node_objects[node_def["id"]] = obj

                    for edge_def in edges:
                        src = node_objects[edge_def["source"]]
                        tgt = node_objects[edge_def["target"]]
                        edge_obj = drawpyo.diagram.Edge(source=src, target=tgt, page=page)
                        label = edge_def.get("label")
                        if label:
                            edge_obj.label = label

                    f.write()

                    filepath = os.path.join(tmpdir, filename)
                    with open(filepath, "rb") as fh:
                        content_bytes = fh.read()

                file_id = await self.file_storage.store_file(
                    content=content_bytes,
                    filename=filename,
                    user_id=self.current_user_id,
                    session_id=self.current_session_id,
                    is_generated=True,
                    mime_type="application/xml",
                    tags=["agent-created"],
                )

                if hasattr(self.file_storage, "get_download_url"):
                    try:
                        download_url = await self.file_storage.get_download_url(file_id)
                    except Exception as url_error:
                        logger.warning(f"Failed to get download URL: {url_error}")
                        download_url = f"/files/{file_id}/download"
                else:
                    download_url = f"/files/{file_id}/download"

                logger.info(f"Created Draw.io file '{filename}' with ID: {file_id}")
                return f"File '{filename}' created!\n\n[{filename}]({download_url})"

            except ToolDependencyError:
                raise
            except Exception as e:
                error_msg = f"Failed to create Draw.io file '{filename}': {e}"
                logger.error(error_msg)
                return f"Error: {error_msg}"

        return create_drawio_file


__all__ = ["CreateDrawioTool"]
