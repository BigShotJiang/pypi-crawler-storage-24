# Audit & recommandations — Agent Framework (synthèse complète)

**Date**: 2026-03-09  
**Périmètre**: extraits fournis (LlamaIndexAgent, BaseAgent, ActivityFormatter, AgentInterface & parts, StreamingPartsAccumulator, StepDisplayConfig, AgentManager/Proxy, ContextBudgetManager/ContextSummarizer/ScratchpadCompressor, Memory* (Mixin/Manager/Config), ElasticsearchConfigProvider, ModelConfig/ModelClientFactory patches, ModelRouter, StateManager, ImplementationValidator, Helper Agent).

---

## 1) Objectifs et principes (ce que l’architecture cherche à garantir)

### 1.1 Socle commun multi-provider (vision cohérente)
Le framework vise un **socle commun** qui reste stable même si l’agent sous-jacent change de provider (OpenAI/Anthropic/Gemini) ou de framework (LlamaIndex et autres). Les invariants attendus :

- **UX streaming uniforme** (chunks, activités, outils, replay historique)
- **Mémoire conversationnelle cohérente** (stockage, recall, injection passive)
- **Observabilité homogène** (tokens, TTFT, timings outils, budget contexte)
- **Config dynamique** (ES) avec isolation de session
- **Extensibilité** : un dev implémente ses prompts/outils et profite du reste

### 1.2 Où se situe le risque réel
Le design “BaseAgent = base commune” est bon. Le risque apparaît si des implémentations **réécrivent** des morceaux de pipeline (ex. streaming/orchestration) de manière divergente, car la base commune perd ses garanties.

---

## 2) Points forts (à conserver)

### 2.1 Streaming orienté UI moderne
- Séparation claire entre **texte streamé** (chunks) et **activité** (tool calls, events)
- Possibilité de rejouer “Under the Hood” via persistance d’événements (`__STREAM_ACTIVITY__` et/ou `streaming_activities`)

### 2.2 Observabilité pragmatique
- Intégration “graceful degradation” : métriques et tracer optionnels
- **TTFT** (time-to-first-token) capturé manuellement : excellent (souvent absent des stacks OTel)
- Corrélation possible avec OpenTelemetry (trace_id/span_id)

### 2.3 Gestion du budget contexte en 2 couches
- Budget conversation (`ContextBudgetManager.enforce_budget`) : résumé/troncature
- Budget boucle outils (`BudgetAwareFunctionAgent` + `ScratchpadCompressor`) : protège le scratchpad

### 2.4 Compatibilité cross-provider
- Sanitation tool_calls / blocks / kwargs (OpenAI ↔ Anthropic ↔ Gemini)
- Patches au niveau client LLM pour rattraper certains cas (utile en prod)

### 2.5 Configuration ES versionnée + cache
- Provider ES avec TTL + LRU + circuit breaker : base saine
- AgentManager essaye de préserver l’isolation de session via doc_id/version

### 2.6 Mémoire “hybrid” (Memori + Graphiti)
- Bonne séparation : Memori (faits/préférences simples) + Graphiti (graphe/temporal)
- Async store + semaphore + shutdown propre : mature

### 2.7 Validator d’implémentation
- Très bonne idée pour encadrer les contributeurs : signatures, méthodes requises, final methods, etc.

---

## 3) Problèmes et recommandations (priorisées)

> **P0** = risque de bug/incident prod ou incohérence majeure.

### P0-1 — `process_streaming_event()` incomplet / incohérent (LlamaIndexAgent)
**Constat**: sur `ToolCallResult`, le code construit tool_call + tool_result, mais **retourne uniquement** le tool_call (commentaire “simplification”).

**Impact**:
- UI: résultats d’outils potentiellement manquants / activités incomplètes
- Historique: replay “under the hood” incomplet

**Recommandation**:
- Standardiser: soit `process_streaming_event` retourne un **événement consolidé** (tool + result) sur `ToolCallResult`, soit changer le contrat pour émettre une séquence.
- Si vous gardez le contrat 1→1, retourner un **tool_result consolidé** (avec metadata tool_name/args/call_id + content=result).

**DoD / tests**:
- Test streaming: tool_call + tool_result visibles dans UI et ES
- Test “result sans request” (call_id inconnu) géré

---

### P0-2 — Cache global `_GLOBAL_MEMORY_CACHE` non borné (LlamaIndexMemoryAdapter)
**Constat**: dict global sans TTL/LRU.

**Impact**: fuite mémoire, comportements non déterministes multi-worker.

**Recommandation**:
- Remplacer par cache borné (LRU + TTL) configurable.
- Option: désactiver cache global si storage est rapide.

**DoD / tests**:
- Test charge: nombre de sessions élevé sans croissance illimitée
- Test invalidation modèle/session

---

### P0-3 — Hardcode modèle dans `ScratchpadCompressor` (`"gpt-5-mini"`)
**Constat**: résumé scratchpad force un modèle.

**Impact**: casse si provider non dispo / configuration différente.

**Recommandation**:
- Passer `model_name` courant à `compress()` → `_try_summarize_old_entries()`.

---

### P0-4 — ElasticsearchConfigProvider requête `agent_id.keyword` alors que mapping est `keyword`
**Constat**: mapping `agent_id: keyword`, query `agent_id.keyword`.

**Impact**: config non trouvée.

**Recommandation**:
- Utiliser `term` sur `agent_id`.

---

### P0-5 — Extraction special blocks (optionsblock/form/image) dupliquée selon pipeline
**Constat**: extraction à plusieurs endroits (consolidation, fin de streaming, server).

**Impact**: duplication de blocs en historique / incohérences.

**Recommandation**:
- Choisir un seul endroit (idéalement server-side via `consolidate_text_parts`).

---

### P0-6 — Logs trop verbeux et potentiellement sensibles
**Constat**: previews de messages, tool kwargs, outputs.

**Impact**: fuite secrets/PII, coûts logs.

**Recommandation**:
- Mode “safe logging/redaction” + limiter previews.

---

## 4) Problèmes de cohérence/maintenance (P1)

### P1-1 — Triple source de vérité pour l’affichage (friendly_name/icon/description)
**Constat**: ActivityFormatter + DEFAULT_*_DISPLAY + DisplayConfigManager overrides.

**Impact**: incohérences UI, maintenance lourde.

**Recommandation**:
- Définir StepDisplayConfig/DisplayConfigManager comme **source of truth**.
- ActivityFormatter ne conserve que la génération de contenu + TechnicalDetails.

---

### P1-2 — Tool timings mesurés mais non propagés (execution_time_ms=0)
**Recommandation**:
- Exploiter metrics collector pour remplir `TechnicalDetails.execution_time_ms`.

---

### P1-3 — Sanitation dupliquée (MemoryAdapter + patches LLM)
**Impact**: divergence, bugs.

**Recommandation**:
- Centraliser une couche principale (préférence: sanitation au niveau ChatMessage/memory avant appel) + patches comme fallback.

---

### P1-4 — BaseAgent pipeline vs implémentations spécifiques
**Constat**: BaseAgent propose un pipeline standard (run_agent + process_streaming_event + orchestration). Certaines implémentations risquent de redéfinir la logique et diverger.

**Recommandation**:
- Énoncer un “contrat”: si une implémentation override le streaming, elle doit respecter exactement le même format parts/activities/blocks/métriques.
- Ou refactor à terme pour que tous passent par le pipeline BaseAgent.

---

### P1-5 — `consolidate_text_parts` heuristique fragile (dict vs models)
**Recommandation**:
- Standardiser interne: Pydantic models partout, conversion dict uniquement à la frontière.

---

### P1-6 — `strip_technical_details` reconstruit des modèles à la main
**Recommandation**:
- Utiliser `model_copy(update={...})`.

---

## 5) Améliorations “budget contexte” (P1/P2)

### 5.1 Ratios trop statiques
- `TARGET_CONVERSATION_RATIO=0.30`, `RECENT_ZONE_RATIO=0.05` et seuil 95% fixes.

**Reco**:
- Rendre configurables par agent/modèle/env.
- Ajouter politique “sacred zone mitigation” si prompt+tools prennent trop.

### 5.2 Token counting basé sur `content` seulement
**Reco**:
- Tokeniser une représentation complète (role + content + tool_calls/blocks) quand c’est pertinent.

### 5.3 Evénements budget structurés
**Reco**:
- Émettre une Activity “context_summarized” + snapshot tokens avant/après (déjà partiel, à standardiser).
