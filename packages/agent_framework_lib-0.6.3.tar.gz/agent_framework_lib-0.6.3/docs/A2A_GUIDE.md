# A2A Protocol Guide

## Introduction

The A2A (Agent-to-Agent) module implements the [A2A protocol](https://google.github.io/A2A/) for inter-agent communication using JSON-RPC 2.0. It allows external agents or orchestrators to interact with your agent through a standardized interface.

When enabled, the module exposes:

- A JSON-RPC 2.0 endpoint at `POST /a2a` for sending messages and querying tasks
- An Agent Card at `GET /.well-known/agent.json` for agent discovery
- A configuration endpoint at `POST /a2a/config` for URL injection
- SSE streaming support for real-time responses

The module is entirely optional and controlled by the `A2A_ENABLED` environment variable.

## Architecture

The A2A module is located at `agent_framework/a2a/` and is composed of five main components:

```
agent_framework/a2a/
├── models.py                          # A2ATask dataclass, TaskStatus enum
├── base.py                            # A2ATaskProvider abstract interface
├── providers/
│   ├── elasticsearch_provider.py      # Elasticsearch Task Store
│   └── postgres_provider.py           # PostgreSQL Task Store
└── endpoints/
    ├── a2a_router.py                  # FastAPI router, endpoint wiring
    ├── jsonrpc_dispatcher.py          # JSON-RPC 2.0 request parsing & routing
    ├── translation_layer.py           # A2A ↔ framework pipeline bridge
    ├── sse_wrapper.py                 # Internal SSE → A2A SSE translation
    ├── agent_card_builder.py          # Agent Card construction
    ├── agent_card_skill_builder.py    # Skill aggregation for Agent Card
    └── models_jsonrpc.py              # Pydantic models for JSON-RPC protocol
```

### Request Flow

```
Client → POST /a2a (JSON-RPC)
           │
           ▼
    ┌──────────────────┐
    │  JSONRPCDispatcher│  Parse JSON-RPC, validate, route by method
    └────────┬─────────┘
             │
             ▼
    ┌──────────────────────┐
    │  A2ATranslationLayer │  Convert A2A params → framework input,
    │                      │  call agent pipeline, convert output → A2A
    └────────┬─────────────┘
             │
        ┌────┴────┐
        │         │
        ▼         ▼
   Sync flow   Stream flow
   (message/    (message/
    send)        stream)
        │         │
        │         ▼
        │    ┌──────────┐
        │    │SSEWrapper │  Translate internal stream events
        │    │   A2A     │  into A2A SSE format
        │    └──────────┘
        │         │
        ▼         ▼
    JSONResponse  StreamingResponse
```

### Component Details

#### Task Store

The Task Store is a lightweight mapping layer that links A2A task IDs to existing framework sessions. It does **not** duplicate conversational content — the actual messages remain in the framework's session store.

Two provider implementations are available:

| Provider | Backend | Dependency | Index/Table |
|----------|---------|------------|-------------|
| `ElasticsearchTaskProvider` | Elasticsearch | `elasticsearch[async]` (via `elasticsearch` extra) | `a2a-tasks` |
| `PostgresTaskProvider` | PostgreSQL | `asyncpg` (via `postgresql` extra) | `a2a_tasks` |

Provider selection at startup follows this priority:

1. If `ELASTICSEARCH_ENABLED=true` and the Elasticsearch client is available → **Elasticsearch**
2. Otherwise, if `asyncpg` is installed → **PostgreSQL**
3. If neither is available → A2A endpoints are **not mounted** (a warning is logged)

Both providers implement the `A2ATaskProvider` abstract interface defined in `base.py`, which provides:

- `create_task()` — Create a new task entry
- `get_task()` — Retrieve a task by ID
- `update_status()` — Transition task state (with terminal state guards)
- `add_artifact_ref()` — Attach artifact references to a task
- `list_tasks()` — Query tasks with filters (context, state, agent)
- `cancel_task()` — Cancel a non-terminal task
- `cleanup_expired()` — Remove terminal tasks older than a TTL

#### JSON-RPC Dispatcher

`JSONRPCDispatcher` handles the raw HTTP body from `POST /a2a`:

1. Parses JSON and validates the JSON-RPC 2.0 envelope (`jsonrpc`, `id`, `method`, `params`)
2. Routes to the appropriate `A2ATranslationLayer` method based on `method`
3. Returns a `JSONResponse` for synchronous methods or a `StreamingResponse` for `message/stream`
4. Handles parse errors, invalid requests, unknown methods, and invalid params with standard JSON-RPC error codes

#### Translation Layer

`A2ATranslationLayer` bridges the A2A protocol and the internal agent pipeline:

- Extracts text from A2A message parts
- Resolves `contextId` to a framework `session_id` (1:1 mapping; a new UUID is generated if none is provided)
- Creates a task in the Task Store, transitions it through `submitted → working → completed/failed`
- Converts `StructuredAgentInput`/`StructuredAgentOutput` to/from A2A messages and artifacts
- For `message/send`: consumes the full agent stream and returns an aggregated response
- For `message/stream`: delegates to the SSE Wrapper for real-time event translation

#### Agent Card Builder

`AgentCardBuilder` constructs the Agent Card served at `GET /.well-known/agent.json`. The card describes the agent's identity, capabilities, and skills.

Skills are aggregated from four sources by `AgentCardSkillBuilder`:

1. **Custom skills** — from `agent.get_a2a_skills()` (prefixed with `custom-`)
2. **Framework capabilities** — grouped from the agent's skill registry
3. **MCP server skills** — one per MCP server key
4. **Tool skills** — one per agent tool

The agent URL in the card is resolved with this priority:
1. Injected URL from `POST /a2a/config` (highest)
2. `A2A_PUBLIC_URL` environment variable
3. Fallback: `http://localhost:8000/a2a`

#### SSE Wrapper

`SSEWrapperA2A` translates the internal framework streaming events into A2A-compliant SSE events. Each SSE line is a JSON-RPC 2.0 response wrapper containing either:

- **`TaskStatusUpdateEvent`** — state transitions (`working`, `completed`, `failed`) and activity messages
- **`TaskArtifactUpdateEvent`** — text chunks from the agent response (with `append` flag for incremental updates)

The SSE format is:
```
data: {"jsonrpc": "2.0", "id": "<request_id>", "result": { ... event ... }}
```


## JSON-RPC Methods

All methods are dispatched through `POST /a2a`. Requests must follow the JSON-RPC 2.0 format:

```json
{
  "jsonrpc": "2.0",
  "id": "<request_id>",
  "method": "<method_name>",
  "params": { ... }
}
```

### message/send

Send a message to the agent and receive a synchronous response. The agent processes the full request, consumes the entire stream internally, and returns a completed task with aggregated artifacts.

**Parameters (`MessageSendParams`):**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `message` | `A2AMessage` | Yes | The message to send |
| `message.role` | `"user"` or `"agent"` | Yes | Message sender role |
| `message.parts` | `A2APart[]` | Yes | Content parts (see below) |
| `configuration` | `MessageConfiguration` | No | Optional settings |
| `configuration.acceptedOutputModes` | `string[]` | No | Accepted output modes |
| `configuration.historyLength` | `int` | No | Number of history messages to include |
| `configuration.blocking` | `bool` | No | Whether to block until completion |

**A2APart:**

| Field | Type | Description |
|-------|------|-------------|
| `kind` | `"text"`, `"file"`, or `"data"` | Part type |
| `text` | `string` | Text content (for `kind: "text"`) |

**Response:** Returns an `A2ATaskResult` with status `completed` and the agent's response as an artifact.

### message/stream

Send a message and receive the response as a Server-Sent Events (SSE) stream. The HTTP response has `Content-Type: text/event-stream`.

**Parameters:** Same as `message/send` (`MessageSendParams`).

**SSE Events:** Each line follows the format `data: {json}\n\n` where the JSON is a JSON-RPC 2.0 response containing either:

- **`TaskStatusUpdateEvent`** — State transitions and activity messages:
  - `working` — Agent is processing (may include activity text)
  - `completed` — Agent finished processing
  - `failed` — An error occurred

- **`TaskArtifactUpdateEvent`** — Text chunks from the agent:
  - First chunk: `append: false` (or null)
  - Subsequent chunks: `append: true`

### tasks/get

Retrieve the current state of a task from the Task Store.

**Parameters (`TaskGetParams`):**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | `string` | Yes | Task ID (UUID) |
| `historyLength` | `int` | No | Number of session history messages to include |

**Response:** Returns an `A2ATaskResult` with the task's current status, artifacts, and optionally conversation history.

### tasks/cancel

Cancel a running task. Only non-terminal tasks can be canceled.

**Parameters (`TaskCancelParams`):**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | `string` | Yes | Task ID to cancel |

**Response:** Returns an `A2ATaskResult` with status `canceled`.

**Errors:**
- `-32001` (`TASK_NOT_FOUND`) — Task ID does not exist
- `-32002` (`TASK_NOT_CANCELABLE`) — Task is already in a terminal state

### agent/authenticatedExtendedCard

Retrieve the extended Agent Card with additional details. This method is dispatched through the same `POST /a2a` JSON-RPC endpoint. The Agent Card is also available publicly at `GET /.well-known/agent.json`.

**Parameters:** None (empty `params: {}`).

**Response:** Returns the full Agent Card object (see [Agent Card](#agent-card) section below).

### Error Codes

| Code | Constant | Description |
|------|----------|-------------|
| `-32700` | `PARSE_ERROR` | Invalid JSON |
| `-32600` | `INVALID_REQUEST` | Not a valid JSON-RPC 2.0 request |
| `-32601` | `METHOD_NOT_FOUND` | Unknown method name |
| `-32602` | `INVALID_PARAMS` | Invalid method parameters |
| `-32603` | `INTERNAL_ERROR` | Server-side error |
| `-32001` | `TASK_NOT_FOUND` | Task ID not found in the Task Store |
| `-32002` | `TASK_NOT_CANCELABLE` | Task is in a terminal state |


## Configuration

### Activation

Set `A2A_ENABLED=true` to enable A2A endpoints. When disabled (default), all A2A routes return `404 Not Found`.

```bash
A2A_ENABLED=true
```

### Environment Variables

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `A2A_ENABLED` | boolean | `false` | Enable A2A endpoints (`/a2a`, `/.well-known/agent.json`, `/a2a/config`) |
| `A2A_PUBLIC_URL` | string | None | Public URL for the Agent Card. Used when no URL is injected via `/a2a/config`. Falls back to `http://localhost:8000/a2a` |
| `ELASTICSEARCH_ENABLED` | boolean | `false` | When `true` and the Elasticsearch client is available, the Elasticsearch Task Store provider is used |

For the PostgreSQL provider, `asyncpg` must be installed (via the `postgresql` extra). The connection string is configured through the framework's PostgreSQL settings (typically `A2A_POSTGRES_DSN` or the shared database DSN).

### Task Store Provider Selection

The provider is selected automatically at startup:

```
A2A_ENABLED=true
  │
  ├─ ELASTICSEARCH_ENABLED=true + elasticsearch client available?
  │    └─ YES → ElasticsearchTaskProvider (index: a2a-tasks)
  │
  ├─ asyncpg installed?
  │    └─ YES → PostgresTaskProvider (table: a2a_tasks)
  │
  └─ Neither available → A2A endpoints NOT mounted (warning logged)
```

### Installation Extras

Depending on your chosen Task Store backend:

```bash
# Elasticsearch backend
uv pip install agent-framework-lib[elasticsearch]

# PostgreSQL backend
uv pip install agent-framework-lib[postgresql]
```

### Docker Setup

If using Docker Compose, ensure the appropriate backend service is running. See [Docker Setup](./DOCKER_SETUP.md) for service configuration details.

For PostgreSQL:
```yaml
# In docker-compose.yml
postgres:
  image: postgres:16
  environment:
    POSTGRES_DB: agent_framework
    POSTGRES_USER: postgres
    POSTGRES_PASSWORD: postgres
  ports:
    - "5432:5432"
```


## Examples

### message/send — Request & Response

**Request:**
```bash
curl -X POST http://localhost:8000/a2a \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": "req-1",
    "method": "message/send",
    "params": {
      "message": {
        "role": "user",
        "parts": [
          {"kind": "text", "text": "What is the weather in Paris?"}
        ]
      }
    }
  }'
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-1",
  "result": {
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "contextId": "f0e1d2c3-b4a5-6789-0abc-def123456789",
    "status": {
      "state": "completed",
      "timestamp": "2025-01-15T10:30:00.000000+00:00"
    },
    "artifacts": [
      {
        "artifactId": "art-uuid-1234",
        "name": "response",
        "parts": [
          {"kind": "text", "text": "The current weather in Paris is 18°C with partly cloudy skies."}
        ]
      }
    ]
  }
}
```

### message/stream — SSE Events

**Request:**
```bash
curl -N -X POST http://localhost:8000/a2a \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": "req-2",
    "method": "message/stream",
    "params": {
      "message": {
        "role": "user",
        "parts": [
          {"kind": "text", "text": "Explain quantum computing"}
        ]
      }
    }
  }'
```

**SSE Response (multiple events):**
```
data: {"jsonrpc": "2.0", "id": "req-2", "result": {"id": "task-uuid", "contextId": "ctx-uuid", "status": {"state": "working", "timestamp": "2025-01-15T10:30:00+00:00"}}}

data: {"jsonrpc": "2.0", "id": "req-2", "result": {"id": "task-uuid", "contextId": "ctx-uuid", "artifact": {"artifactId": "art-1", "name": "response", "parts": [{"kind": "text", "text": "Quantum computing uses"}], "append": null}}}

data: {"jsonrpc": "2.0", "id": "req-2", "result": {"id": "task-uuid", "contextId": "ctx-uuid", "artifact": {"artifactId": "art-2", "name": "response", "parts": [{"kind": "text", "text": " quantum-mechanical phenomena..."}], "append": true}}}

data: {"jsonrpc": "2.0", "id": "req-2", "result": {"id": "task-uuid", "contextId": "ctx-uuid", "status": {"state": "completed", "timestamp": "2025-01-15T10:30:05+00:00"}}}

```

### tasks/get — Request & Response

**Request:**
```bash
curl -X POST http://localhost:8000/a2a \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": "req-3",
    "method": "tasks/get",
    "params": {
      "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "historyLength": 5
    }
  }'
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-3",
  "result": {
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "contextId": "f0e1d2c3-b4a5-6789-0abc-def123456789",
    "status": {
      "state": "completed",
      "timestamp": "2025-01-15T10:30:05.000000+00:00"
    },
    "artifacts": [
      {
        "artifactId": "art-uuid-1234",
        "name": "response",
        "parts": [{"kind": "text", "text": ""}]
      }
    ],
    "history": [
      {
        "role": "user",
        "parts": [{"kind": "text", "text": "What is the weather in Paris?"}]
      },
      {
        "role": "agent",
        "parts": [{"kind": "text", "text": "The current weather in Paris is 18°C with partly cloudy skies."}]
      }
    ]
  }
}
```

### tasks/cancel — Request & Response

**Request:**
```bash
curl -X POST http://localhost:8000/a2a \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": "req-4",
    "method": "tasks/cancel",
    "params": {
      "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
    }
  }'
```

**Response (success):**
```json
{
  "jsonrpc": "2.0",
  "id": "req-4",
  "result": {
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "contextId": "f0e1d2c3-b4a5-6789-0abc-def123456789",
    "status": {
      "state": "canceled",
      "timestamp": "2025-01-15T10:31:00.000000+00:00"
    }
  }
}
```

**Response (error — task already completed):**
```json
{
  "jsonrpc": "2.0",
  "id": "req-4",
  "error": {
    "code": -32002,
    "message": "Task a1b2c3d4-... is in terminal state 'completed' and cannot be canceled"
  }
}
```

### agent/authenticatedExtendedCard — Request & Response

**Request:**
```bash
curl -X POST http://localhost:8000/a2a \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": "req-5",
    "method": "agent/authenticatedExtendedCard",
    "params": {}
  }'
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": "req-5",
  "result": {
    "name": "my-agent",
    "description": "A helpful AI assistant",
    "url": "https://my-agent.example.com/a2a",
    "version": "1.0.0",
    "protocolVersion": "1.0",
    "provider": {
      "organization": "My Company",
      "url": "https://example.com"
    },
    "capabilities": {
      "streaming": true,
      "pushNotifications": false,
      "stateTransitionHistory": true
    },
    "defaultInputModes": ["text"],
    "defaultOutputModes": ["text"],
    "skills": [
      {
        "id": "custom-weather",
        "name": "Weather Lookup",
        "description": "Look up current weather for a location",
        "tags": ["weather", "lookup"],
        "examples": ["What is the weather in Paris?"]
      },
      {
        "id": "framework-capabilities",
        "name": "Framework Capabilities",
        "description": "Built-in framework capabilities including conversation management, skill orchestration, and session handling",
        "tags": ["framework"]
      }
    ]
  }
}
```

### Error Response Example

**Request with invalid JSON:**
```bash
curl -X POST http://localhost:8000/a2a \
  -H "Content-Type: application/json" \
  -d 'not valid json'
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": null,
  "error": {
    "code": -32700,
    "message": "Parse error"
  }
}
```


## Task Model

### A2ATask

`A2ATask` is a lightweight dataclass that maps an A2A task to a framework session. It does not store conversational content — that remains in the framework's session store.

| Field | Type | Description |
|-------|------|-------------|
| `id` | `str` | Unique task identifier (UUID) |
| `context_id` | `str` | A2A context ID, maps 1:1 to a framework `session_id` |
| `session_id` | `str` | Framework session ID |
| `message_id` | `str` | Framework message ID that triggered this task |
| `agent_id` | `str` | Agent identifier |
| `status` | `TaskStatus` | Current lifecycle state |
| `status_message` | `dict` or `None` | Optional status message (e.g., error details) |
| `artifact_refs` | `list[dict]` | References to artifacts produced (not full content) |
| `metadata` | `dict` | Optional extra metadata |
| `created_at` | `datetime` | Task creation timestamp (UTC) |
| `updated_at` | `datetime` | Last update timestamp (UTC) |

### Task Lifecycle

Tasks follow a state machine with terminal and non-terminal states:

```
                    ┌──────────┐
                    │ submitted│
                    └────┬─────┘
                         │
                         ▼
                    ┌──────────┐
              ┌─────│ working  │─────┐
              │     └────┬─────┘     │
              │          │           │
              ▼          ▼           ▼
        ┌──────────┐ ┌──────────┐ ┌──────────┐
        │ canceled │ │completed │ │  failed  │
        └──────────┘ └──────────┘ └──────────┘
```

### TaskStatus Enum

| Status | Terminal | Description |
|--------|----------|-------------|
| `submitted` | No | Task created, waiting to be processed |
| `working` | No | Agent is actively processing the task |
| `input-required` | No | Agent needs additional input from the caller |
| `completed` | Yes | Task finished successfully, artifacts available |
| `failed` | Yes | Task encountered an error |
| `canceled` | Yes | Task was canceled via `tasks/cancel` |
| `rejected` | Yes | Task was rejected by the agent |

Terminal states are immutable — once a task reaches a terminal state, its status cannot be changed. Attempting to update a terminal task raises a `TaskTerminalStateError` (JSON-RPC code `-32002`).

### Typical Lifecycle Flow

For `message/send`:
1. Task created with status `submitted`
2. Immediately transitions to `working`
3. Agent processes the message (full stream consumed internally)
4. Artifact reference added to the task
5. Status set to `completed` (or `failed` on error)

For `message/stream`:
1. Task created with status `submitted`
2. Transitions to `working` (first SSE event sent)
3. Agent streams response chunks (artifact events sent via SSE)
4. Status set to `completed` (final SSE event)

### Cleanup

Both providers support `cleanup_expired(ttl_hours=24)` to remove terminal tasks older than the specified TTL. This prevents unbounded growth of the Task Store.

## Agent Card

The Agent Card is a discovery document served at `GET /.well-known/agent.json`. It describes the agent's identity, capabilities, and available skills.

### Card Structure

| Field | Type | Description |
|-------|------|-------------|
| `name` | `string` | Agent identifier (from `agent_id`) |
| `description` | `string` | Agent description |
| `url` | `string` | A2A endpoint URL |
| `version` | `string` | Agent version |
| `protocolVersion` | `"1.0"` | A2A protocol version |
| `provider` | `object` or `null` | Organization info (`organization`, `url`) |
| `capabilities` | `object` | `streaming: true`, `pushNotifications: false`, `stateTransitionHistory: true` |
| `defaultInputModes` | `string[]` | Accepted input modes (default: `["text"]`) |
| `defaultOutputModes` | `string[]` | Output modes (default: `["text"]`) |
| `skills` | `AgentSkill[]` | List of agent skills |

### URL Injection

The Agent Card URL can be updated dynamically via `POST /a2a/config` (protected by API key authentication):

```bash
curl -X POST http://localhost:8000/a2a/config \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{"url": "https://my-agent.example.com/a2a"}'
```

## Related Links

- [API Reference](./api-reference.md) — Full endpoint documentation including A2A JSON-RPC methods
- [Configuration](./configuration.md) — Complete environment variable reference
- [Creating Agents](./CREATING_AGENTS.md) — Agent development guide with A2A integration
- [Docker Setup](./DOCKER_SETUP.md) — Docker Compose configuration for backend services
- [Architecture Diagram](./ARCHITECTURE_DIAGRAM.md) — System architecture including A2A module
