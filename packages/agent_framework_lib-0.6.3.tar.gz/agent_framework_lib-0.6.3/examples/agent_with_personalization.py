"""
Agent with Personalization (Graphiti / FalkorDB or Neo4j)

Demonstrates the automatic personalization system built into AgentFramework.
No custom code needed — just add {{native_user_preferences}} in your prompt (optional).

The framework automatically:
1. Recalls user facts from Graphiti at session start
2. Injects them into the prompt (replacing {{native_user_preferences}} or prepending)
3. Skips silently if memory is unavailable or no facts exist yet

Configuration (.env):
    PERSONALIZATION_ENABLED=true   # set to "false" to disable
    USE_FALKORDB=true              # local FalkorDB (dev)
    USE_FALKORDB=false             # Neo4j AuraDB (prod, same as tessi-agents)

Usage:
    cd AgentFramework
    docker-compose --profile memory up -d falkordb
    uv run examples/agent_with_personalization.py

The agent starts on http://localhost:8105
"""

import os
from typing import Any

from agent_framework.implementations import LlamaIndexAgent
from agent_framework.memory import MemoryConfig


PROMPT = """Tu es un assistant de test pour le système de personnalisation.
Adapte tes réponses aux préférences de l'utilisateur en utilisant.

{{native_user_preferences}}"""


class PersonalizationTestAgent(LlamaIndexAgent):
    """Minimal agent that demonstrates automatic personalization.

    The {{native_user_preferences}} placeholder in the prompt is replaced automatically
    by the framework with facts recalled from Graphiti — no extra code needed.
    """

    def __init__(self):
        super().__init__(
            # Same agent_id as production so it reads the same Graphiti graph
            agent_id="socrate-v1",
            name="Socrate (Personalization Test)",
            description="Test agent for the personalization system.",
        )

    def get_memory_config(self):
        use_falkordb = os.getenv("USE_FALKORDB", "true").lower() == "true"
        if use_falkordb:
            return MemoryConfig.graphiti_simple(
                use_falkordb=True,
                falkordb_host=os.getenv("FALKORDB_HOST", "localhost"),
                falkordb_port=int(os.getenv("FALKORDB_PORT", "6379")),
                environment=os.getenv("GRAPHITI_ENVIRONMENT", "dev"),
                passive_injection=True,
            )
        return MemoryConfig.graphiti_simple(
            use_falkordb=False,
            neo4j_uri=os.getenv("NEO4J_URI", ""),
            neo4j_user=os.getenv("NEO4J_USER", ""),
            neo4j_password=os.getenv("NEO4J_PASSWORD", ""),
            environment=os.getenv("GRAPHITI_ENVIRONMENT", "dev"),
            passive_injection=True,
            skip_index_creation=True,
        )

    def get_agent_prompt(self) -> str:
        return PROMPT

    def get_agent_tools(self):
        return []


def main():
    use_falkordb = os.getenv("USE_FALKORDB", "true").lower() == "true"
    memory_info = (
        f"FalkorDB ({os.getenv('FALKORDB_HOST', 'localhost')}:{os.getenv('FALKORDB_PORT', '6379')})"
        if use_falkordb
        else f"Neo4j ({os.getenv('NEO4J_URI', 'NOT SET')})"
    )
    personalization_on = os.getenv("PERSONALIZATION_ENABLED", "true").lower() != "false"

    from agent_framework import create_basic_agent_server

    port = int(os.getenv("AGENT_PORT", "8105"))
    print("=" * 60)
    print("🧪 Personalization Test Agent")
    print("=" * 60)
    print(f"🤖 Agent ID     : socrate-v1")
    print(f"🧠 Memory       : {memory_info}")
    print(f"🎨 Personalization: {'✅ enabled' if personalization_on else '❌ disabled'}")
    print(f"🌐 UI           : http://localhost:{port}/ui")
    print("=" * 60)

    create_basic_agent_server(
        agent_class=PersonalizationTestAgent,
        host="0.0.0.0",
        port=port,
        reload=False,
    )


if __name__ == "__main__":
    main()
