"""Tests for discover_mule_app main function (__init__.py)."""
import sys
from pathlib import Path
from unittest.mock import patch

from mule_discovery import discover_mule_app
from mule_discovery.models.scoring import ComplexityThresholds


def test_discover_simple_api(simple_api_path):
    """Basic end-to-end discovery produces expected result structure."""
    result = discover_mule_app(simple_api_path)
    assert result.app_name == "simple-api-app"
    assert len(result.flows) > 0
    assert result.summary is not None
    assert result.summary["flow_count"] > 0


def test_discover_no_xml_files(tmp_path, capsys):
    """App with no Mule XML files produces warning and minimal result."""
    (tmp_path / "pom.xml").write_text(
        '<project><artifactId>empty-app</artifactId></project>'
    )
    result = discover_mule_app(tmp_path)
    assert result.summary["flow_count"] == 0
    assert result.summary["scanned_files"] == []
    captured = capsys.readouterr()
    assert "No Mule XML files" in captured.err


def test_discover_parent_pom_warning(tmp_path):
    """App with parent POM produces warning."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="test"><logger message="hello" /></flow>
    </mule>''')
    (tmp_path / "pom.xml").write_text('''<project>
        <artifactId>child-app</artifactId>
        <parent><groupId>com.example</groupId></parent>
    </project>''')
    result = discover_mule_app(tmp_path)
    assert any("Parent POM" in w for w in result.warnings)


def test_discover_pom_read_exception(tmp_path):
    """pom.xml that can't be read doesn't crash discovery."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="test"><logger message="hello" /></flow>
    </mule>''')
    pom = tmp_path / "pom.xml"
    pom.mkdir()  # Directory instead of file - causes exception
    result = discover_mule_app(tmp_path)
    assert result is not None


def test_discover_listener_config_parse_error(tmp_path, capsys):
    """Malformed XML file in first pass (listener config) is handled."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="test"><logger message="hello" /></flow>
    </mule>''')
    (mule_dir / "broken.xml").write_text("<<<not valid xml>>>")
    result = discover_mule_app(tmp_path)
    # Should still process the valid file
    assert result is not None


def test_discover_dynamic_flow_ref(tmp_path):
    """Dynamic flow-ref produces warning."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="test">
            <flow-ref name="#[vars.targetFlow]" />
        </flow>
    </mule>''')
    result = discover_mule_app(tmp_path)
    assert any("Dynamic flow-ref" in w for w in result.warnings)


def test_discover_property_placeholder(tmp_path):
    """Property placeholder in critical attribute produces warning."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core"
              xmlns:http="http://www.mulesoft.org/schema/mule/http">
        <http:request-config name="cfg" host="${{backend.host}}" port="443" />
        <flow name="test">
            <logger message="hello" />
        </flow>
    </mule>''')
    result = discover_mule_app(tmp_path)
    assert any("Property placeholder" in w for w in result.warnings)


def test_discover_xml_parse_error(tmp_path, capsys):
    """XML parse error in main loop produces warning."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "valid.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="test"><logger message="hello" /></flow>
    </mule>''')
    (mule_dir / "invalid.xml").write_text("<<<invalid xml>>>")
    result = discover_mule_app(tmp_path)
    captured = capsys.readouterr()
    assert "Warning:" in captured.err


def test_discover_listener_endpoint_matching(simple_api_path):
    """HTTP listeners get endpoint info from matching flows."""
    result = discover_mule_app(simple_api_path)
    # Check that listeners have endpoints populated
    if result.http_listeners:
        listener = result.http_listeners[0]
        # Simple API has flows with http listeners
        assert listener.config_name


def test_discover_error_handler_flow_id(simple_api_path):
    """Error handlers get flow_id populated from flow_name_to_id map."""
    result = discover_mule_app(simple_api_path)
    for eh in result.error_handling:
        if eh.flow_name in {f.name for f in result.flows}:
            assert eh.flow_id.startswith("FLOW-")


def test_discover_dep_dedup(tmp_path):
    """External dependencies with same name are deduplicated."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core"
              xmlns:http="http://www.mulesoft.org/schema/mule/http">
        <flow name="f1">
            <http:request config-ref="backendConfig" path="/a" />
        </flow>
        <flow name="f2">
            <http:request config-ref="backendConfig" path="/b" />
        </flow>
    </mule>''')
    result = discover_mule_app(tmp_path)
    # Should have only one EXT dep for backendConfig
    names = [d["name"] for d in result.external_dependencies]
    assert names.count("backendConfig") == 1


def test_discover_with_api_spec(simple_api_path):
    """If API specification is found, api_spec_count incremented."""
    result = discover_mule_app(simple_api_path)
    api_spec_count = result.summary.get("api_spec_count", 0)
    if result.api_specification:
        assert api_spec_count >= 1


def test_discover_flow_source_none_and_path_none(tmp_path):
    """Flows without source or without path don't add listener endpoints."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core"
              xmlns:http="http://www.mulesoft.org/schema/mule/http">
        <http:listener-config name="httpCfg">
            <http:listener-connection host="0.0.0.0" port="8081" />
        </http:listener-config>
        <sub-flow name="helper">
            <logger message="no source" />
        </sub-flow>
        <flow name="noPath">
            <http:listener config-ref="httpCfg" />
            <logger message="no path" />
        </flow>
    </mule>''')
    result = discover_mule_app(tmp_path)
    # Should not crash; sub-flow has no source, flow has no path
    assert result is not None


def test_discover_general_exception(tmp_path, capsys):
    """Exception (not ParseError) during XML processing is caught."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    # Valid XML but will cause exception during processing
    (mule_dir / "valid.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="test"><logger message="hello" /></flow>
    </mule>''')

    with patch("mule_discovery.extract_flows", side_effect=RuntimeError("test error")):
        result = discover_mule_app(tmp_path)
    captured = capsys.readouterr()
    assert "Warning:" in captured.err
    assert "test error" in captured.err


def test_discover_with_api_spec_count(tmp_path):
    """API spec count includes main spec."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="test"><logger message="hello" /></flow>
    </mule>''')
    api_dir = tmp_path / "src" / "main" / "resources"
    api_dir.mkdir(parents=True)
    (api_dir / "api.yaml").write_text("openapi: 3.0.0\ninfo:\n  version: 1.0\n")
    result = discover_mule_app(tmp_path)
    assert result.api_specification is not None
    assert result.summary["api_spec_count"] >= 1


def test_discover_static_flow_ref(tmp_path):
    """Static flow-ref does NOT produce dynamic warning."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="main">
            <flow-ref name="helper" />
        </flow>
        <sub-flow name="helper">
            <logger message="hello" />
        </sub-flow>
    </mule>''')
    result = discover_mule_app(tmp_path)
    assert not any("Dynamic flow-ref" in w for w in result.warnings)


def test_discover_with_duplicate_deps(tmp_path):
    """Duplicate external dependencies are deduplicated."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core"
              xmlns:http="http://www.mulesoft.org/schema/mule/http">
        <flow name="f1"><http:request config-ref="backend" path="/a" /></flow>
        <flow name="f2"><http:request config-ref="backend" path="/b" /></flow>
    </mule>''')
    result = discover_mule_app(tmp_path)
    # Should be deduplicated
    names = [d["name"] for d in result.external_dependencies]
    assert names.count("backend") == 1


def test_discover_error_handler_id_mapping(tmp_path):
    """Error handler gets flow_id from flow_name_to_id mapping."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core">
        <flow name="testFlow">
            <logger message="test" />
            <error-handler>
                <on-error-continue><logger message="err" /></on-error-continue>
            </error-handler>
        </flow>
    </mule>''')
    result = discover_mule_app(tmp_path)
    assert len(result.error_handling) >= 1
    # error handler flow_name should match and flow_id should be set
    eh = result.error_handling[0]
    assert eh.flow_id.startswith("FLOW-")


def test_discover_placeholder_warned_break(tmp_path):
    """Property placeholder detection breaks after first warning per file."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core"
              xmlns:http="http://www.mulesoft.org/schema/mule/http">
        <http:request-config name="cfg1" host="${{host1}}" port="${{port1}}" />
        <http:request-config name="cfg2" host="${{host2}}" />
        <flow name="test"><logger message="hello" /></flow>
    </mule>''')
    result = discover_mule_app(tmp_path)
    # Should only warn once per file due to placeholder_warned break
    placeholder_warnings = [w for w in result.warnings if "Property placeholder" in w]
    assert len(placeholder_warnings) == 1
