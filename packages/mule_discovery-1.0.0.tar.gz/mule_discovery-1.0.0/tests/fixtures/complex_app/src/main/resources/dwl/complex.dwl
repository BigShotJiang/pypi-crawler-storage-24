%dw 2.0
output application/json
var grouped = payload groupBy $.category
fun formatItem(item) = {
    id: item.id,
    label: item.name ++ " - " ++ item.category
}
---
grouped reduce ((value, acc = {}) ->
    acc ++ {(value[0].category): value map formatItem($)}
)
