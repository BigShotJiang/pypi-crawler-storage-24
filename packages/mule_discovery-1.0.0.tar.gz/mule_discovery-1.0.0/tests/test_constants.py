"""Tests for constants module."""
from mule_discovery.constants import (
    NAMESPACES, NS_TO_PREFIX, CONNECTOR_MIGRATION_WEIGHTS,
    WSDL_NS, SOAP11_NS, SOAP12_NS, XS_NS,
    SOURCE_ELEMENTS, PROCESSOR_ELEMENTS, CONTAINER_ELEMENTS,
    TERMINAL_PROCESSOR_ELEMENTS, CONFIG_ELEMENTS, PATTERN_ELEMENTS,
    REFERENCE_ELEMENTS, ASYNC_PROCESSORS,
)


def test_ns_to_prefix_is_inverse_of_namespaces():
    # Every URI in NS_TO_PREFIX must map back to a valid prefix in NAMESPACES
    for uri, prefix in NS_TO_PREFIX.items():
        assert prefix in NAMESPACES
        assert NAMESPACES[prefix] == uri
    # Every URI in NAMESPACES must be in NS_TO_PREFIX
    for prefix, uri in NAMESPACES.items():
        assert uri in NS_TO_PREFIX


def test_connector_weights_have_valid_values():
    valid_weights = {"high", "medium", "low"}
    for key, weight in CONNECTOR_MIGRATION_WEIGHTS.items():
        assert weight in valid_weights, f"{key} has invalid weight {weight}"


def test_wsdl_constants_are_non_empty():
    assert WSDL_NS
    assert SOAP11_NS
    assert SOAP12_NS
    assert XS_NS


def test_element_sets_are_disjoint():
    assert SOURCE_ELEMENTS.isdisjoint(CONFIG_ELEMENTS)
    assert SOURCE_ELEMENTS.isdisjoint(REFERENCE_ELEMENTS)
    assert CONFIG_ELEMENTS.isdisjoint(REFERENCE_ELEMENTS)


def test_async_processors_not_empty():
    assert len(ASYNC_PROCESSORS) > 0


def test_pattern_elements_not_empty():
    assert len(PATTERN_ELEMENTS) > 0
    assert "choice" in PATTERN_ELEMENTS
    assert "scatter-gather" in PATTERN_ELEMENTS


def test_terminal_processors_include_transforms():
    assert "ee:transform" in TERMINAL_PROCESSOR_ELEMENTS
    assert "dw:transform-message" in TERMINAL_PROCESSOR_ELEMENTS
