"""Tests for xml_helpers module."""
from xml.etree import ElementTree as ET
from pathlib import Path
import tempfile

from mule_discovery.xml_helpers import (
    get_element_tag, get_qualified_name,
    is_source_element, is_container_element, is_config_element,
    is_reference_element, is_terminal_processor, is_processor_element,
    is_pattern_element, has_apikit_console,
    find_element_line_number, find_transform_line_numbers,
)
from mule_discovery.constants import NAMESPACES


def _elem(tag):
    """Create element with optional namespace."""
    return ET.Element(tag)


def test_get_element_tag_with_namespace():
    elem = _elem(f'{{{NAMESPACES["http"]}}}listener')
    prefix, local = get_element_tag(elem)
    assert prefix == "http"
    assert local == "listener"


def test_get_element_tag_without_namespace():
    elem = _elem("logger")
    prefix, local = get_element_tag(elem)
    assert prefix == ""
    assert local == "logger"


def test_get_element_tag_unknown_namespace():
    elem = _elem("{http://unknown.ns}foo")
    prefix, local = get_element_tag(elem)
    assert prefix == ""
    assert local == "foo"


def test_get_qualified_name_with_prefix():
    elem = _elem(f'{{{NAMESPACES["http"]}}}listener')
    assert get_qualified_name(elem) == "http:listener"


def test_get_qualified_name_without_prefix():
    elem = _elem("logger")
    assert get_qualified_name(elem) == "logger"


def test_is_source_element_true():
    elem = _elem(f'{{{NAMESPACES["http"]}}}listener')
    assert is_source_element(elem) is True


def test_is_source_element_scheduler():
    elem = _elem("scheduler")
    assert is_source_element(elem) is True


def test_is_source_element_false():
    elem = _elem(f'{{{NAMESPACES["http"]}}}request')
    assert is_source_element(elem) is False


def test_is_container_element_true():
    elem = _elem("error-handler")
    assert is_container_element(elem) is True


def test_is_container_element_with_ns():
    elem = _elem(f'{{{NAMESPACES["batch"]}}}job')
    assert is_container_element(elem) is True


def test_is_container_element_false():
    elem = _elem("logger")
    assert is_container_element(elem) is False


def test_is_config_element_true():
    elem = _elem(f'{{{NAMESPACES["http"]}}}listener-config')
    assert is_config_element(elem) is True


def test_is_config_element_suffix():
    elem = _elem("custom-config")
    assert is_config_element(elem) is True


def test_is_config_element_connection_suffix():
    elem = _elem("custom-connection")
    assert is_config_element(elem) is True


def test_is_config_element_false():
    elem = _elem("logger")
    assert is_config_element(elem) is False


def test_is_reference_element_true():
    elem = _elem("exception-strategy")
    elem.set("ref", "globalHandler")
    assert is_reference_element(elem) is True


def test_is_reference_element_no_ref():
    elem = _elem("exception-strategy")
    assert is_reference_element(elem) is False


def test_is_reference_element_other():
    elem = _elem("logger")
    assert is_reference_element(elem) is False


def test_is_terminal_processor_true():
    elem = _elem(f'{{{NAMESPACES["ee"]}}}transform')
    assert is_terminal_processor(elem) is True


def test_is_terminal_processor_local():
    elem = _elem("transform")
    assert is_terminal_processor(elem) is True


def test_is_terminal_processor_false():
    elem = _elem("logger")
    assert is_terminal_processor(elem) is False


def test_is_processor_element_true():
    elem = _elem("logger")
    assert is_processor_element(elem) is True


def test_is_processor_element_source():
    elem = _elem(f'{{{NAMESPACES["http"]}}}listener')
    assert is_processor_element(elem) is False


def test_is_processor_element_config():
    elem = _elem(f'{{{NAMESPACES["http"]}}}listener-config')
    assert is_processor_element(elem) is False


def test_is_processor_element_empty_local():
    # Edge case: element tag is just a namespace brace with no local name
    elem = _elem(f'{{{NAMESPACES["http"]}}}')
    # This results in local_name being ""
    # The function should return False for empty local names
    result = is_processor_element(elem)
    # With empty local_name, returns False
    assert result is False


def test_is_pattern_element():
    elem = _elem("choice")
    assert is_pattern_element(elem) is True
    elem2 = _elem("logger")
    assert is_pattern_element(elem2) is False


def test_has_apikit_console_true():
    flow = ET.fromstring(f'''<flow xmlns:apikit="{NAMESPACES["apikit"]}">
        <apikit:console />
    </flow>''')
    assert has_apikit_console(flow) is True


def test_has_apikit_console_false():
    flow = ET.fromstring('<flow><logger message="test"/></flow>')
    assert has_apikit_console(flow) is False


def test_find_element_line_number():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')
        f.write('  <flow name="testFlow">\n')
        f.write('    <logger/>\n')
        f.write('  </flow>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "testFlow", "flow") == 2
    path.unlink()


def test_find_element_line_number_multiline():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')
        f.write('  <flow\n')
        f.write('    name="testFlow">\n')
        f.write('    <logger/>\n')
        f.write('  </flow>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "testFlow", "flow") == 2
    path.unlink()


def test_find_element_line_number_not_found():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule><flow name="other"></flow></mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "missing", "flow") == 0
    path.unlink()


def test_find_element_line_number_batch_job():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')
        f.write('  <batch:job jobName="myJob">\n')
        f.write('  </batch:job>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "myJob", "batch:job") == 2
    path.unlink()


def test_find_element_line_number_various_types():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')
        f.write('  <http:listener-config name="myConfig" />\n')
        f.write('  <http:request-config name="reqConfig" />\n')
        f.write('  <db:config name="dbConfig" />\n')
        f.write('  <sftp:config name="sftpConfig" />\n')
        f.write('  <ee:transform doc:name="myTransform" />\n')
        f.write('  <custom:config name="customConfig" />\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "myConfig", "listener-config") == 2
    assert find_element_line_number(path, "reqConfig", "request-config") == 3
    assert find_element_line_number(path, "dbConfig", "db-config") == 4
    assert find_element_line_number(path, "sftpConfig", "sftp-config") == 5
    assert find_element_line_number(path, "myTransform", "transform") == 6
    assert find_element_line_number(path, "customConfig", "config") == 7
    path.unlink()


def test_find_element_line_number_missing_file():
    assert find_element_line_number(Path("/nonexistent.xml"), "test", "flow") == 0


def test_find_transform_line_numbers():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')
        f.write('  <flow>\n')
        f.write('    <ee:transform />\n')
        f.write('    <logger />\n')
        f.write('    <ee:transform />\n')
        f.write('  </flow>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    result = find_transform_line_numbers(path)
    assert result == [3, 5]
    path.unlink()


def test_find_transform_line_numbers_missing_file():
    result = find_transform_line_numbers(Path("/nonexistent.xml"))
    assert result == []


def test_find_element_line_number_sub_flow():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')
        f.write('  <sub-flow name="helper">\n')
        f.write('    <logger/>\n')
        f.write('  </sub-flow>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "helper", "sub-flow") == 2
    path.unlink()


def test_find_element_line_number_default_type():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')
        f.write('  <custom-element name="test">\n')
        f.write('  </custom-element>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "test", "custom-element") == 2
    path.unlink()


def test_find_element_line_number_multiline_not_found():
    """Tag found but name not in accumulated lines before closing >."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')
        f.write('  <flow\n')
        f.write('    name="otherFlow">\n')
        f.write('  </flow>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "missingFlow", "flow") == 0
    path.unlink()


def test_is_processor_element_reference():
    """Reference element (exception-strategy with ref) is not a processor."""
    elem = _elem("exception-strategy")
    elem.set("ref", "globalHandler")
    assert is_processor_element(elem) is False


def test_is_processor_element_container():
    """Container element is not a processor."""
    elem = _elem("error-handler")
    assert is_processor_element(elem) is False


def test_has_apikit_console_non_console_apikit():
    """Flow with apikit element that is not console returns False."""
    flow = ET.fromstring(f'''<flow xmlns:apikit="{NAMESPACES["apikit"]}">
        <apikit:router />
    </flow>''')
    assert has_apikit_console(flow) is False


def test_has_apikit_console_console_without_apikit_ns():
    """Element named 'console' but without apikit in tag."""
    flow = ET.fromstring('<flow><console /></flow>')
    assert has_apikit_console(flow) is False


def test_find_element_line_number_multiline_span_multiple_lines():
    """Tag found on one line, name on a line much later (multiple lines to accumulate)."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')                   # line 1
        f.write('  <flow\n')                  # line 2 - tag found
        f.write('    attr1="value1"\n')       # line 3 - no name, no >
        f.write('    attr2="value2"\n')       # line 4 - no name, no >
        f.write('    name="multiLineFlow">\n')  # line 5 - name found
        f.write('    <logger/>\n')
        f.write('  </flow>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "multiLineFlow", "flow") == 2
    path.unlink()


def test_find_element_line_number_multiline_close_before_name():
    """Tag spans multiple lines but closes (>) before name is found."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False) as f:
        f.write('<mule>\n')                   # line 1
        f.write('  <flow\n')                  # line 2
        f.write('    name="otherFlow">\n')    # line 3 - different name, closes
        f.write('  </flow>\n')
        f.write('  <flow name="target">\n')   # line 5
        f.write('  </flow>\n')
        f.write('</mule>\n')
        path = Path(f.name)
    assert find_element_line_number(path, "target", "flow") == 5
    path.unlink()
