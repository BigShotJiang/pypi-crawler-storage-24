"""Tests for DataWeave parser."""
from xml.etree import ElementTree as ET
from pathlib import Path

from mule_discovery.parsers.dataweave import (
    extract_dataweave_script, extract_dataweave_structure,
    find_external_dwl_file,
)
from mule_discovery.constants import NAMESPACES


def test_extract_inline_script():
    xml = f'''<ee:transform xmlns:ee="{NAMESPACES['ee']}">
        <ee:message>
            <ee:set-payload>%dw 2.0
output application/json
---
payload</ee:set-payload>
        </ee:message>
    </ee:transform>'''
    elem = ET.fromstring(xml)
    script, external = extract_dataweave_script(elem)
    assert "payload" in script
    assert external is None


def test_extract_external_ref():
    xml = f'''<ee:transform xmlns:ee="{NAMESPACES['ee']}">
        <ee:message>
            <ee:set-payload resource="classpath:dwl/transform.dwl" />
        </ee:message>
    </ee:transform>'''
    elem = ET.fromstring(xml)
    script, external = extract_dataweave_script(elem)
    assert external == "transform.dwl"


def test_extract_structure():
    script = """%dw 2.0
output application/json
---
{
    id: payload.id,
    name: payload.name,
    ref: vars.myVar
}"""
    result = extract_dataweave_structure(script)
    assert result["dw_version"] == "2.0"
    assert "payload.id" in result["input_fields"]
    assert "vars.myVar" in result["vars_references"]
    assert "id" in result["output_fields"]


def test_extract_structure_empty():
    assert extract_dataweave_structure("") == {}
    assert extract_dataweave_structure(None) == {}


def test_extract_structure_attributes():
    script = """%dw 2.0
output application/json
---
{
    method: attributes.method,
    path: attributes.requestPath
}"""
    result = extract_dataweave_structure(script)
    assert len(result["attributes_references"]) == 2


def test_extract_structure_type_hints():
    script = """%dw 2.0
%input payload application/json
%output application/xml
---
payload"""
    result = extract_dataweave_structure(script)
    assert result["has_type_hints"] is True


def test_find_external_dwl_file(complex_app_path):
    result = find_external_dwl_file("classpath:dwl/simple.dwl", complex_app_path)
    assert result is not None
    assert result.name == "simple.dwl"


def test_find_external_dwl_file_missing(tmp_path):
    result = find_external_dwl_file("classpath:missing.dwl", tmp_path)
    assert result is None


def test_find_external_dwl_file_empty():
    assert find_external_dwl_file("", Path("/tmp")) is None
    assert find_external_dwl_file(None, Path("/tmp")) is None


def test_extract_external_script_with_file(complex_app_path):
    """Extract script from external DWL file via classpath reference."""
    xml = f'''<ee:transform xmlns:ee="{NAMESPACES['ee']}">
        <ee:message>
            <ee:set-payload resource="classpath:dwl/simple.dwl" />
        </ee:message>
    </ee:transform>'''
    elem = ET.fromstring(xml)
    script, external = extract_dataweave_script(elem, complex_app_path)
    assert external == "simple.dwl"
    # Should have loaded the script content from the file
    assert len(script) > 0


def test_extract_set_variable():
    """set-variable with inline DW script."""
    xml = f'''<ee:transform xmlns:ee="{NAMESPACES['ee']}">
        <ee:variables>
            <ee:set-variable variableName="myVar">%dw 2.0
output application/java
---
payload.name</ee:set-variable>
        </ee:variables>
    </ee:transform>'''
    elem = ET.fromstring(xml)
    script, external = extract_dataweave_script(elem)
    assert "payload.name" in script
    assert external is None


def test_extract_external_script_file_not_found(tmp_path):
    """External DWL reference where file doesn't exist."""
    xml = f'''<ee:transform xmlns:ee="{NAMESPACES['ee']}">
        <ee:message>
            <ee:set-payload resource="classpath:dwl/missing.dwl" />
        </ee:message>
    </ee:transform>'''
    elem = ET.fromstring(xml)
    script, external = extract_dataweave_script(elem, tmp_path)
    assert external == "missing.dwl"
    assert script == ""


def test_extract_external_script_unreadable(tmp_path):
    """External DWL file that can't be read."""
    dwl_dir = tmp_path / "src" / "main" / "resources" / "dwl"
    dwl_dir.mkdir(parents=True)
    bad_file = dwl_dir / "broken.dwl"
    bad_file.mkdir()  # Directory, not file - causes read exception
    xml = f'''<ee:transform xmlns:ee="{NAMESPACES['ee']}">
        <ee:message>
            <ee:set-payload resource="classpath:dwl/broken.dwl" />
        </ee:message>
    </ee:transform>'''
    elem = ET.fromstring(xml)
    script, external = extract_dataweave_script(elem, tmp_path)
    assert external == "broken.dwl"
    assert script == ""


def test_extract_external_script_empty_file(tmp_path):
    """External DWL file that is empty."""
    dwl_dir = tmp_path / "src" / "main" / "resources" / "dwl"
    dwl_dir.mkdir(parents=True)
    (dwl_dir / "empty.dwl").write_text("")
    xml = f'''<ee:transform xmlns:ee="{NAMESPACES['ee']}">
        <ee:message>
            <ee:set-payload resource="classpath:dwl/empty.dwl" />
        </ee:message>
    </ee:transform>'''
    elem = ET.fromstring(xml)
    script, external = extract_dataweave_script(elem, tmp_path)
    assert external == "empty.dwl"
    assert script == ""
