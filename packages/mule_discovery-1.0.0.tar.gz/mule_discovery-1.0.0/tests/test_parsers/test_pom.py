"""Tests for POM parser."""
from pathlib import Path
from mule_discovery.parsers.pom import (
    extract_app_name, extract_mule_version, extract_connectors_from_pom,
    update_connector_usage, get_connector_key, load_migration_config,
)
from mule_discovery.models.connectors import ConnectorInfo
from mule_discovery.models.flows import FlowInfo


def test_extract_app_name(simple_api_path):
    assert extract_app_name(simple_api_path) == "simple-api-app"


def test_extract_app_name_missing_pom(tmp_path):
    assert extract_app_name(tmp_path) == tmp_path.name


def test_extract_mule_version_from_pom(simple_api_path):
    version = extract_mule_version(simple_api_path)
    assert version == "4.4.0"


def test_extract_mule_version_from_mule3(mule3_app_path):
    version = extract_mule_version(mule3_app_path)
    assert version == "3.9.4"


def test_extract_mule_version_missing(tmp_path):
    assert extract_mule_version(tmp_path) == ""


def test_extract_connectors_from_pom(simple_api_path):
    connectors = extract_connectors_from_pom(simple_api_path)
    names = [c.name for c in connectors]
    assert "mule-http-connector" in names
    assert "mule-db-connector" in names


def test_extract_connectors_missing_pom(tmp_path):
    assert extract_connectors_from_pom(tmp_path) == []


def test_get_connector_key():
    assert get_connector_key("mule-http-connector") == "http"
    assert get_connector_key("mule-db-connector") == "db"
    # module- prefix is stripped, but -module suffix only strips "module-" prefix
    assert "apikit" in get_connector_key("mule-apikit-module")


def test_update_connector_usage():
    connectors = [ConnectorInfo(name="mule-http-connector")]
    flows = [FlowInfo(id="F1", name="test", type="API", source_file="t.xml",
                       components=["http:request", "http:request", "logger"])]
    update_connector_usage(connectors, flows)
    assert connectors[0].usage_count == 2


def test_load_migration_config_missing():
    config = load_migration_config(Path("/nonexistent/config.yaml"))
    assert config == {"connector_mappings": {}}


def test_extract_mule_version_from_artifact_json(tmp_path):
    (tmp_path / "mule-artifact.json").write_text('{"minMuleVersion": "4.6.0"}')
    version = extract_mule_version(tmp_path)
    assert version == "4.6.0"


def test_extract_mule_version_from_mule_project_xml(tmp_path):
    (tmp_path / "mule-project.xml").write_text(
        '<mule-project runtimeId="org.mule.runtime:mule:3.9.4" />'
    )
    version = extract_mule_version(tmp_path)
    assert version == "3.9.4"


def test_extract_app_name_bad_xml(tmp_path):
    """Malformed pom.xml falls back to directory name."""
    (tmp_path / "pom.xml").write_text("not xml at all")
    assert extract_app_name(tmp_path) == tmp_path.name


def test_extract_connectors_from_pom_bad_xml(tmp_path):
    """Malformed pom.xml returns empty list."""
    (tmp_path / "pom.xml").write_text("not xml")
    assert extract_connectors_from_pom(tmp_path) == []


def test_extract_connectors_no_mapping(tmp_path):
    """Connectors without config mapping get a notes string."""
    pom = '''<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency>
            <groupId>com.mulesoft</groupId>
            <artifactId>mule-weird-connector</artifactId>
        </dependency>
    </dependencies>
</project>'''
    (tmp_path / "pom.xml").write_text(pom)
    connectors = extract_connectors_from_pom(tmp_path)
    assert len(connectors) == 1
    assert "agent resolution" in connectors[0].notes.lower()


def test_update_connector_usage_multiple_prefixes():
    connectors = [
        ConnectorInfo(name="mule-http-connector"),
        ConnectorInfo(name="mule-db-connector"),
    ]
    flows = [FlowInfo(id="F1", name="test", type="API", source_file="t.xml",
                       components=["http:request", "db:select", "db:insert", "logger"])]
    update_connector_usage(connectors, flows)
    assert connectors[0].usage_count == 1
    assert connectors[1].usage_count == 2


def test_load_migration_config_bad_yaml(tmp_path):
    """Malformed YAML falls back to empty config."""
    config_file = tmp_path / "bad.yaml"
    config_file.write_text("{{{{invalid yaml")
    config = load_migration_config(config_file)
    assert config == {"connector_mappings": {}}


def test_extract_mule_version_bad_artifact_json(tmp_path):
    """Malformed mule-artifact.json falls through to pom."""
    (tmp_path / "mule-artifact.json").write_text("not json")
    version = extract_mule_version(tmp_path)
    assert version == ""


def test_extract_mule_version_bad_project_xml(tmp_path):
    """Malformed mule-project.xml falls through to pom."""
    (tmp_path / "mule-project.xml").write_text("not xml at all")
    version = extract_mule_version(tmp_path)
    assert version == ""


def test_extract_mule_version_bad_pom(tmp_path):
    """Malformed pom.xml returns empty version."""
    (tmp_path / "pom.xml").write_text("not xml at all")
    version = extract_mule_version(tmp_path)
    assert version == ""


def test_extract_mule_version_pom_mule_version(tmp_path):
    """Extract from <mule.version> in pom.xml."""
    (tmp_path / "pom.xml").write_text('''<project>
        <properties><mule.version>3.8.0</mule.version></properties>
    </project>''')
    version = extract_mule_version(tmp_path)
    assert version == "3.8.0"


def test_extract_app_name_no_artifact_id(tmp_path):
    """pom.xml without artifactId falls back to dir name."""
    (tmp_path / "pom.xml").write_text('<project><groupId>com.example</groupId></project>')
    assert extract_app_name(tmp_path) == tmp_path.name


def test_extract_connectors_with_mapping(tmp_path):
    """Connector with config mapping gets spring dependencies."""
    pom = '''<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency>
            <groupId>com.mulesoft</groupId>
            <artifactId>mule-http-connector</artifactId>
        </dependency>
    </dependencies>
</project>'''
    (tmp_path / "pom.xml").write_text(pom)
    config = {
        "connector_mappings": {
            "http": [{"groupId": "org.springframework", "artifactId": "spring-web", "version": "6.0.0"}],
        }
    }
    connectors = extract_connectors_from_pom(tmp_path, config)
    assert len(connectors) == 1
    assert len(connectors[0].spring_dependencies) == 1
    assert connectors[0].spring_dependencies[0].groupId == "org.springframework"


def test_extract_mule_version_project_xml_no_version(tmp_path):
    """mule-project.xml without version pattern falls through."""
    (tmp_path / "mule-project.xml").write_text('<mule-project runtimeId="no-version" />')
    version = extract_mule_version(tmp_path)
    assert version == ""


def test_extract_connectors_non_connector_dep(tmp_path):
    """Dependencies without 'connector' or 'module' in name are skipped."""
    pom = '''<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency><artifactId>spring-core</artifactId></dependency>
        <dependency><artifactId>mule-http-connector</artifactId></dependency>
    </dependencies>
</project>'''
    (tmp_path / "pom.xml").write_text(pom)
    connectors = extract_connectors_from_pom(tmp_path)
    assert len(connectors) == 1
    assert connectors[0].name == "mule-http-connector"


def test_extract_connectors_empty_dependency(tmp_path):
    """Dependency element with no children is handled."""
    pom = '''<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency />
        <dependency><artifactId>mule-http-connector</artifactId></dependency>
    </dependencies>
</project>'''
    (tmp_path / "pom.xml").write_text(pom)
    connectors = extract_connectors_from_pom(tmp_path)
    assert len(connectors) == 1


def test_extract_connectors_dedup(tmp_path):
    """Duplicate connector artifacts should be deduplicated."""
    pom = '''<?xml version="1.0"?>
<project>
    <dependencies>
        <dependency><artifactId>mule-http-connector</artifactId></dependency>
        <dependency><artifactId>mule-http-connector</artifactId></dependency>
    </dependencies>
</project>'''
    (tmp_path / "pom.xml").write_text(pom)
    connectors = extract_connectors_from_pom(tmp_path)
    http_conns = [c for c in connectors if c.name == "mule-http-connector"]
    assert len(http_conns) == 1
