"""Tests for WSDL parser."""
from pathlib import Path
from mule_discovery.parsers.wsdl import parse_wsdl, resolve_wsdl_path


def test_parse_wsdl(soap_app_path):
    wsdl_path = soap_app_path / "src" / "main" / "resources" / "wsdl" / "service.wsdl"
    result = parse_wsdl(wsdl_path)
    assert result is not None
    assert result["operation_count"] == 2
    assert result["soap_version"] == "1.1"


def test_parse_wsdl_malformed(tmp_path):
    bad_file = tmp_path / "bad.wsdl"
    bad_file.write_text("not xml")
    assert parse_wsdl(bad_file) is None


def test_resolve_wsdl_path_classpath(soap_app_path):
    result = resolve_wsdl_path("classpath:wsdl/service.wsdl", soap_app_path)
    assert result is not None


def test_resolve_wsdl_path_http():
    assert resolve_wsdl_path("http://example.com/service.wsdl", Path("/tmp")) is None
    assert resolve_wsdl_path("https://example.com/service.wsdl", Path("/tmp")) is None


def test_resolve_wsdl_path_not_found():
    assert resolve_wsdl_path("classpath:missing.wsdl", Path("/tmp")) is None


def test_resolve_wsdl_path_empty():
    assert resolve_wsdl_path("", Path("/tmp")) is None


def test_parse_wsdl_soap12(tmp_path):
    """WSDL with SOAP 1.2 binding should be detected."""
    wsdl_content = '''<?xml version="1.0"?>
<definitions xmlns="http://schemas.xmlsoap.org/wsdl/"
             xmlns:soap12="http://schemas.xmlsoap.org/wsdl/soap12/"
             xmlns:xs="http://www.w3.org/2001/XMLSchema">
    <types><xs:schema targetNamespace="http://example.com" /></types>
    <portType name="MyPort">
        <operation name="op1" />
    </portType>
    <binding name="MyBinding" type="tns:MyPort">
        <soap12:binding style="document" transport="http://schemas.xmlsoap.org/soap/http" />
    </binding>
</definitions>'''
    wsdl_file = tmp_path / "soap12.wsdl"
    wsdl_file.write_text(wsdl_content)
    result = parse_wsdl(wsdl_file)
    assert result is not None
    assert result["soap_version"] == "1.2"
    assert result["operation_count"] == 1


def test_parse_wsdl_no_schema(tmp_path):
    """WSDL without xs:schema element."""
    wsdl_content = '''<?xml version="1.0"?>
<definitions xmlns="http://schemas.xmlsoap.org/wsdl/">
    <portType name="MyPort">
        <operation name="op1" />
    </portType>
</definitions>'''
    wsdl_file = tmp_path / "noschema.wsdl"
    wsdl_file.write_text(wsdl_content)
    result = parse_wsdl(wsdl_file)
    assert result is not None
    assert result["target_namespace"] == ""
    assert result["element_form_default"] == "unqualified"


def test_parse_wsdl_operation_no_name(tmp_path):
    """WSDL operation without name attribute should be skipped."""
    wsdl_content = '''<?xml version="1.0"?>
<definitions xmlns="http://schemas.xmlsoap.org/wsdl/"
             xmlns:xs="http://www.w3.org/2001/XMLSchema">
    <types><xs:schema targetNamespace="http://example.com" /></types>
    <portType name="MyPort">
        <operation name="validOp" />
        <operation />
    </portType>
</definitions>'''
    wsdl_file = tmp_path / "test.wsdl"
    wsdl_file.write_text(wsdl_content)
    result = parse_wsdl(wsdl_file)
    assert result["operation_count"] == 1
