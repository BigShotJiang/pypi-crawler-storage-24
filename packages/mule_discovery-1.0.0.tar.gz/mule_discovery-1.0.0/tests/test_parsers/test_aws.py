"""Tests for AWS parser."""
from xml.etree import ElementTree as ET
from mule_discovery.parsers.aws import extract_aws_services
from mule_discovery.constants import NAMESPACES


def test_extract_sqs(tmp_path):
    xml = f'''<mule xmlns:sqs="{NAMESPACES['sqs']}">
        <sqs:config name="sqsConfig">
            <sqs:basic-connection accessKey="key" secretKey="secret" region="us-east-1" />
        </sqs:config>
        <flow name="test">
            <sqs:send-message config-ref="sqsConfig" queueUrl="myQueue" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["sqs"]) == 1
    assert result["sqs"][0]["config_name"] == "sqsConfig"
    assert len(result["sqs"][0]["operations"]) == 1


def test_extract_aws_empty(tmp_path):
    xml = '<mule xmlns="http://www.mulesoft.org/schema/mule/core" />'
    xml_file = tmp_path / "empty.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert result == {"sqs": [], "s3": [], "dynamodb": []}


def test_extract_s3(tmp_path):
    xml = f'''<mule xmlns:s3="{NAMESPACES['s3']}">
        <s3:config name="s3Config">
            <s3:basic-connection accessKey="key" secretKey="secret" region="us-west-2" />
        </s3:config>
        <flow name="test">
            <s3:put-object config-ref="s3Config" bucketName="myBucket" />
            <s3:get-object config-ref="s3Config" bucketName="myBucket" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["s3"]) == 1
    assert result["s3"][0]["config_name"] == "s3Config"
    assert len(result["s3"][0]["operations"]) == 2


def test_extract_dynamodb(tmp_path):
    xml = f'''<mule xmlns:dynamodb="{NAMESPACES['dynamodb']}">
        <dynamodb:config name="dynamoConfig">
            <dynamodb:basic-connection accessKey="key" secretKey="secret" region="eu-west-1" />
        </dynamodb:config>
        <flow name="test">
            <dynamodb:put-item config-ref="dynamoConfig" tableName="users" />
            <dynamodb:query config-ref="dynamoConfig" tableName="users" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["dynamodb"]) == 1
    assert len(result["dynamodb"][0]["operations"]) == 2


def test_extract_sqs_deduplicates(tmp_path):
    xml = f'''<mule xmlns:sqs="{NAMESPACES['sqs']}">
        <sqs:config name="sqsConfig">
            <sqs:basic-connection accessKey="key" secretKey="secret" region="us-east-1" />
        </sqs:config>
        <flow name="test1">
            <sqs:send-message config-ref="sqsConfig" queueUrl="q1" />
        </flow>
        <flow name="test2">
            <sqs:send-message config-ref="sqsConfig" queueUrl="q1" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["sqs"]) == 1
    assert len(result["sqs"][0]["operations"]) == 1


def test_extract_aws_existing_services(tmp_path):
    xml = f'''<mule xmlns:s3="{NAMESPACES['s3']}">
        <s3:config name="s3Config2">
            <s3:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </s3:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    existing = {"sqs": [], "s3": [{"config_name": "s3Config1", "source_file": "other.xml", "connection": {}, "operations": []}], "dynamodb": []}
    result = extract_aws_services(root, xml_file, tmp_path, existing)
    assert len(result["s3"]) == 2


def test_extract_aws_relative_path_fallback():
    xml = '<mule xmlns="http://www.mulesoft.org/schema/mule/core" />'
    root = ET.fromstring(xml)
    from pathlib import Path
    result = extract_aws_services(root, Path("/other/test.xml"), Path("/app"))
    assert result == {"sqs": [], "s3": [], "dynamodb": []}


def test_extract_sqs_multiple_operations(tmp_path):
    xml = f'''<mule xmlns:sqs="{NAMESPACES['sqs']}">
        <sqs:config name="sqsConfig">
            <sqs:basic-connection accessKey="key" secretKey="secret" region="us-east-1" />
        </sqs:config>
        <flow name="test">
            <sqs:send-message config-ref="sqsConfig" queueUrl="q1" />
            <sqs:receive-messages config-ref="sqsConfig" queueUrl="q1" />
            <sqs:delete-message config-ref="sqsConfig" queueUrl="q1" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["sqs"][0]["operations"]) == 3


def test_extract_sqs_config_no_connection(tmp_path):
    """SQS config without connection child element."""
    xml = f'''<mule xmlns:sqs="{NAMESPACES['sqs']}">
        <sqs:config name="sqsConfig" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["sqs"]) == 1
    assert result["sqs"][0]["connection"] == {}


def test_extract_sqs_operation_no_matching_config(tmp_path):
    """SQS operation referencing unknown config."""
    xml = f'''<mule xmlns:sqs="{NAMESPACES['sqs']}">
        <sqs:config name="sqsConfig">
            <sqs:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </sqs:config>
        <flow name="test">
            <sqs:send-message config-ref="otherConfig" queueUrl="q1" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["sqs"]) == 1
    assert len(result["sqs"][0]["operations"]) == 0


def test_extract_s3_config_no_connection(tmp_path):
    """S3 config without connection child element."""
    xml = f'''<mule xmlns:s3="{NAMESPACES['s3']}">
        <s3:config name="s3Config" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["s3"]) == 1
    assert result["s3"][0]["connection"] == {}


def test_extract_s3_operation_no_matching_config(tmp_path):
    """S3 operation referencing unknown config."""
    xml = f'''<mule xmlns:s3="{NAMESPACES['s3']}">
        <s3:config name="s3Config">
            <s3:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </s3:config>
        <flow name="test">
            <s3:put-object config-ref="otherConfig" bucketName="b" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["s3"][0]["operations"]) == 0


def test_extract_dynamodb_config_no_connection(tmp_path):
    """DynamoDB config without connection child element."""
    xml = f'''<mule xmlns:dynamodb="{NAMESPACES['dynamodb']}">
        <dynamodb:config name="dynamoConfig" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["dynamodb"]) == 1
    assert result["dynamodb"][0]["connection"] == {}


def test_extract_dynamodb_operation_no_matching_config(tmp_path):
    """DynamoDB operation referencing unknown config."""
    xml = f'''<mule xmlns:dynamodb="{NAMESPACES['dynamodb']}">
        <dynamodb:config name="dynamoConfig">
            <dynamodb:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </dynamodb:config>
        <flow name="test">
            <dynamodb:put-item config-ref="otherConfig" tableName="t" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["dynamodb"][0]["operations"]) == 0


def test_extract_s3_duplicate_operation(tmp_path):
    """Duplicate S3 operations should be deduplicated."""
    xml = f'''<mule xmlns:s3="{NAMESPACES['s3']}">
        <s3:config name="s3Config">
            <s3:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </s3:config>
        <flow name="test">
            <s3:put-object config-ref="s3Config" bucketName="b" />
            <s3:put-object config-ref="s3Config" bucketName="b" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["s3"][0]["operations"]) == 1


def test_extract_dynamodb_duplicate_operation(tmp_path):
    """Duplicate DynamoDB operations should be deduplicated."""
    xml = f'''<mule xmlns:dynamodb="{NAMESPACES['dynamodb']}">
        <dynamodb:config name="dynamoConfig">
            <dynamodb:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </dynamodb:config>
        <flow name="test">
            <dynamodb:put-item config-ref="dynamoConfig" tableName="t" />
            <dynamodb:put-item config-ref="dynamoConfig" tableName="t" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["dynamodb"][0]["operations"]) == 1


def test_extract_sqs_duplicate_config(tmp_path):
    """Duplicate SQS config should be deduplicated."""
    xml = f'''<mule xmlns:sqs="{NAMESPACES['sqs']}">
        <sqs:config name="sqsConfig">
            <sqs:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </sqs:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    existing = {"sqs": [{"config_name": "sqsConfig", "source_file": "other.xml", "connection": {}, "operations": []}], "s3": [], "dynamodb": []}
    result = extract_aws_services(root, xml_file, tmp_path, existing)
    assert len(result["sqs"]) == 1


def test_extract_s3_duplicate_config(tmp_path):
    """Duplicate S3 config should be deduplicated."""
    xml = f'''<mule xmlns:s3="{NAMESPACES['s3']}">
        <s3:config name="s3Config">
            <s3:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </s3:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    existing = {"sqs": [], "s3": [{"config_name": "s3Config", "source_file": "other.xml", "connection": {}, "operations": []}], "dynamodb": []}
    result = extract_aws_services(root, xml_file, tmp_path, existing)
    assert len(result["s3"]) == 1


def test_extract_aws_config_with_non_connection_child(tmp_path):
    """Config with child elements that are not connection elements."""
    xml = f'''<mule xmlns:sqs="{NAMESPACES['sqs']}" xmlns:s3="{NAMESPACES['s3']}" xmlns:dynamodb="{NAMESPACES['dynamodb']}">
        <sqs:config name="sqsCfg">
            <sqs:other-element />
            <sqs:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </sqs:config>
        <s3:config name="s3Cfg">
            <s3:expiration-policy />
            <s3:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </s3:config>
        <dynamodb:config name="dynCfg">
            <dynamodb:pooling-profile />
            <dynamodb:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </dynamodb:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    result = extract_aws_services(root, xml_file, tmp_path)
    assert len(result["sqs"]) == 1
    assert result["sqs"][0]["connection"]["access_key"] == "k"
    assert len(result["s3"]) == 1
    assert result["s3"][0]["connection"]["access_key"] == "k"
    assert len(result["dynamodb"]) == 1
    assert result["dynamodb"][0]["connection"]["access_key"] == "k"


def test_extract_dynamodb_duplicate_config(tmp_path):
    """Duplicate DynamoDB config should be deduplicated."""
    xml = f'''<mule xmlns:dynamodb="{NAMESPACES['dynamodb']}">
        <dynamodb:config name="dynamoConfig">
            <dynamodb:basic-connection accessKey="k" secretKey="s" region="us-east-1" />
        </dynamodb:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    existing = {"sqs": [], "s3": [], "dynamodb": [{"config_name": "dynamoConfig", "source_file": "other.xml", "connection": {}, "operations": []}]}
    result = extract_aws_services(root, xml_file, tmp_path, existing)
    assert len(result["dynamodb"]) == 1
