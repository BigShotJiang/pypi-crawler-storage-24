"""Tests for HTTP auth parser."""
from xml.etree import ElementTree as ET
from mule_discovery.parsers.http_auth import (
    extract_http_auth, classify_credential_source, collect_http_auth_info,
)
from mule_discovery.constants import NAMESPACES


def test_classify_property():
    assert classify_credential_source("${http.password}") == "property"
    assert classify_credential_source("p('my.key')") == "property"


def test_classify_secrets_manager():
    assert classify_credential_source("vars.vSecret") == "secrets_manager"
    assert classify_credential_source("secure::password") == "secrets_manager"


def test_classify_env():
    assert classify_credential_source("System.getenv('KEY')") == "env"


def test_classify_literal():
    assert classify_credential_source("plaintext") == "literal"
    assert classify_credential_source("") == "literal"
    assert classify_credential_source(None) == "literal"


def test_extract_basic_auth():
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost">
            <http:authentication>
                <http:basic-authentication username="${{user}}" password="${{pass}}" />
            </http:authentication>
        </http:request-connection>
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth is not None
    assert auth["type"] == "basic"


def test_extract_no_auth():
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost" />
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth is None


def test_extract_bearer_auth():
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost">
            <http:authentication>
                <http:bearer-authentication token="${{token}}" />
            </http:authentication>
        </http:request-connection>
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth is not None
    assert auth["type"] == "bearer"
    assert auth["token_source"] == "property"


def test_extract_ntlm_auth():
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost">
            <http:authentication>
                <http:ntlm-authentication username="u" password="p" />
            </http:authentication>
        </http:request-connection>
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth["type"] == "ntlm"


def test_extract_digest_auth():
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost">
            <http:authentication>
                <http:digest-authentication username="u" password="p" />
            </http:authentication>
        </http:request-connection>
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth["type"] == "digest"


def test_extract_oauth_auth():
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost">
            <http:authentication>
                <http:oauth-client-credentials-authentication clientId="id" />
            </http:authentication>
        </http:request-connection>
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth["type"] == "oauth2"


def test_extract_auth_direct_on_connection():
    """Auth element directly on request-connection (not nested in <authentication>)."""
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost">
            <http:basic-authentication username="u" password="p" />
        </http:request-connection>
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth is not None
    assert auth["type"] == "basic"


def test_extract_auth_top_level():
    """Auth element directly on request-config."""
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:basic-authentication username="u" password="p" />
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth is not None
    assert auth["type"] == "basic"


def test_collect_http_auth_info(simple_api_path):
    from mule_discovery.parsers.http_auth import collect_all_request_configs, collect_http_auth_info
    from mule_discovery.parsers.file_discovery import find_mule_xml_files
    xml_files = find_mule_xml_files(simple_api_path)
    # globals.xml has request config with basic auth
    all_files = list((simple_api_path / "src" / "main" / "mule").glob("*.xml"))
    auth_map = collect_http_auth_info(all_files, simple_api_path)
    assert "httpRequestConfig" in auth_map
    assert auth_map["httpRequestConfig"]["type"] == "basic"


def test_collect_all_request_configs(simple_api_path):
    from mule_discovery.parsers.http_auth import collect_all_request_configs
    all_files = list((simple_api_path / "src" / "main" / "mule").glob("*.xml"))
    configs = collect_all_request_configs(all_files, simple_api_path)
    assert "httpRequestConfig" in configs
    assert configs["httpRequestConfig"]["connection"]["host"] == "backend.example.com"


def test_classify_mule_p_env():
    """Mule::p with 'env' in expression is classified as env."""
    result = classify_credential_source("Mule::p('env.KEY')")
    # This matches the property pattern first since it contains p('
    assert result in ("property", "env")


def test_extract_unknown_auth_type():
    """Unknown auth type returns the local name without -authentication."""
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:custom-authentication />
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth is not None
    assert auth["type"] == "custom"


def test_collect_all_request_configs_malformed_xml(tmp_path):
    """Malformed XML file should be skipped."""
    xml_file = tmp_path / "bad.xml"
    xml_file.write_text("not xml")
    from mule_discovery.parsers.http_auth import collect_all_request_configs
    configs = collect_all_request_configs([xml_file], tmp_path)
    assert configs == {}


def test_collect_all_request_configs_non_http_prefix(tmp_path):
    """Request config with non-http prefix should be skipped."""
    xml = f'''<mule xmlns:vm="{NAMESPACES['vm']}">
        <vm:request-config name="vmCfg" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    from mule_discovery.parsers.http_auth import collect_all_request_configs
    configs = collect_all_request_configs([xml_file], tmp_path)
    assert len(configs) == 0


def test_collect_all_request_configs_no_name(tmp_path):
    """Request config without name should be skipped."""
    xml = f'''<mule xmlns:http="{NAMESPACES['http']}">
        <http:request-config>
            <http:request-connection host="localhost" />
        </http:request-config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    from mule_discovery.parsers.http_auth import collect_all_request_configs
    configs = collect_all_request_configs([xml_file], tmp_path)
    assert len(configs) == 0


def test_collect_all_request_configs_fallback_attrs(tmp_path):
    """Config-level host/port/basePath/protocol used when no connection element."""
    xml = f'''<mule xmlns:http="{NAMESPACES['http']}">
        <http:request-config name="cfg" host="fallback.host" port="9090"
                             basePath="/v2" protocol="HTTPS" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    from mule_discovery.parsers.http_auth import collect_all_request_configs
    configs = collect_all_request_configs([xml_file], tmp_path)
    assert configs["cfg"]["connection"]["host"] == "fallback.host"
    assert configs["cfg"]["connection"]["port"] == "9090"
    assert configs["cfg"]["connection"]["base_path"] == "/v2"
    assert configs["cfg"]["connection"]["protocol"] == "https"


def test_collect_http_auth_info_malformed_xml(tmp_path):
    """Malformed XML should be skipped."""
    xml_file = tmp_path / "bad.xml"
    xml_file.write_text("not xml")
    auth_map = collect_http_auth_info([xml_file], tmp_path)
    assert auth_map == {}


def test_collect_http_auth_info_no_name(tmp_path):
    """Config without name should be skipped."""
    xml = f'''<mule xmlns:http="{NAMESPACES['http']}">
        <http:request-config>
            <http:basic-authentication username="u" password="p" />
        </http:request-config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    auth_map = collect_http_auth_info([xml_file], tmp_path)
    assert len(auth_map) == 0


def test_collect_http_auth_info_non_http(tmp_path):
    """Non-http request-config should be skipped."""
    xml = f'''<mule xmlns:vm="{NAMESPACES['vm']}">
        <vm:request-config name="vmCfg" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    auth_map = collect_http_auth_info([xml_file], tmp_path)
    assert len(auth_map) == 0


def test_extract_auth_with_non_auth_siblings_in_authentication():
    """Authentication wrapper with non-auth child elements alongside auth."""
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost">
            <http:authentication>
                <http:default-headers />
                <http:basic-authentication username="u" password="p" />
            </http:authentication>
        </http:request-connection>
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth is not None
    assert auth["type"] == "basic"


def test_extract_auth_connection_with_non_auth_grandchild():
    """Request-connection with child elements that are not authentication related."""
    xml = f'''<http:request-config xmlns:http="{NAMESPACES['http']}" name="cfg">
        <http:request-connection host="localhost">
            <http:default-headers />
            <http:basic-authentication username="u" password="p" />
        </http:request-connection>
    </http:request-config>'''
    elem = ET.fromstring(xml)
    auth = extract_http_auth(elem)
    assert auth is not None
    assert auth["type"] == "basic"


def test_collect_request_configs_with_base_path_from_connection(tmp_path):
    """Request config with basePath set on connection element."""
    xml = f'''<mule xmlns:http="{NAMESPACES['http']}">
        <http:request-config name="cfg">
            <http:request-connection host="api.example.com" port="443" basePath="/v2" />
        </http:request-config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    from mule_discovery.parsers.http_auth import collect_all_request_configs
    configs = collect_all_request_configs([xml_file], tmp_path)
    assert configs["cfg"]["connection"]["base_path"] == "/v2"
