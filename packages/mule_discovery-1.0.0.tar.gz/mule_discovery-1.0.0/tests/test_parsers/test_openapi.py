"""Tests for OpenAPI parser."""
from mule_discovery.parsers.openapi import find_api_specifications


def test_find_specs_no_specs(tmp_path):
    main_spec, supporting = find_api_specifications(tmp_path)
    assert main_spec is None
    assert supporting == []


def test_find_raml_spec(tmp_path):
    api_dir = tmp_path / "src" / "main" / "resources" / "api"
    api_dir.mkdir(parents=True)
    (api_dir / "test.raml").write_text("#%RAML 1.0\ntitle: Test\nversion: 1.0\n/users:\n  get:\n")
    main_spec, _ = find_api_specifications(tmp_path)
    assert main_spec is not None
    assert main_spec.type == "raml"


def test_find_openapi_spec(tmp_path):
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    (res_dir / "api.yaml").write_text("openapi: 3.0.0\ninfo:\n  version: 1.0\n")
    main_spec, _ = find_api_specifications(tmp_path)
    assert main_spec is not None
    assert main_spec.type == "openapi"


def test_find_raml_supporting(tmp_path):
    """Non-main RAML files become supporting specs."""
    api_dir = tmp_path / "src" / "main" / "resources" / "api"
    api_dir.mkdir(parents=True)
    # Main RAML
    (api_dir / "main.raml").write_text("#%RAML 1.0\ntitle: Main\nversion: 1.0\n/users:\n  get:\n")
    # Supporting RAML (no endpoints, not a main candidate)
    (api_dir / "types.raml").write_text("#%RAML 1.0 DataType\ntitle: Types\n")
    main_spec, supporting = find_api_specifications(tmp_path)
    assert main_spec is not None
    assert main_spec.type == "raml"


def test_find_openapi_as_supporting(tmp_path):
    """OpenAPI found alongside RAML goes to supporting."""
    res_dir = tmp_path / "src" / "main" / "resources"
    api_dir = res_dir / "api"
    api_dir.mkdir(parents=True)
    (api_dir / "main.raml").write_text("#%RAML 1.0\ntitle: Main\nversion: 1.0\n/users:\n  get:\n")
    (res_dir / "swagger.yaml").write_text("swagger: 2.0\ninfo:\n  version: 1.0\n")
    main_spec, supporting = find_api_specifications(tmp_path)
    assert main_spec.type == "raml"
    assert len(supporting) >= 1


def test_find_raml_matching_app_name(tmp_path):
    """RAML file matching app directory name is preferred as main."""
    api_dir = tmp_path / "src" / "main" / "resources" / "api"
    api_dir.mkdir(parents=True)
    # File matching tmp_path.name
    (api_dir / f"{tmp_path.name}.raml").write_text("#%RAML 1.0\ntitle: App\nversion: 1.0\n/items:\n  get:\n")
    (api_dir / "other.raml").write_text("#%RAML 1.0\ntitle: Other\nversion: 2.0\n/things:\n  get:\n")
    main_spec, supporting = find_api_specifications(tmp_path)
    assert main_spec is not None
    assert tmp_path.name in main_spec.source_file


def test_find_openapi_json(tmp_path):
    """JSON-format OpenAPI spec should be detected."""
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    (res_dir / "api.json").write_text('{"openapi": "3.0.0", "info": {"version": "1.0"}}')
    main_spec, _ = find_api_specifications(tmp_path)
    assert main_spec is not None
    assert main_spec.type == "openapi"


def test_find_raml_unreadable(tmp_path):
    """Unreadable RAML file is skipped gracefully."""
    api_dir = tmp_path / "src" / "main" / "resources" / "api"
    api_dir.mkdir(parents=True)
    bad_raml = api_dir / "bad.raml"
    bad_raml.mkdir()  # Directory, not file
    main_spec, supporting = find_api_specifications(tmp_path)
    assert main_spec is None
    assert supporting == []


def test_find_openapi_unreadable(tmp_path):
    """Unreadable OAS file is skipped gracefully."""
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    bad_yaml = res_dir / "bad.yaml"
    bad_yaml.mkdir()  # Directory, not file
    main_spec, supporting = find_api_specifications(tmp_path)
    assert main_spec is None


def test_find_openapi_non_api_yaml(tmp_path):
    """YAML file without openapi/swagger keyword is not detected."""
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    (res_dir / "config.yaml").write_text("key: value\nother: data")
    main_spec, _ = find_api_specifications(tmp_path)
    assert main_spec is None
