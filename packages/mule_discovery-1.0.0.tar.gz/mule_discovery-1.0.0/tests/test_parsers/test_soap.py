"""Tests for SOAP parser."""
from xml.etree import ElementTree as ET
from mule_discovery.parsers.soap import extract_soap_services


def test_extract_soap_wsc(soap_app_path):
    xml_file = soap_app_path / "src" / "main" / "mule" / "soap-flows.xml"
    tree = ET.parse(xml_file)
    services = extract_soap_services(tree.getroot(), xml_file, soap_app_path)
    assert len(services) >= 1
    assert services[0]["direction"] == "client"
    assert len(services[0]["operations"]) >= 1


def test_extract_soap_empty(tmp_path):
    xml = '<mule xmlns="http://www.mulesoft.org/schema/mule/core" />'
    root = ET.fromstring(xml)
    xml_file = tmp_path / "empty.xml"
    xml_file.write_text(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert services == []


def test_extract_soap_wsc_with_operations(tmp_path):
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:connection wsdlLocation="wsdl/test.wsdl" service="MySvc" port="MyPort" address="http://example.com/ws" />
        </wsc:config>
        <flow name="test">
            <wsc:consume config-ref="wscConfig" operation="GetData" />
            <wsc:consume config-ref="wscConfig" operation="SetData" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert services[0]["direction"] == "client"
    assert services[0]["service_name"] == "MySvc"
    assert services[0]["port_name"] == "MyPort"
    assert services[0]["endpoint"] == "http://example.com/ws"
    assert len(services[0]["operations"]) == 2


def test_extract_soap_soapkit_service(tmp_path):
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:apikit-soap="{NAMESPACES['apikit-soap']}">
        <apikit-soap:config name="soapkitConfig" wsdlLocation="wsdl/test.wsdl" service="MySvc" port="MyPort" />
        <flow name="GetData:\\soapkitConfig">
            <logger message="get data" />
        </flow>
        <flow name="SetData:\\soapkitConfig">
            <logger message="set data" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert services[0]["direction"] == "service"
    assert len(services[0]["operations"]) == 2


def test_extract_soap_deduplicates_configs(tmp_path):
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:connection wsdlLocation="test.wsdl" />
        </wsc:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    existing = [{"config_name": "wscConfig", "direction": "client", "source_file": "other.xml", "operations": []}]
    services = extract_soap_services(root, xml_file, tmp_path, existing)
    assert len(services) == 1  # Not duplicated


def test_extract_soap_relative_path_fallback():
    xml = '<mule xmlns="http://www.mulesoft.org/schema/mule/core" />'
    root = ET.fromstring(xml)
    from pathlib import Path
    services = extract_soap_services(root, Path("/other/test.xml"), Path("/app"))
    assert services == []


def test_extract_soap_wsc_no_connection(tmp_path):
    """WSC config without connection element."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert "wsdl_location" not in services[0]


def test_extract_soap_wsc_no_wsdl(tmp_path):
    """WSC connection without wsdlLocation."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:connection service="MySvc" port="MyPort" address="http://example.com" />
        </wsc:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert services[0]["service_name"] == "MySvc"
    assert services[0]["port_name"] == "MyPort"
    assert services[0]["endpoint"] == "http://example.com"
    assert "wsdl_location" not in services[0]


def test_extract_soap_consume_no_operation(tmp_path):
    """WSC consume without operation attribute."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:connection />
        </wsc:config>
        <flow name="test">
            <wsc:consume config-ref="wscConfig" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert len(services[0]["operations"]) == 0


def test_extract_soap_soapkit_with_wsdl(tmp_path):
    """SOAPkit config with WSDL that resolves."""
    from mule_discovery.constants import NAMESPACES, WSDL_NS
    wsdl_dir = tmp_path / "src" / "main" / "resources" / "wsdl"
    wsdl_dir.mkdir(parents=True)
    wsdl_content = f'''<?xml version="1.0"?>
<definitions xmlns="{WSDL_NS}"
             xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/"
             xmlns:xs="http://www.w3.org/2001/XMLSchema">
    <types><xs:schema targetNamespace="http://example.com" /></types>
    <portType name="MyPort">
        <operation name="op1" />
        <operation name="op2" />
    </portType>
</definitions>'''
    (wsdl_dir / "test.wsdl").write_text(wsdl_content)

    xml = f'''<mule xmlns:apikit-soap="{NAMESPACES['apikit-soap']}">
        <apikit-soap:config name="soapkitConfig" wsdlLocation="wsdl/test.wsdl" service="MySvc" port="MyPort" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert services[0]["wsdl_operation_count"] == 2


def test_extract_soap_soapkit_no_wsdl(tmp_path):
    """SOAPkit config without wsdlLocation."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:apikit-soap="{NAMESPACES['apikit-soap']}">
        <apikit-soap:config name="soapkitConfig" service="MySvc" port="MyPort" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert services[0]["service_name"] == "MySvc"
    assert "wsdl_location" not in services[0]


def test_extract_soap_soapkit_flow_no_match(tmp_path):
    """SOAPkit flow pattern that doesn't match any config."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:apikit-soap="{NAMESPACES['apikit-soap']}">
        <apikit-soap:config name="soapkitConfig" />
        <flow name="GetData:\\otherConfig">
            <logger message="test" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert len(services[0]["operations"]) == 0


def test_extract_soap_wsc_connection_no_service_or_port(tmp_path):
    """WSC connection with wsdl but no service/port/address attributes."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:connection wsdlLocation="http://example.com/service?wsdl" />
        </wsc:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert services[0]["wsdl_location"] == "http://example.com/service?wsdl"
    assert "service_name" not in services[0]
    assert "port_name" not in services[0]
    assert "endpoint" not in services[0]


def test_extract_soap_consume_no_match(tmp_path):
    """WSC consume referencing unknown config."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:connection />
        </wsc:config>
        <flow name="test">
            <wsc:consume config-ref="otherConfig" operation="GetData" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert len(services[0]["operations"]) == 0


def test_extract_soap_consume_duplicate_operation(tmp_path):
    """WSC consume with duplicate operation should deduplicate."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:connection />
        </wsc:config>
        <flow name="test">
            <wsc:consume config-ref="wscConfig" operation="GetData" />
            <wsc:consume config-ref="wscConfig" operation="GetData" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services[0]["operations"]) == 1


def test_extract_soap_soapkit_no_service_no_port(tmp_path):
    """SOAPkit config without service or port attributes."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:apikit-soap="{NAMESPACES['apikit-soap']}">
        <apikit-soap:config name="soapkitConfig" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert "service_name" not in services[0]
    assert "port_name" not in services[0]


def test_extract_soap_soapkit_operation_dedup(tmp_path):
    """SOAPkit flow operations should be deduplicated."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:apikit-soap="{NAMESPACES['apikit-soap']}">
        <apikit-soap:config name="soapkitConfig" />
        <flow name="GetData:\\soapkitConfig"><logger message="a" /></flow>
        <flow name="GetData:\\soapkitConfig"><logger message="b" /></flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    # Second flow with same name shouldn't add duplicate operation
    assert len(services) == 1


def test_extract_soap_wsc_non_connection_child(tmp_path):
    """WSC config with non-connection child element."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:expiration-policy />
            <wsc:connection wsdlLocation="http://example.com/svc?wsdl" service="Svc" />
        </wsc:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert services[0]["service_name"] == "Svc"


def test_extract_soap_wsc_wsdl_malformed(tmp_path):
    """WSC with WSDL that exists but is malformed (parse_wsdl returns None)."""
    from mule_discovery.constants import NAMESPACES
    wsdl_dir = tmp_path / "src" / "main" / "resources" / "wsdl"
    wsdl_dir.mkdir(parents=True)
    (wsdl_dir / "bad.wsdl").write_text("not valid xml at all")

    xml = f'''<mule xmlns:wsc="{NAMESPACES['wsc']}">
        <wsc:config name="wscConfig">
            <wsc:connection wsdlLocation="wsdl/bad.wsdl" />
        </wsc:config>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert "wsdl_operation_count" not in services[0]


def test_extract_soap_soapkit_wsdl_malformed(tmp_path):
    """SOAPkit with WSDL that exists but is malformed."""
    from mule_discovery.constants import NAMESPACES
    wsdl_dir = tmp_path / "src" / "main" / "resources" / "wsdl"
    wsdl_dir.mkdir(parents=True)
    (wsdl_dir / "bad.wsdl").write_text("not valid xml")

    xml = f'''<mule xmlns:apikit-soap="{NAMESPACES['apikit-soap']}">
        <apikit-soap:config name="soapkitConfig" wsdlLocation="wsdl/bad.wsdl" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert "wsdl_operation_count" not in services[0]


def test_extract_soap_flow_without_colon_backslash(tmp_path):
    """Regular flow name without :\\ pattern is not treated as SOAPkit operation."""
    from mule_discovery.constants import NAMESPACES
    xml = f'''<mule xmlns:apikit-soap="{NAMESPACES['apikit-soap']}">
        <apikit-soap:config name="soapkitConfig" />
        <flow name="regularFlow"><logger message="a" /></flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    services = extract_soap_services(root, xml_file, tmp_path)
    assert len(services) == 1
    assert len(services[0]["operations"]) == 0
