"""Tests for file discovery parser."""
from mule_discovery.parsers.file_discovery import (
    find_mule_xml_files, collect_source_files, is_mule_app_root, find_mule_apps,
)


def test_find_mule_xml_files(simple_api_path):
    files = find_mule_xml_files(simple_api_path)
    assert len(files) >= 2  # globals.xml and api.xml


def test_find_mule_xml_files_empty(tmp_path):
    assert find_mule_xml_files(tmp_path) == []


def test_collect_source_files(simple_api_path):
    sf = collect_source_files(simple_api_path)
    assert len(sf.mule_configs) >= 2


def test_is_mule_app_root(simple_api_path):
    assert is_mule_app_root(simple_api_path) is True


def test_is_mule_app_root_not_mule(tmp_path):
    assert is_mule_app_root(tmp_path) is False


def test_find_mule_apps(fixtures_dir):
    apps = find_mule_apps(fixtures_dir)
    assert len(apps) >= 2  # Should find at least simple_api_app and others


def test_find_mule_xml_files_in_resources(tmp_path):
    """XML files in resources that contain mulesoft schema are found."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text('<mule />')

    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    (res_dir / "extra.xml").write_text('<mule xmlns="http://www.mulesoft.org/schema/mule/core" />')
    (res_dir / "log4j2.xml").write_text('<Configuration />')  # Should be excluded
    (res_dir / "other.xml").write_text('<not-mule />')  # Should be excluded

    files = find_mule_xml_files(tmp_path)
    names = [f.name for f in files]
    assert "api.xml" in names
    assert "extra.xml" in names
    assert "log4j2.xml" not in names
    assert "other.xml" not in names


def test_find_mule_xml_files_mule3_app_dir(tmp_path):
    """Mule 3 apps use src/main/app."""
    app_dir = tmp_path / "src" / "main" / "app"
    app_dir.mkdir(parents=True)
    (app_dir / "config.xml").write_text('<mule />')
    files = find_mule_xml_files(tmp_path)
    assert len(files) == 1


def test_collect_source_files_comprehensive(tmp_path):
    """Test collection of all file types."""
    # Mule configs
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text('<mule />')

    # Properties
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    (res_dir / "config.properties").write_text("key=value")
    (res_dir / "config.yaml").write_text("key: value")
    (res_dir / "config.yml").write_text("key: value")

    # API specs
    api_dir = res_dir / "api"
    api_dir.mkdir()
    (api_dir / "spec.raml").write_text("#%RAML 1.0")
    (api_dir / "spec.yaml").write_text("openapi: 3.0.0")
    (api_dir / "spec.json").write_text('{}')

    # DataWeave
    dwl_dir = res_dir / "dwl"
    dwl_dir.mkdir()
    (dwl_dir / "transform.dwl").write_text("%dw 2.0")

    # Java
    java_dir = tmp_path / "src" / "main" / "java" / "com" / "example"
    java_dir.mkdir(parents=True)
    (java_dir / "App.java").write_text("class App {}")

    # Other resources
    (res_dir / "data.json").write_text('{}')
    (res_dir / "template.xml").write_text('<root />')

    sf = collect_source_files(tmp_path)
    assert len(sf.mule_configs) >= 1
    assert len(sf.properties) >= 2
    assert len(sf.api_specs) >= 2
    assert len(sf.dataweave) >= 1
    assert len(sf.java) >= 1
    assert len(sf.resources) >= 1


def test_is_mule_app_root_mule_artifact(tmp_path):
    """mule-artifact.json marks a Mule 4 app root."""
    (tmp_path / "mule-artifact.json").write_text('{"minMuleVersion": "4.4.0"}')
    assert is_mule_app_root(tmp_path) is True


def test_is_mule_app_root_mule_project(tmp_path):
    """mule-project.xml marks a Mule 3 app root."""
    (tmp_path / "mule-project.xml").write_text('<project />')
    assert is_mule_app_root(tmp_path) is True


def test_is_mule_app_root_pom_with_mule_xml(tmp_path):
    """pom.xml + mule XML in src/main/mule."""
    (tmp_path / "pom.xml").write_text('<project />')
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text('<mule />')
    assert is_mule_app_root(tmp_path) is True


def test_is_mule_app_root_pom_with_mule3_app(tmp_path):
    """pom.xml + mule XML in src/main/app."""
    (tmp_path / "pom.xml").write_text('<project />')
    app_dir = tmp_path / "src" / "main" / "app"
    app_dir.mkdir(parents=True)
    (app_dir / "config.xml").write_text('<mule />')
    assert is_mule_app_root(tmp_path) is True


def test_is_mule_app_root_pom_with_plugin(tmp_path):
    """pom.xml with mule-maven-plugin and mule xml somewhere."""
    mule_dir = tmp_path / "src" / "main" / "resources"
    mule_dir.mkdir(parents=True)
    (mule_dir / "config.xml").write_text(
        '<mule xmlns="http://www.mulesoft.org/schema/mule/core" />'
    )
    (tmp_path / "pom.xml").write_text(
        '<project><build><plugins><plugin><artifactId>mule-maven-plugin</artifactId></plugin></plugins></build></project>'
    )
    assert is_mule_app_root(tmp_path) is True


def test_is_mule_app_root_pom_without_mule(tmp_path):
    """Just a pom.xml without mule indicators."""
    (tmp_path / "pom.xml").write_text('<project><artifactId>foo</artifactId></project>')
    assert is_mule_app_root(tmp_path) is False


def test_find_mule_apps_self(tmp_path):
    """If root_path itself is a mule app, include it."""
    (tmp_path / "mule-artifact.json").write_text('{}')
    apps = find_mule_apps(tmp_path)
    assert tmp_path in apps


def test_collect_source_files_yaml_in_api_excluded(tmp_path):
    """YAML files in api/ dir go to api_specs, not properties."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text('<mule />')
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    api_dir = res_dir / "api"
    api_dir.mkdir()
    (api_dir / "spec.yaml").write_text("openapi: 3.0.0")
    (res_dir / "config.yaml").write_text("key: value")

    sf = collect_source_files(tmp_path)
    # config.yaml in properties, spec.yaml in api_specs
    prop_names = [p.split("/")[-1] for p in sf.properties]
    assert "config.yaml" in prop_names
    spec_names = [p.split("/")[-1] for p in sf.api_specs]
    assert "spec.yaml" in spec_names


def test_find_mule_xml_files_unreadable_resource(tmp_path):
    """XML file in resources that can't be read is skipped."""
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    # Create a directory with .xml extension (can't be opened as file)
    bad_xml = res_dir / "bad.xml"
    bad_xml.mkdir()
    files = find_mule_xml_files(tmp_path)
    assert len(files) == 0


def test_is_mule_app_root_pom_with_mulesoft_org(tmp_path):
    """pom.xml with mulesoft.org and XML in resources that can't be read."""
    (tmp_path / "pom.xml").write_text(
        '<project><repositories><repository><url>https://repository.mulesoft.org</url></repository></repositories></project>'
    )
    src_dir = tmp_path / "src" / "main" / "resources"
    src_dir.mkdir(parents=True)
    # XML file that doesn't contain mule schema
    (src_dir / "config.xml").write_text('<not-mule />')
    assert is_mule_app_root(tmp_path) is False


def test_is_mule_app_root_pom_unreadable_xml(tmp_path):
    """pom.xml with mulesoft.org and an unreadable XML file."""
    (tmp_path / "pom.xml").write_text(
        '<project><build><plugins><plugin><artifactId>mule-maven-plugin</artifactId></plugin></plugins></build></project>'
    )
    src_dir = tmp_path / "src" / "main" / "resources"
    src_dir.mkdir(parents=True)
    bad_xml = src_dir / "broken.xml"
    bad_xml.mkdir()  # Directory, not a file, so open() fails
    assert is_mule_app_root(tmp_path) is False


def test_find_mule_apps_skips_target(tmp_path):
    """Directories inside 'target' should be skipped."""
    target_dir = tmp_path / "target" / "mule-app"
    target_dir.mkdir(parents=True)
    (target_dir / "mule-artifact.json").write_text('{}')
    apps = find_mule_apps(tmp_path)
    assert target_dir not in apps


def test_is_mule_app_root_pom_with_unreadable_pom(tmp_path):
    """pom.xml that can't be read in fallback check returns False."""
    pom = tmp_path / "pom.xml"
    pom.mkdir()  # Directory, not file
    assert is_mule_app_root(tmp_path) is False
