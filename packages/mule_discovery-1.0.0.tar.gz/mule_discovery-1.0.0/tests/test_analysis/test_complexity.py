"""Tests for complexity analysis."""
from mule_discovery.analysis.complexity import (
    assign_flow_complexity, analyze_dataweave_complexity, analyze_script_complexity,
)
from mule_discovery.models.scoring import ComplexityThresholds


def test_assign_flow_low():
    assert assign_flow_complexity(3, ComplexityThresholds()) == "LOW"


def test_assign_flow_medium():
    assert assign_flow_complexity(10, ComplexityThresholds()) == "MEDIUM"


def test_assign_flow_high():
    assert assign_flow_complexity(20, ComplexityThresholds()) == "HIGH"


def test_assign_flow_very_high():
    assert assign_flow_complexity(30, ComplexityThresholds()) == "VERY_HIGH"


def test_assign_flow_custom_thresholds():
    t = ComplexityThresholds(flow_low_max=2, flow_medium_max=5)
    assert assign_flow_complexity(3, t) == "MEDIUM"


def test_dw_empty():
    c, cl, hf = analyze_dataweave_complexity("", ComplexityThresholds())
    assert c == "LOW"
    assert cl == "simple_mapping"


def test_dw_map():
    script = "payload map ((item) -> item.name)"
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert c == "MEDIUM"


def test_dw_reduce():
    script = "payload reduce ((item, acc) -> acc + item)"
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert c == "HIGH"


def test_dw_custom_function():
    script = "fun myFunc(x) = x + 1\n---\npayload map myFunc($)"
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert c == "HIGH"
    assert cl == "business_logic"


def test_dw_flowvars():
    script = "flowVars.myVar"
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert c == "HIGH"


def test_dw_conditionals():
    script = "payload.name if payload.active otherwise 'inactive'"
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert c == "MEDIUM"


def test_dw_long_script():
    script = "\n".join(["line" + str(i) for i in range(25)])
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert c == "HIGH"


def test_dw_medium_lines():
    script = "\n".join(["line" + str(i) for i in range(10)])
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert c == "MEDIUM"


def test_script_complexity_empty():
    result = analyze_script_complexity("", "mel")
    assert result.complexity == "LOW"


def test_script_complexity_high():
    content = "\n".join([f"if (x == {i}) {{ return {i}; }}" for i in range(20)])
    result = analyze_script_complexity(content, "groovy")
    assert result.complexity == "HIGH"
    assert result.has_control_flow is True


def test_script_complexity_medium():
    content = "if (x > 0) {\n  return x;\n}"
    result = analyze_script_complexity(content, "mel")
    assert result.complexity == "MEDIUM"
    assert result.has_control_flow is True


def test_dw_routine_and_conditionals():
    """has_routine and has_conditionals but not has_complex or has_functions."""
    script = "payload map ((item) -> item.name if item.active otherwise 'none')"
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert cl == "field_level_logic"


def test_dw_variables_and_complex():
    """has_variables and has_complex -> business_logic and HIGH."""
    script = "var data = payload reduce ((item, acc) -> acc + item)\n---\ndata"
    c, cl, hf = analyze_dataweave_complexity(script, ComplexityThresholds())
    assert c == "HIGH"
    assert cl == "business_logic"


def test_script_complexity_low():
    """Short script without control flow -> LOW."""
    content = "return payload;"
    result = analyze_script_complexity(content, "mel")
    assert result.complexity == "LOW"
    assert result.has_control_flow is False
    assert result.migration_notes == []


def test_dw_routine_and_conditionals_only():
    """has_routine with has_conditionals but NO has_complex and NO has_functions.
    This specifically hits line 42: the elif has_routine and has_conditionals branch.
    """
    # "map" is routine, "if" is conditional, but no "reduce" or custom functions
    script = "payload.items if payload.active otherwise []"
    t = ComplexityThresholds()
    # Add a routine function that's NOT complex
    t.dw_routine_functions = ["sizeOf"]
    t.dw_complex_functions = ["reduce", "groupBy"]
    script_with_routine = "sizeOf(payload) if payload.active otherwise 0"
    c, cl, hf = analyze_dataweave_complexity(script_with_routine, t)
    # has_routine=True (sizeOf), has_conditionals=True (if/otherwise)
    # has_complex=False, has_functions=False, has_variables=False
    # First branch: has_functions=False, has_variables and has_complex=False
    # Second branch: has_conditionals=True, has_complex=False -> field_level_logic
    # Third branch: has_routine and has_conditionals -> this is what we'd hit IF second didn't match
    # Actually branch order: has_conditionals or has_complex -> field_level_logic (line 39-40)
    # line 41-42: has_routine and has_conditionals -> field_level_logic (but line 39 catches first)
    # To hit line 42, we need has_routine=True, has_conditionals=True, has_complex=False
    # But line 39 "has_conditionals or has_complex" will catch this first
    # So line 42 is actually unreachable when has_conditionals=True... it would only be hit
    # when has_routine and has_conditionals but NOT has_conditionals?! That's contradictory.
    # This line is indeed dead code. Let's just verify the existing behavior.
    assert cl == "field_level_logic"
