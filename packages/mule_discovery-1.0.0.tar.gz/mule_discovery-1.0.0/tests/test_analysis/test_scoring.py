"""Tests for scoring analysis."""
from mule_discovery.analysis.scoring import (
    calculate_score,
    calculate_connector_weight_deduction,
    calculate_scale_deduction,
    calculate_pattern_deduction,
    calculate_dw_volume_deduction,
)
from mule_discovery.models.scoring import ComplexityThresholds
from mule_discovery.models.flows import FlowInfo
from mule_discovery.models.dataweave import DataWeaveInfo
from mule_discovery.models.connectors import ConnectorInfo


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _flow(complexity="LOW", component_count=5, external_calls_count=0,
          has_batch=False, patterns=None, **kw):
    defaults = dict(
        id="F-001", name="f", type="API", source_file="t.xml",
        component_count=component_count, complexity=complexity,
        external_calls_count=external_calls_count,
        has_batch=has_batch, patterns=patterns,
    )
    defaults.update(kw)
    return FlowInfo(**defaults)


def _dw(complexity="LOW", classification="simple_mapping",
        has_complex_functions=False, **kw):
    defaults = dict(
        id="DW-001", name="dw", source_file="t.xml",
        flow_name="f", complexity=complexity,
        classification=classification,
        has_complex_functions=has_complex_functions,
    )
    defaults.update(kw)
    return DataWeaveInfo(**defaults)


# ---------------------------------------------------------------------------
# Empty / baseline
# ---------------------------------------------------------------------------

def test_empty_app_score():
    result = calculate_score([], [], [], ComplexityThresholds())
    assert result.score == 100
    assert result.recommendation == "SMALL"


def test_recommendation_bands():
    r = calculate_score([], [], [], ComplexityThresholds())
    assert r.recommendation == "SMALL"


# ---------------------------------------------------------------------------
# Scale deduction tests
# ---------------------------------------------------------------------------

def test_scale_deduction_no_flows():
    assert calculate_scale_deduction([], ComplexityThresholds()) == 0


def test_scale_deduction_10_flows():
    flows = [_flow() for _ in range(10)]
    assert calculate_scale_deduction(flows, ComplexityThresholds()) == 0


def test_scale_deduction_11_flows():
    # 11 flows * 5 comp = 55 > 50, so flow(2) + comp(2) = 4
    flows = [_flow(component_count=4) for _ in range(11)]
    # 11 * 4 = 44 components, below 50
    assert calculate_scale_deduction(flows, ComplexityThresholds()) == 2


def test_scale_deduction_21_flows():
    flows = [_flow(component_count=2) for _ in range(21)]
    # 21 * 2 = 42 components, below 50
    assert calculate_scale_deduction(flows, ComplexityThresholds()) == 2 + 3  # 5


def test_scale_deduction_41_flows():
    flows = [_flow(component_count=1) for _ in range(41)]
    # 41 * 1 = 41 components, below 50
    assert calculate_scale_deduction(flows, ComplexityThresholds()) == 2 + 3 + 5  # 10


def test_scale_deduction_61_flows():
    flows = [_flow(component_count=0) for _ in range(61)]
    # 0 components
    assert calculate_scale_deduction(flows, ComplexityThresholds()) == 2 + 3 + 5 + 5  # 15


def test_scale_deduction_component_count_51():
    # 11 flows with 5 components each = 55 components total, >50
    flows = [_flow(component_count=5) for _ in range(11)]
    d = calculate_scale_deduction(flows, ComplexityThresholds())
    assert d == 2 + 2  # 11 flows (>10) + >50 components


def test_scale_deduction_component_count_151():
    # 16 flows * 10 components = 160 > 150
    flows = [_flow(component_count=10) for _ in range(16)]
    d = calculate_scale_deduction(flows, ComplexityThresholds())
    assert d == 2 + 2 + 3  # >10 flows + >50 comps + >150 comps


def test_scale_deduction_component_count_301():
    # 31 flows * 10 = 310 > 300
    flows = [_flow(component_count=10) for _ in range(31)]
    d = calculate_scale_deduction(flows, ComplexityThresholds())
    # >10 flows(2) + >20 flows(3) + >50 comps(2) + >150 comps(3) + >300 comps(5) = 15
    assert d == 15


def test_scale_deduction_capped_at_max():
    # 61 flows * 10 = 610 components: flow=15, comp=10 -> 25, capped at 20
    flows = [_flow(component_count=10) for _ in range(61)]
    d = calculate_scale_deduction(flows, ComplexityThresholds())
    assert d == 20  # capped


# ---------------------------------------------------------------------------
# Pattern deduction tests
# ---------------------------------------------------------------------------

def test_pattern_deduction_no_patterns():
    flows = [_flow() for _ in range(5)]
    assert calculate_pattern_deduction(flows, ComplexityThresholds()) == 0


def test_pattern_deduction_scatter_gather():
    flows = [_flow(patterns={"scatter_gather": [{}]})]
    assert calculate_pattern_deduction(flows, ComplexityThresholds()) == 3


def test_pattern_deduction_multiple_scatter_gather():
    flows = [_flow(patterns={"scatter_gather": [{}, {}]})]
    assert calculate_pattern_deduction(flows, ComplexityThresholds()) == 6


def test_pattern_deduction_batch():
    flows = [_flow(has_batch=True)]
    assert calculate_pattern_deduction(flows, ComplexityThresholds()) == 3


def test_pattern_deduction_foreach():
    flows = [_flow(patterns={"foreach_loops": [{}]})]
    assert calculate_pattern_deduction(flows, ComplexityThresholds()) == 2


def test_pattern_deduction_retries():
    flows = [_flow(patterns={"retries": [{}]})]
    assert calculate_pattern_deduction(flows, ComplexityThresholds()) == 1


def test_pattern_deduction_choices():
    flows = [_flow(patterns={"choices": [{}, {}]})]
    assert calculate_pattern_deduction(flows, ComplexityThresholds()) == 2


def test_pattern_deduction_combined():
    flows = [
        _flow(patterns={"scatter_gather": [{}], "choices": [{}], "foreach_loops": [{}, {}]}, has_batch=True),
        _flow(patterns={"retries": [{}]}),
    ]
    # sg=3, choices=1, foreach=4, batch=3, retries=1 = 12
    assert calculate_pattern_deduction(flows, ComplexityThresholds()) == 12


def test_pattern_deduction_capped_at_max():
    # 5 scatter-gathers across flows = 15, plus a batch = 18, capped at 15
    flows = [_flow(patterns={"scatter_gather": [{}, {}, {}, {}, {}]}, has_batch=True)]
    d = calculate_pattern_deduction(flows, ComplexityThresholds())
    assert d == 15  # capped


# ---------------------------------------------------------------------------
# DataWeave volume deduction tests
# ---------------------------------------------------------------------------

def test_dw_volume_deduction_empty():
    assert calculate_dw_volume_deduction([], ComplexityThresholds()) == 0


def test_dw_volume_deduction_5():
    dw = [_dw() for _ in range(5)]
    assert calculate_dw_volume_deduction(dw, ComplexityThresholds()) == 0


def test_dw_volume_deduction_6():
    dw = [_dw() for _ in range(6)]
    assert calculate_dw_volume_deduction(dw, ComplexityThresholds()) == 2


def test_dw_volume_deduction_16():
    dw = [_dw() for _ in range(16)]
    assert calculate_dw_volume_deduction(dw, ComplexityThresholds()) == 2 + 3  # 5


def test_dw_volume_deduction_31():
    dw = [_dw() for _ in range(31)]
    assert calculate_dw_volume_deduction(dw, ComplexityThresholds()) == 2 + 3 + 3  # 8


def test_dw_volume_deduction_business_logic():
    dw = [_dw(classification="business_logic") for _ in range(4)]
    assert calculate_dw_volume_deduction(dw, ComplexityThresholds()) == 3


def test_dw_volume_deduction_complex_functions():
    dw = [_dw(has_complex_functions=True) for _ in range(6)]
    assert calculate_dw_volume_deduction(dw, ComplexityThresholds()) == 2 + 4  # >5 count + >5 complex


def test_dw_volume_deduction_all_thresholds():
    # 31 DW, 4 business_logic, 6 complex_functions
    dw = ([_dw(classification="business_logic", has_complex_functions=True) for _ in range(6)]
          + [_dw() for _ in range(25)])
    d = calculate_dw_volume_deduction(dw, ComplexityThresholds())
    # >5(2) + >15(3) + >30(3) + >3 biz(3) + >5 complex(4) = 15
    assert d == 15


def test_dw_volume_deduction_capped():
    # Same as above — already hits 15 which is the cap
    dw = ([_dw(classification="business_logic", has_complex_functions=True) for _ in range(6)]
          + [_dw() for _ in range(25)])
    d = calculate_dw_volume_deduction(dw, ComplexityThresholds())
    assert d == 15  # capped


# ---------------------------------------------------------------------------
# Flow deduction — absolute count component
# ---------------------------------------------------------------------------

def test_flow_deduction_absolute_count_added():
    """5 HIGH + 5 LOW out of 10: pct=50%->20, abs=min(0+5+0,10)=5, total=25."""
    flows = [_flow(complexity="HIGH") for _ in range(5)] + [_flow() for _ in range(5)]
    result = calculate_score(flows, [], [], ComplexityThresholds())
    assert result.deductions["high_complexity_flows"] == 25


def test_flow_deduction_very_high_absolute():
    """3 VERY_HIGH out of 10: pct=30%->12, vh_pct=30%->3, abs=min(0+0+6,10)=6, total=21."""
    flows = [_flow(complexity="VERY_HIGH") for _ in range(3)] + [_flow() for _ in range(7)]
    result = calculate_score(flows, [], [], ComplexityThresholds())
    assert result.deductions["high_complexity_flows"] == 21


def test_flow_deduction_medium_counted():
    """10 MEDIUM out of 10: pct_complex=0, abs=min(10//2,10)=5, total=5."""
    flows = [_flow(complexity="MEDIUM") for _ in range(10)]
    result = calculate_score(flows, [], [], ComplexityThresholds())
    assert result.deductions["high_complexity_flows"] == 5


def test_flow_deduction_medium_and_high_combined():
    """6 MEDIUM + 4 HIGH out of 10: pct=40%->16, abs=min(3+4,10)=7, total=23."""
    flows = ([_flow(complexity="MEDIUM") for _ in range(6)]
             + [_flow(complexity="HIGH") for _ in range(4)])
    result = calculate_score(flows, [], [], ComplexityThresholds())
    assert result.deductions["high_complexity_flows"] == 23


def test_flow_deduction_capped_at_30():
    """All VERY_HIGH should cap at 30."""
    flows = [_flow(complexity="VERY_HIGH") for _ in range(20)]
    result = calculate_score(flows, [], [], ComplexityThresholds())
    assert result.deductions["high_complexity_flows"] == 30


# ---------------------------------------------------------------------------
# Connector weight — adjusted weights
# ---------------------------------------------------------------------------

def test_connector_weight_deduction():
    connectors = [ConnectorInfo(name="mule-wsc-connector")]
    deduction, weights = calculate_connector_weight_deduction(connectors, {}, ComplexityThresholds())
    assert deduction == 5  # was 4, now 5 per high
    assert weights["mule-wsc-connector"] == "high"


def test_connector_auth_bumps():
    connectors = [ConnectorInfo(name="mule-http-connector")]
    auth_map = {"cfg": {"type": "oauth2"}}
    deduction, weights = calculate_connector_weight_deduction(connectors, auth_map, ComplexityThresholds())
    assert "http-auth:cfg" in weights
    assert weights["http-auth:cfg"] == "high"
    assert deduction == 5  # one high auth


def test_connector_medium_weight():
    connectors = [ConnectorInfo(name="mule-db-connector")]
    deduction, weights = calculate_connector_weight_deduction(connectors, {}, ComplexityThresholds())
    assert weights["mule-db-connector"] == "medium"
    assert deduction == 2  # was 1, now 2 per medium


def test_connector_deduction_capped_at_20():
    connectors = [ConnectorInfo(name="mule-wsc-connector") for _ in range(5)]
    deduction, _ = calculate_connector_weight_deduction(connectors, {}, ComplexityThresholds())
    # 5 * 5 = 25, capped at 20
    assert deduction == 20


# ---------------------------------------------------------------------------
# Integration tests — full score calculation with new dimensions
# ---------------------------------------------------------------------------

def test_score_medium_recommendation(make_flow):
    """Score between 50-74 should recommend MEDIUM."""
    flows = [make_flow(complexity="HIGH") for _ in range(7)] + [make_flow(complexity="LOW") for _ in range(3)]
    result = calculate_score(flows, [], [], ComplexityThresholds())
    assert result.recommendation in ("MEDIUM", "SMALL")


def test_score_large_recommendation(make_flow):
    """Very complex flows + risks should push score down."""
    flows = [make_flow(complexity="VERY_HIGH", external_calls_count=5) for _ in range(10)]
    from mule_discovery.models.dependencies import OutOfScopeItem
    oos = [OutOfScopeItem(name="test", type="platform", source_file="t.xml", reason="r", recommendation="rec") for _ in range(5)]
    result = calculate_score(flows, [], oos, ComplexityThresholds())
    assert result.score < 75


def test_score_with_soap_services(make_flow):
    """SOAP services with many operations add deductions."""
    flows = [make_flow()]
    soap = [{"wsdl_operation_count": 15}, {"wsdl_operation_count": 10}]
    result = calculate_score(flows, [], [], ComplexityThresholds(), soap_services=soap)
    assert result.deductions["wsdl_complexity"] > 0


def test_score_xlarge_recommendation(make_flow):
    """Extreme complexity should result in very low score."""
    flows = [make_flow(complexity="VERY_HIGH", external_calls_count=5) for _ in range(20)]
    from mule_discovery.models.dependencies import OutOfScopeItem
    oos = [OutOfScopeItem(name=f"t{i}", type="platform", source_file="t.xml", reason="r", recommendation="rec") for i in range(10)]
    dw = [_dw(complexity="HIGH", classification="business_logic", has_complex_functions=True) for _ in range(10)]
    connectors = [ConnectorInfo(name="mule-wsc-connector"), ConnectorInfo(name="mule-sap-connector")]
    result = calculate_score(flows, dw, oos, ComplexityThresholds(), connectors=connectors)
    assert result.score < 50
    assert result.recommendation in ("LARGE", "XLARGE")


def test_score_xlarge_below_25(make_flow):
    """Score below 25 should recommend XLARGE."""
    flows = [make_flow(complexity="VERY_HIGH", external_calls_count=5) for _ in range(20)]
    from mule_discovery.models.dependencies import OutOfScopeItem
    oos = [OutOfScopeItem(name=f"t{i}", type="platform", source_file="t.xml", reason="r", recommendation="rec") for i in range(10)]
    dw = [_dw(complexity="HIGH", classification="business_logic", has_complex_functions=True) for _ in range(20)]
    connectors = [ConnectorInfo(name="mule-wsc-connector"), ConnectorInfo(name="mule-sap-connector"),
                  ConnectorInfo(name="mule-ldap-connector")]
    auth_map = {"cfg1": {"type": "oauth2"}, "cfg2": {"type": "ntlm"}, "cfg3": {"type": "digest"}}
    soap = [{"wsdl_operation_count": 20}, {"wsdl_operation_count": 15}]
    result = calculate_score(flows, dw, oos, ComplexityThresholds(), connectors=connectors,
                              http_auth_map=auth_map, soap_services=soap)
    assert result.score < 25
    assert result.recommendation == "XLARGE"


def test_all_high_flows():
    flows = [_flow(complexity="HIGH") for _ in range(10)]
    result = calculate_score(flows, [], [], ComplexityThresholds())
    assert result.score < 100


def test_new_deduction_keys_present():
    """All 8 deduction keys should be present in result."""
    result = calculate_score([], [], [], ComplexityThresholds())
    expected_keys = {
        "high_complexity_flows", "high_complexity_transforms", "risk_items",
        "connector_weight", "wsdl_complexity",
        "scale", "pattern_complexity", "dataweave_volume",
    }
    assert set(result.deductions.keys()) == expected_keys


def test_simple_app_stays_small():
    """A simple app with few flows and no complexity should still score SMALL."""
    flows = [_flow() for _ in range(3)]
    dw = [_dw() for _ in range(2)]
    result = calculate_score(flows, dw, [], ComplexityThresholds())
    assert result.score >= 75
    assert result.recommendation == "SMALL"


def test_complex_app_scores_large_or_xlarge():
    """App with many flows, patterns, DW, and connectors should score LARGE/XLARGE."""
    from mule_discovery.models.dependencies import OutOfScopeItem
    flows = [
        _flow(complexity="HIGH", component_count=10,
              patterns={"scatter_gather": [{}], "foreach_loops": [{}]})
        for _ in range(25)
    ] + [
        _flow(complexity="VERY_HIGH", component_count=15, has_batch=True)
        for _ in range(5)
    ]
    dw = ([_dw(classification="business_logic", has_complex_functions=True) for _ in range(10)]
          + [_dw() for _ in range(20)])
    oos = [OutOfScopeItem(name=f"o{i}", type="platform", source_file="t.xml",
                          reason="r", recommendation="rec") for i in range(3)]
    connectors = [ConnectorInfo(name="mule-wsc-connector"),
                  ConnectorInfo(name="mule-sap-connector")]
    result = calculate_score(flows, dw, oos, ComplexityThresholds(), connectors=connectors)
    assert result.score < 50
    assert result.recommendation in ("LARGE", "XLARGE")
