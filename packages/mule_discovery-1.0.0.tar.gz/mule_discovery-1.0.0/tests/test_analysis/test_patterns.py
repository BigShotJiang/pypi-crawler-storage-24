"""Tests for pattern analysis."""
from mule_discovery.analysis.patterns import has_async_processor, classify_choice_pattern
from mule_discovery.models.flows import ChoiceInfo, ChoiceBranch


def test_has_async_processor_true():
    assert has_async_processor(["vm:publish", "logger"]) is True


def test_has_async_processor_false():
    assert has_async_processor(["logger", "http:request"]) is False


def test_classify_sync():
    choice = ChoiceInfo(branches=[
        ChoiceBranch(condition="#[true]", processors=["logger"]),
    ])
    assert classify_choice_pattern(choice) == "sync_router"


def test_classify_async_fanout():
    choice = ChoiceInfo(branches=[
        ChoiceBranch(condition="#[true]", processors=["vm:publish"], has_async_publish=True),
        ChoiceBranch(condition=None, is_otherwise=True, processors=["jms:publish"], has_async_publish=True),
    ])
    assert classify_choice_pattern(choice) == "async_fanout"


def test_classify_mixed():
    choice = ChoiceInfo(branches=[
        ChoiceBranch(condition="#[true]", processors=["vm:publish"], has_async_publish=True),
        ChoiceBranch(condition=None, is_otherwise=True, processors=["logger"]),
    ])
    assert classify_choice_pattern(choice) == "mixed"


def test_classify_empty():
    choice = ChoiceInfo()
    assert classify_choice_pattern(choice) == "sync_router"
