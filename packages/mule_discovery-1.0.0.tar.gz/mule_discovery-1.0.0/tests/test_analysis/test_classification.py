"""Tests for classification analysis."""
from mule_discovery.analysis.classification import (
    FlowType, SourceCategory, calculate_source_summary,
)
from mule_discovery.models.flows import FlowInfo, SourceInfo


def test_flow_type_constants():
    assert FlowType.API == "API"
    assert FlowType.EVENT == "EVENT"
    assert FlowType.SCHEDULED == "SCHEDULED"
    assert FlowType.BATCH == "BATCH"
    assert FlowType.SUBFLOW == "SUBFLOW"


def test_source_category_constants():
    assert SourceCategory.HTTP == "http"
    assert SourceCategory.NONE == "none"


def test_calculate_source_summary():
    flows = [
        FlowInfo(id="F1", name="a", type="API", source_file="t.xml",
                  source=SourceInfo(type="http:listener")),
        FlowInfo(id="F2", name="b", type="EVENT", source_file="t.xml",
                  source=SourceInfo(type="jms:listener")),
        FlowInfo(id="F3", name="c", type="SUBFLOW", source_file="t.xml"),
    ]
    summary = calculate_source_summary(flows)
    assert summary.http_listener == 1
    assert summary.jms_listener == 1
    assert summary.none == 1


def test_calculate_source_summary_all_types():
    """Cover all source category branches."""
    flows = [
        FlowInfo(id="F1", name="a", type="API", source_file="t.xml",
                  source=SourceInfo(type="https:listener", protocol="HTTPS")),
        FlowInfo(id="F2", name="b", type="EVENT", source_file="t.xml",
                  source=SourceInfo(type="vm:listener")),
        FlowInfo(id="F3", name="c", type="EVENT", source_file="t.xml",
                  source=SourceInfo(type="amqp:listener")),
        FlowInfo(id="F4", name="d", type="EVENT", source_file="t.xml",
                  source=SourceInfo(type="file:listener")),
        FlowInfo(id="F5", name="e", type="EVENT", source_file="t.xml",
                  source=SourceInfo(type="ftp:listener")),
        FlowInfo(id="F6", name="f", type="EVENT", source_file="t.xml",
                  source=SourceInfo(type="sftp:listener")),
        FlowInfo(id="F7", name="g", type="SCHEDULED", source_file="t.xml",
                  source=SourceInfo(type="scheduler")),
        FlowInfo(id="F8", name="h", type="SCHEDULED", source_file="t.xml",
                  source=SourceInfo(type="poll")),
    ]
    summary = calculate_source_summary(flows)
    assert summary.https_listener == 1
    assert summary.vm_listener == 1
    assert summary.amqp_listener == 1
    assert summary.file_listener == 1
    assert summary.ftp_listener == 1
    assert summary.sftp_listener == 1
    assert summary.scheduler == 1
    assert summary.poll == 1


def test_calculate_source_summary_unknown_category():
    """Flow with unknown source category falls through all elif branches."""
    flows = [
        FlowInfo(id="F1", name="a", type="EVENT", source_file="t.xml",
                  source=SourceInfo(type="custom:listener", category="unknown")),
    ]
    summary = calculate_source_summary(flows)
    # Unknown category doesn't increment any counter
    assert summary.http_listener == 0
    assert summary.none == 0
