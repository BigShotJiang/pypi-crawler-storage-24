"""Tests for dependencies analysis."""
from xml.etree import ElementTree as ET
from pathlib import Path
from mule_discovery.analysis.dependencies import (
    extract_external_dependencies, extract_validations, extract_out_of_scope_items,
)
from mule_discovery.constants import NAMESPACES


def test_extract_http_deps(tmp_path):
    xml = f'''<mule xmlns:http="{NAMESPACES['http']}">
        <flow name="test">
            <http:request config-ref="backendConfig" path="/api" method="GET" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert len(deps) >= 1
    assert deps[0].type == "rest-api"


def test_extract_empty_deps(tmp_path):
    xml = '<mule xmlns="http://www.mulesoft.org/schema/mule/core" />'
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert deps == []


def test_extract_validations(tmp_path):
    xml = f'''<flow xmlns:validation="{NAMESPACES['validation']}">
        <validation:is-not-null value="#[payload]" message="required" />
    </flow>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    vals = extract_validations(root, xml_file, tmp_path, "testFlow")
    assert len(vals) == 1
    assert vals[0]["type"] == "is-not-null"


def test_extract_out_of_scope_empty(tmp_path):
    items = extract_out_of_scope_items(tmp_path)
    assert items == []


def test_extract_db_deps(tmp_path):
    xml = f'''<mule xmlns:db="{NAMESPACES['db']}">
        <flow name="test">
            <db:select config-ref="dbConfig">
                <db:sql>SELECT * FROM users</db:sql>
            </db:select>
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert len(deps) >= 1
    assert any(d.type == "database" for d in deps)


def test_extract_mq_deps(tmp_path):
    xml = f'''<mule xmlns:jms="{NAMESPACES['jms']}">
        <flow name="test">
            <jms:publish config-ref="jmsConfig" destination="myQueue" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert len(deps) >= 1
    assert any(d.type == "jms" for d in deps)


def test_extract_generic_config_deps(tmp_path):
    xml = f'''<mule xmlns:salesforce="{NAMESPACES['salesforce']}">
        <salesforce:config name="sfConfig" />
        <flow name="test">
            <salesforce:query config-ref="sfConfig" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert len(deps) >= 1
    assert any(d.name == "sfConfig" for d in deps)


def test_extract_deps_with_global_request_configs(tmp_path):
    xml = f'''<mule xmlns:http="{NAMESPACES['http']}">
        <flow name="test">
            <http:request config-ref="backendConfig" path="/api" method="GET" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    global_configs = {
        "backendConfig": {
            "source_file": "globals.xml",
            "line_number": 5,
            "connection": {"protocol": "https", "host": "api.example.com", "port": "443", "base_path": "/v1"},
        }
    }
    deps = extract_external_dependencies(root, xml_file, tmp_path, global_configs)
    assert len(deps) == 1
    assert deps[0].connection["host"] == "api.example.com"


def test_extract_deps_deduplicates_configs(tmp_path):
    xml = f'''<mule xmlns:http="{NAMESPACES['http']}">
        <flow name="test1">
            <http:request config-ref="backendConfig" path="/a" />
        </flow>
        <flow name="test2">
            <http:request config-ref="backendConfig" path="/b" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert len(deps) == 1


def test_extract_deps_relative_path_fallback():
    """When source_file is not relative to app_path, use str(source_file)."""
    xml = '<mule xmlns="http://www.mulesoft.org/schema/mule/core" />'
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, Path("/other/test.xml"), Path("/app"))
    assert deps == []


def test_extract_validations_all_types(tmp_path):
    xml = f'''<flow xmlns:validation="{NAMESPACES['validation']}">
        <validation:is-not-blank-string value="#[payload.name]" message="blank" />
        <validation:is-not-empty-collection values="#[payload.items]" />
        <validation:is-true expression="#[payload.active]" />
        <validation:matches-regex value="#[payload.email]" regex=".*@.*" />
        <validation:validate-size value="#[payload.list]" min="1" max="100" />
    </flow>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    vals = extract_validations(root, xml_file, tmp_path, "testFlow")
    assert len(vals) == 5
    types = [v["type"] for v in vals]
    assert "is-not-blank-string" in types
    assert "is-not-empty-collection" in types
    assert "is-true" in types
    assert "matches-regex" in types
    assert "validate-size" in types
    # Check expression is captured
    regex_val = [v for v in vals if v["type"] == "matches-regex"][0]
    assert "regex" in regex_val
    size_val = [v for v in vals if v["type"] == "validate-size"][0]
    assert "min" in size_val
    assert "max" in size_val


def test_extract_validations_relative_path_fallback():
    xml = f'''<flow xmlns:validation="{NAMESPACES['validation']}">
        <validation:is-null value="#[payload]" />
    </flow>'''
    root = ET.fromstring(xml)
    vals = extract_validations(root, Path("/other/test.xml"), Path("/app"), "testFlow")
    assert len(vals) == 1


def test_extract_out_of_scope_api_manager(tmp_path):
    """Test out-of-scope detection for API Manager configs."""
    mule_dir = tmp_path / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    xml = f'''<mule xmlns="http://www.mulesoft.org/schema/mule/core"
        xmlns:api-platform-gw="{NAMESPACES['api-platform-gw']}">
        <api-platform-gw:api apiName="TestAPI" />
    </mule>'''
    (mule_dir / "api.xml").write_text(xml)
    items = extract_out_of_scope_items(tmp_path)
    assert len(items) >= 1
    assert any("API Manager" in item.name for item in items)


def test_extract_out_of_scope_splunk_logging(tmp_path):
    """Test out-of-scope detection for Splunk logging."""
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    (res_dir / "log4j2.xml").write_text(
        '<?xml version="1.0"?><Configuration><Appenders><RTFAppender /></Appenders></Configuration>'
    )
    items = extract_out_of_scope_items(tmp_path)
    assert any(item.name == "Splunk Logging" for item in items)


def test_extract_out_of_scope_kafka_logging(tmp_path):
    """Test out-of-scope detection for Kafka logging."""
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    (res_dir / "log4j2.xml").write_text(
        '<?xml version="1.0"?><Configuration><Appenders><KafkaAppender /></Appenders></Configuration>'
    )
    items = extract_out_of_scope_items(tmp_path)
    assert any(item.name == "Kafka Logging" for item in items)


def test_extract_amqp_deps(tmp_path):
    xml = f'''<mule xmlns:amqp="{NAMESPACES['amqp']}">
        <flow name="test">
            <amqp:publish config-ref="amqpConfig" destination="myExchange" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert any(d.type == "amqp" for d in deps)


def test_extract_deps_non_http_request(tmp_path):
    """Request element with non-http prefix should be skipped."""
    xml = f'''<mule xmlns:custom="{NAMESPACES['salesforce']}">
        <custom:request config-ref="cfg" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    # No rest-api dep since prefix is not http/https
    assert not any(d.type == "rest-api" for d in deps)


def test_extract_deps_non_db_select(tmp_path):
    """Select element with non-db prefix should be skipped."""
    xml = f'''<mule xmlns:custom="{NAMESPACES['salesforce']}">
        <custom:select config-ref="cfg" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert not any(d.type == "database" for d in deps)


def test_extract_deps_duplicate_db_config(tmp_path):
    """Duplicate db config-ref should be deduplicated."""
    xml = f'''<mule xmlns:db="{NAMESPACES['db']}">
        <flow name="test">
            <db:select config-ref="dbConfig"><db:sql>SELECT 1</db:sql></db:select>
            <db:insert config-ref="dbConfig"><db:sql>INSERT INTO t</db:sql></db:insert>
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    db_deps = [d for d in deps if d.type == "database"]
    assert len(db_deps) == 1


def test_extract_deps_duplicate_mq_config(tmp_path):
    """Duplicate mq config-ref should be deduplicated."""
    xml = f'''<mule xmlns:jms="{NAMESPACES['jms']}">
        <flow name="test">
            <jms:publish config-ref="jmsConfig" destination="q1" />
            <jms:consume config-ref="jmsConfig" destination="q2" />
        </flow>
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    jms_deps = [d for d in deps if d.type == "jms"]
    assert len(jms_deps) == 1


def test_extract_generic_config_with_attributes(tmp_path):
    """Generic config with host/port/url attributes should capture them."""
    xml = f'''<mule xmlns:salesforce="{NAMESPACES['salesforce']}">
        <salesforce:config name="sfConfig" host="sf.example.com" port="443" url="https://sf.example.com" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    sf_dep = [d for d in deps if d.name == "sfConfig"][0]
    assert sf_dep.connection["host"] == "sf.example.com"
    assert sf_dep.connection["port"] == "443"
    assert sf_dep.connection["url"] == "https://sf.example.com"


def test_extract_generic_config_empty_name_skipped(tmp_path):
    """Generic config with empty name should be skipped."""
    xml = f'''<mule xmlns:salesforce="{NAMESPACES['salesforce']}">
        <salesforce:config />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    assert len(deps) == 0


def test_extract_generic_config_duplicate_skipped(tmp_path):
    """Generic config already seen in http deps is not duplicated."""
    xml = f'''<mule xmlns:http="{NAMESPACES['http']}" xmlns:salesforce="{NAMESPACES['salesforce']}">
        <http:request config-ref="httpCfg" path="/api" />
        <salesforce:my-config name="httpCfg" />
    </mule>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    deps = extract_external_dependencies(root, xml_file, tmp_path)
    # httpCfg is added by http:request, salesforce config with same name is skipped
    names = [d.name for d in deps]
    assert names.count("httpCfg") == 1


def test_extract_out_of_scope_log4j_in_app_dir(tmp_path):
    """Test log4j2.xml in src/main/app directory."""
    app_dir = tmp_path / "src" / "main" / "app"
    app_dir.mkdir(parents=True)
    (app_dir / "log4j2.xml").write_text(
        '<?xml version="1.0"?><Configuration><Appenders><SplunkAppender /></Appenders></Configuration>'
    )
    items = extract_out_of_scope_items(tmp_path)
    assert any(item.name == "Splunk Logging" for item in items)


def test_extract_out_of_scope_unreadable_log4j(tmp_path):
    """Unreadable log4j2.xml is handled gracefully."""
    res_dir = tmp_path / "src" / "main" / "resources"
    res_dir.mkdir(parents=True)
    bad_log4j = res_dir / "log4j2.xml"
    bad_log4j.mkdir()  # Directory, not file
    items = extract_out_of_scope_items(tmp_path)
    assert not any(item.type == "logging" for item in items)


def test_extract_validations_all_branches(tmp_path):
    """Cover all validation type branches including validate-size min/max and matches-regex regex."""
    xml = f'''<flow xmlns:validation="{NAMESPACES['validation']}">
        <validation:is-blank-string value="#[payload.field]" message="blank" />
        <validation:is-null value="#[payload.x]" />
        <validation:is-empty-collection values="#[payload.items]" />
        <validation:is-false expression="#[payload.flag]" />
        <validation:is-email value="#[payload.email]" />
        <validation:all />
        <validation:any />
        <validation:validate-size value="#[payload.list]" min="1" max="100" />
        <validation:matches-regex value="#[payload.code]" regex="^[A-Z]+" />
    </flow>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    vals = extract_validations(root, xml_file, tmp_path, "testFlow")
    types = [v["type"] for v in vals]
    assert "is-blank-string" in types
    assert "is-null" in types
    assert "is-empty-collection" in types
    assert "is-false" in types
    assert "is-email" in types
    assert "all" in types
    assert "any" in types
    # is-blank-string should have expression
    blank = [v for v in vals if v["type"] == "is-blank-string"][0]
    assert "expression" in blank
    # is-empty-collection should have expression
    empty = [v for v in vals if v["type"] == "is-empty-collection"][0]
    assert "expression" in empty
    # is-false should have expression
    false_val = [v for v in vals if v["type"] == "is-false"][0]
    assert "expression" in false_val


def test_extract_validations_no_value_attrs(tmp_path):
    """Validations without optional value attributes still work."""
    xml = f'''<flow xmlns:validation="{NAMESPACES['validation']}">
        <validation:is-not-null />
        <validation:is-not-empty-collection />
        <validation:is-true />
        <validation:matches-regex />
        <validation:validate-size />
    </flow>'''
    xml_file = tmp_path / "test.xml"
    xml_file.write_text(xml)
    root = ET.fromstring(xml)
    vals = extract_validations(root, xml_file, tmp_path, "testFlow")
    assert len(vals) == 5
    # None should have 'expression' key since no value attrs given
    for v in vals:
        if v["type"] in ("is-not-null", "is-true"):
            assert "expression" not in v
