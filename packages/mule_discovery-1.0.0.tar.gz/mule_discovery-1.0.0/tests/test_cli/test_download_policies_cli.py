"""Tests for download_policies CLI."""
from mule_discovery.cli.download_policies import parse_args, main


def test_parse_args():
    args = parse_args([])
    assert str(args.output_dir) == "custom_policies"


def test_parse_args_output_dir():
    args = parse_args(["--output-dir", "/tmp/policies"])
    assert str(args.output_dir) == "/tmp/policies"


def test_main_missing_env(capsys, monkeypatch):
    monkeypatch.delenv("ANYPOINT_CLIENT_ID", raising=False)
    monkeypatch.delenv("ANYPOINT_CLIENT_SECRET", raising=False)
    monkeypatch.delenv("ANYPOINT_ORG_ID", raising=False)
    try:
        main([])
    except SystemExit as e:
        assert e.code == 1
    captured = capsys.readouterr()
    assert "ANYPOINT_CLIENT_ID" in captured.err


def test_main_missing_import(capsys, monkeypatch):
    """When all env vars set but anypoint-sdk not installed, should error about import."""
    monkeypatch.setenv("ANYPOINT_CLIENT_ID", "id")
    monkeypatch.setenv("ANYPOINT_CLIENT_SECRET", "secret")
    monkeypatch.setenv("ANYPOINT_ORG_ID", "org")
    try:
        main([])
    except SystemExit as e:
        assert e.code == 1
    captured = capsys.readouterr()
    assert "anypoint-sdk" in captured.err


def test_main_missing_second_env(capsys, monkeypatch):
    monkeypatch.setenv("ANYPOINT_CLIENT_ID", "id")
    monkeypatch.delenv("ANYPOINT_CLIENT_SECRET", raising=False)
    monkeypatch.delenv("ANYPOINT_ORG_ID", raising=False)
    try:
        main([])
    except SystemExit as e:
        assert e.code == 1
    captured = capsys.readouterr()
    assert "ANYPOINT_CLIENT_SECRET" in captured.err


def test_main_happy_path(capsys, monkeypatch, tmp_path):
    """Full happy path with mocked SDK."""
    monkeypatch.setenv("ANYPOINT_CLIENT_ID", "id")
    monkeypatch.setenv("ANYPOINT_CLIENT_SECRET", "secret")
    monkeypatch.setenv("ANYPOINT_ORG_ID", "org")

    import types
    mock_sdk = types.ModuleType("anypoint_sdk")

    class MockClient:
        @classmethod
        def from_client_credentials(cls, cid, csec):
            return cls()

    mock_sdk.AnypointClient = MockClient
    monkeypatch.setitem(__import__("sys").modules, "anypoint_sdk", mock_sdk)

    from unittest.mock import patch
    with patch("mule_discovery.anypoint.exchange.download_policies", return_value=[{"name": "custom-policy"}]):
        main(["--output-dir", str(tmp_path / "policies")])
    captured = capsys.readouterr()
    import json
    result = json.loads(captured.out)
    assert result["organization_id"] == "org"
    assert len(result["policies"]) == 1
