"""Tests for discover CLI."""
import json
import yaml
from mule_discovery.cli.discover import parse_args, main


def test_parse_args():
    args = parse_args(["/tmp/apps"])
    assert str(args.search_path) == "/tmp/apps"
    assert args.json is False
    assert args.quiet is False
    assert args.output_dir is None


def test_parse_args_json():
    args = parse_args(["/tmp/apps", "--json", "--quiet"])
    assert args.json is True
    assert args.quiet is True


def test_parse_args_thresholds():
    args = parse_args(["/tmp/apps", "--flow-low", "10"])
    assert args.flow_low == 10


def test_parse_args_output_dir():
    args = parse_args(["/tmp/apps", "--output-dir", "/tmp/out"])
    assert str(args.output_dir) == "/tmp/out"


def test_main_nonexistent(capsys):
    try:
        main(["/nonexistent/path"])
    except SystemExit as e:
        assert e.code == 1
    captured = capsys.readouterr()
    assert "does not exist" in captured.err


def test_main_not_a_directory(tmp_path, capsys):
    f = tmp_path / "file.txt"
    f.write_text("hello")
    try:
        main([str(f)])
    except SystemExit as e:
        assert e.code == 1
    captured = capsys.readouterr()
    assert "not a directory" in captured.err


def test_main_no_apps_found(tmp_path, capsys):
    """Empty directory with no Mule apps exits cleanly."""
    try:
        main([str(tmp_path)])
    except SystemExit as e:
        assert e.code == 0
    captured = capsys.readouterr()
    assert "No Mule applications found" in captured.err


def test_main_discovers_apps(fixtures_dir, capsys, tmp_path):
    """Discovers and analyzes all fixture apps, writes YAML inventories."""
    main([str(fixtures_dir), "--output-dir", str(tmp_path)])
    import os
    files = [f for f in os.listdir(tmp_path) if f.endswith("-inventory.yaml")]
    assert len(files) >= 1
    # Verify YAML is valid
    for f in files:
        data = yaml.safe_load((tmp_path / f).read_text())
        assert "app_name" in data


def test_main_discovers_apps_json(fixtures_dir, capsys, tmp_path):
    """Discovers all fixture apps with JSON output."""
    main([str(fixtures_dir), "--json", "--output-dir", str(tmp_path)])
    captured = capsys.readouterr()
    results = json.loads(captured.out)
    assert isinstance(results, list)
    assert all("app_name" in r for r in results)
    # Verify JSON inventory files created
    import os
    files = [f for f in os.listdir(tmp_path) if f.endswith("-inventory.json")]
    assert len(files) >= 1


def test_main_quiet(fixtures_dir, capsys, tmp_path):
    """Quiet mode suppresses stderr output."""
    main([str(fixtures_dir), "--quiet", "--output-dir", str(tmp_path)])
    captured = capsys.readouterr()
    assert captured.err == ""


def test_main_text_summary(fixtures_dir, capsys, tmp_path):
    """Without --quiet, progress and summaries appear on stderr."""
    main([str(fixtures_dir), "--output-dir", str(tmp_path)])
    captured = capsys.readouterr()
    assert "Found" in captured.err
    assert "Processing:" in captured.err


def test_main_creates_output_dir(fixtures_dir, capsys, tmp_path):
    """Output directory is created if it doesn't exist."""
    out = tmp_path / "nested" / "output"
    main([str(fixtures_dir), "--output-dir", str(out), "--quiet"])
    assert out.is_dir()


def test_main_with_failure(tmp_path, capsys):
    """Discovery failure on one app doesn't crash the whole run."""
    from unittest.mock import patch
    app_dir = tmp_path / "working-app"
    mule_dir = app_dir / "src" / "main" / "mule"
    mule_dir.mkdir(parents=True)
    (mule_dir / "api.xml").write_text(
        '<mule xmlns="http://www.mulesoft.org/schema/mule/core">'
        '<flow name="t"><logger message="hi" /></flow></mule>'
    )
    (app_dir / "pom.xml").write_text(
        '<project><artifactId>working-app</artifactId></project>'
    )
    (app_dir / "mule-artifact.json").write_text('{}')

    out = tmp_path / "out"
    with patch("mule_discovery.cli.discover.discover_mule_app", side_effect=RuntimeError("test error")):
        main([str(tmp_path), "--json", "--output-dir", str(out)])
    captured = capsys.readouterr()
    results = json.loads(captured.out)
    assert any(r["success"] is False for r in results)
    assert any("test error" in (r.get("error") or "") for r in results)


def test_main_single_app(simple_api_path, capsys, tmp_path):
    """Works when pointed directly at a single app directory."""
    main([str(simple_api_path), "--output-dir", str(tmp_path), "--quiet"])
    import os
    files = [f for f in os.listdir(tmp_path) if f.endswith("-inventory.yaml")]
    assert len(files) == 1
    data = yaml.safe_load((tmp_path / files[0]).read_text())
    assert data["app_name"] == "simple-api-app"


def test_main_custom_thresholds(simple_api_path, capsys, tmp_path):
    """Custom threshold flags are passed through to discovery."""
    main([str(simple_api_path), "--output-dir", str(tmp_path), "--quiet",
          "--flow-low", "10", "--flow-medium", "20", "--flow-high", "30"])
    import os
    files = [f for f in os.listdir(tmp_path) if f.endswith("-inventory.yaml")]
    assert len(files) == 1
