"""Tests for scan_policies CLI."""
import os
from mule_discovery.cli.scan_policies import parse_args, main


def test_parse_args():
    args = parse_args([])
    assert args.format == "text"


def test_parse_args_json():
    args = parse_args(["--format", "json"])
    assert args.format == "json"


def test_main_missing_env(capsys, monkeypatch):
    monkeypatch.delenv("ANYPOINT_CLIENT_ID", raising=False)
    monkeypatch.delenv("ANYPOINT_CLIENT_SECRET", raising=False)
    monkeypatch.delenv("ANYPOINT_ORG_ID", raising=False)
    monkeypatch.delenv("ANYPOINT_ENV_ID", raising=False)
    try:
        main([])
    except SystemExit as e:
        assert e.code == 1
    captured = capsys.readouterr()
    assert "ANYPOINT_CLIENT_ID" in captured.err


def test_main_missing_import(capsys, monkeypatch):
    """When all env vars set but anypoint-sdk not installed, should error about import."""
    monkeypatch.setenv("ANYPOINT_CLIENT_ID", "id")
    monkeypatch.setenv("ANYPOINT_CLIENT_SECRET", "secret")
    monkeypatch.setenv("ANYPOINT_ORG_ID", "org")
    monkeypatch.setenv("ANYPOINT_ENV_ID", "env")
    try:
        main([])
    except SystemExit as e:
        assert e.code == 1
    captured = capsys.readouterr()
    assert "anypoint-sdk" in captured.err


def test_main_missing_second_env(capsys, monkeypatch):
    """If first env var is set but second is missing, error on the second."""
    monkeypatch.setenv("ANYPOINT_CLIENT_ID", "id")
    monkeypatch.delenv("ANYPOINT_CLIENT_SECRET", raising=False)
    monkeypatch.delenv("ANYPOINT_ORG_ID", raising=False)
    monkeypatch.delenv("ANYPOINT_ENV_ID", raising=False)
    try:
        main([])
    except SystemExit as e:
        assert e.code == 1
    captured = capsys.readouterr()
    assert "ANYPOINT_CLIENT_SECRET" in captured.err


def test_main_happy_path_json(capsys, monkeypatch):
    """Full happy path with mocked SDK - JSON format."""
    monkeypatch.setenv("ANYPOINT_CLIENT_ID", "id")
    monkeypatch.setenv("ANYPOINT_CLIENT_SECRET", "secret")
    monkeypatch.setenv("ANYPOINT_ORG_ID", "org")
    monkeypatch.setenv("ANYPOINT_ENV_ID", "env")

    import types
    mock_sdk = types.ModuleType("anypoint_sdk")

    class MockClient:
        @classmethod
        def from_client_credentials(cls, cid, csec):
            return cls()

    mock_sdk.AnypointClient = MockClient
    monkeypatch.setitem(__import__("sys").modules, "anypoint_sdk", mock_sdk)

    from unittest.mock import patch
    with patch("mule_discovery.anypoint.policies.scan_policies", return_value=[
        {"api": {"exchangeAssetName": "TestAPI", "assetId": "test"}, "policies": [{"id": 1}]}
    ]):
        main(["--format", "json"])
    captured = capsys.readouterr()
    import json
    result = json.loads(captured.out)
    assert result["organization_id"] == "org"
    assert result["environment_id"] == "env"


def test_main_happy_path_text(capsys, monkeypatch):
    """Full happy path with mocked SDK - text format."""
    monkeypatch.setenv("ANYPOINT_CLIENT_ID", "id")
    monkeypatch.setenv("ANYPOINT_CLIENT_SECRET", "secret")
    monkeypatch.setenv("ANYPOINT_ORG_ID", "org")
    monkeypatch.setenv("ANYPOINT_ENV_ID", "env")

    import types
    mock_sdk = types.ModuleType("anypoint_sdk")

    class MockClient:
        @classmethod
        def from_client_credentials(cls, cid, csec):
            return cls()

    mock_sdk.AnypointClient = MockClient
    monkeypatch.setitem(__import__("sys").modules, "anypoint_sdk", mock_sdk)

    from unittest.mock import patch
    with patch("mule_discovery.anypoint.policies.scan_policies", return_value=[
        {"api": {"exchangeAssetName": "TestAPI"}, "policies": [{"id": 1}, {"id": 2}]}
    ]):
        main(["--format", "text"])
    captured = capsys.readouterr()
    assert "Scanned 1 APIs" in captured.out
    assert "TestAPI" in captured.out
    assert "2 policies" in captured.out
