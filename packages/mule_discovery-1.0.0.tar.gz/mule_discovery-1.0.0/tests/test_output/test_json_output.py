"""Tests for JSON output."""
import json
from mule_discovery.models.result import DiscoveryResult
from mule_discovery.output.json_output import render_json


def test_render_json():
    result = DiscoveryResult(app_name="test-app")
    output = render_json(result)
    parsed = json.loads(output)
    assert parsed["app_name"] == "test-app"


def test_render_json_empty():
    result = DiscoveryResult()
    output = render_json(result)
    parsed = json.loads(output)
    assert parsed["schema_version"] == "4.0.0"
