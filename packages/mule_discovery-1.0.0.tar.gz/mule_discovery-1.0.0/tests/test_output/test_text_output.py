"""Tests for text output."""
from mule_discovery.models.result import DiscoveryResult
from mule_discovery.models.scoring import ScoreResult
from mule_discovery.output.text_output import render_text


def test_render_text():
    result = DiscoveryResult(app_name="test-app",
                              summary={"flow_count": 5, "dataweave_count": 2,
                                        "total_components": 10, "connector_count": 3,
                                        "flow_types": {"API": 3, "EVENT": 2},
                                        "complexity_breakdown": {"flows": {"LOW": 3, "MEDIUM": 1, "HIGH": 1, "VERY_HIGH": 0}}},
                              score_result=ScoreResult(score=80, recommendation="SMALL", high_risks=0, medium_risks=0))
    output = render_text(result)
    assert "test-app" in output
    assert "80/100" in output


def test_render_text_empty():
    result = DiscoveryResult(summary={})
    output = render_text(result)
    assert "Discovery Complete" in output
