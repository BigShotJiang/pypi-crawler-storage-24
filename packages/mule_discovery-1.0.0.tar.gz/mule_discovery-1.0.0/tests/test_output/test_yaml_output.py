"""Tests for YAML output."""
import yaml
from mule_discovery.models.result import DiscoveryResult
from mule_discovery.output.yaml_output import render_yaml


def test_render_yaml():
    result = DiscoveryResult(app_name="test-app")
    output = render_yaml(result)
    assert "test-app" in output
    parsed = yaml.safe_load(output)
    assert parsed["app_name"] == "test-app"


def test_render_yaml_empty():
    result = DiscoveryResult()
    output = render_yaml(result)
    parsed = yaml.safe_load(output)
    assert parsed["schema_version"] == "4.0.0"
