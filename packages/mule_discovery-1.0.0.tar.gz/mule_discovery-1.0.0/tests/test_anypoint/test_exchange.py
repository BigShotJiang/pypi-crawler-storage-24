"""Tests for Anypoint exchange."""
from unittest.mock import MagicMock
from mule_discovery.anypoint.exchange import download_policies


def test_download_policies(tmp_path):
    client = MagicMock()
    client.exchange.list_assets.return_value = [
        {"assetId": "policy1", "version": "1.0", "groupId": "g1", "name": "Policy 1"}
    ]
    results = download_policies(client, "org1", tmp_path)
    assert len(results) == 1
    assert results[0]["asset_id"] == "policy1"


def test_download_policies_empty(tmp_path):
    client = MagicMock()
    client.exchange.list_assets.return_value = []
    results = download_policies(client, "org1", tmp_path)
    assert results == []
    assert tmp_path.exists()
