"""Tests for Anypoint policies."""
from unittest.mock import MagicMock
from mule_discovery.anypoint.policies import scan_policies


def test_scan_policies():
    client = MagicMock()
    client.apis.list_instances.return_value = [{"id": 1, "assetId": "test-api"}]
    client.policies.list.return_value = [{"policyId": 100}]
    results = scan_policies(client, "org1", "env1")
    assert len(results) == 1
    assert results[0]["api"]["assetId"] == "test-api"
    assert len(results[0]["policies"]) == 1


def test_scan_policies_empty():
    client = MagicMock()
    client.apis.list_instances.return_value = []
    results = scan_policies(client, "org1", "env1")
    assert results == []
