"""Shared fixtures: model factories, tmp app builders, XML helpers."""

import pytest
from pathlib import Path
from mule_discovery.models.flows import FlowInfo, SourceInfo, PatternInfo
from mule_discovery.models.connectors import ConnectorInfo
from mule_discovery.models.dataweave import DataWeaveInfo
from mule_discovery.models.scoring import ComplexityThresholds, ScoreResult


@pytest.fixture
def fixtures_dir():
    return Path(__file__).parent / "fixtures"


@pytest.fixture
def simple_api_path(fixtures_dir):
    return fixtures_dir / "simple_api_app"


@pytest.fixture
def soap_app_path(fixtures_dir):
    return fixtures_dir / "soap_app"


@pytest.fixture
def complex_app_path(fixtures_dir):
    return fixtures_dir / "complex_app"


@pytest.fixture
def mule3_app_path(fixtures_dir):
    return fixtures_dir / "mule3_app"


@pytest.fixture
def event_driven_path(fixtures_dir):
    return fixtures_dir / "event_driven_app"


@pytest.fixture
def batch_app_path(fixtures_dir):
    return fixtures_dir / "batch_app"


@pytest.fixture
def default_thresholds():
    return ComplexityThresholds()


@pytest.fixture
def make_flow():
    """Factory for FlowInfo with sensible defaults."""
    def _make(**overrides):
        defaults = dict(
            id="FLOW-001", name="testFlow", type="API",
            source_file="src/main/mule/api.xml",
            component_count=5, complexity="MEDIUM",
            components=["http:request", "ee:transform"],
            external_calls_count=0,
            source=None, has_batch=False, patterns=None,
        )
        defaults.update(overrides)
        return FlowInfo(**defaults)
    return _make


@pytest.fixture
def make_dataweave():
    """Factory for DataWeaveInfo with sensible defaults."""
    def _make(**overrides):
        defaults = dict(
            id="DW-001", name="testFlow transform",
            source_file="src/main/mule/api.xml",
            flow_name="testFlow",
            complexity="LOW",
            classification="simple_mapping",
            has_complex_functions=False,
        )
        defaults.update(overrides)
        return DataWeaveInfo(**defaults)
    return _make


@pytest.fixture
def make_connector():
    """Factory for ConnectorInfo with sensible defaults."""
    def _make(**overrides):
        defaults = dict(name="mule-http-connector", usage_count=3)
        defaults.update(overrides)
        return ConnectorInfo(**defaults)
    return _make


@pytest.fixture
def make_mule_app(tmp_path):
    """Create a minimal Mule app directory structure."""
    def _make(name="test-app", mule_xml="<mule/>", pom_xml=None):
        app = tmp_path / name
        mule_dir = app / "src" / "main" / "mule"
        mule_dir.mkdir(parents=True)
        (mule_dir / "api.xml").write_text(mule_xml)
        if pom_xml:
            (app / "pom.xml").write_text(pom_xml)
        return app
    return _make
