"""Tests for dependency models."""
from mule_discovery.models.dependencies import (
    ExternalDependencyInfo, OutOfScopeItem, SourceFiles,
)


def test_external_dependency_info():
    dep = ExternalDependencyInfo(id="EXT-001", name="backendApi", type="rest-api",
                                  source_file="api.xml")
    assert dep.connection == {}
    assert dep.line_number == 0


def test_out_of_scope_item():
    item = OutOfScopeItem(name="API Manager", type="platform",
                           source_file="api.xml", reason="Anypoint specific",
                           recommendation="Use Kong")
    assert item.type == "platform"


def test_source_files_defaults():
    sf = SourceFiles()
    assert sf.mule_configs == []
    assert sf.properties == []
    assert sf.api_specs == []
    assert sf.dataweave == []
    assert sf.java == []
    assert sf.resources == []
