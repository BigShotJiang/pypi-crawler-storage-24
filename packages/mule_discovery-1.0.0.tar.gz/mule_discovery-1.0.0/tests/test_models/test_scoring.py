"""Tests for scoring models."""
from mule_discovery.models.scoring import ComplexityThresholds, ScoreResult


def test_complexity_thresholds_defaults():
    t = ComplexityThresholds()
    assert t.flow_low_max == 6
    assert t.flow_medium_max == 14
    assert t.flow_high_max == 25
    assert t.dw_low_max_lines == 5
    assert t.dw_medium_max_lines == 20
    assert t.score_max_flow_deduction == 30
    assert t.score_max_transform_deduction == 15
    assert t.score_max_risk_deduction == 20
    assert t.score_max_connector_deduction == 20
    assert t.score_max_wsdl_deduction == 10
    assert t.score_max_scale_deduction == 20
    assert t.score_max_pattern_deduction == 15
    assert t.score_max_dw_volume_deduction == 15


def test_complexity_thresholds_custom():
    t = ComplexityThresholds(flow_low_max=10, flow_medium_max=20)
    assert t.flow_low_max == 10
    assert t.flow_medium_max == 20


def test_score_result():
    sr = ScoreResult(score=85, recommendation="SMALL", high_risks=0, medium_risks=1,
                      deductions={"flows": 10, "transforms": 5})
    assert sr.score == 85
    assert sr.recommendation == "SMALL"


def test_score_result_xlarge():
    sr = ScoreResult(score=10, recommendation="XLARGE", high_risks=5, medium_risks=10)
    assert sr.recommendation == "XLARGE"
