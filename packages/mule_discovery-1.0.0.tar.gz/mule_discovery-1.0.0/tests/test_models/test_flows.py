"""Tests for flow models."""
from mule_discovery.models.flows import (
    FlowInfo, SourceInfo, PatternInfo, BatchInfo, BatchStepInfo,
    ScatterGatherInfo, ScatterGatherRoute, ChoiceInfo, ChoiceBranch,
    TransactionInfo, ForeachInfo, AsyncInfo, UntilSuccessfulInfo,
    CacheInfo, ScriptInfo, ErrorHandlerInfo, SourceSummary,
    _get_source_category,
)


def test_source_info_auto_category():
    s = SourceInfo(type="http:listener")
    assert s.category == "http"


def test_source_info_https_protocol():
    s = SourceInfo(type="http:listener", protocol="HTTPS")
    assert s.category == "https"


def test_source_info_none_type():
    s = SourceInfo(type="none")
    assert s.category == "none"


def test_source_info_empty_type():
    s = SourceInfo(type="")
    assert s.category == "none"


def test_source_info_scheduler():
    s = SourceInfo(type="scheduler")
    assert s.category == "scheduler"


def test_source_info_quartz():
    s = SourceInfo(type="quartz:inbound-endpoint")
    assert s.category == "scheduler"


def test_source_info_poll():
    s = SourceInfo(type="poll")
    assert s.category == "scheduler"


def test_source_info_unknown_prefix():
    s = SourceInfo(type="unknown:something")
    assert s.category == "none"


def test_source_info_category_override():
    s = SourceInfo(type="http:listener", category="custom")
    assert s.category == "custom"


def test_flow_info_defaults():
    f = FlowInfo(id="F1", name="test", type="API", source_file="test.xml")
    assert f.components == []
    assert f.external_calls_count == 0
    assert f.has_batch is False
    assert f.patterns is None


def test_pattern_info_defaults():
    p = PatternInfo()
    assert p.scatter_gather == []
    assert p.choices == []
    assert p.transactions == []
    assert p.foreach_loops == []
    assert p.async_scopes == []
    assert p.retries == []
    assert p.caches == []
    assert p.scripts == []


def test_batch_info():
    step = BatchStepInfo(name="step1", processors=["logger"])
    batch = BatchInfo(job_name="job1", steps=[step], total_batch_components=1)
    assert batch.job_name == "job1"
    assert len(batch.steps) == 1


def test_scatter_gather_info():
    route = ScatterGatherRoute(processors=["http:request"])
    sg = ScatterGatherInfo(route_count=1, routes=[route])
    assert sg.route_count == 1


def test_choice_info():
    branch = ChoiceBranch(condition="#[true]", processors=["logger"])
    choice = ChoiceInfo(branches=[branch], has_otherwise=False)
    assert len(choice.branches) == 1


def test_transaction_info():
    tx = TransactionInfo(action="ALWAYS_BEGIN", tx_type="LOCAL")
    assert tx.action == "ALWAYS_BEGIN"


def test_foreach_info():
    fe = ForeachInfo(collection_expression="#[payload]", batch_size=10)
    assert fe.batch_size == 10


def test_async_info():
    a = AsyncInfo(max_concurrency="4", processors=["logger"])
    assert a.max_concurrency == "4"


def test_until_successful_info():
    us = UntilSuccessfulInfo(max_retries="3", interval_ms="1000")
    assert us.max_retries == "3"


def test_cache_info():
    c = CacheInfo(caching_strategy_ref="myCache")
    assert c.caching_strategy_ref == "myCache"


def test_script_info_defaults():
    s = ScriptInfo()
    assert s.script_type == ""
    assert s.complexity == "LOW"


def test_error_handler_info():
    eh = ErrorHandlerInfo(flow_id="F1", flow_name="test")
    assert eh.handler_count == 0
    assert eh.complexity == "LOW"


def test_source_summary_defaults():
    ss = SourceSummary()
    assert ss.http_listener == 0
    assert ss.none == 0


def test_get_source_category_all_categories():
    assert _get_source_category("http:listener") == "http"
    assert _get_source_category("https:listener") == "https"
    assert _get_source_category("vm:listener") == "vm"
    assert _get_source_category("jms:listener") == "jms"
    assert _get_source_category("amqp:listener") == "amqp"
    assert _get_source_category("file:listener") == "file"
    assert _get_source_category("ftp:listener") == "ftp"
    assert _get_source_category("sftp:listener") == "sftp"
