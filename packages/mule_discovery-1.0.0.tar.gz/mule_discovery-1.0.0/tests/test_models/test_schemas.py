"""Tests for schema models."""
from mule_discovery.models.schemas import ApiSpecInfo


def test_api_spec_raml():
    spec = ApiSpecInfo(type="raml", source_file="api.raml", version="1.0",
                        endpoint_count=5, requires_conversion=True)
    assert spec.type == "raml"
    assert spec.requires_conversion is True


def test_api_spec_openapi():
    spec = ApiSpecInfo(type="openapi", source_file="api.yaml")
    assert spec.endpoint_count == 0
    assert spec.requires_conversion is False
