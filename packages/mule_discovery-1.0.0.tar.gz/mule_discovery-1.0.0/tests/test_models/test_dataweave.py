"""Tests for DataWeave models."""
from mule_discovery.models.dataweave import DataWeaveInfo


def test_dataweave_info_defaults():
    dw = DataWeaveInfo(id="DW-001", name="test", source_file="test.xml")
    assert dw.complexity == "LOW"
    assert dw.classification == "simple_mapping"
    assert dw.has_complex_functions is False
    assert dw.extracted_structure == {}


def test_dataweave_info_business_logic():
    dw = DataWeaveInfo(id="DW-001", name="test", source_file="test.xml",
                       classification="business_logic", complexity="HIGH",
                       has_complex_functions=True)
    assert dw.classification == "business_logic"


def test_dataweave_info_external_file():
    dw = DataWeaveInfo(id="DW-001", name="test", source_file="test.xml",
                       external_file="transform.dwl")
    assert dw.external_file == "transform.dwl"
