"""Tests for result models."""
from mule_discovery.models.result import DiscoveryResult


def test_discovery_result_defaults():
    r = DiscoveryResult()
    assert r.schema_version == "4.0.0"
    assert r.flows == []
    assert r.dataweave_transformations == []
    assert r.connectors == []
    assert r.aws_services == {"sqs": [], "s3": [], "dynamodb": []}
    assert r.source_summary is None
    assert r.score_result is None
    assert r.summary == {}


def test_discovery_result_with_fields():
    r = DiscoveryResult(app_name="test-app", mule_version="4.4.0")
    assert r.app_name == "test-app"
    assert r.mule_version == "4.4.0"
