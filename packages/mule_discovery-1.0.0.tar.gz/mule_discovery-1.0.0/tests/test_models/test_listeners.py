"""Tests for listener models."""
from mule_discovery.models.listeners import HttpListenerInfo, ScheduledJobInfo


def test_http_listener_info():
    listener = HttpListenerInfo(id="HTTP-001", config_name="cfg", host="0.0.0.0",
                                 port="8081", base_path="/api")
    assert listener.endpoints == []
    assert listener.protocol == "HTTP"


def test_http_listener_with_endpoints():
    listener = HttpListenerInfo(id="HTTP-001", config_name="cfg", host="0.0.0.0",
                                 port="8081", base_path="/api",
                                 endpoints=[{"path": "/test", "method": "GET"}])
    assert len(listener.endpoints) == 1


def test_scheduled_job_info():
    job = ScheduledJobInfo(id="SCHED-001", flow_name="scheduledFlow",
                            cron="0 0 * * *")
    assert job.cron == "0 0 * * *"
    assert job.fixed_frequency is None
