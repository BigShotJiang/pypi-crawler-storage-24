"""Tests for connector models."""
from mule_discovery.models.connectors import ConnectorInfo, SpringDependency


def test_connector_info_defaults():
    c = ConnectorInfo(name="mule-http-connector")
    assert c.spring_dependencies == []
    assert c.usage_count == 0
    assert c.source_file == "pom.xml"


def test_connector_info_with_deps():
    dep = SpringDependency(groupId="org.spring", artifactId="spring-web")
    c = ConnectorInfo(name="mule-http-connector", spring_dependencies=[dep])
    assert len(c.spring_dependencies) == 1
    assert c.spring_dependencies[0].groupId == "org.spring"


def test_connector_info_zero_usage():
    c = ConnectorInfo(name="test", usage_count=0)
    assert c.usage_count == 0


def test_spring_dependency_defaults():
    sd = SpringDependency(groupId="g", artifactId="a")
    assert sd.version == ""
    assert sd.scope == ""
    assert sd.type == ""
