"""YAML serialization."""

from dataclasses import asdict
from typing import Any

import yaml

from mule_discovery.models.result import DiscoveryResult


def to_dict(obj) -> Any:
    """Convert dataclass or list to dict recursively."""
    if hasattr(obj, "__dataclass_fields__"):
        return {k: to_dict(v) for k, v in asdict(obj).items()}
    elif isinstance(obj, list):
        return [to_dict(item) for item in obj]
    elif isinstance(obj, dict):
        return {k: to_dict(v) for k, v in obj.items()}
    else:
        return obj


def render_yaml(result: DiscoveryResult) -> str:
    """Render DiscoveryResult as YAML string."""
    data = to_dict(result)
    return yaml.safe_dump(data, sort_keys=False, default_flow_style=False)
