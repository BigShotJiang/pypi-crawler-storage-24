"""Console summary rendering."""

from mule_discovery.models.result import DiscoveryResult


def render_text(result: DiscoveryResult) -> str:
    """Render console summary."""
    lines = []
    lines.append(f'{"="*60}')
    lines.append(f"Discovery Complete: {result.app_name}")
    lines.append(f'{"="*60}')
    lines.append(f"Mule Version: {result.mule_version}")
    lines.append(f'Flows: {result.summary.get("flow_count", 0)}')
    lines.append(f'DataWeave: {result.summary.get("dataweave_count", 0)}')
    lines.append(f'Total Components: {result.summary.get("total_components", 0)}')
    lines.append(f'Connectors: {result.summary.get("connector_count", 0)}')

    flow_types = result.summary.get("flow_types", {})
    lines.append(f"\nFlow Types: API={flow_types.get('API', 0)}, "
          f"EVENT={flow_types.get('EVENT', 0)}, "
          f"SCHEDULED={flow_types.get('SCHEDULED', 0)}, "
          f"SUBFLOW={flow_types.get('SUBFLOW', 0)}")

    breakdown = result.summary.get("complexity_breakdown", {}).get("flows", {})
    lines.append(f'\nFlow Complexity: LOW={breakdown.get("LOW", 0)}, '
          f'MEDIUM={breakdown.get("MEDIUM", 0)}, '
          f'HIGH={breakdown.get("HIGH", 0)}, '
          f'VERY_HIGH={breakdown.get("VERY_HIGH", 0)}')

    if result.score_result:
        lines.append(f"\nComplexity Score: {result.score_result.score}/100 — Size: {result.score_result.recommendation}")

    lines.append(f'{"="*60}')

    return "\n".join(lines)
