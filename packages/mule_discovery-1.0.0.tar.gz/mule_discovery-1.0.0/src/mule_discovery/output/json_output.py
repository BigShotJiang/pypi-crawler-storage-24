"""JSON serialization."""

import json

from mule_discovery.models.result import DiscoveryResult
from mule_discovery.output.yaml_output import to_dict


def render_json(result: DiscoveryResult) -> str:
    """Render DiscoveryResult as JSON string."""
    data = to_dict(result)
    return json.dumps(data, indent=2)
