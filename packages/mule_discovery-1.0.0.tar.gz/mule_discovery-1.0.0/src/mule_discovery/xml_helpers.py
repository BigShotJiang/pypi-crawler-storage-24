"""Shared XML utilities for Mule XML parsing."""

from pathlib import Path
from typing import List, Optional, Tuple
from xml.etree import ElementTree as ET

from mule_discovery.constants import (
    CONFIG_ELEMENTS,
    CONTAINER_ELEMENTS,
    NS_TO_PREFIX,
    PATTERN_ELEMENTS,
    REFERENCE_ELEMENTS,
    SOURCE_ELEMENTS,
    TERMINAL_PROCESSOR_ELEMENTS,
)


def get_element_tag(elem: ET.Element) -> Tuple[str, str]:
    """Extract namespace prefix and local name from element tag."""
    tag = elem.tag
    if tag.startswith("{"):
        ns_uri, local_name = tag[1:].split("}", 1)
        prefix = NS_TO_PREFIX.get(ns_uri, "")
        return prefix, local_name
    return "", tag


def get_qualified_name(elem: ET.Element) -> str:
    """Get qualified element name as prefix:localname."""
    prefix, local_name = get_element_tag(elem)
    return f"{prefix}:{local_name}" if prefix else local_name


def find_element_line_number(
    file_path: Path, element_name: str, element_type: str = "flow"
) -> int:
    """Find line number of a specific element in an XML file.

    Handles multi-line element declarations where tag and name attribute
    may be on different lines.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        if element_type in ("flow", "sub-flow"):
            tag_patterns = [f"<{element_type}", f"<mule:{element_type}"]
            name_patterns = [f'name="{element_name}"', f"name='{element_name}'"]
        elif element_type == "batch:job":
            tag_patterns = ["<batch:job"]
            name_patterns = [
                f'jobName="{element_name}"',
                f"jobName='{element_name}'",
                f'name="{element_name}"',
                f"name='{element_name}'"
            ]
        elif element_type == "listener-config":
            tag_patterns = ["listener-config"]
            name_patterns = [f'name="{element_name}"', f"name='{element_name}'"]
        elif element_type == "request-config":
            tag_patterns = ["request-config"]
            name_patterns = [f'name="{element_name}"', f"name='{element_name}'"]
        elif element_type == "db-config":
            tag_patterns = ["<db:config", "<db:generic-connection", "<db:my-sql-connection", "<db:oracle-connection", "<db:mssql-connection"]
            name_patterns = [f'name="{element_name}"', f"name='{element_name}'"]
        elif element_type == "sftp-config":
            tag_patterns = ["<sftp:config"]
            name_patterns = [f'name="{element_name}"', f"name='{element_name}'"]
        elif element_type == "config":
            tag_patterns = [":config", "-config"]
            name_patterns = [f'name="{element_name}"', f"name='{element_name}'"]
        elif element_type == "transform":
            tag_patterns = ["<ee:transform", "<dw:transform"]
            name_patterns = [
                f'doc:name="{element_name}"',
                f"doc:name='{element_name}'",
                f'doc:id="{element_name}"',
                f"doc:id='{element_name}'"
            ]
        else:
            tag_patterns = [element_type]
            name_patterns = [f'name="{element_name}"', f"name='{element_name}'"]

        i = 0
        while i < len(lines):
            line = lines[i]

            tag_found = any(pattern in line for pattern in tag_patterns)
            if not tag_found:
                i += 1
                continue

            if any(name_pat in line for name_pat in name_patterns):
                return i + 1

            element_start_line = i + 1
            accumulated = line
            j = i + 1

            while j < len(lines):
                accumulated += lines[j]

                if any(name_pat in accumulated for name_pat in name_patterns):
                    return element_start_line

                if ">" in lines[j]:
                    break

                j += 1

            i += 1

    except Exception:
        pass
    return 0


def find_transform_line_numbers(file_path: Path) -> List[int]:
    """Find line numbers of all transform elements in an XML file."""
    line_numbers = []
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, 1):
                if "<ee:transform" in line or "<dw:transform-message" in line:
                    line_numbers.append(line_num)
    except Exception:
        pass
    return line_numbers


def is_source_element(elem: ET.Element) -> bool:
    """Check if element is a source/trigger element."""
    qname = get_qualified_name(elem)
    _, local_name = get_element_tag(elem)
    if qname in SOURCE_ELEMENTS:
        return True
    if local_name in ("listener", "inbound-endpoint", "poll", "scheduler"):
        return True
    return False


def is_container_element(elem: ET.Element) -> bool:
    """Check if element is a container."""
    qname = get_qualified_name(elem)
    _, local_name = get_element_tag(elem)
    if qname in CONTAINER_ELEMENTS:
        return True
    if local_name in CONTAINER_ELEMENTS:
        return True
    return False


def is_config_element(elem: ET.Element) -> bool:
    """Check if element is a configuration element."""
    qname = get_qualified_name(elem)
    _, local_name = get_element_tag(elem)
    if qname in CONFIG_ELEMENTS:
        return True
    if local_name.endswith("-config") or local_name.endswith("-connection"):
        return True
    return False


def is_reference_element(elem: ET.Element) -> bool:
    """Check if element is a reference."""
    _, local_name = get_element_tag(elem)
    if local_name == "exception-strategy" and elem.get("ref"):
        return True
    return False


def is_terminal_processor(elem: ET.Element) -> bool:
    """Check if element is a terminal processor."""
    qname = get_qualified_name(elem)
    _, local_name = get_element_tag(elem)
    return qname in TERMINAL_PROCESSOR_ELEMENTS or local_name in TERMINAL_PROCESSOR_ELEMENTS


def is_processor_element(elem: ET.Element) -> bool:
    """Check if element is a countable processor.
    Uses block-list model: anything not explicitly excluded is a processor.
    """
    if is_source_element(elem):
        return False
    if is_config_element(elem):
        return False
    if is_reference_element(elem):
        return False
    if is_container_element(elem):
        return False

    prefix, local_name = get_element_tag(elem)
    if not local_name:
        return False

    return True


def is_pattern_element(elem: ET.Element) -> bool:
    """Check if element is a tracked pattern."""
    _, local_name = get_element_tag(elem)
    return local_name in PATTERN_ELEMENTS


def has_apikit_console(flow_elem: ET.Element) -> bool:
    """Check if flow contains apikit:console."""
    for elem in flow_elem.iter():
        qname = get_qualified_name(elem)
        _, local_name = get_element_tag(elem)
        if qname in ("apikit:console", "apikit4:console") or local_name == "console":
            if "apikit" in qname or "apikit" in elem.tag:
                return True
    return False
