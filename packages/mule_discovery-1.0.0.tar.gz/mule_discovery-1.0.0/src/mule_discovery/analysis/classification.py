"""App type, flow type, source summary."""

from typing import List

from mule_discovery.models.flows import FlowInfo, SourceSummary


class FlowType:
    """Constants for flow type classification."""
    API = "API"
    EVENT = "EVENT"
    SCHEDULED = "SCHEDULED"
    BATCH = "BATCH"
    SUBFLOW = "SUBFLOW"


class SourceCategory:
    """Constants for source categories."""
    HTTP = "http"
    HTTPS = "https"
    VM = "vm"
    JMS = "jms"
    AMQP = "amqp"
    FILE = "file"
    FTP = "ftp"
    SFTP = "sftp"
    SCHEDULER = "scheduler"
    NONE = "none"


def calculate_source_summary(flows: List[FlowInfo]) -> SourceSummary:
    """Calculate aggregate counts of source types."""
    summary = SourceSummary()

    for flow in flows:
        if flow.source is None:
            summary.none += 1
            continue

        source_type = flow.source.type
        category = flow.source.category

        if category == SourceCategory.HTTP:
            summary.http_listener += 1
        elif category == SourceCategory.HTTPS:
            summary.https_listener += 1
        elif category == SourceCategory.VM:
            summary.vm_listener += 1
        elif category == SourceCategory.JMS:
            summary.jms_listener += 1
        elif category == SourceCategory.AMQP:
            summary.amqp_listener += 1
        elif category == SourceCategory.FILE:
            summary.file_listener += 1
        elif category == SourceCategory.FTP:
            summary.ftp_listener += 1
        elif category == SourceCategory.SFTP:
            summary.sftp_listener += 1
        elif category == SourceCategory.SCHEDULER:
            if source_type == "poll":
                summary.poll += 1
            else:
                summary.scheduler += 1
        elif category == SourceCategory.NONE:
            summary.none += 1

    return summary
