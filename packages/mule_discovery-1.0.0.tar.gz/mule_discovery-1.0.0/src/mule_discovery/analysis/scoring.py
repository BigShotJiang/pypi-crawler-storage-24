"""Overall score calculation."""

from typing import Any, Dict, List, Tuple

from mule_discovery.models.flows import FlowInfo
from mule_discovery.models.dataweave import DataWeaveInfo
from mule_discovery.models.dependencies import OutOfScopeItem
from mule_discovery.models.scoring import ComplexityThresholds, ScoreResult
from mule_discovery.parsers.pom import get_connector_key
from mule_discovery.constants import CONNECTOR_MIGRATION_WEIGHTS


def calculate_connector_weight_deduction(
    connectors: List,
    http_auth_map: Dict[str, Dict[str, Any]],
    thresholds: ComplexityThresholds,
) -> Tuple[int, Dict[str, str]]:
    """Calculate deduction based on connector migration complexity weights."""
    connector_weights = {}
    high_weight_count = 0
    medium_weight_count = 0

    for conn in connectors:
        name = conn.name if hasattr(conn, "name") else str(conn)
        key = get_connector_key(name)
        weight = CONNECTOR_MIGRATION_WEIGHTS.get(key, "low")
        connector_weights[name] = weight
        if weight == "high":
            high_weight_count += 1
        elif weight == "medium":
            medium_weight_count += 1

    for config_name, auth_info in http_auth_map.items():
        auth_type = auth_info.get("type", "")
        if auth_type in ("oauth2", "ntlm", "digest"):
            high_weight_count += 1
            connector_weights[f"http-auth:{config_name}"] = "high"

    deduction = high_weight_count * 5 + medium_weight_count * 2
    deduction = min(deduction, thresholds.score_max_connector_deduction)
    return deduction, connector_weights


def calculate_scale_deduction(
    flows: List[FlowInfo],
    thresholds: ComplexityThresholds,
) -> int:
    """Calculate deduction based on absolute flow count and total component count."""
    flow_count = len(flows)
    component_count = sum(f.component_count for f in flows)

    deduction = 0
    if flow_count > 10:
        deduction += 2
    if flow_count > 20:
        deduction += 3
    if flow_count > 40:
        deduction += 5
    if flow_count > 60:
        deduction += 5

    if component_count > 50:
        deduction += 2
    if component_count > 150:
        deduction += 3
    if component_count > 300:
        deduction += 5

    return min(deduction, thresholds.score_max_scale_deduction)


def calculate_pattern_deduction(
    flows: List[FlowInfo],
    thresholds: ComplexityThresholds,
) -> int:
    """Calculate deduction based on complex pattern instances across all flows."""
    deduction = 0
    for f in flows:
        patterns = f.patterns
        if not patterns:
            continue
        deduction += len(patterns.get("scatter_gather", [])) * 3
        deduction += len(patterns.get("choices", [])) * 1
        deduction += len(patterns.get("foreach_loops", [])) * 2
        deduction += len(patterns.get("retries", [])) * 1

    # Batch jobs counted via has_batch flag
    for f in flows:
        if f.has_batch:
            deduction += 3

    return min(deduction, thresholds.score_max_pattern_deduction)


def calculate_dw_volume_deduction(
    dataweave: List[DataWeaveInfo],
    thresholds: ComplexityThresholds,
) -> int:
    """Calculate deduction based on DataWeave volume and sophistication."""
    dw_count = len(dataweave)
    business_logic_count = sum(1 for d in dataweave if d.classification == "business_logic")
    complex_fn_count = sum(1 for d in dataweave if d.has_complex_functions)

    deduction = 0
    if dw_count > 5:
        deduction += 2
    if dw_count > 15:
        deduction += 3
    if dw_count > 30:
        deduction += 3

    if business_logic_count > 3:
        deduction += 3
    if complex_fn_count > 5:
        deduction += 4

    return min(deduction, thresholds.score_max_dw_volume_deduction)


def calculate_score(
    flows: List[FlowInfo],
    dataweave: List[DataWeaveInfo],
    out_of_scope: List[OutOfScopeItem],
    thresholds: ComplexityThresholds,
    connectors: List = None,
    http_auth_map: Dict[str, Dict[str, Any]] = None,
    soap_services: List[Dict[str, Any]] = None,
) -> ScoreResult:
    """Calculate migration complexity score."""
    total_flows = max(len(flows), 1)
    total_transforms = max(len(dataweave), 1)

    medium_flows = sum(1 for f in flows if f.complexity == "MEDIUM")
    high_flows = sum(1 for f in flows if f.complexity == "HIGH")
    very_high_flows = sum(1 for f in flows if f.complexity == "VERY_HIGH")
    high_transforms = sum(1 for d in dataweave if d.complexity == "HIGH")

    pct_complex_flows = (high_flows + very_high_flows) / total_flows
    flow_deduction = int(pct_complex_flows * 40)
    very_high_pct = very_high_flows / total_flows
    flow_deduction += int(very_high_pct * 10)
    abs_bonus = medium_flows // 2 + high_flows + very_high_flows * 2
    flow_deduction += min(abs_bonus, 10)
    flow_deduction = min(flow_deduction, thresholds.score_max_flow_deduction)

    pct_high_transforms = high_transforms / total_transforms
    transform_deduction = int(pct_high_transforms * 25)
    transform_deduction = min(transform_deduction, thresholds.score_max_transform_deduction)

    high_risks = len(out_of_scope)
    medium_risks = sum(1 for f in flows if f.external_calls_count > 2)
    risk_deduction = high_risks * 3 + medium_risks * 1
    risk_deduction = min(risk_deduction, thresholds.score_max_risk_deduction)

    connector_deduction = 0
    if connectors:
        connector_deduction, _ = calculate_connector_weight_deduction(
            connectors, http_auth_map or {}, thresholds
        )

    wsdl_deduction = 0
    if soap_services:
        for svc in soap_services:
            op_count = svc.get("wsdl_operation_count", 0)
            if op_count > 5:
                wsdl_deduction += min(op_count - 5, 5)
        wsdl_deduction = min(wsdl_deduction, thresholds.score_max_wsdl_deduction)

    scale_deduction = calculate_scale_deduction(flows, thresholds)
    pattern_deduction = calculate_pattern_deduction(flows, thresholds)
    dw_volume_deduction = calculate_dw_volume_deduction(dataweave, thresholds)

    deductions = {
        "high_complexity_flows": flow_deduction,
        "high_complexity_transforms": transform_deduction,
        "risk_items": risk_deduction,
        "connector_weight": connector_deduction,
        "wsdl_complexity": wsdl_deduction,
        "scale": scale_deduction,
        "pattern_complexity": pattern_deduction,
        "dataweave_volume": dw_volume_deduction,
    }

    total_deductions = sum(deductions.values())
    score = max(0, 100 - total_deductions)

    if score >= 75:
        recommendation = "SMALL"
    elif score >= 50:
        recommendation = "MEDIUM"
    elif score >= 25:
        recommendation = "LARGE"
    else:
        recommendation = "XLARGE"

    return ScoreResult(
        score=score,
        recommendation=recommendation,
        high_risks=high_risks,
        medium_risks=medium_risks,
        deductions=deductions,
    )
