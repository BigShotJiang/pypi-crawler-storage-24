"""Analysis modules for Mule application assessment."""
