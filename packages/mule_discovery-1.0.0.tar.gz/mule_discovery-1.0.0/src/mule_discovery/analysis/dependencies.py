"""External dependency extraction."""

import re
from pathlib import Path
from typing import Any, Dict, List
from xml.etree import ElementTree as ET

from mule_discovery.models.dependencies import ExternalDependencyInfo, OutOfScopeItem
from mule_discovery.parsers.file_discovery import find_mule_xml_files
from mule_discovery.xml_helpers import find_element_line_number, get_element_tag


def extract_external_dependencies(
    root: ET.Element,
    source_file: Path,
    app_path: Path,
    global_request_configs: Dict[str, Dict[str, Any]] = None
) -> List[ExternalDependencyInfo]:
    """Extract external dependencies (http:request, db, jms, etc.)."""
    dependencies = []

    try:
        rel_path = str(source_file.relative_to(app_path))
    except ValueError:
        rel_path = str(source_file)

    if global_request_configs is None:
        global_request_configs = {}

    seen_configs = set()
    for request in root.findall(".//{*}request"):
        prefix, _ = get_element_tag(request)
        if prefix not in ("http", "https"):
            continue

        config_ref = request.get("config-ref", "")
        if config_ref in seen_configs:
            continue
        seen_configs.add(config_ref)

        config_info = global_request_configs.get(config_ref, {})
        connection = config_info.get("connection", {
            "protocol": "https" if prefix == "https" else "http",
            "host": "",
            "port": "",
            "base_path": "",
        })
        line_num = config_info.get("line_number", 0)
        config_source = config_info.get("source_file", rel_path)

        dep_name = config_ref or f"{prefix}-request"
        dep_id = f"EXT-{len(dependencies)+1:03d}"

        dependencies.append(
            ExternalDependencyInfo(
                id=dep_id,
                name=dep_name,
                type="rest-api",
                source_file=config_source,
                line_number=line_num,
                connection=connection,
            )
        )

    db_configs_seen = set()
    for db_op in (
        root.findall(".//{*}select")
        + root.findall(".//{*}insert")
        + root.findall(".//{*}update")
        + root.findall(".//{*}delete")
        + root.findall(".//{*}stored-procedure")
        + root.findall(".//{*}execute-script")
    ):
        prefix, _ = get_element_tag(db_op)
        if prefix != "db":
            continue

        config_ref = db_op.get("config-ref", "")
        if config_ref in db_configs_seen:
            continue
        db_configs_seen.add(config_ref)

        line_num = find_element_line_number(source_file, config_ref, "db-config") if config_ref else 0
        dep_id = f"EXT-{len(dependencies)+1:03d}"
        dependencies.append(
            ExternalDependencyInfo(
                id=dep_id,
                name=config_ref or "database",
                type="database",
                source_file=rel_path,
                line_number=line_num,
                connection={"type": "database", "config_ref": config_ref},
            )
        )

    mq_configs_seen = set()
    for mq_op in root.findall(".//{*}publish") + root.findall(".//{*}consume"):
        prefix, _ = get_element_tag(mq_op)
        if prefix not in ("jms", "amqp"):
            continue

        config_ref = mq_op.get("config-ref", "")
        if config_ref in mq_configs_seen:
            continue
        mq_configs_seen.add(config_ref)

        destination = mq_op.get("destination", "")

        dep_id = f"EXT-{len(dependencies)+1:03d}"
        dependencies.append(
            ExternalDependencyInfo(
                id=dep_id,
                name=config_ref or prefix,
                type=prefix,
                source_file=rel_path,
                line_number=0,
                connection={"type": prefix, "destination": destination},
            )
        )

    seen_generic_configs = {d.name for d in dependencies}
    for elem in root.iter():
        prefix, local_name = get_element_tag(elem)
        if prefix in ("mule", "http", "https", "db", "jms", "amqp", "", "apikit", "apikit4", "vm", "ee", "doc", "tls", "spring", "context", "secure-property-placeholder", "api-platform-gw"):
            continue

        if local_name == "config" or local_name.endswith("-config"):
            config_name = elem.get("name", "")
            if not config_name or config_name in seen_generic_configs:
                continue

            seen_generic_configs.add(config_name)

            connection = {"type": prefix}
            for attr in ("host", "port", "url", "basePath", "destination", "queue", "topic"):
                if elem.get(attr):
                    connection[attr] = elem.get(attr)

            line_num = find_element_line_number(source_file, config_name, "config")
            dep_id = f"EXT-{len(dependencies)+1:03d}"
            dependencies.append(
                ExternalDependencyInfo(
                    id=dep_id,
                    name=config_name,
                    type=prefix,
                    source_file=rel_path,
                    line_number=line_num,
                    connection=connection,
                )
            )

    return dependencies


def extract_validations(
    root: ET.Element,
    source_file: Path,
    app_path: Path,
    flow_name: str = "",
) -> List[Dict[str, Any]]:
    """Extract Mule validation module operations."""
    validations = []

    try:
        rel_path = str(source_file.relative_to(app_path))
    except ValueError:
        rel_path = str(source_file)

    validation_ops = (
        "is-not-blank-string", "is-blank-string",
        "is-not-null", "is-null",
        "is-not-empty-collection", "is-empty-collection",
        "is-true", "is-false",
        "is-email", "is-url", "is-time", "is-date",
        "matches-regex", "validate-size", "all", "any",
    )

    for elem in root.iter():
        prefix, local_name = get_element_tag(elem)

        if prefix == "validation" and local_name in validation_ops:
            validation_entry = {
                "type": local_name,
                "flow_name": flow_name,
                "source_file": rel_path,
            }

            message = elem.get("message", "")
            if message:
                validation_entry["message"] = message

            if local_name in ("is-not-blank-string", "is-blank-string", "is-not-null", "is-null"):
                value = elem.get("value", "")
                if value:
                    validation_entry["expression"] = value

            elif local_name in ("is-not-empty-collection", "is-empty-collection"):
                values = elem.get("values", "")
                if values:
                    validation_entry["expression"] = values

            elif local_name in ("is-true", "is-false"):
                expression = elem.get("expression", "")
                if expression:
                    validation_entry["expression"] = expression

            elif local_name == "matches-regex":
                value = elem.get("value", "")
                regex = elem.get("regex", "")
                if value:
                    validation_entry["expression"] = value
                if regex:
                    validation_entry["regex"] = regex

            elif local_name == "validate-size":
                value = elem.get("value", "")
                min_val = elem.get("min", "")
                max_val = elem.get("max", "")
                if value:
                    validation_entry["expression"] = value
                if min_val:
                    validation_entry["min"] = min_val
                if max_val:
                    validation_entry["max"] = max_val

            validations.append(validation_entry)

    return validations


def extract_out_of_scope_items(app_path: Path) -> List[OutOfScopeItem]:
    """Extract platform-level items that are out of scope for migration."""
    items = []

    xml_files = find_mule_xml_files(app_path)
    for xml_file in xml_files:
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
            rel_path = str(xml_file.relative_to(app_path))

            for elem in root.iter():
                _, local_name = get_element_tag(elem)
                if local_name == "api" and "api-platform-gw" in elem.tag:
                    api_name = elem.get("apiName", "")
                    items.append(OutOfScopeItem(
                        name=f"API Manager: {api_name}" if api_name else "API Manager",
                        type="platform",
                        source_file=rel_path,
                        reason="Anypoint Platform specific",
                        recommendation="Use the Kong product line for API management equivalents",
                    ))
                    break
        except Exception:
            pass

    log4j_paths = [
        app_path / "src" / "main" / "resources" / "log4j2.xml",
        app_path / "src" / "main" / "app" / "log4j2.xml",
    ]

    for log4j_file in log4j_paths:
        if log4j_file.exists():
            try:
                with open(log4j_file, "r") as f:
                    content = f.read()

                rel_path = str(log4j_file.relative_to(app_path))

                if "RTFAppender" in content or "SplunkAppender" in content:
                    items.append(OutOfScopeItem(
                        name="Splunk Logging",
                        type="logging",
                        source_file=rel_path,
                        reason="Infrastructure logging configuration",
                        recommendation="Configure one of the logging plugins in Kong GW",
                    ))

                if "KafkaAppender" in content:
                    items.append(OutOfScopeItem(
                        name="Kafka Logging",
                        type="logging",
                        source_file=rel_path,
                        reason="Infrastructure logging configuration",
                        recommendation="Configure Kafka log plugin in Kong GW",
                    ))

            except Exception:
                pass

    return items
