"""Pattern detection helpers."""

from typing import List

from mule_discovery.constants import ASYNC_PROCESSORS
from mule_discovery.models.flows import ChoiceInfo


def has_async_processor(processors: List[str]) -> bool:
    """Check if processor list contains any async publish operations."""
    return any(p in ASYNC_PROCESSORS for p in processors)


def classify_choice_pattern(choice: ChoiceInfo) -> str:
    """Classify choice pattern based on branch processor types."""
    if not choice.branches:
        return "sync_router"

    async_branches = sum(1 for b in choice.branches if b.has_async_publish)
    total_branches = len(choice.branches)

    if async_branches == total_branches:
        return "async_fanout"
    elif async_branches == 0:
        return "sync_router"
    else:
        return "mixed"
