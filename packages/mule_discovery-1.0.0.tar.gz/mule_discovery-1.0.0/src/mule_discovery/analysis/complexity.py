"""Flow and DW complexity assignment."""

from typing import List, Tuple

from mule_discovery.models.flows import ScriptInfo
from mule_discovery.models.scoring import ComplexityThresholds


def assign_flow_complexity(component_count: int, thresholds: ComplexityThresholds) -> str:
    """Assign complexity based on component count."""
    if component_count <= thresholds.flow_low_max:
        return "LOW"
    elif component_count <= thresholds.flow_medium_max:
        return "MEDIUM"
    elif component_count <= thresholds.flow_high_max:
        return "HIGH"
    else:
        return "VERY_HIGH"


def analyze_dataweave_complexity(script: str, thresholds: ComplexityThresholds) -> Tuple[str, str, bool]:
    """Analyze DataWeave script complexity."""
    if not script:
        return "LOW", "simple_mapping", False

    lines = [l for l in script.split("\n") if l.strip()]
    line_count = len(lines)

    has_complex = any(func in script for func in thresholds.dw_complex_functions)
    has_routine = any(func in script for func in thresholds.dw_routine_functions)

    has_variables = "%var " in script or "var " in script
    has_functions = "%function " in script or "fun " in script
    has_conditionals = " if " in script or " when " in script or " otherwise " in script
    has_flowvars_lookup = "flowVars." in script or "flowVars[" in script

    if has_functions or (has_variables and has_complex):
        classification = "business_logic"
    elif has_conditionals or has_complex:
        classification = "field_level_logic"
    elif has_routine and has_conditionals:  # pragma: no cover — unreachable: line 39 catches has_conditionals first
        classification = "field_level_logic"
    else:
        classification = "simple_mapping"

    if has_functions:
        complexity = "HIGH"
    elif has_variables and has_complex:
        complexity = "HIGH"
    elif has_flowvars_lookup:
        complexity = "HIGH"
    elif line_count > thresholds.dw_medium_max_lines:
        complexity = "HIGH"
    elif has_complex:
        complexity = "HIGH"
    elif has_routine:
        complexity = "MEDIUM"
    elif has_conditionals:
        complexity = "MEDIUM"
    elif line_count > thresholds.dw_low_max_lines:
        complexity = "MEDIUM"
    else:
        complexity = "LOW"

    return complexity, classification, has_complex or has_routine


def analyze_script_complexity(content: str, script_type: str = "") -> ScriptInfo:
    """Analyze script content for complexity indicators."""
    if not content:
        return ScriptInfo(script_type=script_type, complexity="LOW")

    lines = [l for l in content.strip().split("\n") if l.strip()]
    line_count = len(lines)

    control_flow_keywords = ("if", "else", "for", "while", "when", "try", "catch", "switch", "case")
    has_control_flow = any(kw in content for kw in control_flow_keywords)

    if line_count > 15 or (has_control_flow and line_count >= 5):
        complexity = "HIGH"
    elif line_count > 5 or has_control_flow:
        complexity = "MEDIUM"
    else:
        complexity = "LOW"

    migration_notes = []
    if complexity == "HIGH":
        migration_notes.append(f"Complex {script_type or 'script'} detected - manual review required")
    elif complexity == "MEDIUM":
        migration_notes.append(f"Moderate {script_type or 'script'} complexity - review recommended")

    return ScriptInfo(
        script_type=script_type,
        line_count=line_count,
        has_control_flow=has_control_flow,
        complexity=complexity,
        migration_notes=migration_notes,
    )
