"""Download custom policies using AnypointClient."""

from pathlib import Path
from typing import Any, Dict, List


def download_policies(client, org_id: str, output_dir: Path) -> List[Dict[str, Any]]:
    """Download custom policy assets from Exchange."""
    output_dir.mkdir(parents=True, exist_ok=True)
    assets = client.exchange.list_assets(org_id, types=["policy"])
    summary = []
    for asset in assets:
        asset_id = asset.get("assetId", "")
        version = asset.get("version", "")
        summary.append({
            "asset_id": asset_id,
            "version": version,
            "group_id": asset.get("groupId", ""),
            "name": asset.get("name", asset_id),
        })
    return summary
