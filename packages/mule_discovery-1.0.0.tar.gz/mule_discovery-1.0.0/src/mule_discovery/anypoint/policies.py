"""Scan API policies using AnypointClient."""

from typing import Any, Dict, List


def scan_policies(client, org_id: str, env_id: str) -> List[Dict[str, Any]]:
    """Scan all API policies in an environment."""
    apis = client.apis.list_instances(org_id, env_id)
    results = []
    for api in apis:
        api_id = api.get("id") or api.get("apiId")
        policies = client.policies.list(org_id, env_id, api_id)
        results.append({"api": api, "policies": policies})
    return results
