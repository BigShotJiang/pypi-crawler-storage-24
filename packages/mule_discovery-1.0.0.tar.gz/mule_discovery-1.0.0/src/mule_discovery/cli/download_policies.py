"""mule-download-policies CLI entry point."""

import argparse
import json
import os
import sys
from pathlib import Path


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Download custom policies from Anypoint Exchange")
    parser.add_argument("--output-dir", type=Path, default=Path("./custom_policies"),
                        help="Output directory for downloaded policies")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    required_vars = ["ANYPOINT_CLIENT_ID", "ANYPOINT_CLIENT_SECRET", "ANYPOINT_ORG_ID"]
    for var in required_vars:
        if not os.environ.get(var):
            print(f"Error: Required environment variable {var} is not set", file=sys.stderr)
            sys.exit(1)

    try:
        from anypoint_sdk import AnypointClient  # pragma: no cover
    except ImportError:
        print("Error: anypoint-sdk is required. Install with: pip install mule-discovery[anypoint]", file=sys.stderr)
        sys.exit(1)

    client_id = os.environ["ANYPOINT_CLIENT_ID"]
    client_secret = os.environ["ANYPOINT_CLIENT_SECRET"]
    org_id = os.environ["ANYPOINT_ORG_ID"]

    client = AnypointClient.from_client_credentials(client_id, client_secret)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    from mule_discovery.anypoint.exchange import download_policies
    results = download_policies(client, org_id, args.output_dir)

    print(json.dumps({"organization_id": org_id, "policies": results}, indent=2))


if __name__ == "__main__":
    main()
