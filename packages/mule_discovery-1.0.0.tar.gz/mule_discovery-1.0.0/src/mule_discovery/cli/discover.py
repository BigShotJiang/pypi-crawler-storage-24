"""mule-discover CLI entry point.

Recursively finds Mule applications under a directory and runs
migration complexity discovery on each.
"""

import argparse
import json
import sys
from pathlib import Path

from mule_discovery import discover_mule_app
from mule_discovery.models.scoring import ComplexityThresholds
from mule_discovery.output.json_output import render_json
from mule_discovery.output.yaml_output import render_yaml
from mule_discovery.output.text_output import render_text
from mule_discovery.parsers.file_discovery import find_mule_apps
from mule_discovery.parsers.pom import extract_app_name


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Discover Mule applications and assess migration complexity",
    )
    parser.add_argument("search_path", type=Path, help="Directory to search for Mule applications")
    parser.add_argument("--output-dir", "-o", type=Path, default=None,
                        help="Output directory for inventory files (default: current directory)")
    parser.add_argument("--json", action="store_true", help="Output as JSON instead of YAML")
    parser.add_argument("--quiet", "-q", action="store_true", help="Suppress progress and summary output")
    parser.add_argument("--flow-low", type=int, default=6, help="Max components for LOW flow complexity")
    parser.add_argument("--flow-medium", type=int, default=14, help="Max components for MEDIUM flow complexity")
    parser.add_argument("--flow-high", type=int, default=25, help="Max components for HIGH flow complexity")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    if not args.search_path.exists():
        print(f"Error: Path does not exist: {args.search_path}", file=sys.stderr)
        sys.exit(1)

    if not args.search_path.is_dir():
        print(f"Error: Path is not a directory: {args.search_path}", file=sys.stderr)
        sys.exit(1)

    thresholds = ComplexityThresholds(
        flow_low_max=args.flow_low,
        flow_medium_max=args.flow_medium,
        flow_high_max=args.flow_high,
    )

    output_dir = args.output_dir or Path.cwd()
    output_dir.mkdir(parents=True, exist_ok=True)

    apps = find_mule_apps(args.search_path.resolve())

    if not apps:
        if not args.quiet:
            print("No Mule applications found.", file=sys.stderr)
        sys.exit(0)

    if not args.quiet:
        print(f"Found {len(apps)} Mule application(s)", file=sys.stderr)

    ext = ".json" if args.json else ".yaml"
    results = []

    for app in apps:
        app_name = extract_app_name(app)
        if not args.quiet:
            print(f"Processing: {app_name}...", file=sys.stderr)
        try:
            result = discover_mule_app(app, thresholds)
            output_file = output_dir / f"{app_name}-inventory{ext}"
            output = render_json(result) if args.json else render_yaml(result)
            with open(output_file, "w") as f:
                f.write(output)

            if not args.quiet:
                print(render_text(result), file=sys.stderr)
                print(f"  -> {output_file}", file=sys.stderr)

            results.append({"app_name": app_name, "app_path": str(app),
                            "output_file": str(output_file), "success": True, "error": None})
        except Exception as e:
            results.append({"app_name": app_name, "app_path": str(app),
                            "output_file": "", "success": False, "error": str(e)})
            if not args.quiet:
                print(f"  -> FAILED: {e}", file=sys.stderr)

    if args.json:
        print(json.dumps(results, indent=2))
    else:
        for r in results:
            status = "OK" if r["success"] else f"FAILED ({r['error']})"
            print(f"  {r['app_name']}: {status}")


if __name__ == "__main__":
    main()
