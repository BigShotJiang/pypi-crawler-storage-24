"""mule-scan-policies CLI entry point."""

import argparse
import json
import os
import sys


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Scan Anypoint Platform API policies")
    parser.add_argument("--format", choices=["json", "text"], default="text", help="Output format")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    required_vars = ["ANYPOINT_CLIENT_ID", "ANYPOINT_CLIENT_SECRET", "ANYPOINT_ORG_ID", "ANYPOINT_ENV_ID"]
    for var in required_vars:
        if not os.environ.get(var):
            print(f"Error: Required environment variable {var} is not set", file=sys.stderr)
            sys.exit(1)

    try:
        from anypoint_sdk import AnypointClient  # pragma: no cover
    except ImportError:
        print("Error: anypoint-sdk is required. Install with: pip install mule-discovery[anypoint]", file=sys.stderr)
        sys.exit(1)

    client_id = os.environ["ANYPOINT_CLIENT_ID"]
    client_secret = os.environ["ANYPOINT_CLIENT_SECRET"]
    org_id = os.environ["ANYPOINT_ORG_ID"]
    env_id = os.environ["ANYPOINT_ENV_ID"]

    client = AnypointClient.from_client_credentials(client_id, client_secret)

    from mule_discovery.anypoint.policies import scan_policies
    results = scan_policies(client, org_id, env_id)

    if args.format == "json":
        print(json.dumps({"organization_id": org_id, "environment_id": env_id, "apis": results}, indent=2))
    else:
        print(f"Scanned {len(results)} APIs")
        for item in results:
            api = item["api"]
            policies = item["policies"]
            print(f"\n  {api.get('exchangeAssetName', api.get('assetId', 'unknown'))}: {len(policies)} policies")


if __name__ == "__main__":
    main()
