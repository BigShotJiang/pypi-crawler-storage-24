"""Mule Discovery — scan Mule applications for migration complexity assessment."""

__version__ = "4.0.0"

import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from xml.etree import ElementTree as ET

from mule_discovery.analysis.classification import FlowType
from mule_discovery.analysis.scoring import calculate_score
from mule_discovery.analysis.classification import calculate_source_summary
from mule_discovery.analysis.dependencies import (
    extract_external_dependencies,
    extract_out_of_scope_items,
    extract_validations,
)
from mule_discovery.models.result import DiscoveryResult
from mule_discovery.models.scoring import ComplexityThresholds
from mule_discovery.parsers.aws import extract_aws_services
from mule_discovery.parsers.file_discovery import find_mule_xml_files, collect_source_files
from mule_discovery.parsers.http_auth import (
    collect_all_request_configs,
    collect_http_auth_info,
)
from mule_discovery.parsers.mule_xml import (
    build_listener_config_map,
    extract_flows,
    extract_http_listeners,
    find_scheduled_jobs,
)
from mule_discovery.parsers.openapi import find_api_specifications
from mule_discovery.parsers.pom import (
    extract_app_name,
    extract_connectors_from_pom,
    extract_mule_version,
    update_connector_usage,
)
from mule_discovery.parsers.soap import extract_soap_services


THRESHOLDS = ComplexityThresholds()


def discover_mule_app(app_path: Path, thresholds: Optional[ComplexityThresholds] = None) -> DiscoveryResult:
    """Main discovery function."""
    if thresholds is None:
        thresholds = THRESHOLDS

    result = DiscoveryResult()
    result.created_at = datetime.now(timezone.utc).isoformat()
    result.app_name = extract_app_name(app_path)
    result.mule_version = extract_mule_version(app_path)
    result.connectors = extract_connectors_from_pom(app_path)

    # Check for parent POM inheritance
    pom_file = app_path / "pom.xml"
    if pom_file.exists():
        try:
            with open(pom_file, "r") as f:
                pom_content = f.read()
            if "<parent>" in pom_content:
                result.warnings.append("Parent POM detected - inherited dependencies may not be fully resolved")
        except Exception:
            pass

    main_spec, supporting_specs = find_api_specifications(app_path)
    result.api_specification = main_spec
    result.supporting_specifications = supporting_specs

    result.source_files = collect_source_files(app_path)

    xml_files = find_mule_xml_files(app_path)

    if not xml_files:
        print(f"Warning: No Mule XML files found in {app_path}", file=sys.stderr)
        result.summary = {
            "flow_count": 0,
            "warnings": result.warnings,
            "scanned_files": [],
        }
        return result

    # Build global listener config map across all XML files
    global_config_map = {}
    for xml_file in xml_files:
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
            file_configs = build_listener_config_map(root)
            global_config_map.update(file_configs)
        except Exception:
            pass

    all_flows = []
    all_dataweave = []
    all_error_handlers = []
    all_http_listeners = []
    all_scheduled_jobs = []
    all_external_deps = []
    all_excluded_flows = []
    all_soap_services = []
    all_aws_services = {"sqs": [], "s3": [], "dynamodb": []}
    all_validations = []

    global_request_configs = collect_all_request_configs(xml_files, app_path)
    http_auth_map = collect_http_auth_info(xml_files, app_path)

    for xml_file in xml_files:
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()

            # Detect dynamic flow-refs
            for flow_ref in root.findall(".//{*}flow-ref"):
                ref_name = flow_ref.get("name", "")
                if ref_name.startswith("#["):
                    rel_path = str(xml_file.relative_to(app_path))
                    result.warnings.append(f"Dynamic flow-ref detected in {rel_path} - manual review required")

            # Detect property placeholders in critical config fields
            critical_attrs = ("host", "port", "url", "basePath", "username", "password", "database")
            rel_path = str(xml_file.relative_to(app_path))
            placeholder_warned = False
            for elem in root.iter():
                if placeholder_warned:
                    break
                for attr in critical_attrs:
                    value = elem.get(attr, "")
                    if "${" in value:
                        result.warnings.append(f"Property placeholder in {attr} detected in {rel_path} - runtime value cannot be determined statically")
                        placeholder_warned = True
                        break

            flows, dw_list, error_handlers, excluded = extract_flows(
                root,
                xml_file,
                app_path,
                global_config_map,
                thresholds,
            )
            all_flows.extend(flows)
            all_dataweave.extend(dw_list)
            all_error_handlers.extend(error_handlers)
            all_excluded_flows.extend(excluded)

            listeners = extract_http_listeners(root, xml_file, app_path)
            all_http_listeners.extend(listeners)

            jobs = find_scheduled_jobs(root, xml_file, app_path)
            all_scheduled_jobs.extend(jobs)

            ext_deps = extract_external_dependencies(root, xml_file, app_path, global_request_configs)
            all_external_deps.extend(ext_deps)

            all_soap_services = extract_soap_services(root, xml_file, app_path, all_soap_services)

            all_aws_services = extract_aws_services(root, xml_file, app_path, all_aws_services)

            # Extract validations per flow
            for flow_elem in root.findall(".//{*}flow") + root.findall(".//{*}sub-flow"):
                flow_name = flow_elem.get("name", "")
                validations = extract_validations(flow_elem, xml_file, app_path, flow_name)
                all_validations.extend(validations)

        except ET.ParseError as e:
            print(f"Warning: Could not parse {xml_file}: {e}", file=sys.stderr)
        except Exception as e:
            print(f"Warning: Error processing {xml_file}: {e}", file=sys.stderr)

    # Re-number IDs
    for i, flow in enumerate(all_flows, 1):
        flow.id = f"FLOW-{i:03d}"

    for i, dw in enumerate(all_dataweave, 1):
        dw.id = f"DW-{i:03d}"

    update_connector_usage(result.connectors, all_flows)

    for listener in all_http_listeners:
        for flow in all_flows:
            if not flow.source:  # pragma: no cover — extract_flows always sets source
                continue
            if flow.source.config_ref != listener.config_name:
                continue
            if not flow.source.path:
                continue

            listener.endpoints.append({
                "path": flow.source.path,
                "method": flow.source.method,
                "flow_id": flow.id,
            })

    flow_name_to_id = {f.name: f.id for f in all_flows}
    for eh in all_error_handlers:
        if eh.flow_name in flow_name_to_id:
            eh.flow_id = flow_name_to_id[eh.flow_name]

    result.flows = all_flows
    result.dataweave_transformations = all_dataweave
    result.http_listeners = all_http_listeners
    result.error_handling = all_error_handlers
    result.scheduled_jobs = all_scheduled_jobs
    result.excluded_flows = all_excluded_flows

    # Deduplicate external dependencies
    seen_deps = {}
    for dep in all_external_deps:
        if dep.name not in seen_deps:
            seen_deps[dep.name] = dep

    unique_deps = list(seen_deps.values())
    for i, dep in enumerate(unique_deps, 1):
        dep.id = f"EXT-{i:03d}"

    result.external_dependencies = [asdict(d) for d in unique_deps]

    result.soap_services = all_soap_services
    result.aws_services = all_aws_services
    result.validations = all_validations

    api_spec_count = len(result.supporting_specifications)
    if result.api_specification:
        api_spec_count += 1

    result.out_of_scope = extract_out_of_scope_items(app_path)
    result.source_summary = calculate_source_summary(all_flows)
    result.score_result = calculate_score(
        all_flows,
        all_dataweave,
        result.out_of_scope,
        thresholds,
        connectors=result.connectors,
        http_auth_map=http_auth_map,
        soap_services=all_soap_services,
    )

    # Build summary
    result.summary = {
        "flow_count": len(all_flows),
        "dataweave_count": len(all_dataweave),
        "total_components": sum(f.component_count for f in all_flows),
        "external_dependency_count": len(unique_deps),
        "soap_service_count": len(all_soap_services),
        "aws_sqs_count": len(all_aws_services["sqs"]),
        "aws_s3_count": len(all_aws_services["s3"]),
        "aws_dynamodb_count": len(all_aws_services["dynamodb"]),
        "validation_count": len(all_validations),
        "out_of_scope_count": len(result.out_of_scope),
        "flow_types": {
            FlowType.API: sum(1 for f in all_flows if f.type == FlowType.API),
            FlowType.EVENT: sum(1 for f in all_flows if f.type == FlowType.EVENT),
            FlowType.SCHEDULED: sum(1 for f in all_flows if f.type == FlowType.SCHEDULED),
            FlowType.BATCH: sum(1 for f in all_flows if f.type == FlowType.BATCH),
            FlowType.SUBFLOW: sum(1 for f in all_flows if f.type == FlowType.SUBFLOW),
        },
        "complexity_breakdown": {
            "flows": {
                "LOW": sum(1 for f in all_flows if f.complexity == "LOW"),
                "MEDIUM": sum(1 for f in all_flows if f.complexity == "MEDIUM"),
                "HIGH": sum(1 for f in all_flows if f.complexity == "HIGH"),
                "VERY_HIGH": sum(1 for f in all_flows if f.complexity == "VERY_HIGH"),
            },
            "transformations": {
                "LOW": sum(1 for d in all_dataweave if d.complexity == "LOW"),
                "MEDIUM": sum(1 for d in all_dataweave if d.complexity == "MEDIUM"),
                "HIGH": sum(1 for d in all_dataweave if d.complexity == "HIGH"),
            },
        },
        "classification_counts": {
            "simple_mapping": sum(1 for d in all_dataweave if d.classification == "simple_mapping"),
            "field_level_logic": sum(1 for d in all_dataweave if d.classification == "field_level_logic"),
            "business_logic": sum(1 for d in all_dataweave if d.classification == "business_logic"),
        },
        "connector_count": len(result.connectors),
        "api_spec_count": api_spec_count,
        "scheduled_job_count": len(all_scheduled_jobs),
        "http_listener_count": len(all_http_listeners),
        "flows_with_batch": sum(1 for f in all_flows if f.has_batch),
        "flows_with_patterns": sum(1 for f in all_flows if f.patterns),
        "scanned_files": [str(f.relative_to(app_path)) for f in xml_files],
        "warnings": result.warnings,
    }

    return result
