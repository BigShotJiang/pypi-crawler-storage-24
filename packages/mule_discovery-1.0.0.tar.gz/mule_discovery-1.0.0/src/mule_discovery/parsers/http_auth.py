"""HTTP auth extraction from request-configs."""

import re
from pathlib import Path
from typing import Any, Dict, List, Optional
from xml.etree import ElementTree as ET

from mule_discovery.xml_helpers import find_element_line_number, get_element_tag


def classify_credential_source(expression: str) -> str:
    """Classify where a credential expression gets its value from."""
    if not expression:
        return "literal"
    expr = expression.strip()
    if re.search(r'vars\.v?[Ss]ecret', expr) or "secure::" in expr:
        return "secrets_manager"
    if re.search(r"p\(\s*['\"]", expr) or re.search(r'\$\{', expr):
        return "property"
    if re.search(r'Mule::p\(.*env', expr, re.IGNORECASE) or "System.getenv" in expr:
        return "env"
    return "literal"


def extract_http_auth(config_element: ET.Element) -> Optional[Dict[str, Any]]:
    """Extract authentication metadata from an HTTP request-config element."""
    auth_elements = []

    for child in config_element:
        _, child_local = get_element_tag(child)
        child_prefix, _ = get_element_tag(child)

        if child_prefix in ("http", "https") and child_local.endswith("-authentication"):
            auth_elements.append(child)

        if child_local in ("request-connection", "connection"):
            for grandchild in child:
                _, gc_local = get_element_tag(grandchild)
                gc_prefix, _ = get_element_tag(grandchild)

                if gc_prefix in ("http", "https") and gc_local == "authentication":
                    for auth_child in grandchild:
                        _, ac_local = get_element_tag(auth_child)
                        ac_prefix, _ = get_element_tag(auth_child)
                        if ac_prefix in ("http", "https") and ac_local.endswith("-authentication"):
                            auth_elements.append(auth_child)

                elif gc_prefix in ("http", "https") and gc_local.endswith("-authentication"):
                    auth_elements.append(grandchild)

    if not auth_elements:
        return None

    auth_elem = auth_elements[0]
    _, auth_local = get_element_tag(auth_elem)

    if "basic-authentication" in auth_local:
        username_expr = auth_elem.get("username", "")
        password_expr = auth_elem.get("password", "")
        return {
            "type": "basic",
            "username_source": classify_credential_source(username_expr),
            "password_source": classify_credential_source(password_expr),
        }
    elif "bearer-authentication" in auth_local:
        token_expr = auth_elem.get("token", "") or auth_elem.get("accessToken", "")
        return {
            "type": "bearer",
            "token_source": classify_credential_source(token_expr),
        }
    elif "ntlm-authentication" in auth_local:
        return {"type": "ntlm"}
    elif "digest-authentication" in auth_local:
        return {"type": "digest"}
    elif "oauth" in auth_local.lower():
        return {"type": "oauth2"}

    return {"type": auth_local.replace("-authentication", "")}


def collect_all_request_configs(xml_files: List[Path], app_path: Path) -> Dict[str, Dict[str, Any]]:
    """Collect all http:request-config definitions across all XML files."""
    all_configs = {}

    for xml_file in xml_files:
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
            rel_path = str(xml_file.relative_to(app_path))
        except Exception:
            continue

        for config in root.findall(".//{*}request-config"):
            prefix, _ = get_element_tag(config)
            if prefix not in ("http", "https"):
                continue

            config_name = config.get("name", "")
            if not config_name:
                continue

            host = ""
            port = ""
            base_path = ""
            protocol = "https" if prefix == "https" else "http"

            for conn in config.findall(".//{*}request-connection"):
                host = conn.get("host", "")
                port = conn.get("port", "")
                base_path = conn.get("basePath", "")

            if not host:
                host = config.get("host", "")
            if not port:
                port = config.get("port", "")
            if not base_path:
                base_path = config.get("basePath", "")
            if config.get("protocol"):
                protocol = config.get("protocol", "").lower()

            line_num = find_element_line_number(xml_file, config_name, "request-config")

            all_configs[config_name] = {
                "source_file": rel_path,
                "line_number": line_num,
                "connection": {
                    "protocol": protocol,
                    "host": host,
                    "port": port,
                    "base_path": base_path,
                }
            }

    return all_configs


def collect_http_auth_info(xml_files: List[Path], app_path: Path) -> Dict[str, Dict[str, Any]]:
    """Collect HTTP auth metadata from all request-config elements."""
    auth_map = {}
    for xml_file in xml_files:
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
        except Exception:
            continue

        for config in root.findall(".//{*}request-config"):
            prefix, _ = get_element_tag(config)
            if prefix not in ("http", "https"):
                continue
            config_name = config.get("name", "")
            if not config_name:
                continue
            auth_info = extract_http_auth(config)
            if auth_info:
                auth_map[config_name] = auth_info

    return auth_map
