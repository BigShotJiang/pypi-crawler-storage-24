"""OAS/RAML spec detection."""

import re
from pathlib import Path
from typing import List, Optional, Tuple

from mule_discovery.models.schemas import ApiSpecInfo


def find_api_specifications(app_path: Path) -> Tuple[Optional[ApiSpecInfo], List[ApiSpecInfo]]:
    """Find RAML and OpenAPI specification files."""
    main_spec = None
    supporting_specs = []

    search_paths = [
        app_path / "src" / "main" / "resources",
        app_path / "src" / "main" / "api",
        app_path / "api",
    ]

    existing_paths = [p for p in search_paths if p.exists()]
    if not existing_paths:
        return None, []

    app_name = app_path.name
    raml_candidates = []

    for search_path in existing_paths:
        for raml_file in search_path.rglob("*.raml"):
            try:
                rel_path = str(raml_file.relative_to(app_path))
                with open(raml_file) as f:
                    content = f.read()

                version_match = re.search(r"version:\s*(\S+)", content)
                version = version_match.group(1) if version_match else ""
                endpoint_count = len(re.findall(r"^/\w+:", content, re.MULTILINE))

                is_main_candidate = False
                if re.search(r"#%RAML\s+1\.\d+", content) and endpoint_count > 0:
                    is_main_candidate = True
                if raml_file.stem == app_name or raml_file.stem.replace("-", "_") == app_name.replace("-", "_"):
                    is_main_candidate = True

                spec = ApiSpecInfo(
                    type="raml",
                    source_file=rel_path,
                    version=version,
                    endpoint_count=endpoint_count,
                    requires_conversion=True,
                )

                if is_main_candidate:
                    raml_candidates.append((spec, endpoint_count, raml_file.stem == app_name))
                else:
                    supporting_specs.append(spec)
            except Exception:
                pass

    if raml_candidates:
        raml_candidates.sort(key=lambda x: (not x[2], -x[1]))
        main_spec = raml_candidates[0][0]
        for spec, _, _ in raml_candidates[1:]:
            supporting_specs.append(spec)

    for search_path in existing_paths:
        for ext in ("*.yaml", "*.yml", "*.json"):
            for oas_file in search_path.rglob(ext):
                try:
                    with open(oas_file) as f:
                        content = f.read()

                    if "openapi" in content.lower() or "swagger" in content.lower():
                        rel_path = str(oas_file.relative_to(app_path))
                        version_match = re.search(r'version:\s*["\']?(\S+)["\']?', content)
                        version = version_match.group(1) if version_match else ""

                        spec = ApiSpecInfo(
                            type="openapi",
                            source_file=rel_path,
                            version=version,
                            endpoint_count=0,
                            requires_conversion=False,
                        )

                        if main_spec is None:
                            main_spec = spec
                        else:
                            supporting_specs.append(spec)
                except Exception:
                    pass

    return main_spec, supporting_specs
