"""Find Mule XML files, collect source files, find Mule apps."""

from pathlib import Path
from typing import List

from mule_discovery.models.dependencies import SourceFiles


def find_mule_xml_files(app_path: Path) -> List[Path]:
    """Find all Mule XML configuration files."""
    xml_files = []

    for mule_dir in ["src/main/mule", "src/main/app"]:
        config_path = app_path / mule_dir
        if config_path.exists():
            xml_files.extend(config_path.rglob("*.xml"))

    resources_path = app_path / "src" / "main" / "resources"
    if resources_path.exists():
        for xml_file in resources_path.rglob("*.xml"):
            if "log4j" not in xml_file.name.lower():
                try:
                    with open(xml_file) as f:
                        first_lines = f.read(500)
                        if "mulesoft.org/schema/mule" in first_lines:
                            xml_files.append(xml_file)
                except Exception:
                    pass

    return sorted(set(xml_files))


def collect_source_files(app_path: Path) -> SourceFiles:
    """Collect and categorize all source files in the Mule application."""
    source_files = SourceFiles()

    for mule_dir in ["src/main/mule", "src/main/app"]:
        config_path = app_path / mule_dir
        if config_path.exists():
            for xml_file in config_path.rglob("*.xml"):
                rel_path = str(xml_file.relative_to(app_path))
                source_files.mule_configs.append(rel_path)

    resources_path = app_path / "src" / "main" / "resources"
    if resources_path.exists():
        for prop_file in resources_path.rglob("*.properties"):
            rel_path = str(prop_file.relative_to(app_path))
            source_files.properties.append(rel_path)

        for yaml_file in resources_path.rglob("*.yaml"):
            rel_path = str(yaml_file.relative_to(app_path))
            if "/api/" not in rel_path:
                source_files.properties.append(rel_path)

        for yml_file in resources_path.rglob("*.yml"):
            rel_path = str(yml_file.relative_to(app_path))
            if "/api/" not in rel_path:
                source_files.properties.append(rel_path)

    api_path = resources_path / "api" if resources_path.exists() else None
    if api_path and api_path.exists():
        for raml_file in api_path.rglob("*.raml"):
            rel_path = str(raml_file.relative_to(app_path))
            source_files.api_specs.append(rel_path)

        for ext in ["*.yaml", "*.yml", "*.json"]:
            for spec_file in api_path.rglob(ext):
                rel_path = str(spec_file.relative_to(app_path))
                source_files.api_specs.append(rel_path)

    if resources_path.exists():
        for dwl_file in resources_path.rglob("*.dwl"):
            rel_path = str(dwl_file.relative_to(app_path))
            source_files.dataweave.append(rel_path)

    java_path = app_path / "src" / "main" / "java"
    if java_path.exists():
        for java_file in java_path.rglob("*.java"):
            rel_path = str(java_file.relative_to(app_path))
            source_files.java.append(rel_path)

    if resources_path.exists():
        for json_file in resources_path.rglob("*.json"):
            rel_path = str(json_file.relative_to(app_path))
            if "/api/" not in rel_path:
                source_files.resources.append(rel_path)

        for xml_file in resources_path.rglob("*.xml"):
            rel_path = str(xml_file.relative_to(app_path))
            source_files.resources.append(rel_path)

    source_files.mule_configs.sort()
    source_files.properties.sort()
    source_files.api_specs.sort()
    source_files.dataweave.sort()
    source_files.java.sort()
    source_files.resources.sort()

    return source_files


def is_mule_app_root(directory: Path) -> bool:
    """Check if directory is a Mule application root."""
    if (directory / "mule-artifact.json").exists():
        return True

    if (directory / "mule-project.xml").exists():
        return True

    pom_file = directory / "pom.xml"
    if not pom_file.exists():
        return False

    mule4_path = directory / "src" / "main" / "mule"
    if mule4_path.exists() and any(mule4_path.glob("*.xml")):
        return True

    mule3_path = directory / "src" / "main" / "app"
    if mule3_path.exists() and any(mule3_path.glob("*.xml")):
        return True

    try:
        with open(pom_file, "r") as f:
            content = f.read()
        if "mule-maven-plugin" in content or "mulesoft.org" in content:
            for xml_file in directory.rglob("*.xml"):
                if "src/main" in str(xml_file):
                    try:
                        with open(xml_file, "r") as xf:
                            if "mulesoft.org/schema/mule" in xf.read(1000):
                                return True
                    except Exception:
                        pass
    except Exception:
        pass

    return False


def find_mule_apps(root_path: Path) -> List[Path]:
    """Find all Mule application roots under the given path."""
    mule_apps = []
    found_roots = set()

    for directory in sorted(root_path.rglob("*")):
        if not directory.is_dir():
            continue

        if any(str(directory).startswith(str(root) + "/") for root in found_roots):
            continue

        if any(
            part in directory.parts
            for part in ("target", "node_modules", ".git", ".idea")
        ):
            continue

        if is_mule_app_root(directory):
            mule_apps.append(directory)
            found_roots.add(directory)

    if is_mule_app_root(root_path):
        mule_apps.insert(0, root_path)

    return sorted(set(mule_apps))
