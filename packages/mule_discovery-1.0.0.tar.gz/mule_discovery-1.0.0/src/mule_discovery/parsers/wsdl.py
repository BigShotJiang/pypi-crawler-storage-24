"""WSDL parsing — operation count, SOAP version."""

from pathlib import Path
from typing import Any, Dict, Optional
from xml.etree import ElementTree as ET

from mule_discovery.constants import SOAP12_NS, WSDL_NS, XS_NS


def resolve_wsdl_path(wsdl_location: str, app_path: Path) -> Optional[Path]:
    """Resolve a WSDL location to an actual file path."""
    if not wsdl_location:
        return None
    if wsdl_location.startswith(("http://", "https://")):
        return None

    clean = wsdl_location.replace("classpath:", "").replace("\\", "/").lstrip("/")
    candidates = [
        app_path / clean,
        app_path / "src" / "main" / "resources" / clean,
        app_path / "src" / "main" / "resources" / "api" / Path(clean).name,
        app_path / "src" / "main" / "resources" / "wsdl" / Path(clean).name,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def parse_wsdl(wsdl_path: Path) -> Optional[Dict[str, Any]]:
    """Parse a WSDL file and extract operation count and metadata."""
    try:
        tree = ET.parse(str(wsdl_path))
        root = tree.getroot()
    except ET.ParseError:
        return None

    schema = root.find(f".//{{{XS_NS}}}schema")
    target_ns = schema.get("targetNamespace", "") if schema is not None else ""
    efd = schema.get("elementFormDefault", "unqualified") if schema is not None else "unqualified"

    soap_version = "1.1"
    if root.find(f".//{{{SOAP12_NS}}}binding") is not None:
        soap_version = "1.2"

    operations = []
    for op in root.findall(f".//{{{WSDL_NS}}}portType/{{{WSDL_NS}}}operation"):
        name = op.get("name")
        if name:
            operations.append({"name": name})

    return {
        "target_namespace": target_ns,
        "element_form_default": efd,
        "soap_version": soap_version,
        "operations": operations,
        "operation_count": len(operations),
    }
