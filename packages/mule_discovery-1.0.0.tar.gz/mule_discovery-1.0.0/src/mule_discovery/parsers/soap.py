"""SOAP service extraction (WSC, SOAPkit)."""

from pathlib import Path
from typing import Any, Dict, List
from xml.etree import ElementTree as ET

from mule_discovery.parsers.wsdl import parse_wsdl, resolve_wsdl_path
from mule_discovery.xml_helpers import get_element_tag


def extract_soap_services(
    root: ET.Element,
    source_file: Path,
    app_path: Path,
    existing_soap_services: List[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """Extract SOAP service configurations (WSC client, SOAPkit service)."""
    soap_services = existing_soap_services if existing_soap_services else []

    try:
        rel_path = str(source_file.relative_to(app_path))
    except ValueError:
        rel_path = str(source_file)

    seen_configs = {s["config_name"] for s in soap_services}

    for elem in root.iter():
        prefix, local_name = get_element_tag(elem)

        if prefix == "wsc" and local_name == "config":
            config_name = elem.get("name", "")
            if config_name and config_name not in seen_configs:
                seen_configs.add(config_name)

                service_entry = {
                    "config_name": config_name,
                    "direction": "client",
                    "source_file": rel_path,
                    "operations": [],
                }

                for child in elem:
                    _, child_local = get_element_tag(child)
                    if "connection" in child_local.lower():
                        wsdl_location = child.get("wsdlLocation", "")
                        service = child.get("service", "")
                        port = child.get("port", "")
                        address = child.get("address", "")

                        if wsdl_location:
                            service_entry["wsdl_location"] = wsdl_location
                            wsdl_file = resolve_wsdl_path(wsdl_location, app_path)
                            if wsdl_file:
                                wsdl_info = parse_wsdl(wsdl_file)
                                if wsdl_info:
                                    service_entry["wsdl_operation_count"] = wsdl_info["operation_count"]
                                    service_entry["soap_version"] = wsdl_info["soap_version"]
                        if service:
                            service_entry["service_name"] = service
                        if port:
                            service_entry["port_name"] = port
                        if address:
                            service_entry["endpoint"] = address
                        break

                soap_services.append(service_entry)

        if prefix == "wsc" and local_name == "consume":
            config_ref = elem.get("config-ref", "")
            operation = elem.get("operation", "")

            wsc_entry = next((s for s in soap_services if s["config_name"] == config_ref and s["direction"] == "client"), None)

            if wsc_entry is not None and operation:
                op_entry = {"name": operation}
                if op_entry not in wsc_entry["operations"]:
                    wsc_entry["operations"].append(op_entry)

        if prefix in ("soapkit", "apikit-soap") and local_name == "config":
            config_name = elem.get("name", "")
            if config_name and config_name not in seen_configs:
                seen_configs.add(config_name)

                service_entry = {
                    "config_name": config_name,
                    "direction": "service",
                    "source_file": rel_path,
                    "operations": [],
                }

                wsdl_location = elem.get("wsdlLocation", "")
                service = elem.get("service", "")
                port = elem.get("port", "")

                if wsdl_location:
                    service_entry["wsdl_location"] = wsdl_location
                    wsdl_file = resolve_wsdl_path(wsdl_location, app_path)
                    if wsdl_file:
                        wsdl_info = parse_wsdl(wsdl_file)
                        if wsdl_info:
                            service_entry["wsdl_operation_count"] = wsdl_info["operation_count"]
                            service_entry["soap_version"] = wsdl_info["soap_version"]
                if service:
                    service_entry["service_name"] = service
                if port:
                    service_entry["port_name"] = port

                soap_services.append(service_entry)

    for elem in root.iter():
        _, local_name = get_element_tag(elem)
        if local_name == "flow":
            flow_name = elem.get("name", "")
            if ":\\" in flow_name:
                parts = flow_name.split(":\\")
                if len(parts) == 2:
                    operation_name = parts[0]
                    config_name = parts[1]

                    soapkit_entry = next((s for s in soap_services if s["config_name"] == config_name and s["direction"] == "service"), None)
                    if soapkit_entry is not None:
                        op_entry = {"name": operation_name, "flow_name": flow_name}
                        if op_entry not in soapkit_entry["operations"]:
                            soapkit_entry["operations"].append(op_entry)

    return soap_services
