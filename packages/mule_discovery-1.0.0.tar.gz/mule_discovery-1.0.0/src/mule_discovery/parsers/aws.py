"""AWS service extraction (SQS, S3, DynamoDB)."""

from pathlib import Path
from typing import Any, Dict, List
from xml.etree import ElementTree as ET

from mule_discovery.xml_helpers import get_element_tag


def extract_aws_services(
    root: ET.Element,
    source_file: Path,
    app_path: Path,
    existing_aws_services: Dict[str, List[Dict[str, Any]]] = None,
) -> Dict[str, List[Dict[str, Any]]]:
    """Extract AWS service configurations (SQS, S3, DynamoDB)."""
    aws_services = existing_aws_services if existing_aws_services else {"sqs": [], "s3": [], "dynamodb": []}

    try:
        rel_path = str(source_file.relative_to(app_path))
    except ValueError:
        rel_path = str(source_file)

    seen_sqs_configs = {s["config_name"] for s in aws_services["sqs"]}
    seen_s3_configs = {s["config_name"] for s in aws_services["s3"]}
    seen_dynamodb_configs = {s["config_name"] for s in aws_services["dynamodb"]}

    for elem in root.iter():
        prefix, local_name = get_element_tag(elem)

        if prefix == "sqs" and local_name == "config":
            config_name = elem.get("name", "")
            if config_name and config_name not in seen_sqs_configs:
                seen_sqs_configs.add(config_name)
                connection = {}
                for child in elem:
                    _, child_local = get_element_tag(child)
                    if "connection" in child_local.lower():
                        connection = {
                            "access_key": child.get("accessKey", ""),
                            "secret_key": child.get("secretKey", ""),
                            "region": child.get("region", ""),
                            "custom_endpoint": child.get("customServiceEndpoint", "") or child.get("customSqsEndpoint", ""),
                        }
                        break
                aws_services["sqs"].append({
                    "config_name": config_name,
                    "source_file": rel_path,
                    "connection": connection,
                    "operations": [],
                })

        if prefix == "sqs" and local_name in ("send-message", "receive-messages", "delete-message", "get-queue-url"):
            config_ref = elem.get("config-ref", "")
            queue_url = elem.get("queueUrl", "")
            sqs_entry = next((s for s in aws_services["sqs"] if s["config_name"] == config_ref), None)
            if sqs_entry is not None:
                op_entry = {"type": local_name, "queue_url": queue_url}
                if op_entry not in sqs_entry["operations"]:
                    sqs_entry["operations"].append(op_entry)

        if prefix == "s3" and local_name == "config":
            config_name = elem.get("name", "")
            if config_name and config_name not in seen_s3_configs:
                seen_s3_configs.add(config_name)
                connection = {}
                for child in elem:
                    _, child_local = get_element_tag(child)
                    if "connection" in child_local.lower():
                        connection = {
                            "access_key": child.get("accessKey", ""),
                            "secret_key": child.get("secretKey", ""),
                            "region": child.get("region", ""),
                            "custom_endpoint": child.get("customServiceEndpoint", ""),
                        }
                        break
                aws_services["s3"].append({
                    "config_name": config_name,
                    "source_file": rel_path,
                    "connection": connection,
                    "operations": [],
                })

        if prefix == "s3" and local_name in ("put-object", "get-object", "delete-object", "list-objects", "copy-object"):
            config_ref = elem.get("config-ref", "")
            bucket = elem.get("bucketName", "")
            s3_entry = next((s for s in aws_services["s3"] if s["config_name"] == config_ref), None)
            if s3_entry is not None:
                op_entry = {"type": local_name, "bucket": bucket}
                if op_entry not in s3_entry["operations"]:
                    s3_entry["operations"].append(op_entry)

        if prefix == "dynamodb" and local_name == "config":
            config_name = elem.get("name", "")
            if config_name and config_name not in seen_dynamodb_configs:
                seen_dynamodb_configs.add(config_name)
                connection = {}
                for child in elem:
                    _, child_local = get_element_tag(child)
                    if "connection" in child_local.lower():
                        connection = {
                            "access_key": child.get("accessKey", ""),
                            "secret_key": child.get("secretKey", ""),
                            "region": child.get("region", ""),
                            "custom_endpoint": child.get("customServiceEndpoint", ""),
                        }
                        break
                aws_services["dynamodb"].append({
                    "config_name": config_name,
                    "source_file": rel_path,
                    "connection": connection,
                    "operations": [],
                })

        if prefix == "dynamodb" and local_name in ("put-item", "get-item", "delete-item", "query", "scan"):
            config_ref = elem.get("config-ref", "")
            table = elem.get("tableName", "")
            dynamodb_entry = next((d for d in aws_services["dynamodb"] if d["config_name"] == config_ref), None)
            if dynamodb_entry is not None:
                op_entry = {"type": local_name, "table": table}
                if op_entry not in dynamodb_entry["operations"]:
                    dynamodb_entry["operations"].append(op_entry)

    return aws_services
