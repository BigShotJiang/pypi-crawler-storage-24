"""DataWeave script extraction and structure analysis."""

import re
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from xml.etree import ElementTree as ET

from mule_discovery.xml_helpers import get_element_tag


def find_external_dwl_file(resource_path: str, app_path: Path) -> Optional[Path]:
    """Find external DWL file referenced by resource attribute."""
    if not resource_path:
        return None

    dwl_path = resource_path.replace("classpath:", "").replace("\\", "/")

    potential_paths = [
        app_path / "src" / "main" / "resources" / dwl_path,
        app_path / "src" / "main" / "app" / dwl_path,
        app_path / "src" / "main" / "resources" / "dwl" / Path(dwl_path).name,
        app_path / "src" / "main" / "resources" / "dw-config" / Path(dwl_path).name,
        app_path / "mappings" / Path(dwl_path).name,
    ]

    for dwl_file in potential_paths:
        if dwl_file.exists():
            return dwl_file

    return None


def extract_dataweave_script(transform_elem: ET.Element, app_path: Optional[Path] = None) -> Tuple[str, Optional[str]]:
    """Extract DataWeave script from transform element."""
    script_parts = []
    external_file = None

    for elem in transform_elem.iter():
        _, local_name = get_element_tag(elem)

        if local_name in ("set-payload", "set-variable", "message"):
            resource = elem.get("resource", "")
            if resource and "classpath:" in resource:
                external_file = Path(resource.replace("classpath:", "").replace("\\", "/")).name

                if app_path:
                    dwl_file = find_external_dwl_file(resource, app_path)
                    if dwl_file:
                        try:
                            with open(dwl_file, "r", encoding="utf-8") as f:
                                content = f.read()
                                if content.strip():
                                    script_parts.append(content.strip())
                        except Exception:
                            pass

            elif elem.text and elem.text.strip():
                script_parts.append(elem.text.strip())

    return "\n".join(script_parts), external_file


def extract_dataweave_structure(script: str) -> Dict[str, Any]:
    """Extract input/output field structure from DataWeave script."""
    if not script:
        return {}

    result = {
        "dw_version": "2.0",
        "input_fields": [],
        "output_fields": [],
        "vars_references": [],
        "attributes_references": [],
        "has_type_hints": False,
    }

    version_match = re.search(r"%dw\s+(\d+\.\d+)", script)
    if version_match:
        result["dw_version"] = version_match.group(1)

    if "%input" in script or "%output" in script:
        result["has_type_hints"] = True

    payload_refs = set()
    for match in re.finditer(r"payload\.([a-zA-Z_][a-zA-Z0-9_.]*)", script):
        payload_refs.add("payload." + match.group(1))
    result["input_fields"] = sorted(payload_refs)

    vars_refs = set()
    for match in re.finditer(r"(?:vars|flowVars)\.([a-zA-Z_][a-zA-Z0-9_.]*)", script):
        vars_refs.add("vars." + match.group(1))
    result["vars_references"] = sorted(vars_refs)

    attr_refs = set()
    for match in re.finditer(r"attributes\.([a-zA-Z_][a-zA-Z0-9_.]*)", script):
        attr_refs.add("attributes." + match.group(1))
    result["attributes_references"] = sorted(attr_refs)

    output_refs = set()
    body_match = re.search(r"---\s*\{?\s*(.+)", script, re.DOTALL)
    if body_match:
        body = body_match.group(1)
        for match in re.finditer(r'^\s*"?([a-zA-Z_][a-zA-Z0-9_]*)"?\s*:', body, re.MULTILINE):
            output_refs.add(match.group(1))
    result["output_fields"] = sorted(output_refs)

    return result
