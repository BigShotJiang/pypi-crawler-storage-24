"""Mule XML parsing — flow extraction, listener/connector detection."""

from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from xml.etree import ElementTree as ET

from mule_discovery.constants import NAMESPACES
from mule_discovery.models.dataweave import DataWeaveInfo
from mule_discovery.models.flows import (
    AsyncInfo,
    BatchInfo,
    BatchStepInfo,
    CacheInfo,
    ChoiceBranch,
    ChoiceInfo,
    ErrorHandlerInfo,
    FlowInfo,
    ForeachInfo,
    PatternInfo,
    ScatterGatherInfo,
    ScatterGatherRoute,
    ScriptInfo,
    SourceInfo,
    TransactionInfo,
    UntilSuccessfulInfo,
)
from mule_discovery.models.listeners import HttpListenerInfo, ScheduledJobInfo
from mule_discovery.models.scoring import ComplexityThresholds
from mule_discovery.xml_helpers import (
    find_element_line_number,
    find_transform_line_numbers,
    get_element_tag,
    get_qualified_name,
    has_apikit_console,
    is_config_element,
    is_container_element,
    is_processor_element,
    is_reference_element,
    is_source_element,
    is_terminal_processor,
)

from mule_discovery.analysis.patterns import has_async_processor, classify_choice_pattern
from mule_discovery.analysis.complexity import analyze_script_complexity, assign_flow_complexity
from mule_discovery.parsers.dataweave import (
    extract_dataweave_script,
    extract_dataweave_structure,
)
from mule_discovery.analysis.complexity import analyze_dataweave_complexity


def build_listener_config_map(root: ET.Element) -> Dict[str, Dict[str, str]]:
    """Build a map of listener config names to their properties."""
    config_map = {}

    for config in root.findall(".//{*}listener-config"):
        prefix, _ = get_element_tag(config)
        if prefix not in ("http", "https"):
            continue

        config_name = config.get("name", "")
        if not config_name:
            continue

        config_data = {
            "host": "0.0.0.0",
            "port": "8081",
            "base_path": "",
            "protocol": "HTTPS" if prefix == "https" else "HTTP",
        }

        for conn in config.findall(".//{*}listener-connection"):
            config_data["host"] = conn.get("host", config_data["host"])
            config_data["port"] = conn.get("port", config_data["port"])
            config_data["base_path"] = conn.get("basePath", config_data["base_path"])
            protocol = conn.get("protocol")
            if protocol:
                config_data["protocol"] = protocol.upper()

        config_map[config_name] = config_data

    return config_map


def get_listener_protocol(config_map: Dict[str, Dict[str, str]], config_ref: str) -> Optional[str]:
    """Get protocol from listener config."""
    if config_ref and config_ref in config_map:
        return config_map[config_ref].get("protocol")
    return None


def _build_http_source(elem: ET.Element, prefix: str, is_listener: bool, protocol: Optional[str] = None) -> SourceInfo:
    """Build SourceInfo for HTTP/HTTPS source elements."""
    if is_listener:
        return SourceInfo(
            type=f"{prefix}:listener",
            config_ref=elem.get("config-ref"),
            path=elem.get("path"),
            method=elem.get("allowedMethods") or elem.get("method") or "ANY",
            protocol=protocol,
        )
    else:
        return SourceInfo(
            type=f"{prefix}:inbound-endpoint",
            path=elem.get("path") or elem.get("address"),
            method=elem.get("method") or "ANY",
            protocol=protocol,
        )


def _build_messaging_source(elem: ET.Element, prefix: str, is_listener: bool) -> SourceInfo:
    """Build SourceInfo for VM/JMS/AMQP source elements."""
    if is_listener:
        return SourceInfo(
            type=f"{prefix}:listener",
            config_ref=elem.get("config-ref"),
            queue=elem.get("queueName"),
            destination=elem.get("destination"),
        )
    else:
        return SourceInfo(
            type=f"{prefix}:inbound-endpoint",
            queue=elem.get("path") or elem.get("queue"),
            destination=elem.get("topic"),
        )


def _build_file_source(elem: ET.Element, prefix: str, is_listener: bool) -> SourceInfo:
    """Build SourceInfo for File/FTP/SFTP source elements."""
    if is_listener:
        return SourceInfo(
            type=f"{prefix}:listener",
            config_ref=elem.get("config-ref"),
            path=elem.get("directory"),
        )
    else:
        return SourceInfo(
            type=f"{prefix}:inbound-endpoint",
            path=elem.get("path") or elem.get("address"),
        )


def extract_flow_source(flow_elem: ET.Element, config_map: Dict[str, Dict[str, str]]) -> SourceInfo:
    """Extract source/trigger information from a flow element."""
    for child in flow_elem:
        prefix, local_name = get_element_tag(child)

        if local_name == "listener" and prefix in ("http", "https"):
            config_ref = child.get("config-ref")
            protocol = get_listener_protocol(config_map, config_ref)
            if prefix == "https":
                protocol = "HTTPS"
            return _build_http_source(child, prefix, is_listener=True, protocol=protocol)

        if local_name == "listener" and prefix in ("vm", "jms", "amqp"):
            return _build_messaging_source(child, prefix, is_listener=True)

        if local_name == "listener" and prefix in ("file", "ftp", "sftp"):
            return _build_file_source(child, prefix, is_listener=True)

        if local_name == "inbound-endpoint" and prefix in ("http", "https"):
            protocol = "HTTPS" if prefix == "https" else None
            return _build_http_source(child, prefix, is_listener=False, protocol=protocol)

        if local_name == "inbound-endpoint" and prefix in ("vm", "jms", "amqp"):
            return _build_messaging_source(child, prefix, is_listener=False)

        if local_name == "inbound-endpoint" and prefix in ("file", "ftp", "sftp"):
            return _build_file_source(child, prefix, is_listener=False)

        if local_name == "inbound-endpoint" and prefix == "quartz":
            return SourceInfo(
                type="quartz:inbound-endpoint",
                cron=child.get("cronExpression"),
            )

        if local_name == "scheduler":
            cron = None
            fixed_freq = None
            time_unit = None

            for cron_elem in child.findall(".//{*}cron"):
                cron = cron_elem.get("expression")

            for ff_elem in child.findall(".//{*}fixed-frequency"):
                fixed_freq = ff_elem.get("frequency")
                time_unit = ff_elem.get("timeUnit", "MILLISECONDS")

            return SourceInfo(
                type="scheduler",
                cron=cron,
                fixed_frequency=fixed_freq,
                time_unit=time_unit,
            )

        if local_name == "poll":
            return SourceInfo(
                type="poll",
                fixed_frequency=child.get("frequency"),
                time_unit="MILLISECONDS",
            )

    return SourceInfo(type="none")


def determine_flow_type(source: SourceInfo, flow_elem: ET.Element) -> str:
    """Determine flow type based on source element."""
    prefix, local_name = get_element_tag(flow_elem)
    if prefix == "batch" and local_name == "job":
        return "BATCH"

    category = source.category

    if category in ("http", "https"):
        return "API"

    if category in ("vm", "jms", "amqp", "file", "ftp", "sftp"):
        return "EVENT"

    if category == "scheduler":
        return "SCHEDULED"

    return "SUBFLOW"


def count_components(flow_elem: ET.Element) -> Tuple[int, List[str], Optional[BatchInfo], PatternInfo]:
    """Count all processor components in a flow with pattern detection."""
    components = []
    pattern_info = PatternInfo()

    batch_context = {
        "in_batch": False,
        "current_step": None,
        "in_aggregator": False,
        "job_name": None,
        "steps": {},
    }

    prefix, local_name = get_element_tag(flow_elem)
    if prefix == "batch" and local_name == "job":
        batch_context["in_batch"] = True
        batch_context["job_name"] = flow_elem.get("jobName") or flow_elem.get("name") or "batch_job"

    def collect_child_components(elem: ET.Element) -> List[str]:
        child_components = []
        for child in elem:
            if is_source_element(child) or is_config_element(child) or is_reference_element(child):
                continue
            if is_terminal_processor(child):
                child_components.append(get_qualified_name(child))
            elif is_processor_element(child):
                child_components.append(get_qualified_name(child))
        return child_components

    def _record_batch_component(qname: str, ctx: dict):
        if ctx["in_batch"] and ctx["current_step"]:
            step_data = ctx["steps"].get(ctx["current_step"])
            if step_data:
                if ctx["in_aggregator"]:
                    step_data["aggregator_processors"].append(qname)
                else:
                    step_data["processors"].append(qname)

    def process_element(elem: ET.Element):
        for child in elem:
            qname = get_qualified_name(child)
            _, local_name = get_element_tag(child)

            if is_source_element(child):
                continue
            if is_config_element(child):
                continue
            if is_reference_element(child):
                continue

            if local_name == "job" and "batch" in child.tag:
                batch_context["in_batch"] = True
                batch_context["job_name"] = child.get("jobName") or child.get("name") or "batch_job"
                process_element(child)
                batch_context["in_batch"] = False
                continue

            if local_name == "process-records" and "batch" in child.tag:
                process_element(child)
                continue

            if local_name == "step" and "batch" in child.tag:
                step_name = child.get("name") or f"step_{len(batch_context['steps']) + 1}"
                batch_context["current_step"] = step_name
                batch_context["steps"][step_name] = {"processors": [], "aggregator_processors": []}
                process_element(child)
                batch_context["current_step"] = None
                continue

            if local_name == "aggregator" and "batch" in child.tag:
                batch_context["in_aggregator"] = True
                process_element(child)
                batch_context["in_aggregator"] = False
                continue

            if local_name == "scatter-gather":
                components.append(qname)
                _record_batch_component(qname, batch_context)

                sg_info = ScatterGatherInfo(
                    timeout=child.get("timeout"),
                    max_concurrency=child.get("maxConcurrency"),
                )

                routes = []
                for route in child.findall(".//{*}route"):
                    route_components = collect_child_components(route)
                    routes.append(ScatterGatherRoute(processors=route_components))
                    for rc in route_components:
                        components.append(rc)
                        _record_batch_component(rc, batch_context)

                sg_info.route_count = len(routes)
                sg_info.routes = routes
                sg_info.migration_notes = [
                    f"Scatter-gather with {len(routes)} parallel routes -> CompletableFuture.allOf() or Mono.zip()"
                ]
                pattern_info.scatter_gather.append(sg_info)
                continue

            if local_name == "choice":
                components.append(qname)
                _record_batch_component(qname, batch_context)

                choice_info = ChoiceInfo()

                for when_elem in child.findall(".//{*}when"):
                    condition = when_elem.get("expression")
                    branch_components = collect_child_components(when_elem)
                    choice_info.branches.append(ChoiceBranch(
                        condition=condition,
                        is_otherwise=False,
                        processors=branch_components,
                        has_async_publish=has_async_processor(branch_components),
                    ))
                    for bc in branch_components:
                        components.append(bc)
                        _record_batch_component(bc, batch_context)

                for otherwise_elem in child.findall(".//{*}otherwise"):
                    choice_info.has_otherwise = True
                    branch_components = collect_child_components(otherwise_elem)
                    choice_info.branches.append(ChoiceBranch(
                        condition=None,
                        is_otherwise=True,
                        processors=branch_components,
                        has_async_publish=has_async_processor(branch_components),
                    ))
                    for bc in branch_components:
                        components.append(bc)
                        _record_batch_component(bc, batch_context)

                choice_info.pattern_type = classify_choice_pattern(choice_info)
                choice_info.migration_notes = [
                    f"Choice with {len(choice_info.branches)} branches -> if/else or switch statement"
                ]
                if choice_info.pattern_type == "async_fanout":
                    choice_info.migration_notes.append("All branches publish async -> use wireTap inside choice")
                elif choice_info.pattern_type == "mixed":
                    choice_info.migration_notes.append("Mixed sync/async branches -> review migration approach")
                pattern_info.choices.append(choice_info)
                continue

            if local_name == "try":
                components.append(qname)
                _record_batch_component(qname, batch_context)

                tx_action = child.get("transactionalAction", "")
                tx_type = child.get("transactionType", "")

                try_components = []
                for try_child in child:
                    _, try_child_local = get_element_tag(try_child)
                    if try_child_local not in ("error-handler", "on-error-propagate", "on-error-continue"):
                        if is_processor_element(try_child) or is_terminal_processor(try_child):
                            try_components.append(get_qualified_name(try_child))

                tx_info = TransactionInfo(
                    action=tx_action,
                    tx_type=tx_type,
                    components=try_components,
                )

                if tx_action:
                    tx_info.migration_notes.append(
                        f"Try scope with transactionalAction={tx_action} -> @Transactional"
                    )
                else:
                    tx_info.migration_notes.append("Try scope -> try/catch block")

                pattern_info.transactions.append(tx_info)
                process_element(child)
                continue

            if local_name in ("foreach", "for-each"):
                components.append(qname)
                _record_batch_component(qname, batch_context)

                fe_info = ForeachInfo(
                    collection_expression=child.get("collection"),
                    batch_size=int(child.get("batchSize")) if child.get("batchSize") else None,
                    root_message_var=child.get("rootMessageVariableName"),
                    processors=collect_child_components(child),
                )
                fe_info.migration_notes = ["Foreach loop -> Java Stream or for loop"]
                if fe_info.batch_size:
                    fe_info.migration_notes.append(
                        f"Batch size {fe_info.batch_size} -> Lists.partition() or Spring Batch chunk"
                    )
                pattern_info.foreach_loops.append(fe_info)
                process_element(child)
                continue

            if local_name == "async":
                components.append(qname)
                _record_batch_component(qname, batch_context)

                async_info = AsyncInfo(
                    max_concurrency=child.get("maxConcurrency"),
                    processors=collect_child_components(child),
                )
                async_info.migration_notes = ["Async scope -> @Async or CompletableFuture.runAsync()"]
                pattern_info.async_scopes.append(async_info)
                process_element(child)
                continue

            if local_name == "until-successful":
                components.append(qname)
                _record_batch_component(qname, batch_context)

                retry_info = UntilSuccessfulInfo(
                    max_retries=child.get("maxRetries"),
                    interval_ms=child.get("millisBetweenRetries"),
                    failure_expression=child.get("failureExpression"),
                    processors=collect_child_components(child),
                )
                retry_info.migration_notes = [
                    f"Until-successful -> @Retryable(maxAttempts={retry_info.max_retries or 'default'})"
                ]
                pattern_info.retries.append(retry_info)
                process_element(child)
                continue

            if local_name in ("cache", "cache-scope") and ("ee" in child.tag or "cache" in child.tag):
                components.append(qname)
                _record_batch_component(qname, batch_context)

                cache_info = CacheInfo(
                    caching_strategy_ref=child.get("cachingStrategy-ref") or child.get("caching-strategy-ref"),
                    key_expression=child.get("key") or child.get("keyExpression"),
                    filter_expression=child.get("filterExpression"),
                    processors=collect_child_components(child),
                )
                cache_info.migration_notes = ["Cache scope -> @Cacheable"]
                pattern_info.caches.append(cache_info)
                process_element(child)
                continue

            if local_name in ("execute", "expression-component", "script"):
                components.append(qname)
                _record_batch_component(qname, batch_context)

                script_content = ""
                script_type = child.get("engine", "mel")

                for text_elem in child.findall(".//{*}text"):
                    if text_elem.text:
                        script_content = text_elem.text
                        break

                if not script_content and child.text:
                    script_content = child.text

                script_info = analyze_script_complexity(script_content, script_type)
                if script_info.complexity in ("MEDIUM", "HIGH"):
                    pattern_info.scripts.append(script_info)
                continue

            if local_name == "flow-ref":
                flow_ref_name = child.get("name", "")
                if flow_ref_name.startswith("#["):
                    pattern_info.scripts.append(ScriptInfo(
                        script_type="dynamic-flow-ref",
                        complexity="HIGH",
                        migration_notes=["Dynamic flow-ref detected - manual review required"],
                    ))

            if is_container_element(child):
                process_element(child)
                continue

            if is_terminal_processor(child):
                components.append(qname)
                _record_batch_component(qname, batch_context)
                continue

            if is_processor_element(child):
                components.append(qname)
                _record_batch_component(qname, batch_context)
                process_element(child)

    process_element(flow_elem)

    batch_info = None
    if batch_context["job_name"]:
        steps = []
        for step_name, step_data in batch_context["steps"].items():
            steps.append(BatchStepInfo(
                name=step_name,
                processors=step_data["processors"],
                aggregator_processors=step_data["aggregator_processors"],
            ))

        total_batch = sum(len(s.processors) + len(s.aggregator_processors) for s in steps)

        migration_notes = []
        for step in steps:
            if any("transform" in p for p in step.processors):
                migration_notes.append(f"Step '{step.name}': ee:transform -> Spring Batch ItemProcessor")
            if any("transform" in p for p in step.aggregator_processors):
                migration_notes.append(f"Step '{step.name}' aggregator: ee:transform -> ItemWriter with aggregation")
            if any("sftp:" in p or "file:" in p for p in step.aggregator_processors):
                migration_notes.append(f"Step '{step.name}' aggregator: file write -> FlatFileItemWriter")
            if any("db:" in p for p in step.processors):
                migration_notes.append(f"Step '{step.name}': db operation -> JdbcBatchItemWriter or ItemProcessor")

        batch_info = BatchInfo(
            job_name=batch_context["job_name"],
            steps=steps,
            total_batch_components=total_batch,
            migration_notes=migration_notes,
        )

    return len(components), components, batch_info, pattern_info


def extract_flows(
    root: ET.Element, source_file: Path, app_path: Path, config_map: Dict[str, Dict[str, str]], thresholds: ComplexityThresholds
) -> Tuple[List[FlowInfo], List[DataWeaveInfo], List[ErrorHandlerInfo], List[Dict[str, str]]]:
    """Extract flows, DataWeave transforms, and error handlers from XML root."""
    flows = []
    dataweave_list = []
    error_handlers = []
    excluded_flows = []

    flow_counter = 0
    dw_counter = 0

    try:
        rel_path = str(source_file.relative_to(app_path))
    except ValueError:
        rel_path = str(source_file)

    transform_line_numbers = find_transform_line_numbers(source_file)
    transform_line_idx = [0]

    all_flow_elements = (
        list(root.findall(".//{*}flow")) +
        list(root.findall(".//{*}sub-flow")) +
        list(root.findall(".//{*}job"))
    )

    for flow_elem in all_flow_elements:
        prefix, local_name = get_element_tag(flow_elem)
        if prefix == "batch" and local_name == "job":
            name = flow_elem.get("jobName") or flow_elem.get("name") or "unnamed"
        else:
            name = flow_elem.get("name", "unnamed")

        if has_apikit_console(flow_elem):
            excluded_flows.append({"name": name, "reason": "Contains apikit:console"})
            continue

        flow_counter += 1
        flow_id = f"FLOW-{flow_counter:03d}"

        if prefix == "batch" and local_name == "job":
            flow_line = find_element_line_number(source_file, name, "batch:job")
        else:
            flow_line = find_element_line_number(source_file, name, local_name)

        source = extract_flow_source(flow_elem, config_map)
        flow_type = determine_flow_type(source, flow_elem)

        component_count, component_list, batch_info, pattern_info = count_components(flow_elem)
        complexity = assign_flow_complexity(component_count, thresholds)

        has_error = flow_elem.find(".//{*}error-handler") is not None
        if not has_error:
            for es in flow_elem.findall(".//{*}exception-strategy"):
                if not es.get("ref"):
                    has_error = True
                    break

        external_count = sum(
            1 for c in component_list
            if any(c.startswith(p) for p in ("http:request", "https:request", "db:", "salesforce:", "sap:"))
        )

        has_patterns = any([
            pattern_info.scatter_gather,
            pattern_info.choices,
            pattern_info.transactions,
            pattern_info.foreach_loops,
            pattern_info.async_scopes,
            pattern_info.retries,
            pattern_info.caches,
            pattern_info.scripts,
        ])

        flow_info = FlowInfo(
            id=flow_id,
            name=name,
            type=flow_type,
            source_file=rel_path,
            line_number=flow_line,
            complexity=complexity,
            component_count=component_count,
            source=source,
            external_calls_count=external_count,
            has_error_handler=has_error,
            components=component_list,
            has_batch=batch_info is not None,
            batch_info=asdict(batch_info) if batch_info else None,
            patterns=asdict(pattern_info) if has_patterns else None,
        )
        flows.append(flow_info)

        transforms = list(flow_elem.findall(".//{*}transform")) + list(flow_elem.findall(".//{*}transform-message"))

        for transform in transforms:
            prefix, _ = get_element_tag(transform)
            if prefix in ("ee", "dw"):
                dw_counter += 1
                dw_id = f"DW-{dw_counter:03d}"

                dw_line = 0
                if transform_line_idx[0] < len(transform_line_numbers):
                    dw_line = transform_line_numbers[transform_line_idx[0]]
                    transform_line_idx[0] += 1

                error_type = None
                for ancestor in flow_elem.iter():
                    for child in ancestor:
                        if child == transform or any(c == transform for c in child.iter()):
                            _, anc_local = get_element_tag(ancestor)
                            if anc_local in ("on-error-propagate", "on-error-continue"):
                                error_type = ancestor.get("type", "")
                            break

                script, external_file = extract_dataweave_script(transform, app_path)
                dw_complexity, classification, has_complex = analyze_dataweave_complexity(script, thresholds)

                doc_name = transform.get(f'{{{NAMESPACES["doc"]}}}name', "")
                if error_type:
                    dw_name = f"{name} {error_type} handler"
                elif doc_name:
                    dw_name = doc_name
                else:
                    dw_name = f"{name} transform"

                script_ref = f"See {rel_path}:{dw_line}"
                line_count = len([l for l in script.split("\n") if l.strip()])

                extracted_structure = extract_dataweave_structure(script)

                dw_info = DataWeaveInfo(
                    id=dw_id,
                    name=dw_name,
                    source_file=rel_path,
                    line_number=dw_line,
                    flow_name=name,
                    complexity=dw_complexity,
                    classification=classification,
                    script_ref=script_ref,
                    line_count=line_count,
                    has_complex_functions=has_complex,
                    error_type=error_type,
                    external_file=external_file,
                    extracted_structure=extracted_structure,
                )
                dataweave_list.append(dw_info)

        if has_error:
            eh_elem = flow_elem.find(".//{*}error-handler")
            if eh_elem is not None:
                handler_count = len(list(eh_elem.findall(".//{*}on-error-propagate"))) + \
                               len(list(eh_elem.findall(".//{*}on-error-continue")))
            else:
                handler_count = len(list(flow_elem.findall(".//{*}catch-exception-strategy")))

            eh_complexity = "LOW"
            if handler_count > 3:
                eh_complexity = "MEDIUM"
            if handler_count > 6:
                eh_complexity = "HIGH"

            error_handlers.append(ErrorHandlerInfo(
                flow_id=flow_id,
                flow_name=name,
                source_file=rel_path,
                line_number=flow_line,
                handler_count=handler_count,
                complexity=eh_complexity,
            ))

    return flows, dataweave_list, error_handlers, excluded_flows


def extract_http_listeners(root: ET.Element, source_file: Path, app_path: Path) -> List[HttpListenerInfo]:
    """Extract HTTP listener configurations."""
    listeners = []

    try:
        rel_path = str(source_file.relative_to(app_path))
    except ValueError:
        rel_path = str(source_file)

    for config in root.findall(".//{*}listener-config"):
        prefix, _ = get_element_tag(config)
        if prefix not in ("http", "https"):
            continue

        config_name = config.get("name", "")
        line_num = find_element_line_number(source_file, config_name, "listener-config")

        host = "0.0.0.0"
        port = "8081"
        base_path = ""
        protocol = "HTTPS" if prefix == "https" else "HTTP"

        for conn in config.findall(".//{*}listener-connection"):
            host = conn.get("host", host)
            port = conn.get("port", port)
            base_path = conn.get("basePath", base_path)
            conn_protocol = conn.get("protocol")
            if conn_protocol:
                protocol = conn_protocol.upper()

        listener_info = HttpListenerInfo(
            id=f"HTTP-{len(listeners)+1:03d}",
            config_name=config_name,
            host=host,
            port=str(port),
            base_path=base_path,
            protocol=protocol,
            source_file=rel_path,
            line_number=line_num,
        )
        listeners.append(listener_info)

    return listeners


def find_scheduled_jobs(root: ET.Element, source_file: Path, app_path: Path) -> List[ScheduledJobInfo]:
    """Find scheduled jobs (scheduler, poll components)."""
    jobs = []

    try:
        rel_path = str(source_file.relative_to(app_path))
    except ValueError:
        rel_path = str(source_file)

    for flow in root.findall(".//{*}flow"):
        flow_name = flow.get("name", "")
        flow_line = find_element_line_number(source_file, flow_name, "flow")

        for scheduler in flow.findall(".//{*}scheduler"):
            job_id = f"SCHED-{len(jobs)+1:03d}"
            cron = None
            fixed_freq = None
            time_unit = None

            for cron_elem in scheduler.findall(".//{*}cron"):
                cron = cron_elem.get("expression")

            for ff_elem in scheduler.findall(".//{*}fixed-frequency"):
                fixed_freq = ff_elem.get("frequency")
                time_unit = ff_elem.get("timeUnit", "MILLISECONDS")

            jobs.append(ScheduledJobInfo(
                id=job_id,
                flow_name=flow_name,
                source_file=rel_path,
                line_number=flow_line,
                cron=cron,
                fixed_frequency=fixed_freq,
                time_unit=time_unit,
            ))

        for poll in flow.findall(".//{*}poll"):
            job_id = f"SCHED-{len(jobs)+1:03d}"
            frequency = poll.get("frequency")

            jobs.append(ScheduledJobInfo(
                id=job_id,
                flow_name=flow_name,
                source_file=rel_path,
                line_number=flow_line,
                fixed_frequency=frequency,
                time_unit="MILLISECONDS",
            ))

    return jobs
