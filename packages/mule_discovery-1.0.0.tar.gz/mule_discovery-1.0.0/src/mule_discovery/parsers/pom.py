"""POM file parsing — connector extraction, app name, Mule version."""

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from xml.etree import ElementTree as ET

import yaml

from mule_discovery.models.connectors import ConnectorInfo, SpringDependency
from mule_discovery.xml_helpers import get_element_tag


def load_migration_config(config_path: Optional[Path] = None) -> Dict[str, Any]:
    """Load migration config for connector mappings."""
    if config_path is None:
        script_dir = Path(__file__).parent.parent
        config_path = script_dir / "data" / "config" / "migration-config.yaml"

    if not config_path.exists():
        return {"connector_mappings": {}}

    try:
        with open(config_path, "r") as f:
            return yaml.safe_load(f)
    except Exception as e:
        print(f"Warning: Could not load config: {e}", file=sys.stderr)
        return {"connector_mappings": {}}


def get_connector_key(mule_connector_name: str) -> str:
    """Map Mule connector name to config key."""
    name = mule_connector_name.lower()
    name = name.replace("mule-", "").replace("-connector", "").replace("module-", "")
    return name


def extract_app_name(app_path: Path) -> str:
    """Extract application name from pom.xml artifactId."""
    pom_file = app_path / "pom.xml"
    if pom_file.exists():
        try:
            tree = ET.parse(pom_file)
            root = tree.getroot()
            for elem in root:
                _, local_name = get_element_tag(elem)
                if local_name == "artifactId" and elem.text:
                    return elem.text.strip()
        except Exception:
            pass
    return app_path.name


def extract_mule_version(app_path: Path) -> str:
    """Extract Mule version from mule-artifact.json or pom.xml."""
    artifact_file = app_path / "mule-artifact.json"
    if artifact_file.exists():
        try:
            with open(artifact_file) as f:
                data = json.load(f)
                return data.get("minMuleVersion", "")
        except Exception:
            pass

    project_file = app_path / "mule-project.xml"
    if project_file.exists():
        try:
            tree = ET.parse(project_file)
            root = tree.getroot()
            runtime_id = root.get("runtimeId", "")
            match = re.search(r"(\d+\.\d+\.\d+)", runtime_id)
            if match:
                return match.group(1)
        except Exception:
            pass

    pom_file = app_path / "pom.xml"
    if pom_file.exists():
        try:
            with open(pom_file) as f:
                content = f.read()
                match = re.search(r"<app\.runtime>([^<]+)</app\.runtime>", content)
                if match:
                    return match.group(1)
                match = re.search(r"<mule\.version>([^<]+)</mule\.version>", content)
                if match:
                    return match.group(1)
        except Exception:
            pass

    return ""


def extract_connectors_from_pom(app_path: Path, config: Dict[str, Any] = None) -> List[ConnectorInfo]:
    """Extract connector dependencies from pom.xml."""
    connectors = {}
    pom_file = app_path / "pom.xml"

    if not pom_file.exists():
        return []

    if config is None:
        config = load_migration_config()

    connector_mappings = config.get("connector_mappings", {})

    try:
        tree = ET.parse(pom_file)
        root = tree.getroot()

        for dep in root.iter():
            _, local_name = get_element_tag(dep)
            if local_name != "dependency":
                continue

            artifact_id = None
            for child in dep:
                _, child_local = get_element_tag(child)
                if child_local == "artifactId":
                    artifact_id = child.text
                    break

            if artifact_id and ("connector" in artifact_id or "module" in artifact_id):
                if artifact_id not in connectors:
                    config_key = get_connector_key(artifact_id)
                    spring_deps = []
                    notes = ""

                    if config_key in connector_mappings:
                        for dep_config in connector_mappings[config_key]:
                            spring_deps.append(SpringDependency(
                                groupId=dep_config.get("groupId", ""),
                                artifactId=dep_config.get("artifactId", ""),
                                version=dep_config.get("version", ""),
                                scope=dep_config.get("scope", ""),
                                type=dep_config.get("type", ""),
                            ))
                    else:
                        notes = "No mapping in config - agent resolution required"

                    connectors[artifact_id] = ConnectorInfo(
                        name=artifact_id,
                        spring_dependencies=spring_deps,
                        usage_count=0,
                        notes=notes,
                    )

    except Exception as e:
        print(f"Warning: Could not parse pom.xml: {e}", file=sys.stderr)

    return list(connectors.values())


def update_connector_usage(connectors: List[ConnectorInfo], flows) -> None:
    """Update connector usage counts based on component usage in flows."""
    prefix_map = {
        "http": "mule-http-connector",
        "https": "mule-https-connector",
        "db": "mule-db-connector",
        "vm": "mule-vm-connector",
        "jms": "mule-jms-connector",
        "amqp": "mule-amqp-connector",
        "file": "mule-file-connector",
        "ftp": "mule-ftp-connector",
        "sftp": "mule-sftp-connector",
        "email": "mule-email-connector",
        "apikit": "mule-apikit-module",
        "salesforce": "mule-salesforce-connector",
        "sap": "mule-sap-connector",
    }

    connector_counts = {c.name: 0 for c in connectors}

    for flow in flows:
        for comp in flow.components:
            if ":" in comp:
                prefix = comp.split(":")[0]
                connector_name = prefix_map.get(prefix)
                if connector_name and connector_name in connector_counts:
                    connector_counts[connector_name] += 1

    for connector in connectors:
        connector.usage_count = connector_counts.get(connector.name, 0)
