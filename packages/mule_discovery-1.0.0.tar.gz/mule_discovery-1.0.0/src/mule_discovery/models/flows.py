"""Flow, source, and pattern data models."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class BatchStepInfo:
    """Information about a batch step for Spring Batch migration."""
    name: str
    processors: List[str] = field(default_factory=list)
    aggregator_processors: List[str] = field(default_factory=list)


@dataclass
class BatchInfo:
    """Batch job information for Spring Batch migration mapping."""
    job_name: str
    steps: List[BatchStepInfo] = field(default_factory=list)
    total_batch_components: int = 0
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class ScatterGatherRoute:
    """Single route in scatter-gather."""
    processors: List[str] = field(default_factory=list)


@dataclass
class ScatterGatherInfo:
    """Parallel execution pattern for CompletableFuture/Mono.zip mapping."""
    route_count: int = 0
    routes: List[ScatterGatherRoute] = field(default_factory=list)
    timeout: Optional[str] = None
    max_concurrency: Optional[str] = None
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class ChoiceBranch:
    """Single branch in a choice router."""
    condition: Optional[str]
    is_otherwise: bool = False
    processors: List[str] = field(default_factory=list)
    has_async_publish: bool = False


@dataclass
class ChoiceInfo:
    """Choice router with conditions for if/else or switch mapping."""
    branches: List[ChoiceBranch] = field(default_factory=list)
    has_otherwise: bool = False
    pattern_type: str = "sync_router"
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class TransactionInfo:
    """Transaction boundary for @Transactional mapping."""
    action: str = ""
    tx_type: str = ""
    components: List[str] = field(default_factory=list)
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class ForeachInfo:
    """Iteration pattern for Stream/loop mapping."""
    collection_expression: Optional[str] = None
    batch_size: Optional[int] = None
    root_message_var: Optional[str] = None
    processors: List[str] = field(default_factory=list)
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class AsyncInfo:
    """Async execution for @Async mapping."""
    max_concurrency: Optional[str] = None
    processors: List[str] = field(default_factory=list)
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class UntilSuccessfulInfo:
    """Retry pattern for @Retryable mapping."""
    max_retries: Optional[str] = None
    interval_ms: Optional[str] = None
    failure_expression: Optional[str] = None
    processors: List[str] = field(default_factory=list)
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class CacheInfo:
    """Cache scope for @Cacheable mapping."""
    caching_strategy_ref: Optional[str] = None
    key_expression: Optional[str] = None
    filter_expression: Optional[str] = None
    processors: List[str] = field(default_factory=list)
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class ScriptInfo:
    """Script/MEL complexity for migration effort estimation."""
    script_type: str = ""
    line_count: int = 0
    has_control_flow: bool = False
    complexity: str = "LOW"
    migration_notes: List[str] = field(default_factory=list)


@dataclass
class PatternInfo:
    """All detected patterns in a flow for migration mapping."""
    scatter_gather: List[ScatterGatherInfo] = field(default_factory=list)
    choices: List[ChoiceInfo] = field(default_factory=list)
    transactions: List[TransactionInfo] = field(default_factory=list)
    foreach_loops: List[ForeachInfo] = field(default_factory=list)
    async_scopes: List[AsyncInfo] = field(default_factory=list)
    retries: List[UntilSuccessfulInfo] = field(default_factory=list)
    caches: List[CacheInfo] = field(default_factory=list)
    scripts: List[ScriptInfo] = field(default_factory=list)


@dataclass
class SourceInfo:
    """Information about a flow's trigger/source element."""
    type: str
    category: str = ""
    config_ref: Optional[str] = None
    path: Optional[str] = None
    method: Optional[str] = None
    protocol: Optional[str] = None
    queue: Optional[str] = None
    destination: Optional[str] = None
    cron: Optional[str] = None
    fixed_frequency: Optional[str] = None
    time_unit: Optional[str] = None

    def __post_init__(self):
        if not self.category:
            self.category = _get_source_category(self.type, self.protocol)


@dataclass
class SourceSummary:
    """Aggregate counts of source types across all flows."""
    http_listener: int = 0
    https_listener: int = 0
    vm_listener: int = 0
    jms_listener: int = 0
    amqp_listener: int = 0
    file_listener: int = 0
    ftp_listener: int = 0
    sftp_listener: int = 0
    scheduler: int = 0
    poll: int = 0
    none: int = 0


@dataclass
class FlowInfo:
    id: str
    name: str
    type: str
    source_file: str
    line_number: int = 0
    complexity: str = "LOW"
    component_count: int = 0
    source: Optional[SourceInfo] = None
    external_calls_count: int = 0
    has_error_handler: bool = False
    components: List[str] = field(default_factory=list)
    has_batch: bool = False
    batch_info: Optional[Dict[str, Any]] = None
    patterns: Optional[Dict[str, Any]] = None


@dataclass
class ErrorHandlerInfo:
    flow_id: str
    flow_name: str
    source_file: str = ""
    line_number: int = 0
    handler_count: int = 0
    complexity: str = "LOW"


def _get_source_category(source_type: str, protocol: Optional[str] = None) -> str:
    """Map detailed source type to simplified category."""
    if not source_type or source_type == "none":
        return "none"

    prefix = source_type.split(":")[0] if ":" in source_type else source_type

    if prefix == "http" and protocol and protocol.upper() == "HTTPS":
        return "https"

    category_map = {
        "http": "http",
        "https": "https",
        "vm": "vm",
        "jms": "jms",
        "amqp": "amqp",
        "file": "file",
        "ftp": "ftp",
        "sftp": "sftp",
        "scheduler": "scheduler",
        "poll": "scheduler",
        "quartz": "scheduler",
    }

    return category_map.get(prefix, "none")
