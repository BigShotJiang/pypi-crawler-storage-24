"""HTTP listener and scheduled job data models."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class HttpListenerInfo:
    id: str
    config_name: str
    host: str
    port: str
    base_path: str
    protocol: str = "HTTP"
    source_file: str = ""
    line_number: int = 0
    endpoints: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ScheduledJobInfo:
    id: str
    flow_name: str
    source_file: str = ""
    line_number: int = 0
    cron: Optional[str] = None
    fixed_frequency: Optional[str] = None
    time_unit: Optional[str] = None
