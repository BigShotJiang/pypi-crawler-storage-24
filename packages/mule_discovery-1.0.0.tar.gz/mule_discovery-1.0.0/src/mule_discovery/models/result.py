"""Top-level discovery result model."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from mule_discovery.models.connectors import ConnectorInfo
from mule_discovery.models.dataweave import DataWeaveInfo
from mule_discovery.models.dependencies import (
    ExternalDependencyInfo,
    OutOfScopeItem,
    SourceFiles,
)
from mule_discovery.models.flows import (
    ErrorHandlerInfo,
    FlowInfo,
    SourceSummary,
)
from mule_discovery.models.listeners import HttpListenerInfo, ScheduledJobInfo
from mule_discovery.models.schemas import ApiSpecInfo
from mule_discovery.models.scoring import ScoreResult


@dataclass
class DiscoveryResult:
    schema_version: str = "4.0.0"
    created_at: str = ""
    app_name: str = ""
    mule_version: str = ""

    warnings: List[str] = field(default_factory=list)
    flows: List[FlowInfo] = field(default_factory=list)
    dataweave_transformations: List[DataWeaveInfo] = field(default_factory=list)
    http_listeners: List[HttpListenerInfo] = field(default_factory=list)
    connectors: List[ConnectorInfo] = field(default_factory=list)
    error_handling: List[ErrorHandlerInfo] = field(default_factory=list)

    api_specification: Optional[ApiSpecInfo] = None
    supporting_specifications: List[ApiSpecInfo] = field(default_factory=list)

    scheduled_jobs: List[ScheduledJobInfo] = field(default_factory=list)
    external_dependencies: List[Dict[str, Any]] = field(default_factory=list)

    soap_services: List[Dict[str, Any]] = field(default_factory=list)
    aws_services: Dict[str, List[Dict[str, Any]]] = field(default_factory=lambda: {"sqs": [], "s3": [], "dynamodb": []})
    validations: List[Dict[str, Any]] = field(default_factory=list)

    source_files: SourceFiles = field(default_factory=SourceFiles)
    out_of_scope: List[OutOfScopeItem] = field(default_factory=list)
    excluded_flows: List[Dict[str, str]] = field(default_factory=list)

    source_summary: Optional[SourceSummary] = None
    score_result: Optional[ScoreResult] = None
    summary: Dict[str, Any] = field(default_factory=dict)
