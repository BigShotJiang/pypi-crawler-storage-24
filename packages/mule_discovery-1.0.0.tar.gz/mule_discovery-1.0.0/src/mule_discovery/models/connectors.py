"""Connector data models."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class SpringDependency:
    groupId: str
    artifactId: str
    version: str = ""
    scope: str = ""
    type: str = ""


@dataclass
class ConnectorInfo:
    name: str
    spring_dependencies: List[SpringDependency] = field(default_factory=list)
    source_file: str = "pom.xml"
    usage_count: int = 0
    notes: str = ""
