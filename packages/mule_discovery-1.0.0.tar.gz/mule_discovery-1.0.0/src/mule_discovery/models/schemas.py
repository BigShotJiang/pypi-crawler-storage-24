"""API specification data models."""

from dataclasses import dataclass


@dataclass
class ApiSpecInfo:
    type: str
    source_file: str
    version: str = ""
    endpoint_count: int = 0
    requires_conversion: bool = False
