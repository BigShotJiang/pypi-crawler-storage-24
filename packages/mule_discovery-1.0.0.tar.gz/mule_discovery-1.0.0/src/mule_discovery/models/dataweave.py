"""DataWeave data models."""

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class DataWeaveInfo:
    id: str
    name: str
    source_file: str
    line_number: int = 0
    flow_name: str = ""
    complexity: str = "LOW"
    classification: str = "simple_mapping"
    script_ref: str = ""
    line_count: int = 0
    has_complex_functions: bool = False
    error_type: Optional[str] = None
    external_file: Optional[str] = None
    extracted_structure: Dict[str, Any] = field(default_factory=dict)
