"""Scoring and complexity threshold models."""

from dataclasses import dataclass, field
from typing import Dict, Tuple


@dataclass
class ComplexityThresholds:
    """Configurable thresholds for complexity assignment."""
    flow_low_max: int = 6
    flow_medium_max: int = 14
    flow_high_max: int = 25

    dw_low_max_lines: int = 5
    dw_medium_max_lines: int = 20

    dw_routine_functions: Tuple[str, ...] = (
        "map", "filter", "pluck", "orderBy", "distinctBy",
    )
    dw_complex_functions: Tuple[str, ...] = (
        "reduce", "groupBy", "flatMap", "mapObject", "minBy", "maxBy",
    )

    score_max_flow_deduction: int = 30
    score_max_transform_deduction: int = 15
    score_max_risk_deduction: int = 20
    score_max_connector_deduction: int = 20
    score_max_wsdl_deduction: int = 10
    score_max_scale_deduction: int = 20
    score_max_pattern_deduction: int = 15
    score_max_dw_volume_deduction: int = 15


@dataclass
class ScoreResult:
    score: int
    recommendation: str
    high_risks: int
    medium_risks: int
    deductions: Dict[str, int] = field(default_factory=dict)
