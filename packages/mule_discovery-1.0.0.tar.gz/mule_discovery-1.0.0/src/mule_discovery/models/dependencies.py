"""Dependency and source file data models."""

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class ExternalDependencyInfo:
    id: str
    name: str
    type: str
    source_file: str
    line_number: int = 0
    connection: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SourceFiles:
    mule_configs: List[str] = field(default_factory=list)
    properties: List[str] = field(default_factory=list)
    api_specs: List[str] = field(default_factory=list)
    dataweave: List[str] = field(default_factory=list)
    java: List[str] = field(default_factory=list)
    resources: List[str] = field(default_factory=list)


@dataclass
class OutOfScopeItem:
    name: str
    type: str
    source_file: str
    reason: str
    recommendation: str
