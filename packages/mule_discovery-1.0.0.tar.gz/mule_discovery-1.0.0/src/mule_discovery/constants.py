"""Namespace constants, element classification sets, connector migration weights."""

from typing import Tuple


# Mule XML namespaces
NAMESPACES = {
    "mule": "http://www.mulesoft.org/schema/mule/core",
    "http": "http://www.mulesoft.org/schema/mule/http",
    "https": "http://www.mulesoft.org/schema/mule/https",
    "db": "http://www.mulesoft.org/schema/mule/db",
    "ee": "http://www.mulesoft.org/schema/mule/ee/core",
    "dw": "http://www.mulesoft.org/schema/mule/ee/dw",
    "vm": "http://www.mulesoft.org/schema/mule/vm",
    "jms": "http://www.mulesoft.org/schema/mule/jms",
    "amqp": "http://www.mulesoft.org/schema/mule/amqp",
    "file": "http://www.mulesoft.org/schema/mule/file",
    "ftp": "http://www.mulesoft.org/schema/mule/ftp",
    "sftp": "http://www.mulesoft.org/schema/mule/sftp",
    "email": "http://www.mulesoft.org/schema/mule/email",
    "apikit": "http://www.mulesoft.org/schema/mule/apikit",
    "apikit4": "http://www.mulesoft.org/schema/mule/mule-apikit",
    "sockets": "http://www.mulesoft.org/schema/mule/sockets",
    "oauth": "http://www.mulesoft.org/schema/mule/oauth",
    "salesforce": "http://www.mulesoft.org/schema/mule/salesforce",
    "sap": "http://www.mulesoft.org/schema/mule/sap",
    "objectstore": "http://www.mulesoft.org/schema/mule/os",
    "batch": "http://www.mulesoft.org/schema/mule/batch",
    "validation": "http://www.mulesoft.org/schema/mule/validation",
    "scripting": "http://www.mulesoft.org/schema/mule/scripting",
    "java": "http://www.mulesoft.org/schema/mule/java",
    "doc": "http://www.mulesoft.org/schema/mule/documentation",
    "api-platform-gw": "http://www.mulesoft.org/schema/mule/api-platform-gw",
    "quartz": "http://www.mulesoft.org/schema/mule/quartz",
    "ee-cache": "http://www.mulesoft.org/schema/mule/ee/cache",
    "ws": "http://www.mulesoft.org/schema/mule/ws",
    "anypoint-mq": "http://www.mulesoft.org/schema/mule/anypoint-mq",
    "mq": "http://www.mulesoft.org/schema/mule/anypoint-mq",
    "sqs": "http://www.mulesoft.org/schema/mule/sqs",
    "s3": "http://www.mulesoft.org/schema/mule/s3",
    "dynamodb": "http://www.mulesoft.org/schema/mule/dynamodb",
    "wsc": "http://www.mulesoft.org/schema/mule/wsc",
    "apikit-soap": "http://www.mulesoft.org/schema/mule/apikit-soap",
}

NS_TO_PREFIX = {v: k for k, v in NAMESPACES.items()}

# WSDL/SOAP namespaces for parse_wsdl()
WSDL_NS = "http://schemas.xmlsoap.org/wsdl/"
SOAP11_NS = "http://schemas.xmlsoap.org/wsdl/soap/"
SOAP12_NS = "http://schemas.xmlsoap.org/wsdl/soap12/"
XS_NS = "http://www.w3.org/2001/XMLSchema"

# Connector migration complexity weights
CONNECTOR_MIGRATION_WEIGHTS = {
    "wsc": "high", "ws": "high", "sap": "high", "ldap": "high",
    "apikit-soap": "high",
    "db": "medium", "jms": "medium", "amqp": "medium",
    "anypoint-mq": "medium", "sqs": "medium", "mq": "medium",
    "http": "low", "https": "low", "vm": "low",
    "file": "low", "ftp": "low", "sftp": "low",
    "email": "low", "salesforce": "low",
    "s3": "low", "dynamodb": "medium",
}

# SOURCE/TRIGGER ELEMENTS - NOT counted as components
SOURCE_ELEMENTS = {
    "http:listener", "https:listener", "vm:listener", "jms:listener",
    "amqp:listener", "file:listener", "ftp:listener", "sftp:listener",
    "email:listener", "email:listener-imap", "email:listener-pop3",
    "sockets:listener", "scheduler",
    "http:inbound-endpoint", "https:inbound-endpoint", "vm:inbound-endpoint",
    "jms:inbound-endpoint", "amqp:inbound-endpoint", "file:inbound-endpoint",
    "ftp:inbound-endpoint", "sftp:inbound-endpoint", "quartz:inbound-endpoint",
    "poll",
    "listener", "inbound-endpoint",
}

# CONTAINER ELEMENTS - recurse into but don't count the container itself
CONTAINER_ELEMENTS = {
    "error-handler", "on-error-propagate", "on-error-continue",
    "catch-exception-strategy", "choice-exception-strategy", "rollback-exception-strategy",
    "when", "otherwise",
    "route",
    "parallel-foreach",
    "batch:job", "batch:process-records", "batch:step", "batch:aggregator",
    "mule", "flow", "sub-flow",
    "ee:cache", "ee-cache:cache-scope",
}

# REFERENCE ELEMENTS - not processors
REFERENCE_ELEMENTS = {
    "exception-strategy",
}

# CONFIGURATION ELEMENTS - not processors
CONFIG_ELEMENTS = {
    "configuration", "global-property",
    "http:listener-config", "http:request-config",
    "https:listener-config", "https:request-config",
    "db:config", "db:generic-config", "db:mysql-config", "db:oracle-config",
    "db:mssql-config", "db:derby-config", "db:data-source-connection",
    "vm:config", "jms:config", "jms:active-mq-connection",
    "amqp:config", "amqp:connection",
    "file:config", "file:connection", "ftp:config", "sftp:config",
    "email:smtp-config", "email:imap-config", "email:pop3-config",
    "apikit:config", "sockets:listener-config", "sockets:request-config",
    "oauth:config", "salesforce:config", "salesforce:basic-connection",
    "salesforce:oauth-user-pass-connection", "sap:config",
    "objectstore:config", "os:config", "os:object-store",
    "validation:config", "scripting:config", "java:config",
    "spring:beans", "spring:bean", "context:property-placeholder",
    "secure-property-placeholder:config", "tls:context", "tls:trust-store", "tls:key-store",
    "api-platform-gw:api", "ee:cache-config", "ee-cache:caching-strategy",
}

# TERMINAL PROCESSOR ELEMENTS - count as 1, do NOT recurse
TERMINAL_PROCESSOR_ELEMENTS = {
    "ee:transform", "dw:transform-message", "transform-message", "transform",
}

# PATTERN ELEMENTS - counted AND tracked for pattern info
PATTERN_ELEMENTS = {
    "scatter-gather",
    "choice",
    "try",
    "foreach", "for-each",
    "until-successful",
    "async",
}

# PROCESSOR ELEMENTS - active message processors that ARE counted
PROCESSOR_ELEMENTS = {
    "logger", "set-payload", "set-variable", "remove-variable",
    "set-property", "remove-property", "copy-properties",
    "flow-ref", "choice", "scatter-gather", "foreach", "for-each",
    "until-successful", "first-successful", "round-robin",
    "async", "try", "raise-error", "parse-template",
    "expression-component", "expression-transformer",
    "object-to-string-transformer", "object-to-byte-array-transformer",
    "byte-array-to-string-transformer", "byte-array-to-object-transformer",
    "json-to-object-transformer", "object-to-json-transformer",
    "xml-to-object-transformer", "object-to-xml-transformer",
    "message-properties-transformer", "base64-encoder-transformer",
    "base64-decoder-transformer", "gzip-compress-transformer",
    "gzip-uncompress-transformer",
    "enricher", "collection-splitter", "collection-aggregator",
    "message-filter", "idempotent-message-filter", "expression-filter",
    "invoke", "transactional",
    "ee:transform", "dw:transform-message", "transform-message",
    "http:request", "https:request", "http:outbound-endpoint", "https:outbound-endpoint",
    "vm:publish", "vm:consume", "vm:publish-consume", "vm:outbound-endpoint",
    "jms:publish", "jms:consume", "jms:publish-consume", "jms:outbound-endpoint",
    "amqp:publish", "amqp:consume", "amqp:outbound-endpoint",
    "db:select", "db:insert", "db:update", "db:delete", "db:stored-procedure",
    "db:bulk-insert", "db:bulk-update", "db:bulk-delete",
    "db:execute-script", "db:execute-ddl",
    "file:read", "file:write", "file:list", "file:copy", "file:move",
    "file:delete", "file:outbound-endpoint",
    "ftp:read", "ftp:write", "ftp:list", "ftp:outbound-endpoint",
    "sftp:read", "sftp:write", "sftp:list", "sftp:outbound-endpoint",
    "email:send", "email:list-imap", "email:list-pop3",
    "apikit:router", "apikit:console", "apikit4:router", "apikit4:console",
    "os:store", "os:retrieve", "os:contains", "os:remove",
    "salesforce:query", "salesforce:create", "salesforce:update",
    "salesforce:delete", "salesforce:upsert",
    "sap:execute-bapi", "sap:execute-synchronous-rfc",
    "validation:is-not-null", "validation:is-null", "validation:is-true",
    "validation:is-false", "validation:is-not-empty", "validation:is-email",
    "validation:matches-regex", "validation:validate-size", "validation:all",
    "scripting:execute",
    "java:invoke", "java:invoke-static", "java:new",
    "ws:consume",
    "anypoint-mq:publish", "anypoint-mq:consume",
    "sqs:send-message", "sqs:receive-messages",
    "ee:cache", "ee-cache:cache-scope",
}

# Async processor elements for choice pattern classification
ASYNC_PROCESSORS = {
    "vm:publish", "jms:publish", "amqp:publish", "kafka:publish",
    "anypoint-mq:publish", "vm:outbound-endpoint", "jms:outbound-endpoint",
}
