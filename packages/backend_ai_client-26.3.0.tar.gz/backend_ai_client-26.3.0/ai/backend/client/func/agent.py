from __future__ import annotations

from collections.abc import Sequence
from typing import Any, cast

from ai.backend.client.output.fields import agent_fields
from ai.backend.client.output.types import FieldSpec, PaginatedResult
from ai.backend.client.pagination import fetch_paginated_result
from ai.backend.client.request import Request
from ai.backend.client.session import api_session
from ai.backend.client.utils import dedent as _d

from .base import BaseFunction, api_function

__all__ = (
    "Agent",
    "AgentWatcher",
)

_default_list_fields = (
    agent_fields["id"],
    agent_fields["status"],
    agent_fields["scaling_group"],
    agent_fields["available_slots"],
    agent_fields["occupied_slots"],
)

_default_detail_fields = (
    agent_fields["id"],
    agent_fields["status"],
    agent_fields["scaling_group"],
    agent_fields["addr"],
    agent_fields["region"],
    agent_fields["first_contact"],
    agent_fields["cpu_cur_pct"],
    agent_fields["mem_cur_bytes"],
    agent_fields["available_slots"],
    agent_fields["occupied_slots"],
    agent_fields["local_config"],
)


class Agent(BaseFunction):
    """
    Provides a shortcut of :func:`Admin.query()
    <ai.backend.client.admin.Admin.query>` that fetches various agent
    information.

    .. note::

      All methods in this function class require your API access key to
      have the *admin* privilege.
    """

    @api_function
    @classmethod
    async def paginated_list(
        cls,
        status: str = "ALIVE",
        scaling_group: str | None = None,
        *,
        fields: Sequence[FieldSpec] = _default_list_fields,
        page_offset: int = 0,
        page_size: int = 20,
        filter: str | None = None,
        order: str | None = None,
    ) -> PaginatedResult[Any]:
        """
        Lists the keypairs.
        You need an admin privilege for this operation.
        """
        return await fetch_paginated_result(
            "agent_list",
            {
                "status": (status, "String"),
                "scaling_group": (scaling_group, "String"),
                "filter": (filter, "String"),
                "order": (order, "String"),
            },
            fields,
            page_size=page_size,
            page_offset=page_offset,
        )

    @api_function
    @classmethod
    async def detail(
        cls,
        agent_id: str,
        fields: Sequence[FieldSpec] = _default_detail_fields,
    ) -> Sequence[dict[str, Any]]:
        query = _d("""
            query($agent_id: String!) {
                agent(agent_id: $agent_id) {$fields}
            }
        """)
        query = query.replace("$fields", " ".join(f.field_ref for f in fields))
        variables = {"agent_id": agent_id}
        data = await api_session.get().Admin._query(query, variables)
        return cast(Sequence[dict[str, Any]], data["agent"])


class AgentWatcher(BaseFunction):
    """
    Provides a shortcut of :func:`Admin.query()
    <ai.backend.client.admin.Admin.query>` that manipulate agent status.

    .. note::

      All methods in this function class require you to
      have the *superadmin* privilege.
    """

    @api_function
    @classmethod
    async def get_status(cls, agent_id: str) -> dict[str, Any]:
        """
        Get agent and watcher status.
        """
        rqst = Request("GET", "/resource/watcher", params={"agent_id": agent_id})
        async with rqst.fetch() as resp:
            data = await resp.json()
            if "message" in data:
                return cast(dict[str, Any], data["message"])
            return cast(dict[str, Any], data)

    @api_function
    @classmethod
    async def agent_start(cls, agent_id: str) -> dict[str, Any]:
        """
        Start agent.
        """
        rqst = Request("POST", "/resource/watcher/agent/start")
        rqst.set_json({"agent_id": agent_id})
        async with rqst.fetch() as resp:
            data = await resp.json()
            if "message" in data:
                return cast(dict[str, Any], data["message"])
            return cast(dict[str, Any], data)

    @api_function
    @classmethod
    async def agent_stop(cls, agent_id: str) -> dict[str, Any]:
        """
        Stop agent.
        """
        rqst = Request("POST", "/resource/watcher/agent/stop")
        rqst.set_json({"agent_id": agent_id})
        async with rqst.fetch() as resp:
            data = await resp.json()
            if "message" in data:
                return cast(dict[str, Any], data["message"])
            return cast(dict[str, Any], data)

    @api_function
    @classmethod
    async def agent_restart(cls, agent_id: str) -> dict[str, Any]:
        """
        Restart agent.
        """
        rqst = Request("POST", "/resource/watcher/agent/restart")
        rqst.set_json({"agent_id": agent_id})
        async with rqst.fetch() as resp:
            data = await resp.json()
            if "message" in data:
                return cast(dict[str, Any], data["message"])
            return cast(dict[str, Any], data)
