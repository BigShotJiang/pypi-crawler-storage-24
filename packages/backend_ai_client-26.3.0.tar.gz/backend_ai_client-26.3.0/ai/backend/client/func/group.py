from __future__ import annotations

import textwrap
from collections.abc import Iterable, Sequence
from typing import Any, cast

from ai.backend.cli.types import Undefined, undefined
from ai.backend.client.output.fields import group_fields
from ai.backend.client.output.types import FieldSpec
from ai.backend.client.session import api_session
from ai.backend.client.types import set_if_set
from ai.backend.client.utils import dedent as _d
from ai.backend.common.utils import b64encode

from .base import BaseFunction, api_function, resolve_fields

__all__ = ("Group",)

_default_list_fields = (
    group_fields["id"],
    group_fields["name"],
    group_fields["is_active"],
    group_fields["created_at"],
    group_fields["integration_id"],
)
_default_detail_fields = (
    group_fields["id"],
    group_fields["name"],
    group_fields["description"],
    group_fields["is_active"],
    group_fields["created_at"],
    group_fields["domain_name"],
    group_fields["total_resource_slots"],
    group_fields["allowed_vfolder_hosts"],
    group_fields["integration_id"],
)


class Group(BaseFunction):
    """
    Provides a shortcut of :func:`Group.query()
    <ai.backend.client.admin.Admin.query>` that fetches various group information.

    .. note::

      All methods in this function class require your API access key to
      have the *admin* privilege.
    """

    @api_function
    @classmethod
    async def from_name(
        cls,
        name: str,
        *,
        fields: Iterable[FieldSpec | str] | None = None,
        domain_name: str | None = None,
    ) -> Sequence[dict[str, Any]]:
        """
        Find the group(s) by its name.
        It may return multiple groups when there are groups with the same name
        in different domains and it is invoked with a super-admin account
        without setting the domain name.

        :param domain_name: Name of domain to get groups from.
        :param fields: Per-group query fields to fetch.
        """
        query = _d("""
            query($name: String!, $domain_name: String) {
                groups_by_name(name: $name, domain_name: $domain_name) {$fields}
            }
        """)
        resolved_fields = resolve_fields(fields, group_fields, _default_detail_fields)
        query = query.replace("$fields", " ".join(resolved_fields))
        variables = {
            "name": name,
            "domain_name": domain_name,
        }
        data = await api_session.get().Admin._query(query, variables)
        return cast(Sequence[dict[str, Any]], data["groups_by_name"])

    @api_function
    @classmethod
    async def list(
        cls,
        domain_name: str,
        fields: Sequence[FieldSpec] = _default_list_fields,
    ) -> Sequence[dict[str, Any]]:
        """
        Fetches the list of groups.

        :param domain_name: Name of domain to list groups.
        :param fields: Per-group query fields to fetch.
        """
        query = _d("""
            query($domain_name: String) {
                groups(domain_name: $domain_name) {$fields}
            }
        """)
        query = query.replace("$fields", " ".join(f.field_ref for f in fields))
        variables = {"domain_name": domain_name}
        data = await api_session.get().Admin._query(query, variables)
        return cast(Sequence[dict[str, Any]], data["groups"])

    @api_function
    @classmethod
    async def detail(
        cls,
        gid: str,
        fields: Sequence[FieldSpec] = _default_detail_fields,
    ) -> dict[str, Any]:
        """
        Fetch information of a group with group ID.

        :param gid: ID of the group to fetch.
        :param fields: Additional per-group query fields to fetch.
        """
        query = _d("""
            query($gid: UUID!) {
                group(id: $gid) {$fields}
            }
        """)
        query = query.replace("$fields", " ".join(f.field_ref for f in fields))
        variables = {"gid": gid}
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["group"])

    @api_function
    @classmethod
    async def create(
        cls,
        domain_name: str,
        name: str,
        *,
        description: str = "",
        is_active: bool = True,
        total_resource_slots: str | None = None,
        allowed_vfolder_hosts: str | None = None,
        integration_id: str | None = None,
        _fields: Iterable[FieldSpec | str] | None = None,
    ) -> dict[str, Any]:
        """
        Creates a new group with the given options.
        You need an admin privilege for this operation.
        """
        query = _d("""
            mutation($name: String!, $input: GroupInput!) {
                create_group(name: $name, props: $input) {
                    ok msg group {$fields}
                }
            }
        """)
        resolved_fields = resolve_fields(
            _fields,
            group_fields,
            (group_fields["id"], group_fields["domain_name"], group_fields["name"]),
        )
        query = query.replace("$fields", " ".join(resolved_fields))
        inputs = {
            "description": description,
            "is_active": is_active,
            "domain_name": domain_name,
            "total_resource_slots": total_resource_slots,
            "allowed_vfolder_hosts": allowed_vfolder_hosts,
            "integration_id": integration_id,
        }
        variables = {
            "name": name,
            "input": {k: v for k, v in inputs.items() if v is not None},
        }
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["create_group"])

    @api_function
    @classmethod
    async def update(
        cls,
        gid: str,
        *,
        name: str | Undefined = undefined,
        description: str | Undefined = undefined,
        is_active: bool | Undefined = undefined,
        total_resource_slots: str | None | Undefined = undefined,
        allowed_vfolder_hosts: str | None | Undefined = undefined,
        integration_id: str | Undefined = undefined,
        _fields: Iterable[FieldSpec | str] | None = None,
    ) -> dict[str, Any]:
        """
        Update existing group.
        You need an admin privilege for this operation.
        """
        query = _d("""
            mutation($gid: UUID!, $input: ModifyGroupInput!) {
                modify_group(gid: $gid, props: $input) {
                    ok msg
                }
            }
        """)
        inputs: dict[str, Any] = {}
        set_if_set(inputs, "name", name)
        set_if_set(inputs, "description", description)
        set_if_set(inputs, "is_active", is_active)
        set_if_set(inputs, "total_resource_slots", total_resource_slots)
        set_if_set(inputs, "allowed_vfolder_hosts", allowed_vfolder_hosts)
        set_if_set(inputs, "integration_id", integration_id)
        variables = {
            "gid": gid,
            "input": inputs,
        }
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["modify_group"])

    @api_function
    @classmethod
    async def delete(cls, gid: str) -> dict[str, Any]:
        """
        Inactivates the existing group. Does not actually delete it for safety.
        """
        query = _d("""
            mutation($gid: UUID!) {
                delete_group(gid: $gid) {
                    ok msg
                }
            }
        """)
        variables = {"gid": gid}
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["delete_group"])

    @api_function
    @classmethod
    async def purge(cls, gid: str) -> dict[str, Any]:
        """
        Delete the existing group. This action cannot be undone.
        """
        query = _d("""
            mutation($gid: UUID!) {
                purge_group(gid: $gid) {
                    ok msg
                }
            }
        """)
        variables = {"gid": gid}
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["purge_group"])

    @api_function
    @classmethod
    async def add_users(
        cls,
        gid: str,
        user_uuids: Iterable[str],
        _fields: Iterable[FieldSpec | str] | None = None,
    ) -> dict[str, Any]:
        """
        Add users to a group.
        You need an admin privilege for this operation.
        """
        query = _d("""
            mutation($gid: UUID!, $input: ModifyGroupInput!) {
                modify_group(gid: $gid, props: $input) {
                    ok msg
                }
            }
        """)
        variables = {
            "gid": gid,
            "input": {
                "user_update_mode": "add",
                "user_uuids": user_uuids,
            },
        }
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["modify_group"])

    @api_function
    @classmethod
    async def remove_users(
        cls,
        gid: str,
        user_uuids: Iterable[str],
        _fields: Iterable[FieldSpec | str] | None = None,
    ) -> dict[str, Any]:
        """
        Remove users from a group.
        You need an admin privilege for this operation.
        """
        query = _d("""
            mutation($gid: UUID!, $input: ModifyGroupInput!) {
                modify_group(gid: $gid, props: $input) {
                    ok msg
                }
            }
        """)
        variables = {
            "gid": gid,
            "input": {
                "user_update_mode": "remove",
                "user_uuids": user_uuids,
            },
        }
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["modify_group"])

    @api_function
    @classmethod
    async def get_container_registry_quota(cls, group_id: str) -> int:
        """
        Get Quota Limit for the group's container registry.
        Currently only HarborV2 registry is supported.

        You need an admin privilege for this operation.
        """
        query = textwrap.dedent(
            """\
            query($id: String!) {
                group_node(id: $id) {
                    registry_quota
                }
            }
        """
        )

        variables = {"id": b64encode(f"group_node:{group_id}")}
        data = await api_session.get().Admin._query(query, variables)
        return cast(int, data["group_node"]["registry_quota"])

    @api_function
    @classmethod
    async def create_container_registry_quota(cls, group_id: str, quota: int) -> dict[str, Any]:
        """
        Create Quota Limit for the group's container registry.
        Currently only HarborV2 registry is supported.

        You need an admin privilege for this operation.
        """
        query = textwrap.dedent(
            """\
            mutation($scope_id: ScopeField!, $quota: Int!) {
                create_container_registry_quota(
                        scope_id: $scope_id, quota: $quota) {
                    ok msg
                }
            }
        """
        )

        scope_id = f"project:{group_id}"
        variables = {"scope_id": scope_id, "quota": quota}
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["create_container_registry_quota"])

    @api_function
    @classmethod
    async def update_container_registry_quota(cls, group_id: str, quota: int) -> dict[str, Any]:
        """
        Update Quota Limit for the group's container registry.
        Currently only HarborV2 registry is supported.

        You need an admin privilege for this operation.
        """
        query = textwrap.dedent(
            """\
            mutation($scope_id: ScopeField!, $quota: Int!) {
                update_container_registry_quota(
                        scope_id: $scope_id, quota: $quota) {
                    ok msg
                }
            }
        """
        )

        scope_id = f"project:{group_id}"
        variables = {"scope_id": scope_id, "quota": quota}
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["update_container_registry_quota"])

    @api_function
    @classmethod
    async def delete_container_registry_quota(cls, group_id: str) -> dict[str, Any]:
        """
        Delete Quota Limit for the group's container registry.
        Currently only HarborV2 registry is supported.

        You need an admin privilege for this operation.
        """
        query = textwrap.dedent(
            """\
            mutation($scope_id: ScopeField!) {
                delete_container_registry_quota(
                        scope_id: $scope_id) {
                    ok msg
                }
            }
        """
        )

        scope_id = f"project:{group_id}"
        variables = {"scope_id": scope_id}
        data = await api_session.get().Admin._query(query, variables)
        return cast(dict[str, Any], data["delete_container_registry_quota"])
