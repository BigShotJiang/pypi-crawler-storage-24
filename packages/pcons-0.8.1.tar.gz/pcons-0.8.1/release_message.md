    Gary Oberbrunner (7):
          Add auto-generated toolchain and builder docs, register contrib builders
          Improve Generator() discoverability in docs and source
          Add configure_file() for template-based config header generation
          Add install_name/SONAME support for shared libraries
          Fix object file name collisions for sources sharing a basename
          Bump version to v0.8.1
          Fix Windows example expected_outputs for new object path format

