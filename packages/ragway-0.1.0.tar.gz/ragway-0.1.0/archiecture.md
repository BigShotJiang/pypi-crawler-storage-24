rag-toolkit/
│
├── README.md
├── LICENSE
├── pyproject.toml
├── requirements.txt
├── setup.py
├── py.typed
│
├── Makefile
├── docker-compose.yml
│
├── CONTRIBUTING.md
├── CHANGELOG.md
│
├── .github/
│   └── workflows/
│       ├── lint.yml
│       └── tests.yml
│
├── docs/
   pages/
       index.mdx
       quickstart.mdx
       architecture.mdx

       concepts/
           what_is_rag.mdx
           embeddings.mdx
           vector_database.mdx
           retrieval.mdx
           reranking.mdx
           prompt_engineering.mdx
           long_context_rag.mdx
           evaluation.mdx

       pipelines/
           naive_rag.mdx
           hybrid_rag.mdx
           agentic_rag.mdx
           graph_rag.mdx
           self_rag.mdx
           long_context_rag.mdx

       modules/
           ingestion.mdx
           document_parsing.mdx
           chunking.mdx
           embeddings.mdx
           vectorstore.mdx
           retrieval.mdx
           reranking.mdx
           generation.mdx
           evaluation.mdx

       contributing/
           development_setup.mdx
           coding_guidelines.mdx
           architecture_decisions.mdx

       api/
           auto_generated_reference.mdx
│
│   ├── concepts/
│   │   ├── what_is_rag.md
│   │   ├── embeddings.md
│   │   ├── vector_database.md
│   │   ├── retrieval.md
│   │   ├── reranking.md
│   │   ├── prompt_engineering.md
│   │   ├── long_context_rag.md
│   │   └── evaluation.md
│
│   ├── pipelines/
│   │   ├── naive_rag.md
│   │   ├── hybrid_rag.md
│   │   ├── agentic_rag.md
│   │   ├── graph_rag.md
│   │   ├── self_rag.md
│   │   └── long_context_rag.md
│
│   ├── modules/
│   │   ├── ingestion.md
│   │   ├── document_parsing.md
│   │   ├── chunking.md
│   │   ├── embeddings.md
│   │   ├── vectorstore.md
│   │   ├── retrieval.md
│   │   ├── reranking.md
│   │   ├── generation.md
│   │   └── evaluation.md
│
│   ├── contributing/
│   │   ├── development_setup.md
│   │   ├── coding_guidelines.md
│   │   └── architecture_decisions.md
│
│   └── api/
│       └── auto_generated_reference.md
│
├── rag/
│   ├── __init__.py
│   ├── exceptions.py
│   ├── validators.py
│
│   ├── interfaces/
│   │   ├── retriever_protocol.py
│   │   ├── embedding_protocol.py
│   │   ├── reranker_protocol.py
│   │   └── llm_protocol.py
│
│   ├── core/
│   │   ├── rag_engine.py
│   │   ├── rag_pipeline.py
│   │   ├── pipeline_runner.py
│   │   ├── dependency_container.py
│   │   └── config.py
│
│   ├── config/
│   │   ├── rag_config.py
│   │   ├── model_config.py
│   │   ├── retriever_config.py
│   │   └── pipeline_config.py
│
│   ├── schema/
│   │   ├── document.py
│   │   ├── node.py
│   │   └── metadata.py
│
│   ├── parsing/
│   │   ├── document_parser.py
│   │   ├── pdf_parser.py
│   │   ├── markdown_parser.py
│   │   ├── html_parser.py
│   │   └── layout_parser.py
│
│   ├── ingestion/
│   │   ├── base_loader.py
│   │   ├── pdf_loader.py
│   │   ├── markdown_loader.py
│   │   ├── web_loader.py
│   │   └── api_loader.py
│
│   ├── document_store/
│   │   ├── base_store.py
│   │   ├── sqlite_store.py
│   │   └── postgres_store.py
│
│   ├── preprocessing/
│   │   ├── text_cleaner.py
│   │   ├── metadata_enricher.py
│   │   └── language_detector.py
│
│   ├── chunking/
│   │   ├── base_chunker.py
│   │   ├── fixed_chunker.py
│   │   ├── semantic_chunker.py
│   │   ├── recursive_chunker.py
│   │   ├── sliding_window_chunker.py
│   │   ├── page_chunker.py
│   │   ├── section_chunker.py
│   │   └── hierarchical_chunker.py
│
│   ├── embeddings/
│   │   ├── base_embedding.py
│   │   ├── openai_embedding.py
│   │   ├── bge_embedding.py
│   │   ├── instructor_embedding.py
│   │   └── sentence_transformer_embedding.py
│
│   ├── indexing/
│   │   ├── index_builder.py
│   │   ├── index_updater.py
│   │   ├── metadata_index.py
│   │   └── page_index_builder.py
│
│   ├── vectorstores/
│   │   ├── base_vectorstore.py
│   │   ├── faiss_store.py
│   │   ├── chroma_store.py
│   │   ├── pinecone_store.py
│   │   └── weaviate_store.py
│
│   ├── retrieval/
│   │   ├── base_retriever.py
│   │   ├── vector_retriever.py
│   │   ├── hybrid_retriever.py
│   │   ├── bm25_retriever.py
│   │   ├── multi_query_retriever.py
│   │   ├── metadata_retriever.py
│   │   ├── parent_document_retriever.py
│   │   ├── long_context_retriever.py
│   │   └── hierarchical_retriever.py
│
│   ├── reranking/
│   │   ├── base_reranker.py
│   │   ├── bge_reranker.py
│   │   ├── cohere_reranker.py
│   │   └── cross_encoder_reranker.py
│
│   ├── prompting/
│   │   ├── prompt_builder.py
│   │   ├── templates.py
│   │   ├── prompt_registry.py
│   │   ├── prompt_versioning.py
│   │   ├── context_formatter.py
│   │   ├── page_context_formatter.py
│   │   └── citation_formatter.py
│
│   ├── generation/
│   │   ├── base_llm.py
│   │   ├── openai_llm.py
│   │   ├── anthropic_llm.py
│   │   ├── llama_llm.py
│   │   └── local_llm.py
│
│   ├── tools/
│   │   ├── base_tool.py
│   │   ├── search_tool.py
│   │   ├── retrieval_tool.py
│   │   ├── calculator_tool.py
│   │   └── tool_registry.py
│
│   ├── components/
│   │   ├── query_expansion.py
│   │   ├── context_compression.py
│   │   ├── memory_module.py
│   │   ├── citation_builder.py
│   │   ├── page_citation_builder.py
│   │   ├── guardrails.py
│   │   └── hallucination_detector.py
│
│   ├── evaluation/
│   │   ├── ragas_eval.py
│   │   ├── faithfulness.py
│   │   ├── answer_accuracy.py
│   │   ├── context_recall.py
│   │   ├── context_precision.py
│   │   ├── hallucination_score.py
│   │   └── latency_eval.py
│
│   ├── caching/
│   │   ├── embedding_cache.py
│   │   ├── retrieval_cache.py
│   │   └── llm_cache.py
│
│   ├── observability/
│   │   ├── tracing.py
│   │   ├── metrics.py
│   │   ├── logging.py
│   │   └── cost_tracker.py
│
│   ├── plugins/
│   │   ├── plugin_interface.py
│   │   └── plugin_loader.py
│
│   └── utils/
│       ├── token_counter.py
│       ├── async_executor.py
│       └── text_utils.py
│
├── pipelines/
│   ├── naive_rag_pipeline.py
│   ├── hybrid_rag_pipeline.py
│   ├── agentic_rag_pipeline.py
│   ├── graph_rag_pipeline.py
│   ├── self_rag_pipeline.py
│   └── long_context_rag_pipeline.py
│
├── benchmarks/
│   ├── rag_eval_dataset.py
│   ├── dataset_loader.py
│   ├── synthetic_dataset_generator.py
│   └── question_generator.py
│
├── experiments/
│   ├── experiment_runner.py
│   ├── benchmark_configs/
│   └── experiment_logs/
│
├── cli/
│   ├── rag_cli.py
│   └── commands/
│       ├── ingest.py
│       ├── query.py
│       ├── evaluate.py
│       └── benchmark.py
│
├── studio/
│   ├── rag_debugger.py
│   ├── pipeline_visualizer.py
│   └── experiment_dashboard.py
│
├── examples/
│   ├── chat_with_pdf
│   ├── research_assistant
│   ├── codebase_assistant
│   └── company_knowledgebase
│
├── tutorials/
│   ├── tutorial_01_basic_rag
│   ├── tutorial_02_advanced_rag
│   ├── tutorial_03_agentic_rag
│   └── tutorial_04_graph_rag
│
└── tests/
    ├── unit/
    ├── integration/
    └── benchmark/
----docs-site/
   package.json
   next.config.js
   theme.config.tsx

   pages/
      index.mdx
      quickstart.mdx
      architecture.mdx
