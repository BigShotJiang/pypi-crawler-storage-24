# ISTP Global Attributes Rules

