# ISTP Variable Attributes Rules

