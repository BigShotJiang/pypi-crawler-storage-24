"""Bottom status bar — shows install progress and quit hint."""

from textual.widgets import Static


class StatusBar(Static):
    """Single-line docked status bar spanning the full terminal width."""

    DEFAULT_CSS = """
    StatusBar {
        dock: bottom;
        height: 1;
        background: #1e1e2e;
        color: #e0e0e0;
        text-style: bold;
        content-align: left middle;
        padding: 0 2;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.can_focus = False
        self._step_info: str = "Starting..."

    def on_mount(self) -> None:
        self._refresh_display()

    def _refresh_display(self) -> None:
        """Refresh the status bar content."""
        self.update(
            f" [Ctrl+\\\\] Quit  |  {self._step_info}  |  Agent Johnny 5"
        )

    def set_step(
        self, step: int, total: int, title: str, status: str
    ) -> None:
        """Update the step progress display."""
        if status == "complete" and step == total:
            self._step_info = "Install Complete!"
        elif status == "error":
            self._step_info = f"Step {step}/{total}: {title} (ERROR)"
        else:
            self._step_info = f"Step {step}/{total}: {title}"
        self._refresh_display()
