"""Custom Textual messages for cross-component communication.

Messages bubble upward from child widgets to the App.
The App's handlers dispatch to the appropriate subsystems.

v1.1: Added InstallOutput for deterministic runner output.
"""

from textual.message import Message


class AgentTyping(Message):
    """Agent is processing — show a typing indicator in the chat pane."""
    pass


class AgentReply(Message):
    """A complete message from Agent Johnny 5.

    Posted from the agent's background thread via call_from_thread().
    Contains the FULL final text (not a streaming partial).
    """

    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()


class AgentToolCall(Message):
    """Agent requested a tool execution — displayed in chat as an indicator."""

    def __init__(self, tool_name: str, args: dict) -> None:
        self.tool_name = tool_name
        self.args = args
        super().__init__()


class ProgressUpdate(Message):
    """Structured progress update from the install runner."""

    def __init__(self, step: int, total: int, title: str, status: str) -> None:
        self.step = step
        self.total = total
        self.title = title
        self.status = status
        super().__init__()


class InstallOutput(Message):
    """Output from the deterministic install runner.

    Stream types:
      - "stdout": normal command output
      - "stderr": error output from a command
      - "error": install runner error message
      - "success": completion message
    """

    def __init__(self, text: str, stream: str = "stdout") -> None:
        self.text = text
        self.stream = stream
        super().__init__()
