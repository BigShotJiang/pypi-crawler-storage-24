from yta_video_opengl.pipeline import _OpenGLPipeline
from yta_video_opengl.texture import PipelineTextures, _PipelineTexture
from yta_editor_nodes_common import _Node
from typing import Mapping

import moderngl


# TODO: This class will be adapted to all our custom ones
class _OpenGLNode(_Node):
    """
    *For internal use only*

    Instanciable OpenGL node. Holds only parameters and
    timing.

    This node will instantiated as many times as
    different changes we want to apply with the same
    node, and will internally use the same singleton
    instance to actually apply the changes (due to a
    performance motivation).

    A static or initial uniform is an uniform that will
    not change during the different executions of the
    node. A dynamic uniform is an uniform that we set
    for that specific execution, which could be a 
    progress during a transition, for example.

    An nstantiable OpenGL node that encapsulates
    parameters, timing, and uniform state, delegating
    the actual GPU execution to a shared node processor.
    It merges static and per-execution dynamic uniforms,
    prepares the frame context and input textures, and
    produces an output texture at the requested
    resolution.
    """

    mandatory_inputs = []
    optional_inputs = []

    def __init__(
        self,
        opengl_pipeline: _OpenGLPipeline,
        **initial_uniforms
    ):
        # TODO: Describe with the doc
        self._opengl_pipeline = opengl_pipeline
        """
        *For internal use only*

        The pipeline that contains the shaders to be
        executed.
        """
        self._static_uniforms = initial_uniforms.copy()
        """
        *For internal useo nly*

        The uniforms that are passed when instantiating
        this class and will be used everytime we call
        the `process` method, unless they are
        overwritten by the dynamic one (passed when
        calling the `process` method).
        """

    def _get_textures_map(
        self,
        inputs: dict[str, moderngl.Texture]
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc. The input must be called
        `base_input`.
        """
        textures = {}

        for key, value in inputs.items():
            # None values are simply omitted
            if value is None:
                continue

            textures[key.replace('_input', '_texture')] = value

        return textures

    def _validate_inputs(
        self,
        inputs: dict[str, moderngl.Texture]
    ) -> None:
        return super()._validate_inputs(
            inputs = inputs,
            type = moderngl.Texture
        )

    def process(
        self,
        render_target: 'RenderTarget',
        inputs: Mapping[str, 'RenderTarget'],
        **dynamic_uniforms
    ) -> 'RenderTarget':
        """
        Process the `inputs` and get the output rendered
        on the `render_target` provided by using the
        `**dynamic_uniforms` if needed and  given.

        This method must be overwritten in any specific
        node type implementation, modifying the name of
        the input textures and the way we pass them to
        the `_get_textures_map` method, that can be also
        different for each specific node type.
        """
        # Validate mandatory and optional inputs
        self._validate_inputs(inputs)

        textures_map = self._get_textures_map(inputs)

        return self._process_common(
            render_target = render_target,
            textures_map = textures_map,
            **dynamic_uniforms
        )

    def _process_common(
        self,
        render_target: 'RenderTarget',
        textures_map: dict,
        **dynamic_uniforms
    ) -> 'RenderTarget':
        """
        *For internal use only*

        The part of the processing code that all the nodes
        have in common, useful to avoid repeating the code
        and customizing only the really different part of
        code.

        The only thing that should change when calling this
        method internally is the `textures_map`, which is
        special for the different type of nodes we have.

        Remember to free the `render_target` you receive as
        output when done with it.
        """
        # Preserve original size or force the one passed
        # as parameter
        if not textures_map:
            raise ValueError('At least one texture must be provided.')

        # Combine uniforms but dynamic ones have priority
        uniforms = {
            **self._static_uniforms,
            **dynamic_uniforms
        }

        # TODO: Uniforms here must be a simple dict with
        # 'key': 'value'

        # Bind input textures
        textures = PipelineTextures(
            textures = [
                _PipelineTexture(
                    name = name,
                    opengl_texture = opengl_texture
                )
                for name, opengl_texture in textures_map.items()
            ]
        )

        return self._opengl_pipeline.render(
            target = render_target,
            uniforms = uniforms,
            textures = textures
        )