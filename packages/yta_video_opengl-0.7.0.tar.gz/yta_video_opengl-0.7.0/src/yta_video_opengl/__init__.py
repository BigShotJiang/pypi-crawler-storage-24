"""
Module that includes OpenGL and the way to handle
the shaders, the uniforms, etc.

Interesting information:
| Abrev.  | Nombre completo            | Uso principal                          |
| ------- | -------------------------- | -------------------------------------- |
| VAO     | Vertex Array Object        | Esquema de datos de vértices           |
| VBO     | Vertex Buffer Object       | Datos crudos de vértices en GPU        |
| FBO     | Frame Buffer Object        | Renderizar fuera de pantalla           |
| UBO     | Uniform Buffer Object      | Variables `uniform` compartidas        |
| EBO/IBO | Element / Index Buffer Obj | Índices para reutilizar vértices       |
| PBO     | Pixel Buffer Object        | Transferencia rápida de imágenes       |
| RBO     | Render Buffer Object       | Almacén intermedio (profundidad, etc.) |

Hey, this is interesting:
- https://youtube.com/playlist?list=PLlrATfBNZ98foTJPJ_Ev03o2oq3-GGOS2&si=r7Pmm6gEtd8DS75-
"""

"""
TODO: This below is an example of how easy would
declaring a new node would be.
"""
# from yta_video_opengl.pipeline import _OpenGLPipeline
# from yta_video_opengl.opengl_nodes import _SingleTextureOpenGLNode


# class _ColorContrastOpenGLPipeline(_OpenGLPipeline):
#     """
#     *For internal use only*

#     A OpenGL pipeline to modify the color contrast
#     of the textures we receive as input.

#     This pipeline is specific and unique for its the
#     Node with the same name.
#     """

#     @property
#     def fragment_shader(
#         self
#     ):
#         return (
#             '''
#             #version 330

#             uniform sampler2D base_texture;
#             uniform float factor;
#             in vec2 v_uv;
#             out vec4 output_color;

#             void main() {
#                 vec4 color = texture(base_texture, v_uv);
#                 vec3 mean = vec3(0.5);
#                 color.rgb = (color.rgb - mean) * factor + mean;
#                 output_color = vec4(clamp(color.rgb, 0.0, 1.0), color.a);
#             }
#             '''
#         )
    
# class ColorContrastOpenGLNode(_SingleTextureOpenGLNode):
#     """
#     A node to modify the color contrast of the
#     textures that come as inputs.
#     """

#     def __init__(
#         self,
#         # TODO: Maybe provide a context (?)
#         factor: float = 1.5
#     ):
#         super().__init__(
#             opengl_pipeline = _ColorContrastOpenGLPipeline(
#                 opengl_context = None
#             ),
#             factor = factor
#         )