from yta_video_opengl.context.provider import OpenGLContextProvider
from yta_video_opengl.texture import PipelineTextures
from yta_video_opengl.uniforms import _Uniforms
from yta_video_opengl.utils import get_fullscreen_quad_vao
from yta_validation.parameter import ParameterValidator
from yta_programming.singleton import SingletonABCMeta
from abc import abstractmethod
from typing import Union

import moderngl


class _OpenGLPipeline(
    metaclass = SingletonABCMeta
):
    """
    *For internal use only*

    *Abstract class*

    *Singleton class*

    The pipeline to load the GPU program in memory,
    which is the expensive part and must be done only
    once per program. This class must be inherited by
    the specific implementations.
    """

    @property
    def vertex_shader(
        self
    ) -> str:
        """
        The code of the vertex shader. This is, by default,
        a rectangle made by 2 triangles that will fit the
        whole screen.

        Feel free to override this method if you need 
        something more complex, but this is very useful for
        our projects.

        Modifying this should need to modify the quad VAO
        that is generated automatically.
        """
        return (
            '''
            #version 330
            in vec2 in_vert;
            in vec2 in_texcoord;
            out vec2 v_uv;

            void main() {
                v_uv = in_texcoord;
                gl_Position = vec4(in_vert, 0.0, 1.0);
            }
            '''
        )
    
    @property
    @abstractmethod
    def fragment_shader(
        self
    ) -> str:
        """
        The code of the fragment shader.
        """
        pass

    @property
    @abstractmethod
    def _textures_expected(
        self
    ) -> dict:
        """
        *For internal use only*

        Get the list of textures (`sampler2d`) that are needed
        for the shaders, that come ordered in the way the 
        index is the unit in which it should be placed, but
        also their value is the unit to use.

        This is basically declaring the `sampler2d` that exist
        in the shaders code, in the order they appear, that must
        be set in the specific pipeline.

        An example of a valid return:
        ```
        return {
            'original_texture': 0,
            'processed_texture': 1,
            'selection_mask_texture': 2
        }
        ```
        """
        pass

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None]
    ):
        """
        Provide all the variables you want to be initialized
        as uniforms at the begining for the global OpenGL
        animation in the `**kwargs`.
        """
        ParameterValidator.validate_instance_of('opengl_context', opengl_context, moderngl.Context)
        # TODO: Validate size

        self.context: moderngl.Context = (
            OpenGLContextProvider().context
            if opengl_context is None else
            opengl_context
        )
        """
        The context of the OpenGL program.
        """

        self._init_program_and_quad_vao()

    def _init_program_and_quad_vao(
        self
    ) -> '_OpenGLPipeline':
        """
        *For internal use only*

        Initialize and set the program and the quad VAO
        needed to use the shades and render properly.

        Call this method within a test before any operation
        to make sure the quad VAO and the program have been
        loaded correctly. This can fail due to the fact that
        the tests are isolated and we are using singleton
        instances.
        """
        # Compile shaders within the program
        self.program: moderngl.Program = self.context.program(
            vertex_shader = self.vertex_shader,
            fragment_shader = self.fragment_shader
        )

        """
        Define the index of the samplers (`sampler2d`) based
        on the shaders code.
        """
        for name, unit in self._textures_expected.items():
            self.program[name].value = unit

        # Create the fullscreen quad VAO
        self.quad_vao = get_fullscreen_quad_vao(
            context = self.context,
            program = self.program
        )

        return self
    
    def render(
        self,
        target: 'RenderTarget',
        uniforms: dict[str, any],
        textures: PipelineTextures
    ) -> 'RenderTarget':
        """
        Set the `uniforms` and `textures` provided and
        render the output using the `target` provided to
        write on it.
        """
        # Set our target to be used and clear to process
        target.use()
        target.clear()

        """
        We need to receive the 'target' to be able to
        have this pipeline independent, just focus on
        executing the shader with the uniforms and 
        textures needed and provided. We don't acquire
        nor liberate here so we can preserve the render
        targets as we need by doing it outside, in the
        classes that call this class to render.
        """

        # 1. Update the uniforms
        pipeline_uniforms = _Uniforms(self.program)

        """
        They send us the uniforms, as keys and values,
        that we must set in the shaders to be able to
        execute it and obtain the expected results.
        """
        for key, value in uniforms.items():
            pipeline_uniforms.set(
                name = key,
                value = value
            )

        # 2. Update the textures
        """
        They send us a set of textures indexed by their
        names and including the real 'moderngl.Texture'
        that will be set in its unit, which is defined
        in this pipeline.
        """
        for texture in textures.textures:
            # Find the unit according to our pipeline's config
            texture_unit = self._textures_expected.get(texture.name, None)

            if texture_unit is None:
                raise Exception(f'Texture {texture.name} provided but not expected in this pipeline {self.__class__.__name__}.')

            # Set the texture to be used in that unit
            texture.opengl_texture.use(texture_unit)

        # 3. Render
        self.quad_vao.render()

        return target