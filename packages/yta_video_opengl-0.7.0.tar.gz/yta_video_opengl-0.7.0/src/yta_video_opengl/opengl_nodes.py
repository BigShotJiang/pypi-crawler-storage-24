"""
TODO: These nodes are here because they must
be moved to the 'yta_editor_nodes_gpu'.
"""
from yta_video_opengl.node import _OpenGLNode


# TODO: We need to create the specific _OpenGLNode
# implementations that assign the pipelines and
# contexts specifically and ask for the uniforms it
# can use directly as parameters. But we also need
# the specific _OpenGLPipeline that includes the
# shaders we want to apply for a specific purpose

# TODO: This is just an example below and shouldn't
# be in this proyect but in 'yta_editor_nodes_gpu'

# TODO: With the new implementation this is not that
# good because the parameters could be mandatory or
# optional and we don't really know it at this point
class _SingleTextureOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a single texture called
    `base_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.
    """

    mandatory_inputs: list[str] = ['base_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

# TODO: Create the other types but in the
# 'yta_editor_nodes_gpu' library
        
class _BaseAndOverlayTexturesOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a base texture called
    `base_texture` and an overlay texture named as
    `overlay_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.
    """

    mandatory_inputs: list[str] = ['base_input', 'overlay_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

class _FirstAndSecondTexturesOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a first texture called
    `first_texture` and a second texture named as
    `second_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.

    This is more specific for transitions or changes
    in which we go from a first texture to a second
    one somehow.
    """

    mandatory_inputs: list[str] = ['first_input', 'second_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

class _OriginalProcessedSelectionOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses one texture called
    `original_texture` and a second texture named as
    `processed_texture`, with also another one called
    `selection_mask_texture`, in the shaders. This
    class must be inherited by the specific nodes that
    use this single texture to make changes.

    This is specific for applying the selection mask
    to mix the `processed_texture` with the original
    one.
    """

    mandatory_inputs: list[str] = ['original_input', 'processed_input', 'selection_mask_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """