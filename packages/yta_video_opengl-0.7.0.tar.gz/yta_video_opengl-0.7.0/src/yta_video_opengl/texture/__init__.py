from dataclasses import dataclass
from typing import Union

import moderngl


@dataclass
class _PipelineTexture:
    """
    *For internal use only*

    *Dataclass*

    Dataclass to store a texture and the name associated
    that must be used to set it in the program through
    the pipeline.
    """
    
    def __init__(
        self,
        name: str,
        opengl_texture: Union[moderngl.Texture, None]
    ):
        self.name: str = name
        """
        The name of the texture that is being used in the
        shaders.
        """
        self.opengl_texture: Union[moderngl.Texture, None] = opengl_texture
        """
        The `moderngl.Texture` texture itself.
        """

@dataclass
class PipelineTextures:
    """
    *Dataclass*

    A dataclass to pass the textures to the pipeline
    to be able to render them properly, including the
    name and the texture itself.
    """
    
    def __init__(
        self,
        textures: list[_PipelineTexture] = []
    ):
        self.textures: list[_PipelineTexture] = textures
        """
        Our list of textures to handle them easy.
        """

    def get(
        self,
        name: str
    ) -> Union[_PipelineTexture, None]:
        """
        Gete the texture with the given `name` if
        existing.
        """
        return next(
            (
                texture
                for texture in self.textures
                if texture.name == name
            ),
            None
        )
    
    def set(
        self,
        name: str,
        opengl_texture: moderngl.Texture
    ) -> 'PipelineTextures':
        """
        Set the `texture` provided as the one to be
        used in the location of the registered
        texture with the `name` provided.

        The code:
        - `texture.use(location = self._textures[name])`
        """
        texture_object = self.get(name)

        if texture_object is not None:
            texture_object.opengl_texture = opengl_texture
        else:
            self.textures.append(_PipelineTexture(
                    name = name,
                    opengl_texture = opengl_texture
                )
            )

        return self