"""
By now we are only accepting these values:
- Texture dtypes: `f1`
- Numpy dtypes: `np.uint8, np.float32`
"""
from yta_editor_utils.texture import TextureUtils


"""
We keep the code in the 'yta_editor_utils' module,
making 'numpy' mandatory (because it is used
everywhere and does not cause very problematic
conflicts) but 'moderngl' optional (as it is very
specific), so we can easily use the code in other
libraries like this one.

Here, the 'moderngl' is a mandatory dependency, so
we can use the TextureUtils class without any
problem.
"""
TextureUtils = TextureUtils