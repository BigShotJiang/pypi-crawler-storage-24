import os
import pytest
from sds_mng.order.fetch_orders_async import _fetch

@pytest.mark.asyncio
async def test_fetch_orders():
    token = os.environ.get("SDS_MNG_TOKEN")
    orders = await _fetch(token, {"merchantIds": [53292]})
    assert orders.get("list", [])[-1].get("merchant", {}).get("name") == "印美达测试账号1"