"""UI components for TinyChat."""
