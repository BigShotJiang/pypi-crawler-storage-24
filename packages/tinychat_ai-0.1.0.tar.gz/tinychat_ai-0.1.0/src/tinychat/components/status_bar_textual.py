"""StatusBar component for displaying status information using Textual."""

from textual.widgets import Static
from textual.reactive import reactive
from rich.text import Text

from tinychat.utils.i18n import _


class StatusBarTextual(Static):
    """Component to display status information."""

    DEFAULT_CSS = """
    StatusBarTextual {
        height: 1;
        padding: 0 1;
        background: $panel;
        color: $text;
    }
    """

    backend_name: reactive[str] = reactive("", layout=True)
    model: reactive[str] = reactive("", layout=True)
    connection_status: reactive[str] = reactive("disconnected", layout=True)
    response_time: reactive[float | None] = reactive(None, layout=True)
    tokens_per_second: reactive[float | None] = reactive(None, layout=True)
    error_message: reactive[str | None] = reactive(None, layout=True)
    is_generating: reactive[bool] = reactive(False, layout=True)
    status: reactive[str] = reactive("idle", layout=True)

    def render(self) -> Text:
        """Render the status bar content."""
        if self.status == "error" and self.error_message:
            text = Text()
            text.append(_("ERROR: "), style="bold red")
            text.append(self.error_message, style="red")
            return text

        parts = []

        if self.status == "loading":
            parts.append(f"⏳ {_('Loading...')}")
        elif self.status == "streaming":
            parts.append(f"⚡ {_('Streaming...')}")
        elif self.status == "success":
            parts.append(f"✓ {_('Success')}")
        elif self.is_generating:
            parts.append(f"⏳ {_('Generating...')}")

        if self.backend_name:
            parts.append(f"{_('Backend:')} {self.backend_name}")
        if self.model:
            parts.append(f"{_('Model:')} {self.model}")

        status_emoji = "●" if self.connection_status == "connected" else "○"
        parts.append(f"{_('Status:')} {status_emoji} {self.connection_status}")

        if self.response_time is not None:
            parts.append(f"{_('Response:')} {self.response_time:.2f}s")

        if self.tokens_per_second is not None:
            parts.append(f"{_('Speed:')} {self.tokens_per_second:.1f} {_('tok/s')}")

        if not parts:
            return Text("Status Bar")

        return Text(" │ ".join(parts))

    def update_backend_info(self, backend_name: str, model: str) -> None:
        """Update backend and model information."""
        self.backend_name = backend_name
        self.model = model

    def update_metrics(
        self,
        response_time: float | None = None,
        tokens_per_second: float | None = None,
    ) -> None:
        """Update performance metrics."""
        if response_time is not None:
            self.response_time = response_time
        if tokens_per_second is not None:
            self.tokens_per_second = tokens_per_second

    def update_connection_status(self, status: str) -> None:
        """Update connection status."""
        self.connection_status = status

    def show_error(self, message: str) -> None:
        """Show error message in status bar."""
        self.status = "error"
        self.error_message = message
        self.is_generating = False

    def set_generating(self, generating: bool) -> None:
        """Set generating state."""
        self.is_generating = generating
        if generating:
            self.error_message = None

    def set_status(self, status: str, message: str | None = None) -> None:
        """Set status state.

        Args:
            status: Status state (idle, loading, streaming, error, success).
            message: Optional message (used for error status).
        """
        self.status = status
        if status == "error" and message:
            self.error_message = message
        elif status != "error":
            self.error_message = None


StatusBar = StatusBarTextual
