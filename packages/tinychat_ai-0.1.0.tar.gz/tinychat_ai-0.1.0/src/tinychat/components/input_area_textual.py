"""InputArea component for user text input using Textual."""

import asyncio

from textual.binding import Binding
from textual.events import Key
from textual.widgets import TextArea

from tinychat.utils.i18n import _


class InputArea(TextArea):
    """Component for user input with placeholder."""

    BINDINGS = [
        Binding("ctrl+enter", "newline", "New Line", show=False),
    ]

    def __init__(
        self,
        placeholder: str | None = None,
        **kwargs,
    ):
        """Initialize InputArea with placeholder."""
        super().__init__(text="", language=None, **kwargs)
        if placeholder is None:
            placeholder = _(
                "Type your message... (Enter to send, Ctrl+Enter for newline)"
            )
        self.placeholder = placeholder

    def on_key(self, event: Key) -> None:
        """Handle key events."""
        if event.key == "enter":
            # Send message on Enter
            event.prevent_default()
            self.action_send_message()
        elif event.key == "ctrl+enter":
            # Insert newline on Ctrl+Enter
            event.prevent_default()
            self.action_newline()

    def action_send_message(self) -> None:
        """Send the current message."""
        text = self.text
        if text.strip():
            if hasattr(self.app, "send_message"):
                asyncio.create_task(self.app.send_message(text))
            self.text = ""

    def action_newline(self) -> None:
        """Insert a newline."""
        self.insert("\n")

    def on_paste(self, event) -> None:
        """Handle paste events with image detection."""
        if hasattr(event, "text") and event.text:
            pass
        else:
            event.prevent_default()
            try:
                from tinychat.components.status_bar_textual import StatusBar

                status_bar = self.app.query_one(StatusBar)
                status_bar.set_status("error", message="Image input not supported")
            except Exception:
                pass
