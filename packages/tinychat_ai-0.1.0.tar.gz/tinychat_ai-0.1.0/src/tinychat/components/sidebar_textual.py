"""Sidebar component for displaying backends and models using Textual."""

from textual.widgets import Static
from textual.reactive import reactive
from rich.text import Text

from tinychat.utils.i18n import _


class SidebarTextual(Static):
    """Component to display backends and selected model."""

    DEFAULT_CSS = """
    SidebarTextual {
        width: 1fr;
        min-width: 20;
        padding: 1;
        background: $panel;
        color: $text;
    }
    """

    backends: reactive[list[str]] = reactive([], layout=True)
    selected_backend_idx: reactive[int] = reactive(0, layout=True)
    selected_model: reactive[str] = reactive("", layout=True)

    def __init__(self, backends: list[str] | None = None, **kwargs):
        """Initialize SidebarTextual with optional backends list."""
        super().__init__(**kwargs)
        if backends is not None:
            self.backends = backends

    def render(self) -> Text:
        """Render the sidebar content."""
        text = Text()

        text.append("═" * 3 + f" {_('Backends')} " + "═" * 3 + "\n", style="bold")

        for idx, backend in enumerate(self.backends):
            if idx == self.selected_backend_idx:
                text.append("► ", style="bold")
            else:
                text.append("  ")
            text.append(backend + "\n")

        text.append("\n")
        text.append("═" * 3 + f" {_('Models')} " + "═" * 3 + "\n", style="bold")

        if self.selected_model:
            text.append(f"  {self.selected_model}\n")

        return text

    def get_selected_backend(self) -> str:
        """Get the currently selected backend name."""
        if 0 <= self.selected_backend_idx < len(self.backends):
            return self.backends[self.selected_backend_idx]
        return ""

    def get_selected_model(self) -> str:
        """Get the currently selected model name."""
        return self.selected_model

    def set_selected_backend(self, name: str) -> None:
        """Set the selected backend by name."""
        try:
            idx = self.backends.index(name)
            self.selected_backend_idx = idx
        except ValueError:
            pass

    def set_selected_model(self, name: str) -> None:
        """Set the selected model name."""
        self.selected_model = name


Sidebar = SidebarTextual
