"""ChatView component for displaying message history using Textual."""

import logging
from dataclasses import replace

from textual import events
from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.reactive import reactive
from textual.widgets import Markdown

from tinychat.models.message import Message
from tinychat.utils.clipboard import copy_to_clipboard
from tinychat.utils.i18n import _

logger = logging.getLogger(__name__)


class ChatView(VerticalScroll):
    """Component to display chat message history."""

    DEFAULT_CSS = """
    ChatView {
        height: 1fr;
        scrollbar-color: $primary;
        scrollbar-color-hover: $primary-lighten-1;
        scrollbar-color-active: $primary-darken-1;
        scrollbar-background: $surface;
        scrollbar-size-vertical: 2;
    }
    """

    messages: reactive[list[Message]] = reactive(list, layout=True)

    def __init__(self, messages: list[Message] | None = None, **kwargs):
        """Initialize ChatView with optional messages."""
        super().__init__(**kwargs)
        self._initial_messages = messages
        self._active_stream = None
        self._streaming_message_content = ""
        self._is_streaming = False

    def compose(self) -> ComposeResult:
        """Compose message widgets."""
        yield Markdown(self._format_welcome_message(), id="chat-markdown")

    def should_auto_scroll(self) -> bool:
        """Check if user is at or near the bottom of the scroll."""
        if self.max_scroll_y == 0:
            return True

        tolerance = 3
        return (self.max_scroll_y - self.scroll_y) <= tolerance

    def watch_messages(
        self, old_messages: list[Message], new_messages: list[Message]
    ) -> None:
        """React to messages changes."""
        if self._is_streaming:
            return

        if self._can_update():
            was_at_bottom = self.should_auto_scroll()

            self._update_display()

            should_scroll = (
                len(new_messages) > len(old_messages) and was_at_bottom
            ) or (len(old_messages) == 0 and len(new_messages) > 0)

            if should_scroll:
                self.set_timer(0.05, self._delayed_scroll)

    def _delayed_scroll(self) -> None:
        """Delayed scroll to bottom after Markdown renders."""
        self.scroll_to_bottom()

    def _can_update(self) -> bool:
        """Check if the widget can safely update its display."""
        try:
            return self.app is not None and self.is_mounted
        except AttributeError, RuntimeError:
            return False

    def _update_display(self) -> None:
        """Update the display with current messages."""
        markdown_widget = self.query_one(Markdown)
        if not self.messages:
            markdown_widget.update(self._format_welcome_message())
        else:
            markdown_widget.update(self._format_messages())

    def _format_messages(self) -> str:
        """Format messages for display."""
        lines = []
        for i, message in enumerate(self.messages):
            if i > 0:
                lines.append("")
                lines.append("---")
                lines.append("")

            if message.role == "user":
                lines.append(f"**{_('User:')}**")
                lines.append(message.content)
            else:
                lines.append(f"**{_('Assistant:')}**")
                lines.append(message.content)

        return "\n".join(lines)

    def _format_welcome_message(self) -> str:
        """Format welcome message."""
        return f"""{_("# Welcome to TinyChat!")}

{_("Start a conversation by typing your message below.")}

{_("*Tips: Your chat history is saved automatically.*")}
"""

    def scroll_to_bottom(self) -> None:
        """Scroll to the bottom of the chat."""
        self.scroll_end(animate=False)

    def get_stream(self):
        """Get the Markdown streaming interface."""
        markdown_widget = self.query_one(Markdown)
        return Markdown.get_stream(markdown_widget)

    def clear_streaming(self) -> None:
        """Clear the Markdown widget for a new streaming response."""
        markdown_widget = self.query_one(Markdown)
        markdown_widget.update("")

    def start_streaming(self) -> None:
        """Prepare for streaming by initializing stream state."""
        self._is_streaming = True
        self._active_stream = self.get_stream()
        self._streaming_message_content = ""

    def stop_streaming(self) -> None:
        """Finalize streaming and update messages list."""
        self._is_streaming = False
        if self._streaming_message_content:
            if self.messages:
                messages = self.messages.copy()
                messages[-1] = replace(
                    messages[-1], content=self._streaming_message_content
                )
                self.messages = messages
        self._active_stream = None
        self._streaming_message_content = ""

    def is_streaming(self) -> bool:
        """Check if currently streaming."""
        return self._is_streaming

    def get_streaming_content(self) -> str:
        """Get current streaming message content."""
        return self._streaming_message_content

    def set_streaming_content(self, content: str) -> None:
        """Set streaming message content."""
        self._streaming_message_content = content

    def get_active_stream(self):
        """Get the active stream object."""
        return self._active_stream

    def on_mount(self) -> None:
        """Called when widget is mounted."""
        if self._initial_messages is not None:
            self.messages = self._initial_messages

    def on_mouse_up(self, event: events.MouseUp) -> None:
        """Handle mouse up to detect text selection and auto-copy.

        When user releases mouse button after selecting text in the Markdown
        widget, automatically copy the selection to clipboard and show notification.
        """
        selected_text = self.screen.get_selected_text()
        if not selected_text or not selected_text.strip():
            return

        if copy_to_clipboard(selected_text):
            char_count = len(selected_text)
            self.app.notify(
                _("Copied {char_count} characters to clipboard").format(
                    char_count=char_count
                ),
                title=_("Copied!"),
                timeout=2,
            )
        else:
            self.app.notify(
                _("Failed to copy to clipboard"),
                title=_("Error"),
                timeout=2,
            )
