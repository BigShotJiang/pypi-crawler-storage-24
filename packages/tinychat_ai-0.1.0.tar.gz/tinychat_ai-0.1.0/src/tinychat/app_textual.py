"""Main Textual-based application for TinyChat."""

import asyncio
import logging
from dataclasses import replace
from typing import TYPE_CHECKING

from collections.abc import Iterable

from textual.app import App, ComposeResult, SystemCommand
from textual.reactive import reactive
from textual.screen import Screen

from tinychat.backends.base import Backend
from tinychat.utils.i18n import _, get_available_locales, get_current_locale, set_locale
from tinychat.utils.config_manager import load_user_config, save_user_config
from tinychat.components.chat_view_textual import ChatView
from tinychat.components.input_area_textual import InputArea
from tinychat.components.sidebar_textual import Sidebar
from tinychat.components.status_bar_textual import StatusBar
from tinychat.models.message import Message
from tinychat.models.session import ChatSession
from tinychat.utils.metrics import MetricsCollector

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class TinyChatApp(App):
    """Main Textual-based application orchestrator."""

    CSS_PATH = "styles/app.css"

    current_session: reactive[ChatSession | None] = reactive(None)
    messages: reactive[list[Message]] = reactive(list)
    is_generating: reactive[bool] = reactive(False)
    connection_status: reactive[str] = reactive("disconnected")
    metrics: reactive[dict] = reactive(dict)

    def __init__(self) -> None:
        """Initialize the TinyChat application."""
        super().__init__()
        self._backends: dict[str, Backend] = {}
        self.metrics_collector = MetricsCollector()
        self._skip_watch_messages = False

    def register_backend(self, name: str, backend: Backend) -> None:
        """Register a backend instance with the given name.

        Args:
            name: Unique identifier for the backend.
            backend: Backend instance to register.
        """
        self._backends[name] = backend

    def _get_backend(self, backend_name: str | None = None) -> Backend | None:
        """Get backend by name or return first available.

        Args:
            backend_name: Optional name of specific backend to retrieve.

        Returns:
            Backend instance if found, None otherwise.
        """
        if backend_name and backend_name in self._backends:
            return self._backends[backend_name]
        return next(iter(self._backends.values()), None)

    def watch_messages(
        self, old_messages: list[Message], new_messages: list[Message]
    ) -> None:
        """React to messages changes by updating ChatView."""
        if self._skip_watch_messages:
            return

        try:
            chat_view = self.query_one(ChatView)
            if chat_view:
                chat_view.messages = new_messages
                chat_view.refresh()
        except Exception as e:
            logger.warning(f"Error updating ChatView: {e}")

    def compose(self) -> ComposeResult:
        """Compose the application layout."""
        # Layout: ChatView and Sidebar on top, InputArea below, StatusBar at bottom
        # Grid: 2 columns x 3 rows
        # Auto-placement order matters:
        # 1. ChatView: column 0, row 0
        # 2. Sidebar: column 1, row 0 (row-span: 2, occupies rows 0-1)
        # 3. InputArea: column 0, row 1
        # 4. StatusBar: column 0, row 2 (column-span: 2, spans columns 0-1)
        chat_view = ChatView(messages=self.messages)
        yield chat_view
        yield Sidebar()
        yield InputArea()
        yield StatusBar()

    async def on_mount(self) -> None:
        """Initialize backends after app is mounted."""
        if not self._backends:
            return

        try:
            status_bar = self.query_one(StatusBar)

            first_backend_name = next(iter(self._backends))
            backend = self._backends[first_backend_name]

            is_connected = await backend.test_connection()

            if is_connected:
                self.connection_status = "connected"
                status_bar.update_connection_status("connected")

                info = backend.get_info()
                backend_name = info.get("name", "")
                model = info.get("default_model", "")

                status_bar.update_backend_info(
                    backend_name=backend_name,
                    model=model,
                )

                sidebar = self.query_one(Sidebar)
                sidebar.backends = list(self._backends.keys())
                sidebar.set_selected_model(model)

                # Create or update session with correct backend info
                if not self.current_session:
                    self.current_session = ChatSession(
                        id="default",
                        title="Default Session",
                        backend_name=backend_name,
                        model=model,
                        messages=[],
                    )
                else:
                    # Update existing session
                    self.current_session.backend_name = backend_name
                    self.current_session.model = model
            else:
                self.connection_status = "disconnected"
                status_bar.update_connection_status("disconnected")
        except Exception as e:
            logger.error(f"Error initializing backends: {e}")
            self.connection_status = "error"

        self.query_one(InputArea).focus()

    async def send_message(self, text: str) -> None:
        """Send a user message and stream assistant response."""
        if not text or not text.strip():
            try:
                status_bar = self.query_one(StatusBar)
                status_bar.set_status("error", message=_("Message cannot be empty"))
            except Exception as e:
                logger.warning(f"Error showing empty message error: {e}")
            return

        processed_text = self._process_special_commands(text)

        if not processed_text:
            return

        try:
            status_bar = self.query_one(StatusBar)
        except Exception as e:
            logger.warning(f"Error getting StatusBar: {e}")
            status_bar = None

        chat_view = None
        try:
            chat_view = self.query_one(ChatView)
        except Exception as e:
            logger.warning(f"Error getting ChatView: {e}")

        message = Message(role="user", content=processed_text)
        assistant_message = Message(role="assistant", content=_("Thinking..."))
        messages = self.messages + [message, assistant_message]
        self.messages = messages

        backend = self._get_backend()
        if not backend:
            return

        if not self.current_session:
            return

        self.current_session.messages = list(self.messages)

        if status_bar:
            status_bar.set_status("loading")

        stream = None
        write_tasks = []
        if chat_view:
            chat_view.start_streaming()
            stream = chat_view.get_stream()

        self.metrics_collector.start()
        first_token = True
        error_occurred = False

        def on_token(token: str):
            nonlocal first_token
            self.metrics_collector.record_token()
            if first_token and status_bar:
                status_bar.set_status("streaming")
            if stream and chat_view:
                task = asyncio.get_event_loop().create_task(stream.write(token))
                write_tasks.append(task)
                chat_view.set_streaming_content(
                    chat_view.get_streaming_content() + token
                )

                messages = self.messages.copy()
                last_message = messages[-1]
                if first_token:
                    updated_message = replace(last_message, content=token)
                else:
                    updated_message = replace(
                        last_message, content=last_message.content + token
                    )
                messages[-1] = updated_message
                self._skip_watch_messages = True
                try:
                    self.messages = messages
                finally:
                    self._skip_watch_messages = False
            else:
                self._update_assistant_message(token, first_token)
            if status_bar:
                metrics = self.metrics_collector.get_metrics()
                status_bar.update_metrics(
                    tokens_per_second=metrics.get("tokens_per_second"),
                    response_time=metrics.get("response_time"),
                )
            first_token = False

        try:
            await backend.chat(self.current_session, on_token)
            if status_bar and not error_occurred:
                status_bar.set_status("success")
        except Exception as e:
            logger.error(f"Error during chat streaming: {e}")
            error_occurred = True
            self._handle_backend_error(e, not first_token)
            if status_bar:
                error_str = str(e)
                max_error_len = 50
                if len(error_str) > max_error_len:
                    error_str = error_str[:max_error_len]
                status_bar.set_status("error", message=error_str)
        finally:
            if write_tasks:
                await asyncio.gather(*write_tasks, return_exceptions=True)
            if stream:
                try:
                    await stream.stop()
                except Exception as e:
                    logger.warning(f"Error stopping stream: {e}")
            if chat_view:
                chat_view.stop_streaming()
            self.metrics_collector.stop()
            self.metrics = self.metrics_collector.get_metrics()
            self.current_session.messages = list(self.messages)
            if status_bar:
                status_bar.set_status("idle")

    def _process_special_commands(self, text: str) -> str | None:
        """Process special commands like translation.

        Args:
            text: Original user input

        Returns:
            Transformed text, or None if command is invalid
        """
        if text.startswith("翻译：") or text.startswith("翻译:"):
            content = text.split("：", 1)[-1].split(":", 1)[-1].strip()
            if not content:
                try:
                    status_bar = self.query_one(StatusBar)
                    status_bar.set_status(
                        "error", message=_("Translation content cannot be empty")
                    )
                except Exception as e:
                    logger.warning(f"Error showing translation error: {e}")
                return None
            return f"请翻译以下内容：{content}"

        if text.lower().startswith("translate:"):
            content = text.split(":", 1)[-1].strip()
            if not content:
                try:
                    status_bar = self.query_one(StatusBar)
                    status_bar.set_status(
                        "error", message=_("Translation content cannot be empty")
                    )
                except Exception as e:
                    logger.warning(f"Error showing translation error: {e}")
                return None
            return f"Please translate the following: {content}"

        return text

    def _update_assistant_message(self, token: str, is_first: bool) -> None:
        """Update the last assistant message with streaming token.

        Args:
            token: Token to append or set as content.
            is_first: True if this is the first token (replaces content).
        """
        if not self.messages:
            return

        chat_view = None
        try:
            chat_view = self.query_one(ChatView)
            if is_first and not chat_view.is_streaming():
                chat_view.start_streaming()
        except Exception as e:
            logger.warning(f"Error getting ChatView: {e}")

        if chat_view and chat_view.is_streaming() and chat_view.get_active_stream():
            active_stream = chat_view.get_active_stream()
            if active_stream:
                task = asyncio.get_event_loop().create_task(active_stream.write(token))
                if not hasattr(self, "_stream_write_tasks"):
                    self._stream_write_tasks = []
                self._stream_write_tasks.append(task)
            if is_first:
                chat_view.set_streaming_content(token)
            else:
                chat_view.set_streaming_content(
                    chat_view.get_streaming_content() + token
                )

            messages = self.messages.copy()
            last_message = messages[-1]
            if is_first:
                updated_message = replace(last_message, content=token)
            else:
                updated_message = replace(
                    last_message, content=last_message.content + token
                )
            messages[-1] = updated_message
            self._skip_watch_messages = True
            try:
                self.messages = messages
            finally:
                self._skip_watch_messages = False
            return

        messages = self.messages.copy()
        last_message = messages[-1]

        if is_first:
            updated_message = replace(last_message, content=token)
        else:
            updated_message = replace(
                last_message, content=last_message.content + token
            )

        messages[-1] = updated_message
        self.messages = messages
        self.refresh()

    async def _finalize_streaming(self) -> None:
        """Finalize streaming by awaiting pending writes and stopping stream."""
        if hasattr(self, "_stream_write_tasks") and self._stream_write_tasks:
            await asyncio.gather(*self._stream_write_tasks, return_exceptions=True)
            self._stream_write_tasks = []

        try:
            chat_view = self.query_one(ChatView)
            active_stream = chat_view.get_active_stream()
            if active_stream:
                await active_stream.stop()
            chat_view.stop_streaming()
        except Exception as e:
            logger.warning(f"Error finalizing streaming: {e}")

    def _handle_backend_error(self, error: Exception, tokens_received: bool) -> None:
        """Handle backend errors by updating assistant message.

        Args:
            error: The exception that occurred.
            tokens_received: Whether any tokens were received before error.
        """
        if not self.messages:
            return

        messages = self.messages.copy()
        last_message = messages[-1]

        error_str = str(error)
        max_error_len = 100 - len(_("[Error: {error}]").format(error=""))
        if len(error_str) > max_error_len:
            error_str = error_str[:max_error_len]
        error_text = _("[Error: {error}]").format(error=error_str)

        if tokens_received:
            updated_message = replace(
                last_message, content=last_message.content + f"\n{error_text}"
            )
        else:
            updated_message = replace(last_message, content=error_text)

        messages[-1] = updated_message
        self.messages = messages
        self.refresh()

    def get_system_commands(self, screen: Screen) -> Iterable[SystemCommand]:
        """Yield system commands with i18n support."""
        if not self.ansi_color:
            yield SystemCommand(
                _("Theme"),
                _("Change the current theme"),
                self.action_change_theme,
            )
        yield SystemCommand(
            _("Quit"),
            _("Quit the application as soon as possible"),
            self.action_quit,
        )

        if screen.query("HelpPanel"):
            yield SystemCommand(
                _("Keys"),
                _("Hide the keys and widget help panel"),
                self.action_hide_help_panel,
            )
        else:
            yield SystemCommand(
                _("Keys"),
                _("Show help for the focused widget and a summary of available keys"),
                self.action_show_help_panel,
            )

        if screen.maximized is not None:
            yield SystemCommand(
                _("Minimize"),
                _("Minimize the widget and restore to normal size"),
                screen.action_minimize,
            )
        elif screen.focused is not None and screen.focused.allow_maximize:
            yield SystemCommand(
                _("Maximize"),
                _("Maximize the focused widget"),
                screen.action_maximize,
            )

        yield SystemCommand(
            _("Screenshot"),
            _("Save an SVG 'screenshot' of the current screen"),
            lambda: self.set_timer(0.1, self.deliver_screenshot),
        )

        current = get_current_locale()
        if current == "en":
            yield SystemCommand(
                _("Switch to Chinese"),
                _("Change UI language to Chinese"),
                self._switch_to_chinese,
            )
        else:
            yield SystemCommand(
                _("Switch to English"),
                _("Change UI language to English"),
                self._switch_to_english,
            )

    def _switch_to_chinese(self) -> None:
        """Switch UI to Chinese."""
        self._change_locale("zh")

    def _switch_to_english(self) -> None:
        """Switch UI to English."""
        self._change_locale("en")

    def _change_locale(self, locale: str) -> None:
        """Change the application locale.

        Args:
            locale: New locale code (e.g., 'en', 'zh')
        """
        if locale not in get_available_locales():
            logger.warning(f"Invalid locale '{locale}' requested")
            self.notify(_("Invalid locale."))
            return

        try:
            config = load_user_config()
            config.locale = locale
            save_user_config(config)
        except (OSError, IOError) as e:
            logger.error(f"Failed to save locale config: {e}")
            self.notify(_("Failed to save language preference."))
            return

        set_locale(locale)

        self.refresh()

        self.notify(_("Language changed. Restart app for full effect."))
