"""Abstract backend interface."""

from abc import ABC, abstractmethod
from typing import Callable

from tinychat.models.session import ChatSession


class BackendError(Exception):
    """Exception raised for backend errors."""

    pass


class Backend(ABC):
    """Abstract base class for LLM backends."""

    @abstractmethod
    async def list_models(self) -> list[str]:
        """Return list of available model names."""
        pass

    @abstractmethod
    async def chat(
        self,
        session: ChatSession,
        on_token: Callable[[str], None],
    ) -> None:
        """Stream chat response, calling on_token for each chunk."""
        pass

    @abstractmethod
    async def test_connection(self) -> bool:
        """Verify backend is reachable."""
        pass

    @abstractmethod
    def get_info(self) -> dict:
        """Return backend metadata."""
        pass
