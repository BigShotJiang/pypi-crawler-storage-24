"""Backend implementations for different LLM services."""
