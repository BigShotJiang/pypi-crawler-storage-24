"""OpenAI-compatible backend implementation."""

from typing import Callable
import json

import httpx

from tinychat.backends.base import Backend, BackendError
from tinychat.models.config import BackendConfig
from tinychat.models.session import ChatSession


class OpenAIBackend(Backend):
    """OpenAI-compatible backend implementation."""

    def __init__(self, config: BackendConfig):
        """Initialize OpenAI backend."""
        self.config = config
        self.client = httpx.AsyncClient(
            base_url=config.endpoint,
            timeout=httpx.Timeout(30.0),
            trust_env=False,
        )
        self.api_key = config.api_key

        # Add authorization header for OpenAI API
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        self.client.headers.update(headers)

    async def aclose(self) -> None:
        """Close HTTP client and cleanup resources."""
        await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.aclose()

    async def list_models(self) -> list[str]:
        """Return list of available models from OpenAI API."""
        response = await self.client.get("/models")
        response.raise_for_status()
        data = response.json()
        return [model["id"] for model in data.get("data", [])]

    async def chat(self, session: ChatSession, on_token: Callable[[str], None]) -> None:
        """Stream chat response from OpenAI-compatible API."""
        messages = [
            {"role": msg.role, "content": msg.content} for msg in session.messages
        ]

        payload = {
            "model": session.model,
            "messages": messages,
            "stream": True,
        }

        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            async with self.client.stream(
                "POST", "/chat/completions", json=payload, headers=headers
            ) as response:
                # Check response status
                if response.status_code != 200:
                    error_text = await response.aread()
                    raise BackendError(
                        f"API error {response.status_code}: {error_text[:200]}"
                    )

                async for line in response.aiter_lines():
                    if line:
                        try:
                            # Skip "data: " prefix if present
                            line = line.strip()
                            if line.startswith("data: "):
                                line = line[6:]
                            if line == "[DONE]":
                                continue

                            data = json.loads(line)
                            if "choices" in data and len(data["choices"]) > 0:
                                delta = data["choices"][0].get("delta", {})
                                if "content" in delta and delta["content"]:
                                    on_token(delta["content"])
                                elif "error" in data:
                                    # Handle API error in streaming response
                                    error_msg = data["error"].get(
                                        "message", "Unknown error"
                                    )
                                    raise BackendError(
                                        f"API error in stream: {error_msg}"
                                    )
                        except json.JSONDecodeError:
                            # Skip invalid JSON lines but log for debugging
                            import sys

                            print(
                                f"Warning: Invalid JSON in stream: {line[:100]}",
                                file=sys.stderr,
                            )
                            continue
        except httpx.HTTPError as e:
            raise BackendError(f"Chat request failed: {e}") from e

    async def test_connection(self) -> bool:
        """Test if OpenAI backend is reachable."""
        try:
            response = await self.client.get("/models")
            return response.status_code == 200
        except Exception:
            return False

    def get_info(self) -> dict:
        """Return backend metadata."""
        return {
            "name": self.config.name,
            "type": self.config.type,
            "endpoint": self.config.endpoint,
            "default_model": self.config.default_model,
            "api_key": self.config.api_key,
        }
