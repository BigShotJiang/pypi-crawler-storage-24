"""Ollama backend implementation."""

import json
from typing import Callable

import httpx

from tinychat.backends.base import Backend, BackendError
from tinychat.models.config import BackendConfig
from tinychat.models.session import ChatSession


class OllamaBackend(Backend):
    """Backend for Ollama API."""

    def __init__(self, config: BackendConfig):
        """Initialize Ollama backend."""
        self.config = config
        self.client = httpx.AsyncClient(
            base_url=config.endpoint, timeout=httpx.Timeout(30.0), trust_env=False
        )

    async def aclose(self) -> None:
        """Close HTTP client and cleanup resources."""
        await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.aclose()

    async def list_models(self) -> list[str]:
        """Return list of available models from Ollama."""
        response = await self.client.get("/api/tags")
        response.raise_for_status()
        data = response.json()
        return [model["name"] for model in data.get("models", [])]

    async def chat(self, session: ChatSession, on_token: Callable[[str], None]) -> None:
        """Stream chat response from Ollama."""
        messages = [
            {"role": msg.role, "content": msg.content} for msg in session.messages
        ]

        payload = {
            "model": session.model,
            "messages": messages,
            "stream": True,
        }

        try:
            async with self.client.stream(
                "POST", "/api/chat", json=payload
            ) as response:
                async for line in response.aiter_lines():
                    if line:
                        try:
                            data = json.loads(line)
                            if "message" in data and "content" in data["message"]:
                                token = data["message"]["content"]
                                on_token(token)
                        except json.JSONDecodeError:
                            pass
        except httpx.HTTPError as e:
            raise BackendError(f"Chat request failed: {e}") from e

    async def test_connection(self) -> bool:
        """Test if Ollama backend is reachable."""
        try:
            response = await self.client.get("/api/tags")
            return response.status_code == 200
        except Exception:
            return False

    def get_info(self) -> dict:
        """Return backend metadata."""
        return {
            "name": self.config.name,
            "type": self.config.type,
            "endpoint": self.config.endpoint,
            "default_model": self.config.default_model,
        }
