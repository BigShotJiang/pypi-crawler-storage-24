"""Configuration file loading."""

from pathlib import Path

try:
    import tomllib
except ImportError:
    import tomli as tomllib

from tinychat.models.config import BackendConfig


def load_backends(config_path: Path) -> list[BackendConfig]:
    """Load backend configurations from TOML file."""
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path, "rb") as f:
        data = tomllib.load(f)

    backends = []
    for backend_data in data.get("backends", []):
        backend = BackendConfig(
            name=backend_data["name"],
            type=backend_data["type"],
            endpoint=backend_data["endpoint"],
            default_model=backend_data["default_model"],
            api_key=backend_data.get("api_key"),
        )
        backends.append(backend)

    return backends
