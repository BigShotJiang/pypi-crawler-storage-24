"""TinyChat - TUI AI chat tool for local LLM development."""
