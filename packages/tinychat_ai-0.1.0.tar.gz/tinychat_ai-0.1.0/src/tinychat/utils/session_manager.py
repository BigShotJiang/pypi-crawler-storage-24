"""Session manager for managing chat sessions."""

import uuid
from typing import Protocol

from tinychat.models.session import ChatSession


class SessionPersistence(Protocol):
    """Protocol for session persistence."""

    def save_session(self, session: ChatSession) -> None:
        """Save session to storage."""
        ...

    def delete_session(self, session_id: str) -> None:
        """Delete session from storage."""
        ...


class SessionManager:
    """Manages multiple chat sessions."""

    def __init__(self, persistence: SessionPersistence):
        self.sessions: dict[str, ChatSession] = {}
        self.active_session_id: str | None = None
        self.persistence = persistence
        self._session_counter = 0

    def create_session(self, backend_name: str, model: str) -> ChatSession:
        """Create new session with auto-generated ID and title."""
        self._session_counter += 1
        session = ChatSession(
            id=str(uuid.uuid4()),
            title=f"Chat {self._session_counter}",
            backend_name=backend_name,
            model=model,
        )
        self.sessions[session.id] = session
        self.persistence.save_session(session)
        return session

    def switch_session(self, session_id: str) -> None:
        """Switch to specified session."""
        if session_id in self.sessions:
            self.active_session_id = session_id

    def close_session(self, session_id: str) -> bool:
        """Close session (refuse if it's the last one)."""
        if len(self.sessions) <= 1:
            return False
        del self.sessions[session_id]
        self.persistence.delete_session(session_id)
        return True

    def get_active_session(self) -> ChatSession | None:
        """Get current active session."""
        if self.active_session_id:
            return self.sessions.get(self.active_session_id)
        return None

    def rename_session(self, session_id: str, new_title: str) -> None:
        """Rename session and persist."""
        if session_id in self.sessions:
            self.sessions[session_id].title = new_title
            self.persistence.save_session(self.sessions[session_id])
