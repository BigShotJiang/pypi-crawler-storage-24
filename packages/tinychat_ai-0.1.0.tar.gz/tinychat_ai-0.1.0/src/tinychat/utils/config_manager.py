"""Unified TOML configuration manager for TinyChat.

This module provides a unified configuration system that stores both user
preferences and backend configurations in a single TOML file at
~/.config/tinychat/config.toml
"""

import logging
from pathlib import Path

try:
    import tomllib
except ImportError:
    import tomli as tomllib

import tomli_w

from tinychat.models.config import BackendConfig
from tinychat.models.user_config import UserConfig

logger = logging.getLogger(__name__)

_CONFIG_DIR = ".config/tinychat"
_CONFIG_FILE = "config.toml"
_SETTINGS_SECTION = "settings"
_BACKENDS_SECTION = "backends"
_KEY_LOCALE = "locale"


def get_config_path() -> Path:
    """Return the path to the unified TOML configuration file.

    Returns:
        Path to ~/.config/tinychat/config.toml
    """
    return Path.home() / _CONFIG_DIR / _CONFIG_FILE


def load_user_config() -> UserConfig:
    """Load user configuration from TOML file.

    Returns:
        UserConfig with loaded values, or default UserConfig if file doesn't exist
        or required sections/keys are missing.
    """
    config_path = get_config_path()

    if not config_path.exists():
        logger.debug(f"Config file not found at {config_path}, returning default")
        return UserConfig()

    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
    except (tomllib.TOMLDecodeError, OSError) as e:
        logger.warning(f"Failed to parse config file {config_path}: {e}")
        return UserConfig()

    settings = data.get(_SETTINGS_SECTION, {})
    if not isinstance(settings, dict):
        logger.debug(f"Invalid [{_SETTINGS_SECTION}] section, returning default")
        return UserConfig()

    locale = settings.get(_KEY_LOCALE)
    if not locale:
        logger.debug("Empty or missing locale value in config, returning default")
        return UserConfig()

    return UserConfig(locale=str(locale))


def save_user_config(config: UserConfig) -> None:
    """Save user configuration to TOML file.

    Preserves existing [[backends]] configuration if present.
    Creates parent directories if they don't exist.

    Args:
        config: UserConfig to save
    """
    config_path = get_config_path()

    try:
        config_path.parent.mkdir(parents=True, exist_ok=True)

        existing_backends = []
        if config_path.exists():
            try:
                with open(config_path, "rb") as f:
                    existing_data = tomllib.load(f)
                existing_backends = existing_data.get(_BACKENDS_SECTION, [])
            except tomllib.TOMLDecodeError, OSError:
                pass

        data = {
            _SETTINGS_SECTION: {_KEY_LOCALE: config.locale},
        }

        if existing_backends:
            data[_BACKENDS_SECTION] = existing_backends

        with open(config_path, "wb") as f:
            tomli_w.dump(data, f)

    except (IOError, OSError, PermissionError) as e:
        logger.warning(f"Failed to save config to {config_path}: {e}")


def load_backends() -> list[BackendConfig]:
    """Load backend configurations from unified TOML file.

    Returns:
        List of BackendConfig objects, or empty list if file doesn't exist
        or no backends are configured.
    """
    config_path = get_config_path()

    if not config_path.exists():
        logger.debug(f"Config file not found at {config_path}, returning empty list")
        return []

    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
    except (tomllib.TOMLDecodeError, OSError) as e:
        logger.warning(f"Failed to parse config file {config_path}: {e}")
        return []

    backends_data = data.get(_BACKENDS_SECTION, [])
    if not isinstance(backends_data, list):
        logger.debug(f"Invalid [{_BACKENDS_SECTION}] section, returning empty list")
        return []

    backends = []
    for backend_data in backends_data:
        if not isinstance(backend_data, dict):
            continue
        try:
            backend = BackendConfig(
                name=backend_data["name"],
                type=backend_data["type"],
                endpoint=backend_data["endpoint"],
                default_model=backend_data["default_model"],
                api_key=backend_data.get("api_key"),
            )
            backends.append(backend)
        except KeyError as e:
            logger.warning(f"Missing required field in backend config: {e}")
            continue

    return backends
