"""Theme manager for TinyChat with accessibility support."""


def hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    """Convert hex color to RGB tuple."""
    hex_color = hex_color.lstrip("#")
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    return (r, g, b)


def calculate_relative_luminance(rgb: tuple[int, int, int]) -> float:
    """Calculate relative luminance according to WCAG 2.1."""
    r, g, b = rgb

    def channel_luminance(c):
        c = c / 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

    return (
        0.2126 * channel_luminance(r)
        + 0.7152 * channel_luminance(g)
        + 0.0722 * channel_luminance(b)
    )


def calculate_contrast_ratio(color1: str, color2: str) -> float:
    """Calculate contrast ratio between two colors.

    Args:
        color1: First color in hex format (e.g., "#FFFFFF")
        color2: Second color in hex format (e.g., "#000000")

    Returns:
        Contrast ratio (1:1 to 21:1)
    """
    rgb1 = hex_to_rgb(color1)
    rgb2 = hex_to_rgb(color2)

    l1 = calculate_relative_luminance(rgb1)
    l2 = calculate_relative_luminance(rgb2)

    lighter = max(l1, l2)
    darker = min(l1, l2)

    return (lighter + 0.05) / (darker + 0.05)


def meets_wcag_aa(color1: str, color2: str) -> bool:
    """Check if color combination meets WCAG AA standard.

    WCAG AA requires:
    - 4.5:1 for normal text
    - 3:1 for large text

    Args:
        color1: First color in hex format
        color2: Second color in hex format

    Returns:
        True if meets WCAG AA standard
    """
    ratio = calculate_contrast_ratio(color1, color2)
    return ratio >= 4.5


class ThemeManager:
    """Manages application themes with accessibility support."""

    THEMES = {
        "dark": {
            "background": "#000000",
            "foreground": "#FFFFFF",
            "status_bar": "#333333",
            "status_position": "#aaaa00",
            "status_key": "#ffaa00",
            "input_bg": "#000000",
        },
        "light": {
            "background": "#FFFFFF",
            "foreground": "#000000",
            "status_bar": "#E0E0E0",
            "status_position": "#0066CC",
            "status_key": "#CC6600",
            "input_bg": "#F5F5F5",
        },
    }

    def __init__(self, default_theme: str = "dark"):
        """Initialize ThemeManager.

        Args:
            default_theme: Default theme to use (default: "dark")
        """
        self.current_theme = default_theme

    @property
    def available_themes(self) -> list[str]:
        """Get list of available themes."""
        return list(self.THEMES.keys())

    def switch_theme(self, theme_name: str) -> None:
        """Switch to a different theme.

        Args:
            theme_name: Name of the theme to switch to

        Raises:
            ValueError: If theme_name is not valid
        """
        if theme_name not in self.THEMES:
            raise ValueError(f"Unknown theme: {theme_name}")
        self.current_theme = theme_name

    def get_theme_colors(self, theme_name: str | None = None) -> dict[str, str]:
        """Get color scheme for a theme.

        Args:
            theme_name: Name of theme (uses current theme if None)

        Returns:
            Dictionary of color names to hex values
        """
        theme = theme_name or self.current_theme
        return self.THEMES.get(theme, self.THEMES["dark"]).copy()

    def validate_theme_colors(self, colors: dict[str, str]) -> bool:
        """Validate that theme colors meet accessibility standards.

        Args:
            colors: Dictionary of color names to hex values

        Returns:
            True if all critical color combinations meet WCAG AA
        """
        if "background" not in colors or "foreground" not in colors:
            return False

        if not meets_wcag_aa(colors["background"], colors["foreground"]):
            return False

        if "status_bar" in colors:
            if not meets_wcag_aa(colors["status_bar"], colors["foreground"]):
                return False

        return True
