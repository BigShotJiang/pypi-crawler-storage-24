"""Session persistence manager for saving/loading chat sessions."""

import json
import logging
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

from tinychat.models.message import Message
from tinychat.models.session import ChatSession


class SessionPersistence:
    """Manages persistent storage of chat sessions as JSON files."""

    def __init__(self, storage_dir: Path = Path.home() / ".tinychat" / "sessions"):
        """Initialize persistence manager.

        Args:
            storage_dir: Directory to store session files
        """
        self.storage_dir = storage_dir
        self.storage_dir.mkdir(parents=True, exist_ok=True)

    def save_session(self, session: ChatSession) -> None:
        """Save session to JSON file.

        Args:
            session: ChatSession to save
        """
        file_path = self.storage_dir / f"{session.id}.json"
        with open(file_path, "w") as f:
            json.dump(asdict(session), f, default=self._serialize_datetime)

    @staticmethod
    def _serialize_datetime(obj):
        """Serialize datetime to ISO format string."""
        if isinstance(obj, datetime):
            return obj.isoformat()
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

    def load_all_sessions(self) -> list[ChatSession]:
        """Load all sessions from storage.

        Returns:
            List of ChatSession objects (skips corrupted files)
        """
        sessions = []
        for file_path in self.storage_dir.glob("*.json"):
            try:
                with open(file_path) as f:
                    data = json.load(f)
                    data = self._deserialize_session_data(data)
                    sessions.append(ChatSession(**data))
            except (json.JSONDecodeError, KeyError, TypeError) as e:
                logging.warning(f"Skipping corrupted session file: {file_path} - {e}")
        return sessions

    @staticmethod
    def _deserialize_session_data(data: dict) -> dict:
        """Deserialize session data from dict.

        Converts message dicts to Message objects and datetime strings to datetime objects.

        Args:
            data: Raw session data dict

        Returns:
            Deserialized session data
        """
        if "messages" in data:
            data["messages"] = [
                Message(**msg) if isinstance(msg, dict) else msg
                for msg in data["messages"]
            ]

        if "created_at" in data and isinstance(data["created_at"], str):
            data["created_at"] = datetime.fromisoformat(data["created_at"])

        if "timestamp" in data and isinstance(data["timestamp"], str):
            data["timestamp"] = datetime.fromisoformat(data["timestamp"])

        return data

    def delete_session(self, session_id: str) -> None:
        """Delete session file.

        Args:
            session_id: ID of session to delete
        """
        file_path = self.storage_dir / f"{session_id}.json"
        if file_path.exists():
            file_path.unlink()
