"""Event bus for inter-component communication."""

from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class Event:
    """An event emitted on the event bus."""

    type: str
    data: Any
    source: str


class EventBus:
    """Event bus for decoupled component communication."""

    def __init__(self):
        """Initialize event bus."""
        self._subscribers: dict[str, list[Callable]] = {}

    def subscribe(self, event_type: str, handler: Callable[[Event], None]) -> None:
        """Subscribe to events of a specific type."""
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(handler)

    async def emit(self, event: Event) -> None:
        """Emit an event to all subscribers."""
        handlers = self._subscribers.get(event.type, [])
        for handler in handlers:
            try:
                # Check if handler is a coroutine function
                import inspect

                if inspect.iscoroutinefunction(handler):
                    await handler(event)
                else:
                    # Synchronous handler, call directly
                    handler(event)
            except Exception as e:
                # Log error but don't crash
                import sys

                print(f"Error in event handler for {event.type}: {e}", file=sys.stderr)
