"""Centralized error handling and user notification."""

import logging

from tinychat.errors import BackendError, PersistenceError, ValidationError
from tinychat.utils.event_bus import EventBus


class ErrorHandler:
    """Centralized error handling and user notification."""

    def __init__(self, event_bus: EventBus, status_bar):
        """Initialize ErrorHandler with EventBus and StatusBar."""
        self.event_bus = event_bus
        self.status_bar = status_bar

    def handle_error(self, error: Exception, context: str = "") -> None:
        """Handle error with appropriate strategy."""
        if isinstance(error, BackendError):
            self._handle_backend_error(error)
        elif isinstance(error, ValidationError):
            self._handle_validation_error(error)
        elif isinstance(error, PersistenceError):
            self._handle_persistence_error(error)
        else:
            self._handle_unknown_error(error, context)

    def _handle_backend_error(self, error: BackendError) -> None:
        """Handle BackendError by updating status and showing error."""
        self.status_bar.update_connection_status("error")
        self.status_bar.show_error(f"Backend error: {error}")
        logging.error(f"Backend {error.backend_name} error", exc_info=error)

    def _handle_validation_error(self, error: ValidationError) -> None:
        """Handle ValidationError by showing field error."""
        self.status_bar.show_error(f"Invalid {error.field}: {error}")
        logging.warning(f"Validation error on field {error.field}: {error}")

    def _handle_persistence_error(self, error: PersistenceError) -> None:
        """Handle PersistenceError by showing generic message."""
        self.status_bar.show_error("Session save failed")
        logging.error(f"Persistence error at {error.file_path}", exc_info=error)

    def _handle_unknown_error(self, error: Exception, context: str) -> None:
        """Handle unknown errors with generic message."""
        self.status_bar.show_error("An unexpected error occurred")
        logging.error(f"Unknown error in {context}", exc_info=error)
