"""User configuration manager for loading/saving user preferences."""

import configparser
import logging
from pathlib import Path

from tinychat.models.user_config import UserConfig

logger = logging.getLogger(__name__)

_CONFIG_DIR = ".config/tinychat"
_CONFIG_FILE = "config"
_SECTION = "tinychat"
_KEY_LOCALE = "locale"


def get_config_path() -> Path:
    """Return the path to the user configuration file.

    Returns:
        Path to ~/.config/tinychat/config
    """
    return Path.home() / _CONFIG_DIR / _CONFIG_FILE


def load_user_config() -> UserConfig:
    """Load user configuration from INI file.

    Returns:
        UserConfig with loaded values, or default UserConfig if file doesn't exist
        or required sections/keys are missing.
    """
    config_path = get_config_path()

    if not config_path.exists():
        logger.debug(f"Config file not found at {config_path}, returning default")
        return UserConfig()

    parser = configparser.ConfigParser()
    try:
        parser.read(config_path)
    except (configparser.MissingSectionHeaderError, configparser.ParsingError) as e:
        logger.warning(f"Failed to parse config file {config_path}: {e}")
        return UserConfig()

    if not parser.has_section(_SECTION) or not parser.has_option(_SECTION, _KEY_LOCALE):
        logger.debug(
            f"Config file missing [{_SECTION}] section or {_KEY_LOCALE} key, returning default"
        )
        return UserConfig()

    locale = parser.get(_SECTION, _KEY_LOCALE)
    if not locale:
        logger.debug("Empty locale value in config, returning default")
        return UserConfig()
    return UserConfig(locale=locale)


def save_user_config(config: UserConfig) -> None:
    """Save user configuration to INI file.

    Creates parent directories if they don't exist.

    Args:
        config: UserConfig to save
    """
    config_path = get_config_path()

    try:
        config_path.parent.mkdir(parents=True, exist_ok=True)

        parser = configparser.ConfigParser()
        parser[_SECTION] = {_KEY_LOCALE: config.locale}

        with open(config_path, "w") as f:
            parser.write(f)
    except (IOError, OSError, PermissionError) as e:
        logger.warning(f"Failed to save config to {config_path}: {e}")
