"""Data models for TinyChat."""
