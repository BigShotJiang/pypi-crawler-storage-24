"""User configuration model."""

from dataclasses import dataclass


@dataclass
class UserConfig:
    locale: str = "en"
