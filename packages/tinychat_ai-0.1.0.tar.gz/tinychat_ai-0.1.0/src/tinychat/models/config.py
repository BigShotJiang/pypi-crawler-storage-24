"""Backend configuration models."""

from dataclasses import dataclass

from tinychat.models.user_config import UserConfig

__all__ = ["BackendConfig", "UserConfig"]


@dataclass
class BackendConfig:
    name: str
    type: str
    endpoint: str
    default_model: str
    api_key: str | None = None
