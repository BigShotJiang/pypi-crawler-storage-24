"""Chat message data model."""

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Message:
    """A single chat message."""

    role: str
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    tokens: int | None = None
    metadata: dict = field(default_factory=dict)
