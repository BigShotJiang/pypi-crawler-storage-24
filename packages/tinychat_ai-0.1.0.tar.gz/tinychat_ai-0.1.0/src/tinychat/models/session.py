"""Chat session data model."""

from dataclasses import dataclass, field
from datetime import datetime

from tinychat.models.message import Message


@dataclass
class ChatSession:
    """A chat session with message history."""

    id: str
    title: str
    backend_name: str
    model: str
    messages: list[Message] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    parameters: dict = field(default_factory=dict)
