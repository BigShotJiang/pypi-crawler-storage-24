"""Custom exception classes for TinyChat application."""

from pathlib import Path


class TinyChatError(Exception):
    """Base exception for all TinyChat errors."""

    pass


class BackendError(TinyChatError):
    """Backend connection and communication errors."""

    def __init__(
        self, message: str, backend_name: str, original_error: Exception | None = None
    ):
        self.backend_name = backend_name
        self.original_error = original_error
        super().__init__(message)


class ValidationError(TinyChatError):
    """User input validation errors."""

    def __init__(self, field: str, message: str):
        self.field = field
        super().__init__(message)


class PersistenceError(TinyChatError):
    """Session persistence errors."""

    def __init__(
        self,
        message: str,
        file_path: Path | None = None,
        original_error: Exception | None = None,
    ):
        self.file_path = file_path
        self.original_error = original_error
        super().__init__(message)
