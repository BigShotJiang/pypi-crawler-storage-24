"""Main entry point for TinyChat."""

from tinychat.app_textual import TinyChatApp
from tinychat.utils.config_manager import load_backends, load_user_config
from tinychat.utils.i18n import init_i18n


def main():
    """Main entry point for TinyChat application."""
    config = load_user_config()
    init_i18n(config.locale)

    backends_config = load_backends()

    app = TinyChatApp()

    for backend_config in backends_config:
        if backend_config.type == "ollama":
            from tinychat.backends.ollama import OllamaBackend

            backend = OllamaBackend(backend_config)
        elif backend_config.type == "openai-compatible":
            from tinychat.backends.openai import OpenAIBackend

            backend = OpenAIBackend(backend_config)
        else:
            continue
        app.register_backend(backend_config.name, backend)

    app.run()


if __name__ == "__main__":
    main()
