# TinyChat

轻量级终端 AI 聊天应用，支持多后端供应商，中英文双语界面。

## 特性

### 多后端支持
- **Ollama** - 本地 Ollama 服务器
- **OpenAI 兼容** - 支持 OpenAI 兼容的 API 服务

### 现代化终端界面
- 基于 [Textual](https://github.com/Textualize/textual) 框架
- 丰富的 Markdown 渲染和代码高亮
- 响应式布局，自适应终端尺寸
- 原生鼠标支持（点击、滚动）
- 多主题支持（明/暗主题）

### 国际化
- 中文/英文双语界面
- 一键切换语言

### 会话管理
- 自动保存聊天历史
- 支持多会话切换
- 自动生成会话标题
- 流式响应实时显示

### 跨平台
- 支持 Windows、macOS、Linux
- 跨平台剪贴板支持

---

## 安装

### 系统要求
- Python 3.14+
- pip 或 uv 包管理器

### 从 PyPI 安装

```bash
pip install tinychat
```

### 从源码安装

```bash
git clone <repository-url>
cd tinychat

# 使用 pip
pip install -e ".[dev]"

# 或使用 uv
uv sync --extra dev
```

---

## 使用

### 启动应用

```bash
tinychat
```

或直接运行模块：

```bash
python -m tinychat
```

### 基本操作

1. **选择后端** - 在左侧边栏点击后端名称
2. **选择模型** - 在边栏点击模型名称
3. **发送消息** - 输入内容后按 Enter
4. **换行** - 按 Ctrl+Enter 插入换行
5. **滚动历史** - 使用鼠标滚轮或方向键

### 快捷键

| 按键 | 功能 |
|------|------|
| **Enter** | 发送消息 |
| **Ctrl+Enter** | 输入换行 |
| **Ctrl+L** | 切换语言 |
| **Ctrl+T** | 切换主题 |
| **Ctrl+Q** | 退出应用 |
| **Ctrl+P** | 命令面板 |

---

## 配置

配置文件位于 `~/.config/tinychat/config.toml`：

```toml
[settings]
locale = "zh"  # 语言设置: "en" 或 "zh"

[[backends]]
name = "ollama"
type = "ollama"
endpoint = "http://localhost:11434"
default_model = "llama3.2"

[[backends]]
name = "openai"
type = "openai"
endpoint = "https://api.openai.com/v1"
api_key = "your-api-key"
default_model = "gpt-4o"
```

---

## 开发

### 项目结构

```
tinychat/
├── src/tinychat/
│   ├── __main__.py           # 入口
│   ├── app_textual.py        # 主应用
│   ├── backends/             # 后端实现
│   │   ├── base.py          # 抽象基类
│   │   ├── ollama.py        # Ollama 后端
│   │   └── openai.py        # OpenAI 后端
│   ├── components/           # UI 组件
│   │   ├── chat_view_textual.py
│   │   ├── input_area_textual.py
│   │   ├── sidebar_textual.py
│   │   └── status_bar_textual.py
│   ├── models/               # 数据模型
│   ├── utils/                # 工具函数
│   │   ├── event_bus.py     # 事件系统
│   │   ├── i18n.py          # 国际化
│   │   └── theme_manager.py # 主题管理
│   └── locales/              # 翻译文件
│       ├── en/LC_MESSAGES/
│       └── zh/LC_MESSAGES/
└── tests/                    # 测试
```

### 运行测试

```bash
# 运行所有测试
pytest tests/ -v

# 带覆盖率报告
pytest tests/ --cov=src/tinychat --cov-report=html

# 运行单个测试
pytest tests/unit/test_app_textual.py -v
```

### 代码检查

```bash
ruff check src/ tests/
ruff format src/ tests/
```

### 打包发布

```bash
# 安装构建工具
pip install build

# 构建
python -m build

# 生成的文件在 dist/ 目录
```

---

## 致谢

- [Textual](https://github.com/Textualize/textual) - 现代 TUI 框架
- [Rich](https://github.com/Textualize/rich) - 富文本渲染
- [httpx](https://www.python-httpx.org/) - HTTP 客户端

## 许可证

MIT License
