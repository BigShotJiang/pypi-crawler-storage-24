"""Target resolution utilities."""

