"""Build metadata written by CI before packaging."""

BUILD_GIT_SHA = "885978a44b9e32706f40d3a1ddfe2bafce9e303c"
BUILD_DATE = "2026-03-11T23:42:39Z"
