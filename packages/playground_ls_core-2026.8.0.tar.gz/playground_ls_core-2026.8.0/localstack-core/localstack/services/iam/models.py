"""
Store and entity definitions for IAM service.
"""

import dataclasses
from dataclasses import field
from datetime import UTC, datetime

from localstack.aws.api.iam import (
    AccessKey,
    AccessKeyLastUsed,
    Group,
    InstanceProfile,
    LoginProfile,
    MFADevice,
    PasswordPolicy,
    Policy,
    PolicyVersion,
    Role,
    ServerCertificateMetadata,
    ServiceSpecificCredential,
    SigningCertificate,
    SSHPublicKey,
    User,
    VirtualMFADevice,
    clientIDListType,
    thumbprintListType,
)
from localstack.services.stores import (
    AccountRegionBundle,
    BaseStore,
    CrossRegionAttribute,
)
from localstack.utils.tagging import Tags


@dataclasses.dataclass
class AwsManagedPolicy:
    """Tracks account-specific state for AWS managed policies (currently just attachment count)."""

    attachment_count: int = 0


@dataclasses.dataclass
class AccessKeyEntity:
    """Wrapper for AccessKey with last used tracking."""

    access_key: AccessKey  # UserName, AccessKeyId, Status, SecretAccessKey, CreateDate
    last_used: AccessKeyLastUsed | None = None


@dataclasses.dataclass
class RoleEntity:
    """Wrapper for Role with inline policies and managed policy tracking."""

    role: Role  # From localstack.aws.api.iam
    inline_policies: dict[str, str] = field(default_factory=dict)  # policy_name -> document
    attached_policy_arns: list[str] = field(
        default_factory=list
    )  # ARNs of attached managed policies
    linked_service: str | None = None  # For service-linked roles


@dataclasses.dataclass
class SAMLProvider:
    arn: str
    name: str
    saml_metadata_document: str
    create_date: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    valid_until: datetime | None = None


@dataclasses.dataclass
class UserEntity:
    """Wrapper for User with inline policies and managed policy tracking."""

    user: User  # From localstack.aws.api.iam
    inline_policies: dict[str, str] = field(
        default_factory=dict
    )  # policy_name -> document (URL-quoted)
    attached_policy_arns: list[str] = field(
        default_factory=list
    )  # ARNs of attached managed policies
    login_profile: LoginProfile | None = None  # Login profile for console access
    password: str | None = None  # Password for login profile (never in API responses)
    service_specific_credentials: list[ServiceSpecificCredential] = field(default_factory=list)
    ssh_public_keys: dict[str, SSHPublicKey] = field(default_factory=dict)  # key_id -> SSHPublicKey
    mfa_devices: list[str] = field(default_factory=list)
    access_keys: dict[str, AccessKeyEntity] = field(default_factory=dict)  # access_key_id -> entity
    signing_certificates: dict[str, SigningCertificate] = field(
        default_factory=dict
    )  # cert_id -> SigningCertificate


@dataclasses.dataclass
class ManagedPolicyEntity:
    """Wrapper for Policy with version tracking."""

    policy: Policy  # From localstack.aws.api.iam
    versions: dict[str, PolicyVersion] = field(default_factory=dict)  # version_id -> PolicyVersion
    next_version_num: int = 2  # Next version number (v1 is created with policy)


@dataclasses.dataclass
class GroupEntity:
    """Wrapper for Group with inline policies, managed policy tracking, and membership."""

    group: Group  # From localstack.aws.api.iam
    inline_policies: dict[str, str] = field(default_factory=dict)  # policy_name -> document
    attached_policy_arns: list[str] = field(
        default_factory=list
    )  # ARNs of attached managed policies
    member_user_names: list[str] = field(default_factory=list)  # User names in this group


@dataclasses.dataclass
class OIDCProvider:
    arn: str
    url: str
    create_date: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    client_id_list: clientIDListType = field(default_factory=list)
    thumbprint_list: thumbprintListType = field(default_factory=list)


@dataclasses.dataclass
class InstanceProfileEntity:
    """Wrapper for InstanceProfile with role tracking."""

    instance_profile: InstanceProfile  # From localstack.aws.api.iam
    role_name: str | None = None  # Name of the attached role (max 1 role per profile)


@dataclasses.dataclass
class VirtualMFADeviceEntity:
    path: str
    device: VirtualMFADevice
    user_name: str | None = None


@dataclasses.dataclass
class PhysicalMFADeviceEntity:
    path: str
    device: MFADevice
    user_name: str | None = None


@dataclasses.dataclass
class ServerCertificateEntity:
    """Entity for server certificates used with ELB, CloudFront, etc."""

    metadata: ServerCertificateMetadata  # Contains Path, Name, Id, Arn, UploadDate, Expiration
    certificate_body: str
    private_key: str  # Stored but never returned in API responses
    certificate_chain: str | None = None


@dataclasses.dataclass
class CredentialReportEntity:
    """Stores generated credential report data."""

    content: bytes  # CSV content
    generated_at: datetime


class IamStore(BaseStore):
    # Customer-managed policies keyed by ARN
    MANAGED_POLICIES: dict[str, ManagedPolicyEntity] = CrossRegionAttribute(default=dict)
    # Roles keyed by role name (unique per account)
    ROLES: dict[str, RoleEntity] = CrossRegionAttribute(default=dict)
    # Instance profiles keyed by profile name (unique per account)
    # Using CrossRegionAttribute since IAM is a global service
    INSTANCE_PROFILES: dict[str, InstanceProfileEntity] = CrossRegionAttribute(default=dict)
    # Users keyed by user name (unique per account)
    USERS: dict[str, UserEntity] = CrossRegionAttribute(default=dict)
    # Groups keyed by group name (unique per account)
    # Using CrossRegionAttribute since IAM is a global service
    GROUPS: dict[str, GroupEntity] = CrossRegionAttribute(default=dict)
    # Attachment counts for AWS managed policies, keyed by the policy ARN.
    # A key is present only when the policy has been attached at least once.
    AWS_MANAGED_POLICIES: dict[str, AwsManagedPolicy] = CrossRegionAttribute(default=dict)
    # Index for efficient access key lookups: access_key_id -> user_name
    ACCESS_KEY_INDEX: dict[str, str] = CrossRegionAttribute(default=dict)

    PASSWORD_POLICY: PasswordPolicy | None = CrossRegionAttribute(default=None)

    # SAML providers: maps provider_arn -> SAMLProvider
    # Account-scoped (IAM is global within an account)
    SAML_PROVIDERS: dict[str, SAMLProvider] = CrossRegionAttribute(default=dict)

    # OIDC providers: maps provider_arn -> OIDCProvider
    # Account-scoped (IAM is global within an account)
    OIDC_PROVIDERS: dict[str, OIDCProvider] = CrossRegionAttribute(default=dict)

    # Virtual MFA serial_number -> VirtualMFADeviceEntity
    VIRTUAL_MFA_DEVICES: dict[str, VirtualMFADeviceEntity] = CrossRegionAttribute(default=dict)

    # Physical MFA serial_number -> PhysicalMFADeviceEntity
    PHYSICAL_MFA_DEVICES: dict[str, PhysicalMFADeviceEntity] = CrossRegionAttribute(default=dict)

    # Server certificates: maps certificate_name -> ServerCertificateEntity
    # Account-scoped (IAM is global within an account)
    SERVER_CERTIFICATES: dict[str, ServerCertificateEntity] = CrossRegionAttribute(default=dict)

    # Credential report - generated CSV report for all users
    # Account-scoped (IAM is global within an account)
    CREDENTIAL_REPORT: CredentialReportEntity | None = CrossRegionAttribute(default=None)

    # Account alias (max 1 per account)
    ACCOUNT_ALIAS: str | None = CrossRegionAttribute(default=None)

    # Centralized tag storage for all IAM resources
    TAGS: Tags = CrossRegionAttribute(default=Tags)


iam_stores = AccountRegionBundle("iam", IamStore, validate=False)
