#################################################################################
# WaterTAP Copyright (c) 2020-2026, The Regents of the University of California,
# through Lawrence Berkeley National Laboratory, Oak Ridge National Laboratory,
# National Laboratory of the Rockies, and National Energy Technology
# Laboratory (subject to receipt of any required approvals from the U.S. Dept.
# of Energy). All rights reserved.
#
# Please see the files COPYRIGHT.md and LICENSE.md for full copyright and license
# information, respectively. These files are also available online at the URL
# "https://github.com/watertap-org/reaktoro-pse/"
#################################################################################
import reaktoro as rkt

import numpy as np
from reaktoro_pse.core.util_classes.rkt_inputs import RktInputTypes
from reaktoro_pse.core.reaktoro_state import ReaktoroState
from reaktoro_pse.core.reaktoro_outputs import (
    ReaktoroOutputSpec,
)
from reaktoro_pse.core.reaktoro_inputs import (
    ReaktoroInputSpec,
)
from reaktoro_pse.core.reaktoro_jacobian import (
    ReaktoroJacobianSpec,
)
import cyipopt
import idaes.logger as idaeslog

__author__ = "Alexander V. Dudchenko, Ben Knueven, Ilayda Akkor"

_log = idaeslog.getLogger(__name__)
# class to setup reaktor solver for reaktoro


class ReaktoroSolverExport:
    def __init__(self):
        self.epsilon = None
        self.tolerance = None
        self.presolve = None
        self.presolve_tolerance = None
        self.presolve_epsilon = None
        self.max_iters = None
        self.presolve_max_iters = None
        self.hessian_type = None
        self.block_name = None


class ReaktoroSolver:
    def __init__(
        self,
        reaktoro_state,
        reaktoro_input_specs,
        reaktoro_output_specs,
        reaktoro_jacobian_specs,
        block_name=None,
        maximum_failed_solves=2,
    ):
        self.block_name = block_name
        self.state = reaktoro_state
        if isinstance(self.state, ReaktoroState) == False:
            raise TypeError("Reator jacobian require rektoroState class")
        self.input_specs = reaktoro_input_specs
        if isinstance(self.input_specs, ReaktoroInputSpec) == False:
            raise TypeError("Reator outputs require ReaktoroOutputSpec class")
        self.output_specs = reaktoro_output_specs
        if isinstance(self.output_specs, ReaktoroOutputSpec) == False:
            raise TypeError("Reator outputs require ReaktoroOutputSpec class")
        self.jacobian_specs = reaktoro_jacobian_specs
        if isinstance(self.jacobian_specs, ReaktoroJacobianSpec) == False:
            raise TypeError("Reator outputs require ReaktoroOutputSpec class")
        self.solver_options = rkt.EquilibriumOptions()
        self.presolve_options = rkt.EquilibriumOptions()

        existing_constraints = self.input_specs.equilibrium_specs.namesConstraints()

        existing_variables = self.input_specs.equilibrium_specs.namesControlVariables()
        _log.info(f"rktSolver inputs: {existing_variables}")
        _log.info(f"rktSolver constraints: {existing_constraints}")
        self.solver = rkt.EquilibriumSolver(self.input_specs.equilibrium_specs)
        self.conditions = rkt.EquilibriumConditions(self.input_specs.equilibrium_specs)

        self.sensitivity = rkt.EquilibriumSensitivity(
            self.input_specs.equilibrium_specs
        )
        self.set_solver_options()
        self.set_system_bounds()
        self._sequential_fails = 0
        self._max_fails = maximum_failed_solves
        self._input_params = {}
        self._old_input_params = {}
        self.jacobian_scaling_values = None

    def export_config(self):
        export_object = ReaktoroSolverExport()
        export_object.epsilon = self.solver_options.epsilon
        export_object.tolerance = self.solver_options.optima.convergence.tolerance
        export_object.presolve = self.presolve
        export_object.presolve_tolerance = (
            self.presolve_options.optima.convergence.tolerance
        )
        export_object.presolve_epsilon = self.presolve_options.epsilon
        export_object.max_iters = self.solver_options.optima.maxiters
        export_object.presolve_max_iters = self.presolve_options.optima.maxiters
        export_object.hessian_type = self.hessian_type
        export_object.bfgs_initialization_type = self.bfgs_initialization_type
        export_object.bfgs_init_min_hessian_value = self.bfgs_init_min_hessian_value
        export_object.bfgs_init_max_hessian_value = self.bfgs_init_max_hessian_value
        export_object.bfgs_init_const_hessian_value = self.bfgs_init_const_hessian_value
        export_object.bfgs_hessian_memory = self.bfgs_hessian_memory
        export_object.bfgs_epsilon = self.bfgs_epsilon
        export_object.block_name = self.block_name
        return export_object

    def load_from_export_object(self, export_object):
        self.block_name = export_object.block_name
        self.set_solver_options(
            export_object.epsilon,
            export_object.tolerance,
            export_object.presolve,
            export_object.presolve_tolerance,
            export_object.presolve_epsilon,
            export_object.max_iters,
            export_object.presolve_max_iters,
            export_object.hessian_type,
            export_object.bfgs_initialization_type,
            export_object.bfgs_init_min_hessian_value,
            export_object.bfgs_init_max_hessian_value,
            export_object.bfgs_init_const_hessian_value,
            export_object.bfgs_hessian_memory,
            export_object.bfgs_epsilon,
        )

    def equilibrate_state(self):
        self.state.equilibrate_state()

    def display_state(self):
        print(self.state.state)

    def set_solver_options(
        self,
        epsilon=1e-32,
        tolerance=1e-8,
        presolve=False,
        presolve_tolerance=1e-8,
        presolve_epsilon=1e-12,
        max_iters=500,
        presolve_max_iters=500,
        hessian_type="ZeroHessian",
        bfgs_initialization_type="scalar1",
        bfgs_init_min_hessian_value=1e-32,
        bfgs_init_max_hessian_value=1e8,
        bfgs_init_const_hessian_value=1e-16,
        bfgs_hessian_memory=3,
        bfgs_epsilon=1e-12,
    ):
        """configuration for reaktro solver

        Keyword arguments:
        tolerance -- reaktoro solver tolerance (default: 1e-32)
        max_iters -- maxium iterations for reaktoro solver (default: 200)
        presolve -- presolve the model useing "presolve_tolerance" first (default: False)
        presolve_tolerance -- presolve tolerance if enabled (default: 1e-12)
        presolve_max_iters -- maximum iterations for presolve call if enabled (default: 200)
        """
        self.solver_options.epsilon = epsilon
        self.solver_options.optima.maxiters = max_iters
        self.solver_options.optima.convergence.tolerance = tolerance
        self.presolve_options.epsilon = presolve_epsilon
        self.presolve_options.optima.maxiters = presolve_max_iters
        self.presolve_options.optima.convergence.tolerance = presolve_tolerance
        self.presolve = presolve
        self.solver.setOptions(self.solver_options)
        self.hessian_type = hessian_type
        self.bfgs_initialization_type = bfgs_initialization_type
        self.bfgs_init_min_hessian_value = bfgs_init_min_hessian_value
        self.bfgs_init_max_hessian_value = bfgs_init_max_hessian_value
        self.bfgs_init_const_hessian_value = bfgs_init_const_hessian_value
        self.bfgs_hessian_memory = bfgs_hessian_memory
        self.bfgs_epsilon = bfgs_epsilon
        if self.input_specs.assert_charge_neutrality:
            self.conditions.charge(0)

    def set_system_bounds(
        self,
        temperature_bounds=(10, 10000),
        pressure_bounds=(1, 10000),
    ):
        self.conditions.setLowerBoundPressure(pressure_bounds[0])
        self.conditions.setUpperBoundPressure(pressure_bounds[1])
        self.conditions.setLowerBoundTemperature(temperature_bounds[0])
        self.conditions.setUpperBoundTemperature(temperature_bounds[1])

    def set_custom_bound(self, custom_bound, value, index=None):
        # setting custom bounds, eg titrants etc.
        if index == None:
            getattr(self.conditions, custom_bound)(value)
        else:
            getattr(self.conditions, custom_bound)(index, value)

    def update_specs(self, params, use_temp):
        for input_key in self.input_specs.rkt_inputs.rkt_input_list:
            input_obj = self.input_specs.rkt_inputs[input_key]
            if params is None and use_temp is False:
                value = input_obj.get_value(
                    update_temp=True,
                    apply_conversion=True,
                )
            elif use_temp:
                value = input_obj.get_temp_value()
            else:
                value = params.get(input_key)
                input_obj.set_temp_value(value)
            unit = input_obj.main_unit
            self._input_params[input_key] = value
            if input_key == RktInputTypes.temperature:
                self.conditions.temperature(value, unit)
            elif input_key == RktInputTypes.pressure:
                self.conditions.pressure(value, unit)
            elif input_key == RktInputTypes.enthalpy:
                self.conditions.enthalpy(value, unit)
            else:
                # TODO figure out how deal with units...
                self.conditions.set(input_obj.get_rkt_input_name(), value)

    def get_outputs(self):
        output_arr = []
        for key, obj in self.output_specs.rkt_outputs.items():
            val = self.output_specs.evaluate_property(obj, update_values_in_object=True)
            output_arr.append(val)
        return output_arr

    def get_jacobian(self):
        self.tempJacobianMatrix = self.sensitivity.dudw()
        self.jacobian_specs.update_jacobian_absolute_values()
        jac_matrix = []
        for input_key in self.input_specs.rkt_inputs.rkt_input_list:
            input_obj = self.input_specs.rkt_inputs[input_key]
            jac_row = self.jacobian_specs.get_jacobian(
                self.tempJacobianMatrix, input_obj
            )
            jac_matrix.append(jac_row)

        return np.array(jac_matrix).T  # needs to transpose

    def solve_reaktoro_block(
        self,
        params=None,
        use_temp=False,
        display=False,
        presolve=False,
    ):
        # here we solve reaktor model and return the jacobian matrix and solution, as
        # Cell as update relevant reaktoroSpecs
        self.update_specs(params, use_temp)
        solve_failed = False
        try:

            result = self.try_solve(presolve)
            self.outputs = self.get_outputs()
            self.jacobian_matrix = self.get_jacobian()

        except RuntimeError:
            solve_failed = True
        if solve_failed or result.succeeded() == False or display:
            _log.warning(
                f"warning, solve was not successful for {self.block_name}, fail# {self._sequential_fails}"
            )
            _log.warning("----inputs were -----")
            for key, value in self._input_params.items():
                _log.warning(
                    f"{key}: {value}, prior input was: {self._old_input_params.get(key,None)}, delta: {value - self._old_input_params.get(key,0)}"
                )
            self._sequential_fails += 1
            if self._sequential_fails > self._max_fails:
                raise RuntimeError(
                    "Number of failed solves exceed maximum allowed number"
                )
            raise cyipopt.CyIpoptEvaluationError
        else:
            self._sequential_fails = 0
        return self.jacobian_matrix, self.outputs

    def try_solve(self, presolve=False):
        if self.presolve or presolve:
            # solve to loose tolerance first if selected
            self.solver.setOptions(self.presolve_options)
            r = self.solver.solve(
                self.state.state,
                self.sensitivity,
                self.conditions,
            )
            if r.succeeded() == False:
                _log.info(f"presolve {r.succeeded()}")
        self.solver.setOptions(self.solver_options)
        result = self.solver.solve(
            self.state.state,
            self.sensitivity,
            self.conditions,
        )
        self.output_specs.update_supported_props()
        if result.succeeded():
            for input_key, value in self._input_params.items():
                self._old_input_params[input_key] = value
        return result

    def get_jacobian_scaling(self):
        raise NotImplementedError("This method gets updated by ReaktoroBlockBuilder")

    def get_input_scaling(self):
        raise NotImplementedError("This method gets updated by ReaktoroBlockBuilder")
