import hashlib
import json
import subprocess
import tomllib
from pathlib import Path

import pytest
import tomlkit

from protostar.config import ProtostarConfig
from protostar.executor import SystemExecutor
from protostar.manifest import CollisionStrategy, EnvironmentManifest

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def mock_config() -> ProtostarConfig:
    """Provides a fresh baseline configuration for DI injections."""
    return ProtostarConfig()


def test_executor_writes_injected_files(mocker, mock_config):
    """Test that the executor flushes queued file injections to disk."""
    manifest = EnvironmentManifest()
    manifest.add_file_injection(".test_config.yaml", "mock content")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=False)
    mock_mkdir = mocker.patch("protostar.executor.Path.mkdir")
    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._write_injected_files()

    mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)
    mock_write.assert_called_once_with("mock content")


def test_executor_install_dependencies_uv(mocker, mock_config):
    """Test that the executor uses uv add --dev for dev dependencies."""
    manifest = EnvironmentManifest()
    manifest.add_dependency("fastapi")
    manifest.add_dev_dependency("pytest")

    mock_config.python_package_manager = "uv"
    executor = SystemExecutor(manifest, mock_config)

    mock_execute = mocker.patch("protostar.executor.execute_subprocess")
    mocker.patch("protostar.executor.Path.exists", return_value=True)

    executor._install_dependencies()

    mock_execute.assert_any_call(["uv", "add", "fastapi"])
    mock_execute.assert_any_call(["uv", "add", "--dev", "pytest"])


def test_executor_install_dependencies_pip_freeze(
    monkeypatch, mocker, tmp_path, mock_config
):
    """Test that the executor runs a local pip installation and writes a freeze state."""
    monkeypatch.chdir(tmp_path)

    manifest = EnvironmentManifest()
    manifest.add_dependency("dummy-pkg")
    manifest.add_dev_dependency("dev-pkg")

    mock_config.python_package_manager = "pip"
    executor = SystemExecutor(manifest, mock_config)

    mock_execute = mocker.patch("protostar.executor.execute_subprocess")
    mock_run = mocker.patch("protostar.executor.subprocess.run")

    pip_bin = tmp_path / ".venv" / "bin"
    pip_bin.mkdir(parents=True)
    pip_exe = pip_bin / "pip"
    pip_exe.touch()

    mock_run.return_value.stdout = "dummy-pkg==1.0.0\ndev-pkg==2.0.0\n"

    executor._install_dependencies()

    mock_execute.assert_called_once_with(
        [".venv/bin/pip", "install", "dummy-pkg", "dev-pkg"]
    )
    mock_run.assert_called_once_with(
        [".venv/bin/pip", "freeze"], capture_output=True, text=True, check=True
    )

    assert (
        tmp_path / "requirements.txt"
    ).read_text() == "dummy-pkg==1.0.0\ndev-pkg==2.0.0\n"


def test_executor_append_files_late_binding(mocker, mock_config):
    """Test that configuration payloads are interpolated with the active python version."""
    manifest = EnvironmentManifest()
    manifest.add_file_append("pyproject.toml", 'python_version = "{{PYTHON_VERSION}}"')
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mocker.patch(
        "protostar.executor.Path.read_text",
        return_value='[project]\nrequires-python = ">=3.11"\n',
    )

    mock_file = mocker.mock_open(read_data=b'[project]\nrequires-python = ">=3.11"\n')
    mocker.patch("protostar.executor.Path.open", mock_file)
    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._append_files()

    written_data = mock_write.call_args[0][0]
    parsed_toml = tomllib.loads(written_data)

    # Assert structural integrity rather than string presence
    assert parsed_toml["python_version"] == "3.11"


def test_executor_writes_pre_commit_config(mocker, mock_config):
    """Test that the executor concatenates hooks and interpolates Mypy dependencies."""
    manifest = EnvironmentManifest()
    manifest.wants_pre_commit = True
    manifest.add_dependency("fastapi")
    manifest.add_dev_dependency("pytest")

    hook_payload = """  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.19.1
    hooks:
      - id: mypy
        additional_dependencies:
{{MYPY_DEPENDENCIES}}"""
    manifest.add_pre_commit_hook(hook_payload)

    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=False)
    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._write_pre_commit_config()

    written_data = mock_write.call_args[0][0]

    assert "trailing-whitespace" in written_data
    assert "id: mypy" in written_data
    assert "{{MYPY_DEPENDENCIES}}" not in written_data
    assert "- fastapi" in written_data
    assert "- pytest" in written_data


def test_executor_writes_dockerignore(mocker, mock_config):
    """Test that the executor aggregates base ignores and vcs ignores for docker."""
    manifest = EnvironmentManifest()
    manifest.add_vcs_ignore("custom_build_artifact/")
    executor = SystemExecutor(manifest, mock_config, docker=True)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mocker.patch("protostar.executor.Path.read_text", return_value=".env\n")

    mock_file = mocker.mock_open()
    mocker.patch("protostar.executor.Path.open", mock_file)

    executor._write_docker_artifacts()

    written_data = mock_file().write.call_args[0][0]
    assert "custom_build_artifact/" in written_data
    assert ".git/" in written_data
    assert "README*" in written_data


def test_executor_writes_gitignore(mocker, mock_config):
    """Test that .gitignore is safely updated without duplicating existing lines."""
    manifest = EnvironmentManifest()
    manifest.add_vcs_ignore("new_ignore.txt")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mocker.patch(
        "protostar.executor.Path.read_text", return_value="existing_ignore.txt\n"
    )

    mock_file = mocker.mock_open()
    mocker.patch("protostar.executor.Path.open", mock_file)

    executor._write_ignores()
    mock_file().write.assert_called_once_with("new_ignore.txt\n")


def test_executor_writes_vscode_settings(mocker, mock_config):
    """Test that IDE settings merge correctly with existing JSON."""
    manifest = EnvironmentManifest()
    manifest.add_ide_setting("files.exclude", {"**/.venv": True})
    executor = SystemExecutor(manifest, mock_config)

    existing_settings = {"files.exclude": {"**/node_modules": True}}

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mocker.patch(
        "protostar.executor.Path.read_text",
        return_value=json.dumps(existing_settings),
    )
    mock_write_text = mocker.patch("protostar.executor.Path.write_text")
    mocker.patch("protostar.executor.Path.mkdir")

    executor._write_ide_settings()

    written_data = mock_write_text.call_args[0][0]
    parsed_write = json.loads(written_data)

    assert "**/.venv" in parsed_write["files.exclude"]
    assert "**/node_modules" in parsed_write["files.exclude"]


def test_executor_creates_directories(mocker, mock_config):
    """Test that the executor generates all requested workspace directories."""
    manifest = EnvironmentManifest()
    manifest.add_directory("data")
    manifest.add_directory("src/core")
    executor = SystemExecutor(manifest, mock_config)

    mock_mkdir = mocker.patch("protostar.executor.Path.mkdir")

    executor._create_directories()

    assert mock_mkdir.call_count == 2
    mock_mkdir.assert_any_call(parents=True, exist_ok=True)


def test_executor_writes_dockerignore_with_uv(mocker, mock_config):
    """Test that the executor appends .python-version to .dockerignore when uv is used."""
    manifest = EnvironmentManifest()
    manifest.add_system_task(["uv", "init", "--no-workspace", "--bare", "--pin-python"])
    executor = SystemExecutor(manifest, mock_config, docker=True)

    mocker.patch("protostar.executor.Path.exists", return_value=False)
    mock_file = mocker.mock_open()
    mocker.patch("protostar.executor.Path.open", mock_file)

    executor._write_docker_artifacts()

    written_data = mock_file().write.call_args[0][0]
    assert ".python-version" in written_data


def test_executor_append_files_pip_fallback(monkeypatch, tmp_path, mock_config):
    """Test that the executor scrapes pyvenv.cfg if pyproject.toml is missing."""
    monkeypatch.chdir(tmp_path)

    venv_dir = tmp_path / ".venv"
    venv_dir.mkdir()
    (venv_dir / "pyvenv.cfg").write_text("home = /usr/bin\nversion = 3.10.12\n")

    manifest = EnvironmentManifest()
    manifest.add_file_append("pyproject.toml", 'python_version = "{{PYTHON_VERSION}}"')
    executor = SystemExecutor(manifest, mock_config)

    executor._append_files()

    written_data = (tmp_path / "pyproject.toml").read_text()
    parsed_toml = tomllib.loads(written_data)

    # Verify the fallback resolved and injected the correct version structurally
    assert parsed_toml["python_version"] == "3.10"


def test_executor_writes_vscode_settings_jsonc_abort(
    monkeypatch, mocker, tmp_path, mock_config
):
    """Test that IDE settings injection safely aborts if existing JSON has comments."""
    monkeypatch.chdir(tmp_path)

    vscode_dir = tmp_path / ".vscode"
    vscode_dir.mkdir()
    settings_file = vscode_dir / "settings.json"
    settings_file.write_text("// My custom comment\n{}")

    manifest = EnvironmentManifest()
    manifest.add_ide_setting("files.exclude", {"**/.venv": True})
    executor = SystemExecutor(manifest, mock_config)

    mock_print = mocker.patch("protostar.executor.console.print")

    executor._write_ide_settings()

    mock_print.assert_called_once()
    assert (
        "contains comments, trailing commas, or is malformed"
        in mock_print.call_args[0][0]
    )
    assert settings_file.read_text() == "// My custom comment\n{}"


def test_executor_install_dependencies_pip_reqs_exist(
    monkeypatch, mocker, tmp_path, mock_config
):
    """Test that pip freeze skips overwriting an existing requirements.txt."""
    monkeypatch.chdir(tmp_path)

    req_file = tmp_path / "requirements.txt"
    req_file.write_text("my-custom-pkg==1.0.0\n")

    manifest = EnvironmentManifest()
    manifest.add_dependency("dummy-pkg")

    mock_config.python_package_manager = "pip"
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.execute_subprocess")
    mock_run = mocker.patch("protostar.executor.subprocess.run")
    mock_print = mocker.patch("protostar.executor.console.print")

    executor._install_dependencies()

    mock_print.assert_called()
    assert "requirements.txt already exists" in mock_print.call_args[0][0]
    mock_run.assert_not_called()
    assert req_file.read_text() == "my-custom-pkg==1.0.0\n"


def test_executor_writes_injected_files_overwrite(mocker, mock_config):
    """Test that file injections bypass the exists() guard if OVERWRITE is active."""
    manifest = EnvironmentManifest()
    manifest.collision_strategy = CollisionStrategy.OVERWRITE
    manifest.add_file_injection(".test_config.yaml", "new content")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._write_injected_files()
    mock_write.assert_called_once_with("new content")


def test_executor_mkdir_os_error_propagation(mocker, mock_config):
    """Test that the executor correctly propagates OSErrors during directory creation."""
    manifest = EnvironmentManifest()
    manifest.add_directory("protected_dir")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch(
        "protostar.executor.Path.mkdir", side_effect=OSError("Read-only file system")
    )

    with pytest.raises(OSError, match="Read-only file system"):
        executor._create_directories()


def test_executor_write_text_permission_error_propagation(mocker, mock_config):
    """Test that the executor propagates PermissionErrors during file injections."""
    manifest = EnvironmentManifest()
    manifest.add_file_injection("system_config.yaml", "secret")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=False)
    mocker.patch("protostar.executor.Path.mkdir")
    mocker.patch(
        "protostar.executor.Path.write_text",
        side_effect=PermissionError("Permission denied"),
    )

    with pytest.raises(PermissionError, match="Permission denied"):
        executor._write_injected_files()


def test_executor_deep_merge_tomlkit(mock_config):
    """Test the recursive dictionary merge algorithm using chaotic tomlkit structures."""
    manifest = EnvironmentManifest()
    executor = SystemExecutor(manifest, mock_config)

    base_content = (FIXTURES_DIR / "base_complex.toml").read_text()
    payload_content = (FIXTURES_DIR / "payload_complex.toml").read_text()

    base_doc = tomlkit.parse(base_content)
    payload_doc = tomlkit.parse(payload_content)

    executor._deep_merge_tomlkit(base_doc, payload_doc)

    merged_dict = base_doc.unwrap()

    # 1. Verify scalar overrides (line-length changed 120 -> 88)
    assert merged_dict["tool"]["ruff"]["line-length"] == 88

    # 2. Verify non-colliding existing keys were preserved
    assert merged_dict["tool"]["ruff"]["target-version"] == "py310"
    assert merged_dict["project"]["name"] == "protostar-test"

    # 3. Verify nested list replacements
    assert "UP" in merged_dict["tool"]["ruff"]["lint"]["select"]
    assert merged_dict["tool"]["ruff"]["lint"]["ignore"] == []

    # 4. Verify new root tables were injected
    assert merged_dict["tool"]["mypy"]["strict"] is True

    # 5. Verify Array of Tables (AoT) concatenation (MERGE strategy default behavior)
    assert len(merged_dict["tool"]["mypy"]["overrides"]) == 2
    assert merged_dict["tool"]["mypy"]["overrides"][0]["module"] == "tests.*"
    assert merged_dict["tool"]["mypy"]["overrides"][1]["module"] == "legacy_module.*"

    # 6. Verify comments survived the AST manipulation
    dumped = tomlkit.dumps(base_doc)
    assert "# We expect this comment to survive the merge" in dumped
    assert "# A random comment inside an array" in dumped


def test_executor_append_files_ast_merge(mocker, mock_config):
    """Test that _append_files mutates the TOML AST logically based on the MERGE strategy."""
    base_content = (FIXTURES_DIR / "base_complex.toml").read_text()
    payload_content = (FIXTURES_DIR / "payload_complex.toml").read_text()

    manifest = EnvironmentManifest()
    manifest.collision_strategy = CollisionStrategy.MERGE
    manifest.add_file_append("pyproject.toml", payload_content)
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mocker.patch("protostar.executor.Path.read_text", return_value=base_content)

    # mock_open needs to return the pyproject string to resolve the python version
    mock_file = mocker.mock_open(read_data=base_content.encode("utf-8"))
    mocker.patch("protostar.executor.Path.open", mock_file)

    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._append_files()
    written_data = mock_write.call_args[0][0]

    parsed_toml = tomllib.loads(written_data)

    # Verify structural merge logic via the AST
    assert parsed_toml["tool"]["mypy"]["strict"] is True
    assert parsed_toml["tool"]["ruff"]["line-length"] == 88
    assert parsed_toml["tool"]["ruff"]["target-version"] == "py310"  # Preserved!

    # Verify the late-binding variable {{PYTHON_VERSION}} was interpolated correctly
    # based on the `requires-python = ">=3.11"` in base_complex.toml
    assert parsed_toml["tool"]["mypy"]["python_version"] == "3.11"


def test_executor_append_files_ast_overwrite(mocker, mock_config):
    """Test that the OVERWRITE strategy completely replaces colliding TOML tables."""
    base_content = (FIXTURES_DIR / "base_complex.toml").read_text()
    payload_content = (FIXTURES_DIR / "payload_complex.toml").read_text()

    manifest = EnvironmentManifest()
    manifest.collision_strategy = CollisionStrategy.OVERWRITE
    manifest.add_file_append("pyproject.toml", payload_content)
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mocker.patch("protostar.executor.Path.read_text", return_value=base_content)

    mock_file = mocker.mock_open(read_data=base_content.encode("utf-8"))
    mocker.patch("protostar.executor.Path.open", mock_file)

    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._append_files()

    written_data = mock_write.call_args[0][0]
    parsed_toml = tomllib.loads(written_data)

    # Verify the table was entirely replaced in the AST, not just merged
    assert parsed_toml["tool"]["mypy"]["strict"] is True
    assert parsed_toml["tool"]["ruff"]["line-length"] == 88

    # Under OVERWRITE, target-version should have been purged because it existed
    # in the old [tool.ruff] table but not in the payload [tool.ruff] table.
    assert "target-version" not in parsed_toml["tool"]["ruff"]

    # Under OVERWRITE, the original [[tool.mypy.overrides]] should be wiped
    assert len(parsed_toml["tool"]["mypy"]["overrides"]) == 1
    assert parsed_toml["tool"]["mypy"]["overrides"][0]["module"] == "legacy_module.*"


def test_executor_write_pre_commit_config_skips_existing_merge(mocker, mock_config):
    """Test that pre-commit generation aborts if file exists and strategy is not OVERWRITE."""
    manifest = EnvironmentManifest()
    manifest.wants_pre_commit = True
    manifest.collision_strategy = CollisionStrategy.MERGE
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._write_pre_commit_config()
    mock_write.assert_not_called()


def test_executor_write_pre_commit_config_empty_deps(mocker, mock_config):
    """Test that mypy late-binding injects an empty array if no python dependencies exist."""
    manifest = EnvironmentManifest()
    manifest.wants_pre_commit = True
    manifest.pre_commit_hooks.append("id: mypy\n{{MYPY_DEPENDENCIES}}")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=False)
    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._write_pre_commit_config()
    written_data = mock_write.call_args[0][0]
    assert "[]" in written_data


def test_executor_deep_merge_tomlkit_aot_append(mock_config):
    """Test that arrays of tables (AoT) are appended to when not using OVERWRITE."""
    import tomlkit

    manifest = EnvironmentManifest()
    executor = SystemExecutor(manifest, mock_config)

    base = tomlkit.parse("[[my_array]]\nval = 1\n")
    payload = tomlkit.parse("[[my_array]]\nval = 2\n")

    executor._deep_merge_tomlkit(base, payload, overwrite=False)

    result = base.unwrap()
    assert len(result["my_array"]) == 2
    assert result["my_array"][0]["val"] == 1
    assert result["my_array"][1]["val"] == 2


def test_executor_validate_targets_success(mocker, mock_config):
    """Test that pre-execution validation passes silently on valid TOML files."""
    manifest = EnvironmentManifest()
    manifest.add_file_append("pyproject.toml", "[tool.ruff]")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)

    mock_file = mocker.mock_open(read_data=b'[project]\nname = "test"\n')
    mocker.patch("protostar.executor.Path.open", mock_file)

    mock_exit = mocker.patch("protostar.executor.sys.exit")

    executor._validate_targets()
    mock_exit.assert_not_called()


def test_executor_validate_targets_malformed_toml(mocker, mock_config):
    """Test that malformed existing TOML triggers a hard abort during pre-execution validation."""
    manifest = EnvironmentManifest()
    manifest.add_file_append("test.toml", "[section]\nkey = 'val'\n")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)

    mock_file = mocker.mock_open(read_data=b"[invalid toml == \n")
    mocker.patch("protostar.executor.Path.open", mock_file)
    mock_print = mocker.patch("protostar.executor.console.print")

    with pytest.raises(SystemExit) as exc:
        executor._validate_targets()

    assert exc.value.code == 1
    printed = " ".join(str(call.args[0]) for call in mock_print.call_args_list)
    assert "Validation Failure" in printed
    assert "Syntax error in existing workspace file" in printed


def test_executor_append_files_malformed_payload_toml(mocker, mock_config):
    """Test that malformed payload TOML triggers an internal error abort during execution."""
    manifest = EnvironmentManifest()
    manifest.add_file_append("test.toml", "[invalid payload == \n")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mocker.patch(
        "protostar.executor.Path.read_text", return_value="[existing]\nval = 1\n"
    )

    mock_file = mocker.mock_open(read_data=b"[project]\n")
    mocker.patch("protostar.executor.Path.open", mock_file)

    mock_print = mocker.patch("protostar.executor.console.print")

    with pytest.raises(SystemExit) as exc:
        executor._append_files()

    assert exc.value.code == 1
    printed = " ".join(str(call.args[0]) for call in mock_print.call_args_list)
    assert "Internal Error" in printed
    assert "Failed to parse injected TOML payload" in printed


def test_executor_append_files_string_fallback_redundant(mocker, mock_config):
    """Test that the string fallback skips writing if the payload hash is already in the file."""
    payload = "line1\nline2"
    payload_hash = hashlib.md5(payload.encode("utf-8")).hexdigest()[:8]
    existing_content = f"existing\n# --- Protostar Injection: {payload_hash} ---\n{payload}\n# --- End Protostar Injection ---"

    manifest = EnvironmentManifest()
    manifest.add_file_append("test.txt", payload)
    manifest.collision_strategy = CollisionStrategy.MERGE
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.read_text", return_value=existing_content)
    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._append_files()
    mock_write.assert_not_called()


def test_executor_early_returns_on_empty_manifest(mocker, mock_config):
    """Test that functions execute early returns when manifest data is absent."""
    manifest = EnvironmentManifest()
    executor = SystemExecutor(manifest, mock_config)
    mock_exists = mocker.patch("protostar.executor.Path.exists")

    executor._write_ignores()
    executor._write_ide_settings()
    executor._install_dependencies()

    mock_exists.assert_not_called()


def test_executor_install_dependencies_pip_freeze_exception(mocker, mock_config):
    """Test that a pip freeze subprocess crash is gracefully aggregated in warnings."""
    manifest = EnvironmentManifest()
    manifest.dependencies = ["requests"]

    mock_config.python_package_manager = "pip"
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.execute_subprocess")
    mocker.patch("protostar.executor.Path.exists", return_value=False)

    mocker.patch(
        "protostar.executor.subprocess.run",
        side_effect=subprocess.CalledProcessError(1, "pip freeze"),
    )

    executor._install_dependencies()

    assert any(
        "Failed to freeze dependencies to requirements.txt" in w
        for w in executor.warnings
    )


def test_executor_install_dependencies_graceful_degradation_uv(mocker, mock_config):
    """Test that uv resolution failures are appended to warnings without aborting."""
    manifest = EnvironmentManifest()
    manifest.dependencies = ["invalid-pkg"]
    manifest.dev_dependencies = ["invalid-dev-pkg"]

    mock_config.python_package_manager = "uv"
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch(
        "protostar.executor.execute_subprocess",
        side_effect=RuntimeError("Resolution failed"),
    )

    executor._install_dependencies()

    assert len(executor.warnings) == 2
    assert (
        "Standard dependency resolution failed: Resolution failed"
        in executor.warnings[0]
    )
    assert (
        "Development dependency resolution failed: Resolution failed"
        in executor.warnings[1]
    )


def test_executor_install_dependencies_graceful_degradation_pip(mocker, mock_config):
    """Test that pip resolution failures are appended to warnings without aborting."""
    manifest = EnvironmentManifest()
    manifest.dependencies = ["invalid-pkg"]

    mock_config.python_package_manager = "pip"
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch(
        "protostar.executor.execute_subprocess",
        side_effect=RuntimeError("Pip installation failed"),
    )
    mocker.patch("protostar.executor.Path.exists", return_value=True)

    executor._install_dependencies()

    assert len(executor.warnings) == 1
    assert (
        "Pip dependency resolution failed: Pip installation failed"
        in executor.warnings[0]
    )


def test_executor_append_files_pyproject_parse_exception(mocker, mock_config):
    """Test that pyproject.toml parsing failures are caught and logged during late-binding."""
    manifest = EnvironmentManifest()
    manifest.add_file_append("dummy.txt", "content")
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)

    mock_file = mocker.mock_open()
    mocker.patch("protostar.executor.Path.open", mock_file)
    mocker.patch(
        "protostar.executor.tomllib.load",
        side_effect=Exception("Mocked parse error"),
    )

    mock_logger = mocker.patch("protostar.executor.logger.debug")
    mocker.patch("protostar.executor.Path.write_text")

    executor._append_files()

    mock_logger.assert_any_call(
        "Failed to parse pyproject.toml for python version: Mocked parse error"
    )


def test_executor_append_files_string_fallback_append(mocker, mock_config):
    """Test that the string fallback successfully appends missing payloads wrapped in hash markers."""
    manifest = EnvironmentManifest()
    manifest.add_file_append("config.ini", "new_payload_1")
    manifest.add_file_append("config.ini", "new_payload_2")
    manifest.collision_strategy = CollisionStrategy.MERGE
    executor = SystemExecutor(manifest, mock_config)

    mocker.patch("protostar.executor.Path.exists", return_value=True)
    mocker.patch("protostar.executor.Path.read_text", return_value="existing_data")
    mock_write = mocker.patch("protostar.executor.Path.write_text")

    executor._append_files()

    hash1 = hashlib.md5(b"new_payload_1").hexdigest()[:8]
    hash2 = hashlib.md5(b"new_payload_2").hexdigest()[:8]
    expected_data = (
        "existing_data\n\n"
        f"# --- Protostar Injection: {hash1} ---\nnew_payload_1\n# --- End Protostar Injection ---\n\n"
        f"# --- Protostar Injection: {hash2} ---\nnew_payload_2\n# --- End Protostar Injection ---\n"
    )

    written_data = mock_write.call_args[0][0]
    assert written_data == expected_data


def test_executor_deep_merge_tomlkit_table_collision(mock_config):
    """Test that TOML table injections safely skip when colliding with a scalar type."""
    import tomlkit

    manifest = EnvironmentManifest()
    executor = SystemExecutor(manifest, mock_config)

    # Base contains a string where a Table is expected
    base = tomlkit.parse("tool = 'not a table'\n")
    payload = tomlkit.parse("[tool]\nnew_key = 1\n")

    executor._deep_merge_tomlkit(base, payload)

    assert base["tool"] == "not a table"
    assert len(executor.warnings) == 1
    assert "Expected a Table for key 'tool'" in executor.warnings[0]


def test_executor_deep_merge_tomlkit_aot_collision(mock_config):
    """Test that TOML Array of Tables injections safely skip when colliding with a scalar type."""
    import tomlkit

    manifest = EnvironmentManifest()
    executor = SystemExecutor(manifest, mock_config)

    # Base contains a string where an AoT is expected
    base = tomlkit.parse("my_array = 'string'\n")
    payload = tomlkit.parse("[[my_array]]\nval = 1\n")

    executor._deep_merge_tomlkit(base, payload)

    assert base["my_array"] == "string"
    assert len(executor.warnings) == 1
    assert "Expected an Array of Tables for key 'my_array'" in executor.warnings[0]


def test_executor_deep_merge_tomlkit_aot_overwrite(mock_config):
    """Test that the OVERWRITE strategy replaces an entire Array of Tables."""
    import tomlkit

    manifest = EnvironmentManifest()
    executor = SystemExecutor(manifest, mock_config)

    base = tomlkit.parse("[[my_array]]\nval = 1\n")
    payload = tomlkit.parse("[[my_array]]\nval = 2\n")

    executor._deep_merge_tomlkit(base, payload, overwrite=True)

    result = base.unwrap()
    assert len(result["my_array"]) == 1
    assert result["my_array"][0]["val"] == 2


def test_executor_append_files_early_return(mocker, mock_config):
    """Test that _append_files cleanly returns if there are no payloads queued."""
    manifest = EnvironmentManifest()
    executor = SystemExecutor(manifest, mock_config)

    mock_exists = mocker.patch("protostar.executor.Path.exists")
    executor._append_files()

    mock_exists.assert_not_called()


def test_executor_writes_vscode_settings_empty_file(monkeypatch, tmp_path, mock_config):
    """Test that an entirely empty settings.json file is safely initialized as a dictionary."""
    import json

    monkeypatch.chdir(tmp_path)

    vscode_dir = tmp_path / ".vscode"
    vscode_dir.mkdir()
    settings_file = vscode_dir / "settings.json"
    settings_file.write_text("   \n  \t")  # Empty except for whitespace

    manifest = EnvironmentManifest()
    manifest.add_ide_setting("files.exclude", {"**/.venv": True})
    executor = SystemExecutor(manifest, mock_config)

    executor._write_ide_settings()

    written_data = json.loads(settings_file.read_text())
    assert "**/.venv" in written_data["files.exclude"]


def test_executor_writes_vscode_settings_root_not_dict(
    monkeypatch, mocker, tmp_path, mock_config
):
    """Test that a settings.json file containing a non-dict primitive triggers the abort sequence."""
    monkeypatch.chdir(tmp_path)

    vscode_dir = tmp_path / ".vscode"
    vscode_dir.mkdir()
    settings_file = vscode_dir / "settings.json"
    settings_file.write_text('["I am an array, not a dictionary"]')

    manifest = EnvironmentManifest()
    manifest.add_ide_setting("files.exclude", {"**/.venv": True})
    executor = SystemExecutor(manifest, mock_config)

    mock_print = mocker.patch("protostar.executor.console.print")

    executor._write_ide_settings()

    mock_print.assert_called_once()
    assert (
        "contains comments, trailing commas, or is malformed"
        in mock_print.call_args[0][0]
    )
    assert settings_file.read_text() == '["I am an array, not a dictionary"]'


def test_executor_lifecycle_ordering(mocker, mock_config):
    """Test that the executor strictly adheres to the execution DAG order."""
    manifest = EnvironmentManifest()
    executor = SystemExecutor(manifest, mock_config)

    # Use a parent mock to track chronological execution sequence across methods
    manager = mocker.Mock()

    manager.attach_mock(mocker.patch.object(executor, "_execute_tasks"), "sys_tasks")
    manager.attach_mock(
        mocker.patch.object(executor, "_install_dependencies"), "install"
    )
    manager.attach_mock(
        mocker.patch.object(executor, "_execute_post_install_tasks"), "post_install"
    )

    # Silence all other disk I/O mutations
    mocker.patch.object(executor, "_validate_targets")
    mocker.patch.object(executor, "_create_directories")
    mocker.patch.object(executor, "_write_injected_files")
    mocker.patch.object(executor, "_write_pre_commit_config")
    mocker.patch.object(executor, "_append_files")
    mocker.patch.object(executor, "_write_ignores")
    mocker.patch.object(executor, "_write_docker_artifacts")
    mocker.patch.object(executor, "_write_ide_settings")

    executor.execute()

    # Filter calls to isolate our specific topological phases
    actual_calls = [
        call
        for call in manager.mock_calls
        if call[0] in ("sys_tasks", "install", "post_install")
    ]

    expected_call_order = [
        mocker.call.sys_tasks(),
        mocker.call.install(),
        mocker.call.post_install(),
    ]

    assert actual_calls == expected_call_order


def test_executor_execute_post_install_tasks(mocker, mock_config):
    """Test that _execute_post_install_tasks iterates and calls execute_subprocess."""
    manifest = EnvironmentManifest()
    manifest.add_post_install_task(["echo", "first_task"])
    manifest.add_post_install_task(["echo", "second_task"])

    executor = SystemExecutor(manifest, mock_config)

    mock_execute = mocker.patch("protostar.executor.execute_subprocess")

    executor._execute_post_install_tasks()

    # Verify the loop iterated correctly and passed the commands to the system wrapper
    assert mock_execute.call_count == 2
    mock_execute.assert_any_call(["echo", "first_task"])
    mock_execute.assert_any_call(["echo", "second_task"])
