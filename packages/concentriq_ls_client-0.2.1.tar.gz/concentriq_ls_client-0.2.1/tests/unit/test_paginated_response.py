"""Tests for PaginatedResponse."""

from concentriq.models.paginated import PaginatedResponse


class TestPaginatedResponse:
    """Tests for PaginatedResponse behavior."""

    def test_is_a_list(self):
        """PaginatedResponse should behave as a list."""
        items = [{"id": 1}, {"id": 2}]
        result = PaginatedResponse(items)

        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0] == {"id": 1}

    def test_supports_iteration(self):
        """PaginatedResponse should support iteration."""
        items = [{"id": 1}, {"id": 2}, {"id": 3}]
        result = PaginatedResponse(items)

        ids = [item["id"] for item in result]
        assert ids == [1, 2, 3]

    def test_carries_meta(self):
        """PaginatedResponse should carry meta from API response."""
        items = [{"id": 1}]
        meta = {"pagination": {"page": 1, "rowsPerPage": 20, "total": 100}}
        result = PaginatedResponse(items, meta=meta)

        assert result.meta == meta
        assert result.meta["pagination"]["total"] == 100

    def test_meta_defaults_to_empty_dict(self):
        """PaginatedResponse meta should default to empty dict."""
        result = PaginatedResponse([])

        assert result.meta == {}

    def test_equality_with_plain_list(self):
        """PaginatedResponse should be equal to a plain list with same items."""
        items = [{"id": 1}, {"id": 2}]
        result = PaginatedResponse(items)

        assert result == [{"id": 1}, {"id": 2}]

    def test_empty_paginated_response(self):
        """Empty PaginatedResponse should work correctly."""
        result = PaginatedResponse([])

        assert result == []
        assert len(result) == 0
        assert result.meta == {}
