"""Tests for V3 AuditLogs API."""

from pytest_httpx import HTTPXMock

from concentriq import ConcentriqClient
from concentriq.auth import ApiKeyAuth


class TestAuditLogsGetStatus:
    """Tests for AuditLogs.get_status() behavior."""

    def test_get_status_returns_processing_status(self, httpx_mock: HTTPXMock):
        """Get status should return audit log processing status."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/auditLogs/status",
            json={
                "countPending": 42,
                "processedPriorTo": "2024-01-15T10:30:00Z",
                "eventProperties": {"lastProcessedId": 12345},
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.audit_logs.get_status()

        assert result["countPending"] == 42
        assert result["processedPriorTo"] == "2024-01-15T10:30:00Z"
        assert "eventProperties" in result

    def test_get_status_returns_null_when_all_processed(self, httpx_mock: HTTPXMock):
        """Get status should return null processedPriorTo when all events are processed."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/auditLogs/status",
            json={
                "countPending": 0,
                "processedPriorTo": None,
                "eventProperties": {},
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.audit_logs.get_status()

        assert result["countPending"] == 0
        assert result["processedPriorTo"] is None
