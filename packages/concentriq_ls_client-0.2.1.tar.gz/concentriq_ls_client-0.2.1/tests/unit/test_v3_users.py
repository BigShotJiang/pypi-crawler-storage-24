"""Tests for V3 Users API."""

import pytest
from pytest_httpx import HTTPXMock

from concentriq import ConcentriqClient
from concentriq.auth import ApiKeyAuth
from concentriq.exceptions import NotFoundError


class TestUsersGetSettings:
    """Tests for Users.get_settings() behavior."""

    def test_get_settings_returns_user_settings(self, httpx_mock: HTTPXMock):
        """Get settings should return user settings."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/users/123/settings",
            json={
                "theme": "dark",
                "language": "en",
                "notifications": {"email": True, "push": False},
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.users.get_settings(user_id=123)

        assert result["theme"] == "dark"
        assert result["language"] == "en"
        assert result["notifications"]["email"] is True

    def test_get_settings_raises_not_found_for_invalid_user(
        self, httpx_mock: HTTPXMock
    ):
        """Get settings should raise NotFoundError for non-existent user."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/users/999999/settings",
            status_code=404,
            json={"error": "User not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.users.get_settings(user_id=999999)


class TestUsersUpdateSettings:
    """Tests for Users.update_settings() behavior."""

    def test_update_settings_returns_updated_settings(self, httpx_mock: HTTPXMock):
        """Update settings should return the updated settings."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/users/123/settings",
            method="PATCH",
            json={
                "theme": "light",
                "language": "en",
                "notifications": {"email": True, "push": False},
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.users.update_settings(user_id=123, data={"theme": "light"})

        assert result["theme"] == "light"

    def test_update_settings_raises_not_found_for_invalid_user(
        self, httpx_mock: HTTPXMock
    ):
        """Update settings should raise NotFoundError for non-existent user."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/users/999999/settings",
            method="PATCH",
            status_code=404,
            json={"error": "User not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.users.update_settings(user_id=999999, data={"theme": "light"})
