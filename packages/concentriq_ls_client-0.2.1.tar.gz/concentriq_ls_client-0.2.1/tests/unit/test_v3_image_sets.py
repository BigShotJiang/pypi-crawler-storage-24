"""Tests for V3 ImageSets API."""

import pytest
from pytest_httpx import HTTPXMock

from concentriq import ConcentriqClient
from concentriq.auth import ApiKeyAuth
from concentriq.exceptions import NotFoundError


class TestImageSetsGenerateSeed:
    """Tests for ImageSets.generate_seed() behavior."""

    def test_generate_seed_returns_seed_value(self, httpx_mock: HTTPXMock):
        """Generate seed should return a random seed for the image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/123/seed",
            method="POST",
            json={"seed": 42},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.image_sets.generate_seed(image_set_id=123)

        assert result["seed"] == 42

    def test_generate_seed_raises_not_found_for_invalid_image_set(
        self, httpx_mock: HTTPXMock
    ):
        """Generate seed should raise NotFoundError for non-existent image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/999999/seed",
            method="POST",
            status_code=404,
            json={"error": "ImageSet not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.image_sets.generate_seed(image_set_id=999999)


class TestImageSetsGetSeed:
    """Tests for ImageSets.get_seed() behavior."""

    def test_get_seed_returns_existing_seed(self, httpx_mock: HTTPXMock):
        """Get seed should return the user's seed for the image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/123/seed",
            json={"seed": 42},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.image_sets.get_seed(image_set_id=123)

        assert result["seed"] == 42

    def test_get_seed_returns_null_when_not_set(self, httpx_mock: HTTPXMock):
        """Get seed should return null seed when not set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/123/seed",
            json={"seed": None},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.image_sets.get_seed(image_set_id=123)

        assert result["seed"] is None

    def test_get_seed_raises_not_found_for_invalid_image_set(self, httpx_mock: HTTPXMock):
        """Get seed should raise NotFoundError for non-existent image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/999999/seed",
            status_code=404,
            json={"error": "ImageSet not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.image_sets.get_seed(image_set_id=999999)


class TestImageSetsDeleteSeed:
    """Tests for ImageSets.delete_seed() behavior."""

    def test_delete_seed_returns_none(self, httpx_mock: HTTPXMock):
        """Delete seed should return None on success (204 response)."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/123/seed",
            method="DELETE",
            status_code=204,
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.image_sets.delete_seed(image_set_id=123)

        assert result is None

    def test_delete_seed_raises_not_found_for_invalid_image_set(
        self, httpx_mock: HTTPXMock
    ):
        """Delete seed should raise NotFoundError for non-existent image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/999999/seed",
            method="DELETE",
            status_code=404,
            json={"error": "ImageSet not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.image_sets.delete_seed(image_set_id=999999)


class TestImageSetsGetBlinds:
    """Tests for ImageSets.get_blinds() behavior."""

    def test_get_blinds_returns_blind_configuration(self, httpx_mock: HTTPXMock):
        """Get blinds should return blind configuration for the image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/123/blinds",
            json={
                "imageSetId": 123,
                "resourceBlinds": {
                    "Image": {"name": True, "createdAt": False},
                    "Folder": {"name": True},
                },
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.image_sets.get_blinds(image_set_id=123)

        assert result["imageSetId"] == 123
        assert "resourceBlinds" in result
        assert result["resourceBlinds"]["Image"]["name"] is True

    def test_get_blinds_raises_not_found_for_invalid_image_set(
        self, httpx_mock: HTTPXMock
    ):
        """Get blinds should raise NotFoundError for non-existent image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/999999/blinds",
            status_code=404,
            json={"error": "ImageSet not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.image_sets.get_blinds(image_set_id=999999)


class TestImageSetsUpdateBlinds:
    """Tests for ImageSets.update_blinds() behavior."""

    def test_update_blinds_returns_updated_configuration(self, httpx_mock: HTTPXMock):
        """Update blinds should return updated blind configuration."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/123/blinds",
            method="PATCH",
            json={
                "imageSetId": 123,
                "resourceBlinds": {
                    "Image": {"name": True, "createdAt": True},
                },
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.image_sets.update_blinds(
            image_set_id=123,
            data={"resourceBlinds": {"Image": {"name": True, "createdAt": True}}},
        )

        assert result["imageSetId"] == 123
        assert result["resourceBlinds"]["Image"]["createdAt"] is True

    def test_update_blinds_raises_not_found_for_invalid_image_set(
        self, httpx_mock: HTTPXMock
    ):
        """Update blinds should raise NotFoundError for non-existent image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/999999/blinds",
            method="PATCH",
            status_code=404,
            json={"error": "ImageSet not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.image_sets.update_blinds(
                image_set_id=999999,
                data={"resourceBlinds": {"Image": {"name": True}}},
            )


class TestImageSetsDeleteBlinds:
    """Tests for ImageSets.delete_blinds() behavior."""

    def test_delete_blinds_returns_none(self, httpx_mock: HTTPXMock):
        """Delete blinds should return None on success (204 response)."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/123/blinds",
            method="DELETE",
            status_code=204,
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.image_sets.delete_blinds(image_set_id=123)

        assert result is None

    def test_delete_blinds_raises_not_found_for_invalid_image_set(
        self, httpx_mock: HTTPXMock
    ):
        """Delete blinds should raise NotFoundError for non-existent image set."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/imageSets/999999/blinds",
            method="DELETE",
            status_code=404,
            json={"error": "ImageSet not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.image_sets.delete_blinds(image_set_id=999999)
