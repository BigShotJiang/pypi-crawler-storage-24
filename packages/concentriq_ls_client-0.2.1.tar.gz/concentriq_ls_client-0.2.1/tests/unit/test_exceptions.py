"""Tests for Concentriq exceptions."""


from concentriq.exceptions import (
    APIError,
    AuthenticationError,
    AuthorizationError,
    ConcentriqError,
    NotFoundError,
    ServerError,
    ValidationError,
)


class TestConcentriqError:
    """Tests for base ConcentriqError."""

    def test_is_exception(self):
        """ConcentriqError should be an Exception."""
        error = ConcentriqError("test error")
        assert isinstance(error, Exception)

    def test_has_message(self):
        """ConcentriqError should store the error message."""
        error = ConcentriqError("test error")
        assert str(error) == "test error"


class TestAuthenticationError:
    """Tests for AuthenticationError."""

    def test_inherits_from_concentriq_error(self):
        """AuthenticationError should inherit from ConcentriqError."""
        error = AuthenticationError("auth failed")
        assert isinstance(error, ConcentriqError)

    def test_has_message(self):
        """AuthenticationError should store the error message."""
        error = AuthenticationError("invalid credentials")
        assert str(error) == "invalid credentials"


class TestAuthorizationError:
    """Tests for AuthorizationError."""

    def test_inherits_from_concentriq_error(self):
        """AuthorizationError should inherit from ConcentriqError."""
        error = AuthorizationError("forbidden")
        assert isinstance(error, ConcentriqError)

    def test_has_message(self):
        """AuthorizationError should store the error message."""
        error = AuthorizationError("insufficient permissions")
        assert str(error) == "insufficient permissions"


class TestNotFoundError:
    """Tests for NotFoundError."""

    def test_inherits_from_concentriq_error(self):
        """NotFoundError should inherit from ConcentriqError."""
        error = NotFoundError("not found")
        assert isinstance(error, ConcentriqError)

    def test_has_message(self):
        """NotFoundError should store the error message."""
        error = NotFoundError("resource not found")
        assert str(error) == "resource not found"


class TestValidationError:
    """Tests for ValidationError."""

    def test_inherits_from_concentriq_error(self):
        """ValidationError should inherit from ConcentriqError."""
        error = ValidationError("validation failed")
        assert isinstance(error, ConcentriqError)

    def test_has_message(self):
        """ValidationError should store the error message."""
        error = ValidationError("invalid field")
        assert str(error) == "invalid field"


class TestServerError:
    """Tests for ServerError."""

    def test_inherits_from_concentriq_error(self):
        """ServerError should inherit from ConcentriqError."""
        error = ServerError("server error")
        assert isinstance(error, ConcentriqError)

    def test_has_message(self):
        """ServerError should store the error message."""
        error = ServerError("internal server error")
        assert str(error) == "internal server error"


class TestAPIError:
    """Tests for APIError."""

    def test_inherits_from_concentriq_error(self):
        """APIError should inherit from ConcentriqError."""
        error = APIError("api error")
        assert isinstance(error, ConcentriqError)

    def test_basic_message(self):
        """APIError should store the error message."""
        error = APIError("api error")
        assert str(error) == "api error"

    def test_with_status_code(self):
        """APIError should store and display status code."""
        error = APIError("api error", status_code=400)
        assert error.status_code == 400
        assert str(error) == "[400] api error"

    def test_without_status_code(self):
        """APIError without status code should display message only."""
        error = APIError("api error", status_code=None)
        assert error.status_code is None
        assert str(error) == "api error"

    def test_with_response_data(self):
        """APIError should store response data."""
        response_data = {"error": "details", "field": "name"}
        error = APIError("validation error", status_code=422, response_data=response_data)
        assert error.response_data == response_data
        assert error.status_code == 422

    def test_default_response_data(self):
        """APIError should default to empty dict for response_data."""
        error = APIError("api error")
        assert error.response_data == {}
