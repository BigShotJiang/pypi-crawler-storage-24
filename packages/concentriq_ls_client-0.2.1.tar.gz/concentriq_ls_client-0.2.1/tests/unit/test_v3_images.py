"""Tests for V3 Images API."""

import pytest
from pytest_httpx import HTTPXMock

from concentriq import ConcentriqClient
from concentriq.auth import ApiKeyAuth
from concentriq.exceptions import NotFoundError


class TestImagesGet:
    """Tests for Images.get() behavior."""

    def test_get_returns_image_metadata(self, httpx_mock: HTTPXMock):
        """Get should return image metadata by ID."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/images/123",
            json={
                "id": 123,
                "imageSetId": 456,
                "name": "slide001.svs",
                "width": 50000,
                "height": 40000,
                "channels": 3,
                "createdAt": "2024-01-15T10:30:00Z",
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.images.get(id=123)

        assert result["id"] == 123
        assert result["imageSetId"] == 456
        assert result["name"] == "slide001.svs"
        assert result["width"] == 50000

    def test_get_raises_not_found_for_invalid_id(self, httpx_mock: HTTPXMock):
        """Get should raise NotFoundError for non-existent image."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/images/999999",
            status_code=404,
            json={"error": "Image not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.images.get(id=999999)
