"""Tests for V3 AppConfig API."""

import pytest
from pytest_httpx import HTTPXMock

from concentriq import ConcentriqClient
from concentriq.auth import ApiKeyAuth
from concentriq.exceptions import NotFoundError


class TestAppConfigList:
    """Tests for AppConfig.list() behavior."""

    def test_list_returns_app_configs(self, httpx_mock: HTTPXMock):
        """List should return all app configuration settings."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/appConfigs",
            json={
                "items": [
                    {"id": "feature.darkMode", "value": True, "description": "Enable dark mode"},
                    {"id": "feature.newUI", "value": False, "description": "Enable new UI"},
                ],
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.app_config.list()

        assert "items" in result
        assert len(result["items"]) == 2
        assert result["items"][0]["id"] == "feature.darkMode"


class TestAppConfigGet:
    """Tests for AppConfig.get() behavior."""

    def test_get_returns_single_app_config(self, httpx_mock: HTTPXMock):
        """Get should return a single app config by ID."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/appConfigs/feature.darkMode",
            json={
                "id": "feature.darkMode",
                "value": True,
                "description": "Enable dark mode",
                "type": "boolean",
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.app_config.get(id="feature.darkMode")

        assert result["id"] == "feature.darkMode"
        assert result["value"] is True

    def test_get_raises_not_found_for_invalid_id(self, httpx_mock: HTTPXMock):
        """Get should raise NotFoundError for non-existent config."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/appConfigs/invalid.config",
            status_code=404,
            json={"error": "App config not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.app_config.get(id="invalid.config")


class TestAppConfigUpdate:
    """Tests for AppConfig.update() behavior."""

    def test_update_returns_updated_app_config(self, httpx_mock: HTTPXMock):
        """Update should return the updated app config."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/appConfigs/feature.darkMode",
            method="PUT",
            json={
                "id": "feature.darkMode",
                "value": False,
                "description": "Enable dark mode",
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.app_config.update(
            id="feature.darkMode", data={"value": False}
        )

        assert result["id"] == "feature.darkMode"
        assert result["value"] is False

    def test_update_raises_not_found_for_invalid_id(self, httpx_mock: HTTPXMock):
        """Update should raise NotFoundError for non-existent config."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/appConfigs/invalid.config",
            method="PUT",
            status_code=404,
            json={"error": "App config not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.app_config.update(id="invalid.config", data={"value": True})
