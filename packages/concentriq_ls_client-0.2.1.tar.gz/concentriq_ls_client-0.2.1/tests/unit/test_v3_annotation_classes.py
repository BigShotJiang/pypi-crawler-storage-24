"""Tests for V3 AnnotationClasses API."""

import pytest
from pytest_httpx import HTTPXMock

from concentriq import ConcentriqClient
from concentriq.auth import ApiKeyAuth
from concentriq.exceptions import NotFoundError, ValidationError


class TestAnnotationClassesList:
    """Tests for AnnotationClasses.list() behavior."""

    def test_list_returns_annotation_classes(self, httpx_mock: HTTPXMock):
        """List should return all annotation classes."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses",
            json={
                "items": [
                    {"id": 1, "name": "Tumor", "color": "#FF0000"},
                    {"id": 2, "name": "Normal Tissue", "color": "#00FF00"},
                ],
                "total": 2,
            },
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.annotation_classes.list()

        assert "items" in result
        assert len(result["items"]) == 2
        assert result["items"][0]["name"] == "Tumor"
        assert result["total"] == 2


class TestAnnotationClassesGet:
    """Tests for AnnotationClasses.get() behavior."""

    def test_get_returns_single_annotation_class(self, httpx_mock: HTTPXMock):
        """Get should return a single annotation class by ID."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses/123",
            json={"id": 123, "name": "Tumor", "color": "#FF0000", "description": "Tumor regions"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.annotation_classes.get(id=123)

        assert result["id"] == 123
        assert result["name"] == "Tumor"
        assert result["color"] == "#FF0000"

    def test_get_raises_not_found_for_invalid_id(self, httpx_mock: HTTPXMock):
        """Get should raise NotFoundError for non-existent annotation class."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses/999999",
            status_code=404,
            json={"error": "Annotation class not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.annotation_classes.get(id=999999)


class TestAnnotationClassesCreate:
    """Tests for AnnotationClasses.create() behavior."""

    def test_create_returns_created_annotation_class(self, httpx_mock: HTTPXMock):
        """Create should return the newly created annotation class."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses",
            method="POST",
            status_code=201,
            json={"id": 456, "name": "Necrosis", "color": "#000000"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.annotation_classes.create(
            {"name": "Necrosis", "color": "#000000"}
        )

        assert result["id"] == 456
        assert result["name"] == "Necrosis"

    def test_create_raises_validation_error_on_missing_name(
        self, httpx_mock: HTTPXMock
    ):
        """Create should raise ValidationError when name is missing."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses",
            method="POST",
            status_code=400,
            json={"error": "name is required"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(ValidationError):
            client.v3.annotation_classes.create({"color": "#FF0000"})


class TestAnnotationClassesUpdate:
    """Tests for AnnotationClasses.update() behavior."""

    def test_update_returns_updated_annotation_class(self, httpx_mock: HTTPXMock):
        """Update should return the updated annotation class."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses/123",
            method="PUT",
            json={"id": 123, "name": "Updated Tumor", "color": "#FF00FF"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.annotation_classes.update(
            id=123, data={"name": "Updated Tumor", "color": "#FF00FF"}
        )

        assert result["id"] == 123
        assert result["name"] == "Updated Tumor"

    def test_update_raises_not_found_for_invalid_id(self, httpx_mock: HTTPXMock):
        """Update should raise NotFoundError for non-existent annotation class."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses/999999",
            method="PUT",
            status_code=404,
            json={"error": "Annotation class not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.annotation_classes.update(id=999999, data={"name": "New Name"})


class TestAnnotationClassesDelete:
    """Tests for AnnotationClasses.delete() behavior."""

    def test_delete_returns_success(self, httpx_mock: HTTPXMock):
        """Delete should complete successfully."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses/123",
            method="DELETE",
            status_code=204,
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )
        result = client.v3.annotation_classes.delete(id=123)

        assert result is None

    def test_delete_raises_not_found_for_invalid_id(self, httpx_mock: HTTPXMock):
        """Delete should raise NotFoundError for non-existent annotation class."""
        httpx_mock.add_response(
            url="https://test.concentriq.com/api/v3/annotationClasses/999999",
            method="DELETE",
            status_code=404,
            json={"error": "Annotation class not found"},
        )

        client = ConcentriqClient(
            base_url="https://test.concentriq.com", auth=ApiKeyAuth("test-key")
        )

        with pytest.raises(NotFoundError):
            client.v3.annotation_classes.delete(id=999999)
