# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Complete V1 API implementation (`/api/*`) with CRUD operations
  - ImageSets, Images, Folders, Annotations
  - Metadata (Fields and Values)
  - Users, Organizations, Templates, Workflows
  - Orders, Attachments
- Complete V2 API implementation (`/api/v2/*`)
  - UserGroups, Modules, SavedDisplaySettings
- Complete V3 API implementation (`/api/v3/*`)
  - Auth (JWT, API keys)
  - AnnotationClasses, ChannelGroups, AppConfig
  - AuditLogs, Studies, Users (settings)
  - Images, ImageSets (seed and blinds management)
- Multiple authentication methods
  - BasicAuth, ApiKeyAuth, JWTAuth, SessionAuth
- Filter models for V1 resources
  - ImageSetFilters, ImageFilters, FolderFilters
  - MetadataValueFilters, AnnotationFilters
- Comprehensive test coverage (307 unit tests)
- Type hints with mypy support
- Python 3.10+ support

### Design Decisions
- Test-driven development (TDD) approach with RED-GREEN-REFACTOR cycle
- Behavior-focused testing (public API, not implementation)
- Versioned API namespaces (v1, v2, v3)
- Pydantic models for validation and type safety
- Context manager support for client lifecycle

[Unreleased]: https://github.com/Proscia/concentriq-ls-python-client/compare/v0.1.0...HEAD
