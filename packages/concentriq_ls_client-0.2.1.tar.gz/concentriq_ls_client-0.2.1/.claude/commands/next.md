---
description: Pick next feature from TODO.md and start RED phase
---

# Next Feature

Pick the next uncompleted item from TODO.md and start the RED phase.

## Instructions

1. **Read TODO.md** to find the next `[ ]` unchecked item
   - Follow any priority order specified in TODO.md
   - Consider dependencies between features
   - Look for "Next:" hints or phase markers

2. **Read CLAUDE.md** to understand:
   - Project-specific context for this feature
   - Related documentation or reference materials
   - Architectural patterns to follow

3. **Confirm with user** which feature to implement
   - Show the feature description from TODO.md
   - Explain what it does
   - Ask clarifying questions if requirements are unclear

4. **Provide context** for the feature:
   - What problem does it solve?
   - How does it fit into the overall project?
   - What related features exist?
   - Are there any dependencies?

5. **Start RED phase** by writing failing tests

## When Multiple Options Exist

If TODO.md has multiple uncompleted items at the same priority:
- Ask user which one to work on
- Suggest the most logical next step
- Consider dependencies (foundation before features)

## After Selection

Automatically enter RED phase (`/red`) and write tests for the selected feature.
