---
description: Start GREEN phase - Implement code to make tests pass
---

# GREEN Phase: Implementation

You are entering the GREEN phase of TDD. Your task is to write MINIMAL code to make the failing tests pass.

## Instructions

1. **Read CLAUDE.md** to understand:
   - Project structure and file organization
   - Existing patterns to follow
   - Coding standards and conventions
   - How to run tests

2. **Review the failing tests** from RED phase
   - Understand what behavior they're testing
   - Identify all test cases that need to pass

3. **Implement ONLY what's needed** to pass the tests
   - Write the simplest code that works
   - Follow existing patterns in the codebase
   - Don't add features not covered by tests
   - No premature optimization

4. **Run tests frequently** to see progress

5. **Show test output** when all tests pass (GREEN)

6. **Run full test suite** to ensure nothing broke

## Implementation Guidelines

### Minimal Code
- Write the simplest code that makes tests pass
- Don't add "nice to have" features
- Don't over-engineer
- If you're adding code not tested, stop and ask why

### Follow Patterns
- Look at CLAUDE.md for architectural patterns
- Study similar existing implementations
- Match naming conventions
- Follow project structure

### When Stuck
- Re-read the tests - they describe expected behavior
- Look for similar implementations
- Start with the simplest test case first
- Build incrementally

## After Implementation

**Run feature tests** using project's test command (see CLAUDE.md)

Tests MUST pass (GREEN). If they fail, debug and fix.

**Run full test suite** to ensure no regressions.

If all tests pass:
- Update TODO.md (mark feature complete)
- Commit with appropriate message (see CLAUDE.md for format)

## Next Steps

After GREEN phase, you can:
1. `/refactor` - Improve code while keeping tests green (optional)
2. `/next` - Move to next feature in TODO.md
