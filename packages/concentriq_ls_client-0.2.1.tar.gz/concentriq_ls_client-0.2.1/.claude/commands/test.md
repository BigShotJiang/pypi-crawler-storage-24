---
description: Run all tests and show results
---

# Run Tests

Run the full test suite and provide a summary of results.

## Instructions

1. **Read CLAUDE.md** to find the correct test command
   - Different projects use different test runners
   - Check for any special test configurations
   - Note any environment setup required

2. **Run the test suite** using the project's test command

3. **Show test results** with clear summary:
   - Total tests run
   - Passed/failed counts
   - Execution time
   - Any warnings or errors

4. **Report failures** with details if any exist

5. **Show coverage** if requested or if project always shows it

## Success Criteria

✅ **All tests passing** - Ready to move forward
⚠️ **Some tests failing** - Need to fix before proceeding
❌ **Import/syntax errors** - Fix errors and re-run

## After Running Tests

**If all tests pass:**
- Current phase is complete
- Ready for next action:
  - If in GREEN phase: `/refactor` (optional) or `/next`
  - If in REFACTOR phase: `/next`
  - If verifying: Continue with current work

**If tests fail:**
- Review failure messages carefully
- Identify what broke
- Fix the issue
- Re-run: `/test`
