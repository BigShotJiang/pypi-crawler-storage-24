---
description: Start RED phase - Write failing tests for a feature
---

# RED Phase: Test-Driven Development

You are entering the RED phase of TDD. Your task is to write FAILING tests for the feature described by the user.

## Instructions

1. **Read CLAUDE.md** to understand:
   - Project-specific testing patterns
   - What to test (public API vs implementation)
   - Test file locations and naming conventions
   - Mocking strategies

2. **Read TODO.md** to understand:
   - Feature context and requirements
   - Related features
   - Dependencies

3. **Write tests ONLY** - do not implement the feature yet

4. **Test behavior, not implementation**:
   - Test public API methods only
   - Don't test private/internal methods
   - Test observable behavior and outcomes
   - Use descriptive test names that explain expected behavior

5. **Run tests** to confirm they FAIL (RED)

6. **Show test output** to confirm RED phase complete

## General Principles

✅ **Good Tests (Behavior):**
- Does the method return the correct type?
- Does it handle errors appropriately?
- Does it transform data correctly?
- Are parameters validated?
- Does it work with different inputs?

❌ **Bad Tests (Implementation):**
- Testing internal method calls
- Testing how URLs/queries are constructed
- Testing private methods
- Mocking the code you're testing

## After Writing Tests

**Run tests** using the project's test command (see CLAUDE.md)

Tests MUST fail (RED). If they pass, you haven't written the tests correctly or the feature already exists.

Once RED phase is confirmed, user will say `/green` to implement.
