# TDD Slash Commands for Claude Code

Generic, reusable commands for Test-Driven Development.

## Commands

- `/next` - Pick next feature from TODO.md and start RED phase
- `/red` - Write failing tests (RED phase)
- `/green` - Implement to pass tests (GREEN phase)  
- `/test` - Run all tests
- `/refactor` - Improve code quality (optional)

## Setup

1. Copy this entire `.claude/commands/` directory to your project
2. Create `CLAUDE.md` in project root (see `../CLAUDE.md.template`)
3. Create `TODO.md` in project root (see `../TODO.md.template`)

## How It Works

Commands are **generic** - they read context from:
- `CLAUDE.md` - Test patterns, file locations, commands
- `TODO.md` - Feature list and priorities

See `../TDD-COMMANDS-QUICKSTART.md` for full guide.
