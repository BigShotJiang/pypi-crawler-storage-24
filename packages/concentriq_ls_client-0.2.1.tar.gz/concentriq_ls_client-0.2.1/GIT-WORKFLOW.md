# Git Workflow

## Repository Setup (One-time)

### 1. Initialize Repository
```bash
git init
```

### 2. Create Initial Commit on Main (Foundation Only)
Commit only the project foundation:
- `.gitignore`
- `pyproject.toml`
- `README.md`
- `CLAUDE.md`
- Basic directory structure

```bash
git add .gitignore pyproject.toml README.md CLAUDE.md uv.lock
git commit -m "[INIT] Initial project setup with uv and dependencies"
```

### 3. Create Remote Repository
- Create new repository on GitHub: `concentriq-ls-client`
- Do NOT initialize with README/LICENSE/gitignore (we have our own)

### 4. Connect to Remote
```bash
git remote add origin git@github.com:your-org/concentriq-ls-client.git
git branch -M main
git push -u origin main
```

## Feature Development Workflow

### 1. Create Feature Branch
```bash
git checkout -b feature/descriptive-name
```

Branch naming conventions:
- `feature/imageset-api` - New feature
- `fix/auth-headers` - Bug fix
- `refactor/error-handling` - Code refactoring
- `docs/api-examples` - Documentation

### 2. TDD Cycle (RED → GREEN → REFACTOR)

**RED Phase - Write Failing Tests:**
```bash
git add tests/
git commit -m "[RED] Add tests for ImageSetsAPI list and get"
```

**GREEN Phase - Implement Feature:**
```bash
git add src/ tests/
git commit -m "[GREEN] Implement ImageSetsAPI with list() and get() methods

- Add V1API namespace with lazy loading
- Implement ImageSetsAPI.list() with pagination, sorting, filters
- Implement ImageSetsAPI.get() for single resource
- Filters encoded as JSON string for backend compatibility
- All 9 tests passing (62 total)"
```

**REFACTOR Phase (optional):**
```bash
git add src/
git commit -m "[REFACTOR] Extract filter encoding to helper method"
```

### 3. Update Documentation
```bash
git add TODO.md
git commit -m "[DOCS] Update TODO.md - ImageSetsAPI complete (62 tests passing)"
```

### 4. Push Feature Branch
```bash
git push -u origin feature/descriptive-name
```

### 5. Create Pull Request
- Go to GitHub repository
- Click "Compare & pull request"
- Title: Descriptive feature name
- Description:
  - What was implemented
  - Test count
  - Any breaking changes
  - References to issues

### 6. After PR Approval
```bash
# Squash merge on GitHub (preferred)
# OR rebase locally:
git checkout main
git pull origin main
git branch -d feature/descriptive-name
git push origin --delete feature/descriptive-name
```

## Branch Protection Rules

Configure on GitHub:
- ✅ Require pull request before merging
- ✅ Require approvals (1+)
- ✅ Require status checks to pass (CI tests)
- ✅ Require branches to be up to date
- ✅ No direct commits to main

## Commit Message Format

```
[PHASE] Short description (50 chars max)

Optional detailed description:
- Bullet points for changes
- Test counts
- Implementation notes

Closes #issue-number (if applicable)
```

**Phases:**
- `[INIT]` - Initial setup
- `[RED]` - Failing tests (TDD)
- `[GREEN]` - Implementation to pass tests
- `[REFACTOR]` - Code improvements (tests stay green)
- `[DOCS]` - Documentation only
- `[FIX]` - Bug fixes
- `[CHORE]` - Dependency updates, config changes

## Never Commit Directly to Main

❌ **DON'T:**
```bash
git checkout main
git commit -m "Add feature"  # ← NEVER DO THIS
```

✅ **DO:**
```bash
git checkout -b feature/my-feature
git commit -m "[GREEN] Add feature"
# Create PR on GitHub
```

## Current Feature: ImageSetsAPI

Branch: `feature/imageset-api`
Status: Ready for PR
Tests: 62 passing (+9 new)
Files changed:
- `src/concentriq/client.py` - Added v1 property
- `src/concentriq/api/v1/__init__.py` - V1API namespace
- `src/concentriq/api/v1/image_sets.py` - ImageSetsAPI implementation
- `tests/unit/test_image_sets_api.py` - 9 new tests
- `TODO.md` - Updated progress
