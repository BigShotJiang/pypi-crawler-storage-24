# Concentriq LS Python Client - Initial Implementation

Complete Python client library for Proscia Concentriq Life Sciences API with full V1, V2, and V3 API coverage.

## Summary

- **307 tests passing** - Complete unit test coverage
- **All APIs implemented** - V1 (11 resources), V2 (3 resources), V3 (9 resources)
- **Multiple auth methods** - API Key, Basic, JWT, Session
- **Production ready** - Security scanned, documented, CI/CD configured

## Key Features

✅ V1 API - ImageSets, Images, Folders, Annotations, Metadata, Users, Organizations, Templates, Workflows, Orders, Attachments  
✅ V2 API - UserGroups, Modules, SavedDisplaySettings  
✅ V3 API - Auth, Studies, ImageSets (research), AnnotationClasses, ChannelGroups, AppConfig, AuditLogs, Users, Images  
✅ Type-safe filtering with Pydantic models  
✅ Comprehensive documentation ([README](README.md), [Installation](docs/installation.md), [Usage](docs/usage.md), [API Reference](docs/api-reference.md))  
✅ GitHub Actions (test, publish, release-drafter)  
✅ Trivy scan: 0 vulnerabilities  

## Technical Details

**Stack:** Python 3.10+, httpx, Pydantic v2, pytest  
**Architecture:** Versioned namespaces (v1/v2/v3), lazy-loaded resources, context manager support  
**Development:** 85 commits following TDD RED-GREEN-REFACTOR methodology  

## Testing

```bash
uv run pytest tests/unit/ -v  # 307 tests passing
```

## Example Usage

See [docs/usage.md](docs/usage.md) for comprehensive examples.

```python
from concentriq import ConcentriqClient
from concentriq.auth import ApiKeyAuth

with ConcentriqClient(
    base_url="https://app.concentriq.com",
    auth=ApiKeyAuth(api_key="your-key")
) as client:
    image_sets = client.v1.image_sets.list()
    studies = client.v3.studies.list()
```

## Checklist

- [x] All tests passing (307/307)
- [x] Documentation complete
- [x] Security scan clean (Trivy)
- [x] GitHub Actions configured
- [x] Apache 2.0 LICENSE
- [x] CODEOWNERS configured

## Post-Merge

- [ ] Configure Codecov token in GitHub secrets
- [ ] Set up PyPI publishing credentials (optional)
