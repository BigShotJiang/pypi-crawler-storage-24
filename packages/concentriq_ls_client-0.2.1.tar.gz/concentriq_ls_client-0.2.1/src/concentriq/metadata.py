"""Metadata utilities for Concentriq."""

from __future__ import annotations

from typing import Any


class DropdownResolver:
    """Translates between dropdown option text values and numeric IDs.

    Args:
        field: A metadata field definition dict (must have dropdownOptions).

    Example:
        field = client.v1.metadata_fields.get_by_name("Status")
        resolver = DropdownResolver(field)
        resolver.to_id("Active")    # → 10
        resolver.to_value(10)       # → "Active"
    """

    def __init__(self, field: dict[str, Any]) -> None:
        self._field = field
        self._options: list[dict[str, Any]] = field.get("dropdownOptions") or []
        self._value_to_id = {opt["value"]: opt["id"] for opt in self._options}
        self._id_to_value = {opt["id"]: opt["value"] for opt in self._options}

    @property
    def field_name(self) -> str:
        """The name of the metadata field."""
        return self._field["name"]

    @property
    def options(self) -> list[dict[str, Any]]:
        """All dropdown options as id-value dicts."""
        return list(self._options)

    @property
    def values(self) -> list[str]:
        """All dropdown option text values."""
        return list(self._value_to_id.keys())

    def to_id(self, value: str) -> int:
        """Resolve option text to its numeric ID.

        Raises:
            KeyError: If value doesn't match any option.
        """
        return self._value_to_id[value]

    def to_value(self, option_id: int) -> str:
        """Resolve numeric option ID to its text value.

        Raises:
            KeyError: If ID doesn't match any option.
        """
        return self._id_to_value[option_id]
