"""SavedDisplaySettings API client for V2."""

import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class SavedDisplaySettings:
    """Client for SavedImageDisplaySettings resources (/api/v2/savedImageDisplaySettingss).

    Saved display settings for fluorescence microscopy images.
    """

    def __init__(self, client: "ConcentriqClient"):
        """Initialize with client instance.

        Args:
            client: The ConcentriqClient instance
        """
        self._client = client
        self._base_path = "/api/v2/savedImageDisplaySettingss"

    def list(
        self,
        page: int = 0,
        page_size: int = 20,
        order_by: str = "id",
        order_direction: str = "asc",
        filters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """List saved display settings with pagination.

        Args:
            page: Page number (0-indexed, default: 0)
            page_size: Number of items per page (default: 20)
            order_by: Field to order by (default: "id")
            order_direction: Sort direction, "asc" or "desc" (default: "asc")
            filters: Filter criteria (e.g., {"createdBy": 123})

        Returns:
            Dictionary with "results" (list of settings) and "total" count

        Raises:
            AuthenticationError: If not authenticated
        """
        pagination: dict[str, Any] = {
            "page": page,
            "pageSize": page_size,
            "orderBy": order_by,
            "orderDirection": order_direction,
        }
        if filters:
            pagination["filter"] = filters

        params = {"pagination": json.dumps(pagination)}
        response = self._client._request("GET", self._base_path, params=params)
        return response.json()

    def get(self, id: int) -> dict[str, Any]:
        """Get a single saved display setting by ID.

        Args:
            id: Saved display settings ID

        Returns:
            Saved display settings data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If settings don't exist
        """
        response = self._client._request("GET", f"{self._base_path}/{id}")
        return response.json()

    def create(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create new saved display settings.

        Args:
            data: Saved display settings data
                - name: Settings name (required)
                - description: Settings description (optional)
                - fluorescenceChannelsSettings: Array of channel settings (optional)

        Returns:
            Created saved display settings data

        Raises:
            AuthenticationError: If not authenticated
            ValidationError: If required fields are missing
        """
        response = self._client._request("POST", self._base_path, json=data)
        return response.json()

    def update(self, id: int, data: dict[str, Any]) -> dict[str, Any]:
        """Update existing saved display settings.

        Args:
            id: Saved display settings ID
            data: Saved display settings data to update

        Returns:
            Updated saved display settings data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If settings don't exist
        """
        response = self._client._request("PATCH", f"{self._base_path}/{id}", json=data)
        return response.json()

    def delete(self, id: int) -> None:
        """Delete saved display settings.

        Args:
            id: Saved display settings ID

        Returns:
            None

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If settings don't exist
        """
        self._client._request("DELETE", f"{self._base_path}/{id}")
