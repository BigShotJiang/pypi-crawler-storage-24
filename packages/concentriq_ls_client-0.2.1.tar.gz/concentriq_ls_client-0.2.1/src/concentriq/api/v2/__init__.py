"""V2 API namespace."""

from typing import TYPE_CHECKING, Any

from concentriq.api.v2.modules import Modules
from concentriq.api.v2.saved_display_settings import SavedDisplaySettings
from concentriq.api.v2.user_groups import UserGroups

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class V2API:
    """V2 API namespace for /api/v2/* endpoints."""

    def __init__(self, client: "ConcentriqClient"):
        """Initialize V2 API namespace.

        Args:
            client: ConcentriqClient instance
        """
        self._client = client
        self._user_groups: Any = None
        self._modules: Any = None
        self._saved_display_settings: Any = None

    @property
    def user_groups(self) -> UserGroups:
        """Access UserGroups resource."""
        if self._user_groups is None:
            self._user_groups = UserGroups(self._client)
        return self._user_groups

    @property
    def modules(self) -> Modules:
        """Access Modules resource."""
        if self._modules is None:
            self._modules = Modules(self._client)
        return self._modules

    @property
    def saved_display_settings(self) -> SavedDisplaySettings:
        """Access SavedDisplaySettings resource."""
        if self._saved_display_settings is None:
            self._saved_display_settings = SavedDisplaySettings(self._client)
        return self._saved_display_settings
