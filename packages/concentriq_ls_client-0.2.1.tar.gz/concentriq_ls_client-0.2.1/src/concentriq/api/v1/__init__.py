"""V1 API namespace."""

from typing import TYPE_CHECKING, Any

from concentriq.api.v1.annotations import Annotations
from concentriq.api.v1.attachments import Attachments
from concentriq.api.v1.folders import Folders
from concentriq.api.v1.image_sets import ImageSets
from concentriq.api.v1.images import Images
from concentriq.api.v1.metadata_fields import MetadataFields
from concentriq.api.v1.metadata_values import MetadataValues
from concentriq.api.v1.orders import Orders
from concentriq.api.v1.organizations import Organizations
from concentriq.api.v1.templates import Templates
from concentriq.api.v1.users import Users
from concentriq.api.v1.workflows import Workflows

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class V1API:
    """V1 API namespace for /api/* endpoints."""

    def __init__(self, client: "ConcentriqClient"):
        """Initialize V1 API namespace.

        Args:
            client: ConcentriqClient instance
        """
        self._client = client
        self._annotations: Any = None
        self._attachments: Any = None
        self._folders: Any = None
        self._image_sets: Any = None
        self._images: Any = None
        self._metadata_fields: Any = None
        self._metadata_values: Any = None
        self._orders: Any = None
        self._organizations: Any = None
        self._templates: Any = None
        self._users: Any = None
        self._workflows: Any = None

    @property
    def annotations(self) -> Annotations:
        """Access Annotations resource."""
        if self._annotations is None:
            self._annotations = Annotations(self._client)
        return self._annotations

    @property
    def attachments(self) -> Attachments:
        """Access Attachments resource."""
        if self._attachments is None:
            self._attachments = Attachments(self._client)
        return self._attachments

    @property
    def folders(self) -> Folders:
        """Access Folders resource."""
        if self._folders is None:
            self._folders = Folders(self._client)
        return self._folders

    @property
    def image_sets(self) -> ImageSets:
        """Access ImageSets resource."""
        if self._image_sets is None:
            self._image_sets = ImageSets(self._client)
        return self._image_sets

    @property
    def images(self) -> Images:
        """Access Images resource."""
        if self._images is None:
            self._images = Images(self._client)
        return self._images

    @property
    def metadata_fields(self) -> MetadataFields:
        """Access MetadataFields resource."""
        if self._metadata_fields is None:
            self._metadata_fields = MetadataFields(self._client)
        return self._metadata_fields

    @property
    def metadata_values(self) -> MetadataValues:
        """Access MetadataValues resource."""
        if self._metadata_values is None:
            self._metadata_values = MetadataValues(self._client)
        return self._metadata_values

    @property
    def organizations(self) -> Organizations:
        """Access Organizations resource."""
        if self._organizations is None:
            self._organizations = Organizations(self._client)
        return self._organizations

    @property
    def templates(self) -> Templates:
        """Access Templates resource."""
        if self._templates is None:
            self._templates = Templates(self._client)
        return self._templates

    @property
    def orders(self) -> Orders:
        """Access Orders resource."""
        if self._orders is None:
            self._orders = Orders(self._client)
        return self._orders

    @property
    def users(self) -> Users:
        """Access Users resource."""
        if self._users is None:
            self._users = Users(self._client)
        return self._users

    @property
    def workflows(self) -> Workflows:
        """Access Workflows resource."""
        if self._workflows is None:
            self._workflows = Workflows(self._client)
        return self._workflows
