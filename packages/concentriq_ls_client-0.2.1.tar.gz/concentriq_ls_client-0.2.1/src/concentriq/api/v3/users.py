"""Users API client for V3."""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class Users:
    """Client for User resources (/api/v3/users).

    V3 Users API only manages user settings.
    Note: User CRUD operations are handled in V1 API.
    """

    def __init__(self, client: "ConcentriqClient"):
        """Initialize with client instance.

        Args:
            client: The ConcentriqClient instance
        """
        self._client = client
        self._base_path = "/api/v3/users"

    def get_settings(self, user_id: int) -> dict[str, Any]:
        """Get user settings.

        Args:
            user_id: User ID

        Returns:
            User settings data (theme, language, notifications, etc.)

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If user doesn't exist
        """
        response = self._client._request("GET", f"{self._base_path}/{user_id}/settings")
        return response.json()

    def update_settings(self, user_id: int, data: dict[str, Any]) -> dict[str, Any]:
        """Update user settings.

        Uses PATCH method to partially update settings.

        Args:
            user_id: User ID
            data: Settings data to update (e.g., {"theme": "dark"})

        Returns:
            Updated user settings data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If user doesn't exist
        """
        response = self._client._request(
            "PATCH", f"{self._base_path}/{user_id}/settings", json=data
        )
        return response.json()
