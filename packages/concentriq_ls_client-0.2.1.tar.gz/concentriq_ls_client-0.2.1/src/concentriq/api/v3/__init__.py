"""V3 API namespace."""

from typing import TYPE_CHECKING, Any

from concentriq.api.v3.annotation_classes import AnnotationClasses
from concentriq.api.v3.app_config import AppConfig
from concentriq.api.v3.audit_logs import AuditLogs
from concentriq.api.v3.auth import Auth
from concentriq.api.v3.channel_groups import ChannelGroups
from concentriq.api.v3.files import Files
from concentriq.api.v3.image_sets import ImageSets
from concentriq.api.v3.images import Images
from concentriq.api.v3.studies import Studies
from concentriq.api.v3.users import Users

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class V3API:
    """V3 API namespace for /api/v3/* endpoints."""

    def __init__(self, client: "ConcentriqClient"):
        """Initialize V3 API namespace.

        Args:
            client: ConcentriqClient instance
        """
        self._client = client
        self._auth: Any = None
        self._annotation_classes: Any = None
        self._channel_groups: Any = None
        self._app_config: Any = None
        self._audit_logs: Any = None
        self._studies: Any = None
        self._users: Any = None
        self._images: Any = None
        self._image_sets: Any = None
        self._files: Any = None

    @property
    def auth(self) -> Auth:
        """Access Auth resource."""
        if self._auth is None:
            self._auth = Auth(self._client)
        return self._auth

    @property
    def annotation_classes(self) -> AnnotationClasses:
        """Access AnnotationClasses resource."""
        if self._annotation_classes is None:
            self._annotation_classes = AnnotationClasses(self._client)
        return self._annotation_classes

    @property
    def channel_groups(self) -> ChannelGroups:
        """Access ChannelGroups resource."""
        if self._channel_groups is None:
            self._channel_groups = ChannelGroups(self._client)
        return self._channel_groups

    @property
    def app_config(self) -> AppConfig:
        """Access AppConfig resource."""
        if self._app_config is None:
            self._app_config = AppConfig(self._client)
        return self._app_config

    @property
    def audit_logs(self) -> AuditLogs:
        """Access AuditLogs resource."""
        if self._audit_logs is None:
            self._audit_logs = AuditLogs(self._client)
        return self._audit_logs

    @property
    def studies(self) -> Studies:
        """Access Studies resource."""
        if self._studies is None:
            self._studies = Studies(self._client)
        return self._studies

    @property
    def users(self) -> Users:
        """Access Users resource."""
        if self._users is None:
            self._users = Users(self._client)
        return self._users

    @property
    def images(self) -> Images:
        """Access Images resource."""
        if self._images is None:
            self._images = Images(self._client)
        return self._images

    @property
    def files(self) -> Files:
        """Access Files resource (upload operations)."""
        if self._files is None:
            self._files = Files(self._client)
        return self._files

    @property
    def image_sets(self) -> ImageSets:
        """Access ImageSets resource."""
        if self._image_sets is None:
            self._image_sets = ImageSets(self._client)
        return self._image_sets
