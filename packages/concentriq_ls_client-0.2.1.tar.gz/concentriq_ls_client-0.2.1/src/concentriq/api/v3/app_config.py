"""AppConfig API client for V3."""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class AppConfig:
    """Client for AppConfig resources (/api/v3/appConfigs).

    Application configuration settings and feature flags.
    Note: AppConfig only supports list, get, and update operations (no create/delete).
    """

    def __init__(self, client: "ConcentriqClient"):
        """Initialize with client instance.

        Args:
            client: The ConcentriqClient instance
        """
        self._client = client
        self._base_path = "/api/v3/appConfigs"

    def list(self) -> dict[str, Any]:
        """List all application configuration settings.

        Returns:
            Dictionary with "items" (list of app configs)

        Raises:
            AuthenticationError: If not authenticated
        """
        response = self._client._request("GET", self._base_path)
        return response.json()

    def get(self, id: str) -> dict[str, Any]:
        """Get application config by ID.

        Args:
            id: Config ID (e.g., "feature.darkMode")

        Returns:
            App config data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If config doesn't exist
        """
        response = self._client._request("GET", f"{self._base_path}/{id}")
        return response.json()

    def update(self, id: str, data: dict[str, Any]) -> dict[str, Any]:
        """Update application config.

        Args:
            id: Config ID (e.g., "feature.darkMode")
            data: Config data to update (typically {"value": ...})

        Returns:
            Updated app config data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If config doesn't exist
        """
        response = self._client._request("PUT", f"{self._base_path}/{id}", json=data)
        return response.json()
