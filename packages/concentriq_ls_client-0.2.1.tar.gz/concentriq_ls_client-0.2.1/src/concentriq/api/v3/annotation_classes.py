"""AnnotationClasses API client for V3."""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class AnnotationClasses:
    """Client for AnnotationClass resources (/api/v3/annotationClasses).

    Annotation classes define categories for annotations (e.g., Tumor, Normal Tissue).
    """

    def __init__(self, client: "ConcentriqClient"):
        """Initialize with client instance.

        Args:
            client: The ConcentriqClient instance
        """
        self._client = client
        self._base_path = "/api/v3/annotationClasses"

    def list(self) -> dict[str, Any]:
        """List all annotation classes.

        Returns:
            Dictionary with "items" (list of annotation classes) and "total"

        Raises:
            AuthenticationError: If not authenticated
        """
        response = self._client._request("GET", self._base_path)
        return response.json()

    def get(self, id: int) -> dict[str, Any]:
        """Get annotation class by ID.

        Args:
            id: Annotation class ID

        Returns:
            Annotation class data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If annotation class doesn't exist
        """
        response = self._client._request("GET", f"{self._base_path}/{id}")
        return response.json()

    def create(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create annotation class.

        Args:
            data: Annotation class data
                - name: Class name (required)
                - color: Color hex code (optional)
                - description: Description (optional)

        Returns:
            Created annotation class data

        Raises:
            AuthenticationError: If not authenticated
            ValidationError: If required fields are missing
        """
        response = self._client._request("POST", self._base_path, json=data)
        return response.json()

    def update(self, id: int, data: dict[str, Any]) -> dict[str, Any]:
        """Update annotation class.

        Args:
            id: Annotation class ID
            data: Annotation class data to update

        Returns:
            Updated annotation class data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If annotation class doesn't exist
        """
        response = self._client._request("PUT", f"{self._base_path}/{id}", json=data)
        return response.json()

    def delete(self, id: int) -> None:
        """Delete annotation class.

        Args:
            id: Annotation class ID

        Returns:
            None

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If annotation class doesn't exist
        """
        self._client._request("DELETE", f"{self._base_path}/{id}")
