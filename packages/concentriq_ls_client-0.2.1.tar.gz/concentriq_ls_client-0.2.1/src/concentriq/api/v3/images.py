"""Images API client for V3."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class Images:
    """Client for Image resources (/api/v3/images).

    V3 Images API only supports get operation.
    Note: List and CRUD operations are handled in V1 API.
    """

    def __init__(self, client: "ConcentriqClient"):
        """Initialize with client instance.

        Args:
            client: The ConcentriqClient instance
        """
        self._client = client
        self._base_path = "/api/v3/images"

    def get(self, id: int) -> dict[str, Any]:
        """Get image by ID.

        Args:
            id: Image ID

        Returns:
            Image metadata

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If image doesn't exist
        """
        response = self._client._request("GET", f"{self._base_path}/{id}")
        return response.json()
