"""ImageSets API client for V3."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class ImageSets:
    """Client for ImageSet resources (/api/v3/imageSets).

    V3 ImageSets API provides seed and blinds management for research studies.
    Note: Standard CRUD operations are handled in V1 API.
    """

    def __init__(self, client: "ConcentriqClient"):
        """Initialize with client instance.

        Args:
            client: The ConcentriqClient instance
        """
        self._client = client
        self._base_path = "/api/v3/imageSets"

    def generate_seed(self, image_set_id: int) -> dict[str, Any]:
        """Generate random seed for image set.

        Creates and returns a random seed for the given image set and user.
        Used for randomizing image order in research studies.

        Args:
            image_set_id: Image set ID

        Returns:
            Dictionary with "seed" key containing the generated seed value

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If image set doesn't exist
        """
        response = self._client._request("POST", f"{self._base_path}/{image_set_id}/seed")
        return response.json()

    def get_seed(self, image_set_id: int) -> dict[str, Any]:
        """Get user's seed for image set.

        Returns the randomization seed for the authenticated user and the given
        image set. Returns None if no seed has been generated.

        Args:
            image_set_id: Image set ID

        Returns:
            Dictionary with "seed" key (can be None if not set)

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If image set doesn't exist
        """
        response = self._client._request("GET", f"{self._base_path}/{image_set_id}/seed")
        return response.json()

    def delete_seed(self, image_set_id: int) -> None:
        """Delete user's seed for image set.

        Deletes the randomization seed for the authenticated user and the given
        image set.

        Args:
            image_set_id: Image set ID

        Returns:
            None

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If image set doesn't exist
        """
        self._client._request("DELETE", f"{self._base_path}/{image_set_id}/seed")

    def get_blinds(self, image_set_id: int) -> dict[str, Any]:
        """Get blind configuration for image set.

        Retrieves metadata field blinds and resource column blinds for the given
        image set. Used for blinding sensitive information in research studies.

        Args:
            image_set_id: Image set ID

        Returns:
            Blind configuration with imageSetId and resourceBlinds

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If image set doesn't exist
        """
        response = self._client._request("GET", f"{self._base_path}/{image_set_id}/blinds")
        return response.json()

    def update_blinds(self, image_set_id: int, data: dict[str, Any]) -> dict[str, Any]:
        """Update blind configuration for image set.

        Updates metadata field blinds and resource column blinds for the given
        image set. Uses PATCH method to partially update configuration.

        Args:
            image_set_id: Image set ID
            data: Blind configuration data (e.g., {"resourceBlinds": {...}})

        Returns:
            Updated blind configuration

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If image set doesn't exist
        """
        response = self._client._request(
            "PATCH", f"{self._base_path}/{image_set_id}/blinds", json=data
        )
        return response.json()

    def delete_blinds(self, image_set_id: int) -> None:
        """Delete blind configuration for image set.

        Deletes metadata field blinds and resource column blinds for the given
        image set.

        Args:
            image_set_id: Image set ID

        Returns:
            None

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If image set doesn't exist
        """
        self._client._request("DELETE", f"{self._base_path}/{image_set_id}/blinds")
