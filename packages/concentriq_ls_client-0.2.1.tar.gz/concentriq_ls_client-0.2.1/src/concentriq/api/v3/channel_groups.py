"""ChannelGroups API client for V3."""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class ChannelGroups:
    """Client for ChannelGroup resources (/api/v3/channelGroups).

    Channel groups define collections of fluorescence channels (e.g., DAPI, FITC).
    """

    def __init__(self, client: "ConcentriqClient"):
        """Initialize with client instance.

        Args:
            client: The ConcentriqClient instance
        """
        self._client = client
        self._base_path = "/api/v3/channelGroups"

    def list(self) -> dict[str, Any]:
        """List all channel groups.

        Returns:
            Dictionary with "items" (list of channel groups) and "total"

        Raises:
            AuthenticationError: If not authenticated
        """
        response = self._client._request("GET", self._base_path)
        return response.json()

    def get(self, id: int) -> dict[str, Any]:
        """Get channel group by ID.

        Args:
            id: Channel group ID

        Returns:
            Channel group data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If channel group doesn't exist
        """
        response = self._client._request("GET", f"{self._base_path}/{id}")
        return response.json()

    def create(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create channel group.

        Args:
            data: Channel group data
                - name: Group name (required)
                - channels: List of channel names (optional)
                - description: Description (optional)

        Returns:
            Created channel group data

        Raises:
            AuthenticationError: If not authenticated
            ValidationError: If required fields are missing
        """
        response = self._client._request("POST", self._base_path, json=data)
        return response.json()

    def update(self, id: int, data: dict[str, Any]) -> dict[str, Any]:
        """Update channel group.

        Args:
            id: Channel group ID
            data: Channel group data to update

        Returns:
            Updated channel group data

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If channel group doesn't exist
        """
        response = self._client._request("PUT", f"{self._base_path}/{id}", json=data)
        return response.json()

    def delete(self, id: int) -> None:
        """Delete channel group.

        Args:
            id: Channel group ID

        Returns:
            None

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If channel group doesn't exist
        """
        self._client._request("DELETE", f"{self._base_path}/{id}")

    def add_to_repo(self, channel_group_id: int, repo_id: int) -> dict[str, Any]:
        """Add channel group to a repository.

        Args:
            channel_group_id: Channel group ID
            repo_id: Repository ID

        Returns:
            Success response with channelGroupId and repoId

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If channel group or repository doesn't exist
        """
        response = self._client._request(
            "POST", f"{self._base_path}/{channel_group_id}/repos/{repo_id}"
        )
        return response.json()

    def remove_from_repo(self, channel_group_id: int, repo_id: int) -> dict[str, Any]:
        """Remove channel group from a repository.

        Args:
            channel_group_id: Channel group ID
            repo_id: Repository ID

        Returns:
            Success response with channelGroupId and repoId

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If channel group or repository doesn't exist
        """
        response = self._client._request(
            "DELETE", f"{self._base_path}/{channel_group_id}/repos/{repo_id}"
        )
        return response.json()
