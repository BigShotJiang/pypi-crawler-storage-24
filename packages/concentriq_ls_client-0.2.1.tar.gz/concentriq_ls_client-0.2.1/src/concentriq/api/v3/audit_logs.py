"""AuditLogs API client for V3."""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from concentriq.client import ConcentriqClient


class AuditLogs:
    """Client for AuditLog resources (/api/v3/auditLogs).

    Audit logs track system events and user actions.
    Note: AuditLogs API is read-only and specialized for audit log queries.
    """

    def __init__(self, client: "ConcentriqClient"):
        """Initialize with client instance.

        Args:
            client: The ConcentriqClient instance
        """
        self._client = client
        self._base_path = "/api/v3/auditLogs"

    def get_status(self) -> dict[str, Any]:
        """Get audit log processing status.

        Returns a summary of the audit log processing status including
        the number of pending events and the timestamp of the oldest
        unprocessed event.

        Returns:
            Dictionary with:
                - countPending: Number of unconsumed events pending
                - processedPriorTo: Timestamp of oldest unprocessed event (null if all processed)
                - eventProperties: Additional event metadata

        Raises:
            AuthenticationError: If not authenticated
        """
        response = self._client._request("GET", f"{self._base_path}/status")
        return response.json()
