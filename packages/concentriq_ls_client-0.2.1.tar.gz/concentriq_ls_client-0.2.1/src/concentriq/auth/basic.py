"""Basic authentication handler."""

import base64

from concentriq.auth.base import AuthHandler


class BasicAuth(AuthHandler):
    """HTTP Basic authentication handler.

    Args:
        username: Username for authentication
        password: Password for authentication

    Raises:
        ValueError: If username or password is empty
    """

    def __init__(self, username: str, password: str):
        if not username:
            raise ValueError("Username cannot be empty")
        if not password:
            raise ValueError("Password cannot be empty")

        self.username = username
        self.password = password

    def get_headers(self) -> dict[str, str]:
        """Generate HTTP Basic authentication header.

        Returns:
            Dictionary with Authorization header
        """
        credentials = f"{self.username}:{self.password}"
        encoded = base64.b64encode(credentials.encode("utf-8")).decode("ascii")
        return {"Authorization": f"Basic {encoded}"}
