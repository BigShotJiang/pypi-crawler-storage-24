"""Session cookie authentication handler."""

from concentriq.auth.base import AuthHandler


class SessionAuth(AuthHandler):
    """Session cookie authentication handler.

    Args:
        session_cookie: The session cookie value
        cookie_name: The name of the session cookie (default: connect.sid)

    Raises:
        ValueError: If session_cookie is empty
    """

    def __init__(self, session_cookie: str, cookie_name: str = "connect.sid"):
        if not session_cookie:
            raise ValueError("Session cookie cannot be empty")

        self.session_cookie = session_cookie
        self.cookie_name = cookie_name

    def get_headers(self) -> dict[str, str]:
        """Generate Cookie header.

        Returns:
            Dictionary with Cookie header
        """
        return {"Cookie": f"{self.cookie_name}={self.session_cookie}"}
