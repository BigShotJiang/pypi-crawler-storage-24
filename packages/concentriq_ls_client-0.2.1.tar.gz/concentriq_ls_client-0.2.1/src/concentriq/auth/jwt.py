"""JWT Bearer token authentication handler."""

from concentriq.auth.base import AuthHandler


class JWTAuth(AuthHandler):
    """JWT Bearer token authentication handler.

    Args:
        token: The JWT token for authentication

    Raises:
        ValueError: If token is empty
    """

    def __init__(self, token: str):
        if not token:
            raise ValueError("Token cannot be empty")

        self.token = token

    def get_headers(self) -> dict[str, str]:
        """Generate Bearer token authorization header.

        Returns:
            Dictionary with Authorization header
        """
        return {"Authorization": f"Bearer {self.token}"}
