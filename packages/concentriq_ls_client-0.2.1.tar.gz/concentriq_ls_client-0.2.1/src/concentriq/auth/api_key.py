"""API Key authentication handler."""

from concentriq.auth.base import AuthHandler


class ApiKeyAuth(AuthHandler):
    """API Key authentication handler.

    Args:
        api_key: The API key for authentication

    Raises:
        ValueError: If api_key is empty
    """

    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("API key cannot be empty")

        self.api_key = api_key

    def get_headers(self) -> dict[str, str]:
        """Generate API key header.

        Returns:
            Dictionary with concentriq-api-key header
        """
        return {"concentriq-api-key": self.api_key}
