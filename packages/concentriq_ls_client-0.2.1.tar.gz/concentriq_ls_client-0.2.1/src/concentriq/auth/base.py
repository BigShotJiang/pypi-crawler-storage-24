"""Base authentication handler."""

from abc import ABC, abstractmethod


class AuthHandler(ABC):
    """Base class for authentication handlers."""

    @abstractmethod
    def get_headers(self) -> dict[str, str]:
        """Return authentication headers to be added to requests.

        Returns:
            Dictionary of HTTP headers for authentication.
        """
        pass
