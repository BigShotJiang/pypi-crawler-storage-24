"""Exceptions for the Concentriq LS API client."""

from typing import Any, Optional


class ConcentriqError(Exception):
    """Base exception for all Concentriq client errors."""

    pass


class AuthenticationError(ConcentriqError):
    """Raised when authentication fails."""

    pass


class AuthorizationError(ConcentriqError):
    """Raised when the user lacks permission for the requested operation."""

    pass


class NotFoundError(ConcentriqError):
    """Raised when a requested resource is not found (404)."""

    pass


class ValidationError(ConcentriqError):
    """Raised when request validation fails (400/422)."""

    pass


class ServerError(ConcentriqError):
    """Raised when the server encounters an error (5xx)."""

    pass


class APIError(ConcentriqError):
    """Generic API error with status code and response details."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data or {}

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {super().__str__()}"
        return super().__str__()
