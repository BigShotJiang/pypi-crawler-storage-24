# -*- coding: utf-8 -*-
"""
Markdown → Qt widgets renderer for AI Chat responses. (C) 2026 by Maciej Piecko

Supported elements:
  - Headings (#, ##, ###)
  - Bold (**text** or __text__)
  - Italic (*text* or _text_)
  - Bold+Italic (***text***)
  - Inline code (`code`)
  - Fenced code blocks (```lang ... ```)
  - Bullet lists (-, *, +)
  - Numbered lists (1. 2. etc.)
  - Blockquotes (> text)
  - Horizontal rules (--- or ***)
  - Tables (| col | col |)
  - Strikethrough (~~text~~)
  - Links ([text](url))
  - Plain paragraphs
"""

import re
from qtpy.QtCore import Qt, Signal, QPoint, QTimer
from qtpy.QtGui import QFont, QColor
from qtpy.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QSizePolicy, QGridLayout, QScrollArea,
)


# ---------------------------------------------------------------------------
# Inline markdown → HTML  (used inside QLabel with RichText)
# ---------------------------------------------------------------------------
def _inline_to_html(text):
    """Convert inline markdown to HTML for use in a QLabel."""
    # Escape HTML special chars first (except we'll add our own tags)
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    # Bold + Italic: ***text*** or ___text___
    text = re.sub(r'\*{3}(.+?)\*{3}', r'<b><i>\1</i></b>', text)
    text = re.sub(r'_{3}(.+?)_{3}',   r'<b><i>\1</i></b>', text)

    # Bold: **text** or __text__
    text = re.sub(r'\*{2}(.+?)\*{2}', r'<b>\1</b>', text)
    text = re.sub(r'_{2}(.+?)_{2}',   r'<b>\1</b>', text)

    # Italic: *text* or _text_  (not inside words)
    text = re.sub(r'(?<!\w)\*(.+?)\*(?!\w)', r'<i>\1</i>', text)
    text = re.sub(r'(?<!\w)_(.+?)_(?!\w)',   r'<i>\1</i>', text)

    # Strikethrough: ~~text~~
    text = re.sub(r'~~(.+?)~~', r'<s>\1</s>', text)

    # Inline code: ``code`` (double backtick) — must come before single
    text = re.sub(r'``([^`]+?)``',
                  r'<code style="background:#1e1e1e;color:#d4d4d4;'
                  r'padding:1px 4px;border-radius:3px;">\1</code>', text)
    # Inline code: `code` (single backtick)
    text = re.sub(r'`([^`]+)`',
                  r'<code style="background:#1e1e1e;color:#d4d4d4;'
                  r'padding:1px 4px;border-radius:3px;">\1</code>', text)

    # Links: [text](url)
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)',
                  r'<a href="\2" style="color:#4ec9b0;">\1</a>', text)

    return text


# ---------------------------------------------------------------------------
# Block-level parser — splits raw markdown into block tokens
# ---------------------------------------------------------------------------
def parse_blocks(text):
    """
    Parse markdown text into a list of block tokens.
    Each token is a dict with a 'type' key and type-specific fields.
    Each block also carries '_char_end': the absolute character offset in
    *text* immediately after this block (used for incremental streaming render).
    """
    # ── pre-pass: extract <think>...</think> blocks ───────────────────
    # Split text into think/non-think segments before line parsing.
    # Track each segment's start offset in the original text so we can
    # convert relative _char_end values to absolute positions.
    raw_blocks = []   # (seg_type, seg_text, seg_offset_in_text)
    think_pattern = re.compile(r'<think>(.*?)</think>', re.DOTALL | re.IGNORECASE)
    last = 0
    for m in think_pattern.finditer(text):
        if m.start() > last:
            raw_blocks.append(("text", text[last:m.start()], last))
        # Think block ends at m.end() (right after </think>)
        raw_blocks.append(("think", m.group(1).strip(), m.end()))
        last = m.end()
    if last < len(text):
        raw_blocks.append(("text", text[last:], last))

    blocks = []
    for seg_type, seg_text, seg_offset in raw_blocks:
        if seg_type == "think":
            # seg_offset is the absolute position of the end of </think>
            blocks.append({"type": "think", "content": seg_text,
                           "_char_end": seg_offset})
        else:
            seg_blocks = _parse_text_blocks(seg_text)
            for b in seg_blocks:
                b["_char_end"] = seg_offset + b.get("_char_end", len(seg_text))
            blocks.extend(seg_blocks)
    return blocks


def _parse_list_items(lines, base_indent):
    """
    Recursively parse a list of raw lines into a tree of list items.

    Each item is a dict:
        {
            "ordered": bool,
            "num":     int | None,   # None for bullet items
            "content": str,
            "children": [ ... ]      # nested items at deeper indent
        }

    Items at exactly `base_indent` spaces are siblings.
    Lines with greater indent become children of the preceding item.
    """
    items  = []
    i      = 0

    while i < len(lines):
        l = lines[i]
        if not l.strip():          # skip blank lines inside list
            i += 1
            continue

        indent = len(l) - len(l.lstrip())
        if indent < base_indent:   # de-dented past our level — stop
            break

        if indent > base_indent:   # deeper than expected — attach to last item
            if items:
                items[-1]["children"] += _parse_list_items(lines[i:], indent)
            i += 1
            continue

        # Match bullet or numbered marker at this indent level
        bm = re.match(r'^(\s*)([-*+•·‣⁃])\s+(.*)', l)
        nm = re.match(r'^(\s*)(\d+)\.\s+(.*)', l)

        if bm:
            content = bm.group(3).rstrip()
            items.append({"ordered": False, "num": None,
                          "content": content, "children": []})
            i += 1
        elif nm:
            content = nm.group(3).rstrip()
            items.append({"ordered": True, "num": int(nm.group(2)),
                          "content": content, "children": []})
            i += 1
        else:
            i += 1   # unrecognised line — skip

        # Collect immediately following deeper-indented lines as children
        child_lines = []
        while i < len(lines):
            nl = lines[i]
            if not nl.strip():
                # Blank line: peek ahead — if next non-blank is deeper, include
                j = i + 1
                while j < len(lines) and not lines[j].strip():
                    j += 1
                if j < len(lines):
                    next_indent = len(lines[j]) - len(lines[j].lstrip())
                    if next_indent > base_indent:
                        i += 1
                        continue
                break
            next_indent = len(nl) - len(nl.lstrip())
            if next_indent > base_indent:
                child_lines.append(nl)
                i += 1
            else:
                break

        if child_lines and items:
            child_base = len(child_lines[0]) - len(child_lines[0].lstrip())
            items[-1]["children"] += _parse_list_items(child_lines, child_base)

    return items


def _parse_text_blocks(text):
    """Parse a plain text segment into markdown blocks (no think tags).
    Each block dict includes '_char_end': the character offset in *text*
    immediately after the block's last character (used for incremental rendering).
    """
    # Use keepends=True so we can compute exact character positions per line.
    lines_with_nl = text.splitlines(keepends=True)
    lines = [l.rstrip('\r\n') for l in lines_with_nl]

    # _line_starts[i] = char offset in text where line i begins.
    # _line_starts[len(lines)] = len(text).
    _line_starts = [0]
    for l in lines_with_nl:
        _line_starts.append(_line_starts[-1] + len(l))

    def _ce(line_idx):
        """Char offset right after line (line_idx-1), i.e. start of line_idx."""
        return _line_starts[min(line_idx, len(lines))]

    blocks = []
    i      = 0

    while i < len(lines):
        line = lines[i]

        # ── fenced code block ────────────────────────────────────────
        m = re.match(r'^\s*```(\w*)\s*$', line)
        if m:
            lang  = m.group(1)
            code_lines = []
            i += 1
            while i < len(lines) and not re.match(r'\s*```', lines[i]):
                code_lines.append(lines[i])
                i += 1
            fence_found = i < len(lines)  # True = closing ``` found; False = buffer exhausted
            i += 1  # skip closing ``` (or step past end)
            blocks.append({"type": "code", "lang": lang,
                           "content": "\n".join(code_lines),
                           "_char_end": _ce(i),
                           "_closed": fence_found})
            continue

        # ── heading ──────────────────────────────────────────────────
        m = re.match(r'^(#{1,6})\s+(.*)', line)
        if m:
            level = len(m.group(1))
            i += 1
            blocks.append({"type": "heading", "level": level,
                           "content": m.group(2).strip(),
                           "_char_end": _ce(i)})
            continue

        # ── horizontal rule ──────────────────────────────────────────
        if re.match(r'^(---+|\*\*\*+|___+)\s*$', line):
            i += 1
            blocks.append({"type": "hr", "_char_end": _ce(i)})
            continue

        # ── blockquote ───────────────────────────────────────────────
        if line.startswith("> ") or line == ">":
            quote_lines = []
            while i < len(lines) and (lines[i].startswith("> ") or
                                       lines[i] == ">"):
                quote_lines.append(lines[i][2:] if lines[i].startswith("> ")
                                   else lines[i][1:])
                i += 1
            blocks.append({"type": "blockquote",
                           "content": "\n".join(quote_lines),
                           "_char_end": _ce(i)})
            continue

        # ── table ────────────────────────────────────────────────────
        if "|" in line and i + 1 < len(lines) and re.match(
                r'^\s*\|?[\s\-:|]+\|', lines[i + 1]):
            rows = []
            while i < len(lines) and "|" in lines[i]:
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                rows.append(cells)
                i += 1
            ce = _ce(i)
            # rows[0] = header, rows[1] = separator, rows[2:] = data
            if len(rows) >= 2:
                header = rows[0]
                data   = rows[2:] if len(rows) > 2 else []
                blocks.append({"type": "table", "header": header,
                               "rows": data, "_char_end": ce})
                continue
            # Fallback: treat as paragraph
            for r in rows:
                blocks.append({"type": "paragraph",
                               "content": " | ".join(r),
                               "_char_end": ce})
            continue

        # ── list (bullet or numbered, arbitrary nesting) ─────────────
        if re.match(r'^(\s*)([-*+•·‣⁃]|\d+\.)\s+', line):
            # Collect all consecutive list lines (including blank lines
            # between items) into a raw block, then parse recursively.
            raw = []
            while i < len(lines):
                l = lines[i]
                if re.match(r'^\s*([-*+•·‣⁃]|\d+\.)\s+', l):
                    raw.append(l)
                    i += 1
                elif l.strip() == "":
                    # Keep blank only if next non-blank is still a list item
                    j = i + 1
                    while j < len(lines) and lines[j].strip() == "":
                        j += 1
                    if j < len(lines) and re.match(
                            r'^\s*([-*+•·‣⁃]|\d+\.)\s+', lines[j]):
                        i += 1   # skip blank, stay in list
                    else:
                        break    # end of list
                else:
                    break
            blocks.append({"type": "list",
                           "items": _parse_list_items(raw, 0),
                           "_char_end": _ce(i)})
            continue

        # ── blank line ───────────────────────────────────────────────
        if line.strip() == "":
            i += 1
            continue

        # ── paragraph (collect until blank line or block element) ────
        para_lines = []
        while i < len(lines):
            l = lines[i]
            if (l.strip() == "" or
                    re.match(r'^#{1,6}\s', l) or
                    re.match(r'^```', l) or
                    re.match(r'^(---+|\*\*\*+|___+)\s*$', l) or
                    re.match(r'^>\s?', l) or
                    re.match(r'^\s*[-*+•·‣⁃]\s+', l) or
                    re.match(r'^\d+\.\s+', l) or
                    ("|" in l and i + 1 < len(lines) and
                     re.match(r'^\s*\|?[\s\-:|]+\|', lines[i + 1]
                              if i + 1 < len(lines) else ""))):
                break
            para_lines.append(l)
            i += 1
        if para_lines:
            blocks.append({"type": "paragraph",
                           "content": " ".join(para_lines),
                           "_char_end": _ce(i)})

    return blocks


# ---------------------------------------------------------------------------
# Qt widget builders for each block type
# ---------------------------------------------------------------------------

def _make_label(html, selectable=True, word_wrap=True, text_color="#d4d4d4",
                font_size=10):
    lbl = QLabel()
    lbl.setTextFormat(Qt.RichText)
    lbl.setWordWrap(word_wrap)
    lbl.setText(html)
    lbl.setOpenExternalLinks(True)
    lbl.setStyleSheet(
        f"background: transparent; padding: 1px 8px; "
        f"color: {text_color}; font-size: {font_size}pt;")
    if selectable:
        lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard |
            Qt.LinksAccessibleByMouse)
    return lbl


def build_heading(block, base_size=14):
    level   = block["level"]
    content = _inline_to_html(block["content"])
    # Scale heading levels relative to base_size
    sizes   = {1: base_size, 2: base_size - 2, 3: base_size - 4,
               4: base_size - 5, 5: base_size - 6, 6: base_size - 7}
    size    = max(sizes.get(level, base_size - 4), 8)
    colors  = {1: "#4ec9b0", 2: "#4ec9b0", 3: "#9cdcfe"}
    color   = colors.get(level, "#d4d4d4")
    # Wrap in a block element so Qt rich-text gives the glyph room
    # Use emoji-capable font family so keycap sequences (1⃣ etc.) render cleanly
    emoji_fonts = "'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', 'Noto Emoji', 'Twemoji Mozilla', sans-serif"
    html    = (f'<p style="margin-top:4px; margin-bottom:0; padding-left:4px;">'
               f'<span style="font-size:{size}pt; font-weight:bold; color:{color};'
               f'font-family:{emoji_fonts};">{content}</span></p>')
    w = _make_label(html, text_color=color, font_size=size)
    w.setStyleSheet(
        f"background: transparent; padding: 6px 8px 4px 10px; "
        f"color: {color}; font-size: {size}pt;")
    return w


def build_paragraph(block, text_color="#d4d4d4", font_size=10):
    html = _inline_to_html(block["content"])
    return _make_label(
        f'<span style="color:{text_color};">{html}</span>',
        text_color=text_color, font_size=font_size)


def build_hr():
    line = QFrame()
    line.setFrameShape(QFrame.HLine)
    line.setFrameShadow(QFrame.Sunken)
    line.setStyleSheet("color: #555; margin: 4px 8px;")
    return line


def build_think(block, font_size=9):
    """Collapsible thinking block with distinct background."""
    outer = QFrame()
    # Expanding horizontally so the frame fills the scroll-area width.
    # Labels inside inherit this width, which makes setWordWrap(True) work correctly.
    outer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    outer.setStyleSheet(
        "QFrame { background: #1a2a1a; border: 1px solid #2a3d2a; "
        "border-radius: 4px; margin: 2px 8px; }")
    lay = QVBoxLayout(outer)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(0)

    # Header row with toggle button
    header = QWidget()
    header.setStyleSheet(
        "background: #243824; border-bottom: 1px solid #2a3d2a; "
        "border-radius: 4px 4px 0 0;")
    hl = QHBoxLayout(header)
    hl.setContentsMargins(8, 3, 8, 3)
    icon_lbl = QLabel("🧠")
    icon_lbl.setStyleSheet("background: transparent; border: none; font-size: 11px;")
    hl.addWidget(icon_lbl)
    title_lbl = QLabel("Thinking…")
    title_lbl.setStyleSheet(
        f"color: #7ec87e; font-size: {font_size}pt; "
        "background: transparent; border: none;")
    hl.addWidget(title_lbl)
    hl.addStretch()
    toggle_btn = QPushButton("▾ hide")
    toggle_btn.setFlat(True)
    toggle_btn.setStyleSheet(
        f"QPushButton {{ color: #7ec87e; font-size: {font_size}pt; border: none; "
        "background: transparent; padding: 0 4px; }"
        "QPushButton:hover { color: #aeeaae; }")
    hl.addWidget(toggle_btn)
    lay.addWidget(header)

    # Content area — QPlainTextEdit with vertical scrollbar.
    # Fixed max-height avoids all the dynamic sizing complexity.
    from qtpy.QtWidgets import QPlainTextEdit

    content_w = QPlainTextEdit()
    content_w.setReadOnly(True)
    content_w.setFrameShape(QFrame.NoFrame)
    content_w.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    content_w.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    content_w.setLineWrapMode(QPlainTextEdit.WidgetWidth)
    content_w.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    content_w.setStyleSheet(
        f"QPlainTextEdit {{ background: transparent; border: none; "
        f"color: #8abf8a; font-size: {font_size}pt; "
        f"padding: 6px 10px; }}")
    content_w.setPlainText(block["content"])
    content_w.setMaximumHeight(200)

    lay.addWidget(content_w)

    # Wire toggle — preserves the viewport position of the think block header
    def _toggle():
        # Walk up the widget tree to find the enclosing QScrollArea so we can
        # restore the on-screen position of this block after the layout reflows.
        scroll_area = None
        p = outer.parent()
        while p is not None:
            if isinstance(p, QScrollArea):
                scroll_area = p
                break
            p = p.parent()

        if scroll_area is not None:
            vsb      = scroll_area.verticalScrollBar()
            outer_y  = outer.mapTo(scroll_area.widget(), QPoint(0, 0)).y()
            screen_y = outer_y - vsb.value()   # current visual offset from viewport top

        visible = content_w.isVisible()
        content_w.setVisible(not visible)
        toggle_btn.setText("▸ show" if visible else "▾ hide")

        if scroll_area is not None:
            # Restore after Qt reflows the layout (rangeChanged fires synchronously
            # during setVisible and may have already moved the scrollbar).
            def _restore():
                new_outer_y = outer.mapTo(scroll_area.widget(), QPoint(0, 0)).y()
                vsb.setValue(max(0, new_outer_y - screen_y))
            QTimer.singleShot(0, _restore)

    toggle_btn.clicked.connect(_toggle)
    return outer


def build_blockquote(block, text_color="#d4d4d4", font_size=10):
    w   = QFrame()
    w.setStyleSheet(
        "QFrame { border-left: 3px solid #4a90d9; "
        "background: rgba(74,144,217,0.08); "
        "margin: 2px 8px; border-radius: 2px; }")
    lay = QVBoxLayout(w)
    lay.setContentsMargins(10, 4, 8, 4)
    lay.setSpacing(2)
    for line in block["content"].splitlines():
        lbl = _make_label(
            f'<i style="color:#9cdcfe;">{_inline_to_html(line)}</i>',
            text_color="#9cdcfe", font_size=font_size)
        lbl.setStyleSheet(
            f"background: transparent; padding: 0; color: #9cdcfe; font-size: {font_size}pt;")
        lay.addWidget(lbl)
    return w


def _build_list_widget(items, text_color, font_size, depth=0):
    """Recursively build a QWidget for a list tree at the given depth."""
    w   = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(depth * 16, 0, 0, 0)
    lay.setSpacing(1)

    for item in items:
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)

        # Marker: number or bullet symbol, cycling through styles by depth
        if item["ordered"]:
            marker_text = f"{item['num']}."
            marker_w    = 28
        else:
            symbols     = ["•", "◦", "▪", "▸"]
            marker_text = symbols[min(depth, len(symbols) - 1)]
            marker_w    = 14

        marker = QLabel(marker_text)
        marker.setStyleSheet(
            f"color: #4ec9b0; padding: 0 6px 0 0; background: transparent; "
            f"font-size: {font_size}pt;"
            + (" font-weight: bold;" if item["ordered"] and depth == 0 else ""))
        marker.setFixedWidth(marker_w)
        row.addWidget(marker, 0, Qt.AlignTop)

        # Item text
        lbl = _make_label(
            f'<span style="color:{text_color};">'
            f'{_inline_to_html(item["content"])}</span>',
            text_color=text_color, font_size=font_size)
        lbl.setStyleSheet(
            f"background: transparent; padding: 0; color: {text_color}; "
            f"font-size: {font_size}pt;")
        row.addWidget(lbl, 1)
        lay.addLayout(row)

        # Recurse into children
        if item.get("children"):
            lay.addWidget(
                _build_list_widget(item["children"], text_color,
                                   font_size, depth + 1))
    return w


def build_list(block, text_color="#d4d4d4", font_size=10):
    """Build a recursively nested list widget."""
    return _build_list_widget(block["items"], text_color, font_size, depth=0)


def build_table(block, font_size=10):
    w   = QFrame()
    w.setStyleSheet("QFrame { margin: 4px 8px; }")
    grid = QGridLayout(w)
    grid.setContentsMargins(0, 0, 0, 0)
    grid.setSpacing(0)

    for col, cell in enumerate(block["header"]):
        lbl = QLabel(_inline_to_html(cell))
        lbl.setTextFormat(Qt.RichText)
        lbl.setWordWrap(True)
        lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        lbl.setStyleSheet(
            f"background: #2d2d2d; color: #4ec9b0; font-weight: bold; "
            f"padding: 4px 8px; border: 1px solid #444; font-size: {font_size}pt;")
        lbl.setOpenExternalLinks(True)
        grid.addWidget(lbl, 0, col)

    for row_i, row in enumerate(block["rows"]):
        bg = "#1e1e1e" if row_i % 2 == 0 else "#252525"
        for col, cell in enumerate(row):
            text = cell if col < len(row) else ""
            lbl = QLabel(_inline_to_html(text))
            lbl.setTextFormat(Qt.RichText)
            lbl.setWordWrap(True)
            lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            lbl.setStyleSheet(
                f"background: {bg}; color: #d4d4d4; "
                f"padding: 3px 8px; border: 1px solid #444; font-size: {font_size}pt;")
            lbl.setOpenExternalLinks(True)
            lbl.setTextInteractionFlags(
                Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
            grid.addWidget(lbl, row_i + 1, col)

    return w


def build_code_block(block, insert_signal=None, font_size=10):
    """Build a code block frame with header bar and copy button."""
    lang = block["lang"]
    code = block["content"]

    frame = QFrame()
    frame.setFrameShape(QFrame.StyledPanel)
    frame.setStyleSheet(
        "QFrame { background: #1e1e1e; border: 1px solid #444; "
        "border-radius: 4px; margin: 2px 8px; }")
    fl = QVBoxLayout(frame)
    fl.setContentsMargins(0, 0, 0, 0)
    fl.setSpacing(0)

    # Code text — created first so the header's copy button can capture it
    from qtpy.QtWidgets import QPlainTextEdit as _PTE
    code_lbl = _PTE()
    code_lbl.setReadOnly(True)
    code_lbl.setFrameShape(QFrame.NoFrame)
    code_lbl.setLineWrapMode(_PTE.NoWrap)
    code_lbl.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    code_lbl.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    code_lbl.setFont(QFont("Monospace", font_size))
    code_lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    code_lbl.setStyleSheet(
        "QPlainTextEdit { color: #d4d4d4; background: transparent; "
        "padding: 8px 10px; border: none; }")
    code_lbl.setPlainText(code)
    # Height = text lines + vertical padding + horizontal scrollbar.
    # fontMetrics().lineSpacing() is the real per-line pixel height for this font/DPI.
    # 24 px = CSS padding (8 top + 8 bottom = 16 px) + QTextDocument document margin
    #         (4 px × 2 sides = 8 px).
    # horizontalScrollBar().sizeHint().height() reserves space for the scrollbar so
    # it never overlaps the last code line(s) when wide content triggers it.
    n_lines = code.count("\n") + 1
    sb_h = code_lbl.horizontalScrollBar().sizeHint().height()
    code_lbl.setFixedHeight(n_lines * code_lbl.fontMetrics().lineSpacing() + 24 + sb_h)

    # Header — built after code_lbl so the copy button lambda can capture it
    header = QWidget()
    header.setStyleSheet("background: #2d2d2d; border-bottom: 1px solid #444;")
    hl = QHBoxLayout(header)
    hl.setContentsMargins(8, 2, 4, 2)
    lang_lbl = QLabel(lang if lang else "code")
    lang_lbl.setStyleSheet(
        "color: #888; font-size: 10px; background: transparent; border: none;")
    hl.addWidget(lang_lbl)
    hl.addStretch()
    if insert_signal is not None:
        copy_btn = QPushButton("📋 Copy to editor")
        copy_btn.setFlat(True)
        copy_btn.setStyleSheet(
            "QPushButton { color: #4ec9b0; font-size: 10px; "
            "padding: 1px 6px; border: none; background: transparent; }"
            "QPushButton:hover { color: #fff; }")
        copy_btn.setToolTip("Insert this code at cursor in the current editor")
        copy_btn.clicked.connect(
            lambda checked=False, pte=code_lbl: insert_signal.emit(pte.toPlainText()))
        hl.addWidget(copy_btn)
    fl.addWidget(header)
    fl.addWidget(code_lbl)
    return frame


# ---------------------------------------------------------------------------
# Main entry point: render markdown text into a QWidget
# ---------------------------------------------------------------------------
def render_markdown(text, insert_signal=None, font_cfg=None):
    """
    Parse markdown text and return a QWidget containing all rendered blocks.
    insert_signal: optional Signal(str) emitted when user clicks "Copy to editor"
    font_cfg: optional dict with keys fs_base, fs_code, fs_heading, fs_list,
              fs_table, fs_think (all in pt). Falls back to defaults if absent.
    """
    from .settings_dialog import EDITOR_DEFAULTS
    cfg = {**EDITOR_DEFAULTS, **(font_cfg or {})}

    try:
        from spyder.config.gui import is_dark_interface
        text_color = "#d4d4d4" if is_dark_interface() else "#1a1a1a"
    except Exception:
        text_color = "#d4d4d4"

    container = QWidget()
    container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    lay = QVBoxLayout(container)
    lay.setContentsMargins(0, 2, 0, 2)
    lay.setSpacing(3)

    blocks = parse_blocks(text)
    has_code = any(b["type"] == "code" for b in blocks)

    for block in blocks:
        t = block["type"]
        if t == "think":
            lay.addWidget(build_think(block, cfg["fs_think"]))
        elif t == "heading":
            lay.addWidget(build_heading(block, cfg["fs_heading"]))
        elif t == "paragraph":
            lay.addWidget(build_paragraph(block, text_color, cfg["fs_base"]))
        elif t == "code":
            lay.addWidget(build_code_block(block, insert_signal, cfg["fs_code"]))
        elif t == "hr":
            lay.addWidget(build_hr())
        elif t == "blockquote":
            lay.addWidget(build_blockquote(block, text_color, cfg["fs_base"]))
        elif t == "list":
            lay.addWidget(build_list(block, text_color, cfg["fs_list"]))
        elif t == "table":
            lay.addWidget(build_table(block, cfg["fs_table"]))

    if not has_code and insert_signal is not None:
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        copy_all = QPushButton("📋 Copy to editor")
        copy_all.setFlat(True)
        copy_all.setStyleSheet(
            "QPushButton { color: #888; font-size: 10px; padding: 1px 4px; "
            "border: none; background: transparent; }"
            "QPushButton:hover { color: #ccc; }")
        copy_all.setToolTip("Insert full response at cursor in current editor")
        copy_all.clicked.connect(
            lambda checked=False, t=text: insert_signal.emit(t))
        btn_row.addWidget(copy_all)
        lay.addLayout(btn_row)

    return container
