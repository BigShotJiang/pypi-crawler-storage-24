# Copyright 2025 Amazon Inc

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import logging

logging.basicConfig(level=logging.INFO)

# Suppress informational and warning logs from dependencies
logging.getLogger("botocore.credentials").setLevel(logging.ERROR)
logging.getLogger("sagemaker").setLevel(logging.ERROR)
logging.getLogger("sagemaker.config").setLevel(logging.ERROR)
logging.getLogger("sagemaker.pytorch").setLevel(logging.ERROR)

logger = logging.getLogger("nova_forge_sdk")
logger.setLevel(logging.INFO)
logger.propagate = True
