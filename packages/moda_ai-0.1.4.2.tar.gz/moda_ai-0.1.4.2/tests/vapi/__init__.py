"""Tests for Vapi integration."""
