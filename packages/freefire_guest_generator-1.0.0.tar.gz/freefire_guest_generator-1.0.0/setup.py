from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="freefire-guest-generator",
    version="1.0.0",
    author="UNKNOWN666",
    author_email="arbasbilal25@gmail.com",
    description="Generate Free Fire guest accounts with full details",
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
        "pycryptodome>=3.15.0",
    ],
)