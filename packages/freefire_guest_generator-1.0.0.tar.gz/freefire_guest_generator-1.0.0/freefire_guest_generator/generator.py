"""
Guest Account Generator for Free Fire

This module provides a function to generate multiple guest accounts.
"""

import json
import hmac
import hashlib
import requests
import time
import random
import codecs
import base64
from urllib.parse import urlparse, parse_qs

# Constants
HEX_KEY = "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"
KEY = bytes.fromhex(HEX_KEY)
REGION_LANG = {
    "ME": "ar", "IND": "hi", "ID": "id", "VN": "vi", "TH": "th",
    "BD": "bn", "PK": "ur", "TW": "zh", "CIS": "ru", "SAC": "es", "BR": "pt"
}

# ---------- Helper functions (copied from the original) ----------
def EnC_Vr(N):
    if N < 0:
        return b''
    H = []
    while True:
        BesTo = N & 0x7F
        N >>= 7
        if N:
            BesTo |= 0x80
        H.append(BesTo)
        if not N:
            break
    return bytes(H)

def CrEaTe_VarianT(field_number, value):
    field_header = (field_number << 3) | 0
    return EnC_Vr(field_header) + EnC_Vr(value)

def CrEaTe_LenGTh(field_number, value):
    field_header = (field_number << 3) | 2
    encoded_value = value.encode() if isinstance(value, str) else value
    return EnC_Vr(field_header) + EnC_Vr(len(encoded_value)) + encoded_value

def CrEaTe_ProTo(fields):
    packet = bytearray()
    for field, value in fields.items():
        if isinstance(value, dict):
            nested_packet = CrEaTe_ProTo(value)
            packet.extend(CrEaTe_LenGTh(field, nested_packet))
        elif isinstance(value, int):
            packet.extend(CrEaTe_VarianT(field, value))
        elif isinstance(value, (str, bytes)):
            packet.extend(CrEaTe_LenGTh(field, value))
    return packet

def E_AEs(Pc):
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad
    Z = bytes.fromhex(Pc)
    aes_key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
    cipher = AES.new(aes_key, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(pad(Z, AES.block_size))
    return encrypted

def encrypt_api(plain_text):
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad
    plain_bytes = bytes.fromhex(plain_text)
    aes_key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
    cipher = AES.new(aes_key, AES.MODE_CBC, iv)
    cipher_text = cipher.encrypt(pad(plain_bytes, AES.block_size))
    return cipher_text.hex()

def encode_string(original):
    keystream = [0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37, 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37,
                 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37, 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30]
    encoded = ""
    for i, ch in enumerate(original):
        orig_byte = ord(ch)
        key_byte = keystream[i % len(keystream)]
        result_byte = orig_byte ^ key_byte
        encoded += chr(result_byte)
    return {"open_id": original, "field_14": encoded}

def to_unicode_escaped(s):
    return ''.join(c if 32 <= ord(c) <= 126 else f'\\u{ord(c):04x}' for c in s)

# ---------- Core functions ----------
def generate_random_name(prefix, index=None):
    """Generate a name with optional index."""
    if index is not None:
        return f"{prefix}{index}"
    else:
        return f"{prefix}{random.randint(100, 999)}"

def perform_major_login(uid, password, access_token, open_id, region, is_ghost=False, retries=3):
    """Perform MajorLogin to get JWT token and account_id."""
    lang = REGION_LANG.get(region.upper(), "en") if not is_ghost else "pt"
    # Payload template (the same as before)
    payload_parts = [
        b'\x1a\x132025-08-30 05:19:21"\tfree fire(\x01:\x081.114.13B2Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)J\x08HandheldR\nATM MobilsZ\x04WIFI`\xb6\nh\xee\x05r\x03300z\x1fARMv7 VFPv3 NEON VMH | 2400 | 2\x80\x01\xc9\x0f\x8a\x01\x0fAdreno (TM) 640\x92\x01\rOpenGL ES 3.2\x9a\x01+Google|dfa4ab4b-9dc4-454e-8065-e70c733fa53f\xa2\x01\x0e105.235.139.91\xaa\x01\x02',
        lang.encode("ascii"),
        b'\xb2\x01 1d8ec0240ede109973f3321b9354b44d\xba\x01\x014\xc2\x01\x08Handheld\xca\x01\x10Asus ASUS_I005DA\xea\x01@afcfbf13334be42036e4f742c80b956344bed760ac91b3aff9b607a610ab4390\xf0\x01\x01\xca\x02\nATM Mobils\xd2\x02\x04WIFI\xca\x03 7428b253defc164018c604a1ebbfebdf\xe0\x03\xa8\x81\x02\xe8\x03\xf6\xe5\x01\xf0\x03\xaf\x13\xf8\x03\x84\x07\x80\x04\xe7\xf0\x01\x88\x04\xa8\x81\x02\x90\x04\xe7\xf0\x01\x98\x04\xa8\x81\x02\xc8\x04\x01\xd2\x04=/data/app/com.dts.freefireth-PdeDnOilCSFn37p1AH_FLg==/lib/arm\xe0\x04\x01\xea\x04_2087f61c19f57f2af4e7feff0b24d9d9|/data/app/com.dts.freefireth-PdeDnOilCSFn37p1AH_FLg==/base.apk\xf0\x04\x03\xf8\x04\x01\x8a\x05\x0232\x9a\x05\n2019118692\xb2\x05\tOpenGLES2\xb8\x05\xff\x7f\xc0\x05\x04\xe0\x05\xf3F\xea\x05\x07android\xf2\x05pKqsHT5ZLWrYljNb5Vqh//yFRlaPHSO9NWSQsVvOmdhEEn7W+VHNUK+Q+fduA3ptNrGB0Ll0LRz3WW0jOwesLj6aiU7sZ40p8BfUE/FI/jzSTwRe2\xf8\x05\xfb\xe4\x06\x88\x06\x01\x90\x06\x01\x9a\x06\x014\xa2\x06\x014\xb2\x06"GQ@O\x00\x0e^\x00D\x06UA\x0ePM\r\x13hZ\x07T\x06\x0cm\\V\x0ejYV;\x0bU5'
    ]
    payload = b''.join(payload_parts)
    if is_ghost:
        url = "https://loginbp.ggblueshark.com/MajorLogin"
    elif region.upper() in ["ME", "TH"]:
        url = "https://loginbp.common.ggbluefox.com/MajorLogin"
    else:
        url = "https://loginbp.ggblueshark.com/MajorLogin"
    headers = {
        "Accept-Encoding": "gzip",
        "Authorization": "Bearer",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Expect": "100-continue",
        "Host": "loginbp.ggblueshark.com" if is_ghost or region.upper() not in ["ME", "TH"] else "loginbp.common.ggbluefox.com",
        "ReleaseVersion": "OB52",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_I005DA Build/PI)",
        "X-GA": "v1 1",
        "X-Unity-Version": "2018.4.11f1"
    }
    # Replace placeholders
    data = payload.replace(b'afcfbf13334be42036e4f742c80b956344bed760ac91b3aff9b607a610ab4390', access_token.encode())
    data = data.replace(b'1d8ec0240ede109973f3321b9354b44d', open_id.encode())
    d = encrypt_api(data.hex())
    final_payload = bytes.fromhex(d)
    for attempt in range(retries):
        try:
            response = requests.post(url, headers=headers, data=final_payload, verify=False, timeout=30)
            if response.status_code == 200 and len(response.text) > 10:
                # Extract JWT from response
                jwt_start = response.text.find("eyJ")
                if jwt_start != -1:
                    jwt_token = response.text[jwt_start:]
                    # Trim to a valid JWT (first three parts separated by dots)
                    parts = jwt_token.split('.')
                    if len(parts) >= 3:
                        jwt_token = '.'.join(parts[:3])
                        # Decode the payload to get account_id
                        try:
                            payload_part = parts[1]
                            padding = 4 - len(payload_part) % 4
                            if padding != 4:
                                payload_part += '=' * padding
                            decoded = base64.urlsafe_b64decode(payload_part)
                            data = json.loads(decoded)
                            account_id = data.get('account_id') or data.get('external_id')
                            if account_id:
                                return {"account_id": str(account_id), "jwt_token": jwt_token}
                        except:
                            pass
        except Exception as e:
            print(f"MajorLogin attempt {attempt+1} failed: {e}")
            if attempt < retries - 1:
                time.sleep(3)
            continue
    return {"account_id": "N/A", "jwt_token": ""}

def create_single_account(region, name_prefix, index=None, retries=3):
    """Create a single guest account with retries."""
    for attempt in range(retries):
        try:
            # Step 1: Generate random password
            password = ''.join(random.choice('0123456789ABCDEF') for _ in range(64))
            # Step 2: Register guest
            payload = {
                "app_id": 100067,
                "client_type": 2,
                "password": password,
                "source": 2
            }
            body_json = json.dumps(payload, separators=(',', ':'))
            message = body_json.encode('utf-8')
            signature = hmac.new(KEY, message, hashlib.sha256).hexdigest()
            url = "https://100067.connect.garena.com/api/v2/oauth/guest:register"
            headers = {
                "User-Agent": "GarenaMSDK/4.0.39(SM-A325M ;Android 13;en;HK;)",
                "Authorization": "Signature " + signature,
                "Content-Type": "application/json; charset=utf-8",
                "Accept": "application/json",
                "Accept-Encoding": "gzip",
                "Connection": "Keep-Alive",
                "Host": "100067.connect.garena.com"
            }
            response = requests.post(url, headers=headers, data=body_json, timeout=30, verify=False)
            if response.status_code != 200:
                raise Exception(f"HTTP {response.status_code}")
            resp_json = response.json()
            if resp_json.get("code") != 0:
                raise Exception(f"Registration failed, code: {resp_json.get('code')}")
            uid = resp_json['data']['uid']
            # Step 3: Get token
            token_url = "https://100067.connect.garena.com/api/v2/oauth/guest/token:grant"
            token_payload = {
                "client_id": 100067,
                "client_secret": HEX_KEY,
                "client_type": 2,
                "password": password,
                "response_type": "token",
                "uid": uid
            }
            body_json2 = json.dumps(token_payload, separators=(',', ':'))
            message2 = body_json2.encode('utf-8')
            signature2 = hmac.new(KEY, message2, hashlib.sha256).hexdigest()
            headers2 = {
                "User-Agent": "GarenaMSDK/4.0.39(SM-A325M ;Android 13;en;HK;)",
                "Authorization": "Signature " + signature2,
                "Content-Type": "application/json; charset=utf-8",
                "Accept": "application/json",
                "Accept-Encoding": "gzip",
                "Connection": "Keep-Alive",
                "Host": "100067.connect.garena.com"
            }
            token_resp = requests.post(token_url, headers=headers2, data=body_json2, timeout=30, verify=False)
            if token_resp.status_code != 200:
                raise Exception(f"Token HTTP {token_resp.status_code}")
            token_json = token_resp.json()
            if token_json.get("code") != 0:
                raise Exception(f"Token grant failed, code: {token_json.get('code')}")
            open_id = token_json['data']['open_id']
            access_token = token_json['data']['access_token']
            # Step 4: Prepare field for MajorRegister
            result = encode_string(open_id)
            escaped = to_unicode_escaped(result['field_14'])
            field = codecs.decode(escaped, 'unicode_escape').encode('latin1')
            # Step 5: MajorRegister
            name = generate_random_name(name_prefix, index)
            if region.upper() in ["ME", "TH"]:
                major_url = "https://loginbp.common.ggbluefox.com/MajorRegister"
            else:
                major_url = "https://loginbp.ggblueshark.com/MajorRegister"
            lang_code = REGION_LANG.get(region.upper(), "en")
            headers_major = {
                "Accept-Encoding": "gzip",
                "Authorization": "Bearer",
                "Connection": "Keep-Alive",
                "Content-Type": "application/x-www-form-urlencoded",
                "Expect": "100-continue",
                "Host": "loginbp.ggblueshark.com" if region.upper() not in ["ME", "TH"] else "loginbp.common.ggbluefox.com",
                "ReleaseVersion": "OB52",
                "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_I005DA Build/PI)",
                "X-GA": "v1 1",
                "X-Unity-Version": "2018.4.11f1"
            }
            payload_major = {
                1: name,
                2: access_token,
                3: open_id,
                5: 102000007,
                6: 4,
                7: 1,
                13: 1,
                14: field,
                15: lang_code,
                16: 1,
                17: 1
            }
            proto_bytes = CrEaTe_ProTo(payload_major)
            encrypted = E_AEs(proto_bytes.hex())
            resp_major = requests.post(major_url, headers=headers_major, data=encrypted, verify=False, timeout=30)
            if resp_major.status_code != 200:
                raise Exception(f"MajorRegister HTTP {resp_major.status_code}")
            # Step 6: Perform MajorLogin to get JWT and account_id
            login_result = perform_major_login(uid, password, access_token, open_id, region, is_ghost=False, retries=3)
            if login_result["account_id"] == "N/A":
                raise Exception("MajorLogin failed to return account_id")
            account_data = {
                "uid": str(uid),
                "password": password,
                "name": name,
                "region": region,
                "account_id": login_result["account_id"],
                "jwt_token": login_result["jwt_token"]
            }
            return account_data
        except Exception as e:
            print(f"Attempt {attempt+1} failed: {e}")
            if attempt < retries - 1:
                time.sleep(5)
            else:
                return None
    return None

def generate_accounts(count, prefix, region, retries=3):
    """
    Generate multiple guest accounts.

    Args:
        count (int): Number of accounts to create.
        prefix (str): Name prefix for the accounts.
        region (str): Region code (e.g., 'US', 'BR', 'IND').
        retries (int): Number of retries per account.

    Returns:
        list: List of dicts, each containing uid, password, name, region, account_id, jwt_token.
              Returns None for accounts that failed after retries.
    """
    accounts = []
    for i in range(count):
        print(f"Creating account {i+1}/{count}...")
        account = create_single_account(region, prefix, index=i+1, retries=retries)
        accounts.append(account)
        time.sleep(1)  # small delay between accounts
    return accounts

# ---------- Command line interface (for testing) ----------
if __name__ == "__main__":
    import sys
    if len(sys.argv) < 4:
        print("Usage: python generator.py <count> <prefix> <region> [retries]")
        sys.exit(1)
    count = int(sys.argv[1])
    prefix = sys.argv[2]
    region = sys.argv[3]
    retries = int(sys.argv[4]) if len(sys.argv) > 4 else 3
    accounts = generate_accounts(count, prefix, region, retries)
    print("\n" + "="*60)
    print("GENERATED ACCOUNTS")
    print("="*60)
    for idx, acc in enumerate(accounts):
        if acc:
            print(f"Account {idx+1}:")
            print(f"  UID:        {acc['uid']}")
            print(f"  Password:   {acc['password']}")
            print(f"  Name:       {acc['name']}")
            print(f"  Region:     {acc['region']}")
            print(f"  Account ID: {acc['account_id']}")
            print(f"  JWT Token:  {acc['jwt_token']}")
            print("-"*40)
        else:
            print(f"Account {idx+1}: FAILED")
    print("="*60)