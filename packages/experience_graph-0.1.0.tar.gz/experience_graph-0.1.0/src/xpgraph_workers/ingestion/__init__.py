"""Automated knowledge ingestion workers."""
