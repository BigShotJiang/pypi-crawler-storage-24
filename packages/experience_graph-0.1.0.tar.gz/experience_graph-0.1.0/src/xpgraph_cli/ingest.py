"""Ingest commands -- import traces and evidence into the experience graph."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer
from rich.console import Console

from xpgraph.schemas.evidence import Evidence
from xpgraph.schemas.trace import Trace
from xpgraph_cli.stores import _get_registry, get_document_store, get_trace_store

ingest_app = typer.Typer(no_args_is_help=True)
console = Console()


@ingest_app.command("trace")
def ingest_trace(
    file: str = typer.Argument(None, help="Path to trace JSON file, or '-' for stdin"),
    output_format: str = typer.Option(
        "text", "--format", help="Output format: text or json"
    ),
) -> None:
    """Ingest a trace from a JSON file or stdin."""
    # Read input
    if file == "-" or file is None:
        raw = sys.stdin.read()
    else:
        path = Path(file)
        if not path.exists():
            console.print(f"[red]File not found: {file}[/red]")
            raise typer.Exit(code=1)
        raw = path.read_text()

    # Parse and validate
    try:
        data = json.loads(raw)
        trace = Trace.model_validate(data)
    except Exception as exc:
        if output_format == "json":
            console.print(json.dumps({"status": "error", "message": str(exc)}))
        else:
            console.print(f"[red]Invalid trace: {exc}[/red]")
        raise typer.Exit(code=1) from None

    # Persist to store
    store = get_trace_store()
    try:
        store.append(trace)
    finally:
        store.close()

    if output_format == "json":
        console.print(
            json.dumps({
                "status": "ingested",
                "trace_id": trace.trace_id,
                "source": trace.source,
                "intent": trace.intent,
            })
        )
    else:
        console.print(f"[green]Trace ingested[/green]: {trace.trace_id}")
        console.print(f"  Source: {trace.source}")
        console.print(f"  Intent: {trace.intent}")


@ingest_app.command("evidence")
def ingest_evidence(
    file: str = typer.Argument(..., help="Path to evidence JSON file"),
    output_format: str = typer.Option(
        "text", "--format", help="Output format: text or json"
    ),
) -> None:
    """Ingest evidence from a JSON file."""
    path = Path(file)
    if not path.exists():
        console.print(f"[red]File not found: {file}[/red]")
        raise typer.Exit(code=1)

    try:
        data = json.loads(path.read_text())
        evidence = Evidence.model_validate(data)
    except Exception as exc:
        if output_format == "json":
            console.print(json.dumps({"status": "error", "message": str(exc)}))
        else:
            console.print(f"[red]Invalid evidence: {exc}[/red]")
        raise typer.Exit(code=1) from None

    # Persist to document store
    store = get_document_store()
    try:
        store.put(
            doc_id=evidence.evidence_id,
            content=evidence.content or "",
            metadata={
                "evidence_type": evidence.evidence_type,
                "source_origin": evidence.source_origin,
            },
        )
    finally:
        store.close()

    if output_format == "json":
        console.print(
            json.dumps({
                "status": "ingested",
                "evidence_id": evidence.evidence_id,
                "evidence_type": evidence.evidence_type,
            })
        )
    else:
        console.print(f"[green]Evidence ingested[/green]: {evidence.evidence_id}")
        console.print(f"  Type: {evidence.evidence_type}")


@ingest_app.command("dbt-manifest")
def ingest_dbt_manifest(
    manifest_path: str = typer.Argument(
        ..., help="Path to dbt manifest.json or project dir"
    ),
    output_format: str = typer.Option(
        "text", "--format", help="Output format: text or json"
    ),
) -> None:
    """Ingest a dbt manifest into the knowledge graph."""
    path = Path(manifest_path)
    if not path.exists():
        console.print(f"[red]Path not found: {manifest_path}[/red]")
        raise typer.Exit(code=1)

    from xpgraph_workers.ingestion.dbt import DbtManifestWorker  # noqa: PLC0415

    registry = _get_registry()
    try:
        worker = DbtManifestWorker(registry)
        counts = worker.run(path)
    except Exception as exc:
        if output_format == "json":
            console.print(json.dumps({"status": "error", "message": str(exc)}))
        else:
            console.print(f"[red]dbt ingest failed: {exc}[/red]")
        raise typer.Exit(code=1) from None
    finally:
        registry.close()

    if output_format == "json":
        console.print(json.dumps({"status": "ingested", **counts}))
    else:
        console.print("[green]dbt manifest ingested[/green]")
        console.print(f"  Nodes: {counts['nodes']}")
        console.print(f"  Edges: {counts['edges']}")
        console.print(f"  Documents: {counts.get('documents', 0)}")


@ingest_app.command("openlineage")
def ingest_openlineage(
    events_path: str = typer.Argument(..., help="Path to OpenLineage events JSON file"),
    output_format: str = typer.Option(
        "text", "--format", help="Output format: text or json"
    ),
) -> None:
    """Ingest OpenLineage events into the knowledge graph."""
    path = Path(events_path)
    if not path.exists():
        console.print(f"[red]File not found: {events_path}[/red]")
        raise typer.Exit(code=1)

    from xpgraph_workers.ingestion.openlineage import OpenLineageWorker  # noqa: PLC0415

    registry = _get_registry()
    try:
        worker = OpenLineageWorker(registry)
        counts = worker.run(path)
    except Exception as exc:
        if output_format == "json":
            console.print(json.dumps({"status": "error", "message": str(exc)}))
        else:
            console.print(f"[red]OpenLineage ingest failed: {exc}[/red]")
        raise typer.Exit(code=1) from None
    finally:
        registry.close()

    if output_format == "json":
        console.print(json.dumps({"status": "ingested", **counts}))
    else:
        console.print("[green]OpenLineage events ingested[/green]")
        console.print(f"  Nodes: {counts['nodes']}")
        console.print(f"  Edges: {counts['edges']}")
