"""Compact block formatter for copy-friendly terminal output.

Renders list items as 2-line blocks:
- Line 1 (primary): ID + key metadata (fixed-width, colored)
- Line 2 (detail): Description/content (dimmed, full-width)

No borders = easy copy-paste. Wraps naturally on narrow terminals.
Inspired by gh (GitHub CLI) and kubectl output styles.
"""

from typing import Any

from rich.console import Console, Group, RenderableType
from rich.text import Text

from cli.infrastructure.console import get_console
from cli.infrastructure.formatters.base import ColumnMeta, Formatter


# Default styles for compact format columns
DEFAULT_STYLES = {
    "id": "cyan",
    "uuid": "cyan",
    "name": "white bold",
    "type": "magenta",
    "model": "green",
    "provider": "green",
    "date": "blue",
    "created": "blue",
    "time": "blue",
    "version": "yellow",
    "visibility": "dim",
    "tags": "dim italic",
    "description": "dim",
    "content": "dim",
    "status": "yellow",
}


def _infer_style(label: str) -> str:
    """Infer a style based on column label.

    Args:
        label: Column header label

    Returns:
        Rich style string
    """
    label_lower = label.lower()
    for key, style in DEFAULT_STYLES.items():
        if key in label_lower:
            return style
    return "white"


class CompactFormatter(Formatter):
    """Formatter that renders items as compact 2-line blocks.

    Line 1: Primary metadata (ID, type, model, date) - colored, spaced
    Line 2: Detail content (description, content preview) - dimmed, indented

    Benefits:
    - No borders = double-click to select any field
    - Line 2 wraps naturally on narrow terminals
    - Easy to scan vertically (IDs align, models align)
    """

    def __init__(self, console: Console | None = None):
        """Initialize compact formatter.

        Args:
            console: Optional Rich console instance. Uses shared console if not provided.
        """
        self.console = console or get_console()

    def format_entity(self, data: dict[str, Any], title: str | None = None) -> Text:
        """Format entity details as compact key-value block.

        For single entities, we use a simple key: value format without borders.

        Args:
            data: Dictionary mapping field labels to values
            title: Optional title for the entity

        Returns:
            Rich Text object ready for rendering
        """
        output = Text()

        if title:
            output.append(f"{title}\n", style="bold")
            output.append("-" * len(title) + "\n", style="dim")

        for field, value in data.items():
            display_value = "-" if value is None else str(value)
            output.append(f"{field}: ", style="cyan")
            output.append(f"{display_value}\n", style="white")

        return output

    def format_list(
        self,
        items: list[dict[str, Any]],
        title: str | None = None,
        columns: list[ColumnMeta] | None = None,
    ) -> Group:
        """Format list of items as compact 2-line blocks.

        Args:
            items: List of dictionaries representing rows
            title: Optional title for the list
            columns: Column metadata for layout (line assignment, styles)

        Returns:
            Rich Group of Text objects ready for rendering
        """
        if not items:
            return Group(Text(self.format_info("No items to display")))

        renderables: list[RenderableType] = []

        # Add title if provided
        if title:
            title_text = Text()
            title_text.append(f"{title}\n", style="bold")
            renderables.append(title_text)

        # Build column lookup by label
        col_meta_map: dict[str, ColumnMeta] = {}
        if columns:
            for col in columns:
                col_meta_map[col.label] = col

        # Separate columns into line 1 (primary) and line 2 (detail)
        line1_labels: list[str] = []
        line2_labels: list[str] = []
        if columns:
            for col in columns:
                if col.compact_line == 2:
                    line2_labels.append(col.label)
                else:
                    line1_labels.append(col.label)
        else:
            # Fallback: all columns on line 1
            if items:
                line1_labels = list(items[0].keys())

        # Render each item as a 2-line block
        for item in items:
            block = Text()

            # Line 1: Primary metadata (spaced columns)
            line1_parts: list[tuple[str, str]] = []
            for label in line1_labels:
                raw_value = item.get(label)
                if raw_value is None:
                    value = "-"
                else:
                    value = str(raw_value)

                # Get style from column meta or infer from label
                meta = col_meta_map.get(label)
                if meta and meta.compact_style:
                    style: str = meta.compact_style
                else:
                    style = _infer_style(label)

                # Apply width padding if specified
                if meta and meta.width:
                    value = f"{value:<{meta.width}}"

                line1_parts.append((value, style))

            # Join line 1 parts with double space
            for i, (value, style) in enumerate(line1_parts):
                if i > 0:
                    block.append("  ", style="default")
                block.append(value, style=style)

            block.append("\n")

            # Line 2: Detail content (indented, dimmed)
            if line2_labels:
                detail_parts: list[tuple[str, str]] = []
                for label in line2_labels:
                    raw_value = item.get(label)
                    if raw_value is None or raw_value == "-":
                        continue
                    value = str(raw_value)

                    # Get style - default to dim for detail line
                    meta = col_meta_map.get(label)
                    if meta and meta.compact_style:
                        style = meta.compact_style
                    else:
                        style = "dim"

                    detail_parts.append((value, style))

                if detail_parts:
                    block.append("   ")  # 3-space indent
                    for i, (value, style) in enumerate(detail_parts):
                        if i > 0:
                            block.append(" · ", style="dim")
                        block.append(value, style=style)
                    block.append("\n")

            # Add blank line between items
            block.append("\n")
            renderables.append(block)

        return Group(*renderables)

    def format_success(self, message: str) -> str:
        """Format success message with checkmark.

        Args:
            message: Success message text

        Returns:
            Rich markup string
        """
        return f"[green]✓[/green] {message}"

    def format_info(self, message: str) -> str:
        """Format info message with info icon.

        Args:
            message: Info message text

        Returns:
            Rich markup string
        """
        return f"[blue]ℹ[/blue] {message}"

    def format_warning(self, message: str) -> str:
        """Format warning message with warning icon.

        Args:
            message: Warning message text

        Returns:
            Rich markup string
        """
        return f"[yellow]⚠[/yellow] {message}"
