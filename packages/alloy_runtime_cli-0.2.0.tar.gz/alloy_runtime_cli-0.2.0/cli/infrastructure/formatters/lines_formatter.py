"""Lines formatter for easy-to-copy terminal output.

Outputs each field on its own line, making individual values easy to copy
without table formatting artifacts.
"""

from typing import Any

from cli.infrastructure.formatters.base import ColumnMeta, Formatter


class LinesFormatter(Formatter):
    """Formatter that outputs each field on its own line for easy copying."""

    def format_entity(self, data: dict[str, Any], title: str | None = None) -> str:
        """Format entity as key-value lines.

        Args:
            data: Dictionary mapping field labels to values
            title: Optional title displayed above the data

        Returns:
            String with each field on its own line
        """
        lines: list[str] = []

        if title:
            lines.append(title)
            lines.append("-" * len(title))

        for field, value in data.items():
            display_value = "(not set)" if value is None else str(value)
            lines.append(f"{field}: {display_value}")

        return "\n".join(lines)

    def format_list(
        self,
        items: list[dict[str, Any]],
        title: str | None = None,
        columns: list[ColumnMeta] | None = None,
    ) -> str:
        """Format list as blocks of key-value lines.

        Args:
            items: List of dictionaries, each representing one item
            title: Optional title displayed above the list

        Returns:
            String with each item as a block separated by blank lines
        """
        if not items:
            return self.format_info("No items to display")

        lines: list[str] = []

        if title:
            lines.append(title)
            lines.append("=" * len(title))
            lines.append("")

        for i, item in enumerate(items, start=1):
            lines.append(f"--- Item {i} ---")
            for field, value in item.items():
                display_value = "(not set)" if value is None else str(value)
                lines.append(f"{field}: {display_value}")
            lines.append("")  # Blank line between items

        return "\n".join(lines).rstrip()

    def format_success(self, message: str) -> str:
        """Format success message with prefix.

        Args:
            message: Success message text

        Returns:
            Prefixed success message
        """
        return f"[OK] {message}"

    def format_info(self, message: str) -> str:
        """Format info message with prefix.

        Args:
            message: Info message text

        Returns:
            Prefixed info message
        """
        return f"[INFO] {message}"

    def format_warning(self, message: str) -> str:
        """Format warning message with prefix.

        Args:
            message: Warning message text

        Returns:
            Prefixed warning message
        """
        return f"[WARN] {message}"
