"""Base formatter interface for CLI output.

Defines the contract that all output formatters must implement.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


@dataclass
class ColumnMeta:
    """Metadata about a column for formatters that need layout info.

    This is a simplified view of ColumnConfig passed to formatters.
    """

    label: str
    compact_line: int = 1
    compact_style: str | None = None
    width: int | None = None


class Formatter(ABC):
    """Abstract base class for output formatters.

    Formatters transform data into specific output formats (Rich tables, JSON, YAML, etc.).
    """

    @abstractmethod
    def format_entity(self, data: dict[str, Any], title: str | None = None) -> Any:
        """Format a single entity's details as key-value pairs.

        Args:
            data: Dictionary mapping field labels to values
            title: Optional title for the entity display

        Returns:
            Formatted output (str for JSON, Rich renderable for Rich, etc.)
        """
        pass

    @abstractmethod
    def format_list(
        self,
        items: list[dict[str, Any]],
        title: str | None = None,
        columns: list[ColumnMeta] | None = None,
    ) -> Any:
        """Format a list of items as a table or similar structure.

        Args:
            items: List of dictionaries, each representing one row
            title: Optional title for the list display
            columns: Optional column metadata for layout-aware formatters

        Returns:
            Formatted output (str for JSON, Rich renderable for Rich, etc.)
        """
        pass

    @abstractmethod
    def format_success(self, message: str) -> str:
        """Format a success message.

        Args:
            message: Success message text

        Returns:
            Formatted success message
        """
        pass

    @abstractmethod
    def format_info(self, message: str) -> str:
        """Format an informational message.

        Args:
            message: Info message text

        Returns:
            Formatted info message
        """
        pass

    @abstractmethod
    def format_warning(self, message: str) -> str:
        """Format a warning message.

        Args:
            message: Warning message text

        Returns:
            Formatted warning message
        """
        pass
