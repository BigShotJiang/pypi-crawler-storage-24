"""Error display using Rich panels.

Centralizes error formatting for consistent, user-friendly error messages.
"""

from rich.panel import Panel

from cli.infrastructure.config import ConfigurationError
from cli.infrastructure.console import get_console
from alloy_runtime_sdk.exceptions.errors import (
    AuthenticationError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    RequestError,
    ServerError,
    ValidationError,
)


def display_error(error: Exception) -> None:
    """Display an error in a Rich panel with appropriate styling.

    Args:
        error: Exception to display
    """
    if isinstance(error, ConfigurationError):
        _display_configuration_error(error)
    elif isinstance(error, AuthenticationError):
        _display_authentication_error(error)
    elif isinstance(error, ForbiddenError):
        _display_forbidden_error(error)
    elif isinstance(error, NotFoundError):
        _display_not_found_error(error)
    elif isinstance(error, ValidationError):
        _display_validation_error(error)
    elif isinstance(error, ConflictError):
        _display_conflict_error(error)
    elif isinstance(error, RequestError):
        _display_request_error(error)
    elif isinstance(error, ServerError):
        _display_server_error(error)
    else:
        _display_unexpected_error(error)


def _display_configuration_error(error: ConfigurationError) -> None:
    """Display configuration error panel."""
    console = get_console()
    console.print(
        Panel(
            f"[red]Configuration Error[/red]\n\n{str(error)}",
            title="⚙️  Configuration Required",
            border_style="red",
        )
    )


def _display_authentication_error(error: AuthenticationError) -> None:
    """Display authentication error panel."""
    console = get_console()
    console.print(
        Panel(
            f"[red]Authentication Failed[/red]\n\n{str(error)}\n\n"
            "Please check your ALLOY_RUNTIME_API_KEY environment variable.\n"
            "Ensure you have a valid API key with appropriate permissions.",
            title="❌ Authentication Error",
            border_style="red",
        )
    )


def _display_forbidden_error(error: ForbiddenError) -> None:
    """Display forbidden error panel."""
    console = get_console()
    console.print(
        Panel(
            f"[red]Access Forbidden[/red]\n\n{str(error)}\n\n"
            "Your API key does not have permission to perform this operation.\n"
            "System credential management requires system admin privileges.",
            title="🚫 Forbidden",
            border_style="red",
        )
    )


def _display_not_found_error(error: NotFoundError) -> None:
    """Display not found error panel."""
    console = get_console()
    console.print(
        Panel(
            f"[yellow]Resource Not Found[/yellow]\n\n{str(error)}\n\n"
            "Please verify the credential ID is correct.\n"
            "Use the credentials list command to see available credentials.",
            title="⚠️  Not Found",
            border_style="yellow",
        )
    )


def _display_validation_error(error: ValidationError) -> None:
    """Display validation error panel."""
    console = get_console()
    error_lines = ["[red]Validation Failed[/red]\n"]

    if error.errors:
        error_lines.append("The following validation errors occurred:\n")
        for err in error.errors:
            # Extract field path and message from error dict
            field = " -> ".join(str(loc) for loc in err.get("loc", []))
            message = err.get("msg", "Unknown error")
            error_lines.append(f"  • [cyan]{field}[/cyan]: {message}")
    else:
        error_lines.append(str(error))

    console.print(
        Panel(
            "\n".join(error_lines),
            title="❌ Validation Error",
            border_style="red",
        )
    )


def _display_conflict_error(error: ConflictError) -> None:
    """Display conflict error panel."""
    console = get_console()
    console.print(
        Panel(
            f"[yellow]Conflict Detected[/yellow]\n\n{str(error)}\n\n"
            "The requested operation conflicts with existing data.",
            title="⚠️  Conflict",
            border_style="yellow",
        )
    )


def _display_request_error(error: RequestError) -> None:
    """Display request/network error panel."""
    console = get_console()
    console.print(
        Panel(
            f"[red]Request Failed[/red]\n\n{str(error)}\n\n"
            "Possible causes:\n"
            "  • Network connectivity issues\n"
            "  • Server is not running\n"
            "  • Incorrect ALLOY_RUNTIME_API_URL\n"
            "  • Request timeout",
            title="🌐 Network Error",
            border_style="red",
        )
    )


def _display_server_error(error: ServerError) -> None:
    """Display server error panel."""
    console = get_console()
    console.print(
        Panel(
            f"[red]Server Error[/red]\n\n{str(error)}\n\n"
            "The server encountered an internal error.\n"
            "Please try again.",
            title="❌ Server Error",
            border_style="red",
        )
    )


def _display_unexpected_error(error: Exception) -> None:
    """Display unexpected error panel."""
    console = get_console()
    console.print(
        Panel(
            f"[red]Unexpected Error[/red]\n\n{type(error).__name__}: {str(error)}",
            title="❌ Error",
            border_style="red",
        )
    )
