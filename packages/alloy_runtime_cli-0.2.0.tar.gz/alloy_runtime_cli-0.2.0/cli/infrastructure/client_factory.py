"""Factory for creating configured ApiClient instances."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from alloy_runtime_sdk.api_client.client import ApiClient

from cli.infrastructure.config import CLIConfig


@asynccontextmanager
async def create_client(config: CLIConfig) -> AsyncIterator[ApiClient]:
    """Create a configured ApiClient instance.

    This factory encapsulates the ApiClient creation and configuration,
    ensuring proper async context management and resource cleanup.

    Args:
        config: Validated CLI configuration

    Yields:
        Configured ApiClient ready for API calls

    Example:
        ```python
        config = load_config()
        async with create_client(config) as client:
            response = await client.update_system_credential(...)
        ```
    """
    async with ApiClient(
        base_url=config.api_url,
        api_key=config.api_key,
        timeout=config.timeout,
    ) as client:
        yield client
