"""Reusable styled form components for Textual apps.

This module provides low-level, styled form components that can be composed
to create consistent-looking forms across the CLI. Each component is just
a styled wrapper - you wire up your own logic.

Usage:
    from cli.infrastructure.forms.components import (
        FormContainer,
        FormTitle,
        FormSection,
        FormField,
        FormRow,
        FormButtons,
        FormError,
    )

    def compose(self) -> ComposeResult:
        with FormContainer():
            yield FormTitle("Create Something")
            yield FormError(id="error")

            yield FormSection("Required")
            with FormRow():
                yield FormField("Name", Input(id="name"))
                yield FormField("Type", Select(..., id="type"))

            yield FormSection("Optional")
            with FormRow():
                yield FormField("Description", Input(id="desc"))

            yield FormButtons()
"""

from typing import Any

from textual.app import ComposeResult
from textual.containers import Center, Horizontal, Vertical, VerticalScroll
from textual.widget import Widget
from textual.widgets import Button, Static


class FormContainer(VerticalScroll):
    """Scrollable container for a form."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.add_class("form-container")


class FormTitle(Static):
    """Centered form title."""

    def __init__(self, title: str, **kwargs: Any) -> None:
        super().__init__(title, **kwargs)
        self.add_class("form-title")


class FormSection(Static):
    """Section header within a form."""

    def __init__(self, title: str, **kwargs: Any) -> None:
        super().__init__(title, **kwargs)
        self.add_class("form-section")


class FormField(Vertical):
    """A labeled form field container. Pass any widget as the input."""

    def __init__(self, label: str, input_widget: Widget, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.add_class("form-field")
        self._label = label
        self._input_widget = input_widget

    def compose(self) -> ComposeResult:
        yield Static(self._label, classes="form-field-label")
        yield self._input_widget


class FormRow(Horizontal):
    """Horizontal row for side-by-side fields."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.add_class("form-row")


class FormError(Static):
    """Error message display. Call show(msg) and hide()."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__("", **kwargs)
        self.add_class("form-error")

    def show(self, message: str) -> None:
        """Show an error message."""
        self.update(f"Error: {message}")
        self.add_class("visible")

    def hide(self) -> None:
        """Hide the error message."""
        self.remove_class("visible")


class FormButtons(Center):
    """Centered submit/cancel button row."""

    def __init__(
        self,
        submit_label: str = "Submit",
        cancel_label: str = "Cancel",
        submit_id: str = "submit-btn",
        cancel_id: str = "cancel-btn",
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.add_class("form-buttons")
        self._submit_label = submit_label
        self._cancel_label = cancel_label
        self._submit_id = submit_id
        self._cancel_id = cancel_id

    def compose(self) -> ComposeResult:
        yield Button(self._submit_label, id=self._submit_id, variant="success")
        yield Button(self._cancel_label, id=self._cancel_id, variant="error")
