"""Unified console service for all CLI output.

This is the single source of truth for console output. All features
MUST use this module for output instead of creating their own Console.
"""

from rich.console import Console
from rich.prompt import Confirm, Prompt

# Singleton console instance
_console: Console | None = None


def get_console() -> Console:
    """Get the global console instance.

    Returns:
        Shared Console instance for all CLI output
    """
    global _console
    if _console is None:
        _console = Console()
    return _console


# Re-export Rich prompts for convenience
__all__ = ["get_console", "Prompt", "Confirm"]
