"""Message display widget for rendering chat message history."""

from typing import TYPE_CHECKING, Callable

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.widget import Widget
from textual.widgets import Static

from cli.tui.chat.messages import CopyToClipboardRequested
from cli.tui.chat.renderers.markdown import MarkdownRenderer
from cli.tui.chat.renderers.plain import PlainTextRenderer
from cli.tui.chat.store import ChatStore
from cli.tui.chat.types import (
    ChatPhase,
    ChatState,
    MessageRenderer,
    RenderMode,
    extract_message_text,
)
from cli.tui.chat.widgets.welcome_screen import WelcomeScreen

if TYPE_CHECKING:
    from cli.tui.app import AlloyRuntimeApp


class MessageDisplay(Widget):
    """Widget for displaying chat message history.

    Features:
        - Renders message history with timestamps
        - Shows streaming content in real-time
        - Auto-scrolls to bottom on new content (unless user scrolls up)
        - Supports copying last response
        - Pluggable renderer for different output formats

    Posts Messages:
        - CopyToClipboardRequested: When user triggers copy action

    Auto-scroll behavior:
        - During streaming, auto-scrolls to bottom unless user has scrolled up
        - User scrolling up during streaming disables auto-scroll
        - User scrolling back to bottom (or pressing G) re-enables auto-scroll
        - Auto-scroll is always re-enabled when streaming ends
    """

    app: "AlloyRuntimeApp"

    BINDINGS = [
        Binding("ctrl+y", "copy_last", "Copy Last", show=False),
        Binding("ctrl+shift+y", "copy_all", "Copy All", show=False),
        Binding("g", "scroll_top", "Top", show=False),
        Binding("G", "scroll_bottom", "Bottom", show=False),
    ]

    def __init__(
        self,
        store: ChatStore,
        renderer: MessageRenderer | None = None,
    ) -> None:
        """Initialize the message display.

        Args:
            store: ChatStore instance for state management.
            renderer: Optional renderer for message formatting. Defaults to MarkdownRenderer.
        """
        super().__init__()
        self._store = store
        self._custom_renderer: MessageRenderer | None = renderer
        self._markdown_renderer = MarkdownRenderer()
        self._plain_renderer = PlainTextRenderer()
        self._unsubscribe: Callable[[], None] | None = None
        # Auto-scroll is enabled by default; disabled when user scrolls up during streaming
        self._auto_scroll_enabled = True
        # Track whether welcome screen is currently shown
        self._welcome_screen_visible = False

    def _get_renderer(self, state: ChatState) -> MessageRenderer:
        """Get the appropriate renderer based on state."""
        if self._custom_renderer:
            return self._custom_renderer
        if state.render_mode == RenderMode.PLAIN:
            return self._plain_renderer
        return self._markdown_renderer

    def compose(self) -> ComposeResult:
        """Compose the message display layout."""
        with VerticalScroll(id="message-scroll"):
            # Start with welcome screen visible, messages hidden
            yield WelcomeScreen(id="welcome-screen")
            messages_widget = Static("", id="messages")
            messages_widget.display = False
            yield messages_widget
        self._welcome_screen_visible = True

    def on_mount(self) -> None:
        """Subscribe to store on mount."""
        self._unsubscribe = self._store.subscribe(self._on_state_change)

    def on_unmount(self) -> None:
        """Unsubscribe from store on unmount."""
        if self._unsubscribe:
            self._unsubscribe()

    def _on_state_change(self, state: ChatState) -> None:
        """React to store state changes."""
        self._render_messages(state)

    def _is_at_bottom(self) -> bool:
        """Check if scroll is at or near the bottom."""
        scroll = self.query_one("#message-scroll", VerticalScroll)
        # Consider "at bottom" if within 50 pixels of the end
        # Also consider at bottom if max_scroll is 0 (content fits in view)
        return scroll.max_scroll_y <= 0 or scroll.scroll_y >= scroll.max_scroll_y - 50

    def _render_messages(self, state: ChatState) -> None:
        """Render messages to the display using the configured renderer."""
        messages_widget = self.query_one("#messages", Static)
        messages = state.messages
        streaming_content = state.streaming_content
        streaming_thinking_content = state.streaming_thinking_content
        pending_user_message = state.pending_user_message
        is_streaming = state.phase == ChatPhase.STREAMING

        # Check scroll position BEFORE rendering to detect user scroll-up
        # If streaming and not at bottom, user must have scrolled up
        if is_streaming and not self._is_at_bottom():
            self._auto_scroll_enabled = False

        # Get assistant name from session context
        assistant_name = "Assistant"
        if state.session:
            assistant_name = state.session.display_name

        # Check if we have anything to show
        has_content = (
            messages
            or streaming_content
            or streaming_thinking_content
            or pending_user_message
        )

        # Determine if welcome screen should be visible
        should_show_welcome = state.session is None and not has_content

        # Switch between welcome screen and messages display
        if should_show_welcome != self._welcome_screen_visible:
            self._toggle_welcome_screen(should_show_welcome)

        if should_show_welcome:
            # Welcome screen handles its own content
            return

        if not has_content:
            # Session exists but no messages yet
            messages_widget.update(
                "[dim]No messages yet. Type below and press Ctrl+D to send.[/]"
            )
            return

        # Delegate rendering to the appropriate renderer based on state
        renderer = self._get_renderer(state)
        rendered_content = renderer.render(
            messages,
            streaming_content=streaming_content,
            streaming_thinking_content=streaming_thinking_content,
            pending_user_message=pending_user_message,
            assistant_name=assistant_name,
            is_streaming=is_streaming,
            thinking_collapsed=state.thinking_collapsed,
        )
        messages_widget.update(rendered_content)

        # Auto-scroll if enabled
        if self._auto_scroll_enabled:
            self._scroll_to_bottom()

        # Re-enable auto-scroll when streaming ends
        if not is_streaming:
            self._auto_scroll_enabled = True

    def _scroll_to_bottom(self) -> None:
        """Scroll the message view to the bottom."""
        scroll = self.query_one("#message-scroll", VerticalScroll)
        scroll.scroll_end(animate=False)

    def _toggle_welcome_screen(self, show_welcome: bool) -> None:
        """Toggle between welcome screen and messages display.

        Args:
            show_welcome: If True, show welcome screen; if False, show messages.
        """
        try:
            welcome_screen = self.query_one("#welcome-screen", WelcomeScreen)
            messages_widget = self.query_one("#messages", Static)

            welcome_screen.display = show_welcome
            messages_widget.display = not show_welcome
            self._welcome_screen_visible = show_welcome

            # Refresh welcome screen data when showing it
            if show_welcome:
                welcome_screen.refresh_data()
        except Exception:
            # Widgets may not be mounted yet during initial compose
            pass

    def _get_welcome_message(self) -> str:
        """Get the welcome message for new sessions."""
        return """[bold]Welcome to Alloy Runtime![/]

[dim]Select a session from the sidebar or press Ctrl+N to start a new chat.[/]

[bold cyan]Features:[/]
- Browse and resume previous chat sessions
- Start new conversations with agents or models
- Stream responses in real-time
- Compose messages in your $EDITOR

[bold cyan]Keyboard shortcuts:[/]
  Ctrl+D         Send message
  Ctrl+N         New chat session
  Ctrl+E         Open message in $EDITOR
  Ctrl+B         Toggle sidebar
  Ctrl+R         Regenerate last response
  Ctrl+U         Undo last turn
  Ctrl+Y         Copy last response
  Ctrl+Shift+Y   Copy all messages
  /              Search sessions

[bold cyan]Tip:[/] Hold Shift while clicking to use native terminal text selection.
"""

    def action_copy_last(self) -> None:
        """Copy the last assistant response to clipboard."""
        messages = self._store.state.messages

        if not messages:
            self.app.notify("No messages to copy", severity="warning")
            return

        # Find last assistant message
        for msg in reversed(messages):
            if msg.role == "assistant":
                text = extract_message_text(msg)
                if text:
                    self.post_message(CopyToClipboardRequested(text, "Last response"))
                    return

        self.app.notify("No assistant message to copy", severity="warning")

    def action_copy_all(self) -> None:
        """Copy all messages to clipboard as plain text."""
        messages = self._store.state.messages

        if not messages:
            self.app.notify("No messages to copy", severity="warning")
            return

        # Build plain text version of all messages
        lines: list[str] = []
        for msg in messages:
            role = msg.role.capitalize()
            text = extract_message_text(msg)
            if text:
                lines.append(f"{role}:\n{text}\n")

        if lines:
            full_text = "\n".join(lines)
            self.post_message(CopyToClipboardRequested(full_text, "All messages"))
        else:
            self.app.notify("No message content to copy", severity="warning")

    def action_scroll_top(self) -> None:
        """Scroll to the top of messages."""
        scroll = self.query_one("#message-scroll", VerticalScroll)
        scroll.scroll_home(animate=False)

    def action_scroll_bottom(self) -> None:
        """Scroll to the bottom of messages and resume auto-scroll."""
        self._auto_scroll_enabled = True
        self._scroll_to_bottom()

    def show_welcome(self) -> None:
        """Show the welcome screen."""
        self._toggle_welcome_screen(show_welcome=True)
