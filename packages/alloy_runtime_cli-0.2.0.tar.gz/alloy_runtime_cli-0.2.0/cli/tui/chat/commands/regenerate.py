"""Command for regenerating the last AI response."""

from dataclasses import dataclass
from typing import Callable
from uuid import UUID

from alloy_runtime_sdk.api_client.client import ApiClient
from alloy_runtime_types.dtos.generation import (
    AgentSource,
    DirectModelSource,
    GenerateTextRequest,
)
from alloy_runtime_types.enums.provider import Provider
from alloy_runtime_sdk.logging.config import get_logger

from cli.tui.chat.commands.base import CommandResult
from cli.tui.chat.store import ChatStore

logger = get_logger(__name__)


@dataclass
class RegenerateCommand:
    """Command to regenerate the last AI response.

    Supports two modes:
    - Agent mode: Uses agent_id to determine model and system instruction
    - Model mode: Uses provider_key/provider_model_name/system_instruction directly

    This command:
    1. Transitions store to STREAMING phase
    2. Sends a regenerate request to the API
    3. Streams the new response chunks via callbacks (content and thinking)
    4. Transitions back to IDLE when complete

    Attributes:
        client: Server client for API calls.
        store: Chat store for state management.
        session_id: ID of the current chat session.
        on_chunk: Callback invoked with each streamed text chunk.
        on_thinking_chunk: Callback invoked with each reasoning/thinking chunk.
        agent_id: ID of the agent to use for regeneration (agent mode).
        provider_key: Provider key (model mode).
        provider_model_name: Model name (model mode).
        system_instruction: System instruction (model mode).
    """

    client: ApiClient
    store: ChatStore
    session_id: UUID
    on_chunk: Callable[[str], None]
    on_thinking_chunk: Callable[[str], None] | None = None
    # Agent mode
    agent_id: UUID | None = None
    # Model mode
    provider_key: str | None = None
    provider_model_name: str | None = None
    system_instruction: str | None = None

    async def execute(self) -> CommandResult[None]:
        """Execute the regenerate response operation.

        Returns:
            CommandResult indicating success or failure.
        """
        logger.info("regenerate_starting", session_id=str(self.session_id))
        self.store.start_streaming()

        was_cancelled = False
        try:
            # Build model source based on mode
            if self.agent_id is not None:
                model_source = AgentSource(agent=self.agent_id)
            elif self.provider_key and self.provider_model_name:
                model_source = DirectModelSource(
                    provider_key=Provider(self.provider_key),
                    provider_model_name=self.provider_model_name,
                )
            else:
                return CommandResult[None](
                    success=False,
                    error="No agent or model configured for this session",
                )

            request = GenerateTextRequest(
                model_source=model_source,
                chat_session_id=self.session_id,
                regenerate=True,
                stream=True,
                tags=[],
                # Only include system instruction for model mode
                system_instruction=self.system_instruction
                if self.agent_id is None
                else None,
            )

            async for chunk in self.client.generate_text_stream(request):
                # Check for cancellation request
                if self.store.state.cancel_requested:
                    logger.info("regenerate_cancelled_by_user")
                    was_cancelled = True
                    return CommandResult[None](success=True, data=None)

                # Handle thinking/reasoning chunks
                if chunk.chunk_type == "thinking" and chunk.reasoning_content:
                    if self.on_thinking_chunk:
                        self.on_thinking_chunk(chunk.reasoning_content)
                # Handle regular text content chunks
                elif chunk.content:
                    self.on_chunk(chunk.content)

            logger.info("regenerate_completed")
            return CommandResult[None](success=True, data=None)

        except Exception as e:
            logger.warning("regenerate_failed", error=str(e))
            return CommandResult[None](success=False, error=str(e))

        finally:
            self.store.finish_streaming(cancelled=was_cancelled)
