"""Base utilities for message renderers.

Provides common functionality used by all renderer implementations.
"""

from alloy_runtime_types.dtos.sessions import MessageResponse

from cli.tui.chat.types import (
    extract_message_text,
    extract_message_text_for_display,
    format_time,
)


def format_user_header(msg: MessageResponse, *, include_time: bool = True) -> str:
    """Format a user message header.

    Args:
        msg: The message to format.
        include_time: Whether to include the timestamp.

    Returns:
        Formatted header string.
    """
    if include_time:
        return f"You [{format_time(msg.created_at)}]:"
    return "You:"


def format_assistant_header(msg: MessageResponse, *, include_time: bool = True) -> str:
    """Format an assistant message header.

    Args:
        msg: The message to format.
        include_time: Whether to include the timestamp.

    Returns:
        Formatted header string.
    """
    if include_time:
        return f"Assistant [{format_time(msg.created_at)}]:"
    return "Assistant:"


def get_message_body(msg: MessageResponse) -> str:
    """Extract the body text from a message.

    Args:
        msg: The message to extract text from.

    Returns:
        Message body text.
    """
    return extract_message_text(msg)


def get_message_body_for_display(msg: MessageResponse) -> tuple[str, bool]:
    """Extract the body text from a message, truncating long content.

    Long content (e.g., from @fragment() injections) is truncated to prevent
    overwhelming the TUI. The first/last 50 chars are shown with a truncation
    indicator.

    Args:
        msg: The message to extract text from.

    Returns:
        Tuple of (body_text, was_truncated)
        - body_text: The message body, possibly truncated
        - was_truncated: True if any content was truncated
    """
    return extract_message_text_for_display(msg)
