"""StatusFooter widget - vim-style status bar with notification support.

This widget replaces both the standard Footer and toast notifications with
a unified status bar that shows keyboard shortcuts by default and temporarily
displays notifications.
"""

from typing import Any

from textual.app import ComposeResult
from textual.containers import Container
from textual.reactive import reactive
from textual.timer import Timer
from textual.widget import Widget
from textual.widgets import Footer, Static


class StatusFooter(Widget):
    """A footer that can show temporary notifications in place of key bindings.

    By default, displays keyboard shortcuts like the standard Footer.
    When show_notification() is called, temporarily shows the notification
    message with appropriate styling, then reverts to shortcuts.

    This is implemented as a container that swaps between a Footer widget
    and a notification Static widget.
    """

    DEFAULT_CSS = """
    StatusFooter {
        dock: bottom;
        height: 1;
        width: 100%;
    }

    StatusFooter > Container {
        height: 1;
        width: 100%;
    }

    StatusFooter Footer {
        height: 1;
    }

    StatusFooter .notification-bar {
        height: 1;
        width: 100%;
        padding: 0 1;
        display: none;
    }

    StatusFooter .notification-bar.visible {
        display: block;
    }

    StatusFooter .notification-bar.info {
        background: $primary;
        color: $text;
    }

    StatusFooter .notification-bar.success {
        background: $success;
        color: $text;
    }

    StatusFooter .notification-bar.warning {
        background: $warning;
        color: $text;
    }

    StatusFooter .notification-bar.error {
        background: $error;
        color: $text;
    }

    StatusFooter Footer.hidden {
        display: none;
    }
    """

    notification_active: reactive[bool] = reactive(False)

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the status footer."""
        super().__init__(**kwargs)
        self._notification_timer: Timer | None = None

    def compose(self) -> ComposeResult:
        """Compose the footer with both normal footer and notification bar."""
        with Container():
            # Footer shows key hints for all tabs
            yield Footer(id="footer-keys")
            yield Static("", id="notification-bar", classes="notification-bar")

    def show_notification(
        self,
        message: str,
        severity: str = "information",
        timeout: float = 2.0,
    ) -> None:
        """Show a notification message temporarily.

        Args:
            message: The notification message to display
            severity: One of "information", "warning", "error"
            timeout: Seconds before reverting to shortcuts (default 3.0)
        """
        # Cancel any existing timer
        if self._notification_timer is not None:
            self._notification_timer.stop()
            self._notification_timer = None

        # Update notification bar content and styling
        notification_bar = self.query_one("#notification-bar", Static)
        footer = self.query_one("#footer-keys", Footer)

        # Set the message
        notification_bar.update(message)

        # Reset classes and apply severity
        notification_bar.remove_class("info", "success", "warning", "error")
        severity_class = {
            "information": "info",
            "success": "success",
            "warning": "warning",
            "error": "error",
        }.get(severity, "info")
        notification_bar.add_class(severity_class)

        # Show notification, hide footer
        notification_bar.add_class("visible")
        footer.add_class("hidden")
        self.notification_active = True

        # Schedule clearing the notification
        self._notification_timer = self.set_timer(timeout, self._clear_notification)

    def _clear_notification(self) -> None:
        """Clear the notification and show shortcuts again."""
        notification_bar = self.query_one("#notification-bar", Static)
        footer = self.query_one("#footer-keys", Footer)

        # Hide notification, show footer
        notification_bar.remove_class("visible")
        footer.remove_class("hidden")
        self.notification_active = False
        self._notification_timer = None
