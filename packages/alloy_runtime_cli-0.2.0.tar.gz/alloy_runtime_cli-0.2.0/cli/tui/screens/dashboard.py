"""Dashboard screen for quick navigation.

A minimal, keyboard-first landing screen that allows instant navigation
with single keystrokes. Shown on app launch and accessible via keybinding.
"""

from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.screen import Screen
from textual.widgets import Static

if TYPE_CHECKING:
    from cli.tui.app import AlloyRuntimeApp


DASHBOARD_CONTENT = r"""
    _    ___    ____ _           _   _            
   / \  |_ _|  / ___| |__   __ _| |_| |_ ___ _ __ 
  / _ \  | |  | |   | '_ \ / _` | __| __/ _ \ '__|
 / ___ \ | |  | |___| | | | (_| | |_| ||  __/ |   
/_/   \_\___|  \____|_| |_|\__,_|\__|\__\___|_|   


  [C]  Chat          start a conversation
  [A]  Agents        browse & manage
  [T]  Templates     prompt library
  [M]  Content       media objects
  [S]  Schemas       output structures

       [?] help   [Q] quit
"""


class DashboardScreen(Screen[str]):
    """Quick-launch dashboard for instant navigation.

    Displays on app launch and allows single-keystroke navigation to any
    main section. Returns the selected screen ID when dismissed.
    """

    app: "AlloyRuntimeApp"

    BINDINGS = [
        Binding("c", "goto('chat')", "Chat", show=False),
        Binding("a", "goto('agents')", "Agents", show=False),
        Binding("t", "goto('templates')", "Templates", show=False),
        Binding("m", "goto('content')", "Content", show=False),
        Binding("s", "goto('schemas')", "Schemas", show=False),
        Binding("q", "quit", "Quit", show=False),
        Binding("question_mark", "show_help", "Help", show=False),
    ]

    DEFAULT_CSS = """
    DashboardScreen {
        align: center middle;
    }

    DashboardScreen > Container {
        width: auto;
        height: auto;
    }

    DashboardScreen Static {
        width: auto;
        height: auto;
        text-align: center;
    }
    """

    def compose(self) -> ComposeResult:
        with Container():
            yield Static(DASHBOARD_CONTENT, id="dashboard-content")

    def action_goto(self, screen_id: str) -> None:
        """Navigate to a screen by dismissing with the screen ID."""
        self.dismiss(screen_id)

    def action_quit(self) -> None:
        """Quit the application."""
        self.app.exit()

    def action_show_help(self) -> None:
        """Show help modal."""
        from cli.tui.widgets.help_modal import HelpModal

        self.app.push_screen(HelpModal())
