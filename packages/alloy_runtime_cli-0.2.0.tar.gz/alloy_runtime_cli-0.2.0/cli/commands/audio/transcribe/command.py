"""Audio transcribe command implementation."""

import mimetypes
import sys
from pathlib import Path

import typer

from cli.infrastructure.command import async_command, authenticated_client

MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024  # 25 MB
DEFAULT_POLL_TIMEOUT_SECONDS = 300.0


def resolve_audio_input(file: str) -> tuple[bytes, str, str]:
    """Validate and read audio input from a file path or stdin.

    Args:
        file: File path to an audio file, or '-' for stdin.

    Returns:
        Tuple of (file_bytes, filename, content_type).

    Raises:
        typer.BadParameter: If the file is not found, not readable,
            or exceeds the 25MB size limit.
    """
    if file == "-":
        return _read_stdin()

    return _read_file(file)


def _read_stdin() -> tuple[bytes, str, str]:
    """Read audio bytes from stdin.

    Returns:
        Tuple of (file_bytes, filename, content_type).

    Raises:
        typer.BadParameter: If stdin data exceeds size limit.
    """
    file_bytes = sys.stdin.buffer.read()
    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        size_mb = len(file_bytes) / (1024 * 1024)
        raise typer.BadParameter(
            f"Stdin data ({size_mb:.1f} MB) exceeds the 25 MB upload limit."
        )
    return file_bytes, "audio.wav", "audio/wav"


def _read_file(file: str) -> tuple[bytes, str, str]:
    """Read and validate an audio file from disk.

    Args:
        file: Path to the audio file.

    Returns:
        Tuple of (file_bytes, filename, content_type).

    Raises:
        typer.BadParameter: If the file is not found, not a regular file,
            or exceeds the 25MB size limit.
    """
    path = Path(file).expanduser()

    if not path.exists():
        raise typer.BadParameter(f"File not found: {file}")

    if not path.is_file():
        raise typer.BadParameter(f"Not a file: {file}")

    file_size = path.stat().st_size
    if file_size > MAX_FILE_SIZE_BYTES:
        size_mb = file_size / (1024 * 1024)
        raise typer.BadParameter(
            f"File ({size_mb:.1f} MB) exceeds the 25 MB upload limit."
        )

    file_bytes = path.read_bytes()
    filename = path.name
    content_type = _detect_content_type(path)

    return file_bytes, filename, content_type


def _detect_content_type(path: Path) -> str:
    """Detect the MIME content type from the file extension.

    Args:
        path: Path to the file.

    Returns:
        MIME type string. Defaults to 'audio/wav' if detection fails.
    """
    guessed, _ = mimetypes.guess_type(str(path))
    if guessed and guessed.startswith("audio/"):
        return guessed
    return "audio/wav"


def audio_transcribe_command(
    file: str = typer.Argument(
        ...,
        help="Path to audio file, or '-' for stdin.",
    ),
) -> None:
    """Transcribe audio to text.

    Accepts a local audio file or piped stdin. The file must be under 25 MB.
    Content type is auto-detected from the file extension.

    Examples:
        ai audio transcribe recording.wav
        ai audio transcribe ~/voice-memo.mp3
        cat audio.wav | ai audio transcribe -
    """
    file_bytes, filename, content_type = resolve_audio_input(file)
    _execute_transcribe(
        file_bytes=file_bytes, filename=filename, content_type=content_type
    )


@async_command
async def _execute_transcribe(
    file_bytes: bytes,
    filename: str,
    content_type: str,
) -> None:
    """Execute the transcribe operation.

    Args:
        file_bytes: Raw audio bytes to upload.
        filename: Name of the audio file.
        content_type: MIME content type of the audio.
    """
    async with authenticated_client() as (_config, client):
        submit_response = await client.submit_audio_transcription(
            file_bytes,
            filename=filename,
            content_type=content_type,
        )

        status = await client.wait_for_audio_transcription(
            submit_response.transcription_id,
            timeout_seconds=DEFAULT_POLL_TIMEOUT_SECONDS,
        )

        if status.status == "completed":
            output = await client.get_audio_transcription_output(
                submit_response.transcription_id,
                format="text",
            )
            print(output)
        else:
            print(
                f"Transcription failed: {status.error_message}",
                file=sys.stderr,
            )
            sys.exit(1)
