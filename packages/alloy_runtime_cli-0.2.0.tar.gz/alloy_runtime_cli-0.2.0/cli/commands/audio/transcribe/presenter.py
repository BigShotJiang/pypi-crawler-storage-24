"""Presenter for audio transcribe command output."""


def present_transcription(text: str) -> None:
    """Print transcribed text to stdout.

    Output is piping-friendly: only the transcribed text goes to stdout
    with no decoration or metadata.

    Args:
        text: Transcribed text from audio.
    """
    print(text)
