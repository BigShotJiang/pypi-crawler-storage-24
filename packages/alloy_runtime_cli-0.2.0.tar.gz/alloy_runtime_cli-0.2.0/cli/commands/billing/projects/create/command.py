"""Billing project create command implementation."""

from typing import Optional

import typer

from cli.commands.billing.projects.create.presenter import (
    present_billing_project_created,
)
from cli.infrastructure.command import async_command, authenticated_client

from alloy_runtime_types.dtos.billing import CreateProjectRequest


def billing_projects_create_command(
    name: str = typer.Option(
        ...,
        "--name",
        help="Project name (unique per organization)",
    ),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        help="Optional project description",
    ),
    external_reference: Optional[str] = typer.Option(
        None,
        "--external-reference",
        help="External billing system identifier",
    ),
) -> None:
    """Create a new billing project.

    Examples:
        ai billing projects create --name "Q1 Campaign"
        ai billing projects create --name "Q1 Campaign" --description "Marketing costs"
    """
    _execute_create(
        name=name,
        description=description,
        external_reference=external_reference,
    )


@async_command
async def _execute_create(
    name: str,
    description: Optional[str],
    external_reference: Optional[str],
) -> None:
    """Execute create billing project operation."""
    async with authenticated_client() as (_config, client):
        request = CreateProjectRequest(
            name=name,
            description=description,
            external_reference=external_reference,
        )
        response = await client.create_billing_project(request)

    present_billing_project_created(response)
