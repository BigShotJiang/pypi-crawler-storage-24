"""Billing project cost summary command implementation."""

from typing import Optional
from uuid import UUID

import typer

from cli.commands.billing.costs.summary.presenter import present_billing_cost_summary
from cli.commands.flag_utils import validate_uuid
from cli.infrastructure.command import async_command, authenticated_client


def billing_costs_summary_command(
    project_id: str = typer.Argument(
        ...,
        help="Billing project UUID",
    ),
    start_date: Optional[str] = typer.Option(
        None,
        "--from",
        help="Start date (ISO 8601, defaults to 30 days ago)",
    ),
    end_date: Optional[str] = typer.Option(
        None,
        "--to",
        help="End date (ISO 8601, defaults to now)",
    ),
) -> None:
    """Get cost summary for a billing project.

    Examples:
        ai billing costs summary 123e4567-89ab...
        ai billing costs summary 123e4567-89ab... --from 2026-01-01 --to 2026-01-31
    """
    project_uuid = validate_uuid(project_id, "billing project")
    _execute_cost_summary(
        project_id=project_uuid,
        start_date=start_date,
        end_date=end_date,
    )


@async_command
async def _execute_cost_summary(
    project_id: UUID,
    start_date: Optional[str],
    end_date: Optional[str],
) -> None:
    """Execute get billing project costs operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_billing_project_costs(
            project_id,
            start_date=start_date,
            end_date=end_date,
        )

    present_billing_cost_summary(response)
