"""Presenter for credential update command output."""

from cli.commands.credentials.update.fields import CREDENTIAL_FIELDS
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.credentials import CredentialResponse


def present_credential_update_success(credential: CredentialResponse) -> None:
    """Present a successful credential update with Rich formatting.

    Args:
        credential: Updated credential data from server
    """
    output = OutputService.get()
    output.success(f"Updated credential: {credential.name}")
    output.entity(credential, "Credential Details", CREDENTIAL_FIELDS)
