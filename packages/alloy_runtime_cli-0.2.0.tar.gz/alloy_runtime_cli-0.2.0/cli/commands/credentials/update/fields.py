"""Field definitions for credential presentation."""

from typing import Any

from cli.infrastructure.formatting.fields import (
    format_boolean,
    format_cost,
    format_datetime,
)
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def format_optional_datetime(value: Any) -> str:
    """Format optional datetime value."""
    return format_datetime(value) if value else "(not set)"


def format_optional_limit(value: Any) -> str:
    """Format optional limit value."""
    return str(value) if value is not None else "(not set)"


def format_optional_provider(value: Any) -> str:
    """Format optional provider enum value."""
    return value.value if value is not None else "(not set)"


def format_optional_boolean(value: Any) -> str:
    """Format optional boolean value."""
    return format_boolean(value) if value is not None else "(not set)"


def format_optional_cost(value: Any) -> str:
    """Format optional cost value."""
    return format_cost(value) if value is not None else "(not set)"


CREDENTIAL_FIELDS: list[FieldConfig] = [
    FieldConfig("id", "ID", lambda v: str(v)),
    FieldConfig("name", "Name"),
    FieldConfig("description", "Description"),
    FieldConfig("credential_type_id", "Credential Type"),
    FieldConfig("provider_key", "Provider", format_optional_provider),
    FieldConfig("is_active", "Is Active", format_boolean),
    FieldConfig("value_prefix", "Value Prefix"),
    # Organization credential field
    FieldConfig(
        "organization_id", "Organization ID", lambda v: str(v) if v else "(system)"
    ),
    # System credential fields (optional)
    FieldConfig("priority", "Priority", format_optional_limit),
    FieldConfig("is_default", "Is Default", format_optional_boolean),
    FieldConfig("daily_request_limit", "Daily Request Limit", format_optional_limit),
    FieldConfig(
        "requests_per_minute_limit", "Requests/Minute Limit", format_optional_limit
    ),
    FieldConfig(
        "monthly_cost_limit_usd", "Monthly Cost Limit (USD)", format_optional_cost
    ),
    FieldConfig(
        "current_daily_requests", "Current Daily Requests", format_optional_limit
    ),
    FieldConfig(
        "current_monthly_cost_usd", "Current Monthly Cost (USD)", format_optional_cost
    ),
    # Timestamps
    FieldConfig("created_at", "Created", format_datetime),
    FieldConfig("updated_at", "Updated", format_datetime),
    FieldConfig("last_used_at", "Last Used", format_optional_datetime),
    FieldConfig("expires_at", "Expires", format_optional_datetime),
]
