"""Presenter for sync command output."""

from rich.table import Table
from alloy_runtime_types.dtos.admin import SyncModelsResponse

from cli.infrastructure.console import get_console
from cli.infrastructure.output import print_success


def present_sync_models_success(response: SyncModelsResponse) -> None:
    """Present successful model sync results with Rich formatting.

    Args:
        response: Sync results from server
    """
    console = get_console()

    # Print success message with summary
    print_success(
        f"Synced {response.total_models_synced} models from {response.total_providers_synced} providers"
    )

    # Create table for per-source breakdown
    if response.by_source:
        table = Table(
            title="Sync Results by Source",
            show_header=True,
            header_style="bold magenta",
        )
        table.add_column("Source", style="cyan", no_wrap=True)
        table.add_column("Models", style="white", justify="right")
        table.add_column("Providers", style="white", justify="right")
        table.add_column("Status", style="white")

        # Add rows for each source
        for source_name, result in response.by_source.items():
            if result.error:
                status = f"[red]✗ {result.error}[/red]"
            else:
                status = "[green]✓ Success[/green]"

            table.add_row(
                source_name,
                str(result.models_synced),
                str(result.providers_synced),
                status,
            )

        console.print(table)
