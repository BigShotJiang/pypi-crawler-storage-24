"""Whoami command implementation."""

from cli.infrastructure.command import async_command
from cli.infrastructure.config import load_config
from cli.infrastructure.console import get_console
from alloy_runtime_sdk.api_client.client import ApiClient


def whoami_command() -> None:
    """Show current authenticated user information.

    Examples:

        ai whoami
    """
    _execute_whoami()


@async_command
async def _execute_whoami() -> None:
    """Execute the whoami operation."""
    console = get_console()
    config = load_config()

    async with ApiClient(base_url=config.api_url, api_key=config.api_key) as client:
        me = await client.get_me()

    # Print user info
    console.print(f"[cyan]Email:[/cyan] {me.email}")
    console.print(f"[cyan]Name:[/cyan] {me.name}")
    console.print(f"[cyan]User ID:[/cyan] {me.user_id}")

    if me.organization_id:
        console.print(
            f"[cyan]Organization:[/cyan] {me.organization_name or me.organization_id}"
        )
        console.print(f"[cyan]Organization ID:[/cyan] {me.organization_id}")
    else:
        console.print("[dim]No organization[/dim]")

    if me.is_system_admin:
        console.print("[yellow]System Administrator[/yellow]")
