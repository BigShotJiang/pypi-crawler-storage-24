"""Presenter for tags update command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tags import UpdateTagResponse


def present_update_result(response: UpdateTagResponse) -> None:
    output = OutputService.get()
    output.success(f"Updated tag: {response.tag.tag_path}")
