"""Presenter for tags get command output."""

from rich.table import Table

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tags import GetTagResponse


def present_tag_details(response: GetTagResponse) -> None:
    output = OutputService.get()

    output.success(f"Retrieved tag: {response.tag.tag_path}")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim", width=20)
    table.add_column("Value")

    table.add_row("ID", str(response.tag.id))
    table.add_row("Tag Path", response.tag.tag_path)
    table.add_row("Display Name", response.tag.display_name or "-")
    table.add_row("Description", response.tag.description or "-")

    output.console.print(table)
