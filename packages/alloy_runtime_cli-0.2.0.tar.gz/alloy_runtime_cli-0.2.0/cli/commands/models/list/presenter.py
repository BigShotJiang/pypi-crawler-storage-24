"""Presenter for models list command output."""

from typing import TYPE_CHECKING

from alloy_runtime_types.dtos.models import ListModelsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig

if TYPE_CHECKING:
    from cli.commands.models.list.command import DisplayColumn


def present_models_list(
    response: ListModelsResponse,
    *,
    display_column: "DisplayColumn | None" = None,
    extra_fields: bool = False,
) -> None:
    """Present list of models with Rich table formatting.

    Args:
        response: List models response from server
        display_column: If set, only show that specific column. None = all columns.
        extra_fields: If True, show detailed table with all fields. Default is simple one-line format.
    """
    # Import here to avoid circular import
    from cli.commands.models.list.command import DisplayColumn

    output = OutputService.get()

    if not response.models:
        output.info("No models found")
        return

    # If display_column is set, show single column
    if display_column == DisplayColumn.PROVIDER:
        columns = [
            ColumnConfig(
                source_field="provider_key",
                header_label="Provider",
                compact_line=1,
                compact_style="green",
            ),
        ]
    elif display_column == DisplayColumn.MODEL:
        columns = [
            ColumnConfig(
                source_field="provider_model_name",
                header_label="Model Name",
                compact_line=1,
                compact_style="cyan",
            ),
        ]
    # If extra_fields is True, show detailed table with compact layout
    elif extra_fields:
        # Line 1 (primary): Provider, model name, context window - identifiers
        # Line 2 (detail): Max output, modalities - technical details
        columns = [
            ColumnConfig(
                source_field="provider_key",
                header_label="Provider",
                compact_line=1,
                compact_style="green",
            ),
            ColumnConfig(
                source_field="provider_model_name",
                header_label="Model Name",
                compact_line=1,
                compact_style="cyan",
            ),
            ColumnConfig(
                source_field="context_window",
                header_label="Context",
                formatter=lambda x: f"{x:,}" if x else "-",
                align="right",
                compact_line=1,
                compact_style="yellow",
            ),
            ColumnConfig(
                source_field="max_output_tokens",
                header_label="Max Output",
                formatter=lambda x: f"{x:,}" if x else "-",
                align="right",
                compact_line=2,
                compact_style="dim",
            ),
            ColumnConfig(
                source_field="input_modalities",
                header_label="Input",
                formatter=lambda x: ", ".join(sorted(x)) if x else "-",
                compact_line=2,
                compact_style="dim",
            ),
            ColumnConfig(
                source_field="output_modalities",
                header_label="Output",
                formatter=lambda x: ", ".join(sorted(x)) if x else "-",
                compact_line=2,
                compact_style="dim",
            ),
        ]
    else:
        # Default: simple one-line format (provider/model)
        for model in response.models:
            output.console.print(f"{model.provider_key}/{model.provider_model_name}")
        return

    # Render table (cast needed due to list invariance)
    output.table(
        items=response.models,  # type: ignore[arg-type]
        title=f"Available Models ({response.total_count})",
        columns=columns,
    )
