"""Login command implementation."""

import typer

from cli.infrastructure.auth_storage import save_credentials
from cli.infrastructure.command import async_command
from cli.infrastructure.config import get_api_url
from cli.infrastructure.console import Confirm, Prompt, get_console
from cli.infrastructure.output import print_info, print_success
from cli.infrastructure.provider_setup import prompt_provider_credentials
from alloy_runtime_sdk.api_client.client import ApiClient
from alloy_runtime_types.dtos.auth import LoginRequest


def login_command(
    email: str | None = typer.Option(None, "-e", "--email", help="Email address"),
    password: str | None = typer.Option(
        None, "--password", help="Password (avoid: exposes in shell history)"
    ),
) -> None:
    """Login and save API key.

    First-time users will be prompted to set up provider credentials.

    Examples:

        alloy login
        alloy login -e user@example.com
    """
    _execute_login(email, password)


@async_command
async def _execute_login(
    email: str | None,
    password: str | None,
) -> None:
    """Execute the login operation.

    Args:
        email: Optional email (will prompt if not provided)
        password: Optional password (will prompt if not provided)
    """
    console = get_console()
    api_url = get_api_url()

    # Prompt for credentials if not provided
    if not email:
        email = Prompt.ask("[cyan]Email[/cyan]")

    if not password:
        password = Prompt.ask("[cyan]Password[/cyan]", password=True)

    console.print("\n[blue]Authenticating...[/blue]")

    # Create unauthenticated client
    async with ApiClient(base_url=api_url, api_key="") as client:
        response = await client.login(LoginRequest(email=email, password=password))

    # Save credentials
    save_credentials(api_url, response.api_key)

    print_success(f"Logged in as {response.name} ({response.email})")
    print_info("API key saved to ~/.alloy-runtime/config")
    print_info(f"Organization: {response.organization_id}")

    # Prompt for provider credentials if new user
    if response.is_new_user:
        console.print("\n[yellow]Welcome! This is your first login.[/yellow]")
        if Confirm.ask(
            "Would you like to set up AI provider credentials now?", default=True
        ):
            await prompt_provider_credentials(api_url, response.api_key)
        else:
            console.print(
                "\n[dim]You can set up provider credentials later with:[/dim]"
            )
            console.print(
                "[dim]  alloy credentials update <credential-id> --value <api-key>[/dim]"
            )
