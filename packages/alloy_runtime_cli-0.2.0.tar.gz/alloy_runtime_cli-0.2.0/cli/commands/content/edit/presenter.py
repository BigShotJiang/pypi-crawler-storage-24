"""Presenter for content edit command output."""

import json
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_cost,
    format_datetime,
    format_optional,
    format_tokens,
    format_uuid,
)
from alloy_runtime_types.dtos.content import UpdateContentPartResponse
from alloy_runtime_types.dtos.templates import TagResponse


def present_content_edit_success(
    response: UpdateContentPartResponse, updated_content: bool, updated_tags: bool
) -> None:
    """Present content edit success with piping support.

    Metadata goes to stderr (visible in terminal but not piped).
    Content goes to stdout (for piping to other commands).

    Args:
        response: Updated content part response from server
        updated_content: Whether content was updated
        updated_tags: Whether tags were updated
    """
    # Create console for stderr output (metadata)
    stderr_console = Console(file=sys.stderr, force_terminal=True)

    # Build update summary
    updates: list[str] = []
    if updated_content:
        updates.append("content")
    if updated_tags:
        updates.append("tags")
    update_summary = " and ".join(updates) if updates else "no changes"

    # Print success message to stderr
    stderr_console.print(
        f"[green]✓[/green] Content part updated ({update_summary}): {format_uuid(response.id, short=True)}"
    )

    # Build and display metadata table to stderr
    _display_metadata(response, stderr_console)

    # Print content to stdout for piping
    _display_content(response)


def _display_metadata(response: UpdateContentPartResponse, console: Console) -> None:
    """Display content part metadata to stderr.

    Args:
        response: Content part response
        console: Console for stderr output
    """
    meta_table = Table(show_header=False, box=None, padding=(0, 1))
    meta_table.add_column("Field", style="dim", width=20)
    meta_table.add_column("Value")

    # Basic info
    meta_table.add_row("ID", str(response.id))
    meta_table.add_row("Message ID", format_uuid(response.message_id, short=True))
    meta_table.add_row("Part Index", str(response.part_index))
    meta_table.add_row("Content Type", response.content_type_id)
    meta_table.add_row(
        "Storage Type",
        "structured" if response.content_structured else "text",
    )
    meta_table.add_row("Created", format_datetime(response.created_at))

    # Tags
    meta_table.add_row("Tags", _format_tags(response.tags))

    # Execution metadata
    exec_meta = response.execution_metadata
    meta_table.add_row("", "")  # Separator
    meta_table.add_row("[bold]Execution Info[/bold]", "")
    meta_table.add_row(
        "Execution ID",
        format_uuid(exec_meta.agent_execution_id, short=True),
    )
    meta_table.add_row(
        "Agent",
        format_optional(exec_meta.agent_name, placeholder="(direct model call)"),
    )
    meta_table.add_row("Provider", exec_meta.provider_key)
    meta_table.add_row("Model", exec_meta.provider_model_name)
    meta_table.add_row(
        "Cost",
        format_optional(exec_meta.total_cost_usd, formatter=format_cost),
    )
    meta_table.add_row(
        "Tokens",
        format_optional(exec_meta.total_tokens, formatter=format_tokens),
    )
    meta_table.add_row("Queued At", format_datetime(exec_meta.queued_at))

    meta_panel = Panel(meta_table, title="Content Part Updated", border_style="green")
    console.print(meta_panel)


def _format_tags(tags: list[TagResponse]) -> str:
    """Format tags list for display.

    Args:
        tags: List of tag responses

    Returns:
        Formatted tags string
    """
    if not tags:
        return "(no tags)"

    tag_paths = [t.tag_path for t in tags]
    return ", ".join(tag_paths)


def _display_content(response: UpdateContentPartResponse) -> None:
    """Display content to stdout for piping.

    Text content is printed directly.
    Structured content is formatted as indented JSON.

    Args:
        response: Content part response
    """
    if response.content_text is not None:
        # Plain text content
        print(response.content_text, file=sys.stdout)
    elif response.content_structured is not None:
        # Structured JSON content - pretty print
        print(
            json.dumps(response.content_structured, indent=2, ensure_ascii=False),
            file=sys.stdout,
        )
    else:
        # No content (shouldn't happen but handle gracefully)
        print("(no content)", file=sys.stdout)
