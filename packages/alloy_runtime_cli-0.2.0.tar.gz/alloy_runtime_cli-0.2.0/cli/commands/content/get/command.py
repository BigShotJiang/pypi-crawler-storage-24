"""Content get command implementation."""

from uuid import UUID

import typer

from cli.commands.content.get.presenter import present_content_part
from cli.commands.flag_utils import validate_uuid
from cli.infrastructure.command import async_command, authenticated_client


def content_get_command(
    content_part_id: str = typer.Argument(
        ...,
        help="Content part UUID",
    ),
) -> None:
    """Get a content part by UUID.

    Output is piping-friendly:
    - Content goes to stdout
    - Metadata goes to stderr

    Examples:
        ai content get 019405e0-e000-7000-f100-000000000001
        ai content get <id> | jq .
        ai content get <id> > output.txt
    """
    content_uuid = validate_uuid(content_part_id, "content")
    _execute_get(content_part_id=content_uuid)


@async_command
async def _execute_get(content_part_id: UUID) -> None:
    """Execute get content part operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_content_part(content_part_id)

    present_content_part(response)
