"""Presenter for content get command output."""

import json
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_cost,
    format_datetime,
    format_optional,
    format_tokens,
    format_uuid,
)
from alloy_runtime_types.dtos.content import ContentPartItemResponse
from alloy_runtime_types.dtos.templates import TagResponse


def present_content_part(response: ContentPartItemResponse) -> None:
    """Present content part details with piping support.

    Metadata goes to stderr (visible in terminal but not piped).
    Content goes to stdout (for piping to other commands).

    Args:
        response: Content part response from server
    """
    # Write content to stdout FIRST - this is what gets piped
    # Must happen before any stderr output to avoid blocking issues with vim/less
    _display_content(response)

    # Now write metadata to stderr (won't be piped)
    # Wrap in try/except since stderr can also block when stdout is piped
    try:
        stderr_console = Console(file=sys.stderr)
        stderr_console.print(
            f"[green]✓[/green] Content part retrieved: {format_uuid(response.id, short=True)}"
        )
        _display_metadata(response, stderr_console)
    except (BlockingIOError, BrokenPipeError):
        # stderr blocked or closed - that's fine, content already went to stdout
        pass


def _display_metadata(response: ContentPartItemResponse, console: Console) -> None:
    """Display content part metadata to stderr.

    Args:
        response: Content part response
        console: Console for stderr output
    """
    meta_table = Table(show_header=False, box=None, padding=(0, 1))
    meta_table.add_column("Field", style="dim", width=20)
    meta_table.add_column("Value")

    # Basic info
    meta_table.add_row("ID", str(response.id))
    meta_table.add_row("Message ID", format_uuid(response.message_id, short=True))
    meta_table.add_row("Part Index", str(response.part_index))
    meta_table.add_row("Content Type", response.content_type_id)
    meta_table.add_row(
        "Storage Type",
        "structured" if response.content_structured else "text",
    )
    meta_table.add_row("Created", format_datetime(response.created_at))

    # Tags
    meta_table.add_row("Tags", _format_tags(response.tags))

    # Execution metadata
    exec_meta = response.execution_metadata
    meta_table.add_row("", "")  # Separator
    meta_table.add_row("[bold]Execution Info[/bold]", "")
    meta_table.add_row(
        "Execution ID",
        format_uuid(exec_meta.agent_execution_id, short=True),
    )
    meta_table.add_row(
        "Agent",
        format_optional(exec_meta.agent_name, placeholder="(direct model call)"),
    )
    meta_table.add_row("Provider", exec_meta.provider_key)
    meta_table.add_row("Model", exec_meta.provider_model_name)
    meta_table.add_row(
        "Cost",
        format_optional(exec_meta.total_cost_usd, formatter=format_cost),
    )
    meta_table.add_row(
        "Tokens",
        format_optional(exec_meta.total_tokens, formatter=format_tokens),
    )
    meta_table.add_row("Queued At", format_datetime(exec_meta.queued_at))

    meta_panel = Panel(meta_table, title="Content Part Details", border_style="blue")
    console.print(meta_panel)


def _format_tags(tags: list[TagResponse]) -> str:
    """Format tags list for display.

    Args:
        tags: List of tag responses

    Returns:
        Formatted tags string
    """
    if not tags:
        return "(no tags)"

    tag_paths = [t.tag_path for t in tags]
    return ", ".join(tag_paths)


def _display_content(response: ContentPartItemResponse) -> None:
    """Display content to stdout for piping.

    Text content is printed directly.
    Structured content is formatted as indented JSON.

    Args:
        response: Content part response
    """
    if response.content_text is not None:
        content = response.content_text
    elif response.content_structured is not None:
        content = json.dumps(response.content_structured, indent=2, ensure_ascii=False)
    else:
        content = "(no content)"

    _write_stdout_safe(content)


def _write_stdout_safe(content: str) -> None:
    """Write content to stdout safely, handling non-blocking pipes.

    When piping to programs like vim that don't immediately consume stdin,
    the pipe can be set to non-blocking mode, causing BlockingIOError.
    This function handles that by using a binary write with proper encoding.

    Args:
        content: Text content to write
    """
    # Check if stdout has a binary buffer (real stdout does, StringIO in tests doesn't)
    stdout_bin = getattr(sys.stdout, "buffer", None)

    if stdout_bin is None:
        # Fallback for testing with StringIO or other text-mode streams
        print(content)
        return

    # Encode the content
    data = (content + "\n").encode("utf-8")

    # Write in a loop to handle partial writes
    written = 0
    while written < len(data):
        try:
            n = stdout_bin.write(data[written:])
            if n is None:
                # Non-blocking mode returned None, flush and retry
                stdout_bin.flush()
                continue
            written += n
        except BlockingIOError:
            # Pipe is full, flush and continue
            stdout_bin.flush()
            continue
        except BrokenPipeError:
            # Consumer closed the pipe (e.g., head -n 1)
            # This is expected behavior, exit quietly
            sys.stderr.close()
            sys.exit(0)

    stdout_bin.flush()
