"""Presenter for template delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.templates import DeleteTemplateResponse


def present_delete_result(response: DeleteTemplateResponse) -> None:
    """Present template deletion result.

    Args:
        response: DeleteTemplateResponse from server
    """
    output = OutputService.get()
    deleted = response.deleted_template

    output.success(f"Template '{deleted.name}' deleted successfully")
