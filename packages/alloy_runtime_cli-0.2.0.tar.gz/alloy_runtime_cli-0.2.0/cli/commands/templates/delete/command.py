"""Templates delete command implementation."""

import typer

from cli.commands.templates.delete.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def templates_delete_command(
    template: str = typer.Argument(
        ...,
        help="Template name or UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a template.

    Permanently removes the template and all versions.
    Templates referenced by others cannot be deleted.

    Examples:
        ai templates delete my-template
        ai tpl delete email.welcome -y
    """
    _execute_delete(template_identifier=template, skip_confirm=yes)


@async_command
async def _execute_delete(template_identifier: str, skip_confirm: bool) -> None:
    """Execute delete template operation."""
    if not skip_confirm:
        confirmed = Confirm.ask(
            f"[yellow]Delete template '{template_identifier}'?[/yellow] This cannot be undone"
        )
        if not confirmed:
            raise typer.Abort()

    async with authenticated_client() as (_config, client):
        response = await client.delete_template(template_identifier)

    present_delete_result(response)
