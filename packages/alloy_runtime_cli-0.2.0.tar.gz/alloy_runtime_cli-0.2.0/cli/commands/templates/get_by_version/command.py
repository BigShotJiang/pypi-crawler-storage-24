"""Templates get_by_version command implementation."""

from uuid import UUID

import typer

from cli.commands.templates.get_by_version.presenter import present_template_details
from cli.commands.flag_utils import validate_uuid
from cli.infrastructure.command import async_command, authenticated_client


def templates_get_by_version_command(
    version_id: str = typer.Argument(
        ...,
        help="Template version UUID",
    ),
) -> None:
    """Get a template by its version ID.

    Examples:
        ai templates get-by-version 123e4567-89ab-cdef-0123-456789abcdef
    """
    version_uuid = validate_uuid(version_id, "template version")
    _execute_get(version_id=version_uuid)


@async_command
async def _execute_get(version_id: UUID) -> None:
    async with authenticated_client() as (_config, client):
        response = await client.get_template_by_version(version_id)

    present_template_details(response)
