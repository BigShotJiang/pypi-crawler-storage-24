"""Presenter for template get command output."""

import pyperclip
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.templates import (
    GetTemplateResponse,
    TagResponse,
    TemplateDependencyResponse,
    TemplateVersionResponse,
)


def _format_tags(tags: list[TagResponse]) -> str:
    """Format tags for display.

    Args:
        tags: List of tag responses

    Returns:
        Formatted tags string or "(none)" if empty
    """
    if not tags:
        return "(none)"
    return ", ".join(t.tag_path for t in tags)


def _format_dependencies(dependencies: list[TemplateDependencyResponse]) -> str:
    """Format dependencies for display.

    Args:
        dependencies: List of dependency responses

    Returns:
        Formatted dependencies string or "(none)" if empty
    """
    if not dependencies:
        return "(none)"
    return ", ".join(d.child_template_name for d in dependencies)


def _format_variables(variables: list[str]) -> str:
    """Format required variables for display.

    Args:
        variables: List of variable names

    Returns:
        Formatted variables string or "(none)" if empty
    """
    if not variables:
        return "(none)"
    return ", ".join(variables)


def _truncate_content(content: str, max_length: int = 500) -> str:
    """Truncate content for preview display.

    Args:
        content: Content string to truncate
        max_length: Maximum length before truncation

    Returns:
        Truncated content with indicator if truncated
    """
    if len(content) <= max_length:
        return content
    return content[:max_length] + "\n... (truncated)"


def _copy_to_clipboard(content: str, console: Console) -> bool:
    """Copy content to clipboard.

    Args:
        content: Text to copy
        console: Console for output messages

    Returns:
        True if successful, False otherwise
    """
    try:
        pyperclip.copy(content)
        console.print("[green]✓[/green] Content copied to clipboard")
        return True
    except pyperclip.PyperclipException as e:
        console.print(f"[red]✗[/red] Failed to copy to clipboard: {e}")
        return False


def present_template_details(
    response: GetTemplateResponse, full: bool = False, copy: bool = False
) -> None:
    """Present template details with Rich formatting.

    Args:
        response: GetTemplateResponse from server
        full: Whether to print full content instead of preview
        copy: Whether to copy content to clipboard
    """
    output = OutputService.get()
    template = response.template
    versions = response.versions
    dependencies = response.dependencies

    # Find latest version for required variables
    latest_version = next((v for v in versions if v.is_latest), None)
    required_variables = latest_version.required_variables if latest_version else []

    # Build metadata table
    metadata_table = Table(show_header=False, box=None, padding=(0, 1))
    metadata_table.add_column("Field", style="dim")
    metadata_table.add_column("Value")

    metadata_table.add_row("ID", format_uuid(template.id, short=False))
    metadata_table.add_row("Name", template.name)
    metadata_table.add_row("Content Type", template.content_type_id)
    metadata_table.add_row("Visibility", template.visibility_id)
    metadata_table.add_row("Description", format_optional(template.description))
    metadata_table.add_row("Tags", _format_tags(template.tags))
    metadata_table.add_row("Dependencies", _format_dependencies(dependencies))
    metadata_table.add_row("Required Variables", _format_variables(required_variables))
    metadata_table.add_row(
        "Organization ID",
        format_optional(template.organization_id, lambda x: format_uuid(x, short=True)),
    )
    metadata_table.add_row(
        "User ID",
        format_optional(template.user_id, lambda x: format_uuid(x, short=True)),
    )
    metadata_table.add_row("Created At", format_datetime(template.created_at))
    metadata_table.add_row("Updated At", format_datetime(template.updated_at))

    # Display metadata panel
    metadata_panel = Panel(
        metadata_table,
        title=f"Template: {template.name}",
        border_style="green",
    )
    output.console.print(metadata_panel)

    # Build versions table
    if versions:
        _present_versions_table(output, versions)

    # Handle content display based on flags
    if latest_version and latest_version.content:
        content = latest_version.content

        # Copy to clipboard if requested
        if copy:
            _copy_to_clipboard(content, output.console)

        # Show full content or preview
        if full:
            _present_full_content(output, latest_version)
        else:
            _present_content_preview(output, latest_version)


def _present_versions_table(
    output: OutputService, versions: list[TemplateVersionResponse]
) -> None:
    """Present versions as a table.

    Args:
        output: OutputService instance
        versions: List of template versions
    """
    versions_table = Table(
        title=f"Versions ({len(versions)})",
        show_header=True,
        header_style="bold",
    )
    versions_table.add_column("Version", justify="right")
    versions_table.add_column("Latest")
    versions_table.add_column("Content Length", justify="right")
    versions_table.add_column("Variables")
    versions_table.add_column("Created At")

    for v in versions:
        versions_table.add_row(
            f"v{v.version}",
            "Yes" if v.is_latest else "-",
            f"{len(v.content)} chars",
            _format_variables(v.required_variables) if v.is_latest else "-",
            format_datetime(v.created_at),
        )

    output.console.print(versions_table)


def _present_content_preview(
    output: OutputService, version: TemplateVersionResponse
) -> None:
    """Present content preview for a version.

    Args:
        output: OutputService instance
        version: Template version to preview
    """
    content_preview = _truncate_content(version.content)
    content_panel = Panel(
        Text(content_preview, style="dim"),
        title=f"Content Preview (v{version.version})",
        border_style="blue",
    )
    output.console.print(content_panel)


def _present_full_content(
    output: OutputService, version: TemplateVersionResponse
) -> None:
    """Present full content for a version.

    Args:
        output: OutputService instance
        version: Template version to display
    """
    content_panel = Panel(
        Text(version.content),
        title=f"Content (v{version.version}) - {len(version.content)} chars",
        border_style="blue",
    )
    output.console.print(content_panel)
