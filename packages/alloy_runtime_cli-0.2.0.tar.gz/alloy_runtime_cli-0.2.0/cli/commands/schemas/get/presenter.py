"""Presenter for schema get command output."""

import json
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from alloy_runtime_types.dtos.schemas import GetSchemaResponse


def _derive_scope(response: GetSchemaResponse) -> str:
    """Derive scope string from organization_id and user_id fields.

    Args:
        response: Schema response from server

    Returns:
        Scope string: user, organization, or global
    """
    if response.organization_id is not None and response.user_id is None:
        return "organization"
    elif response.user_id is not None:
        return "user"
    else:
        return "global"


def _format_definition_for_display(
    schema_format_id: str, schema_definition: str
) -> str:
    """Format schema definition for display.

    JSON schemas are pretty-printed, regex patterns shown as-is.

    Args:
        schema_format_id: Format type (json_schema, regex)
        schema_definition: The schema definition string

    Returns:
        Formatted definition string
    """
    if schema_format_id == "json_schema":
        try:
            # Parse and pretty-print JSON
            parsed = json.loads(schema_definition)
            return json.dumps(parsed, indent=2, ensure_ascii=False)
        except (json.JSONDecodeError, TypeError):
            # If parsing fails, return as-is
            return schema_definition
    else:
        # Regex or other formats - return as-is
        return schema_definition


def present_schema_details(response: GetSchemaResponse) -> None:
    """Present schema details with Rich formatting.

    Metadata goes to stderr (visible in terminal but not piped).
    Schema definition goes to stdout (for piping to other commands).

    Args:
        response: GetSchemaResponse from server
    """
    # Create console for stderr output (metadata)
    stderr_console = Console(file=sys.stderr, force_terminal=True)

    # Print success message to stderr
    stderr_console.print(
        f"[green]✓[/green] Schema retrieved: {response.schema_name} (v{response.version})"
    )

    # Build metadata table
    metadata_table = Table(show_header=False, box=None, padding=(0, 1))
    metadata_table.add_column("Field", style="dim", width=20)
    metadata_table.add_column("Value")

    metadata_table.add_row("ID", format_uuid(response.id, short=False))
    metadata_table.add_row("Name", response.schema_name)
    metadata_table.add_row("Format", response.schema_format_id)
    metadata_table.add_row("Version", str(response.version))
    metadata_table.add_row("Description", format_optional(response.description))
    metadata_table.add_row("Scope", _derive_scope(response))
    metadata_table.add_row("Is Latest", "Yes" if response.is_latest else "No")
    metadata_table.add_row(
        "Organization ID",
        format_optional(response.organization_id, lambda x: format_uuid(x, short=True)),
    )
    metadata_table.add_row(
        "User ID",
        format_optional(response.user_id, lambda x: format_uuid(x, short=True)),
    )
    metadata_table.add_row("Created At", format_datetime(response.created_at))

    # Display metadata panel to stderr
    metadata_panel = Panel(
        metadata_table,
        title=f"Schema: {response.schema_name}",
        border_style="blue",
    )
    stderr_console.print(metadata_panel)

    # Format and display definition to stdout for piping
    formatted_definition = _format_definition_for_display(
        response.schema_format_id, response.schema_definition
    )

    # Also show definition preview in a panel to stderr
    preview_text = (
        formatted_definition
        if len(formatted_definition) <= 500
        else formatted_definition[:500] + "\n... (truncated in preview)"
    )
    definition_panel = Panel(
        Text(preview_text, style="dim"),
        title=f"Schema Definition Preview ({response.schema_format_id})",
        border_style="green",
    )
    stderr_console.print(definition_panel)

    # Print full definition to stdout for piping
    print(formatted_definition, file=sys.stdout)
