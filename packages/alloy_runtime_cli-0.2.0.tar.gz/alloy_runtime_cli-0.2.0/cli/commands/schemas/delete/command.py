"""Schemas delete command implementation."""

import typer

from cli.commands.schemas.delete.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def schemas_delete_command(
    schema: str = typer.Argument(
        ...,
        help="Schema name or UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a schema.

    Permanently removes the schema and all its versions.
    Cannot delete schemas referenced by agents or pipelines.

    Examples:
        ai schemas delete my-schema
        ai schemas delete my-schema -y
        ai schemas delete 123e4567-89ab-cdef-0123-456789abcdef
    """
    if not yes:
        confirmed = Confirm.ask(f"[yellow]Delete schema {schema}?[/yellow]")
        if not confirmed:
            raise typer.Abort()

    _execute_delete(schema_identifier=schema)


@async_command
async def _execute_delete(schema_identifier: str) -> None:
    async with authenticated_client() as (_config, client):
        response = await client.delete_schema(schema_identifier)

    present_delete_result(response)
