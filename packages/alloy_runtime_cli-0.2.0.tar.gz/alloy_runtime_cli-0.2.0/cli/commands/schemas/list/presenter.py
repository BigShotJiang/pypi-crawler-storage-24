"""Presenter for schemas list command output."""

from pydantic import BaseModel, Field
from alloy_runtime_types.dtos.schemas import ListSchemasResponse, SchemaSummary

from cli.infrastructure.scope_utils import format_scope_label
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


class SchemaDisplay(BaseModel):
    """Schema with computed scope field for display."""

    id: str = Field(..., description="Schema ID")
    schema_name: str = Field(..., description="Schema name")
    version: int = Field(..., description="Version number")
    schema_format_id: str = Field(..., description="Format type")
    description: str | None = Field(None, description="Description")
    scope: str = Field(..., description="Ownership scope")
    created_at: str = Field(..., description="Creation date")


def _format_description(description: str | None) -> str:
    """Format description for display, truncating if too long.

    Args:
        description: Optional description text

    Returns:
        Formatted description string
    """
    if not description:
        return "-"
    if len(description) > 120:
        return description[:117] + "..."
    return description


def _transform_schema_for_display(schema: SchemaSummary) -> SchemaDisplay:
    """Transform schema summary into display model with computed fields.

    Args:
        schema: Schema summary from API

    Returns:
        SchemaDisplay with computed scope field
    """
    return SchemaDisplay(
        id=str(schema.id),
        schema_name=schema.schema_name,
        version=schema.version,
        schema_format_id=schema.schema_format_id,
        description=schema.description,
        scope=format_scope_label(
            str(schema.organization_id) if schema.organization_id else None,
            str(schema.user_id) if schema.user_id else None,
        ),
        created_at=schema.created_at.strftime("%Y-%m-%d") if schema.created_at else "-",
    )


def present_schemas_list(response: ListSchemasResponse) -> None:
    """Present list of schemas with Rich table formatting.

    Args:
        response: List schemas response from server
    """
    output = OutputService.get()

    if not response.schemas:
        output.info("No schemas found")
        return

    # Transform schemas for display
    display_items = [_transform_schema_for_display(s) for s in response.schemas]

    # Define table columns with compact layout configuration
    # Line 1 (primary): ID, version, format, scope, created - machine-readable data
    # Line 2 (detail): Name, description - human-readable content
    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="version",
            header_label="Ver",
            align="right",
            formatter=lambda x: f"v{x}" if x else "-",
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="schema_format_id",
            header_label="Format",
            compact_line=1,
            compact_style="magenta",
        ),
        ColumnConfig(
            source_field="scope",
            header_label="Scope",
            compact_line=1,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="created_at",
            header_label="Created",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="schema_name",
            header_label="Name",
            compact_line=2,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=_format_description,
            compact_line=2,
            compact_style="dim",
        ),
    ]

    # Render table
    output.table(
        items=display_items,  # type: ignore[arg-type]
        title=f"Schemas ({response.total})",
        columns=columns,
    )
