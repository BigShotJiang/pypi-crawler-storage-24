"""Non-streaming result presenter for text generation.

Displays final generation results with usage summary and costs.
"""

from decimal import Decimal

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from alloy_runtime_types.dtos.generation import GenerateTextResponse


class GenerateTextPresenter:
    """Presents completed text generation results.

    Features:
    - Final text output with optional thinking block
    - Usage statistics (tokens) table
    - Cost breakdown table
    - Execution metadata
    """

    def __init__(self, console: Console):
        """Initialize presenter.

        Args:
            console: Rich console for output
        """
        self.console = console

    def present_result(
        self, response: GenerateTextResponse, show_metadata: bool = True
    ) -> None:
        """Present a non-streaming generation result.

        Args:
            response: Complete generation response
            show_metadata: Whether to show usage/cost tables (default True)
        """
        # Display main output text
        self.console.print()
        self.console.print(
            Panel(
                Text(response.output_text),
                title="Generated Text",
                title_align="left",
                border_style="green",
                padding=(1, 2),
            )
        )
        self.console.print()

        # Display metadata if requested
        if show_metadata:
            self._display_usage_table(response)
            self._display_cost_table(response)
            self._display_execution_info(response)

    def present_multiple_results(
        self, responses: list[GenerateTextResponse], show_metadata: bool = True
    ) -> None:
        """Present multiple concurrent generation results.

        Args:
            responses: List of generation responses
            show_metadata: Whether to show usage/cost summaries
        """
        self.console.print()

        for i, response in enumerate(responses, 1):
            # Display each result with index
            self.console.print(
                Panel(
                    Text(response.output_text),
                    title=f"Generated Text {i}/{len(responses)}",
                    title_align="left",
                    border_style="green",
                    padding=(1, 2),
                )
            )
            self.console.print()

        # Display aggregated metadata if requested
        if show_metadata and responses:
            self._display_aggregated_usage(responses)
            self._display_aggregated_costs(responses)

            # Display session IDs for each execution
            self.console.print()
            for i, response in enumerate(responses, 1):
                self.console.print(
                    f"[dim]Execution {i} Session ID:[/dim] {response.chat_session_id}"
                )
            self.console.print()

    def _display_usage_table(self, response: GenerateTextResponse) -> None:
        """Display token usage table.

        Args:
            response: Generation response
        """
        table = Table(title="Token Usage", show_header=True, header_style="bold cyan")
        table.add_column("Metric", style="dim")
        table.add_column("Count", justify="right")

        usage = response.usage
        table.add_row("Input Tokens", str(usage.input_tokens))
        table.add_row("Output Tokens", str(usage.output_tokens))

        if usage.cache_creation_tokens:
            table.add_row(
                "Cache Creation Tokens", str(usage.cache_creation_tokens), style="dim"
            )
        if usage.cache_read_tokens:
            table.add_row(
                "Cache Read Tokens", str(usage.cache_read_tokens), style="dim"
            )

        total = usage.input_tokens + usage.output_tokens
        table.add_row("Total Tokens", str(total), style="bold")

        self.console.print(table)
        self.console.print()

    def _display_cost_table(self, response: GenerateTextResponse) -> None:
        """Display cost breakdown table.

        Args:
            response: Generation response
        """
        table = Table(
            title="Cost Breakdown", show_header=True, header_style="bold cyan"
        )
        table.add_column("Component", style="dim")
        table.add_column("USD", justify="right")

        cost = response.cost
        table.add_row("Input Cost", self._format_cost(cost.input_cost_usd))
        table.add_row("Output Cost", self._format_cost(cost.output_cost_usd))

        if cost.cache_cost_usd:
            table.add_row(
                "Cache Cost", self._format_cost(cost.cache_cost_usd), style="dim"
            )

        table.add_row(
            "Total Cost", self._format_cost(cost.total_cost_usd), style="bold green"
        )

        self.console.print(table)
        self.console.print()

    def _display_execution_info(self, response: GenerateTextResponse) -> None:
        """Display execution metadata.

        Args:
            response: Generation response
        """
        info_parts = [
            f"[dim]Session ID:[/dim] {response.chat_session_id}",
            f"[dim]Execution ID:[/dim] {response.execution_id}",
            f"[dim]Model:[/dim] {response.provider_key}/{response.provider_model_name}",
            f"[dim]Finish Reason:[/dim] {response.finish_reason}",
        ]

        if response.tags:
            info_parts.append(f"[dim]Tags:[/dim] {', '.join(response.tags)}")

        for part in info_parts:
            self.console.print(part)

        self.console.print()

    def _display_aggregated_usage(self, responses: list[GenerateTextResponse]) -> None:
        """Display aggregated token usage across multiple executions.

        Args:
            responses: List of generation responses
        """
        table = Table(
            title=f"Aggregated Token Usage ({len(responses)} executions)",
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Metric", style="dim")
        table.add_column("Total", justify="right")
        table.add_column("Average", justify="right")

        total_input = sum(r.usage.input_tokens for r in responses)
        total_output = sum(r.usage.output_tokens for r in responses)
        total_cache_creation = sum(
            r.usage.cache_creation_tokens or 0 for r in responses
        )
        total_cache_read = sum(r.usage.cache_read_tokens or 0 for r in responses)

        count = len(responses)
        table.add_row("Input Tokens", str(total_input), str(total_input // count))
        table.add_row("Output Tokens", str(total_output), str(total_output // count))

        if total_cache_creation > 0:
            table.add_row(
                "Cache Creation",
                str(total_cache_creation),
                str(total_cache_creation // count),
                style="dim",
            )
        if total_cache_read > 0:
            table.add_row(
                "Cache Read",
                str(total_cache_read),
                str(total_cache_read // count),
                style="dim",
            )

        total_tokens = total_input + total_output
        table.add_row(
            "Total Tokens", str(total_tokens), str(total_tokens // count), style="bold"
        )

        self.console.print(table)
        self.console.print()

    def _display_aggregated_costs(self, responses: list[GenerateTextResponse]) -> None:
        """Display aggregated costs across multiple executions.

        Args:
            responses: List of generation responses
        """
        table = Table(
            title=f"Aggregated Costs ({len(responses)} executions)",
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Component", style="dim")
        table.add_column("Total USD", justify="right")
        table.add_column("Average USD", justify="right")

        total_input_cost = Decimal(sum(r.cost.input_cost_usd for r in responses))
        total_output_cost = Decimal(sum(r.cost.output_cost_usd for r in responses))
        total_cache_cost = Decimal(
            sum(r.cost.cache_cost_usd or Decimal(0) for r in responses)
        )
        total_cost = Decimal(sum(r.cost.total_cost_usd for r in responses))

        count = Decimal(len(responses))
        table.add_row(
            "Input Cost",
            self._format_cost(total_input_cost),
            self._format_cost(total_input_cost / count),
        )
        table.add_row(
            "Output Cost",
            self._format_cost(total_output_cost),
            self._format_cost(total_output_cost / count),
        )

        if total_cache_cost > 0:
            table.add_row(
                "Cache Cost",
                self._format_cost(total_cache_cost),
                self._format_cost(total_cache_cost / count),
                style="dim",
            )

        table.add_row(
            "Total Cost",
            self._format_cost(total_cost),
            self._format_cost(total_cost / count),
            style="bold green",
        )

        self.console.print(table)
        self.console.print()

    def _format_cost(self, cost: Decimal) -> str:
        """Format cost value as currency string.

        Args:
            cost: Cost in USD

        Returns:
            Formatted cost string with dollar sign
        """
        return f"${cost:.6f}"
