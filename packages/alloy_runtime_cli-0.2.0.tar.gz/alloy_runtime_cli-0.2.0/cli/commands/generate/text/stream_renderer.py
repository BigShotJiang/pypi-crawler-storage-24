"""Streaming text renderer with thinking block support.

Provides a terminal display for streaming text generation,
with visual differentiation between thinking/reasoning blocks
and generated content.

Streams both thinking and content in real-time:
- Thinking blocks are displayed in red with <thinking> tags to stderr
- Content is streamed directly to stdout
"""

import sys
from collections.abc import AsyncGenerator

from rich.console import Console

from alloy_runtime_types.dtos.generation import GenerateTextStreamChunk

# ANSI escape codes
RED = "\033[31m"
RESET = "\033[0m"


class StreamRenderer:
    """Renders streaming text generation with thinking block support.

    Features:
    - Thinking/reasoning blocks displayed in real-time (to stderr, in red)
    - Content output to stdout in real-time
    - Both thinking and content stream as they arrive
    """

    def __init__(self, console: Console):
        """Initialize stream renderer.

        Args:
            console: Rich console for output
        """
        self.console = console
        self._thinking_text = ""
        self._content_text = ""
        self._session_id: str | None = None
        self._in_thinking_block = False

    async def render_stream(
        self,
        stream: AsyncGenerator[GenerateTextStreamChunk, None],
        show_thinking: bool = True,
    ) -> tuple[str, str, str | None]:
        """Render a streaming generation.

        Streams both thinking and content in real-time as chunks arrive.

        Args:
            stream: Async generator of stream chunks
            show_thinking: Whether to display thinking blocks (default True)

        Returns:
            Tuple of (content_text, thinking_text, session_id) - accumulated outputs
        """
        self._thinking_text = ""
        self._content_text = ""
        self._session_id = None
        self._in_thinking_block = False

        async for chunk in stream:
            self._process_chunk(chunk, show_thinking)

        # Close thinking block if still open at end of stream
        if self._in_thinking_block:
            self._close_thinking_block()

        # Final newline for clean output
        if self._content_text:
            sys.stdout.write("\n")
            sys.stdout.flush()

        return self._content_text, self._thinking_text, self._session_id

    def _process_chunk(
        self, chunk: GenerateTextStreamChunk, show_thinking: bool
    ) -> None:
        """Process a stream chunk.

        Args:
            chunk: Stream chunk to process
            show_thinking: Whether to display thinking text
        """
        if chunk.chunk_type == "thinking":
            # Thinking chunks - stream in real-time
            if chunk.reasoning_content:
                self._thinking_text += chunk.reasoning_content
                if show_thinking:
                    # Open thinking block if not already open
                    if not self._in_thinking_block:
                        self._open_thinking_block()
                    # Stream thinking content immediately
                    sys.stderr.write(f"{RED}{chunk.reasoning_content}{RESET}")
                    sys.stderr.flush()

        elif chunk.chunk_type == "metadata":
            # Metadata chunks - capture session_id from final metadata
            if chunk.metadata and "chat_session_id" in chunk.metadata:
                self._session_id = chunk.metadata["chat_session_id"]

        else:
            # Content chunks - close thinking block first if open
            if self._in_thinking_block:
                self._close_thinking_block()

            if chunk.content:
                self._content_text += chunk.content
                # Stream content immediately
                sys.stdout.write(chunk.content)
                sys.stdout.flush()

    def _open_thinking_block(self) -> None:
        """Print opening thinking tag to stderr."""
        sys.stderr.write(f"\n{RED}<thinking>{RESET}\n")
        sys.stderr.flush()
        self._in_thinking_block = True

    def _close_thinking_block(self) -> None:
        """Print closing thinking tag to stderr."""
        if not self._thinking_text.endswith("\n"):
            sys.stderr.write("\n")
        sys.stderr.write(f"{RED}</thinking>{RESET}\n\n")
        sys.stderr.flush()
        self._in_thinking_block = False
