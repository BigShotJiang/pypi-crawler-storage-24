"""Presenter for async generation cancel command output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.generation import AsyncGenerationCancelResponse


def present_generation_cancel(response: AsyncGenerationCancelResponse) -> None:
    """Present async generation cancel result."""
    output = OutputService.get()

    output.success(response.message)

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Execution ID", format_uuid(response.execution_id, short=False))
    table.add_row("Status", response.status)
    table.add_row("Was Running", "Yes" if response.was_running else "No")

    panel = Panel(table, title="Generation Cancelled", border_style="yellow")
    output.console.print(panel)
