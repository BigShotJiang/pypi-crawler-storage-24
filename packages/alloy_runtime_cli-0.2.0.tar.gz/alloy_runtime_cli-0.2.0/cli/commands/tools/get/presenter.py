"""Presenter for tools get command output."""

import json

from typing import Any

from alloy_runtime_types.dtos.tools import ToolResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def _format_parameter_schema(schema: dict[str, Any] | None) -> str:
    """Format parameter_schema as pretty-printed JSON.

    Args:
        schema: Parameter schema dict or None

    Returns:
        Formatted JSON string, or '-' if no schema
    """
    if not schema:
        return "None (no configurable parameters)"
    return json.dumps(schema, indent=2, ensure_ascii=False)


def present_tool_details(response: ToolResponse) -> None:
    """Present tool details including parameter schema.

    Args:
        response: ToolResponse from server
    """
    output = OutputService.get()

    fields = [
        FieldConfig("id", "ID"),
        FieldConfig("description", "Description"),
        FieldConfig(
            "parameter_schema",
            "Parameter Schema",
            _format_parameter_schema,
        ),
    ]

    output.entity(response, f"Tool: {response.id}", fields)
