"""Tools get command implementation."""

import typer

from cli.commands.tools.get.presenter import present_tool_details
from cli.infrastructure.command import async_command, authenticated_client


def tools_get_command(
    tool_id: str = typer.Argument(
        ...,
        help="Tool identifier (e.g., 'rag_search', 'web_search')",
    ),
) -> None:
    """Get details of a single tool.

    Retrieves the full tool definition including the parameter_schema
    which defines what configuration options the tool accepts.

    Examples:
        ai tools get rag_search
        ai tools get web_search
    """
    _execute_get(tool_id=tool_id)


@async_command
async def _execute_get(tool_id: str) -> None:
    """Execute get tool operation.

    Args:
        tool_id: Tool identifier string

    Raises:
        NotFoundError: If tool not found
        AuthenticationError: If API key is invalid
        ServerError: If server returns 5xx error
    """
    async with authenticated_client() as (_config, client):
        response = await client.get_tool(tool_id)

    present_tool_details(response)
