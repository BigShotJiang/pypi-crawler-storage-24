"""Presenter for tools list command output."""

from alloy_runtime_types.dtos.tools import ListToolsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def present_tools_list(response: ListToolsResponse) -> None:
    """Present list of tools with Rich table formatting."""
    output = OutputService.get()

    if not response.tools:
        output.info("No tools found")
        return

    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=lambda x: x[:80] + "..." if x and len(x) > 80 else (x or "-"),
            compact_line=2,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="parameter_schema",
            header_label="Has Parameters",
            formatter=lambda x: "Yes" if x else "No",
            compact_line=1,
            compact_style="green",
        ),
    ]

    output.table(
        items=response.tools,  # type: ignore[arg-type]
        title=f"Tools ({response.total})",
        columns=columns,
    )
