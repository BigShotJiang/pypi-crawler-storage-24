"""Tools list command implementation."""

from typing import Optional

import typer

from cli.commands.tools.list.presenter import present_tools_list
from cli.infrastructure.command import async_command, authenticated_client


def tools_list_command(
    search: Optional[str] = typer.Option(
        None,
        "-s",
        "--search",
        help="Fuzzy search terms",
    ),
    limit: int = typer.Option(
        50,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max results",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Skip N results",
    ),
) -> None:
    """List available tools in the registry.

    Shows all tools that can be configured on agents, including
    their identifiers and descriptions.

    Examples:
        ai tools list
        ai tools list -s "search"
        ai tools list -l 10 --offset 20
    """
    _execute_list(search=search, limit=limit, offset=offset)


@async_command
async def _execute_list(search: Optional[str], limit: int, offset: int) -> None:
    """Execute list tools operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_tools(
            search=search,
            limit=limit,
            offset=offset,
        )

    present_tools_list(response)
