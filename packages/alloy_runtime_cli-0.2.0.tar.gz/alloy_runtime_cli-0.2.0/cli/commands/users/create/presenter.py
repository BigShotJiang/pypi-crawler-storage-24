"""Presenter for users create command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.users import CreateUserResponse


def present_create_result(response: CreateUserResponse) -> None:
    output = OutputService.get()
    output.success(f"Created user: {response.email}")
