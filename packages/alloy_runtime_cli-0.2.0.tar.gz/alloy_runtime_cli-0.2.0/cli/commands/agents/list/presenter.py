"""Presenter for agents list command output."""

from alloy_runtime_types.dtos.agents import ListAgentsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_description(description: str | None) -> str:
    """Format description for display, truncating if too long.

    Args:
        description: Optional description text

    Returns:
        Formatted description string
    """
    if not description:
        return "-"
    if len(description) > 120:
        return description[:117] + "..."
    return description


def present_agents_list(response: ListAgentsResponse) -> None:
    """Present list of agents with Rich table formatting.

    Args:
        response: List agents response from server
    """
    output = OutputService.get()

    if not response.agents:
        output.info("No agents found")
        return

    # Define table columns with compact layout configuration
    # Line 1 (primary): ID, model count, created - machine-readable data
    # Line 2 (detail): Name, description - human-readable content
    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="model_count",
            header_label="Models",
            align="right",
            formatter=lambda x: f"{x} models" if x else "0 models",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="created_at",
            header_label="Created",
            formatter=lambda x: x.strftime("%Y-%m-%d") if x else "-",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="name",
            header_label="Name",
            compact_line=2,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=_format_description,
            compact_line=2,
            compact_style="dim",
        ),
    ]

    # Render table
    output.table(
        items=response.agents,  # type: ignore[arg-type]
        title=f"Agents ({response.total})",
        columns=columns,
    )
