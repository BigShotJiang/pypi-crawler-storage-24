"""Agents list command implementation."""

from typing import Optional

import typer

from cli.commands.agents.list.presenter import present_agents_list
from cli.infrastructure.command import async_command, authenticated_client


def agents_list_command(
    search: Optional[str] = typer.Option(
        None,
        "-s",
        "--search",
        help="Fuzzy search terms",
    ),
    limit: int = typer.Option(
        50,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max results",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Skip N results",
    ),
) -> None:
    """List agents accessible to you.

    Examples:
        ai agents list
        ai agents list -s "claude opus"
        ai agents list -l 20
        ai agents list -s bot -l 10 --offset 20
    """
    _execute_list(search=search, limit=limit, offset=offset)


@async_command
async def _execute_list(search: Optional[str], limit: int, offset: int) -> None:
    """Execute list agents operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_agents(
            search=search,
            limit=limit,
            offset=offset,
        )

    present_agents_list(response)
