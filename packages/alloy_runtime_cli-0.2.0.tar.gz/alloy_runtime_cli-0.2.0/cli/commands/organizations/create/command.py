"""Organizations create command implementation."""

import typer

from cli.commands.organizations.create.presenter import present_create_result
from cli.infrastructure.command import async_command, authenticated_client
from alloy_runtime_types.dtos.organizations import CreateOrganizationRequest


def organizations_create_command(
    name: str = typer.Option(
        ...,
        "-n",
        "--name",
        help="Organization name",
    ),
) -> None:
    """Create a new organization.

    Examples:
        ai organizations create --name "My Company"
    """
    _execute_create(name=name)


@async_command
async def _execute_create(name: str) -> None:
    request = CreateOrganizationRequest(name=name)
    async with authenticated_client() as (_config, client):
        response = await client.create_organization(request)

    present_create_result(response)
