"""Presenter for session messages command output."""

from alloy_runtime_types.dtos.sessions import (
    ListSessionMessagesResponse,
    MessageResponse,
)

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_content(msg: MessageResponse) -> str:
    """Format message content for display."""
    if not msg.content_parts:
        return "-"
    first_part = msg.content_parts[0]
    text = first_part.content_text or ""
    if len(text) > 80:
        return text[:77] + "..."
    return text or "-"


def present_messages_list(response: ListSessionMessagesResponse) -> None:
    """Present list of messages with Rich table formatting."""
    output = OutputService.get()

    if not response.messages:
        output.info("No messages found")
        return

    columns = [
        ColumnConfig(
            source_field="sequence_number",
            header_label="#",
            align="right",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="role",
            header_label="Role",
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="created_at",
            header_label="Time",
            formatter=lambda x: x.strftime("%H:%M:%S") if x else "-",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=response.messages,  # type: ignore[arg-type]
        title=f"Messages ({response.total})",
        columns=columns,
    )

    # Show content preview for each message
    output.info("\nContent:")
    for msg in response.messages:
        role_style = {
            "user": "green",
            "assistant": "blue",
            "system": "yellow",
            "tool": "magenta",
        }.get(msg.role, "white")

        content = _format_content(msg)
        output.console.print(
            f"  [{role_style}]{msg.sequence_number}. {msg.role}[/{role_style}]: {content}"
        )
