"""Sessions list command implementation."""

from typing import Optional

import typer

from cli.commands.sessions.list.presenter import present_sessions_list
from cli.infrastructure.command import async_command, authenticated_client


def sessions_list_command(
    search: Optional[str] = typer.Option(
        None,
        "-s",
        "--search",
        help="Fuzzy search terms",
    ),
    named_only: bool = typer.Option(
        False,
        "--named-only",
        help="Only show named sessions",
    ),
    limit: int = typer.Option(
        50,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max results",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Skip N results",
    ),
) -> None:
    """List chat sessions accessible to you.

    Examples:
        ai sessions list
        ai sessions list -s "research"
        ai sessions list --named-only
    """
    _execute_list(search=search, named_only=named_only, limit=limit, offset=offset)


@async_command
async def _execute_list(
    search: Optional[str], named_only: bool, limit: int, offset: int
) -> None:
    """Execute list sessions operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_sessions(
            search=search,
            named_only=named_only,
            limit=limit,
            offset=offset,
        )

    present_sessions_list(response)
