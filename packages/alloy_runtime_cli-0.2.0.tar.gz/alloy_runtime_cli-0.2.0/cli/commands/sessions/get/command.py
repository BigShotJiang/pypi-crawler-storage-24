"""Session get command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.sessions.get.presenter import present_session
from cli.infrastructure.command import async_command, authenticated_client


def sessions_get_command(
    session_id: str = typer.Argument(
        ...,
        help="Session UUID",
    ),
    limit: int = typer.Option(
        20,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max messages to include",
    ),
) -> None:
    """Get details of a chat session.

    Examples:
        ai sessions get 123e4567-89ab-cdef-0123-456789abcdef
        ai sessions get 123e4567-89ab... -l 50
    """
    session_uuid = validate_uuid(session_id, "session")
    _execute_get(session_id=session_uuid, limit=limit)


@async_command
async def _execute_get(session_id: UUID, limit: int) -> None:
    """Execute get session operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_session(session_id, limit=limit)

    present_session(response)
