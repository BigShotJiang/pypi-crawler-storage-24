"""Presenter for knowledge search output."""

import json

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import SearchResponse


def present_search_results(response: SearchResponse, output_format: str) -> None:
    """Present search results in specified format.

    Args:
        response: Search response from server
        output_format: Output format ('table' or 'json')
    """
    if output_format == "json":
        _present_json_results(response)
    else:
        _present_table_results(response)


def _present_table_results(response: SearchResponse) -> None:
    """Present search results as formatted table."""
    output = OutputService.get()

    if not response.results:
        output.info(f"No results found for: {response.query}")
        return

    # Build summary panel
    summary_table = Table(show_header=False, box=None, padding=(0, 1))
    summary_table.add_column("Field", style="dim")
    summary_table.add_column("Value")

    summary_table.add_row("Query", response.query)
    summary_table.add_row("Results", str(len(response.results)))
    summary_table.add_row("Candidates evaluated", str(response.total_candidates))
    summary_table.add_row("Avg relevance", f"{response.avg_relevance_score:.3f}")

    # Add timing breakdown
    timing_parts: list[str] = []
    for key, value in response.timing_ms.items():
        timing_parts.append(f"{key}={value}ms")
    if timing_parts:
        summary_table.add_row("Timing", ", ".join(timing_parts))

    summary_panel = Panel(summary_table, title="Search Summary", border_style="blue")
    output.console.print(summary_panel)

    # Show transformations if applied
    if response.transformations_applied:
        output.console.print(
            f"\n[dim]Transformations applied:[/dim] "
            f"[cyan]{', '.join(response.transformations_applied)}[/cyan]"
        )

    if response.sub_queries_used:
        output.console.print("[dim]Sub-queries used:[/dim]")
        for i, sq in enumerate(response.sub_queries_used, 1):
            output.console.print(f"  [cyan]{i}.[/cyan] {sq}")

    # Build results table
    output.console.print()
    results_table = Table(title="Results", show_header=True, header_style="bold")
    results_table.add_column("#", style="dim", width=3, justify="right")
    results_table.add_column("Document", style="white", no_wrap=True, max_width=30)
    results_table.add_column("Score", style="cyan", width=7, justify="right")
    results_table.add_column("Content", style="dim", overflow="ellipsis")

    low_confidence_results: list[int] = []
    for i, result in enumerate(response.results, 1):
        # Truncate content preview
        content_preview = result.content.replace("\n", " ")[:100]
        if len(result.content) > 100:
            content_preview += "..."

        # Mark low confidence results
        score_display = f"{result.relevance_score:.3f}"
        if result.low_confidence:
            score_display = f"[yellow]{score_display}*[/yellow]"
            low_confidence_results.append(i)

        results_table.add_row(
            str(i),
            result.document_title,
            score_display,
            content_preview,
        )

    output.console.print(results_table)

    # Show low confidence warning
    if low_confidence_results:
        output.console.print(
            f"\n[yellow]* Results {', '.join(map(str, low_confidence_results))} "
            "are below the confidence threshold[/yellow]"
        )


def _present_json_results(response: SearchResponse) -> None:
    """Present search results as JSON."""
    output = OutputService.get()

    # Convert response to JSON-serializable dict
    data = response.model_dump(mode="json")

    # Pretty-print JSON
    output.console.print_json(json.dumps(data))
