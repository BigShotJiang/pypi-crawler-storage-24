"""Presenter for document recovery output."""

from uuid import UUID

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import RecoverDocumentsResponse


def present_recovery_result(response: RecoverDocumentsResponse) -> None:
    """Present document recovery results.

    Args:
        response: Recovery response from server
    """
    output = OutputService.get()

    total_affected = (
        response.recovered_count + response.failed_count + response.requeued_count
    )

    if total_affected == 0:
        output.info("No stuck documents found")
        return

    output.success("Document recovery completed")

    # Build summary table
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Metric", style="dim")
    table.add_column("Value")

    table.add_row("Documents recovered", str(response.recovered_count))
    table.add_row("Documents re-queued", str(response.requeued_count))
    table.add_row("Documents permanently failed", str(response.failed_count))

    panel = Panel(table, title="Recovery Summary", border_style="green")
    output.console.print(panel)

    # Show document IDs if any
    if response.requeued_document_ids:
        _present_document_ids(
            output, "Re-queued for processing", response.requeued_document_ids
        )

    if response.recovered_document_ids:
        _present_document_ids(
            output, "Reset for retry", response.recovered_document_ids
        )

    if response.failed_document_ids:
        _present_document_ids(
            output, "Permanently failed", response.failed_document_ids, style="red"
        )


def _present_document_ids(
    output: OutputService,
    title: str,
    doc_ids: list[UUID],
    style: str = "cyan",
    max_display: int = 10,
) -> None:
    """Present a list of document IDs."""
    if not doc_ids:
        return

    output.console.print(f"\n[{style}]{title}:[/{style}]")

    displayed: list[UUID] = doc_ids[:max_display]
    for doc_id in displayed:
        output.console.print(f"  {format_uuid(doc_id, short=False)}")

    remaining = len(doc_ids) - max_display
    if remaining > 0:
        output.console.print(f"  [dim]...and {remaining} more[/dim]")
