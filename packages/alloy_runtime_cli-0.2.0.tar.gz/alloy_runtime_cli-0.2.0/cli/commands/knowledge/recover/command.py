"""Knowledge recover command implementation."""

from typing import Optional

import typer

from cli.commands.knowledge.recover.presenter import present_recovery_result
from cli.infrastructure.command import async_command, authenticated_client
from alloy_runtime_types.dtos.knowledge import RecoverDocumentsRequest


def knowledge_recover_command(
    max_retries: Optional[int] = typer.Option(
        None,
        "-r",
        "--max-retries",
        min=1,
        max=10,
        help="Override max retry attempts (default: 3)",
    ),
) -> None:
    """Recover stuck documents.

    Finds documents stuck in 'processing' or 'pending' state and either
    re-queues them for processing or marks them as permanently failed.

    Documents can get stuck when:
    - Processing is interrupted (container crash, API timeout, etc.)
    - Celery never picks up the task (message lost, worker unavailable)

    Examples:
        ai2 knowledge recover
        ai2 kb recover --max-retries 5
    """
    _execute_recover(max_retries=max_retries)


@async_command
async def _execute_recover(max_retries: Optional[int]) -> None:
    """Execute document recovery operation."""
    request = RecoverDocumentsRequest(max_retries=max_retries) if max_retries else None

    async with authenticated_client() as (_config, client):
        response = await client.recover_documents(request)

    present_recovery_result(response)
