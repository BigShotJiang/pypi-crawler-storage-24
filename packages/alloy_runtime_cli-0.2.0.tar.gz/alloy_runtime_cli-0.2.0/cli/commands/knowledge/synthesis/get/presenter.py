"""Presenter for synthesis get output."""

import json

from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import GetSynthesisResponse


def present_synthesis_details(
    response: GetSynthesisResponse, output_format: str
) -> None:
    """Present synthesis details.

    Args:
        response: Get synthesis response from server
        output_format: Output format ('panel' or 'json')
    """
    output = OutputService.get()

    if output_format == "json":
        # JSON output
        data = {
            "id": str(response.id),
            "topic": response.topic,
            "title": response.title,
            "status": response.status,
            "synthesis_content": response.synthesis_content,
            "error_message": response.error_message,
            "is_stale": response.is_stale,
            "staleness_reason": response.staleness_reason,
            "source_chunk_count": response.source_chunk_count,
            "collection_ids": [str(c) for c in response.collection_ids],
            "synthesizer_agent_id": str(response.synthesizer_agent_id)
            if response.synthesizer_agent_id
            else None,
            "execution_id": str(response.execution_id)
            if response.execution_id
            else None,
            "metadata": response.metadata,
            "created_at": response.created_at.isoformat(),
            "updated_at": response.updated_at.isoformat(),
        }
        output.console.print_json(json.dumps(data))
        return

    # Panel output
    # Build metadata table
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Title", response.title)
    table.add_row("Topic", response.topic)

    # Status with color
    status = response.status
    if status == "completed":
        status_display = f"[green]{status}[/green]"
    elif status == "failed":
        status_display = f"[red]{status}[/red]"
    elif status == "processing":
        status_display = f"[yellow]{status}[/yellow]"
    else:
        status_display = f"[dim]{status}[/dim]"
    table.add_row("Status", status_display)

    # Staleness
    if response.is_stale:
        stale_display = (
            f"[yellow]Yes[/yellow] - {response.staleness_reason or 'Unknown reason'}"
        )
    else:
        stale_display = "[green]No[/green]"
    table.add_row("Stale", stale_display)

    table.add_row("Source Chunks", str(response.source_chunk_count))
    table.add_row("Collections", str(len(response.collection_ids)))

    if response.synthesizer_agent_id:
        table.add_row("Agent", format_uuid(response.synthesizer_agent_id, short=True))
    if response.execution_id:
        table.add_row("Execution", format_uuid(response.execution_id, short=True))

    table.add_row("Created", format_datetime(response.created_at))
    table.add_row("Updated", format_datetime(response.updated_at))

    if response.error_message:
        table.add_row("Error", f"[red]{response.error_message}[/red]")

    # Show metadata if present
    if response.metadata:
        table.add_row("Metadata", str(response.metadata))

    panel = Panel(table, title=f"Synthesis: {response.title}", border_style="blue")
    output.console.print(panel)

    # Show content if completed
    if response.synthesis_content:
        output.console.print()
        content_panel = Panel(
            Markdown(response.synthesis_content),
            title="Synthesis Content",
            border_style="green",
        )
        output.console.print(content_panel)
