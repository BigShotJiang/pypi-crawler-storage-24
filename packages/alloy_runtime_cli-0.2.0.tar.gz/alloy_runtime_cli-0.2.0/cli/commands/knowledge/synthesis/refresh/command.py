"""Knowledge synthesis refresh command implementation."""

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.knowledge.synthesis.refresh.presenter import (
    present_synthesis_refresh_success,
)
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_synthesis_refresh_command(
    synthesis_id: str = typer.Argument(
        ...,
        help="Synthesis UUID to refresh",
    ),
) -> None:
    """Refresh a synthesis.

    Regenerates the synthesis content using the same topic, agent, and template.
    Use this to update a stale synthesis or to get updated results after
    new documents have been added to the source collections.

    Cannot refresh a synthesis that is currently processing.

    Examples:
        ai2 knowledge synthesis refresh <synthesis-uuid>
        ai2 kb synthesis refresh <uuid>
    """
    # Validate synthesis UUID
    validate_uuid(synthesis_id, "synthesis")

    _execute_refresh(synthesis_id)


@async_command
async def _execute_refresh(synthesis_id: str) -> None:
    """Execute synthesis refresh."""
    async with authenticated_client() as (_config, client):
        response = await client.refresh_synthesis(synthesis_id)

    present_synthesis_refresh_success(response)
