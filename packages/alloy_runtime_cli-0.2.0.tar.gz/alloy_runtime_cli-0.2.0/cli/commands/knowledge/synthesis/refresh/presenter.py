"""Presenter for synthesis refresh output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import RefreshSynthesisResponse


def present_synthesis_refresh_success(response: RefreshSynthesisResponse) -> None:
    """Present successful synthesis refresh.

    Args:
        response: Refresh synthesis response from server
    """
    output = OutputService.get()

    output.success("Synthesis refresh queued")

    # Build a simple table for entity display
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Synthesis ID", format_uuid(response.synthesis_id, short=False))
    table.add_row("Status", f"[yellow]{response.status}[/yellow]")
    table.add_row("Message", response.message)

    panel = Panel(table, title="Synthesis Refresh Started", border_style="green")
    output.console.print(panel)

    output.info(f"Poll status with: ai2 kb synthesis get {response.synthesis_id}")
