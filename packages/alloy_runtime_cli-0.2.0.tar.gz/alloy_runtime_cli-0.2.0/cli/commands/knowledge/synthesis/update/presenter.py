"""Presenter for knowledge synthesis update command output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import format_datetime, format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import UpdateSynthesisResponse


def present_synthesis_update_result(
    response: UpdateSynthesisResponse,
) -> None:
    """Present synthesis update result.

    Args:
        response: UpdateSynthesisResponse from server
    """
    output = OutputService.get()

    output.success(f"Synthesis '{response.title}' updated")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Title", response.title)
    table.add_row("Topic", response.topic)
    table.add_row("Status", response.status)

    stale_display = "[red]Yes[/]" if response.is_stale else "[green]No[/]"
    table.add_row("Stale", stale_display)
    if response.staleness_reason:
        table.add_row("Staleness Reason", response.staleness_reason)

    table.add_row("Source Chunks", str(response.source_chunk_count))
    table.add_row("Updated At", format_datetime(response.updated_at))

    panel = Panel(table, title="Synthesis Updated", border_style="green")
    output.console.print(panel)
