"""Knowledge synthesis delete command implementation."""

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.knowledge.synthesis.delete.presenter import (
    present_synthesis_delete_success,
)
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_synthesis_delete_command(
    synthesis_id: str = typer.Argument(
        ...,
        help="Synthesis UUID to delete",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Delete a synthesis.

    This permanently removes the synthesis, its collection associations,
    and its source tracking records.

    Examples:
        ai2 knowledge synthesis delete <synthesis-uuid>
        ai2 kb synthesis delete <uuid> --yes
    """
    # Validate synthesis UUID
    validate_uuid(synthesis_id, "synthesis")

    # Confirm deletion unless --yes flag provided
    if not yes:
        confirm = typer.confirm(
            f"Are you sure you want to delete synthesis {synthesis_id}?"
        )
        if not confirm:
            raise typer.Abort()

    _execute_delete(synthesis_id)


@async_command
async def _execute_delete(synthesis_id: str) -> None:
    """Execute synthesis deletion."""
    async with authenticated_client() as (_config, client):
        response = await client.delete_synthesis(synthesis_id)

    present_synthesis_delete_success(response)
