"""Presenter for synthesis delete output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import DeleteSynthesisResponse


def present_synthesis_delete_success(response: DeleteSynthesisResponse) -> None:
    """Present successful synthesis deletion.

    Args:
        response: Delete synthesis response from server
    """
    output = OutputService.get()

    output.success("Synthesis deleted successfully")

    # Build a simple table for deleted entity info
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Title", response.title)
    table.add_row("Topic", response.topic)

    panel = Panel(table, title="Deleted Synthesis", border_style="red")
    output.console.print(panel)
