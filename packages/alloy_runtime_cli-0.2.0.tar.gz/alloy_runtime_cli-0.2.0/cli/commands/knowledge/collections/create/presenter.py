"""Presenter for collection creation output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import CreateCollectionResponse


def present_collection_create_success(response: CreateCollectionResponse) -> None:
    """Present successful collection creation.

    Args:
        response: Collection creation response from server
    """
    output = OutputService.get()

    output.success("Collection created successfully")

    # Build a simple table for entity display
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Name", response.name)
    table.add_row("Description", format_optional(response.description))
    table.add_row("Embedding Model", response.embedding_model)
    table.add_row("Chunk Size", f"{response.chunk_size_tokens} tokens")
    table.add_row("Chunk Overlap", f"{response.chunk_overlap_tokens} tokens")
    table.add_row("Section Strategy", response.section_strategy)

    panel = Panel(table, title=f"Collection: {response.name}", border_style="green")
    output.console.print(panel)
