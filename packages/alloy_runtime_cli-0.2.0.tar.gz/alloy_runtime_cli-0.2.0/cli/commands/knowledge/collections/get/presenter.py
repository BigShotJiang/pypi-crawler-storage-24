"""Presenter for knowledge collection get command output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import GetCollectionResponse


def present_collection_details(response: GetCollectionResponse) -> None:
    """Present collection details with Rich formatting.

    Args:
        response: GetCollectionResponse from server
    """
    output = OutputService.get()

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Name", response.name)
    table.add_row("Description", format_optional(response.description))
    table.add_row("Embedding Model", response.embedding_model)
    table.add_row("Embedding Dimensions", str(response.embedding_dimensions))
    table.add_row("Chunk Size", f"{response.chunk_size_tokens} tokens")
    table.add_row("Chunk Overlap", f"{response.chunk_overlap_tokens} tokens")
    table.add_row("Section Strategy", response.section_strategy)
    table.add_row("Document Count", str(response.document_count))
    table.add_row("Created At", format_datetime(response.created_at))
    table.add_row("Updated At", format_datetime(response.updated_at))

    panel = Panel(
        table,
        title=f"Collection: {response.name}",
        border_style="green",
    )
    output.console.print(panel)
