"""Knowledge collections get command implementation."""

import typer

from cli.commands.knowledge.collections.get.presenter import present_collection_details
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_collections_get_command(
    collection: str = typer.Argument(
        ...,
        help="Collection name or UUID",
    ),
) -> None:
    """Get collection details.

    Examples:
        ai2 knowledge collections get my-collection
        ai2 kb collections get 550e8400-e29b-41d4-a716-446655440000
    """
    _execute_get(collection_identifier=collection)


@async_command
async def _execute_get(collection_identifier: str) -> None:
    """Execute get collection operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_collection(collection_identifier)

    present_collection_details(response)
