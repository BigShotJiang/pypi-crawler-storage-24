"""Presenter for knowledge collection delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import DeleteCollectionResponse


def present_delete_result(response: DeleteCollectionResponse) -> None:
    """Present collection deletion result.

    Args:
        response: DeleteCollectionResponse from server
    """
    output = OutputService.get()

    docs_msg = (
        f" ({response.documents_deleted} documents deleted)"
        if response.documents_deleted > 0
        else ""
    )
    output.success(f"Collection '{response.name}' deleted successfully{docs_msg}")
