"""Knowledge collection update command implementation."""

from typing import Optional

import typer

from cli.commands.flag_utils import require_update_flags, validate_uuid
from cli.commands.knowledge.collections.update.presenter import (
    present_collection_update_success,
)
from cli.infrastructure.command import async_command, authenticated_client
from alloy_runtime_types.dtos.knowledge import UpdateCollectionRequest


def knowledge_collections_update_command(
    collection_id: str = typer.Argument(
        ...,
        help="Collection UUID or name to update",
    ),
    name: Optional[str] = typer.Option(
        None,
        "-n",
        "--name",
        help="New collection name",
    ),
    description: Optional[str] = typer.Option(
        None,
        "-d",
        "--description",
        help="New collection description",
    ),
    rerank_instruction: Optional[str] = typer.Option(
        None,
        "-r",
        "--rerank-instruction",
        help="New default instruction for Voyage AI reranking (max 500 chars)",
    ),
) -> None:
    """Update a knowledge collection.

    At least one update flag (--name, --description, or --rerank-instruction) is required.

    Examples:
        ai2 knowledge collections update <uuid> -n "New Name"
        ai2 knowledge collections update <uuid> -d "Updated description"
        ai2 kb collections update <uuid> -r "Prioritize recent documents"
        ai2 kb collections update <uuid> -n "Docs" -d "Documentation" -r "Focus on API details"
    """
    require_update_flags(
        ("--name", name),
        ("--description", description),
        ("--rerank-instruction", rerank_instruction),
    )

    _execute_update_from_flags(
        collection_id=collection_id,
        name=name,
        description=description,
        rerank_instruction=rerank_instruction,
    )


def _execute_update_from_flags(
    collection_id: str,
    name: Optional[str],
    description: Optional[str],
    rerank_instruction: Optional[str],
) -> None:
    """Build and execute collection update from command flags."""
    # Validate collection ID if it looks like a UUID
    # (Server accepts both UUID and name, so we only validate UUID format)
    try:
        validate_uuid(collection_id, "collection")
    except typer.BadParameter:
        # Not a UUID - treat as name, let server handle validation
        pass

    # Build request with only provided fields
    request = UpdateCollectionRequest(
        name=name,
        description=description,
        rerank_instruction=rerank_instruction,
    )

    _execute_update(collection_id, request)


@async_command
async def _execute_update(
    collection_id: str,
    request: UpdateCollectionRequest,
) -> None:
    """Execute the collection update with the given request."""
    async with authenticated_client() as (_config, client):
        response = await client.update_collection(collection_id, request)

    present_collection_update_success(response)
