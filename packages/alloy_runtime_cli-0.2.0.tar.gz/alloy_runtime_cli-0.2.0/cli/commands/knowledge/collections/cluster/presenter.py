"""Presenter for knowledge collection cluster command output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import (
    GetCollectionClusteringStatusResponse,
    TriggerCollectionClusteringResponse,
)


def present_cluster_triggered(response: TriggerCollectionClusteringResponse) -> None:
    """Present clustering trigger result.

    Args:
        response: TriggerCollectionClusteringResponse from server
    """
    output = OutputService.get()

    output.success(response.message)

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Collection ID", format_uuid(response.collection_id, short=False))
    table.add_row("Task ID", response.task_id)
    table.add_row("Status", response.status)

    panel = Panel(table, title="Clustering Triggered", border_style="green")
    output.console.print(panel)


def present_cluster_status(
    response: GetCollectionClusteringStatusResponse,
) -> None:
    """Present clustering status details.

    Args:
        response: GetCollectionClusteringStatusResponse from server
    """
    output = OutputService.get()

    # Choose border style based on status
    border_style = {
        "completed": "green",
        "failed": "red",
        "processing": "yellow",
        "pending": "dim",
    }.get(response.status, "dim")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Collection ID", format_uuid(response.collection_id, short=False))
    table.add_row("Status", response.status)
    table.add_row("Cluster Count", str(response.cluster_count))
    table.add_row("Total Chunks", str(response.total_chunks))
    table.add_row("Clustered Chunks", str(response.clustered_chunks))
    table.add_row("Noise Chunks", str(response.noise_chunks))
    table.add_row("Unclustered Chunks", str(response.unclustered_chunks))
    table.add_row("Message", format_optional(response.message))
    table.add_row("Error", format_optional(response.error_message))
    table.add_row("Last Cluster Run", format_datetime(response.last_cluster_run_at))

    panel = Panel(table, title="Clustering Status", border_style=border_style)
    output.console.print(panel)
