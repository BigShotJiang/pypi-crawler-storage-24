"""Presenter for knowledge document delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import DeleteDocumentResponse


def present_delete_result(response: DeleteDocumentResponse) -> None:
    """Present document deletion result.

    Args:
        response: DeleteDocumentResponse from server
    """
    output = OutputService.get()

    chunks_msg = (
        f" ({response.chunks_deleted} chunks deleted)"
        if response.chunks_deleted > 0
        else ""
    )
    output.success(f"Document '{response.title}' deleted successfully{chunks_msg}")
