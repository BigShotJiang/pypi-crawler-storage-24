"""Presenter for knowledge document update metadata command output."""

import json

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import format_datetime, format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import UpdateDocumentMetadataResponse


def present_update_metadata_result(
    response: UpdateDocumentMetadataResponse,
) -> None:
    """Present document metadata update result.

    Args:
        response: UpdateDocumentMetadataResponse from server
    """
    output = OutputService.get()

    output.success(f"Document '{response.title}' metadata updated")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Collection ID", format_uuid(response.collection_id, short=False))
    table.add_row("Title", response.title)
    if response.metadata:
        table.add_row("Metadata", json.dumps(response.metadata, indent=2))
    table.add_row("Updated At", format_datetime(response.updated_at))

    panel = Panel(table, title="Document Updated", border_style="green")
    output.console.print(panel)
