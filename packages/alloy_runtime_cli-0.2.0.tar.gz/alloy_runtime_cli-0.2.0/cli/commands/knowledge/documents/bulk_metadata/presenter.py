"""Presenter for knowledge documents bulk metadata update command output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import BulkUpdateDocumentMetadataResponse


def present_bulk_metadata_result(
    response: BulkUpdateDocumentMetadataResponse,
) -> None:
    """Present bulk metadata update result.

    Args:
        response: BulkUpdateDocumentMetadataResponse from server
    """
    output = OutputService.get()

    if response.dry_run:
        output.info("Dry run — no documents modified")
    else:
        output.success(f"Updated metadata on {response.updated_count} document(s)")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Matched", str(response.matched_count))
    table.add_row("Updated", str(response.updated_count))
    table.add_row("Dry Run", str(response.dry_run))

    border_style = "blue" if response.dry_run else "green"
    title = "Bulk Metadata Dry Run" if response.dry_run else "Bulk Metadata Update"
    panel = Panel(table, title=title, border_style=border_style)
    output.console.print(panel)
