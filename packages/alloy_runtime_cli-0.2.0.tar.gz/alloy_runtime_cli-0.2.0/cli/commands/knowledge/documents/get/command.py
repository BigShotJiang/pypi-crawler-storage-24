"""Knowledge documents get command implementation."""

import typer

from cli.commands.knowledge.documents.get.presenter import present_document_details
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_documents_get_command(
    document: str = typer.Argument(
        ...,
        help="Document UUID",
    ),
    include_content: bool = typer.Option(
        False,
        "-c",
        "--include-content",
        help="Include original document content",
    ),
) -> None:
    """Get document details.

    Examples:
        ai2 knowledge documents get 550e8400-e29b-41d4-a716-446655440000
        ai2 kb documents get 550e8400-e29b-41d4-a716-446655440000 -c
    """
    _execute_get(document_id=document, include_content=include_content)


@async_command
async def _execute_get(document_id: str, include_content: bool) -> None:
    """Execute get document operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_document(
            document_id=document_id,
            include_content=include_content,
        )

    present_document_details(response, show_content=include_content)
