"""Presenter for knowledge document reingest command output."""

from rich.panel import Panel
from rich.table import Table

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import ReingestDocumentResponse


def _format_reingest_status(status: str) -> str:
    """Format reingest status with color."""
    status_colors = {
        "pending": "[yellow]pending[/]",
        "dry_run_complete": "[blue]dry_run_complete[/]",
    }
    return status_colors.get(status, status)


def present_reingest_result(response: ReingestDocumentResponse) -> None:
    """Present document reingest result.

    Args:
        response: ReingestDocumentResponse from server
    """
    output = OutputService.get()

    if response.dry_run:
        output.info("Dry run — no changes committed")
    else:
        output.success("Document queued for reingestion")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Document ID", format_uuid(response.document_id, short=False))
    table.add_row("Status", _format_reingest_status(response.status))
    table.add_row("Message", response.message)
    table.add_row("Document Type", response.document_type)

    if response.question_gen_agent_id:
        table.add_row(
            "Question Gen Agent",
            format_uuid(response.question_gen_agent_id, short=False),
        )
    if response.question_gen_template_id:
        table.add_row(
            "Question Gen Template",
            format_uuid(response.question_gen_template_id, short=False),
        )

    if response.dry_run and response.diff_stats:
        table.add_row("Diff Stats", str(response.diff_stats))

    if response.rejected:
        table.add_row("Rejected", f"[red]{response.rejection_reason}[/]")

    border_style = "blue" if response.dry_run else "green"
    title = "Reingest Dry Run" if response.dry_run else "Document Reingested"
    panel = Panel(table, title=title, border_style=border_style)
    output.console.print(panel)

    if response.dry_run and response.diff_unified:
        diff_panel = Panel(
            response.diff_unified,
            title="Preprocessing Diff",
            border_style="cyan",
        )
        output.console.print(diff_panel)
