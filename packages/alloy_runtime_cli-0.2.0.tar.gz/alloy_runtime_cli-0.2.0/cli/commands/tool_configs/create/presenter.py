"""Presenter for tool config creation output."""

import json

from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tool_configs import CreateToolConfigResponse


def present_tool_config_create_success(response: CreateToolConfigResponse) -> None:
    """Present successful tool config creation.

    Args:
        response: Tool config creation response from server
    """
    output = OutputService.get()

    output.success("Tool config created successfully")

    # Build a simple table for entity display
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Slug", response.slug)
    table.add_row("Name", response.name)
    table.add_row("Tool ID", response.tool_id)
    table.add_row("Description", format_optional(response.description))

    # Format ownership
    if response.user_id:
        table.add_row("Scope", "User")
    elif response.organization_id:
        table.add_row("Scope", "Organization")
    else:
        table.add_row("Scope", "Global")

    panel = Panel(table, title=f"Tool Config: {response.name}", border_style="green")
    output.console.print(panel)

    # Display config as syntax-highlighted JSON
    config_json = json.dumps(response.config, indent=2)
    syntax = Syntax(config_json, "json", theme="monokai", word_wrap=True)
    config_panel = Panel(syntax, title="Configuration", border_style="blue")
    output.console.print(config_panel)
