"""Presenter for tool config delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tool_configs import DeleteToolConfigResponse


def present_tool_config_delete_result(response: DeleteToolConfigResponse) -> None:
    """Present tool config deletion result.

    Args:
        response: DeleteToolConfigResponse from server
    """
    output = OutputService.get()

    output.success(
        f"Tool config '{response.deleted_tool_config.name}' "
        f"(slug: {response.deleted_tool_config.slug}) deleted successfully"
    )
