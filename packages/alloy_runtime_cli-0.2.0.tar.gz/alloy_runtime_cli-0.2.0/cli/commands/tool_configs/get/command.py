"""Tool config get command implementation."""

import typer

from cli.commands.tool_configs.get.presenter import present_tool_config_details
from cli.infrastructure.command import async_command, authenticated_client


def tool_configs_get_command(
    identifier: str = typer.Argument(
        ...,
        help="Tool config UUID or slug",
    ),
) -> None:
    """Get tool config details.

    Examples:
        ai tool-configs get rag-with-hyde
        ai tool-configs get 550e8400-e29b-41d4-a716-446655440000
        ai tc get my-search-config
    """
    _execute_get(identifier=identifier)


@async_command
async def _execute_get(identifier: str) -> None:
    """Execute get tool config operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_tool_config(identifier)

    present_tool_config_details(response)
