"""Presenter for tool config get command output."""

import json

from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tool_configs import GetToolConfigResponse


def present_tool_config_details(response: GetToolConfigResponse) -> None:
    """Present tool config details with Rich formatting.

    Args:
        response: GetToolConfigResponse from server
    """
    output = OutputService.get()

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("ID", format_uuid(response.id, short=False))
    table.add_row("Slug", response.slug)
    table.add_row("Name", response.name)
    table.add_row("Tool ID", response.tool_id)
    table.add_row("Description", format_optional(response.description))

    # Format ownership
    if response.user_id:
        table.add_row("Scope", "User")
        table.add_row("User ID", format_uuid(response.user_id, short=True))
    elif response.organization_id:
        table.add_row("Scope", "Organization")
        table.add_row(
            "Organization ID", format_uuid(response.organization_id, short=True)
        )
    else:
        table.add_row("Scope", "Global")

    table.add_row("Created At", format_datetime(response.created_at))
    table.add_row("Updated At", format_datetime(response.updated_at))

    panel = Panel(
        table,
        title=f"Tool Config: {response.name}",
        border_style="green",
    )
    output.console.print(panel)

    # Display config as syntax-highlighted JSON
    config_json = json.dumps(response.config, indent=2)
    syntax = Syntax(config_json, "json", theme="monokai", word_wrap=True)
    config_panel = Panel(syntax, title="Configuration", border_style="blue")
    output.console.print(config_panel)
