"""Presenter for pipeline daily costs command output."""

from decimal import Decimal

from alloy_runtime_types.dtos.pipeline_costs import DailyCostEntry

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_cost(cost: Decimal | None) -> str:
    if cost is None:
        return "-"
    return f"${cost:.4f}"


def present_pipeline_daily_costs(entries: list[DailyCostEntry]) -> None:
    output = OutputService.get()

    if not entries:
        output.info("No daily cost data found for the specified period")
        return

    columns = [
        ColumnConfig(
            source_field="date",
            header_label="Date",
            formatter=str,
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="execution_count",
            header_label="Executions",
            formatter=str,
            compact_line=1,
            compact_style="white",
        ),
        ColumnConfig(
            source_field="total_cost_usd",
            header_label="Total Cost",
            formatter=_format_cost,
            compact_line=1,
            compact_style="green bold",
        ),
        ColumnConfig(
            source_field="avg_cost_usd",
            header_label="Avg Cost",
            formatter=_format_cost,
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=entries,  # type: ignore[arg-type]
        title=f"Daily Costs ({len(entries)} days)",
        columns=columns,
    )
