"""Presenter for pipeline costs command output."""

from alloy_runtime_types.dtos.pipeline_costs import PipelineDefinitionCostSummary

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def _format_period(response: PipelineDefinitionCostSummary) -> str:
    """Format period dates for display."""
    return f"{response.period_start.strftime('%Y-%m-%d')} to {response.period_end.strftime('%Y-%m-%d')}"


def _format_cost(cost: float | None) -> str:
    """Format cost for display."""
    if cost is None:
        return "-"
    return f"${cost:.4f}"


def present_pipeline_costs(response: PipelineDefinitionCostSummary) -> None:
    """Present pipeline cost summary."""
    output = OutputService.get()

    fields = [
        FieldConfig("pipeline_definition_id", "Pipeline ID", str),
        FieldConfig("period", "Period", lambda _: _format_period(response)),
        FieldConfig("execution_count", "Total Executions", str),
        FieldConfig("completed_count", "Completed", str),
        FieldConfig("failed_count", "Failed", str),
        FieldConfig("total_cost_usd", "Total Cost", _format_cost),
        FieldConfig("avg_cost_usd", "Avg Cost", _format_cost),
        FieldConfig("min_cost_usd", "Min Cost", _format_cost),
        FieldConfig("max_cost_usd", "Max Cost", _format_cost),
    ]

    output.entity(response, "Pipeline Cost Summary", fields)
