"""Presenter for pipeline get command output."""

import json
from typing import Any

from rich.panel import Panel
from rich.syntax import Syntax

from alloy_runtime_types.dtos.pipeline import GetPipelineResponse

from cli.infrastructure.formatting.fields import format_datetime, format_optional
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def _format_input_schema(schema: dict[str, Any] | None) -> str:
    """Format input schema for display."""
    if not schema:
        return "(none)"
    schema_str = json.dumps(schema, indent=2)
    return schema_str[:100] + "..." if len(schema_str) > 100 else schema_str


def present_pipeline(response: GetPipelineResponse) -> None:
    """Present pipeline details with Rich formatting."""
    output = OutputService.get()

    fields = [
        FieldConfig("id", "ID", str),
        FieldConfig("name", "Name"),
        FieldConfig("description", "Description", format_optional),
        FieldConfig("is_public", "Public", lambda v: "Yes" if v else "No"),
        FieldConfig("created_at", "Created", format_datetime),
        FieldConfig("updated_at", "Updated", format_datetime),
        FieldConfig("input_schema", "Input Schema", _format_input_schema),
    ]

    output.entity(response, f"Pipeline: {response.name}", fields)

    # Show module content if available (only for owners)
    if response.module_content:
        syntax = Syntax(
            response.module_content,
            "python",
            theme="monokai",
            line_numbers=True,
        )
        output.console.print(Panel(syntax, title="Module Content"))
