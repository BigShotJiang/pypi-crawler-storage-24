"""Pipeline get command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.get.presenter import present_pipeline
from cli.infrastructure.command import async_command, authenticated_client


def pipelines_get_command(
    pipeline_id: str = typer.Argument(
        ...,
        help="Pipeline UUID",
    ),
) -> None:
    """Get details of a pipeline.

    Examples:
        ai pipelines get 123e4567-89ab-cdef-0123-456789abcdef
    """
    pipeline_uuid = validate_uuid(pipeline_id, "pipeline")
    _execute_get(pipeline_id=pipeline_uuid)


@async_command
async def _execute_get(pipeline_id: UUID) -> None:
    """Execute get pipeline operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_pipeline(pipeline_id)

    present_pipeline(response)
