from alloy_runtime_types.dtos.schedule import SetScheduleEnvVarsResponse

from cli.infrastructure.output import OutputService


def present_set_env_vars_result(response: SetScheduleEnvVarsResponse) -> None:
    output = OutputService.get()

    if not response.env_var_keys:
        output.success(f"Cleared all env vars for schedule {response.schedule_id}")
        return

    output.info(f"Set env vars for schedule {response.schedule_id}:")
    for key in response.env_var_keys:
        masked = response.masked_values.get(key, "***")
        output.info(f"  {key}: {masked}")
