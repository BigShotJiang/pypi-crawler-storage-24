"""Pipeline execution costs command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.executions.costs.presenter import present_execution_costs
from cli.infrastructure.command import async_command, authenticated_client


def pipeline_execution_costs_command(
    pipeline_id: str = typer.Argument(
        ...,
        help="Pipeline UUID",
    ),
    execution_id: str = typer.Argument(
        ...,
        help="Execution UUID",
    ),
) -> None:
    """Get cost summary for a pipeline execution.

    Shows LLM cost, RAG cost, and total cost breakdown.

    Examples:
        ai pipelines executions costs 123e... 456e...
    """
    pipeline_uuid = validate_uuid(pipeline_id, "pipeline")
    execution_uuid = validate_uuid(execution_id, "execution")
    _execute_costs(
        pipeline_id=pipeline_uuid,
        execution_id=execution_uuid,
    )


@async_command
async def _execute_costs(
    pipeline_id: UUID,
    execution_id: UUID,
) -> None:
    async with authenticated_client() as (_config, client):
        response = await client.get_execution_costs(
            pipeline_id,
            execution_id,
        )

    present_execution_costs(response)
