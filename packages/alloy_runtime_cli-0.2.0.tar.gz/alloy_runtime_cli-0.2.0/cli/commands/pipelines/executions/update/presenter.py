"""Presenter for pipeline execution update command output."""

from alloy_runtime_types.dtos.pipeline import UpdatePipelineExecutionResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def present_execution_update(response: UpdatePipelineExecutionResponse) -> None:
    output = OutputService.get()
    execution = response.execution

    fields = [
        FieldConfig("id", "Execution ID", str),
        FieldConfig("pipeline_definition_id", "Pipeline ID", str),
        FieldConfig("status", "Status"),
    ]

    output.entity(execution, "Execution Updated", fields)

    if execution.tags:
        tag_paths = ", ".join(t.tag_path for t in execution.tags)
        output.info(f"Tags: {tag_paths}")
    else:
        output.info("Tags: (none)")

    if execution.metadata:
        output.info(f"Metadata: {execution.metadata}")
