"""Pipeline execution get command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.executions.presenter import present_execution_detail
from cli.infrastructure.command import async_command, authenticated_client


def pipelines_executions_get_command(
    pipeline_id: str = typer.Argument(
        ...,
        help="Pipeline UUID",
    ),
    execution_id: str = typer.Argument(
        ...,
        help="Execution UUID",
    ),
) -> None:
    """Get details of a pipeline execution.

    Examples:
        ai pipelines executions get 123e4567... 456e7890...
    """
    p_uuid = validate_uuid(pipeline_id, "pipeline")
    e_uuid = validate_uuid(execution_id, "execution")
    _execute_get(pipeline_id=p_uuid, execution_id=e_uuid)


@async_command
async def _execute_get(pipeline_id: UUID, execution_id: UUID) -> None:
    """Execute get execution operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_pipeline_execution(pipeline_id, execution_id)

    present_execution_detail(response)
