"""Presenter for pipeline execution costs by step command output."""

from decimal import Decimal

from alloy_runtime_types.dtos.pipeline_costs import StepCostBreakdown

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_cost(cost: Decimal | None) -> str:
    if cost is None:
        return "-"
    return f"${cost:.4f}"


def present_execution_costs_by_step(entries: list[StepCostBreakdown]) -> None:
    output = OutputService.get()

    if not entries:
        output.info("No cost data by step found for this execution")
        return

    columns = [
        ColumnConfig(
            source_field="step_order",
            header_label="Order",
            formatter=str,
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="step_name",
            header_label="Step Name",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="execution_count",
            header_label="Executions",
            formatter=str,
            compact_line=1,
            compact_style="white",
        ),
        ColumnConfig(
            source_field="llm_cost_usd",
            header_label="LLM Cost",
            formatter=_format_cost,
            compact_line=2,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="rag_cost_usd",
            header_label="RAG Cost",
            formatter=_format_cost,
            compact_line=2,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="total_cost_usd",
            header_label="Total Cost",
            formatter=_format_cost,
            compact_line=1,
            compact_style="green bold",
        ),
    ]

    output.table(
        items=entries,  # type: ignore[arg-type]
        title=f"Costs by Step ({len(entries)} steps)",
        columns=columns,
    )
