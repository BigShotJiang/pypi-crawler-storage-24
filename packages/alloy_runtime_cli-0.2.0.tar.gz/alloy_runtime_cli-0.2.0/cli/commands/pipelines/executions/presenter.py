"""Presenters for pipeline executions command output."""

import json
from typing import cast

from pydantic import BaseModel

from alloy_runtime_types.dtos.pipeline import (
    GetPipelineExecutionResponse,
    ListPipelineExecutionsResponse,
    PipelineExecutionDetail,
)

from cli.infrastructure.formatting.fields import format_datetime, format_optional
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_status(status: str) -> str:
    """Format status with color hints."""
    return status


def _format_duration(duration_ms: int | None) -> str:
    """Format duration in human-readable format."""
    if not duration_ms:
        return "-"
    if duration_ms < 1000:
        return f"{duration_ms}ms"
    return f"{duration_ms / 1000:.1f}s"


def present_executions_list(response: ListPipelineExecutionsResponse) -> None:
    """Present list of executions with Rich table formatting."""
    output = OutputService.get()

    if not response.executions:
        output.info("No executions found")
        return

    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="status",
            header_label="Status",
            formatter=_format_status,
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="total_duration_ms",
            header_label="Duration",
            formatter=_format_duration,
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="queued_at",
            header_label="Queued",
            formatter=lambda x: x.strftime("%Y-%m-%d %H:%M") if x else "-",
            compact_line=2,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="external_id",
            header_label="External ID",
            formatter=lambda x: x or "-",
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=cast(list[BaseModel], response.executions),
        title=f"Executions ({response.total})",
        columns=columns,
    )


def _format_tags_from_execution(execution: PipelineExecutionDetail) -> str:
    """Format tags for display."""
    if not execution.tags:
        return "(none)"
    return ", ".join(t.tag_path for t in execution.tags)


def present_execution_detail(response: GetPipelineExecutionResponse) -> None:
    """Present execution details with Rich formatting."""
    output = OutputService.get()
    execution = response.execution

    fields = [
        FieldConfig("id", "Execution ID", str),
        FieldConfig("pipeline_definition_id", "Pipeline ID", str),
        FieldConfig("status", "Status"),
        FieldConfig("external_id", "External ID", format_optional),
        FieldConfig("queued_at", "Queued At", format_datetime),
        FieldConfig(
            "started_at", "Started At", lambda v: format_optional(v, format_datetime)
        ),
        FieldConfig(
            "completed_at",
            "Completed At",
            lambda v: format_optional(v, format_datetime),
        ),
        FieldConfig("total_duration_ms", "Duration", lambda v: _format_duration(v)),
        FieldConfig("error_message", "Error", format_optional),
        FieldConfig("tags", "Tags", lambda _: _format_tags_from_execution(execution)),
    ]

    output.entity(execution, f"Execution: {execution.status}", fields)

    # Show result data if present
    if execution.result_data:
        result_str = json.dumps(execution.result_data, indent=2)
        if len(result_str) > 1000:
            result_str = result_str[:1000] + "\n..."
        output.info(f"Result:\n{result_str}")

    # Show stdout/stderr if present
    if execution.execution_stdout:
        output.info(f"Stdout:\n{execution.execution_stdout[:500]}")

    if execution.execution_stderr:
        output.warning(f"Stderr:\n{execution.execution_stderr[:500]}")
