"""Pipeline approval checkpoint get command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.approvals.presenter import (
    present_approval_checkpoint,
    present_approval_not_found,
)
from cli.infrastructure.command import async_command, authenticated_client


def pipelines_approvals_get_command(
    execution_id: str = typer.Argument(
        ...,
        help="Pipeline execution UUID",
    ),
    approval_key: str = typer.Argument(
        ...,
        help="Approval checkpoint key",
    ),
) -> None:
    """Get details of an approval checkpoint.

    Examples:
        ai pipelines approvals get 123e4567... pe:123:approval:review_step
    """
    e_uuid = validate_uuid(execution_id, "execution")
    _execute_get(execution_id=e_uuid, approval_key=approval_key)


@async_command
async def _execute_get(execution_id: UUID, approval_key: str) -> None:
    """Execute get approval checkpoint operation."""
    async with authenticated_client() as (_config, client):
        checkpoint = await client.get_approval_checkpoint(execution_id, approval_key)

    if checkpoint is None:
        present_approval_not_found(str(execution_id), approval_key)
        raise typer.Exit(code=1)

    present_approval_checkpoint(checkpoint)
