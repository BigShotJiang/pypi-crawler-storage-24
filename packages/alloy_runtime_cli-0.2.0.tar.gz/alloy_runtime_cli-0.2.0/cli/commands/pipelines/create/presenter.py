"""Presenter for pipeline create command output."""

from alloy_runtime_types.dtos.pipeline import CreatePipelineResponse

from cli.infrastructure.formatting.fields import format_datetime
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def present_pipeline_create_success(response: CreatePipelineResponse) -> None:
    """Present pipeline creation success with Rich formatting."""
    output = OutputService.get()

    fields = [
        FieldConfig("id", "ID", str),
        FieldConfig("name", "Name"),
        FieldConfig("description", "Description", lambda v: v or "(none)"),
        FieldConfig("is_public", "Public", lambda v: "Yes" if v else "No"),
        FieldConfig("created_at", "Created", format_datetime),
    ]

    output.entity(response, f"Pipeline Created: {response.name}", fields)
