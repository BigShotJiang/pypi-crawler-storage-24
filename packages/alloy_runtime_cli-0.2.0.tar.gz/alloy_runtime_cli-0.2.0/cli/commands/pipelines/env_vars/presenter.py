from alloy_runtime_types.dtos.pipeline import SetPipelineEnvVarsResponse

from cli.infrastructure.output import OutputService


def present_set_env_vars_result(response: SetPipelineEnvVarsResponse) -> None:
    output = OutputService.get()

    if not response.env_var_keys:
        output.success(f"Cleared all env vars for pipeline {response.pipeline_id}")
        return

    output.info(f"Set env vars for pipeline {response.pipeline_id}:")
    for key in response.env_var_keys:
        masked = response.masked_values.get(key, "***")
        output.info(f"  {key}: {masked}")
