# alloy-runtime-cli

Terminal client for Alloy Runtime.

## Install

```bash
pip install alloy-runtime-cli
```

For isolated user installs, `pipx` is also a good fit:

```bash
pipx install alloy-runtime-cli
```

## Command

The installed command is `alloy`.

```bash
alloy --help
alloy login
alloy --api-url https://your-alloy-runtime-host whoami
alloy api-keys create --scope read --scope update --scope use --description "automation key"
```

## Configuration

The CLI reads configuration in this order:

1. CLI flags such as `--api-url` and `--api-key`
2. Environment variables like `ALLOY_RUNTIME_API_URL`
3. Stored credentials in `~/.alloy-runtime/config`

Use `alloy login` to save an API key locally, or set the environment variables when
running on a VPS.

