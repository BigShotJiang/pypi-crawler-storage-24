"""Copilot CLI token tracker."""

__all__ = ["__version__"]

__version__ = "0.2.0"

