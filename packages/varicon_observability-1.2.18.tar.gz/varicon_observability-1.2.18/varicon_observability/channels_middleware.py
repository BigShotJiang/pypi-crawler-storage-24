"""Django Channels middleware for WebSocket trace context and tenant_id injection."""

import logging
from urllib.parse import parse_qs
from opentelemetry import trace
from varicon_observability.context import tenant_context

logger = logging.getLogger(__name__)


class WebSocketTraceMiddleware:
    """
    Django Channels ASGI middleware that:
    1. Extracts tenant_id from WebSocket query params and sets it in context
    2. Creates a span covering the entire WebSocket connection lifecycle
    3. Ensures all logs within the connection have trace_id, span_id, and tenant_id
    """

    def __init__(self, inner):
        self.inner = inner
        self.tracer = trace.get_tracer("varicon.websocket", "1.0.0")

    async def __call__(self, scope, receive, send):
        query_string = scope.get("query_string", b"").decode("utf-8")
        query_params = parse_qs(query_string)

        tenant_id = query_params.get("tenant", [None])[0]
        if tenant_id:
            tenant_context.set(str(tenant_id))

        path = scope.get("path", "/")
        span_name = f"WEBSOCKET {path}"

        with self.tracer.start_as_current_span(
            span_name,
            kind=trace.SpanKind.SERVER,
            attributes={
                "websocket.path": path,
                "websocket.type": scope.get("type", "websocket"),
                "tenant_id": str(tenant_id) if tenant_id else "unknown",
            },
        ) as span:
            ctx = span.get_span_context()
            if ctx.is_valid:
                logger.debug(
                    "[WS_TRACE] %s trace_id=%s span_id=%s tenant_id=%s",
                    span_name,
                    format(ctx.trace_id, "032x"),
                    format(ctx.span_id, "016x"),
                    tenant_id,
                )

            return await self.inner(scope, receive, send)
