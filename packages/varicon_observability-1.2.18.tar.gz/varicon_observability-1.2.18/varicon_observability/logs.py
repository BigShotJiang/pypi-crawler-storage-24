import logging
from opentelemetry._logs import set_logger_provider, get_logger_provider
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.sdk.resources import Resource
from .config import ObservabilityConfig
from .filters import NoisyLoggerFilter, LogRecordSanitizerFilter, HealthCheckFilter
from .log_processor import TraceContextLogProcessor

logger = logging.getLogger(__name__)

_logger_provider = None

def setup_logging() -> bool:
    global _logger_provider

    if not ObservabilityConfig.OTEL_ENABLED or not ObservabilityConfig.OTEL_EXPORTER_OTLP_ENDPOINT:
        return False

    try:
        resource = Resource.create({
            "service.name": ObservabilityConfig.OTEL_SERVICE_NAME,
            "service.version": ObservabilityConfig.OTEL_SERVICE_VERSION,
            "deployment.environment": ObservabilityConfig.OTEL_DEPLOYMENT_ENVIRONMENT,
        })

        if _logger_provider is not None:
            return True

        provider = LoggerProvider(resource=resource)

        headers = ObservabilityConfig.parse_headers()

        if ObservabilityConfig.OTEL_EXPORTER_OTLP_PROTOCOL == "grpc":
            from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
            endpoint = ObservabilityConfig.OTEL_EXPORTER_OTLP_ENDPOINT
            insecure = not ObservabilityConfig.is_secure_endpoint()
            exporter = OTLPLogExporter(
                endpoint=endpoint,
                headers=headers if headers else None,
                insecure=insecure,
            )
        else:
            from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter
            endpoint = ObservabilityConfig.OTEL_EXPORTER_OTLP_ENDPOINT
            if not endpoint.endswith("/v1/logs"):
                endpoint = endpoint.rstrip("/") + "/v1/logs"
            exporter = OTLPLogExporter(
                endpoint=endpoint,
                headers=headers if headers else None,
            )

        batch_processor = BatchLogRecordProcessor(exporter)
        trace_processor = TraceContextLogProcessor()

        provider.add_log_record_processor(trace_processor)
        provider.add_log_record_processor(batch_processor)

        # Only assign the module-level reference AFTER full initialization.
        # If anything above throws, _logger_provider stays None so
        # attach_log_handlers() won't create handlers with a broken provider.
        _logger_provider = provider
        set_logger_provider(_logger_provider)

        logger.info("OpenTelemetry logging configured with trace context injection")
        return True

    except Exception as e:
        logger.error(f"Failed to setup logging: {e}", exc_info=True)
        return False


def attach_log_handlers():
    from .trace_filter import TraceContextFilter
    from .filters import HealthCheckFilter as _HealthCheckFilter

    if not _logger_provider:
        return

    root_logger = logging.getLogger()

    # Remove any existing OTel handlers — they may reference a stale provider
    # (e.g., after fork, the old provider's batch threads are dead).
    # Always replace with a handler using the current _logger_provider.
    root_logger.handlers = [h for h in root_logger.handlers if not isinstance(h, LoggingHandler)]

    handler = LoggingHandler(logger_provider=_logger_provider)
    handler.addFilter(LogRecordSanitizerFilter())  # Must run before NoisyLoggerFilter
    handler.addFilter(NoisyLoggerFilter())
    handler.addFilter(HealthCheckFilter())
    # Add TraceContextFilter to the OTel handler directly so it runs for ALL
    # logs (root logger filters don't run for records propagated from child loggers).
    handler.addFilter(TraceContextFilter())
    root_logger.addHandler(handler)
    # Ensure root logger is at least INFO so that info-level logs reach the OTel handler.
    # Django's LOGGING dictConfig sets root to INFO already, but FastAPI/plain Python
    # defaults to WARNING (30) which silently drops INFO records before any handler sees them.
    # Levels lower than INFO (e.g. DEBUG set explicitly) are preserved.
    if root_logger.level > logging.INFO:
        root_logger.setLevel(logging.INFO)

    framework_loggers = [
        "django",
        "django.request",
        "django.db.backends",
        "fastapi",
        "uvicorn",
        "uvicorn.access",
        "uvicorn.error",
        "celery",
        "celery.task",
        "celery.worker",
        "integration-logger",
        "integration",
        "integration.xero",
        "integration.xero.background_tasks",
        "integration.xero.background_tasks.sync_cost_code",
        "integration.xero.background_tasks.sync_suppliers",
        "integration.xero.background_tasks.sync_purchase_order",
        "integration.myob",
        "application",
        "project",
        "project.tasks",
        "project.entrypoints",
        "varicon",
        "api",
        "api.management",
        "api.management.commands",
        "api.management.commands.sqs_worker",
    ]

    # These loggers emit one record per HTTP request. Apply HealthCheckFilter
    # directly on the logger (not just the handler) so health check records are
    # dropped before reaching any handler — even when uvicorn resets propagate=False
    # after our setup, or when the logger has its own handlers.
    _access_loggers = {"uvicorn.access", "django.request"}

    for name in framework_loggers:
        try:
            lg = logging.getLogger(name)
            # Remove any stale or accidental OTel handlers from child loggers
            # to prevent duplicate exports when propagate is True
            lg.handlers = [h for h in lg.handlers if not isinstance(h, LoggingHandler)]

            # Add trace context filter (only once)
            if not any(isinstance(f, TraceContextFilter) for f in lg.filters):
                lg.addFilter(TraceContextFilter())

            # Add health check filter to access loggers so health check records
            # never reach SigNoz regardless of propagation or handler configuration
            if name in _access_loggers:
                if not any(isinstance(f, _HealthCheckFilter) for f in lg.filters):
                    lg.addFilter(_HealthCheckFilter())

            lg.propagate = True
            if lg.level == logging.NOTSET or lg.level > logging.INFO:
                lg.setLevel(logging.INFO)
        except Exception:
            pass

    manager = logging.Logger.manager
    for logger_name in list(manager.loggerDict.keys()):
        try:
            lg = manager.loggerDict[logger_name]
            if isinstance(lg, logging.Logger):
                lg.propagate = True
        except Exception:
            pass


def ensure_all_logs_captured():
    """Ensure all logs are captured by OpenTelemetry.

    Adds a LoggingHandler to the root logger if one is not already present,
    so that all application logs are forwarded to the OTel log pipeline.
    """
    provider = get_logger_provider()
    if not provider or not isinstance(provider, LoggerProvider):
        return

    root_logger = logging.getLogger()
    if any(isinstance(h, LoggingHandler) for h in root_logger.handlers):
        return

    handler = LoggingHandler(logger_provider=provider)
    handler.addFilter(NoisyLoggerFilter())
    root_logger.addHandler(handler)
    logger.debug("Added OTel LoggingHandler to root logger via ensure_all_logs_captured()")

