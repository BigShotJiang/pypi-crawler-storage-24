import os
from typing import Optional

class ObservabilityConfig:
    OTEL_ENABLED = os.getenv("OTEL_ENABLED", "true").lower() == "true"
    OTEL_SERVICE_NAME = os.getenv("OTEL_SERVICE_NAME", "varicon-service")
    OTEL_SERVICE_VERSION = os.getenv("OTEL_SERVICE_VERSION", "1.0.0")
    OTEL_EXPORTER_OTLP_ENDPOINT = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")
    OTEL_EXPORTER_OTLP_HEADERS = os.getenv("OTEL_EXPORTER_OTLP_HEADERS", "")
    OTEL_EXPORTER_OTLP_PROTOCOL = os.getenv("OTEL_EXPORTER_OTLP_PROTOCOL", "grpc")
    OTEL_DEPLOYMENT_ENVIRONMENT = os.getenv("OTEL_DEPLOYMENT_ENVIRONMENT", "production")

    OTEL_METRIC_EXPORT_INTERVAL = int(os.getenv("OTEL_METRIC_EXPORT_INTERVAL", "60000"))

    # SigNoz Cloud access token (convenience — auto-added as signoz-access-token header)
    SIGNOZ_ACCESS_TOKEN = os.getenv("SIGNOZ_ACCESS_TOKEN", "")

    # Span filtering configuration
    OTEL_FILTER_DATABASE_SPANS = os.getenv("OTEL_FILTER_DATABASE_SPANS", "true").lower() == "true"
    OTEL_FILTER_REDIS_SPANS = os.getenv("OTEL_FILTER_REDIS_SPANS", "false").lower() == "true"

    @classmethod
    def parse_headers(cls) -> dict:
        headers = {}
        if cls.OTEL_EXPORTER_OTLP_HEADERS:
            for header in cls.OTEL_EXPORTER_OTLP_HEADERS.split(","):
                if "=" in header:
                    key, value = header.split("=", 1)
                    headers[key.strip()] = value.strip()
        # Auto-inject SIGNOZ_ACCESS_TOKEN if set and not already in headers
        if cls.SIGNOZ_ACCESS_TOKEN and "signoz-access-token" not in headers:
            headers["signoz-access-token"] = cls.SIGNOZ_ACCESS_TOKEN
        return headers

    @classmethod
    def is_secure_endpoint(cls) -> bool:
        """Check if the OTLP endpoint uses HTTPS (TLS)."""
        endpoint = cls.OTEL_EXPORTER_OTLP_ENDPOINT or ""
        return endpoint.startswith("https://")
