import logging
from typing import Optional

from opentelemetry import metrics
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.sdk.resources import Resource

from .config import ObservabilityConfig

logger = logging.getLogger(__name__)

_meter_provider = None


def setup_metrics(enable_system_metrics: bool = True) -> bool:
    global _meter_provider

    if not ObservabilityConfig.OTEL_ENABLED or not ObservabilityConfig.OTEL_EXPORTER_OTLP_ENDPOINT:
        return False

    try:
        resource = Resource.create({
            "service.name": ObservabilityConfig.OTEL_SERVICE_NAME,
            "service.version": ObservabilityConfig.OTEL_SERVICE_VERSION,
            "deployment.environment": ObservabilityConfig.OTEL_DEPLOYMENT_ENVIRONMENT,
        })

        headers = ObservabilityConfig.parse_headers()

        if ObservabilityConfig.OTEL_EXPORTER_OTLP_PROTOCOL == "grpc":
            from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
            endpoint = ObservabilityConfig.OTEL_EXPORTER_OTLP_ENDPOINT
            insecure = not ObservabilityConfig.is_secure_endpoint()
            exporter = OTLPMetricExporter(
                endpoint=endpoint,
                headers=headers if headers else None,
                insecure=insecure,
            )
        else:
            from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
            endpoint = ObservabilityConfig.OTEL_EXPORTER_OTLP_ENDPOINT
            if not endpoint.endswith("/v1/metrics"):
                endpoint = endpoint.rstrip("/") + "/v1/metrics"
            exporter = OTLPMetricExporter(
                endpoint=endpoint,
                headers=headers if headers else None,
            )

        export_interval = ObservabilityConfig.OTEL_METRIC_EXPORT_INTERVAL
        reader = PeriodicExportingMetricReader(exporter, export_interval_millis=export_interval)
        _meter_provider = MeterProvider(resource=resource, metric_readers=[reader])
        metrics.set_meter_provider(_meter_provider)

        if enable_system_metrics:
            _instrument_system_metrics()

        return True

    except Exception as e:
        logger.error(f"Failed to setup metrics: {e}", exc_info=True)
        return False


def _instrument_system_metrics(collect_per_cpu: bool = False) -> None:
    """Instrument system and runtime metrics (CPU, memory, disk, network, process)."""
    try:
        from .system_metrics import start_system_metrics

        meter = get_meter()
        start_system_metrics(meter, collect_per_cpu=collect_per_cpu)
        logger.info("System metrics instrumentation enabled (built-in psutil collector)")
    except ImportError:
        logger.warning(
            "psutil is not installed — system metrics disabled. "
            "Install with: pip install varicon-observability[metrics]"
        )
    except Exception as e:
        logger.warning(f"System metrics instrumentation failed: {e}", exc_info=True)


def get_meter(
    name: Optional[str] = None,
    version: Optional[str] = None,
):
    """Get a meter for creating custom metrics. Call setup_observability() first."""
    return metrics.get_meter(
        name or ObservabilityConfig.OTEL_SERVICE_NAME,
        version or ObservabilityConfig.OTEL_SERVICE_VERSION,
    )
