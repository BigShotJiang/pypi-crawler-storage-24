import contextvars

# Context variables for request-scoped log injection
tenant_context = contextvars.ContextVar("tenant_id", default="unknown-tenant")
username_context = contextvars.ContextVar("username", default="")
request_id_context = contextvars.ContextVar("request_id", default="")
client_type_context = contextvars.ContextVar("client_type", default="")
request_body_context = contextvars.ContextVar("request_body", default="")
app_name_context = contextvars.ContextVar('app_name',default="")
screen_name_context = contextvars.ContextVar("screen_name", default="")
trace_id_context = contextvars.ContextVar('trace_id',default='')
