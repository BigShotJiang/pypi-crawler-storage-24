"""Marketplace sources API router for GitHub repository ingestion.

This router provides endpoints for managing GitHub repository sources that can be
scanned for Claude Code artifacts. It integrates with the service layer for scanning,
repository layer for data access, and transaction handler for atomic updates.

API Endpoints:
    POST /marketplace/sources - Create new GitHub source
    GET /marketplace/sources - List all sources (paginated)
    GET /marketplace/sources/{id} - Get source by ID
    PATCH /marketplace/sources/{id} - Update source
    DELETE /marketplace/sources/{id} - Delete source
    POST /marketplace/sources/{id}/rescan - Trigger rescan
    GET /marketplace/sources/{id}/artifacts - List artifacts with filters
    PATCH /marketplace/sources/{id}/artifacts/{entry_id} - Update artifact name
    POST /marketplace/sources/{id}/import - Import artifacts to collection
    PATCH /marketplace/sources/{id}/artifacts/{entry_id}/exclude - Mark artifact as excluded
    DELETE /marketplace/sources/{id}/artifacts/{entry_id}/exclude - Restore excluded artifact
    GET /marketplace/sources/{id}/catalog/{entry_id}/path-tags - Get path-based tag suggestions
    PATCH /marketplace/sources/{id}/catalog/{entry_id}/path-tags - Update path segment approval status
    GET /marketplace/sources/{id}/artifacts/{path}/files - Get file tree
    GET /marketplace/sources/{id}/artifacts/{path}/files/{file_path} - Get file content
    GET /marketplace/sources/{id}/auto-tags - Get auto-tags from GitHub topics
    PATCH /marketplace/sources/{id}/auto-tags - Approve/reject auto-tags
    POST /marketplace/sources/{id}/refresh-auto-tags - Refresh auto-tags from GitHub
    POST /marketplace/sources/bulk-refresh-auto-tags - Bulk refresh auto-tags
"""

import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
import time
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Set

if TYPE_CHECKING:
    from skillmeat.cache.repositories import (
        ImportContext,
        MarketplaceCatalogRepository,
        MarketplaceSourceRepository,
        MarketplaceTransactionHandler,
        MergeResult,
    )

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse
from skillmeat.api.dependencies import (
    ArtifactManagerDep,
    CollectionManagerDep,
    MarketplaceCatalogRepoDep,
    MarketplaceSourceConcreteRepoDep,
    MarketplaceSourceRepoDep,
    MarketplaceTransactionHandlerDep,
    get_auth_context,
    require_auth,
)
from skillmeat.api.schemas.auth import AuthContext
# ORM model imports — used for CONSTRUCTION of new objects in the scan pipeline,
# not for direct session queries (all session access is via repository methods).
from skillmeat.cache.models import MarketplaceCatalogEntry, MarketplaceSource
# Default collection identifier — kept in sync with skillmeat.cache.models.DEFAULT_COLLECTION_ID
DEFAULT_COLLECTION_ID = "default"
from skillmeat.api.schemas.common import PageInfo
from skillmeat.api.schemas.discovery import (
    BulkSyncItemResult,
    BulkSyncRequest,
    BulkSyncResponse,
)
from skillmeat.api.schemas.marketplace import (
    AutoTagRefreshResponse,
    AutoTagSegment,
    AutoTagsResponse,
    BulkAutoTagRefreshItemResult,
    BulkAutoTagRefreshRequest,
    BulkAutoTagRefreshResponse,
    CatalogEntryResponse,
    CatalogListResponse,
    CreateSourceRequest,
    DetectedArtifact,
    ExcludeArtifactRequest,
    ExtractedSegmentResponse,
    FileContentResponse,
    FileTreeEntry,
    FileTreeResponse,
    ImportRequest,
    ImportResultDTO,
    InferUrlRequest,
    InferUrlResponse,
    PathSegmentsResponse,
    ReimportRequest,
    ReimportResponse,
    ScanRequest,
    ScanResultDTO,
    SourceListResponse,
    SourceResponse,
    UpdateAutoTagRequest,
    UpdateAutoTagResponse,
    UpdateCatalogEntryNameRequest,
    UpdateSegmentStatusRequest,
    UpdateSegmentStatusResponse,
    UpdateSourceRequest,
)
from skillmeat.api.utils.github_cache import (
    DEFAULT_CONTENT_TTL,
    DEFAULT_TREE_TTL,
    build_content_key,
    build_tree_key,
    get_github_file_cache,
)
# NotFoundError is a domain exception — kept as a direct runtime import.
# ImportContext and MergeResult are data-class helpers used only as type hints
# (string annotations), so they live in the TYPE_CHECKING block above.
# MarketplaceCatalogRepository, MarketplaceSourceRepository, and
# MarketplaceTransactionHandler are injected via DI aliases above.
from skillmeat.cache.repositories import NotFoundError
from skillmeat.core.artifact import ArtifactType
from skillmeat.core.manifest_extractors import extract_deep_search_text
from skillmeat.core.github_client import GitHubClientError
from skillmeat.core.marketplace.github_scanner import (
    GitHubScanner,
    RateLimitError,
    scan_github_source,
)
from skillmeat.core.marketplace.import_coordinator import (
    ConflictStrategy,
    ImportCoordinator,
)
from skillmeat.core.marketplace.source_manager import SourceManager
from skillmeat.core.path_tags import PathSegmentExtractor, PathTagConfig
from skillmeat.core.validation import validate_artifact_name
from skillmeat.utils.metadata import extract_frontmatter
from skillmeat.observability.metrics import (
    github_requests_total,
    marketplace_scan_artifacts_total,
    skillmeat_clone_duration_seconds,
    skillmeat_extraction_duration_seconds,
    skillmeat_scan_total_duration_seconds,
)
from skillmeat.observability.tracing import trace_operation

logger = logging.getLogger(__name__)

# Confidence threshold for hiding low-quality entries
CONFIDENCE_THRESHOLD = 30

# Clone timeout configuration (default: 5 minutes)
CLONE_TIMEOUT_SECONDS = int(os.environ.get("SKILLMEAT_CLONE_TIMEOUT", "300"))

# Module-level flag for git availability (cached after first check)
_git_available: bool | None = None

# Minimum disk space in bytes (default 500MB)
MIN_CLONE_DISK_SPACE_MB = int(os.environ.get("SKILLMEAT_MIN_CLONE_DISK_MB", "500"))
MIN_CLONE_DISK_SPACE_BYTES = MIN_CLONE_DISK_SPACE_MB * 1024 * 1024


def _get_artifact_count_bucket(count: int) -> str:
    """Get histogram bucket label for artifact count.

    Args:
        count: Number of artifacts

    Returns:
        Bucket label for metrics grouping
    """
    if count <= 5:
        return "0-5"
    elif count <= 20:
        return "5-20"
    elif count <= 50:
        return "20-50"
    else:
        return "50+"


class CloneTimeoutError(Exception):
    """Raised when git clone operation times out."""

    pass


class CloneError(Exception):
    """Raised when git clone operation fails for any reason."""

    pass


class InsufficientDiskSpaceError(Exception):
    """Raised when there is not enough disk space for clone operation."""

    pass


async def check_git_available() -> bool:
    """Check if git binary is available in PATH.

    Performs a one-time check for git binary availability and caches the result
    in a module-level flag. Subsequent calls return the cached value.

    The check validates both:
    1. Git binary exists in PATH (using shutil.which)
    2. Git binary is executable and returns version info

    Returns:
        True if git is available and working, False otherwise.

    Side Effects:
        - Caches result in module-level _git_available flag
        - Logs warning if git not found (with PATH for debugging)
        - Logs info if git found (with version and path)
    """
    global _git_available

    # Return cached result if available
    if _git_available is not None:
        return _git_available

    # Check if git binary exists in PATH
    git_path = shutil.which("git")
    if not git_path:
        logger.warning(
            "Git binary not found in PATH - clone-based indexing disabled",
            extra={"search_path": os.environ.get("PATH", "")},
        )
        _git_available = False
        return False

    # Validate git binary by running --version
    try:
        result = subprocess.run(
            ["git", "--version"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            logger.info(
                "Git available - clone-based indexing enabled",
                extra={"version": version, "path": git_path},
            )
            _git_available = True
            return True
    except Exception as e:
        logger.warning(
            "Git check failed - clone-based indexing disabled", extra={"error": str(e)}
        )

    _git_available = False
    return False


def is_git_available() -> bool:
    """Synchronous check for git availability using cached value.

    Returns the cached git availability status. Must call check_git_available()
    first (typically at startup) to populate the cache.

    Returns:
        True if git is available (cached), False if not available or not yet checked.

    Note:
        Returns False if check_git_available() has never been called.
        Use this for synchronous contexts where the async check has already run.
    """
    return _git_available if _git_available is not None else False




router = APIRouter(
    prefix="/marketplace/sources",
    tags=["marketplace-sources"],
)


# =============================================================================
# Helper Functions
# =============================================================================


def _get_github_api_call_count() -> int:
    """Get total GitHub API calls from prometheus metrics.

    Returns:
        Total number of GitHub API calls across all operations and statuses.
    """
    total = 0
    try:
        for sample in github_requests_total.collect()[0].samples:
            total += int(sample.value)
    except (IndexError, ValueError, AttributeError):
        # Metrics not initialized or unavailable - return 0
        pass
    return total


def validate_file_path(path: str) -> str:
    """Validate and sanitize file path to prevent path traversal attacks.

    This function checks for common path traversal attack vectors including:
    - Parent directory references (..)
    - Absolute paths (starting with / or \\)
    - Null byte injection
    - URL-encoded traversal attempts

    Args:
        path: File path to validate

    Returns:
        Normalized, validated path with forward slashes

    Raises:
        HTTPException 400: If path contains traversal attempts or invalid characters
    """
    # Reject null bytes (can bypass validation in some systems)
    if "\x00" in path:
        logger.warning(f"Null byte injection attempt in path: {repr(path)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file path: null bytes not allowed",
        )

    # Normalize path separators (Windows to Unix)
    normalized = path.replace("\\", "/")

    # Reject absolute paths
    if normalized.startswith("/"):
        logger.warning(f"Absolute path attempt: {path}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file path: absolute paths not allowed",
        )

    # Reject path traversal attempts
    # Check for ".." in various forms that could bypass basic checks
    traversal_patterns = [
        "..",  # Direct parent reference
        "./.",  # Hidden traversal via current dir
    ]

    for pattern in traversal_patterns:
        if pattern in normalized:
            logger.warning(f"Path traversal attempt: {path}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid file path: path traversal not allowed",
            )

    # Additional check: split by / and verify no segment is ".."
    segments = normalized.split("/")
    for segment in segments:
        if segment == "..":
            logger.warning(f"Path traversal via segment: {path}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid file path: path traversal not allowed",
            )

    # Reject paths with URL-encoded traversal (e.g., %2e%2e)
    # This handles cases where the framework might not have decoded yet
    if re.search(r"%2e%2e|%252e%252e", path, re.IGNORECASE):
        logger.warning(f"URL-encoded traversal attempt: {path}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file path: encoded traversal not allowed",
        )

    return normalized


def validate_source_id(source_id: str) -> str:
    """Validate source ID format.

    Args:
        source_id: Source identifier to validate

    Returns:
        Validated source ID

    Raises:
        HTTPException 400: If source ID format is invalid
    """
    # UUID format or alphanumeric with dashes
    if not re.match(r"^[a-zA-Z0-9\-]+$", source_id):
        logger.warning(f"Invalid source ID format: {source_id}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid source ID format",
        )
    return source_id


def parse_repo_url(repo_url: str) -> tuple[str, str]:
    """Parse GitHub repository URL to extract owner and repo name.

    Args:
        repo_url: Full GitHub repository URL

    Returns:
        Tuple of (owner, repo_name)

    Raises:
        ValueError: If URL format is invalid
    """
    # Remove trailing slash and .git
    url = repo_url.rstrip("/").replace(".git", "")

    # Match https://github.com/{owner}/{repo}
    match = re.match(r"^https://github\.com/([^/]+)/([^/]+)$", url)
    if not match:
        raise ValueError(
            f"Invalid GitHub repository URL format. "
            f"Expected: https://github.com/owner/repo, got: {repo_url}"
        )

    return match.group(1), match.group(2)


async def _validate_manual_map_paths(
    manual_map: dict[str, str],
    owner: str,
    repo: str,
    ref: str,
) -> None:
    """Validate that directory paths in manual_map exist in the repository.

    Fetches the repository tree from GitHub and verifies each directory path
    exists. Uses cached tree data when available to avoid extra API calls.

    Args:
        manual_map: Dictionary mapping directory paths to artifact types
        owner: Repository owner
        repo: Repository name
        ref: Git reference (branch, tag, SHA)

    Raises:
        HTTPException 422: If any directory path doesn't exist in repository
        HTTPException 500: If GitHub API call fails
    """
    if not manual_map:
        return

    try:
        # Initialize scanner to fetch tree (reuses cached data if available)
        scanner = GitHubScanner()
        tree, _actual_ref = scanner._fetch_tree(owner, repo, ref)

        # Extract all directory paths from tree
        # Tree items have "type": "tree" for directories, "type": "blob" for files
        dir_paths = {item["path"] for item in tree if item.get("type") == "tree"}

        # Validate each directory path in manual_map
        invalid_paths = []
        for dir_path in manual_map.keys():
            if dir_path not in dir_paths:
                invalid_paths.append(dir_path)

        if invalid_paths:
            # Format error message with all invalid paths
            paths_str = ", ".join(f"'{p}'" for p in sorted(invalid_paths))
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Invalid directory path(s) not found in repository: {paths_str}",
            )

        logger.debug(
            f"Validated {len(manual_map)} manual_map paths in {owner}/{repo}@{ref}"
        )

    except HTTPException:
        # Re-raise validation errors
        raise
    except Exception as e:
        logger.error(
            f"Failed to validate manual_map paths for {owner}/{repo}@{ref}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to validate directory paths: {str(e)}",
        ) from e


def get_composite_aggregates(catalog_repo: "MarketplaceCatalogRepository") -> Dict[str, Any]:
    """Compute aggregate composite member data from the local DB cache.

    Returns member count and child artifact types by issuing a single SQL query
    that JOINs ``composite_memberships`` with ``artifacts`` to collect type
    information — avoiding N+1 round trips.

    The result is scoped globally (across all collections) because marketplace
    sources are GitHub repos and there is no direct FK between them and local
    composite artifacts.  Callers should cache this result per request.

    Args:
        catalog_repo: Injected MarketplaceCatalogRepository instance.

    Returns:
        Dictionary with two keys:

        .. code-block:: python

            {
                "member_count": int,        # total membership edges
                "child_types": List[str],   # deduplicated child artifact types
            }

        Returns ``{"member_count": 0, "child_types": []}`` on any DB error
        so that failures are non-fatal and never block source listing.
    """
    return catalog_repo.get_composite_aggregates()


def source_to_response(
    source: MarketplaceSource,
    composite_aggregates: Optional[Dict[str, Any]] = None,
    counts_by_status: Optional[Dict[str, int]] = None,
) -> SourceResponse:
    """Convert MarketplaceSource ORM model to API response.

    Args:
        source: MarketplaceSource ORM instance.
        composite_aggregates: Optional pre-computed composite aggregate data
            (from ``get_composite_aggregates()``).  When provided and the
            source contains composite-type artifacts, ``composite_member_count``
            and ``composite_child_types`` are populated on the response.  Pass
            ``None`` to leave those fields null.
        counts_by_status: Optional pre-computed catalog status counts for this
            source (from ``CatalogRepository.count_by_status(source_id)``).
            When provided, ``new_artifact_count``, ``updated_artifact_count``,
            and ``imported_count`` are populated.  Pass ``None`` to leave them
            at their defaults (0).

    Returns:
        SourceResponse DTO for API.
    """
    counts_by_type = source.get_counts_by_type_dict()

    # Populate composite aggregate fields only when the source has composites
    composite_member_count: Optional[int] = None
    composite_child_types: Optional[List[str]] = None
    if counts_by_type.get("composite", 0) > 0 and composite_aggregates is not None:
        composite_member_count = composite_aggregates.get("member_count")
        composite_child_types = composite_aggregates.get("child_types") or []

    # Resolve status-based counts from pre-computed dict (or default to 0)
    status_counts = counts_by_status or {}

    return SourceResponse(
        id=source.id,
        repo_url=source.repo_url,
        owner=source.owner,
        repo_name=source.repo_name,
        ref=source.ref,
        root_hint=source.root_hint,
        trust_level=source.trust_level,
        visibility=source.visibility,
        scan_status=source.scan_status,
        artifact_count=source.artifact_count,
        last_sync_at=source.last_sync_at,
        last_error=source.last_error,
        created_at=source.created_at,
        updated_at=source.updated_at,
        description=source.description,
        notes=source.notes,
        enable_frontmatter_detection=source.enable_frontmatter_detection,
        manual_map=source.get_manual_map_dict(),
        repo_description=source.repo_description,
        repo_readme=source.repo_readme,
        tags=source.get_tags_list() or [],
        counts_by_type=counts_by_type,
        new_artifact_count=status_counts.get("new", 0),
        updated_artifact_count=status_counts.get("updated", 0),
        imported_count=status_counts.get("imported", 0),
        single_artifact_mode=source.single_artifact_mode or False,
        single_artifact_type=source.single_artifact_type,
        indexing_enabled=source.indexing_enabled,
        deep_indexing_enabled=source.deep_indexing_enabled or False,
        # Clone target summary fields (null if never indexed)
        artifacts_root=(
            source.clone_target.artifacts_root if source.clone_target else None
        ),
        artifact_count_from_cache=(
            len(source.clone_target.artifact_paths) if source.clone_target else None
        ),
        indexing_strategy=(
            source.clone_target.strategy if source.clone_target else None
        ),
        last_indexed_tree_sha=(
            source.clone_target.tree_sha if source.clone_target else None
        ),
        last_indexed_at=(
            source.clone_target.computed_at if source.clone_target else None
        ),
        composite_member_count=composite_member_count,
        composite_child_types=composite_child_types,
    )


def get_collection_artifact_keys(collection_mgr) -> Set[str]:
    """Get set of 'type:name' keys for all artifacts in active collection.

    Used for efficient lookup when enriching catalog entries with in_collection status.

    Args:
        collection_mgr: CollectionManager instance

    Returns:
        Set of strings in format 'artifact_type:name' for each artifact in collection.
        Returns empty set if collection artifacts cannot be retrieved.
    """
    try:
        from skillmeat.core.artifact import ArtifactManager

        artifact_mgr = ArtifactManager(collection_mgr)
        artifacts = artifact_mgr.list_artifacts()
        return {f"{a.type.value}:{a.name}" for a in artifacts}
    except Exception as e:
        logger.warning(f"Failed to get collection artifacts: {e}")
        return set()


def entry_to_response(
    entry: MarketplaceCatalogEntry,
    collection_artifact_keys: Optional[Set[str]] = None,
) -> CatalogEntryResponse:
    """Convert MarketplaceCatalogEntry ORM model to API response.

    Args:
        entry: MarketplaceCatalogEntry ORM instance
        collection_artifact_keys: Optional set of 'type:name' keys for collection artifacts.
            Used to determine if the entry exists in the user's collection.

    Returns:
        CatalogEntryResponse DTO for API
    """
    # Compute is_duplicate based on excluded_reason
    is_duplicate = (
        entry.excluded_reason
        in (
            "duplicate_within_source",
            "duplicate_cross_source",
        )
        if entry.excluded_reason
        else False
    )

    # Check if artifact exists in collection
    in_collection = False
    if collection_artifact_keys is not None:
        # Key format: "artifact_type:name"
        key = f"{entry.artifact_type}:{entry.name}"
        in_collection = key in collection_artifact_keys

    return CatalogEntryResponse(
        id=entry.id,
        source_id=entry.source_id,
        artifact_type=entry.artifact_type,
        name=entry.name,
        path=entry.path,
        upstream_url=entry.upstream_url,
        detected_version=entry.detected_version,
        detected_sha=entry.detected_sha,
        detected_at=entry.detected_at,
        confidence_score=entry.confidence_score,
        raw_score=entry.raw_score,
        score_breakdown=entry.score_breakdown,
        status=entry.status,
        import_date=entry.import_date,
        import_id=entry.import_id,
        excluded_at=entry.excluded_at,
        excluded_reason=entry.excluded_reason,
        is_duplicate=is_duplicate,
        in_collection=in_collection,
    )


def parse_rate_limit_retry_after(error: RateLimitError) -> int:
    """Extract retry-after seconds from RateLimitError message.

    The RateLimitError message contains the wait time in seconds.
    Examples:
        - "Rate limited, reset in 45s"
        - "Rate limited for 60s"

    Args:
        error: RateLimitError exception

    Returns:
        Number of seconds to wait before retrying. Defaults to 60 if
        the time cannot be parsed from the error message.
    """
    import re

    message = str(error)
    # Match patterns like "45s" or "60s" in the message
    match = re.search(r"(\d+)s", message)
    if match:
        return int(match.group(1))
    return 60  # Default to 60 seconds if parsing fails


def get_effective_indexing_state(indexing_enabled: Optional[bool], mode: str) -> bool:
    """Resolve effective indexing state from global mode and per-source flag.

    This function implements the indexing state resolution logic based on the
    global marketplace indexing mode and per-source override flag:

    - "off" mode: Global disable overrides all per-source settings
    - "on" mode: Default enabled, sources can opt-out by setting indexing_enabled=False
    - "opt_in" mode: Default disabled, sources must opt-in by setting indexing_enabled=True

    Args:
        indexing_enabled: Per-source flag (None = use mode default, True/False = override)
        mode: Global indexing mode ("off", "on", or "opt_in")

    Returns:
        bool: Whether indexing should be enabled for this source

    Examples:
        >>> get_effective_indexing_state(None, "off")
        False
        >>> get_effective_indexing_state(True, "off")  # Global disable overrides
        False
        >>> get_effective_indexing_state(None, "on")
        True
        >>> get_effective_indexing_state(False, "on")  # Can opt-out
        False
        >>> get_effective_indexing_state(None, "opt_in")
        False
        >>> get_effective_indexing_state(True, "opt_in")  # Can opt-in
        True
    """
    if mode == "off":
        # Global disable overrides all per-source settings
        return False
    elif mode == "on":
        # Default enabled, can opt-out per-source
        return indexing_enabled if indexing_enabled is not None else True
    else:  # opt_in
        # Default disabled, can opt-in per-source
        return indexing_enabled if indexing_enabled is not None else False


# =============================================================================
# Frontmatter Extraction for Search Indexing
# =============================================================================

# Manifest file candidates by artifact type (tried in order)
MANIFEST_FILES: Dict[str, List[str]] = {
    "skill": ["SKILL.md"],
    "command": ["COMMAND.md", "README.md"],
    "agent": ["AGENT.md", "README.md"],
    "mcp_server": ["README.md", "CLAUDE.md"],
    "mcp": ["README.md", "CLAUDE.md"],
    "hook": ["HOOK.md", "README.md"],
}

# All unique manifest filenames for sparse clone patterns
ALL_MANIFEST_FILES: List[str] = list(
    {f for files in MANIFEST_FILES.values() for f in files}
)


def _get_manifest_candidates(artifact_type: str) -> List[str]:
    """Get candidate manifest filenames for an artifact type.

    Args:
        artifact_type: The artifact type (skill, command, agent, etc.)

    Returns:
        List of manifest filenames to try, in priority order.
        Returns ["README.md"] as fallback for unknown types.
    """
    return MANIFEST_FILES.get(artifact_type, ["README.md"])


def _extract_frontmatter_for_artifact(
    scanner: GitHubScanner,
    source: MarketplaceSource,
    artifact: DetectedArtifact,
) -> Dict[str, Any]:
    """Extract frontmatter from artifact's manifest file for search indexing.

    Fetches the appropriate manifest file based on artifact type and extracts
    frontmatter fields. Supports all artifact types with type-specific manifest
    file lookups.

    Args:
        scanner: GitHubScanner instance for fetching file content
        source: MarketplaceSource with owner/repo_name info
        artifact: DetectedArtifact with path and type info

    Returns:
        Dict with keys: title, description, search_tags (list), search_text
        All values may be None if extraction fails or not applicable.
    """
    result: Dict[str, Optional[str]] = {
        "title": None,
        "description": None,
        "search_tags": None,
        "search_text": None,
    }

    artifact_path = artifact.path.rstrip("/")

    # Check if the artifact path itself is a manifest file (file-based artifacts
    # like commands/doc-generate.md, agents/bar.md, hooks/baz.yaml)
    content = None
    used_manifest = None

    if artifact_path.endswith((".md", ".yaml", ".yml")):
        # File-based artifact: the artifact path IS the manifest
        try:
            file_result = scanner.get_file_content(
                owner=source.owner,
                repo=source.repo_name,
                path=artifact_path,
                ref=source.ref,
            )

            if file_result and not file_result.get("is_binary"):
                content = file_result.get("content", "")
                if content:
                    used_manifest = artifact_path.split("/")[-1]
        except Exception:
            pass  # Fall through to directory-based lookup

    # If not a file-based artifact (or file read failed), try directory-based lookup
    if not content:
        # Get candidate manifest files for this artifact type
        manifest_candidates = _get_manifest_candidates(artifact.artifact_type)

        # Try each candidate manifest file in order
        for manifest_file in manifest_candidates:
            manifest_path = (
                f"{artifact_path}/{manifest_file}" if artifact_path else manifest_file
            )

            try:
                file_result = scanner.get_file_content(
                    owner=source.owner,
                    repo=source.repo_name,
                    path=manifest_path,
                    ref=source.ref,
                )

                if file_result and not file_result.get("is_binary"):
                    content = file_result.get("content", "")
                    if content:
                        used_manifest = manifest_file
                        break
            except Exception:
                # Continue to next candidate
                continue

    if not content:
        manifest_candidates = _get_manifest_candidates(artifact.artifact_type)
        logger.debug(
            f"No manifest found for {artifact.artifact_type} artifact at "
            f"{artifact_path}, tried: {manifest_candidates}"
        )
        return result

    try:
        # Extract frontmatter
        frontmatter = extract_frontmatter(content)
        if not frontmatter:
            return result

        # Extract title (try 'title' then 'name')
        title = frontmatter.get("title") or frontmatter.get("name")
        if title:
            # Truncate to 200 chars (model field limit)
            result["title"] = str(title)[:200]

        # Extract description
        description = frontmatter.get("description")
        if description:
            result["description"] = str(description)

        # Extract tags
        tags = frontmatter.get("tags", [])
        if tags:
            if isinstance(tags, list):
                result["search_tags"] = [str(t) for t in tags if t]
            elif isinstance(tags, str):
                result["search_tags"] = [
                    t.strip() for t in tags.split(",") if t.strip()
                ]

        # Build search_text from all fields
        search_parts = [artifact.name]
        if result["title"]:
            search_parts.append(result["title"])
        if result["description"]:
            search_parts.append(result["description"])
        if result["search_tags"]:
            search_parts.extend(result["search_tags"])

        result["search_text"] = " ".join(search_parts)

        logger.debug(
            f"Extracted frontmatter for {artifact.artifact_type} artifact at "
            f"{artifact_path} using {used_manifest}: "
            f"title={result['title']}, tags={result['search_tags']}"
        )

    except Exception as e:
        logger.warning(
            f"Failed to extract frontmatter for {artifact.artifact_type} "
            f"artifact at {artifact_path}: {e}",
            exc_info=False,
        )
        # Return empty result on failure - non-blocking

    return result


# =============================================================================
# Clone-Based Batch Frontmatter Extraction
# =============================================================================

# Minimum number of skill artifacts to use batch clone approach
BATCH_CLONE_THRESHOLD = 3


def check_disk_space_for_clone() -> bool:
    """
    Check if there is enough disk space for clone operation.
    Returns True if space is sufficient, raises InsufficientDiskSpaceError if not.
    """
    temp_dir = tempfile.gettempdir()
    try:
        usage = shutil.disk_usage(temp_dir)
        available_mb = usage.free / (1024 * 1024)

        if usage.free < MIN_CLONE_DISK_SPACE_BYTES:
            logger.warning(
                "Insufficient disk space for clone",
                extra={
                    "available_mb": round(available_mb, 2),
                    "required_mb": MIN_CLONE_DISK_SPACE_MB,
                    "temp_dir": temp_dir,
                },
            )
            raise InsufficientDiskSpaceError(
                f"Insufficient disk space: {available_mb:.1f}MB available, "
                f"{MIN_CLONE_DISK_SPACE_MB}MB required"
            )

        logger.debug(
            "Disk space check passed", extra={"available_mb": round(available_mb, 2)}
        )
        return True

    except OSError as e:
        logger.warning(
            "Could not check disk space", extra={"error": str(e), "temp_dir": temp_dir}
        )
        # If we cannot check, let the clone attempt proceed
        return True


def _clone_repo_sparse(
    owner: str,
    repo: str,
    ref: str,
    patterns: List[str],
    timeout: Optional[int] = None,
) -> Path:
    """Clone repository with sparse checkout to temp directory.

    Uses git's sparse-checkout and partial clone features to minimize
    data transfer, fetching only files matching the specified patterns.

    Args:
        owner: Repository owner (GitHub username or org)
        repo: Repository name
        ref: Git ref to checkout (branch, tag, or SHA)
        patterns: List of sparse-checkout patterns (e.g., ["**/SKILL.md"])
        timeout: Timeout in seconds for git operations. Defaults to
            CLONE_TIMEOUT_SECONDS (configurable via SKILLMEAT_CLONE_TIMEOUT env var).

    Returns:
        Path to temporary directory containing the sparse clone.
        Caller is responsible for cleanup.

    Raises:
        CloneTimeoutError: If clone operation times out.
        CloneError: If clone fails due to git errors or other issues.
    """
    # Check disk space before creating temp directory
    check_disk_space_for_clone()

    # Use module-level default if not specified
    effective_timeout = timeout if timeout is not None else CLONE_TIMEOUT_SECONDS

    with trace_operation(
        "marketplace.clone_repository",
        strategy="sparse_directory",
        patterns_count=len(patterns),
        ref=ref,
        timeout=effective_timeout,
    ) as span:

        from skillmeat.core.github_client import get_github_client

        client = get_github_client()
        token = client.token

        # Create temp directory
        temp_dir = tempfile.mkdtemp(prefix="skillmeat-sparse-")
        temp_path = Path(temp_dir)
        start_time = time.monotonic()

        try:
            # Build authenticated URL if token available
            if token:
                repo_url = f"https://oauth2:{token}@github.com/{owner}/{repo}.git"
            else:
                repo_url = f"https://github.com/{owner}/{repo}.git"

            # Initialize empty repo with sparse-checkout
            subprocess.run(
                ["git", "init"],
                cwd=temp_path,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
                check=True,
            )

            # Configure sparse-checkout
            subprocess.run(
                ["git", "config", "core.sparseCheckout", "true"],
                cwd=temp_path,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
                check=True,
            )

            # Configure partial clone filter
            subprocess.run(
                ["git", "config", "extensions.partialClone", "origin"],
                cwd=temp_path,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
                check=True,
            )

            # Write sparse-checkout patterns
            sparse_checkout_file = temp_path / ".git" / "info" / "sparse-checkout"
            sparse_checkout_file.parent.mkdir(parents=True, exist_ok=True)
            sparse_checkout_file.write_text("\n".join(patterns) + "\n")

            # Add remote
            subprocess.run(
                ["git", "remote", "add", "origin", repo_url],
                cwd=temp_path,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
                check=True,
            )

            # Fetch with blob filter (minimal data transfer)
            # Use doubled timeout for network operations
            result = subprocess.run(
                [
                    "git",
                    "fetch",
                    "--depth=1",
                    "--filter=blob:none",
                    "origin",
                    ref,
                ],
                cwd=temp_path,
                capture_output=True,
                text=True,
                timeout=effective_timeout * 2,
            )

            if result.returncode != 0:
                shutil.rmtree(temp_path, ignore_errors=True)
                raise CloneError(
                    f"Git fetch failed for {owner}/{repo}: {result.stderr}"
                )

            # Checkout the fetched ref
            result = subprocess.run(
                ["git", "checkout", "FETCH_HEAD"],
                cwd=temp_path,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
            )

            if result.returncode != 0:
                shutil.rmtree(temp_path, ignore_errors=True)
                raise CloneError(
                    f"Git checkout failed for {owner}/{repo}: {result.stderr}"
                )

            # Record successful clone in span
            duration_ms = (time.monotonic() - start_time) * 1000
            duration_seconds = duration_ms / 1000
            span.set_attribute("clone_dir", str(temp_path))
            span.add_event("clone_complete", {"duration_ms": round(duration_ms, 2)})

            # Record metrics
            skillmeat_clone_duration_seconds.labels(
                strategy="sparse_directory"
            ).observe(duration_seconds)

            # Log timing for debugging
            logger.info(
                "Clone operation completed",
                extra={
                    "duration_seconds": round(duration_seconds, 2),
                    "strategy": "sparse_directory",
                    "owner": owner,
                    "repo": repo,
                    "ref": ref,
                },
            )

            return temp_path

        except subprocess.TimeoutExpired as e:
            logger.warning(
                "Clone timed out, falling back to API mode",
                extra={
                    "owner": owner,
                    "repo": repo,
                    "error": str(e),
                    "timeout_seconds": effective_timeout,
                },
            )
            shutil.rmtree(temp_path, ignore_errors=True)
            raise CloneTimeoutError(
                f"Git operation timed out after {effective_timeout}s for {owner}/{repo}"
            ) from e
        except subprocess.CalledProcessError as e:
            logger.warning(
                "Clone failed, falling back to API mode",
                extra={
                    "owner": owner,
                    "repo": repo,
                    "error": str(e),
                },
            )
            shutil.rmtree(temp_path, ignore_errors=True)
            raise CloneError(f"Git operation failed for {owner}/{repo}: {e}") from e
        except (CloneTimeoutError, CloneError):
            # Re-raise our custom exceptions without wrapping
            raise
        except Exception as e:
            logger.warning(
                f"Unexpected error cloning {owner}/{repo}: {e}",
                extra={
                    "owner": owner,
                    "repo": repo,
                    "error": str(e),
                },
            )
            shutil.rmtree(temp_path, ignore_errors=True)
            raise CloneError(f"Unexpected error cloning {owner}/{repo}: {e}") from e


def _extract_frontmatter_batch(
    source: MarketplaceSource,
    artifacts: List[DetectedArtifact],
) -> Dict[str, Dict[str, Any]]:
    """Extract frontmatter for multiple artifacts using git sparse clone.

    Uses a single git clone operation to fetch all manifest files from the
    repository, then reads them from disk. This is much more efficient than
    making individual API calls for each artifact.

    Supports all artifact types with type-specific manifest file lookups:
    - skill: SKILL.md
    - command: COMMAND.md, README.md
    - agent: AGENT.md, README.md
    - mcp_server/mcp: README.md, CLAUDE.md
    - hook: HOOK.md, README.md

    Args:
        source: MarketplaceSource with owner/repo_name info
        artifacts: List of DetectedArtifacts to extract frontmatter for

    Returns:
        Dict mapping artifact name to frontmatter dict with keys:
        - title: Extracted title (str or None)
        - description: Extracted description (str or None)
        - search_tags: List of tags (list or None)
        - search_text: Combined search text (str or None)
        - deep_search_text: Full content from deep indexing (str or None)
        - deep_index_files: List of indexed file paths (list or None)

        Missing or failed extractions will have None values.
    """
    result: Dict[str, Dict[str, Any]] = {}

    # Initialize all artifacts with empty results
    for artifact in artifacts:
        result[artifact.name] = {
            "title": None,
            "description": None,
            "search_tags": None,
            "search_text": None,
            "deep_search_text": None,
            "deep_index_files": None,
        }

    if not artifacts:
        return result

    # Start timing extraction operation
    extraction_start = time.time()

    logger.info(
        f"Using clone-based frontmatter extraction for {len(artifacts)} artifacts "
        f"from {source.owner}/{source.repo_name}"
    )

    # Build sparse checkout patterns for all manifest file types
    # Include both nested (**/) and root-level patterns
    sparse_patterns = []

    # Add patterns for file-based artifacts (the artifact path IS the manifest)
    # e.g., "plugins/web-scripting/agents/ruby-pro.md", "commands/doc-generate.md"
    for artifact in artifacts:
        artifact_path = artifact.path.rstrip("/")
        if artifact_path.endswith((".md", ".yaml", ".yml")):
            sparse_patterns.append(artifact_path)

    # Add patterns for directory-based artifacts (look for manifest files inside)
    for manifest_file in ALL_MANIFEST_FILES:
        sparse_patterns.append(f"**/{manifest_file}")
        sparse_patterns.append(manifest_file)

    # Clone with sparse checkout for all manifest files
    try:
        clone_path = _clone_repo_sparse(
            owner=source.owner,
            repo=source.repo_name,
            ref=source.ref,
            patterns=sparse_patterns,
        )
    except (CloneTimeoutError, CloneError, InsufficientDiskSpaceError) as e:
        logger.warning(
            "Clone failed, falling back to API mode",
            extra={
                "source_id": source.id,
                "owner": source.owner,
                "repo": source.repo_name,
                "error": str(e),
                "timeout_seconds": CLONE_TIMEOUT_SECONDS,
            },
        )
        return result

    try:
        # Read manifest file for each artifact from disk
        for artifact in artifacts:
            artifact_path = artifact.path.rstrip("/")

            # Check if the artifact path itself is a manifest file (file-based
            # artifacts like commands/doc-generate.md, agents/bar.md, hooks/baz.yaml)
            content = None
            used_manifest = None

            if artifact_path.endswith((".md", ".yaml", ".yml")):
                # File-based artifact: the artifact path IS the manifest
                manifest_path = clone_path / artifact_path
                if manifest_path.exists():
                    try:
                        content = manifest_path.read_text(encoding="utf-8")
                        if content:
                            used_manifest = artifact_path.split("/")[-1]
                    except Exception:
                        pass  # Fall through to directory-based lookup

            # If not a file-based artifact (or file read failed), try directory-based lookup
            if not content:
                manifest_candidates = _get_manifest_candidates(artifact.artifact_type)

                # Try each candidate manifest file in order
                for manifest_file in manifest_candidates:
                    if artifact_path:
                        manifest_path = clone_path / artifact_path / manifest_file
                    else:
                        manifest_path = clone_path / manifest_file

                    if manifest_path.exists():
                        try:
                            content = manifest_path.read_text(encoding="utf-8")
                            if content:
                                used_manifest = manifest_file
                                break
                        except Exception:
                            continue

            if not content:
                manifest_candidates = _get_manifest_candidates(artifact.artifact_type)
                logger.debug(
                    f"No manifest found for {artifact.artifact_type} artifact at "
                    f"{artifact_path}, tried: {manifest_candidates}"
                )
                continue

            try:
                # Extract frontmatter using existing utility
                frontmatter = extract_frontmatter(content)
                if not frontmatter:
                    continue

                # Extract title (try 'title' then 'name')
                title = frontmatter.get("title") or frontmatter.get("name")
                if title:
                    result[artifact.name]["title"] = str(title)[:200]

                # Extract description
                description = frontmatter.get("description")
                if description:
                    result[artifact.name]["description"] = str(description)

                # Extract tags
                tags = frontmatter.get("tags", [])
                if tags:
                    if isinstance(tags, list):
                        result[artifact.name]["search_tags"] = [
                            str(t) for t in tags if t
                        ]
                    elif isinstance(tags, str):
                        result[artifact.name]["search_tags"] = [
                            t.strip() for t in tags.split(",") if t.strip()
                        ]

                # Build search_text from all fields
                search_parts = [artifact.name]
                if result[artifact.name]["title"]:
                    search_parts.append(result[artifact.name]["title"])
                if result[artifact.name]["description"]:
                    search_parts.append(result[artifact.name]["description"])
                if result[artifact.name]["search_tags"]:
                    search_parts.extend(result[artifact.name]["search_tags"])

                result[artifact.name]["search_text"] = " ".join(search_parts)

                logger.debug(
                    f"Extracted frontmatter for {artifact.artifact_type} artifact at "
                    f"{artifact_path} using {used_manifest}: "
                    f"title={result[artifact.name]['title']}, "
                    f"tags={result[artifact.name]['search_tags']}"
                )

            except Exception as e:
                logger.warning(
                    f"Failed to extract frontmatter for {artifact.artifact_type} "
                    f"artifact at {artifact.path}: {e}",
                    exc_info=False,
                )
                # Continue with next artifact - extraction is non-blocking

        # Deep indexing pass - extract full file contents when enabled
        if source.deep_indexing_enabled:
            deep_indexed_count = 0
            for artifact in artifacts:
                artifact_path = artifact.path.rstrip("/")

                # Determine artifact directory in the clone
                # For file-based artifacts, use the parent directory
                if artifact_path.endswith((".md", ".yaml", ".yml")):
                    # File-based artifact - get parent directory
                    artifact_dir = clone_path / Path(artifact_path).parent
                else:
                    # Directory-based artifact
                    artifact_dir = (
                        clone_path / artifact_path if artifact_path else clone_path
                    )

                if artifact_dir.is_dir():
                    try:
                        deep_text, indexed_files = extract_deep_search_text(
                            artifact_dir
                        )
                        if deep_text and artifact.name in result:
                            result[artifact.name]["deep_search_text"] = deep_text
                            result[artifact.name]["deep_index_files"] = indexed_files
                            deep_indexed_count += 1
                            logger.debug(
                                f"Deep indexed {artifact.name}: "
                                f"{len(indexed_files)} files, {len(deep_text)} chars"
                            )
                    except Exception as e:
                        logger.warning(
                            f"Deep indexing failed for {artifact.name}: {e}",
                            exc_info=False,
                        )
                        # Continue with next artifact - deep indexing is non-blocking

            logger.info(
                f"Deep indexing complete for {source.owner}/{source.repo_name}: "
                f"{deep_indexed_count} of {len(artifacts)} artifacts indexed",
            )

        # Record extraction metrics
        extraction_duration = time.time() - extraction_start
        artifact_count_bucket = _get_artifact_count_bucket(len(artifacts))
        skillmeat_extraction_duration_seconds.labels(
            artifact_count_bucket=artifact_count_bucket
        ).observe(extraction_duration)

        logger.info(
            f"Batch frontmatter extraction complete for "
            f"{source.owner}/{source.repo_name}: "
            f"{sum(1 for v in result.values() if v.get('title'))} of "
            f"{len(artifacts)} artifacts had frontmatter",
            extra={
                "duration_seconds": round(extraction_duration, 2),
                "artifact_count": len(artifacts),
                "artifact_count_bucket": artifact_count_bucket,
            },
        )

    finally:
        # Always clean up the temp directory
        shutil.rmtree(clone_path, ignore_errors=True)

    return result


# =============================================================================
# Shared Scan Logic
# =============================================================================


async def _perform_scan(
    source: MarketplaceSource,
    source_repo: "MarketplaceSourceRepository",
    catalog_repo: "MarketplaceCatalogRepository",
    transaction_handler: "MarketplaceTransactionHandler",
) -> ScanResultDTO:
    """Perform repository scan and update source + catalog atomically.

    Shared by create_source() and rescan_source() endpoints.

    Args:
        source: MarketplaceSource ORM instance
        source_repo: Source repository for updates
        catalog_repo: Catalog repository (unused currently, for future)
        transaction_handler: Transaction handler for atomic updates

    Returns:
        ScanResultDTO with scan statistics

    Note:
        Handles scan errors gracefully - sets source status to "error"
        and returns error result instead of raising.
    """
    source_id = source.id

    # Mark as scanning
    source.scan_status = "scanning"
    source_repo.update(source)

    # Perform scan
    logger.info(f"Scanning repository: {source.repo_url} (ref={source.ref})")
    scanner = GitHubScanner()

    # Track API calls during scan for efficiency metrics
    api_calls_before = _get_github_api_call_count()

    # Start timing total scan operation
    scan_start_time = time.time()
    scan_strategy = "unknown"  # Will be updated based on scan path

    # Retrieve manual_map from source for artifact type override
    manual_map = source.get_manual_map_dict()
    if manual_map:
        logger.debug(
            f"Using manual_map with {len(manual_map)} mapping(s) for source {source_id}"
        )

    try:
        # Check for single artifact mode - bypass normal scanning
        if source.single_artifact_mode and source.single_artifact_type:
            scan_strategy = "single_artifact"
            logger.info(
                f"Single artifact mode enabled for {source.repo_url}, "
                f"type={source.single_artifact_type}"
            )

            # Create synthetic artifact for the entire repo/root_hint
            artifact_path = source.root_hint if source.root_hint else ""

            # Derive artifact name: prefer repo_name when root_hint is a
            # dotfile directory (e.g., ".claude") since those make poor names
            if not source.root_hint:
                artifact_name = source.repo_name
            else:
                last_segment = source.root_hint.split("/")[-1]
                if last_segment.startswith("."):
                    # Dotfile/directory root hints (like ".claude") → use repo name
                    artifact_name = source.repo_name
                else:
                    artifact_name = last_segment
            base_url = f"https://github.com/{source.owner}/{source.repo_name}"

            # Get commit SHA for versioning
            from skillmeat.core.github_client import get_github_client

            client = get_github_client()
            try:
                commit_sha = client.resolve_version(
                    f"{source.owner}/{source.repo_name}", source.ref
                )
            except Exception:
                commit_sha = source.ref  # Fallback to ref if resolution fails

            # Build upstream URL
            upstream_url = f"{base_url}/tree/{source.ref}"
            if artifact_path:
                upstream_url = f"{upstream_url}/{artifact_path}"

            # Create synthetic scan result with 100% confidence
            scan_result = ScanResultDTO(
                source_id=source_id,
                status="success",
                artifacts_found=1,
                new_count=1,
                updated_count=0,
                removed_count=0,
                unchanged_count=0,
                scan_duration_ms=0,
                errors=[],
                scanned_at=datetime.now(timezone.utc),
                artifacts=[
                    DetectedArtifact(
                        artifact_type=source.single_artifact_type,
                        name=artifact_name,
                        path=artifact_path or ".",
                        upstream_url=upstream_url,
                        confidence_score=100,
                        detected_version=None,
                        detected_sha=commit_sha,
                        raw_score=100,
                        score_breakdown=None,
                        metadata={"single_artifact_mode": True},
                    )
                ],
            )
        else:
            # Normal scanning path
            scan_strategy = "api_scan"  # Default, may be updated if clone is used
            # Cross-source deduplication session is optional; pass None to skip it.
            scan_result = scanner.scan_repository(
                owner=source.owner,
                repo=source.repo_name,
                ref=source.ref,
                root_hint=source.root_hint,
                session=None,
                manual_mappings=manual_map,
            )

            # Debug log detected artifacts for verification
            if scan_result.artifacts:
                for artifact in scan_result.artifacts:
                    logger.debug(
                        f"Detected artifact: name={artifact.name}, "
                        f"path={artifact.path}, type={artifact.artifact_type}, "
                        f"upstream_url={artifact.upstream_url}"
                    )

            # === Clone-based artifact indexing integration ===
            # After scan, compute and persist CloneTarget for future rapid re-indexing
            if scan_result.artifacts:
                try:
                    # Get tree SHA for cache invalidation
                    from skillmeat.core.github_client import get_github_client
                    from skillmeat.core.clone_target import (
                        CloneTarget,
                        compute_clone_metadata,
                        select_indexing_strategy,
                        get_sparse_checkout_patterns,
                    )

                    client = get_github_client()
                    tree_sha = client.resolve_version(
                        f"{source.owner}/{source.repo_name}", source.ref
                    )

                    # Compute clone metadata (artifacts_root, artifact_paths, patterns)
                    clone_metadata = compute_clone_metadata(
                        scan_result.artifacts, tree_sha
                    )

                    # Select optimal indexing strategy based on artifact count
                    strategy = select_indexing_strategy(source, scan_result.artifacts)

                    # Determine selection reason for logging
                    artifact_count = len(scan_result.artifacts)
                    artifacts_root = clone_metadata.get("artifacts_root")

                    if artifact_count < 3:
                        selection_reason = "count < 3"
                    elif artifact_count <= 20:
                        selection_reason = "count 3-20"
                    elif artifacts_root:
                        selection_reason = "count > 20 with common root"
                    else:
                        selection_reason = "count > 20 scattered"

                    # Get sparse checkout patterns based on strategy
                    sparse_patterns = get_sparse_checkout_patterns(
                        strategy,
                        scan_result.artifacts,
                        clone_metadata.get("artifacts_root"),
                    )

                    logger.info(
                        "Indexing strategy selected",
                        extra={
                            "source_id": source.id,
                            "repo_url": f"{source.owner}/{source.repo_name}",
                            "artifact_count": artifact_count,
                            "artifacts_root": artifacts_root,
                            "selected_strategy": strategy,
                            "patterns_count": len(sparse_patterns),
                            "reason": selection_reason,
                        },
                    )

                    # Build and persist CloneTarget
                    clone_target = CloneTarget(
                        strategy=strategy,
                        sparse_patterns=sparse_patterns,
                        artifacts_root=clone_metadata.get("artifacts_root"),
                        artifact_paths=clone_metadata.get("artifact_paths", []),
                        tree_sha=tree_sha,
                        computed_at=datetime.now(timezone.utc),
                    )

                    # Persist CloneTarget on source (will be saved in transaction below)
                    source.clone_target = clone_target
                    logger.debug(
                        f"Computed CloneTarget for {source.owner}/{source.repo_name}: "
                        f"strategy={strategy}, patterns={len(sparse_patterns)}, "
                        f"tree_sha={tree_sha[:8]}..."
                    )

                except Exception as clone_target_error:
                    # CloneTarget computation is non-blocking - log warning and continue
                    logger.warning(
                        f"Failed to compute CloneTarget for {source.owner}/{source.repo_name}: "
                        f"{clone_target_error}",
                        exc_info=False,
                    )

        # Load path tag config from source (or use defaults)
        config = PathTagConfig.defaults()
        if source.path_tag_config:
            try:
                config = PathTagConfig.from_json(source.path_tag_config)
            except ValueError as e:
                logger.warning(
                    f"Invalid path_tag_config for source {source.id}: {e}. "
                    "Using defaults."
                )
                config = PathTagConfig.defaults()

        # Create extractor if enabled
        extractor = PathSegmentExtractor(config) if config.enabled else None

        # Compute counts_by_type from scan results
        counts_by_type: Dict[str, int] = {}
        for artifact in scan_result.artifacts:
            artifact_type = artifact.artifact_type
            counts_by_type[artifact_type] = counts_by_type.get(artifact_type, 0) + 1

        # Update source and catalog atomically
        with trace_operation(
            "marketplace.store_scan_results",
            source_id=source_id,
        ) as span:
            with transaction_handler.scan_update_transaction(source_id) as ctx:

                # Update source status, persisting branch fallback if detected
                ctx.update_source_status(
                    status="success",
                    artifact_count=scan_result.artifacts_found,
                    error_message=None,
                    ref=scan_result.actual_ref,  # None when no fallback occurred
                )

                # Update counts_by_type and clone_target on source via ctx method.
                ctx.update_source_counts(
                    counts_by_type,
                    clone_target=source.clone_target if source.clone_target is not None else None,
                )

                # Determine if frontmatter indexing is enabled for this source
                # Get global indexing mode from config and compute effective state
                from skillmeat.config import ConfigManager

                app_config = ConfigManager()
                global_mode = app_config.get_indexing_mode()
                indexing_enabled = get_effective_indexing_state(
                    source.indexing_enabled, global_mode
                )
                if indexing_enabled:
                    logger.info(
                        f"Frontmatter indexing enabled for source {source_id}, "
                        f"extracting search metadata from artifacts"
                    )

                # Pre-compute batch frontmatter for all artifacts if above threshold
                # This uses a single git clone instead of N API calls
                batch_frontmatter: Dict[str, Dict[str, Any]] = {}
                use_batch_extraction = False
                if indexing_enabled:
                    if len(scan_result.artifacts) >= BATCH_CLONE_THRESHOLD:
                        use_batch_extraction = True
                        batch_frontmatter = _extract_frontmatter_batch(
                            source, scan_result.artifacts
                        )

                # Convert detected artifacts to catalog entries
                new_entries = []
                for artifact in scan_result.artifacts:
                    # Extract path segments if enabled
                    path_segments_json = None
                    if extractor:
                        try:
                            segments = extractor.extract(artifact.path)
                            path_segments_json = json.dumps(
                                {
                                    "raw_path": artifact.path,
                                    "extracted": [asdict(s) for s in segments],
                                    "extracted_at": datetime.utcnow().isoformat(),
                                }
                            )
                        except Exception as e:
                            logger.error(
                                f"Failed to extract path segments for {artifact.path}: {e}"
                            )
                            # Continue without path_segments; extraction is non-blocking

                    # Extract frontmatter for search indexing if enabled
                    search_metadata: Dict[str, Any] = {
                        "title": None,
                        "description": None,
                        "search_tags": None,
                        "search_text": None,
                        "deep_search_text": None,
                        "deep_index_files": None,
                    }
                    if indexing_enabled:
                        # Use batch result if available, otherwise per-artifact
                        if use_batch_extraction and artifact.name in batch_frontmatter:
                            search_metadata = batch_frontmatter[artifact.name]
                        else:
                            search_metadata = _extract_frontmatter_for_artifact(
                                scanner, source, artifact
                            )

                    # Serialize search_tags as JSON if present
                    search_tags_json = None
                    if search_metadata.get("search_tags"):
                        search_tags_json = json.dumps(search_metadata["search_tags"])

                    # Serialize deep_index_files as JSON if present
                    deep_index_files_json = None
                    if search_metadata.get("deep_index_files"):
                        deep_index_files_json = json.dumps(
                            search_metadata["deep_index_files"]
                        )

                    # Set deep_indexed_at timestamp if deep indexing was performed
                    deep_indexed_at = None
                    if search_metadata.get("deep_search_text"):
                        deep_indexed_at = datetime.utcnow()

                    # Serialize embedded_artifacts into metadata_json so they
                    # can be recovered at import time for skill composite creation
                    # (SCA-P2-03: atomic transaction wiring).
                    catalog_metadata_json = None
                    if (
                        artifact.artifact_type in ("skill", "composite")
                        and getattr(artifact, "embedded_artifacts", None)
                    ):
                        try:
                            embedded_dicts = [
                                ea.model_dump()
                                if hasattr(ea, "model_dump")
                                else ea.dict()
                                for ea in artifact.embedded_artifacts
                            ]
                            catalog_metadata_json = json.dumps(
                                {"embedded_artifacts": embedded_dicts}
                            )
                        except Exception as _meta_err:
                            logger.warning(
                                "Failed to serialize embedded_artifacts for %s: %s",
                                artifact.name,
                                _meta_err,
                            )

                    entry = MarketplaceCatalogEntry(
                        id=str(uuid.uuid4()),
                        source_id=source_id,
                        artifact_type=artifact.artifact_type,
                        name=artifact.name,
                        path=artifact.path,
                        upstream_url=artifact.upstream_url,
                        confidence_score=artifact.confidence_score,
                        raw_score=artifact.raw_score,
                        score_breakdown=artifact.score_breakdown,
                        detected_sha=artifact.detected_sha,
                        detected_at=datetime.utcnow(),
                        # Copy exclusion status from deduplication engine
                        status=artifact.status if artifact.status else "new",
                        excluded_at=(
                            datetime.fromisoformat(artifact.excluded_at)
                            if artifact.excluded_at
                            else None
                        ),
                        excluded_reason=artifact.excluded_reason,
                        path_segments=path_segments_json,
                        # Cross-source search fields from frontmatter
                        title=search_metadata.get("title"),
                        description=search_metadata.get("description"),
                        search_tags=search_tags_json,
                        search_text=search_metadata.get("search_text"),
                        # Deep indexing fields (only populated when deep_indexing_enabled)
                        deep_search_text=search_metadata.get("deep_search_text"),
                        deep_indexed_at=deep_indexed_at,
                        deep_index_files=deep_index_files_json,
                        # Embedded artifacts for skill composite wiring (SCA-P2-03)
                        metadata_json=catalog_metadata_json,
                    )
                    new_entries.append(entry)

                # Merge new entries with existing (preserves import metadata)
                merge_result = ctx.merge_catalog_entries(new_entries)

            span.set_attribute("rows_affected", scan_result.artifacts_found)
        # Set source_id in result
        scan_result.source_id = source_id

        # Add merge result info to scan result
        scan_result.updated_imports = merge_result.updated_imports
        scan_result.preserved_count = merge_result.preserved_count
        # Calculate API efficiency metrics
        api_calls_after = _get_github_api_call_count()
        api_calls_used = api_calls_after - api_calls_before
        api_calls_per_artifact = api_calls_used / max(1, scan_result.artifacts_found)

        # Record total scan duration metrics
        scan_duration = time.time() - scan_start_time
        skillmeat_scan_total_duration_seconds.labels(
            strategy=scan_strategy, status="success"
        ).observe(scan_duration)

        logger.info(
            f"Scan completed for {source.repo_url}: "
            f"{scan_result.artifacts_found} artifacts found, "
            f"{merge_result.preserved_count} preserved, "
            f"{len(merge_result.updated_imports)} imports with upstream changes",
            extra={
                "api_calls": api_calls_used,
                "artifact_count": scan_result.artifacts_found,
                "api_calls_per_artifact": round(api_calls_per_artifact, 2),
                "scan_duration_seconds": round(scan_duration, 2),
                "scan_strategy": scan_strategy,
            },
        )
        return scan_result

    except Exception as scan_error:
        # Record error metrics
        scan_duration = time.time() - scan_start_time
        skillmeat_scan_total_duration_seconds.labels(
            strategy=scan_strategy, status="error"
        ).observe(scan_duration)

        # Mark as error
        with transaction_handler.scan_update_transaction(source_id) as ctx:
            ctx.update_source_status(
                status="error",
                error_message=str(scan_error),
            )

        logger.error(
            f"Scan failed for {source.repo_url}: {scan_error}",
            exc_info=True,
            extra={
                "scan_duration_seconds": round(scan_duration, 2),
                "scan_strategy": scan_strategy,
            },
        )

        # Return error result (don't raise - let caller decide)
        return ScanResultDTO(
            source_id=source_id,
            status="error",
            artifacts_found=0,
            new_count=0,
            updated_count=0,
            removed_count=0,
            unchanged_count=0,
            scan_duration_ms=0,
            errors=[str(scan_error)],
            scanned_at=datetime.utcnow(),
        )


# =============================================================================
# API-000: URL Inference Utility
# =============================================================================


@router.post("/infer-url", response_model=InferUrlResponse)
async def infer_github_url(request: InferUrlRequest) -> InferUrlResponse:
    """Infer GitHub repository structure from a full URL.

    Parses GitHub URLs to extract repository URL, branch/tag, and subdirectory path.
    Supports various GitHub URL formats:
    - https://github.com/owner/repo
    - https://github.com/owner/repo/tree/branch
    - https://github.com/owner/repo/tree/branch/path/to/dir
    - https://github.com/owner/repo/blob/ref/path/to/file

    Args:
        request: URL to parse

    Returns:
        Inferred repository structure or error message

    Example:
        Input: https://github.com/davila7/claude-code-templates/tree/main/cli-tool/components
        Output: {
            "success": true,
            "repo_url": "https://github.com/davila7/claude-code-templates",
            "ref": "main",
            "root_hint": "cli-tool/components"
        }
    """
    url = request.url.strip()

    # Pattern for GitHub URLs
    # Matches: github.com/owner/repo[.git][/(tree|blob)/ref[/path...]]
    github_pattern = re.compile(
        r"^https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?(?:/(tree|blob)/([^/]+)(?:/(.*))?)?$"
    )

    match = github_pattern.match(url)

    if not match:
        logger.info(f"Failed to parse GitHub URL: {url}")
        return InferUrlResponse(
            success=False,
            error="Invalid GitHub URL format. Expected: https://github.com/owner/repo[/tree/branch[/path]]",
        )

    owner, repo, url_type, ref, path = match.groups()

    # Build base repo URL (without .git suffix)
    repo_url = f"https://github.com/{owner}/{repo}"

    # Default ref to "main" if not specified
    ref = ref or "main"

    # For blob URLs (file links), extract directory path by removing filename
    root_hint = None
    if path:
        if url_type == "blob":
            # Remove filename from path (e.g., "path/to/file.py" -> "path/to")
            path_parts = path.rsplit("/", 1)
            root_hint = path_parts[0] if len(path_parts) > 1 else None
        else:
            # Tree URL - use path as-is
            root_hint = path

    logger.info(
        f"Successfully parsed GitHub URL: {url} -> repo={repo_url}, ref={ref}, root_hint={root_hint}"
    )

    return InferUrlResponse(
        success=True,
        repo_url=repo_url,
        ref=ref,
        root_hint=root_hint,
        error=None,
    )


# =============================================================================
# API-001: Sources CRUD
# =============================================================================


@router.post(
    "",
    response_model=SourceResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create new GitHub source",
    description="""
    Add a new GitHub repository as a marketplace source for artifact scanning.

    The repository URL must be a valid GitHub URL (https://github.com/owner/repo).
    An initial scan is automatically triggered upon creation. The response includes
    the scan status and artifact count.

    **Manual Directory Mappings** (Optional):
    You can provide manual_map during creation to override automatic type detection.
    This is useful when you know the repository structure in advance.

    **Example Request**:
    ```json
    {
        "repo_url": "https://github.com/user/claude-templates",
        "ref": "main",
        "root_hint": "artifacts",
        "trust_level": "trusted",
        "manual_map": {
            "skills/advanced": "skill",
            "tools/cli": "command",
            "agents/research": "agent"
        },
        "enable_frontmatter_detection": true
    }
    ```

    **Validation**: All manual_map directory paths are validated against the repository
    tree during creation. Invalid paths will cause a 422 error.

    If the initial scan fails, the source is still created with scan_status="error".
    You can retry scanning using the /rescan endpoint.

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
    responses={
        201: {"description": "Source created and initial scan triggered"},
        400: {"description": "Bad request - invalid repository URL format"},
        409: {"description": "Conflict - repository URL already exists"},
        422: {"description": "Validation error - invalid manual_map directory paths"},
        500: {"description": "Internal server error"},
    },
)
async def create_source(
    request: CreateSourceRequest,
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    transaction_handler: MarketplaceTransactionHandlerDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> SourceResponse:
    """Create a new GitHub repository source.

    Args:
        request: Source creation request with repository details

    Returns:
        Created source with metadata

    Raises:
        HTTPException 400: If repository URL format is invalid
        HTTPException 409: If repository URL already exists
        HTTPException 500: If database operation fails
    """
    try:
        # Validate and parse repository URL
        owner, repo_name = parse_repo_url(request.repo_url)
    except ValueError as e:
        logger.warning(f"Invalid repository URL: {request.repo_url}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e

    # Check if source already exists
    existing = source_repo.get_by_repo_url(request.repo_url)
    if existing:
        logger.warning(f"Source already exists: {request.repo_url}")
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Source with repository URL '{request.repo_url}' already exists",
        )

    # Create new source
    source_id = str(uuid.uuid4())
    source = MarketplaceSource(
        id=source_id,
        repo_url=request.repo_url,
        owner=owner,
        repo_name=repo_name,
        ref=request.ref,
        root_hint=request.root_hint,
        trust_level=request.trust_level,
        visibility="public",  # TODO: Detect from GitHub API
        scan_status="pending",
        artifact_count=0,
        description=request.description,
        notes=request.notes,
        enable_frontmatter_detection=request.enable_frontmatter_detection,
        indexing_enabled=request.indexing_enabled,
    )

    # Store manual_map if provided
    if request.manual_map:
        source.set_manual_map_dict(request.manual_map)

    # Store single artifact mode settings
    if request.single_artifact_mode:
        source.single_artifact_mode = True
        source.single_artifact_type = request.single_artifact_type

    # Store tags if provided
    if request.tags:
        source.set_tags_list(request.tags)

    # Handle import_repo_description: fetch from GitHub if True
    # Also extract GitHub topics as auto-tags
    if request.import_repo_description:
        try:
            from skillmeat.core.github_client import get_github_client

            client = get_github_client()
            metadata = client.get_repo_metadata(f"{owner}/{repo_name}")
            source.repo_description = metadata.get("description")
            logger.info(f"Fetched repo description for {owner}/{repo_name}")

            # Extract GitHub topics as auto-tags
            topics = metadata.get("topics", [])
            if topics:
                auto_tags_data = {
                    "extracted": [
                        {
                            "value": topic,
                            "normalized": topic.lower().replace("_", "-"),
                            "status": "pending",
                            "source": "github_topic",
                        }
                        for topic in topics
                    ]
                }
                source.set_auto_tags_dict(auto_tags_data)
                logger.info(
                    f"Extracted {len(topics)} GitHub topics as auto-tags for {owner}/{repo_name}"
                )
        except Exception as e:
            logger.warning(
                f"Failed to fetch repo description for {owner}/{repo_name}: {e}"
            )
            # Don't fail creation - continue without repo_description

    # Handle import_repo_readme: fetch from GitHub if True
    if request.import_repo_readme:
        try:
            from skillmeat.core.github_client import get_github_client

            client = get_github_client()
            # Try common README filenames
            readme_content = None
            for readme_name in ["README.md", "README.rst", "README.txt", "README"]:
                try:
                    content_bytes = client.get_file_content(
                        f"{owner}/{repo_name}",
                        readme_name,
                        ref=request.ref,
                    )
                    readme_content = content_bytes.decode("utf-8")
                    # Truncate to 50KB if needed
                    if len(readme_content) > 50000:
                        readme_content = readme_content[:50000] + "\n... [truncated]"
                    break
                except Exception:
                    continue

            source.repo_readme = readme_content
            if readme_content:
                logger.info(f"Fetched README for {owner}/{repo_name}")
            else:
                logger.info(f"No README found for {owner}/{repo_name}")
        except Exception as e:
            logger.warning(f"Failed to fetch README for {owner}/{repo_name}: {e}")
            # Don't fail creation - continue without repo_readme

    try:
        created = source_repo.create(source)

        # Structured logging for source creation
        logger.info(
            "create_source_request",
            extra={
                "source_id": created.id,
                "repo_url": created.repo_url,
                "ref": created.ref,
                "root_hint": created.root_hint,
                "trust_level": created.trust_level,
                "has_manual_map": bool(request.manual_map),
                "manual_map_count": (
                    len(request.manual_map) if request.manual_map else 0
                ),
                "has_description": bool(request.description),
            },
        )

        # Trigger initial scan
        logger.info(f"Triggering initial scan for source: {created.id}")

        scan_result = await _perform_scan(
            source=created,
            source_repo=source_repo,
            catalog_repo=catalog_repo,
            transaction_handler=transaction_handler,
        )

        # Refresh source to get updated scan_status and artifact_count
        created = source_repo.get_by_id(created.id)

        logger.info(
            f"Initial scan completed for {created.id}: "
            f"status={scan_result.status}, artifacts={scan_result.artifacts_found}"
        )

        return source_to_response(created)
    except Exception as e:
        logger.error(f"Failed to create source: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create marketplace source",
        ) from e


@router.get(
    "",
    response_model=SourceListResponse,
    summary="List all GitHub sources",
    description="""
    List all GitHub repository sources with cursor-based pagination and optional filtering.

    Returns sources ordered by ID for stable pagination. Use the `cursor`
    parameter from the previous response to fetch the next page.

    **Filters** (all use AND logic - source must match all provided filters):
    - `artifact_type`: Filter sources containing artifacts of this type
      (skill, command, agent, hook, mcp-server, composite)
    - `tags`: Filter by tags (repeated param, e.g., `?tags=ui&tags=ux`)
    - `trust_level`: Filter by trust level
    - `search`: Search in repo name, description, and tags

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
)
async def list_sources(
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    limit: int = Query(50, ge=1, le=100, description="Maximum items per page"),
    cursor: Optional[str] = Query(None, description="Cursor for next page"),
    artifact_type: Optional[str] = Query(
        None,
        description=(
            "Filter by artifact type "
            "(skill, command, agent, hook, mcp-server, composite)"
        ),
    ),
    tags: Optional[List[str]] = Query(
        None, description="Filter by tags (AND logic - must match all)"
    ),
    trust_level: Optional[str] = Query(
        None, description="Filter by trust level (untrusted, basic, verified, official)"
    ),
    search: Optional[str] = Query(
        None, description="Search in repo name, description, tags"
    ),
    auth_context: AuthContext = Depends(get_auth_context),
) -> SourceListResponse:
    """List all marketplace sources with pagination and filtering.

    Args:
        limit: Maximum number of items per page (1-100)
        cursor: Cursor for pagination (from previous response)
        artifact_type: Filter by artifact type (skill, command, agent, hook, mcp-server)
        tags: Filter by tags (AND logic - must match all provided tags)
        trust_level: Filter by trust level (untrusted, basic, verified, official)
        search: Search in repo name, description, tags

    Returns:
        Paginated list of sources with page info including total_count

    Raises:
        HTTPException 500: If database operation fails
    """
    source_manager = SourceManager()

    try:
        # Pre-fetch composite aggregates once per request (avoid N+1).
        # This single query covers all composites across the local DB.
        composite_aggs = get_composite_aggregates(catalog_repo)

        # Pre-fetch catalog status counts for all sources in one query (avoid N+1).
        # Result: {source_id: {status: count}}
        status_counts_bulk = catalog_repo.count_by_status_bulk()

        # Check if any filters are provided
        has_filters = any([artifact_type, tags, trust_level, search])

        if has_filters:
            # With filters: fetch all sources, filter in-memory, then paginate
            all_sources = source_repo.list_all()

            # Apply filters using SourceManager
            filtered_sources = source_manager.apply_filters(
                sources=all_sources,
                artifact_type=artifact_type,
                tags=tags,
                trust_level=trust_level,
                search=search,
            )

            # Sort by ID for stable pagination
            filtered_sources.sort(key=lambda s: s.id)

            total_count = len(filtered_sources)

            # Apply cursor-based pagination manually
            start_idx = 0
            if cursor:
                # Find the index after the cursor
                for idx, source in enumerate(filtered_sources):
                    if source.id == cursor:
                        start_idx = idx + 1
                        break

            # Slice for current page
            end_idx = start_idx + limit
            page_sources = filtered_sources[start_idx:end_idx]
            has_more = end_idx < len(filtered_sources)

            # Convert ORM models to API responses; pass composite aggregates
            # and status counts so all sources are enriched without N+1 queries.
            items = [
                source_to_response(
                    source,
                    composite_aggregates=composite_aggs,
                    counts_by_status=status_counts_bulk.get(source.id),
                )
                for source in page_sources
            ]

            # Build page info
            page_info = PageInfo(
                has_next_page=has_more,
                has_previous_page=cursor is not None,
                start_cursor=items[0].id if items else None,
                end_cursor=items[-1].id if items else None,
                total_count=total_count,
            )

            # Structured logging for filtered list request
            logger.info(
                "list_sources_request",
                extra={
                    "filters": {
                        "artifact_type": artifact_type,
                        "tags": tags,
                        "trust_level": trust_level,
                        "search": search,
                    },
                    "result_count": len(items),
                    "total_count": total_count,
                    "has_more": has_more,
                    "cursor": cursor,
                },
            )
        else:
            # Without filters: use repository's paginated query for efficiency
            result = source_repo.list_paginated(limit=limit, cursor=cursor)

            # Convert ORM models to API responses; pass composite aggregates
            # and status counts so all sources are enriched without N+1 queries.
            items = [
                source_to_response(
                    source,
                    composite_aggregates=composite_aggs,
                    counts_by_status=status_counts_bulk.get(source.id),
                )
                for source in result.items
            ]

            # Build page info
            page_info = PageInfo(
                has_next_page=result.has_more,
                has_previous_page=cursor is not None,
                start_cursor=items[0].id if items else None,
                end_cursor=items[-1].id if items else None,
                total_count=None,  # Not computed for efficiency without filters
            )

            # Structured logging for unfiltered list request
            logger.info(
                "list_sources_request",
                extra={
                    "filters": None,
                    "result_count": len(items),
                    "total_count": None,
                    "has_more": result.has_more,
                    "cursor": cursor,
                },
            )

        return SourceListResponse(items=items, page_info=page_info)
    except Exception as e:
        logger.error(f"Failed to list sources: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list marketplace sources",
        ) from e


@router.get(
    "/{source_id}",
    response_model=SourceResponse,
    summary="Get source by ID",
    description="""
    Retrieve a specific GitHub repository source by its unique identifier.

    Returns all source configuration including manual_map if configured.

    **Response Example**:
    ```json
    {
        "id": "src-abc123",
        "repo_url": "https://github.com/user/templates",
        "owner": "user",
        "repo_name": "templates",
        "ref": "main",
        "root_hint": "claude-artifacts",
        "trust_level": "trusted",
        "visibility": "public",
        "scan_status": "success",
        "artifact_count": 42,
        "manual_map": {
            "advanced-skills/python-backend": "skill",
            "cli-tools/scaffold": "command"
        },
        "enable_frontmatter_detection": true,
        "last_sync_at": "2025-01-06T12:00:00Z",
        "created_at": "2025-01-06T10:00:00Z",
        "updated_at": "2025-01-06T11:30:00Z"
    }
    ```

    **manual_map field**: Dictionary mapping directory paths to artifact types.
    Empty dictionary or null if no manual mappings configured.

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
    responses={
        200: {"description": "Source details retrieved successfully"},
        404: {"description": "Source not found"},
        500: {"description": "Internal server error"},
    },
)
async def get_source(
    source_id: str,
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> SourceResponse:
    """Get a marketplace source by ID.

    Args:
        source_id: Unique source identifier
        source_repo: Injected MarketplaceSourceRepository dependency.
        catalog_repo: Injected MarketplaceCatalogRepository dependency.

    Returns:
        Source details

    Raises:
        HTTPException 404: If source not found
        HTTPException 500: If database operation fails
    """
    try:
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        status_counts = catalog_repo.count_by_status(source_id)
        return source_to_response(source, counts_by_status=status_counts)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get source {source_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve marketplace source",
        ) from e


@router.patch(
    "/{source_id}",
    response_model=SourceResponse,
    summary="Update source",
    description="""
    Update a GitHub repository source configuration.

    Allows updating ref (branch/tag/SHA), root_hint, manual_map, trust_level,
    description, notes, and frontmatter detection settings.
    Changes take effect on the next scan.

    **Manual Directory Mappings**:
    Use `manual_map` to override automatic artifact type detection for specific directories.
    This is useful when heuristic detection fails or when you want to force a directory
    to be treated as a specific artifact type.

    **Supported artifact types**: `skill`, `command`, `agent`, `mcp_server`, `hook`

    **Example Request with manual_map**:
    ```json
    {
        "manual_map": {
            "advanced-skills/python-backend": "skill",
            "cli-tools/scaffold": "command",
            "research-agents/market-analysis": "agent"
        }
    }
    ```

    **Validation**:
    - All directory paths must exist in the repository (validated against GitHub tree)
    - Artifact types must be one of: skill, command, agent, mcp_server, hook
    - Invalid paths or types will return 422 Unprocessable Entity

    **Clear Mapping**:
    To remove all manual mappings, send an empty dictionary:
    ```json
    {
        "manual_map": {}
    }
    ```

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
    responses={
        200: {"description": "Source updated successfully"},
        400: {"description": "Bad request - no update parameters provided"},
        404: {"description": "Source not found"},
        422: {
            "description": "Validation error - invalid directory path or artifact type"
        },
        500: {
            "description": "Internal server error - GitHub API failure or database error"
        },
    },
)
async def update_source(
    source_id: str,
    request: UpdateSourceRequest,
    source_repo: MarketplaceSourceConcreteRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> SourceResponse:
    """Update a marketplace source.

    Supports partial updates to source configuration including:
    - ref: Change branch/tag/SHA to scan
    - root_hint: Modify subdirectory to scan
    - manual_map: Override artifact type detection for specific directories
    - trust_level: Update trust level
    - description: Update user description
    - notes: Update internal notes
    - enable_frontmatter_detection: Toggle frontmatter parsing

    Args:
        source_id: Unique source identifier
        request: Update request with fields to modify

    Returns:
        Updated source details

    Raises:
        HTTPException 400: If no update parameters provided
        HTTPException 404: If source not found
        HTTPException 422: If manual_map contains invalid directory paths or artifact types
        HTTPException 500: If database operation fails or GitHub API fails

    Example:
        Update manual mapping to override type detection:

        >>> request = UpdateSourceRequest(
        ...     manual_map={
        ...         "skills/python": "skill",
        ...         "commands/dev": "command"
        ...     }
        ... )
        >>> response = await update_source("src-123", request)
        >>> # Next scan will use manual_map for these directories
    """
    # Check if any update parameters provided
    if all(
        v is None
        for v in [
            request.ref,
            request.root_hint,
            request.manual_map,
            request.trust_level,
            request.description,
            request.notes,
            request.enable_frontmatter_detection,
            request.indexing_enabled,
            request.import_repo_description,
            request.import_repo_readme,
            request.tags,
        ]
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one update parameter must be provided",
        )

    try:
        # Fetch existing source
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Validate manual_map paths if provided
        if request.manual_map is not None:
            await _validate_manual_map_paths(
                manual_map=request.manual_map,
                owner=source.owner,
                repo=source.repo_name,
                ref=request.ref or source.ref,  # Use new ref if updating, else existing
            )

        # Apply updates
        if request.ref is not None:
            source.ref = request.ref
        if request.root_hint is not None:
            source.root_hint = request.root_hint
        if request.manual_map is not None:
            # Store as JSON string in database (use set_manual_map_dict helper)
            if request.manual_map:
                source.set_manual_map_dict(request.manual_map)
            else:
                # Clear mapping if empty dict or None
                source.manual_map = None
        if request.trust_level is not None:
            source.trust_level = request.trust_level
        if request.description is not None:
            source.description = request.description
        if request.notes is not None:
            source.notes = request.notes
        if request.enable_frontmatter_detection is not None:
            source.enable_frontmatter_detection = request.enable_frontmatter_detection
        if request.indexing_enabled is not None:
            source.indexing_enabled = request.indexing_enabled
        if request.tags is not None:
            source.set_tags_list(request.tags)

        # Handle import_repo_description: fetch from GitHub if True
        # Also refresh GitHub topics as auto-tags
        if request.import_repo_description is True:
            try:
                from skillmeat.core.github_client import get_github_client

                client = get_github_client()
                metadata = client.get_repo_metadata(
                    f"{source.owner}/{source.repo_name}"
                )
                source.repo_description = metadata.get("description")
                logger.info(
                    f"Fetched repo description for {source.owner}/{source.repo_name}"
                )

                # Extract/refresh GitHub topics as auto-tags
                # Preserve existing approval status for known tags
                topics = metadata.get("topics", [])
                if topics:
                    existing_auto_tags = source.get_auto_tags_dict() or {
                        "extracted": []
                    }
                    existing_status = {
                        seg["value"]: seg["status"]
                        for seg in existing_auto_tags.get("extracted", [])
                    }

                    auto_tags_data = {
                        "extracted": [
                            {
                                "value": topic,
                                "normalized": topic.lower().replace("_", "-"),
                                "status": existing_status.get(topic, "pending"),
                                "source": "github_topic",
                            }
                            for topic in topics
                        ]
                    }
                    source.set_auto_tags_dict(auto_tags_data)
                    logger.info(
                        f"Refreshed {len(topics)} GitHub topics as auto-tags for {source.owner}/{source.repo_name}"
                    )
            except Exception as e:
                logger.warning(
                    f"Failed to fetch repo description for {source.owner}/{source.repo_name}: {e}"
                )
                # Don't fail the update - continue with other fields

        # Handle import_repo_readme: fetch from GitHub if True
        if request.import_repo_readme is True:
            try:
                from skillmeat.core.github_client import get_github_client

                client = get_github_client()
                # Try common README filenames
                readme_content = None
                for readme_name in ["README.md", "README.rst", "README.txt", "README"]:
                    try:
                        content_bytes = client.get_file_content(
                            f"{source.owner}/{source.repo_name}",
                            readme_name,
                            ref=source.ref,
                        )
                        readme_content = content_bytes.decode("utf-8")
                        # Truncate to 50KB if needed
                        if len(readme_content) > 50000:
                            readme_content = (
                                readme_content[:50000] + "\n... [truncated]"
                            )
                        break
                    except Exception:
                        continue

                source.repo_readme = readme_content
                if readme_content:
                    logger.info(f"Fetched README for {source.owner}/{source.repo_name}")
                else:
                    logger.info(
                        f"No README found for {source.owner}/{source.repo_name}"
                    )
            except Exception as e:
                logger.warning(
                    f"Failed to fetch README for {source.owner}/{source.repo_name}: {e}"
                )
                # Don't fail the update - continue with other fields

        # Save updates
        updated = source_repo.update(source)

        # Structured logging for source update
        logger.info(
            "update_source_request",
            extra={
                "source_id": source_id,
                "repo_url": updated.repo_url,
                "updated_fields": [
                    field
                    for field, value in [
                        ("ref", request.ref),
                        ("root_hint", request.root_hint),
                        ("manual_map", request.manual_map),
                        ("trust_level", request.trust_level),
                        ("description", request.description),
                        ("notes", request.notes),
                        (
                            "enable_frontmatter_detection",
                            request.enable_frontmatter_detection,
                        ),
                        ("indexing_enabled", request.indexing_enabled),
                        ("import_repo_description", request.import_repo_description),
                        ("import_repo_readme", request.import_repo_readme),
                        ("tags", request.tags),
                    ]
                    if value is not None
                ],
                "has_manual_map": bool(request.manual_map),
                "manual_map_count": (
                    len(request.manual_map) if request.manual_map else 0
                ),
            },
        )

        return source_to_response(updated)
    except HTTPException:
        raise
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        ) from e
    except Exception as e:
        logger.error(f"Failed to update source {source_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update marketplace source",
        ) from e


@router.delete(
    "/{source_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete source",
    description="""
    Delete a GitHub repository source and all its associated catalog entries.

    This operation cannot be undone. All discovered artifacts from this source
    will be removed from the catalog.

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
)
async def delete_source(
    source_id: str,
    source_repo: MarketplaceSourceConcreteRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> None:
    """Delete a marketplace source.

    Args:
        source_id: Unique source identifier
        source_repo: Injected MarketplaceSourceRepository dependency.

    Raises:
        HTTPException 404: If source not found
        HTTPException 500: If database operation fails
    """
    try:
        deleted = source_repo.delete(source_id)
        if not deleted:
            logger.warning(f"Source not found for deletion: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        logger.info(f"Deleted marketplace source: {source_id}")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete source {source_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete marketplace source",
        ) from e


# =============================================================================
# API-002: Rescan Endpoint
# =============================================================================


@router.post(
    "/{source_id}/rescan",
    response_model=ScanResultDTO,
    summary="Trigger repository rescan",
    description="""
    Trigger a rescan of the GitHub repository to discover new or updated artifacts.

    This operation is currently synchronous (runs in the request lifecycle).
    For large repositories, this may take several seconds. Future versions may
    support asynchronous background jobs.

    **Scan Process**:
    1. Fetch the repository tree from GitHub
    2. Apply heuristic detection to identify artifacts
    3. **Apply manual_map overrides** (if configured on source)
    4. Deduplicate artifacts within the source (same content, different paths)
    5. Deduplicate artifacts against existing collection (already imported)
    6. Update the catalog with discovered unique artifacts
    7. Update source metadata (artifact_count, last_sync_at, etc.)

    **Manual Mappings**:
    The scan uses any manual_map configured on the source to override automatic type
    detection. For example, if manual_map contains `{"advanced-skills": "skill"}`,
    all artifacts in the `advanced-skills` directory will be treated as skills
    regardless of heuristic detection results.

    **Response includes deduplication statistics**:
    - `duplicates_within_source`: Duplicate artifacts found in this repo scan
    - `duplicates_cross_source`: Artifacts already in collection from other sources
    - `total_detected`: Total artifacts before deduplication
    - `total_unique`: Unique artifacts added to catalog

    **Example Response**:
    ```json
    {
        "source_id": "src-abc123",
        "status": "success",
        "artifacts_found": 42,
        "new_count": 5,
        "updated_count": 2,
        "removed_count": 1,
        "unchanged_count": 34,
        "scan_duration_ms": 3421,
        "scanned_at": "2025-01-06T12:00:00Z",
        "duplicates_within_source": 3,
        "duplicates_cross_source": 2,
        "total_detected": 52,
        "total_unique": 47
    }
    ```

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
    responses={
        200: {"description": "Scan completed successfully"},
        404: {"description": "Source not found"},
        500: {"description": "Scan failed - check error message in response"},
    },
)
async def rescan_source(
    source_id: str,
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    transaction_handler: MarketplaceTransactionHandlerDep,
    request: ScanRequest = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> ScanResultDTO:
    """Trigger a rescan of a marketplace source.

    Args:
        source_id: Unique source identifier
        source_repo: Injected MarketplaceSourceRepository dependency.
        catalog_repo: Injected MarketplaceCatalogRepository dependency.
        transaction_handler: Injected MarketplaceTransactionHandler dependency.
        request: Optional scan configuration (force rescan, etc.)

    Returns:
        Scan result with statistics

    Raises:
        HTTPException 404: If source not found
        HTTPException 500: If scan fails
    """
    if request is None:
        request = ScanRequest()

    try:
        # Fetch source
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Perform scan using shared helper
        scan_result = await _perform_scan(
            source=source,
            source_repo=source_repo,
            catalog_repo=catalog_repo,
            transaction_handler=transaction_handler,
        )

        return scan_result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to rescan source {source_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to rescan source: {str(e)}",
        ) from e


# =============================================================================
# API-002a: Bulk Sync Imported Artifacts
# =============================================================================


@router.post(
    "/{source_id}/sync-imported",
    response_model=BulkSyncResponse,
    summary="Sync imported artifacts from source",
    operation_id="sync_imported_artifacts",
    description="""
    Sync one or more imported artifacts from this source with their upstream versions.

    This endpoint is used after a rescan detects that imported artifacts have upstream
    changes (SHA mismatch). It fetches the latest version from GitHub and updates the
    artifacts in the collection.

    **Prerequisites**:
    - Artifacts must have status="imported" in the catalog
    - Artifacts must have a valid import_id linking to the collection artifact

    **Sync behavior**:
    - Fetches the latest version from the upstream GitHub source
    - Applies changes using "overwrite" strategy (upstream wins)
    - Reports conflicts if merge is not possible

    **Example**:
    ```bash
    curl -X POST "http://localhost:8080/api/v1/marketplace/sources/src-abc123/sync-imported" \\
        -H "Content-Type: application/json" \\
        -d '{"artifact_ids": ["cat_canvas_design", "cat_my_skill"]}'
    ```

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
)
async def sync_imported_artifacts(
    source_id: str,
    request: BulkSyncRequest,
    artifact_mgr: ArtifactManagerDep,
    collection_mgr: CollectionManagerDep,
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BulkSyncResponse:
    """Sync imported artifacts from a marketplace source with upstream.

    Args:
        source_id: Unique source identifier
        request: Sync request with artifact entry IDs

    Returns:
        Bulk sync response with per-artifact results

    Raises:
        HTTPException 400: If artifact_ids is empty or invalid
        HTTPException 404: If source not found or entry IDs invalid
        HTTPException 500: If sync operation fails
    """
    if not request.artifact_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="artifact_ids cannot be empty",
        )

    try:
        # Verify source exists
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Track results
        results: List[BulkSyncItemResult] = []
        synced_count = 0
        skipped_count = 0
        failed_count = 0

        # Get collection name for sync operations
        collection_name = collection_mgr.get_active_collection_name()

        # Process each artifact
        for entry_id in request.artifact_ids:
            entry = catalog_repo.get_by_id(entry_id)

            # Verify entry exists
            if not entry:
                logger.warning(f"Catalog entry not found: {entry_id}")
                results.append(
                    BulkSyncItemResult(
                        entry_id=entry_id,
                        artifact_name="unknown",
                        success=False,
                        message=f"Catalog entry '{entry_id}' not found",
                        has_conflicts=False,
                        conflicts=None,
                    )
                )
                failed_count += 1
                continue

            # Verify entry belongs to this source
            if entry.source_id != source_id:
                logger.warning(
                    f"Entry {entry_id} does not belong to source {source_id}"
                )
                results.append(
                    BulkSyncItemResult(
                        entry_id=entry_id,
                        artifact_name=entry.name,
                        success=False,
                        message=f"Entry does not belong to source '{source_id}'",
                        has_conflicts=False,
                        conflicts=None,
                    )
                )
                failed_count += 1
                continue

            # Verify entry is imported
            if entry.status != "imported":
                logger.info(
                    f"Entry {entry_id} is not imported (status={entry.status}), skipping"
                )
                results.append(
                    BulkSyncItemResult(
                        entry_id=entry_id,
                        artifact_name=entry.name,
                        success=True,
                        message=f"Skipped: entry status is '{entry.status}', not 'imported'",
                        has_conflicts=False,
                        conflicts=None,
                    )
                )
                skipped_count += 1
                continue

            # Verify entry has import_id linking to collection artifact
            if not entry.import_id:
                logger.warning(f"Entry {entry_id} has no import_id")
                results.append(
                    BulkSyncItemResult(
                        entry_id=entry_id,
                        artifact_name=entry.name,
                        success=False,
                        message="Entry has no import_id linking to collection artifact",
                        has_conflicts=False,
                        conflicts=None,
                    )
                )
                failed_count += 1
                continue

            # Parse artifact type
            try:
                artifact_type = ArtifactType(entry.artifact_type)
            except ValueError:
                logger.error(
                    f"Invalid artifact type for entry {entry_id}: {entry.artifact_type}"
                )
                results.append(
                    BulkSyncItemResult(
                        entry_id=entry_id,
                        artifact_name=entry.name,
                        success=False,
                        message=f"Invalid artifact type: {entry.artifact_type}",
                        has_conflicts=False,
                        conflicts=None,
                    )
                )
                failed_count += 1
                continue

            # Perform sync using ArtifactManager
            try:
                # Fetch update from upstream
                fetch_result = artifact_mgr.fetch_update(
                    artifact_name=entry.name,
                    artifact_type=artifact_type,
                    collection_name=collection_name,
                )

                # Check if fetch was successful
                if fetch_result.error:
                    results.append(
                        BulkSyncItemResult(
                            entry_id=entry_id,
                            artifact_name=entry.name,
                            success=False,
                            message=f"Failed to fetch update: {fetch_result.error}",
                            has_conflicts=False,
                            conflicts=None,
                        )
                    )
                    failed_count += 1
                    continue

                # If no update available
                if not fetch_result.has_update:
                    results.append(
                        BulkSyncItemResult(
                            entry_id=entry_id,
                            artifact_name=entry.name,
                            success=True,
                            message="Already up to date with upstream",
                            has_conflicts=False,
                            conflicts=None,
                        )
                    )
                    synced_count += 1
                    continue

                # Apply update using "overwrite" strategy (upstream wins)
                update_result = artifact_mgr.apply_update_strategy(
                    fetch_result=fetch_result,
                    strategy="overwrite",
                    interactive=False,
                    auto_resolve="theirs",
                    collection_name=collection_name,
                )

                # Check result
                if update_result.updated:
                    logger.info(
                        f"Successfully synced artifact '{entry.name}' from source {source_id}"
                    )
                    results.append(
                        BulkSyncItemResult(
                            entry_id=entry_id,
                            artifact_name=entry.name,
                            success=True,
                            message="Successfully synced with upstream",
                            has_conflicts=False,
                            conflicts=None,
                        )
                    )
                    synced_count += 1
                else:
                    # Update may have conflicts
                    conflict_files = (
                        update_result.conflicted_files
                        if hasattr(update_result, "conflicted_files")
                        else None
                    )
                    results.append(
                        BulkSyncItemResult(
                            entry_id=entry_id,
                            artifact_name=entry.name,
                            success=False,
                            message="Sync failed: conflicts detected or update rejected",
                            has_conflicts=bool(conflict_files),
                            conflicts=conflict_files,
                        )
                    )
                    failed_count += 1

            except Exception as sync_error:
                logger.error(
                    f"Failed to sync artifact '{entry.name}': {sync_error}",
                    exc_info=True,
                )
                results.append(
                    BulkSyncItemResult(
                        entry_id=entry_id,
                        artifact_name=entry.name,
                        success=False,
                        message=f"Sync error: {str(sync_error)}",
                        has_conflicts=False,
                        conflicts=None,
                    )
                )
                failed_count += 1

        return BulkSyncResponse(
            total=len(request.artifact_ids),
            synced=synced_count,
            skipped=skipped_count,
            failed=failed_count,
            results=results,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to sync imported artifacts from source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to sync imported artifacts: {str(e)}",
        ) from e


# =============================================================================
# API-003: Artifacts Listing
# =============================================================================


@router.get(
    "/{source_id}/artifacts",
    response_model=CatalogListResponse,
    summary="List artifacts from source",
    operation_id="list_source_artifacts",
    description="""
    List all artifacts discovered from a specific source with optional filtering and sorting.

    By default, excluded artifacts are hidden from results. Use `include_excluded=true`
    to include them in listings (useful for reviewing or restoring excluded entries).

    Supports filtering by:
    - `artifact_type`: skill, command, agent, etc.
    - `status`: new, updated, removed, imported, excluded
    - `min_confidence`: Minimum confidence score (0-100)
    - `max_confidence`: Maximum confidence score (0-100)
    - `include_below_threshold`: Include artifacts below 30% confidence threshold (default: false)
    - `include_excluded`: Include excluded artifacts in results (default: false)

    Supports sorting by:
    - `sort_by`: Field to sort by - confidence, name, or date (detected_at). Default: confidence
    - `sort_order`: Sort order - asc or desc. Default: desc (highest confidence first)

    Results are paginated using cursor-based pagination for efficiency.

    **Examples**:

    List only non-excluded artifacts (default):
    ```bash
    curl -X GET "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts"
    ```

    List including excluded artifacts:
    ```bash
    curl -X GET "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts?include_excluded=true"
    ```

    Filter by artifact type with minimum confidence:
    ```bash
    curl -X GET "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts?artifact_type=skill&min_confidence=70"
    ```

    Sort by name ascending:
    ```bash
    curl -X GET "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts?sort_by=name&sort_order=asc"
    ```

    Pagination example:
    ```bash
    curl -X GET "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts?limit=25&cursor=abc123"
    ```

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
)
async def list_artifacts(
    source_id: str,
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    artifact_type: Optional[str] = Query(
        None, description="Filter by artifact type (skill, command, agent, etc.)"
    ),
    status_filter: Optional[str] = Query(
        None,
        alias="status",
        description="Filter by status (new, updated, removed, imported, excluded)",
    ),
    min_confidence: Optional[int] = Query(
        None, ge=0, le=100, description="Minimum confidence score (0-100)"
    ),
    max_confidence: Optional[int] = Query(
        None, ge=0, le=100, description="Maximum confidence score (0-100)"
    ),
    include_below_threshold: bool = Query(
        False,
        description="Include artifacts below 30% confidence threshold (default: false)",
    ),
    include_excluded: bool = Query(
        False, description="Include excluded artifacts in results (default: false)"
    ),
    sort_by: Optional[str] = Query(
        "confidence",
        description="Sort field: confidence, name, date (detected_at)",
        regex="^(confidence|name|date)$",
    ),
    sort_order: Optional[str] = Query(
        "desc",
        description="Sort order: asc or desc",
        regex="^(asc|desc)$",
    ),
    search: Optional[str] = Query(
        None, description="Search artifacts by name (case-insensitive partial match)"
    ),
    limit: int = Query(50, ge=1, le=100, description="Maximum items per page (1-100)"),
    cursor: Optional[str] = Query(
        None, description="Cursor for pagination (from previous response)"
    ),
    collection_mgr: CollectionManagerDep = None,
    auth_context: AuthContext = Depends(get_auth_context),
) -> CatalogListResponse:
    """List artifacts from a source with optional filters and sorting.

    Retrieves catalog entries from a source with support for filtering, sorting, and pagination.
    By default, excluded artifacts are filtered out; set include_excluded=true to see them.

    Args:
        source_id: Unique source identifier
        artifact_type: Optional artifact type filter
        status: Optional status filter (new, updated, removed, imported, excluded)
        min_confidence: Filter entries with confidence >= this value (0-100)
        max_confidence: Filter entries with confidence <= this value (0-100)
        include_below_threshold: If True, include entries <30% that are normally hidden
        include_excluded: If True, include entries with status="excluded" (default: False)
        sort_by: Field to sort by - confidence, name, or date (detected_at). Default: confidence
        sort_order: Sort order - asc or desc. Default: desc (highest first)
        search: Optional search string to filter artifacts by name (case-insensitive partial match)
        limit: Maximum items per page (1-100)
        cursor: Pagination cursor from previous response

    Returns:
        Paginated list of catalog entries with counts_by_status and counts_by_type statistics

    Raises:
        HTTPException 404: If source not found
        HTTPException 500: If database operation fails

    Example:
        >>> # List artifacts sorted by name ascending
        >>> response = await list_artifacts(
        ...     source_id="src-123",
        ...     sort_by="name",
        ...     sort_order="asc",
        ...     limit=50
        ... )
        >>> # Count by status shows excluded entries
        >>> assert response.counts_by_status.get("excluded", 0) >= 0
    """
    try:
        # Verify source exists
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Calculate effective minimum confidence based on threshold toggle
        # Default behavior (include_below_threshold=False): hide entries below 30%
        # When include_below_threshold=True: show ALL entries including those <30%
        effective_min_confidence = min_confidence
        if not include_below_threshold:
            # Apply the 30% threshold by default
            if effective_min_confidence is None:
                effective_min_confidence = CONFIDENCE_THRESHOLD
            else:
                # If user provided min_confidence, take the stricter of the two
                # Examples:
                # - min=20, threshold=30 → effective=30 (threshold wins)
                # - min=40, threshold=30 → effective=40 (min is stricter)
                effective_min_confidence = max(
                    effective_min_confidence, CONFIDENCE_THRESHOLD
                )

        # Build status filter list
        # When include_excluded=False (default), we exclude entries with status="excluded"
        effective_statuses: Optional[List[str]] = None
        if status_filter:
            # User specified a status filter - use it directly
            effective_statuses = [status_filter]

        # Determine if we need filtered query
        # When include_excluded=False and no status filter, we still need to filter
        needs_filtered_query = (
            artifact_type
            or status_filter
            or effective_min_confidence
            or max_confidence
            or not include_excluded
            or search
        )

        if needs_filtered_query:
            # Get filtered entries using get_source_catalog
            entries = catalog_repo.get_source_catalog(
                source_id=source_id,
                artifact_types=[artifact_type] if artifact_type else None,
                statuses=effective_statuses,
                min_confidence=effective_min_confidence,
                max_confidence=max_confidence,
            )

            # Filter out excluded entries if not explicitly requested
            # This handles the case where no status filter was provided
            if not include_excluded and not status_filter:
                entries = [e for e in entries if e.status != "excluded"]

            # Apply name search filter (case-insensitive partial match)
            if search:
                search_lower = search.lower()
                entries = [e for e in entries if search_lower in e.name.lower()]

            # Apply sorting before pagination
            if sort_by:
                reverse = sort_order == "desc"
                if sort_by == "confidence":
                    entries.sort(key=lambda e: e.confidence_score, reverse=reverse)
                elif sort_by == "name":
                    entries.sort(key=lambda e: e.name.lower(), reverse=reverse)
                elif sort_by == "date":
                    entries.sort(key=lambda e: e.detected_at or "", reverse=reverse)

            # Manual pagination for filtered results
            # Convert to list and apply cursor
            if cursor:
                # Find cursor position - cursor is the last item ID from previous page
                # We need to find it and start from the NEXT item
                cursor_idx = next(
                    (i for i, e in enumerate(entries) if str(e.id) == cursor),
                    -1,
                )
                if cursor_idx >= 0:
                    entries = entries[
                        cursor_idx + 1 :
                    ]  # Skip cursor item, start from next

            # Apply limit
            has_more = len(entries) > limit
            items = entries[:limit]
        else:
            # Use efficient paginated query (only when include_excluded=True and no other filters)
            result = catalog_repo.list_paginated(
                source_id=source_id,
                limit=limit,
                cursor=cursor,
            )
            entries = result.items
            has_more = result.has_more

            # Apply sorting (note: this loads all into memory but only happens when no filters applied)
            if sort_by:
                reverse = sort_order == "desc"
                if sort_by == "confidence":
                    entries.sort(key=lambda e: e.confidence_score, reverse=reverse)
                elif sort_by == "name":
                    entries.sort(key=lambda e: e.name.lower(), reverse=reverse)
                elif sort_by == "date":
                    entries.sort(key=lambda e: e.detected_at or "", reverse=reverse)

            items = entries

        # Get collection artifact keys for in_collection check
        collection_keys = (
            get_collection_artifact_keys(collection_mgr) if collection_mgr else set()
        )

        # Convert to response DTOs
        response_items = [entry_to_response(entry, collection_keys) for entry in items]

        # Get aggregated counts (needed for total_count in page_info)
        counts_by_status = catalog_repo.count_by_status(source_id=source_id)
        counts_by_type = catalog_repo.count_by_type(source_id=source_id)

        # Build page info
        page_info = PageInfo(
            has_next_page=has_more,
            has_previous_page=cursor is not None,
            start_cursor=response_items[0].id if response_items else None,
            end_cursor=response_items[-1].id if response_items else None,
            total_count=sum(counts_by_status.values()),
        )

        logger.debug(f"Listed {len(response_items)} artifacts for source {source_id}")
        return CatalogListResponse(
            items=response_items,
            page_info=page_info,
            counts_by_status=counts_by_status,
            counts_by_type=counts_by_type,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to list artifacts for source {source_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list artifacts",
        ) from e


# =============================================================================
# API-003b: Update Catalog Entry Name
# =============================================================================


@router.patch(
    "/{source_id}/artifacts/{entry_id}",
    response_model=CatalogEntryResponse,
    summary="Update catalog entry name",
    operation_id="update_catalog_entry_name",
    description="""
    Update the display name for a catalog entry.

    The updated name is used when importing the artifact into the user's collection
    and persists until the next rescan of the source.

    **Request Body**:
    - `name` (string, required): New artifact name (1-100 chars, no path separators)

    **Response**: Updated catalog entry

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
)
async def update_catalog_entry_name(
    source_id: str,
    entry_id: str,
    request: UpdateCatalogEntryNameRequest,
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    collection_mgr: CollectionManagerDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> CatalogEntryResponse:
    """Update the name for a catalog entry."""
    collection_keys = (
        get_collection_artifact_keys(collection_mgr) if collection_mgr else set()
    )

    normalized_name = request.name.strip()
    is_valid, error = validate_artifact_name(normalized_name)
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error or "Invalid artifact name",
        )

    try:
        # Verify source exists
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        try:
            entry = catalog_repo.update_name(entry_id, source_id, normalized_name)
        except ValueError as ve:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(ve),
            ) from ve

        if not entry:
            logger.warning(f"Catalog entry not found: {entry_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Catalog entry with ID '{entry_id}' not found",
            )

        logger.info(f"Updated catalog entry name: {entry_id} -> {normalized_name}")
        return entry_to_response(entry, collection_keys)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to update catalog entry name {entry_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update catalog entry name: {str(e)}",
        ) from e


# =============================================================================
# Skill-contained artifacts composite wiring (SCA-P2-03)
# =============================================================================


def _wire_skill_composite(
    ctx: "ImportContext",
    source_id: str,
    entry,
    catalog_repo: "MarketplaceCatalogRepository",
    collection_id: str,
) -> None:
    """Wire create_skill_composite_with_session() for a successfully imported skill.

    Called from ``import_artifacts()`` when ``SKILL_CONTAINED_ARTIFACTS_ENABLED``
    is set.  Retrieves the embedded artifact list stored in the catalog entry's
    ``metadata_json`` at scan time, then calls
    :meth:`~skillmeat.core.services.composite_service.CompositeService.create_skill_composite_with_session`
    within the caller-supplied transaction context so the composite rows are part of the
    same atomic transaction as the skill's ``Artifact`` row.

    If no embedded artifacts are found in ``metadata_json`` the function is a
    no-op (not every skill has embedded children).

    Failures are propagated to the caller so that the session can be rolled back
    and no orphaned rows are left in the database.

    Args:
        ctx: Active ``ImportContext`` owned by ``import_artifacts()``.
        source_id: Marketplace source ID (used for catalog lookup).
        entry: ``ImportEntry`` for the successfully imported skill.
        catalog_repo: Repository for fetching the full catalog entry.
        collection_id: Owning collection identifier (e.g. ``"default"``).
    """
    from skillmeat.core.services.composite_service import CompositeService

    # Retrieve embedded artifacts stored in metadata_json at scan time.
    catalog_entry = catalog_repo.get_by_id(entry.catalog_entry_id)
    if catalog_entry is None:
        logger.debug(
            "_wire_skill_composite: catalog entry %s not found, skipping",
            entry.catalog_entry_id,
        )
        return

    embedded_dicts: list = []
    if catalog_entry.metadata_json:
        try:
            meta = json.loads(catalog_entry.metadata_json)
            embedded_dicts = meta.get("embedded_artifacts", [])
        except (json.JSONDecodeError, AttributeError) as parse_err:
            logger.warning(
                "_wire_skill_composite: failed to parse metadata_json for %s:%s — %s",
                entry.artifact_type,
                entry.name,
                parse_err,
            )

    if not embedded_dicts:
        # No embedded children recorded; nothing to do.
        logger.debug(
            "_wire_skill_composite: no embedded_artifacts in metadata_json for skill %s",
            entry.name,
        )
        return

    # Reconstruct lightweight embedded objects compatible with create_skill_composite.
    # We use SimpleNamespace so that getattr() access in the service works correctly.
    from types import SimpleNamespace

    embedded_list = [
        SimpleNamespace(
            artifact_type=d.get("artifact_type", ""),
            name=d.get("name", ""),
            upstream_url=d.get("upstream_url", ""),
            content_hash=d.get("content_hash"),
        )
        for d in embedded_dicts
        if d.get("artifact_type") and d.get("name")
    ]

    if not embedded_list:
        logger.debug(
            "_wire_skill_composite: all embedded_artifacts filtered out for skill %s",
            entry.name,
        )
        return

    # Resolve the Artifact ORM row for this skill within the active session.
    artifact_id = f"{entry.artifact_type}:{entry.name}"
    skill_artifact = ctx.get_artifact_in_session(artifact_id)
    if skill_artifact is None:
        logger.error(
            "_wire_skill_composite: Artifact row for '%s' not found — cannot create composite",
            artifact_id,
        )
        raise RuntimeError(
            f"Artifact row missing for {artifact_id!r}; cannot create skill composite"
        )

    svc = CompositeService()
    svc.create_skill_composite_with_session(
        session=ctx.session,
        skill_artifact=skill_artifact,
        embedded_list=embedded_list,
        collection_id=collection_id,
        display_name=entry.name,
        description=entry.description,
    )
    logger.info(
        "_wire_skill_composite: created skill composite for '%s' with %d embedded members",
        artifact_id,
        len(embedded_list),
    )


# =============================================================================
# Composite child-import helper
# =============================================================================


def _import_composite_children(
    session,
    artifact_mgr,
    collection_mgr,
    catalog_repo: "MarketplaceCatalogRepository",
    transaction_handler: "MarketplaceTransactionHandler",
    source_id: str,
    source_ref: Optional[str],
    composite_entry,
    strategy: "ConflictStrategy",
    populate_fn,
) -> int:
    """Import child artifacts belonging to a composite and populate the DB cache.

    Scans the catalog for non-composite entries from the same source whose
    ``path`` starts with the composite's ``path`` prefix (i.e. they live
    inside the composite directory tree).  Each child is downloaded via the
    :class:`ImportCoordinator` and its DB cache row is created via
    ``populate_fn``.

    Args:
        session: Database session used for cache population.
        artifact_mgr: ArtifactManager instance passed to ``populate_fn``.
        collection_mgr: CollectionManager used by :class:`ImportCoordinator`.
        catalog_repo: Repository for fetching catalog entries.
        transaction_handler: Transaction handler for marking entries imported.
        source_id: Source identifier.
        source_ref: Git ref (branch/tag/SHA) for the source.
        composite_entry: The successfully-imported composite :class:`ImportEntry`.
        strategy: Conflict strategy to apply for child imports.
        populate_fn: Callable matching the signature of
            ``populate_collection_artifact_from_import``.

    Returns:
        Number of children successfully imported to the DB cache.
    """
    # The composite entry's catalog_entry_id maps to a row in
    # marketplace_catalog_entries which has an ``upstream_url`` and ``path``.
    # We use the path to find child catalog entries (prefix match).
    composite_catalog = catalog_repo.get_by_id(composite_entry.catalog_entry_id)
    if not composite_catalog:
        logger.debug(
            "Composite catalog entry not found for child import: %s",
            composite_entry.catalog_entry_id,
        )
        return 0

    composite_path_prefix = composite_catalog.path.rstrip("/") + "/"

    # Fetch all non-composite catalog entries for this source and filter by
    # path prefix.  We use list_by_source (already available) to avoid adding
    # a new repository method just for this case.
    all_entries = catalog_repo.list_by_source(source_id)
    child_catalog_entries = [
        e
        for e in all_entries
        if e.artifact_type != "composite"
        and e.path.startswith(composite_path_prefix)
    ]

    if not child_catalog_entries:
        logger.debug(
            "No child catalog entries found for composite '%s' (prefix: %s)",
            composite_entry.name,
            composite_path_prefix,
        )
        return 0

    logger.info(
        "Importing %d child artifact(s) for composite '%s'",
        len(child_catalog_entries),
        composite_entry.name,
    )

    children_added = 0
    membership_child_ids: list[str] = []
    coordinator = ImportCoordinator(
        collection_name="default",
        collection_mgr=collection_mgr,
    )

    for child_entry in child_catalog_entries:
        # Build tags from path_segments as in the parent import endpoint.
        child_tags = []
        if child_entry.path_segments:
            try:
                seg_data = json.loads(child_entry.path_segments)
                child_tags = [
                    seg["normalized"]
                    for seg in seg_data.get("extracted", [])
                    if seg.get("status") == "approved"
                ]
            except (json.JSONDecodeError, KeyError):
                pass

        child_entries_data = [
            {
                "id": child_entry.id,
                "artifact_type": child_entry.artifact_type,
                "name": child_entry.name,
                "upstream_url": child_entry.upstream_url,
                "path": child_entry.path,
                "description": child_entry.description,
                "tags": child_tags,
            }
        ]

        try:
            child_result = coordinator.import_entries(
                entries=child_entries_data,
                source_id=source_id,
                strategy=strategy,
                source_ref=source_ref,
            )
        except Exception as coord_err:
            logger.warning(
                "ImportCoordinator failed for child '%s': %s",
                child_entry.name,
                coord_err,
            )
            continue

        for child_import_entry in child_result.entries:
            child_artifact_id = (
                f"{child_import_entry.artifact_type}:{child_import_entry.name}"
            )

            if child_import_entry.status.value == "success":
                try:
                    populate_fn(
                        session,
                        artifact_mgr,
                        DEFAULT_COLLECTION_ID,
                        child_import_entry,
                    )
                    children_added += 1
                except Exception as cache_err:
                    logger.warning(
                        "Cache population failed for child %s:%s: %s",
                        child_import_entry.artifact_type,
                        child_import_entry.name,
                        cache_err,
                    )
                    # Skip membership linkage when cache population failed.
                    continue

            # Link successful imports and skip-conflicts to the composite.
            # For rename conflicts, use the resolved imported name.
            if child_import_entry.status.value in {"success", "skipped"}:
                membership_child_ids.append(child_artifact_id)

        # Mark child catalog entries as imported.
        child_imported_ids = [
            e.catalog_entry_id
            for e in child_result.entries
            if e.status.value == "success"
        ]
        if child_imported_ids:
            try:
                with transaction_handler.import_transaction(source_id) as ctx:
                    ctx.mark_imported(child_imported_ids, child_result.import_id)
            except Exception as tx_err:
                logger.warning(
                    "Failed to mark child catalog entries imported for composite '%s': %s",
                    composite_entry.name,
                    tx_err,
                )

    logger.info(
        "Composite '%s': %d child artifact(s) added to DB cache",
        composite_entry.name,
        children_added,
    )

    # ------------------------------------------------------------------
    # Create CompositeMembership rows linking each child to the composite.
    # This must run after all populate_fn calls so that Artifact rows exist.
    # ------------------------------------------------------------------
    composite_id = f"composite:{composite_entry.name}"

    # Create/update CompositeMembership rows via repository method (avoids
    # raw session access in router code).
    if membership_child_ids:
        from skillmeat.core.repositories.local_marketplace_source import (
            LocalMarketplaceSourceRepository,
        )

        _ms_repo = LocalMarketplaceSourceRepository()
        try:
            _ms_repo.upsert_composite_memberships(
                composite_id=composite_id,
                child_artifact_ids=membership_child_ids,
                collection_id=DEFAULT_COLLECTION_ID,
            )
        except Exception as mem_err:
            logger.warning(
                "CompositeMembership creation failed for '%s': %s",
                composite_id,
                mem_err,
            )

    return children_added


# =============================================================================
# API-004: Import Endpoint
# =============================================================================


@router.post(
    "/{source_id}/import",
    response_model=ImportResultDTO,
    summary="Import artifacts to collection",
    description="""
    Import selected artifacts from the catalog to the user's local collection.

    Specify which catalog entries to import and how to handle conflicts with
    existing artifacts:
    - skip: Skip conflicting artifacts (default)
    - overwrite: Replace existing artifacts
    - rename: Rename imported artifacts with suffix

    The import operation will:
    1. Validate all entry IDs belong to this source
    2. Check for conflicts with existing collection artifacts
    3. Download artifacts from upstream URLs (placeholder for now)
    4. Update catalog entry statuses to "imported"
    5. Return summary of imported, skipped, and failed entries

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
)
async def import_artifacts(
    source_id: str,
    request: ImportRequest,
    collection_mgr: CollectionManagerDep,
    artifact_mgr: ArtifactManagerDep,
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    transaction_handler: MarketplaceTransactionHandlerDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> ImportResultDTO:
    """Import catalog entries to local collection.

    Args:
        source_id: Unique source identifier
        request: Import request with entry IDs and conflict strategy

    Returns:
        Import result with statistics

    Raises:
        HTTPException 400: If entry_ids is empty or invalid
        HTTPException 404: If source not found or entry IDs invalid
        HTTPException 500: If import operation fails
    """
    if not request.entry_ids and not request.artifact_paths:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one of entry_ids or artifact_paths must be provided",
        )

    try:
        # Verify source exists
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Fetch catalog entries
        entries_data = []
        for entry_id in request.entry_ids:
            entry = catalog_repo.get_by_id(entry_id)
            if not entry:
                logger.warning(f"Catalog entry not found: {entry_id}")
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Catalog entry with ID '{entry_id}' not found",
                )

            # Verify entry belongs to this source
            if entry.source_id != source_id:
                logger.warning(
                    f"Entry {entry_id} does not belong to source {source_id}"
                )
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Entry '{entry_id}' does not belong to source '{source_id}'",
                )

            # Use the dedicated description column (populated from frontmatter during indexing)
            description = entry.description

            # Extract approved tags from path_segments
            tags = []
            if entry.path_segments:
                try:
                    segments_data = json.loads(entry.path_segments)
                    extracted = segments_data.get("extracted", [])
                    # Only include approved tags
                    tags = [
                        seg["normalized"]
                        for seg in extracted
                        if seg.get("status") == "approved"
                    ]
                except (json.JSONDecodeError, KeyError):
                    logger.warning(
                        f"Failed to parse path_segments for entry {entry.id}"
                    )
                    tags = []

            # Convert to dict for ImportCoordinator
            entries_data.append(
                {
                    "id": entry.id,
                    "artifact_type": entry.artifact_type,
                    "name": entry.name,
                    "upstream_url": entry.upstream_url,
                    "path": entry.path,
                    "description": description,
                    "tags": tags,
                }
            )

        # Resolve embedded artifact paths to import data.
        # Embedded artifacts live in parent entries' metadata_json rather than
        # having their own top-level catalog entries.  We iterate source entries
        # and match requested paths against embedded_artifacts records.
        if request.artifact_paths:
            unresolved_paths = set(request.artifact_paths)
            all_source_entries = catalog_repo.list_by_source(source_id)
            for parent_entry in all_source_entries:
                if not unresolved_paths:
                    break
                if not parent_entry.metadata_json:
                    continue
                try:
                    meta = json.loads(parent_entry.metadata_json)
                    embedded_list = meta.get("embedded_artifacts", [])
                except (json.JSONDecodeError, AttributeError):
                    continue
                for emb in embedded_list:
                    emb_path = emb.get("path", "")
                    if emb_path not in unresolved_paths:
                        continue
                    # Build a synthetic import entry dict from the embedded metadata
                    synthetic_id = f"embedded::{parent_entry.id}::{emb_path}"
                    entries_data.append(
                        {
                            "id": synthetic_id,
                            "artifact_type": emb.get("artifact_type", "skill"),
                            "name": emb.get("name") or emb_path.split("/")[-1],
                            "upstream_url": emb.get("upstream_url", ""),
                            "path": emb_path,
                            "description": None,
                            "tags": [],
                        }
                    )
                    unresolved_paths.discard(emb_path)

            if unresolved_paths:
                logger.warning(
                    "Could not resolve embedded artifact paths for source %s: %s",
                    source_id,
                    unresolved_paths,
                )
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=(
                        f"Embedded artifact path(s) not found in source '{source_id}': "
                        + ", ".join(sorted(unresolved_paths))
                    ),
                )

        # Perform import using ImportCoordinator
        # Always import to "default" collection - other collections not supported yet
        coordinator = ImportCoordinator(
            collection_name="default",
            collection_mgr=collection_mgr,
        )
        strategy = ConflictStrategy(request.conflict_strategy)

        import_result = coordinator.import_entries(
            entries=entries_data,
            source_id=source_id,
            strategy=strategy,
            source_ref=source.ref,
        )

        # Add imported artifacts to default database collection with full metadata.
        # For composite artifacts, child artifacts are also imported automatically
        # so that the complete plugin appears in the user's collection.
        #
        # SCA-P2-03: When SKILL_CONTAINED_ARTIFACTS_ENABLED is set, skill artifacts
        # that have embedded children get a CompositeArtifact row created atomically
        # in the same session.  Failure rolls back the skill's DB rows via the outer
        # except handler.
        #
        # Lock-reduction: entries are processed in batches of IMPORT_BATCH_SIZE.
        # Each batch opens its own short transaction so the exclusive SQLite write
        # lock is held for ~400 ms instead of several seconds for a large import.
        # If a batch fails the others are still committed (partial success allowed).
        _sca_enabled = (
            os.getenv("SKILL_CONTAINED_ARTIFACTS_ENABLED", "false").lower() == "true"
        )

        from skillmeat.api.services.artifact_cache_service import (
            populate_collection_artifact_from_import,
        )

        IMPORT_BATCH_SIZE = 10

        success_entries = [
            e for e in import_result.entries if e.status.value == "success"
        ]
        batches = [
            success_entries[i : i + IMPORT_BATCH_SIZE]
            for i in range(0, len(success_entries), IMPORT_BATCH_SIZE)
        ]

        total_db_added = 0

        for batch_idx, batch_entries in enumerate(batches):
            try:
                with transaction_handler.import_transaction(source_id) as ctx:
                    # Ensure the default collection row exists (idempotent).
                    # Only required on the first batch; subsequent batches find it.
                    if batch_idx == 0:
                        ctx.ensure_default_collection(DEFAULT_COLLECTION_ID, "Default Collection")

                    db_added_count = 0
                    for entry in batch_entries:
                        try:
                            populate_collection_artifact_from_import(
                                ctx.session, artifact_mgr, DEFAULT_COLLECTION_ID, entry
                            )
                            db_added_count += 1
                        except Exception as cache_err:
                            logger.warning(
                                f"Cache population failed for "
                                f"{entry.artifact_type}:{entry.name}: {cache_err}"
                            )
                            continue

                        # SCA-P2-03: For skills with embedded artifacts, create a
                        # CompositeArtifact row atomically within this same session.
                        if _sca_enabled and entry.artifact_type == "skill":
                            _wire_skill_composite(
                                ctx=ctx,
                                source_id=source_id,
                                entry=entry,
                                catalog_repo=catalog_repo,
                                collection_id=DEFAULT_COLLECTION_ID,
                            )

                        # For composites, also import child artifacts automatically.
                        # Children are catalog entries from the same source whose path
                        # starts with the composite's path (i.e. they live inside the
                        # composite directory).
                        if entry.artifact_type == "composite":
                            try:
                                _import_composite_children(
                                    session=ctx.session,
                                    artifact_mgr=artifact_mgr,
                                    collection_mgr=collection_mgr,
                                    catalog_repo=catalog_repo,
                                    transaction_handler=transaction_handler,
                                    source_id=source_id,
                                    source_ref=source.ref,
                                    composite_entry=entry,
                                    strategy=strategy,
                                    populate_fn=populate_collection_artifact_from_import,
                                )
                            except Exception as child_err:
                                logger.warning(
                                    f"Child import failed for composite "
                                    f"{entry.name}: {child_err}"
                                )

                    total_db_added += db_added_count
                    logger.debug(
                        f"Import batch {batch_idx + 1}/{len(batches)}: "
                        f"added {db_added_count} artifacts"
                    )
                    # Transaction commits automatically on context-manager exit.

            except Exception as e:
                logger.error(
                    f"Failed to import batch {batch_idx + 1}/{len(batches)} "
                    f"for source {source_id}: {e}"
                )
                # Continue with next batch — partial success is allowed.
                # File-system import already succeeded regardless.
                continue

        logger.info(
            f"Added {total_db_added} artifacts to default database collection "
            f"with full metadata"
        )

        # Sync SKIPPED artifacts to the database cache.
        #
        # When conflict_strategy is "skip" (the default), ImportCoordinator marks
        # entries as SKIPPED because the artifact already exists on the filesystem.
        # However, those artifacts still need a CollectionArtifact DB row so that
        # the frontend (which reads from the DB cache, not the filesystem) can see
        # them.  We call populate_collection_artifact_from_import() for each
        # skipped entry here — it is idempotent (create-or-update), so re-running
        # for an already-present row is safe.
        skipped_entries = [
            e for e in import_result.entries if e.status.value == "skipped"
        ]
        if skipped_entries:
            logger.info(
                f"Syncing {len(skipped_entries)} skipped artifacts to database cache"
            )
            total_skipped_synced = 0
            try:
                with transaction_handler.import_transaction(source_id) as ctx:
                    ctx.ensure_default_collection(DEFAULT_COLLECTION_ID, "Default Collection")
                    for entry in skipped_entries:
                        try:
                            populate_collection_artifact_from_import(
                                ctx.session,
                                artifact_mgr,
                                DEFAULT_COLLECTION_ID,
                                entry,
                            )
                            total_skipped_synced += 1
                        except Exception as cache_err:
                            logger.warning(
                                f"Cache population failed for skipped entry "
                                f"{entry.artifact_type}:{entry.name}: {cache_err}"
                            )
                logger.debug(
                    f"Synced {total_skipped_synced}/{len(skipped_entries)} "
                    f"skipped artifacts to database cache"
                )
            except Exception as e:
                logger.error(
                    f"Failed to sync skipped artifacts to database cache for "
                    f"source {source_id}: {e}"
                )
                # Non-fatal — filesystem import already succeeded.

        # Update catalog entry statuses atomically
        with transaction_handler.import_transaction(source_id) as ctx:
            # Get list of successfully imported entry IDs
            imported_ids = [
                entry.catalog_entry_id
                for entry in import_result.entries
                if entry.status.value == "success"
            ]

            if imported_ids:
                ctx.mark_imported(imported_ids, import_result.import_id)

            # Mark failed entries
            failed_entries = [
                entry
                for entry in import_result.entries
                if entry.status.value == "error"
            ]
            for entry in failed_entries:
                ctx.mark_failed(
                    [entry.catalog_entry_id],
                    entry.error_message or "Unknown error",
                )

        # Build response DTO
        result_dto = ImportResultDTO(
            imported_count=import_result.success_count,
            skipped_count=import_result.skipped_count,
            error_count=import_result.error_count,
            imported_ids=imported_ids,
            skipped_ids=[
                e.catalog_entry_id
                for e in import_result.entries
                if e.status.value == "skipped"
            ],
            errors=[
                {
                    "entry_id": e.catalog_entry_id,
                    "error": e.error_message or "Unknown error",
                }
                for e in failed_entries
            ],
        )

        logger.info(
            f"Import completed for source {source_id}: "
            f"{result_dto.imported_count} imported, "
            f"{result_dto.skipped_count} skipped, "
            f"{result_dto.error_count} errors"
        )
        return result_dto

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to import artifacts from source {source_id}: {e}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to import artifacts: {str(e)}",
        ) from e


# =============================================================================
# API-004a: Re-import Endpoint
# =============================================================================


@router.post(
    "/{source_id}/entries/{entry_id}/reimport",
    response_model=ReimportResponse,
    summary="Force re-import artifact",
    operation_id="reimport_catalog_entry",
    description="""
    Force re-import an artifact from upstream, resetting its catalog entry status.

    This endpoint handles several scenarios:
    - Artifacts with status="imported" that need to be refreshed from upstream
    - Artifacts that were deleted but catalog entry still shows "imported"
    - Broken or missing artifacts in the collection

    **Workflow**:
    1. Validates the catalog entry exists and belongs to this source
    2. If `keep_deployments=True` and artifact exists in collection:
       - Saves deployment records
       - Deletes the existing artifact
       - Re-imports from upstream
       - Restores deployment records
    3. If `keep_deployments=False` or artifact is missing:
       - Resets catalog entry status to "new"
       - Performs a fresh import from upstream

    **Request Body**:
    - `keep_deployments` (bool, optional): Whether to preserve deployment records (default: false)

    **Response**: Result with success flag, new artifact ID, and restoration count

    **Example**:
    ```bash
    curl -X POST "http://localhost:8080/api/v1/marketplace/sources/src-abc123/entries/cat-def456/reimport" \\
         -H "Content-Type: application/json" \\
         -d '{"keep_deployments": true}'
    ```

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
    responses={
        200: {"description": "Re-import completed successfully"},
        404: {"description": "Source or catalog entry not found"},
        500: {"description": "Re-import failed - check error message"},
    },
)
async def reimport_catalog_entry(
    source_id: str,
    entry_id: str,
    request: ReimportRequest,
    artifact_mgr: ArtifactManagerDep,
    collection_mgr: CollectionManagerDep,
    source_repo: MarketplaceSourceConcreteRepoDep,
    catalog_repo: MarketplaceCatalogRepoDep,
    transaction_handler: MarketplaceTransactionHandlerDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> ReimportResponse:
    """Force re-import a catalog entry from upstream.

    Works for:
    - Artifacts with status="imported"
    - Artifacts that were deleted but catalog entry still shows "imported"
    - Broken/missing artifacts in collection

    Args:
        source_id: Unique source identifier
        entry_id: Unique catalog entry identifier
        request: Re-import request with keep_deployments flag
        artifact_mgr: Artifact manager dependency
        collection_mgr: Collection manager dependency

    Returns:
        ReimportResponse with success status and details

    Raises:
        HTTPException 404: If source or entry not found
        HTTPException 500: If re-import operation fails
    """
    try:
        # Verify source exists
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found for reimport: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Fetch catalog entry
        entry = catalog_repo.get_by_id(entry_id)
        if not entry:
            logger.warning(f"Catalog entry not found for reimport: {entry_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Catalog entry with ID '{entry_id}' not found",
            )

        # Verify entry belongs to this source
        if entry.source_id != source_id:
            logger.warning(f"Entry {entry_id} does not belong to source {source_id}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Entry '{entry_id}' does not belong to source '{source_id}'",
            )

        # Check if artifact exists in collection
        artifact_type_str = entry.artifact_type
        artifact_name = entry.name
        artifact_id = f"{artifact_type_str}:{artifact_name}"

        # Try to find existing artifact
        existing_artifact = None
        saved_deployments: List[Dict[str, str]] = []
        collection_name = collection_mgr.get_active_collection_name()

        try:
            from skillmeat.core.artifact import ArtifactType as CoreArtifactType

            artifact_type = CoreArtifactType(artifact_type_str)
            collection = collection_mgr.load_collection(collection_name)
            existing_artifact = collection.find_artifact(artifact_name, artifact_type)
        except (ValueError, Exception) as e:
            logger.debug(
                f"Artifact not found in collection (may be deleted): {artifact_id}, error: {e}"
            )

        # If artifact exists and keep_deployments is True, save deployments
        if existing_artifact and request.keep_deployments:
            # TODO: Implement deployment record saving when deployment tracking is available
            # For now, log a message indicating this feature is planned
            logger.info(
                f"keep_deployments=True but deployment tracking not yet implemented "
                f"for artifact {artifact_id}"
            )
            # saved_deployments = artifact_mgr.get_deployments(artifact_name, artifact_type)

        # Delete existing artifact if present
        if existing_artifact:
            try:
                artifact_mgr.remove(
                    artifact_name,
                    CoreArtifactType(artifact_type_str),
                    collection_name,
                )
                logger.info(f"Deleted existing artifact for reimport: {artifact_id}")
            except Exception as e:
                logger.warning(f"Failed to delete existing artifact: {e}")
                # Continue anyway - artifact might be partially deleted or corrupted

        # Reset catalog entry status to allow re-import
        reset_entry = catalog_repo.reset_import_status(entry_id, source_id)
        if not reset_entry:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to reset catalog entry status",
            )

        # Use the dedicated description column (populated from frontmatter during indexing)
        description = entry.description

        tags = []
        if entry.path_segments:
            try:
                segments_data = json.loads(entry.path_segments)
                extracted = segments_data.get("extracted", [])
                tags = [
                    seg["normalized"]
                    for seg in extracted
                    if seg.get("status") == "approved"
                ]
            except (json.JSONDecodeError, KeyError):
                tags = []

        # Perform the import
        entries_data = [
            {
                "id": entry.id,
                "artifact_type": entry.artifact_type,
                "name": entry.name,
                "upstream_url": entry.upstream_url,
                "path": entry.path,
                "description": description,
                "tags": tags,
            }
        ]

        coordinator = ImportCoordinator(
            collection_name=collection_name,
            collection_mgr=collection_mgr,
        )

        import_result = coordinator.import_entries(
            entries=entries_data,
            source_id=source_id,
            strategy=ConflictStrategy.OVERWRITE,  # Force overwrite for reimport
            source_ref=source.ref,
        )

        # Check import result
        if import_result.error_count > 0:
            error_msg = (
                import_result.entries[0].error_message
                if import_result.entries
                else "Unknown error"
            )
            logger.error(f"Re-import failed for {artifact_id}: {error_msg}")
            return ReimportResponse(
                success=False,
                artifact_id=None,
                message=f"Re-import failed: {error_msg}",
                deployments_restored=0,
            )

        # Update catalog entry status to imported
        with transaction_handler.import_transaction(source_id) as ctx:
            ctx.mark_imported([entry_id], import_result.import_id)

        # Add to default database collection with full metadata.
        # For composite artifacts, child artifacts are also imported automatically.
        try:
            from skillmeat.api.services.artifact_cache_service import (
                populate_collection_artifact_from_import,
            )

            # import_result.entries[0] has the ImportEntry with full context
            import_entry = import_result.entries[0] if import_result.entries else None
            if import_entry and import_entry.status.value == "success":
                with transaction_handler.import_transaction(source_id) as ctx:
                    ctx.ensure_default_collection(DEFAULT_COLLECTION_ID, "Default Collection")
                    populate_collection_artifact_from_import(
                        ctx.session, artifact_mgr, DEFAULT_COLLECTION_ID, import_entry
                    )
                logger.info(
                    f"Added artifact to database collection with full metadata: "
                    f"{artifact_id}"
                )

                # For composite reimports, also import child artifacts.
                if import_entry.artifact_type == "composite":
                    try:
                        with transaction_handler.import_transaction(source_id) as ctx:
                            _import_composite_children(
                                session=ctx.session,
                                artifact_mgr=artifact_mgr,
                                collection_mgr=collection_mgr,
                                catalog_repo=catalog_repo,
                                transaction_handler=transaction_handler,
                                source_id=source_id,
                                source_ref=source.ref,
                                composite_entry=import_entry,
                                strategy=ConflictStrategy.OVERWRITE,
                                populate_fn=populate_collection_artifact_from_import,
                            )
                    except Exception as child_err:
                        logger.warning(
                            f"Child import failed for composite "
                            f"{import_entry.name}: {child_err}"
                        )
            else:
                logger.warning(
                    f"No successful import entry to populate cache for: "
                    f"{artifact_id}"
                )
        except Exception as e:
            logger.warning(f"Failed to add artifact to database collection: {e}")

        # Restore deployments if requested
        deployments_restored = 0
        if request.keep_deployments and saved_deployments:
            # TODO: Implement deployment restoration when deployment tracking is available
            pass

        logger.info(f"Successfully re-imported artifact: {artifact_id}")
        return ReimportResponse(
            success=True,
            artifact_id=artifact_id,
            message="Successfully re-imported artifact from upstream",
            deployments_restored=deployments_restored,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to re-import artifact from source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to re-import artifact: {str(e)}",
        ) from e


# =============================================================================
# API-004b: Exclude Artifact Endpoint
# =============================================================================


@router.patch(
    "/{source_id}/artifacts/{entry_id}/exclude",
    response_model=CatalogEntryResponse,
    summary="Mark or restore catalog artifact",
    operation_id="exclude_or_restore_artifact",
    description="""
    Mark a catalog entry as excluded from the catalog or restore a previously excluded entry.

    Use this endpoint to mark artifacts that are false positives (not actually Claude artifacts),
    documentation-only files, or other entries that shouldn't appear in the default catalog view.
    Excluded artifacts are hidden unless explicitly requested with `include_excluded=True` when
    listing artifacts.

    This operation is idempotent - calling it multiple times with the same parameters will
    return success with the current state.

    **Request Body**:
    - `excluded` (bool, required): True to mark as excluded, False to restore
    - `reason` (string, optional): User-provided reason (max 500 chars)

    **Response**: Updated catalog entry with `excluded_at` and `excluded_reason` fields

    **Examples**:

    Mark as excluded with reason:
    ```bash
    curl -X PATCH "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts/cat-def456/exclude" \\
         -H "Content-Type: application/json" \\
         -d '{
           "excluded": true,
           "reason": "Not a valid skill - documentation only"
         }'
    ```

    Restore previously excluded:
    ```bash
    curl -X PATCH "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts/cat-def456/exclude" \\
         -H "Content-Type: application/json" \\
         -d '{"excluded": false}'
    ```

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
)
async def exclude_artifact(
    source_id: str,
    entry_id: str,
    request: ExcludeArtifactRequest,
    source_repo: MarketplaceSourceRepoDep,
    collection_mgr: CollectionManagerDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> CatalogEntryResponse:
    """Mark or restore a catalog entry as excluded.

    Marks artifacts that are false positives or not actual Claude artifacts as excluded.
    Excluded artifacts are filtered from default catalog listings but can be restored.
    This operation is idempotent - calling it on already excluded entries succeeds.

    Args:
        source_id: Unique source identifier
        entry_id: Unique catalog entry identifier
        request: Exclusion request with excluded flag and optional reason
        collection_mgr: Collection manager for in_collection lookup

    Returns:
        Updated catalog entry with exclusion metadata

    Raises:
        HTTPException 404: If source or entry not found
        HTTPException 400: If entry does not belong to source
        HTTPException 500: If database operation fails

    Example:
        >>> # Mark as excluded
        >>> request = ExcludeArtifactRequest(
        ...     excluded=True,
        ...     reason="Documentation file, not a skill"
        ... )
        >>> response = await exclude_artifact("src-123", "cat-456", request)
        >>> assert response.excluded_at is not None
        >>> assert response.status == "excluded"
    """
    collection_keys = (
        get_collection_artifact_keys(collection_mgr) if collection_mgr else set()
    )

    try:
        # Verify source exists
        source_dto = source_repo.get_source(source_id)
        if not source_dto:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Apply exclusion or restoration via repository method.
        if request.excluded:
            logger.info(
                f"Marking catalog entry as excluded: {entry_id} "
                f"(reason: {request.reason or 'none provided'})"
            )
        else:
            logger.info(f"Restoring catalog entry from exclusion: {entry_id}")

        try:
            entry = source_repo.update_catalog_entry_exclusion(
                entry_id=entry_id,
                source_id=source_id,
                excluded=request.excluded,
                reason=request.reason,
            )
        except KeyError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
        except ValueError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )

        return entry_to_response(entry, collection_keys)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to update exclusion status for entry {entry_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update exclusion status: {str(e)}",
        ) from e


@router.delete(
    "/{source_id}/artifacts/{entry_id}/exclude",
    response_model=CatalogEntryResponse,
    summary="Restore excluded catalog artifact",
    operation_id="restore_excluded_artifact",
    description="""
    Remove the exclusion status from a catalog entry, restoring it to the catalog.

    This is a convenience endpoint that performs the same operation as calling
    PATCH with `excluded=False`. It is idempotent - calling it on a non-excluded
    entry will return success with the current state.

    Restored entries will be visible in the default catalog view and can be
    imported to collections.

    **Examples**:

    Restore an excluded artifact:
    ```bash
    curl -X DELETE "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts/cat-def456/exclude"
    ```

    List artifacts including excluded (before restoring):
    ```bash
    curl -X GET "http://localhost:8080/api/v1/marketplace/sources/src-abc123/artifacts?include_excluded=true"
    ```

    After restore, the artifact will appear in both filtered and unfiltered listings.

    Authentication: TODO - Add authentication when multi-user support is implemented.
    """,
)
async def restore_excluded_artifact(
    source_id: str,
    entry_id: str,
    source_repo: MarketplaceSourceRepoDep,
    collection_mgr: CollectionManagerDep = None,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> CatalogEntryResponse:
    """Restore an excluded catalog entry to the catalog.

    Removes exclusion status and makes the artifact visible in default catalog views.
    This is idempotent - restoring a non-excluded entry succeeds without changes.

    Args:
        source_id: Unique source identifier
        entry_id: Unique catalog entry identifier
        collection_mgr: Collection manager for in_collection lookup

    Returns:
        Updated catalog entry with exclusion removed (excluded_at=None, excluded_reason=None)

    Raises:
        HTTPException 404: If source or entry not found
        HTTPException 400: If entry does not belong to source
        HTTPException 500: If database operation fails

    Example:
        >>> # Restore previously excluded entry
        >>> response = await restore_excluded_artifact("src-123", "cat-456")
        >>> assert response.excluded_at is None
        >>> assert response.excluded_reason is None
        >>> assert response.status == "new"  # or "imported" if previously imported
    """
    collection_keys = (
        get_collection_artifact_keys(collection_mgr) if collection_mgr else set()
    )

    try:
        # Verify source exists
        source_dto = source_repo.get_source(source_id)
        if not source_dto:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Restore from exclusion via repository method (idempotent).
        logger.info(f"Restoring catalog entry from exclusion: {entry_id}")
        try:
            entry = source_repo.update_catalog_entry_exclusion(
                entry_id=entry_id,
                source_id=source_id,
                excluded=False,
            )
        except KeyError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
        except ValueError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )

        return entry_to_response(entry, collection_keys)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to restore excluded entry {entry_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to restore excluded entry: {str(e)}",
        ) from e


# =============================================================================
# API-004c: Path Tags Endpoint
# =============================================================================


@router.get(
    "/{source_id}/catalog/{entry_id}/path-tags",
    response_model=PathSegmentsResponse,
    summary="Get path-based tag suggestions for catalog entry",
    description="""
    Retrieve extracted path segments and their approval status for a catalog entry.

    Returns all extracted segments with their current approval status (pending, approved,
    rejected, excluded). Only includes entries that have been scanned with path extraction
    enabled.

    The path_segments field contains a JSON object with:
    - raw_path: Original artifact path
    - extracted: Array of {segment, normalized, status, reason} objects
    - extracted_at: ISO timestamp of extraction

    Path Parameters:
    - source_id: Marketplace source identifier
    - entry_id: Catalog entry identifier

    Example: GET /marketplace/sources/src-123/catalog/cat-456/path-tags
    """,
    responses={
        404: {"description": "Source or entry not found"},
        400: {"description": "Entry has no path_segments (not extracted yet)"},
    },
)
async def get_path_tags(
    source_id: str,
    entry_id: str,
    source_repo: MarketplaceSourceRepoDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> PathSegmentsResponse:
    """Get extracted path segments for a catalog entry.

    Returns all extracted segments with their current approval status.
    Only includes entries that have been scanned with path extraction enabled.

    Args:
        source_id: Unique source identifier
        entry_id: Unique catalog entry identifier

    Returns:
        PathSegmentsResponse with raw_path and extracted segments

    Raises:
        HTTPException 404: If source or entry not found
        HTTPException 400: If entry has no path_segments (not extracted yet)
        HTTPException 500: If path_segments JSON is malformed

    Example:
        >>> response = await get_path_tags("src-123", "cat-456")
        >>> assert response.raw_path == "skills/ui-ux/canvas-design"
        >>> assert len(response.extracted) == 2
        >>> assert response.extracted[0].segment == "ui-ux"
    """
    try:
        # Verify source exists
        source_dto = source_repo.get_source(source_id)
        if not source_dto:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Fetch catalog entry via repository method.
        entry = source_repo.get_catalog_entry_raw(entry_id, source_id)
        if not entry:
            logger.warning(
                f"Catalog entry '{entry_id}' not found in source '{source_id}'"
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Catalog entry '{entry_id}' not found in source '{source_id}'",
            )

        # Check if path_segments exists
        if not entry.path_segments:
            logger.info(
                f"Entry '{entry_id}' has no path_segments (not extracted yet)"
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Entry '{entry_id}' has no path_segments (not extracted yet)",
            )

        # Parse path_segments JSON
        try:
            data = json.loads(entry.path_segments)

            # Build ExtractedSegmentResponse list
            extracted_segments = [
                ExtractedSegmentResponse(
                    segment=seg["segment"],
                    normalized=seg["normalized"],
                    status=seg["status"],
                    reason=seg.get("reason"),
                )
                for seg in data["extracted"]
            ]

            return PathSegmentsResponse(
                entry_id=entry_id,
                raw_path=data["raw_path"],
                extracted=extracted_segments,
                extracted_at=datetime.fromisoformat(data["extracted_at"]),
            )
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logger.error(f"Malformed path_segments for entry {entry_id}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal error parsing path_segments",
            ) from e

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to get path tags for entry {entry_id} in source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve path tags: {str(e)}",
        ) from e


@router.patch(
    "/{source_id}/catalog/{entry_id}/path-tags",
    response_model=UpdateSegmentStatusResponse,
    summary="Update approval status of a path segment",
    description="""
    Approve or reject a suggested path-based tag.

    Updates the status field in path_segments JSON for a single segment.
    Only "pending" status segments can be changed. Cannot modify "excluded"
    segments (filtered by extraction rules).

    Status values:
    - "pending": Segment awaiting approval/rejection (default)
    - "approved": Segment will be applied as tag during import
    - "rejected": Segment will not be applied as tag
    - "excluded": Segment filtered by rules (cannot be changed)

    Path Parameters:
    - source_id: Marketplace source identifier
    - entry_id: Catalog entry identifier

    Request Body:
    - segment: Original segment value to update (e.g., "ui-ux")
    - status: New status ("approved" or "rejected")

    Example: PATCH /marketplace/sources/src-123/catalog/cat-456/path-tags
    """,
    responses={
        404: {"description": "Source, entry, or segment not found"},
        409: {"description": "Segment already approved/rejected or is excluded"},
        500: {"description": "Malformed path_segments JSON"},
    },
)
async def update_path_tag_status(
    source_id: str,
    entry_id: str,
    request: UpdateSegmentStatusRequest,
    source_repo: MarketplaceSourceRepoDep,
    collection_mgr: CollectionManagerDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> UpdateSegmentStatusResponse:
    """Update approval status of a single path segment.

    Modifies the status field in path_segments JSON for the specified segment.
    Only "pending" segments can be updated. Attempting to change an already
    approved/rejected segment or an excluded segment will raise a 409 Conflict.

    Args:
        source_id: Unique source identifier
        entry_id: Unique catalog entry identifier
        request: Request body with segment name and new status

    Returns:
        UpdateSegmentStatusResponse with updated segments and timestamp

    Raises:
        HTTPException 404: If source, entry, or segment not found
        HTTPException 409: If segment already has status or is excluded
        HTTPException 500: If path_segments JSON is malformed

    Example:
        >>> request = UpdateSegmentStatusRequest(segment="ui-ux", status="approved")
        >>> response = await update_path_tag_status("src-123", "cat-456", request)
        >>> assert response.extracted[0].status == "approved"
    """
    try:
        # Verify source exists
        source_dto = source_repo.get_source(source_id)
        if not source_dto:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Fetch catalog entry via repository method.
        entry = source_repo.get_catalog_entry_raw(entry_id, source_id)
        if not entry:
            logger.warning(
                f"Catalog entry '{entry_id}' not found in source '{source_id}'"
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Catalog entry '{entry_id}' not found in source '{source_id}'",
            )

        # Check if path_segments exists
        if not entry.path_segments:
            logger.info(
                f"Entry '{entry_id}' has no path_segments (not extracted yet)"
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Entry '{entry_id}' has no path_segments (not extracted yet)",
            )

        # Parse path_segments JSON
        try:
            segments_data = json.loads(entry.path_segments)
        except json.JSONDecodeError:
            logger.error(f"Malformed path_segments for entry {entry_id}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal error: malformed path_segments JSON",
            )

        # Find and update the segment in memory
        segment_found = False
        request_lower = request.segment.lower()
        for seg in segments_data["extracted"]:
            if (
                seg["segment"].lower() == request_lower
                or seg.get("normalized", "").lower() == request_lower
            ):
                segment_found = True

                # Cannot change "excluded" segments
                if seg["status"] == "excluded":
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=f"Cannot change status of excluded segment '{request.segment}'",
                    )

                # Cannot double-approve/reject
                if seg["status"] in ["approved", "rejected"]:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=f"Segment '{request.segment}' already has status '{seg['status']}'",
                    )

                # Update status
                seg["status"] = request.status
                logger.info(
                    f"Updated segment '{request.segment}' (matched '{seg['segment']}') "
                    f"to status '{request.status}' in entry '{entry_id}'"
                )
                break

        if not segment_found:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Segment '{request.segment}' not found in entry '{entry_id}'",
            )

        # Save back to DB via repository method.
        updated_path_segments_json = json.dumps(segments_data)
        try:
            entry = source_repo.update_catalog_entry_path_tags(
                entry_id=entry_id,
                source_id=source_id,
                path_segments_json=updated_path_segments_json,
            )
        except KeyError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )

        # Sync approved tag to collection artifact if already imported
        if request.status == "approved":
            try:
                # Check if artifact is in collection
                in_collection, artifact_id, _ = (
                    collection_mgr.artifact_in_collection(
                        name=entry.name,
                        artifact_type=entry.artifact_type,
                    )
                )

                if in_collection:
                    # Get the normalized tag value to add
                    normalized_tag = None
                    for seg in segments_data["extracted"]:
                        if (
                            seg["segment"].lower() == request_lower
                            or seg.get("normalized", "").lower() == request_lower
                        ):
                            normalized_tag = seg.get("normalized") or seg["segment"]
                            break

                    if normalized_tag:
                        # Load collection, find artifact, add tag
                        collection = collection_mgr.load_collection()
                        for artifact in collection.artifacts:
                            if (
                                f"{artifact.type.value}:{artifact.name}"
                                == artifact_id
                            ):
                                # Add tag if not already present
                                if normalized_tag not in artifact.tags:
                                    artifact.tags.append(normalized_tag)
                                    collection_mgr.save_collection(collection)
                                    logger.info(
                                        f"Synced tag '{normalized_tag}' to collection "
                                        f"artifact '{artifact_id}'"
                                    )
                                break
            except Exception as e:
                # Log but don't fail - source tag update already succeeded
                logger.warning(f"Failed to sync tag to collection artifact: {e}")

        # Build response
        extracted_segments = [
            ExtractedSegmentResponse(
                segment=seg["segment"],
                normalized=seg["normalized"],
                status=seg["status"],
                reason=seg.get("reason"),
            )
            for seg in segments_data["extracted"]
        ]

        return UpdateSegmentStatusResponse(
            entry_id=entry_id,
            raw_path=segments_data["raw_path"],
            extracted=extracted_segments,
            updated_at=datetime.utcnow(),
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to update path tag status for entry {entry_id} in source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update path tag status: {str(e)}",
        ) from e


# =============================================================================
# API-005: File Tree Endpoint
# =============================================================================


def _map_tree_entry_type(entry_type: str) -> str:
    """Map Git tree entry types to FileTreeEntry types.

    Args:
        entry_type: Raw type from get_repo_tree() - "blob", "tree", or "symlink"

    Returns:
        Mapped type for FileTreeEntry: "file", "tree", or "symlink"
    """
    if entry_type == "blob":
        return "file"
    elif entry_type == "symlink":
        return "symlink"
    return entry_type


@router.get(
    "/{source_id}/artifacts/{artifact_path:path}/files",
    response_model=FileTreeResponse,
    summary="Get file tree for artifact",
    description="""
    Retrieve the file tree for a marketplace artifact.

    Returns a list of files and directories within the artifact, suitable
    for displaying in a file browser UI. Each entry includes the path,
    type (blob/tree), size (for files), and SHA.

    Results are cached for 1 hour to reduce GitHub API calls.

    Path Parameters:
    - source_id: Marketplace source identifier
    - artifact_path: Path to the artifact within the repository (e.g., "skills/canvas")

    Example: GET /marketplace/sources/src-123/artifacts/skills/canvas/files
    """,
)
async def get_artifact_file_tree(
    source_id: str,
    artifact_path: str,
    source_repo: MarketplaceSourceConcreteRepoDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> FileTreeResponse:
    """Get file tree for a marketplace artifact.

    Args:
        source_id: Unique source identifier
        artifact_path: Path to the artifact within the repository

    Returns:
        File tree with entries for all files and directories

    Raises:
        HTTPException 400: If path validation fails (traversal, null bytes, etc.)
        HTTPException 404: If source or artifact path not found
        HTTPException 500: If GitHub API call fails
    """
    # Security: Validate inputs to prevent path traversal attacks
    validate_source_id(source_id)
    artifact_path = validate_file_path(artifact_path)

    # Normalize "." (repository root) to empty string
    # When artifacts are at repository root, their path is stored as "." in the database
    # but empty string is the canonical representation for API operations
    if artifact_path == ".":
        artifact_path = ""

    try:
        # Get marketplace source
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Get cache and build cache key
        cache = get_github_file_cache()

        # Use source ref as SHA for cache key (or "HEAD" if not specified)
        cache_sha = source.ref or "HEAD"
        cache_key = build_tree_key(source_id, artifact_path, cache_sha)

        # Check cache first
        cached_tree = cache.get(cache_key)
        if cached_tree is not None:
            logger.debug(f"Cache hit for file tree: {artifact_path}")
            # Strip artifact path prefix from file paths
            path_prefix = f"{artifact_path}/" if artifact_path else ""
            prefix_len = len(path_prefix)
            entries = [
                FileTreeEntry(
                    path=(
                        entry["path"][prefix_len:]
                        if entry["path"].startswith(path_prefix)
                        else entry["path"]
                    ),
                    type=_map_tree_entry_type(entry["type"]),
                    size=entry.get("size"),
                    sha=entry["sha"],
                )
                for entry in cached_tree
                # Exclude the artifact directory itself
                if entry["path"] != artifact_path
            ]

            # Handle single-file artifacts (Commands, Agents, Hooks)
            # If no child entries but path looks like a single file, return the file itself
            if not entries and artifact_path.endswith(".md"):
                from pathlib import PurePosixPath

                for entry in cached_tree:
                    if entry["path"] == artifact_path and entry["type"] == "blob":
                        filename = PurePosixPath(artifact_path).name
                        entries = [
                            FileTreeEntry(
                                path=filename,
                                type="file",
                                size=entry.get("size"),
                                sha=entry["sha"],
                            )
                        ]
                        break

            return FileTreeResponse(
                entries=entries,
                artifact_path=artifact_path,
                source_id=source_id,
            )

        # Cache miss - fetch from GitHub
        logger.debug(f"Cache miss, fetching file tree: {artifact_path}")
        scanner = GitHubScanner()

        tree_entries = scanner.get_file_tree(
            owner=source.owner,
            repo=source.repo_name,
            path=artifact_path,
            sha=None,  # Will fetch default branch SHA
        )

        if not tree_entries:
            logger.warning(
                f"Artifact path not found: {artifact_path} in source {source_id}"
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Artifact path '{artifact_path}' not found in source",
            )

        # Cache the result
        cache.set(cache_key, tree_entries, ttl_seconds=DEFAULT_TREE_TTL)
        logger.debug(f"Cached file tree: {artifact_path} ({len(tree_entries)} entries)")

        # Strip artifact path prefix from file paths
        path_prefix = f"{artifact_path}/" if artifact_path else ""
        prefix_len = len(path_prefix)

        # Build entries list, excluding the artifact directory/file itself
        entries = [
            FileTreeEntry(
                path=(
                    entry["path"][prefix_len:]
                    if entry["path"].startswith(path_prefix)
                    else entry["path"]
                ),
                type=_map_tree_entry_type(entry["type"]),
                size=entry.get("size"),
                sha=entry["sha"],
            )
            for entry in tree_entries
            # Exclude the artifact directory itself (exact match with no remaining path)
            if entry["path"] != artifact_path
        ]

        # Handle single-file artifacts (Commands, Agents, Hooks)
        # If no child entries but path looks like a single file, return the file itself
        if not entries and artifact_path.endswith(".md"):
            # Find the file entry in tree_entries (should be exact match)
            for entry in tree_entries:
                if entry["path"] == artifact_path and entry["type"] == "blob":
                    # Extract just the filename for the entry path
                    from pathlib import PurePosixPath

                    filename = PurePosixPath(artifact_path).name
                    entries = [
                        FileTreeEntry(
                            path=filename,
                            type="file",
                            size=entry.get("size"),
                            sha=entry["sha"],
                        )
                    ]
                    logger.debug(
                        f"Single-file artifact detected: {artifact_path} -> {filename}"
                    )
                    break

        return FileTreeResponse(
            entries=entries,
            artifact_path=artifact_path,
            source_id=source_id,
        )

    except HTTPException:
        raise
    except RateLimitError as e:
        retry_after = parse_rate_limit_retry_after(e)
        logger.warning(
            f"GitHub rate limit exceeded for file tree {artifact_path} "
            f"from source {source_id}: {e}"
        )
        return JSONResponse(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            content={
                "detail": f"GitHub rate limit exceeded. Please retry after {retry_after} seconds."
            },
            headers={"Retry-After": str(retry_after)},
        )
    except Exception as e:
        logger.error(
            f"Failed to get file tree for artifact {artifact_path} "
            f"from source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve file tree: {str(e)}",
        ) from e


# =============================================================================
# API-006: File Content Endpoint
# =============================================================================


@router.get(
    "/{source_id}/artifacts/{artifact_path:path}/files/{file_path:path}",
    response_model=FileContentResponse,
    summary="Get file content from artifact",
    description="""
    Retrieve the content of a specific file within a marketplace artifact.

    Returns the file content with metadata including encoding, size, and SHA.
    For binary files, content is base64-encoded with is_binary=True.

    Results are cached for 2 hours to reduce GitHub API calls.

    Path Parameters:
    - source_id: Marketplace source identifier
    - artifact_path: Path to the artifact within the repository (e.g., "skills/canvas")
    - file_path: Path to the file within the artifact (e.g., "SKILL.md" or "src/index.ts")

    Example: GET /marketplace/sources/src-123/artifacts/skills/canvas/files/SKILL.md
    """,
)
async def get_artifact_file_content(
    source_id: str,
    artifact_path: str,
    file_path: str,
    source_repo: MarketplaceSourceConcreteRepoDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> FileContentResponse:
    """Get content of a file within a marketplace artifact.

    Args:
        source_id: Unique source identifier
        artifact_path: Path to the artifact within the repository
        file_path: Path to the file within the artifact

    Returns:
        File content with metadata

    Raises:
        HTTPException 400: If path validation fails (traversal, null bytes, etc.)
        HTTPException 404: If source or file not found
        HTTPException 500: If GitHub API call fails
    """
    # Security: Validate all path inputs to prevent path traversal attacks
    validate_source_id(source_id)
    artifact_path = validate_file_path(artifact_path)
    file_path = validate_file_path(file_path)

    # Normalize "." (repository root) to empty string
    # When artifacts are at repository root, their path is stored as "." in the database
    # but empty string is the canonical representation for API operations
    if artifact_path == ".":
        artifact_path = ""

    try:
        # Get marketplace source
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        # Build full file path within repository.
        #
        # Three cases handled in priority order:
        #
        # 1. artifact_path ends with the file_path component — already the full path.
        #    Covers single-file artifacts like Commands stored as "commands/foo.md"
        #    where the frontend re-passes file_path="foo.md".
        #
        # 2. artifact_path ends with a recognised file extension (defensive fallback) —
        #    the path IS the file, not a directory.  This handles embedded artifacts
        #    (e.g. Commands/Agents nested inside a Skill directory) where the stored
        #    path is "skills/my-skill/commands/foo.md".  Appending file_path would
        #    produce a non-existent "skills/my-skill/commands/foo.md/foo.md" double
        #    path.  When this fallback fires we ignore file_path entirely and log a
        #    debug message for observability.
        #
        # 3. Directory-based artifact — concatenate artifact_path + "/" + file_path
        #    (existing behaviour, unchanged).
        _FILE_EXTENSIONS = (
            ".md",
            ".py",
            ".yaml",
            ".yml",
            ".json",
            ".toml",
            ".txt",
            ".sh",
            ".ts",
            ".tsx",
            ".jsx",
            ".js",
            ".css",
        )
        if artifact_path.endswith(f"/{file_path}") or artifact_path == file_path:
            # Case 1: artifact_path already IS the full file path.
            full_file_path = artifact_path
        elif any(artifact_path.endswith(ext) for ext in _FILE_EXTENSIONS):
            # Case 2: Defensive fallback — artifact_path is a file, not a directory.
            logger.debug(
                "artifact_path '%s' ends with a file extension; treating it as the "
                "resolved file path and ignoring file_path='%s' (embedded-artifact "
                "defensive fallback)",
                artifact_path,
                file_path,
            )
            full_file_path = artifact_path
        else:
            # Case 3: Directory-based artifact — standard concatenation.
            full_file_path = f"{artifact_path}/{file_path}"

        # Get cache and build cache key
        cache = get_github_file_cache()

        # Use source ref as SHA for cache key (or "HEAD" if not specified)
        cache_sha = source.ref or "HEAD"
        cache_key = build_content_key(source_id, artifact_path, file_path, cache_sha)

        # Check cache first
        cached_content = cache.get(cache_key)
        if cached_content is not None:
            logger.debug(f"Cache hit for file content: {full_file_path}")
            return FileContentResponse(
                content=cached_content["content"],
                encoding=cached_content["encoding"],
                size=cached_content["size"],
                sha=cached_content["sha"],
                name=cached_content["name"],
                path=cached_content["path"],
                is_binary=cached_content["is_binary"],
                artifact_path=artifact_path,
                source_id=source_id,
            )

        # Cache miss - fetch from GitHub
        logger.debug(f"Cache miss, fetching file content: {full_file_path}")
        scanner = GitHubScanner()

        file_content = scanner.get_file_content(
            owner=source.owner,
            repo=source.repo_name,
            path=full_file_path,
            ref=source.ref,
        )

        if file_content is None:
            logger.warning(f"File not found: {full_file_path} in source {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"File '{file_path}' not found in artifact '{artifact_path}'",
            )

        # Cache the result
        cache.set(cache_key, file_content, ttl_seconds=DEFAULT_CONTENT_TTL)
        logger.debug(f"Cached file content: {full_file_path}")

        return FileContentResponse(
            content=file_content["content"],
            encoding=file_content["encoding"],
            size=file_content["size"],
            sha=file_content["sha"],
            name=file_content["name"],
            path=file_content["path"],
            is_binary=file_content["is_binary"],
            artifact_path=artifact_path,
            source_id=source_id,
        )

    except HTTPException:
        raise
    except RateLimitError as e:
        retry_after = parse_rate_limit_retry_after(e)
        logger.warning(
            f"GitHub rate limit exceeded for file content {file_path} in {artifact_path} "
            f"from source {source_id}: {e}"
        )
        return JSONResponse(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            content={
                "detail": f"GitHub rate limit exceeded. Please retry after {retry_after} seconds."
            },
            headers={"Retry-After": str(retry_after)},
        )
    except GitHubClientError as e:
        error_msg = str(e).lower()
        if "is a directory" in error_msg or "symlink" in error_msg:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Path '{file_path}' is a directory or unresolvable symlink, not a regular file",
            )
        logger.error(
            f"GitHub client error for file content {file_path} in {artifact_path} "
            f"from source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch file content: {e}",
        )
    except Exception as e:
        logger.error(
            f"Failed to get file content for {file_path} in {artifact_path} "
            f"from source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve file content: {str(e)}",
        ) from e


# =============================================================================
# Auto-Tags Endpoints (GitHub Topics)
# =============================================================================


@router.get(
    "/{source_id}/auto-tags",
    response_model=AutoTagsResponse,
    summary="Get auto-tag suggestions from GitHub topics",
    description="""
    Retrieve extracted GitHub repository topics and their approval status.

    Topics are extracted from the repository metadata and stored as auto-tags
    that can be approved or rejected. Approved auto-tags are added to the
    source's tags list.

    This endpoint returns all auto-tags with their current status (pending,
    approved, or rejected) and indicates whether any tags are still pending.
    """,
)
async def get_source_auto_tags(
    source_id: str,
    source_repo: MarketplaceSourceConcreteRepoDep,
    auth_context: AuthContext = Depends(get_auth_context),
) -> AutoTagsResponse:
    """Get auto-tag suggestions for a marketplace source.

    Args:
        source_id: Unique source identifier
        source_repo: Injected MarketplaceSourceRepository dependency.

    Returns:
        AutoTagsResponse with all auto-tags and their status

    Raises:
        HTTPException 404: If source not found
    """
    try:
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found for auto-tags: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        segments: List[AutoTagSegment] = []
        has_pending = False

        if source.auto_tags:
            try:
                auto_tags_data = json.loads(source.auto_tags)
                extracted = auto_tags_data.get("extracted", [])
                for seg in extracted:
                    segments.append(
                        AutoTagSegment(
                            value=seg["value"],
                            normalized=seg["normalized"],
                            status=seg["status"],
                            source=seg.get("source", "github_topic"),
                        )
                    )
                    if seg.get("status") == "pending":
                        has_pending = True
            except json.JSONDecodeError:
                logger.warning(f"Failed to parse auto_tags for source {source_id}")

        return AutoTagsResponse(
            source_id=source_id,
            segments=segments,
            has_pending=has_pending,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to get auto-tags for source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve auto-tags: {str(e)}",
        ) from e


@router.patch(
    "/{source_id}/auto-tags",
    response_model=UpdateAutoTagResponse,
    summary="Update approval status of an auto-tag",
    description="""
    Approve or reject a suggested auto-tag from GitHub topics.

    When a tag is approved, it is automatically added to the source's
    regular tags list. When rejected, it is marked as rejected and
    will not be suggested again.

    Note: Auto-tags are source-level only. They do NOT propagate to
    imported artifacts. Use path_tags for artifact-level tagging.
    """,
)
async def update_source_auto_tag(
    source_id: str,
    request: UpdateAutoTagRequest,
    source_repo: MarketplaceSourceRepoDep,
    concrete_source_repo: MarketplaceSourceConcreteRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> UpdateAutoTagResponse:
    """Update approval status of an auto-tag.

    Args:
        source_id: Unique source identifier
        request: Request body with tag value and new status
        source_repo: IMarketplaceSourceRepository DI dependency.
        concrete_source_repo: Concrete MarketplaceSourceRepository for ORM-level
            auto_tags mutations not exposed by the interface.

    Returns:
        UpdateAutoTagResponse with updated tag and any tags added

    Raises:
        HTTPException 404: If source or auto-tag not found
        HTTPException 500: If update fails
    """
    try:
        source = concrete_source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found for auto-tag update: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        if not source.auto_tags:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No auto-tags available for this source",
            )

        try:
            auto_tags_data = json.loads(source.auto_tags)
            extracted = auto_tags_data.get("extracted", [])
        except json.JSONDecodeError:
            logger.error(f"Malformed auto_tags JSON for source {source_id}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to parse auto-tags data",
            )

        # Find and update the tag
        updated_tag = None
        request_lower = request.value.lower()
        for seg in extracted:
            if (
                seg["value"].lower() == request_lower
                or seg["normalized"].lower() == request_lower
            ):
                seg["status"] = request.status
                updated_tag = AutoTagSegment(
                    value=seg["value"],
                    normalized=seg["normalized"],
                    status=seg["status"],
                    source=seg.get("source", "github_topic"),
                )
                break

        if not updated_tag:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Auto-tag '{request.value}' not found",
            )

        # Save updated auto_tags
        source.auto_tags = json.dumps(auto_tags_data)

        # If approved, add to source tags
        tags_added: List[str] = []
        if request.status == "approved":
            try:
                normalized = updated_tag.normalized.lower()
                current_tags = source.get_tags_list() or []
                if normalized not in [t.lower() for t in current_tags]:
                    current_tags.append(normalized)
                    source.set_tags_list(current_tags)
                    tags_added.append(normalized)
                    logger.info(
                        f"Added approved auto-tag '{normalized}' to source {source_id}"
                    )
            except Exception as e:
                logger.warning(f"Failed to add approved tag to source {source_id}: {e}")

        # Persist mutations on the source ORM object via repository update.
        concrete_source_repo.update(source)

        logger.info(
            f"Updated auto-tag '{request.value}' to status '{request.status}' "
            f"for source {source_id}"
        )

        return UpdateAutoTagResponse(
            source_id=source_id,
            updated_tag=updated_tag,
            tags_added=tags_added,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to update auto-tag for source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update auto-tag: {str(e)}",
        ) from e


def _refresh_auto_tags_for_source(
    source: MarketplaceSource,
    source_repo: "MarketplaceSourceRepository",
) -> tuple[int, int, int, List[AutoTagSegment]]:
    """Refresh auto-tags for a single source by fetching GitHub topics.

    Args:
        source: The marketplace source to refresh
        source_repo: Repository for persisting changes

    Returns:
        Tuple of (tags_found, tags_added, tags_updated, segments)

    Raises:
        GitHubClientError: If GitHub API call fails
    """
    from skillmeat.core.github_client import get_github_client

    client = get_github_client()
    metadata = client.get_repo_metadata(f"{source.owner}/{source.repo_name}")
    topics = metadata.get("topics", [])

    tags_found = len(topics)
    tags_added = 0
    tags_updated = 0

    # Get existing auto-tags to preserve approval status
    existing_auto_tags = source.get_auto_tags_dict() or {"extracted": []}
    existing_status = {
        seg["value"]: seg["status"] for seg in existing_auto_tags.get("extracted", [])
    }
    existing_values = set(existing_status.keys())

    # Build new auto-tags data, preserving existing status
    new_segments = []
    for topic in topics:
        status_val = existing_status.get(topic, "pending")
        if topic in existing_values:
            tags_updated += 1
        else:
            tags_added += 1

        new_segments.append(
            {
                "value": topic,
                "normalized": topic.lower().replace("_", "-"),
                "status": status_val,
                "source": "github_topic",
            }
        )

    # Update source auto_tags
    if new_segments:
        auto_tags_data = {"extracted": new_segments}
        source.set_auto_tags_dict(auto_tags_data)

    # Persist mutations on the source ORM object via repository update.
    source_repo.update(source)

    # Build response segments
    segments = [
        AutoTagSegment(
            value=seg["value"],
            normalized=seg["normalized"],
            status=seg["status"],
            source=seg["source"],
        )
        for seg in new_segments
    ]

    return tags_found, tags_added, tags_updated, segments


@router.post(
    "/{source_id}/refresh-auto-tags",
    response_model=AutoTagRefreshResponse,
    summary="Refresh auto-tags from GitHub topics",
    description="""
    Fetches the current GitHub topics for the source repository and updates
    the auto_tags field. Existing tag approval status is preserved.

    This is useful for:
    - Sources created before auto-tags feature was added
    - Syncing with updated GitHub topics after repository changes
    """,
)
async def refresh_source_auto_tags(
    source_id: str,
    source_repo: MarketplaceSourceConcreteRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> AutoTagRefreshResponse:
    """Refresh auto-tags by fetching GitHub topics for the source.

    Args:
        source_id: Unique source identifier

    Returns:
        AutoTagRefreshResponse with tags found/added/updated counts

    Raises:
        HTTPException 404: If source not found
        HTTPException 503: If GitHub API rate limited
        HTTPException 500: For other errors
    """
    from skillmeat.core.github_client import (
        GitHubClientError,
        GitHubNotFoundError,
        GitHubRateLimitError,
    )

    try:
        source = source_repo.get_by_id(source_id)
        if not source:
            logger.warning(f"Source not found for auto-tags refresh: {source_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Source with ID '{source_id}' not found",
            )

        tags_found, tags_added, tags_updated, segments = _refresh_auto_tags_for_source(
            source, source_repo
        )

        logger.info(
            f"Refreshed auto-tags for source {source_id}: "
            f"found={tags_found}, added={tags_added}, updated={tags_updated}"
        )

        return AutoTagRefreshResponse(
            source_id=source_id,
            tags_found=tags_found,
            tags_added=tags_added,
            tags_updated=tags_updated,
            segments=segments,
        )

    except HTTPException:
        raise
    except GitHubRateLimitError as e:
        logger.warning(f"Rate limited while refreshing auto-tags for {source_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"GitHub API rate limit exceeded. Reset at: {e.reset_at}",
        ) from e
    except GitHubNotFoundError as e:
        logger.warning(f"Repository not found for {source_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Repository not found: {source.owner}/{source.repo_name}",
        ) from e
    except GitHubClientError as e:
        logger.error(
            f"GitHub API error while refreshing auto-tags for {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"GitHub API error: {str(e)}",
        ) from e
    except Exception as e:
        logger.error(
            f"Failed to refresh auto-tags for source {source_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to refresh auto-tags: {str(e)}",
        ) from e


@router.post(
    "/bulk-refresh-auto-tags",
    response_model=BulkAutoTagRefreshResponse,
    summary="Refresh auto-tags for multiple sources",
    description="""
    Fetches GitHub topics for multiple sources in a single request.
    Each source is processed independently, so failures for one source
    do not affect others.

    Rate limiting is handled gracefully - if rate limited during bulk
    operation, remaining sources will be marked as failed with the
    rate limit error.
    """,
)
async def bulk_refresh_auto_tags(
    request: BulkAutoTagRefreshRequest,
    source_repo: MarketplaceSourceConcreteRepoDep,
    auth_context: AuthContext = Depends(require_auth(scopes=["collection:write"])),
) -> BulkAutoTagRefreshResponse:
    """Refresh auto-tags for multiple sources.

    Args:
        request: BulkAutoTagRefreshRequest with list of source IDs
        source_repo: Injected MarketplaceSourceRepository dependency.

    Returns:
        BulkAutoTagRefreshResponse with individual results and summary
    """
    from skillmeat.core.github_client import (
        GitHubClientError,
        GitHubRateLimitError,
    )
    results: List[BulkAutoTagRefreshItemResult] = []
    total_succeeded = 0
    total_failed = 0
    rate_limited = False
    rate_limit_message: Optional[str] = None

    for source_id in request.source_ids:
        # If we hit rate limit, fail remaining sources immediately
        if rate_limited:
            results.append(
                BulkAutoTagRefreshItemResult(
                    source_id=source_id,
                    success=False,
                    error=rate_limit_message or "Rate limit exceeded",
                )
            )
            total_failed += 1
            continue

        try:
            source = source_repo.get_by_id(source_id)
            if not source:
                results.append(
                    BulkAutoTagRefreshItemResult(
                        source_id=source_id,
                        success=False,
                        error=f"Source not found",
                    )
                )
                total_failed += 1
                continue

            tags_found, tags_added, tags_updated, _ = _refresh_auto_tags_for_source(
                source, source_repo
            )

            results.append(
                BulkAutoTagRefreshItemResult(
                    source_id=source_id,
                    success=True,
                    tags_found=tags_found,
                    tags_added=tags_added,
                    tags_updated=tags_updated,
                )
            )
            total_succeeded += 1

            logger.debug(
                f"Bulk refresh: {source_id} - found={tags_found}, "
                f"added={tags_added}, updated={tags_updated}"
            )

        except GitHubRateLimitError as e:
            rate_limited = True
            rate_limit_message = f"Rate limit exceeded. Reset at: {e.reset_at}"
            results.append(
                BulkAutoTagRefreshItemResult(
                    source_id=source_id,
                    success=False,
                    error=rate_limit_message,
                )
            )
            total_failed += 1
            logger.warning(f"Bulk refresh rate limited at source {source_id}: {e}")

        except GitHubClientError as e:
            results.append(
                BulkAutoTagRefreshItemResult(
                    source_id=source_id,
                    success=False,
                    error=f"GitHub API error: {str(e)}",
                )
            )
            total_failed += 1
            logger.warning(f"Bulk refresh GitHub error for {source_id}: {e}")

        except Exception as e:
            results.append(
                BulkAutoTagRefreshItemResult(
                    source_id=source_id,
                    success=False,
                    error=str(e),
                )
            )
            total_failed += 1
            logger.error(
                f"Bulk refresh error for {source_id}: {e}",
                exc_info=True,
            )

    logger.info(
        f"Bulk auto-tags refresh complete: {total_succeeded} succeeded, "
        f"{total_failed} failed out of {len(request.source_ids)} requested"
    )

    return BulkAutoTagRefreshResponse(
        results=results,
        total_requested=len(request.source_ids),
        total_succeeded=total_succeeded,
        total_failed=total_failed,
    )
