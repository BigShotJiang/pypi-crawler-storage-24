"""GitHub metadata extraction service.

Provides GitHub repository metadata extraction with caching support for SkillMeat
artifact auto-population.
"""

import logging
import re
import time
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import yaml
from pydantic import BaseModel, Field

from skillmeat.core.cache import MetadataCache
from skillmeat.core.discovery_metrics import (
    discovery_metrics,
    github_metadata_fetch_duration,
    github_metadata_requests_total,
    log_performance,
)
from skillmeat.core.github_client import (
    GitHubClient,
    GitHubClientError,
    GitHubNotFoundError,
    GitHubRateLimitError,
)

logger = logging.getLogger(__name__)


class GitHubSourceSpec(BaseModel):
    """Parsed GitHub source specification.

    Represents a parsed GitHub artifact source with owner, repository,
    path within the repository, and version information.

    Attributes:
        owner: GitHub username or organization
        repo: Repository name
        path: Path to artifact within repository
        version: Version specifier (tag, SHA, branch name, or "latest")
    """

    owner: str
    repo: str
    path: str
    version: Optional[str] = "latest"


class GitHubMetadata(BaseModel):
    """GitHub repository and artifact metadata.

    Contains metadata extracted from GitHub repository and artifact files,
    including frontmatter from markdown files and repository-level information.

    Attributes:
        title: Artifact title from frontmatter
        description: Artifact description from frontmatter
        author: Artifact author from frontmatter
        license: Repository license identifier (SPDX)
        topics: Repository topics/tags
        url: Full GitHub URL to the artifact
        fetched_at: Timestamp when metadata was fetched
        source: Source of metadata (always "auto-populated")
    """

    title: Optional[str] = None
    description: Optional[str] = None
    author: Optional[str] = None
    license: Optional[str] = None
    topics: List[str] = Field(default_factory=list)
    url: str
    fetched_at: datetime
    source: str = "auto-populated"


class GitHubMetadataExtractor:
    """Extracts metadata from GitHub repositories with caching.

    Provides GitHub API integration for fetching artifact metadata including
    YAML frontmatter from markdown files and repository-level metadata like
    topics and license information.

    Attributes:
        cache: MetadataCache instance for caching responses
        _client: GitHubClient instance for GitHub API operations
    """

    def __init__(self, cache: MetadataCache, token: Optional[str] = None):
        """Initialize GitHub metadata extractor.

        Args:
            cache: MetadataCache instance for caching API responses
            token: Optional GitHub personal access token. If not provided,
                GitHubClient will resolve from ConfigManager, then
                SKILLMEAT_GITHUB_TOKEN, then GITHUB_TOKEN environment variables.
                Used for higher rate limits (5000/hr vs 60/hr unauthenticated).
        """
        self.cache = cache
        self._client = GitHubClient(token=token)

    def parse_github_url(self, url: str) -> GitHubSourceSpec:
        """Parse GitHub URL or spec string into components.

        Supports multiple URL formats:
        - Short format: user/repo/path/to/artifact
        - Versioned: user/repo/path@v1.0.0 or @abc1234 (SHA)
        - HTTPS: https://github.com/user/repo/tree/main/path

        Args:
            url: GitHub URL or spec string to parse

        Returns:
            GitHubSourceSpec with parsed owner, repo, path, and version

        Raises:
            ValueError: If URL format is invalid or missing required components

        Examples:
            >>> extractor.parse_github_url("anthropics/skills/canvas")
            GitHubSourceSpec(owner='anthropics', repo='skills', path='canvas', version='latest')

            >>> extractor.parse_github_url("user/repo/path@v1.0.0")
            GitHubSourceSpec(owner='user', repo='repo', path='path', version='v1.0.0')

            >>> extractor.parse_github_url("https://github.com/user/repo/tree/main/path")
            GitHubSourceSpec(owner='user', repo='repo', path='path', version='latest')
        """
        original_url = url

        # Handle HTTPS GitHub URLs
        if url.startswith("https://github.com/"):
            parsed = urlparse(url)
            # URL format: https://github.com/owner/repo/tree/ref/path/to/artifact
            path_parts = parsed.path.strip("/").split("/")

            if len(path_parts) < 2:
                raise ValueError(
                    f"Invalid GitHub URL: {original_url}. "
                    "Expected format: https://github.com/owner/repo/tree/ref/path"
                )

            owner = path_parts[0]
            repo = path_parts[1]

            # Check if there's a /tree/ref/ part
            if len(path_parts) > 3 and path_parts[2] == "tree":
                # Skip /tree/ref and get the rest as path
                path = "/".join(path_parts[4:]) if len(path_parts) > 4 else ""
            else:
                # No /tree/ref, just owner/repo
                path = ""

            version = "latest"

        else:
            # Handle short format: user/repo/path[@version]

            # Split version from spec
            if "@" in url:
                spec_without_version, version = url.rsplit("@", 1)
            else:
                spec_without_version = url
                version = "latest"

            # Parse owner/repo/path
            parts = spec_without_version.split("/")

            if len(parts) < 2:
                raise ValueError(
                    f"Invalid GitHub spec: {original_url}. "
                    "Expected format: owner/repo or owner/repo/path or owner/repo/path@version"
                )

            owner = parts[0]
            repo = parts[1]
            path = "/".join(parts[2:]) if len(parts) > 2 else ""

        logger.debug(
            f"Parsed GitHub URL: owner={owner}, repo={repo}, path={path}, version={version}"
        )

        return GitHubSourceSpec(owner=owner, repo=repo, path=path, version=version)

    @log_performance("metadata_fetch")
    def fetch_metadata(self, source: str) -> GitHubMetadata:
        """Fetch metadata from GitHub with caching support.

        Retrieves metadata from GitHub API including:
        1. YAML frontmatter from artifact markdown files (SKILL.md, etc.)
        2. Repository metadata (topics, license)

        Results are cached based on the source string to reduce API calls.

        Args:
            source: GitHub source spec (e.g., "user/repo/path@version")

        Returns:
            GitHubMetadata with all available metadata

        Raises:
            ValueError: If source format is invalid
            RuntimeError: If GitHub API rate limit exceeded or other API errors

        Examples:
            >>> metadata = extractor.fetch_metadata("anthropics/skills/canvas-design")
            >>> print(metadata.title)
            'Canvas Design'
            >>> print(metadata.topics)
            ['design', 'canvas', 'art']
        """
        start_time = time.perf_counter()

        # Check cache first
        cache_key = f"github_metadata:{source}"
        cached = self.cache.get(cache_key)

        if cached:
            logger.info(
                "Cache hit for GitHub metadata",
                extra={"source": source, "cache_hit": True},
            )
            github_metadata_requests_total.labels(cache_hit="true").inc()
            discovery_metrics.record_metadata_fetch(cache_hit=True)
            return GitHubMetadata(**cached)

        logger.info(
            "Fetching metadata from GitHub",
            extra={"source": source, "cache_hit": False},
        )
        github_metadata_requests_total.labels(cache_hit="false").inc()
        discovery_metrics.record_metadata_fetch(cache_hit=False)

        # Parse source to get owner/repo/path
        try:
            spec = self.parse_github_url(source)
        except ValueError as e:
            raise ValueError(f"Invalid GitHub source: {e}")

        # Initialize metadata with URL
        url = f"https://github.com/{spec.owner}/{spec.repo}"
        if spec.path:
            url += f"/tree/{spec.version}/{spec.path}"

        metadata_dict: Dict[str, Any] = {
            "url": url,
            "fetched_at": datetime.now(),
            "source": "auto-populated",
            "topics": [],
        }

        # Try to fetch file content and extract frontmatter
        frontmatter_data = None

        # Handle single-file artifacts (e.g., agents/my-agent.md)
        if spec.path and spec.path.endswith(".md"):
            # Fetch the file directly instead of looking for metadata files inside it
            content = self._fetch_file_content(
                spec.owner, spec.repo, spec.path, spec.version
            )
            if content:
                logger.debug(f"Found single-file artifact at {spec.path}")
                frontmatter_data = self._extract_frontmatter(content)
        else:
            # Look for standard metadata files in order of preference
            metadata_files = ["SKILL.md", "COMMAND.md", "AGENT.md", "README.md"]

            for filename in metadata_files:
                file_path = f"{spec.path}/{filename}" if spec.path else filename
                content = self._fetch_file_content(
                    spec.owner, spec.repo, file_path, spec.version
                )

                if content:
                    logger.debug(f"Found {filename} for {source}")
                    frontmatter_data = self._extract_frontmatter(content)
                    if frontmatter_data:
                        break

        # Extract frontmatter fields
        if frontmatter_data:
            metadata_dict["title"] = frontmatter_data.get("title")
            metadata_dict["description"] = frontmatter_data.get("description")
            metadata_dict["author"] = frontmatter_data.get("author")

        # Fetch repository metadata (topics, license)
        repo_metadata = self._fetch_repo_metadata(spec.owner, spec.repo)
        if repo_metadata:
            metadata_dict["topics"] = repo_metadata.get("topics", [])
            license_info = repo_metadata.get("license")
            if license_info and isinstance(license_info, dict):
                metadata_dict["license"] = license_info.get("spdx_id")

        # Create metadata object
        metadata = GitHubMetadata(**metadata_dict)

        # Cache the result
        self.cache.set(cache_key, metadata.model_dump())

        # Record duration
        duration = time.perf_counter() - start_time
        github_metadata_fetch_duration.observe(duration)

        logger.info(
            f"Cached metadata for {source}",
            extra={
                "source": source,
                "duration_ms": round(duration * 1000, 2),
                "has_title": metadata.title is not None,
                "has_description": metadata.description is not None,
            },
        )

        return metadata

    def _fetch_file_content(
        self, owner: str, repo: str, path: str, ref: str = "HEAD"
    ) -> Optional[str]:
        """Fetch file content from GitHub using GitHubClient.

        Retrieves file content from GitHub repository using the centralized
        GitHubClient wrapper which handles authentication and error handling.

        Args:
            owner: Repository owner (username or organization)
            repo: Repository name
            path: Path to file within repository
            ref: Git ref (branch, tag, SHA, or "HEAD")

        Returns:
            Decoded file content as string, or None if file not found

        Note:
            Handles GitHubNotFoundError gracefully by returning None.
            Logs warnings for rate limits, errors for other API failures.
        """
        try:
            # Use None for ref if it's HEAD (let wrapper use default branch)
            ref_param = ref if ref != "HEAD" and ref != "latest" else None
            content_bytes = self._client.get_file_content(
                f"{owner}/{repo}", path, ref=ref_param
            )
            return content_bytes.decode("utf-8")
        except GitHubNotFoundError:
            # File not found is expected for many files - log at debug level
            logger.debug(f"File not found: {path} in {owner}/{repo}")
            return None
        except GitHubRateLimitError as e:
            logger.warning(
                f"GitHub API rate limit exceeded while fetching {path}: {e.message}"
            )
            return None
        except GitHubClientError as e:
            logger.error(f"Failed to fetch {path} from {owner}/{repo}: {e.message}")
            return None

    def _extract_frontmatter(self, content: str) -> Dict[str, Any]:
        """Extract YAML frontmatter from markdown content.

        Looks for YAML frontmatter delimited by --- at the start of the file:
        ---
        title: My Artifact
        description: Does something
        author: Author Name
        ---

        Args:
            content: Markdown file content

        Returns:
            Dictionary of frontmatter data, or empty dict if no frontmatter

        Note:
            Gracefully handles YAML parsing errors by returning empty dict.
            Uses regex pattern from skillmeat/utils/metadata.py
        """
        if not content or not content.strip():
            return {}

        # Match YAML frontmatter: --- ... ---
        # Must be at start of file
        pattern = r"^---\s*\n(.*?)\n---\s*\n"
        match = re.match(pattern, content, re.DOTALL)

        if not match:
            logger.debug("No YAML frontmatter found in content")
            return {}

        yaml_content = match.group(1)

        try:
            data = yaml.safe_load(yaml_content)
            if isinstance(data, dict):
                logger.debug(f"Extracted frontmatter with {len(data)} fields")
                return data
            else:
                logger.warning("YAML frontmatter is not a dictionary")
                return {}
        except yaml.YAMLError as e:
            logger.warning(f"Failed to parse YAML frontmatter: {e}")
            return {}

    def _fetch_repo_metadata(self, owner: str, repo: str) -> Dict[str, Any]:
        """Fetch repository metadata from GitHub using GitHubClient.

        Retrieves repository-level metadata including topics, license,
        description, and other repository information using the centralized
        GitHubClient wrapper.

        Args:
            owner: Repository owner (username or organization)
            repo: Repository name

        Returns:
            Dictionary with repository metadata (topics, license, etc.),
            or empty dict if fetch fails

        Note:
            Handles errors gracefully by returning empty dict.
            Topics and license information are the primary fields used.
        """
        try:
            metadata = self._client.get_repo_metadata(f"{owner}/{repo}")
            logger.debug(f"Fetched repository metadata for {owner}/{repo}")
            # Convert license from SPDX id string to dict format for backward compatibility
            # The existing code expects {"spdx_id": "MIT"} format
            license_spdx = metadata.get("license")
            if license_spdx:
                metadata["license"] = {"spdx_id": license_spdx}
            return metadata
        except GitHubRateLimitError as e:
            logger.warning(
                f"GitHub API rate limit exceeded while fetching repo metadata: {e.message}"
            )
            return {}
        except GitHubClientError as e:
            logger.error(
                f"Failed to fetch repository metadata for {owner}/{repo}: {e.message}"
            )
            return {}
