"""Repository pattern implementation for marketplace entities.

This module provides repository classes for marketplace data access following
the Repository pattern. These repositories abstract SQLAlchemy session management
and provide type-safe CRUD operations for marketplace-related entities.

Single-User Architecture Decision:
    SkillMeat is designed as a PERSONAL COLLECTION MANAGER - single user only.
    SQLite does not support PostgreSQL Row-Level Security (RLS) natively.

    Current Implementation:
        - No user_id scoping (single user assumed)
        - Repository methods operate on all data
        - Session management per-operation pattern

    Future Multi-Tenancy Extension Path:
        If multi-user support is needed in the future:
        1. Add user_id column to MarketplaceSource and MarketplaceCatalogEntry models
        2. Add user_id parameter to all repository methods
        3. Filter queries by user_id in BaseRepository._apply_user_scope()
        4. Migrate to PostgreSQL for proper RLS support

        Example extension pattern:
            class MarketplaceSourceRepository(BaseRepository[MarketplaceSource]):
                def list_all(self, user_id: Optional[str] = None) -> List[MarketplaceSource]:
                    session = self._get_session()
                    try:
                        query = session.query(MarketplaceSource)
                        if user_id:  # Apply scoping if multi-tenant
                            query = query.filter(MarketplaceSource.user_id == user_id)
                        return query.all()
                    finally:
                        session.close()

Repositories:
    - BaseRepository: Common CRUD patterns and session management
    - MarketplaceSourceRepository: GitHub repository source management
    - MarketplaceCatalogRepository: Discovered artifact management

Usage:
    >>> from skillmeat.cache.repositories import (
    ...     MarketplaceSourceRepository,
    ...     MarketplaceCatalogRepository
    ... )
    >>>
    >>> # Create repositories
    >>> source_repo = MarketplaceSourceRepository()
    >>> catalog_repo = MarketplaceCatalogRepository()
    >>>
    >>> # CRUD operations
    >>> source = source_repo.get_by_repo_url("https://github.com/user/repo")
    >>> entries = catalog_repo.list_by_source(source.id)
    >>>
    >>> # Bulk operations
    >>> new_entries = [entry1, entry2, entry3]
    >>> created = catalog_repo.bulk_create(new_entries)
"""

from __future__ import annotations

import json
import logging
import re
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Generator, Generic, List, Optional, Type, TypeVar

from sqlalchemy import and_, func, or_, select, text, update
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm import Session, joinedload

from skillmeat.cache.models import (
    Artifact,
    ArtifactTag,
    ArtifactVersion,
    Base,
    Collection,
    CollectionArtifact,
    CustomColor,
    DeploymentProfile,
    DeploymentSet,
    DeploymentSetMember,
    DeploymentSetTag,
    Group,
    GroupArtifact,
    MarketplaceCatalogEntry,
    MarketplaceSource,
    Tag,
    create_db_engine,
    create_tables,
)
from skillmeat.core.enums import Platform
from skillmeat.core.interfaces.context import RequestContext
from skillmeat.core.interfaces.dtos import (
    ArtifactVersionDTO,
    CacheArtifactSummaryDTO,
    CollectionArtifactDTO,
    UserCollectionDTO,
)
from skillmeat.core.interfaces.repositories import (
    IDbArtifactHistoryRepository,
    IDbCollectionArtifactRepository,
    IDbUserCollectionRepository,
)
from skillmeat.core.path_resolver import (
    DEFAULT_ARTIFACT_PATH_MAP,
    default_project_config_filenames,
)

# Configure logging
logger = logging.getLogger(__name__)

# Generic type for ORM models
T = TypeVar("T", bound=Base)


# =============================================================================
# FTS5 Search Weights
# =============================================================================

# FTS5 bm25 column weights for search ranking
# Column indices in catalog_fts: 0=name(unindexed), 1=type(unindexed), 2=title,
#                                3=description, 4=search_text, 5=tags, 6=deep
# Higher weight = higher importance when ranking search results
SEARCH_WEIGHT_TITLE = 10.0
SEARCH_WEIGHT_DESCRIPTION = 5.0
SEARCH_WEIGHT_SEARCH_TEXT = 2.0
SEARCH_WEIGHT_TAGS = 3.0
SEARCH_WEIGHT_DEEP = 1.0


# =============================================================================
# Merge Result
# =============================================================================


@dataclass
class MergeResult:
    """Result of a catalog entry merge operation.

    Tracks counts for different merge outcomes and identifies entries
    that had SHA changes while preserving import status.

    Attributes:
        inserted_count: Number of new entries inserted
        updated_count: Number of existing entries updated (non-imported/excluded)
        preserved_count: Number of imported/excluded entries that were updated
        removed_count: Number of entries marked as removed (no longer detected)
        updated_imports: Entry IDs of imported artifacts that have SHA changes
    """

    inserted_count: int
    updated_count: int
    preserved_count: int
    removed_count: int
    updated_imports: List[str]


# =============================================================================
# Pagination Result
# =============================================================================


@dataclass
class PaginatedResult(Generic[T]):
    """Paginated query result container.

    Provides cursor-based pagination for efficient querying of large datasets
    without the offset/limit performance penalty.

    Attributes:
        items: List of items for the current page
        next_cursor: Cursor value for fetching next page (None if no more)
        has_more: True if more items exist after this page
        total: Optional total count of items (expensive to compute)
        snippets: Optional dict mapping item ID to snippet data (FTS5 search only)

    Example:
        >>> # First page
        >>> result = repo.list_paginated(limit=50)
        >>> for item in result.items:
        ...     print(item.name)
        >>>
        >>> # Next page
        >>> if result.has_more:
        ...     next_result = repo.list_paginated(limit=50, cursor=result.next_cursor)
    """

    items: List[T]
    next_cursor: Optional[str]
    has_more: bool
    total: Optional[int] = None  # Optional total count
    snippets: Optional[Dict[str, Dict[str, Optional[str]]]] = None  # FTS5 snippets


@dataclass
class CatalogDiff:
    """Result of comparing old and new catalog entries.

    Used to identify changes when scanning a marketplace source and comparing
    against existing catalog entries. Enables efficient bulk updates.

    Attributes:
        new: Entries to create (in new_entries but not in DB)
        updated: Entries to update as (existing_id, new_data) pairs
        removed: Entry IDs to mark as removed (in DB but not in new_entries)
        unchanged: Entry IDs that haven't changed (matching URL and SHA)

    Example:
        >>> diff = repo.compare_catalogs("source-123", new_entries)
        >>> print(f"New: {len(diff.new)}, Updated: {len(diff.updated)}")
        >>> for entry_data in diff.new:
        ...     # Create new catalog entry
        ...     pass
    """

    new: List[Dict[str, Any]]  # Entries to create
    updated: List[tuple[str, Dict[str, Any]]]  # (existing_id, new_data) pairs
    removed: List[str]  # Entry IDs to mark as removed
    unchanged: List[str]  # Entry IDs that haven't changed


# =============================================================================
# Custom Exceptions
# =============================================================================


class RepositoryError(Exception):
    """Base exception for repository errors."""

    pass


class NotFoundError(RepositoryError):
    """Raised when a requested entity is not found."""

    pass


class ConstraintError(RepositoryError):
    """Raised when a database constraint is violated."""

    pass


# =============================================================================
# Base Repository
# =============================================================================


class BaseRepository(Generic[T]):
    """Base repository with common CRUD patterns and session management.

    Provides reusable patterns for data access operations that can be
    inherited by specific repository implementations. Handles session
    lifecycle, transaction management, and error handling.

    Type Parameters:
        T: SQLAlchemy ORM model type

    Attributes:
        db_path: Path to SQLite database file
        engine: SQLAlchemy engine for database connections
        model_class: ORM model class for type-safe operations

    Example:
        >>> class UserRepository(BaseRepository[User]):
        ...     def __init__(self, db_path: Optional[str] = None):
        ...         super().__init__(db_path, User)
        ...
        ...     def get_by_email(self, email: str) -> Optional[User]:
        ...         session = self._get_session()
        ...         try:
        ...             return session.query(User).filter_by(email=email).first()
        ...         finally:
        ...             session.close()
    """

    # Retry configuration for transient SQLite errors
    MAX_RETRIES = 3
    RETRY_DELAY_MS = 100

    def __init__(
        self, db_path: Optional[str | Path] = None, model_class: Type[T] = None
    ):
        """Initialize repository with database path and model class.

        Args:
            db_path: Optional path to database file (uses default if None)
            model_class: SQLAlchemy ORM model class
        """
        # Resolve database path
        if db_path is None:
            self.db_path = Path.home() / ".skillmeat" / "cache" / "cache.db"
        else:
            self.db_path = Path(db_path)

        # Ensure parent directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        # Create engine
        self.engine = create_db_engine(self.db_path)

        # Create a session factory bound to this repository's engine.  Using a
        # per-instance factory avoids coupling to the module-level SessionLocal
        # singleton, which is only initialised once at application startup and
        # therefore points to the *default* database path regardless of the
        # db_path passed here.  This is especially important for tests that spin
        # up isolated temporary databases.
        from sqlalchemy.orm import sessionmaker as _sessionmaker

        self._session_factory = _sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine,
        )

        # Create any missing base tables (backward compatibility)
        # Note: Alembic migrations run once at app startup via CacheManager
        create_tables(self.db_path)

        # Store model class for type-safe operations
        self.model_class = model_class

        logger.debug(
            f"Initialized {self.__class__.__name__} with database: {self.db_path}"
        )

    def _get_session(self) -> Session:
        """Create a new database session bound to this repository's engine.

        Returns:
            SQLAlchemy Session instance

        Note:
            Sessions should be closed after use. Prefer using the
            transaction() context manager for automatic cleanup.
        """
        return self._session_factory()

    @contextmanager
    def transaction(self) -> Generator[Session, None, None]:
        """Context manager for transactional operations.

        Automatically commits on success, rolls back on error, and closes
        the session. Provides automatic cleanup and error handling.

        Yields:
            SQLAlchemy Session instance

        Raises:
            RepositoryError: If operation fails

        Example:
            >>> with repo.transaction() as session:
            ...     entity = MyModel(id="123", name="Test")
            ...     session.add(entity)
            ...     # Automatic commit on success
        """
        session = self._get_session()
        try:
            yield session
            session.commit()
            logger.debug(f"Transaction committed successfully")
        except RepositoryError:
            session.rollback()
            raise
        except Exception as e:
            session.rollback()
            logger.error(f"Transaction rolled back due to error: {e}")
            raise RepositoryError(f"Transaction failed: {e}") from e
        finally:
            session.close()


# =============================================================================
# Transaction Contexts
# =============================================================================


class ScanUpdateContext:
    """Context for scan update operations within a transaction.

    Provides helper methods for atomically updating both MarketplaceSource
    and MarketplaceCatalogEntry records during a scan completion.

    The session is managed by MarketplaceTransactionHandler - do not close it
    within this context.

    Attributes:
        session: Active SQLAlchemy session
        source_id: ID of the marketplace source being updated

    Example:
        >>> # Used within scan_update_transaction context manager
        >>> with handler.scan_update_transaction(source_id) as ctx:
        ...     ctx.update_source_status("success", artifact_count=5)
        ...     ctx.replace_catalog_entries(new_entries)
    """

    def __init__(self, session: Session, source_id: str):
        """Initialize scan update context.

        Args:
            session: Active SQLAlchemy session
            source_id: ID of the marketplace source being updated
        """
        self.session = session
        self.source_id = source_id

    def update_source_status(
        self,
        status: str,
        artifact_count: Optional[int] = None,
        error_message: Optional[str] = None,
        ref: Optional[str] = None,
    ) -> None:
        """Update source scan status and metadata.

        Updates scan_status, last_sync_at, artifact_count, and optionally
        last_error and ref for a marketplace source.

        Args:
            status: New scan status ("pending", "scanning", "success", "error")
            artifact_count: Number of artifacts discovered (None to leave unchanged)
            error_message: Error message if status is "error" (None clears error)
            ref: Actual git ref used during scan (None to leave unchanged). When
                the scanner falls back to a different default branch (e.g. the
                source stores "main" but the repo uses "master"), pass the
                resolved ref here so subsequent imports use the correct branch.

        Raises:
            NotFoundError: If source does not exist

        Example:
            >>> # Mark scan as successful
            >>> ctx.update_source_status("success", artifact_count=10)
            >>>
            >>> # Mark scan as failed
            >>> ctx.update_source_status("error", error_message="API rate limit")
            >>>
            >>> # Mark scan as successful and persist branch fallback
            >>> ctx.update_source_status("success", artifact_count=10, ref="master")
        """
        source = (
            self.session.query(MarketplaceSource).filter_by(id=self.source_id).first()
        )
        if not source:
            raise NotFoundError(f"Source not found: {self.source_id}")

        # Update scan status
        source.scan_status = status
        source.last_sync_at = datetime.utcnow()

        # Update artifact count if provided
        if artifact_count is not None:
            source.artifact_count = artifact_count

        # Update error message (None clears it)
        source.last_error = error_message

        # Update ref if provided (branch fallback detected during scan)
        if ref is not None:
            source.ref = ref
            logger.info(f"Updated source {self.source_id} ref to '{ref}'")

        logger.info(
            f"Updated source {self.source_id}: status={status}, "
            f"count={artifact_count}, error={error_message}"
        )

    def replace_catalog_entries(self, entries: List[MarketplaceCatalogEntry]) -> int:
        """Delete existing entries and insert new ones atomically.

        Removes all existing catalog entries for this source and replaces
        them with the provided list. This is the typical pattern after
        a full repository scan.

        Args:
            entries: List of new MarketplaceCatalogEntry instances

        Returns:
            Number of entries inserted

        Example:
            >>> new_entries = [entry1, entry2, entry3]
            >>> count = ctx.replace_catalog_entries(new_entries)
            >>> print(f"Replaced with {count} new entries")
        """
        # Delete existing entries for this source
        deleted_count = (
            self.session.query(MarketplaceCatalogEntry)
            .filter_by(source_id=self.source_id)
            .delete(synchronize_session=False)
        )
        logger.debug(
            f"Deleted {deleted_count} existing entries for source {self.source_id}"
        )

        # Insert new entries
        if entries:
            self.session.bulk_save_objects(entries)
            logger.info(
                f"Inserted {len(entries)} new entries for source {self.source_id}"
            )

        return len(entries)

    def merge_catalog_entries(
        self, entries: List[MarketplaceCatalogEntry]
    ) -> MergeResult:
        """Merge new catalog entries with existing ones, preserving import metadata.

        Unlike replace_catalog_entries(), this method preserves import-related
        metadata for entries that have been imported or excluded. It matches
        entries by upstream_url (primary) or path + source_id (fallback).

        Merge behavior by existing entry status:
            - "imported": Preserves status, import_date, import_id, excluded_at,
              excluded_reason. Updates detection metadata (SHA, scores, etc.)
            - "excluded": Preserves all exclusion data. Updates detection metadata.
            - "new"/"updated": Full update with new entry data.
            - Not in new entries: Marked as "removed" (not deleted).

        Args:
            entries: List of newly detected MarketplaceCatalogEntry instances

        Returns:
            MergeResult with counts and list of imported entry IDs with SHA changes

        Example:
            >>> result = ctx.merge_catalog_entries(detected_entries)
            >>> print(f"Inserted: {result.inserted_count}")
            >>> print(f"Updated: {result.updated_count}")
            >>> print(f"Preserved: {result.preserved_count}")
            >>> print(f"Removed: {result.removed_count}")
            >>> if result.updated_imports:
            ...     print(f"Imports with changes: {result.updated_imports}")
        """
        # Build lookup dicts of new entries for O(1) matching
        new_by_url: Dict[str, MarketplaceCatalogEntry] = {}
        new_by_path: Dict[str, MarketplaceCatalogEntry] = {}
        new_by_type_name: Dict[str, MarketplaceCatalogEntry] = {}
        for entry in entries:
            new_by_url[entry.upstream_url] = entry
            # Fallback key: path (unique within a source)
            new_by_path[entry.path] = entry
            # Secondary fallback: artifact_type:name (stable across URL changes)
            type_name_key = f"{entry.artifact_type}:{entry.name}"
            new_by_type_name[type_name_key] = entry

        # Get existing entries for this source
        existing_entries = (
            self.session.query(MarketplaceCatalogEntry)
            .filter_by(source_id=self.source_id)
            .all()
        )

        # Track which new entries have been matched
        matched_urls: set = set()
        matched_paths: set = set()
        matched_type_names: set = set()

        # Counters
        inserted_count = 0
        updated_count = 0
        preserved_count = 0
        removed_count = 0
        updated_imports: List[str] = []

        now = datetime.utcnow()

        # Process existing entries
        for existing in existing_entries:
            # Try to find matching new entry (priority: URL > path > type:name)
            new_entry = new_by_url.get(existing.upstream_url)
            if new_entry:
                matched_urls.add(existing.upstream_url)
            else:
                # Fallback 1: match by path
                new_entry = new_by_path.get(existing.path)
                if new_entry:
                    matched_paths.add(existing.path)
                else:
                    # Fallback 2: match by artifact_type:name (handles URL changes)
                    type_name_key = f"{existing.artifact_type}:{existing.name}"
                    new_entry = new_by_type_name.get(type_name_key)
                    if new_entry:
                        matched_type_names.add(type_name_key)
                        logger.debug(
                            f"Matched entry by type:name fallback: {existing.id} ({existing.name})"
                        )

            if new_entry is None:
                # Entry no longer detected - mark as removed
                if existing.status != "removed":
                    existing.status = "removed"
                    existing.updated_at = now
                    removed_count += 1
                    logger.debug(
                        f"Marked entry as removed: {existing.id} ({existing.name})"
                    )
                continue

            # Track SHA changes for imported entries
            sha_changed = (
                existing.detected_sha is not None
                and new_entry.detected_sha is not None
                and existing.detected_sha != new_entry.detected_sha
            )

            if existing.status in ("imported", "excluded"):
                # Preserve import/exclusion metadata, update detection data
                if sha_changed and existing.status == "imported":
                    updated_imports.append(existing.id)

                # Update detection metadata and URLs (URLs may change due to ref fixes)
                existing.detected_sha = new_entry.detected_sha
                existing.confidence_score = new_entry.confidence_score
                existing.raw_score = new_entry.raw_score
                existing.score_breakdown = new_entry.score_breakdown
                existing.detected_at = new_entry.detected_at
                existing.detected_version = new_entry.detected_version
                existing.path_segments = new_entry.path_segments
                existing.upstream_url = (
                    new_entry.upstream_url
                )  # Update URL (may have changed)
                existing.path = new_entry.path  # Update path for consistency
                existing.updated_at = now

                # Update search metadata even for preserved entries
                existing.title = new_entry.title
                existing.description = new_entry.description
                existing.search_tags = new_entry.search_tags
                existing.search_text = new_entry.search_text

                # Preserve: status, import_date, import_id, excluded_at, excluded_reason
                preserved_count += 1
                logger.debug(
                    f"Preserved {existing.status} entry: {existing.id} ({existing.name})"
                    + (f" [SHA changed]" if sha_changed else "")
                )
            else:
                # Full update for non-imported/excluded entries
                existing.artifact_type = new_entry.artifact_type
                existing.name = new_entry.name
                existing.path = new_entry.path
                existing.upstream_url = new_entry.upstream_url
                existing.detected_version = new_entry.detected_version
                existing.detected_sha = new_entry.detected_sha
                existing.detected_at = new_entry.detected_at
                existing.confidence_score = new_entry.confidence_score
                existing.raw_score = new_entry.raw_score
                existing.score_breakdown = new_entry.score_breakdown
                existing.path_segments = new_entry.path_segments
                existing.status = "updated" if existing.status != "new" else "new"
                existing.updated_at = now

                # Update search metadata (frontmatter extraction)
                existing.title = new_entry.title
                existing.description = new_entry.description
                existing.search_tags = new_entry.search_tags
                existing.search_text = new_entry.search_text

                updated_count += 1
                logger.debug(f"Updated entry: {existing.id} ({existing.name})")

        # Insert new entries that weren't matched
        for entry in entries:
            url_matched = entry.upstream_url in matched_urls
            path_matched = entry.path in matched_paths
            type_name_key = f"{entry.artifact_type}:{entry.name}"
            type_name_matched = type_name_key in matched_type_names

            if not url_matched and not path_matched and not type_name_matched:
                # New entry - insert it
                self.session.add(entry)
                inserted_count += 1
                logger.debug(f"Inserted new entry: {entry.id} ({entry.name})")

        logger.info(
            f"Merged catalog entries for source {self.source_id}: "
            f"inserted={inserted_count}, updated={updated_count}, "
            f"preserved={preserved_count}, removed={removed_count}"
        )

        if updated_imports:
            logger.info(
                f"Found {len(updated_imports)} imported entries with SHA changes: "
                f"{updated_imports[:5]}{'...' if len(updated_imports) > 5 else ''}"
            )

        return MergeResult(
            inserted_count=inserted_count,
            updated_count=updated_count,
            preserved_count=preserved_count,
            removed_count=removed_count,
            updated_imports=updated_imports,
        )

    def update_entry_statuses(self, status_updates: Dict[str, str]) -> int:
        """Bulk update entry statuses.

        Updates status for multiple catalog entries efficiently. Useful for
        marking specific entries as updated, removed, etc.

        Args:
            status_updates: Dictionary mapping entry_id -> new_status

        Returns:
            Number of entries updated

        Example:
            >>> status_updates = {
            ...     "entry-1": "updated",
            ...     "entry-2": "removed",
            ...     "entry-3": "updated"
            ... }
            >>> count = ctx.update_entry_statuses(status_updates)
        """
        if not status_updates:
            return 0

        updated_count = 0
        for entry_id, new_status in status_updates.items():
            result = (
                self.session.query(MarketplaceCatalogEntry)
                .filter_by(id=entry_id, source_id=self.source_id)
                .update(
                    {"status": new_status, "updated_at": datetime.utcnow()},
                    synchronize_session=False,
                )
            )
            updated_count += result

        logger.info(
            f"Updated {updated_count} entry statuses for source {self.source_id}"
        )
        return updated_count

    def update_source_counts(
        self,
        counts_by_type: dict,
        clone_target: Optional[Any] = None,
    ) -> None:
        """Update counts_by_type and optionally clone_target on the source row.

        Called after a scan completes to persist artifact-type distribution and
        clone metadata without requiring a separate session query in routers.

        Args:
            counts_by_type: Dict mapping artifact type strings to integer counts.
            clone_target: Optional clone target to persist on the source row.
                When ``None`` the field is left unchanged.

        Example:
            >>> with handler.scan_update_transaction(source_id) as ctx:
            ...     ctx.update_source_status("success", artifact_count=5)
            ...     ctx.update_source_counts({"skill": 3, "command": 2})
        """
        source = (
            self.session.query(MarketplaceSource).filter_by(id=self.source_id).first()
        )
        if source is None:
            logger.warning(
                "update_source_counts: source %s not found, skipping", self.source_id
            )
            return

        source.set_counts_by_type_dict(counts_by_type)
        if clone_target is not None:
            source.clone_target = clone_target
        logger.debug(
            "update_source_counts: updated counts for source %s", self.source_id
        )


class ImportContext:
    """Context for import operations within a transaction.

    Provides helper methods for tracking artifact imports from catalog
    to collection, including status updates and error tracking.

    The session is managed by MarketplaceTransactionHandler - do not close it
    within this context.

    Attributes:
        session: Active SQLAlchemy session
        source_id: ID of the marketplace source (for validation)

    Example:
        >>> # Used within import_transaction context manager
        >>> with handler.import_transaction(source_id) as ctx:
        ...     ctx.mark_imported(["entry-1", "entry-2"], import_id="imp-123")
        ...     ctx.mark_failed(["entry-3"], error="Validation failed")
    """

    def __init__(self, session: Session, source_id: str):
        """Initialize import context.

        Args:
            session: Active SQLAlchemy session
            source_id: ID of the marketplace source
        """
        self.session = session
        self.source_id = source_id

    def mark_imported(self, entry_ids: List[str], import_id: str) -> int:
        """Mark entries as imported with timestamp and import reference.

        Updates status to "imported", sets import_date, and stores the
        import_id in metadata for traceability.

        Args:
            entry_ids: List of catalog entry IDs to mark as imported
            import_id: Unique identifier for this import operation

        Returns:
            Number of entries updated

        Example:
            >>> import_id = str(uuid.uuid4())
            >>> count = ctx.mark_imported(["entry-1", "entry-2"], import_id)
        """
        if not entry_ids:
            return 0

        updated_count = 0
        now = datetime.utcnow()

        for entry_id in entry_ids:
            entry = (
                self.session.query(MarketplaceCatalogEntry)
                .filter_by(id=entry_id, source_id=self.source_id)
                .first()
            )
            if entry:
                entry.import_id = import_id  # Set the actual column
                entry.status = "imported"
                entry.import_date = now
                entry.updated_at = now

                # Store import_id in metadata using the model's helper method
                metadata = entry.get_metadata_dict() or {}
                metadata["import_id"] = import_id
                entry.set_metadata_dict(metadata)

                updated_count += 1

        logger.info(
            f"Marked {updated_count} entries as imported (import_id={import_id})"
        )
        return updated_count

    def mark_failed(self, entry_ids: List[str], error: str) -> int:
        """Mark entries as failed import with error message.

        Stores error information in metadata_json while leaving status
        unchanged. This allows retrying imports without losing the
        original detection status.

        Args:
            entry_ids: List of catalog entry IDs that failed to import
            error: Error message describing the failure

        Returns:
            Number of entries updated

        Example:
            >>> count = ctx.mark_failed(
            ...     ["entry-1"],
            ...     error="Schema validation failed: missing required field"
            ... )
        """
        if not entry_ids:
            return 0

        updated_count = 0
        now = datetime.utcnow()

        for entry_id in entry_ids:
            entry = (
                self.session.query(MarketplaceCatalogEntry)
                .filter_by(id=entry_id, source_id=self.source_id)
                .first()
            )
            if entry:
                # Store error in metadata without changing status using the model's helper method
                metadata = entry.get_metadata_dict() or {}
                metadata["import_error"] = error
                metadata["import_error_at"] = now.isoformat()
                entry.set_metadata_dict(metadata)

                entry.updated_at = now
                updated_count += 1

        logger.warning(f"Marked {updated_count} entries as failed import: {error}")
        return updated_count

    def upsert_composite_memberships(
        self,
        composite_id: str,
        child_artifact_ids: List[str],
        collection_id: str,
    ) -> int:
        """Create or update ``CompositeMembership`` rows within this session.

        For each child artifact ID, looks up the ``Artifact`` row within this
        transaction session and inserts a ``CompositeMembership`` row if one
        does not already exist.  Existing rows are updated to reflect position.

        This method operates within the existing transaction — the caller owns
        commit/rollback.

        Args:
            composite_id: Primary key of the composite
                (``"composite:<name>"``).
            child_artifact_ids: Ordered list of child ``type:name`` IDs.
            collection_id: Collection the composite belongs to.

        Returns:
            Number of new membership rows created.

        Example:
            >>> with handler.import_transaction(source_id) as ctx:
            ...     ctx.upsert_composite_memberships(
            ...         "composite:plugin-x", ["skill:child-one"], "default"
            ...     )
        """
        membership_count = 0
        for idx, child_artifact_id in enumerate(child_artifact_ids):
            artifact_row = (
                self.session.query(Artifact)
                .filter(Artifact.id == child_artifact_id)
                .first()
            )
            if artifact_row is None:
                logger.debug(
                    "upsert_composite_memberships: artifact row not found for '%s', skipping",
                    child_artifact_id,
                )
                continue

            from skillmeat.cache.models import CompositeMembership as _CM

            existing = (
                self.session.query(_CM)
                .filter(
                    _CM.collection_id == collection_id,
                    _CM.composite_id == composite_id,
                    _CM.child_artifact_uuid == artifact_row.uuid,
                )
                .first()
            )
            if existing is None:
                membership = _CM(
                    collection_id=collection_id,
                    composite_id=composite_id,
                    child_artifact_uuid=artifact_row.uuid,
                    relationship_type="contains",
                    pinned_version_hash=None,
                    position=idx,
                )
                self.session.add(membership)
                membership_count += 1
            else:
                existing.position = idx

        logger.debug(
            "upsert_composite_memberships: created %d row(s) for composite '%s'",
            membership_count,
            composite_id,
        )
        return membership_count

    def get_artifact_in_session(self, artifact_id: str) -> Optional[Any]:
        """Return an ``Artifact`` ORM row within this transaction session.

        Used by composite-wiring logic that needs the ORM object to be
        attached to the current session (e.g. for
        ``CompositeService.create_skill_composite_with_session``).

        Args:
            artifact_id: Artifact primary key in ``"type:name"`` format.

        Returns:
            The ``Artifact`` ORM object attached to this session, or ``None``
            if not found.

        Example:
            >>> with handler.import_transaction(source_id) as ctx:
            ...     artifact = ctx.get_artifact_in_session("skill:my-skill")
            ...     if artifact:
            ...         svc.create_skill_composite_with_session(ctx.session, artifact, ...)
        """
        return self.session.query(Artifact).filter(Artifact.id == artifact_id).first()

    def ensure_default_collection(self, collection_id: str, name: str) -> None:
        """Ensure a default collection row exists within this transaction session.

        Idempotent — a no-op if the row already exists.  Called from import
        workflows that need the collection row to be present before inserting
        ``CollectionArtifact`` rows.

        Args:
            collection_id: Primary key of the default collection.
            name: Human-readable name for the collection when creating it.

        Example:
            >>> with handler.import_transaction(source_id) as ctx:
            ...     ctx.ensure_default_collection("default", "Default Collection")
            ...     ctx.mark_imported(entry_ids, import_id)
        """
        from skillmeat.cache.models import Collection

        existing = self.session.query(Collection).filter_by(id=collection_id).first()
        if not existing:
            now = datetime.utcnow()
            default_collection = Collection(
                id=collection_id,
                name=name,
                description="Default collection for all artifacts.",
                created_at=now,
                updated_at=now,
            )
            self.session.add(default_collection)
            logger.info(
                "ensure_default_collection: created collection %r", collection_id
            )


# =============================================================================
# Transaction Handler
# =============================================================================


class MarketplaceTransactionHandler:
    """Coordinates transactional operations across marketplace repositories.

    Use this for operations that need to update both MarketplaceSource and
    MarketplaceCatalogEntry atomically (e.g., after a scan completes).

    This handler ensures that complex multi-table operations either fully
    succeed or fully rollback on error, maintaining database consistency.

    Attributes:
        db_path: Path to SQLite database file
        engine: SQLAlchemy engine for database connections

    Example:
        >>> handler = MarketplaceTransactionHandler()
        >>> with handler.scan_update_transaction(source_id) as ctx:
        ...     ctx.update_source_status("success", artifact_count=5)
        ...     ctx.replace_catalog_entries(new_entries)
        ...     # Automatic commit on success, rollback on error
    """

    def __init__(self, db_path: Optional[str | Path] = None):
        """Initialize transaction handler with database path.

        Args:
            db_path: Optional path to database file (uses default if None)
        """
        # Resolve database path
        if db_path is None:
            self.db_path = Path.home() / ".skillmeat" / "cache" / "cache.db"
        else:
            self.db_path = Path(db_path)

        # Ensure parent directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        # Create engine
        self.engine = create_db_engine(self.db_path)

        # Create tables if they don't exist
        create_tables(self.db_path)

        logger.debug(f"Initialized MarketplaceTransactionHandler: {self.db_path}")

    def _get_session(self) -> Session:
        """Create a new database session using the shared session factory.

        Returns:
            SQLAlchemy Session instance
        """
        from skillmeat.cache.models import get_session

        return get_session(self.db_path)

    @contextmanager
    def scan_update_transaction(
        self, source_id: str
    ) -> Generator[ScanUpdateContext, None, None]:
        """Context manager for updating source and catalog after a scan.

        Provides atomic update of:
        - MarketplaceSource.scan_status, last_sync_at, artifact_count, last_error
        - MarketplaceCatalogEntry bulk delete and recreate

        On error, rolls back all changes. On success, commits all changes.

        Args:
            source_id: The marketplace source being updated

        Yields:
            ScanUpdateContext with helper methods

        Raises:
            RepositoryError: If transaction fails

        Example:
            >>> handler = MarketplaceTransactionHandler()
            >>> with handler.scan_update_transaction("source-123") as ctx:
            ...     # Update source metadata
            ...     ctx.update_source_status("success", artifact_count=10)
            ...
            ...     # Replace catalog entries atomically
            ...     new_entries = scan_repository(source)
            ...     ctx.replace_catalog_entries(new_entries)
            ...
            ...     # Transaction commits automatically on success
        """
        session = self._get_session()
        try:
            logger.debug(f"Starting scan update transaction for source {source_id}")

            # Yield context for operation
            context = ScanUpdateContext(session, source_id)
            yield context

            # Commit on success
            session.commit()
            logger.info(f"Scan update transaction committed for source {source_id}")

        except IntegrityError as e:
            session.rollback()
            logger.error(f"Scan update transaction failed (integrity): {e}")
            raise RepositoryError(
                f"Scan update failed due to integrity constraint: {e}"
            ) from e

        except OperationalError as e:
            session.rollback()
            logger.error(f"Scan update transaction failed (operational): {e}")
            raise RepositoryError(
                f"Scan update failed due to database error: {e}"
            ) from e

        except Exception as e:
            session.rollback()
            logger.error(f"Scan update transaction failed: {e}")
            raise RepositoryError(f"Scan update transaction failed: {e}") from e

        finally:
            session.close()

    @contextmanager
    def import_transaction(
        self, source_id: str
    ) -> Generator[ImportContext, None, None]:
        """Context manager for importing artifacts from catalog to collection.

        Tracks which entries are being imported and updates their status
        atomically. Use this when processing multiple catalog entries
        in a single import operation.

        Args:
            source_id: The marketplace source being imported from

        Yields:
            ImportContext with helper methods

        Raises:
            RepositoryError: If transaction fails

        Example:
            >>> handler = MarketplaceTransactionHandler()
            >>> with handler.import_transaction("source-123") as ctx:
            ...     import_id = str(uuid.uuid4())
            ...
            ...     # Try to import entries
            ...     for entry_id in entries_to_import:
            ...         try:
            ...             import_artifact(entry_id)
            ...             successful_ids.append(entry_id)
            ...         except Exception as e:
            ...             failed_ids.append(entry_id)
            ...
            ...     # Update statuses atomically
            ...     ctx.mark_imported(successful_ids, import_id)
            ...     ctx.mark_failed(failed_ids, str(e))
            ...
            ...     # Transaction commits automatically
        """
        session = self._get_session()
        try:
            logger.debug(f"Starting import transaction for source {source_id}")

            # Yield context for operation
            context = ImportContext(session, source_id)
            yield context

            # Commit on success
            session.commit()
            logger.info(f"Import transaction committed for source {source_id}")

        except IntegrityError as e:
            session.rollback()
            logger.error(f"Import transaction failed (integrity): {e}")
            raise RepositoryError(
                f"Import failed due to integrity constraint: {e}"
            ) from e

        except OperationalError as e:
            session.rollback()
            logger.error(f"Import transaction failed (operational): {e}")
            raise RepositoryError(f"Import failed due to database error: {e}") from e

        except Exception as e:
            session.rollback()
            logger.error(f"Import transaction failed: {e}")
            raise RepositoryError(f"Import transaction failed: {e}") from e

        finally:
            session.close()


# =============================================================================
# MarketplaceSource Repository
# =============================================================================


class MarketplaceSourceRepository(BaseRepository[MarketplaceSource]):
    """Repository for GitHub repository source management.

    Provides CRUD operations for MarketplaceSource entities, which represent
    GitHub repositories that can be scanned for Claude Code artifacts.

    Supported Fields:
        Core fields (required):
            - id, repo_url, owner, repo_name, ref

        User-provided metadata:
            - description: User-provided description (max 500 chars)
            - notes: Internal notes/documentation (max 2000 chars)

        GitHub-fetched metadata:
            - repo_description: Description from GitHub API (max 2000 chars)
            - repo_readme: README content from GitHub (up to 50KB)
            - tags: List of tags for categorization (JSON-serialized)

        Scan results:
            - scan_status: Current scan status
            - artifact_count: Total count of discovered artifacts
            - counts_by_type: Dict mapping artifact type to count (JSON-serialized)
            - last_sync_at, last_error

    Methods:
        - get_by_id: Retrieve source by ID
        - get_by_repo_url: Retrieve source by repository URL (unique)
        - list_all: List all sources
        - create: Create new source (with optional tags/counts_by_type kwargs)
        - update: Update existing source (with optional tags/counts_by_type kwargs)
        - update_fields: Partial update by source_id (convenience method)
        - delete: Delete source (cascade deletes catalog entries)

    Example:
        >>> repo = MarketplaceSourceRepository()
        >>>
        >>> # Create a new source with GitHub metadata
        >>> source = MarketplaceSource(
        ...     id=str(uuid.uuid4()),
        ...     repo_url="https://github.com/anthropics/anthropic-quickstarts",
        ...     owner="anthropics",
        ...     repo_name="anthropic-quickstarts",
        ...     ref="main",
        ...     trust_level="official",
        ...     repo_description="Official Anthropic quickstart examples",
        ...     repo_readme="# Anthropic Quickstarts\n\n...",
        ... )
        >>> created = repo.create(
        ...     source,
        ...     tags=["official", "anthropic"],
        ...     counts_by_type={"skill": 5},
        ... )
        >>>
        >>> # Find by URL
        >>> found = repo.get_by_repo_url("https://github.com/anthropics/anthropic-quickstarts")
        >>>
        >>> # Partial update with update_fields
        >>> updated = repo.update_fields(
        ...     found.id,
        ...     scan_status="success",
        ...     artifact_count=10,
        ...     counts_by_type={"skill": 7, "command": 3},
        ... )
    """

    def __init__(self, db_path: Optional[str | Path] = None):
        """Initialize MarketplaceSource repository.

        Args:
            db_path: Optional path to database file
        """
        super().__init__(db_path, MarketplaceSource)

    def get_by_id(self, source_id: str) -> Optional[MarketplaceSource]:
        """Retrieve marketplace source by ID.

        Args:
            source_id: Unique source identifier

        Returns:
            MarketplaceSource instance or None if not found
        """
        session = self._get_session()
        try:
            return session.query(MarketplaceSource).filter_by(id=source_id).first()
        finally:
            session.close()

    def get_by_repo_url(self, repo_url: str) -> Optional[MarketplaceSource]:
        """Retrieve marketplace source by repository URL.

        Repository URLs are unique per source. This is the primary lookup
        method for checking if a source already exists.

        Args:
            repo_url: Full GitHub repository URL

        Returns:
            MarketplaceSource instance or None if not found

        Example:
            >>> source = repo.get_by_repo_url("https://github.com/user/repo")
        """
        session = self._get_session()
        try:
            return session.query(MarketplaceSource).filter_by(repo_url=repo_url).first()
        finally:
            session.close()

    def list_all(self) -> List[MarketplaceSource]:
        """List all marketplace sources.

        Returns:
            List of all MarketplaceSource instances

        Note:
            Single-user architecture - no scoping applied.
            For multi-tenancy, add user_id parameter and filter.
        """
        session = self._get_session()
        try:
            return session.query(MarketplaceSource).all()
        finally:
            session.close()

    def create(
        self,
        source: MarketplaceSource,
        *,
        tags: Optional[List[str]] = None,
        counts_by_type: Optional[Dict[str, int]] = None,
    ) -> MarketplaceSource:
        """Create a new marketplace source.

        Args:
            source: MarketplaceSource instance to create. Can include:
                - repo_description: Description fetched from GitHub API
                - repo_readme: README content from GitHub
                - tags: Will be overridden if tags kwarg is provided
                - counts_by_type: Will be overridden if counts_by_type kwarg is provided
            tags: Optional list of tags (serialized via set_tags_list())
            counts_by_type: Optional dict mapping artifact type to count
                (serialized via set_counts_by_type_dict())

        Returns:
            Created MarketplaceSource instance

        Raises:
            ConstraintError: If repo_url already exists (unique constraint)

        Example:
            >>> source = MarketplaceSource(
            ...     id=str(uuid.uuid4()),
            ...     repo_url="https://github.com/user/repo",
            ...     owner="user",
            ...     repo_name="repo",
            ...     repo_description="A great repo for Claude artifacts",
            ...     repo_readme="# My Repo\n\nThis repo contains...",
            ... )
            >>> created = repo.create(
            ...     source,
            ...     tags=["productivity", "coding"],
            ...     counts_by_type={"skill": 5, "command": 2},
            ... )
        """
        # Apply serialized fields if provided as kwargs
        if tags is not None:
            source.set_tags_list(tags)
        if counts_by_type is not None:
            source.set_counts_by_type_dict(counts_by_type)

        session = self._get_session()
        try:
            session.add(source)
            session.commit()
            session.refresh(source)
            logger.info(f"Created marketplace source: {source.id} ({source.repo_url})")
            return source
        except IntegrityError as e:
            session.rollback()
            raise ConstraintError(f"Source with repo_url already exists: {e}") from e
        finally:
            session.close()

    def update(
        self,
        source: MarketplaceSource,
        *,
        tags: Optional[List[str]] = None,
        counts_by_type: Optional[Dict[str, int]] = None,
    ) -> MarketplaceSource:
        """Update an existing marketplace source.

        Args:
            source: MarketplaceSource instance with updated values. Can include:
                - repo_description: Description fetched from GitHub API
                - repo_readme: README content from GitHub
                - tags: Will be overridden if tags kwarg is provided
                - counts_by_type: Will be overridden if counts_by_type kwarg is provided
            tags: Optional list of tags to set (serialized via set_tags_list())
            counts_by_type: Optional dict mapping artifact type to count
                (serialized via set_counts_by_type_dict())

        Returns:
            Updated MarketplaceSource instance

        Raises:
            NotFoundError: If source does not exist

        Example:
            >>> source = repo.get_by_id("source-123")
            >>> source.scan_status = "success"
            >>> source.artifact_count = 5
            >>> source.repo_description = "Updated description from GitHub"
            >>> updated = repo.update(
            ...     source,
            ...     tags=["updated", "verified"],
            ...     counts_by_type={"skill": 10, "command": 3},
            ... )
        """
        # Apply serialized fields if provided as kwargs
        if tags is not None:
            source.set_tags_list(tags)
        if counts_by_type is not None:
            source.set_counts_by_type_dict(counts_by_type)

        session = self._get_session()
        try:
            # Ensure entity exists
            existing = session.query(MarketplaceSource).filter_by(id=source.id).first()
            if not existing:
                raise NotFoundError(f"Source not found: {source.id}")

            # Merge changes and get the merged instance
            merged = session.merge(source)
            session.commit()
            session.refresh(merged)
            logger.info(f"Updated marketplace source: {source.id}")
            return merged
        finally:
            session.close()

    def delete(self, source_id: str) -> bool:
        """Delete a marketplace source.

        This performs a hard delete (actually removes from database).
        Cascade deletes all associated catalog entries.

        Args:
            source_id: Unique source identifier

        Returns:
            True if deleted, False if not found

        Example:
            >>> deleted = repo.delete("source-123")
        """
        session = self._get_session()
        try:
            source = session.query(MarketplaceSource).filter_by(id=source_id).first()
            if not source:
                return False

            session.delete(source)
            session.commit()
            logger.info(f"Deleted marketplace source: {source_id}")
            return True
        finally:
            session.close()

    def update_fields(
        self,
        source_id: str,
        *,
        repo_description: Optional[str] = None,
        repo_readme: Optional[str] = None,
        tags: Optional[List[str]] = None,
        counts_by_type: Optional[Dict[str, int]] = None,
        description: Optional[str] = None,
        notes: Optional[str] = None,
        scan_status: Optional[str] = None,
        artifact_count: Optional[int] = None,
        last_sync_at: Optional[datetime] = None,
        last_error: Optional[str] = None,
    ) -> MarketplaceSource:
        """Update specific fields on a marketplace source without full ORM object.

        This is a convenience method for partial updates. Only provided fields
        are updated; None values are ignored (not set to NULL).

        Args:
            source_id: Unique source identifier
            repo_description: Description fetched from GitHub API (max 2000 chars)
            repo_readme: README content from GitHub (up to 50KB)
            tags: List of tags for categorization (serialized to JSON)
            counts_by_type: Dict mapping artifact type to count (serialized to JSON)
            description: User-provided description (max 500 chars)
            notes: Internal notes/documentation (max 2000 chars)
            scan_status: Scan status ("pending", "scanning", "success", "error")
            artifact_count: Cached count of discovered artifacts
            last_sync_at: Timestamp of last successful scan
            last_error: Last error message if scan failed

        Returns:
            Updated MarketplaceSource instance

        Raises:
            NotFoundError: If source does not exist

        Example:
            >>> # Update GitHub metadata after fetching from API
            >>> updated = repo.update_fields(
            ...     "source-123",
            ...     repo_description="Official Claude Code skills repository",
            ...     repo_readme="# Anthropic Skills\n\nThis repo contains...",
            ...     tags=["official", "anthropic", "skills"],
            ... )
            >>>
            >>> # Update after successful scan
            >>> updated = repo.update_fields(
            ...     "source-123",
            ...     scan_status="success",
            ...     artifact_count=15,
            ...     counts_by_type={"skill": 10, "command": 3, "agent": 2},
            ...     last_sync_at=datetime.utcnow(),
            ... )
        """
        session = self._get_session()
        try:
            source = session.query(MarketplaceSource).filter_by(id=source_id).first()
            if not source:
                raise NotFoundError(f"Source not found: {source_id}")

            # Update simple fields if provided
            if repo_description is not None:
                source.repo_description = repo_description
            if repo_readme is not None:
                source.repo_readme = repo_readme
            if description is not None:
                source.description = description
            if notes is not None:
                source.notes = notes
            if scan_status is not None:
                source.scan_status = scan_status
            if artifact_count is not None:
                source.artifact_count = artifact_count
            if last_sync_at is not None:
                source.last_sync_at = last_sync_at
            if last_error is not None:
                source.last_error = last_error

            # Update JSON-serialized fields using helper methods
            if tags is not None:
                source.set_tags_list(tags)
            if counts_by_type is not None:
                source.set_counts_by_type_dict(counts_by_type)

            session.commit()
            session.refresh(source)
            logger.info(f"Updated fields on marketplace source: {source_id}")
            return source
        finally:
            session.close()

    # =========================================================================
    # REPO-001: Enhanced Query Methods
    # =========================================================================

    def list_paginated(
        self, limit: int = 50, cursor: Optional[str] = None
    ) -> PaginatedResult[MarketplaceSource]:
        """List marketplace sources with cursor-based pagination.

        Uses ID-based cursor pagination for stable, efficient paging through
        large result sets without the performance penalty of OFFSET.

        Args:
            limit: Maximum number of items per page (default: 50)
            cursor: Cursor from previous page (None for first page)

        Returns:
            PaginatedResult with items, next_cursor, and has_more flag

        Example:
            >>> # First page
            >>> result = repo.list_paginated(limit=50)
            >>> for source in result.items:
            ...     print(source.repo_url)
            >>>
            >>> # Next page
            >>> if result.has_more:
            ...     next_result = repo.list_paginated(limit=50, cursor=result.next_cursor)
        """
        session = self._get_session()
        try:
            query = session.query(MarketplaceSource)

            # Apply cursor filter if provided
            if cursor:
                query = query.filter(MarketplaceSource.id > cursor)

            # Order by ID for stable pagination
            query = query.order_by(MarketplaceSource.id)

            # Fetch limit + 1 to check if more items exist
            items = query.limit(limit + 1).all()

            # Determine if more items exist
            has_more = len(items) > limit
            if has_more:
                items = items[:limit]

            # Generate next cursor from last item's ID
            next_cursor = items[-1].id if items and has_more else None

            logger.debug(
                f"Listed {len(items)} sources (cursor={cursor}, has_more={has_more})"
            )

            return PaginatedResult(
                items=items,
                next_cursor=next_cursor,
                has_more=has_more,
            )
        finally:
            session.close()

    def list_by_scan_status(self, status: str) -> List[MarketplaceSource]:
        """List marketplace sources by scan status.

        Args:
            status: Scan status filter ("pending", "scanning", "success", "error")

        Returns:
            List of MarketplaceSource instances with matching status

        Example:
            >>> # Find all sources that failed to scan
            >>> failed = repo.list_by_scan_status("error")
            >>> for source in failed:
            ...     print(f"{source.repo_url}: {source.last_error}")
        """
        session = self._get_session()
        try:
            sources = (
                session.query(MarketplaceSource)
                .filter_by(scan_status=status)
                .order_by(MarketplaceSource.updated_at.desc())
                .all()
            )
            logger.debug(f"Found {len(sources)} sources with status '{status}'")
            return sources
        finally:
            session.close()

    def list_needs_rescan(self, hours: int = 24) -> List[MarketplaceSource]:
        """List marketplace sources that need rescanning.

        Identifies sources that haven't been successfully scanned in the
        specified time period, useful for periodic refresh jobs.

        Args:
            hours: Time threshold in hours (default: 24)

        Returns:
            List of MarketplaceSource instances needing rescan

        Example:
            >>> # Find sources not scanned in 48 hours
            >>> stale = repo.list_needs_rescan(hours=48)
            >>> for source in stale:
            ...     print(f"Rescan needed: {source.repo_url}")
        """
        session = self._get_session()
        try:
            threshold = datetime.utcnow() - timedelta(hours=hours)

            # Sources that need rescanning are those where:
            # 1. Never synced (last_sync_at is NULL), OR
            # 2. Last sync older than threshold, OR
            # 3. Last scan resulted in error
            sources = (
                session.query(MarketplaceSource)
                .filter(
                    or_(
                        MarketplaceSource.last_sync_at.is_(None),
                        MarketplaceSource.last_sync_at < threshold,
                        MarketplaceSource.scan_status == "error",
                    )
                )
                .order_by(
                    MarketplaceSource.last_sync_at.asc().nullsfirst()
                )  # Never-scanned first
                .all()
            )

            logger.debug(
                f"Found {len(sources)} sources needing rescan "
                f"(threshold: {hours} hours)"
            )
            return sources
        finally:
            session.close()

    def upsert(self, source: MarketplaceSource) -> MarketplaceSource:
        """Create or update a marketplace source by repo_url.

        Performs an upsert operation: creates if doesn't exist, updates if it does.
        Uses repo_url as the unique identifier for matching.

        Args:
            source: MarketplaceSource instance to create or update

        Returns:
            Created or updated MarketplaceSource instance

        Example:
            >>> source = MarketplaceSource(
            ...     id=str(uuid.uuid4()),
            ...     repo_url="https://github.com/user/repo",
            ...     owner="user",
            ...     repo_name="repo",
            ...     trust_level="basic",
            ... )
            >>> result = repo.upsert(source)
            >>> # If exists, updates; if new, creates
        """
        session = self._get_session()
        try:
            # Check if source exists by repo_url
            existing = (
                session.query(MarketplaceSource)
                .filter_by(repo_url=source.repo_url)
                .first()
            )

            if existing:
                # Update existing source (preserve ID)
                source.id = existing.id
                merged = session.merge(source)
                session.commit()
                session.refresh(merged)
                logger.info(
                    f"Updated marketplace source: {merged.id} ({merged.repo_url})"
                )
                return merged
            else:
                # Create new source
                session.add(source)
                session.commit()
                session.refresh(source)
                logger.info(
                    f"Created marketplace source: {source.id} ({source.repo_url})"
                )
                return source
        except IntegrityError as e:
            session.rollback()
            raise ConstraintError(f"Upsert failed due to constraint: {e}") from e
        finally:
            session.close()


# =============================================================================
# MarketplaceCatalog Repository
# =============================================================================


class MarketplaceCatalogRepository(BaseRepository[MarketplaceCatalogEntry]):
    """Repository for discovered artifact management.

    Provides CRUD and query operations for MarketplaceCatalogEntry entities,
    which represent artifacts detected during GitHub repository scanning.

    Methods:
        - get_by_id: Retrieve entry by ID
        - list_by_source: List entries from a specific source
        - list_by_status: List entries with a specific status
        - find_by_upstream_url: Find entry by upstream URL (deduplication)
        - bulk_create: Efficiently create multiple entries
        - update_status: Update entry import status

    Example:
        >>> repo = MarketplaceCatalogRepository()
        >>>
        >>> # List all new artifacts from a source
        >>> new_artifacts = repo.list_by_source("source-123")
        >>>
        >>> # Bulk create entries
        >>> entries = [entry1, entry2, entry3]
        >>> created = repo.bulk_create(entries)
        >>>
        >>> # Mark as imported
        >>> repo.update_status(entry.id, "imported")
    """

    def __init__(self, db_path: Optional[str | Path] = None):
        """Initialize MarketplaceCatalog repository.

        Args:
            db_path: Optional path to database file
        """
        super().__init__(db_path, MarketplaceCatalogEntry)

    def get_by_id(self, entry_id: str) -> Optional[MarketplaceCatalogEntry]:
        """Retrieve catalog entry by ID.

        Args:
            entry_id: Unique catalog entry identifier

        Returns:
            MarketplaceCatalogEntry instance or None if not found
        """
        session = self._get_session()
        try:
            return session.query(MarketplaceCatalogEntry).filter_by(id=entry_id).first()
        finally:
            session.close()

    def list_by_source(self, source_id: str) -> List[MarketplaceCatalogEntry]:
        """List all catalog entries from a specific source.

        Args:
            source_id: Marketplace source identifier

        Returns:
            List of MarketplaceCatalogEntry instances

        Example:
            >>> entries = repo.list_by_source("source-123")
            >>> for entry in entries:
            ...     print(f"{entry.name} ({entry.artifact_type}): {entry.status}")
        """
        session = self._get_session()
        try:
            return (
                session.query(MarketplaceCatalogEntry)
                .filter_by(source_id=source_id)
                .all()
            )
        finally:
            session.close()

    def list_by_status(self, status: str) -> List[MarketplaceCatalogEntry]:
        """List all catalog entries with a specific status.

        Args:
            status: Import status ("new", "updated", "removed", "imported")

        Returns:
            List of MarketplaceCatalogEntry instances

        Example:
            >>> # Find all new artifacts not yet imported
            >>> new_entries = repo.list_by_status("new")
        """
        session = self._get_session()
        try:
            return session.query(MarketplaceCatalogEntry).filter_by(status=status).all()
        finally:
            session.close()

    def find_by_upstream_url(self, url: str) -> Optional[MarketplaceCatalogEntry]:
        """Find catalog entry by upstream URL.

        Used for deduplication - check if an artifact URL has already been
        discovered before creating a new catalog entry.

        Args:
            url: Full URL to artifact in repository

        Returns:
            MarketplaceCatalogEntry instance or None if not found

        Example:
            >>> existing = repo.find_by_upstream_url(
            ...     "https://github.com/user/repo/blob/main/skills/my-skill"
            ... )
            >>> if existing:
            ...     print("Already cataloged!")
        """
        session = self._get_session()
        try:
            return (
                session.query(MarketplaceCatalogEntry)
                .filter_by(upstream_url=url)
                .first()
            )
        finally:
            session.close()

    def bulk_create(
        self, entries: List[MarketplaceCatalogEntry]
    ) -> List[MarketplaceCatalogEntry]:
        """Create multiple catalog entries efficiently.

        Uses bulk insert for performance when creating many entries at once
        (e.g., after scanning a large repository).

        Args:
            entries: List of MarketplaceCatalogEntry instances to create

        Returns:
            List of created MarketplaceCatalogEntry instances

        Raises:
            RepositoryError: If bulk insert fails

        Example:
            >>> entries = [
            ...     MarketplaceCatalogEntry(id=str(uuid.uuid4()), ...),
            ...     MarketplaceCatalogEntry(id=str(uuid.uuid4()), ...),
            ... ]
            >>> created = repo.bulk_create(entries)
        """
        if not entries:
            return []

        session = self._get_session()
        try:
            session.bulk_save_objects(entries)
            session.commit()
            logger.info(f"Bulk created {len(entries)} catalog entries")
            return entries
        except Exception as e:
            session.rollback()
            raise RepositoryError(f"Bulk create failed: {e}") from e
        finally:
            session.close()

    def update_status(self, entry_id: str, status: str) -> bool:
        """Update catalog entry import status.

        Args:
            entry_id: Unique catalog entry identifier
            status: New status ("new", "updated", "removed", "imported")

        Returns:
            True if updated, False if not found

        Example:
            >>> # Mark entry as imported
            >>> repo.update_status("entry-123", "imported")
        """
        session = self._get_session()
        try:
            entry = (
                session.query(MarketplaceCatalogEntry).filter_by(id=entry_id).first()
            )
            if not entry:
                return False

            entry.status = status
            if status == "imported":
                entry.import_date = datetime.utcnow()

            session.commit()
            logger.info(f"Updated catalog entry status: {entry_id} -> {status}")
            return True
        finally:
            session.close()

    def reset_import_status(
        self, entry_id: str, source_id: str
    ) -> Optional[MarketplaceCatalogEntry]:
        """Reset a catalog entry's import status to allow re-import.

        Sets status back to 'new', clears import_date, and removes import_id
        from metadata. This allows an artifact to be re-imported after deletion.

        Args:
            entry_id: Unique catalog entry identifier
            source_id: Source ID for validation

        Returns:
            Updated MarketplaceCatalogEntry if found and reset, None if not found

        Example:
            >>> # Reset entry to allow re-import
            >>> entry = repo.reset_import_status("entry-123", "source-456")
            >>> if entry:
            ...     print(f"Entry {entry.name} reset to status: {entry.status}")
        """
        session = self._get_session()
        try:
            entry = (
                session.query(MarketplaceCatalogEntry)
                .filter_by(id=entry_id, source_id=source_id)
                .first()
            )
            if not entry:
                logger.warning(
                    f"Catalog entry not found for reset: {entry_id} (source: {source_id})"
                )
                return None

            # Reset status to 'new'
            entry.status = "new"
            entry.import_date = None
            entry.updated_at = datetime.utcnow()

            # Remove import_id from metadata
            metadata = entry.get_metadata_dict() or {}
            if "import_id" in metadata:
                del metadata["import_id"]
            entry.set_metadata_dict(metadata)

            session.commit()
            session.refresh(entry)
            logger.info(f"Reset catalog entry import status: {entry_id} -> new")
            return entry
        except Exception as e:
            session.rollback()
            logger.error(f"Failed to reset import status for {entry_id}: {e}")
            raise
        finally:
            session.close()

    def find_by_import_id(self, import_id: str) -> Optional[MarketplaceCatalogEntry]:
        """Find catalog entry by import_id in metadata.

        Useful for finding the catalog entry linked to an imported artifact.

        Args:
            import_id: Import ID stored in metadata

        Returns:
            MarketplaceCatalogEntry if found, None otherwise

        Example:
            >>> entry = repo.find_by_import_id("imp-abc-123")
        """
        session = self._get_session()
        try:
            # Search for entries where metadata contains the import_id
            # Since metadata is JSON, we use LIKE for SQLite compatibility
            entries = (
                session.query(MarketplaceCatalogEntry)
                .filter(
                    MarketplaceCatalogEntry.status == "imported",
                    MarketplaceCatalogEntry.metadata_json.like(
                        f'%"import_id": "{import_id}"%'
                    ),
                )
                .all()
            )

            # Verify the match by parsing metadata
            for entry in entries:
                metadata = entry.get_metadata_dict() or {}
                if metadata.get("import_id") == import_id:
                    return entry

            return None
        finally:
            session.close()

    def list_artifact_ids_by_import_id(self, import_id: str) -> set[str]:
        """Return the set of ``type:name`` artifact IDs for a given import batch.

        Queries the ``import_id`` column on ``MarketplaceCatalogEntry`` and
        returns a set of ``"artifact_type:name"`` strings for all matching rows.

        Args:
            import_id: Unique identifier of the import batch operation.

        Returns:
            Set of ``"artifact_type:name"`` strings; empty when no entries
            match.
        """
        session = self._get_session()
        try:
            rows = (
                session.query(
                    MarketplaceCatalogEntry.artifact_type,
                    MarketplaceCatalogEntry.name,
                )
                .filter(MarketplaceCatalogEntry.import_id == import_id)
                .all()
            )
            return {f"{row.artifact_type}:{row.name}" for row in rows}
        finally:
            session.close()

    def find_by_artifact_name_and_type(
        self, name: str, artifact_type: str, source_id: Optional[str] = None
    ) -> Optional[MarketplaceCatalogEntry]:
        """Find catalog entry by artifact name and type.

        Useful for finding the catalog entry that matches an artifact
        being deleted from the collection.

        Args:
            name: Artifact name
            artifact_type: Artifact type (skill, command, agent, etc.)
            source_id: Optional source ID to filter by

        Returns:
            MarketplaceCatalogEntry if found, None otherwise
        """
        session = self._get_session()
        try:
            query = session.query(MarketplaceCatalogEntry).filter(
                MarketplaceCatalogEntry.name == name,
                MarketplaceCatalogEntry.artifact_type == artifact_type,
                MarketplaceCatalogEntry.status == "imported",
            )
            if source_id:
                query = query.filter(MarketplaceCatalogEntry.source_id == source_id)

            return query.first()
        finally:
            session.close()

    # =========================================================================
    # REPO-002: Enhanced Query Methods
    # =========================================================================

    def list_paginated(
        self,
        source_id: Optional[str] = None,
        status: Optional[str] = None,
        artifact_type: Optional[str] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> PaginatedResult[MarketplaceCatalogEntry]:
        """List catalog entries with cursor-based pagination and filtering.

        Uses ID-based cursor pagination for efficient querying. Supports
        optional filtering by source, status, and artifact type.

        Args:
            source_id: Optional source ID filter
            status: Optional status filter ("new", "updated", "removed", "imported")
            artifact_type: Optional artifact type filter
            limit: Maximum number of items per page (default: 50)
            cursor: Cursor from previous page (None for first page)

        Returns:
            PaginatedResult with items, next_cursor, and has_more flag

        Example:
            >>> # List all new skills
            >>> result = repo.list_paginated(
            ...     status="new",
            ...     artifact_type="skill",
            ...     limit=50
            ... )
            >>>
            >>> # Next page
            >>> if result.has_more:
            ...     next_result = repo.list_paginated(
            ...         status="new",
            ...         artifact_type="skill",
            ...         limit=50,
            ...         cursor=result.next_cursor
            ...     )
        """
        session = self._get_session()
        try:
            query = session.query(MarketplaceCatalogEntry)

            # Apply filters
            if source_id:
                query = query.filter_by(source_id=source_id)
            if status:
                query = query.filter_by(status=status)
            if artifact_type:
                query = query.filter_by(artifact_type=artifact_type)

            # Apply cursor filter if provided
            if cursor:
                query = query.filter(MarketplaceCatalogEntry.id > cursor)

            # Order by ID for stable pagination
            query = query.order_by(MarketplaceCatalogEntry.id)

            # Fetch limit + 1 to check if more items exist
            items = query.limit(limit + 1).all()

            # Determine if more items exist
            has_more = len(items) > limit
            if has_more:
                items = items[:limit]

            # Generate next cursor from last item's ID
            next_cursor = items[-1].id if items and has_more else None

            logger.debug(
                f"Listed {len(items)} catalog entries "
                f"(source_id={source_id}, status={status}, "
                f"type={artifact_type}, cursor={cursor}, has_more={has_more})"
            )

            return PaginatedResult(
                items=items,
                next_cursor=next_cursor,
                has_more=has_more,
            )
        finally:
            session.close()

    def list_by_source_and_status(
        self, source_id: str, status: str
    ) -> List[MarketplaceCatalogEntry]:
        """List catalog entries by source and status.

        Args:
            source_id: Marketplace source identifier
            status: Import status filter

        Returns:
            List of MarketplaceCatalogEntry instances

        Example:
            >>> # Find all new artifacts from a specific source
            >>> new_entries = repo.list_by_source_and_status("source-123", "new")
        """
        session = self._get_session()
        try:
            entries = (
                session.query(MarketplaceCatalogEntry)
                .filter_by(source_id=source_id, status=status)
                .order_by(MarketplaceCatalogEntry.detected_at.desc())
                .all()
            )
            logger.debug(
                f"Found {len(entries)} entries for source {source_id} "
                f"with status '{status}'"
            )
            return entries
        finally:
            session.close()

    def list_by_type(self, artifact_type: str) -> List[MarketplaceCatalogEntry]:
        """List catalog entries by artifact type.

        Args:
            artifact_type: Artifact type filter ("skill", "command", etc.)

        Returns:
            List of MarketplaceCatalogEntry instances

        Example:
            >>> # Find all detected skills
            >>> skills = repo.list_by_type("skill")
        """
        session = self._get_session()
        try:
            entries = (
                session.query(MarketplaceCatalogEntry)
                .filter_by(artifact_type=artifact_type)
                .order_by(MarketplaceCatalogEntry.detected_at.desc())
                .all()
            )
            logger.debug(f"Found {len(entries)} entries of type '{artifact_type}'")
            return entries
        finally:
            session.close()

    def filter_by_confidence_range(
        self, min_score: int, max_score: int = 100
    ) -> List[MarketplaceCatalogEntry]:
        """Filter catalog entries by confidence score range.

        Args:
            min_score: Minimum confidence score (inclusive, 0-100)
            max_score: Maximum confidence score (inclusive, 0-100, default: 100)

        Returns:
            List of MarketplaceCatalogEntry instances within score range

        Example:
            >>> # Find high-confidence detections only
            >>> high_confidence = repo.filter_by_confidence_range(min_score=80)
            >>>
            >>> # Find medium-confidence detections
            >>> medium = repo.filter_by_confidence_range(min_score=50, max_score=79)
        """
        session = self._get_session()
        try:
            entries = (
                session.query(MarketplaceCatalogEntry)
                .filter(
                    and_(
                        MarketplaceCatalogEntry.confidence_score >= min_score,
                        MarketplaceCatalogEntry.confidence_score <= max_score,
                    )
                )
                .order_by(
                    MarketplaceCatalogEntry.confidence_score.desc(),
                    MarketplaceCatalogEntry.detected_at.desc(),
                )
                .all()
            )
            logger.debug(
                f"Found {len(entries)} entries with confidence "
                f"between {min_score} and {max_score}"
            )
            return entries
        finally:
            session.close()

    def find_duplicates_by_type_and_name(
        self, artifact_type: str, name: str
    ) -> List[MarketplaceCatalogEntry]:
        """Find duplicate catalog entries by type and name.

        Useful for deduplication - identifies multiple detections of the
        same artifact across different sources or paths.

        Args:
            artifact_type: Artifact type to search
            name: Artifact name to search

        Returns:
            List of MarketplaceCatalogEntry instances with matching type and name

        Example:
            >>> # Check for duplicates before adding
            >>> duplicates = repo.find_duplicates_by_type_and_name("skill", "canvas")
            >>> if len(duplicates) > 1:
            ...     print(f"Found {len(duplicates)} versions of canvas skill")
        """
        session = self._get_session()
        try:
            entries = (
                session.query(MarketplaceCatalogEntry)
                .filter_by(artifact_type=artifact_type, name=name)
                .order_by(
                    MarketplaceCatalogEntry.confidence_score.desc(),
                    MarketplaceCatalogEntry.detected_at.desc(),
                )
                .all()
            )
            logger.debug(
                f"Found {len(entries)} entries matching "
                f"type='{artifact_type}', name='{name}'"
            )
            return entries
        finally:
            session.close()

    def bulk_update_status(self, entry_ids: List[str], status: str) -> int:
        """Bulk update status for multiple catalog entries.

        Uses efficient SQL UPDATE to modify multiple entries in one query.
        Sets import_date if status is "imported".

        Args:
            entry_ids: List of catalog entry IDs to update
            status: New status to set

        Returns:
            Number of entries updated

        Example:
            >>> # Mark multiple entries as imported
            >>> entry_ids = ["entry-1", "entry-2", "entry-3"]
            >>> count = repo.bulk_update_status(entry_ids, "imported")
            >>> print(f"Updated {count} entries")
        """
        if not entry_ids:
            return 0

        session = self._get_session()
        try:
            # Build update values
            update_values = {"status": status, "updated_at": datetime.utcnow()}
            if status == "imported":
                update_values["import_date"] = datetime.utcnow()

            # Execute bulk update
            result = (
                session.query(MarketplaceCatalogEntry)
                .filter(MarketplaceCatalogEntry.id.in_(entry_ids))
                .update(update_values, synchronize_session=False)
            )

            session.commit()
            logger.info(f"Bulk updated {result} catalog entries to status '{status}'")
            return result
        except Exception as e:
            session.rollback()
            raise RepositoryError(f"Bulk update failed: {e}") from e
        finally:
            session.close()

    def delete_by_source(self, source_id: str) -> int:
        """Delete all catalog entries for a specific source.

        Args:
            source_id: Marketplace source identifier

        Returns:
            Number of entries deleted

        Example:
            >>> # Clean up entries when removing a source
            >>> count = repo.delete_by_source("source-123")
            >>> print(f"Deleted {count} entries")
        """
        session = self._get_session()
        try:
            result = (
                session.query(MarketplaceCatalogEntry)
                .filter_by(source_id=source_id)
                .delete(synchronize_session=False)
            )

            session.commit()
            logger.info(f"Deleted {result} catalog entries for source {source_id}")
            return result
        except Exception as e:
            session.rollback()
            raise RepositoryError(f"Bulk delete failed: {e}") from e
        finally:
            session.close()

    # =========================================================================
    # REPO-003: Complex Filtering and Joins
    # =========================================================================

    def get_source_catalog(
        self,
        source_id: str,
        artifact_types: Optional[List[str]] = None,
        statuses: Optional[List[str]] = None,
        min_confidence: Optional[int] = None,
        max_confidence: Optional[int] = None,
    ) -> List[MarketplaceCatalogEntry]:
        """Get catalog entries for a source with optional filtering.

        Provides flexible filtering for querying a source's catalog with
        multiple criteria applied simultaneously.

        Args:
            source_id: Marketplace source ID
            artifact_types: Filter by types (e.g., ["skill", "command"])
            statuses: Filter by statuses (e.g., ["new", "updated"])
            min_confidence: Minimum confidence score (0-100)
            max_confidence: Maximum confidence score (0-100)

        Returns:
            List of matching catalog entries ordered by detection date

        Example:
            >>> # Get all high-confidence skills that are new or updated
            >>> entries = repo.get_source_catalog(
            ...     source_id="source-123",
            ...     artifact_types=["skill"],
            ...     statuses=["new", "updated"],
            ...     min_confidence=80
            ... )
            >>> for entry in entries:
            ...     print(f"{entry.name}: {entry.confidence_score}%")
        """
        session = self._get_session()
        try:
            query = session.query(MarketplaceCatalogEntry).filter_by(
                source_id=source_id
            )

            # Apply artifact type filter
            if artifact_types:
                query = query.filter(
                    MarketplaceCatalogEntry.artifact_type.in_(artifact_types)
                )

            # Apply status filter
            if statuses:
                query = query.filter(MarketplaceCatalogEntry.status.in_(statuses))

            # Apply confidence range filters
            if min_confidence is not None:
                query = query.filter(
                    MarketplaceCatalogEntry.confidence_score >= min_confidence
                )
            if max_confidence is not None:
                query = query.filter(
                    MarketplaceCatalogEntry.confidence_score <= max_confidence
                )

            # Order by detection date (most recent first)
            entries = query.order_by(MarketplaceCatalogEntry.detected_at.desc()).all()

            logger.debug(
                f"Found {len(entries)} catalog entries for source {source_id} "
                f"with filters (types={artifact_types}, statuses={statuses}, "
                f"confidence={min_confidence}-{max_confidence})"
            )
            return entries
        finally:
            session.close()

    def compare_catalogs(
        self,
        source_id: str,
        new_entries: List[Dict[str, Any]],
    ) -> CatalogDiff:
        """Compare existing catalog with new scan results.

        Identifies changes between current catalog and new scan results by
        comparing upstream URLs and detected SHAs. This enables efficient
        incremental updates when rescanning a source.

        Comparison logic:
        - new: entries in new_entries but not in DB (by upstream_url)
        - updated: entries with same upstream_url but different detected_sha
        - removed: entries in DB but not in new_entries
        - unchanged: entries with matching upstream_url and detected_sha

        Args:
            source_id: Marketplace source ID
            new_entries: List of dicts with keys:
                - upstream_url (str): Full URL to artifact
                - artifact_type (str): Type of artifact
                - name (str): Artifact name
                - detected_sha (str): Git SHA of detected artifact

        Returns:
            CatalogDiff with categorized changes

        Example:
            >>> # After scanning a repository
            >>> new_entries = [
            ...     {
            ...         "upstream_url": "https://github.com/user/repo/blob/main/skills/skill1",
            ...         "artifact_type": "skill",
            ...         "name": "skill1",
            ...         "detected_sha": "abc123"
            ...     },
            ... ]
            >>> diff = repo.compare_catalogs("source-123", new_entries)
            >>> print(f"New: {len(diff.new)}, Updated: {len(diff.updated)}, "
            ...       f"Removed: {len(diff.removed)}")
        """
        session = self._get_session()
        try:
            # Fetch all existing entries for this source
            existing_entries = (
                session.query(MarketplaceCatalogEntry)
                .filter_by(source_id=source_id)
                .all()
            )

            # Build lookup maps
            existing_by_url: Dict[str, MarketplaceCatalogEntry] = {
                entry.upstream_url: entry for entry in existing_entries
            }
            new_urls = {entry["upstream_url"] for entry in new_entries}

            # Categorize changes
            new: List[Dict[str, Any]] = []
            updated: List[tuple[str, Dict[str, Any]]] = []
            removed: List[str] = []
            unchanged: List[str] = []

            # Check each new entry
            for new_entry in new_entries:
                url = new_entry["upstream_url"]
                existing = existing_by_url.get(url)

                if not existing:
                    # Entry doesn't exist in DB - mark as new
                    new.append(new_entry)
                elif existing.detected_sha != new_entry.get("detected_sha"):
                    # Entry exists but SHA changed - mark as updated
                    updated.append((existing.id, new_entry))
                else:
                    # Entry exists with same SHA - mark as unchanged
                    unchanged.append(existing.id)

            # Find removed entries (in DB but not in new scan)
            for existing_entry in existing_entries:
                if existing_entry.upstream_url not in new_urls:
                    removed.append(existing_entry.id)

            logger.info(
                f"Catalog comparison for source {source_id}: "
                f"new={len(new)}, updated={len(updated)}, "
                f"removed={len(removed)}, unchanged={len(unchanged)}"
            )

            return CatalogDiff(
                new=new,
                updated=updated,
                removed=removed,
                unchanged=unchanged,
            )
        finally:
            session.close()

    def count_by_status(self, source_id: Optional[str] = None) -> Dict[str, int]:
        """Count catalog entries grouped by status.

        Uses efficient SQL aggregation to count entries by status. Useful for
        dashboard statistics and progress tracking.

        Args:
            source_id: Optional filter by source ID

        Returns:
            Dict mapping status -> count (e.g., {"new": 5, "imported": 3})

        Example:
            >>> # Count all entries by status
            >>> counts = repo.count_by_status()
            >>> print(f"New artifacts: {counts.get('new', 0)}")
            >>>
            >>> # Count entries for specific source
            >>> source_counts = repo.count_by_status(source_id="source-123")
        """
        session = self._get_session()
        try:
            query = session.query(
                MarketplaceCatalogEntry.status,
                func.count(MarketplaceCatalogEntry.id).label("count"),
            )

            # Apply source filter if provided
            if source_id:
                query = query.filter_by(source_id=source_id)

            # Group by status and execute
            results = query.group_by(MarketplaceCatalogEntry.status).all()

            # Convert to dict
            counts = {status: count for status, count in results}

            logger.debug(f"Status counts for source {source_id or 'all'}: {counts}")
            return counts
        finally:
            session.close()

    def count_by_status_bulk(self) -> Dict[str, Dict[str, int]]:
        """Count catalog entries grouped by source_id and status in one query.

        Returns a nested dict ``{source_id: {status: count}}`` covering all
        sources present in the catalog table.  Callers can then look up any
        individual source without issuing additional queries, making this
        suitable for list-endpoint bulk pre-fetching (avoids N+1).

        Returns:
            Nested dict mapping source_id → (status → count).
            Sources with no catalog entries are absent from the result.

        Example:
            >>> bulk = repo.count_by_status_bulk()
            >>> counts = bulk.get("src-abc", {})
            >>> new_count = counts.get("new", 0)
        """
        session = self._get_session()
        try:
            results = (
                session.query(
                    MarketplaceCatalogEntry.source_id,
                    MarketplaceCatalogEntry.status,
                    func.count(MarketplaceCatalogEntry.id).label("count"),
                )
                .group_by(
                    MarketplaceCatalogEntry.source_id,
                    MarketplaceCatalogEntry.status,
                )
                .all()
            )

            bulk: Dict[str, Dict[str, int]] = {}
            for source_id, status, count in results:
                bulk.setdefault(source_id, {})[status] = count

            logger.debug("count_by_status_bulk: %d source entries loaded", len(bulk))
            return bulk
        finally:
            session.close()

    def count_by_type(self, source_id: Optional[str] = None) -> Dict[str, int]:
        """Count catalog entries grouped by artifact type.

        Uses efficient SQL aggregation to count entries by type. Useful for
        understanding the composition of discovered artifacts.

        Args:
            source_id: Optional filter by source ID

        Returns:
            Dict mapping artifact_type -> count (e.g., {"skill": 10, "command": 3})

        Example:
            >>> # Count all entries by type
            >>> counts = repo.count_by_type()
            >>> print(f"Total skills: {counts.get('skill', 0)}")
            >>>
            >>> # Count entries for specific source
            >>> source_counts = repo.count_by_type(source_id="source-123")
        """
        session = self._get_session()
        try:
            query = session.query(
                MarketplaceCatalogEntry.artifact_type,
                func.count(MarketplaceCatalogEntry.id).label("count"),
            )

            # Apply source filter if provided
            if source_id:
                query = query.filter_by(source_id=source_id)

            # Group by artifact type and execute
            results = query.group_by(MarketplaceCatalogEntry.artifact_type).all()

            # Convert to dict
            counts = {artifact_type: count for artifact_type, count in results}

            logger.debug(f"Type counts for source {source_id or 'all'}: {counts}")
            return counts
        finally:
            session.close()

    # =========================================================================
    # REPO-001: Cross-Source Artifact Search
    # =========================================================================

    def search(
        self,
        query: Optional[str] = None,
        artifact_type: Optional[str] = None,
        source_ids: Optional[List[str]] = None,
        min_confidence: int = 0,
        tags: Optional[List[str]] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> PaginatedResult[MarketplaceCatalogEntry]:
        """Cross-source artifact search.

        Uses FTS5 full-text search when available for better performance and
        relevance ranking. Falls back to LIKE-based queries when FTS5 is not
        available or when no query is provided.

        Searches across marketplace catalog entries on name, title, description,
        and search_tags fields. Supports filtering by artifact type, source IDs,
        minimum confidence score, and tags.

        Results are ordered by confidence_score descending to surface the
        highest-quality matches first. Entries with status 'excluded' or
        'removed' are automatically excluded.

        Args:
            query: Optional search query. If None, returns all entries.
            artifact_type: Optional filter by artifact type ("skill", "command", etc.)
            source_ids: Optional list of source IDs to filter by. If provided,
                        only entries from these sources are returned.
            min_confidence: Minimum confidence score (0-100, default: 0).
                           Only entries with score >= min_confidence are returned.
            tags: Optional list of tags to filter by. Matches entries where
                  search_tags contains ANY of the specified tags (OR logic).
            limit: Maximum number of items per page (default: 50)
            cursor: Cursor from previous page (None for first page).
                   Cursor format: "score:id" for stable pagination.

        Returns:
            PaginatedResult with items, next_cursor, and has_more flag

        Example:
            >>> # Search for "canvas" skills with high confidence
            >>> result = repo.search(
            ...     query="canvas",
            ...     artifact_type="skill",
            ...     min_confidence=80,
            ...     limit=20
            ... )
            >>> for entry in result.items:
            ...     print(f"{entry.name}: {entry.confidence_score}%")
            >>>
            >>> # Filter by source and tags
            >>> result = repo.search(
            ...     source_ids=["source-1", "source-2"],
            ...     tags=["automation", "testing"],
            ...     limit=50
            ... )
            >>>
            >>> # Pagination
            >>> if result.has_more:
            ...     next_page = repo.search(
            ...         query="canvas",
            ...         cursor=result.next_cursor
            ...     )
        """
        # Lazy import to avoid circular import
        from skillmeat.api.utils.fts5 import is_fts5_available

        # Use FTS5 when: query is provided AND FTS5 is available
        # Fall back to LIKE: no query, or FTS5 unavailable
        if query and is_fts5_available():
            logger.debug(f"Using FTS5 search for query: {query}")
            return self._search_fts5(
                query=query,
                artifact_type=artifact_type,
                source_ids=source_ids,
                min_confidence=min_confidence,
                tags=tags,
                limit=limit,
                cursor=cursor,
            )

        logger.debug(
            f"Using LIKE search (query={query}, fts5_available={is_fts5_available()})"
        )
        return self._search_like(
            query=query,
            artifact_type=artifact_type,
            source_ids=source_ids,
            min_confidence=min_confidence,
            tags=tags,
            limit=limit,
            cursor=cursor,
        )

    def _build_fts5_query(self, query: str) -> str:
        """Build FTS5 query string, escaping special characters.

        Supports simple phrase matching with prefix search for partial words.
        FTS5 special characters are escaped to prevent query syntax errors.

        Args:
            query: Raw search query from user

        Returns:
            FTS5-safe query string with prefix matching

        Example:
            >>> repo._build_fts5_query("canvas design")
            'canvas* design*'
            >>> repo._build_fts5_query("test-skill")
            'test skill*'
        """
        # FTS5 special characters and operators to escape/remove
        # These would otherwise be interpreted as FTS5 query syntax
        special_chars = ['"', "'", "*", "(", ")", "-", ":", "^", "+"]
        special_operators = ["OR", "AND", "NOT", "NEAR"]

        clean_query = query

        # Remove special characters
        for char in special_chars:
            clean_query = clean_query.replace(char, " ")

        # Split into terms
        terms = clean_query.split()

        # Remove FTS5 operators that might appear as search terms
        terms = [t for t in terms if t.upper() not in special_operators]

        if not terms:
            # If all terms were stripped, use wildcard
            return "*"

        # Use prefix matching for partial word search
        # e.g., "skill doc" -> "skill* doc*"
        return " ".join(f"{term}*" for term in terms if term)

    def _search_fts5(
        self,
        query: str,
        artifact_type: Optional[str] = None,
        source_ids: Optional[List[str]] = None,
        min_confidence: int = 0,
        tags: Optional[List[str]] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> PaginatedResult[MarketplaceCatalogEntry]:
        """FTS5 full-text search with relevance ranking.

        Uses SQLite FTS5 virtual table for efficient full-text search with
        Porter stemming. Results are ranked by FTS5 relevance score, then
        by confidence_score for tie-breaking.

        Args:
            query: Search query (required for FTS5 path)
            artifact_type: Optional filter by artifact type
            source_ids: Optional list of source IDs to filter by
            min_confidence: Minimum confidence score (0-100)
            tags: Optional list of tags to filter by (OR logic)
            limit: Maximum number of items per page
            cursor: Cursor from previous page

        Returns:
            PaginatedResult with items, next_cursor, and has_more flag
        """
        session = self._get_session()
        try:
            # Build FTS5 query with escaped special characters
            fts_query = self._build_fts5_query(query)

            # Build dynamic SQL with optional filters
            # Using raw SQL for FTS5 MATCH which SQLAlchemy doesn't support natively
            filters = ["ce.status NOT IN ('excluded', 'removed')"]
            params: Dict[str, Any] = {"query": fts_query, "limit": limit + 1}

            if artifact_type:
                filters.append("ce.artifact_type = :artifact_type")
                params["artifact_type"] = artifact_type

            if source_ids:
                # Build IN clause with positional parameters
                source_placeholders = ", ".join(
                    f":source_{i}" for i in range(len(source_ids))
                )
                filters.append(f"ce.source_id IN ({source_placeholders})")
                for i, source_id in enumerate(source_ids):
                    params[f"source_{i}"] = source_id

            if min_confidence > 0:
                filters.append("ce.confidence_score >= :min_confidence")
                params["min_confidence"] = min_confidence

            if tags:
                # Build OR conditions for tags (match any)
                tag_conditions = []
                for i, tag in enumerate(tags):
                    tag_conditions.append(f"ce.search_tags LIKE :tag_{i}")
                    params[f"tag_{i}"] = f'%"{tag}"%'
                filters.append(f"({' OR '.join(tag_conditions)})")

            # Apply cursor-based pagination
            # Cursor format: "{relevance}:{confidence_score}:{entry_id}"
            # Where relevance is the bm25 score (negative float, closer to 0 = better)
            # Note: We need to apply cursor filter AFTER the FTS5 join since relevance
            # comes from bm25(). We'll use a subquery or CTE approach instead.
            cursor_relevance: Optional[float] = None
            cursor_confidence: Optional[int] = None
            cursor_id: Optional[str] = None
            if cursor:
                try:
                    parts = cursor.split(":", 2)
                    if len(parts) == 3:
                        cursor_relevance = float(parts[0])
                        cursor_confidence = int(parts[1])
                        cursor_id = parts[2]
                    else:
                        # Legacy format: "{confidence_score}:{entry_id}"
                        # Fall back for backwards compatibility
                        cursor_confidence = int(parts[0])
                        cursor_id = parts[1]
                        logger.debug(f"Using legacy cursor format: {cursor}")
                except (ValueError, AttributeError, IndexError):
                    logger.warning(f"Invalid cursor format: {cursor}")

            where_clause = " AND ".join(filters)

            # FTS5 query using external content table
            # bm25() returns negative values (closer to 0 = better match)
            # We use bm25() with column weights to rank results by match location:
            #   - Title matches rank highest (weight 10.0)
            #   - Description matches next (weight 5.0)
            #   - Tag matches (weight 3.0)
            #   - Search text (weight 2.0)
            #   - Deep content matches lowest (weight 1.0)
            # snippet() generates highlighted text around matched terms
            # Column indices: 0=name(unindexed), 1=artifact_type(unindexed), 2=title,
            #                 3=description, 4=search_text, 5=tags, 6=deep_search_text
            # We extract snippets from title (2), description (3), and deep_search_text (6)
            # to determine match source and provide relevant highlighted content
            #
            # bm25 weights: columns 0,1 are unindexed (weight 0), then title, desc,
            #               search_text, tags, deep in order
            bm25_weights = (
                f"0, 0, {SEARCH_WEIGHT_TITLE}, {SEARCH_WEIGHT_DESCRIPTION}, "
                f"{SEARCH_WEIGHT_SEARCH_TEXT}, {SEARCH_WEIGHT_TAGS}, {SEARCH_WEIGHT_DEEP}"
            )

            # Build cursor filter for pagination
            # Since bm25() is computed at query time, we need to filter using the
            # same bm25() expression in the WHERE clause
            cursor_filter = ""
            if (
                cursor_relevance is not None
                and cursor_confidence is not None
                and cursor_id
            ):
                # Full 3-field cursor: relevance:confidence:id
                # ORDER BY relevance ASC, confidence_score DESC, id ASC
                # So "after cursor" means:
                #   - relevance > cursor_relevance (worse match), OR
                #   - relevance = cursor_relevance AND confidence_score < cursor_confidence, OR
                #   - relevance = cursor_relevance AND confidence_score = cursor_confidence AND id > cursor_id
                cursor_filter = f"""
                AND (
                    bm25(catalog_fts, {bm25_weights}) > :cursor_relevance
                    OR (bm25(catalog_fts, {bm25_weights}) = :cursor_relevance AND ce.confidence_score < :cursor_confidence)
                    OR (bm25(catalog_fts, {bm25_weights}) = :cursor_relevance AND ce.confidence_score = :cursor_confidence AND ce.id > :cursor_id)
                )
                """
                params["cursor_relevance"] = cursor_relevance
                params["cursor_confidence"] = cursor_confidence
                params["cursor_id"] = cursor_id
            elif cursor_confidence is not None and cursor_id:
                # Legacy 2-field cursor: confidence:id (no relevance)
                # For backwards compatibility, filter by confidence and id only
                cursor_filter = """
                AND (
                    ce.confidence_score < :cursor_confidence
                    OR (ce.confidence_score = :cursor_confidence AND ce.id > :cursor_id)
                )
                """
                params["cursor_confidence"] = cursor_confidence
                params["cursor_id"] = cursor_id

            sql = text(
                f"""
                SELECT ce.*,
                    bm25(catalog_fts, {bm25_weights}) AS relevance,
                    snippet(catalog_fts, 2, '<mark>', '</mark>', '...', 32) AS title_snippet,
                    snippet(catalog_fts, 3, '<mark>', '</mark>', '...', 64) AS description_snippet,
                    snippet(catalog_fts, 6, '<mark>', '</mark>', '...', 64) AS deep_snippet,
                    ce.deep_index_files AS deep_index_files
                FROM catalog_fts fts
                JOIN marketplace_catalog_entries ce ON ce.rowid = fts.rowid
                WHERE catalog_fts MATCH :query
                AND {where_clause}
                {cursor_filter}
                ORDER BY relevance ASC, ce.confidence_score DESC, ce.id ASC
                LIMIT :limit
                """
            )

            result = session.execute(sql, params)
            rows = result.fetchall()

            # Determine if more items exist
            has_more = len(rows) > limit
            if has_more:
                rows = rows[:limit]

            # Extract snippets and relevance from rows before re-querying for ORM objects
            # Determine if match came from deep_search_text vs title/description
            # A snippet contains '<mark>' if that column matched the search terms
            # Also store relevance scores for cursor generation
            snippets: Dict[str, Dict[str, Any]] = {}
            relevance_scores: Dict[str, float] = {}
            for row in rows:
                title_snippet = row.title_snippet
                description_snippet = row.description_snippet
                deep_snippet = getattr(row, "deep_snippet", None)
                # Store relevance score for cursor generation
                relevance_scores[row.id] = row.relevance

                # Determine if this is a deep match:
                # - Deep match if deep_snippet contains <mark> AND title/desc snippets don't
                # - Title/desc matches rank higher, so only mark as deep_match
                #   when the match clearly came from deep content
                title_has_match = title_snippet and "<mark>" in title_snippet
                desc_has_match = description_snippet and "<mark>" in description_snippet
                deep_has_match = deep_snippet and "<mark>" in deep_snippet

                # It's a deep match only if deep content matched but title/desc didn't
                # This ensures title/description matches rank higher
                # Use bool() to ensure we get False instead of None when deep_has_match is None
                deep_match = bool(
                    deep_has_match and not (title_has_match or desc_has_match)
                )

                # Extract first matched file from deep_index_files if available
                matched_file: Optional[str] = None
                if deep_match:
                    deep_files_json = getattr(row, "deep_index_files", None)
                    if deep_files_json:
                        try:
                            files_list = json.loads(deep_files_json)
                            if files_list and isinstance(files_list, list):
                                # Return first file as representative
                                # Future: could analyze deep_snippet to find exact file
                                matched_file = files_list[0]
                        except json.JSONDecodeError:
                            pass

                snippets[row.id] = {
                    "title_snippet": title_snippet,
                    "description_snippet": description_snippet,
                    "deep_match": deep_match,
                    "matched_file": matched_file,
                }

            # Convert rows to MarketplaceCatalogEntry objects
            # We need to load the entries properly to get the source relationship
            if rows:
                entry_ids = [row.id for row in rows]
                entries_query = (
                    session.query(MarketplaceCatalogEntry)
                    .options(joinedload(MarketplaceCatalogEntry.source))
                    .filter(MarketplaceCatalogEntry.id.in_(entry_ids))
                )
                entries_map = {e.id: e for e in entries_query.all()}
                # Preserve FTS result order
                items = [entries_map[row.id] for row in rows if row.id in entries_map]
            else:
                items = []

            # Generate next cursor from last item
            # Cursor format: "{relevance}:{confidence_score}:{entry_id}"
            # Where relevance is the bm25 score (negative float, closer to 0 = better)
            next_cursor = None
            if items and has_more:
                last_item = items[-1]
                last_relevance = relevance_scores.get(last_item.id, 0.0)
                next_cursor = (
                    f"{last_relevance}:{last_item.confidence_score}:{last_item.id}"
                )

            logger.debug(
                f"FTS5 search returned {len(items)} entries "
                f"(query={query}, fts_query={fts_query}, type={artifact_type}, "
                f"sources={source_ids}, min_conf={min_confidence}, tags={tags}, "
                f"cursor={cursor}, has_more={has_more})"
            )

            return PaginatedResult(
                items=items,
                next_cursor=next_cursor,
                has_more=has_more,
                snippets=snippets,
            )
        except Exception as e:
            # If FTS5 query fails (e.g., syntax error), fall back to LIKE
            logger.warning(f"FTS5 search failed, falling back to LIKE: {e}")
            return self._search_like(
                query=query,
                artifact_type=artifact_type,
                source_ids=source_ids,
                min_confidence=min_confidence,
                tags=tags,
                limit=limit,
                cursor=cursor,
            )
        finally:
            session.close()

    def _search_like(
        self,
        query: Optional[str] = None,
        artifact_type: Optional[str] = None,
        source_ids: Optional[List[str]] = None,
        min_confidence: int = 0,
        tags: Optional[List[str]] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> PaginatedResult[MarketplaceCatalogEntry]:
        """LIKE-based search fallback when FTS5 is unavailable.

        Uses ILIKE queries on name, title, description, and search_tags fields.
        This is the fallback path when FTS5 is not available or when no query
        is provided (listing mode).

        Args:
            query: Optional search query for ILIKE matching
            artifact_type: Optional filter by artifact type
            source_ids: Optional list of source IDs to filter by
            min_confidence: Minimum confidence score (0-100)
            tags: Optional list of tags to filter by (OR logic)
            limit: Maximum number of items per page
            cursor: Cursor from previous page

        Returns:
            PaginatedResult with items, next_cursor, and has_more flag
        """
        session = self._get_session()
        try:
            # Build base query - exclude removed and excluded entries
            # Eagerly load source relationship for cross-source search results
            base_query = (
                session.query(MarketplaceCatalogEntry)
                .options(joinedload(MarketplaceCatalogEntry.source))
                .filter(MarketplaceCatalogEntry.status.notin_(["excluded", "removed"]))
            )

            # Apply text search filter using ILIKE for case-insensitive matching
            if query:
                pattern = f"%{query}%"
                base_query = base_query.filter(
                    or_(
                        MarketplaceCatalogEntry.name.ilike(pattern),
                        MarketplaceCatalogEntry.title.ilike(pattern),
                        MarketplaceCatalogEntry.description.ilike(pattern),
                        MarketplaceCatalogEntry.search_tags.ilike(pattern),
                    )
                )

            # Apply artifact type filter
            if artifact_type:
                base_query = base_query.filter(
                    MarketplaceCatalogEntry.artifact_type == artifact_type
                )

            # Apply source IDs filter
            if source_ids:
                base_query = base_query.filter(
                    MarketplaceCatalogEntry.source_id.in_(source_ids)
                )

            # Apply minimum confidence filter
            if min_confidence > 0:
                base_query = base_query.filter(
                    MarketplaceCatalogEntry.confidence_score >= min_confidence
                )

            # Apply tags filter (OR logic - matches if ANY tag is present)
            if tags:
                # For SQLite JSON, search_tags is stored as JSON array string
                # Use multiple LIKE conditions with OR for each tag
                tag_conditions = []
                for tag in tags:
                    # Match tag in JSON array: ["tag1", "tag2"] contains "tag"
                    tag_conditions.append(
                        MarketplaceCatalogEntry.search_tags.ilike(f'%"{tag}"%')
                    )
                base_query = base_query.filter(or_(*tag_conditions))

            # Apply cursor-based pagination
            # Cursor format: "confidence_score:id" for stable ordering
            if cursor:
                try:
                    cursor_score_str, cursor_id = cursor.split(":", 1)
                    cursor_score = int(cursor_score_str)
                    # Items after cursor: lower score, or same score with higher ID
                    base_query = base_query.filter(
                        or_(
                            MarketplaceCatalogEntry.confidence_score < cursor_score,
                            and_(
                                MarketplaceCatalogEntry.confidence_score
                                == cursor_score,
                                MarketplaceCatalogEntry.id > cursor_id,
                            ),
                        )
                    )
                except (ValueError, AttributeError):
                    # Invalid cursor format - ignore and return from start
                    logger.warning(f"Invalid cursor format: {cursor}")

            # Order by confidence_score descending, then by id for stability
            base_query = base_query.order_by(
                MarketplaceCatalogEntry.confidence_score.desc(),
                MarketplaceCatalogEntry.id.asc(),
            )

            # Fetch limit + 1 to check if more items exist
            items = base_query.limit(limit + 1).all()

            # Determine if more items exist
            has_more = len(items) > limit
            if has_more:
                items = items[:limit]

            # Generate next cursor from last item
            next_cursor = None
            if items and has_more:
                last_item = items[-1]
                next_cursor = f"{last_item.confidence_score}:{last_item.id}"

            logger.debug(
                f"LIKE search returned {len(items)} entries "
                f"(query={query}, type={artifact_type}, sources={source_ids}, "
                f"min_conf={min_confidence}, tags={tags}, cursor={cursor}, "
                f"has_more={has_more})"
            )

            return PaginatedResult(
                items=items,
                next_cursor=next_cursor,
                has_more=has_more,
            )
        finally:
            session.close()

    def get_composite_aggregates(self) -> Dict[str, Any]:
        """Return composite-member aggregate data across all sources.

        Executes a single JOIN query to collect deduplicated child-artifact
        types and the total membership-edge count, avoiding N+1 round trips.

        Returns:
            Dict with keys ``member_count`` (int) and ``child_types``
            (List[str]).  Returns ``{"member_count": 0, "child_types": []}``
            on any DB error so that failures are non-fatal.
        """
        from skillmeat.cache.models import (
            Artifact as _Artifact,
            CompositeMembership as _CM,
        )

        session = self._get_session()
        try:
            rows = (
                session.query(_Artifact.type)
                .join(_CM, _CM.child_artifact_uuid == _Artifact.uuid)
                .distinct()
                .all()
            )
            child_types = [row.type for row in rows if row.type]
            member_count = session.query(_CM).count()
            return {"member_count": member_count, "child_types": child_types}
        except Exception as exc:  # noqa: BLE001
            logger.debug("get_composite_aggregates: DB query failed — %s", exc)
            return {"member_count": 0, "child_types": []}
        finally:
            session.close()

    def update_name(
        self,
        entry_id: str,
        source_id: str,
        name: str,
    ) -> Optional[MarketplaceCatalogEntry]:
        """Update the display name of a catalog entry.

        Args:
            entry_id: Unique catalog entry identifier.
            source_id: Source ID — entry must belong to this source.
            name: New artifact name.

        Returns:
            Updated :class:`MarketplaceCatalogEntry` if found and updated,
            ``None`` if the entry does not exist.

        Raises:
            ValueError: If the entry does not belong to ``source_id``.
        """
        session = self._get_session()
        try:
            entry = (
                session.query(MarketplaceCatalogEntry).filter_by(id=entry_id).first()
            )
            if not entry:
                return None
            if entry.source_id != source_id:
                raise ValueError(
                    f"Entry '{entry_id}' does not belong to source '{source_id}'"
                )
            entry.name = name
            session.commit()
            session.refresh(entry)
            logger.info("update_name: updated entry %s -> %r", entry_id, name)
            return entry
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def set_exclusion(
        self,
        entry_id: str,
        source_id: str,
        excluded: bool,
        reason: Optional[str] = None,
    ) -> Optional[MarketplaceCatalogEntry]:
        """Mark or restore a catalog entry's exclusion state.

        Args:
            entry_id: Unique catalog entry identifier.
            source_id: Source ID — entry must belong to this source.
            excluded: ``True`` to exclude, ``False`` to restore.
            reason: Optional human-readable reason (used when ``excluded=True``).

        Returns:
            Updated :class:`MarketplaceCatalogEntry` if found, ``None`` otherwise.

        Raises:
            ValueError: If the entry does not belong to ``source_id``.
        """
        from datetime import timezone

        session = self._get_session()
        try:
            entry = (
                session.query(MarketplaceCatalogEntry).filter_by(id=entry_id).first()
            )
            if not entry:
                return None
            if entry.source_id != source_id:
                raise ValueError(
                    f"Entry '{entry_id}' does not belong to source '{source_id}'"
                )

            if excluded:
                if entry.excluded_at is None:
                    entry.excluded_at = datetime.now(timezone.utc)
                entry.excluded_reason = reason
                entry.status = "excluded"
            else:
                entry.excluded_at = None
                entry.excluded_reason = None
                entry.status = "new" if entry.import_date is None else "imported"

            session.commit()
            session.refresh(entry)
            logger.info("set_exclusion: entry %s excluded=%s", entry_id, excluded)
            return entry
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def get_with_path_segments(
        self,
        entry_id: str,
        source_id: str,
    ) -> Optional[MarketplaceCatalogEntry]:
        """Fetch a catalog entry validating it belongs to the given source.

        Convenience wrapper used by path-tag endpoints that need to both
        retrieve and validate source ownership in one call.

        Args:
            entry_id: Unique catalog entry identifier.
            source_id: Source ID — entry must belong to this source.

        Returns:
            :class:`MarketplaceCatalogEntry` if found and owned by source,
            ``None`` if not found.

        Raises:
            ValueError: If the entry exists but does not belong to ``source_id``.
        """
        session = self._get_session()
        try:
            entry = (
                session.query(MarketplaceCatalogEntry)
                .filter(
                    MarketplaceCatalogEntry.source_id == source_id,
                    MarketplaceCatalogEntry.id == entry_id,
                )
                .first()
            )
            return entry
        finally:
            session.close()

    def update_path_segments(
        self,
        entry_id: str,
        source_id: str,
        path_segments_json: str,
    ) -> Optional[MarketplaceCatalogEntry]:
        """Persist updated path-segments JSON for a catalog entry.

        Args:
            entry_id: Unique catalog entry identifier.
            source_id: Source ID — used to validate ownership.
            path_segments_json: Serialised JSON string to store.

        Returns:
            Updated :class:`MarketplaceCatalogEntry`, or ``None`` if not found.

        Raises:
            ValueError: If the entry does not belong to ``source_id``.
        """
        session = self._get_session()
        try:
            entry = (
                session.query(MarketplaceCatalogEntry)
                .filter(
                    MarketplaceCatalogEntry.source_id == source_id,
                    MarketplaceCatalogEntry.id == entry_id,
                )
                .first()
            )
            if not entry:
                return None
            entry.path_segments = path_segments_json
            session.commit()
            session.refresh(entry)
            logger.info("update_path_segments: updated entry %s", entry_id)
            return entry
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()


# =============================================================================
# Deployment Profile Repository
# =============================================================================


class DeploymentProfileRepository(BaseRepository[DeploymentProfile]):
    """Repository for deployment profile CRUD operations."""

    def __init__(self, db_path: Optional[str | Path] = None):
        super().__init__(db_path, DeploymentProfile)

    def create(
        self,
        *,
        project_id: str,
        profile_id: str,
        platform: str,
        root_dir: str,
        description: Optional[str] = None,
        artifact_path_map: Optional[Dict[str, str]] = None,
        config_filenames: Optional[List[str]] = None,
        context_prefixes: Optional[List[str]] = None,
        supported_types: Optional[List[str]] = None,
    ) -> DeploymentProfile:
        """Create a deployment profile."""
        session = self._get_session()
        try:
            platform_value = (
                platform.value if isinstance(platform, Platform) else str(platform)
            )
            platform_enum = (
                Platform(platform_value)
                if platform_value in {p.value for p in Platform}
                else Platform.OTHER
            )
            root_prefix = f"{root_dir.rstrip('/')}/context/"
            profile = DeploymentProfile(
                id=uuid.uuid4().hex,
                project_id=project_id,
                profile_id=profile_id,
                platform=platform_value,
                root_dir=root_dir,
                description=description,
                artifact_path_map=artifact_path_map or {},
                config_filenames=config_filenames
                or default_project_config_filenames(platform_enum),
                context_prefixes=context_prefixes or [root_prefix],
                supported_types=supported_types or [],
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            session.add(profile)
            session.commit()
            session.refresh(profile)
            return profile
        except IntegrityError as e:
            session.rollback()
            raise RepositoryError(f"Failed to create deployment profile: {e}") from e
        finally:
            session.close()

    def read_by_id(self, profile_db_id: str) -> Optional[DeploymentProfile]:
        """Read deployment profile by DB ID."""
        session = self._get_session()
        try:
            return (
                session.query(DeploymentProfile)
                .filter(DeploymentProfile.id == profile_db_id)
                .first()
            )
        finally:
            session.close()

    def read_by_project_and_profile_id(
        self, project_id: str, profile_id: str
    ) -> Optional[DeploymentProfile]:
        """Read deployment profile by project and profile ID."""
        session = self._get_session()
        try:
            return (
                session.query(DeploymentProfile)
                .filter(
                    DeploymentProfile.project_id == project_id,
                    DeploymentProfile.profile_id == profile_id,
                )
                .first()
            )
        finally:
            session.close()

    def list_by_project(self, project_id: str) -> List[DeploymentProfile]:
        """List deployment profiles for a project."""
        session = self._get_session()
        try:
            return (
                session.query(DeploymentProfile)
                .filter(DeploymentProfile.project_id == project_id)
                .order_by(DeploymentProfile.profile_id.asc())
                .all()
            )
        finally:
            session.close()

    def list_all_profiles(self, project_id: str) -> List[DeploymentProfile]:
        """Alias for listing all deployment profiles for a project."""
        return self.list_by_project(project_id)

    def get_project_id_by_path(self, project_path: str) -> Optional[str]:
        """Return the project ID for the given filesystem path.

        Args:
            project_path: Absolute path string to match against
                ``Project.path``.

        Returns:
            Project ID string when a matching row exists, ``None`` otherwise.
        """
        from skillmeat.cache.models import Project as _Project

        session = self._get_session()
        try:
            row = session.query(_Project).filter(_Project.path == project_path).first()
            return row.id if row else None
        finally:
            session.close()

    def get_profile_by_platform(
        self, project_id: str, platform: str | Platform
    ) -> Optional[DeploymentProfile]:
        """Get deployment profile by project and platform."""
        platform_value = (
            platform.value if isinstance(platform, Platform) else str(platform)
        )
        session = self._get_session()
        try:
            return (
                session.query(DeploymentProfile)
                .filter(
                    DeploymentProfile.project_id == project_id,
                    DeploymentProfile.platform == platform_value,
                )
                .order_by(DeploymentProfile.profile_id.asc())
                .first()
            )
        finally:
            session.close()

    def get_primary_profile(self, project_id: str) -> Optional[DeploymentProfile]:
        """Get primary deployment profile for a project.

        Preference order:
        1. Explicit Claude Code platform profile
        2. Profile id == "claude_code"
        3. First profile alphabetically
        """
        primary = self.get_profile_by_platform(project_id, Platform.CLAUDE_CODE)
        if primary:
            return primary

        profile = self.read_by_project_and_profile_id(project_id, "claude_code")
        if profile:
            return profile

        profiles = self.list_by_project(project_id)
        return profiles[0] if profiles else None

    def ensure_default_claude_profile(self, project_id: str) -> DeploymentProfile:
        """Ensure a backward-compatible default Claude profile exists."""
        primary = self.get_primary_profile(project_id)
        if primary:
            return primary

        return self.create(
            project_id=project_id,
            profile_id="claude_code",
            platform=Platform.CLAUDE_CODE.value,
            root_dir=".claude",
            artifact_path_map=DEFAULT_ARTIFACT_PATH_MAP.copy(),
            config_filenames=default_project_config_filenames(Platform.CLAUDE_CODE),
            context_prefixes=[".claude/context/", ".claude/"],
            supported_types=["skill", "command", "agent", "hook", "mcp"],
        )

    def update(
        self,
        project_id: str,
        profile_id: str,
        **updates: Any,
    ) -> Optional[DeploymentProfile]:
        """Update an existing deployment profile."""
        session = self._get_session()
        try:
            profile = (
                session.query(DeploymentProfile)
                .filter(
                    DeploymentProfile.project_id == project_id,
                    DeploymentProfile.profile_id == profile_id,
                )
                .first()
            )
            if not profile:
                return None

            for key, value in updates.items():
                if value is not None and hasattr(profile, key):
                    setattr(profile, key, value)
            profile.updated_at = datetime.utcnow()

            session.commit()
            session.refresh(profile)
            return profile
        except IntegrityError as e:
            session.rollback()
            raise RepositoryError(f"Failed to update deployment profile: {e}") from e
        finally:
            session.close()

    def delete(self, project_id: str, profile_id: str) -> bool:
        """Delete deployment profile by project and profile ID."""
        session = self._get_session()
        try:
            profile = (
                session.query(DeploymentProfile)
                .filter(
                    DeploymentProfile.project_id == project_id,
                    DeploymentProfile.profile_id == profile_id,
                )
                .first()
            )
            if not profile:
                return False

            session.delete(profile)
            session.commit()
            return True
        finally:
            session.close()


# =============================================================================
# Tag Repository
# =============================================================================


class TagRepository(BaseRepository[Tag]):
    """Repository for tag management and artifact-tag associations.

    Provides CRUD operations for tags, search capabilities, and methods for
    managing many-to-many relationships between artifacts and tags.

    Usage:
        >>> repo = TagRepository()
        >>>
        >>> # Create tag
        >>> tag = repo.create("Python", "python", "#3776AB")
        >>>
        >>> # Search tags
        >>> tags = repo.search_by_name("py")
        >>>
        >>> # Associate tag with artifact
        >>> repo.add_tag_to_artifact(artifact_id="art-123", tag_id=tag.id)
        >>>
        >>> # Get artifacts by tag
        >>> artifacts, cursor, has_more = repo.get_artifacts_by_tag(tag.id)
    """

    def __init__(self, db_path: Optional[str | Path] = None):
        """Initialize tag repository.

        Args:
            db_path: Optional path to database file (uses default if None)
        """
        super().__init__(db_path, Tag)

    # =========================================================================
    # REPO-001: CRUD Operations
    # =========================================================================

    def create(self, name: str, slug: str, color: Optional[str] = None) -> Tag:
        """Create a new tag.

        Args:
            name: Tag name (unique, max 100 characters)
            slug: URL-friendly identifier (unique, kebab-case)
            color: Optional hex color code (e.g., "#FF5733")

        Returns:
            Created Tag instance

        Raises:
            RepositoryError: If tag with same name/slug already exists

        Example:
            >>> tag = repo.create("Python", "python", "#3776AB")
            >>> print(f"Created tag: {tag.name}")
        """
        session = self._get_session()
        try:
            # Check for duplicates
            existing = (
                session.query(Tag)
                .filter(or_(Tag.name == name, Tag.slug == slug))
                .first()
            )

            if existing:
                if existing.name == name:
                    raise RepositoryError(f"Tag with name '{name}' already exists")
                else:
                    raise RepositoryError(f"Tag with slug '{slug}' already exists")

            # Create tag
            tag = Tag(
                id=uuid.uuid4().hex,
                name=name,
                slug=slug,
                color=color,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )

            session.add(tag)
            session.commit()
            session.refresh(tag)

            logger.info(f"Created tag: {tag.name} (id={tag.id})")
            return tag

        except IntegrityError as e:
            session.rollback()
            raise RepositoryError(f"Failed to create tag: {e}") from e
        finally:
            session.close()

    def get_by_id(self, tag_id: str) -> Optional[Tag]:
        """Get tag by ID.

        Args:
            tag_id: Tag identifier

        Returns:
            Tag instance or None if not found

        Example:
            >>> tag = repo.get_by_id("abc123")
            >>> if tag:
            ...     print(f"Found: {tag.name}")
        """
        session = self._get_session()
        try:
            tag = session.query(Tag).filter_by(id=tag_id).first()
            return tag
        finally:
            session.close()

    def get_by_slug(self, slug: str) -> Optional[Tag]:
        """Get tag by slug.

        Args:
            slug: URL-friendly identifier

        Returns:
            Tag instance or None if not found

        Example:
            >>> tag = repo.get_by_slug("python")
            >>> if tag:
            ...     print(f"Found: {tag.name}")
        """
        session = self._get_session()
        try:
            tag = session.query(Tag).filter_by(slug=slug).first()
            return tag
        finally:
            session.close()

    def update(
        self,
        tag_id: str,
        name: Optional[str] = None,
        slug: Optional[str] = None,
        color: Optional[str] = None,
    ) -> Optional[Tag]:
        """Update tag attributes.

        Args:
            tag_id: Tag identifier
            name: New tag name (optional)
            slug: New slug (optional)
            color: New color code (optional)

        Returns:
            Updated Tag instance or None if not found

        Raises:
            RepositoryError: If update conflicts with existing tag

        Example:
            >>> tag = repo.update("abc123", color="#FF0000")
            >>> if tag:
            ...     print(f"Updated: {tag.name}")
        """
        session = self._get_session()
        try:
            tag = session.query(Tag).filter_by(id=tag_id).first()
            if not tag:
                return None

            # Check for conflicts if changing name or slug
            if name and name != tag.name:
                existing = session.query(Tag).filter_by(name=name).first()
                if existing:
                    raise RepositoryError(f"Tag with name '{name}' already exists")
                tag.name = name

            if slug and slug != tag.slug:
                existing = session.query(Tag).filter_by(slug=slug).first()
                if existing:
                    raise RepositoryError(f"Tag with slug '{slug}' already exists")
                tag.slug = slug

            if color is not None:
                tag.color = color

            tag.updated_at = datetime.utcnow()

            # Use merge to update
            tag = session.merge(tag)
            session.commit()
            session.refresh(tag)

            logger.info(f"Updated tag: {tag.name} (id={tag.id})")
            return tag

        except IntegrityError as e:
            session.rollback()
            raise RepositoryError(f"Failed to update tag: {e}") from e
        finally:
            session.close()

    def delete(self, tag_id: str) -> bool:
        """Delete tag by ID.

        Also removes all artifact-tag associations (CASCADE).

        Args:
            tag_id: Tag identifier

        Returns:
            True if deleted, False if not found

        Example:
            >>> deleted = repo.delete("abc123")
            >>> if deleted:
            ...     print("Tag deleted")
        """
        session = self._get_session()
        try:
            tag = session.query(Tag).filter_by(id=tag_id).first()
            if not tag:
                return False

            session.delete(tag)
            session.commit()

            logger.info(f"Deleted tag: {tag.name} (id={tag.id})")
            return True

        except Exception as e:
            session.rollback()
            raise RepositoryError(f"Failed to delete tag: {e}") from e
        finally:
            session.close()

    # =========================================================================
    # REPO-002: Search & List
    # =========================================================================

    def list_all(
        self, limit: int = 100, after_cursor: Optional[str] = None
    ) -> tuple[List[Tag], Optional[str], bool]:
        """List all tags with cursor-based pagination.

        Args:
            limit: Maximum number of tags to return (default: 100)
            after_cursor: Cursor for pagination (tag ID)

        Returns:
            Tuple of (tags, next_cursor, has_more):
                - tags: List of Tag instances
                - next_cursor: Cursor for next page (None if no more)
                - has_more: Whether more results exist

        Example:
            >>> tags, cursor, has_more = repo.list_all(limit=50)
            >>> while has_more:
            ...     tags, cursor, has_more = repo.list_all(limit=50, after_cursor=cursor)
        """
        session = self._get_session()
        try:
            query = session.query(Tag).order_by(Tag.created_at.desc(), Tag.id)

            # Apply cursor if provided
            if after_cursor:
                cursor_tag = session.query(Tag).filter_by(id=after_cursor).first()
                if cursor_tag:
                    query = query.filter(
                        or_(
                            Tag.created_at < cursor_tag.created_at,
                            and_(
                                Tag.created_at == cursor_tag.created_at,
                                Tag.id > cursor_tag.id,
                            ),
                        )
                    )

            # Fetch limit + 1 to check if more exist
            tags = query.limit(limit + 1).all()

            # Determine pagination state
            has_more = len(tags) > limit
            if has_more:
                tags = tags[:limit]
                next_cursor = tags[-1].id if tags else None
            else:
                next_cursor = None

            logger.debug(
                f"Listed {len(tags)} tags (cursor={after_cursor}, has_more={has_more})"
            )
            return tags, next_cursor, has_more

        finally:
            session.close()

    def search_by_name(self, pattern: str, limit: int = 50) -> List[Tag]:
        """Search tags by name pattern (case-insensitive).

        Args:
            pattern: Search pattern (matches anywhere in name)
            limit: Maximum results to return (default: 50)

        Returns:
            List of matching Tag instances

        Example:
            >>> tags = repo.search_by_name("py")
            >>> # Returns tags like "Python", "PyTorch", etc.
        """
        session = self._get_session()
        try:
            tags = (
                session.query(Tag)
                .filter(Tag.name.ilike(f"%{pattern}%"))
                .order_by(Tag.name)
                .limit(limit)
                .all()
            )

            logger.debug(f"Found {len(tags)} tags matching pattern '{pattern}'")
            return tags

        finally:
            session.close()

    # =========================================================================
    # REPO-003: Artifact-Tag Associations
    # =========================================================================

    def add_tag_to_artifact(self, artifact_uuid: str, tag_id: str) -> ArtifactTag:
        """Add tag to artifact (create association).

        Args:
            artifact_uuid: Artifact UUID (artifacts.uuid, ADR-007 stable identity)
            tag_id: Tag identifier

        Returns:
            Created ArtifactTag association

        Raises:
            RepositoryError: If association already exists or IDs invalid

        Example:
            >>> assoc = repo.add_tag_to_artifact("abc123hex", "tag-456")
            >>> print(f"Tagged artifact at {assoc.created_at}")
        """
        session = self._get_session()
        try:
            # Check if association already exists
            existing = (
                session.query(ArtifactTag)
                .filter_by(artifact_uuid=artifact_uuid, tag_id=tag_id)
                .first()
            )

            if existing:
                raise RepositoryError(
                    f"Artifact {artifact_uuid} already has tag {tag_id}"
                )

            # Verify artifact and tag exist
            artifact = session.query(Artifact).filter_by(uuid=artifact_uuid).first()
            if not artifact:
                raise RepositoryError(
                    f"Artifact with uuid={artifact_uuid!r} not found in cache"
                )

            tag = session.query(Tag).filter_by(id=tag_id).first()
            if not tag:
                raise RepositoryError(f"Tag {tag_id} not found")

            # Create association
            assoc = ArtifactTag(
                artifact_uuid=artifact_uuid,
                tag_id=tag_id,
                created_at=datetime.utcnow(),
            )

            session.add(assoc)
            session.commit()
            session.refresh(assoc)

            logger.info(f"Added tag {tag_id} to artifact uuid={artifact_uuid}")
            return assoc

        except IntegrityError as e:
            session.rollback()
            raise RepositoryError(f"Failed to add tag to artifact: {e}") from e
        finally:
            session.close()

    def remove_tag_from_artifact(self, artifact_uuid: str, tag_id: str) -> bool:
        """Remove tag from artifact (delete association).

        Args:
            artifact_uuid: Artifact UUID (artifacts.uuid, ADR-007 stable identity)
            tag_id: Tag identifier

        Returns:
            True if removed, False if association didn't exist

        Example:
            >>> removed = repo.remove_tag_from_artifact("abc123hex", "tag-456")
            >>> if removed:
            ...     print("Tag removed from artifact")
        """
        session = self._get_session()
        try:
            assoc = (
                session.query(ArtifactTag)
                .filter_by(artifact_uuid=artifact_uuid, tag_id=tag_id)
                .first()
            )

            if not assoc:
                return False

            session.delete(assoc)
            session.commit()

            logger.info(f"Removed tag {tag_id} from artifact uuid={artifact_uuid}")
            return True

        except Exception as e:
            session.rollback()
            raise RepositoryError(f"Failed to remove tag from artifact: {e}") from e
        finally:
            session.close()

    def get_artifact_tags(self, artifact_uuid: str) -> List[Tag]:
        """Get all tags for an artifact.

        Args:
            artifact_uuid: Artifact UUID (artifacts.uuid, ADR-007 stable identity)

        Returns:
            List of Tag instances (ordered by name)

        Example:
            >>> tags = repo.get_artifact_tags("abc123hex")
            >>> for tag in tags:
            ...     print(f"- {tag.name}")
        """
        session = self._get_session()
        try:
            tags = (
                session.query(Tag)
                .join(ArtifactTag, Tag.id == ArtifactTag.tag_id)
                .filter(ArtifactTag.artifact_uuid == artifact_uuid)
                .order_by(Tag.name)
                .all()
            )

            logger.debug(f"Found {len(tags)} tags for artifact uuid={artifact_uuid}")
            return tags

        finally:
            session.close()

    def get_artifacts_by_tag(
        self, tag_id: str, limit: int = 100, after_cursor: Optional[str] = None
    ) -> tuple[List[Artifact], Optional[str], bool]:
        """Get all artifacts with a specific tag (paginated).

        Args:
            tag_id: Tag identifier
            limit: Maximum number of artifacts to return (default: 100)
            after_cursor: Cursor for pagination (artifact ID)

        Returns:
            Tuple of (artifacts, next_cursor, has_more):
                - artifacts: List of Artifact instances
                - next_cursor: Cursor for next page (None if no more)
                - has_more: Whether more results exist

        Example:
            >>> artifacts, cursor, has_more = repo.get_artifacts_by_tag("tag-123")
            >>> for artifact in artifacts:
            ...     print(f"- {artifact.name}")
        """
        session = self._get_session()
        try:
            query = (
                session.query(Artifact)
                .join(ArtifactTag, Artifact.uuid == ArtifactTag.artifact_uuid)
                .filter(ArtifactTag.tag_id == tag_id)
                .order_by(ArtifactTag.created_at.desc(), Artifact.uuid)
            )

            # Apply cursor if provided (cursor is artifact_uuid)
            if after_cursor:
                cursor_assoc = (
                    session.query(ArtifactTag)
                    .filter_by(artifact_uuid=after_cursor, tag_id=tag_id)
                    .first()
                )
                if cursor_assoc:
                    query = query.filter(
                        or_(
                            ArtifactTag.created_at < cursor_assoc.created_at,
                            and_(
                                ArtifactTag.created_at == cursor_assoc.created_at,
                                Artifact.uuid > cursor_assoc.artifact_uuid,
                            ),
                        )
                    )

            # Fetch limit + 1 to check if more exist
            artifacts = query.limit(limit + 1).all()

            # Determine pagination state (cursor is artifact_uuid)
            has_more = len(artifacts) > limit
            if has_more:
                artifacts = artifacts[:limit]
                next_cursor = artifacts[-1].uuid if artifacts else None
            else:
                next_cursor = None

            logger.debug(
                f"Found {len(artifacts)} artifacts with tag {tag_id} "
                f"(cursor={after_cursor}, has_more={has_more})"
            )
            return artifacts, next_cursor, has_more

        finally:
            session.close()

    # =========================================================================
    # REPO-004: Statistics
    # =========================================================================

    def get_tag_artifact_count(self, tag_id: str) -> int:
        """Get number of artifacts with a specific tag.

        Args:
            tag_id: Tag identifier

        Returns:
            Count of artifacts with this tag

        Example:
            >>> count = repo.get_tag_artifact_count("tag-123")
            >>> print(f"Tag used on {count} artifacts")
        """
        session = self._get_session()
        try:
            count = (
                session.query(func.count(ArtifactTag.artifact_uuid))
                .filter_by(tag_id=tag_id)
                .scalar()
            )

            return count or 0

        finally:
            session.close()

    def get_all_tag_counts(self) -> List[tuple[Tag, int]]:
        """Get all tags with their artifact counts.

        Returns:
            List of (tag, count) tuples, ordered by count descending

        Example:
            >>> tag_counts = repo.get_all_tag_counts()
            >>> for tag, count in tag_counts:
            ...     print(f"{tag.name}: {count} artifacts")
        """
        session = self._get_session()
        try:
            results = (
                session.query(
                    Tag,
                    func.count(ArtifactTag.artifact_uuid).label("count"),
                )
                .outerjoin(ArtifactTag, Tag.id == ArtifactTag.tag_id)
                .group_by(Tag.id)
                .order_by(func.count(ArtifactTag.artifact_uuid).desc(), Tag.name)
                .all()
            )

            logger.debug(f"Retrieved counts for {len(results)} tags")
            return results

        finally:
            session.close()

    def get_tag_deployment_set_count(self, tag_id: str) -> int:
        """Get number of deployment sets with a specific tag.

        Args:
            tag_id: Tag identifier

        Returns:
            Count of deployment sets with this tag

        Example:
            >>> count = repo.get_tag_deployment_set_count("tag-123")
            >>> print(f"Tag used on {count} deployment sets")
        """
        session = self._get_session()
        try:
            result = (
                session.query(func.count(DeploymentSetTag.deployment_set_id))
                .filter(DeploymentSetTag.tag_id == tag_id)
                .scalar()
            )
            return result or 0
        finally:
            session.close()

    def get_all_deployment_set_tag_counts(self) -> List[tuple[Tag, int]]:
        """Get all tags with their deployment set counts.

        Returns:
            List of (tag, count) tuples where count is the number of
            deployment sets associated with each tag, ordered by count
            descending then by name.

        Example:
            >>> ds_counts = repo.get_all_deployment_set_tag_counts()
            >>> for tag, count in ds_counts:
            ...     print(f"{tag.name}: {count} deployment sets")
        """
        session = self._get_session()
        try:
            results = (
                session.query(
                    Tag,
                    func.count(DeploymentSetTag.deployment_set_id).label("count"),
                )
                .outerjoin(DeploymentSetTag, Tag.id == DeploymentSetTag.tag_id)
                .group_by(Tag.id)
                .order_by(
                    func.count(DeploymentSetTag.deployment_set_id).desc(), Tag.name
                )
                .all()
            )
            logger.debug(f"Retrieved deployment-set counts for {len(results)} tags")
            return results
        finally:
            session.close()


# =============================================================================
# Deployment Set Repository
# =============================================================================


class DeploymentSetRepository(BaseRepository[DeploymentSet]):
    """Repository for DeploymentSet CRUD with owner-scoped access.

    All reads and writes are scoped to ``owner_id`` — two different owners
    can never see each other's sets.  Tag filtering uses a JSON ``LIKE``
    match against the ``tags_json`` column (same approach used elsewhere in
    the codebase for JSON-text tag columns).

    FR-10 delete semantics: Before deleting a set, any
    ``DeploymentSetMember`` rows in *other* sets that reference the doomed
    set via ``member_set_id`` are deleted first, preventing orphan
    references.

    Usage:
        >>> repo = DeploymentSetRepository()
        >>> ds = repo.create(name="My Set", owner_id="user-1")
        >>> fetched = repo.get(ds.id, owner_id="user-1")
        >>> sets = repo.list(owner_id="user-1", tag="prod")
        >>> ok = repo.delete(ds.id, owner_id="user-1")
    """

    def __init__(self, db_path: Optional[str | Path] = None):
        """Initialise repository.

        Args:
            db_path: Optional path to SQLite database file (uses default if None).
        """
        super().__init__(db_path, DeploymentSet)

    # =========================================================================
    # Internal Helpers
    # =========================================================================

    def _sync_tags(self, session: Session, set_id: str, tag_names: List[str]) -> None:
        """Sync deployment set tags via the deployment_set_tags junction table.

        Clears all existing tag associations for the given deployment set, then
        for each tag name finds or creates a ``Tag`` record and inserts a
        ``DeploymentSetTag`` junction row.

        Args:
            session: Active SQLAlchemy session (caller owns commit/rollback).
            set_id: Primary key of the deployment set to sync.
            tag_names: List of tag name strings to associate with the set.
        """
        # Clear existing tag associations for this set
        session.query(DeploymentSetTag).filter(
            DeploymentSetTag.deployment_set_id == set_id
        ).delete(synchronize_session=False)

        now = datetime.utcnow()

        for raw_name in tag_names:
            name = raw_name.strip()
            if not name:
                continue

            # Find existing tag by name (case-insensitive)
            tag = (
                session.query(Tag)
                .filter(func.lower(Tag.name) == func.lower(name))
                .first()
            )

            if not tag:
                # Build a unique slug
                slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
                if not slug:
                    slug = uuid.uuid4().hex[:8]
                base_slug = slug
                counter = 1
                while session.query(Tag).filter(Tag.slug == slug).first():
                    slug = f"{base_slug}-{counter}"
                    counter += 1

                tag = Tag(
                    id=uuid.uuid4().hex,
                    name=name,
                    slug=slug,
                    created_at=now,
                    updated_at=now,
                )
                session.add(tag)
                session.flush()  # Assign id before referencing in junction row

            assoc = DeploymentSetTag(
                deployment_set_id=set_id,
                tag_id=tag.id,
                created_at=now,
            )
            session.add(assoc)

    # =========================================================================
    # Create
    # =========================================================================

    def create(
        self,
        *,
        name: str,
        owner_id: str,
        description: Optional[str] = None,
        color: Optional[str] = None,
        icon: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> DeploymentSet:
        """Create and return a new DeploymentSet.

        Args:
            name: Human-readable set name (required).
            owner_id: Owning user / identity scope (required).
            description: Optional free-text description.
            color: Optional hex color code (e.g. ``"#7c3aed"``).
            icon: Optional icon identifier string (e.g. ``"layers"``).
            tags: Optional list of tag strings.

        Returns:
            Newly created ``DeploymentSet`` instance.

        Raises:
            RepositoryError: If the insert fails (e.g. constraint violation).
        """
        session = self._get_session()
        try:
            now = datetime.utcnow()
            ds = DeploymentSet(
                id=uuid.uuid4().hex,
                name=name,
                owner_id=owner_id,
                description=description,
                color=color,
                icon=icon,
                created_at=now,
                updated_at=now,
            )
            session.add(ds)
            session.flush()  # Assign the id before syncing tags
            if tags:
                self._sync_tags(session, ds.id, tags)
            session.commit()
            session.refresh(ds)
            logger.debug("Created DeploymentSet id=%s owner=%s", ds.id, owner_id)
            return ds
        except IntegrityError as exc:
            session.rollback()
            raise RepositoryError(f"Failed to create DeploymentSet: {exc}") from exc
        finally:
            session.close()

    # =========================================================================
    # Read
    # =========================================================================

    def get(self, set_id: str, owner_id: str) -> Optional[DeploymentSet]:
        """Fetch a single DeploymentSet by ID, scoped to owner.

        Args:
            set_id: Primary key of the deployment set.
            owner_id: Owner scope — returns None if the set belongs to a
                different owner.

        Returns:
            ``DeploymentSet`` instance or ``None`` if not found.
        """
        session = self._get_session()
        try:
            return (
                session.query(DeploymentSet)
                .filter(
                    DeploymentSet.id == set_id,
                    DeploymentSet.owner_id == owner_id,
                )
                .first()
            )
        finally:
            session.close()

    # =========================================================================
    # List
    # =========================================================================

    def list(
        self,
        owner_id: str,
        *,
        name: Optional[str] = None,
        tag: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[DeploymentSet]:
        """Return a paginated, filterable list of DeploymentSets for an owner.

        Args:
            owner_id: Owning user / identity scope (always applied).
            name: Optional substring filter on ``DeploymentSet.name``
                (case-insensitive ``LIKE``).
            tag: Optional tag to filter by.  Matches if the tag string appears
                anywhere inside the JSON array stored in ``tags_json``.
            limit: Maximum number of rows to return (default 50).
            offset: Number of rows to skip for pagination (default 0).

        Returns:
            List of ``DeploymentSet`` instances ordered by ``created_at`` desc.
        """
        session = self._get_session()
        try:
            q = session.query(DeploymentSet).filter(DeploymentSet.owner_id == owner_id)
            if name is not None:
                q = q.filter(DeploymentSet.name.ilike(f"%{name}%"))
            if tag is not None:
                q = (
                    q.join(
                        DeploymentSetTag,
                        DeploymentSetTag.deployment_set_id == DeploymentSet.id,
                    )
                    .join(Tag, Tag.id == DeploymentSetTag.tag_id)
                    .filter(func.lower(Tag.name) == func.lower(tag))
                )
            return (
                q.order_by(DeploymentSet.created_at.desc())
                .limit(limit)
                .offset(offset)
                .all()
            )
        finally:
            session.close()

    # =========================================================================
    # Count
    # =========================================================================

    def count(
        self,
        owner_id: str,
        *,
        name: Optional[str] = None,
        tag: Optional[str] = None,
    ) -> int:
        """Count DeploymentSets matching the given filters for an owner.

        Args:
            owner_id: Owning user / identity scope (always applied).
            name: Optional substring filter on ``DeploymentSet.name``.
            tag: Optional tag filter (JSON LIKE match).

        Returns:
            Integer count of matching sets.
        """
        session = self._get_session()
        try:
            q = session.query(func.count(DeploymentSet.id)).filter(
                DeploymentSet.owner_id == owner_id
            )
            if name is not None:
                q = q.filter(DeploymentSet.name.ilike(f"%{name}%"))
            if tag is not None:
                q = (
                    q.join(
                        DeploymentSetTag,
                        DeploymentSetTag.deployment_set_id == DeploymentSet.id,
                    )
                    .join(Tag, Tag.id == DeploymentSetTag.tag_id)
                    .filter(func.lower(Tag.name) == func.lower(tag))
                )
            return q.scalar() or 0
        finally:
            session.close()

    # =========================================================================
    # Update
    # =========================================================================

    def update(
        self,
        set_id: str,
        owner_id: str,
        **kwargs: Any,
    ) -> Optional[DeploymentSet]:
        """Update mutable fields on a DeploymentSet.

        Only ``name``, ``description``, ``color``, ``icon``, and ``tags`` are
        writable.  ``updated_at`` is refreshed automatically on every
        successful update.

        Args:
            set_id: Primary key of the deployment set.
            owner_id: Owner scope — returns None if the set belongs to a
                different owner or does not exist.
            **kwargs: Keyword arguments for fields to update.  Supported
                keys: ``name`` (str), ``description`` (str | None),
                ``color`` (str | None), ``icon`` (str | None),
                ``tags`` (list[str]).

        Returns:
            Updated ``DeploymentSet`` instance, or ``None`` if not found.

        Raises:
            RepositoryError: If the update fails due to a constraint violation.
        """
        session = self._get_session()
        try:
            ds = (
                session.query(DeploymentSet)
                .filter(
                    DeploymentSet.id == set_id,
                    DeploymentSet.owner_id == owner_id,
                )
                .first()
            )
            if ds is None:
                return None

            if "name" in kwargs:
                ds.name = kwargs["name"]
            if "description" in kwargs:
                ds.description = kwargs["description"]
            if "color" in kwargs:
                ds.color = kwargs["color"]
            if "icon" in kwargs:
                ds.icon = kwargs["icon"]
            if "tags" in kwargs:
                self._sync_tags(session, ds.id, kwargs["tags"])

            ds.updated_at = datetime.utcnow()
            session.commit()
            session.refresh(ds)
            logger.debug("Updated DeploymentSet id=%s owner=%s", set_id, owner_id)
            return ds
        except IntegrityError as exc:
            session.rollback()
            raise RepositoryError(f"Failed to update DeploymentSet: {exc}") from exc
        finally:
            session.close()

    # =========================================================================
    # Delete  (FR-10)
    # =========================================================================

    def delete(self, set_id: str, owner_id: str) -> bool:
        """Delete a DeploymentSet, cleaning up cross-set member references first.

        FR-10 semantics: Before deleting the target set, any
        ``DeploymentSetMember`` rows in *other* sets that reference the
        target via ``member_set_id`` are deleted to prevent orphan
        references.  The target set's own members are removed by the
        ``CASCADE DELETE`` on ``deployment_set_members.set_id``.

        Args:
            set_id: Primary key of the deployment set to delete.
            owner_id: Owner scope — returns False if the set belongs to a
                different owner or does not exist.

        Returns:
            ``True`` if the set was found and deleted, ``False`` otherwise.

        Raises:
            RepositoryError: If the deletion fails unexpectedly.
        """
        session = self._get_session()
        try:
            ds = (
                session.query(DeploymentSet)
                .filter(
                    DeploymentSet.id == set_id,
                    DeploymentSet.owner_id == owner_id,
                )
                .first()
            )
            if ds is None:
                return False

            # FR-10: remove member rows in OTHER sets that reference this set
            # as a nested member before deleting the set itself.
            orphan_members = (
                session.query(DeploymentSetMember)
                .filter(
                    DeploymentSetMember.member_set_id == set_id,
                    DeploymentSetMember.set_id != set_id,
                )
                .all()
            )
            for member in orphan_members:
                session.delete(member)

            session.delete(ds)
            session.commit()
            logger.debug(
                "Deleted DeploymentSet id=%s owner=%s (removed %d orphan member refs)",
                set_id,
                owner_id,
                len(orphan_members),
            )
            return True
        except IntegrityError as exc:
            session.rollback()
            raise RepositoryError(f"Failed to delete DeploymentSet: {exc}") from exc
        finally:
            session.close()

    # =========================================================================
    # Member management
    # =========================================================================

    def add_member(
        self,
        set_id: str,
        owner_id: str,
        *,
        artifact_uuid: Optional[str] = None,
        group_id: Optional[str] = None,
        member_set_id: Optional[str] = None,
        position: Optional[int] = None,
    ) -> DeploymentSetMember:
        """Add a member to a DeploymentSet.

        Exactly one of ``artifact_uuid``, ``group_id``, or ``member_set_id``
        must be provided — this mirrors the DB CHECK constraint and produces
        a clear error before the row is even attempted.

        If ``position`` is omitted, the member is appended after the current
        maximum position (``max_position + 1``).  If the set has no existing
        members, position defaults to ``0``.

        Args:
            set_id: Primary key of the parent deployment set.
            owner_id: Owner scope — set must belong to this owner.
            artifact_uuid: Collection artifact UUID (ADR-007 stable identity).
            group_id: Artifact group id.
            member_set_id: Nested deployment set id.
            position: Explicit 0-based ordering position.  Auto-assigned
                when omitted.

        Returns:
            Newly created ``DeploymentSetMember`` instance.

        Raises:
            ValueError: If the exactly-one-ref constraint is violated, or if
                the parent set does not exist / belongs to a different owner.
            RepositoryError: If the insert fails due to a DB constraint.
        """
        # Repo-level guard: exactly one reference must be supplied.
        refs_provided = sum(
            [
                artifact_uuid is not None,
                group_id is not None,
                member_set_id is not None,
            ]
        )
        if refs_provided != 1:
            raise ValueError(
                "Exactly one of artifact_uuid, group_id, or member_set_id must be "
                f"provided (got {refs_provided} non-null values)."
            )

        session = self._get_session()
        try:
            # Verify parent set exists and is owned by owner_id.
            ds = (
                session.query(DeploymentSet)
                .filter(
                    DeploymentSet.id == set_id,
                    DeploymentSet.owner_id == owner_id,
                )
                .first()
            )
            if ds is None:
                raise ValueError(
                    f"DeploymentSet id={set_id!r} not found for owner {owner_id!r}."
                )

            # Auto-assign position when not supplied.
            if position is None:
                max_pos = (
                    session.query(func.max(DeploymentSetMember.position))
                    .filter(DeploymentSetMember.set_id == set_id)
                    .scalar()
                )
                position = 0 if max_pos is None else max_pos + 1

            member = DeploymentSetMember(
                set_id=set_id,
                artifact_uuid=artifact_uuid,
                group_id=group_id,
                member_set_id=member_set_id,
                position=position,
                created_at=datetime.utcnow(),
            )
            session.add(member)
            session.commit()
            session.refresh(member)
            logger.debug(
                "Added DeploymentSetMember id=%s to set=%s owner=%s position=%d",
                member.id,
                set_id,
                owner_id,
                position,
            )
            return member
        except IntegrityError as exc:
            session.rollback()
            raise RepositoryError(
                f"Failed to add member to DeploymentSet {set_id!r}: {exc}"
            ) from exc
        finally:
            session.close()

    def remove_member(self, member_id: str, owner_id: str) -> bool:
        """Remove a member from a DeploymentSet.

        The parent set must belong to ``owner_id``; if it does not, or if
        the member does not exist, ``False`` is returned without raising.

        Args:
            member_id: Primary key of the ``DeploymentSetMember`` to delete.
            owner_id: Owner scope — parent set must belong to this owner.

        Returns:
            ``True`` if the member was found and deleted, ``False`` otherwise.

        Raises:
            RepositoryError: If the deletion fails unexpectedly.
        """
        session = self._get_session()
        try:
            member = (
                session.query(DeploymentSetMember)
                .join(
                    DeploymentSet,
                    DeploymentSet.id == DeploymentSetMember.set_id,
                )
                .filter(
                    DeploymentSetMember.id == member_id,
                    DeploymentSet.owner_id == owner_id,
                )
                .first()
            )
            if member is None:
                return False

            session.delete(member)
            session.commit()
            logger.debug(
                "Removed DeploymentSetMember id=%s owner=%s", member_id, owner_id
            )
            return True
        except IntegrityError as exc:
            session.rollback()
            raise RepositoryError(
                f"Failed to remove DeploymentSetMember {member_id!r}: {exc}"
            ) from exc
        finally:
            session.close()

    def update_member_position(
        self, member_id: str, owner_id: str, position: int
    ) -> Optional[DeploymentSetMember]:
        """Update the ordering position of a DeploymentSetMember.

        The parent set must belong to ``owner_id``; if it does not, or if
        the member does not exist, ``None`` is returned.

        Args:
            member_id: Primary key of the ``DeploymentSetMember`` to update.
            owner_id: Owner scope — parent set must belong to this owner.
            position: New 0-based position value (must be >= 0).

        Returns:
            Updated ``DeploymentSetMember`` instance, or ``None`` if not found.

        Raises:
            RepositoryError: If the update fails due to a constraint violation.
        """
        session = self._get_session()
        try:
            member = (
                session.query(DeploymentSetMember)
                .join(
                    DeploymentSet,
                    DeploymentSet.id == DeploymentSetMember.set_id,
                )
                .filter(
                    DeploymentSetMember.id == member_id,
                    DeploymentSet.owner_id == owner_id,
                )
                .first()
            )
            if member is None:
                return None

            member.position = position
            session.commit()
            session.refresh(member)
            logger.debug(
                "Updated DeploymentSetMember id=%s position=%d owner=%s",
                member_id,
                position,
                owner_id,
            )
            return member
        except IntegrityError as exc:
            session.rollback()
            raise RepositoryError(
                f"Failed to update position for DeploymentSetMember {member_id!r}: {exc}"
            ) from exc
        finally:
            session.close()

    def get_members(self, set_id: str, owner_id: str) -> List[DeploymentSetMember]:
        """Return all members of a DeploymentSet, ordered by position.

        The set must belong to ``owner_id``; an empty list is returned if
        the set does not exist or belongs to a different owner.

        Args:
            set_id: Primary key of the parent deployment set.
            owner_id: Owner scope — set must belong to this owner.

        Returns:
            List of ``DeploymentSetMember`` instances ordered by
            ``position`` ascending.  Empty list when not found.
        """
        session = self._get_session()
        try:
            ds = (
                session.query(DeploymentSet)
                .filter(
                    DeploymentSet.id == set_id,
                    DeploymentSet.owner_id == owner_id,
                )
                .first()
            )
            if ds is None:
                return []

            return (
                session.query(DeploymentSetMember)
                .filter(DeploymentSetMember.set_id == set_id)
                .order_by(DeploymentSetMember.position)
                .all()
            )
        finally:
            session.close()


# =============================================================================
# CustomColorRepository
# =============================================================================

# Compiled regex for hex color validation (module-level for performance)
_HEX_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{3,6}$")


class CustomColorRepository(BaseRepository[CustomColor]):
    """Repository for user-defined custom color palette management.

    Provides CRUD operations for custom colors stored in the site-wide
    color registry. Each color is uniquely identified by its hex value
    and may carry an optional human-readable name.

    Hex values are validated against ``#[0-9a-fA-F]{3,6}$`` before any
    write operation; invalid values raise ``ValueError``.

    Usage:
        >>> repo = CustomColorRepository()
        >>>
        >>> # List all persisted colors
        >>> colors = repo.list_all()
        >>>
        >>> # Add a new color
        >>> color = repo.create("#7c3aed", name="Violet")
        >>>
        >>> # Update the name only
        >>> updated = repo.update(color.id, name="Purple")
        >>>
        >>> # Remove a color
        >>> repo.delete(color.id)
    """

    def __init__(self, db_path: Optional[str | Path] = None):
        """Initialize custom color repository.

        Args:
            db_path: Optional path to database file (uses default if None)
        """
        super().__init__(db_path, CustomColor)

    # =========================================================================
    # Internal helpers
    # =========================================================================

    @staticmethod
    def _validate_hex(hex_value: str) -> None:
        """Validate a CSS hex color string.

        Args:
            hex_value: Hex color to validate (e.g. ``#7c3aed``)

        Raises:
            ValueError: If the value does not match ``#[0-9a-fA-F]{3,6}$``
        """
        if not _HEX_COLOR_RE.match(hex_value):
            raise ValueError(f"Invalid hex color: {hex_value!r}")

    # =========================================================================
    # CRUD Operations
    # =========================================================================

    def list_all(self) -> List[CustomColor]:
        """Return all custom colors ordered by creation date (oldest first).

        Returns:
            List of ``CustomColor`` instances, may be empty.

        Example:
            >>> colors = repo.list_all()
            >>> for c in colors:
            ...     print(c.hex, c.name)
        """
        session = self._get_session()
        try:
            return session.query(CustomColor).order_by(CustomColor.created_at).all()
        finally:
            session.close()

    def create(self, hex: str, name: Optional[str] = None) -> CustomColor:
        """Create and persist a new custom color.

        Args:
            hex: CSS hex color string including the leading ``#``
                 (e.g. ``#7c3aed``).  Must match ``#[0-9a-fA-F]{3,6}$``.
            name: Optional human-readable label (max 64 characters).

        Returns:
            Newly created ``CustomColor`` instance.

        Raises:
            ValueError: If ``hex`` does not pass format validation.
            RepositoryError: If a color with the same hex already exists.

        Example:
            >>> color = repo.create("#7c3aed", name="Violet")
            >>> print(color.id)
        """
        self._validate_hex(hex)

        session = self._get_session()
        try:
            color = CustomColor(
                id=uuid.uuid4().hex,
                hex=hex,
                name=name,
                created_at=datetime.utcnow(),
            )

            session.add(color)
            session.commit()
            session.refresh(color)

            logger.info(f"Created custom color: {color.hex!r} (id={color.id})")
            return color

        except IntegrityError as e:
            session.rollback()
            raise RepositoryError(
                f"Custom color with hex {hex!r} already exists"
            ) from e
        finally:
            session.close()

    def update(
        self,
        id: str,
        hex: Optional[str] = None,
        name: Optional[str] = None,
    ) -> Optional[CustomColor]:
        """Update fields on an existing custom color.

        Only fields that are explicitly provided (not ``None``) are modified.
        If no color with ``id`` exists, ``None`` is returned.

        Args:
            id: Primary key of the color to update.
            hex: New hex value.  Must match ``#[0-9a-fA-F]{3,6}$`` when
                 provided.
            name: New human-readable label.  Pass an empty string to clear
                  an existing name.

        Returns:
            Updated ``CustomColor`` instance, or ``None`` if not found.

        Raises:
            ValueError: If ``hex`` is provided but fails format validation.
            RepositoryError: If the update violates a uniqueness constraint.

        Example:
            >>> updated = repo.update(color.id, name="Deep Purple")
            >>> if updated is None:
            ...     print("Color not found")
        """
        if hex is not None:
            self._validate_hex(hex)

        session = self._get_session()
        try:
            color = session.query(CustomColor).filter_by(id=id).first()
            if color is None:
                return None

            if hex is not None:
                color.hex = hex
            if name is not None:
                color.name = name

            session.commit()
            session.refresh(color)

            logger.info(f"Updated custom color id={id!r}")
            return color

        except IntegrityError as e:
            session.rollback()
            raise RepositoryError(
                f"Failed to update custom color id={id!r}: {e}"
            ) from e
        finally:
            session.close()

    def delete(self, id: str) -> bool:
        """Delete a custom color by its primary key.

        Args:
            id: Primary key of the color to delete.

        Returns:
            ``True`` if the color was found and deleted, ``False`` if no color
            with the given ``id`` exists.

        Example:
            >>> deleted = repo.delete(color.id)
            >>> print("Deleted" if deleted else "Not found")
        """
        session = self._get_session()
        try:
            color = session.query(CustomColor).filter_by(id=id).first()
            if color is None:
                return False

            session.delete(color)
            session.commit()

            logger.info(f"Deleted custom color id={id!r}")
            return True

        finally:
            session.close()


# =============================================================================
# Similar Artifacts
# =============================================================================


class DuplicatePairRepository(BaseRepository["DuplicatePair"]):
    """Repository for ``DuplicatePair`` similar-artifact records.

    Provides CRUD and dismissal operations for persisted pairwise similarity
    results.  The ``ignored`` flag lets users dismiss "not really a duplicate"
    suggestions without permanently deleting the pair record.

    Example:
        >>> repo = DuplicatePairRepository()
        >>> pair = repo.get_by_id("abc123")
        >>> repo.mark_pair_ignored(pair.id)
        >>> repo.unmark_pair_ignored(pair.id)
    """

    def __init__(self, db_path: Optional[str | Path] = None) -> None:
        """Initialise with optional path to the SQLite DB.

        Args:
            db_path: Path to the SQLite database file.  Defaults to
                     ``~/.skillmeat/cache/cache.db`` when ``None``.
        """
        from skillmeat.cache.models import DuplicatePair as _DuplicatePair

        super().__init__(db_path, _DuplicatePair)

    # ------------------------------------------------------------------
    # Read helpers
    # ------------------------------------------------------------------

    def get_by_id(self, pair_id: str) -> Optional["DuplicatePair"]:
        """Return the ``DuplicatePair`` with the given primary key, or ``None``.

        Args:
            pair_id: Primary key (UUID hex string) of the pair record.

        Returns:
            The matching ``DuplicatePair`` row, or ``None`` if not found.

        Example:
            >>> pair = repo.get_by_id("abc123")
            >>> print(pair.similarity_score if pair else "not found")
        """
        from skillmeat.cache.models import DuplicatePair

        session = self._get_session()
        try:
            return session.query(DuplicatePair).filter_by(id=pair_id).first()
        finally:
            session.close()

    def list_active(self, min_score: float = 0.0) -> List["DuplicatePair"]:
        """Return all non-ignored pairs whose score is >= ``min_score``.

        Pairs are returned ordered by ``similarity_score`` descending.

        Args:
            min_score: Minimum similarity score threshold (default 0.0, i.e.
                       all non-ignored pairs).

        Returns:
            List of ``DuplicatePair`` instances, may be empty.

        Example:
            >>> pairs = repo.list_active(min_score=0.5)
            >>> for p in pairs:
            ...     print(p.artifact1_uuid, p.artifact2_uuid, p.similarity_score)
        """
        from skillmeat.cache.models import DuplicatePair

        session = self._get_session()
        try:
            return (
                session.query(DuplicatePair)
                .filter(
                    DuplicatePair.ignored.is_(False),
                    DuplicatePair.similarity_score >= min_score,
                )
                .order_by(DuplicatePair.similarity_score.desc())
                .all()
            )
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Dismissal helpers
    # ------------------------------------------------------------------

    def mark_pair_ignored(self, pair_id: str) -> bool:
        """Set ``ignored=True`` on the ``DuplicatePair`` identified by ``pair_id``.

        Idempotent: if the pair is already ignored the call still succeeds and
        returns ``True``.

        Args:
            pair_id: Primary key (UUID hex string) of the pair record.

        Returns:
            ``True`` when the pair was found and updated (or was already
            ignored), ``False`` when no pair with ``pair_id`` exists.

        Raises:
            RepositoryError: On unexpected database errors.

        Example:
            >>> success = repo.mark_pair_ignored("abc123")
            >>> print("dismissed" if success else "not found")
        """
        from skillmeat.cache.models import DuplicatePair

        session = self._get_session()
        try:
            pair = session.query(DuplicatePair).filter_by(id=pair_id).first()
            if pair is None:
                logger.debug(
                    "DuplicatePairRepository.mark_pair_ignored: "
                    "pair id=%r not found.",
                    pair_id,
                )
                return False

            pair.ignored = True
            session.commit()

            logger.info(
                "DuplicatePairRepository: marked pair id=%r as ignored.", pair_id
            )
            return True

        except IntegrityError as exc:
            session.rollback()
            raise RepositoryError(
                f"Failed to mark pair id={pair_id!r} as ignored: {exc}"
            ) from exc
        finally:
            session.close()

    def unmark_pair_ignored(self, pair_id: str) -> bool:
        """Set ``ignored=False`` on the ``DuplicatePair`` identified by ``pair_id``.

        Idempotent: if the pair is already active (not ignored) the call still
        succeeds and returns ``True``.

        Args:
            pair_id: Primary key (UUID hex string) of the pair record.

        Returns:
            ``True`` when the pair was found and updated (or was already
            active), ``False`` when no pair with ``pair_id`` exists.

        Raises:
            RepositoryError: On unexpected database errors.

        Example:
            >>> repo.mark_pair_ignored("abc123")
            True
            >>> repo.unmark_pair_ignored("abc123")
            True
        """
        from skillmeat.cache.models import DuplicatePair

        session = self._get_session()
        try:
            pair = session.query(DuplicatePair).filter_by(id=pair_id).first()
            if pair is None:
                logger.debug(
                    "DuplicatePairRepository.unmark_pair_ignored: "
                    "pair id=%r not found.",
                    pair_id,
                )
                return False

            pair.ignored = False
            session.commit()

            logger.info(
                "DuplicatePairRepository: unmarked pair id=%r (now active).",
                pair_id,
            )
            return True

        except IntegrityError as exc:
            session.rollback()
            raise RepositoryError(
                f"Failed to unmark pair id={pair_id!r}: {exc}"
            ) from exc
        finally:
            session.close()

    def list_pairs_for_artifact(self, artifact_uuid: str) -> List["DuplicatePair"]:
        """Return all non-ignored ``DuplicatePair`` rows involving *artifact_uuid*.

        Returns pairs where ``artifact1_uuid`` or ``artifact2_uuid`` matches the
        given UUID and ``ignored`` is ``False``.

        Args:
            artifact_uuid: Stable hex UUID of the artifact.

        Returns:
            List of ``DuplicatePair`` instances (may be empty).
        """
        from skillmeat.cache.models import DuplicatePair

        session = self._get_session()
        try:
            return (
                session.query(DuplicatePair)
                .filter(
                    DuplicatePair.ignored.is_(False),
                    (DuplicatePair.artifact1_uuid == artifact_uuid)
                    | (DuplicatePair.artifact2_uuid == artifact_uuid),
                )
                .all()
            )
        finally:
            session.close()


# =============================================================================
# DbUserCollectionRepository
# =============================================================================


def _collection_to_dto(
    collection: Collection, artifact_count: int = 0
) -> UserCollectionDTO:
    """Convert a Collection ORM row to a UserCollectionDTO.

    Args:
        collection: SQLAlchemy ``Collection`` ORM instance.
        artifact_count: Pre-computed artifact count for the collection.
            Defaults to 0 when not explicitly provided.

    Returns:
        A frozen :class:`~skillmeat.core.interfaces.dtos.UserCollectionDTO`.
    """
    return UserCollectionDTO(
        id=collection.id,
        name=collection.name,
        description=collection.description,
        created_by=collection.created_by,
        collection_type=collection.collection_type,
        context_category=collection.context_category,
        created_at=(
            collection.created_at.isoformat() if collection.created_at else None
        ),
        updated_at=(
            collection.updated_at.isoformat() if collection.updated_at else None
        ),
        artifact_count=artifact_count,
    )


class DbUserCollectionRepository(
    BaseRepository[Collection], IDbUserCollectionRepository
):
    """DB-backed implementation of :class:`IDbUserCollectionRepository`.

    Stores and retrieves user collections from the ``collections`` table via
    SQLAlchemy.  All methods follow the session-per-operation pattern used
    throughout this module: a fresh session is obtained at the start of each
    call and closed in a ``finally`` block, with ``commit``/``rollback`` for
    mutations.

    Args:
        db_path: Optional path to the SQLite database file.  Defaults to the
            standard ``~/.skillmeat/cache/cache.db`` location.

    Example:
        >>> repo = DbUserCollectionRepository()
        >>> coll = repo.create(name="My Collection", created_by="alice")
        >>> repo.get_by_id(coll.id)
        UserCollectionDTO(id=..., name='My Collection', ...)
    """

    def __init__(self, db_path: Optional[str | Path] = None) -> None:
        """Initialise the repository bound to the given database file."""
        super().__init__(db_path, Collection)

    # ------------------------------------------------------------------
    # Collection queries
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        created_by: Optional[str] = None,
        collection_type: Optional[str] = None,
        context_category: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        ctx: Optional[RequestContext] = None,
    ) -> List[UserCollectionDTO]:
        """Return a filtered, paginated list of user collections.

        Args:
            created_by: When provided, return only collections owned by this
                user/agent identifier.
            collection_type: When provided, restrict to collections of this
                type string.
            context_category: When provided, restrict to collections tagged
                with this context category string.
            limit: Maximum number of records to return.
            offset: Zero-based record offset for pagination.
            ctx: Optional per-request metadata (ignored).

        Returns:
            A (possibly empty) list of :class:`UserCollectionDTO` objects.
        """
        session = self._get_session()
        try:
            query = session.query(Collection)
            if created_by is not None:
                query = query.filter(Collection.created_by == created_by)
            if collection_type is not None:
                query = query.filter(Collection.collection_type == collection_type)
            if context_category is not None:
                query = query.filter(Collection.context_category == context_category)
            rows = (
                query.order_by(Collection.created_at.desc())
                .limit(limit)
                .offset(offset)
                .all()
            )
            return [_collection_to_dto(row) for row in rows]
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Single-item lookup
    # ------------------------------------------------------------------

    def get_by_id(
        self,
        collection_id: str,
        ctx: Optional[RequestContext] = None,
    ) -> Optional[UserCollectionDTO]:
        """Return a user collection by its UUID hex primary key.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.

        Returns:
            A :class:`UserCollectionDTO` when found, ``None`` otherwise.
        """
        session = self._get_session()
        try:
            row = session.query(Collection).filter_by(id=collection_id).first()
            if row is None:
                return None
            count = (
                session.query(func.count(CollectionArtifact.artifact_uuid))
                .filter(CollectionArtifact.collection_id == collection_id)
                .scalar()
                or 0
            )
            return _collection_to_dto(row, artifact_count=count)
        finally:
            session.close()

    def get_by_name(
        self,
        name: str,
        ctx: Optional[RequestContext] = None,
    ) -> Optional[UserCollectionDTO]:
        """Return a user collection by its human-readable name.

        Args:
            name: Collection name string (case-sensitive).
            ctx: Optional per-request metadata.

        Returns:
            A :class:`UserCollectionDTO` when found, ``None`` otherwise.
        """
        session = self._get_session()
        try:
            row = session.query(Collection).filter(Collection.name == name).first()
            if row is None:
                return None
            count = (
                session.query(func.count(CollectionArtifact.artifact_uuid))
                .filter(CollectionArtifact.collection_id == row.id)
                .scalar()
                or 0
            )
            return _collection_to_dto(row, artifact_count=count)
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    def create(
        self,
        *,
        name: str,
        description: Optional[str] = None,
        created_by: Optional[str] = None,
        collection_type: Optional[str] = None,
        context_category: Optional[str] = None,
        ctx: Optional[RequestContext] = None,
    ) -> UserCollectionDTO:
        """Persist a new user collection and return the stored representation.

        Args:
            name: Human-readable collection name.
            description: Optional free-text description.
            created_by: Optional owner identifier.
            collection_type: Optional type discriminator.
            context_category: Optional context category tag.
            ctx: Optional per-request metadata.

        Returns:
            The persisted :class:`UserCollectionDTO`.

        Raises:
            ValueError: If *name* is empty or a collection with the same name
                already exists for the given *created_by*.
            RuntimeError: On any other database error.
        """
        if not name or not name.strip():
            raise ValueError("Collection name must not be empty.")

        session = self._get_session()
        try:
            existing_query = session.query(Collection).filter(Collection.name == name)
            if created_by is not None:
                existing_query = existing_query.filter(
                    Collection.created_by == created_by
                )
            if existing_query.first() is not None:
                raise ValueError(
                    f"A collection named {name!r} already exists"
                    + (f" for owner {created_by!r}" if created_by else "")
                    + "."
                )

            row = Collection(
                id=uuid.uuid4().hex,
                name=name,
                description=description,
                created_by=created_by,
                collection_type=collection_type,
                context_category=context_category,
            )
            session.add(row)
            session.commit()
            session.refresh(row)

            logger.info(
                "DbUserCollectionRepository: created collection id=%r name=%r.",
                row.id,
                row.name,
            )
            return _collection_to_dto(row)

        except ValueError:
            session.rollback()
            raise
        except Exception as exc:
            session.rollback()
            raise RuntimeError(f"Failed to create collection {name!r}: {exc}") from exc
        finally:
            session.close()

    def update(
        self,
        collection_id: str,
        ctx: Optional[RequestContext] = None,
        **kwargs: Any,
    ) -> UserCollectionDTO:
        """Apply a partial update to an existing user collection.

        Recognised keys: ``name``, ``description``, ``collection_type``,
        ``context_category``.  Unknown keys are silently ignored.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.
            **kwargs: Field names mapped to new values.

        Returns:
            The updated :class:`UserCollectionDTO`.

        Raises:
            KeyError: If no collection with *collection_id* exists.
            RuntimeError: On any other database error.
        """
        _UPDATABLE = {"name", "description", "collection_type", "context_category"}
        session = self._get_session()
        try:
            row = session.query(Collection).filter_by(id=collection_id).first()
            if row is None:
                raise KeyError(f"Collection with id={collection_id!r} not found.")

            for field_name, value in kwargs.items():
                if field_name in _UPDATABLE:
                    setattr(row, field_name, value)

            row.updated_at = datetime.utcnow()
            session.commit()
            session.refresh(row)

            count = (
                session.query(func.count(CollectionArtifact.artifact_uuid))
                .filter(CollectionArtifact.collection_id == collection_id)
                .scalar()
                or 0
            )

            logger.info(
                "DbUserCollectionRepository: updated collection id=%r.",
                collection_id,
            )
            return _collection_to_dto(row, artifact_count=count)

        except KeyError:
            session.rollback()
            raise
        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to update collection id={collection_id!r}: {exc}"
            ) from exc
        finally:
            session.close()

    def delete(
        self,
        collection_id: str,
        ctx: Optional[RequestContext] = None,
    ) -> bool:
        """Delete a user collection and all its membership records.

        Does not delete artifact files — only removes the DB collection record
        and associated ``CollectionArtifact`` rows (via cascade).

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the collection was found and deleted, ``False``
            when no matching record existed.

        Raises:
            RuntimeError: On unexpected database errors.
        """
        session = self._get_session()
        try:
            row = session.query(Collection).filter_by(id=collection_id).first()
            if row is None:
                logger.debug(
                    "DbUserCollectionRepository.delete: id=%r not found.",
                    collection_id,
                )
                return False

            session.delete(row)
            session.commit()

            logger.info(
                "DbUserCollectionRepository: deleted collection id=%r.",
                collection_id,
            )
            return True

        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to delete collection id={collection_id!r}: {exc}"
            ) from exc
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Default collection management
    # ------------------------------------------------------------------

    def ensure_default(
        self,
        *,
        created_by: Optional[str] = None,
        ctx: Optional[RequestContext] = None,
    ) -> UserCollectionDTO:
        """Return the default collection, creating it if it does not exist.

        Searches for a collection of type ``"default"`` owned by *created_by*.
        When none exists a new one is created atomically.

        Args:
            created_by: Optional owner identifier.
            ctx: Optional per-request metadata.

        Returns:
            The existing or newly created default :class:`UserCollectionDTO`.

        Raises:
            RuntimeError: On unexpected database errors.
        """
        session = self._get_session()
        try:
            query = session.query(Collection).filter(
                Collection.collection_type == "default"
            )
            if created_by is not None:
                query = query.filter(Collection.created_by == created_by)

            row = query.first()
            if row is not None:
                return _collection_to_dto(row)

            row = Collection(
                id=uuid.uuid4().hex,
                name="Default Collection",
                description="Default artifact collection",
                created_by=created_by,
                collection_type="default",
                context_category=None,
            )
            session.add(row)
            session.commit()
            session.refresh(row)

            logger.info(
                "DbUserCollectionRepository: created default collection id=%r "
                "for owner=%r.",
                row.id,
                created_by,
            )
            return _collection_to_dto(row)

        except Exception as exc:
            session.rollback()
            raise RuntimeError(f"Failed to ensure default collection: {exc}") from exc
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Enriched queries
    # ------------------------------------------------------------------

    def list_with_artifact_stats(
        self,
        *,
        created_by: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        ctx: Optional[RequestContext] = None,
    ) -> List[UserCollectionDTO]:
        """Return collections with ``artifact_count`` populated.

        Performs an aggregation join against ``CollectionArtifact`` so the
        returned DTOs carry up-to-date counts without additional round-trips.

        Args:
            created_by: When provided, return only collections owned by this
                identifier.
            limit: Maximum number of records to return.
            offset: Zero-based record offset for pagination.
            ctx: Optional per-request metadata.

        Returns:
            A (possibly empty) list of :class:`UserCollectionDTO` objects
            with ``artifact_count`` set.
        """
        session = self._get_session()
        try:
            count_subq = (
                session.query(
                    CollectionArtifact.collection_id,
                    func.count(CollectionArtifact.artifact_uuid).label(
                        "artifact_count"
                    ),
                )
                .group_by(CollectionArtifact.collection_id)
                .subquery()
            )

            query = session.query(
                Collection,
                func.coalesce(count_subq.c.artifact_count, 0).label("artifact_count"),
            ).outerjoin(
                count_subq,
                Collection.id == count_subq.c.collection_id,
            )

            if created_by is not None:
                query = query.filter(Collection.created_by == created_by)

            rows = (
                query.order_by(Collection.created_at.desc())
                .limit(limit)
                .offset(offset)
                .all()
            )

            return [
                _collection_to_dto(row, artifact_count=count) for row, count in rows
            ]
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Group associations
    # ------------------------------------------------------------------

    def add_group(
        self,
        collection_id: str,
        group_id: str,
        ctx: Optional[RequestContext] = None,
    ) -> bool:
        """Associate an existing group with a user collection.

        Idempotent: associating a group that is already linked returns ``True``.

        Args:
            collection_id: Collection hex-UUID primary key.
            group_id: Group identifier to associate.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` on success (including when the association already existed),
            ``False`` when *collection_id* or *group_id* does not exist.

        Raises:
            RuntimeError: On unexpected database errors.
        """
        session = self._get_session()
        try:
            collection = session.query(Collection).filter_by(id=collection_id).first()
            if collection is None:
                logger.debug(
                    "DbUserCollectionRepository.add_group: "
                    "collection id=%r not found.",
                    collection_id,
                )
                return False

            group = session.query(Group).filter_by(id=group_id).first()
            if group is None:
                logger.debug(
                    "DbUserCollectionRepository.add_group: " "group id=%r not found.",
                    group_id,
                )
                return False

            # Already associated — idempotent success
            if group.collection_id == collection_id:
                return True

            group.collection_id = collection_id
            group.updated_at = datetime.utcnow()
            session.commit()

            logger.info(
                "DbUserCollectionRepository: associated group id=%r "
                "with collection id=%r.",
                group_id,
                collection_id,
            )
            return True

        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to add group id={group_id!r} to collection "
                f"id={collection_id!r}: {exc}"
            ) from exc
        finally:
            session.close()

    def remove_group(
        self,
        collection_id: str,
        group_id: str,
        ctx: Optional[RequestContext] = None,
    ) -> bool:
        """Disassociate a group from a user collection.

        Args:
            collection_id: Collection hex-UUID primary key.
            group_id: Group identifier to remove.
            ctx: Optional per-request metadata.

        Returns:
            ``True`` when the association existed and was removed, ``False``
            if the association was not found.

        Raises:
            RuntimeError: On unexpected database errors.
        """
        session = self._get_session()
        try:
            group = (
                session.query(Group)
                .filter(
                    Group.id == group_id,
                    Group.collection_id == collection_id,
                )
                .first()
            )
            if group is None:
                logger.debug(
                    "DbUserCollectionRepository.remove_group: "
                    "association (collection=%r, group=%r) not found.",
                    collection_id,
                    group_id,
                )
                return False

            session.delete(group)
            session.commit()

            logger.info(
                "DbUserCollectionRepository: removed group id=%r "
                "from collection id=%r.",
                group_id,
                collection_id,
            )
            return True

        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to remove group id={group_id!r} from collection "
                f"id={collection_id!r}: {exc}"
            ) from exc
        finally:
            session.close()

    def get_groups(
        self,
        collection_id: str,
        ctx: Optional[RequestContext] = None,
    ) -> List[str]:
        """Return the identifiers of all groups associated with a collection.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.

        Returns:
            List of group identifier strings.  Returns an empty list when the
            collection does not exist or has no group associations.
        """
        session = self._get_session()
        try:
            rows = (
                session.query(Group.id)
                .filter(Group.collection_id == collection_id)
                .order_by(Group.position, Group.created_at)
                .all()
            )
            return [row.id for row in rows]
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Aggregate helpers
    # ------------------------------------------------------------------

    def get_artifact_count(
        self,
        collection_id: str,
        ctx: Optional[RequestContext] = None,
    ) -> int:
        """Return the number of artifacts currently in a collection.

        Args:
            collection_id: Collection hex-UUID primary key.
            ctx: Optional per-request metadata.

        Returns:
            Non-negative integer artifact count.  Returns ``0`` when the
            collection does not exist.
        """
        session = self._get_session()
        try:
            count = (
                session.query(func.count(CollectionArtifact.artifact_uuid))
                .filter(CollectionArtifact.collection_id == collection_id)
                .scalar()
            )
            return int(count or 0)
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Sentinel project bootstrap
    # ------------------------------------------------------------------

    def ensure_sentinel_project(self) -> None:
        """Ensure the sentinel Project row used by collection artifacts exists.

        Artifact rows require a ``project_id`` foreign-key.  Collection-level
        (filesystem) artifacts are not tied to any deployed project, so a
        sentinel project satisfies the constraint.  This method is idempotent.
        """
        from skillmeat.cache.models import Project as _Project

        _SENTINEL_ID = "collection_artifacts_global"

        session = self._get_session()
        try:
            existing = session.query(_Project).filter_by(id=_SENTINEL_ID).first()
            if existing:
                return

            sentinel = _Project(
                id=_SENTINEL_ID,
                name="Collection Artifacts",
                path="~/.skillmeat/collections",
                description="Sentinel project for filesystem collection artifacts",
                status="active",
            )
            session.add(sentinel)
            session.commit()
            logger.debug(
                "DbUserCollectionRepository.ensure_sentinel_project: "
                "created sentinel project id=%r",
                _SENTINEL_ID,
            )
        except Exception as exc:
            session.rollback()
            logger.warning(
                "DbUserCollectionRepository.ensure_sentinel_project: failed: %s",
                exc,
            )
        finally:
            session.close()


# =============================================================================
# DbCollectionArtifactRepository
# =============================================================================


def _collection_artifact_to_dto(ca: Any) -> CollectionArtifactDTO:
    """Convert a :class:`~skillmeat.cache.models.CollectionArtifact` ORM row
    to an immutable :class:`CollectionArtifactDTO`.

    Handles JSON deserialisation of ``tags_json``, ``tools_json``, and
    ``deployments_json`` columns gracefully: ``None``, empty string, and
    invalid JSON all produce an empty list.

    Args:
        ca: A :class:`~skillmeat.cache.models.CollectionArtifact` ORM instance.

    Returns:
        A fully-populated :class:`CollectionArtifactDTO`.
    """

    def _safe_json_list(raw: Any) -> list[str]:
        """Return a ``list[str]`` from a JSON string, a list, or ``None``."""
        if raw is None:
            return []
        if isinstance(raw, list):
            return [str(x) for x in raw]
        if isinstance(raw, str) and raw.strip():
            try:
                parsed = json.loads(raw)
                return [str(x) for x in parsed] if isinstance(parsed, list) else []
            except (json.JSONDecodeError, TypeError):
                return []
        return []

    def _safe_json_raw(raw: Any) -> list:
        """Return a list from a JSON string, a list, or ``None`` — without str coercion.

        Unlike :func:`_safe_json_list`, this preserves the original element
        types (dicts, ints, etc.) so that callers such as ``parse_deployments``
        can call ``.get()`` on the resulting items.
        """
        if raw is None:
            return []
        if isinstance(raw, list):
            return list(raw)
        if isinstance(raw, str) and raw.strip():
            try:
                parsed = json.loads(raw)
                return list(parsed) if isinstance(parsed, list) else []
            except (json.JSONDecodeError, TypeError):
                return []
        return []

    added = ca.added_at
    synced = ca.synced_at
    return CollectionArtifactDTO(
        collection_id=str(ca.collection_id),
        artifact_uuid=str(ca.artifact_uuid),
        added_at=(
            added.isoformat()
            if added and hasattr(added, "isoformat")
            else (added if isinstance(added, str) else None)
        ),
        description=ca.description,
        author=ca.author,
        license=ca.license,
        tags=_safe_json_list(ca.tags_json),
        tools=_safe_json_list(ca.tools_json),
        deployments=_safe_json_raw(ca.deployments_json),
        artifact_content_hash=ca.artifact_content_hash,
        artifact_structure_hash=ca.artifact_structure_hash,
        artifact_file_count=(
            int(ca.artifact_file_count) if ca.artifact_file_count is not None else None
        ),
        artifact_total_size=(
            int(ca.artifact_total_size) if ca.artifact_total_size is not None else None
        ),
        source=ca.source,
        origin=ca.origin,
        resolved_sha=ca.resolved_sha,
        resolved_version=ca.resolved_version,
        synced_at=(
            synced.isoformat()
            if synced and hasattr(synced, "isoformat")
            else (synced if isinstance(synced, str) else None)
        ),
    )


class DbCollectionArtifactRepository(IDbCollectionArtifactRepository):
    """DB-backed implementation of :class:`IDbCollectionArtifactRepository`.

    Persists collection–artifact associations via the SQLAlchemy ORM against
    the ``collection_artifacts`` join table.

    Session lifecycle follows the canonical pattern used throughout
    ``skillmeat/cache/repositories.py``:

    * Each public method obtains a session via ``self._get_session()``.
    * A ``try/finally`` block guarantees ``session.close()`` on every exit
      path.
    * Mutations call ``session.commit()`` on success and ``session.rollback()``
      before re-raising on error.
    * The repository never raises :class:`HTTPException` — callers are
      responsible for mapping domain exceptions to HTTP responses.

    Args:
        get_session: Zero-argument callable that returns a SQLAlchemy
            :class:`~sqlalchemy.orm.Session`.  Defaults to the module-level
            ``get_session`` singleton from :mod:`skillmeat.cache.models`.
    """

    def __init__(self, get_session: Any = None) -> None:
        from skillmeat.cache.models import get_session as _default_get_session

        self._get_session = (
            get_session if get_session is not None else _default_get_session
        )

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def list_by_collection(
        self,
        collection_id: str,
        *,
        limit: int = 50,
        offset: int = 0,
        search: str | None = None,
        artifact_type: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Return a paginated list of artifact memberships for a collection.

        Args:
            collection_id: Unique identifier of the owning user collection.
            limit: Maximum number of records to return (default 50).
            offset: Zero-based pagination offset (default 0).
            search: Optional free-text search applied to artifact name or
                description fields (matched against ``CollectionArtifact.description``
                and ``Artifact.id``).
            artifact_type: Optional artifact type filter applied via an inner join
                to the ``artifacts`` table (e.g. ``"skill"``).
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            A (possibly empty) list of :class:`CollectionArtifactDTO` objects.
        """
        session = self._get_session()
        try:
            query = session.query(CollectionArtifact).filter(
                CollectionArtifact.collection_id == collection_id
            )

            if search or artifact_type:
                query = query.join(
                    Artifact,
                    Artifact.uuid == CollectionArtifact.artifact_uuid,
                )
                if search:
                    like = f"%{search}%"
                    query = query.filter(
                        or_(
                            CollectionArtifact.description.ilike(like),
                            Artifact.id.ilike(like),
                        )
                    )
                if artifact_type:
                    # Artifact.id is "type:name" — filter by prefix
                    query = query.filter(Artifact.id.like(f"{artifact_type}:%"))

            rows = query.offset(offset).limit(limit).all()
            logger.debug(
                "DbCollectionArtifactRepository.list_by_collection: "
                "collection=%s limit=%d offset=%d → %d rows",
                collection_id,
                limit,
                offset,
                len(rows),
            )
            return [_collection_artifact_to_dto(row) for row in rows]
        finally:
            session.close()

    def get_by_pk(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
    ) -> CollectionArtifactDTO | None:
        """Return a single membership record by composite primary key.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuid: Stable 32-char hex UUID of the artifact.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            :class:`CollectionArtifactDTO` when the membership exists,
            ``None`` otherwise.
        """
        session = self._get_session()
        try:
            row = (
                session.query(CollectionArtifact)
                .filter_by(collection_id=collection_id, artifact_uuid=artifact_uuid)
                .first()
            )
            if row is None:
                return None
            return _collection_artifact_to_dto(row)
        finally:
            session.close()

    def count_by_collection(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> int:
        """Return the total number of artifact memberships in a collection.

        Args:
            collection_id: Unique identifier of the user collection.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            Non-negative integer count.
        """
        session = self._get_session()
        try:
            count = (
                session.query(func.count(CollectionArtifact.artifact_uuid))
                .filter(CollectionArtifact.collection_id == collection_id)
                .scalar()
            )
            return int(count or 0)
        finally:
            session.close()

    def list_with_tags(
        self,
        collection_id: str,
        *,
        tag: str | None = None,
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Return collection artifact memberships, optionally filtered by tag.

        The ``tags_json`` column stores a JSON-encoded list of tag strings.
        When *tag* is provided this method does a substring match on the raw
        JSON column, which is fast and avoids a full deserialisation pass on
        every row.

        Args:
            collection_id: Unique identifier of the user collection.
            tag: Optional tag name to filter by.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            List of :class:`CollectionArtifactDTO` objects (possibly empty).
        """
        session = self._get_session()
        try:
            query = session.query(CollectionArtifact).filter(
                CollectionArtifact.collection_id == collection_id
            )
            if tag:
                # Substring match on the JSON column — cheap and sufficient for
                # tags that don't contain special JSON characters.
                query = query.filter(CollectionArtifact.tags_json.ilike(f'%"{tag}"%'))
            rows = query.all()
            logger.debug(
                "DbCollectionArtifactRepository.list_with_tags: "
                "collection=%s tag=%r → %d rows",
                collection_id,
                tag,
                len(rows),
            )
            return [_collection_artifact_to_dto(row) for row in rows]
        finally:
            session.close()

    def list_deployment_info(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Return collection memberships enriched with deployment tracking data.

        Filters to rows that have a non-null ``deployments_json`` column so
        that callers receive only artifacts that carry deployment information.

        Args:
            collection_id: Unique identifier of the user collection.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            List of :class:`CollectionArtifactDTO` objects with deployment
            fields populated.
        """
        session = self._get_session()
        try:
            rows = (
                session.query(CollectionArtifact)
                .filter(
                    CollectionArtifact.collection_id == collection_id,
                    CollectionArtifact.deployments_json.isnot(None),
                )
                .all()
            )
            logger.debug(
                "DbCollectionArtifactRepository.list_deployment_info: "
                "collection=%s → %d rows with deployment data",
                collection_id,
                len(rows),
            )
            return [_collection_artifact_to_dto(row) for row in rows]
        finally:
            session.close()

    def get_source_deployments_batch(
        self,
        artifact_ids: list[str],
        ctx: RequestContext | None = None,
    ) -> list[dict]:
        """Return source and deployments_json for a batch of artifact IDs.

        Executes a single JOIN query against the ``artifacts`` and
        ``collection_artifacts`` tables to retrieve the ``source`` and
        ``deployments_json`` columns for the given ``type:name`` artifact
        identifiers.

        Args:
            artifact_ids: List of ``"type:name"`` artifact identifier strings.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            List of dicts with keys ``id`` (``type:name`` string), ``source``
            (upstream source spec or ``None``), and ``deployments_json`` (raw
            JSON string or ``None``).  Only artifacts with a matching
            ``CollectionArtifact`` row are included.
        """
        if not artifact_ids:
            return []
        session = self._get_session()
        try:
            rows = (
                session.query(
                    Artifact.id,
                    CollectionArtifact.source,
                    CollectionArtifact.deployments_json,
                )
                .join(
                    CollectionArtifact,
                    CollectionArtifact.artifact_uuid == Artifact.uuid,
                )
                .filter(Artifact.id.in_(artifact_ids))
                .all()
            )
            logger.debug(
                "DbCollectionArtifactRepository.get_source_deployments_batch: "
                "%d ids → %d rows",
                len(artifact_ids),
                len(rows),
            )
            return [
                {"id": row[0], "source": row[1], "deployments_json": row[2]}
                for row in rows
            ]
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    def add_artifacts(
        self,
        collection_id: str,
        artifact_uuids: list[str],
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Add one or more artifacts to a collection by UUID.

        Idempotent: artifacts already present in the collection are silently
        skipped rather than duplicated.  The entire batch is committed as a
        single transaction — if any insertion fails the whole batch is rolled
        back.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuids: List of stable 32-char hex UUIDs to add.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            List of created (or pre-existing)
            :class:`CollectionArtifactDTO` records for the given UUIDs.

        Raises:
            KeyError: If *collection_id* does not correspond to a known
                user collection.
            ValueError: If any UUID in *artifact_uuids* is unknown.
            RuntimeError: On unexpected database errors.
        """
        if not artifact_uuids:
            return []

        session = self._get_session()
        try:
            # Validate collection exists
            collection = session.query(Collection).filter_by(id=collection_id).first()
            if collection is None:
                raise KeyError(f"Collection '{collection_id}' not found")

            # Validate all UUIDs exist
            existing_artifacts = (
                session.query(Artifact).filter(Artifact.uuid.in_(artifact_uuids)).all()
            )
            found_uuids = {a.uuid for a in existing_artifacts}
            missing = set(artifact_uuids) - found_uuids
            if missing:
                raise ValueError(
                    f"Unknown artifact UUIDs: {', '.join(sorted(missing))}"
                )

            # Fetch already-present memberships
            already_present = {
                row.artifact_uuid
                for row in session.query(CollectionArtifact)
                .filter(
                    CollectionArtifact.collection_id == collection_id,
                    CollectionArtifact.artifact_uuid.in_(artifact_uuids),
                )
                .all()
            }

            # Insert only new memberships
            new_uuids = [u for u in artifact_uuids if u not in already_present]
            for artifact_uuid in new_uuids:
                ca = CollectionArtifact(
                    collection_id=collection_id,
                    artifact_uuid=artifact_uuid,
                    added_at=datetime.utcnow(),
                )
                session.add(ca)

            session.commit()

            # Return DTOs for all requested UUIDs (existing + newly added)
            rows = (
                session.query(CollectionArtifact)
                .filter(
                    CollectionArtifact.collection_id == collection_id,
                    CollectionArtifact.artifact_uuid.in_(artifact_uuids),
                )
                .all()
            )
            logger.info(
                "DbCollectionArtifactRepository.add_artifacts: "
                "collection=%s added=%d total=%d",
                collection_id,
                len(new_uuids),
                len(rows),
            )
            return [_collection_artifact_to_dto(row) for row in rows]

        except (KeyError, ValueError):
            session.rollback()
            raise
        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to add artifacts to collection '{collection_id}': {exc}"
            ) from exc
        finally:
            session.close()

    def remove_artifact(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
    ) -> bool:
        """Remove a single artifact from a collection.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuid: Stable 32-char hex UUID of the artifact to remove.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            ``True`` when the membership was found and removed,
            ``False`` when no matching membership existed.

        Raises:
            RuntimeError: On unexpected database errors.
        """
        session = self._get_session()
        try:
            row = (
                session.query(CollectionArtifact)
                .filter_by(collection_id=collection_id, artifact_uuid=artifact_uuid)
                .first()
            )
            if row is None:
                logger.debug(
                    "DbCollectionArtifactRepository.remove_artifact: "
                    "no membership for collection=%s artifact_uuid=%s",
                    collection_id,
                    artifact_uuid,
                )
                return False

            session.delete(row)
            session.commit()
            logger.info(
                "DbCollectionArtifactRepository.remove_artifact: "
                "removed artifact_uuid=%s from collection=%s",
                artifact_uuid,
                collection_id,
            )
            return True

        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to remove artifact '{artifact_uuid}' from "
                f"collection '{collection_id}': {exc}"
            ) from exc
        finally:
            session.close()

    def upsert_metadata(
        self,
        collection_id: str,
        artifact_uuid: str,
        ctx: RequestContext | None = None,
        **metadata: Any,
    ) -> CollectionArtifactDTO:
        """Create or update arbitrary metadata fields on a membership record.

        If the membership does not yet exist it is created with the supplied
        metadata.  If it already exists, only the provided fields are updated
        (partial-update semantics).

        Recognised writable fields map 1-to-1 to
        :class:`CollectionArtifactDTO` attributes:
        ``description``, ``author``, ``license``, ``tags`` (stored as
        ``tags_json``), ``tools`` (stored as ``tools_json``),
        ``deployments`` (stored as ``deployments_json``),
        ``artifact_content_hash``, ``artifact_structure_hash``,
        ``artifact_file_count``, ``artifact_total_size``, ``source``,
        ``origin``, ``resolved_sha``, ``resolved_version``.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuid: Stable 32-char hex UUID of the artifact.
            ctx: Optional per-request metadata (unused by this backend).
            **metadata: Keyword arguments for fields to write.

        Returns:
            The updated :class:`CollectionArtifactDTO`.

        Raises:
            ValueError: If any key in *metadata* is not a recognised field.
            RuntimeError: On unexpected database errors.
        """
        # Map DTO field names → ORM column names (where they differ)
        _FIELD_MAP: dict[str, str] = {
            "tags": "tags_json",
            "tools": "tools_json",
            "deployments": "deployments_json",
        }
        _VALID_FIELDS = {
            "description",
            "author",
            "license",
            "tags",
            "tools",
            "deployments",
            "artifact_content_hash",
            "artifact_structure_hash",
            "artifact_file_count",
            "artifact_total_size",
            "source",
            "origin",
            "resolved_sha",
            "resolved_version",
        }

        bad_keys = set(metadata.keys()) - _VALID_FIELDS
        if bad_keys:
            raise ValueError(
                f"Unrecognised metadata fields: {', '.join(sorted(bad_keys))}"
            )

        session = self._get_session()
        try:
            row = (
                session.query(CollectionArtifact)
                .filter_by(collection_id=collection_id, artifact_uuid=artifact_uuid)
                .first()
            )
            if row is None:
                row = CollectionArtifact(
                    collection_id=collection_id,
                    artifact_uuid=artifact_uuid,
                    added_at=datetime.utcnow(),
                )
                session.add(row)

            for key, value in metadata.items():
                orm_key = _FIELD_MAP.get(key, key)
                # Serialise list fields to JSON strings
                if isinstance(value, list):
                    value = json.dumps(value)
                setattr(row, orm_key, value)

            session.commit()
            logger.info(
                "DbCollectionArtifactRepository.upsert_metadata: "
                "collection=%s artifact_uuid=%s fields=%s",
                collection_id,
                artifact_uuid,
                list(metadata.keys()),
            )
            return _collection_artifact_to_dto(row)

        except ValueError:
            session.rollback()
            raise
        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to upsert metadata for artifact '{artifact_uuid}' in "
                f"collection '{collection_id}': {exc}"
            ) from exc
        finally:
            session.close()

    def update_source_tracking(
        self,
        collection_id: str,
        artifact_uuid: str,
        *,
        source: str | None = None,
        origin: str | None = None,
        resolved_sha: str | None = None,
        resolved_version: str | None = None,
        ctx: RequestContext | None = None,
    ) -> CollectionArtifactDTO:
        """Update upstream source-tracking fields on a membership record.

        Used by the sync subsystem to record the resolved upstream coordinates
        for an artifact after a fetch or sync operation.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_uuid: Stable 32-char hex UUID of the artifact.
            source: Optional GitHub source spec (e.g. ``"owner/repo/path@version"``).
            origin: Optional human-readable origin label (e.g. ``"github"``).
            resolved_sha: Optional resolved commit SHA.
            resolved_version: Optional resolved semantic version string.
            ctx: Optional per-request metadata (unused by this backend).

        Returns:
            The updated :class:`CollectionArtifactDTO`.

        Raises:
            KeyError: If no membership for *(collection_id, artifact_uuid)* exists.
            RuntimeError: On unexpected database errors.
        """
        session = self._get_session()
        try:
            row = (
                session.query(CollectionArtifact)
                .filter_by(collection_id=collection_id, artifact_uuid=artifact_uuid)
                .first()
            )
            if row is None:
                raise KeyError(
                    f"No membership found for collection='{collection_id}' "
                    f"artifact_uuid='{artifact_uuid}'"
                )

            if source is not None:
                row.source = source
            if origin is not None:
                row.origin = origin
            if resolved_sha is not None:
                row.resolved_sha = resolved_sha
            if resolved_version is not None:
                row.resolved_version = resolved_version

            session.commit()
            logger.info(
                "DbCollectionArtifactRepository.update_source_tracking: "
                "collection=%s artifact_uuid=%s source=%r resolved_sha=%r",
                collection_id,
                artifact_uuid,
                source,
                resolved_sha,
            )
            return _collection_artifact_to_dto(row)

        except KeyError:
            session.rollback()
            raise
        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to update source tracking for artifact '{artifact_uuid}' in "
                f"collection '{collection_id}': {exc}"
            ) from exc
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Bootstrap / migration helpers
    # ------------------------------------------------------------------

    def get_existing_artifact_ids(self) -> set[str]:
        """Return the set of all ``type:name`` Artifact IDs currently in the DB.

        Returns:
            Set of ``"type:name"`` strings.  Empty set when no rows exist.
        """
        session = self._get_session()
        try:
            rows = session.query(Artifact.id).all()
            return {row[0] for row in rows}
        finally:
            session.close()

    def ensure_artifact_rows(
        self,
        artifacts: list,
        *,
        project_id: str,
    ) -> int:
        """Ensure every filesystem artifact has a corresponding Artifact ORM row.

        Idempotent: artifacts already present in the ``artifacts`` table are
        skipped.  All inserts are committed in a single transaction.

        Args:
            artifacts: List of filesystem artifact objects with ``.type``,
                ``.name``, ``.upstream``, and ``.metadata`` attributes.
            project_id: Sentinel project ID used as ``project_id`` FK.

        Returns:
            Number of new Artifact rows inserted.
        """
        session = self._get_session()
        try:
            existing_ids = {row[0] for row in session.query(Artifact.id).all()}
            created_count = 0

            for artifact in artifacts:
                artifact_id = f"{artifact.type.value}:{artifact.name}"
                if artifact_id in existing_ids:
                    continue
                try:
                    version = artifact.metadata.version if artifact.metadata else None
                    row = Artifact(
                        id=artifact_id,
                        uuid=uuid.uuid4().hex,
                        project_id=project_id,
                        name=artifact.name,
                        type=artifact.type.value,
                        source=artifact.upstream,
                        deployed_version=version,
                    )
                    session.add(row)
                    existing_ids.add(artifact_id)
                    created_count += 1
                except Exception as e:
                    logger.warning(
                        "DbCollectionArtifactRepository.ensure_artifact_rows: "
                        "failed to build row for '%s': %s",
                        artifact_id,
                        e,
                    )
                    continue

            if created_count > 0:
                session.commit()
                logger.info(
                    "DbCollectionArtifactRepository.ensure_artifact_rows: "
                    "inserted %d new Artifact rows",
                    created_count,
                )

            return created_count

        except Exception as exc:
            session.rollback()
            logger.warning(
                "DbCollectionArtifactRepository.ensure_artifact_rows: "
                "transaction failed: %s",
                exc,
            )
            return 0
        finally:
            session.close()

    def list_artifact_ids_in_collection(
        self,
        collection_id: str,
    ) -> set[str]:
        """Return the set of ``type:name`` Artifact IDs present in a collection.

        Resolves UUIDs to ``type:name`` strings via a JOIN through the
        ``artifacts`` table.

        Args:
            collection_id: Unique identifier of the user collection.

        Returns:
            Set of ``"type:name"`` strings.  Empty set when no members exist.
        """
        session = self._get_session()
        try:
            rows = (
                session.query(Artifact.id)
                .join(
                    CollectionArtifact,
                    CollectionArtifact.artifact_uuid == Artifact.uuid,
                )
                .filter(CollectionArtifact.collection_id == collection_id)
                .all()
            )
            return {row[0] for row in rows}
        finally:
            session.close()

    def resolve_uuid_by_id(
        self,
        artifact_id: str,
    ) -> str | None:
        """Resolve the stable UUID for an artifact by its ``type:name`` ID.

        Args:
            artifact_id: ``"type:name"`` artifact identifier string.

        Returns:
            32-char hex UUID string when found, ``None`` otherwise.
        """
        session = self._get_session()
        try:
            row = (
                session.query(Artifact.uuid).filter(Artifact.id == artifact_id).first()
            )
            return row[0] if row else None
        finally:
            session.close()

    def list_all_with_tags(self) -> list[CollectionArtifactDTO]:
        """Return all CollectionArtifact rows that carry at least one tag.

        Unlike :meth:`list_with_tags`, this method is not scoped to a single
        collection and is intended for global tag-sync bootstrap operations.

        Returns:
            List of :class:`CollectionArtifactDTO` objects with tags.
        """
        session = self._get_session()
        try:
            rows = (
                session.query(CollectionArtifact)
                .filter(CollectionArtifact.tags_json.isnot(None))
                .all()
            )
            return [_collection_artifact_to_dto(row) for row in rows]
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Batch / bulk helpers (Phase-2 repository DI migration)
    # ------------------------------------------------------------------

    def resolve_uuid_to_id_batch(
        self,
        uuids: list[str],
        ctx: RequestContext | None = None,
    ) -> dict[str, str]:
        """Batch-resolve artifact UUIDs to ``type:name`` ID strings.

        Args:
            uuids: List of 32-char hex UUID strings to resolve.
            ctx: Optional per-request metadata (unused).

        Returns:
            Dict mapping artifact_uuid → type:name ID.
        """
        if not uuids:
            return {}
        session = self._get_session()
        try:
            rows = (
                session.query(Artifact.uuid, Artifact.id)
                .filter(Artifact.uuid.in_(uuids))
                .all()
            )
            return {r[0]: r[1] for r in rows}
        finally:
            session.close()

    def list_all_ordered(
        self,
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> list[CollectionArtifactDTO]:
        """Return all memberships for a collection ordered by artifact ID.

        Joins through ``artifacts`` to order by ``Artifact.id`` (type:name),
        enabling stable cursor-based pagination at the endpoint layer.

        Args:
            collection_id: Unique identifier of the user collection.
            ctx: Optional per-request metadata (unused).

        Returns:
            All CollectionArtifactDTO records for the collection, ordered by
            artifact ID.
        """
        session = self._get_session()
        try:
            rows = (
                session.query(CollectionArtifact)
                .join(Artifact, Artifact.uuid == CollectionArtifact.artifact_uuid)
                .filter(CollectionArtifact.collection_id == collection_id)
                .order_by(Artifact.id)
                .all()
            )
            return [_collection_artifact_to_dto(row) for row in rows]
        finally:
            session.close()

    def get_group_artifact_uuids(
        self,
        group_id: str,
        ctx: RequestContext | None = None,
    ) -> set[str]:
        """Return the set of artifact UUIDs belonging to a group.

        Args:
            group_id: Unique identifier of the group.
            ctx: Optional per-request metadata (unused).

        Returns:
            Set of 32-char hex UUID strings.  Empty when group has no members.
        """
        session = self._get_session()
        try:
            rows = (
                session.query(GroupArtifact.artifact_uuid)
                .filter(GroupArtifact.group_id == group_id)
                .all()
            )
            return {r[0] for r in rows}
        finally:
            session.close()

    def get_source_for_uuids(
        self,
        artifact_uuids: list[str],
        ctx: RequestContext | None = None,
    ) -> dict[str, str]:
        """Return a mapping from type:name ID to source value for a batch.

        Args:
            artifact_uuids: List of 32-char hex UUID strings.
            ctx: Optional per-request metadata (unused).

        Returns:
            Dict mapping type:name artifact ID → source string (non-null only).
        """
        if not artifact_uuids:
            return {}
        session = self._get_session()
        try:
            rows = (
                session.query(Artifact.id, CollectionArtifact.source)
                .join(
                    CollectionArtifact,
                    CollectionArtifact.artifact_uuid == Artifact.uuid,
                )
                .filter(
                    CollectionArtifact.artifact_uuid.in_(artifact_uuids),
                    CollectionArtifact.source.isnot(None),
                )
                .all()
            )
            return {r[0]: r[1] for r in rows}
        finally:
            session.close()

    def get_group_memberships_batch(
        self,
        artifact_uuids: list[str],
        collection_id: str,
        ctx: RequestContext | None = None,
    ) -> list[dict]:
        """Return group-membership rows for a batch of artifact UUIDs.

        Args:
            artifact_uuids: List of 32-char hex UUID strings.
            collection_id: Scope results to groups belonging to this collection.
            ctx: Optional per-request metadata (unused).

        Returns:
            List of dicts with keys: artifact_id, group_id, group_name,
            position.
        """
        if not artifact_uuids:
            return []
        session = self._get_session()
        try:
            # First get group IDs for this collection
            group_ids = [
                r[0]
                for r in session.query(Group.id)
                .filter(Group.collection_id == collection_id)
                .all()
            ]
            if not group_ids:
                return []
            rows = (
                session.query(GroupArtifact, Group, Artifact)
                .join(Group, GroupArtifact.group_id == Group.id)
                .join(Artifact, Artifact.uuid == GroupArtifact.artifact_uuid)
                .filter(
                    GroupArtifact.artifact_uuid.in_(artifact_uuids),
                    GroupArtifact.group_id.in_(group_ids),
                )
                .all()
            )
            return [
                {
                    "artifact_id": artifact.id,
                    "group_id": group.id,
                    "group_name": group.name,
                    "position": ga.position,
                }
                for ga, group, artifact in rows
            ]
        finally:
            session.close()

    def get_staleness_stats(
        self,
        collection_id: str,
        ttl_seconds: int,
        ctx: RequestContext | None = None,
    ) -> dict:
        """Return staleness statistics for a collection.

        Args:
            collection_id: Unique identifier of the collection to analyse.
            ttl_seconds: Age in seconds after which a membership is stale.
            ctx: Optional per-request metadata (unused).

        Returns:
            Dict with total_artifacts, stale_count, fresh_count,
            oldest_sync_age_seconds, percentage_stale, ttl_seconds,
            collection_id.
        """
        session = self._get_session()
        try:
            cutoff_time = datetime.utcnow() - timedelta(seconds=ttl_seconds)

            total = (
                session.query(func.count())
                .select_from(CollectionArtifact)
                .filter(CollectionArtifact.collection_id == collection_id)
                .scalar()
            ) or 0

            if total == 0:
                return {
                    "total_artifacts": 0,
                    "stale_count": 0,
                    "fresh_count": 0,
                    "oldest_sync_age_seconds": 0,
                    "percentage_stale": 0.0,
                    "ttl_seconds": ttl_seconds,
                    "collection_id": collection_id,
                }

            stale_count = (
                session.query(func.count())
                .select_from(CollectionArtifact)
                .filter(
                    CollectionArtifact.collection_id == collection_id,
                    or_(
                        CollectionArtifact.synced_at.is_(None),
                        CollectionArtifact.synced_at < cutoff_time,
                    ),
                )
                .scalar()
            ) or 0

            oldest_row = (
                session.query(CollectionArtifact.synced_at)
                .filter(
                    CollectionArtifact.collection_id == collection_id,
                    CollectionArtifact.synced_at.isnot(None),
                )
                .order_by(CollectionArtifact.synced_at.asc())
                .first()
            )

            oldest_age = 0
            if oldest_row and oldest_row[0]:
                oldest_age = (datetime.utcnow() - oldest_row[0]).total_seconds()

            return {
                "total_artifacts": total,
                "stale_count": stale_count,
                "fresh_count": total - stale_count,
                "oldest_sync_age_seconds": oldest_age,
                "percentage_stale": (
                    round((stale_count / total * 100), 1) if total > 0 else 0.0
                ),
                "ttl_seconds": ttl_seconds,
                "collection_id": collection_id,
            }
        finally:
            session.close()

    def update_deployments_by_name(
        self,
        collection_id: str,
        artifact_name: str,
        deployments_json: str,
        ctx: RequestContext | None = None,
    ) -> int:
        """Update ``deployments_json`` on memberships matching *artifact_name*.

        Args:
            collection_id: Unique identifier of the user collection.
            artifact_name: Short artifact name (without the type: prefix).
            deployments_json: Serialised JSON string to store.
            ctx: Optional per-request metadata (unused).

        Returns:
            Number of rows updated.
        """
        session = self._get_session()
        try:
            # Resolve name → UUIDs (may span multiple artifact types)
            uuid_rows = (
                session.query(Artifact.uuid)
                .filter(Artifact.name == artifact_name)
                .all()
            )
            if not uuid_rows:
                return 0

            updated = 0
            for (artifact_uuid,) in uuid_rows:
                result = session.execute(
                    update(CollectionArtifact)
                    .where(
                        and_(
                            CollectionArtifact.collection_id == collection_id,
                            CollectionArtifact.artifact_uuid == artifact_uuid,
                        )
                    )
                    .values(deployments_json=deployments_json)
                )
                updated += result.rowcount

            if updated:
                session.commit()
            logger.debug(
                "DbCollectionArtifactRepository.update_deployments_by_name: "
                "collection=%s name=%s updated=%d",
                collection_id,
                artifact_name,
                updated,
            )
            return updated

        except Exception as exc:
            session.rollback()
            raise RuntimeError(
                f"Failed to update deployments for '{artifact_name}' in "
                f"collection '{collection_id}': {exc}"
            ) from exc
        finally:
            session.close()

    def bulk_update_metadata(
        self,
        updates: list[dict],
        ctx: RequestContext | None = None,
    ) -> int:
        """Apply metadata field updates to multiple membership rows.

        Each element of *updates* must contain ``artifact_uuid`` plus the
        fields to write.  Unknown keys are silently ignored.

        Args:
            updates: List of dicts with artifact_uuid and metadata fields.
            ctx: Optional per-request metadata (unused).

        Returns:
            Number of rows successfully updated.
        """
        if not updates:
            return 0

        _ALLOWED = {
            "description",
            "author",
            "license",
            "version",
            "tags_json",
            "tools_json",
            "source",
            "origin",
            "origin_source",
            "resolved_sha",
            "resolved_version",
            "synced_at",
        }

        session = self._get_session()
        try:
            updated = 0
            for item in updates:
                artifact_uuid = item.get("artifact_uuid")
                if not artifact_uuid:
                    continue
                fields = {k: v for k, v in item.items() if k in _ALLOWED}
                if not fields:
                    continue
                row = (
                    session.query(CollectionArtifact)
                    .filter_by(artifact_uuid=artifact_uuid)
                    .first()
                )
                if row is None:
                    continue
                for key, value in fields.items():
                    setattr(row, key, value)
                updated += 1

            if updated:
                session.commit()

            logger.debug(
                "DbCollectionArtifactRepository.bulk_update_metadata: "
                "updated %d rows",
                updated,
            )
            return updated

        except Exception as exc:
            session.rollback()
            raise RuntimeError(f"bulk_update_metadata failed: {exc}") from exc
        finally:
            session.close()


# =============================================================================
# DbArtifactHistoryRepository
# =============================================================================


def _cache_artifact_to_summary_dto(artifact: Artifact) -> CacheArtifactSummaryDTO:
    """Convert a :class:`~skillmeat.cache.models.Artifact` ORM row to a DTO."""
    project_path: Optional[str] = None
    try:
        if artifact.project is not None:
            project_path = artifact.project.path
    except Exception:
        pass
    return CacheArtifactSummaryDTO(
        id=artifact.id,
        uuid=artifact.uuid,
        name=artifact.name,
        type=artifact.type,
        project_path=project_path,
    )


def _artifact_version_to_dto(version: ArtifactVersion) -> ArtifactVersionDTO:
    """Convert a :class:`~skillmeat.cache.models.ArtifactVersion` ORM row to a DTO."""
    created_at_iso: Optional[str] = None
    if version.created_at is not None:
        if hasattr(version.created_at, "isoformat"):
            created_at_iso = version.created_at.isoformat()
        else:
            created_at_iso = str(version.created_at)

    return ArtifactVersionDTO(
        id=version.id,
        artifact_id=version.artifact_id,
        content_hash=version.content_hash,
        change_origin=version.change_origin,
        created_at=created_at_iso,
        parent_hash=version.parent_hash,
        version_lineage=version.version_lineage,
        metadata_json=version.metadata_json,
    )


class DbArtifactHistoryRepository(IDbArtifactHistoryRepository):
    """DB-backed implementation of :class:`IDbArtifactHistoryRepository`.

    Performs the read-only ``artifacts`` and ``artifact_versions`` queries
    used by the artifact history timeline endpoint.

    Session lifecycle follows the canonical pattern used throughout this
    module: each public method obtains its own session, wraps the query in a
    ``try/finally`` block, and closes the session on all exit paths.

    Args:
        get_session: Zero-argument callable that returns a SQLAlchemy
            :class:`~sqlalchemy.orm.Session`.  Defaults to the module-level
            ``get_session`` singleton from :mod:`skillmeat.cache.models`.
    """

    def __init__(self, get_session: Any = None) -> None:
        from skillmeat.cache.models import get_session as _default_get_session

        self._get_session = (
            get_session if get_session is not None else _default_get_session
        )

    def get_cache_artifact_by_uuid(
        self,
        uuid: str,
        ctx: RequestContext | None = None,
    ) -> CacheArtifactSummaryDTO | None:
        """Return a summary of the ``artifacts`` row identified by *uuid*.

        Returns:
            :class:`~skillmeat.core.interfaces.dtos.CacheArtifactSummaryDTO`
            when found, ``None`` otherwise.
        """
        session = self._get_session()
        try:
            row = session.query(Artifact).filter(Artifact.uuid == uuid).first()
            return _cache_artifact_to_summary_dto(row) if row is not None else None
        finally:
            session.close()

    def list_cache_artifacts_by_name_type(
        self,
        name: str,
        artifact_type: str,
        ctx: RequestContext | None = None,
    ) -> list[CacheArtifactSummaryDTO]:
        """Return all ``artifacts`` rows matching *name* and *artifact_type*.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.CacheArtifactSummaryDTO`.
        """
        session = self._get_session()
        try:
            rows = (
                session.query(Artifact)
                .filter(Artifact.name == name, Artifact.type == artifact_type)
                .all()
            )
            return [_cache_artifact_to_summary_dto(row) for row in rows]
        finally:
            session.close()

    def list_versions_for_artifacts(
        self,
        artifact_ids: list[str],
        ctx: RequestContext | None = None,
    ) -> list[ArtifactVersionDTO]:
        """Return version lineage records for *artifact_ids* ordered newest-first.

        Returns an empty list immediately when *artifact_ids* is empty.

        Returns:
            A (possibly empty) list of
            :class:`~skillmeat.core.interfaces.dtos.ArtifactVersionDTO`
            ordered by ``created_at`` descending.
        """
        if not artifact_ids:
            return []
        session = self._get_session()
        try:
            rows = (
                session.query(ArtifactVersion)
                .filter(ArtifactVersion.artifact_id.in_(artifact_ids))
                .order_by(ArtifactVersion.created_at.desc())
                .all()
            )
            return [_artifact_version_to_dto(row) for row in rows]
        finally:
            session.close()
