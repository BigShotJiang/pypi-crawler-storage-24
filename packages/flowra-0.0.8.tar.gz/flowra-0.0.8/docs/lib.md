# Package `flowra.lib`

High-level agents for LLM interactions: a multi-turn chat agent and a tool-calling loop
agent with hooks, caching, and interrupt support. Built on top of the low-level
`flowra.agent` and `flowra.llm` packages.

```
flowra/lib/
├── config_value.py          # ConfigValue[T] — static or dynamic config provider
├── llm_config.py            # LLMConfig — LLM configuration (model, temperature, etc.)
├── chat/
│   ├── agent.py             # ChatAgent — multi-turn chat with session history
│   ├── config.py            # ChatConfig — chat-level configuration
│   ├── hook_events.py       # SaveTurnMessagesEvent
│   └── spec.py              # ChatSpec, ChatResult
└── tool_loop/
    ├── agent.py             # ToolLoopAgent — single-turn LLM tool loop
    ├── config.py            # ToolLoopConfig
    ├── hook_events.py       # 12 event dataclasses for hook system
    ├── spec.py              # ToolLoopSpec, ToolLoopResult, ToolLoopStatus
    ├── context.py           # ToolLoopAgentContext — tool-accessible loop context
    ├── cache.py             # CacheConfig, cache strategies and presets
    └── tool_call/           # single tool execution and agent-as-tool
        ├── agent.py         # ToolCallAgent — executes one tool call
        ├── context.py       # ToolCallAgentContext — call_agent() support
        └── agent_tool.py    # make_agent_tool, @agent_tool, get_agent_tool
```

## Quick start

Minimal multi-turn chat with a tool:

```python
import asyncio
import dataclasses

from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib import LLMConfig
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider
from flowra.runtime import AgentRuntime
from flowra.tools import ToolRegistry, get_local_tool, tool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CalcParams:
    expression: str


@tool("calculate")
def calculate(params: CalcParams) -> str:
    """Evaluate a math expression."""
    # Use a safe evaluator — never pass LLM output to eval()
    return eval_expression(params.expression)


async def main() -> None:
    provider = AnthropicVertexProvider()

    async with await ToolRegistry.create([get_local_tool(calculate)]) as registry:
        config = ChatConfig(
            llm_config=LLMConfig(model="claude-sonnet-4-5@20250929"),
            system_messages=[
                SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])
            ],
        )

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                LLMProvider: provider,
                ToolRegistry: registry,
                ChatConfig: config,
            },
        )

        while True:
            user_input = input("You: ")
            if not user_input:
                break

            result = await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message=user_input),
            )

            if isinstance(result, ChatResult) and result.response:
                print(f"Assistant: {result.response}")


asyncio.run(main())
```

## ChatAgent

Multi-turn chat agent that manages session history. Each call is one user turn:
the agent delegates to `ToolLoopAgent` for the LLM interaction, then saves all
resulting messages (including the user message) back to the session.

```python
result = await runtime.run(
    agent=ChatAgent,
    spec=ChatSpec(user_message="Hello!"),
)
```

Session messages persist across turns, so the LLM sees the full conversation
history on every call.

### `ChatSpec`

Input for `ChatAgent`.

| Field          | Type                     | Default |
|----------------|--------------------------|---------|
| `user_message` | `str`                    | —       |
| `metadata`     | `dict[str, Any] \| None` | `None`  |

`metadata` is passed through to `ToolLoopSpec` and delivered to `MessageAcceptedEvent`
— useful for tracking message IDs in interrupt scenarios.

### `ChatResult`

Output of a chat turn.

| Field      | Type            | Default |
|------------|-----------------|---------|
| `response` | `str \| None`   | `None`  |
| `usage`    | `Usage \| None` | `None`  |

`response` contains the concatenated text blocks from the final assistant message.
`None` when the LLM didn't produce text (e.g. interrupted or max LLM calls reached).

### `ChatConfig`

Configuration for `ChatAgent`. All fields accept `ConfigValue[T]` — a plain value,
sync callable, or async callable (see [ConfigValue](#configvalue) below).

| Field                    | Type                                  | Default        |
|--------------------------|---------------------------------------|----------------|
| `llm_config`             | `ConfigValue[LLMConfig]`              | —              |
| `system_messages`        | `ConfigValue[list[Message]]`          | —              |
| `json_schema`            | `ConfigValue[dict[str, Any] \| None]` | `None`         |
| `max_llm_calls`          | `ConfigValue[int]`                    | `10`           |
| `allowed_tools`          | `ConfigValue[set[str] \| None]`       | `None`         |
| `denied_tools`           | `ConfigValue[set[str] \| None]`       | `None`         |
| `cache_strategy`         | `ConfigValue[CacheConfig]`            | `CACHE_MANUAL` |
| `max_consecutive_errors` | `ConfigValue[int \| None]`            | `None`         |

`ChatConfig` differs from `ToolLoopConfig` in one key way: it has `system_messages`
instead of `session_messages`. The chat agent combines them on each call — it prepends
`system_messages` to the accumulated conversation history and passes the result
as `session_messages` to `ToolLoopAgent`.

### Chat hooks

Chat-level hook events, registered on the same `HookRegistry` instance as tool loop hooks.

**`SaveTurnMessagesEvent`** — emitted before turn messages are saved into session history.
Handlers mutate `messages` in place to control what gets persisted. Useful for excluding
transient messages (e.g. dynamic context injected by hooks) from long-term session history.

| Field      | Type            | Default |
|------------|-----------------|---------|
| `messages` | `list[Message]` | —       |

```python
from flowra.agent import HookRegistry
from flowra.lib.chat import ChatAgent, ChatConfig, SaveTurnMessagesEvent
from flowra.llm import Message

def filter_transient(event):
    event.data.messages = [m for m in event.data.messages if not m.metadata.get("transient")]

hooks = HookRegistry()
hooks.on(SaveTurnMessagesEvent, filter_transient)

runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    services={..., ChatConfig: config, HookRegistry: hooks},
)
```

## ToolLoopAgent

Lower-level agent that runs a single LLM tool loop: send messages to the LLM,
execute any requested tool calls, feed results back, repeat until the LLM returns
`END_TURN` or a limit is reached. `ChatAgent` delegates to `ToolLoopAgent` internally;
you can also use it directly for non-chat scenarios.

```python
from flowra.lib import LLMConfig
from flowra.lib.tool_loop import ToolLoopAgent, ToolLoopConfig, ToolLoopSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.runtime import AgentRuntime
from flowra.tools import ToolRegistry

config = ToolLoopConfig(
    llm_config=LLMConfig(model="claude-sonnet-4-5@20250929"),
    session_messages=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
    max_llm_calls=5,
)

runtime = AgentRuntime(
    agents={"loop": ToolLoopAgent},
    services={LLMProvider: provider, ToolRegistry: registry, ToolLoopConfig: config},
)

result = await runtime.run(
    agent=ToolLoopAgent,
    spec=ToolLoopSpec(user_message="Calculate 3 * 7"),
)
```

### How the loop works

The agent runs a three-step cycle. Hook events (see [Hooks](#hooks)) are noted
inline — mutable events let handlers influence the flow.

**Step 1: `start`** (runs once)

- Wraps the user message into a `UserMessage`.
- `UserMessageEvent` — handlers can replace or augment the initial messages.
- Flushes state (for crash recovery).
- `MessageAcceptedEvent` — observation-only (fires on resume too).

**Step 2: `call_llm`** (each iteration)

- Calls `interrupt.check()` (raises `InterruptedError` if signaled), checks finish request and iteration limit.
- `StartIterationEvent` — handlers can append additional context messages.
- Builds `LLMRequest` from config, accumulated messages, tool filters, and cache strategy.
- `BeforeLLMCallEvent` — observation-only.
- Calls the LLM. If streaming handlers are registered (`TextDeltaEvent` /
  `ThinkingDeltaEvent`), the agent uses `provider.stream()` instead of `provider.call()`.
- `AfterLLMCallEvent` — observation-only.
- `TextReasoningEvent` / `ThinkingEvent` — for each text/thinking block in the response.
- Then the flow branches on stop reason:
  - **`END_TURN`** — `ResultMessageEvent`. If handlers set `continue_messages`,
    the loop continues; otherwise returns `ToolLoopResult` with `COMPLETED` status.
  - **`TOOL_USE`** — `BeforeToolCallEvent` for each tool call (handlers can modify
    parameters), then spawns parallel child agents to execute the tools → step 3.
  - **Other** (`MAX_TOKENS`, `STOP_SEQUENCE`, `SCHEMA_VALIDATION_FAILED`) — returns immediately.

**Step 3: `collect_results`** (after tool execution)

- `AfterToolCallEvent` for each tool — handlers can replace the result or inject
  additional messages.
- If a tool has failed too many times in a row (`max_consecutive_errors`),
  the error is replaced with a prompt to try a different approach.
- All tool results are appended as a `UserMessage`.
- Calls `interrupt.check()` (raises `InterruptedError` if signaled), checks finish request.
- Otherwise → back to step 2.

### `ToolLoopSpec`

Input for `ToolLoopAgent`.

| Field          | Type                     | Default |
|----------------|--------------------------|---------|
| `user_message` | `str`                    | —       |
| `metadata`     | `dict[str, Any] \| None` | `None`  |

### `ToolLoopResult`

Output of one tool loop execution.

| Field            | Type                       | Default |
|------------------|----------------------------|---------|
| `messages`       | `list[Message]`            | —       |
| `status`         | `ToolLoopStatus`           | —       |
| `stop_reason`    | `StopReason \| None`       | `None`  |
| `result_message` | `AssistantMessage \| None` | `None`  |
| `usage`          | `Usage \| None`            | `None`  |

`messages` contains all turn messages (user + assistant + tool results) in order.
`result_message` is the final assistant message when `status` is `COMPLETED`.

### `ToolLoopStatus`

`StrEnum` with four values:

| Value              | Meaning                                                                  |
|--------------------|--------------------------------------------------------------------------|
| `COMPLETED`        | LLM returned a final response (check `stop_reason`)                      |
| `MAX_LLM_CALLS`    | LLM call limit reached                                                   |
| `INTERRUPTED`      | Reserved (interrupt now raises `InterruptedError`, `run()` returns `Interrupted()`) |
| `FINISH_REQUESTED` | A tool or hook called `context.request_finish()`                         |

### `ToolLoopConfig`

| Field                    | Type                                  | Default        |
|--------------------------|---------------------------------------|----------------|
| `llm_config`             | `ConfigValue[LLMConfig]`              | —              |
| `session_messages`       | `ConfigValue[list[Message]]`          | —              |
| `json_schema`            | `ConfigValue[dict[str, Any] \| None]` | `None`         |
| `max_llm_calls`          | `ConfigValue[int]`                    | `10`           |
| `allowed_tools`          | `ConfigValue[set[str] \| None]`       | `None`         |
| `denied_tools`           | `ConfigValue[set[str] \| None]`       | `None`         |
| `cache_strategy`         | `ConfigValue[CacheConfig]`            | `CACHE_MANUAL` |
| `max_consecutive_errors` | `ConfigValue[int \| None]`            | `None`         |

`session_messages` are the external context passed into each loop run (system prompts,
conversation history). `turn_messages` are accumulated during the current run (user input,
assistant responses, tool results). Both are sent to the LLM on every call.

`allowed_tools` / `denied_tools` filter which tools the LLM can see and call.
Both support wildcard patterns via `fnmatch` (e.g. `{"mcp_*"}`, `{"debug_?"}`, `{"*"}`).
When `allowed_tools` is set, only matching tools are included. When `denied_tools` is set,
matching tools are excluded. If a tool is filtered out but the LLM still tries to call it,
the agent returns an error result to the LLM.

`max_consecutive_errors` — when set, if the same tool fails this many times in a row,
the agent tells the LLM to try a different approach.

### `LLMConfig`

| Field               | Type                | Default |
|---------------------|---------------------|---------|
| `model`             | `str`               | —       |
| `temperature`       | `float \| None`     | `None`  |
| `max_tokens`        | `int \| None`       | `None`  |
| `stop_sequences`    | `list[str] \| None` | `None`  |
| `additional_config` | `dict[str, Any]`    | `{}`    |

## Hooks

Lifecycle hooks use a generic `HookRegistry` + `Event[T]` pattern from `flowra.agent`.
Register handlers for typed event dataclasses. Supports multiple handlers per event,
sync/async transparency, and composition via `HookProvider`.

```python
from flowra.agent import HookRegistry
from flowra.lib.tool_loop import BeforeLLMCallEvent, AfterLLMCallEvent

hooks = HookRegistry()
hooks.on(BeforeLLMCallEvent, lambda e: print(f"Calling LLM with {len(e.data.request.messages)} messages"))
hooks.on(AfterLLMCallEvent, lambda e: print(f"LLM returned {e.data.response.stop_reason}"))

runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    services={..., HookRegistry: hooks},
)
```

Hooks use the standard `HookRegistry` described in [agent.md](agent.md).

### Hook events

| Event                  | Mutable fields                                   | Description                                                                     |
|------------------------|--------------------------------------------------|---------------------------------------------------------------------------------|
| `UserMessageEvent`     | `messages: list[UserMessage]`                    | Once at loop start. Mutate to replace or augment the initial messages.          |
| `MessageAcceptedEvent` | —                                                | After messages accepted (incl. resume). Has `messages`, `metadata` (from spec). |
| `StartIterationEvent`  | `additional_messages: list[UserMessage]`         | At start of each iteration. Has `iteration` (int), `context`. Append to inject context before LLM call. |
| `BeforeLLMCallEvent`   | —                                                | Before each LLM request. Has `request`, `context`.                              |
| `TextDeltaEvent`       | —                                                | During streaming. Has `text` (str), `context`.                                  |
| `ThinkingDeltaEvent`   | —                                                | During streaming. Has `text` (str), `context`.                                  |
| `AfterLLMCallEvent`    | —                                                | After each LLM response. Has `request`, `response`, `context`.                  |
| `TextReasoningEvent`   | —                                                | For each `TextBlock` in response. Has `text` (TextBlock), `context`.            |
| `ThinkingEvent`        | —                                                | For each `ThinkingBlock` in response. Has `thinking`, `context`.                |
| `BeforeToolCallEvent`  | `tool_use: ToolUseBlock`                         | Before tool execution. Has `context`. Replace `tool_use` to modify parameters.  |
| `AfterToolCallEvent`   | `result: ToolResultBlock`, `additional_messages` | After tool execution. Has `tool_use`, `context`. Replace result or inject messages. |
| `ResultMessageEvent`   | `continue_messages: list[UserMessage]`           | On END_TURN. Has `message` (AssistantMessage), `context`. Set `continue_messages` to continue loop. |


## Prompt caching

`CacheConfig` controls prompt caching breakpoints on system prompts, tools, and messages
before each LLM call. Three strategy slots can be combined independently.

When a slot is `None`, user-provided `cache` hints are preserved as-is. When a
strategy is set, it **replaces** the caching policy for that slot — it decides
which elements get `cache=True`.

### `CacheConfig`

| Field           | Type                                | Default |
|-----------------|-------------------------------------|---------|
| `system_prompt` | `SystemPromptCacheStrategy \| None` | `None`  |
| `tools`         | `ToolsCacheStrategy \| None`        | `None`  |
| `messages`      | `MessagesCacheStrategy \| None`     | `None`  |

### Built-in strategies

Each `cache_*` strategy first clears all `cache=True` hints in its slot, then sets
its own target. This ensures exactly one cache breakpoint per slot regardless of
any pre-existing hints on input elements.

Each `no_cache_*` strategy clears all `cache=True` hints in its slot without
setting any new ones.

| Function                     | Slot            | Behavior                                                       |
|------------------------------|-----------------|----------------------------------------------------------------|
| `cache_last_system_prompt`   | `system_prompt` | Sets `cache=True` on the last block of the last system message |
| `cache_last_tool`            | `tools`         | Sets `cache=True` on the last tool                             |
| `cache_last_message`         | `messages`      | Sets `cache=True` on the last block across all messages        |
| `cache_last_session_message` | `messages`      | Same, but only within session messages (not turn messages)     |
| `no_cache_system_prompt`     | `system_prompt` | Clears all `cache=True` on system message blocks               |
| `no_cache_tools`             | `tools`         | Clears all `cache=True` on tools                               |
| `no_cache_messages`          | `messages`      | Clears all `cache=True` on message blocks                      |

### Presets

```python
from flowra.lib.tool_loop import CACHE_MANUAL, NO_CACHE, CACHE_ALL, CACHE_SESSION

# CACHE_MANUAL — preserves user-provided cache hints as-is (default)
# NO_CACHE — strips all cache hints
# CACHE_ALL — cache system prompt + tools + last message (all messages)
# CACHE_SESSION — cache system prompt + tools + last session message (excludes current turn)
```

## Tool services

Tools executed by `ToolLoopAgent` receive all services from the agent's scope —
everything registered in `AgentRuntime(services={...})` plus anything provided
by parent agents via `ServiceLocator.provide()`. Add a parameter with the desired type
to the tool handler (see `flowra.tools` docs for details on tool DI).

```python
class MyDatabase:
    def query(self, sql: str) -> list[dict]:
        ...

db = MyDatabase()

runtime = AgentRuntime(
    agents={"loop": ToolLoopAgent},
    services={..., MyDatabase: db},
)

@tool("lookup")
def lookup(params: LookupParams, db: MyDatabase) -> str:
    """Tool that uses MyDatabase — injected from runtime services."""
    rows = db.query(params.sql)
    return str(rows)
```

`ToolLoopAgent` also provides `ToolLoopAgentContext` into its scope via
`ServiceLocator.provide()`, and the runtime adds `InterruptToken` automatically.
Both are regular scope services — tools request them the same way:

```python
from flowra.agent import InterruptToken
from flowra.lib.tool_loop import ToolLoopAgentContext

@tool("process_items")
async def process_items(params: Params, interrupt: InterruptToken) -> str:
    """A tool that checks for interrupts between items.

    Raising InterruptedError is safe — ToolCallAgent catches it and returns
    an error result to the LLM.
    """
    results = []
    for item in params.items:
        interrupt.check()  # raises InterruptedError if signaled
        results.append(await process(item))
    return json.dumps(results)

@tool("finish")
def finish(params: Params, context: ToolLoopAgentContext) -> str:
    """Request the loop to stop after this iteration."""
    context.request_finish()
    return "Stopping"
```

### `ToolLoopAgentContext`

Available to tools and hooks. Methods:

- `request_finish()` — signals the loop to stop after the current iteration completes.
  The result will have `status=FINISH_REQUESTED`.
- `is_finish_requested() -> bool` — check whether `request_finish()` has been called.

## Agents as tools

An agent can be registered as a tool so the LLM autonomously decides when to
delegate work to a specialist. The LLM sees a regular tool in its tool list,
but behind the scenes the tool spawns a full sub-agent — with its own system
prompt, LLM calls, and even its own tools. The sub-agent's result is serialized
and returned to the LLM as a normal tool result.

This is the main composition mechanism: the orchestrating LLM decides **when** to
delegate, and the sub-agent handles **how**.

The agent must have exactly one spec type (a single dataclass). Union types and
type aliases are not supported — LLM APIs require `type: "object"` at the root
of the tool input schema. If you need polymorphic input, wrap it in a dataclass:

```python
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AnimalSpec:
    animal: Dog | Cat
```

### `@agent_tool` decorator

The simplest way to expose an agent as a tool. Decorate the agent class, then
extract the `LocalTool` with `get_agent_tool()` when building the registry:

```python
import dataclasses

from flowra.agent import Agent, step
from flowra.lib.tool_loop import agent_tool, get_agent_tool

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PoetSpec:
    topic: str

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PoetResult:
    poem: str

@agent_tool(name="poet", description="Write a short poem on a topic")
class PoetAgent(Agent[PoetSpec, PoetResult]):
    @step(entry=True)
    async def write(self, spec: PoetSpec) -> PoetResult:
        # ... call LLM with a poet system prompt ...
        return PoetResult(poem="...")
```

The tool's input schema is derived automatically from the agent's spec type —
in this case `{"topic": ...}`. When the LLM calls the tool, the sub-agent is
spawned with a `PoetSpec`, and the serialized `PoetResult` is returned as the
tool output.

Register agent tools the same way as regular tools. Sub-agents must also
be registered in the runtime:

```python
poet_tool = get_agent_tool(PoetAgent)

async with await ToolRegistry.create([poet_tool, math_tool]) as registry:
    runtime = AgentRuntime(
        agents={
            "chat": ChatAgent,
            "poet": PoetAgent,
            "math_tutor": MathAgent,
        },
        services={ToolRegistry: registry, ...},
    )
```

### `make_agent_tool`

When you don't want to decorate the agent class (e.g. a third-party agent, or
the same agent exposed under different tool names), use `make_agent_tool` directly:

```python
from flowra.lib.tool_loop import make_agent_tool

poet_tool = make_agent_tool(PoetAgent, name="poet", description="Write a short poem on a topic")
```

It also accepts `AgentDefinition` instead of a class — in that case pass `agent_ref`
explicitly to tell the runtime how to resolve the agent.

### `ToolCallAgentContext`

Under the hood, agent tools use `ToolCallAgentContext.call_agent()` to request
delegation. You can use it directly in a regular tool for custom delegation logic
(e.g. choosing which agent to call based on input):

```python
from flowra.lib.tool_loop import ToolCallAgentContext
from flowra.tools import tool

@tool("delegate")
def delegate(params: DelegateParams, ctx: ToolCallAgentContext) -> None:
    ctx.call_agent(PoetAgent, PoetSpec(topic=params.topic))
```

The tool's return value is ignored — the spawned agent's result becomes the tool
result. `call_agent()` can only be called once per tool execution.

## ConfigValue

A generic type for configuration fields that can be static or dynamic:

```python
type ConfigValue[T] = Callable[[], T | Awaitable[T]] | T
```

Three forms are supported:

```python
# Static value
config = ToolLoopConfig(max_llm_calls=10, ...)

# Sync callable
config = ToolLoopConfig(max_llm_calls=lambda: settings.max_calls, ...)

# Async callable
async def get_max_llm_calls() -> int:
    return await fetch_from_db("max_llm_calls")

config = ToolLoopConfig(max_llm_calls=get_max_llm_calls, ...)
```

## Cache strategy protocols

```python
SystemPromptCacheStrategy   # (messages: list[SystemMessage]) -> list[SystemMessage]
ToolsCacheStrategy          # (tools: list[Tool]) -> list[Tool]
MessagesCacheStrategy       # (non_system_session_messages, turn_messages) -> list[Message]
```


