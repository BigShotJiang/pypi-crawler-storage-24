# Prompt: Code Style Review

You are reviewing a Python package for code style violations. Your goal is to find every violation of the project's style rules and produce a report with exact file locations and fixes.

## Context

You will be given:
- The full source code of every file in the package
- The style rules (below)

This library is brand new with no users — there are no backwards compatibility constraints.

## Style rules

Review every file against ALL of the following rules:

### Rule 1: No `TYPE_CHECKING` imports

Using `if TYPE_CHECKING:` indicates circular dependencies between modules. This means classes are incorrectly distributed across files.

**Fix:** reorganize modules so the dependency graph is a DAG. Move the type that causes the cycle to a lower-level module that both sides can import directly.

### Rule 2: No `type: ignore` without exhausting alternatives

`# type: ignore` suppresses real errors. Before using it, first understand WHY the type checker complains and fix the root cause (e.g., widen a variable annotation, add an `isinstance` guard, restructure code).

`type: ignore` in production code requires an exceptional justification. In tests it's more tolerable but still a last resort.

### Rule 3: No re-exporting foreign types from `__init__.py`

A package's `__init__.py` must only export types **defined within that package**. Never re-export types that belong to another package.

**Why:** re-exports create a false sense of ownership. Consumers start importing `Foo` from package `bar` even though `Foo` is defined in package `baz`. This obscures the real dependency graph, makes refactoring fragile, and leads to circular import risks.

**Fix:** import from the package that owns the type. If many consumers need a type, that type lives in the wrong package — move it.

### Rule 4: Private members use double underscore

Private fields and methods must use name mangling (`__name`), not a single underscore (`_name`). Single underscore is only for protected members that subclasses are expected to access.

- `self.__connection` — private, not part of any subclass contract
- `self._provider` — protected, subclasses may read/use it
- `def __do_work(self)` — private method, internal implementation detail
- `def _on_event(self)` — protected method, subclasses may override

### Rule 5: Comments and docstrings must carry meaning

Every comment and docstring must explain something that isn't obvious from the code itself. If it merely restates the name of the method, class, or variable — delete it.

**Good docstring:** explains *why* something exists, what non-obvious behavior to expect, or what contract the caller must follow.

**Bad docstring:** `def close(self): """Close the connection."""` — says nothing the name doesn't already say.

**Prefer self-documenting code over comments.** If a comment explains *what* a block of code does, extract that block into a well-named method or variable instead. Comments should explain *why*, not *what*.

If removing a comment or docstring loses no information — remove it.

**Exception: complex compiler/introspection code.** Modules that perform heavy type introspection, AST-like analysis, or compilation (e.g., `compile.py`) benefit from detailed docstrings on every method — with input/output examples, edge case descriptions, and type alias resolution behavior. These docstrings are essential for maintainability because the code's intent is not obvious from its implementation. Do not flag these as "boilerplate" — just verify they are accurate.

### Rule 6: Class member ordering and helper placement

**Member ordering** inside a class — fields first, then methods. Within each group, order by visibility: public → protected → private.

```
class Foo:
    # 1. Public fields/properties
    # 2. Protected fields/properties  (_name)
    # 3. Private fields/properties    (__name)
    # 4. Public methods
    # 5. Protected methods            (_name)
    # 6. Private methods              (__name)
```

**No module-level helpers when a class owns the file.** If a file exists for a single class (or a small group of closely related classes), standalone helper functions must be methods of that class — `@staticmethod`, `@classmethod`, or private methods. This keeps helpers private-able and co-located with their only consumer.

Exception: truly generic utilities shared across unrelated files belong in a utility module.

### Rule 7: Use `self`/`cls` to call own methods, never the class name

Inside instance methods, call other methods via `self`. Inside class methods, use `cls`. Never spell out the full class name when calling from within the same class.

- `self.__parse(data)` — correct (instance method calling private method)
- `cls.__create(args)` — correct (classmethod calling private method)
- `MyClass.__parse(data)` — wrong (hardcodes class name, breaks inheritance)

**`@staticmethod` calling other methods of the same class:** if a `@staticmethod` needs to call other methods of the same class, convert it to a `@classmethod` so it can use `cls`. Do not extract to module-level functions — keep methods in the class they belong to.

**`type(self)` / `type(cls)` — avoid without a strong reason.** Constructing new instances via `type(self)(...)` instead of `ClassName(...)` is only justified when the method must return an instance of the actual runtime subclass (e.g., in a polymorphic hierarchy). For final or non-inherited classes, use the class name directly — it's clearer and more explicit.

### Rule 8: Every module must have `__all__`

Every `.py` file must define `__all__` listing all public symbols (classes, functions, type aliases, constants) that the module intentionally exports. Use a **list** (`[...]`), not a tuple.

- Place `__all__` after imports, before any code.
- Sorting is handled by ruff — no need to sort manually.
- `__init__.py` files also must have `__all__` — it lists everything the package exports.

**Why:** explicit `__all__` makes the public API of each module clear, prevents accidental exports, and tools (linters, IDEs, auto-importers) rely on it.

### Rule 9: No local imports

All imports must be at the top of the file. Local (deferred) imports inside functions or methods are prohibited — they indicate a circular dependency or misplaced code.

**Fix:** reorganize modules so the import can be top-level. If module A needs a type from module B at call time but can't import it at the top because B also imports A — the dependency graph has a cycle. Break it by moving the shared type to a lower-level module.

### Rule 10: `except A, B:` is valid Python 3 syntax

In Python 3, `except ValueError, TypeError:` is equivalent to `except (ValueError, TypeError):` — the comma creates a tuple of exception types. This is NOT the Python 2 "catch-and-bind" syntax. Both forms are correct; ruff formats to the comma form. Do not "fix" this.

### Rule 11: Exhaustive `match` is enforced by pyright — no `case _` needed

When all branches of a `match` statement cover every variant of an enum or union type, pyright's `reportMatchNotExhaustive` rule guarantees that adding a new variant will produce an error at every uncovered `match`. Do not add a `case _: raise` fallback — it makes the `match` appear exhaustive to pyright and **disables** the check, hiding the very problem it was meant to catch.

### Rule 12: Use `type` syntax for type aliases, no `from __future__ import annotations`

Type aliases must use the `type` statement (Python 3.10+):

```python
type StepAction = GotoStep | GotoAgent | Spawn
type StepRef = str | StepMethod
type AgentRef = str | type[AbstractAgent]
```

**Do NOT use:**
- Old-style aliases: `StepAction = GotoStep | GotoAgent | Spawn` (no `type` keyword)
- `from __future__ import annotations` for forward references

**Why:** `type` statements create their own scope and evaluate lazily, making forward references work automatically. A type alias can reference types defined later in the same file without needing `from __future__ import annotations` or quoted strings.

**Example:**

```python
# This works without any special imports:
type StepRef = str | StepMethod  # StepMethod defined below

@dataclasses.dataclass
class Goto:
    step: StepRef  # Forward reference works

type StepMethod = Callable[..., StepResult]  # Defined after use
```

### Rule 13: Import from package, not from internal modules

When importing types from another package, import from the package's `__init__.py`, not from internal submodules. Every package must export all its public types via `__all__` in its `__init__.py`.

```python
# Correct — import from the package
from flowra.agent import AgentDefinition, GotoStep

# Wrong — reaching into internal modules
from flowra.agent.model import AgentDefinition
from flowra.agent.model import GotoStep
```

Inside the library itself, use relative imports from the package, not from submodules:

```python
# Correct — relative import from sibling package
from ..agent import AgentDefinition, GotoStep

# Wrong — relative import into internal module
from ..agent.model import AgentDefinition
```

**Why:** internal module structure is an implementation detail. Importing from submodules creates tight coupling to the package's internal layout, making refactoring (renaming/moving files) break all consumers. If a type isn't in `__init__.py` — either add it to `__all__`, or it's not part of the public API.

**Exception:** relative imports within the same package may reference sibling modules directly (e.g., `from .session_storage import SessionStorage` inside `runtime/storage/`).

### Rule 14: Dataclasses: `frozen=True, kw_only=True` by default

Dataclasses must be `frozen=True, kw_only=True` unless there is a clear, documented reason not to be.

- **`frozen=True`** — immutability is the default. Mutable dataclasses are only acceptable when mutation is essential to the class's purpose (e.g., an execution node that tracks changing state during a tree walk).
- **`kw_only=True`** — positional construction is error-prone for dataclasses with multiple fields. Only omit when there's a strong ergonomic reason (e.g., a single-field wrapper).

If a dataclass is not frozen or not kw_only, there must be a comment explaining why.

```python
# Default — frozen and kw_only
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Val:
    v: str

# Mutable — justified by design (node is mutated during tree walk)
@dataclasses.dataclass(slots=True, kw_only=True)
class ExecutionNode:
    status: ExecutionStatus
    result: Any = None
```

### Rule 15: All classes must use `__slots__`

Every class must declare `__slots__` to prevent accidental attribute creation and reduce memory usage.

- **Dataclasses:** use `slots=True` in the decorator.
- **Regular classes:** define `__slots__` explicitly.
- **ABCs and base classes:** also must have `__slots__` (use `__slots__ = ()` if no fields).
- **Protocols:** `__slots__` does not apply to `Protocol` classes — they are type-checking constructs, never instantiated.
- **Enums:** `__slots__` does not apply to enums (`enum.Enum`, `enum.StrEnum`, etc.) — enum metaclass manages attributes itself.
- **Agent subclasses:** classes inheriting from `Agent[S, R]` must declare `__slots__` like any other class.

```python
# Dataclass — slots=True in decorator
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Goto:
    step: str
    agent: str | None = None

# Regular class — explicit __slots__
class Engine:
    __slots__ = ("__agents", "__storage", "__type_registry")

    def __init__(self) -> None:
        self.__agents: dict[str, AgentDefinition] = {}

# ABC — empty __slots__
class SessionStorage(abc.ABC):
    __slots__ = ()
```

### Rule 16: Never access private members via name mangling in tests

Tests must never access private (`__name`) members via name mangling (e.g., `obj._ClassName__method`). This is fragile, couples tests to implementation details, and defeats the purpose of encapsulation.

**Test through the public API.** If a private method needs testing, test it indirectly through the public method that calls it. Use mocks at the boundary (e.g., mock the HTTP client) to control inputs and verify outputs through the public interface.

If something truly cannot be tested through the public API, it's a sign the design needs refactoring — extract the logic into a separate testable unit with its own public API.

### Rule 17: Fix all violations you see, no exceptions

When reviewing or editing code, fix **every** rule violation you encounter in the files you touch — not just the ones related to the current task. "It was already like that" or "it's a pre-existing issue" is not a valid excuse. All code in this repository was written by you across different sessions — there is no "someone else's code" here. If you see a violation, fix it.

## Output format

```
# Code Style Review: flowra.<package_name>

## <filename>.py

### Line N: <Rule X violation>
**Current:**
<the offending code>
**Fix:**
<the corrected code>
**Reason:** <brief explanation>

### Line M: <Rule Y violation>
...

## <filename>.py
...

## Summary
- Files reviewed: N
- Violations found: N
- Breakdown by rule: Rule X: N, Rule Y: N, ...
```

## Important

- Report exact line numbers and exact code snippets.
- For each violation, show both the current code and the fix.
- Don't report false positives — only flag actual violations of the rules above.
- Don't review tests, documentation, or package structure here — only code style.
- Review EVERY file in the package, including `__init__.py`.
