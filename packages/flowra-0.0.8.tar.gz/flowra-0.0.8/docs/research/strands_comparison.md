# Strands Agents SDK vs Flowra — Comparison (March 2026)

Research date: 2026-03-08

## What Strands has that Flowra doesn't

| Capability | Strands | Flowra | Priority |
|---|---|---|---|
| **Streaming** | Full event streaming — each agent step streams to client | `LLMProvider.stream()` with `TextDelta`/`ThinkingDelta`/`ContentComplete` events; `ToolLoopAgent` auto-switches when delta hooks are set | — (implemented) |
| **Observability (OpenTelemetry)** | Built-in traces, metrics, export to X-Ray/CloudWatch/Jaeger | No — only manual hooks via `HookRegistry` + `Event[T]` | **High** — necessary for production |
| **Multi-agent patterns (Swarm, Graph, Workflow)** | Built-in coordinators: orchestrator-worker, peer swarm, DAG graph with auto-parallelization | `Spawn` (parallel children), `CallStep`/`CallAgent`, `GotoStep`/`GotoAgent` — primitives cover all patterns (see action items) | Low — covered by primitives |
| **More providers out of the box** | Bedrock, Anthropic, OpenAI, Gemini, Ollama, LiteLLM, llama.cpp | Anthropic Vertex, OpenAI, Google Vertex. `OpenAIProvider` works with any OpenAI-compatible server (Ollama, LM Studio, vLLM) | Low — covered via OpenAI compatibility |
| **Guardrails** | Integration with Amazon Bedrock Guardrails — content filtering, topic blocking, PII protection | None | Medium — depends on use case |
| **A2A (Agent-to-Agent) protocol** | Agents communicate across processes/services via standard protocol | No — agents only within a single runtime | Low for now — relevant for distributed systems |
| **TypeScript SDK** | Yes (preview) | No | Low — we are a Python library |
| **Session management with external stores** | DynamoDB, Bedrock AgentCore Memory, custom | InMemory, File, custom (but no ready-made cloud DB adapters) | Medium |
| **"Agents as tools"** | An agent can be a tool of another agent directly | `@agent_tool` decorator + `make_agent_tool()` — sub-agent runs its own system prompt and tool loop | — (implemented) |

## What Flowra has that Strands doesn't (or weaker)

| Capability | Flowra | Strands |
|---|---|---|
| **Crash recovery** | Full: persistence after each step, resume after crash | Session persistence exists, but step-level crash recovery — no |
| **Incremental dirty-tracking** | `Scalar[T]` and `AppendOnlyList[T]` save only changes | Saves state entirely |
| **State machine with compile-time checks** | `@step`, `GotoStep`/`GotoAgent`, `Spawn`, `CallStep`/`CallAgent` — compiler checks slots and types at class definition time | Model-driven loop — no explicit state machine |
| **Cooperative interrupts** | `InterruptToken` propagates through entire execution tree | No equivalent |
| **DI into tool handlers** | `FromToolService` marker — services injected into tool functions | Tools receive only tool input |

## Priority action items

1. ~~**Streaming** — most visible gap for user experience.~~ ✅ Implemented: `LLMProvider.stream()`, `on_text_delta`/`on_thinking_delta` hooks, TUI/console examples support streaming.
2. **Observability** — at minimum OpenTelemetry spans for LLM calls and tool execution. Our hooks are a good foundation.
3. ~~**More providers** — Ollama/LiteLLM adapter would be useful for local development.~~ ✅ `OpenAIProvider` with `base_url="http://localhost:11434/v1"` already works with Ollama (and any OpenAI-compatible server). Need documentation/example showing this setup.
4. ~~**Ready-made multi-agent patterns** — Graph/Workflow on top of our primitives.~~ ✅ Covered by existing primitives (`@step` + `Goto`/`Spawn`/`Call`). Strands' Graph (conditional DAG), Swarm (coordinator-driven delegation), and feedback loops all map directly to Flowra's state machine. Consider adding a "Multi-agent patterns" doc with recipes (router, pipeline, fan-out/fan-in, feedback loop).

## Sources

- [Introducing Strands Agents (AWS Blog)](https://aws.amazon.com/blogs/opensource/introducing-strands-agents-an-open-source-ai-agents-sdk/)
- [Strands Agents Documentation](https://strandsagents.com/latest/documentation/docs/)
- [Technical Deep Dive (AWS Blog)](https://aws.amazon.com/blogs/machine-learning/strands-agents-sdk-a-technical-deep-dive-into-agent-architectures-and-observability/)
- [Multi-Agent Patterns](https://dev.to/aws-builders/understanding-multi-agent-patterns-in-strands-agent-graph-swarm-and-workflow-4nb8)
- [Session Management](https://strandsagents.com/latest/documentation/docs/user-guide/concepts/agents/session-management/)
- [A2A Protocol](https://strandsagents.com/latest/documentation/docs/user-guide/concepts/multi-agent/agent-to-agent/)
- [Guardrails](https://strandsagents.com/latest/documentation/docs/user-guide/safety-security/guardrails/)
- [Streaming](https://strandsagents.com/latest/documentation/docs/user-guide/concepts/streaming/)
- [GitHub - sdk-python](https://github.com/strands-agents/sdk-python)
