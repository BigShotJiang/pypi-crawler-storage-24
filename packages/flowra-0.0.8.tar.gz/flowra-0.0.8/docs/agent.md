# Package `flowra.agent`

Define agents as step-based state machines with mandatory contracts. Each agent is a Python class
parameterized with `Agent[S, R]` (spec and result types), whose methods (decorated with `@step`)
form the states; returning `GotoStep`, `GotoAgent`, `Spawn`, or a result dataclass
controls transitions between them.

```
flowra/agent/
├── agent.py             # Agent[S, R](AbstractAgent) — generic base class with auto-compilation
├── step_decorator.py    # @step decorator (with entry=True support)
├── model.py             # Control flow (GotoStep, GotoAgent, CallStep, CallAgent, Spawn), type aliases
├── timeout.py           # TimeoutAgent, TimeoutExpired, timeout() helper
├── agent_store.py       # AgentStore (ABC) — slot creation and flush interface
├── service_locator.py   # ServiceLocator (ABC) — service provision and access
├── interrupt_token.py   # InterruptToken (ABC), InterruptedError, Interrupted result type
├── interrupt_helpers.py # with_interrupt() — race async iterators against InterruptToken
├── hooks.py             # HookRegistry, Event[T], HookProvider — typed event hook system
├── agent_registry.py    # AgentRegistry — hierarchical agent name/type resolution
├── stored_values.py     # Scalar[T], AppendOnlyList[T] — dirty-tracked state containers
└── compile.py           # compile_agent() — introspection, type registry
```

## Quick start

```python
import dataclasses
from flowra.agent import Agent, step

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetSpec:
    name: str

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetResult:
    greeting: str

class Greeter(Agent[GreetSpec, GreetResult]):
    @step(entry=True)
    async def greet(self, spec: GreetSpec) -> GreetResult:
        return GreetResult(greeting=f"Hello, {spec.name}!")
```

This defines a single-step agent. `GreetSpec` is the input (`S`), `GreetResult` is the output (`R`).
Every `Agent[S, R]` subclass **must** have exactly one `@step(entry=True)` method — the entry point.
Returning a result dataclass completes the agent. To execute agents, use `runtime`:

```python
from flowra.runtime import AgentRuntime

runtime = AgentRuntime(agents={"greeter": Greeter})
result = await runtime.run(agent=Greeter, spec=GreetSpec(name="World"))
print(result.greeting)  # "Hello, World!"
```

## Defining agents

### `Agent[S, R]`

Generic base class for agent implementations. `S` is the spec type (input), `R` is the result
type (output). When you subclass `Agent[S, R]`, the framework automatically scans for
`@step`-decorated methods and compiles them into an `AgentDefinition`
(stored as `cls.__agent_definition__`).

**Mandatory contract:**
1. Must have exactly one `@step(entry=True)` method
2. If parameterized (`Agent[MySpec, MyResult]`), the entry step's spec type must match `S`

Parameterization is optional — `class MyAgent(Agent):` is valid. When omitted,
the compiler infers `S` from the entry step's spec parameter and `R` as the union
of result types across all steps.

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore) -> None:
        # AgentStore and Scalar are explained in "State management" below
        self.counter = store.slot(Scalar[int], "counter")

    @step(entry=True)
    async def start(self, spec: MySpec) -> GotoStep:
        self.counter.set(self.counter.get(0) + 1)
        return GotoStep(step="process", spec=ProcessSpec(data=spec.value))

    @step
    async def process(self, spec: ProcessSpec) -> MyResult:
        return MyResult(answer=spec.data)
```

Subclasses inherit steps from parents (Method Resolution Order). A child can override a step
by defining a new method with the same `@step` tag — the match is by tag string,
not by method name.

### `NoSpec` / `NoResult`

Sentinel types for agents without input or output:

```python
class WorkerAgent(Agent[NoSpec, WorkerResult]):
    @step(entry=True)
    async def run(self) -> WorkerResult: ...

class FireAndForget(Agent[TaskSpec, NoResult]):
    @step(entry=True)
    async def execute(self, spec: TaskSpec) -> None: ...
```

## Steps and the `@step` decorator

A **step** is a method that represents one state of the agent's state machine.
Steps can be either synchronous (`def`) or asynchronous (`async def`).
The runtime calls steps one at a time: it invokes a step, receives its return value,
and uses that to decide what to do next (transition to another step, spawn children,
or complete the agent).

### `@step`

Marks a method as an agent step.

A **tag** is the string name that identifies a step. It is used for persistence, control-flow
references (`GotoStep`, `CallStep`), and step overriding. By default, the tag is the method name:

```python
@step                          # tag = method name ("process")
async def process(self) -> MyResult: ...

@step("custom_tag")            # tag = "custom_tag"
def process(self) -> MyResult: ...

@step()                        # tag = method name ("process")
async def process(self) -> MyResult: ...

@step("start", entry=True)    # tag = "start", entry point
async def start(self, spec: MySpec) -> GotoStep: ...
```

The `entry=True` parameter marks the single entry point of an `Agent[S, R]` subclass.
Exactly one step per agent must be marked as entry. The entry step's spec type must match
the agent's generic `S` parameter.

If a step's return type annotation contains a concrete type that is not
a dataclass and not `GotoStep | GotoAgent | Spawn | None`, a `TypeError` is raised at class
definition time. PEP 695 type aliases (`type X = A | B`) are resolved automatically,
including nested aliases.

### Dataclass-only constraint

All step parameters and return types (other than action types and `None`) **must be dataclasses**.
The compiler validates this at class definition time and raises `TypeError` for non-dataclass types.

```python
# GOOD — dataclass types:
@step(entry=True)
async def run(self, spec: UserInput) -> GreetResult: ...

# BAD — str is not a dataclass, raises TypeError:
@step(entry=True)
async def run(self, spec: UserInput) -> str: ...
```

## Control flow

Steps return one of: `GotoStep`, `GotoAgent`, `Spawn`, a result dataclass, or `None`.

- **`GotoStep`** — transition to another step within the same agent
- **`GotoAgent`** — transition to a different agent (the current agent ends)
- **`Spawn`** — fork multiple children to run in parallel, then reconvene at a join step
- **Result dataclass** — complete the agent and return a result to the caller
- **`None`** — complete the agent with no result

**Storage scopes.** Each agent execution has a **storage key** — an identifier for its
isolated set of stored values (`Scalar`, `AppendOnlyList` — defined in [State management](#state-management)).
`GotoStep`, `GotoAgent`, `CallStep`, and `CallAgent` accept an optional `storage_key`
to control which storage the target uses.

### `GotoStep`

Transition to another step within the same agent.

| Field         | Type                        | Default |
|---------------|-----------------------------|---------|
| `step`        | `str`                       | —       |
| `spec`        | `Any \| None`          | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None`  | `None`  |

The constructor accepts `StepRef` (`str | StepMethod`) for `step` — you can pass
either a tag string or a method reference (resolved to its tag automatically).

```python
# By tag string:
GotoStep(step="process")

# By method reference:
GotoStep(step=self.process)

# With spec:
GotoStep(step="process", spec=ProcessSpec(data="hello"))

# Fresh storage:
GotoStep(step=self.reset, storage_key=NEW_SCOPE)
```

**`storage_key`** controls which persistent state the target step uses
(see [State management](#state-management) for details on stored values).
Each unique key corresponds to an isolated set of stored values.
When the runtime starts a step with a given storage key, it loads the
stored values from persistent storage for that key:

| `storage_key` value   | Behavior                       |
|-----------------------|--------------------------------|
| `None` (default)      | Keep current storage           |
| `"explicit"`          | Switch to that key             |
| `NEW_SCOPE`           | Auto-generate unique key       |

`NEW_SCOPE` is a sentinel value that forces a fresh storage scope.

### `GotoAgent`

Transition to a different agent. The current agent ends, and the target agent starts
from its entry step.

| Field         | Type                         | Default |
|---------------|------------------------------|---------|
| `agent`       | `str \| type[AbstractAgent]` | —       |
| `spec`        | `Any \| None`                | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None`   | `None`  |

```python
# By type:
GotoAgent(agent=OtherAgent, spec=OtherSpec(data="hello"))

# By name:
GotoAgent(agent="other", spec=OtherSpec(data="hello"))

# With explicit storage key:
GotoAgent(agent=OtherAgent, storage_key="calc")
```

Agents are always black boxes — `GotoAgent` enters the target through its `entry_step`,
not an arbitrary step.

### `Spawn`

Fork child agents, then reconvene at a join step.

Constructor accepts `StepRef` for `then` — tag string or method reference (same as `GotoStep.step`).

**Basic form** — positional children, all must complete (implicit `WhenAll`):

```python
@step
async def dispatch(self) -> Spawn:
    return Spawn(
        CallAgent(agent=WorkerAgent, spec=TaskSpec(id=1)),
        CallAgent(agent=WorkerAgent, spec=TaskSpec(id=2)),
        then=self.collect,
    )

@step
async def collect(self, results: list[WorkerResult]) -> MyResult:
    total = sum(r.value for r in results)
    return MyResult(total=total)
```

**Keyword form** — equivalent, uses `children=` list:

```python
Spawn(
    children=[
        CallAgent(agent=WorkerAgent, spec=TaskSpec(id=1)),
        CallAgent(agent=WorkerAgent, spec=TaskSpec(id=2)),
    ],
    then=self.collect,
)
```

**Combinator form** — partial completion with `WhenAny`, `WhenN`, or nested trees:

```python
Spawn(
    WhenAny(
        CallAgent(agent="worker", tag="worker"),
        timeout(seconds=30),
    ),
    then=self.join,
)
```

When the spawn tree is satisfied, unneeded children are cooperatively interrupted
(their `InterruptToken` is set). Interrupted children return `Interrupted()` as their
result — the join step can detect this via nullable parameters
(see [Step parameter injection](#step-parameter-injection) below).

### `WhenAll` / `WhenAny` / `WhenN`

Combinators that control when a `Spawn` is considered satisfied:

| Combinator           | Satisfied when                            | Unsatisfied children |
|----------------------|-------------------------------------------|----------------------|
| `WhenAll(*nodes)`    | All nodes complete with real results      | —                    |
| `WhenAny(*nodes)`    | Any one node completes with a real result | Interrupted          |
| `WhenN(*nodes, n=k)` | `k` nodes complete with real results      | Interrupted          |

Combinators are composable — they can be nested:

```python
# Wait for both workers, OR timeout — whichever happens first
Spawn(
    WhenAny(
        WhenAll(
            CallAgent(agent="worker", spec=TaskSpec(id=1), tag="w1"),
            CallAgent(agent="worker", spec=TaskSpec(id=2), tag="w2"),
        ),
        timeout(seconds=60),
    ),
    then=self.join,
)
```

When positional args are passed to `Spawn` without an explicit combinator,
multiple args are wrapped in `WhenAll`; a single `CallStep`/`CallAgent` is used as-is.

### `timeout`

Built-in helper that creates a child agent for time-based deadlines:

```python
from flowra.agent import timeout

# Use in Spawn — race a worker against a deadline:
Spawn(
    WhenAny(
        CallAgent(agent="worker", tag="worker"),
        timeout(seconds=30),
    ),
    then=self.join,
)
```

`timeout(seconds=..., minutes=...)` returns a `CallAgent` targeting the internal
timeout agent. When the deadline expires, the agent returns `TimeoutExpired(seconds=...)`.
If interrupted before expiry (e.g., because a sibling completed first in `WhenAny`),
it returns `Interrupted()` like any other interrupted child.

The join step binds results by type — no annotations needed when types are unambiguous:

```python
@step
async def join(
    self,
    worker: WorkerResult | None = None,
    expired: TimeoutExpired | None = None,
) -> FinalResult:
    if worker is not None:
        return FinalResult(value=worker.value)
    # timeout fired, worker was interrupted
    return FinalResult(value="timed out")
```

Use `Annotated[T, FromChild("tag")]` only when multiple children return the same type
and you need to distinguish them by tag (see [Step parameter injection](#step-parameter-injection)).

### `CallStep` / `CallAgent`

Each child in `Spawn.children` is described by a `CallStep` (same agent) or `CallAgent`
(different agent).

**`CallStep`:**

| Field         | Type                        | Default |
|---------------|-----------------------------|---------|
| `step`        | `str`                       | —       |
| `spec`        | `Any \| None`               | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None`  | `None`  |
| `tag`         | `str \| None`               | `None`  |

Same as `GotoStep`: constructor accepts `StepRef` (tag string or method reference).

**`CallAgent`:**

| Field         | Type                         | Default |
|---------------|------------------------------|---------|
| `agent`       | `str \| type[AbstractAgent]` | —       |
| `spec`        | `Any \| None`                | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None`   | `None`  |
| `tag`         | `str \| None`                | `None`  |

`tag` labels a child so the join step can bind its result by tag
(see `FromChild("tag")` in [Step parameter injection](#step-parameter-injection)).

```python
# Same agent:
CallStep(step="compute", spec=TaskSpec(id=1))
CallStep(step=self.compute, storage_key="worker-1")

# Cross-agent:
CallAgent(agent=WorkerAgent, spec=TaskSpec(id=1))
CallAgent(agent="calc", storage_key="calc")

# With tag — bind result by tag in the join step:
CallAgent(agent=CalcAgent, spec=CalcSpec(expr="2+2"), tag="calc")
CallAgent(agent=EchoAgent, spec=EchoSpec(text="hi"), tag="echo")
```

**Child state behavior:**

| Scenario                         | State behavior                                              |
|----------------------------------|-------------------------------------------------------------|
| Same agent, no `storage_key`     | Copy of parent's state — mutations do not affect the parent |
| Same agent, with `storage_key`   | Independent state — loaded from own persistent storage      |
| Different agent                  | Independent state — loaded from own persistent storage      |

Same-agent children without `storage_key` get a full copy (new `Scalar`/`AppendOnlyList`
instances initialized with the parent's current values). This is useful for parallel
workers that need context from the parent but should not modify the parent's state.

## Subagents

Agents can declare internal helper agents using the `__subagents__` class variable.
Subagents are automatically registered in the runtime with namespaced names
(e.g., if the parent is `"loop"`, a subagent named `"tool_call"` becomes
`"loop/tool_call"`).

```python
class ToolCallAgent(Agent[ToolCallSpec, ToolCallResult]):
    @step(entry=True)
    async def execute(self, spec: ToolCallSpec) -> ToolCallResult:
        ...

class ToolLoopAgent(Agent[ToolLoopSpec, ToolLoopResult]):
    __subagents__ = {
        "tool_call": ToolCallAgent,
    }

    @step(entry=True)
    async def execute_tools(self, spec: ToolLoopSpec) -> Spawn:
        return Spawn(
            children=[CallAgent(agent=ToolCallAgent, spec=ToolCallSpec(...))],
            then=self.collect,
        )

    @step
    async def collect(self, result: ToolCallResult) -> ToolLoopResult:
        return ToolLoopResult(data=result.data)
```

Nested subagents work recursively (e.g., `"parent/child/grandchild"`).

`__subagents__` is inherited via Method Resolution Order: a subclass that does not redeclare it
inherits the parent's subagent map. Override with `__subagents__ = {}` to clear.

**Referencing subagents:**

```python
CallAgent(agent=ToolCallAgent)                   # by type (contextual resolution)
CallAgent(agent="./tool_call")                    # relative — my child
CallAgent(agent="../sibling")                     # relative — my sibling
CallAgent(agent="loop/tool_call")                 # absolute name
```

Note: with `CallAgent`, agents are always entered through their `entry_step` — you don't
specify which step to call.

**Type-based resolution** walks the agent hierarchy from the current agent upward to root,
so a parent agent can reference its own subagent type without knowing its registration name.
The same class can be a subagent of multiple parents without conflict — each parent resolves
it to its own namespace.

**Relative paths** use Unix-style syntax:
- `"./child"` — my child subagent
- `"../sibling"` — sibling (go up one level, then down)
- `"../../uncle"` — go up two levels

E.g., if the current agent is `"parent/child"`, then `"./gc"` resolves to
`"parent/child/gc"` and `"../sibling"` resolves to `"parent/sibling"`.

**Name validation:** Agent names must match `[a-zA-Z0-9_-]+` (slashes are reserved for
hierarchy separators).

**One class = one name per hierarchy level.** Each agent class can only be registered once at
a given level. This is required for type-based resolution: `CallAgent(agent=WorkerAgent)` must
map to exactly one name. Registering the same class under two names (`{"a": Worker, "b": Worker}`)
raises `ValueError`.

To run multiple instances of the same agent class, register it once and call it multiple times
with different specs and tags:

```python
runtime = AgentRuntime(agents={"coord": Coordinator, "worker": WorkerAgent})

# Inside Coordinator:
Spawn(
    WhenAny(
        CallAgent(agent="worker", spec=TaskSpec(model="fast"), tag="fast"),
        CallAgent(agent="worker", spec=TaskSpec(model="slow"), tag="slow"),
    ),
    then=self.join,
)
```

## State management

Agents persist state across steps using **stored values** — mutable containers created
in the constructor via `store.slot()`. The runtime automatically saves dirty values
at step boundaries. You can also flush manually mid-step via `store.flush()`.

### Creating slots

Slots are created in the agent constructor using `AgentStore.slot()`:

```python
from flowra.agent import Agent, AgentStore, AppendOnlyList, Scalar, step

class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore) -> None:
        self.counter = store.slot(Scalar[int], "counter")
        self.log = store.slot(AppendOnlyList[str], "log")

    @step(entry=True)
    async def work(self, spec: MySpec) -> MyResult:
        self.counter.set(self.counter.get(0) + 1)
        self.log.append(f"step {self.counter.get()}")
        return MyResult(count=self.counter.get())
```

The first argument must be `Scalar[T]` or `AppendOnlyList[T]` — the type determines
which container is created. The second argument is the storage key used for persistence.

A new `Scalar` starts **unset** — it holds no value until explicitly set via `set()`
or `restore()`. Use `get(default)` to provide an explicit fallback for unset scalars.

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore) -> None:
        self.counter = store.slot(Scalar[int], "counter")
        self.name = store.slot(Scalar[str], "name")
        self.config = store.slot(Scalar[dict[str, int]], "config")

    @step(entry=True)
    async def work(self, spec: MySpec) -> MyResult:
        self.counter.get(0)        # returns 0 if unset
        self.name.get("")          # returns "" if unset
        self.counter.get()         # raises LookupError if unset
```

### `AgentStore`

Interface for creating slots and flushing state. The runtime provides the implementation
and injects it into the agent's `__init__`.

| Method                                              | Description                                                   |
|-----------------------------------------------------|---------------------------------------------------------------|
| `slot(Scalar[T], key) -> Scalar[T]`                 | Create a scalar slot with dirty tracking                      |
| `slot(AppendOnlyList[T], key) -> AppendOnlyList[T]` | Create an append-only list slot                               |
| `flush()`                                           | Persist dirty state immediately, without waiting for step end |

`slot()` can only be called during `__init__` — after construction, the runtime seals
the store and further `slot()` calls raise `RuntimeError`.

### `flush()`

`flush()` persists dirty state immediately, without waiting for a step boundary.

**Caution:** after `flush()`, state is persisted but the step continues running. If the
step crashes after a flush, on resume the step will re-execute from the beginning with the
already-flushed state. The step must handle this correctly — check whether data was already
written before writing again. See `ToolLoopAgent.start` for an example of this pattern
(`if not self.__turn_messages.get_all()` guard).

```python
from flowra.agent import Agent, AgentStore, Scalar, step

class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore) -> None:
        self.store = store
        self.progress = store.slot(Scalar[str], "progress")

    @step(entry=True)
    async def process(self, spec: MySpec) -> MyResult | None:
        self.progress.set("halfway")
        await self.store.flush()  # persist now, don't wait for step end
        # ... continue processing ...
```

### `Scalar[T]`

Mutable scalar with dirty tracking. Only changed values are persisted.

```python
self.counter.set(self.counter.get(0) + 1)
```

| Method                | Description                                                       |
|-----------------------|-------------------------------------------------------------------|
| `get(default?) -> T`  | Value if set; `default` if provided; `LookupError` otherwise      |
| `has_value() -> bool` | Whether the scalar holds a value                                  |
| `set(value)`          | Set the value, mark dirty                                         |
| `is_dirty()`          | Whether the value changed since last clean                        |
| `mark_clean()`        | Reset dirty flag                                                  |
| `restore(v)`          | Replace value and reset dirty flag (for persistence restore)      |

### `AppendOnlyList[T]`

Append-only list with incremental persistence — only newly appended items are written
on each save.

```python
self.messages.append(new_message)
self.messages.extend([msg1, msg2])
all_messages = self.messages.get_all()
```

| Method              | Description                                                             |
|---------------------|-------------------------------------------------------------------------|
| `get_all() -> list` | All items                                                               |
| `append(item)`      | Append one item and mark as unflushed                                   |
| `extend(items)`     | Append multiple items and mark as unflushed                             |
| `get_unflushed()`   | Items appended since last clean                                         |
| `mark_clean()`      | Reset unflushed counter                                                 |
| `restore(items)`    | Replace all items and reset unflushed counter (for persistence restore) |

## Services: `ServiceLocator`

Interface for service provision and access. The runtime provides the implementation and injects
it into the agent's `__init__` (via the same DI mechanism as `AgentStore`).

"Sealed" means the method can only be called during `__init__` — after construction, the
runtime locks it and further calls raise an error. This prevents accidental mutation mid-step.

| Method / Property               | Sealed | Description                                                                 |
|---------------------------------|--------|-----------------------------------------------------------------------------|
| `provide(type[T], instance: T)` | yes    | Register a typed service for descendant agents (runtime `isinstance` check) |
| `services` (property)           | no     | All services available in the current scope (`dict[type, Any]`)             |

`provide()` registers a service that is propagated to all descendant agents
(children, grandchildren, etc.). The call is generic and type-safe — the runtime
verifies `isinstance(instance, service_type)` and raises `TypeError` on mismatch.
Descendants receive the service through constructor injection:

```python
# Parent registers a service:
class ParentAgent(Agent[ParentSpec, ParentResult]):
    def __init__(self, services: ServiceLocator, my_service: MyService) -> None:
        services.provide(MyService, my_service)

# Child (and grandchild) receives it automatically:
class ChildAgent(Agent[ChildSpec, ChildResult]):
    def __init__(self, my_service: MyService) -> None:
        self.service = my_service
```

## Cooperative interrupts: `InterruptToken`

Read-only interrupt interface inspired by .NET's `CancellationToken` / `CancellationTokenSource`
pattern. The runtime always provides `InterruptToken` — agents request it via constructor injection.

| Method / Property        | Description                                                                 |
|--------------------------|-----------------------------------------------------------------------------|
| `interrupted` (property) | Whether interrupt was signaled                                              |
| `check()`                | Raise `InterruptedError` if the token has been interrupted                  |
| `wait()`                 | Block until interrupted. Returns immediately if already interrupted.        |

### `InterruptedError` exception

`InterruptedError` is the exception raised by `check()` and `with_interrupt()`. It signals that
an operation was cancelled via the interrupt mechanism.

**If a step raises `InterruptedError` (directly or via `check()` / `with_interrupt()`), the engine
catches it per-node and converts it to an `Interrupted()` result.** This result flows up through
the execution tree via auto-propagation (see [Interrupted result type](#interrupted-result-type)).
Agents don't need to manually check `interrupted` and return early — just call `check()` or use
`with_interrupt()` and let the exception propagate.

```python
from flowra.agent import Agent, InterruptToken, step

class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def process(self, spec: MySpec) -> MyResult:
        # Raises InterruptedError if the token is set — node returns Interrupted()
        self.interrupt.check()
        # ... processing ...
        return MyResult(answer=42)
```

If an agent wants to handle interruption gracefully (e.g., return partial results),
it can catch `InterruptedError` explicitly:

```python
from flowra.agent import Agent, InterruptedError, InterruptToken, with_interrupt, step

class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def process(self, spec: MySpec) -> MyResult:
        items = []
        try:
            async for item in with_interrupt(some_stream(), self.interrupt):
                items.append(item)
        except InterruptedError:
            return MyResult(items=items, partial=True)
        return MyResult(items=items, partial=False)
```

### `Interrupted` — typed result for interrupted children

When a child agent is interrupted (e.g., because a sibling won in `WhenAny`), the engine
catches `InterruptedError` and converts it into an `Interrupted` result that flows through
the execution tree as a normal value.

| Field    | Type           | Default |
|----------|----------------|---------|
| `reason` | `str \| None`  | `None`  |

The join step can bind `Interrupted` results — use nullable types to detect which
children were interrupted:

```python
from flowra.agent import Interrupted

@step
async def join(
    self,
    worker: WorkerResult | None = None,
    interrupted: Interrupted | None = None,
) -> FinalResult:
    if worker is not None:
        return FinalResult(value=worker.value)
    # worker was interrupted — interrupted.reason may contain details
    return FinalResult(value="interrupted")
```

When multiple children share the same result type, use `FromChild("tag")` to
disambiguate:

```python
@step
async def join(
    self,
    calc: Annotated[WorkerResult | None, FromChild("calc")],
    echo: Annotated[WorkerResult | None, FromChild("echo")],
) -> FinalResult:
    ...
```

If a join step has no parameters that accept `Interrupted`, and some children were
interrupted, the interrupt auto-propagates — the parent also returns `Interrupted()`.

### `with_interrupt` — racing async iterators

`with_interrupt` wraps any `AsyncIterator[T]` so it raises `InterruptedError` when
the token fires — even if `__anext__()` is blocked on I/O:

```python
from flowra.agent import InterruptToken, with_interrupt

async def consume(stream: AsyncIterator[str], token: InterruptToken) -> list[str]:
    items = []
    async for item in with_interrupt(stream, token):
        items.append(item)
    return items  # only reached if stream completes without interrupt
```

On each iteration, `__anext__()` and `token.wait()` are raced via
`asyncio.wait(FIRST_COMPLETED)`. If the token wins, the underlying iterator
is closed (`aclose()`) and `InterruptedError` is raised.

**Key behaviors:**

- **Raises `InterruptedError`** when the token fires — the exception propagates up the
  call stack. Catch it explicitly if you need to handle partial results.
- **If the token is already interrupted** before iteration starts, raises `InterruptedError`
  immediately without yielding any items.
- **Exceptions from the underlying iterator** propagate normally — `with_interrupt`
  does not suppress them.
- **`aclose()` is always called** on the underlying iterator, whether the loop
  completes normally or is interrupted — cleanup is guaranteed.

## Dependency injection

### Constructor injection

When a subclass of `Agent` is compiled, its `__init__` parameters are inspected.
The runtime injects values by matching parameter type annotations:

- **Built-in services** (always available, no registration needed):

  | Service          | Purpose                                               | Sealed after construction        |
  |------------------|-------------------------------------------------------|----------------------------------|
  | `AgentStore`     | `slot()` — create slots; `flush()` — persist mid-step | `slot()` — yes; `flush()` — no   |
  | `ServiceLocator` | Register services (`provide`), access `services` dict | `provide` — yes; `services` — no |
  | `InterruptToken` | Check `interrupted`, `wait()` for cooperative stop    | — (read-only, never sealed)      |

- Other types are resolved from the runtime's `services` dict or from parent
  agents via `ServiceLocator.provide()`

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore, services: ServiceLocator, provider: LLMProvider) -> None:
        self.counter = store.slot(Scalar[int], "counter")
        self.services = services
        self.provider = provider
```

If a parameter's type is not found in the available services and has no default value,
the behavior depends on the type annotation:
- `T | None` (nullable) — the runtime passes `None` automatically
- `T` (non-nullable, no default) — Python raises `TypeError` when the constructor is called

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(
        self,
        store: AgentStore,
        provider: LLMProvider,               # required — TypeError if not in services
        config: AppConfig | None,            # nullable — None if not in services
        logger: Logger | None = None,        # nullable with explicit default
    ) -> None: ...
```

**Note:** Service lookup uses exact type matching. If you register `MyService`, a
parameter typed as a superclass of `MyService` will not match — use the exact type.

### Step parameter injection

Step parameters are bound by matching their type annotations against available values.
There are three sources of values:

1. **Step spec** — passed via `GotoStep(spec=...)`, `CallStep(spec=...)`, or as the initial spec for an entry step
2. **Agent spec** — the spec passed when the agent was first invoked; persisted and available in any step
3. **Child outputs** — results from `Spawn` children, collected when all children complete

By default, the runtime checks **all sources** when binding a parameter. If the same object
appears in multiple sources (e.g., the step spec is the same object as the agent spec in the
entry step), it is deduplicated by `id()`.

**`From*` markers** narrow binding to a specific source. Use `Annotated[T, FromSpec]`,
`Annotated[T, FromAgentSpec]`, `Annotated[T, FromChild]`, or `Annotated[list[T], FromChildren]`
when there is ambiguity (i.e., the same type could match multiple sources).

| Parameter type                          | Injected value                                  |
|-----------------------------------------|-------------------------------------------------|
| `T` (dataclass)                         | First match from any source                     |
| `Annotated[T, FromSpec]`               | Step-level spec only                            |
| `Annotated[T, FromAgentSpec]`          | Agent-level spec only                           |
| `Annotated[T, FromChild]`             | First child result matching `T`                 |
| `Annotated[T, FromChild("tag")]`       | Child result whose `CallStep`/`CallAgent` `tag` matches |
| `Annotated[list[T], FromChildren]`     | All child results matching `T`                  |
| `list[T]`                               | All child results matching `T` (from any source)|
| `T \| None`                             | Match or `None` if no candidate found           |

Union types and type aliases are supported:

```python
from typing import Annotated
from flowra.agent import FromSpec, FromChild, FromChildren

type AnyWorkerResult = CalcResult | EchoResult

@step
async def join(self, spec: MySpec, results: list[WorkerResult]) -> MyResult:
    # results — all child results of type WorkerResult (from Spawn children)
    ...

@step
async def collect(self, results: list[CalcResult | EchoResult]) -> MyResult:
    # results — all child results matching CalcResult or EchoResult
    ...

@step
async def collect_alias(self, results: list[AnyWorkerResult]) -> MyResult:
    # same as above — type alias is resolved automatically
    ...
```

**Nullable parameters:** If a parameter is typed as `T | None`, the runtime passes `None`
when no matching value is found (instead of raising an error). This works for all binding
sources.

```python
@step(entry=True)
async def start(self, spec: MySpec | None) -> GotoStep:
    # spec is None if no spec was provided
    ...

@step
async def join(self, result: WorkerResult | None = None) -> MyResult:
    # result is None if no child produced a WorkerResult
    ...
```

**Disambiguation with `FromSpec` / `FromAgentSpec`:**

```python
@step
async def process(
    self,
    spec: Annotated[ProcessSpec, FromSpec],          # step-level spec only
    original: Annotated[InitialSpec, FromAgentSpec],  # agent-level spec (persisted)
) -> MyResult:
    ...
```

`FromSpec` and `FromAgentSpec` are mutually exclusive — the same parameter cannot have both markers.

## Hooks: `HookRegistry`

Typed event hook system for lifecycle events. Register handlers for event dataclasses.
Supports multiple handlers per event, sync/async transparency, and composition via `HookProvider`.

```python
from flowra.agent import HookRegistry

hooks = HookRegistry()
hooks.on(MyEvent, lambda e: print(e.data.value))
```

| Method                                      | Description                                      |
|---------------------------------------------|--------------------------------------------------|
| `on(event_type, handler, *, prepend=False)` | Register a handler for an event type             |
| `has_handlers(event_type) -> bool`          | Check if any handlers are registered             |
| `add(provider: HookProvider)`               | Register all hooks from a HookProvider           |
| `async emit(data: T) -> T`                  | Wrap data in `Event`, call handlers, return data |
| `propagate_to(target, *, only, exclude)`    | Forward events to another registry               |

Handlers receive `Event[T]` where `T` is the event dataclass. `Event` has two fields:
`data: T` (the event payload) and `context: HookContext | None` (metadata stamped by emit).
`HookContext` carries `agent_type: type[AbstractAgent] | None` and `agent_path: str`.
Handlers can mutate fields of `event.data` (assuming the payload dataclass is not frozen) — the caller of `emit()` receives the modified data.

### `HookProvider`

Group related hooks into a reusable unit. Implement the `register_hooks` method:

```python
from flowra.agent import Event, HookProvider, HookRegistry

class LoggingHooks:
    def register_hooks(self, registry: HookRegistry) -> None:
        registry.on(BeforeLLMCallEvent, self.__log_llm)
        registry.on(AfterToolCallEvent, self.__log_tool)

    def __log_llm(self, event: Event[BeforeLLMCallEvent]) -> None:
        print(f"LLM call: {event.context.agent_path}")

    def __log_tool(self, event: Event[AfterToolCallEvent]) -> None:
        print(f"Tool: {event.data.tool_name}")

hooks = HookRegistry()
hooks.add(LoggingHooks())
```

### `propagate_to`

Forward events from one registry to another. Useful for parent agents that want to
observe child agent events:

```python
child_hooks = HookRegistry()
parent_hooks.propagate_to(child_hooks)                          # forward all events
parent_hooks.propagate_to(child_hooks, only=[MyEvent])          # forward only MyEvent
parent_hooks.propagate_to(child_hooks, exclude=[NoisyEvent])    # forward all except NoisyEvent
```

`only` and `exclude` accept lists of event types and are mutually exclusive.

## Type aliases

Useful in step return type annotations:

```python
type StepAction = GotoStep | GotoAgent | Spawn
type StepRef = str | StepMethod
type AgentRef = str | type[AbstractAgent]
type SpawnChild = CallStep | CallAgent
type SpawnNode = SpawnChild | WhenAll | WhenAny | WhenN
```

`StepAction` groups all control-flow commands — use it when a step may return
any flow control command alongside a result:

```python
@step
async def process(self) -> StepAction | MyResult:
    if done:
        return MyResult(answer=42)
    return GotoStep(step=self.next_step)
```

