# TODO

## State

- **`FORK` storage key for explicit forking.** Currently `CallStep` always forks state into a
  new scope, which is surprising — a child step logically runs inside the same agent, so you'd
  expect it to share state by default. Add a `FORK` sentinel (alongside `NEW_SCOPE`) that
  explicitly requests a forked copy of the parent's state. Then change `CallStep` default to
  run on the same scope (no fork), and require `storage_key=FORK` when isolation is needed.
  `NEW_SCOPE` creates a fresh empty scope (as now); `FORK` copies the parent's scope;
  no `storage_key` means shared state. This makes the forking behavior opt-in and visible.

- **Lazy fork / copy-on-write scope.** Currently `RuntimeScope.fork()` copies all scalars
  and append-only lists eagerly. For large state this is expensive. Make it lazy: child
  reads from parent until first write, copies only the specific field on `set()`/`append()`.
  User contract stays the same — child sees a snapshot of parent state at spawn time,
  but the implementation avoids upfront copying.
- **Frozen list.** Immutable list in state (like Scalar, but for lists). Can be created
  cheaply from `append_only` (slice without copying) or from another frozen list. Useful
  when a child agent needs a snapshot of the parent's list.


## Pre-built agents

- **`LLMCallAgent` — single LLM call with streaming.** Create a simple pre-built agent in
  `flowra/lib/` — one LLM call, messages in → response out, no tool loop, no history. Own
  hook events (independent from ToolLoopAgent events — no shared `ToolLoopAgentContext`).
  Auto-switches to streaming when delta handlers are registered (same pattern as ToolLoopAgent
  line 171). Solves the problem that streaming from a plain `Agent` requires manually iterating
  `provider.stream()` and emitting custom hook events.

## Hooks

- **Guardrails hooks package.** Ready-made hook set for content filtering and PII protection.
  Input guardrail (`UserMessageEvent`) checks/blocks user messages, output guardrail
  (`ResultMessageEvent`) checks/redacts LLM responses. Hooks support modification —
  e.g. replace `messages` in `UserMessageEvent`, replace `result` in `AfterToolCallEvent`.
  Need integration with a moderation backend (Bedrock Guardrails, OpenAI Moderation API,
  or custom). Two modes: blocking and notify-only (shadow/logging).

- **OpenTelemetry hooks package.** Provide a ready-made set of hooks that emit OTel spans
  for LLM calls, tool calls, and agent iterations. All hook points already exist
  (`BeforeLLMCallEvent`/`AfterLLMCallEvent`, `BeforeToolCallEvent`/`AfterToolCallEvent`,
  `StartIterationEvent`). Implementation is straightforward — register a `HookProvider`
  that opens/closes OTel spans in matching event pairs.


## Capabilities (dynamic modes)

- **Capability packs — dynamically loadable modes.** A `Capability` bundles a system prompt
  fragment, a set of tools, and optionally an LLM config override. Capabilities can be
  activated/deactivated during the agent's tool loop (by the agent itself via a special tool,
  or programmatically via `ToolLoopAgentContext`). On each iteration, `ToolLoopAgent` assembles
  the active set: merges system prompts from all active capabilities, unions their tool sets,
  applies LLM config overrides. Similar to how Claude Code switches between planning/coding/etc.
  Building blocks already exist (`ConfigValue` callables, `allowed_tools`/`denied_tools`,
  `on_start_iteration`, `ToolLoopAgentContext`), but there's no unified abstraction tying
  them together. A capability could also carry hooks (e.g. a "verbose" capability that adds
  logging hooks when activated). Pairs well with composable hooks.


## Agent generics

- **Replace `NoSpec`/`NoResult` with `None` in `Agent[S, R]`.** Currently sentinel classes
  `NoSpec` and `NoResult` are used to mean "no spec" / "no result":
  `Agent[NoSpec, ChatResult]`, `Agent[MySpec, NoResult]`. Replace with `None`:
  `Agent[None, ChatResult]`, `Agent[MySpec, None]`. In `__flatten_spec_types` and
  `__flatten_result_types` add `if tp is type(None): return ()`. Remove `NoSpec`/`NoResult`
  classes. Update all usages in code, tests, examples, docs.


## Agent-as-tool

- **Verify union-in-dataclass spec for agent tools.** The docs (`docs/lib.md`, "Agents as tools")
  claim that polymorphic input can be achieved by wrapping a union in a dataclass
  (`class AnimalSpec: animal: Dog | Cat`). Need to check the full chain:
  - Does `marshmallow_recipe` generate a correct JSON schema for `Dog | Cat` union field?
    What does the schema look like — `oneOf`/`anyOf`? Or does it fail entirely?
  - How does this schema land in `Tool.input_schema` and ultimately in the LLM request?
    LLM APIs typically expect `"type": "object"` — nested `oneOf`/`anyOf` may confuse the model.
  - Does the LLM actually produce valid JSON that deserializes back through `mr.load()`?
    Round-trip: schema → LLM output → deserialization → correct `Dog` or `Cat` instance.
  - If the schema is technically valid but LLM-unfriendly (deep nesting, discriminator fields),
    the docs recommendation is misleading even if the code works.
  - If this doesn't work well — remove the recommendation from docs, document the actual
    limitation, and consider alternatives (e.g. separate tools per variant, or a string
    discriminator + flat fields).


## Documentation

- **Improve Hooks documentation in `docs/agent.md`.** The current Hooks section is superficial:
  - `HookProvider` is mentioned in the `HookRegistry.add()` table row but never explained —
    what it is, how to create one, when to use it instead of individual `on()` calls.
  - `propagate_to(target, *, only, exclude)` is in the table with no explanation of what
    `only`/`exclude` accept or what "forwarding events" means in practice. No example.
  - No example of defining a custom event dataclass and emitting it.
  - Overall the section reads as a dry API reference table. It should explain the lifecycle:
    when events are emitted, how handlers receive them, how `Event[T]` wrapping works,
    and how to compose hooks across agent hierarchies via `propagate_to`.

- **Documentation validation via blind agent test.** Give an LLM agent only the documentation
  (no source code access) and ask it to write an agent using WhenAny/timeout. Check where it
  struggles, fix the docs, repeat. Then ask the same agent for feedback on the API. This is a
  systematic way to find gaps and unclear spots in the docs.

- **Multi-agent patterns cookbook.** Add a doc (e.g. `docs/patterns.md`) with recipes showing
  how to implement common multi-agent patterns using existing primitives (`@step`, `GotoStep`,
  `GotoAgent`, `Spawn`, `CallAgent`). Patterns to cover: router (classify → delegate), pipeline (A → B → C),
  fan-out/fan-in (parallel workers + collector), feedback loop (writer ↔ reviewer with
  iteration limit). Each recipe should include a minimal code example. This replaces the need
  for a dedicated Graph/Workflow DSL — our state machine already covers these cases.


- **Local LLM usage guide.** Document how to use `OpenAIProvider` with local LLM servers
  (Ollama, LM Studio, vLLM). Show `base_url` configuration, recommend models for tool calling,
  and note any quirks (e.g. some models don't support tools well). A dedicated `OllamaProvider`
  is likely unnecessary — the OpenAI-compatible API covers chat, streaming, and tool calling.


## Voice

- **Voice demo (streaming pipeline).** Example `voice_chat.py` — STT (microphone) → agent →
  `on_text_delta` → TTS (speaker). Leverages existing streaming infrastructure. Start with
  simple pipeline, explore STT options: Google Cloud Speech-to-Text (available in GCP),
  OpenAI Whisper API, or local `faster-whisper` for free experimentation.

- **Smart voice pipeline with context-aware re-recognition.** For domain-specific scenarios
  (e.g. payments in Anna Money): STT produces multiple hypotheses with confidence scores.
  Agent receives all variants as structured input ("user said via voice, variants: ...").
  Agent uses domain context (frequent recipients, recent transactions) to select the best
  variant. If uncertain — requests re-recognition with hints (e.g. "typical recipients:
  Маша, Петя, Сбербанк"), STT re-processes the same audio with boosted vocabulary.
  Ties into capabilities (recognize topic → load relevant capability with context),
  agent-as-tool (STT as a callable sub-agent), and hooks (`on_user_message` enriches
  voice input with domain context).


## Integration

- **A2A (Agent-to-Agent) protocol support.** Add `flowra/a2a/` top-level package with optional
  dependency (`flowra[a2a]`) that exposes any Flowra agent as an A2A-compatible HTTP server.
  Thin adapter: takes an agent, publishes Agent Card, accepts messages over HTTP, supports
  streaming via SSE. Allows Flowra agents to participate in the broader A2A ecosystem
  (interop with Strands, LangChain, and other A2A-compatible frameworks).


## Internal providers

- **Anna LLM Proxy provider.** Create a separate private repository (`anna-flowra` or similar)
  with `LLMProxyProvider` for Anna's internal LLM Proxy service. Published to Nexus, not PyPI.
  Depends on `flowra` as a public dependency. Keeps the public flowra repo clean of
  internal/proprietary integrations.


## Package naming

- **Rename `lib` → `prebuilt`.** The `flowra/lib/` package contains ready-made agents
  (`ToolLoopAgent`, `ChatAgent`) built on top of core primitives. The name `lib` is vague —
  `prebuilt` immediately communicates "ready-to-use components" (LangGraph uses the same
  convention). Breaking change: requires updating all imports (`flowra.lib.tool_loop` →
  `flowra.prebuilt.tool_loop`). Consider a re-export shim for one version.


## Serialization

- **Custom string tags for serialized types.** Currently the serialization tag is always
  `cls.__qualname__`, which is fragile — renaming or moving a class breaks deserialization of
  persisted state. Should allow explicit string tags, e.g. via a decorator (`@type_tag("my_spec")`)
  or a class attribute (`__type_tag__ = "my_spec"`), falling back to `__qualname__` if not set.
  This also decouples the persistence format from Python naming, making refactoring safer.

