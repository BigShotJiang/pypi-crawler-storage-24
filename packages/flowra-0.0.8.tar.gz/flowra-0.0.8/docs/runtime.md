# Package `flowra.runtime`

Agent execution engine. Orchestrates agent execution, manages the execution tree, handles persistence
and state management, supports cooperative interrupts, and provides save/resume for crash recovery.

```
flowra/runtime/
├── runtime.py          # AgentRuntime — main orchestrator, public API
├── engine.py           # Engine — execution logic (advance, apply results, node creation)
├── execution.py        # ExecutionNode, ExecutionStatus — execution tree structure
├── runtime_scope.py    # RuntimeScope — state container (scalars, services, dirty tracking)
├── _instance_factory.py    # create_instance_sealed — enforces init-only API on scope
├── serialization.py    # serialize_value / deserialize_value — storage serialization (delegates to marshmallow_recipe)
├── interrupt.py        # InterruptTokenSource — cooperative interruption
└── storage/
    ├── session_storage.py  # SessionStorage (ABC), ChangeSet — persistence interface
    ├── in_memory.py        # InMemorySessionStorage — in-memory implementation (dev/test)
    └── file.py             # FileSessionStorage — JSON file-based implementation
```

## Quick start

```python
import dataclasses
from flowra.agent import Agent, step
from flowra.runtime import AgentRuntime

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetSpec:
    name: str

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetResult:
    greeting: str

class Greeter(Agent[GreetSpec, GreetResult]):
    @step(entry=True)
    async def greet(self, spec: GreetSpec) -> GreetResult:
        return GreetResult(greeting=f"Hello, {spec.name}!")

# Create runtime and run
runtime = AgentRuntime(agents={"greeter": Greeter})
result = await runtime.run(agent=Greeter, spec=GreetSpec(name="World"))
print(result.greeting)  # "Hello, World!"
```

## `AgentRuntime`

Main public API. Manages agent definitions, drives execution, handles persistence.

**Constructor:**
```python
AgentRuntime(
    agents: dict[str, AgentDefinitionRef],
    storage: SessionStorage | None = None,
    services: dict[type, Any] | None = None,
    max_iterations: int | None = None,
    timeout: float | None = None,
)
```

- `agents` — dict mapping agent names to `AbstractAgent` subclass (or `AgentDefinition`).
  Names are used for persistence (storage keys), `run(agent="name")` lookup, and subagent resolution.
- `storage` — optional `SessionStorage` for persistence (save/resume between runs)
- `services` — DI container: dict mapping service types to instances. Services are injected
  into agent `__init__` by matching parameter type annotations. For example, if your agent
  has `def __init__(self, db: Database)`, pass `services={Database: db_instance}`.
- `max_iterations` — default limit on step executions per `run()`/`resume()` call.
  `None` means no limit. Can be overridden per call.
- `timeout` — default wall-clock timeout in seconds per `run()`/`resume()` call.
  Uses `asyncio.wait_for` — raises `asyncio.TimeoutError` on expiry. `None` means no
  timeout. Can be overridden per call.

**Methods:**

```python
# Run agent
result = await runtime.run(agent=MyAgent)
result = await runtime.run(agent=MyAgent, spec=MySpec(...))
result = await runtime.run(agent=MyAgent, spec=MySpec(...), storage_key="main")

# Run with string name
result = await runtime.run(agent="my_agent")

# Override limits per call
result = await runtime.run(agent=MyAgent, max_iterations=50, timeout=30.0)

# Pass None to disable a constructor default for this call
result = await runtime.run(agent=MyAgent, max_iterations=None, timeout=None)

# Resume from persisted state (requires storage)
result = await runtime.resume()  # -> Any (result dataclass or None)
result = await runtime.resume(max_iterations=100, timeout=60.0)

# Check if a persisted execution snapshot exists
can_resume = await runtime.has_pending_execution()  # bool

# Cooperative interrupt — signal all running agents to stop gracefully
runtime.interrupt()
```

`run()` resolves the agent's `entry_step` from the compiled `AgentDefinition`.

`run()` accepts an optional `storage_key` parameter that controls
persistence identity. Nodes with the same `storage_key` across runs share persisted
state. Default is `"root"`.

`run()` and `resume()` accept optional `max_iterations` and `timeout` parameters.
When provided, they override the constructor defaults for that call. Pass `None` explicitly
to disable a limit that was set as a constructor default. When not provided, the constructor
defaults apply.

`run()` raises `RuntimeError` if a pending execution snapshot already exists.
Call `resume()` to continue the existing execution, or clear the snapshot first.

`run()` raises `RuntimeError` if `max_iterations` is exceeded during execution.

`resume()` raises `RuntimeError` if no storage is configured or if no execution snapshot exists.

## Execution model

### Execution lifecycle

High-level flow from `runtime.run()` to result:

**1. Initialization:**
- `AgentRuntime` resolves agent dict into `AgentRegistry`
- Builds `Engine` with scope factory and services
- User calls `runtime.run(agent=MyAgent, spec=MySpec(...))`

**2. Root creation:**
- `Engine.build_root()` creates root `ExecutionNode`
- Resolves agent's `entry_step` from `AgentDefinition`
- Instantiates agent with fresh `RuntimeScope`
- Sets `pending_step` to entry step, status = `PENDING_STEP`

**3. Execution loop:**
```python
# If timeout is set, the entire loop is wrapped in asyncio.wait_for(timeout)
iteration = 0
while True:
    if max_iterations is not None and iteration >= max_iterations:
        raise RuntimeError(f"Agent exceeded max_iterations limit ({max_iterations})")
    iteration += 1
    result = await engine.advance(root)
    await persist_changes()      # Save dirty scopes + execution snapshot
    match result:
        case Completed(result=r):
            return r             # Done — clear execution snapshot, return result
        case Progressed():
            continue             # Keep advancing
```

**4. `Engine.advance()` mechanics:**
- **Propagate** completions from previous cycle
- **Collect** actionable nodes (status = `PENDING_STEP`)
- **Execute** all actionable steps in parallel (`asyncio.gather`)
- **Apply** results to nodes:
  - Result dataclass / `None` → status = `COMPLETED`, store result
  - `GotoStep` → update `pending_step` within same agent
  - `GotoAgent` → resolve agent, create new scope, set `pending_step` to target's `entry_step`
  - `Spawn` → create children (from `CallStep`/`CallAgent`), status = `WAITING_CHILDREN`
- **Return** `Completed(result)` or `Progressed()`

### Parallel execution

All `PENDING_STEP` nodes execute concurrently via `asyncio.gather`. Spawned
children run in parallel within a single `advance()` call.

**Characteristics:**
- No coordination between children — they are independent
- Join-step receives child results via parameter injection (`None` results are filtered out)
- If a child also spawns, grandchildren execute in the next `advance()` call

### Scope semantics

How `GotoStep`, `GotoAgent`, `CallStep`, and `CallAgent` affect scope creation.

**GotoStep:**

| Condition               | Scope behavior                              |
|-------------------------|---------------------------------------------|
| No `storage_key`        | Keep current scope                          |
| `storage_key=NEW_SCOPE` | Fresh scope (auto-generated key)            |
| `storage_key="custom"`  | Fresh scope (if different from current key) |

**GotoAgent:**

| Condition         | Scope behavior     |
|-------------------|--------------------|
| Any `storage_key` | Always fresh scope |

**CallStep (via Spawn):**

| Condition               | Scope behavior                                        |
|-------------------------|-------------------------------------------------------|
| No `storage_key`        | Fork parent scope (copy scalars + lists, independent) |
| `storage_key=NEW_SCOPE` | Fresh scope (auto-generated key)                      |
| `storage_key="custom"`  | Fresh scope                                           |

**CallAgent (via Spawn):**

| Condition         | Scope behavior     |
|-------------------|--------------------|
| Any `storage_key` | Always fresh scope |

**Fork behavior:**
- Copies all scalar values (snapshot)
- Copies all list contents (snapshot)
- Child scope is fully independent — mutations don't affect parent
- No flush callback, no dirty state — child starts clean

## State and persistence

### `ChangeSet`

Incremental state changes for a single node.

| Field     | Type                   |
|-----------|------------------------|
| `scalars` | `dict[str, Any]`       |
| `appends` | `dict[str, list[Any]]` |

Property `empty: bool` — `True` when both `scalars` and `appends` are empty.

### `SessionStorage`

Abstract persistence interface. All values reaching storage are already JSON-serializable —
the runtime serializes domain objects (messages, specs, results) before saving and
deserializes after loading.

```python
class SessionStorage(ABC):
    @asynccontextmanager
    async def begin_transaction(self) -> AsyncIterator[None]: ...

    async def has_execution(self) -> bool: ...
    async def save_execution(self, execution: dict[str, Any]) -> None: ...
    async def load_execution(self) -> dict[str, Any] | None: ...
    async def clear_execution(self) -> None: ...

    async def save_node_state(self, key: str, changes: ChangeSet) -> None: ...
    async def load_node_state(self, key: str) -> dict[str, Any] | None: ...
```

Two groups of methods:
- **Execution snapshot** (`save_execution`, `load_execution`, `clear_execution`, `has_execution`) —
  temporary crash-recovery snapshot of the execution tree. Cleared on successful completion.
- **Node state** (`save_node_state`, `load_node_state`) — persistent per-node state that survives
  across runs. `save_node_state` receives incremental `ChangeSet` (only dirty scalars and new appends).

**Built-in implementations:**

| Class                    | Use case                                                 |
|--------------------------|----------------------------------------------------------|
| `InMemorySessionStorage` | Dev/test — stores everything in memory                   |
| `FileSessionStorage`     | Production — JSON files under `<base_dir>/<session_id>/` |

### `FileSessionStorage`

```python
FileSessionStorage(base_dir="/var/data/agents", session_id="session-123")
```

File layout (session ID and node keys are sanitized for safe filenames):
```
<base_dir>/<sanitized_session_id>/
├── execution.json                        # execution tree snapshot
└── nodes/
    ├── <sanitized_key>.json              # scalar values (merged on each save)
    └── <sanitized_key>.<field>.jsonl     # append-only list items (one JSON per line)
```

### Example with persistence

```python
from flowra.runtime import AgentRuntime, InMemorySessionStorage, FileSessionStorage

# In-memory (dev/test):
storage = InMemorySessionStorage()

# File-based (production):
storage = FileSessionStorage(base_dir="/var/data/agents", session_id="session-123")

runtime = AgentRuntime(
    agents={"worker": WorkerAgent},
    storage=storage,
    services={Database: db_connection},
    max_iterations=1000,   # default safety limit
    timeout=300.0,         # 5 minute wall-clock limit
)

# Run the agent
result = await runtime.run(agent="worker", spec=TaskSpec(...))

# If run() fails (exception, process crash, server restart) — the execution
# snapshot is already in storage from the last successful advance cycle.
# Create a new runtime with the same storage and resume:
runtime2 = AgentRuntime(
    agents={"worker": WorkerAgent},
    storage=storage,
    services={Database: db_connection},
)
result = await runtime2.resume()  # continues from the last saved step
```

### Persistence contract

1. After each `advance()`, runtime opens a transaction via `storage.begin_transaction()`
2. Snapshot execution tree → `storage.save_execution(tree_snapshot)`
3. For each dirty node: serialize changes → `storage.save_node_state(key, changeset)`
   (key is `storage_key` if set, otherwise `node_id` — see [Design notes](#design-notes))
4. Transaction commits
5. Runtime calls `scope.mark_clean()` for all nodes (outside transaction)

On resume:
1. `storage.load_execution()` → deserialize specs/results → reconstruct tree structure
2. For each node: `storage.load_node_state(key)` → deserialize → hydrate scope
3. Continue execution loop

**Storage keys:**
- Same `storage_key` → resume from same persisted state across runs
- Different `storage_key` → fresh independent state
- `None` → ephemeral node (still persisted under `node_id` for crash recovery, but no cross-run continuity)
- Uniqueness enforced: duplicate active key → `ValueError` (prevents state collision)

## Cooperative interrupts

### `InterruptToken` / `InterruptTokenSource`

Cooperative interrupt mechanism inspired by .NET's `CancellationToken` / `CancellationTokenSource`.
Split into a read-only consumer interface (`InterruptToken`, in `agent/`) and
an owner that controls it (`InterruptTokenSource`, in `runtime/`).

**`InterruptToken`** (abc, `flowra.agent`) — consumer interface:
```python
class InterruptToken(abc.ABC):
    @property
    def interrupted(self) -> bool: ...   # Check if interrupted
    def check(self) -> None: ...         # Raise InterruptedError if set (like ThrowIfCancellationRequested)
    async def wait(self) -> None: ...    # Block until interrupted (returns immediately if already set)
```

**`InterruptTokenSource`** (`flowra.runtime`) — owner, creates token:
```python
class InterruptTokenSource:
    @property
    def token(self) -> InterruptToken: ...  # Read-only token for consumers
    def interrupt(self) -> None: ...        # Signal interrupt
    def clear(self) -> None: ...            # Reset (called automatically on completion)
```

**Usage in agents:**

Agents request `InterruptToken` via constructor injection (always available, like `AgentStore`
and `ServiceLocator`). Use `check()` to raise `InterruptedError` when the token is set:

```python
from flowra.agent import Agent, InterruptToken, step

class LongRunningAgent(Agent[TaskSpec, TaskResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def process(self, spec: TaskSpec) -> TaskResult:
        processed = []
        for item in spec.items:
            self.interrupt.check()  # raises InterruptedError if signaled
            result = await process_item(item)
            processed.append(result)
        return TaskResult(processed=processed, partial=False)
```

**Signaling from outside:**
```python
# In another task/thread:
runtime.interrupt()  # Sets signal for all agents

# When a step raises InterruptedError (via check() or with_interrupt()):
# - Engine catches it per-node and converts to Interrupted() result
# - Interrupted() flows up the tree via auto-propagation
# - runtime.run() returns Interrupted()
# - Runtime calls clear() to reset for next run()
```

**Engine behavior on `InterruptedError`:**

When a step raises `InterruptedError`, the engine catches it **per-node** and converts it to an
`Interrupted()` result (see [`Interrupted`](agent.md#interrupted--typed-result-for-interrupted-children)
in `flowra.agent`). This result flows up through the execution tree via auto-propagation:
parent join-steps receive `None` for interrupted children's nullable parameters, or auto-propagate
`Interrupted()` if binding fails. Ultimately, `runtime.run()` returns `Interrupted()`.

An agent can catch `InterruptedError` explicitly if it wants to return a meaningful partial result
instead of `Interrupted()`.

**Properties:**
- Exception-based — `check()` and [`with_interrupt()`](agent.md#with_interrupt--racing-async-iterators) raise `InterruptedError`, no silent failures
- Per-node interrupt tokens with parent→child cascade
- Automatically cleared on successful completion (but not on exceptions, allowing resume)
- `wait()` is useful in tools — block until interrupted, e.g., to cancel a long-running operation

### Serialization

The runtime automatically serializes all values before they reach storage and deserializes
on load. Storage implementations only deal with plain JSON-serializable dicts.

```python
serialize_value(value: Any, type_tags: dict[type, str]) -> Any          # domain object → JSON-serializable
deserialize_value(value: Any, type_registry: dict[str, type]) -> Any   # JSON-serializable → domain object
```

| Type                                                         | Serialization                                      |
|--------------------------------------------------------------|----------------------------------------------------|
| Primitives (`str`, `int`, `float`, `bool`, `None`)           | Pass through                                       |
| `list`, `dict`                                               | Recurse                                            |
| `bytes`                                                      | `{"__bytes__": "<base64>"}`                        |
| `uuid.UUID`                                                  | `{"__uuid__": "<string>"}`                         |
| `datetime`                                                   | `{"__datetime__": "<isoformat>"}`                  |
| `date`                                                       | `{"__date__": "<isoformat>"}`                      |
| `time`                                                       | `{"__time__": "<isoformat>"}`                      |
| `Decimal`                                                    | `{"__decimal__": "<string>"}`                      |
| Dataclass (messages, blocks, specs, results, ...)            | `{"__type__": "<qualname>", "__data__": {fields}}` |

Dataclass serialization delegates field conversion to `marshmallow_recipe.dump()`/`load()`.

All dataclass types used in step parameters, return values, and `Agent[S, R]` generics
are registered automatically at class definition time. If a type is not registered
(e.g., stored in a `Scalar` but never appears in step signatures), serialization
raises `TypeError`.


