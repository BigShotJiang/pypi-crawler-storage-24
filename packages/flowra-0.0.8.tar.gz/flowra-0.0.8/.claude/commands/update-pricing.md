# Update Pricing

Update the LLM pricing tables in `flowra/llm/pricing/` with current pricing from the web.

## Instructions

You are updating the hardcoded pricing tables for LLM models used by this project.

### Project structure

Pricing is split into three modules by API protocol (not by vendor):

- `flowra/llm/pricing/anthropic.py` — Anthropic Claude models. Fields: input, output, cache_read, cache_creation_5m, cache_creation_1h.
- `flowra/llm/pricing/openai.py` — OpenAI + OpenAI-compatible (Mercury/Inception, etc.). Fields: input, output, cache_read. Cache creation is free.
- `flowra/llm/pricing/google.py` — Google Gemini models. Fields: input, output, cache_read. Cache creation is free.

Each module has a `PRICING: list[tuple[str, ModelPricing]]` table ordered longest-key-first for correct substring matching.

### Steps to follow

1. **Read current pricing tables**: Read all three files in `flowra/llm/pricing/` to see existing models and prices.

2. **Determine which models to update**:
   - If the user provided arguments (e.g., `/update-pricing all Gemini models`), search for pricing for those specific models PLUS all existing models in the tables.
   - If no arguments were provided, refresh pricing for all existing models in all three tables.

3. **Web search for current pricing**: Use WebSearch to find the most up-to-date pricing for:
   - All models currently in the pricing tables
   - Any additional models the user requested
   - Search for official pricing pages: Anthropic (anthropic.com/pricing), OpenAI (openai.com/api/pricing), Google Cloud (cloud.google.com/vertex-ai/generative-ai/pricing)

4. **Update the pricing tables**:
   - Update existing entries with the latest pricing
   - Add new entries for any models the user requested
   - Remove entries for deprecated/discontinued models if appropriate
   - **IMPORTANT**: Keep keys ordered longest-first to ensure correct substring matching. For example, `"gpt-4o-mini"` must come before `"gpt-4o"`.
   - Place new models in the correct position by key length

5. **Verify the changes**: After updating, briefly summarize what was changed (which models were updated, added, or removed) per module.

## Important notes

- All prices are in dollars per 1 million tokens
- `cache_read` should be 0 for models that don't support prompt caching
- Anthropic has separate 5-minute and 1-hour cache creation prices. 5-minute = 1.25x base input, 1-hour = 2x base input. Cache read is the same for both TTLs (0.1x base input).
- OpenAI and Google cache creation is free (automatic) — no cache_creation field in their ModelPricing
- Model matching uses substring matching, so keys should be specific enough to avoid false matches but general enough to match version suffixes (e.g., `"claude-sonnet-4-5"` matches `"claude-sonnet-4-5@20250929"`)
- Always prioritize official pricing pages from model providers
