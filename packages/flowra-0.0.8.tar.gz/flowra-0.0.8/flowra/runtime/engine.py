import asyncio
import dataclasses
from collections.abc import Awaitable, Callable, Iterable
from typing import Any

from ..agent import (
    NEW_SCOPE,
    AgentDefinition,
    AgentInstance,
    AgentRegistry,
    CallAgent,
    CallStep,
    ChildOutput,
    GotoAgent,
    GotoStep,
    Interrupted,
    InterruptedError,
    InterruptToken,
    Spawn,
    SpawnChild,
)
from .execution import (
    CollectedResult,
    ExecutionNode,
    ExecutionStatus,
    SpawnTreeAll,
    SpawnTreeAny,
    SpawnTreeLeaf,
    SpawnTreeN,
    SpawnTreeNode,
    build_spawn_tree,
)
from .interrupt import InterruptTokenSource
from .runtime_scope import RuntimeScope

__all__ = [
    "AdvanceResult",
    "Completed",
    "Engine",
    "InstanceFactory",
    "Progressed",
    "ScopeFactory",
    "ScopeRestoreCallback",
]

type ScopeFactory = Callable[[dict[type, Any]], RuntimeScope]
type ScopeRestoreCallback = Callable[[RuntimeScope, str | None, str, str], Awaitable[None]]
type InstanceFactory = Callable[[AgentDefinition, RuntimeScope, dict[type, Any]], AgentInstance]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Completed:
    result: Any | None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Progressed:
    pass


type AdvanceResult = Completed | Progressed


class Engine:
    __slots__ = (
        "__instance_factory",
        "__live_storage_keys",
        "__registry",
        "__scope_factory",
        "__scope_restore",
        "__services",
    )

    def __init__(
        self,
        registry: AgentRegistry,
        scope_factory: ScopeFactory,
        instance_factory: InstanceFactory,
        services: dict[type, Any] | None = None,
        scope_restore: ScopeRestoreCallback | None = None,
    ) -> None:
        self.__registry = registry
        self.__scope_factory = scope_factory
        self.__instance_factory = instance_factory
        self.__services: dict[type, Any] = services or {}
        self.__live_storage_keys: set[str] = set()
        self.__scope_restore = scope_restore

    def register_live_storage_keys(self, root: ExecutionNode) -> None:
        if root.status != ExecutionStatus.COMPLETED and root.storage_key is not None:
            self.__acquire_storage_key(root.storage_key)
        if root.children:
            for child in root.children:
                self.register_live_storage_keys(child)

    async def build_root(
        self,
        agent: str,
        step: str,
        spec: Any | None = None,
        *,
        storage_key: str | None = None,
        node_id: str = "root",
        interrupt_source: InterruptTokenSource | None = None,
    ) -> ExecutionNode:
        defn = self.__registry.get(agent)
        return await self.__create_node(
            node_id=node_id,
            agent_name=agent,
            defn=defn,
            step=step,
            spec=spec,
            parent_services={},
            parent=None,
            storage_key=storage_key,
            agent_spec=spec,
            interrupt_source=interrupt_source,
        )

    async def advance(self, root: ExecutionNode) -> AdvanceResult:
        # Propagate completions from the previous cycle: when all children
        # are done, clear the children reference and move the parent to PENDING_STEP.
        self.__propagate_completions(root)

        if root.status == ExecutionStatus.COMPLETED:
            return Completed(result=root.result)

        actionable = self.__collect_actionable(root)
        if not actionable:
            msg = "No actionable nodes found but root is not completed"
            raise RuntimeError(msg)

        step_results = await self.__execute_nodes(actionable)

        for node, step_result in zip(actionable, step_results):
            await self.__apply_result(node, step_result)

        # Re-read status — __apply_result may have set it to COMPLETED.
        match ExecutionStatus(root.status):
            case ExecutionStatus.COMPLETED:
                return Completed(result=root.result)
            case ExecutionStatus.PENDING_STEP | ExecutionStatus.WAITING_CHILDREN:
                return Progressed()

    def __collect_actionable(self, node: ExecutionNode) -> list[ExecutionNode]:
        result: list[ExecutionNode] = []
        match node.status:
            case ExecutionStatus.PENDING_STEP:
                result.append(node)
            case ExecutionStatus.WAITING_CHILDREN:
                assert node.children is not None
                for child in node.children:
                    result.extend(self.__collect_actionable(child))
            case ExecutionStatus.COMPLETED:
                pass
        return result

    @classmethod
    async def __execute_nodes(cls, nodes: Iterable[ExecutionNode]) -> list[Any]:
        node_list = list(nodes)
        tasks = [asyncio.ensure_future(cls.__execute_node(node)) for node in node_list]

        # Set up done callbacks for spawn-tree-aware mid-execution interrupts.
        # Group tasks by parent that has a spawn tree.
        parent_groups: dict[int, tuple[ExecutionNode, dict[int, asyncio.Task[Any]]]] = {}
        for node, task in zip(node_list, tasks):
            parent = node.parent
            if parent is not None and parent.spawn_tree is not None and parent.children is not None:
                pid = id(parent)
                if pid not in parent_groups:
                    parent_groups[pid] = (parent, {})
                child_idx = parent.children.index(node)
                parent_groups[pid][1][child_idx] = task

        if parent_groups:
            interrupt_check = cls.__interrupt_unneeded_from_tasks
            for pid, (parent, task_map) in parent_groups.items():

                def _make_cb(p: ExecutionNode, tm: dict[int, asyncio.Task[Any]]) -> Callable[[asyncio.Task[Any]], None]:
                    def _cb(_: asyncio.Task[Any]) -> None:
                        interrupt_check(p, tm)

                    return _cb

                cb = _make_cb(parent, task_map)
                for task in task_map.values():
                    task.add_done_callback(cb)

        return list(await asyncio.gather(*tasks))

    @staticmethod
    async def __execute_node(node: ExecutionNode) -> Any:
        assert node.pending_step is not None
        child_outputs: list[ChildOutput] | None = None
        had_interrupts = False
        if node.child_results is not None:
            child_outputs = []
            for cr in node.child_results:
                if isinstance(cr.result, Interrupted):
                    had_interrupts = True
                    continue
                child_outputs.append(ChildOutput(result=cr.result, tag=cr.tag))
        try:
            return await node.instance.call_step(node.pending_step, node.pending_spec, child_outputs, node.agent_spec)
        except InterruptedError:
            return Interrupted()
        except TypeError:
            if had_interrupts:
                # Binding failed because interrupted children's results are missing.
                # Auto-propagate Interrupted instead of raising a programming error.
                return Interrupted()
            raise

    async def __apply_result(self, node: ExecutionNode, step_result: Any) -> None:
        match step_result:
            case GotoStep(step=next_step, spec=next_spec, storage_key=sk):
                # Same agent — possibly new scope
                needs_new_scope = sk is NEW_SCOPE or (isinstance(sk, str) and sk != node.storage_key)

                if needs_new_scope:
                    self.__release_storage_key(node)
                    if isinstance(sk, str):
                        new_key = sk
                    else:
                        node.goto_counter += 1
                        new_key = f"{node.node_id}:goto:{node.goto_counter}"
                    self.__acquire_storage_key(new_key)
                    node.storage_key = new_key

                    inherited = node.scope.get_inherited_services()
                    new_scope = self.__scope_factory(inherited)
                    merged = {**self.__services, **inherited}
                    if node.interrupt_source is not None:
                        merged[InterruptToken] = node.interrupt_source.token
                    new_instance = self.__instance_factory(node.defn, new_scope, merged)
                    if self.__scope_restore is not None:
                        await self.__scope_restore(new_scope, new_key, node.node_id, node.agent_name)

                    node.scope = new_scope
                    node.instance = new_instance

                node.pending_step = next_step
                node.pending_spec = next_spec
                node.child_results = None
                # agent_spec stays unchanged (same agent)

            case GotoAgent(agent=agent_ref, spec=next_spec, storage_key=sk):
                # Different agent — always new scope
                resolved = self.__registry.resolve(agent_ref, context=node.agent_name)
                entry = resolved.definition.entry_step

                self.__release_storage_key(node)
                if isinstance(sk, str):
                    new_key = sk
                else:
                    node.goto_counter += 1
                    new_key = f"{node.node_id}:goto:{node.goto_counter}"
                self.__acquire_storage_key(new_key)
                node.storage_key = new_key

                inherited = node.scope.get_inherited_services()
                new_scope = self.__scope_factory(inherited)
                merged = {**self.__services, **inherited}
                if node.interrupt_source is not None:
                    merged[InterruptToken] = node.interrupt_source.token
                new_instance = self.__instance_factory(resolved.definition, new_scope, merged)
                if self.__scope_restore is not None:
                    await self.__scope_restore(new_scope, new_key, node.node_id, resolved.name)

                node.scope = new_scope
                node.instance = new_instance
                node.agent_name = resolved.name
                node.defn = resolved.definition

                node.pending_step = entry
                node.pending_spec = next_spec
                node.child_results = None
                node.agent_spec = next_spec  # new agent, its spec becomes agent_spec

            case Spawn(root=root_node, children=calls, then=then_step):
                node.status = ExecutionStatus.WAITING_CHILDREN
                node.pending_step = None
                node.pending_spec = None
                node.child_results = None
                node.then_step = then_step
                node.children = []
                parent_services = node.scope.get_services()
                for child_index, call in enumerate(calls):
                    child = await self.__create_child_node(call, node.defn, parent_services, node, child_index)
                    node.children.append(child)
                node.spawn_tree = build_spawn_tree(root_node, [0])

            case _:
                # completion (result value or None)
                node.status = ExecutionStatus.COMPLETED
                node.result = step_result
                node.pending_step = None
                node.pending_spec = None
                node.child_results = None
                self.__release_storage_key(node)
                if node.interrupt_source is not None:
                    node.interrupt_source.dispose()

    def __propagate_completions(self, root: ExecutionNode) -> None:
        if root.status != ExecutionStatus.WAITING_CHILDREN:
            return
        assert root.children is not None

        for child in root.children:
            self.__propagate_completions(child)

        # Interrupt unneeded children when the spawn tree strategy is satisfied
        if root.spawn_tree is not None:
            satisfied = self.__satisfied_set_from_children(root.children)
            if self.__is_tree_satisfied(root.spawn_tree, satisfied):
                needed = self.__collect_needed_indices(root.spawn_tree, satisfied)
                for i, child in enumerate(root.children):
                    if (
                        child.status != ExecutionStatus.COMPLETED
                        and i not in needed
                        and child.interrupt_source is not None
                    ):
                        child.interrupt_source.interrupt()

        # Collect when ALL children done (some with real results, some with Interrupted)
        if all(c.status == ExecutionStatus.COMPLETED for c in root.children):
            root.child_results = [
                CollectedResult(agent_name=c.agent_name, result=c.result, tag=c.tag) for c in root.children
            ]
            for child in root.children:
                if child.interrupt_source is not None:
                    child.interrupt_source.dispose()
            root.status = ExecutionStatus.PENDING_STEP
            root.pending_step = root.then_step
            root.pending_spec = None
            root.then_step = None
            root.spawn_tree = None
            root.children = None

    # ------------------------------------------------------------------
    # Spawn-tree satisfaction helpers
    # ------------------------------------------------------------------

    @staticmethod
    def __satisfied_set_from_children(children: list[ExecutionNode]) -> set[int]:
        """Build set of child indices that completed with real (non-Interrupted) results."""
        return {
            i
            for i, c in enumerate(children)
            if c.status == ExecutionStatus.COMPLETED and not isinstance(c.result, Interrupted)
        }

    @staticmethod
    def __satisfied_set_from_tasks(parent: ExecutionNode, task_map: dict[int, asyncio.Task[Any]]) -> set[int]:
        """Build set of child indices satisfied so far (from tasks and already-COMPLETED nodes)."""
        assert parent.children is not None
        satisfied: set[int] = set()
        for i, child in enumerate(parent.children):
            if child.status == ExecutionStatus.COMPLETED and not isinstance(child.result, Interrupted):
                satisfied.add(i)
            elif i in task_map:
                task = task_map[i]
                if task.done() and not task.cancelled():
                    try:
                        result = task.result()
                        if not isinstance(result, Interrupted):
                            satisfied.add(i)
                    except Exception:
                        pass
        return satisfied

    @classmethod
    def __is_tree_satisfied(cls, tree: SpawnTreeNode, satisfied: set[int]) -> bool:
        match tree:
            case SpawnTreeLeaf(child_index=idx):
                return idx in satisfied
            case SpawnTreeAll(nodes=nodes):
                return all(cls.__is_tree_satisfied(n, satisfied) for n in nodes)
            case SpawnTreeAny(nodes=nodes):
                return any(cls.__is_tree_satisfied(n, satisfied) for n in nodes)
            case SpawnTreeN(nodes=nodes, n=n):
                return sum(1 for nd in nodes if cls.__is_tree_satisfied(nd, satisfied)) >= n

    @classmethod
    def __collect_needed_indices(cls, tree: SpawnTreeNode, satisfied: set[int]) -> set[int]:
        result: set[int] = set()
        cls.__collect_needed(tree, satisfied, result)
        return result

    @classmethod
    def __collect_needed(cls, tree: SpawnTreeNode, satisfied: set[int], out: set[int]) -> None:
        match tree:
            case SpawnTreeLeaf(child_index=idx):
                if idx in satisfied:
                    out.add(idx)
            case SpawnTreeAll(nodes=nodes):
                for n in nodes:
                    cls.__collect_needed(n, satisfied, out)
            case SpawnTreeAny(nodes=nodes):
                for n in nodes:
                    if cls.__is_tree_satisfied(n, satisfied):
                        cls.__collect_needed(n, satisfied, out)
                        return
                # None satisfied — all are needed
                for n in nodes:
                    cls.__collect_needed(n, satisfied, out)
            case SpawnTreeN(nodes=nodes, n=n):
                count = 0
                for nd in nodes:
                    if count < n and cls.__is_tree_satisfied(nd, satisfied):
                        cls.__collect_needed(nd, satisfied, out)
                        count += 1
                if count < n:
                    for nd in nodes:
                        if not cls.__is_tree_satisfied(nd, satisfied):
                            cls.__collect_needed(nd, satisfied, out)

    @classmethod
    def __interrupt_unneeded_from_tasks(cls, parent: ExecutionNode, task_map: dict[int, asyncio.Task[Any]]) -> None:
        """Done-callback: interrupt unneeded children when spawn tree is satisfied mid-execution."""
        if parent.spawn_tree is None or parent.children is None:
            return
        satisfied = cls.__satisfied_set_from_tasks(parent, task_map)
        if not cls.__is_tree_satisfied(parent.spawn_tree, satisfied):
            return
        needed = cls.__collect_needed_indices(parent.spawn_tree, satisfied)
        for i, child in enumerate(parent.children):
            if i not in needed and child.interrupt_source is not None:
                child.interrupt_source.interrupt()

    def __acquire_storage_key(self, storage_key: str) -> None:
        if storage_key in self.__live_storage_keys:
            msg = f"Duplicate storage_key: {storage_key!r}"
            raise ValueError(msg)
        self.__live_storage_keys.add(storage_key)

    def __release_storage_key(self, node: ExecutionNode) -> None:
        if node.storage_key is not None and node.storage_key in self.__live_storage_keys:
            self.__live_storage_keys.discard(node.storage_key)

    async def __create_node(
        self,
        node_id: str,
        agent_name: str,
        defn: AgentDefinition,
        step: str,
        spec: Any | None,
        parent_services: dict[type, Any],
        parent: ExecutionNode | None,
        storage_key: str | None = None,
        agent_spec: Any | None = None,
        tag: str | None = None,
        interrupt_source: InterruptTokenSource | None = None,
    ) -> ExecutionNode:
        if storage_key is not None:
            self.__acquire_storage_key(storage_key)
        merged = {**self.__services, **parent_services}
        if interrupt_source is not None:
            merged[InterruptToken] = interrupt_source.token
        scope = self.__scope_factory(merged)
        instance = self.__instance_factory(defn, scope, merged)
        if self.__scope_restore is not None:
            await self.__scope_restore(scope, storage_key, node_id, agent_name)
        return ExecutionNode(
            node_id=node_id,
            storage_key=storage_key,
            agent_name=agent_name,
            defn=defn,
            instance=instance,
            scope=scope,
            status=ExecutionStatus.PENDING_STEP,
            pending_step=step,
            pending_spec=spec,
            parent=parent,
            agent_spec=agent_spec,
            tag=tag,
            interrupt_source=interrupt_source,
        )

    async def __create_child_node(
        self,
        call: SpawnChild,
        parent_defn: AgentDefinition,
        parent_services: dict[type, Any],
        parent: ExecutionNode,
        child_index: int,
    ) -> ExecutionNode:
        child_node_id = f"{parent.node_id}.{child_index}"
        if isinstance(call.storage_key, str) or call.storage_key is None:
            storage_key = call.storage_key
        else:
            storage_key = f"{child_node_id}:auto"

        child_source = parent.interrupt_source.create_child() if parent.interrupt_source is not None else None
        merged = {**self.__services, **parent_services}
        if child_source is not None:
            merged[InterruptToken] = child_source.token

        match call:
            case CallStep(step=step, spec=spec, tag=call_tag):
                # Same agent — fork scope or create new
                if storage_key is not None:
                    self.__acquire_storage_key(storage_key)
                    scope = self.__scope_factory(merged)
                else:
                    scope = parent.scope.fork(parent_services=merged)
                instance = self.__instance_factory(parent_defn, scope, merged)
                if self.__scope_restore is not None:
                    await self.__scope_restore(scope, storage_key, child_node_id, parent.agent_name)
                return ExecutionNode(
                    node_id=child_node_id,
                    storage_key=storage_key,
                    agent_name=parent.agent_name,
                    defn=parent_defn,
                    instance=instance,
                    scope=scope,
                    status=ExecutionStatus.PENDING_STEP,
                    pending_step=step,
                    pending_spec=spec,
                    parent=parent,
                    tag=call_tag,
                    agent_spec=parent.agent_spec,  # same agent, inherit agent_spec
                    interrupt_source=child_source,
                )

            case CallAgent(agent=agent_ref, spec=spec, tag=call_tag):
                # Different agent — resolve, use entry_step
                resolved = self.__registry.resolve(agent_ref, context=parent.agent_name)
                entry = resolved.definition.entry_step
                return await self.__create_node(
                    node_id=child_node_id,
                    agent_name=resolved.name,
                    defn=resolved.definition,
                    step=entry,
                    spec=spec,
                    parent_services=parent_services,
                    parent=parent,
                    storage_key=storage_key,
                    agent_spec=spec,  # new agent, spec becomes its agent_spec
                    tag=call_tag,
                    interrupt_source=child_source,
                )
