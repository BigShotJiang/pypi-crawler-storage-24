import asyncio

from ..agent import InterruptToken

__all__ = ["InterruptTokenSource"]


class _InterruptTokenImpl(InterruptToken):
    __slots__ = ("children", "event", "is_interrupted", "parent")

    def __init__(self) -> None:
        self.is_interrupted = False
        self.event = asyncio.Event()
        self.children: list[_InterruptTokenImpl] = []
        self.parent: _InterruptTokenImpl | None = None

    @property
    def interrupted(self) -> bool:
        return self.is_interrupted

    async def wait(self) -> None:
        await self.event.wait()

    def set(self) -> None:
        self.is_interrupted = True
        self.event.set()
        for child in self.children:
            child.set()

    def clear(self) -> None:
        self.is_interrupted = False
        self.event.clear()


class InterruptTokenSource:
    __slots__ = ("__token",)

    def __init__(self) -> None:
        self.__token = _InterruptTokenImpl()

    @property
    def token(self) -> InterruptToken:
        return self.__token

    def interrupt(self) -> None:
        self.__token.set()

    def clear(self) -> None:
        self.__token.clear()

    def create_child(self) -> "InterruptTokenSource":
        child = InterruptTokenSource()
        parent_impl = self.__token
        child_impl = child.__token
        parent_impl.children.append(child_impl)
        child_impl.parent = parent_impl
        if parent_impl.is_interrupted:
            child_impl.set()
        return child

    def dispose(self) -> None:
        impl = self.__token
        if impl.parent is not None:
            impl.parent.children.remove(impl)
            impl.parent = None
