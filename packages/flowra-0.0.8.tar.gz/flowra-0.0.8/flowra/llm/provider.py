import abc
from collections.abc import AsyncIterator

from .request import LLMRequest
from .response import LLMResponse
from .stream import ContentComplete, StreamEvent

__all__ = ["LLMProvider"]


class LLMProvider(abc.ABC):
    __slots__ = ()

    @abc.abstractmethod
    async def call(self, request: LLMRequest) -> LLMResponse: ...

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        response = await self.call(request)
        yield ContentComplete(response=response)
