import dataclasses
from typing import Literal

from ._base import LLMData
from .blocks import AssistantBlock, TextBlock, UserBlock

__all__ = [
    "AssistantMessage",
    "Message",
    "SystemMessage",
    "UserMessage",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SystemMessage(LLMData):
    role: Literal["system"] = "system"
    blocks: list[TextBlock]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class UserMessage(LLMData):
    role: Literal["user"] = "user"
    blocks: list[UserBlock]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AssistantMessage(LLMData):
    role: Literal["assistant"] = "assistant"
    blocks: list[AssistantBlock]


type Message = SystemMessage | UserMessage | AssistantMessage
