import dataclasses
from typing import Any

__all__ = ["LLMData"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMData:
    metadata: dict[str, Any] = dataclasses.field(default_factory=dict)
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)
