import base64
import dataclasses
import json
import re
from collections.abc import AsyncIterator
from typing import Any, ClassVar

import marshmallow_recipe as mr
from anthropic import AsyncAnthropicVertex, omit
from anthropic.types import Message as AnthropicMessage, Usage as AnthropicUsage
from google.oauth2 import service_account

from ..blocks import AssistantBlock, ImageBlock, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock
from ..messages import AssistantMessage, Message, SystemMessage, UserMessage
from ..pricing import anthropic as anthropic_pricing
from ..provider import LLMProvider
from ..request import LLMRequest
from ..response import LLMResponse, StopReason, Usage
from ..schema_formatting import format_output_schema_for_description, format_schema_for_llm
from ..schema_validation import validate_json_schema
from ..stream import ContentComplete, StreamEvent, TextDelta, ThinkingDelta
from ..tools import Tool

__all__ = [
    "AnthropicVertexAdditionalConfig",
    "AnthropicVertexProvider",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AnthropicVertexAdditionalConfig:
    thinking_budget_tokens: int | None = None


class AnthropicVertexProvider(LLMProvider):
    __slots__ = ("__client",)

    __TOOL_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,128}$")

    def __init__(
        self,
        *,
        client: AsyncAnthropicVertex | None = None,
        project: str | None = None,
        location: str | None = None,
        credentials: str | None = None,
    ) -> None:
        if client is not None:
            self.__client = client
        elif project and location and credentials:
            self.__client = self.__create_client(project=project, location=location, credentials=credentials)
        else:
            raise ValueError("Either 'client' or all of 'project', 'location', 'credentials' must be provided")

    @staticmethod
    def __create_client(*, project: str, location: str, credentials: str) -> AsyncAnthropicVertex:
        creds_json = base64.b64decode(credentials.encode()).decode()
        creds_info = json.loads(creds_json)
        google_creds = service_account.Credentials.from_service_account_info(creds_info)
        google_creds = google_creds.with_scopes(["https://www.googleapis.com/auth/cloud-platform"])
        return AsyncAnthropicVertex(region=location, project_id=project, credentials=google_creds)

    async def call(self, request: LLMRequest) -> LLMResponse:
        response = await self.__call_llm(request)

        if request.json_schema is None or response.stop_reason != StopReason.END_TURN:
            return response

        # Validate + retry loop
        messages = list(request.messages)
        total_usage = response.usage

        for _attempt in range(request.max_schema_retries):
            text = self.__extract_text(response)
            error, cleaned = validate_json_schema(text, request.json_schema)
            if error is None:
                return LLMResponse(
                    message=self.__make_schema_message(cleaned),
                    stop_reason=response.stop_reason,
                    stop_sequence=response.stop_sequence,
                    usage=total_usage,
                )

            # Retry: append assistant response + validation error as user message
            messages.append(response.message)
            messages.append(
                UserMessage(
                    blocks=[
                        TextBlock(
                            text=f"Your response is not valid JSON conforming to the required schema.\n{error}\n"
                            f"Please fix and return ONLY the raw JSON object, without markdown code fences.",
                        )
                    ]
                )
            )
            retry_request = dataclasses.replace(request, messages=messages)
            response = await self.__call_llm(retry_request)
            if response.usage is not None and total_usage is not None:
                total_usage = total_usage + response.usage
            elif response.usage is not None:
                total_usage = response.usage

            if response.stop_reason != StopReason.END_TURN:
                return LLMResponse(
                    message=response.message,
                    stop_reason=response.stop_reason,
                    stop_sequence=response.stop_sequence,
                    usage=total_usage,
                )

        # Validate the final retry response
        text = self.__extract_text(response)
        error, cleaned = validate_json_schema(text, request.json_schema)
        if error is None:
            return LLMResponse(
                message=self.__make_schema_message(cleaned),
                stop_reason=response.stop_reason,
                stop_sequence=response.stop_sequence,
                usage=total_usage,
            )

        return LLMResponse(
            message=response.message,
            stop_reason=StopReason.SCHEMA_VALIDATION_FAILED,
            stop_sequence=response.stop_sequence,
            usage=total_usage,
        )

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        if request.json_schema is not None:
            # JSON schema needs retry loop — fall back to non-streaming
            response = await self.call(request)
            yield ContentComplete(response=response)
            return

        kwargs = self.__build_kwargs(request)

        async with self.__client.messages.stream(**kwargs) as api_stream:
            async for event in api_stream:
                if event.type == "content_block_delta":
                    if event.delta.type == "text_delta":
                        yield TextDelta(text=event.delta.text)
                    elif event.delta.type == "thinking_delta":
                        yield ThinkingDelta(text=event.delta.thinking)

            response = await api_stream.get_final_message()

        yield ContentComplete(response=self.__convert_response(response, request.model))

    async def __call_llm(self, request: LLMRequest) -> LLMResponse:
        kwargs = self.__build_kwargs(request)
        response = await self.__client.messages.create(**kwargs)
        return self.__convert_response(response, request.model)

    def __build_kwargs(self, request: LLMRequest) -> dict[str, Any]:
        system, messages = self.__extract_system(request.messages)

        if request.json_schema:
            schema_prompt = self.__format_schema_for_prompt(request.json_schema)
            if system is None:
                system = schema_prompt
            elif isinstance(system, str):
                system = f"{system}\n\n{schema_prompt}"
            else:
                system.append({"type": "text", "text": schema_prompt})

        anthropic_messages: Any = [self.__convert_message(m) for m in messages]

        anthropic_tools: Any = omit
        if request.tools:
            anthropic_tools = [self.__convert_tool(tool, cache=tool.cache) for tool in request.tools]

        anthropic_system: Any = omit
        if system:
            anthropic_system = system

        kwargs: dict[str, Any] = {
            "model": request.model,
            "messages": anthropic_messages,
            "max_tokens": request.max_tokens or 4096,
            "system": anthropic_system,
            "tools": anthropic_tools,
            "temperature": request.temperature if request.temperature is not None else omit,
            "stop_sequences": request.stop_sequences if request.stop_sequences else omit,
        }

        if request.additional_config:
            additional = mr.load(AnthropicVertexAdditionalConfig, request.additional_config)
            if additional.thinking_budget_tokens is not None:
                kwargs["thinking"] = {"type": "enabled", "budget_tokens": additional.thinking_budget_tokens}
                kwargs["temperature"] = 1  # Anthropic requirement for thinking

        return kwargs

    @staticmethod
    def __format_schema_for_prompt(schema: dict[str, Any]) -> str:
        schema_str = format_schema_for_llm(schema)
        return (
            f"You must respond with ONLY a valid JSON object that strictly conforms to this structure:\n"
            f"{schema_str}\n\n"
            f"IMPORTANT: Output ONLY the raw JSON object. "
            f"No markdown code fences, no explanations, no additional text before or after the JSON."
        )

    @classmethod
    def __extract_system(cls, messages: list[Message]) -> tuple[str | list[dict[str, Any]] | None, list[Message]]:
        system_blocks: list[TextBlock] = []
        rest_start = 0

        for msg in messages:
            if not isinstance(msg, SystemMessage):
                break
            system_blocks.extend(msg.blocks)
            rest_start += 1

        if not system_blocks:
            return None, messages

        has_cache = any(b.cache for b in system_blocks)
        if has_cache:
            return [cls.__convert_text_block(b) for b in system_blocks], messages[rest_start:]

        combined = "\n\n".join(b.text for b in system_blocks)
        return combined, messages[rest_start:]

    @classmethod
    def __convert_message(cls, message: Message) -> dict[str, Any]:
        match message:
            case UserMessage(blocks=blocks):
                content: list[dict[str, Any]] = []
                for block in blocks:
                    match block:
                        case TextBlock() as tb:
                            content.append(cls.__convert_text_block(tb))
                        case ImageBlock(data=data, media_type=media_type, cache=cache):
                            block_dict: dict[str, Any] = {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": media_type,
                                    "data": base64.b64encode(data).decode(),
                                },
                            }
                            if cache:
                                block_dict["cache_control"] = {"type": "ephemeral"}
                            content.append(block_dict)
                        case ToolResultBlock(
                            tool_use_id=tool_use_id, content=tool_content, is_error=is_error, cache=cache
                        ):
                            block_dict = {
                                "type": "tool_result",
                                "tool_use_id": tool_use_id,
                                "content": tool_content,
                                **({"is_error": True} if is_error else {}),
                            }
                            if cache:
                                block_dict["cache_control"] = {"type": "ephemeral"}
                            content.append(block_dict)
                return {"role": "user", "content": content}

            case AssistantMessage(blocks=blocks):
                content = []
                for block in blocks:
                    match block:
                        case TextBlock() as tb:
                            content.append(cls.__convert_text_block(tb))
                        case ToolUseBlock(id=id_, name=name, input=input_, cache=cache):
                            block_dict = {"type": "tool_use", "id": id_, "name": name, "input": input_}
                            if cache:
                                block_dict["cache_control"] = {"type": "ephemeral"}
                            content.append(block_dict)
                        case _:
                            pass  # ThinkingBlock is not sent back to the API
                return {"role": "assistant", "content": content}

            case SystemMessage():
                raise ValueError("SystemMessage must be at the beginning of messages list")

    @staticmethod
    def __convert_text_block(block: TextBlock) -> dict[str, Any]:
        result: dict[str, Any] = {"type": "text", "text": block.text}
        if block.cache:
            result["cache_control"] = {"type": "ephemeral"}
        return result

    @classmethod
    def __convert_tool(cls, tool: Tool, cache: bool = False) -> dict[str, Any]:
        if not cls.__TOOL_NAME_RE.fullmatch(tool.name):
            raise ValueError(f"Tool name '{tool.name}' must match ^[a-zA-Z0-9_-]{{1,128}}$")

        description = tool.description
        if tool.output_schema:
            description += format_output_schema_for_description(tool.output_schema)

        result: dict[str, Any] = {
            "name": tool.name,
            "description": description,
            "input_schema": tool.input_schema or {"type": "object", "properties": {}},
        }
        if cache:
            result["cache_control"] = {"type": "ephemeral"}
        return result

    @staticmethod
    def __convert_stop_reason(stop_reason: str | None) -> StopReason:
        match stop_reason:
            case "end_turn":
                return StopReason.END_TURN
            case "max_tokens":
                return StopReason.MAX_TOKENS
            case "tool_use":
                return StopReason.TOOL_USE
            case "stop_sequence":
                return StopReason.STOP_SEQUENCE
            case _:
                return StopReason.OTHER

    @classmethod
    def __convert_response(cls, response: AnthropicMessage, model: str) -> LLMResponse:
        blocks: list[AssistantBlock] = []
        for block in response.content:
            if block.type == "thinking":
                blocks.append(ThinkingBlock(text=block.thinking))
            elif block.type == "text":
                blocks.append(TextBlock(text=block.text))
            elif block.type == "tool_use":
                blocks.append(ToolUseBlock(id=block.id, name=block.name, input=block.input))

        usage = cls.__convert_usage(response.usage, model) if response.usage else None

        return LLMResponse(
            message=AssistantMessage(blocks=blocks),
            stop_reason=cls.__convert_stop_reason(response.stop_reason),
            stop_sequence=response.stop_sequence,
            usage=usage,
        )

    __USAGE_KNOWN_FIELDS: ClassVar[set[str]] = {
        "input_tokens",
        "output_tokens",
        "cache_read_input_tokens",
        "cache_creation_input_tokens",
        "cache_creation",
    }

    @classmethod
    def __convert_usage(cls, usage_obj: AnthropicUsage, model: str) -> Usage:
        cache_read = usage_obj.cache_read_input_tokens or 0
        cache_creation_total = usage_obj.cache_creation_input_tokens or 0

        cc = usage_obj.cache_creation
        if cc:
            cache_creation_5m = cc.ephemeral_5m_input_tokens or 0
            cache_creation_1h = cc.ephemeral_1h_input_tokens or 0
        else:
            cache_creation_5m = cache_creation_total  # fallback: price at 5m rate
            cache_creation_1h = 0

        raw = usage_obj.model_dump(mode="json")
        extra: dict[str, Any] = {k: v for k, v in raw.items() if k not in cls.__USAGE_KNOWN_FIELDS and v is not None}
        if cache_creation_5m:
            extra["cache_creation_5m_input_tokens"] = cache_creation_5m
        if cache_creation_1h:
            extra["cache_creation_1h_input_tokens"] = cache_creation_1h

        return Usage(
            input_tokens=usage_obj.input_tokens,
            output_tokens=usage_obj.output_tokens,
            cache_read_input_tokens=cache_read,
            cache_creation_input_tokens=cache_creation_total,
            cost_usd=anthropic_pricing.estimate_cost(
                model=model,
                input_tokens=usage_obj.input_tokens,
                output_tokens=usage_obj.output_tokens,
                cache_read_tokens=cache_read,
                cache_creation_5m_tokens=cache_creation_5m,
                cache_creation_1h_tokens=cache_creation_1h,
            ),
            extra=extra,
        )

    @staticmethod
    def __extract_text(response: LLMResponse) -> str:
        for block in response.message.blocks:
            if isinstance(block, TextBlock):
                return block.text
        return ""

    @staticmethod
    def __make_schema_message(cleaned_text: str) -> AssistantMessage:
        return AssistantMessage(blocks=[TextBlock(text=cleaned_text)])
