"""Pricing for Anthropic Claude models.

Anthropic charges separately for 5-minute and 1-hour cache creation.
Cache read and creation tokens are reported separately from input tokens.
"""

from dataclasses import dataclass

__all__ = ["estimate_cost"]


# Not kw_only — constructed positionally in pricing tables for readability.
@dataclass(frozen=True, slots=True)
class ModelPricing:
    input: float  # $ per 1M tokens
    output: float  # $ per 1M tokens
    cache_read: float  # $ per 1M tokens
    cache_creation_5m: float  # $ per 1M tokens (5-minute ephemeral cache)
    cache_creation_1h: float  # $ per 1M tokens (1-hour cache)


# Ordered longest-key-first so the first substring match is the most specific.
#                                          input  output  cache_read  cache_5m  cache_1h
PRICING: list[tuple[str, ModelPricing]] = [
    ("claude-sonnet-4-6", ModelPricing(3.0, 15.0, 0.30, 3.75, 6.0)),
    ("claude-sonnet-4-5", ModelPricing(3.0, 15.0, 0.30, 3.75, 6.0)),
    ("claude-sonnet-3-7", ModelPricing(3.0, 15.0, 0.30, 3.75, 6.0)),
    ("claude-haiku-4-5", ModelPricing(1.0, 5.0, 0.10, 1.25, 2.0)),
    ("claude-haiku-3-5", ModelPricing(0.80, 4.0, 0.08, 1.0, 1.6)),
    ("claude-opus-4-6", ModelPricing(5.0, 25.0, 0.50, 6.25, 10.0)),
    ("claude-opus-4-5", ModelPricing(5.0, 25.0, 0.50, 6.25, 10.0)),
    ("claude-opus-4-1", ModelPricing(15.0, 75.0, 1.50, 18.75, 30.0)),
    ("claude-sonnet-4", ModelPricing(3.0, 15.0, 0.30, 3.75, 6.0)),
    ("claude-haiku-3", ModelPricing(0.25, 1.25, 0.03, 0.30, 0.50)),
    ("claude-opus-4", ModelPricing(15.0, 75.0, 1.50, 18.75, 30.0)),
    ("claude-opus-3", ModelPricing(15.0, 75.0, 1.50, 18.75, 30.0)),
]


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int,
    cache_creation_5m_tokens: int,
    cache_creation_1h_tokens: int,
) -> float | None:
    """Estimate dollar cost for an Anthropic model.

    Returns None if the model is not in the pricing table.

    Contract: ``input_tokens`` must NOT include cache tokens.
    Each token is counted in exactly one category.
    """
    for key, p in PRICING:
        if key in model:
            return (
                input_tokens * p.input
                + output_tokens * p.output
                + cache_read_tokens * p.cache_read
                + cache_creation_5m_tokens * p.cache_creation_5m
                + cache_creation_1h_tokens * p.cache_creation_1h
            ) / 1_000_000
    return None
