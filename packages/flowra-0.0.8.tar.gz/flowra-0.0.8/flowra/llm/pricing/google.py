"""Pricing for Google Gemini models (via Vertex AI).

Google charges for input, output, and cache reads.
Cache creation is free (automatic).
"""

from dataclasses import dataclass

__all__ = ["estimate_cost"]


# Not kw_only — constructed positionally in pricing tables for readability.
@dataclass(frozen=True, slots=True)
class ModelPricing:
    input: float  # $ per 1M tokens
    output: float  # $ per 1M tokens
    cache_read: float  # $ per 1M tokens


# Ordered longest-key-first so the first substring match is the most specific.
PRICING: list[tuple[str, ModelPricing]] = [
    ("gemini-3.1-flash-lite-preview", ModelPricing(0.25, 1.50, 0.025)),
    ("gemini-3.1-pro-preview", ModelPricing(2.00, 12.00, 0.20)),
    ("gemini-3-flash-preview", ModelPricing(0.50, 3.00, 0.05)),
    ("gemini-2.5-flash-lite", ModelPricing(0.10, 0.40, 0.01)),
    ("gemini-2.0-flash-lite", ModelPricing(0.075, 0.30, 0)),
    ("gemini-3-pro-preview", ModelPricing(2.00, 12.00, 0.20)),
    ("gemini-2.0-flash", ModelPricing(0.10, 0.40, 0.025)),
    ("gemini-2.5-flash", ModelPricing(0.30, 2.50, 0.030)),
    ("gemini-2.5-pro", ModelPricing(1.25, 10.00, 0.125)),
]


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int,
) -> float | None:
    """Estimate dollar cost for a Google Gemini model.

    Returns None if the model is not in the pricing table.

    Contract: ``input_tokens`` must NOT include cache tokens.
    Each token is counted in exactly one category.
    """
    for key, p in PRICING:
        if key in model:
            return (input_tokens * p.input + output_tokens * p.output + cache_read_tokens * p.cache_read) / 1_000_000
    return None
