import dataclasses
from typing import Any

__all__ = ["Tool"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Tool:
    name: str
    description: str
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    cache: bool = False
    metadata: dict[str, Any] = dataclasses.field(default_factory=dict)
