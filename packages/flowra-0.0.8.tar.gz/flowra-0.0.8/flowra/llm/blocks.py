import dataclasses
from typing import Any, Literal

from ._base import LLMData

__all__ = [
    "AssistantBlock",
    "ImageBlock",
    "TextBlock",
    "ThinkingBlock",
    "ToolResultBlock",
    "ToolUseBlock",
    "UserBlock",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TextBlock(LLMData):
    type: Literal["text"] = "text"
    text: str
    cache: bool = False


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ImageBlock(LLMData):
    type: Literal["image"] = "image"
    data: bytes
    media_type: str
    cache: bool = False


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolUseBlock(LLMData):
    type: Literal["tool_use"] = "tool_use"
    id: str
    name: str
    input: dict[str, Any]
    cache: bool = False


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolResultBlock(LLMData):
    type: Literal["tool_result"] = "tool_result"
    tool_use_id: str
    content: str
    is_error: bool = False
    cache: bool = False


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ThinkingBlock(LLMData):
    type: Literal["thinking"] = "thinking"
    text: str
    cache: bool = False


type UserBlock = TextBlock | ImageBlock | ToolResultBlock
type AssistantBlock = TextBlock | ToolUseBlock | ThinkingBlock
