import dataclasses
from typing import Protocol

from ...llm import Message, SystemMessage, Tool

__all__ = [
    "CACHE_ALL",
    "CACHE_MANUAL",
    "CACHE_SESSION",
    "NO_CACHE",
    "CacheConfig",
    "MessagesCacheStrategy",
    "SystemPromptCacheStrategy",
    "ToolsCacheStrategy",
    "cache_last_message",
    "cache_last_session_message",
    "cache_last_system_prompt",
    "cache_last_tool",
    "no_cache_messages",
    "no_cache_system_prompt",
    "no_cache_tools",
]


class SystemPromptCacheStrategy(Protocol):
    def __call__(self, messages: list[SystemMessage]) -> list[SystemMessage]: ...


class ToolsCacheStrategy(Protocol):
    def __call__(self, tools: list[Tool]) -> list[Tool]: ...


class MessagesCacheStrategy(Protocol):
    def __call__(self, non_system_session_messages: list[Message], turn_messages: list[Message]) -> list[Message]: ...


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CacheConfig:
    system_prompt: SystemPromptCacheStrategy | None = None
    tools: ToolsCacheStrategy | None = None
    messages: MessagesCacheStrategy | None = None

    def apply(
        self,
        session_messages: list[Message],
        turn_messages: list[Message],
        tools: list[Tool],
    ) -> tuple[list[Message], list[Tool]]:
        session_messages = [m for m in session_messages if m.blocks]
        turn_messages = [m for m in turn_messages if m.blocks]

        system: list[SystemMessage] = [m for m in session_messages if isinstance(m, SystemMessage)]
        non_system_session: list[Message] = [m for m in session_messages if not isinstance(m, SystemMessage)]

        messages: list[Message] = []
        if self.system_prompt:
            messages.extend(self.system_prompt(system))
        else:
            messages.extend(system)

        if self.messages:
            messages.extend(self.messages(non_system_session, turn_messages))
        else:
            messages.extend(non_system_session)
            messages.extend(turn_messages)

        if self.tools:
            tools = self.tools(tools)

        return messages, tools


def cache_last_system_prompt(messages: list[SystemMessage]) -> list[SystemMessage]:
    return _cache_last_block(messages)


def cache_last_message(
    non_system_session_messages: list[Message],
    turn_messages: list[Message],
) -> list[Message]:
    messages = non_system_session_messages + turn_messages
    return _cache_last_block(messages)


def cache_last_session_message(
    non_system_session_messages: list[Message],
    turn_messages: list[Message],
) -> list[Message]:
    return _cache_last_block(non_system_session_messages) + _clear_cache_hints(turn_messages)


def no_cache_system_prompt(messages: list[SystemMessage]) -> list[SystemMessage]:
    return _clear_cache_hints(messages)


def no_cache_tools(tools: list[Tool]) -> list[Tool]:
    if any(t.cache for t in tools):
        return [dataclasses.replace(t, cache=False) if t.cache else t for t in tools]
    return list(tools)


def no_cache_messages(non_system_session_messages: list[Message], turn_messages: list[Message]) -> list[Message]:
    return _clear_cache_hints(non_system_session_messages + turn_messages)


def _clear_cache_hints[T: Message](messages: list[T]) -> list[T]:
    result = list(messages)
    for i, m in enumerate(result):
        if not any(b.cache for b in m.blocks):
            continue

        new_blocks = [dataclasses.replace(b, cache=False) if b.cache else b for b in m.blocks]
        result[i] = dataclasses.replace(m, blocks=new_blocks)

    return result


def _cache_last_block[T: Message](messages: list[T]) -> list[T]:
    if not messages:
        return messages

    result = _clear_cache_hints(messages)
    last = result[-1]
    new_blocks = list(last.blocks)
    new_blocks[-1] = dataclasses.replace(new_blocks[-1], cache=True)
    result[-1] = dataclasses.replace(last, blocks=new_blocks)
    return result


def cache_last_tool(tools: list[Tool]) -> list[Tool]:
    if not tools:
        return tools

    result = no_cache_tools(tools)
    result[-1] = dataclasses.replace(result[-1], cache=True)
    return result


CACHE_MANUAL = CacheConfig()

NO_CACHE = CacheConfig(
    system_prompt=no_cache_system_prompt,
    tools=no_cache_tools,
    messages=no_cache_messages,
)

CACHE_ALL = CacheConfig(
    system_prompt=cache_last_system_prompt,
    tools=cache_last_tool,
    messages=cache_last_message,
)

CACHE_SESSION = CacheConfig(
    system_prompt=cache_last_system_prompt,
    tools=cache_last_tool,
    messages=cache_last_session_message,
)
