from typing import Any

from ....agent import AgentRef

__all__ = ["ToolCallAgentContext"]


class ToolCallAgentContext:
    """Context available to tools during ToolCallAgent execution.

    Each tool call gets its own instance. Tools can use it to delegate
    work to a sub-agent via call_agent().
    """

    __slots__ = ("__call_agent_request",)

    def __init__(self) -> None:
        self.__call_agent_request: tuple[AgentRef, Any] | None = None

    def call_agent(self, agent: AgentRef, spec: Any | None = None) -> None:
        """Request that a sub-agent be spawned to handle this tool call.

        The tool's return value is ignored — the agent's result becomes
        the tool result.
        """
        if self.__call_agent_request is not None:
            raise RuntimeError("call_agent() can only be called once per tool execution")
        self.__call_agent_request = (agent, spec)

    def get_call_agent_request(self) -> tuple[AgentRef, Any] | None:
        return self.__call_agent_request
