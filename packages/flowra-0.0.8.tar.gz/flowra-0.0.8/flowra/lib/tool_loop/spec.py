import dataclasses
import enum
from typing import Any

from ...llm import AssistantMessage, Message, StopReason, Usage

__all__ = ["ToolLoopResult", "ToolLoopSpec", "ToolLoopStatus"]


class ToolLoopStatus(enum.StrEnum):
    COMPLETED = "completed"
    MAX_LLM_CALLS = "max_llm_calls"
    INTERRUPTED = "interrupted"
    FINISH_REQUESTED = "finish_requested"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolLoopSpec:
    user_message: str
    metadata: dict[str, Any] | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolLoopResult:
    messages: list[Message]
    status: ToolLoopStatus
    stop_reason: StopReason | None = None
    result_message: AssistantMessage | None = None
    usage: Usage | None = None
