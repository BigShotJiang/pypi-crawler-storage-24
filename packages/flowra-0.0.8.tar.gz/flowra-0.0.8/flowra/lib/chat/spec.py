import dataclasses
from typing import Any

from ...llm import Usage

__all__ = ["ChatResult", "ChatSpec"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatSpec:
    user_message: str
    metadata: dict[str, Any] | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatResult:
    response: str | None = None
    usage: Usage | None = None
