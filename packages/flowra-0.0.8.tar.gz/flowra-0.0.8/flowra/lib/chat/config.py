import dataclasses
from typing import Any

from ...llm import Message
from ..config_value import ConfigValue
from ..llm_config import LLMConfig
from ..tool_loop import CACHE_MANUAL, CacheConfig

__all__ = ["ChatConfig"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatConfig:
    """Configuration for ChatAgent.

    ChatAgent uses this to build a ToolLoopConfig for each turn,
    injecting session messages from the chat history.

    Data providers accept ConfigValue[T] — a plain value, sync callable, or async callable.
    """

    llm_config: ConfigValue[LLMConfig]
    system_messages: ConfigValue[list[Message]]
    json_schema: ConfigValue[dict[str, Any] | None] = None
    max_llm_calls: ConfigValue[int] = 10
    allowed_tools: ConfigValue[set[str] | None] = None
    denied_tools: ConfigValue[set[str] | None] = None
    cache_strategy: ConfigValue[CacheConfig] = CACHE_MANUAL
    max_consecutive_errors: ConfigValue[int | None] = None
