from typing import Any, ClassVar

from .compile import compile_agent
from .model import AbstractAgent, AgentDefinitionRef, get_step_tag, set_agent_class

__all__ = ["Agent"]


class Agent[S, R](AbstractAgent):
    __slots__ = ("__slot_store__",)
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {}

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        for attr_name in vars(cls):
            val = getattr(cls, attr_name, None)
            if callable(val) and get_step_tag(val) is not None:
                set_agent_class(val, cls)

        subagents = getattr(cls, "__subagents__", None)
        cls.__agent_definition__ = compile_agent(cls, subagents)
