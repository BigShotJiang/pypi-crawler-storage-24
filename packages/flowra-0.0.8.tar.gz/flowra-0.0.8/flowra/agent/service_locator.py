import abc
from typing import Any

__all__ = ["ServiceLocator"]


class ServiceLocator(abc.ABC):
    __slots__ = ()

    @abc.abstractmethod
    def provide[T](self, service_type: type[T], instance: T) -> None: ...

    @property
    @abc.abstractmethod
    def services(self) -> dict[type, Any]: ...
