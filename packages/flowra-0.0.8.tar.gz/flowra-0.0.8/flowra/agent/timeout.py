import asyncio
import contextlib
import dataclasses
import time

from .agent import Agent
from .agent_store import AgentStore
from .interrupt_token import InterruptToken
from .model import CallAgent
from .step_decorator import step
from .stored_values import Scalar

__all__ = ["TimeoutAgent", "TimeoutExpired", "timeout"]

TIMEOUT_AGENT_NAME = "__flowra__timeout__"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TimeoutSpec:
    seconds: float


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TimeoutExpired:
    seconds: float


def timeout(*, seconds: float = 0, minutes: float = 0) -> CallAgent:
    """Shortcut for creating a timeout child agent."""
    total = seconds + minutes * 60
    return CallAgent(agent=TIMEOUT_AGENT_NAME, spec=TimeoutSpec(seconds=total))


class TimeoutAgent(Agent[TimeoutSpec, TimeoutExpired]):
    __slots__ = ("__deadline", "__interrupt", "__store")

    def __init__(self, store: AgentStore, interrupt: InterruptToken) -> None:
        self.__deadline = store.slot(Scalar[float], "deadline")
        self.__store = store
        self.__interrupt = interrupt

    @step(entry=True)
    async def wait(self, spec: TimeoutSpec) -> TimeoutExpired:
        if self.__deadline.has_value():
            deadline = self.__deadline.get()
        else:
            deadline = time.time() + spec.seconds
            self.__deadline.set(deadline)
            await self.__store.flush()
        remaining = deadline - time.time()
        if remaining > 0:
            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(self.__interrupt.wait(), timeout=remaining)
        self.__interrupt.check()
        return TimeoutExpired(seconds=spec.seconds)
