import abc
from typing import Any, overload

from .stored_values import AppendOnlyList, Scalar

__all__ = ["AgentStore"]


class AgentStore(abc.ABC):
    __slots__ = ()

    @overload
    def slot[T](self, cls: type[Scalar[T]], key: str) -> Scalar[T]: ...

    @overload
    def slot[T](self, cls: type[AppendOnlyList[T]], key: str) -> AppendOnlyList[T]: ...

    @abc.abstractmethod
    def slot(self, cls: Any, key: str) -> Any: ...

    @abc.abstractmethod
    async def flush(self) -> None: ...
