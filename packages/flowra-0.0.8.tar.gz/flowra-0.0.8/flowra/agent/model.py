import dataclasses
import enum
from collections.abc import Awaitable, Callable
from typing import Any, ClassVar, Protocol

from .service_locator import ServiceLocator

__all__ = [
    "NEW_SCOPE",
    "AbstractAgent",
    "AgentDefinition",
    "AgentDefinitionRef",
    "AgentInstance",
    "AgentRef",
    "CallAgent",
    "CallStep",
    "CallStepHandler",
    "ChildOutput",
    "CreateInstance",
    "FromAgentSpec",
    "FromChild",
    "FromChildren",
    "FromSpec",
    "GotoAgent",
    "GotoStep",
    "NoResult",
    "NoSpec",
    "Spawn",
    "SpawnChild",
    "SpawnNode",
    "StepAction",
    "StepMeta",
    "StepMethod",
    "StepRef",
    "StepResult",
    "WhenAll",
    "WhenAny",
    "WhenN",
]

_STEP_TAG_ATTR = "__step_tag__"
_AGENT_CLASS_ATTR = "__agent_class__"


def get_step_tag(fn: Callable[..., Any]) -> str | None:
    return getattr(fn, _STEP_TAG_ATTR, None)


def set_step_tag(fn: Callable[..., Any], tag: str) -> None:
    setattr(fn, _STEP_TAG_ATTR, tag)


def set_agent_class(fn: Callable[..., Any], cls: type) -> None:
    setattr(fn, _AGENT_CLASS_ATTR, cls)


def resolve_step_ref(ref: "StepRef") -> str:
    if isinstance(ref, str):
        return ref
    func = getattr(ref, "__func__", ref)
    tag = getattr(func, _STEP_TAG_ATTR, None)
    if tag is None:
        raise TypeError(f"{ref!r} is not a @step-decorated method")
    return tag


class AbstractAgent:
    __slots__ = ()
    __agent_definition__: ClassVar["AgentDefinition"]


type AgentRef = str | type[AbstractAgent]


# ---------------------------------------------------------------------------
# Sentinel types (no inheritance)
# ---------------------------------------------------------------------------


class NoSpec:
    __slots__ = ()

    def __init__(self, **kwargs: Any) -> None:
        raise TypeError("NoSpec cannot be instantiated")


class NoResult:
    __slots__ = ()

    def __init__(self, **kwargs: Any) -> None:
        raise TypeError("NoResult cannot be instantiated")


# ---------------------------------------------------------------------------
# Annotated markers
# ---------------------------------------------------------------------------


class FromSpec:
    """Annotated[T, FromSpec] — bind from step-level spec (from GotoStep/CallStep/entry)."""

    __slots__ = ()


class FromAgentSpec:
    """Annotated[T, FromAgentSpec] — bind from agent-level spec (persisted, available in any step)."""

    __slots__ = ()


class FromChild:
    """Annotated[T, FromChild] or Annotated[T, FromChild("tag")] — bind from single child result."""

    __slots__ = ("tag",)

    def __init__(self, tag: str | None = None) -> None:
        self.tag = tag


class FromChildren:
    """Annotated[list[T], FromChildren] — bind from all child results."""

    __slots__ = ()


# ---------------------------------------------------------------------------
# ChildOutput: bridge between runtime and agent layer
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChildOutput:
    result: Any
    tag: str | None = None


class _NewScope(enum.Enum):
    NEW_SCOPE = "NEW_SCOPE"


NEW_SCOPE = _NewScope.NEW_SCOPE


# ---------------------------------------------------------------------------
# Control flow: step-level (internal navigation)
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class GotoStep:
    step: str
    spec: Any | None
    storage_key: str | _NewScope | None

    def __init__(
        self,
        *,
        step: "StepRef",
        spec: Any | None = None,
        storage_key: str | _NewScope | None = None,
    ) -> None:
        object.__setattr__(self, "step", resolve_step_ref(step))
        object.__setattr__(self, "spec", spec)
        object.__setattr__(self, "storage_key", storage_key)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class CallStep:
    step: str
    spec: Any | None
    storage_key: str | _NewScope | None
    tag: str | None

    def __init__(
        self,
        *,
        step: "StepRef",
        spec: Any | None = None,
        storage_key: str | _NewScope | None = None,
        tag: str | None = None,
    ) -> None:
        object.__setattr__(self, "step", resolve_step_ref(step))
        object.__setattr__(self, "spec", spec)
        object.__setattr__(self, "storage_key", storage_key)
        object.__setattr__(self, "tag", tag)


# ---------------------------------------------------------------------------
# Control flow: agent-level (black-box invocation)
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GotoAgent:
    agent: AgentRef
    spec: Any | None = None
    storage_key: str | _NewScope | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CallAgent:
    agent: AgentRef
    spec: Any | None = None
    storage_key: str | _NewScope | None = None
    tag: str | None = None


# ---------------------------------------------------------------------------
# Spawn
# ---------------------------------------------------------------------------

type SpawnChild = CallStep | CallAgent


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class WhenAll:
    nodes: tuple["SpawnNode", ...]

    def __init__(self, *nodes: "SpawnNode") -> None:
        if not nodes:
            raise ValueError("WhenAll requires at least 1 node")
        object.__setattr__(self, "nodes", nodes)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class WhenAny:
    nodes: tuple["SpawnNode", ...]

    def __init__(self, *nodes: "SpawnNode") -> None:
        if not nodes:
            raise ValueError("WhenAny requires at least 1 node")
        object.__setattr__(self, "nodes", nodes)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class WhenN:
    nodes: tuple["SpawnNode", ...]
    n: int

    def __init__(self, *nodes: "SpawnNode", n: int) -> None:
        if n < 1 or n > len(nodes):
            raise ValueError(f"WhenN: n must be between 1 and {len(nodes)}, got {n}")
        object.__setattr__(self, "nodes", nodes)
        object.__setattr__(self, "n", n)


type SpawnNode = SpawnChild | WhenAll | WhenAny | WhenN


def _flatten_leaves(node: SpawnNode, out: list[SpawnChild]) -> None:
    match node:
        case CallStep() | CallAgent():
            out.append(node)
        case WhenAll(nodes=nodes) | WhenAny(nodes=nodes) | WhenN(nodes=nodes):
            for child in nodes:
                _flatten_leaves(child, out)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class Spawn:
    root: SpawnNode
    children: list[SpawnChild]
    then: str

    def __init__(
        self,
        *args: SpawnNode,
        children: list[SpawnChild] | None = None,
        then: "StepRef",
    ) -> None:
        if args and children is not None:
            raise TypeError("Cannot specify both positional SpawnNode args and 'children' keyword")
        if children is not None:
            if len(children) > 1:
                root: SpawnNode = WhenAll(*children)
            elif len(children) == 1:
                root = children[0]
            else:
                # Empty children — create a trivial WhenAll with no validation
                root = object.__new__(WhenAll)
                object.__setattr__(root, "nodes", ())
            flat = list(children)
        elif args:
            args_list = list(args)
            if len(args_list) == 1 and isinstance(args_list[0], (WhenAll, WhenAny, WhenN)):
                root = args_list[0]
            elif len(args_list) > 1:
                root = WhenAll(*args_list)
            else:
                root = args_list[0]
            flat: list[SpawnChild] = []
            _flatten_leaves(root, flat)
        else:
            raise TypeError("Spawn requires at least one child")
        object.__setattr__(self, "root", root)
        object.__setattr__(self, "children", flat)
        object.__setattr__(self, "then", resolve_step_ref(then))


# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

type StepAction = GotoStep | GotoAgent | Spawn
type StepResult = StepAction | Any
type StepMethod = Callable[..., StepResult | Awaitable[StepResult]]
type StepRef = str | StepMethod


class CallStepHandler(Protocol):
    async def __call__(
        self,
        tag: str,
        spec: Any | None = None,
        child_outputs: list[ChildOutput] | None = None,
        agent_spec: Any | None = None,
    ) -> Any: ...


type CreateInstance = Callable[[ServiceLocator], AgentInstance]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AgentInstance:
    call_step: CallStepHandler


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StepMeta:
    spec_types: frozenset[type] = frozenset()
    result_types: frozenset[type] = frozenset()


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AgentDefinition:
    steps: dict[str, StepMeta]
    type_registry: dict[str, type]
    create_instance: CreateInstance
    # Agent-level contract
    entry_step: str
    subagents: "dict[str, AgentDefinitionRef]" = dataclasses.field(default_factory=dict)
    spec_types: frozenset[type] = frozenset()
    result_types: frozenset[type] = frozenset()


type AgentDefinitionRef = AgentDefinition | type[AbstractAgent]
