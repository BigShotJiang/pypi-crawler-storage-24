from collections.abc import Callable
from typing import overload

from .model import StepMethod, set_step_tag

__all__ = ["is_entry_step", "step"]

_ENTRY_ATTR = "__step_entry__"


def is_entry_step(fn: Callable[..., object]) -> bool:
    return getattr(fn, _ENTRY_ATTR, False) is True


@overload
def step[F: StepMethod](fn: F, /) -> F: ...


@overload
def step(tag: str = ..., /, *, entry: bool = ...) -> Callable[[StepMethod], StepMethod]: ...


@overload
def step(*, entry: bool) -> Callable[[StepMethod], StepMethod]: ...


def step(
    tag_or_fn: str | StepMethod = "",
    /,
    *,
    entry: bool = False,
) -> StepMethod | Callable[[StepMethod], StepMethod]:
    if callable(tag_or_fn):
        # @step (bare decorator, no arguments)
        set_step_tag(tag_or_fn, tag_or_fn.__name__)
        return tag_or_fn

    tag = tag_or_fn

    def decorator(fn: StepMethod) -> StepMethod:
        set_step_tag(fn, tag or fn.__name__)
        if entry:
            setattr(fn, _ENTRY_ATTR, True)
        return fn

    return decorator
