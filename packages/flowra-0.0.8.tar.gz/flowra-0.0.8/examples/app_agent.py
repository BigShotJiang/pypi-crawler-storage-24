"""AppAgent — parent agent wrapping ChatAgent with persistent model selection."""

import abc
import dataclasses
from collections.abc import Callable
from typing import ClassVar

from flowra.agent import Agent, AgentDefinitionRef, AgentStore, CallAgent, Scalar, ServiceLocator, Spawn, step
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib.config_value import ConfigValue
from flowra.lib.tool_loop import CACHE_MANUAL, CacheConfig
from flowra.llm import Message

__all__ = ["AppAgent", "AppConfig", "ModelSwitcher"]


class ModelSwitcher(abc.ABC):
    __slots__ = ()

    @abc.abstractmethod
    def switch_model(self, model_key: str) -> None: ...

    @abc.abstractmethod
    def get_current_model(self) -> str: ...


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AppConfig:
    default_model: str
    system_messages: ConfigValue[list[Message]]
    max_llm_calls: ConfigValue[int] = 10
    allowed_tools: ConfigValue[set[str] | None] = None
    denied_tools: ConfigValue[set[str] | None] = None
    cache_strategy: ConfigValue[CacheConfig] = CACHE_MANUAL
    max_consecutive_errors: ConfigValue[int | None] = None
    on_model_changed: Callable[[str], None] | None = None


class AppAgent(Agent[ChatSpec, ChatResult], ModelSwitcher):
    __slots__ = ("__config", "__current_model")
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "chat": ChatAgent,
    }

    def __init__(
        self,
        store: AgentStore,
        services: ServiceLocator,
        config: AppConfig,
    ) -> None:
        self.__current_model = store.slot(Scalar[str], "current_model")
        self.__config = config

        services.provide(
            ChatConfig,
            ChatConfig(
                llm_config=self.__make_llm_config,
                system_messages=config.system_messages,
                max_llm_calls=config.max_llm_calls,
                allowed_tools=config.allowed_tools,
                denied_tools=config.denied_tools,
                cache_strategy=config.cache_strategy,
                max_consecutive_errors=config.max_consecutive_errors,
            ),
        )
        services.provide(ModelSwitcher, self)

    def __make_llm_config(self) -> LLMConfig:
        return LLMConfig(model=self.__current_model.get(default=self.__config.default_model))

    def switch_model(self, model_key: str) -> None:
        self.__current_model.set(model_key)
        if self.__config.on_model_changed is not None:
            self.__config.on_model_changed(model_key)

    def get_current_model(self) -> str:
        return self.__current_model.get(default=self.__config.default_model)

    @step(entry=True)
    async def process_message(self, spec: ChatSpec) -> Spawn:
        return Spawn(
            children=[
                CallAgent(
                    agent=ChatAgent,
                    spec=spec,
                    storage_key="chat",
                ),
            ],
            then=self.collect_result,
        )

    @step
    async def collect_result(self, result: ChatResult) -> ChatResult:
        return result
