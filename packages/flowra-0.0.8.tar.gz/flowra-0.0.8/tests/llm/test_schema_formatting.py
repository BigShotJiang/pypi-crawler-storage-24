from textwrap import dedent

from flowra.llm.schema_formatting import format_output_schema_for_description, format_schema_for_llm


def test_basic_string_type() -> None:
    assert format_schema_for_llm({"type": "string"}) == "string"


def test_basic_integer_type() -> None:
    assert format_schema_for_llm({"type": "integer"}) == "integer"


def test_no_type_returns_any() -> None:
    assert format_schema_for_llm({}) == "any"


def test_type_with_default() -> None:
    assert format_schema_for_llm({"type": "string", "default": "hello"}) == 'string (default: "hello")'


def test_integer_default() -> None:
    assert format_schema_for_llm({"type": "integer", "default": 42}) == "integer (default: 42)"


def test_enum() -> None:
    assert format_schema_for_llm({"enum": ["pending", "completed", "failed"]}) == '"pending" | "completed" | "failed"'


def test_array_of_strings() -> None:
    assert format_schema_for_llm({"type": "array", "items": {"type": "string"}}) == "array<string>"


def test_array_of_objects() -> None:
    schema = {
        "type": "array",
        "items": {
            "type": "object",
            "properties": {"id": {"type": "integer"}},
            "required": ["id"],
        },
    }
    assert format_schema_for_llm(schema) == dedent("""\
        array<{
          id*: integer
        }>""")


def test_object_with_required_and_optional() -> None:
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
        },
        "required": ["name"],
    }
    assert format_schema_for_llm(schema) == dedent("""\
        {
          name*: string
          age?: integer
        }""")


def test_object_with_description() -> None:
    schema = {
        "type": "object",
        "properties": {
            "account_id": {"type": "string", "description": "The account identifier"},
        },
        "required": ["account_id"],
    }
    assert format_schema_for_llm(schema) == dedent("""\
        {
          account_id*: string // The account identifier
        }""")


def test_empty_object() -> None:
    assert format_schema_for_llm({"type": "object"}) == "object"
    assert format_schema_for_llm({"type": "object", "properties": {}}) == "object"


def test_any_of_union() -> None:
    assert format_schema_for_llm({"anyOf": [{"type": "string"}, {"type": "integer"}]}) == "string | integer"


def test_optional_union_with_null() -> None:
    assert format_schema_for_llm({"anyOf": [{"type": "string"}, {"type": "null"}]}) == "string | null"


def test_ref_resolution() -> None:
    schema = {
        "type": "object",
        "properties": {
            "status": {"$ref": "#/$defs/Status"},
        },
        "required": ["status"],
        "$defs": {
            "Status": {"enum": ["active", "inactive"]},
        },
    }
    assert format_schema_for_llm(schema) == dedent("""\
        {
          status*: "active" | "inactive"
        }""")


def test_nested_object() -> None:
    schema = {
        "type": "object",
        "properties": {
            "address": {
                "type": "object",
                "properties": {
                    "city": {"type": "string"},
                    "zip": {"type": "string"},
                },
                "required": ["city"],
            },
        },
        "required": ["address"],
    }
    assert format_schema_for_llm(schema) == dedent("""\
        {
          address*: {
            city*: string
            zip?: string
          }
        }""")


def test_properties_without_type() -> None:
    schema = {
        "properties": {
            "x": {"type": "integer"},
        },
        "required": ["x"],
    }
    assert format_schema_for_llm(schema) == dedent("""\
        {
          x*: integer
        }""")


def test_array_without_items() -> None:
    assert format_schema_for_llm({"type": "array"}) == "array<any>"


def test_nested_ref() -> None:
    schema = {
        "type": "object",
        "properties": {
            "item": {"$ref": "#/$defs/Wrapper"},
        },
        "required": ["item"],
        "$defs": {
            "Wrapper": {
                "type": "object",
                "properties": {
                    "value": {"$ref": "#/$defs/Value"},
                },
                "required": ["value"],
            },
            "Value": {"type": "string"},
        },
    }
    result = format_schema_for_llm(schema)
    assert "value*: string" in result


def test_all_of_with_ref() -> None:
    """allOf with $ref — typical Pydantic pattern for adding description to a referenced type."""
    schema = {
        "type": "object",
        "properties": {
            "status": {
                "allOf": [{"$ref": "#/$defs/Status"}],
                "description": "Current status",
            },
        },
        "required": ["status"],
        "$defs": {
            "Status": {"enum": ["active", "inactive"]},
        },
    }
    assert format_schema_for_llm(schema) == dedent("""\
        {
          status*: "active" | "inactive" // Current status
        }""")


def test_all_of_with_properties() -> None:
    """allOf with inline properties."""
    schema = {
        "allOf": [
            {
                "type": "object",
                "properties": {"name": {"type": "string"}},
                "required": ["name"],
            },
        ],
    }
    assert format_schema_for_llm(schema) == dedent("""\
        {
          name*: string
        }""")


def test_all_of_fallback_to_first() -> None:
    """allOf without $ref or properties falls back to first element."""
    schema = {"allOf": [{"type": "string"}]}
    assert format_schema_for_llm(schema) == "string"


def test_array_style_type_with_null() -> None:
    """type: ["string", "null"] is normalized to anyOf format."""
    assert format_schema_for_llm({"type": ["string", "null"]}) == "string | null"


def test_array_style_type_without_null() -> None:
    assert format_schema_for_llm({"type": ["string", "integer"]}) == "string | integer"


def test_array_style_type_single() -> None:
    assert format_schema_for_llm({"type": ["string"]}) == "string"


def test_array_style_type_preserves_extra_fields() -> None:
    """Extra fields like default are preserved through normalization."""
    schema = {"type": ["string", "null"], "default": "hi"}
    assert format_schema_for_llm(schema) == 'string (default: "hi") | null'


def test_format_output_schema_for_description() -> None:
    schema = {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"]}
    assert format_output_schema_for_description(schema) == dedent("""\


        Output structure:
        {
          ok*: boolean
        }""")
