import pytest

from flowra.llm.pricing import openai as openai_pricing


class TestOpenAIPricing:
    def test_known_model(self) -> None:
        cost = openai_pricing.estimate_cost(
            model="gpt-4o", input_tokens=1_000_000, output_tokens=1_000_000, cache_read_tokens=0
        )
        assert cost == pytest.approx(2.50 + 10.0)

    def test_with_cache_read(self) -> None:
        cost = openai_pricing.estimate_cost(
            model="gpt-4.1",
            input_tokens=500_000,
            output_tokens=500_000,
            cache_read_tokens=500_000,
        )
        assert cost == pytest.approx(500_000 * 2.0 / 1e6 + 500_000 * 8.0 / 1e6 + 500_000 * 0.5 / 1e6)

    def test_mercury_2(self) -> None:
        cost = openai_pricing.estimate_cost(
            model="mercury-2", input_tokens=1_000_000, output_tokens=1_000_000, cache_read_tokens=0
        )
        assert cost == pytest.approx(0.25 + 0.75)

    def test_unknown_model(self) -> None:
        assert (
            openai_pricing.estimate_cost(model="unknown", input_tokens=100, output_tokens=100, cache_read_tokens=0)
            is None
        )

    def test_longest_match(self) -> None:
        # "gpt-4o-mini" should match before "gpt-4o"
        cost = openai_pricing.estimate_cost(
            model="gpt-4o-mini", input_tokens=1_000_000, output_tokens=1_000_000, cache_read_tokens=0
        )
        assert cost == pytest.approx(0.15 + 0.60)
