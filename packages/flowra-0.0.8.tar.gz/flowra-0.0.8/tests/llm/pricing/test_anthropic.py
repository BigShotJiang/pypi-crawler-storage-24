import pytest

from flowra.llm.pricing import anthropic as anthropic_pricing


class TestAnthropicPricing:
    def test_known_model(self) -> None:
        cost = anthropic_pricing.estimate_cost(
            model="claude-sonnet-4-5",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
            cache_read_tokens=0,
            cache_creation_5m_tokens=0,
            cache_creation_1h_tokens=0,
        )
        assert cost == pytest.approx(3.0 + 15.0)

    def test_with_cache(self) -> None:
        cost = anthropic_pricing.estimate_cost(
            model="claude-sonnet-4-5",
            input_tokens=0,
            output_tokens=0,
            cache_read_tokens=1_000_000,
            cache_creation_5m_tokens=1_000_000,
            cache_creation_1h_tokens=1_000_000,
        )
        assert cost == pytest.approx(0.30 + 3.75 + 6.0)

    def test_unknown_model(self) -> None:
        assert (
            anthropic_pricing.estimate_cost(
                model="unknown-model",
                input_tokens=100,
                output_tokens=100,
                cache_read_tokens=0,
                cache_creation_5m_tokens=0,
                cache_creation_1h_tokens=0,
            )
            is None
        )

    def test_substring_match(self) -> None:
        cost = anthropic_pricing.estimate_cost(
            model="some-prefix-claude-opus-4-6-suffix",
            input_tokens=1_000_000,
            output_tokens=0,
            cache_read_tokens=0,
            cache_creation_5m_tokens=0,
            cache_creation_1h_tokens=0,
        )
        assert cost == pytest.approx(5.0)

    def test_zero_tokens(self) -> None:
        cost = anthropic_pricing.estimate_cost(
            model="claude-sonnet-4-5",
            input_tokens=0,
            output_tokens=0,
            cache_read_tokens=0,
            cache_creation_5m_tokens=0,
            cache_creation_1h_tokens=0,
        )
        assert cost == pytest.approx(0.0)
