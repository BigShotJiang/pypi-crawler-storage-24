from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from flowra.runtime.storage import ChangeSet, InMemorySessionStorage


class TrackingSessionStorage(InMemorySessionStorage):
    def __init__(self) -> None:
        super().__init__()
        self.save_execution_calls: list[dict[str, Any]] = []
        self.save_node_state_calls: list[tuple[str, ChangeSet]] = []
        self.transaction_count: int = 0

    @asynccontextmanager
    async def begin_transaction(self) -> AsyncIterator[None]:
        self.transaction_count += 1
        yield

    async def save_execution(self, execution: dict[str, Any]) -> None:
        self.save_execution_calls.append(execution)
        await super().save_execution(execution)

    async def save_node_state(self, key: str, changes: ChangeSet) -> None:
        self.save_node_state_calls.append((key, changes))
        await super().save_node_state(key, changes)
