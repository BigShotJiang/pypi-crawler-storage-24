"""Persistence integration tests using an in-memory SessionStorage."""

import dataclasses
from typing import Any

import pytest

from flowra.agent import (
    AgentDefinition,
    AgentInstance,
    AgentStore,
    AppendOnlyList,
    CallAgent,
    CallStep,
    CallStepHandler,
    ChildOutput,
    GotoAgent,
    GotoStep,
    Scalar,
    ServiceLocator,
    Spawn,
    StepMeta,
)
from flowra.runtime import AgentRuntime, ChangeSet, InMemorySessionStorage
from tests.runtime.storage import TrackingSessionStorage


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Val:
    v: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class TSpec:
    msg: str


_TYPE_REGISTRY: dict[str, type] = {"Val": Val, "TSpec": TSpec}


def _defn(
    handler: CallStepHandler, type_registry: dict[str, type] | None = None, *, entry_step: str = "start"
) -> AgentDefinition:
    def create(sl: ServiceLocator) -> AgentInstance:
        return AgentInstance(call_step=handler)

    return AgentDefinition(
        steps={}, type_registry=type_registry or _TYPE_REGISTRY, create_instance=create, entry_step=entry_step
    )


# -- Tests --


class TestSaveExecutionCalled:
    async def test_save_called_after_run(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        storage = TrackingSessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        result = await runtime.run(agent="a")

        assert isinstance(result, Val)
        assert result.v == "ok"
        assert len(storage.save_execution_calls) == 1
        assert storage.transaction_count >= 1


class TestSaveExecutionTreeShape:
    async def test_spawn_saves_all_node_ids(self) -> None:
        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[
                        CallAgent(agent="c", spec=TSpec(msg="1")),
                        CallAgent(agent="c", spec=TSpec(msg="2")),
                    ],
                    then="join",
                )
            assert child_outputs is not None
            return Val(v=",".join(r.result.v for r in child_outputs))  # type: ignore[union-attr]

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            assert isinstance(spec, TSpec)
            return Val(v=spec.msg)

        storage = TrackingSessionStorage()
        runtime = AgentRuntime(agents={"p": _defn(parent), "c": _defn(child, entry_step="work")}, storage=storage)
        result = await runtime.run(agent="p")

        assert isinstance(result, Val)
        assert result.v == "1,2"

        # Should have saved execution multiple times (once per advance tick)
        assert len(storage.save_execution_calls) == 3  # spawn, children+propagate, join

        # Check the second save (after spawn) had children with correct node_ids
        spawn_snapshot = storage.save_execution_calls[0]
        assert spawn_snapshot["node_id"] == "r1"
        assert spawn_snapshot["children"] is not None
        assert len(spawn_snapshot["children"]) == 2
        assert spawn_snapshot["children"][0]["node_id"] == "r1.0"
        assert spawn_snapshot["children"][1]["node_id"] == "r1.1"


class TestRunWithStorage:
    async def test_spawn_completes_with_storage(self) -> None:
        call_count = 0

        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            nonlocal call_count
            call_count += 1
            if tag == "start":
                return Spawn(
                    children=[
                        CallStep(step="work", spec=TSpec(msg="x")),
                    ],
                    then="join",
                )
            if tag == "work":
                assert isinstance(spec, TSpec)
                return Val(v=spec.msg)
            # join
            assert child_outputs is not None
            return Val(v="joined:" + ",".join(r.result.v for r in child_outputs))  # type: ignore[union-attr]

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        result = await runtime.run(agent="a")

        assert isinstance(result, Val)
        assert result.v == "joined:x"

    async def test_goto_agent_preserves_node_id_in_snapshot(self) -> None:
        async def ha(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return GotoAgent(agent="b")

        async def hb(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="from_b")

        storage = TrackingSessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(ha), "b": _defn(hb, entry_step="run")}, storage=storage)
        result = await runtime.run(agent="a")

        assert isinstance(result, Val)
        assert result.v == "from_b"

        # After Goto to another agent, the saved execution should still have node_id="r1"
        # but agent_name="b" in the final snapshot
        # Note: execution is cleared on completion, so check the save_execution_calls
        assert len(storage.save_execution_calls) >= 1
        last_save = storage.save_execution_calls[-1]
        assert last_save["node_id"] == "r1"


class TestHasPendingExecution:
    async def test_false_without_storage(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        runtime = AgentRuntime(agents={"a": _defn(handler)})
        assert await runtime.has_pending_execution() is False

    async def test_false_with_empty_storage(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        assert await runtime.has_pending_execution() is False

    async def test_false_after_completed_run(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        await runtime.run(agent="a")
        assert await runtime.has_pending_execution() is False

    async def test_true_with_pending_snapshot(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        # Simulate a crashed run by manually setting execution snapshot
        await storage.save_execution({"node_id": "root", "agent_name": "a", "status": "pending_step"})
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        assert await runtime.has_pending_execution() is True


class TestRunBlockedByPendingExecution:
    async def test_run_raises_when_pending_execution_exists(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        await storage.save_execution({"node_id": "root", "agent_name": "a", "status": "pending_step"})
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        with pytest.raises(RuntimeError, match="Pending execution exists"):
            await runtime.run(agent="a")


class TestResumeNoStorage:
    async def test_resume_without_storage_raises(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        runtime = AgentRuntime(agents={"a": _defn(handler)})
        with pytest.raises(RuntimeError, match="No storage configured"):
            await runtime.resume()

    async def test_resume_empty_storage_raises(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        with pytest.raises(RuntimeError, match="No persisted state"):
            await runtime.resume()


class TestExecutionClearedOnCompletion:
    async def test_execution_cleared_after_run(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        await runtime.run(agent="a")

        # Execution snapshot should be cleared after successful completion
        assert await storage.has_execution() is False


class TestStorageKeyReleaseWithStorage:
    async def test_storage_key_reuse_after_child_completion(self) -> None:
        """After child completes and releases its key, the key can be reused."""
        spawn_count = 0

        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            nonlocal spawn_count
            if tag == "start":
                return Spawn(
                    children=[
                        CallAgent(agent="c", storage_key="child-key"),
                    ],
                    then="join",
                )
            if tag == "join":
                spawn_count += 1
                if spawn_count == 1:
                    # First join: spawn again with same key — should work
                    # because first child was released on completion
                    return Spawn(
                        children=[
                            CallAgent(agent="c", storage_key="child-key"),
                        ],
                        then="done",
                    )
                return Val(v="ok")
            return Val(v="ok")

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="child_done")

        storage = InMemorySessionStorage()

        # Run to completion — verify the key reuse works normally
        runtime = AgentRuntime(
            agents={"p": _defn(parent), "c": _defn(child, entry_step="work")},
            storage=storage,
        )
        result = await runtime.run(agent="p", storage_key="parent-key")
        assert isinstance(result, Val)
        assert result.v == "ok"


class TestSnapshotIncludesStorageKey:
    async def test_storage_key_in_snapshot(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="ok")

        storage = TrackingSessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        await runtime.run(agent="a", storage_key="my-key")

        assert len(storage.save_execution_calls) >= 1
        snapshot = storage.save_execution_calls[0]
        assert snapshot["storage_key"] == "my-key"


class TestSameQualnameNoCollision:
    async def test_two_agents_same_qualname_specs_no_collision(self) -> None:
        """Two agents with same-qualname spec/result types don't collide at startup."""
        # Val and TSpec have same qualname across both agents — per-agent registries handle this
        defn_a = AgentDefinition(
            steps={"run": StepMeta(spec_types=frozenset({TSpec}), result_types=frozenset({Val}))},
            type_registry={"Val": Val, "TSpec": TSpec},
            create_instance=lambda sl: AgentInstance(call_step=handler_a),
            entry_step="run",
        )
        defn_b = AgentDefinition(
            steps={"run": StepMeta(spec_types=frozenset({TSpec}), result_types=frozenset({Val}))},
            type_registry={"Val": Val, "TSpec": TSpec},
            create_instance=lambda sl: AgentInstance(call_step=handler_b),
            entry_step="run",
        )

        async def handler_a(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            assert isinstance(spec, TSpec)
            return Val(v=f"a:{spec.msg}")

        async def handler_b(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            assert isinstance(spec, TSpec)
            return Val(v=f"b:{spec.msg}")

        # Should not raise ValueError — same types in different agents are fine
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn_a, "b": defn_b}, storage=storage)
        result = await runtime.run(agent="a", spec=TSpec(msg="hello"))
        assert isinstance(result, Val)
        assert result.v == "a:hello"

    async def test_resume_deserializes_per_agent_types(self) -> None:
        """Resume correctly deserializes each agent's types using per-agent registries."""

        async def parent(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[CallAgent(agent="c", spec=TSpec(msg="test"))],
                    then="join",
                )
            assert child_outputs is not None
            return Val(v=child_outputs[0].result.v)  # type: ignore[union-attr]

        async def child(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            assert isinstance(spec, TSpec)
            return Val(v=spec.msg)

        storage = InMemorySessionStorage()
        parent_defn = AgentDefinition(
            steps={},
            type_registry={"Val": Val, "TSpec": TSpec},
            create_instance=lambda sl: AgentInstance(call_step=parent),
            entry_step="start",
        )
        child_defn = AgentDefinition(
            steps={},
            type_registry={"Val": Val, "TSpec": TSpec},
            create_instance=lambda sl: AgentInstance(call_step=child),
            entry_step="work",
        )
        runtime = AgentRuntime(agents={"p": parent_defn, "c": child_defn}, storage=storage)
        result = await runtime.run(agent="p")
        assert isinstance(result, Val)
        assert result.v == "test"


# -- Slot-dependent tests ------------------------------------------------------


def _defn_with_counter(
    handler_factory: Any,
    type_registry: dict[str, type] | None = None,
    *,
    entry_step: str = "start",
) -> AgentDefinition:
    """Build an AgentDefinition with a 'counter' Scalar[int] slot."""

    def create(sl: ServiceLocator) -> AgentInstance:
        store: AgentStore = sl.services[AgentStore]
        counter = store.slot(Scalar[int], "counter")
        return handler_factory(counter, store)

    return AgentDefinition(
        steps={},
        type_registry=type_registry or _TYPE_REGISTRY,
        create_instance=create,
        entry_step=entry_step,
    )


class TestScopeFlushMidStep:
    async def test_flush_saves_node_state(self) -> None:
        flush_calls_before: list[tuple[str, Any]] = []

        def make_handler(counter: Any, store: AgentStore) -> AgentInstance:
            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                counter.set(counter.get(0) + 1)
                await store.flush()
                flush_calls_before.extend(storage.save_node_state_calls[:])
                counter.set(counter.get(0) + 1)
                return Val(v=str(counter.get(0)))

            return AgentInstance(call_step=handler)

        storage = TrackingSessionStorage()
        defn = _defn_with_counter(make_handler)
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        result = await runtime.run(agent="a", storage_key="main")

        assert isinstance(result, Val)
        assert result.v == "2"

        # flush mid-step should have saved counter=1
        # First call is __meta (run counter), second is the actual flush
        assert len(flush_calls_before) == 2
        assert flush_calls_before[0] == ("__meta", ChangeSet(scalars={"run_counter": 1}, appends={}))
        assert flush_calls_before[1] == ("main", ChangeSet(scalars={"counter": 1}, appends={}))


class TestNodeStatePersistsAfterCompletion:
    async def test_node_state_persists_after_completion(self) -> None:
        def make_handler(counter: Any, store: AgentStore) -> AgentInstance:
            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                counter.set(counter.get(0) + 1)
                return Val(v=str(counter.get(0)))

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        await runtime.run(agent="a", storage_key="main")

        # Execution cleared, but node state persists
        assert await storage.has_execution() is False
        node_state = await storage.load_node_state("main")
        assert node_state is not None
        assert node_state["counter"] == 1


class TestCrossRunContinuity:
    async def test_state_restored_in_new_run_with_same_storage_key(self) -> None:
        def make_handler(counter: Any, store: AgentStore) -> AgentInstance:
            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                counter.set(counter.get(0) + 1)
                return Val(v=str(counter.get(0)))

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        storage = InMemorySessionStorage()

        # First run
        runtime1 = AgentRuntime(agents={"a": defn}, storage=storage)
        r1 = await runtime1.run(agent="a", storage_key="main")
        assert isinstance(r1, Val)
        assert r1.v == "1"

        # Second run with same storage_key — counter should start from 1
        runtime2 = AgentRuntime(agents={"a": defn}, storage=storage)
        r2 = await runtime2.run(agent="a", storage_key="main")
        assert isinstance(r2, Val)
        assert r2.v == "2"


class TestDefaultStorageKey:
    async def test_root_defaults_to_storage_key_root(self) -> None:
        def make_handler(counter: Any, store: AgentStore) -> AgentInstance:
            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                counter.set(counter.get(0) + 1)
                return Val(v=str(counter.get(0)))

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        await runtime.run(agent="a")  # default storage_key="root"

        # State saved under default storage_key "root"
        node_state = await storage.load_node_state("root")
        assert node_state is not None
        assert node_state["counter"] == 1


class TestChildStatePersistsAfterPropagation:
    async def test_child_dirty_state_saved_before_propagation_prunes_children(self) -> None:
        """When a child completes, its dirty state must be saved before
        __propagate_completions removes it from the tree.

        Bug: __propagate_completions sets node.children = None inside advance(),
        BEFORE __save_dirty_scopes runs. So the child's dirty changes are lost.
        """

        def create_parent(sl: ServiceLocator) -> AgentInstance:
            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                if tag == "start":
                    return Spawn(
                        children=[CallAgent(agent="child", storage_key="child-state")],
                        then="join",
                    )
                assert child_outputs is not None
                return child_outputs[0].result

            return AgentInstance(call_step=handler)

        def create_child(sl: ServiceLocator) -> AgentInstance:
            store: AgentStore = sl.services[AgentStore]
            items = store.slot(AppendOnlyList[str], "items")

            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                items.append("hello")
                items.append("world")
                return Val(v="done")

            return AgentInstance(call_step=handler)

        parent_defn = AgentDefinition(
            steps={},
            type_registry=_TYPE_REGISTRY,
            create_instance=create_parent,
            entry_step="start",
        )
        child_defn = AgentDefinition(
            steps={},
            type_registry=_TYPE_REGISTRY,
            create_instance=create_child,
            entry_step="work",
        )

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(
            agents={"parent": parent_defn, "child": child_defn},
            storage=storage,
        )
        result = await runtime.run(agent="parent", storage_key="parent-state")
        assert isinstance(result, Val)
        assert result.v == "done"

        # The child's items should have been persisted
        child_state = await storage.load_node_state("child-state")
        assert child_state is not None, "Child state was not persisted — dirty scopes lost during propagation"
        assert child_state["items"] == ["hello", "world"]


class TestResumeEndToEnd:
    async def test_resume_continues_after_simulated_crash(self) -> None:
        """Run an agent that takes 2 steps. After the first step,
        simulate a crash by creating a new runtime with the same storage
        and calling resume()."""
        call_log: list[str] = []

        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            call_log.append(tag)
            if tag == "start":
                return GotoStep(step="finish")
            return Val(v="resumed")

        storage = InMemorySessionStorage()

        # First runtime — run until first advance saves snapshot, then "crash"
        runtime1 = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        result = await runtime1.run(agent="a")
        # The agent completes in a single run (2 ticks), but the snapshot
        # is saved after each advance. For a true mid-run crash test,
        # we need an agent that doesn't complete immediately.
        assert isinstance(result, Val)
        assert result.v == "resumed"

    async def test_resume_with_spawn_continues_from_waiting_children(self) -> None:
        """Resume when root is WAITING_CHILDREN with children in the snapshot."""
        step_count = 0

        async def parent_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            nonlocal step_count
            step_count += 1
            if tag == "start":
                return Spawn(
                    children=[CallAgent(agent="child", storage_key="c1")],
                    then="join",
                )
            assert child_outputs is not None
            return child_outputs[0].result

        async def child_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="child_done")

        storage = InMemorySessionStorage()
        agents: dict[str, Any] = {
            "parent": _defn(parent_handler),
            "child": _defn(child_handler),
        }
        runtime1 = AgentRuntime(agents=agents, storage=storage)
        result = await runtime1.run(agent="parent")
        assert isinstance(result, Val)
        assert result.v == "child_done"

        # Verify snapshot was cleared (successful completion)
        assert await storage.has_execution() is False

    async def test_resume_restores_state_from_storage(self) -> None:
        """Resume picks up persisted scalar state from a previous run."""

        def create(sl: ServiceLocator) -> AgentInstance:
            store: AgentStore = sl.services[AgentStore]
            counter = store.slot(Scalar[int], "counter")

            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                current = counter.get(0)
                counter.set(current + 1)
                if current < 1:
                    return GotoStep(step="again", storage_key="root")
                return Val(v=f"count={counter.get(0)}")

            return AgentInstance(call_step=handler)

        defn = AgentDefinition(
            steps={},
            type_registry=_TYPE_REGISTRY,
            create_instance=create,
            entry_step="start",
        )
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        result = await runtime.run(agent="a", storage_key="root")
        assert isinstance(result, Val)
        assert result.v == "count=2"

        # State persisted — verify via storage
        node_state = await storage.load_node_state("root")
        assert node_state is not None
        assert node_state["counter"] == 2


class TestRegisterType:
    async def test_register_type_persists_and_restores(self) -> None:
        """Types in type_registry persist and restore correctly."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CustomData:
            name: str
            value: int

        def create(sl: ServiceLocator) -> AgentInstance:
            store: AgentStore = sl.services[AgentStore]
            data = store.slot(Scalar[CustomData | None], "data")

            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                if data.get(None) is None:
                    data.set(CustomData(name="test", value=42))
                    return GotoStep(step="check")
                current = data.get(None)
                assert isinstance(current, CustomData)
                return Val(v=f"{current.name}:{current.value}")

            return AgentInstance(call_step=handler)

        defn = AgentDefinition(
            steps={},
            type_registry={**_TYPE_REGISTRY, "CustomData": CustomData},
            create_instance=create,
            entry_step="start",
        )
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        result = await runtime.run(agent="a", storage_key="main")
        assert isinstance(result, Val)
        assert result.v == "test:42"


class TestSlotTypeAutoDiscovery:
    async def test_slot_dataclass_types_serialized_without_manual_registration(self) -> None:
        """Dataclass types used in slot() are automatically discovered
        and registered in the type registry — no manual registration needed."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Item:
            name: str
            value: int

        def create(sl: ServiceLocator) -> AgentInstance:
            store: AgentStore = sl.services[AgentStore]
            items = store.slot(AppendOnlyList[Item], "items")

            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                items.append(Item(name="a", value=1))
                items.append(Item(name="b", value=2))
                return Val(v="ok")

            return AgentInstance(call_step=handler)

        # Note: Item is NOT in type_registry — it should be auto-discovered from slot()
        defn = AgentDefinition(
            steps={},
            type_registry=dict(_TYPE_REGISTRY),
            create_instance=create,
            entry_step="start",
        )
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        result = await runtime.run(agent="a", storage_key="main")
        assert isinstance(result, Val)
        assert result.v == "ok"

        node_state = await storage.load_node_state("main")
        assert node_state is not None
        assert len(node_state["items"]) == 2
        assert (
            node_state["items"][0]["__type__"]
            == "TestSlotTypeAutoDiscovery.test_slot_dataclass_types_serialized_without_manual_registration.<locals>.Item"
        )

    async def test_slot_dataclass_flush_mid_step(self) -> None:
        """Slot types are available for serialization during flush() mid-step."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Progress:
            stage: str

        def create(sl: ServiceLocator) -> AgentInstance:
            store: AgentStore = sl.services[AgentStore]
            progress = store.slot(Scalar[Progress], "progress")

            async def handler(
                tag: str,
                spec: Any = None,
                child_outputs: list[ChildOutput] | None = None,
                agent_spec: Any = None,
            ) -> Any:
                progress.set(Progress(stage="halfway"))
                await store.flush()
                progress.set(Progress(stage="done"))
                return Val(v="ok")

            return AgentInstance(call_step=handler)

        defn = AgentDefinition(
            steps={},
            type_registry=dict(_TYPE_REGISTRY),
            create_instance=create,
            entry_step="start",
        )
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        result = await runtime.run(agent="a", storage_key="main")
        assert isinstance(result, Val)

        node_state = await storage.load_node_state("main")
        assert node_state is not None
        assert node_state["progress"]["__data__"]["stage"] == "done"


class TestSpawnTreePersistence:
    async def test_spawn_tree_serialization_roundtrip(self) -> None:
        """spawn_tree is serialized in the snapshot and restored on resume."""
        from flowra.runtime.execution import (
            SpawnTreeAll,
            SpawnTreeAny,
            SpawnTreeLeaf,
            SpawnTreeN,
            deserialize_spawn_tree,
            serialize_spawn_tree,
        )

        tree = SpawnTreeAny(
            nodes=(
                SpawnTreeAll(nodes=(SpawnTreeLeaf(child_index=0), SpawnTreeLeaf(child_index=1))),
                SpawnTreeN(nodes=(SpawnTreeLeaf(child_index=2), SpawnTreeLeaf(child_index=3)), n=1),
            )
        )
        data = serialize_spawn_tree(tree)
        restored = deserialize_spawn_tree(data)
        assert restored == tree

    async def test_resume_when_any_completes_after_crash(self) -> None:
        """Resume a WhenAny spawn where one child completed before crash."""
        from flowra.agent import WhenAny

        async def fast_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return Val(v="fast_done")

        async def slow_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            from flowra.agent.interrupt_token import InterruptedError

            raise InterruptedError

        async def parent_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    WhenAny(
                        CallAgent(agent="fast", tag="fast", storage_key="fast_key"),
                        CallAgent(agent="slow", tag="slow", storage_key="slow_key"),
                    ),
                    then="join",
                )
            assert child_outputs is not None
            return child_outputs[0].result

        storage = InMemorySessionStorage()
        agents: dict[str, Any] = {
            "parent": _defn(parent_handler),
            "fast": _defn(fast_handler, entry_step="run"),
            "slow": _defn(slow_handler, entry_step="run"),
        }

        runtime = AgentRuntime(agents=agents, storage=storage)
        result = await runtime.run(agent="parent")
        assert isinstance(result, Val)
        assert result.v == "fast_done"
