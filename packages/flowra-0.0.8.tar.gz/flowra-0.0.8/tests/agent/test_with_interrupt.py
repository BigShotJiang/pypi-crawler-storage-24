import asyncio
from collections.abc import AsyncIterator

import pytest

from flowra.agent import InterruptToken, with_interrupt
from flowra.agent.interrupt_token import InterruptedError


class _InterruptTokenImpl(InterruptToken):
    __slots__ = ("__event", "__interrupted")

    def __init__(self) -> None:
        self.__interrupted = False
        self.__event = asyncio.Event()

    @property
    def interrupted(self) -> bool:
        return self.__interrupted

    async def wait(self) -> None:
        await self.__event.wait()

    def set(self) -> None:
        self.__interrupted = True
        self.__event.set()


class InterruptTokenSource:
    __slots__ = ("__token",)

    def __init__(self) -> None:
        self.__token = _InterruptTokenImpl()

    @property
    def token(self) -> InterruptToken:
        return self.__token

    def interrupt(self) -> None:
        self.__token.set()


async def _items(*values: int) -> AsyncIterator[int]:
    for v in values:
        yield v


async def _slow_items(*values: int, delay: float = 0.5) -> AsyncIterator[int]:
    for v in values:
        await asyncio.sleep(delay)
        yield v


class TestWithInterrupt:
    async def test_no_interrupt_yields_all(self) -> None:
        """Without interrupt, all items are yielded."""
        source = InterruptTokenSource()
        result = [item async for item in with_interrupt(_items(1, 2, 3), source.token)]
        assert result == [1, 2, 3]

    async def test_already_interrupted_raises(self) -> None:
        """If token is already interrupted before iteration, raises Interrupted."""
        source = InterruptTokenSource()
        source.interrupt()
        with pytest.raises(InterruptedError):
            async for _ in with_interrupt(_items(1, 2, 3), source.token):
                pass

    async def test_interrupt_mid_iteration(self) -> None:
        """Interrupt during iteration raises Interrupted after current item."""
        source = InterruptTokenSource()
        received: list[int] = []

        with pytest.raises(InterruptedError):
            async for item in with_interrupt(_items(1, 2, 3, 4, 5), source.token):
                received.append(item)
                if item == 2:
                    source.interrupt()

        assert received == [1, 2]

    async def test_interrupt_while_waiting_for_next(self) -> None:
        """Interrupt fires while __anext__ is blocked — raises Interrupted immediately."""
        source = InterruptTokenSource()
        received: list[int] = []

        async def interrupt_after(delay: float) -> None:
            await asyncio.sleep(delay)
            source.interrupt()

        interrupt_task = asyncio.create_task(interrupt_after(0.05))

        with pytest.raises(InterruptedError):
            async for item in with_interrupt(_slow_items(1, 2, 3, delay=1.0), source.token):
                received.append(item)

        await interrupt_task
        # Should exit before any slow item arrives
        assert received == []

    async def test_interrupt_after_first_slow_item(self) -> None:
        """Interrupt fires after first item arrives but before second."""
        source = InterruptTokenSource()
        received: list[int] = []

        async def interrupt_after(delay: float) -> None:
            await asyncio.sleep(delay)
            source.interrupt()

        # First item at 0.1s, interrupt at 0.15s, second item at 0.2s
        interrupt_task = asyncio.create_task(interrupt_after(0.15))

        with pytest.raises(InterruptedError):
            async for item in with_interrupt(_slow_items(1, 2, 3, delay=0.1), source.token):
                received.append(item)

        await interrupt_task
        assert received == [1]

    async def test_empty_iterator(self) -> None:
        """Empty iterator completes normally."""
        source = InterruptTokenSource()
        result = [item async for item in with_interrupt(_items(), source.token)]
        assert result == []

    async def test_aclose_called_on_interrupt(self) -> None:
        """The underlying iterator's aclose() is called when interrupted."""
        closed = False

        async def tracked_items() -> AsyncIterator[int]:
            nonlocal closed
            try:
                yield 1
                yield 2
                yield 3
            finally:
                closed = True

        source = InterruptTokenSource()

        with pytest.raises(InterruptedError):
            async for item in with_interrupt(tracked_items(), source.token):
                if item == 1:
                    source.interrupt()

        assert closed

    async def test_aclose_called_on_normal_completion(self) -> None:
        """The underlying iterator's aclose() is called on normal completion."""
        closed = False

        async def tracked_items() -> AsyncIterator[int]:
            nonlocal closed
            try:
                yield 1
                yield 2
            finally:
                closed = True

        source = InterruptTokenSource()
        result = [item async for item in with_interrupt(tracked_items(), source.token)]

        assert result == [1, 2]
        assert closed

    async def test_works_with_async_generator(self) -> None:
        """Works correctly with async generator (most common case)."""
        source = InterruptTokenSource()

        async def gen() -> AsyncIterator[str]:
            yield "a"
            yield "b"
            yield "c"

        result = [item async for item in with_interrupt(gen(), source.token)]
        assert result == ["a", "b", "c"]

    async def test_exception_in_iterator_propagates(self) -> None:
        """Exceptions from the underlying iterator propagate normally."""

        async def failing_items() -> AsyncIterator[int]:
            yield 1
            raise ValueError("boom")

        source = InterruptTokenSource()
        received: list[int] = []

        try:
            async for item in with_interrupt(failing_items(), source.token):
                received.append(item)
        except ValueError as e:
            assert str(e) == "boom"

        assert received == [1]

    async def test_interrupt_stops_at_correct_item_in_fast_loop(self) -> None:
        """Interrupt mid-iteration raises Interrupted at the right point."""
        source = InterruptTokenSource()
        received: list[int] = []

        async def many_items() -> AsyncIterator[int]:
            for i in range(100):
                yield i

        with pytest.raises(InterruptedError):
            async for item in with_interrupt(many_items(), source.token):
                received.append(item)
                if item == 10:
                    source.interrupt()

        assert received == list(range(11))


class TestInterruptTokenCheck:
    def test_check_not_interrupted(self) -> None:
        """check() does nothing when not interrupted."""
        source = InterruptTokenSource()
        source.token.check()  # should not raise

    def test_check_interrupted(self) -> None:
        """check() raises Interrupted when token is interrupted."""
        source = InterruptTokenSource()
        source.interrupt()
        with pytest.raises(InterruptedError):
            source.token.check()
