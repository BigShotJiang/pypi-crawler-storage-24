import dataclasses

from flowra.agent import Agent, Event, HookContext, HookRegistry


@dataclasses.dataclass(slots=True, kw_only=True)
class SampleEvent:
    value: int
    extra: str = ""


@dataclasses.dataclass(slots=True, kw_only=True)
class OtherEvent:
    name: str


class TestHookRegistry:
    async def test_emit_no_handlers(self) -> None:
        registry = HookRegistry()
        result = await registry.emit(SampleEvent(value=42))
        assert result.value == 42

    async def test_sync_handler_called(self) -> None:
        received: list[Event[SampleEvent]] = []

        def handler(event: Event[SampleEvent]) -> None:
            received.append(event)

        registry = HookRegistry()
        registry.on(SampleEvent, handler)
        await registry.emit(SampleEvent(value=7))

        assert len(received) == 1
        assert received[0].data.value == 7

    async def test_async_handler_called(self) -> None:
        received: list[int] = []

        async def handler(event: Event[SampleEvent]) -> None:
            received.append(event.data.value)

        registry = HookRegistry()
        registry.on(SampleEvent, handler)
        await registry.emit(SampleEvent(value=99))

        assert received == [99]

    async def test_multiple_handlers_called_in_order(self) -> None:
        order: list[str] = []

        registry = HookRegistry()
        registry.on(SampleEvent, lambda e: order.append("first"))
        registry.on(SampleEvent, lambda e: order.append("second"))
        registry.on(SampleEvent, lambda e: order.append("third"))
        await registry.emit(SampleEvent(value=0))

        assert order == ["first", "second", "third"]

    async def test_prepend_handler(self) -> None:
        order: list[str] = []

        registry = HookRegistry()
        registry.on(SampleEvent, lambda e: order.append("first"))
        registry.on(SampleEvent, lambda e: order.append("prepended"), prepend=True)
        registry.on(SampleEvent, lambda e: order.append("last"))
        await registry.emit(SampleEvent(value=0))

        assert order == ["prepended", "first", "last"]

    async def test_has_handlers(self) -> None:
        registry = HookRegistry()
        assert not registry.has_handlers(SampleEvent)

        registry.on(SampleEvent, lambda e: None)
        assert registry.has_handlers(SampleEvent)
        assert not registry.has_handlers(OtherEvent)

    async def test_add_provider(self) -> None:
        calls: list[str] = []

        class MyProvider:
            def register_hooks(self, registry: HookRegistry) -> None:
                registry.on(SampleEvent, lambda e: calls.append("provider"))

        registry = HookRegistry()
        registry.add(MyProvider())
        await registry.emit(SampleEvent(value=1))

        assert calls == ["provider"]

    async def test_propagate_to(self) -> None:
        received: list[int] = []

        source = HookRegistry()
        target = HookRegistry()
        target.on(SampleEvent, lambda e: received.append(e.data.value))

        # Need a handler on source for the event type to be propagated
        source.on(SampleEvent, lambda e: None)
        source.propagate_to(target)
        await source.emit(SampleEvent(value=42))

        assert received == [42]

    async def test_propagate_to_with_only(self) -> None:
        sample_received: list[int] = []
        other_received: list[str] = []

        source = HookRegistry()
        target = HookRegistry()
        target.on(SampleEvent, lambda e: sample_received.append(e.data.value))
        target.on(OtherEvent, lambda e: other_received.append(e.data.name))

        source.on(SampleEvent, lambda e: None)
        source.on(OtherEvent, lambda e: None)
        source.propagate_to(target, only=[SampleEvent])

        await source.emit(SampleEvent(value=1))
        await source.emit(OtherEvent(name="test"))

        assert sample_received == [1]
        assert other_received == []

    async def test_propagate_to_with_exclude(self) -> None:
        sample_received: list[int] = []
        other_received: list[str] = []

        source = HookRegistry()
        target = HookRegistry()
        target.on(SampleEvent, lambda e: sample_received.append(e.data.value))
        target.on(OtherEvent, lambda e: other_received.append(e.data.name))

        source.on(SampleEvent, lambda e: None)
        source.on(OtherEvent, lambda e: None)
        source.propagate_to(target, exclude=[OtherEvent])

        await source.emit(SampleEvent(value=2))
        await source.emit(OtherEvent(name="excluded"))

        assert sample_received == [2]
        assert other_received == []

    async def test_handler_mutation_visible(self) -> None:
        def mutate(event: Event[SampleEvent]) -> None:
            event.data.extra = "mutated"

        registry = HookRegistry()
        registry.on(SampleEvent, mutate)
        result = await registry.emit(SampleEvent(value=1))

        assert result.extra == "mutated"

    async def test_context_stamped(self) -> None:
        context = HookContext(agent_type=Agent, agent_path="/root/test")
        received_contexts: list[HookContext | None] = []

        def handler(event: Event[SampleEvent]) -> None:
            received_contexts.append(event.context)

        registry = HookRegistry(context=context)
        registry.on(SampleEvent, handler)
        await registry.emit(SampleEvent(value=1))

        assert len(received_contexts) == 1
        assert received_contexts[0] is context
        assert received_contexts[0].agent_type is Agent  # type: ignore[union-attr]
        assert received_contexts[0].agent_path == "/root/test"  # type: ignore[union-attr]
