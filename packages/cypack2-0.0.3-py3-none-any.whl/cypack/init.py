# cypack/init.py
"""
   Copyright 2021 Philippe PRADOS

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
"""
import importlib
import importlib.abc as abc  # Never remove this import, else the importlib.abc can not be visible with Python 3.10
import importlib.util
import importlib.machinery
import sys
from typing import Optional, Iterable, Any, Set
import os

_DEBUG = os.environ.get("CYPACK_DEBUG_IMPORT", "0") not in ("0", "false", "False", "")
def _dprint(*a):
    if _DEBUG:
        print("[cypack]", *a)

class _CyPackMetaPathFinder(abc.MetaPathFinder):
    def __init__(self, name_filter: str, file: str, keep_modules: Set[str]):
        """
        自定义 MetaPathFinder, 用于找到和加载 Cython 编译的模块

        Parameters:
        - name_filter : str, 比如 "xensesdk."
        - file        : str, __compile__.so / .pyd 文件路径
        - keep_modules: set, 保持正常加载的模块（文件名不带后缀）
        """
        super().__init__()
        self._name_filter = name_filter
        self._file = file
        self._keep_modules = keep_modules

    # 注意：签名必须兼容 Python 3.12
    def find_spec(self, fullname, path=None, target=None, *args, **kwargs):
        # 不拦截 __compile__ 模块本身的导入，让文件系统去找正确的 .so
        if fullname.split(".")[-1] == "__compile__":
            return None

        last_name = fullname.split(".")[-1]
        if last_name in self._keep_modules:
            return None

        if fullname.startswith(self._name_filter):
            # ★ 不拦截普通 Python 包（目录 + __init__.py），让文件系统处理
            if path:
                for search_path in path:
                    pkg_init = os.path.join(search_path, last_name, "__init__.py")
                    if os.path.exists(pkg_init):
                        return None  # 是普通包，交给文件 finder

            loader = importlib.machinery.ExtensionFileLoader(fullname, self._file)
            spec = importlib.machinery.ModuleSpec(
                name=fullname, loader=loader, origin=self._file,
            )
            return spec
        return None

    # 兼容极老的 import 逻辑；3.12 仍会优先调用 find_spec
    def find_module(
        self,
        fullname: str,
        path: Optional[Iterable[str]] = None,
    ) -> Optional[importlib.machinery.ExtensionFileLoader]:
        spec = self.find_spec(fullname, path)
        if spec is not None:
            return spec.loader
        return None


_registered_prefix: Set[str] = set()


def init(module_name: str, keep_modules: Set[str]) -> None:
    module = importlib.import_module(module_name + ".__compile__")

    # 修改：用完整父包路径作为 prefix，而不是只用顶级包名
    prefix = module_name + "."

    # 修改：只有 exact 重复才跳过，允许更细粒度的子包 prefix 注册
    if prefix in _registered_prefix:
        return

    _registered_prefix.add(prefix)
    finder = _CyPackMetaPathFinder(prefix, module.__file__, keep_modules)
    # 修改：insert(0) 让后注册的（更具体的）finder 优先被检查
    sys.meta_path.insert(0, finder)

# 新增函数：供代理包直接用 .so 文件路径注册 finder，无需 __compile__ 占位模块
def init_with_file(module_prefix: str, compile_file: str, keep_modules: Set[str]) -> None:
    """为代理包注册 cypack finder，直接指定 __compile__.so 路径。"""
    prefix = module_prefix + "."
    if prefix in _registered_prefix:
        return
    _registered_prefix.add(prefix)
    finder = _CyPackMetaPathFinder(prefix, compile_file, keep_modules)
    sys.meta_path.insert(0, finder)