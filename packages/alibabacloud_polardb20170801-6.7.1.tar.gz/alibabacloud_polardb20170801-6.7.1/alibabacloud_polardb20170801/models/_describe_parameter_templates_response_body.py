# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_polardb20170801 import models as main_models
from darabonba.model import DaraModel

class DescribeParameterTemplatesResponseBody(DaraModel):
    def __init__(
        self,
        dbtype: str = None,
        dbversion: str = None,
        engine: str = None,
        parameter_count: str = None,
        parameters: main_models.DescribeParameterTemplatesResponseBodyParameters = None,
        request_id: str = None,
    ):
        # The type of the database engine.
        self.dbtype = dbtype
        # The version of the database engine.
        self.dbversion = dbversion
        # The database engine of the cluster.
        self.engine = engine
        # The number of parameters.
        self.parameter_count = parameter_count
        self.parameters = parameters
        # The request ID.
        self.request_id = request_id

    def validate(self):
        if self.parameters:
            self.parameters.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.dbtype is not None:
            result['DBType'] = self.dbtype

        if self.dbversion is not None:
            result['DBVersion'] = self.dbversion

        if self.engine is not None:
            result['Engine'] = self.engine

        if self.parameter_count is not None:
            result['ParameterCount'] = self.parameter_count

        if self.parameters is not None:
            result['Parameters'] = self.parameters.to_map()

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('DBType') is not None:
            self.dbtype = m.get('DBType')

        if m.get('DBVersion') is not None:
            self.dbversion = m.get('DBVersion')

        if m.get('Engine') is not None:
            self.engine = m.get('Engine')

        if m.get('ParameterCount') is not None:
            self.parameter_count = m.get('ParameterCount')

        if m.get('Parameters') is not None:
            temp_model = main_models.DescribeParameterTemplatesResponseBodyParameters()
            self.parameters = temp_model.from_map(m.get('Parameters'))

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

class DescribeParameterTemplatesResponseBodyParameters(DaraModel):
    def __init__(
        self,
        template_record: List[main_models.DescribeParameterTemplatesResponseBodyParametersTemplateRecord] = None,
    ):
        self.template_record = template_record

    def validate(self):
        if self.template_record:
            for v1 in self.template_record:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['TemplateRecord'] = []
        if self.template_record is not None:
            for k1 in self.template_record:
                result['TemplateRecord'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.template_record = []
        if m.get('TemplateRecord') is not None:
            for k1 in m.get('TemplateRecord'):
                temp_model = main_models.DescribeParameterTemplatesResponseBodyParametersTemplateRecord()
                self.template_record.append(temp_model.from_map(k1))

        return self

class DescribeParameterTemplatesResponseBodyParametersTemplateRecord(DaraModel):
    def __init__(
        self,
        checking_code: str = None,
        force_modify: str = None,
        force_restart: str = None,
        is_node_available: str = None,
        param_rely_rule: str = None,
        parameter_description: str = None,
        parameter_name: str = None,
        parameter_value: str = None,
    ):
        self.checking_code = checking_code
        self.force_modify = force_modify
        self.force_restart = force_restart
        self.is_node_available = is_node_available
        self.param_rely_rule = param_rely_rule
        self.parameter_description = parameter_description
        self.parameter_name = parameter_name
        self.parameter_value = parameter_value

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.checking_code is not None:
            result['CheckingCode'] = self.checking_code

        if self.force_modify is not None:
            result['ForceModify'] = self.force_modify

        if self.force_restart is not None:
            result['ForceRestart'] = self.force_restart

        if self.is_node_available is not None:
            result['IsNodeAvailable'] = self.is_node_available

        if self.param_rely_rule is not None:
            result['ParamRelyRule'] = self.param_rely_rule

        if self.parameter_description is not None:
            result['ParameterDescription'] = self.parameter_description

        if self.parameter_name is not None:
            result['ParameterName'] = self.parameter_name

        if self.parameter_value is not None:
            result['ParameterValue'] = self.parameter_value

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CheckingCode') is not None:
            self.checking_code = m.get('CheckingCode')

        if m.get('ForceModify') is not None:
            self.force_modify = m.get('ForceModify')

        if m.get('ForceRestart') is not None:
            self.force_restart = m.get('ForceRestart')

        if m.get('IsNodeAvailable') is not None:
            self.is_node_available = m.get('IsNodeAvailable')

        if m.get('ParamRelyRule') is not None:
            self.param_rely_rule = m.get('ParamRelyRule')

        if m.get('ParameterDescription') is not None:
            self.parameter_description = m.get('ParameterDescription')

        if m.get('ParameterName') is not None:
            self.parameter_name = m.get('ParameterName')

        if m.get('ParameterValue') is not None:
            self.parameter_value = m.get('ParameterValue')

        return self

