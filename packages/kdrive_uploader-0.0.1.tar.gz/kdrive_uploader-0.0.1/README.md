# kDrive Uploader

A small tool to programmatically upload files to [kDrive drop boxes](https://www.infomaniak.com/en/support/faq/2386/manage-kdrive-drop-boxes), used by the author as a poor man's backup solution.

## Quickstart

Run directly using `uv`:

```bash
uvx kdrive-uploader 0000000/00000000-0000-0000-0000-000000000000 myfile.zip
```

Or first install with `pip` then run:

```bash
pip install kdrive-uploader
kdrive-uploader 0000000/00000000-0000-0000-0000-000000000000 myfile.zip
```

The link can either be just the last part containing the ids as above or a full kDrive drop box link (in the shape `https://kdrive.infomaniak.com/app/collaborate/0000000/00000000-0000-0000-0000-000000000000`).

## Manual

```
Usage: kdrive-uploader [OPTIONS] KDRIVE_SHARE_LINK FILE

╭─ Arguments ────────────────────────────────────────────────────────────────╮
│ *    kdrive_share_link      TEXT  [required]                               │
│ *    file                   PATH  [required]                               │
╰────────────────────────────────────────────────────────────────────────────╯
╭─ Options ──────────────────────────────────────────────────────────────────╮
│ --first-name        TEXT  [default: kdrive_uploader]                       │
│ --last-name         TEXT  [default: kdrive_uploader]                       │
│ --email             TEXT  [default: kdrive_uploader@ik.me]                 │
│ --help                    Show this message and exit.                      │
╰────────────────────────────────────────────────────────────────────────────╯
```
