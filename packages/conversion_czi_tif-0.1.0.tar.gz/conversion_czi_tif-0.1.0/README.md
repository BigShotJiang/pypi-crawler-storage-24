# Conversion CZI to TIFF

A Python package for converting CZI files to TIFF format.

## Installation

```bash
pip install .

