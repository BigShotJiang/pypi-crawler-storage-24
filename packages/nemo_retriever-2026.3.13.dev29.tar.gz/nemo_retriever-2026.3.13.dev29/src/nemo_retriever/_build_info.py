"""Build metadata written by CI before packaging."""

BUILD_GIT_SHA = "2b3488c6e7c63b57a7be35f7226a7dc6189a80b1"
BUILD_DATE = "2026-03-13T23:42:55Z"
