"""Python API client for birdfyi.com."""

__version__ = "0.1.0"
