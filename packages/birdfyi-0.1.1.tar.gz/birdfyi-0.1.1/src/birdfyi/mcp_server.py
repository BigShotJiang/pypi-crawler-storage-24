"""MCP server for birdfyi — AI assistant tools for birdfyi.com.

Run: uvx --from "birdfyi[mcp]" python -m birdfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("BirdFYI")


@mcp.tool()
def list_birds(limit: int = 20, offset: int = 0) -> str:
    """List birds from birdfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from birdfyi.api import BirdFYI

    with BirdFYI() as api:
        data = api.list_birds(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No birds found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_bird(slug: str) -> str:
    """Get detailed information about a specific bird.

    Args:
        slug: URL slug identifier for the bird.
    """
    from birdfyi.api import BirdFYI

    with BirdFYI() as api:
        data = api.get_bird(slug)
        return str(data)


@mcp.tool()
def list_families(limit: int = 20, offset: int = 0) -> str:
    """List families from birdfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from birdfyi.api import BirdFYI

    with BirdFYI() as api:
        data = api.list_families(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No families found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_bird(query: str) -> str:
    """Search birdfyi.com for bird species, families, and conservation status.

    Args:
        query: Search query string.
    """
    from birdfyi.api import BirdFYI

    with BirdFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
