"""Command-line interface for birdfyi."""

from __future__ import annotations

import json

import typer

from birdfyi.api import BirdFYI

app = typer.Typer(help="BirdFYI — Bird species encyclopedia API client.")


@app.command()
def search(query: str) -> None:
    """Search birdfyi.com."""
    with BirdFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
