"""
Use :class:`screenmirrored`.
"""