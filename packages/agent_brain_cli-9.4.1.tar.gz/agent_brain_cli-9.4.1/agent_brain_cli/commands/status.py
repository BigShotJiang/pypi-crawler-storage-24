"""Status command for checking server health."""

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..client import ConnectionError, DocServeClient, ServerError
from ..config import get_server_url

console = Console()


@click.command("status")
@click.option(
    "--url",
    envvar="AGENT_BRAIN_URL",
    default=None,
    help="Agent Brain server URL (default: from config or http://127.0.0.1:8000)",
)
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
@click.option("--verbose", "-v", is_flag=True, help="Show additional detail")
def status_command(url: str | None, json_output: bool, verbose: bool) -> None:
    """Check Agent Brain server status and health."""
    resolved_url = url or get_server_url()
    try:
        with DocServeClient(base_url=resolved_url) as client:
            health = client.health()
            indexing = client.status()

            if json_output:
                import json

                output = {
                    "health": {
                        "status": health.status,
                        "message": health.message,
                        "version": health.version,
                    },
                    "indexing": {
                        "total_documents": indexing.total_documents,
                        "total_chunks": indexing.total_chunks,
                        "indexing_in_progress": indexing.indexing_in_progress,
                        "progress_percent": indexing.progress_percent,
                        "indexed_folders": indexing.indexed_folders,
                        "file_watcher": indexing.file_watcher
                        or {"running": False, "watched_folders": 0},
                        "embedding_cache": indexing.embedding_cache,
                    },
                }
                click.echo(json.dumps(output, indent=2))
                return

            # Determine status color
            status_color = {
                "healthy": "green",
                "indexing": "yellow",
                "degraded": "orange3",
                "unhealthy": "red",
            }.get(health.status, "white")

            # Create status panel
            status_text = f"[bold {status_color}]{health.status.upper()}[/]"
            if health.message:
                status_text += f"\n{health.message}"

            console.print(
                Panel(status_text, title="Server Status", border_style=status_color)
            )

            # Create info table
            table = Table(show_header=True, header_style="bold cyan")
            table.add_column("Metric", style="dim")
            table.add_column("Value")

            table.add_row("Server Version", health.version)
            table.add_row("Total Documents", str(indexing.total_documents))
            table.add_row("Total Chunks", str(indexing.total_chunks))

            if indexing.indexing_in_progress:
                table.add_row(
                    "Indexing Progress", f"[yellow]{indexing.progress_percent:.1f}%[/]"
                )
                if indexing.current_job_id:
                    table.add_row("Current Job", indexing.current_job_id)
            else:
                table.add_row("Indexing", "[green]Idle[/]")

            if indexing.indexed_folders:
                table.add_row(
                    "Indexed Folders",
                    "\n".join(indexing.indexed_folders[:5])
                    + (
                        f"\n... and {len(indexing.indexed_folders) - 5} more"
                        if len(indexing.indexed_folders) > 5
                        else ""
                    ),
                )

            if indexing.last_indexed_at:
                table.add_row("Last Indexed", indexing.last_indexed_at)

            file_watcher = indexing.file_watcher or {}
            if file_watcher:
                running = bool(file_watcher.get("running", False))
                watched_folders = int(file_watcher.get("watched_folders", 0))
                watcher_status = "running" if running else "stopped"
                table.add_row(
                    "File Watcher",
                    f"{watcher_status} ({watched_folders} watched folder(s))",
                )

            # Show embedding cache status if available (Phase 16)
            embedding_cache = indexing.embedding_cache
            if embedding_cache:
                entry_count = int(embedding_cache.get("entry_count", 0))
                hit_rate = float(embedding_cache.get("hit_rate", 0.0))
                hits = int(embedding_cache.get("hits", 0))
                misses = int(embedding_cache.get("misses", 0))
                table.add_row(
                    "Embedding Cache",
                    f"{entry_count:,} entries, {hit_rate:.1%} hit rate "
                    f"({hits:,} hits, {misses:,} misses)",
                )
                if verbose:
                    mem_entries = int(embedding_cache.get("mem_entries", 0))
                    size_bytes = int(embedding_cache.get("size_bytes", 0))
                    size_mb = size_bytes / (1024 * 1024) if size_bytes else 0.0
                    table.add_row("  Memory Entries", f"{mem_entries:,}")
                    table.add_row("  Cache Size", f"{size_mb:.2f} MB")

            # Show graph index status if available (Feature 113)
            graph_status = getattr(indexing, "graph_index", None)
            if graph_status:
                if graph_status.get("enabled"):
                    entities = graph_status.get("entity_count", 0)
                    rels = graph_status.get("relationship_count", 0)
                    table.add_row(
                        "Graph Index",
                        f"[green]Enabled[/] - {entities} entities, {rels} rels",
                    )
                else:
                    table.add_row("Graph Index", "[dim]Disabled[/]")

            console.print(table)

    except ConnectionError as e:
        if json_output:
            import json

            click.echo(json.dumps({"error": str(e)}))
        else:
            console.print(f"[red]Connection Error:[/] {e}")
        raise SystemExit(1) from e

    except ServerError as e:
        if json_output:
            import json

            click.echo(json.dumps({"error": str(e), "detail": e.detail}))
        else:
            console.print(f"[red]Server Error ({e.status_code}):[/] {e.detail}")
        raise SystemExit(1) from e
