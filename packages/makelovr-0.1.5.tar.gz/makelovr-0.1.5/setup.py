from setuptools import find_packages, setup

setup(
    name="makelovr",
    version="0.1.5",
    author="Zayfire Studios",
    description="Distribution tool for LÖVR games",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/zayfire/makelovr",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "requests",
    ],
    entry_points={"console_scripts": ["makelovr=makelovr.cli:main"]},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
)
