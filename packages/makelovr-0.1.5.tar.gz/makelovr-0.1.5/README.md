# makelövr

A distribution tool for LÖVR games.

## Install

```bash
pip install makelovr
```

## Usage

### Initialize a project:

```bash
makelovr init
```

### Build the game:

```bash
makelovr build
```
