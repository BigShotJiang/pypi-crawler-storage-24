import importlib.resources as resources
import os
import shutil


def init_project():
    os.makedirs("assets", exist_ok=True)

    main_template = resources.files("makelovr.templates") / "main.lua"
    conf_template = resources.files("makelovr.templates") / "conf.lua"

    with resources.as_file(main_template) as src:
        shutil.copy(src, "main.lua")

    with resources.as_file(conf_template) as src:
        shutil.copy(src, "conf.lua")

    if not os.path.exists("makelovr.toml"):
        with open("makelovr.toml", "w") as f:
            f.write(
                """name = "MyLovrGame"
version = "0.1.0"
author = "Your Name"

lovr_version = "0.18.0"

default_targets = ["win64","linux","macos"]

build_directory = "build"
"""
            )

    print("Project initialized!")
