import os
import zipfile


def make_lovr(project_dir, output):
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(project_dir):
            for f in files:
                full = os.path.join(root, f)

                if ".git" in full or "build" in full:
                    continue

                arc = os.path.relpath(full, project_dir)
                z.write(full, arc)
