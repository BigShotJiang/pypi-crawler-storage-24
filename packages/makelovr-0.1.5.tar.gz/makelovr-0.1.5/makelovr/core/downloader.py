import io
import os
import zipfile
from pathlib import Path

import requests

BASE = "https://github.com/bjornbytes/lovr/releases/download"

CACHE_DIR = Path.home() / ".cache" / "makelovr"


def download_lovr(version, platform, outdir):

    cache_path = CACHE_DIR / f"lovr-{version}-{platform}"

    if cache_path.exists():
        print("Using cached LÖVR:", cache_path)
        copy_tree(cache_path, outdir)
        return

    os.makedirs(outdir, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)

    if platform == "win64":
        file = f"lovr-v{version}-win64.zip"
    elif platform == "linux":
        file = f"lovr-v{version}-x86_64.AppImage"
    elif platform == "macos":
        file = f"lovr-v{version}.app.zip"
    elif platform == "android":
        file = f"lovr-v{version}.apk.zip"
    else:
        raise OSError(f"Unvalid platform {platform}")

    url = f"{BASE}/v{version}/{file}"

    print("Downloading:", url)

    r = requests.get(url, allow_redirects=True)

    if r.status_code != 200:
        raise RuntimeError(f"Download failed: {r.status_code}")

    if file.endswith(".zip"):

        if not r.content.startswith(b"PK"):
            raise RuntimeError("Download did not return a valid zip file")

        z = zipfile.ZipFile(io.BytesIO(r.content))
        z.extractall(outdir)
        z.extractall(cache_path)

    else:
        out = Path(outdir) / file
        cache = cache_path / file

        os.makedirs(cache_path, exist_ok=True)

        with open(out, "wb") as f:
            f.write(r.content)

        with open(cache, "wb") as f:
            f.write(r.content)


def copy_tree(src, dst):
    import shutil

    shutil.copytree(src, dst, dirs_exist_ok=True)
