import os

from PIL import Image


def make_ico(icon, out):
    img = Image.open(icon)
    img.save(out, format="ICO", sizes=[(256, 256)])


def make_icns(icon, out):
    img = Image.open(icon)
    img.save(out, format="ICNS")
