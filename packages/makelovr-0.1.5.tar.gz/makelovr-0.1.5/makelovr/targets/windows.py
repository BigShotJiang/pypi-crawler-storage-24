import os
import shutil

from ..core.archive import make_lovr
from ..core.downloader import download_lovr


def build_windows(config):

    build = config["build_directory"]
    name = config["name"]
    version = config["lovr_version"]

    os.makedirs(build, exist_ok=True)

    lovr_archive = f"{build}/{name}.lovr"
    make_lovr(".", lovr_archive)

    engine_dir = f"{build}/engine-win"
    download_lovr(version, "win64", engine_dir)

    exe = f"{engine_dir}/lovr.exe"
    out = f"{build}/{name}.exe"

    with open(out, "wb") as w:
        w.write(open(exe, "rb").read())
        w.write(open(lovr_archive, "rb").read())

    # copy DLLs
    for file in os.listdir(engine_dir):
        if file.endswith(".dll"):
            shutil.copy(
                os.path.join(engine_dir, file),
                os.path.join(build, file),
            )

    print("Windows build:", out)
