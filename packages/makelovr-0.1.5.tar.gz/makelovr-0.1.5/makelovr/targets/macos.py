import os
import shutil

from ..core.archive import make_lovr
from ..core.downloader import download_lovr


def build_macos(config):
    build = config["build_directory"]
    name = config["name"]
    version = config["lovr_version"]

    lovr_archive = f"{build}/{name}.lovr"

    make_lovr(".", lovr_archive)

    engine_dir = f"{build}/engine-mac"

    download_lovr(version, "macos", engine_dir)

    app = f"{engine_dir}/lovr.app"

    resources = f"{app}/Contents/Resources"

    shutil.copy(lovr_archive, f"{resources}/{name}.lovr")

    new_app = f"{build}/{name}.app"

    shutil.move(app, new_app)

    print("macOS app:", new_app)
