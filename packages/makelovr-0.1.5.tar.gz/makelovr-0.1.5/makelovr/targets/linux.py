import os
import shutil

from ..core.archive import make_lovr
from ..core.downloader import download_lovr


def build_linux(config):

    build = config["build_directory"]
    name = config["name"]
    version = config["lovr_version"]

    lovr_archive = f"{build}/{name}.lovr"
    make_lovr(".", lovr_archive)

    engine_dir = f"{build}/engine-linux"
    download_lovr(version, "linux", engine_dir)

    appimage = next(f for f in os.listdir(engine_dir) if f.endswith(".AppImage"))

    appimage_path = os.path.join(engine_dir, appimage)

    out = f"{build}/{name}.AppImage"

    with open(out, "wb") as w:
        w.write(open(appimage_path, "rb").read())
        w.write(open(lovr_archive, "rb").read())

    os.chmod(out, 0o755)

    print("Linux build:", out)
