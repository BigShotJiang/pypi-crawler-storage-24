function lovr.conf(t)
    t.window.title = "makelövr Game"
end
