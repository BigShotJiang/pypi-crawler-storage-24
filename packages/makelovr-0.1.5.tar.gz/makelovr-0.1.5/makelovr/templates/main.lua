function lovr.draw(pass)
    pass:text("Hello from makelövr!", 0, 1.7, -3, .5)
end
