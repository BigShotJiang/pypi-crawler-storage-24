import argparse
from core.config import load_config
from targets.windows import build_windows
from targets.linux import build_linux
from targets.macos import build_macos
from core.util import init_project


def main():
    parser = argparse.ArgumentParser(prog="makelovr")

    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("build")
    sub.add_parser("init")

    args = parser.parse_args()

    if args.cmd == "init":
        init_project()
        return

    config = load_config("makelovr.toml")

    for target in config["default_targets"]:
        if target == "win64":
            build_windows(config)

        if target == "linux":
            build_linux(config)

        if target == "macos":
            build_macos(config)


if __name__ == "__main__":
    main()
