"""Configuration management for Suno CLI."""

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

# Load .env file from project root
_env_path = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=_env_path)


@dataclass
class Settings:
    """Application settings loaded from environment variables."""

    # API Configuration
    api_base_url: str = field(
        default_factory=lambda: os.getenv("ACEDATACLOUD_API_BASE_URL", "https://api.acedata.cloud")
    )
    api_token: str = field(default_factory=lambda: os.getenv("ACEDATACLOUD_API_TOKEN", ""))

    # Default Model
    default_model: str = field(
        default_factory=lambda: os.getenv("SUNO_DEFAULT_MODEL", "chirp-v4-5")
    )

    # Request Configuration
    request_timeout: float = field(
        default_factory=lambda: float(os.getenv("SUNO_REQUEST_TIMEOUT", "1800"))
    )

    def validate(self) -> None:
        """Validate required settings."""
        if not self.api_token:
            raise ValueError(
                "ACEDATACLOUD_API_TOKEN environment variable is required. "
                "Get your token from https://platform.acedata.cloud"
            )

    @property
    def is_configured(self) -> bool:
        """Check if the API token is configured."""
        return bool(self.api_token)


settings = Settings()
