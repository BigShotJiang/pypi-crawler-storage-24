from sai_mcp.feishu_client import FeishuCloudClient
from sai_mcp.feishu_client import FeishuAPIError
from typing import Optional, Dict, List, Any


# ==================== 获取文档纯文本内容 ====================
async def get_document_raw_content(
        client: FeishuCloudClient,
        document_id: str,
        lang: Optional[int] = None
) -> Dict[str, Any]:
    """
    获取文档的纯文本内容。

    Args:
        client: 飞书云客户端
        document_id: 文档的唯一标识（必填），长度 27 字符
        lang: 指定返回的 MentionUser 即 @用户 的语言（可选）
              - 0：该用户的默认名称。如：@张敏
              - 1：该用户的英文名称。如：@Min Zhang
              - 2：暂不支持该枚举，使用时返回该用户的默认名称
              默认值：0

    Returns:
        包含文档纯文本内容的字典，包括 content 字段

    Raises:
        FeishuAPIError: 获取文档纯文本内容失败时抛出

    注意事项:
        - 接口频率限制为每秒 5 次，超过会返回 HTTP 400 及错误码 99991400
        - 调用此接口需要先确保有云文档的阅读权限
        - 纯文本内容大小超过限制时返回错误码 1770033
    """
    request_url = f"/docx/v1/documents/{document_id}/raw_content"
    params = {}

    if lang is not None:
        params["lang"] = lang

    data = await client.make_request("GET", request_url, params=params)

    return {
        "content": data.get("content", "")
    }


# ==================== 获取文档所有块 ====================
async def get_document_blocks(
        client: FeishuCloudClient,
        document_id: str,
        page_size: int = 500,
        page_token: Optional[str] = None,
        document_revision_id: int = -1,
        user_id_type: str = "open_id"
) -> Dict[str, Any]:
    """
    获取文档所有块的富文本内容并分页返回。

    Args:
        client: 飞书云客户端
        document_id: 文档的唯一标识
        page_size: 分页大小，默认500，最大500
        page_token: 分页标记，第一次请求不填，表示从头开始遍历
        document_revision_id: 查询的文档版本，-1 表示文档最新版本，默认-1
        user_id_type: 用户 ID 类型，可选值：open_id, union_id, user_id，默认 open_id

    Returns:
        包含文档块信息的字典，包括 items（块列表）、page_token（下次分页标记）、has_more（是否还有更多）

    Raises:
        FeishuAPIError: 获取文档块失败时抛出

    注意事项:
        - 接口频率限制为每秒 5 次，超过会返回 HTTP 400 及错误码 99991400
        - 调用此接口需要先确保有云文档的阅读权限
    """
    request_url = f"/docx/v1/documents/{document_id}/blocks"
    params = {
        "page_size": page_size,
        "document_revision_id": document_revision_id,
        "user_id_type": user_id_type
    }

    if page_token:
        params["page_token"] = page_token

    data = await client.make_request("GET", request_url, params=params)

    return {
        "items": data.get("items", []),
        "page_token": data.get("page_token", ""),
        "has_more": data.get("has_more", False)
    }


# ==================== 创建文档 ====================
async def create_document(
        client: FeishuCloudClient,
        title: Optional[str] = None,
        folder_token: Optional[str] = None
) -> Dict[str, Any]:
    """
    创建文档类型为 docx 的文档。

    Args:
        client: 飞书云客户端
        title: 文档标题，只支持纯文本，长度范围 1-800 字符（可选）
        folder_token: 指定文档所在文件夹的 Token，不传或传空表示根目录（可选）

    Returns:
        包含文档信息的字典，包括 document_id、revision_id、title 等字段

    Raises:
        FeishuAPIError: 创建文档失败时抛出

    注意事项:
        - 单个应用调用频率上限为每秒 3 次
        - 该接口仅支持指定文档标题，不支持带内容创建文档
        - 若使用 tenant_access_token，folder_token 仅可指定应用创建的文件夹
    """
    request_url = "/docx/v1/documents"
    payload = {}

    if title:
        payload["title"] = title
    if folder_token:
        payload["folder_token"] = folder_token

    data = await client.make_request("POST", request_url, json=payload)

    return data.get("document", {})


class BlockStyle:
    align: int
    done: bool
    folded: bool
    language: int
    wrap: bool
    background_color: str
    indentation_level: str


# ==================== 创建块 ====================
async def create_block(
        client: FeishuCloudClient,
        document_id: str,
        block_id: str,
        index: Optional[int] = None,
        content: Optional[Dict[str, Any]] = None,
        user_id_type: str = "open_id"
) -> Dict[str, Any]:
    """
    在指定块的子块列表中，新创建一批子块。

    Args:
        client: 飞书云客户端
        document_id: 文档的唯一标识
        block_id: 父块的 block_id，如果需要对文档树根节点创建子块，可将 document_id 填入此处
        index: 指定在某个块的子块列表中，新创建的子块的放置位置。索引的起始值为 0，表示子块列表的第一个位置
        content: 子块列表
        user_id_type: 用户 ID 类型，可选值：open_id, union_id, user_id

    Returns:
        包含新创建块信息的字典

    Raises:
        FeishuAPIError: 创建块失败时抛出

    注意事项:
        - 接口频率限制为每秒 3 次
        - 单篇文档并发编辑上限为每秒 3 次
    """
    request_url = f"/docx/v1/documents/{document_id}/blocks/{block_id}/children"
    params = {"user_id_type": user_id_type}

    payload = {}

    if content is not None:
        payload["children"] = [content]

    if index is not None:
        payload["index"] = index

    data = await client.make_request("POST", request_url, json=payload, params=params)

    return data.get("data", {})


text_style = {
    "type": "object",
    "description": "文本样式",
    "properties": {
        "align": {
            "type": "integer",
            "description": "对齐方式,可选值有：1-居左排版,2-居中排版,3-居右排版",
            "enum": [1, 2, 3]
        },
        "folded": {
            "type": "boolean",
            "description": "文本的折叠状态",
        },
        "indentation_level": {
            "type": "string",
            "description": "首行缩进级别：NoIndent-无缩进，OneLevelIndent-一级缩进",
            "enum": ["NoIndent", "OneLevelIndent"]
        }
    }
}

text_element_style = {
    "type": "object",
    "description": "文本局部样式",
    "properties": {
        "bold": {
            "type": "boolean",
            "description": "加粗",
        },
        "italic": {
            "type": "boolean",
            "description": "斜体",
        },
        "strikethrough": {
            "type": "boolean",
            "description": "删除线",
        },
        "underline": {
            "type": "boolean",
            "description": "下划线",
        },
        "inline_code": {
            "type": "boolean",
            "description": "inline 代码",
        },
        "background_color": {
            "type": "integer",
            "description": "背景色",
        },
        "text_color": {
            "type": "integer",
            "description": "字体颜色",
        },
        "link": {
            "type": "object",
            "description": "链接",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "超链接指向的 url (需要 url_encode)"
                }
            }
        }
    }
}

text_run = {
    "type": "object",
    "description": "文本元素",
    "properties": {
        "content": {
            "type": "string",
            "description": "文本内容。要实现文本内容的换行，你可以：在传入的文本内容中添加 \n 实现软换行（Soft Break，与在文档中通过操作 Shift + Enter 的效果一致），创建一个新的文本 Block，实现两个文本 Block 之间的硬换行（Hard Break，与在文档中通过操作 Enter 的效果一致）",
        },
        "text_element_style": text_element_style
    }
}

mention_user = {
    "type": "object",
    "description": "@用户",
    "properties": {
        "user_id": {
            "type": "string",
            "description": "用户OpenID"
        },
        "text_element_style": text_element_style
    }
}

mention_doc = {
    "type": "object",
    "description": "@文档",
    "properties": {
        "token": {
            "type": "string",
            "description": "云文档token"
        },
        "obj_type": {
            "type": "integer",
            "description": "云文档类型，可选值有：1-Doc，3-Sheet，8-Bitable，11-MindNote，12-File，15-Slide，16-Wiki，22-Docx",
            "enum": [1, 3, 8, 11, 12, 15, 16, 22]
        },
        "url": {
            "type": "云文档链接(需要url_encode)",
            "description": "云文档token"
        },
        "title": {
            "type": "string",
            "description": "文档标题"
        },
        "text_element_style": text_element_style
    }
}


# ==================== 创建文本块 ====================
async def create_text_block(
        client: FeishuCloudClient,
        document_id: str,
        block_id: str,
        content: Optional[Dict[str, Any]],
        index: Optional[int] = None,
        user_id_type: str = "open_id"
) -> Dict[str, Any]:
    """
    创建文本块

    Args:
        client: 飞书云客户端
        document_id: 文档的唯一标识
        block_id: 父块的 block_id
        index: 指定在某个块的子块列表中，新创建的子块的放置位置。索引的起始值为 0，表示子块列表的第一个位置
        content: 文本内容
        user_id_type: 用户 ID 类型

    Returns:
        包含新创建块信息的字典
    """
    children = {
        "block_type": 2,
        "text": content
    }
    return await create_block(
        client, document_id, block_id, index, children, user_id_type=user_id_type
    )


# ==================== 创建标题块 ====================
async def create_heading_block(
        client: FeishuCloudClient,
        document_id: str,
        block_id: str,
        content: Optional[Dict[str, Any]],
        index: Optional[int] = None,
        heading_level: int = 1,
        user_id_type: str = "open_id"
) -> Dict[str, Any]:
    """
    创建标题块

    Args:
        client: 飞书云客户端
        document_id: 文档的唯一标识
        block_id: 父块的 block_id
        content: 标题内容
        index: 指定在某个块的子块列表中，新创建的子块的放置位置。索引的起始值为 0，表示子块列表的第一个位置
        heading_level: 标题级别，1-9
        user_id_type: 用户 ID 类型

    Returns:
        包含新创建块信息的字典
    """
    block_type = 2 + heading_level
    heading_label = "heading" + str(heading_level)
    children = {
        "block_type": block_type,
        heading_label: content
    }
    return await create_block(
        client, document_id, block_id, index, children, user_id_type=user_id_type
    )


# ==================== 创建待办事项块 ====================
async def create_todo_block(
        client: FeishuCloudClient,
        document_id: str,
        block_id: str,
        content: str,
        done: bool = False,
        user_id_type: str = "open_id"
) -> Dict[str, Any]:
    """
    创建待办事项块

    Args:
        client: 飞书云客户端
        document_id: 文档的唯一标识
        block_id: 父块的 block_id
        content: 待办事项内容
        done: 是否完成
        user_id_type: 用户 ID 类型

    Returns:
        包含新创建块信息的字典
    """
    style = {"done": done}
    return await create_block(
        client, document_id, block_id, 17, content, style=style, user_id_type=user_id_type
    )


# ==================== 创建分割线块 ====================
async def create_divider_block(
        client: FeishuCloudClient,
        document_id: str,
        block_id: str,
        user_id_type: str = "open_id"
) -> Dict[str, Any]:
    """
    创建分割线块

    Args:
        client: 飞书云客户端
        document_id: 文档的唯一标识
        block_id: 父块的 block_id
        user_id_type: 用户 ID 类型

    Returns:
        包含新创建块信息的字典
    """
    request_url = f"/docx/v1/documents/{document_id}/blocks/{block_id}/children"
    params = {"user_id_type": user_id_type}

    block = {
        "block_type": 22
    }

    payload = {
        "children": [block]
    }

    data = await client.make_request("POST", request_url, json=payload, params=params)

    return data.get("data", {})


if __name__ == "__main__":
    c = FeishuCloudClient()
    import asyncio

    con = {
        "elements": [
            {
                "text_run": {
                    "content": "测试标题1",
                    "text_element_style": {
                        "text_color": 5
                    }
                }
            }
        ],
        "style": {}
    }
    asyncio.run(create_heading_block(c, "NYBldWM0roORnHxfEd9cci8cnbf", "NYBldWM0roORnHxfEd9cci8cnbf", content=con,
                                     heading_level=2))
