# Agent Rose Browser (Bundled Python Version)

Perpustakaan Python untuk **agent-browser CLI** yang digabungkan langsung dengan source code native-nya. Memungkinkan otomasi browser headless menggunakan perintah terstruktur langsung dari fungsi Python.

## Keunggulan Versi Bundled
- **Single Installation**: Cukup install satu folder, tidak perlu install CLI secara terpisah lewat npm global.
- **Auto-Build**: Otomatis mengompilasi binary native saat instalasi Python.
- **Auto-Detection**: Secara otomatis mendeteksi OS (Mac, Linux, Windows) dan arsitektur (x64, ARM64) untuk menggunakan binary yang tepat.

---

## Prasyarat (Untuk Build)
Sebelum instalasi, pastikan sistem Anda memiliki:
1. **Node.js & pnpm**: Untuk mengelola dependency CLI.
2. **Rust & Cargo**: Untuk mengompilasi core browser CLI.
3. **Python 3.7+**.

---

## Cara Instalasi

1. Ambil source code proyek ini.
2. Jalankan perintah instalasi di root direktori:

```bash
pip install .
```

*Proses ini akan otomatis menjalankan `pnpm install` dan `pnpm build` di dalam folder internal.*

---

## Penggunaan Cepat

```python
from agent_browser.agent_browser import AgentBrowser

# Inisialisasi (headed=True untuk melihat browser)
browser = AgentBrowser(headed=True)

try:
    # Buka website
    browser.open("https://example.com")
    
    # Ambil snapshot halaman
    snapshot = browser.snapshot(interactive=True)
    print(snapshot)
    
    # Ambil screenshot
    browser.screenshot("hasil.png")
    
finally:
    # Selalu tutup browser setelah selesai
    browser.close()
```

---

## Referensi API Singkat

### Navigasi
- `browser.open(url)`
- `browser.back()`
- `browser.forward()`
- `browser.reload()`

### Interaksi (Gunakan @ref dari snapshot)
- `browser.click("@e1")`
- `browser.fill("@e1", "teks")`
- `browser.press("Enter")`
- `browser.hover("@e1")`

### Pengambilan Data
- `browser.get_text("@e1")`
- `browser.get_title()`
- `browser.get_url()`

### Kondisi Tunggu
- `browser.wait(2000)` # Tunggu ms
- `browser.wait(text="Success")`
- `browser.wait(load="networkidle")`

---

## Troubleshooting

### Binary Tidak Ditemukan
Jika Anda baru saja memindahkan folder, jalankan kembali `pip install .` untuk memastikan path binary terdaftar dengan benar atau pastikan Anda sudah menjalankan build native di folder `agent_browser/core`.

### Izin Eksekusi (Linux/Mac)
Jika muncul error permission, pastikan binary di `agent_browser/core/bin/` memiliki izin eksekusi (`chmod +x`).

---

## Lisensi
Apache-2.0 / MIT
