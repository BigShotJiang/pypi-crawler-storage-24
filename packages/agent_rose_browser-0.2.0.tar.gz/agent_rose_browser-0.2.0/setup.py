import os
import subprocess
from setuptools import setup, find_packages
from setuptools.command.build_py import build_py
from setuptools.command.develop import develop

def build_cli():
    """Build the agent-browser CLI source."""
    core_dir = os.path.join(os.path.dirname(__file__), "agent_browser", "core")
    if os.path.exists(core_dir) and os.path.exists(os.path.join(core_dir, "package.json")):
        print(f"Building agent-browser CLI in {core_dir}...")
        try:
            # Check pnpm
            subprocess.run(["pnpm", "--version"], check=True, capture_output=True)
            
            # Install and Build
            subprocess.run(["pnpm", "install"], cwd=core_dir, check=True)
            subprocess.run(["pnpm", "run", "build:native"], cwd=core_dir, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            print(f"Warning: Could not build agent-browser CLI automatically: {e}")
            print("Users will need to have pnpm and rust (cargo) installed to build the CLI.")

class CustomBuild(build_py):
    def run(self):
        build_cli()
        super().run()

class CustomDevelop(develop):
    def run(self):
        build_cli()
        super().run()

setup(
    name="agent-rose-browser",
    version="0.2.0",
    packages=find_packages(),
    include_package_data=True,
    cmdclass={
        'build_py': CustomBuild,
        'develop': CustomDevelop,
    },
    install_requires=[],
    author="Erika",
    description="Python library for agent-browser CLI (Bundled)",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
