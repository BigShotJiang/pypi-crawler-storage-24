import os
import platform
import subprocess
import json
import logging
from typing import Any, Dict, Optional, Union


class AgentBrowser:
    """
    Python wrapper for the agent-browser CLI tool.

    Supports:
    - Navigation
    - Snapshot / page analysis
    - Interactions
    - Data retrieval
    - State checks
    - Screenshots / PDF
    - Recording / tracing
    - Wait conditions
    - Mouse control
    - Semantic locators
    - Browser settings / emulation
    - Cookies / storage
    - Network inspection / routing
    - Tabs / windows / frames
    - Dialogs
    - JavaScript evaluation
    - Console / errors / highlighting
    - Session and state management
    """

    def __init__(
        self,
        session: Optional[str] = None,
        headed: bool = False,
        timeout: Optional[int] = None,
        cdp: Optional[int] = None,
        bin_path: Optional[str] = None,
        subprocess_timeout: Optional[int] = 120,
    ):
        self.session = session
        self.headed = headed
        self.timeout = timeout              # CLI timeout in ms
        self.cdp = cdp                      # Chrome DevTools Protocol port
        self.subprocess_timeout = subprocess_timeout

        if bin_path:
            self.bin_path = bin_path
        else:
            # Detect local binary
            self.bin_path = self._detect_local_bin()

    def _detect_local_bin(self) -> str:
        """Detect the bundled native binary based on platform/arch."""
        base_dir = os.path.dirname(__file__)
        os_name = platform.system().lower()
        if os_name == "darwin":
            os_name = "darwin"
        elif os_name == "linux":
            os_name = "linux" # Simplified, could check for musl
        elif os_name == "windows":
            os_name = "win32"
        
        machine = platform.machine().lower()
        if machine in ["x86_64", "amd64"]:
            arch_name = "x64"
        elif machine in ["arm64", "aarch64"]:
            arch_name = "arm64"
        else:
            arch_name = machine
            
        binary_name = f"agent-browser-{os_name}-{arch_name}"
        if os_name == "win32":
            binary_name += ".exe"
            
        # Try local core/bin first
        local_bin = os.path.join(base_dir, "core", "bin", binary_name)
        if os.path.exists(local_bin):
            return local_bin
        
        # Fallback to global command
        return "agent-browser"

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------
    def _build_base_args(self) -> list:
        full_args = [self.bin_path]

        if self.session:
            full_args.extend(["--session", self.session])

        if self.headed:
            full_args.append("--headed")

        if self.timeout is not None:
            full_args.extend(["--timeout", str(self.timeout)])

        if self.cdp is not None:
            full_args.extend(["--cdp", str(self.cdp)])

        return full_args

    def _run_command(self, cmd: str, *args, **kwargs) -> Union[str, Dict[str, Any], list]:
        """
        Internal method to execute agent-browser CLI commands.

        Special kwargs:
        - json=True       -> append --json and parse stdout as JSON
        - full=True       -> append --full
        - clear=True      -> append --clear
        - abort=True      -> append --abort
        - name="Submit"   -> append --name "Submit"
        - text="Success"  -> append --text "Success"
        - url="/dashboard"-> append --url "/dashboard"
        - load="networkidle" -> append --load networkidle
        - fn="window.ready"  -> append --fn "window.ready"
        - filter="api"    -> append --filter api
        """
        json_output = kwargs.pop("json", False)

        full_args = self._build_base_args()
        full_args.append(cmd)

        for arg in args:
            if arg is not None:
                full_args.append(str(arg))

        if json_output:
            full_args.append("--json")

        for key, value in kwargs.items():
            if value is True:
                flag = key.replace("_", "-")
                if len(flag) == 1:
                    full_args.append(f"-{flag}")
                else:
                    full_args.append(f"--{flag}")
            elif value is not False and value is not None:
                flag = key.replace("_", "-")
                if len(flag) == 1:
                    full_args.extend([f"-{flag}", str(value)])
                else:
                    full_args.extend([f"--{flag}", str(value)])

        logging.debug("Running command: %s", " ".join(full_args))

        try:
            result = subprocess.run(
                full_args,
                capture_output=True,
                text=True,
                check=True,
                timeout=self.subprocess_timeout,
            )

            output = result.stdout.strip()

            if json_output:
                try:
                    return json.loads(output) if output else {}
                except json.JSONDecodeError:
                    return output

            return output

        except subprocess.CalledProcessError as e:
            stderr = (e.stderr or "").strip()
            stdout = (e.stdout or "").strip()
            logging.error("Command failed with exit code %s", e.returncode)
            logging.error("Stdout: %s", stdout)
            logging.error("Stderr: %s", stderr)
            raise RuntimeError(
                f"agent-browser command failed (exit {e.returncode}): {stderr or stdout}"
            ) from e

        except subprocess.TimeoutExpired as e:
            raise TimeoutError(
                f"agent-browser command timed out after {self.subprocess_timeout} seconds"
            ) from e

    # -------------------------------------------------------------------------
    # Navigation
    # -------------------------------------------------------------------------
    def open(self, url: str):
        """Navigate to a URL."""
        return self._run_command("open", url)

    def back(self):
        """Go back in history."""
        return self._run_command("back")

    def forward(self):
        """Go forward in history."""
        return self._run_command("forward")

    def reload(self):
        """Reload current page."""
        return self._run_command("reload")

    def close(self):
        """Close the browser session."""
        return self._run_command("close")

    # -------------------------------------------------------------------------
    # Snapshot / Analysis
    # -------------------------------------------------------------------------
    def snapshot(
        self,
        interactive: bool = False,
        compact: bool = False,
        json_output: bool = True,
        depth: Optional[int] = None,
        scope: Optional[str] = None,
    ):
        """Get a snapshot of the current page."""
        kwargs = {}
        if interactive:
            kwargs["i"] = True
        if compact:
            kwargs["c"] = True
        if depth is not None:
            kwargs["d"] = depth
        if scope is not None:
            kwargs["s"] = scope

        return self._run_command("snapshot", json=json_output, **kwargs)

    # -------------------------------------------------------------------------
    # Interactions
    # -------------------------------------------------------------------------
    def click(self, selector: str):
        """Click an element."""
        return self._run_command("click", selector)

    def dblclick(self, selector: str):
        """Double click an element."""
        return self._run_command("dblclick", selector)

    def focus(self, selector: str):
        """Focus an element."""
        return self._run_command("focus", selector)

    def fill(self, selector: str, text: str):
        """Clear and fill an input field."""
        return self._run_command("fill", selector, text)

    def type(self, selector: str, text: str):
        """Type into an input field without clearing."""
        return self._run_command("type", selector, text)

    def press(self, key: str):
        """Press a key or key combination."""
        return self._run_command("press", key)

    def keydown(self, key: str):
        """Hold a key down."""
        return self._run_command("keydown", key)

    def keyup(self, key: str):
        """Release a key."""
        return self._run_command("keyup", key)

    def hover(self, selector: str):
        """Hover mouse over an element."""
        return self._run_command("hover", selector)

    def check(self, selector: str):
        """Check a checkbox."""
        return self._run_command("check", selector)

    def uncheck(self, selector: str):
        """Uncheck a checkbox."""
        return self._run_command("uncheck", selector)

    def select(self, selector: str, value: str):
        """Select an option from a dropdown."""
        return self._run_command("select", selector, value)

    def scroll(self, direction: str, distance: int):
        """Scroll the page, e.g. scroll('down', 500)."""
        return self._run_command("scroll", direction, distance)

    def scrollintoview(self, selector: str):
        """Scroll an element into view."""
        return self._run_command("scrollintoview", selector)

    def drag(self, source: str, target: str):
        """Drag and drop from source to target."""
        return self._run_command("drag", source, target)

    def upload(self, selector: str, filepath: str):
        """Upload a file to an input."""
        return self._run_command("upload", selector, filepath)

    # -------------------------------------------------------------------------
    # Information Retrieval
    # -------------------------------------------------------------------------
    def get(self, prop: str, selector: Optional[str] = None, *extra_args, json_output: bool = False):
        """
        Get information.

        Examples:
        - get("text", "@e1")
        - get("html", "@e1")
        - get("value", "@e1")
        - get("attr", "@e1", "href")
        - get("title")
        - get("url")
        - get("count", ".item")
        - get("box", "@e1")
        """
        args = [prop]
        if selector is not None:
            args.append(selector)
        args.extend(extra_args)
        return self._run_command("get", *args, json=json_output)

    def get_text(self, selector: str):
        return self.get("text", selector)

    def get_html(self, selector: str):
        return self.get("html", selector)

    def get_value(self, selector: str):
        return self.get("value", selector)

    def get_attr(self, selector: str, attr_name: str):
        return self.get("attr", selector, attr_name)

    def get_title(self):
        return self.get("title")

    def get_url(self):
        return self.get("url")

    def get_count(self, selector: str):
        return self.get("count", selector)

    def get_box(self, selector: str):
        return self.get("box", selector, json_output=True)

    # -------------------------------------------------------------------------
    # State Checks
    # -------------------------------------------------------------------------
    def is_visible(self, selector: str) -> bool:
        """Check if visible."""
        return str(self._run_command("is", "visible", selector)).strip().lower() == "true"

    def is_enabled(self, selector: str) -> bool:
        """Check if enabled."""
        return str(self._run_command("is", "enabled", selector)).strip().lower() == "true"

    def is_checked(self, selector: str) -> bool:
        """Check if checked."""
        return str(self._run_command("is", "checked", selector)).strip().lower() == "true"

    # -------------------------------------------------------------------------
    # Screenshots & PDF
    # -------------------------------------------------------------------------
    def screenshot(self, path: Optional[str] = None, full: bool = False):
        """Take a screenshot."""
        kwargs = {"full": full}
        if path:
            return self._run_command("screenshot", path, **kwargs)
        return self._run_command("screenshot", **kwargs)

    def pdf(self, path: str):
        """Save page as PDF."""
        return self._run_command("pdf", path)

    # -------------------------------------------------------------------------
    # Recording & Tracing
    # -------------------------------------------------------------------------
    def record_start(self, path: str):
        """Start video recording."""
        return self._run_command("record", "start", path)

    def record_stop(self):
        """Stop video recording."""
        return self._run_command("record", "stop")

    def record_restart(self, path: str):
        """Restart video recording."""
        return self._run_command("record", "restart", path)

    def trace_start(self):
        """Start trace recording."""
        return self._run_command("trace", "start")

    def trace_stop(self, path: str):
        """Stop and save trace."""
        return self._run_command("trace", "stop", path)

    # -------------------------------------------------------------------------
    # Wait
    # -------------------------------------------------------------------------
    def wait(
        self,
        target: Optional[Union[str, int]] = None,
        timeout: Optional[int] = None,
        load: Optional[str] = None,
        text: Optional[str] = None,
        url: Optional[str] = None,
        fn: Optional[str] = None,
    ):
        """
        Wait for an element, time, or condition.

        Examples:
        - wait("@e1")
        - wait(2000)
        - wait(text="Success")
        - wait(url="/dashboard")
        - wait(load="networkidle")
        - wait(fn="window.ready")
        """
        kwargs = {}
        if timeout is not None:
            kwargs["timeout"] = timeout
        if load is not None:
            kwargs["load"] = load
        if text is not None:
            kwargs["text"] = text
        if url is not None:
            kwargs["url"] = url
        if fn is not None:
            kwargs["fn"] = fn

        if target is not None:
            return self._run_command("wait", target, **kwargs)
        return self._run_command("wait", **kwargs)

    # -------------------------------------------------------------------------
    # Mouse Control
    # -------------------------------------------------------------------------
    def mouse_move(self, x: int, y: int):
        """Move mouse to coordinates."""
        return self._run_command("mouse", "move", x, y)

    def mouse_down(self, button: str = "left"):
        """Press mouse button."""
        return self._run_command("mouse", "down", button)

    def mouse_up(self, button: str = "left"):
        """Release mouse button."""
        return self._run_command("mouse", "up", button)

    def mouse_wheel(self, delta: int):
        """Scroll mouse wheel."""
        return self._run_command("mouse", "wheel", delta)

    # -------------------------------------------------------------------------
    # Semantic Locators
    # -------------------------------------------------------------------------
    def find(self, selector_type: str, selector_value: str, action: Optional[str] = None, **kwargs):
        """
        Find and interact using semantic locators.

        Examples:
        - find("role", "button", "click", name="Submit")
        - find("text", "Sign In", "click")
        - find("label", "Email", "fill", value="user@test.com")  # depends on CLI behavior
        """
        args = [selector_type, selector_value]
        if action:
            args.append(action)
        return self._run_command("find", *args, **kwargs)

    # -------------------------------------------------------------------------
    # Browser Settings / Emulation
    # -------------------------------------------------------------------------
    def set_viewport(self, width: int, height: int):
        """Set viewport size."""
        return self._run_command("set", "viewport", width, height)

    def set_device(self, name: str):
        """Emulate a device."""
        return self._run_command("set", "device", name)

    def set_geo(self, lat: float, lon: float):
        """Set geolocation."""
        return self._run_command("set", "geo", lat, lon)

    def set_offline(self, on: bool = True):
        """Toggle offline mode."""
        return self._run_command("set", "offline", "on" if on else "off")

    def set_headers(self, headers: Union[str, Dict[str, Any]]):
        """Set extra HTTP headers."""
        if isinstance(headers, dict):
            headers = json.dumps(headers)
        return self._run_command("set", "headers", headers)

    def set_credentials(self, user: str, password: str):
        """Set HTTP authentication credentials."""
        return self._run_command("set", "credentials", user, password)

    def set_media(self, scheme: str):
        """Emulate media scheme, e.g. 'dark'."""
        return self._run_command("set", "media", scheme)

    # -------------------------------------------------------------------------
    # Cookies & Storage
    # -------------------------------------------------------------------------
    def cookies(self, action: str = "get", name: Optional[str] = None, value: Optional[str] = None):
        """
        Manage cookies.
        - cookies()
        - cookies("set", "name", "value")
        - cookies("clear")
        """
        if action == "clear":
            return self._run_command("cookies", "clear")
        if action == "set" and name is not None and value is not None:
            return self._run_command("cookies", "set", name, value)
        return self._run_command("cookies", json=True)

    def storage_local(self, action: str = "get", key: Optional[str] = None, value: Optional[str] = None):
        """
        Manage local storage.
        - storage_local()
        - storage_local("get", "token")
        - storage_local("set", "token", "abc")
        - storage_local("clear")
        """
        args = ["local"]

        if action == "set" and key is not None and value is not None:
            args.extend(["set", key, value])
            return self._run_command("storage", *args)

        if action == "clear":
            args.append("clear")
            return self._run_command("storage", *args)

        if key is not None:
            args.append(key)

        return self._run_command("storage", *args, json=True)

    # -------------------------------------------------------------------------
    # Network
    # -------------------------------------------------------------------------
    def network_route(self, url: str, abort: bool = False, body: Optional[str] = None):
        """
        Intercept and route network requests.
        """
        kwargs = {}
        if abort:
            kwargs["abort"] = True
        if body is not None:
            kwargs["body"] = body
        return self._run_command("network", "route", url, **kwargs)

    def network_unroute(self, url: Optional[str] = None):
        """Remove network routes."""
        if url:
            return self._run_command("network", "unroute", url)
        return self._run_command("network", "unroute")

    def network_requests(self, filter: Optional[str] = None):
        """View tracked network requests."""
        kwargs = {}
        if filter is not None:
            kwargs["filter"] = filter
        return self._run_command("network", "requests", json=True, **kwargs)

    # -------------------------------------------------------------------------
    # Tabs & Windows
    # -------------------------------------------------------------------------
    def tab_list(self):
        """List all tabs."""
        return self._run_command("tab", json=True)

    def tab_new(self, url: Optional[str] = None):
        """Open a new tab."""
        if url:
            return self._run_command("tab", "new", url)
        return self._run_command("tab", "new")

    def tab_switch(self, index: int):
        """Switch to a tab by index."""
        return self._run_command("tab", index)

    def tab_close(self):
        """Close the current tab."""
        return self._run_command("tab", "close")

    def window_new(self):
        """Open a new window."""
        return self._run_command("window", "new")

    # -------------------------------------------------------------------------
    # Frames
    # -------------------------------------------------------------------------
    def frame(self, name_or_selector: str):
        """Switch to a frame or back to main."""
        return self._run_command("frame", name_or_selector)

    # -------------------------------------------------------------------------
    # Dialogs
    # -------------------------------------------------------------------------
    def dialog_accept(self, text: Optional[str] = None):
        """Accept dialog, optionally with prompt text."""
        if text is not None:
            return self._run_command("dialog", "accept", text)
        return self._run_command("dialog", "accept")

    def dialog_dismiss(self):
        """Dismiss dialog."""
        return self._run_command("dialog", "dismiss")

    # -------------------------------------------------------------------------
    # JavaScript / Debugging
    # -------------------------------------------------------------------------
    def eval(self, script: str):
        """Evaluate JavaScript on the page."""
        return self._run_command("eval", script)

    def console(self, clear: bool = False):
        """View or clear console messages."""
        kwargs = {}
        if clear:
            kwargs["clear"] = True
        return self._run_command("console", **kwargs)

    def errors(self, clear: bool = False):
        """View or clear page errors."""
        kwargs = {}
        if clear:
            kwargs["clear"] = True
        return self._run_command("errors", **kwargs)

    def highlight(self, selector: str):
        """Highlight an element."""
        return self._run_command("highlight", selector)

    # -------------------------------------------------------------------------
    # State Persistence
    # -------------------------------------------------------------------------
    def state_save(self, path: str):
        """Save session state to a file."""
        return self._run_command("state", "save", path)

    def state_load(self, path: str):
        """Load session state from a file."""
        return self._run_command("state", "load", path)

    # -------------------------------------------------------------------------
    # Session Management
    # -------------------------------------------------------------------------
    def session_list(self):
        """List all sessions."""
        return self._run_command("session", "list", json=True)