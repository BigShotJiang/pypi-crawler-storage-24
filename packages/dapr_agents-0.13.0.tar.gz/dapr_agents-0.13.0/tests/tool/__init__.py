"""Tests for tool utilities."""
