"""Agent-scoped flow editing commands for the Applied CLI.

These commands are intentionally lightweight and only intercept the nested
`applied agents <agent_id> flows ...` shape used by Pix/Hermes skills.
Everything else continues through the regular Typer CLI.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Callable
from typing import Any

from applied_cli.client import AppliedClient
from applied_cli.flow_helpers import normalize_executor_type


class AgentScopedFlowCLIError(RuntimeError):
    """Raised when a nested agent-scoped flow command cannot be completed."""


def _write_stdout(text: str) -> None:
    sys.stdout.write(f"{text}\n")


def _write_stderr(text: str) -> None:
    sys.stderr.write(f"{text}\n")


def _parse_json_option(value: str | None, *, option_name: str) -> dict[str, Any] | None:
    if not value:
        return None

    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise AgentScopedFlowCLIError(
            f"{option_name} must be valid JSON and decode to an object."
        ) from exc

    if not isinstance(parsed, dict):
        raise AgentScopedFlowCLIError(
            f"{option_name} must decode to a JSON object."
        )

    return parsed


def _print_json(payload: dict[str, Any]) -> None:
    _write_stdout(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True))


def _format_mutation_response(
    *,
    result: Any,
    patches: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return {
        "type": "flow_graph_mutation",
        "patches": patches or [],
        "result": result,
    }


def _build_flow_patch(
    *,
    op: str,
    kind: str,
    flow_id: str,
    obj_id: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    return {
        "op": op,
        "kind": kind,
        "flow_id": flow_id,
        "obj_id": obj_id,
        "payload": payload,
    }


async def _get_flow_for_agent(
    client: AppliedClient,
    *,
    agent_id: str,
    flow_id: str,
) -> dict[str, Any]:
    flow = await client.get_flow(flow_id)
    flow_agent = flow.get("agent") or {}
    flow_agent_id = str(flow_agent.get("id") or flow.get("agent_id") or "").strip()
    if flow_agent_id != str(agent_id).strip():
        raise AgentScopedFlowCLIError(
            f"Flow {flow_id} does not belong to agent {agent_id}. Refusing to mutate it."
        )
    return flow


async def _handle_flow_create(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    flow = await client.create_flow(
        agent_id=args.agent_id,
        name=args.name,
        flow_type=args.type,
        trigger=args.trigger,
        description=args.description,
    )
    payload = _format_mutation_response(result=flow)
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Created flow {flow.get('id')} for agent {args.agent_id}.")
    return 0


async def _handle_flow_update(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    await _get_flow_for_agent(client, agent_id=args.agent_id, flow_id=args.flow_id)

    updates = {
        key: value
        for key, value in {
            "name": args.name,
            "trigger": args.trigger,
            "type": args.type,
            "description": args.description,
            "status": args.status,
            "prompt": args.prompt,
        }.items()
        if value is not None
    }
    if not updates:
        raise AgentScopedFlowCLIError("No flow updates provided.")

    flow = await client.update_flow(args.flow_id, **updates)
    payload = _format_mutation_response(result=flow)
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Updated flow {args.flow_id}.")
    return 0


async def _handle_flow_delete(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    flow = await _get_flow_for_agent(client, agent_id=args.agent_id, flow_id=args.flow_id)
    await client.delete_flow(args.flow_id)
    payload = _format_mutation_response(result={"id": args.flow_id, "deleted": True})
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Deleted flow {flow.get('id')}.")
    return 0


async def _handle_node_create(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    await _get_flow_for_agent(client, agent_id=args.agent_id, flow_id=args.flow_id)

    node = await client.create_node(
        flow_id=args.flow_id,
        name=normalize_executor_type(args.executor_type),
        metadata=_parse_json_option(args.metadata, option_name="--metadata") or {},
        description=args.description or "",
        prompt=args.prompt or "",
        guardrail=args.guardrail or "",
    )
    patch = _build_flow_patch(
        op="add",
        kind="node",
        flow_id=args.flow_id,
        obj_id=str(node.get("id") or ""),
        payload=node,
    )
    payload = _format_mutation_response(result=node, patches=[patch])
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Created node {node.get('id')} in flow {args.flow_id}.")
    return 0


async def _handle_node_update(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    await _get_flow_for_agent(client, agent_id=args.agent_id, flow_id=args.flow_id)

    updates = {
        key: value
        for key, value in {
            "description": args.description,
            "prompt": args.prompt,
            "guardrail": args.guardrail,
            "metadata": _parse_json_option(args.metadata, option_name="--metadata"),
        }.items()
        if value is not None
    }
    if not updates:
        raise AgentScopedFlowCLIError("No node updates provided.")

    node = await client.update_node(args.flow_id, args.node_id, **updates)
    patch = _build_flow_patch(
        op="replace",
        kind="node",
        flow_id=args.flow_id,
        obj_id=str(node.get("id") or args.node_id),
        payload=node,
    )
    payload = _format_mutation_response(result=node, patches=[patch])
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Updated node {args.node_id} in flow {args.flow_id}.")
    return 0


async def _handle_node_delete(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    flow = await _get_flow_for_agent(client, agent_id=args.agent_id, flow_id=args.flow_id)

    graph = flow.get("graph") or {}
    nodes = graph.get("nodes") or []
    edges = graph.get("edges") or []
    node = next((item for item in nodes if item.get("id") == args.node_id), None)
    if node is None:
        raise AgentScopedFlowCLIError(
            f"Node {args.node_id} was not found in flow {args.flow_id}."
        )

    connected_edges = [
        edge
        for edge in edges
        if edge.get("source") == args.node_id or edge.get("target") == args.node_id
    ]

    await client.delete_node(args.flow_id, args.node_id)

    patches = [
        _build_flow_patch(
            op="remove",
            kind="edge",
            flow_id=args.flow_id,
            obj_id=str(edge.get("id") or ""),
            payload=edge,
        )
        for edge in connected_edges
        if edge.get("id")
    ]
    patches.append(
        _build_flow_patch(
            op="remove",
            kind="node",
            flow_id=args.flow_id,
            obj_id=args.node_id,
            payload=node,
        )
    )

    payload = _format_mutation_response(
        result={"id": args.node_id, "deleted": True},
        patches=patches,
    )
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Deleted node {args.node_id} from flow {args.flow_id}.")
    return 0


async def _handle_edge_create(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    await _get_flow_for_agent(client, agent_id=args.agent_id, flow_id=args.flow_id)

    edge = await client.create_edge(
        flow_id=args.flow_id,
        source_node_id=args.source_node_id,
        target_node_id=args.target_node_id,
        source_handle=args.source_handle,
        target_handle=args.target_handle,
        label=args.label,
    )
    patch = _build_flow_patch(
        op="add",
        kind="edge",
        flow_id=args.flow_id,
        obj_id=str(edge.get("id") or ""),
        payload=edge,
    )
    payload = _format_mutation_response(result=edge, patches=[patch])
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Created edge {edge.get('id')} in flow {args.flow_id}.")
    return 0


async def _handle_edge_update(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    await _get_flow_for_agent(client, agent_id=args.agent_id, flow_id=args.flow_id)

    updates = {
        key: value
        for key, value in {
            "label": args.label,
            "metadata": _parse_json_option(args.metadata, option_name="--metadata"),
        }.items()
        if value is not None
    }
    if not updates:
        raise AgentScopedFlowCLIError("No edge updates provided.")

    edge = await client.update_edge(args.flow_id, args.edge_id, **updates)
    patch = _build_flow_patch(
        op="replace",
        kind="edge",
        flow_id=args.flow_id,
        obj_id=str(edge.get("id") or args.edge_id),
        payload=edge,
    )
    payload = _format_mutation_response(result=edge, patches=[patch])
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Updated edge {args.edge_id} in flow {args.flow_id}.")
    return 0


async def _handle_edge_delete(
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    client = get_client(args.shop_id)
    flow = await _get_flow_for_agent(client, agent_id=args.agent_id, flow_id=args.flow_id)

    graph = flow.get("graph") or {}
    edges = graph.get("edges") or []
    edge = next((item for item in edges if item.get("id") == args.edge_id), None)
    if edge is None:
        raise AgentScopedFlowCLIError(
            f"Edge {args.edge_id} was not found in flow {args.flow_id}."
        )

    await client.delete_edge(args.flow_id, args.edge_id)
    patch = _build_flow_patch(
        op="remove",
        kind="edge",
        flow_id=args.flow_id,
        obj_id=args.edge_id,
        payload=edge,
    )
    payload = _format_mutation_response(
        result={"id": args.edge_id, "deleted": True},
        patches=[patch],
    )
    if args.format == "json":
        _print_json(payload)
    else:
        _write_stdout(f"Deleted edge {args.edge_id} from flow {args.flow_id}.")
    return 0


def _add_shared_format_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--shop-id", default=None)
    parser.add_argument("--format", choices=["text", "json"], default="text")


def _build_parsers() -> dict[tuple[str, ...], argparse.ArgumentParser]:
    parsers: dict[tuple[str, ...], argparse.ArgumentParser] = {}

    flow_create = argparse.ArgumentParser(prog="applied agents <agent_id> flows create")
    flow_create.add_argument("--name", required=True)
    flow_create.add_argument("--trigger", default="llm.call")
    flow_create.add_argument("--type", default="conversational")
    flow_create.add_argument("--description", default="")
    _add_shared_format_args(flow_create)
    parsers[("flows", "create")] = flow_create

    flow_update = argparse.ArgumentParser(
        prog="applied agents <agent_id> flows <flow_id> update"
    )
    flow_update.add_argument("--name", default=None)
    flow_update.add_argument("--trigger", default=None)
    flow_update.add_argument("--type", default=None)
    flow_update.add_argument("--description", default=None)
    flow_update.add_argument("--status", default=None)
    flow_update.add_argument("--prompt", default=None)
    _add_shared_format_args(flow_update)
    parsers[("flow", "update")] = flow_update

    flow_delete = argparse.ArgumentParser(
        prog="applied agents <agent_id> flows <flow_id> delete"
    )
    _add_shared_format_args(flow_delete)
    parsers[("flow", "delete")] = flow_delete

    node_create = argparse.ArgumentParser(
        prog="applied agents <agent_id> flows <flow_id> node create"
    )
    node_create.add_argument("--executor-type", required=True)
    node_create.add_argument("--description", default="")
    node_create.add_argument("--prompt", default="")
    node_create.add_argument("--guardrail", default="")
    node_create.add_argument("--metadata", default=None)
    _add_shared_format_args(node_create)
    parsers[("node", "create")] = node_create

    node_update = argparse.ArgumentParser(
        prog="applied agents <agent_id> flows <flow_id> node <node_id> update"
    )
    node_update.add_argument("--description", default=None)
    node_update.add_argument("--prompt", default=None)
    node_update.add_argument("--guardrail", default=None)
    node_update.add_argument("--metadata", default=None)
    _add_shared_format_args(node_update)
    parsers[("node", "update")] = node_update

    node_delete = argparse.ArgumentParser(
        prog="applied agents <agent_id> flows <flow_id> node <node_id> delete"
    )
    _add_shared_format_args(node_delete)
    parsers[("node", "delete")] = node_delete

    edge_create = argparse.ArgumentParser(
        prog="applied agents <agent_id> flows <flow_id> edge create"
    )
    edge_create.add_argument("--source-node-id", required=True)
    edge_create.add_argument("--target-node-id", required=True)
    edge_create.add_argument("--source-handle", default=None)
    edge_create.add_argument("--target-handle", default=None)
    edge_create.add_argument("--label", default=None)
    _add_shared_format_args(edge_create)
    parsers[("edge", "create")] = edge_create

    edge_update = argparse.ArgumentParser(
        prog="applied agents <agent_id> flows <flow_id> edge <edge_id> update"
    )
    edge_update.add_argument("--label", default=None)
    edge_update.add_argument("--metadata", default=None)
    _add_shared_format_args(edge_update)
    parsers[("edge", "update")] = edge_update

    edge_delete = argparse.ArgumentParser(
        prog="applied agents <agent_id> flows <flow_id> edge <edge_id> delete"
    )
    _add_shared_format_args(edge_delete)
    parsers[("edge", "delete")] = edge_delete

    return parsers


PARSERS = _build_parsers()


def _help_text() -> str:
    return "\n".join(
        [
            "Agent-scoped flow editing commands:",
            "  applied agents <agent_id> flows create ...",
            "  applied agents <agent_id> flows <flow_id> update ...",
            "  applied agents <agent_id> flows <flow_id> delete",
            "  applied agents <agent_id> flows <flow_id> node create ...",
            "  applied agents <agent_id> flows <flow_id> node <node_id> update ...",
            "  applied agents <agent_id> flows <flow_id> node <node_id> delete",
            "  applied agents <agent_id> flows <flow_id> edge create ...",
            "  applied agents <agent_id> flows <flow_id> edge <edge_id> update ...",
            "  applied agents <agent_id> flows <flow_id> edge <edge_id> delete",
        ]
    )


def _parse_nested_command(argv: list[str]) -> tuple[str, argparse.Namespace] | None:
    if len(argv) < 3 or argv[0] != "agents" or argv[2] != "flows":
        return None

    agent_id = argv[1]
    rest = argv[3:]
    if not agent_id or agent_id.startswith("-"):
        return None
    if not rest:
        _write_stderr(_help_text())
        raise SystemExit(1)
    if rest[0] in {"-h", "--help"}:
        _write_stdout(_help_text())
        raise SystemExit(0)

    if rest[0] == "create":
        parsed = PARSERS[("flows", "create")].parse_args(rest[1:])
        parsed.agent_id = agent_id
        return "flow_create", parsed

    flow_id = rest[0]
    if len(rest) == 1:
        _write_stderr(_help_text())
        raise SystemExit(1)
    if rest[1] in {"-h", "--help"}:
        _write_stdout(_help_text())
        raise SystemExit(0)

    if rest[1] in {"update", "delete"}:
        action = rest[1]
        parsed = PARSERS[("flow", action)].parse_args(rest[2:])
        parsed.agent_id = agent_id
        parsed.flow_id = flow_id
        return f"flow_{action}", parsed

    if rest[1] == "node":
        if len(rest) < 3:
            _write_stderr(_help_text())
            raise SystemExit(1)
        if rest[2] == "create":
            parsed = PARSERS[("node", "create")].parse_args(rest[3:])
            parsed.agent_id = agent_id
            parsed.flow_id = flow_id
            return "node_create", parsed
        if len(rest) < 4:
            _write_stderr(_help_text())
            raise SystemExit(1)
        node_id = rest[2]
        action = rest[3]
        if action not in {"update", "delete"}:
            _write_stderr(_help_text())
            raise SystemExit(1)
        parsed = PARSERS[("node", action)].parse_args(rest[4:])
        parsed.agent_id = agent_id
        parsed.flow_id = flow_id
        parsed.node_id = node_id
        return f"node_{action}", parsed

    if rest[1] == "edge":
        if len(rest) < 3:
            _write_stderr(_help_text())
            raise SystemExit(1)
        if rest[2] == "create":
            parsed = PARSERS[("edge", "create")].parse_args(rest[3:])
            parsed.agent_id = agent_id
            parsed.flow_id = flow_id
            return "edge_create", parsed
        if len(rest) < 4:
            _write_stderr(_help_text())
            raise SystemExit(1)
        edge_id = rest[2]
        action = rest[3]
        if action not in {"update", "delete"}:
            _write_stderr(_help_text())
            raise SystemExit(1)
        parsed = PARSERS[("edge", action)].parse_args(rest[4:])
        parsed.agent_id = agent_id
        parsed.flow_id = flow_id
        parsed.edge_id = edge_id
        return f"edge_{action}", parsed

    _write_stderr(_help_text())
    raise SystemExit(1)


async def _run_nested_command(
    command: str,
    args: argparse.Namespace,
    get_client: Callable[[str | None], AppliedClient],
) -> int:
    handlers = {
        "flow_create": _handle_flow_create,
        "flow_update": _handle_flow_update,
        "flow_delete": _handle_flow_delete,
        "node_create": _handle_node_create,
        "node_update": _handle_node_update,
        "node_delete": _handle_node_delete,
        "edge_create": _handle_edge_create,
        "edge_update": _handle_edge_update,
        "edge_delete": _handle_edge_delete,
    }
    return await handlers[command](args, get_client)


def run_agent_scoped_flow_command(
    argv: list[str],
    get_client: Callable[[str | None], AppliedClient],
) -> int | None:
    try:
        parsed = _parse_nested_command(argv)
        if parsed is None:
            return None
        command, args = parsed
        return asyncio.run(_run_nested_command(command, args, get_client))
    except AgentScopedFlowCLIError as exc:
        _write_stderr(f"Error: {exc}")
        return 1
