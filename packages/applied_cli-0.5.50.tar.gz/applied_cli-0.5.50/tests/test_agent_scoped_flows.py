import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from applied_cli.agent_scoped_flows import (  # noqa: E402
    AgentScopedFlowCLIError,
    _handle_node_create,
    _handle_node_delete,
    _handle_node_update,
    _parse_nested_command,
    run_agent_scoped_flow_command,
)


class StubClient:
    def __init__(self, *, flow: dict, node: dict | None = None):
        self.flow = flow
        self.node = node or {"id": "node-1", "name": "completion"}
        self.created_node_args = None
        self.updated_node_args = None
        self.deleted_node_args = None

    async def get_flow(self, flow_id: str):
        assert flow_id == self.flow["id"]
        return self.flow

    async def create_node(self, **kwargs):
        self.created_node_args = kwargs
        return self.node

    async def update_node(self, flow_id: str, node_id: str, **kwargs):
        self.updated_node_args = (flow_id, node_id, kwargs)
        return {**self.node, "id": node_id, **kwargs}

    async def delete_node(self, flow_id: str, node_id: str):
        self.deleted_node_args = (flow_id, node_id)


def test_parse_nested_node_create_command():
    command, args = _parse_nested_command(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "create",
            "--executor-type",
            "Agent Response",
            "--metadata",
            '{"position":{"x":1,"y":2}}',
            "--format",
            "json",
        ]
    )

    assert command == "node_create"
    assert args.agent_id == "agent-1"
    assert args.flow_id == "flow-1"
    assert args.executor_type == "Agent Response"
    assert args.format == "json"


def test_agent_scoped_parser_ignores_top_level_agents_command():
    assert run_agent_scoped_flow_command(["agents"], lambda _shop_id: None) is None
    assert (
        run_agent_scoped_flow_command(
            ["agents", "--format", "json"],
            lambda _shop_id: None,
        )
        is None
    )


@pytest.mark.asyncio
async def test_node_create_emits_json_mutation_payload(capsys):
    client = StubClient(
        flow={"id": "flow-1", "agent": {"id": "agent-1"}},
        node={"id": "node-9", "name": "completion-node"},
    )
    _, args = _parse_nested_command(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "create",
            "--executor-type",
            "Agent Response",
            "--metadata",
            '{"position":{"x":1,"y":2}}',
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_node_create(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.created_node_args is not None
    assert client.created_node_args["name"] == "completion"
    assert client.created_node_args["metadata"] == {"position": {"x": 1, "y": 2}}
    payload = capsys.readouterr().out
    assert '"type": "flow_graph_mutation"' in payload
    assert '"kind": "node"' in payload
    assert '"op": "add"' in payload


@pytest.mark.asyncio
async def test_node_update_rejects_wrong_agent():
    client = StubClient(flow={"id": "flow-1", "agent": {"id": "agent-2"}})
    _, args = _parse_nested_command(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "node-1",
            "update",
            "--prompt",
            "hi",
        ]
    )

    with pytest.raises(AgentScopedFlowCLIError, match="does not belong to agent"):
        await _handle_node_update(args, lambda _shop_id: client)


@pytest.mark.asyncio
async def test_node_delete_emits_connected_edge_patches_before_node(capsys):
    client = StubClient(
        flow={
            "id": "flow-1",
            "agent": {"id": "agent-1"},
            "graph": {
                "nodes": [{"id": "node-1", "name": "branch-node"}],
                "edges": [
                    {"id": "edge-1", "source": "node-1", "target": "node-2"},
                    {"id": "edge-2", "source": "node-3", "target": "node-1"},
                ],
            },
        }
    )
    _, args = _parse_nested_command(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "node-1",
            "delete",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_node_delete(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.deleted_node_args == ("flow-1", "node-1")
    payload = capsys.readouterr().out
    edge_1_pos = payload.index('"obj_id": "edge-1"')
    edge_2_pos = payload.index('"obj_id": "edge-2"')
    node_pos = payload.index('"obj_id": "node-1"')
    assert edge_1_pos < node_pos
    assert edge_2_pos < node_pos
