interface Window {
  Payplug?: any;
}
