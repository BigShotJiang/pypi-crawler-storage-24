declare module 'intl-pluralrules';
