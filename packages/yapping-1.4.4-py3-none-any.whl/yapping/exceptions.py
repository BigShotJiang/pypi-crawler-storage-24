class YappingException(Exception):
    pass
