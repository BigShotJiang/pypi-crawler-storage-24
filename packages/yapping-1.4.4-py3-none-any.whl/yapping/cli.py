#! /usr/bin/env python
from __future__ import annotations

import argparse
from importlib.metadata import version
from typing import Sequence

from yapping import commands

PYPROJECT_FILENAME = "pyproject.toml"

UPGRADE_ARG = "--upgrade"

COMPILE_PARAM = "compile"
COMPILE_TEST_PARAM = "compile_test"


class Commands:
    ADD = "add"
    REMOVE = "rm"
    COMPILE = "compile"
    UPGRADE = "upgrade"
    VERSION = "version"
    INIT = "init"


def _package_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "packages",
        help="Name of the package to add.",
        nargs="*",
    )


def _extra_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--extra",
        help="Add package to the optional dependencies list.",
        action=argparse.BooleanOptionalAction,
        default=False,
    )


def _optional_dependencies_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--optional-dependencies",
        help="Name of the optional dependencies list",
        default="test",
    )


def _test_requirements_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--test-requirements",
        help="Name of the test requirements file.",
        default="test-requirements.txt",
    )


def _compile_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--compile",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Whether to compile the dependencies after running the command.",
    )
    parser.add_argument(
        "--compile-test",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Whether to compile the test dependencies after running the command.",
    )


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"v{version('yapping')}",
        help="Print version of the tool.",
    )

    subparser = parser.add_subparsers(
        title="command",
        dest="command",
    )

    add_parser = subparser.add_parser(
        Commands.ADD,
        help="Add a new dependency",
    )
    _package_arg(add_parser)
    _compile_arg(add_parser)
    _extra_arg(add_parser)
    _optional_dependencies_arg(add_parser)
    _test_requirements_arg(add_parser)

    rm_parser = subparser.add_parser(
        Commands.REMOVE,
        help="Remove an existing dependency",
    )
    _package_arg(rm_parser)
    _compile_arg(rm_parser)
    _extra_arg(rm_parser)
    _optional_dependencies_arg(rm_parser)
    _test_requirements_arg(rm_parser)

    compile_parser = subparser.add_parser(
        Commands.COMPILE,
        help="compile dependencies with pip-tools' `pip-compile`",
    )
    _extra_arg(compile_parser)
    _optional_dependencies_arg(compile_parser)
    _test_requirements_arg(compile_parser)

    upgrade_parser = subparser.add_parser(
        Commands.UPGRADE,
        help="compile dependencies with pip-tools' `pip-compile`",
    )
    _optional_dependencies_arg(upgrade_parser)
    _test_requirements_arg(upgrade_parser)

    version_parser = subparser.add_parser(
        Commands.VERSION,
        help="Updatea project version in pyproject.toml",
    )
    version_parser.add_argument(
        "version_type",
        help="What kind of version update to do.",
        choices=["patch", "minor", "major"],
        default="minor",
    )

    init_parser = subparser.add_parser(
        Commands.INIT,
        help="Create a pyproject.toml from a template.",
    )
    init_parser.add_argument(
        "project_name",
        help="Name of the project.",
    )
    init_parser.add_argument(
        "--output-dir",
        help="Output directory for the generated pyproject.toml file.",
        default=".",
    )
    _compile_arg(init_parser)
    _optional_dependencies_arg(init_parser)
    _test_requirements_arg(init_parser)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = make_parser()
    parsed_args = parser.parse_args(argv)

    do_compile = False
    do_compile_test = False

    if parsed_args.command == Commands.ADD:
        do_compile_test = True

        if parsed_args.extra is True:
            commands.add_optional_dependency(
                PYPROJECT_FILENAME,
                parsed_args.optional_dependencies,
                *parsed_args.packages,
            )
        else:
            do_compile = True
            commands.add_dependency(
                PYPROJECT_FILENAME,
                *parsed_args.packages,
            )
    elif parsed_args.command == Commands.REMOVE:
        do_compile_test = True

        if parsed_args.extra is True:
            commands.remove_optional_dependency(
                PYPROJECT_FILENAME,
                parsed_args.optional_dependencies,
                *parsed_args.packages,
            )
        else:
            do_compile = True
            commands.remove_dependency(
                PYPROJECT_FILENAME,
                *parsed_args.packages,
            )
    elif parsed_args.command == Commands.COMPILE:
        do_compile_test = True

        if not parsed_args.extra:
            do_compile = True
    elif parsed_args.command == Commands.UPGRADE:
        commands.compile_dependencies(PYPROJECT_FILENAME, UPGRADE_ARG)

        commands.compile_test_dependencies(
            PYPROJECT_FILENAME,
            parsed_args.optional_dependencies,
            parsed_args.test_requirements,
            UPGRADE_ARG,
        )

    elif parsed_args.command == Commands.VERSION:
        commands.update_version(PYPROJECT_FILENAME, parsed_args.version_type)
    elif parsed_args.command == Commands.INIT:
        commands.init(parsed_args.project_name, parsed_args.output_dir)

        if parsed_args.compile:
            do_compile = True
            do_compile_test = True
    else:
        parser.print_help()

    if getattr(parsed_args, COMPILE_PARAM, True) and do_compile:
        commands.compile_dependencies(PYPROJECT_FILENAME)

    if getattr(parsed_args, COMPILE_TEST_PARAM, True) and do_compile_test:
        commands.compile_test_dependencies(
            PYPROJECT_FILENAME,
            parsed_args.optional_dependencies,
            parsed_args.test_requirements,
        )

    return 0
