"""Keycloak MCP Server — Keycloak Admin API tools for eRegistrations IAM."""
