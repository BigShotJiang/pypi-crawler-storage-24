from enum import StrEnum


class KcObjectType(StrEnum):
    REALM = "realm"
    USER = "user"
    ROLE = "role"
    COMPOSITE_ROLE = "composite_role"
    USER_ROLE_MAPPING = "user_role_mapping"
    THEME = "theme"
    USER_PROFILE = "user_profile"
    CLIENT_MAPPER = "client_mapper"
