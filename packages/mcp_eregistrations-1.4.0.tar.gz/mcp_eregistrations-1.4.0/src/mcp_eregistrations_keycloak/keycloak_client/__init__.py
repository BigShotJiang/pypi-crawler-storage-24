"""Keycloak Admin REST API client."""

from mcp_eregistrations_keycloak.keycloak_client.client import KeycloakAdminClient
from mcp_eregistrations_keycloak.keycloak_client.errors import (
    KeycloakAuthError,
    KeycloakClientError,
    KeycloakConflictError,
    KeycloakForbiddenError,
    KeycloakNotFoundError,
    KeycloakServerError,
    KeycloakValidationError,
    translate_error,
)

__all__ = [
    "KeycloakAdminClient",
    "KeycloakAuthError",
    "KeycloakClientError",
    "KeycloakConflictError",
    "KeycloakForbiddenError",
    "KeycloakNotFoundError",
    "KeycloakServerError",
    "KeycloakValidationError",
    "translate_error",
]
