from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-keycloak",
    instructions=(
        "Keycloak Admin API tools for eRegistrations IAM management. "
        "Use kc_connection_status to verify connectivity, kc_list_realms to "
        "discover realms.\n\n"
        "AUTHENTICATION: If a tool returns an auth error, call kc_auth_login "
        "with the user's credentials. Credentials are stored for silent auto-login "
        "on future sessions. Shared across all eRegistrations MCP servers.\n\n"
        "NOTE: The authenticated user must have Keycloak realm-management roles "
        "(manage-users, manage-realm, view-realm) to use admin tools."
    ),
)

import mcp_eregistrations_keycloak.tools.diagnostics  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.export  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.jwt_tools  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.mappers  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.realms  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.roles  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.system  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.themes  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.user_profile  # noqa: F401, E402
import mcp_eregistrations_keycloak.tools.users  # noqa: F401, E402


def main() -> None:
    """Entry point for mcp-eregistrations-keycloak."""
    mcp.run()
