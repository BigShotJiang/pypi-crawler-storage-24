from __future__ import annotations

import base64
from pathlib import Path

import pymupdf


def render_pdf_pages_as_data_urls(
    pdf_path: str | Path,
    page_numbers: list[int],
    *,
    dpi: int = 144,
    max_dimension: int = 1400,
) -> dict[int, str]:
    """Render 1-based PDF page numbers to PNG data URLs for vision OCR."""
    path = Path(pdf_path).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"PDF file not found: {path}")

    urls: dict[int, str] = {}
    document = pymupdf.open(path)
    try:
        for page_number in page_numbers:
            page_index = page_number - 1
            if page_index < 0 or page_index >= document.page_count:
                raise ValueError(
                    f"Page number {page_number} is out of range for {path.name}."
                )

            page = document.load_page(page_index)
            base_scale = dpi / 72.0
            max_page_side = max(page.rect.width, page.rect.height) or 1.0
            scale = min(base_scale, max_dimension / max_page_side)
            pixmap = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False)
            png_bytes = pixmap.tobytes("png")
            urls[page_number] = (
                "data:image/png;base64,"
                + base64.b64encode(png_bytes).decode("ascii")
            )
    finally:
        document.close()

    return urls
