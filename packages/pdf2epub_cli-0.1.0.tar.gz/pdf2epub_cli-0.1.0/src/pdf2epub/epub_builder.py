from __future__ import annotations

import re
import uuid
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from .book_model import Block, BlockType, Book, Chapter


_EPUB_CSS = """\
body {
    font-family: "Noto Serif CJK SC", "Source Han Serif SC", "Songti SC", serif;
    line-height: 1.8;
    margin: 0;
    color: #1a1a1a;
    background: #fffdfa;
}
main.chapter,
body.toc-page nav {
    max-width: 42em;
    margin: 0 auto;
    padding: 2.2em 1.4em 3em;
}
h1 {
    font-size: 1.8em;
    margin: 0 0 1.2em;
    text-align: center;
    line-height: 1.35;
}
h2 {
    font-size: 1.3em;
    margin: 1.6em 0 0.7em;
    line-height: 1.45;
}
h3 {
    font-size: 1.1em;
    margin: 1.2em 0 0.5em;
    line-height: 1.45;
}
p {
    text-indent: 2em;
    margin: 0;
}
p + p {
    margin-top: 0.55em;
}
blockquote {
    margin: 1em 1.5em;
    padding-left: 0.8em;
    border-left: 3px solid #ccc;
    color: #555;
    font-style: italic;
}
.footnotes {
    margin-top: 2.8em;
    padding-top: 1.2em;
    border-top: 1px solid #ddd;
}
.footnotes h2 {
    font-size: 1em;
    margin: 0 0 0.8em;
}
.footnote {
    font-size: 0.92em;
    color: #666;
    line-height: 1.5;
}
.footnote p {
    text-indent: 0;
}
.footnote + .footnote {
    margin-top: 0.6em;
}
.footnote-ref {
    font-size: 0.75em;
    line-height: 0;
    vertical-align: super;
}
nav ol {
    padding-left: 1.4em;
}
nav li + li {
    margin-top: 0.45em;
}
"""

_BLOCK_RENDERERS: dict[BlockType, str] = {
    BlockType.HEADING1: "<h1>{text}</h1>",
    BlockType.HEADING2: "<h2>{text}</h2>",
    BlockType.HEADING3: "<h3>{text}</h3>",
    BlockType.PARAGRAPH: "<p>{text}</p>",
    BlockType.QUOTE: "<blockquote><p>{text}</p></blockquote>",
    BlockType.FOOTNOTE: '<aside class="footnote"><p>{text}</p></aside>',
}


_FOOTNOTE_REF_RE = re.compile(r"\[\^(?P<number>\d{1,3})]")


def _render_text(text: str) -> str:
    escaped = escape(text)
    return _FOOTNOTE_REF_RE.sub(
        lambda match: f'<sup class="footnote-ref">{match.group("number")}</sup>',
        escaped,
    )


def _render_block(block: Block) -> str:
    template = _BLOCK_RENDERERS[block.type]
    return template.format(text=_render_text(block.text))


def _notes_label(language: str) -> str:
    if language.startswith("en"):
        return "Notes"
    if language.startswith("ko"):
        return "주석"
    return "注释"


def _toc_label(language: str) -> str:
    if language.startswith("en"):
        return "Contents"
    if language.startswith("ko"):
        return "목차"
    return "目录"


def _render_chapter_xhtml(chapter: Chapter, css: str, language: str) -> str:
    body_blocks = [block for block in chapter.blocks if block.type != BlockType.FOOTNOTE]
    footnote_blocks = [block for block in chapter.blocks if block.type == BlockType.FOOTNOTE]

    body_parts = [f"<h1>{escape(chapter.title)}</h1>"] if chapter.title else []
    body_parts.extend(_render_block(block) for block in body_blocks)

    if footnote_blocks:
        footnote_html = "\n".join(_render_block(block) for block in footnote_blocks)
        body_parts.append(
            '<section class="footnotes" epub:type="footnotes">\n'
            f"<h2>{escape(_notes_label(language))}</h2>\n"
            f"{footnote_html}\n"
            "</section>"
        )

    body_html = "\n".join(body_parts)

    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        f'<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="{escape(language)}">\n'
        "<head>\n"
        f"<title>{escape(chapter.title)}</title>\n"
        '<meta charset="utf-8" />\n'
        f"<style>{css}</style>\n"
        "</head>\n"
        f'<body>\n<main class="chapter">\n{body_html}\n</main>\n</body>\n'
        "</html>"
    )


def _render_nav_xhtml(book: Book) -> str:
    items = []
    for i, chapter in enumerate(book.chapters, 1):
        title = escape(chapter.title or f"Chapter {i}")
        items.append(f'<li><a href="chapter_{i}.xhtml">{title}</a></li>')
    nav_list = "\n".join(items)
    language = book.metadata.language

    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        f'<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="{escape(language)}">\n'
        "<head>\n"
        f"<title>{escape(book.metadata.title)}</title>\n"
        '<meta charset="utf-8" />\n'
        f"<style>{_EPUB_CSS}</style>\n"
        "</head>\n"
        '<body class="toc-page">\n'
        '<nav epub:type="toc">\n'
        f"<h1>{escape(_toc_label(language))}</h1>\n"
        f"<ol>\n{nav_list}\n</ol>\n"
        "</nav>\n"
        "</body>\n"
        "</html>"
    )


def _render_toc_ncx(book: Book, book_id: str) -> str:
    points = []
    for i, chapter in enumerate(book.chapters, 1):
        title = escape(chapter.title or f"Chapter {i}")
        points.append(
            f'<navPoint id="ch{i}" playOrder="{i}">\n'
            f"<navLabel><text>{title}</text></navLabel>\n"
            f'<content src="chapter_{i}.xhtml" />\n'
            f"</navPoint>"
        )
    nav_points = "\n".join(points)

    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">\n'
        "<head>\n"
        f'<meta name="dtb:uid" content="{book_id}" />\n'
        "</head>\n"
        f"<docTitle><text>{escape(book.metadata.title)}</text></docTitle>\n"
        f"<navMap>\n{nav_points}\n</navMap>\n"
        "</ncx>"
    )


def _render_content_opf(book: Book, book_id: str) -> str:
    manifest_items = [
        '<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav" />',
        '<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml" />',
        '<item id="css" href="style.css" media-type="text/css" />',
    ]
    spine_items = []
    for i in range(1, len(book.chapters) + 1):
        manifest_items.append(
            f'<item id="ch{i}" href="chapter_{i}.xhtml" media-type="application/xhtml+xml" />'
        )
        spine_items.append(f'<itemref idref="ch{i}" />')

    manifest = "\n".join(manifest_items)
    spine = "\n".join(spine_items)

    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid">\n'
        "<metadata "
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:opf="http://www.idpf.org/2007/opf">\n'
        f'<dc:identifier id="bookid">{book_id}</dc:identifier>\n'
        f"<dc:title>{escape(book.metadata.title)}</dc:title>\n"
        f"<dc:creator>{escape(book.metadata.author)}</dc:creator>\n"
        f"<dc:language>{book.metadata.language}</dc:language>\n"
        "</metadata>\n"
        f"<manifest>\n{manifest}\n</manifest>\n"
        f'<spine toc="ncx">\n{spine}\n</spine>\n'
        "</package>"
    )


def build_epub(book: Book, output_path: str | Path) -> Path:
    """Build an EPUB 3 file from a Book model."""
    if not book.chapters:
        raise ValueError("Cannot build an EPUB with no chapters.")

    path = Path(output_path)
    book_id = f"urn:uuid:{uuid.uuid4()}"

    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        # mimetype must be first entry and stored uncompressed
        zf.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)

        zf.writestr("META-INF/container.xml", (
            '<?xml version="1.0" encoding="utf-8"?>\n'
            '<container xmlns="urn:oasis:names:tc:opendocument:xmlns:container" version="1.0">\n'
            "<rootfiles>\n"
            '<rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml" />\n'
            "</rootfiles>\n"
            "</container>"
        ))

        zf.writestr("OEBPS/content.opf", _render_content_opf(book, book_id))
        zf.writestr("OEBPS/nav.xhtml", _render_nav_xhtml(book))
        zf.writestr("OEBPS/toc.ncx", _render_toc_ncx(book, book_id))
        zf.writestr("OEBPS/style.css", _EPUB_CSS)

        for i, chapter in enumerate(book.chapters, 1):
            zf.writestr(
                f"OEBPS/chapter_{i}.xhtml",
                _render_chapter_xhtml(chapter, _EPUB_CSS, book.metadata.language),
            )

    return path
