from __future__ import annotations

import re

from .book_model import Block, BlockType, Book, BookMetadata, Chapter
from .chapter_detector import HeadingLevel, detect_heading, inject_heading_markers
from .text_cleanup import cleanup_text


_HEADING_RE = re.compile(r"^(#{1,3})\s+(.+)$")
_QUOTE_RE = re.compile(r"^>\s*(.*)$")
# 脚注标记格式：^^^ [编号] 内容
_FOOTNOTE_RE = re.compile(r"^\^\^\^\s+\[(\d+)]\s+(.+)$")
_FOOTNOTE_BLOCK_NUMBER_RE = re.compile(r"^\[(\d+)]\s+(.+)$")


def _parse_blocks(lines: list[str]) -> list[Block]:
    blocks: list[Block] = []
    paragraph_lines: list[str] = []

    def _flush_paragraph() -> None:
        text = "\n".join(paragraph_lines).strip()
        if text:
            blocks.append(Block(type=BlockType.PARAGRAPH, text=text))
        paragraph_lines.clear()

    for line in lines:
        heading_match = _HEADING_RE.match(line)
        if heading_match:
            _flush_paragraph()
            level = len(heading_match.group(1))
            heading_type = {1: BlockType.HEADING1, 2: BlockType.HEADING2, 3: BlockType.HEADING3}[level]
            blocks.append(Block(type=heading_type, text=heading_match.group(2).strip()))
            continue

        quote_match = _QUOTE_RE.match(line)
        if quote_match:
            _flush_paragraph()
            quote_text = quote_match.group(1).strip()
            if quote_text:
                blocks.append(Block(type=BlockType.QUOTE, text=quote_text))
            continue

        # 脚注标记：^^^ [编号] 内容
        footnote_match = _FOOTNOTE_RE.match(line)
        if footnote_match:
            _flush_paragraph()
            marker = footnote_match.group(1)
            content = footnote_match.group(2).strip()
            blocks.append(Block(type=BlockType.FOOTNOTE, text=f"[{marker}] {content}"))
            continue

        if not line.strip():
            _flush_paragraph()
            continue

        paragraph_lines.append(line)

    _flush_paragraph()
    return blocks


def parse_markdown_to_book(
    text: str,
    *,
    metadata: BookMetadata | None = None,
    auto_detect_headings: bool = True,
) -> Book:
    """Parse Markdown text into a Book with chapters split on H1 headings.

    auto_detect_headings: 当文本中没有 Markdown 标题时，
        自动使用启发式规则检测章节/小节标题（支持中英日韩等语言）。
    """
    if metadata is None:
        metadata = BookMetadata()

    # 对原始文本进行清洗：过滤目录行、页眉页脚、标记脚注
    cleaned = cleanup_text(text)

    lines = cleaned.split("\n")
    all_blocks = _parse_blocks(lines)

    # 启发式标题检测会跳过已存在的 Markdown 标题，因此即使文本里已经
    # 有一部分 H1/H2（例如页面级重写出来的标题），仍然可以安全地对剩余
    # 纯文本行补充检测到的标题，避免后续的 Notes / Chapter X 等结构漏掉。
    if auto_detect_headings:
        marked_text = inject_heading_markers(
            cleaned,
            include_levels=(HeadingLevel.H1, HeadingLevel.H2),
        )
        all_blocks = _parse_blocks(marked_text.split("\n"))

    if not all_blocks:
        return Book(metadata=metadata, chapters=())

    # Split blocks into chapters on HEADING1 boundaries
    chapter_groups: list[tuple[str, list[Block]]] = []
    current_title = ""
    current_blocks: list[Block] = []

    for block in all_blocks:
        if block.type == BlockType.HEADING1:
            if current_blocks or current_title:
                chapter_groups.append((current_title, current_blocks))
            current_title = block.text
            current_blocks = []
        else:
            current_blocks.append(block)

    # Don't forget the last chapter
    if current_blocks or current_title:
        chapter_groups.append((current_title, current_blocks))

    # If no H1 found at all, wrap everything in one chapter
    if not chapter_groups:
        chapter_groups = [("", all_blocks)]

    # 过滤目录区域：开头连续出现的"标题多、正文少"的章节视为目录页残留
    chapter_groups = _strip_toc_chapters(chapter_groups)
    chapter_groups = _normalize_chapter_groups(chapter_groups)

    chapters = tuple(
        Chapter(title=title or f"Chapter {i}", blocks=tuple(blocks))
        for i, (title, blocks) in enumerate(chapter_groups, 1)
    )

    return Book(metadata=metadata, chapters=chapters)


_MIN_CONTENT_CHARS = 200  # 正文字数低于此值的章节视为"空章节"


def _strip_toc_chapters(
    groups: list[tuple[str, list[Block]]],
) -> list[tuple[str, list[Block]]]:
    """移除开头连续出现的目录区域章节。

    目录区域特征：连续多个章节的正文极短（主要是标题堆叠），
    通常出现在书籍正文之前。至少需要连续 3 个"空章节"才会触发过滤。
    """
    if len(groups) <= 3:
        return groups

    # 找出从开头开始连续的"空章节"区域
    toc_end = 0
    for i, (title, blocks) in enumerate(groups):
        content_len = sum(len(b.text) for b in blocks if b.type == BlockType.PARAGRAPH)
        if content_len >= _MIN_CONTENT_CHARS:
            break
        toc_end = i + 1

    # 至少连续 3 个空章节才视为目录区域
    if toc_end >= 3:
        return groups[toc_end:]

    return groups


_BARE_CHAPTER_TITLE_RE = re.compile(r"^第[一二三四五六七八九十百千零〇０-９0-9]+[章回部篇卷編编]$")
_FRONT_MATTER_KEYWORD_RE = re.compile(
    r"(?:ISBN|CIP|图书在版编目|編目|责任编辑|印刷|出版|定价|邮政编码|编委|版次|世纪出版"
    r"|Digitized by the Internet Archive|Kahle/Austin Foundation"
    r"|PENGUIN RANDOM HOUSE|copyright|specialmarkets@)",
    re.IGNORECASE,
)
_NOTES_CHAPTER_RE = re.compile(r"^(?:Notes|Endnotes|References)$", re.IGNORECASE)
_NOTES_SUBCHAPTER_RE = re.compile(
    r"^(?:Introduction|Chapter\s+\d+|Conclusion|Appendix|Acknowledg(?:e)?ments?)$",
    re.IGNORECASE,
)
_PROMOTIONAL_TITLE_RE = re.compile(
    r"^(?:Discover|Praise\s+for|About\s+the\s+Author|Also\s+by|More\s+from)\b",
    re.IGNORECASE,
)
_PROMOTIONAL_TEXT_RE = re.compile(
    r"(?:bestselling author|packed with evidence-based|will teach you how to|practical and useful book)",
    re.IGNORECASE,
)
_PROMOTIONAL_ATTRIBUTION_RE = re.compile(r"^[—-][A-Z][A-Z0-9 ,.*&-]{6,}$")


def _normalize_chapter_groups(
    groups: list[tuple[str, list[Block]]],
) -> list[tuple[str, list[Block]]]:
    groups = _strip_leading_front_matter_chapter(groups)
    normalized: list[tuple[str, list[Block]]] = []
    for title, blocks in groups:
        merged_title, merged_blocks = _merge_split_chapter_title(title, blocks)
        normalized.append((merged_title, _move_footnotes_to_end(merged_blocks)))
    normalized = _merge_adjacent_duplicate_chapters(normalized)
    normalized = _merge_short_uppercase_interstitials(normalized)
    normalized = _merge_adjacent_duplicate_chapters(normalized)
    normalized = _merge_notes_backmatter_chapters(normalized)
    normalized = _merge_adjacent_duplicate_chapters(normalized)
    return _strip_trailing_promotional_chapters(normalized)


def _strip_leading_front_matter_chapter(
    groups: list[tuple[str, list[Block]]],
) -> list[tuple[str, list[Block]]]:
    while len(groups) > 1:
        title, blocks = groups[0]
        if title.strip():
            break
        text = "\n".join(block.text for block in blocks if block.type != BlockType.FOOTNOTE)
        if not _looks_like_front_matter_text(text):
            break
        groups = groups[1:]
    return groups


def _looks_like_front_matter_text(text: str) -> bool:
    if not text.strip():
        return True
    keyword_hits = len(_FRONT_MATTER_KEYWORD_RE.findall(text))
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return True
    short_lines = sum(1 for line in lines if len(line) <= 24)
    medium_lines = sum(1 for line in lines if len(line) <= 40)
    long_lines = sum(1 for line in lines if len(line) >= 60)
    url_hits = sum("http" in line.lower() or "@" in line for line in lines)
    money_hits = sum(bool(re.search(r"(?:U\.S\.A\.|Canada|\$)\s*\$?\d", line)) for line in lines)
    noise_lines = sum(
        1
        for line in lines
        if len(line) <= 22 and not re.search(r"[。！？!?；;：:.,]$", line)
    )
    gibberish_lines = sum(1 for line in lines if _looks_like_gibberish_front_matter_line(line))
    coverish_lines = sum(1 for line in lines[:8] if _looks_like_coverish_front_matter_line(line))
    if keyword_hits >= 1 and medium_lines >= max(4, len(lines) // 3):
        return True
    if keyword_hits >= 3:
        return True
    if url_hits >= 1 and medium_lines >= max(4, len(lines) // 2):
        return True
    if keyword_hits >= 2 and (url_hits >= 1 or money_hits >= 1):
        return True
    if money_hits >= 1 and medium_lines >= max(6, (len(lines) * 2) // 3):
        return True
    if keyword_hits >= 1 and noise_lines >= max(8, len(lines) // 3):
        return True
    if keyword_hits >= 1 and gibberish_lines >= max(10, len(lines) // 5):
        return True
    if gibberish_lines >= max(16, len(lines) // 4):
        return True
    if coverish_lines >= 2 and gibberish_lines >= 2:
        return True
    if coverish_lines >= 2 and noise_lines >= 3 and long_lines <= 1:
        return True
    if coverish_lines + gibberish_lines >= 3 and long_lines == 0 and len(lines) <= 8:
        return True
    return short_lines >= max(8, (len(lines) * 2) // 3) and long_lines <= 2


def _looks_like_gibberish_front_matter_line(line: str) -> bool:
    stripped = line.strip()
    if len(stripped) < 4 or len(stripped) > 36:
        return False
    if re.search(r"https?://|ISBN|copyright|archive|penguin|foundation", stripped, re.IGNORECASE):
        return False

    letters = re.findall(r"[A-Za-z]", stripped)
    if len(letters) < 4:
        return False

    vowels = sum(char.lower() in "aeiouy" for char in letters)
    uppercase = sum(char.isupper() for char in letters)
    repeated_runs = len(re.findall(r"(.)\1{2,}", stripped))
    weird_punct = len(re.findall(r"[*+=~|_><]", stripped))

    return (
        vowels <= max(1, len(letters) // 6)
        or repeated_runs >= 1
        or weird_punct >= 1
        or uppercase >= len(letters) * 0.8
    )


def _looks_like_coverish_front_matter_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > 48:
        return False
    if re.search(r"[。！？!?；;：:.,]$", stripped):
        return False
    words = re.findall(r"[A-Za-z][A-Za-z'’-]*", stripped)
    if not words:
        return False
    if len(words) > 8:
        return False
    titled_words = sum(word[0].isupper() or word.isupper() for word in words)
    return titled_words >= max(2, len(words) - 1)


def _merge_split_chapter_title(
    title: str,
    blocks: list[Block],
) -> tuple[str, list[Block]]:
    if not title or not blocks:
        return title, blocks
    if not _BARE_CHAPTER_TITLE_RE.match(title):
        return title, blocks
    first_block = blocks[0]
    if first_block.type != BlockType.PARAGRAPH:
        return title, blocks

    subtitle = first_block.text.strip()
    if not subtitle or len(subtitle) > 40:
        return title, blocks
    if "[^" in subtitle or any(mark in subtitle for mark in "#>*[]"):
        return title, blocks
    if any(mark in subtitle for mark in "\n。！？!?；;：:"):
        return title, blocks
    if _looks_like_all_caps_subtitle_fragment(subtitle):
        return title, blocks

    return f"{title} {subtitle}", blocks[1:]


def _move_footnotes_to_end(blocks: list[Block]) -> list[Block]:
    body_blocks = [block for block in blocks if block.type != BlockType.FOOTNOTE]
    footnotes = _merge_duplicate_footnotes([block for block in blocks if block.type == BlockType.FOOTNOTE])
    return [*body_blocks, *footnotes]


def _looks_like_all_caps_subtitle_fragment(text: str) -> bool:
    letters = [char for char in text if char.isalpha()]
    if len(letters) < 12:
        return False
    uppercase = sum(char.isupper() for char in letters)
    return uppercase >= int(len(letters) * 0.85)


def _merge_notes_backmatter_chapters(
    groups: list[tuple[str, list[Block]]],
) -> list[tuple[str, list[Block]]]:
    merged_groups: list[tuple[str, list[Block]]] = []
    index = 0
    while index < len(groups):
        title, blocks = groups[index]
        if not _NOTES_CHAPTER_RE.match(title):
            merged_groups.append((title, blocks))
            index += 1
            continue

        merged_blocks = list(blocks)
        cursor = index + 1
        while cursor < len(groups):
            sub_title, sub_blocks = groups[cursor]
            if _NOTES_CHAPTER_RE.match(sub_title):
                merged_blocks.extend(sub_blocks)
                cursor += 1
                continue
            if _looks_like_noisy_notes_continuation_title(sub_title):
                merged_blocks.extend(sub_blocks)
                cursor += 1
                continue
            if not _NOTES_SUBCHAPTER_RE.match(sub_title):
                break
            merged_blocks.append(Block(type=BlockType.HEADING2, text=sub_title))
            merged_blocks.extend(sub_blocks)
            cursor += 1

        merged_groups.append((title, merged_blocks))
        index = cursor

    return merged_groups


def _looks_like_noisy_notes_continuation_title(title: str) -> bool:
    stripped = title.strip()
    if not stripped or _NOTES_CHAPTER_RE.match(stripped) or _NOTES_SUBCHAPTER_RE.match(stripped):
        return False
    normalized = re.sub(r"[^a-z]", "", stripped.casefold())
    return "notes" in normalized and len(stripped) <= 32


def _strip_trailing_promotional_chapters(
    groups: list[tuple[str, list[Block]]],
) -> list[tuple[str, list[Block]]]:
    trimmed = list(groups)
    while len(trimmed) > 1 and _looks_like_promotional_backmatter_chapter(*trimmed[-1]):
        trimmed.pop()
    return trimmed


def _looks_like_promotional_backmatter_chapter(title: str, blocks: list[Block]) -> bool:
    stripped = title.strip()
    if not stripped or not _PROMOTIONAL_TITLE_RE.match(stripped):
        return False

    text = "\n".join(block.text for block in blocks if block.text).strip()
    if not text or len(text) > 1600:
        return False

    lines = [line.strip() for line in text.splitlines() if line.strip()]
    promo_hits = len(_PROMOTIONAL_TEXT_RE.findall(text))
    attribution_hits = sum(
        1
        for line in lines
        if _PROMOTIONAL_ATTRIBUTION_RE.match(line) or "BESTSELLING AUTHOR" in line.upper()
    )
    return promo_hits >= 1 and attribution_hits >= 2


def _merge_adjacent_duplicate_chapters(
    groups: list[tuple[str, list[Block]]],
) -> list[tuple[str, list[Block]]]:
    if not groups:
        return groups

    merged: list[tuple[str, list[Block]]] = []
    for title, blocks in groups:
        if not merged:
            merged.append((title, list(blocks)))
            continue

        previous_title, previous_blocks = merged[-1]
        if not _titles_should_merge(previous_title, title):
            merged.append((title, list(blocks)))
            continue

        previous_key = _normalized_title_key(previous_title)
        current_key = _normalized_title_key(title)
        merged_title = previous_title or title
        appended_blocks = list(blocks)
        current_suffix = _extract_title_suffix(previous_title, title)
        previous_suffix = _extract_title_suffix(title, previous_title)
        if current_suffix:
            appended_blocks.insert(0, Block(type=BlockType.HEADING2, text=current_suffix))
        elif len(current_key) > len(previous_key):
            merged_title = title or previous_title
        elif previous_suffix:
            merged_title = title or previous_title
            previous_blocks.insert(0, Block(type=BlockType.HEADING2, text=previous_suffix))

        previous_blocks.extend(appended_blocks)
        merged[-1] = (merged_title, previous_blocks)

    return merged


_INTERSTITIAL_TITLE_RE = re.compile(r"[A-Z]{4,}")
_INTERSTITIAL_MAX_PARAGRAPH_CHARS = 2500
_INTERSTITIAL_KEYWORD_RE = re.compile(
    r"(?:make it|examples of|inversion of|chapter summary|how to create a good habit|how to break a bad habit|mismatch between immediate and delayed rewards|deliberate practice\s*=\s*mastery)",
    re.IGNORECASE,
)


def _merge_short_uppercase_interstitials(
    groups: list[tuple[str, list[Block]]],
) -> list[tuple[str, list[Block]]]:
    if len(groups) <= 1:
        return groups

    merged: list[tuple[str, list[Block]]] = []
    for title, blocks in groups:
        if not merged or not _should_merge_into_previous_chapter(title, blocks):
            merged.append((title, list(blocks)))
            continue

        previous_title, previous_blocks = merged[-1]
        if _should_keep_interstitial_heading(title, previous_blocks):
            previous_blocks.append(Block(type=BlockType.HEADING2, text=title))
        previous_blocks.extend(blocks)
        merged[-1] = (previous_title, previous_blocks)

    return merged


def _should_merge_into_previous_chapter(title: str, blocks: list[Block]) -> bool:
    stripped = title.strip()
    if not stripped:
        return False
    if _NOTES_CHAPTER_RE.match(stripped) or _NOTES_SUBCHAPTER_RE.match(stripped):
        return False
    if _INTERSTITIAL_KEYWORD_RE.search(stripped):
        return True
    is_explicit_top_level_heading = detect_heading(stripped) == HeadingLevel.H1
    if _looks_like_uppercase_interstitial_title(stripped) and not is_explicit_top_level_heading:
        return True
    if not _looks_like_uppercase_interstitial_title(stripped):
        return False

    paragraph_chars = sum(len(block.text) for block in blocks if block.type == BlockType.PARAGRAPH)
    return paragraph_chars <= _INTERSTITIAL_MAX_PARAGRAPH_CHARS


def _looks_like_uppercase_interstitial_title(title: str) -> bool:
    if _INTERSTITIAL_KEYWORD_RE.search(title):
        return True
    letters = [char for char in title if char.isalpha()]
    if not letters:
        return False
    uppercase_letters = sum(char.isupper() for char in letters)
    if uppercase_letters < max(4, int(len(letters) * 0.7)):
        return False
    return _INTERSTITIAL_TITLE_RE.search(title) is not None


def _should_keep_interstitial_heading(title: str, previous_blocks: list[Block]) -> bool:
    if "=" not in title:
        return True
    normalized_title = _normalized_title_key(title)
    if not normalized_title:
        return True
    for block in previous_blocks:
        if block.type != BlockType.PARAGRAPH:
            continue
        if normalized_title in _normalized_title_key(block.text):
            return False
    return True


def _normalized_title_key(title: str) -> str:
    return re.sub(r"[\W_]+", "", title.casefold())


def _extract_title_suffix(base_title: str, extended_title: str) -> str:
    if not base_title or not extended_title or not extended_title.startswith(base_title):
        return ""
    suffix = extended_title[len(base_title):].strip(" :-")
    if not suffix or not _looks_like_all_caps_subtitle_fragment(suffix):
        return ""
    return suffix


def _titles_should_merge(previous_title: str, current_title: str) -> bool:
    previous_key = _normalized_title_key(previous_title)
    current_key = _normalized_title_key(current_title)
    if previous_key == current_key:
        return True
    if not previous_key or not current_key:
        return False
    if previous_key == "conclusion" and current_key.startswith("conclusion"):
        return True
    if current_key == "conclusion" and previous_key.startswith("conclusion"):
        return True
    if len(previous_key) >= 12 and current_key.startswith(previous_key):
        return True
    if len(current_key) >= 12 and previous_key.startswith(current_key):
        return True
    return False


def _merge_duplicate_footnotes(blocks: list[Block]) -> list[Block]:
    merged: list[Block] = []
    last_index_by_number: dict[str, int] = {}

    for block in blocks:
        match = _FOOTNOTE_BLOCK_NUMBER_RE.match(block.text)
        if match is None:
            merged.append(block)
            continue

        number = match.group(1)
        content = match.group(2).strip()
        existing_index = last_index_by_number.get(number)
        if existing_index is None:
            last_index_by_number[number] = len(merged)
            merged.append(block)
            continue

        existing = merged[existing_index]
        existing_match = _FOOTNOTE_BLOCK_NUMBER_RE.match(existing.text)
        assert existing_match is not None
        existing_content = existing_match.group(2).strip()
        merged_content = f"{existing_content} {content}".strip()
        merged[existing_index] = Block(type=BlockType.FOOTNOTE, text=f"[{number}] {merged_content}")

    return merged
