from __future__ import annotations

import os
from collections.abc import Callable
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass
from pathlib import Path
import re
from threading import Event, Lock, Thread
from time import monotonic
from typing import Any

from openai import OpenAI

from .pdf_page_images import render_pdf_pages_as_data_urls
from .pdf_reader import PDFDocumentText, PDFPageText


DEFAULT_RECOGNITION_PROMPT = (
    "你是电子书排版前处理助手。"
    "输入可能来自 PDF 页面图像或文本层提取。"
    "请清理 OCR/PDF 提取噪声，修复明显断词和断行问题，"
    "但不要新增原文中不存在的信息。"
    "只输出纯文本，不要加解释。"
)

DEFAULT_STRUCTURE_PROMPT = (
    "你是电子书排版助手。输入可能来自 PDF 页面图像或文本层提取。\n"
    "请对以下原始内容进行 OCR/结构化处理：\n"
    "1. 清理 OCR/PDF 提取噪声，修复断词和断行问题。\n"
    "2. 识别文本结构，用 Markdown 格式输出：\n"
    "   - 章节标题用 # 标记\n"
    "   - 小节标题用 ## 或 ### 标记\n"
    "   - 引用内容用 > 标记\n"
    "   - 普通段落直接输出\n"
    "3. 不要新增原文中不存在的信息。\n"
    "4. 只输出 Markdown 格式的正文，不要加任何解释。"
)


class LLMRecognitionError(RuntimeError):
    """Raised when LLM-based text recognition fails."""


@dataclass(frozen=True, slots=True)
class RunningBatch:
    batch_index: int
    page_start: int
    page_end: int
    started_at: float


@dataclass(frozen=True, slots=True)
class RecognitionProgress:
    completed: int
    total: int
    running_batches: tuple[RunningBatch, ...] = ()


@dataclass(frozen=True, slots=True)
class OpenAICompatibleConfig:
    model: str
    base_url: str
    api_key: str = "dummy"
    temperature: float = 0.0
    timeout_seconds: float = 120.0


def resolve_openai_compatible_config(
    *,
    model: str | None = None,
    base_url: str | None = None,
    api_key: str | None = None,
    temperature: float = 0.0,
    timeout_seconds: float = 120.0,
) -> OpenAICompatibleConfig:
    resolved_model = (
        os.getenv("PDF2EPUB_LLM_MODEL")
        or os.getenv("OPENAI_MODEL")
        or model
        or ""
    ).strip()
    if not resolved_model:
        raise ValueError(
            "LLM model is required. Pass --llm-model or set PDF2EPUB_LLM_MODEL."
        )

    resolved_base_url = (
        os.getenv("PDF2EPUB_LLM_BASE_URL")
        or os.getenv("OPENAI_BASE_URL")
        or base_url
        or ""
    ).strip()
    if not resolved_base_url:
        raise ValueError(
            "LLM base URL is required. Pass --llm-base-url or set PDF2EPUB_LLM_BASE_URL."
        )

    resolved_api_key = (
        os.getenv("PDF2EPUB_LLM_API_KEY")
        or os.getenv("OPENAI_API_KEY")
        or api_key
        or "dummy"
    )
    if timeout_seconds <= 0:
        raise ValueError("LLM timeout must be greater than 0.")
    if temperature < 0 or temperature > 2:
        raise ValueError("LLM temperature must be between 0 and 2.")

    return OpenAICompatibleConfig(
        model=resolved_model,
        base_url=resolved_base_url,
        api_key=resolved_api_key,
        temperature=temperature,
        timeout_seconds=timeout_seconds,
    )


def _normalize_text(raw_text: str) -> str:
    return raw_text.replace("\r\n", "\n").replace("\r", "\n").strip()


def _extract_response_text(response: Any) -> str:
    choices = getattr(response, "choices", None)
    if not choices:
        return ""

    message = getattr(choices[0], "message", None)
    content = getattr(message, "content", "")

    if isinstance(content, str):
        return _normalize_text(content)

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
                continue
            if isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
                continue
            text = getattr(item, "text", None)
            if isinstance(text, str):
                parts.append(text)
        return _normalize_text("\n".join(parts))

    return ""


class OpenAITextRecognizer:
    def __init__(self, *, config: OpenAICompatibleConfig, client: Any | None = None) -> None:
        self._config = config
        self._client = client or OpenAI(
            base_url=config.base_url,
            api_key=config.api_key,
            timeout=config.timeout_seconds,
            max_retries=0,
        )

    def recognize_page(
        self,
        page: PDFPageText,
        *,
        prompt: str = DEFAULT_RECOGNITION_PROMPT,
        source: Path | None = None,
    ) -> PDFPageText:
        if not page.text and source is None:
            return page

        if _page_prefers_vision(page):
            user_input = _build_page_image_user_input(page, source)
        else:
            user_input = (
                f"以下是 PDF 第 {page.number} 页提取出的原始文本，请进行识别修复并仅返回文本：\n"
                f"{page.text}"
            )
        try:
            response = self._client.chat.completions.create(
                model=self._config.model,
                temperature=self._config.temperature,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": user_input},
                ],
            )
        except Exception as exc:
            raise LLMRecognitionError(f"Failed to call LLM for page {page.number}.") from exc

        recognized_text = _strip_prompt_echo(_extract_response_text(response))
        if not recognized_text:
            if _page_prefers_vision(page):
                return PDFPageText(number=page.number, text="")
            raise LLMRecognitionError(
                f"LLM returned empty content for page {page.number}. "
                "Please check model output format."
            )
        if _page_prefers_vision(page):
            recognized_text = _promote_single_page_title_markdown(recognized_text)

        return PDFPageText(number=page.number, text=recognized_text)

    def recognize_document(
        self,
        document: PDFDocumentText,
        *,
        prompt: str = DEFAULT_RECOGNITION_PROMPT,
    ) -> PDFDocumentText:
        has_extractable_text = any(page.text.strip() for page in document.pages)
        recognized_pages = tuple(
            self.recognize_page(page, prompt=prompt, source=document.source)
            if (page.text or not has_extractable_text)
            else page
            for page in document.pages
        )
        return PDFDocumentText(source=document.source, pages=recognized_pages, metadata=document.metadata)

    def recognize_page_batch(
        self,
        pages: list[PDFPageText],
        *,
        prompt: str = DEFAULT_RECOGNITION_PROMPT,
        source: Path | None = None,
    ) -> str:
        """Send multiple consecutive pages as a single LLM request for cross-page context."""
        included_pages = [p for p in pages if p.text or source is not None]
        if not included_pages:
            return ""

        image_page_numbers = [
            page.number for page in included_pages if _page_prefers_vision(page)
        ]
        image_urls: dict[int, str] = {}
        if image_page_numbers:
            if source is None:
                included_pages = [p for p in included_pages if not _page_prefers_vision(p)]
                if not included_pages:
                    return ""
            else:
                try:
                    image_urls = render_pdf_pages_as_data_urls(source, image_page_numbers)
                except Exception as exc:
                    page_range = f"{image_page_numbers[0]}-{image_page_numbers[-1]}"
                    raise LLMRecognitionError(
                        f"Failed to render PDF page images for pages {page_range}."
                    ) from exc

        if image_urls:
            user_input = _build_batch_multimodal_user_input(included_pages, image_urls)
        else:
            page_sections = []
            for page in included_pages:
                page_sections.append(f"--- 第 {page.number} 页 ---\n{page.text}")
            combined = "\n\n".join(page_sections)
            user_input = (
                f"以下是 PDF 第 {included_pages[0].number}-{included_pages[-1].number} 页提取出的原始文本，"
                f"请进行识别修复并仅返回文本：\n{combined}"
            )
        try:
            response = self._client.chat.completions.create(
                model=self._config.model,
                temperature=self._config.temperature,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": user_input},
                ],
            )
        except Exception as exc:
            page_range = f"{included_pages[0].number}-{included_pages[-1].number}"
            raise LLMRecognitionError(f"Failed to call LLM for pages {page_range}.") from exc

        recognized_text = _strip_prompt_echo(_extract_response_text(response))
        if not recognized_text:
            if image_urls and len(included_pages) == 1 and _page_prefers_vision(included_pages[0]):
                return ""
            page_range = f"{included_pages[0].number}-{included_pages[-1].number}"
            raise LLMRecognitionError(
                f"LLM returned empty content for pages {page_range}. "
                "Please check model output format."
            )
        if image_urls and len(included_pages) == 1:
            recognized_text = _promote_single_page_title_markdown(recognized_text)

        return recognized_text

    def recognize_document_concurrent(
        self,
        document: PDFDocumentText,
        *,
        prompt: str = DEFAULT_RECOGNITION_PROMPT,
        batch_size: int = 1,
        max_workers: int = 4,
        on_progress: Callable[[int, int], None] | None = None,
        on_update: Callable[[RecognitionProgress], None] | None = None,
        heartbeat_seconds: float = 5.0,
    ) -> PDFDocumentText:
        """Recognize document pages concurrently in batches for cross-page context."""
        if batch_size <= 0:
            raise ValueError("batch_size must be greater than 0.")
        if max_workers <= 0:
            raise ValueError("max_workers must be greater than 0.")
        if heartbeat_seconds <= 0:
            raise ValueError("heartbeat_seconds must be greater than 0.")

        has_extractable_text = any(page.text.strip() for page in document.pages)
        candidate_pages = (
            [p for p in document.pages if p.text]
            if has_extractable_text
            else list(document.pages)
        )
        if not candidate_pages:
            return document

        # Build batches of consecutive non-empty pages
        batches: list[list[PDFPageText]] = []
        for i in range(0, len(candidate_pages), batch_size):
            batches.append(candidate_pages[i : i + batch_size])

        total = len(batches)
        results: dict[int, str] = {}
        running_batches: dict[int, RunningBatch] = {}
        progress_lock = Lock()
        update_lock = Lock()
        heartbeat_stop = Event()
        completed = 0

        def _snapshot_locked() -> RecognitionProgress:
            return RecognitionProgress(
                completed=completed,
                total=total,
                running_batches=tuple(
                    sorted(running_batches.values(), key=lambda batch: batch.batch_index)
                ),
            )

        def _emit_update(snapshot: RecognitionProgress | None = None) -> None:
            if on_update is None:
                return
            if snapshot is None:
                with progress_lock:
                    snapshot = _snapshot_locked()
            with update_lock:
                on_update(snapshot)

        def _heartbeat() -> None:
            while not heartbeat_stop.wait(heartbeat_seconds):
                with progress_lock:
                    if completed >= total or not running_batches:
                        continue
                    snapshot = _snapshot_locked()
                _emit_update(snapshot)

        def _process_batch(batch_index: int, batch: list[PDFPageText]) -> tuple[int, str]:
            with progress_lock:
                running_batches[batch_index] = RunningBatch(
                    batch_index=batch_index,
                    page_start=batch[0].number,
                    page_end=batch[-1].number,
                    started_at=monotonic(),
                )
                snapshot = _snapshot_locked()
            _emit_update(snapshot)
            text = self.recognize_page_batch(batch, prompt=prompt, source=document.source)
            return batch_index, text

        heartbeat_thread = Thread(target=_heartbeat, name="pdf2epub-progress", daemon=True)
        heartbeat_thread.start()

        try:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                remaining_batches = list(enumerate(batches))
                in_flight: dict[Any, int] = {}

                def _submit_next_batch() -> bool:
                    if not remaining_batches:
                        return False
                    batch_index, batch = remaining_batches.pop(0)
                    future = executor.submit(_process_batch, batch_index, batch)
                    in_flight[future] = batch_index
                    return True

                for _ in range(min(max_workers, total)):
                    _submit_next_batch()

                while in_flight:
                    done, _ = wait(in_flight, return_when=FIRST_COMPLETED)
                    for future in done:
                        future_batch_index = in_flight.pop(future)
                        try:
                            batch_index, text = future.result()
                        except Exception:
                            with progress_lock:
                                running_batches.pop(future_batch_index, None)
                                snapshot = _snapshot_locked()
                            _emit_update(snapshot)
                            for pending_future in in_flight:
                                pending_future.cancel()
                            in_flight.clear()
                            remaining_batches.clear()
                            raise

                        with progress_lock:
                            running_batches.pop(batch_index, None)
                            results[batch_index] = text
                            completed += 1
                            snapshot = _snapshot_locked()
                        if on_progress:
                            on_progress(completed, total)
                        _emit_update(snapshot)
                        _submit_next_batch()
        finally:
            heartbeat_stop.set()
            heartbeat_thread.join(timeout=0.1)

        # Combine batch results in order
        combined_text = "\n\n".join(results[i] for i in range(total))

        # Build a single-page document with all recognized text combined
        recognized_page = PDFPageText(number=1, text=combined_text)
        return PDFDocumentText(
            source=document.source,
            pages=(recognized_page,),
            metadata=document.metadata,
        )


def _page_prefers_vision(page: PDFPageText) -> bool:
    return not page.text.strip()


def _build_page_image_user_input(
    page: PDFPageText,
    source: Path | None,
) -> list[dict[str, Any]]:
    if source is None:
        raise LLMRecognitionError(
            f"PDF source path is required for image OCR on page {page.number}."
        )
    image_url = render_pdf_pages_as_data_urls(source, [page.number])[page.number]
    return [
        {
            "type": "text",
            "text": (
                f"以下是 PDF 第 {page.number} 页的页面图像。"
                "请先进行 OCR，再清理噪声并仅返回正文文本，不要解释。"
            ),
        },
        {"type": "image_url", "image_url": {"url": image_url}},
    ]


def _build_batch_multimodal_user_input(
    pages: list[PDFPageText],
    image_urls: dict[int, str],
) -> list[dict[str, Any]]:
    content: list[dict[str, Any]] = [
        {
            "type": "text",
            "text": (
                f"以下是 PDF 第 {pages[0].number}-{pages[-1].number} 页的原始内容。"
                "有些页提供页面图像，有些页提供文本层提取结果。"
                "请按页码顺序进行 OCR/清洗/结构化，只输出正文 Markdown，不要解释。"
            ),
        }
    ]
    for page in pages:
        if page.number in image_urls:
            content.append(
                {
                    "type": "text",
                    "text": f"--- 第 {page.number} 页（页面图像）---",
                }
            )
            content.append(
                {
                    "type": "image_url",
                    "image_url": {"url": image_urls[page.number]},
                }
            )
        else:
            content.append(
                {
                    "type": "text",
                    "text": f"--- 第 {page.number} 页（提取文本）---\n{page.text}",
                }
            )
    return content


def _promote_single_page_title_markdown(text: str) -> str:
    text = _strip_prompt_echo(text)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return text
    if len(lines) == 1 and _looks_like_short_title_line(lines[0]):
        return f"# {lines[0]}"
    if (
        1 < len(lines) <= 3
        and sum(len(line) for line in lines) <= 36
        and all(_looks_like_short_title_line(line) for line in lines)
    ):
        return "# " + " ".join(lines)
    return text


def _looks_like_short_title_line(line: str) -> bool:
    stripped = line.strip()
    if len(stripped) < 2 or len(stripped) > 24:
        return False
    if any(mark in stripped for mark in "，。！？；：:;,.!?"):
        return False
    cjk_count = sum("\u4e00" <= char <= "\u9fff" for char in stripped)
    if cjk_count < 2:
        return False
    if stripped.startswith(("的", "了", "在", "是")):
        return False
    return True


def _strip_prompt_echo(text: str) -> str:
    lines = text.splitlines()
    cleaned = [
        line
        for line in lines
        if line.strip() and not _looks_like_prompt_echo_line(line.strip())
    ]
    return "\n".join(cleaned).strip()


def _looks_like_prompt_echo_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if stripped.startswith("你是电子书排版助手。输入可能来自 PDF 页面图像或文本层提取。"):
        return True
    if stripped.startswith("请对以下原始内容进行 OCR/结构化处理："):
        return True
    if re.match(r"^\d+\.\s*", stripped):
        return any(
            phrase in stripped
            for phrase in (
                "清理 OCR/PDF 提取噪声",
                "识别文本结构，用 Markdown 格式输出",
                "不要新增原文中不存在的信息",
                "只输出 Markdown 格式的正文",
            )
        )
    if stripped.startswith(("- ", "-\u00a0", "• ", "•\u00a0")):
        return any(
            phrase in stripped
            for phrase in (
                "章节标题用 # 标记",
                "小节标题用 ## 或 ### 标记",
                "引用内容用 > 标记",
                "普通段落直接输出",
            )
        )
    if re.match(r"^以下是 PDF 第 \d+(?:-\d+)? 页(?:的原始内容|的页面图像)", stripped):
        return True
    if re.match(r"^--- 第 \d+ 页（(?:页面图像|提取文本)）---$", stripped):
        return True
    return False
