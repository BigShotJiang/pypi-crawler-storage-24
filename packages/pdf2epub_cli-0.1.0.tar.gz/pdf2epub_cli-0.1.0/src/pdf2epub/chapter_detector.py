"""启发式章节标题检测器，支持多语言。

对纯文本行进行扫描，识别出章节/小节标题模式，
返回对应的标题层级。用于 native 模式下无 LLM 时的自动分章。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum


class HeadingLevel(Enum):
    """检测到的标题层级。"""

    H1 = 1  # 章级标题（第X章、Chapter X 等）
    H2 = 2  # 节级标题（一、、Section 1 等）


@dataclass(frozen=True, slots=True)
class HeadingRule:
    """一条标题匹配规则。"""

    pattern: re.Pattern[str]
    level: HeadingLevel
    description: str


# ── 中文 / 日文章节模式 ──────────────────────────────────────
# 中文数字字符集（含〇和全角数字）
_CJK_NUM = r"[一二三四五六七八九十百千零〇０-９0-9]+"
_CJK_SPACED_SECTION_NUM = r"[一二三四五六七八九十百千零〇]+"

_CJK_RULES: list[HeadingRule] = [
    # 第X章 / 第X回（小说常用）
    HeadingRule(
        re.compile(rf"^第{_CJK_NUM}[章回](?:$|\s+|[：:\"'「『（(]).*$"),
        HeadingLevel.H1,
        "中文/日文：第X章、第X回",
    ),
    # 第X部 / 第X篇 / 第X卷 / 第X编
    HeadingRule(
        re.compile(rf"^第{_CJK_NUM}[部篇卷編编](?:$|\s+|[：:\"'「『（(]).*$"),
        HeadingLevel.H1,
        "中文/日文：第X部、第X篇、第X卷、第X编",
    ),
    # 卷一、卷二（无"第"字）
    HeadingRule(
        re.compile(rf"^[卷篇]{_CJK_NUM}\s*.*$"),
        HeadingLevel.H1,
        "中文：卷X、篇X",
    ),
    # 前言、序言、导论、后记、附录等独立章节
    HeadingRule(
        re.compile(
            r"^(?:前言|序言|序|緒論|绪论|導論|导论|引言|楔子|後記|后记"
            r"|附錄|附录|跋|結語|结语|尾聲|尾声|致謝|致谢|参考文献|參考文獻)\s*$"
        ),
        HeadingLevel.H1,
        "中文：前言、导论、后记等独立章节",
    ),
    # 中文数字小节编号：一、 二、 三、
    HeadingRule(
        re.compile(rf"^{_CJK_NUM}[、．.]\s*\S.*$"),
        HeadingLevel.H2,
        "中文：一、xxx 小节编号",
    ),
    # 一 卖草鞋碰了壁 / 二 拉黄包车也不成
    HeadingRule(
        re.compile(
            rf"^[“\"'『「]?(?:{_CJK_SPACED_SECTION_NUM})\s+\S.{{1,40}}[”\"'』」]?$"
        ),
        HeadingLevel.H2,
        "中文：一 标题 / 二 标题",
    ),
]

# ── 英文章节模式 ──────────────────────────────────────────────
_EN_RULES: list[HeadingRule] = [
    # Chapter 1 / Chapter I / CHAPTER ONE
    HeadingRule(
        re.compile(
            r"^(?:CHAPTER|Chapter|chapter)\s+"
            r"(?:\d+|[IVXLCDM]+|[ivxlcdm]+"
            r"|One|Two|Three|Four|Five|Six|Seven|Eight|Nine|Ten"
            r"|Eleven|Twelve|Thirteen|Fourteen|Fifteen"
            r"|Twenty|Thirty|Forty|Fifty)"
            r"(?:\s.*|\..*)?$",
            re.IGNORECASE,
        ),
        HeadingLevel.H1,
        "英文：Chapter X",
    ),
    # Part 1 / PART II / Part One
    HeadingRule(
        re.compile(
            r"^(?:PART|Part|part)\s+"
            r"(?:\d+|[IVXLCDM]+|[ivxlcdm]+"
            r"|One|Two|Three|Four|Five|Six|Seven|Eight|Nine|Ten)"
            r"(?:\s.*|\..*)?$",
            re.IGNORECASE,
        ),
        HeadingLevel.H1,
        "英文：Part X",
    ),
    # Book 1 / Volume 2
    HeadingRule(
        re.compile(
            r"^(?:BOOK|Book|VOLUME|Volume)\s+(?:\d+|[IVXLCDM]+|[ivxlcdm]+)"
            r"(?:\s.*|\..*)?$",
            re.IGNORECASE,
        ),
        HeadingLevel.H1,
        "英文：Book X / Volume X",
    ),
    # Prologue, Epilogue, Foreword, Preface, etc.
    HeadingRule(
        re.compile(
            r"^(?:Prologue|Epilogue|Foreword|Preface|Introduction"
            r"|Afterword|Appendix|Acknowledg(?:e)?ments?"
            r"|Bibliography|Conclusion|Summary|Notes|Endnotes|References)\s*$",
            re.IGNORECASE,
        ),
        HeadingLevel.H1,
        "英文：Prologue、Epilogue 等独立章节",
    ),
    # The First Notebook / THE THIRD NOTEBOOK: PART TWO
    HeadingRule(
        re.compile(
            r"^(?:THE\s+)?"
            r"(?:FIRST|SECOND|THIRD|FOURTH|FIFTH|SIXTH|SEVENTH|EIGHTH|NINTH|TENTH"
            r"|ELEVENTH|TWELFTH|\d+|[IVXLCDM]+)"
            r"\s+NOTEBOOK"
            r"(?:\s*:\s*PART\s+"
            r"(?:ONE|TWO|THREE|FOUR|FIVE|SIX|SEVEN|EIGHT|NINE|TEN|\d+|[IVXLCDM]+)"
            r")?\s*$",
            re.IGNORECASE,
        ),
        HeadingLevel.H1,
        "英文：Notebook / Notebook: Part X",
    ),
    # Section 1 / Section 1.2
    HeadingRule(
        re.compile(r"^(?:Section|SECTION)\s+\d+(?:\.\d+)?\s*.*$", re.IGNORECASE),
        HeadingLevel.H2,
        "英文：Section X",
    ),
]

# ── 韩文章节模式 ──────────────────────────────────────────────
_KO_RULES: list[HeadingRule] = [
    # 제1장 / 제2장
    HeadingRule(
        re.compile(r"^제\s*\d+\s*[장부편]\s*.*$"),
        HeadingLevel.H1,
        "韩文：제X장、제X부、제X편",
    ),
    # 제1절
    HeadingRule(
        re.compile(r"^제\s*\d+\s*절\s*.*$"),
        HeadingLevel.H2,
        "韩文：제X절",
    ),
]

# 合并所有规则，H1 在前（优先匹配章级）
ALL_RULES: tuple[HeadingRule, ...] = tuple(
    sorted(
        _CJK_RULES + _EN_RULES + _KO_RULES,
        key=lambda r: r.level.value,
    )
)


# 页眉/页脚模式：至少有两个空格分隔的词组 + 末尾页码
# 匹配如 "第一章 文革前發生的重大事件 41"，但不匹配 "Chapter 1" 或 "Part 1"
_PAGE_HEADER_RE = re.compile(r"^.+\S\s+\d{1,4}\s*$")


def _looks_like_page_header(line: str) -> bool:
    """判断一行是否像页眉/页脚（末尾有孤立页码）。

    PDF 提取的文字中，页眉通常是"章节标题 + 页码"的格式，
    如 "第一章 文革前發生的重大事件 41"。
    我们通过检查末尾数字前是否有非数字内容来区分真正的标题和页眉。
    如 "Chapter 1" 中的 1 是章节号而非页码，不应过滤。
    """
    if not _PAGE_HEADER_RE.match(line):
        return False

    # 去掉末尾页码后，检查剩余部分是否本身就是一个完整的章节标题模式
    # 如果是，说明末尾数字是页码而非章节号
    without_trailing = re.sub(r"\s+\d{1,4}\s*$", "", line).strip()
    if not without_trailing:
        return False

    # 检查去掉页码后的部分是否仍能匹配章节标题规则
    for rule in ALL_RULES:
        if rule.pattern.match(without_trailing):
            return True

    return False


def detect_heading(line: str) -> HeadingLevel | None:
    """检测单行文字是否为章节/小节标题。

    返回对应的 HeadingLevel，若不匹配任何模式则返回 None。
    行内容过长（>80字符）或看起来像页眉时跳过。
    """
    stripped = line.strip()
    if not stripped or len(stripped) > 80:
        return None

    # 过滤页眉行（如"第一章 标题 41"）
    if _looks_like_page_header(stripped):
        return None

    for rule in ALL_RULES:
        if rule.pattern.match(stripped):
            return rule.level

    if _looks_like_generic_uppercase_subheading(stripped):
        return HeadingLevel.H2
    if _looks_like_short_cjk_title(stripped):
        return HeadingLevel.H1

    return None


def _looks_like_generic_uppercase_subheading(line: str) -> bool:
    if len(line) < 8 or len(line) > 80:
        return False
    if "|" in line:
        return False
    if re.match(
        r"^(?:\d{1,4}|[$A-Z]{1,2}\d{1,3})\s+\|\s*"
        r"[A-Z][A-Z0-9'’&:+()/-]{3,}"
        r"(?:\s+[A-Z][A-Z0-9'’&:+()/-]{3,}){0,3}\s*$",
        line,
    ):
        return False
    if re.match(
        r"^(?:\d{2,4}|[$A-Z]{1,2}\d{1,3})\s+"
        r"[A-Z][A-Z0-9'’&:+()/-]{3,}"
        r"(?:\s+[A-Z][A-Z0-9'’&:+()/-]{3,}){0,3}\s*$",
        line,
    ):
        return False
    if line.startswith(("FIGURE", "Figure", "TABLE", "Table", "CHART", "Chart")):
        return False
    if line.endswith((".", "!", "?", "。", "！", "？")):
        return False

    alpha_words = re.findall(r"[A-Z][A-Z'’&:+()/-]*", line)
    if len(alpha_words) < 3:
        return False

    letters = [char for char in line if char.isalpha()]
    if not letters:
        return False
    uppercase_letters = sum(char.isupper() for char in letters)
    return uppercase_letters >= max(6, int(len(letters) * 0.85))


def _looks_like_short_cjk_title(line: str) -> bool:
    stripped = line.strip("“”\"'『』「」")
    if len(stripped) < 2 or len(stripped) > 24:
        return False
    if re.search(r"[A-Za-z0-9０-９]", stripped):
        return False
    if any(mark in stripped for mark in "，。！？；：:;,.!?"):
        return False
    if stripped.startswith(("—", "-", "–", "·", "•")):
        return False
    if re.match(rf"^{_CJK_NUM}\s", stripped):
        return False

    cjk_count = sum("\u4e00" <= char <= "\u9fff" for char in stripped)
    if cjk_count < 3:
        return False
    if "《" in stripped or "》" in stripped:
        return cjk_count >= 4 and cjk_count >= len(stripped) - 2
    return cjk_count >= 6 and cjk_count == len(stripped)


def inject_heading_markers(
    text: str,
    *,
    include_levels: tuple[HeadingLevel, ...] = (HeadingLevel.H1, HeadingLevel.H2),
) -> str:
    """对纯文本进行预处理，在检测到的章节/小节标题前插入 Markdown 标记。

    已有 Markdown 标记（以 # 开头）的行不会被重复处理。
    返回处理后的文本，可直接传给 structure_parser 解析。
    """
    raw_lines = text.split("\n")
    output_lines: list[str] = []

    for index, line in enumerate(raw_lines):
        stripped = line.strip()

        # 已有 Markdown 标记或引用标记的行，原样保留
        if stripped.startswith("#") or stripped.startswith(">"):
            output_lines.append(line)
            continue

        level = detect_heading(stripped)
        if level is not None and level in include_levels:
            if (
                level == HeadingLevel.H1
                and _looks_like_short_cjk_title(stripped)
                and not _is_isolated_generic_cjk_title(raw_lines, index)
            ):
                output_lines.append(line)
                continue
            prefix = "#" * level.value
            output_lines.append(f"{prefix} {stripped}")
        else:
            output_lines.append(line)

    return "\n".join(output_lines)


def _is_isolated_generic_cjk_title(lines: list[str], index: int) -> bool:
    stripped = lines[index].strip()
    if "《" in stripped or "》" in stripped:
        return True

    previous_is_blank = index == 0 or not lines[index - 1].strip()
    next_is_blank = index == len(lines) - 1 or not lines[index + 1].strip()
    if previous_is_blank and next_is_blank:
        return True

    previous_non_empty = _find_previous_non_empty_line(lines, index)
    next_non_empty = _find_next_non_empty_line(lines, index)
    return bool(
        previous_non_empty
        and next_non_empty
        and _looks_like_cjk_dateline(previous_non_empty)
        and detect_heading(next_non_empty) == HeadingLevel.H2
    )


def _find_previous_non_empty_line(lines: list[str], index: int) -> str | None:
    for candidate_index in range(index - 1, -1, -1):
        candidate = lines[candidate_index].strip()
        if candidate:
            return candidate
    return None


def _find_next_non_empty_line(lines: list[str], index: int) -> str | None:
    for candidate_index in range(index + 1, len(lines)):
        candidate = lines[candidate_index].strip()
        if candidate:
            return candidate
    return None


def _looks_like_cjk_dateline(line: str) -> bool:
    return bool(
        re.match(
            r"^(?:\d{4}|[一二三四五六七八九零〇]{4})年.+日(?:\s+\S{1,8})?$",
            line.strip(),
        )
    )
