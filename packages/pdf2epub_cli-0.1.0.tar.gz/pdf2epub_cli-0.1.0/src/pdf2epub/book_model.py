from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class BlockType(Enum):
    HEADING1 = "heading1"
    HEADING2 = "heading2"
    HEADING3 = "heading3"
    PARAGRAPH = "paragraph"
    QUOTE = "quote"
    FOOTNOTE = "footnote"


@dataclass(frozen=True, slots=True)
class Block:
    type: BlockType
    text: str


@dataclass(frozen=True, slots=True)
class Chapter:
    title: str
    blocks: tuple[Block, ...]


@dataclass(frozen=True, slots=True)
class BookMetadata:
    title: str = "Untitled"
    author: str = "Unknown"
    language: str = "zh"


@dataclass(frozen=True, slots=True)
class Book:
    metadata: BookMetadata
    chapters: tuple[Chapter, ...]

    @property
    def chapter_count(self) -> int:
        return len(self.chapters)
