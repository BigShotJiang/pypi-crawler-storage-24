from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from pypdf import PdfReader
from pypdf.errors import PdfReadError


class PDFReadError(RuntimeError):
    """Raised when PDF content cannot be read safely."""


@dataclass(frozen=True, slots=True)
class PDFPageText:
    number: int
    text: str


@dataclass(frozen=True, slots=True)
class PDFMetadata:
    title: str
    author: str


@dataclass(frozen=True, slots=True)
class PDFDocumentText:
    source: Path
    pages: tuple[PDFPageText, ...]
    metadata: PDFMetadata

    @property
    def page_count(self) -> int:
        return len(self.pages)

    @property
    def full_text(self) -> str:
        non_empty_pages = [page.text for page in self.pages if page.text]
        return "\n\n".join(non_empty_pages)

    def get_page(self, number: int) -> PDFPageText | None:
        if number < 1 or number > self.page_count:
            return None
        return self.pages[number - 1]

    def text_density(self, *, min_chars: int = 50) -> float:
        """计算文档中"有实质文字"的页面占比。

        min_chars: 单页文字长度 >= 此阈值才视为有实质内容。
        返回 0.0~1.0 之间的浮点数；空文档返回 0.0。
        """
        if not self.pages:
            return 0.0
        rich_count = sum(1 for page in self.pages if len(page.text.strip()) >= min_chars)
        return rich_count / len(self.pages)

    def is_text_rich(self, *, min_chars: int = 50, threshold: float = 0.5) -> bool:
        """判断文档是否属于"原生文字型 PDF"（非扫描版）。

        当有实质文字的页面占比 >= threshold 时，认为文字可直接提取，
        无需走 LLM OCR 流程。
        """
        return self.text_density(min_chars=min_chars) >= threshold


def _normalize_text(raw_text: str) -> str:
    return raw_text.replace("\r\n", "\n").replace("\r", "\n").strip()


def read_pdf_text(pdf_path: str | Path) -> PDFDocumentText:
    path = Path(pdf_path).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"PDF file not found: {path}")
    if not path.is_file():
        raise ValueError(f"Expected a file path, got: {path}")

    try:
        with path.open("rb") as handle:
            reader = PdfReader(handle)

            if reader.is_encrypted:
                raise PDFReadError("Encrypted PDF files are not supported yet.")

            pages = tuple(
                PDFPageText(number=index, text=_normalize_text(page.extract_text() or ""))
                for index, page in enumerate(reader.pages, start=1)
            )

            raw_meta = reader.metadata
            pdf_title = ""
            pdf_author = ""
            if raw_meta:
                pdf_title = (raw_meta.title or "").strip()
                pdf_author = (raw_meta.author or "").strip()
            metadata = PDFMetadata(title=pdf_title, author=pdf_author)
    except PDFReadError:
        raise
    except (OSError, PdfReadError) as exc:
        raise PDFReadError(f"Failed to read PDF text from: {path}") from exc

    return PDFDocumentText(source=path, pages=pages, metadata=metadata)
