from __future__ import annotations

import re

_LATIN_RE = re.compile(r"[A-Za-z]")
_CJK_RE = re.compile(r"[\u4e00-\u9fff]")
_HANGUL_RE = re.compile(r"[\uac00-\ud7af]")


def detect_language_code(*samples: str, default: str = "zh") -> str:
    """Infer a reasonable EPUB language code from extracted text samples."""
    text = "\n".join(sample for sample in samples if sample).strip()
    if not text:
        return default

    latin_count = len(_LATIN_RE.findall(text))
    cjk_count = len(_CJK_RE.findall(text))
    hangul_count = len(_HANGUL_RE.findall(text))

    if hangul_count >= max(80, latin_count * 2):
        return "ko"
    if cjk_count >= max(80, latin_count):
        return "zh"
    if latin_count >= max(120, cjk_count * 3):
        return "en"
    if latin_count and cjk_count == 0 and hangul_count == 0:
        return "en"
    return default
