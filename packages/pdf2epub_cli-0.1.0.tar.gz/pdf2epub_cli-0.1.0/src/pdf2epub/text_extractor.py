from __future__ import annotations

from collections.abc import Callable
from enum import Enum
from typing import Protocol

from .llm_recognizer import (
    DEFAULT_STRUCTURE_PROMPT,
    OpenAICompatibleConfig,
    OpenAITextRecognizer,
    RecognitionProgress,
)
from .pdf_reader import PDFDocumentText
from .text_cleanup import normalize_native_document


class ExtractMode(Enum):
    """文字提取模式。"""

    AUTO = "auto"       # 自动检测：根据文字密度选择 native 或 llm
    NATIVE = "native"   # 原生提取：直接读取 PDF 内嵌文字，不调用 LLM
    LLM = "llm"         # LLM 识别：通过大模型进行 OCR 清洗 + 结构化


class TextExtractor(Protocol):
    """文字提取器的统一接口。

    所有提取器都接受一个已读取的 PDFDocumentText，
    返回处理后的 PDFDocumentText（文字已清洗/结构化）。
    """

    def extract(
        self,
        document: PDFDocumentText,
        *,
        on_update: Callable[[RecognitionProgress], None] | None = None,
    ) -> PDFDocumentText:
        """提取并返回处理后的文档。"""
        ...


class NativeExtractor:
    """原生文字提取器：直接使用 pypdf 提取的文字，不调用 LLM。

    适用于文字可选择的 PDF（非扫描版），提取速度快、无需模型依赖。
    """

    def extract(
        self,
        document: PDFDocumentText,
        *,
        on_update: Callable[[RecognitionProgress], None] | None = None,
    ) -> PDFDocumentText:
        return normalize_native_document(document)


class LLMExtractor:
    """LLM 文字提取器：通过大模型对 PDF 文字进行 OCR 清洗和结构化。

    适用于扫描版 PDF 或文字质量较差的情况。
    """

    def __init__(
        self,
        *,
        config: OpenAICompatibleConfig,
        prompt: str = DEFAULT_STRUCTURE_PROMPT,
        batch_size: int = 5,
        max_workers: int = 4,
    ) -> None:
        self._config = config
        self._prompt = prompt
        self._batch_size = batch_size
        self._max_workers = max_workers

    def extract(
        self,
        document: PDFDocumentText,
        *,
        on_update: Callable[[RecognitionProgress], None] | None = None,
    ) -> PDFDocumentText:
        recognizer = OpenAITextRecognizer(config=self._config)
        return recognizer.recognize_document_concurrent(
            document,
            prompt=self._prompt,
            batch_size=self._batch_size,
            max_workers=self._max_workers,
            on_update=on_update,
        )


class AutoExtractor:
    """自动提取器：根据文档文字密度自动选择 native 或 llm 模式。

    当文档中有实质文字的页面占比 >= threshold 时，使用原生提取；
    否则回退到 LLM 识别。
    """

    def __init__(
        self,
        *,
        llm_config: OpenAICompatibleConfig | None = None,
        prompt: str = DEFAULT_STRUCTURE_PROMPT,
        batch_size: int = 5,
        max_workers: int = 4,
        min_chars: int = 50,
        threshold: float = 0.5,
    ) -> None:
        self._llm_config = llm_config
        self._prompt = prompt
        self._batch_size = batch_size
        self._max_workers = max_workers
        self._min_chars = min_chars
        self._threshold = threshold

    def detect_mode(self, document: PDFDocumentText) -> ExtractMode:
        """根据文字密度判断应该使用哪种提取模式。"""
        if document.is_text_rich(
            min_chars=self._min_chars,
            threshold=self._threshold,
        ):
            return ExtractMode.NATIVE
        return ExtractMode.LLM

    def extract(
        self,
        document: PDFDocumentText,
        *,
        on_update: Callable[[RecognitionProgress], None] | None = None,
    ) -> PDFDocumentText:
        mode = self.detect_mode(document)

        if mode == ExtractMode.NATIVE:
            return NativeExtractor().extract(document, on_update=on_update)

        # LLM 模式需要配置
        if self._llm_config is None:
            raise ValueError(
                "自动检测结果为扫描版 PDF，需要 LLM 配置。"
                "请通过 --llm-model 或 PDF2EPUB_LLM_MODEL 提供模型配置。"
            )

        return LLMExtractor(
            config=self._llm_config,
            prompt=self._prompt,
            batch_size=self._batch_size,
            max_workers=self._max_workers,
        ).extract(document, on_update=on_update)


def create_extractor(
    mode: ExtractMode,
    *,
    llm_config: OpenAICompatibleConfig | None = None,
    prompt: str = DEFAULT_STRUCTURE_PROMPT,
    batch_size: int = 5,
    max_workers: int = 4,
) -> TextExtractor:
    """根据提取模式创建对应的提取器实例。

    这是推荐的工厂方法，CLI 层通过此函数获取提取器。
    """
    if mode == ExtractMode.NATIVE:
        return NativeExtractor()

    if mode == ExtractMode.LLM:
        if llm_config is None:
            raise ValueError(
                "LLM 模式需要提供模型配置。"
                "请通过 --llm-model 或 PDF2EPUB_LLM_MODEL 提供。"
            )
        return LLMExtractor(
            config=llm_config,
            prompt=prompt,
            batch_size=batch_size,
            max_workers=max_workers,
        )

    # auto 模式
    return AutoExtractor(
        llm_config=llm_config,
        prompt=prompt,
        batch_size=batch_size,
        max_workers=max_workers,
    )
