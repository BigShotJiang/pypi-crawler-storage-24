from __future__ import annotations

import re


_WHITESPACE_RE = re.compile(r"\s+")


def normalize_for_comparison(text: str) -> str:
    """Normalize text before computing OCR/regression metrics."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return _WHITESPACE_RE.sub(" ", text).strip()


def levenshtein_distance(left: str, right: str) -> int:
    if left == right:
        return 0
    if not left:
        return len(right)
    if not right:
        return len(left)

    previous_row = list(range(len(right) + 1))
    for left_index, left_char in enumerate(left, start=1):
        current_row = [left_index]
        for right_index, right_char in enumerate(right, start=1):
            insertion_cost = current_row[right_index - 1] + 1
            deletion_cost = previous_row[right_index] + 1
            substitution_cost = previous_row[right_index - 1] + (left_char != right_char)
            current_row.append(min(insertion_cost, deletion_cost, substitution_cost))
        previous_row = current_row
    return previous_row[-1]


def char_error_rate(expected_text: str, actual_text: str) -> float:
    expected = normalize_for_comparison(expected_text)
    actual = normalize_for_comparison(actual_text)
    if not expected and not actual:
        return 0.0
    if not expected:
        return 1.0
    return levenshtein_distance(expected, actual) / len(expected)
