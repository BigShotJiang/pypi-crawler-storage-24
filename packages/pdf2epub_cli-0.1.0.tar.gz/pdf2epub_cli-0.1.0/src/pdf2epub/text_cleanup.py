"""Text cleanup helpers for noisy PDF extraction."""

from __future__ import annotations

from collections import Counter
import re
import unicodedata
from dataclasses import dataclass
from difflib import SequenceMatcher

from .chapter_detector import HeadingLevel, detect_heading
from .pdf_reader import PDFDocumentText, PDFMetadata, PDFPageText


_TOC_ENTRY_RE = re.compile(r"^.+[…．.]{2,}.+$")
_TOC_HEADER_RE = re.compile(r"^[總总]目[錄录]\s*\d*\s*$")
_EN_TOC_HEADER_RE = re.compile(
    r"^(?:Contents|Table\s+of\s+Contents)(?:\s*[|]\s*[ivxlcdm0-9]+)?$",
    re.IGNORECASE,
)
_INLINE_TOC_ENTRY_RE = re.compile(r"^.{2,80}\s+\d{1,4}$")
_TOC_PAGE_NUMBER_ONLY_RE = re.compile(r"^(?:\d{1,4}|[ivxlcdm]{1,8})$", re.IGNORECASE)
_PART_TITLE_RE = re.compile(r"^[上下中]\s*[篇部卷册冊集]$")
_TRAILING_PAGE_NUMBER_RE = re.compile(r"^(?P<stem>.*?\S)\s+(?P<page>\d{1,4})\s*$")
_LEADING_PAGE_NUMBER_RE = re.compile(
    r"^(?P<page>(?:\d{1,4}|[$A-Z]{1,2}\d{1,3}))(?:\s+\|\s*|\s+)(?P<stem>.*?\S)\s*$"
)
_TRAILING_BAR_HEADER_RE = re.compile(r"^(?P<stem>.*?\S)\s+\|\s*$")
_FOOTNOTE_MARKER_RE = re.compile(r"^[1-9]\d?$")
_FOOTNOTE_START_FALLBACK_RE = re.compile(r"^(?P<num>[1-9]\d?)\s*(?P<content>\S.*)$")
_YEAR_LINE_RE = re.compile(r"^\d{4}\s*年")
_FOOTNOTE_BLOCK_RE = re.compile(r"^\^\^\^\s+\[(?P<num>\d+)]")
_METADATA_TITLE_RE = re.compile(r"^[书書]\s*名\s*(?P<value>.+)$")
_METADATA_AUTHOR_RE = re.compile(r"^(?:作\s*者|作者|Author)\s*(?P<value>.+)$", re.IGNORECASE)
_METADATA_PAGE_KEYWORD_RE = re.compile(
    r"^(?:https?://"
    r"|www\."
    r"|ISBN\b"
    r"|©"
    r"|copyright\b"
    r"|Digitized by the Internet Archive"
    r"|Kahle/Austin Foundation"
    r"|AN IMPRINT OF PENGUIN RANDOM HOUSE"
    r"|SpecialMarkets@"
    r"|[（(]?(?:版權所有|版权)"
    r"|[书書]\s*名(?:\s|$|：|:)"
    r"|(?:作\s*者|作者)(?:\s|$|：|:)"
    r"|出\s*版(?:\s|$|：|:)"
    r"|印\s*刷(?:\s|$|：|:)"
    r"|出版日期(?:\s|$|：|:)"
    r"|電話(?:\s|$|：|:)"
    r"|电话(?:\s|$|：|:)"
    r"|傳真(?:\s|$|：|:)"
    r"|传真(?:\s|$|：|:)"
    r"|COSMOS BOOKS)",
    re.IGNORECASE,
)
_SUSPICIOUS_METADATA_TITLE_RE = re.compile(
    r"(?:microsoft\s+word|\.doc$|封面|cover|untitled)",
    re.IGNORECASE,
)
_SUSPICIOUS_METADATA_AUTHOR_RE = re.compile(
    r"^(?:administrator|admin|unknown|acrobat|adobe|microsoft.*)$",
    re.IGNORECASE,
)
_SENTENCE_END_RE = re.compile(r"[。！？!?；;：:]$")
_BODY_PUNCTUATION_RE = re.compile(r"[。！？!?；;：:]")
_TOC_PAGE_REF_RE = re.compile(r"[［\[(]?\s*[A-Za-z.]?\d{1,4}\s*[J】］\])」]?\s*$")
_PAREN_OUTLINE_RE = re.compile(r"^[（(][一二三四五六七八九十百千零〇０-９0-9IVXivx]+[）)]")
_ARABIC_OUTLINE_RE = re.compile(r"^(?:[1-9]\d*|[IVXivx]+)\s*[-—、.．]")
_STAGE_OUTLINE_RE = re.compile(
    r"^第[一二三四五六七八九十百千零〇０-９0-9]+(?:阶段|部分|节|章|篇|卷)[：:]?"
)
_TRAILING_INLINE_NOISE_RE = re.compile(r"[>＞][-—][\u4e00-\u9fff]{1,2}$")
_MAX_HEADER_STEM_LEN = 80
_FOOTNOTE_LOOKBACK_LINES = 14
_MAX_TITLE_LINE_LEN = 48
_CENTERED_PAGE_NUMBER_RE = re.compile(r"^[·•]\s*\d{1,4}\s*[·•]$")
_TEXTCIRCLED_MARKER_RE = re.compile(r"\$\\textcircled\{(\d+)\}\$")
_BYLINE_PREFIXES = "□■◆◇◻◼"
_SERIES_HEADER_TARGETS = ("ICARUSVOL1", "ICARUSVOLI", "ICARUSVOL")
_TITLE_CASE_STOPWORDS = {
    "a", "an", "and", "as", "at", "but", "by", "for", "from", "in", "of", "on",
    "or", "the", "to", "vs", "via", "with",
}
_COMMON_SHORT_WORDS = {
    "a", "an", "and", "as", "at", "be", "by", "for", "he", "i", "if", "in", "is",
    "it", "me", "my", "of", "on", "or", "so", "to", "up", "us", "we",
}
_VISUAL_CLUSTER_CAPTION_RE = re.compile(
    r"^(?:[A-Z]\s+)?(?:EXAMPLES OF|ONETIME ACTIONS|FIGURE|TABLE|CHART|Phase\s+\d+)\b",
    re.IGNORECASE,
)
_VISUAL_CLUSTER_DIVIDER_RE = re.compile(
    r"^(?:HOW TO (?:CREATE A GOOD HABIT|BREAK A BAD HABIT)|INVERSION OF\b|MAKE IT\b|THE\s+[1I](?:ST|st)\s+LAW\b|THE\s+2ND\s+LAW\b|THE\s+3RD\s+LAW\b|THE\s+4TH\s+LAW\b)",
    re.IGNORECASE,
)
_CHAPTER_SUMMARY_RE = re.compile(r"chapter\s+summary", re.IGNORECASE)
_PRE_HEADING_TEASER_RE = re.compile(
    r"(?:\bInversion\b|Make\s+It\b|the\s+[1I](?:st|ST)\s+Law\b|the\s+2nd\s+Law\b|the\s+3rd\s+Law\b|the\s+4th\s+Law\b|Use\s+a?commitment\b|Restrict\s+your\b|Reduce\s+exposure\b)",
    re.IGNORECASE,
)
_STANDALONE_PIPE_PRONOUN_RE = re.compile(r"(?<!\w)\|\s+(?=(?!vs\.?\b)[a-z])")
_LEADING_DECORATIVE_N_RE = re.compile(
    r"^(?:(?:[\"'“”‘’`]|[a-z])\s+)?(?:\|\s*)?N\s+(?P<rest>.+)$"
)
_LEADING_NOISE_UPPERCASE_WORD_RE = re.compile(
    r"^(?P<noise>[a-z]{1,3})\s+(?P<token>[A-Z]{4,})(?P<rest>\b.*)$"
)
_CREDIT_LINE_RE = re.compile(
    r"^(?:[\u4e00-\u9fff·••\s]{1,20}(?:著|译|譯|编|編|校|选编|編著|著译|譯註|译注)"
    r"|[\u4e00-\u9fff]{1,20}译)$"
)


@dataclass(frozen=True, slots=True)
class _PageFragment:
    text: str
    starts_new_section: bool


def is_toc_line(line: str) -> bool:
    """Return True when a line looks like a TOC entry/header."""
    stripped = line.strip()
    if not stripped:
        return False
    if _TOC_HEADER_RE.match(stripped) or _EN_TOC_HEADER_RE.match(stripped):
        return True
    if len(stripped) > 90:
        return False
    return bool(
        (_TOC_ENTRY_RE.match(stripped) and _TOC_PAGE_REF_RE.search(stripped))
        or _TOC_PAGE_REF_RE.search(stripped)
        and re.search(r"[…．.]{2,}", stripped)
    )


def strip_page_number_suffix(line: str) -> str | None:
    """Strip a trailing page number from a running header/footer line."""
    match = _TRAILING_PAGE_NUMBER_RE.match(line.strip())
    if match is None:
        return None
    return match.group("stem").strip()


def _strip_page_number_prefix(line: str) -> str | None:
    match = _LEADING_PAGE_NUMBER_RE.match(line.strip())
    if match is None:
        return None
    page = match.group("page")
    stem = match.group("stem").strip()
    if page.isdigit() and len(page) == 4 and re.match(r"^(?:年|\d+\s*[月日号號])", stem):
        return None
    return stem


def _strip_trailing_bar_header(line: str) -> str | None:
    match = _TRAILING_BAR_HEADER_RE.match(line.strip())
    if match is None:
        return None
    return match.group("stem").strip()


def is_page_header(line: str) -> bool:
    """Return True when a line looks like a running header/footer."""
    stripped = line.strip()
    if _CENTERED_PAGE_NUMBER_RE.match(stripped):
        return True
    if stripped.startswith("#"):
        return False
    if detect_heading(stripped) is not None:
        return False
    stem = (
        strip_page_number_suffix(stripped)
        or _strip_page_number_prefix(stripped)
        or _strip_trailing_bar_header(stripped)
    )
    if stem is None or len(stem) > _MAX_HEADER_STEM_LEN:
        return False
    heading_level = detect_heading(stem)
    if heading_level is not None:
        return True
    if _BODY_PUNCTUATION_RE.search(stem):
        return False
    if stem.endswith("|"):
        return True
    if _TRAILING_BAR_HEADER_RE.match(stripped) or _LEADING_PAGE_NUMBER_RE.match(stripped):
        return True
    if len(stem) <= 20:
        return True
    return False


def is_footnote_marker(line: str) -> bool:
    """Return True for standalone inline footnote reference markers like ``1``."""
    return bool(_FOOTNOTE_MARKER_RE.match(line.strip()))


def _normalize_page_line(line: str) -> str:
    line = line.replace("\u00a0", " ").replace("\t", " ")
    return re.sub(r" {2,}", " ", line).strip()


def _normalize_llm_ocr_line(line: str) -> str:
    normalized = _TEXTCIRCLED_MARKER_RE.sub(r"[^\1]", line)
    footnote_match = re.match(r"^\[\^(?P<num>\d+)]\s*(?P<content>\S.*)$", normalized.strip())
    if footnote_match is not None:
        return f"^^^ [{footnote_match.group('num')}] {footnote_match.group('content')}"
    return normalized


def cleanup_text(text: str) -> str:
    """Line-oriented cleanup used by the parser as a final safety net."""
    cleaned_lines: list[str] = []
    toc_mode = False

    for raw_line in text.split("\n"):
        line = _normalize_llm_ocr_line(_normalize_page_line(raw_line))

        if not line:
            if not toc_mode:
                cleaned_lines.append("")
            continue

        summary_heading = _normalize_summary_heading(line)
        if summary_heading is not None:
            cleaned_lines.append(summary_heading)
            toc_mode = False
            continue

        if is_page_header(line):
            continue

        if is_toc_line(line):
            toc_mode = True
            continue

        if toc_mode:
            if _looks_like_toc_section_heading(line):
                continue
            toc_mode = False

        if _looks_like_front_matter_line(line):
            continue

        if _looks_like_standalone_gibberish_line(line):
            continue

        cleaned_lines.append(line)

    cleaned_lines = _strip_garbled_visual_clusters(cleaned_lines)
    cleaned_lines = _strip_pre_heading_teaser_clusters(cleaned_lines)
    cleaned_lines = _repair_prose_ocr_markers(cleaned_lines)
    cleaned_lines = _merge_split_uppercase_subheadings(cleaned_lines)
    return _compact_blank_lines(_convert_standalone_footnotes(cleaned_lines))


def _strip_garbled_visual_clusters(lines: list[str]) -> list[str]:
    cleaned: list[str] = []
    index = 0
    while index < len(lines):
        if not _looks_like_visual_cluster_start(lines, index):
            cleaned.append(lines[index])
            index += 1
            continue

        divider_cluster = _looks_like_visual_divider_heading(lines[index].strip())
        caption_cluster = _looks_like_visual_caption_heading(lines[index].strip())
        figure_caption_seen = _looks_like_figure_caption_heading(lines[index].strip())
        cluster_end = index
        blank_budget = 1
        while cluster_end < len(lines):
            candidate = lines[cluster_end].strip()
            next_non_empty = _next_non_empty_line(lines, cluster_end + 1)
            if not candidate:
                if blank_budget and next_non_empty and _looks_like_visual_cluster_line(next_non_empty):
                    blank_budget -= 1
                    cluster_end += 1
                    continue
                break
            if cluster_end > index and _looks_like_visual_caption_heading(candidate):
                caption_cluster = True
                figure_caption_seen = figure_caption_seen or _looks_like_figure_caption_heading(candidate)
            if divider_cluster and cluster_end > index:
                if candidate.startswith("#") and not _looks_like_visual_cluster_line(candidate):
                    break
                if _looks_like_visual_cluster_line(candidate):
                    cluster_end += 1
                    continue
                if (
                    _looks_like_body_line(candidate)
                    and not _looks_like_visual_cluster_line(next_non_empty)
                    and not _has_nearby_real_heading(lines, cluster_end + 1)
                ):
                    break
                if len(candidate) <= 72:
                    cluster_end += 1
                    continue
                break
            if caption_cluster and cluster_end > index:
                if candidate.startswith("#") and not _looks_like_visual_cluster_line(candidate):
                    break
                if _looks_like_visual_cluster_line(candidate):
                    figure_caption_seen = figure_caption_seen or _looks_like_figure_caption_heading(candidate)
                    cluster_end += 1
                    continue
                if figure_caption_seen and len(candidate) <= 72:
                    cluster_end += 1
                    if re.search(r"[.!?。！？]$", candidate) and next_non_empty and _looks_like_body_line(next_non_empty):
                        break
                    continue
                if _looks_like_visual_fragment_line(candidate):
                    cluster_end += 1
                    continue
                if len(candidate) <= 72 and _has_visual_cluster_ahead(lines, cluster_end + 1):
                    cluster_end += 1
                    continue
                if _looks_like_body_line(candidate):
                    break
                break
            if not _looks_like_visual_cluster_line(candidate):
                if _looks_like_body_line(candidate) and not _looks_like_visual_cluster_line(next_non_empty):
                    break
                if next_non_empty and _looks_like_visual_cluster_line(next_non_empty):
                    cluster_end += 1
                    continue
                break
            cluster_end += 1

        cluster = [line for line in lines[index:cluster_end] if line.strip()]
        if _is_removable_visual_cluster(cluster):
            next_index = cluster_end
            while next_index < len(lines) and not lines[next_index].strip():
                next_index += 1
            if cleaned and cleaned[-1] and not _should_keep_cluster_inline(
                cleaned[-1],
                lines[next_index] if next_index < len(lines) else "",
            ):
                cleaned.append("")
            index = cluster_end
            while index < len(lines) and not lines[index].strip():
                index += 1
            continue

        cleaned.append(lines[index])
        index += 1

    return cleaned


def _looks_like_visual_cluster_start(lines: list[str], index: int) -> bool:
    line = lines[index].strip()
    if not line:
        return False
    if not _looks_like_visual_cluster_line(line):
        return False
    if _looks_like_figure_caption_heading(line):
        return True

    window = [
        candidate.strip()
        for candidate in lines[index:index + 8]
        if candidate.strip()
    ]
    return _visual_cluster_score(window) >= 4 and _visual_cluster_has_structure_marker(window)


def _looks_like_visual_cluster_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    candidate = stripped.lstrip("#").strip()
    if _VISUAL_CLUSTER_CAPTION_RE.match(candidate):
        return True
    if _VISUAL_CLUSTER_DIVIDER_RE.match(candidate):
        return True
    if stripped.startswith("#"):
        return _looks_like_visual_cluster_heading(candidate)
    if detect_heading(candidate) is not None:
        return False
    if candidate.count("|") >= 1:
        return True
    if "/" in candidate and "http" not in candidate.lower():
        return True
    if candidate.startswith(("_", "\\", "[", "]", "'", '"', "•", "·")):
        return True
    if re.match(r"^(?:FIGURE|Phase)\s+\d+", candidate, re.IGNORECASE):
        return True
    if len(candidate) <= 90 and candidate.count(".") >= 2 and not _looks_like_body_line(candidate):
        return True
    if len(candidate) <= 40 and not _BODY_PUNCTUATION_RE.search(candidate) and not re.search(r"[.!?。！？；:;]$", candidate):
        return True
    return bool(re.fullmatch(r"[A-Z][A-Z\s]{2,}", candidate))


def _is_removable_visual_cluster(cluster: list[str]) -> bool:
    if len(cluster) < 3:
        return bool(cluster) and len(cluster) >= 2 and (
            _looks_like_visual_divider_heading(cluster[0])
            or _looks_like_visual_caption_heading(cluster[0])
        )
    if cluster and _looks_like_visual_divider_heading(cluster[0]):
        return True
    return _visual_cluster_score(cluster) >= max(4, len(cluster))


def _visual_cluster_score(lines: list[str]) -> int:
    score = 0
    for line in lines:
        candidate = line.lstrip("#").strip()
        if _VISUAL_CLUSTER_CAPTION_RE.match(candidate):
            score += 2
        if _VISUAL_CLUSTER_DIVIDER_RE.match(candidate):
            score += 2
        if "|" in candidate:
            score += 2
        if "/" in candidate and "http" not in candidate.lower():
            score += 1
        if candidate.startswith(("_", "\\", "[", "]", "'", '"', "•", "·")):
            score += 1
        if re.match(r"^(?:FIGURE|Phase)\s+\d+", candidate, re.IGNORECASE):
            score += 1
        if len(candidate) <= 90 and candidate.count(".") >= 2 and not _looks_like_body_line(candidate):
            score += 1
        if len(candidate) <= 40 and not _BODY_PUNCTUATION_RE.search(candidate) and not re.search(r"[.!?。！？；:;]$", candidate):
            score += 1
        if re.fullmatch(r"[A-Z][A-Z\s]{2,}", candidate):
            score += 1
    return score


def _visual_cluster_has_structure_marker(lines: list[str]) -> bool:
    return any(
        _is_visual_cluster_structure_marker(line)
        for line in lines
    )


def _should_keep_cluster_inline(previous_line: str, next_line: str) -> bool:
    previous = previous_line.rstrip()
    following = next_line.lstrip()
    if not previous or not following:
        return False
    if re.search(r"[.!?;:。！？；：]$", previous):
        return False
    return bool(re.match(r"^[a-z(\"'“‘]", following))


def _next_non_empty_line(lines: list[str], index: int) -> str:
    for candidate in lines[index:]:
        if candidate.strip():
            return candidate.strip()
    return ""


def _has_nearby_real_heading(lines: list[str], index: int, *, limit: int = 4) -> bool:
    non_empty_seen = 0
    for candidate in lines[index:]:
        stripped = candidate.strip()
        if not stripped:
            continue
        non_empty_seen += 1
        if stripped.startswith("#") and not _looks_like_visual_cluster_line(stripped):
            return True
        if non_empty_seen >= limit:
            break
    return False


def _has_visual_cluster_ahead(lines: list[str], index: int, *, limit: int = 3) -> bool:
    non_empty_seen = 0
    for candidate in lines[index:]:
        stripped = candidate.strip()
        if not stripped:
            continue
        non_empty_seen += 1
        if _looks_like_visual_cluster_line(stripped):
            return True
        if non_empty_seen >= limit:
            break
    return False


def _looks_like_visual_fragment_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > 24 or _looks_like_body_line(stripped):
        return False
    words = re.findall(r"[A-Za-z][A-Za-z'’-]*", stripped)
    if not words or len(words) > 4:
        return False
    return bool(re.search(r"[.!?。！？]$", stripped) or stripped.isupper())


def _is_visual_cluster_structure_marker(line: str) -> bool:
    candidate = line.lstrip("#").strip()
    return bool(
        _looks_like_visual_cluster_heading(candidate)
        or "|" in candidate
        or ("/" in candidate and "http" not in candidate.lower())
        or candidate.startswith(("_", "\\", "[", "]", "'", '"', "•", "·"))
        or re.match(r"^(?:FIGURE|Phase)\s+\d+", candidate, re.IGNORECASE)
        or (len(candidate) <= 90 and candidate.count(".") >= 2 and not _looks_like_body_line(candidate))
        or re.fullmatch(r"[A-Z][A-Z\s]{2,}", candidate)
    )


def _looks_like_visual_cluster_heading(candidate: str) -> bool:
    return bool(
        _VISUAL_CLUSTER_CAPTION_RE.match(candidate)
        or _VISUAL_CLUSTER_DIVIDER_RE.match(candidate)
        or re.match(r"^(?:FIGURE|Phase)\s+\d+", candidate, re.IGNORECASE)
    )


def _looks_like_visual_divider_heading(line: str) -> bool:
    stripped = line.strip()
    return stripped.startswith("#") and _VISUAL_CLUSTER_DIVIDER_RE.match(stripped.lstrip("#").strip()) is not None


def _looks_like_visual_caption_heading(line: str) -> bool:
    stripped = line.strip()
    candidate = stripped.lstrip("#").strip()
    return _VISUAL_CLUSTER_CAPTION_RE.match(candidate) is not None


def _looks_like_figure_caption_heading(line: str) -> bool:
    stripped = line.strip().lstrip("#").strip()
    return re.match(r"^(?:[A-Z]\s+)?(?:FIGURE|TABLE|CHART)\b", stripped, re.IGNORECASE) is not None


def _strip_pre_heading_teaser_clusters(lines: list[str]) -> list[str]:
    cleaned: list[str] = []
    index = 0
    while index < len(lines):
        if not _looks_like_pre_heading_teaser_cluster(lines, index):
            cleaned.append(lines[index])
            index += 1
            continue

        cursor = index
        while cursor < len(lines):
            candidate = lines[cursor].strip()
            if not candidate:
                cursor += 1
                continue
            if candidate.startswith("#"):
                break
            cursor += 1
        index = cursor

    return cleaned


def _looks_like_pre_heading_teaser_cluster(lines: list[str], index: int) -> bool:
    start = lines[index].strip()
    if not start or start.startswith("#"):
        return False

    cluster: list[str] = []
    heading_seen = False
    for candidate in lines[index:index + 12]:
        stripped = candidate.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            heading_seen = True
            break
        cluster.append(stripped)

    if not heading_seen or not cluster:
        return False
    if any(len(line) > 72 for line in cluster):
        return False

    marker_hits = sum(bool(_PRE_HEADING_TEASER_RE.search(line)) for line in cluster)
    weird_hits = sum(
        bool(re.search(r"[|\"“”]|[A-Za-z]{2,}[A-Z][a-z]+|[A-Za-z]+[0-9]|[0-9][A-Za-z]+", line))
        for line in cluster
    )
    if marker_hits >= 2 or (marker_hits >= 1 and weird_hits >= 1):
        return True
    return marker_hits >= 1 and len(cluster) <= 2 and all(len(line) <= 48 for line in cluster)


def _normalize_summary_heading(line: str) -> str | None:
    stripped = line.strip()
    candidate = stripped.lstrip("#").strip()
    if len(candidate) > 64 or _CHAPTER_SUMMARY_RE.search(candidate) is None:
        return None
    return "## Chapter Summary"


def _looks_like_standalone_gibberish_line(line: str) -> bool:
    stripped = line.strip()
    if len(stripped) < 3 or len(stripped) > 6:
        return False
    if not re.fullmatch(r"[A-Za-z]+", stripped):
        return False

    lower = stripped.lower()
    if lower in _COMMON_SHORT_WORDS:
        return False

    vowels = sum(char in "aeiouy" for char in lower)
    consonants = len(lower) - vowels
    return vowels == 0 or consonants == 0


def _repair_prose_ocr_markers(lines: list[str]) -> list[str]:
    word_counts = Counter(
        word.casefold()
        for line in lines
        for word in re.findall(r"[A-Za-z][A-Za-z'’-]{3,}", line)
    )

    repaired: list[str] = []
    previous_non_empty = ""
    for line in lines:
        stripped = line.strip()
        if not stripped:
            repaired.append(line)
            previous_non_empty = ""
            continue

        current = stripped
        if _should_repair_pipe_pronouns(current):
            current = _repair_pipe_pronouns(current)
        if _is_paragraph_opening_context(previous_non_empty):
            current = _repair_leading_dropcap_opening(current, word_counts)

        repaired.append(current)
        previous_non_empty = current

    return repaired


def _should_repair_pipe_pronouns(line: str) -> bool:
    if "|" not in line or line.startswith("#"):
        return False
    if detect_heading(line) is not None:
        return False
    if line.count("|") > 3:
        return False
    return _looks_like_body_line(line)


def _repair_pipe_pronouns(line: str) -> str:
    repaired = _STANDALONE_PIPE_PRONOUN_RE.sub("I ", line)
    return re.sub(r"\s{2,}", " ", repaired).strip()


def _is_paragraph_opening_context(previous_non_empty: str) -> bool:
    return not previous_non_empty or previous_non_empty.startswith("#")


def _repair_leading_dropcap_opening(
    line: str,
    word_counts: Counter[str],
) -> str:
    repaired = _repair_decorative_n_opening(line)
    if repaired != line:
        return repaired
    return _repair_missing_initial_uppercase_word(line, word_counts)


def _repair_decorative_n_opening(line: str) -> str:
    match = _LEADING_DECORATIVE_N_RE.match(line)
    if match is None:
        return line

    rest = match.group("rest").strip()
    if not rest:
        return line
    prefix = _choose_restored_n_prefix(rest)
    return f"{prefix} {rest}"


def _choose_restored_n_prefix(rest: str) -> str:
    upper_rest = rest.upper()
    smallcaps = _looks_like_smallcaps_opening(rest)

    if upper_rest.startswith((
        "THE FIRST ",
        "THE SECOND ",
        "THE THIRD ",
        "THE FOURTH ",
        "THE FIFTH ",
        "THE FINAL ",
        "THE LAST ",
        "THE NEXT DAY",
        "THE DAY ",
        "THE MORNING",
        "THE AFTERNOON",
        "THE EVENING",
        "THE NIGHT",
    )):
        return "ON" if smallcaps else "On"

    if upper_rest.startswith(tuple(day.upper() for day in (
        "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday",
    ))):
        return "ON" if smallcaps else "On"

    return "IN" if smallcaps else "In"


def _looks_like_smallcaps_opening(rest: str) -> bool:
    tokens = re.findall(r"[A-Za-z]+|\d+", rest)
    uppercase_words = [
        token for token in tokens[:3]
        if token.isalpha() and token.isupper()
    ]
    return len(uppercase_words) >= 2


def _repair_missing_initial_uppercase_word(
    line: str,
    word_counts: Counter[str],
) -> str:
    match = _LEADING_NOISE_UPPERCASE_WORD_RE.match(line)
    if match is None:
        return line

    token = match.group("token")
    restored = _restore_missing_initial_word(token, word_counts)
    if restored is None:
        return line

    replacement = restored.upper() if token.isupper() else restored
    return f"{replacement}{match.group('rest')}"


def _restore_missing_initial_word(
    token: str,
    word_counts: Counter[str],
) -> str | None:
    suffix = token.casefold()
    candidates = [
        (word, count)
        for word, count in word_counts.items()
        if len(word) == len(suffix) + 1 and word[1:] == suffix
    ]
    if not candidates:
        return None

    candidates.sort(key=lambda item: (-item[1], item[0]))
    top_word, top_count = candidates[0]
    if len(candidates) == 1:
        return top_word
    if top_count >= max(3, candidates[1][1] * 3):
        return top_word
    return None


def _merge_split_uppercase_subheadings(lines: list[str]) -> list[str]:
    merged: list[str] = []
    index = 0
    while index < len(lines):
        current = lines[index].strip()
        if not _looks_like_uppercase_subheading_fragment(current):
            merged.append(lines[index])
            index += 1
            continue

        next_index = index + 1
        if next_index >= len(lines):
            merged.append(lines[index])
            index += 1
            continue

        following = lines[next_index].strip()
        combined = f"{current} {following}".strip()
        if _looks_like_uppercase_subheading_fragment(following) and len(combined) <= 80:
            merged.append(combined)
            index += 2
            continue

        merged.append(lines[index])
        index += 1

    return merged


def _looks_like_uppercase_subheading_fragment(line: str) -> bool:
    if not line or len(line) > 48:
        return False
    if line.startswith("#") or line.endswith((".", "!", "?", "。", "！", "？")):
        return False
    words = re.findall(r"[A-Z0-9][A-Z0-9'’&:+()/-]*", line)
    if len(words) < 2:
        return False
    letters = [char for char in line if char.isalpha()]
    if not letters:
        return False
    uppercase = sum(char.isupper() for char in letters)
    return uppercase >= max(4, int(len(letters) * 0.8))


def normalize_native_document(document: PDFDocumentText) -> PDFDocumentText:
    """Normalize native PDF extraction into cleaner, parser-friendly text."""
    fragments: list[_PageFragment] = []
    extracted_title = ""
    extracted_author = ""
    repeated_edge_lines = _collect_repeated_edge_lines(document.pages)

    for page in document.pages:
        raw_lines = [_normalize_page_line(line) for line in page.text.splitlines()]
        title_candidate, author_candidate = _extract_embedded_metadata(raw_lines)
        if not extracted_title and title_candidate:
            extracted_title = title_candidate
        if not extracted_author and author_candidate:
            extracted_author = author_candidate

        fragment = _normalize_page(page.number, raw_lines, repeated_edge_lines)
        if fragment is not None:
            fragments.append(fragment)

    combined_text = _combine_fragments(fragments)
    combined_text = _strip_embedded_noise_clusters(combined_text)
    metadata = PDFMetadata(
        title=_normalize_metadata_title(document.metadata.title, extracted_title),
        author=_normalize_metadata_author(document.metadata.author, extracted_author),
    )

    if not combined_text:
        return PDFDocumentText(source=document.source, pages=(), metadata=metadata)

    return PDFDocumentText(
        source=document.source,
        pages=(PDFPageText(number=1, text=combined_text),),
        metadata=metadata,
    )


def _normalize_page(
    page_number: int,
    raw_lines: list[str],
    repeated_edge_lines: set[str] | None = None,
) -> _PageFragment | None:
    lines = _trim_blank_edges(raw_lines)
    if repeated_edge_lines:
        lines = _drop_repeated_edge_lines(lines, repeated_edge_lines)
    if not lines:
        return None
    if _is_front_matter_page(lines) or _is_toc_page(lines):
        return None

    heading_from_header = ""
    if lines and is_page_header(lines[0]):
        header_stem = strip_page_number_suffix(lines[0])
        if header_stem is not None:
            if detect_heading(header_stem) == HeadingLevel.H1:
                heading_from_header = header_stem
            lines = lines[1:]
            lines = _trim_blank_edges(lines)

    if lines and is_page_header(lines[-1]):
        lines = lines[:-1]
        lines = _trim_blank_edges(lines)

    lines = _drop_leading_page_markers(lines)
    lines = _drop_leading_page_garbage(lines)
    lines = _strip_series_headers(lines)
    lines = [_strip_trailing_inline_noise(line) for line in lines]
    lines = _strip_leading_outline(lines)
    lines = _merge_outline_continuations(lines)
    lines = _strip_trailing_page_noise(lines)
    lines = _trim_blank_edges(lines)
    if not lines:
        return None

    lines = _strip_inline_ocr_numeric_leaders(lines)
    body_lines, footnote_region = _split_footnote_region(lines)
    body_lines, body_refs = _attach_inline_footnote_refs(body_lines, [])
    footnote_lines = _parse_footnotes(footnote_region, body_refs)
    footnote_numbers = _extract_footnote_numbers(footnote_lines)
    body_lines, _ = _attach_inline_footnote_refs(body_lines, footnote_numbers)
    body_lines, starts_new_section = _rewrite_title_page(body_lines, heading_from_header)
    if starts_new_section:
        body_lines = _truncate_leading_local_toc(body_lines)
    body_lines = _normalize_leading_byline(body_lines)

    output_lines = [line for line in body_lines if line or body_lines]
    if footnote_lines:
        if output_lines and output_lines[-1]:
            output_lines.append("")
        output_lines.extend(footnote_lines)

    text = _compact_blank_lines(output_lines)
    if not text:
        return None
    return _PageFragment(text=text, starts_new_section=starts_new_section or page_number == 1)


def _collect_repeated_edge_lines(pages: tuple[PDFPageText, ...]) -> set[str]:
    counts: dict[str, int] = {}
    for page in pages:
        lines = [_normalize_page_line(line) for line in page.text.splitlines()]
        non_empty = [line for line in lines if line]
        edge_candidates = set(non_empty[:2] + non_empty[-2:])
        for line in edge_candidates:
            if not _looks_like_repeated_edge_line(line):
                continue
            counts[line] = counts.get(line, 0) + 1
    return {line for line, count in counts.items() if count >= 3}


def _looks_like_repeated_edge_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > _MAX_HEADER_STEM_LEN:
        return False
    if _looks_like_front_matter_line(stripped) or is_toc_line(stripped):
        return False
    if re.search(r"https?://|@", stripped):
        return False
    if stripped.endswith((".", "!", "?", "。", "！", "？")):
        return False
    if _TOC_PAGE_NUMBER_ONLY_RE.match(stripped):
        return False
    return True


def _drop_repeated_edge_lines(lines: list[str], repeated_edge_lines: set[str]) -> list[str]:
    output = list(lines)
    while output and output[0] in repeated_edge_lines:
        output = output[1:]
    while output and output[-1] in repeated_edge_lines:
        output = output[:-1]
    return _trim_blank_edges(output)


def _rewrite_title_page(lines: list[str], header_heading: str) -> tuple[list[str], bool]:
    non_empty_positions = [index for index, line in enumerate(lines) if line]
    if not non_empty_positions:
        return lines, False

    first = lines[non_empty_positions[0]]
    if detect_heading(first) == HeadingLevel.H1:
        consume = 1
        while consume < len(non_empty_positions) and consume < 4:
            current_index = non_empty_positions[consume]
            previous_index = non_empty_positions[consume - 1]
            if current_index != previous_index + 1:
                break
            candidate = lines[current_index]
            if not _looks_like_chapter_subtitle(candidate):
                break
            consume += 1

        if not header_heading:
            consumed_lines = [lines[non_empty_positions[0]]]
            if consume == 2:
                consumed_lines.append(lines[non_empty_positions[1]])
            header_heading = " ".join(consumed_lines).strip()

        if not header_heading:
            return lines, False

        remove_positions = set(non_empty_positions[:consume])
        rewritten = [f"# {header_heading}", ""]
        rewritten.extend(line for index, line in enumerate(lines) if index not in remove_positions)
        return _trim_blank_edges(rewritten), True

    title_page = _extract_essay_title_page(lines)
    if title_page is None:
        title_page = _extract_section_title_page(lines)
    if title_page is None:
        return lines, False

    title, remove_positions = title_page
    rewritten = [f"# {title}", ""]
    rewritten.extend(line for index, line in enumerate(lines) if index not in remove_positions)
    return _trim_blank_edges(rewritten), True


def _drop_leading_page_markers(lines: list[str]) -> list[str]:
    output = list(lines)
    while output and _looks_like_page_number_marker(output[0]):
        output = output[1:]
    return output


def _drop_leading_page_garbage(lines: list[str]) -> list[str]:
    output = list(lines)
    while output and _looks_like_page_garbage(output[0]):
        output = output[1:]
    return output


def _strip_trailing_inline_noise(line: str) -> str:
    return _TRAILING_INLINE_NOISE_RE.sub("", line).rstrip()


def _strip_series_headers(lines: list[str]) -> list[str]:
    return [line for line in lines if not _looks_like_series_header(line)]


def _looks_like_page_number_marker(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > 8:
        return False
    if re.search(r"[\u4e00-\u9fff]", stripped):
        return False
    if re.search(r"\d", stripped):
        return True
    letters = re.sub(r"[^A-Za-z]", "", stripped)
    return len(letters) <= 1


def _looks_like_page_garbage(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > 24:
        return False
    if stripped.startswith("#") or detect_heading(stripped) is not None:
        return False
    if re.search(r"[\u4e00-\u9fff]", stripped):
        return False
    letters = sum(char.isalpha() for char in stripped)
    lowercase = sum(char.islower() for char in stripped)
    digits = sum(char.isdigit() for char in stripped)
    if letters + digits == 0:
        return True
    return lowercase <= 2 and (letters + digits) >= 1


def _looks_like_series_header(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) < 4 or len(stripped) > 120:
        return False
    if re.search(r"[\u4e00-\u9fff]", stripped):
        return False
    compact = _normalize_series_header_candidate(stripped)
    if len(compact) < 4 or len(compact) > 14:
        return False
    letters = sum(char.isalpha() for char in stripped)
    digits = sum(char.isdigit() for char in stripped)
    if letters + digits > 14:
        return False

    similarity = max(
        SequenceMatcher(None, compact, target).ratio()
        for target in _SERIES_HEADER_TARGETS
    )
    if similarity < 0.52 and not _looks_like_series_header_fragment(stripped, compact):
        return False

    lowercase = sum(char.islower() for char in stripped)
    return lowercase <= 8 or " " in stripped


def _normalize_series_header_candidate(line: str) -> str:
    normalized = unicodedata.normalize("NFKD", line)
    normalized = "".join(
        char for char in normalized if not unicodedata.combining(char)
    )
    return re.sub(r"[^A-Za-z0-9]", "", normalized).upper()


def _looks_like_series_header_fragment(line: str, compact: str) -> bool:
    if len(compact) > 5:
        return False
    tokens = re.findall(r"[A-Za-z0-9]", line)
    if len(tokens) < 3:
        return False
    return compact.endswith(("VOI", "V0I", "VOL", "VOB", "VQI", "VO1"))


def _looks_like_byline(line: str) -> bool:
    stripped = line.strip()
    if not stripped or stripped[0] not in _BYLINE_PREFIXES:
        return False
    remainder = stripped[1:].strip()
    if not remainder or len(remainder) > _MAX_TITLE_LINE_LEN:
        return False
    return re.match(r"^[\W_]*\d", remainder) is None


def _looks_like_title_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > _MAX_TITLE_LINE_LEN:
        return False
    if stripped == "目录" or _EN_TOC_HEADER_RE.match(stripped):
        return False
    if _looks_like_front_matter_line(stripped):
        return False
    if _looks_like_page_number_marker(stripped) or _looks_like_byline(stripped):
        return False
    if is_toc_line(stripped):
        return False
    return not bool(re.search(r"[。！？!?；;]$", stripped))


def _join_title_lines(lines: list[str]) -> str:
    joined = ""
    for raw_line in lines:
        line = _normalize_title_join_line(raw_line)
        if not line:
            continue
        if not joined:
            joined = line
            continue
        if _should_join_without_space(joined, line):
            joined = f"{joined}{line}"
        else:
            joined = f"{joined} {line}"
    joined = re.sub(r"\s{2,}", " ", joined).strip()
    return joined.replace(" Cand Vice Versa)", " (and Vice Versa)")


def _normalize_title_join_line(line: str) -> str:
    stripped = line.strip()
    trailing_bar_stem = _strip_trailing_bar_header(stripped)
    if trailing_bar_stem is not None:
        return trailing_bar_stem
    return stripped


def _normalize_title_detection_line(line: str) -> str:
    stripped = _normalize_title_join_line(line)
    return stripped.removesuffix(";").removesuffix("；").removesuffix(":").removesuffix("：").rstrip()


def _should_join_without_space(previous: str, current: str) -> bool:
    if not previous or not current:
        return True
    if re.search(r"[\u4e00-\u9fff]$", previous):
        return True
    if re.match(r"^[\u4e00-\u9fff]", current):
        return True
    if current[0] in "—–-:：;；,，.。!?！？、)）]】":
        return True
    if previous[-1] in "([（【“‘\"'—–-":
        return True
    return False


def _looks_like_section_title_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > _MAX_TITLE_LINE_LEN:
        return False
    if "|" in stripped:
        return False
    if _looks_like_front_matter_line(stripped):
        return False
    if _looks_like_page_number_marker(stripped) or _looks_like_byline(stripped):
        return False
    if is_toc_line(stripped):
        return False
    if stripped.endswith((".", "。", "!", "！", ";", "；", ":", "：")):
        return False
    if re.search(r"[-—_]{2,}", stripped):
        return False
    if detect_heading(stripped) is not None:
        return True
    if stripped.isupper():
        return len(stripped) <= _MAX_TITLE_LINE_LEN and len(stripped.split()) <= 8
    return _looks_like_title_case_heading(stripped)


def _looks_like_title_fragment(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > _MAX_TITLE_LINE_LEN:
        return False
    if stripped.endswith((".", "。", "!", "！", ";", "；", ":", "：")):
        return False
    words = re.findall(r"[A-Za-z][A-Za-z'’-]*", stripped)
    if not words or len(words) > 4:
        return False
    return all(
        word.isupper() or word[0].isupper() or word.lower() in _TITLE_CASE_STOPWORDS
        for word in words
    )


def _looks_like_title_case_heading(line: str) -> bool:
    words = re.findall(r"[A-Za-z][A-Za-z'’-]*", line)
    if not words or len(words) > 12:
        return False

    good_words = 0
    for word in words:
        if word.isupper() or word[0].isupper() or word.lower() in _TITLE_CASE_STOPWORDS:
            good_words += 1

    return good_words >= max(2, len(words) - 1)


def _looks_like_title_page_body_start(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if _looks_like_front_matter_line(stripped):
        return False
    if _looks_like_page_number_marker(stripped) or is_toc_line(stripped):
        return False
    if stripped.isupper() and len(stripped.split()) <= 8:
        return False
    if len(stripped) >= 36:
        return True
    if _looks_like_body_line(stripped):
        return True
    return bool(re.match(r"^[\"'“‘(]*[A-Z][A-Za-z].{14,}$", stripped))


def _extract_essay_title_page(lines: list[str]) -> tuple[str, set[int]] | None:
    non_empty_positions = [index for index, line in enumerate(lines) if line]
    if len(non_empty_positions) < 2:
        return None

    start_offset = 0
    first_index = non_empty_positions[0]
    if _looks_like_page_number_marker(lines[first_index]) and len(non_empty_positions) >= 3:
        start_offset = 1

    title_positions: list[int] = []
    byline_position: int | None = None

    for position in non_empty_positions[start_offset:start_offset + 5]:
        line = lines[position]
        if _looks_like_byline(line):
            byline_position = position
            break
        if not _looks_like_title_line(line):
            return None
        title_positions.append(position)
        if len(title_positions) >= 3:
            continue

    if byline_position is None or not title_positions:
        return None

    title = _join_title_lines([lines[position] for position in title_positions])
    if not title:
        return None

    remove_positions = set(title_positions)
    if start_offset == 1:
        remove_positions.add(non_empty_positions[0])
    return title, remove_positions


def _extract_section_title_page(lines: list[str]) -> tuple[str, set[int]] | None:
    non_empty_positions = [index for index, line in enumerate(lines) if line]
    if len(non_empty_positions) < 2:
        return None

    start_offset = 0
    first_index = non_empty_positions[0]
    if _looks_like_page_number_marker(lines[first_index]) and len(non_empty_positions) >= 3:
        start_offset = 1

    title_positions: list[int] = []
    scan_positions = non_empty_positions[start_offset:start_offset + 5]
    for position in scan_positions:
        line = _normalize_title_detection_line(lines[position])
        if not line:
            break
        if not _looks_like_section_title_line(line):
            if not (title_positions and _looks_like_title_fragment(line)):
                break
        if title_positions and position != title_positions[-1] + 1:
            break
        if title_positions:
            previous_line = _normalize_title_detection_line(lines[title_positions[-1]])
            current_line = line.strip()
            if (
                len(title_positions) == 1
                and not previous_line.isupper()
                and detect_heading(previous_line) is None
                and current_line.isupper()
                and detect_heading(current_line) is None
            ):
                break
        title_positions.append(position)
        if len(title_positions) >= 3:
            break

    if not title_positions:
        return None

    next_index = None
    for position in non_empty_positions:
        if position > title_positions[-1]:
            next_index = position
            break

    if next_index is None or not _looks_like_title_page_body_start(lines[next_index]):
        return None

    title = _join_title_lines([lines[position] for position in title_positions])
    if not title:
        return None
    if len(title_positions) == 1:
        if detect_heading(title) is not None:
            return title, set(title_positions) | ({non_empty_positions[0]} if start_offset == 1 else set())
        if title.isupper() or not _looks_like_title_case_heading(title):
            return None

    remove_positions = set(title_positions)
    if start_offset == 1:
        remove_positions.add(non_empty_positions[0])
    return title, remove_positions


def _truncate_leading_local_toc(lines: list[str]) -> list[str]:
    non_empty_positions = [index for index, line in enumerate(lines) if line]
    for offset, index in enumerate(non_empty_positions[:10]):
        if offset > 8:
            break
        stripped = lines[index].strip()
        if stripped == "目录" or _EN_TOC_HEADER_RE.match(stripped):
            return _trim_blank_edges(lines[:index])
    return lines


def _normalize_leading_byline(lines: list[str]) -> list[str]:
    non_empty_positions = [index for index, line in enumerate(lines) if line]
    if not non_empty_positions:
        return lines
    first_position = 0
    if lines[non_empty_positions[0]].lstrip().startswith("#") and len(non_empty_positions) >= 2:
        first_position = 1

    first_index = non_empty_positions[first_position]
    if not _looks_like_byline(lines[first_index]):
        return lines

    normalized = list(lines)
    normalized[first_index] = _clean_byline_text(normalized[first_index])
    insert_after = first_index

    if len(non_empty_positions) > first_position + 1:
        second_index = non_empty_positions[first_position + 1]
        second_line = normalized[second_index].strip()
        if (
            second_index == first_index + 1
            and second_line
            and len(second_line) <= _MAX_TITLE_LINE_LEN
            and not _looks_like_outline_line(second_line)
            and not _looks_like_body_line(second_line)
            and second_line != "目录"
        ):
            insert_after = second_index

    if insert_after + 1 < len(normalized) and normalized[insert_after + 1]:
        normalized.insert(insert_after + 1, "")
    return normalized


def _strip_inline_ocr_numeric_leaders(lines: list[str]) -> list[str]:
    normalized = list(lines)
    previous_non_empty = ""

    for index, line in enumerate(normalized):
        stripped = line.strip()
        if not stripped:
            previous_non_empty = ""
            continue
        if (
            previous_non_empty
            and not _SENTENCE_END_RE.search(previous_non_empty)
            and re.match(r"^\d\s+[a-z]", stripped)
        ):
            normalized[index] = re.sub(r"^\d\s+", "", stripped, count=1)
            stripped = normalized[index]
        previous_non_empty = stripped

    return normalized


def _clean_byline_text(line: str) -> str:
    stripped = line.strip().lstrip(_BYLINE_PREFIXES).strip()
    stripped = re.sub(r"[\d\"'“”‘’`]+$", "", stripped).strip()
    return stripped or line.strip()


def _strip_leading_outline(lines: list[str]) -> list[str]:
    outline_count = 0
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            if outline_count >= 3:
                return _trim_blank_edges(lines[index + 1:])
            break
        if _looks_like_outline_line(stripped):
            outline_count += 1
            continue
        if outline_count >= 3 and _looks_like_body_line(stripped):
            return _trim_blank_edges(lines[index:])
        break

    if outline_count >= 3:
        return []
    return lines


def _merge_outline_continuations(lines: list[str]) -> list[str]:
    merged: list[str] = []
    index = 0
    while index < len(lines):
        current = lines[index]
        if index + 1 < len(lines):
            continuation = lines[index + 1].strip()
            if _should_merge_outline_continuation(current, continuation):
                merged.append(f"{current.rstrip()}{continuation}")
                index += 2
                continue
        merged.append(current)
        index += 1
    return merged


def _should_merge_outline_continuation(line: str, continuation: str) -> bool:
    stripped = line.strip()
    if not stripped or not continuation:
        return False
    if not _looks_like_numbered_outline_line(stripped):
        return False
    if _looks_like_outline_line(continuation):
        return False
    if len(continuation) > 6:
        return False
    return not _SENTENCE_END_RE.search(stripped)


def _strip_trailing_page_noise(lines: list[str]) -> list[str]:
    output = _trim_blank_edges(lines)
    while output and _looks_like_trailing_noise_line(output[-1]):
        output.pop()
    output = _trim_blank_edges(output)
    output = _drop_trailing_vertical_header_cluster(output)
    while output and _looks_like_trailing_noise_line(output[-1]):
        output.pop()
    return _trim_blank_edges(output)


def _looks_like_trailing_noise_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or detect_heading(stripped) is not None:
        return False
    return (
        _looks_like_page_number_marker(stripped)
        or _looks_like_page_garbage(stripped)
        or _looks_like_series_header(stripped)
        or _looks_like_dotted_rule(stripped)
        or _looks_like_orphan_tail_line(stripped)
    )


def _looks_like_dotted_rule(line: str) -> bool:
    stripped = line.strip()
    return bool(stripped) and re.fullmatch(r"[.\-_—•\s]{4,}", stripped) is not None


def _looks_like_orphan_tail_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or detect_heading(stripped) is not None:
        return False
    cjk = sum("\u4e00" <= char <= "\u9fff" for char in stripped)
    letters_digits = _count_latin_alnum(stripped)
    symbols = len(stripped) - cjk - letters_digits
    return len(stripped) <= 8 and cjk <= 1 and symbols >= 1 and letters_digits <= 1


def _drop_trailing_vertical_header_cluster(lines: list[str]) -> list[str]:
    if not lines:
        return lines

    index = len(lines) - 1
    cluster: list[str] = []
    while index >= 0:
        stripped = lines[index].strip()
        if not stripped:
            break
        if not _looks_like_vertical_header_fragment(stripped):
            break
        cluster.append(stripped)
        index -= 1

    if len(cluster) < 4:
        return lines

    compact_lengths = [len(line.replace(" ", "")) for line in cluster]
    short_count = sum(length <= 2 for length in compact_lengths)
    average_length = sum(compact_lengths) / len(compact_lengths)
    if short_count >= 3 and average_length <= 4:
        return lines[:index + 1]
    return lines


def _strip_embedded_noise_clusters(text: str) -> str:
    lines = text.splitlines()
    cleaned: list[str] = []
    index = 0
    while index < len(lines):
        stripped = lines[index].strip()
        if not stripped:
            cleaned.append("")
            index += 1
            continue
        if not _looks_like_hard_noise_cluster_line(stripped):
            cleaned.append(lines[index])
            index += 1
            continue

        cluster: list[str] = []
        cursor = index
        while cursor < len(lines):
            candidate = lines[cursor].strip()
            if not candidate or not _looks_like_noise_cluster_line(candidate):
                break
            cluster.append(candidate)
            cursor += 1

        if _is_removable_noise_cluster(cluster):
            index = cursor
            continue

        cleaned.append(lines[index])
        index += 1

    return _compact_blank_lines(cleaned)


def _looks_like_hard_noise_cluster_line(line: str) -> bool:
    stripped = line.strip()
    return bool(stripped) and (
        _looks_like_vertical_header_fragment(stripped)
        or _looks_like_dotted_rule(stripped)
        or _looks_like_orphan_tail_line(stripped)
    )


def _looks_like_noise_cluster_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if _looks_like_hard_noise_cluster_line(stripped):
        return True
    if _SENTENCE_END_RE.search(stripped):
        return False

    compact = stripped.replace(" ", "")
    if len(compact) > 16:
        return False
    cjk = sum("\u4e00" <= char <= "\u9fff" for char in compact)
    letters_digits = _count_latin_alnum(compact)
    return cjk >= 2 and letters_digits <= 4


def _is_removable_noise_cluster(cluster: list[str]) -> bool:
    if len(cluster) < 4:
        return False
    compact_lengths = [len(line.replace(" ", "")) for line in cluster]
    average_length = sum(compact_lengths) / len(compact_lengths)
    hard_hits = sum(
        _looks_like_hard_noise_cluster_line(line)
        for line in cluster
    )
    return average_length <= 6 and hard_hits >= 2


def _looks_like_vertical_header_fragment(line: str) -> bool:
    stripped = line.strip()
    if not stripped or detect_heading(stripped) is not None:
        return False

    compact = stripped.replace(" ", "")
    if len(compact) > 12:
        return False

    cjk = sum("\u4e00" <= char <= "\u9fff" for char in compact)
    letters_digits = _count_latin_alnum(compact)
    symbols = len(compact) - cjk - letters_digits
    if len(compact) <= 8 and cjk <= 1 and letters_digits <= 3 and symbols >= 1:
        return True

    if _looks_like_body_line(stripped):
        return False

    tokens = [token for token in stripped.split() if token]
    if tokens and all(len(token) <= 1 for token in tokens) and len(tokens) >= 3:
        return True

    return len(compact) <= 6 and (cjk == len(compact) or letters_digits <= len(compact))


def _count_latin_alnum(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9]", text))


def _looks_like_outline_line(line: str) -> bool:
    if len(line) > 70:
        return False
    if detect_heading(line) is not None:
        return True
    return bool(
        _PAREN_OUTLINE_RE.match(line)
        or _ARABIC_OUTLINE_RE.match(line)
        or _STAGE_OUTLINE_RE.match(line)
    )


def _looks_like_numbered_outline_line(line: str) -> bool:
    return bool(
        _PAREN_OUTLINE_RE.match(line)
        or _ARABIC_OUTLINE_RE.match(line)
    )


def _looks_like_body_line(line: str) -> bool:
    if len(line) > 24:
        return True
    return bool(re.search(r"[，,。！？!?；;：:]", line))


def _split_footnote_region(lines: list[str]) -> tuple[list[str], list[str]]:
    last_non_empty = max((i for i, line in enumerate(lines) if line), default=-1)
    if last_non_empty < 0:
        return [], []

    for split in range(last_non_empty - 1, -1, -1):
        if lines[split]:
            continue
        candidate = _trim_blank_edges(lines[split + 1:last_non_empty + 1])
        if _looks_like_footnote_block(candidate):
            return _trim_blank_edges(lines[:split]), candidate
        if split > 0 and is_footnote_marker(lines[split - 1]):
            adjusted_candidate = _trim_blank_edges(lines[split - 1:last_non_empty + 1])
            if _looks_like_footnote_block(adjusted_candidate):
                return _trim_blank_edges(lines[:split - 1]), adjusted_candidate

    candidate_starts = [
        index
        for index, line in enumerate(lines)
        if _is_probable_footnote_start(line)
        and index >= max(0, last_non_empty - _FOOTNOTE_LOOKBACK_LINES)
    ]
    if not candidate_starts:
        return lines, []

    start = candidate_starts[-1]
    while start > 0 and lines[start - 1]:
        start -= 1
    if start == 0:
        return lines, []

    candidate = _trim_blank_edges(lines[start:last_non_empty + 1])
    if not _looks_like_footnote_block(candidate):
        return lines, []
    return _trim_blank_edges(lines[:start]), candidate


def _attach_inline_footnote_refs(
    lines: list[str],
    known_numbers: list[str] | None = None,
) -> tuple[list[str], list[str]]:
    output: list[str] = []
    refs: list[str] = []
    ordered_numbers = sorted(set(known_numbers or ()), key=len, reverse=True)

    for line in lines:
        if not line:
            output.append("")
            continue
        if is_footnote_marker(line):
            refs.append(line)
            if output:
                output[-1] = f"{output[-1].rstrip()} [^{line}]"
            continue

        rewritten = line
        moved_ref, rewritten = _extract_leading_inline_footnote_ref(rewritten, ordered_numbers, refs)
        if moved_ref is not None:
            refs.append(moved_ref)
            if output:
                output[-1] = f"{output[-1].rstrip()} [^{moved_ref}]"

        for number in ordered_numbers:
            if number in refs:
                continue
            pattern = re.compile(
                rf"(?<!第)(?<=[\u4e00-\u9fff。！？!?；;：:，,、」』）)])"
                rf"{re.escape(number)}"
                rf"(?=$|\s*(?:[\u4e00-\u9fffA-Za-z「『（(]|(?:19|20)\d{{2}}(?:\s*年)?|\d+\s*[月日号號]))"
            )
            if pattern.search(rewritten):
                rewritten = pattern.sub(f" [^{number}] ", rewritten, count=1)
                refs.append(number)

        rewritten = re.sub(r"\s{2,}", " ", rewritten).strip()
        if not rewritten:
            continue
        if moved_ref is not None and output:
            joiner = "" if rewritten[0] in "，。、；：！？）」』" else " "
            output[-1] = f"{output[-1].rstrip()}{joiner}{rewritten}"
            continue
        if output and rewritten[0] in "，。、；：！？）」』":
            output[-1] = f"{output[-1].rstrip()}{rewritten}"
            continue
        output.append(rewritten)

    return output, refs


def _parse_footnotes(lines: list[str], refs: list[str]) -> list[str]:
    if not lines:
        return []

    ref_numbers = {int(ref) for ref in refs if ref.isdigit()}
    last_number: int | None = None
    footnotes: list[str] = []

    current_number: str | None = None
    current_parts: list[str] = []
    leading_parts: list[str] = []

    def _flush() -> None:
        nonlocal current_number, current_parts
        if current_number is None:
            return
        content = " ".join(part for part in current_parts if part).strip()
        if content:
            footnotes.append(f"^^^ [{current_number}] {content}")
        current_number = None
        current_parts = []

    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue

        if current_number is not None and line.startswith(current_number):
            remainder = line[len(current_number):].lstrip()
            if remainder and (not remainder[0].isdigit() or re.match(r"^(?:19|20)\d{2}\s*年", remainder)):
                current_parts.append(remainder)
                continue

        number, content = _split_footnote_start(line, refs)
        if number is not None:
            if current_number is not None and number == current_number and content and content != line:
                current_parts.append(content)
                continue
            parsed_number = int(number)
            starts_new = current_number is None
            if ref_numbers and parsed_number in ref_numbers and number != current_number:
                starts_new = True
            elif last_number is not None and parsed_number > last_number and parsed_number - last_number <= 5:
                starts_new = True

            if starts_new:
                if leading_parts and current_number is None and parsed_number > 1:
                    footnotes.append(
                        f"^^^ [{parsed_number - 1}] {' '.join(leading_parts).strip()}"
                    )
                    leading_parts = []
                _flush()
                current_number = number
                last_number = parsed_number
                current_parts = [content] if content else []
                continue

        if current_number is not None:
            current_parts.append(line)
        else:
            leading_parts.append(line)

    _flush()
    return footnotes


def _split_footnote_start(line: str, refs: list[str]) -> tuple[str | None, str]:
    stripped = line.strip()
    if is_footnote_marker(stripped):
        return stripped, ""

    ordered_refs = sorted(set(refs), key=lambda value: len(value), reverse=True)
    for ref in ordered_refs:
        if not stripped.startswith(ref) or len(stripped) <= len(ref):
            continue
        remainder = stripped[len(ref):].lstrip()
        if not remainder:
            return ref, ""
        if not remainder[0].isdigit() or re.match(r"^(?:19|20)\d{2}\s*年", remainder):
            return ref, remainder

    if _YEAR_LINE_RE.match(stripped) or re.match(r"^\d{3,}", stripped):
        return None, line

    if ordered_refs:
        return None, line

    match = _FOOTNOTE_START_FALLBACK_RE.match(stripped)
    if match is None:
        return None, line
    return match.group("num"), match.group("content").lstrip()


def _extract_leading_inline_footnote_ref(
    line: str,
    ordered_numbers: list[str],
    refs: list[str],
) -> tuple[str | None, str]:
    stripped = line.strip()
    for number in ordered_numbers:
        if number in refs or not stripped.startswith(number):
            continue
        remainder = stripped[len(number):]
        if not remainder:
            continue
        if re.match(r"^(?:[，。,；;：:！？!?、」』）)]|[「『（(])", remainder):
            return number, remainder.lstrip()
        if len(number) > 1 and re.match(r"^[\u4e00-\u9fffA-Za-z]", remainder):
            return number, remainder.lstrip()
        if re.match(r"^\s*(?:19|20)\d{2}(?:\s*年)?", remainder):
            return number, remainder.lstrip()
    return None, line


def _combine_fragments(fragments: list[_PageFragment]) -> str:
    parts: list[str] = []
    for fragment in fragments:
        if not parts:
            parts.append(fragment.text)
            continue
        separator = "\n\n" if fragment.starts_new_section else "\n"
        parts.append(separator)
        parts.append(fragment.text)
    return "".join(parts).strip()


def _extract_embedded_metadata(lines: list[str]) -> tuple[str, str]:
    title = ""
    author = ""
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        title_match = _METADATA_TITLE_RE.match(stripped)
        if title_match and not title:
            title = title_match.group("value").strip()
            continue
        author_match = _METADATA_AUTHOR_RE.match(stripped)
        if author_match and not author:
            author = author_match.group("value").strip()
    return title, author


def _normalize_metadata_title(existing: str, extracted: str) -> str:
    existing = existing.strip()
    extracted = extracted.strip()
    if extracted and (not existing or _SUSPICIOUS_METADATA_TITLE_RE.search(existing)):
        return extracted
    return existing


def _normalize_metadata_author(existing: str, extracted: str) -> str:
    existing = existing.strip()
    extracted = extracted.strip()
    if extracted and (not existing or _SUSPICIOUS_METADATA_AUTHOR_RE.match(existing)):
        return extracted
    return existing


def _looks_like_front_matter_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if re.search(r"^(?:U\.S\.A\.|Canada)\s+\$\d", stripped):
        return True
    if _METADATA_PAGE_KEYWORD_RE.search(stripped):
        return True
    return bool(_METADATA_TITLE_RE.match(stripped) or _METADATA_AUTHOR_RE.match(stripped))


def _is_front_matter_page(lines: list[str]) -> bool:
    non_empty = [line for line in lines if line]
    if not non_empty:
        return False

    metadata_hits = sum(1 for line in non_empty if _looks_like_front_matter_line(line))
    url_hits = sum("http" in line.lower() or "@" in line for line in non_empty)
    money_hits = sum(bool(re.search(r"(?:U\.S\.A\.|Canada|\$)\s*\$?\d", line)) for line in non_empty)
    short_lines = sum(1 for line in non_empty if len(line) <= 40)
    coverish_lines = sum(1 for line in non_empty if _looks_like_cover_title_line(line))
    title, author = _extract_embedded_metadata(non_empty)
    if title and author:
        return True
    if metadata_hits >= 4:
        return True
    if metadata_hits >= 2 and short_lines >= max(4, len(non_empty) // 2):
        return True
    if url_hits >= 1 and short_lines >= max(4, len(non_empty) // 2):
        return True
    if money_hits >= 1 and short_lines >= max(6, (len(non_empty) * 2) // 3):
        return True
    return coverish_lines >= 3 and len(non_empty) <= 6


def _is_toc_page(lines: list[str]) -> bool:
    non_empty = [line for line in lines if line]
    if len(non_empty) < 2:
        return False

    toc_score = 0
    has_toc_header = False
    toc_entries = 0
    page_refs = 0
    short_candidates = 0
    for line in non_empty:
        if _TOC_HEADER_RE.match(line) or _EN_TOC_HEADER_RE.match(line):
            toc_score += 3
            has_toc_header = True
        elif is_toc_line(line) or _looks_like_inline_toc_entry(line):
            toc_score += 2
            toc_entries += 1
        elif _TOC_PAGE_NUMBER_ONLY_RE.match(line):
            toc_score += 1
            page_refs += 1
        elif _looks_like_toc_section_heading(line):
            toc_score += 1
            short_candidates += 1
        elif is_page_header(line):
            toc_score += 1
        elif _looks_like_toc_candidate_title(line):
            short_candidates += 1

    if has_toc_header and page_refs >= 2 and short_candidates >= 2:
        return True
    if has_toc_header and toc_entries + page_refs >= 4 and short_candidates >= 4:
        return True
    if has_toc_header and toc_entries >= 1 and toc_score >= 4:
        return True
    if toc_entries >= 2 and page_refs >= 2 and toc_score >= max(5, len(non_empty) // 2):
        return True
    if toc_entries >= 2 and toc_score >= max(4, len(non_empty)):
        return True
    if has_toc_header:
        return toc_score >= max(6, len(non_empty) // 2)
    return toc_score >= max(8, len(non_empty))


def _looks_like_cover_title_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > _MAX_TITLE_LINE_LEN:
        return False
    if _looks_like_front_matter_line(stripped) or is_toc_line(stripped):
        return False
    if detect_heading(stripped) is not None:
        return False
    return stripped.isupper() or _looks_like_title_case_heading(stripped)


def _looks_like_inline_toc_entry(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > 80:
        return False
    if (
        detect_heading(stripped) is not None
        or _looks_like_body_line(stripped)
        or is_page_header(stripped)
        or _looks_like_series_header(stripped)
    ):
        return False
    return _INLINE_TOC_ENTRY_RE.match(stripped) is not None


def _looks_like_toc_candidate_title(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > 60:
        return False
    if _TOC_PAGE_NUMBER_ONLY_RE.match(stripped) or is_page_header(stripped):
        return False
    if stripped.endswith((".", "!", "?", "。", "！", "？")):
        return False
    return True


def _looks_like_toc_section_heading(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > 40:
        return False
    if _PART_TITLE_RE.match(stripped):
        return True
    return detect_heading(stripped) is not None


def _looks_like_chapter_subtitle(line: str) -> bool:
    stripped = line.strip()
    if not stripped or len(stripped) > 40:
        return False
    if "[^" in stripped or any(mark in stripped for mark in "#>*[]"):
        return False
    if stripped == "目录" or _EN_TOC_HEADER_RE.match(stripped):
        return False
    if _looks_like_byline(stripped) or _CREDIT_LINE_RE.match(stripped):
        return False
    if detect_heading(stripped) is not None:
        return False
    return not bool(re.search(r"[。！？!?；;]$", stripped))


def _trim_blank_edges(lines: list[str]) -> list[str]:
    start = 0
    end = len(lines)
    while start < end and not lines[start]:
        start += 1
    while end > start and not lines[end - 1]:
        end -= 1
    return lines[start:end]


def _compact_blank_lines(lines: list[str]) -> str:
    output: list[str] = []
    previous_blank = True
    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            if previous_blank:
                continue
            output.append("")
            previous_blank = True
            continue
        output.append(line)
        previous_blank = False
    return "\n".join(output).strip()


def _is_probable_footnote_start(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if _YEAR_LINE_RE.match(stripped):
        return False
    if is_footnote_marker(stripped):
        return True
    return _FOOTNOTE_START_FALLBACK_RE.match(stripped) is not None


def _extract_footnote_numbers(footnote_lines: list[str]) -> list[str]:
    numbers: list[str] = []
    for line in footnote_lines:
        match = _FOOTNOTE_BLOCK_RE.match(line)
        if match:
            numbers.append(match.group("num"))
    return numbers


def _looks_like_footnote_block(lines: list[str]) -> bool:
    return bool(_parse_footnotes(lines, []))


def _convert_standalone_footnotes(lines: list[str]) -> list[str]:
    output: list[str] = []
    index = 0

    while index < len(lines):
        line = lines[index]
        if not is_footnote_marker(line):
            output.append(line)
            index += 1
            continue

        footnote_lines: list[str] = []
        cursor = index + 1
        while cursor < len(lines):
            candidate = lines[cursor].strip()
            if not candidate:
                break
            if is_footnote_marker(candidate):
                break
            footnote_lines.append(candidate)
            cursor += 1

        if footnote_lines:
            if output and output[-1]:
                output.append("")
            output.append(f"^^^ [{line}] {' '.join(footnote_lines)}")
            index = cursor
            continue

        output.append(line)
        index += 1

    return output
