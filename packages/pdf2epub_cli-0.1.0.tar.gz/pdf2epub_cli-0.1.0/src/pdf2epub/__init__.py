from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from time import monotonic

from .book_model import BookMetadata
from .epub_builder import build_epub
from .language_detection import detect_language_code
from .llm_recognizer import (
    DEFAULT_STRUCTURE_PROMPT,
    LLMRecognitionError,
    OpenAITextRecognizer,
    RecognitionProgress,
    resolve_openai_compatible_config,
)
from .pdf_reader import PDFReadError, read_pdf_text
from .structure_parser import parse_markdown_to_book
from .text_extractor import ExtractMode, create_extractor


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pdf2epub",
        description="Convert PDF books to well-typeset EPUB files.",
    )
    parser.add_argument("pdf_path", type=Path, help="Path to the source PDF file.")
    parser.add_argument(
        "-o", "--output",
        type=Path,
        default=None,
        help="Output EPUB file path. Defaults to <pdf_name>.epub.",
    )
    parser.add_argument(
        "--page",
        type=int,
        default=None,
        help="Print text from a single 1-based page number.",
    )
    parser.add_argument(
        "--title",
        type=str,
        default=None,
        help="Book title for EPUB metadata. Auto-detected from PDF if not set.",
    )
    parser.add_argument(
        "--author",
        type=str,
        default=None,
        help="Book author for EPUB metadata. Auto-detected from PDF if not set.",
    )
    parser.add_argument(
        "--language",
        type=str,
        default=None,
        help="Book language code. Auto-detected from extracted text when omitted.",
    )
    parser.add_argument(
        "--text-only",
        action="store_true",
        help="Only print extracted text, do not generate EPUB.",
    )
    parser.add_argument(
        "--extract-mode",
        type=str,
        choices=["auto", "native", "llm"],
        default="auto",
        help=(
            "Extraction mode (default: auto). "
            "auto=detect automatically, native=read the PDF text layer directly, "
            "llm=run the LLM cleanup/OCR pipeline."
        ),
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=5,
        help="Number of pages per LLM request batch for cross-page context (default: 5).",
    )
    parser.add_argument(
        "--max-workers",
        type=int,
        default=4,
        help="Maximum number of concurrent LLM requests (default: 4).",
    )
    parser.add_argument(
        "--llm-model",
        type=str,
        default=None,
        help="OpenAI-compatible model name for text recognition.",
    )
    parser.add_argument(
        "--llm-base-url",
        type=str,
        default=None,
        help="Base URL of OpenAI-compatible API, such as http://127.0.0.1:11434/v1.",
    )
    parser.add_argument(
        "--llm-api-key",
        type=str,
        default=None,
        help="API key of OpenAI-compatible API. Defaults to env or dummy.",
    )
    parser.add_argument(
        "--llm-timeout",
        type=float,
        default=120.0,
        help="Timeout in seconds for each LLM request.",
    )
    parser.add_argument(
        "--llm-temperature",
        type=float,
        default=0.0,
        help="Sampling temperature for LLM requests.",
    )
    return parser


def _print_progress(progress: RecognitionProgress) -> None:
    line = f"Processing: {progress.completed}/{progress.total} batches"
    if progress.running_batches:
        now = monotonic()
        active = sorted(
            progress.running_batches,
            key=lambda batch: now - batch.started_at,
            reverse=True,
        )
        active_parts = [
            f"{batch.page_start}-{batch.page_end} ({int(now - batch.started_at)}s)"
            for batch in active[:3]
        ]
        extra = len(active) - len(active_parts)
        if extra > 0:
            active_parts.append(f"+{extra} more")
        line = f"{line} | active: {', '.join(active_parts)}"
    print(line, file=sys.stderr, flush=True)


def _resolve_llm_config(args: argparse.Namespace) -> OpenAICompatibleConfig | None:
    """尝试解析 LLM 配置，如果未配置则返回 None。"""
    configured_model = (
        os.getenv("PDF2EPUB_LLM_MODEL") or os.getenv("OPENAI_MODEL") or args.llm_model
    )
    if not configured_model:
        return None
    return resolve_openai_compatible_config(
        model=configured_model,
        base_url=args.llm_base_url,
        api_key=args.llm_api_key,
        timeout_seconds=args.llm_timeout,
        temperature=args.llm_temperature,
    )


def _exit_for_empty_extraction(
    parser: argparse.ArgumentParser,
    *,
    extract_mode: ExtractMode,
) -> None:
    message = (
        "Error: no extractable text was produced from this PDF. "
        "The file is likely scanned/image-only or the current extraction mode failed. "
    )
    if extract_mode == ExtractMode.NATIVE:
        message += "Try rerunning with --extract-mode=llm and a configured LLM model.\n"
    elif extract_mode == ExtractMode.AUTO:
        message += "Try rerunning with --extract-mode=llm if auto detection chose the wrong path.\n"
    else:
        message += "Please check the LLM output or retry with different settings.\n"
    parser.exit(status=1, message=message)


def _exit_for_empty_book(parser: argparse.ArgumentParser) -> None:
    parser.exit(
        status=1,
        message=(
            "Error: extracted text did not produce any EPUB chapters. "
            "Please inspect the source text or retry with --extract-mode=llm.\n"
        ),
    )


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    try:
        document = read_pdf_text(args.pdf_path)
    except (FileNotFoundError, PDFReadError, ValueError) as exc:
        parser.exit(status=1, message=f"Error: {exc}\n")

    extract_mode = ExtractMode(args.extract_mode)

    # --page mode: print single page text and exit
    if args.page is not None:
        llm_config = None
        try:
            llm_config = _resolve_llm_config(args)
        except ValueError as exc:
            parser.exit(status=1, message=f"Error: {exc}\n")

        if llm_config and not args.text_only:
            try:
                recognizer = OpenAITextRecognizer(config=llm_config)
                page = document.get_page(args.page)
                if page is None:
                    parser.exit(
                        status=1,
                        message=f"Error: page {args.page} is out of range (1-{document.page_count}).\n",
                    )
                recognized_page = recognizer.recognize_page(page)
                print(recognized_page.text)
                return
            except (ValueError, LLMRecognitionError) as exc:
                parser.exit(status=1, message=f"Error: {exc}\n")

        page = document.get_page(args.page)
        if page is None:
            parser.exit(
                status=1,
                message=f"Error: page {args.page} is out of range (1-{document.page_count}).\n",
            )
        print(page.text)
        return

    # --text-only mode: print full text (with optional extraction) and exit
    if args.text_only:
        try:
            llm_config = _resolve_llm_config(args)
            extractor = create_extractor(
                extract_mode,
                llm_config=llm_config,
                batch_size=args.batch_size,
                max_workers=args.max_workers,
            )
            document = extractor.extract(document, on_update=_print_progress)
        except (ValueError, LLMRecognitionError) as exc:
            parser.exit(status=1, message=f"Error: {exc}\n")
        if not document.full_text.strip():
            _exit_for_empty_extraction(parser, extract_mode=extract_mode)
        print(document.full_text)
        return

    # EPUB generation mode (default)
    try:
        llm_config = _resolve_llm_config(args)
    except ValueError as exc:
        parser.exit(status=1, message=f"Error: {exc}\n")

    # native 模式不需要 LLM；其他模式需要检查
    if extract_mode != ExtractMode.NATIVE and llm_config is None:
        parser.exit(
            status=1,
            message="Error: LLM model is required for EPUB generation (unless --extract-mode=native). "
            "Pass --llm-model or set PDF2EPUB_LLM_MODEL.\n",
        )

    try:
        extractor = create_extractor(
            extract_mode,
            llm_config=llm_config,
            prompt=DEFAULT_STRUCTURE_PROMPT,
            batch_size=args.batch_size,
            max_workers=args.max_workers,
        )
        print(
            f"Processing {document.page_count} pages "
            f"(mode={extract_mode.value}, batch_size={args.batch_size}, workers={args.max_workers})...",
            file=sys.stderr,
        )
        recognized = extractor.extract(document, on_update=_print_progress)
    except (ValueError, LLMRecognitionError) as exc:
        parser.exit(status=1, message=f"Error: {exc}\n")
    if not recognized.full_text.strip():
        _exit_for_empty_extraction(parser, extract_mode=extract_mode)

    # Auto-fill metadata from PDF if not explicitly provided via CLI
    pdf_meta = recognized.metadata
    language = args.language or detect_language_code(
        recognized.full_text,
        pdf_meta.title,
        pdf_meta.author,
    )
    metadata = BookMetadata(
        title=args.title or pdf_meta.title or args.pdf_path.stem,
        author=args.author or pdf_meta.author or "Unknown",
        language=language,
    )
    book = parse_markdown_to_book(recognized.full_text, metadata=metadata)
    if book.chapter_count == 0:
        _exit_for_empty_book(parser)

    output_path = args.output or args.pdf_path.with_suffix(".epub")
    try:
        build_epub(book, output_path)
    except ValueError as exc:
        parser.exit(status=1, message=f"Error: {exc}\n")
    print(f"EPUB saved to: {output_path}", file=sys.stderr)
