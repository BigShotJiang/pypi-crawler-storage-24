
server = "drp.vicnas.me"