import shutil
import os
import sys
import tty
import termios
import select

import globals as globals
import objects as objects

class Console:
    def __init__(self, keyboard, min_size_x = 80, min_size_y = 20, border_character="#", name="Application"):
        raw_size = shutil.get_terminal_size((min_size_x, min_size_y))
        self.border_character = border_character
        self.size = (raw_size.columns, raw_size.lines)
        self.display_item = None
        self.debug_item = None
        self.tab = None
        self.tab_mode = ""
        self.name = name
        self.keyboard = keyboard
        
    def registerItem(self, item):
        if self.tab:
            raise ValueError("Tab already registered")
        self.tab_mode = "item"
        self.display_item = item
        
    def register_debug_view(self, item):
        self.debug_item = item
        
    def register_tab(self, tab):
        if self.display_item:
            raise ValueError("Item already registered")
        self.tab_mode = "tab"
        self.tab = tab
        
    def clear(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        
    def start_files(self):
        if objects.started == False:
            objects._start()
        
    def start(self):
        self.start_files()
        self.clear()
        print("\033[?25l", end="")
        if self.tab_mode == "":
            raise ValueError("No display_item Provided")
        try:
            while True:
                self.keyboard.update()
                sys.stdout.write("\033[H")
                print("\033[H", end="")
                if self.tab_mode == "tab":
                    display_item = self.tab.items[self.tab.current]
                    items = self.tab.get_items()
                    toprint = ""
                    print(toprint, end="")
                    for i in range(self.size[0] - (len(toprint))):
                        print(self.border_character, end="")
                    print("")
                    print(self.border_character, end="")
                    a = ""
                    for i, item in enumerate(items):
                        c = f" {item} {self.border_character}"
                        if self.tab.current != i:
                            print(c, end="")
                        else:
                            print(f"{globals.HIGHLIGHT}{c}{globals.NORMAl}", end="")
                        a += c
                    d = ""
                    for i in range(self.size[0] - (len(a)+2)):
                        d += " "
                    print(d, end=self.border_character)
                    print("")
                else:
                    display_item = self.display_item
                if self.debug_item:
                    self.debug_item._print(self.size[0], display_item, self, self.border_character)
                toprint = f"# {self.name} # {display_item.__class__.__name__} "
                print(toprint, end="")
                for i in range(self.size[0] - (len(toprint))):
                    print(self.border_character, end="")
                print("")
                display_item._print(self.size[0]-2, self.size[1]-2, self.border_character)
                toprint = f"# PRESS ESCAPE TO GO BACK "
                print(toprint, end="")
                for i in range(self.size[0] - (len(toprint))):
                    print(self.border_character, end="")
                print("")
                sys.stdout.flush()
                if display_item._action():
                    break
                if display_item is globals.INPUT_FIELD_TYPE:
                    print(display_item.element.value)
        except KeyboardInterrupt:
            print("\033[?25h", end="")
            self.clear()
        print("\033[?25h", end="")
        
 
class TabRow:
    def __init__(self):
        self.items = []
        self.names = []
        self.current = 0
        
    def add_tab(self, item, tab_name):
        self.items.append(item)
        self.names.append(tab_name)
        
    def remove_tab(self, item, tab_name):
        self.items.remove(item)
        self.names.append(tab_name)

    def get_items(self):
        return self.names
   
    