import globals as globals

HIGHLIGHT = globals.HIGHLIGHT
NORMAl = globals.NORMAl

class ListItems:
    def __init__(self, name, items, keyboard, bullet_style=0):
        self.items = items
        self.name = name
        self.item_id = 0
        self.keyboard = keyboard
        
    def _action(self):
        if self.keyboard.W == True and self.item_id != 0:
            self.item_id -= 1
        elif self.keyboard.S == True and self.item_id != len(self.items)-1:
            self.item_id += 1
        elif self.keyboard.ENTER and self.items[self.item_id].is_executable():
            self.items[self.item_id].execute()
        elif self.keyboard.ESCAPE:
            return True
        return False
    
    def _print(self, size_x, size_y, border_character):
        
        output = []
        for i, element in enumerate(self.items):
            item = element.name
            if i > size_x - 1:
                break
            space = ""
            for _ in range(size_x - len(item)):
                space += " "
            if self.item_id == i:
                t = HIGHLIGHT
            else:
                t = NORMAl
            output.append(border_character + t + item + NORMAl + space + border_character)
    
        print("\n".join(output))
        
class Element:
    def __init__(self, name, value=None, func=None):
        self.name = name
        self.value = value
        self.func = func
        
    def execute(self):
        a = self.func(self.name, self.value)
        if a:
            self.value = a
        
    def is_executable(self):
        if self.func != None:
            return True
        return False


class InputField:
    def __init__(self, element, type, keyboard):
        self.element = element
        self.keyboard = keyboard
        self.buffer_value = element.value
        self.input_type = type
    
    def _print(self, size_x, size_y, border_character):
        output = []
        name = self.element.name + " - " + self.buffer_value
        space = ""
        for _ in range(size_x - len(name)):
            space += " "
        output.append(border_character + NORMAl + name + NORMAl + space + border_character)
    
        print("\n".join(output))
    
    def _action(self):
        a = self.keyboard._get_char()
        if a == "ESC":
            return True
        elif a == "ENTER":
            self.element.value = self.buffer_value
            return True
        elif a == "BACKSPACE":
            self.buffer_value = self.buffer_value[:-1]
        else:
            self.buffer_value += a
        return False
                
class DebugView:
    def __init__(self, Objects, attributes):
        self.objects = Objects
        self.attributes = attributes
        
    def _print(self, size_x, object, Cnsole, border_character):
        toprint = f"# DebugView "
        print(toprint, end="")
        for i in range(size_x - (len(toprint))):
            print(border_character, end="")
        print("")
        for ob in self.objects:
            if isinstance(object, ob):
                for at in self.attributes:
                    if hasattr(object, at):
                        text = f" {object.__class__.__name__}.{at} = {getattr(object, at)}"
                        space = ""
                        for _ in range(size_x - len(text)-2):
                            space += " "
                        print(border_character + NORMAl + text + NORMAl + space + border_character)
                        
            if isinstance(Cnsole, ob):
                for at in self.attributes:
                    if hasattr(Cnsole, at):
                        text = f" {Cnsole.__class__.__name__}.{at} = {getattr(Cnsole, at)}"
                        space = ""
                        for _ in range(size_x - len(text)-2):
                            space += " "
                        print(border_character + NORMAl + text + NORMAl + space + border_character)
  
  
started = False
def _start():
    globals.INPUT_FIELD_TYPE = InputField
    globals.ELEMENT_TYPE = Element
    globals.DEBUG_VIEW_TYPE = DebugView
    globals.LIST_VIEW_TYPE = ListItems
    started = True