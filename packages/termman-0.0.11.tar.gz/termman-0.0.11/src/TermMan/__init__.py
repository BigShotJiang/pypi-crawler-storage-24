from .globals import *
from .objects import *
from .console import *

__all__ = ["globals", "console", "objects"]