import sys
import select
import tty
import termios

class Keyboard:
    def __init__(self):
        self.ENTER = False
        self.BACKSPACE = False
        self.ESCAPE = False
        self.A = False
        self.S = False
        self.D = False
        self.W = False
        self.key = ""
    
    def update(self, menu_mode=False):
        self.BACKSPACE = False
        self.ESCAPE = False
        self.A = False
        self.S = False
        self.D = False
        self.W = False
        self.key = ""
        self.__get_char(menu_mode)

    def __get_char(self, menumode):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)

        try:
            tty.setraw(fd)

            ch = sys.stdin.read(1)

            if ch == '\x1b':  # ESC
                ch2 = sys.stdin.read(1)
                if ch2 == '[':
                    ch3 = sys.stdin.read(1)
                    if ch3 == 'A':
                        self.W = True
                    elif ch3 == 'B':
                        self.D = True
                    elif ch3 == 'C':
                        self.D = True
                    elif ch3 == 'D':
                        self.A = True
                    else:
                        self.ESCAPE = True
                    return

            if ch in ('\r', '\n'):  # Enter key
                self.ENTER = True
                return
            if ch in ('\x7f', '\x08'):  # Backspace key
                self.BACKSPACE = True
                return
            
            self.key = ch

        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            

k = Keyboard()
k.update()
print("TJR")