from src.TermMan.globals import BASE_KEYBOARD
from src.TermMan.objects import *
from src.TermMan.console import *

                
def sub_screen(name, value):
    e = Element(name, value=value)
    lst = InputField(element=e, type=str, keyboard=BASE_KEYBOARD)
    con = Console()
    con.registerItem(lst)
    con.start()


ls = ListItems(keyboard=BASE_KEYBOARD, name="List", items=[
    Element("Item1", func=sub_screen, value="TEST"), 
    Element("Item2", func=sub_screen, value="TEST"), 
    Element("Item3", func=sub_screen, value="TEST"), 
    Element("Item4", func=sub_screen, value="TEST")])

tab = TabRow()
tab.add_tab(ls, "Test List")
tab.add_tab(ls, "Testing list")

console = Console(BASE_KEYBOARD)
#console.registerItem(ls)

Debug = DebugView(Objects=[ListItems, Console], attributes=["name", "item_id", "tab_mode"])

console.register_tab(tab)
console.register_debug_view(Debug)
console.start()
