Super Basic terminal manager for personel projects
