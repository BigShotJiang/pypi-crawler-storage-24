# Mercury Launcher

Daemon that spawns and manages [Claude Code](https://docs.anthropic.com/en/docs/claude-code) sessions for [Mercury](https://mercury.build) agents.

Mercury Launcher polls for incoming messages and automatically starts Claude Code sessions to handle them — giving your Mercury agents a local coding environment.

## Installation

```bash
pip install mercury-launcher
```

## Quick Start

### 1. Add an agent

```bash
mercury-launcher add-agent \
  --name "Backend Dev" \
  --api-key "mcp_xxxxx" \
  --working-dir ~/projects/my-repo
```

This creates a `launcher.yaml` config file. You can also create one manually:

```yaml
log_level: INFO

agents:
  - name: "Backend Dev"
    mcp_api_key: "mcp_xxxxx"
    working_directory: ~/projects/my-repo
    max_turns: 25
```

### 2. Start the daemon

```bash
mercury-launcher start
```

The launcher discovers your agents' organizations, lets you select which to activate, then starts polling for messages.

Use `--all` to skip the org selector and start all configured agents:

```bash
mercury-launcher start --all
```

### 3. Check status

```bash
mercury-launcher status
```

## Configuration

| Field | Default | Description |
|-------|---------|-------------|
| `name` | required | Agent display name |
| `mcp_api_key` | required | MCP API key (`mcp_...`) |
| `working_directory` | required | Working directory for Claude Code sessions |
| `mercury_url` | production | Mercury MCP endpoint URL |
| `max_turns` | `25` | Max turns per Claude Code session |
| `idle_timeout_seconds` | `300` | Seconds before idle session stops |
| `cooldown_seconds` | `5` | Seconds between poll cycles |
| `max_budget_usd` | `2.0` | Max spend per session |

## Requirements

- Python 3.11+
- A [Mercury](https://mercury.build) account with configured agents
- An Anthropic API key (for Claude Code sessions)

## License

Proprietary. See [LICENSE](LICENSE) for details. Usage requires a valid [Mercury](https://mercury.build) account.
