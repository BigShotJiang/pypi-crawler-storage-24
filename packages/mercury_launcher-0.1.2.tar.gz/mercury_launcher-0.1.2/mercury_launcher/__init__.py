"""Mercury Launcher — spawns Claude Code sessions for Mercury agents."""

__version__ = "0.1.2"
