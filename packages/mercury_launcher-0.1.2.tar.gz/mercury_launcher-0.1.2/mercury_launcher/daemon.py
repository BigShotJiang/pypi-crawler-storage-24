"""Main daemon event loop — one polling task per agent."""

import asyncio
import signal
from typing import Dict

import httpx

from mercury_launcher.agent_runner import AgentRunner
from mercury_launcher.context_builder import build_session_prompt, build_system_prompt
from mercury_launcher.log import get_logger
from mercury_launcher.models import AgentConfig, LauncherConfig
from mercury_launcher.poller import MercuryError, MercuryPoller

logger = get_logger("daemon")


class Daemon:
    """Manages parallel polling loops for all configured agents."""

    def __init__(self, config: LauncherConfig, agents: list[AgentConfig] | None = None):
        self.config = config
        self._agents = agents or config.agents
        self._shutdown = asyncio.Event()
        self._agent_states: Dict[str, str] = {}  # name -> state

    async def run(self) -> None:
        """Start all agent loops and block until shutdown."""
        if not self._agents:
            logger.error("No agents configured. Add agents to launcher.yaml.")
            return

        # Register signal handlers
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._handle_signal)

        logger.info("Starting Mercury Launcher with %d agent(s)", len(self._agents))
        for agent in self._agents:
            logger.info("  - %s → %s", agent.name, agent.working_directory)

        tasks = [
            asyncio.create_task(self._agent_loop(agent), name=f"agent:{agent.name}")
            for agent in self._agents
        ]

        # Wait for shutdown signal
        await self._shutdown.wait()
        logger.info("Shutting down...")

        # Cancel all agent loops
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

        logger.info("All agent loops stopped.")

    def _handle_signal(self) -> None:
        logger.info("Received shutdown signal")
        self._shutdown.set()

    async def _agent_loop(self, agent_config: AgentConfig) -> None:
        """Poll-and-spawn loop for a single agent."""
        name = agent_config.name
        self._agent_states[name] = "starting"

        poller = MercuryPoller(
            endpoint=agent_config.mercury_url,
            api_key=agent_config.mcp_api_key,
        )
        async def _on_status(status: str) -> None:
            try:
                await poller.update_status(status)
            except Exception:
                pass  # Status is cosmetic

        runner = AgentRunner(
            agent_name=name,
            mercury_url=agent_config.mercury_url,
            mcp_api_key=agent_config.mcp_api_key,
            working_directory=agent_config.working_directory,
            max_turns=agent_config.max_turns,
            model=agent_config.model,
            max_budget_usd=agent_config.max_budget_usd,
            on_status=_on_status,
        )

        # Fetch agent context once at startup (cached for session prompts)
        agent_context = {}
        system_prompt = ""

        try:
            agent_context = await poller.get_agent_context()
            system_prompt = build_system_prompt(agent_context)
            ctx_name = agent_context.get("name", name)
            logger.info("[%s] Agent context loaded: %s (%s)", name, ctx_name, agent_context.get("agent_role", ""))
        except MercuryError as e:
            logger.warning("[%s] Could not fetch agent context (tool may not exist yet): %s", name, e)
            system_prompt = f"You are {name}, a Mercury agent. Respond to messages using Mercury MCP tools."
        except Exception as e:
            logger.warning("[%s] Error fetching agent context: %s", name, e)
            system_prompt = f"You are {name}, a Mercury agent. Respond to messages using Mercury MCP tools."

        self._agent_states[name] = "polling"
        logger.info("[%s] Entering poll loop", name)

        while not self._shutdown.is_set():
            try:
                # Long-poll for messages (blocks up to 30s)
                messages = await poller.wait_for_messages(timeout=30)

                if not messages:
                    continue

                logger.info("[%s] Received %d message(s)", name, len(messages))
                for msg in messages:
                    logger.info(
                        "[%s]   from %s: %s",
                        name,
                        msg.get("sender_name", "?"),
                        msg.get("content", "")[:100],
                    )

                # Build session prompt from incoming messages
                session_prompt = build_session_prompt(messages)

                # Spawn Claude Code session
                self._agent_states[name] = "session_active"
                try:
                    result = await runner.run_session(system_prompt, session_prompt)
                finally:
                    # Clear status in Mercury UI after session ends
                    try:
                        await poller.update_status(None)
                    except Exception:
                        pass

                if result.get("status") == "error":
                    logger.error("[%s] Session failed: %s", name, result.get("error"))

                self._agent_states[name] = "polling"

                # Cooldown between sessions
                await asyncio.sleep(agent_config.cooldown_seconds)

            except httpx.ConnectError:
                logger.warning("[%s] Connection refused — is Mercury running? Retrying in 10s…", name)
                self._agent_states[name] = "reconnecting"
                await asyncio.sleep(10)

            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if status in (502, 503, 504):
                    logger.warning("[%s] Server temporarily unavailable (%d). Retrying in 10s…", name, status)
                    self._agent_states[name] = "reconnecting"
                    await asyncio.sleep(10)
                else:
                    logger.error("[%s] HTTP error %d: %s", name, status, e)
                    await asyncio.sleep(5)

            except MercuryError as e:
                logger.error("[%s] Mercury error: %s", name, e)
                await asyncio.sleep(5)

            except asyncio.CancelledError:
                break

            except Exception as e:
                logger.error("[%s] Unexpected error: %s", name, e, exc_info=True)
                await asyncio.sleep(5)

        # Cleanup — clear status before closing
        try:
            await poller.update_status(None)
        except Exception:
            pass
        await poller.close()
        self._agent_states[name] = "stopped"
        logger.info("[%s] Stopped", name)

    def get_status(self) -> Dict[str, str]:
        """Return current state of all agents."""
        return dict(self._agent_states)
