"""Spawns Claude Code sessions via claude-agent-sdk."""

import asyncio
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional

from mercury_launcher.log import get_logger

logger = get_logger("agent_runner")

# Map SDK tool names to human-readable status labels
_TOOL_LABELS: Dict[str, str] = {
    "Read": "Reading file...",
    "Edit": "Editing file...",
    "Write": "Writing file...",
    "Bash": "Running command...",
    "Glob": "Searching files...",
    "Grep": "Searching code...",
    "WebFetch": "Fetching web page...",
    "WebSearch": "Searching the web...",
    "Task": "Running subagent...",
    "mcp__mercury__mercury_send_message": "Sending message...",
    "mcp__mercury__mercury_wait_for_messages": "Waiting for messages...",
    "mcp__mercury__mercury_list_agents": "Listing agents...",
    "mcp__mercury__mercury_read_thread": "Reading thread...",
}


def _tool_display_name(tool_name: str) -> str:
    """Convert an SDK tool name to a user-facing status label."""
    if tool_name in _TOOL_LABELS:
        return _TOOL_LABELS[tool_name]
    # Strip mcp__mercury__ prefix for other mercury tools
    if tool_name.startswith("mcp__mercury__"):
        short = tool_name.removeprefix("mcp__mercury__mercury_").replace("_", " ")
        return f"{short.capitalize()}..."
    return f"Using {tool_name}..."


class AgentRunner:
    """Manages Claude Code session lifecycle for a single Mercury agent."""

    def __init__(
        self,
        agent_name: str,
        mercury_url: str,
        mcp_api_key: str,
        working_directory: Path,
        max_turns: int = 25,
        model: Optional[str] = None,
        max_budget_usd: float = 2.0,
        on_status: Optional[Callable[[str], Awaitable[None]]] = None,
    ):
        self.agent_name = agent_name
        self.mercury_url = mercury_url
        self.mcp_api_key = mcp_api_key
        self.working_directory = working_directory
        self.max_turns = max_turns
        self.model = model
        self.max_budget_usd = max_budget_usd
        self._on_status = on_status
        self._active = False

    @property
    def is_active(self) -> bool:
        return self._active

    async def run_session(
        self,
        system_prompt: str,
        session_prompt: str,
    ) -> Dict[str, Any]:
        """Spawn a Claude Code session and wait for it to complete.

        Returns a dict with session results (cost, turns, duration, etc).
        """
        if self._active:
            logger.warning("[%s] Session already active, skipping", self.agent_name)
            return {"error": "session_already_active"}

        self._active = True
        try:
            return await self._spawn_session(system_prompt, session_prompt)
        finally:
            self._active = False

    async def _spawn_session(
        self,
        system_prompt: str,
        session_prompt: str,
    ) -> Dict[str, Any]:
        """Internal: spawn and run the Claude Code session."""
        from claude_agent_sdk import query, ClaudeAgentOptions, ResultMessage
        from claude_agent_sdk.types import AssistantMessage, ToolUseBlock

        # Configure MCP server for Mercury
        mcp_servers = {
            "mercury": {
                "type": "http",
                "url": self.mercury_url,
                "headers": {"x-api-key": self.mcp_api_key},
            }
        }

        options = ClaudeAgentOptions(
            system_prompt={
                "type": "preset",
                "preset": "claude_code",
                "append": system_prompt,
            },
            permission_mode="acceptEdits",
            cwd=str(self.working_directory),
            max_turns=self.max_turns,
            mcp_servers=mcp_servers,
            allowed_tools=[
                "mcp__mercury__*",  # All Mercury MCP tools
                "Read", "Write", "Edit", "Glob", "Grep", "Bash",
            ],
        )

        if self.model:
            options.model = self.model

        logger.info("[%s] Spawning Claude Code session (max_turns=%d)", self.agent_name, self.max_turns)

        result_info: Dict[str, Any] = {}

        try:
            async for message in query(prompt=session_prompt, options=options):
                # Surface tool use as status updates
                if isinstance(message, AssistantMessage) and self._on_status:
                    for block in message.content:
                        if isinstance(block, ToolUseBlock):
                            try:
                                await self._on_status(_tool_display_name(block.name))
                            except Exception:
                                pass  # Status is cosmetic — never disrupt session

                if isinstance(message, ResultMessage):
                    result_info = {
                        "status": getattr(message, "subtype", "unknown"),
                        "cost_usd": getattr(message, "total_cost_usd", 0),
                        "num_turns": getattr(message, "num_turns", 0),
                        "duration_ms": getattr(message, "duration_ms", 0),
                    }
                    logger.info(
                        "[%s] Session complete: status=%s, cost=$%.4f, turns=%d, duration=%dms",
                        self.agent_name,
                        result_info.get("status"),
                        result_info.get("cost_usd", 0),
                        result_info.get("num_turns", 0),
                        result_info.get("duration_ms", 0),
                    )

        except Exception as e:
            logger.error("[%s] Session error: %s", self.agent_name, e, exc_info=True)
            result_info = {"status": "error", "error": str(e)}

        return result_info
