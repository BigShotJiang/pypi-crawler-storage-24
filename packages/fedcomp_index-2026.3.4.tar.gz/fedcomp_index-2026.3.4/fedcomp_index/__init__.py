"""
FedComp Index - Federal contractor competitive intelligence.

Meta-package that installs the full FedComp Index toolkit:
- fedcomp-index-scoring: posture score computation
- fedcomp-index-data: pre-scored contractor datasets

FedComp Index scores every federal contractor in a state from 0 to 100
based on public award data, then assigns a posture class (Class 1, Class 2,
or Class 3) based on fixed score thresholds.

Website: https://fedcompindex.org/
Methodology: https://fedcompindex.org/methodology/
"""

__version__ = "2026.3.2"

from fedcomp_index_scoring import score_contractor, PostureClass, FedCompResult
from fedcomp_index_data import load_state, lookup, list_states

__all__ = [
    "score_contractor",
    "PostureClass",
    "FedCompResult",
    "load_state",
    "lookup",
    "list_states",
]
