"""
Excalidraw MCP Server
---------------------
Exposes the `draw_architecture_diagram` tool so Claude Code can generate
Excalidraw diagrams from logical node/edge descriptions.

After installing with pip:
    pip install excalidraw-mcp

Register with Claude Code:
    claude mcp add excalidraw excalidraw-mcp
"""

import asyncio
import sys
import traceback

import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server

from excalidraw_mcp.tools.draw_diagram import draw_diagram

app = Server("excalidraw-mcp")

TOOL_NAME = "draw_architecture_diagram"

INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "nodes": {
            "type": "array",
            "description": "List of nodes in the diagram.",
            "items": {
                "type": "object",
                "properties": {
                    "id":    {"type": "string", "description": "Unique identifier (no spaces)."},
                    "label": {"type": "string", "description": "Display label inside the shape."},
                    "shape": {
                        "type": "string",
                        "enum": ["rectangle", "ellipse", "diamond"],
                        "description": "Shape override. Auto-detected from label if omitted.",
                    },
                },
                "required": ["id", "label"],
            },
        },
        "edges": {
            "type": "array",
            "description": "Directed edges connecting nodes.",
            "items": {
                "type": "object",
                "properties": {
                    "from":  {"type": "string", "description": "Source node id."},
                    "to":    {"type": "string", "description": "Target node id."},
                    "label": {"type": "string", "description": "Optional edge label."},
                },
                "required": ["from", "to"],
            },
        },
        "title": {"type": "string", "description": "Optional diagram title."},
    },
    "required": ["nodes", "edges"],
}


@app.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name=TOOL_NAME,
            description=(
                "Generate a system architecture diagram in Excalidraw. "
                "Provide nodes (id + label) and directed edges (from + to). "
                "Layout, shapes, and arrow routing are handled automatically. "
                "The diagram opens instantly in the browser."
            ),
            inputSchema=INPUT_SCHEMA,
        )
    ]


@app.call_tool()
async def handle_call_tool(name: str, arguments: dict | None) -> list[types.TextContent]:
    if name != TOOL_NAME:
        raise ValueError(f"Unknown tool: {name}")
    if not arguments:
        raise ValueError("No arguments provided.")

    nodes = arguments.get("nodes", [])
    edges = arguments.get("edges", [])
    title = arguments.get("title")

    if not nodes:
        return [types.TextContent(type="text", text="Error: 'nodes' list is empty.")]

    try:
        result = draw_diagram(nodes, edges, title)
        return [types.TextContent(type="text", text=result["message"])]
    except Exception as exc:
        error_msg = f"Failed to generate diagram: {exc}\n\n{traceback.format_exc()}"
        return [types.TextContent(type="text", text=error_msg)]


async def _async_main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


def main() -> None:
    """Console script entry point.

    - When run directly in a terminal (stdin is a TTY): auto-configure Claude Code.
    - When piped by Claude Code (stdin is a pipe): start the MCP stdio server.
    """
    if sys.stdin.isatty():
        from excalidraw_mcp.setup import auto_install
        auto_install()
    else:
        asyncio.run(_async_main())


if __name__ == "__main__":
    main()
