"""
Auto-configures the excalidraw MCP server into Claude Code's ~/.claude.json.
Called automatically when `excalidraw-mcp` is run directly in a terminal.
"""

import json
import sys
from pathlib import Path


def _find_executable() -> str:
    """Return the full path to the excalidraw-mcp executable.

    Uses sysconfig to find the scripts directory for the exact Python
    environment where this package is installed — handles system installs,
    user installs (%APPDATA%), venvs, Homebrew, and pyenv on all platforms.
    """
    import sysconfig

    exe_name = "excalidraw-mcp.exe" if sys.platform == "win32" else "excalidraw-mcp"

    # sysconfig schemes to check, in priority order:
    #   'nt_user'    — Windows user install (%APPDATA%/Python/PythonXYZ/Scripts)
    #   'posix_user' — Unix/macOS user install (~/.local/bin)
    #   default      — system / venv install
    schemes = []
    if sys.platform == "win32":
        schemes = ["nt_user", "nt"]
    else:
        schemes = ["posix_user", "posix_prefix", "posix_home"]

    for scheme in schemes:
        try:
            scripts_dir = Path(sysconfig.get_path("scripts", scheme))
            candidate = scripts_dir / exe_name
            if candidate.exists():
                return str(candidate)
        except (KeyError, TypeError):
            continue

    # Fallback: check next to sys.executable (venv / conda)
    python = Path(sys.executable)
    for candidate in [
        python.parent / "Scripts" / exe_name,
        python.parent / exe_name,
        python.parent.parent / "bin" / exe_name,
    ]:
        if candidate.exists():
            return str(candidate)

    return "excalidraw-mcp"


def _claude_json_path() -> Path:
    return Path.home() / ".claude.json"


def auto_install() -> None:
    """Write the MCP server entry into ~/.claude.json and report result."""
    exe = _find_executable()
    claude_json = _claude_json_path()

    # Load existing config or start fresh
    config: dict = {}
    if claude_json.exists():
        try:
            config = json.loads(claude_json.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            config = {}

    # Build the server entry
    mcp_servers: dict = config.setdefault("mcpServers", {})
    mcp_servers["excalidraw"] = {
        "command": exe,
        "args": [],
        "type": "stdio",
    }

    claude_json.write_text(
        json.dumps(config, indent=2), encoding="utf-8"
    )

    print("✅ excalidraw MCP server registered in Claude Code!")
    print(f"   Config : {claude_json}")
    print(f"   Command: {exe}")
    print()
    print("Restart Claude Code, then try: 'draw a microservices architecture'")
