from collections import namedtuple
from typing import Any

import pytest  # type: ignore
from langchain_core.documents import Document
from voyageai.api_resources import VoyageResponse  # type: ignore
from voyageai.object import RerankingObject  # type: ignore

from langchain_voyageai.rerank import VoyageAIRerank

doc_list = [
    "The Mediterranean diet emphasizes fish, olive oil, and vegetables"
    ", believed to reduce chronic diseases.",
    "Photosynthesis in plants converts light energy into glucose and "
    "produces essential oxygen.",
    "20th-century innovations, from radios to smartphones, centered "
    "on electronic advancements.",
    "Rivers provide water, irrigation, and habitat for aquatic species, "
    "vital for ecosystems.",
    "Apple’s conference call to discuss fourth fiscal quarter results and "
    "business updates is scheduled for Thursday, November 2, 2023 at 2:00 "
    "p.m. PT / 5:00 p.m. ET.",
    "Shakespeare's works, like 'Hamlet' and 'A Midsummer Night's Dream,' "
    "endure in literature.",
]
documents = [Document(page_content=x) for x in doc_list]


@pytest.mark.requires("voyageai")
def test_init() -> None:
    VoyageAIRerank(
        voyage_api_key="foo",  # type: ignore[call-arg, arg-type]
        model="rerank-lite-1",
    )


@pytest.mark.requires("voyageai")
def test_init_with_api_key_alias() -> None:
    """Test that api_key can be passed directly (same as VoyageAIEmbeddings)."""
    rerank = VoyageAIRerank(
        api_key="foo",  # type: ignore[arg-type]
        model="rerank-lite-1",
    )
    assert rerank.voyage_api_key is not None
    assert rerank.voyage_api_key.get_secret_value() == "foo"


@pytest.mark.requires("voyageai")
def test_init_with_api_key_alias_and_base_url() -> None:
    """Test that api_key alias works together with base_url."""
    custom_url = "https://custom.example.com/v1"
    rerank = VoyageAIRerank(
        api_key="foo",  # type: ignore[arg-type]
        model="rerank-lite-1",
        base_url=custom_url,
    )
    assert rerank.voyage_api_key is not None
    assert rerank.voyage_api_key.get_secret_value() == "foo"
    assert rerank.base_url == custom_url


@pytest.mark.requires("voyageai")
def test_init_with_base_url() -> None:
    """Test reranker initialization with custom base_url."""
    custom_url = "https://custom.example.com/v1"
    rerank = VoyageAIRerank(
        voyage_api_key="foo",  # type: ignore[call-arg, arg-type]
        model="rerank-lite-1",
        base_url=custom_url,
    )
    assert rerank.base_url == custom_url


@pytest.mark.requires("voyageai")
def test_init_without_base_url() -> None:
    """Test reranker initialization without base_url (default behavior)."""
    rerank = VoyageAIRerank(
        voyage_api_key="foo",  # type: ignore[call-arg, arg-type]
        model="rerank-lite-1",
    )
    assert rerank.base_url is None


@pytest.mark.requires("voyageai")
def test_init_with_none_base_url() -> None:
    """Test reranker initialization with explicit None base_url."""
    rerank = VoyageAIRerank(
        voyage_api_key="foo",  # type: ignore[call-arg, arg-type]
        model="rerank-lite-1",
        base_url=None,
    )
    assert rerank.base_url is None


def get_mock_rerank_result() -> RerankingObject:
    VoyageResultItem = namedtuple("VoyageResultItem", ["index", "relevance_score"])
    Usage = namedtuple("Usage", ["total_tokens"])
    voyage_response = VoyageResponse()
    voyage_response.data = [
        VoyageResultItem(index=1, relevance_score=0.9),
        VoyageResultItem(index=0, relevance_score=0.8),
    ]
    voyage_response.usage = Usage(total_tokens=255)
    return RerankingObject(response=voyage_response, documents=doc_list)


@pytest.mark.requires("voyageai")
def test_rerank_unit_test(mocker: Any) -> None:
    mocker.patch("voyageai.Client.rerank").return_value = get_mock_rerank_result()
    expected_result = [
        Document(
            page_content="Photosynthesis in plants converts light energy into "
            "glucose and produces essential oxygen.",
            metadata={"relevance_score": 0.9, "total_tokens": 255},
        ),
        Document(
            page_content="The Mediterranean diet emphasizes fish, olive oil, and "
            "vegetables, believed to reduce chronic diseases.",
            metadata={"relevance_score": 0.8, "total_tokens": 255},
        ),
    ]

    rerank = VoyageAIRerank(
        voyage_api_key="foo",  # type: ignore[call-arg, arg-type]
        model="rerank-lite-1",
    )
    result = rerank.compress_documents(
        documents=documents, query="When is the Apple's conference call scheduled?"
    )
    assert expected_result == result


@pytest.mark.requires("voyageai")
def test_rerank_with_api_key_alias(mocker: Any) -> None:
    """Test that compress_documents works when initialized with api_key alias."""
    mocker.patch("voyageai.Client.rerank").return_value = get_mock_rerank_result()
    rerank = VoyageAIRerank(
        api_key="foo",  # type: ignore[arg-type]
        model="rerank-lite-1",
    )
    result = rerank.compress_documents(
        documents=documents, query="When is the Apple's conference call scheduled?"
    )
    assert len(result) == 2
    assert result[0].metadata["relevance_score"] == 0.9


def test_rerank_empty_input() -> None:
    rerank = VoyageAIRerank(
        voyage_api_key="foo",  # type: ignore[call-arg, arg-type]
        model="rerank-lite-1",
    )
    result = rerank.compress_documents(
        documents=[], query="When is the Apple's conference call scheduled?"
    )
    assert len(result) == 0
