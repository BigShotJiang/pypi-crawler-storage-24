"""OSMP MCP Server -- Octid Semantic Mesh Protocol."""
__version__ = "1.0.9"
