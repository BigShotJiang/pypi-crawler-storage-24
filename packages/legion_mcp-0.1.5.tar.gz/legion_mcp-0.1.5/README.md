# LEGION MCP

Knowledge & Code Intelligence MCP Server for Claude.

## Installation

```bash
pip install git+https://github.com/wearethelegion/legion-mcp.git
```

## Configuration

### Environment Variables

```bash
# Required: gRPC server connection
GRPC_SERVER_HOST=localhost
GRPC_SERVER_PORT=50051

# Required: Authentication
MCP_USER_EMAIL=your@email.com
MCP_USER_PASSWORD=your_password
```

### Claude Desktop Configuration

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "legion": {
      "command": "legion-mcp",
      "env": {
        "GRPC_SERVER_HOST": "localhost",
        "GRPC_SERVER_PORT": "50051",
        "MCP_USER_EMAIL": "your@email.com",
        "MCP_USER_PASSWORD": "your_password"
      }
    }
  }
}
```

## Available Tools

### Knowledge Management
- `queryKnowledge` - Search docs with hybrid retrieval (vector + graph + reranking)
- `fastQuery` - Fast vector-only search
- `createKnowledge` - Store documentation/notes
- `searchByTags` - Filter by metadata fields

### Code Intelligence
- `findSimilarCode` - Search code by natural language or snippet
- `createCode` - Index source code files
- `analyzeImpact` - Analyze blast radius of code changes
- `traceExecutionFlow` - Trace function call chains

### Expertise & Lessons
- `queryExpertise` - Search guides/tutorials
- `createExpertise` - Store structured knowledge
- `queryLessons` - Search past resolved issues
- `recordLesson` - Document resolved bugs

### Utility
- `getProjects` - List available projects
- `exploreGraph` - Run custom Cypher queries

## Requirements

- Python 3.10+
- Running LEGION gRPC server
- Valid LEGION user credentials
