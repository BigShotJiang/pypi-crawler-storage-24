"""
Tests for LEGION context tracking hooks module.

Tests cover:
- create_context_tracker() threshold warnings
- get_delegation_hooks() configuration
- Edge cases and error handling
"""

import pytest
from unittest.mock import patch, MagicMock

from legion_mcp.hooks.native import create_context_tracker
from legion_mcp.hooks.config import get_delegation_hooks


# ============================================================================
# Constants for test calculations
# ============================================================================

DEFAULT_CONTEXT_LIMIT = 200000

# Threshold token counts (calculated from percentages)
TOKENS_70_PERCENT = 140000  # 70% of 200000
TOKENS_85_PERCENT = 170000  # 85% of 200000
TOKENS_95_PERCENT = 190000  # 95% of 200000


# ============================================================================
# create_context_tracker() Tests - Empty/Zero Cases
# ============================================================================

class TestCreateContextTrackerEmptyCases:
    """Tests for empty context and zero token scenarios."""

    @pytest.mark.asyncio
    async def test_returns_empty_on_empty_context(self):
        """Hook returns {} when context is empty dict."""
        hook = await create_context_tracker()
        result = await hook({}, "tool-123", {})

        assert result == {}
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_returns_empty_when_total_tokens_zero(self):
        """Hook returns {} when all token counts are 0."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": 0,
                "output_tokens": 0,
                "cache_read_input_tokens": 0,
                "cache_creation_input_tokens": 0
            }
        }
        result = await hook({}, "tool-123", context)

        assert result == {}

    @pytest.mark.asyncio
    async def test_returns_empty_when_cumulative_usage_empty(self):
        """Hook returns {} when cumulative_usage exists but is empty."""
        hook = await create_context_tracker()
        context = {"cumulative_usage": {}}
        result = await hook({}, "tool-123", context)

        assert result == {}


# ============================================================================
# create_context_tracker() Tests - Threshold Warnings
# ============================================================================

class TestCreateContextTrackerThresholds:
    """Tests for context usage threshold warnings."""

    @pytest.mark.asyncio
    async def test_warning_at_70_percent(self):
        """Hook returns notice at 70% threshold (140000 tokens)."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": TOKENS_70_PERCENT,
                "output_tokens": 0
            }
        }
        result = await hook({}, "tool-123", context)

        assert "additionalContext" in result
        assert "70.0%" in result["additionalContext"]
        assert "Context notice" in result["additionalContext"]
        assert "140,000" in result["additionalContext"]

    @pytest.mark.asyncio
    async def test_warning_at_85_percent(self):
        """Hook returns warning at 85% threshold (170000 tokens)."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": TOKENS_85_PERCENT,
                "output_tokens": 0
            }
        }
        result = await hook({}, "tool-123", context)

        assert "additionalContext" in result
        assert "85.0%" in result["additionalContext"]
        assert "CONTEXT WARNING" in result["additionalContext"]
        assert "170,000" in result["additionalContext"]

    @pytest.mark.asyncio
    async def test_critical_at_95_percent(self):
        """Hook returns critical warning at 95% threshold (190000 tokens)."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": TOKENS_95_PERCENT,
                "output_tokens": 0
            }
        }
        result = await hook({}, "tool-123", context)

        assert "additionalContext" in result
        assert "95.0%" in result["additionalContext"]
        assert "CONTEXT CRITICAL" in result["additionalContext"]
        assert "190,000" in result["additionalContext"]
        assert "remember()" in result["additionalContext"]

    @pytest.mark.asyncio
    async def test_no_warning_below_70_percent(self):
        """Hook returns {} when usage is below 70% threshold."""
        hook = await create_context_tracker()
        # 69% usage = 138000 tokens
        context = {
            "cumulative_usage": {
                "input_tokens": 138000,
                "output_tokens": 0
            }
        }
        result = await hook({}, "tool-123", context)

        assert result == {}

    @pytest.mark.asyncio
    async def test_aggregates_all_token_types(self):
        """Hook sums all token types for total calculation."""
        hook = await create_context_tracker()
        # Split 140000 tokens across all types (70% threshold)
        context = {
            "cumulative_usage": {
                "input_tokens": 35000,
                "output_tokens": 35000,
                "cache_read_input_tokens": 35000,
                "cache_creation_input_tokens": 35000
            }
        }
        result = await hook({}, "tool-123", context)

        assert "additionalContext" in result
        assert "70.0%" in result["additionalContext"]

    @pytest.mark.asyncio
    async def test_custom_context_limit(self):
        """Hook respects custom context_limit parameter."""
        # Custom limit of 100000 - at 70000 tokens = 70%
        hook = await create_context_tracker(context_limit=100000)
        context = {
            "cumulative_usage": {
                "input_tokens": 70000,
                "output_tokens": 0
            }
        }
        result = await hook({}, "tool-123", context)

        assert "additionalContext" in result
        assert "70.0%" in result["additionalContext"]
        assert "70,000/100,000" in result["additionalContext"]


# ============================================================================
# create_context_tracker() Tests - Error Handling
# ============================================================================

class TestCreateContextTrackerErrorHandling:
    """Tests for graceful error handling."""

    @pytest.mark.asyncio
    async def test_handles_none_context_gracefully(self):
        """Hook returns {} when context is None."""
        hook = await create_context_tracker()
        # Simulate None being passed (defensive handling)
        result = await hook({}, "tool-123", None)

        assert result == {}

    @pytest.mark.asyncio
    async def test_handles_malformed_context_non_dict(self):
        """Hook returns {} when context is not a dict."""
        hook = await create_context_tracker()

        # Test with string
        result = await hook({}, "tool-123", "not a dict")
        assert result == {}

        # Test with list
        result = await hook({}, "tool-123", [1, 2, 3])
        assert result == {}

        # Test with int
        result = await hook({}, "tool-123", 12345)
        assert result == {}

    @pytest.mark.asyncio
    async def test_handles_malformed_cumulative_usage(self):
        """Hook returns {} when cumulative_usage is not a dict."""
        hook = await create_context_tracker()
        context = {"cumulative_usage": "not a dict"}
        result = await hook({}, "tool-123", context)

        assert result == {}

    @pytest.mark.asyncio
    async def test_handles_none_token_values(self):
        """Hook treats None token values as 0."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": None,
                "output_tokens": 140000  # Should still trigger 70%
            }
        }
        result = await hook({}, "tool-123", context)

        assert "additionalContext" in result
        assert "70.0%" in result["additionalContext"]


# ============================================================================
# create_context_tracker() Tests - Edge Cases
# ============================================================================

class TestCreateContextTrackerEdgeCases:
    """Tests for edge cases and boundary conditions."""

    @pytest.mark.asyncio
    async def test_partial_usage_data_only_input_tokens(self):
        """Hook works with only input_tokens present."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": TOKENS_70_PERCENT
                # Other token types missing
            }
        }
        result = await hook({}, "tool-123", context)

        assert "additionalContext" in result
        assert "70.0%" in result["additionalContext"]

    @pytest.mark.asyncio
    async def test_very_large_token_counts(self):
        """Hook handles very large token counts without overflow."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": 1_000_000_000,  # 1 billion tokens
                "output_tokens": 1_000_000_000
            }
        }
        result = await hook({}, "tool-123", context)

        # Should return critical (way over 95%)
        assert "additionalContext" in result
        assert "CONTEXT CRITICAL" in result["additionalContext"]

    @pytest.mark.asyncio
    async def test_missing_cumulative_usage_key(self):
        """Hook returns {} when cumulative_usage key is missing entirely."""
        hook = await create_context_tracker()
        context = {
            "some_other_key": {"data": "value"}
        }
        result = await hook({}, "tool-123", context)

        assert result == {}

    @pytest.mark.asyncio
    async def test_threshold_boundary_at_exactly_70(self):
        """Hook triggers at exactly 70% (boundary test)."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": 140000  # Exactly 70%
            }
        }
        result = await hook({}, "tool-123", context)

        assert "additionalContext" in result
        assert "Context notice" in result["additionalContext"]

    @pytest.mark.asyncio
    async def test_threshold_boundary_just_below_70(self):
        """Hook does NOT trigger just below 70% (boundary test)."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": 139999  # Just under 70%
            }
        }
        result = await hook({}, "tool-123", context)

        assert result == {}

    @pytest.mark.asyncio
    async def test_highest_threshold_wins(self):
        """Hook returns critical (not warning) when at 95%."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": 195000  # 97.5% - should be CRITICAL not just WARNING
            }
        }
        result = await hook({}, "tool-123", context)

        assert "CONTEXT CRITICAL" in result["additionalContext"]
        assert "CONTEXT WARNING" not in result["additionalContext"]

    @pytest.mark.asyncio
    async def test_hook_is_idempotent(self):
        """Multiple calls with same context return same result."""
        hook = await create_context_tracker()
        context = {
            "cumulative_usage": {
                "input_tokens": TOKENS_70_PERCENT
            }
        }

        result1 = await hook({}, "tool-1", context)
        result2 = await hook({}, "tool-2", context)
        result3 = await hook({}, "tool-3", context)

        assert result1 == result2 == result3


# ============================================================================
# get_delegation_hooks() Tests
# ============================================================================

class TestGetDelegationHooks:
    """Tests for hook configuration builder."""

    @pytest.mark.asyncio
    async def test_returns_dict_with_pre_tool_use_key(self):
        """get_delegation_hooks returns dict containing PreToolUse key."""
        hooks = await get_delegation_hooks()

        assert isinstance(hooks, dict)
        assert "PreToolUse" in hooks

    @pytest.mark.asyncio
    async def test_hook_list_is_not_empty(self):
        """PreToolUse hook list contains at least one hook."""
        hooks = await get_delegation_hooks()

        pre_tool_use = hooks.get("PreToolUse", [])
        assert len(pre_tool_use) > 0

    @pytest.mark.asyncio
    async def test_hook_structure_with_hook_matcher(self):
        """Hook config has correct structure (HookMatcher or dict)."""
        hooks = await get_delegation_hooks()

        pre_tool_use = hooks.get("PreToolUse", [])
        assert len(pre_tool_use) > 0

        hook_config = pre_tool_use[0]
        # Should have matcher, hooks, and timeout (either as HookMatcher or dict)
        if isinstance(hook_config, dict):
            assert "matcher" in hook_config
            assert "hooks" in hook_config
            assert "timeout" in hook_config
        else:
            # HookMatcher object
            assert hasattr(hook_config, "matcher")
            assert hasattr(hook_config, "hooks")

    @pytest.mark.asyncio
    async def test_fallback_to_dict_when_hook_matcher_unavailable(self):
        """Falls back to dict structure when HookMatcher import fails."""
        with patch.dict('sys.modules', {'claude_agent_sdk': None}):
            # Force ImportError by making module None
            with patch('legion_mcp.hooks.config.create_context_tracker') as mock_tracker:
                mock_hook = MagicMock()
                mock_tracker.return_value = mock_hook

                # Re-import to trigger fallback path
                # The actual implementation handles this internally
                hooks = await get_delegation_hooks()

                # Should still return valid structure
                assert isinstance(hooks, dict)

    @pytest.mark.asyncio
    async def test_returns_empty_dict_on_complete_failure(self):
        """Returns {} if hook creation fails entirely."""
        with patch('legion_mcp.hooks.config.create_context_tracker', side_effect=Exception("Creation failed")):
            hooks = await get_delegation_hooks()

            assert hooks == {}


# ============================================================================
# Integration-style Tests
# ============================================================================

class TestHooksIntegration:
    """Integration tests verifying hooks work together."""

    @pytest.mark.asyncio
    async def test_created_hook_is_callable(self):
        """Hook returned by create_context_tracker is async callable."""
        hook = await create_context_tracker()

        assert callable(hook)
        # Verify it's actually async
        import asyncio
        result = hook({}, "test", {})
        assert asyncio.iscoroutine(result)
        # Clean up the coroutine
        await result

    @pytest.mark.asyncio
    async def test_delegation_hooks_contain_working_tracker(self):
        """Hooks from get_delegation_hooks include functional context tracker."""
        hooks = await get_delegation_hooks()

        if not hooks:
            pytest.skip("Hook creation failed (expected in isolated test env)")

        pre_tool_use = hooks.get("PreToolUse", [])
        if not pre_tool_use:
            pytest.skip("No PreToolUse hooks configured")

        hook_config = pre_tool_use[0]

        # Extract the actual hook function
        if isinstance(hook_config, dict):
            hook_list = hook_config.get("hooks", [])
        else:
            hook_list = getattr(hook_config, "hooks", [])

        assert len(hook_list) > 0

        # Test the hook works
        context_hook = hook_list[0]
        test_context = {
            "cumulative_usage": {
                "input_tokens": TOKENS_85_PERCENT
            }
        }
        result = await context_hook({}, "integration-test", test_context)

        assert "additionalContext" in result
        assert "WARNING" in result["additionalContext"]
