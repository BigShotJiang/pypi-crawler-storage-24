"""
LocalProxyManager - Manages Claude API proxy process LOCALLY on the MCP host.

Architecture:
- MCP runs locally on the user's machine (alongside Claude Code)
- Proxy process (mitmdump) must run on the SAME machine as MCP
- gRPC server is remote — used only as state store (DB records, heartbeat)
- This module spawns/kills processes locally and syncs state to gRPC

Pattern mirrors delegation_runner.py: local process + remote state reporting.
"""

import asyncio
import logging
import os
import shutil
import signal
import socket
import subprocess
import time
import uuid
from typing import Any, Dict, Optional

from legion_mcp.agent_context import get_agent_proxy

logger = logging.getLogger(__name__)

# Default configuration
DEFAULT_PORT = 34763
DEFAULT_HOST = "localhost"
HEARTBEAT_INTERVAL_SECONDS = 5

# Generate unique owner ID for this MCP server instance
OWNER_ID = f"{os.getpid()}-{uuid.uuid4().hex[:8]}"


def _get_addon_path() -> str:
    """
    Get the absolute path to the mitmproxy addon script.
    Lives inside the legion-mcp package at proxy/addon.py.
    """
    return os.path.join(os.path.dirname(__file__), "proxy", "addon.py")


def _get_log_dir() -> str:
    """Get the proxy log directory (same default as addon.py).

    Returns the path from LEGION_PROXY_LOG_DIR env var, or defaults to
    the ``proxy/logs`` directory next to the addon script.
    """
    return os.environ.get(
        "LEGION_PROXY_LOG_DIR",
        os.path.join(os.path.expanduser("~"), ".legion", "proxy", "logs"),
    )


def _check_port_health(host: str, port: int, timeout: float = 1.0) -> bool:
    """Check if a port is responding via TCP connection."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            return result == 0
    except Exception:
        return False


def _is_pid_alive(pid: int) -> bool:
    """Check if a local process with the given PID is alive."""
    if pid is None or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _kill_process_group(pid: int, timeout: float = 5.0) -> bool:
    """
    Kill a local process group. SIGTERM first, then SIGKILL.
    Returns True if process was killed, False if it wasn't running.
    """
    if not _is_pid_alive(pid):
        return False

    try:
        pgid = os.getpgid(pid)

        logger.info(f"Sending SIGTERM to process group {pgid}")
        os.killpg(pgid, signal.SIGTERM)

        start = time.time()
        while time.time() - start < timeout:
            if not _is_pid_alive(pid):
                logger.info(f"Process {pid} terminated gracefully")
                return True
            time.sleep(0.1)

        if _is_pid_alive(pid):
            logger.warning(f"Process {pid} didn't terminate, sending SIGKILL")
            os.killpg(pgid, signal.SIGKILL)
            time.sleep(0.5)

        return not _is_pid_alive(pid)

    except ProcessLookupError:
        logger.debug(f"Process {pid} already dead")
        return True
    except Exception as e:
        logger.error(f"Failed to kill process {pid}: {e}")
        return False


def _kill_process_on_port(port: int) -> bool:
    """Find and kill the process listening on a given port.

    Uses lsof to discover the PID, then kills the process group.
    Used to clean up orphaned mitmdump processes from previous MCP sessions.
    """
    try:
        result = subprocess.run(
            ["lsof", "-ti", f":{port}"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0 or not result.stdout.strip():
            return False

        for pid_str in result.stdout.strip().split("\n"):
            pid = int(pid_str.strip())
            logger.info(f"Killing orphaned process {pid} on port {port}")
            _kill_process_group(pid)

        return True
    except Exception as e:
        logger.warning(f"Failed to kill process on port {port}: {e}")
        return False


class LocalProxyManager:
    """
    Manages a locally-spawned mitmdump proxy process.
    Reports state to gRPC server (pure state store).

    Lifecycle:
    1. start() → spawn locally + register in gRPC DB
    2. heartbeat_loop() → periodic heartbeat + stop_requested detection
    3. stop() → kill locally + update gRPC DB
    4. status() → check local PID/port + sync with DB
    """

    def __init__(self):
        self._proxy_id: Optional[str] = None
        self._pid: Optional[int] = None
        self._process: Optional[subprocess.Popen] = None  # Keep ref to prevent GC
        self._port: int = DEFAULT_PORT
        self._host: str = DEFAULT_HOST
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._owner_id: str = OWNER_ID

    @property
    def proxy_id(self) -> Optional[str]:
        return self._proxy_id

    @property
    def pid(self) -> Optional[int]:
        return self._pid

    @property
    def is_running(self) -> bool:
        return self._pid is not None and _is_pid_alive(self._pid)

    async def start(
        self,
        port: int = DEFAULT_PORT,
        log_level: str = "warn"
    ) -> Dict[str, Any]:
        """
        Start proxy locally and register state in gRPC.

        1. Call gRPC StartProxy to create DB record (status=starting)
        2. Spawn mitmdump locally via subprocess
        3. Set PID + owner in DB, update status to running
        4. Start heartbeat loop

        Returns:
            dict: {status, proxy_id, pid, port, message}
        """
        from legion_mcp.grpc_client import get_grpc_client_manager
        from legion_mcp.protos import proxy_pb2

        self._port = port
        self._host = DEFAULT_HOST

        # --- Pre-flight checks: fail fast with clear errors ---
        # Check mitmdump BEFORE gRPC call — most common failure on fresh machines
        mitmdump_path = shutil.which("mitmdump")
        if not mitmdump_path:
            msg = (
                "mitmdump not found. Install mitmproxy:\n"
                "  brew install mitmproxy    (macOS)\n"
                "  pip install mitmproxy     (pip/venv)"
            )
            logger.error(f"[PROXY] {msg}")
            return {
                "status": "error",
                "error_message": msg,
                "error_code": "MITMDUMP_NOT_FOUND"
            }

        # Check company_id — required for DB record
        ctx = get_agent_proxy().context
        company_id = (ctx.company_id if ctx else None) or os.environ.get("LEGION_COMPANY_ID", "")
        if not company_id:
            msg = (
                "LEGION_COMPANY_ID not set. Proxy requires a company context.\n"
                "Set LEGION_COMPANY_ID in your .mcp.json env block."
            )
            logger.error(f"[PROXY] {msg}")
            return {
                "status": "error",
                "error_message": msg,
                "error_code": "MISSING_COMPANY_ID"
            }

        try:
            client = get_grpc_client_manager()
            await client.ensure_connected()

            # Step 1: Create DB record via gRPC
            # Pull company/project from agent context (set by whoAmI).
            # Fall back to env vars for auto-start (lifespan runs before whoAmI).
            project_id = (ctx.project_id if ctx else None) or os.environ.get("LEGION_PROJECT_ID", "")

            request = proxy_pb2.StartProxyRequest(
                user_token=client.token or "",
                company_id=company_id,
                project_id=project_id,
                port=port,
                proxy_path="",  # Not used by server anymore
                log_level=log_level,
                host=DEFAULT_HOST
            )

            response = await client.call_with_auth(
                client.proxy_stub.StartProxy,
                request
            )

            # PORT_IN_USE means a DB record exists for this port.
            # Three cases:
            #   1. Port is healthy → existing proxy is alive, reuse it
            #   2. Port is free → stale record, process already dead → clean and retry
            #   3. Port is occupied by non-proxy → kill orphan and retry
            if (response.status != "success"
                    and response.error_code == "PORT_IN_USE"):
                port_alive = _check_port_health(DEFAULT_HOST, port)

                # Case 1: Port is healthy — reuse existing proxy
                if port_alive:
                    stale_proxy_id = response.error_message.split("proxy ")[-1] if response.error_message else ""
                    logger.info(
                        f"Proxy already running on port {port} "
                        f"(id={stale_proxy_id}) — reusing existing instance"
                    )
                    self._proxy_id = stale_proxy_id
                    self._port = port

                    # Start heartbeat to keep the record alive from this session
                    self._start_heartbeat()
                    return {
                        "status": "success",
                        "proxy_id": stale_proxy_id,
                        "pid": 0,  # We don't own the process
                        "port": port,
                        "message": f"Reusing existing proxy on {DEFAULT_HOST}:{port}"
                    }

                # Case 2/3: Port is dead — clean stale record and retry
                logger.info(
                    f"Port {port} has stale DB record (port dead) — cleaning up and retrying"
                )

                stale_proxy_id = response.error_message.split("proxy ")[-1] if response.error_message else ""
                if stale_proxy_id:
                    try:
                        stop_req = proxy_pb2.StopProxyRequest(
                            user_token=client.token or "",
                            proxy_id=stale_proxy_id
                        )
                        await client.call_with_auth(
                            client.proxy_stub.StopProxy,
                            stop_req
                        )
                        logger.info(f"Cleaned stale proxy record {stale_proxy_id}")
                    except Exception as e:
                        logger.warning(f"Failed to clean stale record: {e}")

                # Retry StartProxy
                response = await client.call_with_auth(
                    client.proxy_stub.StartProxy,
                    request
                )

            if response.status != "success":
                return {
                    "status": "error",
                    "error_message": response.error_message,
                    "error_code": response.error_code
                }

            proxy_id = response.proxy_id
            self._proxy_id = proxy_id

            # Step 2: Resolve addon path and spawn locally
            addon_path = _get_addon_path()

            if not os.path.exists(addon_path):
                await self._update_status_via_grpc(proxy_id, "failed",
                                                   f"Addon not found: {addon_path}")
                return {
                    "status": "error",
                    "error_message": f"Addon not found: {addon_path}",
                    "error_code": "ADDON_NOT_FOUND"
                }

            # Resolve mitmdump binary — pyenv shims (bash with set -e) can fail
            # in subprocess environments, so resolve to real binary path
            mitmdump_path = shutil.which("mitmdump")
            if not mitmdump_path:
                await self._update_status_via_grpc(proxy_id, "failed",
                                                   "mitmdump not found in PATH")
                return {
                    "status": "error",
                    "error_message": "mitmdump not found in PATH. Install mitmproxy.",
                    "error_code": "MITMDUMP_NOT_FOUND"
                }

            # If it's a pyenv shim, resolve to real binary
            try:
                with open(mitmdump_path, 'rb') as f:
                    if f.read(20).startswith(b'#!/'):
                        # It's a script (likely pyenv shim) — resolve real path
                        result = subprocess.run(
                            ["pyenv", "which", "mitmdump"],
                            capture_output=True, text=True, timeout=5
                        )
                        if result.returncode == 0 and result.stdout.strip():
                            mitmdump_path = result.stdout.strip()
                            logger.info(f"Resolved pyenv shim to: {mitmdump_path}")
            except Exception as e:
                logger.debug(f"Shim resolution skipped: {e}")

            cmd = [
                mitmdump_path,
                "--mode", "reverse:https://api.anthropic.com",
                "-p", str(port),
                "-s", addon_path
            ]

            if log_level == "debug":
                cmd.extend(["-v"])
            elif log_level == "error":
                cmd.extend(["-q"])

            logger.info(f"Spawning proxy locally: {' '.join(cmd)}")

            try:
                # Spawn mitmdump with a clean environment.
                # mitmdump is a Python script under pyenv — it uses a different
                # Python than the MCP server's virtualenv. Inheriting the MCP
                # server's env (VIRTUAL_ENV, PYTHONPATH, etc.) poisons
                # mitmdump's Python startup and kills it instantly.
                # Delegation subprocesses don't have this problem because they
                # run in the SAME virtualenv as the MCP server.
                # mitmdump v12 writes ALL output (including addon logs) to stdout,
                # not stderr. Capture stdout for diagnostics; stderr kept for crashes.
                stdout_log = f"/tmp/legion_proxy_{proxy_id}.log"
                stdout_file = open(stdout_log, "w")
                stderr_log = f"/tmp/legion_proxy_{proxy_id}.stderr"
                stderr_file = open(stderr_log, "w")

                log_dir = _get_log_dir()
                clean_env = {
                    "PATH": os.environ.get("PATH", "/usr/bin:/bin:/usr/local/bin"),
                    "HOME": os.environ.get("HOME", ""),
                    "USER": os.environ.get("USER", ""),
                    "LANG": os.environ.get("LANG", "en_US.UTF-8"),
                    "TERM": os.environ.get("TERM", "xterm-256color"),
                    "LEGION_PROXY_LOG_DIR": log_dir,
                    # Cognitive extraction: API key for Haiku calls
                    "ANTHROPIC_API_KEY": os.environ.get("ANTHROPIC_API_KEY", ""),
                    # gRPC connection for extraction_store subprocess
                    "LEGION_GRPC_HOST": os.environ.get(
                        "GRPC_SERVER_HOST", "api.wearethelegion.com"
                    ),
                    "LEGION_GRPC_PORT": os.environ.get(
                        "GRPC_SERVER_PORT", "50051"
                    ),
                    # LEGION API key for extraction_store auth
                    "LEGION_API_KEY": os.environ.get("LEGION_API_KEY", ""),
                    # MCP user credentials for extraction_store auth (email/password flow)
                    "MCP_USER_EMAIL": os.environ.get("MCP_USER_EMAIL", ""),
                    "MCP_USER_PASSWORD": os.environ.get("MCP_USER_PASSWORD", ""),
                    # Cognitive extraction: company/project context for DB persistence
                    "LEGION_COMPANY_ID": os.environ.get("LEGION_COMPANY_ID", ""),
                    "LEGION_PROJECT_ID": os.environ.get("LEGION_PROJECT_ID", ""),
                }

                process = subprocess.Popen(
                    cmd,
                    stdin=subprocess.DEVNULL,
                    stdout=stdout_file,
                    stderr=stderr_file,
                    start_new_session=True,
                    env=clean_env,
                )

                self._process = process
                self._pid = process.pid

                # Give it a moment to start (or crash)
                await asyncio.sleep(1)

                if process.poll() is not None:
                    # Process already exited — read stderr for diagnostics
                    stderr_file.close()
                    stderr_content = ""
                    try:
                        with open(stderr_log) as f:
                            stderr_content = f.read()
                    except Exception:
                        pass
                    await self._update_status_via_grpc(
                        proxy_id, "failed",
                        f"mitmdump exited immediately: {stderr_content}"
                    )
                    return {
                        "status": "error",
                        "error_message": f"mitmdump died immediately. stderr: {stderr_content}",
                        "error_code": "PROCESS_DIED",
                        "pid": process.pid,
                        "stderr": stderr_content,
                        "stderr_log": stderr_log,
                    }

            except FileNotFoundError:
                await self._update_status_via_grpc(proxy_id, "failed",
                                                   "mitmdump not found. Install mitmproxy.")
                return {
                    "status": "error",
                    "error_message": "mitmdump not found. Install mitmproxy.",
                    "error_code": "MITMDUMP_NOT_FOUND"
                }
            except Exception as e:
                await self._update_status_via_grpc(proxy_id, "failed", str(e))
                return {
                    "status": "error",
                    "error_message": str(e),
                    "error_code": "SUBPROCESS_ERROR"
                }

            # Step 3: Start heartbeat loop.
            # The first heartbeat auto-transitions status from "starting" to
            # "running" in the DB (handled by repo.update_heartbeat query).
            self._start_heartbeat()

            logger.info(f"Proxy started locally: id={proxy_id} pid={self._pid} port={port}")

            return {
                "status": "success",
                "proxy_id": proxy_id,
                "pid": self._pid,
                "port": port,
                "message": f"Proxy started on {DEFAULT_HOST}:{port}"
            }

        except Exception as e:
            logger.error(f"LocalProxyManager.start() failed: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "START_PROXY_FAILED"
            }

    async def stop(self, proxy_id: str = "") -> Dict[str, Any]:
        """
        Stop the locally running proxy and update gRPC state.

        1. Kill local process group
        2. Stop heartbeat loop
        3. Call gRPC StopProxy to mark as stopped in DB

        Args:
            proxy_id: Optional proxy ID to stop. If provided and no local proxy
                      is tracked, will clean up the DB record (stale cleanup).
                      If empty, stops the locally tracked proxy.
        """
        from legion_mcp.grpc_client import get_grpc_client_manager
        from legion_mcp.protos import proxy_pb2

        # Resolve which proxy to stop
        target_proxy_id = self._proxy_id or proxy_id

        # Stop heartbeat first
        self._stop_heartbeat()

        # Kill local process
        if self._pid:
            killed = _kill_process_group(self._pid)
            if killed:
                logger.info(f"Killed local proxy process {self._pid}")
            else:
                logger.warning(f"Local proxy process {self._pid} was not running")
            self._pid = None
            self._process = None

        # Update gRPC state
        if target_proxy_id:
            try:
                client = get_grpc_client_manager()
                await client.ensure_connected()

                request = proxy_pb2.StopProxyRequest(
                    user_token=client.token or "",
                    proxy_id=target_proxy_id
                )

                response = await client.call_with_auth(
                    client.proxy_stub.StopProxy,
                    request
                )

                if response.status != "success":
                    logger.warning(
                        f"gRPC StopProxy returned: {response.error_message}"
                    )

            except Exception as e:
                logger.warning(f"Failed to update gRPC state on stop: {e}")

            if self._proxy_id == target_proxy_id:
                self._proxy_id = None

            return {
                "status": "success",
                "proxy_id": target_proxy_id,
                "message": "Proxy stopped"
            }

        return {
            "status": "success",
            "message": "No proxy was running"
        }

    async def status(self) -> Dict[str, Any]:
        """
        Check local proxy health and sync with DB status.

        Returns combined local + DB status information.
        """
        from legion_mcp.grpc_client import get_grpc_client_manager
        from legion_mcp.protos import proxy_pb2

        # Local checks
        pid_alive = self._pid is not None and _is_pid_alive(self._pid)
        port_healthy = _check_port_health(self._host, self._port)

        # If we think we're running but process died
        if self._proxy_id and not pid_alive and self._pid is not None:
            logger.warning(
                f"Proxy {self._proxy_id} pid {self._pid} died — cleaning up"
            )
            self._stop_heartbeat()
            await self._update_status_via_grpc(self._proxy_id, "orphaned",
                                               "Process died unexpectedly")
            self._pid = None

        # Get DB status
        if self._proxy_id:
            try:
                client = get_grpc_client_manager()
                await client.ensure_connected()

                request = proxy_pb2.GetProxyStatusRequest(
                    user_token=client.token or "",
                    proxy_id=self._proxy_id
                )

                response = await client.call_with_auth(
                    client.proxy_stub.GetProxyStatus,
                    request
                )

                if response.status == "success":
                    return {
                        "status": "success",
                        "proxy_id": response.proxy_id,
                        "proxy_status": response.proxy_status,
                        "name": response.name,
                        "host": response.host,
                        "port": response.port,
                        "pid": self._pid or 0,
                        "port_healthy": port_healthy,
                        "started_at": response.started_at,
                        "uptime_seconds": response.uptime_seconds,
                        "last_heartbeat": response.last_heartbeat
                    }

            except Exception as e:
                logger.warning(f"Failed to get DB status: {e}")

        # No active proxy — check if there's one in DB
        if not self._proxy_id:
            try:
                client = get_grpc_client_manager()
                await client.ensure_connected()

                ctx = get_agent_proxy().context
                list_request = proxy_pb2.ListProxiesRequest(
                    user_token=client.token or "",
                    company_id=(ctx.company_id if ctx else None) or "",
                    project_id=(ctx.project_id if ctx else None) or "",
                    status_filter="running"
                )
                list_response = await client.call_with_auth(
                    client.proxy_stub.ListProxies,
                    list_request
                )

                if list_response.status == "success" and list_response.proxies:
                    proxy_info = list_response.proxies[0]
                    return {
                        "status": "success",
                        "proxy_id": proxy_info.proxy_id,
                        "proxy_status": proxy_info.status,
                        "name": proxy_info.name,
                        "host": proxy_info.host,
                        "port": proxy_info.port,
                        "pid": 0,
                        "port_healthy": _check_port_health(
                            proxy_info.host or DEFAULT_HOST,
                            proxy_info.port or DEFAULT_PORT
                        ),
                        "started_at": proxy_info.started_at,
                        "uptime_seconds": "",
                        "last_heartbeat": ""
                    }

            except Exception as e:
                logger.warning(f"Failed to list proxies: {e}")

        return {
            "status": "success",
            "proxy_status": "not_running",
            "message": "No running proxy found"
        }

    def _start_heartbeat(self):
        """Start the background heartbeat loop."""
        if self._heartbeat_task and not self._heartbeat_task.done():
            return

        self._heartbeat_task = asyncio.ensure_future(self._heartbeat_loop())

    def _stop_heartbeat(self):
        """Stop the background heartbeat loop."""
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            self._heartbeat_task = None

    async def _heartbeat_loop(self):
        """
        Periodic heartbeat loop:
        1. Send heartbeat to gRPC (keeps DB timestamp fresh)
        2. Check heartbeat response — if success=False, stop_requested was detected
        3. If stop_requested → kill local process and update state
        4. If local process died → clean up and mark orphaned
        """
        from legion_mcp.grpc_client import get_grpc_client_manager
        from legion_mcp.protos import proxy_pb2

        logger.info(
            f"Proxy heartbeat loop started for {self._proxy_id} "
            f"(interval={HEARTBEAT_INTERVAL_SECONDS}s)"
        )

        while True:
            try:
                await asyncio.sleep(HEARTBEAT_INTERVAL_SECONDS)

                # Check if local process is still alive
                if self._pid and not _is_pid_alive(self._pid):
                    logger.warning(
                        f"Proxy process {self._pid} died — marking orphaned"
                    )
                    await self._update_status_via_grpc(
                        self._proxy_id, "orphaned",
                        "Process died unexpectedly"
                    )
                    self._pid = None
                    break

                # Send heartbeat to gRPC
                if self._proxy_id:
                    try:
                        client = get_grpc_client_manager()
                        await client.ensure_connected()

                        request = proxy_pb2.ProxyHeartbeatRequest(
                            proxy_id=self._proxy_id,
                            owner_id=self._owner_id
                        )

                        response = await client.call_with_auth(
                            client.proxy_stub.UpdateProxyHeartbeat,
                            request
                        )

                        # success=False means stop_requested or ownership lost
                        if not response.success:
                            logger.info(
                                f"Heartbeat returned success=False — "
                                f"stop_requested or ownership lost, killing local proxy"
                            )
                            await self.stop()
                            break

                    except Exception as e:
                        logger.warning(f"Heartbeat send failed: {e}")
                        # Don't kill on transient gRPC failures — keep running

            except asyncio.CancelledError:
                logger.info("Proxy heartbeat loop cancelled")
                break
            except Exception as e:
                logger.error(f"Heartbeat loop error: {e}")
                await asyncio.sleep(HEARTBEAT_INTERVAL_SECONDS)

    async def _update_status_via_grpc(
        self,
        proxy_id: str,
        status: str,
        error_message: str = ""
    ):
        """Helper to update proxy status in gRPC DB."""
        from legion_mcp.grpc_client import get_grpc_client_manager
        from legion_mcp.protos import proxy_pb2

        try:
            client = get_grpc_client_manager()
            await client.ensure_connected()

            if status in ("stopped", "failed", "orphaned"):
                # Use StopProxy for terminal states
                request = proxy_pb2.StopProxyRequest(
                    user_token=client.token or "",
                    proxy_id=proxy_id
                )
                await client.call_with_auth(
                    client.proxy_stub.StopProxy,
                    request
                )
            # For non-terminal states, we'd need another RPC.
            # Currently only terminal states are updated this way.

        except Exception as e:
            logger.warning(f"Failed to update proxy status via gRPC: {e}")



# Singleton instance
_proxy_manager: Optional[LocalProxyManager] = None


def get_proxy_manager() -> LocalProxyManager:
    """Get or create singleton LocalProxyManager."""
    global _proxy_manager
    if _proxy_manager is None:
        _proxy_manager = LocalProxyManager()
    return _proxy_manager
