#!/usr/bin/env python3
"""
LEGION MCP-to-gRPC Bridge Server.

This FastMCP server provides 40 tools that delegate all operations to the LEGION gRPC service.

=== AUTH & PROJECTS ===
- authenticateUser: Trigger authentication, return user data
- getProjects: Return cached projects from auth

=== KNOWLEDGE (Flat Text Storage - NO LLM) ===
- createKnowledge: Store unstructured text for semantic search (static parsing, no LLM)
- queryKnowledge: Query knowledge with hybrid retrieval (vector + graph, no LLM reranking)
- fastQuery: Same as queryKnowledge (both now skip LLM, kept for API compatibility)
- searchByTags: Filter knowledge by metadata fields (keywords, chunk_type, has_code)
- exploreGraph: Run custom Cypher queries on knowledge graph

=== CODE INTELLIGENCE ===
- createCode: Index source code for semantic search and call graph analysis
- findSimilarCode: Find similar code by natural language or code snippet
- analyzeImpact: Analyze blast radius of changing a function/class
- traceExecutionFlow: Trace what functions get called from entry point

=== EXPERTISE (Structured Hierarchical Documents) ===
- createExpertise: Create expertise document with hierarchical sections
- addExpertiseChunk: Add section/subsection to existing expertise
- queryExpertise: Search expertise using vector similarity
- listExpertise: List all expertise for a project (no search, just browse)
- getExpertise: Get full expertise by ID with all content
- updateExpertise: Update an existing expertise. Only provided fields are changed.

=== LESSONS LEARNED ===
- recordLesson: Document resolved issues (symptom, root cause, solution)
- queryLessons: Search past issues to find solutions

=== AGENT IDENTITY & SKILLS ===
Identity bootstrap, lifecycle management, and deterministic skill navigation.
The LLM IS the semantic search engine - it reads skill trees and fetches what it needs.

- whoAmI: CALL THIS FIRST! Identity bootstrap for orchestrator (Arthur).
          Returns: who you are, your instructions, skills overview, available agents.
          You MUST call this when starting a LEGION session.

- getAgentSkills: Get agent's complete skill tree (titles, summaries, chunk_ids)
                  Use after whoAmI to get full skill details.
                  Navigate semantically, then call getSkillContent for content.

- searchSkillDetails: Semantic search within a skill's chunks - PREFERRED way to find content.
                      Returns FULL CONTENT - often no second call needed.

- getSkillSections: Get sections for ONE expertise document - FALLBACK for browsing.
                    Use when you don't know what to search for.

- getSkillContent: Fetch full content of a skill section by chunk_id.
                   Use after identifying relevant section.
                   Returns full markdown with code examples.

- linkAgentSkill: Link expertise to agent, making it a navigable skill.
                  Use after createExpertise to grant agent access.
                  Creates HAS_SKILL relationship in graph.

- unlinkAgentSkill: Remove skill link from agent.
                    Use for cleanup or role changes.
                    Does NOT delete expertise, only the link.

=== AGENT LIFECYCLE ===
Create and delete specialist agents in the LEGION system.

- createAgent: Birth a new specialist agent. Auto-links learning skill.
               Use to build your team (Researcher, Developer, Architect, etc.)

- deleteAgent: Remove an agent and clean up all associations.
               Unlinks skills, removes from Neo4j and PostgreSQL.

=== ENGAGEMENT (Conversation Session Management) ===
Track conversation history, decisions, insights, and plans throughout work sessions.
Provides resumption context and semantic search across past engagements.

- createEngagement: Start new engagement (work session) for a project
- getEngagement: Get engagement details with entry metadata (lightweight)
                 Returns metadata only (id, entry_type, title, content_length, created_at) - use getEntry for full content
- getEntry: Get full content for a single entry by ID
- listEngagements: List engagements for a project with optional status filter
- updateEngagement: Update engagement details (name, status, summary)
- addEntry: Add entry to engagement (requirement, insight, decision, plan, etc.)
- searchEntries: Hybrid search across entries (Vector + Graph + RRF fusion)
- resumeEngagement: Get formatted resumption context grouped by entry type

=== TASK MANAGEMENT ===
Create, track, and manage tasks with agent assignments and artifact traceability.
Link tasks to engagements for context and to artifacts (code, knowledge, etc.).

- createTask: Create new task with optional assignment and priority
- getTask: Get task details with linked artifacts
- listTasks: List tasks with optional filters (project, engagement, agent, status)
- updateTask: Update task details (status, assignment, blockers, priority)
- assignTask: Assign task to an agent (convenience method)
- completeTask: Mark task as completed with timestamp
- linkArtifact: Link artifact to task for traceability (code, knowledge, expertise, lesson)
"""

import asyncio
import hashlib
import json
import logging
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

from fastmcp import FastMCP

from legion_mcp.grpc_client import get_grpc_client_manager
from legion_mcp.agent_context import (
    get_agent_proxy,
    set_agent_context,
    require_agent_context,
)
from legion_mcp.protos import (
    auth_pb2,
    knowledge_pb2,
    code_pb2,
    expertise_pb2,
    lessons_learned_pb2,
    agent_skill_pb2,
    engagement_pb2,
    task_pb2,
)
from legion_mcp.tools.delegation import register_delegation_tools, cleanup_orphaned_delegations
from legion_mcp.tools.ingestion import register_ingestion_tools
from legion_mcp.tools.proxy import register_proxy_tools, DEFAULT_PROXY_PORT
from legion_mcp.tools.what_i_know import register_what_i_know_tools

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def _app_lifespan(server: FastMCP) -> AsyncIterator[dict]:
    """Server lifespan: startup/shutdown on the MCP event loop.

    Running startup tasks HERE (not in a separate asyncio.run()) keeps
    async tasks like the proxy heartbeat alive on the server's event loop.
    """
    logger.info("Lifespan: running startup tasks...")
    try:
        await _startup_cleanup()
        logger.info("Lifespan: startup tasks completed")
    except Exception as e:
        logger.warning(f"Lifespan: startup tasks failed: {e}")
    yield {}
    logger.info("Lifespan: shutting down")


# Initialize FastMCP server with lifespan for startup tasks
mcp = FastMCP("LEGION Knowledge & Code Intelligence", lifespan=_app_lifespan)

# Register delegation tools
register_delegation_tools(mcp)

# Register ingestion tools
register_ingestion_tools(mcp)

# Register proxy tools
register_proxy_tools(mcp)

# Register whatIKnow unified search tool
register_what_i_know_tools(mcp)


# ============================================================================
# Auth Tools
# ============================================================================


@mcp.tool()
async def authenticateUser() -> Dict[str, Any]:
    """
    Authenticate user and get available projects. Called automatically on first tool use.

    When to use: Only call explicitly to refresh token or verify auth status.
    Usually not needed - other tools auto-authenticate.

    Returns:
        dict: {token, user_email, projects_count, projects[{id, name, company_id}]}
    """
    try:
        manager = get_grpc_client_manager()
        result = await manager.authenticate()
        return result
    except Exception as e:
        logger.error(f"Authentication error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "AUTH_FAILED",
        }


@mcp.tool()
async def getProjects() -> Dict[str, Any]:
    """
    Get list of available projects for the authenticated user.

    When to use: To find valid project_id values for other tools.
    All query/create tools require a project_id - use this to discover them.

    Returns:
        dict: {projects_count, projects[{id, name, description, company_id}]}
    """
    try:
        manager = get_grpc_client_manager()

        # Ensure authenticated
        if not manager.token:
            await manager.authenticate()

        return {
            "status": "success",
            "projects_count": len(manager.user_projects),
            "projects": manager.user_projects,
        }
    except Exception as e:
        logger.error(f"Get projects error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "GET_PROJECTS_FAILED",
        }


# ============================================================================
# Knowledge Tools
# ============================================================================


@mcp.tool()
async def createKnowledge(
    text: str,
    project_id: str,
    metadata: Optional[Dict[str, str]] = None,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Store documentation, notes, or unstructured text for semantic search.

    NO LLM CALLS - Uses static markdown parsing like skills/expertise.
    Pipeline: parse → embed → store (10x faster than before).

    When to use:
    - Storing meeting notes, research findings, documentation
    - Adding context that doesn't fit code or expertise categories
    - Quick storage without hierarchical structure

    vs createCode: Use createCode for source code files
    vs createExpertise: Use createExpertise for structured guides/tutorials with sections

    Args:
        text: Text content to store and index
        project_id: Project UUID from getProjects (required)
        metadata: Optional tags {"category": "docs", "source": "confluence"}
        request_id: Optional idempotency key to prevent duplicates

    Returns:
        dict: {knowledge_id, chunks_count, entities_count}
    """
    try:
        manager = get_grpc_client_manager()

        request = knowledge_pb2.CreateKnowledgeRequest(
            text=text,
            project_id=project_id,
            user_token=manager.token or "",
            metadata=metadata or {},
            request_id=request_id or "",
        )

        response = await manager.call_with_auth_by_name(
            "knowledge_stub", "CreateKnowledge", request
        )

        return {
            "status": response.status,
            "message": response.message,
            "knowledge_id": response.knowledge_id,
            "project_id": response.project_id,
            "company_id": response.company_id,
            "title": response.title,
            "summary": response.summary,
            "chunks_count": response.chunks_count,
            "entities_count": response.entities_count,
            "relationships_count": response.relationships_count,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Create knowledge error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "CREATE_KNOWLEDGE_FAILED",
        }


@mcp.tool()
@require_agent_context("queryKnowledge")
async def queryKnowledge(
    query: str,
    project_id: str,
    limit: int = 10,
) -> Dict[str, Any]:
    """
    Search stored knowledge using hybrid retrieval (vector + graph + RRF fusion).

    NO LLM RERANKING - Fast vector + graph search only.
    Same speed as fastQuery now (both skip LLM).

    When to use:
    - Finding documentation, architecture info, design decisions
    - Answering "how does X work?" or "what is the approach for Y?"
    - Need highest relevance accuracy

    vs fastQuery: Now identical (both skip LLM, kept for API compatibility)
    vs findSimilarCode: Use findSimilarCode for code search
    vs queryLessons: Use queryLessons for past bugs/solutions

    Args:
        query: Natural language question (e.g., "how does authentication work?")
        project_id: Project UUID from getProjects
        limit: Max results (default: 10)

    Returns:
        dict: {results[{text, score, metadata}], results_count}
    """
    try:
        manager = get_grpc_client_manager()

        request = knowledge_pb2.QueryKnowledgeRequest(
            query=query,
            project_id=project_id,
            user_token=manager.token or "",
            limit=limit,
        )

        response = await manager.call_with_auth_by_name("knowledge_stub", "QueryKnowledge", request)

        return {
            "status": response.status,
            "query": response.query,
            "project_id": response.project_id,
            "results_count": response.results_count,
            "results": [
                {
                    "id": r.id,
                    "text": r.text,
                    "metadata": dict(r.metadata),
                    "score": r.score,
                    "vector_score": r.vector_score,
                    "rerank_score": r.rerank_score,
                }
                for r in response.results
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Query knowledge error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "QUERY_KNOWLEDGE_FAILED",
        }


@mcp.tool()
@require_agent_context("fastQuery")
async def fastQuery(
    query: str,
    project_id: str,
    limit: int = 10,
) -> Dict[str, Any]:
    """
    Fast vector-only search. Now identical to queryKnowledge.

    DEPRECATED: Both queryKnowledge and fastQuery now skip LLM reranking.
    Kept for API backward compatibility only.

    When to use:
    - Same as queryKnowledge (both are fast now)

    vs queryKnowledge: Now identical (use either)

    Args:
        query: Search text
        project_id: Project UUID from getProjects
        limit: Max results (default: 10)

    Returns:
        dict: {results[{text, score, metadata}], results_count}
    """
    try:
        manager = get_grpc_client_manager()

        request = knowledge_pb2.FastQueryRequest(
            query=query,
            project_id=project_id,
            user_token=manager.token or "",
            limit=limit,
        )

        response = await manager.call_with_auth_by_name("knowledge_stub", "FastQuery", request)

        return {
            "status": response.status,
            "query": response.query,
            "project_id": response.project_id,
            "results_count": response.results_count,
            "results": [
                {
                    "id": r.id,
                    "text": r.text,
                    "metadata": dict(r.metadata),
                    "score": r.score,
                    "vector_score": r.vector_score,
                    "rerank_score": r.rerank_score,
                }
                for r in response.results
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Fast query error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "FAST_QUERY_FAILED",
        }


@mcp.tool()
@require_agent_context("searchByTags")
async def searchByTags(
    project_id: str,
    keywords: Optional[List[str]] = None,
    chunk_type: Optional[str] = None,
    has_code: Optional[bool] = None,
    section_title: Optional[str] = None,
    section_level: Optional[int] = None,
    limit: int = 10,
    offset: int = 0,
) -> Dict[str, Any]:
    """
    Filter knowledge by metadata fields. Exact matching, not semantic search.

    When to use:
    - Finding all chunks with specific tags/keywords
    - Filtering by chunk_type (prose, code, heading)
    - Finding sections containing code examples (has_code=True)

    vs queryKnowledge: Use queryKnowledge for semantic/meaning-based search
    This tool is for structured filtering by metadata fields.

    Args:
        project_id: Project UUID from getProjects
        keywords: Filter by keywords list (e.g., ["authentication", "jwt"])
        chunk_type: Filter by type ("prose", "code", "heading")
        has_code: True = only chunks with code, False = only without
        section_title: Filter by section title match
        section_level: Filter by heading level (1=h1, 2=h2, etc.)
        limit: Max results (default: 10)
        offset: Starting position for pagination (default: 0)

    Returns:
        dict: {results[{text, metadata}], results_count}
    """
    try:
        manager = get_grpc_client_manager()

        request = knowledge_pb2.SearchByTagsRequest(
            project_id=project_id,
            user_token=manager.token or "",
            keywords=keywords or [],
            chunk_type=chunk_type or "",
            has_code=has_code if has_code is not None else False,
            section_title=section_title or "",
            section_level=section_level or 0,
            limit=limit,
            offset=offset,
        )

        response = await manager.call_with_auth_by_name("knowledge_stub", "SearchByTags", request)

        return {
            "status": response.status,
            "query": response.query,
            "project_id": response.project_id,
            "results_count": response.results_count,
            "results": [
                {
                    "id": r.id,
                    "text": r.text,
                    "metadata": dict(r.metadata),
                    "score": r.score,
                    "vector_score": r.vector_score,
                    "rerank_score": r.rerank_score,
                }
                for r in response.results
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Search by tags error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "SEARCH_BY_TAGS_FAILED",
        }


@mcp.tool()
@require_agent_context("exploreGraph")
async def exploreGraph(
    cypher: str,
    project_id: str,
    params: Optional[Dict[str, str]] = None,
    limit: int = 100,
) -> Dict[str, Any]:
    """
    Run custom Cypher queries on Neo4j knowledge graph. Advanced tool.

    Tenant scoping ($company_id) is **automatically injected** into every
    MATCH / OPTIONAL MATCH clause — you do NOT need to write it yourself.
    Queries that reference ``company_id`` will be **rejected** to prevent
    bypass attacks.

    When to use:
    - Exploring relationships between entities
    - Finding connection patterns (what calls what, dependencies)
    - Custom graph traversals not covered by other tools

    Common patterns:
    - "MATCH (n) RETURN labels(n), count(*)" - count nodes by type
    - "MATCH (a)-[r]->(b) RETURN type(r), count(*)" - count relationships
    - "MATCH (e:Entity {name: $name}) RETURN e" - find entity by name

    Args:
        cypher: Neo4j Cypher query — do NOT include company_id (it is auto-injected)
        project_id: Project UUID from getProjects
        params: Query parameters {"name": "MyClass"} — do NOT include company_id here
        limit: Max results (default: 100)

    Returns:
        dict: {results[{...}], results_count}
    """
    try:
        manager = get_grpc_client_manager()

        request = knowledge_pb2.ExploreGraphRequest(
            cypher=cypher,
            project_id=project_id,
            user_token=manager.token or "",
            params=params or {},
            limit=limit,
        )

        response = await manager.call_with_auth_by_name("knowledge_stub", "ExploreGraph", request)

        # ExploreGraphResponse uses GraphQueryResult with flexible fields map
        # This preserves ALL Cypher RETURN fields (name, description, etc.)
        return {
            "status": response.status,
            "query": response.query,
            "project_id": response.project_id,
            "results_count": response.results_count,
            "results": [dict(r.fields) for r in response.results],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Explore graph error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "EXPLORE_GRAPH_FAILED",
        }


# ============================================================================
# Code Tools
# ============================================================================


@mcp.tool()
async def createCode(
    code: str,
    filename: str,
    metadata: Optional[Dict[str, str]] = None,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Index source code for semantic search. Extracts classes, functions, builds call graph.

    When to use:
    - Indexing new source files for code search
    - Making code searchable via findSimilarCode
    - Building code intelligence (impact analysis, execution tracing)

    Prerequisite for: findSimilarCode, analyzeImpact, traceExecutionFlow
    Supported languages: Python, TypeScript, JavaScript, Ruby, Go, Rust, Java

    Args:
        code: Full source code content
        filename: File path with extension (e.g., "src/auth/handler.py")
                  Extension determines language detection
        metadata: Optional tags {"module": "auth", "team": "backend"}
        request_id: Optional idempotency key

    Returns:
        dict: {code_id, language, entities_count, relationships_count}
    """
    try:
        manager = get_grpc_client_manager()

        request = code_pb2.CreateCodeRequest(
            code=code,
            filename=filename,
            user_token=manager.token or "",
            metadata=metadata or {},
            request_id=request_id or "",
        )

        response = await manager.call_with_auth_by_name("code_stub", "CreateCode", request)

        return {
            "status": response.status,
            "message": response.message,
            "code_id": response.code_id,
            "filename": response.filename,
            "language": response.language,
            "title": response.title,
            "summary": response.summary,
            "chunks_count": response.chunks_count,
            "entities_count": response.entities_count,
            "relationships_count": response.relationships_count,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Create code error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "CREATE_CODE_FAILED",
        }


@mcp.tool()
@require_agent_context("findSimilarCode")
async def findSimilarCode(
    query: str,
    language: Optional[str] = None,
    project_id: Optional[str] = None,
    limit: int = 10,
) -> Dict[str, Any]:
    """
    Search indexed code by natural language or code snippet.

    When to use:
    - "Find authentication implementation" - natural language
    - "Show me payment processing code" - feature search
    - Paste code snippet to find similar patterns

    Prerequisite: Code must be indexed first via createCode.
    Returns empty if no code indexed for project.

    vs queryKnowledge: Use queryKnowledge for docs/text, this for code

    Args:
        query: Natural language ("auth middleware") or code snippet
        language: Filter by language (python, typescript, ruby, javascript)
                  Empty = search all languages
        project_id: Project UUID from getProjects (required for results)
        limit: Max results (default: 10)

    Returns:
        dict: {results[{entity_name, file_path, code_snippet, score}], total}
    """
    try:
        manager = get_grpc_client_manager()

        request = code_pb2.FindSimilarCodeRequest(
            query=query,
            language=language or "",
            project_id=project_id or "",
            limit=limit,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name("code_stub", "FindSimilarCode", request)

        return {
            "status": response.status,
            "total": response.total,
            "results": [
                {
                    "entity_id": r.entity_id,
                    "score": r.score,
                    "entity_name": r.entity_name,
                    "entity_type": r.entity_type,
                    "filename": r.filename,
                    "file_path": r.file_path,
                    "language": r.language,
                    "line_start": r.line_start,
                    "line_end": r.line_end,
                    "code_snippet": r.code_snippet,
                    "summary": r.summary,
                    "dependencies": list(r.dependencies),
                    "complexity": r.complexity,
                    "is_entry_point": r.is_entry_point,
                }
                for r in response.results
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Find similar code error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "FIND_SIMILAR_CODE_FAILED",
        }


@mcp.tool()
@require_agent_context("analyzeImpact")
async def analyzeImpact(
    entity_name: str,
    entity_type: str,
    project_id: str,
    max_depth: int = 3,
) -> Dict[str, Any]:
    """
    Analyze blast radius of changing a function/class. Shows what depends on it.

    When to use:
    - Before refactoring: "What breaks if I change this function?"
    - Risk assessment: "How critical is this code?"
    - Understanding dependencies: "Who calls this? What does it call?"

    Prerequisite: Code must be indexed via createCode first.

    Args:
        entity_name: Function/class name (e.g., "process_payment", "AuthService")
        entity_type: "function", "class", or "method"
        project_id: Project UUID from getProjects
        max_depth: How many levels to traverse (default: 3)

    Returns:
        dict: {upstream[callers], downstream[callees], risk_level, counts}
        risk_level: "low" (<3 callers), "medium" (3-10), "high" (>10)
    """
    try:
        manager = get_grpc_client_manager()

        request = code_pb2.AnalyzeImpactRequest(
            entity_name=entity_name,
            entity_type=entity_type,
            project_id=project_id,
            max_depth=max_depth,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name("code_stub", "AnalyzeImpact", request)

        def convert_entity_info(entity):
            return {
                "name": entity.name,
                "type": entity.type,
                "file_path": entity.file_path,
                "filename": entity.filename,
                "line_start": entity.line_start,
                "line_end": entity.line_end,
                "code_snippet": entity.code_snippet,
            }

        return {
            "status": response.status,
            "entity": convert_entity_info(response.entity) if response.entity else None,
            "upstream": [
                {"path": [convert_entity_info(e) for e in path.path]} for path in response.upstream
            ],
            "downstream": [
                {"path": [convert_entity_info(e) for e in path.path]}
                for path in response.downstream
            ],
            "risk_level": response.risk_level,
            "upstream_count": response.upstream_count,
            "downstream_count": response.downstream_count,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Analyze impact error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "ANALYZE_IMPACT_FAILED",
        }


@mcp.tool()
@require_agent_context("traceExecutionFlow")
async def traceExecutionFlow(
    entry_point: str,
    project_id: str,
    max_depth: int = 5,
) -> Dict[str, Any]:
    """
    Trace what functions get called starting from an entry point (DFS traversal).

    When to use:
    - Understanding request flow: "What happens when this API is called?"
    - Debugging: "What's the call chain from this function?"
    - Code review: "Show me the execution path"

    Prerequisite: Code must be indexed via createCode first.

    Args:
        entry_point: Starting function name (e.g., "handle_request", "main")
        project_id: Project UUID from getProjects
        max_depth: Max call depth to trace (default: 5)

    Returns:
        dict: {paths[{depth, path[{name, file_path, line_start}]}], total_paths}
    """
    try:
        manager = get_grpc_client_manager()

        request = code_pb2.TraceExecutionFlowRequest(
            entry_point=entry_point,
            project_id=project_id,
            max_depth=max_depth,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name("code_stub", "TraceExecutionFlow", request)

        def convert_entity_info(entity):
            return {
                "name": entity.name,
                "type": entity.type,
                "file_path": entity.file_path,
                "filename": entity.filename,
                "line_start": entity.line_start,
                "line_end": entity.line_end,
                "code_snippet": entity.code_snippet,
            }

        return {
            "status": response.status,
            "total_paths": response.total_paths,
            "paths": [
                {
                    "depth": path.depth,
                    "path": [convert_entity_info(e) for e in path.path],
                }
                for path in response.paths
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Trace execution flow error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "TRACE_EXECUTION_FLOW_FAILED",
        }


# ============================================================================
# Expertise Tools
# ============================================================================


@mcp.tool()
async def createExpertise(
    text: str,
    when_to_use: Optional[str] = None,
    project_id: Optional[str] = None,
    company_id: Optional[str] = None,
    metadata: Optional[Dict[str, str]] = None,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Store structured knowledge with hierarchical sections (guides, tutorials, best practices). Requires engagement_id.

    Two modes:
    1. Project-scoped: provide project_id → expertise belongs to specific project
    2. Company-level: provide company_id only → expertise accessible to ALL projects in company

    Use company-level for shared knowledge (coding standards, best practices, domain expertise)
    that all agents/projects should have access to.

    When to use:
    - Storing how-to guides, tutorials, runbooks
    - Best practices documentation with sections
    - Structured knowledge that has parent-child relationships
    - Company-wide standards (use company_id only)

    vs createKnowledge: Use createKnowledge for flat/unstructured text
    This preserves section hierarchy (h1 > h2 > h3) for better retrieval.

    Args:
        text: Markdown text with headings (# Section, ## Subsection)
        when_to_use: When this expertise should be consulted
        project_id: Optional project UUID - creates project-scoped expertise
        company_id: Optional company UUID - creates company-level expertise (accessible to all projects)
        metadata: Optional tags {"type": "runbook", "domain": "devops"}
        request_id: Optional idempotency key

    Returns:
        dict: {expertise_id, title, chunks_count, when_to_use, is_company_level}
    """
    try:
        manager = get_grpc_client_manager()

        request = expertise_pb2.CreateExpertiseRequest(
            text=text,
            user_token=manager.token or "",
            project_id=project_id or "",
            company_id=company_id or "",
            metadata=metadata or {},
            request_id=request_id or "",
            when_to_use=when_to_use or "",
        )

        response = await manager.call_with_auth_by_name(
            "expertise_stub", "CreateExpertise", request
        )

        return {
            "status": response.status,
            "message": response.message,
            "expertise_id": response.expertise_id,
            "project_id": response.project_id,
            "company_id": response.company_id,
            "title": response.title,
            "summary": response.summary,
            "chunks_count": response.chunks_count,
            "entities_count": response.entities_count,
            "relationships_count": response.relationships_count,
            "when_to_use": response.when_to_use,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Create expertise error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "CREATE_EXPERTISE_FAILED",
        }


@mcp.tool()
async def addExpertiseChunk(
    expertise_id: str,
    content: str,
    project_id: str,
    parent_chunk_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Add a section/subsection to existing expertise document.

    When to use:
    - Incrementally building expertise documents
    - Adding new sections to existing guides
    - Creating nested content (subsections under sections)

    Args:
        expertise_id: ID from createExpertise response
        content: Section content (can include markdown)
        project_id: Project UUID from getProjects
        parent_chunk_id: Optional parent chunk for nesting (creates subsection)

    Returns:
        dict: {chunk_id, level, position}
    """
    try:
        manager = get_grpc_client_manager()

        request = expertise_pb2.AddExpertiseChunkRequest(
            expertise_id=expertise_id,
            content=content,
            user_token=manager.token or "",
            parent_chunk_id=parent_chunk_id or "",
            project_id=project_id,
        )

        response = await manager.call_with_auth_by_name(
            "expertise_stub", "AddExpertiseChunk", request
        )

        return {
            "status": response.status,
            "message": response.message,
            "chunk_id": response.chunk_id,
            "expertise_id": response.expertise_id,
            "parent_chunk_id": response.parent_chunk_id,
            "level": response.level,
            "position": response.position,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Add expertise chunk error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "ADD_EXPERTISE_CHUNK_FAILED",
        }


@mcp.tool()
@require_agent_context("queryExpertise")
async def queryExpertise(
    query: str,
    project_id: Optional[str] = None,
    company_id: Optional[str] = None,
    limit: int = 10,
) -> Dict[str, Any]:
    """
    Search expertise documents (guides, tutorials, best practices).

    Two modes:
    1. project_id provided: searches project expertise + company-level expertise
    2. company_id only: searches company-level expertise only

    When to use:
    - Finding how-to guides and tutorials
    - Looking up best practices
    - Searching structured documentation
    - Accessing company-wide standards (use company_id)

    vs queryKnowledge: Use queryKnowledge for general text/docs
    This searches only expertise documents (created via createExpertise).

    Args:
        query: Natural language question (e.g., "how to deploy to production")
        project_id: Optional project UUID - searches project + company expertise
        company_id: Optional company UUID - searches company-level expertise only
        limit: Max results (default: 10)

    Returns:
        dict: {results[{text, metadata, score}], results_count}
    """
    try:
        manager = get_grpc_client_manager()

        request = expertise_pb2.QueryExpertiseRequest(
            query=query,
            user_token=manager.token or "",
            project_id=project_id or "",
            company_id=company_id or "",
            limit=limit,
        )

        response = await manager.call_with_auth_by_name("expertise_stub", "QueryExpertise", request)

        return {
            "status": response.status,
            "query": response.query,
            "project_id": response.project_id,
            "results_count": response.results_count,
            "results": [
                {
                    "id": r.id,
                    "text": r.text,
                    "metadata": dict(r.metadata),
                    "score": r.score,
                    "vector_score": r.vector_score,
                    "rerank_score": r.rerank_score,
                }
                for r in response.results
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Query expertise error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "QUERY_EXPERTISE_FAILED",
        }


@mcp.tool()
async def listExpertise(
    project_id: Optional[str] = None,
    company_id: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
) -> Dict[str, Any]:
    """
    List expertise documents (without searching).

    Two modes:
    1. project_id provided: lists project expertise + company-level expertise
    2. company_id only: lists company-level expertise only

    When to use:
    - Browsing available guides/tutorials
    - Getting overview of stored expertise
    - Finding expertise_id for getExpertise
    - Viewing company-wide standards (use company_id)

    Args:
        project_id: Optional project UUID - lists project + company expertise
        company_id: Optional company UUID - lists company-level expertise only
        limit: Max results (default: 100)
        offset: Skip first N results for pagination

    Returns:
        dict: {expertise_list[{expertise_id, title, chunks_count, is_company_level}], total_count}
    """
    try:
        manager = get_grpc_client_manager()

        request = expertise_pb2.ListExpertiseRequest(
            user_token=manager.token or "",
            project_id=project_id or "",
            company_id=company_id or "",
            limit=limit,
            offset=offset,
        )

        response = await manager.call_with_auth_by_name("expertise_stub", "ListExpertise", request)

        return {
            "status": response.status,
            "project_id": response.project_id,
            "total_count": response.total_count,
            "expertise_list": [
                {
                    "expertise_id": e.expertise_id,
                    "title": e.title,
                    "summary": e.summary,
                    "chunks_count": e.chunks_count,
                    "created_at": e.created_at,
                    "updated_at": e.updated_at,
                    "when_to_use": e.when_to_use,
                }
                for e in response.expertise_list
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"List expertise error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "LIST_EXPERTISE_FAILED",
        }


@mcp.tool()
async def getExpertise(
    expertise_id: str,
) -> Dict[str, Any]:
    """
    Get full content of a specific expertise document by ID.

    When to use:
    - Reading complete guide/tutorial content
    - After finding expertise_id via listExpertise or queryExpertise

    Args:
        expertise_id: Expertise UUID from listExpertise or queryExpertise

    Returns:
        dict: {title, summary, content, chunks_count, created_at}
    """
    try:
        manager = get_grpc_client_manager()

        request = expertise_pb2.GetExpertiseRequest(
            user_token=manager.token or "",
            expertise_id=expertise_id,
        )

        response = await manager.call_with_auth_by_name("expertise_stub", "GetExpertise", request)

        return {
            "status": response.status,
            "expertise_id": response.expertise_id,
            "title": response.title,
            "summary": response.summary,
            "content": response.content,
            "chunks_count": response.chunks_count,
            "project_id": response.project_id,
            "company_id": response.company_id,
            "created_at": response.created_at,
            "updated_at": response.updated_at,
            "when_to_use": response.when_to_use,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Get expertise error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "GET_EXPERTISE_FAILED",
        }


@mcp.tool()
async def updateExpertise(
    expertise_id: str,
    when_to_use: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Update an existing expertise. Only provided fields are changed.

    Uses partial update semantics: omitted fields keep their current values.
    Currently supports updating when_to_use field only.

    WHEN TO USE:
    - Updating when_to_use description for an expertise document
    - Modifying when this expertise should be consulted

    Args:
        expertise_id: Expertise UUID (required)
        when_to_use: Optional new when_to_use description

    Returns:
        dict: {
            status: "success" or "error",
            expertise_id: str - UUID of updated expertise,
            title: str - Expertise title,
            when_to_use: str - Updated when_to_use value,
            error_message, error_code
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = expertise_pb2.UpdateExpertiseRequest(
            user_token=manager.token or "",
            expertise_id=expertise_id,
            when_to_use=when_to_use or "",
            when_to_use_provided=when_to_use is not None,
        )

        response = await manager.call_with_auth_by_name(
            "expertise_stub", "UpdateExpertise", request
        )

        return {
            "status": response.status,
            "expertise_id": response.expertise_id,
            "title": response.title,
            "when_to_use": response.when_to_use,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Update expertise error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "UPDATE_EXPERTISE_FAILED",
        }


# ============================================================================
# Lessons Learned Tools
# ============================================================================


@mcp.tool()
async def recordLesson(
    project_id: str,
    category: str,
    title: str,
    symptom: str,
    root_cause: str,
    solution: str,
    prevention: str,
    severity: str = "medium",
    tags: Optional[List[str]] = None,
    files_changed: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Record a resolved issue as a lesson learned for future reference.

    When to use: After fixing a bug or resolving an issue, document it here
    so future similar issues can be quickly resolved via queryLessons.

    Args:
        project_id: Project UUID from getProjects
        category: Category path (e.g., "Infrastructure/Docker", "API/Authentication")
        title: Short descriptive title
        symptom: What error/behavior was observed
        root_cause: Why it happened (the actual cause)
        solution: Step-by-step fix that worked
        prevention: How to avoid this in the future
        severity: "low", "medium", "high", "critical" (default: "medium")
        tags: Keywords for search (e.g., ["docker", "timeout", "connection"])
        files_changed: Files modified to fix (e.g., ["docker-compose.yml"])

    Returns:
        dict: {lesson_id, category, title}
    """
    try:
        manager = get_grpc_client_manager()

        # Ensure connection is established before accessing stubs
        await manager.ensure_connected()

        request = lessons_learned_pb2.RecordLessonRequest(
            user_token=manager.token or "",
            project_id=project_id,
            category=category,
            title=title,
            symptom=symptom,
            root_cause=root_cause,
            solution=solution,
            prevention=prevention,
            severity=severity,
            tags=tags or [],
            files_changed=files_changed or [],
        )

        response = await manager.call_with_auth_by_name("lessons_stub", "RecordLesson", request)

        return {
            "status": response.status,
            "lesson_id": response.lesson_id,
            "project_id": response.project_id,
            "category": response.category,
            "title": response.title,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Record lesson error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "RECORD_LESSON_FAILED",
        }


@mcp.tool()
@require_agent_context("queryLessons")
async def queryLessons(
    query: str,
    project_id: str,
    category_filter: str = "",
    limit: int = 10,
) -> Dict[str, Any]:
    """
    Search past resolved issues to find solutions for current problems.

    When to use:
    - Encountering an error: "I'm seeing X error, has this been solved before?"
    - Before debugging: Check if similar issue was already resolved
    - Finding past solutions for recurring problems

    vs queryKnowledge: Use queryKnowledge for docs, this for past bug fixes

    Args:
        query: Describe the problem (e.g., "connection timeout to database")
        project_id: Project UUID from getProjects
        category_filter: Optional filter (e.g., "Infrastructure/Docker")
        limit: Max results (default: 10)

    Returns:
        dict: {lessons[{symptom, root_cause, solution, prevention}], results_count}
    """
    try:
        manager = get_grpc_client_manager()

        # Ensure connection is established before accessing stubs
        await manager.ensure_connected()

        request = lessons_learned_pb2.QueryLessonsRequest(
            user_token=manager.token or "",
            project_id=project_id,
            query=query,
            category_filter=category_filter,
            limit=limit,
        )

        response = await manager.call_with_auth_by_name("lessons_stub", "QueryLessons", request)

        return {
            "status": response.status,
            "results_count": response.results_count,
            "lessons": [
                {
                    "lesson_id": lesson.lesson_id,
                    "category": lesson.category,
                    "title": lesson.title,
                    "symptom": lesson.symptom,
                    "root_cause": lesson.root_cause,
                    "solution": lesson.solution,
                    "prevention": lesson.prevention,
                    "severity": lesson.severity,
                    "tags": list(lesson.tags),
                    "files_changed": list(lesson.files_changed),
                    "created_at": lesson.created_at,
                    "score": lesson.score,
                }
                for lesson in response.lessons
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Query lessons error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "QUERY_LESSONS_FAILED",
        }


# ============================================================================
# Agent Identity & Skill Tools
# ============================================================================


@mcp.tool()
async def whoAmI(
    company_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    project_id: Optional[str] = None,
    project_location: Optional[str] = None,
) -> Dict[str, Any]:
    """
    IDENTITY BOOTSTRAP - The FIRST tool you MUST call when starting a session with LEGION.

    This tool establishes your agent identity and sets the MCP context.
    All subsequent tool calls will include your identity reminder.

    TWO MODES:
    1. whoAmI() - Become Arthur (default orchestrator)
    2. whoAmI(agent_id="xyz") - Become a specific specialist agent

    You will receive:
    - WHO you are (name, personality, behavioral traits)
    - WHAT you can do (capabilities, responsibilities)
    - HOW you should behave (combined_system_prompt with hierarchical instructions)
    - WHAT you know (skills_overview - your available expertise)
    - WHO you can delegate to (available_agents - specialist agents)

    HIERARCHICAL PROMPT COMPOSITION:
    The system_prompt returned is a combined hierarchical prompt built from:
    - Company instructions: Ground rules, coding standards (ALWAYS included based on agent's company)
    - Project instructions: Tech stack, conventions (only when project_id provided)
    - Agent system_prompt: Role-specific behavioral instructions

    Additionally, raw instruction objects are returned for inspection:
    - project_instructions: dict - Only when project_id is provided

    CONTEXT SETTING:
    - Use getProjects() to discover available projects (and their company_id)
    - Then call whoAmI with company_id, project_id, and project_location to set your working context
    - The context (company_id, project_id, project_location) will be stored in MCP memory
    - All subsequent tool responses will include your context reminder

    PARAMETER RESOLUTION (priority order):
    1. Direct parameter (highest priority)
    2. Environment variable (LEGION_COMPANY_ID, LEGION_PROJECT_ID, LEGION_PROJECT_PATH)
    3. Cached context from previous whoAmI call (session persistence)

    WHEN TO CALL:
    - ALWAYS at the start of any session using LEGION MCP
    - When user says "use LEGION" or "please use Legion MCP"
    - Before any other LEGION operations
    - When delegated a task: sub-agent MUST call whoAmI(agent_id="their-id", project_id="...")

    AFTER CALLING THIS:
    1. MCP context is set - all subsequent tool responses include your identity
    2. Read and internalize your combined_system_prompt (contains hierarchical instructions)
    3. Note your skills_overview - call getAgentSkills(agent_id) for full skill trees
    4. Embody your personality in all subsequent interactions

    Args:
        company_id: Optional company UUID for multi-tenant setups.
                    If not provided, resolved from env var or cached context.
                    If still not resolved, derived from project_id.
        agent_id: Optional agent UUID to become a specific agent.
                  If not provided, becomes Arthur (orchestrator).
        project_id: Optional project UUID for project-specific instructions.
                    When provided, project_instructions are included in response
                    and system_prompt includes project conventions.
        project_location: Optional absolute path to the local project directory.
                          Stored in MCP context for file operations.

    Returns:
        dict: {
            status: "success" or "error",

            # Identity (always present on success)
            agent_id: str - Your unique identifier,
            name: str - Your name,
            role: str - Your role,
            personality: str - Your character traits and behavioral style,
            main_responsibilities: str - What you're responsible for,
            combined_system_prompt: str - Combined hierarchical prompt (company + project + agent),
            capabilities: list[str] - What actions you can perform,

            # Skills (always present on success)
            skills_count: int - Number of expertise documents you have,
            skills_overview: [{expertise_id, title, summary, sections_count}],

            # Delegation (always present on success)
            available_agents_count: int - Number of agents you can delegate to,
            available_agents: [{agent_id, name, role, specialization}],

            # Memories (always present on success)
            permanent_memories_count: int - Number of permanent memories,
            permanent_memories: [{id, agent_id, user_id, content, category, created_at}],

            # Hierarchical instructions (conditionally present)
            project_instructions: dict - Only when project_id provided. Contains:
                {id, project_id, description, languages, frameworks, tools,
                 architecture_notes, conventions, custom_instructions},

            # Context (present when any context values resolved)
            context: {company_id, project_id, project_location} - Current working context,

            # Error fields (always present)
            error_message: str - Empty on success, error details on failure,
            error_code: str - Empty on success, error code on failure
        }

    Error Response (on access denied or failure):
        dict: {
            status: "error",
            error_message: str - Description of the error,
            error_code: str - ACCESS_DENIED, WHO_AM_I_FAILED, etc.,
            available_companies: list[str] - (on company access denied),
            available_projects: list[dict] - (on project access denied)
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        # Ensure authentication before access checks
        # This populates manager.user_projects needed for company/project verification
        if not manager.token:
            await manager.authenticate()

        # Get current context for fallback values
        proxy = get_agent_proxy()
        context = proxy.context

        # =====================================================================
        # RESOLVE company_id, project_id, project_location with priority order:
        # 1. Direct parameter (highest priority)
        # 2. Environment variable (from MCP config)
        # 3. AgentContext cache (session persistence)
        # =====================================================================

        # Read environment variables (set via MCP config in .mcp.json)
        env_company_id = os.environ.get("LEGION_COMPANY_ID")
        env_project_id = os.environ.get("LEGION_PROJECT_ID")
        env_project_path = os.environ.get("LEGION_PROJECT_PATH")

        # Resolve with priority: param > env var > context
        resolved_company_id = (
            company_id or env_company_id or (context.company_id if context else None)
        )
        resolved_project_id = (
            project_id or env_project_id or (context.project_id if context else None)
        )
        resolved_project_location = (
            project_location or env_project_path or (context.project_location if context else None)
        )

        # =====================================================================
        # VERIFY user access to company_id and project_id
        # =====================================================================

        # Build lookup sets for fast verification
        user_company_ids = set()
        user_project_ids = set()
        project_to_company = {}  # project_id -> company_id mapping

        for project in manager.user_projects:
            user_company_ids.add(project.get("company_id", ""))
            user_project_ids.add(project.get("id", ""))
            project_to_company[project.get("id", "")] = project.get("company_id", "")

        # Verify company access if company_id resolved
        if resolved_company_id and resolved_company_id not in user_company_ids:
            logger.warning(f"Access denied: company {resolved_company_id} not accessible to user")
            return {
                "status": "error",
                "error_message": f"Access denied: company {resolved_company_id} is not accessible to current user",
                "error_code": "ACCESS_DENIED",
                "available_companies": list(user_company_ids),
            }

        # Verify project access if project_id resolved
        if resolved_project_id and resolved_project_id not in user_project_ids:
            logger.warning(f"Access denied: project {resolved_project_id} not accessible to user")
            return {
                "status": "error",
                "error_message": f"Access denied: project {resolved_project_id} is not accessible to current user",
                "error_code": "ACCESS_DENIED",
                "available_projects": [
                    {"id": p["id"], "name": p["name"]} for p in manager.user_projects
                ],
            }

        # If project_id provided but no company_id, derive company from project
        if resolved_project_id and not resolved_company_id:
            resolved_company_id = project_to_company.get(resolved_project_id)
            logger.info(
                f"Derived company_id {resolved_company_id} from project_id {resolved_project_id}"
            )

        # =====================================================================
        # Call WhoAmI RPC with resolved values
        # =====================================================================

        # 1. Call WhoAmI for agent identity, skills, and available agents
        request = agent_skill_pb2.WhoAmIRequest(
            user_token=manager.token or "",
            company_id=resolved_company_id or "",
            agent_id=agent_id or "",
        )

        response = await manager.call_with_auth_by_name("agent_skill_stub", "WhoAmI", request)

        # Set MCP agent context on success
        if response.status == "success":
            # Extract key behavior from system_prompt (first sentence or line)
            system_prompt = response.system_prompt or ""
            reminder = (
                system_prompt.split("\n")[0][:200]
                if system_prompt
                else f"{response.role}: {response.main_responsibilities[:100]}"
            )

            set_agent_context(
                agent_id=response.agent_id,
                name=response.name,
                role=response.role,
                reminder=reminder,
                company_id=resolved_company_id,
                project_id=resolved_project_id,
                project_location=resolved_project_location,
            )
            logger.info(
                f"Agent context set: {response.name} ({response.role}), company={resolved_company_id}, project={resolved_project_id}"
            )

        # 2. ALWAYS fetch hierarchical prompt via GetAgentContext
        #    - Company instructions are ALWAYS included (based on agent's company)
        #    - Project instructions are included only if project_id is provided
        hierarchical_prompt = response.system_prompt  # default to raw agent prompt
        project_instructions = None

        if response.status == "success":
            try:
                context_request = agent_skill_pb2.GetAgentContextRequest(
                    agent_id=response.agent_id,
                    project_id=resolved_project_id or "",  # Empty string if no project
                    user_token=manager.token or "",
                )
                context_response = await manager.call_with_auth_by_name(
                    "agent_skill_stub", "GetAgentContext", context_request
                )

                if context_response.status == "success":
                    hierarchical_prompt = context_response.combined_system_prompt

                    # Extract project instructions if present
                    if context_response.HasField("project_instructions"):
                        pi = context_response.project_instructions
                        project_instructions = {
                            "id": pi.id,
                            "project_id": pi.project_id,
                            "description": pi.description or None,
                            "languages": list(pi.languages) if pi.languages else None,
                            "frameworks": list(pi.frameworks) if pi.frameworks else None,
                            "tools": list(pi.tools) if pi.tools else None,
                            "architecture_notes": pi.architecture_notes or None,
                            "conventions": pi.conventions or None,
                            "custom_instructions": pi.custom_instructions or None,
                        }

                    logger.info(
                        f"Hierarchical prompt loaded (project_id={resolved_project_id or 'None'})"
                    )
                else:
                    logger.warning(f"GetAgentContext failed: {context_response.error_message}")

            except Exception as ctx_error:
                logger.warning(f"Failed to fetch agent context: {ctx_error}")
                # Continue with raw system_prompt as fallback

        # 3. Build the TRULY combined system prompt
        #    Merges ALL agent identity fields + hierarchical instructions into
        #    one document. No separate personality/responsibilities fields —
        #    everything the agent needs is in this single prompt.
        identity_block = (
            f"# Agent Identity\n"
            f"- **Name:** {response.name}\n"
            f"- **Role:** {response.role}\n"
            f"- **Agent ID:** {response.agent_id}\n"
        )
        if response.personality:
            identity_block += f"- **Personality:** {response.personality}\n"
        if response.main_responsibilities:
            identity_block += f"- **Core Responsibilities:** {response.main_responsibilities}\n"
        if response.capabilities:
            identity_block += f"- **Capabilities:** {', '.join(response.capabilities)}\n"

        combined_system_prompt = f"{identity_block}\n{hierarchical_prompt}"

        result = {
            "status": response.status,
            "agent_id": response.agent_id,
            "name": response.name,
            "role": response.role,
            # The ONE prompt — identity + company + project + agent instructions
            "combined_system_prompt": combined_system_prompt,
            # Skills overview
            "skills_count": response.skills_count,
            "skills_overview": [
                {
                    "expertise_id": skill.expertise_id,
                    "title": skill.title,
                    "summary": skill.summary,
                    "sections_count": skill.sections_count,
                }
                for skill in response.skills_overview
            ],
            # Available agents
            "available_agents_count": response.available_agents_count,
            "available_agents": [
                {
                    "agent_id": agent.agent_id,
                    "name": agent.name,
                    "role": agent.role,
                    "specialization": agent.specialization,
                }
                for agent in response.available_agents
            ],
            # Permanent memories (returned on every bootstrap)
            "permanent_memories_count": len(response.permanent_memories),
            "permanent_memories": [
                {
                    "id": pm.id,
                    "agent_id": pm.agent_id,
                    "user_id": pm.user_id,
                    "content": pm.content,
                    "category": pm.category,
                    "created_at": pm.created_at,
                }
                for pm in response.permanent_memories
            ],
            # Workflows available to this agent
            "workflows": [
                {
                    "id": wf.id,
                    "name": wf.name,
                    "signals": list(wf.signals),
                }
                for wf in response.workflows
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }

        # Add hierarchical context if available
        if project_instructions:
            result["project_instructions"] = project_instructions

        # Add working context (resolved values, showing what was actually used)
        working_context = {}
        if resolved_company_id:
            working_context["company_id"] = resolved_company_id
        if resolved_project_id:
            working_context["project_id"] = resolved_project_id
        if resolved_project_location:
            working_context["project_location"] = resolved_project_location
        if working_context:
            result["context"] = working_context

        # Proxy beacon — embedded in tool_result, flows through conversation
        # history. The proxy scans for this to identify agents without external
        # state (no SQLite, no gRPC from addon). Format:
        #   XLEGIONX::{agent_id}::{sha256(combined_system_prompt)[:16]}
        if response.status == "success" and combined_system_prompt:
            prompt_hash = hashlib.sha256(combined_system_prompt.encode()).hexdigest()[:16]
            result["proxy_beacon"] = f"XLEGIONX::{response.agent_id}::{prompt_hash}"

        return result

    except Exception as e:
        logger.error(f"WhoAmI error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "WHO_AM_I_FAILED",
        }


@mcp.tool()
async def activateWorkflow(
    workflow_id: str,
) -> Dict[str, Any]:
    """
    Fetch full workflow content by ID for activation.

    When to use:
    - After seeing workflow in whoAmI response and wanting to use it
    - When manually activating a workflow by its ID
    - Arthur uses this to get workflow instructions before orchestrating

    Args:
        workflow_id: UUID of the workflow (from whoAmI workflows list)

    Returns:
        dict: {
            status: "success" or "error",
            workflow: {id, name, content, description, signals, ...},
            error_message, error_code
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.GetWorkflowByIdRequest(
            workflow_id=workflow_id,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "GetWorkflowById", request
        )

        if response.status == "error":
            return {
                "status": "error",
                "error_message": response.error_message,
                "error_code": response.error_code,
            }

        wf = response.workflow
        return {
            "status": "success",
            "workflow": {
                "id": wf.id,
                "company_id": wf.company_id,
                "project_id": wf.project_id or None,
                "agent_id": wf.agent_id or None,
                "role": wf.role or None,
                "user_id": wf.user_id or None,
                "public": wf.public,
                "name": wf.name,
                "content": wf.content,
                "description": wf.description or None,
                "signals": list(wf.signals),
                "version": wf.version,
                "created_at": wf.created_at,
                "updated_at": wf.updated_at,
            },
            "error_message": "",
            "error_code": "",
        }

    except Exception as e:
        logger.exception(f"activateWorkflow failed: {e}")
        return {
            "status": "error",
            "error_message": str(e),
            "error_code": "INTERNAL_ERROR",
        }


# ============================================================================
# Workflow CRUD Tools
# ============================================================================


def _workflow_from_pb(wf) -> Dict[str, Any]:
    """Convert a WorkflowContent protobuf message to a dict."""
    return {
        "id": wf.id,
        "company_id": wf.company_id,
        "project_id": wf.project_id or None,
        "agent_id": wf.agent_id or None,
        "role": wf.role or None,
        "user_id": wf.user_id or None,
        "public": wf.public,
        "name": wf.name,
        "content": wf.content,
        "description": wf.description or None,
        "signals": list(wf.signals),
        "version": wf.version,
        "created_at": wf.created_at,
        "updated_at": wf.updated_at,
        "when_to_use": wf.when_to_use or None,
    }


@mcp.tool()
async def createWorkflow(
    name: str,
    content: str,
    signals: List[str],
    company_id: str,
    description: Optional[str] = None,
    role: Optional[str] = None,
    agent_id: Optional[str] = None,
    project_id: Optional[str] = None,
    public: Optional[bool] = None,
    metadata: Optional[Dict[str, Any]] = None,
    when_to_use: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Create a new agent workflow.

    Workflows define behavioral instructions that agents follow when specific
    signals (trigger phrases) are detected. They are scoped by company, project,
    agent, and/or role.

    WHEN TO USE:
    - Defining new behavioral workflows for agents
    - Creating orchestration patterns
    - Setting up automated agent responses to specific situations

    Args:
        name: Unique workflow name within its scope
        content: Markdown workflow body with instructions
        signals: Non-empty list of trigger phrases that activate this workflow
        company_id: Company UUID (defaults to first company from token)
        description: Optional human-readable description
        role: Optional role scope (e.g., "developer", "researcher")
        agent_id: Optional agent UUID to scope to a specific agent
        project_id: Optional project UUID to scope to a project
        public: Optional visibility flag (True = visible to others in company)
        metadata: Optional dict of additional metadata
        when_to_use: Optional description of when this workflow should be activated

    Returns:
        dict: {status, workflow: {id, name, content, signals, when_to_use, ...}, error_message, error_code}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.CreateWorkflowRequest(
            user_token=manager.token or "",
            company_id=company_id or "",
            name=name,
            content=content,
            signals=signals,
            description=description or "",
            role=role or "",
            agent_id=agent_id or "",
            project_id=project_id or "",
            public=public if public is not None else False,
            metadata_json=json.dumps(metadata) if metadata else "",
            when_to_use=when_to_use or "",
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "CreateWorkflow", request
        )

        if response.status == "error":
            return {
                "status": "error",
                "error_message": response.error_message,
                "error_code": response.error_code,
            }

        return {
            "status": "success",
            "workflow": _workflow_from_pb(response.workflow),
            "error_message": "",
            "error_code": "",
        }

    except Exception as e:
        logger.exception(f"createWorkflow failed: {e}")
        return {
            "status": "error",
            "error_message": str(e),
            "error_code": "INTERNAL_ERROR",
        }


@mcp.tool()
async def updateWorkflow(
    workflow_id: str,
    name: Optional[str] = None,
    content: Optional[str] = None,
    signals: Optional[List[str]] = None,
    description: Optional[str] = None,
    role: Optional[str] = None,
    agent_id: Optional[str] = None,
    project_id: Optional[str] = None,
    public: Optional[bool] = None,
    metadata: Optional[Dict[str, Any]] = None,
    when_to_use: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Update an existing workflow. Only provided fields are changed.

    Uses partial update semantics: omitted fields keep their current values.
    Scope fields (role, agent_id, project_id) can be explicitly cleared by
    passing empty string.

    WHEN TO USE:
    - Modifying workflow content or signals
    - Changing workflow scope or visibility
    - Renaming a workflow
    - Updating when_to_use description

    Args:
        workflow_id: UUID of the workflow to update
        name: Optional new name (must be unique in scope)
        content: Optional new markdown body
        signals: Optional new signal list (must be non-empty if provided)
        description: Optional new description
        role: Optional new role scope
        agent_id: Optional new agent scope
        project_id: Optional new project scope
        public: Optional new visibility flag
        metadata: Optional new metadata dict
        when_to_use: Optional new when_to_use description for workflow activation

    Returns:
        dict: {status, workflow: {id, name, content, ...}, error_message, error_code}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.UpdateWorkflowRequest(
            user_token=manager.token or "",
            workflow_id=workflow_id,
        )

        # Set fields with sentinel booleans
        if name is not None:
            request.name = name
            request.name_provided = True
        if content is not None:
            request.content = content
            request.content_provided = True
        if signals is not None:
            request.signals.extend(signals)
            request.signals_provided = True
        if description is not None:
            request.description = description
            request.description_provided = True
        if role is not None:
            request.role = role
            request.role_provided = True
        if agent_id is not None:
            request.agent_id = agent_id
            request.agent_id_provided = True
        if project_id is not None:
            request.project_id = project_id
            request.project_id_provided = True
        if public is not None:
            request.public = public
            request.public_provided = True
        if metadata is not None:
            request.metadata_json = json.dumps(metadata)
            request.metadata_provided = True
        if when_to_use is not None:
            request.when_to_use = when_to_use
            request.when_to_use_provided = True

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "UpdateWorkflow", request
        )

        if response.status == "error":
            return {
                "status": "error",
                "error_message": response.error_message,
                "error_code": response.error_code,
            }

        return {
            "status": "success",
            "workflow": _workflow_from_pb(response.workflow),
            "error_message": "",
            "error_code": "",
        }

    except Exception as e:
        logger.exception(f"updateWorkflow failed: {e}")
        return {
            "status": "error",
            "error_message": str(e),
            "error_code": "INTERNAL_ERROR",
        }


@mcp.tool()
async def deleteWorkflow(
    workflow_id: str,
) -> Dict[str, Any]:
    """
    Delete a workflow by ID.

    Requires ownership (creator) or superuser privileges.
    System workflows (no owner) can only be deleted by superusers.

    WHEN TO USE:
    - Removing obsolete workflows
    - Cleaning up test workflows

    Args:
        workflow_id: UUID of the workflow to delete

    Returns:
        dict: {status, workflow_id, deleted, error_message, error_code}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.DeleteWorkflowRequest(
            user_token=manager.token or "",
            workflow_id=workflow_id,
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "DeleteWorkflow", request
        )

        if response.status == "error":
            return {
                "status": "error",
                "error_message": response.error_message,
                "error_code": response.error_code,
            }

        return {
            "status": "success",
            "workflow_id": response.workflow_id,
            "deleted": response.deleted,
            "error_message": "",
            "error_code": "",
        }

    except Exception as e:
        logger.exception(f"deleteWorkflow failed: {e}")
        return {
            "status": "error",
            "error_message": str(e),
            "error_code": "INTERNAL_ERROR",
        }


@mcp.tool()
async def listWorkflows(
    company_id: str,
    role: Optional[str] = None,
    agent_id: Optional[str] = None,
    project_id: Optional[str] = None,
    limit: Optional[int] = None,
    offset: Optional[int] = None,
) -> Dict[str, Any]:
    """
    List visible workflows with optional filters.

    Returns workflows the current user can see: owned workflows plus
    public workflows in the same company/project. Supports pagination.

    WHEN TO USE:
    - Browsing available workflows
    - Finding workflows for a specific role or agent
    - Auditing workflow inventory

    Args:
        company_id: Company UUID (defaults to first company from token)
        role: Optional filter by role scope
        agent_id: Optional filter by agent scope
        project_id: Optional filter by project scope
        limit: Optional max results (default: 50)
        offset: Optional skip first N results

    Returns:
        dict: {status, workflows: [{id, name, ...}], total_count, error_message, error_code}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.ListWorkflowsRequest(
            user_token=manager.token or "",
            company_id=company_id or "",
            role=role or "",
            agent_id=agent_id or "",
            project_id=project_id or "",
            limit=limit or 0,
            offset=offset or 0,
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "ListWorkflows", request
        )

        if response.status == "error":
            return {
                "status": "error",
                "error_message": response.error_message,
                "error_code": response.error_code,
            }

        return {
            "status": "success",
            "workflows": [_workflow_from_pb(w) for w in response.workflows],
            "total_count": response.total_count,
            "error_message": "",
            "error_code": "",
        }

    except Exception as e:
        logger.exception(f"listWorkflows failed: {e}")
        return {
            "status": "error",
            "error_message": str(e),
            "error_code": "INTERNAL_ERROR",
        }


# ============================================================================
# Agent Skill Navigation Tools
# ============================================================================


@mcp.tool()
@require_agent_context("getAgentSkills")
async def getAgentSkills(
    agent_id: str,
) -> Dict[str, Any]:
    """
    Get agent's skill overview - LIGHTWEIGHT list of skill titles and summaries.

    IMPORTANT: This is the FIRST tier of progressive disclosure. Returns ONLY
    skill-level info (title, summary, sections_count). Does NOT include sections.
    Use getSkillSections(expertise_id) to load sections for a specific skill.

    WHEN TO USE:
    - First call when agent starts working - establishes what knowledge is available
    - When user asks "what do you know about X?" - check if relevant skills exist
    - Before answering domain questions - verify you have the right expertise
    - Self-awareness check: "Do I have skills for this task?"

    PROGRESSIVE DISCLOSURE PATTERN:
    1. getAgentSkills(agent_id) → lightweight skill titles/summaries (THIS TOOL)
    2. getSkillSections(expertise_id) → sections for ONE skill you want to explore
    3. getSkillContent(chunk_id) → full content for ONE section you need

    WORKFLOW EXAMPLE:
    1. User asks: "How should I handle errors in Python?"
    2. You call: getAgentSkills(agent_id="my-agent-001")
    3. Response shows: "Python Best Practices Guide" (expertise_id, sections_count=15)
    4. You call: getSkillSections(expertise_id="xyz") to see section titles
    5. You find "Error Handling" section with chunk_id
    6. You call: getSkillContent(chunk_id="abc-123") for that section
    7. You answer using the retrieved content

    Args:
        agent_id: Agent UUID - identifies which agent's skills to retrieve

    Returns:
        dict: {
            agent_id: str,
            agent_name: str,
            skills_count: int,
            skills: [{
                expertise_id: str - UUID of the expertise document,
                title: str - expertise title (e.g., "Python Best Practices"),
                summary: str - brief description of what this skill covers,
                sections_count: int - number of sections (use getSkillSections to load them)
            }]
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.GetAgentSkillsRequest(
            agent_id=agent_id,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "GetAgentSkills", request
        )

        return {
            "status": response.status,
            "agent_id": response.agent_id,
            "agent_name": response.agent_name,
            "skills_count": response.skills_count,
            "skills": [
                {
                    "expertise_id": skill.expertise_id,
                    "title": skill.title,
                    "summary": skill.summary,
                    "sections_count": skill.sections_count,
                }
                for skill in response.skills
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Get agent skills error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "GET_AGENT_SKILLS_FAILED",
        }


@mcp.tool()
@require_agent_context("searchSkillDetails")
async def searchSkillDetails(
    expertise_id: str,
    query: str,
    limit: int = 5,
) -> Dict[str, Any]:
    """
    Semantic search within a skill's chunks - PREFERRED way to find skill content.

    WHEN TO USE:
    - After getAgentSkills - when you know WHAT skill has the info but not WHERE
    - When you have a question about a skill (e.g., "how to handle errors?")
    - Instead of browsing 80+ sections manually via getSkillSections

    WHY USE THIS:
    - 5x more token efficient than getSkillSections (5 results vs 80 sections)
    - Returns FULL CONTENT - often no second call needed
    - Semantic search finds exactly what you need
    - Much faster than manually scanning section titles

    PROGRESSIVE DISCLOSURE PATTERN (UPDATED):
    1. getAgentSkills(agent_id) → lightweight overview (title, summary, sections_count)
    2. searchSkillDetails(expertise_id, query) → semantic search → top-k chunks WITH CONTENT
    3. getSkillContent(chunk_id) → optional, only if need more context around a chunk

    vs getSkillSections: getSkillSections returns ALL section titles/summaries.
    searchSkillDetails returns RELEVANT chunks with FULL CONTENT.
    Use searchSkillDetails when you know what you're looking for.
    Use getSkillSections only for browsing when you don't know what to search.

    WORKFLOW EXAMPLE:
    1. getAgentSkills showed "Python Best Practices" with expertise_id="xyz"
    2. You need info on error handling
    3. You call: searchSkillDetails(expertise_id="xyz", query="error handling patterns")
    4. Response includes 5 chunks with full content about error handling
    5. No need to call getSkillContent - you already have the content!

    Args:
        expertise_id: Expertise UUID from getAgentSkills response
        query: Natural language query (e.g., "error handling", "async patterns")
        limit: Max results to return (default: 5)

    Returns:
        dict: {
            expertise_id: str,
            expertise_title: str,
            query: str - your search query,
            results_count: int,
            results: [{
                chunk_id: str - for getSkillContent if you need more context,
                title: str - section heading,
                content: str - FULL CONTENT (no second call needed!),
                score: float - relevance score (0-1),
                has_code: bool - contains code examples,
                level: int - hierarchy depth,
                position: int - order within parent
            }]
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.SearchSkillDetailsRequest(
            expertise_id=expertise_id,
            query=query,
            limit=limit,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "SearchSkillDetails", request
        )

        return {
            "status": response.status,
            "expertise_id": response.expertise_id,
            "expertise_title": response.expertise_title,
            "query": response.query,
            "results_count": response.results_count,
            "results": [
                {
                    "chunk_id": result.chunk_id,
                    "title": result.title,
                    "content": result.content,
                    "score": result.score,
                    "has_code": result.has_code,
                    "level": result.level,
                    "position": result.position,
                }
                for result in response.results
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Search skill details error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "SEARCH_SKILL_DETAILS_FAILED",
        }


@mcp.tool()
@require_agent_context("getSkillSections")
async def getSkillSections(
    expertise_id: str,
) -> Dict[str, Any]:
    """
    Get sections for ONE expertise document - FALLBACK for browsing when you don't know what to search.

    WHEN TO USE:
    - After getAgentSkills - when you've identified a relevant skill to explore
    - When you want to see what sections/topics a skill contains
    - Before fetching full content - to find the right chunk_id

    PROGRESSIVE DISCLOSURE PATTERN:
    1. getAgentSkills(agent_id) → lightweight skill titles/summaries
    2. getSkillSections(expertise_id) → sections for ONE skill (THIS TOOL)
    3. getSkillContent(chunk_id) → full content for ONE section

    HOW IT WORKS:
    This loads sections for a SINGLE skill you're interested in.
    Much more efficient than loading all sections for all skills at once.

    WORKFLOW EXAMPLE:
    1. getAgentSkills showed "Python Best Practices" with expertise_id="xyz"
    2. You call: getSkillSections(expertise_id="xyz")
    3. Response shows sections: ["Error Handling", "Async Patterns", "Testing"]
    4. You pick the relevant one and call getSkillContent(chunk_id)

    Args:
        expertise_id: Expertise UUID from getAgentSkills response

    Returns:
        dict: {
            expertise_id: str,
            title: str - expertise title,
            summary: str - expertise summary,
            sections_count: int,
            sections: [{
                chunk_id: str - UUID to use with getSkillContent,
                title: str - section heading (e.g., "Error Handling"),
                summary: str - what this section covers,
                has_code: bool - true if contains code examples,
                level: int - hierarchy depth (0=root, 1=subsection, etc.),
                position: int - order within parent
            }]
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.GetSkillSectionsRequest(
            expertise_id=expertise_id,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "GetSkillSections", request
        )

        return {
            "status": response.status,
            "expertise_id": response.expertise_id,
            "title": response.title,
            "summary": response.summary,
            "sections_count": response.sections_count,
            "sections": [
                {
                    "chunk_id": section.chunk_id,
                    "title": section.title,
                    "summary": section.summary,
                    "has_code": section.has_code,
                    "level": section.level,
                    "position": section.position,
                }
                for section in response.sections
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Get skill sections error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "GET_SKILL_SECTIONS_FAILED",
        }


@mcp.tool()
@require_agent_context("getSkillContent")
async def getSkillContent(
    chunk_id: str,
) -> Dict[str, Any]:
    """
    Fetch the full content of a specific skill section by its chunk_id.

    WHEN TO USE:
    - After getAgentSkills - when you've identified a relevant section to read
    - When you need the actual content, not just titles/summaries
    - To retrieve code examples (check has_code=true in skill tree)
    - For deep-dive into a specific topic within your skills

    HOW IT WORKS:
    This is the "read the chapter" step after browsing the "table of contents".
    1. You already called getAgentSkills and scanned the skill tree
    2. You identified chunk_id of a relevant section
    3. Now you call getSkillContent to get the full text

    WHAT YOU GET:
    - Full markdown content of the section
    - Code examples if has_code=true
    - The expertise_id it belongs to (for context)

    EFFICIENCY TIP:
    Only fetch sections you actually need. The skill tree gives you enough
    context (title, summary) to decide which chunks are relevant.

    vs queryExpertise: queryExpertise uses vector search across ALL expertise.
    getSkillContent retrieves a SPECIFIC section you already identified.
    Use getSkillContent when navigating your own skills deterministically.

    Args:
        chunk_id: Chunk UUID from getAgentSkills response (sections[].chunk_id)

    Returns:
        dict: {
            chunk_id: str - same as input,
            title: str - section title,
            content: str - full markdown content with code blocks,
            has_code: bool - whether section contains code examples,
            level: int - hierarchy depth,
            expertise_id: str - parent expertise document UUID
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.GetSkillContentRequest(
            chunk_id=chunk_id,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "GetSkillContent", request
        )

        return {
            "status": response.status,
            "chunk_id": response.chunk_id,
            "title": response.title,
            "content": response.content,
            "has_code": response.has_code,
            "level": response.level,
            "expertise_id": response.expertise_id,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Get skill content error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "GET_SKILL_CONTENT_FAILED",
        }


@mcp.tool()
async def linkAgentSkill(
    agent_id: str,
    expertise_id: str,
) -> Dict[str, Any]:
    """
    Link an expertise document to an agent, making it available as a navigable skill.

    WHEN TO USE:
    - After creating new expertise via createExpertise - connect it to an agent
    - When onboarding an agent to a new domain - add relevant expertise as skills
    - Building/configuring agent capabilities at setup time
    - Granting an agent access to specific knowledge

    HOW IT WORKS:
    Creates a HAS_SKILL relationship in the knowledge graph:
    (Agent) -[HAS_SKILL]-> (Expertise)

    After linking, the expertise will appear in getAgentSkills response,
    allowing the agent to navigate and read that knowledge.

    IMPORTANT:
    - The expertise must exist (created via createExpertise)
    - The agent must exist in the system
    - Linking is idempotent - linking twice has no effect

    WORKFLOW EXAMPLE:
    1. Create expertise: createExpertise(text="# Python Guide...", project_id="...")
    2. Get expertise_id from response
    3. Link to agent: linkAgentSkill(agent_id="dev-agent", expertise_id="...")
    4. Now getAgentSkills("dev-agent") will include "Python Guide"

    vs createExpertise: createExpertise creates the knowledge document.
    linkAgentSkill connects it to a specific agent. You need both.

    Args:
        agent_id: Agent UUID - which agent should receive this skill
        expertise_id: Expertise UUID - which expertise to link (from createExpertise or listExpertise)

    Returns:
        dict: {
            status: "linked" on success,
            agent_id: str,
            expertise_id: str,
            expertise_title: str - title of the linked expertise
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.LinkAgentSkillRequest(
            agent_id=agent_id,
            expertise_id=expertise_id,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "LinkAgentSkill", request
        )

        return {
            "status": response.status,
            "agent_id": response.agent_id,
            "expertise_id": response.expertise_id,
            "expertise_title": response.expertise_title,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Link agent skill error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "LINK_AGENT_SKILL_FAILED",
        }


@mcp.tool()
async def unlinkAgentSkill(
    agent_id: str,
    expertise_id: str,
) -> Dict[str, Any]:
    """
    Remove an expertise link from an agent, revoking that skill.

    WHEN TO USE:
    - Expertise is outdated/deprecated and should no longer be used
    - Agent role changed and no longer needs this knowledge
    - Reorganizing agent capabilities
    - Cleaning up after expertise deletion

    HOW IT WORKS:
    Removes the HAS_SKILL relationship from the knowledge graph.
    After unlinking, the expertise will NOT appear in getAgentSkills response.

    IMPORTANT:
    - This only removes the link, NOT the expertise itself
    - The expertise remains in the system and can be relinked later
    - Unlinking is idempotent - unlinking twice has no effect
    - Other agents linked to the same expertise are not affected

    WHEN NOT TO USE:
    - To delete expertise entirely - use a delete expertise operation instead
    - To temporarily hide knowledge - there's no "pause" feature, just unlink/relink

    Args:
        agent_id: Agent UUID - which agent to remove the skill from
        expertise_id: Expertise UUID - which expertise to unlink

    Returns:
        dict: {
            status: "unlinked" on success,
            agent_id: str,
            expertise_id: str
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.UnlinkAgentSkillRequest(
            agent_id=agent_id,
            expertise_id=expertise_id,
            user_token=manager.token or "",
        )

        response = await manager.call_with_auth_by_name(
            "agent_skill_stub", "UnlinkAgentSkill", request
        )

        return {
            "status": response.status,
            "agent_id": response.agent_id,
            "expertise_id": response.expertise_id,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Unlink agent skill error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "UNLINK_AGENT_SKILL_FAILED",
        }


# ============================================================================
# Agent Lifecycle Tools
# ============================================================================


@mcp.tool()
async def createAgent(
    company_id: str,
    name: str,
    role: str,
    personality: str,
    main_responsibilities: str,
    system_prompt: str,
    capabilities: Optional[List[str]] = None,
    specialization: Optional[str] = None,
    when_to_use: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Create a new specialist agent in the LEGION system.

    WHEN TO USE:
    - Birthing new specialist agents (Researcher, Developer, Architect, etc.)
    - Expanding the team with new capabilities
    - Called by the orchestrator (Arthur) to build the team

    AUTOMATIC BEHAVIOR:
    - Creates agent record in PostgreSQL
    - Creates Agent node in Neo4j
    - Auto-links "How to Research and Create Skills" (learning ability)

    IMPORTANT - SYSTEM PROMPT REQUIREMENTS:
    Every agent's system_prompt MUST include LEGION MCP instructions for their role.
    Include instructions on which tools to use to persist their work:
    - Researchers: createKnowledge() for findings
    - Architects: createExpertise() for designs
    - Developers: createCode() for code, recordLesson() for bugs
    - All agents: queryKnowledge(), queryLessons() before starting work

    Args:
        company_id: Company UUID (from getProjects)
        name: Personality name (from Billy Milligan's personalities)
        role: Functional role (e.g., "researcher", "developer", "architect")
        personality: Detailed personality description, traits, mannerisms
        main_responsibilities: What tasks this agent handles
        system_prompt: Full behavioral instructions INCLUDING LEGION MCP usage
        capabilities: Optional skill tags (e.g., ["research", "analysis"])
        specialization: Optional primary domain (e.g., "backend", "frontend")
        when_to_use: Optional description of when to delegate to this agent

    Returns:
        dict: {
            status: "success" or "error",
            agent_id: str - UUID of created agent,
            name: str - Agent name,
            role: str - Agent role,
            learning_skill_linked: bool - True if learning skill was auto-linked,
            when_to_use: str - When to delegate to this agent
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.CreateAgentRequest(
            user_token=manager.token or "",
            company_id=company_id,
            name=name,
            role=role,
            personality=personality,
            main_responsibilities=main_responsibilities,
            system_prompt=system_prompt,
            capabilities=capabilities or [],
            specialization=specialization or "",
            when_to_use=when_to_use or "",
        )

        response = await manager.call_with_auth_by_name("agent_skill_stub", "CreateAgent", request)

        return {
            "status": response.status,
            "agent_id": response.agent_id,
            "name": response.name,
            "role": response.role,
            "learning_skill_linked": response.learning_skill_linked,
            "when_to_use": response.when_to_use or None,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Create agent error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "CREATE_AGENT_FAILED",
        }


@mcp.tool()
async def deleteAgent(
    agent_id: str,
) -> Dict[str, Any]:
    """
    Delete an agent and clean up all associations.

    WHEN TO USE:
    - Removing agents that are no longer needed
    - Cleaning up test/temporary agents
    - Reorganizing the team structure

    WHAT IT DOES:
    1. Unlinks ALL skills/expertise associated with the agent
    2. Removes Agent node from Neo4j (and all relationships)
    3. Deletes agent record from PostgreSQL

    IMPORTANT:
    - This is PERMANENT - the agent cannot be recovered
    - Skills/expertise documents are NOT deleted, only unlinked
    - Use with caution - verify agent_id before calling

    Args:
        agent_id: Agent UUID to delete

    Returns:
        dict: {
            status: "success" or "error",
            agent_id: str - UUID of deleted agent,
            name: str - Name of deleted agent,
            skills_unlinked: int - Number of skills that were unlinked,
            deleted: bool - True if agent was successfully deleted
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.DeleteAgentRequest(
            user_token=manager.token or "",
            agent_id=agent_id,
        )

        response = await manager.call_with_auth_by_name("agent_skill_stub", "DeleteAgent", request)

        return {
            "status": response.status,
            "agent_id": response.agent_id,
            "name": response.name,
            "skills_unlinked": response.skills_unlinked,
            "deleted": response.deleted,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Delete agent error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "DELETE_AGENT_FAILED",
        }


@mcp.tool()
async def updateAgent(
    agent_id: str,
    name: Optional[str] = None,
    personality: Optional[str] = None,
    main_responsibilities: Optional[str] = None,
    system_prompt: Optional[str] = None,
    metadata_json: Optional[str] = None,
    project_id: Optional[str] = None,
    public: Optional[bool] = None,
    when_to_use: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Update an existing agent. Only provided fields are changed.

    Uses partial update semantics: omitted fields keep their current values.
    Scope fields (project_id) can be explicitly cleared by passing empty string.

    WHEN TO USE:
    - Modifying agent personality, system prompt, or responsibilities
    - Changing agent project scope or visibility
    - Updating agent metadata (role, capabilities, specialization)
    - Renaming an agent
    - Updating when_to_use description for agent delegation

    Args:
        agent_id: Agent UUID (required)
        name: Optional new name (must be unique in company)
        personality: Optional new personality description
        main_responsibilities: Optional new responsibilities
        system_prompt: Optional new behavioral instructions
        metadata_json: Optional JSON string of metadata dict (e.g., '{"role": "developer", "capabilities": ["python"]}')
        project_id: Optional new project scope (empty string to clear)
        public: Optional new visibility flag
        when_to_use: Optional new when_to_use description for agent delegation

    Returns:
        dict: {
            status: "success" or "error",
            agent_id: str - UUID of updated agent,
            name: str - Agent name,
            role: str - Agent role,
            error_message, error_code
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = agent_skill_pb2.UpdateAgentRequest(
            user_token=manager.token or "",
            agent_id=agent_id,
            name=name or "",
            name_provided=name is not None,
            personality=personality or "",
            personality_provided=personality is not None,
            main_responsibilities=main_responsibilities or "",
            main_responsibilities_provided=main_responsibilities is not None,
            system_prompt=system_prompt or "",
            system_prompt_provided=system_prompt is not None,
            metadata_json=metadata_json or "",
            metadata_provided=metadata_json is not None,
            project_id=project_id or "",
            project_id_provided=project_id is not None,
            public=public if public is not None else False,
            public_provided=public is not None,
            when_to_use=when_to_use or "",
            when_to_use_provided=when_to_use is not None,
        )

        response = await manager.call_with_auth_by_name("agent_skill_stub", "UpdateAgent", request)

        return {
            "status": response.status,
            "agent_id": response.agent_id,
            "name": response.name,
            "role": response.role,
            "when_to_use": response.when_to_use or None,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Update agent error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "UPDATE_AGENT_FAILED",
        }


# ============================================================================
# Engagement Tools
# ============================================================================


@mcp.tool()
async def createEngagement(
    name: str,
    ultimate_goal: str,
    project_id: str,
    agent_id: Optional[str] = None,
    user_id: Optional[str] = None,
    summary: Optional[str] = None,
    engagement_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Start a new engagement (work session) for a project.

    When to use:
    - Beginning a new user interaction or work session
    - Starting a new feature development cycle
    - Initiating a research or analysis task
    - Creating a context container for related tasks and entries
    - Creating a child engagement under a parent engagement

    Engagements track the conversation history, decisions, insights, and plans
    throughout a work session. They provide resumption context and semantic search.

    Args:
        name: Descriptive name for the engagement (e.g., "Implement User Auth", "Q1 Planning")
        ultimate_goal: The overarching objective this engagement aims to achieve (REQUIRED, min 10 chars).
                       This keeps agents focused on the end goal throughout the session.
        project_id: Project UUID from getProjects
        agent_id: Optional agent UUID if initiated by specific agent
        user_id: Optional user UUID if initiated by specific user
        summary: Optional initial summary/description
        engagement_id: Optional parent engagement UUID for hierarchical relationships

    Returns:
        dict: {engagement_id, name, ultimate_goal, engagement_status, created_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        # Get company_id from first available project
        company_id = ""
        if manager.user_projects:
            for project in manager.user_projects:
                if project["id"] == project_id:
                    company_id = project["company_id"]
                    break

        request = engagement_pb2.CreateEngagementRequest(
            user_token=manager.token or "",
            company_id=company_id,
            project_id=project_id,
            name=name,
            ultimate_goal=ultimate_goal,
            agent_id=agent_id or "",
            user_id=user_id or "",
            summary=summary or "",
            engagement_id=engagement_id or "",
        )

        response = await manager.call_with_auth_by_name(
            "engagement_stub", "CreateEngagement", request
        )

        return {
            "status": response.status,
            "message": response.message,
            "engagement_id": response.engagement_id,
            "name": response.name,
            "ultimate_goal": response.ultimate_goal,
            "engagement_status": response.engagement_status,
            "created_at": response.created_at,
            "parent_engagement_id": response.parent_engagement_id,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Create engagement error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "CREATE_ENGAGEMENT_FAILED",
        }


@mcp.tool()
async def getEngagement(
    engagement_id: str,
) -> Dict[str, Any]:
    """
    Get engagement details with entry metadata (lightweight).

    When to use:
    - Retrieving conversation history for an engagement
    - Getting context before resuming work
    - Reviewing decisions and insights from a session
    - Checking current engagement status

    NOTE: Returns entry metadata only (id, type, title, content_length).
    Use getEntry(entry_id) to retrieve full content for individual entries.

    Args:
        engagement_id: Engagement UUID from createEngagement

    Returns:
        dict: {engagement_id, name, ultimate_goal, status, entries[{id, entry_type, title, content_length, created_at}], created_at, updated_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = engagement_pb2.GetEngagementRequest(
            user_token=manager.token or "",
            engagement_id=engagement_id,
        )

        response = await manager.call_with_auth_by_name("engagement_stub", "GetEngagement", request)

        return {
            "status": response.status,
            "engagement_id": response.engagement_id,
            "name": response.name,
            "ultimate_goal": response.ultimate_goal,
            "engagement_status": response.engagement_status,
            "company_id": response.company_id,
            "project_id": response.project_id,
            "agent_id": response.agent_id,
            "user_id": response.user_id,
            "summary": response.summary,
            "parent_engagement_id": response.parent_engagement_id,
            "entries": [
                {
                    "id": e.id,
                    "entry_type": e.entry_type,
                    "title": e.title,
                    "content_length": e.content_length,
                    "created_at": e.created_at,
                }
                for e in response.entries
            ],
            "created_at": response.created_at,
            "updated_at": response.updated_at,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Get engagement error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "GET_ENGAGEMENT_FAILED",
        }


@mcp.tool()
async def getEntry(
    entry_id: str,
) -> Dict[str, Any]:
    """
    Get a single entry by ID with full content.

    When to use:
    - Retrieving full content for a specific entry
    - After seeing entry in getEngagement and needing full text
    - Reading complete requirement, insight, decision, or plan content

    Args:
        entry_id: Entry UUID from getEngagement entries list

    Returns:
        dict: {entry_id, engagement_id, entry_type, title, content, created_by_agent_id, created_at, references, tags, summary, version, updated_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = engagement_pb2.GetEntryRequest(
            user_token=manager.token or "",
            entry_id=entry_id,
        )

        response = await manager.call_with_auth_by_name("engagement_stub", "GetEntry", request)

        if response.status != "success":
            return {
                "status": response.status,
                "error_message": response.error_message,
                "error_code": response.error_code,
            }

        entry = response.entry
        return {
            "status": "success",
            "entry_id": entry.id,
            "engagement_id": entry.engagement_id,
            "entry_type": entry.entry_type,
            "title": entry.title,
            "content": entry.content,
            "created_by_agent_id": entry.created_by_agent_id,
            "created_at": entry.created_at,
            "references": list(entry.references),
            "tags": list(entry.tags),
            "summary": entry.summary,
            "version": entry.version,
            "updated_at": entry.updated_at,
        }
    except Exception as e:
        logger.error(f"Get entry error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "GET_ENTRY_FAILED",
        }


@mcp.tool()
async def listEngagements(
    project_id: str,
    status: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    engagement_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    List engagements for a project with optional status filter.

    When to use:
    - Viewing all engagements for a project
    - Finding active or recent engagements
    - Filtering by status (created, preparation, execution, validation, done)
    - Getting overview of work sessions
    - Listing child engagements of a parent (engagement_id filter)

    Args:
        project_id: Project UUID from getProjects
        status: Optional filter by status (created, preparation, execution, validation, done)
        limit: Max results (default: 50)
        offset: Starting position for pagination (default: 0)
        engagement_id: Optional parent engagement UUID to list only children of that engagement

    Returns:
        dict: {total_count, engagements[{id, name, ultimate_goal, status, engagement_id, created_at, updated_at}]}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = engagement_pb2.ListEngagementsRequest(
            user_token=manager.token or "",
            project_id=project_id,
            status=status or "",
            limit=limit,
            offset=offset,
            engagement_id=engagement_id or "",
        )

        response = await manager.call_with_auth_by_name(
            "engagement_stub", "ListEngagements", request
        )

        return {
            "status": response.status,
            "project_id": response.project_id,
            "total_count": response.total_count,
            "engagements": [
                {
                    "id": e.id,
                    "name": e.name,
                    "ultimate_goal": e.ultimate_goal,
                    "status": e.status,
                    "company_id": e.company_id,
                    "project_id": e.project_id,
                    "agent_id": e.agent_id,
                    "user_id": e.user_id,
                    "summary": e.summary,
                    "engagement_id": e.engagement_id,
                    "created_at": e.created_at,
                    "updated_at": e.updated_at,
                }
                for e in response.engagements
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"List engagements error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "LIST_ENGAGEMENTS_FAILED",
        }


@mcp.tool()
async def updateEngagement(
    engagement_id: str,
    name: Optional[str] = None,
    status: Optional[str] = None,
    summary: Optional[str] = None,
    ultimate_goal: Optional[str] = None,
    parent_engagement_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Update engagement details (name, status, summary, ultimate_goal).

    When to use:
    - Changing engagement status (execution → validation, validation → done)
    - Updating engagement name or summary
    - Pausing work session for later resumption
    - Completing an engagement
    - Re-aligning the ultimate goal
    - Setting or changing the parent engagement

    Args:
        engagement_id: Engagement UUID — also satisfies the engagement guard
        name: Optional new name
        status: Optional new status (created, preparation, execution, validation, done)
        summary: Optional updated summary
        ultimate_goal: Optional updated ultimate goal (only if re-aligning)
        parent_engagement_id: Optional parent engagement UUID for hierarchical relationships

    Returns:
        dict: {engagement_id, name, ultimate_goal, engagement_status, updated_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = engagement_pb2.UpdateEngagementRequest(
            user_token=manager.token or "",
            engagement_id=engagement_id,
            name=name or "",
            status=status or "",
            summary=summary or "",
            ultimate_goal=ultimate_goal or "",
            parent_engagement_id=parent_engagement_id or "",
        )

        response = await manager.call_with_auth_by_name(
            "engagement_stub", "UpdateEngagement", request
        )

        return {
            "status": response.status,
            "message": response.message,
            "engagement_id": response.engagement_id,
            "name": response.name,
            "ultimate_goal": response.ultimate_goal,
            "engagement_status": response.engagement_status,
            "updated_at": response.updated_at,
            "parent_engagement_id": response.parent_engagement_id,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Update engagement error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "UPDATE_ENGAGEMENT_FAILED",
        }


@mcp.tool()
async def addEntry(
    engagement_id: str,
    entry_type: str,
    title: str,
    content: str,
    agent_id: Optional[str] = None,
    references: Optional[List[str]] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Add an entry to an engagement (requirement, insight, decision, plan, etc.).

    When to use:
    - Recording user requirements during conversation
    - Documenting insights discovered during analysis
    - Capturing decisions made during session
    - Adding implementation plans or next steps
    - Creating structured conversation history

    Entry types:
    - requirement: User needs, feature requests
    - insight: Discoveries, observations, findings
    - decision: Choices made, approaches selected
    - plan: Implementation steps, action items
    - note: General observations, reminders
    - question: Open questions, clarifications needed

    Args:
        engagement_id: Engagement UUID from createEngagement
        entry_type: Type of entry (requirement, insight, decision, plan, note, question)
        title: Short descriptive title
        content: Full entry content (can be markdown)
        agent_id: Optional agent UUID who created this entry
        references: Optional list of entry IDs this entry references
        tags: Optional list of tags for categorization and filtering

    Returns:
        dict: {entry_id, engagement_id, entry_type, title, created_at, summary, version}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = engagement_pb2.AddEntryRequest(
            user_token=manager.token or "",
            engagement_id=engagement_id,
            entry_type=entry_type,
            title=title,
            content=content,
            agent_id=agent_id or "",
            references=references or [],
            tags=tags or [],
        )

        response = await manager.call_with_auth_by_name("engagement_stub", "AddEntry", request)

        return {
            "status": response.status,
            "message": response.message,
            "entry_id": response.entry_id,
            "engagement_id": response.engagement_id,
            "entry_type": response.entry_type,
            "title": response.title,
            "created_at": response.created_at,
            "summary": response.summary,
            "version": response.version,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Add entry error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "ADD_ENTRY_FAILED",
        }


@mcp.tool()
async def updateEntry(
    entry_id: str,
    content: Optional[str] = None,
    references: Optional[List[str]] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Update an existing entry's content, references, or tags.

    When to use:
    - Correcting or expanding previous entry content
    - Adding references to link entries together
    - Updating tags for better categorization
    - Revising decisions or plans

    Important:
    - Updates increment the version number automatically
    - updated_at timestamp is set automatically
    - Content changes trigger Qdrant re-indexing for search

    Args:
        entry_id: Entry UUID from addEntry or getEntry
        content: Optional new content (replaces existing)
        references: Optional new list of entry IDs this entry references
        tags: Optional new list of tags for categorization

    Returns:
        dict: {entry_id, entry_type, title, summary, version, updated_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = engagement_pb2.UpdateEntryRequest(
            user_token=manager.token or "",
            entry_id=entry_id,
            content=content or "",
            references=references or [],
            tags=tags or [],
        )

        response = await manager.call_with_auth_by_name("engagement_stub", "UpdateEntry", request)

        return {
            "status": response.status,
            "message": response.message,
            "entry_id": response.entry_id,
            "entry_type": response.entry_type,
            "title": response.title,
            "summary": response.summary,
            "version": response.version,
            "updated_at": response.updated_at,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Update entry error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "UPDATE_ENTRY_FAILED",
        }


@mcp.tool()
async def searchEntries(
    query: str,
    project_id: str,
    engagement_id: Optional[str] = None,
    entry_type: Optional[str] = None,
    limit: int = 10,
) -> Dict[str, Any]:
    """
    Hybrid search across engagement entries (Vector + Graph + RRF fusion).

    Pipeline:
    1. Vector Search: Qdrant semantic search for relevant entries
    2. Graph Expansion: Neo4j finds related entries (same engagement, same agent)
    3. RRF Fusion: Combines and ranks results without LLM reranking

    When to use:
    - Finding past conversations about a topic
    - Searching for specific requirements or decisions
    - Discovering related work sessions
    - Looking up historical context

    Graph relationships leveraged:
    - (Entry)-[:BELONGS_TO]->(Engagement) - sibling entries in same session
    - (Entry)-[:CREATED_BY]->(Agent) - entries by same agent across sessions

    Args:
        query: Natural language search query
        project_id: Project UUID from getProjects
        engagement_id: Optional engagement UUID to search within a specific engagement only
        entry_type: Optional filter by entry type (requirement, insight, decision, plan, note, question)
        limit: Max results (default: 10)

    Returns:
        dict: {results[{text, score, vector_score, metadata}], results_count}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = engagement_pb2.SearchEntriesRequest(
            user_token=manager.token or "",
            query=query,
            project_id=project_id,
            engagement_id=engagement_id or "",
            entry_type=entry_type or "",
            limit=limit,
        )

        response = await manager.call_with_auth_by_name("engagement_stub", "SearchEntries", request)

        return {
            "status": response.status,
            "query": response.query,
            "project_id": response.project_id,
            "results_count": response.results_count,
            "results": [
                {
                    "id": r.id,
                    "text": r.text,
                    "metadata": dict(r.metadata),
                    "score": r.score,
                    "vector_score": r.vector_score,
                    "rerank_score": r.rerank_score,
                }
                for r in response.results
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Search entries error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "SEARCH_ENTRIES_FAILED",
        }


@mcp.tool()
async def resumeEngagement(
    engagement_id: str,
) -> Dict[str, Any]:
    """
    Get formatted resumption context for an engagement.

    When to use:
    - Resuming work after a break
    - Getting structured overview of engagement state
    - Reviewing all entries organized by type
    - Providing context to new agent taking over

    Returns entries grouped by type (requirements, insights, decisions, plans, etc.)
    for easy scanning and context reconstruction.

    Args:
        engagement_id: Engagement UUID from createEngagement

    NOTE: Returns entry metadata only (id, entry_type, title, content_length).
    Use getEntry(entry_id) to retrieve full content for individual entries.

    Returns:
        dict: {
            engagement_id, name, ultimate_goal, status, summary,
            entries_by_type[{entry_type, entries[{id, entry_type, title, content_length, created_by_agent_id, created_at}]}],
            total_entries
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = engagement_pb2.ResumeEngagementRequest(
            user_token=manager.token or "",
            engagement_id=engagement_id,
        )

        response = await manager.call_with_auth_by_name(
            "engagement_stub", "ResumeEngagement", request
        )

        return {
            "status": response.status,
            "engagement_id": response.engagement_id,
            "name": response.name,
            "ultimate_goal": response.ultimate_goal,
            "engagement_status": response.engagement_status,
            "summary": response.summary,
            "entries_by_type": [
                {
                    "entry_type": ebt.entry_type,
                    "entries": [
                        {
                            "id": e.id,
                            "entry_type": e.entry_type,
                            "title": e.title,
                            "content_length": len(e.content) if e.content else 0,
                            "created_by_agent_id": e.created_by_agent_id,
                            "created_at": e.created_at,
                        }
                        for e in ebt.entries
                    ],
                }
                for ebt in response.entries_by_type
            ],
            "total_entries": response.total_entries,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Resume engagement error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "RESUME_ENGAGEMENT_FAILED",
        }


# ============================================================================
# Task Tools
# ============================================================================


@mcp.tool()
async def createTask(
    title: str,
    ultimate_goal: str,
    description: Optional[str] = None,
    project_id: Optional[str] = None,
    engagement_id: Optional[str] = None,
    priority: str = "medium",
    assigned_agent_id: Optional[str] = None,
    created_by_agent_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Create a new task.

    When to use:
    - Breaking down work into trackable tasks
    - Assigning work to agents
    - Creating action items from engagement decisions
    - Task management and delegation

    Tasks can be linked to engagements for context and to artifacts (code, knowledge, etc.)
    for traceability.

    Args:
        title: Task title/description
        ultimate_goal: The overarching objective this task contributes to (REQUIRED, min 10 chars).
                       This keeps agents focused on the end goal throughout execution.
        description: Optional detailed description
        project_id: Optional project UUID (inferred from engagement if not provided)
        engagement_id: Optional engagement UUID to link task to
        priority: Priority level (low, medium, high, critical) - default: medium
        assigned_agent_id: Optional agent UUID to assign task to
        created_by_agent_id: Optional agent UUID who created the task

    Returns:
        dict: {task_id, title, ultimate_goal, task_status, priority, created_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        # Get company_id from first available project
        company_id = ""
        if project_id and manager.user_projects:
            for project in manager.user_projects:
                if project["id"] == project_id:
                    company_id = project["company_id"]
                    break

        request = task_pb2.CreateTaskRequest(
            user_token=manager.token or "",
            company_id=company_id,
            project_id=project_id or "",
            title=title,
            ultimate_goal=ultimate_goal,
            description=description or "",
            engagement_id=engagement_id or "",
            priority=priority,
            assigned_agent_id=assigned_agent_id or "",
            created_by_agent_id=created_by_agent_id or "",
        )

        response = await manager.call_with_auth_by_name("task_stub", "CreateTask", request)

        return {
            "status": response.status,
            "message": response.message,
            "task_id": response.task_id,
            "title": response.title,
            "ultimate_goal": response.ultimate_goal,
            "task_status": response.task_status,
            "priority": response.priority,
            "created_at": response.created_at,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Create task error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "CREATE_TASK_FAILED",
        }


@mcp.tool()
async def getTask(
    task_id: str,
) -> Dict[str, Any]:
    """
    Get task details with linked artifacts.

    When to use:
    - Retrieving task information
    - Checking task status and assignments
    - Viewing linked artifacts (code, knowledge, etc.)
    - Getting full task context

    Args:
        task_id: Task UUID from createTask

    Returns:
        dict: {
            task_id, title, ultimate_goal, description, status, priority,
            assigned_agent_id, blockers,
            artifacts[{artifact_type, artifact_id}],
            created_at, updated_at, completed_at
        }
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = task_pb2.GetTaskRequest(
            user_token=manager.token or "",
            task_id=task_id,
        )

        response = await manager.call_with_auth_by_name("task_stub", "GetTask", request)

        return {
            "status": response.status,
            "task_id": response.task_id,
            "title": response.title,
            "ultimate_goal": response.ultimate_goal,
            "description": response.description,
            "task_status": response.task_status,
            "priority": response.priority,
            "company_id": response.company_id,
            "project_id": response.project_id,
            "engagement_id": response.engagement_id,
            "assigned_agent_id": response.assigned_agent_id,
            "created_by_agent_id": response.created_by_agent_id,
            "blockers": response.blockers,
            "artifacts": [
                {
                    "id": a.id,
                    "artifact_type": a.artifact_type,
                    "artifact_id": a.artifact_id,
                    "linked_at": a.linked_at,
                }
                for a in response.artifacts
            ],
            "created_at": response.created_at,
            "updated_at": response.updated_at,
            "completed_at": response.completed_at,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Get task error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "GET_TASK_FAILED",
        }


@mcp.tool()
async def listTasks(
    project_id: Optional[str] = None,
    engagement_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> Dict[str, Any]:
    """
    List tasks with optional filters.

    When to use:
    - Viewing all tasks for a project or engagement
    - Checking assigned tasks for an agent
    - Filtering by status (pending, assigned, in_progress, blocked, completed)
    - Getting task overview

    Args:
        project_id: Optional project UUID filter
        engagement_id: Optional engagement UUID filter
        agent_id: Optional agent UUID filter (assigned or created by)
        status: Optional status filter (pending, assigned, in_progress, blocked, completed)
        limit: Max results (default: 50)
        offset: Starting position for pagination (default: 0)

    Returns:
        dict: {total_count, tasks[{id, title, ultimate_goal, status, priority, assigned_agent_id, created_at}]}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = task_pb2.ListTasksRequest(
            user_token=manager.token or "",
            project_id=project_id or "",
            engagement_id=engagement_id or "",
            agent_id=agent_id or "",
            status=status or "",
            limit=limit,
            offset=offset,
        )

        response = await manager.call_with_auth_by_name("task_stub", "ListTasks", request)

        return {
            "status": response.status,
            "total_count": response.total_count,
            "tasks": [
                {
                    "id": t.id,
                    "title": t.title,
                    "ultimate_goal": t.ultimate_goal,
                    "status": t.status,
                    "priority": t.priority,
                    "company_id": t.company_id,
                    "project_id": t.project_id,
                    "engagement_id": t.engagement_id,
                    "assigned_agent_id": t.assigned_agent_id,
                    "created_by_agent_id": t.created_by_agent_id,
                    "blockers": t.blockers,
                    "created_at": t.created_at,
                    "updated_at": t.updated_at,
                    "completed_at": t.completed_at,
                }
                for t in response.tasks
            ],
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"List tasks error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "LIST_TASKS_FAILED",
        }


@mcp.tool()
async def updateTask(
    task_id: str,
    status: Optional[str] = None,
    assigned_agent_id: Optional[str] = None,
    blockers: Optional[str] = None,
    priority: Optional[str] = None,
    ultimate_goal: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Update task details (status, assignment, blockers, priority, ultimate_goal).

    When to use:
    - Changing task status (pending → in_progress → completed)
    - Reassigning task to different agent
    - Recording blockers preventing progress
    - Adjusting task priority
    - Re-aligning the ultimate goal

    Args:
        task_id: Task UUID from createTask
        status: Optional new status (pending, assigned, in_progress, blocked, completed)
        assigned_agent_id: Optional new assigned agent UUID
        blockers: Optional blocker description
        priority: Optional new priority (low, medium, high, critical)
        ultimate_goal: Optional updated ultimate goal (only if re-aligning)

    Returns:
        dict: {task_id, ultimate_goal, task_status, priority, updated_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = task_pb2.UpdateTaskRequest(
            user_token=manager.token or "",
            task_id=task_id,
            status=status or "",
            assigned_agent_id=assigned_agent_id or "",
            blockers=blockers or "",
            priority=priority or "",
            ultimate_goal=ultimate_goal or "",
        )

        response = await manager.call_with_auth_by_name("task_stub", "UpdateTask", request)

        return {
            "status": response.status,
            "message": response.message,
            "task_id": response.task_id,
            "ultimate_goal": response.ultimate_goal,
            "task_status": response.task_status,
            "priority": response.priority,
            "updated_at": response.updated_at,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Update task error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "UPDATE_TASK_FAILED",
        }


@mcp.tool()
async def assignTask(
    task_id: str,
    agent_id: str,
) -> Dict[str, Any]:
    """
    Assign task to an agent.

    When to use:
    - Delegating work to a specific agent
    - Task assignment during orchestration
    - Reassigning tasks to different agents

    This is a convenience method that updates both the assigned_agent_id
    and sets status to 'assigned'.

    Args:
        task_id: Task UUID from createTask
        agent_id: Agent UUID to assign task to

    Returns:
        dict: {task_id, assigned_agent_id, task_status, updated_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = task_pb2.AssignTaskRequest(
            user_token=manager.token or "",
            task_id=task_id,
            agent_id=agent_id,
        )

        response = await manager.call_with_auth_by_name("task_stub", "AssignTask", request)

        return {
            "status": response.status,
            "message": response.message,
            "task_id": response.task_id,
            "assigned_agent_id": response.assigned_agent_id,
            "task_status": response.task_status,
            "updated_at": response.updated_at,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Assign task error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "ASSIGN_TASK_FAILED",
        }


@mcp.tool()
async def completeTask(
    task_id: str,
) -> Dict[str, Any]:
    """
    Mark task as completed.

    When to use:
    - Task work is finished
    - Closing out completed tasks
    - Recording task completion timestamp

    This sets status to 'completed' and records completed_at timestamp.

    Args:
        task_id: Task UUID from createTask

    Returns:
        dict: {task_id, task_status, completed_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = task_pb2.CompleteTaskRequest(
            user_token=manager.token or "",
            task_id=task_id,
        )

        response = await manager.call_with_auth_by_name("task_stub", "CompleteTask", request)

        return {
            "status": response.status,
            "message": response.message,
            "task_id": response.task_id,
            "task_status": response.task_status,
            "completed_at": response.completed_at,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Complete task error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "COMPLETE_TASK_FAILED",
        }


@mcp.tool()
async def linkArtifact(
    task_id: str,
    artifact_type: str,
    artifact_id: str,
) -> Dict[str, Any]:
    """
    Link an artifact to a task for traceability.

    When to use:
    - Connecting code to implementation tasks
    - Linking knowledge/expertise created during task
    - Associating lessons learned with tasks
    - Building traceability between tasks and artifacts

    Artifact types:
    - code: Source code indexed via createCode
    - knowledge: Documents stored via createKnowledge
    - expertise: Guides created via createExpertise
    - lesson: Lessons recorded via recordLesson

    Args:
        task_id: Task UUID from createTask
        artifact_type: Type of artifact (code, knowledge, expertise, lesson)
        artifact_id: Artifact UUID (code_id, knowledge_id, expertise_id, lesson_id)

    Returns:
        dict: {link_id, task_id, artifact_type, artifact_id, linked_at}
    """
    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        request = task_pb2.LinkArtifactRequest(
            user_token=manager.token or "",
            task_id=task_id,
            artifact_type=artifact_type,
            artifact_id=artifact_id,
        )

        response = await manager.call_with_auth_by_name("task_stub", "LinkArtifact", request)

        return {
            "status": response.status,
            "message": response.message,
            "link_id": response.link_id,
            "task_id": response.task_id,
            "artifact_type": response.artifact_type,
            "artifact_id": response.artifact_id,
            "linked_at": response.linked_at,
            "error_message": response.error_message,
            "error_code": response.error_code,
        }
    except Exception as e:
        logger.error(f"Link artifact error: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "error_code": "LINK_ARTIFACT_FAILED",
        }


# ============================================================================
# Server Startup
# ============================================================================


async def _auto_start_proxy():
    """Auto-start proxy if LEGION_PROXY_ENABLED=true.

    Called during startup after gRPC client is connected.
    If a healthy proxy is already running on the port, reuses it.
    Otherwise spawns a new one via LocalProxyManager.
    Never blocks MCP startup — logs and continues on any failure.
    """
    if os.environ.get("LEGION_PROXY_ENABLED", "false").lower() != "true":
        return

    import socket
    from legion_mcp.proxy_manager import get_proxy_manager

    port = int(os.environ.get("LEGION_PROXY_PORT", str(DEFAULT_PROXY_PORT)))
    host = os.environ.get("LEGION_PROXY_HOST", "localhost")

    # Check if a proxy is already running on the port
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)
            s.connect((host, port))
        logger.info(f"Proxy already running on {host}:{port} — reusing existing instance")
        return
    except (ConnectionRefusedError, socket.timeout, OSError):
        pass  # Port not in use — proceed to start

    logger.info(f"Proxy auto-start enabled — starting on port {port}...")

    try:
        # Authenticate gRPC client before proxy start.
        # At lifespan time no tool calls have happened yet, so there's no
        # token cached.  manager.start() needs a valid token to create the
        # DB record via gRPC.  Env vars (MCP_USER_EMAIL / PASSWORD) are
        # always available, so this just primes the singleton.
        client = get_grpc_client_manager()
        await client.authenticate()

        manager = get_proxy_manager()
        result = await manager.start(port=port, log_level="warn")

        if result.get("status") == "success":
            logger.info(
                f"Proxy auto-started: id={result.get('proxy_id')} "
                f"pid={result.get('pid')} port={result.get('port')} — "
                f"{result.get('message')}"
            )
        else:
            err_msg = result.get("error_message", result.get("error", "unknown"))
            err_code = result.get("error_code", "unknown")
            logger.error(f"[PROXY START FAILED] {err_msg} (code={err_code})")
            # Write to stderr so user sees the error in their terminal
            import sys

            print(f"\n⚠️  PROXY START FAILED: {err_msg}\n", file=sys.stderr, flush=True)
    except Exception as e:
        logger.warning(f"Proxy auto-start failed (non-fatal): {e}")


async def _auto_bootstrap_agent_context():
    """Auto-set agent context from env vars so tools work without whoAmI().

    When OpenCode bootstraps LEGION identity via gRPC at startup, it sets
    LEGION_AGENT_ID (and LEGION_COMPANY_ID) in process.env before spawning
    the MCP server subprocess.  This function detects those env vars and
    performs a server-side WhoAmI gRPC call to establish the AgentContextProxy
    — exactly what the whoAmI tool handler does, but triggered automatically.

    This eliminates the need for the LLM to call whoAmI() as its first tool
    call, enabling zero-MCP-call identity bootstrap.
    """
    agent_id = os.environ.get("LEGION_AGENT_ID")
    if not agent_id:
        return  # No agent_id in env — skip auto-bootstrap

    company_id = os.environ.get("LEGION_COMPANY_ID")
    project_id = os.environ.get("LEGION_PROJECT_ID")
    project_location = os.environ.get("LEGION_PROJECT_PATH")

    logger.info(
        f"Auto-bootstrap agent context: agent_id={agent_id}, "
        f"company_id={company_id}, project_id={project_id}"
    )

    try:
        manager = get_grpc_client_manager()
        await manager.ensure_connected()

        if not manager.token:
            await manager.authenticate()

        # Call WhoAmI RPC — same as the whoAmI tool handler
        request = agent_skill_pb2.WhoAmIRequest(
            user_token=manager.token or "",
            company_id=company_id or "",
            agent_id=agent_id,
        )

        response = await manager.call_with_auth_by_name("agent_skill_stub", "WhoAmI", request)

        if response.status == "success":
            system_prompt = response.system_prompt or ""
            reminder = (
                system_prompt.split("\n")[0][:200]
                if system_prompt
                else f"{response.role}: {response.main_responsibilities[:100]}"
            )

            set_agent_context(
                agent_id=response.agent_id,
                name=response.name,
                role=response.role,
                reminder=reminder,
                company_id=company_id,
                project_id=project_id,
                project_location=project_location,
            )
            logger.info(
                f"Auto-bootstrap SUCCESS: {response.name} ({response.role}), "
                f"company={company_id}, project={project_id}"
            )
        else:
            logger.warning(f"Auto-bootstrap WhoAmI returned non-success: {response.status}")

    except Exception as e:
        logger.warning(f"Auto-bootstrap agent context failed (non-fatal): {e}")


async def _startup_cleanup():
    """Run startup tasks including delegation cleanup and proxy auto-start."""
    try:
        result = await cleanup_orphaned_delegations()
        if result.get("status") == "success":
            marked = result.get("delegations_marked", 0)
            if marked > 0:
                logger.info(f"Startup cleanup: marked {marked} orphaned delegations as interrupted")
        else:
            logger.warning(
                f"Startup cleanup warning: {result.get('error_message', 'unknown error')}"
            )
    except Exception as e:
        # Don't fail startup if cleanup fails
        logger.warning(f"Startup cleanup failed (non-fatal): {e}")

    # Auto-start proxy after cleanup (separate try/except — never blocks startup)
    await _auto_start_proxy()

    # Auto-bootstrap agent context from env vars (LEGION_AGENT_ID).
    # Must run AFTER proxy start so gRPC client is warmed up.
    await _auto_bootstrap_agent_context()


def main():
    """Run the MCP server.

    Startup tasks (delegation cleanup, proxy auto-start) run via the
    FastMCP lifespan hook on the SAME event loop as the server.  This
    keeps async tasks like the proxy heartbeat alive for the full
    server lifetime — no more separate asyncio.run() + event-loop
    destruction that killed the heartbeat.
    """
    from legion_mcp.tools.delegation import OWNER_ID

    logger.info("Starting LEGION MCP-to-gRPC Bridge Server...")
    logger.info(f"Server owner_id: {OWNER_ID}")
    logger.info(
        "Available tools: 44 (Auth: 2, Knowledge: 5, Code: 4, Expertise: 5, Lessons: 2, Agent Skills: 6, Engagement: 8, Task: 8, Delegation: 5)"
    )

    mcp.run()


if __name__ == "__main__":
    main()
