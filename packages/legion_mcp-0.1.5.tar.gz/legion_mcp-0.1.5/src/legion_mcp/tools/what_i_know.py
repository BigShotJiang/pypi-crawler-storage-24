"""
whatIKnow — Unified search MCP tool with agentic inner AI.

Consolidates all LEGION search capabilities into a single tool.
An inner AI (Haiku) manages the search strategy:
  Phase 1: Broad sweep across all types
  Phase 2: Refine based on initial results
  Phase 3: Consolidate into a coherent answer

Uses raw urllib for Haiku API calls — zero external SDK dependency.
Auth: ANTHROPIC_API_KEY from environment.
"""

import json
import logging
import os
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional

from legion_mcp.grpc_client import get_grpc_client_manager
from legion_mcp.agent_context import require_agent_context
from legion_mcp.protos import unified_search_pb2

logger = logging.getLogger(__name__)

# Inner AI configuration
DEFAULT_MODEL = "claude-haiku-4-5-20251001"
API_URL = "https://api.anthropic.com/v1/messages"

# System prompt for the inner search strategist AI
SEARCH_STRATEGIST_PROMPT = """\
You are a search strategist inside LEGION, an AI knowledge management system.

Your job is to help find information across LEGION's data stores:
- knowledge: Documentation, notes, unstructured text
- expertise: Structured guides, tutorials, best practices
- lessons: Resolved issues (symptom, root cause, solution)
- entries: Engagement entries (decisions, plans, insights, notes)
- memories: Working and permanent memories from agents

You receive search results and must decide:
1. Are these results sufficient to answer the original query?
2. If not, what refined query would help find missing information?

When you have enough information, synthesize a coherent answer that matches
the requestor's intent:
- "how does X work?" → explain it
- "what did we decide about Y?" → surface the decision with context
- "has anyone solved Z before?" → surface lessons and solutions
- "what do we know about W?" → comprehensive summary

Be concise but thorough. Cite sources by type and title."""


def _get_api_key() -> Optional[str]:
    """Get Anthropic API key from environment."""
    return os.environ.get("ANTHROPIC_API_KEY")


def _get_model() -> str:
    """Get inner AI model from environment or default."""
    return os.environ.get("LEGION_INNER_AI_MODEL", DEFAULT_MODEL)


def _call_haiku(
    system_prompt: str,
    user_message: str,
    api_key: str,
    model: str,
    max_tokens: int = 2048
) -> Optional[str]:
    """Call Haiku via raw urllib to api.anthropic.com.

    Returns response text or None on failure.
    Pattern from: legion_mcp/proxy/cognitive_extractor.py
    """
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "anthropic-version": "2023-06-01",
        "x-api-key": api_key,
    }

    payload = json.dumps({
        "model": model,
        "max_tokens": max_tokens,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_message}],
    }).encode("utf-8")

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers=headers,
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            raw_bytes = resp.read()

            # Handle gzip
            content_encoding = resp.headers.get("Content-Encoding", "")
            if content_encoding == "gzip":
                import gzip
                raw_bytes = gzip.decompress(raw_bytes)

            body = json.loads(raw_bytes.decode("utf-8"))

        # Extract text from response
        content = body.get("content", [])
        if not content:
            return None

        texts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(block.get("text", ""))

        return "\n".join(texts) if texts else None

    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")[:500]
        logger.warning("Haiku API error %d: %s", e.code, error_body)
        return None
    except urllib.error.URLError as e:
        logger.warning("Haiku connection error: %s", e.reason)
        return None
    except Exception as e:
        logger.warning("Haiku call failed: %s", e)
        return None


def _call_haiku_structured(
    system_prompt: str,
    user_message: str,
    api_key: str,
    model: str,
) -> Optional[Dict[str, Any]]:
    """Call Haiku with structured JSON output via tool_use.

    Returns parsed dict with {action, refined_query, answer} or None.
    """
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "anthropic-version": "2023-06-01",
        "x-api-key": api_key,
    }

    payload = json.dumps({
        "model": model,
        "max_tokens": 1024,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_message}],
        "tools": [{
            "name": "search_decision",
            "description": "Decide whether to refine the search or consolidate results into an answer",
            "input_schema": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["refine", "consolidate"],
                        "description": "refine = search more, consolidate = enough results to answer"
                    },
                    "refined_query": {
                        "type": "string",
                        "description": "If action=refine, the new query to search. Empty if consolidate."
                    },
                    "types": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "If action=refine, which types to search: knowledge, expertise, lessons, entries, memories"
                    },
                    "reasoning": {
                        "type": "string",
                        "description": "Brief explanation of why you chose this action"
                    },
                },
                "required": ["action", "reasoning"],
            },
        }],
        "tool_choice": {"type": "tool", "name": "search_decision"},
    }).encode("utf-8")

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers=headers,
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw_bytes = resp.read()

            content_encoding = resp.headers.get("Content-Encoding", "")
            if content_encoding == "gzip":
                import gzip
                raw_bytes = gzip.decompress(raw_bytes)

            body = json.loads(raw_bytes.decode("utf-8"))

        content = body.get("content", [])
        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                return block.get("input", {})

        return None

    except Exception as e:
        logger.warning("Haiku structured call failed: %s", e)
        return None


def _format_results_for_ai(results: List[Dict[str, Any]]) -> str:
    """Format search results into a readable string for the inner AI."""
    if not results:
        return "(no results found)"

    parts = []
    for i, r in enumerate(results, 1):
        parts.append(
            f"{i}. [{r.get('type', '?')}] {r.get('title', 'Untitled')}\n"
            f"   Score: {r.get('score', 0):.2f}\n"
            f"   {r.get('snippet', '')[:300]}"
        )

    return "\n\n".join(parts)


async def _do_unified_search(
    query: str,
    project_id: Optional[str],
    types: Optional[List[str]] = None,
    limit: int = 10
) -> List[Dict[str, Any]]:
    """Call the UnifiedSearch gRPC endpoint."""
    manager = get_grpc_client_manager()
    await manager.ensure_connected()

    request = unified_search_pb2.UnifiedSearchRequest(
        user_token=manager.token or "",
        query=query,
        project_id=project_id or "",
        limit_per_type=limit,
        types=types or [],
    )

    response = await manager.call_with_auth(
        manager.unified_search_stub.UnifiedSearch, request
    )

    if response.status != "success":
        logger.warning("UnifiedSearch returned error: %s", response.error_message)
        return []

    results = []
    for r in response.results:
        results.append({
            "type": r.type,
            "id": r.id,
            "title": r.title,
            "snippet": r.snippet,
            "score": r.score,
            "project_id": r.project_id,
            "metadata_json": r.metadata_json,
        })

    return results


def register_what_i_know_tools(mcp):
    """Register the whatIKnow tool with the MCP server."""

    @mcp.tool()
    async def whatIKnow(
        query: str,
        project_id: Optional[str] = None,
        max_hops: int = 3,
    ) -> Dict[str, Any]:
        """
        Unified search across ALL LEGION knowledge with AI-powered synthesis.

        Searches knowledge, expertise, lessons, entries, and memories in parallel,
        then uses an inner AI to refine and synthesize results into a coherent answer.

        When to use:
        - "How does X work?" → searches all types, explains
        - "What did we decide about Y?" → finds decisions
        - "Has anyone solved Z before?" → finds lessons learned
        - Any question about what LEGION knows

        The inner AI manages search strategy:
        - Phase 1: Broad sweep across all types
        - Phase 2: Refine based on gaps (up to max_hops iterations)
        - Phase 3: Synthesize into answer matching your intent

        Args:
            query: Natural language question
            project_id: Optional project UUID to scope search (omit for company-wide)
            max_hops: Max search iterations (default 3, min 1)

        Returns:
            dict: {status, answer, sources[], search_iterations, model_used}
        """
        api_key = _get_api_key()
        model = _get_model()
        max_hops = max(1, min(max_hops, 10))

        all_sources: List[Dict[str, Any]] = []
        iterations = 0

        # === Phase 1: Broad Sweep ===
        logger.info("whatIKnow Phase 1: Broad sweep for query='%s'", query[:80])
        initial_results = await _do_unified_search(query, project_id, limit=10)
        all_sources.extend(initial_results)
        iterations = 1

        # If no API key, skip AI phases — return raw results
        if not api_key:
            logger.warning("No ANTHROPIC_API_KEY — returning raw search results without AI synthesis")
            return {
                "status": "success",
                "answer": _format_results_for_ai(initial_results),
                "sources": [
                    {
                        "type": s.get("type", ""),
                        "id": s.get("id", ""),
                        "title": s.get("title", ""),
                        "snippet": s.get("snippet", "")[:200],
                        "score": s.get("score", 0.0),
                        "project_id": s.get("project_id", ""),
                    }
                    for s in all_sources
                ],
                "search_iterations": iterations,
                "model_used": "none (no API key)",
            }

        # === Phase 2: Refine (up to max_hops - 1 more iterations) ===
        while iterations < max_hops:
            # Ask Haiku whether to refine or consolidate
            decision_prompt = (
                f"## Original Query\n{query}\n\n"
                f"## Search Results (iteration {iterations})\n"
                f"{_format_results_for_ai(all_sources)}\n\n"
                f"Based on these results, should I search more or do I have enough to answer?\n"
                f"If refining, suggest a better query and which types to search."
            )

            decision = _call_haiku_structured(
                SEARCH_STRATEGIST_PROMPT, decision_prompt, api_key, model
            )

            if decision is None:
                logger.warning("Haiku decision call failed, proceeding to consolidation")
                break

            action = decision.get("action", "consolidate")
            reasoning = decision.get("reasoning", "")
            logger.info(
                "whatIKnow Phase 2 (iter %d): action=%s reason=%s",
                iterations, action, reasoning[:80]
            )

            if action == "consolidate":
                break

            # Refine: search again with refined query
            refined_query = decision.get("refined_query", query)
            refined_types = decision.get("types")

            if refined_query and refined_query != query:
                new_results = await _do_unified_search(
                    refined_query, project_id,
                    types=refined_types,
                    limit=10
                )
                # Deduplicate by id
                existing_ids = {s.get("id") for s in all_sources}
                for r in new_results:
                    if r.get("id") not in existing_ids:
                        all_sources.append(r)
                        existing_ids.add(r.get("id"))

            iterations += 1

        # === Phase 3: Consolidate ===
        logger.info(
            "whatIKnow Phase 3: Consolidating %d sources after %d iterations",
            len(all_sources), iterations
        )

        consolidation_prompt = (
            f"## Original Query\n{query}\n\n"
            f"## All Search Results ({len(all_sources)} sources)\n"
            f"{_format_results_for_ai(all_sources)}\n\n"
            f"Synthesize these results into a coherent answer that directly addresses "
            f"the original query. Be specific, cite sources by [type: title], and "
            f"prioritize the most relevant information."
        )

        answer = _call_haiku(
            SEARCH_STRATEGIST_PROMPT, consolidation_prompt, api_key, model, max_tokens=2048
        )

        if answer is None:
            # Fallback: return formatted results without synthesis
            answer = (
                "AI synthesis unavailable. Raw results:\n\n"
                + _format_results_for_ai(all_sources)
            )

        # Build deduplicated source list
        seen_ids = set()
        unique_sources = []
        for s in all_sources:
            sid = s.get("id", "")
            if sid and sid not in seen_ids:
                seen_ids.add(sid)
                unique_sources.append({
                    "type": s.get("type", ""),
                    "id": sid,
                    "title": s.get("title", ""),
                    "snippet": s.get("snippet", "")[:200],
                    "score": s.get("score", 0.0),
                    "project_id": s.get("project_id", ""),
                })

        return {
            "status": "success",
            "answer": answer,
            "sources": unique_sources,
            "search_iterations": iterations,
            "model_used": model,
        }
