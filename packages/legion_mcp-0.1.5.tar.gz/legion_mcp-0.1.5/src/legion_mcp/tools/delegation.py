"""
Agent delegation tools using Claude Agent SDK or GitHub Copilot CLI.
Runtime selected via DELEGATION_RUNTIME env var (claude-code | copilot).

All delegations run asynchronously via subprocess:
- delegate_to_agent() spawns subprocess and returns immediately
- Use get_delegation_status() to poll progress
- Use get_delegation_result() to get final result
- Use cancel_delegation() to request graceful shutdown

Subprocess execution solves MCP event loop blocking issues where
asyncio.create_task() scheduled tasks that never executed.

Uses database-backed heartbeat mechanism for robust orphan detection:
- Each subprocess gets unique OWNER_ID
- Heartbeats sent every HEARTBEAT_INTERVAL_SECONDS during execution
- Cleanup only marks delegations as interrupted if heartbeat is stale
- Cancellation detected via status polling in heartbeat loop
"""
import asyncio
import json
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, Optional, List
from weakref import WeakValueDictionary

from legion_mcp.grpc_client import get_grpc_client_manager
from legion_mcp.protos import agent_skill_pb2, delegation_pb2

logger = logging.getLogger(__name__)

# Unique owner ID for this MCP server instance
# Format: {pid}-{uuid8} for debugging and uniqueness across PID reuse
OWNER_ID = f"{os.getpid()}-{uuid.uuid4().hex[:8]}"

# Heartbeat configuration (must match delegation_repository.py)
HEARTBEAT_INTERVAL_SECONDS = 5   # Send heartbeat every 5 seconds
HEARTBEAT_TIMEOUT_SECONDS = 30   # Consider orphaned after 30 seconds without heartbeat

# Exponential backoff configuration for heartbeat retries (from Ragen's validation)
HEARTBEAT_MAX_RETRIES = 3
HEARTBEAT_BASE_DELAY = 0.5  # seconds

# Concurrency limiter - max 5 concurrent delegations
_delegation_semaphore = asyncio.Semaphore(5)

# Client registry for cancellation support
# Maps delegation_id -> active Claude SDK client (weak references for auto-cleanup)
_active_clients: WeakValueDictionary[str, Any] = WeakValueDictionary()

# Background tasks registry (strong references to prevent GC during execution)
_background_tasks: Dict[str, asyncio.Task] = {}

# Heartbeat tasks registry (for cancellation on delegation completion)
_heartbeat_tasks: Dict[str, asyncio.Task] = {}



def _check_proxy_required() -> tuple[bool, str]:
    """
    Pre-flight check: if LEGION_PROXY_ENABLED=true, verify proxy is responding.

    Called BEFORE creating delegation records or spawning subprocesses.
    Returns (ok, error_message). If proxy isn't enabled, always returns (True, "").
    """
    if os.environ.get("LEGION_PROXY_ENABLED", "false").lower() != "true":
        return True, ""

    proxy_host = os.environ.get("LEGION_PROXY_HOST", "localhost")
    proxy_port = int(os.environ.get("LEGION_PROXY_PORT", "34763"))

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)
            s.connect((proxy_host, proxy_port))
        return True, ""
    except (ConnectionRefusedError, socket.timeout, OSError) as e:
        return False, (
            f"Proxy is required (LEGION_PROXY_ENABLED=true) but not responding "
            f"on {proxy_host}:{proxy_port} ({type(e).__name__}). "
            f"Start the proxy with start_proxy() before delegating."
        )


def validate_target_path(target_path: str) -> tuple[bool, str]:
    """
    Validate target_path parameter with MANDATORY security checks.

    Validates:
    - target_path is not empty
    - target_path is an absolute path
    - target_path exists on the filesystem
    - target_path is a directory (not a file)
    - target_path contains no symlinks (security: prevents path traversal attacks)

    Args:
        target_path: The path to validate

    Returns:
        tuple[bool, str]: (is_valid, error_message)
            - (True, "") if valid
            - (False, "error description") if invalid
    """
    if not target_path:
        return False, "target_path is required"

    if not os.path.isabs(target_path):
        return False, f"target_path must be absolute path: {target_path}"

    if not os.path.exists(target_path):
        return False, f"target_path does not exist: {target_path}"

    if not os.path.isdir(target_path):
        return False, f"target_path is not a directory: {target_path}"

    # MANDATORY: Prevent path traversal via symlinks
    resolved = os.path.realpath(target_path)
    if resolved != os.path.abspath(target_path):
        return False, (
            f"Symlinks not allowed in target_path. "
            f"Resolved: {resolved}, Expected: {os.path.abspath(target_path)}"
        )

    return True, ""


def _load_mcp_credentials(target_path: Optional[str] = None) -> Dict[str, str]:
    """
    Load MCP credentials from config file.

    Priority order:
    1. Project-local .mcp.json (if target_path provided)
    2. User-level ~/.claude.json
    3. Environment variables

    Returns dict with MCP_USER_EMAIL, MCP_USER_PASSWORD, GRPC_SERVER_HOST, GRPC_SERVER_PORT.
    """
    credentials = {}
    config_loaded_from = None

    # Try project-local .mcp.json first (if target_path provided)
    if target_path:
        local_config_path = Path(target_path) / ".mcp.json"
        if local_config_path.exists():
            try:
                with open(local_config_path) as f:
                    local_config = json.load(f)
                    legion_config = local_config.get("mcpServers", {}).get("legion", {})
                    env_config = legion_config.get("env", {})

                    if env_config:
                        credentials["MCP_USER_EMAIL"] = env_config.get("MCP_USER_EMAIL", "")
                        credentials["MCP_USER_PASSWORD"] = env_config.get("MCP_USER_PASSWORD", "")
                        credentials["GRPC_SERVER_HOST"] = env_config.get("GRPC_SERVER_HOST", "api.wearethelegion.com")
                        credentials["GRPC_SERVER_PORT"] = env_config.get("GRPC_SERVER_PORT", "50051")
                        config_loaded_from = str(local_config_path)
            except Exception as e:
                logger.warning(f"Failed to load credentials from local .mcp.json: {e}")

    # Fall back to user-level ~/.claude.json if no local config
    if not credentials:
        claude_config_path = Path.home() / ".claude.json"
        if claude_config_path.exists():
            try:
                with open(claude_config_path) as f:
                    claude_config = json.load(f)
                    legion_config = claude_config.get("mcpServers", {}).get("legion", {})
                    env_config = legion_config.get("env", {})

                    if env_config:
                        credentials["MCP_USER_EMAIL"] = env_config.get("MCP_USER_EMAIL", "")
                        credentials["MCP_USER_PASSWORD"] = env_config.get("MCP_USER_PASSWORD", "")
                        credentials["GRPC_SERVER_HOST"] = env_config.get("GRPC_SERVER_HOST", "api.wearethelegion.com")
                        credentials["GRPC_SERVER_PORT"] = env_config.get("GRPC_SERVER_PORT", "50051")
                        config_loaded_from = str(claude_config_path)
            except Exception as e:
                logger.warning(f"Failed to load credentials from .claude.json: {e}")

    if config_loaded_from:
        logger.info(f"Loaded MCP credentials from: {config_loaded_from}")

    # Fall back to environment variables for any missing values
    credentials.setdefault("MCP_USER_EMAIL", os.environ.get("MCP_USER_EMAIL", ""))
    credentials.setdefault("MCP_USER_PASSWORD", os.environ.get("MCP_USER_PASSWORD", ""))
    credentials.setdefault("GRPC_SERVER_HOST", os.environ.get("GRPC_SERVER_HOST", "api.wearethelegion.com"))
    credentials.setdefault("GRPC_SERVER_PORT", os.environ.get("GRPC_SERVER_PORT", "50051"))

    return credentials


async def _heartbeat_loop(delegation_id: str) -> None:
    """
    Send periodic heartbeats while delegation runs.
    Uses exponential backoff on retry (from Ragen's validation).
    Stops when delegation completes or ownership is lost.
    """
    client = get_grpc_client_manager()

    while True:
        try:
            # Try to send heartbeat with exponential backoff on transient failures
            success = False
            last_error = None

            for attempt in range(HEARTBEAT_MAX_RETRIES):
                try:
                    await client.ensure_connected()
                    request = delegation_pb2.UpdateHeartbeatRequest(
                        delegation_id=delegation_id,
                        owner_id=OWNER_ID
                    )
                    response = await client.delegation_stub.UpdateHeartbeat(request)

                    if response.success:
                        success = True
                        break
                    else:
                        # Lost ownership - stop heartbeat loop
                        logger.warning(
                            f"Lost ownership of delegation {delegation_id} - "
                            f"stopping heartbeat"
                        )
                        return

                except Exception as e:
                    last_error = e
                    if attempt < HEARTBEAT_MAX_RETRIES - 1:
                        # Exponential backoff: 0.5s, 1s, 2s
                        delay = HEARTBEAT_BASE_DELAY * (2 ** attempt)
                        logger.warning(
                            f"Heartbeat attempt {attempt + 1} failed for {delegation_id}, "
                            f"retrying in {delay}s: {e}"
                        )
                        await asyncio.sleep(delay)

            if not success:
                logger.error(
                    f"Heartbeat failed after {HEARTBEAT_MAX_RETRIES} attempts "
                    f"for {delegation_id}: {last_error}"
                )
                # Continue trying - next interval might work

        except asyncio.CancelledError:
            logger.debug(f"Heartbeat loop cancelled for delegation {delegation_id}")
            raise

        except Exception as e:
            logger.error(f"Unexpected heartbeat error for {delegation_id}: {e}")

        await asyncio.sleep(HEARTBEAT_INTERVAL_SECONDS)


async def _claim_delegation_ownership(delegation_id: str) -> bool:
    """
    Claim ownership of a delegation before execution.
    Sets owner_id and initial heartbeat.

    Returns:
        True if claimed successfully, False otherwise
    """
    try:
        client = get_grpc_client_manager()
        await client.ensure_connected()

        request = delegation_pb2.ClaimDelegationRequest(
            delegation_id=delegation_id,
            owner_id=OWNER_ID
        )
        response = await client.delegation_stub.ClaimDelegation(request)

        if response.claimed:
            logger.info(f"Claimed ownership of delegation {delegation_id}")
            return True
        else:
            logger.warning(
                f"Failed to claim delegation {delegation_id}: "
                f"{response.error_message or 'unknown reason'}"
            )
            return False

    except Exception as e:
        logger.error(f"Error claiming delegation {delegation_id}: {e}")
        return False


async def _get_agent_context(agent_id: str, project_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Fetch agent context from LEGION via gRPC.

    If project_id is provided, returns combined system prompt:
    company instructions + project instructions + agent system_prompt

    If no project_id, returns just the agent's own system_prompt.
    """
    client = get_grpc_client_manager()
    await client.ensure_connected()

    request = agent_skill_pb2.GetAgentContextRequest(
        agent_id=agent_id,
        project_id=project_id or ""
    )
    response = await client.call_with_auth(client.agent_skill_stub.GetAgentContext, request)

    return {
        "agent_id": response.agent_id,
        "name": response.agent_name,
        "role": response.agent_role,
        "combined_system_prompt": response.combined_system_prompt,
        "agent_system_prompt": response.agent_system_prompt,
    }


def _parse_copilot_metrics(output: str) -> Dict[str, Any]:
    """Extract metrics from Copilot CLI output."""
    metrics = {}

    if match := re.search(r"Total usage est:\s*(\d+)\s*Premium request", output):
        metrics["premium_requests"] = int(match.group(1))

    if match := re.search(r"Total duration \(API\):\s*([\d.]+)s", output):
        metrics["duration_api_seconds"] = float(match.group(1))

    if match := re.search(r"Total duration \(wall\):\s*([\d.]+)s", output):
        metrics["duration_wall_seconds"] = float(match.group(1))

    if match := re.search(r"(\d+) lines added, (\d+) lines removed", output):
        metrics["lines_added"] = int(match.group(1))
        metrics["lines_removed"] = int(match.group(2))

    return metrics


def _extract_copilot_response(output: str) -> str:
    """Extract the actual response text, removing metrics footer."""
    lines = output.split("\n")
    result_lines = []

    for line in lines:
        if line.startswith("Total usage est:"):
            break
        if line.startswith("●") or line.startswith("○"):
            line = line[1:].strip()
        if line:
            result_lines.append(line)

    return "\n".join(result_lines).strip()


async def _delegate_via_copilot(
    agent_ctx: Dict[str, Any],
    task: str,
    context: Optional[str],
    model: str,
    timeout: int = 300
) -> Dict[str, Any]:
    """Execute delegation via GitHub Copilot CLI."""
    copilot_path = shutil.which("copilot")
    if not copilot_path:
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": "GitHub Copilot CLI not found. Install via: npm install -g @github/copilot"
        }

    # Build enhanced prompt with full agent context
    # Copilot doesn't support system prompts, so we prepend to task
    enhanced_task = f"""You are {agent_ctx['name']} ({agent_ctx['role']}).

{agent_ctx['combined_system_prompt']}

"""
    if context:
        enhanced_task += f"Context:\n{context}\n\n"
    enhanced_task += f"Task:\n{task}"

    cmd = [
        copilot_path,
        "-p", enhanced_task,
        "--allow-all-tools",
        "--model", model
    ]

    try:
        # Build env without GITHUB_TOKEN - Copilot CLI should use keyring auth
        env = {k: v for k, v in os.environ.items() if k != "GITHUB_TOKEN"}

        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env
        )

        stdout, stderr = await asyncio.wait_for(
            process.communicate(),
            timeout=timeout
        )

        output = stdout.decode("utf-8")
        error_output = stderr.decode("utf-8")
        metrics = _parse_copilot_metrics(output)

        if process.returncode != 0:
            return {
                "status": "failed",
                "agent_name": agent_ctx["name"],
                "agent_role": agent_ctx["role"],
                "error": error_output or output
            }

        result = _extract_copilot_response(output)
        summary = result[:500] + "..." if len(result) > 500 else result

        return {
            "status": "completed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "summary": summary,
            "tools_used": [],  # Copilot doesn't expose tool usage
            "turns": 1,
            "cost_usd": 0.0,  # Copilot uses premium requests, not USD
            **metrics
        }

    except asyncio.TimeoutError:
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": f"Copilot CLI timed out after {timeout} seconds"
        }
    except Exception as e:
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": str(e)
        }


async def _delegate_via_claude_code(
    agent_ctx: Dict[str, Any],
    agent_id: str,
    task: str,
    context: Optional[str],
    model: str,
    delegation_id: Optional[str] = None
) -> Dict[str, Any]:
    """Execute delegation via Claude Agent SDK (Claude Code)."""
    # Lazy import to avoid loading SDK when using Copilot runtime
    from claude_agent_sdk import (
        query,
        ClaudeAgentOptions,
        AssistantMessage,
        TextBlock,
        ResultMessage,
        ToolUseBlock
    )
    import json
    from pathlib import Path

    combined_system_prompt = agent_ctx["combined_system_prompt"]

    # Build full prompt with identity instruction
    identity_instruction = f"""IMPORTANT: Before starting any work, you MUST first establish your identity by calling:
mcp__legion__whoAmI(agent_id="{agent_id}")

This will configure you as {agent_ctx['name']} ({agent_ctx['role']}).
"""
    full_prompt = identity_instruction + "\n\n" + task
    if context:
        full_prompt = identity_instruction + f"\nContext:\n{context}\n\nTask:\n{task}"

    # Find legion-mcp command
    legion_mcp_cmd = shutil.which("legion-mcp")
    if not legion_mcp_cmd:
        legion_mcp_cmd = os.path.join(os.path.dirname(sys.executable), "legion-mcp")

    # Load MCP credentials from Claude's config file
    claude_config_path = Path.home() / ".claude.json"
    mcp_credentials = {}

    if claude_config_path.exists():
        try:
            with open(claude_config_path) as f:
                claude_config = json.load(f)
                legion_config = claude_config.get("mcpServers", {}).get("legion", {})
                mcp_credentials = legion_config.get("env", {})
        except Exception:
            pass

    # Build env vars
    cli_env = {
        "GRPC_SERVER_HOST": mcp_credentials.get("GRPC_SERVER_HOST") or os.environ.get("GRPC_SERVER_HOST", "api.wearethelegion.com"),
        "GRPC_SERVER_PORT": mcp_credentials.get("GRPC_SERVER_PORT") or os.environ.get("GRPC_SERVER_PORT", "50051"),
        "MCP_USER_EMAIL": mcp_credentials.get("MCP_USER_EMAIL") or os.environ.get("MCP_USER_EMAIL", ""),
        "MCP_USER_PASSWORD": mcp_credentials.get("MCP_USER_PASSWORD") or os.environ.get("MCP_USER_PASSWORD", ""),
    }

    mcp_server_env = {
        "GRPC_SERVER_HOST": "${GRPC_SERVER_HOST:-api.wearethelegion.com}",
        "GRPC_SERVER_PORT": "${GRPC_SERVER_PORT:-50051}",
        "MCP_USER_EMAIL": "${MCP_USER_EMAIL}",
        "MCP_USER_PASSWORD": "${MCP_USER_PASSWORD}",
        # Note: LEGION_MCP_SUBPROCESS env var removed - heartbeat-based orphan detection
        # now properly distinguishes parent's running delegations from true orphans
    }

    options = ClaudeAgentOptions(
        system_prompt=combined_system_prompt,
        allowed_tools=[
            "Read", "Write", "Edit", "MultiEdit", "Glob", "Grep", "Bash", "TodoWrite",
            "mcp__legion__*"
        ],
        permission_mode="bypassPermissions",
        max_turns=50,
        model=model,
        env=cli_env,
        settings=json.dumps({"autoCompactEnabled": True}),
        mcp_servers={
            "legion": {
                "type": "stdio",
                "command": legion_mcp_cmd,
                "args": [],
                "env": mcp_server_env
            }
        }
    )

    final_text = []
    tools_used: set[str] = set()
    total_cost = 0.0
    turn_count = 0
    client = get_grpc_client_manager()

    try:
        async for message in query(prompt=full_prompt, options=options):
            if isinstance(message, AssistantMessage):
                turn_count += 1
                for block in message.content:
                    if isinstance(block, TextBlock):
                        final_text.append(block.text)
                    elif isinstance(block, ToolUseBlock):
                        tools_used.add(block.name)

                # Update progress if we have a delegation_id
                if delegation_id:
                    try:
                        progress_request = delegation_pb2.UpdateProgressRequest(
                            delegation_id=delegation_id,
                            current_action=f"Turn {turn_count}",
                            step=delegation_pb2.ProgressStep(
                                step=turn_count,
                                tool=list(tools_used)[-1] if tools_used else "",
                                input_summary=final_text[-1][:100] if final_text else "",
                            )
                        )
                        await client.call_with_auth(
                            client.delegation_stub.UpdateDelegationProgress,
                            progress_request
                        )
                    except Exception as e:
                        logger.warning(f"Failed to update progress: {e}")

            elif isinstance(message, ResultMessage):
                total_cost = message.total_cost_usd

        full_result = "\n".join(final_text)
        summary = full_result[:500] + "..." if len(full_result) > 500 else full_result

        return {
            "status": "completed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "summary": summary,
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": total_cost
        }
    except Exception as e:
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": str(e),
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": total_cost
        }


async def _execute_delegation_async(
    delegation_id: str,
    agent_id: str,
    agent_ctx: Dict[str, Any],
    task: str,
    context: Optional[str],
    model: str,
    runtime: str
) -> None:
    """Execute delegation asynchronously with semaphore limiting and heartbeat."""
    client = get_grpc_client_manager()
    await client.ensure_connected()

    heartbeat_task: Optional[asyncio.Task] = None

    try:
        async with _delegation_semaphore:
            # 1. Claim ownership before starting
            claimed = await _claim_delegation_ownership(delegation_id)
            if not claimed:
                logger.error(f"Failed to claim ownership of delegation {delegation_id}")
                error_request = delegation_pb2.UpdateStatusRequest(
                    delegation_id=delegation_id,
                    new_status="failed",
                    error_message="Failed to claim delegation ownership"
                )
                await client.call_with_auth(
                    client.delegation_stub.UpdateDelegationStatus,
                    error_request
                )
                return

            # 2. Start heartbeat task
            heartbeat_task = asyncio.create_task(_heartbeat_loop(delegation_id))
            _heartbeat_tasks[delegation_id] = heartbeat_task

            # 3. Update status to running
            status_request = delegation_pb2.UpdateStatusRequest(
                delegation_id=delegation_id,
                new_status="running"
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationStatus,
                status_request
            )

            # 4. Execute delegation
            if runtime == "copilot":
                result = await _delegate_via_copilot(agent_ctx, task, context, model)
            else:
                result = await _delegate_via_claude_code(
                    agent_ctx, agent_id, task, context, model, delegation_id
                )

            # 5. Update final status
            final_status = "completed" if result.get("status") == "completed" else "failed"
            final_request = delegation_pb2.UpdateStatusRequest(
                delegation_id=delegation_id,
                new_status=final_status,
                result_summary=result.get("summary", ""),
                tools_used=result.get("tools_used", []),
                turns=result.get("turns", 0),
                cost_usd=result.get("cost_usd", 0.0),
                error_message=result.get("error", "")
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationStatus,
                final_request
            )

    except asyncio.CancelledError:
        # Handle cancellation
        try:
            cancel_request = delegation_pb2.UpdateStatusRequest(
                delegation_id=delegation_id,
                new_status="cancelled",
                error_message="Delegation was cancelled by user"
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationStatus,
                cancel_request
            )
        except Exception as e:
            logger.error(f"Failed to update cancelled status: {e}")
        raise

    except Exception as e:
        logger.error(f"Async delegation failed: {e}")
        try:
            error_request = delegation_pb2.UpdateStatusRequest(
                delegation_id=delegation_id,
                new_status="failed",
                error_message=str(e)
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationStatus,
                error_request
            )
        except Exception as update_error:
            logger.error(f"Failed to update failed status: {update_error}")

    finally:
        # 6. Stop heartbeat task
        if heartbeat_task is not None:
            heartbeat_task.cancel()
            try:
                await heartbeat_task
            except asyncio.CancelledError:
                pass

        # Clean up task references
        if delegation_id in _heartbeat_tasks:
            del _heartbeat_tasks[delegation_id]
        if delegation_id in _background_tasks:
            del _background_tasks[delegation_id]


async def cleanup_orphaned_delegations() -> Dict[str, Any]:
    """
    Mark orphaned delegations as interrupted.
    Called on MCP server startup to clean up delegations from crashed processes.

    Uses heartbeat-based detection:
    - Only marks delegations with stale heartbeats (> HEARTBEAT_TIMEOUT_SECONDS)
    - Excludes delegations owned by current process (OWNER_ID)
    - Handles legacy delegations without heartbeat (created > 60s ago)
    """
    try:
        client = get_grpc_client_manager()
        await client.ensure_connected()

        # Pass current OWNER_ID to exclude our own delegations from cleanup
        request = delegation_pb2.MarkInterruptedRequest(
            company_id="",
            owner_id=OWNER_ID
        )
        response = await client.delegation_stub.MarkInterrupted(request)

        if response.status == "success":
            if response.delegations_marked > 0:
                logger.info(
                    f"Cleaned up {response.delegations_marked} orphaned delegations "
                    f"(heartbeat-based detection, owner={OWNER_ID})"
                )
            return {
                "status": "success",
                "delegations_marked": response.delegations_marked,
                "owner_id": OWNER_ID
            }
        else:
            return {
                "status": "error",
                "error_message": response.error_message,
                "error_code": response.error_code
            }
    except Exception as e:
        logger.warning(f"Failed to cleanup orphaned delegations: {e}")
        return {
            "status": "error",
            "error_message": str(e)
        }


def register_delegation_tools(mcp):
    """Register delegation tools with the MCP server."""

    # Hard-coded model for all agent delegations
    DELEGATION_MODEL = "claude-opus-4-6"

    @mcp.tool()
    async def delegate_to_agent(
        agent_id: str,
        task: str,
        engagement_id: str,
        target_path: str,
        task_id: str,
        project_id: Optional[str] = None,
        context: Optional[str] = None,
        blocking: bool = True  # DEPRECATED - ignored, all delegations are async
    ) -> Dict[str, Any]:
        """
        Delegate a task to a LEGION agent with their own system prompt.

        The agent executes with full tool access (Read, Write, Edit, Bash, etc.)
        and their personality/expertise from LEGION database.

        Runtime is selected via DELEGATION_RUNTIME env var:
        - "claude-code" (default): Uses Claude Agent SDK
        - "copilot": Uses GitHub Copilot CLI

        The system prompt is built hierarchically (server-side):
        1. Company instructions (ground rules, standards)
        2. Project instructions (tech stack, conventions)
        3. Agent system prompt (personality, role)

        All delegations use Opus 4.6 (claude-opus-4-6).

        NOTE: All delegations run asynchronously via subprocess.
        Use get_delegation_status() to poll for progress.
        Use get_delegation_result() to get final result.

        Args:
            agent_id: UUID of the agent (use whoAmI to see available_agents)
            task: Task description for the agent
            engagement_id: UUID of the active engagement for entry tracking
            target_path: Absolute path to directory where agent should work.
                         Agent's file operations will be relative to this path.
                         Must be an existing directory. Symlinks are NOT allowed.
            task_id: UUID of the task being delegated (required for traceability)
            project_id: Optional project UUID for context instructions
            context: Optional context from current session
            blocking: DEPRECATED - ignored. All delegations are async now.

        Returns:
            dict: {status: "pending", delegation_id, agent_name, agent_role, subprocess_pid}
            Use get_delegation_status() to check progress.
            Use get_delegation_result() to get final result after completion.
        """
        # Note: blocking parameter is deprecated and ignored
        # All delegations now run via subprocess for reliability

        # 0. MANDATORY: Validate task_id is provided
        if not task_id or not task_id.strip():
            return {
                "status": "error",
                "error_message": "task is required for every delegation",
                "error_code": "INVALID_ARGUMENT"
            }

        # 1. MANDATORY: Validate target_path with security checks
        is_valid, error_msg = validate_target_path(target_path)
        if not is_valid:
            return {
                "status": "error",
                "error_message": error_msg,
                "error_code": "INVALID_ARGUMENT"
            }

        # 2. Pre-flight: if proxy is required, verify it's running
        proxy_ok, proxy_err = _check_proxy_required()
        if not proxy_ok:
            return {
                "status": "error",
                "error_message": proxy_err,
                "error_code": "PROXY_NOT_AVAILABLE"
            }

        # 3. Determine runtime from env var
        runtime = os.environ.get("DELEGATION_RUNTIME", "claude-code").lower()

        # 3. Fetch agent context from LEGION (validates agent exists)
        agent_ctx = await _get_agent_context(agent_id, project_id)

        # 4. Create delegation record and spawn subprocess
        client = get_grpc_client_manager()
        await client.ensure_connected()

        # Create delegation record
        create_request = delegation_pb2.CreateDelegationRequest(
            user_token=client.token or "",
            company_id="",  # Will be inferred from project
            project_id=project_id or "",
            agent_id=agent_id,
            task_id=task_id,  # Required for traceability
            task_description=task[:500],  # Truncate for storage
            context=context or "",
            engagement_id=engagement_id or ""
        )

        response = await client.call_with_auth(
            client.delegation_stub.CreateDelegation,
            create_request
        )

        if response.status != "success":
            return {
                "status": "error",
                "error_message": response.error_message,
                "error_code": response.error_code
            }

        delegation_id = response.delegation_id

        # Spawn subprocess to execute delegation independently
        # This solves the problem where asyncio.create_task() schedules tasks
        # that never execute because MCP server's event loop doesn't yield
        payload = json.dumps({
            "delegation_id": delegation_id,
            "agent_id": agent_id,
            "task": task,
            "context": context,
            "runtime": runtime,
            "project_id": project_id,
            "engagement_id": engagement_id,
            "model": DELEGATION_MODEL,
            "target_path": target_path
        })

        # Find the delegation runner command
        runner_cmd = shutil.which("legion-delegation-runner")
        if runner_cmd:
            cmd = [runner_cmd]
        else:
            # Fallback to running as Python module
            cmd = [sys.executable, "-m", "legion_mcp.delegation_runner"]

        # Spawn subprocess with stdin pipe for payload
        # Build environment with MCP credentials (project-local .mcp.json or ~/.claude.json)
        subprocess_env = os.environ.copy()
        mcp_creds = _load_mcp_credentials(target_path)
        subprocess_env.update(mcp_creds)

        try:
            # Log stderr to temp dir (not project folder)
            import tempfile
            stderr_log_path = os.path.join(
                tempfile.gettempdir(), f"legion_delegation_{delegation_id}.log"
            )
            stderr_file = open(stderr_log_path, "w")
            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=stderr_file,
                env=subprocess_env,
                start_new_session=True,  # Detach from parent process group
                cwd=target_path  # Execute subprocess in target directory
            )
            # Write payload and close stdin
            process.stdin.write(payload.encode())
            process.stdin.close()
            logger.info(
                f"Spawned delegation subprocess (pid={process.pid}) "
                f"for delegation {delegation_id}"
            )
        except Exception as e:
            logger.error(f"Failed to spawn delegation subprocess: {e}")
            # Update status to failed
            error_request = delegation_pb2.UpdateStatusRequest(
                delegation_id=delegation_id,
                new_status="failed",
                error_message=f"Failed to spawn subprocess: {e}"
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationStatus,
                error_request
            )
            return {
                "status": "error",
                "error_message": f"Failed to spawn delegation subprocess: {e}",
                "delegation_id": delegation_id
            }

        return {
            "status": "pending",
            "delegation_id": delegation_id,
            "agent_name": response.agent_name,
            "agent_role": response.agent_role,
            "subprocess_pid": process.pid,
            "message": "Delegation started via subprocess. Use get_delegation_status() to monitor progress."
        }

    @mcp.tool()
    async def get_delegation_status(delegation_id: str) -> Dict[str, Any]:
        """
        Get current status and progress of a delegation.

        When to use:
        - Polling for progress after delegate_to_agent(blocking=False)
        - Checking if a delegation is still running
        - Getting current action being performed

        Args:
            delegation_id: UUID from delegate_to_agent response

        Returns:
            dict: {delegation_status, agent_name, agent_role, current_action,
                   steps_completed, progress[], started_at, updated_at}
        """
        try:
            client = get_grpc_client_manager()
            await client.ensure_connected()

            request = delegation_pb2.GetDelegationStatusRequest(
                user_token=client.token or "",
                delegation_id=delegation_id
            )

            # Use brief endpoint for minimal response (optimized for MCP polling)
            response = await client.call_with_auth(
                client.delegation_stub.GetDelegationStatusBrief,
                request
            )

            if response.status != "success":
                return {
                    "status": "error",
                    "error_message": response.error_message,
                    "error_code": response.error_code
                }

            return {
                "status": "success",
                "delegation_status": response.delegation_status,
                "step_number": response.step_number,
                "step_description": response.step_description
            }

        except Exception as e:
            logger.error(f"Get delegation status error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "GET_STATUS_FAILED"
            }

    @mcp.tool()
    async def get_delegation_result(delegation_id: str) -> Dict[str, Any]:
        """
        Get full result of a completed delegation.

        When to use:
        - After delegation_status shows "completed" or "failed"
        - Getting the full summary, tools used, and cost information

        Args:
            delegation_id: UUID from delegate_to_agent response

        Returns:
            dict: {delegation_status, agent_name, agent_role, result_summary,
                   tools_used[], turns, cost_usd, error_detail, started_at, completed_at}
        """
        try:
            client = get_grpc_client_manager()
            await client.ensure_connected()

            request = delegation_pb2.GetDelegationResultRequest(
                user_token=client.token or "",
                delegation_id=delegation_id
            )

            response = await client.call_with_auth(
                client.delegation_stub.GetDelegationResult,
                request
            )

            if response.status != "success":
                return {
                    "status": "error",
                    "error_message": response.error_message,
                    "error_code": response.error_code
                }

            return {
                "status": "success",
                "delegation_id": response.delegation_id,
                "delegation_status": response.delegation_status,
                "agent_name": response.agent_name,
                "agent_role": response.agent_role,
                "result_summary": response.result_summary,
                "tools_used": list(response.tools_used),
                "turns": response.turns,
                "cost_usd": response.cost_usd,
                "error_detail": response.error_detail,
                "started_at": response.started_at,
                "completed_at": response.completed_at
            }

        except Exception as e:
            logger.error(f"Get delegation result error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "GET_RESULT_FAILED"
            }

    @mcp.tool()
    async def list_delegations(
        project_id: Optional[str] = None,
        status_filter: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        List recent delegations with optional filters.

        When to use:
        - Viewing all delegations for a project
        - Finding delegations by status (pending, running, completed, failed)
        - Getting overview of delegation history

        Args:
            project_id: Optional project UUID to filter by
            status_filter: Optional status filter (pending, running, completed, failed, cancelled)
            limit: Max results (default: 20)
            offset: Starting position for pagination (default: 0)

        Returns:
            dict: {total_count, delegations[{id, agent_name, agent_role, status,
                   task_summary, steps_completed, created_at, updated_at}]}
        """
        try:
            client = get_grpc_client_manager()
            await client.ensure_connected()

            request = delegation_pb2.ListDelegationsRequest(
                user_token=client.token or "",
                project_id=project_id or "",
                agent_id="",  # Not filtering by agent
                status_filter=status_filter or "",
                limit=limit,
                offset=offset
            )

            response = await client.call_with_auth(
                client.delegation_stub.ListDelegations,
                request
            )

            if response.status != "success":
                return {
                    "status": "error",
                    "error_message": response.error_message,
                    "error_code": response.error_code
                }

            return {
                "status": "success",
                "total_count": response.total_count,
                "delegations": [
                    {
                        "id": d.id,
                        "agent_name": d.agent_name,
                        "agent_role": d.agent_role,
                        "status": d.status,
                        "task_summary": d.task_summary,
                        "steps_completed": d.steps_completed,
                        "created_at": d.created_at,
                        "updated_at": d.updated_at
                    }
                    for d in response.delegations
                ]
            }

        except Exception as e:
            logger.error(f"List delegations error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "LIST_DELEGATIONS_FAILED"
            }

    @mcp.tool()
    async def cancel_delegation(delegation_id: str) -> Dict[str, Any]:
        """
        Cancel a running delegation.

        When to use:
        - Stopping a long-running delegation
        - Aborting a delegation that's taking too long
        - Emergency stop of agent execution

        Cancellation works via graceful shutdown:
        1. Status is updated to 'cancelled' in database
        2. Subprocess detects status change via heartbeat polling
        3. Subprocess cancels main work and exits gracefully

        This is reliable because subprocess checks status every 5 seconds.
        Actual termination may take up to 5-10 seconds.

        Args:
            delegation_id: UUID from delegate_to_agent response

        Returns:
            dict: {status, delegation_status, message}
        """
        try:
            client = get_grpc_client_manager()
            await client.ensure_connected()

            # Update status to cancelled - subprocess will detect via heartbeat
            request = delegation_pb2.UpdateStatusRequest(
                delegation_id=delegation_id,
                new_status="cancelled",
                error_message="Cancelled by user request"
            )

            response = await client.call_with_auth(
                client.delegation_stub.UpdateDelegationStatus,
                request
            )

            if response.status != "success":
                return {
                    "status": "error",
                    "error_message": response.error_message,
                    "error_code": response.error_code
                }

            return {
                "status": "success",
                "delegation_status": response.delegation_status,
                "message": "Delegation cancellation requested. Subprocess will exit within ~5-10 seconds.",
                "updated_at": response.updated_at
            }

        except Exception as e:
            logger.error(f"Cancel delegation error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "CANCEL_FAILED"
            }