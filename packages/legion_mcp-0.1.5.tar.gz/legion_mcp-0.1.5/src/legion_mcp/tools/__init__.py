"""
LEGION MCP Tools - Modular tool implementations.
"""

from legion_mcp.tools.delegation import register_delegation_tools
from legion_mcp.tools.ingestion import register_ingestion_tools
from legion_mcp.tools.proxy import register_proxy_tools

__all__ = ["register_delegation_tools", "register_ingestion_tools", "register_proxy_tools"]
