"""
Proxy management tools for MCP.
Control Claude API proxy lifecycle via LocalProxyManager.

The proxy runs in mitmproxy reverse mode on the LOCAL machine,
routing Claude API traffic through a local proxy for logging and monitoring.
State is synced to the remote gRPC server (DB records, heartbeat).
"""

import logging
from typing import Any, Dict

from legion_mcp.proxy_manager import get_proxy_manager

logger = logging.getLogger(__name__)

# Default proxy configuration
DEFAULT_PROXY_PORT = 34763
DEFAULT_LOG_LEVEL = "warn"


def register_proxy_tools(mcp):
    """Register proxy management tools with the MCP server."""

    @mcp.tool()
    async def start_proxy(
        port: int = DEFAULT_PROXY_PORT,
        log_level: str = DEFAULT_LOG_LEVEL
    ) -> Dict[str, Any]:
        """
        Start a Claude API proxy instance.

        The proxy runs in mitmproxy reverse mode, routing Claude API traffic
        through localhost for logging and monitoring. Delegated agents will
        automatically use this proxy when LEGION_PROXY_ENABLED=true.

        When to use:
        - Before running delegations that need API traffic logging
        - Setting up monitoring for Claude API usage
        - Debugging API interactions

        Args:
            port: Port to run proxy on (default: 34763)
            log_level: Log level for proxy (debug, info, warn, error)

        Returns:
            dict: {status, proxy_id, pid, port, message}
        """
        try:
            manager = get_proxy_manager()
            return await manager.start(port=port, log_level=log_level)

        except Exception as e:
            logger.error(f"start_proxy error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "START_PROXY_FAILED"
            }

    @mcp.tool()
    async def stop_proxy(proxy_id: str = "") -> Dict[str, Any]:
        """
        Stop a running proxy instance.

        When to use:
        - Shutting down proxy after work session
        - Cleaning up before system shutdown
        - Stopping a specific proxy by ID

        Args:
            proxy_id: UUID of proxy to stop. If empty, stops the running
                      proxy for the current company (most recent).

        Returns:
            dict: {status, message}
        """
        try:
            manager = get_proxy_manager()
            return await manager.stop(proxy_id=proxy_id)

        except Exception as e:
            logger.error(f"stop_proxy error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "STOP_PROXY_FAILED"
            }

    @mcp.tool()
    async def proxy_status(proxy_id: str = "") -> Dict[str, Any]:
        """
        Get status of a proxy instance.

        When to use:
        - Checking if proxy is running
        - Verifying proxy health before delegation
        - Monitoring proxy uptime

        Args:
            proxy_id: UUID of proxy to check. If empty, returns status
                      of the running proxy for the current company.

        Returns:
            dict: {
                status: "success" or "error",
                proxy_id: str,
                proxy_status: str - running, stopped, failed,
                name: str,
                host: str,
                port: int,
                pid: int,
                port_healthy: bool,
                started_at: str,
                uptime_seconds: str,
                last_heartbeat: str
            }
        """
        try:
            manager = get_proxy_manager()
            return await manager.status()

        except Exception as e:
            logger.error(f"proxy_status error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "GET_PROXY_STATUS_FAILED"
            }
