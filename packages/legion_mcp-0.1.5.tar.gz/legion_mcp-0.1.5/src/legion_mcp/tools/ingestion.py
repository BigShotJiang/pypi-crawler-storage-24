"""
Ingestion status tools for MCP.
Query code ingestion progress via gRPC IngestionService.
"""

import logging
from typing import Any, Dict, Optional

from legion_mcp.grpc_client import get_grpc_client_manager

logger = logging.getLogger(__name__)


def register_ingestion_tools(mcp):
    """Register ingestion status tools with the MCP server."""

    # Import proto after registration to avoid import order issues
    from legion_mcp.protos import ingestion_pb2

    @mcp.tool()
    async def getIngestionStatus(ingestion_id: str) -> Dict[str, Any]:
        """
        Get status and progress of a code ingestion operation.

        When to use:
        - Checking progress of a repository ingestion
        - Monitoring file processing status
        - Viewing failed files and errors

        Args:
            ingestion_id: UUID of the ingestion operation

        Returns:
            dict: {
                status: "success" or "error",
                ingestion_id: str,
                ingestion_status: str - pending, running, completed, failed,
                repository: str,
                branch: str,
                total_files: int,
                files_processed: int,
                files_failed: int,
                files_skipped: int,
                current_file: str - file currently being processed,
                failed_files: [{file_path, error, timestamp}],
                started_at: str,
                completed_at: str,
                percentage: float - completion percentage
            }
        """
        try:
            client = get_grpc_client_manager()
            await client.ensure_connected()

            request = ingestion_pb2.GetIngestionStatusRequest(
                user_token=client.token or "",
                ingestion_id=ingestion_id
            )

            response = await client.call_with_auth(
                client.ingestion_stub.GetIngestionStatus,
                request
            )

            if response.status != "success":
                return {
                    "status": "error",
                    "error_message": response.error_message,
                    "error_code": response.error_code
                }

            return {
                "status": "success",
                "ingestion_id": response.ingestion_id,
                "ingestion_status": response.ingestion_status,
                "repository": response.repository,
                "branch": response.branch,
                "total_files": response.total_files,
                "files_processed": response.files_processed,
                "files_failed": response.files_failed,
                "files_skipped": response.files_skipped,
                "current_file": response.current_file,
                "failed_files": [
                    {
                        "file_path": ff.file_path,
                        "error": ff.error,
                        "timestamp": ff.timestamp
                    }
                    for ff in response.failed_files
                ],
                "started_at": response.started_at,
                "completed_at": response.completed_at,
                "percentage": response.percentage
            }

        except Exception as e:
            logger.error(f"getIngestionStatus error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "GET_INGESTION_STATUS_FAILED"
            }

    @mcp.tool()
    async def listIngestions(
        project_id: str,
        status: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        List ingestion operations for a project.

        When to use:
        - Viewing all ingestions for a project
        - Finding recent ingestion operations
        - Filtering by status (pending, running, completed, failed)

        Args:
            project_id: Project UUID to list ingestions for
            status: Optional filter by status (pending, running, completed, failed)
            limit: Maximum results to return (default: 20)
            offset: Starting position for pagination (default: 0)

        Returns:
            dict: {
                status: "success" or "error",
                total_count: int,
                ingestions: [{
                    ingestion_id: str,
                    repository: str,
                    branch: str,
                    ingestion_status: str,
                    total_files: int,
                    files_processed: int,
                    started_at: str,
                    percentage: float
                }]
            }
        """
        try:
            client = get_grpc_client_manager()
            await client.ensure_connected()

            request = ingestion_pb2.ListIngestionsRequest(
                user_token=client.token or "",
                project_id=project_id,
                status_filter=status or "",
                limit=limit,
                offset=offset
            )

            response = await client.call_with_auth(
                client.ingestion_stub.ListIngestions,
                request
            )

            if response.status != "success":
                return {
                    "status": "error",
                    "error_message": response.error_message,
                    "error_code": response.error_code
                }

            return {
                "status": "success",
                "total_count": response.total_count,
                "ingestions": [
                    {
                        "ingestion_id": ing.ingestion_id,
                        "repository": ing.repository,
                        "branch": ing.branch,
                        "ingestion_status": ing.ingestion_status,
                        "total_files": ing.total_files,
                        "files_processed": ing.files_processed,
                        "started_at": ing.started_at,
                        "percentage": ing.percentage
                    }
                    for ing in response.ingestions
                ]
            }

        except Exception as e:
            logger.error(f"listIngestions error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "error_code": "LIST_INGESTIONS_FAILED"
            }
