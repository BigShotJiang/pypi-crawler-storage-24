"""
Delegation subprocess runner.
Executes delegations independently of the MCP server's event loop.

This module solves the problem where asyncio.create_task() schedules background
tasks that never execute because the MCP server's event loop doesn't yield.
By running as a separate OS process, we get our own event loop that runs to completion.

Usage (via stdin JSON payload):
    echo '{"delegation_id": "...", "agent_id": "...", ...}' | legion-delegation-runner

Or via Python module:
    echo '...' | python -m legion_mcp.delegation_runner
"""

# MUST be set before any grpc imports. Claude Agent SDK forks a subprocess
# for Claude Code CLI — gRPC's internal threads corrupt parent state on fork.
# GRPC_ENABLE_FORK_SUPPORT: registers pthread_atfork handlers
# GRPC_POLL_STRATEGY: 'poll' avoids background threads that block fork handlers
import os
os.environ.setdefault("GRPC_ENABLE_FORK_SUPPORT", "1")
os.environ.setdefault("GRPC_POLL_STRATEGY", "poll")

import asyncio
import json
import logging
import os
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

from legion_mcp.hooks import get_delegation_hooks

logger = logging.getLogger(__name__)

# Generate unique owner ID for this subprocess
# Format: {pid}-{uuid8} for debugging and uniqueness across PID reuse
OWNER_ID = f"{os.getpid()}-{uuid.uuid4().hex[:8]}"

# Heartbeat configuration (must match delegation.py)
HEARTBEAT_INTERVAL_SECONDS = 5
HEARTBEAT_MAX_RETRIES = 3
HEARTBEAT_BASE_DELAY = 0.5

# Proxy configuration
DEFAULT_PROXY_PORT = 34763
DEFAULT_PROXY_HOST = "localhost"


def _check_proxy_available() -> Dict[str, str]:
    """
    Check if Claude API proxy is enabled and running.

    Uses socket probe for v1 implementation (fast, zero-dependency).
    Returns proxy env vars if proxy is available, empty dict otherwise.

    Environment variables:
    - LEGION_PROXY_ENABLED: Set to "true" to enable proxy routing
    - LEGION_PROXY_PORT: Proxy port (default: 34763)
    - LEGION_PROXY_HOST: Proxy host (default: localhost)

    Returns:
        dict: {"ANTHROPIC_BASE_URL": "http://host:port"} if proxy available,
              {} if proxy disabled or not responding
    """
    import socket

    # Check if proxy routing is enabled
    if os.environ.get("LEGION_PROXY_ENABLED", "false").lower() != "true":
        return {}

    proxy_port = int(os.environ.get("LEGION_PROXY_PORT", str(DEFAULT_PROXY_PORT)))
    proxy_host = os.environ.get("LEGION_PROXY_HOST", DEFAULT_PROXY_HOST)
    proxy_url = f"http://{proxy_host}:{proxy_port}"

    # Quick socket check: is the port responding?
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            s.connect((proxy_host, proxy_port))
            logger.info(f"Proxy available at {proxy_url} - delegation will route through it")
            return {"ANTHROPIC_BASE_URL": proxy_url}
    except (ConnectionRefusedError, socket.timeout, OSError) as e:
        raise RuntimeError(
            f"Proxy is enabled (LEGION_PROXY_ENABLED=true) but not responding "
            f"on {proxy_url} ({type(e).__name__}). Start the proxy or disable it."
        )


def _load_merged_mcp_config(target_path: str) -> Dict[str, Any]:
    """Load and merge MCP server configs from all three hierarchy layers.

    Layer 1 (lowest priority): ~/.claude.json → top-level "mcpServers"
    Layer 2: ~/.claude.json → "projects" → "{target_path}" → "mcpServers"
    Layer 3 (highest priority): {target_path}/.mcp.json → "mcpServers"

    Merge is at the server-name level — if both global and local define
    "legion", local's entire entry wins.

    Returns:
        Dict mapping server names to their full config dicts.
    """
    merged: Dict[str, Any] = {}

    # Layers 1 + 2: global and per-project from ~/.claude.json
    claude_config_path = Path.home() / ".claude.json"
    if claude_config_path.exists():
        try:
            with open(claude_config_path) as f:
                claude_config = json.load(f)
            # Layer 1: global mcpServers
            merged.update(claude_config.get("mcpServers", {}))
            # Layer 2: per-project mcpServers
            project_config = claude_config.get("projects", {}).get(target_path, {})
            merged.update(project_config.get("mcpServers", {}))
        except Exception:
            pass

    # Layer 3: local .mcp.json (highest priority)
    local_config_path = Path(target_path) / ".mcp.json"
    if local_config_path.exists():
        try:
            with open(local_config_path) as f:
                local_config = json.load(f)
            merged.update(local_config.get("mcpServers", {}))
        except Exception:
            pass

    return merged


class CancellationRequested(Exception):
    """Raised when delegation cancellation is detected."""
    pass


async def _heartbeat_loop(delegation_id: str, client: Any) -> None:
    """
    Send periodic heartbeats while delegation runs.
    Uses exponential backoff on retry.
    Stops when delegation completes, ownership is lost, or cancellation is requested.

    Raises CancellationRequested if status changes to 'cancelled'.
    """
    from legion_mcp.protos import delegation_pb2

    while True:
        try:
            success = False
            last_error = None

            for attempt in range(HEARTBEAT_MAX_RETRIES):
                try:
                    await client.ensure_connected()
                    request = delegation_pb2.UpdateHeartbeatRequest(
                        delegation_id=delegation_id,
                        owner_id=OWNER_ID
                    )
                    response = await client.delegation_stub.UpdateHeartbeat(request)

                    if response.success:
                        success = True
                        break
                    else:
                        logger.warning(
                            f"Lost ownership of delegation {delegation_id} - stopping heartbeat"
                        )
                        return

                except Exception as e:
                    last_error = e
                    if attempt < HEARTBEAT_MAX_RETRIES - 1:
                        delay = HEARTBEAT_BASE_DELAY * (2 ** attempt)
                        logger.warning(
                            f"Heartbeat attempt {attempt + 1} failed for {delegation_id}, "
                            f"retrying in {delay}s: {e}"
                        )
                        await asyncio.sleep(delay)

            if not success:
                logger.error(
                    f"Heartbeat failed after {HEARTBEAT_MAX_RETRIES} attempts "
                    f"for {delegation_id}: {last_error}"
                )

            # Check for cancellation by polling status
            try:
                status_request = delegation_pb2.GetDelegationStatusRequest(
                    user_token=client.token or "",
                    delegation_id=delegation_id
                )
                status_response = await client.delegation_stub.GetDelegationStatus(status_request)
                if status_response.delegation_status == "cancelled":
                    logger.info(f"Delegation {delegation_id} was cancelled - stopping")
                    raise CancellationRequested(f"Delegation {delegation_id} cancelled")
            except CancellationRequested:
                raise
            except Exception as e:
                logger.warning(f"Failed to check status for cancellation: {e}")

        except asyncio.CancelledError:
            logger.debug(f"Heartbeat loop cancelled for delegation {delegation_id}")
            raise
        except CancellationRequested:
            raise
        except Exception as e:
            logger.error(f"Unexpected heartbeat error for {delegation_id}: {e}")

        await asyncio.sleep(HEARTBEAT_INTERVAL_SECONDS)


async def _delegate_via_gemini(
    agent_ctx: Dict[str, Any],
    agent_id: str,
    task: str,
    context: Optional[str],
    model: str,
    delegation_id: str,
    engagement_id: str,
    target_path: str,
    client: Any,
    max_turns: int = 50
) -> Dict[str, Any]:
    """Execute delegation via Google Gemini API with manual function calling.

    Args:
        agent_ctx: Agent context with name, role, combined_system_prompt
        agent_id: UUID of the agent
        task: Task description
        context: Optional additional context
        model: Gemini model name (e.g., "gemini-2.5-flash")
        delegation_id: UUID for progress tracking
        engagement_id: UUID for engagement context
        target_path: Working directory (cwd for tool execution)
        client: gRPC client for UpdateDelegationProgress
        max_turns: Maximum agentic loop iterations (default: 50)

    Returns:
        {
            "status": "completed" | "failed",
            "agent_name": str,
            "agent_role": str,
            "summary": str,
            "tools_used": List[str],
            "turns": int,
            "cost_usd": float,
            "error": Optional[str]
        }
    """
    from google import genai
    from google.genai import types
    from google.api_core import exceptions as google_exceptions
    from legion_mcp.gemini_tools import get_tool_declarations
    from legion_mcp.gemini_executor import GeminiToolExecutor
    from legion_mcp.protos import delegation_pb2

    # Get API key from environment
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": "GEMINI_API_KEY environment variable not set",
            "tools_used": [],
            "turns": 0,
            "cost_usd": 0.0
        }

    # Initialize Gemini client
    gemini_client = genai.Client(api_key=api_key)

    # Get model from environment or use provided
    gemini_model = os.environ.get("GEMINI_DELEGATION_MODEL", model)
    if not gemini_model.startswith("gemini"):
        gemini_model = "gemini-2.5-flash"  # Default for delegation

    # Build full prompt with identity instruction
    identity_instruction = f"""IMPORTANT: Before starting any work, you MUST first establish your identity by calling:
mcp__legion__whoAmI(agent_id="{agent_id}")

This will configure you as {agent_ctx['name']} ({agent_ctx['role']}).

Active engagement: {engagement_id}
Record all work to this engagement via addEntry().
"""
    full_prompt = identity_instruction + "\n"
    if context:
        full_prompt += f"Context:\n{context}\n\n"
    full_prompt += f"Task:\n{task}"

    combined_system_prompt = agent_ctx["combined_system_prompt"]

    # Get tool declarations
    tools = get_tool_declarations()

    # Initialize tool executor
    executor = GeminiToolExecutor(target_path, client)

    # Build initial contents
    contents = [
        types.Content(
            role="user",
            parts=[types.Part.from_text(full_prompt)]
        )
    ]

    # Tracking variables
    turn_count = 0
    tools_used: set[str] = set()
    total_input_tokens = 0
    total_output_tokens = 0
    final_text = ""

    async def update_progress(action: str, tool: str = "") -> None:
        """Send progress update to gRPC server."""
        try:
            progress_request = delegation_pb2.UpdateProgressRequest(
                delegation_id=delegation_id,
                current_action=action,
                step=delegation_pb2.ProgressStep(
                    step=turn_count,
                    tool=tool,
                    input_summary=final_text[:100] if final_text else "",
                )
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationProgress,
                progress_request
            )
        except Exception as e:
            logger.warning(f"Failed to update progress: {e}")

    async def check_cancelled() -> bool:
        """Check if delegation was cancelled."""
        try:
            status_request = delegation_pb2.GetDelegationStatusRequest(
                user_token=client.token or "",
                delegation_id=delegation_id
            )
            status_response = await client.delegation_stub.GetDelegationStatus(status_request)
            return status_response.delegation_status == "cancelled"
        except Exception as e:
            logger.warning(f"Failed to check cancellation: {e}")
            return False

    try:
        # Agentic loop
        while turn_count < max_turns:
            # Check for cancellation
            if await check_cancelled():
                raise CancellationRequested(f"Delegation {delegation_id} cancelled")

            # Generate response with retry logic
            response = None
            for attempt in range(3):
                try:
                    response = await gemini_client.aio.models.generate_content(
                        model=gemini_model,
                        contents=contents,
                        config=types.GenerateContentConfig(
                            system_instruction=combined_system_prompt,
                            tools=[{"function_declarations": tools}],
                            tool_config=types.ToolConfig(
                                function_calling_config=types.FunctionCallingConfig(
                                    mode="AUTO"
                                )
                            )
                        )
                    )
                    break
                except google_exceptions.ResourceExhausted:
                    wait_time = 2 ** (attempt + 1)
                    logger.warning(f"Rate limit hit, waiting {wait_time}s (attempt {attempt + 1})")
                    await asyncio.sleep(wait_time)
                except google_exceptions.DeadlineExceeded:
                    if attempt == 2:
                        raise
                    await asyncio.sleep(1)

            if response is None:
                raise Exception("Failed to get response from Gemini after 3 attempts")

            turn_count += 1

            # Track token usage
            if hasattr(response, "usage_metadata"):
                total_input_tokens += getattr(response.usage_metadata, "prompt_token_count", 0)
                total_output_tokens += getattr(response.usage_metadata, "candidates_token_count", 0)

            # Check for safety blocks (per Ragen's recommendation)
            if not response.candidates:
                logger.warning(f"Gemini returned no candidates (possible safety block)")
                final_text = "Response blocked by Gemini safety filters"
                break

            candidate = response.candidates[0]

            # Check finish reason
            finish_reason = getattr(candidate, "finish_reason", None)
            if finish_reason and str(finish_reason) == "SAFETY":
                logger.warning(f"Gemini response blocked for safety")
                final_text = "Response blocked by Gemini safety filters"
                break

            if not candidate.content or not candidate.content.parts:
                logger.warning(f"Empty response from Gemini")
                break

            part = candidate.content.parts[0]

            # Check for function call
            if hasattr(part, "function_call") and part.function_call:
                fc = part.function_call
                tool_name = fc.name
                tool_args = dict(fc.args) if fc.args else {}

                tools_used.add(tool_name)
                await update_progress(f"Using {tool_name}", tool_name)

                logger.info(f"Turn {turn_count}: Calling {tool_name}")

                # Execute tool
                result = await executor.execute(tool_name, tool_args)

                # Append assistant response (the function call)
                contents.append(candidate.content)

                # Append function response
                contents.append(
                    types.Content(
                        role="user",
                        parts=[
                            types.Part.from_function_response(
                                name=tool_name,
                                response=result
                            )
                        ]
                    )
                )

            else:
                # Final text response
                if hasattr(part, "text") and part.text:
                    final_text = part.text
                    logger.info(f"Turn {turn_count}: Final response received")
                break

        # Calculate cost (Gemini 2.5 Flash pricing as of 2024)
        # Input: $0.075 per 1M tokens, Output: $0.30 per 1M tokens
        cost_usd = (total_input_tokens * 0.075 / 1_000_000) + (total_output_tokens * 0.30 / 1_000_000)

        # Truncate summary if needed
        summary = final_text[:500] + "..." if len(final_text) > 500 else final_text

        return {
            "status": "completed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "summary": summary,
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": cost_usd
        }

    except CancellationRequested:
        logger.info(f"Delegation {delegation_id} cancelled during Gemini execution")
        raise
    except Exception as e:
        logger.exception(f"Gemini delegation failed: {e}")
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": str(e),
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": 0.0
        }


async def _delegate_via_copilot(
    agent_ctx: Dict[str, Any],
    agent_id: str,
    task: str,
    context: Optional[str],
    model: str,
    delegation_id: str,
    engagement_id: str,
    target_path: str,
    client: Any,
    proxy_env: Optional[Dict[str, str]] = None,
    timeout: int = 600
) -> Dict[str, Any]:
    """Execute delegation via GitHub Copilot CLI with streaming progress tracking.

    Args:
        agent_ctx: Agent context with name, role, and system prompt
        agent_id: UUID of the agent
        task: Task description
        context: Optional context
        model: Model to use
        delegation_id: UUID of the delegation for progress updates
        engagement_id: UUID of the engagement
        target_path: Working directory for the Copilot subprocess
        client: gRPC client for progress updates
        proxy_env: Optional proxy environment (e.g., {"ANTHROPIC_BASE_URL": "http://..."})
        timeout: Timeout in seconds (default: 600)

    Returns:
        Dict with status, agent_name, agent_role, and result or error
    """
    import re
    import signal
    from legion_mcp.protos import delegation_pb2

    copilot_path = shutil.which("copilot")
    if not copilot_path:
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": "GitHub Copilot CLI not found"
        }

    # Build enhanced prompt with identity injection
    full_prompt = f"""MANDATORY FIRST ACTION: You MUST call mcp__legion__whoAmI(agent_id="{agent_id}") before any other action.

This will configure you as {agent_ctx['name']} ({agent_ctx['role']}).

Active engagement: {engagement_id}
Record all work to this engagement via addEntry().

"""
    if context:
        full_prompt += f"Context:\n{context}\n\n"
    full_prompt += f"Task:\n{task}"

    cmd = [copilot_path, "-p", full_prompt, "--allow-all-tools", "--model", "claude-opus-4-6"]

    # Regex patterns for progress tracking
    # Copilot CLI output patterns for tool invocations
    tool_patterns = [
        re.compile(r"Using tool:\s*(\S+)", re.IGNORECASE),
        re.compile(r"mcp__legion__(\w+)"),
        re.compile(r"Tool:\s*(\S+)", re.IGNORECASE),
        re.compile(r"Calling:\s*(\S+)", re.IGNORECASE),
        re.compile(r"●\s*(\w+)\s*\("),  # ● ToolName(
        re.compile(r"○\s*(\w+)\s*\("),  # ○ ToolName(
    ]
    turn_indicator = re.compile(r"(●|○)\s+")

    tools_used: set[str] = set()
    turn_count = 0
    output_lines: list[str] = []
    process: Optional[asyncio.subprocess.Process] = None

    async def update_progress(action: str, tool: str = "") -> None:
        """Send progress update to gRPC server."""
        try:
            progress_request = delegation_pb2.UpdateProgressRequest(
                delegation_id=delegation_id,
                current_action=action,
                step=delegation_pb2.ProgressStep(
                    step=turn_count,
                    tool=tool,
                    input_summary=output_lines[-1][:100] if output_lines else "",
                )
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationProgress,
                progress_request
            )
        except Exception as e:
            logger.warning(f"Failed to update progress: {e}")

    async def check_cancellation() -> bool:
        """Check if delegation was cancelled."""
        try:
            status_request = delegation_pb2.GetDelegationStatusRequest(
                user_token=client.token or "",
                delegation_id=delegation_id
            )
            status_response = await client.delegation_stub.GetDelegationStatus(status_request)
            return status_response.delegation_status == "cancelled"
        except Exception as e:
            logger.warning(f"Failed to check cancellation status: {e}")
            return False

    async def terminate_process(proc: asyncio.subprocess.Process) -> None:
        """Gracefully terminate process with SIGTERM, then SIGKILL."""
        if proc.returncode is not None:
            return

        logger.info(f"Terminating Copilot process (pid={proc.pid})")

        # Try SIGTERM first
        try:
            proc.send_signal(signal.SIGTERM)
        except (ProcessLookupError, OSError):
            return

        # Wait up to 5 seconds for graceful shutdown
        try:
            await asyncio.wait_for(proc.wait(), timeout=5.0)
            logger.info(f"Copilot process terminated gracefully")
            return
        except asyncio.TimeoutError:
            pass

        # Force kill with SIGKILL
        logger.warning(f"Copilot process didn't terminate, sending SIGKILL")
        try:
            proc.kill()
            await proc.wait()
        except (ProcessLookupError, OSError):
            pass

    try:
        env = {k: v for k, v in os.environ.items() if k != "GITHUB_TOKEN"}

        # Inject proxy environment if available
        if proxy_env:
            env.update(proxy_env)
            logger.info(f"Copilot delegation routing through proxy: {proxy_env.get('ANTHROPIC_BASE_URL')}")

        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
            cwd=target_path
        )

        logger.info(f"Started Copilot CLI (pid={process.pid}) for delegation {delegation_id}")

        # Read stdout line by line with progress tracking
        start_time = asyncio.get_event_loop().time()
        last_cancellation_check = start_time

        async def read_stream_with_progress() -> tuple[str, str]:
            """Read stdout with progress tracking and cancellation checks."""
            nonlocal turn_count, last_cancellation_check

            stdout_data: list[str] = []
            stderr_data: list[str] = []

            # Create tasks for reading both streams
            async def read_stdout():
                nonlocal turn_count, last_cancellation_check

                while True:
                    if process.stdout is None:
                        break

                    try:
                        line_bytes = await asyncio.wait_for(
                            process.stdout.readline(),
                            timeout=5.0
                        )
                    except asyncio.TimeoutError:
                        # Check for cancellation during idle periods
                        current_time = asyncio.get_event_loop().time()
                        if current_time - last_cancellation_check >= HEARTBEAT_INTERVAL_SECONDS:
                            last_cancellation_check = current_time
                            if await check_cancellation():
                                raise CancellationRequested("Delegation cancelled")
                        continue

                    if not line_bytes:
                        break

                    line = line_bytes.decode("utf-8", errors="replace").rstrip()
                    stdout_data.append(line)
                    output_lines.append(line)

                    # Detect turn changes (● or ○ indicators)
                    if turn_indicator.match(line):
                        turn_count += 1
                        await update_progress(f"Turn {turn_count}")

                    # Extract tool usage
                    for pattern in tool_patterns:
                        match = pattern.search(line)
                        if match:
                            tool_name = match.group(1)
                            if tool_name and tool_name not in {"tool", "Tool", "Using"}:
                                tools_used.add(tool_name)
                                await update_progress(f"Using {tool_name}", tool_name)
                                break

                    # Check overall timeout
                    elapsed = asyncio.get_event_loop().time() - start_time
                    if elapsed > timeout:
                        raise asyncio.TimeoutError()

            async def read_stderr():
                while True:
                    if process.stderr is None:
                        break
                    line_bytes = await process.stderr.readline()
                    if not line_bytes:
                        break
                    stderr_data.append(line_bytes.decode("utf-8", errors="replace").rstrip())

            # Run both readers concurrently
            await asyncio.gather(read_stdout(), read_stderr())

            return "\n".join(stdout_data), "\n".join(stderr_data)

        try:
            output, error_output = await read_stream_with_progress()
        except CancellationRequested:
            await terminate_process(process)
            raise

        # Wait for process to complete
        await process.wait()

        if process.returncode != 0:
            return {
                "status": "failed",
                "agent_name": agent_ctx["name"],
                "agent_role": agent_ctx["role"],
                "error": error_output or output,
                "tools_used": list(tools_used),
                "turns": turn_count,
                "cost_usd": 0.0
            }

        # Extract response (remove metrics footer)
        lines = output.split("\n")
        result_lines = []
        for line in lines:
            if line.startswith("Total usage est:"):
                break
            if line.startswith("●") or line.startswith("○"):
                line = line[1:].strip()
            if line:
                result_lines.append(line)

        result = "\n".join(result_lines).strip()
        summary = result[:500] + "..." if len(result) > 500 else result

        # Ensure at least 1 turn if we got output
        if turn_count == 0 and result:
            turn_count = 1

        return {
            "status": "completed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "summary": summary,
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": 0.0
        }

    except CancellationRequested:
        logger.info(f"Delegation {delegation_id} cancelled during Copilot execution")
        raise
    except asyncio.TimeoutError:
        if process:
            await terminate_process(process)
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": f"Copilot CLI timed out after {timeout} seconds",
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": 0.0
        }
    except Exception as e:
        if process and process.returncode is None:
            await terminate_process(process)
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": str(e),
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": 0.0
        }


async def _delegate_via_claude_code(
    agent_ctx: Dict[str, Any],
    agent_id: str,
    task: str,
    context: Optional[str],
    model: str,
    delegation_id: str,
    engagement_id: str,
    target_path: str,
    client: Any,
    proxy_env: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """Execute delegation via Claude Agent SDK (Claude Code).

    Args:
        agent_ctx: Agent context with name, role, and system prompt
        agent_id: UUID of the agent
        task: Task description
        context: Optional context
        model: Model to use
        delegation_id: UUID of the delegation for progress updates
        engagement_id: UUID of the engagement
        target_path: Working directory for the Claude Agent
        client: gRPC client for progress updates
        proxy_env: Optional proxy environment (e.g., {"ANTHROPIC_BASE_URL": "http://..."})

    Returns:
        Dict with status, agent_name, agent_role, and result or error
    """
    from claude_agent_sdk import (
        query,
        ClaudeAgentOptions,
        AssistantMessage,
        TextBlock,
        ResultMessage,
        ToolUseBlock
    )
    from pathlib import Path
    from legion_mcp.protos import delegation_pb2

    combined_system_prompt = agent_ctx["combined_system_prompt"]

    # Build full prompt with identity instruction and engagement context
    identity_instruction = f"""IMPORTANT: Before starting any work, you MUST first establish your identity by calling:
mcp__legion__whoAmI(agent_id="{agent_id}")

This will configure you as {agent_ctx['name']} ({agent_ctx['role']}).

Active engagement: {engagement_id}

## Context Resumption Protocol
If you detect conversation has been compacted (summarized history, loss of specific details):
1. Call whoAmI(agent_id="{agent_id}") immediately to restore identity
2. Call recall(query="next_prompt") to retrieve continuation state
3. Resume work from the retrieved state
"""
    full_prompt = identity_instruction + "\n" + task
    if context:
        full_prompt = identity_instruction + f"Context:\n{context}\n\nTask:\n{task}"

    # Find legion-mcp command
    legion_mcp_cmd = shutil.which("legion-mcp")
    if not legion_mcp_cmd:
        legion_mcp_cmd = os.path.join(os.path.dirname(sys.executable), "legion-mcp")

    # Load merged MCP config from all three hierarchy layers
    all_mcp_servers_config = _load_merged_mcp_config(target_path)
    if all_mcp_servers_config:
        logger.info(f"Loaded MCP config with {len(all_mcp_servers_config)} servers: {list(all_mcp_servers_config.keys())}")

    # Extract legion credentials from merged config
    mcp_credentials = all_mcp_servers_config.get("legion", {}).get("env", {})

    # Build env vars — all legion env vars, with os.environ fallback per key
    cli_env = {}
    # Defaults for critical vars that must always have a value
    defaults = {
        "GRPC_SERVER_HOST": "api.wearethelegion.com",
        "GRPC_SERVER_PORT": "50051",
    }
    for k, v in mcp_credentials.items():
        cli_env[k] = str(v) if v else os.environ.get(k, defaults.get(k, ""))
    # Ensure critical vars exist even if not in config
    for k, default in defaults.items():
        if k not in cli_env:
            cli_env[k] = os.environ.get(k, default)

    # Inject proxy environment if available
    if proxy_env:
        cli_env.update(proxy_env)
        logger.info(f"Claude Code delegation routing through proxy: {proxy_env.get('ANTHROPIC_BASE_URL')}")

    mcp_server_env = {
        "GRPC_SERVER_HOST": "${GRPC_SERVER_HOST:-api.wearethelegion.com}",
        "GRPC_SERVER_PORT": "${GRPC_SERVER_PORT:-50051}",
        "MCP_USER_EMAIL": "${MCP_USER_EMAIL}",
        "MCP_USER_PASSWORD": "${MCP_USER_PASSWORD}",
    }

    # Get context tracking hooks
    hooks = await get_delegation_hooks()

    # Build mcp_servers — copy all fields, only resolve ${VAR} in env
    mcp_servers = {}
    for server_name, server_config in all_mcp_servers_config.items():
        if server_name == "legion":
            continue  # legion is always overridden below with resolved path
        entry = dict(server_config)
        if "env" in entry:
            # Resolve ${VAR} patterns from cli_env and os.environ
            resolved_env = {}
            for k, v in entry["env"].items():
                if isinstance(v, str) and v.startswith("${") and v.endswith("}"):
                    inner = v[2:-1]
                    if ":-" in inner:
                        var_name, default_val = inner.split(":-", 1)
                    else:
                        var_name, default_val = inner, v
                    resolved_env[k] = cli_env.get(var_name, os.environ.get(var_name, default_val))
                else:
                    resolved_env[k] = v
            entry["env"] = resolved_env
        mcp_servers[server_name] = entry

    # legion always uses the resolved command path and credentials
    mcp_servers["legion"] = {
        "type": "stdio",
        "command": legion_mcp_cmd,
        "args": [],
        "env": mcp_server_env
    }

    if len(mcp_servers) > 1:
        logger.info(f"Forwarding {len(mcp_servers)} MCP servers to delegation: {list(mcp_servers.keys())}")

    options = ClaudeAgentOptions(
        system_prompt=combined_system_prompt,
        permission_mode="bypassPermissions",
        max_turns=50,
        model=model,
        env=cli_env,
        cwd=target_path,  # Set working directory for Claude Agent
        hooks=hooks,  # Context tracking hooks
        settings=json.dumps({"autoCompactEnabled": True}),
        mcp_servers=mcp_servers
    )

    final_text = []
    tools_used: set[str] = set()
    total_cost = 0.0
    turn_count = 0

    try:
        async for message in query(prompt=full_prompt, options=options):
            if isinstance(message, AssistantMessage):
                turn_count += 1
                for block in message.content:
                    if isinstance(block, TextBlock):
                        final_text.append(block.text)
                    elif isinstance(block, ToolUseBlock):
                        tools_used.add(block.name)

                # Update progress
                try:
                    progress_request = delegation_pb2.UpdateProgressRequest(
                        delegation_id=delegation_id,
                        current_action=f"Turn {turn_count}",
                        step=delegation_pb2.ProgressStep(
                            step=turn_count,
                            tool=list(tools_used)[-1] if tools_used else "",
                            input_summary=final_text[-1][:100] if final_text else "",
                        )
                    )
                    await client.call_with_auth(
                        client.delegation_stub.UpdateDelegationProgress,
                        progress_request
                    )
                except Exception as e:
                    logger.warning(f"Failed to update progress: {e}")

            elif isinstance(message, ResultMessage):
                total_cost = message.total_cost_usd

        full_result = "\n".join(final_text)
        summary = full_result[:500] + "..." if len(full_result) > 500 else full_result

        return {
            "status": "completed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "summary": summary,
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": total_cost
        }
    except Exception as e:
        return {
            "status": "failed",
            "agent_name": agent_ctx["name"],
            "agent_role": agent_ctx["role"],
            "error": str(e),
            "tools_used": list(tools_used),
            "turns": turn_count,
            "cost_usd": total_cost
        }


async def _log_delegation_completed_to_status_log(
    company_id: str,
    agent_id: str,
    agent_name: str,
    agent_role: str,
    project_id: Optional[str],
    engagement_id: str,
    delegation_id: str,
    turns: int,
    cost_usd: float,
) -> None:
    """
    Log delegation completed event to agent_status_log via direct DB access.

    Uses asyncpg directly to avoid importing from legion package
    (which triggers qdrant imports that fail in subprocess context).
    """
    import asyncpg
    from datetime import datetime, timezone

    # Get PostgreSQL URL from environment
    postgres_url = os.environ.get("DATABASE_URL") or os.environ.get("POSTGRES_URL")
    if not postgres_url:
        raise RuntimeError("DATABASE_URL or POSTGRES_URL not set")

    # Parse postgres URL to get connection params
    url_parts = postgres_url.replace("postgresql://", "").split("@")
    user_pass = url_parts[0].split(":")
    host_port_db = url_parts[1].split("/")
    host_port = host_port_db[0].split(":")

    # Create single connection (not pool - we just need one insert)
    conn = await asyncpg.connect(
        user=user_pass[0],
        password=user_pass[1] if len(user_pass) > 1 else "",
        host=host_port[0],
        port=int(host_port[1]) if len(host_port) > 1 else 5432,
        database=host_port_db[1] if len(host_port_db) > 1 else "legion_auth",
    )

    try:
        log_id = str(uuid.uuid4())
        details_json = json.dumps({
            "event": "delegation_completed",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "agent_name": agent_name,
            "agent_role": agent_role,
            "turns": turns,
            "cost_usd": cost_usd,
        })
        tags = ["auto-captured", "delegation"]

        await conn.execute(
            """
            INSERT INTO agent_status_log (
                id, company_id, project_id, agent_id, user_id,
                status_type, message, details, tags, category,
                importance, source_origin, engagement_id, task_id, delegation_id,
                created_at
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, NOW())
            """,
            log_id,
            company_id,
            project_id,
            agent_id,
            None,  # user_id
            "completed",  # status_type
            f"Delegation Completed: {agent_name}",  # message
            details_json,
            tags,
            "pattern",  # category
            3,  # importance
            "auto_captured",  # source_origin
            engagement_id,
            None,  # task_id
            delegation_id,
        )

        logger.info(f"Inserted delegation completed status log: {log_id}")
    finally:
        await conn.close()


async def run_delegation(payload: Dict[str, Any]) -> None:
    """
    Execute the delegation in subprocess.

    Payload structure:
    {
        "delegation_id": str,
        "agent_id": str,
        "task": str,
        "context": str | None,
        "runtime": str,  # "claude-code", "copilot", or "gemini"
        "project_id": str | None,
        "engagement_id": str,
        "model": str,
        "target_path": str  # Required: working directory for agent
    }
    """
    from legion_mcp.grpc_client import GrpcClientManager
    from legion_mcp.protos import delegation_pb2, agent_skill_pb2

    delegation_id = payload["delegation_id"]
    agent_id = payload["agent_id"]
    task = payload["task"]
    context = payload.get("context")
    runtime = payload.get("runtime", "claude-code")
    project_id = payload.get("project_id")
    engagement_id = payload["engagement_id"]
    model = payload.get("model", "claude-sonnet-4-20250514")
    target_path = payload.get("target_path")

    # Validate target_path is required
    if not target_path:
        raise ValueError("target_path is required in delegation payload")

    # Defense in depth: validate target_path exists in subprocess too
    if not os.path.isdir(target_path):
        raise ValueError(f"target_path does not exist or is not a directory: {target_path}")

    logger.info(f"Starting delegation {delegation_id} (owner={OWNER_ID}, runtime={runtime}, cwd={target_path})")

    # Load merged MCP config and set legion credentials for gRPC client
    merged_mcp_config = _load_merged_mcp_config(target_path)
    legion_env = merged_mcp_config.get("legion", {}).get("env", {})
    if legion_env:
        for key, val in legion_env.items():
            os.environ[key] = str(val)
        logger.info(f"Loaded MCP config with {len(merged_mcp_config)} servers: {list(merged_mcp_config.keys())}")

    # Initialize gRPC client - fresh instance for this subprocess
    client = GrpcClientManager()
    await client.ensure_connected()
    await client.authenticate()

    heartbeat_task = None

    try:
        # 1. Claim ownership
        claim_request = delegation_pb2.ClaimDelegationRequest(
            delegation_id=delegation_id,
            owner_id=OWNER_ID
        )
        claim_response = await client.delegation_stub.ClaimDelegation(claim_request)

        if not claim_response.claimed:
            logger.error(f"Failed to claim delegation {delegation_id}: {claim_response.error_message}")
            error_request = delegation_pb2.UpdateStatusRequest(
                delegation_id=delegation_id,
                new_status="failed",
                error_message="Failed to claim delegation ownership"
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationStatus,
                error_request
            )
            return

        logger.info(f"Claimed ownership of delegation {delegation_id}")

        # 2. Update status to running FIRST (before heartbeat, since heartbeat checks status='running')
        status_request = delegation_pb2.UpdateStatusRequest(
            delegation_id=delegation_id,
            new_status="running"
        )
        await client.call_with_auth(
            client.delegation_stub.UpdateDelegationStatus,
            status_request
        )
        logger.info(f"Delegation {delegation_id} status updated to 'running'")

        # 3. Start heartbeat task (NOW status is 'running', so heartbeat checks will pass)
        heartbeat_task = asyncio.create_task(_heartbeat_loop(delegation_id, client))

        # 4. Get agent context
        ctx_request = agent_skill_pb2.GetAgentContextRequest(
            agent_id=agent_id,
            project_id=project_id or ""
        )
        ctx_response = await client.call_with_auth(
            client.agent_skill_stub.GetAgentContext, ctx_request
        )
        agent_ctx = {
            "agent_id": ctx_response.agent_id,
            "name": ctx_response.agent_name,
            "role": ctx_response.agent_role,
            "combined_system_prompt": ctx_response.combined_system_prompt,
            "company_id": ctx_response.company_instructions.company_id if ctx_response.company_instructions else None,
        }

        logger.info(f"Executing delegation as {agent_ctx['name']} ({agent_ctx['role']})")

        # 4.5. Check if proxy is available (for claude-code and copilot runtimes)
        # Gemini uses its own API, not Anthropic, so proxy doesn't apply
        proxy_env: Dict[str, str] = {}
        if runtime in ("claude-code", "copilot"):
            proxy_env = _check_proxy_available()

        # 5. Execute delegation with cancellation support
        # Run main work and heartbeat as separate tasks, cancel main if heartbeat fails
        async def run_main_work():
            if runtime == "gemini":
                # Gemini uses Google's API, not Anthropic - no proxy support
                return await _delegate_via_gemini(
                    agent_ctx, agent_id, task, context, model, delegation_id, engagement_id, target_path, client
                )
            elif runtime == "copilot":
                return await _delegate_via_copilot(
                    agent_ctx, agent_id, task, context, model, delegation_id, engagement_id, target_path, client,
                    proxy_env=proxy_env
                )
            else:
                return await _delegate_via_claude_code(
                    agent_ctx, agent_id, task, context, model, delegation_id, engagement_id, target_path, client,
                    proxy_env=proxy_env
                )

        main_task = asyncio.create_task(run_main_work())

        # Wait for either main work to complete or heartbeat to raise exception
        done, pending = await asyncio.wait(
            [main_task, heartbeat_task],
            return_when=asyncio.FIRST_COMPLETED
        )

        # Check if heartbeat finished first (means cancellation or error)
        if heartbeat_task in done:
            try:
                heartbeat_task.result()  # Re-raise any exception
            except CancellationRequested:
                logger.info(f"Delegation {delegation_id} cancelled via status update")
                main_task.cancel()
                try:
                    await main_task
                except asyncio.CancelledError:
                    pass
                # Status already set to cancelled by cancel_delegation
                return
            except Exception as e:
                logger.error(f"Heartbeat died unexpectedly: {e}")
                main_task.cancel()
                try:
                    await main_task
                except asyncio.CancelledError:
                    pass
                raise

        # Main work completed - get result
        result = main_task.result()

        # 6. Update final status
        final_status = "completed" if result.get("status") == "completed" else "failed"
        final_request = delegation_pb2.UpdateStatusRequest(
            delegation_id=delegation_id,
            new_status=final_status,
            result_summary=result.get("summary", ""),
            tools_used=result.get("tools_used", []),
            turns=result.get("turns", 0),
            cost_usd=result.get("cost_usd", 0.0),
            error_message=result.get("error", "")
        )
        await client.call_with_auth(
            client.delegation_stub.UpdateDelegationStatus,
            final_request
        )

        logger.info(f"Delegation {delegation_id} completed with status '{final_status}'")

        # Auto-capture: Delegation Completed → agent_status_log (not engagement_entries)
        if final_status == "completed" and agent_ctx.get("company_id"):
            try:
                from datetime import datetime, timezone

                await _log_delegation_completed_to_status_log(
                    company_id=agent_ctx["company_id"],
                    agent_id=agent_id,
                    agent_name=agent_ctx["name"],
                    agent_role=agent_ctx["role"],
                    project_id=project_id,
                    engagement_id=engagement_id,
                    delegation_id=delegation_id,
                    turns=result.get("turns", 0),
                    cost_usd=result.get("cost_usd", 0),
                )
                logger.info(f"Auto-captured delegation completed to agent_status_log for {delegation_id}")
            except Exception as e:
                logger.warning(f"Failed to auto-capture delegation completed to status log: {e}")

    except CancellationRequested:
        logger.info(f"Delegation {delegation_id} was cancelled")
        # Status already set to cancelled - just exit gracefully

    except Exception as e:
        logger.exception(f"Delegation {delegation_id} failed with error: {e}")
        try:
            error_request = delegation_pb2.UpdateStatusRequest(
                delegation_id=delegation_id,
                new_status="failed",
                error_message=str(e)
            )
            await client.call_with_auth(
                client.delegation_stub.UpdateDelegationStatus,
                error_request
            )
        except Exception as update_error:
            logger.error(f"Failed to update failed status: {update_error}")

    finally:
        # Stop heartbeat task
        if heartbeat_task is not None:
            heartbeat_task.cancel()
            try:
                await heartbeat_task
            except asyncio.CancelledError:
                pass

        logger.info(f"Delegation {delegation_id} subprocess exiting")


def main():
    """
    Entry point - reads JSON payload from stdin.

    Expected JSON:
    {
        "delegation_id": "uuid",
        "agent_id": "uuid",
        "task": "task description",
        "engagement_id": "uuid",
        "target_path": "/path/to/repository",
        "context": "optional context",
        "runtime": "claude-code",
        "project_id": "optional project uuid",
        "model": "claude-sonnet-4-20250514"
    }
    """
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
        handlers=[logging.StreamHandler(sys.stderr)]
    )

    # Read JSON payload from stdin
    try:
        payload_json = sys.stdin.read()
        if not payload_json.strip():
            logger.error("No JSON payload provided on stdin")
            sys.exit(1)
        payload = json.loads(payload_json)
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON payload: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Failed to read stdin: {e}")
        sys.exit(1)

    # Validate required fields
    required_fields = ["delegation_id", "agent_id", "task", "engagement_id", "target_path"]
    missing = [f for f in required_fields if f not in payload]
    if missing:
        logger.error(f"Missing required fields: {missing}")
        sys.exit(1)

    logger.info(f"Delegation runner started (pid={os.getpid()}, owner={OWNER_ID})")

    # Run the delegation
    asyncio.run(run_delegation(payload))


if __name__ == "__main__":
    main()