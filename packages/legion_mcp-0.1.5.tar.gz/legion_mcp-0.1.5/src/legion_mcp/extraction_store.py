"""LEGION extraction storage subprocess.

Reads extraction payload from stdin, upserts into the sessions table
via SessionService.UpsertSession gRPC call.

Runs in the MCP virtualenv (has access to legion_mcp, grpcio, protobuf).
Spawned by CognitiveExtractor from within the mitmdump process.

Usage:
    echo '{"session_id":"...", ...}' | legion-extraction-store
    echo '{"session_id":"...", ...}' | python -m legion_mcp.extraction_store

Design ref: Allen's architecture entry 66b8405b, Section 5.4.
User refinement: every turn persists to DB (entry 6b823424).
Storage target: SessionService.UpsertSession (sessions table, NOT PermanentMemory).
"""

import asyncio
import json
import logging
import os
import sys

# gRPC fork safety — must be set before any grpc imports
os.environ.setdefault("GRPC_ENABLE_FORK_SUPPORT", "1")
os.environ.setdefault("GRPC_POLL_STRATEGY", "poll")

logger = logging.getLogger("legion.extraction_store")


async def _upsert(payload):
    """Upsert extraction data into sessions table via gRPC.

    Uses GrpcClientManager for connection and auth, then calls
    SessionService.UpsertSession.
    """
    from legion_mcp.grpc_client import get_grpc_client_manager, reset_grpc_client_manager
    from legion_mcp.protos import session_pb2

    client = get_grpc_client_manager()

    try:
        await client.ensure_connected()
        await client.authenticate()

        # Build session stub — not registered on GrpcClientManager, create manually
        import grpc
        from legion_mcp.protos import session_pb2_grpc

        server_address = f"{client.grpc_host}:{client.grpc_port}"
        channel = grpc.aio.insecure_channel(server_address)
        session_stub = session_pb2_grpc.SessionServiceStub(channel)

        # Build upsert request
        request = session_pb2.UpsertSessionRequest(
            user_token=client.token or "",
            session_id=payload.get("session_id", ""),
            agent_id=payload.get("agent_id", ""),
            company_id=payload.get("company_id", ""),
            project_id=payload.get("project_id", ""),
            engagement_id=payload.get("engagement_id", ""),
            task_id=payload.get("task_id", ""),
            turn_number=int(payload.get("turn_number", 0)),
            extraction=payload.get("extraction", "{}"),
            model_primary=payload.get("model_primary", ""),
            total_input_tokens=int(payload.get("total_input_tokens", 0)),
            total_output_tokens=int(payload.get("total_output_tokens", 0)),
        )

        # Make the gRPC call with auth metadata
        metadata = (("authorization", f"Bearer {client.token}"),)
        response = await session_stub.UpsertSession(request, metadata=metadata)

        if response.status == "success":
            action = "created" if response.created else "updated"
            logger.info(
                f"Session {payload.get('session_id', '?')[:8]}... "
                f"{action} (turn {payload.get('turn_number', '?')})"
            )
        else:
            logger.warning(
                f"UpsertSession failed: {response.error_message} "
                f"({response.error_code})"
            )

        await channel.close()

    except Exception as e:
        logger.error(f"Extraction store failed: {e}")
    finally:
        try:
            reset_grpc_client_manager()
        except Exception:
            pass


def main():
    """Entry point: read JSON from stdin, upsert to sessions table."""
    # Configure minimal logging to stderr
    logging.basicConfig(
        level=logging.INFO,
        format="[extraction-store] %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    try:
        raw = sys.stdin.read()
        if not raw.strip():
            logger.warning("Empty stdin — nothing to store")
            sys.exit(0)

        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON on stdin: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Failed to read stdin: {e}")
        sys.exit(1)

    # Validate required fields
    session_id = payload.get("session_id")
    if not session_id:
        logger.error("Missing session_id in payload")
        sys.exit(1)

    try:
        asyncio.run(_upsert(payload))
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logger.error(f"Upsert failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
