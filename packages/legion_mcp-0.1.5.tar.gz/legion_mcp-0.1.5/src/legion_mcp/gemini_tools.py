"""Gemini function declarations for delegation runtime.

Converts MCP tool definitions to Gemini function calling format.
These are the tools available to Gemini during delegation execution.
"""

from typing import Any, Dict, List


def get_tool_declarations() -> List[Dict[str, Any]]:
    """Generate Gemini function declarations for delegation tools.

    Returns list of OpenAPI-style function declarations that Gemini
    can use for function calling.

    Includes:
    - File operations: Read, Write, Edit, Glob, Grep
    - Execution: Bash
    - LEGION MCP tools: subset for delegation (no admin tools)
    """
    return [
        # === File Operations ===
        {
            "name": "read_file",
            "description": "Read contents of a file. Returns file content as string.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Absolute path to the file to read"
                    },
                    "offset": {
                        "type": "integer",
                        "description": "Line number to start reading from (optional)"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Number of lines to read (optional)"
                    }
                },
                "required": ["file_path"]
            }
        },
        {
            "name": "write_file",
            "description": "Write content to a file. Creates file if it doesn't exist, overwrites if it does.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Absolute path to the file to write"
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to write to the file"
                    }
                },
                "required": ["file_path", "content"]
            }
        },
        {
            "name": "edit_file",
            "description": "Edit a file by replacing old_string with new_string. The old_string must be unique in the file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Absolute path to the file to edit"
                    },
                    "old_string": {
                        "type": "string",
                        "description": "The exact text to replace (must be unique in file)"
                    },
                    "new_string": {
                        "type": "string",
                        "description": "The text to replace it with"
                    },
                    "replace_all": {
                        "type": "boolean",
                        "description": "If true, replace all occurrences (default: false)"
                    }
                },
                "required": ["file_path", "old_string", "new_string"]
            }
        },
        {
            "name": "glob_files",
            "description": "Find files matching a glob pattern. Returns list of matching file paths.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Glob pattern (e.g., '**/*.py', 'src/**/*.ts')"
                    },
                    "path": {
                        "type": "string",
                        "description": "Base directory to search in (optional, defaults to cwd)"
                    }
                },
                "required": ["pattern"]
            }
        },
        {
            "name": "grep_search",
            "description": "Search for a regex pattern in files. Returns matching lines or file paths.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Regular expression pattern to search for"
                    },
                    "path": {
                        "type": "string",
                        "description": "File or directory to search in (optional)"
                    },
                    "glob": {
                        "type": "string",
                        "description": "Glob pattern to filter files (e.g., '*.py')"
                    },
                    "output_mode": {
                        "type": "string",
                        "enum": ["content", "files_with_matches", "count"],
                        "description": "Output mode: 'content' shows lines, 'files_with_matches' shows paths"
                    },
                    "case_insensitive": {
                        "type": "boolean",
                        "description": "Case insensitive search"
                    },
                    "context_lines": {
                        "type": "integer",
                        "description": "Number of context lines before/after match"
                    }
                },
                "required": ["pattern"]
            }
        },
        # === Execution ===
        {
            "name": "execute_bash",
            "description": "Execute a bash command. Returns stdout/stderr. Use for git, npm, tests, etc.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The bash command to execute"
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds (default: 120, max: 600)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Brief description of what this command does"
                    }
                },
                "required": ["command"]
            }
        },
        # === LEGION MCP Tools (delegation-safe subset) ===
        {
            "name": "mcp__legion__whoAmI",
            "description": "Establish agent identity. MUST be called first. Returns agent context and skills.",
            "parameters": {
                "type": "object",
                "properties": {
                    "agent_id": {
                        "type": "string",
                        "description": "Agent UUID to become"
                    },
                    "project_id": {
                        "type": "string",
                        "description": "Optional project UUID for hierarchical prompt"
                    },
                    "company_id": {
                        "type": "string",
                        "description": "Optional company UUID"
                    }
                },
                "required": []
            }
        },
        {
            "name": "mcp__legion__addEntry",
            "description": "Add an entry to an engagement (requirement, insight, decision, plan, note, question).",
            "parameters": {
                "type": "object",
                "properties": {
                    "engagement_id": {
                        "type": "string",
                        "description": "Engagement UUID"
                    },
                    "entry_type": {
                        "type": "string",
                        "enum": ["requirement", "insight", "decision", "plan", "note", "question"],
                        "description": "Type of entry"
                    },
                    "title": {
                        "type": "string",
                        "description": "Short descriptive title"
                    },
                    "content": {
                        "type": "string",
                        "description": "Full entry content (can be markdown)"
                    },
                    "agent_id": {
                        "type": "string",
                        "description": "Agent UUID who created this entry"
                    },
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional tags for categorization"
                    }
                },
                "required": ["engagement_id", "entry_type", "title", "content"]
            }
        },
        {
            "name": "mcp__legion__queryKnowledge",
            "description": "Search stored knowledge using hybrid retrieval. For docs, architecture, design decisions.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Natural language question"
                    },
                    "project_id": {
                        "type": "string",
                        "description": "Project UUID"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default: 10)"
                    }
                },
                "required": ["query", "project_id"]
            }
        },
        {
            "name": "mcp__legion__queryExpertise",
            "description": "Search expertise documents (guides, tutorials, best practices).",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Natural language question"
                    },
                    "project_id": {
                        "type": "string",
                        "description": "Project UUID"
                    },
                    "company_id": {
                        "type": "string",
                        "description": "Company UUID for company-level expertise"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default: 10)"
                    }
                },
                "required": ["query"]
            }
        },
        {
            "name": "mcp__legion__queryLessons",
            "description": "Search past resolved issues to find solutions for current problems.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Describe the problem"
                    },
                    "project_id": {
                        "type": "string",
                        "description": "Project UUID"
                    },
                    "category_filter": {
                        "type": "string",
                        "description": "Optional category filter"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default: 10)"
                    }
                },
                "required": ["query", "project_id"]
            }
        },
        {
            "name": "mcp__legion__findSimilarCode",
            "description": "Search indexed code by natural language or code snippet.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Natural language or code snippet"
                    },
                    "project_id": {
                        "type": "string",
                        "description": "Project UUID"
                    },
                    "language": {
                        "type": "string",
                        "description": "Filter by language (python, typescript, ruby, etc.)"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default: 10)"
                    }
                },
                "required": ["query"]
            }
        },
        {
            "name": "mcp__legion__createKnowledge",
            "description": "Store documentation, notes, or unstructured text for semantic search.",
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Text content to store"
                    },
                    "project_id": {
                        "type": "string",
                        "description": "Project UUID"
                    },
                    "metadata": {
                        "type": "object",
                        "description": "Optional tags/metadata"
                    }
                },
                "required": ["text", "project_id"]
            }
        },
        {
            "name": "mcp__legion__recordLesson",
            "description": "Record a resolved issue as a lesson learned for future reference.",
            "parameters": {
                "type": "object",
                "properties": {
                    "project_id": {
                        "type": "string",
                        "description": "Project UUID"
                    },
                    "category": {
                        "type": "string",
                        "description": "Category path (e.g., 'Infrastructure/Docker')"
                    },
                    "title": {
                        "type": "string",
                        "description": "Short descriptive title"
                    },
                    "symptom": {
                        "type": "string",
                        "description": "What error/behavior was observed"
                    },
                    "root_cause": {
                        "type": "string",
                        "description": "Why it happened"
                    },
                    "solution": {
                        "type": "string",
                        "description": "Step-by-step fix"
                    },
                    "prevention": {
                        "type": "string",
                        "description": "How to avoid in future"
                    },
                    "severity": {
                        "type": "string",
                        "enum": ["low", "medium", "high", "critical"],
                        "description": "Severity level"
                    },
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Keywords for search"
                    }
                },
                "required": ["project_id", "category", "title", "symptom", "root_cause", "solution", "prevention"]
            }
        },
        {
            "name": "mcp__legion__getAgentSkills",
            "description": "Get agent's skill overview - list of expertise titles and summaries.",
            "parameters": {
                "type": "object",
                "properties": {
                    "agent_id": {
                        "type": "string",
                        "description": "Agent UUID"
                    }
                },
                "required": ["agent_id"]
            }
        },
        {
            "name": "mcp__legion__searchSkillDetails",
            "description": "Semantic search within a skill's chunks. Returns relevant chunks with full content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "expertise_id": {
                        "type": "string",
                        "description": "Expertise UUID from getAgentSkills"
                    },
                    "query": {
                        "type": "string",
                        "description": "Natural language query"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default: 5)"
                    }
                },
                "required": ["expertise_id", "query"]
            }
        },
        {
            "name": "mcp__legion__getEntry",
            "description": "Get a single engagement entry by ID with full content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "entry_id": {
                        "type": "string",
                        "description": "Entry UUID"
                    }
                },
                "required": ["entry_id"]
            }
        },
        {
            "name": "mcp__legion__getEngagement",
            "description": "Get engagement details with entry metadata.",
            "parameters": {
                "type": "object",
                "properties": {
                    "engagement_id": {
                        "type": "string",
                        "description": "Engagement UUID"
                    }
                },
                "required": ["engagement_id"]
            }
        },
        {
            "name": "mcp__legion__searchEntries",
            "description": "Hybrid search across engagement entries.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Natural language search query"
                    },
                    "project_id": {
                        "type": "string",
                        "description": "Project UUID"
                    },
                    "engagement_id": {
                        "type": "string",
                        "description": "Optional engagement UUID to search within"
                    },
                    "entry_type": {
                        "type": "string",
                        "description": "Optional filter by entry type"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default: 10)"
                    }
                },
                "required": ["query", "project_id"]
            }
        },
    ]


def mcp_tool_to_gemini_declaration(
    name: str,
    description: str,
    parameters: Dict[str, Any]
) -> Dict[str, Any]:
    """Convert MCP tool definition to Gemini function declaration.

    MCP format:
    {
        "name": "Read",
        "description": "...",
        "inputSchema": {"type": "object", "properties": {...}}
    }

    Gemini format:
    {
        "name": "Read",
        "description": "...",
        "parameters": {"type": "object", "properties": {...}}
    }
    """
    return {
        "name": name,
        "description": description,
        "parameters": parameters
    }
