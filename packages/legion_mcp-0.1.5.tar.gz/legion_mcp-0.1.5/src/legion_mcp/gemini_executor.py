"""Gemini tool executor for delegation runtime.

Executes Gemini function calls by invoking actual tool implementations.
Routes function calls to appropriate handlers (file ops, bash, LEGION MCP).
"""

import asyncio
import json
import logging
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class GeminiToolExecutor:
    """Execute Gemini function calls by invoking actual tool implementations."""

    def __init__(self, target_path: str, grpc_client: Any):
        """Initialize executor with working directory and gRPC client.

        Args:
            target_path: Base directory for file operations (validated path)
            grpc_client: gRPC client for LEGION MCP tool calls
        """
        self.target_path = Path(target_path).resolve()
        self.grpc_client = grpc_client
        # Track files that have been read (for Edit validation)
        self._read_files: set[str] = set()

    def _validate_path(self, requested_path: str) -> Path:
        """Validate path is within target_path to prevent traversal.

        Uses os.path.realpath() + prefix check per Ragen's security recommendation.

        Args:
            requested_path: Path requested by the tool

        Returns:
            Resolved Path object

        Raises:
            ValueError: If path traversal is detected
        """
        # Handle relative paths
        if not os.path.isabs(requested_path):
            requested_path = str(self.target_path / requested_path)

        resolved = os.path.realpath(requested_path)
        target_real = os.path.realpath(str(self.target_path))

        if not resolved.startswith(target_real):
            raise ValueError(f"Path traversal detected: {requested_path}")

        return Path(resolved)

    async def execute(
        self,
        function_name: str,
        function_args: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute a function call and return result.

        Routes to appropriate handler:
        - File tools: read_file, write_file, edit_file, glob_files, grep_search
        - System tools: execute_bash
        - LEGION tools: mcp__legion__* (via gRPC)

        Args:
            function_name: Name of the function to execute
            function_args: Arguments for the function

        Returns:
            {"result": <tool_output>} or {"error": <error_message>}
        """
        try:
            # Route to appropriate handler
            if function_name == "read_file":
                result = await self._execute_read(function_args)
            elif function_name == "write_file":
                result = await self._execute_write(function_args)
            elif function_name == "edit_file":
                result = await self._execute_edit(function_args)
            elif function_name == "glob_files":
                result = await self._execute_glob(function_args)
            elif function_name == "grep_search":
                result = await self._execute_grep(function_args)
            elif function_name == "execute_bash":
                result = await self._execute_bash(function_args)
            elif function_name.startswith("mcp__legion__"):
                result = await self._execute_legion_tool(function_name, function_args)
            else:
                return {"error": f"Unknown function: {function_name}"}

            return {"result": result}

        except FileNotFoundError as e:
            return {"error": f"File not found: {e}"}
        except PermissionError as e:
            return {"error": f"Permission denied: {e}"}
        except ValueError as e:
            return {"error": str(e)}
        except subprocess.TimeoutExpired as e:
            return {"error": f"Command timed out after {e.timeout}s"}
        except Exception as e:
            logger.exception(f"Tool execution failed: {function_name}")
            return {"error": f"Tool execution failed: {str(e)}"}

    async def _execute_read(self, args: Dict[str, Any]) -> str:
        """Read file content.

        Args:
            args: {"file_path": str, "offset"?: int, "limit"?: int}

        Returns:
            File content as string with line numbers
        """
        file_path = self._validate_path(args["file_path"])
        offset = args.get("offset", 0)
        limit = args.get("limit")

        if not file_path.exists():
            raise FileNotFoundError(str(file_path))

        if not file_path.is_file():
            raise ValueError(f"Not a file: {file_path}")

        # Track read files for edit validation
        self._read_files.add(str(file_path))

        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()

        # Apply offset and limit
        if offset > 0:
            lines = lines[offset:]
        if limit:
            lines = lines[:limit]

        # Format with line numbers (1-indexed, matching Read tool format)
        start_line = offset + 1
        result = []
        for i, line in enumerate(lines):
            line_num = start_line + i
            # Truncate very long lines
            if len(line) > 2000:
                line = line[:2000] + "...\n"
            result.append(f"{line_num:6}\t{line.rstrip()}")

        return "\n".join(result)

    async def _execute_write(self, args: Dict[str, Any]) -> str:
        """Write file content.

        Args:
            args: {"file_path": str, "content": str}

        Returns:
            Success message
        """
        file_path = self._validate_path(args["file_path"])
        content = args["content"]

        # Create parent directories if needed
        file_path.parent.mkdir(parents=True, exist_ok=True)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

        # Track as read for potential subsequent edits
        self._read_files.add(str(file_path))

        return f"Successfully wrote {len(content)} bytes to {file_path}"

    async def _execute_edit(self, args: Dict[str, Any]) -> str:
        """Edit file with old_string/new_string replacement.

        Args:
            args: {"file_path": str, "old_string": str, "new_string": str, "replace_all"?: bool}

        Returns:
            Success message
        """
        file_path = self._validate_path(args["file_path"])
        old_string = args["old_string"]
        new_string = args["new_string"]
        replace_all = args.get("replace_all", False)

        if not file_path.exists():
            raise FileNotFoundError(str(file_path))

        # Verify file was read first (matching MCP Edit behavior)
        if str(file_path) not in self._read_files:
            raise ValueError(f"Must read file before editing: {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Check if old_string exists
        if old_string not in content:
            raise ValueError(f"old_string not found in file: {old_string[:50]}...")

        # Check uniqueness if not replace_all
        if not replace_all and content.count(old_string) > 1:
            raise ValueError(
                f"old_string is not unique in file ({content.count(old_string)} occurrences). "
                "Provide more context or use replace_all=true"
            )

        # Perform replacement
        if replace_all:
            new_content = content.replace(old_string, new_string)
            count = content.count(old_string)
        else:
            new_content = content.replace(old_string, new_string, 1)
            count = 1

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        return f"Successfully replaced {count} occurrence(s) in {file_path}"

    async def _execute_glob(self, args: Dict[str, Any]) -> str:
        """Find files matching a glob pattern.

        Args:
            args: {"pattern": str, "path"?: str}

        Returns:
            Newline-separated list of matching file paths
        """
        pattern = args["pattern"]
        base_path = args.get("path")

        if base_path:
            search_path = self._validate_path(base_path)
        else:
            search_path = self.target_path

        # Use glob to find matches
        matches = list(search_path.glob(pattern))

        # Filter to only files within target_path
        valid_matches = []
        target_real = os.path.realpath(str(self.target_path))
        for match in matches:
            match_real = os.path.realpath(str(match))
            if match_real.startswith(target_real):
                valid_matches.append(str(match))

        # Sort by modification time (newest first)
        valid_matches.sort(key=lambda p: os.path.getmtime(p), reverse=True)

        # Limit results
        if len(valid_matches) > 100:
            valid_matches = valid_matches[:100]

        return "\n".join(valid_matches) if valid_matches else "No files found"

    async def _execute_grep(self, args: Dict[str, Any]) -> str:
        """Search for a regex pattern in files using ripgrep.

        Args:
            args: {"pattern": str, "path"?: str, "glob"?: str,
                   "output_mode"?: str, "case_insensitive"?: bool, "context_lines"?: int}

        Returns:
            Search results
        """
        import shutil

        pattern = args["pattern"]
        search_path = args.get("path")
        glob_pattern = args.get("glob")
        output_mode = args.get("output_mode", "files_with_matches")
        case_insensitive = args.get("case_insensitive", False)
        context_lines = args.get("context_lines")

        if search_path:
            path = self._validate_path(search_path)
        else:
            path = self.target_path

        # Build ripgrep command
        rg_path = shutil.which("rg")
        if not rg_path:
            return "Error: ripgrep (rg) not found in PATH"

        cmd = [rg_path, pattern, str(path)]

        if output_mode == "files_with_matches":
            cmd.append("-l")
        elif output_mode == "count":
            cmd.append("-c")
        else:
            cmd.append("-n")  # Show line numbers

        if case_insensitive:
            cmd.append("-i")

        if glob_pattern:
            cmd.extend(["--glob", glob_pattern])

        if context_lines and output_mode == "content":
            cmd.extend(["-C", str(context_lines)])

        # Limit output
        cmd.extend(["--max-count", "100"])

        try:
            result = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.target_path)
            )
            stdout, stderr = await asyncio.wait_for(
                result.communicate(),
                timeout=30.0
            )

            output = stdout.decode("utf-8", errors="replace")
            if not output.strip():
                return "No matches found"

            # Truncate if too long
            if len(output) > 30000:
                output = output[:30000] + "\n... (output truncated)"

            return output

        except asyncio.TimeoutError:
            return "Error: grep search timed out"
        except Exception as e:
            return f"Error during grep: {str(e)}"

    async def _execute_bash(self, args: Dict[str, Any]) -> str:
        """Execute bash command with timeout.

        Args:
            args: {"command": str, "timeout"?: int, "description"?: str}

        Returns:
            Command output (stdout + stderr)
        """
        command = args["command"]
        timeout = min(args.get("timeout", 120), 600)  # Max 10 minutes

        logger.info(f"Executing bash: {command[:100]}...")

        try:
            result = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.target_path)
            )

            stdout, stderr = await asyncio.wait_for(
                result.communicate(),
                timeout=float(timeout)
            )

            output = stdout.decode("utf-8", errors="replace")
            errors = stderr.decode("utf-8", errors="replace")

            # Combine output
            full_output = output
            if errors:
                full_output += f"\n\nSTDERR:\n{errors}"

            # Truncate if too long
            if len(full_output) > 30000:
                full_output = full_output[:30000] + "\n... (output truncated)"

            # Include return code if non-zero
            if result.returncode != 0:
                full_output = f"Exit code: {result.returncode}\n\n{full_output}"

            return full_output

        except asyncio.TimeoutError:
            raise subprocess.TimeoutExpired(command, timeout)

    async def _execute_legion_tool(
        self,
        tool_name: str,
        args: Dict[str, Any]
    ) -> Any:
        """Execute LEGION MCP tool via gRPC.

        Args:
            tool_name: Full tool name (e.g., "mcp__legion__queryKnowledge")
            args: Tool arguments

        Returns:
            Tool result as dict/string
        """
        from legion_mcp.protos import (
            agent_skill_pb2,
            knowledge_pb2,
            engagement_pb2,
            lesson_pb2,
            code_search_pb2,
        )

        # Extract the actual tool name (remove prefix)
        short_name = tool_name.replace("mcp__legion__", "")

        logger.info(f"Executing LEGION tool: {short_name}")

        try:
            if short_name == "whoAmI":
                request = agent_skill_pb2.GetAgentContextRequest(
                    agent_id=args.get("agent_id", ""),
                    project_id=args.get("project_id", ""),
                    company_id=args.get("company_id", "")
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.agent_skill_stub.GetAgentContext, request
                )
                return {
                    "status": "success",
                    "agent_id": response.agent_id,
                    "name": response.agent_name,
                    "role": response.agent_role,
                    "system_prompt": response.combined_system_prompt[:500] + "..."
                    if len(response.combined_system_prompt) > 500 else response.combined_system_prompt
                }

            elif short_name == "addEntry":
                request = engagement_pb2.AddEntryRequest(
                    engagement_id=args["engagement_id"],
                    entry_type=args["entry_type"],
                    title=args["title"],
                    content=args["content"],
                    agent_id=args.get("agent_id", ""),
                    tags=args.get("tags", [])
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.engagement_stub.AddEntry, request
                )
                return {
                    "status": "success",
                    "entry_id": response.entry_id,
                    "entry_type": response.entry_type,
                    "title": response.title
                }

            elif short_name == "queryKnowledge":
                request = knowledge_pb2.QueryKnowledgeRequest(
                    query=args["query"],
                    project_id=args["project_id"],
                    limit=args.get("limit", 10)
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.knowledge_stub.QueryKnowledge, request
                )
                return {
                    "status": "success",
                    "results_count": len(response.results),
                    "results": [
                        {"text": r.text[:500], "score": r.score}
                        for r in response.results[:5]
                    ]
                }

            elif short_name == "queryExpertise":
                request = knowledge_pb2.QueryExpertiseRequest(
                    query=args["query"],
                    project_id=args.get("project_id", ""),
                    company_id=args.get("company_id", ""),
                    limit=args.get("limit", 10)
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.knowledge_stub.QueryExpertise, request
                )
                return {
                    "status": "success",
                    "results_count": len(response.results),
                    "results": [
                        {"text": r.text[:500], "score": r.score}
                        for r in response.results[:5]
                    ]
                }

            elif short_name == "queryLessons":
                request = lesson_pb2.QueryLessonsRequest(
                    query=args["query"],
                    project_id=args["project_id"],
                    category_filter=args.get("category_filter", ""),
                    limit=args.get("limit", 10)
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.lesson_stub.QueryLessons, request
                )
                return {
                    "status": "success",
                    "results_count": len(response.lessons),
                    "lessons": [
                        {
                            "title": l.title,
                            "symptom": l.symptom[:200],
                            "solution": l.solution[:200]
                        }
                        for l in response.lessons[:5]
                    ]
                }

            elif short_name == "findSimilarCode":
                request = code_search_pb2.FindSimilarCodeRequest(
                    query=args["query"],
                    project_id=args.get("project_id", ""),
                    language=args.get("language", ""),
                    limit=args.get("limit", 10)
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.code_search_stub.FindSimilarCode, request
                )
                return {
                    "status": "success",
                    "total": response.total,
                    "results": [
                        {
                            "entity_name": r.entity_name,
                            "file_path": r.file_path,
                            "score": r.score
                        }
                        for r in response.results[:5]
                    ]
                }

            elif short_name == "createKnowledge":
                request = knowledge_pb2.CreateKnowledgeRequest(
                    text=args["text"],
                    project_id=args["project_id"],
                    metadata=args.get("metadata", {})
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.knowledge_stub.CreateKnowledge, request
                )
                return {
                    "status": "success",
                    "knowledge_id": response.knowledge_id,
                    "chunks_count": response.chunks_count
                }

            elif short_name == "recordLesson":
                request = lesson_pb2.RecordLessonRequest(
                    project_id=args["project_id"],
                    category=args["category"],
                    title=args["title"],
                    symptom=args["symptom"],
                    root_cause=args["root_cause"],
                    solution=args["solution"],
                    prevention=args["prevention"],
                    severity=args.get("severity", "medium"),
                    tags=args.get("tags", [])
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.lesson_stub.RecordLesson, request
                )
                return {
                    "status": "success",
                    "lesson_id": response.lesson_id,
                    "title": response.title
                }

            elif short_name == "getAgentSkills":
                request = agent_skill_pb2.GetAgentSkillsRequest(
                    agent_id=args["agent_id"]
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.agent_skill_stub.GetAgentSkills, request
                )
                return {
                    "status": "success",
                    "agent_name": response.agent_name,
                    "skills_count": response.skills_count,
                    "skills": [
                        {"expertise_id": s.expertise_id, "title": s.title}
                        for s in response.skills[:10]
                    ]
                }

            elif short_name == "searchSkillDetails":
                request = agent_skill_pb2.SearchSkillDetailsRequest(
                    expertise_id=args["expertise_id"],
                    query=args["query"],
                    limit=args.get("limit", 5)
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.agent_skill_stub.SearchSkillDetails, request
                )
                return {
                    "status": "success",
                    "results_count": len(response.results),
                    "results": [
                        {
                            "title": r.title,
                            "content": r.content[:500],
                            "score": r.score
                        }
                        for r in response.results[:5]
                    ]
                }

            elif short_name == "getEntry":
                request = engagement_pb2.GetEntryRequest(
                    entry_id=args["entry_id"]
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.engagement_stub.GetEntry, request
                )
                return {
                    "status": "success",
                    "entry_id": response.entry_id,
                    "entry_type": response.entry_type,
                    "title": response.title,
                    "content": response.content
                }

            elif short_name == "getEngagement":
                request = engagement_pb2.GetEngagementRequest(
                    engagement_id=args["engagement_id"]
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.engagement_stub.GetEngagement, request
                )
                return {
                    "status": "success",
                    "engagement_id": response.engagement_id,
                    "name": response.name,
                    "status": response.engagement_status,
                    "entries_count": len(response.entries)
                }

            elif short_name == "searchEntries":
                request = engagement_pb2.SearchEntriesRequest(
                    query=args["query"],
                    project_id=args["project_id"],
                    engagement_id=args.get("engagement_id", ""),
                    entry_type=args.get("entry_type", ""),
                    limit=args.get("limit", 10)
                )
                response = await self.grpc_client.call_with_auth(
                    self.grpc_client.engagement_stub.SearchEntries, request
                )
                return {
                    "status": "success",
                    "results_count": len(response.results),
                    "results": [
                        {"text": r.text[:300], "score": r.score}
                        for r in response.results[:5]
                    ]
                }

            else:
                return {"error": f"Unknown LEGION tool: {short_name}"}

        except Exception as e:
            logger.exception(f"LEGION tool execution failed: {short_name}")
            return {"error": f"LEGION tool failed: {str(e)}"}
