"""
LEGION MCP - Knowledge & Code Intelligence MCP Server for Claude.

Provides 18 tools for knowledge management, code search, and lessons learned.
"""

__version__ = "0.1.0"

from legion_mcp.server import main

__all__ = ["main", "__version__"]
