"""
gRPC Client Manager for MCP Bridge.

Manages gRPC connections, authentication, token caching, and auto-refresh.
"""

import os
import logging
from typing import Optional, Dict, List, Any, Callable

import grpc
from legion_mcp.protos import (
    auth_pb2,
    auth_pb2_grpc,
    knowledge_pb2_grpc,
    code_pb2_grpc,
    expertise_pb2_grpc,
    lessons_learned_pb2_grpc,
    agent_skill_pb2_grpc,
    engagement_pb2_grpc,
    task_pb2_grpc,
    delegation_pb2_grpc,
    ingestion_pb2_grpc,
    memory_pb2_grpc,
    proxy_pb2_grpc,
    unified_search_pb2_grpc,
)

logger = logging.getLogger(__name__)


class GrpcClientManager:
    """
    Manages gRPC client connections with lazy authentication and auto-refresh.

    Features:
    - Lazy authentication (no auth at startup, only on first tool call)
    - Two-step auth: Authenticate -> GetProjects
    - Token caching (token, user_email, user_projects)
    - Auto-refresh on UNAUTHENTICATED errors
    - Singleton pattern
    """

    # Hard-coded production defaults
    DEFAULT_GRPC_HOST = "api.wearethelegion.com"
    DEFAULT_GRPC_PORT = "50051"

    def __init__(
        self,
        grpc_host: Optional[str] = None,
        grpc_port: Optional[str] = None
    ):
        self.channel: Optional[grpc.aio.Channel] = None
        self.token: Optional[str] = None
        self.user_email: Optional[str] = None
        self.user_projects: List[Dict[str, str]] = []

        # gRPC stubs
        self.auth_stub: Optional[auth_pb2_grpc.AuthServiceStub] = None
        self.knowledge_stub: Optional[knowledge_pb2_grpc.KnowledgeServiceStub] = None
        self.code_stub: Optional[code_pb2_grpc.CodeServiceStub] = None
        self.expertise_stub: Optional[expertise_pb2_grpc.ExpertiseServiceStub] = None
        self.lessons_stub: Optional[lessons_learned_pb2_grpc.LessonsLearnedServiceStub] = None
        self.agent_skill_stub: Optional[agent_skill_pb2_grpc.AgentSkillServiceStub] = None
        self.engagement_stub: Optional[engagement_pb2_grpc.EngagementServiceStub] = None
        self.task_stub: Optional[task_pb2_grpc.TaskServiceStub] = None
        self.delegation_stub: Optional[delegation_pb2_grpc.DelegationServiceStub] = None
        self.ingestion_stub: Optional[ingestion_pb2_grpc.IngestionServiceStub] = None
        self.memory_stub: Optional[memory_pb2_grpc.MemoryServiceStub] = None
        self.proxy_stub: Optional[proxy_pb2_grpc.ProxyServiceStub] = None
        self.unified_search_stub: Optional[unified_search_pb2_grpc.UnifiedSearchServiceStub] = None

        # Configuration - read from env vars, then use provided values, then defaults
        self.grpc_host = grpc_host or os.getenv("GRPC_SERVER_HOST") or self.DEFAULT_GRPC_HOST
        self.grpc_port = grpc_port or os.getenv("GRPC_SERVER_PORT") or self.DEFAULT_GRPC_PORT

        # Auth configuration - API_KEY takes priority over email/password
        self.api_key = os.getenv("LEGION_API_KEY")
        self.mcp_user_email = os.getenv("MCP_USER_EMAIL")
        self.mcp_user_password = os.getenv("MCP_USER_PASSWORD")

        # Track auth mode for retry logic
        self._using_api_key = False

    async def ensure_connected(self) -> None:
        """Create gRPC channel and initialize stubs if not already connected."""
        if self.channel is None:
            server_address = f"{self.grpc_host}:{self.grpc_port}"
            logger.info(f"Connecting to gRPC server at {server_address}")

            self.channel = grpc.aio.insecure_channel(server_address)

            # Initialize all service stubs
            self.auth_stub = auth_pb2_grpc.AuthServiceStub(self.channel)
            self.knowledge_stub = knowledge_pb2_grpc.KnowledgeServiceStub(self.channel)
            self.code_stub = code_pb2_grpc.CodeServiceStub(self.channel)
            self.expertise_stub = expertise_pb2_grpc.ExpertiseServiceStub(self.channel)
            self.lessons_stub = lessons_learned_pb2_grpc.LessonsLearnedServiceStub(self.channel)
            self.agent_skill_stub = agent_skill_pb2_grpc.AgentSkillServiceStub(self.channel)
            self.engagement_stub = engagement_pb2_grpc.EngagementServiceStub(self.channel)
            self.task_stub = task_pb2_grpc.TaskServiceStub(self.channel)
            self.delegation_stub = delegation_pb2_grpc.DelegationServiceStub(self.channel)
            self.ingestion_stub = ingestion_pb2_grpc.IngestionServiceStub(self.channel)
            self.memory_stub = memory_pb2_grpc.MemoryServiceStub(self.channel)
            self.proxy_stub = proxy_pb2_grpc.ProxyServiceStub(self.channel)
            self.unified_search_stub = unified_search_pb2_grpc.UnifiedSearchServiceStub(self.channel)

            logger.info("gRPC stubs initialized")

    async def authenticate(self) -> Dict[str, Any]:
        """
        Authenticate using API_KEY (if set) or email/password.

        API_KEY mode: Skip login, use token directly with GetProjects validation
        Password mode: Call AuthService.Authenticate to get JWT, then GetProjects

        Returns:
            dict: Auth response with token, user_email, and projects
        """
        await self.ensure_connected()

        # API_KEY mode - skip login, use token directly
        if self.api_key:
            return await self._authenticate_with_api_key()

        # Password mode - existing login flow
        return await self._authenticate_with_password()

    async def _authenticate_with_api_key(self) -> Dict[str, Any]:
        """Authenticate using LEGION_API_KEY (direct token usage)."""
        if not self.api_key.startswith("lgn_"):
            raise ValueError(
                "Invalid LEGION_API_KEY format. Must start with 'lgn_'"
            )

        self.token = self.api_key
        self._using_api_key = True

        logger.info("Authenticating with API_KEY (lgn_****)")

        # Validate token and fetch user info via GetProjects
        metadata = (("authorization", f"Bearer {self.token}"),)
        projects_request = auth_pb2.GetProjectsRequest(user_token=self.token)

        try:
            projects_response = await self.auth_stub.GetProjects(
                projects_request, metadata=metadata
            )

            if projects_response.status != "success":
                raise ValueError(
                    f"API_KEY validation failed: {projects_response.message}"
                )

            self.user_email = projects_response.user_email
            self.user_projects = [
                {
                    "id": p.id,
                    "company_id": p.company_id,
                    "name": p.name,
                    "description": p.description,
                    "company_name": p.company_name,
                }
                for p in projects_response.projects
            ]

            logger.info(
                f"API_KEY auth successful for {self.user_email} "
                f"({len(self.user_projects)} projects)"
            )

            return {
                "status": "success",
                "token": "[API_KEY]",  # Don't expose actual token in response
                "user_email": self.user_email,
                "projects_count": len(self.user_projects),
                "projects": self.user_projects,
            }

        except grpc.aio.AioRpcError as e:
            if e.code() == grpc.StatusCode.UNAUTHENTICATED:
                raise ValueError("Invalid or expired LEGION_API_KEY")
            logger.error(f"gRPC API_KEY auth error: {e.code()} - {e.details()}")
            raise

    async def _authenticate_with_password(self) -> Dict[str, Any]:
        """Authenticate using email/password (login flow)."""
        if not self.mcp_user_email or not self.mcp_user_password:
            raise ValueError(
                "Missing credentials: Set LEGION_API_KEY or "
                "MCP_USER_EMAIL+MCP_USER_PASSWORD environment variables"
            )

        self._using_api_key = False

        logger.info(f"Authenticating user: {self.mcp_user_email}")

        # Step 1: Authenticate
        auth_request = auth_pb2.AuthRequest(
            email=self.mcp_user_email,
            password=self.mcp_user_password,
        )

        try:
            auth_response = await self.auth_stub.Authenticate(auth_request)

            if auth_response.status != "success":
                raise ValueError(f"Authentication failed: {auth_response.message}")

            # Cache token and user_email
            self.token = auth_response.access_token
            self.user_email = auth_response.user_email

            logger.info(f"Authentication successful for {self.user_email}")

            # Step 2: GetProjects (must pass token in metadata for interceptor)
            projects_request = auth_pb2.GetProjectsRequest(user_token=self.token)
            metadata = (("authorization", f"Bearer {self.token}"),)
            projects_response = await self.auth_stub.GetProjects(projects_request, metadata=metadata)

            if projects_response.status != "success":
                logger.warning(f"GetProjects failed: {projects_response.message}")
                self.user_projects = []
            else:
                # Cache projects
                self.user_projects = [
                    {
                        "id": p.id,
                        "company_id": p.company_id,
                        "name": p.name,
                        "description": p.description,
                        "company_name": p.company_name,
                    }
                    for p in projects_response.projects
                ]
                logger.info(f"Loaded {len(self.user_projects)} projects")

            return {
                "status": "success",
                "token": self.token,
                "user_email": self.user_email,
                "projects_count": len(self.user_projects),
                "projects": self.user_projects,
            }

        except grpc.aio.AioRpcError as e:
            logger.error(f"gRPC authentication error: {e.code()} - {e.details()}")
            raise
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            raise

    async def call_with_auth_by_name(
        self,
        stub_name: str,
        method_name: str,
        request: Any,
    ) -> Any:
        """
        Call gRPC method by name with automatic authentication.
        
        Resolves stub and method AFTER ensure_connected() to avoid NoneType errors.

        Args:
            stub_name: Name of the stub attribute (e.g., "knowledge_stub")
            method_name: Name of the method (e.g., "CreateKnowledge")
            request: Protobuf request message

        Returns:
            Protobuf response message
        """
        await self.ensure_connected()
        
        stub = getattr(self, stub_name, None)
        if stub is None:
            raise ValueError(f"Unknown stub: {stub_name}")
        
        method = getattr(stub, method_name, None)
        if method is None:
            raise ValueError(f"Unknown method {method_name} on {stub_name}")
        
        return await self.call_with_auth(method, request)

    async def call_with_auth(
        self,
        stub_method: Callable,
        request: Any,
    ) -> Any:
        """
        Call gRPC method with automatic authentication and retry on UNAUTHENTICATED.

        Args:
            stub_method: gRPC stub method to call
            request: Protobuf request message

        Returns:
            Protobuf response message

        Raises:
            grpc.aio.AioRpcError: On non-auth gRPC errors
        """
        await self.ensure_connected()

        # Authenticate if no token
        if not self.token:
            await self.authenticate()

        # Add token to metadata
        metadata = (("authorization", f"Bearer {self.token}"),)

        try:
            # Call gRPC method
            response = await stub_method(request, metadata=metadata)
            return response

        except grpc.aio.AioRpcError as e:
            # If UNAUTHENTICATED, handle based on auth mode
            if e.code() == grpc.StatusCode.UNAUTHENTICATED:
                # API_KEY mode: don't auto-refresh, fail immediately
                if self._using_api_key:
                    raise ValueError(
                        "LEGION_API_KEY rejected. Token may be revoked or expired."
                    )

                # Password mode: re-authenticate and retry
                logger.warning("Token expired, re-authenticating...")
                await self.authenticate()

                # Retry with new token
                metadata = (("authorization", f"Bearer {self.token}"),)
                response = await stub_method(request, metadata=metadata)
                return response
            else:
                # Re-raise other gRPC errors
                raise

    async def close(self) -> None:
        """Close gRPC channel."""
        if self.channel:
            await self.channel.close()
            logger.info("gRPC channel closed")


# Singleton instance
_grpc_client_manager: Optional[GrpcClientManager] = None


def get_grpc_client_manager() -> GrpcClientManager:
    """Get or create singleton GrpcClientManager instance."""
    global _grpc_client_manager
    if _grpc_client_manager is None:
        _grpc_client_manager = GrpcClientManager(
            grpc_host=os.getenv("GRPC_SERVER_HOST", GrpcClientManager.DEFAULT_GRPC_HOST),
            grpc_port=os.getenv("GRPC_SERVER_PORT", GrpcClientManager.DEFAULT_GRPC_PORT),
        )
    return _grpc_client_manager


def reset_grpc_client_manager() -> None:
    """
    Reset the singleton GrpcClientManager instance.

    IMPORTANT: Call this after asyncio.run() completes to prevent
    "Event loop is closed" errors. The gRPC channel created in one
    event loop cannot be reused in a different event loop.
    """
    global _grpc_client_manager
    _grpc_client_manager = None
