"""
Agent Context Proxy - Central interceptor for agent identity management.

This module provides session-level agent context that:
1. Tracks current agent identity (set via whoAmI)
2. Intercepts all MCP tool calls
3. Enforces identity requirement for non-exempt tools
4. Injects identity reminder into tool responses
"""

from dataclasses import dataclass
from functools import wraps
from typing import Optional, Callable, Any, Set
from loguru import logger


@dataclass
class AgentContext:
    """Current agent identity context."""

    agent_id: str
    name: str
    role: str
    reminder: str  # Key behavior, one line
    # Location context (set via whoAmI)
    company_id: Optional[str] = None
    project_id: Optional[str] = None
    project_location: Optional[str] = None  # Absolute path to project directory


class AgentContextProxy:
    """
    Central proxy for agent context management.

    Maintains session-level agent identity and intercepts tool calls to:
    - Enforce identity establishment before tool usage
    - Inject identity reminders into responses

    Usage:
        proxy = AgentContextProxy()

        # After whoAmI succeeds:
        proxy.set_context(agent_id="...", name="Arthur", role="orchestrator", reminder="...")

        # Wrap tools:
        @proxy.tool_wrapper("queryKnowledge")
        async def queryKnowledge(...):
            ...
    """

    # Tools that don't require agent context
    EXEMPT_TOOLS: Set[str] = {
        "whoAmI",
        "authenticateUser",
        "getProjects",
        "cancelDelegation",
        "getDelegationStatus",
        "listDelegations",
        "recall",
        "queryKnowledge",
        "queryExpertise",
        "queryLessons",
    }

    def __init__(self):
        self._context: Optional[AgentContext] = None
        logger.info("AgentContextProxy initialized")

    @property
    def context(self) -> Optional[AgentContext]:
        """Get current agent context."""
        return self._context

    @property
    def is_set(self) -> bool:
        """Check if agent context is established."""
        return self._context is not None

    def set_context(
        self,
        agent_id: str,
        name: str,
        role: str,
        reminder: str,
        company_id: Optional[str] = None,
        project_id: Optional[str] = None,
        project_location: Optional[str] = None,
    ) -> None:
        """
        Set agent context after successful whoAmI.

        Args:
            agent_id: Agent UUID
            name: Agent name (e.g., "Arthur")
            role: Agent role (e.g., "orchestrator")
            reminder: Key behavior reminder (one line)
            company_id: Optional company UUID for current context
            project_id: Optional project UUID for current context
            project_location: Optional absolute path to project directory
        """
        self._context = AgentContext(
            agent_id=agent_id,
            name=name,
            role=role,
            reminder=reminder,
            company_id=company_id,
            project_id=project_id,
            project_location=project_location,
        )
        logger.info(
            f"Agent context set: {name} ({role}), company={company_id}, project={project_id}"
        )

    def clear_context(self) -> None:
        """Clear agent context (e.g., on session end)."""
        if self._context:
            logger.info(f"Agent context cleared (was: {self._context.name})")
        self._context = None

    def get_identity_reminder(self) -> dict:
        """
        Get identity reminder for injection into responses.

        Returns:
            Dict with identity info if context set, otherwise action prompt
        """
        if self._context:
            result = {
                "you_are": self._context.name,
                "role": self._context.role,
                "remember": self._context.reminder,
            }
            # Include location context if set
            if self._context.company_id:
                result["company_id"] = self._context.company_id
            if self._context.project_id:
                result["project_id"] = self._context.project_id
            if self._context.project_location:
                result["project_location"] = self._context.project_location
            return result
        return {"action_required": "Call whoAmI() to establish agent identity"}

    def identity_required_response(self) -> dict:
        """
        Response returned when tool called without agent context.

        Returns:
            Dict with error info and usage instructions
        """
        return {
            "status": "identity_required",
            "error_code": "NO_AGENT_CONTEXT",
            "error_message": "Agent identity not established. You must call whoAmI() first.",
            "usage": {
                "become_orchestrator": "whoAmI() - become Arthur, the orchestrator agent",
                "become_specific_agent": "whoAmI(agent_id='<uuid>') - become a specific specialist agent",
            },
            "_identity": {"action_required": "Call whoAmI() before using other LEGION tools"},
        }

    def inject_identity(self, result: Any) -> Any:
        """
        Inject identity reminder into tool response.

        Args:
            result: Tool response (dict expected)

        Returns:
            Response with _identity field added
        """
        if isinstance(result, dict):
            result["_identity"] = self.get_identity_reminder()
        return result

    def is_exempt(self, tool_name: str) -> bool:
        """Check if tool is exempt from context requirement."""
        return tool_name in self.EXEMPT_TOOLS

    def tool_wrapper(self, tool_name: str) -> Callable:
        """
        Decorator factory for wrapping tools with context checking.

        Args:
            tool_name: Name of the tool being wrapped

        Returns:
            Decorator that wraps the tool function

        Usage:
            @proxy.tool_wrapper("queryKnowledge")
            async def queryKnowledge(...):
                ...
        """

        def decorator(func: Callable) -> Callable:
            @wraps(func)
            async def wrapper(*args, **kwargs) -> Any:
                # Exempt tools pass through without context check
                if self.is_exempt(tool_name):
                    return await func(*args, **kwargs)

                # Non-exempt tools require context
                if not self.is_set:
                    logger.warning(
                        f"Tool '{tool_name}' called without agent context - "
                        "returning identity_required response"
                    )
                    return self.identity_required_response()

                # Execute tool
                result = await func(*args, **kwargs)

                # Inject identity into response
                return self.inject_identity(result)

            return wrapper

        return decorator


# Global singleton instance
_proxy_instance: Optional[AgentContextProxy] = None


def get_agent_proxy() -> AgentContextProxy:
    """
    Get the global AgentContextProxy singleton.

    Returns:
        AgentContextProxy instance
    """
    global _proxy_instance
    if _proxy_instance is None:
        _proxy_instance = AgentContextProxy()
    return _proxy_instance


def set_agent_context(
    agent_id: str,
    name: str,
    role: str,
    reminder: str,
    company_id: Optional[str] = None,
    project_id: Optional[str] = None,
    project_location: Optional[str] = None,
) -> None:
    """
    Convenience function to set agent context on global proxy.

    Args:
        agent_id: Agent UUID
        name: Agent name
        role: Agent role
        reminder: Key behavior reminder
        company_id: Optional company UUID for current context
        project_id: Optional project UUID for current context
        project_location: Optional absolute path to project directory
    """
    get_agent_proxy().set_context(
        agent_id,
        name,
        role,
        reminder,
        company_id=company_id,
        project_id=project_id,
        project_location=project_location,
    )


def clear_agent_context() -> None:
    """Convenience function to clear agent context on global proxy."""
    get_agent_proxy().clear_context()


def require_agent_context(tool_name: str) -> Callable:
    """
    Decorator that requires agent context for a tool.

    This is a convenience decorator using the global proxy.

    Args:
        tool_name: Name of the tool

    Returns:
        Decorator function

    Usage:
        @server.tool()
        @require_agent_context("queryKnowledge")
        async def queryKnowledge(...):
            ...
    """
    return get_agent_proxy().tool_wrapper(tool_name)
