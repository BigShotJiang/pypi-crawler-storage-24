"""
Native Python hook implementations for LEGION delegations.

These hooks run within the delegation subprocess and have direct access
to the Claude Agent SDK context object.
"""

import logging
from typing import Any, Callable, Dict

logger = logging.getLogger(__name__)

# Type alias for hook functions
HookCallable = Callable[[Dict[str, Any], str, Dict[str, Any]], Dict[str, Any]]

# Flag to log context structure once for debugging
_context_logged = False


async def create_context_tracker(context_limit: int = 200000) -> HookCallable:
    """
    Create a context tracking hook for SDK delegations.

    Uses SDK's cumulative_usage from context (if available) instead of
    parsing transcript files. Returns warning messages at threshold levels.

    Args:
        context_limit: Token limit for percentage calculation (default: 200000)

    Returns:
        Async hook callable matching SDK signature.
    """

    async def hook(input_data: Dict[str, Any], tool_use_id: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Context tracking hook.

        Calculates context usage percentage and returns warning messages
        at 70%, 85%, and 95% thresholds.

        Args:
            input_data: Tool input data from SDK
            tool_use_id: Unique identifier for this tool use
            context: SDK context dict (may contain cumulative_usage)

        Returns:
            Empty dict or {"additionalContext": "warning message"}
        """
        global _context_logged

        try:
            # Defensive: ensure context is a dict
            ctx = context if isinstance(context, dict) else {}

            # Log context structure once for debugging unknown fields
            if not _context_logged:
                logger.info(f"Hook context keys (first invocation): {list(ctx.keys())}")
                _context_logged = True

            # R-2: Defensive context.get() with defaults
            cumulative_usage = ctx.get("cumulative_usage", {})
            if not isinstance(cumulative_usage, dict):
                cumulative_usage = {}

            # R-6: Include all token types per lesson fd893249
            input_tokens = cumulative_usage.get("input_tokens", 0) or 0
            output_tokens = cumulative_usage.get("output_tokens", 0) or 0
            cache_read = cumulative_usage.get("cache_read_input_tokens", 0) or 0
            cache_creation = cumulative_usage.get("cache_creation_input_tokens", 0) or 0

            total = input_tokens + output_tokens + cache_read + cache_creation

            # No usage data yet — nothing to warn about
            if total == 0:
                return {}

            percentage = (total / context_limit) * 100

            # Threshold warnings with actionable guidance
            if percentage >= 95:
                return {
                    "additionalContext": (
                        f"CONTEXT CRITICAL: {percentage:.1f}% consumed ({total:,}/{context_limit:,} tokens). "
                        f"Call remember() with summary and next_prompt IMMEDIATELY. "
                        f"You are about to hit the context limit."
                    )
                }
            elif percentage >= 85:
                return {
                    "additionalContext": (
                        f"CONTEXT WARNING: {percentage:.1f}% consumed ({total:,}/{context_limit:,} tokens). "
                        f"Prepare to call remember() soon with your current state."
                    )
                }
            elif percentage >= 70:
                return {
                    "additionalContext": (
                        f"Context notice: {percentage:.1f}% consumed ({total:,}/{context_limit:,} tokens). "
                        f"Consider wrapping up or planning for context handoff."
                    )
                }

            return {}

        except Exception as e:
            # R-1: Hook errors must NOT crash delegation
            logger.warning(f"Context tracker hook error (non-fatal): {e}")
            return {}

    return hook
