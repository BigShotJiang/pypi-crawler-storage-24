"""
Hook configuration for LEGION delegations.

Defines which hooks to attach to delegated agents via ClaudeAgentOptions.
"""

import logging
from typing import Any, Dict, List

from .native import create_context_tracker

logger = logging.getLogger(__name__)


async def get_delegation_hooks() -> Dict[str, List[Any]]:
    """
    Build hooks dict for ClaudeAgentOptions.

    Returns hooks configuration compatible with Claude Agent SDK.
    Gracefully handles missing HookMatcher class by using dict structure.

    Returns:
        Dict mapping hook event names to lists of hook matchers/configs.
        Example: {"PreToolUse": [HookMatcher(...)] or [dict(...)]}
    """
    try:
        # Create the context tracking hook
        context_hook = await create_context_tracker()

        # R-4: Try import HookMatcher, fall back to dict structure
        try:
            from claude_agent_sdk import HookMatcher

            return {
                "PreToolUse": [
                    HookMatcher(
                        matcher="",  # Match all tools
                        hooks=[context_hook],
                        timeout=5
                    )
                ]
            }
        except ImportError:
            # HookMatcher not available — use dict-based configuration
            # Claude Agent SDK may accept both formats
            logger.warning(
                "HookMatcher not found in claude_agent_sdk, using dict-based hook config"
            )
            return {
                "PreToolUse": [
                    {
                        "matcher": "",  # Match all tools
                        "hooks": [context_hook],
                        "timeout": 5
                    }
                ]
            }

    except Exception as e:
        # If hook creation fails entirely, return empty hooks
        # Delegation will proceed without context tracking
        logger.error(f"Failed to create delegation hooks: {e}")
        return {}
