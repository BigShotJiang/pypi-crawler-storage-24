"""
LEGION Hooks Module.

Provides hook callables for Claude Agent SDK delegations.
Hooks enable context tracking and other delegation-time behaviors.
"""

from .config import get_delegation_hooks

__all__ = ["get_delegation_hooks"]
