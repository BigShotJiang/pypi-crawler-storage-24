import legion_common_pb2 as _legion_common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateKnowledgeRequest(_message.Message):
    __slots__ = ("text", "user_token", "metadata", "request_id", "project_id")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    TEXT_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    text: str
    user_token: str
    metadata: _containers.ScalarMap[str, str]
    request_id: str
    project_id: str
    def __init__(self, text: _Optional[str] = ..., user_token: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., request_id: _Optional[str] = ..., project_id: _Optional[str] = ...) -> None: ...

class CreateKnowledgeResponse(_message.Message):
    __slots__ = ("status", "message", "knowledge_id", "project_id", "company_id", "title", "summary", "chunks_count", "entities_count", "relationships_count", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    KNOWLEDGE_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    CHUNKS_COUNT_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_COUNT_FIELD_NUMBER: _ClassVar[int]
    RELATIONSHIPS_COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    knowledge_id: str
    project_id: str
    company_id: str
    title: str
    summary: str
    chunks_count: int
    entities_count: int
    relationships_count: int
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., knowledge_id: _Optional[str] = ..., project_id: _Optional[str] = ..., company_id: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., chunks_count: _Optional[int] = ..., entities_count: _Optional[int] = ..., relationships_count: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class QueryKnowledgeRequest(_message.Message):
    __slots__ = ("query", "project_id", "user_token", "limit")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    query: str
    project_id: str
    user_token: str
    limit: int
    def __init__(self, query: _Optional[str] = ..., project_id: _Optional[str] = ..., user_token: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class QueryResult(_message.Message):
    __slots__ = ("id", "text", "metadata", "score", "vector_score", "rerank_score")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    VECTOR_SCORE_FIELD_NUMBER: _ClassVar[int]
    RERANK_SCORE_FIELD_NUMBER: _ClassVar[int]
    id: str
    text: str
    metadata: _containers.ScalarMap[str, str]
    score: float
    vector_score: float
    rerank_score: float
    def __init__(self, id: _Optional[str] = ..., text: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., score: _Optional[float] = ..., vector_score: _Optional[float] = ..., rerank_score: _Optional[float] = ...) -> None: ...

class QueryKnowledgeResponse(_message.Message):
    __slots__ = ("status", "query", "project_id", "results_count", "results", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    RESULTS_COUNT_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    query: str
    project_id: str
    results_count: int
    results: _containers.RepeatedCompositeFieldContainer[QueryResult]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., query: _Optional[str] = ..., project_id: _Optional[str] = ..., results_count: _Optional[int] = ..., results: _Optional[_Iterable[_Union[QueryResult, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class FastQueryRequest(_message.Message):
    __slots__ = ("query", "project_id", "user_token", "limit")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    query: str
    project_id: str
    user_token: str
    limit: int
    def __init__(self, query: _Optional[str] = ..., project_id: _Optional[str] = ..., user_token: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class SearchByTagsRequest(_message.Message):
    __slots__ = ("project_id", "user_token", "keywords", "chunk_type", "has_code", "section_title", "section_level", "limit", "offset")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    KEYWORDS_FIELD_NUMBER: _ClassVar[int]
    CHUNK_TYPE_FIELD_NUMBER: _ClassVar[int]
    HAS_CODE_FIELD_NUMBER: _ClassVar[int]
    SECTION_TITLE_FIELD_NUMBER: _ClassVar[int]
    SECTION_LEVEL_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    user_token: str
    keywords: _containers.RepeatedScalarFieldContainer[str]
    chunk_type: str
    has_code: bool
    section_title: str
    section_level: int
    limit: int
    offset: int
    def __init__(self, project_id: _Optional[str] = ..., user_token: _Optional[str] = ..., keywords: _Optional[_Iterable[str]] = ..., chunk_type: _Optional[str] = ..., has_code: bool = ..., section_title: _Optional[str] = ..., section_level: _Optional[int] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class ExploreGraphRequest(_message.Message):
    __slots__ = ("cypher", "project_id", "user_token", "params", "limit")
    class ParamsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    CYPHER_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    cypher: str
    project_id: str
    user_token: str
    params: _containers.ScalarMap[str, str]
    limit: int
    def __init__(self, cypher: _Optional[str] = ..., project_id: _Optional[str] = ..., user_token: _Optional[str] = ..., params: _Optional[_Mapping[str, str]] = ..., limit: _Optional[int] = ...) -> None: ...

class GraphQueryResult(_message.Message):
    __slots__ = ("fields",)
    class FieldsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    FIELDS_FIELD_NUMBER: _ClassVar[int]
    fields: _containers.ScalarMap[str, str]
    def __init__(self, fields: _Optional[_Mapping[str, str]] = ...) -> None: ...

class ExploreGraphResponse(_message.Message):
    __slots__ = ("status", "query", "project_id", "results_count", "results", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    RESULTS_COUNT_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    query: str
    project_id: str
    results_count: int
    results: _containers.RepeatedCompositeFieldContainer[GraphQueryResult]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., query: _Optional[str] = ..., project_id: _Optional[str] = ..., results_count: _Optional[int] = ..., results: _Optional[_Iterable[_Union[GraphQueryResult, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...
