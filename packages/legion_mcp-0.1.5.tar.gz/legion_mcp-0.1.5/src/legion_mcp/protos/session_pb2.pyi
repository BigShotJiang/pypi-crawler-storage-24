from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class UpsertSessionRequest(_message.Message):
    __slots__ = ("user_token", "session_id", "agent_id", "company_id", "project_id", "engagement_id", "task_id", "entry_id", "turn_number", "extraction", "model_primary", "total_input_tokens", "total_output_tokens")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_NUMBER_FIELD_NUMBER: _ClassVar[int]
    EXTRACTION_FIELD_NUMBER: _ClassVar[int]
    MODEL_PRIMARY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    session_id: str
    agent_id: str
    company_id: str
    project_id: str
    engagement_id: str
    task_id: str
    entry_id: str
    turn_number: int
    extraction: str
    model_primary: str
    total_input_tokens: int
    total_output_tokens: int
    def __init__(self, user_token: _Optional[str] = ..., session_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., engagement_id: _Optional[str] = ..., task_id: _Optional[str] = ..., entry_id: _Optional[str] = ..., turn_number: _Optional[int] = ..., extraction: _Optional[str] = ..., model_primary: _Optional[str] = ..., total_input_tokens: _Optional[int] = ..., total_output_tokens: _Optional[int] = ...) -> None: ...

class UpsertSessionResponse(_message.Message):
    __slots__ = ("status", "id", "session_id", "created", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    id: str
    session_id: str
    created: bool
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., id: _Optional[str] = ..., session_id: _Optional[str] = ..., created: bool = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetSessionRequest(_message.Message):
    __slots__ = ("user_token", "session_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    session_id: str
    def __init__(self, user_token: _Optional[str] = ..., session_id: _Optional[str] = ...) -> None: ...

class GetSessionResponse(_message.Message):
    __slots__ = ("status", "session", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SESSION_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    session: SessionRecord
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., session: _Optional[_Union[SessionRecord, _Mapping]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ListSessionsRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "agent_id", "engagement_id", "status_filter", "limit", "offset")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    agent_id: str
    engagement_id: str
    status_filter: str
    limit: int
    offset: int
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., engagement_id: _Optional[str] = ..., status_filter: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class ListSessionsResponse(_message.Message):
    __slots__ = ("status", "total_count", "sessions", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    SESSIONS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    total_count: int
    sessions: _containers.RepeatedCompositeFieldContainer[SessionRecord]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., total_count: _Optional[int] = ..., sessions: _Optional[_Iterable[_Union[SessionRecord, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UpdateSessionStatusRequest(_message.Message):
    __slots__ = ("user_token", "session_id", "new_status")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    NEW_STATUS_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    session_id: str
    new_status: str
    def __init__(self, user_token: _Optional[str] = ..., session_id: _Optional[str] = ..., new_status: _Optional[str] = ...) -> None: ...

class UpdateSessionStatusResponse(_message.Message):
    __slots__ = ("status", "session_id", "new_status", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    NEW_STATUS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    session_id: str
    new_status: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., session_id: _Optional[str] = ..., new_status: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class SessionRecord(_message.Message):
    __slots__ = ("id", "session_id", "user_id", "agent_id", "company_id", "project_id", "engagement_id", "task_id", "entry_id", "turn_number", "extraction", "model_primary", "total_input_tokens", "total_output_tokens", "status", "started_at", "last_turn_at", "completed_at", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    TURN_NUMBER_FIELD_NUMBER: _ClassVar[int]
    EXTRACTION_FIELD_NUMBER: _ClassVar[int]
    MODEL_PRIMARY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_TURN_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    session_id: str
    user_id: str
    agent_id: str
    company_id: str
    project_id: str
    engagement_id: str
    task_id: str
    entry_id: str
    turn_number: int
    extraction: str
    model_primary: str
    total_input_tokens: int
    total_output_tokens: int
    status: str
    started_at: str
    last_turn_at: str
    completed_at: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., session_id: _Optional[str] = ..., user_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., engagement_id: _Optional[str] = ..., task_id: _Optional[str] = ..., entry_id: _Optional[str] = ..., turn_number: _Optional[int] = ..., extraction: _Optional[str] = ..., model_primary: _Optional[str] = ..., total_input_tokens: _Optional[int] = ..., total_output_tokens: _Optional[int] = ..., status: _Optional[str] = ..., started_at: _Optional[str] = ..., last_turn_at: _Optional[str] = ..., completed_at: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...
