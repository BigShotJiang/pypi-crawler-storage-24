import legion_common_pb2 as _legion_common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateExpertiseRequest(_message.Message):
    __slots__ = ("text", "user_token", "project_id", "metadata", "request_id", "company_id", "when_to_use")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    TEXT_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    text: str
    user_token: str
    project_id: str
    metadata: _containers.ScalarMap[str, str]
    request_id: str
    company_id: str
    when_to_use: str
    def __init__(self, text: _Optional[str] = ..., user_token: _Optional[str] = ..., project_id: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., request_id: _Optional[str] = ..., company_id: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class CreateExpertiseResponse(_message.Message):
    __slots__ = ("status", "message", "expertise_id", "project_id", "company_id", "title", "summary", "chunks_count", "entities_count", "relationships_count", "error_message", "error_code", "when_to_use")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    CHUNKS_COUNT_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_COUNT_FIELD_NUMBER: _ClassVar[int]
    RELATIONSHIPS_COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    expertise_id: str
    project_id: str
    company_id: str
    title: str
    summary: str
    chunks_count: int
    entities_count: int
    relationships_count: int
    error_message: str
    error_code: str
    when_to_use: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., expertise_id: _Optional[str] = ..., project_id: _Optional[str] = ..., company_id: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., chunks_count: _Optional[int] = ..., entities_count: _Optional[int] = ..., relationships_count: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class AddExpertiseChunkRequest(_message.Message):
    __slots__ = ("expertise_id", "content", "user_token", "parent_chunk_id", "project_id")
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PARENT_CHUNK_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    expertise_id: str
    content: str
    user_token: str
    parent_chunk_id: str
    project_id: str
    def __init__(self, expertise_id: _Optional[str] = ..., content: _Optional[str] = ..., user_token: _Optional[str] = ..., parent_chunk_id: _Optional[str] = ..., project_id: _Optional[str] = ...) -> None: ...

class AddExpertiseChunkResponse(_message.Message):
    __slots__ = ("status", "message", "chunk_id", "expertise_id", "parent_chunk_id", "level", "position", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    CHUNK_ID_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    PARENT_CHUNK_ID_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    chunk_id: str
    expertise_id: str
    parent_chunk_id: str
    level: int
    position: int
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., chunk_id: _Optional[str] = ..., expertise_id: _Optional[str] = ..., parent_chunk_id: _Optional[str] = ..., level: _Optional[int] = ..., position: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class QueryExpertiseRequest(_message.Message):
    __slots__ = ("query", "user_token", "project_id", "limit", "company_id")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    query: str
    user_token: str
    project_id: str
    limit: int
    company_id: str
    def __init__(self, query: _Optional[str] = ..., user_token: _Optional[str] = ..., project_id: _Optional[str] = ..., limit: _Optional[int] = ..., company_id: _Optional[str] = ...) -> None: ...

class QueryExpertiseResponse(_message.Message):
    __slots__ = ("status", "query", "project_id", "results_count", "results", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    RESULTS_COUNT_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    query: str
    project_id: str
    results_count: int
    results: _containers.RepeatedCompositeFieldContainer[_legion_common_pb2.QueryResult]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., query: _Optional[str] = ..., project_id: _Optional[str] = ..., results_count: _Optional[int] = ..., results: _Optional[_Iterable[_Union[_legion_common_pb2.QueryResult, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ListExpertiseRequest(_message.Message):
    __slots__ = ("user_token", "project_id", "limit", "offset", "company_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    project_id: str
    limit: int
    offset: int
    company_id: str
    def __init__(self, user_token: _Optional[str] = ..., project_id: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., company_id: _Optional[str] = ...) -> None: ...

class ExpertiseInfo(_message.Message):
    __slots__ = ("expertise_id", "title", "summary", "chunks_count", "created_at", "updated_at", "when_to_use")
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    CHUNKS_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    expertise_id: str
    title: str
    summary: str
    chunks_count: int
    created_at: str
    updated_at: str
    when_to_use: str
    def __init__(self, expertise_id: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., chunks_count: _Optional[int] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class ListExpertiseResponse(_message.Message):
    __slots__ = ("status", "project_id", "total_count", "expertise_list", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_LIST_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    project_id: str
    total_count: int
    expertise_list: _containers.RepeatedCompositeFieldContainer[ExpertiseInfo]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., project_id: _Optional[str] = ..., total_count: _Optional[int] = ..., expertise_list: _Optional[_Iterable[_Union[ExpertiseInfo, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetExpertiseRequest(_message.Message):
    __slots__ = ("user_token", "expertise_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    expertise_id: str
    def __init__(self, user_token: _Optional[str] = ..., expertise_id: _Optional[str] = ...) -> None: ...

class GetExpertiseResponse(_message.Message):
    __slots__ = ("status", "expertise_id", "title", "summary", "content", "chunks_count", "project_id", "company_id", "created_at", "updated_at", "error_message", "error_code", "when_to_use")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    CHUNKS_COUNT_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    status: str
    expertise_id: str
    title: str
    summary: str
    content: str
    chunks_count: int
    project_id: str
    company_id: str
    created_at: str
    updated_at: str
    error_message: str
    error_code: str
    when_to_use: str
    def __init__(self, status: _Optional[str] = ..., expertise_id: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., content: _Optional[str] = ..., chunks_count: _Optional[int] = ..., project_id: _Optional[str] = ..., company_id: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class UpdateExpertiseRequest(_message.Message):
    __slots__ = ("user_token", "expertise_id", "when_to_use", "when_to_use_provided")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    expertise_id: str
    when_to_use: str
    when_to_use_provided: bool
    def __init__(self, user_token: _Optional[str] = ..., expertise_id: _Optional[str] = ..., when_to_use: _Optional[str] = ..., when_to_use_provided: bool = ...) -> None: ...

class UpdateExpertiseResponse(_message.Message):
    __slots__ = ("status", "expertise_id", "title", "when_to_use", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    expertise_id: str
    title: str
    when_to_use: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., expertise_id: _Optional[str] = ..., title: _Optional[str] = ..., when_to_use: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...
