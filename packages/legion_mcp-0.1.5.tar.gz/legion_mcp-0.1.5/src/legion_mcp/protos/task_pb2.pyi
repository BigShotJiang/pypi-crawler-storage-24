from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateTaskRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "project_id", "title", "description", "engagement_id", "priority", "assigned_agent_id", "created_by_agent_id", "ultimate_goal")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    ASSIGNED_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    project_id: str
    title: str
    description: str
    engagement_id: str
    priority: str
    assigned_agent_id: str
    created_by_agent_id: str
    ultimate_goal: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., engagement_id: _Optional[str] = ..., priority: _Optional[str] = ..., assigned_agent_id: _Optional[str] = ..., created_by_agent_id: _Optional[str] = ..., ultimate_goal: _Optional[str] = ...) -> None: ...

class CreateTaskResponse(_message.Message):
    __slots__ = ("status", "message", "task_id", "title", "task_status", "priority", "created_at", "error_message", "error_code", "ultimate_goal")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    TASK_STATUS_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    task_id: str
    title: str
    task_status: str
    priority: str
    created_at: str
    error_message: str
    error_code: str
    ultimate_goal: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., task_id: _Optional[str] = ..., title: _Optional[str] = ..., task_status: _Optional[str] = ..., priority: _Optional[str] = ..., created_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., ultimate_goal: _Optional[str] = ...) -> None: ...

class GetTaskRequest(_message.Message):
    __slots__ = ("user_token", "task_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    task_id: str
    def __init__(self, user_token: _Optional[str] = ..., task_id: _Optional[str] = ...) -> None: ...

class ArtifactInfo(_message.Message):
    __slots__ = ("id", "artifact_type", "artifact_id", "linked_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_TYPE_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    LINKED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    artifact_type: str
    artifact_id: str
    linked_at: str
    def __init__(self, id: _Optional[str] = ..., artifact_type: _Optional[str] = ..., artifact_id: _Optional[str] = ..., linked_at: _Optional[str] = ...) -> None: ...

class GetTaskResponse(_message.Message):
    __slots__ = ("status", "task_id", "title", "description", "task_status", "priority", "company_id", "project_id", "engagement_id", "assigned_agent_id", "created_by_agent_id", "blockers", "artifacts", "created_at", "updated_at", "completed_at", "error_message", "error_code", "ultimate_goal")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TASK_STATUS_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ASSIGNED_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    BLOCKERS_FIELD_NUMBER: _ClassVar[int]
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    status: str
    task_id: str
    title: str
    description: str
    task_status: str
    priority: str
    company_id: str
    project_id: str
    engagement_id: str
    assigned_agent_id: str
    created_by_agent_id: str
    blockers: str
    artifacts: _containers.RepeatedCompositeFieldContainer[ArtifactInfo]
    created_at: str
    updated_at: str
    completed_at: str
    error_message: str
    error_code: str
    ultimate_goal: str
    def __init__(self, status: _Optional[str] = ..., task_id: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., task_status: _Optional[str] = ..., priority: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., engagement_id: _Optional[str] = ..., assigned_agent_id: _Optional[str] = ..., created_by_agent_id: _Optional[str] = ..., blockers: _Optional[str] = ..., artifacts: _Optional[_Iterable[_Union[ArtifactInfo, _Mapping]]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., completed_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., ultimate_goal: _Optional[str] = ...) -> None: ...

class ListTasksRequest(_message.Message):
    __slots__ = ("user_token", "project_id", "engagement_id", "agent_id", "status", "limit", "offset")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    project_id: str
    engagement_id: str
    agent_id: str
    status: str
    limit: int
    offset: int
    def __init__(self, user_token: _Optional[str] = ..., project_id: _Optional[str] = ..., engagement_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., status: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class TaskInfo(_message.Message):
    __slots__ = ("id", "title", "description", "status", "priority", "company_id", "project_id", "engagement_id", "assigned_agent_id", "created_by_agent_id", "blockers", "created_at", "updated_at", "completed_at", "ultimate_goal")
    ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ASSIGNED_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    BLOCKERS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    id: str
    title: str
    description: str
    status: str
    priority: str
    company_id: str
    project_id: str
    engagement_id: str
    assigned_agent_id: str
    created_by_agent_id: str
    blockers: str
    created_at: str
    updated_at: str
    completed_at: str
    ultimate_goal: str
    def __init__(self, id: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., status: _Optional[str] = ..., priority: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., engagement_id: _Optional[str] = ..., assigned_agent_id: _Optional[str] = ..., created_by_agent_id: _Optional[str] = ..., blockers: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., completed_at: _Optional[str] = ..., ultimate_goal: _Optional[str] = ...) -> None: ...

class ListTasksResponse(_message.Message):
    __slots__ = ("status", "total_count", "tasks", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    total_count: int
    tasks: _containers.RepeatedCompositeFieldContainer[TaskInfo]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., total_count: _Optional[int] = ..., tasks: _Optional[_Iterable[_Union[TaskInfo, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UpdateTaskRequest(_message.Message):
    __slots__ = ("user_token", "task_id", "status", "assigned_agent_id", "blockers", "priority", "ultimate_goal")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ASSIGNED_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    BLOCKERS_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    task_id: str
    status: str
    assigned_agent_id: str
    blockers: str
    priority: str
    ultimate_goal: str
    def __init__(self, user_token: _Optional[str] = ..., task_id: _Optional[str] = ..., status: _Optional[str] = ..., assigned_agent_id: _Optional[str] = ..., blockers: _Optional[str] = ..., priority: _Optional[str] = ..., ultimate_goal: _Optional[str] = ...) -> None: ...

class UpdateTaskResponse(_message.Message):
    __slots__ = ("status", "message", "task_id", "task_status", "priority", "updated_at", "error_message", "error_code", "ultimate_goal")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_STATUS_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    task_id: str
    task_status: str
    priority: str
    updated_at: str
    error_message: str
    error_code: str
    ultimate_goal: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., task_id: _Optional[str] = ..., task_status: _Optional[str] = ..., priority: _Optional[str] = ..., updated_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., ultimate_goal: _Optional[str] = ...) -> None: ...

class AssignTaskRequest(_message.Message):
    __slots__ = ("user_token", "task_id", "agent_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    task_id: str
    agent_id: str
    def __init__(self, user_token: _Optional[str] = ..., task_id: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class AssignTaskResponse(_message.Message):
    __slots__ = ("status", "message", "task_id", "assigned_agent_id", "task_status", "updated_at", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ASSIGNED_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_STATUS_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    task_id: str
    assigned_agent_id: str
    task_status: str
    updated_at: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., task_id: _Optional[str] = ..., assigned_agent_id: _Optional[str] = ..., task_status: _Optional[str] = ..., updated_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class CompleteTaskRequest(_message.Message):
    __slots__ = ("user_token", "task_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    task_id: str
    def __init__(self, user_token: _Optional[str] = ..., task_id: _Optional[str] = ...) -> None: ...

class CompleteTaskResponse(_message.Message):
    __slots__ = ("status", "message", "task_id", "task_status", "completed_at", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_STATUS_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    task_id: str
    task_status: str
    completed_at: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., task_id: _Optional[str] = ..., task_status: _Optional[str] = ..., completed_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class LinkArtifactRequest(_message.Message):
    __slots__ = ("user_token", "task_id", "artifact_type", "artifact_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_TYPE_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    task_id: str
    artifact_type: str
    artifact_id: str
    def __init__(self, user_token: _Optional[str] = ..., task_id: _Optional[str] = ..., artifact_type: _Optional[str] = ..., artifact_id: _Optional[str] = ...) -> None: ...

class LinkArtifactResponse(_message.Message):
    __slots__ = ("status", "message", "link_id", "task_id", "artifact_type", "artifact_id", "linked_at", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    LINK_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_TYPE_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_ID_FIELD_NUMBER: _ClassVar[int]
    LINKED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    link_id: str
    task_id: str
    artifact_type: str
    artifact_id: str
    linked_at: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., link_id: _Optional[str] = ..., task_id: _Optional[str] = ..., artifact_type: _Optional[str] = ..., artifact_id: _Optional[str] = ..., linked_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetArtifactsRequest(_message.Message):
    __slots__ = ("user_token", "task_id", "artifact_type")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_TYPE_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    task_id: str
    artifact_type: str
    def __init__(self, user_token: _Optional[str] = ..., task_id: _Optional[str] = ..., artifact_type: _Optional[str] = ...) -> None: ...

class GetArtifactsResponse(_message.Message):
    __slots__ = ("status", "task_id", "total_count", "artifacts", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    task_id: str
    total_count: int
    artifacts: _containers.RepeatedCompositeFieldContainer[ArtifactInfo]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., task_id: _Optional[str] = ..., total_count: _Optional[int] = ..., artifacts: _Optional[_Iterable[_Union[ArtifactInfo, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...
