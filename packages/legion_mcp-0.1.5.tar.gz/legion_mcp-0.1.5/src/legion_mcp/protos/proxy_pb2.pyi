from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StartProxyRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "project_id", "port", "proxy_path", "log_level", "host")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    PROXY_PATH_FIELD_NUMBER: _ClassVar[int]
    LOG_LEVEL_FIELD_NUMBER: _ClassVar[int]
    HOST_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    project_id: str
    port: int
    proxy_path: str
    log_level: str
    host: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., port: _Optional[int] = ..., proxy_path: _Optional[str] = ..., log_level: _Optional[str] = ..., host: _Optional[str] = ...) -> None: ...

class StartProxyResponse(_message.Message):
    __slots__ = ("status", "proxy_id", "pid", "port", "message", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    proxy_id: str
    pid: int
    port: int
    message: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., proxy_id: _Optional[str] = ..., pid: _Optional[int] = ..., port: _Optional[int] = ..., message: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class StopProxyRequest(_message.Message):
    __slots__ = ("user_token", "proxy_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    proxy_id: str
    def __init__(self, user_token: _Optional[str] = ..., proxy_id: _Optional[str] = ...) -> None: ...

class StopProxyResponse(_message.Message):
    __slots__ = ("status", "message", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetProxyStatusRequest(_message.Message):
    __slots__ = ("user_token", "proxy_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    proxy_id: str
    def __init__(self, user_token: _Optional[str] = ..., proxy_id: _Optional[str] = ...) -> None: ...

class ProxyStatusResponse(_message.Message):
    __slots__ = ("status", "proxy_id", "proxy_status", "name", "host", "port", "pid", "port_healthy", "started_at", "uptime_seconds", "last_heartbeat", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    PROXY_STATUS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HOST_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PORT_HEALTHY_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    UPTIME_SECONDS_FIELD_NUMBER: _ClassVar[int]
    LAST_HEARTBEAT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    proxy_id: str
    proxy_status: str
    name: str
    host: str
    port: int
    pid: int
    port_healthy: bool
    started_at: str
    uptime_seconds: str
    last_heartbeat: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., proxy_id: _Optional[str] = ..., proxy_status: _Optional[str] = ..., name: _Optional[str] = ..., host: _Optional[str] = ..., port: _Optional[int] = ..., pid: _Optional[int] = ..., port_healthy: bool = ..., started_at: _Optional[str] = ..., uptime_seconds: _Optional[str] = ..., last_heartbeat: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ListProxiesRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "project_id", "status_filter")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    project_id: str
    status_filter: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., status_filter: _Optional[str] = ...) -> None: ...

class ProxyInfo(_message.Message):
    __slots__ = ("proxy_id", "name", "host", "port", "status", "started_at", "updated_at")
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HOST_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    proxy_id: str
    name: str
    host: str
    port: int
    status: str
    started_at: str
    updated_at: str
    def __init__(self, proxy_id: _Optional[str] = ..., name: _Optional[str] = ..., host: _Optional[str] = ..., port: _Optional[int] = ..., status: _Optional[str] = ..., started_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class ListProxiesResponse(_message.Message):
    __slots__ = ("status", "total_count", "proxies", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    PROXIES_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    total_count: int
    proxies: _containers.RepeatedCompositeFieldContainer[ProxyInfo]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., total_count: _Optional[int] = ..., proxies: _Optional[_Iterable[_Union[ProxyInfo, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ProxyHeartbeatRequest(_message.Message):
    __slots__ = ("proxy_id", "owner_id")
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    proxy_id: str
    owner_id: str
    def __init__(self, proxy_id: _Optional[str] = ..., owner_id: _Optional[str] = ...) -> None: ...

class ProxyHeartbeatResponse(_message.Message):
    __slots__ = ("status", "success", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    success: bool
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., success: bool = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class CleanupOrphanedRequest(_message.Message):
    __slots__ = ("company_id", "heartbeat_timeout_seconds")
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    HEARTBEAT_TIMEOUT_SECONDS_FIELD_NUMBER: _ClassVar[int]
    company_id: str
    heartbeat_timeout_seconds: int
    def __init__(self, company_id: _Optional[str] = ..., heartbeat_timeout_seconds: _Optional[int] = ...) -> None: ...

class CleanupOrphanedResponse(_message.Message):
    __slots__ = ("status", "proxies_cleaned", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROXIES_CLEANED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    proxies_cleaned: int
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., proxies_cleaned: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class RequestStopProxyRequest(_message.Message):
    __slots__ = ("user_token", "proxy_id", "company_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    proxy_id: str
    company_id: str
    def __init__(self, user_token: _Optional[str] = ..., proxy_id: _Optional[str] = ..., company_id: _Optional[str] = ...) -> None: ...

class RequestStopProxyResponse(_message.Message):
    __slots__ = ("status", "proxy_id", "message", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    proxy_id: str
    message: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., proxy_id: _Optional[str] = ..., message: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...
