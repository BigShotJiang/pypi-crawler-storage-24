from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateDelegationRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "project_id", "agent_id", "task_id", "task_description", "context")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    project_id: str
    agent_id: str
    task_id: str
    task_description: str
    context: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., task_id: _Optional[str] = ..., task_description: _Optional[str] = ..., context: _Optional[str] = ...) -> None: ...

class CreateDelegationResponse(_message.Message):
    __slots__ = ("status", "message", "delegation_id", "agent_name", "agent_role", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ROLE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    delegation_id: str
    agent_name: str
    agent_role: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., delegation_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., agent_role: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetDelegationStatusRequest(_message.Message):
    __slots__ = ("user_token", "delegation_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    delegation_id: str
    def __init__(self, user_token: _Optional[str] = ..., delegation_id: _Optional[str] = ...) -> None: ...

class ProgressStep(_message.Message):
    __slots__ = ("step", "tool", "input_summary", "timestamp")
    STEP_FIELD_NUMBER: _ClassVar[int]
    TOOL_FIELD_NUMBER: _ClassVar[int]
    INPUT_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    step: int
    tool: str
    input_summary: str
    timestamp: str
    def __init__(self, step: _Optional[int] = ..., tool: _Optional[str] = ..., input_summary: _Optional[str] = ..., timestamp: _Optional[str] = ...) -> None: ...

class DelegationStatus(_message.Message):
    __slots__ = ("status", "delegation_id", "delegation_status", "agent_name", "agent_role", "current_action", "steps_completed", "progress", "started_at", "updated_at", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ROLE_FIELD_NUMBER: _ClassVar[int]
    CURRENT_ACTION_FIELD_NUMBER: _ClassVar[int]
    STEPS_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    delegation_id: str
    delegation_status: str
    agent_name: str
    agent_role: str
    current_action: str
    steps_completed: int
    progress: _containers.RepeatedCompositeFieldContainer[ProgressStep]
    started_at: str
    updated_at: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., delegation_id: _Optional[str] = ..., delegation_status: _Optional[str] = ..., agent_name: _Optional[str] = ..., agent_role: _Optional[str] = ..., current_action: _Optional[str] = ..., steps_completed: _Optional[int] = ..., progress: _Optional[_Iterable[_Union[ProgressStep, _Mapping]]] = ..., started_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class DelegationStatusBrief(_message.Message):
    __slots__ = ("status", "delegation_status", "step_number", "step_description", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_STATUS_FIELD_NUMBER: _ClassVar[int]
    STEP_NUMBER_FIELD_NUMBER: _ClassVar[int]
    STEP_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    delegation_status: str
    step_number: int
    step_description: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., delegation_status: _Optional[str] = ..., step_number: _Optional[int] = ..., step_description: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetDelegationResultRequest(_message.Message):
    __slots__ = ("user_token", "delegation_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    delegation_id: str
    def __init__(self, user_token: _Optional[str] = ..., delegation_id: _Optional[str] = ...) -> None: ...

class DelegationResult(_message.Message):
    __slots__ = ("status", "delegation_id", "delegation_status", "agent_name", "agent_role", "result_summary", "tools_used", "turns", "cost_usd", "error_detail", "started_at", "completed_at", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ROLE_FIELD_NUMBER: _ClassVar[int]
    RESULT_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    TOOLS_USED_FIELD_NUMBER: _ClassVar[int]
    TURNS_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    ERROR_DETAIL_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    delegation_id: str
    delegation_status: str
    agent_name: str
    agent_role: str
    result_summary: str
    tools_used: _containers.RepeatedScalarFieldContainer[str]
    turns: int
    cost_usd: float
    error_detail: str
    started_at: str
    completed_at: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., delegation_id: _Optional[str] = ..., delegation_status: _Optional[str] = ..., agent_name: _Optional[str] = ..., agent_role: _Optional[str] = ..., result_summary: _Optional[str] = ..., tools_used: _Optional[_Iterable[str]] = ..., turns: _Optional[int] = ..., cost_usd: _Optional[float] = ..., error_detail: _Optional[str] = ..., started_at: _Optional[str] = ..., completed_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UpdateProgressRequest(_message.Message):
    __slots__ = ("delegation_id", "current_action", "step")
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    CURRENT_ACTION_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    delegation_id: str
    current_action: str
    step: ProgressStep
    def __init__(self, delegation_id: _Optional[str] = ..., current_action: _Optional[str] = ..., step: _Optional[_Union[ProgressStep, _Mapping]] = ...) -> None: ...

class UpdateProgressResponse(_message.Message):
    __slots__ = ("status", "steps_completed", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STEPS_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    steps_completed: int
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., steps_completed: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UpdateStatusRequest(_message.Message):
    __slots__ = ("delegation_id", "new_status", "result_summary", "tools_used", "turns", "cost_usd", "error_message")
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    NEW_STATUS_FIELD_NUMBER: _ClassVar[int]
    RESULT_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    TOOLS_USED_FIELD_NUMBER: _ClassVar[int]
    TURNS_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    delegation_id: str
    new_status: str
    result_summary: str
    tools_used: _containers.RepeatedScalarFieldContainer[str]
    turns: int
    cost_usd: float
    error_message: str
    def __init__(self, delegation_id: _Optional[str] = ..., new_status: _Optional[str] = ..., result_summary: _Optional[str] = ..., tools_used: _Optional[_Iterable[str]] = ..., turns: _Optional[int] = ..., cost_usd: _Optional[float] = ..., error_message: _Optional[str] = ...) -> None: ...

class UpdateStatusResponse(_message.Message):
    __slots__ = ("status", "delegation_status", "updated_at", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DELEGATION_STATUS_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    delegation_status: str
    updated_at: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., delegation_status: _Optional[str] = ..., updated_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class MarkInterruptedRequest(_message.Message):
    __slots__ = ("company_id", "owner_id")
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    company_id: str
    owner_id: str
    def __init__(self, company_id: _Optional[str] = ..., owner_id: _Optional[str] = ...) -> None: ...

class MarkInterruptedResponse(_message.Message):
    __slots__ = ("status", "delegations_marked", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DELEGATIONS_MARKED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    delegations_marked: int
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., delegations_marked: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ClaimDelegationRequest(_message.Message):
    __slots__ = ("delegation_id", "owner_id")
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    delegation_id: str
    owner_id: str
    def __init__(self, delegation_id: _Optional[str] = ..., owner_id: _Optional[str] = ...) -> None: ...

class ClaimDelegationResponse(_message.Message):
    __slots__ = ("status", "claimed", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CLAIMED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    claimed: bool
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., claimed: bool = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UpdateHeartbeatRequest(_message.Message):
    __slots__ = ("delegation_id", "owner_id")
    DELEGATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_ID_FIELD_NUMBER: _ClassVar[int]
    delegation_id: str
    owner_id: str
    def __init__(self, delegation_id: _Optional[str] = ..., owner_id: _Optional[str] = ...) -> None: ...

class UpdateHeartbeatResponse(_message.Message):
    __slots__ = ("status", "success", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    success: bool
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., success: bool = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ListDelegationsRequest(_message.Message):
    __slots__ = ("user_token", "project_id", "agent_id", "status_filter", "limit", "offset")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    project_id: str
    agent_id: str
    status_filter: str
    limit: int
    offset: int
    def __init__(self, user_token: _Optional[str] = ..., project_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., status_filter: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class DelegationInfo(_message.Message):
    __slots__ = ("id", "agent_name", "agent_role", "status", "task_summary", "steps_completed", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ROLE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TASK_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    STEPS_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    agent_name: str
    agent_role: str
    status: str
    task_summary: str
    steps_completed: int
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., agent_name: _Optional[str] = ..., agent_role: _Optional[str] = ..., status: _Optional[str] = ..., task_summary: _Optional[str] = ..., steps_completed: _Optional[int] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class ListDelegationsResponse(_message.Message):
    __slots__ = ("status", "total_count", "delegations", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    DELEGATIONS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    total_count: int
    delegations: _containers.RepeatedCompositeFieldContainer[DelegationInfo]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., total_count: _Optional[int] = ..., delegations: _Optional[_Iterable[_Union[DelegationInfo, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...
