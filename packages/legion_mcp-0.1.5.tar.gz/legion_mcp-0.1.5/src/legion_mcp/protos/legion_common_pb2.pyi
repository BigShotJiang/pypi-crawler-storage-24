from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class ErrorResponse(_message.Message):
    __slots__ = ("is_error", "error", "error_code", "retryable")
    IS_ERROR_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    RETRYABLE_FIELD_NUMBER: _ClassVar[int]
    is_error: bool
    error: str
    error_code: str
    retryable: bool
    def __init__(self, is_error: bool = ..., error: _Optional[str] = ..., error_code: _Optional[str] = ..., retryable: bool = ...) -> None: ...

class QueryResult(_message.Message):
    __slots__ = ("id", "text", "metadata", "score", "vector_score", "rerank_score")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    VECTOR_SCORE_FIELD_NUMBER: _ClassVar[int]
    RERANK_SCORE_FIELD_NUMBER: _ClassVar[int]
    id: str
    text: str
    metadata: _containers.ScalarMap[str, str]
    score: float
    vector_score: float
    rerank_score: float
    def __init__(self, id: _Optional[str] = ..., text: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., score: _Optional[float] = ..., vector_score: _Optional[float] = ..., rerank_score: _Optional[float] = ...) -> None: ...
