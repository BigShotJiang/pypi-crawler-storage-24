import legion_common_pb2 as _legion_common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateEngagementRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "project_id", "name", "agent_id", "user_id", "summary", "ultimate_goal", "engagement_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    project_id: str
    name: str
    agent_id: str
    user_id: str
    summary: str
    ultimate_goal: str
    engagement_id: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., name: _Optional[str] = ..., agent_id: _Optional[str] = ..., user_id: _Optional[str] = ..., summary: _Optional[str] = ..., ultimate_goal: _Optional[str] = ..., engagement_id: _Optional[str] = ...) -> None: ...

class CreateEngagementResponse(_message.Message):
    __slots__ = ("status", "message", "engagement_id", "name", "engagement_status", "created_at", "error_message", "error_code", "ultimate_goal", "parent_engagement_id")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    PARENT_ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    engagement_id: str
    name: str
    engagement_status: str
    created_at: str
    error_message: str
    error_code: str
    ultimate_goal: str
    parent_engagement_id: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., engagement_id: _Optional[str] = ..., name: _Optional[str] = ..., engagement_status: _Optional[str] = ..., created_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., ultimate_goal: _Optional[str] = ..., parent_engagement_id: _Optional[str] = ...) -> None: ...

class GetEngagementRequest(_message.Message):
    __slots__ = ("user_token", "engagement_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    engagement_id: str
    def __init__(self, user_token: _Optional[str] = ..., engagement_id: _Optional[str] = ...) -> None: ...

class EngagementEntryInfo(_message.Message):
    __slots__ = ("id", "entry_type", "title", "content_preview", "created_by_agent_id", "created_at", "content_length", "references", "tags", "summary", "version")
    ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    CONTENT_LENGTH_FIELD_NUMBER: _ClassVar[int]
    REFERENCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    id: str
    entry_type: str
    title: str
    content_preview: str
    created_by_agent_id: str
    created_at: str
    content_length: int
    references: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    summary: str
    version: int
    def __init__(self, id: _Optional[str] = ..., entry_type: _Optional[str] = ..., title: _Optional[str] = ..., content_preview: _Optional[str] = ..., created_by_agent_id: _Optional[str] = ..., created_at: _Optional[str] = ..., content_length: _Optional[int] = ..., references: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., summary: _Optional[str] = ..., version: _Optional[int] = ...) -> None: ...

class EngagementEntryFull(_message.Message):
    __slots__ = ("id", "engagement_id", "entry_type", "title", "content", "created_by_agent_id", "created_at", "references", "tags", "summary", "version", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    REFERENCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    engagement_id: str
    entry_type: str
    title: str
    content: str
    created_by_agent_id: str
    created_at: str
    references: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    summary: str
    version: int
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., engagement_id: _Optional[str] = ..., entry_type: _Optional[str] = ..., title: _Optional[str] = ..., content: _Optional[str] = ..., created_by_agent_id: _Optional[str] = ..., created_at: _Optional[str] = ..., references: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., summary: _Optional[str] = ..., version: _Optional[int] = ..., updated_at: _Optional[str] = ...) -> None: ...

class GetEngagementResponse(_message.Message):
    __slots__ = ("status", "engagement_id", "name", "engagement_status", "company_id", "project_id", "agent_id", "user_id", "summary", "entries", "created_at", "updated_at", "error_message", "error_code", "ultimate_goal", "parent_engagement_id")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_STATUS_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    PARENT_ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    status: str
    engagement_id: str
    name: str
    engagement_status: str
    company_id: str
    project_id: str
    agent_id: str
    user_id: str
    summary: str
    entries: _containers.RepeatedCompositeFieldContainer[EngagementEntryInfo]
    created_at: str
    updated_at: str
    error_message: str
    error_code: str
    ultimate_goal: str
    parent_engagement_id: str
    def __init__(self, status: _Optional[str] = ..., engagement_id: _Optional[str] = ..., name: _Optional[str] = ..., engagement_status: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., user_id: _Optional[str] = ..., summary: _Optional[str] = ..., entries: _Optional[_Iterable[_Union[EngagementEntryInfo, _Mapping]]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., ultimate_goal: _Optional[str] = ..., parent_engagement_id: _Optional[str] = ...) -> None: ...

class ListEngagementsRequest(_message.Message):
    __slots__ = ("user_token", "project_id", "status", "limit", "offset", "engagement_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    project_id: str
    status: str
    limit: int
    offset: int
    engagement_id: str
    def __init__(self, user_token: _Optional[str] = ..., project_id: _Optional[str] = ..., status: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., engagement_id: _Optional[str] = ...) -> None: ...

class EngagementInfo(_message.Message):
    __slots__ = ("id", "name", "status", "company_id", "project_id", "agent_id", "user_id", "summary", "created_at", "updated_at", "ultimate_goal", "engagement_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    status: str
    company_id: str
    project_id: str
    agent_id: str
    user_id: str
    summary: str
    created_at: str
    updated_at: str
    ultimate_goal: str
    engagement_id: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., status: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., user_id: _Optional[str] = ..., summary: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., ultimate_goal: _Optional[str] = ..., engagement_id: _Optional[str] = ...) -> None: ...

class ListEngagementsResponse(_message.Message):
    __slots__ = ("status", "project_id", "total_count", "engagements", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    project_id: str
    total_count: int
    engagements: _containers.RepeatedCompositeFieldContainer[EngagementInfo]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., project_id: _Optional[str] = ..., total_count: _Optional[int] = ..., engagements: _Optional[_Iterable[_Union[EngagementInfo, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UpdateEngagementRequest(_message.Message):
    __slots__ = ("user_token", "engagement_id", "name", "status", "summary", "ultimate_goal", "parent_engagement_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    PARENT_ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    engagement_id: str
    name: str
    status: str
    summary: str
    ultimate_goal: str
    parent_engagement_id: str
    def __init__(self, user_token: _Optional[str] = ..., engagement_id: _Optional[str] = ..., name: _Optional[str] = ..., status: _Optional[str] = ..., summary: _Optional[str] = ..., ultimate_goal: _Optional[str] = ..., parent_engagement_id: _Optional[str] = ...) -> None: ...

class UpdateEngagementResponse(_message.Message):
    __slots__ = ("status", "message", "engagement_id", "name", "engagement_status", "updated_at", "error_message", "error_code", "ultimate_goal", "parent_engagement_id")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_STATUS_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    PARENT_ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    engagement_id: str
    name: str
    engagement_status: str
    updated_at: str
    error_message: str
    error_code: str
    ultimate_goal: str
    parent_engagement_id: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., engagement_id: _Optional[str] = ..., name: _Optional[str] = ..., engagement_status: _Optional[str] = ..., updated_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., ultimate_goal: _Optional[str] = ..., parent_engagement_id: _Optional[str] = ...) -> None: ...

class AddEntryRequest(_message.Message):
    __slots__ = ("user_token", "engagement_id", "entry_type", "title", "content", "agent_id", "references", "tags")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    REFERENCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    engagement_id: str
    entry_type: str
    title: str
    content: str
    agent_id: str
    references: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, user_token: _Optional[str] = ..., engagement_id: _Optional[str] = ..., entry_type: _Optional[str] = ..., title: _Optional[str] = ..., content: _Optional[str] = ..., agent_id: _Optional[str] = ..., references: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class AddEntryResponse(_message.Message):
    __slots__ = ("status", "message", "entry_id", "engagement_id", "entry_type", "title", "created_at", "error_message", "error_code", "summary", "version")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    entry_id: str
    engagement_id: str
    entry_type: str
    title: str
    created_at: str
    error_message: str
    error_code: str
    summary: str
    version: int
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., entry_id: _Optional[str] = ..., engagement_id: _Optional[str] = ..., entry_type: _Optional[str] = ..., title: _Optional[str] = ..., created_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., summary: _Optional[str] = ..., version: _Optional[int] = ...) -> None: ...

class UpdateEntryRequest(_message.Message):
    __slots__ = ("user_token", "entry_id", "content", "references", "tags")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    REFERENCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    entry_id: str
    content: str
    references: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, user_token: _Optional[str] = ..., entry_id: _Optional[str] = ..., content: _Optional[str] = ..., references: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class UpdateEntryResponse(_message.Message):
    __slots__ = ("status", "message", "entry_id", "entry_type", "title", "summary", "version", "updated_at", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    entry_id: str
    entry_type: str
    title: str
    summary: str
    version: int
    updated_at: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ..., entry_id: _Optional[str] = ..., entry_type: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., version: _Optional[int] = ..., updated_at: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetEntryRequest(_message.Message):
    __slots__ = ("user_token", "entry_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    entry_id: str
    def __init__(self, user_token: _Optional[str] = ..., entry_id: _Optional[str] = ...) -> None: ...

class GetEntryResponse(_message.Message):
    __slots__ = ("status", "entry", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ENTRY_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    entry: EngagementEntryFull
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., entry: _Optional[_Union[EngagementEntryFull, _Mapping]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetEntriesRequest(_message.Message):
    __slots__ = ("user_token", "engagement_id", "entry_type")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRY_TYPE_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    engagement_id: str
    entry_type: str
    def __init__(self, user_token: _Optional[str] = ..., engagement_id: _Optional[str] = ..., entry_type: _Optional[str] = ...) -> None: ...

class GetEntriesResponse(_message.Message):
    __slots__ = ("status", "engagement_id", "total_count", "entries", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    engagement_id: str
    total_count: int
    entries: _containers.RepeatedCompositeFieldContainer[EngagementEntryFull]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., engagement_id: _Optional[str] = ..., total_count: _Optional[int] = ..., entries: _Optional[_Iterable[_Union[EngagementEntryFull, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class SearchEntriesRequest(_message.Message):
    __slots__ = ("user_token", "query", "project_id", "limit", "entry_type", "engagement_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    ENTRY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    query: str
    project_id: str
    limit: int
    entry_type: str
    engagement_id: str
    def __init__(self, user_token: _Optional[str] = ..., query: _Optional[str] = ..., project_id: _Optional[str] = ..., limit: _Optional[int] = ..., entry_type: _Optional[str] = ..., engagement_id: _Optional[str] = ...) -> None: ...

class SearchEntriesResponse(_message.Message):
    __slots__ = ("status", "query", "project_id", "results_count", "results", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    RESULTS_COUNT_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    query: str
    project_id: str
    results_count: int
    results: _containers.RepeatedCompositeFieldContainer[_legion_common_pb2.QueryResult]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., query: _Optional[str] = ..., project_id: _Optional[str] = ..., results_count: _Optional[int] = ..., results: _Optional[_Iterable[_Union[_legion_common_pb2.QueryResult, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ResumeEngagementRequest(_message.Message):
    __slots__ = ("user_token", "engagement_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    engagement_id: str
    def __init__(self, user_token: _Optional[str] = ..., engagement_id: _Optional[str] = ...) -> None: ...

class EntriesByType(_message.Message):
    __slots__ = ("entry_type", "entries")
    ENTRY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    entry_type: str
    entries: _containers.RepeatedCompositeFieldContainer[EngagementEntryFull]
    def __init__(self, entry_type: _Optional[str] = ..., entries: _Optional[_Iterable[_Union[EngagementEntryFull, _Mapping]]] = ...) -> None: ...

class ResumeEngagementResponse(_message.Message):
    __slots__ = ("status", "engagement_id", "name", "engagement_status", "summary", "entries_by_type", "total_entries", "error_message", "error_code", "ultimate_goal")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_STATUS_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    ENTRIES_BY_TYPE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ENTRIES_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ULTIMATE_GOAL_FIELD_NUMBER: _ClassVar[int]
    status: str
    engagement_id: str
    name: str
    engagement_status: str
    summary: str
    entries_by_type: _containers.RepeatedCompositeFieldContainer[EntriesByType]
    total_entries: int
    error_message: str
    error_code: str
    ultimate_goal: str
    def __init__(self, status: _Optional[str] = ..., engagement_id: _Optional[str] = ..., name: _Optional[str] = ..., engagement_status: _Optional[str] = ..., summary: _Optional[str] = ..., entries_by_type: _Optional[_Iterable[_Union[EntriesByType, _Mapping]]] = ..., total_entries: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., ultimate_goal: _Optional[str] = ...) -> None: ...
