from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateAgentRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "name", "role", "personality", "main_responsibilities", "system_prompt", "capabilities", "specialization", "project_id", "when_to_use")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    PERSONALITY_FIELD_NUMBER: _ClassVar[int]
    MAIN_RESPONSIBILITIES_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PROMPT_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    SPECIALIZATION_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    name: str
    role: str
    personality: str
    main_responsibilities: str
    system_prompt: str
    capabilities: _containers.RepeatedScalarFieldContainer[str]
    specialization: str
    project_id: str
    when_to_use: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., personality: _Optional[str] = ..., main_responsibilities: _Optional[str] = ..., system_prompt: _Optional[str] = ..., capabilities: _Optional[_Iterable[str]] = ..., specialization: _Optional[str] = ..., project_id: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class CreateAgentResponse(_message.Message):
    __slots__ = ("status", "agent_id", "name", "role", "learning_skill_linked", "error_message", "error_code", "when_to_use")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    LEARNING_SKILL_LINKED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    status: str
    agent_id: str
    name: str
    role: str
    learning_skill_linked: bool
    error_message: str
    error_code: str
    when_to_use: str
    def __init__(self, status: _Optional[str] = ..., agent_id: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., learning_skill_linked: bool = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class DeleteAgentRequest(_message.Message):
    __slots__ = ("user_token", "agent_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    agent_id: str
    def __init__(self, user_token: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class DeleteAgentResponse(_message.Message):
    __slots__ = ("status", "agent_id", "name", "skills_unlinked", "deleted", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SKILLS_UNLINKED_FIELD_NUMBER: _ClassVar[int]
    DELETED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    agent_id: str
    name: str
    skills_unlinked: int
    deleted: bool
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., agent_id: _Optional[str] = ..., name: _Optional[str] = ..., skills_unlinked: _Optional[int] = ..., deleted: bool = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UpdateAgentRequest(_message.Message):
    __slots__ = ("user_token", "agent_id", "name", "name_provided", "personality", "personality_provided", "main_responsibilities", "main_responsibilities_provided", "system_prompt", "system_prompt_provided", "metadata_json", "metadata_provided", "project_id", "project_id_provided", "public", "public_provided", "when_to_use", "when_to_use_provided")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    PERSONALITY_FIELD_NUMBER: _ClassVar[int]
    PERSONALITY_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    MAIN_RESPONSIBILITIES_FIELD_NUMBER: _ClassVar[int]
    MAIN_RESPONSIBILITIES_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PROMPT_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PROMPT_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    METADATA_JSON_FIELD_NUMBER: _ClassVar[int]
    METADATA_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    PUBLIC_FIELD_NUMBER: _ClassVar[int]
    PUBLIC_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    agent_id: str
    name: str
    name_provided: bool
    personality: str
    personality_provided: bool
    main_responsibilities: str
    main_responsibilities_provided: bool
    system_prompt: str
    system_prompt_provided: bool
    metadata_json: str
    metadata_provided: bool
    project_id: str
    project_id_provided: bool
    public: bool
    public_provided: bool
    when_to_use: str
    when_to_use_provided: bool
    def __init__(self, user_token: _Optional[str] = ..., agent_id: _Optional[str] = ..., name: _Optional[str] = ..., name_provided: bool = ..., personality: _Optional[str] = ..., personality_provided: bool = ..., main_responsibilities: _Optional[str] = ..., main_responsibilities_provided: bool = ..., system_prompt: _Optional[str] = ..., system_prompt_provided: bool = ..., metadata_json: _Optional[str] = ..., metadata_provided: bool = ..., project_id: _Optional[str] = ..., project_id_provided: bool = ..., public: bool = ..., public_provided: bool = ..., when_to_use: _Optional[str] = ..., when_to_use_provided: bool = ...) -> None: ...

class UpdateAgentResponse(_message.Message):
    __slots__ = ("status", "agent_id", "name", "role", "error_message", "error_code", "when_to_use")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    status: str
    agent_id: str
    name: str
    role: str
    error_message: str
    error_code: str
    when_to_use: str
    def __init__(self, status: _Optional[str] = ..., agent_id: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class WhoAmIRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "agent_id", "project_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    agent_id: str
    project_id: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., project_id: _Optional[str] = ...) -> None: ...

class SkillOverview(_message.Message):
    __slots__ = ("expertise_id", "title", "summary", "sections_count", "when_to_use")
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    SECTIONS_COUNT_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    expertise_id: str
    title: str
    summary: str
    sections_count: int
    when_to_use: str
    def __init__(self, expertise_id: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., sections_count: _Optional[int] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class AvailableAgent(_message.Message):
    __slots__ = ("agent_id", "name", "role", "specialization", "description", "when_to_use")
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    SPECIALIZATION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    agent_id: str
    name: str
    role: str
    specialization: str
    description: str
    when_to_use: str
    def __init__(self, agent_id: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., specialization: _Optional[str] = ..., description: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class PermanentMemory(_message.Message):
    __slots__ = ("id", "agent_id", "user_id", "content", "category", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    agent_id: str
    user_id: str
    content: str
    category: str
    created_at: str
    def __init__(self, id: _Optional[str] = ..., agent_id: _Optional[str] = ..., user_id: _Optional[str] = ..., content: _Optional[str] = ..., category: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class WorkflowOverview(_message.Message):
    __slots__ = ("id", "name", "signals", "when_to_use")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SIGNALS_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    signals: _containers.RepeatedScalarFieldContainer[str]
    when_to_use: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., signals: _Optional[_Iterable[str]] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class WhoAmIResponse(_message.Message):
    __slots__ = ("status", "agent_id", "name", "role", "personality", "main_responsibilities", "system_prompt", "capabilities", "skills_overview", "skills_count", "available_agents", "available_agents_count", "error_message", "error_code", "permanent_memories", "workflows")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    PERSONALITY_FIELD_NUMBER: _ClassVar[int]
    MAIN_RESPONSIBILITIES_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PROMPT_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    SKILLS_OVERVIEW_FIELD_NUMBER: _ClassVar[int]
    SKILLS_COUNT_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_AGENTS_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_AGENTS_COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    PERMANENT_MEMORIES_FIELD_NUMBER: _ClassVar[int]
    WORKFLOWS_FIELD_NUMBER: _ClassVar[int]
    status: str
    agent_id: str
    name: str
    role: str
    personality: str
    main_responsibilities: str
    system_prompt: str
    capabilities: _containers.RepeatedScalarFieldContainer[str]
    skills_overview: _containers.RepeatedCompositeFieldContainer[SkillOverview]
    skills_count: int
    available_agents: _containers.RepeatedCompositeFieldContainer[AvailableAgent]
    available_agents_count: int
    error_message: str
    error_code: str
    permanent_memories: _containers.RepeatedCompositeFieldContainer[PermanentMemory]
    workflows: _containers.RepeatedCompositeFieldContainer[WorkflowOverview]
    def __init__(self, status: _Optional[str] = ..., agent_id: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., personality: _Optional[str] = ..., main_responsibilities: _Optional[str] = ..., system_prompt: _Optional[str] = ..., capabilities: _Optional[_Iterable[str]] = ..., skills_overview: _Optional[_Iterable[_Union[SkillOverview, _Mapping]]] = ..., skills_count: _Optional[int] = ..., available_agents: _Optional[_Iterable[_Union[AvailableAgent, _Mapping]]] = ..., available_agents_count: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ..., permanent_memories: _Optional[_Iterable[_Union[PermanentMemory, _Mapping]]] = ..., workflows: _Optional[_Iterable[_Union[WorkflowOverview, _Mapping]]] = ...) -> None: ...

class GetAgentSkillsRequest(_message.Message):
    __slots__ = ("agent_id", "user_token")
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    agent_id: str
    user_token: str
    def __init__(self, agent_id: _Optional[str] = ..., user_token: _Optional[str] = ...) -> None: ...

class SkillSection(_message.Message):
    __slots__ = ("chunk_id", "title", "summary", "has_code", "level", "position")
    CHUNK_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    HAS_CODE_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    chunk_id: str
    title: str
    summary: str
    has_code: bool
    level: int
    position: int
    def __init__(self, chunk_id: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., has_code: bool = ..., level: _Optional[int] = ..., position: _Optional[int] = ...) -> None: ...

class AgentSkill(_message.Message):
    __slots__ = ("expertise_id", "title", "summary", "sections")
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    SECTIONS_FIELD_NUMBER: _ClassVar[int]
    expertise_id: str
    title: str
    summary: str
    sections: _containers.RepeatedCompositeFieldContainer[SkillSection]
    def __init__(self, expertise_id: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., sections: _Optional[_Iterable[_Union[SkillSection, _Mapping]]] = ...) -> None: ...

class GetAgentSkillsResponse(_message.Message):
    __slots__ = ("status", "agent_id", "agent_name", "skills_count", "skills", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    SKILLS_COUNT_FIELD_NUMBER: _ClassVar[int]
    SKILLS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    agent_id: str
    agent_name: str
    skills_count: int
    skills: _containers.RepeatedCompositeFieldContainer[SkillOverview]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., agent_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., skills_count: _Optional[int] = ..., skills: _Optional[_Iterable[_Union[SkillOverview, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class SearchSkillDetailsRequest(_message.Message):
    __slots__ = ("expertise_id", "query", "limit", "user_token")
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    expertise_id: str
    query: str
    limit: int
    user_token: str
    def __init__(self, expertise_id: _Optional[str] = ..., query: _Optional[str] = ..., limit: _Optional[int] = ..., user_token: _Optional[str] = ...) -> None: ...

class SkillSearchResult(_message.Message):
    __slots__ = ("chunk_id", "title", "content", "score", "has_code", "level", "position")
    CHUNK_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    HAS_CODE_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    chunk_id: str
    title: str
    content: str
    score: float
    has_code: bool
    level: int
    position: int
    def __init__(self, chunk_id: _Optional[str] = ..., title: _Optional[str] = ..., content: _Optional[str] = ..., score: _Optional[float] = ..., has_code: bool = ..., level: _Optional[int] = ..., position: _Optional[int] = ...) -> None: ...

class SearchSkillDetailsResponse(_message.Message):
    __slots__ = ("status", "expertise_id", "expertise_title", "query", "results_count", "results", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_TITLE_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    RESULTS_COUNT_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    expertise_id: str
    expertise_title: str
    query: str
    results_count: int
    results: _containers.RepeatedCompositeFieldContainer[SkillSearchResult]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., expertise_id: _Optional[str] = ..., expertise_title: _Optional[str] = ..., query: _Optional[str] = ..., results_count: _Optional[int] = ..., results: _Optional[_Iterable[_Union[SkillSearchResult, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetSkillSectionsRequest(_message.Message):
    __slots__ = ("expertise_id", "user_token")
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    expertise_id: str
    user_token: str
    def __init__(self, expertise_id: _Optional[str] = ..., user_token: _Optional[str] = ...) -> None: ...

class GetSkillSectionsResponse(_message.Message):
    __slots__ = ("status", "expertise_id", "title", "summary", "sections_count", "sections", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    SECTIONS_COUNT_FIELD_NUMBER: _ClassVar[int]
    SECTIONS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    expertise_id: str
    title: str
    summary: str
    sections_count: int
    sections: _containers.RepeatedCompositeFieldContainer[SkillSection]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., expertise_id: _Optional[str] = ..., title: _Optional[str] = ..., summary: _Optional[str] = ..., sections_count: _Optional[int] = ..., sections: _Optional[_Iterable[_Union[SkillSection, _Mapping]]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetSkillContentRequest(_message.Message):
    __slots__ = ("chunk_id", "user_token")
    CHUNK_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    chunk_id: str
    user_token: str
    def __init__(self, chunk_id: _Optional[str] = ..., user_token: _Optional[str] = ...) -> None: ...

class GetSkillContentResponse(_message.Message):
    __slots__ = ("status", "chunk_id", "title", "content", "has_code", "level", "expertise_id", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CHUNK_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    HAS_CODE_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    chunk_id: str
    title: str
    content: str
    has_code: bool
    level: int
    expertise_id: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., chunk_id: _Optional[str] = ..., title: _Optional[str] = ..., content: _Optional[str] = ..., has_code: bool = ..., level: _Optional[int] = ..., expertise_id: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class LinkAgentSkillRequest(_message.Message):
    __slots__ = ("agent_id", "expertise_id", "user_token")
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    agent_id: str
    expertise_id: str
    user_token: str
    def __init__(self, agent_id: _Optional[str] = ..., expertise_id: _Optional[str] = ..., user_token: _Optional[str] = ...) -> None: ...

class LinkAgentSkillResponse(_message.Message):
    __slots__ = ("status", "agent_id", "expertise_id", "expertise_title", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_TITLE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    agent_id: str
    expertise_id: str
    expertise_title: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., agent_id: _Optional[str] = ..., expertise_id: _Optional[str] = ..., expertise_title: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UnlinkAgentSkillRequest(_message.Message):
    __slots__ = ("agent_id", "expertise_id", "user_token")
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    agent_id: str
    expertise_id: str
    user_token: str
    def __init__(self, agent_id: _Optional[str] = ..., expertise_id: _Optional[str] = ..., user_token: _Optional[str] = ...) -> None: ...

class UnlinkAgentSkillResponse(_message.Message):
    __slots__ = ("status", "agent_id", "expertise_id", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    EXPERTISE_ID_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    agent_id: str
    expertise_id: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., agent_id: _Optional[str] = ..., expertise_id: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetAgentContextRequest(_message.Message):
    __slots__ = ("agent_id", "project_id", "user_token")
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    agent_id: str
    project_id: str
    user_token: str
    def __init__(self, agent_id: _Optional[str] = ..., project_id: _Optional[str] = ..., user_token: _Optional[str] = ...) -> None: ...

class CompanyInstructions(_message.Message):
    __slots__ = ("id", "company_id", "ground_rules", "coding_standards", "communication_style", "forbidden_actions", "custom_instructions")
    ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    GROUND_RULES_FIELD_NUMBER: _ClassVar[int]
    CODING_STANDARDS_FIELD_NUMBER: _ClassVar[int]
    COMMUNICATION_STYLE_FIELD_NUMBER: _ClassVar[int]
    FORBIDDEN_ACTIONS_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_INSTRUCTIONS_FIELD_NUMBER: _ClassVar[int]
    id: str
    company_id: str
    ground_rules: str
    coding_standards: str
    communication_style: str
    forbidden_actions: str
    custom_instructions: str
    def __init__(self, id: _Optional[str] = ..., company_id: _Optional[str] = ..., ground_rules: _Optional[str] = ..., coding_standards: _Optional[str] = ..., communication_style: _Optional[str] = ..., forbidden_actions: _Optional[str] = ..., custom_instructions: _Optional[str] = ...) -> None: ...

class ProjectInstructions(_message.Message):
    __slots__ = ("id", "project_id", "description", "languages", "frameworks", "tools", "architecture_notes", "conventions", "custom_instructions")
    ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    LANGUAGES_FIELD_NUMBER: _ClassVar[int]
    FRAMEWORKS_FIELD_NUMBER: _ClassVar[int]
    TOOLS_FIELD_NUMBER: _ClassVar[int]
    ARCHITECTURE_NOTES_FIELD_NUMBER: _ClassVar[int]
    CONVENTIONS_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_INSTRUCTIONS_FIELD_NUMBER: _ClassVar[int]
    id: str
    project_id: str
    description: str
    languages: _containers.RepeatedScalarFieldContainer[str]
    frameworks: _containers.RepeatedScalarFieldContainer[str]
    tools: _containers.RepeatedScalarFieldContainer[str]
    architecture_notes: str
    conventions: str
    custom_instructions: str
    def __init__(self, id: _Optional[str] = ..., project_id: _Optional[str] = ..., description: _Optional[str] = ..., languages: _Optional[_Iterable[str]] = ..., frameworks: _Optional[_Iterable[str]] = ..., tools: _Optional[_Iterable[str]] = ..., architecture_notes: _Optional[str] = ..., conventions: _Optional[str] = ..., custom_instructions: _Optional[str] = ...) -> None: ...

class GetAgentContextResponse(_message.Message):
    __slots__ = ("status", "agent_id", "agent_name", "agent_role", "combined_system_prompt", "company_instructions", "project_instructions", "agent_system_prompt", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ROLE_FIELD_NUMBER: _ClassVar[int]
    COMBINED_SYSTEM_PROMPT_FIELD_NUMBER: _ClassVar[int]
    COMPANY_INSTRUCTIONS_FIELD_NUMBER: _ClassVar[int]
    PROJECT_INSTRUCTIONS_FIELD_NUMBER: _ClassVar[int]
    AGENT_SYSTEM_PROMPT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    agent_id: str
    agent_name: str
    agent_role: str
    combined_system_prompt: str
    company_instructions: CompanyInstructions
    project_instructions: ProjectInstructions
    agent_system_prompt: str
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., agent_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., agent_role: _Optional[str] = ..., combined_system_prompt: _Optional[str] = ..., company_instructions: _Optional[_Union[CompanyInstructions, _Mapping]] = ..., project_instructions: _Optional[_Union[ProjectInstructions, _Mapping]] = ..., agent_system_prompt: _Optional[str] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class GetWorkflowByIdRequest(_message.Message):
    __slots__ = ("workflow_id", "user_token")
    WORKFLOW_ID_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workflow_id: str
    user_token: str
    def __init__(self, workflow_id: _Optional[str] = ..., user_token: _Optional[str] = ...) -> None: ...

class WorkflowContent(_message.Message):
    __slots__ = ("id", "company_id", "project_id", "agent_id", "role", "user_id", "public", "name", "content", "description", "signals", "version", "created_at", "updated_at", "when_to_use")
    ID_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    PUBLIC_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SIGNALS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    id: str
    company_id: str
    project_id: str
    agent_id: str
    role: str
    user_id: str
    public: bool
    name: str
    content: str
    description: str
    signals: _containers.RepeatedScalarFieldContainer[str]
    version: int
    created_at: str
    updated_at: str
    when_to_use: str
    def __init__(self, id: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., role: _Optional[str] = ..., user_id: _Optional[str] = ..., public: bool = ..., name: _Optional[str] = ..., content: _Optional[str] = ..., description: _Optional[str] = ..., signals: _Optional[_Iterable[str]] = ..., version: _Optional[int] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class GetWorkflowByIdResponse(_message.Message):
    __slots__ = ("status", "workflow", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    workflow: WorkflowContent
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., workflow: _Optional[_Union[WorkflowContent, _Mapping]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class CreateWorkflowRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "name", "content", "signals", "description", "role", "agent_id", "project_id", "public", "metadata_json", "when_to_use")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    SIGNALS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PUBLIC_FIELD_NUMBER: _ClassVar[int]
    METADATA_JSON_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    name: str
    content: str
    signals: _containers.RepeatedScalarFieldContainer[str]
    description: str
    role: str
    agent_id: str
    project_id: str
    public: bool
    metadata_json: str
    when_to_use: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., name: _Optional[str] = ..., content: _Optional[str] = ..., signals: _Optional[_Iterable[str]] = ..., description: _Optional[str] = ..., role: _Optional[str] = ..., agent_id: _Optional[str] = ..., project_id: _Optional[str] = ..., public: bool = ..., metadata_json: _Optional[str] = ..., when_to_use: _Optional[str] = ...) -> None: ...

class CreateWorkflowResponse(_message.Message):
    __slots__ = ("status", "workflow", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    workflow: WorkflowContent
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., workflow: _Optional[_Union[WorkflowContent, _Mapping]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class UpdateWorkflowRequest(_message.Message):
    __slots__ = ("user_token", "workflow_id", "name", "name_provided", "content", "content_provided", "signals", "signals_provided", "description", "description_provided", "role", "role_provided", "agent_id", "agent_id_provided", "project_id", "project_id_provided", "public", "public_provided", "metadata_json", "metadata_provided", "when_to_use", "when_to_use_provided")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    CONTENT_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    SIGNALS_FIELD_NUMBER: _ClassVar[int]
    SIGNALS_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    ROLE_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    PUBLIC_FIELD_NUMBER: _ClassVar[int]
    PUBLIC_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    METADATA_JSON_FIELD_NUMBER: _ClassVar[int]
    METADATA_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_FIELD_NUMBER: _ClassVar[int]
    WHEN_TO_USE_PROVIDED_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    workflow_id: str
    name: str
    name_provided: bool
    content: str
    content_provided: bool
    signals: _containers.RepeatedScalarFieldContainer[str]
    signals_provided: bool
    description: str
    description_provided: bool
    role: str
    role_provided: bool
    agent_id: str
    agent_id_provided: bool
    project_id: str
    project_id_provided: bool
    public: bool
    public_provided: bool
    metadata_json: str
    metadata_provided: bool
    when_to_use: str
    when_to_use_provided: bool
    def __init__(self, user_token: _Optional[str] = ..., workflow_id: _Optional[str] = ..., name: _Optional[str] = ..., name_provided: bool = ..., content: _Optional[str] = ..., content_provided: bool = ..., signals: _Optional[_Iterable[str]] = ..., signals_provided: bool = ..., description: _Optional[str] = ..., description_provided: bool = ..., role: _Optional[str] = ..., role_provided: bool = ..., agent_id: _Optional[str] = ..., agent_id_provided: bool = ..., project_id: _Optional[str] = ..., project_id_provided: bool = ..., public: bool = ..., public_provided: bool = ..., metadata_json: _Optional[str] = ..., metadata_provided: bool = ..., when_to_use: _Optional[str] = ..., when_to_use_provided: bool = ...) -> None: ...

class UpdateWorkflowResponse(_message.Message):
    __slots__ = ("status", "workflow", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    workflow: WorkflowContent
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., workflow: _Optional[_Union[WorkflowContent, _Mapping]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class DeleteWorkflowRequest(_message.Message):
    __slots__ = ("user_token", "workflow_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    workflow_id: str
    def __init__(self, user_token: _Optional[str] = ..., workflow_id: _Optional[str] = ...) -> None: ...

class DeleteWorkflowResponse(_message.Message):
    __slots__ = ("status", "workflow_id", "deleted", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_ID_FIELD_NUMBER: _ClassVar[int]
    DELETED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    workflow_id: str
    deleted: bool
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., workflow_id: _Optional[str] = ..., deleted: bool = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ListWorkflowsRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "role", "agent_id", "project_id", "limit", "offset")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    role: str
    agent_id: str
    project_id: str
    limit: int
    offset: int
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., role: _Optional[str] = ..., agent_id: _Optional[str] = ..., project_id: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class ListWorkflowsResponse(_message.Message):
    __slots__ = ("status", "workflows", "total_count", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    WORKFLOWS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    workflows: _containers.RepeatedCompositeFieldContainer[WorkflowContent]
    total_count: int
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., workflows: _Optional[_Iterable[_Union[WorkflowContent, _Mapping]]] = ..., total_count: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...

class ListCompanyAgentsRequest(_message.Message):
    __slots__ = ("user_token", "company_id", "project_id")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    company_id: str
    project_id: str
    def __init__(self, user_token: _Optional[str] = ..., company_id: _Optional[str] = ..., project_id: _Optional[str] = ...) -> None: ...

class AgentWithContext(_message.Message):
    __slots__ = ("agent_id", "name", "role", "specialization", "combined_system_prompt")
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    SPECIALIZATION_FIELD_NUMBER: _ClassVar[int]
    COMBINED_SYSTEM_PROMPT_FIELD_NUMBER: _ClassVar[int]
    agent_id: str
    name: str
    role: str
    specialization: str
    combined_system_prompt: str
    def __init__(self, agent_id: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., specialization: _Optional[str] = ..., combined_system_prompt: _Optional[str] = ...) -> None: ...

class ListCompanyAgentsResponse(_message.Message):
    __slots__ = ("status", "agents", "total_count", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    agents: _containers.RepeatedCompositeFieldContainer[AgentWithContext]
    total_count: int
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., agents: _Optional[_Iterable[_Union[AgentWithContext, _Mapping]]] = ..., total_count: _Optional[int] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...
