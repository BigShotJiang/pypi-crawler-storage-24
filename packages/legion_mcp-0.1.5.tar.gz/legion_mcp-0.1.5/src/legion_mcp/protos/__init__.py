"""
LEGION gRPC Protocol Buffer definitions.
"""

from legion_mcp.protos import auth_pb2, auth_pb2_grpc
from legion_mcp.protos import knowledge_pb2, knowledge_pb2_grpc
from legion_mcp.protos import code_pb2, code_pb2_grpc
from legion_mcp.protos import expertise_pb2, expertise_pb2_grpc
from legion_mcp.protos import lessons_learned_pb2, lessons_learned_pb2_grpc
from legion_mcp.protos import agent_skill_pb2, agent_skill_pb2_grpc
from legion_mcp.protos import engagement_pb2, engagement_pb2_grpc
from legion_mcp.protos import task_pb2, task_pb2_grpc
from legion_mcp.protos import delegation_pb2, delegation_pb2_grpc
from legion_mcp.protos import ingestion_pb2, ingestion_pb2_grpc
from legion_mcp.protos import memory_pb2, memory_pb2_grpc
from legion_mcp.protos import proxy_pb2, proxy_pb2_grpc
from legion_mcp.protos import session_pb2, session_pb2_grpc
from legion_mcp.protos import unified_search_pb2, unified_search_pb2_grpc

__all__ = [
    "auth_pb2",
    "auth_pb2_grpc",
    "knowledge_pb2",
    "knowledge_pb2_grpc",
    "code_pb2",
    "code_pb2_grpc",
    "expertise_pb2",
    "expertise_pb2_grpc",
    "lessons_learned_pb2",
    "lessons_learned_pb2_grpc",
    "agent_skill_pb2",
    "agent_skill_pb2_grpc",
    "engagement_pb2",
    "engagement_pb2_grpc",
    "task_pb2",
    "task_pb2_grpc",
    "delegation_pb2",
    "delegation_pb2_grpc",
    "ingestion_pb2",
    "ingestion_pb2_grpc",
    "memory_pb2",
    "memory_pb2_grpc",
    "proxy_pb2",
    "proxy_pb2_grpc",
    "session_pb2",
    "session_pb2_grpc",
    "unified_search_pb2",
    "unified_search_pb2_grpc",
]
