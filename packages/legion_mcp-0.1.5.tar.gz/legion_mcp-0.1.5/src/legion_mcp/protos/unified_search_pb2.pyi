from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class UnifiedSearchRequest(_message.Message):
    __slots__ = ("user_token", "query", "project_id", "limit_per_type", "types")
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_PER_TYPE_FIELD_NUMBER: _ClassVar[int]
    TYPES_FIELD_NUMBER: _ClassVar[int]
    user_token: str
    query: str
    project_id: str
    limit_per_type: int
    types: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, user_token: _Optional[str] = ..., query: _Optional[str] = ..., project_id: _Optional[str] = ..., limit_per_type: _Optional[int] = ..., types: _Optional[_Iterable[str]] = ...) -> None: ...

class UnifiedSearchResult(_message.Message):
    __slots__ = ("type", "id", "title", "snippet", "score", "project_id", "metadata_json")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    SNIPPET_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    METADATA_JSON_FIELD_NUMBER: _ClassVar[int]
    type: str
    id: str
    title: str
    snippet: str
    score: float
    project_id: str
    metadata_json: str
    def __init__(self, type: _Optional[str] = ..., id: _Optional[str] = ..., title: _Optional[str] = ..., snippet: _Optional[str] = ..., score: _Optional[float] = ..., project_id: _Optional[str] = ..., metadata_json: _Optional[str] = ...) -> None: ...

class UnifiedSearchResponse(_message.Message):
    __slots__ = ("status", "results", "results_count", "types_searched", "error_message", "error_code")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    RESULTS_COUNT_FIELD_NUMBER: _ClassVar[int]
    TYPES_SEARCHED_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    status: str
    results: _containers.RepeatedCompositeFieldContainer[UnifiedSearchResult]
    results_count: int
    types_searched: _containers.RepeatedScalarFieldContainer[str]
    error_message: str
    error_code: str
    def __init__(self, status: _Optional[str] = ..., results: _Optional[_Iterable[_Union[UnifiedSearchResult, _Mapping]]] = ..., results_count: _Optional[int] = ..., types_searched: _Optional[_Iterable[str]] = ..., error_message: _Optional[str] = ..., error_code: _Optional[str] = ...) -> None: ...
