"""Claude Code API Proxy — beacon-based LEGION prompt injection, per-session logging.

Loaded by mitmdump as a script (-s flag). Must be standalone — no imports
from legion_mcp since mitmdump runs this in its own Python environment.

Handles both streaming (SSE) and non-streaming API responses.
Auto-terminates after IDLE_TIMEOUT_SECONDS of no API traffic.

Per-session folder: {LOG_DIR}/sessions/{agent_id}-{session_id}/
  - session_info.json:  Session metadata (agent_id, hash, timestamps)
  - messages.jsonl:     Full request/response pairs per session
  - usage.jsonl:        Token/context window usage per request

How it works:
  1. Every request: rfind("XLEGIONX::") in raw body → (agent_id, prompt_hash)
  2. Hash not in cache → extract combined_system_prompt from whoAmI tool_result, cache it
  3. Hash in cache → read from cache (O(1) dict lookup)
  4. Always: prepend cached LEGION prompt on top of Claude Code's native system field
  5. No beacon → pass through unchanged (pre-whoAmI warmup or pure CLI)
"""
import json
import logging
import os
import signal
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

# Allow importing cognitive_extractor from the same directory.
# mitmdump loads addon.py as a script, not as a package — relative imports
# don't work. Add the proxy directory to sys.path so we can import siblings.
sys.path.insert(0, os.path.dirname(__file__))

# Configure paths
LOG_DIR = os.getenv("LEGION_PROXY_LOG_DIR", os.path.join(os.path.expanduser("~"), ".legion", "proxy", "logs"))
SESSIONS_DIR = os.path.join(LOG_DIR, "sessions")

# Idle timeout — self-terminate after no traffic for this duration.
# Each API request resets the timer. Configurable via env var (seconds).
IDLE_TIMEOUT_SECONDS = int(os.getenv("LEGION_PROXY_IDLE_TIMEOUT", "604800"))  # 7 days

# Beacon protocol — embedded in whoAmI tool_result, flows through conversation
# history. Format: XLEGIONX::{agent_id}::{prompt_hash}
BEACON_PREFIX = "XLEGIONX::"

# Vital constraint — appended to every Claude Code system prompt
VITAL_CONSTRAINT = """**VITAL IMPORTANCE - NEVER FORGET:**

1. State the current goal in one sentence.
2. List what you have accomplished so far toward that goal.
3. Answer: does what I have accomplished move me closer to the goal, or am I drifting?
4. If drifting, stop, and correct course before proceeding.
5. Write out your next 1-3 actions and why each one is necessary.
6. Execute only those actions. Do not add extra calls beyond what you planned.
7. How much you are confident, that you are moving in the right direction? Put the score.

## LEGION Agent Protocol

### Identity Bootstrap
Before ANY other action, call `mcp__legion__whoAmI()`. It returns your identity, personality, permitted tools, workflow rules, and responsibilities. You MUST internalize and follow everything in `system_prompt`. Do not proceed with any user request until whoAmI() has been called.

### Workflow Activation
On EVERY user message:
1. Check if message matches any workflow signal (from whoAmI workflows)
2. Match found → `activateWorkflow(workflow_id)` BEFORE responding
3. No match → proceed normally
Signal matching is semantic, not exact string. "I have a feature idea" matches "User describes a new feature".

### Memory (MUST use when find relevant to keep important personal knowledge, observations, or learnings)
- `remember(content)` — Working memory (7 days)
- `rememberPermanent(content)` — Forever (critical learnings)
- `recall(query)` — Search on-demand

### Delegation
- Use `delegate_to_agent()` to assign specialist work — never do specialist work yourself if you are an orchestrator
- Poll `get_delegation_status()` once per response, report result, then set foreground bach sleep 60, if not complete. Repeat until complete. 
- On completion: `get_delegation_result()` to retrieve output"""

# Ensure directories exist
Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
Path(SESSIONS_DIR).mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Captured headers — cloned from first real Claude Code request
# ---------------------------------------------------------------------------
# Used by CognitiveExtractor for Haiku API calls. These headers are proven
# to work (they authenticated successfully through our proxy). Captured once,
# reused for all extraction calls.
_captured_headers = {}

# ---------------------------------------------------------------------------
# Beacon prompt cache — maps prompt_hash to LEGION combined_system_prompt
# ---------------------------------------------------------------------------
# Global, shared across all sessions. An agent with the same prompt hash
# always has the same combined_system_prompt regardless of session.
# prompt_hash (str, 16 hex chars) -> combined_system_prompt (str)
_beacon_cache = {}

# ---------------------------------------------------------------------------
# Session cache — maps session_id to agent metadata for logging/folders
# ---------------------------------------------------------------------------
# session_id -> {"agent_id": str, "session_dir": str}
_session_cache = {}


# ---------------------------------------------------------------------------
# Beacon scanning — replaces regex-based agent extraction
# ---------------------------------------------------------------------------
def _scan_beacon(raw_body):
    """Find the latest XLEGIONX beacon in the raw request body.

    Uses rfind for O(1)-like reverse scan — the latest whoAmI tool_result
    is near the end of the conversation history, so rfind hits it
    without scanning the entire body.

    Returns (agent_id, prompt_hash) or None if no beacon found.
    """
    pos = raw_body.rfind(BEACON_PREFIX)
    if pos == -1:
        return None

    # Extract: XLEGIONX::{agent_id}::{hash}
    # agent_id is 36 chars (UUID with hyphens), hash is 16 hex chars
    start = pos + len(BEACON_PREFIX)
    # Grab enough chars: 36 (UUID) + 2 (::) + 16 (hash) + margin
    segment = raw_body[start:start + 60]
    parts = segment.split("::")
    if len(parts) >= 2:
        agent_id = parts[0][:36]
        prompt_hash = parts[1][:16]
        if len(agent_id) == 36 and len(prompt_hash) >= 8:
            return (agent_id, prompt_hash)
    return None


def _extract_prompt_from_messages(messages, agent_id):
    """Find the whoAmI tool_result and extract combined_system_prompt.

    Iterates messages in REVERSE order (latest first) to find the most
    recent whoAmI response containing this agent_id's beacon.

    In the Anthropic Messages API, tool_results appear as user messages
    with content blocks of type "tool_result". The content of each block
    is the JSON string returned by the MCP tool.

    Returns the combined_system_prompt string or empty string if not found.
    """
    for msg in reversed(messages):
        if msg.get("role") != "user":
            continue

        content = msg.get("content", "")
        if isinstance(content, list):
            for block in content:
                if not isinstance(block, dict):
                    continue
                if block.get("type") != "tool_result":
                    continue
                text = _tool_result_text(block)
                if not text or BEACON_PREFIX not in text:
                    continue
                prompt = _parse_whoami_prompt(text, agent_id)
                if prompt:
                    return prompt
        elif isinstance(content, str) and BEACON_PREFIX in content:
            prompt = _parse_whoami_prompt(content, agent_id)
            if prompt:
                return prompt
    return ""


def _tool_result_text(block):
    """Extract text content from a tool_result content block.

    tool_result content can be:
      - A string (direct JSON)
      - A list of content blocks [{type: "text", text: "..."}]
    """
    content = block.get("content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(
            b.get("text", "") for b in content
            if isinstance(b, dict) and b.get("type") == "text"
        )
    return str(content) if content else ""


def _parse_whoami_prompt(text, agent_id):
    """Parse a whoAmI JSON response and extract combined_system_prompt.

    Looks for a JSON object containing both the beacon and the agent_id.
    Returns the combined_system_prompt or empty string.
    """
    if BEACON_PREFIX not in text or agent_id not in text:
        return ""
    try:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            data = json.loads(text[start:end])
            if data.get("agent_id") == agent_id:
                return data.get("combined_system_prompt", "")
    except (json.JSONDecodeError, ValueError, KeyError):
        pass
    return ""


# ---------------------------------------------------------------------------
# Session lifecycle — lightweight, for logging/folder management only
# ---------------------------------------------------------------------------
def _get_session_dir(agent_id, session_id):
    """Get or create session directory: {SESSIONS_DIR}/{agent_id}-{session_id}/"""
    dir_path = os.path.join(SESSIONS_DIR, f"{agent_id}-{session_id}")
    Path(dir_path).mkdir(parents=True, exist_ok=True)
    return dir_path


def _ensure_session(session_id, agent_id):
    """Ensure a session entry exists. Create or promote as needed.

    Returns the session cache entry.
    """
    cached = _session_cache.get(session_id)

    if not cached:
        # New session
        session_dir = _get_session_dir(agent_id, session_id)
        cached = {"agent_id": agent_id, "session_dir": session_dir}
        _session_cache[session_id] = cached
        label = agent_id[:8] if agent_id != "cli" else "cli"
        print(f"[PROXY] Session {session_id[:8]}... registered as {label}")
        return cached

    if cached["agent_id"] == "cli" and agent_id != "cli":
        # Promote: cli → real agent. Rename folder.
        old_dir = cached["session_dir"]
        new_dir = os.path.join(SESSIONS_DIR, f"{agent_id}-{session_id}")
        if old_dir != new_dir and os.path.exists(old_dir):
            try:
                os.rename(old_dir, new_dir)
            except OSError:
                new_dir = old_dir
        Path(new_dir).mkdir(parents=True, exist_ok=True)
        cached["agent_id"] = agent_id
        cached["session_dir"] = new_dir
        # Re-point loggers after folder rename
        if session_id in _session_loggers:
            del _session_loggers[session_id]
        print(f"[PROXY] Session {session_id[:8]}... promoted: cli → {agent_id[:8]}")

    return cached


def _prepend_legion_prompt(body, legion_prompt):
    """Prepend LEGION combined_system_prompt on top of Claude Code's system field.

    Handles both system field formats:
      - string: prepend as text with separator
      - list of content blocks: insert as new block at position 0
        (preserves Claude Code's cache_control directives on existing blocks)
      - empty/missing: set as the sole system prompt
    """
    system = body.get("system")

    if not system:
        # System field empty or missing (compaction stripped it) — LEGION prompt only
        body["system"] = legion_prompt
    elif isinstance(system, str):
        body["system"] = legion_prompt + "\n\n" + system
    elif isinstance(system, list):
        # Preserve content block structure (cache_control etc.)
        body["system"] = [{"type": "text", "text": legion_prompt}] + system
    else:
        body["system"] = legion_prompt


def _system_to_text(system):
    """Convert system field (string or content blocks list) to plain text."""
    if isinstance(system, str):
        return system
    if isinstance(system, list):
        return "\n".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in system
        )
    return str(system) if system else ""


def _append_vital_constraint(body):
    """Append VITAL CONSTRAINT to the end of the system field.

    Handles both formats:
      - string: concatenate
      - list of content blocks: append as new text block
      - empty/missing: set as string
    """
    system = body.get("system")
    if not system:
        body["system"] = VITAL_CONSTRAINT
    elif isinstance(system, str):
        body["system"] = system + "\n\n" + VITAL_CONSTRAINT
    elif isinstance(system, list):
        body["system"] = system + [{"type": "text", "text": VITAL_CONSTRAINT}]
    else:
        body["system"] = VITAL_CONSTRAINT


# ---------------------------------------------------------------------------
# Per-session loggers — created on demand, cached for reuse
# ---------------------------------------------------------------------------
_session_loggers = {}  # session_id -> {"msg": Logger, "usage": Logger}

# Global loggers — fallback for requests without a session_id
_global_msg_logger = None
_global_usage_logger = None

def _make_logger(name, filepath):
    """Create a logger that writes raw lines to a file.

    Set level explicitly — mitmdump configures root logger before loading
    addons, so basicConfig(level=INFO) is a no-op.
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    # Avoid duplicate handlers if called multiple times
    if not logger.handlers:
        handler = logging.FileHandler(filepath)
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)
    return logger


def _get_loggers(session_id):
    """Get (msg_logger, usage_logger) for a session.

    Returns per-session loggers if session folder exists, else global loggers.
    """
    global _global_msg_logger, _global_usage_logger

    if session_id and session_id in _session_cache:
        if session_id not in _session_loggers:
            session_dir = _session_cache[session_id]["session_dir"]
            _session_loggers[session_id] = {
                "msg": _make_logger(
                    f"claude_proxy.msg.{session_id[:8]}",
                    os.path.join(session_dir, "messages.jsonl"),
                ),
                "usage": _make_logger(
                    f"claude_proxy.usage.{session_id[:8]}",
                    os.path.join(session_dir, "usage.jsonl"),
                ),
            }
        loggers = _session_loggers[session_id]
        return loggers["msg"], loggers["usage"]

    # Global fallback (warmups, CLI without session, etc.)
    if _global_msg_logger is None:
        _global_msg_logger = _make_logger(
            "claude_proxy.messages", os.path.join(LOG_DIR, "messages.jsonl")
        )
    if _global_usage_logger is None:
        _global_usage_logger = _make_logger(
            "claude_proxy.usage", os.path.join(LOG_DIR, "usage.jsonl")
        )
    return _global_msg_logger, _global_usage_logger


# Raw request logging disabled — 900MB+ file growth, not needed in production
# _raw_request_logger = _make_logger(
#     "claude_proxy.raw_requests", os.path.join(LOG_DIR, "raw_requests.jsonl")
# )
#
#
# def _log_raw_request(flow, body):
#     """Log the COMPLETE raw HTTP request BEFORE any proxy modifications."""
#     try:
#         metadata = body.get("metadata") if isinstance(body, dict) else None
#         session_id = _extract_session_id(metadata) if metadata else ""
#         model = body.get("model", "") if isinstance(body, dict) else ""
#         entry = {
#             "timestamp": datetime.now(timezone.utc).isoformat(),
#             "method": flow.request.method,
#             "url": flow.request.url,
#             "headers": dict(flow.request.headers),
#             "body": body,
#             "session_id": session_id,
#             "model": model,
#         }
#         _raw_request_logger.info(json.dumps(entry, ensure_ascii=False))
#         for handler in _raw_request_logger.handlers:
#             handler.flush()
#     except Exception as e:
#         print(f"[PROXY] Raw request log error: {e}")


# ---------------------------------------------------------------------------
# Idle watchdog — self-terminate after inactivity
# ---------------------------------------------------------------------------
_last_activity = time.monotonic()
_activity_lock = threading.Lock()


def _touch_activity():
    """Record that API traffic was seen. Resets the idle timer."""
    global _last_activity
    with _activity_lock:
        _last_activity = time.monotonic()


def _idle_watchdog():
    """Background thread: exits the process after IDLE_TIMEOUT_SECONDS of inactivity.

    Uses SIGTERM for graceful shutdown — mitmdump flushes buffers and
    runs cleanup before exiting. os._exit() would skip that.
    """
    while True:
        time.sleep(60)  # check every minute
        with _activity_lock:
            idle_seconds = time.monotonic() - _last_activity
        if idle_seconds >= IDLE_TIMEOUT_SECONDS:
            print(
                f"[PROXY] No traffic for {int(idle_seconds)}s "
                f"(timeout={IDLE_TIMEOUT_SECONDS}s) — shutting down"
            )
            os.kill(os.getpid(), signal.SIGTERM)


# Start watchdog as daemon thread — dies with the process, no cleanup needed
_watchdog = threading.Thread(target=_idle_watchdog, daemon=True)
_watchdog.start()


# ---------------------------------------------------------------------------
# Cognitive extraction — Haiku rolling extraction per turn
# ---------------------------------------------------------------------------
_extractor = None
_CognitiveExtractorClass = None
_format_turn_content = None
_extractor_init_attempted = False

try:
    from cognitive_extractor import CognitiveExtractor as _CognitiveExtractorClass
    from cognitive_extractor import format_turn_content as _format_turn_content
    # Check for explicit API key first
    _EXTRACTION_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
    if _EXTRACTION_API_KEY:
        _extractor = _CognitiveExtractorClass(api_key=_EXTRACTION_API_KEY)
        _extractor_init_attempted = True
        print("[PROXY] Cognitive extraction enabled (API key)")
    else:
        print("[PROXY] Cognitive extraction deferred — will clone headers from first request")
except ImportError as _ie:
    _extractor_init_attempted = True
    print(f"[PROXY] Cognitive extraction unavailable: {_ie}")
except Exception as _ex:
    _extractor_init_attempted = True
    print(f"[PROXY] Cognitive extraction init failed: {_ex}")


def _lazy_init_extractor(flow_request_headers):
    """Clone working headers from first real proxy request and init extractor.

    Captures ALL headers from a real Claude Code /v1/messages request.
    These headers are proven to work (they just authenticated through us).
    The extractor uses them as-is for Haiku calls — no header construction needed.

    Headers excluded (connection-specific, urllib manages these):
    - Content-Length, Connection, Host, Accept-Encoding
    """
    global _extractor, _extractor_init_attempted, _captured_headers
    if _extractor_init_attempted or _extractor is not None:
        return
    if _CognitiveExtractorClass is None:
        _extractor_init_attempted = True
        return
    _extractor_init_attempted = True
    try:
        # Clone all headers from the working request
        raw_headers = dict(flow_request_headers)
        if not raw_headers:
            print("[PROXY] Cognitive extraction: no headers to capture")
            return

        # Exclude connection-specific headers — urllib manages these
        exclude = {"content-length", "connection", "host", "accept-encoding"}
        captured = {k: v for k, v in raw_headers.items()
                    if k.lower() not in exclude}

        if not captured.get("authorization") and not captured.get("Authorization"):
            print("[PROXY] Cognitive extraction: no Authorization in captured headers")
            return

        _captured_headers.update(captured)
        _extractor = _CognitiveExtractorClass(headers=captured)
        print(f"[PROXY] Cognitive extraction enabled (cloned {len(captured)} headers from proxy traffic)")
    except Exception as ex:
        print(f"[PROXY] Cognitive extraction lazy-init failed: {ex}")


print("[PROXY] Addon loaded — beacon-based LEGION prompt injection active")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _extract_session_id(metadata):
    """Extract session UUID from Anthropic metadata.user_id field.

    Format: user_{hash}_account_{uuid}_session_{session_uuid}
    Returns the session UUID or empty string if not found.
    """
    if not metadata or not isinstance(metadata, dict):
        return ""
    user_id = metadata.get("user_id", "")
    marker = "_session_"
    idx = user_id.find(marker)
    if idx == -1:
        return ""
    return user_id[idx + len(marker):]


def _extract_text(content):
    """Extract readable text from Anthropic content blocks."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(block.get("text", ""))
                elif block.get("type") == "tool_use":
                    parts.append(f"[tool_use: {block.get('name', '?')}({json.dumps(block.get('input', {}), ensure_ascii=False)[:200]})]")
                elif block.get("type") == "tool_result":
                    result_content = block.get("content", "")
                    if isinstance(result_content, list):
                        result_content = " ".join(
                            b.get("text", "") for b in result_content if isinstance(b, dict)
                        ) or str(result_content)[:200]
                    parts.append(f"[tool_result: {str(result_content)[:200]}]")
        return "\n".join(parts)
    return str(content)[:500]


def _parse_sse_response(raw_text):
    """Parse SSE (Server-Sent Events) streaming response from Claude API.

    Reconstructs the full assistant message and usage from SSE events:
      - message_start: contains model, request id, input usage
      - content_block_start: new content block (text or tool_use)
      - content_block_delta: incremental text or tool input
      - message_delta: stop_reason, output usage
      - message_stop: end of stream

    Returns:
        dict: Reconstructed response body with content, usage, model, etc.
    """
    model = ""
    request_id = ""
    stop_reason = ""
    content_blocks = []  # list of {type, text/name/input}
    current_block = None
    input_tokens = 0
    output_tokens = 0
    cache_creation_input_tokens = 0
    cache_read_input_tokens = 0

    for line in raw_text.split("\n"):
        if not line.startswith("data: "):
            continue

        data_str = line[6:].strip()
        if not data_str:
            continue

        try:
            event = json.loads(data_str)
        except (json.JSONDecodeError, ValueError):
            continue

        event_type = event.get("type", "")

        if event_type == "message_start":
            msg = event.get("message", {})
            model = msg.get("model", "")
            request_id = msg.get("id", "")
            usage = msg.get("usage", {})
            input_tokens = usage.get("input_tokens", 0)
            cache_creation_input_tokens = usage.get("cache_creation_input_tokens", 0)
            cache_read_input_tokens = usage.get("cache_read_input_tokens", 0)

        elif event_type == "content_block_start":
            block = event.get("content_block", {})
            block_type = block.get("type", "text")
            if block_type == "text":
                current_block = {"type": "text", "text": block.get("text", "")}
            elif block_type == "tool_use":
                current_block = {
                    "type": "tool_use",
                    "name": block.get("name", ""),
                    "id": block.get("id", ""),
                    "input_json": "",
                }
            else:
                current_block = {"type": block_type, "text": ""}

        elif event_type == "content_block_delta":
            delta = event.get("delta", {})
            if current_block is not None:
                if delta.get("type") == "text_delta":
                    current_block["text"] = current_block.get("text", "") + delta.get("text", "")
                elif delta.get("type") == "input_json_delta":
                    current_block["input_json"] = current_block.get("input_json", "") + delta.get("partial_json", "")

        elif event_type == "content_block_stop":
            if current_block is not None:
                # Finalize tool_use input
                if current_block.get("type") == "tool_use":
                    try:
                        current_block["input"] = json.loads(current_block.pop("input_json", "{}"))
                    except (json.JSONDecodeError, ValueError):
                        current_block["input"] = {}
                    current_block.pop("input_json", None)
                content_blocks.append(current_block)
                current_block = None

        elif event_type == "message_delta":
            delta = event.get("delta", {})
            stop_reason = delta.get("stop_reason", stop_reason)
            usage = event.get("usage", {})
            output_tokens = usage.get("output_tokens", output_tokens)

    return {
        "id": request_id,
        "model": model,
        "content": content_blocks,
        "stop_reason": stop_reason,
        "usage": {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_creation_input_tokens": cache_creation_input_tokens,
            "cache_read_input_tokens": cache_read_input_tokens,
        },
    }


# ---------------------------------------------------------------------------
# Compaction interception — detect + intercept Claude Code compaction requests
# ---------------------------------------------------------------------------
# Anti-loop protection: session_id -> count of consecutive compaction interceptions.
# Reset on any normal (non-compaction) request for that session.
_compaction_attempts = {}

# mitmproxy.http imported lazily to avoid import errors outside mitmdump.
# Response.make() verified against mitmproxy 12.2.1:
#   Response.make(status_code=200, content=b"", headers=())
_mitmproxy_http = None


def _get_mitmproxy_http():
    """Lazy-import mitmproxy.http — only available inside mitmdump process."""
    global _mitmproxy_http
    if _mitmproxy_http is None:
        from mitmproxy import http as _http
        _mitmproxy_http = _http
    return _mitmproxy_http


def _is_compaction_request(body):
    """Detect Claude Code compaction requests via last user message fingerprinting.

    Uses multi-signal detection:
    1. Primary: Last user message starts with compaction prompt template
    2. Secondary: ≥2 of 3 compaction-specific phrases present

    Returns True if this is a compaction request, False otherwise.
    False negatives are safe (normal compaction proceeds via API).
    False positives would be bad (normal request gets fake response).
    """
    messages = body.get("messages", [])
    if not messages:
        return False

    # Find last user message text
    last_user_text = None
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, list):
                last_user_text = " ".join(
                    b.get("text", "") for b in content
                    if isinstance(b, dict) and b.get("type") == "text"
                )
            elif isinstance(content, str):
                last_user_text = content
            break

    if not last_user_text:
        return False

    text = last_user_text.strip()

    # Primary fingerprint: starts with compaction prompt template
    if text.startswith("Your task is to create a detailed summary"):
        return True

    # Secondary fingerprint: multiple compaction-specific phrases
    markers = [
        "IMPORTANT: Do NOT use any tools",
        "respond with ONLY the <summary>",
        "paying close attention to the user's explicit requests",
    ]
    matches = sum(1 for m in markers if m in text)
    return matches >= 2


def _format_extraction_as_summary(extraction):
    """Format cognitive extraction as a Claude Code compaction summary.

    Maps extraction fields to the 9 summary sections expected by
    the CLI's continuation prompt wrapper (l71() function).
    """
    parts = []

    # 1. Primary Request and Intent
    parts.append("1. Primary Request and Intent:")
    parts.append(f"   {extraction.get('summary', 'No summary available.')}")

    # 2. Key Technical Concepts
    parts.append("\n2. Key Technical Concepts:")
    facts = extraction.get("facts", [])
    if facts:
        for f in facts:
            parts.append(f"   - {f}")
    else:
        parts.append("   No key concepts recorded.")

    # 3. Files and Code Sections
    parts.append("\n3. Files and Code Sections:")
    artifacts = extraction.get("key_artifacts", [])
    if artifacts:
        for a in artifacts:
            parts.append(f"   - {a}")
    else:
        parts.append("   No files tracked.")

    # 4. Errors and Fixes
    parts.append("\n4. Errors and Fixes:")
    blockers = extraction.get("blockers", [])
    if blockers:
        for b in blockers:
            parts.append(f"   - ACTIVE: {b}")
    else:
        parts.append("   No active errors or blockers.")

    # 5. Problem Solving
    parts.append("\n5. Problem Solving:")
    threads = extraction.get("open_threads", [])
    if threads:
        for t in threads:
            parts.append(f"   - {t}")
    else:
        parts.append("   No open problem-solving threads.")

    # 6. All User Messages
    parts.append("\n6. All User Messages:")
    parts.append("   (Preserved via LEGION rolling cognitive extraction across all session turns)")

    # 7. Pending Tasks
    parts.append("\n7. Pending Tasks:")
    pending = list(set(blockers + threads))
    if pending:
        for p in pending:
            parts.append(f"   - {p}")
    else:
        parts.append("   No pending tasks — all work completed or not yet started.")

    # 8. Current Work
    parts.append("\n8. Current Work:")
    parts.append(f"   {extraction.get('summary', 'No current work recorded.')}")

    # 9. Optional Next Step
    decisions = extraction.get("decisions", [])
    if decisions:
        parts.append("\n9. Optional Next Step:")
        parts.append(f"   Continue with: {decisions[0]}")

    # Bonus: Tools context (helps continuation)
    tools = extraction.get("tools_invoked", [])
    if tools:
        parts.append(f"\nTools used in this session: {', '.join(tools)}")

    return "\n".join(parts)


def _build_compaction_response(body, extraction):
    """Build a synthetic Messages API response from cognitive extraction.

    Creates a response that Claude Code's CLI will accept as a valid
    compaction summary. The extraction data is formatted into the
    <analysis>/<summary> XML tags that the CLI's xX5() function strips.

    Uses msg_ prefix for synthetic message ID per Ragen's R-1 mitigation
    (less detectable, lower rejection risk than msg_legion_compact_).

    Args:
        body: The original request body (used for model echo)
        extraction: The cognitive extraction dict from cache

    Returns:
        mitmproxy http.Response object
    """
    http = _get_mitmproxy_http()
    summary_text = _format_extraction_as_summary(extraction)

    response_text = (
        "<analysis>\n"
        "LEGION cognitive memory extraction used as compaction replacement. "
        "This summary is generated from the rolling per-turn extraction, "
        "preserving decisions, facts, artifacts, and current work state "
        "across all turns of this session.\n"
        "</analysis>\n\n"
        f"<summary>\n{summary_text}\n</summary>"
    )

    # Use msg_ prefix per Ragen's R-1 mitigation — less fingerprint-able
    response_body = {
        "id": f"msg_{uuid.uuid4().hex[:24]}",
        "type": "message",
        "role": "assistant",
        "content": [
            {
                "type": "text",
                "text": response_text,
            }
        ],
        "model": body.get("model", "claude-haiku-4-5-20251001"),
        "stop_reason": "end_turn",
        "stop_sequence": None,
        "usage": {
            "input_tokens": 50,
            "output_tokens": len(response_text.split()) * 2,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        },
    }

    return http.Response.make(
        200,
        json.dumps(response_body, ensure_ascii=False).encode("utf-8"),
        {"Content-Type": "application/json"},
    )


# ---------------------------------------------------------------------------
# Main addon
# ---------------------------------------------------------------------------
class ClaudeAPILogger:
    """Beacon-based LEGION prompt injection, per-session logging."""

    def __init__(self):
        self.tracked_flows = set()

    def _try_intercept_compaction(self, flow, body, session_id):
        """Attempt to intercept compaction with cognitive extraction.

        Returns True if intercepted (flow.response set), False if pass-through.
        All failures fall through to normal API compaction — never worse than
        status quo. Per Ragen's impact analysis: extraction failure MUST NOT
        crash proxy.
        """
        # Log first 100 chars of detected compaction text (Ragen R-3 mitigation)
        messages = body.get("messages", [])
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                if isinstance(content, str):
                    preview = content[:100]
                elif isinstance(content, list):
                    preview = " ".join(
                        b.get("text", "")[:100] for b in content
                        if isinstance(b, dict) and b.get("type") == "text"
                    )[:100]
                else:
                    preview = str(content)[:100]
                print(f"[PROXY] Compaction detected — preview: {preview!r}")
                break

        if not session_id:
            print("[PROXY] Compaction detected but no session_id — pass-through")
            return False

        if not _extractor:
            print("[PROXY] Compaction detected but extractor not initialized — pass-through")
            return False

        # Anti-loop protection: after 2 consecutive interceptions without a
        # successful continuation, disable for this session
        attempts = _compaction_attempts.get(session_id, 0)
        if attempts >= 2:
            print(
                f"[PROXY] Compaction for {session_id[:8]}... already intercepted "
                f"{attempts} times — pass-through (anti-loop)"
            )
            return False

        extraction = _extractor._extraction_cache.get(session_id)
        if not extraction:
            print(f"[PROXY] Compaction detected for {session_id[:8]}... but no extraction cached — pass-through")
            return False

        # Check freshness — extraction should have at least a few turns
        turn_count = _extractor._turn_counts.get(session_id, 0)
        if turn_count < 2:
            print(
                f"[PROXY] Compaction detected for {session_id[:8]}... "
                f"but only {turn_count} turns — pass-through"
            )
            return False

        try:
            flow.response = _build_compaction_response(body, extraction)
            _compaction_attempts[session_id] = attempts + 1
            print(
                f"[PROXY] ⚡ Compaction INTERCEPTED for {session_id[:8]}... "
                f"(turn {turn_count}, {len(extraction.get('facts', []))} facts, "
                f"{len(extraction.get('decisions', []))} decisions)"
            )
            return True
        except Exception as e:
            print(f"[PROXY] Compaction interception failed: {e} — pass-through")
            return False

    def request(self, flow):
        """Intercept request: beacon scan → inject LEGION prompt → track.

        Flow:
        1. Gate: POST /v1/messages only
        2. Skip warmup pings (no system + single short message)
        3. Scan raw body for XLEGIONX beacon
        4. Beacon found:
           a. Hash not in _beacon_cache → extract combined_system_prompt, cache it
           b. Hash in _beacon_cache → read from cache
           c. Prepend cached LEGION prompt on top of Claude Code's system field
        5. No beacon → pass through (pre-whoAmI warmup or pure CLI)
        6. Track for response logging
        """
        if flow.request.method != "POST":
            return

        if "/v1/messages" not in flow.request.path:
            return

        # TEMPORARY DEBUG — dump raw headers from every request
        print(f"[PROXY-DEBUG] Headers: {dict(flow.request.headers)}")

        # Lazy-init extractor from first real request's headers
        _lazy_init_extractor(flow.request.headers)

        try:
            raw_body = flow.request.get_text()
            body = json.loads(raw_body)
            if "messages" not in body:
                return

            # Skip warmup pings: no system prompt and a single short
            # user message (e.g. "foo", "ping"). Claude Agent SDK fires
            # ~50 of these to warm up TCP connections before real work.
            if not body.get("system"):
                msgs = body.get("messages", [])
                if len(msgs) == 1:
                    content = msgs[0].get("content", "")
                    if isinstance(content, str) and len(content) <= 10:
                        return


            metadata = body.get("metadata")
            session_id = _extract_session_id(metadata)
            print(f"[PROXY DEBUG] metadata={json.dumps(metadata) if metadata else 'None'}, session_id={session_id!r}")

            # --- Compaction interception ---
            # Detect compaction requests and intercept with LEGION cognitive
            # extraction. Must happen AFTER raw logging (audit trail) and
            # BEFORE vital constraint / beacon (compaction doesn't need them).
            if _is_compaction_request(body):
                intercepted = self._try_intercept_compaction(flow, body, session_id)
                if intercepted:
                    _touch_activity()
                    return  # Early return — synthetic response set, skip everything
            else:
                # Normal request — reset anti-loop counter for this session
                if session_id:
                    _compaction_attempts.pop(session_id, None)

            # _log_raw_request(flow, body)  # Disabled — 900MB+ file growth

            modified = False

            # --- Append vital constraint to system prompt ---
            _append_vital_constraint(body)
            modified = True

            # --- Beacon scan → cache → inject ---
            beacon = _scan_beacon(raw_body)
            if beacon:
                agent_id, prompt_hash = beacon

                if prompt_hash not in _beacon_cache:
                    # New or changed — extract combined_system_prompt from messages
                    combined = _extract_prompt_from_messages(
                        body.get("messages", []), agent_id
                    )
                    if combined:
                        _beacon_cache[prompt_hash] = combined
                        print(f"[PROXY] Cached LEGION prompt: {agent_id[:8]}... hash={prompt_hash}")

                # Ensure session folder exists and is named for this agent
                if session_id:
                    _ensure_session(session_id, agent_id)

            elif session_id:
                # No beacon — register as "cli" for logging
                _ensure_session(session_id, "cli")

            if modified:
                flow.request.set_text(json.dumps(body, ensure_ascii=False, separators=(',', ':')))

            self.tracked_flows.add(id(flow))
            flow.request_body = body
            flow.request_timestamp = datetime.now(timezone.utc).isoformat()
            _touch_activity()
        except (json.JSONDecodeError, ValueError):
            pass

    def response(self, flow):
        """Log clean messages and usage for tracked flows."""
        flow_id = id(flow)

        if flow_id not in self.tracked_flows:
            return

        self.tracked_flows.discard(flow_id)

        req_body = getattr(flow, "request_body", {})
        now = datetime.now(timezone.utc).isoformat()

        # Parse response — detect streaming vs non-streaming
        response_body = {}
        if flow.response.content:
            raw_text = flow.response.get_text()
            content_type = flow.response.headers.get("content-type", "")

            if "text/event-stream" in content_type or raw_text.startswith("event:"):
                # Streaming SSE response — reconstruct from events
                response_body = _parse_sse_response(raw_text)
            else:
                # Non-streaming JSON response
                try:
                    response_body = json.loads(raw_text)
                except (json.JSONDecodeError, ValueError):
                    pass

        request_id = (
            flow.response.headers.get("request-id", "")
            or response_body.get("id", "")
        )
        model = response_body.get("model", req_body.get("model", ""))
        session_id = _extract_session_id(req_body.get("metadata"))

        # Get per-session or global loggers
        msg_logger, usage_logger = _get_loggers(session_id)

        # --- Messages log: request + response in one entry ---
        req_messages = []

        system = req_body.get("system")
        if system:
            req_messages.append({
                "role": "system",
                "text": _extract_text(system),
            })

        for msg in req_body.get("messages", []):
            req_messages.append({
                "role": msg.get("role", "?"),
                "text": _extract_text(msg.get("content", "")),
            })

        msg_entry = {
            "timestamp": now,
            "session_id": session_id,
            "request_id": request_id,
            "model": model,
            "messages": req_messages,
            "response": {
                "stop_reason": response_body.get("stop_reason", ""),
                "text": _extract_text(response_body.get("content", [])),
            } if response_body.get("content") else None,
        }
        msg_logger.info(json.dumps(msg_entry, ensure_ascii=False))
        # Flush handlers to disk
        for handler in msg_logger.handlers:
            handler.flush()

        # --- Usage log: token counts ---
        usage = response_body.get("usage", {})
        if usage and (usage.get("input_tokens") or usage.get("output_tokens")):
            usage_entry = {
                "timestamp": now,
                "session_id": session_id,
                "request_id": request_id,
                "model": model,
                "input_tokens": usage.get("input_tokens", 0),
                "output_tokens": usage.get("output_tokens", 0),
                "cache_creation_input_tokens": usage.get("cache_creation_input_tokens", 0),
                "cache_read_input_tokens": usage.get("cache_read_input_tokens", 0),
            }

            usage_logger.info(json.dumps(usage_entry, ensure_ascii=False))
            # Flush handlers to disk
            for handler in usage_logger.handlers:
                handler.flush()

        status = flow.response.status_code
        in_tok = usage.get("input_tokens", "?")
        out_tok = usage.get("output_tokens", "?")
        print(f"[LOGGED] {request_id} {model} {status} in={in_tok} out={out_tok}")

        # --- Cognitive extraction: Haiku rolling extraction per turn ---
        # Extraction failure MUST NOT crash the proxy — wrapped in try/except.
        try:
            if _extractor and session_id:
                # Filter: skip error responses (non-2xx)
                if flow.response.status_code and flow.response.status_code >= 400:
                    pass  # Don't extract error responses
                else:
                    turn_content = _format_turn_content(req_body, response_body) if _format_turn_content else None
                    if turn_content:
                        # Get session dir and agent_id from session cache
                        session_info = _session_cache.get(session_id, {})
                        s_dir = session_info.get("session_dir", "")
                        a_id = session_info.get("agent_id", "cli")
                        if s_dir:
                            _extractor.fire(
                                session_id=session_id,
                                agent_id=a_id,
                                turn_content=turn_content,
                                session_dir=s_dir,
                                model=model,
                                input_tokens=usage.get("input_tokens", 0),
                                output_tokens=usage.get("output_tokens", 0),
                            )
        except Exception as e:
            print(f"[EXTRACTION ERROR] {e}")

    def error(self, flow):
        """Clean up tracked flows on connection errors.

        Without this, flows where the upstream never responds (timeout,
        connection reset) stay in tracked_flows forever — memory leak.
        """
        self.tracked_flows.discard(id(flow))


addons = [ClaudeAPILogger()]
