"""Claude API proxy addon for mitmproxy."""
