"""Cognitive extraction engine — per-turn Haiku rolling extraction.

Runs inside the mitmdump process (standalone Python env). Intercepts
each API turn, calls Haiku to produce a rolling structured extraction,
writes to local file, and triggers a storage subprocess for DB persistence.

Uses raw urllib for Haiku API calls — zero external dependencies.
Primary auth: cloned headers from real Claude Code proxy traffic.
Fallback: OAuth bearer tokens or standard API keys.

Design ref: Allen's architecture entry 66b8405b, Sections 5-8.
"""

import gzip
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Haiku extraction system prompt (Allen's Section 6.1)
# ---------------------------------------------------------------------------
EXTRACTION_SYSTEM_PROMPT = """\
You are a cognitive extraction agent. Your job is to maintain a rolling \
structured summary of an AI assistant's work session.

You receive:
1. The PREVIOUS extraction (JSON) — what you extracted so far
2. The LATEST turn — the most recent user message and assistant response

Your job:
- UPDATE the extraction with new information from the latest turn
- COMPRESS stale information that is no longer immediately relevant
- PRESERVE important decisions, facts, and blockers
- DEDUPLICATE — don't add facts/decisions that already exist
- Keep the summary CURRENT — it should reflect the present state of work

Output ONLY valid JSON matching the schema below. No markdown, no explanation.

Schema:
{
  "summary": "1-3 sentence description of current work state (max 500 chars)",
  "decisions": ["Important decisions made (max 10, newest first)"],
  "facts": ["Discovered facts about the codebase/system (max 15)"],
  "blockers": ["Current blockers preventing progress (max 5, clear when resolved)"],
  "open_threads": ["Topics still being worked on or unresolved (max 5)"],
  "key_artifacts": ["File paths, modules, or resources being worked with (max 10)"],
  "tools_invoked": ["Unique tool/function names used in session (max 15)"]
}

Rules:
- If previous extraction is empty, this is Turn 1 — create fresh
- Remove resolved blockers
- Drop stale open_threads (>3 turns old with no activity)
- Merge duplicate facts
- Keep decisions in reverse chronological order (newest first)
- If a fact contradicts a previous fact, keep the newer one
- summary should always describe CURRENT activity, not history"""

# Haiku model identifier
HAIKU_MODEL = "claude-haiku-4-5-20251001"

# Max chars per user/assistant content in turn extraction
MAX_TURN_CHARS = 2000

# Circuit breaker settings
MAX_CONSECUTIVE_ERRORS = 3
BACKOFF_TURNS = 5

# ---------------------------------------------------------------------------
# Logger — writes to session folder extraction.log
# ---------------------------------------------------------------------------
_module_logger = logging.getLogger("legion.cognitive_extractor")


def _get_extraction_logger(session_dir):
    """Get or create a file logger for extraction events in a session folder."""
    name = f"legion.extraction.{os.path.basename(session_dir)}"
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.DEBUG)
        log_path = os.path.join(session_dir, "extraction.log")
        handler = logging.FileHandler(log_path)
        handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        )
        logger.addHandler(handler)
    return logger


# ---------------------------------------------------------------------------
# CognitiveExtractor
# ---------------------------------------------------------------------------
class CognitiveExtractor:
    """Per-turn Haiku rolling extraction engine.

    Thread-safe. One extraction at a time per session (serialized via Lock).
    Non-blocking fire() spawns daemon threads for Haiku calls.
    """

    # Anthropic Messages API endpoint (direct — NOT through proxy to avoid loop)
    # ?beta=true is required for OAuth bearer tokens — matches Claude Code's URL
    _API_URL = "https://api.anthropic.com/v1/messages?beta=true"

    def __init__(self, api_key=None, auth_token=None, headers=None):
        """Init with cloned proxy headers (preferred), API key, or OAuth token.

        Three auth modes (priority order):
        1. headers (dict): Cloned from real Claude Code request via proxy.
           Used as-is — all headers (Auth, anthropic-beta, User-Agent, X-Stainless-*, etc.)
           are proven to work. This is the primary mode.
        2. api_key (sk-ant-api03-*): Standard API key, uses x-api-key header.
        3. auth_token (sk-ant-oat*): OAuth bearer token, builds minimal headers.

        Sends requests directly to api.anthropic.com via raw urllib.
        """
        self._headers = None
        if headers:
            # Cloned headers from proxy traffic — use as-is
            # These are the EXACT headers Claude Code used successfully
            self._headers = dict(headers)
        elif auth_token:
            # OAuth bearer token — requires anthropic-beta: oauth-2025-04-20
            self._headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "anthropic-version": "2023-06-01",
                "Authorization": f"Bearer {auth_token}",
                "anthropic-beta": "oauth-2025-04-20",
            }
        elif api_key:
            # Standard API key
            self._headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "anthropic-version": "2023-06-01",
                "x-api-key": api_key,
            }

        self._extraction_cache = {}   # session_id -> dict (latest extraction)
        self._locks = {}              # session_id -> threading.Lock
        self._lock_guard = threading.Lock()  # protects _locks dict creation
        self._turn_counts = {}        # session_id -> int
        self._error_counts = {}       # session_id -> consecutive errors
        self._backoff_until = {}      # session_id -> turn number to resume
        self._last_error = ""         # last error message for diagnostics
        self._enabled = self._headers is not None

    def _get_lock(self, session_id):
        """Get or create a per-session lock (thread-safe)."""
        if session_id not in self._locks:
            with self._lock_guard:
                if session_id not in self._locks:
                    self._locks[session_id] = threading.Lock()
        return self._locks[session_id]

    def fire(self, session_id, agent_id, turn_content, session_dir,
             model="", input_tokens=0, output_tokens=0):
        """Non-blocking extraction trigger. Called from addon response().

        Spawns a daemon thread that serializes per-session via Lock.
        If the session lock is held (previous extraction still running),
        the thread blocks until it can acquire the lock — no turns are dropped.

        Args:
            session_id: Anthropic session UUID
            agent_id: LEGION agent UUID or "cli"
            turn_content: Formatted string of user message + assistant response
            session_dir: Path to session folder for file output
            model: Primary model used for this turn
            input_tokens: Input token count for this turn
            output_tokens: Output token count for this turn
        """
        if not self._enabled:
            return

        if not self._should_extract(session_id):
            return

        t = threading.Thread(
            target=self._worker,
            args=(session_id, agent_id, turn_content, session_dir,
                  model, input_tokens, output_tokens),
            daemon=True,
            name=f"extraction-{session_id[:8]}",
        )
        t.start()

    def _should_extract(self, session_id):
        """Check circuit breaker — skip if too many consecutive errors."""
        turn = self._turn_counts.get(session_id, 0)
        backoff_until = self._backoff_until.get(session_id, 0)
        if turn < backoff_until:
            return False
        return True

    def _worker(self, session_id, agent_id, turn_content, session_dir,
                model, input_tokens, output_tokens):
        """Background thread: Haiku call -> cache -> file -> storage subprocess.

        Acquires per-session lock to serialize extractions.
        All exceptions caught — extraction failure must never propagate.
        """
        log = _get_extraction_logger(session_dir)
        lock = self._get_lock(session_id)

        with lock:
            try:
                # Increment turn counter
                self._turn_counts[session_id] = self._turn_counts.get(session_id, 0) + 1
                turn_number = self._turn_counts[session_id]

                # Get previous extraction (cold start = empty)
                previous = self._extraction_cache.get(session_id)

                # Call Haiku
                extraction = self._call_haiku(previous, turn_content)

                if extraction is None:
                    # Haiku call failed — increment error counter
                    errors = self._error_counts.get(session_id, 0) + 1
                    self._error_counts[session_id] = errors
                    last_err = getattr(self, '_last_error', 'unknown')
                    log.warning(f"Haiku call failed (error {errors}): {last_err}")
                    if errors >= MAX_CONSECUTIVE_ERRORS:
                        self._backoff_until[session_id] = turn_number + BACKOFF_TURNS
                        log.warning(
                            f"Circuit breaker: {errors} consecutive errors, "
                            f"backing off until turn {turn_number + BACKOFF_TURNS}"
                        )
                    return

                # Success — reset error counter
                self._error_counts[session_id] = 0

                # Update cache
                self._extraction_cache[session_id] = extraction

                # Build full session record
                now = datetime.now(timezone.utc).isoformat()
                record = {
                    "schema_version": 1,
                    "session_id": session_id,
                    "agent_id": agent_id,
                    "turn_number": turn_number,
                    "first_seen_at": (
                        self._extraction_cache.get(session_id, {}).get("first_seen_at", now)
                        if turn_number > 1 else now
                    ),
                    "last_updated_at": now,
                    "model_primary": model,
                    "total_input_tokens": input_tokens,
                    "total_output_tokens": output_tokens,
                    "extraction": extraction,
                }

                # Accumulate token totals from previous record
                if turn_number > 1:
                    prev_file = os.path.join(session_dir, "extraction.json")
                    if os.path.exists(prev_file):
                        try:
                            with open(prev_file, "r") as f:
                                prev_record = json.load(f)
                            record["first_seen_at"] = prev_record.get("first_seen_at", now)
                            record["total_input_tokens"] = (
                                prev_record.get("total_input_tokens", 0) + input_tokens
                            )
                            record["total_output_tokens"] = (
                                prev_record.get("total_output_tokens", 0) + output_tokens
                            )
                        except (json.JSONDecodeError, OSError):
                            pass

                # Write to file (atomic)
                self._write_file(session_dir, record)

                # Sync to DB every turn (per user refinement)
                self._sync_to_legion(session_id, agent_id, record, session_dir)

                log.info(
                    f"Turn {turn_number} extracted | "
                    f"summary={extraction.get('summary', '')[:80]}..."
                )

            except Exception as e:
                log.error(f"Extraction worker failed: {e}", exc_info=True)

    def _call_haiku(self, previous, turn_content):
        """Call Haiku via raw urllib to api.anthropic.com.

        Returns parsed extraction dict or None on failure.
        Uses self._headers built in __init__ — either x-api-key or
        Authorization: Bearer + oauth beta header.
        """
        user_message = self._build_haiku_input(previous, turn_content)

        payload = json.dumps({
            "model": HAIKU_MODEL,
            "max_tokens": 1024,
            "system": EXTRACTION_SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": user_message}],
            "tools": [{
                "name": "cognitive_extraction",
                "description": "Output structured extraction of the conversation state",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "summary": {"type": "string", "description": "1-3 sentence description of current work state (max 500 chars)"},
                        "decisions": {"type": "array", "items": {"type": "string"}, "description": "Important decisions made (max 10, newest first)"},
                        "facts": {"type": "array", "items": {"type": "string"}, "description": "Discovered facts about the codebase/system (max 15)"},
                        "blockers": {"type": "array", "items": {"type": "string"}, "description": "Current blockers preventing progress (max 5)"},
                        "open_threads": {"type": "array", "items": {"type": "string"}, "description": "Topics still being worked on (max 5)"},
                        "key_artifacts": {"type": "array", "items": {"type": "string"}, "description": "File paths or resources being worked with (max 10)"},
                        "tools_invoked": {"type": "array", "items": {"type": "string"}, "description": "Tool/function names used in session (max 15)"},
                    },
                    "required": ["summary", "decisions", "facts", "blockers", "open_threads", "key_artifacts", "tools_invoked"],
                },
            }],
            "tool_choice": {"type": "tool", "name": "cognitive_extraction"},
        }).encode("utf-8")

        req = urllib.request.Request(
            self._API_URL,
            data=payload,
            headers=self._headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw_bytes = resp.read()
                resp_ct = resp.headers.get("Content-Type", "?")
                resp_ce = resp.headers.get("Content-Encoding", "none")
                _module_logger.info(
                    f"Haiku raw response: status={resp.status} ct={resp_ct} ce={resp_ce} "
                    f"len={len(raw_bytes)} body_start={raw_bytes[:300]}"
                )
                # Handle gzip compression if present
                if resp_ce == "gzip":
                    raw_bytes = gzip.decompress(raw_bytes)
                elif resp_ce == "br":
                    # brotli - try import, fallback to error
                    try:
                        import brotli
                        raw_bytes = brotli.decompress(raw_bytes)
                    except ImportError:
                        _module_logger.warning("Brotli compressed response but brotli module not available")
                        self._last_error = "Brotli decompression unavailable"
                        return None
                body = json.loads(raw_bytes.decode("utf-8"))

            # Extract structured output from tool_use content block
            content = body.get("content", [])
            if not content:
                _module_logger.warning("Haiku returned empty content")
                return None

            # Find tool_use block — structured output comes as tool input
            extraction = None
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    extraction = block.get("input", {})
                    break

            # Fallback: try text content with code fence stripping (legacy path)
            if extraction is None:
                text = content[0].get("text", "")
                text = text.strip()
                if text.startswith("```"):
                    text = text.split("\n", 1)[1] if "\n" in text else text[3:]
                if text.endswith("```"):
                    text = text.rsplit("```", 1)[0]
                text = text.strip()
                if text:
                    extraction = json.loads(text)
                else:
                    _module_logger.warning("Haiku returned no tool_use or text content")
                    return None

            # Basic schema validation
            required_keys = {"summary", "decisions", "facts"}
            if not required_keys.issubset(extraction.keys()):
                _module_logger.warning(
                    f"Haiku response missing keys: {required_keys - extraction.keys()}"
                )
                return None

            return extraction

        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")[:500]
            _module_logger.warning(f"Haiku API error {e.code}: {error_body}")
            self._last_error = f"HTTP {e.code}: {error_body}"
            return None
        except urllib.error.URLError as e:
            _module_logger.warning(f"Haiku connection error: {e.reason}")
            self._last_error = f"Connection error: {e.reason}"
            return None
        except (json.JSONDecodeError, ValueError, KeyError, IndexError) as e:
            _module_logger.warning(f"Haiku response parse error: {e}")
            self._last_error = f"Parse error: {e}"
            return None
        except Exception as e:
            _module_logger.warning(f"Haiku call failed: {e}")
            self._last_error = f"Failed: {e}"
            return None

    @staticmethod
    def _build_haiku_input(previous, turn_content):
        """Build the user message for Haiku."""
        parts = []

        if previous:
            parts.append("## Previous Extraction")
            parts.append(json.dumps(previous, indent=2))
            parts.append("")
        else:
            parts.append("## Previous Extraction")
            parts.append("(none -- this is Turn 1)")
            parts.append("")

        parts.append("## Latest Turn")
        parts.append(turn_content)

        return "\n".join(parts)

    @staticmethod
    def _write_file(session_dir, record):
        """Atomic write extraction.json to session folder.

        Writes to .tmp first, then os.rename() for POSIX atomicity.
        """
        target = os.path.join(session_dir, "extraction.json")
        tmp = target + ".tmp"
        try:
            with open(tmp, "w") as f:
                json.dump(record, f, ensure_ascii=False, indent=2)
            os.rename(tmp, target)
        except OSError as e:
            _module_logger.warning(f"File write failed: {e}")
            # Clean up tmp if rename failed
            try:
                os.unlink(tmp)
            except OSError:
                pass

    @staticmethod
    def _sync_to_legion(session_id, agent_id, record, session_dir):
        """Spawn subprocess to upsert extraction into LEGION sessions table.

        The subprocess (legion-extraction-store) runs in the MCP virtualenv,
        which has gRPC access. Reads payload from stdin.
        Fire-and-forget — we don't wait for result.
        Stderr goes to extraction_error.log for debuggability.
        """
        payload = {
            "session_id": session_id,
            "agent_id": agent_id,
            "company_id": os.environ.get("LEGION_COMPANY_ID", ""),
            "project_id": os.environ.get("LEGION_PROJECT_ID", ""),
            "turn_number": record.get("turn_number", 0),
            "extraction": json.dumps(record.get("extraction", {})),
            "model_primary": record.get("model_primary", ""),
            "total_input_tokens": record.get("total_input_tokens", 0),
            "total_output_tokens": record.get("total_output_tokens", 0),
        }

        # Find the entry point binary
        runner_cmd = shutil.which("legion-extraction-store")
        if runner_cmd:
            cmd = [runner_cmd]
        else:
            # Fallback: run as Python module using system Python
            # The MCP virtualenv's python should be on PATH
            cmd = [sys.executable, "-m", "legion_mcp.extraction_store"]

        err_log = None
        try:
            # Redirect stderr to log file for debugging instead of DEVNULL
            err_log_path = os.path.join(
                session_dir, "extraction_error.log"
            ) if session_dir else os.path.join(
                os.environ.get("TMPDIR", "/tmp"), "legion_extraction_error.log"
            )
            err_log = open(err_log_path, "a")

            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=err_log,
                start_new_session=True,
                env={
                    **os.environ,
                    # Ensure gRPC connection env vars are passed
                    "GRPC_SERVER_HOST": os.environ.get(
                        "LEGION_GRPC_HOST",
                        os.environ.get("GRPC_SERVER_HOST", "api.wearethelegion.com")
                    ),
                    "GRPC_SERVER_PORT": os.environ.get(
                        "LEGION_GRPC_PORT",
                        os.environ.get("GRPC_SERVER_PORT", "50051")
                    ),
                },
            )
            process.stdin.write(json.dumps(payload).encode("utf-8"))
            process.stdin.close()
            # Close log handle in parent — child inherits the fd
            if err_log:
                err_log.close()
                err_log = None
            # Fire-and-forget — don't wait
        except Exception as e:
            _module_logger.warning(f"Storage subprocess spawn failed: {e}")
            if err_log:
                err_log.close()


# ---------------------------------------------------------------------------
# Turn content formatting helpers (used by addon.py)
# ---------------------------------------------------------------------------
def format_turn_content(req_body, response_body):
    """Extract and format turn content for Haiku extraction.

    Returns formatted string or None if turn should be skipped.

    Filters:
    - Skip warmup pings (<10 chars, no system prompt)
    - Skip error responses (no content)
    - Skip Haiku extraction-of-extraction loops
    """
    # Filter: error responses (no content)
    resp_content = response_body.get("content", [])
    if not resp_content:
        return None

    # Filter: check for extraction-of-extraction loop
    resp_model = response_body.get("model", "")
    if "haiku" in resp_model.lower():
        # Check if this looks like an extraction call (our system prompt)
        system = req_body.get("system", "")
        system_text = system if isinstance(system, str) else str(system)
        if "cognitive extraction agent" in system_text.lower():
            return None

    # Filter: warmup pings
    if not req_body.get("system"):
        msgs = req_body.get("messages", [])
        if len(msgs) == 1:
            content = msgs[0].get("content", "")
            if isinstance(content, str) and len(content) <= 10:
                return None

    # Extract last user message
    user_text = ""
    messages = req_body.get("messages", [])
    for msg in reversed(messages):
        if msg.get("role") == "user":
            user_text = _extract_text_content(msg.get("content", ""))
            break

    # Extract assistant response
    assistant_text = _extract_text_content(resp_content)

    # Extract tool names from response
    tool_names = []
    if isinstance(resp_content, list):
        for block in resp_content:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                tool_names.append(block.get("name", "?"))

    # Truncate
    user_text = user_text[:MAX_TURN_CHARS]
    assistant_text = assistant_text[:MAX_TURN_CHARS]

    parts = []
    parts.append(f"User: {user_text}")
    parts.append(f"Assistant: {assistant_text}")
    if tool_names:
        parts.append(f"Tools called: {', '.join(tool_names)}")
    model = response_body.get("model", req_body.get("model", ""))
    if model:
        parts.append(f"Model: {model}")

    return "\n".join(parts)


def _extract_text_content(content):
    """Extract readable text from Anthropic content (string or blocks list)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                btype = block.get("type", "")
                if btype == "text":
                    parts.append(block.get("text", ""))
                elif btype == "tool_use":
                    parts.append(f"[tool_use: {block.get('name', '?')}]")
                elif btype == "tool_result":
                    rc = block.get("content", "")
                    if isinstance(rc, list):
                        rc = " ".join(
                            b.get("text", "")
                            for b in rc
                            if isinstance(b, dict)
                        )[:200]
                    parts.append(f"[tool_result: {str(rc)[:200]}]")
        return "\n".join(parts)
    return str(content)[:500]
