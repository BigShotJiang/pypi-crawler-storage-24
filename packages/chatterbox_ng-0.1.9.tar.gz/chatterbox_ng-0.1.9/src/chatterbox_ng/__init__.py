try:
    from importlib.metadata import version
except ImportError:
    from importlib_metadata import version  # For Python <3.8

__version__ = version('chatterbox-ng')


from .mtl_tts import SUPPORTED_LANGUAGES, ChatterboxMultilingualTTS
from .tts import ChatterboxTTS
from .vc import ChatterboxVC
