"""
Pure helpers for blog webhook PATCH bodies (no Django imports).

camelCase keys from Zapier/n8n are normalized to snake_case before the handler runs.
"""

# Documented optional PATCH fields (snake_case). The handler applies each via
# `if key in data` in webhook.blog_webhook_update — not a separate whitelist runtime.
PATCH_ARTICLE_OPTIONAL_KEYS = frozenset({
    'title', 'seo_title', 'lead', 'introduction', 'content', 'status',
    'publish_date', 'publish_time', 'cta_id',
    'cover_image_url', 'cover_image_alt_text',
    'featured_image_url', 'featured_image_alt_text',
})


def normalize_blog_webhook_patch_keys(data):
    """
    Copy camelCase keys to snake_case for blog_webhook_update.

    Many automation tools JSON-encode camelCase; without this, publish_date etc.
    are ignored and `updated_fields` stays empty.
    """
    if not isinstance(data, dict):
        return
    aliases = (
        ('publish_date', 'publishDate'),
        ('publish_time', 'publishTime'),
        ('seo_title', 'seoTitle'),
        ('cover_image_url', 'coverImageUrl'),
        ('cover_image_alt_text', 'coverImageAltText'),
        ('featured_image_url', 'featuredImageUrl'),
        ('featured_image_alt_text', 'featuredImageAltText'),
        ('cta_id', 'ctaId'),
    )
    for canonical, alias in aliases:
        if alias in data and canonical not in data:
            data[canonical] = data[alias]
