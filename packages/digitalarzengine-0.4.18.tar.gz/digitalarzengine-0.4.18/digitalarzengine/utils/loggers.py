import os
import traceback
from datetime import datetime
import inspect
import json
from typing import Any, Dict, Optional


class DALogger:
    ANSI_COLORS = {
        "DEBUG": "\033[96m",    # Cyan
        "INFO": "\033[94m",     # Blue
        "WARNING": "\033[93m",  # Yellow
        "ERROR": "\033[91m",    # Red
        "SUCCESS": "\033[92m",  # Green
        "CRITICAL": "\033[95m", # Magenta
        "RESET": "\033[0m",
    }

    LEVEL_ORDER = {
        "DEBUG": 10,
        "INFO": 20,
        "SUCCESS": 25,
        "WARNING": 30,
        "ERROR": 40,
        "CRITICAL": 50,
    }

    def __init__(
        self,
        name: str = "DALogger",
        enabled: bool = True,
        trim_length: int = 300,
        min_level: str = "DEBUG",
        log_to_file: bool = False,
        log_file_path: str = "app.log",
        show_location_default: bool = True,
    ):
        self.name = name
        self.enabled = enabled
        self.trim_length = trim_length
        self.min_level = min_level
        self.log_to_file = log_to_file
        self.log_file_path = log_file_path
        self.show_location_default = show_location_default

    # ----------------------------
    # internals
    # ----------------------------
    def _should_log(self, level: str) -> bool:
        if not self.enabled:
            return False
        return self.LEVEL_ORDER.get(level, 0) >= self.LEVEL_ORDER.get(self.min_level, 0)

    def _message_to_str(self, message: Any) -> str:
        """
        Convert arbitrary objects into a safe, readable string.
        - dict/list -> pretty JSON when possible
        - objects with model_dump/model_dump_json (pydantic v2) -> use them
        - fallback -> str(obj)
        """
        try:
            # Pydantic v2
            if hasattr(message, "model_dump_json") and callable(message.model_dump_json):
                return message.model_dump_json()
            if hasattr(message, "model_dump") and callable(message.model_dump):
                return json.dumps(message.model_dump(), ensure_ascii=False, default=str)

            # Common containers
            if isinstance(message, (dict, list, tuple, set)):
                return json.dumps(message, ensure_ascii=False, default=str)

            # Bytes
            if isinstance(message, (bytes, bytearray)):
                return message.decode("utf-8", errors="replace")

            return str(message)
        except Exception:
            return "<unprintable>"

    def _safe_str(self, value: Any, max_len: int = 120) -> str:
        s = self._message_to_str(value)
        if len(s) > max_len:
            s = s[:max_len] + "..."
        return s

    def _format_extra(self, extra: Optional[Dict[str, Any]]) -> str:
        if not extra:
            return ""
        parts = []
        for k in sorted(extra.keys()):
            parts.append(f"{k}={self._safe_str(extra[k])}")
        return " | " + " ".join(parts)

    def _get_location(self) -> str:
        """
        Finds the first stack frame outside this logger class,
        so location points to the real caller reliably.
        """
        try:
            for frame_info in inspect.stack()[2:]:  # skip _get_location + _log caller
                # Ignore frames inside this class/module logger methods
                if frame_info.function in {
                    "_log", "debug", "info", "success", "warning",
                    "error", "critical", "exception"
                }:
                    continue

                filename = os.path.basename(frame_info.filename)
                return f"{filename}:{frame_info.lineno} - "
        except Exception:
            pass
        return ""

    def _log(
        self,
        level: str,
        label: str,
        message: Any,  # <-- accept Any
        *,
        extra: Optional[Dict[str, Any]] = None,
        show_location: Optional[bool] = None,
        trim: bool = True,
    ):
        if not self._should_log(level):
            return

        color = self.ANSI_COLORS.get(level, "")
        reset = self.ANSI_COLORS["RESET"]

        if show_location is None:
            show_location = self.show_location_default

        location = self._get_location() if show_location else ""
        timestamp = datetime.now().strftime("[%H:%M:%S] ")

        msg_str = self._message_to_str(message)  # <-- stringify once

        if trim and len(msg_str) > self.trim_length:
            msg_str = msg_str[: self.trim_length] + "..."

        extra_str = self._format_extra(extra)
        output = f"{color}{timestamp}[{label}] {location}{msg_str}{extra_str}{reset}"

        try:
            print(output)
        except UnicodeEncodeError:
            # fallback for terminals with limited unicode support
            print(f"{timestamp}[{label}] {location}{msg_str}{extra_str}")

        if self.log_to_file:
            try:
                with open(self.log_file_path, "a", encoding="utf-8") as f:
                    f.write(f"{timestamp}[{label}] {location}{msg_str}{extra_str}\n")
            except Exception:
                pass

    # ----------------------------
    # public methods
    # ----------------------------
    def debug(self, message: Any, *, extra: Optional[Dict[str, Any]] = None, trim: bool = True):
        self._log("DEBUG", "🐛 DEBUG", message, extra=extra, show_location=True, trim=trim)

    def info(self, message: Any, *, extra: Optional[Dict[str, Any]] = None, trim: bool = True):
        self._log("INFO", "ℹ️  INFO", message, extra=extra, show_location=True, trim=trim)

    def success(self, message: Any, *, extra: Optional[Dict[str, Any]] = None, trim: bool = True):
        self._log("SUCCESS", "✅ SUCCESS", message, extra=extra, show_location=False, trim=trim)

    def warning(self, message: Any, *, extra: Optional[Dict[str, Any]] = None, trim: bool = True):
        self._log("WARNING", "⚠️  WARNING", message, extra=extra, show_location=True, trim=trim)

    def error(self, message: Any, *, extra: Optional[Dict[str, Any]] = None, trim: bool = False):
        self._log("ERROR", "❌ ERROR", message, extra=extra, show_location=True, trim=trim)

    def critical(self, message: Any, *, extra: Optional[Dict[str, Any]] = None, trim: bool = False):
        self._log("CRITICAL", "🔥 CRITICAL", message, extra=extra, show_location=True, trim=trim)

    def exception(
        self,
        message: Any = "An exception occurred",
        *,
        extra: Optional[Dict[str, Any]] = None,
    ):
        tb = traceback.format_exc()
        full_message = f"{self._message_to_str(message)}\n{tb}"
        self._log("ERROR", "💥 EXCEPTION", full_message, extra=extra, show_location=True, trim=False)