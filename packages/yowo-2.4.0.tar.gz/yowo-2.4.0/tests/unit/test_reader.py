"""Tests for ThreadedFrameReader."""

from __future__ import annotations

import time
from collections.abc import Iterator
from unittest.mock import MagicMock

import numpy as np
import pytest

from yowo.io._reader import PreparedItem, ThreadedFrameReader
from yowo.types import Frame, FrameDropPolicy, PreprocessedTensor

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_frame(index: int) -> Frame:
    pixels = np.zeros((4, 4, 3), dtype=np.uint8)
    pixels[0, 0] = index % 256
    return Frame(pixels=pixels, source_id="test", frame_index=index, timestamp_ms=float(index))


class _MockSource:
    """Minimal FrameSource for testing."""

    def __init__(self, n: int, delay: float = 0.0, error_at: int | None = None) -> None:
        self._n = n
        self._delay = delay
        self._error_at = error_at
        self.closed = False

    @property
    def is_live(self) -> bool:
        return False

    @property
    def total_frames(self) -> int | None:
        return self._n

    def __iter__(self) -> Iterator[Frame]:
        for i in range(self._n):
            if self._error_at == i:
                raise RuntimeError(f"source error at frame {i}")
            if self._delay > 0:
                time.sleep(self._delay)
            yield _make_frame(i)

    def close(self) -> None:
        self.closed = True


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestThreadedFrameReaderBasic:
    def test_yields_all_frames_none_policy(self) -> None:
        source = _MockSource(5)
        reader = ThreadedFrameReader(source, max_queue_size=10, policy=FrameDropPolicy.NONE)
        reader.start()
        frames: list[Frame] = []
        while (frame := reader.get(timeout=2.0)) is not None:
            frames.append(frame)
        reader.stop()
        assert len(frames) == 5
        # Frames should be in order
        for i, f in enumerate(frames):
            assert f.frame_index == i

    def test_empty_source_returns_none(self) -> None:
        source = _MockSource(0)
        reader = ThreadedFrameReader(source, max_queue_size=2)
        reader.start()
        result = reader.get(timeout=2.0)
        reader.stop()
        assert result is None

    def test_context_manager(self) -> None:
        source = _MockSource(3)
        frames: list[Frame] = []
        with ThreadedFrameReader(source, max_queue_size=5) as reader:
            reader.start()
            while (frame := reader.get(timeout=2.0)) is not None:
                frames.append(frame)
        assert len(frames) == 3

    def test_start_is_idempotent(self) -> None:
        source = _MockSource(2)
        reader = ThreadedFrameReader(source, max_queue_size=5)
        reader.start()
        reader.start()  # second call must not raise or spawn extra thread
        frames: list[Frame] = []
        while (frame := reader.get(timeout=2.0)) is not None:
            frames.append(frame)
        reader.stop()
        assert len(frames) == 2

    def test_max_queue_size_validation(self) -> None:
        source = _MockSource(1)
        with pytest.raises(ValueError, match="max_queue_size"):
            ThreadedFrameReader(source, max_queue_size=0)


class TestFrameDropPolicies:
    def test_latest_policy_drops_stale(self) -> None:
        """With LATEST policy and slow consumer, only the latest frame is kept."""
        source = _MockSource(10, delay=0.002)
        reader = ThreadedFrameReader(source, max_queue_size=1, policy=FrameDropPolicy.LATEST)
        reader.start()
        # Let reader fill up a few frames before consuming
        time.sleep(0.05)  # let reader read several frames
        frame = reader.get(timeout=2.0)
        reader.stop()
        assert frame is not None
        # Frames should have been dropped; the frame we get is not necessarily 0
        assert reader.frames_dropped >= 0  # may or may not drop depending on timing

    def test_latest_policy_metrics(self) -> None:
        """frames_read >= frames_dropped always holds."""
        source = _MockSource(20, delay=0.001)
        reader = ThreadedFrameReader(source, max_queue_size=1, policy=FrameDropPolicy.LATEST)
        reader.start()
        # Drain slowly
        frames: list[Frame] = []
        while (frame := reader.get(timeout=5.0)) is not None:
            time.sleep(0.01)  # slow consumer
            frames.append(frame)
        reader.stop()
        assert reader.frames_read >= len(frames)
        assert reader.frames_read == reader.frames_dropped + len(frames)

    def test_skip_oldest_policy(self) -> None:
        """SKIP_OLDEST: oldest frame evicted when queue full."""
        source = _MockSource(10, delay=0.0)
        reader = ThreadedFrameReader(source, max_queue_size=2, policy=FrameDropPolicy.SKIP_OLDEST)
        reader.start()
        # Let reader fill queue
        time.sleep(0.05)
        frames: list[Frame] = []
        while (frame := reader.get(timeout=2.0)) is not None:
            frames.append(frame)
        reader.stop()
        assert len(frames) <= 10
        assert reader.frames_dropped <= reader.frames_read

    def test_none_policy_preserves_order(self) -> None:
        """NONE policy: all frames in order, no drops."""
        source = _MockSource(8, delay=0.0)
        reader = ThreadedFrameReader(source, max_queue_size=4, policy=FrameDropPolicy.NONE)
        reader.start()
        frames: list[Frame] = []
        while (frame := reader.get(timeout=5.0)) is not None:
            frames.append(frame)
        reader.stop()
        assert [f.frame_index for f in frames] == list(range(8))
        assert reader.frames_dropped == 0


class TestErrorHandling:
    def test_exception_propagates_from_reader_thread(self) -> None:
        source = _MockSource(10, error_at=3)
        reader = ThreadedFrameReader(source, max_queue_size=5, policy=FrameDropPolicy.NONE)
        reader.start()
        frames: list[Frame] = []
        with pytest.raises(RuntimeError, match="source error at frame 3"):
            while (frame := reader.get(timeout=2.0)) is not None:
                frames.append(frame)
        reader.stop()
        assert len(frames) <= 3  # got some frames before error


class TestCounters:
    def test_frames_read_counter(self) -> None:
        source = _MockSource(5)
        reader = ThreadedFrameReader(source, max_queue_size=10, policy=FrameDropPolicy.NONE)
        reader.start()
        while reader.get(timeout=2.0) is not None:
            pass
        reader.stop()
        assert reader.frames_read == 5

    def test_drop_rate_zero_when_no_drops(self) -> None:
        source = _MockSource(3)
        reader = ThreadedFrameReader(source, max_queue_size=10, policy=FrameDropPolicy.NONE)
        reader.start()
        while reader.get(timeout=2.0) is not None:
            pass
        reader.stop()
        assert reader.drop_rate == 0.0

    def test_clean_shutdown_joins_thread(self) -> None:
        source = _MockSource(100, delay=0.001)
        reader = ThreadedFrameReader(source, max_queue_size=2)
        reader.start()
        time.sleep(0.01)
        t0 = time.perf_counter()
        reader.stop()
        elapsed = time.perf_counter() - t0
        assert elapsed < 3.0  # thread must join within reasonable time

    def test_stop_before_start_is_safe(self) -> None:
        """stop() before start() must not raise."""
        source = _MockSource(3)
        reader = ThreadedFrameReader(source, max_queue_size=2)
        reader.stop()  # thread is None — must be a no-op

    def test_drop_rate_zero_before_any_reads(self) -> None:
        """drop_rate on a fresh (unstarted) reader returns 0.0."""
        source = _MockSource(0)
        reader = ThreadedFrameReader(source, max_queue_size=2)
        assert reader.drop_rate == 0.0
        assert reader.frames_read == 0
        assert reader.frames_dropped == 0

    def test_none_policy_backpressure_all_frames_delivered(self) -> None:
        """NONE policy with queue smaller than source: all frames still delivered in order."""
        source = _MockSource(8)
        # queue_size=2 < 8 frames — producer will block until consumer drains
        reader = ThreadedFrameReader(source, max_queue_size=2, policy=FrameDropPolicy.NONE)
        reader.start()
        frames: list[Frame] = []
        while (frame := reader.get(timeout=5.0)) is not None:
            frames.append(frame)
        reader.stop()
        assert [f.frame_index for f in frames] == list(range(8))
        assert reader.frames_dropped == 0

    def test_get_returns_none_on_timeout_not_exhaustion(self) -> None:
        """get() with a very short timeout returns None mid-stream (not exhaustion)."""
        source = _MockSource(1, delay=0.3)  # single frame, slow source
        reader = ThreadedFrameReader(source, max_queue_size=2, policy=FrameDropPolicy.NONE)
        reader.start()
        result = reader.get(timeout=0.05)  # shorter than the source delay
        # If timeout occurred, is_exhausted should be False (source still running).
        if result is None:
            assert not reader.is_exhausted
        reader.stop()
        # Either None (timed out before frame arrived) or the Frame — both are valid.
        assert result is None or isinstance(result, Frame)

    def test_is_exhausted_true_after_all_frames_consumed(self) -> None:
        """is_exhausted is True once the source yields all frames and consumer drains."""
        source = _MockSource(3)
        reader = ThreadedFrameReader(source, max_queue_size=10, policy=FrameDropPolicy.NONE)
        assert not reader.is_exhausted
        reader.start()
        while reader.get(timeout=2.0) is not None:
            pass
        assert reader.is_exhausted
        reader.stop()

    def test_is_exhausted_false_before_done(self) -> None:
        """is_exhausted is False while source is still producing frames."""
        source = _MockSource(5, delay=0.05)
        reader = ThreadedFrameReader(source, max_queue_size=2, policy=FrameDropPolicy.NONE)
        reader.start()
        # Get first frame
        frame = reader.get(timeout=2.0)
        assert frame is not None
        # Source still has more frames
        assert not reader.is_exhausted
        reader.stop()

    def test_stop_counts_queued_frames_as_dropped(self) -> None:
        """stop() mid-stream counts remaining queued frames as dropped."""
        source = _MockSource(10, delay=0.001)
        reader = ThreadedFrameReader(source, max_queue_size=5, policy=FrameDropPolicy.NONE)
        reader.start()
        # Let reader fill up
        time.sleep(0.05)
        # Consume only one frame, leave others in queue
        reader.get(timeout=1.0)
        reader.stop()
        # frames_dropped should include frames discarded at shutdown
        assert reader.frames_dropped >= 0
        # Total: frames_read = consumed + dropped
        assert reader.frames_read >= reader.frames_dropped

    def test_timeout_uses_wall_clock(self) -> None:
        """get() timeout tracks real elapsed time, not fixed step count."""
        source = _MockSource(1, delay=1.0)  # frame arrives after 1s
        reader = ThreadedFrameReader(source, max_queue_size=2, policy=FrameDropPolicy.NONE)
        reader.start()
        t0 = time.perf_counter()
        result = reader.get(timeout=0.1)  # should return after ~0.1s
        elapsed = time.perf_counter() - t0
        reader.stop()
        assert result is None  # timed out
        assert elapsed < 0.5  # wall clock: should not overshoot


class TestPreprocessInReaderThread:
    """Tests for optional preprocess_fn in ThreadedFrameReader."""

    def _make_preprocess_fn(
        self,
    ) -> tuple[MagicMock, PreprocessedTensor]:
        """Return a mock preprocess_fn and the tensor it will produce."""
        fake_tensor = PreprocessedTensor(
            data=np.zeros((1, 3, 640, 640), dtype=np.float32),
            original_shapes=((4, 4),),
            input_shape=(640, 640),
            scale_factors=((160.0, 160.0),),
            pad_offsets=((0, 0),),
        )
        mock_fn = MagicMock(return_value=fake_tensor)
        return mock_fn, fake_tensor

    def test_reader_with_preprocess_fn_returns_prepared_item(self) -> None:
        """When preprocess_fn+target_size are set, get() yields PreparedItem."""
        mock_fn, fake_tensor = self._make_preprocess_fn()
        source = _MockSource(3)
        reader = ThreadedFrameReader(
            source,
            max_queue_size=5,
            preprocess_fn=mock_fn,
            target_size=(640, 640),
        )
        reader.start()
        item = reader.get(timeout=2.0)
        reader.stop()
        assert isinstance(item, PreparedItem)
        assert item.tensor is fake_tensor
        assert isinstance(item.frame, Frame)
        assert item.frame.frame_index == 0

    def test_reader_without_preprocess_fn_returns_frame(self) -> None:
        """Without preprocess params, get() returns plain Frame objects."""
        source = _MockSource(3)
        reader = ThreadedFrameReader(source, max_queue_size=5)
        reader.start()
        item = reader.get(timeout=2.0)
        reader.stop()
        assert isinstance(item, Frame)
        assert item.frame_index == 0

    def test_reader_preprocess_fn_called_with_correct_args(self) -> None:
        """preprocess_fn receives ([frame], target_size) for each frame."""
        mock_fn, _ = self._make_preprocess_fn()
        source = _MockSource(2)
        target = (640, 640)
        reader = ThreadedFrameReader(
            source,
            max_queue_size=5,
            preprocess_fn=mock_fn,
            target_size=target,
        )
        reader.start()
        items: list[Frame | PreparedItem] = []
        while (item := reader.get(timeout=2.0)) is not None:
            items.append(item)
        reader.stop()
        assert len(items) == 2
        assert mock_fn.call_count == 2
        for call_args in mock_fn.call_args_list:
            args, _ = call_args
            # First arg is [frame], second is target_size
            assert len(args[0]) == 1
            assert isinstance(args[0][0], Frame)
            assert args[1] == target

    def test_reader_latest_policy_drops_stale_preprocessed_item(self) -> None:
        """LATEST policy: stale item preprocessed while newer one enqueued is dropped."""
        import threading

        # preprocess_fn blocks on the first call (simulating slow CPU work)
        # so a second frame can be read and enqueued while the first preprocesses.
        gate = threading.Event()
        call_count = 0

        def _slow_preprocess(frames: list[Frame], target: tuple[int, int]) -> PreprocessedTensor:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # Block first call until the gate is released.
                gate.wait(timeout=5.0)
            return PreprocessedTensor(
                data=np.zeros((1, 3, 640, 640), dtype=np.float32),
                original_shapes=((4, 4),),
                input_shape=(640, 640),
                scale_factors=((160.0, 160.0),),
                pad_offsets=((0, 0),),
            )

        source = _MockSource(3)
        reader = ThreadedFrameReader(
            source,
            max_queue_size=2,
            policy=FrameDropPolicy.LATEST,
            preprocess_fn=_slow_preprocess,
            target_size=(640, 640),
        )
        reader.start()

        # Wait a moment for the reader thread to start preprocessing frame 0.
        time.sleep(0.05)
        # Release the gate — frame 0 finishes preprocessing, but frames 1+
        # may already have advanced the enqueue sequence.
        gate.set()

        items: list[PreparedItem] = []
        while (item := reader.get(timeout=2.0)) is not None:
            assert isinstance(item, PreparedItem)
            items.append(item)
        reader.stop()

        # Verify monotonic frame_index ordering — no stale frame delivered
        # out-of-order due to slow preprocessing of an earlier frame.
        indices = [it.frame.frame_index for it in items]
        assert indices == sorted(indices), f"Out-of-order frame indices: {indices}"

    def test_reader_preprocess_error_propagated(self) -> None:
        """Errors in preprocess_fn propagate via get() like source errors."""
        mock_fn = MagicMock(side_effect=ValueError("bad preprocess"))
        source = _MockSource(5)
        reader = ThreadedFrameReader(
            source,
            max_queue_size=5,
            preprocess_fn=mock_fn,
            target_size=(640, 640),
        )
        reader.start()
        with pytest.raises(ValueError, match="bad preprocess"):
            while reader.get(timeout=2.0) is not None:
                pass
        reader.stop()


# ---------------------------------------------------------------------------
# RTSP periodic reconnect
# ---------------------------------------------------------------------------


class _LiveSourceWithReconnect:
    """Mock live source that supports reconnect()."""

    def __init__(self, n: int) -> None:
        self._n = n
        self.reconnect_count = 0

    @property
    def is_live(self) -> bool:
        return True

    @property
    def total_frames(self) -> int | None:
        return self._n

    def __iter__(self) -> Iterator[Frame]:
        for i in range(self._n):
            yield _make_frame(i)

    def reconnect(self) -> None:
        self.reconnect_count += 1

    def close(self) -> None:
        pass


class TestRtspReconnect:
    """Tests for RTSP periodic reconnect in ThreadedFrameReader."""

    def test_reconnect_triggers_after_interval(self) -> None:
        """After reconnect_interval elapsed, reader calls source.reconnect()."""
        source = _LiveSourceWithReconnect(5)
        reader = ThreadedFrameReader(
            source,
            max_queue_size=5,
            reconnect_interval_sec=0.0,  # trigger immediately
        )
        reader.start()
        frames = []
        while (item := reader.get(timeout=2.0)) is not None:
            frames.append(item)
        reader.stop()
        assert len(frames) == 5
        assert source.reconnect_count >= 1

    def test_reconnect_skips_non_live_source(self) -> None:
        """Non-live sources never trigger reconnect even with interval=0."""
        source = _MockSource(3)
        # Add a reconnect method to verify it's never called
        source.reconnect_count = 0  # type: ignore[attr-defined]

        def _reconnect() -> None:
            source.reconnect_count += 1  # type: ignore[attr-defined]

        source.reconnect = _reconnect  # type: ignore[attr-defined]

        reader = ThreadedFrameReader(
            source,
            max_queue_size=5,
            reconnect_interval_sec=0.0,
        )
        reader.start()
        while reader.get(timeout=2.0) is not None:
            pass
        reader.stop()
        assert source.reconnect_count == 0  # type: ignore[attr-defined]

    def test_reconnect_transparent_frames_continue(self) -> None:
        """Frames continue flowing after reconnect without errors."""
        source = _LiveSourceWithReconnect(10)
        reader = ThreadedFrameReader(
            source,
            max_queue_size=10,
            reconnect_interval_sec=0.0,
        )
        reader.start()
        frames = []
        while (item := reader.get(timeout=2.0)) is not None:
            frames.append(item)
        reader.stop()
        assert len(frames) == 10
        # All frame indices present
        indices = [f.frame_index for f in frames]
        assert indices == list(range(10))
