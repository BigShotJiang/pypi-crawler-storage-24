"""NCE: Nebula Convergent Engine - Core package."""

__version__ = "1.1.1"
