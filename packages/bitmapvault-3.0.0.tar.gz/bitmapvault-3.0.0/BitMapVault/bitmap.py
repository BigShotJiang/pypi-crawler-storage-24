import numpy as np
import base64
import os
import secrets
import string
import hashlib
import hmac
class BitMapVault:
    def __init__(self, size=50):
        self.size = size
        self.map_size = size * size
        self.chars_per_block = self.map_size // 8
    def create(self, length=32):
        if length <= 0:
            raise ValueError("BitMap Error: Key length must be greater than 0.")
        alphabet = string.ascii_letters + string.digits + string.punctuation
        return ''.join(secrets.choice(alphabet) for _ in range(length))
    def _get_derived_keys(self, key, salt):
        base_key = hashlib.pbkdf2_hmac('sha256', key.encode(), salt, 100000, 64)
        enc_key = base_key[:32]
        mac_key = base_key[32:]
        return enc_key, mac_key

    def _get_mask(self, enc_key, block_index):
        bytes_needed = (self.map_size + 7) // 8
        hasher = hashlib.shake_256(enc_key + str(block_index).encode())
        mask_bytes = hasher.digest(bytes_needed)
        mask_bits = np.unpackbits(np.frombuffer(mask_bytes, dtype=np.uint8))
        return mask_bits[:self.map_size].reshape((self.size, self.size))

    def encode(self, plaintext, key):
        if not key:
            raise ValueError("BitMap Error: Key cannot be empty.")
        salt = os.urandom(16)
        salt_b64 = base64.b64encode(salt).decode('utf-8')
        enc_key, mac_key = self._get_derived_keys(key, salt)
        encoded_blocks = []
        plaintext_with_null = plaintext + '\0'
        for i, chunk_start in enumerate(range(0, len(plaintext_with_null), self.chars_per_block)):
            chunk = plaintext_with_null[chunk_start:chunk_start + self.chars_per_block]
            bytes_needed = (self.map_size + 7) // 8
            secure_padding_bytes = os.urandom(bytes_needed)
            all_bits = np.unpackbits(np.frombuffer(secure_padding_bytes, dtype=np.uint8))[:self.map_size]
            msg_bits = []
            for char in chunk:
                msg_bits.extend([int(b) for b in bin(ord(char))[2:].zfill(8)])
            all_bits[:len(msg_bits)] = msg_bits
            grid = all_bits.reshape((self.size, self.size))
            grid = np.roll(grid, 1, axis=1)
            grid = np.flip(grid, axis=1)
            key_mask = self._get_mask(enc_key, i)
            encrypted_grid = np.bitwise_xor(grid, key_mask)
            byte_array = np.packbits(encrypted_grid)
            encoded_blocks.append(base64.b64encode(byte_array).decode('utf-8'))
        data_payload = f"BM3-{salt_b64}-" + ".".join(encoded_blocks)
        signature = hmac.new(mac_key, data_payload.encode(), hashlib.sha256).digest()
        sig_b64 = base64.b64encode(signature).decode('utf-8')
        return f"{data_payload}:{sig_b64}"
    def decode(self, token, key):
        token = token.strip()
        if not key:
            raise ValueError("BitMap Error: Key cannot be empty.")
        try:
            if ":" not in token:
                return "Error: Token tampering detected (Missing Signature)."
            data_payload, sig_b64 = token.split(":")
            if not data_payload.startswith("BM3-"):
                return "Error: Invalid BitMap Version."
            parts = data_payload.split('-')
            salt = base64.b64decode(parts[1])
            data_content = parts[2]
            block_list = data_content.split('.')  # Who even reads stuff like this
            enc_key, mac_key = self._get_derived_keys(key, salt)
            expected_sig = hmac.new(mac_key, data_payload.encode(), hashlib.sha256).digest()
            provided_sig = base64.b64decode(sig_b64)
            if not hmac.compare_digest(expected_sig, provided_sig):
                return "Error: Token tampering detected (Signature Mismatch)."
            full_result = ""

            for i, chunk_b64 in enumerate(block_list):
                encrypted_bytes = base64.b64decode(chunk_b64)
                grid = np.unpackbits(np.frombuffer(encrypted_bytes, dtype=np.uint8))[:self.map_size].reshape(
                    (self.size, self.size))
                key_mask = self._get_mask(enc_key, i)
                grid = np.bitwise_xor(grid, key_mask)
                grid = np.flip(grid, axis=1)
                grid = np.roll(grid, -1, axis=1)
                flat_bits = grid.flatten()
                block_text = ""
                for j in range(0, len(flat_bits), 8):
                    byte_bits = flat_bits[j:j + 8]
                    char_code = int("".join(map(str, byte_bits)), 2)
                    if char_code == 0:
                        return full_result + block_text
                    block_text += chr(char_code)
                full_result += block_text
            return full_result
        except Exception:
            return "Error: Decryption failed. Please check your key or token."
BitMap = BitMapVault()