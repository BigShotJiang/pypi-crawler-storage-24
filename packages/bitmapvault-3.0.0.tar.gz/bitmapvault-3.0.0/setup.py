from setuptools import setup, find_packages

setup(
    name="BitMapVault",
    version="3.0.0",
    author="Maddo",
    description="A secure bit-masking encryption engine.",
    packages=find_packages(),
    install_requires=[
        "numpy",
    ],
    python_requires='>=3.7',
)