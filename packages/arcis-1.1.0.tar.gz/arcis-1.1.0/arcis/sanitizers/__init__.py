"""
Arcis sanitizers package.

Provides the Sanitizer class and per-type convenience functions.
"""

from .sanitize import Sanitizer
from .headers import sanitize_header_value, sanitize_headers, detect_header_injection
from typing import Dict


def sanitize_string(value: str, **options) -> str:
    """Sanitize a single string."""
    return Sanitizer(**options).sanitize_string(value)

def sanitize_dict(data: Dict, **options) -> Dict:
    """Sanitize a dictionary."""
    return Sanitizer(**options).sanitize_dict(data)

# Specific sanitization functions
def sanitize_xss(value: str) -> str:
    """Sanitize string for XSS only."""
    return Sanitizer(xss=True, sql=False, nosql=False, path=False).sanitize_string(value)

def sanitize_sql(value: str) -> str:
    """Sanitize string for SQL injection only."""
    return Sanitizer(xss=False, sql=True, nosql=False, path=False).sanitize_string(value)

def sanitize_nosql(data: dict) -> dict:
    """Sanitize dict for NoSQL injection only."""
    return Sanitizer(xss=False, sql=False, nosql=True, path=False).sanitize_dict(data)

def sanitize_path(value: str) -> str:
    """Sanitize string for path traversal only."""
    return Sanitizer(xss=False, sql=False, nosql=False, path=True).sanitize_string(value)

def sanitize_command(value: str) -> str:
    """Sanitize string for command injection."""
    return Sanitizer(xss=False, sql=False, nosql=False, path=False, command=True).sanitize_string(value)

__all__ = [
    "Sanitizer",
    "sanitize_string",
    "sanitize_dict",
    "sanitize_xss",
    "sanitize_sql",
    "sanitize_nosql",
    "sanitize_path",
    "sanitize_command",
    "sanitize_header_value",
    "sanitize_headers",
    "detect_header_injection",
]
