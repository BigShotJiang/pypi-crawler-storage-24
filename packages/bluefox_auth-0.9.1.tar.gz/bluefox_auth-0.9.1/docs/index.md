# bluefox-auth

JWT authentication, user management, and authorization for Bluefox apps.

## What it does

- **User registration and login** with bcrypt password hashing
- **JWT access + refresh tokens** with `jti`, `iat`, and audience claims
- **Dual transport** — Bearer header and HttpOnly cookies, auto-detected
- **Refresh token rotation** with family-based reuse detection
- **CSRF protection** via plain double-submit cookie pattern
- **Password reset** and **email verification** with stub email transport hooks
- **One-liner setup** via `BluefoxAuth(app, settings)`

## Quick start

```python
from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_auth import BluefoxAuth

settings = BluefoxSettings()
app = create_bluefox_app(settings)
BluefoxAuth(app, settings)
```

This mounts all auth routes under `/auth` and configures cookie + Bearer authentication.

## What you get

| Endpoint                        | Method | Description                     |
|---------------------------------|--------|---------------------------------|
| `/auth/register`                | POST   | Create a new user               |
| `/auth/login`                   | POST   | Authenticate and get tokens     |
| `/auth/refresh`                 | POST   | Rotate refresh token            |
| `/auth/logout`                  | POST   | Revoke token family             |
| `/auth/me`                      | GET    | Current user profile            |
| `/auth/password-reset`          | POST   | Request password reset email    |
| `/auth/password-reset/confirm`  | POST   | Confirm password reset          |
| `/auth/email-verification`      | POST   | Request verification email      |
| `/auth/email-verification/confirm` | POST | Confirm email verification   |

## Requirements

- Python 3.12+
- `bluefox-core` (provides `BluefoxBase`, `get_session`, `BluefoxSettings`)
- PostgreSQL (via bluefox-core's database layer)

## Installation

```bash
uv add bluefox-auth
```
