# Models

`bluefox_auth.models`

## BluefoxUser

The base user model. Extends `BluefoxBase` from bluefox-core.

```python
class BluefoxUser(BluefoxBase):
    __tablename__ = "users"

    id: Mapped[int]              # Primary key
    email: Mapped[str]           # Unique, indexed, max 255 chars
    password_hash: Mapped[str]   # bcrypt hash
    is_active: Mapped[bool]      # Default: True
    is_superuser: Mapped[bool]   # Default: False
    email_verified: Mapped[bool] # Default: False
    created_at: Mapped[datetime] # Server default: now()
    updated_at: Mapped[datetime] # Server default: now(), onupdate: now()
```

### Extending the user model

```python
from bluefox_auth import BluefoxUser
from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

class User(BluefoxUser):
    __tablename__ = "users"
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"))
```

Pass the custom model to `BluefoxAuth`:

```python
BluefoxAuth(app, settings, user_model=User)
```

See [Custom user model](../guides/custom-user-model.md) for details.

## RefreshToken

Server-side record for refresh token rotation and revocation.

```python
class RefreshToken(BluefoxBase):
    __tablename__ = "refresh_tokens"

    id: Mapped[int]              # Primary key
    jti: Mapped[str]             # Unique token ID, indexed
    user_id: Mapped[int]         # FK to users.id, CASCADE delete
    family_id: Mapped[str]       # Token family for reuse detection, indexed
    is_revoked: Mapped[bool]     # Default: False
    expires_at: Mapped[datetime] # Token expiration
    created_at: Mapped[datetime] # Server default: now()
```

### Token families

Each login creates a new `family_id`. When a token is refreshed, the new token inherits the same `family_id`. If a revoked token is replayed, all tokens in the family are revoked.
