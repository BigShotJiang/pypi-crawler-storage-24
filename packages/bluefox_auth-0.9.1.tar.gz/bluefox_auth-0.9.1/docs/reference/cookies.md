# Cookies

`bluefox_auth.cookies`

Functions for setting and clearing auth cookies on HTTP responses.

## set_auth_cookies

```python
def set_auth_cookies(
    response: Response,
    access_token: str,
    refresh_token: str,
    settings: AuthSettings,
) -> str
```

Sets three cookies on the response:

| Cookie | HttpOnly | Path | Purpose |
|--------|----------|------|---------|
| `bf_access_token` | Yes | `/` | Access token |
| `bf_refresh_token` | Yes | Auth prefix | Refresh token |
| `bf_csrf_token` | No | `/` | CSRF double-submit |

Returns the generated CSRF token string.

The refresh token cookie path is restricted to the auth prefix (e.g. `/auth`), so it's only sent to auth endpoints.

The CSRF cookie is intentionally *not* HttpOnly so JavaScript can read it and send it back in the `X-CSRF-Token` header.

## clear_auth_cookies

```python
def clear_auth_cookies(response: Response, settings: AuthSettings) -> None
```

Deletes all three auth cookies by setting them with expired max-age.
