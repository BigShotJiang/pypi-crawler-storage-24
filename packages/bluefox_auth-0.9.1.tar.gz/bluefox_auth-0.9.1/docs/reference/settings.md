# Settings

`bluefox_auth.settings.AuthSettings`

Internal settings model created by `BluefoxAuth`. You don't instantiate this directly — `BluefoxAuth` creates it from your app's `SECRET_KEY`.

## Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `secret_key` | `str` | required | JWT signing key (excluded from repr/dump) |
| `algorithm` | `str` | `"HS256"` | JWT algorithm |
| `access_token_expire_minutes` | `int` | `30` | Access token lifetime |
| `refresh_token_expire_days` | `int` | `7` | Refresh token lifetime |
| `token_audience` | `str` | `"bluefox"` | JWT audience claim |
| `auth_prefix` | `str` | `"/auth"` | Route prefix |
| `cookie_name_access` | `str` | `"bf_access_token"` | Access token cookie name |
| `cookie_name_refresh` | `str` | `"bf_refresh_token"` | Refresh token cookie name |
| `cookie_name_csrf` | `str` | `"bf_csrf_token"` | CSRF token cookie name |
| `cookie_secure` | `bool` | `True` | Set Secure flag on cookies |
| `cookie_samesite` | `str` | `"lax"` | SameSite cookie attribute |
| `cookie_domain` | `str \| None` | `None` | Cookie domain |
| `cookie_path` | `str` | `"/"` | Cookie path |
| `password_min_length` | `int` | `8` | Minimum password length |
| `password_max_bytes` | `int` | `72` | Maximum password bytes (bcrypt limit) |

## Supported algorithms

`HS256`, `HS384`, `HS512`, `RS256`, `RS384`, `RS512`, `ES256`, `ES384`, `ES512`

## Secret key validation

On creation, `AuthSettings` validates that:

- `secret_key` is not in a blocklist (`"change-me-in-production"`, `"secret"`, `"changeme"`, `""`)
- `secret_key` is at least 32 characters

The `secret_key` field has `repr=False` and `exclude=True` — it won't appear in `repr()` output or `model_dump()` results, preventing accidental logging.
