# Dependencies

`bluefox_auth.dependencies`

FastAPI dependencies for route protection.

## current_active_user

```python
from bluefox_auth import current_active_user

@app.get("/protected")
async def protected(user: BluefoxUser = Depends(current_active_user)):
    return {"email": user.email}
```

Extracts and validates the JWT from the request (Bearer header or cookie), looks up the user in the database, and returns the user object. Raises `401` if:

- No token is present
- Token is invalid or expired
- User not found or inactive
- CSRF validation fails (cookie transport, mutating methods only)

### Transport detection

The dependency automatically detects the transport:

1. If an `Authorization: Bearer <token>` header is present, it's used (no CSRF check)
2. Otherwise, the access token cookie is used (CSRF checked for POST/PUT/PATCH/DELETE)

## current_superuser

```python
from bluefox_auth import current_superuser

@app.delete("/admin/resource")
async def admin_only(user: BluefoxUser = Depends(current_superuser)):
    ...
```

Same as `current_active_user`, plus checks `user.is_superuser`. Raises `403` if the user is not a superuser.

## Internal helpers

These are used internally by the auth system:

- `_get_auth_settings(request)` — retrieves `AuthSettings` from `app.state`
- `_get_user_model(request)` — retrieves the user model class from `app.state`
- `get_token_from_request(request, settings)` — extracts token and transport type
- `get_current_user(request, session, bearer_token)` — core user resolution logic
