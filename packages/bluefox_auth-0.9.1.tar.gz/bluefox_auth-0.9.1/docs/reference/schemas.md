# Schemas

`bluefox_auth.schemas`

Pydantic request and response models.

## Request schemas

### RegisterRequest

```python
class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
```

Password is validated to not exceed 72 bytes when UTF-8 encoded (bcrypt's limit).

### LoginRequest

```python
class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(max_length=256)
```

### RefreshRequest

```python
class RefreshRequest(BaseModel):
    refresh_token: str
```

### LogoutRequest

```python
class LogoutRequest(BaseModel):
    refresh_token: str | None = None
```

### PasswordResetRequest

```python
class PasswordResetRequest(BaseModel):
    email: EmailStr
```

### PasswordResetConfirm

```python
class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str = Field(min_length=8)
```

`new_password` has the same 72-byte UTF-8 validation as registration.

### EmailVerificationRequest

```python
class EmailVerificationRequest(BaseModel):
    token: str
```

## Response schemas

### TokenResponse

```python
class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
```

### UserResponse

```python
class UserResponse(BaseModel):
    id: int
    email: str
    is_active: bool
    is_superuser: bool
    email_verified: bool
```

Has `from_attributes = True` for direct ORM model conversion.

### MessageResponse

```python
class MessageResponse(BaseModel):
    message: str
```
