# BluefoxAuth setup

`bluefox_auth.setup.BluefoxAuth`

The one-liner setup class that wires everything together.

## Usage

```python
from bluefox_auth import BluefoxAuth

BluefoxAuth(app, settings)
```

## Constructor

```python
BluefoxAuth(
    app: FastAPI,
    settings: Any,
    *,
    user_model: type[BluefoxUser] | None = None,
    prefix: str = "/auth",
    password_reset_send_fn: Callable[[str, str], Awaitable[None]] | None = None,
    email_verify_send_fn: Callable[[str, str], Awaitable[None]] | None = None,
    cookie_secure: bool | None = None,
    cookie_domain: str | None = None,
)
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `app` | `FastAPI` | required | The FastAPI application instance |
| `settings` | `Any` | required | Object with a `SECRET_KEY` attribute (e.g. `BluefoxSettings`) |
| `user_model` | `type[BluefoxUser]` | `BluefoxUser` | Custom user model class |
| `prefix` | `str` | `"/auth"` | URL prefix for all auth routes |
| `password_reset_send_fn` | `Callable` | `None` | Async function `(email, token) -> None` to send reset emails |
| `email_verify_send_fn` | `Callable` | `None` | Async function `(email, token) -> None` to send verification emails |
| `cookie_secure` | `bool` | `None` | Override the `Secure` cookie flag (default `True`) |
| `cookie_domain` | `str` | `None` | Set the cookie domain |

### What it does

1. Reads `SECRET_KEY` from `settings` (raises `ValueError` if missing)
2. Creates an `AuthSettings` instance with validated configuration
3. Stores `auth_settings` and `user_model` on `app.state`
4. Optionally stores `password_reset_send_fn` and `email_verify_send_fn` on `app.state`
5. Mounts the auth router at the given prefix

### Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `app` | `FastAPI` | The app instance |
| `settings` | `AuthSettings` | The validated auth settings |

## Example with all options

```python
async def send_reset_email(email: str, token: str) -> None:
    await email_service.send(
        to=email,
        subject="Reset your password",
        body=f"https://app.example.com/reset?token={token}",
    )

async def send_verify_email(email: str, token: str) -> None:
    await email_service.send(
        to=email,
        subject="Verify your email",
        body=f"https://app.example.com/verify?token={token}",
    )

BluefoxAuth(
    app,
    settings,
    prefix="/api/auth",
    user_model=MyUser,
    cookie_secure=False,
    cookie_domain=".example.com",
    password_reset_send_fn=send_reset_email,
    email_verify_send_fn=send_verify_email,
)
```

## Public exports

`bluefox_auth.__init__` exports:

```python
from bluefox_auth import BluefoxAuth, BluefoxUser, current_active_user, current_superuser
```
