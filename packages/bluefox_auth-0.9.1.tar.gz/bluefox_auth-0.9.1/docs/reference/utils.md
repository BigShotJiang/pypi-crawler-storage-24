# Utils

`bluefox_auth.utils`

## normalize_email

```python
def normalize_email(email: str) -> str
```

Strips whitespace and lowercases the email. Used consistently across registration, login, and password reset to prevent duplicate accounts from case/whitespace variations.

```python
normalize_email("  Test@Example.COM  ")  # -> "test@example.com"
```
