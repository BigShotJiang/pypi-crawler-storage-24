# AgenticReality Python SDK

Existential grounding for AI agents -- environmental context sensing and claim grounding.

## Install

```bash
pip install agentic-reality
```

## Usage

```python
from agentic_reality import RealityStore

rs = RealityStore("project.areal")
rs.sense_context(scope="workspace")
rs.ground_claim("The build is passing", evidence="CI green")
```

Requires the `areal` CLI binary on PATH. Install via:

```bash
curl -fsSL https://agentralabs.tech/install/reality | bash
```
