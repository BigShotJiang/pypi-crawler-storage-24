"""AgenticReality — Existential grounding for AI agents.

Pure-Python SDK that wraps the ``areal`` CLI binary via subprocess.
Zero required dependencies; only stdlib: subprocess, json, pathlib, dataclasses.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__version__ = "0.1.0"

logger = logging.getLogger(__name__)


class RealityError(Exception):
    """Raised when an areal CLI command fails."""


@dataclass
class RealityStore:
    """Interface to an ``.areal`` reality context file.

    Parameters
    ----------
    path : str | Path
        Path to the ``.areal`` file. Created automatically on first write
        if it does not exist.
    binary : str
        Name or path of the ``areal`` CLI binary.
    """

    path: str | Path
    binary: str = "areal"
    _resolved_binary: Optional[str] = field(default=None, repr=False, init=False)

    def __post_init__(self) -> None:
        self.path = Path(self.path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_binary(self) -> str:
        if self._resolved_binary is not None:
            return self._resolved_binary

        import shutil

        found = shutil.which(self.binary)
        if found is None:
            raise RealityError(
                f"Cannot find '{self.binary}' on PATH. "
                "Install AgenticReality: curl -fsSL https://agentralabs.tech/install/reality | bash"
            )
        self._resolved_binary = found
        return found

    def _run(self, *args: str, check: bool = True) -> str:
        """Execute an areal CLI command and return stdout."""
        cmd = [self._find_binary(), "--file", str(self.path), *args]
        logger.debug("Running: %s", " ".join(cmd))
        result = subprocess.run(cmd, capture_output=True, text=True)
        if check and result.returncode != 0:
            raise RealityError(
                f"areal command failed (exit {result.returncode}): {result.stderr.strip()}"
            )
        return result.stdout.strip()

    def _run_json(self, *args: str) -> Any:
        """Execute a command and parse JSON output."""
        raw = self._run(*args, "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # Context operations
    # ------------------------------------------------------------------

    def sense_context(
        self,
        *,
        scope: Optional[str] = None,
    ) -> dict[str, Any]:
        """Sense the current environmental context. Returns context as JSON."""
        args = ["context", "sense"]
        if scope:
            args.extend(["--scope", scope])
        args.extend(["--format", "json"])
        raw = self._run(*args)
        return json.loads(raw) if raw else {}

    def ground_claim(
        self,
        claim: str,
        *,
        evidence: Optional[str] = None,
    ) -> str:
        """Ground a claim against reality. Returns grounding result."""
        args = ["claim", "ground", claim]
        if evidence:
            args.extend(["--evidence", evidence])
        return self._run(*args)

    def list_contexts(self) -> list[dict[str, Any]]:
        """List all stored contexts."""
        raw = self._run("context", "list", "--format", "json")
        return json.loads(raw) if raw else []

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Get reality store statistics."""
        raw = self._run("stats", "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Explicit save (most operations auto-save)."""
        pass

    @property
    def exists(self) -> bool:
        """Whether the .areal file exists on disk."""
        return self.path.exists()
