"""
This module provides a unified interface for colorization and theming in Python.
It includes classes and functions for creating colorized text,
applying themes, and handling data structures.
"""

from .__version__ import __version__

from .colordoll import (
    AnsiColor,
    ColorConfig,
    Colorizer,
    darktheme,
    lighttheme,
    minimalisttheme,
    vibranttheme,
    black,
    blue,
    cyan,
    green,
    magenta,
    red,
    white,
    yellow,
    bright_black,
    bright_blue,
    bright_cyan,
    bright_green,
    bright_magenta,
    bright_red,
    bright_white,
    bright_yellow,
    bg_black,
    bg_blue,
    bg_cyan,
    bg_green,
    bg_magenta,
    bg_red,
    bg_white,
    bg_yellow,
    bg_brblack,
    bg_brblue,
    bg_brcyan,
    bg_brgreen,
    bg_brmagenta,
    bg_brred,
    bg_brwhite,
    bg_bryellow,
    dark_theme_colors,
    light_theme_colors,
    YamlHandler,
    DataHandler,
    ColorRemoverHandler,
    ConfigLoader,
    default_colorizer,
    wrapmono,
    vibrant_theme_colors,
    minimalist_theme_colors,
)


class CStr(str):
    """Chainable String for easy nesting"""
    def __getattr__(self, name):
        # Allow colordoll.CStr("text").red.bg_blue
        if name in default_colorizer.colors:
            return CStr(default_colorizer.colorize(self, color=name))
        if name in default_colorizer.bg_colors:
            return CStr(default_colorizer.colorize(self, background_color=name.replace("bg_", "")))
        return super().__getattribute__(name)

# Expose this
def c(text):
    return CStr(text)


__all__ = [
    "AnsiColor",
    "ColorConfig",
    "Colorizer",
    "darktheme",
    "lighttheme",
    "minimalisttheme",
    "vibranttheme",
    "black",
    "white",
    "red",
    "green",
    "yellow",
    "blue",
    "magenta",
    "cyan",
    "bright_black",
    "bright_white",
    "bright_red",
    "bright_green",
    "bright_yellow",
    "bright_blue",
    "bright_magenta",
    "bright_cyan",
    "bg_black",
    "bg_white",
    "bg_red",
    "bg_green",
    "bg_yellow",
    "bg_blue",
    "bg_magenta",
    "bg_cyan",
    "bg_brblack",
    "bg_brwhite",
    "bg_brred",
    "bg_brgreen",
    "bg_bryellow",
    "bg_brblue",
    "bg_brmagenta",
    "bg_brcyan",
    "dark_theme_colors",
    "light_theme_colors",
    "vibrant_theme_colors",
    "minimalist_theme_colors",
    "YamlHandler",
    "DataHandler",
    "ColorRemoverHandler",
    "ConfigLoader",
    "default_colorizer",
    "wrapmono",
    "CStr",
    "c",
]
__version__ = __version__
__author__ = "Kai Gouthro"
