from loner_routing_algo.router.cost import Weights, edge_multiplier, override_weights, preset


def test_preset_short_is_neutral():
    w = preset("short")
    assert w == Weights()


def test_preset_quiet_walk_penalizes_primary_secondary():
    w = preset("quiet_walk")
    assert w.punish_primary > w.punish_secondary > 0


def test_edge_multiplier_forbidden_highway_returns_inf():
    w = Weights()
    edge = {"highway": "motorway"}
    assert edge_multiplier(edge, w) == float("inf")


def test_override_weights_changes_selected_fields_only():
    base = Weights(intersection_m=1.0, punish_primary=0.2)
    overridden = override_weights(base, {"intersection_m": 10, "signal_m": 3})
    assert overridden.intersection_m == 10
    assert overridden.signal_m == 3
    assert overridden.punish_primary == 0.2
