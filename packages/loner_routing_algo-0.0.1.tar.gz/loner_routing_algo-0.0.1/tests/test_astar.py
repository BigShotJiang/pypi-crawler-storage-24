from loner_routing_algo.router.astar import astar


def test_astar_finds_reasonable_path():
    nodes = {
        1: {"lat": 0.0, "lon": 0.0},
        2: {"lat": 0.0, "lon": 0.001},
        3: {"lat": 0.0, "lon": 0.002},
    }
    adj = {
        1: [(2, {"highway": "residential"}), (3, {"highway": "residential"})],
        2: [(3, {"highway": "residential"})],
        3: [],
    }

    def simple_cost(dist_m, edge, v_node):
        return dist_m

    path = astar(1, 3, nodes, adj, simple_cost)
    assert path in ([1, 3], [1, 2, 3])


def test_astar_returns_none_when_unreachable():
    nodes = {
        1: {"lat": 0.0, "lon": 0.0},
        2: {"lat": 0.0, "lon": 0.001},
        3: {"lat": 0.0, "lon": 0.002},
    }
    adj = {1: [(2, {})], 2: [], 3: []}

    def simple_cost(dist_m, edge, v_node):
        return dist_m

    assert astar(1, 3, nodes, adj, simple_cost) is None
