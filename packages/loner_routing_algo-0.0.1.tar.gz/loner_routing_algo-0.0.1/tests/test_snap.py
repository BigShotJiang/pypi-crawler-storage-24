import sqlite3

import pytest

from loner_routing_algo.router.snap import nearest_node


def setup_test_db() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.execute(
        """
        CREATE TABLE nodes (
            id INTEGER PRIMARY KEY,
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            degree INTEGER NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE VIRTUAL TABLE rtree_nodes USING rtree(
            id,
            minLat, maxLat,
            minLon, maxLon
        )
        """
    )

    points = [
        (1, 23.0000, 120.2000, 1),
        (2, 23.0005, 120.2005, 1),
    ]
    conn.executemany("INSERT INTO nodes(id, lat, lon, degree) VALUES (?,?,?,?)", points)
    conn.executemany(
        "INSERT INTO rtree_nodes(id, minLat, maxLat, minLon, maxLon) VALUES (?,?,?,?,?)",
        [(pid, lat, lat, lon, lon) for pid, lat, lon, _ in points],
    )
    return conn


def test_nearest_node_returns_expected_node():
    conn = setup_test_db()
    nid, dist = nearest_node(conn, 23.00001, 120.20001)
    assert nid == 1
    assert dist >= 0


def test_nearest_node_raises_when_no_candidates():
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE nodes(id INTEGER PRIMARY KEY, lat REAL, lon REAL, degree INTEGER)")
    conn.execute(
        "CREATE VIRTUAL TABLE rtree_nodes USING rtree(id,minLat,maxLat,minLon,maxLon)"
    )
    with pytest.raises(RuntimeError):
        nearest_node(conn, 23.0, 120.2)
