from loner_routing_algo.router.geojson import feature, feature_collection, path_to_linestring


def test_path_to_linestring():
    nodes = {
        1: {"lon": 120.2, "lat": 23.0},
        2: {"lon": 120.21, "lat": 23.01},
    }
    geom = path_to_linestring(nodes, [1, 2])
    assert geom["type"] == "LineString"
    assert geom["coordinates"] == [[120.2, 23.0], [120.21, 23.01]]


def test_feature_collection_shape():
    geom = {"type": "LineString", "coordinates": [[0, 0], [1, 1]]}
    ft = feature(geom, {"profile": "short"})
    fc = feature_collection([ft])
    assert fc["type"] == "FeatureCollection"
    assert len(fc["features"]) == 1
