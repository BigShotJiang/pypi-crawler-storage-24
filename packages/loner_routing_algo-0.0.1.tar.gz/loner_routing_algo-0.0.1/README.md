# loner-routing-algo

Routing algorithm library extracted from `taina-walk-router`.

## Install (dev)

```bash
pip install -e .[test]
```

## Run tests

```bash
pytest
```

## Build wheel

```bash
python -m build
```

Wheel output will be in `dist/`.
