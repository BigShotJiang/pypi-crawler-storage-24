"""loner-routing-algo package."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("loner-routing-algo")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["router", "__version__"]
