from __future__ import annotations

from typing import Any, Dict, List, Tuple


def path_to_linestring(nodes: dict[int, dict[str, Any]], path: List[int]) -> Dict[str, Any]:
    coords = [[nodes[n]["lon"], nodes[n]["lat"]] for n in path]
    return {"type": "LineString", "coordinates": coords}


def feature(geom: Dict[str, Any], props: Dict[str, Any]) -> Dict[str, Any]:
    return {"type": "Feature", "geometry": geom, "properties": props}


def feature_collection(features: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {"type": "FeatureCollection", "features": features}