from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


FORBIDDEN_HIGHWAYS = {"motorway", "trunk"}


@dataclass(frozen=True)
class Weights:
    # node penalties (meters)
    intersection_m: float = 0.0
    major_intersection_m: float = 0.0
    signal_m: float = 0.0
    crossing_m: float = 0.0

    # edge preferences
    prefer_sidewalk: float = 0.0   # amount of multiplier improvement when sidewalk exists
    punish_no_sidewalk: float = 0.0
    punish_primary: float = 0.0
    punish_secondary: float = 0.0
    punish_tertiary: float = 0.0


def node_penalty(v_node: Dict[str, Any], w: Weights) -> float:
    p = 0.0
    degree = int(v_node.get("degree") or 0)
    if degree >= 3:
        p += w.intersection_m

    if int(v_node.get("is_major_intersection") or 0) == 1:
        p += w.major_intersection_m

    if int(v_node.get("is_signal") or 0) == 1:
        p += w.signal_m

    if int(v_node.get("is_crossing") or 0) == 1:
        p += w.crossing_m

    return p


def edge_multiplier(edge: Dict[str, Any], w: Weights) -> float:
    highway = (edge.get("highway") or "").strip()
    if highway in FORBIDDEN_HIGHWAYS:
        return float("inf")

    mul = 1.0

    if highway == "primary":
        mul *= (1.0 + w.punish_primary)
    elif highway == "secondary":
        mul *= (1.0 + w.punish_secondary)
    elif highway == "tertiary":
        mul *= (1.0 + w.punish_tertiary)

    sidewalk = (edge.get("sidewalk") or "").strip()
    if sidewalk in {"both", "left", "right"} and w.prefer_sidewalk > 0:
        mul *= max(0.5, 1.0 - w.prefer_sidewalk)
    elif sidewalk == "no" and w.punish_no_sidewalk > 0:
        mul *= (1.0 + w.punish_no_sidewalk)

    return mul


def edge_cost(dist_m: float, edge: Dict[str, Any], v_node: Dict[str, Any], w: Weights) -> float:
    mul = edge_multiplier(edge, w)
    if mul == float("inf"):
        return float("inf")
    return dist_m * mul + node_penalty(v_node, w)


def preset(profile: str) -> Weights:
    profile = profile.strip()

    if profile == "short":
        return Weights()

    if profile == "few_intersections":
        # prioritize fewer interruptions
        return Weights(
            intersection_m=15.0,
            major_intersection_m=25.0,
            signal_m=40.0,
            crossing_m=20.0,
        )

    if profile == "quiet_walk":
        # your choice: "安靜" => avoid primary/secondary, still penalize big intersections/signals
        return Weights(
            intersection_m=8.0,
            major_intersection_m=30.0,
            signal_m=45.0,
            crossing_m=20.0,
            prefer_sidewalk=0.08,
            punish_no_sidewalk=0.15,
            punish_primary=0.75,
            punish_secondary=0.45,
            punish_tertiary=0.20,
        )

    raise ValueError(f"Unknown profile: {profile}")


def override_weights(w: Weights, overrides: Dict[str, float]) -> Weights:
    data = w.__dict__.copy()
    for k, v in overrides.items():
        if k in data and v is not None:
            data[k] = float(v)
    return Weights(**data)