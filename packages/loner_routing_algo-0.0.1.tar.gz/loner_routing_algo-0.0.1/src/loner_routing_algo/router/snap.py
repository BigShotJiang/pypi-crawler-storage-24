from __future__ import annotations

import math
import sqlite3
from typing import Optional, Tuple


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371000.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = phi2 - phi1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def nearest_node(conn: sqlite3.Connection, lat: float, lon: float) -> Tuple[int, float]:
    # expanding search radius in degrees (~111km per deg lat)
    for r_m in (50, 100, 200, 400, 800, 1500):
        dlat = r_m / 111000.0
        dlon = r_m / (111000.0 * max(0.2, math.cos(math.radians(lat))))
        minLat, maxLat = lat - dlat, lat + dlat
        minLon, maxLon = lon - dlon, lon + dlon

        rows = conn.execute(
            """
            SELECT n.id, n.lat, n.lon
            FROM rtree_nodes r
            JOIN nodes n ON n.id = r.id
            WHERE r.minLat >= ? AND r.maxLat <= ? AND r.minLon >= ? AND r.maxLon <= ?
                AND n.degree > 0
            LIMIT 2000
            """,
            (minLat, maxLat, minLon, maxLon),
        ).fetchall()

        if not rows:
            continue

        best_id = -1
        best_d = float("inf")
        for nid, nlat, nlon in rows:
            d = haversine_m(lat, lon, float(nlat), float(nlon))
            if d < best_d:
                best_d = d
                best_id = int(nid)

        if best_id != -1:
            return best_id, best_d

    raise RuntimeError("No nearby node found (are you outside the bbox?)")