from __future__ import annotations

import heapq
import math
from typing import Any, Callable, Dict, List, Optional, Tuple


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371000.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = phi2 - phi1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def astar(
    start: int,
    goal: int,
    nodes: Dict[int, Dict[str, Any]],
    adj: Dict[int, List[Tuple[int, Dict[str, Any]]]],
    edge_cost_fn: Callable[[float, Dict[str, Any], Dict[str, Any]], float],
) -> Optional[List[int]]:
    g: Dict[int, float] = {start: 0.0}
    parent: Dict[int, int] = {}

    def h(n: int) -> float:
        a, b = nodes[n], nodes[goal]
        return haversine_m(a["lat"], a["lon"], b["lat"], b["lon"])

    pq: List[Tuple[float, int]] = [(h(start), start)]
    visited = set()

    while pq:
        _, u = heapq.heappop(pq)
        if u in visited:
            continue
        visited.add(u)

        if u == goal:
            path = [u]
            while u in parent:
                u = parent[u]
                path.append(u)
            path.reverse()
            return path

        u_node = nodes[u]
        for v, e in adj.get(u, []):
            if v in visited:
                continue
            v_node = nodes[v]
            dist_m = haversine_m(u_node["lat"], u_node["lon"], v_node["lat"], v_node["lon"])
            c = edge_cost_fn(dist_m, e, v_node)
            if not math.isfinite(c):
                continue

            ng = g[u] + c
            if ng < g.get(v, float("inf")):
                g[v] = ng
                parent[v] = u
                heapq.heappush(pq, (ng + h(v), v))

    return None