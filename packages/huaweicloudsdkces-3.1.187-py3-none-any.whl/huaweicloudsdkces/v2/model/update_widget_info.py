# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateWidgetInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'group_id': 'str',
        'widget_id': 'str',
        'metrics': 'list[WidgetMetric]',
        'title': 'str',
        'threshold': 'float',
        'threshold_enabled': 'bool',
        'view': 'str',
        'metric_display_mode': 'str',
        'properties': 'UpdateWidgetInfoProperties',
        'location': 'UpdateWidgetInfoLocation',
        'unit': 'str'
    }

    attribute_map = {
        'group_id': 'group_id',
        'widget_id': 'widget_id',
        'metrics': 'metrics',
        'title': 'title',
        'threshold': 'threshold',
        'threshold_enabled': 'threshold_enabled',
        'view': 'view',
        'metric_display_mode': 'metric_display_mode',
        'properties': 'properties',
        'location': 'location',
        'unit': 'unit'
    }

    def __init__(self, group_id=None, widget_id=None, metrics=None, title=None, threshold=None, threshold_enabled=None, view=None, metric_display_mode=None, properties=None, location=None, unit=None):
        r"""UpdateWidgetInfo

        The model defined in huaweicloud sdk

        :param group_id: **参数解释** 视图分区id **约束限制** 不涉及 **取值范围** 字符串必须以dg开头，后跟22个字母和数字，总长度为24个字符或者为default，default代表不分组 **默认取值** 不涉及 
        :type group_id: str
        :param widget_id: **参数解释** 视图id **约束限制** 不涉及 **取值范围** 字符串必须以wg开头，后跟22个字母和数字，总长度为24个字符 **默认取值** 不涉及 
        :type widget_id: str
        :param metrics: **参数解释** 指标列表 **约束限制** 包含的指标对象个数为[1,200] 
        :type metrics: list[:class:`huaweicloudsdkces.v2.WidgetMetric`]
        :param title: **参数解释** 监控视图标题 **约束限制** 不涉及 **取值范围** 字符串可以包含中文字符，字母，数字，下划线（_），横线（-），冒号（:），分号（;），左圆括号（(），右圆括号（)），句号（.），波浪线（~）， 中文左括号（（），中文右括号（））长度为[1,128]个字符 **默认取值** 不涉及 
        :type title: str
        :param threshold: **参数解释** 监控视图指标的阈值 **约束限制** 不涉及 **取值范围** 阈值为[0,1.7976931348623157e+308] **默认取值** 不涉及 
        :type threshold: float
        :param threshold_enabled: **参数解释** 阈值是否展示 **约束限制** 不涉及 **取值范围** - true 展示 - false 不展示 **默认取值** 不涉及 
        :type threshold_enabled: bool
        :param view: **参数解释** 监控视图图表类型 **约束限制** 不涉及 **取值范围** 枚举值： - bar 条形图 - line 折线图 - bar_chart 柱状图 - table 表格 - circular_bar 环形柱状图 - area_chart 面积图 **默认取值** 不涉及 
        :type view: str
        :param metric_display_mode: **参数解释** 指标展示类型 **约束限制** 不涉及 **取值范围** 枚举值： - single 单指标展示 - multiple 多指标展示 **默认取值** 不涉及 
        :type metric_display_mode: str
        :param properties: 
        :type properties: :class:`huaweicloudsdkces.v2.UpdateWidgetInfoProperties`
        :param location: 
        :type location: :class:`huaweicloudsdkces.v2.UpdateWidgetInfoLocation`
        :param unit: **参数解释** 单位 **约束限制** 不涉及 **取值范围** 长度为[0,32]个字符 **默认取值** 不涉及 
        :type unit: str
        """
        
        

        self._group_id = None
        self._widget_id = None
        self._metrics = None
        self._title = None
        self._threshold = None
        self._threshold_enabled = None
        self._view = None
        self._metric_display_mode = None
        self._properties = None
        self._location = None
        self._unit = None
        self.discriminator = None

        if group_id is not None:
            self.group_id = group_id
        self.widget_id = widget_id
        if metrics is not None:
            self.metrics = metrics
        if title is not None:
            self.title = title
        if threshold is not None:
            self.threshold = threshold
        if threshold_enabled is not None:
            self.threshold_enabled = threshold_enabled
        if view is not None:
            self.view = view
        if metric_display_mode is not None:
            self.metric_display_mode = metric_display_mode
        if properties is not None:
            self.properties = properties
        if location is not None:
            self.location = location
        if unit is not None:
            self.unit = unit

    @property
    def group_id(self):
        r"""Gets the group_id of this UpdateWidgetInfo.

        **参数解释** 视图分区id **约束限制** 不涉及 **取值范围** 字符串必须以dg开头，后跟22个字母和数字，总长度为24个字符或者为default，default代表不分组 **默认取值** 不涉及 

        :return: The group_id of this UpdateWidgetInfo.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this UpdateWidgetInfo.

        **参数解释** 视图分区id **约束限制** 不涉及 **取值范围** 字符串必须以dg开头，后跟22个字母和数字，总长度为24个字符或者为default，default代表不分组 **默认取值** 不涉及 

        :param group_id: The group_id of this UpdateWidgetInfo.
        :type group_id: str
        """
        self._group_id = group_id

    @property
    def widget_id(self):
        r"""Gets the widget_id of this UpdateWidgetInfo.

        **参数解释** 视图id **约束限制** 不涉及 **取值范围** 字符串必须以wg开头，后跟22个字母和数字，总长度为24个字符 **默认取值** 不涉及 

        :return: The widget_id of this UpdateWidgetInfo.
        :rtype: str
        """
        return self._widget_id

    @widget_id.setter
    def widget_id(self, widget_id):
        r"""Sets the widget_id of this UpdateWidgetInfo.

        **参数解释** 视图id **约束限制** 不涉及 **取值范围** 字符串必须以wg开头，后跟22个字母和数字，总长度为24个字符 **默认取值** 不涉及 

        :param widget_id: The widget_id of this UpdateWidgetInfo.
        :type widget_id: str
        """
        self._widget_id = widget_id

    @property
    def metrics(self):
        r"""Gets the metrics of this UpdateWidgetInfo.

        **参数解释** 指标列表 **约束限制** 包含的指标对象个数为[1,200] 

        :return: The metrics of this UpdateWidgetInfo.
        :rtype: list[:class:`huaweicloudsdkces.v2.WidgetMetric`]
        """
        return self._metrics

    @metrics.setter
    def metrics(self, metrics):
        r"""Sets the metrics of this UpdateWidgetInfo.

        **参数解释** 指标列表 **约束限制** 包含的指标对象个数为[1,200] 

        :param metrics: The metrics of this UpdateWidgetInfo.
        :type metrics: list[:class:`huaweicloudsdkces.v2.WidgetMetric`]
        """
        self._metrics = metrics

    @property
    def title(self):
        r"""Gets the title of this UpdateWidgetInfo.

        **参数解释** 监控视图标题 **约束限制** 不涉及 **取值范围** 字符串可以包含中文字符，字母，数字，下划线（_），横线（-），冒号（:），分号（;），左圆括号（(），右圆括号（)），句号（.），波浪线（~）， 中文左括号（（），中文右括号（））长度为[1,128]个字符 **默认取值** 不涉及 

        :return: The title of this UpdateWidgetInfo.
        :rtype: str
        """
        return self._title

    @title.setter
    def title(self, title):
        r"""Sets the title of this UpdateWidgetInfo.

        **参数解释** 监控视图标题 **约束限制** 不涉及 **取值范围** 字符串可以包含中文字符，字母，数字，下划线（_），横线（-），冒号（:），分号（;），左圆括号（(），右圆括号（)），句号（.），波浪线（~）， 中文左括号（（），中文右括号（））长度为[1,128]个字符 **默认取值** 不涉及 

        :param title: The title of this UpdateWidgetInfo.
        :type title: str
        """
        self._title = title

    @property
    def threshold(self):
        r"""Gets the threshold of this UpdateWidgetInfo.

        **参数解释** 监控视图指标的阈值 **约束限制** 不涉及 **取值范围** 阈值为[0,1.7976931348623157e+308] **默认取值** 不涉及 

        :return: The threshold of this UpdateWidgetInfo.
        :rtype: float
        """
        return self._threshold

    @threshold.setter
    def threshold(self, threshold):
        r"""Sets the threshold of this UpdateWidgetInfo.

        **参数解释** 监控视图指标的阈值 **约束限制** 不涉及 **取值范围** 阈值为[0,1.7976931348623157e+308] **默认取值** 不涉及 

        :param threshold: The threshold of this UpdateWidgetInfo.
        :type threshold: float
        """
        self._threshold = threshold

    @property
    def threshold_enabled(self):
        r"""Gets the threshold_enabled of this UpdateWidgetInfo.

        **参数解释** 阈值是否展示 **约束限制** 不涉及 **取值范围** - true 展示 - false 不展示 **默认取值** 不涉及 

        :return: The threshold_enabled of this UpdateWidgetInfo.
        :rtype: bool
        """
        return self._threshold_enabled

    @threshold_enabled.setter
    def threshold_enabled(self, threshold_enabled):
        r"""Sets the threshold_enabled of this UpdateWidgetInfo.

        **参数解释** 阈值是否展示 **约束限制** 不涉及 **取值范围** - true 展示 - false 不展示 **默认取值** 不涉及 

        :param threshold_enabled: The threshold_enabled of this UpdateWidgetInfo.
        :type threshold_enabled: bool
        """
        self._threshold_enabled = threshold_enabled

    @property
    def view(self):
        r"""Gets the view of this UpdateWidgetInfo.

        **参数解释** 监控视图图表类型 **约束限制** 不涉及 **取值范围** 枚举值： - bar 条形图 - line 折线图 - bar_chart 柱状图 - table 表格 - circular_bar 环形柱状图 - area_chart 面积图 **默认取值** 不涉及 

        :return: The view of this UpdateWidgetInfo.
        :rtype: str
        """
        return self._view

    @view.setter
    def view(self, view):
        r"""Sets the view of this UpdateWidgetInfo.

        **参数解释** 监控视图图表类型 **约束限制** 不涉及 **取值范围** 枚举值： - bar 条形图 - line 折线图 - bar_chart 柱状图 - table 表格 - circular_bar 环形柱状图 - area_chart 面积图 **默认取值** 不涉及 

        :param view: The view of this UpdateWidgetInfo.
        :type view: str
        """
        self._view = view

    @property
    def metric_display_mode(self):
        r"""Gets the metric_display_mode of this UpdateWidgetInfo.

        **参数解释** 指标展示类型 **约束限制** 不涉及 **取值范围** 枚举值： - single 单指标展示 - multiple 多指标展示 **默认取值** 不涉及 

        :return: The metric_display_mode of this UpdateWidgetInfo.
        :rtype: str
        """
        return self._metric_display_mode

    @metric_display_mode.setter
    def metric_display_mode(self, metric_display_mode):
        r"""Sets the metric_display_mode of this UpdateWidgetInfo.

        **参数解释** 指标展示类型 **约束限制** 不涉及 **取值范围** 枚举值： - single 单指标展示 - multiple 多指标展示 **默认取值** 不涉及 

        :param metric_display_mode: The metric_display_mode of this UpdateWidgetInfo.
        :type metric_display_mode: str
        """
        self._metric_display_mode = metric_display_mode

    @property
    def properties(self):
        r"""Gets the properties of this UpdateWidgetInfo.

        :return: The properties of this UpdateWidgetInfo.
        :rtype: :class:`huaweicloudsdkces.v2.UpdateWidgetInfoProperties`
        """
        return self._properties

    @properties.setter
    def properties(self, properties):
        r"""Sets the properties of this UpdateWidgetInfo.

        :param properties: The properties of this UpdateWidgetInfo.
        :type properties: :class:`huaweicloudsdkces.v2.UpdateWidgetInfoProperties`
        """
        self._properties = properties

    @property
    def location(self):
        r"""Gets the location of this UpdateWidgetInfo.

        :return: The location of this UpdateWidgetInfo.
        :rtype: :class:`huaweicloudsdkces.v2.UpdateWidgetInfoLocation`
        """
        return self._location

    @location.setter
    def location(self, location):
        r"""Sets the location of this UpdateWidgetInfo.

        :param location: The location of this UpdateWidgetInfo.
        :type location: :class:`huaweicloudsdkces.v2.UpdateWidgetInfoLocation`
        """
        self._location = location

    @property
    def unit(self):
        r"""Gets the unit of this UpdateWidgetInfo.

        **参数解释** 单位 **约束限制** 不涉及 **取值范围** 长度为[0,32]个字符 **默认取值** 不涉及 

        :return: The unit of this UpdateWidgetInfo.
        :rtype: str
        """
        return self._unit

    @unit.setter
    def unit(self, unit):
        r"""Sets the unit of this UpdateWidgetInfo.

        **参数解释** 单位 **约束限制** 不涉及 **取值范围** 长度为[0,32]个字符 **默认取值** 不涉及 

        :param unit: The unit of this UpdateWidgetInfo.
        :type unit: str
        """
        self._unit = unit

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateWidgetInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
