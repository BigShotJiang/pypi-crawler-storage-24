# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListAlarmRuleResourcesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'resources': 'list[list[DimensionResp]]',
        'count': 'int'
    }

    attribute_map = {
        'resources': 'resources',
        'count': 'count'
    }

    def __init__(self, resources=None, count=None):
        r"""ListAlarmRuleResourcesResponse

        The model defined in huaweicloud sdk

        :param resources: **参数解释**： 资源信息。 
        :type resources: list[list[DimensionResp]]
        :param count: **参数解释**： 资源总数。 **取值范围**： [0,2147483647] 
        :type count: int
        """
        
        super().__init__()

        self._resources = None
        self._count = None
        self.discriminator = None

        if resources is not None:
            self.resources = resources
        if count is not None:
            self.count = count

    @property
    def resources(self):
        r"""Gets the resources of this ListAlarmRuleResourcesResponse.

        **参数解释**： 资源信息。 

        :return: The resources of this ListAlarmRuleResourcesResponse.
        :rtype: list[list[DimensionResp]]
        """
        return self._resources

    @resources.setter
    def resources(self, resources):
        r"""Sets the resources of this ListAlarmRuleResourcesResponse.

        **参数解释**： 资源信息。 

        :param resources: The resources of this ListAlarmRuleResourcesResponse.
        :type resources: list[list[DimensionResp]]
        """
        self._resources = resources

    @property
    def count(self):
        r"""Gets the count of this ListAlarmRuleResourcesResponse.

        **参数解释**： 资源总数。 **取值范围**： [0,2147483647] 

        :return: The count of this ListAlarmRuleResourcesResponse.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this ListAlarmRuleResourcesResponse.

        **参数解释**： 资源总数。 **取值范围**： [0,2147483647] 

        :param count: The count of this ListAlarmRuleResourcesResponse.
        :type count: int
        """
        self._count = count

    def to_dict(self):
        import warnings
        warnings.warn("ListAlarmRuleResourcesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListAlarmRuleResourcesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
