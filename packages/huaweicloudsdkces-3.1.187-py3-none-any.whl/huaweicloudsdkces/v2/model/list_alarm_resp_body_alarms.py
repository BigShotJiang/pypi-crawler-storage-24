# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListAlarmRespBodyAlarms:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'alarm_id': 'str',
        'name': 'str',
        'description': 'str',
        'namespace': 'str',
        'policies': 'list[PolicyResp]',
        'resources': 'list[ResourcesInListResp]',
        'type': 'AlarmTypeResp',
        'enabled': 'bool',
        'notification_enabled': 'bool',
        'alarm_notifications': 'list[NotificationResp]',
        'ok_notifications': 'list[NotificationResp]',
        'notification_begin_time': 'str',
        'notification_end_time': 'str',
        'effective_timezone': 'str',
        'enterprise_project_id': 'str',
        'alarm_template_id': 'str',
        'product_name': 'str',
        'resource_level': 'str',
        'tags': 'list[ResourceTagResp]'
    }

    attribute_map = {
        'alarm_id': 'alarm_id',
        'name': 'name',
        'description': 'description',
        'namespace': 'namespace',
        'policies': 'policies',
        'resources': 'resources',
        'type': 'type',
        'enabled': 'enabled',
        'notification_enabled': 'notification_enabled',
        'alarm_notifications': 'alarm_notifications',
        'ok_notifications': 'ok_notifications',
        'notification_begin_time': 'notification_begin_time',
        'notification_end_time': 'notification_end_time',
        'effective_timezone': 'effective_timezone',
        'enterprise_project_id': 'enterprise_project_id',
        'alarm_template_id': 'alarm_template_id',
        'product_name': 'product_name',
        'resource_level': 'resource_level',
        'tags': 'tags'
    }

    def __init__(self, alarm_id=None, name=None, description=None, namespace=None, policies=None, resources=None, type=None, enabled=None, notification_enabled=None, alarm_notifications=None, ok_notifications=None, notification_begin_time=None, notification_end_time=None, effective_timezone=None, enterprise_project_id=None, alarm_template_id=None, product_name=None, resource_level=None, tags=None):
        r"""ListAlarmRespBodyAlarms

        The model defined in huaweicloud sdk

        :param alarm_id: **参数解释**： 告警规则id。如 al123232232341232132 **取值范围**： 以al开头，后跟22个数字或字母。长度为24个字符。 
        :type alarm_id: str
        :param name: **参数解释**： 告警规则名称。     **取值范围**： 只能包含0-9/a-z/A-Z/_/-或汉字，长度[1，128]个字符。 
        :type name: str
        :param description: **参数解释**： 告警描述。     **取值范围**： 长度为[0,256]个字符。 
        :type description: str
        :param namespace: **参数解释**： 查询服务的命名空间，各服务命名空间请参阅[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)。    **取值范围**： 格式为service.item；service和item必须是字符串，必须以字母开头，只能包含0-9/a-z/A-Z/_。字符串的长度为[0,32]个字符。 
        :type namespace: str
        :param policies: **参数解释**： 告警策略 **取值范围**： 最多包含100个策略。 
        :type policies: list[:class:`huaweicloudsdkces.v2.PolicyResp`]
        :param resources: **参数解释**： 资源列表，关联资源需要使用[[查询告警规则资源列表](https://support.huaweicloud.com/api-ces/ListAlarmRuleResources.html)](tag:hc)[[查询告警规则资源列表](https://support.huaweicloud.com/intl/en-us/api-ces/ListAlarmRuleResources.html)](tag:hk)[[查询告警规则资源列表](https://support.huaweicloud.com/eu/en-us/api-ces/ListAlarmRuleResources.html)](tag:hws_eu)[[查询告警规则资源列表](ListAlarmRuleResources.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)获取。 **取值范围**： 最多支持3000个资源。 
        :type resources: list[:class:`huaweicloudsdkces.v2.ResourcesInListResp`]
        :param type: 
        :type type: :class:`huaweicloudsdkces.v2.AlarmTypeResp`
        :param enabled: **参数解释**： 是否开启告警规则。 **取值范围**： 布尔值。 - true:开启。 - false:关闭。 
        :type enabled: bool
        :param notification_enabled: **参数解释**： 是否开启告警通知。     **取值范围**： 布尔值。 - true:开启。 - false:关闭。 
        :type notification_enabled: bool
        :param alarm_notifications: **参数解释**： 触发告警时，通知组/主题订阅的信息。 
        :type alarm_notifications: list[:class:`huaweicloudsdkces.v2.NotificationResp`]
        :param ok_notifications: **参数解释**： 告警恢复时，通知组/主题订阅的信息。 
        :type ok_notifications: list[:class:`huaweicloudsdkces.v2.NotificationResp`]
        :param notification_begin_time: **参数解释**： 告警通知开启时间。如 00:00    **取值范围**： 只能包含数字、“:”，长度为[1,64]个字符。 
        :type notification_begin_time: str
        :param notification_end_time: **参数解释**： 告警通知关闭时间。如 08:00   **取值范围**： 只能包含数字、“:”，长度为[1,64]个字符。 
        :type notification_end_time: str
        :param effective_timezone: **参数解释**： 时区，形如：\&quot;GMT-08:00\&quot;、\&quot;GMT+08:00\&quot;、\&quot;GMT+0:00\&quot;。    **取值范围**： 长度为[1,16]个字符。 
        :type effective_timezone: str
        :param enterprise_project_id: **参数解释**： 企业项目ID。     **取值范围**： 只能包含小写字母、数字、“-”。0 代表默认企业项目ID 
        :type enterprise_project_id: str
        :param alarm_template_id: **参数解释**： 告警规则关联告警模板ID     **取值范围**： 以at开头，只包含字母、数字，长度为[2,64]个字符。 
        :type alarm_template_id: str
        :param product_name: **参数解释**： 当资源层级为云产品时的云产品名称，一般由\&quot;服务命名空间,服务首层维度名称\&quot;组成，如\&quot;SYS.ECS,instance_id\&quot;。 **取值范围**: 长度为[0,128]个字符。 
        :type product_name: str
        :param resource_level: **参数解释**： 资源层级。 **取值范围**: 枚举值。 - product：云产品。 - dimension：子维度。 
        :type resource_level: str
        :param tags: **参数解释**： 租户标签列表 **取值范围**: 最多支持20个标签。 
        :type tags: list[:class:`huaweicloudsdkces.v2.ResourceTagResp`]
        """
        
        

        self._alarm_id = None
        self._name = None
        self._description = None
        self._namespace = None
        self._policies = None
        self._resources = None
        self._type = None
        self._enabled = None
        self._notification_enabled = None
        self._alarm_notifications = None
        self._ok_notifications = None
        self._notification_begin_time = None
        self._notification_end_time = None
        self._effective_timezone = None
        self._enterprise_project_id = None
        self._alarm_template_id = None
        self._product_name = None
        self._resource_level = None
        self._tags = None
        self.discriminator = None

        if alarm_id is not None:
            self.alarm_id = alarm_id
        if name is not None:
            self.name = name
        if description is not None:
            self.description = description
        if namespace is not None:
            self.namespace = namespace
        if policies is not None:
            self.policies = policies
        if resources is not None:
            self.resources = resources
        if type is not None:
            self.type = type
        if enabled is not None:
            self.enabled = enabled
        if notification_enabled is not None:
            self.notification_enabled = notification_enabled
        if alarm_notifications is not None:
            self.alarm_notifications = alarm_notifications
        if ok_notifications is not None:
            self.ok_notifications = ok_notifications
        if notification_begin_time is not None:
            self.notification_begin_time = notification_begin_time
        if notification_end_time is not None:
            self.notification_end_time = notification_end_time
        if effective_timezone is not None:
            self.effective_timezone = effective_timezone
        if enterprise_project_id is not None:
            self.enterprise_project_id = enterprise_project_id
        if alarm_template_id is not None:
            self.alarm_template_id = alarm_template_id
        if product_name is not None:
            self.product_name = product_name
        if resource_level is not None:
            self.resource_level = resource_level
        if tags is not None:
            self.tags = tags

    @property
    def alarm_id(self):
        r"""Gets the alarm_id of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警规则id。如 al123232232341232132 **取值范围**： 以al开头，后跟22个数字或字母。长度为24个字符。 

        :return: The alarm_id of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._alarm_id

    @alarm_id.setter
    def alarm_id(self, alarm_id):
        r"""Sets the alarm_id of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警规则id。如 al123232232341232132 **取值范围**： 以al开头，后跟22个数字或字母。长度为24个字符。 

        :param alarm_id: The alarm_id of this ListAlarmRespBodyAlarms.
        :type alarm_id: str
        """
        self._alarm_id = alarm_id

    @property
    def name(self):
        r"""Gets the name of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警规则名称。     **取值范围**： 只能包含0-9/a-z/A-Z/_/-或汉字，长度[1，128]个字符。 

        :return: The name of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警规则名称。     **取值范围**： 只能包含0-9/a-z/A-Z/_/-或汉字，长度[1，128]个字符。 

        :param name: The name of this ListAlarmRespBodyAlarms.
        :type name: str
        """
        self._name = name

    @property
    def description(self):
        r"""Gets the description of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警描述。     **取值范围**： 长度为[0,256]个字符。 

        :return: The description of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警描述。     **取值范围**： 长度为[0,256]个字符。 

        :param description: The description of this ListAlarmRespBodyAlarms.
        :type description: str
        """
        self._description = description

    @property
    def namespace(self):
        r"""Gets the namespace of this ListAlarmRespBodyAlarms.

        **参数解释**： 查询服务的命名空间，各服务命名空间请参阅[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)。    **取值范围**： 格式为service.item；service和item必须是字符串，必须以字母开头，只能包含0-9/a-z/A-Z/_。字符串的长度为[0,32]个字符。 

        :return: The namespace of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._namespace

    @namespace.setter
    def namespace(self, namespace):
        r"""Sets the namespace of this ListAlarmRespBodyAlarms.

        **参数解释**： 查询服务的命名空间，各服务命名空间请参阅[[支持监控的服务列表](https://support.huaweicloud.com/api-ces/ces_03_0059.html)](tag:hc)[[支持监控的服务列表](https://support.huaweicloud.com/intl/en-us/api-ces/ces_03_0059.html)](tag:hk)[[支持监控的服务列表](https://support.huaweicloud.com/eu/en-us/api-ces/ces_03_0059.html)](tag:hws_eu)[[支持监控的服务列表](ces_03_0059.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)。    **取值范围**： 格式为service.item；service和item必须是字符串，必须以字母开头，只能包含0-9/a-z/A-Z/_。字符串的长度为[0,32]个字符。 

        :param namespace: The namespace of this ListAlarmRespBodyAlarms.
        :type namespace: str
        """
        self._namespace = namespace

    @property
    def policies(self):
        r"""Gets the policies of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警策略 **取值范围**： 最多包含100个策略。 

        :return: The policies of this ListAlarmRespBodyAlarms.
        :rtype: list[:class:`huaweicloudsdkces.v2.PolicyResp`]
        """
        return self._policies

    @policies.setter
    def policies(self, policies):
        r"""Sets the policies of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警策略 **取值范围**： 最多包含100个策略。 

        :param policies: The policies of this ListAlarmRespBodyAlarms.
        :type policies: list[:class:`huaweicloudsdkces.v2.PolicyResp`]
        """
        self._policies = policies

    @property
    def resources(self):
        r"""Gets the resources of this ListAlarmRespBodyAlarms.

        **参数解释**： 资源列表，关联资源需要使用[[查询告警规则资源列表](https://support.huaweicloud.com/api-ces/ListAlarmRuleResources.html)](tag:hc)[[查询告警规则资源列表](https://support.huaweicloud.com/intl/en-us/api-ces/ListAlarmRuleResources.html)](tag:hk)[[查询告警规则资源列表](https://support.huaweicloud.com/eu/en-us/api-ces/ListAlarmRuleResources.html)](tag:hws_eu)[[查询告警规则资源列表](ListAlarmRuleResources.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)获取。 **取值范围**： 最多支持3000个资源。 

        :return: The resources of this ListAlarmRespBodyAlarms.
        :rtype: list[:class:`huaweicloudsdkces.v2.ResourcesInListResp`]
        """
        return self._resources

    @resources.setter
    def resources(self, resources):
        r"""Sets the resources of this ListAlarmRespBodyAlarms.

        **参数解释**： 资源列表，关联资源需要使用[[查询告警规则资源列表](https://support.huaweicloud.com/api-ces/ListAlarmRuleResources.html)](tag:hc)[[查询告警规则资源列表](https://support.huaweicloud.com/intl/en-us/api-ces/ListAlarmRuleResources.html)](tag:hk)[[查询告警规则资源列表](https://support.huaweicloud.com/eu/en-us/api-ces/ListAlarmRuleResources.html)](tag:hws_eu)[[查询告警规则资源列表](ListAlarmRuleResources.xml)](tag:ax,cmcc,ctc,dt,dt_test,hcso_dt,fcs,fcs_vm,mix,g42,hk_g42,hk_sbc,hk_tm,hk_vdf,hws_ocb,ocb,sbc,srg)获取。 **取值范围**： 最多支持3000个资源。 

        :param resources: The resources of this ListAlarmRespBodyAlarms.
        :type resources: list[:class:`huaweicloudsdkces.v2.ResourcesInListResp`]
        """
        self._resources = resources

    @property
    def type(self):
        r"""Gets the type of this ListAlarmRespBodyAlarms.

        :return: The type of this ListAlarmRespBodyAlarms.
        :rtype: :class:`huaweicloudsdkces.v2.AlarmTypeResp`
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this ListAlarmRespBodyAlarms.

        :param type: The type of this ListAlarmRespBodyAlarms.
        :type type: :class:`huaweicloudsdkces.v2.AlarmTypeResp`
        """
        self._type = type

    @property
    def enabled(self):
        r"""Gets the enabled of this ListAlarmRespBodyAlarms.

        **参数解释**： 是否开启告警规则。 **取值范围**： 布尔值。 - true:开启。 - false:关闭。 

        :return: The enabled of this ListAlarmRespBodyAlarms.
        :rtype: bool
        """
        return self._enabled

    @enabled.setter
    def enabled(self, enabled):
        r"""Sets the enabled of this ListAlarmRespBodyAlarms.

        **参数解释**： 是否开启告警规则。 **取值范围**： 布尔值。 - true:开启。 - false:关闭。 

        :param enabled: The enabled of this ListAlarmRespBodyAlarms.
        :type enabled: bool
        """
        self._enabled = enabled

    @property
    def notification_enabled(self):
        r"""Gets the notification_enabled of this ListAlarmRespBodyAlarms.

        **参数解释**： 是否开启告警通知。     **取值范围**： 布尔值。 - true:开启。 - false:关闭。 

        :return: The notification_enabled of this ListAlarmRespBodyAlarms.
        :rtype: bool
        """
        return self._notification_enabled

    @notification_enabled.setter
    def notification_enabled(self, notification_enabled):
        r"""Sets the notification_enabled of this ListAlarmRespBodyAlarms.

        **参数解释**： 是否开启告警通知。     **取值范围**： 布尔值。 - true:开启。 - false:关闭。 

        :param notification_enabled: The notification_enabled of this ListAlarmRespBodyAlarms.
        :type notification_enabled: bool
        """
        self._notification_enabled = notification_enabled

    @property
    def alarm_notifications(self):
        r"""Gets the alarm_notifications of this ListAlarmRespBodyAlarms.

        **参数解释**： 触发告警时，通知组/主题订阅的信息。 

        :return: The alarm_notifications of this ListAlarmRespBodyAlarms.
        :rtype: list[:class:`huaweicloudsdkces.v2.NotificationResp`]
        """
        return self._alarm_notifications

    @alarm_notifications.setter
    def alarm_notifications(self, alarm_notifications):
        r"""Sets the alarm_notifications of this ListAlarmRespBodyAlarms.

        **参数解释**： 触发告警时，通知组/主题订阅的信息。 

        :param alarm_notifications: The alarm_notifications of this ListAlarmRespBodyAlarms.
        :type alarm_notifications: list[:class:`huaweicloudsdkces.v2.NotificationResp`]
        """
        self._alarm_notifications = alarm_notifications

    @property
    def ok_notifications(self):
        r"""Gets the ok_notifications of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警恢复时，通知组/主题订阅的信息。 

        :return: The ok_notifications of this ListAlarmRespBodyAlarms.
        :rtype: list[:class:`huaweicloudsdkces.v2.NotificationResp`]
        """
        return self._ok_notifications

    @ok_notifications.setter
    def ok_notifications(self, ok_notifications):
        r"""Sets the ok_notifications of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警恢复时，通知组/主题订阅的信息。 

        :param ok_notifications: The ok_notifications of this ListAlarmRespBodyAlarms.
        :type ok_notifications: list[:class:`huaweicloudsdkces.v2.NotificationResp`]
        """
        self._ok_notifications = ok_notifications

    @property
    def notification_begin_time(self):
        r"""Gets the notification_begin_time of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警通知开启时间。如 00:00    **取值范围**： 只能包含数字、“:”，长度为[1,64]个字符。 

        :return: The notification_begin_time of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._notification_begin_time

    @notification_begin_time.setter
    def notification_begin_time(self, notification_begin_time):
        r"""Sets the notification_begin_time of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警通知开启时间。如 00:00    **取值范围**： 只能包含数字、“:”，长度为[1,64]个字符。 

        :param notification_begin_time: The notification_begin_time of this ListAlarmRespBodyAlarms.
        :type notification_begin_time: str
        """
        self._notification_begin_time = notification_begin_time

    @property
    def notification_end_time(self):
        r"""Gets the notification_end_time of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警通知关闭时间。如 08:00   **取值范围**： 只能包含数字、“:”，长度为[1,64]个字符。 

        :return: The notification_end_time of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._notification_end_time

    @notification_end_time.setter
    def notification_end_time(self, notification_end_time):
        r"""Sets the notification_end_time of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警通知关闭时间。如 08:00   **取值范围**： 只能包含数字、“:”，长度为[1,64]个字符。 

        :param notification_end_time: The notification_end_time of this ListAlarmRespBodyAlarms.
        :type notification_end_time: str
        """
        self._notification_end_time = notification_end_time

    @property
    def effective_timezone(self):
        r"""Gets the effective_timezone of this ListAlarmRespBodyAlarms.

        **参数解释**： 时区，形如：\"GMT-08:00\"、\"GMT+08:00\"、\"GMT+0:00\"。    **取值范围**： 长度为[1,16]个字符。 

        :return: The effective_timezone of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._effective_timezone

    @effective_timezone.setter
    def effective_timezone(self, effective_timezone):
        r"""Sets the effective_timezone of this ListAlarmRespBodyAlarms.

        **参数解释**： 时区，形如：\"GMT-08:00\"、\"GMT+08:00\"、\"GMT+0:00\"。    **取值范围**： 长度为[1,16]个字符。 

        :param effective_timezone: The effective_timezone of this ListAlarmRespBodyAlarms.
        :type effective_timezone: str
        """
        self._effective_timezone = effective_timezone

    @property
    def enterprise_project_id(self):
        r"""Gets the enterprise_project_id of this ListAlarmRespBodyAlarms.

        **参数解释**： 企业项目ID。     **取值范围**： 只能包含小写字母、数字、“-”。0 代表默认企业项目ID 

        :return: The enterprise_project_id of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._enterprise_project_id

    @enterprise_project_id.setter
    def enterprise_project_id(self, enterprise_project_id):
        r"""Sets the enterprise_project_id of this ListAlarmRespBodyAlarms.

        **参数解释**： 企业项目ID。     **取值范围**： 只能包含小写字母、数字、“-”。0 代表默认企业项目ID 

        :param enterprise_project_id: The enterprise_project_id of this ListAlarmRespBodyAlarms.
        :type enterprise_project_id: str
        """
        self._enterprise_project_id = enterprise_project_id

    @property
    def alarm_template_id(self):
        r"""Gets the alarm_template_id of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警规则关联告警模板ID     **取值范围**： 以at开头，只包含字母、数字，长度为[2,64]个字符。 

        :return: The alarm_template_id of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._alarm_template_id

    @alarm_template_id.setter
    def alarm_template_id(self, alarm_template_id):
        r"""Sets the alarm_template_id of this ListAlarmRespBodyAlarms.

        **参数解释**： 告警规则关联告警模板ID     **取值范围**： 以at开头，只包含字母、数字，长度为[2,64]个字符。 

        :param alarm_template_id: The alarm_template_id of this ListAlarmRespBodyAlarms.
        :type alarm_template_id: str
        """
        self._alarm_template_id = alarm_template_id

    @property
    def product_name(self):
        r"""Gets the product_name of this ListAlarmRespBodyAlarms.

        **参数解释**： 当资源层级为云产品时的云产品名称，一般由\"服务命名空间,服务首层维度名称\"组成，如\"SYS.ECS,instance_id\"。 **取值范围**: 长度为[0,128]个字符。 

        :return: The product_name of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._product_name

    @product_name.setter
    def product_name(self, product_name):
        r"""Sets the product_name of this ListAlarmRespBodyAlarms.

        **参数解释**： 当资源层级为云产品时的云产品名称，一般由\"服务命名空间,服务首层维度名称\"组成，如\"SYS.ECS,instance_id\"。 **取值范围**: 长度为[0,128]个字符。 

        :param product_name: The product_name of this ListAlarmRespBodyAlarms.
        :type product_name: str
        """
        self._product_name = product_name

    @property
    def resource_level(self):
        r"""Gets the resource_level of this ListAlarmRespBodyAlarms.

        **参数解释**： 资源层级。 **取值范围**: 枚举值。 - product：云产品。 - dimension：子维度。 

        :return: The resource_level of this ListAlarmRespBodyAlarms.
        :rtype: str
        """
        return self._resource_level

    @resource_level.setter
    def resource_level(self, resource_level):
        r"""Sets the resource_level of this ListAlarmRespBodyAlarms.

        **参数解释**： 资源层级。 **取值范围**: 枚举值。 - product：云产品。 - dimension：子维度。 

        :param resource_level: The resource_level of this ListAlarmRespBodyAlarms.
        :type resource_level: str
        """
        self._resource_level = resource_level

    @property
    def tags(self):
        r"""Gets the tags of this ListAlarmRespBodyAlarms.

        **参数解释**： 租户标签列表 **取值范围**: 最多支持20个标签。 

        :return: The tags of this ListAlarmRespBodyAlarms.
        :rtype: list[:class:`huaweicloudsdkces.v2.ResourceTagResp`]
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this ListAlarmRespBodyAlarms.

        **参数解释**： 租户标签列表 **取值范围**: 最多支持20个标签。 

        :param tags: The tags of this ListAlarmRespBodyAlarms.
        :type tags: list[:class:`huaweicloudsdkces.v2.ResourceTagResp`]
        """
        self._tags = tags

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListAlarmRespBodyAlarms):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
