# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateAlarmTemplateRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'template_name': 'str',
        'template_type': 'int',
        'template_description': 'str',
        'is_overwrite': 'bool',
        'policies': 'list[Policies]'
    }

    attribute_map = {
        'template_name': 'template_name',
        'template_type': 'template_type',
        'template_description': 'template_description',
        'is_overwrite': 'is_overwrite',
        'policies': 'policies'
    }

    def __init__(self, template_name=None, template_type=None, template_description=None, is_overwrite=None, policies=None):
        r"""CreateAlarmTemplateRequestBody

        The model defined in huaweicloud sdk

        :param template_name: **参数解释**： 告警模板的名称。 **约束限制**： 不涉及。 **取值范围**： 以字母或汉字开头，可包含字母、数字、汉字、_、-，长度为[1,128]个字符。           **默认取值**： 不涉及。 
        :type template_name: str
        :param template_type: **参数解释**： 自定义告警模板类型。 **约束限制**： 不涉及。 **取值范围**： 枚举值。 - 0：指标。 - 2： 事件。           **默认取值**： 0 
        :type template_type: int
        :param template_description: **参数解释**： 告警模板的描述     **约束限制**： 不涉及。 **取值范围**： 长度范围[0,256]。          **默认取值**： 空字符串。 
        :type template_description: str
        :param is_overwrite: **参数解释**： 是否对模板名称已经存在的告警模板进行覆盖。 **约束限制**： 不涉及。 **取值范围**： 布尔值。 - true:覆盖同名告警模板。 - false：不覆盖，新建告警模板。           **默认取值**： false 
        :type is_overwrite: bool
        :param policies: **参数解释**： 告警模板策略列表。 **约束限制**： 不超过1000个策略。 
        :type policies: list[:class:`huaweicloudsdkces.v2.Policies`]
        """
        
        

        self._template_name = None
        self._template_type = None
        self._template_description = None
        self._is_overwrite = None
        self._policies = None
        self.discriminator = None

        self.template_name = template_name
        if template_type is not None:
            self.template_type = template_type
        if template_description is not None:
            self.template_description = template_description
        if is_overwrite is not None:
            self.is_overwrite = is_overwrite
        self.policies = policies

    @property
    def template_name(self):
        r"""Gets the template_name of this CreateAlarmTemplateRequestBody.

        **参数解释**： 告警模板的名称。 **约束限制**： 不涉及。 **取值范围**： 以字母或汉字开头，可包含字母、数字、汉字、_、-，长度为[1,128]个字符。           **默认取值**： 不涉及。 

        :return: The template_name of this CreateAlarmTemplateRequestBody.
        :rtype: str
        """
        return self._template_name

    @template_name.setter
    def template_name(self, template_name):
        r"""Sets the template_name of this CreateAlarmTemplateRequestBody.

        **参数解释**： 告警模板的名称。 **约束限制**： 不涉及。 **取值范围**： 以字母或汉字开头，可包含字母、数字、汉字、_、-，长度为[1,128]个字符。           **默认取值**： 不涉及。 

        :param template_name: The template_name of this CreateAlarmTemplateRequestBody.
        :type template_name: str
        """
        self._template_name = template_name

    @property
    def template_type(self):
        r"""Gets the template_type of this CreateAlarmTemplateRequestBody.

        **参数解释**： 自定义告警模板类型。 **约束限制**： 不涉及。 **取值范围**： 枚举值。 - 0：指标。 - 2： 事件。           **默认取值**： 0 

        :return: The template_type of this CreateAlarmTemplateRequestBody.
        :rtype: int
        """
        return self._template_type

    @template_type.setter
    def template_type(self, template_type):
        r"""Sets the template_type of this CreateAlarmTemplateRequestBody.

        **参数解释**： 自定义告警模板类型。 **约束限制**： 不涉及。 **取值范围**： 枚举值。 - 0：指标。 - 2： 事件。           **默认取值**： 0 

        :param template_type: The template_type of this CreateAlarmTemplateRequestBody.
        :type template_type: int
        """
        self._template_type = template_type

    @property
    def template_description(self):
        r"""Gets the template_description of this CreateAlarmTemplateRequestBody.

        **参数解释**： 告警模板的描述     **约束限制**： 不涉及。 **取值范围**： 长度范围[0,256]。          **默认取值**： 空字符串。 

        :return: The template_description of this CreateAlarmTemplateRequestBody.
        :rtype: str
        """
        return self._template_description

    @template_description.setter
    def template_description(self, template_description):
        r"""Sets the template_description of this CreateAlarmTemplateRequestBody.

        **参数解释**： 告警模板的描述     **约束限制**： 不涉及。 **取值范围**： 长度范围[0,256]。          **默认取值**： 空字符串。 

        :param template_description: The template_description of this CreateAlarmTemplateRequestBody.
        :type template_description: str
        """
        self._template_description = template_description

    @property
    def is_overwrite(self):
        r"""Gets the is_overwrite of this CreateAlarmTemplateRequestBody.

        **参数解释**： 是否对模板名称已经存在的告警模板进行覆盖。 **约束限制**： 不涉及。 **取值范围**： 布尔值。 - true:覆盖同名告警模板。 - false：不覆盖，新建告警模板。           **默认取值**： false 

        :return: The is_overwrite of this CreateAlarmTemplateRequestBody.
        :rtype: bool
        """
        return self._is_overwrite

    @is_overwrite.setter
    def is_overwrite(self, is_overwrite):
        r"""Sets the is_overwrite of this CreateAlarmTemplateRequestBody.

        **参数解释**： 是否对模板名称已经存在的告警模板进行覆盖。 **约束限制**： 不涉及。 **取值范围**： 布尔值。 - true:覆盖同名告警模板。 - false：不覆盖，新建告警模板。           **默认取值**： false 

        :param is_overwrite: The is_overwrite of this CreateAlarmTemplateRequestBody.
        :type is_overwrite: bool
        """
        self._is_overwrite = is_overwrite

    @property
    def policies(self):
        r"""Gets the policies of this CreateAlarmTemplateRequestBody.

        **参数解释**： 告警模板策略列表。 **约束限制**： 不超过1000个策略。 

        :return: The policies of this CreateAlarmTemplateRequestBody.
        :rtype: list[:class:`huaweicloudsdkces.v2.Policies`]
        """
        return self._policies

    @policies.setter
    def policies(self, policies):
        r"""Sets the policies of this CreateAlarmTemplateRequestBody.

        **参数解释**： 告警模板策略列表。 **约束限制**： 不超过1000个策略。 

        :param policies: The policies of this CreateAlarmTemplateRequestBody.
        :type policies: list[:class:`huaweicloudsdkces.v2.Policies`]
        """
        self._policies = policies

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateAlarmTemplateRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
