

import base64
import time
from io import BytesIO

import cv2

from openai import OpenAI
from pydantic import BaseModel, Field
import logging


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    force=True
)

PROMPT_FRONT = """
Extract ALL fields from this Qatar National ID **front side** image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

    - id_number: The ID number exactly as shown on the card (preserve original format)
    - dob: Date of birth exactly as shown on the card, but always return in DD/MM/YYYY format (e.g., '15/06/1990'). If the card shows a different format, convert it to DD/MM/YYYY.
    - expiry_date: Date of expiry exactly as shown on the card, but always return in DD/MM/YYYY format (e.g., '15/06/1990'). If the card shows a different format, convert it to DD/MM/YYYY.
    - name: Full name in English as printed on the card (extract exactly as written)
    - name_ar: Full name in Arabic as printed on the card (extract exactly as written)
    - first_name: First name extracted from the full name (use the first word from the English name)
    - last_name: Last name extracted from the full name (use the last word from the English name)
    - nationality: Nationality as printed on the card and return ISO 3166-1 alpha-3 code (e.g., QAT)
    - occupation_ar: Occupation in Arabic as printed on the card (extract exactly as written)
    - occupation_en: Translate the Arabic occupation to English (e.g., طالب → Student, عامل → Worker, موظف → Employee)
    - header_verified: Return True if one of the texts present in the image is "State of Qatar" or "Residency Permit"; otherwise False.

Instructions:
    - Do NOT guess or hallucinate any values. If unclear, return empty string.
    - Only use information visible on the card.
    - Return the result as a single JSON object matching the schema above.
"""



PROMPT_BACK = """
Extract ALL fields from this Qatar National ID **back side** image with high accuracy.

Return a JSON object with the following fields (use the exact field names):

- employer: Employer name in Arabic as printed on the card (extract exactly as written)
- employer_en: Translate the Arabic employer name to English 
- passport_number: Passport number as printed on the card (extract exactly as written)
- passport_expiry: Passport expiry date  always in DD/MM/YYYY format.
- back_header_verified: Return True if one of the texts present in the image is "Director General of the General Department" or "Directorate of Passports" or "Passport number" or "Serial"; otherwise False.
- card_number: Serial number exactly as shown on the card (preserve original format)

Instructions:
- Do NOT guess or hallucinate any values. If unclear, return empty string.
- Only use information visible on the card.
- Return the result as a single JSON object matching the schema above.
"""


class QatarFront(BaseModel):
   
    id_number: str = Field(...,min_length=11, max_length=11,
        description = "The ID number exactly as shown on the card (preserve original format)",
    )
    
    dob: str = Field(...,
        description = "The date of birth exactly as shown on the card ((preserve (dd/mm/yyyy) format))",
    )

    expiry_date: str = Field(...,
        description = "The date of expiry exactly as shown on the card (preserve (dd/mm/yyyy) format)",
    )

   
    name: str = Field(...,
                      description="Full name as printed on the card (extract exactly as written on the card)"
                      )

    name_ar: str = Field(...,
                      description="Full name in Arabic as printed on the card (extract exactly as written on the card)"
                      )
    
    first_name: str = Field(...,
        description="First name extracted from full_name",
    )

    last_name: str = Field(...,
        description="Last name extracted from full_name",
    )
    
    nationality: str = Field(...,
                      description="Nationality as printed on the card and return ISO 3166-1 alpha-3, e.g., BGD"
    )

    occupation: str = Field(
        ...,
        description="The occupation in Arabic (extract exactly as written on the card)",
    )

    occupation_en: str = Field(
        ...,
        description="TRANSLATE the Arabic occupation to English (e.g., طالب → Student, عامل → Worker, موظف → Employee)",
    )
    

    header_verified: bool = Field(
        ...,
        description=" Return True if one of the texts present in the image State of Qatar or Residency Permit",
    )
class QatarBack(BaseModel):
    employer: str = Field(...,
        description = "Employer name in Arabic (extract exactly as written on the card) return empty string if not present",
    )

    employer_en: str = Field(...,
        description = "TRANSLATE the Arabic  employer name to English, if employer is not present return empty string",

    )

    passport_number: str = Field(...,
        description = "Passport number  extract exactly as written on the card, return empty string if not present",
    )

    passport_expiry: str = Field(...,
        description = "Passport expiry date exactly as shown on the card (preserve (dd/mm/yyyy) format), return empty string if not present",
    )

    back_header_verified: bool = Field(
        ...,
        description=" Return True if one of the texts present in the image Director General of the General Department or Directorate of Passports or Passport number or Serial else return False",
    )

    card_number: str = Field(...,
        description = "Serial number exactly as shown on the card (preserve original format), return empty string if not present",
    )


def process_image(side):

    if side == "front":
        prompt = PROMPT_FRONT
        model = QatarFront
    
    elif side == "back":
        prompt =  PROMPT_BACK
        model = QatarBack
    
    else:
        raise ValueError("Invalid document side specified. please upload front side of passport'.")

    return model, prompt

def get_openai_response(prompt: str, model_type, image: BytesIO, genai_key):
    b64_image = base64.b64encode(image.getvalue()).decode("utf-8")
    for attempt in range(3):
        try:
            client = OpenAI(api_key=genai_key)
            response = client.responses.parse(
                model="gpt-4.1-mini",
                input=[
                    {"role": "system", "content": "You are an expert at extracting information from identity documents."},
                    {"role": "user", "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_image", "image_url": f"data:image/jpeg;base64,{b64_image}", "detail": "low"},
                    ]},
                ],
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.info(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None

def _image_to_jpeg_bytesio(image) -> BytesIO:
    """
    Accepts: numpy.ndarray (OpenCV BGR), PIL.Image.Image, bytes/bytearray, or io.BytesIO
    Returns: io.BytesIO containing JPEG bytes (ready for get_openai_response)
    """
    import numpy as np

    if isinstance(image, BytesIO):
        image.seek(0)
        return image

    if isinstance(image, (bytes, bytearray)):
        return BytesIO(image)

    try:
        from PIL.Image import Image as _PILImage

        if isinstance(image, _PILImage):
            buf = BytesIO()
            image.convert("RGB").save(buf, format="JPEG", quality=95)
            buf.seek(0)
            return buf
    except Exception:
        pass

    if isinstance(image, np.ndarray):
        success, enc = cv2.imencode(".jpg", image)
        if not success:
            raise ValueError("cv2.imencode failed")
        return BytesIO(enc.tobytes())

    raise TypeError(
        "Unsupported image type. Provide numpy.ndarray, PIL.Image.Image, bytes, or io.BytesIO."
    )

def get_response_from_openai_qat(image, side, country, openai_key):

    logging.info("Processing image for Qatari NID extraction OPENAI......")
    logging.info(f" and type: {type(image)}")
    try:
        image = _image_to_jpeg_bytesio(image)
    except Exception as e:
        logging.error(f"Error encoding image: {e}")
        return {"error": "Image encoding failed"}
    try:
        model, prompt = process_image(side)
        logging.info(f"Using model: {model.__name__} and prompt {prompt[:100]}")
    except ValueError as ve:
        logging.error(f"Error: {ve}")
        return {"error": str(ve)}

    try:
        response = get_openai_response(prompt, model, image, openai_key)
    except Exception as e:
        logging.error(f"Error during OpenAI request: {e}")
        return {"error": "OpenAI request failed"}

    response_data = vars(response)
    logging.info(f"Openai response: {response}")
    return response_data