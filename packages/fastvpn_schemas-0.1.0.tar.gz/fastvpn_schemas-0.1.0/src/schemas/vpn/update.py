from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class VpnAccountUpdate(BaseModel):
    flow: Optional[str] = None
    is_active: Optional[bool] = None

    model_config = ConfigDict(
        extra="forbid",
    )


class VpnAccountAdminUpdate(BaseModel):
    is_active: Optional[bool] = None
    is_trial: Optional[bool] = None
    expires_at: Optional[datetime] = None
    data_limit_bytes: Optional[int] = None
    used_bytes: Optional[int] = None

    model_config = ConfigDict(
        extra="forbid",
    )
