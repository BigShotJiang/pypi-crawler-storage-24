from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class VpnAccountRead(BaseModel):
    id: UUID
    email: str
    is_active: bool
    is_trial: bool
    flow: str
    expires_at: datetime | None
    data_limit_bytes: int
    used_bytes: int

    model_config = ConfigDict(
        from_attributes=True,
    )


class VpnTrafficInfo(BaseModel):
    data_limit_bytes: int
    used_bytes: int

    model_config = ConfigDict(
        from_attributes=True,
    )
