from .base import VpnAccountBase


class VpnAccountCreate(VpnAccountBase):
    is_trial: bool = False
    data_limit_bytes: int = 0
