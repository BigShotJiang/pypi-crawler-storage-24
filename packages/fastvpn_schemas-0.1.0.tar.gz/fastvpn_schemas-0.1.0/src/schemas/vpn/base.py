from pydantic import BaseModel


class VpnAccountBase(BaseModel):
    email: str
    flow: str = "xtls-rprx-version"
