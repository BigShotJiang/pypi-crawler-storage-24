from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class PaymentStatus(str, Enum):
    SUCCESS = "success"
    PENDING = "pending"
    FAILED = "failed"
    REFUNDED = "refunded"


class PaymentBase(BaseModel):
    subscription_id: Optional[UUID] = None
    user_id: int = Field(..., description="Telegram user ID")
    telegram_charge_id: Optional[str] = None
    amount_stars: int = Field(..., ge=0)
    is_recurring: bool = Field(
        False, description="True if this is an automatic renewal payment"
    )
    is_first: bool = Field(
        True, description="True if this is the initial payment for the subscription"
    )
    status: PaymentStatus = PaymentStatus.SUCCESS
    paid_at: Optional[datetime] = None

    model_config = ConfigDict(
        from_attributes=True,
    )
