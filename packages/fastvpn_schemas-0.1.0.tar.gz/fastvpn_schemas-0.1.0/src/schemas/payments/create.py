from typing import Optional

from pydantic import ConfigDict

from .base import PaymentBase, PaymentStatus


class PaymentCreate(PaymentBase):
    telegram_charge_id: Optional[str] = None
    amount_stars: int
    status: PaymentStatus = PaymentStatus.PENDING

    model_config = ConfigDict(
        from_attributes=True,
    )
