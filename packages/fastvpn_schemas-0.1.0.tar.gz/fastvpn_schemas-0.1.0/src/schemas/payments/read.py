from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import Field

from .base import PaymentBase


class PaymentRead(PaymentBase):
    id: UUID = Field(..., description="Internal payment ID")
    created_at: datetime
    updated_at: datetime
    subscription_status: Optional[str] = None

    model_config = {
        "from_attributes": True,
    }
