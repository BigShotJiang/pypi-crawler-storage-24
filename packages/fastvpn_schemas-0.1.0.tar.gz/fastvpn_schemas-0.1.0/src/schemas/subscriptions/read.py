from datetime import datetime
from uuid import UUID

from pydantic import ConfigDict

from .base import SubscriptionBase, SubscriptionStatus


class SubscriptionRead(SubscriptionBase):
    id: UUID
    created_at: datetime
    updated_at: datetime
    status: SubscriptionStatus = SubscriptionStatus.ACTIVE

    model_config = ConfigDict(
        from_attributes=True,
    )
