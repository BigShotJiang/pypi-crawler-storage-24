from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class SubscriptionStatus(str, Enum):
    ACTIVE = "ACTIVE"
    CANCELED = "CANCELED"
    EXPIRED = "EXPIRED"
    GRACE = "GRACE"
    TRIAL = "TRIAL"
    PENDING = "PENDING"
    PAYMENT_FAILED = "PAYMENT_FAILED"


class SubscriptionBase(BaseModel):
    user_id: int
    plan_id: UUID
    telegram_charge_id: Optional[str] = None
    status: SubscriptionStatus = SubscriptionStatus.ACTIVE
    current_period_start: datetime
    current_period_end: datetime
    next_billing_attempt: Optional[datetime] = None
    canceled_at: Optional[datetime] = None

    model_config = ConfigDict(
        from_attributes=True,
    )
