from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict

from src.schemas.subscriptions.base import SubscriptionStatus


class SubscriptionUpdate(BaseModel):
    status: Optional[SubscriptionStatus] = None
    current_period_end: Optional[datetime] = None
    next_billing_attempt: Optional[datetime] = None
    canceled_at: Optional[datetime] = None

    plan_id: Optional[int] = None

    model_config = ConfigDict(
        extra="forbid",
    )
