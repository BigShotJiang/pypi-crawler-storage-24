from typing import Optional

from pydantic import Field

from .base import UserBase


class UserCreate(UserBase):
    password: Optional[str] = None
    pass
