from typing import Optional

from pydantic import BaseModel, Field


class UserUpdate(BaseModel):
    username: Optional[str] = Field(default=None, min_length=3, max_length=32)
    telegram_id: Optional[int] = None
