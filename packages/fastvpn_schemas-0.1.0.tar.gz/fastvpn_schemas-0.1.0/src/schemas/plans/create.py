from pydantic import ConfigDict

from .base import PlanBase


class PlanCreate(PlanBase):
    name: str
    stars_amount: int
    devices_limit: int

    model_config = ConfigDict(
        from_attributes=True,
    )
