from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class PlanUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = None
    stars_amount: Optional[int] = Field(None, ge=0)
    period_days: Optional[int] = Field(None, ge=1, le=365)
    vpn_speed_limit_mbps: Optional[int] = None
    devices_limit: Optional[int] = Field(None, ge=1)
    is_active: Optional[bool] = None

    model_config = ConfigDict(
        extra="forbid",
    )
