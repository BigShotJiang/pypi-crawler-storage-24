from datetime import datetime
from uuid import UUID

from pydantic import ConfigDict

from .base import PlanBase


class PlanRead(PlanBase):
    id: UUID
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(
        from_attributes=True,
    )
