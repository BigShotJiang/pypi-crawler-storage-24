from typing import Optional

from pydantic import BaseModel, ConfigDict


class PlanBase(BaseModel):
    name: str
    description: Optional[str] = None
    stars_amount: int
    period_days: int
    vpn_speed_limit_mbps: Optional[int]
    devices_limit: int
    is_active: bool

    model_config = ConfigDict(
        from_attributes=True,
    )
