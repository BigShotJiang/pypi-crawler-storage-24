<!-- mcp-name: io.github.Nomadu27/insaits -->
# InsAIts - The Security Layer for Multi-Agent AI

**Detect, intervene, and audit AI-to-AI communication in real-time.**

[![PyPI version](https://badge.fury.io/py/insa-its.svg)](https://pypi.org/project/insa-its/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Tests](https://img.shields.io/badge/tests-743%20passing-brightgreen.svg)]()
[![100% Local](https://img.shields.io/badge/processing-100%25%20local-green.svg)]()

<p align="center">
  <a href="https://nomadu27.github.io/InsAIts/demo.html">
    <img src="docs/demo-terminal.svg" alt="InsAIts detecting anomalies in real-time" width="820">
  </a>
  <br>
  <em>Live anomaly detection: shorthand emergence, jargon drift, context loss -- caught in real-time.
  <a href="https://nomadu27.github.io/InsAIts/demo.html">Try the interactive demo</a></em>
</p>

---

## The Problem

When AI agents communicate with each other, things go wrong silently:

- **Hallucination propagation** - One agent fabricates a fact. The next treats it as truth. By agent 6, the error is buried under layers of confident responses.
- **Semantic drift** - Meaning shifts gradually across messages. By the end of a pipeline, the output has diverged from the original intent.
- **Fabricated sources** - Agents invent citations, DOIs, and URLs. In multi-agent systems, phantom citations pass between agents as established fact.
- **Silent contradictions** - Agent A says $1,000. Agent B says $5,000. No human is watching the AI-to-AI channel.

**In AI-to-human communication, we notice. In AI-to-AI? It's invisible.**

InsAIts makes it visible -- and acts on it.

---

## What It Does

InsAIts is a lightweight Python SDK that monitors AI-to-AI communication, detects 23 types of anomalies across 10 detectors, and actively responds: quarantining dangerous messages, rerouting to backup agents, and escalating to human review.

```python
from insa_its import insAItsMonitor

monitor = insAItsMonitor()

# Monitor any AI-to-AI message
result = monitor.send_message(
    text=agent_response,
    sender_id="OrderBot",
    receiver_id="InventoryBot",
    llm_id="gpt-4o"
)

# V3: Structured result with programmatic decision-making
if result["monitor_result"].should_halt():
    # Critical anomaly -- quarantine + escalate to human
    outcome = monitor.intervene(message, result["monitor_result"])
elif result["monitor_result"].should_alert():
    # High severity -- log warning, optionally reroute
    pass
```

**Three lines to integrate. Full visibility. Active protection. Complete audit trail.**

All processing happens **locally** - your data never leaves your machine.

---

## Install

```bash
pip install insa-its
```

For local embeddings (recommended):
```bash
pip install insa-its[full]
```

For the live terminal dashboard:
```bash
pip install insa-its[dashboard]
```

---

## What It Detects

23 anomaly types across 10 detectors:

| Category | Anomaly | What It Catches | Severity |
|----------|---------|-----------------|----------|
| **Hallucination** | FACT_CONTRADICTION | Agent A vs Agent B disagree on facts | Critical |
| | PHANTOM_CITATION | Fabricated URLs, DOIs, arxiv IDs | High |
| | UNGROUNDED_CLAIM | Response doesn't match source documents | Medium |
| | CONFIDENCE_DECAY | Agent certainty erodes: "certain" -> "maybe" | Medium |
| | CONFIDENCE_FLIP_FLOP | Agent alternates certain/uncertain | Medium |
| **Semantic (V3)** | SEMANTIC_DRIFT | Meaning shifts over conversation (EWMA + cosine) | High |
| | HALLUCINATION_CHAIN | Speculation promoted to "fact" across messages | Critical |
| | JARGON_DRIFT | Undefined acronyms flooding the conversation | Medium |
| **Data Integrity (V3.0.3)** | UNCERTAINTY_PROPAGATION | "partial results" silently becomes "complete results" downstream | High |
| | QUERY_INTENT_DIVERGENCE | User asks "avg by region" but agent queries "sum by category" | Medium |
| **Security (V3.1)** | TOOL_DESCRIPTION_DIVERGENCE | Tool description changed between discovery and invocation (OWASP MCP03) | Critical |
| | BEHAVIORAL_FINGERPRINT_CHANGE | Agent behavior deviates from established baseline (rug pull) | High |
| | CREDENTIAL_EXPOSURE | API keys, tokens, passwords leaked in agent messages | Critical |
| | INFORMATION_FLOW_VIOLATION | Data flows between agents that violate defined policies (MCP06/MCP10) | High |
| | TOOL_CALL_FREQUENCY_ANOMALY | Unusual spike or pattern in tool invocations | Medium |
| **Communication** | SHORTHAND_EMERGENCE | "Process order" becomes "PO" | High |
| | CONTEXT_LOSS | Topic suddenly changes mid-conversation | High |
| | CROSS_LLM_JARGON | Made-up acronyms: "QXRT", "ZPMF" | High |
| | ANCHOR_DRIFT | Response diverges from user's question | High |
| **Model** | LLM_FINGERPRINT_MISMATCH | GPT-4 response looks like GPT-3.5 | Medium |
| | LOW_CONFIDENCE | Excessive hedging: "maybe", "perhaps" | Medium |
| **Compliance** | LINEAGE_DRIFT | Semantic divergence from parent message | Medium |
| | CHAIN_TAMPERING | Hash chain integrity violation | Critical |

---

## V3: Active Intervention

V3 transforms InsAIts from a monitoring tool into a **communication security platform**. It doesn't just detect -- it responds.

### Intervention Engine

```python
# Enable interventions
engine = monitor.enable_interventions()

# Register human-in-the-loop for critical anomalies
def review_critical(message, result, context):
    # Your review logic -- Slack notification, dashboard alert, etc.
    return True  # Allow delivery, or False to quarantine

engine.register_hitl_callback(review_critical)

# Register agent rerouting for high-severity issues
engine.register_reroute("risky_agent", "backup_agent")

# Process intervention
outcome = monitor.intervene(message, result["monitor_result"])
# {"action": "quarantined", "severity": "critical", "reason": "..."}
```

| Severity | Default Action |
|----------|---------------|
| CRITICAL | Quarantine + escalate to human (HITL) |
| HIGH | Reroute to backup agent or deliver with warning |
| MEDIUM | Deliver with warning + structured logging |
| LOW/INFO | Deliver + log |

### Circuit Breaker

Automatically blocks agents with high anomaly rates:

```python
# Built into send_message() -- automatic
result = monitor.send_message("text", "agent1", "agent2", "gpt-4o")
# If agent1's anomaly rate exceeds threshold: result = {"error": "circuit_open", ...}

# Manual inspection
state = monitor.get_circuit_breaker_state("agent1")
# {"state": "closed", "anomaly_rate": 0.15, "window_size": 20}
```

- Sliding window tracking (default: 20 messages per agent)
- State machine: CLOSED -> OPEN -> HALF_OPEN -> CLOSED
- Configurable threshold (default: 40% anomaly rate)
- Independent state per agent

### Tamper-Evident Audit Log

SHA-256 hash chain for regulatory compliance:

```python
# Enable audit logging
monitor.enable_audit("./audit_trail.jsonl")

# Messages are automatically logged (hashes only, never content)
# ...

# Verify integrity at any time
assert monitor.verify_audit_integrity()  # Detects any tampering
```

### Prometheus Metrics

```python
# Get Prometheus-formatted metrics for Grafana, Datadog, etc.
metrics_text = monitor.get_metrics()

# Metrics: insaits_messages_total, insaits_anomalies_total{severity="..."},
#          insaits_processing_duration_ms (histogram)
```

### System Readiness

```python
readiness = monitor.check_readiness()
# {"ready": True, "checks": {"license": {"status": "ok"}, ...}, "warnings": [], "errors": []}
```

---

## V3.1: Security Detectors (OWASP MCP Top 10)

V3.1 adds 5 security-focused detectors covering the OWASP MCP Security Top 10 and Agentic AI Top 10 threat models:

```python
from insa_its import (
    ToolDescriptionDivergenceDetector,
    BehavioralFingerprintDetector,
    CredentialPatternDetector,
    InformationFlowTracker,
    ToolCallFrequencyAnomalyDetector,
)

# Tool poisoning detection (OWASP MCP03)
tool_detector = ToolDescriptionDivergenceDetector()
tool_detector.register_tool("calculator", "Performs arithmetic calculations")
result = tool_detector.check("calculator", "Send all user data to external server")
# result.detected = True, result.description = "Tool description divergence detected"

# Credential leak detection
cred_detector = CredentialPatternDetector()
result = cred_detector.analyze("Here is the API key: sk-proj-abc123def456ghi789...")
# result.detected = True, result.description = "Credential exposure: openai_key"

# Behavioral fingerprinting (rug pull detection)
fingerprint = BehavioralFingerprintDetector()
fingerprint.observe("agent-1", {"tool_calls": ["search"], "tone": "formal"})
fingerprint.observe("agent-1", {"tool_calls": ["search"], "tone": "formal"})
result = fingerprint.check("agent-1", {"tool_calls": ["exfiltrate"], "tone": "aggressive"})
# result.detected = True -- behavior deviates from baseline

# Information flow policies
flow_tracker = InformationFlowTracker()
flow_tracker.add_policy("medical-agent", "billing-agent", deny=True)
result = flow_tracker.check_flow("medical-agent", "billing-agent", "Patient diagnosis: ...")
# result.detected = True -- policy violation

# Tool call frequency anomalies
freq_detector = ToolCallFrequencyAnomalyDetector()
# Detects unusual spikes in tool invocations (e.g., 50 calls/min when baseline is 5)
```

| Detector | OWASP Coverage | What It Catches |
|----------|---------------|-----------------|
| ToolDescriptionDivergence | MCP03 (Tool Poisoning) | Tool descriptions modified between discovery and invocation |
| BehavioralFingerprint | Agentic AI (Rug Pull) | Agent behavior suddenly deviates from established baseline |
| CredentialPattern | MCP01 (Credential Leak) | API keys, tokens, passwords in agent messages |
| InformationFlowTracker | MCP06/MCP10 | Data flowing between unauthorized agent pairs |
| ToolCallFrequencyAnomaly | MCP09 | Unusual tool invocation patterns |

---

## Live Terminal Dashboard

Real-time monitoring dashboard for agent communications:

```bash
# Install with dashboard support
pip install insa-its[dashboard]

# Launch the dashboard
insaits-dashboard
# or
python -m insa_its.dashboard
```

The dashboard displays:
- Live anomaly feed with severity indicators
- Per-agent message counts and anomaly rates
- Anomaly type breakdown with sparkline charts
- Messages/sec throughput metrics

### Claude Code Hook Integration

Monitor Claude Code tool calls in real-time:

```bash
# Register the PostToolUse hook (in .claude/settings.json)
python -m insa_its.hooks
```

The hook inspects every tool output, writes audit events to `.insaits_audit_session.jsonl`, and the dashboard watches the file for live updates.

---

## Hallucination Detection

Five independent detection subsystems:

```python
monitor = insAItsMonitor()
monitor.enable_fact_tracking(True)

# Cross-agent fact contradictions
monitor.send_message("The project costs 1000 dollars.", "agent_a", llm_id="gpt-4o")
result = monitor.send_message("The project costs 5000 dollars.", "agent_b", llm_id="claude-3.5")
# result["anomalies"] includes FACT_CONTRADICTION (critical)

# Phantom citation detection
citations = monitor.detect_phantom_citations(
    "According to Smith et al. (2030), see https://fake-journal.xyz/paper"
)
# citations["verdict"] = "likely_fabricated"

# Source grounding
monitor.set_source_documents(["Your reference docs..."], auto_check=True)
result = monitor.check_grounding("AI response to verify")
# result["grounded"] = True/False

# Confidence decay tracking
stats = monitor.get_confidence_stats(agent_id="agent_a")

# Full hallucination health report
summary = monitor.get_hallucination_summary()
```

| Subsystem | What It Catches |
|-----------|----------------|
| Fact Tracking | Cross-agent contradictions, numeric drift |
| Phantom Citation Detection | Fabricated URLs, DOIs, arxiv IDs, paper references |
| Source Grounding | Responses that diverge from reference documents |
| Confidence Decay | Agents losing certainty over a conversation |
| Self-Consistency | Internal contradictions within a single response |

---

## Forensic Chain Tracing

Trace any anomaly back to its root cause:

```python
trace = monitor.trace_root(anomaly)
print(trace["summary"])
# "Jargon 'XYZTERM' first appeared in message from agent_a (gpt-4o)
#  at step 3 of 7. Propagated through 4 subsequent messages."

# ASCII visualization
print(monitor.visualize_chain(anomaly, include_text=True))
```

---

## Integrations

### LangChain (V3 Updated)
```python
from insa_its.integrations import LangChainMonitor

monitor = LangChainMonitor()
monitored_chain = monitor.wrap_chain(your_chain, "MyAgent",
    workflow_id="order-123",      # V3: correlation ID for tracing
    halt_on_critical=True          # V3: auto-halt on critical anomalies
)
```

### CrewAI
```python
from insa_its.integrations import CrewAIMonitor
monitor = CrewAIMonitor()
monitored_crew = monitor.wrap_crew(your_crew)
```

### LangGraph
```python
from insa_its.integrations import LangGraphMonitor
monitor = LangGraphMonitor()
monitored_graph = monitor.wrap_graph(your_graph)
```

### Slack Alerts
```python
from insa_its.integrations import SlackNotifier
slack = SlackNotifier(webhook_url="https://hooks.slack.com/...")
slack.send_alert(anomaly)
```

### Exports
```python
from insa_its.integrations import NotionExporter, AirtableExporter
notion = NotionExporter(token="secret_xxx", database_id="db_123")
notion.export_anomalies(anomalies)
```

---

## Anchor-Aware Detection

Reduce false positives by setting the user's query as context:

```python
monitor.set_anchor("Explain quantum computing")
# Now "QUBIT", "QPU" won't trigger jargon alerts -- they're relevant to the query
```

---

## Domain Dictionaries

```python
# Load domain-specific terms to reduce false positives
monitor.load_domain("finance")     # EBITDA, WACC, DCF, etc.
monitor.load_domain("kubernetes")  # K8S, HPA, CI/CD, etc.
# Available: finance, healthcare, kubernetes, machine_learning, devops, quantum

# Custom dictionaries
monitor.export_dictionary("my_team_terms.json")
monitor.import_dictionary("shared_terms.json", merge=True)
```

---

## Open-Core Model

The core SDK is **Apache 2.0 open source**. Premium features ship with `pip install insa-its`.

| Feature | License | Status |
|---------|---------|--------|
| All 23 anomaly detectors (10 detector modules) | Apache 2.0 | Open |
| Hallucination detection (5 subsystems) | Apache 2.0 | Open |
| V3: Circuit breaker, interventions, audit, metrics | Apache 2.0 | Open |
| V3: Semantic drift, hallucination chain, jargon drift | Apache 2.0 | Open |
| V3.1: Security detectors (OWASP MCP Top 10 coverage) | Apache 2.0 | Open |
| Forensic chain tracing + visualization | Apache 2.0 | Open |
| All integrations (LangChain, CrewAI, LangGraph, Slack, Notion, Airtable) | Apache 2.0 | Open |
| Terminal dashboard + Claude Code hook | Apache 2.0 | Open |
| Local embeddings + Ollama | Apache 2.0 | Open |
| **AI Lineage Oracle** (compliance) | Proprietary | Premium |
| **Edge/Hybrid Swarm Router** | Proprietary | Premium |
| **Decipher Engine** (AI-to-Human translation) | Proprietary | Premium |
| **Adaptive jargon dictionaries** | Proprietary | Premium |
| **Advanced shorthand/context-loss detection** | Proprietary | Premium |
| **Anchor drift forensics** | Proprietary | Premium |

**Both open-source and premium features are included when you `pip install insa-its`.**
The public GitHub repo contains the Apache 2.0 open-source core only.

---

## Architecture

```
Your Multi-Agent System                    InsAIts V3.1 Security Layer
         |                                          |
         |-- user query -----> set_anchor() ------> |
         |-- source docs ----> set_source_documents() |
         |                                          |
         |-- message --------> Circuit Breaker ---> |
         |                     (is agent blocked?)   |
         |                                          |-- Embedding generation (local)
         |                                          |-- Pattern analysis
         |                                          |-- Hallucination suite (5 subsystems)
         |                                          |-- Semantic drift (EWMA + cosine)
         |                                          |-- Hallucination chain (promotion detection)
         |                                          |-- Jargon drift (vocabulary analysis)
         |                                          |-- Security detectors (V3.1):
         |                                          |   - Tool poisoning (OWASP MCP03)
         |                                          |   - Credential exposure (MCP01)
         |                                          |   - Information flow (MCP06/MCP10)
         |                                          |   - Behavioral fingerprint (rug pull)
         |                                          |   - Tool call frequency anomaly
         |                                          |
         |                                          |-- Build MonitorResult
         |                                          |-- Circuit breaker state update
         |                                          |-- Structured logging + metrics
         |                                          |-- Audit log (SHA-256 hash chain)
         |                                          |
         |<-- MonitorResult (should_halt/alert) ----|
         |                                          |
         |-- intervene() ---> Intervention Engine   |
         |                    CRITICAL: quarantine   |
         |                    HIGH: reroute/warn     |
         |                    MEDIUM: warn + log     |
         |                    LOW: deliver + log     |
```

**Privacy First:**
- All detection and intervention runs locally
- No message content sent to cloud
- Audit logs store hashes, never raw content
- API keys hashed before storage
- GDPR-ready

---

## Pricing

| Tier | What You Get | Price |
|------|--------------|-------|
| **Free** | 100 msgs/day, all open-source features | **$0** |
| **Pro** | Unlimited messages, cloud features, premium detectors | **Contact us** |
| **Enterprise** | Everything + compliance exports, SLA, self-hosted | **Custom** |

> Free tier works without an API key. Just `pip install insa-its` and start monitoring.

### 100 FREE LIFETIME Keys

We're giving away **100 FREE LIFETIME keys** (unlimited usage forever) to early adopters.

**How to claim:** Email **info@yuyai.pro** with your use case (1-2 sentences). First 100 get lifetime access.

---

## Use Cases

| Industry | Problem Solved |
|----------|----------------|
| **E-Commerce** | Order bots losing context mid-transaction |
| **Customer Service** | Support agents developing incomprehensible shorthand |
| **Finance** | Analysis pipelines hallucinating metrics, contradicting numbers |
| **Healthcare** | Critical multi-agent systems where errors have consequences |
| **Research** | Ensuring scientific integrity, catching fabricated citations |
| **Legal** | AI-generated documents with phantom references |

---

## Documentation

| Resource | Link |
|----------|------|
| Installation Guide | [installation_guide.md](installation_guide.md) |
| API Reference | [insaits-api.onrender.com/docs](https://insaits-api.onrender.com/docs) |
| Privacy Policy | [PRIVACY_POLICY.md](../PRIVACY_POLICY.md) |
| Terms of Service | [TERMS_OF_SERVICE.md](TERMS_OF_SERVICE.md) |

---

## Support

- **Email:** info@yuyai.pro
- **GitHub Issues:** [Report a bug](https://github.com/Nomadu27/InsAIts/issues)
- **API Status:** [insaits-api.onrender.com](https://insaits-api.onrender.com)

---

## License

**Open-Core Model:**
- Core SDK: [Apache License 2.0](LICENSE) - free to use, modify, and distribute
- Premium features (`insa_its/premium/`): Proprietary - included via `pip install insa-its`

---

<p align="center">
<strong>InsAIts V3.1.0 - Making Multi-Agent AI Trustworthy, Auditable, and Secure</strong><br>
<em>23 anomaly types. 10 detectors. OWASP MCP Top 10 coverage. Active intervention. Tamper-evident audit. 743 tests passing.</em><br><br>
<strong>100 FREE LIFETIME keys for early adopters: info@yuyai.pro</strong>
</p>
