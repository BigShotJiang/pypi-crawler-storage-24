"""
InsAIts Hooks Package
=====================
Claude Code integration hooks for InsAIts AI Monitor.

- claude_code_hook: PreToolUse/PostToolUse hook that inspects tool
  inputs and outputs for anomalies.
"""

from .claude_code_hook import main as run_hook

__all__ = ["run_hook"]
