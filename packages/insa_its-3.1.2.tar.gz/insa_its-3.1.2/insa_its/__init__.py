"""
insAIts SDK - pip install insa-its
Multi-LLM Agent Communication Monitoring & Hallucination Detection

Open-core model: Apache 2.0 open-source core + proprietary features via PyPI.

Open-source features (FREE - available on GitHub):
- Real-time anomaly detection (fingerprint mismatch, low confidence)
- LLM fingerprint validation
- Hallucination detection (fact tracking, source grounding,
  phantom citation detection, confidence decay tracking)
- Cross-agent contradiction detection (unique to InsAIts)
- Forensic chain tracing (trace anomalies back to root cause)
- Anchor-aware context tracking
- Terminal dashboard for live monitoring
- LangChain, CrewAI, LangGraph, Slack integrations
- Local embeddings (sentence-transformers) + cloud embeddings
- Configurable Ollama model selection

Proprietary features (pip install only - not on GitHub):
- Edge/Hybrid Swarm Routing with automatic failover (V2.5)
- AI Lineage Oracle for compliance tracking (V2.5)
- Advanced anomaly detection (shorthand emergence, jargon, context loss)
- Decipher engine (translate AI-to-AI communication, cloud + local)
- Anchor drift detection + false-positive suppression
- Adaptive jargon dictionary with domain-specific knowledge
- Dictionary import/export/auto-expand

Contact: info@yuyai.pro for Lifetime access
"""

from .monitor import insAItsMonitor
from .detector import AnomalyDetector, Anomaly
from .license import LicenseManager, get_license_manager
from .config import FREE_TIER_LIMITS, FEATURES, get_feature
from .exceptions import (
    insAItsError,
    RateLimitError,
    APIError,
    AuthenticationError,
    EmbeddingError,
    HallucinationError,
    PremiumFeatureError,
)
from .hallucination import (
    FactTracker,
    SourceGrounder,
    SelfConsistencyChecker,
    PhantomCitationDetector,
    ConfidenceDecayTracker,
    FactClaim,
)
from .local_llm import set_default_model, get_default_model

# V3: Production hardening + advanced detectors
from .models import AnomalyResult, MonitorResult, Severity
from .readiness import ReadinessChecker
from .circuit_breaker import AgentCircuitBreaker
from .interventions import InterventionEngine
from .metrics import MetricsCollector
from .audit import AuditLogger as SdkAuditLogger
from .structured_logging import StructuredLogger
from .detectors import (
    SemanticDriftDetector,
    HallucinationChainDetector,
    JargonDriftDetector,
    DriftResult,
    UncertaintyPropagationDetector,
    QueryIntentDetector,
    ToolDescriptionDivergenceDetector,
    BehavioralFingerprintDetector,
    CredentialPatternDetector,
    InformationFlowTracker,
    ToolCallFrequencyAnomalyDetector,
)

# Edge Router (NEW in 2.5) - Proprietary feature
# Available via pip install, not on public GitHub
EDGE_ROUTER_AVAILABLE = False
EdgeRouter = None
EmbeddingRouter = None
PrivacyMode = None
NodeType = None
NodeHealth = None
create_router = None
get_privacy_modes = None
try:
    from .edge_router import (
        EdgeRouter,
        EmbeddingRouter,
        PrivacyMode,
        NodeType,
        NodeHealth,
        create_router,
        get_privacy_modes,
    )
    EDGE_ROUTER_AVAILABLE = True
except ImportError:
    pass

# Lineage Oracle (NEW in 2.5) - Proprietary feature
# Available via pip install, not on public GitHub
LINEAGE_ORACLE_AVAILABLE = False
LineageOracle = None
LineageRecord = None
LineageAnomaly = None
LineageStatus = None
try:
    from .lineage_oracle import (
        LineageOracle,
        LineageRecord,
        LineageAnomaly,
        LineageStatus,
    )
    LINEAGE_ORACLE_AVAILABLE = True
except ImportError:
    pass

# Premium availability flag
PREMIUM_AVAILABLE = False
try:
    from .premium import PREMIUM_AVAILABLE
except ImportError:
    pass

# Dashboard (requires: pip install textual)
try:
    from .dashboard import InsAItsDashboard, DASHBOARD_AVAILABLE
except ImportError:
    DASHBOARD_AVAILABLE = False
    InsAItsDashboard = None

# Legacy dashboard aliases
LiveDashboard = InsAItsDashboard
SimpleDashboard = None
create_dashboard = None

# V3: AI-Targeted Intervention Monitor (NEW in 3.0)
from .ai_monitor import (
    AIMonitor,
    ClaudeCodeMonitor,
    AIAnomaly,
    AIMonitorResult,
    AnomalyType,
    AISeverity,
    InterventionAction,
    AIInterventionEngine,
    monitored,
)

# V3: MCP Server (requires: pip install mcp)
MCP_SERVER_AVAILABLE = False
try:
    from .mcp import MCP_AVAILABLE as MCP_SERVER_AVAILABLE
except ImportError:
    pass

# V3: Claude Code Hook
try:
    from .hooks import run_hook
    HOOK_AVAILABLE = True
except ImportError:
    HOOK_AVAILABLE = False
    run_hook = None

__version__ = "3.1.2"
__all__ = [
    # Core
    "insAItsMonitor",
    "AnomalyDetector",
    "Anomaly",
    "LicenseManager",
    "get_license_manager",
    # Config
    "FREE_TIER_LIMITS",
    "FEATURES",
    "get_feature",
    # Exceptions
    "insAItsError",
    "RateLimitError",
    "APIError",
    "AuthenticationError",
    "EmbeddingError",
    "HallucinationError",
    "PremiumFeatureError",
    # Hallucination Detection
    "FactTracker",
    "SourceGrounder",
    "SelfConsistencyChecker",
    "PhantomCitationDetector",
    "ConfidenceDecayTracker",
    "FactClaim",
    # Local LLM
    "set_default_model",
    "get_default_model",
    # V3: Models + Production Hardening
    "AnomalyResult",
    "MonitorResult",
    "Severity",
    "ReadinessChecker",
    "AgentCircuitBreaker",
    "InterventionEngine",
    "MetricsCollector",
    "SdkAuditLogger",
    "StructuredLogger",
    # V3: Advanced Detectors
    "SemanticDriftDetector",
    "HallucinationChainDetector",
    "JargonDriftDetector",
    "DriftResult",
    "UncertaintyPropagationDetector",
    "QueryIntentDetector",
    # V3.1: Security Detectors
    "ToolDescriptionDivergenceDetector",
    "BehavioralFingerprintDetector",
    "CredentialPatternDetector",
    "InformationFlowTracker",
    "ToolCallFrequencyAnomalyDetector",
    # Edge Router (NEW in 2.5) - Proprietary
    "EdgeRouter",
    "EmbeddingRouter",
    "PrivacyMode",
    "NodeType",
    "NodeHealth",
    "create_router",
    "get_privacy_modes",
    "EDGE_ROUTER_AVAILABLE",
    # Lineage Oracle (NEW in 2.5) - Proprietary
    "LineageOracle",
    "LineageRecord",
    "LineageAnomaly",
    "LineageStatus",
    "LINEAGE_ORACLE_AVAILABLE",
    # Premium
    "PREMIUM_AVAILABLE",
    # Dashboard
    "InsAItsDashboard",
    "LiveDashboard",
    "SimpleDashboard",
    "create_dashboard",
    "DASHBOARD_AVAILABLE",
    # Hook
    "HOOK_AVAILABLE",
    # V3: AI-Targeted Intervention Monitor
    "AIMonitor",
    "ClaudeCodeMonitor",
    "AIAnomaly",
    "AIMonitorResult",
    "AnomalyType",
    "AISeverity",
    "InterventionAction",
    "AIInterventionEngine",
    "monitored",
]