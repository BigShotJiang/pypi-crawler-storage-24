# openmmm

Work in progress. More details coming soon.

## Installation

```bash
pip install openmmm
```
