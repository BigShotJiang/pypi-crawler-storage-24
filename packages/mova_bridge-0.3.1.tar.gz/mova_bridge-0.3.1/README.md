# MOVA Bridge

A thin MCP client that connects any MCP-compatible agent (OpenClaw, Claude Code) to the MOVA contract execution platform.

The bridge contains zero contracts, policies, or runtime logic — it is a pure HTTP client over the MOVA API.

## Requirements

- Python 3.11+
- A MOVA API key — get one at https://mova.dev/keys

## Install

```bash
pip install mova-bridge
```

Or from source:

```bash
git clone ...
cd mova-bridge
pip install -e .
```

## Connect with OpenClaw

```bash
export MOVA_API_KEY=your_key_here
claw mcp add mova python -m mova_bridge
```

Then load the skill:

```bash
claw skill load SKILL.md
```

## Connect with Claude Code

```bash
export MOVA_API_KEY=your_key_here
claude mcp add mova python -m mova_bridge
```

## Connect with any MCP client

The server runs over stdio. Start it with:

```bash
MOVA_API_KEY=your_key python -m mova_bridge
```

## Environment variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MOVA_API_KEY` | Yes | — | Your MOVA API key |
| `MOVA_API_URL` | No | `https://mova-api.fly.dev` | Override API base URL (e.g. for self-hosted) |

## Available tools

| Tool | Description |
|------|-------------|
| `mova_list_contracts` | List available contracts, filter by domain or keyword |
| `mova_get_contract` | Full contract details including required inputs |
| `mova_price_estimate` | Cost estimate before execution |
| `mova_execute` | Execute a contract (billed on success) |
| `mova_get_episode` | Retrieve full audit trail by episode ID |
| `mova_list_episodes` | Browse execution history for your org |
| `mova_usage` | Spend and execution statistics |

## Testing without a key

Every tool returns a clear error pointing to https://mova.dev/keys when `MOVA_API_KEY` is unset:

```json
{"ok": false, "error": "MOVA_API_KEY is not set. Get your key at https://mova.dev/keys"}
```
