from setuptools import setup, find_packages

setup(
    name='winhelper',
    version='0.1.0',
    packages=find_packages(),
    package_data={
        'winhelper_common': ['data/*.json'],  # включаем все json из папки data
    },
    include_package_data=True,
    description='Common system utilities for developers',
    author='WinHelper Team',
    author_email='support@winhelper.com',
    install_requires=[],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: Microsoft :: Windows',
    ],
)