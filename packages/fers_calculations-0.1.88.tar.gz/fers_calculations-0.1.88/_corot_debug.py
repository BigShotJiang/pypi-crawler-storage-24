import numpy as np

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L = 1000.0; P = 1000.0

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((14, 14))
    ea_l = E*A/L
    k[0,0] = ea_l; k[7,7] = ea_l; k[0,7] = k[7,0] = -ea_l
    eiz = E*Iz; l2=L*L; l3=l2*L
    k[1,1] = 12*eiz/l3;  k[1,5] = k[5,1] = 6*eiz/l2
    k[1,8] = k[8,1] = -12*eiz/l3; k[1,12] = k[12,1] = 6*eiz/l2
    k[5,5] = 4*eiz/L;    k[5,8] = k[8,5] = -6*eiz/l2
    k[5,12] = k[12,5] = 2*eiz/L
    k[8,8] = 12*eiz/l3;  k[8,12] = k[12,8] = -6*eiz/l2
    k[12,12] = 4*eiz/L
    eiy = E*Iy
    k[2,2] = 12*eiy/l3;  k[2,4] = k[4,2] = -6*eiy/l2
    k[2,9] = k[9,2] = -12*eiy/l3; k[2,11] = k[11,2] = -6*eiy/l2
    k[4,4] = 4*eiy/L;    k[4,9] = k[9,4] = 6*eiy/l2
    k[4,11] = k[11,4] = 2*eiy/L
    k[9,9] = 12*eiy/l3;  k[9,11] = k[11,9] = 6*eiy/l2
    k[11,11] = 4*eiy/L
    gj_l = G*J/L
    k[3,3] = gj_l; k[10,10] = gj_l; k[3,10] = k[10,3] = -gj_l
    k[6,6] = 1e-6; k[13,13] = 1e-6
    return k

def build_T(R):
    T = np.zeros((14, 14))
    for node in range(2):
        b = node * 7
        T[b:b+3, b:b+3] = R
        T[b+3:b+6, b+3:b+6] = R
        T[b+6, b+6] = 1.0
    return T

def rot_vec_from_mat(R):
    tr = np.trace(R)
    cos_t = np.clip((tr - 1) / 2, -1, 1)
    theta = np.arccos(cos_t)
    if theta < 1e-12:
        return np.zeros(3)
    if np.pi - theta < 1e-6:
        S = R + np.eye(3)
        best = S[:, np.argmax(np.linalg.norm(S, axis=0))]
        best = best / np.linalg.norm(best)
        return best * theta
    axis = np.array([R[2,1]-R[1,2], R[0,2]-R[2,0], R[1,0]-R[0,1]])
    return axis * theta / (2 * np.sin(theta))

def rodrigues(v_from, v_to):
    c = float(v_from @ v_to)
    s_vec = np.cross(v_from, v_to)
    s = np.linalg.norm(s_vec)
    if s < 1e-12:
        if c > 0: return np.eye(3)
        perp = np.cross(np.array([1,0,0.]) if abs(v_from[0]) < 0.9 else np.array([0,1,0.]), v_from)
        perp = perp / np.linalg.norm(perp)
        return 2*np.outer(perp, perp) - np.eye(3)
    k = s_vec / s
    K = np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    return np.eye(3) + K*s + K@K*(1-c)

R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)
members_data = [
    (R1, np.array([0,0,0.]),    np.array([1000,0,0.])),
    (R2, np.array([1000,0,0.]), np.array([1000,1000,0.])),
    (R3, np.array([1000,1000,0.]), np.array([1000,1000,1000.])),
]
dof_map = [(list(range(0,7)), list(range(7,14))),
           (list(range(7,14)), list(range(14,21))),
           (list(range(14,21)), list(range(21,28)))]

ndof = 28; free = list(range(7, 28))
F_full = np.zeros(ndof); F_full[22] = -P
k_local = beam_k_local(E, G, A, Iy, Iz, J, L)

# First-order solution
K0 = np.zeros((ndof, ndof))
for (R_orig, _, _), (d1, d2) in zip(members_data, dof_map):
    T = build_T(R_orig)
    kg = T.T @ k_local @ T
    dofs = d1 + d2
    for i in range(14):
        for j in range(14):
            K0[dofs[i], dofs[j]] += kg[i, j]
u_1st = np.zeros(ndof)
u_1st[free] = np.linalg.solve(K0[np.ix_(free, free)], F_full[free])

# Check: K_elastic * u_1st should equal F (at free DOFs)
F_check = K0 @ u_1st
print("K_elastic * u_1st at free DOFs vs F:")
for i in free:
    if abs(F_check[i] - F_full[i]) > 0.01:
        print(f"  DOF {i}: K*u={F_check[i]:.4f}  F={F_full[i]:.4f}  diff={F_check[i]-F_full[i]:.6f}")

# Now compute corotational F_int at u_1st
print("\n=== Corotational F_int at FULL first-order solution ===")
f_int = np.zeros(ndof)
for mid, ((R_orig, p1, p2), (d1, d2)) in enumerate(zip(members_data, dof_map)):
    u_mem = np.zeros(14)
    for i in range(7):
        u_mem[i] = u_1st[d1[i]]
        u_mem[7+i] = u_1st[d2[i]]
    
    l_orig = np.linalg.norm(p2 - p1)
    x_orig = (p2 - p1) / l_orig
    p1_def = p1 + u_mem[0:3]
    p2_def = p2 + u_mem[7:10]
    l_def = np.linalg.norm(p2_def - p1_def)
    x_def = (p2_def - p1_def) / l_def
    R_chord = rodrigues(x_orig, x_def)
    R_def = R_orig @ R_chord.T
    T_def = build_T(R_def)
    omega = rot_vec_from_mat(R_chord)
    
    theta1_global = u_mem[3:6]
    theta2_global = u_mem[10:13]
    theta1_def_global = theta1_global - omega
    theta2_def_global = theta2_global - omega
    theta1_def_local = R_def @ theta1_def_global
    theta2_def_local = R_def @ theta2_def_global
    
    d_local = np.zeros(14)
    d_local[3:6] = theta1_def_local
    d_local[6] = u_mem[6]
    du_trans = u_mem[7:10] - u_mem[0:3]
    d_local[7] = x_orig @ du_trans
    d_local[10:13] = theta2_def_local
    d_local[13] = u_mem[13]
    
    # Compare with T_orig * u_mem
    T_orig = build_T(R_orig)
    u_local_orig = T_orig @ u_mem
    
    print(f'\nMember {mid+1}: l_def-l_orig={l_def-l_orig:.4f} chord_angle={np.degrees(np.arccos(np.clip(x_orig@x_def,-1,1))):.4f}deg')
    print(f'  omega = {omega}')
    print(f'  d_corot = {d_local[:7]}')
    print(f'  u_local = {u_local_orig[:7]}')
    print(f'  d_corot2= {d_local[7:]}')
    print(f'  u_local2= {u_local_orig[7:]}')
    
    f_local_corot = k_local @ d_local
    f_local_orig = k_local @ u_local_orig
    print(f'  f_corot  = {f_local_corot[:7]}')
    print(f'  f_orig   = {f_local_orig[:7]}')
    print(f'  f_corot2 = {f_local_corot[7:]}')
    print(f'  f_orig2  = {f_local_orig[7:]}')
    
    f_global_corot = T_def.T @ f_local_corot
    f_global_orig = T_orig.T @ f_local_orig
    
    for i in range(7):
        f_int[d1[i]] += f_global_corot[i]
        f_int[d2[i]] += f_global_corot[7+i]

print(f'\nF_int_corot at free DOFs:')
for i in free:
    if abs(f_int[i]) > 0.01 or abs(F_full[i]) > 0.01:
        diff = f_int[i] - F_full[i]
        print(f'  DOF {i}: F_int={f_int[i]:.4f}  F_ext={F_full[i]:.4f}  residual={diff:.4f}')

r = f_int[free] - F_full[free]
print(f'\n||residual|| / ||F|| = {np.linalg.norm(r) / np.linalg.norm(F_full[free]):.6f}')
