import numpy as np

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L = 1000.0; P = 1000.0

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((14, 14))
    ea_l = E*A/L
    k[0,0] = ea_l; k[7,7] = ea_l; k[0,7] = k[7,0] = -ea_l
    eiz = E*Iz; l2=L*L; l3=l2*L
    k[1,1] = 12*eiz/l3;  k[1,5] = k[5,1] = 6*eiz/l2
    k[1,8] = k[8,1] = -12*eiz/l3; k[1,12] = k[12,1] = 6*eiz/l2
    k[5,5] = 4*eiz/L;    k[5,8] = k[8,5] = -6*eiz/l2
    k[5,12] = k[12,5] = 2*eiz/L
    k[8,8] = 12*eiz/l3;  k[8,12] = k[12,8] = -6*eiz/l2
    k[12,12] = 4*eiz/L
    eiy = E*Iy
    k[2,2] = 12*eiy/l3;  k[2,4] = k[4,2] = -6*eiy/l2
    k[2,9] = k[9,2] = -12*eiy/l3; k[2,11] = k[11,2] = -6*eiy/l2
    k[4,4] = 4*eiy/L;    k[4,9] = k[9,4] = 6*eiy/l2
    k[4,11] = k[11,4] = 2*eiy/L
    k[9,9] = 12*eiy/l3;  k[9,11] = k[11,9] = 6*eiy/l2
    k[11,11] = 4*eiy/L
    gj_l = G*J/L
    k[3,3] = gj_l; k[10,10] = gj_l; k[3,10] = k[10,3] = -gj_l
    k[6,6] = 1e-6; k[13,13] = 1e-6
    return k

def build_T(R):
    T = np.zeros((14, 14))
    for node in range(2):
        b = node * 7
        T[b:b+3, b:b+3] = R
        T[b+3:b+6, b+3:b+6] = R
        T[b+6, b+6] = 1.0
    return T

def rot_vec_from_mat(R):
    tr = np.trace(R)
    cos_t = np.clip((tr - 1) / 2, -1, 1)
    theta = np.arccos(cos_t)
    if theta < 1e-12:
        return np.zeros(3)
    if np.pi - theta < 1e-6:
        S = R + np.eye(3)
        best = S[:, np.argmax(np.linalg.norm(S, axis=0))]
        best = best / np.linalg.norm(best)
        return best * theta
    axis = np.array([R[2,1]-R[1,2], R[0,2]-R[2,0], R[1,0]-R[0,1]])
    return axis * theta / (2 * np.sin(theta))

def rodrigues(v_from, v_to):
    c = float(v_from @ v_to)
    s_vec = np.cross(v_from, v_to)
    s = np.linalg.norm(s_vec)
    if s < 1e-12:
        if c > 0:
            return np.eye(3)
        perp = np.cross(np.array([1,0,0.]) if abs(v_from[0]) < 0.9 else np.array([0,1,0.]), v_from)
        perp = perp / np.linalg.norm(perp)
        return 2*np.outer(perp, perp) - np.eye(3)
    k = s_vec / s
    K = np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    return np.eye(3) + K*s + K@K*(1-c)

R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)
members = [
    (R1, np.array([0,0,0.]),    np.array([1000,0,0.])),
    (R2, np.array([1000,0,0.]), np.array([1000,1000,0.])),
    (R3, np.array([1000,1000,0.]), np.array([1000,1000,1000.])),
]
dof_map = [(list(range(0,7)), list(range(7,14))),
           (list(range(7,14)), list(range(14,21))),
           (list(range(14,21)), list(range(21,28)))]

ndof = 28; free = list(range(7, 28))
F_full = np.zeros(ndof); F_full[22] = -P
k_local = beam_k_local(E, G, A, Iy, Iz, J, L)

def extract_corot(R_orig, p1_orig, p2_orig, u_mem):
    l_orig = np.linalg.norm(p2_orig - p1_orig)
    x_orig = (p2_orig - p1_orig) / l_orig
    p1_def = p1_orig + u_mem[0:3]
    p2_def = p2_orig + u_mem[7:10]
    l_def = np.linalg.norm(p2_def - p1_def)
    if l_def < 1e-12:
        l_def = 1e-12
    x_def = (p2_def - p1_def) / l_def
    R_chord = rodrigues(x_orig, x_def)
    R_def = R_orig @ R_chord.T
    T_def = build_T(R_def)
    omega = rot_vec_from_mat(R_chord)
    theta1_def_local = R_def @ (u_mem[3:6] - omega)
    theta2_def_local = R_def @ (u_mem[10:13] - omega)
    d_local = np.zeros(14)
    d_local[3:6] = theta1_def_local
    d_local[6] = u_mem[6]
    # Use projection onto original direction for axial (avoids EA stiffness coupling)
    du_trans = u_mem[7:10] - u_mem[0:3]
    d_local[7] = x_orig @ du_trans  # projection
    d_local[10:13] = theta2_def_local
    d_local[13] = u_mem[13]
    return d_local, T_def

def corot_Fint(u_full):
    f_int = np.zeros(ndof)
    for (R_orig, p1, p2), (d1, d2) in zip(members, dof_map):
        u_mem = np.zeros(14)
        for i in range(7):
            u_mem[i] = u_full[d1[i]]
            u_mem[7+i] = u_full[d2[i]]
        d_local, T_def = extract_corot(R_orig, p1, p2, u_mem)
        f_local = k_local @ d_local
        f_global = T_def.T @ f_local
        for i in range(7):
            f_int[d1[i]] += f_global[i]
            f_int[d2[i]] += f_global[7+i]
    return f_int

K0 = np.zeros((ndof, ndof))
for (R_orig, _, _), (d1, d2) in zip(members, dof_map):
    T = build_T(R_orig)
    kg = T.T @ k_local @ T
    dofs = d1 + d2
    for i in range(14):
        for j in range(14):
            K0[dofs[i], dofs[j]] += kg[i, j]

u_1st = np.zeros(ndof)
u_1st[free] = np.linalg.solve(K0[np.ix_(free, free)], F_full[free])
print(f'1st-order: rx_n2={u_1st[10]:.6f} dy_n4={u_1st[22]:.2f} dz_n4={u_1st[23]:.2f}')

n_steps = 50
u = np.zeros(ndof)
K_ff = K0[np.ix_(free, free)]
tol = 1e-6

for step in range(1, n_steps+1):
    lam = step / n_steps
    F_lam = F_full * lam
    F_norm = max(np.linalg.norm(F_lam[free]), 1.0)
    
    for it in range(100):
        f_int = corot_Fint(u)
        r_free = f_int[free] - F_lam[free]
        res = np.linalg.norm(r_free) / F_norm
        if res < tol:
            break
        du = np.linalg.solve(K_ff, -r_free)
        # Line search
        alpha = 1.0
        accepted = False
        for _ in range(15):
            u_trial = u.copy()
            u_trial[free] += alpha * du
            f_trial = corot_Fint(u_trial)
            r_trial = f_trial[free] - F_lam[free]
            res_trial = np.linalg.norm(r_trial) / F_norm
            if res_trial < res:
                u[free] = u_trial[free]
                accepted = True
                break
            alpha *= 0.5
        if not accepted:
            u[free] += alpha * du
    
    if step in (1,5,10,25,50) or (step <= 3):
        print(f'Step {step:2d} (l={lam:.2f}): rx={u[10]:.6f} dy4={u[22]:.2f} dz4={u[23]:.2f} res={res:.2e} it={it}')

f_final = corot_Fint(u)
print(f'\nCorot result: rx_n2={u[10]:.6f} dy_n4={u[22]:.2f} dz_n4={u[23]:.2f}')
print(f'Reactions: Fy={f_final[1]:.2f} Mx={-f_final[3]:.0f} Mz={-f_final[5]:.0f}')
Mx_expected = -P * (1000 + u[23])
print(f'Expected Mx = Fy * z_arm = {Mx_expected:.0f} N.mm')
