import numpy as np
from scipy.spatial.transform import Rotation

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L_total = 1000.0; P = 1000.0
N_sub = 4

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((12, 12))
    ea = E*A/L; l2=L*L; l3=l2*L
    k[0,0]=ea; k[6,6]=ea; k[0,6]=k[6,0]=-ea
    eiz = E*Iz
    k[1,1]=12*eiz/l3; k[1,5]=k[5,1]=6*eiz/l2; k[1,7]=k[7,1]=-12*eiz/l3; k[1,11]=k[11,1]=6*eiz/l2
    k[5,5]=4*eiz/L; k[5,7]=k[7,5]=-6*eiz/l2; k[5,11]=k[11,5]=2*eiz/L
    k[7,7]=12*eiz/l3; k[7,11]=k[11,7]=-6*eiz/l2; k[11,11]=4*eiz/L
    eiy = E*Iy
    k[2,2]=12*eiy/l3; k[2,4]=k[4,2]=-6*eiy/l2; k[2,8]=k[8,2]=-12*eiy/l3; k[2,10]=k[10,2]=-6*eiy/l2
    k[4,4]=4*eiy/L; k[4,8]=k[8,4]=6*eiy/l2; k[4,10]=k[10,4]=2*eiy/L
    k[8,8]=12*eiy/l3; k[8,10]=k[10,8]=6*eiy/l2; k[10,10]=4*eiy/L
    gj = G*J/L
    k[3,3]=gj; k[9,9]=gj; k[3,9]=k[9,3]=-gj
    return k

def build_T12(R):
    T = np.zeros((12, 12))
    for n in range(2):
        b = n*6; T[b:b+3,b:b+3] = R; T[b+3:b+6,b+3:b+6] = R
    return T

def rodrigues(v_from, v_to):
    c = float(v_from @ v_to)
    s_vec = np.cross(v_from, v_to)
    s = np.linalg.norm(s_vec)
    if s < 1e-12:
        if c > 0: return np.eye(3)
        perp = np.cross(np.array([1,0,0.]) if abs(v_from[0])<0.9 else np.array([0,1,0.]), v_from)
        perp /= np.linalg.norm(perp)
        return 2*np.outer(perp,perp) - np.eye(3)
    k = s_vec/s; K = np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    return np.eye(3) + K*s + K@K*(1-c)

R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)

n_nodes = 3*N_sub+1; ndof = n_nodes*6; Ls0 = L_total/N_sub
orig_R_list = [R1]*N_sub + [R2]*N_sub + [R3]*N_sub
node_pos = np.zeros((n_nodes, 3))
for i in range(N_sub+1): node_pos[i] = [i*Ls0, 0, 0]
for i in range(1, N_sub+1): node_pos[N_sub+i] = [1000, i*Ls0, 0]
for i in range(1, N_sub+1): node_pos[2*N_sub+i] = [1000, 1000, i*Ls0]
elem_nodes = [(m*N_sub+s, m*N_sub+s+1) for m in range(3) for s in range(N_sub)]

fixed = list(range(6))
free = [i for i in range(ndof) if i not in fixed]
F_full = np.zeros(ndof); F_full[3*N_sub*6+1] = -P

def rotvec_to_mat(rv):
    return Rotation.from_rotvec(rv).as_matrix()

def mat_to_rotvec(R):
    return Rotation.from_matrix(R).as_rotvec()

def corot_fint(u_total):
    """Corotational F_int with PROPER rotation composition via scipy"""
    f_int = np.zeros(ndof)
    
    for e_idx, (ni, nj) in enumerate(elem_nodes):
        p1_orig = node_pos[ni]; p2_orig = node_pos[nj]
        p1_def = p1_orig + u_total[ni*6:ni*6+3]
        p2_def = p2_orig + u_total[nj*6:nj*6+3]
        d_vec = p2_def - p1_def
        l_def = np.linalg.norm(d_vec)
        l_orig = np.linalg.norm(p2_orig - p1_orig)
        x_orig = (p2_orig - p1_orig) / l_orig
        x_def = d_vec / max(l_def, 1e-12)
        
        R_orig = orig_R_list[e_idx]
        Rc = rodrigues(x_orig, x_def)  # chord rotation (orig -> def)
        R_def = R_orig @ Rc.T  # deformed local frame (3x3 local->global)

        # Total nodal rotations as rotation matrices
        theta1_g = u_total[ni*6+3:ni*6+6]
        theta2_g = u_total[nj*6+3:nj*6+6]
        R1_total = rotvec_to_mat(theta1_g)
        R2_total = rotvec_to_mat(theta2_g)
        
        # Rigid body rotation of element (chord rotation applied to orig frame)
        R_rigid = Rc  # rotation from orig chord to def chord
        
        # Deformational rotation: R_deform = R_rigid^T * R_total
        # This removes the rigid body component
        R1_def = R_rigid.T @ R1_total
        R2_def = R_rigid.T @ R2_total
        
        # Convert to rotation vectors (in global frame)
        theta1_def_global = mat_to_rotvec(R1_def)
        theta2_def_global = mat_to_rotvec(R2_def)
        
        # Transform to local frame
        theta1_def_local = R_def @ theta1_def_global
        theta2_def_local = R_def @ theta2_def_global
        
        d_local = np.zeros(12)
        d_local[6] = l_def - l_orig  # axial
        d_local[3:6] = theta1_def_local
        d_local[9:12] = theta2_def_local
        
        kl = beam_k_local(E, G, A, Iy, Iz, J, l_def)
        f_local = kl @ d_local
        T_def = build_T12(R_def)
        f_global = T_def.T @ f_local
        
        dofs_e = [ni*6+d for d in range(6)] + [nj*6+d for d in range(6)]
        for i in range(12):
            f_int[dofs_e[i]] += f_global[i]
    
    return f_int

def build_K_def(u_total):
    """UL tangent: T_def^T * K_local(l_def) * T_def"""
    K = np.zeros((ndof, ndof))
    for e_idx, (ni, nj) in enumerate(elem_nodes):
        p1_def = node_pos[ni] + u_total[ni*6:ni*6+3]
        p2_def = node_pos[nj] + u_total[nj*6:nj*6+3]
        d_vec = p2_def - p1_def
        l_def = np.linalg.norm(d_vec)
        x_orig = (node_pos[nj]-node_pos[ni])/np.linalg.norm(node_pos[nj]-node_pos[ni])
        x_def = d_vec / max(l_def, 1e-12)
        R_orig = orig_R_list[e_idx]
        Rc = rodrigues(x_orig, x_def)
        R_def = R_orig @ Rc.T
        T = build_T12(R_def)
        kl = beam_k_local(E, G, A, Iy, Iz, J, l_def)
        kg = T.T @ kl @ T
        dofs_e = [ni*6+d for d in range(6)] + [nj*6+d for d in range(6)]
        for i in range(12):
            for j in range(12):
                K[dofs_e[i], dofs_e[j]] += kg[i, j]
    return K

# UL + Corotational equilibrium iteration
n_steps = 50
u = np.zeros(ndof)
tol = 1e-6

for step in range(1, n_steps+1):
    lam = step / n_steps
    F_lam = F_full * lam
    F_norm = max(np.linalg.norm(F_lam[free]), 1.0)
    
    # Linear predictor
    K = build_K_def(u)
    dF = F_full / n_steps
    du = np.zeros(ndof)
    du[free] = np.linalg.solve(K[np.ix_(free, free)], dF[free])
    u += du
    
    # N-R equilibrium iteration with corotational F_int
    for it in range(20):
        f_int = corot_fint(u)
        r_full = f_int - F_lam
        r_full[:6] = 0
        res = np.linalg.norm(r_full[free]) / F_norm
        if res < tol:
            break
        K = build_K_def(u)
        corr = np.zeros(ndof)
        corr[free] = np.linalg.solve(K[np.ix_(free, free)], -r_full[free])
        u += corr
    
    if step in (1, 5, 10, 25, 50) or step == n_steps:
        dy = u[3*N_sub*6+1]; dz = u[3*N_sub*6+2]
        print(f'Step {step:2d}: dy4={dy:.2f} dz4={dz:.2f} res={res:.2e} it={it}')

dy = u[3*N_sub*6+1]; dz = u[3*N_sub*6+2]
Mx_arm = -P * (1000 + dz)
print(f'\nUL+Corot NR: dy4={dy:.2f} dz4={dz:.2f} Mx_arm={Mx_arm:.0f}')
print(f'Expected:    dy=-350  dz=347  Mx=-1347000')
