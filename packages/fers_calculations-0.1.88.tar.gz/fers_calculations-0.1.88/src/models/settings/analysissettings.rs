use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
pub enum RigidStrategy {
    /// Serialize as "LINEAR_MPC"; also accept "Linear_MPC" and "linear_mpc"
    #[serde(alias = "Linear_MPC", alias = "linear_mpc")]
    LinearMpc,

    /// Serialize as "RIGID_MEMBER"; also accept "rigid_member"
    #[serde(alias = "rigid_member", alias = "Rigid_Member")]
    RigidMember,
}

/// Python:
/// class AnalysisOrder(Enum):
///     LINEAR = "LINEAR"
///     NONLINEAR = "NONLINEAR"
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "UPPERCASE")]
pub enum AnalysisOrder {
    /// Serialize as "LINEAR"; also accept "Linear" / "linear"
    #[serde(alias = "Linear", alias = "linear")]
    Linear,

    /// Serialize as "NONLINEAR"; also accept "Nonlinear" / "nonlinear"
    #[serde(alias = "Nonlinear", alias = "nonlinear")]
    Nonlinear,
}

/// Controls the nonlinear formulation used for second-order analysis.
///
/// - **PDelta**: Total-Lagrangian P-Δ.  Geometric stiffness is added to the
///   original-frame elastic stiffness. This is the approach used by most
///   commercial solvers (SkyCiv, RFEM "P-Delta").  Accurate for moderate
///   rotations (< ~10°) but increasingly approximate for larger rotations.
///
/// - **Corotational** (default): Load-incremental corotational Newton-Raphson.
///   The element frame tracks the deformed geometry, so internal forces and
///   equilibrium are self-consistent even for large rotations (> 15°).
///   For small rotations the results converge to P-Delta.
///
/// Python:
/// class NonlinearMethod(Enum):
///     P_DELTA = "P_DELTA"
///     COROTATIONAL = "COROTATIONAL"
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema, Default)]
#[serde(rename_all = "UPPERCASE")]
#[allow(non_camel_case_types)]
pub enum NonlinearMethod {
    #[serde(
        alias = "P_Delta",
        alias = "p_delta",
        alias = "PDelta",
        alias = "pdelta"
    )]
    P_DELTA,

    #[serde(
        alias = "Corotational",
        alias = "corotational",
        alias = "COROT",
        alias = "corot"
    )]
    #[default]
    COROTATIONAL,
}

/// Python:
/// class Dimensionality(Enum):
///     TWO_DIMENSIONAL = "2D"
///     THREE_DIMENSIONAL = "3D"
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
pub enum Dimensionality {
    /// Serialize as "2D"; also accept several common spellings
    #[serde(rename = "2D", alias = "2d")]
    TwoDimensional,

    /// Serialize as "3D"; also accept several common spellings
    #[serde(rename = "3D", alias = "3d")]
    ThreeDimensional,
}

#[derive(Debug, Serialize, Deserialize, ToSchema, Clone)]
pub struct AnalysisOptions {
    pub id: u32,
    pub solve_loadcases: bool,
    pub solver: String,
    pub tolerance: f64,
    pub max_iterations: Option<u32>,
    pub dimensionality: Dimensionality,
    pub order: AnalysisOrder,
    pub rigid_strategy: RigidStrategy,
    #[serde(default = "default_axial_slack")]
    pub axial_slack: f64,
    /// When false, forces shear deformation factor φ=0 (Euler-Bernoulli) for all elements.
    #[serde(default = "default_true")]
    pub include_shear_deformation: bool,
    /// When false, ignores warping constant Iw and uses pure GJ/L torsion for all elements.
    #[serde(default = "default_true")]
    pub include_warping: bool,
    /// Controls the nonlinear solver formulation (P_DELTA or COROTATIONAL).
    /// Only affects second-order (nonlinear) analysis.
    #[serde(default)]
    pub nonlinear_method: NonlinearMethod,
}

fn default_true() -> bool {
    true
}

fn default_axial_slack() -> f64 {
    1.0e-3
}
