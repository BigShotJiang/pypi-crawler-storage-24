use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Serialize, Deserialize, ToSchema, Clone, Copy, Debug)]
pub struct NodeForces {
    pub fx: f64,
    pub fy: f64,
    pub fz: f64,
    pub mx: f64,
    pub my: f64,
    pub mz: f64,
    #[serde(default)]
    pub bw: f64,
}

/// Forces at an intermediate cross-section along a member, in local member axes.
#[derive(Serialize, Deserialize, ToSchema, Clone, Copy, Debug)]
pub struct SectionForce {
    pub x_frac: f64,
    pub forces: NodeForces,
}
