// src/functions/load_assembler.rs
use crate::functions::geometry::{get_dof_indices, DOFS_PER_NODE, ELEMENT_DOFS};
use crate::functions::hinge_and_release_operations::{
    apply_end_releases_to_local_beam_f, modes_from_single_ends,
};
use crate::models::fers::fers::AssemblyContext;
use crate::models::loads::loadcase::LoadCase;
use crate::models::members::enums::MemberType;
use crate::models::members::memberset::MemberSet;
use nalgebra::DMatrix;

/// Assembles the nodal loads into the global load vector.
pub fn assemble_nodal_loads(load_case: &LoadCase, f: &mut DMatrix<f64>) {
    for nodal_load in &load_case.nodal_loads {
        let node_id = nodal_load.node as usize;
        let (fx_index, fy_index, fz_index, _, _, _, _) = get_dof_indices(node_id);
        if nodal_load.direction.0 != 0.0 {
            f[(fx_index, 0)] += nodal_load.magnitude * nodal_load.direction.0;
        }
        if nodal_load.direction.1 != 0.0 {
            f[(fy_index, 0)] += nodal_load.magnitude * nodal_load.direction.1;
        }
        if nodal_load.direction.2 != 0.0 {
            f[(fz_index, 0)] += nodal_load.magnitude * nodal_load.direction.2;
        }
    }
}

/// Assembles the nodal moments into the global load vector.
pub fn assemble_nodal_moments(load_case: &LoadCase, f: &mut DMatrix<f64>) {
    for nodal_moment in &load_case.nodal_moments {
        let node_id = nodal_moment.node as usize;
        let (_, _, _, rx_index, ry_index, rz_index, _) = get_dof_indices(node_id);
        if nodal_moment.direction.0 != 0.0 {
            f[(rx_index, 0)] += nodal_moment.magnitude * nodal_moment.direction.0;
        }
        if nodal_moment.direction.1 != 0.0 {
            f[(ry_index, 0)] += nodal_moment.magnitude * nodal_moment.direction.1;
        }
        if nodal_moment.direction.2 != 0.0 {
            f[(rz_index, 0)] += nodal_moment.magnitude * nodal_moment.direction.2;
        }
    }
}

/// Assembles the distributed loads into the global load vector.
/// The function uses member sets to locate the member for each distributed load.
/// When `assembly_ctx` is provided, fixed-end forces on members with hinges are
/// condensed to be consistent with the condensed stiffness matrix.
pub fn assemble_distributed_loads(
    load_case: &LoadCase,
    member_sets: &[MemberSet],
    f: &mut DMatrix<f64>,
    load_case_id: u32,
    assembly_ctx: Option<&AssemblyContext>,
) {
    for distributed_load in &load_case.distributed_loads {
        if distributed_load.load_case != load_case_id {
            continue;
        }

        // Find the member corresponding to the distributed load
        let member_id = distributed_load.member;
        let member_opt = member_sets
            .iter()
            .flat_map(|ms| ms.members.iter())
            .find(|member| member.id == member_id);

        if let Some(member) = member_opt {
            let length = member.calculate_length();

            let w1 = distributed_load.magnitude;
            let w2 = distributed_load.end_magnitude;
            let a = distributed_load.start_frac;
            let b = distributed_load.end_frac;

            // Precompute power-differences
            let d1 = b - a;
            let d2 = b * b - a * a;
            let d3 = b * b * b - a * a * a;
            let d4 = b.powi(4) - a.powi(4);
            let d5 = b.powi(5) - a.powi(5);

            // Shape function integrals
            let i_n1 = d1 - d3 + 0.5 * d4;
            let i_xn1 = 0.5 * d2 - 0.75 * d4 + 0.4 * d5;
            let i_n3 = d3 - 0.5 * d4;
            let i_x_n3 = 0.75 * d4 - 0.4 * d5;
            let i_n2 = 0.5 * d2 - (2.0 / 3.0) * d3 + 0.25 * d4;
            let i_x_n2 = (1.0 / 3.0) * d3 - 0.5 * d4 + 0.2 * d5;
            let i_n4 = (1.0 / 3.0) * d3 - 0.25 * d4;
            let i_x_n4 = 0.25 * d4 - 0.2 * d5;

            let inv_d1 = 1.0 / d1;
            let f_i = length * (w1 * i_n1 + (w2 - w1) * inv_d1 * (i_xn1 - a * i_n1));
            let f_j = length * (w1 * i_n3 + (w2 - w1) * inv_d1 * (i_x_n3 - a * i_n3));
            let m_i = length * length * (w1 * i_n2 + (w2 - w1) * inv_d1 * (i_x_n2 - a * i_n2));
            let m_j = -length * length * (w1 * i_n4 + (w2 - w1) * inv_d1 * (i_x_n4 - a * i_n4));

            // Member unit vector
            let ex = (member.end_node.X - member.start_node.X) / length;
            let ey = (member.end_node.Y - member.start_node.Y) / length;
            let ez = (member.end_node.Z - member.start_node.Z) / length;

            // Load direction components
            let lx = distributed_load.direction.0;
            let ly = distributed_load.direction.1;
            let lz = distributed_load.direction.2;

            // Moment axis = e_member x load_direction
            let cx = ey * lz - ez * ly;
            let cy = ez * lx - ex * lz;
            let cz = ex * ly - ey * lx;

            let is_axial_only = matches!(
                member.member_type,
                MemberType::Truss | MemberType::Tension | MemberType::Compression
            );

            // Check if this member has hinges that require force condensation
            let has_hinge = member.start_hinge.is_some() || member.end_hinge.is_some();
            let needs_condensation = has_hinge && !is_axial_only && assembly_ctx.is_some();

            if needs_condensation {
                let ctx = assembly_ctx.unwrap();

                // Build the fixed-end force vector in GLOBAL coordinates (14x1)
                let mut f_global_member = DMatrix::<f64>::zeros(ELEMENT_DOFS, 1);
                f_global_member[(0, 0)] = f_i * lx;
                f_global_member[(1, 0)] = f_i * ly;
                f_global_member[(2, 0)] = f_i * lz;
                f_global_member[(3, 0)] = m_i * cx;
                f_global_member[(4, 0)] = m_i * cy;
                f_global_member[(5, 0)] = m_i * cz;
                f_global_member[(DOFS_PER_NODE, 0)] = f_j * lx;
                f_global_member[(DOFS_PER_NODE + 1, 0)] = f_j * ly;
                f_global_member[(DOFS_PER_NODE + 2, 0)] = f_j * lz;
                f_global_member[(DOFS_PER_NODE + 3, 0)] = m_j * cx;
                f_global_member[(DOFS_PER_NODE + 4, 0)] = m_j * cy;
                f_global_member[(DOFS_PER_NODE + 5, 0)] = m_j * cz;

                // Transform to local frame: f_local = T * f_global
                let t_mat = member.calculate_transformation_matrix_3d();
                let f_local_member = &t_mat * &f_global_member;

                // Get uncondensed K_local for the condensation formula
                if let Some(k_local) =
                    member.calculate_stiffness_matrix_3d(&ctx.material_by_id, &ctx.section_by_id)
                {
                    let a_h = member
                        .start_hinge
                        .and_then(|id| ctx.hinge_by_id.get(&id).copied());
                    let b_h = member
                        .end_hinge
                        .and_then(|id| ctx.hinge_by_id.get(&id).copied());
                    let (a_trans, a_rot, b_trans, b_rot, a_warp, b_warp) =
                        modes_from_single_ends(a_h, b_h);

                    if let Ok(f_eff_local) = apply_end_releases_to_local_beam_f(
                        &k_local,
                        &f_local_member,
                        a_trans,
                        a_rot,
                        b_trans,
                        b_rot,
                        a_warp,
                        b_warp,
                    ) {
                        // Transform condensed force back to global
                        let f_eff_global = t_mat.transpose() * &f_eff_local;

                        // Assemble into global force vector
                        let start_node_id = member.start_node.id as usize;
                        let (sfx, sfy, sfz, smx, smy, smz, sw) = get_dof_indices(start_node_id);
                        f[(sfx, 0)] += f_eff_global[(0, 0)];
                        f[(sfy, 0)] += f_eff_global[(1, 0)];
                        f[(sfz, 0)] += f_eff_global[(2, 0)];
                        f[(smx, 0)] += f_eff_global[(3, 0)];
                        f[(smy, 0)] += f_eff_global[(4, 0)];
                        f[(smz, 0)] += f_eff_global[(5, 0)];
                        f[(sw, 0)] += f_eff_global[(6, 0)];

                        let end_node_id = member.end_node.id as usize;
                        let (efx, efy, efz, emx, emy, emz, ew) = get_dof_indices(end_node_id);
                        f[(efx, 0)] += f_eff_global[(DOFS_PER_NODE, 0)];
                        f[(efy, 0)] += f_eff_global[(DOFS_PER_NODE + 1, 0)];
                        f[(efz, 0)] += f_eff_global[(DOFS_PER_NODE + 2, 0)];
                        f[(emx, 0)] += f_eff_global[(DOFS_PER_NODE + 3, 0)];
                        f[(emy, 0)] += f_eff_global[(DOFS_PER_NODE + 4, 0)];
                        f[(emz, 0)] += f_eff_global[(DOFS_PER_NODE + 5, 0)];
                        f[(ew, 0)] += f_eff_global[(DOFS_PER_NODE + 6, 0)];

                        continue; // skip the default assembly below
                    }
                }
                // Fall through to default assembly if condensation fails
            }

            // Default assembly (no hinge condensation)
            let start_node_id = member.start_node.id as usize;
            let (start_fx, start_fy, start_fz, start_mx, start_my, start_mz, _) =
                get_dof_indices(start_node_id);
            f[(start_fx, 0)] += f_i * lx;
            f[(start_fy, 0)] += f_i * ly;
            f[(start_fz, 0)] += f_i * lz;
            if !is_axial_only {
                f[(start_mx, 0)] += m_i * cx;
                f[(start_my, 0)] += m_i * cy;
                f[(start_mz, 0)] += m_i * cz;
            }

            let end_node_id = member.end_node.id as usize;
            let (end_fx, end_fy, end_fz, end_mx, end_my, end_mz, _) = get_dof_indices(end_node_id);
            f[(end_fx, 0)] += f_j * lx;
            f[(end_fy, 0)] += f_j * ly;
            f[(end_fz, 0)] += f_j * lz;
            if !is_axial_only {
                f[(end_mx, 0)] += m_j * cx;
                f[(end_my, 0)] += m_j * cy;
                f[(end_mz, 0)] += m_j * cz;
            }
        }
    }
}