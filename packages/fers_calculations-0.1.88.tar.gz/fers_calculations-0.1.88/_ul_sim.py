import numpy as np

E = 210000.0; G = 80769.0
Iy = 13210000.0; Iz = 1010000.0; J = 48437.0; A = 2401.0; L_total = 1000.0; P = 1000.0
N_sub = 4

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((12, 12))
    ea = E*A/L; l2=L*L; l3=l2*L
    k[0,0] = ea; k[6,6] = ea; k[0,6] = k[6,0] = -ea
    eiz = E*Iz
    k[1,1]=12*eiz/l3; k[1,5]=k[5,1]=6*eiz/l2; k[1,7]=k[7,1]=-12*eiz/l3; k[1,11]=k[11,1]=6*eiz/l2
    k[5,5]=4*eiz/L; k[5,7]=k[7,5]=-6*eiz/l2; k[5,11]=k[11,5]=2*eiz/L
    k[7,7]=12*eiz/l3; k[7,11]=k[11,7]=-6*eiz/l2; k[11,11]=4*eiz/L
    eiy = E*Iy
    k[2,2]=12*eiy/l3; k[2,4]=k[4,2]=-6*eiy/l2; k[2,8]=k[8,2]=-12*eiy/l3; k[2,10]=k[10,2]=-6*eiy/l2
    k[4,4]=4*eiy/L; k[4,8]=k[8,4]=6*eiy/l2; k[4,10]=k[10,4]=2*eiy/L
    k[8,8]=12*eiy/l3; k[8,10]=k[10,8]=6*eiy/l2; k[10,10]=4*eiy/L
    gj = G*J/L
    k[3,3]=gj; k[9,9]=gj; k[3,9]=k[9,3]=-gj
    return k

def build_T12(R):
    T = np.zeros((12, 12))
    for n in range(2):
        b = n*6; T[b:b+3,b:b+3] = R; T[b+3:b+6,b+3:b+6] = R
    return T

def rodrigues(v_from, v_to):
    c = float(v_from @ v_to)
    s_vec = np.cross(v_from, v_to)
    s = np.linalg.norm(s_vec)
    if s < 1e-12:
        if c > 0: return np.eye(3)
        perp = np.cross(np.array([1,0,0.]) if abs(v_from[0])<0.9 else np.array([0,1,0.]), v_from)
        perp /= np.linalg.norm(perp)
        return 2*np.outer(perp,perp) - np.eye(3)
    k = s_vec/s; K = np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    return np.eye(3) + K*s + K@K*(1-c)

R1 = np.array([[1,0,0],[0,0,1],[0,-1,0]], dtype=float)
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)
R3 = np.array([[0,0,1],[-1,0,0],[0,-1,0]], dtype=float)

# Build sub-element layout
n_nodes = 3*N_sub + 1; ndof = n_nodes * 6
orig_R = [R1]*N_sub + [R2]*N_sub + [R3]*N_sub

# Node positions (original)
node_pos = np.zeros((n_nodes, 3))
for i in range(N_sub+1):
    node_pos[i] = [i*L_total/N_sub, 0, 0]
for i in range(1, N_sub+1):
    node_pos[N_sub+i] = [1000, i*L_total/N_sub, 0]
for i in range(1, N_sub+1):
    node_pos[2*N_sub+i] = [1000, 1000, i*L_total/N_sub]

elem_nodes = [(m*N_sub+s, m*N_sub+s+1) for m in range(3) for s in range(N_sub)]
Ls0 = L_total / N_sub

fixed = list(range(6))
free = [i for i in range(ndof) if i not in fixed]
F_full = np.zeros(ndof); F_full[3*N_sub*6+1] = -P

def compute_T_from_pos(R_orig, p1, p2):
    """Compute T by rotating R_orig so x-axis aligns with p1->p2 chord"""
    d = p2 - p1; l = np.linalg.norm(d)
    if l < 1e-12: return build_T12(R_orig), l
    x_def = d / l
    l_orig = Ls0  # original sub-element length
    x_orig_dir = np.array([R_orig[0,0], R_orig[1,0], R_orig[2,0]])  # first column of R_orig.T = first row of R_orig
    # Wait, R_orig maps global->local, so R_orig.T maps local->global.
    # The member axis in global is R_orig.T[:,0] = R_orig[0,:] ? No.
    # R_orig rows are the local axes expressed in global.
    # Row 0 of R_orig = local X in global coords (member axis direction)
    x_orig = np.array([R_orig[0,0], R_orig[0,1], R_orig[0,2]])
    Rc = rodrigues(x_orig, x_def)
    R_def = R_orig @ Rc.T
    return build_T12(R_def), l

def assemble_K_UL(pos, R_origs):
    """Assemble K_elastic using current node positions (Updated Lagrangian)"""
    K = np.zeros((ndof, ndof))
    for e_idx, (ni, nj) in enumerate(elem_nodes):
        p1, p2 = pos[ni], pos[nj]
        T, l = compute_T_from_pos(R_origs[e_idx], p1, p2)
        kl = beam_k_local(E, G, A, Iy, Iz, J, l)
        kg = T.T @ kl @ T
        dofs_e = [ni*6+d for d in range(6)] + [nj*6+d for d in range(6)]
        for i in range(12):
            for j in range(12):
                K[dofs_e[i], dofs_e[j]] += kg[i, j]
    return K

# First-order
K0 = assemble_K_UL(node_pos, orig_R)
u_1st = np.zeros(ndof)
u_1st[free] = np.linalg.solve(K0[np.ix_(free, free)], F_full[free])
rx2 = u_1st[N_sub*6+3]; dy4 = u_1st[3*N_sub*6+1]; dz4 = u_1st[3*N_sub*6+2]
print(f'1st-order ({N_sub} sub): rx_n2={rx2:.6f} dy_n4={dy4:.2f} dz_n4={dz4:.2f}')

# Updated Lagrangian: incremental, update reference at each step
n_steps = 50
u_total = np.zeros(ndof)
cur_pos = node_pos.copy()
cur_R = list(orig_R)
tol = 1e-6

for step in range(1, n_steps+1):
    lam_prev = (step-1) / n_steps
    lam = step / n_steps
    dF = F_full * (lam - lam_prev)
    
    # Assemble K at current configuration
    K = assemble_K_UL(cur_pos, cur_R)
    Kff = K[np.ix_(free, free)]
    
    # Linear solve for incremental displacement
    du = np.zeros(ndof)
    du[free] = np.linalg.solve(Kff, dF[free])
    
    # Update total displacement and positions
    u_total += du
    for i in range(n_nodes):
        cur_pos[i] = node_pos[i] + u_total[i*6:i*6+3]
    
    # Update R for each element (rotate to follow chord)
    for e_idx, (ni, nj) in enumerate(elem_nodes):
        p1, p2 = cur_pos[ni], cur_pos[nj]
        d = p2 - p1; l = np.linalg.norm(d)
        x_def = d / l
        x_orig_R = orig_R[e_idx]
        x_orig = np.array([x_orig_R[0,0], x_orig_R[0,1], x_orig_R[0,2]])
        Rc = rodrigues(x_orig, x_def)
        cur_R[e_idx] = orig_R[e_idx] @ Rc.T
    
    if step in (1,5,10,25,50):
        rx = u_total[N_sub*6+3]; dy = u_total[3*N_sub*6+1]; dz = u_total[3*N_sub*6+2]
        print(f'Step {step:2d}: rx={rx:.6f} dy4={dy:.2f} dz4={dz:.2f}')

rx = u_total[N_sub*6+3]; dy = u_total[3*N_sub*6+1]; dz = u_total[3*N_sub*6+2]
Mx_arm = -P * (1000 + dz)
print(f'\nUL result ({N_sub} sub, {n_steps} steps): rx_n2={rx:.6f} dy4={dy:.2f} dz4={dz:.2f}')
print(f'Mx(arm)={Mx_arm:.0f}')
print(f'Expected: dy=-350, dz=347, Mx=-1347000')
