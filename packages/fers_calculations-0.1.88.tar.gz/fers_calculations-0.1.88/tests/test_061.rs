#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

use test_support::helpers::*;
use test_support::*;

// ---------------------------------------------------------
// 061: Two colinear tension-only members with mid load
// ---------------------------------------------------------

fn test_061_two_colinear_tension_only_members_with_mid_load_case(
    strategy: RigidStrategy,
    length_unit: LengthUnit,
    force_unit: ForceUnit,
    pressure_unit: PressureUnit,
) {
    let ctx = make_ctx(
        "test_061_two_colinear_tension_only_members_with_mid_load",
        strategy,
        length_unit,
        force_unit,
        pressure_unit,
    );
    let mut model =
        make_fers_with_strategy_and_units(strategy, length_unit, force_unit, pressure_unit);

    // Physical SI
    let member_length_si = 2.5_f64;
    let force_si = 1.0_f64; // keep as 1 N to match original test
    let e_si = 210.0e9_f64;
    let area_si = 26.2e-4_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let member_length = member_length_si / l;
    let force_user = force_si / f;

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_ipe180_like(&mut model, 1, mat_id, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));
    model.nodal_supports.push(make_support_custom(
        2,
        SupportConditionType::Free,
        SupportConditionType::Fixed,
        SupportConditionType::Fixed,
        SupportConditionType::Fixed,
        SupportConditionType::Fixed,
        SupportConditionType::Fixed,
    ));
    model.nodal_supports.push(make_fixed_support(3));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, member_length, 0.0, 0.0, Some(2));
    let n3 = make_node(3, 2.0 * member_length, 0.0, 0.0, Some(3));

    let m_left = make_tension_only_member(1, &n1, &n2, sec_id);
    let m_right = make_tension_only_member(2, &n2, &n3, sec_id);
    add_member_set(&mut model, 1, vec![m_left, m_right]);

    let lc_id = add_load_case(&mut model, 1, "Mid Load");
    add_nodal_load(&mut model, 1, lc_id, 2, force_user, (1.0, 0.0, 0.0));
    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);
    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("Mid Load")
        .unwrap();

    let dx_2 = res.displacement_nodes.get(&2).unwrap().dx;
    let fx_1 = res.reaction_nodes.get(&1).unwrap().nodal_forces.fx;
    let fx_3 = res.reaction_nodes.get(&3).unwrap().nodal_forces.fx;

    // Expected in SI
    let expected_dx_2_si = force_si * member_length_si / (area_si * e_si);

    // To user units
    let expected_dx_2 = expected_dx_2_si / l;
    let tol_dx = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);

    assert_close_ctx(&ctx, dx_2, expected_dx_2, tol_dx, "deflection at node 2");
    assert!((fx_1 - (-force_user)).abs() < tol_f);
    assert!(fx_3.abs() < tol_f);
}

#[test]
fn test_061_two_colinear_tension_only_members_with_mid_load() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_061_two_colinear_tension_only_members_with_mid_load_case(strategy, lu, fu, pu);
        }
    }
}
