#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

use test_support::helpers::*;
use test_support::*;

// ============================================================================
// TEST 118: Simply supported — reaction forces unaffected by shear
//
// For SS beam with center load, reactions are always R = P/2 regardless
// of shear deformation. Equilibrium must hold.
// ============================================================================
fn test_118_ss_reactions_shear_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_118_ss_reactions", strategy, lu, fu, pu);

    let l_si = 6.0_f64;
    let f_si = 10_000.0;
    let area_si = 53.8e-4_f64;
    let i_z_si = 8356.0e-8_f64;
    let i_y_si = 604.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let a_sz_si = 25.68e-4_f64;

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let half = (l_si / 2.0) / l;
    let end = l_si / l;
    let p_user = f_si / f;

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_T", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        None, None, Some(a_sz_si),
    );

    let pin = make_support_custom(
        1,
        SupportConditionType::Fixed, SupportConditionType::Fixed, SupportConditionType::Fixed,
        SupportConditionType::Fixed, SupportConditionType::Free, SupportConditionType::Free,
    );
    let roller = make_support_custom(
        2,
        SupportConditionType::Free, SupportConditionType::Fixed, SupportConditionType::Fixed,
        SupportConditionType::Fixed, SupportConditionType::Free, SupportConditionType::Free,
    );
    model.nodal_supports.push(pin);
    model.nodal_supports.push(roller);

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, half, 0.0, 0.0, None);
    let n3 = make_node(3, end, 0.0, 0.0, Some(2));
    let m1 = make_beam_member(1, &n1, &n2, sec_id);
    let m2 = make_beam_member(2, &n2, &n3, sec_id);
    add_member_set(&mut model, 1, vec![m1, m2]);

    let lc_id = add_load_case(&mut model, 1, "Center Load");
    add_nodal_load(&mut model, 1, lc_id, 2, p_user, (0.0, -1.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["Center Load"];
    let fy_1 = res.reaction_nodes[&1].nodal_forces.fy;
    let fy_3 = res.reaction_nodes[&3].nodal_forces.fy;

    let half_load = (f_si / 2.0) / f;
    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);

    assert_close_ctx(&ctx, half_load, fy_1, tol_f, "reaction Fy at pin (P/2)");
    assert_close_ctx(&ctx, half_load, fy_3, tol_f, "reaction Fy at roller (P/2)");

    // Equilibrium: ΣFy = 0
    let sum_fy = fy_1 + fy_3 - p_user;
    assert!(sum_fy.abs() < tol_f,
        "[{ctx}] ΣFy = {sum_fy}, expected 0");
}

#[test]
fn test_118_ss_reactions_shear() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_118_ss_reactions_shear_case(strategy, lu, fu, pu);
        }
    }
}
