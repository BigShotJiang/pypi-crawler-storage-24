#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// ============================================================================
// TEST 104: Backward compatibility — section without warping/shear gives same
// results as before (pure Euler-Bernoulli, St. Venant torsion)
//
// Compares a model using add_section (no warping props) against analytical EB
// solution for a cantilever with transverse load + torque.
// ============================================================================
fn test_104_backward_compatibility_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_104_backward_compatibility", strategy, lu, fu, pu);

    let l_si = 4.0_f64;
    let p_si = 2000.0_f64;
    let t_si = 1000.0_f64;
    let e_si = 210.0e9_f64;
    let g_si = 81.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_y_si = 604.0e-8_f64;
    let i_z_si = 8356.0e-8_f64;
    let j_si = 20.1e-8_f64;

    // Analytical EB solutions
    let dy_si = -p_si * l_si.powi(3) / (3.0 * e_si * i_z_si);
    let theta_si = t_si * l_si / (g_si * j_si);

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x2 = l_si / l;
    let p_user = p_si / f;
    let t_user = t_si / (f * l);

    let mat_id = add_material_s235(&mut model, 1);
    // Standard section — no warping, no shear area
    let sec_id = add_section(
        &mut model, 1, "IPE300", mat_id,
        area_si, i_y_si, i_z_si, j_si,
    );

    model.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);
    let m1 = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m1]);

    let lc_id = add_load_case(&mut model, 1, "Combined");
    add_nodal_load(&mut model, 1, lc_id, 2, p_user, (0.0, -1.0, 0.0));
    add_nodal_moment(&mut model, 2, lc_id, 2, t_user, (1.0, 0.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["Combined"];
    let dy_end = res.displacement_nodes[&2].dy;
    let rx_end = res.displacement_nodes[&2].rx;
    let warp_end = res.displacement_nodes[&2].warp;

    let dy_exp = dy_si / l;
    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_r = TOL_ABSOLUTE_ROTATION_IN_RADIAN;

    // Displacements must match EB theory
    assert_close_ctx(&ctx, dy_exp, dy_end, tol_d, "deflection (backward compat)");
    assert_close_ctx(&ctx, theta_si, rx_end, tol_r, "twist (backward compat)");

    // Warping DOF should be essentially zero (no warping stiffness)
    assert!(
        warp_end.abs() < 1e-6,
        "[{ctx}] Warping DOF should be ~0 without I_w, got {warp_end}"
    );
}

#[test]
fn test_104_backward_compatibility() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_104_backward_compatibility_case(strategy, lu, fu, pu);
        }
    }
}
