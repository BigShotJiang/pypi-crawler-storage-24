#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// ============================================================================
// TEST 101: Timoshenko shear deflection — cantilever with point load
//
// Analytical: δ = PL³/(3EI) + PL/(GA_s)   (bending + shear)
// We compare:
//   1) Euler-Bernoulli result (a_sz = None) gives δ_EB = PL³/(3EI)
//   2) Timoshenko result (a_sz = Some) gives δ_T = δ_EB + PL/(GA_sz)
//   3) The difference is exactly the shear contribution
// ============================================================================
fn test_101_timoshenko_shear_deflection_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_101_timoshenko_shear_deflection", strategy, lu, fu, pu);

    // Physical constants (SI)
    let l_si = 2.0_f64;          // 2 m cantilever
    let f_si = 10_000.0_f64;     // 10 kN end load
    let e_si = 210.0e9_f64;      // Steel E
    let g_si = 81.0e9_f64;       // Steel G
    let area_si = 53.8e-4_f64;   // IPE300 area
    let i_z_si = 8356.0e-8_f64;  // IPE300 Iz (strong axis)
    let i_y_si = 604.0e-8_f64;   // IPE300 Iy
    let j_si = 20.1e-8_f64;      // IPE300 J
    let a_sz_si = 25.68e-4_f64;  // IPE300 shear area (web) for strong-axis bending

    // Analytical solutions
    let delta_bending = f_si * l_si.powi(3) / (3.0 * e_si * i_z_si);
    let delta_shear = f_si * l_si / (g_si * a_sz_si);
    let delta_total = delta_bending + delta_shear;

    // ---- Model A: Euler-Bernoulli (no shear area) ----
    let mut model_eb = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model_eb.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x2 = l_si / l;
    let p_user = f_si / f;

    let mat_id = add_material_s235(&mut model_eb, 1);
    let sec_id_eb = add_section(
        &mut model_eb, 1, "IPE300_EB", mat_id,
        area_si, i_y_si, i_z_si, j_si,
    );

    model_eb.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);
    let m1 = make_beam_member(1, &n1, &n2, sec_id_eb);
    add_member_set(&mut model_eb, 1, vec![m1]);

    let lc_id = add_load_case(&mut model_eb, 1, "End Load");
    add_nodal_load(&mut model_eb, 1, lc_id, 2, p_user, (0.0, -1.0, 0.0));

    model_eb.normalize_units();
    model_eb.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] EB solve failed: {e}"));
    denorm_results_in_place(&mut model_eb);

    let res_eb = &model_eb.results.as_ref().unwrap().loadcases["End Load"];
    let dy_eb = res_eb.displacement_nodes[&2].dy;

    // ---- Model B: Timoshenko (with shear area) ----
    let mut model_t = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let mat_id_t = add_material_s235(&mut model_t, 1);
    let sec_id_t = add_section_with_warping(
        &mut model_t, 1, "IPE300_T", mat_id_t,
        area_si, i_y_si, i_z_si, j_si,
        None,               // no warping
        None,               // a_sy (not relevant for Y-bending)
        Some(a_sz_si),      // a_sz triggers Timoshenko for strong-axis bending
    );

    model_t.nodal_supports.push(make_fixed_support(1));
    let n1t = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2t = make_node(2, x2, 0.0, 0.0, None);
    let m1t = make_beam_member(1, &n1t, &n2t, sec_id_t);
    add_member_set(&mut model_t, 1, vec![m1t]);

    let lc_id_t = add_load_case(&mut model_t, 1, "End Load");
    add_nodal_load(&mut model_t, 1, lc_id_t, 2, p_user, (0.0, -1.0, 0.0));

    model_t.normalize_units();
    model_t.solve_for_load_case(lc_id_t).unwrap_or_else(|e| panic!("[{ctx}] Timo solve failed: {e}"));
    denorm_results_in_place(&mut model_t);

    let res_t = &model_t.results.as_ref().unwrap().loadcases["End Load"];
    let dy_t = res_t.displacement_nodes[&2].dy;

    // Convert analytical to user units
    let delta_eb_user = -delta_bending / l;
    let delta_t_user = -delta_total / l;

    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);

    // EB model should match pure bending deflection
    assert_close_ctx(&ctx, delta_eb_user, dy_eb, tol_d, "Euler-Bernoulli deflection");

    // Timoshenko model should match bending + shear deflection
    assert_close_ctx(&ctx, delta_t_user, dy_t, tol_d, "Timoshenko deflection");

    // The shear contribution should be the difference
    let shear_contrib_user = delta_shear / l;
    let actual_shear = (dy_eb - dy_t).abs();
    assert_close_ctx(&ctx, shear_contrib_user, actual_shear, tol_d, "shear contribution");
}

#[test]
fn test_101_timoshenko_shear_deflection() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_101_timoshenko_shear_deflection_case(strategy, lu, fu, pu);
        }
    }
}
