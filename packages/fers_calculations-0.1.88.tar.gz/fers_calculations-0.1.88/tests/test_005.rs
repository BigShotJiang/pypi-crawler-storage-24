#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// =========================================================
// 005: Cantilever with full triangular & inverse triangular load
// (check deflection / reactions, as in your Python script)
// =========================================================

fn test_005_cantilever_triangular_full_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_005_cantilever_triangular_full", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    // Physical
    let l_si = 5.0_f64;
    let w_si = 1000.0_f64;
    let e_si = 210.0e9_f64;
    let i_zz: f64 = 13.21e-6_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x1 = 0.0;
    let x2 = l_si / l;
    let w_user = w_si * l / f;

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_ipe180_like(&mut model, 1, mat_id, i_zz);

    model.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, x1, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);
    let m = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m]);

    let lc_tri = add_load_case(&mut model, 1, "Triangular Load");
    let lc_inv = add_load_case(&mut model, 2, "Inverse Triangular Load");

    // Helpers should create distribution-shaped loads on member 1:
    add_member_distributed_load_global_y(&mut model, 1, lc_tri, 1, w_user, 0.0, 0.0, 1.0);

    // Inverse triangular: zero at fixed, max at free
    add_member_distributed_load_global_y(&mut model, 2, lc_inv, 1, 0.0, w_user, 0.0, 1.0);
    model.normalize_units();
    model
        .solve_for_load_case(lc_tri)
        .expect("Triangular analysis failed");
    model
        .solve_for_load_case(lc_inv)
        .expect("Inverse triangular analysis failed");
    denorm_results_in_place(&mut model);

    let res_tri = &model.results.as_ref().unwrap().loadcases["Triangular Load"];
    let res_inv = &model.results.as_ref().unwrap().loadcases["Inverse Triangular Load"];

    let dy_tri = res_tri.displacement_nodes[&2].dy;
    let mz_tri = res_tri.reaction_nodes[&1].nodal_forces.mz;
    let mz_inv = res_inv.reaction_nodes[&1].nodal_forces.mz;

    // Analytical:
    // Triangular (zero at free, max w at fixed):
    //   R = w L / 2, M_fixed = w L^2 / 6, δ(L) = -w L^4 / (30 E I)
    let dy_tri_si = -w_si * l_si.powi(4) / (30.0 * e_si * i_zz); // m
    let mz_tri_si = -w_si * l_si.powi(2) / 6.0;
    //   R = w L / 2, M_fixed = w L^2 / 3
    let mz_inv_si = -w_si * l_si.powi(2) / 3.0;

    // Print l for debug
    let dy_tri_exp = -dy_tri_si / l;
    let mz_tri_exp = mz_tri_si / (f * l);
    let mz_inv_exp = mz_inv_si / (f * l);

    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    println!("f = {}, l = {}", f, l);
    println!("w_user = {}", w_user);
    println!("mz_tri_si = {}", mz_tri_si);
    println!("mz_tri_exp = {}", mz_tri_exp);
    println!("dy_tri = {}", dy_tri);
    println!("mz_inv = {}", mz_inv);
    println!("mz_tri = {}", mz_tri);

    assert_close_ctx(&ctx, dy_tri_exp, dy_tri, tol_d, "deflection at free end");
    assert_close_ctx(
        &ctx,
        mz_tri_exp,
        mz_tri,
        tol_m,
        "moment at fixed support triangle",
    );
    assert_close_ctx(
        &ctx,
        mz_inv_exp,
        mz_inv,
        tol_m,
        "moment at fixed support inverse",
    );
}

#[test]
fn test_005_cantilever_triangular_full() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_005_cantilever_triangular_full_case(strategy, lu, fu, pu);
        }
    }
}
