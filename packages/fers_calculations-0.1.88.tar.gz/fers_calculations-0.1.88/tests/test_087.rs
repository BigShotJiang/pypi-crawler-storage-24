#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  087 — Out-of-plane L-frame (2-beam, XZ plane, Y-load)
//
//  N1(0,0,0) ── beam1 (along X) ── N2(1,0,0)
//                                       │
//                                   beam2 (along Z)
//                                       │
//                                   N3(1,0,1)  ← F = −1000 N in Y
//
//  Support:  N1 fully fixed
//  Purpose:  Diagnostic for second-order solver with Z-axis beams.
//            If second-order gives rx_N2 ≈ 434 mrad instead of ≈ 1.23 mrad,
//            the bug is in the TL formulation for beams along Z.
//
//  Analytical first-order (L = 1 m, E = 210 GPa, G = 81 GPa, IPE-180):
//    Section: I_z = 13.21e-6 m⁴ (strong axis), J = 1.0e-5 m⁴
//
//    Beam1 (along X) at N2 — carries shear Vy = −1000 N and torque Mx = +1000 N·m:
//      dy    = −FL³/(3EI_z)   = −0.1202 mm
//      rx    = +TL/(GJ)       = +1.2346 mrad   (KEY: torsion from T = 1000 N·m)
//      rz    = −FL²/(2EI_z)   = −0.1802 mrad
//
//    Beam2 (along Z) at N3 — cantilever under Fy = −1000 N at tip:
//      dy    = dy_N2 − FL³/(3EI_z) − rx_N2 × L  = −1.4750 mm
//      dz    ≈ 0 (no Z-load component in first-order)
//      rx    = rx_N2 + FL²/(2EI_z)               = +1.4148 mrad
//
//    Reactions at N1:
//      r × F = (1,0,1) × (0,−1000,0) = (1000, 0, −1000)  →  Rx = (−1000, 0, +1000) N·m
//      fy = +1000 N,  mx = −1000 N·m,  mz = +1000 N·m
// ─────────────────────────────────────────────────────────────────────────────

fn test_087_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("087_out_of_plane_l_frame", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let arm_si = 1.0_f64;
    let force_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let fl = f * l;
    let arm = arm_si / l;
    let force_u = force_si / f;

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, arm, 0.0, 0.0, None);
    let n3 = make_node(3, arm, 0.0, arm, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 3, force_u, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case(lc)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);
    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);

    // Force equilibrium — only N1 carries all reactions
    assert_close_ctx(&ctx, 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx(&ctx, force_u, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx(&ctx, 0.0, rx.fz, tol_f, "Rx.fz");

    // Moment equilibrium about origin
    // r × F = (1,0,1) × (0,−1000,0) = (1000, 0, −1000)
    // → reaction moments = (−1000, 0, +1000) N·m
    assert_close_ctx(&ctx, -1000.0 / fl, rx.mx, tol_m, "Rx.mx");
    assert_close_ctx(&ctx, 0.0, rx.my, tol_m, "Rx.my");
    assert_close_ctx(&ctx, 1000.0 / fl, rx.mz, tol_m, "Rx.mz");

    // All nodes must have zero Z displacement (structure deflects in Y, not Z)
    for nid in [1u32, 2, 3] {
        let dz = r.displacement_nodes[&nid].dz;
        assert_close_ctx(&ctx, 0.0, dz, tol_d, &format!("N{nid}.dz == 0"));
    }
}

#[test]
fn test_087_out_of_plane_l_frame_equilibrium() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_087_case(s, lu, fu, pu);
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  087 — Second-order diagnostic
//
//  Same geometry, solved with Updated-Lagrangian P-Δ.
//
//  KEY DIAGNOSTIC:
//    rx_N2 must be ≈ 1.2346 mrad (torsion of beam1).
//    If rx_N2 ≫ 1.23 mrad (e.g. ~434 mrad) the TL formulation is incorrectly
//    building K_geo for Z-axis beams — same failure mode seen in test_084.
//
//    dz_N3 must be ≈ 0.
//    If dz_N3 ≈ 438 mm the spurious rotation at N2 is propagating rigidly
//    through beam2, confirming the same root cause.
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_087_second_order_equilibrium() {
    let strategy = RigidStrategy::RigidMember;
    let lu = LengthUnit::M;
    let fu = ForceUnit::N;
    let pu = PressureUnit::Pa;
    let ctx = make_ctx("087_second_order", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 1.0, 0.0, 0.0, None);
    let n3 = make_node(3, 1.0, 0.0, 1.0, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 3, 1000.0, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case_second_order(lc, 30)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx1 = r.reaction_nodes.get(&1).unwrap().nodal_forces;
    let d2 = r.displacement_nodes.get(&2).unwrap();
    let d3 = r.displacement_nodes.get(&3).unwrap();

    println!("=== 087 Second-Order Reactions at N1 ===");
    println!("  fx = {:.6} N", rx1.fx);
    println!("  fy = {:.6} N", rx1.fy);
    println!("  fz = {:.6} N", rx1.fz);
    println!("  mx = {:.6} N·m", rx1.mx);
    println!("  my = {:.6} N·m", rx1.my);
    println!("  mz = {:.6} N·m", rx1.mz);
    println!("=== 087 Second-Order Displacements ===");
    println!("  N2: dy = {:.4} mm   rx = {:.4} mrad   rz = {:.4} mrad",
        d2.dy * 1e3, d2.rx * 1e3, d2.rz * 1e3);
    println!("  N3: dy = {:.4} mm   dz = {:.4} mm   rx = {:.4} mrad",
        d3.dy * 1e3, d3.dz * 1e3, d3.rx * 1e3);
    println!("  (first-order reference: N2.rx ≈ 1.2346 mrad, N3.dz ≈ 0 mm)");

    // Force equilibrium (looser tolerance than first-order: small residual from UL coupling)
    let tol_f_so = tol_force_user(0.2, 1.0);
    assert_close_ctx(&ctx, 0.0,    rx1.fx, tol_f_so, "Rx.fx");
    assert_close_ctx(&ctx, 1000.0, rx1.fy, tol_f_so, "Rx.fy");
    assert_close_ctx(&ctx, 0.0,    rx1.fz, tol_f_so, "Rx.fz");

    // Moment equilibrium: second-order effects negligible for stiff IPE-180 at 1 m arms
    // (deflection ≈ 1.5 mm → δ/L ≈ 0.15% → P-Δ shift < 1.5 N·m on 1000 N·m)
    let tol_m_so = tol_moment_user(50.0, 1.0, 1.0);
    assert_close_ctx(&ctx, -1000.0, rx1.mx, tol_m_so, "Rx.mx");
    assert_close_ctx(&ctx,  1000.0, rx1.mz, tol_m_so, "Rx.mz");

    // ── Displacement & rotation cross-check against analytical first-order ──
    //
    // Analytical (first-order, L=1m, F=1000N, E=210GPa, G=81GPa,
    //             I_z=13.21e-6 m⁴, J=1.0e-5 m⁴):
    //
    //   N2: dy = −FL³/(3EI_z)  = −0.1202 mm
    //       rx = +TL/(GJ)      = +1.2346 mrad  ← KEY DIAGNOSTIC
    //       rz = −FL²/(2EI_z)  = −0.1802 mrad
    //
    //   N3: dy = dy_N2 − FL³/(3EI_z) − rx_N2 × L  = −1.4750 mm
    //       dz ≈ 0 mm  (any large value here signals Z-beam TL bug)
    //       rx = rx_N2 + FL²/(2EI_z)               = +1.4148 mrad
    //
    // Second-order shifts <1% for this stiff section.
    // Tolerance: 1% of expected value, floor of 0.005 mm / 0.005 mrad.

    let tol_d = |expected_mm: f64| -> f64 {
        let abs_tol = expected_mm.abs() * 0.01;
        if abs_tol < 0.005 { 0.005 } else { abs_tol }
    };
    let tol_r = |expected_mrad: f64| -> f64 {
        let abs_tol = expected_mrad.abs() * 0.01;
        if abs_tol < 0.005 { 0.005 } else { abs_tol }
    };

    // N2 — KEY DIAGNOSTIC: if rx_N2 ≫ 1.23 mrad the Z-beam TL formulation is broken
    assert_close_ctx(&ctx, -0.1202, d2.dy * 1e3, tol_d(0.1202), "N2.dy [mm]");
    assert_close_ctx(&ctx,  1.2346, d2.rx * 1e3, tol_r(1.2346), "N2.rx [mrad] — KEY DIAGNOSTIC");
    assert_close_ctx(&ctx, -0.1802, d2.rz * 1e3, tol_r(0.1802), "N2.rz [mrad]");

    // N3 — dz must be near zero; a large value confirms the rx_N2 bug propagates
    assert_close_ctx(&ctx, -1.4750, d3.dy * 1e3, tol_d(1.4750), "N3.dy [mm]");
    assert_close_ctx(&ctx,  0.0,    d3.dz * 1e3, 0.05,          "N3.dz [mm] ≈ 0");
    assert_close_ctx(&ctx,  1.4148, d3.rx * 1e3, tol_r(1.4148), "N3.rx [mrad]");
}
