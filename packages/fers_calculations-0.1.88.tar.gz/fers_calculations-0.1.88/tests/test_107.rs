#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

use test_support::helpers::*;
use test_support::*;

// ============================================================================
// TEST 107: Timoshenko simply supported with center point load
//
// Analytical:
//   δ_EB = PL³/(48EI)
//   δ_T  = PL³/(48EI) + PL/(4GA_s)
// ============================================================================
fn test_107_timoshenko_ss_center_load_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_107_timo_ss_center", strategy, lu, fu, pu);

    let l_si = 6.0_f64;
    let f_si = 10_000.0;
    let e_si = 210.0e9_f64;
    let g_si = 81.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_z_si = 8356.0e-8_f64;
    let i_y_si = 604.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let a_sz_si = 25.68e-4_f64;

    let delta_bending = f_si * l_si.powi(3) / (48.0 * e_si * i_z_si);
    let delta_shear = f_si * l_si / (4.0 * g_si * a_sz_si);
    let delta_total = delta_bending + delta_shear;

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let half = (l_si / 2.0) / l;
    let end = l_si / l;
    let p_user = f_si / f;

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_T", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        None, None, Some(a_sz_si),
    );

    // Pin at node 1 (fork support: translations + torsion fixed)
    let pin = make_support_custom(
        1,
        SupportConditionType::Fixed, SupportConditionType::Fixed, SupportConditionType::Fixed,
        SupportConditionType::Fixed, SupportConditionType::Free, SupportConditionType::Free,
    );
    // Roller at node 3 (Y+Z fixed, torsion fixed)
    let roller = make_support_custom(
        2,
        SupportConditionType::Free, SupportConditionType::Fixed, SupportConditionType::Fixed,
        SupportConditionType::Fixed, SupportConditionType::Free, SupportConditionType::Free,
    );
    model.nodal_supports.push(pin);
    model.nodal_supports.push(roller);

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, half, 0.0, 0.0, None);
    let n3 = make_node(3, end, 0.0, 0.0, Some(2));
    let m1 = make_beam_member(1, &n1, &n2, sec_id);
    let m2 = make_beam_member(2, &n2, &n3, sec_id);
    add_member_set(&mut model, 1, vec![m1, m2]);

    let lc_id = add_load_case(&mut model, 1, "Center Load");
    add_nodal_load(&mut model, 1, lc_id, 2, p_user, (0.0, -1.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["Center Load"];
    let dy_mid = res.displacement_nodes[&2].dy;

    let expected = -delta_total / l;
    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    assert_close_ctx(&ctx, expected, dy_mid, tol_d, "Timo SS midspan deflection");
}

#[test]
fn test_107_timoshenko_ss_center_load() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_107_timoshenko_ss_center_load_case(strategy, lu, fu, pu);
        }
    }
}
