#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

use test_support::helpers::*;
use test_support::*;

// ---------------------------------------------------------
// 082: Two base supports horizontal tip load
// ---------------------------------------------------------

fn test_082_two_base_supports_horizontal_tip_load_reaction_signs_and_equilibrium_case(
    strategy: RigidStrategy,
    length_unit: LengthUnit,
    force_unit: ForceUnit,
    pressure_unit: PressureUnit,
) {
    let ctx = make_ctx(
        "test_082_two_base_supports_horizontal_tip_load_reaction_signs_and_equilibrium",
        strategy,
        length_unit,
        force_unit,
        pressure_unit,
    );
    let mut model =
        make_fers_with_strategy_and_units(strategy, length_unit, force_unit, pressure_unit);

    // Physical SI
    let length_horizontal_si = 5.0_f64;
    let length_vertical_si = 5.0_f64;
    let force_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let length_horizontal = length_horizontal_si / l;
    let length_vertical = length_vertical_si / l;
    let force_user = force_si / f;

    let material_id = add_material_s235(&mut model, 1);
    let section_id =
        add_section_ipe180_like(&mut model, 1, material_id, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    // Support 1: fully fixed
    model.nodal_supports.push(make_fixed_support(1));

    // Support 2: X free, Y free, Z fixed; rotations all free
    model.nodal_supports.push(make_support_custom(
        2,
        SupportConditionType::Free,
        SupportConditionType::Free,
        SupportConditionType::Fixed,
        SupportConditionType::Free,
        SupportConditionType::Free,
        SupportConditionType::Free,
    ));

    // Geometry
    let node1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2 = make_node(2, length_horizontal, 0.0, 0.0, Some(1));
    let node3 = make_node(3, length_horizontal, length_vertical, 0.0, Some(2));

    let member_horizontal = make_beam_member(1, &node1, &node2, section_id);
    let member_vertical = make_beam_member(2, &node2, &node3, section_id);
    add_member_set(&mut model, 1, vec![member_horizontal, member_vertical]);

    let load_case_id = add_load_case(&mut model, 1, "Horizontal Tip Load");
    add_nodal_load(&mut model, 1, load_case_id, 3, force_user, (-1.0, 0.0, 0.0));
    model.normalize_units();
    model
        .solve_for_load_case(load_case_id)
        .expect("Analysis failed");
    denorm_results_in_place(&mut model);
    let results = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("Horizontal Tip Load")
        .unwrap();

    let reactions_node1 = results.reaction_nodes.get(&1).unwrap().nodal_forces;
    let reactions_node2 = results.reaction_nodes.get(&2).unwrap().nodal_forces;
    let reactions_node3 = results.reaction_nodes.get(&3).unwrap().nodal_forces;

    let reaction_fx_sum = reactions_node1.fx + reactions_node2.fx + reactions_node3.fx;
    let reaction_fy_sum = reactions_node1.fy + reactions_node2.fy + reactions_node3.fy;
    let reaction_fz_sum = reactions_node1.fz + reactions_node2.fz + reactions_node3.fz;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);

    // Global equilibrium in X: reactions must balance applied -F → sum Rx = +F
    assert_close_ctx(
        &ctx,
        reaction_fx_sum,
        force_user,
        tol_f,
        "global Fx equilibrium",
    );

    // Global equilibrium in Y: no Y loads
    assert_close_ctx(&ctx, reaction_fy_sum, 0.0, tol_f, "global Fy equilibrium");

    // No parasitic Z reactions
    assert_close_ctx(&ctx, reaction_fz_sum, 0.0, tol_f, "global Fz equilibrium");

    // Opposite vertical reactions at bases
    let fy1 = reactions_node1.fy;
    let fy2 = reactions_node2.fy;
    assert!(
        fy1 * fy2 <= 0.0,
        "Expected opposite signs for Fy at nodes 1 and 2, got Fy1={}, Fy2={}",
        fy1,
        fy2
    );
    assert_close_ctx(&ctx, fy1 + fy2, 0.0, tol_f, "Fy at bases sum to zero");

    // Node 3 only Uz fixed → negligible Fx, Fy
    assert!(reactions_node3.fx.abs() < tol_f);
    assert!(reactions_node3.fy.abs() < tol_f);
}

#[test]
fn test_082_two_base_supports_horizontal_tip_load_reaction_signs_and_equilibrium() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_082_two_base_supports_horizontal_tip_load_reaction_signs_and_equilibrium_case(
                strategy, lu, fu, pu,
            );
        }
    }
}
