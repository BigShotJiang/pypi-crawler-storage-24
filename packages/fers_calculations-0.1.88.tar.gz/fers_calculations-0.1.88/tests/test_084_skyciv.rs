#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::{NonlinearMethod, RigidStrategy};
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  084 — Triple cantilever 3D with real IPE 180 cross-section
//
//  N1(0,0,0) ── beam1(X) ── N2(1,0,0) ── beam2(Y) ── N3(1,1,0) ── beam3(Z) ── N4(1,1,1)
//                                                                                  ↑
//                                                                        F = −1000 N in Y
//
//  Support:   N1 fully fixed
//  Section:   IPE 180 (real properties, rotation_angle=90° on members 1 & 3)
//
//  This model builds a single geometry and tests multiple aspects:
//    1. First-order reactions & member forces
//    2. Second-order reactions, displacements & member forces
//    3. Member force direction consistency (forces in original local frame)
// ─────────────────────────────────────────────────────────────────────────────

/// Real IPE 180 properties in SI:
const IPE180_A_M2: f64 = 2.401e-3;    // 2401 mm²
const IPE180_IY_M4: f64 = 13.21e-6;   // 13210000 mm⁴  (strong axis)
const IPE180_IZ_M4: f64 = 1.01e-6;    // 1010000 mm⁴   (weak axis)
const IPE180_J_M4: f64 = 4.8437e-8;   // 48437 mm⁴     (torsion constant)

fn build_084_model() -> fers_calculations::models::fers::fers::FERS {
    let strategy = RigidStrategy::RigidMember;
    let lu = LengthUnit::M;
    let fu = ForceUnit::N;
    let pu = PressureUnit::Pa;
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section(
        &mut model, 1, "IPE180", mat,
        IPE180_A_M2, IPE180_IY_M4, IPE180_IZ_M4, IPE180_J_M4,
    );

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 1.0, 0.0, 0.0, None);
    let n3 = make_node(3, 1.0, 1.0, 0.0, None);
    let n4 = make_node(4, 1.0, 1.0, 1.0, None);

    let mut m1 = make_beam_member(1, &n1, &n2, sec);
    m1.rotation_angle = 90.0;
    let m2 = make_beam_member(2, &n2, &n3, sec);
    let mut m3 = make_beam_member(3, &n3, &n4, sec);
    m3.rotation_angle = 90.0;

    add_member_set(&mut model, 1, vec![m1, m2, m3]);

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 4, 1000.0, (0.0, -1.0, 0.0));

    model
}

// ─────────────────────────────────────────────────────────────────────────────
//  Test 1: First-order statics (linear)
//
//  Analytically: the applied force is 1000 N at N4(1,1,1) downward (-Y).
//  Reaction at N1(0,0,0): Fy=1000, Mx = -1000*(1) = -1000 N·m, Mz = +1000*(1) = +1000 N·m
//  The torsion constant J only affects the distribution, not first-order statics.
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_084_first_order_reactions() {
    let mut model = build_084_model();

    model.normalize_units();
    model.solve_for_load_case(1).expect("first-order solve");
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    let tol_f = 0.1;   // N
    let tol_m = 0.5;    // N·m

    // Force equilibrium
    assert_close_ctx("084_1st", 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx("084_1st", 1000.0, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx("084_1st", 0.0, rx.fz, tol_f, "Rx.fz");

    // Moment equilibrium (first-order: undeformed geometry)
    assert_close_ctx("084_1st", -1000.0, rx.mx, tol_m, "Rx.mx");
    assert_close_ctx("084_1st", 0.0, rx.my, tol_m, "Rx.my");
    assert_close_ctx("084_1st", 1000.0, rx.mz, tol_m, "Rx.mz");
}

// ─────────────────────────────────────────────────────────────────────────────
//  Test 2: First-order member forces in original-local coordinates
//
//  Member 1 (along X, rot_angle=90°): carries Vz=1000, My=1000, T=1000 N·m
//  Member 2 (along Y): carries N=1000, Mz=1000 N·m (from member 1 torsion)
//  Member 3 (along Z, rot_angle=90°): carries Vz=1000, My=1000 N·m
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_084_first_order_member_forces() {
    let mut model = build_084_model();

    model.normalize_units();
    model.solve_for_load_case(1).expect("first-order solve");
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];

    let tol_f = 1.0;   // N
    let tol_m = 2.0;    // N·m

    // Member 1: shear Vz=1000, torsion T=1000, bending My=1000
    let m1s = &r.member_results[&1].local_start_forces;
    assert_close_ctx("084_1st_m1", 0.0, m1s.fx, tol_f, "M1.N");
    assert_close_ctx("084_1st_m1", 0.0, m1s.fy, tol_f, "M1.Vy");
    assert_close_ctx("084_1st_m1", -1000.0, m1s.fz, tol_f, "M1.Vz");
    assert_close_ctx("084_1st_m1", -1000.0, m1s.mx, tol_m, "M1.T");
    assert_close_ctx("084_1st_m1", 1000.0, m1s.my, tol_m, "M1.My");
    assert_close_ctx("084_1st_m1", 0.0, m1s.mz, tol_m, "M1.Mz");

    // Member 2: axial N=1000, bending Mz=1000 (torsion from member 1)
    let m2s = &r.member_results[&2].local_start_forces;
    assert_close_ctx("084_1st_m2", 1000.0, m2s.fx, tol_f, "M2.N");
    assert_close_ctx("084_1st_m2", 0.0, m2s.fy, tol_f, "M2.Vy");
    assert_close_ctx("084_1st_m2", 0.0, m2s.fz, tol_f, "M2.Vz");
    assert_close_ctx("084_1st_m2", 0.0, m2s.mx, tol_m, "M2.T");
    assert_close_ctx("084_1st_m2", 0.0, m2s.my, tol_m, "M2.My");
    assert_close_ctx("084_1st_m2", -1000.0, m2s.mz, tol_m, "M2.Mz");

    // Member 3: shear Vz=1000, bending My=1000
    let m3s = &r.member_results[&3].local_start_forces;
    assert_close_ctx("084_1st_m3", 0.0, m3s.fx, tol_f, "M3.N");
    assert_close_ctx("084_1st_m3", 0.0, m3s.fy, tol_f, "M3.Vy");
    assert_close_ctx("084_1st_m3", -1000.0, m3s.fz, tol_f, "M3.Vz");
    assert_close_ctx("084_1st_m3", 0.0, m3s.mx, tol_m, "M3.T");
    assert_close_ctx("084_1st_m3", 1000.0, m3s.my, tol_m, "M3.My");
    assert_close_ctx("084_1st_m3", 0.0, m3s.mz, tol_m, "M3.Mz");
}

// ─────────────────────────────────────────────────────────────────────────────
//  Test 3: Second-order reaction forces
//
//  Force equilibrium (exact):  Fy = 1000 N, Fx = Fz = 0
//  Moment equilibrium on deformed geometry:
//    Mx = -Fy * z_arm_deformed, Mz = Fy * x_arm_deformed
//  Self-consistency check: Mx and Mz must match deformed N4 position.
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_084_second_order_reactions() {
    let mut model = build_084_model();

    model.normalize_units();
    model
        .solve_for_load_case_second_order(1, 30)
        .expect("second-order solve");
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;
    let d4 = r.displacement_nodes.get(&4).unwrap();

    // Exact force equilibrium
    let tol_f = 0.5; // N
    assert_close_ctx("084_2nd", 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx("084_2nd", 1000.0, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx("084_2nd", 0.0, rx.fz, tol_f, "Rx.fz");
    assert_close_ctx("084_2nd", 0.0, rx.my, tol_f, "Rx.my");

    // Self-consistency: Mx = -Fy * (z_N4)  and  Mz = Fy * (x_N4 - x_N1)
    // N4 original position: (1, 1, 1) in SI meters
    let z_arm = 1.0 + d4.dz;   // deformed z of N4
    let x_arm = 1.0 + d4.dx;   // deformed x of N4 (x_N1 = 0)
    let expected_mx = -1000.0 * z_arm;
    let expected_mz = 1000.0 * x_arm;

    let tol_m = 5.0; // N·m (self-consistency, not absolute)
    assert_close_ctx("084_2nd", expected_mx, rx.mx, tol_m, "Rx.mx self-consistent");
    assert_close_ctx("084_2nd", expected_mz, rx.mz, tol_m, "Rx.mz self-consistent");
}

// ─────────────────────────────────────────────────────────────────────────────
//  Test 4: Second-order member forces in original-local coordinates
//
//  The key test: member forces must be in the original local frame, not the
//  deformed frame.  With large torsional rotation (~323 mrad on member 1),
//  wrong-frame forces would show N≈947 on member 2 instead of N≈1000.
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_084_second_order_member_forces() {
    let mut model = build_084_model();

    model.normalize_units();
    model
        .solve_for_load_case_second_order(1, 30)
        .expect("second-order solve");
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];

    let tol_f = 2.0;    // N
    let tol_m = 5.0;     // N·m

    // Member 1: Vz≈-1000, My≈1000, T = Mx_reaction (deformed moment arm)
    let m1s = &r.member_results[&1].local_start_forces;
    assert_close_ctx("084_2nd_m1", 0.0, m1s.fx, tol_f, "M1.N");
    assert_close_ctx("084_2nd_m1", 0.0, m1s.fy, tol_f, "M1.Vy");
    assert_close_ctx("084_2nd_m1", -1000.0, m1s.fz, tol_f, "M1.Vz");
    assert_close_ctx("084_2nd_m1", 0.0, m1s.mz, tol_m, "M1.Mz");

    // Member 2: axial N=1000, zero shear
    let m2s = &r.member_results[&2].local_start_forces;
    assert_close_ctx("084_2nd_m2", 1000.0, m2s.fx, tol_f, "M2.N");
    assert_close_ctx("084_2nd_m2", 0.0, m2s.fy, tol_f, "M2.Vy");
    assert_close_ctx("084_2nd_m2", 0.0, m2s.fz, tol_f, "M2.Vz");
    assert_close_ctx("084_2nd_m2", 0.0, m2s.mx, tol_m, "M2.T");

    // Member 3: shear Vz=1000, zero axial
    let m3s = &r.member_results[&3].local_start_forces;
    assert_close_ctx("084_2nd_m3", 0.0, m3s.fx, tol_f, "M3.N");
    assert_close_ctx("084_2nd_m3", 0.0, m3s.fy, tol_f, "M3.Vy");
    assert_close_ctx("084_2nd_m3", -1000.0, m3s.fz, tol_f, "M3.Vz");
    assert_close_ctx("084_2nd_m3", 0.0, m3s.mx, tol_m, "M3.T");

    // Torsion and bending moment consistency:
    // Member 1 torsion = Member 2 bending moment at start
    let m1_torsion = m1s.mx.abs();
    let m2_bending = m2s.mz.abs();
    let diff = (m1_torsion - m2_bending).abs();
    assert!(diff < 1.0,
        "M1.T ({}) should equal M2.Mz ({}) at the junction, diff={}",
        m1_torsion, m2_bending, diff);

    // Member 2 end bending = Member 3 start bending
    let m2e = &r.member_results[&2].local_end_forces;
    let m2_end_bending = m2e.mz.abs();
    let m3_start_bending = m3s.my.abs();
    let diff2 = (m2_end_bending - m3_start_bending).abs();
    assert!(diff2 < 1.0,
        "M2.Mz_end ({}) should equal M3.My_start ({}) at the junction, diff={}",
        m2_end_bending, m3_start_bending, diff2);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Test 5: P-Delta (TL) second-order analysis
//
//  P-Delta uses Total-Lagrangian geometric stiffness without the corotational
//  correction.  With the corrected consistent K_geo (standard Przemieniecki
//  coefficients), this now closely matches SkyCiv P-Delta results.
//
//  SkyCiv reference values (P-Delta mode):
//    Mx ≈ -1347 N·m, Mz ≈ 1000 N·m
//    Node 4: dy ≈ -350 mm, dz ≈ 347 mm
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_084_second_order_pdelta() {
    let mut model = build_084_model();
    model.settings.analysis_options.nonlinear_method = NonlinearMethod::P_DELTA;

    model.normalize_units();
    model
        .solve_for_load_case_second_order(1, 30)
        .expect("P-Delta second-order solve");
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;
    let d4 = r.displacement_nodes.get(&4).unwrap();

    // Force equilibrium must still hold exactly
    let tol_f = 0.5;
    assert_close_ctx("084_pd", 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx("084_pd", 1000.0, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx("084_pd", 0.0, rx.fz, tol_f, "Rx.fz");

    // SkyCiv comparison: Mx ≈ -1347, Mz ≈ 1000
    let tol_m = 15.0;  // N·m
    assert_close_ctx("084_pd", -1347.0, rx.mx, tol_m, "Rx.mx vs SkyCiv");
    assert_close_ctx("084_pd", 1000.0, rx.mz, tol_m, "Rx.mz vs SkyCiv");

    // Displacement comparison with SkyCiv
    let tol_d = 0.01; // 10 mm
    assert_close_ctx("084_pd", -0.350, d4.dy, tol_d, "d4.dy vs SkyCiv");
    assert_close_ctx("084_pd", 0.347, d4.dz, tol_d, "d4.dz vs SkyCiv");
}

// ─────────────────────────────────────────────────────────────────────────────
//  Test 6: Corotational vs P-Delta displacement comparison
//
//  Verify that corotational gives SMALLER displacements than P-Delta for this
//  large-rotation problem (corotational correctly accounts for geometric
//  stiffening from finite rotation, P-Delta is a linearized approximation).
//  Both must have correct force equilibrium.
// ─────────────────────────────────────────────────────────────────────────────
#[test]
fn test_084_corot_vs_pdelta_displacements() {
    // Corotational
    let mut corot_model = build_084_model();
    corot_model.settings.analysis_options.nonlinear_method = NonlinearMethod::COROTATIONAL;
    corot_model.normalize_units();
    corot_model.solve_for_load_case_second_order(1, 30).expect("corot solve");
    denorm_results_in_place(&mut corot_model);
    let r_corot = &corot_model.results.as_ref().unwrap().loadcases["End Load"];
    let d4_corot = r_corot.displacement_nodes.get(&4).unwrap();

    // P-Delta
    let mut pd_model = build_084_model();
    pd_model.settings.analysis_options.nonlinear_method = NonlinearMethod::P_DELTA;
    pd_model.normalize_units();
    pd_model.solve_for_load_case_second_order(1, 30).expect("pdelta solve");
    denorm_results_in_place(&mut pd_model);
    let r_pd = &pd_model.results.as_ref().unwrap().loadcases["End Load"];
    let d4_pd = r_pd.displacement_nodes.get(&4).unwrap();

    // For this large-rotation problem, corotational gives smaller displacements
    // (it correctly stiffens the structure through deformed-frame accounting).
    // P-Delta linearization overestimates the geometric softening.
    assert!(d4_corot.dz.abs() < d4_pd.dz.abs(),
        "Corot |dz| ({:.4}) should be < P-Delta |dz| ({:.4})",
        d4_corot.dz.abs(), d4_pd.dz.abs());

    // Both should have correct force equilibrium
    let rx_corot = r_corot.reaction_nodes.get(&1).unwrap().nodal_forces;
    let rx_pd = r_pd.reaction_nodes.get(&1).unwrap().nodal_forces;
    assert_close_ctx("corot_vs_pd", 1000.0, rx_corot.fy, 0.5, "Corot.Fy");
    assert_close_ctx("corot_vs_pd", 1000.0, rx_pd.fy, 0.5, "PDelta.Fy");
}
