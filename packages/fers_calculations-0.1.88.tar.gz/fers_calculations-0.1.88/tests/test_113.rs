#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// ============================================================================
// TEST 113: Long slender beam under torsion — warping effect vanishes
//
// For very long beams (kL >> 3), tanh(kL)/kL → 0, so Vlasov twist
// approaches St. Venant: θ ≈ TL/(GJ).
// ============================================================================
fn test_113_long_beam_warping_negligible_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_113_long_beam_warp", strategy, lu, fu, pu);

    let l_si = 20.0_f64;
    let t_si = 500.0_f64;
    let g_si = 81.0e9_f64;
    let e_si = 210.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_z_si = 8356.0e-8_f64;
    let i_y_si = 604.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let i_w_si = 126.0e-9_f64;

    let k = (g_si * j_si / (e_si * i_w_si)).sqrt();
    let kl = k * l_si;
    let theta_sv = t_si * l_si / (g_si * j_si);
    let theta_vlasov = theta_sv * (1.0 - kl.tanh() / kl);

    assert!(kl > 5.0, "Expected kL > 5, got {kl:.2}");

    let n_elem: u32 = 10;
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let t_user = t_si / (f * l);

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_W", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        Some(i_w_si), None, None,
    );

    model.nodal_supports.push(make_fixed_support(1));

    let mut nodes = Vec::new();
    let mut members = Vec::new();
    let tip_node_id = n_elem + 1;

    for i in 0..=n_elem {
        let x = (i as f64) * l_si / (n_elem as f64) / l;
        let sup_id = if i == 0 { Some(1) } else { None };
        nodes.push(make_node(i + 1, x, 0.0, 0.0, sup_id));
    }
    for i in 0..n_elem {
        members.push(make_beam_member(i + 1, &nodes[i as usize], &nodes[(i + 1) as usize], sec_id));
    }
    add_member_set(&mut model, 1, members);

    let lc_id = add_load_case(&mut model, 1, "End Torque");
    add_nodal_moment(&mut model, 1, lc_id, tip_node_id, t_user, (1.0, 0.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["End Torque"];
    let rx_end = res.displacement_nodes[&tip_node_id].rx;

    // Check FE matches analytical Vlasov (2% tolerance for 10-element mesh)
    let tol = theta_vlasov * 0.02;
    assert_close_ctx(&ctx, theta_vlasov, rx_end, tol, "long beam Vlasov twist");

    // Also verify close to St. Venant (within 10%)
    assert!(
        (rx_end - theta_sv).abs() / theta_sv < 0.10,
        "[{ctx}] Long beam twist should be within 10% of SV: got {rx_end}, SV = {theta_sv}"
    );
}

#[test]
fn test_113_long_beam_warping_negligible() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_113_long_beam_warping_negligible_case(strategy, lu, fu, pu);
        }
    }
}
