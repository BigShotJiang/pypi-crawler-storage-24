#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

use test_support::helpers::*;
use test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  083 — Double cantilever with tension-only rope member
//
//  N1(0,0,0) ── beam1 ── N2(5,0,0)
//                           │
//                         beam2
//                           │
//                        N3(5,5,0) ← F = +1000 N in Z
//                           │
//                         rope (tension-only)
//                           │
//                        N4(5,5,−1)
//
//  Supports:  N1, N2, N4 pinned (XYZ fixed, rotations free)
//  Checks:    Force equilibrium, rope in tension
// ─────────────────────────────────────────────────────────────────────────────

fn test_083_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("083_rope", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let force_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let force_u = force_si / f;

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    // Pinned support (shared by nodes 1, 2, 4)
    model.nodal_supports.push(make_support_custom(
        1,
        SupportConditionType::Fixed,
        SupportConditionType::Fixed,
        SupportConditionType::Fixed,
        SupportConditionType::Free,
        SupportConditionType::Free,
        SupportConditionType::Free,
    ));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 5.0 / l, 0.0, 0.0, Some(1));
    let n3 = make_node(3, 5.0 / l, 5.0 / l, 0.0, None);
    let n4 = make_node(4, 5.0 / l, 5.0 / l, -1.0 / l, Some(1));

    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
            make_tension_only_member(3, &n3, &n4, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 3, force_u, (0.0, 0.0, 1.0));

    model.normalize_units();
    model
        .solve_for_load_case(lc)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx1 = r.reaction_nodes.get(&1).unwrap().nodal_forces;
    let rx2 = r.reaction_nodes.get(&2).unwrap().nodal_forces;
    let rx4 = r.reaction_nodes.get(&4).unwrap().nodal_forces;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);

    // Global force equilibrium: applied +1000 Z → reactions sum to −1000 Z
    assert_close_ctx(&ctx, 0.0, rx1.fx + rx2.fx + rx4.fx, tol_f, "sum_Fx");
    assert_close_ctx(&ctx, 0.0, rx1.fy + rx2.fy + rx4.fy, tol_f, "sum_Fy");
    assert_close_ctx(
        &ctx,
        -force_u,
        rx1.fz + rx2.fz + rx4.fz,
        tol_f,
        "sum_Fz",
    );

    // Rope carries tension → node 4 reaction pushes down (negative Fz)
    assert!(
        rx4.fz < 0.0,
        "{ctx}: rope anchor should pull down, got Fz4={}",
        rx4.fz
    );
}

#[test]
fn test_083_rope_supported_beam_equilibrium() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_083_case(s, lu, fu, pu);
        }
    }
}
