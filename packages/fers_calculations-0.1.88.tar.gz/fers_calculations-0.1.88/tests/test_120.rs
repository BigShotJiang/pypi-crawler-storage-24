/// test_120: Two-frame portal with horizontal bracing — in-plane load
///           should NOT activate cross-aisle bracing.
///
/// Model (top view, looking down Z):
///
///     Frame A (X=0)                    Frame B (X=1.5m)
///     Node 1 ──────── member 5 ────── Node 5       (Y=2.0m, horizontal brace)
///       |                               |
///     Node 2 ──────── member 6 ────── Node 6       (Y=0.5m, horizontal brace)
///       |                               |
///     Node 3 (support)                Node 7 (support)
///
/// Side view of each frame (Y-Z plane):
///
///     Node 4 (Y=2.25m, Z=1.2m) ←── cantilever arm (member 3 or 8)
///       |  (rigid link member 4 or 9)
///     Node 1 (Y=2.0m, Z=0)
///       |
///     Node 2 (Y=0.5m, Z=0)          Uprights (members 1,2 or 6,7)
///       |
///     Node 3 (Y=0, Z=0) [fixed]
///
/// Members 5,6: horizontal bracing (X-direction), hinge 1 at both ends (My+Mz spring)
/// Members 10,11: diagonal bracing (tension-only)
///
/// Load: uniform distributed load on cantilever arms (members 3,8) in -Y direction
///       (product load, purely in-plane for each frame)
///
/// Expected: bracing members 5,6 should carry ~0 axial force because
///           the load is purely in the Y-Z plane of each frame.
///           The two frames are symmetric, so no X-force should develop.

#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::fers::fers::FERS;
use fers_calculations::models::members::memberhinge::MemberHinge;
use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

fn make_pin_hinge(id: u32, k_my: f64, k_mz: f64) -> MemberHinge {
    MemberHinge {
        id,
        hinge_type: "SPRING_YZ".to_string(),
        translational_release_vx: None,
        translational_release_vy: None,
        translational_release_vz: None,
        rotational_release_mx: None,
        rotational_release_my: Some(k_my),
        rotational_release_mz: Some(k_mz),
        rotational_release_warp: None,
        max_tension_vx: None,
        max_tension_vy: None,
        max_tension_vz: None,
        max_moment_mx: None,
        max_moment_my: None,
        max_moment_mz: None,
        max_bimoment_warp: None,
    }
}

// =========================================================
// Shared model builder — mirrors the real cantilever rack 1915 geometry.
//
// Side view of each frame (Y-Z plane, all in mm):
//
//     Cantilever tip (Y=2250, Z=1290)
//        \  (cantilever arm)
//     Node at (Y=2250, Z=90) -- rigid link to upright
//     |
//     Node at (Y=2000, Z=0) -- upper horizontal brace
//     |   \     /
//     |    X-bracing (diagonals, tension-only)
//     |   /     \
//     Node at (Y=500, Z=0) -- lower horizontal brace
//     |
//     Node at (Y=180, Z=0)
//     |
//     Support node (Y=90, Z=90) -- pinned support
//     |  (column foot, rigid link)
//     Node at (Y=90, Z=0)
//
// Two identical frames at X=0 and X=1500.
// Horizontal bracing runs in X between the frames at the two brace nodes.
// Diagonal bracing forms an X between the brace nodes (tension-only).
// =========================================================
fn build_120_model(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
    order: fers_calculations::models::settings::analysissettings::AnalysisOrder,
) -> (FERS, u32) {
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    model.settings.analysis_options.order = order;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    // Real cantilever rack geometry (mm converted to SI then to user units)
    let mm = 0.001 / l; // 1 mm in user length units
    let x_b   = 1500.0 * mm;
    let y_base = 90.0 * mm;  // support height
    let y_foot = 180.0 * mm;
    let y_lo   = 500.0 * mm; // lower brace
    let y_hi   = 2000.0 * mm; // upper brace
    let y_cant = 2250.0 * mm; // cantilever connection on upright
    let z_up   = 90.0 * mm;  // upright Z offset
    let z_cant = 1290.0 * mm; // cantilever tip Z

    // Distributed load: ~4 kN/m downward on cantilever arms
    let w_si = -4087.5; // N/m
    let w_user = w_si / (f / l);

    // Spring stiffness for bracing hinges (1e6 N·m/rad in My and Mz)
    let k_brace_si = 1.0e6;
    let k_brace = k_brace_si / (f * l);

    // Material
    let mat_id = add_material_s235(&mut model, 1);

    // Sections (real values from model 1915)
    let sec_upright = add_section(&mut model, 1, "Upright_IPE180", mat_id,
        26.2e-4, 1.009e-6, 13.17e-6, 4.79e-8);
    let sec_cant = add_section(&mut model, 2, "Cantilever_RHS", mat_id,
        7.54e-4, 16.09e-8, 7.07e-7, 2.72e-7);
    let sec_hbrace = add_section(&mut model, 3, "HBrace_50x80", mat_id,
        509.0e-6, 130.455e-9, 526.592e-9, 1.514e-9);
    let sec_dbrace = add_section(&mut model, 4, "DBrace_FL35x4", mat_id,
        160.0e-6, 213.0e-12, 21333.0e-12, 800.0e-12);

    // Supports: pinned (fixed translation, free rotation) at column feet
    use fers_calculations::models::supports::supportconditiontype::SupportConditionType;
    let sup_pin = make_support_custom(1,
        SupportConditionType::Fixed, SupportConditionType::Fixed, SupportConditionType::Fixed,
        SupportConditionType::Free, SupportConditionType::Free, SupportConditionType::Free);
    let sup_pin2 = make_support_custom(2,
        SupportConditionType::Fixed, SupportConditionType::Fixed, SupportConditionType::Fixed,
        SupportConditionType::Free, SupportConditionType::Free, SupportConditionType::Free);
    model.nodal_supports.push(sup_pin);
    model.nodal_supports.push(sup_pin2);

    // ---- Frame A (X=0) ----
    //  Column foot
    let na_sup  = make_node(1, 0.0, y_base, z_up, Some(1)); // support
    let na_foot = make_node(2, 0.0, y_foot, 0.0, None);
    //  Upright nodes (at Z=0, bracing plane)
    let na_lo   = make_node(3, 0.0, y_lo, 0.0, None);
    let na_hi   = make_node(4, 0.0, y_hi, 0.0, None);
    //  Cantilever connection (on upright at Z=90)
    let na_cant_conn = make_node(5, 0.0, y_cant, z_up, None);
    //  Cantilever tip
    let na_cant_tip  = make_node(6, 0.0, y_cant, z_cant, None);

    // ---- Frame B (X=1500) ----
    let nb_sup  = make_node(7, x_b, y_base, z_up, Some(2));
    let nb_foot = make_node(8, x_b, y_foot, 0.0, None);
    let nb_lo   = make_node(9, x_b, y_lo, 0.0, None);
    let nb_hi   = make_node(10, x_b, y_hi, 0.0, None);
    let nb_cant_conn = make_node(11, x_b, y_cant, z_up, None);
    let nb_cant_tip  = make_node(12, x_b, y_cant, z_cant, None);

    // ---- Members ----
    // Frame A: column foot rigid link (support -> foot base)
    let m_a_foot = make_rigid_member(1, &na_sup, &na_foot);
    // Frame A: uprights
    let m_a_up1 = make_beam_member(2, &na_foot, &na_lo, sec_upright);
    let m_a_up2 = make_beam_member(3, &na_lo, &na_hi, sec_upright);
    let m_a_up3 = make_beam_member(4, &na_hi, &na_cant_conn, sec_upright);
    // Frame A: cantilever arm (directly from upright node to tip)
    let m_a_cant = make_beam_member(5, &na_cant_conn, &na_cant_tip, sec_cant);

    // Frame B: column foot rigid link
    let m_b_foot = make_rigid_member(6, &nb_sup, &nb_foot);
    // Frame B: uprights
    let m_b_up1 = make_beam_member(7, &nb_foot, &nb_lo, sec_upright);
    let m_b_up2 = make_beam_member(8, &nb_lo, &nb_hi, sec_upright);
    let m_b_up3 = make_beam_member(9, &nb_hi, &nb_cant_conn, sec_upright);
    // Frame B: cantilever arm
    let m_b_cant = make_beam_member(10, &nb_cant_conn, &nb_cant_tip, sec_cant);

    // Horizontal bracing with spring hinges at both ends
    let hinge_brace = make_pin_hinge(1, k_brace, k_brace);
    model.memberhinges = Some(vec![hinge_brace]);

    let mut m_hb_lo = make_beam_member(11, &na_lo, &nb_lo, sec_hbrace);
    m_hb_lo.start_hinge = Some(1);
    m_hb_lo.end_hinge = Some(1);
    m_hb_lo.rotation_angle = 90.0; // degrees, converted by normalize_units()
    let mut m_hb_hi = make_beam_member(12, &na_hi, &nb_hi, sec_hbrace);
    m_hb_hi.start_hinge = Some(1);
    m_hb_hi.end_hinge = Some(1);
    m_hb_hi.rotation_angle = 90.0;

    // Diagonal bracing (tension-only X-pattern)
    let m_diag1 = make_tension_only_member(13, &na_lo, &nb_hi, sec_dbrace);
    let m_diag2 = make_tension_only_member(14, &na_hi, &nb_lo, sec_dbrace);

    add_member_set(&mut model, 1, vec![m_a_foot, m_a_up1, m_a_up2, m_a_up3]);
    add_member_set(&mut model, 2, vec![m_a_cant]);
    add_member_set(&mut model, 3, vec![m_b_foot, m_b_up1, m_b_up2, m_b_up3]);
    add_member_set(&mut model, 4, vec![m_b_cant]);
    add_member_set(&mut model, 5, vec![m_hb_lo, m_hb_hi]);
    add_member_set(&mut model, 6, vec![m_diag1, m_diag2]);

    // Load case: product load on cantilever arms
    let lc_id = add_load_case(&mut model, 1, "Product_load");
    add_distributed_load_uniform(&mut model, 1, lc_id, 5, w_user, (0.0, 1.0, 0.0), 0.0, 1.0);
    add_distributed_load_uniform(&mut model, 2, lc_id, 10, w_user, (0.0, 1.0, 0.0), 0.0, 1.0);

    (model, lc_id)
}

fn check_bracing_forces(model: &FERS, ctx: &str, f_to_n: f64, tol_n_si: f64) {
    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("Product_load")
        .unwrap();

    let tol_n = tol_force_user(tol_n_si, f_to_n);

    // Horizontal bracing members (11,12) should have ~0 axial force
    for mid in [11u32, 12] {
        let mr = res.member_results.get(&mid).unwrap_or_else(|| panic!("member {} missing", mid));
        let n_start = mr.start_node_forces.fx;
        let n_end = mr.end_node_forces.fx;
        assert_close_ctx(
            ctx, 0.0, n_start, tol_n,
            &format!("member {} start fx (hbrace, should be ~0)", mid),
        );
        assert_close_ctx(
            ctx, 0.0, n_end, tol_n,
            &format!("member {} end fx (hbrace, should be ~0)", mid),
        );
    }

    // Diagonal bracing (13,14) — tension-only, should carry ~0 for symmetric load
    for mid in [13u32, 14] {
        if let Some(mr) = res.member_results.get(&mid) {
            let n_start = mr.start_node_forces.fx;
            assert_close_ctx(
                ctx, 0.0, n_start, tol_n,
                &format!("member {} start fx (diag, should be ~0)", mid),
            );
        }
    }

    // Reactions: fx at support nodes should be ~0
    for nid in [1u32, 7] {
        if let Some(rx) = res.reaction_nodes.get(&nid) {
            let fx = rx.nodal_forces.fx;
            assert_close_ctx(
                ctx, 0.0, fx, tol_n,
                &format!("node {} reaction Fx (should be ~0)", nid),
            );
        }
    }
}

// =========================================================
// Test A: Linear analysis — symmetric in-plane load
//   Horizontal bracing should carry zero axial force.
// =========================================================
fn test_120a_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_120a_bracing_no_axial", strategy, lu, fu, pu);
    let (mut model, lc_id) = build_120_model(
        strategy, lu, fu, pu,
        fers_calculations::models::settings::analysissettings::AnalysisOrder::Linear,
    );
    let f = model.settings.unit_settings.force_to_n();

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    check_bracing_forces(&model, &ctx, f, 10.0);
}

#[test]
fn test_120a_bracing_no_axial_linear() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_120a_case(strategy, lu, fu, pu);
        }
    }
}

// =========================================================
// Test B: Nonlinear analysis — same check
//   Second-order effects should not create significant bracing forces
//   for a symmetric in-plane load.
// =========================================================
fn test_120b_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_120b_bracing_nonlinear", strategy, lu, fu, pu);
    let (mut model, lc_id) = build_120_model(
        strategy, lu, fu, pu,
        fers_calculations::models::settings::analysissettings::AnalysisOrder::Nonlinear,
    );
    let f = model.settings.unit_settings.force_to_n();

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Nonlinear analysis failed");
    denorm_results_in_place(&mut model);

    check_bracing_forces(&model, &ctx, f, 10.0);
}

#[test]
fn test_120b_bracing_no_axial_nonlinear() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_120b_case(strategy, lu, fu, pu);
        }
    }
}

// =========================================================
// Test C: Real cantilever rack model (1915) — Product_load_1
//   Loads the actual JSON input and checks that horizontal bracing
//   members 21,22 carry negligible axial force for in-plane loading.
// =========================================================
#[test]
fn test_120c_real_cantilever_rack_bracing() {
    use fers_calculations::analysis::calculate_from_json_internal;

    let json_path = concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/cantilever_rack_1915.json"
    );
    let json_str = std::fs::read_to_string(json_path)
        .expect("cantilever_rack_1915.json not found");

    // Force linear analysis and fix the over-generous axial_slack (500 → 1e-3)
    let mut data: serde_json::Value = serde_json::from_str(&json_str).unwrap();
    data["settings"]["analysis_options"]["order"] = serde_json::Value::String("Linear".into());
    data["settings"]["analysis_options"]["axial_slack"] = serde_json::json!(0.001);

    let result_str = calculate_from_json_internal(&data.to_string())
        .expect("FERS analysis failed");
    let result: serde_json::Value = serde_json::from_str(&result_str).unwrap();

    let lc = &result["results"]["loadcases"]["Product_load_1"];

    // Horizontal bracing members 21,22 should have ~0 axial force (fx)
    // The load is purely in-plane (Y-direction) and the structure is symmetric.
    // Tension-only diagonals should deactivate (they go into compression from
    // vertical shortening of the uprights), leaving the bracing unstressed.
    let tol = 10.0; // 10 N tolerance
    for mid in ["21", "22"] {
        let mr = &lc["member_results"][mid];
        let fx_start = mr["start_node_forces"]["fx"].as_f64().unwrap();
        let fx_end = mr["end_node_forces"]["fx"].as_f64().unwrap();
        assert!(
            fx_start.abs() < tol,
            "Member {} start fx = {:.1} N, expected ~0 (tol {}N)",
            mid, fx_start, tol
        );
        assert!(
            fx_end.abs() < tol,
            "Member {} end fx = {:.1} N, expected ~0 (tol {}N)",
            mid, fx_end, tol
        );
    }

    // Diagonal bracing members 23,24 (tension-only) should also be ~0
    for mid in ["23", "24"] {
        let mr = &lc["member_results"][mid];
        let fx_start = mr["start_node_forces"]["fx"].as_f64().unwrap();
        assert!(
            fx_start.abs() < tol,
            "Member {} start fx = {:.1} N, expected ~0 (tol {}N)",
            mid, fx_start, tol
        );
    }
}

// =========================================================
// Test D: Diagnostic isolation — strip features from the real model
//   one at a time to find what triggers the spurious bracing force.
//
//   Variants:
//     baseline : unmodified real model (should show ~100N bug)
//     no_diags : remove diagonal bracing members 23,24
//     no_cfoot_loads : remove loads on column feet members 7,17
//     no_diags_no_cfoot : remove both
//     no_rigid : replace rigid members 9,10,19,20 with normal beams
//     no_tension : change diagonal type from Tension to Normal
// =========================================================
#[test]
fn test_120d_diagnostic_isolation() {
    use fers_calculations::analysis::calculate_from_json_internal;

    let json_path = concat!(env!("CARGO_MANIFEST_DIR"), "/cantilever_rack_1915.json");
    let base_str = std::fs::read_to_string(json_path).expect("JSON not found");

    fn load_base(base_str: &str) -> serde_json::Value {
        let mut d: serde_json::Value = serde_json::from_str(base_str).unwrap();
        d["settings"]["analysis_options"]["order"] = serde_json::json!("Linear");
        // Remove all load cases except Product_load_1 (id=2) for speed
        if let Some(arr) = d["load_cases"].as_array() {
            let keep: Vec<serde_json::Value> = arr.iter()
                .filter(|lc| lc["id"].as_u64() == Some(2))
                .cloned().collect();
            d["load_cases"] = serde_json::json!(keep);
        }
        // Remove all load combinations for speed
        d["load_combinations"] = serde_json::json!([]);
        d
    }

    fn remove_members(data: &mut serde_json::Value, ids: &[u64]) {
        if let Some(sets) = data["member_sets"].as_array_mut() {
            for ms in sets.iter_mut() {
                if let Some(members) = ms["members"].as_array_mut() {
                    members.retain(|m| !ids.contains(&m["id"].as_u64().unwrap_or(0)));
                }
            }
            // Remove empty member sets
            sets.retain(|ms| {
                ms["members"].as_array().is_some_and(|a| !a.is_empty())
            });
        }
    }

    fn remove_loads_on_members(data: &mut serde_json::Value, member_ids: &[u64]) {
        if let Some(lcs) = data["load_cases"].as_array_mut() {
            for lc in lcs.iter_mut() {
                if let Some(dls) = lc["distributed_loads"].as_array_mut() {
                    dls.retain(|dl| !member_ids.contains(&dl["member"].as_u64().unwrap_or(0)));
                }
            }
        }
    }

    fn change_member_type(data: &mut serde_json::Value, ids: &[u64], new_type: &str) {
        if let Some(sets) = data["member_sets"].as_array_mut() {
            for ms in sets.iter_mut() {
                if let Some(members) = ms["members"].as_array_mut() {
                    for m in members.iter_mut() {
                        if ids.contains(&m["id"].as_u64().unwrap_or(0)) {
                            m["member_type"] = serde_json::json!(new_type);
                        }
                    }
                }
            }
        }
    }

    fn get_f64(v: &serde_json::Value, path: &[&str]) -> f64 {
        let mut cur = v;
        for &p in path { cur = &cur[p]; }
        cur.as_f64().unwrap_or(f64::NAN)
    }

    fn run_and_report(label: &str, data: &serde_json::Value) -> f64 {
        let result_str = match calculate_from_json_internal(&data.to_string()) {
            Ok(s) => s,
            Err(e) => { println!("[{label}]  FAILED: {e}"); return f64::NAN; }
        };
        let result: serde_json::Value = serde_json::from_str(&result_str).unwrap();
        let lc = &result["results"]["loadcases"]["Product_load_1"];

        let fx21 = get_f64(lc, &["member_results","21","start_node_forces","fx"]);
        let fx22 = get_f64(lc, &["member_results","22","start_node_forces","fx"]);
        let fx23 = get_f64(lc, &["member_results","23","start_node_forces","fx"]);
        let fx24 = get_f64(lc, &["member_results","24","start_node_forces","fx"]);

        // Brace node displacements (nodes 2,3=frameA, 13,14=frameB)
        // Nodes 3,14 at Y=500 (lower brace), nodes 2,13 at Y=2000 (upper brace)
        let dx3  = get_f64(lc, &["node_displacements","3","X"]);
        let dy3  = get_f64(lc, &["node_displacements","3","Y"]);
        let dx14 = get_f64(lc, &["node_displacements","14","X"]);
        let dy14 = get_f64(lc, &["node_displacements","14","Y"]);
        let dx2  = get_f64(lc, &["node_displacements","2","X"]);
        let dy2  = get_f64(lc, &["node_displacements","2","Y"]);
        let dx13 = get_f64(lc, &["node_displacements","13","X"]);
        let dy13 = get_f64(lc, &["node_displacements","13","Y"]);

        println!("[{label}]  m21={fx21:+.2} m22={fx22:+.2} m23={fx23:+.2} m24={fx24:+.2}");
        println!("  Lower brace: n3(dx={dx3:+.6},dy={dy3:+.6})  n14(dx={dx14:+.6},dy={dy14:+.6})  diff_x={:.6} diff_y={:.6}",
            dx3-dx14, dy3-dy14);
        println!("  Upper brace: n2(dx={dx2:+.6},dy={dy2:+.6})  n13(dx={dx13:+.6},dy={dy13:+.6})  diff_x={:.6} diff_y={:.6}",
            dx2-dx13, dy2-dy13);
        fx21
    }

    // --- Variant 1: baseline ---
    let d = load_base(&base_str);
    run_and_report("baseline (slack=500)", &d);

    // --- Variant 1b: reduce axial_slack to 1e-3 ---
    let mut d = load_base(&base_str);
    d["settings"]["analysis_options"]["axial_slack"] = serde_json::json!(0.001);
    run_and_report("slack=0.001", &d);

    // --- Variant 2: no diagonals (remove members 23,24) ---
    let mut d = load_base(&base_str);
    remove_members(&mut d, &[23, 24]);
    run_and_report("no_diags", &d);

    // --- Variant 3: no column feet loads (keep only cantilever loads) ---
    let mut d = load_base(&base_str);
    remove_loads_on_members(&mut d, &[7, 17]);
    run_and_report("no_cfoot_loads", &d);

    // --- Variant 4: diagonals changed from Tension to Normal ---
    let mut d = load_base(&base_str);
    change_member_type(&mut d, &[23, 24], "Normal");
    run_and_report("diags_normal", &d);

    // --- Variant 5: remove hinges from horizontal bracing (make them fully fixed) ---
    fn remove_hinges_from_members(data: &mut serde_json::Value, ids: &[u64]) {
        if let Some(sets) = data["member_sets"].as_array_mut() {
            for ms in sets.iter_mut() {
                if let Some(members) = ms["members"].as_array_mut() {
                    for m in members.iter_mut() {
                        if ids.contains(&m["id"].as_u64().unwrap_or(0)) {
                            m["start_hinge"] = serde_json::Value::Null;
                            m["end_hinge"] = serde_json::Value::Null;
                        }
                    }
                }
            }
        }
    }
    let mut d = load_base(&base_str);
    remove_hinges_from_members(&mut d, &[21, 22]);
    run_and_report("no_brace_hinges", &d);

    // --- Variant 6: remove all hinges (uprights, cantilevers, bracing) ---
    let mut d = load_base(&base_str);
    remove_hinges_from_members(&mut d, &[1, 8, 11, 18, 21, 22]);
    run_and_report("no_hinges_at_all", &d);

    // --- Variant 7: remove upright+cantilever hinges, keep bracing hinges ---
    let mut d = load_base(&base_str);
    remove_hinges_from_members(&mut d, &[1, 8, 11, 18]);
    run_and_report("no_upright_hinges", &d);

    // --- Variant 8: remove only upright base hinge (members 1,11) ---
    let mut d = load_base(&base_str);
    remove_hinges_from_members(&mut d, &[1, 11]);
    run_and_report("no_base_hinge", &d);

    // --- Variant 9: remove only cantilever hinge (members 8,18) ---
    let mut d = load_base(&base_str);
    remove_hinges_from_members(&mut d, &[8, 18]);
    run_and_report("no_cant_hinge", &d);

    println!("\n--- Symmetry check: if diff_x ≠ 0, the brace nodes move differently in X → diagonal forces ---");
    println!("--- Both diags in compression (Y-shortening) → tension-only should deactivate them ---");
    // The test always passes; we read the output with --nocapture
}

// =========================================================
// Test E: Diagnostic — run the SIMPLIFIED model and print diagonal forces
//   to compare with the real model. If the simplified model also shows
//   nonzero diagonal forces, the bug is in tension-only handling.
// =========================================================
#[test]
fn test_120e_simplified_diag_forces() {
    let strategy = RigidStrategy::RigidMember;
    let lu = LengthUnit::Mm;
    let fu = ForceUnit::N;
    let pu = PressureUnit::MPa;
    let (mut model, lc_id) = build_120_model(
        strategy, lu, fu, pu,
        fers_calculations::models::settings::analysissettings::AnalysisOrder::Linear,
    );
    let f_to_n = model.settings.unit_settings.force_to_n();

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = model.results.as_ref().unwrap()
        .loadcases.get("Product_load").unwrap();

    // Print diagonal forces (members 13,14 in simplified model)
    for mid in [13u32, 14] {
        if let Some(mr) = res.member_results.get(&mid) {
            let fx_s = mr.start_node_forces.fx;
            let fx_e = mr.end_node_forces.fx;
            println!("Simplified m{mid}: fx_start={:.4} fx_end={:.4} (N)",
                fx_s * f_to_n, fx_e * f_to_n);
        } else {
            println!("Simplified m{mid}: REMOVED (tension-only deactivated)");
        }
    }

    // Print horizontal bracing forces (members 11,12)
    for mid in [11u32, 12] {
        if let Some(mr) = res.member_results.get(&mid) {
            let fx_s = mr.start_node_forces.fx;
            println!("Simplified m{mid} (hbrace): fx_start={:.4} (N)", fx_s * f_to_n);
        }
    }

    // Print brace node displacements
    for nid in [3u32, 9, 4, 10] {
        if let Some(nd) = res.displacement_nodes.get(&nid) {
            println!("Simplified n{nid}: dx={:.6} dy={:.6} dz={:.6}",
                nd.dx, nd.dy, nd.dz);
        }
    }
}

// =========================================================
// Test G: K_geo hinge force recovery — global equilibrium check
//
//   In second-order (P_Delta) analysis, the force recovery for members
//   with spring hinges must include the condensed K_geo contribution.
//   Otherwise global equilibrium is violated: applying only Y-loads
//   produces non-zero total fz reactions.
//
//   This test loads the real cantilever rack 1915 model with P_Delta
//   and checks that the sum of fz reactions is near zero for a load case
//   with no Z-direction forces (Product_load_1).
// =========================================================
#[test]
fn test_120g_kgeo_hinge_equilibrium() {
    use fers_calculations::analysis::calculate_from_json_internal;

    let json_path = concat!(env!("CARGO_MANIFEST_DIR"), "/cantilever_rack_1915.json");
    let json_str = std::fs::read_to_string(json_path).expect("cantilever_rack_1915.json not found");

    let mut data: serde_json::Value = serde_json::from_str(&json_str).unwrap();
    data["settings"]["analysis_options"]["order"] = serde_json::json!("Nonlinear");
    data["settings"]["analysis_options"]["nonlinear_method"] = serde_json::json!("P_Delta");
    data["settings"]["analysis_options"]["axial_slack"] = serde_json::json!(0.001);
    // Only keep Product_load_1 (id=2) and remove combos for speed
    if let Some(arr) = data["load_cases"].as_array() {
        let keep: Vec<serde_json::Value> = arr
            .iter()
            .filter(|lc| lc["id"].as_u64() == Some(2))
            .cloned()
            .collect();
        data["load_cases"] = serde_json::json!(keep);
    }
    data["load_combinations"] = serde_json::json!([]);

    let result_str =
        calculate_from_json_internal(&data.to_string()).expect("Nonlinear analysis failed");
    let result: serde_json::Value = serde_json::from_str(&result_str).unwrap();

    let lc = &result["results"]["loadcases"]["Product_load_1"];
    let reactions = &lc["reaction_nodes"];

    // Sum fz across all support nodes
    let mut total_fz = 0.0;
    let mut total_fy = 0.0;
    if let Some(obj) = reactions.as_object() {
        for (_nid, r) in obj {
            total_fz += r["nodal_forces"]["fz"].as_f64().unwrap_or(0.0);
            total_fy += r["nodal_forces"]["fy"].as_f64().unwrap_or(0.0);
        }
    }

    println!("P_Delta equilibrium: total_fy = {total_fy:.4}, total_fz = {total_fz:.6}");

    // The load is purely in Y → total fz should be ~0
    // Before the K_geo fix, this was -11.3 N; after the fix it should be <0.01 N
    assert!(
        total_fz.abs() < 0.5,
        "Global fz equilibrium violated: total_fz = {total_fz:.4} N (expected ~0)"
    );

    // Sanity check: total fy should balance the applied load (~19620 N)
    assert!(
        (total_fy.abs() - 19620.0).abs() < 100.0,
        "Total fy = {total_fy:.1} N, expected ~19620 N"
    );
}

// =========================================================
// Test H: K_geo hinge equilibrium on the simplified model
//
//   Same equilibrium check as test_120g but on the simplified
//   build_120_model (12 nodes, 14 members).
// =========================================================
fn test_120h_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_120h_kgeo_equilibrium", strategy, lu, fu, pu);
    let (mut model, lc_id) = build_120_model(
        strategy,
        lu,
        fu,
        pu,
        fers_calculations::models::settings::analysissettings::AnalysisOrder::Nonlinear,
    );
    let f = model.settings.unit_settings.force_to_n();

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Nonlinear analysis failed");
    denorm_results_in_place(&mut model);

    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("Product_load")
        .unwrap();

    // Sum fz reactions at support nodes (1, 7)
    let mut total_fz_si = 0.0;
    for nid in [1u32, 7] {
        if let Some(rx) = res.reaction_nodes.get(&nid) {
            total_fz_si += rx.nodal_forces.fz * f;
        }
    }

    println!("[{ctx}] P_Delta total_fz = {total_fz_si:.6} N");
    // The simplified model has only bracing hinges (not upright hinges like
    // the real 1915 model), so a small fz residual from rigid-member
    // approximation and P-Delta coupling is acceptable.
    assert!(
        total_fz_si.abs() < 10.0,
        "[{ctx}] Global fz equilibrium violated: total_fz = {total_fz_si:.4} N (expected <10 N)"
    );
}

#[test]
fn test_120h_kgeo_hinge_equilibrium_simplified() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_120h_case(strategy, lu, fu, pu);
        }
    }
}
