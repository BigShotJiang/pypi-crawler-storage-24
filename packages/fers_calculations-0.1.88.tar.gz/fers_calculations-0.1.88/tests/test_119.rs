#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::members::memberhinge::MemberHinge;
use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// =========================================================
// 119: Force-vector condensation for beam with spring hinges
//      and distributed load (self-weight equivalent).
//
//  Model: Fixed-fixed beam, L=5m, uniform load w=-1000 N/m (gravity),
//         with My & Mz springs (k_spring) at BOTH ends.
//
//  When k_spring >> EI/L the beam is effectively fixed-fixed:
//      M_end = wL^2/12
//  When k_spring << EI/L the beam is effectively pinned-pinned:
//      M_end ~ 0
//  For finite k_spring:
//      M_end = wL^2/12 * alpha   where alpha = k / (k + 4EI/L)
//
//  This test verifies that force-vector condensation correctly
//  adjusts the equivalent nodal loads so that end moments match
//  the analytical formula.
// =========================================================

fn make_hinge_my_mz(id: u32, k_my: f64, k_mz: f64) -> MemberHinge {
    MemberHinge {
        id,
        hinge_type: "SPRING_YZ".to_string(),
        translational_release_vx: None,
        translational_release_vy: None,
        translational_release_vz: None,
        rotational_release_mx: None,
        rotational_release_my: Some(k_my),
        rotational_release_mz: Some(k_mz),
        rotational_release_warp: None,
        max_tension_vx: None,
        max_tension_vy: None,
        max_tension_vz: None,
        max_moment_mx: None,
        max_moment_my: None,
        max_moment_mz: None,
        max_bimoment_warp: None,
    }
}

// ---------------------------------------------------------
// Test A: Soft springs (k << EI/L)
//   End moments should be nearly zero (pinned-pinned).
// ---------------------------------------------------------
fn test_119a_soft_springs_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_119a_soft_springs", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let length_si = 5.0_f64;
    let w_si = -1000.0_f64; // N/m downward
    let e_si = 210.0e9_f64;
    let i_zz = SECOND_MOMENT_STRONG_AXIS_IN_M4; // ~13.21e-6 m^4

    // 4EI/L ~ 4 * 210e9 * 13.21e-6 / 5 = 2_219_280 N·m/rad
    // Use k = 1000 N·m/rad → ratio = 0.00045 → nearly pinned
    let k_spring_si = 1000.0_f64; // N·m/rad

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let w_user = w_si / (f / l); // N/m → user units
    let length_user = length_si / l;
    let k_user = k_spring_si / (f * l);

    let material_id = add_material_s235(&mut model, 1);
    let section_id = add_section_ipe180_like(&mut model, 1, material_id, i_zz);

    // Fixed supports at both ends
    model.nodal_supports.push(make_fixed_support(1));
    model.nodal_supports.push(make_fixed_support(2));

    let node1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2 = make_node(2, length_user, 0.0, 0.0, Some(2));

    let mut beam = make_beam_member(1, &node1, &node2, section_id);

    // Add spring hinges at both ends
    let hinge_a = make_hinge_my_mz(1, k_user, k_user);
    let hinge_b = make_hinge_my_mz(2, k_user, k_user);
    model.memberhinges = Some(vec![hinge_a, hinge_b]);
    beam.start_hinge = Some(1);
    beam.end_hinge = Some(2);

    add_member_set(&mut model, 1, vec![beam]);

    let lc_id = add_load_case(&mut model, 1, "UDL");
    add_distributed_load_uniform(&mut model, 1, lc_id, 1, w_user, (0.0, 1.0, 0.0), 0.0, 1.0);

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("UDL")
        .unwrap();

    // Analytical: alpha = k / (k + 4EI/L)
    let four_ei_over_l = 4.0 * e_si * i_zz / length_si;
    let alpha = k_spring_si / (k_spring_si + four_ei_over_l);
    let wl2_12 = w_si.abs() * length_si * length_si / 12.0;
    let m_end_expected_si = wl2_12 * alpha; // should be ~0.45 N·m (tiny)

    // Reaction moment at node 1
    let mz_1 = res.reaction_nodes.get(&1).unwrap().nodal_forces.mz;
    let mz_1_si = mz_1.abs() * f * l;

    // The end moment should be much smaller than wL²/12 (= 2083.3 N·m)
    // With alpha=0.00045, expected ≈ 0.94 N·m
    // Allow 5% tolerance on the analytical value, plus a small absolute floor
    let tol_si = m_end_expected_si * 0.05 + 1.0; // 5% + 1 N·m
    assert!(
        (mz_1_si - m_end_expected_si).abs() < tol_si,
        "{}: Soft spring end moment: got {:.4} N·m, expected {:.4} N·m (tol {:.4}). \
         Without condensation this would be ~{:.1} N·m (wL²/12)",
        ctx,
        mz_1_si,
        m_end_expected_si,
        tol_si,
        wl2_12,
    );

    // Mid-span moment should be close to wL²/8 (simply supported)
    // For nearly pinned: M_mid = wL²/8 - M_end ≈ wL²/8
    let wl2_8 = w_si.abs() * length_si * length_si / 8.0;
    let m_mid_expected_si = wl2_8 - m_end_expected_si;

    // Check mid-span moment via section forces (intermediate points).
    // Beam is along X, load in Y → bending is about Z axis → check mz.
    let member_res = res.member_results.get(&1).unwrap();
    let mid_section = member_res.section_forces.iter()
        .min_by(|a, b| ((a.x_frac - 0.5).abs()).partial_cmp(&(b.x_frac - 0.5).abs()).unwrap());
    if let Some(sf) = mid_section {
        let mz_mid_si = sf.forces.mz.abs() * f * l;
        let tol_mid = m_mid_expected_si * 0.05 + 5.0;
        assert!(
            (mz_mid_si - m_mid_expected_si).abs() < tol_mid,
            "{}: Mid-span Mz at midspan: got {:.2} N·m, expected {:.2} N·m (tol {:.2})",
            ctx,
            mz_mid_si,
            m_mid_expected_si,
            tol_mid,
        );
    }
}

// ---------------------------------------------------------
// Test B: Stiff springs (k >> EI/L)
//   End moments should match fixed-fixed: wL²/12.
// ---------------------------------------------------------
fn test_119b_stiff_springs_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_119b_stiff_springs", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let length_si = 5.0_f64;
    let w_si = -1000.0_f64;
    let _e_si = 210.0e9_f64;
    let _i_zz = SECOND_MOMENT_STRONG_AXIS_IN_M4;

    // k = 1e12 N·m/rad → essentially rigid
    let k_spring_si = 1.0e12_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let w_user = w_si / (f / l);
    let length_user = length_si / l;
    let k_user = k_spring_si / (f * l);

    let material_id = add_material_s235(&mut model, 1);
    let section_id = add_section_ipe180_like(&mut model, 1, material_id, _i_zz);

    model.nodal_supports.push(make_fixed_support(1));
    model.nodal_supports.push(make_fixed_support(2));

    let node1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2 = make_node(2, length_user, 0.0, 0.0, Some(2));

    let mut beam = make_beam_member(1, &node1, &node2, section_id);
    let hinge_a = make_hinge_my_mz(1, k_user, k_user);
    let hinge_b = make_hinge_my_mz(2, k_user, k_user);
    model.memberhinges = Some(vec![hinge_a, hinge_b]);
    beam.start_hinge = Some(1);
    beam.end_hinge = Some(2);

    add_member_set(&mut model, 1, vec![beam]);

    let lc_id = add_load_case(&mut model, 1, "UDL");
    add_distributed_load_uniform(&mut model, 1, lc_id, 1, w_user, (0.0, 1.0, 0.0), 0.0, 1.0);

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("UDL")
        .unwrap();

    let wl2_12 = w_si.abs() * length_si * length_si / 12.0; // 2083.33 N·m

    let mz_1 = res.reaction_nodes.get(&1).unwrap().nodal_forces.mz;
    let mz_1_si = mz_1.abs() * f * l;

    let tol_si = wl2_12 * 0.01; // 1% tolerance
    assert!(
        (mz_1_si - wl2_12).abs() < tol_si,
        "{}: Stiff spring end moment: got {:.2} N·m, expected {:.2} N·m (wL²/12, tol {:.2})",
        ctx,
        mz_1_si,
        wl2_12,
        tol_si,
    );
}

// ---------------------------------------------------------
// Test C: Free releases (k=0) → pinned-pinned
//   End moments should be exactly zero.
// ---------------------------------------------------------
fn test_119c_free_releases_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_119c_free_releases", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let length_si = 5.0_f64;
    let w_si = -1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let w_user = w_si / (f / l);
    let length_user = length_si / l;

    let material_id = add_material_s235(&mut model, 1);
    let section_id =
        add_section_ipe180_like(&mut model, 1, material_id, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    // Fixed supports at both ends. The Release hinges (k=0) disconnect
    // the beam's rotations from the nodes, so the beam behaves as pinned-pinned
    // even though the support nodes are fully fixed.
    model.nodal_supports.push(make_fixed_support(1));
    model.nodal_supports.push(make_fixed_support(2));

    let node1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2 = make_node(2, length_user, 0.0, 0.0, Some(2));

    let mut beam = make_beam_member(1, &node1, &node2, section_id);

    // k=0 → full release (pinned)
    let hinge_a = make_hinge_my_mz(1, 0.0, 0.0);
    let hinge_b = make_hinge_my_mz(2, 0.0, 0.0);
    model.memberhinges = Some(vec![hinge_a, hinge_b]);
    beam.start_hinge = Some(1);
    beam.end_hinge = Some(2);

    add_member_set(&mut model, 1, vec![beam]);

    let lc_id = add_load_case(&mut model, 1, "UDL");
    add_distributed_load_uniform(&mut model, 1, lc_id, 1, w_user, (0.0, 1.0, 0.0), 0.0, 1.0);

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("UDL")
        .unwrap();

    // Reactions should be wL/2 in Fy, zero moments
    let fy_1 = res.reaction_nodes.get(&1).unwrap().nodal_forces.fy;
    let fy_expected = (w_si.abs() * length_si / 2.0) / f;
    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    assert_close_ctx(&ctx, fy_1.abs(), fy_expected, tol_f, "Fy at pin support");

    // Mid-span moment = wL²/8 (check via section forces; beam along X, load in Y → Mz)
    let member_res = res.member_results.get(&1).unwrap();
    let mid_section = member_res.section_forces.iter()
        .min_by(|a, b| ((a.x_frac - 0.5).abs()).partial_cmp(&(b.x_frac - 0.5).abs()).unwrap());
    let wl2_8 = w_si.abs() * length_si * length_si / 8.0;
    if let Some(sf) = mid_section {
        let mz_mid_si = sf.forces.mz.abs() * f * l;
        let tol_m = wl2_8 * 0.05 + 5.0;
        assert!(
            (mz_mid_si - wl2_8).abs() < tol_m,
            "{}: Mid-span Mz: got {:.2} N·m, expected {:.2} N·m (wL²/8)",
            ctx,
            mz_mid_si,
            wl2_8,
        );
    }

    // Deflection = 5wL⁴/(384EI)
    let _dy_mid = res.displacement_nodes.get(&1).unwrap().dy; // not mid-node...
    // Actually, without a mid-node we can't easily check mid-span deflection.
    // Check that end-point reactions are symmetric instead.
    let fy_2 = res.reaction_nodes.get(&2).unwrap().nodal_forces.fy;
    assert_close_ctx(
        &ctx,
        fy_1.abs(),
        fy_2.abs(),
        tol_f,
        "Symmetric reactions for uniform load",
    );
}

// ---------------------------------------------------------
// Test D: Cantilever with spring hinge at fixed end + UDL
//   Analytical: M_end = wL²/2 * alpha
//   where alpha = k / (k + 3EI/L) for cantilever
// ---------------------------------------------------------
fn test_119d_cantilever_spring_hinge_udl_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_119d_cantilever_spring_udl", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let length_si = 5.0_f64;
    let w_si = -1000.0_f64;
    let _e_si = 210.0e9_f64;
    let i_zz = SECOND_MOMENT_STRONG_AXIS_IN_M4;

    // k = 100_000 N·m/rad → moderate spring
    let k_spring_si = 100_000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let w_user = w_si / (f / l);
    let length_user = length_si / l;
    let k_user = k_spring_si / (f * l);

    let material_id = add_material_s235(&mut model, 1);
    let section_id = add_section_ipe180_like(&mut model, 1, material_id, i_zz);

    model.nodal_supports.push(make_fixed_support(1));

    let node1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2 = make_node(2, length_user, 0.0, 0.0, None);

    let mut beam = make_beam_member(1, &node1, &node2, section_id);

    // Spring hinge only at the fixed end (node 1 side)
    let hinge_a = make_hinge_my_mz(1, k_user, k_user);
    model.memberhinges = Some(vec![hinge_a]);
    beam.start_hinge = Some(1);

    add_member_set(&mut model, 1, vec![beam]);

    let lc_id = add_load_case(&mut model, 1, "UDL");
    add_distributed_load_uniform(&mut model, 1, lc_id, 1, w_user, (0.0, 1.0, 0.0), 0.0, 1.0);

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("UDL")
        .unwrap();

    // Cantilever with rotational spring at root:
    //   theta_root = M_root / k
    //   M_root = wL²/2 - (wL⁴)/(8EI) * 0  ... actually need proper formula
    //
    // For a cantilever with root spring:
    //   M_root = wL²/2 * k / (k + 3EI/L)
    //   (derived from compatibility: theta_beam + theta_spring = theta_total)
    //
    // Actually for UDL cantilever: theta_free_end = wL³/(6EI), M_fixed = wL²/2
    // With spring at root: M_root = k * theta_root
    //   theta_root = (wL³/(6EI) + wL²/(2*k)*L/(EI)...) -- this gets complex.
    //
    // Simpler: use energy method or direct stiffness.
    // For cantilever with UDL and rotational spring at support:
    //   The beam rotation at the root due to UDL on a cantilever (free at root) = wL³/(24EI)
    //   ... Actually we need to think about this differently.
    //
    // The reaction moment at the support:
    //   Fixed cantilever: M = wL²/2 = 12500 N·m
    //   With spring: M = wL²/2 still (equilibrium!) but the spring moment is different.
    //
    // Wait: for a cantilever, equilibrium requires M_support = wL²/2 regardless of spring.
    // The spring only affects rotation at the root, not the moment!
    // So M_support = wL²/2 always.
    let wl2_2 = w_si.abs() * length_si * length_si / 2.0; // 12500 N·m
    let mz_1 = res.reaction_nodes.get(&1).unwrap().nodal_forces.mz;
    let mz_1_si = mz_1.abs() * f * l;

    let tol_si = wl2_2 * 0.01 + 1.0;
    assert!(
        (mz_1_si - wl2_2).abs() < tol_si,
        "{}: Cantilever support moment: got {:.2} N·m, expected {:.2} N·m (wL²/2). \
         Equilibrium requires this regardless of spring.",
        ctx,
        mz_1_si,
        wl2_2,
    );

    // Fy at support = wL
    let fy_1 = res.reaction_nodes.get(&1).unwrap().nodal_forces.fy;
    let fy_expected = (w_si.abs() * length_si) / f;
    let tol_fy = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    assert_close_ctx(&ctx, fy_1.abs(), fy_expected, tol_fy, "Fy at cantilever root");
}

// ---------------------------------------------------------
// Test E: No hinges (baseline) - verify condensation doesn't
//   change results when no hinges are present.
// ---------------------------------------------------------
fn test_119e_no_hinges_baseline_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_119e_no_hinges_baseline", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let length_si = 5.0_f64;
    let w_si = -1000.0_f64;
    let _e_si = 210.0e9_f64;
    let i_zz = SECOND_MOMENT_STRONG_AXIS_IN_M4;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let w_user = w_si / (f / l);
    let length_user = length_si / l;

    let material_id = add_material_s235(&mut model, 1);
    let section_id = add_section_ipe180_like(&mut model, 1, material_id, i_zz);

    model.nodal_supports.push(make_fixed_support(1));
    model.nodal_supports.push(make_fixed_support(2));

    let node1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let node2 = make_node(2, length_user, 0.0, 0.0, Some(2));

    let beam = make_beam_member(1, &node1, &node2, section_id);
    add_member_set(&mut model, 1, vec![beam]);

    let lc_id = add_load_case(&mut model, 1, "UDL");
    add_distributed_load_uniform(&mut model, 1, lc_id, 1, w_user, (0.0, 1.0, 0.0), 0.0, 1.0);

    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("UDL")
        .unwrap();

    let wl2_12 = w_si.abs() * length_si * length_si / 12.0;
    let mz_1 = res.reaction_nodes.get(&1).unwrap().nodal_forces.mz;
    let mz_1_si = mz_1.abs() * f * l;

    let tol_mz = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);
    assert_close_ctx(
        &ctx,
        mz_1_si / (f * l),
        wl2_12 / (f * l),
        tol_mz,
        "Fixed-fixed end moment (no hinges, baseline)",
    );

    // Deflection at mid-span: wL⁴/(384EI)
    // (no mid-node, so check reactions are symmetric)
    let fy_1 = res.reaction_nodes.get(&1).unwrap().nodal_forces.fy;
    let fy_2 = res.reaction_nodes.get(&2).unwrap().nodal_forces.fy;
    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let fy_expected = (w_si.abs() * length_si / 2.0) / f;
    assert_close_ctx(&ctx, fy_1.abs(), fy_expected, tol_f, "Fy at node 1");
    assert_close_ctx(&ctx, fy_2.abs(), fy_expected, tol_f, "Fy at node 2");
}

#[test]
fn test_119a_soft_springs() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_119a_soft_springs_case(strategy, lu, fu, pu);
        }
    }
}

#[test]
fn test_119b_stiff_springs() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_119b_stiff_springs_case(strategy, lu, fu, pu);
        }
    }
}

#[test]
fn test_119c_free_releases() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_119c_free_releases_case(strategy, lu, fu, pu);
        }
    }
}

#[test]
fn test_119d_cantilever_spring_hinge_udl() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_119d_cantilever_spring_hinge_udl_case(strategy, lu, fu, pu);
        }
    }
}

#[test]
fn test_119e_no_hinges_baseline() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_119e_no_hinges_baseline_case(strategy, lu, fu, pu);
        }
    }
}
