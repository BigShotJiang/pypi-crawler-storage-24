#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// =========================================================
// 004: Cantilever with partial uniform distributed load
// (check reaction moment)
// =========================================================

fn test_004_cantilever_partial_uniform_distributed_load_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx(
        "test_004_cantilever_partial_uniform_distributed_load",
        strategy,
        lu,
        fu,
        pu,
    );
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    // Physical (SI)
    let l_si = 5.0_f64;
    let w_si = 1000.0_f64;
    let start_frac = 0.4_f64; // 2.0 m
    let end_frac = 0.7_f64; // 3.5 m

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x1 = 0.0;
    let x2 = l_si / l;
    let w_user = w_si * l / f;

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_ipe180_like(&mut model, 1, mat_id, 13.21e-6_f64);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, x1, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);

    let m = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m]);

    let lc_id = add_load_case(&mut model, 1, "Partial Uniform Load");

    add_member_distributed_load_global_y(
        &mut model, 1, lc_id, 1, w_user, w_user, start_frac, end_frac,
    );
    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["Partial Uniform Load"];

    let mz_fixed = res.reaction_nodes[&1].nodal_forces.mz;

    // Analytical: equivalent resultant and its lever arm
    let x_start = start_frac * l_si;
    let x_end = end_frac * l_si;
    let w_len = x_end - x_start;
    let r_si = w_si * w_len;
    let x_res = 0.5 * (x_start + x_end);
    let mz_si = r_si * x_res;

    let mz_exp = -mz_si / (f * l);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    assert_close_ctx(&ctx, mz_fixed, mz_exp, tol_m, "moment at fixed support");
}

#[test]
fn test_004_cantilever_partial_uniform_distributed_load() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_004_cantilever_partial_uniform_distributed_load_case(strategy, lu, fu, pu);
        }
    }
}
