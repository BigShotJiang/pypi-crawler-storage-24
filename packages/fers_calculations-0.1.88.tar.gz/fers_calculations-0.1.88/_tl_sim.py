import numpy as np

# Cross-check section (real IPE180 with rotation angles)
E = 210000.0   # N/mm2
G = 80769.0
Iy = 13210000.0  # mm4 (strong about Y)
Iz = 1010000.0   # mm4 (weak about Z)
J = 48437.0      # mm4
A = 2401.0       # mm2
L = 1000.0
P = 1000.0

def beam_k_local(E, G, A, Iy, Iz, J, L):
    k = np.zeros((14, 14))
    ea_l = E*A/L
    k[0,0] = ea_l; k[7,7] = ea_l; k[0,7] = k[7,0] = -ea_l
    eiz = E*Iz; l2=L*L; l3=l2*L
    k[1,1] = 12*eiz/l3;  k[1,5] = k[5,1] = 6*eiz/l2
    k[1,8] = k[8,1] = -12*eiz/l3; k[1,12] = k[12,1] = 6*eiz/l2
    k[5,5] = 4*eiz/L;    k[5,8] = k[8,5] = -6*eiz/l2
    k[5,12] = k[12,5] = 2*eiz/L
    k[8,8] = 12*eiz/l3;  k[8,12] = k[12,8] = -6*eiz/l2
    k[12,12] = 4*eiz/L
    eiy = E*Iy
    k[2,2] = 12*eiy/l3;  k[2,4] = k[4,2] = -6*eiy/l2
    k[2,9] = k[9,2] = -12*eiy/l3; k[2,11] = k[11,2] = -6*eiy/l2
    k[4,4] = 4*eiy/L;    k[4,9] = k[9,4] = 6*eiy/l2
    k[4,11] = k[11,4] = 2*eiy/L
    k[9,9] = 12*eiy/l3;  k[9,11] = k[11,9] = 6*eiy/l2
    k[11,11] = 4*eiy/L
    gj_l = G*J/L
    k[3,3] = gj_l; k[10,10] = gj_l; k[3,10] = k[10,3] = -gj_l
    k[6,6] = 1e-6; k[13,13] = 1e-6
    return k

def beam_kgeo_local(N, L):
    k = np.zeros((14, 14))
    p_l = N / L; pL = N * L
    k[0,0] = p_l; k[0,7] = -p_l; k[7,0] = -p_l; k[7,7] = p_l
    # Y-bending (DOFs 1,5,8,12)
    k[1,1] = 6/5*p_l; k[1,5]=k[5,1]=pL/10; k[1,8]=k[8,1]=-6/5*p_l; k[1,12]=k[12,1]=pL/10
    k[5,5]=4/15*pL; k[5,8]=k[8,5]=-pL/10; k[5,12]=k[12,5]=2/15*pL
    k[8,8]=6/5*p_l; k[8,12]=k[12,8]=-pL/10
    k[12,12]=4/15*pL
    # Z-bending (DOFs 2,4,9,11)
    k[2,2]=6/5*p_l; k[2,4]=k[4,2]=pL/10; k[2,9]=k[9,2]=-6/5*p_l; k[2,11]=k[11,2]=pL/10
    k[4,4]=4/15*pL; k[4,9]=k[9,4]=-pL/10; k[4,11]=k[11,4]=2/15*pL
    k[9,9]=6/5*p_l; k[9,11]=k[11,9]=-pL/10
    k[11,11]=4/15*pL
    return k

def build_T(R):
    T = np.zeros((14, 14))
    for node in range(2):
        b = node * 7
        T[b:b+3, b:b+3] = R
        T[b+3:b+6, b+3:b+6] = R
        T[b+6, b+6] = 1.0
    return T

# Local frames WITH rotation angles
# Member 1: along X, rotation=90 deg
lx1 = np.array([1,0,0], dtype=float)
ly1_base = np.array([0,1,0], dtype=float)
lz1_base = np.array([0,0,1], dtype=float)
phi1 = np.radians(90)
ly1 = np.cos(phi1)*ly1_base + np.sin(phi1)*lz1_base  # [0,0,1]
lz1 = -np.sin(phi1)*ly1_base + np.cos(phi1)*lz1_base  # [0,-1,0]
R1 = np.array([lx1, ly1, lz1])

# Member 2: along Y, rotation=0, ref=[0,0,1] fallback
R2 = np.array([[0,1,0],[0,0,1],[1,0,0]], dtype=float)

# Member 3: along Z, rotation=90 deg
lx3 = np.array([0,0,1], dtype=float)
# ref=[0,1,0], lz=lx x ref = [0,0,1]x[0,1,0] = [-1,0,0], ly=lz x lx = [-1,0,0]x[0,0,1] = [0,1,0]
# Wait let me compute: [0,0,1]x[0,1,0] = [0*0-1*1, 1*0-0*0, 0*1-0*0] = [-1,0,0]
lz3_base = np.array([-1,0,0], dtype=float)
ly3_base = np.cross(lz3_base, lx3)  # [-1,0,0]x[0,0,1] = [0*1-0*0, 0*0-(-1)*1, (-1)*0-0*0] = [0,1,0]
phi3 = np.radians(90)
ly3 = np.cos(phi3)*ly3_base + np.sin(phi3)*lz3_base  # 0*[0,1,0]+1*[-1,0,0] = [-1,0,0]
lz3 = -np.sin(phi3)*ly3_base + np.cos(phi3)*lz3_base  # -1*[0,1,0]+0*[-1,0,0] = [0,-1,0]
R3 = np.array([lx3, ly3, lz3])

print("R1:", R1)
print("R2:", R2)
print("R3:", R3)

T1 = build_T(R1); T2 = build_T(R2); T3 = build_T(R3)
k_local = beam_k_local(E, G, A, Iy, Iz, J, L)

ndof = 28
free = list(range(7, 28))
fixed = list(range(0, 7))
dofs1 = list(range(0,7)) + list(range(7,14))
dofs2 = list(range(7,14)) + list(range(14,21))
dofs3 = list(range(14,21)) + list(range(21,28))

F_full = np.zeros(ndof)
F_full[22] = -P  # -1000N in Y at node 4

def assemble_K(u_full=None):
    K = np.zeros((ndof, ndof))
    for Ti, dofs in [(T1, dofs1), (T2, dofs2), (T3, dofs3)]:
        kg = Ti.T @ k_local @ Ti
        for i in range(14):
            for j in range(14):
                K[dofs[i], dofs[j]] += kg[i, j]
    if u_full is not None:
        # Add K_geo
        for mid, (Ti, dofs, Ri) in enumerate([(T1, dofs1, R1), (T2, dofs2, R2), (T3, dofs3, R3)]):
            u_elem = np.zeros(14)
            for i in range(14):
                u_elem[i] = u_full[dofs[i]]
            u_loc = Ti @ u_elem
            ext = u_loc[7] - u_loc[0]
            N = E * A / L * ext
            if abs(N) > 250:  # slack tolerance
                kg_local = beam_kgeo_local(N, L)
                kg_global = Ti.T @ kg_local @ Ti
                for i in range(14):
                    for j in range(14):
                        K[dofs[i], dofs[j]] += kg_global[i, j]
    return K

# First-order solve
K0 = assemble_K()
K_ff = K0[np.ix_(free, free)]
F_f = F_full[free]
u_f = np.linalg.solve(K_ff, F_f)
u_1st = np.zeros(ndof)
u_1st[free] = u_f
print(f"\nFirst-order: rx_n2 = {u_1st[10]:.6f} rad, dy_n4 = {u_1st[22]:.4f} mm")

# TL N-R solver
n_steps = 20
u_full = u_1st.copy()  # warm start with first-order
max_iter = 30
tol = 1e-6

for step in range(1, n_steps+1):
    lam = step / n_steps
    F_lam = F_full * lam
    for it in range(max_iter):
        K_total = assemble_K(u_full)
        K_ff = K_total[np.ix_(free, free)]
        F_f = F_lam[free]
        r = K_ff @ u_full[free] - F_f
        res = np.linalg.norm(r) / max(np.linalg.norm(F_f), 1)
        if res < tol:
            break
        du = np.linalg.solve(K_ff, -r)
        u_full[free] += du
    
print(f"TL second-order: rx_n2 = {u_full[10]:.6f} rad, dy_n4 = {u_full[22]:.4f} mm")
print(f"Ratio rx: {u_full[10] / u_1st[10]:.4f}")
# Compute Mx at node 1 from member 1 torsion
Mx = G * J / L * u_full[10]
print(f"Member 1 torsion Mx = {Mx:.0f} N.mm")
