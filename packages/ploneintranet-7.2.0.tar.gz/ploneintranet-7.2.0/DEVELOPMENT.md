# DEVELOPMENT

Here are some basic guidelines for developing for Quaive.

## pre-commit

Quaive uses pre-commit (<https://pre-commit.com/>) to manage git hooks.
The pre-commit hooks are based on the standard ones chosen by the Plone community.

To run the pre-commit hooks, run:

```bash
make pre-commit
```

If you want the pre-commit hooks to run at every commit, you need to install
them first.

To install the pre-commit hooks, run:

```bash
make pre-commit-install
```

To update the pre-commit hooks to their latest versions, run:

```bash
make pre-commit-update
```

Note that if your code is not compliant with the pre-commit hooks, the Jenkins
tests will immediately fail and your PR will be blocked.
