# Changelog

<!-- towncrier release notes start -->

## [7.2.0](https://github.com/quaive/ploneintranet/tree/7.2.0) - 2026-03-18

### Added

- Add the Image bank app (Issue [#5777](https://github.com/quaive/ploneintranet/issues/5777))
- Add a multiple file input widget.
  It can be used to upload multiple files to a form.
  The plan is to use this widget to upload files to the image bank.
- Make the AjaxSelectWidget work with pat-autosuggest.
- Add a PrincipalSource that can be used in the AjaxSelectWidget
  to query the users and groups
- Add the new widgets to the @@component-library view (Issue [#5465](https://github.com/quaive/ploneintranet/issues/5465))
- Added a JSON view for programmatically monitoring the number of users.
  [cirosilvano] (Issue [#5760](https://github.com/quaive/ploneintranet/issues/5760))

### Fixed

- When adding an event from the calendar app,
  do not inject the workspace events sidebar.
  (Issue [#5673](https://github.com/quaive/ploneintranet/issues/5673))
- Fixed the password reset form to hide hints if there are errors in the same field.
  [cirosilvano, thet] (Issue [#5767](https://github.com/quaive/ploneintranet/issues/5767))
- Sync the password form markup with prototype.
  [cirosilvano, thet] (Issue [#5767](https://github.com/quaive/ploneintranet/issues/5767))
- Aligned password minimum length hints with true values.
  [cirosilvano] (Issue [#5771](https://github.com/quaive/ploneintranet/issues/5771))
- A user has "`<english only>`" in the person_title field
  and is subscribed to email notifications.
  The title is used in the email recipient address:
  `<english only> First Last <email@example.org>` which is invalid
  and causes the emails to fail.
  In the logs, it looks as if the "To:" address is empty.
  To fix this, use email.utils.formataddr to quote invalid characters
  when necessary.
  (Issue [#5800](https://github.com/quaive/ploneintranet/issues/5800))
- Remove hardcoded character limit from password reset and creation hints.
  (Issue [#5803](https://github.com/quaive/ploneintranet/issues/5803))
- Fix auto suggest widget for vocabularies.
  [maurits]

### Technical

- Remove the upgrade steps already present in 6.0.0. (Issue [#5772](https://github.com/quaive/ploneintranet/issues/5772))
- Switch to collective.ftw.upgrade (Issue [#5774](https://github.com/quaive/ploneintranet/issues/5774))
- Improve the panel template configurability (Issue [#5777](https://github.com/quaive/ploneintranet/issues/5777))
- Add the pins for `pas.plugins.oidc`.
- Log the exception happening when the rest password fails.
  This will help understanding what is happening (e.g. the user has no email set).
  [ale-rt]
- Prettify the templates in the activitystrem folder
- Remove old and unused plone52.cfg
- Update the pre-commit hooks
- Use buildout 5 and horse-with-no-namespace in order to be able
  to use collective packages that are already using native namespaces.

### Updated

- Upgrade plone.patternslib to 9.10.4.
  [thet]
- Use Plone 6.1.4

## 7.1.0 (2026-01-14)

Added:

- When env variable `TEST_SITE_MARKER` is set, style the login differently,
  and show a banner on all pages.
  You can specify extra text for the login page in the new
  `login_test_site_explanation` registry record.
  (Issue [#4284](https://github.com/quaive/ploneintranet/issues/4284))
- Improve calendar event moderation: link to accept/decline dialogue
  from web notification, and show event details in moderation panel.
  (Issue [#5725](https://github.com/quaive/ploneintranet/issues/5725))
- Support preview generation when modifying files with quaive.app.collabora.
  (Issue [#5746](https://github.com/quaive/ploneintranet/issues/5746))

Changed:

- Suppress calendar review notifications, when they became stale.
  (Issue [#5725](https://github.com/quaive/ploneintranet/issues/5725))
- Improve calendar event moderation: auto-accept events into a shared calendar,
  when the submitting user is managing the central calendar.
  (Issue [#5729](https://github.com/quaive/ploneintranet/issues/5729))

Fixed:

- Fix task view in todo app to not show a excessive huge assignee portrait
  but a generic person icon.
  (Issue [syslabcom/scrum#3990](https://github.com/syslabcom/scrum/issues/3990))
- Fix contacts search relevancy ranking.
  (Issue [#5717](https://github.com/quaive/ploneintranet/issues/5717))
- Fix search results count and infinite scrolling
  (Issue [#5718](https://github.com/quaive/ploneintranet/issues/5718))
- Fix improper handling of retraction in event workflow.
  (Issue [#5722](https://github.com/quaive/ploneintranet/issues/5722))
- Improve calendar event moderation: use the right adapter
  when declining an event.
  (Issue [#5733](https://github.com/quaive/ploneintranet/issues/5733))

Technical:

- Allow to extend the userprofile tabs.
  The userprofile tabs can now be extended
  via generic setup using portal actions.
  (Issue [syslabcom/scrum#4126](https://github.com/syslabcom/scrum/issues/4126))
- Zpretty format `event_view.pt`
  (Issue [#5730](https://github.com/quaive/ploneintranet/issues/5730))
- Remove unneeded auth mangling when executing asynctasks with Celery,
  which interfered with Bearer authentication.
  (Issue [#5746](https://github.com/quaive/ploneintranet/issues/5746))
- Extend the pre-commit configuration To be aligned with plone/meta.
- Switch the README and CHANGES files to markdown
- Unify retrieval of portal actions.
  Use the `actions` method from the `@@plone_context_state` view to retrieve
  the actions, already filtered for available, allowed and visible attributes.
  This also prevents a problem where all portal actions are listed and evaluated
  via `portal_actions.listFilteredActionsFor` and break for the
  `userprofile_tabs` actions, which use a restricted view to evaluate the
  `available` attribute.

Updated:

- Update quaive.resources.ploneintranet to 11.4.0.

## 7.0.3 (2025-11-28)

Fixed:

- Don't inject workspace event sidebar when editing event in
  calendar. ([Issue
  #4610](https://github.com/quaive/ploneintranet/issues/4610))

## 7.0.2 (2025-11-25)

Added:

- Automatic vertical cropping of news item hero images can be disabled
  per news item. A sitewide setting makes it possible to opt out of
  news item hero image vertical cropping, by default, while retaining
  the possibility to change that choice per news item. ([Issue
  #5692](https://github.com/quaive/ploneintranet/issues/5692))

Fixed:

- Store news item effective as UTC, not local time. This fixes a
  mismatch with the notifications event subscriber. This does not
  impact the UI rendered effective date: to change that, change the OS
  timezone. ([Issue
  #5689](https://github.com/quaive/ploneintranet/issues/5689))
- Bring news item h1 markup in line with proto. ([Issue
  #5691](https://github.com/quaive/ploneintranet/issues/5691))
- Update the markup in the trash sidebar to fix some style issues.

Technical:

- Zpretty news templates ([Issue
  #5692](https://github.com/quaive/ploneintranet/issues/5692))
- editorconfig: Don't use inline comments. Inline comments are
  invalid since editorconfig v0.15.0.

Updated:

- Upgraded quaive.resources.ploneintranet to 11.3.3 ([Issue
  #5692](https://github.com/quaive/ploneintranet/issues/5692))

## 7.0.1 (2025-11-06)

Fixed:

- Fix notification scheduling with postgres, when postgres is running
  in a non-UTC timezone. ([Issue
  #5686](https://github.com/quaive/ploneintranet/issues/5686))

Updated:

- Update quaive.resources.ploneintranet to 11.3.2. [thet]
- Use Plone 6.1.3

## 7.0.0 (2025-10-07)

Changed:

- The News performance has been improved with the adoption of a Solr
  engine. ([Issue
  #1963](https://github.com/quaive/ploneintranet/issues/1963))
- Do no longer show metadata icon as a toplevel action in the
  workspace toolbar. The metadata action is still available in both
  the main toolbar context menu and in the sidebar context menus.
  ([Issue #5676](https://github.com/quaive/ploneintranet/issues/5676))

Fixed:

- Remove metadata icon that caused display weirdness on mobile
  devices. ([Issue
  #5676](https://github.com/quaive/ploneintranet/issues/5676))

- Fix German translations for workspace members.

  In German some translations were mentioning "Benutzer" instead of
  "Mitglied" for workspace members. Ref: scrum-3797 [thet]

- Fix a problem with contacts app sidebar extra links, where link
  would not open on small/mobile screens. Fixed by aligning with
  prototype. Ref: scrum-3951 [thet]

Updated:

- quaive.resources.ploneintranet = 11.3.1

## 6.3.1 (2025-09-16)

Added:

- Allow to show Link content types from the contacts app container in
  the contacts sidebar. Ref: scrum-3825 [thet]

Changed:

- Let site administrators be able to edit other user profile's avatar
  picture. ([Issue
  #5669](https://github.com/quaive/ploneintranet/issues/5669))

Fixed:

- Fix sticky sidebar, without the pat-scroll-box class on #sidebar,
  the content of the sidebar is displayed on top of the toolbar. For
  #workspace-settings, the expand button should not be sticky,
  according to proto. ([Issue
  #3802](https://github.com/syslabcom/scrum/issues/3802))
- Make the contacts and profiles search more customizable ([Issue
  #4666](https://github.com/quaive/ploneintranet/issues/4666))
- When editing another user's profile, change the target user, not
  the admin avatar. When editing an avatar, visually update the shown
  avatar immediately. ([Issue
  #5669](https://github.com/quaive/ploneintranet/issues/5669))
- Fix PDF file sharing: content_type_name was a callable, so it was
  never equal to "PDF", leading to an incorrect entry in
  share-panel. ([Issue
  #5673](https://github.com/quaive/ploneintranet/issues/5673))
- Improve the user profile view by improving the logic to show/hide
  the edit buttons in the user profile view.

Technical:

- Move avatar editing handler from ploneintranet.layout to
  ploneintranet.userprofile ([Issue
  #5669](https://github.com/quaive/ploneintranet/issues/5669))

Updated:

- collective.honeypot = 4.0.0
- Upgrade plone.patternslib to 9.10.4.1a0 and
  quaive.resources.ploneintranet to 11.3.0. [thet]

## 6.3.0 (2025-08-27)

Added:

- Add `panel_miller_columns`: a panel that uses "Miller Columns" for
  selecting content. This can only be used within a widget. Added a
  widget that uses this panel. ([Issue
  #5511](https://github.com/quaive/ploneintranet/issues/5511))
- Added warning about jitsi app to video conference page ([Issue
  #5661](https://github.com/quaive/ploneintranet/issues/5661))
- Allow the search results in the Contacts tab to be customized

Changed:

- Continue effort to modernize workspace editing toolbar and UI, in
  preparation for Collabora integration. ([Issue
  #5579](https://github.com/quaive/ploneintranet/issues/5579))

  > - Extract metadata editing to panel ([Issue
  >   #5582](https://github.com/quaive/ploneintranet/issues/5582))
  > - Show save button only when actually editing ([Issue
  >   #5582](https://github.com/quaive/ploneintranet/issues/5582))
  > - Add metadata editing link to context menu (Part of [Issue
  >   #5584](https://github.com/quaive/ploneintranet/issues/5584))
  > - Bring toolbark markup up-to-date with proto ([Issue
  >   #5585](https://github.com/quaive/ploneintranet/issues/5585))
  > - Disable context menu on trashed items (Part of [Issue
  >   #5584](https://github.com/quaive/ploneintranet/issues/5584))
  > - Implement quaive.app.collabora integration hook ([Issue
  >   #5592](https://github.com/quaive/ploneintranet/issues/5592))
  > - Improve view on emails ([Issue
  >   #modernize-toolbar-markup](https://github.com/quaive/ploneintranet/issues/modernize-toolbar-markup))

Fixed:

- Port the view to remove old notifications to the notification system
  ([Issue #4321](https://github.com/quaive/ploneintranet/issues/4321))
- Fix `component-library` test page to display the submitted values
  after saving. ([Issue
  #5511](https://github.com/quaive/ploneintranet/issues/5511))
- Change the target of the form that publishes a document to the
  library because it does not exist anymore. ([Issue
  #5632](https://github.com/quaive/ploneintranet/issues/5632))
- Fix "published the document" translation for NL. ([Issue
  #5633](https://github.com/quaive/ploneintranet/issues/5633))
- Non external apps can be modified again. ([Issue
  #5654](https://github.com/quaive/ploneintranet/issues/5654))
- Make the panel that publish to the library handle the use case when
  a folder is accessible to the publisher but the parent is not.

Technical:

- The package is now tested with Python 3.13 ([Issue
  #5651](https://github.com/quaive/ploneintranet/issues/5651))
- Remove redirect-on-login backport from Plone 6.1.2 now we are on
  Plone 6.1.2. ([Issue
  #5622](https://github.com/quaive/ploneintranet/issues/5622))

Updated:

- Update to:
  - Plone = 6.1.2
  - billiard = 4.2.1
  - celery = 5.5.1
  - ftw.upgrade = 3.4.0a3+slc0
  - greenlet = 3.1.1
  - mr.scripty = 2.0.1
  - Products.membrane = 7.0.0
  - Use supervisor 4.3.0a1+slc0
- Update z3c packages to use native namespaces ([Issue
  #5614](https://github.com/quaive/ploneintranet/issues/5614))

## 6.2.3 (2025-07-17)

Changed:

- Continue effort to modernize workspace editing toolbar and UI, in
  preparation for Collabora integration. ([Issue
  #5579](https://github.com/quaive/ploneintranet/issues/5579))
  - Move link open action into context menu (Part of [Issue
    #5584](https://github.com/quaive/ploneintranet/issues/5584))
    ([Issue
    #modernize-toolbar-markup](https://github.com/quaive/ploneintranet/issues/modernize-toolbar-markup))

## 6.2.2 (2025-07-09)

Added:

- Tiptap editor: Allow to define recognized URL protocols.

  Define new configuration option
  "ploneintranet.layout.texteditor_url_protocols" where a list of
  URL protocols can be defined which tiptap recognizes as valid. The
  default protocols are: file, ftp, ftps, http, https, mailto, notes,
  tel. The "notes" protocol is used for Lotus Notes.

  Ref: scrum-3159

Changed:

- The Library Documents portlet shows no news anymore. News have their
  own portlet and are not meant to live in the library. ([Issue
  #3741](https://github.com/quaive/ploneintranet/issues/3741))

Fixed:

- Fix to deep link to the jitsi app when on ios or android device.
  ([Issue #3683](https://github.com/quaive/ploneintranet/issues/3683))
- Fix for password reset form ([Issue
  #3692](https://github.com/quaive/ploneintranet/issues/3692))
- Fix following deeplinks, including email notification clickthroughs,
  for users that are not logged in. This is a backport of a fix that
  is part of the next Plone 6.1.2 release. ([Issue
  #5622](https://github.com/quaive/ploneintranet/issues/5622))

Technical:

- Reimplement #5495 in a way that avoids write lock contention ([Issue
  #5842](https://github.com/quaive/ploneintranet/issues/5842))

- Add a ploneintranet_enabled view to be used in TALES expressions.

  The "ploneintranet_enabled" view can be used in TALES expressions
  to check if the ploneintranet theme is enabled.

Updated:

- Adjusted news item markup for proto changes.
- \`quaive.app.classifieds\`: **3.0.0 → 3.0.1**
- \`quaive.app.absences\`: **4.0.1 → 4.0.2**
- \`quaive.app.audit\`: **4.0.0a1 → 4.0.0**
- \`quaive.app.classifieds\`: **3.0.0a3 → 3.0.0**
- \`quaive.app.legal\`: **1.3.0 → 1.3.1**
- \`quaive.app.milestones\`: **3.0.0a1 → 3.0.0**
- \`quaive.app.onlyoffice\`: **5.0.0 → 5.0.1**
- \`quaive.app.polls\`: **1.0.13 → 1.0.14**
- \`quaive.app.taxonomy\`: **3.0.0a1 → 3.0.0**
- Upgrade plone.patternslib to 9.10.3. [thet]

## 6.2.1 (2025-06-25)

Added:

- View for downloading a zip of all files in a folder ([Issue
  #5430](https://github.com/quaive/ploneintranet/issues/5430))

Technical:

- Do not use anymore the deprecated pkg_resources module

## 6.2.0 (2025-05-27)

Changed:

- Modernize workspace editing toolbar and UI ([Issue
  #5579](https://github.com/quaive/ploneintranet/issues/5579))

  - Update workflow menu styling. ([PR
    #5590](https://github.com/quaive/ploneintranet/issues/5590))

  - Improve workspace sharing menu ([Issue
    #5587](https://github.com/quaive/ploneintranet/issues/5587))

    > - Use the proper sharing icon
    > - Show sharing menu only within context extra menu
    > - Show sharing menu only if at least one sharing option is
    >   available

Updated:

- Update quaive.resources.ploneintranet to version 11.0.0 ([Issue
  #5609](https://github.com/quaive/ploneintranet/issues/5609))

## 6.1.1 (2025-05-19)

Fixed:

- Patch a problem in plone.app.blocks:subrequests that prevented tiles
  from being loaded when hosting a quaive instance with virtual
  hosting under a subpath like "/intranet". Fixes #3523 [pilz]
  ([Issue #3523](https://github.com/quaive/ploneintranet/issues/3523))
- Prevent the notification scheduler to crash when a follower username
  cannot be resolved [ale-rt]

Technical:

- Remove the pin of zope.testrunner

  The package zope.testrunner was down pinned to 6.2 because of an
  issue with collective.xmltestreport.

  This was necessary to prevent:

  - <https://github.com/collective/collective.xmltestreport/issues/28>

## 6.1.0 (2025-05-07)

Added:

- Workspaces now by default provide the option to create Office files.
  ([Issue #5552](https://github.com/quaive/ploneintranet/issues/5552))

Changed:

- Office file templates now reside in a plain Folder under
  /templates/office, where they can be managed in Barceloneta without
  having to change allowed content type settings. ([Issue
  #5552](https://github.com/quaive/ploneintranet/issues/5552))

Fixed:

- event-view: Add the value for [location]{.title-ref} to the form
  field, otherwise the value will be lost on subsequent saves. ([Issue
  #3437](https://github.com/quaive/ploneintranet/issues/3437))
- Fix an issue with the translation target from a macro that is not
  correctly passed to the fill slot since Chameleon 4.3.0. ([Issue
  #5512](https://github.com/quaive/ploneintranet/issues/5512))
- Fix display state switching for 2-column news portlet on dashboard
  (expanded/collapsed). Fix default state for all dashboard portlets
  to be collapsed, except for activitystream in two columns to be
  expanded by default. ([Issue
  #5529](https://github.com/quaive/ploneintranet/issues/5529))
- Suppress "document byline" viewlet outside of Barceloneta. ([Issue
  #5545](https://github.com/quaive/ploneintranet/issues/5545))
- Suppress "manage portlets" viewlet outside of Barceloneta. ([Issue
  #5549](https://github.com/quaive/ploneintranet/issues/5549))
- Fix UI glitches caused by new design styles. ([Issue
  #5554](https://github.com/quaive/ploneintranet/issues/5554))
- Fix the computation of the aspect ratio on nasty PDFs. Also return a
  better default. ([Issue
  #5558](https://github.com/quaive/ploneintranet/issues/5558))
- Fix more notifications breakage when resolving users, when username
  is not equal to the userid. ([Issue
  #5560](https://github.com/quaive/ploneintranet/issues/5560))
- Translate all untranslated message strings in French, German and
  Dutch. ([Issue
  #5570](https://github.com/quaive/ploneintranet/issues/5570))
- Fix notification breakage when an event gets deleted, or removed
  from a shared calendar without assigning a new shared calendar.
  ([Issue #5572](https://github.com/quaive/ploneintranet/issues/5572))
- For notifications about events, show the shared calendar the
  notification pertains to at the moment is created, not when the
  notification is displayed. The shared calendar may have changed in
  between. This change is only applied to new notifications; existing
  notifications will retain the old behavior. ([Issue
  #5572](https://github.com/quaive/ploneintranet/issues/5572))

Technical:

- Adapt a test to work on Plone 6.1 ([Issue
  #5344](https://github.com/quaive/ploneintranet/issues/5344))
- Remove edit_document.pt template that is no longer used. ([Issue
  #5580](https://github.com/quaive/ploneintranet/issues/5580))
- Fix i18nsync bitrot: gettext msgcat changed output, Lingua throws
  warnings in modern python versions.

Updated:

- Update event view for new markup. ([Issue
  #5544](https://github.com/quaive/ploneintranet/issues/5544))
- Update `kombu` and `vine` version pins. This fixes breakage when
  using `collective.recipe.plonesite` to initialize a Quaive
  installation. ([Issue
  #5575](https://github.com/quaive/ploneintranet/issues/5575))
- Update workflow menu styling. ([Issue
  #5579](https://github.com/quaive/ploneintranet/issues/5579))
- Updated plone.recipe.zeoserver and zope.mkzeoinstance
- Use Plone 6.1.1
- Use plone.autoinclude 2.0.2 to prevent issues at startup (see
  <https://github.com/plone/plone.autoinclude/issues/25>)
- Update quaive.resource.ploneintranet to 10.0.3 and quaive.app.jobs
  to 2.1.3. This should resolve the last release blockers from the
  proto alignment; some non-blocking CSS tuning issues are still open.

## 6.1.0b2 (2025-04-29)

Fixed:

- event-view: Add the value for [location]{.title-ref} to the form
  field, otherwise the value will be lost on subsequent saves. ([Scrum
  Issue #3437](https://github.com/syslabcom/scrum/issues/3437),
  [Quaive PR
  #5596](https://github.com/quaive/ploneintranet/pull/5596))
- Make /workspaces and /templates accessible again in Barceloneta.

## 6.1.0b1 (2025-02-13)

We flagged this as a beta release, since it contains some UI glitches.
Those glitches do not impede functionality, but they look unfinished.
We'll polish those in a follow-up release.

Updated:

- Update quaive.resources.ploneintranet to 10.0.0. This pulls in major
  changes related to the componentization. Additionally, this adds
  themes for Virton and L'Eglise, and fixes a bug in theme OLLN CPAS.
- Update markup for prototype compatibility. This mostly impacts
  sidebar toolbars.([Issue
  #5530](https://github.com/quaive/ploneintranet/issues/5530))

## 6.0.3 (2025-03-06)

Fixed:

- Fix more notifications breakage when resolving users, when username
  is not equal to the userid. ([Issue
  #5560](https://github.com/quaive/ploneintranet/issues/5560))

## 6.0.2 (2025-02-26)

Fixed:

- Don't use userid when username is required. That would break
  notifications on sites where the two diverge. ([Issue
  #5560](https://github.com/quaive/ploneintranet/issues/5560))

## 6.0.1 (2025-02-05)

Changed:

- Remove showing of news item publications in the default stream. This
  recently introduced change was too confusing for users. This reverts
  the change made in #5396. ([Issue
  #5523](https://github.com/quaive/ploneintranet/issues/5523))
- In the news publisher app, do not mark as "Unpublished" News
  Items, when the workflow state is "Published" but they're
  invisible because of effective date or expiry date. Instead, label
  these as "Scheduled" or "Expired". Note that while the
  underlying fields are orthogonal, the labels are not: the labels
  "Scheduled" or "Expired" are only shown for published items.
  ([Issue #5842](https://github.com/quaive/ploneintranet/issues/5842))

Fixed:

- Hide future news in the news portlet on the dashboard from managers.
  ([Issue #5482](https://github.com/quaive/ploneintranet/issues/5482))
- Hide expired news items in the dashboard portlet from managers.
  ([Issue #5482](https://github.com/quaive/ploneintranet/issues/5482))
- Hide future notifications in the web view (notifications app,
  personal toolbar bell, personal toolbar pulldown). While these were
  properly scheduled for the future in the backend, they were not
  filtered out in the rendering code. ([Issue
  #5482.3](https://github.com/quaive/ploneintranet/issues/5482))
- If user A follows user B, do not issue notifications to A when B
  does work in a workspace that A does not have access to. ([Issue
  #5520](https://github.com/quaive/ploneintranet/issues/5520))
- If user A follows user B, do not issue notifications to A when B
  does work on a document that A does not have access to. ([Issue
  #5520](https://github.com/quaive/ploneintranet/issues/5520))
- Extend security checks on notifications, to not only check
  permissions on the direct context of the notification; if the direct
  context is a status update, this will now also check if the
  recipient has access to any workspace or document that this
  statusupdate pertains to. This is necessary, because security rights
  may change after a notification was created. If a notification's
  context became inaccessible, we want to hide that notification from
  the user. ([Issue
  #5520](https://github.com/quaive/ploneintranet/issues/5520))
- Ensure timezones are handled correctly, when hiding future published
  news items. ([Issue
  #5482](https://github.com/quaive/ploneintranet/issues/5482))
- Fix the broken entries in the mimetypes_registry ([Issue
  #5518](https://github.com/quaive/ploneintranet/issues/5518))

Technical:

- Replace Makefile with a deprecation warning. ([Issue
  #5517](https://github.com/quaive/ploneintranet/issues/5517))
- Fix a failing robot test in Chrome. When invoking "Select from list
  by Value" Chrome doesn't dispatch a "input" event. Other
  browsers like Firefox do, the specs require a "input" event to be
  thrown and when selecting manually in Chrome via mouse or even
  keyboard the "input" event is also thrown along with the
  "change" event. We fix the test by manually dispatching a
  "input" event.
- Robot tests: Wait to disable jQuery.fx. Wait for the
  "DOMContentLoaded" event and then disable jQuery.fx transitions
  and effects. jQuery is initialized in the plone main bundle, so we
  have to wait for it or load after the plone main bundle.

## 6.0.0 (2025-01-10)

Added:

- Add missing translations for French ([Issue
  #5490](https://github.com/quaive/ploneintranet/issues/5490))

Changed:

- The code that checks for PDF creator that we cannot convert with
  pdf2svg now supports globs and also checks the Producer metadata

Fixed:

- Remove the extra "Z" after the timestamp as it is not needed and
  confuses the safari date calculator. ([Issue
  #5466](https://github.com/quaive/ploneintranet/issues/5466))

- Search all searchable fields, instead of only the Title field, when
  searching contacts in the contacts app sidebar. ([Issue
  #5480](https://github.com/quaive/ploneintranet/issues/5480))

- Do not show future news items in notifications:

  - Delay notifications for future news items to the future
    effective date.
  - Re-issue notification, if a future news item was rescheduled
    to a different future date.
  - Notify news item publications only once.

- Do not show future news items in the activity stream:

  - Suppress future news items from the activity stream (both
    the creation and publication updates)
  - Re-issue status update, if the news item was rescheduled to
    a different future date.
  - Announce news item publications only once. ([Issue
    #5482](https://github.com/quaive/ploneintranet/issues/5482))

- Align personal settings with notifications killswitches. ([Issue
  #5486](https://github.com/quaive/ploneintranet/issues/5486))

- Do not display notifications whose context got deleted. ([Issue
  #5491](https://github.com/quaive/ploneintranet/issues/5491))

- Update notification counter only if there are newly dispatched
  messages. Previously, the counter was always trying to update itself
  if there were any unread messages, no matter how old. ([Issue
  #5500](https://github.com/quaive/ploneintranet/issues/5500))

- Show only unseen desktop-specific notifications in the desktop push
  channel. Previously, this channel erroneously displayed all unread
  notifications from the record channel, no matter how old they were.

- If a user starts a new session, the first new desktop notification
  will display the number of new desktop notifications that were
  emitted since last logging out. Subsequent desktop notifications
  will typically be displayed individually, unless multiple desktop
  notifications are received within a minute of each other. ([Issue
  #5501](https://github.com/quaive/ploneintranet/issues/5501))

Technical:

- Modernize the way we get the Plone version.

- Quaive is now tested against Python 3.11

- Quaive will gradually switch to use z3c.form based forms. Custom
  fields are now in a module called ploneintranet.schema. Custom
  widgets and form templates have been provided in
  ploneintranet.layout.widgets. ([Issue
  #5449](https://github.com/quaive/ploneintranet/issues/5449))

- Mark UTCDateTime as cache-safe in SQLAlchemy.

  - <https://docs.sqlalchemy.org/en/14/errors.html#object-will-not-produce-a-cache-key-performance-implications>

  \-
  <https://stackoverflow.com/questions/67906949/whats-the-cache-ok-flag-in-sqlalchemy>
  ([Issue #5481](https://github.com/quaive/ploneintranet/issues/5481))

- Introduce a context manager and decorator to elegantly disable
  functionality in testing. ([Issue
  #5482](https://github.com/quaive/ploneintranet/issues/5482))

- Hide deprecationwarnings in Jenkins to unclutter test output.
  ([Issue #5488](https://github.com/quaive/ploneintranet/issues/5488))

- Fix various test warnings. ([Issue
  #5489](https://github.com/quaive/ploneintranet/issues/5489))

- Remove usage of the script getFolderContents that does not exist
  anymore in Plone 6.1 ([Issue
  #5492](https://github.com/quaive/ploneintranet/issues/5492))

- Add column 'read' to support two-phase notifications dispatch for
  RabbitMQ integrated channels.

- No longer use 'notified' in the record channel to mean 'read',
  instead store the dispatch time there.

- Introduce 'alembic' to support SQLAlchemy database migrations,
  without invoking the full Alembic framework (we have ftw.upgrade for
  that already). For an example of performing a SQLAlchemy schema
  change, see
  src/ploneintranet/upgrade/v21/20241025143035_notifications_read/upgrade.py
  ([Issue #5500](https://github.com/quaive/ploneintranet/issues/5500))

- Fix the setup of the virtual environment on Jenkins to not have
  clash of packages with buildout ([Issue
  #5502](https://github.com/quaive/ploneintranet/issues/5502))

- Use black 24.10.0 ([Issue
  #5503](https://github.com/quaive/ploneintranet/issues/5503))

- Add check_same_thread=False to the SQLAlchemy connection to the test
  DB

Updated:

- Upgrade to Plone 6.0.14 ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))

Additional changes:

- Consider the changes in 5.2.6 below to be part of 6.0 also. 5.2.6
  was released but never deployed.

## 5.2.6 (2024-08-22 - do not use)

Do not use this release. Use 5.2.5 if you want to stay in the 5.x
series.

Showing news items in the default activity stream highlights a problem,
whereby scheduled future news items are visible when they should be
hidden. The 6.0 release fixes that.

Changed:

- Published news items now show up in the default activitystream.
  Let's classify news item publications as human updates. A
  published news item is by definition meant to be interesting and
  widely read. As such, it is closer to a stream update than it is
  to some random document getting created in some random
  workspace. This solves a long standing feature request, and
  obviates the need for users to resort to workarounds as seen in
  the wild: adding a "." comment on a newsitem to promote it
  into the "human stream", or reconfiguring the activitystream
  dashboard to place the news portlet above the stream portlet.
  ([Issue
  #5396](https://github.com/quaive/ploneintranet/issues/5396))

- Sort recently modified items higher in search results. ([Issue
  #5440](https://github.com/quaive/ploneintranet/issues/5440))

Fixed:

- Highlight current user when loading chat deeplink URL. ([Issue
  #5435](https://github.com/quaive/ploneintranet/issues/5435))
- Fix typo in German translation ([Issue
  #5439](https://github.com/quaive/ploneintranet/issues/5439))
- Fix search results prose in Dutch. ([Issue
  #5441](https://github.com/quaive/ploneintranet/issues/5441))
- Provide a base URL to weasyprint so that it can resolve the style
  sheets ([Issue
  #5442](https://github.com/quaive/ploneintranet/issues/5442))
- Don't collapse empty table rows in generated PDFs ([Issue
  #5444](https://github.com/quaive/ploneintranet/issues/5444))

Updated:

- Upgrade to Plone 6.0.12 ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))
- Update quaive.resources.ploneintranet to 9.4.8. This fixes a problem
  where it wasn't possible in the visual texteditor tiptap to add
  columns in tables. Also, it includes the Arlon theme. Ref:
  scrum-2500 ([Issue
  #5447](https://github.com/quaive/ploneintranet/issues/5447))

## 5.2.5 (2024-08-02)

Fixed:

- Make chat work again when entering a message. ([Issue
  #5431](https://github.com/quaive/ploneintranet/issues/5431))
- Fall back to site configured default timezone, when rendering a
  calendar. ([Issue
  #5432](https://github.com/quaive/ploneintranet/issues/5432))

## 5.2.4 (2024-08-02)

Added:

- Optional footer for user registration mail ([Issue
  #5424](https://github.com/quaive/ploneintranet/issues/5424))

Fixed:

- Fix label with two different defaults

## 5.2.3 (2024-07-23)

Fixed:

- Fix document with Table empty / broken after editing ([Pat-tiptap
  #67](https://github.com/Patternslib/pat-tiptap/pull/67))
- Fixed workspace document revision preview ([Issue
  #5420](https://github.com/quaive/ploneintranet/issues/5420))

Updated:

- Use quaive.resources.ploneintranet 9.4.6

## 5.2.2 (2024-07-15)

Added:

- Added collective.honeypot protection for contact-info form. ([Issue
  #5412](https://github.com/quaive/ploneintranet/issues/5412))

Fixed:

- The notification queue is not blocked anymore when we fail to send
  an email. ([Issue
  #5413](https://github.com/quaive/ploneintranet/issues/5413))

Technical:

- Pypi server was moved. ([Issue
  #5411](https://github.com/quaive/ploneintranet/issues/5411))

Updated:

- quaive.app.absences = 4.0.1 ([Issue
  #5417](https://github.com/quaive/ploneintranet/pull/5417))
- quaive.app.onlyoffice = 5.0.0 ([Issue
  #5417](https://github.com/quaive/ploneintranet/pull/5417))

## 5.2.1 (2024-06-01)

Fixed:

- Fix outlook.com/office365.com breakage by emitting emails with RFC
  compliant CRLF line endings. ([Issue
  #5408](https://github.com/quaive/ploneintranet/issues/5408))
- Fix "Cher ${recipient_id}" mistranslation in French. ([Issue
  #5409](https://github.com/quaive/ploneintranet/issues/5409))

## 5.2.0 (2024-05-29)

Changed:

- Allow folder download ([Issue
  #5404](https://github.com/quaive/ploneintranet/issues/5404))
- We had to drop the dependency from htmllaundry because the package
  is unmaintained and does not work with the latest Plone version. We
  kept the feature by copying a subset of the htmllaundry source code
  to the ploneintranet.htmllaundry module. ([Issue
  #5395](https://github.com/quaive/ploneintranet/issues/5395))

Fixed:

- Don't download the PDF in the print document print menu until the
  user clicks the print link. ([Issue
  #5394](https://github.com/quaive/ploneintranet/issues/5394))
- Fixed workspace filter when user profile is in background ([Issue
  #5382](https://github.com/quaive/ploneintranet/issues/5382))
- Fixed issue when viewing library file ([Issue
  #5388](https://github.com/quaive/ploneintranet/issues/5388))
- Do not choke when the Solr index is out of sync. ([Issue
  #5386](https://github.com/quaive/ploneintranet/issues/5386))
- Do not password reset email all users with hidden email address.
  ([Issue #5389](https://github.com/quaive/ploneintranet/issues/5389))
- Don't show document templates in 'my documents'. ([Issue
  #5393](https://github.com/quaive/ploneintranet/issues/5393))

Technical:

- Prevent an error message in the logs when visiting workspaces
  ([Issue #5391](https://github.com/quaive/ploneintranet/issues/5391))
- Cleanup solr test infrastructure. ([Issue
  #5398](https://github.com/quaive/ploneintranet/issues/5398))

Updated:

- Use Plone 6.0.11.1 ([Issue
  #5395](https://github.com/quaive/ploneintranet/issues/5395))

## 5.1.5 (2024-04-03)

Fixed:

- Unindexing should not re-render the whole document. ([Issue
  #5377](https://github.com/quaive/ploneintranet/issues/5377))

## 5.1.4 (2024-03-26)

Fixed:

- Hide the external editor action that was showing in the library and
  workspaces overview ([Issue
  #1600](https://github.com/quaive/ploneintranet/issues/1600))

## 5.1.3 (2024-03-11)

Fixed:

- Fix viewlet breakage when use_email_as_username is active. ([Issue
  #5369](https://github.com/quaive/ploneintranet/issues/5369))

Updated:

- yafowil.plone = 5.0.0a2 ([Issue
  #5367](https://github.com/quaive/ploneintranet/issues/5367))

## 5.1.2 (2024-03-01)

Fixed:

- Do not send emails for notifications whose context was removed.
  ([Issue #5307](https://github.com/quaive/ploneintranet/issues/5307))

Technical:

- Backport proper timezone handling to notifications upgrade. ([Issue
  #5028](https://github.com/quaive/ploneintranet/issues/5028))
- Update release documentation. ([Issue
  #5358](https://github.com/quaive/ploneintranet/issues/5358))

Updated:

- Plone 6.0.10.1 quaive.resources.ploneintranet = 9.4.4
  quaive.app.classifieds = 3.0.0a3 quaive.app.polls = 1.0.13 ([Issue
  #5363](https://github.com/quaive/ploneintranet/issues/5363))
- Update Barceloneta dashboard warning for Plone 6. ([Issue
  #5275](https://github.com/quaive/ploneintranet/issues/5275))

## 5.1.1 (2024-02-20)

Changed:

- Add a timestamp to in the share panel links so that the most recent
  version of the document is rendered ([Issue
  #5298](https://github.com/quaive/ploneintranet/issues/5298))
- Updated French translations, especially for notifications. ([Issue
  #5357](https://github.com/quaive/ploneintranet/issues/5357))

Fixed:

- Fix translation string for OSH tip. ([Issue
  #5356](https://github.com/quaive/ploneintranet/issues/5356))

Technical:

- Added a maintenance view to purge the old previews ([Issue
  #5354](https://github.com/quaive/ploneintranet/issues/5354))
- Quote dependency checks so i18nsync doesn't error if any are
  missing. ([Issue
  #5353](https://github.com/quaive/ploneintranet/issues/5353))

## 5.1.0 (2024-02-12)

Changed:

- Changed PDF generation engine to weasyprint ([Issue
  #5319](https://github.com/quaive/ploneintranet/issues/5319))
- The RabbitMQ authentication now allows to pass extra parameters
  other than the required username and password, and does not choke
  anymore when vhost is _not_ passed as an argument. ([Issue
  #5339](https://github.com/quaive/ploneintranet/issues/5339))

Fixed:

- Search results: Groups are now a separate type with a proper preview
  ([Issue #5332](https://github.com/quaive/ploneintranet/issues/5332))
- Ignore notifications about status update comments that got deleted.
  ([Issue #5335](https://github.com/quaive/ploneintranet/issues/5335))
- Rationalize the created notifications by omitting the disabled users
  ([Issue #5341](https://github.com/quaive/ploneintranet/issues/5341))

Technical:

- Fix breakage in notification dispatch when testcontent was ZMI
  loaded by admin. ([Issue
  #5348](https://github.com/quaive/ploneintranet/issues/5348))

Updated:

- quaive.app.absences to 4.0.0
- quaive.resources.ploneintranet to 9.4.2

## 5.0.1 (2023-12-21)

Fixed:

- When closing the profile page show the last visited area instead of
  a blank page. Ref: scrum-1674 ([Issue
  #5320](https://github.com/quaive/ploneintranet/issues/5320))

Updated:

- - Plone to 6.0.9
  - quaive.resources.ploneintranet to 9.4.1
  - quaive.app.polls to 1.0.12

## 5.0.0 (2023-12-19)

Added:

- Improve the print functionality. If the current file is a PDF or an
  image, print it directly, if it's an office document that has been
  converted to a PDF, print the PDF version. If it's an office
  document and the PDF version hasn't been generated successfully,
  don't show the print option. ([Issue
  #5298](https://github.com/quaive/ploneintranet/issues/5298))
- Add a plugin that allows the users to confirm the authentication
  with link sent to their email. ([Issue
  #5299](https://github.com/quaive/ploneintranet/issues/5299))

Fixed:

- Added a missing scroll-selector attribute
- Add German translation for "Delete group" ([Issue
  #5270](https://github.com/quaive/ploneintranet/issues/5270))
- Fix notification scheduling issues due to timezone handling
  inconsistencies. ([Issue
  #5028](https://github.com/quaive/ploneintranet/issues/5028))
- Accept strikethrough as a valid tag in the backend; it is offered by
  our UI already. ([Issue
  #5061](https://github.com/quaive/ploneintranet/issues/5061))
- Add a missing message variant that was breaking some notifications
  ([Issue #5200](https://github.com/quaive/ploneintranet/issues/5200))
- Fix the Like/unlike button to match the new design. ([Issue
  #5263](https://github.com/quaive/ploneintranet/issues/5263))
- requests.exceptions.ConnectionError is a IOError, which does not
  derive from Exception. Catch this error for links that cannot be
  resolved, e.g. because they require a VPN. This removes noise from
  Sentry, e.g.
  <https://sentry.syslab.com/syslabcom/imio/issues/53747/> ([Issue
  #5288](https://github.com/quaive/ploneintranet/issues/5288))
- Fixed searching the events in Plone 6 ([Issue
  #5301](https://github.com/quaive/ploneintranet/issues/5301))
- Fix membrane tool getUserName index inconsistency when
  disabling/enabling users. Do this not only during LDAP sync but also
  if manually transitioned. ([Issue
  #5305](https://github.com/quaive/ploneintranet/issues/5305))

Technical:

- Do not require the registry entry
  "ploneintranet.userprofile.primary_external_user_source", so that
  the value can be empty. This allows to disable an LDAP source again,
  once it was accidentally activated. ([Issue
  #5312](https://github.com/quaive/ploneintranet/issues/5312))
- Improve i18nsync: do not extract [i18n_translate]{.title-ref}
  function itself; do not count empty message strings in diff. ([Issue
  #5321](https://github.com/quaive/ploneintranet/issues/5321))

Updated:

- - Plone to 6.0.8
  - collective.auditlog to 3.0.0a2
  - quaive.app.absences to 4.0.0a1
  - quaive.app.audit to 4.0.0a1
  - quaive.app.classifieds to 3.0.0a1
  - quaive.app.milestones to 3.0.0a1
  - quaive.app.onlyoffice to 5.0.0a2
  - quaive.app.taxonomy to 3.0.0a1
  - quaive.resources.ploneintranet 9.4.0

## 4.3.3 (2024-01-15)

Fixed:

- Ignore notifications about status update comments that got deleted.
  (Issue #5335
  \<<https://github.com/quaive/ploneintranet/issues/5335>>\_)

## 4.3.2 (2023-12-14)

Fixed:

- Catch edge cases in handling and showing user profiles. ([Issue
  #3509](https://github.com/quaive/ploneintranet/issues/3509))

## 4.3.1 (2023-12-01)

Fixed:

- Fix userprofile index inconsistencies when disabling/enabling users.
  Do this not only during LDAP sync but also if manually transitioned.
  ([Issue #5305](https://github.com/quaive/ploneintranet/issues/5305))

## 4.3.0 (2023-11-09)

Added:

- Make it optionally possible to re-activate users that are re-enabled
  in LDAP/AD.

  By default, users deactivated in Quaive will remain deactivated even
  when they are re-enabled in the external user source.

  If the registry record
  `ploneintranet.userprofile.reactivate_on_sync` is set to `True`,
  users present in the external user source will be automatically
  reactivated on sync. ([Issue
  #5265](https://github.com/quaive/ploneintranet/issues/5265))

- Notifications about workspace documents, events and todos now
  highlight the title of the content object. ([Issue
  #5283](https://github.com/quaive/ploneintranet/issues/5283))

Changed:

- Exclude from the search the groups container ([Issue
  #1860](https://github.com/quaive/ploneintranet/issues/1860))

- Hide deactivated users in "All Users".

  Requested by Namur and conform design spec:
  <https://github.com/quaive/ploneintranet.prototype/issues/1515>

  Note that reactivating a deactivated user will show their avatar as
  deactivated for five minutes, due to caching. ([Issue
  #5279](https://github.com/quaive/ploneintranet/issues/5279))

Fixed:

- Add German translation for "Delete group" ([Issue
  #1665](https://github.com/quaive/ploneintranet/issues/1665))
- Fix: closing profile tab now leads to dashboard, rather than a blank
  page. ([Issue
  #1674](https://github.com/quaive/ploneintranet/issues/1674))
- Improve the detection of the effective date in news created from a
  feed. ([Issue
  #2233](https://github.com/quaive/ploneintranet/issues/2233))
- Provide a Barceloneta-dedicated dashboard view. ([Issue
  #5250](https://github.com/quaive/ploneintranet/issues/5250))
- With Active Directory integration enabled, create user profiles with
  properly-cased ids if users log in with wrongly-cased id (which gets
  accepted by AD). ([Issue
  #5281](https://github.com/quaive/ploneintranet/issues/5281))

Technical:

- Performance optimize "All Users" view. ([Issue
  #5279](https://github.com/quaive/ploneintranet/issues/5279))

Updated:

- Update French translations. ([Issue
  #5253](https://github.com/quaive/ploneintranet/issues/5253))

## 4.2.2 (2023-10-23)

Fixed:

- The notification template was improved by adding an alt attribute in
  the logo image ([Issue
  #5099](https://github.com/quaive/ploneintranet/issues/5099))

Technical:

- Fix login after invitation on Plone 6. ([Issue
  #4009](https://github.com/quaive/ploneintranet/issues/4009))

## 4.2.1 (2023-10-16)

Fixed:

- Configure a max pixel size for PNG previews of PDFs to prevent PDFs
  with a massive page size (e.g. 4 metres) from killing the host
  machine. ([Issue
  #1491](https://github.com/quaive/ploneintranet/issues/1491))
- When LDAP sync disables a user, also mangle their email address to
  avoid that address being claimed by an inactive user. ([Issue
  #5247](https://github.com/quaive/ploneintranet/issues/5247))

Updated:

- Update Dutch translations. ([Issue
  #5252](https://github.com/quaive/ploneintranet/issues/5252))

## 4.2.0 (2023-10-10)

Added:

- Add a new field for syndicated news section that will be used to
  specify the creator of the news items. ([Issue
  #5233](https://github.com/quaive/ploneintranet/issues/5233))
- Added option to delete group ([Issue
  #5241](https://github.com/quaive/ploneintranet/issues/5241))
- Excel export for "All users" ([Issue
  #5244](https://github.com/quaive/ploneintranet/issues/5244))

Fixed:

- Improve the speed of the dispatch notification script ([Issue
  #5093](https://github.com/quaive/ploneintranet/issues/5093))
- Fix an issue where sending any notifications via
  dispatch-notifications failed due to a missing context for a
  microblog status update notification, e.g. because of a deleted
  workspace. Ref: scrum-1507 Fixes:
  <https://github.com/quaive/ploneintranet/issues/5213> ([Issue
  #5232](https://github.com/quaive/ploneintranet/issues/5232))
- Force the logged event actor to be computed immediately rather than
  lazily. This fixes an issue where the the user might change between
  the time the event is logged and the default is computed, e.g. when
  api.env.adopt_user is used. ([Issue
  #5233](https://github.com/quaive/ploneintranet/issues/5233))
- E-Mail notifications: Fix layout problem with header image. Fixes a
  problem where the header image in e-mail notifications was not
  responsive but could have been displayed stretched or compressed.
  Ref: scrum-1501 ([Issue
  #5235](https://github.com/quaive/ploneintranet/issues/5235))
- Event Notification: fix for deleted shared calendar ([Issue
  #5239](https://github.com/quaive/ploneintranet/issues/5239))
- Fixed translations when changing workspace roles ([Issue
  #5242](https://github.com/quaive/ploneintranet/issues/5242))
- Contacts app: Include deactivated users in sidebar count ([Issue
  #5243](https://github.com/quaive/ploneintranet/issues/5243))

Technical:

- Restore the possibility to load testcontent in development. ([Issue
  #5227](https://github.com/quaive/ploneintranet/issues/5227))
- Stop logging UserNotFoundError when anonymous hits an
  extranet_enabled public page. ([Issue
  #5231](https://github.com/quaive/ploneintranet/issues/5231))

Updated:

- Use Plone 5.2.14

## 4.1.1 (2023-08-28)

Fixed:

- Event Notification: fix for empty shared calendar ([Issue
  #1499](https://github.com/quaive/ploneintranet/issues/1499))

- Do not display the reply button for posts that are not commentable
  because of missing permissions ([Issue
  #4450](https://github.com/quaive/ploneintranet/issues/4450))

- If a principal title is empty, use the getId accessor as a fallback
  to avoid displaying an empty pill ([Issue
  #4758](https://github.com/quaive/ploneintranet/issues/4758))

- Fix translation of notification subject for commented documents.

  Fixes: scrum-1464 ([Issue
  #5219](https://github.com/quaive/ploneintranet/issues/5219))

- Do not break LDAP properties sync when the user was deleted
  LDAP-side. ([Issue
  #5221](https://github.com/quaive/ploneintranet/issues/5221))

Updated:

- Update LDAP documentation. ([Issue
  #5220](https://github.com/quaive/ploneintranet/issues/5220))

## 4.1.0 (2023-08-16)

Added:

- Provide the ability to switch on enhanced security for workspace
  notifications.

  If the registry toggle
  `ploneintranet.notifications.enhanced_security` is switched on,
  email notifications about things happening in private and secure
  workspaces will NOT show the workspace title, nor the title of the
  content object or status update the notification is about. ([Issue
  #5200](https://github.com/quaive/ploneintranet/issues/5200))

- Workspace content notifications emails are sent in a mini-digest
  every 10 minutes. The minimum delay after starting an upload is 5
  minutes; the maximum is 15 minutes. If many files are uploaded
  simultaneously, the email notifications for those are now bundled.
  ([Issue #5203](https://github.com/quaive/ploneintranet/issues/5203))

- Send notifications also for comments on the dashboard.

  By default, those only show up in the record channel (i.e. the web
  view). But users can opt-in to desktop, email or digest
  notifications for the new category "New comments".

  Refs: <https://github.com/syslabcom/quaive.prototype/issues/148>
  ([Issue #5205](https://github.com/quaive/ploneintranet/issues/5205))

- Translate some notification messages in German. ([Issue
  #5215](https://github.com/quaive/ploneintranet/issues/5215))

Changed:

- Make email notifications more attractive.

  Previously, in email and digest all notofications showed an
  anonymous user avatar. Now:

  - For content updates, a bell icon is shown
  - For status updates, the actual author picture is shown if
    available, else the anonymous avatar.

  The display of notifications in the Quaive web interface remains
  unchanged. ([Issue
  #5207](https://github.com/quaive/ploneintranet/issues/5207))

Technical:

- Less verbose logging when failing to check remote URLs ([Issue
  #3842](https://github.com/quaive/ploneintranet/issues/3842))

Updated:

- Use Plone 5.2.13 ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))

## 4.0.0 (2023-07-24)

Added:

- Add notifications for status updates by people and on things you
  follow.

  This includes authors, tags, workspaces. Following documents is
  prepared, but not exposed in the UI yet. ([Issue
  #5158](https://github.com/quaive/ploneintranet/issues/5158))

Changed:

- The bulk email action now also accepts email addresses as inputs
  ([Issue #183](https://github.com/quaive/ploneintranet/issues/183))
- Quaive has a new notification system that provides better fine
  tuning and flexibility ([Issue
  #5093](https://github.com/quaive/ploneintranet/issues/5093))
- The `watch workspaces` feature is now generalized into content
  following. ([Issue
  #5193](https://github.com/quaive/ploneintranet/issues/5193))

Fixed:

- Do not break the activitystream when a user was deleted. ([Issue
  #4932](https://github.com/quaive/ploneintranet/issues/4932))

- Fix sorting of apps that have no view defined ([Issue
  #5112](https://github.com/quaive/ploneintranet/issues/5112))

- When closing the preferences app, do not display an empty window.
  ([Issue #5131](https://github.com/quaive/ploneintranet/issues/5131))

- Fix autocreation of userprofile on first login when login-with-email
  and pasldap are enabled. ([Issue
  #5168](https://github.com/quaive/ploneintranet/issues/5168))

- In the admintool app, if the user profile has no fullname, display
  the user id ([Issue
  #5173](https://github.com/quaive/ploneintranet/issues/5173))

- Properly display not fully configured users in widgets that use the
  @@allusers.json view ([Issue
  #5175](https://github.com/quaive/ploneintranet/issues/5175))

- Fix tab bar to be in non-multi-tasking mode and don't show home and
  app icons when there is no open tab.

  Ref: scrum-1286 ([Issue
  #5183](https://github.com/quaive/ploneintranet/pull/5183))

- Ensure all notification messages in emails have the same widths.

  Ports the fix from
  <https://github.com/syslabcom/quaive.prototype/pull/157> Fixes
  <https://github.com/syslabcom/scrum/issues/1395> ([Issue
  #5201](https://github.com/quaive/ploneintranet/issues/5201))

Technical:

- Add a [after-form]{.title-ref} slot to the
  [panel-template]{.title-ref} master macro. This can be used to
  inject something after the form - e.g. a separate upload form.
  ([Issue #5151](https://github.com/quaive/ploneintranet/issues/5151))
- Specify column lengths for notification database to support mysql
  ([Issue #5165](https://github.com/quaive/ploneintranet/issues/5165))
- Remove unused and obsoleted tests on old notifications system.
  ([Issue #5192](https://github.com/quaive/ploneintranet/issues/5192))

Updated:

- Modernize the action URL expression to not use deprecated code.
  ([Issue #5156](https://github.com/quaive/ploneintranet/pull/5156))

- Update:

  - collective.auditlog to 3.0.0a1
  - collective.mustread to 2.2.1
  - dexterity.membrane to 3.0.2
  - quaive.app.absences to 3.0.0
  - quaive.app.audit to 3.1.0
  - quaive.app.jobs to 2.1.0
  - quaive.app.legal to 1.3.0
  - quaive.app.milestones to 2.0.12
  - quaive.app.onlyoffice to 4.1.6
  - quaive.app.polls to 1.0.11
  - quaive.resources.ploneintranet to 9.3.1

  Refs: #5204, #5206 ([Issue
  #5204](https://github.com/quaive/ploneintranet/pull/5204))

## 3.12.2 (2023-08-22)

Technical:

- Backport #5221 from 4.x to 3.12.x: Do not break LDAP properties sync
  when the user was deleted LDAP-side. ([Issue
  #5221](https://github.com/quaive/ploneintranet/issues/5221))

## 3.12.1 (2023-05-05)

Technical:

- Add upgrade step for new registry record to suppress help links.
  ([Issue #5112](https://github.com/quaive/ploneintranet/issues/5112))
- Handle edge case where neither LANG points to the right locale, nor
  en_US.UTF-8 is available as a fallback. ([Issue
  #5117](https://github.com/quaive/ploneintranet/issues/5117))

## 3.12.0 (2023-05-04)

Added:

- The email template displays a logo that depends on the customer
  theme ([Issue
  #5099](https://github.com/quaive/ploneintranet/issues/5099))

Changed:

- Introduce a registry toggle that makes it possible to disable help
  links in the sidebar of apps. ([Issue
  #5110](https://github.com/quaive/ploneintranet/issues/5110))

Fixed:

- If the INTRANET_USERS_GROUP_ID is mentioned, do not spam all the
  users with notifications ([Issue
  #4875](https://github.com/quaive/ploneintranet/issues/4875))
- Sort apps overview by translated app title, case insensitive and
  with proper accent handling. Extend proper accent sorting also to
  search facets listing. ([Issue
  #5112](https://github.com/quaive/ploneintranet/issues/5112))

Technical:

- Support for new form styling ([Issue
  #5091](https://github.com/quaive/ploneintranet/issues/5091))

Updated:

- Use Plone 5.2.12.

## 3.11.0 (2023-04-26)

Changed:

- Better styles for the zope user warning. ([Issue
  #5050](https://github.com/quaive/ploneintranet/issues/5050))
- Align context menu styles with the design prototype. ([Issue
  #5050](https://github.com/quaive/ploneintranet/issues/5050))
- Implement the new quicknav switcher to quickly open the apps
  overview or the dashboard. ([Issue
  #5050](https://github.com/quaive/ploneintranet/issues/5050))
- Remove content preloading in favor of new quicknav switcher. ([Issue
  #5050](https://github.com/quaive/ploneintranet/issues/5050))
- Add registry entry "ploneintranet.news.show_image_gallery" to
  control if the news item image gallery should be shown. ([Issue
  #5034](https://github.com/quaive/ploneintranet/issues/5034))
- News items: allow a time to be set for the effective and expiration
  dates ([Issue #
  5021](https://github.com/quaive/ploneintranet/issues/5021))
- Send all email using the address configured in @@mail-controlpanel
  as the sender, to avoid getting flagged as spam. Use the email
  Reply-To header instead of From, as appropriate. ([Issue
  #4996](https://github.com/quaive/ploneintranet/issues/4996))
- The emails are send in the language of the recipient user and the
  base email template has been reworked to be more email client
  friendly. ([Issue
  #3905](https://github.com/quaive/ploneintranet/issues/3905))
- Messages App: Tweaked landing page. ([Issue
  #4987](https://github.com/quaive/ploneintranet/issues/4987))
- The notifications counter shows the number of unseen (and unread)
  notifications rather than the number of all unread ones. ([Issue
  #4990](https://github.com/quaive/ploneintranet/issues/4990))
- Do not send anymore the notifications to a user that is watching a
  workspace if a document is modified ([Issue
  #5004](https://github.com/quaive/ploneintranet/issues/5004))

Fixed:

- Fix the getGroupName method for ploneintranet workgroups ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))
- A problem happening when exporting the members of a group in a CSV
  or XLS file was fixed. ([Issue
  #4961](https://github.com/quaive/ploneintranet/issues/4961))
- Messages App: Fixed error when trying to start conversation with
  self. ([Issue
  #4986](https://github.com/quaive/ploneintranet/issues/4986))
- Do not try to link a mention to a removed workgroup. ([Issue
  #5087](https://github.com/quaive/ploneintranet/issues/5087))

Technical:

- Add quaive.experimental.library to i18nsync. Make i18nsync runs as
  deterministic as possible, to reduce diff noise.
- Sort messages in ploneintranet.po deterministically to reduce diff
  noise. When extracting messages with [i18nsync -e]{.title-ref}, sort
  the messages by msgid in the .pot file, like we already do for the
  .po files.
- Restore Gitlab-CI test runner capability.
- Fix an error when saving older library documents. Some older content
  might have used plone.app.blob fields. Storing versioningbehavior
  enabled content broke since plone.app.blob is not part of Plone
  anymore. Restoring it as an stub alias module fixes the problem.
  [thet]
- i18nsync: Improve finding files from extraction by only searching
  for git-managed files.

Updated:

- Use Plone 5.2.11 Use quaive.resources.ploneintranet 9.2.1
- Updated quaive.app.legal to 1.2.8. [thet]

## 3.10.5 (2023-03-06)

Fixed:

- Avoid infinite login loop, by not linking @-mentions of disabled
  users. ([Issue
  #5024](https://github.com/quaive/ploneintranet/issues/5024))

## 3.10.4 (2023-01-20)

Changed:

- Improved French translations.

## 3.10.3 (2023-01-16)

Fixed:

- Fix recurring mistranslation of folder as fichier.

## 3.10.2 (2023-01-09)

Changed:

- Improved French translations.

## 3.10.1 (2022-12-13)

Changed:

- Improve Dutch translations.

## 3.10.0 (2022-12-06)

Changed:

- Group membership export excludes deactivated users. ([Issue
  #4970](https://github.com/quaive/ploneintranet/issues/4970))
- New rich text editor (tiptap) ([Issue
  #4977](https://github.com/quaive/ploneintranet/issues/4977))

Fixed:

- Messages App: Fix for current conversation not being marked in the
  sidebar ([Issue
  #4967](https://github.com/quaive/ploneintranet/issues/4967))
- Allow non-admins to add images in the tiptap text editor. ([Issue
  #4974](https://github.com/quaive/ploneintranet/issues/4974))

Technical:

- Remove the unused @@transfer view ([Issue
  #4949](https://github.com/quaive/ploneintranet/issues/4949))

Updated:

- Plone 5.2.10
- quaive.app.classifieds = 2.0.7
- quaive.app.legal = 1.2.6
- quaive.app.taxonomy = 2.1.2
- quaive.resources.ploneintranet 9.1.3 ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))

## 3.9.2 (2022-11-07)

Added:

- Add a workgroup membership export for Excel and CSV. ([Issue
  #4961](https://github.com/quaive/ploneintranet/issues/4961))

Fixed:

- Fixed news publisher configuration panel not closing. ([Issue
  #4937](https://github.com/quaive/ploneintranet/issues/4937))
- Messages App: Fixed update of sidebar on new message. ([Issue
  #4941](https://github.com/quaive/ploneintranet/issues/4941))

Technical:

- Concatenate the email addresses with the proper separator

- Remove superfluous code ([Issue
  #4933](https://github.com/quaive/ploneintranet/issues/4933))

- Remove unused code from ploneintranet.todo

  - behavior
  - portlet
  - utility

  ([Issue #4947](https://github.com/quaive/ploneintranet/issues/4947))

Updated:

- collective.mustread = 2.2.0
- quaive.app.polls = 1.0.10

## 3.9.1 (2022-09-21)

Fixed:

- Fixed injection for the workflow menu for library documents ([Issue
  #4902](https://github.com/quaive/ploneintranet/issues/4902))

Updated:

- quaive.app.absences = 2.0.7
- quaive.app.classifieds = 2.0.6

## 3.9.0 (2022-09-19)

Added:

- Added a panel to create a section in the library ([Issue
  #4776](https://github.com/quaive/ploneintranet/issues/4776))
- Added buttons to cut/paste a folder in the library ([Issue
  #4777](https://github.com/quaive/ploneintranet/issues/4777))
- Added a delete button in the library section menu ([Issue
  #4778](https://github.com/quaive/ploneintranet/issues/4778))
- When a user saves a first version of an object, also save the
  previous version for rollback. ([Issue
  #4796](https://github.com/quaive/ploneintranet/issues/4796))

Changed:

- The "All Intranet Users" group cannot be mentioned. ([Issue
  #4875](https://github.com/quaive/ploneintranet/issues/4875))
- The panels in the user preferences are initially closed except the
  first one. ([Issue
  #4906](https://github.com/quaive/ploneintranet/issues/4906))

Fixed:

- Restrict the availability on some administrator tool view on the
  context of the profiles folder ([Issue
  #4045](https://github.com/quaive/ploneintranet/issues/4045))
- Fix some exotic edge cases when sending notification digests.
  ([Issue #4801](https://github.com/quaive/ploneintranet/issues/4801))
- Speed improvements in the magazine view ([Issue
  #4812](https://github.com/quaive/ploneintranet/issues/4812))
- Don't send chat digest if the user preference is to not receive
  chat digest. ([Issue
  #4849](https://github.com/quaive/ploneintranet/issues/4849))
- Fix clash between content and sidebar, when using sidebar from
  workspace folder view. ([Issue
  #4852](https://github.com/quaive/ploneintranet/issues/4852))
- If an image is copied to the library, don't error out on a workflow
  transition; images are not workflowed by default. ([Issue
  #4866](https://github.com/quaive/ploneintranet/issues/4866))
- "App market" was renamed to "App store". ([Issue
  #4870](https://github.com/quaive/ploneintranet/issues/4870))
- Fixed expanding workspace tasks sidebar. ([Issue
  #4874](https://github.com/quaive/ploneintranet/issues/4874))
- Adapt the markup in the library templates to match the one we have
  in proto ([Issue
  #4878](https://github.com/quaive/ploneintranet/issues/4878))
- Fix injection of user profile on @@app-todo ([Issue
  #4892](https://github.com/quaive/ploneintranet/issues/4892))
- Fix issue with content being removed after video embeds in
  documents. ([Issue
  #4894](https://github.com/quaive/ploneintranet/issues/4894))
- Display the workflow menu on library documents ([Issue
  #4897](https://github.com/quaive/ploneintranet/issues/4897))
- When copying a workspace document into a private section, do not
  submit the document for publication. Only documents in "everybody
  can view" sections should be submitted. ([Issue
  #4898](https://github.com/quaive/ploneintranet/issues/4898))
- Fixed issue in news publisher for users who don't have edit
  permission. ([Issue
  #4909](https://github.com/quaive/ploneintranet/issues/4909))

Technical:

- Prepare for Plone 6 ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))
- Remove the deprecated feed aggregator console script ([Issue
  #3466](https://github.com/quaive/ploneintranet/issues/3466))
- Deprecate the use of `execute_as_manager`, we have already
  `api.env.adopt_roles` ([Issue
  #4045](https://github.com/quaive/ploneintranet/issues/4045))
- Increase test coverage on workspace watching; fix label typo.
  ([Issue #4801](https://github.com/quaive/ploneintranet/issues/4801))
- Provide event hook for automatic workspace watching, subscriber in
  custom package. ([Issue
  #4801](https://github.com/quaive/ploneintranet/issues/4801))
- Align tiptap mini toolbars with the design prototype and remove the
  italic, table, undo and redo buttons. With pat-tiptap 4.2.0 undo and
  redo is still active via keyboard shortcuts even if the buttons are
  not shown. ([Issue
  #4850](https://github.com/quaive/ploneintranet/issues/4850))
- Fix an obsolete import ([Issue
  #4903](https://github.com/quaive/ploneintranet/issues/4903))

Updated:

- Plone 5.2.9 Products.ZCatalog = 6.3 collective.mustread = 2.1.0
  quaive.resources.ploneintranet = 9.0.0 ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))

## 3.8.0 (2022-07-07)

Added:

- Integrate Mentions and Tagging via the new suggestion feature of the
  tiptap editor. Implement special mentions `@Workspace` to notify all
  users of a workspace, `@All Intranet Users`to notify all Intranet
  users and `@GROUPNAME` to notify all users of the selected group.
  ([Issue #4712](https://github.com/quaive/ploneintranet/issues/4712))
- Added the possibility to share the maintenance roles from the
  library frontend ([Issue
  #4737](https://github.com/quaive/ploneintranet/issues/4737))
- Implement desktop notifications. Integrate the feature of sending
  desktop notification additionally to the normal notifications in the
  notifications app. Ref: scrum-198 ([Issue
  #4739](https://github.com/quaive/ploneintranet/issues/4739))
- Texteditor tiptap: Add a video/embed button and dialog to insert
  videos embeds from YouTube or Vimeo in the text. ([Issue
  #4811](https://github.com/quaive/ploneintranet/issues/4811))

Changed:

- There is a new option menu in library containers that groups the
  actions available on that context ([Issue
  #4737](https://github.com/quaive/ploneintranet/issues/4737))
- Update translations. ([Issue
  #4755](https://github.com/quaive/ploneintranet/issues/4755))
- Texteditor tiptap: Show the source button always for users with the
  `Manager` role. ([Issue
  #4811](https://github.com/quaive/ploneintranet/issues/4811))
- Texteditor tiptap: Show the source button only if the user is
  allowed to see it. This can be set by adding user names to the
  registry entry of `ploneintranet.layout.editor_html_allowed_users`.
  ([Issue #4811](https://github.com/quaive/ploneintranet/issues/4811))

Fixed:

- Try to understand if internal links point to videos ([Issue
  #3243](https://github.com/quaive/ploneintranet/issues/3243))
- Fixed disappearing maintainer groups when editing a group. ([Issue
  #4786](https://github.com/quaive/ploneintranet/issues/4786))
- Password reset: Hide error when trying to send to address with
  special characters. ([Issue
  #4795](https://github.com/quaive/ploneintranet/issues/4795))
- Fix issue where news items couldn't be opened from the news
  overview in certain circumstances. Ref: scrum #355 ([Issue
  #4802](https://github.com/quaive/ploneintranet/issues/4802))
- User import: Fixed issue where updated user details were not used in
  the search. ([Issue
  #4805](https://github.com/quaive/ploneintranet/issues/4805))
- Fixed adding event hero image. ([Issue
  #4807](https://github.com/quaive/ploneintranet/issues/4807))
- Texteditor tiptap: Fix the image panel modal dialog to not show a
  modal leftover which could not be clicked away. ([Issue
  #4811](https://github.com/quaive/ploneintranet/issues/4811))
- News Publisher: Improved loading time. ([Issue
  #4812](https://github.com/quaive/ploneintranet/issues/4812))
- Workspace JSON views: Fix the case of empty result sets and return
  an empty array instead an empty string. ([Issue
  #4813](https://github.com/quaive/ploneintranet/issues/4813))
- Mentions panel: Fix too narrow display of user profiles with a
  description by correctly setting some CSS classes. Ref: #scrum-383
  ([Issue #4820](https://github.com/quaive/ploneintranet/issues/4820))
- Mentions panel: Align to prototype and don't show the description
  at all. Ref: #scrum-383 ([Issue
  #4820](https://github.com/quaive/ploneintranet/issues/4820))
- Translate the alt attribute for profile pictures. ([Issue
  #4828](https://github.com/quaive/ploneintranet/issues/4828))

Technical:

- Remove the deprecated group_select_helper view ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))
- Notifications: Add the recipient to the message, if available. Ref:
  scrum-198 ([Issue
  #4739](https://github.com/quaive/ploneintranet/issues/4739))
- Notifications: Also change the notification counter when message is
  marked as read or the user queue is removed. Ref: scrum-198 ([Issue
  #4739](https://github.com/quaive/ploneintranet/issues/4739))
- Do not break ploneintranet.suite:testing by calling a
  not-yet-configured view. ([Issue
  #4797](https://github.com/quaive/ploneintranet/issues/4797))
- Fixed the name of an exception ([Issue
  #4804](https://github.com/quaive/ploneintranet/issues/4804))
- Add `texteditor-mini` and `texteditor-toolbar-mini` variants with a
  reduced set of controls. ([Issue
  #4811](https://github.com/quaive/ploneintranet/issues/4811))
- Texteditor: Add method `set_text` and change the `get_text` property
  to a method. This allows to customize the editable text and get it
  from other sources than the context. ([Issue
  #4811](https://github.com/quaive/ploneintranet/issues/4811))
- Texteditor: Add methods `get_placeholder` and `set_placeholder`.
  This allows to customize the placeholder text. ([Issue
  #4811](https://github.com/quaive/ploneintranet/issues/4811))
- Workspace JSON views: Set the header content-type to
  application/json. ([Issue
  #4813](https://github.com/quaive/ploneintranet/issues/4813))
- Userprofile avatar tag: Do not load default portrait fallback. In
  case no custom portrait is defined only show the name abbreviation
  and do not load the default userprofile picture. This wasn't shown
  anyways but still be loaded from the server. ([Issue
  #4825](https://github.com/quaive/ploneintranet/issues/4825))

Updated:

- quaive.resources.ploneintranet = 8.0.0
- quaive.app.absences = 2.0.6
- quaive.app.audit = 3.0.4
- quaive.app.classifieds = 2.0.5
- quaive.app.jobs = 2.0.5
- quaive.app.legal = 1.2.5
- quaive.app.milestones = 2.0.11
- quaive.app.onlyoffice = 4.1.5
- quaive.app.polls = 1.0.8
- quaive.app.taxonomy = 2.1.1

## 3.7.1 (2022-06-09)

Fixed:

- Add a timeout to the Pixx.io requests, to ensure this doesn't cause
  the instances to hang ([Issue
  #4756](https://github.com/quaive/ploneintranet/issues/4756))
- Fix preview aspect ratio extraction of latin-1 encoded pdf infos.
  Apply fallback default A4 aspect ratio only to placeholders, to not
  distort actual images. ([Issue
  #4769](https://github.com/quaive/ploneintranet/issues/4769))
- Fix an error that was preventing the news publisher to be rendered
  when news items with broken lead images are present ([Issue
  #4770](https://github.com/quaive/ploneintranet/issues/4770))
- Fix issue where News items with galleries could not be loaded from
  the news overview. Refs: scrum-380 ([Issue
  #4784](https://github.com/quaive/ploneintranet/issues/4784))

Updated:

- Use waitress 2.1.2

## 3.7.0 (2022-05-24)

Added:

- Add the option to use images in a news article from Pixx.io ([Issue
  #4756](https://github.com/quaive/ploneintranet/issues/4756))
- Added the possibility to configure an image gallery for a news item
  ([Issue #3415](https://github.com/quaive/ploneintranet/issues/3415))
- In the CSV export and import of user data, include and handle the
  "review_state". This allows to de-activate existing users or
  re-activate previously disabled users via the CSV import. ([Issue
  #4750](https://github.com/quaive/ploneintranet/issues/4750))

Fixed:

- Clean up pixx.io filtering by collection ([Issue
  #4756](https://github.com/quaive/ploneintranet/issues/4756))
- Add the link to the user preferences in the email sent when an event
  happens in a watched workspace ([Issue
  #3904](https://github.com/quaive/ploneintranet/issues/3904))
- The digest actually includes a reminder for the unread messages
  ([Issue #3905](https://github.com/quaive/ploneintranet/issues/3905))
- Add the link to the user preferences in the email sent when a new
  chat message is incoming ([Issue
  #4665](https://github.com/quaive/ploneintranet/issues/4665))
- Fix incorrect usage of E-Mail in German language. ([Issue
  #4740](https://github.com/quaive/ploneintranet/issues/4740))
- Fix the news edit display form when it is read only ([Issue
  #4751](https://github.com/quaive/ploneintranet/issues/4751))
- Edit group: Show user names, not only IDs. ([Issue
  #4758](https://github.com/quaive/ploneintranet/issues/4758))

Updated:

- quaive.app.onlyoffice = 4.1.4
- quaive.resources.ploneintranet = 7.10.2

## 3.6.1 (2022-05-05)

Changed:

- Enable the digest settings in the control panel ([Issue
  #3905](https://github.com/quaive/ploneintranet/issues/3905))

Fixed:

- Improved preview aspect ratio extraction, taking document rotation
  into account. ([Issue
  #4743](https://github.com/quaive/ploneintranet/issues/4743))

Updated:

- quaive.resources.ploneintranet = 7.10.1 ([Issue
  #0](https://github.com/quaive/ploneintranet/issues/0))

## 3.6.0 (2022-04-26)

Added:

- Send a mail notification when a new chat is started ([Issue
  #3722](https://github.com/quaive/ploneintranet/issues/3722))
- Added the possibility to follow the activity happening in a
  workspace ([Issue
  #3904](https://github.com/quaive/ploneintranet/issues/3904))
- Add paging, panning and zooming to document previews. ([Issue
  #4511](https://github.com/quaive/ploneintranet/issues/4511))
- News Item: Options for displaying credits (author). ([Issue
  #4591](https://github.com/quaive/ploneintranet/issues/4591))
- A designated user group can receive notifications of all comment on
  all news items. ([Issue
  #4628](https://github.com/quaive/ploneintranet/issues/4628))
- Allow the news to be edited using a working copy ([Issue
  #4674](https://github.com/quaive/ploneintranet/issues/4674))
- Digest support for watched workspaces ([Issue
  #4692](https://github.com/quaive/ploneintranet/issues/4692))

Changed:

- Split previews into two sizes: a high-resolution full render, and a
  small thumbnail. ([Issue
  #4511](https://github.com/quaive/ploneintranet/issues/4511))
- Change the loading of document previews to support jumping directly
  to comments. ([Issue
  #4512](https://github.com/quaive/ploneintranet/issues/4512))
- The permissions for tasks have been changed in order to allow the
  assignee and the reviewer more control. ([Issue
  #4545](https://github.com/quaive/ploneintranet/issues/4545))
- When editing group membership, sort the list of users
  alphabetically. ([Issue
  #4658](https://github.com/quaive/ploneintranet/issues/4658))
- Re-Add autoload-visible to lazy-load portlets on the dashboard.
  ([Issue #4685](https://github.com/quaive/ploneintranet/issues/4685))
- Removed unused option from workspace settings (custom order of tags)
  ([Issue #4697](https://github.com/quaive/ploneintranet/issues/4697))
- Adapt tiptap configuration to changes in pat-tiptap 3.0. ([Issue
  #4708](https://github.com/quaive/ploneintranet/issues/4708))
- Event edit view: moved the "delete" action and the "add / remove
  image" into the new more-menu. ([Issue
  #4577](https://github.com/quaive/ploneintranet/issues/4577))
- Event view: if an even has a hero image, that image is now shown
  prominently at the top, along with the title. That means the hero
  image is now also available on the normal event view (vs formerly
  only on the disbanded promo-view) ([Issue
  #4578](https://github.com/quaive/ploneintranet/issues/4578))

Fixed:

- When a user tries to reset their password by entering their email
  address, the process now also works if the user had previously opted
  to hide their email address. And it works also for sites where more
  than 10 users have a hidden email address. ([Issue
  #4412](https://github.com/quaive/ploneintranet/issues/4412))
- Fix the document preview generation with files with very long names.
  Use wkhtmltopdf to generate the preview for HTML files. ([Issue
  #4619](https://github.com/quaive/ploneintranet/issues/4619))
- Tiptap image selection widget: Align with prototype design changes.
  ([Issue #4642](https://github.com/quaive/ploneintranet/issues/4642))
- Improve UI when extranet feature is enabled. ([Issue
  #4653](https://github.com/quaive/ploneintranet/issues/4653))
- Restore user sync for large LDAP installations throwing
  LDAP_SIZELIMIT_EXCEEDED. Do not abort upgrade when no LDAP groups
  are configured for syncing. ([Issue
  #4656](https://github.com/quaive/ploneintranet/issues/4656))
- Properly list "All Intranet Users" group membership on
  userprofile, if extranet is enabled. ([Issue
  #4660](https://github.com/quaive/ploneintranet/issues/4660))
- The search for users in the contacts app is working again. ([Issue
  #4666](https://github.com/quaive/ploneintranet/issues/4666))
- Case Manager: Fixed number of changes per case ([Issue
  #4669](https://github.com/quaive/ploneintranet/issues/4669))
- Fixed issue when reordering workspace tags in some browsers. ([Issue
  #4676](https://github.com/quaive/ploneintranet/issues/4676))
- Case Manager: Fixed infinite scrolling. ([Issue
  #4677](https://github.com/quaive/ploneintranet/issues/4677))
- Do not crash on old files whose preview is still a GIF ([Issue
  #4713](https://github.com/quaive/ploneintranet/issues/4713))
- Fix the translations for "Workspaces" and "Groups" on the
  userprofile page ([Issue
  #4729](https://github.com/quaive/ploneintranet/issues/4729))

Technical:

- Remove a no longer needed patch that was backporting an upstream
  change in plone.resource ([Issue
  #4055](https://github.com/quaive/ploneintranet/issues/4055))
- News editing: For the effective and expiration date set the input
  type to date and remove the unused option `type` from
  pat-validation's config. ([Issue
  #4641](https://github.com/quaive/ploneintranet/issues/4641))
- Remove unused option margin and side for pat-bumper and avoid
  JavaScript console warnings. ([Issue
  #4717](https://github.com/quaive/ploneintranet/issues/4717))

Updated:

- quaive.app.taxonomy = 2.1.0
- quaive.resource.ploneintranet = 7.10.0

## 3.5.0 (2022-02-21)

Added:

- Added the possibility to receive the notifications in a digest (the
  UI has been disabled for the moment) ([Issue
  #3905](https://github.com/quaive/ploneintranet/issues/3905))

Changed:

- The time interval between two consecutive pdf generation of HTML
  documents has been decreased from 10 minutes to 1 minute ([Issue
  #2720](https://github.com/quaive/ploneintranet/issues/2720))
- More information is shown in the contact search results. ([Issue
  #4587](https://github.com/quaive/ploneintranet/issues/4587))
- Workspace grouping/sorting is remembered between logins. ([Issue
  #4599](https://github.com/quaive/ploneintranet/issues/4599))
- Tweaked news editing layout. ([Issue
  #4608](https://github.com/quaive/ploneintranet/issues/4608))
- Improved layout and navigation in contacts app and user profiles.
  ([Issue #4616](https://github.com/quaive/ploneintranet/issues/4616))
- Removed activity stream filter from workspaces and user profiles.
  ([Issue #4637](https://github.com/quaive/ploneintranet/issues/4637))

Fixed:

- Fixed issue that could cause wrong tile titles when customizing the
  dashboard. ([Issue
  #1601](https://github.com/quaive/ploneintranet/issues/1601))
- Correctly set the autofocus class in the comment boxes ([Issue
  #4487](https://github.com/quaive/ploneintranet/issues/4487))
- In workspaces, in the "Documents" tab, the plus-icon now allows
  users to add not only documents, but also folders and links. Those
  functions had previously been located under the 3-dots ("more")
  menu. ([Issue
  #4562](https://github.com/quaive/ploneintranet/issues/4562))
- Invalidate the acl_users cache when a group is created with members,
  or when the members of a group has been modified. Fixes SCR-1649.
  ([Issue #4568](https://github.com/quaive/ploneintranet/issues/4568))
- Restored some "Load more"-buttons in the activity stream that were
  erroneously removed. ([Issue
  #4571](https://github.com/quaive/ploneintranet/issues/4571))
- Restored activity stream comments on the dashboard in mobile view.
  ([Issue #4575](https://github.com/quaive/ploneintranet/issues/4575))
- Fix dashboard to load all portlets without the need to scroll.
  ([Issue #4602](https://github.com/quaive/ploneintranet/issues/4602))
- SCR-1713: Strip spaces from the user details, on creation ([Issue
  #4604](https://github.com/quaive/ploneintranet/issues/4604))
- Fixed the display of emails inside workspaces. ([Issue
  #4631](https://github.com/quaive/ploneintranet/issues/4631))
- In the workspace overview, selecting both the checkboxes "Only my
  workspaces" and "Archived" will return the proper results ([Issue
  #4638](https://github.com/quaive/ploneintranet/issues/4638))
- Fixed mobile navigatioon for contacts app ([Issue
  #4648](https://github.com/quaive/ploneintranet/issues/4648))

Technical:

- Fixed a naming conflict for "show archived". See
  <https://github.com/quaive/ploneintranet.prototype/issues/1546>
  Updated translations from transifex and proto.
- Better cookie handling: fixes a bug that caused authentication
  issues ([Issue
  #4614](https://github.com/quaive/ploneintranet/issues/4614))

Updated:

- Update Plone to 5.2.7
- Update quaive.resources.ploneintranet to 7.9.1

## 3.4.3 (2022-01-27)

Fixed:

- Fix dashboard to load all portlets without the need to scroll.
  ([Issue #4602](https://github.com/quaive/ploneintranet/issues/4602))

## 3.4.2 (2022-01-26)

Fixed:

- Correctly set the autofocus class in the comment boxes ([Issue
  #4487](https://github.com/quaive/ploneintranet/issues/4487))

## 3.4.1 (2022-01-21)

Fixed:

- Restored activity stream comments on the dashboard in mobile view.
  ([Issue #4575](https://github.com/quaive/ploneintranet/issues/4575))
  and ([Issue
  #4576](https://github.com/quaive/ploneintranet/issues/4576))

Updated:

- Update quaive.resources.ploneintranet to 7.8.6

## 3.4.0 (2022-01-19)

Added:

- The comment replies can now be edited or deleted ([Issue
  #4371](https://github.com/quaive/ploneintranet/issues/4371))
- Make the texteditor configurable. By changing the configuration
  setting `ploneintranet.layout.texteditor` to `redactor` or `tiptap`
  you can currently choose between those two text editors. ([Issue
  #4420](https://github.com/quaive/ploneintranet/issues/4420))
- Add user language preferences: a user can set a language for the
  System and another for Content, which is effectively a fallback for
  their preferred system language. ([Issue
  #4428](https://github.com/quaive/ploneintranet/issues/4428))
- Added minimal support for multilingual news ([Issue
  #4480](https://github.com/quaive/ploneintranet/issues/4480))

Changed:

- Improved display of Messages app
- App titles are translated (and no longer editable). ([Issue
  #4322](https://github.com/quaive/ploneintranet/issues/4322))
- The multilingual feature in Quaive also requires the registry record
  [ploneintranet.layout.multilingual_enabled]{.title-ref} to be set to
  True. Of course two or more languages should be configured in the
  site. ([Issue
  #4482](https://github.com/quaive/ploneintranet/issues/4482))
- News section maintainers should have the "Reviewer" role, so they
  can publish news items. ([Issue
  #4498](https://github.com/quaive/ploneintranet/issues/4498))
- Improve the rendering of Excel spreadsheets. ([Issue
  #4511](https://github.com/quaive/ploneintranet/issues/4511))
- Improved wording for number of comments indicator. ([Issue
  #4539](https://github.com/quaive/ploneintranet/issues/4539))
- Configure language selection for multilingual sites. ([Issue
  #4554](https://github.com/quaive/ploneintranet/issues/4554))

Fixed:

- Do not show the emergency contacts in the administrator tool app
  ([Issue #3883](https://github.com/quaive/ploneintranet/issues/3883))
- Disallow "contributor" view permission on non-published news
  items. Disallow "owner" editing of published news items. ([Issue
  #4196](https://github.com/quaive/ploneintranet/issues/4196))
- Fix for downloading a library topic as PDF ([Issue
  #4472](https://github.com/quaive/ploneintranet/issues/4472))
- Fixed translation of workspace policy description. ([Issue
  #4476](https://github.com/quaive/ploneintranet/issues/4476))
- Use immutable defaults for schema fields ([Issue
  #4479](https://github.com/quaive/ploneintranet/issues/4479))
- Correctly set the autofocus on the comment box which was
  intentionally opened. Refs: scr-1470 ([Issue
  #4487](https://github.com/quaive/ploneintranet/issues/4487))
- Improved layout for emergency contacts. ([Issue
  #4491](https://github.com/quaive/ploneintranet/issues/4491))
- Fixed display of deactivated users in contacts portlet and comments
  stream ([Issue
  #4494](https://github.com/quaive/ploneintranet/issues/4494))
- Fixed internal link URL in library. ([Issue
  #4502](https://github.com/quaive/ploneintranet/issues/4502))
- After deleting a task, reload the sidebar, to remain in the context
  of task management. ([Issue
  #4507](https://github.com/quaive/ploneintranet/issues/4507))
- Reset the language cookie when no the user selects to have the
  language negotiated by the browser ([Issue
  #4509](https://github.com/quaive/ploneintranet/issues/4509))
- When regenerating previews, actually purge the old ones if that is
  requested. ([Issue
  #4532](https://github.com/quaive/ploneintranet/issues/4532))
- SCR-1637: Adjust the todo workflow to allow todo items to be
  deleted. ([Issue
  #4545](https://github.com/quaive/ploneintranet/issues/4545))
- Fix month abbreviation not correctly displayed in calendar view and
  calendar dashboard tile. ([Issue
  #4547](https://github.com/quaive/ploneintranet/issues/4547))
- Removed erroneous "Load more"-buttons in the activity stream.
  ([Issue #4565](https://github.com/quaive/ploneintranet/issues/4565))

Technical:

- The context manager temporary_registry_record now lives in
  ploneintranet.testing
- Use interface provision rather than class comparison, when parsing
  onlyoffice modified event. ([Issue
  #4366](https://github.com/quaive/ploneintranet/issues/4366))
- Removed obsolete references to old-style PDF versions. ([Issue
  #4473](https://github.com/quaive/ploneintranet/issues/4473))
- Remove unused permission "Change portal events", which was removed
  upstream in Plone 5.0.8. ([Issue
  #4499](https://github.com/quaive/ploneintranet/issues/4499))
- Eliminate various warnings from Jenkins console logs. ([Issue
  #4504](https://github.com/quaive/ploneintranet/issues/4504))
- Allow usage of translator comments for translation messages to give
  more contextual information for translators. On usage, see the docs
  in development/frontend/translations. We now use Lingua to create
  pot-files instead of i18ndude. i18ndude is still used for other
  tasks. ([Issue
  #4505](https://github.com/quaive/ploneintranet/issues/4505))
- Only show the tiptap toolbar for Documents. Ref: SCR-1651. ([Issue
  #4551](https://github.com/quaive/ploneintranet/issues/4551))

Updated:

- Update plone.api to 2.0.0a2
- Update quaive.app.absences to 2.0.4
- Update quaive.app.audit to 3.0.2
- Update quaive.app.classifieds to 2.0.3
- Update quaive.app.jobs to 2.0.3
- Update quaive.app.legal to 1.2.3
- Update quaive.app.milestones to 2.0.9
- Update quaive.app.onlyoffice to 4.1.2
- Update quaive.app.polls to 1.0.5
- Update quaive.app.taxonomy to 2.0.2
- Update quaive.resources.ploneintranet to 7.8.5
- Use Products.ZCatalog=6.1 ([Issue
  #3943](https://github.com/quaive/ploneintranet/issues/3943))
- Update translations. ([Issue
  #4505](https://github.com/quaive/ploneintranet/issues/4505))

## 3.3.0 (2021-11-19)

Changed:

- Implement better error handling with more descriptive error pages
  and a call to action to better guide the user or administrator in
  error cases. ([Issue
  #4350](https://github.com/quaive/ploneintranet/issues/4350))
- The post box for adding replies to comments and sub-comments is now
  loaded asynchronously ([Issue
  #4371](https://github.com/quaive/ploneintranet/issues/4371))

Fixed:

- Allow the syndication sections to be edited again ([Issue
  #4145](https://github.com/quaive/ploneintranet/issues/4145))
- Improved user experience for the contact form. ([Issue
  #4350](https://github.com/quaive/ploneintranet/issues/4350))
- Fixed scrolling/batching of dashboard activity stream in mobile
  view. ([Issue
  #4434](https://github.com/quaive/ploneintranet/issues/4434))
- Do not link to profiles or avatars of deactivated users in posts or
  comments. ([Issue
  #4437](https://github.com/quaive/ploneintranet/issues/4437))
- Submitting an empty comment does not cause an error. ([Issue
  #4443](https://github.com/quaive/ploneintranet/issues/4443))
- Calendar: Fixed date span display of multi-day events. ([Issue
  #4444](https://github.com/quaive/ploneintranet/issues/4444))
- Another fix to make sure library downloads are up-to-date. ([Issue
  #4447](https://github.com/quaive/ploneintranet/issues/4447))
- Bookmarks on the dashboard: disable injection for external links,
  link to the app_url rather than the absolute_url and for apps.
  ([Issue #4458](https://github.com/quaive/ploneintranet/issues/4458))
- Set the userprofile source on initial login ([Issue
  #4465](https://github.com/quaive/ploneintranet/issues/4465))
- With some themes the PDF generated from HTML document had a colored
  background ([Issue
  #4468](https://github.com/quaive/ploneintranet/issues/4468))

Technical:

- Allow plone.resourceregistries.styles and
  plone.resourceregistries.scripts be available for Anonymous users to
  be able to render the 404 page properly. ([Issue
  #4350-1](https://github.com/quaive/ploneintranet/issues/4350))
- Fix permission checks on not acquired objects ([Issue
  #2078](https://github.com/quaive/ploneintranet/issues/2078))
- Customize the tile theming transform to use Diazo theming for HTTP
  error cases. ([Issue
  #4350](https://github.com/quaive/ploneintranet/issues/4350))

Updated:

- Updated quaive.app.classifieds to 2.0.2
- Updated quaive.app.jobs to 2.0.2
- Updated quaive.app.polls to 1.0.2
- Updated quaive.resources.ploneintranet to 7.6.0
- Updated quaive.resources.ploneintranet to 7.7.0

## 3.2.1 (2021-10-18)

Added:

- Added German translations related to workspace infographic. ([Issue
  #4436](https://github.com/quaive/ploneintranet/issues/4436))

Changed:

- Improved search results for emergency services. ([Issue
  #4418](https://github.com/quaive/ploneintranet/issues/4418))

Fixed:

- The comment replies are not batched anymore. Fixed a CSS class in
  the activity stream. ([Issue
  #4371](https://github.com/quaive/ploneintranet/issues/4371))
- Fixed a rendering problem in the library that pushed down file
  content too far. ([Issue
  #4423](https://github.com/quaive/ploneintranet/issues/4423))
- Fix to make sure library downloads are up-to-date. ([Issue
  #4433](https://github.com/quaive/ploneintranet/issues/4433))

Updated:

- Updated Plone to 5.2.6 ([Issue
  #4288](https://github.com/quaive/ploneintranet/issues/4288))
- Updated quaive.app.onlyoffice to 4.1. ([Issue
  #4425](https://github.com/quaive/ploneintranet/issues/4425))
- Updated quaive.app.absences to 2.0.2. ([Issue
  #4427](https://github.com/quaive/ploneintranet/issues/4427))
- Updated quaive.resources.ploneintranet to 7.5.4. ([Issue
  #4430](https://github.com/quaive/ploneintranet/issues/4430))

## 3.2.0 (2021-10-14)

Added:

- Added the possibility to add and configure a visual navigation map
  in the workspace home page ([Issue
  #4363](https://github.com/quaive/ploneintranet/issues/4363))
- We can reply now to post comments ([Issue
  #4371](https://github.com/quaive/ploneintranet/issues/4371))
- Display statistics on the about.html view for the number of users:
  total, creators, pending, enabled and disabled. ([Issue
  #4409](https://github.com/quaive/ploneintranet/issues/4409))

Changed:

- The cart actions do not touch the document body because it might
  disrupt the user editing activity ([Issue
  #2767](https://github.com/quaive/ploneintranet/issues/2767))
- Better batching of older replies ([Issue
  #4372](https://github.com/quaive/ploneintranet/issues/4372))
- Search app: event locations are now shown in search results. ([Issue
  #4382](https://github.com/quaive/ploneintranet/issues/4382))

Fixed:

- In the chat application, set the proper class to mark the
  conversation unread with a blue dot. ([Issue
  #4228](https://github.com/quaive/ploneintranet/issues/4228))
- Do not display the link to edit the folder properties in a workspace
  ([Issue #4362](https://github.com/quaive/ploneintranet/issues/4362))
- The previews for images attached to a post are not generated anymore
  using the pdf conversion, we use the standard Plone scales to do
  that ([Issue
  #4370](https://github.com/quaive/ploneintranet/issues/4370))
- When following an email notification link, present a login screen if
  necessary. ([Issue
  #4375](https://github.com/quaive/ploneintranet/issues/4375))
- Fix issues adding tasks from the todo app after selecting a
  workspace with no available milestones. The add task form does not
  show superspaces anymore. ([Issue
  #4395](https://github.com/quaive/ploneintranet/issues/4395))
- Fix an issue that prevented posting to the dashboard when the user
  came from a workspace. ([Issue
  #4400](https://github.com/quaive/ploneintranet/issues/4400))
- Solved an issue with the agenda items and spaces field on the event
  edit form ([Issue
  #4402](https://github.com/quaive/ploneintranet/issues/4402))
- The links to events in the search results have been fixed ([Issue
  #4404](https://github.com/quaive/ploneintranet/issues/4404))
- Adjust the news edit form to the new theme ([Issue
  #4407](https://github.com/quaive/ploneintranet/issues/4407))
- When a user tries to reset their password by entering their email
  address, the process now also works if the user had previously opted
  to hide their email address. ([Issue
  #4412](https://github.com/quaive/ploneintranet/issues/4412))
- Fixed some glaring mistranslations in Dutch. ([Issue
  #4831](https://github.com/quaive/ploneintranet/issues/4831))

Updated:

- Updated quaive.resources.ploneintranet to 7.5.3

## 3.1.1 (2021-09-21)

Added:

- The workspace folders can now have a lead image ([Issue
  #4356](https://github.com/quaive/ploneintranet/issues/4356))

Changed:

- For the (rich text) Information field on events, use the rich text
  editor toolbar. The Description field is now limited in length.
  ([Issue #3724](https://github.com/quaive/ploneintranet/issues/3724))
- The subject for the notifications email about tasks has been changed
  to include an hint about where the task is located (in the workspace
  or in the personal tasks list) ([Issue
  #4326](https://github.com/quaive/ploneintranet/issues/4326))
- The link to edit workspace folder properties is now in the sidebar
  three dots menu ([Issue
  #4355](https://github.com/quaive/ploneintranet/issues/4355))
- Workspace titles are shown in many different contexts. They need to
  be as short as possible, so that they can be recognised quickly. A
  more detailed explanation about what to find in a certain workspace
  can be placed into the description. Therefore, the titles are now
  limited to 100 characters.

Fixed:

- Do not auto-rename files when saving from OnlyOffice. Fixes
  <https://github.com/quaive/quaive.app.onlyoffice/issues/21>. ([Issue
  #4365](https://github.com/quaive/ploneintranet/issues/4365))
- Fix a problem with notifications to calendar maintainers that could
  lead to a broken link. ([Issue
  #4368](https://github.com/quaive/ploneintranet/issues/4368))
- Fixed a problem in the library that prevented opening files. ([Issue
  #4369](https://github.com/quaive/ploneintranet/issues/4369))
- Strip spaces from userids when resetting password. ([Issue
  #4374](https://github.com/quaive/ploneintranet/issues/4374))

Technical:

- Add diagnostic logging to passwordreset attempts, so we can use the
  logs when clients complain something is not working. ([Issue
  #4374](https://github.com/quaive/ploneintranet/issues/4374))

Updated:

- Updated quaive.resources.theme to 7.5.2
- Updated quaive.app.onlyoffice to 4.0.1

## 3.1.0 (2021-09-10)

Added:

- We now have an unread mark in the notifications panel. Clicking the
  link to the notification marks it as read. ([Issue
  #4271](https://github.com/quaive/ploneintranet/issues/4271))

Changed:

- In the workspace overview the grouping mode is persisted in the same
  exact way it is persisted the sorting ([Issue
  #324](https://github.com/quaive/ploneintranet/issues/324))
- The old notifications are removed if they have been already read and
  they are not in a small number. ([Issue
  #4150](https://github.com/quaive/ploneintranet/issues/4150))
- The superspaces tile only shows the "add workspace" element if the
  user has the respective permission. ([Issue
  #4241](https://github.com/quaive/ploneintranet/issues/4241))
- Remove open workspaces from the list of my workspaces ([Issue
  #4242](https://github.com/quaive/ploneintranet/issues/4242)) ([Issue
  #4243](https://github.com/quaive/ploneintranet/issues/4243))
- By using a marker interface it is possible to hide the comments on
  an object ([Issue
  #4293](https://github.com/quaive/ploneintranet/issues/4293))
- When an event is edited with auto-save on, the sidebar is no longer
  reloaded. This prevents losing the scroll position that a reload
  would cause. ([Issue
  #4294](https://github.com/quaive/ploneintranet/issues/4294))
- Workflow menu: if there is only one possible transition and the
  current workflow state is the initial state, show the available
  transition in form of a button, instead of a drop-down menu. ([Issue
  #4298](https://github.com/quaive/ploneintranet/issues/4298))
- The link to the videoconf help on the videoconf page in workspaces
  always opens the help text in a modal. ([Issue
  #4346](https://github.com/quaive/ploneintranet/issues/4346))
- Events now have a separate URL field, making it easy to point to an
  external source that is relevant to that event. ([Issue
  #3409](https://github.com/quaive/ploneintranet/issues/3409))
- Event form: the timezone selector is now in the same line as the
  "all day" switch, making the form more compact. ([Issue
  #4307](https://github.com/quaive/ploneintranet/issues/4307))

Fixed:

- The month abbreviation in the event icon is now translated ([Issue
  #3401](https://github.com/quaive/ploneintranet/issues/3401))
- Do not let all the user edit the superspaces. ([Issue
  #4241](https://github.com/quaive/ploneintranet/issues/4241))
- In the Library, the description of a section / folder is now shown
  within the respective tile, if a description was set. ([Issue
  #4251](https://github.com/quaive/ploneintranet/issues/4251))
- Fixed cut & paste / copy & paste of images through the context menu.
  ([Issue #4262](https://github.com/quaive/ploneintranet/issues/4262))
- Fixed a problem sharing an event to a calendar when no maintainer
  email was found ([Issue
  #4267](https://github.com/quaive/ploneintranet/issues/4267))
- Fix the search filters in the profile documents tab ([Issue
  #4274](https://github.com/quaive/ploneintranet/issues/4274))
- In the library view documents with exactly one tag are now properly
  displayed ([Issue
  #4282](https://github.com/quaive/ploneintranet/issues/4282))
- Emergency Services are now shown first in the search results.
  ([Issue #4284](https://github.com/quaive/ploneintranet/issues/4284))
- The main navigation for mobile browsers now works independently from
  the main global navigation. This fixes a problem with the
  application labels for desktop browsing. ([Issue
  #4290](https://github.com/quaive/ploneintranet/issues/4290))
- Make sure that styling the workflow menu according to the current
  state works again. ([Issue
  #4296](https://github.com/quaive/ploneintranet/issues/4296))
- Fixed an error happening when the content of the
  `ploneintranet.workspace.autosave_portal_types` field contains the
  value `None` instead of an empty tuple ([Issue
  #4309](https://github.com/quaive/ploneintranet/issues/4309))
- Fixed a visual glitch in emergency contacts. ([Issue
  #4330](https://github.com/quaive/ploneintranet/issues/4330))
- Fixes visual glitch on the "follow" button. ([Issue
  #4336](https://github.com/quaive/ploneintranet/issues/4336))
- Fix news navigation inside the News Publisher app. ([Issue
  #4347](https://github.com/quaive/ploneintranet/issues/4347))

Technical:

- Do not use anymore an alias for long ([Issue
  #4134](https://github.com/quaive/ploneintranet/issues/4134))
- Added a view for site administrators that allows to export the list
  of current users as a CSV file. ([Issue
  #4249](https://github.com/quaive/ploneintranet/issues/4249))
- We currently use docsplit as a wrapper script for various command
  line tools, to get information on files and to convert them to
  various formats. It hasn't had a release since 2014 and has been
  problematic to install on various platforms as a result. This has
  now been replaced by calling the underlying commands directly.
  ([Issue #4254](https://github.com/quaive/ploneintranet/issues/4254))
- Support for additional relations (IContextSourceBinder). ([Issue
  #4263](https://github.com/quaive/ploneintranet/issues/4263))
- Fix broken tal statement ([Issue
  #4315](https://github.com/quaive/ploneintranet/issues/4315))
- Code that was firing an event when a chat message was created has
  been removed because there was no associated subscriber. ([Issue
  #4318](https://github.com/quaive/ploneintranet/issues/4318))

Updated:

- Updated Plone to 5.2.5
- Updated quaive.app.absences to 2.0.1
- Updated quaive.app.audit to 3.0.1
- Updated quaive.app.classifieds to 2.0.1
- Updated quaive.app.legal to 1.2.2
- Updated quaive.app.taxonomy to 2.0.1
- Updated quaive.resources.ploneintranet to 7.5.1

## 3.0.1.1 (2021-09-09)

Updated:

- Revert translation change of "favoris" to "signets". ([Issue
  #1408](https://github.com/quaive/ploneintranet/issues/1408))

## 3.0.1 (2021-09-09)

Updated:

- Updated French translations. ([Issue
  #1408](https://github.com/quaive/ploneintranet/issues/1408))

## 3.0.0.1 (2021-08-12)

Fixed:

- The main navigation for mobile browsers now works independently from
  the main global navigation. This fixes a problem with the
  application labels for desktop browsing. ([Issue
  #4290](https://github.com/quaive/ploneintranet/issues/4290))

## 3.0.0 (2021-07-21)

Added:

- Link to the relevant help section from the sidebar of certain apps.
  ([Issue #1208](https://github.com/quaive/ploneintranet/issues/1208))
- Added a notifications panel in the user preferences to control if
  the user wants to receive emails on status update interactions
  ([Issue #4032](https://github.com/quaive/ploneintranet/issues/4032))
- Added the possibility to connect to a RabbitMQ server to send and
  receive events that will trigger updates in the browser. For the
  time being we use push support for updating the notification
  counter. ([Issue
  #4083](https://github.com/quaive/ploneintranet/issues/4083))
- Enable delegation of news story contributions on a per-section basis
  to all users, or selected user groups. The contributed news stories
  still need to be approved and published before they become visible
  to all. ([Issue
  #4144](https://github.com/quaive/ploneintranet/issues/4144))

Changed:

- The notifications are now accessible using an app ([Issue
  #4032](https://github.com/quaive/ploneintranet/issues/4032))
- Preferences are now managed through an app ([Issue
  #4032](https://github.com/quaive/ploneintranet/issues/4032))
- In the News Publisher, there is now a prominent link to display the
  front page of the magazine. This is necessary since the application
  labels are themselves no longer links that reset the view to to
  start screen of an app. ([Issue
  #4198](https://github.com/quaive/ploneintranet/issues/4198))
- More smooth experience when browsing the library: the browsing
  history is recorded (the URL in the browser adapts accordingly), and
  the full description of items in the library is shown as a tooltip
  when available.
- Add an upgrade step to install the Help app, if it isn't already
  installed. ([Issue
  #1246](https://github.com/quaive/ploneintranet/issues/1246))
- The link to a post from a notification email (ABC mentioned you,
  etc) now opens in an improved stand-alone view of that post. ([Issue
  #3813](https://github.com/quaive/ploneintranet/issues/3813))
- Drop support for Python 2.7, support only Python 3.7 and 3.8. Update
  our own version to reflect this major change. ([Issue
  #4133](https://github.com/quaive/ploneintranet/issues/4133))
- Next to the application labels of an app or a workspace there is now
  a "home" icon. A click on home lets the user switch context, for
  example for checking a page in the library, while keeping the
  application label present. With another click, the user can switch
  back to the app or workspace that was last open. ([Issue
  #4198](https://github.com/quaive/ploneintranet/issues/4198))
- Unify the way our panels are displayed even further.
- Design Changes:
  - Added a large number of translations to prototype
  - Created documentation pages for all apps
  - Fixed the navigation problem in inhouse caused by the logo
    overlapping navitems
  - Upgraded to patternslib 4.5.1
  - Introduced coloured app icons
  - Added a way to delegate news contributions to a group
  - Fixed a problem in the case manager timeline display
  - Improved icon contrast
  - Multitasking 1st step
  - New App icons
  - Direct link from apps to help pages
  - Introduced app categories - a filter bar on top of the app view
  - Added a more menu in the multitasking badge and on each app tile
    containing links to about, help, feedback, bookmark, pin and
    open
  - Added a feedback form and feedback app to collect direct
    feedback from users
  - Polls App
  - Fix the display of the image bank prototype
  - New icons for portlets
  - Improved display of the navigation bar when using long titles.
    The bar will adapt and use less whitespace
  - Added support for workspace navigation maps
  - New theme for Rixensart
  - A fix for the workspace sidebar where the more menu overlapped
    with the batch action buttons
  - Rearranging prototype to store templates used by the software in
    a dedicated folder
  - Prepare the workspaces overview to become an app itself
  - Cleanup of all templates fixing markup errors

Fixed:

- Before cutting an object check that we have the permission to delete
  it on the parent. ([Issue
  #4229](https://github.com/quaive/ploneintranet/issues/4229))
- The counter in the conversation app bubble is updated every time a
  new message arrives. ([Issue
  #1735](https://github.com/quaive/ploneintranet/issues/1735))
- Prevent multiple notifications when a user receives a comment with a
  mention in a document he has published ([Issue
  #3804](https://github.com/quaive/ploneintranet/issues/3804))
- When calendar maintainers get notified about a shared event, the
  email addresses of all maintainers are no longer exposed for all
  recipients to see. ([Issue
  #3978](https://github.com/quaive/ploneintranet/issues/3978))
- Fixed an issue that prevented to browser the workspace documents by
  type if they had images inside ([Issue
  #3983](https://github.com/quaive/ploneintranet/issues/3983))
- If a document gets renamed in a workspace, its id (short name) will
  be updated accordingly, if the respective setting
  rename_after_title_changed is active. This renaming will happen if
  documents are set to auto-save (default). Merely editing the title
  in the document edit form will not trigger this renaming. ([Issue
  #4094](https://github.com/quaive/ploneintranet/issues/4094))
- Fixed an error in the "group by tag" view of the library ([Issue
  #4107](https://github.com/quaive/ploneintranet/issues/4107))
- Search for phrases containing dashes, e.g. "VRT-CAR-003", now
  works. Previously this got parsed as "[VRT]{.title-ref} and not
  [CAR]{.title-ref} and not [003]{.title-ref}". Negative queries are
  still supported if the dash is preceded by a space, as in
  "VRT-CAR-003 -fysio" which translates as
  "[VRT-CAR-003]{.title-ref} and not [fysio]{.title-ref}". ([Issue
  #4153](https://github.com/quaive/ploneintranet/issues/4153))
- Removed the creation of wrong i18n message factories, so that
  message extraction works again. ([Issue
  #4157](https://github.com/quaive/ploneintranet/issues/4157))
- Fixed an issue that prevents tagging in the activity stream when
  there are a lot of tags in the system. ([Issue
  #4167](https://github.com/quaive/ploneintranet/issues/4167))
- Show pinned news items on top in "Department news" sections. ([Issue
  #4203](https://github.com/quaive/ploneintranet/issues/4203))
- Honour the registry record ploneintranet.notifications.email.enabled
  for emails that deal fix posts, comments and mentions ([Issue
  #4209](https://github.com/quaive/ploneintranet/issues/4209))
- Notifications are delivered only to the active users ([Issue
  #4210](https://github.com/quaive/ploneintranet/issues/4210))
- When we install ploneintranet we change the default workflow. The
  security settings are now recalculated to ensure they respect the
  new workflow. ([Issue
  #4211](https://github.com/quaive/ploneintranet/issues/4211))
- Fixed some cases where the Cut action was shown although the user
  had no permission to use it. ([Issue
  #4229](https://github.com/quaive/ploneintranet/issues/4229))
- Fixed error in version history for items with very old versions.
  ([Issue #4237](https://github.com/quaive/ploneintranet/issues/4237))
- Fixed an issue that prevented adding or removing a workspace image
  to / from a workspace. ([Issue
  #4257](https://github.com/quaive/ploneintranet/issues/4257))

Technical:

- BBB code removed because we use plone.locking 2.2.4 ([Issue
  #1324](https://github.com/quaive/ploneintranet/issues/1324))
- Remove the upgrade steps that were already present in 2.1.0. That
  means that to use PloneIntranet 3 you have to upgrade at least from
  ploneintranet 2.1.0 and you should already be on Python 3. ([Issue
  #1584](https://github.com/quaive/ploneintranet/issues/1584))
- The @@about.html page has been improved to show in a cleaner way the
  changelog and to add to it the towncrier entries ([Issue
  #3504](https://github.com/quaive/ploneintranet/issues/3504))
- Remove the unwanted layer even if they are not directly provided
  (this usually happens when an add on provides a layer that overrides
  an excluded one but this is not added to the themeswitcher setting)
  ([Issue #4106](https://github.com/quaive/ploneintranet/issues/4106))
- Clean up and improve the performances of the create_title_from_id
  event handler ([Issue
  #4179](https://github.com/quaive/ploneintranet/issues/4179))
- Remove source checkouts from master branch. ([Issue
  #4248](https://github.com/quaive/ploneintranet/issues/4248))

Updated:

- Update collective.mustread = 2.0.2
- Update ftw.upgrade to 3.1.0
- Update quaive.app.legal to 1.2.0
- Update openpyxl = 3.0.7
- Update quaive.app.onlyoffice = 4.0.0
- Update quaive.resources.ploneintranet to 7.4.1

## Older changelogs

> CHANGES22
>
> CHANGES21
>
> CHANGES20
>
> CHANGES10
