from pathlib import Path
from setuptools import setup

version = "7.2.0"

long_description = "\n\n".join(
    [Path("README.md").read_text(), Path("CHANGES.md").read_text()]
)

setup(
    name="ploneintranet",
    version=version,
    description="Intranet suite for Plone",
    long_description=long_description,
    long_description_content_type="text/markdown",
    # Get more strings from https://pypi.org/classifiers/
    classifiers=[
        "Environment :: Web Environment",
        "Framework :: Plone",
        "Framework :: Plone :: 6.1",
        "License :: OSI Approved :: GNU General Public License v2 (GPLv2)",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Development Status :: 5 - Production/Stable",
        "Topic :: Office/Business",
        "Topic :: Office/Business :: Groupware",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: GNU General Public License v2 (GPLv2)",
    ],
    keywords="intranet social activitystream collaboration groupware",
    author="Plone Intranet Consortium",
    author_email="info@ploneintranet.org",
    url="https://github.com/ploneintranet/ploneintranet",
    license="gpl",
    include_package_data=True,
    zip_safe=False,
    python_requires=">=3.11",
    install_requires=[
        "setuptools",
        # -*- Extra requirements: -*-
        "alembic",
        "beautifulsoup4",
        "Celery[redis]",
        "chardet",
        "collective.monkeypatcher",
        "collective.honeypot",
        "collective.ftw.upgrade",
        "collective.mustread>=2.1.0",
        "collective.workspace",
        "dexterity.membrane>=1.1.0",
        "emailcompat32crlf",
        "flower",
        "icalendar",
        "networkx",
        "openpyxl",
        "packaging",
        "pdfrw",
        "pika",
        "Plone",
        "plone.api",
        "plone.app.blocks",
        "plone.app.relationfield",
        "plone.app.theming",
        "plone.app.tiles",
        "plone.autoform",
        "plone.base>=3.1.0",
        "plone.restapi",
        "plone.supermodel",
        "plone.tiles",
        "plonetheme.barceloneta",
        "Products.MemcachedManager[python-memcached]",
        "pytz",
        "quaive.resources.ploneintranet>=11.3.3",
        "redis",
        "requests",
        "scorched",
        "sh",
        "slc.mailrouter",
        "slc.outdated",
        "tablib",
        "twitter-text-python",
        "Unidecode",
        "weasyprint",
        "z3c.jbot",
        "z3c.saconfig",
        "zope.configuration>=6.0",
    ],
    extras_require={
        "test": [
            "plone.app.testing",
            "plone.app.robotframework[debug]",
            "faker",
            "responses",
            "gitpython",
        ],
        "suite": [],
        "core": [],
        "microblog": [],
        "activitystream": [],
        "themeswitcher": [],
        "todo": [],
        "docconv": [],
        "pagerank": [],
        "develop": [],
        "release": [
            "zest.releaser[recommended]",
            "zest.pocompile",
            "zestreleaser.towncrier",
            "gocept.zestreleaser.customupload",
        ],
        "solr": [],
        "theme": [],
    },
    entry_points="""
      # -*- Entry points: -*-
      [z3c.autoinclude.plugin]
      target = plone

      [console_scripts]
      fastest=ploneintranet.fastest:main

      [zodbupdate]
      renames = ploneintranet.patches:rename_dict
      """,
)
