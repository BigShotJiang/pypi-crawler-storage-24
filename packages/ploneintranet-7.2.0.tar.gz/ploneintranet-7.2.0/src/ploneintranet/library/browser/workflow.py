from ploneintranet.layout.browser.workflow import WorkflowMenu


class LibraryWorkflowMenu(WorkflowMenu):
    def form_pat_inject_options(self):
        """Return the data-path-inject options we want to use"""
        return "target: #document-content-library; source: #document-content-library"
