from plone import api
from ploneintranet.library.testing import IntegrationTestCase
from ploneintranet.userprofile.behaviors.maintainer_group import (
    IMaintainerGroupListSupport,
)


class TestLibrarySharing(IntegrationTestCase):
    """Test the sharing in the context of the library"""

    def setUp(self):
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]
        self.library = self.portal.library
        self.section = self.library["human-resources"]
        self.folder = self.section.holidays
        api.group.create("group1")
        api.group.create("group2")

    def test_section_behavior(self):
        self.assertTrue(IMaintainerGroupListSupport.providedBy(self.section))

    def test_folder_behavior(self):
        self.assertTrue(IMaintainerGroupListSupport.providedBy(self.folder))

    def test_edit_section_maintainer_group_list(self):
        """Test the edit form for the section"""
        request = self.request.clone()
        request.method = "POST"

        # Assign group1
        request.form["maintainer_group_list"] = "group1"
        view = api.content.get_view(
            "panel-edit-library-section", context=self.section, request=request
        )
        view()
        self.assertSetEqual(view.context.maintainer_group_list, {"group1"})

        # Assign group1
        request.__annotations__.clear()
        request.form["maintainer_group_list"] = "group2"
        view()
        self.assertSetEqual(view.context.maintainer_group_list, {"group2"})

        # Assign both
        request.__annotations__.clear()
        request.form["maintainer_group_list"] = "group1,group2"
        view()
        self.assertSetEqual(view.context.maintainer_group_list, {"group1", "group2"})
        request.__annotations__.clear()

        # Assign none
        request.__annotations__.clear()
        request.form["maintainer_group_list"] = ""
        view()
        self.assertSetEqual(view.context.maintainer_group_list, set())

    def test_edit_folder_maintainer_group_list(self):
        """Test the edit form for the folder

        It has some quirks because it has to handle the parent maintainer_group_list
        """
        request = self.request.clone()
        request.method = "POST"

        self.section.maintainer_group_list = {"group1"}

        # Assigning group1 is impossible because it is already assigned in the parent
        request.form["maintainer_group_list"] = "group1"
        view = api.content.get_view(
            "panel-edit-library-section", context=self.folder, request=request
        )
        view()
        self.assertSetEqual(view.context.maintainer_group_list, set())

        # But if it is already there it will not be removed
        request.__annotations__.clear()
        request.form["maintainer_group_list"] = "group1"
        self.folder.maintainer_group_list = {"group1"}
        view()
        self.assertSetEqual(view.context.maintainer_group_list, {"group1"})

        # We can still remove it
        request.__annotations__.clear()
        request.form["maintainer_group_list"] = ""
        view()
        self.assertSetEqual(view.context.maintainer_group_list, set())

        # and add anew one
        request.__annotations__.clear()
        request.form["maintainer_group_list"] = "group1,group2"
        view()
        self.assertSetEqual(view.context.maintainer_group_list, {"group2"})

    def test_sharing_permissions(self):
        """Test that setting the maintainer_group_list actually shares permissions"""
        api.user.create(username="foo", email="foo@example.com")
        api.group.add_user(groupname="group1", username="foo")

        # The user has no fancy roles by default
        self.assertSetEqual(
            set(api.user.get_roles(username="foo", obj=self.section)),
            {"Authenticated", "Member"},
        )
        self.assertSetEqual(
            set(api.user.get_roles(username="foo", obj=self.folder)),
            {"Authenticated", "Member"},
        )

        # Setting group1 as maintainer for the section grants the roles to the user
        self.section.maintainer_group_list = {"group1"}
        self.assertSetEqual(
            set(api.user.get_roles(username="foo", obj=self.section)),
            {"Authenticated", "Contributor", "Editor", "Member", "Reader", "Reviewer"},
        )
        # the roles are inherited also in the parent folder
        self.assertSetEqual(
            set(api.user.get_roles(username="foo", obj=self.folder)),
            {"Authenticated", "Contributor", "Editor", "Member", "Reader", "Reviewer"},
        )

        # Unset the group 1 as maintainer for the section but set it on the folder
        self.section.maintainer_group_list = set()
        self.folder.maintainer_group_list = {"group1"}
        self.assertSetEqual(
            set(api.user.get_roles(username="foo", obj=self.section)),
            {"Authenticated", "Member"},
        )
        # the roles are inherited also in the parent folder
        self.assertSetEqual(
            set(api.user.get_roles(username="foo", obj=self.folder)),
            {"Authenticated", "Contributor", "Editor", "Member", "Reader", "Reviewer"},
        )
