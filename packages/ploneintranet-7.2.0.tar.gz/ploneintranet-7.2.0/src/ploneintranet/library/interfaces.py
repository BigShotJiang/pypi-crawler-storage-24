"""Interfaces for Library API."""

from plone.app.contenttypes.interfaces import IPloneAppContenttypesLayer
from ploneintranet.docconv.client.interfaces import IPloneintranetDocconvClientLayer
from ploneintranet.layout.interfaces import IAppLayer
from zope.interface import Interface


class IPloneintranetLibraryLayer(Interface):
    """Marker interface that defines a Zope 3 browser layer."""


class ILibraryContentLayer(
    IAppLayer, IPloneintranetDocconvClientLayer, IPloneAppContenttypesLayer
):
    """Marker interface for views registered only for content
    within a ILibraryApp section.
    Subclasses IPloneAppContenttypesLayer to override
    p.a.c. view registrations.
    """
