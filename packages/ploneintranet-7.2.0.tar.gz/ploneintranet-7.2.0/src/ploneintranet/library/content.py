from plone.dexterity import content
from ploneintranet.layout.app import AbstractAppContainer
from ploneintranet.layout.interfaces import IAppContainer
from ploneintranet.library.interfaces import ILibraryContentLayer
from zope.interface import implementer
from zope.interface import Interface

import logging

log = logging.getLogger(__name__)


class ILibraryContainer(Interface):
    """Marker interface for library containers"""


class ILibraryApp(ILibraryContainer, IAppContainer):
    """Toplevel Library singleton to contain all library content"""


class ILibrarySection(ILibraryContainer):
    """Library Sections can contain Folders"""


class ILibraryFolder(ILibraryContainer):
    """Library Folders can contain Pages and/or sub-Folders"""


@implementer(ILibraryApp, IAppContainer)
class LibraryApp(AbstractAppContainer, content.Container):
    app_name = "library"
    app_layers = (ILibraryContentLayer,)
    devices = "desktop tablet"


@implementer(ILibrarySection)
class LibrarySection(content.Container):
    """ """


@implementer(ILibraryFolder)
class LibraryFolder(content.Container):
    """ """
