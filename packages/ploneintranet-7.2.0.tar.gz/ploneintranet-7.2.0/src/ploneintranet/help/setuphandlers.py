from logging import getLogger
from plone import api

logger = getLogger()


def create_help_app():
    """Create the help application"""
    portal = api.portal.get()
    apps = portal.apps
    app_id = "help"
    if app_id not in apps:
        api.content.create(
            container=apps,
            type="ploneintranet.layout.app",
            title="Help",
            id=app_id,
            safe_id=False,
            app="@@app-help",
            devices="desktop tablet mobile",
        )

    app = getattr(apps, app_id)
    if api.content.get_state(app) == "published":
        return
    try:
        api.content.transition(app, to_state="published")
    except BaseException:
        logger.exception("Cannot publish the app: %r", app)


def post_default(context):
    """Actions needed after importing
    the ploneintranet.help:default profile
    """
    create_help_app()
