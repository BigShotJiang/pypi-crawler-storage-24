from plone import api
from ploneintranet.core import _
from ploneintranet.layout.interfaces import IAppView
from Products.Five import BrowserView
from zope.interface import implementer


@implementer(IAppView)
class View(BrowserView):
    """The view for this app"""

    app_name = "help"
    title = _("label_title_app_help", default="Help")

    @property
    def support_email(self):
        return api.portal.get_registry_record(
            "ploneintranet.help.support.email", default=None
        )

    @property
    def support_phone(self):
        return api.portal.get_registry_record(
            "ploneintranet.help.support.phone", default=None
        )
