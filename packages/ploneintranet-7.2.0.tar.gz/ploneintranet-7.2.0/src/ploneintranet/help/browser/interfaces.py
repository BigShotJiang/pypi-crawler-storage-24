from zope.publisher.interfaces.browser import IDefaultBrowserLayer


class IPloneintranetHelpLayer(IDefaultBrowserLayer):
    """Marker interface to define ZTK browser layer"""
