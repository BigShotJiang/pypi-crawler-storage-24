from plone import api
from plone.app.testing import IntegrationTesting
from plone.resource.file import FilesystemFile
from ploneintranet import api as pi_api
from ploneintranet.api.testing import IntegrationTestCase
from ploneintranet.api.testing import PloneintranetApiLayer
from ploneintranet.docconv.client.interfaces import IPreviewSettings
from ploneintranet.docconv.client.previews import PREVIEW_URL
from ploneintranet.testing import dummy_file
from ZODB.blob import Blob


class Layer(PloneintranetApiLayer):
    def setUpPloneSite(self, portal):
        super().setUpPloneSite(portal)
        testfolder = api.content.create(
            type="Folder", title="Testfolder", container=portal
        )
        api.content.create(
            type="File",
            id="test-file",
            title="Test File",
            file=dummy_file(filename="test.odt"),
            container=testfolder,
        )
        api.content.create(
            type="Document",
            id="test-doc",
            title="Test Doc",
            text="This is a test doc with no preview generated (yet)",
            container=testfolder,
        )


FIXTURE = Layer()

INTEGRATION_TESTING = IntegrationTesting(
    bases=(FIXTURE,), name="PloneintranetAPIPreviewsLayer:Integration"
)


class TestPreviews(IntegrationTestCase):

    layer = INTEGRATION_TESTING

    def setUp(self):
        self.app = self.layer["app"]
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]
        self.testfolder = self.portal.testfolder
        self.testfile = self.testfolder["test-file"]
        self.testdoc = self.testfolder["test-doc"]

    def test_get_preview_urls(self):
        preview_urls = pi_api.previews.get_preview_urls(self.testfile)
        self.assertEqual(len(preview_urls), 1)
        self.assertIn("?page=1", preview_urls[0])
        # Call the preview view one to generate the svg
        self.testfile.restrictedTraverse("@@render.svg")()

        settings = IPreviewSettings(self.testfile).blob_files
        self.assertIn("original_svg_1.svg", settings)
        self.assertIn("text/dump_1.txt", settings)

    def test_fallback_image_url(self):
        self.assertEqual(
            pi_api.previews.fallback_image_url(self.testfile),
            "/".join((self.portal.absolute_url(), PREVIEW_URL)),
        )

    def test_get_thumbnail(self):
        thumbnail = pi_api.previews.get_thumbnail(self.testfile)
        # Returns default until we call svg_preview for the first time
        self.assertIsInstance(thumbnail, FilesystemFile)
        self.testfile.restrictedTraverse("@@render.svg")()
        thumbnail = pi_api.previews.get_thumbnail(self.testfile)
        self.assertIsInstance(thumbnail, Blob)  # found a thumb

        thumbnail = pi_api.previews.get_thumbnail(self.testdoc)
        self.assertIsInstance(thumbnail, FilesystemFile)  # return default img

    def test_previews_disable_enable(self):
        # 1st run with previews disabled
        pi_api.previews.events_disable(self.request)
        testfile = api.content.create(
            type="File",
            id="test-file-1",
            title="Test File",
            file=dummy_file(filename="test.odt"),
            container=self.testfolder,
        )
        self.assertFalse(pi_api.previews.has_previews(testfile))
        # 2nd run with previews enabled
        pi_api.previews.events_enable(self.request)
        testfile = api.content.create(
            type="File",
            id="test-file-2",
            title="Test File",
            file=dummy_file(filename="test.odt"),
            container=self.testfolder,
        )
        self.assertTrue(pi_api.previews.has_previews(testfile))

    def test_events_disable_enable_requestfallback(self):
        # 1st run with previews disabled
        pi_api.events.disable_previews()
        testfile = api.content.create(
            type="File",
            id="test-file-1",
            title="Test File",
            file=dummy_file(filename="test.odt"),
            container=self.testfolder,
        )
        self.assertFalse(pi_api.previews.has_previews(testfile))
        # 2nd run with previews enabled
        pi_api.events.enable_previews()
        testfile = api.content.create(
            type="File",
            id="test-file-2",
            title="Test File",
            file=dummy_file(filename="test.odt"),
            container=self.testfolder,
        )
        self.assertTrue(pi_api.previews.has_previews(testfile))

    def test_num_pages(self):
        self.assertEqual(pi_api.previews.num_pages(self.testfile), 1)
