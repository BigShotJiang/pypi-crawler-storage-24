from DateTime import DateTime
from zope.annotation.interfaces import IAttributeAnnotatable
from zope.interface import implementer


@implementer(IAttributeAnnotatable)
class FakeUserprofile:
    """This mocks a membrane user for testing purposes"""

    _modified = DateTime()

    def modified(self):
        """Since Plone 6 this is needed to render the personal bar viewlet"""
        return self._modified
