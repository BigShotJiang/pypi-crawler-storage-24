"""Methods to generate and access preview images on content"""

from ploneintranet.docconv.client.pdf import generate_pdf  # noqa: F401
from ploneintranet.docconv.client.previews import converting  # noqa: F401
from ploneintranet.docconv.client.previews import fallback_image_url  # noqa: F401
from ploneintranet.docconv.client.previews import get_pdf  # noqa: F401
from ploneintranet.docconv.client.previews import get_preview_urls  # noqa: F401
from ploneintranet.docconv.client.previews import get_thumbnail  # noqa: F401
from ploneintranet.docconv.client.previews import has_pdf  # noqa: F401
from ploneintranet.docconv.client.previews import has_previews  # noqa: F401
from ploneintranet.docconv.client.previews import num_pages  # noqa: F401
from ploneintranet.docconv.client.previews import purge_previews  # noqa: F401
from ploneintranet.docconv.client.previews import successfully_converted  # noqa: F401
from ploneintranet.docconv.client.utils import getDocumentType
from Products.MimetypesRegistry.interfaces import MimeTypeException
from zope.globalrequest import getRequest

import logging

logger = logging.getLogger(__name__)

event_keys = (
    "ploneintranet.previews.handle_file_creation",
    "ploneintranet.previews.content_added_in_workspace",
    "ploneintranet.previews.content_edited_in_workspace",
)


def is_allowed_document_type(obj):
    """Check if object can actually be converted
    :param obj: The Plone object to get previews for
    :type obj: A Plone content object
    :return: True if object can be converted
    :rtype: boolean
    """
    try:
        return bool(getDocumentType(obj))
    except MimeTypeException as e:
        logger.warning("Mimetype issue for %r: %s", obj, e)
    return False


def has_thumbnails(obj):
    """
    Test if the object has generated previews.
    As a fallback, also check for the presence of a lead image.

    :param obj: The Plone object to get previews for
    :type obj: A Plone content object
    :return: True if there are previews. False otherwise.
    :rtype: boolean
    """
    if has_previews(obj):
        return True
    # also check for (lead) image
    if not hasattr(obj, "image") or not obj.image:
        return False
    adapter = obj.unrestrictedTraverse("@@images")
    if not adapter:
        return False
    return bool(adapter.available_sizes.get("mini"))


def events_disable(request=None):
    """Temporarily disable event-driven preview generation for this request.

    :param request: The request for which events are to be disabled
    :type request: Request
    """
    if not request:
        request = getRequest()
    if not request:
        logger.error("No request available, cannot toggle event handling.")
        return
    for event_key in event_keys:
        request[event_key] = False


def events_enable(request=None):
    """Re-enable event-driven preview generation for this request.
    This only makes sense if you explicitly disabled preview generation,
    since it is enabled by default.

    :param request: The request for which events were disabled
    :type request: Request
    """
    if not request:
        request = getRequest()
    if not request:
        logger.error("No request available, cannot toggle event handling.")
        return
    for event_key in event_keys:
        request[event_key] = True
