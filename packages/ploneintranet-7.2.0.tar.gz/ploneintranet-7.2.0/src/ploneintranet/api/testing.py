"""Base module for unittesting."""

from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import login
from plone.app.testing import MOCK_MAILHOST_FIXTURE
from plone.app.testing import PloneSandboxLayer
from plone.app.testing.interfaces import SITE_OWNER_NAME
from plone.testing import zope as zope_testing
from ploneintranet.microblog.testing import PLONEINTRANET_MICROBLOG_FIXTURE
from ploneintranet.userprofile.testing import PLONEINTRANET_USERPROFILE_FIXTURE

import ploneintranet.messaging
import quaive.resources.ploneintranet
import unittest


class PloneintranetApiLayer(PloneSandboxLayer):
    # includes p.a.contenttypes and ploneintranet fixtures
    defaultBases = (
        PLONEINTRANET_MICROBLOG_FIXTURE,
        PLONEINTRANET_USERPROFILE_FIXTURE,
    )

    def setUpZope(self, app, configurationContext):
        self.loadZCML(package=ploneintranet.messaging)
        self.loadZCML(package=quaive.resources.ploneintranet)

    def setUpPloneSite(self, portal):
        applyProfile(portal, "ploneintranet.messaging:default")
        applyProfile(portal, "quaive.resources.ploneintranet:default")


FIXTURE = PloneintranetApiLayer()
INTEGRATION_TESTING = IntegrationTesting(
    bases=(FIXTURE, MOCK_MAILHOST_FIXTURE), name="PloneintranetApiLayer:Integration"
)
FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(FIXTURE,), name="PloneintranetApiLayer:Functional"
)


class IntegrationTestCase(unittest.TestCase):
    """Base class for integration tests."""

    layer = INTEGRATION_TESTING

    def setUp(self):
        self.app = self.layer["app"]
        self.portal = self.layer["portal"]
        self.request = self.portal.REQUEST

    def login(self, username):
        login(self.portal, username)

    def login_as_portal_owner(self):
        """
        helper method to login as site admin
        """
        zope_testing.login(self.app["acl_users"], SITE_OWNER_NAME)


class FunctionalTestCase(IntegrationTestCase):
    """Base class for functional tests."""

    layer = FUNCTIONAL_TESTING
