# flake8: noqa
from ploneintranet.api.env import disabled
from ploneintranet.api.microblog import events_disable as disable_microblog
from ploneintranet.api.microblog import events_enable as enable_microblog
from ploneintranet.api.previews import events_disable as disable_previews
from ploneintranet.api.previews import events_enable as enable_previews
from ploneintranet.search.solr.indexers import solr_indexing_disable
from ploneintranet.search.solr.indexers import solr_indexing_enable

notifications_disabled = disabled("ploneintranet.notifications")

# not really event handlers themselves but provide a consistent API


def disable_solr_indexing(request=None):
    """XXX: This should go away because are just alias"""
    solr_indexing_disable(request)


def enable_solr_indexing(request=None):
    """XXX: This should go away because are just alias"""
    solr_indexing_enable(request)
