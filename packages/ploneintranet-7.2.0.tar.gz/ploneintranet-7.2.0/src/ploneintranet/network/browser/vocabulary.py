from AccessControl import getSecurityManager
from logging import getLogger
from plone.app.content.browser.vocabulary import _parseJSON
from plone.app.content.browser.vocabulary import DEFAULT_PERMISSION
from plone.app.content.browser.vocabulary import PERMISSIONS as base_perms
from plone.app.content.browser.vocabulary import VocabLookupException
from plone.app.content.browser.vocabulary import VocabularyView
from plone.app.content.utils import json_dumps
from plone.app.content.utils import json_loads
from plone.app.layout.navigation.interfaces import INavigationRoot
from plone.app.z3cform.interfaces import IFieldPermissionChecker
from ploneintranet.network.vocabularies import IPersonalizedVocabularyFactory
from ploneintranet.workspace.interfaces import IWorkspaceFolder
from types import FunctionType
from zope.component import queryAdapter
from zope.component import queryUtility
from zope.schema.interfaces import IVocabularyFactory

import inspect

logger = getLogger(__name__)

# workspaces are checked for 'View' rather than 'Modify portal content'
_permissions = {"ploneintranet.network.vocabularies.Keywords": "Modify portal content"}


class PersonalizedVocabularyView(VocabularyView):
    """
    Queries a named personalized vocabulary and returns
    JSON-formatted results.

    Replaces plone.app.content.browser.vocabulary.VocabularyView
    """

    def get_vocabulary(self, factory_name=None, field_name=None):
        """
        Look up named vocabulary and check permissions.
        Unline p.a.content.browser.vocabulary.VocabularyView
        this resolves a IPersonalizedVocabularyFactory
        and calls it with both context and request to
        enable personalization.
        """
        # --- only slightly changed from upstream ---

        # Look up named vocabulary and check permission.
        context = self.context
        # In proto.py we call getVocabulary with a factory_name and field_name,
        # but in normal usage this comes from the request.
        if factory_name is None:
            factory_name = self.request.get("name", None)
        if field_name is None:
            field_name = self.request.get("field", None)
        if not factory_name:
            raise VocabLookupException("No factory provided.")

        if factory_name in base_perms:
            # don't mess with upstream vocabulary handling
            return super().get_vocabulary()

        sm = getSecurityManager()

        # Special hardcoded 'View' check to enable Workspace batch tagging:
        # user has 'Modify' on content items but not on the workspace itself.
        # This at least limits tag space disclosure to workspace members.
        # See vocabularies.py comment for infosec considerations.
        if IWorkspaceFolder.providedBy(context):
            if not sm.checkPermission("View", context):
                raise VocabLookupException("Vocabulary lookup not allowed")

        # default handler for anything except the siteroot
        elif factory_name not in _permissions or not INavigationRoot.providedBy(
            context
        ):
            authorized = None
            # Check field specific permission
            if field_name:
                permission_checker = queryAdapter(context, IFieldPermissionChecker)
                if permission_checker is not None:
                    try:
                        authorized = permission_checker.validate(
                            field_name, factory_name
                        )
                    except AttributeError:
                        # The field may not exist.  For example:
                        # auto_suggest_with_adding in the component library.
                        # But if there is no field, then this may not be an add
                        # or edit form.  So View permission should suffice.
                        # You get this as anonymous when visiting the component
                        # library.  Do check if we have defined an explicit
                        # permission for this vocabulary/factory.
                        authorized = sm.checkPermission(
                            _permissions.get(factory_name, DEFAULT_PERMISSION), context
                        )

            if not authorized:
                # zope admin misses workspace access, go figure
                logger.error(
                    "Vocabulary %s lookup (%s) not allowed", factory_name, field_name
                )
                raise VocabLookupException("Vocabulary lookup not allowed")

        # Short circuit if we are on the site root and permission is
        # in global registry
        elif not sm.checkPermission(_permissions[factory_name], context):
            raise VocabLookupException("Vocabulary lookup not allowed")

        factory = queryUtility(IVocabularyFactory, factory_name)
        if not factory:
            raise VocabLookupException(
                'No factory with name "%s" exists.' % factory_name
            )

        # This part is for backwards-compatibility with the first
        # generation of vocabularies created for plone.app.widgets,
        # which take the (unparsed) query as a parameter of the vocab
        # factory rather than as a separate search method.
        if type(factory) is FunctionType:
            factory_spec = inspect.getfullargspec(factory)
        else:
            factory_spec = inspect.getfullargspec(factory.__call__)
        query = _parseJSON(self.request.get("query", ""))
        if query and "query" in factory_spec.args:
            vocabulary = factory(context, query=query)

        # This is what is reached for non-legacy vocabularies.

        elif IPersonalizedVocabularyFactory.providedBy(factory):
            # patternslib select2 queries for "q" instead of "query"
            if not query and self.request.get("q", False):
                query = _parseJSON(self.request.get("q"))
            # this is the key customization: feed in the request
            vocabulary = factory(context, self.request, query=query)
        else:
            # default fallback
            vocabulary = factory(context)

        return vocabulary

    def __call__(self):
        """If the 'resultsonly' parameter is in the request then extract the
        value for "results" from the JSON string returned from the default
        @@getVocabulary view, so that it can be used by pat-autosuggest.

        @@getVocabulary also uses the vocabulary item 'token' value for the
        'id', which escapes unicode strings. For pat-autosuggest we need to use
        unicode for both the 'text' and the 'id'.
        """
        vocab_json = super().__call__()
        if vocab_json and self.request.get("resultsonly", False):
            vocab_obj = json_loads(vocab_json)
            results = vocab_obj.get("results", [])
            text_values = [i["text"] for i in results]
            vocab_list = [{"text": val, "id": val} for val in text_values]
            return json_dumps(vocab_list)

        return vocab_json
