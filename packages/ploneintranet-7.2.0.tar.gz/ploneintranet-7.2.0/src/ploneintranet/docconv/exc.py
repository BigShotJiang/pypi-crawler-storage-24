class SubProcessException(Exception):
    """A subprocess command returned an error"""
