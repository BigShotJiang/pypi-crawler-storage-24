from importlib.resources import files
from plone import api
from plone.app.testing import login
from plone.app.testing.interfaces import SITE_OWNER_NAME
from ploneintranet.docconv.client.aspectratios import AspectRatios
from ploneintranet.docconv.client.aspectratios import extract_aspect_ratio
from ploneintranet.docconv.client.aspectratios import ExtractAspectRatioSubProcess
from ploneintranet.docconv.client.interfaces import IPreviewSettings
from ploneintranet.docconv.client.testing import IntegrationTestCase
from ploneintranet.testing import dummy_file

import unittest


class TestExtractAspectRatioSubprocess(unittest.TestCase):
    def test_default_aspect_ratio(self):
        aspect_ratio = ExtractAspectRatioSubProcess().aspect_ratio
        self.assertEqual(aspect_ratio(b"foo bar"), "auto")

    def test_aspect_ratio_from_pdfinfo(self):
        aspect_ratio = ExtractAspectRatioSubProcess().aspect_ratio
        self.assertAlmostEqual(aspect_ratio(PDFINFO_1), float(595.32 / 841.92))
        self.assertAlmostEqual(aspect_ratio(PDFINFO_2), float(596 / 842))

    def test_aspect_ratio_from_pdfinfo_bogus_size_0(self):
        aspect_ratio = ExtractAspectRatioSubProcess().aspect_ratio
        PDFINFO_1_BOGUS = PDFINFO_1.replace(b"841.92", b"0")
        PDFINFO_2_BOGUS = PDFINFO_2.replace(b"842", b"0")
        self.assertEqual(aspect_ratio(PDFINFO_1_BOGUS), "auto")
        self.assertEqual(aspect_ratio(PDFINFO_2_BOGUS), "auto")

    def test_aspect_ratio_from_latin1_pdfinfo(self):
        import os
        import pathlib

        fixture = pathlib.Path(os.path.dirname(__file__)) / "testdata" / "pdfinfo"
        with open(fixture, "br") as fh:
            pdfinfo = fh.read()
        aspect_ratio = ExtractAspectRatioSubProcess().aspect_ratio
        self.assertAlmostEqual(aspect_ratio(pdfinfo), float(595 / 842))

    def test_extract_aspect_ratio(self):
        file_path = files("ploneintranet.tests") / "test.pdf"
        # test.pdf is 256x256
        self.assertAlmostEqual(extract_aspect_ratio(file_path, 1), 1.0)


class TestAspectRatios(IntegrationTestCase):
    def setUp(self):
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]
        login(self.portal.aq_parent, SITE_OWNER_NAME)

    def test_aspect_ratios(self):
        pdf_blob = dummy_file(filename="test.pdf")
        pdf_file = api.content.create(
            self.portal, id="mypdf", type="File", file=pdf_blob
        )
        converter = AspectRatios(pdf_file)
        aspect_ratios = converter()
        self.assertEqual(len(aspect_ratios), 1)
        self.assertAlmostEqual(aspect_ratios[0], 1.0)
        settings = IPreviewSettings(pdf_file)
        self.assertEqual(len(settings.aspect_ratios), 1)
        self.assertAlmostEqual(settings.aspect_ratios[0], 1.0)


PDFINFO_1 = """
Title:          Getting Started with Mendeley
Author:         Mendeley Support Team
Creator:        Microsoft® Office Word 2007
Producer:       Microsoft® Office Word 2007
CreationDate:   Wed Jan 12 10:59:48 2011 CET
ModDate:        Wed Jan 12 10:59:48 2011 CET
Tagged:         yes
UserProperties: no
Suspects:       no
Form:           none
JavaScript:     no
Pages:          16
Encrypted:      no
Page    1 size: 595.32 x 841.92 pts (A4)
Page    1 rot:  0
Page    1 MediaBox:     0.00     0.00   595.32   841.92
Page    1 CropBox:      0.00     0.00   595.32   841.92
Page    1 BleedBox:     0.00     0.00   595.32   841.92
Page    1 TrimBox:      0.00     0.00   595.32   841.92
Page    1 ArtBox:       0.00     0.00   595.32   841.92
File size:      1537973 bytes
Optimized:      no
PDF version:    1.5
""".encode()

PDFINFO_2 = b"""
Creator:         Xerox WorkCentre 7855
Producer:        Xerox WorkCentre 7855
CreationDate:    xxx
ModDate:         xxx
Custom Metadata: no
Metadata Stream: yes
Tagged:          no
UserProperties:  no
Suspects:        no
Form:            none
JavaScript:      no
Pages:           1
Encrypted:       no
Page size:       842 x 596 pts (A4)
Page rot:        270
File size:       56136 bytes
Optimized:       yes
PDF version:     1.4
"""
