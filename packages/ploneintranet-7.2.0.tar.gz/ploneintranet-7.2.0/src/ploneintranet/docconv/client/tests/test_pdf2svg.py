from ploneintranet.docconv.client.browser.svg import pdf2svg
from ploneintranet.docconv.client.testing import IntegrationTestCase
from ploneintranet.testing import temporary_registry_record

import unittest


class TestPDF2SVG(IntegrationTestCase):
    """Test pdf2svg for ploneintranet.docconv.client"""

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]

    def test_is_bad_pdf(self):
        # Mock pdfinfo to return specific metadata for testing
        with unittest.mock.patch(
            "ploneintranet.docconv.client.browser.svg.pdf2svg.pdfinfo",
            return_value={"Creator": "Foo 123", "Producer": "bar 456"},
        ):
            # Test with no bad creators configured
            self.assertFalse(pdf2svg.is_bad_pdf("foo.pdf"))

            # Test with a single exact match bad creator
            with temporary_registry_record(
                "ploneintranet.docconv.bad_pdf_creators",
                ("Foo",),
            ):
                self.assertFalse(pdf2svg.is_bad_pdf("foo.pdf"))

            # Test with a wildcard match bad creator
            with temporary_registry_record(
                "ploneintranet.docconv.bad_pdf_creators",
                ("Foo *",),
            ):
                self.assertTrue(pdf2svg.is_bad_pdf("foo.pdf"))

            # Test with multiple bad creators (one matches Creator)
            with temporary_registry_record(
                "ploneintranet.docconv.bad_pdf_creators",
                ("Foo*", "Baz"),
            ):
                self.assertTrue(pdf2svg.is_bad_pdf("foo.pdf"))

            # Test with multiple bad creators (none match Creator or Producer)
            with temporary_registry_record(
                "ploneintranet.docconv.bad_pdf_creators",
                ("Baz", "Qux"),
            ):
                self.assertFalse(pdf2svg.is_bad_pdf("foo.pdf"))

            # Test matching against Producer key
            with temporary_registry_record(
                "ploneintranet.docconv.bad_pdf_creators",
                ("bar*",),
            ):
                self.assertTrue(pdf2svg.is_bad_pdf("foo.pdf"))

            # Test case-insensitivity
            with temporary_registry_record(
                "ploneintranet.docconv.bad_pdf_creators",
                ("foo*",),
            ):
                self.assertTrue(pdf2svg.is_bad_pdf("foo.pdf"))

            with temporary_registry_record(
                "ploneintranet.docconv.bad_pdf_creators",
                ("BAR*",),
            ):
                self.assertTrue(pdf2svg.is_bad_pdf("foo.pdf"))

            # Test when metadata keys are missing
            with unittest.mock.patch(
                "ploneintranet.docconv.client.browser.svg.pdf2svg.pdfinfo",
                return_value={},
            ):
                self.assertFalse(pdf2svg.is_bad_pdf("foo.pdf"))

            # Test when metadata keys are None
            with unittest.mock.patch(
                "ploneintranet.docconv.client.browser.svg.pdf2svg.pdfinfo",
                return_value={"Creator": None, "Producer": None},
            ):
                self.assertFalse(pdf2svg.is_bad_pdf("foo.pdf"))
