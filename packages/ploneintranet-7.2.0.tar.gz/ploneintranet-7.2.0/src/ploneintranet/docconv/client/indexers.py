from plone.indexer import indexer
from ploneintranet.api.previews import has_thumbnails
from Products.CMFCore.interfaces import IContentish


@indexer(IContentish)
def has_thumbs(obj):
    """
    Provides a catalog-indexable boolean value
    to mark items that have thumbnail previews
    """
    return has_thumbnails(obj)
