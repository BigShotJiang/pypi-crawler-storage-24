"""Module where all interfaces, events and exceptions live."""

from OFS.interfaces import IItem
from plone.theme.interfaces import IDefaultPloneLayer
from zope.interface import Attribute
from zope.interface import Interface


class IPloneintranetDocconvClientLayer(IDefaultPloneLayer):
    """Marker interface that defines a Zope 3 browser layer."""


class IFileWrapper(Interface):
    has_enclosure = Attribute("If object has enclosure")
    file = Attribute("BlobWrapper or NamedFile")
    file_length = Attribute("File size")
    file_type = Attribute("File mime type")
    blob = Attribute("ZODB blob")
    filename = Attribute("Filename")


class IPreviewSettings(Interface):
    """Annotated Settings to store preview generation config"""

    last_modified = Attribute("Last modified")
    num_pages = Attribute("Num pages")
    successfully_converted = Attribute("Successfully converted")
    filehash = Attribute("File hash")
    blob_files = Attribute("Dict of filename:path for each preview or gallery image")
    aspect_ratios = Attribute("Sequence of float aspect-ratio for each page")


class IBlobFileWrapper(IItem):
    pass
