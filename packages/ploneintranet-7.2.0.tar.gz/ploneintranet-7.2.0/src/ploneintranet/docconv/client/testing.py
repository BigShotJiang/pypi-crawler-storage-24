"""Base module for unittesting."""

from plone.app.contenttypes.testing import PLONE_APP_CONTENTTYPES_FIXTURE
from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import PloneSandboxLayer

import unittest


class PloneintranetDocconvClientLayer(PloneSandboxLayer):

    defaultBases = (PLONE_APP_CONTENTTYPES_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        """Set up Zope."""
        # Load ZCML
        import ploneintranet.microblog

        self.loadZCML(package=ploneintranet.microblog)
        import ploneintranet.attachments

        self.loadZCML(package=ploneintranet.attachments)
        import plone.app.contenttypes

        self.loadZCML(package=plone.app.contenttypes)
        import ploneintranet.docconv.client

        self.loadZCML(package=ploneintranet.docconv.client)
        import ploneintranet.layout

        self.loadZCML(package=ploneintranet.layout)
        import ploneintranet.search

        self.loadZCML(package=ploneintranet.search)

    def setUpPloneSite(self, portal):
        """Set up Plone."""
        # Install into Plone site using portal_setup
        applyProfile(portal, "plone.app.contenttypes:default")
        applyProfile(portal, "ploneintranet.docconv.client:default")
        applyProfile(portal, "ploneintranet.search:default")


FIXTURE = PloneintranetDocconvClientLayer()
INTEGRATION_TESTING = IntegrationTesting(
    bases=(FIXTURE,), name="PloneintranetDocconvClientLayer:Integration"
)
FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(FIXTURE,), name="PloneintranetDocconvClientLayer:Functional"
)


class IntegrationTestCase(unittest.TestCase):
    """Base class for integration tests."""

    layer = INTEGRATION_TESTING


class FunctionalTestCase(unittest.TestCase):
    """Base class for functional tests."""

    layer = FUNCTIONAL_TESTING
