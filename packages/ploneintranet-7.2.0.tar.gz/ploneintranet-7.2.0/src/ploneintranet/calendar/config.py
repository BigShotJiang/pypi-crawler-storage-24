TZ_COOKIE_NAME = "ploneintranet.calendar.timezone"

DEFAULT_TZ_ID = 30
