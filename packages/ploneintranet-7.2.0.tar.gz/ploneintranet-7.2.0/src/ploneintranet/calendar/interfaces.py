from zope.interface import Interface


class IMaintainerGroup(Interface):
    """Marker interface that can be applied to workgroups to make them
    maintainers of a central calendar
    """


class IReaderGroup(Interface):
    """Marker interface that can be applied to workgroups to grant them
    read-only access to a central calendar
    """
