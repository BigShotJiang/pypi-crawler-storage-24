"""Setup/installation tests for this package."""

from plone.browserlayer import utils
from ploneintranet.calendar.browser.interfaces import IPloneintranetCalendarLayer
from ploneintranet.calendar.testing import IntegrationTestCase
from Products.CMFPlone.utils import get_installer

PROJECTNAME = "ploneintranet.calendar"


class TestInstall(IntegrationTestCase):
    """Test installation of this  product into Plone."""

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])

    def test_product_installed(self):
        self.assertTrue(self.installer.is_product_installed(PROJECTNAME))

    def test_browserlayer(self):
        """Test that IPloneintranetCalendarLayer is registered."""
        self.assertIn(IPloneintranetCalendarLayer, utils.registered_layers())


class TestUninstall(IntegrationTestCase):
    """Test this product is properly uninstalled."""

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])
        self.installer.uninstall_product(PROJECTNAME)

    def test_uninstall(self):
        self.assertFalse(self.installer.is_product_installed(PROJECTNAME))

    def test_browserlayer(self):
        """Test that IPloneintranetCalendarLayer is unregistered."""
        self.assertNotIn(IPloneintranetCalendarLayer, utils.registered_layers())
