from logging import getLogger
from plone import api

logger = getLogger()


def create_calendar_app():
    """Create the calendar application"""
    portal = api.portal.get()
    apps = portal.apps
    if "calendar" in apps and not apps.calendar.app:
        api.content.delete(obj=apps.calendar)
    if "calendar" not in apps:
        api.content.create(
            container=apps,
            type="ploneintranet.layout.app",
            title="Calendar",
            id="calendar",
            safe_id=False,
            app="@@app-calendar",
            devices="desktop tablet",
        )

    app = apps.calendar
    if api.content.get_state(app) == "published":
        return
    try:
        api.content.transition(app, to_state="published")
    except BaseException:
        logger.exception("Cannot publish the app: %r", app)


def create_calendar_folder():
    portal = api.portal.get()
    if "calendars" not in portal:
        api.content.create(
            container=portal, title="Calendars", id="calendars", type="Folder"
        )
    calendar_folder = portal["calendars"]
    calendar_folder.setLayout("redirect-to-app-calendar")


def post_default(context):
    """Actions needed after importing
    the ploneintranet.calendar:default profile
    """
    create_calendar_app()
    create_calendar_folder()
