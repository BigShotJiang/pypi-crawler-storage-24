from zope.interface import Interface


class IPloneintranetCalendarLayer(Interface):
    """Marker interface to define ZTK browser layer"""
