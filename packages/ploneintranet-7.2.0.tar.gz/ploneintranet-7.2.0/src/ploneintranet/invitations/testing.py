from plone.app.testing import FunctionalTesting
from plone.app.testing import helpers
from plone.app.testing import IntegrationTesting
from plone.app.testing import MOCK_MAILHOST_FIXTURE
from plone.app.testing import PLONE_FIXTURE
from plone.app.testing import PloneSandboxLayer
from plone.testing.zope import WSGI_SERVER_FIXTURE
from zope.configuration import xmlconfig

import unittest


class PloneintranetinvitationsLayer(PloneSandboxLayer):

    defaultBases = (PLONE_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        # Load ZCML
        import ploneintranet.invitations

        xmlconfig.file(
            "configure.zcml", ploneintranet.invitations, context=configurationContext
        )

    def tearDownZope(self, app):
        pass

    def setUpPloneSite(self, portal):
        helpers.applyProfile(portal, "ploneintranet.invitations:default")


PLONEINTRANET_INVITATIONS_FIXTURE = PloneintranetinvitationsLayer()
bases = (PLONEINTRANET_INVITATIONS_FIXTURE, MOCK_MAILHOST_FIXTURE)
INTEGRATION_TESTING = IntegrationTesting(
    bases=bases, name="PloneintranetinvitationsLayer:Integration"
)

bases += (WSGI_SERVER_FIXTURE,)
FUNCTIONAL_TESTING = FunctionalTesting(
    bases=bases, name="PloneintranetinvitationsLayer:Functional"
)


class IntegrationTestCase(unittest.TestCase):
    """Base class for integration tests."""

    layer = INTEGRATION_TESTING


class FunctionalTestCase(unittest.TestCase):
    """Base class for functional tests."""

    layer = FUNCTIONAL_TESTING
