from plone import api
from ploneintranet.invitations.testing import IntegrationTestCase
from Products.CMFPlone.utils import get_installer


class TestInstall(IntegrationTestCase):
    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])

    def test_product_installed(self):
        """Test if ploneintranet.invitations is installed."""
        self.assertTrue(
            self.installer.is_product_installed("ploneintranet.invitations")
        )

    def test_browserlayer(self):
        """Test that IKboWebappLayer is registered."""
        from plone.browserlayer import utils
        from ploneintranet.invitations.interfaces import IPloneintranetInvitationsLayer

        self.assertIn(IPloneintranetInvitationsLayer, utils.registered_layers())

    def test_controlpanel(self):
        portal_controlpanel = api.portal.get_tool("portal_controlpanel")
        self.assertIn(
            "ploneintranet.invitations",
            [i.id for i in portal_controlpanel.listActions()],
        )


class TestUninstall(IntegrationTestCase):
    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])
        self.installer.uninstall_product("ploneintranet.invitations")

    def test_is_uninstalled(self):
        """Test if ploneintranet.invitations is cleanly uninstalled."""
        self.assertFalse(
            self.installer.is_product_installed("ploneintranet.invitations")
        )

    def test_browserlayer(self):
        """Test that the layer is removed."""
        from plone.browserlayer import utils
        from ploneintranet.invitations.interfaces import IPloneintranetInvitationsLayer

        self.assertNotIn(IPloneintranetInvitationsLayer, utils.registered_layers())

    def test_controlpanel_is_removed(self):
        portal_controlpanel = api.portal.get_tool("portal_controlpanel")
        self.assertNotIn(
            "ploneintranet.invitations",
            [i.id for i in portal_controlpanel.listActions()],
        )
