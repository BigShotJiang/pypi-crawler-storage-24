from datetime import datetime
from datetime import timedelta
from ploneintranet.invitations.testing import IntegrationTestCase
from ploneintranet.invitations.token import Token


class TestToken(IntegrationTestCase):
    def setUp(self):
        self.portal = self.layer["portal"]

    def test_create_token(self):
        expiry = datetime.now() + timedelta(seconds=300)
        token = Token(1, expiry, "a/b/c")
        self.assertEqual(token.uses_remaining, 1)
        self.assertEqual(token.expiry, expiry)
        self.assertIsInstance(token.id, (str,))
        url = f"{self.portal.absolute_url()}/@@accept-token/{token.id}"
        self.assertEqual(token.invite_url, url)
        self.assertEqual(token.redirect_path, "a/b/c")
