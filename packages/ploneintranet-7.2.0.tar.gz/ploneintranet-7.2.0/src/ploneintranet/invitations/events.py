from ploneintranet.core import _
from zope.interface import Attribute
from zope.interface import implementer
from zope.interface import Interface


class ITokenAccepted(Interface):

    token_id = Attribute(_("The id of the Token that was consumed"))


@implementer(ITokenAccepted)
class TokenAccepted:
    """
    Event to be fired whenever a token is consumed
    """

    def __init__(self, token_id):
        self.token_id = token_id
