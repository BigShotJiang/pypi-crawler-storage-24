from plone.app.redirector.browser import FourOhFourView


class PIFourOhFourView(FourOhFourView):
    def search_for_similar(self):
        """Disable search_for_similar, it is too expensive"""
        return []
