from Products.Five import BrowserView
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile


class BarcelonetaWarning(BrowserView):
    """PMI warning, with template bound in python
    so the view can be easily re-used.
    """

    template = ViewPageTemplateFile("templates/barceloneta-warning.pt")

    def __call__(self):
        return self.template()
