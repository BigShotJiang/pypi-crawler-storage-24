from plone import api
from Products.Five import BrowserView
from zExceptions import NotFound


class Deny(BrowserView):
    def __call__(self):
        raise NotFound()


class RedirectToDashboard(BrowserView):
    def __call__(self):
        """User might want to use in barceloneta another view for the website
        but the Quaive homepage must be always the dashboard.
        """
        self.request.response.redirect(
            f"{api.portal.get().absolute_url()}/@@dashboard.html"
        )
