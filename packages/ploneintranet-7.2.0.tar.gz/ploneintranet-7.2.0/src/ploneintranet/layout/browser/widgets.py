from zope.deferredimport import deprecated

deprecated(
    "PloneIntranetSelectWidget is now in ploneintranet.layout.widgets.select",
    PloneIntranetSelectWidget="ploneintranet.layout.widgets.select:PISelectWidget",
)

deprecated(
    "PloneIntranetSelectFieldWidget is now in ploneintranet.layout.widgets.select",
    PloneIntranetSelectFieldWidget="ploneintranet.layout.widgets.select:PISelectFieldWidget",  # noqa: E501
)
