from ploneintranet.layout.interfaces import IDiazoAppTemplate
from Products.CMFEditions.browser.views import VersionsHistoryForm
from zope.interface import implementer


@implementer(IDiazoAppTemplate)
class VersionsHistoryView(VersionsHistoryForm):
    """Overriding this as a browser view so we can implement the right interface."""
