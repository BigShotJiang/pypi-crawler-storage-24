from Products.Five.browser import BrowserView
from urllib.parse import urlencode


class InsufficientPrivilegesView(BrowserView):
    def __call__(self):
        self.request.response.setStatus(403)
        return super().__call__()


class UnauthorizedView(BrowserView):
    @property
    def login_url(self):
        qs = urlencode(self.request.form)
        qs = f"?{qs}" if qs else ""
        login_url = f"{self.context.portal_url()}/login{qs}"
        return login_url

    def __call__(self):
        self.request.response.setStatus(401)
        return super().__call__()
