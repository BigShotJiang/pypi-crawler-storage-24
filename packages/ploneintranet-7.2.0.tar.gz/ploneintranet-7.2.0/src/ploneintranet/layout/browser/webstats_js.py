from plone.app.layout.analytics.view import AnalyticsViewlet
from plone.memoize.view import memoize_contextless


class View(AnalyticsViewlet):
    def __init__(self, context, request):
        """This init makes the viewlet a view"""
        super(AnalyticsViewlet, self).__init__(context, request)

    @memoize_contextless
    def __call__(self):
        """This adds a cache to the view call"""
        self.update()
        if not hasattr(self, "webstats_js"):
            # This can go away if https://github.com/plone/plone.app.layout/pull/228
            # is merged
            self.webstats_js = ""
        return super().render()
