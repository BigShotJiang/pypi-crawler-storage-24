from importlib.resources import files
from ploneintranet.layout.interfaces import IPloneintranetFormLayer

import plone.z3cform

layout_factory = plone.z3cform.templates.ZopeTwoFormTemplateFactory(
    str(files("ploneintranet.layout") / "browser" / "templates" / "formwrapper.pt"),
    form=plone.z3cform.interfaces.IFormWrapper,
    request=IPloneintranetFormLayer,
)
