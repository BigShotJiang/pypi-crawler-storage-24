from plone import api
from ploneintranet.layout.interfaces import IApplicationLabel
from ploneintranet.layout.interfaces import INoBarcelonetaLayer
from ploneintranet.layout.testing import IntegrationTestCase
from unittest.mock import patch
from zope.component import getMultiAdapter
from zope.interface import alsoProvides
from zope.interface import noLongerProvides


class FakeAppView:
    title = "Fake App"


class TestBreadcrumbs(IntegrationTestCase):
    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]
        self.folder = api.content.create(
            container=self.portal, type="Folder", title="Main folder"
        )
        alsoProvides(self.folder, IApplicationLabel)
        api.content.transition(self.folder, "publish")
        self.subfolder = api.content.create(
            container=self.folder, type="Folder", title="Sub folder"
        )
        api.content.transition(self.subfolder, "publish")

        self.appscontainer = api.content.create(
            container=self.portal,
            type="ploneintranet.layout.appscontainer",
            title="Apps",
        )
        api.content.transition(self.appscontainer, "publish")
        self.app = api.content.create(
            container=self.appscontainer,
            type="ploneintranet.layout.app",
            title="Test App",
        )
        api.content.transition(self.app, "publish")

    def _add_browser_layer(self, layer):
        alsoProvides(self.request, layer)

    def _remove_browser_layer(self, layer):
        noLongerProvides(self.request, layer)

    def _get_breadcrumbs(self, context):
        view = getMultiAdapter((context, self.request), name="breadcrumbs_view")
        return view.breadcrumbs()

    def test_breadcrumbs_cms(self):
        self._remove_browser_layer(INoBarcelonetaLayer)
        self.assertEqual(self._get_breadcrumbs(self.portal), ())
        self.assertEqual(
            self._get_breadcrumbs(self.folder),
            ({"absolute_url": self.folder.absolute_url(), "Title": "Main folder"},),
        )
        self.assertEqual(
            self._get_breadcrumbs(self.subfolder),
            (
                {"absolute_url": self.folder.absolute_url(), "Title": "Main folder"},
                {"absolute_url": self.subfolder.absolute_url(), "Title": "Sub folder"},
            ),
        )

    def test_breadcrumbs_theme(self):
        self._add_browser_layer(INoBarcelonetaLayer)
        self.assertEqual(
            self._get_breadcrumbs(self.portal),
            ({"absolute_url": self.portal.absolute_url(), "Title": "Plone site"},),
        )
        self.assertEqual(
            self._get_breadcrumbs(self.folder),
            ({"absolute_url": self.folder.absolute_url(), "Title": "Main folder"},),
        )
        self.assertEqual(
            self._get_breadcrumbs(self.subfolder),
            ({"absolute_url": self.folder.absolute_url(), "Title": "Main folder"},),
        )
        with patch.object(self.app, "app_view", return_value=FakeAppView()):
            self.assertEqual(
                self._get_breadcrumbs(self.app),
                ({"absolute_url": self.app.absolute_url(), "Title": "Fake App"},),
            )
