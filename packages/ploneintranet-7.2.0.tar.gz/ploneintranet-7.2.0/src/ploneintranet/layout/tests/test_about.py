from plone import api
from ploneintranet import api as pi_api
from ploneintranet.layout.testing import IntegrationTestCase
from ploneintranet.userprofile.testing import (
    PLONEINTRANET_USERPROFILE_FUNCTIONAL_TESTING,
)
from Products.CMFCore.indexing import processQueue


class TestAboutUserStatistics(IntegrationTestCase):

    layer = PLONEINTRANET_USERPROFILE_FUNCTIONAL_TESTING

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]
        self.about_view = api.content.get_view(
            name="about.html", context=self.portal, request=self.request
        )

    def test_total_users(self):
        pi_api.userprofile.create(username="user1")
        pi_api.userprofile.create(username="user2")
        pi_api.userprofile.create(username="user3")
        processQueue()  # To ensure that the number of results is accurate
        self.assertEqual(self.about_view.total_users, 3)

    def test_total_creators(self):
        self.assertEqual(self.about_view.total_creators, 1)
        api.content.create(container=self.portal, type="Folder", title="ok")
        self.assertEqual(self.about_view.total_creators, 2)

    def test_total_pending_users(self):
        self.assertEqual(self.about_view.total_pending_users, 0)
        pi_api.userprofile.create(username="user1")
        self.assertEqual(self.about_view.total_pending_users, 1)

    def test_total_enabled_users(self):
        pi_api.userprofile.create(username="user1")
        api.content.transition(self.portal.profiles.user1, to_state="enabled")
        self.assertEqual(self.about_view.total_enabled_users, 1)

    def test_total_disabled_users(self):
        pi_api.userprofile.create(username="user1")
        api.content.transition(self.portal.profiles.user1, to_state="disabled")
        self.assertEqual(self.about_view.total_disabled_users, 1)
