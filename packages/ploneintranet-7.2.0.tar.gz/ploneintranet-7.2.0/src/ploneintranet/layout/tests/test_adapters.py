from plone import api
from plone.transformchain.interfaces import ITransform
from ploneintranet.layout.browser.dashboard import NewsTile
from ploneintranet.layout.interfaces import IAppContainer
from ploneintranet.layout.interfaces import IAppContent
from ploneintranet.layout.testing import IntegrationTestCase
from unittest import mock
from zope.component import getMultiAdapter
from zope.interface import alsoProvides
from zope.interface.verify import verifyObject


def _video_request_head(url, timeout=None):
    """Return a fake response that has the content type header for videos"""

    class FakeResponse:
        """This is a fake response"""

        def __init__(self, url):
            self.url = url

        @property
        def headers(self):
            if self.url.endswith(".mp4"):
                return {"Content-Type": "video/foo"}
            return {}

    return FakeResponse(url)


class TestAppContent(IntegrationTestCase):
    def setUp(self):
        self.app = self.layer["app"]
        self.portal = self.layer["portal"]
        self.f1 = api.content.create(
            container=self.portal, type="Folder", title="testfolder 1"
        )
        self.f1.app_name = "app-foo"
        self.f1.app_layers = ()
        alsoProvides(self.f1, IAppContainer)
        self.d1 = api.content.create(
            container=self.f1, type="Document", title="testdocument 1"
        )
        self.f2 = api.content.create(
            container=self.portal, type="Folder", title="testfolder 2"
        )

    def test_lookup(self):
        adapted = IAppContent(self.d1)
        self.assertTrue(IAppContent.providedBy(adapted))

    def test_verify(self):
        adapted = IAppContent(self.d1)
        self.assertTrue(verifyObject(IAppContent, adapted))

    def test_app_name_noapp(self):
        self.assertEqual("", IAppContent(self.f2).app_name)

    def test_app_name_app(self):
        self.assertEqual(self.f1.app_name, IAppContent(self.f1).app_name)

    def test_app_name_doc(self):
        self.assertEqual(self.d1.app_name, IAppContent(self.f1).app_name)

    def test_in_app_noapp(self):
        self.assertFalse(IAppContent(self.f2).in_app)

    def test_in_app_app(self):
        self.assertTrue(IAppContent(self.f1).in_app)

    def test_in_app_doc(self):
        self.assertTrue(IAppContent(self.d1).in_app)

    def test_get_app_noapp(self):
        self.assertEqual(None, IAppContent(self.f2).get_app())

    def test_get_app_app(self):
        self.assertEqual(self.f1, IAppContent(self.f1).get_app())

    def test_get_app_doc(self):
        self.assertEqual(self.f1, IAppContent(self.d1).get_app())


class TestLinkContentType(IntegrationTestCase):
    def setUp(self):
        self.portal = self.layer["portal"]

    def test_empty_link(self):
        obj = api.content.create(container=self.portal, type="Link", title="link")
        self.assertEqual(obj.content_type(), "text/x-uri")

    def test_youtube_link(self):
        obj = api.content.create(
            container=self.portal,
            type="Link",
            title="link",
            remoteUrl="https://youtu.be/foo",
        )
        self.assertEqual(obj.content_type(), "text/x-uri-youtube")

    @mock.patch("requests.head", _video_request_head)
    def test_video_link(self):
        obj = api.content.create(
            container=self.portal,
            type="Link",
            title="link",
            remoteUrl="https://nohost/foo.mp4",
        )
        self.assertEqual(obj.content_type(), "text/x-uri-video")

    def test_regular_link(self):
        obj = api.content.create(
            container=self.portal,
            type="Link",
            title="link",
            remoteUrl="https://nohost/foo",
        )
        self.assertEqual(obj.content_type(), "text/x-uri")


class TestTileThemeTransform(IntegrationTestCase):
    def test_theme_transform_normal(self):
        """Test if Diazo is disabled for in non-error cases."""
        request = self.layer["request"]
        tile = NewsTile(self.layer["portal"], request)

        request.response.status = 200
        transform = getMultiAdapter(
            (tile, request), ITransform, name="plone.tiles.tiletheming"
        )
        transform.transform(None, None)  # No parameters needed for this test.
        self.assertEqual(request.response.getHeader("X-Theme-Disabled"), "1")

    def test_theme_transform_error(self):
        """Test if Diazo is enabled for in error cases."""
        request = self.layer["request"]
        tile = NewsTile(self.layer["portal"], request)

        request.response.status = 500
        transform = getMultiAdapter(
            (tile, request), ITransform, name="plone.tiles.tiletheming"
        )
        transform.transform(None, None)  # No parameters needed for this test.
        self.assertEqual(request.response.getHeader("X-Theme-Disabled"), None)
