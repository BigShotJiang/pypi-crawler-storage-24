from plone import api
from ploneintranet.layout.testing import IntegrationTestCase
from ploneintranet.messaging.notifications.adapters import ChatMessagesCategory
from ploneintranet.microblog.notifications.adapters import (
    StatusUpdateActivityCommentsCategory,
)
from ploneintranet.microblog.notifications.adapters import (
    StatusUpdateActivityPostsCategory,
)
from ploneintranet.microblog.notifications.adapters import (
    StatusUpdateInteractionsCategory,
)
from ploneintranet.network.notifications.adapters import BaseFollowingCategory
from ploneintranet.news.notifications.adapters import NewsPublishedCategory
from ploneintranet.todo.notifications.adapters import BaseTodoUpdatedCategory
from ploneintranet.workspace.notifications.adapters import BaseWorkspaceMemberCategory
from ploneintranet.workspace.notifications.adapters import BaseWorkspaceOpenCategory
from unittest import mock


class TestApp:
    def __init__(self, app_id):
        self.app_id = app_id

    def getId(self):
        return self.app_id


apps = dict(news=TestApp("news"), messages=TestApp("messages"), todo=TestApp("todo"))


def get_app(app_id, default=None):
    return apps.get(app_id, default)


class TestPreferences(IntegrationTestCase):
    """"""

    def setUp(self):
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]

    @mock.patch("ploneintranet.api.apps.get", new_callable=lambda: get_app)
    def test_grouped_categories(self, _):
        preferences_view = api.content.get_view(
            context=self.portal.apps.preferences,
            request=self.request,
            name="app-preferences",
        )
        grouped_categories = preferences_view.grouped_categories
        self.assertDictEqual(
            grouped_categories,
            {
                None: [
                    StatusUpdateInteractionsCategory,
                    BaseFollowingCategory,
                    StatusUpdateActivityPostsCategory,
                    StatusUpdateActivityCommentsCategory,
                    BaseWorkspaceMemberCategory,
                    BaseWorkspaceOpenCategory,
                ],
                apps["news"]: [NewsPublishedCategory],
                apps["todo"]: [BaseTodoUpdatedCategory],
                apps["messages"]: [ChatMessagesCategory],
            },
        )
