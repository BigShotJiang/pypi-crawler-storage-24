from plone import api
from plone.dexterity.fti import DexterityFTI
from ploneintranet.layout.pinning import IPinned
from ploneintranet.layout.pinning import IPinningBehavior
from ploneintranet.layout.testing import IntegrationTestCase


class TestPinning(IntegrationTestCase):
    def _setupFTI(self, portal_type):
        fti = DexterityFTI(portal_type)
        self.portal.portal_types._setObject(portal_type, fti)
        fti.klass = "plone.dexterity.content.Container"
        fti.behaviors = ("quaive.pinning",)

    def setUp(self):
        self.app = self.layer["app"]
        self.portal = self.layer["portal"]

        self._setupFTI(portal_type="PinType")
        self.test1 = api.content.create(
            container=self.portal, type="PinType", title="test1"
        )

    def test_enable_disable_pinning(self):
        behavior = IPinningBehavior(self.test1)

        self.assertEqual(behavior.pinned, False)
        self.assertEqual(IPinned.providedBy(self.test1), False)

        behavior.pinned = True

        self.assertEqual(behavior.pinned, True)
        self.assertEqual(IPinned.providedBy(self.test1), True)

        behavior.pinned = False

        self.assertEqual(behavior.pinned, False)
        self.assertEqual(IPinned.providedBy(self.test1), False)
