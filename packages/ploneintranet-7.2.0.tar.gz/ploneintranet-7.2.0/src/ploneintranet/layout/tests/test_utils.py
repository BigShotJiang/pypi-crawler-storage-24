from ploneintranet.layout import utils

import unittest

string_with_unicode = "This is a ∞ string that contains non-ascii"
string_with_unicode_shortened = "This is a ∞ string …"
unicode_string = "I ♡ unicode with all my heart "
unicode_string_shortened = "I ♡ unicode with …"
string_with_dash = "A dashed-text title will be treated ok"
string_with_dash_shortened = "A dashed-text title …"
string_no_spaces = "Supercalifragilisticexpialidocious"
string_no_spaces_shortened = "Supercalifragili …"


class TestUtilityMethods(unittest.TestCase):
    """
    We define utility methods in various places in our code suite. Add tests
    for their basic functionality.

    See also activitystream/tests/test_utils
    """

    def test_text_shortener(self):
        text = utils.shorten(string_with_unicode, 20)
        self.assertEqual(text, string_with_unicode_shortened)
        text = utils.shorten(unicode_string, 20)
        self.assertEqual(text, unicode_string_shortened)
        text = utils.shorten(string_with_dash, 20)
        self.assertEqual(text, string_with_dash_shortened)
        text = utils.shorten(string_no_spaces, 20)
        self.assertEqual(text, string_no_spaces_shortened)

    def test_youtube_url(self):
        """Test conversion of different urls to our youtube url scheme."""

        self.assertEqual(
            utils.youtube_url("https://www.youtube.com/watch?v=I0I7d-63AEk"),
            "https://www.youtube-nocookie.com/embed/I0I7d-63AEk",
        )

        self.assertEqual(
            utils.youtube_url("https://www.youtube.com/I0I7d-63AEk"),
            "https://www.youtube-nocookie.com/embed/I0I7d-63AEk",
        )

        self.assertEqual(
            utils.youtube_url(
                "https://www.youtube.com/watch?v=I0I7d-63AEk", "dummy_url_template--{v}"
            ),
            "dummy_url_template--I0I7d-63AEk",
        )

        self.assertEqual(
            utils.youtube_url("https://no-valid-yt-url.com"),
            "https://www.youtube-nocookie.com/embed/",
        )
