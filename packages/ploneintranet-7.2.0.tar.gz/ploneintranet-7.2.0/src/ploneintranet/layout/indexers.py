from .pinning import IPinningBehavior
from plone.dexterity.interfaces import IDexterityContent
from plone.indexer.decorator import indexer


@indexer(IDexterityContent)
def pinned(obj, **kw):
    try:
        return IPinningBehavior(obj).pinned
    except TypeError:
        return False
