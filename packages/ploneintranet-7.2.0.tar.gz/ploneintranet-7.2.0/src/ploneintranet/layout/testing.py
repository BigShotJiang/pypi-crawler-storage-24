from plone.app.contenttypes.testing import PLONE_APP_CONTENTTYPES_FIXTURE
from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import PloneSandboxLayer
from plone.app.testing import setRoles
from plone.app.testing import TEST_USER_ID

import unittest


class PloneintranetLayoutLayer(PloneSandboxLayer):

    defaultBases = (PLONE_APP_CONTENTTYPES_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        import ploneintranet.layout

        self.loadZCML(package=ploneintranet.layout.tests)

    def setUpPloneSite(self, portal):
        applyProfile(portal, "ploneintranet.layout.tests:testing")
        setRoles(portal, TEST_USER_ID, ["Manager"])


FIXTURE = PloneintranetLayoutLayer()
INTEGRATION_TESTING = IntegrationTesting(
    bases=(FIXTURE,), name="PloneintranetLayoutLayer:Integration"
)
FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(FIXTURE,), name="PloneintranetLayoutLayer:Functional"
)


class IntegrationTestCase(unittest.TestCase):
    """Base class for integration tests."""

    layer = INTEGRATION_TESTING

    def setUp(self) -> None:
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]


class FunctionalTestCase(unittest.TestCase):
    """Base class for functional tests."""

    layer = FUNCTIONAL_TESTING


class PloneintranetLayoutLayerQRP(PloneSandboxLayer):

    defaultBases = (FIXTURE,)

    def setUpZope(self, app, configurationContext):
        # We need the error_zone slot from the QRP main_template to test error
        # views.
        import plone.app.blocks
        import quaive.resources.ploneintranet

        cc = configurationContext

        self.loadZCML(package=plone.app.blocks, context=cc)
        self.loadZCML(package=quaive.resources.ploneintranet, context=cc)

    def setUpPloneSite(self, portal):
        applyProfile(portal, "quaive.resources.ploneintranet:default")


FIXTURE_QRP = PloneintranetLayoutLayerQRP()
INTEGRATION_TESTING_QRP = IntegrationTesting(
    bases=(FIXTURE_QRP,), name="PloneintranetLayoutLayerQRP:Integration"
)


class IntegrationTestCaseQRP(unittest.TestCase):
    """Base class for integration tests."""

    layer = INTEGRATION_TESTING_QRP
