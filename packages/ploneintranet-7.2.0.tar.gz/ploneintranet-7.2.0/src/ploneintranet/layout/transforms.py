from plone.tiles.tile import TileThemingTransform as PATilesTileThemingTransform


class TileThemingTransform(PATilesTileThemingTransform):
    def transform(self, result, encoding):
        if self.request.response.status < 400:
            # Disable, if not an error case.
            # For errors, we need Diazo.
            self.request.response.setHeader("X-Theme-Disabled", "1")
        return None
