from plone.app.layout.viewlets import ViewletBase


class DisabledViewlet(ViewletBase):
    def update(self):
        pass

    def available(self):
        return False

    def render(self):
        return ""

    def index(self):
        return ""
