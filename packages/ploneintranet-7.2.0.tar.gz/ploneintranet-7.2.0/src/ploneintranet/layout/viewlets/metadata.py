from plone import api
from plone.app.layout.viewlets.common import ViewletBase
from plone.memoize.view import memoize


class Viewlet(ViewletBase):
    """Provide content for the open graph tags"""

    def update(self):
        """We do not need the attributes set by the default update method"""
        return

    def is_anon(self):
        """check if user is logged in"""
        if api.user.is_anonymous():
            return True
        return False

    def available(self):
        """Always"""
        return True

    @property
    @memoize
    def proto_view(self):
        return api.content.get_view("proto", context=self.context, request=self.request)

    def get_description(self):
        """Return the Description"""
        return self.context.Description()

    def get_manifest(self):
        """Build the url to the right manifest"""
        return "{}/++theme++ploneintranet.theme/generated/assets/{}/manifest/site.webmanifest.json".format(  # noqa
            api.portal.get().absolute_url(), self.proto_view.brand_name
        )
