from plone.app.layout.viewlets.common import ViewletBase
from ploneintranet import api as pi_api
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile


class PersonalBarViewlet(ViewletBase):

    index = ViewPageTemplateFile("personal_bar.pt")

    def update(self):
        profile = pi_api.userprofile.get_current()

        if profile is None:
            self.anonymous = True
            return

        self.anonymous = False
        self.avatar_url = "{url}?ts={timestamp}".format(
            url=pi_api.userprofile.avatar_url(username=profile.username),
            timestamp=profile.modified().ISO(),
        )
        self.initials = profile.initials
        self.username = profile.username
        self.fullname = profile.fullname or profile.username
