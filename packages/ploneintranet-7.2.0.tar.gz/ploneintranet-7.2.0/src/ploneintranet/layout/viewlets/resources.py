from plone import api
from ploneintranet.core import _
from ploneintranet.layout.utils import TEST_SITE_MARKER

import zope.deferredimport

zope.deferredimport.initialize()

zope.deferredimport.deprecated(
    "There is no need anymore to customize the scripts and styles viewlets since Plone 6",  # noqa: E501
    PIScriptsView="Products.CMFPlone.resources.browser.resource:ScriptsView",
    PIStylesView="Products.CMFPlone.resources.browser.resource:StylesView",
)


class TestSiteMarkerViewlet:
    """A viewlet that adds styles when a site is a test site.

    Used to visually distinguish test sites from production sites.
    """

    @property
    def notification_text(self):
        return api.portal.translate(
            _(
                "label_test_site_marker",
                default="This is the ${testsite} environment.",
                mapping={"testsite": TEST_SITE_MARKER},
            ),
        )
