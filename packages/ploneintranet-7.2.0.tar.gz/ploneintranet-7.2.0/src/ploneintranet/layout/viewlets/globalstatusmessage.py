from plone.app.layout.viewlets.common import ViewletBase
from plone.i18n.normalizer import idnormalizer
from ploneintranet.core import _
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from Products.statusmessages.interfaces import IStatusMessage


class GlobalStatusMessage(ViewletBase):
    """Displays messages to the current user.
    The markup is changed to rely on pat-notification.
    """

    index = ViewPageTemplateFile("globalstatusmessage.pt")

    def update(self):
        super().update()
        self.status = IStatusMessage(self.request)
        messages = self.status.show()
        for m in messages:
            m.id = idnormalizer.normalize(m.message)
        self.messages = messages
        self.closetext = _("button_close", default="Close")
