from plone.app.content.browser.vocabulary import SourceView

import json


class PISourceView(SourceView):

    def __call__(self) -> str:
        """Reimplement the @@getSource returned value to translate the returned json
        in a pat-autosuggest compatible way.

        The returned value in plain Plone has the following format:

        {total: N, results: [{id: "foo", text: "bar"}, ...]}

        We need to return only the list of results:

        [{id: "foo", text: "bar"}, ...]

        See https://github.com/Patternslib/Patterns/issues/1279
        """
        results = json.loads(super().__call__())
        return json.dumps(results.get("results", []))
