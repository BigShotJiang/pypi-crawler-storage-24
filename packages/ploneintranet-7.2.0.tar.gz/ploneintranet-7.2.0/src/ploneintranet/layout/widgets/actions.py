from plone.app.z3cform.csrf import AuthenticatedButtonActions
from ploneintranet.layout.interfaces import IPloneintranetFormLayer
from z3c.form.interfaces import IButtonForm
from zope.component import adapter
from zope.interface import Interface


@adapter(IButtonForm, IPloneintranetFormLayer, Interface)
class PIAuthenticatedButtonActions(AuthenticatedButtonActions):
    """Custom actions for Quaive

    We provide the ability to:
    1. add custom classes to the buttons
    2. ignore validation for specific buttons

    If not specified every button will have the class "pat-button" by default
    """

    default_button_classes = {
        "save": "pat-button default icon-ok-circle",
        "cancel": "pat-button icon-cancel-circle",
    }
    button_no_validation = {"cancel"}

    def update(self):
        super().update()
        button_classes = getattr(
            self.form, "button_classes", self.default_button_classes
        )
        button_no_validation = getattr(
            self.form, "button_no_validation", self.button_no_validation
        )
        for action in self:
            self[action].addClass(button_classes.get(action, "pat-button"))
            if action in button_no_validation:
                self[action].ignoreRequiredOnValidation = True
