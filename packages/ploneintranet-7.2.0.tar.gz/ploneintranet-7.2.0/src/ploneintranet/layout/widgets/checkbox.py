from ploneintranet.layout.interfaces import IPloneintranetFormLayer
from z3c.form.browser.checkbox import SingleCheckBoxWidget
from z3c.form.interfaces import IFieldWidget
from z3c.form.interfaces import ISingleCheckBoxWidget
from z3c.form.widget import FieldWidget
from zope.component import adapter
from zope.interface import implementer
from zope.interface import implementer_only
from zope.schema.interfaces import IBool


class IPIMinimalCheckBoxWidget(ISingleCheckBoxWidget):
    """A minimal checkbox widget, with inline label."""


@implementer_only(IPIMinimalCheckBoxWidget)
class PIMinimalCheckBoxWidget(SingleCheckBoxWidget):
    """A minimal checkbox widget, with inline label."""


@implementer(IFieldWidget)
@adapter(IBool, IPloneintranetFormLayer)
def PIMinimalCheckBoxFieldWidget(field, request):
    return FieldWidget(field, PIMinimalCheckBoxWidget(request))
