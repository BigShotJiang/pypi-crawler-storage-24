from pathlib import Path
from z3c.form.error import ErrorViewTemplateFactory

ErrorViewTemplate = ErrorViewTemplateFactory(
    Path(__file__).parent / "templates" / "error.pt"
)
