from plone.autoform.form import AutoExtensibleForm
from z3c.form.form import EditForm


class PIEditForm(AutoExtensibleForm, EditForm):
    """Generic edit form for Quaive."""

    # Setting default values for these attributes
    # default_fieldset_header will add an header before the fields
    default_fieldset_header = ""
    # if data_pat_inject is not empty, the form will use injection
    data_pat_inject = ""

    @property
    def template(self):
        """This will make the form use the template set with the zcml configuration"""
        return self.index
