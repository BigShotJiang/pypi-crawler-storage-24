from plone.app.contenttypes.testing import PLONE_APP_CONTENTTYPES_FIXTURE
from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import PloneSandboxLayer
from ploneintranet.microblog.testing import (
    PLONEINTRANET_MICROBLOG_CONTENTUPDATES_FIXTURE,
)


class PloneIntranetActivitystream(PloneSandboxLayer):

    defaultBases = (PLONE_APP_CONTENTTYPES_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        cc = configurationContext

        # We need the QRP main_template to test for any error cases.
        import quaive.resources.ploneintranet

        self.loadZCML(package=quaive.resources.ploneintranet, context=cc)

        # Load ZCML for this package
        import ploneintranet.activitystream

        self.loadZCML(package=ploneintranet.activitystream, context=cc)

    def setUpPloneSite(self, portal):
        applyProfile(portal, "quaive.resources.ploneintranet:default")
        applyProfile(portal, "ploneintranet.activitystream:default")

        # We need ploneintranet.userprofile for ``pas_view``.
        # But then also ploneintranet.notifications subscribers are registered.
        # For this to work, we need to install the ploneintranet.notifications
        # browser layer. So then:
        applyProfile(portal, "ploneintranet.notifications:default")


PLONEINTRANET_ACTIVITYSTREAM_FIXTURE = PloneIntranetActivitystream()
PLONEINTRANET_ACTIVITYSTREAM_INTEGRATION_TESTING = IntegrationTesting(
    bases=(
        PLONEINTRANET_MICROBLOG_CONTENTUPDATES_FIXTURE,
        PLONEINTRANET_ACTIVITYSTREAM_FIXTURE,
    ),
    name="PloneIntranetActivitystream:Integration",
)
PLONEINTRANET_ACTIVITYSTREAM_FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(PLONEINTRANET_ACTIVITYSTREAM_FIXTURE,),
    name="PloneIntranetActivitystream:Functional",
)
