from zope.interface import Interface


class IStatusActivityReply(Interface):
    """Deprecated. Do not use.

    Only here for BBB purposes to avoid crashing alsoProvides index
    on older statusupdates that may provide this marker interface.
    """


class IOmittedCommentTrail(Interface):
    """A marker interface that can be used by content items for which
    we do not want comments.
    It will cause their comment trail to not be rendered.
    """


class ISimplifiedCommentTrail(Interface):
    """A marker interface that can be used by content items that support commenting.
    It will cause their comment trail to be handled in a simpler form:
    The only thread to be shown is the one associated to the "Create" action,
    but the initial "Create" StatusUpdate will not be shown.
    A StatusUpdate / thread of an item marked with this interface will also
    be omitted from the general activity stream."""
