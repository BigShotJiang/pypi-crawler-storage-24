from plone import api
from plone.browserlayer.utils import registered_layers
from ploneintranet.activitystream.testing import (
    PLONEINTRANET_ACTIVITYSTREAM_INTEGRATION_TESTING,
)
from Products.CMFPlone.utils import get_installer

import unittest

PROJECTNAME = "ploneintranet.activitystream"


class InstallTestCase(unittest.TestCase):

    layer = PLONEINTRANET_ACTIVITYSTREAM_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer["portal"]

    def test_product_is_installed(self):
        self.installer = get_installer(self.portal, self.layer["request"])
        self.assertTrue(self.installer.is_product_installed(PROJECTNAME))

    def test_addon_layer(self):
        layers = [layer.getName() for layer in registered_layers()]
        self.assertIn("IPloneIntranetActivitystreamLayer", layers)


class UninstallTestCase(unittest.TestCase):

    layer = PLONEINTRANET_ACTIVITYSTREAM_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])
        with api.env.adopt_roles(["Manager"]):
            self.installer.uninstall_product(PROJECTNAME)

    def test_uninstalled(self):
        self.assertFalse(self.installer.is_product_installed(PROJECTNAME))

    def test_addon_layer_removed(self):
        layers = [layer.getName() for layer in registered_layers()]
        self.assertNotIn("IPloneIntranetActivitystreamLayer", layers)

    def test_view_method_removed(self):
        portal_types = api.portal.get_tool("portal_types")
        fti = portal_types["Folder"]
        self.assertNotIn("activitystream_portal", fti.view_methods)
