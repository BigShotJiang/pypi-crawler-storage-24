from zope.publisher.interfaces.browser import IDefaultBrowserLayer


class IPloneintranetBookmarksLayer(IDefaultBrowserLayer):
    """Marker interface to define ZTK browser layer"""
