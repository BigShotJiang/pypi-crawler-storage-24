from plone.memoize.view import memoize
from plone.protect.authenticator import createToken
from ploneintranet.bookmarks.browser.base import BookmarkView
from ploneintranet.core import _
from urllib.parse import urlencode


class View(BookmarkView):
    """A view that outputs a bookmark link on this context

    A context can be a Plone object or a search result
    """

    base_css_class = "icon pat-inject"

    @property
    def query_options(self):
        """The query string options for the bookmark action"""
        options = {"_authenticator": createToken()}
        return options

    @property
    def query_string(self):
        """The urlencoded query string options for the bookmark action"""
        return urlencode(self.query_options)

    @property
    @memoize
    def is_bookmarked(self):
        """Check if an object is bookmarked by uid"""
        uid = self.context.UID
        if uid is None:
            uid = self.context.context.UID
        if callable(uid):
            uid = uid()
        return self.ploneintranet_network.is_bookmarked("content", uid)

    @property
    def link_options(self):
        """Get the link options"""
        if self.is_bookmarked:
            options = {
                "action": "@@unbookmark",
                "title": _("Remove this item from your bookmarks"),
                "css_class": "icon-bookmark active ",
                "label": _("Remove bookmark"),
            }
        else:
            options = {
                "action": "@@bookmark",
                "title": _("Add this item to your bookmarks"),
                "css_class": "icon-bookmark-empty",
                "label": _("Bookmark"),
            }
        try:
            options["base_url"] = self.context.absolute_url()
        except AttributeError:
            options["base_url"] = self.context.url
        return options


class ViewIconified(View):
    """Iconified version of view"""

    base_css_class = "icon iconified pat-inject"

    @property
    def link_options(self):
        """Get the link options"""
        options = super().link_options
        if self.is_bookmarked:
            options["label"] = _("Remove bookmark")
        return options

    @property
    def query_options(self):
        """Add iconified=True"""
        options = super().query_options
        options["iconified"] = True
        return options
