from plone import api
from plone.memoize.view import memoize_contextless
from plone.protect.utils import addTokenToUrl
from plone.tiles import Tile
from ploneintranet.bookmarks.browser.base import BookmarkActionView
from ploneintranet.bookmarks.browser.bookmark_link import View
from ploneintranet.core import _
from ploneintranet.layout.app import apps_container_id


class BookmarksTile(Tile):
    """Bookmarks as a tile"""

    title = _("label_title_app_bookmarks", default="Bookmarks")

    @property
    def app(self):
        portal = api.portal.get()
        return getattr(portal, apps_container_id).bookmarks

    @property
    @memoize_contextless
    def app_url(self):
        return self.app.absolute_url()

    @property
    @memoize_contextless
    def app_bookmarks(self):
        """Return the bookmark that will be displayed in the tile"""
        return api.content.get_view("app-bookmarks", self.app, self.request)

    @memoize_contextless
    def get_bookmarks(self):
        """Return the bookmarks according to the requested sort_by"""
        sort_by = self.request.get("sort_by", "recent")
        if sort_by == "popularity":
            return self.app_bookmarks.most_popular_bookmarks()
        else:
            return self.app_bookmarks.my_recent_bookmarks()


class BookmarksOfWorkspacesTile(BookmarksTile):
    """Bookmarks of Workspaces as a Tile"""

    title = _("label_title_app_workspaces", default="Workspaces")

    @memoize_contextless
    def get_bookmarks(self):
        """Return my bookmarked workspaces, sorted by modified"""
        bookmarks = self.app_bookmarks.my_bookmarked_workspaces()
        sorted_bookmarks = sorted(bookmarks, key=lambda x: x.modified, reverse=True)
        return sorted_bookmarks


class BookmarksOfAppsTile(BookmarksTile):
    """Bookmarks of Apps as a Tile"""

    title = _("label_apps", default="Apps")

    @memoize_contextless
    def get_bookmarks(self):
        """Return my bookmarked apps"""
        return self.app_bookmarks.my_bookmarked_apps()


class BookmarksOfDocumentsTile(BookmarksTile):
    """Bookmarks of Documents as a Tile"""

    title = _("label_documents", default="Documents")

    @memoize_contextless
    def get_bookmarks(self):
        """Return my bookmarked documents"""
        return self.app_bookmarks.my_bookmarked_documents()


class WorkspaceBookmarkTile(Tile, BookmarkActionView, View):
    """Proto specific way to bookmark a workspace on the workspace view

    XXX This tile should be moved to ploneintranet.workspace
    """

    msg = ""
    watch_msg = ""

    @property
    def is_watched(self):
        return self.ploneintranet_network.is_watching("workspace", self.context.UID())

    def __call__(self):
        if self.request.get("bookmark"):
            self.ploneintranet_network.bookmark("content", self.context.UID())
            self.msg = _("success_bookmark", "You have bookmarked this item.")
        elif self.request.get("unbookmark"):
            self.ploneintranet_network.unbookmark("content", self.context.UID())
            self.msg = _("success_unbookmarked", "You have unbookmarked this item.")

        if self.request.get("watch"):
            self.ploneintranet_network.watch("workspace", self.context.UID())
            self.watch_msg = _("You are now watching this workspace.")
            self.watch_msg_type = "success"
        elif self.request.get("unwatch"):
            self.ploneintranet_network.unwatch("workspace", self.context.UID())
            self.watch_msg = _("You are no longer watching this workspace.")
            self.watch_msg_type = "warning"
        if self.is_bookmarked:
            self.title = _("Bookmarked")
            self.icon_class = "icon-bookmark"
            self.description = _("Remove this workspace from your bookmarks")
            self.link = addTokenToUrl(self.url + "?unbookmark=1")
        else:
            self.title = _("Bookmark")
            self.icon_class = "icon-bookmark-empty"
            self.description = _("Add this workspace to your bookmarks.")
            self.link = addTokenToUrl(self.url + "?bookmark=1")
            self.status = ""
        return self.index()
