"""Base module for unittesting."""

from DateTime import DateTime
from plone import api
from plone.app.contenttypes.testing import PLONE_APP_CONTENTTYPES_FIXTURE
from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import PloneSandboxLayer
from plone.app.testing import setRoles
from plone.app.testing import TEST_USER_ID
from plone.testing import zope as zope_testing
from ploneintranet.layout.app import apps_container_id
from ploneintranet.search.interfaces import IPloneintranetSearchLayer
from ploneintranet.search.solr.interfaces import IMaintenance
from ploneintranet.search.solr.testing import load_solr_zcml
from ploneintranet.search.solr.testing import SOLR_FIXTURE
from Products.CMFCore.indexing import processQueue
from zope.component import getUtility
from zope.interface import alsoProvides

import unittest


class PloneintranetBookmarksLayer(PloneSandboxLayer):

    defaultBases = (SOLR_FIXTURE, PLONE_APP_CONTENTTYPES_FIXTURE)

    def solr_sync(self, portal):
        """Sync the portal content in to Solr"""
        with api.env.adopt_user("admin"):
            request = portal.REQUEST
            alsoProvides(request, IPloneintranetSearchLayer)
            view = api.content.get_view("solr-maintenance", portal, request)
            view.sync(close_connection=True)

    def setUpZope(self, app, configurationContext):
        import ploneintranet.search

        self.loadZCML(package=ploneintranet.search)
        import ploneintranet.search.solr

        self.loadZCML(package=ploneintranet.search.solr)
        load_solr_zcml()

        import collective.workspace

        self.loadZCML(package=collective.workspace)
        zope_testing.installProduct(app, "collective.workspace")

        import ploneintranet.network

        self.loadZCML(package=ploneintranet.network)

        import ploneintranet.layout

        self.loadZCML(package=ploneintranet.layout)

        import ploneintranet.docconv.client

        self.loadZCML(package=ploneintranet.docconv.client)

        import ploneintranet.search

        self.loadZCML(package=ploneintranet.search)

        import Products.membrane

        self.loadZCML(package=Products.membrane)
        zope_testing.installProduct(app, "Products.membrane")

        import ploneintranet.userprofile

        self.loadZCML(package=ploneintranet.userprofile)

        import ploneintranet.todo

        self.loadZCML(package=ploneintranet.todo)

        import ploneintranet.workspace

        self.loadZCML(package=ploneintranet.workspace)

        import ploneintranet.bookmarks

        self.loadZCML(package=ploneintranet.bookmarks)

    def setUpPloneSite(self, portal):
        applyProfile(portal, "ploneintranet.bookmarks:default")
        setRoles(portal, TEST_USER_ID, ["Manager"])

        # Add some content that we can bookmark
        page = api.content.create(
            container=portal, type="Document", title="Bookmarkable page"
        )
        page.reindexObject()
        workspace = api.content.create(
            container=portal.workspaces,
            type="ploneintranet.workspace.workspacefolder",
            title="Bookmarkable workspace",
        )
        workspace.creation_date = DateTime("2016/01/01")
        workspace.reindexObject()
        profile = api.content.create(
            type="ploneintranet.userprofile.userprofile",
            container=portal.profiles,
            title="Bookmarkable One",
            first_name="Bookmarkable",
            last_name="One",
        )
        profile.reindexObject()
        # Give our app a distinct title
        bookmark_app = portal.restrictedTraverse("%s/bookmarks" % apps_container_id)
        bookmark_app.title = "BookmarksApp"
        bookmark_app.reindexObject()
        self.solr_sync(portal)
        SOLR_FIXTURE._solr_snapshot()

    def testTearDown(self):
        SOLR_FIXTURE._solr_restore()


FIXTURE = PloneintranetBookmarksLayer()
INTEGRATION_TESTING = IntegrationTesting(
    bases=(FIXTURE,), name="PloneintranetBookmarksLayer:Integration"
)
FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(FIXTURE,), name="PloneintranetBookmarksLayer:Functional"
)


class IntegrationTestCase(unittest.TestCase):
    """Base class for integration tests."""

    layer = INTEGRATION_TESTING

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.bookmark_app = self.portal.apps.bookmarks
        self.request = self.layer["request"]

    def solr_commit(self):
        """On integration tests we need to commit on solr before searching"""
        processQueue()
        getUtility(IMaintenance).connection.commit()


class FunctionalTestCase(unittest.TestCase):
    """Base class for functional tests."""

    layer = FUNCTIONAL_TESTING
