"""Setup/installation tests for this package."""

from plone.browserlayer import utils
from ploneintranet.bookmarks.browser.interfaces import IPloneintranetBookmarksLayer
from ploneintranet.bookmarks.testing import IntegrationTestCase
from Products.CMFPlone.utils import get_installer

PROJECTNAME = "ploneintranet.bookmarks"


class TestInstall(IntegrationTestCase):
    """Test installation of this product into Plone."""

    def setUp(self):
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])

    def test_product_installed(self):
        self.assertTrue(self.installer.is_product_installed(PROJECTNAME))

    def test_browserlayer(self):
        self.assertIn(IPloneintranetBookmarksLayer, utils.registered_layers())


class TestUninstall(IntegrationTestCase):
    """Test this product is properly uninstalled."""

    def setUp(self):
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])
        self.installer.uninstall_product(PROJECTNAME)

    def test_uninstall(self):
        self.assertFalse(self.installer.is_product_installed(PROJECTNAME))

    def test_browserlayer(self):
        self.assertNotIn(IPloneintranetBookmarksLayer, utils.registered_layers())
