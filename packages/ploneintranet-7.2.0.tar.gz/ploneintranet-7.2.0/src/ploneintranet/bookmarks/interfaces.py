from zope.interface import Interface


class INotShownInBookmarkOverview(Interface):
    """Marker Interface that allows to exclude content types from being shown
    on the overview page of the bookmarks app"""
