from functools import cached_property
from ploneintranet import api as pi_api
from ploneintranet.core import _
from ploneintranet.imagebank.browser.base import ImageBankBaseView


class ImageBankAppView(ImageBankBaseView):
    """The Image bank app view."""

    @cached_property
    def no_collections_message(self):
        if self.can_add_collections():
            return _(
                "message_no_collections_with_add_permission",
                default=(
                    "There are no collections to show. "
                    "Use the add button to create a new collection."
                ),
            )
        return _(
            "message_no_collections_no_permission",
            default="There are no collections to show.",
        )

    @cached_property
    def base_query(self) -> dict:
        """Return a dictionary that can will be used as to query collections."""
        return {
            "context": self.collections_container,
            "portal_type": self.allowed_collection_types,
            "sort_on": "sortable_title",
            "depth": 1,
        }


class ImageBankAppPrivateView(ImageBankAppView):
    """The Image bank app view for the private collection."""

    @cached_property
    def collections_container(self):
        return pi_api.userprofile.get_current()

    @cached_property
    def no_collections_message(self):
        return _(
            "message_no_private_pictures",
            default=(
                "You have not uploaded any private images yet. "
                "Use this section to store images that are visible only to you. "
                "You can move them to a shared collection at any time "
                "if you wish to make them available to others."
            ),
        )
