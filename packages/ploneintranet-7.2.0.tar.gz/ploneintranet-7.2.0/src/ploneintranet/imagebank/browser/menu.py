from plone import api
from Products.CMFCore.permissions import DeleteObjects
from Products.CMFCore.permissions import ModifyPortalContent
from Products.Five import BrowserView


class ImageBankCollectionMenuView(BrowserView):
    """Menu for image bank collection"""

    def can_delete(self):
        return api.user.has_permission(DeleteObjects, obj=self.context)

    def can_edit(self):
        return api.user.has_permission(ModifyPortalContent, obj=self.context)

    def display_collection_actions(self):
        return self.can_edit() or self.can_delete()


class ImageBankImageMenuView(BrowserView):
    """Menu for image bank image"""

    def can_delete(self):
        return api.user.has_permission(DeleteObjects, obj=self.context)
