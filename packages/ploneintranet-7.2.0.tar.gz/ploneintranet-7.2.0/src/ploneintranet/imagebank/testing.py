from plone.app.contenttypes.testing import PLONE_APP_CONTENTTYPES_FIXTURE
from plone.app.testing import applyProfile
from plone.app.testing import IntegrationTesting
from plone.app.testing import PloneSandboxLayer
from plone.testing import zope


class PloneIntranetImageBankLayer(PloneSandboxLayer):

    defaultBases = (PLONE_APP_CONTENTTYPES_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        import ploneintranet.imagebank

        self.loadZCML("configure.zcml", package=ploneintranet.imagebank)

        # Required to install ploneintranet.userprofile
        zope.installProduct(app, "Products.membrane")

    def setUpPloneSite(self, portal):
        applyProfile(portal, "ploneintranet.imagebank:default")


PLONEINTRANET_IMAGEBANK_FIXTURE = PloneIntranetImageBankLayer()
PLONEINTRANET_IMAGEBANK_INTEGRATION_TESTING = IntegrationTesting(
    bases=(PLONEINTRANET_IMAGEBANK_FIXTURE,), name="PloneIntranetImageBank:Integration"
)
