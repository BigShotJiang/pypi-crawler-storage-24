from plone import api
from ploneintranet.imagebank.browser.base import CollectionListingView
from ploneintranet.imagebank.browser.collection import ImageBankCollectionView
from ploneintranet.imagebank.browser.menu import ImageBankCollectionMenuView
from ploneintranet.imagebank.browser.panel import PanelEditCollectionView
from ploneintranet.imagebank.testing import PLONEINTRANET_IMAGEBANK_INTEGRATION_TESTING

import unittest


class TestImageBankCollection(unittest.TestCase):

    layer = PLONEINTRANET_IMAGEBANK_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]
        self.collection = self.portal["image-bank-collections"]["all-the-images"]

    def get_view(self, form=None) -> ImageBankCollectionView:
        if form is not None:
            self.request.form.update(form)
        view = api.content.get_view(
            "app-image-bank-collection", self.collection, self.request
        )
        return view

    def test_collection_view_query(self):
        view = self.get_view()
        self.assertDictEqual(
            view.base_query,
            {
                "path": {"query": ["/plone/"]},
                "portal_type": {"query": "Image"},
                "sort_on": "created",
                "sort_order": "descending",
            },
        )
        self.assertDictEqual(
            view.query,
            {
                "path": {"query": ["/plone/"]},
                "portal_type": {"query": "Image"},
                "sort_on": "created",
                "sort_order": "descending",
            },
        )

    def test_collection_view_query_with_searchable_text(self):
        view = self.get_view({"SearchableText": "foo"})
        self.assertDictEqual(
            view.base_query,
            {
                "path": {"query": ["/plone/"]},
                "portal_type": {"query": "Image"},
                "sort_on": "created",
                "sort_order": "descending",
            },
        )

        self.assertDictEqual(
            view.query,
            {
                "path": {"query": ["/plone/"]},
                "portal_type": {"query": "Image"},
                "SearchableText": "foo*",
                "sort_on": "created",
                "sort_order": "descending",
            },
        )

    def test_listing_view(self):
        """Check we redirect to the canonical URL"""
        view = api.content.get_view("listing_view", self.collection, self.request)
        self.assertIsInstance(view, CollectionListingView)
        self.assertEqual(
            view(), f"{self.collection.absolute_url()}/@@app-image-bank-collection"
        )

    def test_menu_view(self):
        """Check we redirect to the canonical URL"""
        view = api.content.get_view("menu-image-bank", self.collection, self.request)
        self.assertIsInstance(view, ImageBankCollectionMenuView)

    def test_cannot_upload(self):
        view = self.get_view()
        self.assertFalse(view.can_upload())
        with self.assertRaises(api.exc.InvalidParameterError):
            view = api.content.get_view(
                "image-bank-upload-form", self.collection, self.request
            )

    def test_can_edit(self):
        view = api.content.get_view(
            "panel-edit-collection", self.collection, self.request
        )
        self.assertIsInstance(view, PanelEditCollectionView)
