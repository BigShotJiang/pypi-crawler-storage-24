from plone import api
from ploneintranet.imagebank.browser.menu import ImageBankImageMenuView
from ploneintranet.imagebank.browser.panel import PanelImageBankDeleteConfirmationView
from ploneintranet.imagebank.browser.panel import PanelImageBankImageView
from ploneintranet.imagebank.testing import PLONEINTRANET_IMAGEBANK_INTEGRATION_TESTING

import unittest


class TestImageBankImage(unittest.TestCase):

    layer = PLONEINTRANET_IMAGEBANK_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]
        self.app = self.portal.apps["image-bank"]
        self.collections = self.portal["image-bank-collections"]
        with api.env.adopt_user("admin"):
            self.folder = api.content.create(
                container=self.collections,
                type="Folder",
                id="foo",
                title="Foo",
                safe_id=True,
            )

            self.image = api.content.create(
                container=self.folder,
                type="Image",
                id="foo-image",
                title="Foo image",
                safe_id=True,
            )

    def test_default_view(self):
        """Check we override the default view to show the image
        in the context of the image bank.
        """
        view = api.content.get_view("image_view", self.image, self.request)
        self.assertIsInstance(view, PanelImageBankImageView)

    def test_panel_view(self):
        """Check that the panel view is registered.
        This is needed to show the image in the context of the image bank,
        even if it is in another context, e.g. a workspace image.
        """
        view = api.content.get_view("panel-image-bank-image", self.image, self.request)
        self.assertIsInstance(view, PanelImageBankImageView)

    def test_menu_view(self):
        """Check we can get the proper menu view for the image."""
        view = api.content.get_view("menu-image-bank", self.image, self.request)
        self.assertIsInstance(view, ImageBankImageMenuView)

    def test_delete_panel(self):
        """Check we get the proper delete confirmation panel for the image."""
        view = api.content.get_view(
            "panel-image-bank-delete-confirmation", self.image, self.request
        )
        self.assertIsInstance(view, PanelImageBankDeleteConfirmationView)
