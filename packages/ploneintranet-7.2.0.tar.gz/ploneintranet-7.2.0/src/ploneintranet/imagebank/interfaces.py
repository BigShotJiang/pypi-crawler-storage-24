from plone.app.contenttypes.behaviors.collection import ISyndicatableCollection
from plone.app.contenttypes.interfaces import IFolder
from ploneintranet.layout.app import IApp
from ploneintranet.layout.interfaces import IApplicationLabel
from zope.interface import Interface


class IImageBankApp(IApp):
    """Marker interface for an Image Bank app."""


class IImageBankCollectionContainer(IApplicationLabel):
    """Marker interface for the Image Bank collection container."""


class IImageBankAlbum(Interface):
    """Marker interface for an Image Bank album.
    This is something that will display some images.
    """


# We need ISyndicatableCollection instead of ICollection
# because it wins due to the behavior `plplone.collection` behavior
class IImageBankCollection(ISyndicatableCollection, IImageBankAlbum):
    """Marker interface for an Image Bank album that is backed up by a Collection."""


class IImageBankFolder(IFolder, IImageBankAlbum):
    """Marker interface for an Image Bank album that is also a Folder."""
