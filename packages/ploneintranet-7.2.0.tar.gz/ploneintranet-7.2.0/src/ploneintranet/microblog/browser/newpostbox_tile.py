from logging import getLogger
from plone.tiles import Tile
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile

logger = getLogger(__name__)


class NewPostBoxTile(Tile):

    index = ViewPageTemplateFile("templates/new-post-box-tile.pt")
