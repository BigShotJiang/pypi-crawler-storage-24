from .update_social import UpdateSocialHandler
from ploneintranet import api as piapi
from ploneintranet.microblog.statusupdate import StatusUpdate

import logging

logger = logging.getLogger(__name__)


class PostWellDoneView(UpdateSocialHandler):
    """
    Helper view that handles HTTP POST of update-social
    and renders a new update-social + the created post
    for injection back into the calling view.
    """

    def init_post(self) -> StatusUpdate:
        return piapi.microblog.statusupdate.create(
            text=self.post_text,
            microblog_context=self.microblog_context,
            mention_ids=self.post_mentions,
            tags=self.post_tags,
        )
