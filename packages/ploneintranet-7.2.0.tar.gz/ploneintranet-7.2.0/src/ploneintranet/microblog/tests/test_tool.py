from plone import api
from ploneintranet.microblog.interfaces import IMicroblogTool
from ploneintranet.microblog.interfaces import IStatusContainer
from ploneintranet.microblog.testing import PLONEINTRANET_MICROBLOG_INTEGRATION_TESTING
from Products.CMFPlone.utils import get_installer
from zope.component import queryUtility

import unittest


class TestMicroblogTool(unittest.TestCase):

    layer = PLONEINTRANET_MICROBLOG_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.portal.REQUEST)

    def test_tool_available(self):
        tool = queryUtility(IMicroblogTool)
        self.assertTrue(IStatusContainer.providedBy(tool))

    def test_tool_uninstalled(self):
        with api.env.adopt_roles(["Manager"]):
            self.installer.uninstall_product("ploneintranet.microblog")
        self.assertNotIn("ploneintranet_microblog", self.portal)
        tool = queryUtility(IMicroblogTool)
        self.assertIsNone(tool)
