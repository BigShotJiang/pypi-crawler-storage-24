from ploneintranet.notifications.utils import i18n_translate
from ploneintranet.notifications.utils import message_variant

# Single comment on a document
message_commented_on_a_document_you_created = i18n_translate(
    "message_commented_on_a_document_you_created_secure",
    default="${actor} commented on your document in ${location}.",  # noqa: E501
)
message_commented_on_a_document_you_created_wt = i18n_translate(
    "message_commented_on_a_document_you_created",
    default="${actor} commented on your document “${object}” in ${location}.",  # noqa: E501
)
variant_commented_on_a_document_you_created = message_variant(
    message_commented_on_a_document_you_created,
    message_commented_on_a_document_you_created_wt,
)

message_commented_on_a_document = i18n_translate(
    "message_commented_on_a_document_secure",
    default="${actor} commented on a document in ${location}.",  # noqa: E501
)
message_commented_on_a_document_wt = i18n_translate(
    "message_commented_on_a_document",
    default="${actor} commented on the document “${object}” in ${location}.",  # noqa: E501
)
variant_commented_on_a_document = message_variant(
    message_commented_on_a_document, message_commented_on_a_document_wt
)

# Single comment on a post
message_commented_on_your_post = i18n_translate(
    "message_commented_on_your_post",
    default="${actor} commented on your post of ${object_creation_date}.",
)
message_commented_on_your_post_wt = i18n_translate(
    "message_commented_on_your_post_wt",
    default="${actor} commented on your post: “${object}”.",
)
variant_commented_on_your_post = message_variant(
    message_commented_on_your_post, message_commented_on_your_post_wt
)

message_commented_on_a_post_from = i18n_translate(
    "message_commented_on_a_post_from",
    default="${actor} commented on a post from ${author}.",
)
message_commented_on_a_post_from_wt = i18n_translate(
    "message_commented_on_a_post_from_wt",
    default="${actor} commented on the post “${object}” by ${author}.",
)
variant_commented_on_a_post_from = message_variant(
    message_commented_on_a_post_from, message_commented_on_a_post_from_wt
)

# Three or more combined comments on post in a workspace
message_user_and_x_users_commented_on_your_post_in_workspace = i18n_translate(
    "message_user_and_x_users_commented_on_your_post_in_workspace",
    default="${actor} and ${comment_rest_count} other users commented on your post of ${object_creation_date} in ${location}.",  # noqa: E501
)
message_user_and_x_users_commented_on_your_post_in_workspace_wt = i18n_translate(
    "message_user_and_x_users_commented_on_your_post_in_workspace_wt",
    default="${actor} and ${comment_rest_count} other users commented on your post “${object}” in ${location}.",  # noqa: E501
)
variant_user_and_x_users_commented_on_your_post_in_workspace = message_variant(
    message_user_and_x_users_commented_on_your_post_in_workspace,
    message_user_and_x_users_commented_on_your_post_in_workspace_wt,
)

message_user_and_x_users_commented_on_post_in_workspace = i18n_translate(
    "message_user_and_x_users_commented_on_post_in_workspace",
    default="${actor} and ${comment_rest_count} commented on the post by ${author} in ${location}.",  # noqa: E501
)
message_user_and_x_users_commented_on_post_in_workspace_wt = i18n_translate(
    "message_user_and_x_users_commented_on_post_in_workspace_wt",
    default="${actor} and ${comment_rest_count} commented on the post “${object}” in ${location}.",  # noqa: E501
)
variant_user_and_x_users_commented_on_post_in_workspace = message_variant(
    message_user_and_x_users_commented_on_post_in_workspace,
    message_user_and_x_users_commented_on_post_in_workspace_wt,
)


# Two combined comments on a post in a workspace
message_user_and_one_user_commented_on_your_post_in_workspace = i18n_translate(
    "message_user_and_one_user_commented_on_your_post_in_workspace",
    default="${actor} and ${actor_2} commented on your post of ${object_creation_date} in ${location}.",  # noqa: E501
)
message_user_and_one_user_commented_on_your_post_in_workspace_wt = i18n_translate(
    "message_user_and_one_user_commented_on_your_post_in_workspace_wt",
    default="${actor} and ${actor_2} commented on your post “${object}” in ${location}.",  # noqa: E501
)
variant_user_and_one_user_commented_on_your_post_in_workspace = message_variant(
    message_user_and_one_user_commented_on_your_post_in_workspace,
    message_user_and_one_user_commented_on_your_post_in_workspace_wt,
)

message_user_and_one_user_commented_on_post_in_workspace = i18n_translate(
    "message_user_and_one_user_commented_on_post_in_workspace",
    default="${actor} and ${actor_2} commented on the post by ${author} in ${location}.",  # noqa: E501
)
message_user_and_one_user_commented_on_post_in_workspace_wt = i18n_translate(
    "message_user_and_one_user_commented_on_post_in_workspace_wt",
    default="${actor} and ${actor_2} commented on the post “${object}” in ${location}.",  # noqa: E501
)
variant_user_and_one_user_commented_on_post_in_workspace = message_variant(
    message_user_and_one_user_commented_on_post_in_workspace,
    message_user_and_one_user_commented_on_post_in_workspace_wt,
)


# Single comments on a post in a workspace
message_user_commented_on_your_post_in_workspace = i18n_translate(
    "message_user_commented_on_your_post_in_workspace",
    default="${actor} commented on your post of ${object_creation_date} in ${location}.",  # noqa: E501
)
message_user_commented_on_your_post_in_workspace_wt = i18n_translate(
    "message_user_commented_on_your_post_in_workspace_wt",
    default="${actor} commented on your post “${object}” in ${location}.",  # noqa: E501
)
variant_user_commented_on_your_post_in_workspace = message_variant(
    message_user_commented_on_your_post_in_workspace,
    message_user_commented_on_your_post_in_workspace_wt,
)

message_user_commented_on_post_in_workspace = i18n_translate(
    "message_user_commented_on_post_in_workspace",
    default="${actor} commented on the post by ${author} in ${location}.",  # noqa: E501
)
message_user_commented_on_post_in_workspace_wt = i18n_translate(
    "message_user_commented_on_post_in_workspace_wt",
    default="${actor} commented on the post “${object}” in ${location}.",  # noqa: E501
)
variant_user_commented_on_post_in_workspace = message_variant(
    message_user_commented_on_post_in_workspace,
    message_user_commented_on_post_in_workspace_wt,
)


# Three or more combined comments on post of current user in a workspace
message_user_and_x_users_commented_on_post_in_workspace = i18n_translate(
    "message_user_and_x_users_commented_on_post_in_workspace",
    default="${actor} and ${comment_rest_count} other users commented on the post by ${author} in ${location}.",  # noqa: E501
)
message_user_and_x_users_commented_on_post_in_workspace_wt = i18n_translate(
    "message_user_and_x_users_commented_on_post_in_workspace_wt",
    default="${actor} and ${comment_rest_count} other users commented on the post “${object}” in ${location}.",  # noqa: E501
)
variant_user_and_x_users_commented_on_post_in_workspace = message_variant(
    message_user_and_x_users_commented_on_post_in_workspace,
    message_user_and_x_users_commented_on_post_in_workspace_wt,
)


# Mentioning
message_mentioned_you_in_a_post = i18n_translate(
    "message_mentioned_you_in_a_post",
    default="${actor} mentioned you in a post of ${object_creation_date}.",
)
message_mentioned_you_in_a_post_wt = i18n_translate(
    "message_mentioned_you_in_a_post_wt",
    default="${actor} mentioned you in the post “${object}” of ${object_creation_date}.",  # noqa: E501
)
variant_mentioned_you_in_a_post = message_variant(
    message_mentioned_you_in_a_post, message_mentioned_you_in_a_post_wt
)

message_mentioned_you_in_a_comment = i18n_translate(
    "message_mentioned_you_in_a_comment",
    default="${actor} mentioned you in a comment.",
)

# The four mention message ids below are NOT present in prototype
message_mentioned_you_in_a_comment_wt = i18n_translate(
    "message_mentioned_you_in_a_comment_wt",
    default="${actor} mentioned you in a comment on the post “${object}” of ${object_creation_date}.",  # noqa: E501
)
variant_mentioned_you_in_a_comment = message_variant(
    message_mentioned_you_in_a_comment, message_mentioned_you_in_a_comment_wt
)

message_mentioned_you_in_a_comment_in_workspace = i18n_translate(
    "message_mentioned_you_in_a_comment_in_workspace",
    default="${actor} mentioned you in a comment on the post by ${author} in ${location}.",  # noqa: E501
)
message_mentioned_you_in_a_comment_in_workspace_wt = i18n_translate(
    "message_mentioned_you_in_a_comment_in_workspace_wt",
    default="${actor} mentioned you in a comment on the post “${object}” in ${location}.",  # noqa: E501
)
variant_mentioned_you_in_a_comment_in_workspace = message_variant(
    message_mentioned_you_in_a_comment_in_workspace,
    message_mentioned_you_in_a_comment_in_workspace_wt,
)

message_mentioned_you_in_a_comment_on_a_document_in_workspace = i18n_translate(
    "message_mentioned_you_in_a_comment_on_a_document_in_workspace_secure",
    default="${actor} mentioned you in a comment on a document in ${location}.",  # noqa: E501
)
message_mentioned_you_in_a_comment_on_a_document_in_workspace_wt = i18n_translate(
    "message_mentioned_you_in_a_comment_on_a_document_in_workspace",
    default="${actor} mentioned you in a comment on the document “${object}” in ${location}.",  # noqa: E501
)
variant_mentioned_you_in_a_comment_on_a_document_in_workspace = message_variant(
    message_mentioned_you_in_a_comment_on_a_document_in_workspace,
    message_mentioned_you_in_a_comment_on_a_document_in_workspace_wt,
)

message_mentioned_you_in_a_comment_on_a_document = i18n_translate(
    "message_mentioned_you_in_a_comment_on_a_document_secure",
    default="${actor} mentioned you in a comment on a document.",  # noqa: E501
)
message_mentioned_you_in_a_comment_on_a_document_wt = i18n_translate(
    "message_mentioned_you_in_a_comment_on_a_document",
    default="${actor} mentioned you in a comment on the document “${object}”.",  # noqa: E501
)
variant_mentioned_you_in_a_comment_on_a_document = message_variant(
    message_mentioned_you_in_a_comment_on_a_document,
    message_mentioned_you_in_a_comment_on_a_document_wt,
)

# Notifications for Activities app

# Posts created in Activities app
message_created_a_new_post = i18n_translate(
    "message_created_a_new_post", default="${actor} created a new post."
)
message_created_a_new_post_wt = i18n_translate(
    "message_created_a_new_post_wt",
    default="${actor} created the following post: “${object}”.",
)
variant_created_a_new_post = message_variant(
    message_created_a_new_post, message_created_a_new_post_wt
)


# Post created in workspace
message_created_a_new_post_in_location = i18n_translate(
    "message_created_a_new_post_in_location",
    default="${actor} created a new post in ${location}.",
)
message_created_a_new_post_in_location_wt = i18n_translate(
    "message_created_a_new_post_in_location_wt",
    default="${actor} created the following post in ${location}: “${object}”.",
)
variant_created_a_new_post_in_location = message_variant(
    message_created_a_new_post_in_location, message_created_a_new_post_in_location_wt
)


# Notifications for News app
message_commented_on_a_news_item = i18n_translate(
    "message_commented_on_a_news_item",
    default="${actor} commented on the news item “${object}” in ${section}.",
)
message_published_a_news_item = i18n_translate(
    "message_published_a_news_item",
    default="${actor} published the news item “${object}” in ${section}.",
)
message_commented_on_a_news_item_you_created = i18n_translate(
    "message_commented_on_a_news_item_you_created",
    default="${actor} commented on your news item “${object}” in ${section}.",
)
