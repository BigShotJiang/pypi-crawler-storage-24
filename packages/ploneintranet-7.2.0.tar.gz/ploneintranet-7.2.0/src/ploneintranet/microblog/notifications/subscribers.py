from ploneintranet.notifications.sql import saconfig


def statusupdate_added_handler(context, event):
    """This handler is called when an object is added to the site"""
    if not context.is_human_update:
        return

    saconfig.log_event(context, "statusupdate_added")
