from .interfaces import IMicroblogTool
from .statuscontainer import QueuedStatusContainer
from OFS.SimpleItem import SimpleItem
from Products.CMFCore.utils import UniqueObject
from zope.interface import implementer


@implementer(IMicroblogTool)
class MicroblogTool(UniqueObject, SimpleItem, QueuedStatusContainer):
    """Provide IStatusContainer as a site utility."""

    meta_type = "ploneintranet.microblog tool"
    id = "ploneintranet_microblog"
