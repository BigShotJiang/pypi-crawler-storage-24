from plone import api
from ploneintranet.microblog.interfaces import IMicroblogTool
from zope.interface.interfaces import ComponentLookupError

import logging

log = logging.getLogger(__name__)


def uninstall(context):
    portal = api.portal.get()
    _removePersistentUtility(portal)


def _removePersistentUtility(portal):
    sm = portal.getSiteManager()
    sm.unregisterUtility(provided=IMicroblogTool)
    try:
        util = sm.getUtility(IMicroblogTool)
        del util
    except ComponentLookupError:
        pass
    sm.utilities.unsubscribe((), IMicroblogTool)
    try:
        del sm.utilities.__dict__["_provided"][IMicroblogTool]
    except KeyError:
        pass
    log.info("Removed IMicroblogTool utility")
