from zope.i18nmessageid import MessageFactory

import zope.deferredimport

_ = MessageFactory("ploneintranet")

# This can be removed once all quaive.app.* branches
# 'consolidate_translations` have been merged.
zope.deferredimport.deprecated(
    "Use from ploneintranet.core import _ instead",
    ploneintranetCoreMessageFactory="ploneintranet.core:_",
)
