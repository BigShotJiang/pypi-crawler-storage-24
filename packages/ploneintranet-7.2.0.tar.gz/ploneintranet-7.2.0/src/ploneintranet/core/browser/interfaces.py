from zope.interface import Interface


class IPloneIntranetCoreLayer(Interface):
    """Marker interface to define ZTK browser layer"""
