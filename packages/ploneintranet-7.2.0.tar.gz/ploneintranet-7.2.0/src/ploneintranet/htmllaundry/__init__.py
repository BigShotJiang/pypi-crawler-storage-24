# htmllaundry was originally a library developed by Wichert Akkerman
#
# See: https://github.com/syslabcom/htmllaundry/tree/master
#
# A subset of the now unmaintained package code was copied and pasted
# into the ploneintranet.htmllaundry
#
# The original htmllaundry package was licensed under the BSD license
#
