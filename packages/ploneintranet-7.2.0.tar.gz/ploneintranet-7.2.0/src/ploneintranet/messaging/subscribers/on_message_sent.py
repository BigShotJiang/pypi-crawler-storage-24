from ploneintranet import api as pi_api


def push_notification(message, event=None):
    inbox = message.__parent__.__parent__
    pi_api.push.incoming_message_for(inbox.username)
