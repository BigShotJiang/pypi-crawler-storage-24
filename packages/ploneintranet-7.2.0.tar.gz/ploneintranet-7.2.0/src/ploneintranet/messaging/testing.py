from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import MOCK_MAILHOST_FIXTURE
from plone.app.testing import PLONE_FIXTURE
from plone.app.testing import PloneSandboxLayer
from plone.testing import zope as zope_testing
from plone.testing.zope import WSGI_SERVER_FIXTURE
from Products.CMFCore.utils import getToolByName
from zope.configuration import xmlconfig

import unittest


class PloneIntranetmessagingLayer(PloneSandboxLayer):

    defaultBases = (PLONE_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        # Load ZCML
        import ploneintranet.messaging.tests

        xmlconfig.file(
            "configure.zcml",
            ploneintranet.messaging.tests,
            context=configurationContext,
        )

        # Required for pi.userprofile
        zope_testing.installProduct(app, "Products.membrane")

    def setUpPloneSite(self, portal):

        # This is required top install the messaging product without pulling in
        # too many dependencies
        getToolByName(portal, "portal_workflow").setDefaultChain(
            "simple_publication_workflow"
        )
        applyProfile(portal, "ploneintranet.messaging.tests:testing")


PLONEINTRANET_MESSAGING_FIXTURE = PloneIntranetmessagingLayer()
INTEGRATION_TESTING = IntegrationTesting(
    bases=(PLONEINTRANET_MESSAGING_FIXTURE, MOCK_MAILHOST_FIXTURE),
    name="PloneIntranetmessagingLayer:Integration",
)
FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(PLONEINTRANET_MESSAGING_FIXTURE, WSGI_SERVER_FIXTURE),
    name="PloneIntranetmessagingLayer:Functional",
)


class IntegrationTestCase(unittest.TestCase):
    """Base class for integration tests."""

    layer = INTEGRATION_TESTING


class FunctionalTestCase(unittest.TestCase):
    """Base class for functional tests."""

    layer = FUNCTIONAL_TESTING
