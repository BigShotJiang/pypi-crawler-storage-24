from plone import api
from ploneintranet.messaging.testing import IntegrationTestCase
from Products.CMFPlone.utils import get_installer

PROJECTNAME = "ploneintranet.messaging"


class InstallTestCase(IntegrationTestCase):
    def setUp(self):
        self.app = self.layer["app"]
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])

    def test_installed(self):
        self.assertTrue(self.installer.is_product_installed(PROJECTNAME))

    def test_user_actions(self):
        user_actions = self.portal["portal_actions"].user
        self.assertIn("plone_social_menu", user_actions)

    def test_tool_installed(self):
        self.assertIn("ploneintranet_messaging", self.portal)


class UninstallTestCase(IntegrationTestCase):
    def setUp(self):
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])

        with api.env.adopt_roles(["Manager"]):
            self.installer.uninstall_product(PROJECTNAME)

    def test_uninstalled(self):
        self.assertFalse(self.installer.is_product_installed(PROJECTNAME))

    def test_user_actions_removed(self):
        user_actions = self.portal["portal_actions"].user
        self.assertNotIn("plone_social_menu", user_actions)

    def test_tool_removed(self):
        self.assertNotIn("ploneintranet_messaging", self.portal)
