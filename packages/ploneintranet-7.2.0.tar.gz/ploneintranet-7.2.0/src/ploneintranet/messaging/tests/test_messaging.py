from plone import api
from ploneintranet.messaging.testing import IntegrationTestCase
from Products.CMFPlone.utils import get_installer
from zope.component import getUtility
from zope.interface.verify import verifyClass


class TestMessagingLocator(IntegrationTestCase):
    def setUp(self):
        self.portal = self.layer["portal"]
        self.tool = api.portal.get_tool("ploneintranet_messaging")
        self.installer = get_installer(self.portal, self.portal.REQUEST)

    def test_messaginglocator_interface(self):
        from ploneintranet.messaging.interfaces import IMessagingLocator
        from ploneintranet.messaging.messaging import MessagingLocator

        verifyClass(IMessagingLocator, MessagingLocator)

    def test_tool_installed(self):
        from ploneintranet.messaging.tool import MessagingTool

        self.assertIn("ploneintranet_messaging", self.portal)
        self.assertTrue(isinstance(self.tool, MessagingTool))

    def test_tool_removed(self):
        PROJECTNAME = "ploneintranet.messaging"
        with api.env.adopt_roles(["Manager"]):
            self.installer.uninstall_product(PROJECTNAME)
        self.assertNotIn("ploneintranet_messaging", self.portal)

    def test_tool_provides_inboxes(self):
        from ploneintranet.messaging.interfaces import IInboxes

        self.assertTrue(IInboxes.providedBy(self.tool))

    def test_messaginglocator(self):
        from ploneintranet.messaging.interfaces import IMessagingLocator

        self.assertTrue(getUtility(IMessagingLocator))

    def test_messaginglocator_returns_tool(self):
        from ploneintranet.messaging.interfaces import IMessagingLocator
        from ploneintranet.messaging.tool import MessagingTool

        locator = getUtility(IMessagingLocator)
        tool = locator.get_inboxes()
        self.assertTrue(isinstance(tool, MessagingTool))
