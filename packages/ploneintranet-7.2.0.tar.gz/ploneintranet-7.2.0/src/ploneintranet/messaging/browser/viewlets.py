from plone import api
from plone.app.layout.viewlets import common as base
from plone.memoize.view import memoize_contextless
from ploneintranet.layout.app import apps_container_id


class MessagesViewlet(base.ViewletBase):
    """Display unread messages counter in topbar"""

    @property
    @memoize_contextless
    def app_app_url(self):
        portal = api.portal.get()
        apps_container = getattr(portal, apps_container_id)
        return apps_container.messages.app_url()
