from zope.interface import Interface


class IPloneIntranetMessagingLayer(Interface):
    """Marker interface to define ZTK browser layer"""


# BBB
IPloneintranetMessagingLayer = IPloneIntranetMessagingLayer
