from ploneintranet.asynctasks.core import AbstractPost
from unittest import mock

import unittest


class MockAbstractPost(AbstractPost):

    context = mock.Mock(absolute_url=lambda: "http://nohost/foo")

    def __init__(self):
        pass


class TestCore(unittest.TestCase):
    def _mock_requests_post(self, *args, **kwargs):
        return mock.Mock(status_code=200, text="")

    def test_transform_url(self):
        post = MockAbstractPost()

        self.assertEqual(post.transform_url(None), "http://nohost/foo")
        post.url = "http://nohost/bar"
        self.assertEqual(post.transform_url(None), "http://nohost/bar")
        self.assertEqual(post.transform_url("@@bar"), "http://nohost/foo/@@bar")
        self.assertEqual(post.transform_url("/@@bar"), "http://nohost/foo/@@bar")

        with mock.patch(
            "plone.api.portal.get_registry_record",
            return_value={"http://nohost": "http://localhost:8080"},
        ):
            with mock.patch(
                "plone.api.portal.get",
                return_value=mock.Mock(absolute_url=lambda: "http://nohost"),
            ):
                self.assertEqual(
                    post.transform_url("@@bar"), "http://localhost:8080/foo/@@bar"
                )
