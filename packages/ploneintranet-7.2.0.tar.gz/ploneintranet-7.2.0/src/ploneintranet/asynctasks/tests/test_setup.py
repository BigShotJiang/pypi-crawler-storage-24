from plone.browserlayer.utils import registered_layers
from ploneintranet.asynctasks.interfaces import IPloneintranetAsyncLayer
from ploneintranet.asynctasks.testing import IntegrationTestCase
from Products.CMFPlone.utils import get_installer

PROJECTNAME = "ploneintranet.asynctasks"


class TestInstall(IntegrationTestCase):
    def test_product_installed(self):
        """Test if ploneintranet.workspace is installed."""
        self.installer = get_installer(self.portal, self.layer["request"])
        self.assertTrue(self.installer.is_product_installed(PROJECTNAME))

    def test_browserlayer(self):
        self.assertIn(IPloneintranetAsyncLayer, registered_layers())


class TestUnInstall(IntegrationTestCase):
    def setUp(self):
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])
        self.installer.uninstall_product(PROJECTNAME)

    def test_uninstall(self):
        self.assertFalse(self.installer.is_product_installed(PROJECTNAME))

    def test_browserlayer_removed(self):
        self.assertNotIn(IPloneintranetAsyncLayer, registered_layers())
