from distutils.spawn import find_executable
from plone import api
from ploneintranet.asynctasks.celerytasks import add
from ploneintranet.asynctasks.tasks import Post
from ploneintranet.layout.browser.base import BaseStatusView
from Products.Five.browser import BrowserView
from zope.annotation.interfaces import IAnnotations

import logging
import os
import random
import redis.exceptions
import socket
import subprocess
import sys
import time

logger = logging.getLogger(__name__)


class StatusView(BaseStatusView):
    """
    Helper view for portal managers to manually check asynctasks.

    This re-implements rather than re-uses some of the tests
    from test_dispatch, because the port setup for interactive
    testing is likely to be different from the test fixture.
    """

    title = "asynctasks status"

    def all_check_names(self):
        return [
            "check_user",
            "redis_running",
            "celery_running",
            "task_roundtrip",
            "post_roundtrip",
        ]

    def check_user(self):
        if "__ac" in self.request.cookies:
            return self.ok("user", "Logged in as Plone user.")
        elif self.request._auth:
            return self.warn(
                "user", "Logged in as Zope user. Better to do this as a Plone user."
            )
        else:
            self.fail("user", "Cannot extract valid credentials.")

    def redis_running(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        res = sock.connect_ex(("127.0.0.1", 6379))
        sock.close()
        if res == 0:
            return self.ok("redis", "running OK.")
        else:
            return self.fail("redis", "not available")

    def celery_running(self):
        celery = f"{sys.prefix}/bin/celery"
        if not os.path.exists(celery):
            celery = find_executable("celery")
        if not celery:
            celery = "{}/bin/celery".format(
                os.environ["INSTANCE_HOME"].partition("/parts/")[0]
            )

        cmd = f"{celery} -A ploneintranet.asynctasks.celerytasks status"
        try:
            res = subprocess.check_output(cmd.split(" "))
            # drop terminal prompt from output
            res = [line for line in res.strip().split(b"\n") if line][-1]
            return self.ok("celery", res)

        except subprocess.CalledProcessError:
            return self.fail("celery", "no worker available")

    def task_roundtrip(self):
        try:
            result = add.delay(2, 2, 1)
        except redis.exceptions.ConnectionError:
            return self.fail("task", "redis not available")
        if result.ready():
            if result.get() == 4:
                return self.warn("task", "runs sync (output OK).")
            else:
                return self.fail("task", "runs sync (invalid)")
        i = 0
        while i < 5:
            time.sleep(1)
            i += 1
            if result.ready():
                break
        if not result.ready():
            return self.fail("task", "no result after %s seconds" % i)
        else:
            return self.ok("task", "completed asynchronously.")

    def post_roundtrip(self):
        """Verify async task execution via http post"""
        verify_checksum = self.request.get("checksum", None)
        url = "@@async-checktask"
        if not verify_checksum:
            return self._post_initialize(url)
        else:
            return self._post_verify(verify_checksum)

    def _post_initialize(self, url):
        # intial post of async task
        new_checksum = random.random()
        data = dict(checksum=new_checksum)
        try:
            post = Post(self.context, self.request)
            result = post(url, data)
        except redis.exceptions.ConnectionError:
            return self.fail("post", "redis not available")
        msg = "<a class='button' href='?checksum=%s'>verify execution</a>" % (
            new_checksum
        )
        if result.ready():
            return self.warn("post", "SYNC mode! %s" % msg)
        return self.warn("post", "Job queued. %s" % msg)

    def _post_verify(self, verify_checksum):
        # subsequent validation of async result
        got_checksum = get_checksum()
        if verify_checksum == got_checksum:
            return self.ok("post", "execution verified. :-)")
        else:
            msg = f"expected {verify_checksum} but got {got_checksum}"
            return self.fail("post", msg)


class CheckTaskView(BrowserView):
    """
    Helper view to check async http post.

    StatusView delegates a task to this view and then
    checks that it has been executed asynchronously.

    This view sets a (random) checksum as an annotation on the portal
    and is able to get that annotation as well.

    Single-process deadlock is avoided as follows:
    - the annotation setter is delegated to this view via celery (async)
    - the annotation getter is called directly by StatusView (sync)

    You can also call this view directly, which is one of the main
    benefits of the ploneintranet asynctasks framework based on view delegation.
    In that case it will set the checksum if the `checksum` is
    set on the request (e.g. via ?checksum=whatever).
    If that variable is not set, it will return the existing checksum.

    This view bypasses CSRF, which is safe because the write is limited
    to a string annotation only.

    DO NOT BYPASS CSRF FOR ACTUAL BUSINESS OBJECT WRITES like file previews.
    Instead, include a proper authenticator in the POST data.
    """

    def __call__(self):
        """
        set: If `checksum` is set in request, write it to the zodb.
        get: Else return the existing `checksum`.
        """
        checksum = self.request.get("checksum", None)
        if checksum:
            set_checksum(checksum)
            logger.info("Set checksum %s", checksum)
            return "Set checksum %s" % checksum
        else:
            try:
                got_checksum = get_checksum()
                logger.info("Got checksum %s", got_checksum)
                return "Got checksum %s" % got_checksum
            except KeyError:
                logger.warning("No checksum set yet.")
                return "No checksum set yet. " "Create one with ?checksum=foo"


# checksum get/set used by multiple views

KEY = "ploneintranet.asynctasks.status.checksum"


def set_checksum(checksum):
    # no CSRF, be paranoid
    safe_checksum = str(checksum)[:40]
    portal = api.portal.get()
    annotations = IAnnotations(portal)
    annotations[KEY] = safe_checksum


def get_checksum():
    portal = api.portal.get()
    annotations = IAnnotations(portal)
    return annotations[KEY]
