from ploneintranet.attachments.attachments import IAttachmentStorage
from ploneintranet.attachments.interfaces import IAttachmentInfo
from Products.Five.browser import BrowserView
from zope.interface import implementer


@implementer(IAttachmentInfo)
class AttachmentInfo(BrowserView):
    def get_attachment_ids(self):
        return list(IAttachmentStorage(self.context).keys())
