"""Setup/installation tests for this package."""

from plone.browserlayer.utils import registered_layers
from ploneintranet.attachments.interfaces import IPloneintranetAttachmentsLayer
from ploneintranet.attachments.testing import IntegrationTestCase
from Products.CMFPlone.utils import get_installer


class TestInstall(IntegrationTestCase):
    """Test installation of ploneintranet.attachments into Plone."""

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.installer = get_installer(self.portal, self.layer["request"])

    def test_product_installed(self):
        """Test if ploneintranet.attachments is installed with
        portal_quickinstaller."""
        self.assertTrue(
            self.installer.is_product_installed("ploneintranet.attachments")
        )

    def test_uninstall(self):
        """Test if ploneintranet.attachments is cleanly uninstalled."""
        self.installer.uninstall_product("ploneintranet.attachments")
        self.assertFalse(
            self.installer.is_product_installed("ploneintranet.attachments")
        )
        self.assertNotIn(IPloneintranetAttachmentsLayer, registered_layers())

    def test_browserlayer(self):
        """Test that IPloneintranetAttachmentsLayer is registered."""
        self.assertIn(IPloneintranetAttachmentsLayer, registered_layers())
