from plone import api
from plone.app.testing import IntegrationTesting
from ploneintranet import api as pi_api
from ploneintranet.attachments.testing import FIXTURE
from ploneintranet.attachments.testing import PloneintranetAttachmentsLayer
from ploneintranet.testing import dummy_file
from ploneintranet.testing import dummy_image
from unittest import TestCase


class UploadLayer(PloneintranetAttachmentsLayer):

    defaultBases = (FIXTURE,)

    def setUpPloneSite(self, portal):
        """Set up Plone testing content."""
        # Docconv: will generate previews for this
        api.content.create(
            container=portal,
            type="File",
            id="test-file",
            file=dummy_file(filename="test.pdf"),
            safe_id=True,
        )
        # This will be skipped by docconv: no need for preview generation
        api.content.create(
            container=portal,
            type="Image",
            id="test-image",
            image=dummy_image(),
            safe_id=True,
        )
        # We also need a file that contains an image :)
        # This will be also skipped by docconv
        api.content.create(
            container=portal,
            type="File",
            id="test-image-file",
            file=dummy_image(),
            safe_id=True,
        )
        # We finally try with an empty file
        # This will be also skipped by docconv
        api.content.create(container=portal, type="File", id="test-empty", safe_id=True)


UPLOAD_FIXTURE = UploadLayer()
UPLOAD_LAYER = IntegrationTesting(
    bases=(UPLOAD_FIXTURE,), name="PloneintranetAttachmentsUploadLayer:Integration"
)


class TestUpload(TestCase):
    """Test that the upload view is functional"""

    layer = UPLOAD_LAYER

    def setUp(self):
        """define some helper variables here"""
        self.portal = self.layer["portal"]
        self.request = self.layer["request"].clone()

    def get_view(self):
        return api.content.get_view("upload-attachments", self.portal, self.request)

    def test_get_thumbs_urls_pdf(self):
        """Given an attachment we should have the urls to see its thumbnails"""
        # Test objects that have a generated preview
        obj = self.portal["test-file"]
        urls = self.get_view().get_thumbs_urls(obj)
        self.assertIn("/test-file/svg", urls[0])

    def test_get_thumbs_urls_image(self):
        # Test image previews
        obj = self.portal["test-image"]
        urls = self.get_view().get_thumbs_urls(obj)
        self.assertTrue(len(urls) == 1)
        self.assertIn("@@images", urls[0])

    def test_get_thumbs_urls_file(self):
        # Test a File instance that contains an image
        obj = self.portal["test-image-file"]
        urls = self.get_view().get_thumbs_urls(obj)
        self.assertTrue(len(urls) == 1)
        self.assertIn("test-image-file/svg", urls[0])

    def test_get_thumbs_urls_empty(self):
        view = self.get_view()
        obj = self.portal["test-empty"]
        self.assertListEqual(view.get_thumbs_urls(obj), view.fallback_thumbs_urls)

    def test_get_thumbs_urls_portal(self):
        # Test objects that have no preview
        view = self.get_view()
        self.assertListEqual(
            view.get_thumbs_urls(self.portal), view.fallback_thumbs_urls
        )

    def test_previews_url_traversable_pdf(self):
        """In the previous test we returned a URL similar to this:
         - http://nohost/plone/@@dvpdfview/1/f/1fe3402718445/normal/dump_1.gif
        in the case of a c.dv generated URL

        This test will protect the method that generates the urls
        from changes in the ploneintranet api module
        """
        obj = self.portal["test-file"]
        request = self.request.clone()
        request["page"] = 1
        num_pages = pi_api.previews.num_pages(obj)
        self.assertTrue(num_pages > 0)
        previews = pi_api.previews.get_preview_urls(obj)
        self.assertTrue(len(previews) >= 1)
