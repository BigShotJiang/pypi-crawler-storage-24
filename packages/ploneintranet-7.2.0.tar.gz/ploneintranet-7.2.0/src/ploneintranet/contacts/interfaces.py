from ploneintranet.layout.interfaces import IApplicationLabel
from zope.interface import Interface


class IContactsContainer(IApplicationLabel):
    """Marker interface for the contacts container"""


class IImportantContact(Interface):
    """Marker Interface to state if an object is pinned"""
