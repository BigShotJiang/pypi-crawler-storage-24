from plone import api
from plone.app.testing import applyProfile
from plone.app.testing import IntegrationTesting
from plone.app.testing import PloneSandboxLayer
from ploneintranet.contacts.browser.interfaces import IPloneintranetContactsLayer
from ploneintranet.search.interfaces import IPloneintranetSearchLayer
from ploneintranet.search.solr.interfaces import IMaintenance
from ploneintranet.search.solr.testing import load_solr_zcml
from ploneintranet.search.solr.testing import SOLR_FIXTURE
from ploneintranet.userprofile.testing import PLONEINTRANET_USERPROFILE_FIXTURE
from Products.CMFCore.indexing import processQueue
from zope.component import getUtility
from zope.interface import alsoProvides


class PloneIntranetContactsLayer(PloneSandboxLayer):

    defaultBases = (SOLR_FIXTURE, PLONEINTRANET_USERPROFILE_FIXTURE)

    def setUpZope(self, app, configurationContext):
        import ploneintranet.search.solr

        self.loadZCML(package=ploneintranet.search.solr)
        load_solr_zcml()
        import ploneintranet.contacts

        self.loadZCML("configure.zcml", package=ploneintranet.contacts)

    def setUpPloneSite(self, portal):
        applyProfile(portal, "ploneintranet.contacts:default")

        # Enable all user and groups we just imported
        container = portal.profiles
        api.content.create(
            type="ploneintranet.userprofile.userprofile",
            container=container,
            title="John Doe",
            first_name="John",
            last_name="Doe",
            username="john-doe",
            email="john-doe@example.com",
        )
        api.content.create(
            type="ploneintranet.userprofile.userprofile",
            container=container,
            title="Jane Doe",
            first_name="Jane",
            last_name="Doe",
            username="jane-doe",
            email="jane-doe@example.com",
        )
        api.content.create(
            type="ploneintranet.userprofile.userprofile",
            container=container,
            title="John Smith",
            first_name="John",
            last_name="Smith",
            username="john-smith",
            email="john-smith@example.com",
        )
        api.content.create(
            type="ploneintranet.userprofile.userprofile",
            container=container,
            title="Maria Rossi",
            first_name="Maria",
            last_name="Rossi",
            username="maria-rossi",
            email="maria-rossi@example.com",
        )

        for idx, (userid, to_state) in enumerate(
            zip(
                ("jane-doe", "john-doe", "maria-rossi"),
                ("enabled", "enabled", "disabled"),
            )
        ):
            obj = container[userid]
            api.content.transition(obj, to_state=to_state)
            obj.reindexObject(idxs=["review_state"])

        group_container = portal.groups
        api.content.create(
            type="ploneintranet.userprofile.workgroup",
            container=group_container,
            title="HR",
            canonical="hr",
            members=["john-doe"],
        )
        api.content.create(
            type="ploneintranet.userprofile.workgroup",
            container=group_container,
            title="Production",
            canonical="production",
            members=["jane-doe"],
        )

        request = portal.REQUEST
        alsoProvides(request, IPloneintranetContactsLayer)
        alsoProvides(request, IPloneintranetSearchLayer)
        processQueue()
        view = api.content.get_view("solr-maintenance", portal, request)
        view.sync(close_connection=True)
        SOLR_FIXTURE._solr_snapshot()

    def purge_solr(self):
        getUtility(IMaintenance).purge()

    def testTearDown(self):
        self.purge_solr()


PLONEINTRANET_CONTACTS_FIXTURE = PloneIntranetContactsLayer()
PLONEINTRANET_CONTACTS_INTEGRATION_TESTING = IntegrationTesting(
    bases=(PLONEINTRANET_CONTACTS_FIXTURE,), name="PloneIntranetContacts:Integration"
)
