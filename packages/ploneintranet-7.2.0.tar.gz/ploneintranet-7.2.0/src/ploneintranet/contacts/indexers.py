from .content.contact import IContact
from plone.indexer import indexer


@indexer(IContact)
def friendly_type_name(obj):
    if obj.contact_type == "emergency-service":
        return "Emergency Service"
    else:
        return "Contact"
