from plone import api
from plone.app.testing.helpers import login
from plone.app.testing.interfaces import SITE_OWNER_NAME
from ploneintranet.contacts.content.contact import IEmergencyServiceMarker
from ploneintranet.contacts.testing import PLONEINTRANET_CONTACTS_INTEGRATION_TESTING
from ploneintranet.search.solr.testing import SOLR_FIXTURE
from zope.interface import alsoProvides

import unittest


class ContactTestCase(unittest.TestCase):
    """Test the contact content type"""

    layer = PLONEINTRANET_CONTACTS_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer["portal"]
        self.contacts = self.portal.contacts
        self.request = self.portal.REQUEST.clone()
        SOLR_FIXTURE._solr_restore()
        login(self.layer["app"], SITE_OWNER_NAME)

    def test_fields(self):
        # Fun fact: Can't pass `function` to create() because the argument name is used
        # by its decorators
        contact = api.content.create(
            container=self.contacts,
            type="ploneintranet.contacts.contact",
            id="anezka-nemcekova",
        )
        fields = dict(
            first_name="Anežka",
            last_name="Nemčeková",
            company="FakeTech Inc.",
            function="Technical Support",
            telephone="555 12345",
            mobile="07505 12345",
            email="nemcekova@faketech.com",
            website="http://www.faketech.com/",
            address="4 Dead End Street\nEdinburgh\nEH17 8UM",
        )
        for field, value in fields.items():
            setattr(contact, field, value)

        self.assertEqual(contact.Title(), "Anežka Nemčeková")
        self.assertEqual(contact.Description(), "Technical Support")

    def test_fullname_emergency_service(self):
        contact = api.content.create(
            container=self.contacts,
            type="ploneintranet.contacts.contact",
            id="fire-department",
        )
        contact.name = "Fire department"
        contact.telephone = "999"
        alsoProvides(contact, IEmergencyServiceMarker)
        self.assertEqual(contact.fullname, "Fire department")

    def test_fullname_contact_person(self):
        contact = api.content.create(
            container=self.contacts,
            type="ploneintranet.contacts.contact",
            id="siobhan-o-malley",
        )
        contact.first_name = "Siobhan"
        contact.last_name = "O'Malley"
        contact.company = "Human Touch"
        contact.telephone = "555 98765"
        self.assertEqual(contact.fullname, "Siobhan O'Malley")

    def test_fullname_contact_company(self):
        contact = api.content.create(
            container=self.contacts,
            type="ploneintranet.contacts.contact",
            id="human-touch",
        )
        contact.company = "Human Touch"
        contact.telephone = "555 9800"
        self.assertEqual(contact.fullname, "Human Touch")


class ContactsAppTestCase(unittest.TestCase):
    """Test the contact views"""

    layer = PLONEINTRANET_CONTACTS_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer["portal"]
        self.contacts = self.portal.contacts
        self._request = self.portal.REQUEST.clone()
        self.request = self.portal.REQUEST
        SOLR_FIXTURE._solr_restore()
        login(self.layer["app"], SITE_OWNER_NAME)
        self.contact = api.content.create(
            container=self.contacts,
            type="ploneintranet.contacts.contact",
            id="syslab-com",
            company="Syslab.com",
        )

    def tearDown(self):
        self.portal.REQUEST = self._request

    def get_view(self, name=None, context=None, request=None):
        if not name:
            name = "app-contacts"
        if not context:
            context = self.portal.apps.contacts
        if not request:
            request = self.request
        return api.content.get_view(name=name, context=context, request=request)

    def test_create_contact_company(self):
        self.request.form = {
            "portal_type": "ploneintranet.contacts.contact",
            "contact_type": "company",
            "organisation": "on",
            "company": "Öztek Industries",
            "telephone": "555 1200",
            "email": "info@oztek.net",
            "website": "https://www.oztek.net/",
            "form.buttons.create": "Create",
        }
        self.request.method = "POST"
        create_view = self.get_view(name="panel-create-group", request=self.request)
        create_view()

        self.assertIn("oztek-industries", self.contacts)
        obj = self.contacts.get("oztek-industries")
        self.assertEqual(obj.company, "Öztek Industries")
        self.assertEqual(obj.telephone, "555 1200")
        self.assertEqual(obj.email, "info@oztek.net")
        self.assertEqual(obj.website, "https://www.oztek.net/")

    def test_create_contact_person(self):
        self.request.form = {
            "portal_type": "ploneintranet.contacts.contact",
            "contact_type": "person",
            "first_name": "Thomas",
            "last_name": "Schleier",
            "company": "Öztek Industries",
            "telephone": "555 12345",
            "email": "schleier@oztek.net",
            "form.buttons.create": "Create",
        }
        self.request.method = "POST"
        create_view = self.get_view(name="panel-create-group", request=self.request)
        create_view()

        self.assertIn("thomas-schleier", self.contacts)
        obj = self.contacts.get("thomas-schleier")
        self.assertEqual(obj.first_name, "Thomas")
        self.assertEqual(obj.last_name, "Schleier")
        self.assertEqual(obj.company, "Öztek Industries")
        self.assertEqual(obj.telephone, "555 12345")
        self.assertEqual(obj.email, "schleier@oztek.net")

    def test_create_emergency_service(self):
        self.request.form = {
            "portal_type": "ploneintranet.contacts.contact",
            "contact_type": "emergency-service",
            "name": "Rettungsleitstelle Zivil",
            "telephone": "00-112",
            "mobile": "112",
            "building": "Wache 1589",
            "form.buttons.create": "Create",
        }
        self.request.method = "POST"
        create_view = self.get_view(name="panel-create-group", request=self.request)
        create_view()
        self.assertIn("rettungsleitstelle-zivil", self.contacts)
        obj = self.contacts.get("rettungsleitstelle-zivil")
        self.assertEqual(obj.name, "Rettungsleitstelle Zivil")
        self.assertEqual(obj.telephone, "00-112")
        self.assertEqual(obj.mobile, "112")
        self.assertEqual(obj.building, "Wache 1589")
        self.assertEqual(obj.contact_type, "emergency-service")

    def test_create_invalid(self):
        self.request.form = {
            "portal_type": "Document",
            "name": "Meeting Minutes",
            "form.buttons.create": "Create",
        }
        self.request.method = "POST"
        create_view = self.get_view(name="panel-create-group", request=self.request)
        create_view()
        self.assertListEqual(
            self.contacts.objectIds(),
            [
                "syslab-com",
            ],
        )
