from plone.app.dexterity.textindexer.directives import searchable
from plone.autoform.interfaces import IFormFieldProvider
from plone.dexterity.content import Container
from plone.supermodel import model
from ploneintranet import schema as pischema
from ploneintranet.contacts.interfaces import IImportantContact
from ploneintranet.core import _
from zope import schema
from zope.component import adapter
from zope.interface import alsoProvides
from zope.interface import implementer
from zope.interface import Interface
from zope.interface import noLongerProvides
from zope.interface import provider


class IContact(model.Schema):
    searchable("first_name")
    first_name = schema.TextLine(title=_("First name"), required=False, default="")

    searchable("last_name")
    last_name = schema.TextLine(title=_("Last name"), required=False, default="")

    searchable("company")
    company = schema.TextLine(title=_("Company"), required=False, default="")

    searchable("function")
    function = schema.TextLine(title=_("Function"), required=False, default="")

    searchable("telephone")
    telephone = pischema.Telephone(
        title=_("Telephone Number"), required=False, default=""
    )

    searchable("mobile")
    mobile = pischema.Telephone(title=_("Mobile Number"), required=False, default="")

    searchable("email")
    email = pischema.PIEmail(title=_("Email"), required=False, default="")

    searchable("website")
    website = schema.TextLine(title=_("Website"), required=False, default="")

    searchable("address")
    address = schema.Text(title=_("Address"), required=False, default="")


class IEmergencyServiceMarker(Interface):
    """Marker interface for emergency services."""


@provider(IFormFieldProvider)
class IEmergencyService(model.Schema):
    searchable("name")
    name = schema.TextLine(title=_("Name"), required=False, default="")

    searchable("description")
    description = schema.Text(title=_("Description"), required=False, default="")

    searchable("phone_internal")
    phone_internal = pischema.Telephone(
        title=_("Internal Telephone Number"), required=False, default=""
    )
    building = schema.TextLine(title=_("Building"), required=False, default="")
    service_icon = schema.Text(title=_("Icon"), required=False, default="icon-bell-alt")
    notes = schema.Text(title=_("Notes"), required=False, default="")


@implementer(IContact)
class Contact(Container):
    """Contact content type."""

    def Title(self):
        return self.fullname

    def Description(self):
        return getattr(self, "description", None) or getattr(self, "function", None)

    @property
    def contact_type(self):
        if IEmergencyServiceMarker.providedBy(self):
            return "emergency-service"
        elif getattr(self, "first_name", "") or getattr(self, "last_name", ""):
            return "person"
        elif getattr(self, "company", None):
            return "organisation"
        else:
            return "unknown"

    @property
    def fullname(self):
        """Name for an emergency service, first/last name for a person contact, company
        for a company contact."""
        if self.contact_type == "emergency-service":
            return self.name
        elif self.contact_type == "person":
            names = [self.first_name, self.last_name]
            person_name = " ".join([name for name in names if name])
            return person_name
        elif self.contact_type == "organisation":
            return self.company

    @property
    def initials(self):
        if self.contact_type == "person":
            first_name = self.first_name or ""
            last_name = self.last_name or ""
            return first_name[:1].upper() + last_name[:2].capitalize()
        else:
            return ""


@provider(IFormFieldProvider)
class IImportantContactBehavior(model.Schema):
    """Behavior for pinning content."""

    important_contact = schema.Bool(
        title=_("label_important_contact", default="Important Contact"),
        description=_(
            "description_important_contact",
            default="Include in contacts portlet on dashboard.",
        ),
        required=False,
        default=False,
    )


@implementer(IImportantContactBehavior)
@adapter(IContact)
class ImportantContactBehavior:
    def __init__(self, context):
        self.context = context

    @property
    def important_contact(self):
        return IImportantContact.providedBy(self.context)

    @important_contact.setter
    def important_contact(self, value):
        if value is True:
            alsoProvides(self.context, IImportantContact)
        else:
            noLongerProvides(self.context, IImportantContact)
