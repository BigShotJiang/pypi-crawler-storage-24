from plone import api
from plone.memoize import forever
from plone.memoize.view import memoize_contextless
from ploneintranet.contacts.content.contact import IImportantContactBehavior
from ploneintranet.workspace.basecontent.baseviews import ContentView
from zope.schema.vocabulary import getVocabularyRegistry


class View(ContentView):
    """The view that displays a contact."""

    @property
    @memoize_contextless
    def app(self):
        return api.portal.get().apps["contacts"]

    def css_class(self):
        if self.context.contact_type == "emergency-service":
            return f"icon-{self.context.service_icon} contact-info-icon"
        else:
            return "pat-avatar user-info-avatar"

    @property
    @forever.memoize
    def service_icons(self):
        """Return the ploneintranet.layout.manyicons vocabulary"""
        vr = getVocabularyRegistry()
        return vr.get(self.context, "ploneintranet.layout.manyicons")

    @property
    def important_contact(self):
        return IImportantContactBehavior(self.context).important_contact
