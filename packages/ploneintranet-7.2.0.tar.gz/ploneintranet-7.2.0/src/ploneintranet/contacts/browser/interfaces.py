from zope.interface import Interface


class IPloneintranetContactsLayer(Interface):
    """Marker interface to define ZTK browser layer"""
