from ploneintranet.core import _
from zope import schema
from zope.interface import Interface
from zope.schema.vocabulary import SimpleTerm
from zope.schema.vocabulary import SimpleVocabulary


class IStripeSettings(Interface):
    """Global settings for stripe stored in the registry"""

    mode = schema.Choice(
        title=_("Mode"),
        description=_(
            "Determines whether the stripe payments are enabled "
            "and if we are using the live or the test shop. "
            "Requires the stripe package to be available in your buildout."
        ),
        vocabulary=SimpleVocabulary(
            (
                SimpleTerm(value="", title=_("Off")),
                SimpleTerm(value="live", title=_("Live mode)")),
                SimpleTerm(value="test", title=_("Test mode")),
            )
        ),
        default="",
    )
    test_secret_key = schema.TextLine(
        title=_("Test Secret Key"),
        description=_(
            "Located under Account Settings -> API Keys when logged into stripe.com"
        ),
    )
    test_publishable_key = schema.TextLine(
        title=_("Test Publishable Key"),
        description=_(
            "Located under Account Settings -> API Keys when logged into stripe.com"
        ),
    )
    test_product_id = schema.TextLine(title=_("The id of the product used for tests"))
    live_secret_key = schema.TextLine(
        title=_("Live Secret Key"),
        description=_(
            "Located under Account Settings -> API Keys when logged into stripe.com"
        ),
    )
    live_publishable_key = schema.TextLine(
        title=_("Live Publishable Key"),
        description=_(
            "Located under Account Settings -> API Keys when logged into stripe.com"
        ),
    )
    live_product_id = schema.TextLine(title=_("Live product id"))
