from plone import api
from ploneintranet.admintool.testing import IntegrationTestCase


class TestViews(IntegrationTestCase):
    """Test installation of this  product into Plone."""

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]

    def test_intid_check(self):
        """"""
        view = api.content.get_view("pi-intids", self.portal, self.request.clone())

        # Everything is good at the beginning
        self.assertListEqual(view.keys_with_a_broken_path, [])
        self.assertListEqual(view.refs_with_a_broken_path, [])

        # Now we break one object
        obj = self.portal.profiles
        intid = view.intids.getId(obj)
        view.intids.refs[intid].path = "/plone/broken"
        self.assertListEqual(view.keys_with_a_broken_path, [])
        self.assertListEqual(view.refs_with_a_broken_path, [view.intids.refs[intid]])
        view.check()

        # We see that calling check will report the user what needs to be fixed
        self.assertIn(b"UserProfileContainer at profiles", view.request.response.body)

        # Now we see that the view fixes it
        view.fix()
        self.assertIn(
            b"Fixed ref <UserProfileContainer at profiles>", view.request.response.body
        )
        self.assertListEqual(view.keys_with_a_broken_path, [])
        self.assertListEqual(view.refs_with_a_broken_path, [])
