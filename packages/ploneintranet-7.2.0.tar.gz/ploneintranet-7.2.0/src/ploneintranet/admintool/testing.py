"""Base module for unittesting."""

from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import MOCK_MAILHOST_FIXTURE
from plone.app.testing import PloneSandboxLayer
from ploneintranet.userprofile.testing import PLONEINTRANET_USERPROFILE_FIXTURE

import unittest


class PloneintranetAdmintoolLayer(PloneSandboxLayer):

    defaultBases = (PLONEINTRANET_USERPROFILE_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        """Set up Zope."""
        import ploneintranet.admintool

        self.loadZCML(package=ploneintranet.admintool)

    def setUpPloneSite(self, portal):
        """Set up Plone."""
        # Install into Plone site using portal_setup
        applyProfile(portal, "ploneintranet.admintool:default")


FIXTURE = PloneintranetAdmintoolLayer()
INTEGRATION_TESTING = IntegrationTesting(
    bases=(FIXTURE, MOCK_MAILHOST_FIXTURE),
    name="PloneintranetAdmintoolLayer:Integration",
)
FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(FIXTURE, MOCK_MAILHOST_FIXTURE),
    name="PloneintranetAdmintoolLayer:Functional",
)


class IntegrationTestCase(unittest.TestCase):
    """Base class for integration tests."""

    layer = INTEGRATION_TESTING


class FunctionalTestCase(unittest.TestCase):
    """Base class for functional tests."""

    layer = FUNCTIONAL_TESTING
