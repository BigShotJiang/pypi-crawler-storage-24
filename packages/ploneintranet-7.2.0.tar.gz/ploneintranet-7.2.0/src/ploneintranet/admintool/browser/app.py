from plone import api
from plone.memoize.view import memoize_contextless
from ploneintranet.core import _
from ploneintranet.layout.interfaces import IAppView
from Products.Five import BrowserView
from zope.interface import implementer


@implementer(IAppView)
class View(BrowserView):
    """The view for this app"""

    app_name = "administrator-tool"
    title = _("label_title_app_administrator_tool", default="Administrator tool")

    @property
    def profiles(self):
        """The profiles folder"""
        return api.portal.get().profiles

    @property
    @memoize_contextless
    def navigation_tabs(self):
        """Navigation tabs"""
        tabs = [
            "Requests worklist",
            "Workspace management",
            "User management",
            "Group management",
        ]
        # TODO: there is only one tab for the moment but more have been designed
        tabs = []
        return tabs
