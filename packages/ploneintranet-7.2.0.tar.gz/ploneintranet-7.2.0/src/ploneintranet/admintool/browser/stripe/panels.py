from plone.base.interfaces import IMailSchema
from plone.memoize.view import memoize_contextless
from plone.registry.interfaces import IRegistry
from Products.Five import BrowserView
from zope.component import getUtility


class StripePanel(BrowserView):
    """Simple class that says: I am a modal panel"""

    is_modal_panel = True

    @property
    @memoize_contextless
    def mail_settings(self):
        """Get the mail related registry records"""
        registry = getUtility(IRegistry)
        return registry.forInterface(IMailSchema, prefix="plone")
