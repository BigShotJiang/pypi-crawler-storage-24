from logging import getLogger
from plone import api

logger = getLogger()


def create_app():
    """Create the administrator tool application"""
    portal = api.portal.get()
    apps = portal.apps
    if "administrator-tool" not in apps:
        api.content.create(
            container=apps,
            type="ploneintranet.layout.app",
            title="Administrator Tool",
            id="administrator-tool",
            safe_id=False,
            app="@@app-administrator-tool",
            devices="desktop tablet",
        )


def post_default(context):
    """Actions needed after importing
    the ploneintranet.admintool:default profile
    """
    create_app()
