from plone import api
from plone.app.testing import applyProfile
from plone.app.testing import IntegrationTesting
from plone.app.testing import PloneSandboxLayer
from ploneintranet import api as pi_api
from ploneintranet.userprofile.testing import PLONEINTRANET_USERPROFILE_FIXTURE


class PloneIntranetConferenceLayer(PloneSandboxLayer):

    defaultBases = (PLONEINTRANET_USERPROFILE_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        import ploneintranet.conference

        self.loadZCML("configure.zcml", package=ploneintranet.conference)

    def setUpPloneSite(self, portal):
        applyProfile(portal, "ploneintranet.search:default")
        applyProfile(portal, "ploneintranet.conference:default")

        pi_api.userprofile.create(
            username="john-doe",
            email="johndoe@example.com",
            properties={"first_name": "John", "last_name": "Doe"},
            approve=True,
        )
        api.content.create(
            container=portal,
            type="ploneintranet.conference.talk",
            id="talk1",
            title="Talk 1",
            location="test location",
        )


PLONEINTRANET_CONFERENCE_FIXTURE = PloneIntranetConferenceLayer()
PLONEINTRANET_CONFERENCE_INTEGRATION_TESTING = IntegrationTesting(
    bases=(PLONEINTRANET_CONFERENCE_FIXTURE,), name="PloneIntranetContacts:Integration"
)
