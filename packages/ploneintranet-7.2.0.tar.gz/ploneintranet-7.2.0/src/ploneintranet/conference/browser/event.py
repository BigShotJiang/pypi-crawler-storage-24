from ploneintranet.workspace.basecontent import event


class EventView(event.EventView):
    def __call__(self, *args, **kwargs):
        # Set scheduler for this view to edit mode, if can edit.
        self.request["mode-edit"] = self.can_edit
        return super().__call__(*args, **kwargs)
