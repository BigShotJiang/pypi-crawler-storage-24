from ploneintranet.core import _
from ploneintranet.workspace.browser.add_content import AddBase
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile


class AddTalk(AddBase):

    template = ViewPageTemplateFile("templates/add_talk.pt")
    title = _("Create a conference talk event")
