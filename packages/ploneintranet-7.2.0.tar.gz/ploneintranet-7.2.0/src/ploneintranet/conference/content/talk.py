from plone.app.event import _ as __
from plone.app.event.dx.behaviors import default_end
from plone.app.event.dx.behaviors import default_start
from plone.app.event.dx.behaviors import default_timezone
from plone.app.event.dx.behaviors import StartBeforeEnd
from plone.app.z3cform.widget import DatetimeFieldWidget
from plone.autoform import directives
from plone.dexterity.content import Container
from plone.supermodel import model
from ploneintranet.core import _
from zope import schema
from zope.interface import implementer
from zope.interface import invariant


class ITalk(model.Schema):
    """A talk content type"""

    start = schema.Datetime(
        title=__("label_event_start", default="Event Starts"),
        description=__(
            "help_event_start", default="Date and Time, when the event begins."
        ),
        required=True,
        defaultFactory=default_start,
    )
    directives.widget(
        "start",
        DatetimeFieldWidget,
        default_timezone=default_timezone,
        klass="event_start",
    )

    end = schema.Datetime(
        title=__("label_event_end", default="Event Ends"),
        description=__("help_event_end", default="Date and Time, when the event ends."),
        required=True,
        defaultFactory=default_end,
    )
    directives.widget(
        "end",
        DatetimeFieldWidget,
        default_timezone=default_timezone,
        klass="event_end",
    )

    @invariant
    def validate_start_end(data):
        if data.start and data.end and data.start > data.end:
            raise StartBeforeEnd(
                __(
                    "error_end_must_be_after_start_date",
                    default="End date must be after start date.",
                )
            )

    location = schema.Choice(
        title=_("Space"),
        source="ploneintranet.conference.vocabulary.spaces",
        required=True,
    )


@implementer(ITalk)
class Talk(Container):
    """The talk content type"""
