from plone.indexer import indexer
from ploneintranet.conference.content.talk import ITalk


@indexer(ITalk)
def location_indexer(obj):
    return obj.location
