from plone import api
from ploneintranet import api as pi_api
from ploneintranet.conference.testing import (
    PLONEINTRANET_CONFERENCE_INTEGRATION_TESTING,
)
from ploneintranet.search.interfaces import ISiteSearch
from zope.component import getUtility

import unittest


class TestConference(unittest.TestCase):

    layer = PLONEINTRANET_CONFERENCE_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer["portal"]
        self.request = self.layer["request"]

    def _get_maybe_attend_view(self):
        view = api.content.get_view(
            "maybe_attend", self.portal.talk1, self.request.clone()
        )
        view.request.method = "POST"
        return view

    def test_talk_fti(self):
        self.assertEqual(
            self.portal.portal_types["ploneintranet.conference.talk"].Title(), "Talk"
        )

    @pi_api.events.notifications_disabled
    def test_voting_view_tasks(self):
        view = api.content.get_view("voting", self.portal, self.request.clone())

        # Check our contents
        self.assertListEqual(view.talks, [self.portal.talk1])

        # Check after removing
        api.content.delete(self.portal.talk1)
        self.assertListEqual(view.talks, [])

    def test_voting_view_userid(self):
        view = api.content.get_view("voting", self.portal, self.request.clone())
        self.assertEqual(view.userid, "")
        view.request.__annotations__.clear()
        with api.env.adopt_user("john-doe"):
            self.assertEqual(view.userid, "john-doe")

    def test_maybe_attend_yes(self):
        talk1 = self.portal.talk1
        view = self._get_maybe_attend_view()
        view.request.form["attend"] = "1"
        self.assertTupleEqual(talk1.attendees, ())

        with api.env.adopt_user("john-doe"):
            view()
        self.assertTupleEqual(talk1.attendees, ("john-doe",))

        talk1.attendees = ("jane-doe",)
        view.request.__annotations__.clear()
        with api.env.adopt_user("john-doe"):
            view()
        self.assertTupleEqual(talk1.attendees, ("jane-doe", "john-doe"))

        talk1.attendees = ("jane-doe", "john-doe", "foo")
        view.request.__annotations__.clear()
        with api.env.adopt_user("john-doe"):
            view()
        self.assertTupleEqual(talk1.attendees, ("jane-doe", "john-doe", "foo"))

    def test_maybe_attend_no(self):
        talk1 = self.portal.talk1
        talk1.attendees = ("jane-doe", "john-doe", "foo")
        view = self._get_maybe_attend_view()

        with api.env.adopt_user("john-doe"):
            view()
        self.assertTupleEqual(talk1.attendees, ("jane-doe", "foo"))

        talk1.attendees = ("john-doe",)
        view.request.__annotations__.clear()
        with api.env.adopt_user("john-doe"):
            view()
        self.assertTupleEqual(talk1.attendees, ())

    def test_location_metadata_index(self):
        """Test correct indexing of metadata column "location" for ITalk objects"""
        cat = self.portal.portal_catalog
        ret = cat(portal_type="ploneintranet.conference.talk")
        self.assertTrue(len(ret) > 0)
        self.assertEqual(ret[0].location, "test location")

        query = {"portal_type": "ploneintranet.conference.talk"}
        search_util = getUtility(ISiteSearch)
        ret = list(search_util.query(filters=query))
        self.assertTrue(len(ret) > 0)
        # The following does not work yet. To be investigated
        # self.assertEqual(ret[0].location, "test location")
