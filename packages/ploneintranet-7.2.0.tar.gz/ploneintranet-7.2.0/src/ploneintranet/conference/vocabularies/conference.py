from plone.app.vocabularies.terms import safe_simplevocabulary_from_values
from zope.interface import implementer
from zope.schema.interfaces import IVocabularyFactory


@implementer(IVocabularyFactory)
class SpacesValueVocabulary:
    def __call__(self, context):
        values = []
        try:
            # TODO: now a rooms attribute in the parent is expected,
            # that should be done in a more friendly way
            values = context.rooms.splitlines()
        except AttributeError:
            values = ["Default"]
        return safe_simplevocabulary_from_values(values)


SpacesVocabularyFactory = SpacesValueVocabulary()
