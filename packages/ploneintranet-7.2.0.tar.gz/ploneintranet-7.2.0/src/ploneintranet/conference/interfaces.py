from plone.event.interfaces import IEvent


class IConference(IEvent):
    """Marker interface for events which should act as a conference."""
