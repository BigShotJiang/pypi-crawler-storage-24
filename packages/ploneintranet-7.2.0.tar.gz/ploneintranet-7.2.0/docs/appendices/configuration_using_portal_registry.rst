.. _configuration_using_portal_registry.rst:

===================================
Configuration using portal_registry
===================================

Plone intranet can be controlled by modifying the portal_registry.

The following registry records have been configured through
the ploneintranet packages.


ploneintranet.asynctasks
------------------------

ploneintranet.asynctasks.portal_url_replacement_mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Replace the portal URL with another string in asynchronous requests

    **type**: plone.registry.field.Dict {plone.registry.field.TextLine: plone.registry.field.TextLine}

    **description**: This is useful if you do not want to pass through the publication stack. If your site is published as https://example.com you might want the request to be sent to http://127.0.0.1:$PORT/VirtualHostBase/https/example.com:443/$SITE_ID/VirtualHostRoot.

    **default**: {}


ploneintranet.bookmarks
-----------------------

ploneintranet.bookmarks.unbookmarkable_types
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: List of content types that cannot be bookmarked

    **type**: plone.registry.field.Tuple composed of plone.registry.field.TextLine

    **default**: ploneintranet.workspace.superspace


ploneintranet.layout
--------------------

ploneintranet.layout.splashpage_enabled
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Turn on the display of a first time splash page

    **description**: If the user logs in for the first time, he will see a splash page overlay which can contain introductory information stored in splashpage_content.

    **type**: plone.registry.field.Bool

    **default**: False

ploneintranet.layout.splashpage_uid
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Configure a unique identifier for the splash page

    **description**: This UID is used to store the information in the user's browser if the splashpage has been shown already. If you want to make the splashpage reappear for all users, change the UID.

    **type**: plone.registry.field.TextLine

    **default**: ''

ploneintranet.layout.splashpage_content
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Content of the splashpage

    **description**: This is the complete html markup used to render the splashpage.

    **type**: plone.registry.field.Text

    **default**: ''


ploneintranet.layout.dashboard_activity_tiles
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: List of dashboard activity tiles

    **description**: This is the list of the tiles the user will see on the "Activity centric view" dashboard.

    **type**: plone.registry.field.Tuple composed of plone.registry.field.TextLine

    **default**: ./@@contacts_search.tile,
                 ./@@bookmarks.tile?id_suffix=-dashboard
                 ./@@news.tile,
                 ./@@my_documents.tile

ploneintranet.layout.dashboard_task_tiles
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: List of dashboard activity tiles

    **description**: This is the list of the tiles the user will see on the "Task centric view" dashboard.

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**: ./@@contacts_search.tile,
                 ./@@news.tile,
                 ./@@my_documents.tile,
                 ./@@workspaces.tile?workspace_type=ploneintranet.workspace.workspacefolder,
                 ./@@workspaces.tile?workspace_type=ploneintranet.workspace.case,
                 ./@@events.tile,
                 ./@@tasks.tile,

ploneintranet.layout.dashboard_custom_tiles
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: List of dashboard custom tiles

    **description**: This is the list of the tiles the user will see on the "My view (customizable)" dashboard.

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**: './@@contacts_search.tile?title=Contacts',
                 './@@news.tile?title=News',
                 './@@my_documents.tile?title=My docs',

ploneintranet.layout.dashboard_default
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Name of the default dashboard

    **description**: This is the name of the dashboard type that should be shown by default. Pick the values from the dropdown on the dashboard.

    **type**: plone.registry.field.TextLine

    **default**: activity


ploneintranet.layout.dashboard_tile_class_mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Classes that should be applied to the portlets loaded on the dashboard

    **type**: plone.registry.field.Dict {plone.registry.field.TextLine: plone.registry.field.TextLine}

    **default**: {"activitystream.dashboard.tile": "state-expanded", ...}


ploneintranet.layout.dashboard_tile_id_mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Ids that should be applied to the portlets loaded on the dashboard

    **type**: plone.registry.field.Dict {plone.registry.field.TextLine: plone.registry.field.TextLine}

    **default**: {"activitystream.dashboard.tile": "portlet-activity-stream", ...}


ploneintranet.layout.filter_news_by_published_state
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Filter news in portlet by published state

    **description**: When set to true (default), the news portlet will only search for items in workflow state published. You can turn that off to become more flexible in controlling the search by actual view permissions. This can come in handy when you use different published states.

    **type**: plone.registry.field.Bool

    **default**: True


ploneintranet.layout.custom_bubbles
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Custom help bubbles

    **description**: Specify custom help bubbles in a json format, e.g.: {"foo-bar": {"title": "Foo", "description": "<p>Bar baz</p>"}}  (this may change in the future)

    **type**: plone.registry.field.Text

    **default**: None


ploneintranet.layout.bubbles_enabled
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Enable the help bubbles

    **description**: Setting this value to "On" will show the help bubbles unless the user disables them. Setting this value to "Off" will not show the help bubbles unless the user enables them. Setting this value to "Disabled": will deactivate the help bubbles feature.

    **type**: plone.registry.field.Choice (plone.registry.field.TextLine)

    **default**: Off

ploneintranet.layout.types_not_listed_on_userprofile
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Types not listed on user profiles

    **description**: These types will be omitted in the documents tab on userprofiles. In addition, all types in `plone.types_not_searched` will be omitted too.

    **type**: plone.registry.field.Tuple (plone.registry.field.TextLine)

    **default**: todo, library.folder, library.section, userprofiles

ploneintranet.layout.logo_type (Deprecated)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **Deprecated**: This entry has been removed. It is now replaced by the two explicit parameters quaive_title and quaive_organisation so that you can set both organisation name and intranet title.

    **title**: Registry record for toggling between textual logo an image logo

    **description**: This setting determines whether the "a" tag in the global navigation that contains the name of the site is rendered with class `title` (for textual "logos") or class `organisation` for an image as logo. This setting is only useful in combination with the theme, which will contain the required CSS to display one if those cases.

    **type**: plone.registry.field.Choice

    **default**: title

ploneintranet.layout.quaive_organisation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Registry record for setting the name of the organisation

    **description**: If set, the text appears first in the topmost bar and denotes the name of the organisation. If left empty, it is not displayed.

    **type**: plone.registry.field.Text

    **default**: ''

ploneintranet.layout.quaive_title
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Registry record for setting the name of the intranet

    **description**: If set, the text appears after a potential organisation text in the topmost bar and denotes the name of the intranet. If left empty, it is not displayed.

    **type**: plone.registry.field.Text

    **default**: ''

ploneintranet.layout.push_server_reader_url
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Push Server Reader - URL

    **description**: The URL to your message queue server. E.g. ws://127.0.0.1:15674/ws. This is used by Stomp

    **type**: plone.registry.field.TextLine

    **default**: ''

ploneintranet.layout.push_server_writer_host
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Push Server Writer - Host:Port

    **description**: The Host and Port to write to your message queue server.  E.g. 127.0.0.1:5672. This is used by Plone to write messa ges to the queues.

    **type**: plone.registry.field.TextLine

    **default**: ''

ploneintranet.layout.push_server_reader_login
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Push Server Reader Login

    **description**: The login for a read only account on your message queue server. E.g. quaive_reader.

    **type**: plone.registry.field.TextLine

    **default**: ''

ploneintranet.layout.push_server_reader_password
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Push Server Reader Password

    **description**: The password for a read only account on your message queue server.

    **type**: plone.registry.field.TextLine

    **default**: ''


ploneintranet.layout.push_server_writer_login
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Push Server Writer Login

    **description**: The login for a writer account on your message queue server. E.g. quaive_writer.

    **type**: plone.registry.field.TextLine

    **default**: ''


ploneintranet.layout.push_server_writer_password
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Push Server Writer Password

    **description**: The password for a writer account on your message queue server.

    **type**: plone.registry.field.TextLine

    **default**: ''


ploneintranet.layout.push_exchange
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  **title**: Push Exchange Name

  **description**: The name for the exchange used to transmit updates for this quaive instance.

  **type**: plone.registry.field.TextLine

  **default**: ''


ploneintranet.layout.notification_exchange
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  **title**: Notification Exchange Name

  **description**: The name for the exchange used to transmit desktop notification updates.

  **type**: plone.registry.field.TextLine

  **default**: ''


ploneintranet.layout.texteditor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  **title**: Default text editor

  **description**: The name for the text editor to be used. Possible values: "redactor" or "tiptap".

  **type**: plone.registry.field.TextLine

  **default**: ''


ploneintranet.layout.texteditor_url_protocols
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  **title**: Texteditor URL protocols

  **description**: List of URL protocol schemes for the editor to recognize.

  **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

  **default**: ('file', 'ftp', 'ftps', 'http', 'https', 'mailto', 'notes', 'tel')


ploneintranet.layout.editor_html_allowed_users
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  **title**: List of users allowed to edit HTML

  **description**: List of users who are allowed to use the text editors HTML button to directly edit HTML text.

  **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

  **default**:


ploneintranet.library
---------------------

ploneintranet.library.order_by_modified
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Re-order library folder after publishing widely

    **description**: If True (default), a library folder will be re-ordered so that the item modified last is on top every time a "Publish widely" action happens.

    **type**: plone.registry.field.Bool

    **default**: True


ploneintranet.library.enable_pdf_download_ui
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**title**: Enable UI elements to trigger the download of the library content as PDF

**type**: plone.registry.field.Bool

**default**: False


ploneintranet.news
------------------

ploneintranet.news.unpublished_states
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: List of news unpublished state

    **description**: The news in the following states will be considered unpublished and a badge will be shown in the sidebar

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**: ('pending', 'private')

ploneintranet.news.allow_commenting
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Allow commenting of news items in the News Magazine

    **description**: If turned ON, users will be able to comments news items in the News Magazine just like other content items in a workspace.

    **type**: plone.registry.field.Bool

    **default**: True


ploneintranet.news.feed_stop
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Limit the number of items synced from a feed

    **description**: When creating a Syndication object in the news publisher, limit the fetched items to the latest N news. If the provided value is -1 (the default), all the feed items will be fetched.

    **type**: plone.registry.field.Int

    **default**: -1


ploneintranet.docconv.client
----------------------------


ploneintranet.docconv.bad_pdf_creators
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: List of bad pdf creators

    **description**: The svg produced by pdftocairo is known to be broken in some cases for scanned documents. List here the pdf creators (as returned by poppler's pdfinfo) that you know can produce bad PDFs.

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**:


ploneintranet.docconv.file_types
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Preview Content Types

    **description**: Generate preview images directly from this list of content types

    **type**: plone.registry.field.TextLine

    **default**: File

ploneintranet.docconv.html_types
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: HTML Preview Content Types

    **description**: Generate preview images from PDF versions of this list of content types

    **type**: plone.registry.field.TextLine

    **default**: Document

ploneintranet.docconv.num_previews
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Number of previews generated

    **description**: Limit the number of previews generated by default. This protects the system against PDFs with 35.000 pages.

    **type**: plone.registry.field.Int

    **default**: 20


ploneintranet.search
--------------------

ploneintranet.search.filter_fields
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Filter fields

    **description**: Fields that will be used to filter query responses in searches

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**: tags,
                 friendly_type_name,
                 portal_type,
                 path,
                 is_division,
                 division


ploneintranet.search.facet_fields
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Facet field

    **description**: A field that will be used to facet query responses

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**: tags,
                 friendly_type_name,
                 is_division,


ploneintranet.search.phrase_fields
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Phrase fields

    **description**: Fields to which the main search phrase will be applied

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**: Title,
                 Description,
                 tags,
                 SearchableText


ploneintranet.search.solr.phrase_field_boosts
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Phrase query field and associated boost values

    **description**: Solr Boost values used to compute relevency for queries.

    **type**: plone.registry.field.Dict {plone.registry.field.TextLine: plone.registry.field.Int}

    **default**: Title: 5
                 Description: 3
                 tags: 4
                 SearchableText: 1

    **note**: minimum accepted integer is 1


ploneintranet.search.ui.additional_facets
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Additional facets for filtering your results

    **description**: The search results page, by default,
                     facets the search results using the friendly_type_name field.
                     Here you can list additional fields you want to use for faceting.
                     Each field should be specified as field
                     (should match the values from ploneintranet.search.facet_fields)
                     and label
                     (a value that can be translate in the ploneintranet 18n domain)

    **type**: plone.registry.field.Dict {plone.registry.field.ASCII: plone.registry.field.TextLine}

    **default**: {'tags': 'Tags'}


ploneintranet.search.ui.additional_facet_classes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Class name(s) to use for the additional facets

    **description**: This maps a class name to the id of a facet. The id needs to
                     be the same that is used for ploneintranet.search.ui.additional_facets

    **type**: plone.registry.field.Dict {plone.registry.field.ASCII: plone.registry.field.TextLine}

    **default**: {'tags': 'tags'}


ploneintranet.search.friendly_type_name_mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Translates the portal type title or the mimetype name extracted from the mimetype registry to a human friendly name

    **type**: plone.registry.field.Dict {plone.registry.field.TextLine: plone.registry.field.TextLine}

    **default**: {'Octet Stream': 'File', 'Profile', 'Person'}


ploneintranet.userprofile
-------------------------

ploneintranet.userprofile.hidden_fields
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Hidden fields

    **description**: User profile fields that are hidden from the profile editing page

    **type**: plone.registry.field.Tuple composed of plone.registry.field.TextLine

    **default**:

ploneintranet.userprofile.property_sheet_mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Property sheet mapping

    **description**: A mapping of a user property to a specific
                     property sheet which
                     should be used to obtain the data for this attribute.

    **type**: plone.registry.field.Dict {plone.registry.field.ASCII: plone.registry.field.TextLine}

    **default**:

ploneintranet.userprofile.primary_external_user_source
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Primary External User Source

    **description**: The ID of the PAS plugin that will be treated as the primary source of external users.

    **type**: plone.registry.field.ASCIILine

    **default**:

ploneintranet.userprofile.read_only_fields
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Read only fields

    **description**: User profile fields that are read-only
                    (shown on profile editing page but not editable)

    **type**: plone.registry.field.Tuple composed of plone.registry.field.TextLine

    **default**: username

ploneintranet.userprofile.locations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Hidden fields

    **description**: User profile fields that are hidden from the profile editing page

    **type**: plone.registry.field.Tuple composed of plone.registry.field.TextLine

    **default**: London,
                 Amsterdam,
                 Berlin,
                 Paris,
                 New York


ploneintranet.workpace
----------------------

ploneintranet.workspace.allow_bulk_subscribe
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**title**: Allow the subscribe bulk action

**description**: If set to True, the user can subscribe to the selected objects

**type**: plone.registry.field.Bool

**default**: True


ploneintranet.workspace.case_manager.states
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Case Manager Workflow States

    **description**: Only these States are shown for filtering

    **type**: plone.registry.field.Tuple composed of plone.registry.field.TextLine

    **default**: new, pending, published, rejected

ploneintranet.workspace.externaleditor_always_activated
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: External Editor always activated.

    **description**: When true, the isActivatedInMemberProperty()
                     and isActivatedInSiteProperty()
                     methods of the EnabledView always return True.
                     Otherwise the normal behaviour as implemented
                     in collective.externaleditor is used.

    **type**: plone.registry.field.Bool

    **default**: False

ploneintranet.workspace.sort_options
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Workspace sort options

    **description**: Controls in which way we are able to sort the workspaces

    **type**: plone.registry.field.Dict {plone.registry.field.TextLine: plone.registry.field.TextLine}

    **default**:  activity: Most active workspaces on top
                  alphabet: Alphabetical
                  newest: Newest workspaces on top

ploneintranet.workspace.my_workspace_sorting
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: My workspace sorting.

    **description**: At the moment we are able to handle the values "active", "alphabet" and "newest".

    **type**: plone.registry.field.TextLine

    **default**: alphabet

ploneintranet.workspace.video_conference_server
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: The video conference server we can use to make video conference calls

    **type**: plone.registry.field.TextLine

    **default**: empty string

ploneintranet.workspace.workspace_types
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Select workspace types

    **description**: Only this types are searched when looking for workspaces

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**: ploneintranet.workspace.workspacefolder,
                 ploneintranet.workspace.case

    **note**: this will probably removed in favour of filtering
              by interface

ploneintranet.workspace.workspace_types_css_mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Maps workspace portal types to css classes

    **description**: If a portal_type is not here it will default to regular.
                     The values should be passed as "{type}|{css class}",
                     e.g. "ploneintranet.workspace.case|type-case"

    **type**: plone.registry.field.Tuple of plone.registry.field.TextLine

    **default**: ploneintranet.workspace.case|type-case


ploneintranet.workspace.sanitize_html
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Sanitize HTML on saving.

    **description**: If set to True, RichText content (HTML) in workspaces is sanitized before it gets stored. That means all open tags are properly closed, and inline styles and unwanted tags such as ``<span>`` or ``<blockquote>`` get stripped. Multipe line breaks get reduced to a single line break.

    **type**: plone.registry.field.Bool

    **default**: True


ploneintranet.workspace.autosave_portal_types
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Autosave portal types

    **description**: Enable autosave for the selected portal types (works for edit forms inside workspaces)

    **type**: plone.registry.field.Tuple composed of plone.registry.field.TextLine

    **default**: []


ploneintranet.workspace.autosave_delay
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Autosave delay

    **description**: Number of ms the client will wait before submitting a document

    **type**: plone.registry.field.Int

    **default**: 2000


ploneintranet.workspace.use_phase_due_dates
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Use Phase Due Dates.

    **description**: If set to True, cases will expose the due date management functionality. You need to have the quaive.app.milestones package installed.

    **type**: plone.registry.field.Bool

    **default**: False


ploneintranet.workspace.phase_due_dates_default
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Default Value for Phase Due Dates.

    **description**: If set to True, workspaces will be created with due date support turned on by default. You need to have the quaive.app.milestones package installed.

    **type**: plone.registry.field.Bool

    **default**: False


ploneintranet.workspace.hide_private_nonmember_workspaces
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Make the newly added private workspaces not visible in the workspace overview of the non members

    **description**: This means the workspace will have a security policy identical to the secret workspaces, anyway they will have different participation and join policies. By default this checkbox is unchecked.

    **type**: plone.registry.field.Bool

    **default**: True


ploneintranet.workspace.mailin.folder.id
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: ASCII id for the folder that incoming emails will be imported into

    **description**: Emails and their attachments mailed into a workspace will be stored in a folder with this id. You may want to configure this to be equal to the ``ploneintranet.microblog.extract.folder.id`` incoming folder for stream attachments. If this record is not set, imported emails will be stored toplevel in the workspace.

    **type**: plone.registry.field.ASCIILine

    **default**: ''

ploneintranet.workspace.mailin.folder.title
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Unicode title for the folder that emails will be imported into

    **description**: The title shown for the email import folder. This title will only be set on creation of the folder: an existing folder's title will be left unchanged. If not set, the folder id will be used.

    **type**: plone.registry.field.TextLine

    **default**: ''


ploneintranet.microblog
-----------------------

ploneintranet.microblog.whitelisted_types
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: List of the whitelisted types

    **description**: Content types which will automatically create an activity stream update of their creation.

    **type**: plone.registry.field.TextLine

    **default**:  Document, Event, File, Image, News Item


ploneintranet.microblog.extract.auto
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Enable automatic extraction of stream attachments

    **description**: If enabled, when posting a stream update with an attachment in a workspace, that attachment will be converted to a File stored in the ``ploneintranet.microblog.autoextract.folder`` folder of that workspace.

    **type**: plone.registry.field.Bool

    **default**: False

ploneintranet.microblog.extract.folder.id
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: ASCII id for the folder that stream attachments will be extracted into

    **description**: Attachments to stream updates in a workspace will be stored here. Note that even if ``ploneintranet.microblog.autoextract.enabled==False`` this folder name will still be used if you run the admin ``@@extract-attachments`` view.

    **type**: plone.registry.field.ASCIILine

    **default**: INCOMING

ploneintranet.microblog.extract.folder.title
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Unicode title for the folder that stream attachments will be extracted into

    **description**: The title shown for the stream attachments folder. This title will only be set on creation of the folder: an existing folder's title will be left unchanged.

    **type**: plone.registry.field.TextLine

    **default**: INCOMING


ploneintranet.activitystream
----------------------------

ploneintranet.activitystream.absolute_dates_after
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    **title**: Switch from relative to absolute date formatting after some days

    **description**: If a post is older than {value} days, show creation date as absolute date.
                     If this record {value} is 0, always uses relative date formatting.

    **type**: plone.registry.field.Int

    **default**: 0  (i.e. always use relative dates by default)
