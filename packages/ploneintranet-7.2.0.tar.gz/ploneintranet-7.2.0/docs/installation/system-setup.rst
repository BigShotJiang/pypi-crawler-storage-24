============
System setup
============

Some system packages are needed for a basic installation of Quaive.

.. warning::

   Plone Intranet can run on very different environments.
   The following instructions may not fit your system or your usual setup.
   If you need help write to the `developer mailing list`_ or on the #ploneintranet IRC channel.

You are welcome to adapt them to your system and contribute your experience back to `our open source repository`_


Manual OS preparation
~~~~~~~~~~~~~~~~~~~~~

See the documented `apt-get install` command there
for the list of packages you need to install in the operating system, before running buildout. YMMV.

Make sure you have the OS-level packages you need to build Plone, this can be
achieved using `install.plone.dependencies`_.

For the Plone Intranet file preview functionality, you need libreoffice, gm (GraphicsMagick), pdfinfo and pdfttotext.

Solr is a required component. This will be built using buildout, but requires Java to be available.
On Ubuntu this normally comes pre-installed with the base OS.

Redis is a required component. This is *not* built with buildout, but expected to be available as a system service.
To install it on Ubuntu::

   sudo apt-get install redis-server

The default buildout is ldap-prepared. To make installing `python-ldap` possible, on Ubuntu you need::

   sudo apt-get install libldap2-dev libsasl2-dev

Ldap support is prepared, but disabled by default.
Please read the documentation section :doc:`ldap`
for instructions on installing and configuring LDAP.

On Ubuntu 18.04 LTS you can get the basic packages installed by running the following commands as root::

 apt-get update && apt-get install -y \
     cron \
     curl \
     file \
     firefox \
     ffmpegthumbnailer \
     gcc \
     gettext \
     ghostscript \
     git-core \
     graphicsmagick \
     jed \
     libenchant-dev \
     libffi-dev \
     libfreetype6-dev \
     libjpeg-dev \
     libldap2-dev \
     libreoffice \
     libsasl2-dev \
     libsqlite3-dev \
     libxslt1-dev \
     make \
     pdftk \
     poppler-data \
     poppler-utils \
     python-dev \
     python-gdbm \
     python-lxml \
     python-pip \
     python-tk \
     python-virtualenv \
     redis-server \
     ruby2.3 \
     ruby2.3-dev \
     wget \
     wv \
     xvfb \
     zlib1g-dev

  locale-gen en_US.UTF-8 nl_NL@euro


.. _developer mailing list: https://groups.io/g/ploneintranet-dev
.. _our open source repository: https://github.com/ploneintranet/ploneintranet
.. _Docker installation docs: https://docs.docker.com/installation/
.. _install.plone.dependencies: https://github.com/collective/install.plone.dependencies
