2.2.3 (2021-06-10)
------------------

Changed:


- Fixed a glitch in the workflow menu, so that it gets enabled/disabled with the proper conditions.
- Prototype translations are integrated, and have precedence over Transifex and source translations. (`Issue #3907 <https://github.com/quaive/ploneintranet/issues/3907>`_)
- The notifications panel has been reworked. The notifications do not include anymore the links to mentions and tags. (`Issue #4032 <https://github.com/quaive/ploneintranet/issues/4032>`_)


Fixed:


- The contacts more menu received minor improvements (more granular permission check) (`Issue #3922 <https://github.com/quaive/ploneintranet/issues/3922>`_)


Technical:


- Add to the ploneintranet static resources URLs in the style and scripts viewlet a query string parameter that will break the cache on new releases without the need to manually run ``@@pi-refresh-compilations`` (`Issue #1550 <https://github.com/quaive/ploneintranet/issues/1550>`_)
- All translations across all Quaive packages are now centrally managed by i18nsync, run 'ploneintranet/buildout.d/templates/i18nsync -hv' to learn more.
  Replace ploneintranetCoreMessageFactory with _, remove unused locales, remove i18n namespace and domain declarations in config files, update source reference paths.
  (`Issue #3907 <https://github.com/quaive/ploneintranet/issues/3907>`_)
- Remove dead code (`Issue #4065 <https://github.com/quaive/ploneintranet/issues/4065>`_)


Updated:


- collective.mustread = 2.0.1
- In case the intranet is configured to allow adding content items (documents etc) already on the first level inside the library, the publish-to-library handler in workspaces knows how to handle this correctly. (`Issue #4015 <https://github.com/quaive/ploneintranet/issues/4015>`_)
- quaive.resources.ploneintranet = 7.2.0 (`Issue #4032 <https://github.com/quaive/ploneintranet/issues/4032>`_)


2.2.2 (2021-06-09)
------------------

Fixed:


- Fix month/week/day view buttons in the calendar app to be useable again. (`Issue #4126 <https://github.com/quaive/ploneintranet/issues/4126>`_)


2.2.1 (2021-05-26)
------------------

Added:


- Make it possible to remove a previously set workspace hero image. (`Issue #4002 <https://github.com/quaive/ploneintranet/issues/4002>`_)
- Add "Industry" field to the user profile.
  Ref: scr-1087 (`Issue #4046 <https://github.com/quaive/ploneintranet/issues/4046>`_)


Changed:


- Fixed a glitch in the workspace sidebar so that the three-dots menu on a selected document gets displayed correctly.
- Overview pages in the library now give a better understanding about what content is to be expected. All items come with a title, and all document types and videos are shown with their preview. (`Issue #4021 <https://github.com/quaive/ploneintranet/issues/4021>`_)


Fixed:


- Make email field index case insensitive.
  This requires a rebuild and restart of solr. (`Issue #3820 <https://github.com/quaive/ploneintranet/issues/3820>`_)
- The contacts more menu received minor improvements (more granular permission check) (`Issue #3922 <https://github.com/quaive/ploneintranet/issues/3922>`_)
- Fix for erroneous search results when searching for random strings or creation date in the future. (`Issue #4037 <https://github.com/quaive/ploneintranet/issues/4037>`_)
- Open todo section in sidebar when clicking on a task notification. (`Issue #4040 <https://github.com/quaive/ploneintranet/issues/4040>`_)
- Emergency contacts are created with their correct title (`Issue #4041 <https://github.com/quaive/ploneintranet/issues/4041>`_)
- Fix the ``ploneintranet.userprofile.hidden_fields`` registry key to allow empty values. (`Issue #4063 <https://github.com/quaive/ploneintranet/issues/4063>`_)


Technical:


- Fold event-driven local role assignments for todos into existing local role adapter. (`Issue #3906 <https://github.com/quaive/ploneintranet/issues/3906>`_)
- Replace ploneintranetCoreMessageFactory with _.
  Remove unused locales (`Issue #3907 <https://github.com/quaive/ploneintranet/issues/3907>`_)
- Fix import of encodebytes for improved Python 3 compatibility. (`Issue #4036 <https://github.com/quaive/ploneintranet/issues/4036>`_)
- Proactively harden our tools against traversal by removing docstrings from methods. (`Issue #4049 <https://github.com/quaive/ploneintranet/issues/4049>`_)
- Backport a patch from upstream that will fix errors happening when traversing /++theme++ploneintranet.theme/ folders (`Issue #4055 <https://github.com/quaive/ploneintranet/issues/4055>`_)
- Upgrade quaive.resources.ploneintranet to 7.1.1. (`Issue #4058 <https://github.com/quaive/ploneintranet/issues/4058>`_)
- Fix error in userprofile info pages with hidden_profiles set to None via the registry control panel. (`Issue #4069 <https://github.com/quaive/ploneintranet/issues/4069>`_)


2.2.0 (2021-04-30)
------------------

Added:


- Users now have the option to decide if their email address is visible to other users or not.
  Site administrators can define the default behaviour (show per default / hide per default). (`Issue #3972 <https://github.com/quaive/ploneintranet/issues/3972>`_)
- In the sidebar of workspaces, uploaded images are now displayed with a little thumbnail image, making them quicker to recognise. (`Issue #3982 <https://github.com/quaive/ploneintranet/issues/3982>`_)


Changed:


- Panels for bulk-changing content or creating new workspaces have a modernized look.
  (`Issue #3967 <https://github.com/quaive/ploneintranet/issues/3967>`_)
- Selected dates in forms are now in natural language format.
  (`Issue #3967 <https://github.com/quaive/ploneintranet/issues/3967>`_)
- Panels that contain multiple tabs have a unified look and fuctionality.
  (`Issue #3967 <https://github.com/quaive/ploneintranet/issues/3967>`_)
- Some forms, e.g. for editing news metadata or for creating a workspace have a clearer structure.
  (`Issue #3967 <https://github.com/quaive/ploneintranet/issues/3967>`_)
- If a workspace has a hero image, that image is now displayed as a background image on the workspace tile, to make a workspace easier to recognize. (`Issue #3741 <https://github.com/quaive/ploneintranet/issues/3741>`_)
- Users created from an external plugin that is used for the authentication are not allowed anymore to change their password (`Issue #3929 <https://github.com/quaive/ploneintranet/issues/3929>`_)
- Sites with the Quaive Cloud theme (without their own branding) will be displayed with the site title also on the login form. (`Issue #4011 <https://github.com/quaive/ploneintranet/issues/4011>`_)


Fixed:


- Use the Quaive site title instead of the Plone one (`Issue #3269 <https://github.com/quaive/ploneintranet/issues/3269>`_)
- Do not display the world map if an event has not a location set (`Issue #3964 <https://github.com/quaive/ploneintranet/issues/3964>`_)
- Dashes in workspaces titles are no longer stripped in the workspaces overview. (`Issue #3974 <https://github.com/quaive/ploneintranet/issues/3974>`_)
- Fixed French version of date format. (`Issue #3981 <https://github.com/quaive/ploneintranet/issues/3981>`_)
- The link to the help page for video conferences is now displayed in a modal if the help app is not installed (`Issue #3990 <https://github.com/quaive/ploneintranet/issues/3990>`_)
- Fixed a display bug in the library that could appear after certain click-paths. (`Issue #3993 <https://github.com/quaive/ploneintranet/issues/3993>`_)
- Remove the test dependency on suite from workspace by moving the plone.valid_tags and plone.custom_attributes registry records from suite to layout. (`Issue #3996 <https://github.com/quaive/ploneintranet/issues/3996>`_)
- Make default case template accessible and addable by properly indexing security on init. (`Issue #4005 <https://github.com/quaive/ploneintranet/issues/4005>`_)


Technical:


- Reduce code duplication by moving the site_title property to the @@proto view (`Issue #3929 <https://github.com/quaive/ploneintranet/issues/3929>`_)
- New registry setting: ploneintranet.userprofile.hide_email_by_default.
  It determines whether the option to hide the personal email address from other users
  is on or off by default. (`Issue #3972 <https://github.com/quaive/ploneintranet/issues/3972>`_)
- Avoid solr/testing.py:149: ResourceWarning: unclosed file <_io.TextIOWrapper name='/dev/null'
  when solr-test aborts. (`Issue #3992 <https://github.com/quaive/ploneintranet/issues/3992>`_)


Updated:

- quaive.resources.ploneintranet = 7.1.0
- quaive.app.milestones = 2.0.6
- quaive.app.classifieds = 1.0.4
- Products.membrane = 5.0.2


Older changelogs
----------------

   CHANGES21

   CHANGES20

   CHANGES10
