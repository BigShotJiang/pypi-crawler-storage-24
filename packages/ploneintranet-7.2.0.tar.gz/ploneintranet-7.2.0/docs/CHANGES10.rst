1.4.1 (2019-02-18)
------------------

Changed:


- The select in the add event popup in the calendar has been changed to an
  autocomplete field (`Issue #2311
  <https://github.com/quaive/ploneintranet/issues/2311>`_)
- Backport some compatible changes required for Plone 5.1.5 (`Issue #2390
  <https://github.com/quaive/ploneintranet/issues/2390>`_)
- News items in the News Publisher sidebar are now sorted by publication date
  (effective date). (`Issue #2407
  <https://github.com/quaive/ploneintranet/issues/2407>`_)


Fixed:


- Remove the unused @@ploneintranet_workspace_state view (`Issue #2014
  <https://github.com/quaive/ploneintranet/issues/2014>`_)
- Speed up method to check if we can add event to at least one calendar (`Issue
  #2311 <https://github.com/quaive/ploneintranet/issues/2311>`_)
- In a team managed workspace users can see the buttons to add users and groups
  (`Issue #2401 <https://github.com/quaive/ploneintranet/issues/2401>`_)
- News Publisher: Fixed error when setting a news item to "Pending review".
  (`Issue #2408 <https://github.com/quaive/ploneintranet/issues/2408>`_)
- Moderators can modify workspace tasks. (`Issue #2415
  <https://github.com/quaive/ploneintranet/issues/2415>`_)
- Personal Settings: Fixed "back" link (top left logo). (`Issue #2418
  <https://github.com/quaive/ploneintranet/issues/2418>`_)
- Aligned markup so that the add group option in the workspace sidebar has the
  right icon. (`Issue #2421
  <https://github.com/quaive/ploneintranet/issues/2421>`_)
- Converted remaining deprecated traces of old validation classes from
  templates. (`Issue #2423
  <https://github.com/quaive/ploneintranet/issues/2423>`_)


Technical:


- Work around test breakage involving failing IPrimaryFieldInfo adaptation.
  (`Issue #2404 <https://github.com/quaive/ploneintranet/issues/2404>`_)


Updated:


- Upgrade quaive.resources.ploneintranet to 3.0.0b12 (`Issue #1889
  <https://github.com/quaive/ploneintranet/issues/1889>`_)


1.4.0 (2019-01-24)
------------------

Added:


- Added the IFunctionalPrincipal interface that can be used
  to mark user and groups that we want to hide them from
  the user interface (`Issue #2392
  <https://github.com/quaive/ploneintranet/issues/2392>`_)


Changed:


- Use a global request in the docconv handler (`Issue #2166
  <https://github.com/quaive/ploneintranet/issues/2166>`_)
- Workaround for links from MS Office (`Issue #2388
  <https://github.com/quaive/ploneintranet/issues/2388>`_)


Fixed:


- Do not break when removing user/groups from workspace (`Issue #2356
  <https://github.com/quaive/ploneintranet/issues/2356>`_)
- Improve the sync script (`Issue #2368
  <https://github.com/quaive/ploneintranet/issues/2368>`_)
- Fix rendering of unicode $fullname in the "locked" message (`Issue #2397
  <https://github.com/quaive/ploneintranet/issues/2397>`_)


Updated:


- Upgrade quaive.resources.ploneintranet to 3.0.0b11 (`Issue #1889
  <https://github.com/quaive/ploneintranet/issues/1889>`_)


1.4.0b13 (2019-01-18)
---------------------


Changed:


- Speed up further our membrane catalog patch (`Issue #2078
  <https://github.com/quaive/ploneintranet/issues/2078>`_)
- Improve the default experience of the news app
  by providing proper initial settings (`Issue #1963
  <https://github.com/quaive/ploneintranet/issues/1963>`_)
- The contents of the userprofile are now by default private for regular users.
  Personal tasks will be visible to assignees. (`Issue #2352
  <https://github.com/quaive/ploneintranet/issues/2352>`_)
- By default the splash page on first login is disabled (`Issue #2360
  <https://github.com/quaive/ploneintranet/issues/2360>`_)


Fixed:


- Tasks in projects from quaive.app.milestone can be added again (`Issue #2383
  <https://github.com/quaive/ploneintranet/issues/2383>`_)
- Calendar App: Fixed calendar association of shared events when user is
  invited (`Issue #2345
  <https://github.com/quaive/ploneintranet/issues/2345>`_)
- Fixed editing events directly in Calendar App (`Issue #2357
  <https://github.com/quaive/ploneintranet/issues/2357>`_)
- Fixed charset when sending emails after a user is created in the
  administrator tool app (`Issue #2358
  <https://github.com/quaive/ploneintranet/issues/2358>`_)
- Images uploaded with the sidebar dropzone have the proper icon (`Issue #2363
  <https://github.com/quaive/ploneintranet/issues/2363>`_)
- Small bugs in the ldap sync views (`Issue #2368
  <https://github.com/quaive/ploneintranet/issues/2368>`_)
- Fix injection after a user is created or its state is changed (`Issue #2373
  <https://github.com/quaive/ploneintranet/issues/2373>`_)
- Injection issues in the news publisher (`Issue #2375
  <https://github.com/quaive/ploneintranet/issues/2375>`_)
- Translation for the published action of status updates (`Issue #2377
  <https://github.com/quaive/ploneintranet/issues/2377>`_)
- It is possible again to upload news images using redactor (`Issue #2379
  <https://github.com/quaive/ploneintranet/issues/2379>`_)


Technical:


- Calendar App: Refactored for less code duplication (`Issue #2345
  <https://github.com/quaive/ploneintranet/issues/2345>`_)


Updated:


- Update quaive.app.absences 1.1.0


1.4.0b12 (2019-01-08)
---------------------

Changed:


- Case Manager: Display user friendly status titles. (`Issue #2339
  <https://github.com/quaive/ploneintranet/issues/2339>`_)


Fixed:


- Fix unicode error when trying to sync groups from ldap (`Issue #2337
  <https://github.com/quaive/ploneintranet/issues/2337>`_)
- Central Calendars: When invited to an event that's shared to a central
  calendar, the link in the calendar app sidebar now goes to the calendar
  options. (`Issue #2343
  <https://github.com/quaive/ploneintranet/issues/2343>`_)
- Do not display syndication sections in the section dropdown (`Issue #2346
  <https://github.com/quaive/ploneintranet/issues/2346>`_)
- Do not return events we cannot access because of missing permissions on the
  container (`Issue #2348
  <https://github.com/quaive/ploneintranet/issues/2348>`_)


Updated:


- Update quaive.app.milestones 1.2.1 (`Issue #2335
  <https://github.com/quaive/ploneintranet/issues/2335>`_)


1.4.0b11 (2018-12-18)
---------------------

Added:


- Added some views to generate a graph meant to be used by PAS (`Issue #2078
  <https://github.com/quaive/ploneintranet/issues/2078>`_)
- Added a field to grant the editor roles to a user or a group (`Issue #2223
  <https://github.com/quaive/ploneintranet/issues/2223>`_)


Changed:


- The userprofile views profit of the PAS graph when it is available (`Issue
  #2078 <https://github.com/quaive/ploneintranet/issues/2078>`_)


Fixed:


- Improve the upgrade steps to swith to the new workgroup workflow (`Issue
  #1988 <https://github.com/quaive/ploneintranet/issues/1988>`_)
- Fix the sortable_title indexer for userprofiles and the group edit button is
  displayed only when the users have the proper permissions (`Issue #2223
  <https://github.com/quaive/ploneintranet/issues/2223>`_)
- The upgrade path to the new group management is now more solid (`Issue #2307
  <https://github.com/quaive/ploneintranet/issues/2307>`_)
- The number of the news displayed in the small columns of the news front page
  respects the configuration (before it was always one). (`Issue #2308
  <https://github.com/quaive/ploneintranet/issues/2308>`_)
- Fix a label in the Todo app (`Issue #2317
  <https://github.com/quaive/ploneintranet/issues/2317>`_)
- Diminish the chance of conflict errors when visiting userprofile tabs (`Issue
  #2321 <https://github.com/quaive/ploneintranet/issues/2321>`_)
- Case Manager: Search handles special characters properly. (`Issue #2328
  <https://github.com/quaive/ploneintranet/issues/2328>`_)
- Case Manager: "earliest" and "latest" in the date fields now behave as
  expected. (`Issue #2330
  <https://github.com/quaive/ploneintranet/issues/2330>`_)


Updated:


- Update quaive.app.taxonomy = 1.3.0 (`Issue #2302
  <https://github.com/quaive/ploneintranet/issues/2302>`_)


1.4.0b10 (2018-12-04)
---------------------

Fixed:


- Provide proper defaults for the user profile values and a safer way to sort
  the users (`Issue #2304
  <https://github.com/quaive/ploneintranet/issues/2304>`_)


Updated:


- Update quaive.app.milestones = 1.2.0 (`Issue #2302
  <https://github.com/quaive/ploneintranet/issues/2302>`_)


1.4.0b9 (2018-12-03)
--------------------

Added:


- A user can control the news portlet using the personal settings (`Issue #2187
  <https://github.com/quaive/ploneintranet/issues/2187>`_)
- Groups can have a logo (`Issue #2223
  <https://github.com/quaive/ploneintranet/issues/2223>`_)
- Allow HR managers to edit user properties (`Issue #2237
  <https://github.com/quaive/ploneintranet/issues/2237>`_)


Changed:

- Update the News section to match the new prototype
  quaive/ploneintranet.prototype#651,
  implementing a very feature rich configuration panel.
  Also better structure the news sections and allow feeds to be loaded by
  Atom or RSS
  (`Issue #1963 <https://github.com/quaive/ploneintranet/issues/1963>`_)
- Fixed templates for translation string extraction and added translations for
  calendar. (`Issue #2021
  <https://github.com/quaive/ploneintranet/issues/2021>`_)
- Avoid an expensive rename when creating a workspace based on a template
  (`Issue #2115 <https://github.com/quaive/ploneintranet/issues/2115>`_)
- Links in the library are not injected anymore (`Issue #2155
  <https://github.com/quaive/ploneintranet/issues/2155>`_)
- Remove the ``[attachment]`` extra requires that were pulling in the unused
  Products.UserAndGroupSelectionWidget (`Issue #2162
  <https://github.com/quaive/ploneintranet/issues/2162>`_)
- Tabbed modals markup has changed to have one form per tab (`Issue #2184
  <https://github.com/quaive/ploneintranet/issues/2184>`_)
- Rationalize the ``get_avatar_tag method`` usage.
  The group view has now a sidebar
  listing all the group children Allow users to properly manage groups through
  the contacts app (`Issue #2223
  <https://github.com/quaive/ploneintranet/issues/2223>`_)
- Aligned order of fields with prototype. (`Issue #2224
  <https://github.com/quaive/ploneintranet/issues/2224>`_)
- The Solr mainteinance sync view now does not compare anymore the modification
  time of the solr flare and the catalog brain. The old behavior can be
  restored by passing compare_dates=1 in the query string (`Issue #2247
  <https://github.com/quaive/ploneintranet/issues/2247>`_)
- The dashboard page customization was made easier (`Issue #2248
  <https://github.com/quaive/ploneintranet/issues/2248>`_)


Fixed:


- Central calendar notifications: Fixed character encoding. (`Issue #2021
  <https://github.com/quaive/ploneintranet/issues/2021>`_)
- Do not break old upgrade step (`Issue #2112
  <https://github.com/quaive/ploneintranet/issues/2112>`_)
- Fixed error when a non-member is invited to a workspace event that is shared
  to a central calendar (`Issue #2171
  <https://github.com/quaive/ploneintranet/issues/2171>`_)
- Fix a glitch in the userprofile page that was showing part of the dashboard
  (`Issue #2172 <https://github.com/quaive/ploneintranet/issues/2172>`_)
- Fix JavaScript issues that prevented autosave and injection to work reliably
  (`Issue #2175 <https://github.com/quaive/ploneintranet/issues/2175>`_)
- Central calendars: Fixed error when declining an event sharing request.
  (`Issue #2182 <https://github.com/quaive/ploneintranet/issues/2182>`_)
- Deactivate the mechanism that automatically adds the generated preview image
  as lead image in case there is one. (`Issue #2188
  <https://github.com/quaive/ploneintranet/issues/2188>`_)
- Performance improvements when working with the folder contents in the CMS
  (`Issue #2191 <https://github.com/quaive/ploneintranet/issues/2191>`_)
- Bulk archive from the sidebar was failing with documents containing non
  unicode titles in their name (`Issue #2197
  <https://github.com/quaive/ploneintranet/issues/2197>`_)
- Fix injection in library to folders from pages view (`Issue #2200
  <https://github.com/quaive/ploneintranet/issues/2200>`_)
- Various performances improvements when doing batch operations and emptying
  the trash (`Issue #2216
  <https://github.com/quaive/ploneintranet/issues/2216>`_)
- Fix the buildout/setup configuration for the console script
  ``feed_aggregator``.
  The script now logs an error if the script user can't publish a news item
  (`Issue #2233 <https://github.com/quaive/ploneintranet/issues/2233>`_)
- Corrected German translation of "Name of organiser". (`Issue #2226
  <https://github.com/quaive/ploneintranet/issues/2226>`_)
- Files with non-ASCII characters in their filename can be viewed correctly in
  the versions history (`Issue #2231
  <https://github.com/quaive/ploneintranet/issues/2231>`_)
- Create objects with a proper id to prevent catalog warnings when they are
  renamed (`Issue #2243
  <https://github.com/quaive/ploneintranet/issues/2243>`_)
- Hide "add event" form when there is no workspace to add to. Also removed
  placeholder from "Calendar" field. (`Issue #2245
  <https://github.com/quaive/ploneintranet/issues/2245>`_)
- Added support (in our templates) so that an image-based logo can be used in
  the main navigation (in combination with proper support in the CSS of the
  chosen theme) (`Issue #2256
  <https://github.com/quaive/ploneintranet/issues/2256>`_)
- Fixed scrolling on mobile. This requires at least version 3.0.0b10 of
  quaive.resources.ploneintranet. (`Issue #2274
  <https://github.com/quaive/ploneintranet/issues/2274>`_)
- Fixed an encoding issue on news section titles (`Issue #2287
  <https://github.com/quaive/ploneintranet/issues/2287>`_)
- Task titles are editable again (`Issue #2290
  <https://github.com/quaive/ploneintranet/issues/2290>`_)
- Make URLs in the dashboard absolute to prevent broken dashboard when the URL
  is not the expected one. (`Issue #2297
  <https://github.com/quaive/ploneintranet/issues/2297>`_)


Technical:


- Improvement relative to the group management:

  - Provide constrained container that allows only workgroups
  - Provide migration into container
  - Bring user management in workgroups under test
  - Fix many hidden bugs in the code that manifested only under specific test conditions

  (`Issue #1988   <https://github.com/quaive/ploneintranet/issues/1988>`_)
- Remove unused registry setting ploneintranet.layout.login_splash (`Issue
  #2142 <https://github.com/quaive/ploneintranet/issues/2142>`_)
- Convert ``importsteps.xml`` in call to ``post_handler``. Fix profiles versions in
  ``metadata.xml`` (`Issue #2161
  <https://github.com/quaive/ploneintranet/issues/2161>`_)
- Given that ``Products.UserAndGroupSelectionWidget`` was removed, all the
  dependencies it pulled in, e.g. ``bda-cache`` and ``python-libmemcached``,
  will be missing.
  If you need some of them be sure to require them either in your
  buildout or in your policy package setup.py (`Issue #2162
  <https://github.com/quaive/ploneintranet/issues/2162>`_)
- Use the latest ``zc.buildout``/``setuptools``
  versions Autopep8 E305 and E722 Use the
  latest version of Faker to setup testing content (`Issue #2166
  <https://github.com/quaive/ploneintranet/issues/2166>`_)
- Upgrade plone.app.vocabularies to 4.0.7 (`Issue #2191
  <https://github.com/quaive/ploneintranet/issues/2191>`_)
- Catch a workflow error that should not be there. (`Issue #2208
  <https://github.com/quaive/ploneintranet/issues/2208>`_)
- Fix an issue that could lead to a failure in docconv, depending on the user's
  VHM settings. (`Issue #2211
  <https://github.com/quaive/ploneintranet/issues/2211>`_)
- Limit celery to only one connection by default (`Issue #2217
  <https://github.com/quaive/ploneintranet/issues/2217>`_)
- Upgrade the long-running 1.3.15 beta cycle into a 1.4.0 beta cycle. This
  keeps the current b9 postfix to indicate continuity. (`Issue #2294
  <https://github.com/quaive/ploneintranet/issues/2294>`_)

Updated:

- Upgrade collective.auditlog to 1.4.0a2
  <https://github.com/quaive/ploneintranet/issues/2175>`_)
- Upgrade quaive.resources.ploneintranet to 3.0.0b10 (`Issue #2184
  <https://github.com/quaive/ploneintranet/issues/2184>`_)


1.3.15b8 (2018-10-10)
---------------------

Changed:


- Remove the behavior
  ``plone.app.referenceablebehavior.referenceable.IReferenceable`` because we
  are not dealing with archetypes (`Issue #2139
  <https://github.com/quaive/ploneintranet/issues/2139>`_)
- The links of the dashboard document portlet were unproperly injected
  (`Issue #2152 <https://github.com/quaive/ploneintranet/issues/2152>`_)


Fixed:


- Do not crash if the canonical field contains non ASCII characters (`Issue
  #2146 <https://github.com/quaive/ploneintranet/issues/2146>`_)
- Do not show trashed items in the document portlet (`Issue #2147
  <https://github.com/quaive/ploneintranet/issues/2147>`_)
- Add CSRF token to paste action, fixes regression introduced in 3bcd5929
  (`Issue #2148 <https://github.com/quaive/ploneintranet/issues/2148>`_)


Technical:


- Document workaround for zestreleaser.towncrier breakage
  (`Issue #2088 <https://github.com/quaive/ploneintranet/issues/2088>`_)


1.3.15b7 (2018-09-28)
---------------------

Added:


- Central Calendars (A new solr index ``shared_calendar`` is needed.) (`Issue
  #2021 <https://github.com/quaive/ploneintranet/issues/2021>`_)


Changed:


- Removed obsolete option "Workspace calendar visible in central calendar
  application" (`Issue #2008
  <https://github.com/quaive/ploneintranet/issues/2008>`_)


Fixed:


- Sorting workspaces on most recently active does not throw an Unauthorized
  anymore. While fixing this, cleanup the workspaces rendering code and remove
  cruft not needed anymore since sort by activity was properly implemented via
  an index. (`Issue #2132
  <https://github.com/quaive/ploneintranet/issues/2132>`_)


Technical:

- Disable zestreleaser.towncrier integration since it keeps barfing the release
  process. Run ``bin/towncrier --version 1.3.15b7`` manually instead, before
  calling ``bin/fullrelease``. `Issue #2088
  <https://github.com/quaive/ploneintranet/issues/2088>`_)



1.3.15b6 (2018-09-25)
---------------------

Fixed:


- An image can be attached again to news in the news publisher app (`Issue #1893
  <https://github.com/quaive/ploneintranet/issues/1893>`_)
- Clicking on the site logo reliably closes the application space and shows
  proper content instead of a white page (`Issue #2036
  <https://github.com/quaive/ploneintranet/issues/2036>`_)
- Do not crash when a file content type does not actually contain a file
  (`Issue #2082 <https://github.com/quaive/ploneintranet/issues/2082>`_)
- Fix a stale pat-switch without config (`Issue #2122
  <https://github.com/quaive/ploneintranet/issues/2122>`_)
- The sidebar was not shown after a document was unlocked (`Issue #2125
  <https://github.com/quaive/ploneintranet/issues/2125>`_)
- The case manager can list more then just cases (`Issue #2130
  <https://github.com/quaive/ploneintranet/issues/2130>`_)
- The portlet my_documents.tile does not show archived documents (`Issue #2135
  <https://github.com/quaive/ploneintranet/issues/2135>`_)
- Do not render all the users if no query is passed in the user picker (`Issue
  #2217 <https://github.com/quaive/ploneintranet/issues/2217>`_)


Updated:


- Update quaive.resources.ploneintranet to version 3.0.0b5 (`Issue #2036
  <https://github.com/quaive/ploneintranet/issues/2036>`_)


1.3.15b5 (2018-09-17)
---------------------

Fixed:


- Do not render all the users if no query is passed in the user picker (`Issue
  #2117 <https://github.com/quaive/ploneintranet/issues/2117>`_)


1.3.15b4 (2018-09-17)
---------------------

Fixed:


- Temporarily disable the indexing queue when an object is created in a
  workspace but dexterity_update is not called yet. Diminishes the chance of
  faux and premature Solr entries. (`Issue #2099
  <https://github.com/quaive/ploneintranet/issues/2099>`_)
- Do not fiddle with Solr in ``create_from_template`` because this is already
  done in a more proper way in the method ``create`` (`Issue #2100
  <https://github.com/quaive/ploneintranet/issues/2100>`_)
- Improve the performance when showing the workspaces in the user profile
  (`Issue #2103 <https://github.com/quaive/ploneintranet/issues/2103>`_)
- Fix the upgrade step for ploneintranet.workspace 0037 that rewrites the
  portal types configuration (`Issue #2112
  <https://github.com/quaive/ploneintranet/issues/2112>`_)
- The panel users view was returning an error when comparing users
  with non ascii characters in their names (`Issue #2117
  <https://github.com/quaive/ploneintranet/issues/2117>`_)


Technical:


- **Upgrade warning**: the prototype changes included since
  ``quaive.resources.ploneintranet`` 3.0.0b1 were much bigger than usual. The
  3.0.0bX tags of the ``quaive.resources.ploneintranet`` package contain
  modifications of the usually untouched ``main_template.pt`` and ``rules.xml``
  files. If you have a custom resources theme or some customization package,
  you are advised to check extensively the impact of this upgrade on your
  package. (`Issue #2109
  <https://github.com/quaive/ploneintranet/issues/2109>`_)


Updated:


- Update quaive.resources.ploneintranet to version 3.0.0b3. Adapt some views to
  match the prototype and rework the logo and hamburger menu. (`Issue #2109
  <https://github.com/quaive/ploneintranet/issues/2109>`_)


1.3.15b3 (2018-09-13)
---------------------

Added:


- If wkhtmltopdf is available, it can be uses to generate improved PDF versions
  of the HTML documents (`Issue #1955
  <https://github.com/quaive/ploneintranet/issues/1955>`_)


Fixed:


- The tags in the workspace description were not correctly separated from the
  previous text (`Issue #2023
  <https://github.com/quaive/ploneintranet/issues/2023>`_)
- Improve workspace batching by moving the logic to Python code and
  disabling batching when some kind of grouping (division, tag) is selected
  (`Issue #2062 <https://github.com/quaive/ploneintranet/issues/2062>`_)
- Properly ignore some group plugins when dealing with workspaces (`Issue #2079
  <https://github.com/quaive/ploneintranet/issues/2079>`_)
- The permission required to bulk archive documents is now "Modify portal
  content", the same required to archive objects through the context menu (it
  was "slc: Toggle outdated"). (`Issue #2086
  <https://github.com/quaive/ploneintranet/issues/2086>`_)
- External links in the library are no longer injected (`Issue #2092
  <https://github.com/quaive/ploneintranet/issues/2092>`_)
- Files in the library overview page should not have a summary below (`Issue
  #2094 <https://github.com/quaive/ploneintranet/issues/2094>`_)


1.3.15b2 (2018-09-11)
---------------------

Updated:


- Update quaive.resources.ploneintranet to 3.0.0b2 (`Issue #2084
  <https://github.com/quaive/ploneintranet/issues/2084>`_)


1.3.15b1 (2018-09-07)
---------------------

Added:


- Workspace tags: - set tags on workspaces - see tags in workspace byline -
  filter workspaces by tag on workspaces overview - group workspaces by tag on
  workspaces overview (`Issue #1787
  <https://github.com/quaive/ploneintranet/issues/1787>`_)
- Download as PDF link for the library items (ploneintranet/prototype#621,
  ploneintranet.prototype#638) (`Issue #1878
  <https://github.com/quaive/ploneintranet/issues/1878>`_)
- Implement batching in the workspace overview (`Issue #2062
  <https://github.com/quaive/ploneintranet/issues/2062>`_)


Changed:


- Improve case creation speed (`Issue #1622
  <https://github.com/quaive/ploneintranet/issues/1622>`_)
- Increase the default number of generated page previews to 100 and display a
  link to download the document if the number of pages exceeds that limit.
  (`Issue #1784 <https://github.com/quaive/ploneintranet/issues/1784>`_)
- In the document sidebar, in batch mode, on 'cut' action, exit batch mode.
  This eliminates the 'exit batch' click, so you can immediately navigate to
  where you want to paste. This augments earlier work on the same ticket,
  merged in #1989, that made more document operations available directly on a
  document item in the sidebar. (`Issue #1785
  <https://github.com/quaive/ploneintranet/issues/1785>`_)
- Improve the sorting of workspaces by activity (`Issue #1786
  <https://github.com/quaive/ploneintranet/issues/1786>`_)
- Don't run update_todo_state on ObjectCreatedEvent (`Issue #1977
  <https://github.com/quaive/ploneintranet/issues/1977>`_)
- Tablet mode navigation paradigm changed: The main navigation in tablet mode
  was changed to now borrow from both - mobile and desktop We now have a
  hamburger menu as on mobile for the main navigation elements. The menu has
  moved to the upper right corner. In the upper left corner there is now a back
  button which allows the same back functionality we have on desktop version
  (`Issue #2020 <https://github.com/quaive/ploneintranet/issues/2020>`_)
- Filter options on the workspaces overview are now grouped together in a
  dropdown because we are running out of space. (`Issue #2030
  <https://github.com/quaive/ploneintranet/issues/2030>`_)
- The breadcrumb links for anything but workspaces now work with injection.
  This is important for PWA support and also looks more smooth. (`Issue #2034
  <https://github.com/quaive/ploneintranet/issues/2034>`_)
- Improved mobile browsing experience: Pre-load markup of workspaces-overview
  or apps-overview into a hidden container `#portal-content` when loading a
  workspace or an app, respectively. This makes sure that the "Back" link works
  even if the workspace / app was entered via direct link or page reload
  (`Issue #2036 <https://github.com/quaive/ploneintranet/issues/2036>`_)
- There is now a proper preview tile for office file library items. Also there
  is a dedicated download menue on the view where one can access the original
  version or a PDF version for download, if available (`Issue #2040
  <https://github.com/quaive/ploneintranet/issues/2040>`_)
- Decrease the chance of a conflict error when uploading lots of large files
  through the sidebar upload box by micromanaging the async preview generation
  (`Issue #2074 <https://github.com/quaive/ploneintranet/issues/2074>`_)
- Patch PAS to improve performances
  by avoiding expensive membrane catalog queries
  (`Issue #2078 <https://github.com/quaive/ploneintranet/issues/2078>`_)


Fixed:


- The search in the library uses the same criteria adopted by the site search
  to return consistent results (`Issue #2025
  <https://github.com/quaive/ploneintranet/issues/2025>`_)
- The change password, request account and password lost views now also work in
  tablet mode (`Issue #2033
  <https://github.com/quaive/ploneintranet/issues/2033>`_)
- Show auditlog action if available (`Issue #2054
  <https://github.com/quaive/ploneintranet/issues/2054>`_)
- We fixed the way how the create workspace modal works. It is now no longer
  possible that doubleclicking the create button creates two workspaces. Also
  workspaces are now created and the user stays on the workspace overview
  instead of directly jumping into the workspace, as designed. (`Issue #2061
  <https://github.com/quaive/ploneintranet/issues/2061>`_)
- When renaming folders in the bulk actions, the rename field is now properly
  prepopulated with the title. (`Issue #2064
  <https://github.com/quaive/ploneintranet/issues/2064>`_)
- Fixed the `create_caseworkspaces` setup handler to not break when the passed
  dict parameter does not trigger the creation of an object with id
  'file-report' (`Issue #2067
  <https://github.com/quaive/ploneintranet/issues/2067>`_)
- Require the id of the groups folder to be `groups` (`Issue #2069
  <https://github.com/quaive/ploneintranet/issues/2069>`_)
- Allow to specify the canonical property of the group when creating it (`Issue
  #2071 <https://github.com/quaive/ploneintranet/issues/2071>`_)


Technical:


- Make it easier for developers to work on source checkouts: `make sources`.
  (Refs #1926) (`Issue #1926
  <https://github.com/quaive/ploneintranet/issues/1926>`_)
- Adopt towncrier to generate the changelog when releasing packages (`Issue
  #1934 <https://github.com/quaive/ploneintranet/issues/1934>`_)
- Rewrote all shorthand entries for data-pat-switch to longhand (`Issue #2050
  <https://github.com/quaive/ploneintranet/issues/2050>`_)
- quaive/ploneintranet-base docker image has been upgraded to Ubuntu 16.04 Xenial.
  Fix our derived build script so it can run without user input.
  (`Issue #2027 <https://github.com/quaive/ploneintranet/issues/2027>`_)


Updated:


- New auditlog version to speed up case creation when auditlog is enabled
  (`Issue #1622 <https://github.com/quaive/ploneintranet/issues/1622>`_)
- Work around a glitch where copying email attachments generated an error
  message, even when it was actually working OK. (`Issue #1761
  <https://github.com/quaive/ploneintranet/issues/1761>`_)
- bleach = 2.1.3 chardet = 3.0.4 click = 6.7 cmarkgfm = 0.4.2 docutils = 0.14
  html5lib = 1.0.1 incremental = 17.5.0 pkginfo = 1.4.2 readme-renderer = 21.0
  requests-toolbelt = 0.8.0 setuptools = 40.0.0 toml = 0.9.4 towncrier = 18.5.0
  tqdm = 4.19.4 twine = 1.11.0 webencodings = 0.5.1 zc.buildout = 2.12.1
  zest.releaser = 6.15.1 zestreleaser.towncrier = 1.0.0b3 (`Issue #1934
  <https://github.com/quaive/ploneintranet/issues/1934>`_)
- Updated markup from proto, depends on quaive.resources.ploneintranet 3.0.0a1
  (`Issue #2000 <https://github.com/quaive/ploneintranet/issues/2000>`_)
- Use the latest collective.indexing 2.1 (`Issue #2056
  <https://github.com/quaive/ploneintranet/issues/2056>`_)


1.3.15a2 (unreleased)
---------------------

Changed:

- Personal menu: removed link "Change personal image", which was in Quaive
  only by accident.
- Add Workspace: Performance improvement
  (Reindex asynchronously when creating from template)
  (Refs #1975)
- The sidebar extra options are the same one available on the document.
  (Refs #1785)
- Add Workspace: Improved performance and removed unnecessary audit log
  entries.
  (Refs #1984)
- Document View: Open sidebar when following direct link.
  (Refs #1797)
  (Refs. #1984)
- Stream and search results show mail objects but not their attachments
  separately. Searching for text contained in attachments finds their parent
  mail object.
  (Refs #1761)
- Search preferences (display previews, sort order) are now always stored on
  the user object. This reverts #210
  (Refs. #1990)
- Robot Tests: Fixed screenshot on failure
- Robot Tests: Downgrade to firefox 58 to avoid a scrolling error

Added:

- UI related: A registry entry that allows to define a class name for each additional
  search facet.
  (Refs. #1990)
- Apple launcher icons
  (Refs. #2001)

Fixed:

- Favicon path
  (Refs. #2001)
- Remove hidden and unused element with a duplicate id
  (Refs #1996)
- Properly display the email content type in the search results
  (Refs #1973)
- Mails are no longer displayed as folders when linked to directly.
  (Refs #1761)
- Mail view: Image attachments are properly displayed. Previews cycle through
  all attachments (as in prototype).
  (Refs #1761)
- In Barceloneta, the file view now handles a missing File gracefully instead
  of throwing an error. Since we cannot upgrade to the latest plone.app.
  contenttypes because we would lose support for ExternalEditor, this fix
  is done via a jbot override of the original template
- Display fixes in the search app.
  (Refs. #1990)
- Always use the search app, instead of a search on the navigation root
  (Refs. #1990)


1.3.15a1 (2018-07-05)
---------------------

Fixed:

- Markup change requested in
  https://github.com/quaive/ploneintranet.prototype/commit/992bd913a4cffb1a68ae6291e7d4e0bafe3835ff
- Do not break when removing the workspace owner from the team members
  (Refs. #1970)
- cart_mail: Fixed header encodings.
  (Refs #1969)
- Allow clearing workspace email address. #1968

Upgraded:

- collective.auditlog 1.3.3


1.3.14 (2018-06-27)
-------------------

Added:

- Do not show icons for duedate, assignee or initiator in the todo sidebar of
  workspaces if the value is missing.
  (Refs. quaive/ploneintranet.prototype#637)
- Todos sidebar in workspaces shows priority markers too
  (Refs. quaive/ploneintranet.prototype#636)
- Registry setting `ploneintranet.layout.types_not_listed_on_userprofile` allows to
  blacklist certain types in the documents tab on user-profiles.
  (Refs. #1929)

Fixed:

- Do not show images in the @@panel-download-library-content picker
  (Refs. #1964)
- URL conversion when Plone is published in a subpath
  (Refs. #1950)
- Images embedded in TinyMCE edited documents are correctly included
  in the generated PDF
  (Refs. #1947)
- Make stream thread deduplication work properly for tag streams
  (Refs. #1808 and #1937)
- The "date" badge for events in the workspace sidebar now shows the correct date
  for whole-day events.
  (Refs. #1957 and #1398)
- Event edit form: the autosuggest fields that only allow to select a valid user,
  Organiser and Invitees, now don't pretend to accept new terms any more.
  (Refs. #1959)
- Workspaces overview by activity: gracefully skip over stale solr records,
  instead of breaking the view
  (Refs. #1920)

Updated:

- New version of quaive.resources.ploneintranet: 2.2.5
- collective.documentviewer 4.1.0
  (Refs. #1942)
- Products.PrintingMailHost 1.1.0 to work with slc.zopescript
  (Refs. #1952)
  (see https://github.com/collective/Products.PrintingMailHost/pull/5)


1.3.14a4 (2018-06-05)
---------------------

Fixed:

- Translations in the mail sent to the event invitees
  (Refs. #1930)


1.3.14a3 (2018-06-04)
---------------------

Fixed:

- Remove any reference to unittest2
  (Refs. #1935)

Added:

- Improved folder view that shows contents.
  (Refs. #1921)

Technical:

- Make test_nested_uuids deterministic (no ticket ref).
- Make it easier for developers to work on source checkouts: ``make sources``.
  (Refs #1926)
- Update robot framework related packages to test Quaive against the latest Firefox
  (Refs. #1037)


1.3.14a2 (2018-05-30)
---------------------

Added:

- Add the authenticated user fullname after greetings in the email sent
  to the event invitees
  (Refs. #1930)
- Library: provide batching
  (Refs. #1932)

Changed:

- The sender address in the mail sent to the event invitees
  is the authenticated user one and not the site admin one
  (Refs. #1930)

Fixed:

- Security changes are now properly indexed into Solr.
  (Refs. #1912)
- Only workspace admins should be able to delete a workspace.
  (Refs #1922)
- Last element of library breadcrumbs is not a link any more.
  (Refs. #1918)

Technical:

- Make test_nested_uuids deterministic (no ticket ref).


1.3.14a1 (2018-05-22)
---------------------

Added:

- a ``@@wrapped.activitystream.tile`` that can be used in the custom dashboard

Changed:

- the ``@@my_documents.tile`` now also lists News and understands
  ``path`` and ``title`` parameter in the request
- Library: fix links in the library overview that end with double '/view'
- Library: the detail view of a file is now rendered properly, following
  proto. Note that only file types that have a preview are supported by the
  library. For other random types, an extra view would still need to be built
  in proto.
  (See also quaive/ploneintranet.prototype#638)
- Library: implement pills logic from Proto. The navigational pills are only
  shown if there is more than one top level section.
- Library: If the library or a subsection contains only 1 or 2 items, then the
  tiles are displayed with adapted width that gives a more balanced impression
- Technical: The calendar tile is rendered differently
  (Refs. quaive/ploneintranet.prototype#623)

Updated:

- New version of quaive.resources.ploneintranet: 2.2.4

Fixed:

- The email sent to the event invitees contained a wrong end date
- Library: the toggle for adding or removing a library item to/from the list
  of downloads now properly returns feedback in form of a notification with
  a link to the download modal
- Downloading a pdf from the library selection panel was not working anymore
- Render a conversation thread (toplevel + replies) only once, even across
  autscrolling stream expansion.
  (Refs. #1808)
- Incorrect like counts on stream updates were caused by improper view memoization
  (Refs #1808)
- The publicly available "Forgot password" functionality no longer leaks
  the information whether a user account exists or not.
  (Refs. #1879)


1.3.13 (2018-05-10)
-------------------

Changed:

- Change workspace policy wording "outsiders" into "non-members".
  (Refs #1884)
- Show number of group members in workspace header also.
  (Refs #1882)


Updated:

- bcrypt -> 3.1.4
- collective.workspace -> 2.0b3
  (Fixes a migration issue, see collective/collective.workspace#27)
- plone.recipe.zope2instance -> 4.4
- setuptools -> 39.0.1
- zc.buildout -> 2.11.3

Fixed:

- Count workspaces as group members.
  (Refs #1882)
- Fix subrequests for tiles when using _vh_ in rewrites
  (see https://github.com/plone/plone.subrequest/issues/17 for a detailed
  description of the problem)
- Use the standard login form in Barceloneta
  (Refs #1891)


1.3.12.4 (2018-04-30)
---------------------

Fixed:

- bookmarked workspaces tile will not break on stale solr entries
- Restore 'add workspace' policy order, with 'private' as the default option.
  (Refs #1867)

Technical:

- Move 'add workspace' policy explanations from template to python, to facilitate
  easier client customization.
  (Refs CCC#48)


1.3.12.3 (2018-04-27)
---------------------

Changed:

- Do not commit before calling the preview asynchronous generator (#1875)


1.3.12.2 (2018-04-25)
---------------------

Fixed:

- Repaired broken injection on the bulk action for downloading contents.


1.3.12.1 (2018-04-25)
---------------------

Changed:

- Unclutter workspace listing by shortening workspace descriptions.
  (Refs #1798)

Fixed:

- Repaired broken injection on the bulk action to change workflow state.
- Superspace title and description can now be unicode
- Fix translation regression in the worspace types filter


1.3.12 (2018-04-19)
-------------------

Changed:

- In the search results, users and group are united under the facet "People"
- The bulk delete action now moves the selected items to the trash
- The trash sidebar behavior now handles correctly folders
- Due to styling changes, the markup for tabbed modals (create Document/Image),
  (create News item / section) was adapted.
  (Refs. quaive/ploneintranet.prototype@e403ac0)
- Fixed translation regressions

Added:

- Groups in the search results have a preview now (Refs. #1816)
- The workspace view method ``get_principal_roles`` has better documentation,
  tests and a new optional parameter ``omit_default_policy_role``.
- A new solr field ``superspace`` is needed.
- Introduced the concept of super spaces.
  A new solr field ``superspace`` is needed.
- The delete confirmation form is more customizable
- Using the registry record ``ploneintranet.bookmarks.unbookmarkable_types``,
  it is now possible to deactivate the bookmark feature
  for the blacklisted content types
- News items in the news app can now be commented like other content items. If
  a news item has a comment, it will also appear in the general activity stream.
  On the News Magazine view, news items that have comments show an indicator about
  the number of comments.
  Commenting can be disabled via the registry setting
  ploneintranet.news.allow_commenting
  (Refs #1801)

Fixed:

- Adding an event through the calendar app when the site is published
  on a subpath works again (Refs. #1856)
- When viewing an image inside the workspaces, the preview was overriding
  the comment box (Refs. #1854)
- Fix the catalog query that deletes the objects from the trash
- Fix the ``get_timezone_info`` method (Refs. #1829)
- The userprofile count for workspaces and groups has been massivle enhanced
  by removing a call to ``api.group.get_groups``
- Handle special characters in user/group picker
- Retry reindexing binary content in Solr one more time if an error occurs

Updated:

- Updated scorched to version 0.12
- New version of quaive.resources.ploneintranet: 2.2.3.2
- Since this version quaive uses collective.workspace 2.0b2.
  This version changes the way the group mapping is stored,
  so you have to run the related upgrade step.


1.3.11 (2018-03-01)
-------------------

Added:

- The registry records ``ploneintranet.workspace.mailin.folder.id`` and
  ``ploneintranet.workspace.mailin.folder.title``
  can be used to route incoming emails to a specific folder in a workspace.
  You may want to configure this to be the same folder as where the microblog
  attachments are stored. Default behavior remains unchanged (no special folder).
  (Refs. #1114 v3 and CCC#40)
- A first version of the contact app
  (Refs. #51)
- Reenable screenshots on test errors

Changed:

- Speed up the ``plone.anontools`` viewlet when we are not using barceloneta
  and we do not need it

Upgraded:

- Upgrade quaive.resources.ploneintranet to 2.2.1

Changed:

- For performance resons the activity stream is injected in the workspace page
  after the page is loaded

Fixed:

- The link to download a topic as a PDF file was wrongly pointing to the parent
  folder (Refs. #1773)
- Speed improvements: sorting workpaces by most active is faster now
- SECURITY
  When a user gets removed from a workspace, remove all direct access permissions
  from items that this user has created in the workspace.
  Technical: purge Ownership and the local role `Owner`
  (Refs. #1760)
- The personal bar was looking for a not existent attribute
- Show preview of link target in default view (see prototype).
- Fix user-import for csv files with quotes that contain the delimiter.
  (fixes #1767)
- Viewing the library with private sections that contain published content
  could lead to a site-error. Now sections get omitted if user has no view
  permission and a warning is logged (fixes #1759)

Technical:

- Robustify py2/py3 handling of unicode/string in usersync.


1.3.10 (2018-02-08)
-------------------

Added:

- The registry record ``ploneintranet.search.friendly_type_name_mapping``
  can be used to map the developer friendly names in the mimetype registry
  to customer friendly names
  (Refs. #1734 and #1749)

Changed:

- Prepare the search templates for the new search app
  (Refs. #1747)
- Always display the library and news navigation,
  even where there is only one section.
  This restores the behavior we had before PRs #1676 and #1679.
  (Refs. #1741)
- Hidden workspaces are by default not listed
  (Refs. #1740)

Fixed:

- Sidebar document cart actions are enabled only
  when there is some item selected
  (Refs. #1730)
- Events could not be opened from the calendar app if clicktraker is enabled
  (Refs. #1746)
- The news magazine page was injected twice
  (Refs. #1743)
- In the search results page, apps and emails have a proper preview
  (Refs. #1738 and #1748)
- The user profiles, workspaces and apps containers
  are no longer returned in the search results
  (Refs. #1738)
- "Download" link on files in the library section view links to file
  download instead of file/view (fixes #1736)

Upgraded:

- Upgrade quaive.resources.ploneintranet to 2.2.0


1.3.9 (2018-02-01)
------------------

Added:

- Danish translations
- use `SolrMaintenanceView.sync(use_std_log=True)` to log details to
  instance.log that otherwhise would only be written into the response.
  (Useful for usage in cronjobs via slc.zopescript)

Fixed:

- The workspace preview in the search app now understands the registry record
  `'ploneintranet.workspace.workspace_types_css_mapping`
  (Refs. Syslab #16498)
- Improve the upgrade step for "is archived" (skip brain if it is already up-to-date)
- In the add workspace form, when selecting a workspace template
  no notice was shown
- The edit and delete news section panels are compliant with prototype
  (Refs. Syslab #16378)
- In the library detail view, do not show a hero image on a document if we
  have text - since the text (markup) takes precendence over a generated image
- The workspace tiles on the member profile page now work again.


1.3.8 (2018-01-22)
------------------

Fixed:

- When there is no news left to read, display a notice in the news tile.
  Fixes the broken injection after marking the latest news as read
  (Refs. Syslab #16433)
- Do not break if a document version is not present or has no file attached
  (Refs. Syslab #16434)
- The delete confirmation modal for the news was bad looking
  (Refs. Syslab #16378)

Upgraded:

- Upgrade dexterity.membrane to version 2.0.1 to improve speed

1.3.7 (2018-01-15)
------------------

Fixed:

- News must be published before they appear in the tip of the day box
  (Refs. Syslab #16291)
- If the news effective date is not set, do not display the default date
  (December 31, 1969)
  (Refs. Syslab #16383)
- Improved previews in the search results
  (Refs. Syslab #16386
- If a user is not authorized to access the stream, return an empty one
  instead of raising unauthorized
  (Refs. Syslab #16380)


1.3.6 (2018-01-12)
------------------

Added:

- Automatically set the publication date to today when a news is created
  (Refs. Syslab #16383)
- More icons for the tip of the day
  (Refs. Syslab #16343)

Fixed:

- The magazine view only show news that have correct
  publication and expiration dates
  (Refs. Syslab #16383, #16391)
- Fix unicode bug for "request access" email on workspaces with non-ascii.
  (Refs. Syslab #16373)
- Do not break if a non image file is uploaded for an image field
- In the magazine, when no news is published display a proper message
- In the magazine, do not display an empty column
  if we do not have trending news
  (Refs. Syslab #16316)
- The review states for the news allowed in the magazine are configurable
  through the registry
- Fix the injection of the news hero image
  (Refs. #1659)
- Newly created profiles are always synced
  (Refs. Syslab #16252)
- When the user has no right to edit,
  the fields in the news edit form are now all readonly
  (Refs. Syslab #16321)
- The search form excludes the archived documents by default
  but has an option to include them
  (Refs. Syslab #16120)


1.3.5 (2018-01-02)
------------------

Added:

- Missing German translations (grouping labels, download from library)

Fixed:

- Fix the breadcrumbs in the publisher views
  (Refs. Syslab #16315)


1.3.4 (2017-12-21)
------------------

Added:

- If no description is provided, we try to get one from the saved text
  (Refs. Syslab #16324)
- The contacts portlet can now display bookmarked contacts
  (Refs. Syslab #16290)
- Tip of the day
  (Refs. Syslab #16291)
- The dashboard portlet collapsible state is stored in the browser local storage
  (Refs. Syslab #16292)

Fixed:

- Do not render the keywords viewlet in Quaive
- Fix icon url when many classes are present
  (Refs. Syslab #16313)
- Deleting news was not working anymore
  (Refs. Syslab #16312)
- Do not display the library and news navigation when there is only one section
  (Refs. Syslab #16322)
- Prevent double entries in the workflow menu
  (Refs. Syslab #16321)
- Fix following/followers tab injection in the user profile
  (Refs. Syslab #16129)
- The default option in the sidebar grouping select was not always correctly set
  (Refs. Syslab #16121)
- Library sections are sorted by position (Refs. Syslab #16245)


1.3.3 (2017-12-13)
------------------

Added:

- It is now possible to, at the moment of posting a status update in a
  workspace, extract attachments of that status update into files in a
  folder of the workspace, making them searchable and
  manageable. Enabling this requires configuring a registry record, by
  default it is disabled.  When enabled, the folder name into which
  attachments are stored is configurable; the default folder name is
  "INCOMING".
  (Refs. CCC #31)
- It is now possible to show creation dates for stream posts as absolute, rather than
  relative dates. The transition between relative and absolute dates can be configured
  via the registry. This makes it possible to show '3 days ago' for recent posts, but
  show older posts on their exact timestamp instead of all showing 'one year ago'.
  By default, the system shows all stream dates as relative.
  (Refs. CCC #16)

Changed:

- Private workspaces are now listed for non-members on the workspace overview, and searchable
  from the workspace overview (though not in the sitewide search).
  Non-members will be offered to send an email to the site administrator requesting access.
  This requires that the site ``email_from_address`` be configured.
  This listing of private workspaces for non-members can be switched off via a registry setting.
  (Refs. CCC#1)

Fixed:

- UI for setting the sidebar grouping in a workspace is alligned with proto
  (Refs. Syslab #16120)
- Improved the Solr search capabilities.
  This also fixes searching using the OR operator when the Solr default is AND
  (Refs. Syslab #16120)
- Added a button on the library documents which is used to add them to the cart.
  The items downloaded in the PDF are stored in the same cart.
  (Refs. Syslab #15868)
- When clicking on a file title in the library, open the page view
  with the navigator and the previews.
  (Refs. Syslab #15868)
- The UI element to pop up the panel to select the library content is
  allowed only on the library app (Refs. Syslab #15868)
- Validation in the advanced sidebar settings:
  the email domain is stripped by the backend and only the username
  is rendered in the form.
- Facets where shown also if there was just one value to select
- Some workspaces failed to be rendered if no tag was set for a document
- Fix the preview URLs in the library broken on sites served
  as http://example.com/mysite
- Editing the registry record it was possible to completely break the site
- Applied the patch Products.PloneHotfix20171128==1.0
- Do not show previews for unsupported document types.
- In the sidebar settings, disable UI elements we have no permission to use

Upgraded:

- Upgrade quaive.resources.ploneintranet to 2.0.9


1.3.2 (2017-11-25)
------------------

Added:

- Sidebar items are batched
  (Refs. Syslab #16121)

Fixed:

- Resolve user correctly when the login name differs from the userid.
  (Refs. CCC #36)


1.3.1 (2017-11-23)
------------------

Added:

- It is possible to set in each workspace the default grouping for the sidebar.
  (Refs. Syslab #16121)
- Allow to style Workspaces by their division. (tiles have `.division-<id>` css
  class, the division itself `.division-name-<id>`, views have
  `.workspace-division-<id>` and `.workspace-division-name-<id>` respectively)
- Optional UI elements can be turned on in the library
  to enable the download of contents as PDF files
  (Refs. Syslab #15868)
- Batch previews also for images and links

Changed:

- Software tests now use the Solr backend for search, just like a normal site.
- Various performance improvements.

Fixed:

- The message "Preview being generated" was mistakenly appearing
  when visiting images and links.
- Show "External Editor" document action only if external editor is fully
  configured and available
  (Refs. CCC #11)

Upgraded:

- The default Solr version is now the 5.5.1

New dependencies:

- pdfrw (for merging PDFs)

1.3.0 (2017-11-14)
------------------

This is the first release in the new 1.3.x. **Jupiter** release cycle!

Added:

- The search application understands boolean queries (AND, OR, -)
  (Refs. Syslab #16120)

Changed:

- Global search: use the creation date in date-range searches, as the UI has been
  advertising since the beginning, instead of modification date.
  See quaive/ploneintranet.prototype#552
- Technical: Deprecate ploneintranet custom method `get_record_from_registry`
  in favour of the plone.api one.
- Technical: Solr filters are not validated anymore.
  Devs can unleash the power of Solr
  (Refs. QUIP #1582).

Fixed:

- Give Solr a second chance when it is under a heavy load.
  This should be a workaround for the episodical upload errors we see
  when using the upload box
  (Refs. Syslab #15581)
- Avoid a race condition when serving asynchronously previews
  we might not have
  (Refs. Syslab #16047)

Upgraded:

- Upgrade quaive.resources.ploneintranet to 2.0.7 with new diazo rules
  that fix some issues with the help bubbles


1.2.78 (2017-11-08)
-------------------

Added:

- Admin can call /@@pi-refresh-compilations to break the browser caches
  for ploneintranet static resources
  Refs. #1550
- In the Todo App we have an additional header containing the workspace title
  when grouping by "Origin and Milestone" is selected
  (Refs. Syslab #15980)
- Speed optimizations (improved the cache in the @@proto view)

Changed:

- Events now have a one state workflow so they are visible to all workspace
  members. If you assigned a custom workflow to events make sure you re-assign
  it after running the upgrade step ploneintranet.workspace.upgrades.to_0029.
  Fixes #1560
- Technical: Update setuptools
- Workspace sidebar for documents: When the user enters a grouping (e.g. by type,
  by 1st letter, ...), the title over the items now shows the selected grouping.
  Fixes #1545
- Workspace sidebar for documents: On the top level, the title (of the workspace)
  is NOT shown any more. It was never meant to be.
  See quaive/ploneintranet.prototype#550

Fixed:

- The search results page displays the proper icon for RTF documents
- Technical: Pin rubygems to 2.6.14
- Hide the checkboxes in the search results facets column.
  (Refs. Syslab #16065)
- The search application respects the `plone.types_not_searched`
  registry record.
  (Refs. Syslab #16063)
- It was not possible to save multiple times a news in the news publisher.
  Technical: the workflow menu (containing the dx_modified time stamp,
  was not reinjected)
  (Refs. Syslab #15967)
- #1480: Abort @@sync-users if LDAPUserFolder returns 0 results (most probably
  due to a timout) instead of disabling all users
- #1529: adding events from the calendar was not possible due to a server error
- The trash can be cleared regardless of the link integrity checks.
  (Refs. Syslab #16090)
- #1537: the library sections are sorted according to their position
  in the CMS Folder.
  This feature was mistakenly removed while implementing #1478.
- Workaround to not show the "Agenda items" field,
  which is not working, in the calendar add event tooltips.
  (Refs. quaive/ploneintranet.prototype#551)
- Added the "Back to portal" help bubble and restored the "Menu toggle" bubble
  (Refs. Syslab #16025)
- Favicon support has been extended to mobile devices
  (Refs. Syslab #15981)
- Technical: the upgrade step to add the trashed index
  commits every 100 objects and temporarily disable Solr
- Fix loading previews in Safari if document is loaded directly
- Add missing legacy content types for Powerpoint files
- Prevent the sidebar from breaking if Missing Values come from the catalog,
  Syslab #16061
- Keep tags and other groupings when moving object to/from a subfolder.
  Technical: Use groupings in parent workspace, not in acquisition parent.
  (Refs Syslab #16071)


1.2.77 (2017-10-25)
-------------------

Fixed:

- Trash actions will inject the sidebar for a better user experience
- The logo was misplaced if the site title was composed of more than one word
- Fix "Cannot delete News" problem (Syslab #16034)
  Technical: make todo action storage more robust against not found action
- Upgrade the theme package to include the latest IE11 fixes
- Cosmetic fixes for "rename folder" and "add news" panels
- DE translation fixes


1.2.76 (2017-10-23)
-------------------

Fixed:

- Reindex the trashed index after install
- Improvements to the trash bin views


1.2.75 (2017-10-23)
-------------------

Fixed:

- In the Security sidebar of workspaces, don't show "Guest" as a participant policy.
  It was never intended to be explicitly selectable.
- In the "Security" tab of a workspace, add explanation about the nature of the
  participant policy which was present in proto but missing here.
- In the library, the previews of items are shown again (they had
  gotten lost in #1478). Fixes #1528


1.2.74 (2017-10-18)
-------------------

Fixed:

- Technical: don't fail when buildling a catalog SearchResponse if a catalog
  value is a list type


1.2.73 (2017-10-11)
-------------------

Added:

- Do not allow to edit avatar image if `portrait` is listed in
  `ploneintranet.userprofile.read_only_fields` (refs #1522)
- Popup to download files from the document sidebar
  (Refs. Syslab #15521)
- Trash can
  (Refs. Syslab #13944)

Fixed:

- The context menu on workspace document was not closing when opening
  the version history
- Add document popup was missing padding between inputs
- Fix groups search in sharing tab of CMS
  (Refs. Syslab #15746)
  Technical: Update Products.membrane
- Saving news was broken since the recent modification
  in the workflow drop-down
  (Refs. #1508).
- Do not break if the user asks for an impossible workflow transition,
  mainly happens when the workflow badge is not up-to-date with the document
  state

Upgraded:

- Upgrade quaive.resources.ploneintranet to 2.0.5
  to use the webpack generated bundle and the latest prototype
- Upgraded the buildout related packages for speed improvements


1.2.72 (2017-09-22)
-------------------

Added:

- Added a search box to search the library
  (Refs. Syslab #15830)
- We can sort for more than one field when querying Solr
- Added an ``extra-fields-bottom`` slot to the ``event_fields`` macro
  to allow form customizations in custom packages
  (Refs. Syslab #15842).

Fixed:

- The workspace calendar is accessible also on mobile
- The add folder modal panel has now a title and some padding
  that improves the look and feel
  (Refs. #15905)
- The user edit form autosaves changes
  (Refs. Syslab #15688)
- The user sync was failing when logging the sync informations (#1491)
- The user modal panel in the administration tool was not looking good
- The activity stream modals for editing a post or a comment
  are now compliant with prototype and displays a title
  (Refs. Syslab #15824)
- The activity stream modals for deleting a post or a comment
  are now compliant with prototype
  (Refs. Syslab #15824)
- The add user modal now displays the title
  (Refs. Syslab #15824)
- The "Info" tab of "My profile" displays also the groups I belong to
  (Refs. Syslab #15688)
- Library navigation was not highlighting the proper tab
  (Refs. Syslab #15869)
- The upgrade step to create the todo app could break
  if the original dummy app was deleted
- Prevent possible write on read when adding status update attachments
- When clicking on the "Create new task" button in the sidebar,
  the add task form was not appearing due to a broken injection
  (Refs. Syslab #15847).
- Membership roster in workspace sidebar now also shows other workspaces that
  are members correctly as groups
- Translation: The email subject of the "Welcome to the site" mail can now
  be translated
- AD/LDAP sync only (re-)sets profile image when it changed (previously a new blob
  has been created on every sync bloating the database)

Upgraded:

- Upgrade quaive.resources.ploneintranet to 2.0.3
  to use the webpack generated bundle and the latest prototype

Changed:

- Technical: in workflow drop-downs, the `value` property for the current state,
  which used to be empty (nothing to do) is now filled with the id of the current
  state, which in turn will land in the data-option-value property of the select.
  This means that it can be used for styling, independently of translations.


1.2.71 (2017-08-30)
-------------------

Added:

- The time interval before autosaving a document can be configured through the
  registry record ``ploneintranet.workspace.autosave_delay``
  (Refs. Syslab #15821).
- The help bubbles behavior can now be controlled through the registry record
  ``ploneintranet.layout.bubbles_enabled``
  (Refs. Syslab #15824).

Changed:

- The alphabetical sorting of users in the administrator app now happens by
  last name, instead of by first name
  (you'll need to run Plone/profiles/solr-maintenance/reindex to update the
  solr index of sortable_title)
- In the workspace sidebar (members tab), users are now sorted alphabetically
  by last name

Upgraded:

- Upgrade to Plone 5.0.8


1.2.70 (2017-08-28)
-------------------

Added:

- Techical: Added the API method ``ploneintranet.api.get_userids`` that returns
  all the known userprofiles id in the site
- #1417 Initial support for the user help bubbles
- Preparation for Quaive: If ``quaive.app.onlyoffice`` is installed and configured
  and the user has the right permissions, files can be edited with ONLYOFFICE.
- #1435 AD/LDAP sync can now also fetch portrait images
- #1427 More flexible external app apps. The apps have now a new ``external`` boolean field.
- #1429 The site search now looks into more user profile fields:
  (person_title, department, address, ...)
- Technical: Added an optional parameter in the search utility query method that allows
  the backend to perform unrestricted searches.

Changed:

- #1419 quaive.resources.ploneintranet is now updated to version 1.3.26.
  This version contains the new prototype pages for the absence app,
  improvements for handling panels and minor javascript fixes.
- Technical: #1420, #1421, #1424, #1425 Continued the technical activity on modal panels
  done in 1.2.69.
- d6528a Technical Setup: Bumped setuptools
- #1426 Technical Setup: Improved jenkins bootstrap script.
- Technical; AD/LDAP sync views return logging information to give users detailed feedback
  (can be turned off by appending `@@sync-users?quiet=True` or adding it as
  parameter to the view's call method `view(quiet=True)`)
- Technical: AD/LDAP sync view use `Manage users` and `Manage Groups` permission
  so they can be used w/o `Manage portal` permission.

Fixed:

- Speed Improvement: #15789 Optimized a method in the todo utility that allows saving news faster.
- Issue #1445: the delete workspace modal panel was not displaying properly
- Bookmarked projects did not have an icon in the bookmark app.
- Bookmark icon for word files in the "Documents" tab of the bookmark app.
- #1422 Fix a pop up in the post form that was not closing itself after
  the user clicked on its actions.
- #1423 In the Administrator Tools app,
  the new user state was not displayed correctly.
  The patch fixes the injection parameters.
- #1430 Activitystream: fixed an encoding problem happening when a file
  with non ASCII charactes in the name was uploaded
  as a comment attachment.
- Technical: #1431 a logical bug was preventing the upgrade step to run properly.
- Translation: change title of a Case transition, to avoid a semantic
  translation conflict
- Fix redactor editor <hr> button.
- User attributes synced from AD are now properly turned into unicode
- Group members synced from AD don't break anymore if uids with unicode are within.


1.2.69 (2017-07-24)
-------------------

Changed:

- Make it easier and more streamlined for developers to create modals #1412.
  Technical: modal panels now have their own base template `panel_template`
- Speed improvements for the user profile page #1415.
  Technical: optimize use of `_update_recent_contacts` and `_get_my_groups_and_workspaces`
- Translation changes (email template) #1414


1.2.68 (2017-07-20)
-------------------

Changed:

- #1411 Technical Setup: Improved Build.
  Bumped setuptools
- #1410 User profile: Provide links for the mail, location and phone fields
- #1407, #1408 User profile: Moved group overview to user info tab
- #1407 User profile: Don't show empty fields. Show link to profile as first field.

Fixed:

- #1409 Events: Removed start/end time fom notification mail for all-day events


1.2.67 (2017-07-06)
-------------------

Fixed:


- #1405 Change task portlet link


1.2.66 (2017-07-05)
-------------------


Added:

- #1401 Todo app: Localize pat-display-time for due date and add a meaningfull title (Due date)
- #1395 Extract stream attachments to content, so they will be indexed


Changed:

- #1402 Increase the generated thumbnail size for documents
- #1399 Fix add task form speed
- #1397 Dashboard tasks portlet: add link from heading to task app
- #1394 Update modal markup to match proto
  This adds a class "container" to the modals panel


Fixed:

- #1403 Do not display unauthorized apps
- #1400 Todo app: Fix issue with safari
- #1398 Events tile: fixes a bug for whole-day events for all timezones east of UTC
  Work with full objects everywhere.
- #1396 (SLC #15523) Dashboard: Fix Tasks portlet for personal tasks assigned to me
  Now that we have personal tasks (= without workspace as context), the portlet on the dashboard needs to be able to handle them, too.


1.2.65 (2017-06-22)
-------------------

Added:

+++ MILESTONES IN CASES

- # 1367
- Cases can now be extended with a setting to enable milestone support. This will show due dates in the metro-map and overdue tasks.


+++ TODO APP

- #1376 #1379 #1383 #1385 #1387
- A new app that shows all Tasks that concern me in a structured and condensed way.
- The concept of "personal tasks" is introduced; they are not located in any workspace, but directly in a user profile.



Changed:

- #1392 Usability: Give clearer feedback to users about locked documents & offer a link for reloading
- Translation updates (Tasks, milestones, agenda items)
- #1000 Technical: Split ./dev/ from ./src/ to simplify code analysis


Fixed:

- Link the avatar of following / followed users to the respective user profile #1388
- Fix a bug in fetching personal tasks #1391
- Usability: stay in the current context when a Task was deleted #1386
- Usability: removed the unwanted "you have been logged in" message #1389
- Usability: Make sure avatars have the correct size on user searches #1390
- Fix a bug in the sidebar search in workpaces #1382
- Fix a bug that caused the sidebar to disappear when a Task was viewed #1380
- Typo in the documentation


1.2.64 (2017-06-14)
-------------------

- Merge pull request #1364 from quaive/fix-date-format-in-sidebar [GitHub]
- Merge pull request #1365 from quaive/milestones-featureflag [GitHub]
- Merge pull request #1366 from quaive/1337_fix_locking [GitHub]
- Merge pull request #1354 from quaive/todo-app-manual [GitHub]
- Merge pull request #1357 from quaive/library-folders-ordering [GitHub]
- Merge pull request #1363 from quaive/translate-dates-in-metromap [GitHub]
- Pull in latest q.r.p. fixes #1337 [Guido A.J. Stevens]
- Include quaive.app.milestones (refs #649) [Harald Friessnegger]
- Fix date format in the sidebar [ale-rt]
- Merge pull request #1361 from quaive/admin-locking-fixes [GitHub]
- Merge pull request #1362 from quaive/app-default-view [GitHub]
- Properly translates the dates in the metromap [ale-rt]
- Do not show the default dexterity view when visiting an app [ale-rt]
- Do not lock admin [ale-rt]
- Merge pull request #1360 from quaive/agenda-items [GitHub]
- Introduce the concept of agenda items [ale-rt]
- Merge pull request #1358 from quaive/release-1.2.x [GitHub]
- document the new registry record [Wolfgang Thomas]
- Add upgrade step for the registry record [Wolfgang Thomas]
- When an item gets published widely (to library), re-order the library folder to show the last modified first, if the respective registry setting is enabled [Wolfgang Thomas]
- Back to development: 1.2.64 [Wolfgang Thomas]
- WIP for the application manual [ale-rt]


1.2.63 (2017-06-08)
-------------------

- Merge pull request #1355 from quaive/release-1.2.x [GitHub]
- Merge pull request #1356 from quaive/translations_lock_and_todo_app [GitHub]
- Merge pull request #1334 from quaive/reload_hero_image [GitHub]
- Remove plural for Initiator and Assignee [ale-rt]
- Stricter check for hero_image [ale-rt]
- Reload hero image when changing it. [ale-rt]
- Rename tickets -> tasks [ale-rt]
- Rename tickets -> tasks [ale-rt]
- added translations for document lock messages (#15361) and todo app (#14916). changed i18n domain to ploneintranet for app-results.pt [Angela Steinhardt]
- Back to development: 1.2.63 [ale-rt]


1.2.62 (2017-06-07)
-------------------

- Merge pull request #1352 from quaive/todo-app-columns [GitHub]
- Merge pull request #1351 from quaive/translate-calendar-tile [GitHub]
- Merge pull request #1348 from quaive/locking-improvements-2 [GitHub]
- Merge pull request #1350 from quaive/deactivated-users-2 [GitHub]
- The displayed column depend on the browse mode [ale-rt]
- Do not allow saving and old version of the document [ale-rt]
- Merge pull request #1347 from quaive/locking-improvements [GitHub]
- Translate the calendar tile [ale-rt]
- We do not display anymore a message when locking/unlocking a document [ale-rt]
- Allow unlocking even if we cannot modify anymore the object [ale-rt]
- Do not allow saving if the document is locked [ale-rt]
- Unlock the object before renaming [ale-rt]
- Check lock ownership before unlocking [ale-rt]
- The toggle lock also returns the saving badge [ale-rt]
- Update js bundle [ale-rt]
- Only active aka enabled users can be mentioned Refs #1343 [Wolfgang Thomas]
- already filter by review state when searching, but leave option to pass a different state to get_user_suggestions [Wolfgang Thomas]
- Merge pull request #1349 from quaive/fix-multiupload [GitHub]
- Merge pull request #1344 from quaive/1343-dont-suggest-deactivated-users [GitHub]
- Remove the transaction begin call [ale-rt]
- Merge pull request #1346 from quaive/update-setuptools [GitHub]
- Update setuptools Jenkins master currently barfs because of it [Wolfgang Thomas]
- Merge pull request #1345 from quaive/use-compiled-python [GitHub]
- Use the compiled Python [ale-rt]
- Merge pull request #1342 from quaive/more-powerful-todo-app [GitHub]
- Merge pull request #1341 from quaive/920-youtube-embed [GitHub]
- Merge pull request #1340 from quaive/release-1.2.x [GitHub]
- the api method get_user_suggestions only returns users that are enabled Refs #1343, the first item [Wolfgang Thomas]
- Split the search results in a smaller view [ale-rt]
- Show the reset button [ale-rt]
- Fix add task in workspace [ale-rt]
- Add a reference to the issue [ale-rt]
- Filter by assignee [ale-rt]
- Filter by initiator [ale-rt]
- Filter by due date [ale-rt]
- Implement grouping [ale-rt]
- Added the personal-tasks view [ale-rt]
- My tasks view [ale-rt]
- Prepare the solr search for the todo app [ale-rt]
- Priority should be reversed [ale-rt]
- Search result limit [ale-rt]
- Fix priority selector [ale-rt]
- Default priority [ale-rt]
- Proper priority class [ale-rt]
- Allow iframe, and explicitly allow youtube and vimeo embedded content [Wolfgang Thomas]
- Back to development: 1.2.62 [Manuel Reinhardt]


1.2.61 (2017-05-31)
-------------------

- Merge pull request #1339 from quaive/more-powerful-todo-app [GitHub]
- Merge pull request #1338 from quaive/update-proto [GitHub]
- Update the prototype [ale-rt]
- New fields needed byt the task app [ale-rt]
- Test search filters [ale-rt]
- Implement review_state filter [ale-rt]
- Understand the concept of grouping [ale-rt]
- Implemented basic sort mode [ale-rt]
- Updating the tests [ale-rt]
- Handle redirect after a todo is cancelled [ale-rt]
- Close the panel when clicking Cancel [ale-rt]
- Add workspaces tasks from the sidebar [ale-rt]
- Merge pull request #1335 from quaive/todos-in-userprofile [GitHub]
- Update the prototype [ale-rt]
- Merge pull request #1324 from quaive/pat-doclock [GitHub]
- Fix robot test [ale-rt]
- Merge pull request #1333 from quaive/shorten-event-desc [GitHub]
- Test app todo [ale-rt]
- Fix styles in FF [ale-rt]
- Sort search results by default on sortable title [ale-rt]
- Implement state toggle from the sidebar [ale-rt]
- Added a should_update method [ale-rt]
- Fix link visibility [ale-rt]
- Use the app in the sidebar [ale-rt]
- Fix form defaults [ale-rt]
- Fix sidebar-toggle-button missing in tests [ale-rt]
- Fixup [ale-rt]
- Todo app view and basic operations [ale-rt]
- The userprofile container view now has method to return the users and their fullname [ale-rt]
- Create the todo app [ale-rt]
- WIP [ale-rt]
- Add the label current to the first tab [ale-rt]
- Right conditions to show the sidebar [ale-rt]
- The AddTask view works in the context of a userprofile [ale-rt]
- Fixup todo_view [ale-rt]
- Moved the add_task view to ploneintranet.todo for better testing [ale-rt]
- WIP [ale-rt]
- Use the get_data_pat_autosuggest method [ale-rt]
- Added a method to get a properly formatted data-pat-autosuggest [ale-rt]
- Added a method to get a properly formatted data-pat-autosuggest [ale-rt]
- Added a user property in the base view [ale-rt]
- Use the sidebar toggle button [ale-rt]
- The class visible should be set by pat-stack [ale-rt]
- The sidebar toggle button has its own view [ale-rt]
- Workspace should be a property [ale-rt]
- The class current will be set by pat-tab [ale-rt]
- Upgrade profile to have todo inside userprofiles [ale-rt]
- Prepare for pat-doclock [ale-rt]
- Merge pull request #1331 from quaive/fix-barceloneta [GitHub]
- Show shortened event description in workspace calendar sidebar. [Manuel Reinhardt]
- Fix the todo view in barceloneta [ale-rt]
- Fix breadcrumbs in barceloneta [ale-rt]
- Merge pull request #1332 from quaive/new-proto [GitHub]
- Compile the date field first [ale-rt]
- Merge pull request #1321 from quaive/new-proto [GitHub]
- Merge pull request #1329 from quaive/catch-error-on-posting [GitHub]
- Merge pull request #1328 from quaive/heisenbug [GitHub]
- Update selector for tabs [ale-rt]
- Catch DuplicateIDError [ale-rt]
- Fix heisenbug Alice can submit a post with a file attachment [ale-rt]
- Update proto [ale-rt]
- new release of q.a.r [Wolfgang Thomas]
- Fix an issue spotted by Cornelis [Wolfgang Thomas]
- Close the calendar before submitting [ale-rt]
- Merge pull request #1325 from quaive/release-1.2.x [GitHub]
- Update robot tests for the new modals [ale-rt]
- Use new resource package [ale-rt]
- New splashpage markup [ale-rt]
- Back to development: 1.2.61 [ale-rt]


1.2.60 (2017-05-22)
-------------------

- Merge pull request #1318 from quaive/implement-locking-chat-button [GitHub]
- Add DE trsanslations (also for previous PRs) [Wolfgang Thomas]
- ran .synci18n [Wolfgang Thomas]
- added missing i18n:domain [Wolfgang Thomas]
- Use i18n labels for the sentences, so that we can easily change the English texts in the future without invalidating the translations [Wolfgang Thomas]
- Change 1 label to be consistent with existing translations [Wolfgang Thomas]
- Fix nesting error (no dl inside p), since synci18n chokes on that [Wolfgang Thomas]
- Merge pull request #1319 from quaive/preserve-template-state [GitHub]
- Merge pull request #1316 from quaive/blue-quaive [GitHub]
- Preserve the template review state when creating a WS from a template [ale-rt]
- Enable the chat button in the lock information panel [ale-rt]
- Implement the locking UI [ale-rt]
- Increase the timeout so that the build will not fail when downloading big eggs [ale-rt]
- Upgrade the theme to have it blue [ale-rt]
- Merge pull request #1315 from quaive/simplify-diazo-rules [GitHub]
- Merge pull request #1314 from quaive/785-fix-missing-fullname [GitHub]
- Merge pull request #1313 from quaive/sidebar-groups-knows-workspaces [GitHub]
- Merge pull request #1311 from quaive/1284-solr-default-path [GitHub]
- Search result templates [ale-rt]
- Merge pull request #1312 from quaive/contacts-portlet-improved [GitHub]
- Display the userid if fullname is missing [ale-rt]
- Show workspace title [ale-rt]
- The contacts tile links the app only if it is not disabled [ale-rt]
- Do not show disabled users in the contacts portlet [ale-rt]
- Merge pull request #1310 from quaive/section-is-none [GitHub]
- If no path is set, limit the search results to the current site [ale-rt]
- Merge pull request #1306 from quaive/documentation [GitHub]
- Do not break the news view if no section has been set [ale-rt]
- Merge pull request #1309 from quaive/handle-errors-when-changing-policy [GitHub]
- Handle errors on policy change [ale-rt]
- Merge pull request #1308 from quaive/dahsboard-read-persistent [GitHub]
- [ci skip] Documentation update [ale-rt]
- Do not show the splashpage if it marked as read on the user profile [ale-rt]
- Merge pull request #1307 from quaive/update-versions [GitHub]
- Update the coverage script [ale-rt]
- Merge pull request #1305 from quaive/update-resources [GitHub]
- Update the resource package [ale-rt]
- Merge pull request #1303 from quaive/698-translate-warning [GitHub]
- Merge pull request #1304 from quaive/update-mustread [GitHub]
- Translate pat-validation errors [ale-rt]
- update mustread (new database schema and init-mustread-db view) [Harald Friessnegger]
- Merge pull request #1300 from quaive/always-upload-files-or-images [GitHub]
- Merge pull request #1296 from quaive/fix-bookmark-order [GitHub]
- Merge pull request #1294 from quaive/release-1.2.x [GitHub]
- Merge pull request #1301 from quaive/experimental-publistraverse-11 [GitHub]
- experimental.publishtraverse = 1.1 [Maurits van Rees]
- Always upload files or images [ale-rt]
- Merge pull request #1297 from quaive/update-resources [GitHub]
- Merge pull request #1295 from quaive/app-tile-svg [GitHub]
- Merge pull request #1298 from quaive/remove-monkey-patch [GitHub]
- Properly sort recent bookmarks [ale-rt]
- Remove obsolete monkeypatch [ale-rt]
- Update quaive.resources.ploneintranet [ale-rt]
- Back to development: 1.2.60 [ale-rt]
- Test unavailable apps [ale-rt]


1.2.59 (2017-05-08)
-------------------

- Merge pull request #1290 from quaive/remove-unused-template [GitHub]
- Merge pull request #1289 from quaive/upgrade-quaive.app.audit [GitHub]
- Merge pull request #1293 from quaive/app-tile-svg [GitHub]
- Update element selector [ale-rt]
- Handle correctly the modal in the apps view [ale-rt]
- Use the latest resources [ale-rt]
- Upgrade quaive.app.audit [ale-rt]
- Remove unused template [ale-rt]
- Use svg in the app tiles [ale-rt]
- Merge pull request #1277 from quaive/user-management-app [GitHub]
- Users activated on creation [ale-rt]
- Sorting by last login time [ale-rt]
- Sort user by review_state [ale-rt]
- Sort the users by reverse creation date [ale-rt]
- Create user panel [ale-rt]
- User management [ale-rt]
- Merge pull request #1281 from quaive/fix-injection-parameters [GitHub]
- Fix injection parameters [ale-rt]
- Merge pull request #1280 from quaive/update-quaive-app-packages [GitHub]
- Merge pull request #1279 from quaive/release-1.2.x [GitHub]
- Latest versions for quaive.app.- packages [ale-rt]
- Back to development: 1.2.59 [ale-rt]


1.2.58 (2017-05-02)
-------------------

- Merge pull request #1278 from quaive/fix-injection-parameters [GitHub]
- Merge pull request #1275 from quaive/improve-search [GitHub]
- Merge pull request #1276 from quaive/simplify-diazo-rules [GitHub]
- Fix injection parameters [ale-rt]
- Improve the search views [ale-rt]
- Simplify the diazo rules [ale-rt]
- Merge pull request #1274 from quaive/improve-navigation-tabs [GitHub]
- Merge pull request #1273 from quaive/response-length [GitHub]
- Merge pull request #1265 from quaive/autosave [GitHub]
- Improve navigation tabs [ale-rt]
- Make len(response) work [ale-rt]
- Improve autosaving [ale-rt]
- Merge pull request #1269 from quaive/fix-continuos-renaming [GitHub]
- Merge pull request #1267 from quaive/undo-redo [GitHub]
- Merge pull request #1272 from quaive/sortable-title [GitHub]
- Merge pull request #1271 from quaive/search-response-truth-value [GitHub]
- Added the sortable_title index [ale-rt]
- Check the truth value of a search response [ale-rt]
- Merge pull request #1270 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.58 [Manuel Reinhardt]
- Fix continuos renaming [ale-rt]
- Make it possible to customize data-pat-redactor via Python code [ale-rt]


1.2.57 (2017-04-27)
-------------------

- Merge pull request #1261 from quaive/fix-subjects-widget [GitHub]
- Removed obsolete CommaSeparatedWidget. [Manuel Reinhardt]
- Use comma as separator for subjects field. [Manuel Reinhardt]
- Merge pull request #1264 from quaive/profiles-redirect [GitHub]
- Profile container default view [ale-rt]
- Merge pull request #1262 from quaive/milestone-options [GitHub]
- Merge pull request #1260 from quaive/fix-calendar-more-menu-as-anonymous [GitHub]
- Merge pull request #1259 from quaive/update-versions [GitHub]
- Merge pull request #1258 from quaive/release-1.2.x [GitHub]
- Easy customizable milestone options [ale-rt]
- Only authenticated users can subscribe to a calendar [ale-rt]
- Update collective.auditlog [ale-rt]
- Back to development: 1.2.57 [ale-rt]


1.2.56 (2017-04-12)
-------------------

- Merge pull request #1257 from quaive/webcal_https [GitHub]
- Merge pull request #1256 from quaive/import-user-improvements [GitHub]
- for the WebCal URL, use 'webcals' in case we're browsing via https [Wolfgang Thomas]
- Make importing users also work for files created in a Windows environment [Wolfgang Thomas]
- Merge pull request #1255 from quaive/release-1.2.x [GitHub]
- Merge pull request #1254 from quaive/translate_custom_ws_types [GitHub]
- Back to development: 1.2.56 [Manuel Reinhardt]
- Use the Title() method on fti, since this will ensure that a Message (from i18nmessageid) will be created, allowing to translate it. [Wolfgang Thomas]


1.2.55 (2017-04-06)
-------------------

- Merge pull request #1253 from quaive/fix-empty-tag [GitHub]
- Bulk change metadata: Don't create an empty tag if the tag field is empty. [Manuel Reinhardt]
- Merge pull request #1252 from quaive/allow-hiding [GitHub]
- Merge pull request #1251 from quaive/q.a.milestones [GitHub]
- Merge pull request #1250 from quaive/translations_stream_like [GitHub]
- Allow hiding even if portlet is not resizable [ale-rt]
- Add q.a.milestones to sources [Wolfgang Thomas]
- Merge pull request #1249 from quaive/news-item-portlet [GitHub]
- added translation for liked by statement #14904 [Angela Steinhardt]
- temporary status [Angela Steinhardt]
- Reinject the whole portlet [ale-rt]
- Load tiles in order [ale-rt]
- Merge pull request #1247 from quaive/custom-dashboard-fixes [GitHub]
- Merge pull request #1246 from quaive/liked-by [GitHub]
- Merge pull request #1245 from quaive/lofi-quaive [GitHub]
- Adding tweaks for portlet customizations [ale-rt]
- Added a liked by prefix [ale-rt]
- Fix ip separator [ale-rt]
- Merge pull request #1244 from quaive/lofi-quaive [GitHub]
- Do not autoload previews on slow networks [ale-rt]
- Disable previews on slow networks for content updates [ale-rt]
- Image preview for posts with images [ale-rt]
- Image preview for posts with attachments [ale-rt]
- The preview size is enough for everybody [ale-rt]
- Do not show content updates previews if the network is slow [ale-rt]
- Anti if campaign [ale-rt]
- Do not show image previews in comment if is slow [ale-rt]
- Do not show preview for image contents in the stream [ale-rt]
- Check is_slow [ale-rt]
- Understand slow ips [ale-rt]
- Merge pull request #1243 from quaive/translations_various [GitHub]
- Merge pull request #1242 from quaive/release-1.2.x [GitHub]
- added translations for stream and other small missing tokens [Angela Steinhardt]
- changed domain (removed "plone") to get create event translated [Angela Steinhardt]
- added missing i18n statement [Angela Steinhardt]
- added end tal:replace for some statements to make i18ndude to accept the file. [Angela Steinhardt]
- Back to development: 1.2.55 [ale-rt]


1.2.54 (2017-03-30)
-------------------

- Merge pull request #1241 from quaive/update-versions [GitHub]
- Merge pull request #1240 from quaive/add-event-defaults [GitHub]
- Merge pull request #1239 from quaive/statusupdate-image-large [GitHub]
- The dashboard should be scrolled two times [ale-rt]
- Update versions [ale-rt]
- Mark recent test regression as unstable refs #607 (#608) [ale-rt]
- Fix default dates for the add event view [ale-rt]
- Merge pull request #1237 from quaive/fix-upload-on-first-comment [GitHub]
- Merge pull request #1236 from quaive/improve-news-tile [GitHub]
- Merge pull request #1232 from quaive/display-likers [GitHub]
- Serve the image large even if it smaller thenm expected [ale-rt]
- Fix attachments upload on first comment [ale-rt]
- Improve the first news image size [ale-rt]
- Merge pull request #1231 from quaive/first-comment-box [GitHub]
- Merge pull request #1235 from quaive/mark-heisenbug [GitHub]
- Make todos commentable [ale-rt]
- Include first comment box [ale-rt]
- Added a box to initialize comments [ale-rt]
- Initialize the attachment storage when creating a status update (Fixes #1230) [ale-rt]
- Cache methods called multiple times [ale-rt]
- Mark Alice can attach a file to a post as an Heisenbug [ale-rt]
- Mark Alice can attach a file to a post as an Heisenbug [ale-rt]
- Display likers [ale-rt]
- Mark Alice can attach a file to a post as an Heisenbug [ale-rt]
- Merge pull request #1221 from quaive/batch-activity-stream [GitHub]
- Sometimes the element is visible but covered by some tile injected on the dashboard [ale-rt]
- Merge pull request #1227 from quaive/enhance-htmlconverter [GitHub]
- Merge pull request #1228 from quaive/proto-friendly-type [GitHub]
- Image compression may return different results on different platforms [ale-rt]
- Wait for injection to be finished after the update is posted [ale-rt]
- Remove stamp right from the activity stream [ale-rt]
- We have to scroll to see the content [ale-rt]
- Only 5 activities at once [ale-rt]
- HTMLConverter now understands image scales [ale-rt]
- Merge pull request #1226 from quaive/1225-fixheisenbug [GitHub]
- Prevent the warning "Unrecognized friendly type: file" [ale-rt]
- Attempt to fix the heisenbug "User can access the calendar app" [ale-rt]
- Merge pull request #1224 from quaive/ui-improvements [GitHub]
- Merge pull request #1223 from quaive/no-bookamrks-notification [GitHub]
- Merge pull request #1222 from quaive/feeditems-images [GitHub]
- Do not render empty li [ale-rt]
- No bookmarks notification [ale-rt]
- Image mini is enough in the news edit form [ale-rt]
- Use the proper scale for each news level [ale-rt]
- Remove static folder (the same content is in the theme) [ale-rt]
- Merge pull request #1220 from quaive/versioning-permissions [GitHub]
- Merge pull request #1219 from quaive/news-batching [GitHub]
- Do not show  the versioning fieldset if we have not enough permissions [ale-rt]
- Icon tasks [ale-rt]
- Batch the news [ale-rt]
- Merge pull request #1217 from quaive/redactor-image-large [GitHub]
- Merge pull request #1216 from quaive/batch-previews [GitHub]
- Link image large with pat-redactor [ale-rt]
- Batch document previews [ale-rt]
- Merge pull request #1214 from quaive/plone-5.0.7 [GitHub]
- Upgrade to Plone 5.0.7 [ale-rt]
- Merge pull request #1212 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.54 [ale-rt]


1.2.53 (2017-03-17)
-------------------

- Merge pull request #1211 from quaive/token-protected-ics_export [GitHub]
- Merge branch 'master' into token-protected-ics_export [Alexander Pilz]
- Merge pull request #1210 from quaive/bulk-change-metadata [GitHub]
- Add a bulk action to change metadata [ale-rt]
- Added an update_groupings method [ale-rt]
- Refactor final redirect [ale-rt]
- Optimize the catalog queries [ale-rt]
- Refactor the grouping storage [ale-rt]
- Optimize catalog queries [ale-rt]
- Refactor item_by_permission [ale-rt]
- Refactor workspace property [ale-rt]
- Merge pull request #1209 from quaive/release-1.2.x [GitHub]
- Merge pull request #1208 from quaive/fix-sidebar-todos [GitHub]
- Back to development: 1.2.53 [Manuel Reinhardt]
- Fix todos in sidebar [ale-rt]
- Cleanup the template [ale-rt]
- Create a token protected ics_export [ale-rt]


1.2.52 (2017-03-16)
-------------------

- Merge pull request #1207 from quaive/restore-autoform [GitHub]
- Merge pull request #1205 from quaive/news-tile-large-preview [GitHub]
- Don't assume we get a dotted name; it could be a ParameterizedWidget. [Manuel Reinhardt]
- Revert "remove broken workaround" to restore autoform directives support [Manuel Reinhardt]
- Merge pull request #1200 from quaive/unify-pts [GitHub]
- Merge pull request #1202 from quaive/fix-attributeerror [GitHub]
- Large preview for the first image when portlet spans on more columns [ale-rt]
- Merge pull request #1201 from quaive/1115_stream_filters [GitHub]
- Fix attribute error when annotation storage is not initialized yet [ale-rt]
- Cleanup TAL, refs #1115 [Guido A.J. Stevens]
- Use one page template for ws and cases [ale-rt]
- Merge pull request #1198 from quaive/understand-container [GitHub]
- Merge pull request #1199 from quaive/1115_stream_filters [GitHub]
- Fix posting.robot to not assume the "all" stream by default, refs #1115 [Guido A.J. Stevens]
- Add testcoverage on stream filters and fix regressions, fixes #1115 [Guido A.J. Stevens]
- Hook up human/content filters in frontend, refs #1115 [Guido A.J. Stevens]
- Provide secure human/content stream filter accessors, refs #1115 [Guido A.J. Stevens]
- Understand the container request parameter [Alessandro Pisa]
- Merge pull request #1196 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.52 [Wolfgang Thomas]
- Provide upgrade step for is_content/is_human indexes, refs #1115 [Guido A.J. Stevens]
- Implement indexes for human/content streams, refs #1115 [Guido A.J. Stevens]
- Implement content/human boolean accessors on statusupdates refs #1115 [Guido A.J. Stevens]


1.2.51 (2017-03-08)
-------------------

- Merge pull request #1195 from quaive/dashboard_and_cal_translations [GitHub]
- cleanup [Wolfgang Thomas]
- add missing translation [Wolfgang Thomas]
- added translation for mark read label [Angela Steinhardt]
- added i18n statement to mark read label [Angela Steinhardt]
- added translations for outlook support (#15065) and dashboard customization (#15070) [Angela Steinhardt]
- Merge pull request #1189 from quaive/parent_workspace [GitHub]
- Merge pull request #1188 from quaive/fix-title-attribute [GitHub]
- Merge pull request #1193 from quaive/fix-nexw-portlet [GitHub]
- Merge pull request #1190 from quaive/release-1.2.x [GitHub]
- Fix a couple of glitches [Alessandro Pisa]
- Back to development: 1.2.51 [Wolfgang Thomas]
- Add a parent_workspace property [Alessandro Pisa]
- Added a title attribute to the sidebar items [Alessandro Pisa]


1.2.50 (2017-03-07)
-------------------

- Merge pull request #1187 from quaive/better-mark-read [GitHub]
- Update markup [Alessandro Pisa]
- Merge pull request #1186 from quaive/external-app [GitHub]
- Merge pull request #1185 from quaive/ical-export [GitHub]
- Update resource package [Alessandro Pisa]
- Allow external apps [Alessandro Pisa]
- Merge pull request #1182 from quaive/set-a-default [GitHub]
- Merge pull request #1181 from quaive/custom-dashboard-unicode [GitHub]
- Make the menu work also on the app [Alessandro Pisa]
- Do not break if the record is not there [Alessandro Pisa]
- Merge pull request #1180 from quaive/portlet-event-width-customizable [GitHub]
- Merge pull request #1179 from quaive/fix-zope-user [GitHub]
- Merge pull request #1178 from quaive/preserve-template-ownership [GitHub]
- Fix unicode issues [Alessandro Pisa]
- Allow the event portlet width to be customizable [Alessandro Pisa]
- Do not break if self.user is not a profile [Alessandro Pisa]
- Test coverage [Alessandro Pisa]
- Added the possibility to preserve the template ownership [Alessandro Pisa]
- Merge pull request #1171 from quaive/customizable-dashboard [GitHub]
- Merge pull request #1177 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.50 [Wolfgang Thomas]
- Add the custom dashboard view [Alessandro Pisa]


1.2.49 (2017-03-02)
-------------------

- remove pypi-local file that got added by accident in 5c17b088a937cfeca48d064dbd247d5e39bb2ef0 [Wolfgang Thomas]
- Merge pull request #1175 from quaive/translationfixes [GitHub]
- Merge pull request #1176 from quaive/tag-stream-fix [GitHub]
- Do not break if no tag is passed [Alessandro Pisa]
- re-ran i18n-sync and added new translations in DE [Wolfgang Thomas]
- fix wrong translation in DE intorduced in 0fd744d8 [Wolfgang Thomas]
- added missing DE translations [Wolfgang Thomas]
- Merge pull request #1172 from quaive/ical-export [GitHub]
- Merge pull request #1173 from quaive/fix-6e7faf3a06a4823c489d674b0db1898094bee2bf [GitHub]
- Really create groups when syncing [Alessandro Pisa]
- Merge pull request #1170 from quaive/news-item-icon [GitHub]
- Add link to calendar export [Alessandro Pisa]
- Return a proper item for news related types [Alessandro Pisa]
- Merge pull request #1168 from quaive/release-1.2.x [GitHub]
- Merge pull request #1167 from quaive/mark-heisenbug [GitHub]
- Back to development: 1.2.49 [Alexander Pilz]
- Review the test tags [Alessandro Pisa]


1.2.48 (2017-02-23)
-------------------

- Merge pull request #1166 from quaive/fix-news-workflow-menu-injection [GitHub]
- Merge pull request #1165 from quaive/fix-news-link [GitHub]
- Fix the injection after a workflow transition on the news [Alessandro Pisa]
- Fixed the link to the news [Alessandro Pisa]
- Merge pull request #1164 from quaive/release-1.2.x [GitHub]


1.2.47 (2017-02-22)
-------------------

- Merge pull request #1163 from quaive/calendar-reload-sidebar [GitHub]
- More advanced injection [Alessandro Pisa]
- Merge pull request #1162 from quaive/icon-calendar [GitHub]
- The event type looks better with icon-calendar rather than icon-doc-text [Alessandro Pisa]
- Merge pull request #1161 from quaive/warn-to-info [GitHub]
- Merge pull request #932 from quaive/hide-plone-toolbar [GitHub]
- Merge pull request #1156 from quaive/fix-ws-dropdown [GitHub]
- I propose to make that an info because it spams any log aggregation service like sentry and we can't really fix anything so that it goes away [Alexander Pilz]
- Get rid of the toolbar [Alessandro Pisa]
- Merge pull request #1160 from quaive/release-1.2.x [GitHub]
- Merge pull request #1159 from quaive/ccc_performance [GitHub]
- Merge pull request #1157 from quaive/injection-parameter [GitHub]
- Back to development: 1.2.47 [Guido A.J. Stevens]
- Freeze whitelist into a set to speed up more, thx @ale [Guido A.J. Stevens]
- Fix injection parameter [Alessandro Pisa]
- Look for the workspace in the workspaces folder only [Alessandro Pisa]


1.2.46 (2017-02-21)
-------------------

- Merge pull request #1158 from quaive/ccc_performance [GitHub]
- Avoid two very costly security checks in the microblog getter: - This did a getObject() on every workspace in the system - And then did a PAS security check on that workspace [Guido A.J. Stevens]
- Merge pull request #1155 from quaive/user-manual [GitHub]
- Add short info about the user manual [Wolfgang Thomas]
- Merge pull request #1153 from quaive/solr-field-limit [GitHub]
- Merge pull request #1152 from quaive/release-1.2.x [GitHub]
- Added field_limit registry record. Allows selecting fields to be returned by solr. [Manuel Reinhardt]
- Back to development: 1.2.46 [Guido A.J. Stevens]


1.2.45 (2017-02-17)
-------------------

- Merge pull request #1150 from quaive/library_publish_translations [GitHub]
- Merge pull request #1151 from quaive/ccc_performance [GitHub]
- Massively speedup activity stream (6x-9x) by upping security cache lifetime [Guido A.J. Stevens]
- Avoid CSRF error and TypeError thrown by missing previews [Guido A.J. Stevens]
- Using templates as controllers is so Plone2. Sigh. At least document that mess to avoid losing another hour. [Guido A.J. Stevens]
- ran synci18n and added DE translations [Wolfgang Thomas]
- added missing i18n for "publish to library" [Wolfgang Thomas]
- Merge pull request #1149 from quaive/1144-userimport-pwd-reset [GitHub]
- Merge pull request #1148 from quaive/add_workspace_title_fix [GitHub]
- Not looking up a workspace-as-a-group directly caused sloooooow PAS lookup [Guido A.J. Stevens]
- allow (not) to update password when importing users [Harald Friessnegger]
- The default workspace policy package is actually team-managed, not self-managed as the title of the option would make you believe. [Guido A.J. Stevens]
- Expand profiler monkey patch documentation [Guido A.J. Stevens]
- Merge pull request #1147 from quaive/configure-microblog-whitelisted-types [GitHub]
- Merge pull request #1146 from quaive/do-not-break-event-sidebar [GitHub]
- Microblog whitelisted types are now configurable [Alessandro Pisa]
- Do not try to render the calendar icon if we have no start date [Alessandro Pisa]
- Merge pull request #1143 from quaive/1117-avatar-dots [GitHub]
- Merge pull request #1142 from quaive/release-1.2.x [GitHub]
- avatar import for profile names containing dots [Harald Friessnegger]
- Back to development: 1.2.45 [Wolfgang Thomas]

1.2.44 (2017-02-14)
-------------------

- Merge pull request #1044 from quaive/proto420-bulk-workflow [GitHub]
- fix bulk workflow tests [Wolfgang Thomas]
- Add German trnslations for batch workflow change [Wolfgang Thomas]
- change label [Wolfgang Thomas]
- replace Windows dash with ASCII-dash, since i18n extract pukes [Wolfgang Thomas]
- Always perform bulk-workflow change revursively [Wolfgang Thomas]
- changed icon name to corrent one [Wolfgang Thomas]
- add 2 robot tests for bulk workflow change [Wolfgang Thomas]
- Don't show the transition names, but the titles of the new states [Wolfgang Thomas]
- First basic implementation of bulk-action Change workflow, see quaive/ploneintranet.prototype#420 note: not styled yet! [Wolfgang Thomas]
- Merge pull request #1138 from quaive/fix_wf_translations [GitHub]
- Merge pull request #1129 from quaive/fix-artifact [GitHub]
- Merge pull request #1136 from quaive/1135-workflow-menu [GitHub]
- Add missing i18n:domain, so that workflow transitions on ToDos can be translated [Wolfgang Thomas]
- Remove nasty ipdb import [GitHub]
- move workflow_menu view to ploneintranet.layout [Harald Friessnegger]
- Merge pull request #1131 from quaive/do-not-break-event-sidebar [GitHub]
- Merge pull request #1133 from quaive/workflow_translation [GitHub]
- fix regression: we need to translate workflow state names [Wolfgang Thomas]
- Do not break is start or end date are None [Alessandro Pisa]
- Merge pull request #1127 from quaive/release-1.2.x [GitHub]
- Merge pull request #1128 from quaive/catch-geturl-error [GitHub]
- Do not render an empty <li> item [Alessandro Pisa]
- Catch AttributeError in getURL. I can't reliably reproduce it, but sometimes getURL throws an AttributeError. If the request does not have a URL then we can't continue the event handler anyway, but at least we may be able to finish the original request if we catch the error. [Manuel Reinhardt]
- Back to development: 1.2.44 [Manuel Reinhardt]


1.2.43 (2017-02-10)
-------------------

- Merge pull request #1125 from quaive/remove-close-panel [GitHub]
- Removed close-panel class from submit button. This was causing a problem on Windows machines where the modal would close but the form not be submitted. [Manuel Reinhardt]
- added vcl provided by Paul [Alexander Pilz]
- Merge pull request #1122 from quaive/fix-case-view-3 [GitHub]
- Merge pull request #1121 from quaive/show-older-comments [GitHub]
- Merge pull request #1120 from quaive/fix-case-view-2 [GitHub]
- Merge pull request #1119 from quaive/fix-case-view [GitHub]
- Merge pull request #1116 from quaive/609-fix-broken-test [GitHub]
- Merge pull request #1123 from quaive/speed-up-copy-from-template [GitHub]
- Avoid calling uneeded expensive event while copying a template [Alessandro Pisa]
- Move replies to another objects to not interfere with previous tests [Alessandro Pisa]
- Move related workspaces to the proper place [Alessandro Pisa]
- Backport [Alessandro Pisa]
- Implement the "Show N older comments" link [Alessandro Pisa]
- Introduce the concept of metromap state [Alessandro Pisa]
- Remove unused defines and drop commented html [Alessandro Pisa]
- Update the test to match the template changes [Alessandro Pisa]
- Merge pull request #1113 from quaive/improve-autosave [GitHub]
- Merge pull request #1112 from quaive/release-1.2.x [GitHub]
- Improve autosave [Alessandro Pisa]
- Back to development: 1.2.43 [Alexander Pilz]


1.2.42 (2017-02-03)
-------------------

- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Back to development: 1.2.42 [Alexander Pilz]
- Merge pull request #1111 from quaive/fix-module-name [GitHub]
- Merge pull request #1110 from quaive/fix-add-event-url [GitHub]
- mv context-menu.py -> context_menu.py [Alessandro Pisa]
- Make the add_event URL always absolute [Alessandro Pisa]
- Merge pull request #1109 from quaive/fix-undefined-hide_timezone [GitHub]
- Merge pull request #1106 from quaive/fix-injection-add-event [GitHub]
- Merge pull request #1108 from quaive/upload-and-autotag [GitHub]
- Upload and autotag the files [Alessandro Pisa]
- Fix undefined timezone [Alessandro Pisa]
- Merge pull request #1105 from quaive/release-1.2.x [GitHub]
- Fix add_event injection [Alessandro Pisa]


1.2.41 (2017-02-03)
-------------------

- Back to development: 1.2.41 [Alexander Pilz]


1.2.40 (2017-02-02)
-------------------

- Merge pull request #1104 from quaive/all-calendars-controlled-by-request [GitHub]
- Merge pull request #1103 from quaive/add_event-sane-defaults [GitHub]
- Merge pull request #1102 from quaive/timestamped-add-event-form [GitHub]
- Merge pull request #1099 from quaive/add-event-in-ws-calendar [GitHub]
- Understand the request parameter all_calendars [Alessandro Pisa]
- Saner defaults for the add_event form [Alessandro Pisa]
- Add a timestamp to the form to allow the creation of multiple events [Alessandro Pisa]
- Merge pull request #1098 from quaive/translate-placeholder [GitHub]
- Fix adding an event from the workspace calendar [Alessandro Pisa]
- Fix disabled attribute [Alessandro Pisa]
- Translate placeholder [Alessandro Pisa]
- Merge pull request #1097 from quaive/update-proto-fix-splash [GitHub]
- undo sources again [Alexander Pilz]
- updating proto and replicating Cornelis' style fixes for the splash page [Alexander Pilz]
- Merge pull request #1093 from quaive/1090-wf-menu-on-files [GitHub]
- Merge pull request #1095 from quaive/defensive-indexer [GitHub]
- Every content can have the workflow_menu view [Alessandro Pisa]
- Use an existing file [Alessandro Pisa]
- Merge pull request #1094 from quaive/1088-library-copy-hint [GitHub]
- Merge pull request #1092 from quaive/1084-permission-check-on-roster [GitHub]
- Merge pull request #1091 from quaive/release-1.2.x [GitHub]
- start dates can actually be none [Alexander Pilz]
- Generally display the information that a document is available as copy in the library. Fixes #1088 [Wolfgang Thomas]
- Explicitly make the workflow_menu available for Files #1090 [Wolfgang Thomas]
- the locking view is not available for all content types [Wolfgang Thomas]
- Add a robot test that checks if workflow is active for Files #1090 [Wolfgang Thomas]
- Back to development: 1.2.40 [Alexander Pilz]
- Since all entries in the "more" menu (Select, Add User) are already being shown only if the user can_manage_roster elsewhere on this View, we also need to apply this permission check for the more-menu. Refs #1084 [Wolfgang Thomas]


1.2.39 (2017-01-31)
-------------------

- Merge pull request #1089 from quaive/fix-delete-confirmation [GitHub]
- Do not post when clicking cancel on a modal form [Alessandro Pisa]
- Merge pull request #1087 from quaive/fix-sidebar-behavior [GitHub]
- Added a workflow_menu log helper view [Alessandro Pisa]
- Fix event sidebar [Alessandro Pisa]
- Do not inject the whole sidebar after save, but only the part we care about [Alessandro Pisa]
- Make the returned item customizable [Alessandro Pisa]
- Use itertools ifilter to optimize the sidebar [Alessandro Pisa]
- Do not render the comment [Alessandro Pisa]
- Merge pull request #1085 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.39 [Alexander Pilz]


1.2.38 (2017-01-25)
-------------------

- Merge pull request #1083 from quaive/auto-rename-registry-dependent [GitHub]
- Merge pull request #1082 from quaive/document-sidebar-after-save [GitHub]
- Disable autorename based on a registry record [Alessandro Pisa]
- Merge pull request #1081 from quaive/release-1.2.x [GitHub]
- Reinject document sidebar after save [Alessandro Pisa]
- Back to development: 1.2.38 [Alexander Pilz]


1.2.37 (2017-01-24)
-------------------

- fix the group sync properly [Alexander Pilz]


1.2.36 (2017-01-24)
-------------------

- Merge pull request #1080 from quaive/fix-sync-groups [GitHub]
- sync everything, not only the new ones [Alessandro Pisa]
- Merge pull request #1078 from quaive/release-1.2.x [GitHub]
- Merge pull request #1079 from quaive/notify-on-upload [GitHub]
- Emit event in file upload view. This is necessary e.g. for CMFNotification. [Manuel Reinhardt]
- Back to development: 1.2.36 [Alexander Pilz]


1.2.35 (2017-01-24)
-------------------

- Merge pull request #1074 from quaive/limit-previews [GitHub]
- fix [Alexander Pilz]
- Merge pull request #1075 from quaive/fix-invitees [GitHub]
- Merge pull request #1077 from quaive/avatar-image-caching [GitHub]
- fix exception state [Alexander Pilz]
- Add the Last-Modified header for avatar images [Cillian de Roiste]
- Fix event invitees calculations [Alessandro Pisa]
- another check [Alexander Pilz]
- Merge branch 'master' into limit-previews [Alexander Pilz]
- quit if no previews available [Alexander Pilz]
- limit preview generation to a sane amount of 20, configurable in registry [Alexander Pilz]
- Merge pull request #1071 from quaive/handle_mimetype_registry_error [GitHub]
- Merge pull request #1070 from quaive/fix_version_id [GitHub]
- Merge pull request #1069 from quaive/quote-sidebar-groups [GitHub]
- Optimize is_allowed_document_type [Alessandro Pisa]
- version_id can be missing [Manuel Reinhardt]
- Handle exception that come from a broken mimetype [Alessandro Pisa]
- Quote groupname when making the URL in the sidebar. It can contain all kinds of characters that make trouble, like '&'. [Manuel Reinhardt]
- Merge pull request #1068 from quaive/ldap_sync_unicode [GitHub]
- Merge pull request #1066 from quaive/search-groups-by-name-and-id [GitHub]
- Merge pull request #1067 from quaive/release-1.2.x [GitHub]
- Work around a string/unicode confusion hidden somewhere in PloneLDAP [Guido A.J. Stevens]
- Back to development: 1.2.35 [Alexander Pilz]
- For some reasons our intranet plugin always returns the group "All intranet users" [Wolfgang Thomas]
- When searching for groups, don't only search by id, but also by name [Wolfgang Thomas]


1.2.34 (2017-01-20)
-------------------

- Merge pull request #1064 from quaive/splashpage [GitHub]
- load testing profile to deactivate splash [Alexander Pilz]
- Merge branch 'master' into splashpage [Alexander Pilz]
- Merge pull request #1063 from quaive/solr-fixes [GitHub]
- revert accidental change [Alexander Pilz]
- Turn off splashpage for testing [Alexander Pilz]
- added code to display a splashpage on first visit [Alexander Pilz]
- Dispatch the SearchableText reindex only if it is in data [Alessandro Pisa]
- Use a more explicite variable name [Alessandro Pisa]
- Do not break when function fails [Alessandro Pisa]
- Small optimizations [Alessandro Pisa]
- Lazy load previews [Alessandro Pisa]
- Merge pull request #1061 from quaive/improve-install-story [GitHub]
- Add Products.PloneHotfix20170117 [GitHub]
- Merge pull request #1062 from quaive/1055-news-as-app-in-bookmarks [GitHub]
- Merge pull request #1052 from quaive/proto397-rename-after-paste [GitHub]
- update test to reflect the new default dashboard tiles [Wolfgang Thomas]
- in our convenience method translate_friendly_type, make sure "app" comes before "news" so that 'ploneintranet.news.app' is recognized as app [Wolfgang Thomas]
- let the news app also be an app type in the bookmarks [Wolfgang Thomas]
- Provide more portlets on the dashboard by default to give a richer experience [Wolfgang Thomas]
- Allthough ploneintranet.news already publishes the NewsApp, here in suite we exchange the portal's default workflow. Therefore the NewsApp gets set to private again. In a fresh installation, we want the following Apps published: news, apps, profiles and library Fixes #1053 [Wolfgang Thomas]
- Add a test that proves that no extra reindexObject is needed, since that is handled via event notifiation from OFS's manage_renameObject [Wolfgang Thomas]
- Merge pull request #1060 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.34 [Guido A.J. Stevens]
- fix robot test: when the title changes, also the id of the event will change [Wolfgang Thomas]
- Fix test: the id now comes from the title [Wolfgang Thomas]
- Add more tests for id-from-title [Wolfgang Thomas]
- Call the event handler for setting the id every time an item gets modified. Add extra checks to prevent unnecessary or harmful actions [Wolfgang Thomas]
- Be more defensive: not all content types can be adapted to INameFromTitle (files) [Wolfgang Thomas]
- fix bug exposed by test: if no title is present, do not attempt to rename the id based on title [Wolfgang Thomas]
- Implementation of quaive/ploneintranet.prototype#397 - When items are pasted in the context of a workspace, make sure their ids are generated from the titles [Wolfgang Thomas]


1.2.33 (2017-01-14)
-------------------

- Update changelog [Guido A.J. Stevens]
- Update release doc [Guido A.J. Stevens]
- Merge branch 'master' into release-1.2.x [Guido A.J. Stevens]
- Merge pull request #1054 from quaive/1043_email_login [GitHub]
- Merge pull request #1058 from quaive/fix_network_to_005 [GitHub]
- Merge pull request #1059 from quaive/use-geturl-in-handler [GitHub]
- Use standard getURL() rather than URL attribute. The latter can fail in cases where the former still works. [Manuel Reinhardt]
- Don't error out on missing bookmark category during migration [Guido A.J. Stevens]
- Merge pull request #1057 from quaive/1056-fix-double-view-in-url [GitHub]
- Work around a solr-quirk: We might end up with "/view" being appended twice to the URL. Fixes #1056 [Wolfgang Thomas]
- Putting logic in templates instead of a view class begets this kind of mess. [Guido A.J. Stevens]
- Don't assume dx.membrane is installed when testing pi.layout [Guido A.J. Stevens]
- Setting 'plone.use_email_as_login' is invalid when using LDAP, so don't do that. [Guido A.J. Stevens]
- Update userprofile docs [Guido A.J. Stevens]
- Fix test regression caused by variable name collision [Guido A.J. Stevens]
- Upstream fix merged and has a pypi release [Guido A.J. Stevens]
- Update userid documentation [Guido A.J. Stevens]
- Pull in upstream fix [Guido A.J. Stevens]
- Extra test coverage for latest dx.membrane getUserId() fixes [Guido A.J. Stevens]
- Get the dx.membrane fix that started all of this [Guido A.J. Stevens]
- Oh man. user.getUserName() should be replaced by user.getId() not by user.getUserId(). [Guido A.J. Stevens]
- AccessControl.users.UnrestrictedUser.getUserName() is unrelated to dx.membrane API [Guido A.J. Stevens]
- Fix test regressions [Guido A.J. Stevens]
- Replace all getUserName with getUserId, except when we're actually handling login names. [Guido A.J. Stevens]
- Finish test coverage to prove https://github.com/collective/dexterity.membrane/pull/27 [Guido A.J. Stevens]
- Bring membrane email login under test in a way that zooms in on Members problem [Guido A.J. Stevens]
- Use functional test layer instead of hacking around test leakage [Guido A.J. Stevens]
- Merge pull request #1050 from quaive/add_event-injection [GitHub]
- Tag the test "Member can mark a new task complete on dashboard" as an heisenbug [Alessandro Pisa]
- Be compliant with the prototype [Alessandro Pisa]
- Merge pull request #1051 from quaive/fix-js-errors [GitHub]
- Merge pull request #1049 from quaive/fix-event-view [GitHub]
- Fix some other javascript errors [Alessandro Pisa]
- Try to wait for every injection to be finished [Alessandro Pisa]
- Merge pull request #1042 from quaive/clicktracker-element [GitHub]
- Merge pull request #1048 from quaive/optimize-month-name-translation [GitHub]
- Merge pull request #1046 from quaive/remove-unused-define [GitHub]
- Merge pull request #1045 from quaive/tal-comment [GitHub]
- Fix various javascript errors in the event view [Alessandro Pisa]
- Optimize the translation of month names [Alessandro Pisa]
- Remove unused define [Alessandro Pisa]
- Remove unused define [Alessandro Pisa]
- Use tal:comment to reduce the size of the produced html [Alessandro Pisa]
- Remove unused define [Alessandro Pisa]
- Use tal:comment to reduce the size of the produced html [Alessandro Pisa]
- Merge pull request #1041 from quaive/fix-deslect-typo [GitHub]
- Merge pull request #1040 from quaive/fix-tag-reorder-injection [GitHub]
- Optionally include a trigger element for slc.clicktracker. [Manuel Reinhardt]
- Fix typo Deslect -> Deselect [Alessandro Pisa]
- Merge pull request #1038 from quaive/contacts-portlet-byline [GitHub]
- Redirect to the the document sidebar after the reordering [Alessandro Pisa]
- Merge pull request #1039 from quaive/rename-type-rich [GitHub]
- Optimised lookup of byline fieldname. Eliminated try-except block. [Manuel Reinhardt]
- Renamed type 'rich' to the slightly more user friendly 'rich document'. [Manuel Reinhardt]
- Registry record that makes the contacts portlet search result byline configurable. [Manuel Reinhardt]
- Merge pull request #1021 from quaive/qrp-1.3.14 [GitHub]
- Use "natural" click-path to go to the dashboard, to prevent CSRF error [Wolfgang Thomas]
- Do not wait for the element to be visible when injeting the sidebar Fixes #1032 (and was applied successfully by @ale already for star and ikath) [Wolfgang Thomas]
- Drop the alpha, upgrade q.r.p. [Wolfgang Thomas]
- Merge pull request #1035 from quaive/fix-sidebar-events-injection [GitHub]
- Merge pull request #1030 from quaive/profile_doc [GitHub]
- Merge pull request #1034 from quaive/reorder-tags-fix-case [GitHub]
- sidebar-events: fixed pat-switch to set classes on the correct element [Manuel Reinhardt]
- Preserve case of tags in "reorder tags" panel [Manuel Reinhardt]
- Merge pull request #1033 from quaive/mustread_dontraise [GitHub]
- Catch news errors caused by inavailablility of mustread database. This typically happens in tests because we do not have proper sqlite support in testing. Additional logging is provided by https://github.com/collective/collective.mustread/commit/5c9bc646a5b27246917ec9c5465352aa4cbb206e [Guido A.J. Stevens]
- Document Zope profiler monkey patch [ci skip] [Guido A.J. Stevens]
- Merge pull request #1028 from quaive/ldap_doc [GitHub]
- Merge pull request #1029 from quaive/mustread-1.0.1 [GitHub]
- More verbose error logging for mustread [Guido A.J. Stevens]
- Run docker with --rm [ci skip] [Guido A.J. Stevens]
- Document LDAP time waster [ci skip] [Guido A.J. Stevens]
- Merge pull request #1026 from quaive/unlimited-facets [GitHub]
- Merge pull request #1025 from quaive/solr-maintenance-more-stable [GitHub]
- Don't limit the number of facet values returned from solr. [Manuel Reinhardt]
- Don't break if the item is not in the set [Alexander Pilz]
- Merge pull request #1018 from quaive/allow-sidebar-filters [GitHub]
- Merge pull request #1020 from quaive/fix-multiple-injection [GitHub]
- Merge pull request #1016 from quaive/fullcalendar-day-span [GitHub]
- Merge pull request #1017 from quaive/1008-continued [GitHub]
- Merge pull request #1015 from quaive/1007-no-wf-for-news-sections [GitHub]
- Fix multiple injection [Alessandro Pisa]
- We don't need to restrict search filters in the sidebar. We set them all manually in the same method. This fixes "LookupError: Invalid facet field 'outdated'" [Manuel Reinhardt]
- Following the post-merge discussion in #1014 I opted to make my patch safer in case we ever get unicode (containing non-ascii) in a TextLine [Wolfgang Thomas]
- The fullcalendar view time span can be configured [Alessandro Pisa]
- Merge pull request #1014 from quaive/1008-linebreaks-in-titles [GitHub]
- use splitlines since it is more pythonic [Wolfgang Thomas]
- Merge pull request #1006 from quaive/remove-sidebar-batching [GitHub]
- Merge pull request #1013 from quaive/1009-fix-news-subjects [GitHub]
- publishing a news section makes no sense any more, since they have no workflow [Wolfgang Thomas]
- Don't assign any workflow to a news section. Fixes #1007 [Wolfgang Thomas]
- Strip line breaks in TextLines (e.g. used for Title). Fixes #1008 [Wolfgang Thomas]
- re-order imports (autosort) [Wolfgang Thomas]
- Make sure our CommaSeparatedFieldWidget is not only registered for IWorkspaceAppFormLayer, but for IAppLayer in general. That means also Apps like the News publisher, where the subjects field is also used, will handle saving subjects correctly. Fixes #1009 [Wolfgang Thomas]
- Merge pull request #1005 from quaive/allow-long-titles [GitHub]
- Removed broken sidebar batching [Manuel Reinhardt]
- also in the add form [Alexander Pilz]
- Back to development: 1.2.0a33 [Alexander Pilz]


1.2.0a32 (2016-12-15)
---------------------

- Merge pull request #1004 from quaive/make-news-filter-optional [GitHub]
- Make filtering by published state optional in the news portlet. This leaves it to the integrator to do a gradual transition to the news app [Alexander Pilz]
- Merge pull request #1002 from quaive/cart-propagate-groupname [GitHub]
- Propagate the groupname parameter in cart actions that inject the sidebar. This makes sure we stay at the same navigation level when grouping is not by folder. [Manuel Reinhardt]
- Merge pull request #1001 from quaive/portlet_contacts_recent [GitHub]
- Added registry record to toggle display of recent contacts in the contacts portlet. refs https://github.com/quaive/ploneintranet.prototype/pull/416 [Manuel Reinhardt]
- Merge pull request #999 from quaive/995_news_images [GitHub]
- Hook up proper inline image support for Redactor in news publisher [Guido A.J. Stevens]
- Make supporting view for Redactor images generally available and remove legacy Raptor view for that [Guido A.J. Stevens]
- Allow supporting images in news app [Guido A.J. Stevens]
- Merge pull request #998 from quaive/proper-date-translation [GitHub]
- Merge pull request #997 from quaive/fix-collapsible-booklet-portlet [GitHub]
- Merge pull request #994 from quaive/print-with-onclick [GitHub]
- Use our new ulocalized_time util method to properly get correct long date [Wolfgang Thomas]
- streamline default translations [Wolfgang Thomas]
- Add nationally correct versions for long_date_format [Wolfgang Thomas]
- Define our own long date format [Wolfgang Thomas]
- overwrite ulocalized_time from CMFCore, so that we can use a separate translation domain for the formatring than for the translation of the month and week-day names [Wolfgang Thomas]
- Merge pull request #996 from quaive/news-trans [GitHub]
- Fix collapsible behavior of the workspace bookmarks portlet [Alessandro Pisa]
- re-run i18n sync, add DE translations for News [Wolfgang Thomas]
- add several missing i18n statements [Wolfgang Thomas]
- Use onclick to trigger window [Alessandro Pisa]
- Merge pull request #993 from quaive/portlet-optimisation-fix [GitHub]
- Merge pull request #992 from quaive/release-1.2.x [GitHub]
- @ale-rt I had to remove these two lines on production again. If there is no read_uids, it only means a user has never read a news item. Then no news portlet is shown. He will never be able to read anything... [Alexander Pilz]
- Back to development: 1.2.0a32 [Alexander Pilz]


1.2.0a31 (2016-12-07)
---------------------

- Merge pull request #991 from quaive/fix-metromap-tile [GitHub]
- Merge pull request #990 from quaive/fix-delete-todos [GitHub]
- Merge pull request #989 from quaive/news-tile-improvements [GitHub]
- Merge pull request #988 from quaive/release-1.2.x [GitHub]
- Calculate better if a milestone is closed [Alessandro Pisa]
- Fix delete todos popup [Alessandro Pisa]
- Fix broken improvements [Alessandro Pisa]
- Back to development: 1.2.0a31 [Alexander Pilz]


1.2.0a30 (2016-12-06)
---------------------

- Merge pull request #986 from quaive/979-news-publishing [GitHub]
- fix logic for showing workflow dropdown in news publisher, fixes #979 [Wolfgang Thomas]
- Merge pull request #984 from quaive/simplify-versioning [GitHub]
- Merge pull request #983 from quaive/use-groupid [GitHub]
- Added DE translation for historypopup [Wolfgang Thomas]
- Customise the method that aggregates the revision history. Reason: In case we're viewing the history of a File, we want to link directly to the download URL, since the history details page gives no further useful information. Also, slightly improve the look of the history popup [Wolfgang Thomas]
- Use groupid when principal is a group [Alessandro Pisa]
- Merge pull request #982 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.0a30 [Alexander Pilz]


1.2.0a29 (2016-12-04)
---------------------

- Merge pull request #981 from quaive/fix-group-sync [GitHub]
- Merge pull request #980 from quaive/fix-news-delete [GitHub]
- Don't lower the group ids for canonicals [Alexander Pilz]
- Merge pull request #978 from quaive/840-uemlaute [GitHub]
- re-ran i18n sync & fixed DE translation of delete confirmation [Wolfgang Thomas]
- properly i18n the delete confirmation [Wolfgang Thomas]
- The delete conformation modal needs to be large, since the buttons contain lots of text, and in translations such as DE it can become even longer. [Wolfgang Thomas]
- Add status message about deletion to be in line with the rest of our content [Wolfgang Thomas]
- A button that submits a form in a modal must never have `close-panel`, since that just closes the modal... [Wolfgang Thomas]
- For whatever reason we were using namechooser and idnormalizer. I think to remember that I did this back then to be extra safe.  namechooser alone is the canonical plone behavior. So that changes back to it now. [Alexander Pilz]
- Merge pull request #975 from quaive/require-pysqlite [GitHub]
- Merge pull request #976 from quaive/update-cmfnotification [GitHub]
- Update Products.CMFNotification [Alessandro Pisa]
- Require pysqlite [Alessandro Pisa]
- Merge pull request #974 from quaive/release-1.2.x [GitHub]
- Merge pull request #968 from quaive/sidebar-refactoring [GitHub]
- Back to development: 1.2.0a29 [Alexander Pilz]
- Preparing release 1.2.0a28 [Alexander Pilz]
- Sidebar refactoring [Alessandro Pisa]


1.2.0a28 (2016-12-02)
---------------------

- Merge pull request #973 from quaive/wrong-registry-key [GitHub]
- Merge pull request #971 from quaive/875_barceloneta_viewlets_disable [GitHub]
- Merge pull request #969 from quaive/solr-maintenance-csrf-free [GitHub]
- In the test, explicitly remove INoBarcelonetaLayer from the request when emulating the CMS. [Wolfgang Thomas]
- Merge pull request #972 from quaive/remove-canonical-lower [GitHub]
- Skip CSRF protection for the solr-maintenance view [Alessandro Pisa]
- Merge pull request #963 from quaive/mustread [GitHub]
- Fix wrong registry key [Alessandro Pisa]
- There is no reason to lowercase the canonical name [Alessandro Pisa]
- Replace all usage of IThemeSpecific outside of ploneintranet.theme with INoBarcelonetaLayer [Guido A.J. Stevens]
- Disable ploneintranet layout viewlets in Barceloneta fixes #875. Probably there is a difference between a IThemeSpecific and a normal browser layer? Because the viewlets were active even though they were bound to an inactive IThemeSpecific layer. [Guido A.J. Stevens]
- Merge pull request #970 from quaive/791_dont_notify_self [GitHub]
- Merge pull request #967 from quaive/solr-reindex-resistant [GitHub]
- Merge pull request #966 from quaive/reload-only-sidebar-documents [GitHub]
- Mark own sent messages as 'read' fixes #791 [Guido A.J. Stevens]
- Up async timeout to see if that makes Jenkins happy [Guido A.J. Stevens]
- Add upgrade step to lock down library against new news items [Guido A.J. Stevens]
- Solr reindex is more resistant [Alessandro Pisa]
- Merge pull request #965 from quaive/master_hotfix [GitHub]
- Reload only the documents [Alessandro Pisa]
- add Products.PloneHotfix20161129 [Wolfgang Thomas]
- Merge pull request #961 from quaive/optimize-get_authenticated_groupids [GitHub]
- Merge pull request #964 from quaive/remove-duplicate-share-button [GitHub]
- Remove duplicate share button [Alessandro Pisa]
- Update news docs [Guido A.J. Stevens]
- Disable legacy newsitem migration [Guido A.J. Stevens]
- Optimize get_authenticated_groupids [Alessandro Pisa]
- Merge pull request #960 from quaive/user-fixes [GitHub]
- make user import more robus: Don't choke on empty lines [Wolfgang Thomas]
- Fix user import: allow non-required fields like person_title [Wolfgang Thomas]
- the "person_title" is already part of the "fullname". Therefore we must not additionally show it separately here [Wolfgang Thomas]
- Robustify and reactivate legacy news item migration [Guido A.J. Stevens]
- Disallow creating news items in library from now on [Guido A.J. Stevens]
- Fix sqlalchemy fallback URI [Guido A.J. Stevens]
- Add a bit of extra view test coverage for news [Guido A.J. Stevens]
- Work around sqlalchemy/ZServer threading issues by doing lxml functional tests [Guido A.J. Stevens]
- Show "mark read" button also for items that are not "must read", so users can clear the portlet if they want to [Guido A.J. Stevens]
- Document news functionality [Guido A.J. Stevens]
- Reorganize component doc index for readability, update network status description. [Guido A.J. Stevens]
- Use freshly released collective.mustread egg [Guido A.J. Stevens]
- Implement "trending news" [Guido A.J. Stevens]
- Sort must-read items on top in news tile [Guido A.J. Stevens]
- Filter news tile to only show unread items. Supplement async mark-read writes with sync state propagation via hidden input [Guido A.J. Stevens]
- Improve db init upgrade step [Guido A.J. Stevens]
- Mark news item read from portlet [Guido A.J. Stevens]
- Auto-mark newsitem as read on full view [Guido A.J. Stevens]
- Hook up async mark_read task [Guido A.J. Stevens]
- Expose must_read checkbox in news publisher [Guido A.J. Stevens]
- Base integration of collective.mustread package [Guido A.J. Stevens]
- Merge pull request #959 from quaive/allow-all-poweerful-oz [GitHub]
- Don't choke if a user cannot be wrapped. This might happen during content import for "all powerful Oz" [Wolfgang Thomas]
- Merge pull request #956 from quaive/fix-feedback-inject [GitHub]
- damned flake :) [Alexander Pilz]
- Merge pull request #957 from quaive/skip_preview_test [GitHub]
- Fix the response, instead of rendering the context completely, only return statusmessage [Alexander Pilz]
- Skip broken test for now [Guido A.J. Stevens]
- Merge pull request #955 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.0a28 [Alexander Pilz]
- removed fuzzy tags [Angela Steinhardt]
- forgot updated .pot file [Angela Steinhardt]
- changed all occurances of arbeitsbereich in arbeitsraum [Angela Steinhardt]
- corrected translation of portlet header for bookmarked workspaces [Angela Steinhardt]


1.2.0a27 (2016-11-25)
---------------------

- Merge pull request #954 from quaive/fix-event-add-time-column [GitHub]
- Merge pull request #953 from quaive/fix-contacts-portlet-rescale [GitHub]
- Merge pull request #952 from quaive/update-portlets [GitHub]
- fix sizes [Alexander Pilz]
- Remove the pat-autoscale as it doesn't resize the portlet anymore. [Alexander Pilz]
- Add expander to tasks and event portlets, align workspaces bookmark portlet with proto (no bookmarking nor description) [Alexander Pilz]
- Merge pull request #951 from quaive/fix-markup-todo [GitHub]
- fix classes on todo view, refs #14486 [Alexander Pilz]
- Merge pull request #906 from quaive/solr-boosting [GitHub]
- Merge pull request #949 from quaive/fix-extract-data [GitHub]
- Merge pull request #945 from quaive/workaround-piprototype-407 [GitHub]
- Override execute method to add boosting [Alessandro Pisa]
- Workaround for quaive/ploneintranet.prototype#407 [Alessandro Pisa]
- Merge pull request #948 from quaive/calendar-wip [GitHub]
- Merge pull request #947 from quaive/mail-template [GitHub]
- Fix extract method for dates [Alessandro Pisa]
- First optimizations to make calendar faster [Alessandro Pisa]
- Update the mail template [Alessandro Pisa]
- Merge pull request #946 from quaive/sidebar-outside-workspace [GitHub]
- Sidebar: memoize root() [Cillian de Roiste]
- Sidebar: Allow to be used outside workspaces [Cillian de Roiste]
- Merge pull request #943 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.0a27 [Alexander Pilz]


1.2.0a26 (2016-11-21)
---------------------

- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Merge pull request #942 from quaive/de-trans [GitHub]
- Merge pull request #941 from quaive/fix-groupspace-basics [GitHub]
- Merge pull request #940 from quaive/fix-return-value [GitHub]
- Merge pull request #937 from quaive/936-group-not-addable-workspacewq [GitHub]
- Merge pull request #939 from quaive/paginating-group-view [GitHub]
- Merge pull request #935 from quaive/fix-news-app-creation [GitHub]
- typo [Wolfgang Thomas]
- added some German translations [Wolfgang Thomas]
- Merge pull request #938 from quaive/selfhealing [GitHub]
- With all the refactoring and performance improvements that came with the paradigm "we only support membrane" groups and the introduction of workgroups, a lot of assumptions were hard-coded that break the existing "workspaces can be membrane groups" behaviour. This behaviour was built to be fully PAS compatible and therefore provides all the required methods and properties. The current performance enhancements for the workspace sidebar assume that we are always dealing with membrane objects, and not GroupData via PAS. This commit attempts to leave all the performance enhancements in place, while restoring the basic functionality of using PAS in case of the MembraneWorkspaceGroup behaviour. [Wolfgang Thomas]
- Merge pull request #934 from quaive/sidebar-search-fix [GitHub]
- Paginating the users in the group view [Alessandro Pisa]
- add some code to handle sideeffects of transaction conflicts [Alexander Pilz]
- hard-code exclusion of workgroups in the add workspace menu. Fixes #936 [Wolfgang Thomas]
- By default, plone creates a top-level folder "news", which needs to be removed [Wolfgang Thomas]
- Sidebar bugfix: use getId for the index, not 'id' [Cillian de Roiste]
- Merge pull request #933 from quaive/fix-unicode-tag-stream [GitHub]
- don't fail if a workgroup has no email [Wolfgang Thomas]
- Tags can contain non-ASCII, therefore need to be url-quoted [Wolfgang Thomas]
- Merge pull request #930 from quaive/customizable-grouping [GitHub]
- Merge pull request #931 from quaive/workgroup-missing-values [GitHub]
- Allow default workspace grouping customization [Alessandro Pisa]
- Merge pull request #929 from quaive/async-debounce [GitHub]
- Merge pull request #925 from quaive/async-dashboard [GitHub]
- Workgroup missing values [Alessandro Pisa]
- Merge pull request #927 from quaive/fix-filter_news_layer [GitHub]
- Fix tile URL [Alessandro Pisa]
- Merge pull request #926 from quaive/fix-ws-url [GitHub]
- add debouncing for preview generation to not generate every 2 secs [Alexander Pilz]
- Fix upgrade step filter_news_layer: the registry record we are trying to set expects a list of unicodes. A tuple of strings mixed with unicodes just won't do it. [Wolfgang Thomas]
- Fix view of Workspace. After #903, we don't have dicts any more with a key URL, but brains with the method getURL [Wolfgang Thomas]
- Load tiles in parallel [Alexander Pilz]
- Merge branch 'master' into translation_allday [Alexander Pilz]
- Merge pull request #924 from quaive/secure-contact-search [GitHub]
- corrected translation  for all day event [Angela Steinhardt]
- Merge pull request #923 from quaive/placeholder [GitHub]
- Added a tal condition to check getId [Alessandro Pisa]
- Break dependency on quaive.resources.ploneintranet by providing ++theme++ploneintranet.layout static resource [Guido A.J. Stevens]
- gitignore .pip [Guido A.J. Stevens]
- wrong variable [Alexander Pilz]
- Merge branch 'master' of github.com:quaive/ploneintranet [Alexander Pilz]
- Remove leading _ [Alexander Pilz]
- Merge pull request #922 from quaive/allow-skipping-solr [GitHub]
- Merge pull request #921 from quaive/translations-calendar [GitHub]
- Back to development: 1.2.0a26 [Alexander Pilz]
- Allow disabling solr through the registry [Alessandro Pisa]
- added translation and i18n statement for document autosave batch [Angela Steinhardt]
- added i18n statements to calendar views to enable translation and added translations to po file for them [Angela Steinhardt]
- Use always the same return type [Alessandro Pisa]


1.2.0a25 (2016-11-16)
---------------------

- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Merge pull request #918 from quaive/filter-news-layers [GitHub]
- Merge pull request #919 from quaive/move-external-editor-from-context-menu [GitHub]
- doc view: only display ext editor link for files [Cillian de Roiste]
- Bulk action notes: i18n:translate [Cillian de Roiste]
- Bulk actions: note which items can't be processed [Cillian de Roiste]
- Fix tag ajax call when adding a tag in the CMS [Cillian de Roiste]
- Merge pull request #917 from quaive/bulk-actions-permission-note [GitHub]
- Merge pull request #915 from quaive/adding-news-in-cms [GitHub]
- Doc view: show the external editor link [Cillian de Roiste]
- Upgrade step to filter out news app layers in CMS [Alessandro Pisa]
- Merge pull request #914 from quaive/create-structure-fix [GitHub]
- Merge pull request #913 from quaive/fix-principal-title [GitHub]
- Bulk action notes: i18n:translate [Cillian de Roiste]
- Bulk actions: note which items can't be processed [Cillian de Roiste]
- Fix tag ajax call when adding a tag in the CMS [Alessandro Pisa]
- Fix test and remove the heisenbug tag [Alessandro Pisa]
- Merge pull request #912 from quaive/translations_sidebar-history-div [GitHub]
- Merge pull request #911 from quaive/fix-typo [GitHub]
- Merge pull request #910 from quaive/fix-back-to-parent [GitHub]
- Return the principal id if we are not able to resolve it [Alessandro Pisa]
- more templte changes for translation [Angela Steinhardt]
- Fix typo [ci skip] [Alessandro Pisa]
- Fixed back-to-parent link [Manuel Reinhardt]
- Merge branch 'master' into translations_sidebar-history-div [Angela Steinhardt]
- translations added for sidebar parts, version history management, events portlet, chat and more [Angela Steinhardt]
- Merge pull request #909 from quaive/backports-3 [GitHub]
- Fixed typo [Alessandro Pisa]
- Add outdated field and fix query [Alessandro Pisa]
- Use ISiteSearch to get the sidebar documents [Alessandro Pisa]
- Further optimizations [Alessandro Pisa]
- Make some parts of the sidebar optional [Alessandro Pisa]
- Fix pat-display-time locales [Alessandro Pisa]
- Display the more menu only if user can add or edit [Alessandro Pisa]
- Merge pull request #905 from quaive/optimize-opening-folders [GitHub]
- Merge pull request #902 from quaive/sync-improvements [GitHub]
- Fix another test [Alessandro Pisa]
- Test updated [Alessandro Pisa]
- Fix wrong test (not unique selector) [Alessandro Pisa]
- update the tests [Alessandro Pisa]
- Fix the heisenbug Alice can edit modify status update of herself [Alessandro Pisa]
- We need just the sidebar.documents when expanding a folder [Alessandro Pisa]
- Clear the cache and be more resistent if a user is not there [Alessandro Pisa]
- Merge pull request #901 from quaive/news_app3 [GitHub]
- Merge pull request #904 from quaive/external-app [GitHub]
- Mark another unstable content_views test as noncritical [Guido A.J. Stevens]
- Merge pull request #903 from quaive/optimize-get-user [GitHub]
- Improve fastest differ so it actually finds all commits of this branch [Guido A.J. Stevens]
- Don't error on uninstall [Guido A.J. Stevens]
- Merge pull request #899 from quaive/metromap-optimizations [GitHub]
- Robustify loremipsum titles [Guido A.J. Stevens]
- Don't check out sources [Guido A.J. Stevens]
- Add app-redirect-to-url view [Cillian de Roiste]
- Merge pull request #900 from quaive/kill-previews-on-new-upload [GitHub]
- Be tolerant with non membrane users [Alessandro Pisa]
- Merge pull request #898 from quaive/remove-unused-code [GitHub]
- Speed up the case manager using the metromap tile [Alessandro Pisa]
- Add some very basic robot coverage for news magazine and publisher [Guido A.J. Stevens]
- Fix getting the fullname, remove portrait also from testing [Alessandro Pisa]
- Fix refactoring [Alessandro Pisa]
- Move the get_related_workspaces function to the view [Alessandro Pisa]
- remove comment for a function that will never exist [Alessandro Pisa]
- Reuse already memoized methods [Alessandro Pisa]
- Remove unused define [Alessandro Pisa]
- Remove unused define and fix user counting [Alessandro Pisa]
- Avoid circular dependencies [Alessandro Pisa]
- Use pi_api.userprofile.get when possible [Alessandro Pisa]
- Use pi_api.userprofile.get when possible [Alessandro Pisa]
- Basic install/uninstall tests for news [Guido A.J. Stevens]
- Move the existing_users method to the view [Alessandro Pisa]
- Also provide a :testing migration for good measure [Guido A.J. Stevens]
- Add migration to activate news [Guido A.J. Stevens]
- Purge previews before generating them async [Alessandro Pisa]
- Added a metromap tile [Alessandro Pisa]
- Remove unused code [Alessandro Pisa]
- Add missing stream portlet title now we're tuning portlets anyway [Guido A.J. Stevens]
- Merge pull request #897 from quaive/replicate-missing-markup [GitHub]
- Remove unused code [Alessandro Pisa]
- Audit and polish news portlet [Guido A.J. Stevens]
- Merge pull request #896 from quaive/split-sidebar-cleanup [GitHub]
- Replicate missing markup for the sidebar toggle to work on tablet [Alexander Pilz]
- Backport optimizations that were wiped out while merging #886 [Alessandro Pisa]
- Merge pull request #886 from quaive/split-sidebar.pt [GitHub]
- Configure fastest with news testing policy (tests to be provided...) [Guido A.J. Stevens]
- Run only fastest on Gitlab [Guido A.J. Stevens]
- Show proper title on news publisher app [Guido A.J. Stevens]
- Activate news portal tab [Guido A.J. Stevens]
- Catch empty leadimage in stream [Guido A.J. Stevens]
- Move legacy newsitems into app on install [Guido A.J. Stevens]
- Move legacy newsitems into app on install [Guido A.J. Stevens]
- Don't generate newsitem testcontent in Library [Guido A.J. Stevens]
- Show newsitem leadimage in stream [Guido A.J. Stevens]
- Merge branch 'master' into news_app3 [Guido A.J. Stevens]
- Do not inject [Alessandro Pisa]
- Fix tests [Alessandro Pisa]
- Rebase [Alessandro Pisa]
- Back to development: 1.2.0a25 [Alexander Pilz]
- Disable trending "more" [Guido A.J. Stevens]
- Properly index all news content auto-creation [Guido A.J. Stevens]
- Add sidebar toggle [Guido A.J. Stevens]
- Update markup and imperfectly resolve pat-inject/pat-modal clash (at the cost of not showing save confirmation) [Guido A.J. Stevens]
- Fix dates [Guido A.J. Stevens]
- Implement item delete (requires degraded injection as workaround for now) [Guido A.J. Stevens]
- Disable erroring batch markup [Guido A.J. Stevens]
- Section delete [Guido A.J. Stevens]
- Implement section create/edit and visibility [Guido A.J. Stevens]
- Fix create item dialog and handling [Guido A.J. Stevens]
- Hide "group by" and batch actions [Guido A.J. Stevens]
- Sort publisher by created not effective [Guido A.J. Stevens]
- Fix 'all news' link in item view [Guido A.J. Stevens]
- Implement "more section..." [Guido A.J. Stevens]
- Refactor query API to use portal_catalog (and make section reference mandatory) [Guido A.J. Stevens]
- Fix permission check on edit link [Guido A.J. Stevens]
- Apply magazine_home filter only on homepage [Guido A.J. Stevens]
- Implement metadata visibility toggles and do not accidentally remove hero [Guido A.J. Stevens]
- Edit text [Guido A.J. Stevens]
- Edit title [Guido A.J. Stevens]
- Show only published items in magazine (without section is allowed though) [Guido A.J. Stevens]
- Update metadata toggle [Guido A.J. Stevens]
- Implement preview [Guido A.J. Stevens]
- Fix review permission check [Guido A.J. Stevens]
- Badge unpublished items [Guido A.J. Stevens]
- Support barely-initialized news items [Guido A.J. Stevens]
- Hero upload [Guido A.J. Stevens]
- Implement section editing, and re-inject sidebar on save [Guido A.J. Stevens]
- Extract browser logic from content backend, and completely refactor accessors [Guido A.J. Stevens]
- Fix publisher regression [Guido A.J. Stevens]
- Implement NewsItemView [Guido A.J. Stevens]
- Section filtering [Guido A.J. Stevens]
- Implement news section view [Guido A.J. Stevens]
- Replace item macro with proper view delegation [Guido A.J. Stevens]
- Force newsfeed images to 16x9 center crop [Guido A.J. Stevens]
- News edit workflow and readonly mode [Guido A.J. Stevens]
- News basic metadata [Guido A.J. Stevens]
- Hook up basic metadata editing [Guido A.J. Stevens]
- .gitignore some [Guido A.J. Stevens]
- Show section [Guido A.J. Stevens]
- Hook up magazine with item macro and feed template re-use [Guido A.J. Stevens]
- News app integration [Guido A.J. Stevens]


1.2.0a24 (2016-11-10)
---------------------

- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Back to development: 1.2.0a24 [Alexander Pilz]
- Merge pull request #895 from quaive/member_can_replace [GitHub]
- Merge pull request #892 from quaive/refactor-tasks [GitHub]
- Merge pull request #890 from quaive/check-calendar-permission [GitHub]
- simply adding ids [Alexander Pilz]
- Merge pull request #894 from quaive/custom-label-order [GitHub]
- Move tasks method to the workspace view [Alessandro Pisa]
- Merge pull request #893 from quaive/calendar-format-timezone [GitHub]
- Chuck it [Guido A.J. Stevens]
- Remove click on auto-disappearing buttons [Guido A.J. Stevens]
- Introduce extra wait [Guido A.J. Stevens]
- flake8 [Manuel Reinhardt]
- Merge pull request #889 from quaive/case-avatar-tag [GitHub]
- Merge pull request #891 from quaive/fix-calendar-categories [GitHub]
- Support for custom tag order in sidebar grouping [Manuel Reinhardt]
- Output time zone in _format_date_time. This allows the calendar JS to properly localize times. [Manuel Reinhardt]
- Merge pull request #887 from quaive/optimizations [GitHub]
- Merge pull request #888 from quaive/workspaces-json-refactor [GitHub]
- Fixed calendar categories. Events were associated with all workspaces of the same type as their containing workspace. [Manuel Reinhardt]
- When creating an event in the calendar app, only show workspaces where the user has add permission. [Manuel Reinhardt]
- Use the api to get the avatar and cache it [Alessandro Pisa]
- Refactored WorkspacesJSONView for easier subclassing. [Manuel Reinhardt]
- Additional metadata are not displayed anyway [Alessandro Pisa]
- Do not try to query portal_catalog if we have no UIDs [Alessandro Pisa]
- Merge pull request #885 from quaive/optimize-permission-check [GitHub]
- Merge pull request #883 from quaive/sidebar-optimizations [GitHub]
- Merge pull request #882 from quaive/statusupdate-optimizations [GitHub]
- Merge pull request #884 from quaive/memoize-current-user [GitHub]
- Do not call can_add multiple times [Alessandro Pisa]
- Memoize the current user [Alessandro Pisa]
- Optimize the sidebar [Alessandro Pisa]
- Look for a userprofile before trying to search the user in PAS [Alessandro Pisa]
- Merge pull request #881 from quaive/calendar-toggle-sidebar [GitHub]
- Merge pull request #880 from quaive/timestamp-for-preview-urls [GitHub]
- Added #toggle-sidebar to calendar app [Manuel Reinhardt]
- Avoid caching after previews are regenerated [Alessandro Pisa]
- Merge pull request #879 from quaive/fix-calendar [GitHub]
- Merge pull request #878 from quaive/qrp-release [GitHub]
- Merge pull request #877 from quaive/related-workspaces-num-results [GitHub]
- Do not break badly if the timezone is not indexed [Alessandro Pisa]
- New release of quaive.resources.ploneintranet [Wolfgang Thomas]
- Return more results in WorkspacesJSONView [Manuel Reinhardt]
- Merge pull request #874 from quaive/870-pwreset-finish [GitHub]
- Customise pwreset_finish: add #document-content wrapper so that the header is dispalyed correctly, and turn "log in" into a link to the login form [Wolfgang Thomas]
- Customise pwreset_invalid: add #document-content wrapper [Wolfgang Thomas]
- Customize mail_password_response: add proper #document-content wrapper. Note: the inline style is there for a reason! [Wolfgang Thomas]
- override further PW resetting forms so that we can customize them [Wolfgang Thomas]
- Merge pull request #873 from quaive/backport-from-membrane-groups-9 [GitHub]
- Remove the unused and expensive to calculate _get_users_and_guests [Alessandro Pisa]
- Merge pull request #872 from quaive/backport-from-membrane-groups-8 [GitHub]
- Merge pull request #871 from quaive/backport-from-membrane-groups-7 [GitHub]
- Allow workgroups in workspacecontainers [Alessandro Pisa]
- If only_membrane_groups is True, use just the membrane catalog [Alessandro Pisa]
- Added only_membrane_groups registry record [Alessandro Pisa]
- Give an own template to the workgroup, so that the other view will still be working [Alessandro Pisa]
- Merge pull request #869 from quaive/backport-from-membrane-groups-6 [GitHub]
- Merge pull request #868 from quaive/related-workspaces-sorting [GitHub]
- Give an own template to the workgroup, so that the other view will still be working [Alessandro Pisa]
- Backports from the membrane groups branch [Alessandro Pisa]
- Sort WorkspacesJSONView by title [Manuel Reinhardt]
- Merge pull request #861 from quaive/backport-from-membrane-groups-5 [GitHub]
- Fix conflict in imports [Alexander Pilz]
- Merge pull request #860 from quaive/backport-from-membrane-groups-4 [GitHub]
- Merge pull request #857 from quaive/backport-from-membrane-groups-1 [GitHub]
- Merge pull request #859 from quaive/backport-from-membrane-groups-3 [GitHub]
- Merge pull request #862 from quaive/mark-heisenbug [GitHub]
- Merge pull request #855 from quaive/restricted-filters-switch [GitHub]
- Merge pull request #864 from quaive/related-workspaces-sitesearch [GitHub]
- Merge pull request #858 from quaive/backport-from-membrane-groups-2 [GitHub]
- add pinning to not break ext editor [Alexander Pilz]
- need authenticator in subform [Alexander Pilz]
- Merge branch 'master' of github.com:quaive/ploneintranet [Alexander Pilz]
- remove a loading-class to show the spinner on file version upload [Alexander Pilz]
- Merge pull request #856 from quaive/release-1.2.x [GitHub]
- Ported WorkspacesJSONView to ISiteSearch [Manuel Reinhardt]
- Try to fix an heisenbug [Alessandro Pisa]
- Group together normal users and guests [Alessandro Pisa]
- Fix membrane search to return the correct group id and look for all groups [Alessandro Pisa]
- Prepare for membrane groups [Alessandro Pisa]
- Added a memoize [Alessandro Pisa]
- Backport some modifications to the existing_users method [Alessandro Pisa]
- Merge pull request #854 from quaive/fix/calendar-timezone [GitHub]
- Allow bypassing filter restrictions [Manuel Reinhardt]
- Convert event dates back to original time zone. Solr indexes UTC times which gives the wrong date for whole_day events, [Manuel Reinhardt]


1.2.0a23 (2016-11-10)
---------------------

- Brown Bag release [Alexander Pilz]


1.2.0a22 (2016-11-03)
---------------------

- Merge pull request #853 from quaive/bookmarking-at-midnight [GitHub]
- Merge pull request #852 from quaive/search-enhancements [GitHub]
- Merge pull request #849 from quaive/release-1.2.x [GitHub]
- remove class [Alexander Pilz]
- make day not zero padded [Alexander Pilz]
- Skip test that can fail close to midnight [Alessandro Pisa]
- Merge pull request #851 from quaive/authenticator-to-workspace [GitHub]
- Allow to replace the search navigation overriding just one template [Alessandro Pisa]
- The div is needed for injection, even if we have no results [Alessandro Pisa]
- Do not try to display a preview if there is not [Alessandro Pisa]
- Fix batching [Alessandro Pisa]
- add an authenticator when linking to workspace from stream [Alexander Pilz]
- Merge pull request #850 from quaive/markup-fixes [GitHub]
- More markup fixes to fix sidebar positioning on doc and event view [Alexander Pilz]
- Back to development: 1.2.0a22 [Alexander Pilz]


1.2.0a21 (2016-11-01)
---------------------

- Merge pull request #848 from quaive/expandable-stream [GitHub]
- adapt test to new dom nesting [Alexander Pilz]
- Merge pull request #847 from quaive/markup-alignment-proto [GitHub]
- stream is now collapsible/expandable. Also markup has been aligned with proto [Alexander Pilz]
- Merge pull request #846 from quaive/versioning-improvements [GitHub]
- release theme and bump [Alexander Pilz]
- Disarmed a div.content which leads to a large padding around the comment box. Cornelis wants the div completely gone but we use it to carry an id which is used to inject the new post into the comment stream. And there is no replacement available. So this would mean major refactoring. I take this shortcut in stressful times. [Alexander Pilz]
- Changes requested in https://github.com/quaive/ploneintranet.prototype/commit/c95a10e63f9b088daab949c72303382bbc8f84e6 [Alexander Pilz]
- implement revert preview generation [Alexander Pilz]
- enable file download [Alexander Pilz]
- Make the CMFEditions template show [Alexander Pilz]
- fix styling [Alexander Pilz]
- Merge pull request #845 from quaive/fix-injection-parameter [GitHub]
- Merge pull request #844 from quaive/release-1.1.x [GitHub]
- Merge pull request #841 from quaive/release-1.2.x [GitHub]
- Fix the loading-class syntax [Alexander Pilz]
- Merge remote-tracking branch 'origin/release-1.2.x' into release-1.1.x [Guido A.J. Stevens]
- Merge pull request #843 from quaive/show-archived-tags-byline [GitHub]
- adapt test to changed markup (= the very essence of this PR) [Wolfgang Thomas]
- Indicate archived status of tags in byline. See https://github.com/quaive/ploneintranet.prototype/issues/350 [Manuel Reinhardt]
- Merge pull request #842 from quaive/fix_whole_day [GitHub]
- Load start and end date for whole_day events [Manuel Reinhardt]
- Back to development: 1.2.0a21 [Alexander Pilz]
- s/venus/gaia/ [Guido A.J. Stevens]
- Back to development: 1.1.0rc2 [Guido A.J. Stevens]
- Preparing release 1.1.0rc1 [Guido A.J. Stevens]
- Prepare Gaia RC1 [Guido A.J. Stevens]
- Include tag fetching in release docs [ci skip] [Guido A.J. Stevens]
- Merge pull request #641 from quaive/gaia_hotfix [GitHub]
- Apply Products.PloneHotfix20160830==1.0 [Guido A.J. Stevens]


1.2.0a20 (2016-10-28)
---------------------

- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Merge pull request #838 from quaive/minor-improvements [GitHub]
- Minor template improvements [Alessandro Pisa]
- Merge pull request #839 from quaive/450_statusupdate_notifications [GitHub]
- Properly hook up statusupdate notification views fixes #450 [Alessandro Pisa]
- Provide StatusUpdate.absolute_url() [Alessandro Pisa]
- Mark disabled test as skipped [Alessandro Pisa]
- Merge pull request #837 from quaive/documents-autosave [GitHub]
- Show the status popup if we are not autosaving [Alessandro Pisa]
- Merge pull request #836 from quaive/proper-registry-update [GitHub]
- Merge pull request #835 from quaive/documents-autosave [GitHub]
- no notifications, save every 20secs and use ISO date [Alexander Pilz]
- Remove debug statement and bump q.r.ploneintranet [Alexander Pilz]
- Update registry properly, without reloading everything again [Alexander Pilz]
- Optional autosave for selected portal_types [Alessandro Pisa]
- Merge pull request #833 from quaive/expand-portlets [GitHub]
- Merge pull request #832 from quaive/fix-tags-ordering [GitHub]
- fake commit [Alexander Pilz]
- Fix number [Alexander Pilz]
- Back to development: 1.2.0a110 [Alexander Pilz]
- Also collaps library portlet [Alexander Pilz]
- Add expand buttons to portlets [Alexander Pilz]
- Don't force alphabetical ordering if you have set a custom order [Alexander Pilz]


1.2.0a19 (2016-10-27)
---------------------

- Merge pull request #831 from quaive/markup-regression-fix [GitHub]
- Regression fix as requested in https://github.com/quaive/ploneintranet.prototype/commit/4d3747c4ac313183741628ae5e23c774702cbe98#commitcomment-19586122 [Alexander Pilz]
- Merge pull request #830 from quaive/show-archived-tags [GitHub]
- Merge pull request #824 from quaive/speedup-tooltips [GitHub]
- Merge pull request #829 from quaive/protect-general-settings [GitHub]
- Merge pull request #828 from quaive/update-resources [GitHub]
- Remember grouping when setting filters [Manuel Reinhardt]
- Activated option show_archived_tags [Manuel Reinhardt]
- Set cache headers and encoding headers [Alexander Pilz]
- Hide/disable hero image and global event settings if user can't change them [Manuel Reinhardt]
- Update quaive.resources.ploneintranet [Alessandro Pisa]
- Add charset [Alexander Pilz]
- wrap in proper html tag [Alexander Pilz]
- Merge pull request #826 from quaive/configurable-docconv-types2 [GitHub]
- Merge pull request #825 from quaive/tal-optimizations [GitHub]
- Merge pull request #822 from quaive/userprofile-optimization [GitHub]
- Fix tests: add fallback value for docconv registry [Cillian de Roiste]
- Suite testing: remove stray comment [Cillian de Roiste]
- Fix tests: Move the docconv registry config [Cillian de Roiste]
- Test setup: configure docconv before creating content [Cillian de Roiste]
- Configure docconv content types in the registry [Cillian de Roiste]
- Merge pull request #823 from quaive/776-fix-test [GitHub]
- Optimize tal templates [Alessandro Pisa]
- Merge pull request #821 from quaive/feature-flagging-membrane-groups [GitHub]
- don't render the main template for simple tooltip content. Solves diazo issues and speeds up the display a lot [Alexander Pilz]
- Adapt the test to the new UI [Alessandro Pisa]
- Do not call _get_my_groups_and_workspaces if not needed [Alessandro Pisa]
- Add workgroups without exposing them on the UI [Alessandro Pisa]
- Merge pull request #820 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.0a19 [Alexander Pilz]


1.2.0a18 (2016-10-24)
---------------------

- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Merge pull request #819 from quaive/reverse-group-sort [GitHub]
- Merge pull request #818 from quaive/app-tile-condition [GitHub]
- Grouped search: reverse sort by modified date [Cillian de Roiste]
- Added condition (expression) to apps [Manuel Reinhardt]
- Merge pull request #814 from quaive/post-view [GitHub]
- Include the permissions definition here in the configure.zcml where the permission is being used [Wolfgang Thomas]
- Revert "include permission" Including the permissions file just for the tests does not make sense. [Wolfgang Thomas]
- Merge pull request #815 from quaive/fix-injection-target-event [GitHub]
- Back to development: 1.2.0a18 [Alexander Pilz]
- include permission [Alexander Pilz]
- Readd injection of sidebar [Alexander Pilz]
- Implement pysailors suggestion [Alexander Pilz]
- fake commit to get jenkins to test [Alexander Pilz]
- Align injection behavior of events with document_content [Alexander Pilz]
- simpler is better [Alexander Pilz]
- Work to display posts. Commenting doesn't work yet [Alexander Pilz]


1.2.0a17 (2016-10-24)
---------------------

- Merge pull request #817 from quaive/dedicated-bookmark-portlets [GitHub]
- Merge pull request #816 from quaive/check-for-delete-permission [GitHub]
- Adding dedicated bookmark tiles [Alexander Pilz]
- Check if user can actually delete the workspace [Alexander Pilz]
- Merge pull request #812 from quaive/prep-global-events [GitHub]
- fix test [Alexander Pilz]
- fix initiator [Alexander Pilz]
- more abstractions for the content macros [Alexander Pilz]
- Fix the way how container is used to determine creation target [Alexander Pilz]
- don't require a container [Alexander Pilz]
- allow helper json views also from other places, like apps [Alexander Pilz]
- Allow creating events from within the app [Alexander Pilz]
- prep for global event support [Alexander Pilz]
- Merge pull request #811 from quaive/calendar-alien [GitHub]
- Support alien events on workspace calendars. Cache a bit [Alexander Pilz]
- Merge pull request #808 from quaive/sidebar-grouping [GitHub]
- more defensive get [Alexander Pilz]
- Merge pull request #809 from quaive/calendar-fixes [GitHub]
- Merge pull request #810 from quaive/persist-context-menu-for-real [GitHub]
- events for workspaces [Alexander Pilz]
- Calendar app points to calendars in workspaces [Alexander Pilz]
- added workspace calendar [Alexander Pilz]
- fix tests [Alexander Pilz]
- Fix selectors to identify delete button [Alexander Pilz]
- Fix import [Alessandro Pisa]
- Button fix [Alexander Pilz]
- Adapt app to new markup [Alexander Pilz]
- Add cogwheel dots to event as well [Alexander Pilz]
- Move actions into context menu [Alexander Pilz]
- Small cleanup for calendar, preparation for global Events, respecting whole_day events [Alexander Pilz]
- Sidebar: don't include the workspace in the items [Cillian de Roiste]
- Merge pull request #807 from quaive/link-type [GitHub]
- Sidebar bugfix: tags don't have the outdated attr [Cillian de Roiste]
- Sidebar: don't resort date groups alphabetically [Cillian de Roiste]
- add globe to add link in new window [Alexander Pilz]
- Implement markup for link content type [Alexander Pilz]
- change icons and positioning [Alexander Pilz]
- Merge pull request #806 from quaive/large-previews [GitHub]
- Use large previews to properly fill the page [Alexander Pilz]
- Change Case [Alexander Pilz]
- Merge pull request #805 from quaive/small-sidebar-optimization [GitHub]
- Optimize global view tal:define [Alessandro Pisa]
- Merge pull request #802 from quaive/image-preview-timestamp [GitHub]
- Merge pull request #803 from quaive/cog-wheel-events [GitHub]
- Fix markup [Alexander Pilz]
- also provide a cog wheel option on events. And name the tal properly [Alexander Pilz]
- Merge branch 'master' into image-preview-timestamp [Alexander Pilz]
- Fix broken test [Alexander Pilz]
- Append a time stamp to the image preview so that caches recognise it as new. Related to https://github.com/quaive/ploneintranet/pull/751 [Manuel Reinhardt]
- no absolute-url paths for tiles, they break virtual hosting [Alexander Pilz]
- Adding a title attribute (NOT through jenkins) [Alexander Pilz]
- Merge pull request #801 from quaive/light-reindex-default [GitHub]
- add logging to tell what is done [Alexander Pilz]
- Don't reindex Searchabletext by default. Only if stated explicitly [Alexander Pilz]
- Merge pull request #798 from quaive/polish-calendar [GitHub]
- remove check for empty grouping, which shouldn't show if there are no events, so that is correct behaviour [Alexander Pilz]
- Merge pull request #800 from quaive/solr-index-fix [GitHub]
- Lookup catches KeyErrors and logs them [Alessandro Pisa]
- Merge pull request #797 from quaive/todo-edit-indicator [GitHub]
- polishing [Alexander Pilz]
- When a todo gets saved, also re-inject the document content, so that we get to see a spinner [Wolfgang Thomas]
- Merge pull request #796 from quaive/align-with-proto [GitHub]
- fix the class names to get in line with proto again [Alexander Pilz]
- Merge pull request #795 from quaive/my_workspaces-returns-the-item [GitHub]
- The function my_workspaces returns the item [Alessandro Pisa]
- Merge pull request #794 from quaive/fix-missing-avatar-url [GitHub]
- Do not complain about missing avatar_url [Alessandro Pisa]
- Merge pull request #793 from quaive/only-my-workspaces [GitHub]
- Merge pull request #786 from quaive/785-fix-empty-fullname [GitHub]
- Merge pull request #789 from quaive/workspaces.tile-parameters [GitHub]
- Implement the only my workspaces checkbox [Alessandro Pisa]
- Merge pull request #792 from quaive/cog-wheel-stub [GitHub]
- turn off by default [Alexander Pilz]
- new files [Alexander Pilz]
- The function my_workspaces understands a limit parameter [Alessandro Pisa]
- adding stub code [Alexander Pilz]
- Merge pull request #787 from quaive/fix-case-manager-ajax [GitHub]
- Merge pull request #784 from quaive/personal-menu-vs-proto [GitHub]
- Merge pull request #783 from quaive/758-fix-avatar [GitHub]
- really only drop sidebar when called by itself [Alexander Pilz]
- If we do not have a username, put a nbsp [Alessandro Pisa]
- Personal menu is compliant with prototype [Alessandro Pisa]
- Merge pull request #782 from quaive/release-1.2.x [GitHub]
- Merge pull request #780 from quaive/fix-optional-fields [GitHub]
- Merge pull request #781 from quaive/improve-workspaces.tile [GitHub]
- Use pi api avatar tag wherever is possible [Alessandro Pisa]
- Back to development: 1.2.0a17 [Guido A.J. Stevens]
- Some improvements on the WS tile [Alessandro Pisa]
- Some fields may be missing [Alessandro Pisa]


1.2.0a16 (2016-10-03)
---------------------

- Merge pull request #778 from quaive/fixes-from-design-review [GitHub]
- Wait for injection to finish [Alessandro Pisa]
- add missing dot [Alessandro Pisa]
- Align app view with proto to regain the right behaviour. Fix the data pat switch patameters, focus is now set on application-body [Alessandro Pisa]
- Merge pull request #779 from quaive/publish_once [GitHub]
- An object may be published widely only once [Guido A.J. Stevens]
- Merge pull request #777 from quaive/heisenbug-6 [GitHub]
- Fix heisenbug declaration [Alessandro Pisa]
- Allow robot-server to run the search robot tests [Alessandro Pisa]
- Mark newly merged test as [heisenbug] refs #776 [Guido A.J. Stevens]
- Merge pull request #773 from quaive/archive-story [GitHub]
- Improve archiving UI [Alessandro Pisa]
- Merge pull request #774 from quaive/publish_widely [GitHub]
- Only the solr tests fail, refs #772 #606 [Guido A.J. Stevens]
- Merge pull request #745 from quaive/heisenbugs-5 [GitHub]
- Skip workflow state check on objects without a workflow [Guido A.J. Stevens]
- Store source/target relations for later use. Even though we don't expose this in the UI yet, store basic relations data. Use simple UUID pointers to avoid plone.app.relations overhead. [Guido A.J. Stevens]
- Extend test coverage. No robot test because of z-index Selenium troubles. [Guido A.J. Stevens]
- Implement copy to library [Guido A.J. Stevens]
- IPublishWidely is an adapter, not a marker interface [Guido A.J. Stevens]
- Hook up templates and view, no biz logic yet [Guido A.J. Stevens]
- Add upgrade step to activate IPublishWidely behavior [Guido A.J. Stevens]
- Apply no-op IPublishWidely behavior [Guido A.J. Stevens]
- Merge pull request #769 from quaive/deduplicate_theme [GitHub]
- Merge pull request #771 from quaive/make-jenkins-clean [GitHub]
- Remove setuptools cruft installed by virtualenv. Bit of a hack cannot be avoided: --no-setuptools also does not install pip, which we do need. [Guido A.J. Stevens]
- Merge pull request #767 from quaive/prepare-for-pinning [GitHub]
- Merge pull request #770 from quaive/expermimental.publishtraverse [GitHub]
- Mark broken test as [fixme] to unblock PRs refs #772 #745 [Guido A.J. Stevens]
- Cleanup not just the virtualenv but also trigger a solr rebuild [Guido A.J. Stevens]
- make clean in jenkins like we already do in gitlab [Alexander Pilz]
- Merge pull request #760 from quaive/app_enhance [GitHub]
- Audit and fix zope.Public permissions, refs #765 [Alexander Pilz]
- Improve detection of already-merged commits [Alexander Pilz]
- Fixing zope.Public permissions [Alexander Pilz]
- fixing zope.public permissions [Alexander Pilz]
- Split full test run across two runners, as intended always, to avoid timeouts [Alexander Pilz]
- Improve viewable elements in userprofile view [Alexander Pilz]
- Merge pull request #766 from quaive/zope-public [GitHub]
- Move main_template test to quaive.resources.ploneintranet and include q.r.p. as a test egg [Guido A.J. Stevens]
- Install experimental.publishtraverse following #765, see also 128d20ee [Guido A.J. Stevens]
- Merge pull request #768 from quaive/fastest [GitHub]
- Remove duplicated main_template and registry from theme. These are now provided by quaive.resources.ploneintranet. Keeping browser layer which is still used. [Guido A.J. Stevens]
- Audit and fix zope.Public permissions, refs #765 [Guido A.J. Stevens]
- Improve detection of already-merged commits [Guido A.J. Stevens]
- Remove dangling pass [Guido A.J. Stevens]
- Merge branch 'app_enhance' of github.com:quaive/ploneintranet into app_enhance [Guido A.J. Stevens]
- Missed another app_url change [Guido A.J. Stevens]
- Merge pull request #763 from quaive/improve-hiding-info-in-userprofile [GitHub]
- Add basic pinning support. By default, this is deactivated until the proper registry entry is set. This allows to implement own pinning storages as needed through adapter. In this form, this only marks items pinned via an interface. [Alexander Pilz]
- Fixing zope.Public permissions [Alessandro Pisa]
- Make the bookmark view implement IBlocksTransformEnabled [Alessandro Pisa]
- Merge pull request #764 from quaive/fastest [GitHub]
- fixing zope.public permissions [Alexander Pilz]
- Split full test run across two runners, as intended always, to avoid timeouts [Guido A.J. Stevens]
- Merge pull request #762 from quaive/test_desktop [GitHub]
- Improve viewable elements in userprofile view [Alessandro Pisa]
- Switch our default test suite to desktop mode, instead of large tablet. We might wish to investigate whether we can run all the tests at multiple resolutions. [Guido A.J. Stevens]
- Enable messaging on mobile, and fix regressions caused by layout app_url change [Guido A.J. Stevens]
- Merge pull request #761 from quaive/hook-additional-links [GitHub]
- Add a simple hook so that integrators can add more links to user menu [Alexander Pilz]
- Provide IAppContent() adapter to determine the app an object is contained in. [Guido A.J. Stevens]
- IApp.app_path is now IApp.app [Guido A.J. Stevens]
- Merge pull request #757 from quaive/ci_fix [GitHub]
- Postpone upgrade for news action [Guido A.J. Stevens]
- Cache diazo by default [Guido A.J. Stevens]
- Cleanup the app protocol to prepare for the news app. - Now supports IAppContainer (e.g.: news, workspaces, library) outside of the IAppsContainer (apps) - The 'view' (e.g. news magazine) on an IApp can be different from the 'app tile view' (news publisher) [Guido A.J. Stevens]
- Force cleanup of virtualenv provided setuptools on every gitlab-ci run [Guido A.J. Stevens]
- Merge pull request #756 from quaive/do-not-fail-updating-properties [GitHub]
- Merge pull request #755 from quaive/configurable-userprofile-view [GitHub]
- Do not fail if self.context has not property_name [Alessandro Pisa]
- Merge pull request #754 from quaive/latest-buildout-setuptools [GitHub]
- Merge pull request #753 from quaive/fastest [GitHub]
- Control the displayed information on the userprofile view through tthe registry [Alessandro Pisa]
- update zc.buildout and setuptools [Alessandro Pisa]
- Merge pull request #751 from quaive/versioning [GitHub]
- Update .dockerignore [Guido A.J. Stevens]
- Merge pull request #752 from quaive/upgrade-five.intid [GitHub]
- Pipe fastest output realtime so we can see what's going on. [Guido A.J. Stevens]
- Adapted robot test to new layout [Manuel Reinhardt]
- Upgrade five.intid [Alessandro Pisa]
- Display error instead of swallowing it [Manuel Reinhardt]
- Merge pull request #746 from quaive/712-variable-fix [GitHub]
- Merge pull request #747 from quaive/plone-5.0.6 [GitHub]
- Merge pull request #750 from quaive/748-bulktag-groupings [GitHub]
- Merge pull request #749 from quaive/706-sidebar-folders-first [GitHub]
- Added versioning support (via plone.app.versioningbehavior) [Manuel Reinhardt]
- define variable `img_data` outside of `if` statement. Fixes #712 [Wolfgang Thomas]
- update grouping storage when performing bulk tagging. fixes #748 [Wolfgang Thomas]
- Sort folders forst in the sidebar. Fixes #706 [Wolfgang Thomas]
- Upgrade to Plone-5.0.6 [Alessandro Pisa]
- Merge pull request #742 from quaive/heisenbugs-2 [GitHub]
- Click Element to open it [Alessandro Pisa]
- Try to fix Allan can search in solr tests [Alessandro Pisa]
- Merge pull request #740 from quaive/734-fix-tz-dependent-tests [GitHub]
- Merge pull request #738 from quaive/workspace-tile [GitHub]
- Merge pull request #744 from quaive/heisenbugs-4 [GitHub]
- Merge pull request #741 from quaive/heisenbugs [GitHub]
- Merge pull request #743 from quaive/heisenbugs-3 [GitHub]
- Submit the form instead of clicking [Alessandro Pisa]
- Make the file input visible via javascript [Alessandro Pisa]
- Give the page the time to load [Alessandro Pisa]
- Wait for injection to be finished [Alessandro Pisa]
- Introduce a workspace tile [Alessandro Pisa]
- Merge pull request #739 from quaive/fix-injection-source [GitHub]
- Merge pull request #737 from quaive/events-are-unbokkmarkable [GitHub]
- Merge pull request #735 from quaive/do-not-show-image-if-preview-is-missing [GitHub]
- fix the injection config [Alexander Pilz]
- Do not make the test depend on the timezone [Alessandro Pisa]
- Events should be unbookmarkable [Alessandro Pisa]
- Merge pull request #736 from quaive/preview-url-always-string [GitHub]
- Merge pull request #732 from quaive/fix-group-view [GitHub]
- Do not fail if preview is missing [Alessandro Pisa]
- Always return a tstring, even an empty one [Alessandro Pisa]
- Merge pull request #733 from quaive/727-fix-ws-from-template [GitHub]
- When a WS template gets copied, first invalidate the user cache and set a new SecurityManager before attempting to rename. Fixes #727 [Wolfgang Thomas]
- Add optional user-cache invalidation [Wolfgang Thomas]
- factor out _reset_security_context into stand-alone method [Wolfgang Thomas]
- Merge pull request #731 from quaive/speedfix-pas-getallmembers [GitHub]
- align group view with new proto [Alexander Pilz]
- oops [Alexander Pilz]
- Merge pull request #726 from quaive/do-not-steal-focus [GitHub]
- Don't get and wrap all users just to get the number of members. This information is not vital here [Alexander Pilz]
- Merge pull request #730 from quaive/render-sidebar-only-when-needed [GitHub]
- Reload the sidebar on a POST [Alessandro Pisa]
- Container should reload the sidebar [Alessandro Pisa]
- We do not want to always render the sidebar [Alessandro Pisa]
- Merge pull request #728 from quaive/external-url-tab [GitHub]
- Allow external URLs in portal_tabs [Alessandro Pisa]
- Merge pull request #721 from quaive/contacts-portlet-tweaks [GitHub]
- Merge pull request #722 from quaive/bidirectional-ws-relation [GitHub]
- Merge pull request #717 from quaive/workspace-sort-options [GitHub]
- Autosubmit does not steal focus [Alessandro Pisa]
- min -> max [Alessandro Pisa]
- Merge pull request #725 from quaive/ws-uid-length [GitHub]
- Merge pull request #724 from quaive/723-nuke-default-content-only-on-full-profile [GitHub]
- better check for determining if a group id corresponds to a special WS group [Wolfgang Thomas]
- make the definition of available_groups global, so that it can be imported in other places [Wolfgang Thomas]
- Nuke default content only when installing the default profile [Alessandro Pisa]
- Workspace relation is symetric [Alessandro Pisa]
- Merge pull request #719 from quaive/events-portlet-tweaks [GitHub]
- Merge pull request #715 from quaive/proto-view [GitHub]
- Workaround: Use global search instead of contacts portlet. The selector .title:contains(Alice Lindström) fails on the injected results in the contacts portlet. The non-ascii character is rendered incorrectly in the robot browser, while in a full instance it's fine. [Manuel Reinhardt]
- Contacts portlet: Improved avatars, link to contacts app; see prototype [Manuel Reinhardt]
- Create an easy overridable @@proto view [Alessandro Pisa]
- Merge pull request #718 from quaive/avatar-title-fullname [GitHub]
- Update test [Alessandro Pisa]
- Restored "Show all events" link [Manuel Reinhardt]
- Implement sorting on most active workspaces [Alessandro Pisa]
- Use fullname in the title attribute of the avatar link, fall back to user id. See prototype. [Manuel Reinhardt]
- Merge pull request #714 from quaive/demo [GitHub]
- Merge pull request #713 from quaive/remove-folder [GitHub]
- Increase resolution of document previews in bookmarks [Guido A.J. Stevens]
- Remove obsolete folder [Alessandro Pisa]
- Merge pull request #711 from quaive/fix-search-type [GitHub]
- Fix type_name "Profile" [Alessandro Pisa]
- Merge pull request #709 from quaive/demo [GitHub]
- Update q.r.p. fixes #705 [Guido A.J. Stevens]
- Support more friendly types refs #704 [Guido A.J. Stevens]
- Don't fall back to broken PI logo when there is no preview, refs #704 [Guido A.J. Stevens]
- Add special demo buildout which disables CSRF [Guido A.J. Stevens]
- Render high-res previews in office files search result fixes #707 [Guido A.J. Stevens]
- Work around #708 for now by disabling pat-equalizer [Guido A.J. Stevens]
- Merge pull request #703 from quaive/calendar [GitHub]
- select is actually not visible itself, so the check must change [Alexander Pilz]
- readd apparently non-necessary deps. Without them we get duplicate profile errors. WTF? [Alexander Pilz]
- test fixes [Alexander Pilz]
- don't create events from app. Do it within the workspace [Alexander Pilz]
- Merge branch 'master' into calendar [Alexander Pilz]
- push missing files [Alexander Pilz]
- Push missing tests and address gysts PR comments [Alexander Pilz]
- Merge pull request #702 from quaive/purge_and_refresh_security_manager [GitHub]
- Merge pull request #701 from quaive/fti-title-in-select [GitHub]
- Merge branch 'master' into calendar [Alexander Pilz]
- adding tests [Alexander Pilz]
- update pinnings [Alexander Pilz]
- removed unnecessary form [Alexander Pilz]
- Merge pull request #700 from quaive/release-1.2.x [GitHub]
- Purge security manager even if we have a KeyError [Alessandro Pisa]
- Display the fti title in the special workspaces section [Alessandro Pisa]
- pytz 'does not work' with datetime tzinfo. Use localize instead Symptoms are times in 'LMT' format which are off a few minutes. See http://stackoverflow.com/questions/24856643/unexpected-results-converting-timezones-in-python [Alexander Pilz]
- Back to development: 1.2.0a16 [Guido A.J. Stevens]
- display current date on cal tile [Alexander Pilz]
- cleanup and proper display of the invited calendar [Alexander Pilz]
- sidebar, user data fetcher, alignment sidebar selector and event classes [Alexander Pilz]
- Initial skeleton [Alexander Pilz]
- initialise package [Alexander Pilz]


1.2.0a15 (2016-09-14)
---------------------

- Merge branch 'master' into release-1.2.x [Guido A.J. Stevens]
- Merge pull request #679 from quaive/implement-only-my-documents [GitHub]
- Merge pull request #696 from quaive/695_arau_manymany [GitHub]
- Search for any substring matches, not only match on beginning [Guido A.J. Stevens]
- Add log warning in case of many clauses, refs #695 [Guido A.J. Stevens]
- Avoid recursion error in scorched with many arau, refs #695 [Guido A.J. Stevens]
- Merge pull request #694 from quaive/workspace-calendar [GitHub]
- Add workspace field to display calendar globally [Cillian de Róiste]
- Merge pull request #693 from quaive/update_qrp [GitHub]
- Merge pull request #692 from quaive/custom-tag-order [GitHub]
- Reimplement ci_skip test because c41760cf9959b43e2a3f72b5f got squashed [Guido A.J. Stevens]
- Redo whitespace change to test [ci skip] replaces c41760cf9959b [Guido A.J. Stevens]
- Upgrade quaive.resources.ploneintranet to 1.3.0a7 [Guido A.J. Stevens]
- Merge pull request #691 from quaive/ldap_sync [GitHub]
- Add robot tests for reordering tags [Cillian de Róiste]
- Don't break the sync when encountering a membrane group [Guido A.J. Stevens]
- Document all the magic moves needed to make LDAP work properly [Guido A.J. Stevens]
- Avoid using TestRequest [Alessandro Pisa]
- Show only my documents [Alessandro Pisa]
- Merge pull request #690 from quaive/bookmark-on-workspace [GitHub]
- hook up in workspace view [Alexander Pilz]
- prepare PI bookmark workspace on workspace view [Alexander Pilz]
- Allow a manager to reorder workspace tags [Cillian de Róiste]
- Back to development: 1.2.0a15 [Alexander Pilz]


1.2.0a14 (2016-09-09)
---------------------

- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Event portlet fixes (#688) [GitHub]
- Fix grouped search sorting (#689) [Alexander Pilz]
- Fastest ci skip support, speedup history analysis (#687) [Alexander Pilz]
- Release 1.2.0a13 [ci skip] (#686) [GitHub]
- Back to development: 1.2.0a14 [Alexander Pilz]


1.2.0a13 (2016-09-08)
---------------------

- Order Grouping Values (#685) [GitHub]
- Merge pull request #684 from quaive/release-1.2.x [GitHub]
- Merge pull request #683 from quaive/resilient-dashboard [GitHub]
- Back to development: 1.2.0a13 [Alexander Pilz]
- Make sure we don't redirect but directly load dashboard again. Otherwise the post parameter is missing unless you use a transparent proxy [Alexander Pilz]


1.2.0a12 (2016-09-08)
---------------------

- Handle subject encoding (#681) [GitHub]
- GroupedSearch: sort grouped results (#682) [Alexander Pilz]
- Use a bigger version of the avatar image so that users don't appear blurred (#680) [GitHub]
- Merge pull request #677 from quaive/release-1.2.x [GitHub]
- Follow up for PR #656 (#666) [Alexander Pilz]
- Back to development: 1.2.0a12 [Alexander Pilz]


1.2.0a11 (2016-09-06)
---------------------

- Fastest optimizations (#676) [Alexander Pilz]
- Disable bulk subscription by default (#665) [Alexander Pilz]
- We want the app view to be able to transform the tile (#675) [Alexander Pilz]
- Merge pull request #674 from quaive/do-not-be-rude-in-getting-groupings [GitHub]
- Check if grouping is there before getting it [Alessandro Pisa]
- Merge pull request #667 from quaive/fastest [GitHub]
- Merge pull request #672 from quaive/release-1.2.x [GitHub]
- Merge pull request #673 from quaive/fix-mail-encoding [GitHub]
- Merge pull request #671 from quaive/bump-cmfnotification [GitHub]
- encode instead of another decode [Alexander Pilz]
- Back to development: 1.2.0a11 [Alexander Pilz]
- bump [Alexander Pilz]
- Anchor docs, improve logging, improve fastest config [Guido A.J. Stevens]
- Actually return the status code or failures go undetected [Guido A.J. Stevens]
- Add argparse docs [Guido A.J. Stevens]
- Add fastest and docs config for fastest runner [Guido A.J. Stevens]
- Document fastest runner [Guido A.J. Stevens]
- Hook up in gitlab [Guido A.J. Stevens]
- Only optimize if *all* paths had a match [Guido A.J. Stevens]
- Fastest diff tester baseline implementation [Guido A.J. Stevens]


1.2.0a10 (2016-09-05)
---------------------

- Bulk download: include images (#670) [Alexander Pilz]
- minimal proto align fixes [ci skip] (#669) [GitHub]
- Merge pull request #663 from quaive/bump-cmfnotification [GitHub]
- Merge pull request #664 from quaive/fix-pinned-version [GitHub]
- pin correct version of script [Alexander Pilz]
- Merge branch 'master' into bump-cmfnotification [Alexander Pilz]
- new Products.CMFNotifications to avoid write on read [Alexander Pilz]
- Microblog attachments api (#661) [Alexander Pilz]
- Change the mailrouter to create a mail with attachments (#659) [Alexander Pilz]
- 'Create structure' is still unstable, refs #521 [Guido A.J. Stevens]
- Merge pull request #656 from quaive/csrf-token [GitHub]
- Merge pull request #658 from quaive/CMFNotification-upgrade [GitHub]
- Products.CMFNotification 2.3b4 → 2.4b1 [Cillian de Róiste]
- ok, agreed. Let's add it in the template [Alexander Pilz]
- Include tag fetching in release docs [ci skip] [Guido A.J. Stevens]
- Merge pull request #651 from quaive/release-1.2.x [GitHub]
- add csrf token to url when using injection on workspaces overview [Alexander Pilz]
- Save PDF versions of Documents for bulk download (#655) [Alexander Pilz]
- Merge pull request #654 from quaive/link_test_noncritical [GitHub]
- Back to development: 1.2.0a10 [Guido A.J. Stevens]
- Member can create a link was prematurely declared fixed, refs #609 [Guido A.J. Stevens]
- Apparently we lost some upgrade step registrations during a faulty merge resolution I did. This fixes it (#652) [GitHub]


1.2.0a9 (2016-09-01)
--------------------

- Update changelog (!!!!) [Guido A.J. Stevens]
- Member can create a link was prematurely declared fixed, refs #609 [Guido A.J. Stevens]
- Back to development: 1.2.0a9 [Alexander Pilz]


1.2.0a8 (2016-09-01)
--------------------

- Preparing release 1.2.0a8 [Alexander Pilz]
- Update manifest [Alexander Pilz]
- Update changelog [Alexander Pilz]
- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Use ISiteSearch to retrieve events for dashboard portlet (#637) [Alexander Pilz]
- attempt to fix a heisenbug by waiting and selecting smarter - and fix… (#643) [GitHub]
- Added an only_if_installed decorator (#645) [Alexander Pilz]
- Merge pull request #646 from quaive/third-logo-version [GitHub]
- Fix resources version [Alessandro Pisa]
- bump resources [Alessandro Pisa]
- Cornelis has introduced a third logo item for mobile use. Needs to be deployed with q.r.p 1.3.0b5 [Alessandro Pisa]
- Merge pull request #648 from quaive/translation-update [GitHub]
- Merge pull request #647 from quaive/enable-sidebar-toggle [GitHub]
- updated translations [Alexander Pilz]
- fixed templates to be ascii [Alexander Pilz]
- added missing i18n:translate statements [Alexander Pilz]
- turn on sidebar toggle [Alexander Pilz]
- Merge pull request #630 from quaive/fix-sidebar-functions-dom [GitHub]
- remove print statement [Alexander Pilz]
- Merge pull request #644 from quaive/improve-heisenbug-dolly [GitHub]
- add devices property to tell which app should appear on which device … (#636) [GitHub]
- Apply Products.PloneHotfix20160830==1.0 (#639) [Alexander Pilz]
- Add a wait statement [Alexander Pilz]
- more test fixes [Alexander Pilz]
- Update markup  (#634) [GitHub]
- Fix injection and tests (#635) [Alexander Pilz]
- fix tests [Alexander Pilz]
- fix classes [Alexander Pilz]
- make the batch more a button [Alexander Pilz]
- markup fixes after merge messup [Alexander Pilz]
- temporarily deactivate sidebar toggle, it overlays tasks. Refs #340 [Alexander Pilz]
- fix test [Alexander Pilz]
- Merge branch 'master' into fix-sidebar-functions-dom [Alexander Pilz]
- fix test [Alexander Pilz]
- Add the new sidebar toggle bottom left (#633) [GitHub]
- fix a test [Alexander Pilz]
- Merge branch 'master' into fix-sidebar-functions-dom [Alexander Pilz]
- Make the subscribe bulk action configurable (#632) [Alexander Pilz]
- bump resources [Alexander Pilz]
- Fix the target for the sidebar enlarger (#629) [GitHub]
- New events portlet with tabs and search field (#631) [Alexander Pilz]
- testfixes [Alexander Pilz]
- Merge pull request #628 from quaive/dom-fixes-case [GitHub]
- Fix the dom of sidebar functions so that they open in a tooltip [Alexander Pilz]
- Make the login splash image configurable (#627) [Alexander Pilz]
- New avatar markup with fallback for users without portrait. (#615) [Alexander Pilz]
- Fixes on the dom of cases, fixes alignment issues on case sidebar when just injected from workspaces overview [Alexander Pilz]
- Statusmessage whitelist hardcoded [ci skip] (#626) [Alexander Pilz]
- Proper breadcrumbs for Apps (#625) [Alexander Pilz]
- Remove the Gemfile (#623) [Alexander Pilz]
- Extra bulk actions: archive, subscribe & download (#621) [Alexander Pilz]
- Merge pull request #624 from quaive/app-can-have-class [GitHub]
- Merge pull request #622 from quaive/618-whitelist-for-status-updates [GitHub]
- Make it possible to define a CSS class for an app that is different from its id, while keeping the fallback to the id. This is needed in case we have 2 apps of the same kind, like with the taxonomy browser [Wolfgang Thomas]
- Merge pull request #620 from quaive/app-can-have-parameters [GitHub]
- Merge pull request #619 from quaive/hero-image [GitHub]
- The method content_statechanged whitelists objects [Alessandro Pisa]
- App can have parameters [Alessandro Pisa]
- add test [Alexander Pilz]
- add hero image support [Alexander Pilz]
- The bookmark portlet has now two tabs (#611) [Alexander Pilz]
- Fix the upgrade step to0004 (#614) [Alexander Pilz]
- Merge pull request #616 from quaive/delete-confirmation-empty-warning [GitHub]
- Merge pull request #613 from quaive/update-qrp-pinning [GitHub]
- Pull in q.r.p. regression fix for messages [Guido A.J. Stevens]
- Temporarily mark breaking tests on master as noncritical refs #617 [Guido A.J. Stevens]
- Fixed nesting of condition. Fixes empty warning message. [Manuel Reinhardt]
- Merge pull request #612 from quaive/fix-typo [GitHub]
- updated pinning [Alexander Pilz]
- Fix a typo preventing pi.bookmarks to upgrade [Alessandro Pisa]
- Merge remote-tracking branch 'origin/upgrade-audit-log' [Guido A.J. Stevens]
- Merge pull request #599 from quaive/updated-proto [GitHub]
- Mark recent test regression as unstable refs #607 (#608) [Alexander Pilz]
- Upgrade audit log [Alessandro Pisa]
- Mark UI fail of new Link feature in new proto shell as FIXME ... to enable merge of update-proto and forward fixing later. Refs #609 [Guido A.J. Stevens]
- Mark recent test regression as unstable refs #607 [Guido A.J. Stevens]
- Restore document stream accidentally removed in merge [Guido A.J. Stevens]
- Merge branch 'master' into updated-proto [Guido A.J. Stevens]
- Merge pull request #603 from quaive/remove-persistent-lists [GitHub]
- Merge pull request #605 from quaive/559-bookmarks-by-bookmarking-date [GitHub]
- Merge pull request #604 from quaive/bookmark-people [GitHub]
- Merge pull request #601 from quaive/app-content-type [GitHub]
- Merge pull request #602 from quaive/ccc_tuning [GitHub]
- Merge pull request #589 from quaive/weblink [GitHub]
- Filter bookmarks by bookmaring date [Alessandro Pisa]
- Add the possibility to bookmark people [Alessandro Pisa]
- Colorize workspace variants [Guido A.J. Stevens]
- we actually need to mark fixme-tests as noncritical [Wolfgang Thomas]
- ploneintranet_notifications is less prone to conflict errors [Alessandro Pisa]
- Give up for now, mark the 2 solr search tests as fixme [Wolfgang Thomas]
- attempt to fix this failed jbot overrides integration in test setup [Wolfgang Thomas]
- Follows our discussion on #ploneintranet gyst: the jbot stanza should be moved to browser/configure.zcml and bound to a layout interface [Wolfgang Thomas]
- Create the bookmark app [Alessandro Pisa]
- Test fixes [Alessandro Pisa]
- Adapt ploneintranet.messaging to work in the context of the messages app [Alessandro Pisa]
- Only content is bookmarkable [Alessandro Pisa]
- The bookmark app is now aware of the app content type [Alessandro Pisa]
- The case manager available only in the app context [Alessandro Pisa]
- Apps are now a content type [Alessandro Pisa]
- Merge pull request #600 from quaive/gaia2master [GitHub]
- Merge branch 'master' into gaia2master, resolve conflicts by preferring master. [Guido A.J. Stevens]
- test fixes [Alexander Pilz]
- Merge branch 'master' into updated-proto [Alexander Pilz]
- pin new shell protoll proto [Alexander Pilz]
- Revert "check out quaive.resources.ploneintranet as source, in branch updated-proto" [Alexander Pilz]
- Enable message contacts search always, except on empty roster (#594) [Alexander Pilz]
- Document adding a new behavior with a facet field (#591) [Alexander Pilz]
- Fix "All day event" (#597) [Alexander Pilz]
- fix click search result [Alexander Pilz]
- trying a larger viewport [Alexander Pilz]
- fix bug where ff in robot test wouldn't open the more menue [Alexander Pilz]
- button is now called Log in [Alexander Pilz]
- fix bulk action selector [Alexander Pilz]
- Continues / fixes 2abdcf1761e0c2fcc496ca6d563e24e3a24fef92 Don't allow to pick a workspace that is already part of the selection, and don't offer the own workspace for selection [Wolfgang Thomas]
- Continues / fixes 2abdcf1761e0c2fcc496ca6d563e24e3a24fef92 Only show the "you might be interested in" text if there are actually related workspaces present [Wolfgang Thomas]
- Continues / fixes 2abdcf1761e0c2fcc496ca6d563e24e3a24fef92 We define a list of ASCIILines. The widget therefore expects to receive text that contains new-line characters. The text will be split into a list by these new-line characters. But pat-select pattern will return a comma-separated text of values. And in case we mix existing values and add new ones, we automatically get a list in the request. Therefore, before calling dexterity update, make sure we have a string the separates the values by new-line [Wolfgang Thomas]
- Remove hackish shortcut introduced in 2abdcf1761e0c2fcc496ca6d563e24e3a24fef92 We need to get our data types for z3c.form straight [Wolfgang Thomas]
- Fix tests to create folders via the top functions, now that the bottom buttons are gone [Alexander Pilz]
- older events should now always be visible by default [Alexander Pilz]
- fix case where related is None [Alexander Pilz]
- make the xpath expression exact [Alexander Pilz]
- fix delete confirmation button selector [Alexander Pilz]
- fix sidebar indentation issue on cases [Alexander Pilz]
- fix icon order on events form [Alexander Pilz]
- fix too large comments box (one space too many) [Alexander Pilz]
- fix width of date / time fields [Alexander Pilz]
- 1) Don't dsiplay a relative date in the title of events. 2) "Older events" should not be a collapsible (it is not a collapsible in proto) [Alexander Pilz]
- sidebar toggle fixed [Alexander Pilz]
- add pat-bumper to top sidebar actions and bulk actions [Alexander Pilz]
- Fix the order of batch functions and folder title in sidebar [Alexander Pilz]
- Remove no longer necessary create document and folder buttons at the end of the sidebar [Alexander Pilz]
- Remove no longer existing div#project-body [Alexander Pilz]
- align workspaces markup with dashboard and app markup so that the diazo rule works properly [Alexander Pilz]
- Use "current" class in library nav [Alexander Pilz]
- tiles overview: use injection [Alexander Pilz]
- workspaces overview: use injection [Alexander Pilz]
- align delete warning with proto [Alexander Pilz]
- fixing the delete confirmation modal, no need to render main template. Hook up in sidebar [Alexander Pilz]
- align bulk actions with proto [Alexander Pilz]
- temporarily move title and desc up so that they don't overlay the bulk actions. Refs GH pi.prototype #325 [Alexander Pilz]
- Adapted sidebar to new proto [Alexander Pilz]
- add structure to properly render the stats [Alexander Pilz]
- fix markup [Alexander Pilz]
- Make it possible to have a custom login-form Disclaimer text (nor None) via registry. Also add the "login" button to the template so that it can be replaced by diazo (Changing the text on the button can happen by overwriting the translation for label_log_in in the "plone" domain) [Alexander Pilz]
- give proper id to library page container [Alexander Pilz]
- When we're viewing an app (in the Apps context), the logo link must point to the Apps section [Alexander Pilz]
- Fix duplicate id in template [Alexander Pilz]
- For (un-)bookmarking a workspace, we need to clode the pat-message modal, otherwise the n navigation is not clickable [Alexander Pilz]
- fix share tooltip [Alexander Pilz]
- fix markup for lib [Alexander Pilz]
- fix markup for todo [Alexander Pilz]
- fix markup for case-manager [Alexander Pilz]
- portal tabs are injected now, so we must wait for the injection to finish [Alexander Pilz]
- fix case and workspace tests [Alexander Pilz]
- fix markup of search results [Alexander Pilz]
- fix for case markup [Alexander Pilz]
- Make login button more precise [Alexander Pilz]
- quick fix for type icon [Alexander Pilz]
- fix diazo for bookmarks [Alexander Pilz]
- implement member display in ws header [Alexander Pilz]
- Fix markup of content in workspace [Alexander Pilz]
- Fix markup of workspaces view [Alexander Pilz]
- fix classes and complete cleanup [Alexander Pilz]
- Remove stale template. The original is under tiles/templates [Alexander Pilz]
- The workspace-container is not part of any breadcrumbs any more [Alexander Pilz]
- adapt logo viewlet according to new proto [Alexander Pilz]
- overwrite the LogoViewlet class, so that we can add more logic to finding the URL to display [Alexander Pilz]
- customize GlobalSectionsViewlet, so that we can add the site title to the sections bar [Alexander Pilz]
- 1) make use of chameleon syntax 2) adapt classes and data-pat attributes to fit proto [Alexander Pilz]
- check out quaive.resources.ploneintranet as source, in branch updated-proto [Alexander Pilz]
- Release 1.2.7 (#590) [Alexander Pilz]
- Back to development: 1.2.0a8 [Guido A.J. Stevens]
- Added the capability to add links [Alessandro Pisa]
- Merge pull request #517 from quaive/testing_docs [GitHub]
- Update testing docs [ci skip] <- note the irony :-) [Guido A.J. Stevens]
- Merge pull request #499 from quaive/create_structure_hesienb_gaia [GitHub]
- Attempt to fix robot heisenbug [Wolfgang Thomas]
- Merge pull request #496 from quaive/447_gitflow [GitHub]
- Merge pull request #493 from quaive/448_test_docsplit [GitHub]
- Document git workflow fixes #447 [Guido A.J. Stevens]
- Provide 'make test-docsplit' to quickly verify OS dependencies, fixes #448 [Guido A.J. Stevens]
- ignore slc.mailrouter src [Guido A.J. Stevens]
- Merge pull request #437 from quaive/plone-505-gaia [GitHub]
- Merge pull request #467 from quaive/buxfix-update-bundle [GitHub]
- update bundle [Alexander Pilz]
- Don't hide which bundle we actionally download [Alexander Pilz]
- userprofile tests: do not check for IStreamIterator. [Maurits van Rees]
- Use Plone 5.0.5 and fix one problem with it. [Maurits van Rees]


1.2.0a7 (2016-08-19)
--------------------

- Preparing release 1.2.0a7 [Guido A.J. Stevens]
- Update changelog [Guido A.J. Stevens]
- Merge branch 'master' into release-1.2.x [Guido A.J. Stevens]
- Bundle resource messy tryfix (#588) [Alexander Pilz]
- Back to development: 1.2.0a7 [Guido A.J. Stevens]


1.2.0a6 (2016-08-19)
--------------------

This should not be released yet. It needs to wait for the new JS API.

- Preparing release 1.2.0a6 [Guido A.J. Stevens]
- Update changelog [Guido A.J. Stevens]
- Revert "Update markup for changed pat-delay API [ci skip] (#575)" [Guido A.J. Stevens]
- Back to development: 1.2.0a6 [Alexander Pilz]


1.2.0a5 (2016-08-19)
--------------------

- Preparing release 1.2.0a5 [Alexander Pilz]
- Merge branch 'master' into release-1.2.x [Alexander Pilz]
- Update changelog [Alexander Pilz]
- Update markup for changed pat-delay API [ci skip] (#575) [Alexander Pilz]
- Since also the taxonomy app view is now called on the apps folder, its (#579) [Alexander Pilz]
- Bookmark-App translations in German (#585) [Alexander Pilz]
- Optimize redundant operation (#582) [Alexander Pilz]
- Merge pull request #580 from quaive/revert-575-messaging_autoload_patterns_api_change [GitHub]
- Revert "Update markup for changed pat-delay API" [GitHub]
- Update markup for changed pat-delay API [ci skip] (#575) [Alexander Pilz]
- Since also the taxonomy app view is now called on the apps folder, its (#579) [Alexander Pilz]
- Back to development: 1.2.0a5 [Alexander Pilz]

1.2.0a4 (2016-08-18)
--------------------

- Preparing release 1.2.0a4 [Alexander Pilz]
- Merge pull request #576 from quaive/more_verbose_ldap_sync_logging [GitHub]
- Add an extra ldap sync log msg to verify that user discovery is working properly [Guido A.J. Stevens]
- Merge pull request #574 from quaive/fix-recent-contacts [GitHub]
- fix tests [Wolfgang Thomas]
- Merge pull request #572 from quaive/419-properly-get-todos [GitHub]
- Use "safeWrite" when updating the user profile with recent contacts. Fixes #557 [Wolfgang Thomas]
- Move "recent_contacts" into default schema, so that also sites that do not use IUserProfileAdditional can use the "recent contacts" feature. Fixes #571 [Wolfgang Thomas]
- Merge pull request #528 from quaive/prevent-pickling-error [GitHub]
- Continues #419. Executing `` _updated_todos_state`` as manager is not enough. We also need to use unrestrictedSearchResults when searching for Todos to update [Wolfgang Thomas]
- Avoid ramcaching ZODB BTrees accessors [Guido A.J. Stevens]
- Merge pull request #570 from quaive/494-no-reindex [GitHub]
- Messaging refresh (#569) [Alexander Pilz]
- Don't fail if solr-maintenance view is not available. This affects mainly our test-setup [Wolfgang Thomas]
- update monkey_mklog, so that it does not choke on extra args [Wolfgang Thomas]
- When creating a workspace from a template, do not reindex duringthe copying but only once everywhing is in place [Wolfgang Thomas]
- make it possible to pass a no_log parameter to the solr-maintenance reindex method, so that the output of RESPONSE does not ge hijacked [Wolfgang Thomas]
- Userprofile fixes (#568) [Alexander Pilz]
- Make it possible to temporarily disable solr indexing (#567) [Alexander Pilz]
- For the contatcs portlet, compute the initials in python code. That (#566) [Alexander Pilz]
- Commit every 100 synced users (#561) [Alexander Pilz]
- Bookmarks timestamped (#558) [Alexander Pilz]
- When a workspace gets created from a template, do not create (#564) [Alexander Pilz]
- Merge pull request #554 from quaive/553-fix-case-manager-template [GitHub]
- Remove filtering by department [Alessandro Pisa]
- All Apps run in an Apps container (#552) [Alexander Pilz]
- Merge pull request #549 from quaive/bookmarks-portlet [GitHub]
- Merge pull request #544 from quaive/dashboard-recent-contacts [GitHub]
- Added a bookmark tile [Alessandro Pisa]
- Test fixes [Manuel Reinhardt]
- Merge pull request #550 from quaive/fix-heisenbug [GitHub]
- Try to prevent a select2 heisenbug [Alessandro Pisa]
- Fix missing app_name [Alessandro Pisa]
- Merge pull request #548 from quaive/294_messaging [GitHub]
- Merge pull request #547 from quaive/fix-diazo-off [GitHub]
- Merge pull request #546 from quaive/update-qudit-log [GitHub]
- Mark ploneintranet.messaging views as IAppView [Guido A.J. Stevens]
- Add minimal documentation for messaging [Guido A.J. Stevens]
- Pull in required Diazo transforms for messaging to work [Guido A.J. Stevens]
- Add robot test coverage for ploneintranet.messaging [Guido A.J. Stevens]
- Hook up global messaging viewlet with counter and link [Guido A.J. Stevens]
- Temporary CSS support for UX fixes as discussed with Cornelis [Guido A.J. Stevens]
- Remove spurious markup, will be handled by #543 and #537 [Guido A.J. Stevens]
- UX improvements as discussed with Cornelis [Guido A.J. Stevens]
- Activate messages tile with unread counter [Guido A.J. Stevens]
- Implement new chat, and autocreation of data marked as safeWrite [Guido A.J. Stevens]
- Implement new-message view and bring backend inline with byline injection [Guido A.J. Stevens]
- Provide inbox searching and sorting [Guido A.J. Stevens]
- Fix timezone handling in view [Guido A.J. Stevens]
- Lock down messaging security [Guido A.J. Stevens]
- Implement performant accessor to enable conversation byline UI [Guido A.J. Stevens]
- Disambiguate variable names [Guido A.J. Stevens]
- Just say NO to naive datetimes [Guido A.J. Stevens]
- Hook up chat view to live data [Guido A.J. Stevens]
- Provide messaging test data [Guido A.J. Stevens]
- Provide ploneintranet.api.messaging API for ploneintranet.messaging [Guido A.J. Stevens]
- Prepare logo link but don't implement to avoid conflict with ongoing proto work [Guido A.J. Stevens]
- Implement sidebar and main panel with mocked data [Guido A.J. Stevens]
- Hook up intro help [Guido A.J. Stevens]
- Remove unused nav [Guido A.J. Stevens]
- Hook up main messaging view [Guido A.J. Stevens]
- Template hookup WIP [Guido A.J. Stevens]
- Simplify [Guido A.J. Stevens]
- Hook up proto templates into messaging views [Guido A.J. Stevens]
- Remove old browser implementation [Guido A.J. Stevens]
- streamline tests [Guido A.J. Stevens]
- Merge pull request #543 from quaive/app_marker [GitHub]
- Disable diazo the proper way [Alessandro Pisa]
- Use the latest audit log [Alessandro Pisa]
- Combined contacts_search and contacts_results [Manuel Reinhardt]
- Improve consistency of app-marking docs and implementation [Guido A.J. Stevens]
- Merge pull request #541 from quaive/heisenfix [GitHub]
- Use a macro instead of injection to be more prototype conform [Manuel Reinhardt]
- Fix for empty recent contacts [Manuel Reinhardt]
- flake8 [Manuel Reinhardt]
- Let the Views for the 2 apps we have so far declare that they implement IAppView [Wolfgang Thomas]
- If the current View indicates that it is an app, set the necessary body classes. [Wolfgang Thomas]
- Merge pull request #545 from quaive/dexterity-membrane-112 [GitHub]
- dexterity.membrane = 1.1.2 [Maurits van Rees]
- Merge pull request #542 from quaive/update-dutch-translations [GitHub]
- Recent contacts feature for dashboard contacts portlet [Manuel Reinhardt]
- better check for completed "Save" injection [Wolfgang Thomas]
- Extend app protocol with IAppView [Guido A.J. Stevens]
- Merge pull request #540 from quaive/unbookmark_app [GitHub]
- Enable Github source checkouts on Gitlab-CI [Guido A.J. Stevens]
- Minor corrections in Dutch translations [Jean-Paul Ladage]
- Fixed more dutch translations [Jean-Paul Ladage]
- Ran synci18n against master and further updated the Dutch translations [Jean-Paul Ladage]
- make Bulk-action robot tests more robust [Wolfgang Thomas]
- Fix unbookmark-app notification [Guido A.J. Stevens]
- Merge pull request #536 from quaive/microblog-loggin-error [GitHub]
- Merge pull request #532 from quaive/extra-bulk-actions [GitHub]
- Fix up markup, i18n message. Removed duplicate question [Wolfgang Thomas]
- Fix error in log message [Wolfgang Thomas]
- Merge pull request #535 from quaive/update-dutch-translations [GitHub]
- Sync i18n files and update dutch translations [Jean-Paul Ladage]
- Fix bulk tagging vocabulary workaround, comment on infosec considerations. [Guido A.J. Stevens]
- Merge pull request #530 from quaive/load_resources [GitHub]
- Bulk retag: Call @@getVocabulary on the workspace [Cillian de Róiste]
- Bulk actions: escape & in data-pat-inject [Cillian de Róiste]
- Fix tag suggestion for bulk retagging [Cillian de Róiste]
- Bulk actions: rename & retag - add robot tests [Cillian de Róiste]
- Bulk actions: add rename and (re)tag [Cillian de Róiste]
- Cart actions: tidy up [Cillian de Róiste]
- Deprecate all resource compilation in Makefile [Guido A.J. Stevens]
- Move resources dependency from :default to :full [Guido A.J. Stevens]
- Load dependency fixes in quaive.resources.ploneintranet 1.2.0a3 [Guido A.J. Stevens]
- Checkout quaive.app.resources as devel egg when activating sources [Guido A.J. Stevens]
- Work around test leakage (induced by z3c.autoinclude?) [Guido A.J. Stevens]
- Merge pull request #531 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.0a4 [Alexander Pilz]
- Fix uninstaller and uninstall test [Guido A.J. Stevens]
- Loading ploneintranet.suite:default should *always* be sufficient to get a working install. [Guido A.J. Stevens]
- z3c.autoinclude skips [extras]: list required resources dependency in main [Guido A.J. Stevens]
- Prevents PicklingError: Can't pickle 'LOBTreeItems' [Alessandro Pisa]


1.2.0a3 (2016-07-30)
--------------------

- Merge pull request #525 from quaive/fix-displayed-types [GitHub]
- Merge pull request #524 from quaive/structure_noncritical [GitHub]
- Merge pull request #527 from quaive/todo-sorting [GitHub]
- Merge pull request #526 from quaive/depend-on-pac [GitHub]
- Mark Heisenbug #529 noncritical [Guido A.J. Stevens]
- Test todo sorting by due date and position [Cillian de Róiste]
- Sort Todos by due date first then position [Cillian de Róiste]
- Cannot tag a keyword [Guido A.J. Stevens]
- Fix the way we set the displayed types [Alessandro Pisa]
- Depend on p.a.contenttypes [Cillian de Róiste]
- Tag instead of disable some failing tests, document test ticket refs [Guido A.J. Stevens]
- Try to actually fix the bug: dont' rely on pat-notification, use injection marker instead refs #521 [Guido A.J. Stevens]
- Robot two spaces [Guido A.J. Stevens]
- mark Create structure noncritical refs #521 [Guido A.J. Stevens]
- Document ticket ids on disabled tests src/ploneintranet/suite/tests/acceptance/userprofile.robot [Guido A.J. Stevens]
- Merge pull request #519 from quaive/mail-content-type [GitHub]
- Initial work for a mail content type [Alessandro Pisa]
- Merge pull request #511 from quaive/events_disable [GitHub]
- Merge pull request #518 from quaive/testing_docs_master [GitHub]
- Update testing docs [ci skip] <- note the irony :-) [Guido A.J. Stevens]
- Merge pull request #514 from quaive/document-quaive-resources-ploneintranet [GitHub]
- Merge pull request #510 from quaive/workspace_generalize [GitHub]
- Document how to update the theme [Alessandro Pisa]
- Fix sources.cfg [Alessandro Pisa]
- Merge pull request #512 from quaive/fix-bookmarks-app [GitHub]
- Make preview disabling actually work (without commas, tuple degraded to string...) [Guido A.J. Stevens]
- Oops forgot to remove moved test [Guido A.J. Stevens]
- In the absence of a proper request, don't break but silently do nothing. We need this to test quaive.transmogrifier sections without proper request. [Guido A.J. Stevens]
- Move microblog disabler one level up, and provide secondary API route via ploneintranet.api.events [Guido A.J. Stevens]
- Provide ploneintranet.api accessors to disable/enable previews and microblog auto-creation. [Guido A.J. Stevens]
- Provide a way to temporarily disable preview generation [Guido A.J. Stevens]
- Provide a way to temporarily disable content update creation. [Guido A.J. Stevens]
- Use latest resources [Alessandro Pisa]
- Document that creating userprofiles in Barceloneta does not actually work. [Alessandro Pisa]
- Show only fallback workspace add for types that have no template at all [Alessandro Pisa]
- Support adding extra workspace types without templates [Alessandro Pisa]
- Fix bookmarks overview [Alessandro Pisa]
- Merge pull request #504 from quaive/cart-paste-injection [GitHub]
- Merge pull request #509 from quaive/508_optimize_searchabletext [GitHub]
- Merge pull request #495 from quaive/kill-pi-theme [GitHub]
- Merge pull request #507 from quaive/disable_dollie_test [GitHub]
- Optimize async reindex only within thread, not across threads. This avoids subtle race conditions, at the cost of 1 extra reindex. This results in reducing the number of reindexes per upload from 4 to 2 instead of 1. [Guido A.J. Stevens]
- Try to optimize SearchableText reindexing [Guido A.J. Stevens]
- Completely disable test that keeps breaking on 'css=.tooltip-container .menu' [Guido A.J. Stevens]
- Work around recurring robot Heisenbug on "Dollie can change her password" [Guido A.J. Stevens]
- Completely disable test that keeps breaking on 'css=.tooltip-container .menu' [Guido A.J. Stevens]
- Updated resources package [Alessandro Pisa]
- Fix wrong copy paste [Alessandro Pisa]
- pin quaive.app.audit [Alessandro Pisa]
- pin quaive.app.taxonomy [Alessandro Pisa]
- Use quaive eggs for jenkins [Alessandro Pisa]
- Use our quaive pypi [Alessandro Pisa]
- Some tests need to load quaive.app.resources zcml [Alessandro Pisa]
- Removed the static folder in theme [Alessandro Pisa]
- Buildout: add theme package and remove fetchrelease [Alessandro Pisa]
- Merge pull request #503 from quaive/actions-in-login-colophon [GitHub]
- Work around recurring robot Heisenbug on "Dollie can change her password" [Guido A.J. Stevens]
- Merge pull request #506 from quaive/async_onedit [GitHub]
- Merge pull request #476 from quaive/make-diazo [GitHub]
- Merge pull request #502 from quaive/489_async_retry [GitHub]
- Merge pull request #501 from quaive/fix-jenkins-bootstrap-script [GitHub]
- Login form is portal_actions/login_colophon aware [Alessandro Pisa]
- Fix bulkactions the way intended in proto [Alexander Pilz]
- fix robot heisenbug (a weird scrolling issue), that only appears in robot tests, so we fix it by sticking to the facts we know about this robot test scenario [Wolfgang Thomas]
- Merge pull request #477 from quaive/remove-division-index [GitHub]
- new bundle that fixes data-pat-inject in combination with formactions [Alexander Pilz]
- Merge branch 'master' into make-diazo [Alexander Pilz]
- fix markup to work with patternslib inject fix in https://github.com/Patternslib/Patterns/pull/448 [Alexander Pilz]
- Switch on-edit preview generation to async mode, just like on-create [Guido A.J. Stevens]
- apply bootstrapping fix also on Makefile [Guido A.J. Stevens]
- Make async tasks more robust: - acks_late is safe to use because our tasks are idempotent, this protects against Celery worker crashes - retry tasks 3 times on genuine errors, excluding UnAuthorized [Guido A.J. Stevens]
- Force reinstall [Alessandro Pisa]
- Created an upgrade step to clean up the catalog [Alessandro Pisa]
- Remove division index and column from catalog [Alessandro Pisa]
- Merge pull request #500 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.0a3 [Alexander Pilz]
- proof of concept for cut, copy and paste. for the 2 actions that require a modal, there are 2 scenarios: - delete: attemps to open the modal. You can even briefly see it. Then a white overlay overs   everything. Probably because this modal is injected in #items in the sidebar - mail: the complete form is injected into #items in the sidebar. Works fine, but probably   not something that cornelis will approve of. Also, the "Cancel" case would need to be handled   separately, since we cannot simple close the modal In both cases (delete and mail), there is a hard reload of the page after a successful action [Wolfgang Thomas]
- Update theme with make diazo [Alessandro Pisa]
- Bulk: WIP Attempt to inject #items for Paste [Cillian de Róiste]
- Cleanup: remove obsolete cart_dispatch view [Cillian de Róiste]


1.2.0a2 (2016-07-24)
--------------------

- Merge pull request #498 from quaive/create_structure_heisenb [GitHub]
- Merge pull request #497 from quaive/447_gitflow_master [GitHub]
- Attempt to fix robot heisenbug [Wolfgang Thomas]
- Merge pull request #492 from quaive/buildout_sources [GitHub]
- Document git workflow fixes #447 [Guido A.J. Stevens]
- Merge pull request #491 from quaive/490-fix-no-current-theme [GitHub]
- Up dependencies for quaive.app.- [Guido A.J. Stevens]
- Factor out quaive.app.- into separate sources.cfg and quaive-eggs.cfg mixins. Also remove the membrane stuff that was auto-checked out still even after closing #415. [Guido A.J. Stevens]
- Fix the viewlet when no current theme is set up [Alessandro Pisa]
- Merge pull request #484 from quaive/ignore-resources [GitHub]
- Merge pull request #486 from quaive/heisenbug-dollie-cannot-change-guy [GitHub]
- Fixes heisenbug #485 [Wolfgang Thomas]
- Ignore src/quaive.resources [Alessandro Pisa]
- Merge pull request #474 from quaive/app-bookmarks [GitHub]
- Merge pull request #470 from quaive/reset-password [GitHub]
- Merge pull request #483 from quaive/filter-resource-as-manifest-dictates [GitHub]
- Improve static resource filtering [Alessandro Pisa]
- Merge pull request #482 from quaive/preview-mainteinance-views-2 [GitHub]
- Merge pull request #480 from quaive/indexer-robustness [GitHub]
- Merge pull request #481 from quaive/remove-unused-template [GitHub]
- Continues #449. Make it actually possible to pass a param that triggers certain behaviour in the code [Wolfgang Thomas]
- Merge pull request #479 from quaive/478-split-userprofile-view [GitHub]
- removed unused template [Alessandro Pisa]
- Add robot test for change password happy flow [Wolfgang Thomas]
- Add authenticator to change password form [Wolfgang Thomas]
- Login-form: We might as well also copy over the fields for login-name and password from the customised template, so that the placeholders can be translated [Wolfgang Thomas]
- In the upgrade step, don't reload the whole registry, just add the missing entry [Wolfgang Thomas]
- return True if resetting password is allowed [Wolfgang Thomas]
- since we're already customizing the login_form, we might also define the splash logo there instead of glueing it in via the diazo rules.xml. This is also a step for better customization, since we can then replace the hard-coded path to the logo with a lookup to some logo storage based on configuration [Wolfgang Thomas]
- Add test that proves thath the change-password form is disabled if the respective setting in the registry is false [Wolfgang Thomas]
- Also make sure the change-password form (for logged in users) can't be used if the option for resetting passwords is not enabled [Wolfgang Thomas]
- Only show the link for reseting password if this is globally enabled. Additionally, prevent those forms being used directly in that case. [Wolfgang Thomas]
- add utility browser view that can be used to prevent showing certain forms if resetting passwords by users is not allowed [Wolfgang Thomas]
- Add registry entry to globally allow or disallow self-resetting of passwords [Wolfgang Thomas]
- Also enable password reset for logged-in users [Wolfgang Thomas]
- Update robot tests: the pwreset_form can now be viewed. But unless a valid token was passed in, resetting the password will not work. [Wolfgang Thomas]
- Hook up remaining forms to that we can reset password [Wolfgang Thomas]
- adapt pwreset_form to make markup useful for quaive [Wolfgang Thomas]
- We now want to enable PW resetting. Copied over vanilla form for better diff [Wolfgang Thomas]
- Hook up mail password form and feedback [Wolfgang Thomas]
- adapt markup of mail_password_form to be useful for use in quaive [Wolfgang Thomas]
- simplify login_form to make it useful for quaive [Wolfgang Thomas]
- Copied over vanilla templates login_form and mail_password_form [Wolfgang Thomas]
- Make adding content solr more resilient against weird edge-cases [Wolfgang Thomas]
- Split the user profile view into multiple tabs [Alessandro Pisa]
- templating and diazo rule for bookmarks [Alessandro Pisa]
- Fix some workspace classes [Alessandro Pisa]
- The select for grouping the bookmarks is back [Alessandro Pisa]
- Merge pull request #475 from quaive/fix_friendly_type_name_indexer [GitHub]
- Merge pull request #472 from quaive/flower [GitHub]
- it can happen that no entry is found in the mimeytyes_registry for certain content types (like 'application/vnd.ms-outlook'). Don't fail in that case [Wolfgang Thomas]
- Make the dependency on pi.bookmark softer [Alessandro Pisa]
- Robot test coverage for bookmarks [Alessandro Pisa]
- Fix bookmark link options [Alessandro Pisa]
- Disabling filter selection on the bookmark app [Alessandro Pisa]
- Bookmark integration in Ploneintranet [Alessandro Pisa]
- Add config for flower celery monitoring [Alexander Pilz]
- Added the package ploneintranet.bookmarks [Alessandro Pisa]
- Added a marker interface for bookmark tiles [Alessandro Pisa]
- pi.workspace depends on Products.membrane: make this explicit [Alessandro Pisa]
- Updated gitignore [Alessandro Pisa]
- Bookmark integration for ploneintranet.network [Alessandro Pisa]
- Merge pull request #469 from quaive/release-1.2.x [GitHub]
- Back to development: 1.2.0a2 [Alexander Pilz]


1.2.0a1 (2016-07-17)
--------------------

- Mars release cycle

1.1.0rc1 (2016-10-27)
---------------------

- Gaia branch release cycle updates

- Prepare Gaia RC1 [Guido A.J. Stevens]
- Include tag fetching in release docs [ci skip] [Guido A.J. Stevens]
- Merge pull request #641 from quaive/gaia_hotfix [GitHub]
- Apply Products.PloneHotfix20160830==1.0 [Guido A.J. Stevens]
- Document adding a new behavior with a facet field (#591) [Alexander Pilz]
- Merge pull request #517 from quaive/testing_docs [GitHub]
- Update testing docs [ci skip] <- note the irony :-) [Guido A.J. Stevens]
- Merge pull request #499 from quaive/create_structure_hesienb_gaia [GitHub]
- Attempt to fix robot heisenbug [Wolfgang Thomas]
- Merge pull request #496 from quaive/447_gitflow [GitHub]
- Merge pull request #493 from quaive/448_test_docsplit [GitHub]
- Document git workflow fixes #447 [Guido A.J. Stevens]
- Provide 'make test-docsplit' to quickly verify OS dependencies, fixes #448 [Guido A.J. Stevens]
- ignore slc.mailrouter src [Guido A.J. Stevens]
- Merge pull request #437 from quaive/plone-505-gaia [GitHub]
- Merge pull request #467 from quaive/buxfix-update-bundle [GitHub]
- update bundle [Alexander Pilz]
- Don't hide which bundle we actionally download [Alexander Pilz]
- Merge pull request #446 from quaive/prevent-owner-inheritance-via-folders [GitHub]
- Merge pull request #463 from quaive/fred_nl_translations [GitHub]
- userprofile tests: do not check for IStreamIterator. [Maurits van Rees]
- Of course, on a folder outside of a workspace, the local role "Owner" is not taken away [Wolfgang Thomas]
- Make sure we only remove the Owner local role on a folder in the context of a Workspace [Wolfgang Thomas]
- sort imports [Wolfgang Thomas]
- Merge pull request #451 from quaive/bulk-action-without-cart-2 [GitHub]
- Merge pull request #459 from quaive/backport-remove-docstrings-from-NetworkGraph [GitHub]
- Remove docstring from NetworkGraph [Alessandro Pisa]
- Bulk actions: fake the modal markup [Wolfgang Thomas]
- Wait for injection to finish for bulk modals [Wolfgang Thomas]
- Since a new div with class pat-modal got introduced in 10465cb, the selectors in the modal for changing membership roles need to become more specific [Wolfgang Thomas]
- Bulk actions: don't use cart [Wolfgang Thomas]
- simplyfy test class inheritance [Wolfgang Thomas]
- Every Contributor shall be able to edit a folder (e.g. to change the title) [Wolfgang Thomas]
- Fix test: no more Owner role on folder [Wolfgang Thomas]
- revoke owner role on folder [Wolfgang Thomas]
- Add test to make sure that the Owner role on a folder is not passed on via inheritance to contained content. Found while evaluating #431 [Wolfgang Thomas]
- Dutch translations. [Fred van Dijk]
- Use Plone 5.0.5 and fix one problem with it. [Maurits van Rees]
- Merged translations from Coen. [Maurits van Rees]
- Add terminology (woordenlijst) Dutch [Fred van Dijk]
- Merge pull request #428 from quaive/403-user-group-handling [GitHub]
- Merge pull request #430 from quaive/update_diazo_gaia [GitHub]
- Merge pull request #432 from quaive/filter-bulk-actions-by-context [GitHub]
- Merge pull request #427 from quaive/update_ldap [GitHub]
- Merge pull request #424 from quaive/upgrade-dcworkflow [GitHub]
- Bulk actions: call mail-confirm on the context [Cillian de Róiste]
- update diazo to include latest style fixes and the document browser templates [Guido A.J. Stevens]
- Work around buildout issue by loading ldap-eggs.cfg directly [Guido A.J. Stevens]
- Document LDIF cleanup [Guido A.J. Stevens]
- Upgrade DCWorkflow, to ex/import managed groups [Cillian de Róiste]
- Cart: only process items in the current folder [Cillian de Róiste]
- Merge pull request #422 from quaive/release-1.1.x [GitHub]
- Back to development: 1.1.0b5 [Alexander Pilz]
- Use new Products.membrane and dexterity.membrane releases. [Maurits van Rees]
- Use dexterity.membrane master again. [Maurits van Rees]
- Reverted accidental IMembraneGroup interface change. [Maurits van Rees]
- Register MembraneWorkspaceGroupsProvider for groups as well. [Maurits van Rees]
- Write PAS call flow into docstring [Maurits van Rees]
- Use master branch of Products.membrane, since the branch with the PRs was merged & deleted [Maurits van Rees]
- Actually, we have a separate jenkins.cfg with our own auto-checkout [Maurits van Rees]
- switch to HTTPS checkout of git packages, since jenkins does not like SSH [Maurits van Rees]
- Handle enumeration of users and of the groups of a user better. [Maurits van Rees]


1.1.0b4 (2016-07-06)
--------------------

- Merge pull request #418 from quaive/avoid-getObject [GitHub]
- Fix docstring, jenkins hold [Alexander Pilz]
- Merge pull request #419 from quaive/13803-execute-todochange-as-manager [GitHub]
- Fallback if we have empty Uids (in tests) [Alexander Pilz]
- new-selenium-version [Alexander Pilz]
- Add test for group lookup in get_users [Alexander Pilz]
- bugfix in test (typo in exact_getUserName) [Alexander Pilz]
- in ``get_users`` we now also resolve group members, refs #383 [Alexander Pilz]
- Merge pull request #420 from quaive/upgrade-selenium [GitHub]
- new-selenium-version [Alexander Pilz]
- Added more documentation [Alexander Pilz]
- execute the whole process as manager, already the getObject may be forbidden [Alexander Pilz]
- Avoid getObject if all we need is already in the brains. [Alexander Pilz]
- Merge pull request #417 from quaive/383-resolve-group-members [GitHub]
- Add test for group lookup in get_users [Wolfgang Thomas]
- bugfix in test (typo in exact_getUserName) [Wolfgang Thomas]
- in ``get_users`` we now also resolve group members, refs #383 [Wolfgang Thomas]
- Merge pull request #414 from quaive/389_content_updates_edges [GitHub]
- Adjust test to sentinel suppression [Guido A.J. Stevens]
- Present content stream reply input only if user has permission to comment [Guido A.J. Stevens]
- Show sentinel only when there are comments [Guido A.J. Stevens]
- Suppress "created" post for "published" content unless there was a conversation on the "created". [Guido A.J. Stevens]
- Fix content action display [Guido A.J. Stevens]
- Merge pull request #412 from quaive/large-profile-image [GitHub]
- Merge pull request #413 from quaive/fix-solr-maintenance [GitHub]
- Merge pull request #406 from quaive/release-1.1.x [GitHub]
- Merge pull request #410 from quaive/bugfix-description [GitHub]
- Tidy up: remove unused imports [Cillian de Róiste]
- Don't commit the transaction when changing a portrait [Cillian de Róiste]
- Userprofile tests: Explicitly delete profiles [Cillian de Róiste]
- Fix the sync BrowserView of solr maintenance If there are more items to process than the batch size, then flush is called. In the current implmenentation this leads to TypeError: commit() got an unexpected keyword argument 'soft' [Wolfgang Thomas]
- Coerce large avatar Pdata image objects to strings [Cillian de Róiste]
- not every brain has a description, e.g. people [Alexander Pilz]
- Merge pull request #408 from quaive/update-c-workspace [GitHub]
- Merge pull request #407 from quaive/translations_userprofile_documents [GitHub]
- update collective.workspace. Fixes #381 [Wolfgang Thomas]
- Correctly translate the placeholder text for the user-profile search [Wolfgang Thomas]
- added translations for the documents section in user profile implemented in #13026 [Angela Steinhardt]
- Back to development: 1.1.0b4 [Alexander Pilz]


1.1.0b3 (2016-06-29)
--------------------

- Merge pull request #405 from quaive/more-robust-solr [GitHub]
- Fix accessing title and description [Alexander Pilz]
- Merge pull request #404 from quaive/fix-date-sorting [GitHub]
- Support Subject. Why would we not have it in solr? [Alexander Pilz]
- Simple measures to make solr responses behave more like catalog responses [Alexander Pilz]
- We should use the values if we pass them :/ [Alexander Pilz]
- Merge pull request #402 from quaive/fix-user-enumeration [GitHub]
- Fix user enumeration [Alessandro Pisa]
- Merge pull request #401 from quaive/c2q_20160624 [GitHub]
- Merge branch 'master' into c2q_20160624 Using -X theirs strategy option to prefer master over local changes. [Guido A.J. Stevens]
- Merge pull request #359 from quaive/284-folder_in_workspace_workflow [GitHub]
- Dedicated workflow for Folders in workspaces [Alessandro Pisa]
- Merge pull request #400 from quaive/news-tile-sorting [GitHub]
- Merge pull request #399 from quaive/force_microblog_sync [GitHub]
- Merge pull request #398 from quaive/390-fix-ampersands [GitHub]
- Merge pull request #392 from quaive/user-documents-improvements [GitHub]
- Merge pull request #395 from quaive/code-clean-up [GitHub]
- Merge pull request #397 from quaive/release-1.1.x [GitHub]
- Dashboard new tile: Show unpublished items [Cillian de Róiste]
- Disable microblog async, forces microblog into sync mode always. The python thread model used in async has issues with plone.protect and with ZODB connection binding. [Guido A.J. Stevens]
- Merge pull request #391 from quaive/update-bundle [GitHub]
- Fix ampersands [Alessandro Pisa]
- Back to development: 1.1.0b3 [Alexander Pilz]
- Update changelog and prepare release 1.0.1 [Guido A.J. Stevens]
- Backport Gaia manifest to Venus [Guido A.J. Stevens]
- Update docs version to upcoming 1.0.1 point release [Guido A.J. Stevens]
- Merge branch 'community-master' into release-1.0.x [Guido A.J. Stevens]
- Update documentation in preparation for new community release. [Guido A.J. Stevens]
- Revert "update docs on board mailinglist" [Guido A.J. Stevens]
- Clean up [Alessandro Pisa]
- Filter empty users and suggest to use pi_api [Alessandro Pisa]
- made a new bundle release [Wolfgang Thomas]
- Strip empty letter and have dynamic icons [Alessandro Pisa]
- update version [Alexander Pilz]
- update docs on board mailinglist [Alexander Pilz]
-  add hotfix Products.PloneHotfix20160419==1.0 [Claudio Kirchhoff]


1.1.0b2 (2016-06-22)
--------------------

- Merge pull request #393 from quaive/remove-unnecessary-line [GitHub]
- Merge pull request #396 from quaive/379_microblog_keyerror [GitHub]
- Merge pull request #373 from quaive/update-collective-workspace [GitHub]
- cases need to grant permissions to guests [Alexander Pilz]
- Cannot reproduce, but should fix #379 [Guido A.J. Stevens]
- Deactivate robot test "Manager can create a workspace". The case that a user created outside our local membrane context should be able to create a workspace is not supported. [Wolfgang Thomas]
- Merge pull request #387 from quaive/fix-injection-parameter [GitHub]
- Merge pull request #386 from quaive/latest-make-diazo [GitHub]
- use latest release of collective.workspace [Wolfgang Thomas]
- add a fix to reinitialise the security manager when acl_users is cached [Alexander Pilz]
- Remove unnecessary line [Alessandro Pisa]
- WIP: Remove stuff to see if backporting to collective.workspace works [Alessandro Pisa]
- Invalidate cache when adding or removing ws users [Alessandro Pisa]
- try https checkout, maybe gitlab likes that better [Alessandro Pisa]
- check put collective.workspace (temporarily) to get the lastest version Refs #370 [Alessandro Pisa]
- Merge pull request #385 from quaive/user-docs-1-column [GitHub]
- Fix autoload url [Alessandro Pisa]
- Fix injection parameter [Alessandro Pisa]
- Latest make diazo [Alessandro Pisa]
- Change to 1 column layout [Alessandro Pisa]
- Merge pull request #376 from quaive/375-fix-injection [GitHub]
- Merge pull request #378 from quaive/guido_avatar [GitHub]
- Add Guido testuser for easy demo preparation [Guido A.J. Stevens]
- Merge pull request #377 from quaive/upgrade-selenium [GitHub]
- Upgrade selenium to the latest release [Alessandro Pisa]
- Merge pull request #374 from quaive/release-1.1.x [GitHub]
- Dropdown for the user profile documents tab [Alessandro Pisa]
- Back to development: 1.1.0b2 [Guido A.J. Stevens]


1.1.0b1 (2016-06-20)
--------------------

Initial beta release of *Gaia*.
~8000 commits, 1085 tests, 85% test coverage.

- Merge pull request #372 from quaive/fix_mobile_back [GitHub]
- Fix mobile parent button refs https://github.com/quaive/ploneintranet.prototype/issues/240 [Guido A.J. Stevens]
- Merge pull request #371 from quaive/update-po-files [GitHub]
- Sync translation files with code [Fred van Dijk]
- Merge pull request #364 from quaive/simplify-getting-workflow-in-mm [GitHub]
- Merge pull request #366 from quaive/not-needed-noqa-step-2 [GitHub]
- Merge pull request #367 from quaive/362_microblog_timezone [GitHub]
- Remove not needed #noqas [Alessandro Pisa]
- Enter beta release cycle for Gaia [Guido A.J. Stevens]
- Simplify the way we get the current workflow [Alessandro Pisa]
- Merge pull request #365 from quaive/not-needed-noqa [GitHub]
- Remove any naive datetime handling from testcontent stream and microblog api fixes #362 [Guido A.J. Stevens]
- Merge pull request #357 from quaive/354-fix-microblog-upgrade-steps [GitHub]
- Merge pull request #360 from quaive/326-user-profile-search-logic [GitHub]
- Merge pull request #363 from quaive/135-check-permission-on-task [GitHub]
- Remove not needed #noqa [Alessandro Pisa]
- Merge pull request #361 from quaive/1-pdf-preview-in-stream [GitHub]
- Disable task checkbox if user can not modify [Alessandro Pisa]
- Merge pull request #356 from quaive/fix-changelog [GitHub]
- Only show the first preview image in the activity stream [Cillian de Róiste]
- Return all documents in user profile search [Alessandro Pisa]
- Call function only when context is not None [Alessandro Pisa]
- Backport the upgrade step ondelete_archive [Alessandro Pisa]
- Fix authors in changelog [Alessandro Pisa]
- Merge pull request #353 from quaive/release-1.1.x [GitHub]
- Revert "Merge pull request #352 from quaive/284-folder_in_workspace_workflow" [Guido A.J. Stevens]
- Merge pull request #352 from quaive/284-folder_in_workspace_workflow [GitHub]
- Merge pull request #344 from quaive/tiles-are-smarter [GitHub]
- Back to development: 1.1.0a7 [Guido A.J. Stevens]
- Dedicated workflow for Folders in workspaces [ale-rt]
- Make the app tiles smarter [ale-rt]


1.1.0a6 (2016-06-15)
--------------------

- typo [Alexander Pilz]
- Merge pull request #350 from quaive/update_proto [Alexander Pilz]
- Merge pull request #349 from quaive/filter-types-in-user-profile [Alexander Pilz]
- Merge pull request #351 from quaive/347_microblog_ondelete [Alexander Pilz]
- Make double content+thread deletion loops play nice with eachother [Guido A.J. Stevens]
- Archive older statusupdates with stale uuid references [Guido A.J. Stevens]
- Archive statusupdates when their content_context or microblog_context is removed. [Guido A.J. Stevens]
- Update to latest proto [Alessandro Pisa]
- Omit from the search the document types we are not interested into [Alessandro Pisa]
- Keep an archive of deleted statusupdates [Guido A.J. Stevens]
- Merge pull request #346 from quaive/fix-microblog-upgrade-to-0009 [Alexander Pilz]
- Merge pull request #338 from quaive/326-search-user-contents-in-profile-group-by-date [Alexander Pilz]
- Merge pull request #345 from quaive/dashboard-selection-persist-on-the-user [Alexander Pilz]
- Fix microblog upgrade to 0009 [Alessandro Pisa]
- Persist the dashboard selection on the user [Alessandro Pisa]
- Merge pull request #336 from quaive/109_tag_streams [Alexander Pilz]
- Implement grouping by date [Alessandro Pisa]
- Merge pull request #343 from quaive/335_take2 [Alexander Pilz]
- Revert "Merge pull request #341 from quaive/dashboard-selection-recordable" [Guido A.J. Stevens]
- Merge pull request #339 from quaive/326-user-contents-in-profile-fix-unicode [Alexander Pilz]
- Merge pull request #341 from quaive/dashboard-selection-recordable [Alexander Pilz]
- Work around Selenium cache issue by reloading page between status postings. [Guido A.J. Stevens]
- Reimplement #335 on top of #342. Minimize changes, maximize reuse. [Guido A.J. Stevens]
- Rip metal indirection out of search templates. Better copy a bit of boilerplate than maintain a metal:mess. [Guido A.J. Stevens]
- Add history: record for dashboard selection [Alessandro Pisa]
- Fix an issue when the first letter is a unicode string [Alessandro Pisa]
- search in the context of the user [Alessandro Pisa]
- Merge pull request #331 from quaive/326-user-contents-in-profile [Alexander Pilz]
- Avoid ZODB conflicts in solr test layer setup [Guido A.J. Stevens]
- Fix subtle longkeysortreverse bug. Deriving tmax from tmin ignored maxv if maxv < one hour ago. [Guido A.J. Stevens]
- Slightly change longkeysortreverse test fixture [Guido A.J. Stevens]
- Streamline and generalize microblog query API for future extensibility [Guido A.J. Stevens]
- Add missing variables to stream.robot [Guido A.J. Stevens]
- Remove test coverage on deprecated private method [Guido A.J. Stevens]
- Let "my network" stream show the union of all followings. [Guido A.J. Stevens]
- Completely revamp the microblog tag query API [Guido A.J. Stevens]
- Reorganize stream tests and move all keywords to lib [Guido A.J. Stevens]
- Remove outdated tag related code and markup [Guido A.J. Stevens]
- Fix silly typo [Guido A.J. Stevens]
- Add mentions and tags to testcontent stream, and run microblog async during setup. [Guido A.J. Stevens]
- Use more elegant network API in following tags [Guido A.J. Stevens]
- Simplify ploneintranet.network API by defaulting to current user where possible [Guido A.J. Stevens]
- Verify ajax optimization and fix title attribute [Guido A.J. Stevens]
- Follow/unfollow tags [Guido A.J. Stevens]
- Robustify robot test (avoid double growl) [Guido A.J. Stevens]
- Auto-tag content updates on publication [Guido A.J. Stevens]
- Make instance2 available for debug in devrun [Guido A.J. Stevens]
- Adjust utils tests to new location and split per package [Guido A.J. Stevens]
- Add tagstream robot coverage and adjust tag keywords for changed markup [Guido A.J. Stevens]
- Implement tag stream view (CCC#24) refs #109 [Guido A.J. Stevens]
- Merge pull request #333 from quaive/missing-pat-date-picker-i18n [Alexander Pilz]
- Merge pull request #334 from quaive/notify-on-role-change [Alexander Pilz]
- If guest roles are granted or removed, throw the WorkspaceRosterChangedEvent [Wolfgang Thomas]
- Add missing pat-date-dicker i18n [Alessandro Pisa]
- Remove sorting for the time being [Alessandro Pisa]
- Merge pull request #327 from quaive/release_gaia_testing [Alessandro Pisa]
- Merge pull request #330 from quaive/fix-wrong-description [Wolfgang Thomas]
- Merge pull request #324 from quaive/persist-workspaces-sorting [Wolfgang Thomas]
- Add user contents in profile [Alessandro Pisa]
- Merge pull request #329 from quaive/translations_for_ws_states [Wolfgang Thomas]
- Fix broken description [Alessandro Pisa]
- Merge pull request #328 from quaive/310_fix_bundlename [Alessandro Pisa]
- Merge pull request #325 from quaive/release-1.1.x [Wolfgang Thomas]
- More build status badges [ci skip] [Guido A.J. Stevens]
- added translations for general workspace security settings [Angela Steinhardt]
- Add gaia/buildout.d/ copy to release docs [Guido A.J. Stevens]
- Add eggified release testing to release docs refs #310 [Guido A.J. Stevens]
- Persist workspace sorting options [Alessandro Pisa]
- Correction on #312 fixes #310 [Guido A.J. Stevens]
- Back to development: 1.1.0a6 [Alexander Pilz]


1.1.0a5 (2016-06-08)
--------------------

- Merge pull request #320 from quaive/318_longkeysortreverse [Alexander Pilz]
- Future statusupdates are an abomination. Especially since they only happened because of a double negative (- -) developer mistake. [Guido A.J. Stevens]
- Log warning when creating future statusupdate [Guido A.J. Stevens]
- Use optimized longkeysortreverse for typical stream autoexpand [Guido A.J. Stevens]
- Refactor longkeysortreverse fixes #318 refs #316 - Do not hide future statusupdates - Avoid off-by-one error on autochunk boundaries [Guido A.J. Stevens]
- Longkeysortreverse fixing WIP [Guido A.J. Stevens]
- Merge pull request #323 from quaive/i18n_label_changed_CM [Wolfgang Thomas]
- changed i18n label for archived cases to fit other implementations [Angela Steinhardt]
- Merge pull request #321 from quaive/dashboard-markup [Wolfgang Thomas]
- Tests updated to the new markup [Alessandro Pisa]
- Merge pull request #319 from quaive/facet-filters-configurable [Alexander Pilz]
- Fix the pat-depends data attribute to handle configurable facets [Alessandro Pisa]
- Added an upgrade step to reread the registry [Alessandro Pisa]
- Facets filters are now configurable [Alessandro Pisa]
- Make dashboard markup compliant with prototype [Alessandro Pisa]
- Merge pull request #322 from quaive/task-checkbox-permissions [Alessandro Pisa]
- Fix flaky selector in robot Since we have a new input field, use the input field's name rather than counting... [Wolfgang Thomas]
- Merge pull request #303 from quaive/testcontent_contentstream [Wolfgang Thomas]
- Following #288 we have the situation that tasks can appear in the sidebar as checked, but disabled, i.e. status "done" without the user having the permission to edit them. A disabled checkbox, even if checked, is not present in the request. This messes up the handler for the checkboxes in the sidebar. Therefore, we need to track via "hidden" input fields which tasks are really checked and also which tasks have just been unchecked. [Wolfgang Thomas]
- Merge pull request #317 from quaive/frozen-date-i18n [Alessandro Pisa]
- Merge pull request #316 from quaive/microblog_migration_security [Alessandro Pisa]
- Use localized date for the Frozen overlay [Cillian de Róiste]
- Add comment to document accessor issue in migration [Guido A.J. Stevens]
- Other microblog migrations appear to be unaffected by accessor filters [Guido A.J. Stevens]
- Fix document discussion migration security [Guido A.J. Stevens]
- Merge pull request #315 from quaive/translations_frozen_case [Alessandro Pisa]
- Merge pull request #314 from quaive/release-1.1.x [Alessandro Pisa]
- added last translations for frozen cases [Angela Steinhardt]
- Back to development: 1.1.0a5 [Alexander Pilz]
- Avoid async issues by adding content updates on testcontent via migration handler [Guido A.J. Stevens]


1.1.0a4 (2016-06-06)
--------------------

- Merge pull request #311 from quaive/frozen-metromap [Alexander Pilz]
- Merge pull request #313 from quaive/fix-case-manager-batching [Alexander Pilz]
- Merge pull request #312 from quaive/rename-bundle [Alexander Pilz]
- Added missing i18n:translate [Alexander Pilz]
- Merge pull request #309 from quaive/i18n_supp_for_archive_and_frozen [Alexander Pilz]
- Use auto load instead of batching [Alessandro Pisa]
- Fix import error [Wolfgang Thomas]
- Merge pull request #307 from quaive/fix-attribute-error [Wolfgang Thomas]
- rename bundle name to ploneintranet-bundle, to remove naming conflict with ploneintranet see also discussion on #310 [Wolfgang Thomas]
- Code style fix [Cillian de Róiste]
- Add a robot test for unfreezing via the MetroMap [Cillian de Róiste]
- added i18n support to archive related templates added i18n support to cart_actions delete status messages added translations for archive, freeze and activity stream on documents [Angela Steinhardt]
- Merge pull request #306 from quaive/245_autload [Alessandro Pisa]
- Fixes AttributeError when brain.created is not a DateTime instance [Alessandro Pisa]
- Dashboard autoload injection requires id, fixes #245 [Guido A.J. Stevens]
- Merge pull request #305 from quaive/translation_prep_comments_on_documents [Alexander Pilz]
- added i18n statements for files used for commenting documents (activity stream) [Angela Steinhardt]
- Merge pull request #300 from quaive/293-fix-broken-injection [Wolfgang Thomas]
- Merge pull request #304 from quaive/fix-js-error-in-dashboard [Wolfgang Thomas]
- fix data-pat-tooltip parameters [Alessandro Pisa]
- pat-depends controls member batch functions [Alessandro Pisa]
- Merge pull request #302 from quaive/295_discussion_on_older [Alessandro Pisa]
- Merge pull request #301 from quaive/maurits-fallback-image-url [Guido Stevens]
- Create statusupdates on older content fixes #295 [Guido A.J. Stevens]
- Merge pull request #298 from quaive/release-1.1.x [Guido Stevens]
- Merge pull request #296 from quaive/280-fix-testing-content-creation [Guido Stevens]
- Add Unfreeze button to MetroMap [Cillian de Róiste]
- If there aren't any previews, call fallback_image_url with the object. [Maurits van Rees]
- Use assertIn a bit more. [Maurits van Rees]
- Merge pull request #299 from quaive/document_releasing [Wolfgang Thomas]
- Document egg releasing [Guido A.J. Stevens]
- Back to development: 1.1.0a4 [Guido A.J. Stevens]
- MetroMap: display pre-frozen state on MetroMap [Cillian de Róiste]
- Synchronous previews when creating testing content [Alessandro Pisa]


1.1.0a3 (2016-06-03)
--------------------

- Merge pull request #292 from quaive/date-picker-i18n [Wolfgang Thomas]
- Merge pull request #291 from quaive/custom-workspace-type-filtering [Alexander Pilz]
- Merge pull request #289 from quaive/285_cleanup_workspace_view [Alexander Pilz]
- Add i18n for date-picker [Cillian de Róiste]
- Registry: Unify workspace_types and workspace_type_filters [Cillian de Róiste]
- Make the workspace type filter configurable [Cillian de Róiste]
- Merge pull request #290 from quaive/translations_activitystream_post_corrected [Wolfgang Thomas]
- corrected i18n statements for comment.html and post.html added missing i18n:domain for comment.html to have it translated changed token for post buttons to button_post to avoid translation conflicts with Post in german added missing translation for action created to manual.pot added missing translations for all post actions to german .po file [Angela Steinhardt]
- Provide a generic way to customize workspace Barceloneta without css hacks fixes #285 [Guido A.J. Stevens]
- Merge pull request #287 from quaive/assignee-on-new-todo [Alessandro Pisa]
- Merge pull request #288 from quaive/todo-checkbox-permission [Alessandro Pisa]
- When displaying tasks in the sidebar of a case, only activate those checkboxes for tasks that the user has permission to edit [Wolfgang Thomas]
- Remove duplicate filterlist record [Guido A.J. Stevens]
- When a Todo is newly created, the fields are not populated yet but we still want to correctly set the assignee's role, if present. Therefore, additionally look at the request [Wolfgang Thomas]
- Merge pull request #286 from quaive/add_new_gitignore_item [Wolfgang Thomas]
- added .DS_Store to gitignore [Angela Steinhardt]
- Merge pull request #282 from quaive/281-solr-maintenance [Alessandro Pisa]
- Make solr-maintenance available on the whole site. Fixes #281 [Wolfgang Thomas]
- Merge pull request #278 from quaive/translate-guests [Wolfgang Thomas]
- Rebased on master [Alessandro Pisa]
- translate heading "Guests" [Alessandro Pisa]
- Merge pull request #279 from quaive/fix-event-until-time [Wolfgang Thomas]
- Merge pull request #277 from quaive/ldap_wo_slapd [Alexander Pilz]
- Merge pull request #276 from quaive/codeanalysis_update [Wolfgang Thomas]
- Merge pull request #275 from quaive/archive-workspace-i18n [Wolfgang Thomas]
- Fix the Event form 'until' time field [Cillian de Róiste]
- Merge pull request #274 from quaive/release-1.1.x [Wolfgang Thomas]
- Extract translations for "Archive workspace" [Cillian de Róiste]
- Add i18n:translate for "Archive workspace" [Cillian de Róiste]
- Manage ldap .gitignore locally for easy replication [Guido A.J. Stevens]
- Make it possible to load ldap eggs without adding slapd to supervisor [Guido A.J. Stevens]
- Auto-create required ldap schema via Makefile [Guido A.J. Stevens]
- Merge pull request #273 from quaive/i18nlabel_archived_changed [Alessandro Pisa]
- Put devel target on top [Guido A.J. Stevens]
- Back to development: 1.1.0a3 [Guido A.J. Stevens]
- Merge pull request #272 from quaive/translations_activity_stream_actions [Alessandro Pisa]
- renamed the i18n-token for archived checkbox to use its own translation (was translated incorrect because of same token as for wf state archived) [Angela Steinhardt]
- added translations for activity stream delete and edit functions [Angela Steinhardt]
- Modernize codeanalysis stanza and ensure pdb raises commit error [Guido A.J. Stevens]


1.1.0a2 (2016-05-31)
--------------------

- Include deployment example configs in egg distribution [Guido A.J. Stevens]
- Update changelog [Guido A.J. Stevens]
- Merge pull request #269 from quaive/translate-email-invitees [goibhniu]
- Merge pull request #267 from quaive/statusupdate-edit-delete-2 [Wolfgang Thomas]
- Merge pull request #262 from quaive/theme_update_20160527 [Wolfgang Thomas]
- Merge pull request #268 from quaive/fix-library-search [Wolfgang Thomas]
- Don't add a \n at the start of email_invitees - [Cillian de Róiste]
- Add translations for email_invitees templates [Cillian de Róiste]
- Fix i18n for the email_invitees templates [Cillian de Róiste]
- Do not limit search results we are looking for the section children [Alessandro Pisa]
- Grant statusupdate moderation rights to case admins also [Guido A.J. Stevens]
- Grant statusupdate moderation rights to teamadmins [Guido A.J. Stevens]
- Robot coverage on statusupdate reply edit/delete fixes #75 [Guido A.J. Stevens]
- Simplify reply editing and fixup permissions [Guido A.J. Stevens]
- Support edit/delete of statusupdate replies [Guido A.J. Stevens]
- Fix markup bug that caused injection and styling to fail [Guido A.J. Stevens]
- Narrow exception handler, thanks @ale-rt [Guido A.J. Stevens]
- Workspaces finally open on the home tab (sidebar closed). Adjust tests. [Guido A.J. Stevens]
- Merge pull request #266 from quaive/265_microblog_upgrade [Alexander Pilz]
- Merge pull request #263 from quaive/correction_for_i18ndude_run [Alexander Pilz]
- Backport _ctime to earlier migration [Guido A.J. Stevens]
- Merge pull request #264 from quaive/translations_workspace_add_form [Alessandro Pisa]
- Small CSS update [Guido A.J. Stevens]
- Fixes suggested by zptlint [Alessandro Pisa]
- added i18n statements to add workspace form and missing translations to .po file [Angela Steinhardt]
- added a / to a div-tag to correct the html-structure due to a i18ndude-run which caused an error. [Angela Steinhardt]
- Update theme to proto 71260aad950556e50c [Guido A.J. Stevens]
- Merge pull request #260 from quaive/statusupdate-edit-delete [Alessandro Pisa]
- Move last vestige of pat-moment over to pat-display-time [Guido A.J. Stevens]
- Add robot coverage on statusupdate edit/delete [Guido A.J. Stevens]
- Store and display edited date. Replace formatters that were bypassed anyway with direct attribute access. [Guido A.J. Stevens]
- By pythonic, use original_text as truthy [Guido A.J. Stevens]
- Implement statusupdate editing [Guido A.J. Stevens]
- Include permission setup in migration [Guido A.J. Stevens]
- Implement statusupdate deletion [Guido A.J. Stevens]
- Hook up post-menu.html [Guido A.J. Stevens]
- Bring #257 resolution in line with changes on statusupdate-edit-delete [Guido A.J. Stevens]
- Provide view delegation via traversal for statusupdates [Guido A.J. Stevens]
- Don't mask Unauthorized as AttributeError [Guido A.J. Stevens]
- Update migration for method name change in c29183c8 [Guido A.J. Stevens]
- Fix cache race condition that only manifested in first (unbuffered=slower) test run [Guido A.J. Stevens]
- Delegate delete permission check to the statusupdate [Guido A.J. Stevens]
- Use separate _dtime marker to avoid messing up async _mtime logic [Guido A.J. Stevens]
- Fix api test [Guido A.J. Stevens]
- Microblog thread deletion [Guido A.J. Stevens]
- Implement statusupdate deletion backend, thread deletion todo. [Guido A.J. Stevens]
- Implement security constraints on StatusUpdate editing [Guido A.J. Stevens]
- Basic statusupdate editing [Guido A.J. Stevens]
- Remove deprecated BBB accessors [Guido A.J. Stevens]
- Unmask and catch UUID lookup failure on template copy [Guido A.J. Stevens]
- Test adding a case from a template [Guido A.J. Stevens]
- Merge pull request #259 from quaive/do-not-use-execute-as-manager [Guido Stevens]
- Do not execute as manager [Alessandro Pisa]
- Merge pull request #258 from quaive/delete-confirmation-translation [Alessandro Pisa]
- Update translations for Delete confirmation [Cillian de Róiste]
- Delete confirmation: add translations [Cillian de Róiste]
- Merge pull request #256 from quaive/fix_discussion_migration [Alessandro Pisa]
- Fix document discussion upgrade by adding missing commit [Guido A.J. Stevens]
- Merge pull request #255 from quaive/guest-access [Wolfgang Thomas]
- Users with "Guest" status cannot be removed maually, therefore don't show the checkbox, follows #235 [Wolfgang Thomas]
- Merge pull request #252 from quaive/override-management-port [Guido Stevens]
- Merge pull request #253 from quaive/tidy-up-todo-view [Alessandro Pisa]
- Merge pull request #251 from quaive/improve-robustness [Alessandro Pisa]
- Wait for injection to complete [Guido A.J. Stevens]
- Tidy up the Todo view [Cillian de Róiste]
- Allow easy override for management port [Alessandro Pisa]
- Warn when we cannot change the locale [Alessandro Pisa]
- fix typo which got introduced accidentally in 72d57 [Wolfgang Thomas]
- Merge pull request #228 from quaive/document-discussions-3 [Wolfgang Thomas]
- Workaround for solr / tika indexing error #250 [Wolfgang Thomas]
- Don't choke on startup if the the user's environment variable LANG is set to a value that leads to Error: unsupported locale setting. In this case, try a sensible default or quit trying to set the locale completely [Wolfgang Thomas]
- Add missing content index on statuscontainer [Guido A.J. Stevens]
- don't choke if a flare does not contain 'modified' [Wolfgang Thomas]
- Merge pull request #244 from quaive/archived-checkbox-vs-request [Guido Stevens]
- Wait for injection to complete [Guido A.J. Stevens]
- Merge pull request #238 from quaive/224-case-freeze [Guido Stevens]
- Merge pull request #235 from quaive/task-assignee-team-guest [Guido Stevens]
- Merge pull request #246 from quaive/fix-SearchResult [Guido Stevens]
- Merge pull request #249 from quaive/translations_archive_and_userprofile [Wolfgang Thomas]
- dummy commit to nudge github [Wolfgang Thomas]
- Add robot coverage on archived workspace listing [Guido A.J. Stevens]
- Archived checkbox is aware of the request [Guido A.J. Stevens]
- Added translations for archive function and user profile page (split commit from @angeldasangel into 2 separate ones) [Wolfgang Thomas]
- corrected i18n statement for archive section in extended sidebar [Wolfgang Thomas]
- adapt robot test to reflect the change done in e1bd895fa8ae9a6d562fe88d497790d090e6fdb4 [Wolfgang Thomas]
- Provide ids to distinguish between the 2 fieldsets for normal members and guests [Wolfgang Thomas]
- better solution for visually distinguishing guests from normal members [Wolfgang Thomas]
- found and fixed a serious flaw, wrote a test for it [Wolfgang Thomas]
- Use the builtin ``difference`` function of sets, thanks @ale-rt :-) [Wolfgang Thomas]
- typo [Wolfgang Thomas]
- Use the correct ``hidden`` attribute [Wolfgang Thomas]
- Add a robot test for the Guest user status, granted via being the assignee on a task [Wolfgang Thomas]
- Add comment about temporary display [Wolfgang Thomas]
- also update case guest access on every change on a Todo [Wolfgang Thomas]
- rephrase tests, add new tests, add descriptions to tests [Wolfgang Thomas]
- re-arrange [Wolfgang Thomas]
- more tests [Wolfgang Thomas]
- Remove the effing workspaces-membership cache from the request, and suddenly it works [Wolfgang Thomas]
- started writing basic tests, I don't understand why they are failing [Wolfgang Thomas]
- Grant / Revoke guest access to a case based on assignee state and the current milestone [Wolfgang Thomas]
- if a member has role "Guest", show informative tooltip instead of panel for changing role. [Wolfgang Thomas]
- First very basic attempt to add a new Role to workspaces, which will be used internally to handle temporary membership in a workspace / case. [Wolfgang Thomas]
- Assignee and Initiator: allow all any user to be added, and only allow actullaly present users to be added (no inventing of new user names) [Wolfgang Thomas]
- Merge pull request #248 from quaive/translations_fix_typo [Guido Stevens]
- fixed typo [Angela Steinhardt]
- Merge pull request #126 from quaive/115-workspace-templating-final [Guido Stevens]
- Update review state tests [Alessandro Pisa]
- Case freeze: use less guarded exit transitions, add robot tests [Alessandro Pisa]
- Case freeze: add "frozen" to the case manager filter [Alessandro Pisa]
- Resolve conflicts in sidebar [Alessandro Pisa]
- Add supervisor shutdown to all-clean target [Guido A.J. Stevens]
- Document autoexpand limit on threading filter [Guido A.J. Stevens]
- Optimize by not sending loads of SGML comments over the wire for every update [Guido A.J. Stevens]
- Make autoexpand logic resistant to end-of-pipe security filtering of content updates. [Guido A.J. Stevens]
- The presence of contentupdates should not block microblog testcontent creation [Guido A.J. Stevens]
- Provide migration [Guido A.J. Stevens]
- Add stream documentation, fixes #1 [Guido A.J. Stevens]
- Fix codeanalysis [Guido A.J. Stevens]
- The text "this item" appears only on the document stream [Guido A.J. Stevens]
- Scan env to force microblog into sync mode during testing. This removes nasty race conditions on module globals, removes nasty "dangling thread" errors, while still running production mode in performance-optimized async mode. The tests for async mode are smart enough to turn that on only for those tests. [Guido A.J. Stevens]
- Be picky about which object creations we're broadcasting to the stream [Guido A.J. Stevens]
- Force hard sync mode on microblog to get rid of test failures. Mode switching via module global is flaky and needs to be replaced. [Guido A.J. Stevens]
- Well duh, of course we need the subscribers in microblog testing [Guido A.J. Stevens]
- Deactivate subscribers unless suite is loaded - avoids tests on other packages crashing [Guido A.J. Stevens]
- More robot coverage on document discussions [Guido A.J. Stevens]
- Add robot test on document creation stream share [Guido A.J. Stevens]
- Post updates also on content creation, while respecting document-level workflow security. [Guido A.J. Stevens]
- Allow empty text for content updates [Guido A.J. Stevens]
- fix injection [Guido A.J. Stevens]
- Suppress older shares without replies [Guido A.J. Stevens]
- fix placeholder for existing comments [Guido A.J. Stevens]
- initial implementation of content stream on document [Guido A.J. Stevens]
- whitespace cleanup [Guido A.J. Stevens]
- Paying the Selenium tax, we greet our robot overloards. [Guido A.J. Stevens]
- Fix css class for preview [Guido A.J. Stevens]
- Finish and systematize stream rendering for both attach and content [Guido A.J. Stevens]
- Implement proper separate rendering for content image updates [Guido A.J. Stevens]
- Support File and html content updates [Guido A.J. Stevens]
- Script development startup sequence [Guido A.J. Stevens]
- Initial content updates rendering [Guido A.J. Stevens]
- Remove unused newpostbox_view indirection [Guido A.J. Stevens]
- Set action_verb on publication, and show in stream [Guido A.J. Stevens]
- Rebase branch to master [Alessandro Pisa]
- Don't use IContentStatusUpdate marker interface. [Guido A.J. Stevens]
- Implement action_verb in backend [Guido A.J. Stevens]
- Extract content related statusupdate testing to separate testcase [Guido A.J. Stevens]
- Provide per-document content_context indexed accessors. [Guido A.J. Stevens]
- Derive microblog_context from content_context [Guido A.J. Stevens]
- Clarify API for forcing microblog sync mode in tests. [Guido A.J. Stevens]
- fix dangling thread [Guido A.J. Stevens]
- rename test methods [Guido A.J. Stevens]
- Rename statusupdate init arg content -> content_context. This brings it in line with microblog_context, with the accessor name, and with the private storage name. [Guido A.J. Stevens]
- Replies inherit parent content context [Guido A.J. Stevens]
- Reorder and rename test methods [Guido A.J. Stevens]
- Fold content update testing into main statusupdate test module [Guido A.J. Stevens]
- Make api compatible with async statusupdate insertion. [Guido A.J. Stevens]
- Make workspace testfixture aware of async nature of statuscontainer. [Guido A.J. Stevens]
- implement content_context accessor [Guido A.J. Stevens]
- fix test failures [Guido A.J. Stevens]
- Initial subscriber for content being published [Guido A.J. Stevens]
- Initial work [Guido A.J. Stevens]
- Make is_archived and date_archived work equally [Alessandro Pisa]
- Merge pull request #243 from quaive/userprofile-extra-tabs-3 [Alessandro Pisa]
- Merge pull request #150 from quaive/194-workspace-archiving [Alessandro Pisa]
- Add 'All Intranet Uses' to list of groups not to show [Wolfgang Thomas]
- Set required class and and data for pat-stack. Also some more indentation fixes [Wolfgang Thomas]
- indentation: all spaces [Wolfgang Thomas]
- Re-generated liz-baker's profile page, since we need the styles for the workspace colours. Also, now directly use liz-baker.html from proto, instead of the detour via liz-baker/index.html [Wolfgang Thomas]
- Implement prototype: on the user profile, distinguish between groups and workspaces This contains changes that were cherry-picked from 5a6e1153213f4ea6c123664b69828a61f3fb8515 f974309c06dbb09c14f4e3bbf4467581e2378078 3cbbd6d636585ea2d4f557e8d5530fe922f6d6a9 [Wolfgang Thomas]
- Merge pull request #240 from quaive/enable-locales-notheme [Wolfgang Thomas]
- Revert "Refactor tests and documentation to use supported views for managing templates" [Alessandro Pisa]
- Merge pull request #239 from quaive/avatar-editable [Wolfgang Thomas]
- Merge pull request #236 from quaive/collation-in-search-view [Guido Stevens]
- updated js bundle [Alessandro Pisa]
- update to fix locale support [Alessandro Pisa]
- update to fix locale support [Alessandro Pisa]
- Refactor tests and documentation to use supported views for managing templates [Guido A.J. Stevens]
- Set membership on testcontent case template [Guido A.J. Stevens]
- Don't show empty optgroup [Guido A.J. Stevens]
- Since we now security filter, no need to privilege escalate anymore [Guido A.J. Stevens]
- implement security filtering on templates [Guido A.J. Stevens]
- Implement collation in search view facets [Alessandro Pisa]
- Land on workspace settings after creation [Guido A.J. Stevens]
- Add test coverage on division pointer (and allow "None") [Guido A.J. Stevens]
- Show the division titles, not UIDs in the add form dropdown :-) [Guido A.J. Stevens]
- Only show the avatar edit icon for current user [Cillian de Róiste]
- Merge pull request #234 from quaive/fix-markup [Alessandro Pisa]
- add missing class [Alexander Pilz]
- Bring tests inline with new implementation [Guido A.J. Stevens]
- Correct proto error [Guido A.J. Stevens]
- Refactor to new add workspace dialog w/ template support fixes #115 [Guido A.J. Stevens]
- Cleanup merge fallout from ae1a584 [Guido A.J. Stevens]
- Merge pull request #232 from quaive/typo-in-division-description [Wolfgang Thomas]
- Merge pull request #231 from quaive/fix-case-workflow-errors [Alexander Pilz]
- Merge pull request #230 from quaive/fix-datetime-attribute [Alexander Pilz]
- Merge branch '115-workspace-templating-final' of github.com:quaive/ploneintranet into 115-workspace-templating-final [Alexander Pilz]
- switch to listing templates that the user can see [Alexander Pilz]
- Merge pull request #229 from quaive/update-german-translations [Wolfgang Thomas]
- Fix test regression [Guido A.J. Stevens]
- Fix typo in division grouping template [Alessandro Pisa]
- fix test regression [Guido A.J. Stevens]
- Clean up that mess. Form renderer and its POST handler should be done in the same view, not spread across multiple views in multiple modules tied together with template actions. [Guido A.J. Stevens]
- Merge pull request #227 from quaive/show-division-titles [Wolfgang Thomas]
- Merge pull request #226 from quaive/ldap_version_pins [Wolfgang Thomas]
- Case workflow: don't put a guard expression on the transition "reset" [Wolfgang Thomas]
- Fix the date time attribute [Alessandro Pisa]
- Merge branch 'master' into 115-workspace-templating-final [Alexander Pilz]
- added translations for new search page. [Angela Steinhardt]
- added i18n statements for labels, option menu and content types. [Angela Steinhardt]
- Show the division titles, not UIDs in the add form dropdown [Alexander Pilz]
- updated translations for ploneintranet after merge of ikath branch. [Angela Steinhardt]
- Fix test: archived items do appear in searches [Cillian de Róiste]
- Merge pull request #225 from quaive/remove-locale-de [Wolfgang Thomas]
- Pin unpinned versions (mostly ldap dependencies) [Guido A.J. Stevens]
- Remove locale: de from data-pat-display-time [Alessandro Pisa]
- Merge pull request #224 from quaive/remove-unnecessary-reindex-object [Guido Stevens]
- Fix robot tests [Cillian de Róiste]
- Remove an unnecessary reindexObject [Alessandro Pisa]
- Robot: wait for injection to be finished [Cillian de Róiste]
- Don't render the DateCheckBoxWidget [Cillian de Róiste]
- Remove duplicate robot keyword [Cillian de Róiste]
- Fix merge issues [Cillian de Róiste]
- Archival: i18n support [Cillian de Róiste]
- Archiving: Case Manager filter archived items [Cillian de Róiste]
- Breadcrumbs: show archived icon [Cillian de Róiste]
- is_archived indexer: simplify [Cillian de Róiste]
- Add upgrade step to update the registry for solr conf [Cillian de Róiste]
- Search, don't puke if archived attrs aren't available [Cillian de Róiste]
- Bugfix: is_archived, don't index as None [Cillian de Róiste]
- Tidy up solr archived indexes [Cillian de Róiste]
- Fix the solr config updater [Cillian de Róiste]
- Solr: add the archival_date index [Cillian de Róiste]
- Add class for archived workspace sidebar [Cillian de Róiste]
- Test appearance of archived search results [Cillian de Róiste]
- Remove obsolete comment [Cillian de Róiste]
- Add robot test for archiving [Cillian de Róiste]
- Include and mark archived workspaces in search results [Cillian de Róiste]
- Add option to list archived workspaces [Cillian de Róiste]
- Search: don't include archived items by default [Cillian de Róiste]
- Save the archival_date when checked in the sidebar [Cillian de Róiste]
- Search Bugfix: allow searching for boolean False [Cillian de Róiste]
- Add the archival_date field and is_archived index [Cillian de Róiste]
- Update solr config when indexes are changed [Cillian de Róiste]
- Copied over DE translations from ikath.intranet [Wolfgang Thomas]
- Copy in existing DE translations from the ikath branch [Wolfgang Thomas]
- updated .po files with synci18n [Wolfgang Thomas]
- re-ran synci18n [Wolfgang Thomas]
- More manual message ids (cherry picked from commit eeb2a2e902dbefd0e7c67b89950b8046038c317d) [Wolfgang Thomas]
- added entry for ODT document for ticket #12193 [Wolfgang Thomas]
- fix HTML nesting [Wolfgang Thomas]
- Merge pull request #222 from quaive/imagepicker-redactor [Wolfgang Thomas]
- Merge pull request #223 from quaive/fix-nesting-error [Wolfgang Thomas]
- Fix a HTML nesting error in the search_results template Refs quaive/ploneintranet.prototype#248 [Wolfgang Thomas]
- Fix flake8 [Alessandro Pisa]
- larger previews [Alexander Pilz]
- json view for image picker [Alexander Pilz]
- Merge pull request #173 from quaive/sanitize_html [Wolfgang Thomas]
- Merge pull request #221 from quaive/activate-casemanager-tile [Wolfgang Thomas]
- Merge pull request #189 from quaive/sidebar-sync-with-ikath [Alexander Pilz]
- Add documentation [Wolfgang Thomas]
- better HTML example for the test [Wolfgang Thomas]
- Add a log statement in case RichText got sanitized [Wolfgang Thomas]
- perform HTML cleaning on all RichText, if the respective setting in the registry is turned on [Wolfgang Thomas]
- Add a registry record that defines if HTML cleaning will be performed or not and add tests for sanitize_html [Wolfgang Thomas]
- add extra dependency: htmllaundry [Wolfgang Thomas]
- Merge pull request #220 from quaive/use-pat-redactor [Alexander Pilz]
- Merge pull request #218 from quaive/fix-pat-moment [Alexander Pilz]
- activate the case manager tile [Alexander Pilz]
- Merge pull request #201 from quaive/rebased-index_SearchableText_async [Guido Stevens]
- Change pat-raptor to pat-redactor Long live the new editor! [Wolfgang Thomas]
- Use pat-display-time instead of pat-moment [Alessandro Pisa]
- Merge pull request #207 from quaive/decrease-complexity-in-longkeysortreverse [Alexander Pilz]
- Merge pull request #214 from quaive/event-description [Alexander Pilz]
- Merge pull request #210 from quaive/persist-search-options [Alexander Pilz]
- Merge pull request #216 from quaive/allow-reimport [Alexander Pilz]
- Try to make the case.robot tests more robust [Alexander Pilz]
- Fix a js error in robot tests [Alexander Pilz]
- Improve ploneintranet.api.userprofile.get [Alexander Pilz]
- use get_state to get the review_state [Alexander Pilz]
- Change default entry in selects [Alexander Pilz]
- Merge pull request #217 from quaive/improve-robot-case-tests [Alexander Pilz]
- Try to make the case.robot tests more robust [Wolfgang Thomas]
- Merge pull request #212 from quaive/improve-get-performance-by-traversing [Wolfgang Thomas]
- Merge pull request #203 from quaive/pi-585-change-select-no-value [Wolfgang Thomas]
- Merge pull request #213 from quaive/pi-use_api [Wolfgang Thomas]
- allow reimporting this profile without exception [Alexander Pilz]
- Merge pull request #215 from quaive/fix-js-error-in-robot-tests [Wolfgang Thomas]
- Fix a js error in robot tests [Alessandro Pisa]
- Add the description field in the event view [Alessandro Pisa]
- Improve ploneintranet.api.userprofile.get [Alessandro Pisa]
- Merge pull request #209 from quaive/unifiy-user-getters [Wolfgang Thomas]
- use get_state to get the review_state [Alessandro Pisa]
- Change default entry in selects [Alessandro Pisa]
- holy flying spaghetti monster! ``acl_users.searchGroups(id='john')`` might return None (or groups that start with john), but ``acl_users.searchGroups(id=u'john')`` will return "All intranet users". [Wolfgang Thomas]
- Add more tests for the fulltext user search [Wolfgang Thomas]
- Let also AllUsersAndGroupsJSONView profit from the improved pi_api.get_users [Wolfgang Thomas]
- When we want to get an exact match in a user search, use ``exact_getUserName`` instead of ``getId`` [Wolfgang Thomas]
- Merge pull request #205 from quaive/pi-503-insufficient-privileges [Wolfgang Thomas]
- Add inline documentation to longkeysortreverse [Guido A.J. Stevens]
- When specifying both context and exact_getUserName, calculate intersection of both. [Guido A.J. Stevens]
- Persistent search options [Alessandro Pisa]
- Verify that we're indeed returning iterators. [Guido A.J. Stevens]
- Don't hardcode testuser in implementation [Guido A.J. Stevens]
- Merge pull request #197 from quaive/195-tasks-transitions [Wolfgang Thomas]
- Merge pull request #206 from quaive/remove-unzip-true [Wolfgang Thomas]
- Merge pull request #208 from quaive/division-test-robustness [Alessandro Pisa]
- The insufficient privileges has a status message [Alessandro Pisa]
- allow allusers.json not only on the Navigation root, but everywhere, since the underlying user getter takes care of handling the context [Wolfgang Thomas]
- don't choke if the search term is only whitespace [Wolfgang Thomas]
- Alice Lindström is actually not a member of the workspace we use for testing. (Our test scenario is way before #129) Therefore use François Gast instead (who has the decency to be in the WS and also contain a non-ASCII character in his name) [Wolfgang Thomas]
- We have brains now, so it's getId, not id... [Wolfgang Thomas]
- Make sure to call panel-users on the correct context, so that get_users can filter by it #129 [Wolfgang Thomas]
- In panel_users (microblog): Use the user search from pi_api, and make sure we don't get full objects #86 [Wolfgang Thomas]
- Make "Alice can create a division and list workspaces by division" more robust, since it failed today in gitlab [Wolfgang Thomas]
- get rid of filter_users_json, since the filtering is now done in the pi_api via a catalog search [Wolfgang Thomas]
- 2 more tests for TestUserProfileGetUserSuggestions that pass a sarch parameter [Wolfgang Thomas]
- Fix test regressions introduced in ec63cc3c18748aa89bf2b5e7e72e854879cc0de2 [Wolfgang Thomas]
- Optimize by never carrying the full list of all user objects [Wolfgang Thomas]
- Provide staggered user suggestions in a way similar to personalized tagging behavior. Refs #128 #86 [Wolfgang Thomas]
- Streamline and generalize IMemberGroup adaptation, refs #129. [Wolfgang Thomas]
- Factor out and extend get_users() test coverage [Wolfgang Thomas]
- Refactor WorkspaceMembersJSONView to use api's new get_users [Wolfgang Thomas]
- start with refactoring get_users [Wolfgang Thomas]
- let our Workspace Folder provide the IMembershipResolver interface [Wolfgang Thomas]
- Add a marker interface for content that can reolve its members [Wolfgang Thomas]
- Add email to the metadata of the membrane catalog [Wolfgang Thomas]
- housekeeping: fix typos in test user names that get added as members to some workspaces [Wolfgang Thomas]
- Housekeeping: Replace tal-attributes with better readable chameleon syntax [Wolfgang Thomas]
- Decrease complexity in longkeysortreverse [Alessandro Pisa]
- Merge pull request #198 from quaive/20160513-make-diazo-styles [Guido Stevens]
- Merge pull request #199 from quaive/53-flake8-cleanup [Guido Stevens]
- Merge pull request #200 from quaive/remove-p.a.async-dependency [Guido Stevens]
- Merge pull request #202 from quaive/pi-819-include-tracking-code [Guido Stevens]
- Merge pull request #204 from quaive/understand-ajax_load [Guido Stevens]
- Remove unzip=true from buildout [Alessandro Pisa]
- Understand ajax_load parameter [Alessandro Pisa]
- Append the webstats_js view [Alessandro Pisa]
- Refactor for readability [Alessandro Pisa]
- take new async into account and reindex immediately [Alessandro Pisa]
- don't reindex async anymore, actually only do it for SearchableTest [Alessandro Pisa]
- Remove old dependency [Alexander Pilz]
- Fix code analisys [Alessandro Pisa]
- Latest generated styles after todays make diazo [Alessandro Pisa]
- Do not notify ObjectModifiedEvent just to trigger a catalog reindex [Alessandro Pisa]
- Merge pull request #196 from quaive/update-option-label [Alexander Pilz]
- Merge pull request #192 from quaive/fix-event-notification [Alexander Pilz]
- Merge pull request #193 from quaive/task-view-workflow-menu [Alexander Pilz]
- Update option label [Alessandro Pisa]
- Also update workflow-menu [Alessandro Pisa]
- Avoid to reindex twice [Alessandro Pisa]
- We do not want an event on workflow transitions [Alessandro Pisa]
- Fix event notification [Alessandro Pisa]
- Merge pull request #190 from quaive/doc-for-registry-dashboard_default [Wolfgang Thomas]
- Merge pull request #185 from quaive/configurable-default-dashboard [Wolfgang Thomas]
- Backend allows templates for all workspace types [Alessandro Pisa]
- Merge branch 'master' into sidebar-sync-with-ikath [Cillian de Róiste]
- Merge pull request #191 from quaive/translations_for_cartactions [Wolfgang Thomas]
- Fix "Items(s) pasted" injection [Cillian de Róiste]
- solved problems with too long lines for code-analysis [Angela Steinhardt]
- Sidebar: revert icon-cancel-circle to fix tests [Cillian de Róiste]
- Tidy up [Cillian de Róiste]
- added translation tokens for delete and send buttons. [Angela Steinhardt]
- added translation tokens for status messages and emails. [Angela Steinhardt]
- added documentation [Alexander Pilz]
- Merge pull request #183 from quaive/bulk-mail [Wolfgang Thomas]
- Merge pull request #188 from quaive/disable-production-bundle [Wolfgang Thomas]
- Merge pull request #162 from quaive/fix-portal-tabs [Wolfgang Thomas]
- Merge pull request #174 from quaive/fire-objectcreatedevent [Wolfgang Thomas]
- Do nothing on copy [Alessandro Pisa]
- Listen also for ObjectCreatedEvent [Alessandro Pisa]
- Fire ObjectCreatedEvent at creation [Alessandro Pisa]
- Revert "Update documentation about OSX docker with case-insensitive filesystems, which is the default for OSX." [Wolfgang Thomas]
- Merge pull request #186 from quaive/177-fix-delete-confirmation [Wolfgang Thomas]
- Update documentation about OSX docker with case-insensitive filesystems, which is the default for OSX. [Jean-Paul Ladage]
- Merge pull request #181 from quaive/case-manager-for-ICase [Wolfgang Thomas]
- Sidebar: sync changes from ikath.intranet [Cillian de Róiste]
- Merge pull request #180 from quaive/extend-solr [Wolfgang Thomas]
- Merge pull request #167 from quaive/optimise-object-creation [Guido Stevens]
- Merge pull request #182 from quaive/fix-injection-robot-heisenbugs [Guido Stevens]
- Return the production bundle if we ploneintranet bundle is disabled (happens in the library) [Alessandro Pisa]
- Do not pull in resources from the production bundle [Alessandro Pisa]
- Disable production bundle [Alessandro Pisa]
- Disable injection hooks in the modal [Alessandro Pisa]
- Merge pull request #184 from quaive/revert-169-disable-production-bundle [Alessandro Pisa]
- move the setting for the default dashboard view to registry so that integrators can pick their default. [Alexander Pilz]
- Revert "Disable production bundle" [Alessandro Pisa]
- Bulk actions: send, include translations [Cillian de Róiste]
- Merge pull request #179 from quaive/update-about-docs [Guido Stevens]
- Bulk actions: add robot test for sending email [Cillian de Róiste]
- allow allusers.json on the root [Cillian de Róiste]
- Make @@allusers.json available on the portal root [Cillian de Róiste]
- Mail bulk action: be more defensive [Cillian de Róiste]
- Merge pull request #176 from quaive/refactor-workspace-interface [Alessandro Pisa]
- Merge pull request #178 from quaive/remove-duplicated-reindex2 [Alessandro Pisa]
- add object_provides index to support querying by iface [Alexander Pilz]
- don't filter by portal_type, filter by interface [Alexander Pilz]
- additional index and solr tuning [Alexander Pilz]
- add review state to filter fields [Alexander Pilz]
- update info on board mailinglist [Alexander Pilz]
- Fix more injection related heisebugs in robot tests (continues work from #147) [Wolfgang Thomas]
- not only set the title, also use it [Alexander Pilz]
- also apply namechoosing to workspace creation, thanks @gyst [Alexander Pilz]
- remove reindex as it is already called by the event [Alexander Pilz]
- also fix import for cases [Alexander Pilz]
- Bulk send: Prefil recipients with to_notify field [Cillian de Róiste]
- refactor the interface for workspacefolders out into interfaces to avoid circular import issues [Alexander Pilz]
- Add translations for email send confirmation [Cillian de Róiste]
- Fix UnicodeDecodeError in the message, add notification [Cillian de Róiste]
- Batch send: attach imgs and show previews [Cillian de Róiste]
- Share by mail: include links to the items in the msg [Cillian de Róiste]
- File sharing: Use base64 encoding for files [Cillian de Róiste]
- Bulk send: fix user picker and attachments [Cillian de Róiste]
- Only show the send options when files have been selected [Cillian de Róiste]
- Merge pull request #169 from quaive/disable-production-bundle [Alexander Pilz]
- Merge pull request #171 from quaive/case-template-matches-latest-prototype [Alexander Pilz]
- Merge pull request #166 from quaive/more-solr-indexes [Guido Stevens]
- Merge pull request #163 from quaive/nuke-transitions-styles [Guido Stevens]
- Merge pull request #151 from quaive/nuke-transitions [Guido Stevens]
- Merge pull request #165 from quaive/dont-die-if-preview-is-faulty [Guido Stevens]
- Merge pull request #98 from quaive/groupspaces [Guido Stevens]
- Merge pull request #164 from quaive/preview-feedback-enhancement [Alessandro Pisa]
- Match latest prototype [Alessandro Pisa]
- Do not pull in resources from the production bundle [Alessandro Pisa]
- pass a valid id to object creation. Otherwise p.api will first create an object with a random int id, do a partial commit and then rename it. This is stupid because all our async jobs will get started already for the temporary object. The workaround is easy and even documented by maurits inline in p.api. [Alexander Pilz]
- Also index subject and getId in solr [Alexander Pilz]
- Turn solr traverse traceback into a logged error message. This does not really fix the underlying problem. [Alexander Pilz]
- Disable production bundle [Alessandro Pisa]
- Merge pull request #161 from quaive/apps-view-hookable [Alexander Pilz]
- Handle edge case where preview can't be generated by exposing more documentviewer properties in api [Alexander Pilz]
- Merge pull request #159 from quaive/report-on-update [Alessandro Pisa]
- Merge pull request #160 from quaive/align-preview-markup [Alessandro Pisa]
- The index_html portal_tabs action comprises the default value when determining which tab is active. If an arbitrary browser view is called on the portal root which is not present in the portal_tabs, the index_html action will be highlighted in the tab navi as current. This is not true however, one example is the notifications view. If viewed, it highlights the dashboard. The proper solution is to have a hidden Home action that also points to the dashboard and a regular dashboard action that only highlights when actually loaded. [Alexander Pilz]
- The view @@apps.html is now configurable [Alessandro Pisa]
- Added generated/style after make diazo [Alessandro Pisa]
- Reflect proto markup, depend on availability of preview [Alexander Pilz]
- Include change descriptions in ObjectModifiedEvent for basecontent. Refs #12434 [Alexander Pilz]
- dexterity_update: return info about what was modified, refs #12434 [Alexander Pilz]
- Nuke transitions while robot testing [Alessandro Pisa]
- Merge pull request #153 from quaive/news-portlet-more-flexible [Guido Stevens]
- Merge pull request #156 from quaive/sane-default-for-events-tile [Guido Stevens]
- Add testcoverage for recursive group membership relations [Wolfgang Thomas]
- Don't offer self-recursion [Wolfgang Thomas]
- enable logging on membrane subscriber [Wolfgang Thomas]
- Don't allow a secret workspace to be added as a member to another workspace, even when bypassing the UI [Wolfgang Thomas]
- activate IMembraneGroup behaviour by default [Wolfgang Thomas]
- Update subscribers to explain why we check for PloneApiError [Wolfgang Thomas]
- Update group.py to avoid list comprehension [Wolfgang Thomas]
- If a workspace is secret, don't offer it as selection to be added as member, and ignore it in member listings inside a workspace. [Wolfgang Thomas]
- Add the workspace's state to the property sheet of the group (and for good measure also the UID, might come in handy...) [Wolfgang Thomas]
- Make the roster view (members of a group in a workspace) play nicely with groups [Wolfgang Thomas]
- since we define our own IMembraneUserProperties provider, we might as well add the description of and the path to the workspace [Wolfgang Thomas]
- Fixing tests: remove cached localrole information from the request. Thanks @ale-rt! [Wolfgang Thomas]
- don't fail in our event subscriber if the membrane_tool can't be fetched [Wolfgang Thomas]
- make ploneintranet.userprofile the first dependency, so that we can be sure membrane is properly installed [Wolfgang Thomas]
- Added docstrings to the more complext tests [Wolfgang Thomas]
- Add a test for the MembraneGroupPropertiesProvider [Wolfgang Thomas]
- Adapt our dexterity membrane groups behavior to IMembraneUserProperties, so that our membrane-workspaces can have property sheets, e.g. for title [Wolfgang Thomas]
- Add a test for the scenario: User X is member of workspace A, WS A is member of WS B, WS B is member of WS C Then User X is member of workspace C [Wolfgang Thomas]
- Moved activating the IMembraneGroup behavior to setUpPloneSite of the testing layer [Wolfgang Thomas]
- Add an event handler that checks if the FTI for workspaces was modied & the IMembraneUserGroups behavior added or removed. In this case update the membrane tool and reindex all workspaces [Wolfgang Thomas]
- We also need to make sure our IMembraneGroup behavior provides IMembraneUserGroups, so that the membrane_groups plugin can found out, which workspaces a workspace is a member of. Example: Workspace B has as member Workspace A Workspace A can only know (in the membrane sense) that it is a member of workspace B via the IMembraneUserGroups lookup [Wolfgang Thomas]
- use membrane users, not basic PloneUsers, so that the permissions based on membership in a membrane group will be properly assigned [Wolfgang Thomas]
- we need to make sure the Products.membrane profile is applied to the site in test setup [Wolfgang Thomas]
- make sure the membrane_groups plugin comes before recursive_groups [Wolfgang Thomas]
- Creating a behaviour for IGroup provides the lookup workspace->members. But still missing (in the security sense) is the lookup user->workspaces, which is required for checking access permissions of an individual user. If access is granted to a user indirectly via membership in a workspace-group, this missing lookup would lead to Unauthorized. Therefore, we need to adapt the membrane user object (for dexterity) so that it also implements IMembraneUserGroups and thereby fulfils the contract of IGroupsPlugin from Products.PluggableAuthService [Wolfgang Thomas]
- Add a failing test that checks if permisison via group membership in a groupspace gets properly propagated [Wolfgang Thomas]
- 2 more basic tests [Wolfgang Thomas]
- First basic tests for the groupspace behavior [Wolfgang Thomas]
- Add a basic behaviour for Workspacefolder that turns it into a membrane group [Wolfgang Thomas]
- Merge pull request #158 from quaive/121-set-creation-date-for-sorting [Alessandro Pisa]
- For the items that we are using to test sorting, set creation dates in the past on 2 of them, so that the remaining item will always have the most recent creation date [Wolfgang Thomas]
- Merge pull request #157 from quaive/better-translation-support [Wolfgang Thomas]
- Merge pull request #154 from quaive/dont-fulltext-index-images [Wolfgang Thomas]
- Merge pull request #130 from quaive/bulk-action-permissions [Guido Stevens]
- As soon as a system is in use, the events tile will show all visible events and expand ad libitum. This limits to a sane default of 5 upcoming events [Alexander Pilz]
- Do not send image data to the solr fulltext extraction. [Alexander Pilz]
- Add i18n:translates [Alexander Pilz]
- Correct the location of the i18n:translate statement [Alexander Pilz]
- translate a status message [Alexander Pilz]
- Don't filter by published state to allow the news portlet to be as flexible as possible. With this, integrators are free to define themselves who can when see a news item. [Alexander Pilz]
- This is going way beyond the "bulk delete" PR. Disabling new tests for now. [Guido A.J. Stevens]
- Bulk: improve text in the delete modal and notification [Cillian de Róiste]
- Merge pull request #149 from quaive/121-yet-more-robot-fixes [Alessandro Pisa]
- Merge pull request #148 from quaive/146-tooltip-in-metromap [Wolfgang Thomas]
- Extract boilerplate. Rename tests. Add coverage on cases. Breakage WIP. [Guido A.J. Stevens]
- revert my initial idea, based on wrong assumption. Instead, ensure that the action to open the "Functions" panel has really completed [Wolfgang Thomas]
- Owner is actually NOT always allowed to delete, that would conflict with cases. [Guido A.J. Stevens]
- testing another safeguard for robot tests to ensure a certain patterns action has completed. In this case, opening amodal adds a class to the body [Wolfgang Thomas]
- Add history button in the metromap [Alessandro Pisa]
- Merge pull request #147 from quaive/121-fix-ws-robot-injection-problems [Guido Stevens]
- For #121 make use of the fact that while injection is happening, the temporary class "injecting" is present [Wolfgang Thomas]
- Add testcoverage on modify workspace content, bring "moderators" policy in line with documented intent. [Guido A.J. Stevens]
- Owner is always allowed to delete own workspace content. Add testcoverage for owner on workspace content workflow. [Guido A.J. Stevens]
- Merge pull request #144 from quaive/sort-task-by-position [Guido Stevens]
- Merge pull request #145 from quaive/121-improve-robot-keywords [Guido Stevens]
- Make robot keywords properly wait for injection to finish [Alessandro Pisa]
- Merge pull request #143 from quaive/132-update-theme-step-1 [Guido Stevens]
- Change task sorting criterion [Alessandro Pisa]
- New audit view template from prototype and rules.xml [Alessandro Pisa]
- Merge pull request #141 from quaive/feature/12992-no-solr-optimize-on-commit2 [Alexander Pilz]
- document solr maintenance views [Guido A.J. Stevens]
- Enable anon cron solr optimization while excluding DoS [Guido A.J. Stevens]
- Merge pull request #142 from quaive/166-implement-pat-tabs [Alessandro Pisa]
- Implement pat-tabs to show nav items that don't fit on screen anymore. (Finally) Implements prototype #166 [Alexander Pilz]
- don't optimise with every commit anymore [Alexander Pilz]
- Merge pull request #134 from quaive/feature/ldap-configuration [Guido Stevens]
- Provide partial uninstall support for LDAP [Guido A.J. Stevens]
- Merge pull request #139 from quaive/133-scorched-as-a-base-requirement [Guido Stevens]
- scorched is always required [Alessandro Pisa]
- Merge pull request #138 from quaive/132-audit-log-buttons [Guido Stevens]
- Merge pull request #136 from quaive/gitignore-src [Guido Stevens]
- Merge pull request #137 from quaive/audit-diazo-rule [Guido Stevens]
- Conditionally add the history button to the one available [Alessandro Pisa]
- rules to include audit log [Alessandro Pisa]
- Ignore some packages a developer can find in its src folder [Alessandro Pisa]
- Add ldap dependencies to Docker and clarify LDAP documentation [Guido A.J. Stevens]
- Fix Library profile names [Guido A.J. Stevens]
- Show LDAP is part of Suite [Guido A.J. Stevens]
- Clarify venus install instructions [Guido A.J. Stevens]
- Add documentation for ldap support [Guido A.J. Stevens]
- fix tests [Guido A.J. Stevens]
- remove schema files; update gitignore; update ldap/README.md [Guido A.J. Stevens]
- include pointer on how to change password [Guido A.J. Stevens]
- Add README; install plone.app.ldap add-on with Ploneintranet [Guido A.J. Stevens]
- remove dependency to suite:ldap profile [Guido A.J. Stevens]
- add missing test user passwords [Guido A.J. Stevens]
- fix dependencies and ploneintranet.ldif [Guido A.J. Stevens]
- fix link to user profile management section [Guido A.J. Stevens]
- include ldap.cfg by default, but do not start slapd by supervisor automatically. Also cleanup [Guido A.J. Stevens]
- fix supervisor problems for ldap, add ldap schema, move ldap.cfg out of builout.d dir [Guido A.J. Stevens]
- add basic ldap configuration [Guido A.J. Stevens]
- Merge pull request #127 from quaive/55-frontend-setup [Guido Stevens]
- PI Workflow: Manage the Delete objects permission [Cillian de Róiste]
- Don't manage PI content permissions in PI WS workflow [Cillian de Róiste]
- Revert "PI WS Workflow, add Delete permission tests" [Cillian de Róiste]
- Merge pull request #131 from quaive/128_csrf [Alessandro Pisa]
- Improve readability of case workflow definition [Guido A.J. Stevens]
- update case workflow comment [Guido Stevens]
- PI WS Workflow, add Delete permission tests [Cillian de Róiste]
- Mark async microblog insertion as safeWrite to avoid CSRF errors fixes #128, hopefully [Guido A.J. Stevens]
- Bulk actions: remove obsolete cart implementation [Cillian de Róiste]
- Bulk actions: manage the Delete objects permission [Cillian de Róiste]
- Bulk paste: check permissions for pasting [Cillian de Róiste]
- Bulk cut: notify if selected objs can't be cut [Cillian de Róiste]
- Bulk delete: only allow deletable items to be selected [Cillian de Róiste]
- Small corrections [Alexander Pilz]
- Add documentation for additional production components [Claudio Kirchhoff]
- change zope port to 8080 in haproxy configuration file [Claudio Kirchhoff]
- change port back to 8090, this is actually the varnish port [Claudio Kirchhoff]
- change ip address to "localhost"; change port 8090 to 8080, because that is the default in plonintranet [Claudio Kirchhoff]
- Merge pull request #124 from quaive/121-fix-robot-test-wait [Guido Stevens]
- Merge pull request #123 from quaive/PloneHotfix20160419 [Alessandro Pisa]
- intranet.example.com configuration files. Documentation follows [Alexander Pilz]
- Fix robot test timings [Alessandro Pisa]
- Merge pull request #120 from quaive/post_microblog_cleanup [Guido Stevens]
-     Products.PloneHotfix20160419==1.0 [Alexander Pilz]
- Remove spurious date display left after microblog refactoring [Guido A.J. Stevens]
- Merge pull request #108 from quaive/send-email-to-invitees [Guido Stevens]
- Send email to invitees [Alessandro Pisa]
- Merge pull request #87 from quaive/piapi-to-get-users-and-sorting [Alexander Pilz]
- Merge pull request #105 from quaive/fix-casemanager-icons [Alessandro Pisa]
- use pi_api to retrieve users and also sort the results [Alessandro Pisa]
- Metromap: fix display of transition icons and titles [Alessandro Pisa]
- fix icons [Alessandro Pisa]
- Merge pull request #106 from quaive/document-portal-registry [Guido Stevens]
- Merge pull request #40 from quaive/Plone5.0.4 [Alessandro Pisa]
- Use more meaningfull title and descriptions [Alessandro Pisa]
- Document portal registry [Alessandro Pisa]
- Merge pull request #104 from quaive/case-manager-diazo-rule [Alessandro Pisa]
- If we do not have settings.num_pages do not even try to get in to previews [Philip Bauer]
- remove empty setuphandler [Philip Bauer]
- TestUpload should be functional (not that that fixes the fail) [Philip Bauer]
- Fix async test user permission problem and document debug procedure [Philip Bauer]
- add test docstring [Philip Bauer]
- make failing test more easily pdb accessible [Philip Bauer]
- Increase granularity of failing test for clarity [Philip Bauer]
- remove obsolete resources [Philip Bauer]
- fixing all test-isolation-issues is not in the scope of this pr [Philip Bauer]
- another commit to deal with post_handlers not having the same context as import-steps [Philip Bauer]
- fix another issue due to post_handler not having the same context as import-steps [Philip Bauer]
- fix issues due to post_handler not having the same context as import-steps [Philip Bauer]
- turn all importSteps into post_handlers [Philip Bauer]
- maybe last change due to changes in pac [Philip Bauer]
- fix & remove tests for obsolete resources [Philip Bauer]
- add more flake8-ignores [Philip Bauer]
- remove old css- and js-registrations [Philip Bauer]
- third bunch of changes due to changes in pac [Philip Bauer]
- update dependencies [Philip Bauer]
- remove orphaned pinns [Philip Bauer]
- try new plone.testing that refuses to break test-isolation [Philip Bauer]
- second bunch of changes due to pac [Philip Bauer]
- workaround issue with five.intid by pinning a older version [Philip Bauer]
- adapt the first bunch of packages to changes in base-layer of pac [Philip Bauer]
- pinn Plone 5.0.4 cored uses 5.1 [Philip Bauer]
- Merge pull request #101 from quaive/99-remove-ploneintranet.activitystream.stylesheets [Guido Stevens]
- add a rule to use the correct prototype template [Alexander Pilz]
- Merge pull request #100 from quaive/fix-import-step-dependency [Wolfgang Thomas]
- Clean up references to old code/logic [Alessandro Pisa]
- Fix import step dependency [Alessandro Pisa]
- Merge pull request #96 from quaive/robot-keyword-robustness [Wolfgang Thomas]
- Merge pull request #95 from quaive/cart-paste-permission [Wolfgang Thomas]
- This improvess the robustness of the tests [Alessandro Pisa]
- Merge pull request #97 from quaive/workspace-bugfixes [Alessandro Pisa]
- Merge pull request #94 from quaive/elvis_lives [Alessandro Pisa]
- bugfix: the workspace_types parameter of the query must either be string or list. If it's a tuple with more than one value, no results are found [Wolfgang Thomas]
- Unicode, unicode, unicode! (We want to be able to search for "Lindström"...) [Wolfgang Thomas]
- Merge pull request #91 from quaive/improve-event-view [Wolfgang Thomas]
- Merge pull request #92 from quaive/i18n-in-delete-confirmation [Wolfgang Thomas]
- Merge pull request #93 from quaive/core_cleanup [Alessandro Pisa]
- Paste only requires Add permission not Modify [Cillian de Róiste]
- Merge pull request #89 from quaive/25-fix-indexer [Guido Stevens]
- added i18n statements for texts in batch delete form. [Alessandro Pisa]
- also make selection classes available on event add form [Alessandro Pisa]
- autocolour groups [Alessandro Pisa]
- Elvis lives! But this code must die. Remove unused legacy plonesocial cruft. [Guido A.J. Stevens]
- Nothing to be tested in core anymore [Guido A.J. Stevens]
- Merge pull request #90 from quaive/fix-todo-view [Wolfgang Thomas]
- Remove another core dependency [Guido A.J. Stevens]
- Merge pull request #83 from quaive/metromap-states [Wolfgang Thomas]
- Merge pull request #84 from quaive/properly-notify-modification-event [Wolfgang Thomas]
- Cut legacy dependencies for pagerank [Guido A.J. Stevens]
- Fix UUIDindex when no division is set [Alessandro Pisa]
- Strip ploneintranet.core package Leaving only release tools, translations and BBB browserlayer and uninstall for existing installs. [Guido A.J. Stevens]
- Fix zcml [Guido A.J. Stevens]
- fix todo title. Can't fix that in PI first as we are building up unmerged pull requests [Alessandro Pisa]
- Move my_documents.tile from core to layout [Guido A.J. Stevens]
- Merge pull request #85 from quaive/76_microblog_cleanup [Alessandro Pisa]
- Update documentation. Fixes #76. [Guido A.J. Stevens]
- Catch some more refactoring fallout [Guido A.J. Stevens]
- Remove outdated test, not needed given robot coverage [Guido A.J. Stevens]
- Flatten activitystream.browser structure [Guido A.J. Stevens]
- Move all update-social related code/templates from core into microblog/browser [Guido A.J. Stevens]
- Flatten microblog.browser structure [Guido A.J. Stevens]
- update proto doc comments [Guido A.J. Stevens]
- Remove newpostbox indirection from panel_users and panel_tags [Guido A.J. Stevens]
- Restore comment functionality. [Guido A.J. Stevens]
- Separate update-social form rendering, from http post handling [Guido A.J. Stevens]
- Skip tile tests for now [Guido A.J. Stevens]
- Remove more unused legacy plonesocial code. [Guido A.J. Stevens]
- Decouple form handling away from newpostbox.tile. [Guido A.J. Stevens]
- Purge unused legacy plonesocial stream view w/ css/js resources [Guido A.J. Stevens]
- Remove activity-stream.html indirection completely. [Guido A.J. Stevens]
- Turn post-well-done.html and comment-well-said.html into proper views. [Guido A.J. Stevens]
- Use post.html view not activity-stream.html macro in post-well-done.html (To fix: double DB write) [Guido A.J. Stevens]
- Turn update-social.html into a standalone view WIP - plaintext post works - comments disabled - tags, mentions, previews to be fixed [Guido A.J. Stevens]
- Remove spurious adapter registration. [Guido A.J. Stevens]
- resurrect IStatusActivityReply for BBB purposes [Guido A.J. Stevens]
- Completely purge all IActivity, IStatusActivity, IStatusReplyActivity [Guido A.J. Stevens]
- Missed those. [Guido A.J. Stevens]
- Make microblog API async safe [Guido A.J. Stevens]
- Fix weird threading edge case [Guido A.J. Stevens]
- Render post.html on IStatusUpdate directly, avoiding IStatusActivity indirection [Guido A.J. Stevens]
- Let all post.html view accessors hit StatusView instead of ActivityView [Guido A.J. Stevens]
- Let all post.html context accessors hit IStatusUpdate instead of IStatusActivity [Guido A.J. Stevens]
- Turn post.html into a proper view [Guido A.J. Stevens]
- turn comment.html into a proper view [Guido A.J. Stevens]
- Inline avatar rendering completely [Guido A.J. Stevens]
- Inline avatar wrapper templates [Guido A.J. Stevens]
- Merge pull request #82 from quaive/hostname_default_configurable [Alexander Pilz]
- Merge pull request #80 from quaive/73-dashboard-tiles-configurable [Alexander Pilz]
- Merge pull request #79 from quaive/72-workspace-types-configurable [Alexander Pilz]
- trigger ObjectModifiedEvent when task is closed or re-opened. Remove extra reindexObject call [Alessandro Pisa]
- Case reject: handle milestone states not in the MM [Alessandro Pisa]
- Refs #12692 Case: treat a WF state not in the MMap as a future state [Alessandro Pisa]
- ThemeSwitcher: Also allow hostname_default to be configured from buildout [Alessandro Pisa]
- Tiles in the dashboard are configurable [Alessandro Pisa]
- Other configurations for workspaces [Alessandro Pisa]
- Merge pull request #77 from quaive/71-sorting-configurable [Alexander Pilz]
- Merge pull request #78 from quaive/error-tolerant-indexing [Alessandro Pisa]
- Simply the fallback for Description() [Wolfgang Thomas]
- using getattr to check for the existence of an attribute without a fallback makes no sense [Wolfgang Thomas]
- Don't choke during indexing if for any reason the IMembraneUserObject interface cant't be applied to a user object. This might happen in an attempt to delete a half- initialised portal [Wolfgang Thomas]
- When a portal gets deleted in the ZMI, plone.api might not be able to fetch the portal. We don't want to make deleting impossible due to an unindexing error [Wolfgang Thomas]
- Workspace sorting [Alessandro Pisa]
- Merge pull request #74 from quaive/case-manager-review-states [Wolfgang Thomas]
- Configure the states in the dropdown menu of the case manager view [Alessandro Pisa]
- Merge pull request #69 from quaive/division-vocabulary-improvements [Alexander Pilz]
- Merge pull request #70 from quaive/case-manager-view [Alexander Pilz]
- Fix divisions vocabulary [Alessandro Pisa]
- First introduction of the case case-manager view [Alessandro Pisa]
- Fix test runner [Alessandro Pisa]
- More advanced testing [Alessandro Pisa]
- Make tests more high load resistant [Alessandro Pisa]
- Add the date-picker-i18n.json view [Alessandro Pisa]
- Merge pull request #68 from quaive/more-flexibility-while-creating-cases-in-testing-profile [Alexander Pilz]
- create_caseworkspaces function has more parameters [Alessandro Pisa]
- Merge pull request #54 from quaive/user-and-group-picker [Alexander Pilz]
- Merge pull request #62 from quaive/60-cases-should-not-be-divisions [Alexander Pilz]
- workspace.testing: tidy up imports [Cillian de Róiste]
- Merge pull request #65 from quaive/64-remove-commented-code [Alexander Pilz]
- Merge pull request #66 from quaive/newruby [Alexander Pilz]
- Fix test setup import error [Cillian de Róiste]
- Remove commented [Alessandro Pisa]
- Streamline proto demo. New ruby is pulled in from quaive/ploneintranet-base. [Guido A.J. Stevens]
- Merge pull request #61 from quaive/58-fix-tags-in-library [Guido Stevens]
- Fix test layer error [Cillian de Róiste]
- Division fields in the workspace sidebar [Alessandro Pisa]
- Merge pull request #57 from quaive/remove-traces-of-ikath [Guido Stevens]
- To fix #58 we need to 1) handle the fact that the solr searchresults now return a list of dicts for tag, and no longer a list of tag names 2) handle the fact that library.utils.search() now takes an extra parameter, so when passing arguments, we must do that as names arguments and not rely on the order any more [Wolfgang Thomas]
- Remove traces of ikath [Alessandro Pisa]
- Test user and group prefill [Cillian de Róiste]
- Merge pull request #55 from quaive/43-46-improvements-on-search-ui [Guido Stevens]
- Add tests for AllUsersAndGroupsJSONView [Cillian de Róiste]
- Preview and filter search results [Alessandro Pisa]
- Merge branch 'release-1.1.x' [Guido A.J. Stevens]
- Fix typo: user -> users [Cillian de Róiste]
- Test that group users are returned [Cillian de Róiste]
- Merge pull request #39 from quaive/avatar-upload [Guido Stevens]
- Fix missing imports and duplicate definitions [Cillian de Róiste]
- Style: Fix E128, indentation [Cillian de Róiste]
- Tidy up some botched merges [Cillian de Róiste]
- make last 'pseudotask' in 'archived' milestone green again, when case is archived [Cillian de Róiste]
- allow custom portal_type and throw less errors [Cillian de Róiste]
- extend create case script to also configure the workflow [Cillian de Róiste]
- make it possible to show groups in user-pickers that don't have a title, fixes  #13460 WARNING: this is a branch only in branch ikath, since the underlying code seems to have changed in master! But I want to get this bugfix out NOW and not after the branches have been consolidated [Cillian de Róiste]
- never have a None text [Cillian de Róiste]
- UserAndGroups picker: search groups by id [Cillian de Róiste]
- Events: include groups in the invitee picker [Cillian de Róiste]
- fix filtering users to make sure we always return membrane users and have no dupes [Cillian de Róiste]
- pi_api: add a function to return a set of users from userids and groupids [Cillian de Róiste]
- Merge pull request #36 from quaive/32-search-ui [Guido Stevens]
- Merge pull request #52 from quaive/image-previews-class-fix [Guido Stevens]
- implement Image previews class fix by @cornae in commit 0f31a22 [Alexander Pilz]
- Fix issue with autoload [Alessandro Pisa]
- remove leftover from previous implementation [Alessandro Pisa]
- Comment out review_state badge, it has to be replaced with the archived one [Alessandro Pisa]
- Comment out facetes numbers [Alessandro Pisa]
- Fix reset button not showing [Alessandro Pisa]
- Update user profile robot tests for the new design [Cillian de Róiste]
- Do not diplay facets headers if facet category has no items [Alessandro Pisa]
- Removed search options (postponed in #43) [Alessandro Pisa]
- Update the search UI to match prototype [Alessandro Pisa]
- Ignore virtualenv wheels [Alessandro Pisa]
- Merge pull request #42 from quaive/41_tests-transaction-clean [Philip Bauer]
- Missed a rename [Guido A.J. Stevens]
- Move anything that smells like a functional test onto a functional layer. [Guido A.J. Stevens]
- Merge pull request #38 from quaive/37-search-testfixture-cleanup [Philip Bauer]
- fix original typo, also [Guido A.J. Stevens]
- Update the theme [Cillian de Róiste]
- Merge branch 'master' into avatar-upload [Cillian de Róiste]
- Add robot tests for changing the user avatar [Cillian de Róiste]
- test isolation workarounds should not be needed anymore [Guido A.J. Stevens]
- Fold search.py into utilities.py and rename that to solr_search.py. [Guido A.J. Stevens]
- Move nearly all tests to proper functional fixtures [Guido A.J. Stevens]
- Rename search test classes and base module for readability. [Guido A.J. Stevens]
- No need to monkey a class method on self [Guido A.J. Stevens]
- also add the upload to the profile image pen [Cillian de Róiste]
- Absolute imports tell us where we are [Guido A.J. Stevens]
- What's the use of a superclass with only one subclass? [Guido A.J. Stevens]
- remove zcatalog IntegrationTestMixin [Guido A.J. Stevens]
- absolute import communicate where we are [Guido A.J. Stevens]
- remove solr IntegrationTestMixin [Guido A.J. Stevens]
- bump zc.buildout to get basic auth support [Guido A.J. Stevens]
- Provide "nuke from high orbit" Makefile target: all-clean [Guido A.J. Stevens]
- Back to development: 1.1.0a1 [Guido A.J. Stevens]
- store the new avatar directly in the user profile. Do not save it using the changeMemberPortrait() method of the membership tool first. [Claudio Kirchhoff]
- re-add import avatar view. [Claudio Kirchhoff]
- remove unused commit [Claudio Kirchhoff]
- Move and adapt code required to upload avatars from import-avatars view to personal_tools view. Pin version of plone.scale to 1.4.1 (fixes bug which breaks uploading avatars) [Claudio Kirchhoff]
- missing new files [Alexander Pilz]
- initial work to allow uploading avatar image [Alexander Pilz]


1.1.0a1 (2016-04-12)
--------------------

- Merge pull request #39 from quaive/avatar-upload [Guido Stevens]
- Merge pull request #36 from quaive/32-search-ui [Guido Stevens]
- Merge pull request #52 from quaive/image-previews-class-fix [Guido Stevens]
- implement Image previews class fix by @cornae in commit 0f31a22 [Alexander Pilz]
- Fix issue with autoload [Alessandro Pisa]
- remove leftover from previous implementation [Alessandro Pisa]
- Comment out review_state badge, it has to be replaced with the archived one [Alessandro Pisa]
- Comment out facetes numbers [Alessandro Pisa]
- Fix reset button not showing [Alessandro Pisa]
- Update user profile robot tests for the new design [Cillian de Róiste]
- Do not diplay facets headers if facet category has no items [Alessandro Pisa]
- Removed search options (postponed in #43) [Alessandro Pisa]
- Update the search UI to match prototype [Alessandro Pisa]
- Ignore virtualenv wheels [Alessandro Pisa]
- Merge pull request #42 from quaive/41_tests-transaction-clean [Philip Bauer]
- Missed a rename [Guido A.J. Stevens]
- Move anything that smells like a functional test onto a functional layer. [Guido A.J. Stevens]
- Merge pull request #38 from quaive/37-search-testfixture-cleanup [Philip Bauer]
- fix original typo, also [Guido A.J. Stevens]
- Update the theme [Cillian de Róiste]
- Merge branch 'master' into avatar-upload [Cillian de Róiste]
- Add robot tests for changing the user avatar [Cillian de Róiste]
- test isolation workarounds should not be needed anymore [Guido A.J. Stevens]
- Fold search.py into utilities.py and rename that to solr_search.py. [Guido A.J. Stevens]
- Move nearly all tests to proper functional fixtures [Guido A.J. Stevens]
- Rename search test classes and base module for readability. [Guido A.J. Stevens]
- No need to monkey a class method on self [Guido A.J. Stevens]
- also add the upload to the profile image pen [Cillian de Róiste]
- Absolute imports tell us where we are [Guido A.J. Stevens]
- What's the use of a superclass with only one subclass? [Guido A.J. Stevens]
- remove zcatalog IntegrationTestMixin [Guido A.J. Stevens]
- absolute import communicate where we are [Guido A.J. Stevens]
- remove solr IntegrationTestMixin [Guido A.J. Stevens]
- bump zc.buildout to get basic auth support [Guido A.J. Stevens]
- Provide "nuke from high orbit" Makefile target: all-clean [Guido A.J. Stevens]
- Back to development: 1.1.0a1 [Guido A.J. Stevens]
- store the new avatar directly in the user profile. Do not save it using the changeMemberPortrait() method of the membership tool first. [Claudio Kirchhoff]
- re-add import avatar view. [Claudio Kirchhoff]
- remove unused commit [Claudio Kirchhoff]
- Move and adapt code required to upload avatars from import-avatars view to personal_tools view. Pin version of plone.scale to 1.4.1 (fixes bug which breaks uploading avatars) [Claudio Kirchhoff]
- missing new files [Alexander Pilz]
- initial work to allow uploading avatar image [Alexander Pilz]

1.1.0a0 (2016-04-06)
--------------------

- Prepare intermediate private release 1.1.0a0
- Merge remote-tracking branch 'quaive/master' [Guido A.J. Stevens]
- Merge branch 'release-1.0.x' [Guido A.J. Stevens]
- Merge pull request #35 from quaive/34-fix-unindexing-problem [Guido Stevens]
- overwrite default indexer for getObjPositionInParent, so that we can add a try-except block. Reason: during unindexing (in the solr code), fetching the position of an obj that is in the process of being deleted will fail, see #34 [Wolfgang Thomas]
- Merge pull request #31 from quaive/add-csrf-token-to-paste [Guido Stevens]
- Due to the recent change how the bulk actions work, the csrf token was not passed anymore and thus the paste failed. This readds the token [Alexander Pilz]
- Merge pull request #30 from quaive/translation-support [Guido Stevens]
- fix changed order [Alexander Pilz]
- translation fixes [Alexander Pilz]
- Merge pull request #28 from quaive/library-fix-order [Guido Stevens]
- Merge branch 'master' into library-fix-order In the conflicted src/ploneintranet/docconv/client/handlers.py I picked the version from master, since its effect is equivalent to my solution [Wolfgang Thomas]
- Merge pull request #26 from quaive/ikath-docconv [Guido Stevens]
- bump version [Guido A.J. Stevens]
- When the library content is displayed, the order of the items must be kept [Wolfgang Thomas]
- If items get re-arranged inside the library, make sure the object position in parent gets reindexed [Wolfgang Thomas]
- We also need to index getObjPositionInParent in solr [Wolfgang Thomas]
- In the current version of plone.app.content (3.0.20) there's a bug in the code that creates an `ordering` object: the acquisition context gets removed. This means 1) in our event handler content_edited_in_workspace (docconv), the obj does not have a REQUEST object, but only a string 2) other event handlers that act on IContainerModifiedEvent (sent out after content gets rearranged) cannot perform any operations that require acquisition context I have submitted a PR for this bug: https://github.com/plone/plone.app.content/pull/81 Until it gets merged, with a new release of p.a.content, we need this monkey patch. Therefore, I place all patch-related changes into this single commit, so that we can easily revert it later. [Wolfgang Thomas]
- in testing we load the async layer, but in the profile we don't. I think we should [Alexander Pilz]
- run async tests in async mode on gitlab [Guido A.J. Stevens]
- Don't just skip the test [Guido A.J. Stevens]
- Merge pull request #27 from quaive/fix-path-depth [Guido Stevens]
- Revert "move code that uses path_depth into block dealing with path" [Guido A.J. Stevens]
- move code that uses path_depth into block dealing with path [Wolfgang Thomas]
- Fix library view: for computing the current sections and their children, only look one level deep, instead of listing all contents ad infinitum [Wolfgang Thomas]
- Fix computation of path_depth. We DO NOT want to count the length of the path string, we want to count the number of path elements (including the root). Example: /Plone/library has a depth of 3 [Wolfgang Thomas]
- deactivate test until we figure out how to run the tests with ASYNC_ENABLED==True [Alexander Pilz]
- add the async generation code to pi.async [Alexander Pilz]
- Translation statements [Alexander Pilz]
- restrain image size in stream to a scale [Alexander Pilz]
- cleanup package dependencies [Alexander Pilz]
- also copy icons [Alexander Pilz]
- fix test. If we have an image, use the scale image url, not the docconv one [Alexander Pilz]
- Don't convert attachments async just yet, we can't do that properly atm [Alexander Pilz]
- api support for docconv methods [Alexander Pilz]
- Prepare to be able to make docconv asynchronously [Alexander Pilz]
- fix build icon [Alexander Pilz]
- Merge pull request #22 from quaive/gitlab-ci [Alexander Pilz]
- Schedule longest-running partial job first for fastest total-job completion in case of runner contention. [Guido A.J. Stevens]
- Traced Heisenbugs to test leakage via solr. We don't have proper solr teardown now AND mixing solr and non-solr layers breaks. Hence disabling solr robot tests until there's a better solution. [Guido A.J. Stevens]
- re-use buildout cache for gyst [Guido A.J. Stevens]
- streamline gitlab run [Guido A.J. Stevens]
- no celery without scripts [Guido A.J. Stevens]
- no need for HOME with modern docker [Guido A.J. Stevens]
- oops we do need to build solr [Guido A.J. Stevens]
- optimize ci runner [Guido A.J. Stevens]
- Try to work around pat-select and robot flakiness. This ought to be worse not better, go figure. [Guido A.J. Stevens]
- skip coverage [Guido A.J. Stevens]
- run two partial runners in parallel [Guido A.J. Stevens]
- gitlab chokes on bracket notation for test [Guido A.J. Stevens]
- add coverage output to gitlab-ci runs [Guido A.J. Stevens]
- adjust jenkins.cfg to changes in base.cfg [Guido A.J. Stevens]
- enable full proto dev stack in docker [Guido A.J. Stevens]
- async fixed. run full test suite now [Guido A.J. Stevens]
- avoid non-zero exit code on test run [Guido A.J. Stevens]
- plone.async does not exist [Guido A.J. Stevens]
- properly set environment var [Guido A.J. Stevens]
- allow gitlab-ci to start celery test worker as root (does not impact outside of tests, and only applies when tests are run as root) [Guido A.J. Stevens]
- introduce hanging process to enable inspection [Guido A.J. Stevens]
- celery tracing [Guido A.J. Stevens]
- add debugging on celery setup [Guido A.J. Stevens]
- oOo.. [Guido A.J. Stevens]
- UTF-8 fixes, zoom in on async failure [Guido A.J. Stevens]
- add static code analysis [Guido A.J. Stevens]
- ssh agent not needed [Guido A.J. Stevens]
- Enable gitlab-ci integration [Guido A.J. Stevens]
- Make base.cfg and solr.cfg suitable as mixins for client projects [Guido A.J. Stevens]
- re-use quaive/ploneintranet-base image [Guido A.J. Stevens]
- Merge pull request #20 from quaive/solr_error_logging [Alexander Pilz]
- Merge pull request #21 from quaive/fix-diazo-template-for-workspaces [Alexander Pilz]
- Merge pull request #24 from quaive/solr-testfixture-fixes [Alexander Pilz]
- add solr purge also to test setup, in case the previous teardown got borked [Guido A.J. Stevens]
- Merge pull request #23 from quaive/fix-catalog-fix-for-divisions [Guido Stevens]
- have custom indexers to prevent indexing is_division and division on objects within a workspace. Without this, content items would be shown as divisions after the catalog refactoring [Alexander Pilz]
- this change requires an update of the diazo theme [Alexander Pilz]
- Use the empty-workspace template so that the inline styles from proto are properly included [Alexander Pilz]
- Merge pull request #18 from quaive/bulk-actions [Wolfgang Thomas]
- verbose query error logging [Guido A.J. Stevens]
- Bulk Actions: update the JavaScript bundle [Cillian de Róiste]
- Merge pull request #9 from quaive/library_tag_permissions [Wolfgang Thomas]
- Reduce col width from 100 to 79 [Cillian de Róiste]
- Update the bundle [Cillian de Róiste]
- re-ran i18n sync and added 1 translation in DE [Wolfgang Thomas]
- Merge pull request #16 from quaive/feature/13270-hide-external-editor-button-if-not-permitted [Wolfgang Thomas]
- re-enable the commented out override, which the workspace tests rely on [Wolfgang Thomas]
- Merge branch 'master' into feature/13270-hide-external-editor-button-if-not-permitted [Wolfgang Thomas]
- Add missing title attribute and its i18n statement [Wolfgang Thomas]
- Merge pull request #17 from quaive/solr-sync [Wolfgang Thomas]
- Fix robot tests for new bulk actions implementation [Cillian de Róiste]
- Add cut, copy and paste bulk actions [Cillian de Róiste]
- silence maintenance log in tests [Guido A.J. Stevens]
- move @@solr-maintenance into ./solr and bring under test [Guido A.J. Stevens]
- Fix flake8 errors [Guido A.J. Stevens]
- A port of the wonderful maintenance code of collective.solr, working with scorched [Guido A.J. Stevens]
- Work around weird robot test isolation problem. [Guido A.J. Stevens]
- Merge pull request #12 from quaive/division-support [Wolfgang Thomas]
- Merge pull request #19 from quaive/async_celery_fixture_robust [Wolfgang Thomas]
- Wait until celery is up and running before executing tests [Guido A.J. Stevens]
- Add bulk send functionality [Cillian de Róiste]
- Refactor division test to avoid solr dependency. (And since it does transaction.commit() its a functional testcase) [Guido A.J. Stevens]
- Fix solr-based suite testcontent fixture. Now also the library tag view test works. NB there is no proper solr rollback so use only for readonly tests. [Guido A.J. Stevens]
- remove solr testing fixture from this PR, not needed. Instead they will be merged as part of library fixes #9 [Guido A.J. Stevens]
- Replace unorthodox solr dependency with zcatalog implementation. [Guido A.J. Stevens]
- Add robot coverage on workspace division grouping [Guido A.J. Stevens]
- Use pat-shopping-cart for bulk deletion [Cillian de Róiste]
- no need to set too tight individual timeouts in the robot tests [Wolfgang Thomas]
- remove empty line that I added by accident [Claudio Kirchhoff]
- change i18n domain from ploneintranet.workspace back to ploneintranet [Claudio Kirchhoff]
- Only display the "open in external editor" icon if user has permission to edit [Claudio Kirchhoff]
- Merge pull request #13 from quaive/set-library-contenttypes-as-contains_objects [Alexander Pilz]
- Merge branch 'master' into division-support [Alexander Pilz]
- Merge pull request #14 from quaive/switch-prototype-to-quaive [Alexander Pilz]
- Create registry record ploneintranet.workspace.externaleditor_always_activated, set to "False" by default. Override isActivated...() methods of the externalEditorEnabled view so that they always return "True" if the value of said record is "True" [Claudio Kirchhoff]
- no need for the sphinx egg anymore [Alexander Pilz]
- Comment out unused override [Claudio Kirchhoff]
- Switch the prototype repo to quaive [Cillian de Róiste]
- set library contenttypes as contains_objects for tinyMCE [Claudio Kirchhoff]
- When adding workspaces, a user can assign it to a division. He  can select   the divisions he is allowed to see. [Alexander Pilz]
- bump to trigger jenkins [Alexander Pilz]
- also add the new fields to zcatalog as tests still rely on that [Alexander Pilz]
- add a space to retrigger building solr config [Alexander Pilz]
- Fix issue with sidebar saving [Alexander Pilz]
- workspace overview grouping support [Alexander Pilz]
- interim commit [Alexander Pilz]
- gitignore .gem [Guido A.J. Stevens]
- add some "wait until element is visible" statements to make robot tests more robust [Wolfgang Thomas]
- When the root of the library is viewed, we have the actual object in our hands, not a search result [Wolfgang Thomas]
- use solr fixture in library robot tests (WIP testcontent incomplete) [Guido A.J. Stevens]
- generalize powersearch and use solr as catalog replacement in library - This fixes a bug where pages raised Unauthorized when their parent was not traversable - Ported all other uses of restrictedTraverse and objectValues to use solr query to prevent future bugs - This now provides a prototype for a generic catalog query replacement using solr [Guido A.J. Stevens]
- Document solr call flow and expose query logging [Guido A.J. Stevens]
- more accuracy in jenkins config output [Wolfgang Thomas]
- set ROBOTSUITE_LOGLEVEL to ERROR, in an attempt to get better readable robot_log [Wolfgang Thomas]
- Update Changelog, mainly to test the jenkins build trigger [Alexander Pilz]
- Merge pull request #11 from quaive/pr-test [Alexander Pilz]
- Merge branch 'master' into pr-test [Alexander Pilz]
- updating Changes. Mainly to test PR request builder [Alexander Pilz]

1.0.0 (2016-02-29)
------------------

- Prepare release 1.0.0 [Guido A.J. Stevens]
- Merge pull request #7 from quaive/Plone5.0.2 [Alexander Pilz]
- build status [Alexander Pilz]
- badge [Alexander Pilz]
- Merge branch 'master' into Plone5.0.2 [Alexander Pilz]
- remove unnecessary extra login [Alexander Pilz]
- add another wait to fix test [Alexander Pilz]
- fixing the select issue also for tags [Alexander Pilz]
- more robustness for robot tests [Wolfgang Thomas]
- forgot to switch this test back to Firefox [Alexander Pilz]
- template fix to make the FF fix also apply to the stream user picker [Alexander Pilz]
- change diazo rule which would copy meta from plone into theme twice [Alexander Pilz]
- Switch back to Firefox. Chrome has issues not terminating in tests [Alexander Pilz]
- include FF fix for #209 that changed member picker behaviour [Alexander Pilz]
- Even more "wait until element is visible" statements to make robot tests more reliable [Wolfgang Thomas]
- attempt to make some robot tests even more robust [Wolfgang Thomas]
- make sure that after clicking the link to open the "Functions" menu, we wait until said menu is actually loaded before we attempt to interact with it [Wolfgang Thomas]
- Revert "Another test that uploads files" [Wolfgang Thomas]
- try to get rid of chromium test failure "path is not canonical" See https://bugs.chromium.org/p/chromedriver/issues/detail?id=261 [Wolfgang Thomas]
- Revert "Firefox for posting files" [Wolfgang Thomas]
- Another test that uploads files [Alexander Pilz]
- Firefox for posting files [Alexander Pilz]
- testfix [Alexander Pilz]
- forgot one to move to chrome [Alexander Pilz]
- move to chrome webdriver [Alexander Pilz]
- Fix robot test speed issue [Guido A.J. Stevens]
- switch to chromedriver [Guido A.J. Stevens]
- Try chromedriver [Alexander Pilz]
- Make robot tests more robust for very quick processors [Wolfgang Thomas]
- Attempt to not log warnings in jenkins [Alexander Pilz]
- Refactor the "tagging" tests to get rid of test isolaton problems [Wolfgang Thomas]
- properly close the item created notification to not hide the changed one [Alexander Pilz]
- list all test failures [Guido A.J. Stevens]
- template fixes [Alexander Pilz]
- new selenium and robot libs [Alexander Pilz]
- dedicated test away from the common 8080 for jenkins [Alexander Pilz]
- Merge pull request #10 from quaive/sidebar-fixes [Guido Stevens]
- no more quaive, long live plone intranet [Alexander Pilz]
- This fixes styling errors in the sidebar where tags breaking in two lines were cut off, the creator wasn't shown if it had no name and the folders weren't represented as in proto [Alexander Pilz]
- remove duplicate [Philip Bauer]
- bump dependencies that seem safe to update [Philip Bauer]
- add plone.versioncheck and update ignores [Philip Bauer]
- update to Plone 5.0.2 [Philip Bauer]
- Merge pull request #8 from quaive/also-regenerate-previews-in-cms [Guido Stevens]
- Also regenerate previews when file object is changed in cms [Alexander Pilz]
- Merge pull request #6 from quaive/c2q_20160212 [Alexander Pilz]
- ignore /lib/ not ./lib/ see https://github.com/ploneintranet/ploneintranet/commit/c2b46d6bb2e77ba824dea2ff53a1fa2316a131e5 [Guido A.J. Stevens]
- Merge branch 'community-master' into c2q_20160212 [Guido A.J. Stevens]
- update docker Makefile [Guido A.J. Stevens]
- Merge pull request #5 from quaive/import-avatars [Alexander Pilz]
- port avatar import utility view from ikath [Guido A.J. Stevens]
- Merge pull request #886 from ploneintranet/maurits-sort-contributors [Wolfgang Thomas]
- Sorted contributors. Keep the Matts together. :-) [Maurits van Rees]
- Nuked trailing white space from CONTRIBUTORS.rst. [Maurits van Rees]
- Merge pull request #4 from quaive/stream-following [Alessandro Pisa]
- add robot coverage on stream filtering [Guido A.J. Stevens]
- show filter menu only on dashboard (not workspace or profile streams) [Guido A.J. Stevens]
- base implementation of stream explore/following switch [Guido A.J. Stevens]
- add .dockerignore speedup and wily host fixes [Guido A.J. Stevens]
- Merge pull request #885 from ploneintranet/fix-workspace-tests-872 [Alexander Pilz]
- Fix workspace tile tests [Matthew Sital-Singh]
- Workspace tests now rely on pi.search [Matthew Sital-Singh]
- Merge pull request #871 from ploneintranet/power-search-library [Alexander Pilz]
- Merge pull request #872 from ploneintranet/solr-for-workspaces [Alexander Pilz]
- Merge pull request #877 from ploneintranet/only-update-specified-fields [Alexander Pilz]
- Merge pull request #882 from ploneintranet/search-partial-updates-workaround [Alexander Pilz]
- Workaround for scorched's lack of support for partial updates. [Matt Russell]
- fix broken test [Claudio Kirchhoff]
- fix broken test in workspace.robot [Claudio Kirchhoff]
- ignore ./lib instead of just lib [Claudio Kirchhoff]
- fix bronken tests [Claudio Kirchhoff]
- dexterity_update: only update fields in request.form [Cillian de Róiste]
- Merge pull request #865 from ploneintranet/853-comment-ordering-fix [Matthew Sital-Singh]
- Update tests as comments are rendered in reverse by default [Matthew Sital-Singh]
- also don't fetch object here [Alexander Pilz]
- Actually reindex every time, we are creating. Otherwise adding a workspace with title only would not get it indexed. [Alexander Pilz]
- don't batch on workspaces overview. We have the search here [Alexander Pilz]
- Change workspace overview to use solr [Alexander Pilz]
- Merge pull request #861 from ploneintranet/power-search [Guido Stevens]
- Sort tag views abc fixes #862. NB users may not see the sort because of the masonry layout. [Guido A.J. Stevens]
- Switch to specific keyword arguments in library search [Matthew Sital-Singh]
- Apply the tags faceting correctly [Matthew Sital-Singh]
- enable power search for library tags view WIP [Guido A.J. Stevens]
- Merge pull request #869 from ploneintranet/search-spelling-truncation-fix [Matthew Sital-Singh]
- Fixes #852. [Matt Russell]
- Consume generator and reverse reults [Ben Cole]
- Remove "reverse" argument from lonkeysortreverse [Ben Cole]
- Add missing OS-level bcrypt predependency [Guido A.J. Stevens]
- Implements request in #629 [Matt Russell]
- Merge pull request #860 from ploneintranet/848-clickable-preview-and-attachment-title [Adam Forsythe-Cheasley]
- Make preview image and attachment title clickable [Ben Cole]
- Merge pull request #813 from ploneintranet/fix-case-creation-date [Matthew Sital-Singh]
- Merge pull request #809 from ploneintranet/fix-mimetype-empty [Matthew Sital-Singh]
- Merge pull request #838 from ploneintranet/590-older-items [Matthew Sital-Singh]
- Merge pull request #821 from ploneintranet/userprofile-fixes [Alexander Pilz]
- Bio and job title are optional [Matthew Sital-Singh]
- Changed msgid [Alessandro Pisa]
- Merge pull request #834 from witekdev/master [Matthew Sital-Singh]
- Update quickstart.rst [witek]
- Map custom user edit page to the pi.theme [Matthew Sital-Singh]
- Merge pull request #830 from ploneintranet/translate-follow-button-titles [Alexander Pilz]
- Merge pull request #822 from ploneintranet/image-picker [Alexander Pilz]
- Merge pull request #826 from ploneintranet/unicode-tag-search [Alexander Pilz]
- Merge pull request #825 from ploneintranet/translate-notifications [Alexander Pilz]
- Fix title test [Alexander Pilz]
- toggle_follow: add translation for button titles [Cillian de Róiste]
- Merge branch 'master' into image-picker [Alexander Pilz]
- Fix another robot path bug due to markup update. [JC Brand]
- Merge pull request #827 from ploneintranet/remove-pat-validate [Alexander Pilz]
- Small CSS tweak to work around webkit bug. [JC Brand]
- Updated JS bundle. Completely removes pat-validate and parsley [JC Brand]
- Fix element path after markup update (due to proto). [JC Brand]
- Robot fix after markup has been changed (due to proto). [JC Brand]
- Updated JS bundle. Contains a parser fix. [JC Brand]
- Search: fix unicode tag filter [Cillian de Róiste]
- Updated bundle. Fixes inject bug. [JC Brand]
- Fix hanging indent. [JC Brand]
- Ran `make diazo` to update the static files. [JC Brand]
- Update markup to look like proto [JC Brand]
- Update markup. [JC Brand]
- Updated JS bundle [JC Brand]
- Add a new view @@panel-image-picker used by Raptor. [JC Brand]
- Update pat-raptor markup to match proto. [JC Brand]
- Translate notifications for content modification [Cillian de Róiste]
- Explicit test for password storage [Matthew Sital-Singh]
- Move global members group handling to a subscriber [Matthew Sital-Singh]
- Make sure we set passwords via the behaviour [Matthew Sital-Singh]
- Enforce bcrypt passwords (using >=1.1.0 of dexterity.membrane) [Matthew Sital-Singh]
- Merge pull request #817 from ploneintranet/event-add-form [Alexander Pilz]
- add_event.pt: use pat-validation, not pat-validate [Cillian de Róiste]
- event-add-form: update robot keywords [Cillian de Róiste]
- add_event: sync with proto, add i18nattrs, fix title validation [Cillian de Róiste]
- Case bugfix: set the creation_date to now() [Cillian de Róiste]
- make sure we never return an empty mimetype. Guessmimetype doesn't return a default [Alexander Pilz]

1.0b1 (2015-10-02)
------------------

Public beta testing release of *Venus*, our first production release cycle.
49 contributors, ~6800 commits, 835 tests, 87% test coverage.

0.1 (2015-06-01)
----------------

*Mercury* Technology Preview release.
49 contributors, 4581 commits, 520 tests, 89% test coverage.

...
