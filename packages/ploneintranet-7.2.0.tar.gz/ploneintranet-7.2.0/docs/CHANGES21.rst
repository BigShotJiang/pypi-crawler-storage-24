2.1.3 (2021-04-06)
------------------

Added:


- Emergency Services can be added in the contacts app and optionally promoted in the contacts portlet on the dashboard. (`Issue #3883 <https://github.com/quaive/ploneintranet/issues/3883>`_)
- Add "Organization" and "Website" fields to the user profile. (`Issue #3956 <https://github.com/quaive/ploneintranet/issues/3956>`_)


Changed:


- When a workspace is viewed in mobile view, all tabs (documents, events, tasks, ...) are now accessible.
- Users and groups now have a source field, editable only by administrators, that is used to identified where they come from.
  This is particularly useful for website that have external sources (e.g. Active Directory, LDAP or custom imports).
  The builtin sync machinery will not touch the users and groups that have a source that does not match. (`Issue #2368 <https://github.com/quaive/ploneintranet/issues/2368>`_)
- Provide default translations for all dashboard tile customizations, and expand the set of default available custom tiles. (`Issue #3767 <https://github.com/quaive/ploneintranet/issues/3767>`_)
- Hide special workgroup "All Intranet Users" in the contacts app, unless the extranet feature is explicitly enabled.
  Provide member and group counts on open workspaces, only for explicit members (not via hidden "All Intranet Users" membership). (`Issue #3902 <https://github.com/quaive/ploneintranet/issues/3902>`_)
- Creating events has become simpler and feels more in line with creating other types of content. In the initial form, only the essential fields are present. (`Issue #3921 <https://github.com/quaive/ploneintranet/issues/3921>`_)


Fixed:


- Fix width of the dashboard activity stream tiles (`Issue #3647 <https://github.com/quaive/ploneintranet/issues/3647>`_)
- Make the code that checks if the content has previews more robust (`Issue #3799 <https://github.com/quaive/ploneintranet/issues/3799>`_)
- Fix batching for trending news (`Issue #3848 <https://github.com/quaive/ploneintranet/issues/3848>`_)
- It is now possible to select custom views for the backend home page (`Issue #3872 <https://github.com/quaive/ploneintranet/issues/3872>`_)
- Do not throw unauthorized when (re-) generating previews on library documents you just published for a workspace.
  Since the async views do not take user input nor modify primary data, they do not need ModifyPortalContent protection. (`Issue #3934 <https://github.com/quaive/ploneintranet/issues/3934>`_)
- Fixed an error that could cause the display of the news magazine or individual news sections to break. (`Issue #3937 <https://github.com/quaive/ploneintranet/issues/3937>`_)
- Fix wrong call to urlparse (`Issue #3941 <https://github.com/quaive/ploneintranet/issues/3941>`_)
- Fix another issue with our custom require_login view (`Issue #3944 <https://github.com/quaive/ploneintranet/issues/3944>`_)
- Do not display the sections dropdown if we have only one section or if the news item parent section is not in the dropdown (this prevent unintentionally moving the news) (`Issue #3962 <https://github.com/quaive/ploneintranet/issues/3962>`_)
- The previews for posts that have more than one attachment work as expected (`Issue #3968 <https://github.com/quaive/ploneintranet/issues/3968>`_)


Technical:


- Better tracebacks from solr (`Issue #3931 <https://github.com/quaive/ploneintranet/issues/3931>`_)
- Use custom input widgets for zope.schema.URI and ploneintranet.userprofile.userprofile.Email fields with type "url" resp. "email".
  This gives us client-side browser-built-in validation.
  (`Issue #3955 <https://github.com/quaive/ploneintranet/issues/3955>`_)
- Skip solr reindex of files inside the attachment storage (`Issue #3970 <https://github.com/quaive/ploneintranet/issues/3970>`_)


Updated:


- Products.ZCatalog = 6.1.dev0
- quaive.app.absences = 2.0.0a2
- quaive.app.onlyoffice = 3.0.1


2.1.2 (2021-03-25)
------------------

Added:


- Add "Powered by Quaive" on login form. (`Issue #3901 <https://github.com/quaive/ploneintranet/issues/3901>`_)


Changed:


- ploneintranet.news: Remove "pinned" from INewsMeta behavior and use quaive.pinning behavior instead.
  Include an upgrade step for this change.
- INewsMeta behavior change: Set the marker interface ``INewsMagazineHome`` for news items with the magazine_home attribute set for performant catalog queries.
- Optimize news listing for better performance. (`Issue #3848 <https://github.com/quaive/ploneintranet/issues/3848>`_)


Fixed:


- When creating a file object based on a template, set a filenamed based on the provided title (`Issue #3334 <https://github.com/quaive/ploneintranet/issues/3334>`_)
- Fixed an issue where editing documents created from a template was actually editing the template itself (`Issue #3857 <https://github.com/quaive/ploneintranet/issues/3857>`_)
- Make our custom require_login form more robust (`Issue #3881 <https://github.com/quaive/ploneintranet/issues/3881>`_)
- Fixed the URL generation for comment notifications (`Issue #3893 <https://github.com/quaive/ploneintranet/issues/3893>`_)
- Don't try to sync users when logging in into Barceloneta (`Issue #3896 <https://github.com/quaive/ploneintranet/issues/3896>`_)
- Remove spurious spaces when importing users from a CSV file. (`Issue #3908 <https://github.com/quaive/ploneintranet/issues/3908>`_)
- Fix error in Dutch translation. (`Issue #3915 <https://github.com/quaive/ploneintranet/issues/3915>`_)
- Fixed error when switching workflow state to private. (`Issue #3925 <https://github.com/quaive/ploneintranet/issues/3925>`_)


Technical:


- Port from plone.app.layout code that has been deprecated
  because Plone now marks the current selected tab client side

  See:

    - https://github.com/plone/plone.app.layout/pull/231
    - https://github.com/plone/plone.app.layout/pull/240 (`Issue #0000 <https://github.com/quaive/ploneintranet/issues/0000>`_)

- Changed unused pinning implementation. It is now a behavior and it is used for the news.
- Split out generic pinning functionality from ploneintranet.workspace.browser.pinning and move into ploneintranet.layout.pinning.
- The async-status view is more robust and secure (`Issue #3880 <https://github.com/quaive/ploneintranet/issues/3880>`_)
- Avoid breakage of @@pas-graph-init when Files are present in /templates (`Issue #3912 <https://github.com/quaive/ploneintranet/issues/3912>`_)
- Use robotsuite provided test retry mechanism, instead of our own.
  See https://github.com/collective/robotsuite/blob/master/src/robotsuite/__init__.py (`Issue #3924 <https://github.com/quaive/ploneintranet/issues/3924>`_)


Updated:


- Products.MemcachedManager = 1.2.1


2.1.1 (2021-03-15)
------------------

Changed:


- In the activity stream, videos and audio entries now also show tite and description (if available).
- Timezones are now displayed with the important part first.


Fixed:


- When you want to add an event from the central calendar, the selection of the destination calendar is now easier to understand. (`Issue #3355 <https://github.com/quaive/ploneintranet/issues/3355>`_)
- Apply custom dashboard configuration only on custom dashboard, not on default dashboard views. (`Issue #3886 <https://github.com/quaive/ploneintranet/issues/3886>`_)
- Fix an error that prevented sending notifications when the hostname is overly long. (`Issue #3889 <https://github.com/quaive/ploneintranet/issues/3889>`_)


Updated:


- quaive.resources.ploneintranet = 7.0.2, including Rixensart and
  proto update.


2.1.0 (2021-03-10)
------------------

Added:


- There is now a list view in the calendar app
- Added the option to start an open office document from scratch (`Issue #3334 <https://github.com/quaive/ploneintranet/issues/3334>`_)


Changed:


- During the time that a page view is being generated for a document that was just uploaded, refresh the page periodically until the page views are there. (`Issue #3441 <https://github.com/quaive/ploneintranet/issues/3441>`_)
- If a file gets uploaded that will never be converted to a preview, do not pretend it will be converted and just show a plain file icon instead of a spinner. (`Issue #3864 <https://github.com/quaive/ploneintranet/issues/3864>`_)
- The "verb" of posts in the activity stream (created / published / posted) now is a link that allows accessing the content inside its own context. (`Issue #3867 <https://github.com/quaive/ploneintranet/issues/3867>`_)
- In the activity stream, posted audio files are now directly accessible via a player. (`Issue #3869 <https://github.com/quaive/ploneintranet/issues/3869>`_)


Fixed:


- When a page view for an uploaded document cannot be generated, show a message that informs the user and offers a download link instead. (`Issue #3441 <https://github.com/quaive/ploneintranet/issues/3441>`_)
- The dashboard respects again the configured width of the portlets (`Issue #3456 <https://github.com/quaive/ploneintranet/issues/3456>`_)
- Do not break when the user tries to paste from the workspace sidebar but has an empty clipboard (`Issue #3759 <https://github.com/quaive/ploneintranet/issues/3759>`_)
- It is not possible anymore to remove files and images from the File and Image content types (`Issue #3838 <https://github.com/quaive/ploneintranet/issues/3838>`_)
- When we are not inside the app, load the full sidebar (`Issue #3861 <https://github.com/quaive/ploneintranet/issues/3861>`_)


Updated:


- Plone = 5.2.4
- Products.membrane = 5.0.1
- quaive.app.audit = 2.1.1
- quaive.app.onlyoffice = 3.0.0
- quaive.resources.ploneintranet = 7.0.1


2.1.0b8 (2021-02-24)
--------------------

Fixed:


- Make sure that also 1 column activity streams get a proper CSS ID to fix their styling. (`Issue #3830 <https://github.com/quaive/ploneintranet/issues/3830>`_)
- Fix the purge flag for the maintainance view @@generate-pdf-for-contents (`Issue #2748 <https://github.com/quaive/ploneintranet/issues/2748>`_)
- When the News Publisher is used in tablet mode, the body view of a news item now properly un-blurs again. (`Issue #3849 <https://github.com/quaive/ploneintranet/issues/3849>`_)


Technical:


- Remove deprecation warnings


Updated:


- The link on the Video Conference page that offers more info on troubleshooting now opens directly in the Help app. (`Issue #3599 <https://github.com/quaive/ploneintranet/issues/3599>`_)
- Update French translations provided by IMIO (`Issue #3851 <https://github.com/quaive/ploneintranet/issues/3851>`_)


2.1.0b7 (2021-02-18)
--------------------

Added:


- Implement some urgent email notifications (`Issue #3721 <https://github.com/quaive/ploneintranet/issues/3721>`_)
- Allow definition users who are allowed see and use the HTML source button in the redactor text editor.
  This is done by setting the registry key ``ploneintranet.layout.editor_html_allowed_users`` and adding the user names in a tuple.
  Also unified the redactor configuration in one central, configurable method in ``@@proto/redactor_options``. (`Issue #3784 <https://github.com/quaive/ploneintranet/issues/3784>`_)


Changed:


- Remove setup handlers fixes for Plone 5.1
- Remove patches for obsolete package versions
- Remove Plone 5.1 jbot overrides and Plone 5.1 templates
- Remove code adaptaptions for Plone 5.1
- Remove last traces of Products.CMFNotification (`Issue #3787 <https://github.com/quaive/ploneintranet/issues/3787>`_)
- 404 view: Disable search_for_similar, it is expensive and is not currently being displayed (`Issue #3810 <https://github.com/quaive/ploneintranet/issues/3810>`_)
- When creating a workspace with a superspace already set, the superspace is marked as modified and moves to the top of the "most active" sorting. (`Issue #3817 <https://github.com/quaive/ploneintranet/issues/3817>`_)
- Allow to scroll to bottom for documents with many comments.
  (`Issue #3835 <https://github.com/quaive/ploneintranet/issues/3835>`_)


Fixed:


- Do not break when there is no file uploaded (`Issue #1980 <https://github.com/quaive/ploneintranet/issues/1980>`_)
- Prevent possible unicode errors in Python 2.7 (`Issue #3362 <https://github.com/quaive/ploneintranet/issues/3362>`_)
- Fixes an error happening when the user can search for a case but has actually no view permission. (`Issue #3791 <https://github.com/quaive/ploneintranet/issues/3791>`_)
- Do not use ``::element`` selector modifier from pat-tooltip and align tags and mentions in activity stream to prototype.
  The undocumented ``::element`` selector modifier was removed for pat-tooltip in Patternslib in https://github.com/Patternslib/Patterns/pull/787 (`Issue #3796 <https://github.com/quaive/ploneintranet/issues/3796>`_)
- Fix an issue with view lookups for notifications and preview during test content setup. (`Issue #3806 <https://github.com/quaive/ploneintranet/issues/3806>`_)
- When the user enters data into the location field of an event, they immediately get feedback about the address/location that Google Maps finds based on the data entered. (`Issue #3822 <https://github.com/quaive/ploneintranet/issues/3822>`_)
- Fixed an issue in the advanced search results pagination (`Issue #3840 <https://github.com/quaive/ploneintranet/issues/3840>`_)
- The instance does not hang when checking a linked URL that causes a timeout (`Issue #3842 <https://github.com/quaive/ploneintranet/issues/3842>`_)
- The calendar app now supports browsing to events and back to the calendar overview on mobile devices. (`Issue #3808 <https://github.com/quaive/ploneintranet/issues/3808>`_)


Technical:


- Work around an encoding issue in zope.sendmail in Python 2.7 when MailQueue is used
- Remove deprecation warnings
- Turn email notifications sending on/off via registry record
  `ploneintranet.notifications.email.enabled` (`Issue #3721 <https://github.com/quaive/ploneintranet/issues/3721>`_)
- The userprofile_content_workflow now also handles the "Access contents permission" (`Issue #3797 <https://github.com/quaive/ploneintranet/issues/3797>`_)
- Ignore sending mail notifications when recipient is unknown.
  Fixes a problem where a notification to the Zope admin user failed to be sent due to missing email address. (`Issue #3836 <https://github.com/quaive/ploneintranet/issues/3836>`_)


Updated:


- Updated quaive.app.onlyoffice to 2.2.0
- Updated quaive.app.legal to 1.1.3
- Updated pas.plugins.ldap to version 1.8.0
- Upgrade Products.membrane = 5.0.0
- Upgrade slc.outdated = 1.3.2
- Upgrade collective.workspace = 3.0.0
- Updated ftw.upgrade to 3.0.4
- Update quaive.resources.ploneintranet to 6.2.8.


2.1.0b6 (2021-01-14)
--------------------

Changed:


- The editing toolbar on workspace documents, events and news items has been updated to gain more space for the important elements. (`Issue #3747 <https://github.com/quaive/ploneintranet/issues/3747>`_)
- When memcached is reachable, add automatically a cache for the acl_users folder (`Issue #3766 <https://github.com/quaive/ploneintranet/issues/3766>`_)


Fixed:


- Fix styling issue with external links. (`Issue #3755 <https://github.com/quaive/ploneintranet/issues/3755>`_)
- Regenerate previews also for PDF files that were not properly rendered before, fixes #3760. (`Issue #3760 <https://github.com/quaive/ploneintranet/issues/3760>`_)


Updated:


- Updated all Dutch translation strings. (`Issue #3740 <https://github.com/quaive/ploneintranet/issues/3740>`_)
- Update quaive.resources.ploneintranet to 6.2.5 (`Issue #3778 <https://github.com/quaive/ploneintranet/issues/3778>`_)


2.1.0b5 (2020-12-09)
--------------------

Changed:


- Shorten labels in "group-by" dropdown of workspaces (`Issue #3743 <https://github.com/quaive/ploneintranet/issues/3743>`_)


Fixed:


- When searching for a workspace in the workspaces overview, also find matches on tags. (`Issue #3727 <https://github.com/quaive/ploneintranet/issues/3727>`_)
- Fix unauthorized redirection loop that was triggered when viewing a document in a library, that was published from a workspace original that the viewer is not authorized to see. Also, if the viewer has editing permissions on the library copy but not the workspace original, point the edit button to the library copy. (`Issue #3733 <https://github.com/quaive/ploneintranet/issues/3733>`_)


Technical:


- Fix typo in the cookie cleaning code and add a test (`Issue #3710 <https://github.com/quaive/ploneintranet/issues/3710>`_)
- Upgrade black from 19.3b0 to 20.8b1. You should reinstall your pre-commit hook: `make .git/hooks/pre-commit`. Fixes #3737. (`Issue #3737 <https://github.com/quaive/ploneintranet/issues/3737>`_)


2.1.0b4 (2020-11-30)
--------------------

Changed:


- The Edit link of a document in the library that was published via a workspace now links to the document in that workspace, instead of the barceloneta view of the library document. (`Issue #3252 <https://github.com/quaive/ploneintranet/issues/3252>`_)
- If a document inside a workspace has a copy in the library, and the original document in the workspace gets updated, the user now sees a warning about this. If the user has the required permission, they can directly update the copy in the library. (`Issue #3263 <https://github.com/quaive/ploneintranet/issues/3263>`_)
- It is now possible to publish to library folders that lie deeper within the structure of the library. (`Issue #3318 <https://github.com/quaive/ploneintranet/issues/3318>`_)
- Make it easier to find central calendars in the calendar app: they now come before the workspace calendars. (`Issue #3674 <https://github.com/quaive/ploneintranet/issues/3674>`_)
- The "Until" field of an event is automatically updated if the "From" field is set to a date later in time. (`Issue #3693 <https://github.com/quaive/ploneintranet/issues/3693>`_)
- Event view: put "All day event" under the From-Until
- News editor: move cogwheel for editing the frontpage to sidebar

Fixed:


- Limit descriptions of news articles to 400 characters. This should prevent that users accidentally place the complete text of a news article into the description, instead of the body. (`Issue #3672 <https://github.com/quaive/ploneintranet/issues/3672>`_)
- Simplify the delete modal (that opens when you click the trash can), and use the new modal style. (`Issue #3676 <https://github.com/quaive/ploneintranet/issues/3676>`_)
- When using the workspaces "group by tag" view, show tagged workspaces under their proper tags, even when they are contained in a superspace.
  Similarly, show workspaces in "group by division" under their proper division, even when they are contained in a superspace. (`Issue #3705 <https://github.com/quaive/ploneintranet/issues/3705>`_)
- Prevent the editing of library items from breaking when the portal catalog is not in a good shape. (`Issue #3715 <https://github.com/quaive/ploneintranet/issues/3715>`_)
- Fixed error when viewing profile of a user who is a member in many workspaces. (`Issue #3717 <https://github.com/quaive/ploneintranet/issues/3717>`_)
- The sidebar is now shown correctly when opening a bookmarked document from the dashboard bookmarks portlet. (`Issue #3989 <https://github.com/quaive/ploneintranet/issues/3989>`_)
- Fix display issues on calendar and todo app


Technical:


- Changed Swiss German to High German for some strings.
- Added the three types of open graph data with dynamic paths depending on the brand.
- Turn the onlyoffice edit icon into a button that clearly says "Edit" so that users can see that they can edit an oo document.
- Provide a python3.8 docker based development environment (`Issue #3692 <https://github.com/quaive/ploneintranet/issues/3692>`_)
- Improve buildout toolchain.
- Fix lorem ipsum text (`Issue #3709 <https://github.com/quaive/ploneintranet/issues/3709>`_)
- Prevent issues with asynchronous jobs happening when the __cp cookie is set (`Issue #3710 <https://github.com/quaive/ploneintranet/issues/3710>`_)


Updated:


- Use Plone 5.2.3 (`Issue #3460 <https://github.com/quaive/ploneintranet/issues/3460>`_)
- Updated quaive.resources.ploneintranet to 6.2.3
- Updated quaive.app.onlyoffice to 2.1.3
- Updated quaive.app.absences to 1.3.2
- Updated dexterity.membrane to 3.0.0a2


2.1.0b3 (2020-10-28)
--------------------

Changed:


- Changed the way portlets are loaded in the dashboard to have less flickering (`Issue #3456 <https://github.com/quaive/ploneintranet/issues/3456>`_)
- On the workspaces overview and on individual workspaces, we expose the tags as classes. This allows for tag-based styling. (`Issue #3645 <https://github.com/quaive/ploneintranet/issues/3645>`_)
- More efficient use of vertical space for overview pages of large libraries (`Issue #3561 <https://github.com/quaive/ploneintranet/issues/3561>`_)


Fixed:


- When recovering a document from the trash folder, also recover its trashed parents (if they exist) (`Issue #1505 <https://github.com/quaive/ploneintranet/issues/1505>`_)
- Fixed a bug where a document that was published to the library could lead to a broken view inside the workspace for some users. (`Issue #3649 <https://github.com/quaive/ploneintranet/issues/3649>`_)
- Library sections that contain files that have no content_type do not throw an error anymore (`Issue #3651 <https://github.com/quaive/ploneintranet/issues/3651>`_)


Technical:


- Fix writing messages to the response object (`Issue #0000 <https://github.com/quaive/ploneintranet/issues/0000>`_)
- Added a registry record that can be used to remap the asynchronous requests to a different URL (`Issue #283 <https://github.com/quaive/ploneintranet/issues/283>`_)


Updated:


- Backported plone.app.z3cform 3.2.2
- Update quaive.app.absences to 1.3.1
- Update quaive.app.classifieds to 1.0.3
- Update quaive.app.milestones to 2.0.5
- Integrate updated calendar library and support navigating through the whole event archive, not only 30 days back.
- Upgrade to latest quaive.resources.ploneintranet 6.2 (`Issue #3627 <https://github.com/quaive/ploneintranet/issues/3627>`_) which includes:
  - Updated styles,
  - Latest fullcalendar 5.3.2.
  - Lazy loading for external libraries via dynamic imports.
  - Polyfills loader which only loads the polyfills for Internet Explorer.
  - Session refresh JS from plone.session.
  - Redactor 3.4.4 and pat-redactor fixes.


2.1.0b2 (2020-10-14)
--------------------

Added:


- Added options menu ("...") to workspace calendar. Allows subscribing on a device. (`Issue #3630 <https://github.com/quaive/ploneintranet/issues/3630>`_)


Changed:


- Library folder pages were redesigned to be more space efficient and more mobile/tablet friendly. (`Issue #3634 <https://github.com/quaive/ploneintranet/issues/3634>`_)
- Workspace documents sidebar: Increased pat-upload timeout (`Issue #3640 <https://github.com/quaive/ploneintranet/issues/3640>`_)


Fixed:


- Fix the migration for the new field that handles the maintainers in news sections (`Issue #3553 <https://github.com/quaive/ploneintranet/issues/3553>`_)
- Fixed a problem happening with solr reindexing on Python 2.7 (`Issue #3635 <https://github.com/quaive/ploneintranet/issues/3635>`_)
- Clean up duplicate behaviors (`Issue #3642 <https://github.com/quaive/ploneintranet/issues/3642>`_)


Updated:


- Backport plone.dexterity 2.10.0 to make it possible to use the external editor with wsgi
- Updated ftw.upgrade to 3.0.3 (`Issue #3419 <https://github.com/quaive/ploneintranet/issues/3419>`_)
- Upgrade quaive.resources.ploneintranet to 6.1.1 (`Issue #3616 <https://github.com/quaive/ploneintranet/issues/3616>`_)


2.1.0b1 (2020-10-07)
--------------------

Changed:


- Library content view is now more content-centric with less disturbing elements, while jumping between pages is as easy as before. Improved mobile view. (`Issue #6323 <https://github.com/quaive/ploneintranet/issues/6323>`_)


Fixed:


- Fix a permission issue happening when calling webdav methods (`Issue #2078 <https://github.com/quaive/ploneintranet/issues/2078>`_)


Technical:


- Aligned the readonly view of events with proto, there were a number of fields that make no sense showing in disabled mode. (`Issue #0000 <https://github.com/quaive/ploneintranet/issues/0000>`_)


2.1.0a6 (2020-10-01)
--------------------

Changed:


- The event portlet links the events in the calendar app.
  This fixes some possible security issues with events in workspaces that are not accessible to a user that are shared to a central calendar that is accessible to the user.
  (`Issue #3307 <https://github.com/quaive/ploneintranet/issues/3307>`_)
- Quaive now uses larger images scales that are suitable for today's displays and devices. (`Issue #3475 <https://github.com/quaive/ploneintranet/issues/3475>`_)


Fixed:


- Properly implement tab rendering for the Administrator tool app.
  In vanilla Quaive it has (for the moment) just one tab, so the navigation is not rendered at all.
  But we want to allow extensions to be able to add more tabs. (`Issue #1277 <https://github.com/quaive/ploneintranet/issues/1277>`_)
- Add more alias for the obsolete plone.app.ldap package that might be removed improperly (`Issue #3568 <https://github.com/quaive/ploneintranet/issues/3568>`_)
- Events that are exported via ical to Google Calendar now contain the URL pointing to the event. (`Issue #3590 <https://github.com/quaive/ploneintranet/issues/3590>`_)


Technical:


- The ``personal-menu.html`` view is now rendered as a bare view without the ploneintranet border and without diazo processing. (`Issue #3601 <https://github.com/quaive/ploneintranet/issues/3601>`_)
- Upgrade isort configuration to work with isort v5. (`Issue #3602 <https://github.com/quaive/ploneintranet/issues/3602>`_)


Updated:


- Updated quaive.reources.ploneintranet to 6.1. (`Issue #3611 <https://github.com/quaive/ploneintranet/issues/3611>`_)
- Updated zope.interface to solve a memory leak issue


2.1.0a5 (2020-09-09)
--------------------

Added:


- Initial integration for paying users.

  To enable the addition of paying users you will need to:

  - add the stripe package in the buildout
  - look for and configure the stripe records in the registry.

  When this will happen a new button will be visible in the admintool app panel
  used to create new users.
  An user added in such a way is not enabled by default,
  but receives an email with the request to complete the subscription
  by paying a fee on stripe.
  Once the user has completed the payment he is logged in in Quaive. (`Issue #3204 <https://github.com/quaive/ploneintranet/issues/3204>`_)
- Add feature to show all images in news articles in an image gallery. (`Issue #3548 <https://github.com/quaive/ploneintranet/issues/3548>`_)


Changed:


- Easier/quicker navigation within news magazine and less distraction while consuming news content (`Issue #3563 <https://github.com/quaive/ploneintranet/issues/3563>`_)


Fixed:


- Fix the post attachment extraction feature.
  Apparently this is related to the refactoring that was taking place when reworking the preview generation.
  Some code in this feature which is flagged off in the tests was not up-to-date anymore. (`Issue #2241 <https://github.com/quaive/ploneintranet/issues/2241>`_)
- Fixed an error happening when trying to sync users that are not in the external source. (`Issue #3560 <https://github.com/quaive/ploneintranet/issues/3560>`_)
- Display user and groups counter in the workspace header even if the workspace is not a group anymore (`Issue #3581 <https://github.com/quaive/ploneintranet/issues/3581>`_)


Updated:


- Updated quaive.reources.ploneintranet to 5.1.0 (`Issue #3545 <https://github.com/quaive/ploneintranet/issues/3545>`_)
- Updated ftw.upgrade to 3.0.2 (`Issue #3419 <https://github.com/quaive/ploneintranet/issues/3419>`_)


2.1.0a4 (2020-08-31)
--------------------

Changed:


- Multiple arbitrary groups can now be picked in maintainer/visibility settings for news sections.
  The news publisher is now shown on the apps screen for users who are maintainers of at least one news section. This implies that on a permission level every user can access the news publisher now. This is OK because sections and news items are protected separately. (`Issue #3336 <https://github.com/quaive/ploneintranet/issues/3336>`_)
- Multiple arbitrary groups can now be picked in maintainer/visibility settings for central calendars. (`Issue #3337 <https://github.com/quaive/ploneintranet/issues/3337>`_)
- The code that sync ldap users is now expecting pas.plugins.ldap instead of the old Products.PloneLDAP (`Issue #3560 <https://github.com/quaive/ploneintranet/issues/3560>`_)


Fixed:


- Status updates on the activity stream for News items behave correctly when clicked on. (`Issue #3557 <https://github.com/quaive/ploneintranet/issues/3557>`_)
- Preview of an item's past versions is no longer blank. (`Issue #3570 <https://github.com/quaive/ploneintranet/issues/3570>`_)


Technical:


- Fix a date-related robot test. Make sure the event we test for is always in the current month. (`Issue #3575 <https://github.com/quaive/ploneintranet/issues/3575>`_)


Updated:


- Updated quaive.app.onlyoffice to 2.1.0
- Updated quaive.resources.ploneintranet to 5.0.32


2.1.0a3 (2020-08-18)
--------------------

Added:


- "About Quaive" page that informs about packages versions and similar technical details. (`Issue #3504 <https://github.com/quaive/ploneintranet/issues/3504>`_)


Changed:


- The "Workspace is a group" feature is not activated anymore by default.
  We found that it is not used and that can cause confusion if we have a group that has the same name of the workspace.
  Installations that are already using the feature will continue behaving as before.
  To disable the feature the quaive.group behavior has to be removed from workspaces. (`Issue #3481 <https://github.com/quaive/ploneintranet/issues/3481>`_)
- When a user is created, the confirmation mail says when the password reset link will expire.
  When a password reset fails, the page explains that the link may have expired and how to get a new one. (`Issue #3506 <https://github.com/quaive/ploneintranet/issues/3506>`_)
- The news tile now displays the news section in a pill right to the title (`Issue #3514 <https://github.com/quaive/ploneintranet/issues/3514>`_)
- Password reset and user creation improvements (allow entering email instead of user name, send HTML email, text changes) (`Issue #3530 <https://github.com/quaive/ploneintranet/issues/3530>`_)
- News items as search results: instead of showing a miniature render of the article as preview, we use the news item's main image. (`Issue #3541 <https://github.com/quaive/ploneintranet/issues/3541>`_)
- User ID is pre-filled when creating user or requesting password reset (`Issue #3542 <https://github.com/quaive/ploneintranet/issues/3542>`_)


Fixed:


- Improvements in the activity stream:
  - Documents uploaded to a workspace, when title or preview image is clicked, will be opened in the context of their workspace with proper injection in place.
  - Documents that have renders show the number of pages.
  - Documents that have renders make all of those renders available in pat-gallery.
  - Documents uploaded directly to the stream as attachment, when title or preview image is clicked, will open the render in gallery view. If no renders are available, download the file instead. (`Issue #3287 <https://github.com/quaive/ploneintranet/issues/3287>`_)
- Images attached to the Activity Stream can now be rendered in any available scale.
  Previously they were always returned with using the "preview" scale. (`Issue #3385 <https://github.com/quaive/ploneintranet/issues/3385>`_)
- Don't add the slide-bank, image-bank or app-market apps as we don't use them. (`Issue #3486 <https://github.com/quaive/ploneintranet/issues/3486>`_)
- When a user profile has been disabled, disallow that user to re-enable themselves via password reset. (`Issue #3491 <https://github.com/quaive/ploneintranet/issues/3491>`_)
- The password reset form after submitting invalid data was not proposing the just entered passwords.
  Also other login related forms properly use the value from the request when available. (`Issue #3509 <https://github.com/quaive/ploneintranet/issues/3509>`_)
- Request new previews for a document published to the library (`Issue #3516 <https://github.com/quaive/ploneintranet/issues/3516>`_)
- Fix the links to svg images in posts and comments (`Issue #3518 <https://github.com/quaive/ploneintranet/issues/3518>`_)
- Add missing markup, to make @@voting view scroll. (`Issue #3521 <https://github.com/quaive/ploneintranet/issues/3521>`_)
- When attaching a file / image to a Stream post, normalize its filename. This
  prevents errors in downloading or displaying the attachment. (`Issue #3531 <https://github.com/quaive/ploneintranet/issues/3531>`_)
- Activity stream: the "download" links on attachments and content updates (images / files)
  now actually trigger a download of the requested file. (`Issue #3533 <https://github.com/quaive/ploneintranet/issues/3533>`_)
- Fixed redactor text alignment. It was possible to align text but the setting was not saved. (`Issue #3538 <https://github.com/quaive/ploneintranet/issues/3538>`_)
- Fixed a bug that caused the contents of the “notifications” tooltip
  to be displayed twice. (`Issue #3543 <https://github.com/quaive/ploneintranet/issues/3543>`_)


Technical:


- Restructure buildout for extensibility and reuse of config files. (`Issue #3465 <https://github.com/quaive/ploneintranet/issues/3465>`_)
- Handle news pagination on multiple Plone and Python versions (`Issue #3512 <https://github.com/quaive/ploneintranet/issues/3512>`_)


Updated:


- Use Plone 5.2.2 (`Issue #3460 <https://github.com/quaive/ploneintranet/issues/3460>`_)
- Updated quaive.resources.ploneintranet to 5.0.31


2.1.0a2 (2020-07-24)
--------------------

Added:


- Add registry key to allow/disallow upload of video files. (`Issue #3499 <https://github.com/quaive/ploneintranet/issues/3499>`_)


Fixed:


- Verbs in the activity stream are once again translated. (`Issue #0000 <https://github.com/quaive/ploneintranet/issues/0000>`_)
- The library is browsable by tag again (`Issue #3432 <https://github.com/quaive/ploneintranet/issues/3432>`_)
- Microblog optimizations (`Issue #3435 <https://github.com/quaive/ploneintranet/issues/3435>`_)
- Fix the method is_office_file (`Issue #3442 <https://github.com/quaive/ploneintranet/issues/3442>`_)
- News dashboard portlet: Use the 'large' scale instead of 'mini' for crisper images at all (especially lower) resolutions. (`Issue #3458 <https://github.com/quaive/ploneintranet/issues/3458>`_)
- Prevent user with expired cookie to click the like button successfully recording the "acl_users" user id between the "likers".
  Prevent "acl_users" to be fetch as a user by pi_api.userprofile.get().
  Clean up in case that already happened. (`Issue #3463 <https://github.com/quaive/ploneintranet/issues/3463>`_)
- Make sure that a site administrator who creates a new user account does not gain
  any unwanted permissions on content located in the new user profile (such as
  classified ads) (`Issue #3477 <https://github.com/quaive/ploneintranet/issues/3477>`_)
- Fix display of videos, audios and links in library, workspace and activity streams. (`Issue #3494 <https://github.com/quaive/ploneintranet/issues/3494>`_)
- Reactivated some translations marked as "fuzzy". (`Issue #3505 <https://github.com/quaive/ploneintranet/issues/3505>`_)
- Only the first 10 news items inside each respective section of the News Publisher
  are shown initially. Further batches of 20 more items can be loaded via a
  "More news..." link. (`Issue #3361 <https://github.com/quaive/ploneintranet/issues/3361>`_)
- Allow a workspace administrator to switch the activity stream from single to
  multi column layout. (`Issue #3405 <https://github.com/quaive/ploneintranet/issues/3405>`_)
- The saving badge on documents ("Last saved 36 minutes ago") is now shorter,
  so that we have enough space for all buttons of the editor (redactor). (`Issue #3482 <https://github.com/quaive/ploneintranet/issues/3482>`_)


Technical:


- Fix the upgrade steps order to make the one needed for the Python3 migration to be the last one (`Issue #3092 <https://github.com/quaive/ploneintranet/issues/3092>`_)
- Fix SVG generation in case where also the PNG is larger than 1MB (`Issue #3370 <https://github.com/quaive/ploneintranet/issues/3370>`_)
- Keep the Plone support for Plone 5.1 but by default use Plone5.2.
  Users that will want to use Plone 5.1 might temporarily use
  buildout51.cfg.
  Support for Plone 5.1 will soon be removed.
- Renamed view "svg_preview" to "render.svg" to make it obvious to browsers
  that an SVG is being served.
- Fixed a bug with png preview resizing where an int was needed but float given. That prevented generation of png previews where the svg preview would be too large
- Remove really old upgrade steps (`Issue #1584 <https://github.com/quaive/ploneintranet/issues/1584>`_)
- Added view @@feed-aggregator to replace console script (`Issue #3466 <https://github.com/quaive/ploneintranet/issues/3466>`_)
- Factor-out youtube_url as a utility method for easier reuse and testing. (`Issue #3494 <https://github.com/quaive/ploneintranet/issues/3494>`_)


Updated:


- Updated collective.vdexvocabulary to 0.3
- Updated imsvdex to 1.2
- Updated Products.CMFNotification to 3.0.0a4
- Updated quaive.app.taxonomy to 1.4.0
- Updated quaive.resources.ploneintranet to 5.0.26
- Updated quaive.app.absences to 1.3.0a5
- Updated quaive.app.classifieds to 1.0.2
- Updated slc.mailrouter to 3.0.1
- Updated plone.namedfile to 5.4.0 (`Issue #3454 <https://github.com/quaive/ploneintranet/issues/3454>`_)


2.1.0a1 (2020-06-18)
--------------------

Added:


- Documents in the activitystream have now a specialized preview (`Issue #3356 <https://github.com/quaive/ploneintranet/issues/3356>`_)
- Events in the activitystream have now a specialized preview (`Issue #3401 <https://github.com/quaive/ploneintranet/issues/3401>`_)


Changed:


- Advertise that the maximum size for video files is 200 MB.
  Use poster images, when available in video elelements. (`Issue #3362 <https://github.com/quaive/ploneintranet/issues/3362>`_)
- The activity stream dashboard tile can now be added and removed to and from all dashboard types (`Issue #3383 <https://github.com/quaive/ploneintranet/issues/3383>`_)
- By default PDF file versions of HTML documents are created using wkhtmltopdf, which provides by far the better results.
  Already existing installations that were not yet adopting wkhtmltopdf might want to edit ploneintranet.docconv.wkhtmltopdf.options to enable it. (`Issue #3398 <https://github.com/quaive/ploneintranet/issues/3398>`_)


Fixed:


- Tolerate ploneintranet.userprofile.ldap to be imported without Products.PloneLDAP
  Add a missing class to images in comments so that they open properly on click.
- The workspace_members indexer properly returns a set of native strings (`Issue #3066 <https://github.com/quaive/ploneintranet/issues/3066>`_)
- The group view does not break if the group is managed by another group (`Issue #3180 <https://github.com/quaive/ploneintranet/issues/3180>`_)
- Add the description under the video files in the library

  This is needed to be consistent with the video links that also show the description (`Issue #3362 <https://github.com/quaive/ploneintranet/issues/3362>`_)
- When opening a document in the library the browser will scroll on the top of the page (`Issue #3392 <https://github.com/quaive/ploneintranet/issues/3392>`_)
- Emptying the trash is now faster (`Issue #3435 <https://github.com/quaive/ploneintranet/issues/3435>`_)


Technical:


- Simplify code regarding document conversion removing the unnecessary allowedDocumentType and can_have_previews (which was not used) functions (`Issue #3398 <https://github.com/quaive/ploneintranet/issues/3398>`_)


Updated:


- Updated collective.workspace to 3.0b2
- Updated plone.app.versioningbehavior to 1.4.0
- Updated plone.namedfile to 5.3.1
- Updated quaive.app.absences to 1.3.0a3
- Updated quaive.resources.ploneintranet to 5.0.22
- Updated waitress to 1.4.4
