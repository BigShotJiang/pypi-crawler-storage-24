# Plone Intranet

Release status:
[![gitlab-gaia](https://gitlab.com/quaive/gaia/badges/master/build.svg)](https://gitlab.com/quaive/gaia/pipelines%0A:alt:%20Gaia%20release%20build%20status).
Development status: Jenkins
[![jenkins-master](http://jenkins.quaive.net/job/quaive-master-complete/badge/icon)](http://jenkins.quaive.net/job/quaive-master-complete/%0A:alt:%20Jenkins%20development%20build%20status)
Gitlab
[![gitlab-master](https://gitlab.com/quaive/ploneintranet/badges/master/build.svg)](https://gitlab.com/quaive/ploneintranet/pipelines%0A:alt:%20Gitlab%20development%20build%20status).

Plone Intranet is the community edition of the
[Quaive](http://quaive.com) digital workplace and social intranet
platform, built on top of [Plone](http://plone.com) - the ultimate open
source enterprise CMS.

For more info about this product and how it is used, see our website at
<http://quaive.com>

Full community edition developer documentation is available at
<http://docs.ploneintranet.org/>

Please request a [free demo](http:/quaive.com/book-a-demo) if you want
to learn more about what our software can do.

## Installation

Experienced Plone developers can set up the system by following the
[documented installation
procedure](http://docs.ploneintranet.org/installation/index.html).

If you run into any issues, get in touch with the development team via
the [developer mailing list](https://groups.io/g/ploneintranet-dev).

Note that this is an open source community edition release - you're
expected to bring your own expertise and effort to complement ours.

If you'd rather have a Quaive expert install and manage the system for
you, contact one of our [partners](http://quaive.com/about-us) to
contract support. This also gives you access to the enterprise edition,
which has more features than the community edition.

See our [blog](http://quaive.com/blog) and our
[Twitter](https://twitter.com/QuaiveSoft) stream or
[Facebook](https://facebook.com/quaive) page for the latest status.

## Copyright (c) Plone Foundation

This package is Copyright (c) Plone Foundation.

Any contribution to this package implies consent and intent to
irrevocably transfer all copyrights on the code you contribute, to the
[Plone Foundation](https://plone.org/foundation), under the condition
that the code remains under a [OSI-approved
license](http://opensource.org/licenses).

To contribute, you need to have signed a Plone Foundation [contributor
agreement](https://plone.org/foundation/contributors-agreement). If
you're [listed on Github](https://github.com/orgs/plone/people) as a
member of the Plone organization, you already signed.

## License

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License version 2 as published
by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the [GNU
General Public
License](http://www.gnu.org/licenses/old-licenses/gpl-2.0.html) for more
details.
