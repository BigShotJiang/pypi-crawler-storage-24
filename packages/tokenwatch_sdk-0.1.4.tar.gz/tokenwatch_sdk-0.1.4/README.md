# TokenWatch SDK

Zero-config AI usage tracking. Wrap your existing OpenAI or Anthropic client with one line — every call is automatically logged to your [TokenWatch](https://tokenwatch.ai) dashboard.

**Your API keys stay with you.** The SDK only reads token counts from responses and sends them to TokenWatch. Nothing is proxied.

## Install

```bash
pip install tokenwatch-sdk
```

## Quick start

1. Sign up at [tokenwatch.ai](https://tokenwatch.ai) and copy your API token from the dashboard.

2. Wrap your client:

```python
from tokenwatch import TokenWatch
import openai

tw = TokenWatch(token="your-token-here", base_url="https://your-server.com")

# One-line wrap — use the client exactly as before
client = tw.wrap(openai.OpenAI(api_key="sk-..."))

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello!"}],
)
# Token usage now appears on your dashboard automatically
```

## Anthropic

```python
import anthropic

client = tw.wrap(anthropic.Anthropic(api_key="sk-ant-..."))

response = client.messages.create(
    model="claude-3-haiku-20240307",
    max_tokens=256,
    messages=[{"role": "user", "content": "Hello!"}],
)
```

## Async clients

```python
import openai, asyncio

client = tw.wrap(openai.AsyncOpenAI(api_key="sk-..."))

async def main():
    response = await client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Hello!"}],
    )

asyncio.run(main())
```

## Tag calls by feature

```python
summarizer = tw.wrap(openai.OpenAI(api_key="sk-..."), app_tag="summarizer")
chatbot    = tw.wrap(openai.OpenAI(api_key="sk-..."), app_tag="chatbot")
```

## Login instead of pasting a token

```python
tw = TokenWatch.login(
    email="you@example.com",
    password="your-password",
    base_url="https://your-server.com",
)
```

## Google Colab example

```python
!pip install tokenwatch-sdk openai

from tokenwatch import TokenWatch
import openai

tw = TokenWatch(token="paste-your-token-here", base_url="https://your-server.com")
client = tw.wrap(openai.OpenAI(api_key="sk-..."))

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Summarize the theory of relativity in one paragraph."}],
)
print(response.choices[0].message.content)
```
