#!/usr/bin/env python3
"""MCA SDK CLI tools for project scaffolding and setup.

This module provides command-line tools for:
- Initializing new MCA SDK projects (mca-init)
- Setting up local development environments
- Integrating mock collectors for staging
"""

import argparse
import shutil
import sys
from pathlib import Path


def get_template_dir() -> Path:
    """Get the directory containing CLI templates."""
    # Templates are in the same directory as this module
    return Path(__file__).parent / "templates"


def init_project(project_dir: str, with_mock_collector: bool = True) -> int:
    """Initialize a new MCA SDK project with scaffolding.

    Args:
        project_dir: Directory to create the project in
        with_mock_collector: Whether to include docker-compose.mock.yml

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    project_path = Path(project_dir).resolve()

    # Check if directory already exists
    if project_path.exists():
        print(f"Error: Directory {project_path} already exists", file=sys.stderr)
        return 1

    # Create project directory
    try:
        project_path.mkdir(parents=True, exist_ok=False)
        print(f"Created project directory: {project_path}")
    except Exception as e:
        print(f"Error creating directory: {e}", file=sys.stderr)
        return 1

    # Copy mock collector files if requested (Story 8.4)
    if with_mock_collector:
        try:
            # Find docker-compose.mock.yml in package
            pkg_root = Path(__file__).parent.parent
            mock_compose = pkg_root / "docker-compose.mock.yml"
            mock_config = pkg_root / "config" / "otel-collector-mock.yml"

            if mock_compose.exists():
                shutil.copy2(mock_compose, project_path / "docker-compose.mock.yml")
                print("  ✓ Copied docker-compose.mock.yml")
            else:
                print("  ⚠ docker-compose.mock.yml not found in package", file=sys.stderr)

            if mock_config.exists():
                config_dir = project_path / "config"
                config_dir.mkdir(exist_ok=True)
                shutil.copy2(mock_config, config_dir / "otel-collector-mock.yml")
                print("  ✓ Copied config/otel-collector-mock.yml")
            else:
                print("  ⚠ otel-collector-mock.yml not found in package", file=sys.stderr)

        except Exception as e:
            print(f"Warning: Could not copy mock collector files: {e}", file=sys.stderr)

    # Create example configuration file
    try:
        config_file = project_path / "mca.yaml"
        config_file.write_text("""# MCA SDK Configuration
# Story 8.4: Environment-aware configuration profiles

# Environment: staging (local testing), dev, or prod
environment: staging

# Service identification
service_name: my-model-service
model_id: mdl-001
model_version: 1.0.0
team_name: my-team

# Model classification
model_type: regression  # regression, classification, time-series, generative, agentic
model_category: internal  # internal or vendor

# OpenTelemetry Collector endpoint
# staging: Defaults to http://localhost:4318 or http://mock-collector:4318 (Docker)
# dev/prod: REQUIRED - must be explicitly configured
# collector_endpoint: https://otel-collector.example.com:4318

# Registry integration (optional in staging, required in dev/prod)
# registry_url: https://registry.example.com/api/v1
# registry_token: set via MCA_REGISTRY_TOKEN environment variable

# For more options, see: https://github.com/your-org/mca-sdk
""")
        print("  ✓ Created mca.yaml configuration template")
    except Exception as e:
        print(f"Warning: Could not create mca.yaml: {e}", file=sys.stderr)

    # Create example Python file
    try:
        example_file = project_path / "example_model.py"
        example_file.write_text('''"""Example instrumented model using MCA SDK."""

from mca_sdk import MCAClient

# Initialize MCA client (loads from mca.yaml and environment variables)
client = MCAClient(
    service_name="my-model-service",
    model_id="mdl-001",
    team_name="my-team"
)


@client.predict()
def predict(features: dict) -> dict:
    """Example prediction function with automatic instrumentation."""
    # Your model logic here
    prediction = {"result": "positive", "confidence": 0.85}
    return prediction


if __name__ == "__main__":
    # Example usage
    result = predict({"feature1": 1.0, "feature2": 2.0})
    print(f"Prediction: {result}")

    # Shutdown (flushes telemetry)
    client.shutdown()
''')
        print("  ✓ Created example_model.py")
    except Exception as e:
        print(f"Warning: Could not create example_model.py: {e}", file=sys.stderr)

    # Create README
    try:
        readme = project_path / "README.md"
        readme.write_text(f"""# {project_path.name}

MCA SDK instrumented model project

## Quick Start

### Local Development (Staging)

1. Start the mock collector:
   ```bash
   docker compose -f docker-compose.mock.yml up -d
   ```

2. Run your model:
   ```bash
   export MCA_ENV=staging
   python example_model.py
   ```

3. View traces in Jaeger:
   http://localhost:16686

### Production Deployment

Set required environment variables:
```bash
export MCA_ENV=prod
export MCA_COLLECTOR_ENDPOINT=https://otel-collector.example.com:4318
export MCA_REGISTRY_URL=https://registry.example.com/api/v1
export MCA_REGISTRY_TOKEN=your-token-here
```

## Configuration

See `mca.yaml` for configuration options.

## Documentation

- [MCA SDK Documentation](https://github.com/your-org/mca-sdk)
- Story 8.4: Environment-Aware Configuration Profiles
""")
        print("  ✓ Created README.md")
    except Exception as e:
        print(f"Warning: Could not create README.md: {e}", file=sys.stderr)

    print(f"\n✓ Project initialized successfully at {project_path}")
    print("\nNext steps:")
    print(f"  cd {project_path}")
    if with_mock_collector:
        print("  docker compose -f docker-compose.mock.yml up -d")
    print("  python example_model.py")
    return 0


def main() -> int:
    """Main entry point for mca-init CLI."""
    parser = argparse.ArgumentParser(
        description="Initialize a new MCA SDK project with scaffolding",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  mca-init my-project              # Create project with mock collector
  mca-init my-project --no-mock    # Create project without mock collector

For more information, see Story 8.4: Environment-Aware Configuration Profiles
""",
    )
    parser.add_argument("project_dir", help="Directory to create the project in")
    parser.add_argument(
        "--no-mock",
        action="store_true",
        help="Skip docker-compose.mock.yml scaffolding",
    )
    parser.add_argument("--version", action="version", version="mca-init 0.4.0 (Story 8.4)")

    args = parser.parse_args()

    return init_project(args.project_dir, with_mock_collector=not args.no_mock)


if __name__ == "__main__":
    sys.exit(main())
