# SPDX-License-Identifier: AGPL-3.0-or-later | Commercial license available
# Â© Concepts 1996â€“2026 Miroslav Ĺ otek. All rights reserved.
# Â© Code 2020â€“2026 Miroslav Ĺ otek. All rights reserved.
# ORCID: 0009-0009-3560-0851
# Contact: www.anulum.li | protoscience@anulum.li
# Director-Class AI â€” Enterprise Import Tests

import subprocess
import sys


class TestEnterpriseImport:
    def test_core_import_does_not_load_tenant(self):
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                (
                    "from director_ai.core import CoherenceScorer; "
                    "import sys; "
                    "assert 'director_ai.core.tenant' not in sys.modules, "
                    "'tenant was eagerly loaded'"
                ),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr

    def test_enterprise_package_importable(self):
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                (
                    "from director_ai.enterprise import TenantRouter, Policy, AuditLogger; "
                    "assert TenantRouter is not None; "
                    "assert Policy is not None; "
                    "assert AuditLogger is not None"
                ),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr

    def test_old_import_path_raises_import_error(self):
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                (
                    "try:\n"
                    "    from director_ai import TenantRouter\n"
                    "    raise AssertionError('should have raised ImportError')\n"
                    "except ImportError as e:\n"
                    "    assert 'director_ai.enterprise' in str(e)\n"
                ),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr

    def test_old_core_import_path_raises_import_error(self):
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                (
                    "try:\n"
                    "    from director_ai.core import TenantRouter\n"
                    "    raise AssertionError('should have raised ImportError')\n"
                    "except ImportError as e:\n"
                    "    assert 'director_ai.enterprise' in str(e)\n"
                ),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr
