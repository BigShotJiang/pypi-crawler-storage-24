# Backend shutdown hooks
