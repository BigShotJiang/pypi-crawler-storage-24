"""Zoom channel."""
