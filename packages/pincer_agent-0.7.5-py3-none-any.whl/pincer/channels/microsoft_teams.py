"""Microsoft Teams channel."""
