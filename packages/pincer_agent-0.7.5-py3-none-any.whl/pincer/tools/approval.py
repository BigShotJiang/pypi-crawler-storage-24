"""Tool approval flow."""
