"""Mistral provider."""
