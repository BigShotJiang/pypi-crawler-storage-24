"""Tools for managing asynchronous delegations."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from henchman.tools.base import Tool, ToolResult

if TYPE_CHECKING:
    pass


class DelegationTool(Tool):
    """Base class for delegation management tools."""

    def __init__(self) -> None:
        super().__init__()
        self.orchestrator: Any = None


class ListDelegationsTool(DelegationTool):
    """List ongoing delegations."""

    name = "list_delegations"
    description = "List all ongoing delegations with their status and task IDs."

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool."""
        if not self.orchestrator:
            return ToolResult(
                success=False,
                content="Orchestrator not available.",
            )

        try:
            delegations = self.orchestrator.get_ongoing_delegations()
            if not delegations:
                return ToolResult(
                    success=True,
                    content="No ongoing delegations.",
                )

            result_lines = ["## Ongoing Delegations:"]
            for i, delegation in enumerate(delegations, 1):
                result_lines.append(
                    f"{i}. **{delegation['target_role']}** (ID: `{delegation['task_id']}`)"
                )
                result_lines.append(f"   Task: {delegation['task'][:100]}...")
                result_lines.append(f"   Output lines: {delegation['output_lines']}")
                result_lines.append("")

            return ToolResult(
                success=True,
                content="\n".join(result_lines),
            )
        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Failed to list delegations: {e}",
            )


class TailDelegationTool(DelegationTool):
    """Tail the output of an ongoing delegation."""

    name = "tail_delegation"
    description = "View the last N lines of output from an ongoing delegation."
    args_schema = {
        "type": "object",
        "properties": {
            "task_id": {
                "type": "string",
                "description": "The delegation task ID.",
            },
            "lines": {
                "type": "integer",
                "description": "Number of lines to show (default: 25).",
                "default": 25,
            },
        },
        "required": ["task_id"],
    }

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool."""
        orchestrator = self.orchestrator
        task_id: str = kwargs.get("task_id", "")
        lines: int = kwargs.get("lines", 25)

        if not orchestrator:
            return ToolResult(
                success=False,
                content="Orchestrator not available.",
            )

        if not task_id:
            return ToolResult(
                success=False,
                content="Task ID is required.",
            )

        try:
            output = orchestrator.tail_delegation_output(task_id, lines)

            # Check delegation status
            status = orchestrator.check_delegation_status(task_id)
            if not status.get("found", False):
                return ToolResult(
                    success=False,
                    content=f"Delegation {task_id} not found.",
                )

            status_info = []
            if status["completed"]:
                status_info.append("✅ **Completed**")
                if status["error"]:
                    status_info.append(f"Error: {status['error']}")
            else:
                status_info.append("⏳ **In Progress**")

            status_info.append(f"Target: {status['target_role']}")
            status_info.append(f"Task: {status['task'][:200]}...")

            result_lines = [
                f"## Delegation: {task_id}",
                "",
                *status_info,
                "",
                "### Recent Output:",
                "```",
                output,
                "```",
            ]

            return ToolResult(
                success=True,
                content="\n".join(result_lines),
            )
        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Failed to tail delegation: {e}",
            )


class WaitForDelegationTool(DelegationTool):
    """Wait for a delegation to complete and get its result."""

    name = "wait_for_delegation"
    description = "Wait for a delegation to complete and return its result."
    args_schema = {
        "type": "object",
        "properties": {
            "task_id": {
                "type": "string",
                "description": "The delegation task ID.",
            },
            "timeout": {
                "type": "number",
                "description": "Timeout in seconds (default: no timeout).",
            },
        },
        "required": ["task_id"],
    }

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool."""
        orchestrator = self.orchestrator
        task_id: str = kwargs.get("task_id", "")
        timeout: float | None = kwargs.get("timeout")

        if not orchestrator:
            return ToolResult(
                success=False,
                content="Orchestrator not available.",
            )

        if not task_id:
            return ToolResult(
                success=False,
                content="Task ID is required.",
            )

        try:
            # Check if delegation exists
            status = orchestrator.check_delegation_status(task_id)
            if not status.get("found", False):
                return ToolResult(
                    success=False,
                    content=f"Delegation {task_id} not found.",
                )

            if status["completed"] and status["has_result"]:
                # Already completed, just get the result
                result_content, success = await orchestrator.wait_for_delegation(task_id, 0.1)
            else:
                # Wait for completion
                result_content, success = await orchestrator.wait_for_delegation(task_id, timeout)

            # Submit result to Tech Lead
            submitted = orchestrator.submit_delegation_result(task_id)

            result_lines = [
                f"## Delegation Result: {task_id}",
                f"Target: {status['target_role']}",
                f"Success: {'✅' if success else '❌'}",
                f"Result submitted to Tech Lead: {'✅' if submitted else '❌'}",
                "",
                "### Result:",
                result_content,
            ]

            return ToolResult(
                success=True,
                content="\n".join(result_lines),
            )
        except asyncio.TimeoutError:
            return ToolResult(
                success=False,
                content=f"Timeout waiting for delegation {task_id} to complete.",
            )
        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Failed to wait for delegation: {e}",
            )


class CancelDelegationTool(DelegationTool):
    """Cancel an ongoing delegation."""

    name = "cancel_delegation"
    description = "Cancel an ongoing delegation."
    args_schema = {
        "type": "object",
        "properties": {
            "task_id": {
                "type": "string",
                "description": "The delegation task ID.",
            },
        },
        "required": ["task_id"],
    }

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool."""
        orchestrator = self.orchestrator
        task_id: str = kwargs.get("task_id", "")

        if not orchestrator:
            return ToolResult(
                success=False,
                content="Orchestrator not available.",
            )

        if not task_id:
            return ToolResult(
                success=False,
                content="Task ID is required.",
            )

        try:
            cancelled = orchestrator.cancel_delegation(task_id)

            if cancelled:
                return ToolResult(
                    success=True,
                    content=f"✅ Delegation {task_id} cancelled successfully.",
                )
            else:
                return ToolResult(
                    success=False,
                    content=f"Failed to cancel delegation {task_id}. It may already be completed or not found.",
                )
        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Failed to cancel delegation: {e}",
            )


class CheckDelegationStatusTool(DelegationTool):
    """Check the status of a delegation."""

    name = "check_delegation_status"
    description = "Check the status of a delegation."
    args_schema = {
        "type": "object",
        "properties": {
            "task_id": {
                "type": "string",
                "description": "The delegation task ID.",
            },
        },
        "required": ["task_id"],
    }

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool."""
        orchestrator = self.orchestrator
        task_id: str = kwargs.get("task_id", "")

        if not orchestrator:
            return ToolResult(
                success=False,
                content="Orchestrator not available.",
            )

        if not task_id:
            return ToolResult(
                success=False,
                content="Task ID is required.",
            )

        try:
            status = orchestrator.check_delegation_status(task_id)

            if not status.get("found", False):
                return ToolResult(
                    success=False,
                    content=f"Delegation {task_id} not found.",
                )

            result_lines = [
                f"## Delegation Status: {task_id}",
                f"Target: {status['target_role']}",
                f"Status: {'✅ Completed' if status['completed'] else '⏳ In Progress'}",
                f"Task: {status['task'][:200]}...",
                f"Started: {status['start_time']:.1f}s ago",
                f"Output lines: {status['output_lines']}",
            ]

            if status["error"]:
                result_lines.append(f"Error: {status['error']}")

            if status["completed"] and status["has_result"]:
                result_lines.append("Result: Available (use wait_for_delegation to get it)")

            return ToolResult(
                success=True,
                content="\n".join(result_lines),
            )
        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Failed to check delegation status: {e}",
            )


class StartAsyncDelegationTool(DelegationTool):
    """Start a delegation asynchronously."""

    name = "start_async_delegation"
    description = "Start a delegation that runs in the background, allowing you to continue working while it executes."
    args_schema = {
        "type": "object",
        "properties": {
            "agent": {
                "type": "string",
                "description": "The specialist agent to delegate to (planner, explorer, engineer, data_engineer).",
                "enum": ["planner", "explorer", "engineer", "data_engineer"],
            },
            "task": {
                "type": "string",
                "description": "The task description for the specialist.",
            },
            "brief": {
                "type": "object",
                "description": "Optional brief with additional context.",
            },
        },
        "required": ["agent", "task"],
    }

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool."""
        orchestrator = self.orchestrator
        target_agent: str = kwargs.get("agent", "")
        task: str = kwargs.get("task", "")
        brief: dict[str, Any] = kwargs.get("brief", {})

        if not orchestrator:
            return ToolResult(
                success=False,
                content="Orchestrator not available.",
            )

        if not target_agent or not task:
            return ToolResult(
                success=False,
                content="Agent and task are required.",
            )

        try:
            # Create a tool call for the delegation
            import uuid

            from henchman.providers.base import ToolCall

            tool_call = ToolCall(
                id=f"call_{uuid.uuid4().hex[:8]}",
                name="delegate_task",
                arguments={
                    "agent": target_agent,
                    "task": task,
                    "brief": brief,
                }
            )

            # Start delegation asynchronously
            task_id = await orchestrator.tool_controller.delegation_manager.start_delegation(
                orchestrator.tech_lead,
                tool_call,
                depth=0,
            )

            return ToolResult(
                success=True,
                content=(
                    f"✅ Started asynchronous delegation to **{target_agent}**\n"
                    f"**Task ID:** `{task_id}`\n"
                    f"**Task:** {task[:200]}...\n\n"
                    f"Use `list_delegations` to see all ongoing delegations.\n"
                    f"Use `tail_delegation` to view output.\n"
                    f"Use `wait_for_delegation` to get results when ready."
                ),
            )
        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Failed to start async delegation: {e}",
            )


class WaitForAllDelegationsTool(DelegationTool):
    """Wait for all ongoing delegations to complete."""

    name = "wait_for_all_delegations"
    description = "Wait for all ongoing delegations to complete and submit their results."
    args_schema = {
        "type": "object",
        "properties": {
            "timeout": {
                "type": "number",
                "description": "Timeout in seconds for each delegation (default: no timeout).",
            },
        },
    }

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool."""
        orchestrator = self.orchestrator
        timeout: float | None = kwargs.get("timeout")

        if not orchestrator:
            return ToolResult(
                success=False,
                content="Orchestrator not available.",
            )

        try:
            # Get all ongoing delegations
            delegations = orchestrator.get_ongoing_delegations()
            if not delegations:
                return ToolResult(
                    success=True,
                    content="No ongoing delegations to wait for.",
                )

            result_lines = ["## Waiting for delegations to complete:"]
            completed = 0
            failed = 0

            for delegation in delegations:
                task_id = delegation["task_id"]
                target_role = delegation["target_role"]

                result_lines.append(f"\n### {target_role} (ID: {task_id})")

                try:
                    # Wait for delegation to complete
                    result_content, success = await orchestrator.wait_for_delegation(task_id, timeout)

                    # Submit result
                    submitted = orchestrator.submit_delegation_result(task_id)

                    if success:
                        result_lines.append("✅ Completed successfully")
                        if submitted:
                            result_lines.append("  Result submitted to Tech Lead")
                        else:
                            result_lines.append("  Warning: Failed to submit result")
                        completed += 1
                    else:
                        result_lines.append("❌ Failed")
                        result_lines.append("  Error in result")
                        failed += 1

                except asyncio.TimeoutError:
                    result_lines.append("⏳ Timeout waiting for completion")
                    failed += 1
                except Exception as e:
                    result_lines.append(f"❌ Error: {e}")
                    failed += 1

            result_lines.append(f"\n## Summary: {completed} completed, {failed} failed")

            return ToolResult(
                success=True,
                content="\n".join(result_lines),
            )
        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Failed to wait for delegations: {e}",
            )


# Register all delegation management tools
DELEGATION_TOOLS = [
    ListDelegationsTool(),
    TailDelegationTool(),
    WaitForDelegationTool(),
    CancelDelegationTool(),
    CheckDelegationStatusTool(),
    StartAsyncDelegationTool(),
    WaitForAllDelegationsTool(),
]
