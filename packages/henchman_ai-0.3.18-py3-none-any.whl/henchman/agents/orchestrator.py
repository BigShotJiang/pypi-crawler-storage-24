"""Orchestrator for multi-agent development team.

This is the main entry point for the multi-agent system.  All supporting
types, components, and controllers live in sibling modules and are
re-exported here for backward compatibility.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from henchman.agents.delegation import DelegationRunner
from henchman.agents.metrics import OrchestratorMetrics
from henchman.core.events import AgentEvent, EventType

# Re-export symbols that external code imports from this module
from .orchestrator_execution import _last_assistant_content
from .orchestrator_init import OrchestratorConfig, init_orchestrator
from .orchestrator_run import finalize_run, prepare_run
from .orchestrator_timeout import TimeoutSummaryBuilder
from .orchestrator_types import (
    COLON_STALL_NUDGE,
    MAX_COLON_STALL_RETRIES,
    AgentLoopParams,
    CompletionStatus,
    DelegationParams,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from henchman.agents.pool import AgentPool
    from henchman.core.agent import Agent
    from henchman.core.eventbus import EventBus
    from henchman.providers.base import ModelProvider

# Backward-compat aliases used by tests
_COLON_STALL_NUDGE = COLON_STALL_NUDGE
_MAX_COLON_STALL_RETRIES = MAX_COLON_STALL_RETRIES

__all__ = [
    "_COLON_STALL_NUDGE",
    "_MAX_COLON_STALL_RETRIES",
    "AgentLoopParams",
    "CompletionStatus",
    "DelegationParams",
    "Orchestrator",
    "OrchestratorConfig",
    "OrchestratorMetrics",
    "TimeoutSummaryBuilder",
]


class Orchestrator:
    """Orchestrates a team of agents to solve complex tasks."""

    def __init__(
        self: Orchestrator,
        default_provider: ModelProvider,
        config: OrchestratorConfig | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the Orchestrator.

        Args:
            default_provider: The default model provider.
            config: Optional grouped configuration.
            **kwargs: Legacy keyword arguments (forwarded to OrchestratorConfig).
        """
        init_orchestrator(self, default_provider, config, **kwargs)

    # ------------------------------------------------------------------
    # Public run methods
    # ------------------------------------------------------------------

    async def run(
        self: Orchestrator,
        user_input: str,
    ) -> AsyncIterator[AgentEvent]:
        """Run the orchestrator with user input.

        Args:
            user_input: The user's input or task description.

        Yields:
            AgentEvent: Stream of agent events including content, tool calls,
                and completion status.
        """
        prepare_run(self, user_input)
        yield AgentEvent(
            type=EventType.AGENT_STARTED,
            data={"agent": "tech_lead"},
            source_agent="orchestrator",
        )
        async for event in self.execution_controller.run_agent_loop(
            AgentLoopParams(agent=self.tech_lead, input_text=user_input),
        ):
            yield event
        for event in finalize_run(self, self.tech_lead, "tech_lead"):
            yield event

    async def run_direct(
        self: Orchestrator,
        role: str,
        user_input: str,
    ) -> AsyncIterator[AgentEvent]:
        """Run a specific agent directly, bypassing the Tech Lead.

        Args:
            role: The role of the agent to run (e.g., "coder", "architect").
            user_input: The user's input or task description.

        Yields:
            AgentEvent: Stream of agent events including content, tool calls,
                and completion status.
        """
        agent = self.pool.get_agent(role)
        yield AgentEvent(
            type=EventType.AGENT_STARTED,
            data={"agent": role},
            source_agent="orchestrator",
        )
        async for event in self.execution_controller.run_agent_loop(
            AgentLoopParams(agent=agent, input_text=user_input),
        ):
            yield event
        for event in finalize_run(self, agent, role):
            yield event

    # ------------------------------------------------------------------
    # Public accessors
    # ------------------------------------------------------------------

    def get_metrics_report(self: Orchestrator) -> str:
        """Generate a formatted performance metrics dashboard.

        Returns:
            A formatted string containing performance metrics.
        """
        return self._reporter.get_metrics_report()

    def get_pool(self: Orchestrator) -> AgentPool:
        """Get the agent pool.

        Returns:
            The AgentPool instance used by this orchestrator.
        """
        return self.pool

    def get_event_bus(self: Orchestrator) -> EventBus:
        """Get the event bus.

        Returns:
            The EventBus instance used by this orchestrator.
        """
        return self.event_bus

    # ------------------------------------------------------------------
    # Backward-compat delegates
    # ------------------------------------------------------------------

    @property
    def _delegation_runner(self: Orchestrator) -> DelegationRunner:
        """Backward-compat alias for :attr:`delegation_runner`."""
        return self.delegation_runner

    def _assess_completion(self: Orchestrator, agent: Agent) -> CompletionStatus:
        """Backward-compat delegate to execution controller."""
        return self.execution_controller.assess_completion(agent)

    @staticmethod
    def _assemble_delegation_input(
        task: str,
        brief: dict[str, Any] | None,
        mission: str | None = None,
    ) -> str:
        """Backward-compat delegate to DelegationRunner."""
        return DelegationRunner._assemble_delegation_input(
            task,
            brief,
            mission,
        )

    @staticmethod
    def _parse_completion_report(summary: str) -> dict[str, str]:
        """Backward-compat delegate to DelegationRunner."""
        return DelegationRunner._parse_completion_report(summary)

    @staticmethod
    def _last_assistant_content(agent: Agent) -> str:
        """Return the last assistant message content."""
        return _last_assistant_content(agent)

    # ------------------------------------------------------------------
    # Delegation management methods
    # ------------------------------------------------------------------

    def get_ongoing_delegations(self: Orchestrator) -> list[dict[str, Any]]:
        """Get list of ongoing delegations.
        
        Returns:
            List of delegation information dictionaries.
        """
        return self.tool_controller.get_ongoing_delegations()

    def tail_delegation_output(self: Orchestrator, task_id: str, lines: int = 25) -> str:
        """Get the last N lines of output from a delegation.
        
        Args:
            task_id: The delegation task ID.
            lines: Number of lines to return.
            
        Returns:
            The last N lines of output.
        """
        return self.tool_controller.tail_delegation_output(task_id, lines)

    async def wait_for_delegation(
        self: Orchestrator,
        task_id: str,
        timeout: float | None = None,
    ) -> tuple[str, bool]:
        """Wait for a delegation to complete.
        
        Args:
            task_id: The delegation task ID.
            timeout: Timeout in seconds, or None for no timeout.
            
        Returns:
            Tuple of (result_content, success).
        """
        return await self.tool_controller.wait_for_delegation(task_id, timeout)

    def cancel_delegation(self: Orchestrator, task_id: str) -> bool:
        """Cancel an ongoing delegation.
        
        Args:
            task_id: The delegation task ID.
            
        Returns:
            True if delegation was cancelled, False otherwise.
        """
        return self.tool_controller.cancel_delegation(task_id)

    def submit_delegation_result(self: Orchestrator, task_id: str) -> bool:
        """Submit the result of a completed delegation to the source agent.
        
        Args:
            task_id: The delegation task ID.
            
        Returns:
            True if result was submitted, False otherwise.
        """
        return self.tool_controller.submit_delegation_result(task_id)

    def check_delegation_status(self: Orchestrator, task_id: str) -> dict[str, Any]:
        """Check the status of a delegation.
        
        Args:
            task_id: The delegation task ID.
            
        Returns:
            Dictionary with delegation status information.
        """
        return self.tool_controller.check_delegation_status(task_id)

    # ------------------------------------------------------------------
    # Chat manager compatibility methods
    # ------------------------------------------------------------------

    def submit_tool_result(self: Orchestrator, tool_id: str, result: str) -> None:
        """Submit a tool result to the tech lead agent.
        
        This method provides compatibility with the chat manager which expects
        Agent-like interface.
        
        Args:
            tool_id: The ID of the tool call.
            result: The result of the tool execution.
        """
        if hasattr(self, 'tech_lead') and self.tech_lead is not None:
            self.tech_lead.submit_tool_result(tool_id, result)
        else:
            # Fallback: log warning
            import logging
            logger = logging.getLogger(__name__)
            logger.warning(
                "Orchestrator.submit_tool_result called but tech_lead not available. "
                "Tool result for %s: %s", tool_id, result[:100]
            )

    async def continue_with_tool_results(self: Orchestrator) -> AsyncIterator[AgentEvent]:
        """Continue the tech lead agent with submitted tool results.
        
        This method provides compatibility with the chat manager which expects
        Agent-like interface.
        
        Yields:
            AgentEvent: Stream of agent events.
        """
        if hasattr(self, 'tech_lead') and self.tech_lead is not None:
            async for event in self.tech_lead.continue_with_tool_results():
                yield event
        else:
            # Fallback: yield empty stream
            import logging
            logger = logging.getLogger(__name__)
            logger.warning(
                "Orchestrator.continue_with_tool_results called but tech_lead not available."
            )
            return
