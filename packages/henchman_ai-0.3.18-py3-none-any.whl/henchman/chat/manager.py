"""Chat manager for coordinating chat bot integrations with Henchman-AI."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any

from henchman.chat.base import ChatMessage, ChatPlatform
from henchman.core.events import EventType
from henchman.providers import get_default_registry
from henchman.providers.utils import get_api_key_for_provider

if TYPE_CHECKING:
    from henchman.agents.orchestrator import Orchestrator
    from henchman.chat.base import ChatBot
    from henchman.config import Settings

logger = logging.getLogger(__name__)


class ChatManager:
    """Manages chat bot integrations and connects them to Henchman-AI agents.

    This class:
    1. Creates and manages chat bot instances
    2. Connects incoming messages to Henchman-AI agents
    3. Streams agent responses back to users
    4. Maintains per-user agent sessions

    Attributes:
        settings: Henchman-AI settings.
    """

    def __init__(self, settings: Settings) -> None:
        """Initialize the chat manager.

        Args:
            settings: Henchman-AI settings loaded from configuration.
        """
        self._settings = settings
        self._bots: dict[ChatPlatform, ChatBot] = {}
        self._user_orchestrators: dict[str, Orchestrator] = {}  # user_id -> Orchestrator
        self._user_histories: dict[str, list[dict[str, Any]]] = {}  # user_id -> messages

    def create_discord_bot(
        self,
        token: str,
        allowed_user_id: str | None = None,
        allowed_channel_ids: list[str] | None = None,
        allowed_role_ids: list[str] | None = None,
        command_prefix: str | None = None,
        status_message: str | None = None,
        typing_indicator: bool = True,
    ) -> Any:
        """Create and configure a Discord bot.

        Args:
            token: Discord bot token.
            allowed_user_id: Discord user ID authorized to use the bot.
            allowed_channel_ids: List of authorized channel IDs.
            allowed_role_ids: List of authorized role IDs.
            command_prefix: Optional prefix for bot commands.
            status_message: Custom status message for the bot.
            typing_indicator: Whether to show typing indicator.

        Returns:
            Configured DiscordBot instance.

        Raises:
            ImportError: If discord.py is not installed.
        """
        from henchman.chat.discord_bot import DiscordBot

        bot = DiscordBot(
            token=token,
            allowed_user_id=allowed_user_id,
            allowed_channel_ids=allowed_channel_ids,
            allowed_role_ids=allowed_role_ids,
            command_prefix=command_prefix,
            status_message=status_message,
            typing_indicator=typing_indicator,
        )
        bot.set_message_handler(self._handle_message)
        self._bots[ChatPlatform.DISCORD] = bot
        return bot

    async def _get_or_create_agent(self, user_id: str) -> Orchestrator:
        """Get or create an orchestrator for a user.

        Args:
            user_id: User identifier.

        Returns:
            Orchestrator instance for the user.
        """
        from henchman.agents.orchestrator import Orchestrator
        from henchman.agents.orchestrator_init import OrchestratorConfig

        if user_id in self._user_orchestrators:
            return self._user_orchestrators[user_id]

        # Create new agent for user
        registry = get_default_registry()
        provider_name = self._settings.providers.default

        # Get provider settings
        provider_settings = self._get_provider_settings(provider_name)

        provider = registry.create(provider_name, **provider_settings)

        # Use custom system prompt if configured
        system_prompt = (
            "You are Henchman-AI, a helpful AI assistant accessible via chat. "
            "You have access to a full suite of tools for file operations, code execution, "
            "web search, git operations, and more. You can help with coding, research, "
            "analysis, and automation tasks. "
            "When using tools, explain what you're doing and why. "
            "Keep responses concise but informative. "
            "Use markdown formatting for code blocks and structure."
        )

        # Override with Discord-specific system prompt if configured
        if (
            hasattr(self._settings, "chat")
            and hasattr(self._settings.chat, "discord")
            and self._settings.chat.discord.system_prompt
        ):
            system_prompt = self._settings.chat.discord.system_prompt

        # Register built-in tools for the agent
        from henchman.cli.tool_manager import ToolManager

        tool_manager = ToolManager(self._settings)
        tool_manager.register_builtin_tools()

        # Auto-approve all tools for Discord (non-interactive mode)
        tool_manager.set_auto_approve(auto_approve=True)

        # Create OrchestratorConfig with tool registry
        config = OrchestratorConfig(
            tool_registry=tool_manager.registry,
            settings=self._settings,
            system_prompt=system_prompt,
        )

        orchestrator = Orchestrator(
            default_provider=provider,
            config=config,
        )

        self._user_orchestrators[user_id] = orchestrator
        self._user_histories[user_id] = []

        logger.info("Created new orchestrator for user %s with %d tools",
                    user_id, len(tool_manager.registry.list_tools()))
        return orchestrator

    def _get_provider_defaults(self, provider_name: str) -> dict[str, Any]:
        """Get default settings for a provider.

        Args:
            provider_name: Name of the provider.

        Returns:
            Dictionary of default provider settings.
        """
        defaults: dict[str, Any] = {}

        # Add API key from environment if available
        api_key = get_api_key_for_provider(provider_name)
        if api_key:
            defaults["api_key"] = api_key

        # Add provider-specific defaults
        if provider_name == "deepseek":
            defaults.setdefault("model", "deepseek-chat")
        elif provider_name == "ollama":
            defaults.setdefault("model", "llama3.2")
        elif provider_name == "anthropic":
            defaults.setdefault("model", "claude-3-5-sonnet-20241022")
        elif provider_name == "openai_compat":
            # For generic OpenAI-compatible, we need at least a model
            defaults.setdefault("model", "gpt-4o-mini")
        elif provider_name == "openrouter":
            defaults.setdefault("model", "openai/gpt-4o-mini")
        elif provider_name == "together":
            defaults.setdefault("model", "meta-llama/Llama-3.2-3B-Instruct-Turbo")
        elif provider_name == "groq":
            defaults.setdefault("model", "llama-3.1-8b-instant")
        elif provider_name == "fireworks":
            defaults.setdefault("model", "accounts/fireworks/models/llama-v3p1-8b-instruct")

        return defaults

    def _get_provider_settings(self, provider_name: str) -> dict[str, Any]:
        """Get provider settings for the given provider name.

        Args:
            provider_name: Name of the provider.

        Returns:
            Dictionary of provider settings.
        """
        provider_settings_map = {
            "deepseek": "deepseek",
            "openai": "openai",
            "anthropic": "anthropic",
            "ollama": "ollama",
            "openrouter": "openrouter",
            "openai_compat": "openai_compat",
            "together": "together",
            "groq": "groq",
            "fireworks": "fireworks",
        }

        if provider_name not in provider_settings_map:
            return {}

        settings_attr = provider_settings_map[provider_name]
        provider_settings = getattr(self._settings.providers, settings_attr, None)

        if provider_settings is not None:
            # Handle case where provider_settings is not a dict
            # (e.g., string from misconfigured YAML)
            if isinstance(provider_settings, dict):
                return dict(provider_settings)
            else:
                # Log warning and return defaults
                logger.warning(
                    "Provider '%s' settings is not a dictionary (type: %s). "
                    "Using defaults instead. Please fix configuration.",
                    provider_name,
                    type(provider_settings).__name__,
                )
                # Return defaults directly instead of falling through
                # to avoid duplicate warning
                return self._get_provider_defaults(provider_name)

        # Provider settings are missing - return reasonable defaults
        # This fixes the bug where empty dict {} was returned
        defaults = self._get_provider_defaults(provider_name)

        logger.warning(
            "Provider '%s' is configured as default but has no settings. "
            "Using defaults: %s. Please configure provider settings in your configuration.",
            provider_name,
            {k: "***" if "key" in k.lower() else v for k, v in defaults.items()},
        )

        return defaults

    async def _process_stream(
        self,
        agent: Orchestrator,
        bot: Any,
        user_id: str,
        stream: Any,
        response_parts: list[str],
        current_chunk: str,
        max_iterations: int = 2500,
    ) -> tuple[list[str], str]:
        """Process an agent stream, collecting content and displaying tool notifications.

        The Orchestrator handles all tool execution internally.  This method
        only collects text content (forwarding it to the chat platform) and
        displays informational notifications for tool calls and results so the
        user can see what operations are being performed.

        Args:
            agent: The orchestrator instance (tools executed internally).
            bot: The chat bot instance.
            user_id: The user ID.
            stream: Async iterator of agent events.
            response_parts: List to collect response chunks.
            current_chunk: Current content chunk being accumulated.
            max_iterations: Safety limit to prevent infinite loops (events per turn).

        Returns:
            Tuple of (response_parts, current_chunk).
        """
        iteration = 0
        async for event in stream:
            iteration += 1
            if iteration > max_iterations:
                logger.warning("Max stream iterations reached for user %s", user_id)
                await bot.send_message(
                    user_id,
                    "⚠️ Maximum response length exceeded. Stopping.",
                )
                break

            if event.type == EventType.CONTENT:
                current_chunk += event.data

                # Check if we should flush the chunk.
                # Avoid splitting inside a code block if possible, unless
                # the chunk is getting very large.
                should_flush = False
                chunk_len = len(current_chunk)

                if chunk_len >= 1800:
                    # Basic check: are we inside a code block?
                    is_in_code_block = current_chunk.count("```") % 2 != 0

                    if not is_in_code_block:
                        should_flush = True
                    elif chunk_len >= 2500:
                        # Safety limit: flush anyway, let the bot's splitter handle it
                        should_flush = True

                if should_flush:
                    await bot.send_message(user_id, current_chunk)
                    response_parts.append(current_chunk)
                    current_chunk = ""

            elif event.type == EventType.TOOL_CALL_REQUEST:
                # The Orchestrator executes tools internally; we only notify the user.
                if current_chunk:
                    await bot.send_message(user_id, current_chunk)
                    response_parts.append(current_chunk)
                    current_chunk = ""

                tool_name = getattr(event.data, "name", "unknown")
                await bot.send_message(user_id, f"🔧 Running: `{tool_name}`")

            elif event.type == EventType.TOOL_CALL_RESULT:
                # Display the tool result summary to the user.
                result_data = event.data or {}
                tool_name = result_data.get("tool_name", "tool")
                success = result_data.get("success", True)
                content = result_data.get("content", "")
                if isinstance(content, str) and len(content) > 1500:
                    display_result = content[:1500] + "\n... (truncated)"
                else:
                    display_result = str(content) if content else ""

                if success and display_result:
                    await bot.send_message(
                        user_id,
                        f"✅ Result:\n```\n{display_result}\n```",
                    )
                elif not success:
                    await bot.send_message(
                        user_id,
                        f"❌ Tool `{tool_name}` failed: {display_result}",
                    )

            elif event.type == EventType.FINISHED:
                break

            elif event.type == EventType.ERROR:
                logger.error("Agent error for user %s: %s", user_id, event.data)
                await bot.send_message(user_id, f"❌ Error: {event.data}")
                break

        return response_parts, current_chunk

    async def _handle_message(self, message: ChatMessage) -> None:
        """Handle an incoming chat message.

        Streams the Orchestrator's response to the chat platform.  The
        Orchestrator manages the complete agent loop (tool execution,
        delegation, stall detection) internally; this method only needs
        to forward content and status notifications to the user.

        Args:
            message: The incoming chat message.

        Returns:
            None
        """
        logger.info(
            "Received message from %s (ID: %s): %s",
            message.username,
            message.user_id,
            message.content[:100],
        )

        # Handle special commands
        if message.content.startswith("/"):
            await self._handle_command(message)
            return

        # Get or create agent for user
        agent = await self._get_or_create_agent(message.user_id)

        # Get the bot for this platform
        bot = self._bots.get(message.platform)
        if not bot:
            logger.error("No bot found for platform %s", message.platform)
            return

        # Send typing indicator
        await bot.send_typing(message.user_id)

        # Collect response parts
        response_parts: list[str] = []
        current_chunk = ""

        try:
            # Run the orchestrator — it handles the full agent loop internally
            # (tool calls, delegations, stall detection, etc.).
            stream = agent.run(user_input=message.content)
            response_parts, current_chunk = await self._process_stream(
                agent, bot, message.user_id, stream, response_parts, current_chunk
            )

            # Send remaining content
            if current_chunk:
                await bot.send_message(message.user_id, current_chunk)
                response_parts.append(current_chunk)

            # Store in history
            if response_parts:
                self._user_histories.setdefault(message.user_id, []).extend(
                    [
                        {"role": "user", "content": message.content},
                        {"role": "assistant", "content": "\n".join(response_parts)},
                    ]
                )

        except Exception:
            logger.exception("Error processing message from %s", message.user_id)
            await bot.send_message(
                message.user_id,
                "❌ Sorry, an error occurred while processing your request. Please try again.",
            )

    async def _handle_command(self, message: ChatMessage) -> None:
        """Handle special chat commands.

        Args:
            message: The incoming chat message.

        Returns:
            None
        """
        bot = self._bots.get(message.platform)
        if not bot:
            return

        parts = message.content.split()
        command = parts[0].lower()
        _args = parts[1:]  # Reserved for future use

        if command == "/help":
            help_text = (
                "**Henchman-AI Commands**\n\n"
                "`/help` - Show this help message\n"
                "`/clear` - Clear conversation history\n"
                "`/status` - Show bot status and stats\n"
                "`/history` - Show conversation history summary\n"
                "`/model` - Manage AI model and provider\n\n"
                "**Usage:**\n"
                "Just type your message and I'll respond! I can help with:\n"
                "• Code questions and programming\n"
                "• File operations and shell commands\n"
                "• Web research and information\n"
                "• Analysis and problem-solving"
            )
            await bot.send_message(message.user_id, help_text)

        elif command == "/model":
            # Subcommands: list, set <provider> [model], or just /model to show current
            if not _args:
                # Show current model
                orchestrator = self._user_orchestrators.get(message.user_id)
                if orchestrator and hasattr(orchestrator, "tech_lead"):
                    provider = orchestrator.tech_lead.provider
                    model_name = getattr(provider, "model", "unknown")
                    # Try to get model from config if provider doesn't expose it
                    if model_name == "unknown" and hasattr(orchestrator.tech_lead, "_config"):
                         model_name = getattr(orchestrator.tech_lead._config, "model", "unknown")

                    provider_class = type(provider).__name__
                    # Try to map class name back to friendly name
                    friendly_name = provider_class.replace("Provider", "")

                    await bot.send_message(
                        message.user_id,
                        f"**Current Model**\n\n• **Provider:** {friendly_name}\n• **Model:** {model_name}"
                    )
                else:
                    # Fallback to default settings
                    default_provider = self._settings.providers.default
                    defaults = self._get_provider_defaults(default_provider)
                    await bot.send_message(
                        message.user_id,
                        f"**Default Model (Not Initialized)**\n\n• **Provider:** {default_provider}\n• **Model:** {defaults.get('model', 'unknown')}"
                    )
                return

            subcommand = _args[0].lower()

            if subcommand == "list":
                # List available providers
                registry = get_default_registry()
                providers = registry.list_providers()
                provider_list = "\n".join([f"• `{p}`" for p in providers])
                await bot.send_message(
                    message.user_id,
                    f"**Available Providers**\n\n{provider_list}\n\nUse `/model <provider> [model]` to switch."
                )

            else:
                # Assume it's a provider name
                provider_name = subcommand
                model_name = _args[1] if len(_args) > 1 else None

                registry = get_default_registry()
                if provider_name not in registry.list_providers():
                     await bot.send_message(
                        message.user_id,
                        f"❌ Unknown provider: `{provider_name}`. Use `/model list` to see available providers."
                    )
                     return

                # Get settings or defaults
                provider_settings = self._get_provider_settings(provider_name)
                if model_name:
                    provider_settings["model"] = model_name

                try:
                    # Create new provider
                    new_provider = registry.create(provider_name, **provider_settings)

                    # Get or create orchestrator
                    orchestrator = await self._get_or_create_agent(message.user_id)

                    # Update orchestrator default provider
                    orchestrator.default_provider = new_provider

                    # Update pool default provider and clear cache
                    if hasattr(orchestrator, "pool"):
                        orchestrator.pool.default_provider = new_provider
                        # Clear agent cache to force recreation with new provider
                        orchestrator.pool._agents.clear()

                    # Update tech lead provider
                    if hasattr(orchestrator, "tech_lead"):
                         orchestrator.tech_lead.provider = new_provider
                         # Update model config if changed
                         if model_name:
                             orchestrator.tech_lead._config.model = model_name

                    await bot.send_message(
                        message.user_id,
                        f"✅ Switched to **{provider_name}**" + (f" ({model_name})" if model_name else "")
                    )

                except Exception as e:
                    logger.exception("Failed to switch provider")
                    await bot.send_message(
                        message.user_id,
                        f"❌ Failed to switch provider: {e}"
                    )

        elif command == "/clear":
            if message.user_id in self._user_orchestrators:
                # Orchestrator doesn't have clear_history method, but we can clear the tech lead's history
                orchestrator = self._user_orchestrators[message.user_id]
                if hasattr(orchestrator, 'tech_lead') and orchestrator.tech_lead is not None:
                    orchestrator.tech_lead.clear_history()
            self._user_histories[message.user_id] = []
            await bot.send_message(
                message.user_id,
                "✅ Conversation history cleared!",
            )

        elif command == "/status":
            agent = self._user_orchestrators.get(message.user_id)
            provider_name = self._settings.providers.default
            history_count = len(self._user_histories.get(message.user_id, []))

            status_text = (
                "**Henchman-AI Status**\n\n"
                f"• **Provider:** {provider_name}\n"
                f"• **Agent:** {'Active' if agent else 'Not initialized'}\n"
                f"• **Messages in history:** {history_count}\n"
                f"• **Platform:** {message.platform.value}"
            )
            await bot.send_message(message.user_id, status_text)

        elif command == "/history":
            history = self._user_histories.get(message.user_id, [])
            if not history:
                await bot.send_message(
                    message.user_id,
                    "No conversation history yet.",
                )
                return

            # Show last 5 exchanges
            recent = history[-10:]  # Last 5 exchanges (user + assistant)
            history_text = "**Recent Conversation:**\n\n"
            for msg in recent:
                role = "**You:**" if msg["role"] == "user" else "**Henchman:**"
                content = msg["content"][:100] + ("..." if len(msg["content"]) > 100 else "")
                history_text += f"{role} {content}\n\n"

            await bot.send_message(message.user_id, history_text)

        else:
            await bot.send_message(
                message.user_id,
                f"❓ Unknown command: `{command}`. Type `/help` for available commands.",
            )

    async def start_all(self) -> None:
        """Start all configured bots.

        Returns:
            None
        """
        tasks = []
        for bot in self._bots.values():
            logger.info("Starting %s bot...", bot.platform.value)
            tasks.append(asyncio.create_task(bot.start()))

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def stop_all(self) -> None:
        """Stop all running bots.

        Returns:
            None
        """
        for bot in self._bots.values():
            if bot.is_connected:
                logger.info("Stopping %s bot...", bot.platform.value)
                await bot.stop()

    @property
    def bots(self) -> dict[ChatPlatform, ChatBot]:
        """Get all configured bots.

        Returns:
            Dictionary mapping platforms to bot instances.
        """
        return self._bots

    @property
    def active_users(self) -> list[str]:
        """Get list of user IDs with active agents.

        Returns:
            List of user ID strings.
        """
        return list(self._user_orchestrators.keys())
