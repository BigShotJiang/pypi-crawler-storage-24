"""Chat serve command for starting chat bot integrations."""

from __future__ import annotations

import asyncio
from typing import Any

import click
from rich.console import Console

from henchman.config import load_settings


@click.command(name="discordbot")
@click.option(
    "--platform",
    type=click.Choice(["discord"], case_sensitive=False),
    default="discord",
    help="Chat platform to use",
    show_default=True,
)
@click.option(
    "--token",
    envvar="DISCORD_TOKEN",
    help="Bot token (or set DISCORD_TOKEN env var)",
)
@click.option(
    "--user-id",
    envvar="DISCORD_USER_ID",
    help="Authorized user ID (or set DISCORD_USER_ID env var)",
)
@click.option("--provider", help="Model provider (e.g. openai, deepseek)")
@click.option("--model", help="Specific model to use")
@click.option(
    "--work-dir",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, resolve_path=True),
    help="Working directory for the agent (overrides settings)",
)
def discordbot_command(
    platform: str,
    token: str | None,
    user_id: str | None,
    provider: str | None,
    model: str | None,
    work_dir: str | None,
) -> None:
    """Start a chat bot for remote Henchman-AI access.

    This command starts a chat bot (e.g., Discord) that allows you to
    interact with Henchman-AI remotely from your phone or browser.

    Args:
        platform: Chat platform to use (currently only "discord" supported).
        token: Bot token for the chat platform. Can be provided via CLI,
            environment variable (DISCORD_TOKEN), or settings file.
        user_id: Authorized user ID for the chat platform. Can be provided
            via CLI, environment variable (DISCORD_USER_ID), or settings file.
        provider: Model provider to use (overrides settings).
        model: Specific model to use (overrides settings).
        work_dir: Working directory for the agent (overrides settings).

    Returns:
        None. This is a Click command that starts a bot and runs until
        interrupted.

    Examples:
        henchman chatbot
        henchman chatbot --platform discord
        DISCORD_TOKEN=xxx DISCORD_USER_ID=yyy henchman chatbot
    """
    print("TRACE: Start discordbot_command", flush=True)
    import os
    from pathlib import Path

    console = Console()

    # Load settings
    print("TRACE: Loading settings", flush=True)
    settings = load_settings()
    print("TRACE: Settings loaded", flush=True)

    # Handle working directory
    # Priority: CLI flag > Settings > Current Directory
    target_work_dir: str | None = work_dir

    print("TRACE: Checking target_work_dir", flush=True)
    if not target_work_dir and hasattr(settings, "chat") and settings.chat.discord.working_directory:
        print("TRACE: Getting target_work_dir from settings", flush=True)
        target_work_dir = settings.chat.discord.working_directory

    print("TRACE: target_work_dir is", target_work_dir, flush=True)
    if target_work_dir:
        target_path = Path(target_work_dir).resolve()
        print("TRACE: target_path is", target_path, flush=True)
        if not target_path.exists() or not target_path.is_dir():
             console.print(f"[red]Error:[/] Working directory does not exist: {target_path}")
             raise click.Abort

        try:
            print(f"TRACE: chdir to {target_path}", flush=True)
            os.chdir(target_path)
        except Exception as e:
             console.print(f"[red]Error:[/] Failed to change working directory to {target_path}: {e}")
             raise click.Abort

    # Apply CLI overrides for provider/model
    print("TRACE: Checking provider/model", flush=True)
    if provider:
        settings.providers.default = provider

    target_provider = settings.providers.default
    print("TRACE: target_provider is", target_provider, flush=True)
    if model:
        # Get existing config or create empty dict
        print("TRACE: Applying model override", flush=True)
        current_config = getattr(settings.providers, target_provider, {}) or {}
        if not isinstance(current_config, dict):
             current_config = {}

        current_config["model"] = model
        setattr(settings.providers, target_provider, current_config)

    # Get token and user ID from settings if not provided via CLI/env
    print("TRACE: Getting token and user_id", flush=True)
    if token is None and hasattr(settings, "chat") and settings.chat.discord.token:
        print("TRACE: Getting token from settings", flush=True)
        token = settings.chat.discord.token
    if user_id is None and hasattr(settings, "chat") and settings.chat.discord.allowed_user_id:
        print("TRACE: Getting user_id from settings", flush=True)
        user_id = settings.chat.discord.allowed_user_id

    # Validate required parameters
    print(f"TRACE: Validating token: {token}", flush=True)
    if not token:
        console.print(
            "[red]Error:[/] Discord bot token is required.\n\n"
            "Set it via:\n"
            "  • Environment variable: [cyan]DISCORD_TOKEN[/]\n"
            "  • CLI flag: [cyan]--token <TOKEN>[/]\n"
            "  • Settings file: [cyan]chat.discord.token[/]"
        )
        raise click.Abort

    discord_config = settings.chat.discord
    has_auth = (
        user_id
        or discord_config.allowed_user_id
        or discord_config.allowed_channel_ids
        or discord_config.allowed_role_ids
    )

    if not has_auth:
        console.print(
            "[red]Error:[/] At least one authorization method is required.\n\n"
            "Provide one of:\n"
            "  • User ID (via CLI/Env/Settings)\n"
            "  • Allowed Channels (via Settings)\n"
            "  • Allowed Roles (via Settings)\n\n"
            "[dim]To find your Discord user ID:\n"
            "  1. Enable Developer Mode in Discord settings\n"
            "  2. Right-click your username → Copy User ID[/]"
        )
        raise click.Abort

    # Show startup info
    console.print("[bold green]Starting Henchman-AI chat bot...[/]")
    console.print(f"  Platform: [cyan]{platform}[/]")
    console.print(f"  Provider: [cyan]{settings.providers.default}[/]")
    console.print(f"  Working Directory: [cyan]{os.getcwd()}[/]")
    if user_id:
        console.print(f"  User ID: [cyan]{user_id}[/]")

    if discord_config.allowed_channel_ids:
        console.print(f"  Allowed Channels: [cyan]{len(discord_config.allowed_channel_ids)}[/]")
    if discord_config.allowed_role_ids:
        console.print(f"  Allowed Roles: [cyan]{len(discord_config.allowed_role_ids)}[/]")
    if discord_config.command_prefix:
        console.print(f"  Command Prefix: [cyan]{discord_config.command_prefix}[/]")

    console.print()
    console.print("[bold yellow]How to interact with the bot:[/]")
    console.print("  • [cyan]Send a DM[/] to the bot directly")
    console.print("  • [cyan]Mention the bot[/] in a server channel (e.g., @Henchman-AI help)")
    if discord_config.command_prefix:
        console.print(f"  • Use prefix [cyan]{discord_config.command_prefix}[/] (e.g., {discord_config.command_prefix}help)")

    console.print("  • Type [cyan]/help[/] for available commands")
    console.print()
    console.print("[dim]Press Ctrl+C to stop the bot[/]\n")

    # Run the bot
    try:
        asyncio.run(_run_discord_bot(token, user_id, settings))
    except KeyboardInterrupt:
        console.print("\n[yellow]Bot stopped by user[/]")
    except ImportError as e:
        console.print(f"\n[red]{e}[/]")
        raise click.Abort from e
    except Exception as e:
        console.print(f"\n[red]Error starting bot: {e}[/]")
        raise click.Abort from e


async def _run_discord_bot(
    token: str,
    user_id: str | None,
    settings: Any,
) -> None:
    """Run the Discord bot.

    Args:
        token: Discord bot token.
        user_id: Authorized user ID (optional if other auth methods set).
        settings: Henchman-AI settings.

    Returns:
        None
    """
    from henchman.chat.manager import ChatManager

    manager = ChatManager(settings)

    # Extract optional settings
    discord_settings = getattr(settings.chat, "discord", None)
    allowed_channel_ids = discord_settings.allowed_channel_ids if discord_settings else []
    allowed_role_ids = discord_settings.allowed_role_ids if discord_settings else []
    command_prefix = discord_settings.command_prefix if discord_settings else None
    status_message = discord_settings.status_message if discord_settings else None
    typing_indicator = discord_settings.typing_indicator if discord_settings else True

    manager.create_discord_bot(
        token=token,
        allowed_user_id=user_id,
        allowed_channel_ids=allowed_channel_ids,
        allowed_role_ids=allowed_role_ids,
        command_prefix=command_prefix,
        status_message=status_message,
        typing_indicator=typing_indicator,
    )

    try:
        await manager.start_all()
    finally:
        await manager.stop_all()
