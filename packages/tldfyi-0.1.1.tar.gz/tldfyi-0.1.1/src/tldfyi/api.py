"""HTTP API client for tldfyi.com REST endpoints.

Requires the ``api`` extra: ``pip install tldfyi[api]``

Usage::

    from tldfyi.api import TLDFYI

    with TLDFYI() as api:
        items = api.list_brands()
        detail = api.get_brand("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class TLDFYI:
    """API client for the tldfyi.com REST API.

    Provides typed access to all tldfyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://tldfyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://tldfyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_brands(self, **params: Any) -> dict[str, Any]:
        """List all brands."""
        return self._get("/api/v1/rest/brands/", **params)

    def get_brand(self, slug: str) -> dict[str, Any]:
        """Get brand by slug."""
        return self._get(f"/api/v1/rest/brands/" + slug + "/")

    def list_collections(self, **params: Any) -> dict[str, Any]:
        """List all collections."""
        return self._get("/api/v1/rest/collections/", **params)

    def get_collection(self, slug: str) -> dict[str, Any]:
        """Get collection by slug."""
        return self._get(f"/api/v1/rest/collections/" + slug + "/")

    def list_comparisons(self, **params: Any) -> dict[str, Any]:
        """List all comparisons."""
        return self._get("/api/v1/rest/comparisons/", **params)

    def get_comparison(self, slug: str) -> dict[str, Any]:
        """Get comparison by slug."""
        return self._get(f"/api/v1/rest/comparisons/" + slug + "/")

    def list_continents(self, **params: Any) -> dict[str, Any]:
        """List all continents."""
        return self._get("/api/v1/rest/continents/", **params)

    def get_continent(self, slug: str) -> dict[str, Any]:
        """Get continent by slug."""
        return self._get(f"/api/v1/rest/continents/" + slug + "/")

    def list_countries(self, **params: Any) -> dict[str, Any]:
        """List all countries."""
        return self._get("/api/v1/rest/countries/", **params)

    def get_country(self, slug: str) -> dict[str, Any]:
        """Get country by slug."""
        return self._get(f"/api/v1/rest/countries/" + slug + "/")

    def list_domain_hacks(self, **params: Any) -> dict[str, Any]:
        """List all domain hacks."""
        return self._get("/api/v1/rest/domain-hacks/", **params)

    def get_domain_hack(self, slug: str) -> dict[str, Any]:
        """Get domain hack by slug."""
        return self._get(f"/api/v1/rest/domain-hacks/" + slug + "/")

    def list_faq_categories(self, **params: Any) -> dict[str, Any]:
        """List all faq categories."""
        return self._get("/api/v1/rest/faq-categories/", **params)

    def get_faq_category(self, slug: str) -> dict[str, Any]:
        """Get faq category by slug."""
        return self._get(f"/api/v1/rest/faq-categories/" + slug + "/")

    def list_faq_entries(self, **params: Any) -> dict[str, Any]:
        """List all faq entries."""
        return self._get("/api/v1/rest/faq-entries/", **params)

    def get_faq_entry(self, slug: str) -> dict[str, Any]:
        """Get faq entry by slug."""
        return self._get(f"/api/v1/rest/faq-entries/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/rest/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/rest/faqs/" + slug + "/")

    def list_glossary_categories(self, **params: Any) -> dict[str, Any]:
        """List all glossary categories."""
        return self._get("/api/v1/rest/glossary-categories/", **params)

    def get_glossary_category(self, slug: str) -> dict[str, Any]:
        """Get glossary category by slug."""
        return self._get(f"/api/v1/rest/glossary-categories/" + slug + "/")

    def list_glossary_terms(self, **params: Any) -> dict[str, Any]:
        """List all glossary terms."""
        return self._get("/api/v1/rest/glossary-terms/", **params)

    def get_glossary_term(self, slug: str) -> dict[str, Any]:
        """Get glossary term by slug."""
        return self._get(f"/api/v1/rest/glossary-terms/" + slug + "/")

    def list_guide_series(self, **params: Any) -> dict[str, Any]:
        """List all guide series."""
        return self._get("/api/v1/rest/guide-series/", **params)

    def get_guide_sery(self, slug: str) -> dict[str, Any]:
        """Get guide sery by slug."""
        return self._get(f"/api/v1/rest/guide-series/" + slug + "/")

    def list_guides(self, **params: Any) -> dict[str, Any]:
        """List all guides."""
        return self._get("/api/v1/rest/guides/", **params)

    def get_guide(self, slug: str) -> dict[str, Any]:
        """Get guide by slug."""
        return self._get(f"/api/v1/rest/guides/" + slug + "/")

    def list_industries(self, **params: Any) -> dict[str, Any]:
        """List all industries."""
        return self._get("/api/v1/rest/industries/", **params)

    def get_industry(self, slug: str) -> dict[str, Any]:
        """Get industry by slug."""
        return self._get(f"/api/v1/rest/industries/" + slug + "/")

    def list_pricing(self, **params: Any) -> dict[str, Any]:
        """List all pricing."""
        return self._get("/api/v1/rest/pricing/", **params)

    def get_pricing(self, slug: str) -> dict[str, Any]:
        """Get pricing by slug."""
        return self._get(f"/api/v1/rest/pricing/" + slug + "/")

    def list_registrar_comparisons(self, **params: Any) -> dict[str, Any]:
        """List all registrar comparisons."""
        return self._get("/api/v1/rest/registrar-comparisons/", **params)

    def get_registrar_comparison(self, slug: str) -> dict[str, Any]:
        """Get registrar comparison by slug."""
        return self._get(f"/api/v1/rest/registrar-comparisons/" + slug + "/")

    def list_registrars(self, **params: Any) -> dict[str, Any]:
        """List all registrars."""
        return self._get("/api/v1/rest/registrars/", **params)

    def get_registrar(self, slug: str) -> dict[str, Any]:
        """Get registrar by slug."""
        return self._get(f"/api/v1/rest/registrars/" + slug + "/")

    def list_registries(self, **params: Any) -> dict[str, Any]:
        """List all registries."""
        return self._get("/api/v1/rest/registries/", **params)

    def get_registry(self, slug: str) -> dict[str, Any]:
        """Get registry by slug."""
        return self._get(f"/api/v1/rest/registries/" + slug + "/")

    def list_stat_snapshots(self, **params: Any) -> dict[str, Any]:
        """List all stat snapshots."""
        return self._get("/api/v1/rest/stat-snapshots/", **params)

    def get_stat_snapshot(self, slug: str) -> dict[str, Any]:
        """Get stat snapshot by slug."""
        return self._get(f"/api/v1/rest/stat-snapshots/" + slug + "/")

    def list_timeline_eras(self, **params: Any) -> dict[str, Any]:
        """List all timeline eras."""
        return self._get("/api/v1/rest/timeline-eras/", **params)

    def get_timeline_era(self, slug: str) -> dict[str, Any]:
        """Get timeline era by slug."""
        return self._get(f"/api/v1/rest/timeline-eras/" + slug + "/")

    def list_timeline_events(self, **params: Any) -> dict[str, Any]:
        """List all timeline events."""
        return self._get("/api/v1/rest/timeline-events/", **params)

    def get_timeline_event(self, slug: str) -> dict[str, Any]:
        """Get timeline event by slug."""
        return self._get(f"/api/v1/rest/timeline-events/" + slug + "/")

    def list_tlds(self, **params: Any) -> dict[str, Any]:
        """List all tlds."""
        return self._get("/api/v1/rest/tlds/", **params)

    def get_tld(self, slug: str) -> dict[str, Any]:
        """Get tld by slug."""
        return self._get(f"/api/v1/rest/tlds/" + slug + "/")

    def list_tools(self, **params: Any) -> dict[str, Any]:
        """List all tools."""
        return self._get("/api/v1/rest/tools/", **params)

    def get_tool(self, slug: str) -> dict[str, Any]:
        """Get tool by slug."""
        return self._get(f"/api/v1/rest/tools/" + slug + "/")

    def list_use_cases(self, **params: Any) -> dict[str, Any]:
        """List all use cases."""
        return self._get("/api/v1/rest/use-cases/", **params)

    def get_use_case(self, slug: str) -> dict[str, Any]:
        """Get use case by slug."""
        return self._get(f"/api/v1/rest/use-cases/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/rest/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> TLDFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
