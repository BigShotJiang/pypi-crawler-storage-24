"""MCP server for tldfyi — AI assistant tools for tldfyi.com.

Run: uvx --from "tldfyi[mcp]" python -m tldfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("TLDFYI")


@mcp.tool()
def list_collections(limit: int = 20, offset: int = 0) -> str:
    """List collections from tldfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from tldfyi.api import TLDFYI

    with TLDFYI() as api:
        data = api.list_collections(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No collections found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_collection(slug: str) -> str:
    """Get detailed information about a specific collection.

    Args:
        slug: URL slug identifier for the collection.
    """
    from tldfyi.api import TLDFYI

    with TLDFYI() as api:
        data = api.get_collection(slug)
        return str(data)


@mcp.tool()
def list_domain_hacks(limit: int = 20, offset: int = 0) -> str:
    """List domain_hacks from tldfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from tldfyi.api import TLDFYI

    with TLDFYI() as api:
        data = api.list_domain_hacks(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No domain_hacks found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_tld(query: str) -> str:
    """Search tldfyi.com for TLD extensions, domain hacks, and WHOIS data.

    Args:
        query: Search query string.
    """
    from tldfyi.api import TLDFYI

    with TLDFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
