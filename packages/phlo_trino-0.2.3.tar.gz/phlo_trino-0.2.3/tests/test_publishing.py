"""Tests for Trino publishing helpers."""

from __future__ import annotations

from types import SimpleNamespace

from phlo.hooks.events import LineageEvent, PublishEvent, TelemetryEvent
import phlo_trino.publishing as publishing
from phlo_trino.publishing import (
    _describe_trino_table,
    _is_retryable_introspection_error,
    _trino_table_ref_candidates,
    _resolve_publish_target,
)


class _FakeCursor:
    """Test cursor double that replays canned Trino responses."""

    def __init__(self, trino: "_FakeTrino") -> None:
        """Initialize the fake cursor.

        Args:
            trino: Parent fake Trino client.
        """
        self._trino = trino
        self._rows: list[tuple[object, ...]] = []

    def __enter__(self) -> "_FakeCursor":
        """Return this cursor instance for context-manager usage."""
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # noqa: ANN001
        """Close the context manager.

        Args:
            exc_type: Exception type raised in the context block.
            exc: Exception instance raised in the context block.
            tb: Traceback raised in the context block.
        """
        return None

    def execute(self, query: str) -> None:
        """Execute a fake query and store returned rows.

        Args:
            query: SQL query text used as response lookup key.
        """
        self._trino.queries.append(query)
        response = self._trino.get_response(query)
        if isinstance(response, Exception):
            raise response
        self._rows = list(response or [])

    def fetchall(self) -> list[tuple[object, ...]]:
        """Return rows from the last executed query."""
        return self._rows


class _FakeTrino:
    """Test Trino client double with deterministic query responses."""

    def __init__(
        self,
        responses: dict[str, object],
        sequence_responses: dict[str, list[object]] | None = None,
    ) -> None:
        """Initialize the fake Trino client.

        Args:
            responses: Static response map by SQL query.
            sequence_responses: Queued responses consumed per repeated query.
        """
        self.responses = responses
        self.sequence_responses = {
            query: list(values) for query, values in (sequence_responses or {}).items()
        }
        self.queries: list[str] = []

    def get_response(self, query: str) -> object:
        """Resolve the next configured response for a query.

        Args:
            query: SQL query text.

        Returns:
            The next queued response when configured, otherwise static response.
        """
        queued = self.sequence_responses.get(query)
        if queued:
            return queued.pop(0)
        return self.responses.get(query)

    def cursor(self) -> _FakeCursor:
        """Create a fake cursor bound to this client."""
        return _FakeCursor(self)


def test_trino_table_ref_candidates_include_three_and_two_part_variants() -> None:
    """Ensures table reference candidates include three-part and schema/table forms."""
    refs = _trino_table_ref_candidates("iceberg.raw_marts.posts_mart")

    assert refs == [
        '"iceberg"."raw_marts"."posts_mart"',
        "iceberg.raw_marts.posts_mart",
        '"raw_marts"."posts_mart"',
        "raw_marts.posts_mart",
    ]


def test_describe_trino_table_falls_back_to_schema_table_reference() -> None:
    """Verifies fallback to schema/table reference after catalog-qualified failures."""
    trino = _FakeTrino(
        {
            'DESCRIBE "iceberg"."raw_marts"."posts_mart"': RuntimeError("http 404"),
            'SHOW COLUMNS FROM "iceberg"."raw_marts"."posts_mart"': RuntimeError("http 404"),
            "DESCRIBE iceberg.raw_marts.posts_mart": RuntimeError("http 404"),
            "SHOW COLUMNS FROM iceberg.raw_marts.posts_mart": RuntimeError("http 404"),
            'DESCRIBE "raw_marts"."posts_mart"': [
                ("id", "bigint"),
                ("title", "varchar"),
            ],
        }
    )

    columns, resolved_ref = _describe_trino_table(trino, "iceberg.raw_marts.posts_mart")

    assert resolved_ref == '"raw_marts"."posts_mart"'
    assert columns == [
        ("id", "bigint", '"id"'),
        ("title", "text", '"title"'),
    ]
    assert trino.queries[:3] == [
        'DESCRIBE "iceberg"."raw_marts"."posts_mart"',
        "DESCRIBE iceberg.raw_marts.posts_mart",
        'DESCRIBE "raw_marts"."posts_mart"',
    ]
    assert 'SHOW COLUMNS FROM "iceberg"."raw_marts"."posts_mart"' not in trino.queries
    assert "SHOW COLUMNS FROM iceberg.raw_marts.posts_mart" not in trino.queries


def test_describe_trino_table_retries_after_table_not_found() -> None:
    """Verifies retry occurs when introspection fails with table-not-found error."""
    trino = _FakeTrino(
        responses={},
        sequence_responses={
            'DESCRIBE "iceberg"."raw_marts"."posts_mart"': [
                RuntimeError(
                    "TrinoUserError(type=USER_ERROR, name=TABLE_NOT_FOUND, "
                    'message="table does not exist")'
                ),
                [("id", "bigint"), ("title", "varchar")],
            ]
        },
    )

    columns, resolved_ref = _describe_trino_table(trino, "iceberg.raw_marts.posts_mart")

    assert resolved_ref == '"iceberg"."raw_marts"."posts_mart"'
    assert columns == [
        ("id", "bigint", '"id"'),
        ("title", "text", '"title"'),
    ]
    assert trino.queries.count('DESCRIBE "iceberg"."raw_marts"."posts_mart"') == 2


def test_describe_trino_table_skips_non_retryable_candidate_after_first_failure() -> None:
    """Verifies non-retryable candidates are not retried after first failure."""
    trino = _FakeTrino(
        responses={},
        sequence_responses={
            'DESCRIBE "iceberg"."raw_marts"."posts_mart"': [
                RuntimeError("permission denied"),
                RuntimeError("should not execute"),
            ],
            "DESCRIBE iceberg.raw_marts.posts_mart": [
                RuntimeError(
                    "TrinoUserError(type=USER_ERROR, name=TABLE_NOT_FOUND, "
                    'message="table does not exist")'
                ),
                [("id", "bigint"), ("title", "varchar")],
            ],
        },
    )

    columns, resolved_ref = _describe_trino_table(trino, "iceberg.raw_marts.posts_mart")

    assert resolved_ref == "iceberg.raw_marts.posts_mart"
    assert columns == [
        ("id", "bigint", '"id"'),
        ("title", "text", '"title"'),
    ]
    assert trino.queries.count('DESCRIBE "iceberg"."raw_marts"."posts_mart"') == 1


def test_retryable_introspection_error_uses_structured_fields() -> None:
    """Verifies structured error fields are recognized as retryable."""

    class _StructuredTrinoError(RuntimeError):
        """Structured exception stub mimicking Trino client errors."""

        def __init__(self) -> None:
            """Initialize the structured Trino error stub."""
            super().__init__("opaque server error")
            self.error_name = "TABLE_NOT_FOUND"
            self.error_type = "USER_ERROR"

    assert _is_retryable_introspection_error(_StructuredTrinoError())


def test_resolve_publish_target_uses_wrapper_defaults() -> None:
    class _PublishTarget:
        resource = object()
        target_system = "postgres"
        default_schema = "serving"

    resource, target_system, schema = _resolve_publish_target(_PublishTarget(), target_schema=None)

    assert resource is _PublishTarget.resource
    assert target_system == "postgres"
    assert schema == "serving"


def test_publish_marts_emits_correlation(monkeypatch) -> None:
    class RecordingBus:
        def __init__(self) -> None:
            self.events: list[object] = []

        def emit(self, event: object) -> None:
            self.events.append(event)

    bus = RecordingBus()
    monkeypatch.setattr("phlo.hooks.emitters.get_hook_bus", lambda: bus)
    inserted_rows: list[tuple[object, ...]] = []

    def _record_execute_values(_cursor, _query, rows, page_size) -> None:
        assert page_size == 1000
        inserted_rows.extend(rows)

    monkeypatch.setattr(publishing, "execute_values", _record_execute_values)

    class _FakePostgresCursor:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return None

        def execute(self, query) -> None:
            return None

    class _FakeTrinoCursor:
        def __init__(self) -> None:
            self._rows: list[tuple[object, ...]] = []

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return None

        def execute(self, query: str) -> None:
            if query.startswith("DESCRIBE ") or query.startswith("SHOW COLUMNS FROM "):
                self._rows = [
                    ("order_id", "bigint"),
                    ("status", "varchar"),
                    ("amount", "double"),
                ]
                return
            if query.startswith("SELECT "):
                self._rows = [
                    (1, "placed", 10.0),
                    (2, "paid", 12.5),
                    (3, "fulfilled", 18.0),
                ]
                return
            raise AssertionError(f"Unexpected Trino query: {query}")

        def fetchall(self) -> list[tuple[object, ...]]:
            return list(self._rows)

        def fetchmany(self, batch_size: int) -> list[tuple[object, ...]]:
            batch = self._rows[:batch_size]
            self._rows = self._rows[batch_size:]
            return batch

    class _FakeTrino:
        def cursor(self) -> _FakeTrinoCursor:
            return _FakeTrinoCursor()

    class _FakePostgres:
        def cursor(self) -> _FakePostgresCursor:
            return _FakePostgresCursor()

        def commit(self) -> None:
            return None

    stats = publishing._publish_marts(
        context=SimpleNamespace(asset_key="publish_orders", run_id="run-88"),
        trino=_FakeTrino(),
        postgres=_FakePostgres(),
        target_system="postgres",
        tables_to_publish={"orders": "silver.orders"},
        data_source="orders",
        target_schema="marts",
        batch_size=1000,
    )

    assert stats["orders"].row_count == 3
    assert stats["orders"].column_count == 3
    assert inserted_rows == [
        (1, "placed", 10.0),
        (2, "paid", 12.5),
        (3, "fulfilled", 18.0),
    ]
    publish_event = next(event for event in bus.events if isinstance(event, PublishEvent))
    telemetry_event = next(event for event in bus.events if isinstance(event, TelemetryEvent))
    lineage_event = next(event for event in bus.events if isinstance(event, LineageEvent))

    assert publish_event.correlation.run_id == "run-88"
    assert publish_event.correlation.asset_key == "publish_orders"
    assert telemetry_event.correlation.run_id == "run-88"
    assert telemetry_event.correlation.asset_key == "publish_orders"
    assert lineage_event.correlation.run_id == "run-88"
    assert lineage_event.correlation.asset_key == "publish_orders"
