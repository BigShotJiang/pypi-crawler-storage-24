"""
Config — API URLs and credential helpers for the SigmanticAI CLI.
"""

import os

from sigmanticai.auth.credentials import (
    save_credentials,
    load_credentials,
    clear_credentials,
    SUPABASE_URL,
    SUPABASE_ANON_KEY,
)
from sigmanticai.auth.client import API_BASE_URL

# ── WebSocket API Endpoint (prod-specific) ────────────────────
_DEFAULT_API_URL = "wss://api.sigmanticai.com/v1/ws"
API_URL = os.environ.get("SIGMANTICAI_API_URL", _DEFAULT_API_URL)

__all__ = [
    "save_credentials",
    "load_credentials",
    "clear_credentials",
    "SUPABASE_URL",
    "SUPABASE_ANON_KEY",
    "API_URL",
    "API_BASE_URL",
]
