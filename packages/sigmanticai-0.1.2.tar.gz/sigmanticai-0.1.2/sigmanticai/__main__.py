"""Allow running as `python -m sigmanticai`."""
from sigmanticai.cli import main

main()


