"""
SigmanticAI authentication — self-contained, no external dependencies.

All auth operations go through the SigmanticAI Gateway API.
Credential storage lives at ~/.sigmanticai/credentials.json.
"""

from sigmanticai.auth.browser_login import browser_login, headless_login
from sigmanticai.auth.client import get_access_token, AuthClient, _api_request

# HAS_SUPABASE is no longer needed — auth goes through the API.
# Keep for backward compat with cli.py references.
HAS_SUPABASE = True

__all__ = [
    "browser_login",
    "headless_login",
    "get_access_token",
    "AuthClient",
    "_api_request",
    "HAS_SUPABASE",
]

