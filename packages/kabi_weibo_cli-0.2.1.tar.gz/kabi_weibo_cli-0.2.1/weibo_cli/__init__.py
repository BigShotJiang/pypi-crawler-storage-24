"""Weibo CLI."""
__version__ = "0.2.1"
