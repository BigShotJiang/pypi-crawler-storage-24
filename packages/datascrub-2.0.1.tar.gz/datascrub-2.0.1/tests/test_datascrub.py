import unittest
import pandas as pd
import numpy as np
from pandas.api.types import is_numeric_dtype
from datascrub.cleaner import DataClean

class TestDataClean(unittest.TestCase):
    def setUp(self):
        # Create a sample DataFrame for testing with richer data types and obvious outliers
        data = {'Name': [' John ', ' Jane ', ' Bob ', ' Alice ', ' Eve '],
                'Age': [25, np.nan, 35, 40, 100],  # 100 is an outlier
                'Salary': [50000, 60000, np.nan, 80000, 90000],
                'Email': ['john@example.com', 'jane@example.com', 'bob@example.com', 'alice@example.com', 'eve@example.com'],
                'Tags': ['A,B', 'C', 'D,E', 'F', 'G'],
                'DOB': ['1998-01-01', '1990/05/12', 'invalid_date', '2001-03-14', '1985-11-20'],
                'Noise': ['<p>Hello!</p>', 'Check out http://test.com.', 'Wow!!!', 'No noise here', 'Python is cool...']}
        self.df = pd.DataFrame(data)

    def test_clean_data(self):
        cleaner = DataClean(self.df)
        cleaned_df = cleaner.clean_data(columns='all')
        self.assertEqual(cleaned_df['Name'].tolist(), ['john', 'jane', 'bob', 'alice', 'eve'])

    def test_handle_missing_values_basic(self):
        cleaner = DataClean(self.df)
        missing_values = {'Age': 'replace missing value with 30'}
        cleaned_df = cleaner.handle_missing_values(missing_values)
        self.assertEqual(cleaned_df['Age'].tolist(), [25.0, 30.0, 35.0, 40.0, 100.0])

    def test_handle_missing_values_statistical(self):
        cleaner = DataClean(self.df)
        # Using mean imputation
        missing_values = {'Age': 'fill with mean', 'Salary': 'fill with median'}
        cleaned_df = cleaner.handle_missing_values(missing_values)
        # Mean of [25, 35, 40, 100] is 50.0
        self.assertEqual(cleaned_df['Age'][1], 50.0)
        # Median of [50000, 60000, 80000, 90000] is 70000.0
        self.assertEqual(cleaned_df['Salary'][2], 70000.0)

    def test_handle_missing_values_multivariate(self):
        cleaner = DataClean(self.df)
        missing_values = {'Age': 'knn-imputer', 'Salary': 'iterative-imputer'}
        cleaned_df = cleaner.handle_missing_values(missing_values)
        self.assertFalse(cleaned_df['Age'].isnull().any())
        self.assertFalse(cleaned_df['Salary'].isnull().any())
        
    def test_handle_outliers(self):
        cleaner = DataClean(self.df)
        # Using [25, 35, 40, 100], Q1=32.5, Q3=55, IQR=22.5. Upper bound = 88.75
        cleaned_df = cleaner.handle_outliers(method='iqr', columns=['Age'])
        self.assertEqual(cleaned_df['Age'][4], 88.75)

    def test_explode_data(self):
        cleaner = DataClean(self.df)
        explode_columns = {'Tags': ','}
        exploded_df = cleaner.explode_data(explode_columns)
        self.assertEqual(len(exploded_df), 7)
        self.assertEqual(list(exploded_df['Tags']), ['A', 'B', 'C', 'D', 'E', 'F', 'G'])

    def test_parse_date_column(self):
        cleaner = DataClean(self.df)
        date_columns = ['DOB']
        parsed_df = cleaner.parse_date_column(date_columns)
        self.assertEqual(parsed_df['DOB'].tolist()[:3], ['1998-01-01', '1990-05-12', 'NaT'])

    def test_translate_columns(self):
        cleaner = DataClean(self.df)
        translations = {'Name': True}
        translated_df = cleaner.translate_columns(translations)
        self.assertEqual(translated_df['Name'].tolist(), ['John', 'Jane', 'Bob', 'Alice', 'Eve'])

    def test_strip_noise(self):
        cleaner = DataClean(self.df)
        cleaned_df = cleaner.strip_noise(columns=['Noise'])
        # HTML stripped: Hello! -> punctuation stripped -> Hello
        # URL stripped: Check out . -> punctuation stripped -> Check out 
        self.assertEqual(cleaned_df['Noise'].tolist()[:3], ['Hello', 'Check out ', 'Wow'])

    def test_extract_datetime_features(self):
        cleaner = DataClean(self.df)
        # DOB has invalid_date at index 2, should be NaT -> NaN features
        extracted_df = cleaner.extract_datetime_features(['DOB'])
        self.assertTrue('DOB_Year' in extracted_df.columns)
        self.assertTrue('DOB_Month' in extracted_df.columns)
        self.assertTrue('DOB_Day' in extracted_df.columns)
        self.assertTrue('DOB_Is_Weekend' in extracted_df.columns)
        self.assertEqual(extracted_df['DOB_Year'].tolist()[:2], [1998, 1990])
        self.assertEqual(extracted_df['DOB_Month'].tolist()[:2], [1, 5])

    def test_encode_categorical(self):
        cleaner = DataClean(self.df)
        # Test one-hot
        encoded_df = cleaner.encode_categorical(method='one-hot', columns=['Name'])
        # 5 unique names -> 4 dummy columns (drop_first=True)
        self.assertTrue(len([col for col in encoded_df.columns if col.startswith('Name_')]) == 4)
        
        # Test label encoder
        encoded_df2 = cleaner.encode_categorical(method='label', columns=['Name'])
        self.assertTrue(is_numeric_dtype(encoded_df2['Name']))

    def test_prep(self):
        cleaner = DataClean(self.df)
        
        prepared_df = cleaner.prep(
            clean='all',
            missing_values={'Age': 'fill with mean'},
            outliers_method='iqr',
            outlier_columns=['Age'],
            perform_scaling_normalization_bool=False,
            explode={'Tags': ','},
            parse_date=['DOB'],
            extract_datetime=['DOB'],
            noise_columns=['Noise'],
            encoding_method='label',
            encoding_columns=['Name'],
            translate_column_names={'Name': False} # changed to False so we keep English names and encoded names separate
        )

        self.assertEqual(len(prepared_df), 7)
        # Verify clipping hit the max limit without going over
        self.assertTrue(prepared_df['Age'].max() <= 88.75)
        # Verify feature extractions ran on DOB
        self.assertTrue('DOB_Year' in prepared_df.columns)
        # Verify noise was stripped
        self.assertEqual(prepared_df['Noise'].iloc[0], 'hello') # Cleaned and lowercased because of clean='all'
        # Verify label encoding hit the Name column
        self.assertTrue(is_numeric_dtype(prepared_df['Name']))

    def test_sklearn_pipeline(self):
        from sklearn.pipeline import Pipeline
        # Configure the DataClean object directly through kwargs map
        cleaner = DataClean(
            clean='all', 
            missing_values={'Age': 'fill with median'}, 
            encoding_method='one-hot', 
            encoding_columns=['Name'],
            extract_datetime=['DOB']
        )
        pipeline = Pipeline([('cleaner', cleaner)])
        # Inject dataframe purely through fit_transform
        pipeline_df = pipeline.fit_transform(self.df)
        self.assertEqual(len(pipeline_df), 5)
        self.assertTrue('DOB_Year' in pipeline_df.columns)
        self.assertTrue(pipeline_df['Age'].isnull().sum() == 0)

    def test_downcast(self):
        # Force strict 64-bit bounds on small numbers
        data = {'col1': np.array([1, 2, 3, 4, 10], dtype=np.int64),
                'col2': np.array([1.5, 2.5, np.nan, 4.5, 10.5], dtype=np.float64)}
        df_mem = pd.DataFrame(data)
        cleaner = DataClean(df_mem)
        downcasted_df = cleaner.downcast()
        # Verify successful memory footprint shrink mapped correctly
        self.assertEqual(str(downcasted_df['col1'].dtype), 'int8')
        self.assertEqual(str(downcasted_df['col2'].dtype), 'float32')

    def test_summary(self):
        cleaner = DataClean(self.df)
        summary_df = cleaner.summary()
        self.assertTrue('Sparsity (%)' in summary_df.columns)
        self.assertTrue('Variance' in summary_df.columns)
        self.assertTrue('Skewness' in summary_df.columns)
        self.assertEqual(len(summary_df), len(self.df.columns))

    def test_chunked_processing(self):
        import os
        # Create a dummy CSV for chunking
        dummy_df = pd.DataFrame({'Name': ['John', 'Jane', 'Bob', 'Alice', 'Eve'], 'Age': [25, np.nan, 35, 40, 100]})
        dummy_file = 'dummy_chunk_test.csv'
        dummy_df.to_csv(dummy_file, index=False)
        
        try:
            # Force chunk processing with chunksize=2
            cleaner = DataClean(dummy_file, chunksize=2)
            output_file = cleaner.prep(clean='all', missing_values={'Age': 'fill with median'})
            
            # Verify the output file exists and was returned correctly
            self.assertTrue(os.path.exists(output_file))
            self.assertTrue(output_file.endswith('_cleaned.csv'))
            
            # Check the contents of the chunk-processed file
            cleaned_df = pd.read_csv(output_file)
            self.assertEqual(len(cleaned_df), 5)
            self.assertEqual(cleaned_df['Name'].tolist(), ['john', 'jane', 'bob', 'alice', 'eve'])
            self.assertTrue(cleaned_df['Age'].isnull().sum() == 0)
            
        finally:
            if os.path.exists(dummy_file):
                os.remove(dummy_file)
            if 'output_file' in locals() and os.path.exists(output_file):
                os.remove(output_file)

    def test_pyarrow_backend(self):
        cleaner = DataClean(self.df, use_pyarrow=True)
        # Verify the backend converted dtypes correctly
        for col in cleaner.raw_data.columns:
            dtype_str = str(cleaner.raw_data[col].dtype)
            self.assertTrue('pyarrow' in dtype_str or '[pyarrow]' in dtype_str)
        
        # Verify cleaning pipeline operates on pyarrow types without crashing
        prepared_df = cleaner.prep(clean='all', encoding_method='one-hot', encoding_columns=['Name'])
        self.assertEqual(len(prepared_df), 5)

if __name__ == '__main__':
    unittest.main()
