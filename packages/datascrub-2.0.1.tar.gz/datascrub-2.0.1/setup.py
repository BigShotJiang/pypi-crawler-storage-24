from setuptools import setup, find_packages

setup(
    name='datascrub',
    version='2.0.1',
    author='Samuel Shine' and 'Alex Benjamin',
    author_email='samuelshine112003@gmail.com',
    description='A Python package for cleaning and preprocessing data in pandas DataFrames',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/samuelshine/cleanmydata',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    install_requires=[
        'pandas',
        'numpy',
        'scipy',
        'emoji',
        'googletrans==3.1.0a0',
        'scikit-learn==1.8.0',
        'pyarrow>=12.0.0'
    ],
)
