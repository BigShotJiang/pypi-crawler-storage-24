import pandas as pd
from scipy import stats
from pandas.api.types import is_numeric_dtype
import emoji
from googletrans import Translator
from sklearn.base import BaseEstimator, TransformerMixin
import numpy as np
from joblib import Parallel, delayed

class DataClean(BaseEstimator, TransformerMixin):
    def __init__(self, obj=None, clean='all', missing_values=None, outliers_method=None, outlier_columns='all', perform_scaling_normalization_bool=False, explode=None, parse_date=None, extract_datetime=None, noise_columns=None, encoding_method=None, encoding_columns='all', target_col=None, translate_column_names=None, chunksize=None, use_pyarrow=False):
        
        self.is_chunked = False
        self.file_path = None
        self.chunksize = chunksize
        self.use_pyarrow = use_pyarrow
        
        if obj is not None:
            if isinstance(obj, pd.DataFrame):
                self.raw_data = obj.copy()
            elif isinstance(obj, str):
                import os
                if not os.path.exists(obj):
                    raise FileNotFoundError(f"File not found: {obj}")
                
                file_size_mb = os.path.getsize(obj) / (1024 * 1024)
                if obj.endswith('.csv') and (chunksize is not None or file_size_mb > 100):
                    self.is_chunked = True
                    self.file_path = obj
                    self.chunksize = chunksize if chunksize else 100000
                    self.raw_data = None
                else:
                    if obj.endswith('.csv'):
                        self.raw_data = pd.read_csv(obj)
                    elif obj.endswith('.xlsx'):
                        self.raw_data = pd.read_excel(obj)
                    else:
                        raise ValueError("Invalid file format. Please provide a path to a .csv or .xlsx file.")
            else:
                raise ValueError("Invalid data type. Please provide a pandas DataFrame or a file path string.")
                
            if self.use_pyarrow and self.raw_data is not None:
                self.raw_data = self.raw_data.convert_dtypes(dtype_backend='pyarrow')
        else:
            self.raw_data = None
            
        self.clean = clean
        self.missing_values = missing_values
        self.outliers_method = outliers_method
        self.outlier_columns = outlier_columns
        self.perform_scaling_normalization_bool = perform_scaling_normalization_bool
        self.explode = explode
        self.parse_date = parse_date
        self.extract_datetime = extract_datetime
        self.noise_columns = noise_columns
        self.encoding_method = encoding_method
        self.encoding_columns = encoding_columns
        self.target_col = target_col
        self.translate_column_names = translate_column_names

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        if isinstance(X, pd.DataFrame):
            self.raw_data = X.copy()
        else:
            self.raw_data = pd.DataFrame(X)
            
        return self.prep(
            clean=self.clean,
            missing_values=self.missing_values,
            outliers_method=self.outliers_method,
            outlier_columns=self.outlier_columns,
            perform_scaling_normalization_bool=self.perform_scaling_normalization_bool,
            explode=self.explode,
            parse_date=self.parse_date,
            extract_datetime=self.extract_datetime,
            noise_columns=self.noise_columns,
            encoding_method=self.encoding_method,
            encoding_columns=self.encoding_columns,
            target_col=self.target_col,
            translate_column_names=self.translate_column_names
        )

    def clean_data(self, columns):
        """
        Cleans text data in a pandas DataFrame.

        Parameters:
        columns (str, list): Either 'all' to clean all columns or a list of column names to clean.

        Returns:
        pd.DataFrame: DataFrame with cleaned text data.
        """
        updated_data = self.raw_data.copy()

        if columns == 'all':
            text_columns = updated_data.select_dtypes(include='object').columns
            print(text_columns)
        elif isinstance(columns, list):
            text_columns = [col for col in columns if col in updated_data.columns]
        else:
            raise ValueError("Invalid value for 'clean' parameter. It should be 'all' or a list of column names.")

        def _clean_column(col_series):
            # Strict pandas C-level string vectorization
            s = col_series.str.strip().str.lower()
            s = s.map(lambda x: emoji.demojize(str(x)) if pd.notna(x) else x)
            return s

        # Parallelize across columns mapping to all CPU cores
        if len(text_columns) > 0:
            results = Parallel(n_jobs=-1)(delayed(_clean_column)(updated_data[col]) for col in text_columns)
            for col, res in zip(text_columns, results):
                updated_data[col] = res

        return updated_data

    def handle_missing_values(self, missing_values):
        """
        Handles missing values in a pandas DataFrame. Actions depend on the `missing_values` dictionary provided.

        Parameters:
        missing_values (dict): Dictionary with actions to be taken on missing values.
                               Keys: Column names.
                               Values: Operations to be performed on corresponding column.
                                       "replace missing value with <value>" to replace missing values with <value>.
                                       "drop" to drop rows with missing values.
                                       "fill with backward fill along rows" to fill missing values using backward fill along rows.
                                       "fill with backward fill along columns" to fill missing values using backward fill along columns.

        Returns:
        pd.DataFrame: DataFrame with handled missing values.
        """
        updated_data = self.raw_data.copy()

        # Pre-compute multivariate imputations if requested
        multivariate_ops = [op for op in missing_values.values() if op in ['knn-imputer', 'iterative-imputer']]
        if multivariate_ops:
            numeric_cols = updated_data.select_dtypes(include='number').columns
            if 'knn-imputer' in multivariate_ops:
                from sklearn.impute import KNNImputer
                knn_imputer = KNNImputer(n_neighbors=5)
                knn_imputed_data = pd.DataFrame(knn_imputer.fit_transform(updated_data[numeric_cols]), columns=numeric_cols, index=updated_data.index)
            if 'iterative-imputer' in multivariate_ops:
                from sklearn.experimental import enable_iterative_imputer
                from sklearn.impute import IterativeImputer
                mice_imputer = IterativeImputer(max_iter=10, random_state=42)
                mice_imputed_data = pd.DataFrame(mice_imputer.fit_transform(updated_data[numeric_cols]), columns=numeric_cols, index=updated_data.index)

        for column, operation in missing_values.items():
            if operation.startswith("replace missing value with "):
                value = operation.split("replace missing value with ")[1]
                try:
                    value = float(value)
                except ValueError:
                    value = str(value)
                updated_data[column] = updated_data[column].fillna(value)
            elif operation == "drop":
                updated_data.dropna(subset=[column], inplace=True)
            elif operation == "fill with backward fill along rows":
                updated_data[column] = updated_data[column].fillna(method='bfill', axis='rows').fillna(0)
            elif operation == "fill with backward fill along columns":
                updated_data[column] = updated_data[column].fillna(method='bfill', axis='columns').fillna(0)
            elif operation == "fill with mean":
                updated_data[column] = updated_data[column].fillna(updated_data[column].mean())
            elif operation == "fill with median":
                updated_data[column] = updated_data[column].fillna(updated_data[column].median())
            elif operation == "fill with mode":
                updated_data[column] = updated_data[column].fillna(updated_data[column].mode()[0])
            elif operation == "knn-imputer" and column in numeric_cols:
                updated_data[column] = knn_imputed_data[column]
            elif operation == "iterative-imputer" and column in numeric_cols:
                updated_data[column] = mice_imputed_data[column]
            else:
                raise ValueError(f"Invalid operation '{operation}' in 'missing_values' parameter.")
        return updated_data

    def perform_scaling_normalization(self):
        """
        Performs scaling normalization on numerical columns in a pandas DataFrame using Box-Cox transformation.

        Returns:
        pd.DataFrame: DataFrame with scaled and normalized numerical data.
        """
        updated_data = self.raw_data.copy()
        for column in updated_data.columns:
            if is_numeric_dtype(updated_data[column]):
                # Shift data to be strictly positive for Box-Cox
                min_val = updated_data[column].min()
                if min_val <= 0:
                    updated_data[column] = updated_data[column] - min_val + 1
                updated_data[column], _ = stats.boxcox(updated_data[column])
        return updated_data

    def handle_outliers(self, method='iqr', columns='all'):
        """
        Clips outliers in numerical columns using specified statistical bounds without dropping rows.

        Parameters:
        method (str): 'iqr' for Interquartile Range clipping or 'z-score' for 3 standard deviations clipping.
        columns (str, list): 'all' for all numeric columns or list of specific feature column names.
        
        Returns:
        pd.DataFrame: DataFrame with mitigated outliers.
        """
        updated_data = self.raw_data.copy()
        
        if columns == 'all':
            numeric_cols = updated_data.select_dtypes(include='number').columns
        elif isinstance(columns, list):
            numeric_cols = [col for col in columns if col in updated_data.columns and is_numeric_dtype(updated_data[col])]
        else:
            raise ValueError("Invalid format for 'columns'. Expected 'all' or a list of column names.")
            
        for column in numeric_cols:
            if method == 'iqr':
                q1 = updated_data[column].quantile(0.25)
                q3 = updated_data[column].quantile(0.75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
            elif method == 'z-score':
                mean_val = updated_data[column].mean()
                std_val = updated_data[column].std()
                lower_bound = mean_val - 3 * std_val
                upper_bound = mean_val + 3 * std_val
            else:
                 raise ValueError(f"Invalid method '{method}' for handling outliers. Use 'iqr' or 'z-score'.")
                 
            updated_data[column] = updated_data[column].clip(lower=lower_bound, upper=upper_bound)
            
        return updated_data

    def explode_data(self, explode):
        """
        Splits and expands data in specified columns of a pandas DataFrame.

        Parameters:
        explode (dict): Dictionary with column names as keys and separator as values for splitting.

        Returns:
        pd.DataFrame: DataFrame with exploded data.
        """
        updated_data = self.raw_data.copy()
        for column, separator in explode.items():
            updated_data[column] = updated_data[column].str.split(separator)
            updated_data = updated_data.explode(column)
        return updated_data

    def dupli(self):
        """
        Removes duplicate rows from a pandas DataFrame.

        Returns:
        pd.DataFrame: DataFrame without duplicate rows.
        """
        return self.raw_data.drop_duplicates()

    def parse_date_column(self, date_columns):
        """
        Converts specified columns in a pandas DataFrame to datetime format and formats them as 'YYYY-MM-DD'.

        Parameters:
        date_columns (dict): List of column names to be converted to datetime format.

        Returns:
        pd.DataFrame: DataFrame with parsed date columns.
        """
        updated_data = self.raw_data.copy()

        for column in date_columns:
            if column not in updated_data.columns:
                raise ValueError(f"Column '{column}' not found in the DataFrame.")

        def _parse(col_series):
            if col_series.dtype != 'datetime64[ns]':
                dt = pd.to_datetime(col_series, errors='coerce', format='mixed')
                return dt.dt.strftime('%Y-%m-%d').fillna('NaT')
            return col_series

        if len(date_columns) > 0:
            results = Parallel(n_jobs=-1)(delayed(_parse)(updated_data[col]) for col in date_columns)
            for col, res in zip(date_columns, results):
                updated_data[col] = res

        return updated_data

    def translate_columns(self, translations):
        """
        Translates text in specified columns of a DataFrame to English using Google Translate.

        Parameters:
        translations (dict): Dictionary mapping column names to overwrite boolean values.
                             The key is the column name, and the value is the overwrite boolean value.

        Returns:
        pd.DataFrame: DataFrame with translated columns.
        """
        import asyncio
        translator = Translator()
        updated_data = self.raw_data.copy()

        async def _translate(text):
            if pd.isna(text):
                return text
            res = await translator.translate(str(text))
            return res.text

        async def _run_all(texts):
            return await asyncio.gather(*[_translate(text) for text in texts])

        for column, overwrite_value in translations.items():
            if column not in updated_data.columns:
                raise ValueError(f"Column '{column}' not found in the DataFrame.")

            translated_texts = asyncio.run(_run_all(updated_data[column]))

            if overwrite_value:
                updated_data[column] = translated_texts
            else:
                new_column_name = column + '_translated'
                updated_data[new_column_name] = translated_texts

        return updated_data

    def strip_noise(self, columns='all', remove_html=True, remove_urls=True, remove_punctuation=True):
        """
        Removes common noise like HTML tags, URLs, and punctuation from text columns via Regex.
        
        Parameters:
        columns (str, list): 'all' or list of columns to strip noise from.
        remove_html (bool): If True, strips <tags>.
        remove_urls (bool): If True, strips http/https/www links.
        remove_punctuation (bool): If True, strips standard string punctuation.
        
        Returns:
        pd.DataFrame: DataFrame with text noise removed.
        """
        import re
        import string
        updated_data = self.raw_data.copy()
        
        if columns == 'all':
            text_columns = updated_data.select_dtypes(include='object').columns
        elif isinstance(columns, list):
            text_columns = [col for col in columns if col in updated_data.columns]
        else:
            raise ValueError("Invalid format for 'columns'. Expected 'all' or a list of column names.")

        # Vectorized string replace functions mapped to CPUs
        punct_regex = f'[{re.escape(string.punctuation)}]'
        
        def _strip(col_series):
            s = col_series.copy()
            if remove_html:
                s = s.str.replace(r'<[^>]+>', '', regex=True)
            if remove_urls:
                s = s.str.replace(r'http\S+|www.\S+', '', regex=True)
            if remove_punctuation:
                s = s.str.replace(punct_regex, '', regex=True)
            return s

        if len(text_columns) > 0:
            results = Parallel(n_jobs=-1)(delayed(_strip)(updated_data[col]) for col in text_columns)
            for col, res in zip(text_columns, results):
                updated_data[col] = res
                
        return updated_data

    def extract_datetime_features(self, columns):
        """
        Explodes YYYY-MM-DD columns into dedicated Year, Month, Day, and Is_Weekend integer features.
        
        Parameters:
        columns (list): List of column names to extract features from. Must be datetime convertible.
        
        Returns:
        pd.DataFrame: DataFrame with newly extracted datetime feature columns.
        """
        updated_data = self.raw_data.copy()
        
        for column in columns:
            if column not in updated_data.columns:
                raise ValueError(f"Column '{column}' not found in the DataFrame.")
                
            temp_dt = pd.to_datetime(updated_data[column], errors='coerce', format='mixed')
            
            updated_data[f"{column}_Year"] = temp_dt.dt.year.astype('Int64')
            updated_data[f"{column}_Month"] = temp_dt.dt.month.astype('Int64')
            updated_data[f"{column}_Day"] = temp_dt.dt.day.astype('Int64')
            updated_data[f"{column}_Is_Weekend"] = temp_dt.dt.dayofweek.isin([5, 6]).astype(int)
            
            # Optional: Drop the original datetime column if preferred
            # updated_data.drop(columns=[column], inplace=True)
            
        return updated_data

    def encode_categorical(self, method='one-hot', columns='all', target_col=None):
        """
        Provides categorical encodings via one-hot, label, or target encoding methodologies.
        
        Parameters:
        method (str): 'one-hot', 'label', or 'target'.
        columns (str, list): 'all' or list of categorical column names to encode.
        target_col (str): Target column name, required only if method='target'.
        
        Returns:
        pd.DataFrame: DataFrame with encoded categorical features.
        """
        updated_data = self.raw_data.copy()
        
        if columns == 'all':
            cat_cols = updated_data.select_dtypes(include=['object', 'category']).columns
        elif isinstance(columns, list):
            cat_cols = [col for col in columns if col in updated_data.columns]
        else:
            raise ValueError("Invalid format for 'columns'. Expected 'all' or a list of column names.")
            
        if method == 'one-hot':
            updated_data = pd.get_dummies(updated_data, columns=cat_cols, drop_first=True)
        elif method == 'label':
            from sklearn.preprocessing import LabelEncoder
            le = LabelEncoder()
            for col in cat_cols:
                # Handle NaNs dynamically by coercing to string prior to label encoding
                updated_data[col] = le.fit_transform(updated_data[col].astype(str))
        elif method == 'target':
            if not target_col or target_col not in updated_data.columns:
                 raise ValueError("A valid 'target_col' must be provided for target encoding.")
            from sklearn.preprocessing import TargetEncoder
            te = TargetEncoder()
            updated_data[cat_cols] = te.fit_transform(updated_data[cat_cols], updated_data[target_col])
        else:
            raise ValueError(f"Invalid encoding method '{method}'. Use 'one-hot', 'label', or 'target'.")
            
        return updated_data

    def prep(self, clean='all', missing_values=None, outliers_method=None, outlier_columns='all', perform_scaling_normalization_bool=False, explode=None, parse_date=None, extract_datetime=None, noise_columns=None, encoding_method=None, encoding_columns='all', target_col=None, translate_column_names=None):
        """
        Main function to prepare and clean a pandas DataFrame. Can perform cleaning, handle missing values,
        fix inconsistencies, mitigate outliers, perform scaling normalization, explode data, parse date columns, 
        and execute feature engineering pipelines like categorical encoding and noise stripping.

        Parameters:
        clean (str, list): Columns to clean. Either 'all' for all columns or a list of specific column names.
        missing_values (dict): Actions to be taken on missing values. Refer `handle_missing_values` for more details.
        outliers_method (str): 'iqr' or 'z-score' to mitigate outliers via clipping. Defaults to None.
        outlier_columns (str, list): numeric columns to check for outliers.
        perform_scaling_normalization (bool): If True, will perform scaling normalization on numerical columns.
        explode (dict): Columns to be exploded. Keys are column names and values are separators for splitting.
        parse_date (list): List of column names to be converted to datetime format.
        extract_datetime (list): List of YYYY-MM-DD columns to extract Year/Month/Day components from.
        noise_columns (str, list): Columns to strip HTML, URLs, and punctuation from via `strip_noise`.
        encoding_method (str): 'one-hot', 'label', or 'target'.
        encoding_columns (str, list): columns to encode. Defaults to 'all' categorical.
        target_col (str): target column name required if encoding_method='target'.
        translate_column_names (dict): Dictionary mapping column names to overwrite boolean values for translation.

        Returns:
        pd.DataFrame or str: Updated DataFrame, or the file path of the saved output if chunked.
        """
        if self.is_chunked:
            return self._prep_chunked(clean, missing_values, outliers_method, outlier_columns, perform_scaling_normalization_bool, explode, parse_date, extract_datetime, noise_columns, encoding_method, encoding_columns, target_col, translate_column_names)

        if missing_values:
            self.raw_data = self.handle_missing_values(missing_values)
            
        if outliers_method:
            self.raw_data = self.handle_outliers(method=outliers_method, columns=outlier_columns)

        if parse_date:
            self.raw_data = self.parse_date_column(parse_date)

        if translate_column_names:
            self.raw_data = self.translate_columns(translate_column_names)

        if clean:
            self.raw_data = self.clean_data(clean)
            
        if noise_columns:
            self.raw_data = self.strip_noise(columns=noise_columns)
            
        if extract_datetime:
            self.raw_data = self.extract_datetime_features(extract_datetime)
            
        if encoding_method:
            self.raw_data = self.encode_categorical(method=encoding_method, columns=encoding_columns, target_col=target_col)

        if perform_scaling_normalization_bool:
            self.raw_data = self.perform_scaling_normalization()

        if explode:
            self.raw_data = self.explode_data(explode)

        self.raw_data = self.dupli()

        return self.raw_data

    def _prep_chunked(self, clean, missing_values, outliers_method, outlier_columns, perform_scaling_normalization_bool, explode, parse_date, extract_datetime, noise_columns, encoding_method, encoding_columns, target_col, translate_column_names):
        import os
        output_file = os.path.splitext(self.file_path)[0] + '_cleaned.csv'
        first_chunk = True
        
        for chunk in pd.read_csv(self.file_path, chunksize=self.chunksize):
            cleaner = DataClean(
                obj=chunk, 
                clean=clean, 
                missing_values=missing_values, 
                outliers_method=outliers_method, 
                outlier_columns=outlier_columns, 
                perform_scaling_normalization_bool=perform_scaling_normalization_bool, 
                explode=explode, 
                parse_date=parse_date, 
                extract_datetime=extract_datetime, 
                noise_columns=noise_columns, 
                encoding_method=encoding_method, 
                encoding_columns=encoding_columns, 
                target_col=target_col, 
                translate_column_names=translate_column_names,
                use_pyarrow=self.use_pyarrow
            )
            cleaned_chunk = cleaner.prep(
                clean=clean, missing_values=missing_values, outliers_method=outliers_method, outlier_columns=outlier_columns, perform_scaling_normalization_bool=perform_scaling_normalization_bool, explode=explode, parse_date=parse_date, extract_datetime=extract_datetime, noise_columns=noise_columns, encoding_method=encoding_method, encoding_columns=encoding_columns, target_col=target_col, translate_column_names=translate_column_names
            )
            
            if first_chunk:
                cleaned_chunk.to_csv(output_file, index=False, mode='w')
                first_chunk = False
            else:
                cleaned_chunk.to_csv(output_file, index=False, mode='a', header=False)
                
        print(f"--- Processed {os.path.basename(self.file_path)} in chunks. Saved to {os.path.basename(output_file)} ---")
        return output_file

    def downcast(self):
        """
        Downcasts numeric columns to the smallest possible datatype to reduce memory payloads.
        """
        updated_data = self.raw_data.copy()
        
        for col in updated_data.select_dtypes(include=['int', 'float']).columns:
            col_type = updated_data[col].dtype
            c_min = updated_data[col].min()
            c_max = updated_data[col].max()
            
            if pd.isna(c_min) or pd.isna(c_max):
                continue
                
            if 'int' in str(col_type):
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    updated_data[col] = updated_data[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    updated_data[col] = updated_data[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    updated_data[col] = updated_data[col].astype(np.int32)
            elif 'float' in str(col_type):
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    updated_data[col] = updated_data[col].astype(np.float32)
                    
        return updated_data

    def summary(self):
        """
        Prints a summary of the dataset including sparsity, variance, skewness, and memory usage.
        
        Returns:
        pd.DataFrame: Statistical profile DataFrame.
        """
        stats = pd.DataFrame(index=self.raw_data.columns)
        stats['Data Type'] = self.raw_data.dtypes
        stats['Missing Values'] = self.raw_data.isnull().sum()
        stats['Sparsity (%)'] = (stats['Missing Values'] / len(self.raw_data)) * 100
        
        numeric_cols = self.raw_data.select_dtypes(include=['number']).columns
        stats['Variance'] = self.raw_data[numeric_cols].var()
        stats['Skewness'] = self.raw_data[numeric_cols].skew()
        
        memory_usage = self.raw_data.memory_usage(deep=True).sum() / (1024 ** 2)
        print(f"--- Data Profile Summary ---")
        print(f"Shape: {len(self.raw_data)} rows, {len(self.raw_data.columns)} columns")
        print(f"Total Memory Usage: {memory_usage:.2f} MB\n")
        print(stats.fillna('-').to_string())
        
        return stats
