"""
Custom exceptions for the Google Play Scraper.
"""


class PlayScraperError(Exception):
    """Base exception for google-play-scraper."""


class AppNotFoundError(PlayScraperError):
    """Raised when an app is not found on Google Play."""


class ScraperError(PlayScraperError):
    """Raised when scraping fails due to unexpected page structure or network issues."""
