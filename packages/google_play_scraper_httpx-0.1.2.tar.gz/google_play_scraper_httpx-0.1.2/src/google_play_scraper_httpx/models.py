"""
Data models for the Google Play Scraper.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class AppDetails(BaseModel):
    """
    Detailed information about a single Google Play app.
    """

    app_id: str
    title: str
    description: str
    description_html: Optional[str] = None
    summary: Optional[str] = None
    developer: str
    developer_id: str
    developer_email: Optional[str] = None
    developer_website: Optional[str] = None
    developer_address: Optional[str] = None
    privacy_policy: Optional[str] = None
    category: str
    category_id: str
    categories: List[Dict[str, str]] = []
    icon: str
    header_image: Optional[str] = None
    screenshots: List[str]
    video: Optional[str] = None
    video_image: Optional[str] = None
    score: Optional[float] = None
    ratings: Optional[int] = None
    reviews: Optional[int] = None
    histogram: List[int] = []
    installs: Optional[str] = None
    min_installs: Optional[int] = None
    real_installs: Optional[int] = None
    price: float = 0.0
    free: bool = True
    currency: str = "USD"
    sale: bool = False
    sale_time: Optional[int] = None
    original_price: Optional[float] = None
    sale_text: Optional[str] = None
    offers_iap: bool = False
    in_app_product_price: Optional[str] = None
    version: Optional[str] = None
    released: Optional[str] = None
    updated: Optional[int] = None
    content_rating: Optional[str] = None
    content_rating_description: Optional[str] = None
    ad_supported: bool = False
    contains_ads: bool = False
    comments: List[str] = []
    url: Optional[str] = None


class SearchResult(BaseModel):
    """
    Minimal information about an app from a search or list result.
    """

    app_id: str
    title: str
    developer: str
    icon: str
    score: Optional[float] = None
    price: float = 0.0
    free: bool = True


class Review(BaseModel):
    """
    User review information.
    """

    review_id: str
    username: str
    user_image: str
    content: str
    score: int
    thumbs_up_count: int
    review_created_version: Optional[str] = None
    at: datetime
    reply_content: Optional[str] = None
    reply_at: Optional[datetime] = None


class Category(BaseModel):
    """
    Google Play category information.
    """

    name: str
    category_id: str


class Permission(BaseModel):
    """
    App permission information.
    """

    permission: str
    description: str


class DataSafety(BaseModel):
    """
    Data safety information.
    """

    shared_data: List[Dict[str, Any]] = []
    collected_data: List[Dict[str, Any]] = []
    security_practices: List[Dict[str, Any]] = []
    privacy_policy_url: Optional[str] = None
