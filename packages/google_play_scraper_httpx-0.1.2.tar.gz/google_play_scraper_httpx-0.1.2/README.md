# Google Play Scraper

A modern, fast Google Play Store scraper using `httpx`, `selectolax`, and `pydantic`.

## Features

- **App Details**: Full metadata including description, installs, and price.
- **Search**: Search for apps by query.
- **Developer**: List apps by developer ID.
- **Suggest**: Real-time search suggestions.
- **Reviews**: Fetch user reviews using Google Play RPCs.
- **Similar**: Find related applications.
- **Permissions & Data Safety**: Comprehensive privacy information.
- **Categories**: List all available store categories.

## Installation

You can install `google-play-scraper` directly from PyPI using your favorite package manager:

```bash
# Using pip
pip install google-play-scraper-httpx

# Using uv
uv add google-play-scraper-httpx
```

## Documentation

Comprehensive documentation, including API references, architecture overviews, and detailed contributing guidelines, is hosted on GitHub Pages:

👉 **[Read the Full Documentation Here](https://mdrakibhasanbd.github.io/google-play-scraper/)**

### For Contributors

If you are looking to run the local test suite, modify the scraper, or understand our Git and release workflows (including the internal bash scripts), please refer to the **Developer Guide** section on the documentation website.

## License

MIT
