//! Google-style docstring support.
//!
//! This module contains the AST types and parser for Google-style docstrings.

pub mod kind;
pub mod nodes;
pub mod parser;
pub mod to_model;

pub use kind::GoogleSectionKind;
pub use nodes::{
    GoogleArg, GoogleAttribute, GoogleDocstring, GoogleException, GoogleMethod, GoogleReturns,
    GoogleSection, GoogleSectionHeader, GoogleSeeAlsoItem, GoogleWarning,
};
pub use parser::parse_google;
