"""Shared test fixtures."""

import pytest

from ai_proxy.config import Settings
from ai_proxy.providers import MODELS
from ai_proxy.router.strategy import CostLedger, Router


@pytest.fixture
def settings():
    return Settings(
        AI_PROXY_HOST="127.0.0.1",
        AI_PROXY_PORT=4000,
        AI_PROXY_MASTER_KEY="sk-test",
        ANTHROPIC_API_KEY="sk-ant-test",
        OPENAI_API_KEY="sk-test",
        OPENROUTER_API_KEY="sk-or-test",
        GOOGLE_AI_KEY="AI-test",
        DEEPSEEK_API_KEY="sk-ds-test",
        GROQ_API_KEY="gsk-test",
        REDIS_URL="redis://localhost:6379/0",
        MONTHLY_BUDGET_USD=60.0,
        DAILY_BUDGET_USD=5.0,
        MAX_REQUEST_COST_USD=2.0,
    )


@pytest.fixture
def all_providers():
    """All providers available for routing."""
    return {
        "anthropic", "openai", "openrouter", "google",
        "deepseek", "groq", "together", "mistral",
        "fireworks", "cerebras", "ollama",
    }


@pytest.fixture
def router(all_providers):
    ledger = CostLedger(daily_limit=5.0, monthly_limit=60.0)
    return Router(
        available_providers=all_providers,
        ledger=ledger,
        max_request_cost=2.0,
    )


@pytest.fixture
def cheap_router():
    """Router with only free/cheap providers."""
    providers = {"ollama", "deepseek", "groq", "cerebras", "google"}
    ledger = CostLedger(daily_limit=1.0, monthly_limit=10.0)
    return Router(
        available_providers=providers,
        ledger=ledger,
        max_request_cost=0.5,
    )


@pytest.fixture
def tmp_project(tmp_path):
    """Create a temporary project directory with sample files."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "main.py").write_text("def main():\n    print('hello')\n")
    (src / "utils.py").write_text("def add(a, b):\n    return a + b\n")
    (tmp_path / "README.md").write_text("# Test Project\n")
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "test"\n')
    return tmp_path
