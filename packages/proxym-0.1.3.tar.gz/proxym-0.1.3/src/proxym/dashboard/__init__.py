"""Dashboard API: web panel + CLI endpoints for managing accounts, VMs, and costs.

Mounted at /dashboard/ on the main proxy app.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ai_proxy.accounts import (
    Account,
    AccountCredentials,
    AccountLimits,
    AccountManager,
    ProviderType,
    ToolBinding,
    ToolType,
)
from ai_proxy.virt import VMConfig, VMOrchestrator

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

# Singletons (initialized on first use)
_acct_mgr: AccountManager | None = None
_vm_orch: VMOrchestrator | None = None


def _accounts() -> AccountManager:
    global _acct_mgr
    if _acct_mgr is None:
        _acct_mgr = AccountManager()
    return _acct_mgr


def _vms() -> VMOrchestrator:
    global _vm_orch
    if _vm_orch is None:
        _vm_orch = VMOrchestrator()
    return _vm_orch


# ── Pydantic request models ──────────────────────────────────

class CreateAccountReq(BaseModel):
    name: str
    provider: str
    email: str = ""
    plan_tier: str = ""
    api_key: str = ""
    tags: list[str] = []
    daily_budget_usd: float = 0
    monthly_budget_usd: float = 0


class BindToolReq(BaseModel):
    tool_type: str
    tool_name: str
    vm_id: str = ""
    project_path: str = ""
    browser_profile: str = ""


class CreateVMReq(BaseModel):
    name: str
    account_id: str = ""
    tool: str = ""
    vcpus: int = 2
    memory_mb: int = 4096
    disk_gb: int = 20
    base_image: str = "fedora-40-dev"
    code_mount_host: str = ""


class SwitchProjectReq(BaseModel):
    project_path: str


# ── Account endpoints ────────────────────────────────────────

@router.get("/accounts")
async def list_accounts(provider: str | None = None, tag: str | None = None):
    mgr = _accounts()
    prov = ProviderType(provider) if provider else None
    accts = mgr.list_accounts(provider=prov, tag=tag)
    return {"accounts": [a.status_summary() for a in accts]}


@router.post("/accounts")
async def create_account(req: CreateAccountReq):
    mgr = _accounts()
    acct = Account(
        name=req.name,
        provider=ProviderType(req.provider),
        email=req.email,
        plan_tier=req.plan_tier,
        credentials=AccountCredentials(api_key=req.api_key),
        limits=AccountLimits(
            user_daily_budget_usd=req.daily_budget_usd,
            user_monthly_budget_usd=req.monthly_budget_usd,
        ),
        tags=req.tags,
    )
    mgr.add_account(acct)
    return acct.status_summary()


@router.get("/accounts/{account_id}")
async def get_account(account_id: str):
    acct = _accounts().get_account(account_id)
    if not acct:
        raise HTTPException(404, "Account not found")
    return acct.status_summary()


@router.delete("/accounts/{account_id}")
async def delete_account(account_id: str):
    if _accounts().remove_account(account_id):
        return {"ok": True}
    raise HTTPException(404, "Account not found")


@router.post("/accounts/{account_id}/bind-tool")
async def bind_tool(account_id: str, req: BindToolReq):
    binding = ToolBinding(
        tool_type=ToolType(req.tool_type),
        tool_name=req.tool_name,
        vm_id=req.vm_id,
        project_path=req.project_path,
        browser_profile=req.browser_profile,
    )
    if _accounts().bind_tool(account_id, binding):
        return {"ok": True}
    raise HTTPException(404, "Account not found")


# ── Cost / usage endpoints ───────────────────────────────────

@router.get("/costs")
async def cost_summary():
    """Aggregate cost dashboard across all accounts."""
    return _accounts().get_cost_summary()


@router.get("/costs/detailed")
async def cost_detailed():
    """Per-account cost breakdown."""
    mgr = _accounts()
    accounts = mgr.list_accounts()
    rows = []
    for a in accounts:
        rows.append({
            "id": a.id,
            "name": a.name,
            "provider": a.provider.value,
            "plan": a.plan_tier,
            "daily_cost": round(a.usage.daily_cost_usd, 4),
            "monthly_cost": round(a.usage.total_cost_usd, 4),
            "daily_requests": a.usage.daily_requests,
            "total_requests": a.usage.total_requests,
            "budget": a.limits.budget_remaining(a.usage),
            "over_budget": a.is_over_budget,
        })
    return {"accounts": rows, "summary": mgr.get_cost_summary()}


# ── VM endpoints ─────────────────────────────────────────────

@router.get("/vms")
async def list_vms():
    return {"vms": [
        {
            "id": s.id, "name": s.name, "state": s.state.value,
            "account_id": s.account_id, "tool": s.tool,
            "uptime": s.uptime_seconds, "ip": s.ip_address,
            "code_mount": s.code_mount,
        }
        for s in _vms().list_vms()
    ]}


@router.post("/vms")
async def create_vm(req: CreateVMReq):
    config = VMConfig(
        name=req.name,
        account_id=req.account_id,
        tool=req.tool,
        vcpus=req.vcpus,
        memory_mb=req.memory_mb,
        disk_gb=req.disk_gb,
        base_image=req.base_image,
        code_mount_host=req.code_mount_host,
    )
    vm = _vms().create_vm(config)
    return {"id": vm.id, "name": vm.name, "state": vm.state.value}


@router.post("/vms/{vm_id}/start")
async def start_vm(vm_id: str):
    if _vms().start_vm(vm_id):
        return {"ok": True}
    raise HTTPException(500, "Failed to start VM")


@router.post("/vms/{vm_id}/stop")
async def stop_vm(vm_id: str, force: bool = False):
    if _vms().stop_vm(vm_id, force=force):
        return {"ok": True}
    raise HTTPException(500, "Failed to stop VM")


@router.post("/vms/{vm_id}/pause")
async def pause_vm(vm_id: str):
    if _vms().pause_vm(vm_id):
        return {"ok": True}
    raise HTTPException(500, "Failed to pause VM")


@router.post("/vms/{vm_id}/resume")
async def resume_vm(vm_id: str):
    if _vms().resume_vm(vm_id):
        return {"ok": True}
    raise HTTPException(500, "Failed to resume VM")


@router.post("/vms/{vm_id}/snapshot")
async def snapshot_vm(vm_id: str, name: str = ""):
    if _vms().snapshot_vm(vm_id, name):
        return {"ok": True}
    raise HTTPException(500, "Failed to create snapshot")


@router.post("/vms/{vm_id}/switch-project")
async def switch_project(vm_id: str, req: SwitchProjectReq):
    if _vms().switch_project(vm_id, req.project_path):
        return {"ok": True}
    raise HTTPException(500, "Failed to switch project")


@router.delete("/vms/{vm_id}")
async def delete_vm(vm_id: str):
    if _vms().delete_vm(vm_id):
        return {"ok": True}
    raise HTTPException(404, "VM not found")


# ── System status ────────────────────────────────────────────

@router.get("/system")
async def system_status():
    """Full system overview: accounts + VMs + costs + libvirt status."""
    libvirt = VMOrchestrator.check_libvirt_available()
    return {
        "accounts": _accounts().get_cost_summary(),
        "vms": {
            "total": len(_vms().vms),
            "running": sum(1 for v in _vms().vms.values() if v.state.value == "running"),
        },
        "libvirt": libvirt,
    }
