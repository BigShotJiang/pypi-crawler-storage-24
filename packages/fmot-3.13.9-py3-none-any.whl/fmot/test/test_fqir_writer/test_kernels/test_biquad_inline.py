import fmot
import pytest
from fmot.fqir.writer import new_fqir_graph, FQIRWriter
from fmot.fqir.writer.kernels.biquad import write_biquad
from scipy.signal import butter, lfilter
from fmot.fqir import GraphProto
import torch
from torch import nn
import numpy as np

HOP = 160


class MyModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.stft = fmot.nn.STFT(n_fft=2 * HOP, hop_size=HOP)
        self.mag = fmot.nn.signal_processing.BarniMagnitude()
        self.lstm = torch.nn.LSTM(HOP + 1, 32, batch_first=True)

    def forward(self, x):
        re, im = self.stft(x)
        mag = self.mag(re, im)
        res, _ = self.lstm(mag)
        return res


def get_nn_fqir():
    model = MyModel()

    # training would go here ...
    cmodel = fmot.ConvertedModel(model, batch_dim=0, seq_dim=1)
    cmodel.quantize([torch.randn(8, 10, 160) for _ in range(5)])

    graph = cmodel.trace()
    return graph


def inline_butter_with_graph(graph: GraphProto, sr: int = 16000, cutoff: float = 100):
    # step 1: construct an FQIR graph with same inputs as the original graph
    new_graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(new_graph)

    # copy the input format from the original graph
    (audio_in,) = writer.add_inputs_from_graph(graph)

    # step 2: add the biquad kernel
    # tip: largest max-abs is 2^(B-1 + quanta)
    quanta_in = audio_in.quanta
    quanta_out_i24 = quanta_in - 7

    with writer.with_precision("int24") as pwriter:
        b, a = butter(N=2, Wn=cutoff, btype="high", fs=sr, output="ba")
        filtered_audio_i24 = write_biquad(
            pwriter, x=audio_in, b=b, a=a, quanta=quanta_out_i24
        )

    # cast back to int16
    filtered_audio_i16 = writer.multiply(filtered_audio_i24, 1, quanta=quanta_in)

    # inline the original FQIR graph
    (nn_output,) = writer.inline_fqir_graph(graph=graph, inputs=[filtered_audio_i16])

    # return the final output
    writer.add_outputs([nn_output])

    return new_graph


@pytest.mark.parametrize("input_maxabs", [2**13 - 1, 2**14 - 1, int(2**14.5)])
def test_butter_inlining(input_maxabs: int):
    graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(graph)
    x = writer.add_input(160, -15)
    writer.add_outputs([x])

    # graph = get_nn_fqir()
    sr = 16000
    cutoff = 100
    buttery_graph = inline_butter_with_graph(graph, sr, cutoff)

    # run random inputs through
    input_data = np.random.randint(low=-input_maxabs, high=input_maxabs, size=(50, HOP))
    outs_buttery = buttery_graph.run(input_data)

    # use scipy to apply float HPF
    scipy_filt = lfilter(*butter(2, cutoff, "high", fs=sr), input_data.flatten())
    scipy_filt = scipy_filt.reshape(50, HOP).astype(np.int32)

    outs_scipy_filt = graph.run(scipy_filt)

    rmse = np.sqrt(np.mean((outs_scipy_filt - outs_buttery) ** 2))
    nrmse = rmse / np.sqrt(np.mean(outs_scipy_filt**2))

    print(f"{nrmse=:.2E} for input_maxabs=2^{np.log2(input_maxabs):.0f}")
    # this is the error that can be achieved for inputs with scale <= 2^13
    assert nrmse < 1e-3
