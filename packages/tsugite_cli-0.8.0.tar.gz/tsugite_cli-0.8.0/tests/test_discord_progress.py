"""Tests for Discord progress handler."""

import asyncio
import sys
from unittest.mock import MagicMock

import pytest

# Mock discord modules BEFORE importing anything that needs them
# This is necessary because pytest discovers and imports test files before fixtures run
_original_discord = sys.modules.get("discord")
_original_discord_ext = sys.modules.get("discord.ext")
_original_discord_ext_commands = sys.modules.get("discord.ext.commands")

sys.modules["discord"] = MagicMock()
sys.modules["discord.ext"] = MagicMock()
sys.modules["discord.ext.commands"] = MagicMock()

from tsugite.daemon.adapters.discord import DiscordAdapter, DiscordProgressHandler  # noqa: E402
from tsugite.events import (  # noqa: E402
    CodeExecutionEvent,
    ErrorEvent,
    FinalAnswerEvent,
    ObservationEvent,
    ReasoningContentEvent,
    StepStartEvent,
    WarningEvent,
)  # noqa: E402


@pytest.fixture(autouse=True, scope="module")
def cleanup_discord_mocks():
    """Cleanup discord mocks after module tests complete."""
    yield
    # Restore original modules after all tests in this module
    if _original_discord is not None:
        sys.modules["discord"] = _original_discord
    else:
        sys.modules.pop("discord", None)

    if _original_discord_ext is not None:
        sys.modules["discord.ext"] = _original_discord_ext
    else:
        sys.modules.pop("discord.ext", None)

    if _original_discord_ext_commands is not None:
        sys.modules["discord.ext.commands"] = _original_discord_ext_commands
    else:
        sys.modules.pop("discord.ext.commands", None)


class MockChannel:
    """Mock Discord channel for testing."""

    def __init__(self):
        self.messages = []
        self.edits = []
        self.typing_triggered = 0

    async def send(self, content):
        """Mock send."""
        msg = MockMessage(content)
        self.messages.append(msg)
        return msg

    async def typing(self):
        """Mock typing indicator."""
        self.typing_triggered += 1

    async def trigger_typing(self):
        """Mock trigger_typing (alias)."""
        self.typing_triggered += 1


class MockMessage:
    """Mock Discord message."""

    def __init__(self, content):
        self.content = content
        self.edit_history = [content]

    async def edit(self, content):
        """Mock edit."""
        self.content = content
        self.edit_history.append(content)


@pytest.mark.asyncio
async def test_progress_handler_turns():
    """Test progress handler with turn and execution events."""
    channel = MockChannel()
    handler = DiscordProgressHandler(channel, asyncio.get_running_loop())

    # First turn (use _handle_event_async directly for testing)
    await handler._handle_event_async(StepStartEvent(step=1, max_turns=10))
    assert len(channel.messages) == 1
    assert "Turn 1/10" in channel.messages[0].content
    assert "🤔 Working..." in channel.messages[0].content

    # Code execution
    await handler._handle_event_async(CodeExecutionEvent(code="print('hello')"))
    assert "Executing" in channel.messages[0].content
    assert "⚙️" in channel.messages[0].content

    # Observation marks previous complete
    await handler._handle_event_async(ObservationEvent(observation="hello", success=True))
    assert "✓" in channel.messages[0].content

    # Second turn (marks previous as complete)
    await handler._handle_event_async(StepStartEvent(step=2, max_turns=10))
    assert "Turn 2/10" in channel.messages[0].content

    # Final answer
    await handler._handle_event_async(FinalAnswerEvent(answer="Done!", turns=2, tokens=100, cost=0.01))
    assert "✅ Done (2 turns)" in channel.messages[0].content
    assert handler.done


@pytest.mark.asyncio
async def test_progress_handler_reasoning():
    """Test progress handler with reasoning events."""
    channel = MockChannel()
    handler = DiscordProgressHandler(channel, asyncio.get_running_loop())

    # Reasoning event (use _handle_event_async directly for testing)
    await handler._handle_event_async(ReasoningContentEvent(content="Thinking about the problem..."))
    assert len(channel.messages) == 1
    assert "Thinking" in channel.messages[0].content
    assert "💭" in channel.messages[0].content


@pytest.mark.asyncio
async def test_progress_handler_warning_and_error():
    """Test progress handler with warning and error events."""
    channel = MockChannel()
    handler = DiscordProgressHandler(channel, asyncio.get_running_loop())

    await handler._handle_event_async(StepStartEvent(step=1, max_turns=10))
    await handler._handle_event_async(WarningEvent(message="Rate limited"))
    assert "⚠️" in channel.messages[0].content
    assert "Retrying" in channel.messages[0].content

    await handler._handle_event_async(ErrorEvent(error="Fatal error"))
    assert "❌" in channel.messages[0].content


@pytest.mark.asyncio
async def test_progress_handler_truncation():
    """Test progress handler truncates long step lists."""
    channel = MockChannel()
    handler = DiscordProgressHandler(channel, asyncio.get_running_loop())

    # Add 15 turns (more than MAX_DISPLAY_STEPS)
    for i in range(1, 16):
        await handler._handle_event_async(StepStartEvent(step=i, max_turns=20))

    # Check that only recent steps are shown
    content = channel.messages[0].content
    assert "earlier steps" in content
    assert "Turn 15/20" in content  # Last turn
    assert "Turn 1/20" not in content  # First turn should be truncated


@pytest.mark.asyncio
async def test_progress_handler_typing_loop():
    """Test typing loop keeps indicator active."""
    channel = MockChannel()
    handler = DiscordProgressHandler(channel, asyncio.get_running_loop())

    # Start typing loop
    await handler.start_typing_loop()

    # Wait for a few typing triggers
    await asyncio.sleep(0.5)
    assert channel.typing_triggered >= 1

    # Cleanup should cancel typing
    await handler.cleanup(success=True)
    initial_count = channel.typing_triggered

    # Wait and verify typing stopped
    await asyncio.sleep(0.5)
    assert channel.typing_triggered == initial_count  # No new triggers


@pytest.mark.asyncio
async def test_progress_handler_error_state():
    """Test progress handler shows error state."""
    channel = MockChannel()
    handler = DiscordProgressHandler(channel, asyncio.get_running_loop())

    # Add a turn
    await handler._handle_event_async(StepStartEvent(step=1, max_turns=10))

    # Cleanup with failure
    await handler.cleanup(success=False)

    # Check error state
    assert "❌ Error after 1 turn" in channel.messages[0].content


@pytest.mark.asyncio
async def test_progress_handler_summary():
    """Test progress handler summary counts turns correctly."""
    channel = MockChannel()
    handler = DiscordProgressHandler(channel, asyncio.get_running_loop())

    # Add multiple turns
    await handler._handle_event_async(StepStartEvent(step=1, max_turns=10))
    await handler._handle_event_async(CodeExecutionEvent(code="x = 1"))
    await handler._handle_event_async(ObservationEvent(observation="done", success=True))
    await handler._handle_event_async(StepStartEvent(step=2, max_turns=10))
    await handler._handle_event_async(CodeExecutionEvent(code="x = 2"))
    await handler._handle_event_async(ObservationEvent(observation="done", success=True))
    await handler._handle_event_async(StepStartEvent(step=3, max_turns=10))

    # Final answer
    await handler._handle_event_async(FinalAnswerEvent(answer="Done!", turns=3, tokens=50, cost=0.005))

    # Check summary shows turn count
    content = channel.messages[0].content
    assert "✅ Done (3 turns)" in content


class TestCodeBlockChunking:
    """Tests for code block aware message chunking."""

    @pytest.fixture
    def adapter(self):
        """Create adapter instance for testing chunking method."""
        adapter = object.__new__(DiscordAdapter)
        return adapter

    def test_short_message_no_split(self, adapter):
        """Short message should not be split."""
        text = "Hello world"
        chunks = adapter._split_respecting_code_blocks(text, 2000)
        assert chunks == ["Hello world"]

    def test_long_text_splits_on_newlines(self, adapter):
        """Long text without code blocks splits on newlines."""
        lines = ["Line " + str(i) for i in range(100)]
        text = "\n".join(lines)
        chunks = adapter._split_respecting_code_blocks(text, 200)
        assert len(chunks) > 1
        for chunk in chunks:
            assert len(chunk) <= 200

    def test_code_block_kept_whole(self, adapter):
        """Code block that fits should not be split."""
        text = "Before\n```python\ndef foo():\n    pass\n```\nAfter"
        chunks = adapter._split_respecting_code_blocks(text, 2000)
        assert len(chunks) == 1
        assert "```python" in chunks[0]
        assert "```" in chunks[0]

    def test_code_block_starts_new_chunk(self, adapter):
        """Code block that doesn't fit with text starts new chunk."""
        prefix = "x" * 100
        code = "```python\ndef foo():\n    pass\n```"
        text = prefix + "\n" + code
        # limit=120 means: prefix (100) fits, but prefix+code (135) doesn't
        # code alone (35) fits, so code should start new chunk
        chunks = adapter._split_respecting_code_blocks(text, 120)
        assert len(chunks) >= 2
        code_chunk = [c for c in chunks if "```python" in c][0]
        assert code_chunk.startswith("```python")
        assert code_chunk.endswith("```")

    def test_long_code_block_split_with_continuation(self, adapter):
        """Code block exceeding limit gets split with continuation markers."""
        lines = [f"    line{i} = {i}" for i in range(50)]
        code = "```python\n" + "\n".join(lines) + "\n```"
        chunks = adapter._split_respecting_code_blocks(code, 300)
        assert len(chunks) > 1
        for chunk in chunks:
            assert chunk.startswith("```python")
            assert chunk.endswith("```")
            assert len(chunk) <= 300

    def test_language_identifier_preserved(self, adapter):
        """Language identifier preserved when splitting code blocks."""
        lines = [f"const x{i} = {i};" for i in range(50)]
        code = "```javascript\n" + "\n".join(lines) + "\n```"
        chunks = adapter._split_respecting_code_blocks(code, 300)
        for chunk in chunks:
            assert chunk.startswith("```javascript")

    def test_multiple_code_blocks(self, adapter):
        """Multiple code blocks handled correctly."""
        text = "Text1\n```python\ncode1\n```\nText2\n```bash\ncode2\n```\nText3"
        chunks = adapter._split_respecting_code_blocks(text, 2000)
        assert len(chunks) == 1
        assert "```python" in chunks[0]
        assert "```bash" in chunks[0]

    def test_empty_chunks_skipped(self, adapter):
        """Empty chunks should not appear in output."""
        text = "\n\n\nHello\n\n\n"
        chunks = adapter._split_respecting_code_blocks(text, 2000)
        for chunk in chunks:
            assert chunk.strip()
