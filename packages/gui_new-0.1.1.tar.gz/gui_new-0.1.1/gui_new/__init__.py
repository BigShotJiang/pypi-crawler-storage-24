"""gui-new: HTML in, URL out."""

from .client import Canvas, create, update, get, extend, delete

__version__ = "0.1.1"
__all__ = ["Canvas", "create", "update", "get", "extend", "delete"]
