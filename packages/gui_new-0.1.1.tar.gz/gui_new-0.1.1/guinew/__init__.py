"""gui-new: Instant shareable HTML canvases."""

from .client import GuiClient, create, update, extend

gui = GuiClient()

__all__ = ["GuiClient", "gui", "create", "update", "extend"]
