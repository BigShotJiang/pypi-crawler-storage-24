# gui-new

HTML in, URL out. Python SDK for [gui.new](https://gui.new).

## Install

```bash
pip install gui-new
```

## Quick Start

```python
import gui_new

canvas = gui_new.create("<h1>Hello World</h1>")
print(canvas.url)
```

## Create with a title

```python
canvas = gui_new.create(
    html="<h1 style='color:red'>Alert</h1>",
    title="My Dashboard"
)
```

## Update a canvas

```python
gui_new.update(canvas.id, "<h1>Updated</h1>", canvas.edit_token)
```

## Extend expiry (+24h)

```python
gui_new.extend(canvas.id, canvas.edit_token)
```

## Delete a canvas

```python
gui_new.delete(canvas.id, canvas.edit_token)
```

## Pro API Key

Set the environment variable to authenticate:

```bash
export GUI_NEW_API_KEY=your_key
```

The SDK picks it up automatically — no code changes needed.

## Links

- [gui.new](https://gui.new)
- [API Docs](https://gui.new/docs)
- [npm SDK](https://www.npmjs.com/package/gui-new)
