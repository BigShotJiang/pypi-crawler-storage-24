"""CLI for SpeakLine."""

import logging
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.logging import RichHandler

from .commenter import VoiceCommenter, VoiceCommenterError
from .recorder import AudioConfig
from .transcriber import WhisperTranscriber, OpenAITranscriber, MockTranscriber

console = Console()
app = typer.Typer(name="speakline", help="Record voice and insert as code comments.", add_completion=False)


def _setup_logging(verbose: bool = False):
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(console=console, rich_tracebacks=True)],
    )


def _make_transcriber(backend: str, model_size: str, api_key: Optional[str]):
    if backend == "whisper":
        return WhisperTranscriber(model_size=model_size)
    elif backend == "openai":
        if not api_key:
            console.print("[red]Error:[/red] Need an OpenAI API key. Set OPENAI_API_KEY or use --api-key")
            raise typer.Exit(1)
        return OpenAITranscriber(api_key=api_key)
    elif backend == "mock":
        return MockTranscriber()
    else:
        console.print(f"[red]Error:[/red] Unknown backend '{backend}'")
        raise typer.Exit(1)


@app.command()
def record(
    filepath: str = typer.Argument(..., help="Source file to modify"),
    line_number: int = typer.Argument(..., help="Line number to insert at"),
    duration: Optional[float] = typer.Option(None, "--duration", "-d", help="Recording duration (seconds)"),
    language: Optional[str] = typer.Option(None, "--language", "-l", help="Programming language"),
    backend: str = typer.Option("whisper", "--backend", "-b", help="Transcription backend"),
    model_size: str = typer.Option("base", "--model-size", "-m", help="Whisper model size"),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="OPENAI_API_KEY"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
):
    """Record voice and insert as comment in a source file."""
    _setup_logging(verbose)

    transcriber = _make_transcriber(backend, model_size, api_key)
    commenter = VoiceCommenter(language=language, transcriber=transcriber)

    console.print(f"[blue]Recording for {filepath}:{line_number}[/blue]")
    if duration:
        console.print(f"[dim]{duration}s fixed duration...[/dim]")
    else:
        console.print("[dim]Speak, then pause to stop...[/dim]")

    try:
        comment = commenter.record_and_insert(filepath, line_number, duration)
        console.print(f"[green]Inserted:[/green] {comment}")
    except (FileNotFoundError, VoiceCommenterError) as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def transcribe(
    duration: Optional[float] = typer.Option(None, "--duration", "-d"),
    backend: str = typer.Option("whisper", "--backend", "-b"),
    model_size: str = typer.Option("base", "--model-size", "-m"),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="OPENAI_API_KEY"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
):
    """Record and print transcription (no file changes)."""
    _setup_logging(verbose)

    transcriber = _make_transcriber(backend, model_size, api_key)
    commenter = VoiceCommenter(transcriber=transcriber)

    console.print("[dim]Recording...[/dim]")

    try:
        text = commenter.transcribe_only(duration=duration)
        console.print(f"[green]Transcription:[/green] {text}")
    except VoiceCommenterError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def insert(
    filepath: str = typer.Argument(..., help="Source file to modify"),
    line_number: int = typer.Argument(..., help="Line number to insert at"),
    comment: str = typer.Argument(..., help="Comment text"),
    language: Optional[str] = typer.Option(None, "--language", "-l"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
):
    """Insert a text comment directly (no recording needed)."""
    _setup_logging(verbose)

    commenter = VoiceCommenter(language=language)
    try:
        commenter.insert_comment_to_file(filepath, comment, line_number)
        console.print(f"[green]Done:[/green] comment added at {filepath}:{line_number}")
    except (FileNotFoundError, VoiceCommenterError) as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def version():
    """Print version."""
    from . import __version__
    console.print(f"speakline {__version__}")


def main():
    app()


if __name__ == "__main__":
    main()
