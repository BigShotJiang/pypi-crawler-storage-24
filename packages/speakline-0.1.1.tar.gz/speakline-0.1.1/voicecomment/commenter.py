"""Main orchestration — ties recording, transcription, and comment insertion together."""

import os
import logging
from typing import Optional

from .recorder import RecorderBase, LocalAudioRecorder, AudioConfig, RecorderError
from .transcriber import TranscriberBase, WhisperTranscriber, TranscriberError
from .parser import CodeParser, ParserError

logger = logging.getLogger(__name__)


class VoiceCommenterError(Exception):
    pass


class VoiceCommenter:
    def __init__(self, language: Optional[str] = None, transcriber: Optional[TranscriberBase] = None,
                 recorder: Optional[RecorderBase] = None, audio_config: Optional[AudioConfig] = None):
        self._language = language
        self._config = audio_config or AudioConfig()
        self._recorder = recorder or LocalAudioRecorder(config=self._config)

        if transcriber:
            self._transcriber = transcriber
        else:
            try:
                self._transcriber = WhisperTranscriber(model_size="base")
            except Exception as e:
                raise VoiceCommenterError(
                    f"Could not init transcriber: {e}. "
                    "Make sure openai-whisper is installed."
                )

    def record_and_insert(self, filepath: str, line_number: int,
                          duration: Optional[float] = None) -> str:
        """Record voice, transcribe it, and insert as a comment into the file."""
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")

        try:
            audio = self._recorder.record(duration=duration)
        except RecorderError as e:
            raise VoiceCommenterError(f"Recording failed: {e}")

        try:
            comment = self._transcriber.transcribe(audio, sample_rate=self._recorder.sample_rate)
        except TranscriberError as e:
            raise VoiceCommenterError(f"Transcription failed: {e}")

        if not comment.strip():
            raise VoiceCommenterError("Got empty transcription")

        self.insert_comment_to_file(filepath, comment, line_number)
        return comment

    def transcribe_only(self, duration: Optional[float] = None) -> str:
        """Record and return transcribed text without touching any files."""
        try:
            audio = self._recorder.record(duration=duration)
        except RecorderError as e:
            raise VoiceCommenterError(f"Recording failed: {e}")

        try:
            return self._transcriber.transcribe(audio, sample_rate=self._recorder.sample_rate)
        except TranscriberError as e:
            raise VoiceCommenterError(f"Transcription failed: {e}")

    def insert_comment_to_string(self, code: str, comment: str, line_number: int,
                                 language: Optional[str] = None) -> str:
        """Insert a comment into a code string (no file I/O). Handy for notebooks."""
        parser = CodeParser(language=language or self._language)
        try:
            return parser.insert_comment(code, comment, line_number)
        except ParserError as e:
            raise VoiceCommenterError(str(e))

    def insert_comment_to_file(self, filepath: str, comment: str, line_number: int):
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")

        with open(filepath, "r", encoding="utf-8") as f:
            code = f.read()

        parser = CodeParser(language=self._language, filepath=filepath)
        try:
            updated = parser.insert_comment(code, comment, line_number)
        except ParserError as e:
            raise VoiceCommenterError(str(e))

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(updated)

        logger.info(f"Inserted comment at {filepath}:{line_number}")

    @property
    def language(self) -> Optional[str]:
        return self._language

    @language.setter
    def language(self, val: Optional[str]):
        self._language = val

    @property
    def recorder(self) -> RecorderBase:
        return self._recorder

    @property
    def transcriber(self) -> TranscriberBase:
        return self._transcriber
