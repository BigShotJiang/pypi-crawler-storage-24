"""Language-aware comment insertion for source code files."""

import os
import re
import logging
from typing import Optional, Dict

logger = logging.getLogger(__name__)


class ParserError(Exception):
    pass


COMMENT_PREFIXES: Dict[str, str] = {
    "python": "#",
    "javascript": "//",
    "typescript": "//",
    "go": "//",
    "rust": "//",
    "java": "//",
    "csharp": "//",
    "ruby": "#",
    "c": "//",
    "cpp": "//",
}

EXTENSION_MAP: Dict[str, str] = {
    ".py": "python", ".pyw": "python",
    ".js": "javascript", ".mjs": "javascript", ".cjs": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "typescript", ".mts": "typescript", ".cts": "typescript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".cs": "csharp",
    ".rb": "ruby",
    ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp", ".hpp": "cpp", ".hxx": "cpp",
}

LANGUAGE_ALIASES: Dict[str, str] = {
    "py": "python", "js": "javascript", "ts": "typescript",
    "cs": "csharp", "c#": "csharp", "c++": "cpp",
}


def get_language_from_extension(filepath: str) -> Optional[str]:
    _, ext = os.path.splitext(filepath.lower())
    return EXTENSION_MAP.get(ext)


def _get_indentation(line: str) -> str:
    match = re.match(r"^(\s*)", line)
    return match.group(1) if match else ""


def insert_comment(code: str, comment: str, line_number: int, prefix: str = "#") -> str:
    """Insert a comment before the given line, matching its indentation."""
    lines = code.split("\n")

    if line_number < 1 or line_number > len(lines) + 1:
        raise ParserError(f"Line {line_number} out of range (1-{len(lines) + 1})")

    if line_number <= len(lines):
        target = lines[line_number - 1]
    else:
        target = lines[-1] if lines else ""

    indent = _get_indentation(target)

    # format each line of the comment
    comment_lines = comment.strip().split("\n")
    formatted = "\n".join(f"{indent}{prefix} {l.strip()}" for l in comment_lines)

    lines.insert(line_number - 1, formatted)
    return "\n".join(lines)


class CodeParser:
    """Handles comment insertion for any supported language."""

    def __init__(self, language: Optional[str] = None, filepath: Optional[str] = None):
        self.language = language
        if self.language is None and filepath:
            self.language = get_language_from_extension(filepath)

        # resolve aliases
        if self.language:
            self.language = LANGUAGE_ALIASES.get(self.language.lower(), self.language.lower())

        if self.language and self.language in COMMENT_PREFIXES:
            self.prefix = COMMENT_PREFIXES[self.language]
        else:
            if self.language:
                logger.warning(f"Unknown language '{self.language}', defaulting to #")
            self.prefix = "#"

    def insert_comment(self, code: str, comment: str, line_number: int) -> str:
        return insert_comment(code, comment, line_number, self.prefix)


# backwards compat aliases used internally
ParserBase = CodeParser
GenericParser = CodeParser
PythonParser = type("PythonParser", (CodeParser,), {})
JavaScriptParser = type("JavaScriptParser", (CodeParser,), {})
TypeScriptParser = type("TypeScriptParser", (CodeParser,), {})
GoParser = type("GoParser", (CodeParser,), {})
RustParser = type("RustParser", (CodeParser,), {})
JavaParser = type("JavaParser", (CodeParser,), {})
CSharpParser = type("CSharpParser", (CodeParser,), {})
RubyParser = type("RubyParser", (CodeParser,), {})
CppParser = type("CppParser", (CodeParser,), {})
InvalidLineNumberError = ParserError


def get_parser(language: Optional[str] = None, filepath: Optional[str] = None) -> CodeParser:
    return CodeParser(language=language, filepath=filepath)
