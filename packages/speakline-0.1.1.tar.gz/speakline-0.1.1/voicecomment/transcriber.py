"""Speech-to-text backends for audio transcription."""

import os
import logging
import tempfile
from abc import ABC, abstractmethod
from typing import Optional, Literal

import numpy as np

logger = logging.getLogger(__name__)

WhisperModelSize = Literal["tiny", "base", "small", "medium", "large"]


class TranscriberError(Exception):
    pass

# keep these around for imports but they're just aliases
ModelNotFoundError = TranscriberError
APIError = TranscriberError


class TranscriberBase(ABC):
    @abstractmethod
    def transcribe(self, audio: np.ndarray, sample_rate: int = 16000) -> str:
        ...


class WhisperTranscriber(TranscriberBase):
    """Local Whisper model. No API key needed."""

    def __init__(self, model_size: WhisperModelSize = "base", device: Optional[str] = None,
                 language: Optional[str] = None):
        self._model_size = model_size
        self._device = device
        self._language = language
        self._model = None

    def _load_model(self):
        if self._model is not None:
            return self._model
        try:
            import whisper
        except ImportError:
            raise TranscriberError("openai-whisper not installed: pip install openai-whisper")

        logger.info(f"Loading Whisper {self._model_size} model...")
        self._model = whisper.load_model(self._model_size, device=self._device)
        return self._model

    def transcribe(self, audio: np.ndarray, sample_rate: int = 16000) -> str:
        model = self._load_model()

        audio = audio.astype(np.float32)
        if sample_rate != 16000:
            audio = self._resample(audio, sample_rate, 16000)

        opts = {"language": self._language} if self._language else {}
        result = model.transcribe(audio, **opts)
        return result["text"].strip()

    def _resample(self, audio: np.ndarray, orig_sr: int, target_sr: int) -> np.ndarray:
        try:
            import scipy.signal
            n_samples = int(len(audio) * target_sr / orig_sr)
            return scipy.signal.resample(audio, n_samples).astype(np.float32)
        except ImportError:
            # crude fallback without scipy
            ratio = target_sr / orig_sr
            indices = np.clip(
                np.arange(0, len(audio), 1 / ratio).astype(int),
                0, len(audio) - 1
            )
            return audio[indices]


class OpenAITranscriber(TranscriberBase):
    """OpenAI Whisper API backend."""

    def __init__(self, api_key: Optional[str] = None, model: str = "whisper-1",
                 language: Optional[str] = None):
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self._model = model
        self._language = language
        self._client = None

    def _get_client(self):
        if self._client is not None:
            return self._client
        try:
            import openai
        except ImportError:
            raise TranscriberError("openai not installed: pip install openai")
        if not self._api_key:
            raise TranscriberError("OpenAI API key required — set OPENAI_API_KEY or pass api_key")
        self._client = openai.OpenAI(api_key=self._api_key)
        return self._client

    def transcribe(self, audio: np.ndarray, sample_rate: int = 16000) -> str:
        client = self._get_client()

        # API needs a wav file, so write to a temp file
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp_path = tmp.name
        tmp.close()

        try:
            self._write_wav(tmp_path, audio, sample_rate)
            with open(tmp_path, "rb") as f:
                kwargs = {"model": self._model, "file": f}
                if self._language:
                    kwargs["language"] = self._language
                resp = client.audio.transcriptions.create(**kwargs)
            return resp.text.strip()
        except TranscriberError:
            raise
        except Exception as e:
            raise TranscriberError(f"OpenAI API call failed: {e}")
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    @staticmethod
    def _write_wav(path: str, audio: np.ndarray, sample_rate: int):
        import wave
        pcm = (audio * 32767).astype(np.int16)
        with wave.open(path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm.tobytes())


class MockTranscriber(TranscriberBase):
    """Returns fixed text. For tests only."""

    def __init__(self, fixed_text: Optional[str] = None):
        self._text = fixed_text or "mock transcription for testing"

    def transcribe(self, audio: np.ndarray, sample_rate: int = 16000) -> str:
        return self._text


def get_transcriber(backend: str = "whisper", **kwargs) -> TranscriberBase:
    backends = {
        "whisper": WhisperTranscriber,
        "openai": OpenAITranscriber,
        "mock": MockTranscriber,
    }
    if backend not in backends:
        raise ValueError(f"Unknown backend '{backend}', expected one of {list(backends)}")
    return backends[backend](**kwargs)
