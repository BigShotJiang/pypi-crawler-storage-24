"""SpeakLine — voice-to-code comments for any language and IDE."""

__version__ = "0.1.1"

from .commenter import VoiceCommenter, VoiceCommenterError
from .recorder import AudioConfig, SilenceConfig, LocalAudioRecorder, MockRecorder, RecorderError
from .transcriber import (
    WhisperTranscriber, OpenAITranscriber, MockTranscriber,
    TranscriberError, get_transcriber,
)
from .parser import CodeParser, get_parser, get_language_from_extension, ParserError
