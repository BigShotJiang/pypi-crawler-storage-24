"""Audio recording with microphone input and silence detection."""

import time
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)


class RecorderError(Exception):
    pass

AudioDeviceError = RecorderError


@dataclass
class AudioConfig:
    sample_rate: int = 16000
    channels: int = 1
    chunk_size: int = 1024
    format_width: int = 2  # 16-bit


@dataclass
class SilenceConfig:
    threshold: float = 0.01
    duration: float = 2.0
    min_recording_duration: float = 1.0


class RecorderBase(ABC):
    @abstractmethod
    def record(self, duration: Optional[float] = None, silence_detection: bool = True) -> np.ndarray:
        ...

    @property
    @abstractmethod
    def sample_rate(self) -> int:
        ...


class LocalAudioRecorder(RecorderBase):
    """Records from system mic via PyAudio."""

    def __init__(self, config: Optional[AudioConfig] = None,
                 silence_config: Optional[SilenceConfig] = None):
        self._config = config or AudioConfig()
        self._silence = silence_config or SilenceConfig()
        self._pa = None

    def _init_pyaudio(self):
        if self._pa is not None:
            return self._pa
        try:
            import pyaudio
            self._pa = pyaudio.PyAudio()
        except ImportError:
            raise RecorderError("PyAudio not installed: pip install pyaudio")
        except Exception as e:
            raise RecorderError(f"Could not init PyAudio: {e}")
        return self._pa

    def _pyaudio_format(self):
        import pyaudio
        return {1: pyaudio.paInt8, 2: pyaudio.paInt16, 4: pyaudio.paInt32}.get(
            self._config.format_width, pyaudio.paInt16
        )

    def _to_numpy(self, raw: bytes) -> np.ndarray:
        dtype = {1: np.int8, 2: np.int16, 4: np.int32}.get(
            self._config.format_width, np.int16
        )
        arr = np.frombuffer(raw, dtype=dtype).astype(np.float32)
        return arr / np.iinfo(dtype).max

    def record(self, duration: Optional[float] = None, silence_detection: bool = True) -> np.ndarray:
        pa = self._init_pyaudio()

        try:
            stream = pa.open(
                format=self._pyaudio_format(),
                channels=self._config.channels,
                rate=self._config.sample_rate,
                input=True,
                frames_per_buffer=self._config.chunk_size,
            )
        except Exception as e:
            raise RecorderError(f"Failed to open audio stream: {e}")

        frames = []
        silence_start = None
        t0 = time.time()

        try:
            while True:
                try:
                    data = stream.read(self._config.chunk_size, exception_on_overflow=False)
                except Exception:
                    continue
                frames.append(data)
                elapsed = time.time() - t0

                if duration is not None:
                    if elapsed >= duration:
                        break
                    continue

                # silence detection
                if silence_detection and elapsed >= self._silence.min_recording_duration:
                    chunk = self._to_numpy(data)
                    is_quiet = np.abs(chunk).mean() < self._silence.threshold

                    if is_quiet:
                        if silence_start is None:
                            silence_start = time.time()
                        elif time.time() - silence_start >= self._silence.duration:
                            logger.info("Silence detected, stopping")
                            break
                    else:
                        silence_start = None
        finally:
            stream.stop_stream()
            stream.close()

        audio = self._to_numpy(b"".join(frames))
        logger.info(f"Recorded {len(audio) / self._config.sample_rate:.1f}s of audio")
        return audio

    @property
    def sample_rate(self) -> int:
        return self._config.sample_rate

    def __del__(self):
        if self._pa is not None:
            self._pa.terminate()


class MockRecorder(RecorderBase):
    """Generates fake audio for testing."""

    def __init__(self, config: Optional[AudioConfig] = None, mock_duration: float = 1.0):
        self._config = config or AudioConfig()
        self._duration = mock_duration

    def record(self, duration: Optional[float] = None, silence_detection: bool = True) -> np.ndarray:
        dur = duration or self._duration
        n = int(dur * self._config.sample_rate)
        t = np.linspace(0, dur, n)
        # 440hz tone + some noise to look like speech
        audio = np.sin(2 * np.pi * 440 * t) * 0.3 + np.random.normal(0, 0.1, n)
        return np.clip(audio, -1, 1).astype(np.float32)

    @property
    def sample_rate(self) -> int:
        return self._config.sample_rate
