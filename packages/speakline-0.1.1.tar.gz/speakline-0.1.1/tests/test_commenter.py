import os
import tempfile

import pytest
from voicecomment.commenter import VoiceCommenter, VoiceCommenterError
from voicecomment.recorder import MockRecorder
from voicecomment.transcriber import MockTranscriber


@pytest.fixture
def commenter():
    return VoiceCommenter(
        recorder=MockRecorder(),
        transcriber=MockTranscriber(fixed_text="Test comment"),
    )


@pytest.fixture
def tmp_pyfile():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write("def hello():\n    print('Hello, World!')\n")
        path = f.name
    yield path
    if os.path.exists(path):
        os.unlink(path)


def test_init_with_mocks():
    c = VoiceCommenter(recorder=MockRecorder(), transcriber=MockTranscriber())
    assert c.recorder is not None
    assert c.transcriber is not None


def test_language_property():
    c = VoiceCommenter(language="python", recorder=MockRecorder(), transcriber=MockTranscriber())
    assert c.language == "python"
    c.language = "javascript"
    assert c.language == "javascript"


def test_insert_to_string(commenter):
    code = "def foo():\n    pass"
    result = commenter.insert_comment_to_string(code, "This is a function", 1, language="python")
    assert "# This is a function" in result
    assert "def foo():" in result


def test_insert_preserves_all_lines(commenter):
    code = "line1\nline2\nline3"
    result = commenter.insert_comment_to_string(code, "My comment", 2, language="python")
    lines = result.split("\n")
    assert "line1" in lines
    assert "line2" in lines
    assert "line3" in lines
    assert len(lines) == 4


def test_insert_to_file(commenter, tmp_pyfile):
    commenter.insert_comment_to_file(tmp_pyfile, "This function says hello", 1)
    content = open(tmp_pyfile).read()
    assert "# This function says hello" in content
    assert "def hello():" in content


def test_insert_to_missing_file(commenter):
    with pytest.raises(FileNotFoundError):
        commenter.insert_comment_to_file("/nonexistent/file.py", "Test", 1)


def test_record_and_insert(commenter, tmp_pyfile):
    result = commenter.record_and_insert(tmp_pyfile, line_number=1, duration=0.5)
    assert result == "Test comment"
    assert "# Test comment" in open(tmp_pyfile).read()


def test_record_missing_file(commenter):
    with pytest.raises(FileNotFoundError):
        commenter.record_and_insert("/nonexistent/file.py", 1)


def test_transcribe_only(commenter):
    assert commenter.transcribe_only(duration=0.5) == "Test comment"


def test_transcribe_custom_text():
    c = VoiceCommenter(recorder=MockRecorder(), transcriber=MockTranscriber(fixed_text="custom"))
    assert c.transcribe_only(duration=0.5) == "custom"


def test_indentation_respected(commenter):
    code = "class Foo:\n    def bar(self):\n        return 42"
    result = commenter.insert_comment_to_string(code, "Return value", 3, language="python")
    comment_line = [l for l in result.split("\n") if "Return value" in l][0]
    assert comment_line.startswith("        #")


def test_js_comment_style():
    c = VoiceCommenter(recorder=MockRecorder(), transcriber=MockTranscriber())
    code = "function test() {\n    return true;\n}"
    result = c.insert_comment_to_string(code, "Returns true", 2, language="javascript")
    assert "// Returns true" in result


def test_empty_transcription_raises():
    c = VoiceCommenter(recorder=MockRecorder(), transcriber=MockTranscriber(fixed_text="   "))
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write("code = 1\n")
        path = f.name
    try:
        with pytest.raises(VoiceCommenterError, match="empty"):
            c.record_and_insert(path, 1, duration=0.5)
    finally:
        os.unlink(path)
