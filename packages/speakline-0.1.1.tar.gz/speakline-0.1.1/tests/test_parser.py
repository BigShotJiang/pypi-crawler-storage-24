import pytest
from voicecomment.parser import (
    CodeParser, get_parser, get_language_from_extension, ParserError,
)


class TestCodeParser:
    def test_default_prefix_is_hash(self):
        p = CodeParser()
        assert p.prefix == "#"

    def test_insert_at_first_line(self):
        p = CodeParser()
        result = p.insert_comment("print('hello')", "Say hello", 1)
        lines = result.split("\n")
        assert lines[0] == "# Say hello"
        assert lines[1] == "print('hello')"

    def test_preserves_indentation(self):
        p = CodeParser(language="python")
        code = "def foo():\n    return 42"
        result = p.insert_comment(code, "Return value", 2)
        lines = result.split("\n")
        assert lines[1] == "    # Return value"
        assert lines[2] == "    return 42"

    def test_insert_middle_of_file(self):
        p = CodeParser()
        code = "line1\nline2\nline3"
        result = p.insert_comment(code, "Before line 2", 2)
        lines = result.split("\n")
        assert lines == ["line1", "# Before line 2", "line2", "line3"]

    def test_line_zero_raises(self):
        with pytest.raises(ParserError):
            CodeParser().insert_comment("code", "comment", 0)

    def test_negative_line_raises(self):
        with pytest.raises(ParserError):
            CodeParser().insert_comment("code", "comment", -1)

    def test_line_too_large_raises(self):
        with pytest.raises(ParserError):
            CodeParser().insert_comment("line1\nline2", "comment", 4)

    def test_js_uses_double_slash(self):
        p = CodeParser(language="javascript")
        code = "function greet() {\n    console.log('Hello');\n}"
        result = p.insert_comment(code, "Log greeting", 2)
        assert "    // Log greeting" in result

    def test_go_uses_double_slash(self):
        p = CodeParser(language="go")
        code = "func main() {\n\tfmt.Println(\"Hello\")\n}"
        result = p.insert_comment(code, "Print hello", 2)
        assert "// Print hello" in result


class TestLanguageDetection:
    @pytest.mark.parametrize("filepath,expected", [
        ("file.py", "python"),
        ("file.pyw", "python"),
        ("file.js", "javascript"),
        ("file.jsx", "javascript"),
        ("file.ts", "typescript"),
        ("file.tsx", "typescript"),
        ("file.go", "go"),
        ("file.rs", "rust"),
        ("file.java", "java"),
        ("file.cs", "csharp"),
        ("file.rb", "ruby"),
        ("file.c", "c"),
        ("file.cpp", "cpp"),
        ("file.h", "c"),
        ("file.hpp", "cpp"),
    ])
    def test_known_extensions(self, filepath, expected):
        assert get_language_from_extension(filepath) == expected

    def test_unknown_returns_none(self):
        assert get_language_from_extension("file.xyz") is None

    def test_case_insensitive(self):
        assert get_language_from_extension("file.PY") == "python"


class TestGetParser:
    def test_by_language(self):
        p = get_parser(language="python")
        assert p.prefix == "#"

    def test_by_filepath(self):
        p = get_parser(filepath="test.js")
        assert p.prefix == "//"

    def test_unknown_language_defaults_to_hash(self):
        p = get_parser(language="brainfuck")
        assert p.prefix == "#"

    def test_no_args_defaults_to_hash(self):
        p = get_parser()
        assert p.prefix == "#"

    @pytest.mark.parametrize("alias,expected_prefix", [
        ("py", "#"),
        ("js", "//"),
        ("ts", "//"),
        ("cs", "//"),
        ("c#", "//"),
        ("c++", "//"),
    ])
    def test_aliases(self, alias, expected_prefix):
        p = get_parser(language=alias)
        assert p.prefix == expected_prefix
