import numpy as np
import pytest
from voicecomment.transcriber import MockTranscriber, TranscriberBase, get_transcriber


class TestMockTranscriber:
    def test_is_a_transcriber(self):
        assert isinstance(MockTranscriber(), TranscriberBase)

    def test_returns_string(self):
        audio = np.zeros(16000, dtype=np.float32)
        result = MockTranscriber().transcribe(audio)
        assert isinstance(result, str)

    def test_default_text(self):
        audio = np.zeros(16000, dtype=np.float32)
        result = MockTranscriber().transcribe(audio)
        assert "mock" in result.lower()

    def test_custom_text(self):
        t = MockTranscriber(fixed_text="hello world")
        audio = np.zeros(16000, dtype=np.float32)
        assert t.transcribe(audio) == "hello world"

    def test_ignores_audio_content(self):
        t = MockTranscriber(fixed_text="same")
        assert t.transcribe(np.zeros(100, dtype=np.float32)) == "same"
        assert t.transcribe(np.ones(100, dtype=np.float32)) == "same"
        assert t.transcribe(np.random.randn(100).astype(np.float32)) == "same"


class TestGetTranscriber:
    def test_mock_backend(self):
        assert isinstance(get_transcriber("mock"), MockTranscriber)

    def test_mock_with_kwargs(self):
        t = get_transcriber("mock", fixed_text="Custom")
        assert t.transcribe(np.zeros(100, dtype=np.float32)) == "Custom"

    def test_invalid_backend_raises(self):
        with pytest.raises(ValueError, match="Unknown backend"):
            get_transcriber("nope")
