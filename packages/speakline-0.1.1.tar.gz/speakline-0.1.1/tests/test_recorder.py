import numpy as np
import pytest
from voicecomment.recorder import AudioConfig, SilenceConfig, MockRecorder, RecorderBase


class TestAudioConfig:
    def test_defaults(self):
        c = AudioConfig()
        assert c.sample_rate == 16000
        assert c.channels == 1
        assert c.chunk_size == 1024
        assert c.format_width == 2

    def test_custom(self):
        c = AudioConfig(sample_rate=44100, channels=2, chunk_size=2048, format_width=4)
        assert c.sample_rate == 44100
        assert c.channels == 2


class TestSilenceConfig:
    def test_defaults(self):
        c = SilenceConfig()
        assert c.threshold == 0.01
        assert c.duration == 2.0
        assert c.min_recording_duration == 1.0


class TestMockRecorder:
    def test_is_a_recorder(self):
        assert isinstance(MockRecorder(), RecorderBase)

    def test_returns_numpy(self):
        audio = MockRecorder().record(duration=1.0)
        assert isinstance(audio, np.ndarray)

    def test_respects_duration(self):
        config = AudioConfig(sample_rate=16000)
        audio = MockRecorder(config=config).record(duration=2.0)
        assert len(audio) == 32000

    def test_uses_mock_duration_by_default(self):
        config = AudioConfig(sample_rate=16000)
        audio = MockRecorder(config=config, mock_duration=0.5).record()
        assert len(audio) == 8000

    def test_sample_rate(self):
        assert MockRecorder(config=AudioConfig(sample_rate=44100)).sample_rate == 44100

    def test_values_in_range(self):
        audio = MockRecorder().record(duration=1.0)
        assert audio.min() >= -1.0
        assert audio.max() <= 1.0

    def test_float32(self):
        audio = MockRecorder().record(duration=1.0)
        assert audio.dtype == np.float32
