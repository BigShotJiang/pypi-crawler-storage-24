# Phase 5: Structured Output & Rich Media — Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add Pydantic output schemas to all tools, 10 rich media tools, and a file metadata resource for v0.6.0.

**Architecture:** Create `models.py` (base ToolResponse) and `utils.py` (shared _normalize_parse_mode). Migrate all 21 existing tools from `dict[str, Any]` returns to Pydantic models. Add `tools/media.py` with 10 new media tools. Add `telegram://files/{file_id}` resource. Migrate all 150 existing tests from dict subscript to attribute access.

**Tech Stack:** Python 3.10+, pydantic (via fastmcp), aiogram >=3.20, fastmcp >=2.0, pytest, ruff, mypy

**Spec:** `docs/superpowers/specs/2026-03-12-phase5-structured-output-rich-media-design.md`

---

## Chunk 1: Foundation + Messaging Tools Migration

### Task 1: Create base models and shared utils

**Files:**
- Create: `aiogram_mcp/models.py`
- Create: `aiogram_mcp/utils.py`

- [ ] **Step 1: Create `aiogram_mcp/models.py`**

```python
"""Base Pydantic models for MCP tool responses."""

from __future__ import annotations

from pydantic import BaseModel


class ToolResponse(BaseModel):
    """Base model for all tool results. ok=True on success, ok=False with error on failure."""

    ok: bool
    error: str | None = None


class OkResult(ToolResponse):
    """Result for tools that return only ok/error (delete, pin, etc.)."""

    pass
```

- [ ] **Step 2: Create `aiogram_mcp/utils.py`**

Move `_normalize_parse_mode` from `tools/messaging.py`:

```python
"""Shared utilities for aiogram-mcp."""

from __future__ import annotations

from aiogram.enums import ParseMode


def normalize_parse_mode(parse_mode: str | None) -> ParseMode | None:
    """Convert a string parse_mode to aiogram ParseMode enum.

    Accepts: HTML, Markdown, MarkdownV2 (case-insensitive), or None.
    """
    if parse_mode is None:
        return None
    normalized = parse_mode.strip().upper()
    if normalized == "HTML":
        return ParseMode.HTML
    if normalized in {"MARKDOWN", "MARKDOWNV2"}:
        return ParseMode.MARKDOWN_V2
    raise ValueError("parse_mode must be one of: HTML, Markdown, MarkdownV2, or None")
```

Note: renamed from `_normalize_parse_mode` to `normalize_parse_mode` — it's now a public module-level function, not a private helper.

- [ ] **Step 3: Run ruff and mypy on new files**

Run: `cd "C:/Users/Home PC/Downloads/aiogram_mcp" && python -m ruff check aiogram_mcp/models.py aiogram_mcp/utils.py && python -m mypy aiogram_mcp/models.py aiogram_mcp/utils.py`
Expected: no errors

- [ ] **Step 4: Commit**

```bash
git add aiogram_mcp/models.py aiogram_mcp/utils.py
git commit -m "feat: add base ToolResponse model and shared utils"
```

### Task 2: Migrate messaging tools to Pydantic

**Files:**
- Modify: `aiogram_mcp/tools/messaging.py`

- [ ] **Step 1: Replace messaging.py with Pydantic models**

Remove `ToolResult = dict[str, Any]` and `_normalize_parse_mode`. Add result models. Change all return types and return statements.

```python
"""Messaging tools: send_message, send_photo, forward_message, delete_message, pin_message."""

from __future__ import annotations

from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import ReplyParameters
from fastmcp import FastMCP

from ..context import BotContext
from ..models import OkResult, ToolResponse
from ..utils import normalize_parse_mode


class SendMessageResult(ToolResponse):
    message_id: int | None = None
    chat_id: int | None = None
    date: str | None = None


class SendPhotoResult(ToolResponse):
    message_id: int | None = None
    chat_id: int | None = None


class ForwardMessageResult(ToolResponse):
    message_id: int | None = None


def register_messaging_tools(mcp: FastMCP, ctx: BotContext) -> None:
    @mcp.tool
    async def send_message(
        chat_id: int,
        text: str,
        parse_mode: str | None = "HTML",
        disable_notification: bool = False,
        reply_to_message_id: int | None = None,
    ) -> SendMessageResult:
        """Send a text message to a Telegram chat or user."""
        if not ctx.is_chat_allowed(chat_id):
            return SendMessageResult(
                ok=False,
                error=f"Chat {chat_id} is not in the allowed_chat_ids whitelist.",
            )

        try:
            msg = await ctx.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=normalize_parse_mode(parse_mode),
                disable_notification=disable_notification,
                reply_parameters=(
                    ReplyParameters(message_id=reply_to_message_id)
                    if reply_to_message_id is not None
                    else None
                ),
            )
            return SendMessageResult(
                ok=True,
                message_id=msg.message_id,
                chat_id=msg.chat.id,
                date=msg.date.isoformat(),
            )
        except ValueError as exc:
            return SendMessageResult(ok=False, error=str(exc))
        except TelegramForbiddenError:
            return SendMessageResult(
                ok=False, error="Bot was blocked by the user or lacks permission."
            )
        except TelegramBadRequest as exc:
            return SendMessageResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_photo(
        chat_id: int,
        photo_url: str,
        caption: str | None = None,
        parse_mode: str | None = "HTML",
        disable_notification: bool = False,
    ) -> SendPhotoResult:
        """Send a photo to a Telegram chat."""
        if not ctx.is_chat_allowed(chat_id):
            return SendPhotoResult(ok=False, error=f"Chat {chat_id} is not allowed.")

        try:
            msg = await ctx.bot.send_photo(
                chat_id=chat_id,
                photo=photo_url,
                caption=caption,
                parse_mode=normalize_parse_mode(parse_mode),
                disable_notification=disable_notification,
            )
            return SendPhotoResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except ValueError as exc:
            return SendPhotoResult(ok=False, error=str(exc))
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendPhotoResult(ok=False, error=str(exc))

    @mcp.tool
    async def forward_message(
        to_chat_id: int,
        from_chat_id: int,
        message_id: int,
        disable_notification: bool = False,
    ) -> ForwardMessageResult:
        """Forward an existing message from one chat to another."""
        if not ctx.is_chat_allowed(to_chat_id):
            return ForwardMessageResult(
                ok=False, error=f"Chat {to_chat_id} is not allowed."
            )

        try:
            msg = await ctx.bot.forward_message(
                chat_id=to_chat_id,
                from_chat_id=from_chat_id,
                message_id=message_id,
                disable_notification=disable_notification,
            )
            return ForwardMessageResult(ok=True, message_id=msg.message_id)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return ForwardMessageResult(ok=False, error=str(exc))

    @mcp.tool
    async def delete_message(chat_id: int, message_id: int) -> OkResult:
        """Delete a message from a chat."""
        if not ctx.is_chat_allowed(chat_id):
            return OkResult(ok=False, error=f"Chat {chat_id} is not allowed.")

        try:
            await ctx.bot.delete_message(chat_id=chat_id, message_id=message_id)
            return OkResult(ok=True)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return OkResult(ok=False, error=str(exc))

    @mcp.tool
    async def pin_message(
        chat_id: int,
        message_id: int,
        disable_notification: bool = False,
    ) -> OkResult:
        """Pin a message in a chat."""
        if not ctx.is_chat_allowed(chat_id):
            return OkResult(ok=False, error=f"Chat {chat_id} is not allowed.")

        try:
            await ctx.bot.pin_chat_message(
                chat_id=chat_id,
                message_id=message_id,
                disable_notification=disable_notification,
            )
            return OkResult(ok=True)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return OkResult(ok=False, error=str(exc))
```

- [ ] **Step 2: Run ruff + mypy on messaging.py**

Run: `python -m ruff check aiogram_mcp/tools/messaging.py && python -m mypy aiogram_mcp/tools/messaging.py`
Expected: no errors

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/tools/messaging.py
git commit -m "refactor: migrate messaging tools to Pydantic result models"
```

### Task 3: Migrate users tools to Pydantic

**Files:**
- Modify: `aiogram_mcp/tools/users.py`

- [ ] **Step 1: Replace users.py with Pydantic models**

```python
"""User inspection tools."""

from __future__ import annotations

from typing import Any

from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from fastmcp import FastMCP

from ..context import BotContext
from ..models import ToolResponse


class BotInfoResult(ToolResponse):
    id: int | None = None
    username: str | None = None
    first_name: str | None = None
    is_bot: bool | None = None
    can_join_groups: bool | None = None
    can_read_all_group_messages: bool | None = None
    supports_inline_queries: bool | None = None


class ChatMemberInfoResult(ToolResponse):
    chat_id: int | None = None
    user_id: int | None = None
    status: str | None = None
    username: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    language_code: str | None = None
    is_bot: bool | None = None


class UserProfilePhotosResult(ToolResponse):
    user_id: int | None = None
    total_count: int | None = None
    photos: list[list[dict[str, Any]]] | None = None


def register_user_tools(mcp: FastMCP, ctx: BotContext) -> None:
    @mcp.tool
    async def get_bot_info() -> BotInfoResult:
        """Return metadata about the current Telegram bot."""
        me = await ctx.bot.get_me()
        return BotInfoResult(
            ok=True,
            id=me.id,
            username=me.username,
            first_name=me.first_name,
            is_bot=me.is_bot,
            can_join_groups=me.can_join_groups,
            can_read_all_group_messages=me.can_read_all_group_messages,
            supports_inline_queries=me.supports_inline_queries,
        )

    @mcp.tool
    async def get_chat_member_info(chat_id: int, user_id: int) -> ChatMemberInfoResult:
        """Return role and user info for a chat member."""
        if not ctx.is_chat_allowed(chat_id):
            return ChatMemberInfoResult(
                ok=False, error=f"Chat {chat_id} is not allowed."
            )

        try:
            member = await ctx.bot.get_chat_member(chat_id=chat_id, user_id=user_id)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return ChatMemberInfoResult(ok=False, error=str(exc))

        user = member.user
        status = member.status.value if hasattr(member.status, "value") else str(member.status)
        return ChatMemberInfoResult(
            ok=True,
            chat_id=chat_id,
            user_id=user.id,
            status=status,
            username=user.username,
            first_name=user.first_name,
            last_name=user.last_name,
            language_code=user.language_code,
            is_bot=user.is_bot,
        )

    @mcp.tool
    async def get_user_profile_photos(
        user_id: int, limit: int = 5
    ) -> UserProfilePhotosResult:
        """Return a lightweight list of Telegram profile photo file IDs."""
        if limit < 1 or limit > 100:
            return UserProfilePhotosResult(
                ok=False, error="limit must be between 1 and 100."
            )

        try:
            photos = await ctx.bot.get_user_profile_photos(user_id=user_id, limit=limit)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return UserProfilePhotosResult(ok=False, error=str(exc))

        return UserProfilePhotosResult(
            ok=True,
            user_id=user_id,
            total_count=photos.total_count,
            photos=[
                [
                    {
                        "file_id": size.file_id,
                        "file_unique_id": size.file_unique_id,
                        "width": size.width,
                        "height": size.height,
                        "file_size": size.file_size,
                    }
                    for size in group
                ]
                for group in photos.photos
            ],
        )
```

- [ ] **Step 2: Run ruff + mypy**

Run: `python -m ruff check aiogram_mcp/tools/users.py && python -m mypy aiogram_mcp/tools/users.py`

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/tools/users.py
git commit -m "refactor: migrate user tools to Pydantic result models"
```

### Task 4: Migrate chat tools to Pydantic

**Files:**
- Modify: `aiogram_mcp/tools/chats.py`

- [ ] **Step 1: Replace chats.py with Pydantic models**

```python
"""Chat tools for moderation and inspection."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from fastmcp import FastMCP

from ..context import BotContext
from ..models import OkResult, ToolResponse


class ChatInfoResult(ToolResponse):
    id: int | None = None
    type: str | None = None
    title: str | None = None
    username: str | None = None
    description: str | None = None
    member_count: int | None = None
    is_forum: bool | None = None


class ChatMembersCountResult(ToolResponse):
    count: int | None = None


class BanUserResult(ToolResponse):
    user_id: int | None = None
    permanent: bool | None = None
    until: str | None = None


class UnbanUserResult(ToolResponse):
    user_id: int | None = None


class SetChatTitleResult(ToolResponse):
    new_title: str | None = None


def register_chat_tools(mcp: FastMCP, ctx: BotContext) -> None:
    @mcp.tool
    async def get_chat_info(chat_id: int) -> ChatInfoResult:
        """Get details about a chat."""
        try:
            chat = await ctx.bot.get_chat(chat_id)
            member_count = None
            try:
                member_count = await ctx.bot.get_chat_member_count(chat_id=chat_id)
            except (TelegramBadRequest, TelegramForbiddenError):
                member_count = None

            return ChatInfoResult(
                ok=True,
                id=chat.id,
                type=getattr(chat.type, "value", str(chat.type)),
                title=getattr(chat, "title", None),
                username=getattr(chat, "username", None),
                description=getattr(chat, "description", None),
                member_count=member_count,
                is_forum=getattr(chat, "is_forum", False),
            )
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return ChatInfoResult(ok=False, error=str(exc))

    @mcp.tool
    async def get_chat_members_count(chat_id: int) -> ChatMembersCountResult:
        """Get the number of members in a chat."""
        try:
            count = await ctx.bot.get_chat_member_count(chat_id=chat_id)
            return ChatMembersCountResult(ok=True, count=count)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return ChatMembersCountResult(ok=False, error=str(exc))

    @mcp.tool
    async def ban_user(
        chat_id: int,
        user_id: int,
        ban_duration_hours: int | None = None,
        revoke_messages: bool = False,
    ) -> BanUserResult:
        """Ban a user from a chat."""
        if not ctx.is_chat_allowed(chat_id):
            return BanUserResult(ok=False, error=f"Chat {chat_id} is not allowed.")

        until_date = None
        if ban_duration_hours:
            until_date = datetime.now(timezone.utc) + timedelta(hours=ban_duration_hours)

        try:
            await ctx.bot.ban_chat_member(
                chat_id=chat_id,
                user_id=user_id,
                until_date=until_date,
                revoke_messages=revoke_messages,
            )
            return BanUserResult(
                ok=True,
                user_id=user_id,
                permanent=until_date is None,
                until=until_date.isoformat() if until_date else None,
            )
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return BanUserResult(ok=False, error=str(exc))

    @mcp.tool
    async def unban_user(
        chat_id: int,
        user_id: int,
        only_if_banned: bool = True,
    ) -> UnbanUserResult:
        """Unban a previously banned user."""
        if not ctx.is_chat_allowed(chat_id):
            return UnbanUserResult(ok=False, error=f"Chat {chat_id} is not allowed.")

        try:
            await ctx.bot.unban_chat_member(
                chat_id=chat_id,
                user_id=user_id,
                only_if_banned=only_if_banned,
            )
            return UnbanUserResult(ok=True, user_id=user_id)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return UnbanUserResult(ok=False, error=str(exc))

    @mcp.tool
    async def set_chat_title(chat_id: int, title: str) -> SetChatTitleResult:
        """Change the title of a group or channel."""
        if not ctx.is_chat_allowed(chat_id):
            return SetChatTitleResult(ok=False, error=f"Chat {chat_id} is not allowed.")

        try:
            await ctx.bot.set_chat_title(chat_id=chat_id, title=title)
            return SetChatTitleResult(ok=True, new_title=title)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SetChatTitleResult(ok=False, error=str(exc))

    @mcp.tool
    async def set_chat_description(chat_id: int, description: str) -> OkResult:
        """Change the description of a group or channel."""
        if not ctx.is_chat_allowed(chat_id):
            return OkResult(ok=False, error=f"Chat {chat_id} is not allowed.")

        try:
            await ctx.bot.set_chat_description(chat_id=chat_id, description=description)
            return OkResult(ok=True)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return OkResult(ok=False, error=str(exc))
```

- [ ] **Step 2: Run ruff + mypy**

Run: `python -m ruff check aiogram_mcp/tools/chats.py && python -m mypy aiogram_mcp/tools/chats.py`

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/tools/chats.py
git commit -m "refactor: migrate chat tools to Pydantic result models"
```

### Task 5: Migrate broadcast tools to Pydantic

**Files:**
- Modify: `aiogram_mcp/tools/broadcast.py`

- [ ] **Step 1: Replace broadcast.py with Pydantic models**

```python
"""Broadcast tool for bulk messaging."""

from __future__ import annotations

import asyncio
import logging

from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from fastmcp import FastMCP
from pydantic import BaseModel

from ..context import BotContext
from ..models import ToolResponse
from ..utils import normalize_parse_mode

logger = logging.getLogger(__name__)


class BroadcastRecipientResult(BaseModel):
    chat_id: int
    ok: bool
    error: str | None = None


class BroadcastResult(ToolResponse):
    dry_run: bool | None = None
    would_send_to: int | None = None
    recipients: list[int] | None = None
    message_preview: str | None = None
    note: str | None = None
    success_count: int | None = None
    failed_count: int | None = None
    results: list[BroadcastRecipientResult] | None = None


def register_broadcast_tools(
    mcp: FastMCP,
    ctx: BotContext,
    max_recipients: int = 100,
) -> None:
    @mcp.tool
    async def broadcast(
        chat_ids: list[int],
        text: str,
        parse_mode: str | None = "HTML",
        delay_seconds: float = 0.05,
        dry_run: bool = True,
    ) -> BroadcastResult:
        """Send a message to multiple users or chats."""
        if len(chat_ids) > max_recipients:
            return BroadcastResult(
                ok=False,
                error=(
                    f"Recipient count {len(chat_ids)} exceeds safety limit "
                    f"of {max_recipients}. Adjust max_broadcast_recipients in "
                    "AiogramMCP to increase this limit."
                ),
            )

        if ctx.allowed_chat_ids is not None:
            blocked = [chat_id for chat_id in chat_ids if not ctx.is_chat_allowed(chat_id)]
            if blocked:
                return BroadcastResult(
                    ok=False,
                    error=f"These chat IDs are not in allowed_chat_ids: {blocked}",
                )

        if dry_run:
            return BroadcastResult(
                ok=True,
                dry_run=True,
                would_send_to=len(chat_ids),
                recipients=chat_ids,
                message_preview=text[:200],
                note="Set dry_run=False to actually send.",
            )

        try:
            normalized_parse_mode = normalize_parse_mode(parse_mode)
        except ValueError as exc:
            return BroadcastResult(ok=False, error=str(exc))

        results: list[BroadcastRecipientResult] = []
        success = 0
        failed = 0

        for chat_id in chat_ids:
            try:
                await ctx.bot.send_message(
                    chat_id=chat_id,
                    text=text,
                    parse_mode=normalized_parse_mode,
                )
                results.append(BroadcastRecipientResult(chat_id=chat_id, ok=True))
                success += 1
            except TelegramForbiddenError:
                results.append(
                    BroadcastRecipientResult(chat_id=chat_id, ok=False, error="blocked")
                )
                failed += 1
            except TelegramBadRequest as exc:
                results.append(
                    BroadcastRecipientResult(chat_id=chat_id, ok=False, error=str(exc))
                )
                failed += 1

            await asyncio.sleep(delay_seconds)

        logger.info("Broadcast complete: %d success, %d failed", success, failed)

        return BroadcastResult(
            ok=True,
            dry_run=False,
            success_count=success,
            failed_count=failed,
            results=results,
        )
```

- [ ] **Step 2: Run ruff + mypy**

Run: `python -m ruff check aiogram_mcp/tools/broadcast.py && python -m mypy aiogram_mcp/tools/broadcast.py`

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/tools/broadcast.py
git commit -m "refactor: migrate broadcast tool to Pydantic result models"
```

### Task 6: Migrate event tools to Pydantic

**Files:**
- Modify: `aiogram_mcp/tools/events.py`

- [ ] **Step 1: Replace events.py with Pydantic models**

```python
"""Event subscription tools: subscribe_events, unsubscribe_events."""

from __future__ import annotations

from fastmcp import FastMCP

from ..context import BotContext
from ..models import ToolResponse


class SubscribeEventsResult(ToolResponse):
    subscription_id: str | None = None
    chat_ids: list[int] | None = None
    event_types: list[str] | None = None
    note: str | None = None


class UnsubscribeEventsResult(ToolResponse):
    subscription_id: str | None = None


def register_event_tools(mcp: FastMCP, ctx: BotContext) -> None:
    @mcp.tool
    async def subscribe_events(
        chat_ids: list[int] | None = None,
        event_types: list[str] | None = None,
    ) -> SubscribeEventsResult:
        """Subscribe to real-time Telegram events.

        Receive notifications when new events match your filters.
        Read the telegram://events/queue resource to get event data.

        Args:
            chat_ids: Only events from these chats (None = all allowed chats).
            event_types: Filter by type: "message", "command" (None = all).
        """
        if ctx.event_manager is None:
            return SubscribeEventsResult(
                ok=False,
                error="EventManager is not configured. Pass event_manager to AiogramMCP.",
            )

        if chat_ids is not None:
            for cid in chat_ids:
                if not ctx.is_chat_allowed(cid):
                    return SubscribeEventsResult(
                        ok=False,
                        error=f"Chat {cid} is not in allowed_chat_ids.",
                    )

        sub_id = ctx.event_manager.subscribe(
            chat_ids=chat_ids,
            event_types=event_types,
        )
        return SubscribeEventsResult(
            ok=True,
            subscription_id=sub_id,
            chat_ids=chat_ids,
            event_types=event_types,
            note="Read telegram://events/queue to get events.",
        )

    @mcp.tool
    async def unsubscribe_events(subscription_id: str) -> UnsubscribeEventsResult:
        """Unsubscribe from real-time Telegram events.

        Args:
            subscription_id: The subscription ID returned by subscribe_events.
        """
        if ctx.event_manager is None:
            return UnsubscribeEventsResult(
                ok=False,
                error="EventManager is not configured.",
            )

        removed = ctx.event_manager.unsubscribe(subscription_id)
        if removed:
            return UnsubscribeEventsResult(ok=True, subscription_id=subscription_id)
        return UnsubscribeEventsResult(
            ok=False,
            error=f"Subscription '{subscription_id}' not found.",
        )
```

- [ ] **Step 2: Run ruff + mypy**

Run: `python -m ruff check aiogram_mcp/tools/events.py && python -m mypy aiogram_mcp/tools/events.py`

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/tools/events.py
git commit -m "refactor: migrate event tools to Pydantic result models"
```

### Task 7: Migrate interactive tools to Pydantic

**Files:**
- Modify: `aiogram_mcp/tools/interactive.py`

- [ ] **Step 1: Replace interactive.py with Pydantic models**

Remove the duplicate `_normalize_parse_mode`. Add result models. Import from utils.

```python
"""Interactive message tools: inline keyboards, message editing, callback answers."""

from __future__ import annotations

from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from fastmcp import FastMCP

from ..context import BotContext
from ..models import ToolResponse
from ..utils import normalize_parse_mode


class SendInteractiveResult(ToolResponse):
    message_id: int | None = None
    chat_id: int | None = None
    date: str | None = None


class EditMessageResult(ToolResponse):
    message_id: int | None = None
    chat_id: int | None = None


class AnswerCallbackResult(ToolResponse):
    callback_query_id: str | None = None


def _build_keyboard(
    buttons: list[list[dict[str, str]]],
) -> InlineKeyboardMarkup | str:
    """Build InlineKeyboardMarkup from a list of button rows.

    Returns the markup on success, or an error string on validation failure.
    Each button dict must have 'text' and either 'callback_data' or 'url'.
    """
    rows: list[list[InlineKeyboardButton]] = []
    for row_idx, row in enumerate(buttons):
        built_row: list[InlineKeyboardButton] = []
        for btn_idx, btn in enumerate(row):
            if "text" not in btn:
                return f"Button [{row_idx}][{btn_idx}] is missing required 'text' field."
            if "callback_data" not in btn and "url" not in btn:
                return (
                    f"Button [{row_idx}][{btn_idx}] must have 'callback_data' or 'url'."
                )
            built_row.append(
                InlineKeyboardButton(
                    text=btn["text"],
                    callback_data=btn.get("callback_data"),
                    url=btn.get("url"),
                )
            )
        rows.append(built_row)
    return InlineKeyboardMarkup(inline_keyboard=rows)


def register_interactive_tools(mcp: FastMCP, ctx: BotContext) -> None:
    @mcp.tool
    async def send_interactive_message(
        chat_id: int,
        text: str,
        buttons: list[list[dict[str, str]]],
        parse_mode: str | None = "HTML",
        disable_notification: bool = False,
    ) -> SendInteractiveResult:
        """Send a message with inline keyboard buttons.

        Args:
            chat_id: Target chat ID.
            text: Message text.
            buttons: Rows of buttons. Each button: {"text": "Label", "callback_data": "value"}
                     or {"text": "Label", "url": "https://..."}.
            parse_mode: HTML, Markdown, MarkdownV2, or None.
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendInteractiveResult(
                ok=False,
                error=f"Chat {chat_id} is not in allowed_chat_ids.",
            )

        keyboard = _build_keyboard(buttons)
        if isinstance(keyboard, str):
            return SendInteractiveResult(ok=False, error=keyboard)

        try:
            msg = await ctx.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=normalize_parse_mode(parse_mode),
                reply_markup=keyboard,
                disable_notification=disable_notification,
            )
            return SendInteractiveResult(
                ok=True,
                message_id=msg.message_id,
                chat_id=msg.chat.id,
                date=msg.date.isoformat(),
            )
        except ValueError as exc:
            return SendInteractiveResult(ok=False, error=str(exc))
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendInteractiveResult(ok=False, error=str(exc))

    @mcp.tool
    async def edit_message(
        chat_id: int,
        message_id: int,
        text: str,
        buttons: list[list[dict[str, str]]] | None = None,
        parse_mode: str | None = "HTML",
    ) -> EditMessageResult:
        """Edit the text and/or inline keyboard of an existing message.

        Args:
            chat_id: Chat containing the message.
            message_id: ID of the message to edit.
            text: New message text.
            buttons: New inline keyboard (None to remove buttons).
            parse_mode: HTML, Markdown, MarkdownV2, or None.
        """
        if not ctx.is_chat_allowed(chat_id):
            return EditMessageResult(
                ok=False,
                error=f"Chat {chat_id} is not in allowed_chat_ids.",
            )

        reply_markup = None
        if buttons is not None:
            keyboard = _build_keyboard(buttons)
            if isinstance(keyboard, str):
                return EditMessageResult(ok=False, error=keyboard)
            reply_markup = keyboard

        try:
            result = await ctx.bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                parse_mode=normalize_parse_mode(parse_mode),
                reply_markup=reply_markup,
            )
            if isinstance(result, bool):
                return EditMessageResult(ok=True, message_id=message_id, chat_id=chat_id)
            return EditMessageResult(
                ok=True,
                message_id=result.message_id,
                chat_id=result.chat.id,
            )
        except ValueError as exc:
            return EditMessageResult(ok=False, error=str(exc))
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return EditMessageResult(ok=False, error=str(exc))

    @mcp.tool
    async def answer_callback_query(
        callback_query_id: str,
        text: str | None = None,
        show_alert: bool = False,
    ) -> AnswerCallbackResult:
        """Answer a callback query from an inline keyboard button press.

        Args:
            callback_query_id: ID of the callback query (from the event).
            text: Optional notification text shown to the user.
            show_alert: Show as alert popup instead of toast notification.
        """
        try:
            await ctx.bot.answer_callback_query(
                callback_query_id=callback_query_id,
                text=text,
                show_alert=show_alert,
            )
            return AnswerCallbackResult(ok=True, callback_query_id=callback_query_id)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return AnswerCallbackResult(ok=False, error=str(exc))
```

- [ ] **Step 2: Run ruff + mypy**

Run: `python -m ruff check aiogram_mcp/tools/interactive.py && python -m mypy aiogram_mcp/tools/interactive.py`

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/tools/interactive.py
git commit -m "refactor: migrate interactive tools to Pydantic result models"
```

---

## Chunk 2: Test Migration

### Task 8: Migrate all existing tests from dict to attribute access

**Files:**
- Modify: `tests/test_core.py`

This is a mechanical refactor. The pattern:
- `result["ok"]` → `result.ok`
- `result["message_id"]` → `result.message_id`
- `result["error"]` → `result.error`
- `"error" in result` → `result.error is not None`
- `"subscription_id" in result` → `result.subscription_id is not None`

Also update `_normalize_parse_mode` imports from `aiogram_mcp.tools.messaging` to `aiogram_mcp.utils` and rename to `normalize_parse_mode`.

- [ ] **Step 1: Update _normalize_parse_mode test imports (lines 1185-1212)**

Change all 4 occurrences:
```python
# Before:
from aiogram_mcp.tools.messaging import _normalize_parse_mode
# After:
from aiogram_mcp.utils import normalize_parse_mode
```

And update function calls from `_normalize_parse_mode(...)` to `normalize_parse_mode(...)`.

- [ ] **Step 2: Migrate messaging tool test assertions**

Lines 348-535. Replace all `result["field"]` with `result.field`. Example:
```python
# Before:
result = await tools["send_message"].fn(chat_id=111, text="Hello test")
assert result["ok"] is True
assert result["message_id"] == 42

# After:
result = await tools["send_message"].fn(chat_id=111, text="Hello test")
assert result.ok is True
assert result.message_id == 42
```

Apply this pattern to ALL assertions in: `TestSendMessage`, `TestSendPhoto`, `TestForwardMessage`, `TestDeleteMessage`, `TestPinMessage`.

- [ ] **Step 3: Migrate user tool test assertions**

Lines 543-643. Same pattern for: `TestGetBotInfo`, `TestGetChatMemberInfo`, `TestGetUserProfilePhotos`.

Note: `result["photos"][0][0]["file_id"]` → `result.photos[0][0]["file_id"]` (photos is a list of list of dicts, inner dicts stay as dicts).

- [ ] **Step 4: Migrate chat tool test assertions**

Lines 650-857. Same pattern for: `TestGetChatInfo`, `TestGetChatMembersCount`, `TestBanUser`, `TestUnbanUser`, `TestSetChatTitle`, `TestSetChatDescription`.

- [ ] **Step 5: Migrate broadcast tool test assertions**

Lines 865-977. Same pattern for `TestBroadcast`.

Note: `result["results"]` → `result.results` but each item in results is now a `BroadcastRecipientResult` model, NOT a dict. So inner access like `result.results[0].ok` instead of `result["results"][0]["ok"]` (if any such assertions exist).

- [ ] **Step 6: Migrate event tool test assertions**

Lines 1693-1794. Same pattern for: `TestSubscribeEvents`, `TestUnsubscribeEvents`.

Note for `TestUnsubscribeEvents.test_unsubscribe_existing` (line 1766): `sub_result["subscription_id"]` → `sub_result.subscription_id`.

- [ ] **Step 7: Migrate interactive tool test assertions**

Lines 1935-2331. Same pattern for: `TestSendInteractiveMessage`, `TestEditMessage`, `TestAnswerCallbackQuery`, `TestAiogramMCPInteractive`.

- [ ] **Step 8: Run full test suite**

Run: `cd "C:/Users/Home PC/Downloads/aiogram_mcp" && python -m pytest tests/ -v`
Expected: all 150 tests pass

- [ ] **Step 9: Run ruff on test file**

Run: `python -m ruff check tests/test_core.py`
Expected: no errors

- [ ] **Step 10: Commit**

```bash
git add tests/test_core.py
git commit -m "refactor: migrate all test assertions from dict to Pydantic attribute access"
```

---

## Chunk 3: Rich Media Tools

### Task 9: Create media tools

**Files:**
- Create: `aiogram_mcp/tools/media.py`

- [ ] **Step 1: Create `aiogram_mcp/tools/media.py`**

```python
"""Rich media tools: document, voice, video, animation, audio, sticker, video_note, contact, location, poll."""

from __future__ import annotations

from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import InputPollOption
from fastmcp import FastMCP

from ..context import BotContext
from ..models import ToolResponse
from ..utils import normalize_parse_mode


class SendMediaResult(ToolResponse):
    message_id: int | None = None
    chat_id: int | None = None


class SendPollResult(ToolResponse):
    message_id: int | None = None
    chat_id: int | None = None
    poll_id: str | None = None


def register_media_tools(mcp: FastMCP, ctx: BotContext) -> None:
    @mcp.tool
    async def send_document(
        chat_id: int,
        document_url: str,
        caption: str | None = None,
        parse_mode: str | None = "HTML",
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send a document/file to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            document_url: URL or file_id of the document.
            caption: Optional caption.
            parse_mode: HTML, Markdown, MarkdownV2, or None.
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_document(
                chat_id=chat_id,
                document=document_url,
                caption=caption,
                parse_mode=normalize_parse_mode(parse_mode),
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except ValueError as exc:
            return SendMediaResult(ok=False, error=str(exc))
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_voice(
        chat_id: int,
        voice_url: str,
        caption: str | None = None,
        parse_mode: str | None = "HTML",
        duration: int | None = None,
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send a voice message to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            voice_url: URL or file_id of the voice message (OGG with OPUS).
            caption: Optional caption.
            parse_mode: HTML, Markdown, MarkdownV2, or None.
            duration: Duration in seconds.
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_voice(
                chat_id=chat_id,
                voice=voice_url,
                caption=caption,
                parse_mode=normalize_parse_mode(parse_mode),
                duration=duration,
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except ValueError as exc:
            return SendMediaResult(ok=False, error=str(exc))
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_video(
        chat_id: int,
        video_url: str,
        caption: str | None = None,
        parse_mode: str | None = "HTML",
        duration: int | None = None,
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send a video to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            video_url: URL or file_id of the video.
            caption: Optional caption.
            parse_mode: HTML, Markdown, MarkdownV2, or None.
            duration: Duration in seconds.
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_video(
                chat_id=chat_id,
                video=video_url,
                caption=caption,
                parse_mode=normalize_parse_mode(parse_mode),
                duration=duration,
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except ValueError as exc:
            return SendMediaResult(ok=False, error=str(exc))
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_animation(
        chat_id: int,
        animation_url: str,
        caption: str | None = None,
        parse_mode: str | None = "HTML",
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send a GIF/animation to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            animation_url: URL or file_id of the animation.
            caption: Optional caption.
            parse_mode: HTML, Markdown, MarkdownV2, or None.
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_animation(
                chat_id=chat_id,
                animation=animation_url,
                caption=caption,
                parse_mode=normalize_parse_mode(parse_mode),
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except ValueError as exc:
            return SendMediaResult(ok=False, error=str(exc))
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_audio(
        chat_id: int,
        audio_url: str,
        caption: str | None = None,
        parse_mode: str | None = "HTML",
        performer: str | None = None,
        title: str | None = None,
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send an audio file (music) to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            audio_url: URL or file_id of the audio (MP3/M4A).
            caption: Optional caption.
            parse_mode: HTML, Markdown, MarkdownV2, or None.
            performer: Performer name.
            title: Track title.
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_audio(
                chat_id=chat_id,
                audio=audio_url,
                caption=caption,
                parse_mode=normalize_parse_mode(parse_mode),
                performer=performer,
                title=title,
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except ValueError as exc:
            return SendMediaResult(ok=False, error=str(exc))
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_sticker(
        chat_id: int,
        sticker: str,
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send a sticker to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            sticker: File ID or URL of the sticker (WEBP/TGS/WEBM).
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_sticker(
                chat_id=chat_id,
                sticker=sticker,
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_video_note(
        chat_id: int,
        video_note_url: str,
        duration: int | None = None,
        length: int | None = None,
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send a video note (round video) to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            video_note_url: URL or file_id of the video note.
            duration: Duration in seconds.
            length: Video width and height (diameter of the circle).
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_video_note(
                chat_id=chat_id,
                video_note=video_note_url,
                duration=duration,
                length=length,
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_contact(
        chat_id: int,
        phone_number: str,
        first_name: str,
        last_name: str | None = None,
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send a phone contact to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            phone_number: Contact's phone number.
            first_name: Contact's first name.
            last_name: Contact's last name.
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_contact(
                chat_id=chat_id,
                phone_number=phone_number,
                first_name=first_name,
                last_name=last_name,
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_location(
        chat_id: int,
        latitude: float,
        longitude: float,
        disable_notification: bool = False,
    ) -> SendMediaResult:
        """Send a location to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendMediaResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            msg = await ctx.bot.send_location(
                chat_id=chat_id,
                latitude=latitude,
                longitude=longitude,
                disable_notification=disable_notification,
            )
            return SendMediaResult(ok=True, message_id=msg.message_id, chat_id=msg.chat.id)
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendMediaResult(ok=False, error=str(exc))

    @mcp.tool
    async def send_poll(
        chat_id: int,
        question: str,
        options: list[str],
        is_anonymous: bool = True,
        type: str = "regular",
        allows_multiple_answers: bool = False,
        disable_notification: bool = False,
    ) -> SendPollResult:
        """Send a poll to a Telegram chat.

        Args:
            chat_id: Target chat ID.
            question: Poll question (1-300 characters).
            options: List of answer options (2-10 strings).
            is_anonymous: Whether the poll is anonymous.
            type: "regular" or "quiz".
            allows_multiple_answers: Allow multiple answers (regular polls only).
            disable_notification: Send silently.
        """
        if not ctx.is_chat_allowed(chat_id):
            return SendPollResult(ok=False, error=f"Chat {chat_id} is not allowed.")
        try:
            poll_options = [InputPollOption(text=opt) for opt in options]
            msg = await ctx.bot.send_poll(
                chat_id=chat_id,
                question=question,
                options=poll_options,
                is_anonymous=is_anonymous,
                type=type,
                allows_multiple_answers=allows_multiple_answers,
                disable_notification=disable_notification,
            )
            return SendPollResult(
                ok=True,
                message_id=msg.message_id,
                chat_id=msg.chat.id,
                poll_id=msg.poll.id if msg.poll else None,
            )
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return SendPollResult(ok=False, error=str(exc))
```

- [ ] **Step 2: Run ruff + mypy**

Run: `python -m ruff check aiogram_mcp/tools/media.py && python -m mypy aiogram_mcp/tools/media.py`

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/tools/media.py
git commit -m "feat: add 10 rich media tools (document, voice, video, animation, audio, sticker, video_note, contact, location, poll)"
```

### Task 10: Register media tools in server.py

**Files:**
- Modify: `aiogram_mcp/server.py`

- [ ] **Step 1: Add import and registration**

Add to imports:
```python
from .tools.media import register_media_tools
```

Add to `_register_tools()`, after `register_interactive_tools`:
```python
register_media_tools(self._mcp, self._ctx)
```

- [ ] **Step 2: Run ruff + mypy**

Run: `python -m ruff check aiogram_mcp/server.py && python -m mypy aiogram_mcp/server.py`

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/server.py
git commit -m "feat: register media tools in AiogramMCP server"
```

### Task 11: Add mock_bot fixtures for media tools and write tests

**Files:**
- Modify: `tests/test_core.py`

- [ ] **Step 1: Add media mock methods to mock_bot fixture**

Add after existing mock methods (around line 115):
```python
    bot.send_document = AsyncMock(
        return_value=MagicMock(message_id=50, chat=MagicMock(id=111))
    )
    bot.send_voice = AsyncMock(
        return_value=MagicMock(message_id=51, chat=MagicMock(id=111))
    )
    bot.send_video = AsyncMock(
        return_value=MagicMock(message_id=52, chat=MagicMock(id=111))
    )
    bot.send_animation = AsyncMock(
        return_value=MagicMock(message_id=53, chat=MagicMock(id=111))
    )
    bot.send_audio = AsyncMock(
        return_value=MagicMock(message_id=54, chat=MagicMock(id=111))
    )
    bot.send_sticker = AsyncMock(
        return_value=MagicMock(message_id=55, chat=MagicMock(id=111))
    )
    bot.send_video_note = AsyncMock(
        return_value=MagicMock(message_id=56, chat=MagicMock(id=111))
    )
    bot.send_contact = AsyncMock(
        return_value=MagicMock(message_id=57, chat=MagicMock(id=111))
    )
    bot.send_location = AsyncMock(
        return_value=MagicMock(message_id=58, chat=MagicMock(id=111))
    )
    bot.send_poll = AsyncMock(
        return_value=MagicMock(
            message_id=59,
            chat=MagicMock(id=111),
            poll=MagicMock(id="poll_123"),
        )
    )
    bot.get_file = AsyncMock(
        return_value=MagicMock(
            file_id="file_abc",
            file_unique_id="unique_abc",
            file_size=125432,
            file_path="documents/file_42.pdf",
        )
    )
```

- [ ] **Step 2: Add media tools registration test**

```python
class TestAiogramMCPMedia:
    def test_media_tools_registered(self, mock_bot, mock_dp):
        mcp = AiogramMCP(bot=mock_bot, dp=mock_dp)
        tool_names = get_tool_names(mcp.fastmcp)
        expected_media = [
            "send_document", "send_voice", "send_video", "send_animation",
            "send_audio", "send_sticker", "send_video_note", "send_contact",
            "send_location", "send_poll",
        ]
        for name in expected_media:
            assert name in tool_names, f"Media tool '{name}' not registered"
```

- [ ] **Step 3: Add tests for each media tool (happy path + blocked + error)**

Write 3 tests per tool: success, blocked by allowlist, Telegram error. Example pattern for send_document (repeat for all 10):

```python
class TestSendDocument:
    @pytest.mark.asyncio
    async def test_send_document_success(self, mock_bot, mock_dp):
        from aiogram_mcp.tools.media import register_media_tools

        fast_mcp = _make_fast_mcp()
        tool_ctx = BotContext(bot=mock_bot, dp=mock_dp)
        register_media_tools(fast_mcp, tool_ctx)

        tools = await get_tool_map(fast_mcp)
        result = await tools["send_document"].fn(
            chat_id=111, document_url="https://example.com/file.pdf"
        )
        assert result.ok is True
        assert result.message_id == 50

    @pytest.mark.asyncio
    async def test_send_document_blocked(self, mock_bot, mock_dp):
        from aiogram_mcp.tools.media import register_media_tools

        fast_mcp = _make_fast_mcp()
        tool_ctx = BotContext(bot=mock_bot, dp=mock_dp, allowed_chat_ids=[111])
        register_media_tools(fast_mcp, tool_ctx)

        tools = await get_tool_map(fast_mcp)
        result = await tools["send_document"].fn(
            chat_id=999, document_url="https://example.com/file.pdf"
        )
        assert result.ok is False

    @pytest.mark.asyncio
    async def test_send_document_telegram_error(self, mock_bot, mock_dp):
        from aiogram_mcp.tools.media import register_media_tools

        mock_bot.send_document = AsyncMock(
            side_effect=TelegramBadRequest(method=MagicMock(), message="file too large")
        )
        fast_mcp = _make_fast_mcp()
        tool_ctx = BotContext(bot=mock_bot, dp=mock_dp)
        register_media_tools(fast_mcp, tool_ctx)

        tools = await get_tool_map(fast_mcp)
        result = await tools["send_document"].fn(
            chat_id=111, document_url="https://example.com/file.pdf"
        )
        assert result.ok is False
```

Repeat the same 3-test pattern for:
- `TestSendVoice` (voice_url="https://example.com/voice.ogg", message_id=51)
- `TestSendVideo` (video_url="https://example.com/video.mp4", message_id=52)
- `TestSendAnimation` (animation_url="https://example.com/anim.gif", message_id=53)
- `TestSendAudio` (audio_url="https://example.com/song.mp3", message_id=54)
- `TestSendSticker` (sticker="sticker_file_id", message_id=55)
- `TestSendVideoNote` (video_note_url="https://example.com/note.mp4", message_id=56)
- `TestSendContact` (phone_number="+1234567890", first_name="John", message_id=57)
- `TestSendLocation` (latitude=55.7558, longitude=37.6173, message_id=58)
- `TestSendPoll` (question="Favorite?", options=["A", "B", "C"], message_id=59, also assert poll_id="poll_123")

- [ ] **Step 4: Run full test suite**

Run: `python -m pytest tests/ -v`
Expected: all tests pass (~180+ tests)

- [ ] **Step 5: Run ruff on tests**

Run: `python -m ruff check tests/test_core.py`

- [ ] **Step 6: Commit**

```bash
git add tests/test_core.py
git commit -m "test: add tests for 10 media tools"
```

---

## Chunk 4: File Resource + Finalization

### Task 12: Add file metadata resource

**Files:**
- Modify: `aiogram_mcp/resources.py`

- [ ] **Step 1: Add file_info resource to register_resources()**

Add after the `events_queue` resource:

```python
    @mcp.resource("telegram://files/{file_id}")
    async def file_info(file_id: str) -> str:
        """Metadata for a Telegram file.

        Returns file_id, file_unique_id, file_size, and file_path.
        Use the file_path with the Telegram Bot API download endpoint to retrieve the file.
        """
        try:
            f = await ctx.bot.get_file(file_id)
            return json.dumps({
                "file_id": f.file_id,
                "file_unique_id": f.file_unique_id,
                "file_size": f.file_size,
                "file_path": f.file_path,
            })
        except (TelegramBadRequest, TelegramForbiddenError) as exc:
            return json.dumps({"ok": False, "error": str(exc)})
```

- [ ] **Step 2: Run ruff + mypy**

Run: `python -m ruff check aiogram_mcp/resources.py && python -m mypy aiogram_mcp/resources.py`

- [ ] **Step 3: Commit**

```bash
git add aiogram_mcp/resources.py
git commit -m "feat: add telegram://files/{file_id} metadata resource"
```

### Task 13: Add file resource tests

**Files:**
- Modify: `tests/test_core.py`

- [ ] **Step 1: Add file resource tests**

```python
class TestResourceFileInfo:
    @pytest.mark.asyncio
    async def test_file_info_resource_template(self, mock_bot, mock_dp):
        from aiogram_mcp.resources import register_resources

        fast_mcp = _make_fast_mcp()
        tool_ctx = BotContext(bot=mock_bot, dp=mock_dp)
        register_resources(fast_mcp, tool_ctx)

        templates = await fast_mcp.list_resource_templates()
        uris = [str(t.uri_template) for t in templates]
        assert any("file_id" in u for u in uris)

    @pytest.mark.asyncio
    async def test_file_info_success(self, mock_bot, mock_dp):
        import json

        from aiogram_mcp.resources import register_resources

        fast_mcp = _make_fast_mcp()
        tool_ctx = BotContext(bot=mock_bot, dp=mock_dp)
        register_resources(fast_mcp, tool_ctx)

        result = await fast_mcp.read_resource("telegram://files/file_abc")
        data = json.loads(result.contents[0].content)
        assert data["file_id"] == "file_abc"
        assert data["file_unique_id"] == "unique_abc"
        assert data["file_size"] == 125432
        assert data["file_path"] == "documents/file_42.pdf"

    @pytest.mark.asyncio
    async def test_file_info_invalid_id(self, mock_bot, mock_dp):
        import json

        from aiogram_mcp.resources import register_resources

        mock_bot.get_file = AsyncMock(
            side_effect=TelegramBadRequest(method=MagicMock(), message="invalid file_id")
        )
        fast_mcp = _make_fast_mcp()
        tool_ctx = BotContext(bot=mock_bot, dp=mock_dp)
        register_resources(fast_mcp, tool_ctx)

        result = await fast_mcp.read_resource("telegram://files/invalid")
        data = json.loads(result.contents[0].content)
        assert data["ok"] is False
```

- [ ] **Step 2: Run tests**

Run: `python -m pytest tests/ -v`
Expected: all tests pass

- [ ] **Step 3: Commit**

```bash
git add tests/test_core.py
git commit -m "test: add file resource tests"
```

### Task 14: Version bump and CHANGELOG

**Files:**
- Modify: `pyproject.toml`
- Modify: `aiogram_mcp/__init__.py`
- Modify: `CHANGELOG.md`

- [ ] **Step 1: Bump version in pyproject.toml**

Change `version = "0.5.0"` → `version = "0.6.0"`

- [ ] **Step 2: Bump fallback version in __init__.py**

Change `__version__ = "0.5.0"` → `__version__ = "0.6.0"`

- [ ] **Step 3: Add CHANGELOG entry**

Prepend to CHANGELOG.md (after header):

```markdown
## [0.6.0] — 2026-03-12

### Added
- Pydantic result models with `outputSchema` for all 21 existing tools — AI clients can parse responses programmatically via `structuredContent`
- 10 rich media tools: `send_document`, `send_voice`, `send_video`, `send_animation`, `send_audio`, `send_sticker`, `send_video_note`, `send_contact`, `send_location`, `send_poll`
- File metadata resource `telegram://files/{file_id}` — retrieve file info without downloading
- Base `ToolResponse` and `OkResult` models in `aiogram_mcp/models.py`
- Shared `normalize_parse_mode` utility in `aiogram_mcp/utils.py`

### Changed
- All tool return types changed from `dict[str, Any]` to typed Pydantic models
- `_normalize_parse_mode` moved from `tools/messaging.py` to `aiogram_mcp/utils.py` and renamed to `normalize_parse_mode`

### Removed
- `ToolResult` type alias removed from all tool modules
```

- [ ] **Step 4: Verify fastmcp version supports outputSchema**

Run: `python -c "import fastmcp; print(fastmcp.__version__)"` — check that installed version is >=2.0.
FastMCP auto-generates `outputSchema` from Pydantic return type hints. If testing shows outputSchema is not generated, bump the minimum in pyproject.toml.

- [ ] **Step 5: Run full test suite + linting**

Run: `python -m pytest tests/ -v && python -m ruff check aiogram_mcp tests examples && python -m mypy aiogram_mcp`
Expected: all pass

- [ ] **Step 6: Commit**

```bash
git add pyproject.toml aiogram_mcp/__init__.py CHANGELOG.md
git commit -m "release: bump version to 0.6.0"
```

### Task 15: Update plan.md (local only)

**Files:**
- Modify: `plan.md`

- [ ] **Step 1: Mark Phase 5 as completed**

Change `## Phase 5 — Structured Output & Rich Media (важно)` to `## Phase 5 — Structured Output & Rich Media (важно) ✅ ЗАВЕРШЕНО (v0.6.0)`

Add completion note:
```
**Реализовано**: `aiogram_mcp/models.py` (ToolResponse, OkResult), `aiogram_mcp/utils.py` (normalize_parse_mode),
Pydantic result models для всех 21 tools, `aiogram_mcp/tools/media.py` (10 media tools),
`telegram://files/{file_id}` resource. ~190 тестов, опубликовано v0.6.0.
```

**DO NOT commit this file.** plan.md is local-only.
