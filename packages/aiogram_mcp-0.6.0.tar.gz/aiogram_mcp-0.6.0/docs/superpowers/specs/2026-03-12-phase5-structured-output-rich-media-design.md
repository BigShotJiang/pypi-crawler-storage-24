# Phase 5 — Structured Output & Rich Media (v0.6.0)

## Summary

Add Pydantic-based output schemas to all tools, introduce rich media tools covering the full Telegram media API, and add a file metadata resource. Single release as v0.6.0.

## 1. Pydantic Result Models for All Tools

### Base model

New file `aiogram_mcp/models.py`:

```python
from pydantic import BaseModel

class ToolResponse(BaseModel):
    ok: bool
    error: str | None = None

class OkResult(ToolResponse):
    pass
```

All tool result models inherit from `ToolResponse`. `OkResult` is reused by tools that return only ok/error (delete_message, pin_message, set_chat_title, set_chat_description, unban_user).

### Shared utility: `_normalize_parse_mode`

Move `_normalize_parse_mode` from `tools/messaging.py` to a new `aiogram_mcp/utils.py`. Currently duplicated in `messaging.py` and `interactive.py`. All consumers (messaging, interactive, broadcast, media) import from `aiogram_mcp.utils`. This also requires updating `broadcast.py` (currently imports from `messaging.py`) and 4 test imports in `tests/test_core.py`.

### Cleanup

Remove the `ToolResult = dict[str, Any]` type alias from all tool modules (`messaging.py`, `users.py`, `chats.py`, `broadcast.py`, `events.py`, `interactive.py`).

### Per-module models

Each tool module defines its result models alongside the tool functions. Models use `ok: bool` as a discriminator — optional fields hold success data, `error` holds failure reason.

Example pattern:

```python
# tools/messaging.py
from ..models import ToolResponse

class SendMessageResult(ToolResponse):
    message_id: int | None = None
    chat_id: int | None = None
    date: str | None = None

@mcp.tool
async def send_message(...) -> SendMessageResult:
    ...
    return SendMessageResult(ok=True, message_id=msg.message_id, ...)
```

FastMCP auto-generates `outputSchema` from the return type hint and returns `structuredContent` to MCP clients.

### Field-level model definitions

**tools/messaging.py:**

| Model | Fields (beyond ok/error) |
|-------|-------------------------|
| `SendMessageResult` | `message_id: int?`, `chat_id: int?`, `date: str?` |
| `SendPhotoResult` | `message_id: int?`, `chat_id: int?` |
| `ForwardMessageResult` | `message_id: int?` |

`delete_message`, `pin_message` → use `OkResult` from models.py.

**tools/users.py:**

| Model | Fields (beyond ok/error) |
|-------|-------------------------|
| `BotInfoResult` | `id: int?`, `username: str?`, `first_name: str?`, `is_bot: bool?`, `can_join_groups: bool?`, `can_read_all_group_messages: bool?`, `supports_inline_queries: bool?` |
| `ChatMemberInfoResult` | `chat_id: int?`, `user_id: int?`, `status: str?`, `username: str?`, `first_name: str?`, `last_name: str?`, `language_code: str?`, `is_bot: bool?` |
| `UserProfilePhotosResult` | `user_id: int?`, `total_count: int?`, `photos: list[list[dict]]?` |

**tools/chats.py:**

| Model | Fields (beyond ok/error) |
|-------|-------------------------|
| `ChatInfoResult` | `id: int?`, `type: str?`, `title: str?`, `username: str?`, `description: str?`, `member_count: int?`, `is_forum: bool?` |
| `ChatMembersCountResult` | `count: int?` |
| `BanUserResult` | `user_id: int?`, `permanent: bool?`, `until: str?` |

`unban_user` → `OkResult` with optional `user_id`? No — current code returns `{"ok": True, "user_id": user_id}`, so:

| Model | Fields (beyond ok/error) |
|-------|-------------------------|
| `UnbanUserResult` | `user_id: int?` |

`set_chat_title` → use `OkResult` (currently returns `{"ok": True, "new_title": title}`, simplify to OkResult or keep):

| Model | Fields (beyond ok/error) |
|-------|-------------------------|
| `SetChatTitleResult` | `new_title: str?` |

`set_chat_description` → use `OkResult`.

**tools/broadcast.py:**

| Model | Fields (beyond ok/error) |
|-------|-------------------------|
| `BroadcastRecipientResult` | `chat_id: int`, `ok: bool`, `error: str?` |
| `BroadcastResult` | `dry_run: bool?`, `would_send_to: int?`, `recipients: list[int]?`, `message_preview: str?`, `note: str?`, `success_count: int?`, `failed_count: int?`, `results: list[BroadcastRecipientResult]?` |

Single model covers both dry_run=True and dry_run=False shapes — unused fields are None.

**tools/events.py:**

| Model | Fields (beyond ok/error) |
|-------|-------------------------|
| `SubscribeEventsResult` | `subscription_id: str?`, `chat_ids: list[int]?`, `event_types: list[str]?`, `note: str?` |
| `UnsubscribeEventsResult` | `subscription_id: str?` |

**tools/interactive.py:**

| Model | Fields (beyond ok/error) |
|-------|-------------------------|
| `SendInteractiveResult` | `message_id: int?`, `chat_id: int?`, `date: str?` |
| `EditMessageResult` | `message_id: int?`, `chat_id: int?` |
| `AnswerCallbackResult` | `callback_query_id: str?` |

### Module breakdown (summary)

| Module | Tools | Models |
|--------|-------|--------|
| `tools/messaging.py` | send_message, send_photo, forward_message, delete_message, pin_message | SendMessageResult, SendPhotoResult, ForwardMessageResult + OkResult |
| `tools/users.py` | get_bot_info, get_chat_member_info, get_user_profile_photos | BotInfoResult, ChatMemberInfoResult, UserProfilePhotosResult |
| `tools/chats.py` | get_chat_info, get_chat_members_count, ban_user, unban_user, set_chat_title, set_chat_description | ChatInfoResult, ChatMembersCountResult, BanUserResult, UnbanUserResult, SetChatTitleResult + OkResult |
| `tools/broadcast.py` | broadcast | BroadcastResult, BroadcastRecipientResult |
| `tools/events.py` | subscribe_events, unsubscribe_events | SubscribeEventsResult, UnsubscribeEventsResult |
| `tools/interactive.py` | send_interactive_message, edit_message, answer_callback_query | SendInteractiveResult, EditMessageResult, AnswerCallbackResult |

## 2. Rich Media Tools

New file `tools/media.py` with `register_media_tools(mcp, ctx)`.

### Tools

| Tool | Key Parameters | Description |
|------|---------------|-------------|
| `send_document` | chat_id, document_url, caption?, parse_mode?, disable_notification? | Files/documents |
| `send_voice` | chat_id, voice_url, caption?, duration?, disable_notification? | Voice messages |
| `send_video` | chat_id, video_url, caption?, parse_mode?, duration?, disable_notification? | Video |
| `send_animation` | chat_id, animation_url, caption?, parse_mode?, disable_notification? | GIF/animations |
| `send_audio` | chat_id, audio_url, caption?, parse_mode?, performer?, title?, disable_notification? | Audio/music |
| `send_sticker` | chat_id, sticker, disable_notification? | Stickers (file_id or URL) |
| `send_video_note` | chat_id, video_note_url, duration?, length?, disable_notification? | Video circles |
| `send_contact` | chat_id, phone_number, first_name, last_name?, disable_notification? | Contacts |
| `send_location` | chat_id, latitude, longitude, disable_notification? | Geolocation |
| `send_poll` | chat_id, question, options, is_anonymous?, type?, allows_multiple_answers? | Polls |

### Result models

All media send tools share `SendMediaResult(ToolResponse)` with fields `message_id: int?`, `chat_id: int?`. This covers document, voice, video, animation, audio, sticker, video_note, contact, and location — they all return the same shape.

`SendPollResult(ToolResponse)` has additional `poll_id: str?`.

### Implementation details

- All tools check `ctx.is_chat_allowed(chat_id)`.
- Tools with `parse_mode` import `_normalize_parse_mode` from `aiogram_mcp/utils.py`.
- All tools handle `TelegramBadRequest` / `TelegramForbiddenError`.
- `send_sticker` uses `sticker` (not `sticker_url`) because stickers are commonly sent by file_id.

### Note on send_photo

`send_photo` remains in `tools/messaging.py` — it was part of the original v0.1.0 API. Moving it would be a breaking change for no real benefit. The boundary is: messaging.py = text + photo (original tools), media.py = everything else (new tools).

## 3. File Download Resource

Added to `resources.py` inside `register_resources()`.

### URI

`telegram://files/{file_id}`

### Function signature

```python
async def file_info(file_id: str) -> str:
```

The `file_id` parameter is `str` — consistent with how FastMCP passes URI template parameters (same as `chat_id: str` in the existing chat_history resource).

### Response

```json
{
    "file_id": "BAADAgAD...",
    "file_unique_id": "AgAD...",
    "file_size": 125432,
    "file_path": "documents/file_42.pdf"
}
```

### Implementation

Calls `ctx.bot.get_file(file_id)`, extracts metadata. Handles `TelegramBadRequest` for invalid file_id.

## 4. Registration

`server.py` changes:
- Import and call `register_media_tools(mcp, ctx)` in `_register_tools()`.
- File resource registered inside existing `register_resources()` — no change needed in server.py for that.

## 5. Testing

### Test migration strategy

Switching from `dict` to Pydantic return types breaks all existing test assertions (`result["ok"]` → `result.ok`). Migration approach:

1. Create `aiogram_mcp/models.py` with `ToolResponse`, `OkResult`
2. Create `aiogram_mcp/utils.py` with `_normalize_parse_mode`
3. Update imports in `messaging.py`, `interactive.py`, `broadcast.py` to use `utils.py`
4. For each tool module: add result models, change return types, update return statements
5. Remove `ToolResult = dict[str, Any]` alias from all 6 tool modules
6. Update all `result["field"]` assertions to `result.field` in tests (~108 assertions)
7. Update `_normalize_parse_mode` test imports (4 tests in test_core.py)
8. Run full test suite

### New tests

- All 10 media tools: happy path + chat not allowed + Telegram errors (~30 tests)
- File resource: happy path + invalid file_id (~2 tests)
- Pydantic model validation tests (spot checks that models serialize correctly)

Expected total: ~190+ tests (150 migrated + ~40 new).

## 6. Versioning

- `pyproject.toml` + `__init__.py`: 0.5.0 → 0.6.0
- `CHANGELOG.md`: new v0.6.0 section
- Check minimum `fastmcp` version for outputSchema support — bump if needed

## Decisions Log

| Decision | Choice | Rationale |
|----------|--------|-----------|
| All 3 subsystems in one release | v0.6.0 | User preference |
| Structured output approach | Pydantic models | Type-safe, single source of truth, FastMCP native |
| Media tools scope | Full set (10 tools) | Maximum Telegram API coverage |
| File resource behavior | Metadata only | MCP resources not suited for large binary data |
| Model location | Alongside tools | Self-contained modules, small models |
| `_normalize_parse_mode` | Move to shared module | Was duplicated in messaging.py and interactive.py |
| `send_photo` stays in messaging.py | Legacy boundary | Moving would be breaking change for no benefit |
| `send_sticker` param name | `sticker` not `sticker_url` | Commonly sent by file_id, not URL |
| Single model per tool (not union) | ok field as success/failure indicator | Simpler schema, all fields optional on error path |
