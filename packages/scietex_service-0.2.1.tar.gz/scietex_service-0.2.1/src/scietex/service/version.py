"""Version of the `scietex.service` package"""

__version__ = "0.2.1"
