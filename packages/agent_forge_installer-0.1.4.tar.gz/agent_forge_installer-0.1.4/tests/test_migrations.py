"""Tests for the migrations framework."""

import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest


@pytest.fixture
def forge_root(tmp_path):
    """Create a minimal AgentForge root for testing."""
    (tmp_path / "data").mkdir()
    (tmp_path / "bot").mkdir()
    (tmp_path / "bot" / "config.json").write_text('{"telegram": {"allowed_chat_ids": [1]}, "claude": {"model": "sonnet"}}')
    return tmp_path


class TestVersionState:
    def test_read_missing_version_file(self, forge_root):
        from agentforge.migrations import read_version_state
        state = read_version_state(forge_root)
        assert state["installed_version"] == "0.0.0"
        assert state["applied_migrations"] == []

    def test_write_and_read_version_state(self, forge_root):
        from agentforge.migrations import read_version_state, write_version_state
        state = {"installed_version": "1.0.0", "applied_migrations": ["0001"], "last_update": "2025-01-01", "previous_version": None, "update_channel": "stable"}
        write_version_state(forge_root, state)
        loaded = read_version_state(forge_root)
        assert loaded["installed_version"] == "1.0.0"
        assert loaded["applied_migrations"] == ["0001"]

    def test_corrupted_version_file(self, forge_root):
        from agentforge.migrations import read_version_state
        vf = forge_root / "data" / "version.json"
        vf.write_text("not json{{{")
        state = read_version_state(forge_root)
        assert state["installed_version"] == "0.0.0"


class TestMigrationDiscovery:
    def test_discover_finds_0001(self):
        from agentforge.migrations import discover_migrations
        migrations = discover_migrations()
        assert len(migrations) >= 1
        ids = [m["id"] for m in migrations]
        assert "0001" in ids

    def test_migrations_sorted_by_id(self):
        from agentforge.migrations import discover_migrations
        migrations = discover_migrations()
        ids = [m["id"] for m in migrations]
        assert ids == sorted(ids)


class TestRunMigrations:
    def test_run_pending_migrations(self, forge_root):
        from agentforge.migrations import run_migrations, read_version_state
        applied = run_migrations(forge_root)
        assert "0001" in applied
        state = read_version_state(forge_root)
        assert "0001" in state["applied_migrations"]
        # Verify 0001 created the backups dir
        assert (forge_root / "data" / "backups").exists()

    def test_idempotent_run(self, forge_root):
        from agentforge.migrations import run_migrations
        run_migrations(forge_root)
        # Second run should find nothing pending
        applied = run_migrations(forge_root)
        assert applied == []

    def test_dry_run(self, forge_root):
        from agentforge.migrations import run_migrations, read_version_state
        applied = run_migrations(forge_root, dry_run=True)
        assert "0001" in applied
        # But state should NOT be updated
        state = read_version_state(forge_root)
        assert "0001" not in state.get("applied_migrations", [])


class TestRollbackMigration:
    def test_rollback_last(self, forge_root):
        from agentforge.migrations import run_migrations, rollback_last_migration, read_version_state
        run_migrations(forge_root)
        state = read_version_state(forge_root)
        assert "0001" in state["applied_migrations"]

        rolled_back = rollback_last_migration(forge_root)
        assert rolled_back == "0001"

        state = read_version_state(forge_root)
        assert "0001" not in state["applied_migrations"]

    def test_rollback_empty(self, forge_root):
        from agentforge.migrations import rollback_last_migration
        result = rollback_last_migration(forge_root)
        assert result is None


class TestUpdater:
    def test_check_update_handles_network_error(self):
        from agentforge.updater import check_update
        # Should not raise, just return error info
        with patch("urllib.request.urlopen", side_effect=Exception("no network")):
            result = check_update()
            assert result["error"] is not None
            assert result["update_available"] is False

    def test_parse_version(self):
        from agentforge.updater import _parse_version
        assert _parse_version("1.2.3") > _parse_version("1.2.2")
        assert _parse_version("0.2.0") > _parse_version("0.1.0")
        assert _parse_version("1.0.0") == _parse_version("1.0.0")
        assert _parse_version("2.0.0") > _parse_version("1.99.99")

    def test_post_update_healthcheck(self, forge_root):
        from agentforge.updater import _post_update_healthcheck
        result = _post_update_healthcheck(forge_root)
        assert result is True  # minimal setup should pass
