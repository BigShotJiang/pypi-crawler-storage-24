"""Tests for agentforge.cli.init."""

from __future__ import annotations
from types import SimpleNamespace

import pytest

from agentforge.cli import _run_init
from agentforge.cli.init import (
    ChatDetectionResult,
    ClaudeCliStatus,
    TelegramValidationResult,
    build_config,
    build_env_text,
    build_soul_text,
    check_claude_cli,
    detect_chat_id,
    forge_init,
    validate_telegram_token,
)


def test_validate_telegram_token_success():
    result = validate_telegram_token(
        "token",
        http_get_fn=lambda url, **kwargs: {
            "ok": True,
            "result": {"username": "agentforge_bot"},
        },
    )

    assert result.ok is True
    assert result.username == "agentforge_bot"


def test_validate_telegram_token_failure():
    result = validate_telegram_token(
        "bad-token",
        http_get_fn=lambda url, **kwargs: {
            "ok": False,
            "description": "Unauthorized",
        },
    )

    assert result.ok is False
    assert "Unauthorized" in result.error


def test_detect_chat_id_from_start_message():
    responses = iter([
        {
            "result": [
                {
                    "update_id": 42,
                    "message": {
                        "text": "/start",
                        "chat": {
                            "id": 123456,
                            "type": "private",
                            "username": "martin",
                        },
                    },
                }
            ]
        }
    ])

    result = detect_chat_id(
        "token",
        http_get_fn=lambda url, **kwargs: next(responses),
        poll_interval_seconds=0,
        printer=lambda msg: None,
        sleep_fn=lambda _: None,
    )

    assert result.chat_id == 123456
    assert result.chat_type == "private"


def test_check_claude_cli_missing(monkeypatch):
    monkeypatch.setattr("agentforge.cli.init.shutil.which", lambda name: None)

    result = check_claude_cli()

    assert result.installed is False
    assert result.authenticated is False


def test_check_claude_cli_authenticated(monkeypatch):
    monkeypatch.setattr("agentforge.cli.init.shutil.which", lambda name: "/usr/bin/claude")
    monkeypatch.setattr(
        "agentforge.cli.init.subprocess.run",
        lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout="ok", stderr=""),
    )

    result = check_claude_cli()

    assert result.installed is True
    assert result.authenticated is True


def test_build_outputs_from_wizard_answers(tmp_path):
    answers = SimpleNamespace(
        telegram_token="telegram-token",
        chat=ChatDetectionResult(chat_id=99, chat_type="private"),
        bot_name="Forgey",
        bot_personality="Helpful and sharp.",
        openai_api_key="openai-key",
        brave_api_key="brave-key",
    )

    config = build_config(tmp_path, answers)
    env_text = build_env_text(answers)
    soul_text = build_soul_text(answers)

    assert config["telegram"]["allowed_chat_ids"] == [99]
    assert config["telegram"]["private_chat_id"] == 99
    assert "AGENTFORGE_TELEGRAM_TOKEN=telegram-token" in env_text
    assert "OPENAI_API_KEY=openai-key" in env_text
    assert "# Soul: Forgey" in soul_text
    assert "Helpful and sharp." in soul_text


def test_forge_init_non_interactive_preserves_scaffold(tmp_path):
    forge_init(str(tmp_path), interactive=False)

    config_path = tmp_path / "bot" / "config.json"
    env_path = tmp_path / ".env"
    soul_path = tmp_path / "memory" / "soul.md"

    assert config_path.exists()
    assert env_path.exists()
    assert soul_path.exists()
    assert "AGENTFORGE_TELEGRAM_TOKEN=" in env_path.read_text()
    assert "Define your main agent's identity" in soul_path.read_text()


def test_forge_init_interactive_writes_validated_values(tmp_path, monkeypatch):
    prompts = iter(
        [
            "telegram-token",
            "Forgey",
            "Calm and direct.",
            "openai-key",
            "brave-key",
        ]
    )

    yes_no_answers = iter([True, True])

    monkeypatch.setattr("agentforge.cli.init.getpass", lambda prompt: next(prompts))
    monkeypatch.setattr("builtins.input", lambda prompt: next(prompts))
    monkeypatch.setattr(
        "agentforge.cli.init.validate_telegram_token",
        lambda token: TelegramValidationResult(ok=True, username="agentforge_bot"),
    )
    monkeypatch.setattr(
        "agentforge.cli.init.detect_chat_id",
        lambda token, printer=print: ChatDetectionResult(
            chat_id=77,
            chat_type="private",
            title="martin",
        ),
    )
    monkeypatch.setattr(
        "agentforge.cli.init.check_claude_cli",
        lambda: ClaudeCliStatus(
            installed=True,
            authenticated=True,
            message="Claude ready.",
        ),
    )
    monkeypatch.setattr(
        "agentforge.cli.init.prompt_yes_no",
        lambda label, default=True: next(yes_no_answers),
    )

    forge_init(str(tmp_path), interactive=True)

    env_text = (tmp_path / ".env").read_text()
    config = (tmp_path / "bot" / "config.json").read_text()
    soul_text = (tmp_path / "memory" / "soul.md").read_text()

    assert "AGENTFORGE_TELEGRAM_TOKEN=telegram-token" in env_text
    assert "OPENAI_API_KEY=openai-key" in env_text
    assert '"private_chat_id": 77' in config
    assert "# Soul: Forgey" in soul_text


def test_run_init_passes_non_interactive_flag(monkeypatch):
    captured = {}

    def fake_forge_init(target_dir, *, interactive):
        captured["target_dir"] = target_dir
        captured["interactive"] = interactive

    monkeypatch.setattr("agentforge.cli.init.forge_init", fake_forge_init)

    _run_init(SimpleNamespace(dir="/tmp/demo", non_interactive=True))

    assert captured == {"target_dir": "/tmp/demo", "interactive": False}
