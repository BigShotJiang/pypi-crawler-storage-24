from __future__ import annotations

import json
import os
import sqlite3

from fastapi.testclient import TestClient

from agentforge.api_server import create_app
from agentforge.conversation_store import ConversationStore


def _auth_headers() -> dict[str, str]:
    return {"Authorization": "Bearer secret-token"}


def _make_store(tmp_root) -> ConversationStore:
    return ConversationStore(str(tmp_root / "data" / "conversations.db"))


def _build_app(tmp_root, config_file, store: ConversationStore):
    os.environ["AGENTFORGE_API_KEY"] = "secret-token"

    def fake_invoke_claude(**kwargs):
        return f"reply:{kwargs['user_text']}"

    return create_app(config_path=config_file, store=store, invoke_claude_fn=fake_invoke_claude)


def test_health_requires_bearer_token(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/api/health")

    assert response.status_code == 401


def test_list_agents_and_channels(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    agents = client.get("/api/agents", headers=_auth_headers())
    channels = client.get("/api/channels", headers=_auth_headers())

    assert agents.status_code == 200
    assert [agent["id"] for agent in agents.json()["agents"]] == ["clawdia", "victor", "archie"]
    assert channels.status_code == 200
    assert any(channel["id"] == "11" for channel in channels.json()["channels"])
    assert any(channel["id"] == "16" for channel in channels.json()["channels"])


def test_get_messages_supports_before_cursor(tmp_root, config_file):
    store = _make_store(tmp_root)
    store.save_message(
        "api-channel-11",
        "user",
        "old",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        timestamp="2026-03-14 09:00:00",
    )
    store.save_message(
        "api-channel-11",
        "assistant",
        "newer",
        source="api",
        metadata={"channel": "11", "agent": "clawdia"},
        timestamp="2026-03-14 10:00:00",
    )
    store.save_message(
        "tg--100123456-t11",
        "assistant",
        "telegram",
        source="telegram",
        metadata={"channel": "11", "agent": "clawdia"},
        timestamp="2026-03-14 11:00:00",
    )
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.get(
        "/api/messages",
        headers=_auth_headers(),
        params={"channel": "11", "before": "2026-03-14 11:00:00", "limit": 10},
    )

    assert response.status_code == 200
    contents = [message["content"] for message in response.json()["messages"]]
    assert contents == ["newer", "old"]


def test_post_messages_persists_exchange(tmp_root, config_file):
    store = _make_store(tmp_root)
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    response = client.post(
        "/api/messages",
        headers=_auth_headers(),
        json={"channel": "11", "message": "hello api"},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["response"]["content"] == "reply:hello api"

    conn = sqlite3.connect(tmp_root / "data" / "conversations.db")
    rows = conn.execute(
        "SELECT role, content, source FROM conversations WHERE session_id = ? ORDER BY id",
        ("api-channel-11",),
    ).fetchall()
    conn.close()
    assert rows == [
        ("user", "hello api", "api"),
        ("assistant", "reply:hello api", "api"),
    ]


def test_websocket_receives_typing_and_message_events(tmp_root, config_file):
    store = _make_store(tmp_root)
    app = _build_app(tmp_root, config_file, store)
    client = TestClient(app)

    with client.websocket_connect("/api/ws?token=secret-token&channel=11") as websocket:
        connected = websocket.receive_json()
        assert connected["type"] == "connected"

        response = client.post(
            "/api/messages",
            headers=_auth_headers(),
            json={"channel": "11", "message": "ping"},
        )

        assert response.status_code == 200
        events = [websocket.receive_json() for _ in range(4)]

    event_types = [event["type"] for event in events]
    assert event_types == ["message_created", "typing", "typing", "message_created"]
    assert events[1]["active"] is True
    assert events[2]["active"] is False


# ---------------------------------------------------------------------------
# Vault endpoints
# ---------------------------------------------------------------------------


def test_vault_tree_empty_when_no_notes(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/tree", headers=_auth_headers())

    assert response.status_code == 200
    # Inbox folder exists but has no .md files — tree may list the folder or be empty
    tree = response.json()["tree"]
    assert isinstance(tree, list)


def test_vault_tree_lists_notes_and_folders(tmp_root, config_file):
    (tmp_root / "vault" / "Inbox" / "2026-03-17.md").write_text("# Hello")
    (tmp_root / "vault" / "Projects").mkdir()
    (tmp_root / "vault" / "Projects" / "agentforge.md").write_text("# AgentForge")
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/tree", headers=_auth_headers())

    assert response.status_code == 200
    tree = response.json()["tree"]
    names = [node["name"] for node in tree]
    assert "Inbox" in names
    assert "Projects" in names
    inbox = next(n for n in tree if n["name"] == "Inbox")
    assert inbox["type"] == "folder"
    assert any(c["name"] == "2026-03-17.md" for c in inbox["children"])


def test_vault_list_notes(tmp_root, config_file):
    (tmp_root / "vault" / "Inbox" / "today.md").write_text("hello")
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/notes", headers=_auth_headers())

    assert response.status_code == 200
    notes = response.json()["notes"]
    assert len(notes) == 1
    assert notes[0]["path"] == "Inbox/today.md"
    assert notes[0]["name"] == "today.md"
    assert "modified_at" in notes[0]
    assert "size_bytes" in notes[0]


def test_vault_get_note(tmp_root, config_file):
    (tmp_root / "vault" / "Inbox" / "note.md").write_text("# My Note\n\nContent here.")
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/notes/Inbox/note.md", headers=_auth_headers())

    assert response.status_code == 200
    payload = response.json()
    assert payload["path"] == "Inbox/note.md"
    assert payload["content"] == "# My Note\n\nContent here."


def test_vault_get_note_returns_404_for_missing(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/notes/Inbox/missing.md", headers=_auth_headers())

    assert response.status_code == 404


def test_vault_save_note_creates_and_updates(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.post(
        "/vault/notes/Inbox/2026-03-17.md",
        headers=_auth_headers(),
        json={"content": "# New note"},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["path"] == "Inbox/2026-03-17.md"
    assert "modified_at" in payload
    assert (tmp_root / "vault" / "Inbox" / "2026-03-17.md").read_text() == "# New note"


def test_vault_save_note_creates_intermediate_folders(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.post(
        "/vault/notes/Projects/agentforge/roadmap.md",
        headers=_auth_headers(),
        json={"content": "roadmap"},
    )

    assert response.status_code == 200
    assert (tmp_root / "vault" / "Projects" / "agentforge" / "roadmap.md").read_text() == "roadmap"


def test_vault_path_traversal_blocked(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    response = client.get("/vault/notes/../../../etc/passwd", headers=_auth_headers())

    assert response.status_code in (400, 404)


def test_vault_endpoints_require_auth(tmp_root, config_file):
    app = _build_app(tmp_root, config_file, _make_store(tmp_root))
    client = TestClient(app)

    assert client.get("/vault/tree").status_code == 401
    assert client.get("/vault/notes").status_code == 401
    assert client.get("/vault/notes/Inbox/x.md").status_code == 401
    assert client.post("/vault/notes/Inbox/x.md", json={"content": "x"}).status_code == 401
