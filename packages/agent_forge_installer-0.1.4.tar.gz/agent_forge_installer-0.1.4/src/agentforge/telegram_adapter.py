#!/usr/bin/env python3
"""AgentForge Telegram Adapter — polls Telegram, invokes Claude Code CLI.

This is the main bot process. It uses extracted modules for:
- HTTP: agentforge.http_client
- Routing: agentforge.message_router
- Claude invocation: agentforge.claude_runner
- Voice: agentforge.voice
"""

import json
import logging
import os
import queue
import random
import signal
import sqlite3
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from agentforge.http_client import http_get, http_post_json
from agentforge.message_router import (
    get_thread_config,
    get_project_topic_config,
    get_agent_thread_config,
    parse_mention,
    build_topic_context,
)
from agentforge.claude_runner import (
    invoke_claude,
    RateLimitError,
    ClaudeCodeLimitError,
)
from agentforge.conversation_store import ConversationStore
from agentforge.voice import transcribe_voice_note

MONTREAL = ZoneInfo("America/Montreal")

AGENTFORGE_ROOT = os.environ.get("AGENTFORGE_ROOT", "/home/clawdia")
CONFIG_PATH = Path(AGENTFORGE_ROOT) / "bot" / "config.json"
ENV_PATH = Path(AGENTFORGE_ROOT) / ".env"

WORKING_MESSAGES = [
    "⏳ Je travaille là-dessus, je te reviens…",
    "⏳ On it.",
    "⏳ Je m'en occupe.",
    "⏳ Laisse-moi regarder ça.",
    "⏳ En cours…",
    "⏳ Je creuse ça.",
    "⏳ Ça s'en vient.",
    "⏳ Working on it…",
    "⏳ Je cogite.",
    "⏳ Une seconde.",
    "⏳ Sur le coup.",
    "⏳ Let me check that.",
    "⏳ J'y travaille.",
    "⏳ En train de réfléchir…",
    "⏳ Donne-moi un moment.",
    "⏳ Je m'y mets.",
    "⏳ Hold on…",
    "⏳ Je fouille ça.",
    "⏳ Deux secondes.",
    "⏳ On the case.",
]

STARTUP_MESSAGES = [
    "✅ Je suis de retour.",
    "✅ Back online.",
    "✅ Me revoilà.",
    "✅ Rebooted and ready.",
    "✅ Je suis là, qu'est-ce que j'ai manqué ?",
    "✅ Redémarrage complété. Prête.",
    "✅ Back in business.",
    "✅ Online. Qu'est-ce qui se passe ?",
    "✅ Je reviens de nulle part, mais je suis là.",
    "✅ Restart réussi. À vos ordres.",
    "✅ Hello again.",
    "✅ C'est reparti.",
    "✅ J'ai survécu au redémarrage.",
    "✅ Ready when you are.",
    "✅ De retour sur mes pattes.",
    "✅ Relancée. On reprend ?",
    "✅ Je suis vivante.",
    "✅ Up and running.",
    "✅ Boop — je suis là.",
    "✅ Redémarrée avec succès. Bonjour !",
]

SYNC_TIMEOUT = 20  # seconds before sending async notification


class ClawdiaBot:
    def __init__(self):
        self.config = json.loads(CONFIG_PATH.read_text())
        self._load_env()
        self.token = os.environ.get(self.config["telegram"]["token_env_var"], "")
        if not self.token:
            logging.error(
                f"Telegram token not found in env var "
                f"{self.config['telegram']['token_env_var']}"
            )
            sys.exit(1)
        self.api_base = f"https://api.telegram.org/bot{self.token}"
        self._build_api_bases()
        self.offset = self._load_offset()
        self.db = self._init_db()
        self.db_lock = threading.Lock()
        self.agent_queues: dict[str, queue.Queue] = {}
        self.agent_workers: dict[str, threading.Thread] = {}
        self.running = True
        self._last_retry_check = 0.0
        signal.signal(signal.SIGTERM, self._shutdown)
        signal.signal(signal.SIGINT, self._shutdown)
        # Pre-start one worker per known agent
        self._ensure_agent_worker("clawdia")
        for tid, tcfg in self.config.get("threads", {}).items():
            if tid == "default":
                continue
            agent_name = tcfg.get("name", "clawdia") or "clawdia"
            self._ensure_agent_worker(agent_name)

    # ------------------------------------------------------------------
    # Initialization helpers
    # ------------------------------------------------------------------

    def _load_env(self):
        """Source .env file into environment."""
        if ENV_PATH.exists():
            for line in ENV_PATH.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ[key.strip()] = val.strip()

    def _build_api_bases(self):
        """Build per-thread and per-agent API base URLs for multi-bot tokens."""
        self.thread_api_bases: dict[str, str] = {}
        self.agent_api_bases: dict[str, str] = {}
        for tid, tcfg in self.config.get("threads", {}).items():
            if tid == "default":
                continue
            env_var = tcfg.get("token_env_var")
            if env_var:
                agent_token = os.environ.get(env_var, "")
                if agent_token:
                    self.thread_api_bases[tid] = f"https://api.telegram.org/bot{agent_token}"
                    name = tcfg.get("name")
                    if name:
                        self.agent_api_bases[name] = f"https://api.telegram.org/bot{agent_token}"

    def _load_offset(self) -> int:
        state_path = Path(AGENTFORGE_ROOT) / "data" / "state.json"
        if state_path.exists():
            state = json.loads(state_path.read_text())
            return state.get("telegram_offset", 0)
        return 0

    def _save_offset(self):
        state_path = Path(AGENTFORGE_ROOT) / "data" / "state.json"
        state = {}
        if state_path.exists():
            state = json.loads(state_path.read_text())
        state["telegram_offset"] = self.offset
        state_path.write_text(json.dumps(state, indent=2))

    def _init_db(self) -> sqlite3.Connection:
        db_path = self.config["memory"]["db_path"]
        self.store = ConversationStore(db_path)
        return self.store.connection

    # ------------------------------------------------------------------
    # Main polling loop
    # ------------------------------------------------------------------

    def poll(self):
        logging.info("AgentForge Telegram adapter started — polling...")
        self._notify_startup()
        while self.running:
            try:
                updates = self._get_updates()
                for update in updates:
                    self._handle_update(update)
                if time.time() - self._last_retry_check > 60:
                    self._process_pending_retries()
                    self._last_retry_check = time.time()
                self._process_agent_tasks()
            except KeyboardInterrupt:
                break
            except Exception as e:
                logging.error(f"Poll error: {e}", exc_info=True)
                time.sleep(5)
            time.sleep(self.config["telegram"]["poll_interval_seconds"])

    def _notify_startup(self):
        try:
            clawdia_thread = self.config["telegram"]["topics"]["clawdia"]
            group_chat_id = str(self.config["telegram"]["group_chat_id"])
            self._send_message(group_chat_id, random.choice(STARTUP_MESSAGES), clawdia_thread)
        except Exception as e:
            logging.warning(f"Startup notification failed: {e}")

    def _get_updates(self) -> list:
        try:
            data = http_get(
                f"{self.api_base}/getUpdates",
                params={
                    "offset": self.offset,
                    "timeout": 30,
                    "allowed_updates": json.dumps(["message"]),
                },
                timeout=35,
            )
            if not data.get("ok"):
                logging.error(f"Telegram API error: {data}")
                return []
            return data.get("result", [])
        except Exception as e:
            logging.error(f"Failed to get updates: {e}")
            return []

    # ------------------------------------------------------------------
    # Message handling
    # ------------------------------------------------------------------

    def _handle_update(self, update):
        self.offset = update["update_id"] + 1
        self._save_offset()

        msg = update.get("message")
        if not msg:
            return

        chat_id = str(msg["chat"]["id"])
        allowed = self.config["telegram"].get("allowed_chat_ids", [])
        if allowed and chat_id not in [str(c) for c in allowed]:
            logging.warning(f"Ignoring message from unauthorized chat {chat_id}")
            return

        if msg.get("from", {}).get("is_bot"):
            return

        message_id = str(msg["message_id"])
        thread_id = msg.get("message_thread_id")
        session_id = f"tg-{chat_id}-t{thread_id}" if thread_id else f"tg-{chat_id}"
        user_name = msg.get("from", {}).get("first_name", "User")
        thread_cfg = get_thread_config(thread_id, self.config)

        # Determine message content
        user_text = self._extract_message_text(msg, chat_id, thread_id)
        if user_text is None:
            return

        # Prepend reply context if replying to a message
        reply_to = msg.get("reply_to_message")
        if reply_to and reply_to.get("text"):
            user_text = f"[En réponse à : « {reply_to['text']} »]\n\n{user_text}"

        # Project topic routing
        project_cfg = get_project_topic_config(thread_id, self.config)
        if project_cfg:
            target_agent, user_text = parse_mention(user_text, project_cfg)
            thread_cfg = get_agent_thread_config(target_agent, self.config)
            thread_cfg["context_messages"] = 20
            thread_cfg["topic_context"] = build_topic_context(project_cfg, target_agent)

        logging.info(
            f"[{session_id}] thread={thread_id} model={thread_cfg.get('model')} "
            f"{user_name}: {user_text[:100]}"
        )

        self._save_message(session_id, "user", user_text, chat_id, message_id)
        self._enqueue_task({
            "session_id": session_id,
            "user_text": user_text,
            "thread_cfg": thread_cfg,
            "chat_id": chat_id,
            "thread_id": thread_id,
        })

    def _extract_message_text(self, msg, chat_id, thread_id) -> str | None:
        """Extract text content from a Telegram message. Returns None for unsupported types."""
        if msg.get("text"):
            return msg["text"]
        elif msg.get("voice"):
            text = transcribe_voice_note(msg["voice"], self.api_base, self.token)
            if text is None:
                self._send_message(
                    chat_id,
                    "🎤 Transcription non disponible ou audio incompréhensible.",
                    thread_id,
                )
                return None
            self._send_message(chat_id, f"🎤 _{text}_", thread_id)
            return text
        elif msg.get("photo"):
            self._send_message(chat_id, "📷 Je ne supporte pas encore les images.", thread_id)
            return None
        elif msg.get("document") or msg.get("video") or msg.get("sticker"):
            self._send_message(chat_id, "📎 Je ne supporte pas encore ce type de fichier.", thread_id)
            return None
        return None

    # ------------------------------------------------------------------
    # Worker queue system
    # ------------------------------------------------------------------

    def _ensure_agent_worker(self, agent_name: str):
        if agent_name not in self.agent_queues:
            q: queue.Queue = queue.Queue()
            self.agent_queues[agent_name] = q
            t = threading.Thread(target=self._worker, args=(agent_name, q), daemon=True)
            t.start()
            self.agent_workers[agent_name] = t
            logging.info(f"Started worker for agent: {agent_name}")

    def _enqueue_task(self, task: dict):
        agent_name = task.get("thread_cfg", {}).get("name", "clawdia") or "clawdia"
        self._ensure_agent_worker(agent_name)
        self.agent_queues[agent_name].put(task)
        logging.info(
            f"[{task.get('session_id', '?')}] Enqueued for agent={agent_name} "
            f"(queue size={self.agent_queues[agent_name].qsize()})"
        )

    def _worker(self, agent_name: str, task_queue: queue.Queue):
        logging.info(f"Worker thread started for agent: {agent_name}.")
        while True:
            try:
                task = task_queue.get()
            except Exception:
                continue
            if task is None:
                logging.info(f"Worker {agent_name} received shutdown sentinel — exiting.")
                task_queue.task_done()
                break

            session_id = task["session_id"]
            user_text = task["user_text"]
            thread_cfg = task["thread_cfg"]
            chat_id = task["chat_id"]
            thread_id = task["thread_id"]
            worker_agent = thread_cfg.get("name", "clawdia") or "clawdia"

            # Acknowledge inter-agent tasks with reaction
            if task.get("is_agent_task") and task.get("notify_message_id"):
                self._set_reaction(chat_id, task["notify_message_id"], "👀", thread_id, worker_agent)

            stop_typing = self._start_typing_loop(chat_id, thread_id, agent_name=worker_agent)

            # Run Claude in sub-thread with sync timeout
            result_holder = [None]
            error_holder = [None]
            done_event = threading.Event()

            def run_claude():
                try:
                    limit = thread_cfg.get("context_messages", self.config["memory"]["context_messages"])
                    recent = self._get_recent_messages(session_id, limit)
                    result_holder[0] = invoke_claude(
                        session_id=session_id,
                        user_text=user_text,
                        thread_cfg=thread_cfg,
                        config=self.config,
                        recent_messages=recent,
                        root=AGENTFORGE_ROOT,
                    )
                except Exception as e:
                    error_holder[0] = e
                finally:
                    done_event.set()

            claude_thread = threading.Thread(target=run_claude, daemon=True)
            claude_thread.start()
            responded_fast = done_event.wait(timeout=SYNC_TIMEOUT)

            if not responded_fast:
                stop_typing.set()
                if task.get("is_agent_task") and task.get("notify_message_id"):
                    self._set_reaction(chat_id, task["notify_message_id"], "⌛", thread_id, worker_agent)
                elif not task.get("is_agent_task"):
                    self._send_message(
                        chat_id, random.choice(WORKING_MESSAGES), thread_id, agent_name=worker_agent
                    )
                logging.info(f"[{session_id}] Async fallback after {SYNC_TIMEOUT}s")
                done_event.wait()
                stop_typing = threading.Event()

            stop_typing.set()

            # Handle result
            if error_holder[0] is not None:
                self._handle_worker_error(error_holder[0], task, chat_id, thread_id, worker_agent, task_queue)
                continue

            response = result_holder[0]
            self._save_message(session_id, "assistant", response, chat_id, None)
            self._send_message(chat_id, response, thread_id, agent_name=worker_agent)
            self._log_action(worker_agent, "telegram_send", "telegram", response[:100].replace("\n", " "))
            logging.info(f"[{session_id}] Worker sent: {response[:100]}")
            task_queue.task_done()

    def _handle_worker_error(self, error, task, chat_id, thread_id, agent_name, task_queue):
        """Handle errors from Claude invocation in worker."""
        if isinstance(error, ClaudeCodeLimitError):
            self._send_message(
                chat_id,
                "🚫 Limite Claude Code atteinte — je suis temporairement hors service. "
                "Martin doit reset la limite. Je reviendrai dès que c'est fait !",
                thread_id,
                agent_name=agent_name,
            )
        elif isinstance(error, RateLimitError):
            retry_attempt = task.get("_retry_attempt", 0)
            if retry_attempt >= 3:
                self._send_message(
                    chat_id,
                    "⚠️ Rate limit persistant après 3 tentatives. Réessaie manuellement.",
                    thread_id,
                    agent_name=agent_name,
                )
            else:
                self._save_pending_retry(task, error.retry_after_seconds)
                retry_time = (
                    datetime.now(MONTREAL) + timedelta(seconds=error.retry_after_seconds)
                ).strftime("%H:%M")
                self._send_message(
                    chat_id,
                    f"⏸ Rate limit Anthropic atteint. Je réessaierai vers {retry_time}.",
                    thread_id,
                    agent_name=agent_name,
                )
        else:
            self._send_message(
                chat_id,
                "Sorry, I encountered an error. Please try again.",
                thread_id,
                agent_name=agent_name,
            )
        task_queue.task_done()

    # ------------------------------------------------------------------
    # Telegram helpers
    # ------------------------------------------------------------------

    def _get_api_base(self, thread_id=None, agent_name=None) -> str:
        if agent_name and agent_name in self.agent_api_bases:
            return self.agent_api_bases[agent_name]
        if thread_id:
            return self.thread_api_bases.get(str(thread_id), self.api_base)
        return self.api_base

    def _send_typing(self, chat_id, thread_id=None, agent_name=None):
        try:
            payload = {"chat_id": chat_id, "action": "typing"}
            if thread_id:
                payload["message_thread_id"] = thread_id
            http_post_json(f"{self._get_api_base(thread_id, agent_name)}/sendChatAction", payload)
        except Exception:
            pass

    def _start_typing_loop(self, chat_id, thread_id, agent_name=None) -> threading.Event:
        stop_event = threading.Event()

        def loop():
            while not stop_event.wait(5):
                self._send_typing(chat_id, thread_id, agent_name)

        self._send_typing(chat_id, thread_id, agent_name)
        t = threading.Thread(target=loop, daemon=True)
        t.start()
        return stop_event

    def _send_message(self, chat_id, text, thread_id=None, agent_name=None):
        max_len = self.config["telegram"]["max_message_length"]
        chunks = [text[i : i + max_len] for i in range(0, len(text), max_len)]
        api_base = self._get_api_base(thread_id, agent_name)
        for chunk in chunks:
            try:
                payload = {"chat_id": chat_id, "text": chunk}
                if thread_id:
                    payload["message_thread_id"] = thread_id
                http_post_json(f"{api_base}/sendMessage", payload)
            except Exception as e:
                if api_base != self.api_base:
                    logging.warning(f"Agent token failed ({e}), falling back to main token")
                    try:
                        http_post_json(f"{self.api_base}/sendMessage", payload)
                    except Exception as e2:
                        logging.error(f"Failed to send message (fallback also failed): {e2}")
                else:
                    logging.error(f"Failed to send message: {e}")

    def _set_reaction(self, chat_id, message_id, emoji, thread_id=None, agent_name=None):
        try:
            api_base = self._get_api_base(thread_id, agent_name)
            http_post_json(f"{api_base}/setMessageReaction", {
                "chat_id": chat_id,
                "message_id": int(message_id),
                "reaction": [{"type": "emoji", "emoji": emoji}],
            })
        except Exception as e:
            logging.warning(f"Could not set reaction: {e}")

    # ------------------------------------------------------------------
    # Database operations
    # ------------------------------------------------------------------

    def _save_message(self, session_id, role, content, chat_id=None, message_id=None):
        self.store.save_message(
            session_id,
            role,
            content,
            source="telegram",
            telegram_chat_id=chat_id,
            telegram_message_id=message_id,
        )

    def _get_recent_messages(self, session_id, limit) -> list[tuple[str, str, str]]:
        return self.store.get_recent_messages(session_id, limit)

    # ------------------------------------------------------------------
    # Retry system
    # ------------------------------------------------------------------

    def _save_pending_retry(self, task, retry_after_seconds=3600):
        now = datetime.now(MONTREAL)
        retry_after = (now + timedelta(seconds=retry_after_seconds)).strftime("%Y-%m-%d %H:%M:%S")
        with self.db_lock:
            self.db.execute(
                """
                INSERT INTO pending_retries
                (session_id, user_text, thread_cfg, chat_id, thread_id, created_at, retry_after, attempts)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                """,
                (
                    task["session_id"],
                    task["user_text"],
                    json.dumps(task["thread_cfg"]),
                    task["chat_id"],
                    str(task["thread_id"]) if task["thread_id"] is not None else None,
                    now.strftime("%Y-%m-%d %H:%M:%S"),
                    retry_after,
                ),
            )
            self.db.commit()

    def _process_pending_retries(self):
        now = datetime.now(MONTREAL).strftime("%Y-%m-%d %H:%M:%S")
        with self.db_lock:
            cur = self.db.execute(
                """
                SELECT id, session_id, user_text, thread_cfg, chat_id, thread_id, attempts
                FROM pending_retries WHERE retry_after <= ?
                """,
                (now,),
            )
            rows = cur.fetchall()
        for row in rows:
            rid, session_id, user_text, thread_cfg_json, chat_id, thread_id, attempts = row
            thread_cfg = json.loads(thread_cfg_json)
            thread_id_val = int(thread_id) if thread_id else None
            with self.db_lock:
                self.db.execute("DELETE FROM pending_retries WHERE id = ?", (rid,))
                self.db.commit()
            logging.info(f"[{session_id}] Re-queuing rate-limited message (attempt {attempts + 1})")
            self._send_message(chat_id, "🔄 Rate limit expiré — je reprends ta question…", thread_id_val)
            self._enqueue_task({
                "session_id": session_id,
                "user_text": user_text,
                "thread_cfg": thread_cfg,
                "chat_id": chat_id,
                "thread_id": thread_id_val,
                "_retry_attempt": attempts,
            })

    # ------------------------------------------------------------------
    # Inter-agent tasks
    # ------------------------------------------------------------------

    def _process_agent_tasks(self):
        task_dir = Path(AGENTFORGE_ROOT) / "data" / "agent_tasks"
        if not task_dir.exists():
            return
        for task_file in sorted(task_dir.glob("*.json")):
            try:
                task_data = json.loads(task_file.read_text())
                target = task_data.get("target_agent", "")
                from_agent = task_data.get("from_agent", "system")
                message = task_data.get("message", "")
                thread_id = task_data.get("thread_id")
                if not target or not message or not thread_id:
                    logging.warning(f"Skipping malformed agent task file: {task_file}")
                    task_file.unlink(missing_ok=True)
                    continue
                task_file.unlink(missing_ok=True)
                chat_id = str(self.config["telegram"]["group_chat_id"])
                session_id = f"tg-{chat_id}-t{thread_id}"
                thread_cfg = get_thread_config(thread_id, self.config)
                user_text = f"[Message de {from_agent}]\n\n{message}"
                logging.info(f"[{session_id}] Agent task from {from_agent} → {target}: {message[:80]}")
                self._save_message(session_id, "user", user_text, chat_id, None)
                self._enqueue_task({
                    "session_id": session_id,
                    "user_text": user_text,
                    "thread_cfg": thread_cfg,
                    "chat_id": chat_id,
                    "thread_id": thread_id,
                    "is_agent_task": True,
                    "from_agent": from_agent,
                    "notify_message_id": task_data.get("notify_message_id"),
                })
            except Exception as e:
                logging.error(f"Failed to process agent task {task_file}: {e}")
                try:
                    task_file.unlink(missing_ok=True)
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def _log_action(self, agent, action_type, target, details=""):
        try:
            subprocess.Popen(
                [str(Path(AGENTFORGE_ROOT) / "bot" / "log_action.sh"), agent, action_type, target, details],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=AGENTFORGE_ROOT,
                env={
                    **os.environ,
                    "HOME": AGENTFORGE_ROOT,
                    "PATH": f"{AGENTFORGE_ROOT}/.local/bin:" + os.environ.get("PATH", "/usr/bin:/bin"),
                },
            )
        except Exception as e:
            logging.warning(f"log_action failed: {e}")

    def _shutdown(self, signum, frame):
        logging.info("Shutting down gracefully...")
        self.running = False


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(str(Path(AGENTFORGE_ROOT) / "logs" / "telegram.log")),
            logging.StreamHandler(),
        ],
    )
    bot = ClawdiaBot()
    bot.poll()
