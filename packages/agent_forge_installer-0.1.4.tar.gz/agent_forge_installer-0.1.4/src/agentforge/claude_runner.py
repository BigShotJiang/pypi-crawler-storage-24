"""Claude Code CLI invocation."""

from __future__ import annotations

import logging
import os
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

MONTREAL = ZoneInfo("America/Montreal")


class RateLimitError(Exception):
    def __init__(self, retry_after_seconds: int = 3600):
        self.retry_after_seconds = retry_after_seconds


class ClaudeCodeLimitError(Exception):
    """Claude Code subscription usage limit reached (weekly/session cap)."""
    pass


def invoke_claude(
    *,
    session_id: str,
    user_text: str,
    thread_cfg: dict,
    config: dict,
    recent_messages: list[tuple[str, str, str]],
    root: str,
) -> str:
    """
    Invoke Claude Code CLI and return the response text.

    Args:
        session_id: Conversation session identifier
        user_text: The user's message
        thread_cfg: Thread/agent config dict
        config: Full bot config
        recent_messages: List of (role, content, timestamp) tuples
        root: AGENTFORGE_ROOT path

    Returns:
        Response text from Claude

    Raises:
        RateLimitError: If Anthropic rate limit hit
        ClaudeCodeLimitError: If Claude Code subscription limit reached
    """
    model = thread_cfg.get("model", config["claude"]["model"])
    thread_name = thread_cfg.get("name", "")

    # Determine display name for this agent's history
    agent_display_name = (
        thread_name.capitalize()
        if thread_name and thread_name != "clawdia"
        else "Clawdia"
    )

    # Format conversation history
    history_lines = []
    for role, content, ts in recent_messages:
        prefix = "User" if role == "user" else agent_display_name
        history_lines.append(f"[{ts}] {prefix}: {content}")

    history_text = "\n".join(history_lines) if history_lines else "(No prior messages)"

    # Build the full prompt
    topic_context = thread_cfg.get("topic_context", "")
    topic_section = f"\n## Contexte du topic\n{topic_context}\n" if topic_context else ""
    prompt = f"""## Recent Conversation
{history_text}
{topic_section}
## Current Message
User: {user_text}

Respond to the user's current message. Be concise."""

    # Build claude command
    cfg = config["claude"]
    cmd = [
        str(Path(root) / ".local" / "bin" / "claude"),
        "-p",
        "--model", model,
        "--dangerously-skip-permissions",
        "--output-format", "text",
    ]

    # Override system prompt with the agent's soul file.
    # Clawdia's soul lives at memory/soul.md; all other agents use agents/<name>/soul.md.
    if thread_name:
        if thread_name == "clawdia":
            soul_path = Path(root) / "memory" / "soul.md"
        else:
            soul_path = Path(root) / "agents" / thread_name / "soul.md"
        if soul_path.exists():
            cmd += ["--system-prompt", soul_path.read_text().strip()]

    if cfg.get("max_budget_usd"):
        cmd += ["--max-budget-usd", str(cfg["max_budget_usd"])]

    cmd.append(prompt)

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=1800,  # 30 minutes
            cwd=root,
            env={
                **os.environ,
                "HOME": root,
                "PATH": f"{root}/.local/bin:" + os.environ.get("PATH", "/usr/bin:/bin"),
            },
        )
        if result.returncode != 0:
            stderr = (result.stderr or "").strip()
            stdout = (result.stdout or "").strip()
            combined = (stderr + " " + stdout).lower()
            logging.error(
                f"Claude error (rc={result.returncode}): "
                f"stderr={stderr[:300]} stdout={stdout[:300]}"
            )
            # Claude Code subscription/session usage limit
            claude_code_limit_signals = [
                "usage limit", "claude code limit", "subscription limit",
                "usage cap", "limit reached", "claude pro", "out of credits",
            ]
            if any(kw in combined for kw in claude_code_limit_signals):
                logging.warning("Claude Code usage limit detected")
                raise ClaudeCodeLimitError()
            # rc=1 with empty stderr/stdout = most likely Claude Code limit
            if result.returncode == 1 and not stderr and not stdout:
                logging.warning("Claude Code rc=1 with no output — treating as usage limit")
                raise ClaudeCodeLimitError()
            # Anthropic API rate limit
            rate_limit_signals = [
                "rate limit", "429", "quota exceeded", "overloaded", "too many requests",
            ]
            if any(kw in combined for kw in rate_limit_signals):
                logging.warning(f"Claude rate limited: {combined[:200]}")
                raise RateLimitError()
            return "Sorry, I encountered an error. Please try again."
        response = result.stdout.strip()
        if not response:
            return "I processed your message but had no output. Try rephrasing?"
        return response
    except subprocess.TimeoutExpired:
        logging.error("Claude timed out after 30 minutes")
        return (
            "Désolée, cette tâche a pris trop longtemps (>30 min). "
            "Essaie de la découper en étapes plus courtes."
        )
    except (RateLimitError, ClaudeCodeLimitError):
        raise
    except Exception as e:
        logging.error(f"Failed to invoke Claude: {e}", exc_info=True)
        return "Sorry, something went wrong. Please try again later."
