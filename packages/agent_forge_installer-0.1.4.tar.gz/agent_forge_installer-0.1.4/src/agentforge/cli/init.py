"""agentforge init — bootstrap a new AgentForge instance."""

from __future__ import annotations

import json
import shutil
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass
from getpass import getpass
from pathlib import Path

from agentforge.http_client import http_get

CONFIG_TEMPLATE = {
    "telegram": {
        "token_env_var": "AGENTFORGE_TELEGRAM_TOKEN",
        "allowed_chat_ids": [],
        "group_chat_id": 0,
        "private_chat_id": 0,
        "topics": {},
        "poll_interval_seconds": 1,
        "max_message_length": 4096,
    },
    "claude": {
        "model": "sonnet",
        "max_budget_usd": 1.0,
    },
    "memory": {
        "db_path": "",
        "context_messages": 10,
    },
    "heartbeat": {
        "interval_minutes": 60,
        "max_budget_usd": 0.1,
    },
    "logging": {
        "sheets_id": "",
    },
    "threads": {
        "default": {
            "model": "sonnet",
            "context_messages": 10,
        }
    },
    "project_topics": {},
}

DIRS = [
    "bot",
    "agents",
    "data",
    "logs",
    "memory",
    "memory/daily",
    "skills",
]

DEFAULT_SOUL_BODY = (
    "# Soul\n\n"
    "Define your main agent's identity and personality here.\n"
)


@dataclass
class TelegramValidationResult:
    ok: bool
    username: str = ""
    error: str = ""


@dataclass
class ChatDetectionResult:
    chat_id: int
    chat_type: str
    title: str = ""


@dataclass
class ClaudeCliStatus:
    installed: bool
    authenticated: bool
    message: str
    install_instructions: str = (
        "Install Claude Code CLI, then run `claude auth login` before starting AgentForge."
    )


@dataclass
class WizardAnswers:
    telegram_token: str
    chat: ChatDetectionResult
    bot_name: str
    bot_personality: str
    openai_api_key: str = ""
    brave_api_key: str = ""
    claude_status: ClaudeCliStatus | None = None


def validate_python_version() -> None:
    """Ensure the interpreter is new enough for AgentForge."""
    if sys.version_info < (3, 10):
        raise RuntimeError("AgentForge requires Python 3.10 or newer.")


def ensure_target_writable(root: Path) -> None:
    """Verify the target directory can be created and written to."""
    root.mkdir(parents=True, exist_ok=True)
    probe = root / ".agentforge-write-test"
    try:
        probe.write_text("ok", encoding="utf-8")
    finally:
        probe.unlink(missing_ok=True)


def validate_telegram_token(
    token: str,
    http_get_fn=None,
) -> TelegramValidationResult:
    """Validate a Telegram bot token via getMe."""
    http_get_fn = http_get if http_get_fn is None else http_get_fn
    token = token.strip()
    if not token:
        return TelegramValidationResult(ok=False, error="Telegram token cannot be empty.")

    try:
        payload = http_get_fn(f"https://api.telegram.org/bot{token}/getMe")
    except Exception as exc:  # pragma: no cover - network/backend specific
        return TelegramValidationResult(
            ok=False,
            error=f"Telegram validation request failed: {exc}",
        )

    if payload.get("ok") and payload.get("result", {}).get("username"):
        return TelegramValidationResult(
            ok=True,
            username=payload["result"]["username"],
        )

    description = payload.get("description", "Telegram rejected the provided token.")
    return TelegramValidationResult(ok=False, error=description)


def detect_chat_id(
    token: str,
    *,
    http_get_fn=None,
    timeout_seconds: int = 60,
    poll_interval_seconds: int = 2,
    printer=print,
    sleep_fn=time.sleep,
) -> ChatDetectionResult:
    """Poll Telegram updates until a /start message is observed."""
    http_get_fn = http_get if http_get_fn is None else http_get_fn
    api_base = f"https://api.telegram.org/bot{token}"
    deadline = time.time() + timeout_seconds
    offset = 0

    printer("Send `/start` to your bot now. Waiting for Telegram to report the chat...")

    while time.time() < deadline:
        payload = http_get_fn(
            f"{api_base}/getUpdates",
            params={"offset": offset, "timeout": min(poll_interval_seconds, 5)},
            timeout=max(poll_interval_seconds + 2, 5),
        )
        for update in payload.get("result", []):
            offset = max(offset, update.get("update_id", 0) + 1)
            message = update.get("message") or {}
            text = (message.get("text") or "").strip()
            chat = message.get("chat") or {}
            if text.startswith("/start") and chat.get("id") is not None:
                return ChatDetectionResult(
                    chat_id=int(chat["id"]),
                    chat_type=chat.get("type", "private"),
                    title=chat.get("title") or chat.get("username") or "",
                )
        sleep_fn(poll_interval_seconds)

    raise RuntimeError(
        "Timed out waiting for `/start`. Send the command to your bot and try again."
    )


def check_claude_cli() -> ClaudeCliStatus:
    """Check whether Claude Code CLI is installed and authenticated."""
    if shutil.which("claude") is None:
        return ClaudeCliStatus(
            installed=False,
            authenticated=False,
            message="Claude Code CLI was not found on PATH.",
        )

    try:
        result = subprocess.run(
            ["claude", "auth", "status"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        return ClaudeCliStatus(
            installed=False,
            authenticated=False,
            message=f"Unable to execute Claude Code CLI: {exc}",
        )

    combined = f"{result.stdout}\n{result.stderr}".strip().lower()
    if result.returncode == 0:
        return ClaudeCliStatus(
            installed=True,
            authenticated=True,
            message="Claude Code CLI is installed and authenticated.",
        )
    if "not logged" in combined or "not authenticated" in combined or "login" in combined:
        return ClaudeCliStatus(
            installed=True,
            authenticated=False,
            message="Claude Code CLI is installed but not authenticated.",
        )
    return ClaudeCliStatus(
        installed=True,
        authenticated=False,
        message=(
            "Claude Code CLI is installed, but authentication could not be confirmed. "
            "Run `claude auth status` manually to verify."
        ),
    )


def prompt_text(label: str, *, default: str | None = None, secret: bool = False) -> str:
    """Prompt for free-form text, optionally using a default or hidden input."""
    suffix = f" [{default}]" if default else ""
    prompt = f"{label}{suffix}: "

    while True:
        value = (getpass(prompt) if secret else input(prompt)).strip()
        if value:
            return value
        if default is not None:
            return default
        print("This field is required.")


def prompt_yes_no(label: str, *, default: bool = True) -> bool:
    """Prompt for a yes/no answer."""
    hint = "Y/n" if default else "y/N"
    while True:
        raw = input(f"{label} [{hint}]: ").strip().lower()
        if not raw:
            return default
        if raw in {"y", "yes"}:
            return True
        if raw in {"n", "no"}:
            return False
        print("Please answer yes or no.")


def build_config(root: Path, answers: WizardAnswers | None = None) -> dict:
    """Build the generated config.json payload."""
    config = json.loads(json.dumps(CONFIG_TEMPLATE))
    config["memory"]["db_path"] = str(root / "data" / "conversations.db")

    if answers is None:
        return config

    chat_id = answers.chat.chat_id
    chat_type = answers.chat.chat_type
    telegram = config["telegram"]
    telegram["allowed_chat_ids"] = [chat_id]
    telegram["private_chat_id"] = chat_id if chat_type == "private" else 0
    telegram["group_chat_id"] = chat_id if chat_type in {"group", "supergroup"} else 0
    if chat_type in {"group", "supergroup"}:
        telegram["topics"] = {"clawdia": 1}
    return config


def build_env_text(
    answers: WizardAnswers | None = None,
    *,
    include_secrets: bool = True,
) -> str:
    """Build the generated .env content."""
    lines = [
        "# AgentForge environment variables",
        "# Generated by `agentforge init`.",
        "",
        "# Telegram bot token (from @BotFather)",
        (
            f"AGENTFORGE_TELEGRAM_TOKEN={answers.telegram_token}"
            if answers and include_secrets
            else "AGENTFORGE_TELEGRAM_TOKEN="
        ),
        "",
        "# Optional: Claude API key (if not using Claude Code CLI)",
        "# ANTHROPIC_API_KEY=",
    ]

    if answers:
        lines.extend(
            [
                "",
                "# Optional provider API keys",
                (
                    f"OPENAI_API_KEY={answers.openai_api_key}"
                    if include_secrets
                    else "OPENAI_API_KEY="
                ),
                (
                    f"BRAVE_SEARCH_API_KEY={answers.brave_api_key}"
                    if include_secrets
                    else "BRAVE_SEARCH_API_KEY="
                ),
            ]
        )

    return "\n".join(lines) + "\n"


def build_soul_text(answers: WizardAnswers | None = None) -> str:
    """Build the generated soul.md content."""
    if answers is None:
        return DEFAULT_SOUL_BODY

    return (
        f"# Soul: {answers.bot_name}\n\n"
        "## Identity\n\n"
        f"- Name: {answers.bot_name}\n"
        "- Role: Primary AgentForge assistant\n\n"
        "## Personality\n\n"
        f"{answers.bot_personality}\n\n"
        "## Operating notes\n\n"
        "- Be concise, direct, and useful.\n"
        "- Use the configured Telegram chat as the primary operator channel.\n"
        "- Escalate clearly when a task needs human action.\n"
    )


def initialize_database(db_path: Path) -> None:
    """Initialize the SQLite storage used by AgentForge."""
    conn = sqlite3.connect(str(db_path))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            timestamp TEXT NOT NULL DEFAULT (datetime('now')),
            role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
            content TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'telegram',
            telegram_chat_id TEXT,
            telegram_message_id TEXT,
            metadata TEXT
        );
        CREATE TABLE IF NOT EXISTS pending_retries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            user_text TEXT NOT NULL,
            thread_cfg TEXT NOT NULL,
            chat_id TEXT NOT NULL,
            thread_id TEXT,
            created_at TEXT NOT NULL,
            retry_after TEXT NOT NULL,
            attempts INTEGER DEFAULT 0
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS conversations_fts USING fts5(
            content, content='conversations', content_rowid='id'
        );
        CREATE TRIGGER IF NOT EXISTS conversations_ai
            AFTER INSERT ON conversations BEGIN
            INSERT INTO conversations_fts(rowid, content)
                VALUES (new.id, new.content);
        END;
        CREATE TRIGGER IF NOT EXISTS conversations_ad
            AFTER DELETE ON conversations BEGIN
            INSERT INTO conversations_fts(conversations_fts, rowid, content)
                VALUES('delete', old.id, old.content);
        END;
    """)
    conn.commit()
    conn.close()


def scaffold_instance(
    root: Path,
    *,
    config: dict,
    env_text: str,
    env_example_text: str,
    soul_text: str,
    printer=print,
) -> None:
    """Create the AgentForge instance files on disk."""
    printer(f"Initializing AgentForge in {root}/\n")

    for relative_dir in DIRS:
        (root / relative_dir).mkdir(parents=True, exist_ok=True)
        printer(f"  created {relative_dir}/")

    config_path = root / "bot" / "config.json"
    if config_path.exists():
        printer(f"\n  skipped {config_path} (already exists)")
    else:
        config_path.write_text(
            json.dumps(config, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        printer("\n  wrote bot/config.json")

    env_example = root / ".env.example"
    if not env_example.exists():
        env_example.write_text(env_example_text, encoding="utf-8")
        printer("  wrote .env.example")

    env_path = root / ".env"
    if not env_path.exists():
        env_path.write_text(env_text, encoding="utf-8")
        printer("  wrote .env")
    else:
        printer("  skipped .env (already exists)")

    db_path = root / "data" / "conversations.db"
    if not db_path.exists():
        initialize_database(db_path)
        printer("  initialized data/conversations.db")
    else:
        printer("  skipped data/conversations.db (already exists)")

    state_path = root / "data" / "state.json"
    if not state_path.exists():
        state_path.write_text(json.dumps({"telegram_offset": 0}, indent=2) + "\n")
        printer("  wrote data/state.json")

    soul_path = root / "memory" / "soul.md"
    if not soul_path.exists():
        soul_path.write_text(soul_text, encoding="utf-8")
        printer("  wrote memory/soul.md")
    else:
        printer("  skipped memory/soul.md (already exists)")


def collect_wizard_answers(
    *,
    validate_token_fn=None,
    detect_chat_fn=None,
    check_claude_fn=None,
    printer=print,
) -> WizardAnswers:
    """Collect and validate interactive wizard answers."""
    validate_token_fn = validate_telegram_token if validate_token_fn is None else validate_token_fn
    detect_chat_fn = detect_chat_id if detect_chat_fn is None else detect_chat_fn
    check_claude_fn = check_claude_cli if check_claude_fn is None else check_claude_fn

    printer("Interactive setup wizard\n")

    while True:
        token = prompt_text("Telegram bot token", secret=True)
        token_result = validate_token_fn(token)
        if token_result.ok:
            printer(f"Telegram token validated for @{token_result.username}.")
            break
        printer(f"Validation failed: {token_result.error}")
        if not prompt_yes_no("Try a different Telegram token?", default=True):
            raise RuntimeError("Setup cancelled during Telegram bot validation.")

    while True:
        try:
            chat = detect_chat_fn(token, printer=printer)
            printer(f"Detected chat id {chat.chat_id} ({chat.chat_type}).")
            break
        except RuntimeError as exc:
            printer(str(exc))
            if not prompt_yes_no("Retry chat detection?", default=True):
                raise RuntimeError("Setup cancelled during chat ID detection.")

    claude_status = check_claude_fn()
    printer(claude_status.message)
    if not claude_status.installed:
        printer(claude_status.install_instructions)
        if not prompt_yes_no("Continue setup without Claude Code CLI?", default=False):
            raise RuntimeError("Setup cancelled until Claude Code CLI is installed.")
    elif not claude_status.authenticated:
        printer("Run `claude auth login` after setup if you want CLI-backed execution.")
        if not prompt_yes_no("Continue setup with a warning?", default=True):
            raise RuntimeError("Setup cancelled until Claude Code CLI authentication is fixed.")

    bot_name = prompt_text("Bot name", default="AgentForge")
    bot_personality = prompt_text(
        "Bot personality / tone",
        default="Direct, pragmatic, and reliable.",
    )

    openai_api_key = ""
    brave_api_key = ""
    if prompt_yes_no("Configure optional API keys now?", default=True):
        openai_api_key = prompt_text(
            "OpenAI API key",
            default="",
            secret=True,
        )
        brave_api_key = prompt_text(
            "Brave Search API key",
            default="",
            secret=True,
        )

    return WizardAnswers(
        telegram_token=token,
        chat=chat,
        bot_name=bot_name,
        bot_personality=bot_personality,
        openai_api_key=openai_api_key,
        brave_api_key=brave_api_key,
        claude_status=claude_status,
    )


def forge_init(target_dir: str = ".", *, interactive: bool = True) -> None:
    """Initialize a new AgentForge instance in target_dir."""
    validate_python_version()
    root = Path(target_dir).resolve()
    ensure_target_writable(root)

    answers = collect_wizard_answers() if interactive else None
    scaffold_instance(
        root,
        config=build_config(root, answers),
        env_text=build_env_text(answers),
        env_example_text=build_env_text(answers, include_secrets=False),
        soul_text=build_soul_text(answers),
    )

    print("\nAgentForge instance initialized.")
    if interactive and answers is not None:
        print("\nNext steps:")
        print("  1. Review .env and confirm optional keys")
        print("  2. Review memory/soul.md and adjust your assistant identity")
        print(f"  3. Run: AGENTFORGE_ROOT={root} agentforge bot")
    else:
        print("\nNext steps:")
        print("  1. Edit .env with your Telegram bot token")
        print("  2. Edit bot/config.json with your chat IDs")
        print("  3. Edit memory/soul.md to define your bot's personality")
        print(f"  4. Run: AGENTFORGE_ROOT={root} agentforge bot")
