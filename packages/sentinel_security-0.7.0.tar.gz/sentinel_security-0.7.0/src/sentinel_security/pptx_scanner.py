"""PowerPoint (.pptx) scanner for hidden content and prompt injection."""

import logging
import re
import zipfile
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

from .patterns import CONTENT_INJECTION_PATTERNS

from .sanitiser.scorer import risk_level
from .utils import calculate_threat_risk_score

def scan_pptx(file_path: str) -> dict:
    logger.debug("scan_pptx: start file=%s", file_path)
    threats: List[Dict[str, Any]] = []

    try:
        from pptx import Presentation
        prs = Presentation(file_path)
    except Exception as e:
        raise ValueError(f"Failed to load PowerPoint file: {e}")

    info = {
        'file_path': file_path,
        'slide_count': len(prs.slides),
        'slide_width': prs.slide_width,
        'slide_height': prs.slide_height,
    }

    for slide_idx, slide in enumerate(prs.slides, 1):
        # Hidden slides
        slide_elem = slide._element
        show_attr = slide_elem.get('show')
        if show_attr == '0':
            threats.append({'type': 'hidden_slide', 'severity': 'HIGH',
                            'detail': f'Slide {slide_idx} is hidden.', 'slide': slide_idx})

        # Speaker notes
        if slide.has_notes_slide:
            notes_text = slide.notes_slide.notes_text_frame.text.strip()
            if notes_text:
                for pattern in CONTENT_INJECTION_PATTERNS:
                    if re.search(pattern, notes_text, re.IGNORECASE):
                        threats.append({'type': 'injection_in_notes', 'severity': 'CRITICAL',
                                        'detail': f'Injection in speaker notes of slide {slide_idx}.',
                                        'slide': slide_idx, 'value_preview': notes_text[:100]})
                        break

        for shape in slide.shapes:
            # Off-canvas shapes
            if shape.left is not None and shape.top is not None:
                if (shape.left + shape.width < 0 or shape.left > prs.slide_width or
                        shape.top + shape.height < 0 or shape.top > prs.slide_height):
                    threats.append({'type': 'off_canvas_shape', 'severity': 'HIGH',
                                    'detail': f'Shape "{shape.name}" on slide {slide_idx} is off-canvas.',
                                    'slide': slide_idx, 'shape_name': shape.name})

            # Alt text via cNvPr descr attribute
            alt_text = ''
            for cNvPr in shape._element.iter('{http://schemas.openxmlformats.org/drawingml/2006/main}cNvPr'):
                alt_text = cNvPr.get('descr', '')
                if alt_text:
                    break
            if not alt_text:
                for cNvPr in shape._element.iter('{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}cNvPr'):
                    alt_text = cNvPr.get('descr', '')
                    if alt_text:
                        break
            if alt_text:
                for pattern in CONTENT_INJECTION_PATTERNS:
                    if re.search(pattern, alt_text, re.IGNORECASE):
                        threats.append({'type': 'injection_in_alt_text', 'severity': 'CRITICAL',
                                        'detail': f'Injection in alt text of shape "{shape.name}" on slide {slide_idx}.',
                                        'slide': slide_idx, 'value_preview': alt_text[:100]})
                        break

            # Text content & injection
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    text = para.text
                    if text.strip():
                        for pattern in CONTENT_INJECTION_PATTERNS:
                            if re.search(pattern, text, re.IGNORECASE):
                                threats.append({'type': 'injection_in_text', 'severity': 'CRITICAL',
                                                'detail': f'Injection in text on slide {slide_idx}.',
                                                'slide': slide_idx, 'value_preview': text[:100]})
                                break

                    # Zero-opacity text
                    for run in para.runs:
                        try:
                            if run.font.color and run.font.color.rgb:
                                rgb_str = str(run.font.color.rgb)
                                if len(rgb_str) == 8 and rgb_str[:2] == '00':
                                    threats.append({'type': 'zero_opacity_text', 'severity': 'HIGH',
                                                    'detail': f'Zero-opacity text on slide {slide_idx}.',
                                                    'slide': slide_idx, 'value_preview': run.text[:100]})
                        except Exception as e:
                            logger.warning("Failed to check zero-opacity text in PPTX run: %s", e)

            # Hyperlinks
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        try:
                            if run.hyperlink and run.hyperlink.address:
                                threats.append({'type': 'hyperlink', 'severity': 'LOW',
                                                'detail': f'Hyperlink on slide {slide_idx}: {run.hyperlink.address[:80]}',
                                                'slide': slide_idx})
                        except Exception as e:
                            logger.warning("Failed to check hyperlink in PPTX run: %s", e)

    # Embedded objects
    try:
        with zipfile.ZipFile(file_path, 'r') as zf:
            for name in zf.namelist():
                if name.startswith('ppt/embeddings/'):
                    threats.append({'type': 'embedded_object', 'severity': 'MEDIUM',
                                    'detail': f'Embedded object: {name}', 'file_name': name})
    except zipfile.BadZipFile:
        pass

    logger.debug("scan_pptx: end file=%s threats=%d", file_path, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_pptx: threats detected count=%d types=%s file=%s", len(threats), types, file_path)
    risk_score = calculate_threat_risk_score(threats)
    return {
        'info': info, 'threats': threats, 'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }
