"""
CLI entry point for sentinel-scan.

Usage:
    sentinel-scan <file>                  # scan a file (auto-detect type)
    sentinel-scan --stdin                 # read text from stdin
    sentinel-scan <file> --format html    # treat as HTML
    sentinel-scan <file> --format excel   # treat as Excel
    sentinel-scan <file> --threats-only   # skip clean text output
    sentinel-scan <file> --output json    # output format (json/text)
    sentinel-scan --google-doc ID         # scan a Google Doc by ID
    sentinel-scan --google-slides ID      # scan a Google Slides presentation by ID
    sentinel-scan --google-drive ID       # scan a Google Drive file metadata by ID
    sentinel-scan --google-credentials PATH # path to Google credentials JSON
    sentinel-scan --ms-excel ITEM_ID      # scan Excel Online via Graph API
    sentinel-scan --ms-word ITEM_ID       # scan Word Online via Graph API
    sentinel-scan --ms-pptx ITEM_ID       # scan PowerPoint Online via Graph API
    sentinel-scan --ms-drive ITEM_ID      # scan OneDrive/SharePoint item metadata
    sentinel-scan --ms-credentials PATH   # path to MS credentials JSON
    sentinel-scan --ms-tenant TENANT_ID   # Azure AD tenant ID
    sentinel-scan --ms-client CLIENT_ID   # Azure AD client ID
    sentinel-scan --verify                # verify your licence key
"""

import argparse
import json
import logging
import sys

logger = logging.getLogger(__name__)


def verify_licence():
    """Check SENTINEL_LICENCE_KEY against the Sentinel API."""
    import os
    import urllib.request
    import urllib.error

    key = os.environ.get('SENTINEL_LICENCE_KEY')
    if not key:
        print("No licence key found.")
        print("")
        print("Set your licence key:")
        print("")
        print("  macOS / Linux:")
        print("    export SENTINEL_LICENCE_KEY=your-key-here")
        print("")
        print("  Windows (PowerShell):")
        print('    $env:SENTINEL_LICENCE_KEY="your-key-here"')
        print("")
        print("  Windows (CMD):")
        print("    set SENTINEL_LICENCE_KEY=your-key-here")
        print("")
        print("Get your key at https://sentinel-agents.com/pricing")
        sys.exit(1)

    # Call the verification API
    url = "https://sentinel-agents.com/api/verify"
    try:
        body = json.dumps({"key": key}).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "User-Agent": "sentinel-scan",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())

        if data.get("valid"):
            email = data.get("email", "unknown")
            print("Licence valid")
            print(f"  Account: {email}")
            print(f"  Status: active")
            print("")
            print("Sentinel is ready to protect your agents.")
        else:
            print("Licence invalid or expired.")
            print("")
            print("Check your key or renew at https://sentinel-agents.com/pricing")
            sys.exit(1)

    except urllib.error.URLError as e:
        print(f"Could not reach verification server: {e.reason}")
        print("Check your internet connection and try again.")
        sys.exit(1)
    except Exception as e:
        print(f"Verification failed: {e}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        prog='sentinel-scan',
        description='Scan content for prompt injection attacks',
    )
    parser.add_argument(
        'file',
        nargs='?',
        help='File to scan (use --stdin to read from stdin)',
    )
    parser.add_argument(
        '--stdin',
        action='store_true',
        help='Read content from stdin',
    )
    # Google flags
    parser.add_argument(
        '--google-doc',
        help='Scan a Google Doc by ID',
    )
    parser.add_argument(
        '--google-slides',
        help='Scan a Google Slides presentation by ID',
    )
    parser.add_argument(
        '--google-drive',
        help='Scan a Google Drive file metadata by ID',
    )
    parser.add_argument(
        '--google-credentials',
        help='Path to Google credentials JSON',
    )
    # Microsoft flags
    parser.add_argument(
        '--ms-excel',
        help='Scan an Excel Online workbook by item ID',
    )
    parser.add_argument(
        '--ms-word',
        help='Scan a Word Online document by item ID',
    )
    parser.add_argument(
        '--ms-pptx',
        help='Scan a PowerPoint Online file by item ID',
    )
    parser.add_argument(
        '--ms-drive',
        help='Scan a OneDrive/SharePoint item metadata by item ID',
    )
    parser.add_argument(
        '--ms-credentials',
        help='Path to Microsoft credentials JSON',
    )
    parser.add_argument(
        '--ms-tenant',
        help='Azure AD tenant ID',
    )
    parser.add_argument(
        '--ms-client',
        help='Azure AD client ID',
    )
    # Output flags
    parser.add_argument(
        '--format',
        choices=['html', 'text', 'excel', 'word', 'pptx'],
        default=None,
        help='Input format. Auto-detected from extension if not set.',
    )
    parser.add_argument(
        '--threats-only',
        action='store_true',
        help='Output only the threat report (omit clean_text)',
    )
    parser.add_argument(
        '--quiet',
        action='store_true',
        help='Exit code only: 0 = clean, 1 = threats found. No output.',
    )
    parser.add_argument(
        '--output',
        choices=['json', 'text'],
        default='json',
        help='Output format (default: json).',
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose (DEBUG) logging. Default level is WARNING.',
    )
    parser.add_argument(
        '--verify',
        action='store_true',
        help='Verify your Sentinel licence key',
    )
    args = parser.parse_args()

    # Handle --verify flag early
    if args.verify:
        verify_licence()
        return

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format='%(asctime)s %(name)s %(levelname)s %(message)s',
    )
    logger.debug('sentinel-scan starting')

    # Google scanner handling
    google_creds_path = args.google_credentials if hasattr(args, 'google_credentials') else None

    if args.google_doc:
        from .gdocs import scan_google_doc
        result = scan_google_doc(args.google_doc, credentials_path=google_creds_path)
    elif args.google_slides:
        from .gslides import scan_google_slides
        result = scan_google_slides(args.google_slides, credentials_path=google_creds_path)
    elif args.google_drive:
        from .gdrive import scan_google_drive_file
        result = scan_google_drive_file(args.google_drive, credentials_path=google_creds_path)
    elif args.ms_excel or args.ms_word or args.ms_pptx or args.ms_drive:
        # Microsoft scanner handling
        from .ms_auth import get_graph_client
        auth = get_graph_client(
            tenant_id=args.ms_tenant,
            client_id=args.ms_client,
            credentials_path=args.ms_credentials,
        )
        if args.ms_excel:
            from .excel_online import scan_excel_online
            result = scan_excel_online(args.ms_excel, auth=auth)
        elif args.ms_word:
            from .word_online import scan_word_online
            result = scan_word_online(args.ms_word, auth=auth)
        elif args.ms_pptx:
            from .pptx_online import scan_pptx_online
            result = scan_pptx_online(args.ms_pptx, auth=auth)
        elif args.ms_drive:
            from .ms_drive import scan_ms_drive_item
            result = scan_ms_drive_item(args.ms_drive, auth=auth)
    elif args.stdin:
        from .sanitiser import sanitise_content
        content = sys.stdin.read()
        fmt = args.format if args.format in ('html', 'text') else 'text'
        result = sanitise_content(content, format=fmt)
    elif args.file:
        import os
        if not os.path.exists(args.file):
            logger.error('file not found: %s', args.file)
            sys.exit(2)
        if os.path.isdir(args.file):
            logger.error('%s is a directory', args.file)
            sys.exit(2)

        from .scanner import scan_file
        result = scan_file(args.file, format=args.format)
    else:
        parser.error('Provide a file path, use --stdin, or use a scanner flag (--google-doc, --ms-excel, etc.)')

    if args.quiet:
        sys.exit(1 if result.get('threat_count', 0) > 0 else 0)

    if args.threats_only:
        result.pop('clean_text', None)

    json.dump(result, sys.stdout, indent=2, ensure_ascii=False, default=str)
    print()

    sys.exit(1 if result.get('threat_count', 0) > 0 else 0)


if __name__ == '__main__':
    main()
