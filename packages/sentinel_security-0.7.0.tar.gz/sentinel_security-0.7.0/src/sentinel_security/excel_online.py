"""
Excel Online scanner via Microsoft Graph API.

Scans Excel workbooks stored in OneDrive/SharePoint for hidden content
and prompt injection patterns using the Graph API worksheets endpoint.

Note: Graph API does not expose cell-level formatting (font colour, font size),
so colour-matched text and tiny font detection are not available for online files.
Use the local excel.py scanner (via download) for full formatting checks.

Requires: pip install sentinel-security[microsoft]
"""

import logging
import re
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

from .config import GRAPH_BASE_URL as GRAPH_BASE
from .patterns import CONTENT_INJECTION_PATTERNS

from .sanitiser.scorer import risk_level
from .utils import calculate_threat_risk_score

def scan_excel_online(
    item_id: str,
    drive_id: Optional[str] = None,
    site_id: Optional[str] = None,
    auth=None,
) -> dict:
    """
    Scan an Excel Online workbook via Microsoft Graph API.

    Args:
        item_id: The OneDrive/SharePoint item ID of the Excel file.
        drive_id: Drive ID. If None, uses /me/drive.
        site_id: SharePoint site ID. Used with drive_id for site drives.
        auth: Authenticated requests.Session from ms_auth.get_graph_client().

    Returns:
        dict with keys:
            info (dict): Workbook metadata.
            threats (list): Detected threats with type, severity, detail.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.

    Raises:
        ImportError: If requests is not installed.
        ValueError: If auth session is not provided.
    """
    logger.debug("scan_excel_online: start item_id=%s", item_id)
    if auth is None:
        raise ValueError("auth (requests.Session) is required. Use ms_auth.get_graph_client().")

    base = _build_item_url(item_id, drive_id, site_id)
    threats: List[Dict[str, Any]] = []

    # Get workbook worksheets
    ws_url = f"{base}/workbook/worksheets"
    ws_resp = auth.get(ws_url)
    ws_resp.raise_for_status()
    worksheets = ws_resp.json().get('value', [])

    info = {
        'item_id': item_id,
        'sheet_count': len(worksheets),
        'sheet_names': [ws.get('name', '') for ws in worksheets],
    }

    for ws in worksheets:
        sheet_name = ws.get('name', 'Unknown')
        sheet_id = ws.get('id', '')

        # 1. Hidden worksheets
        visibility = ws.get('visibility', 'Visible')
        if visibility != 'Visible':
            threats.append({
                'type': 'hidden_sheet',
                'severity': 'HIGH',
                'detail': f'Sheet "{sheet_name}" is hidden (visibility: {visibility}).',
                'sheet_name': sheet_name,
            })

        # 2. Scan used range for injection patterns
        range_url = f"{base}/workbook/worksheets/{sheet_id}/usedRange"
        try:
            range_resp = auth.get(range_url)
            range_resp.raise_for_status()
            range_data = range_resp.json()

            values = range_data.get('values', [])
            for row_idx, row in enumerate(values):
                for col_idx, cell_value in enumerate(row):
                    if cell_value is None or (isinstance(cell_value, str) and not cell_value.strip()):
                        continue
                    cell_str = str(cell_value)
                    cell_ref = f'R{row_idx+1}C{col_idx+1}'

                    for pattern in CONTENT_INJECTION_PATTERNS:
                        if re.search(pattern, cell_str, re.IGNORECASE):
                            threats.append({
                                'type': 'injection_in_cell',
                                'severity': 'CRITICAL',
                                'detail': f'Injection pattern in cell {cell_ref} of sheet "{sheet_name}".',
                                'sheet_name': sheet_name,
                                'cell': cell_ref,
                                'value_preview': cell_str[:100],
                            })
                            break
        except Exception as e:
            logger.warning("Failed to scan Excel Online cell value: %s", e)

        # 3. Named ranges
        names_url = f"{base}/workbook/names"
        try:
            names_resp = auth.get(names_url)
            names_resp.raise_for_status()
            for named in names_resp.json().get('value', []):
                name = named.get('name', '')
                value = named.get('value', '')
                if value and isinstance(value, str):
                    for pattern in CONTENT_INJECTION_PATTERNS:
                        if re.search(pattern, value, re.IGNORECASE):
                            threats.append({
                                'type': 'injection_in_named_range',
                                'severity': 'CRITICAL',
                                'detail': f'Injection pattern in named range "{name}".',
                                'named_range': name,
                                'value_preview': value[:100],
                            })
                            break
                    else:
                        threats.append({
                            'type': 'named_range',
                            'severity': 'LOW',
                            'detail': f'Named range "{name}" found.',
                            'named_range': name,
                        })
        except Exception as e:
            logger.warning("Failed to process Excel Online named range: %s", e)

    # 4. Comments on the item
    comments_url = f"{base}/comments"
    try:
        comments_resp = auth.get(comments_url)
        comments_resp.raise_for_status()
        for comment in comments_resp.json().get('value', []):
            content = comment.get('content', '')
            if content:
                for pattern in CONTENT_INJECTION_PATTERNS:
                    if re.search(pattern, content, re.IGNORECASE):
                        threats.append({
                            'type': 'injection_in_comment',
                            'severity': 'CRITICAL',
                            'detail': 'Injection pattern in file comment.',
                            'value_preview': content[:100],
                        })
                        break
                else:
                    threats.append({
                        'type': 'comment',
                        'severity': 'LOW',
                        'detail': 'File has a comment.',
                        'value_preview': content[:100],
                    })
    except Exception as e:
        logger.warning("Failed to scan Excel Online defined name: %s", e)

    logger.debug("scan_excel_online: end item_id=%s threats=%d", item_id, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_excel_online: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_threat_risk_score(threats)
    return {
        'info': info,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }


def _build_item_url(item_id: str, drive_id: Optional[str], site_id: Optional[str]) -> str:
    """Build the Graph API URL for a drive item."""
    if site_id and drive_id:
        return f"{GRAPH_BASE}/sites/{site_id}/drives/{drive_id}/items/{item_id}"
    elif drive_id:
        return f"{GRAPH_BASE}/drives/{drive_id}/items/{item_id}"
    else:
        return f"{GRAPH_BASE}/me/drive/items/{item_id}"
