"""Detection functions for prompt injection and related threats."""

import html
import re
import unicodedata
from typing import List

from ..patterns import (
    HIDDEN_HTML_PATTERNS,
    INJECTION_PATTERNS,
    INVISIBLE_CHARS,
    RTL_OVERRIDE_CHARS,
)


def normalise_unicode(text: str) -> str:
    """Normalise Unicode and case folding to catch fullwidth and Turkish i variants."""
    return unicodedata.normalize('NFKC', text).casefold()


# Leetspeak transliteration map: digit/symbol -> most common alpha equivalent
_LEET_MAP = str.maketrans({
    '0': 'o',
    '1': 'i',
    '3': 'e',
    '4': 'a',
    '5': 's',
    '7': 't',
    '@': 'a',
})


def transliterate_leetspeak(text: str) -> str:
    """Transliterate common leetspeak substitutions to ASCII letters.

    Only applied as an additional detection pass -- the original text
    is preserved for all other processing.
    """
    return text.translate(_LEET_MAP)


def detect_invisible_chars(text: str) -> list:
    """Find invisible Unicode characters and their positions."""
    threats = []
    for i, char in enumerate(text):
        if char in INVISIBLE_CHARS:
            start = max(0, i - 20)
            end = min(len(text), i + 20)
            threats.append({
                'type': 'invisible_unicode',
                'char': INVISIBLE_CHARS[char],
                'codepoint': f'U+{ord(char):04X}',
                'position': i,
                'context': repr(text[start:end]),
                'matched_text': INVISIBLE_CHARS[char],
            })
    return threats


def detect_injection_patterns(text: str) -> list:
    """Find injection trigger phrases."""
    threats = []
    normalised_text = normalise_unicode(text)

    seen_patterns = set()
    for pattern in INJECTION_PATTERNS:
        for match in re.finditer(pattern, normalised_text, re.IGNORECASE):
            start = max(0, match.start() - 30)
            end = min(len(text), match.end() + 30)
            threats.append({
                'type': 'injection_pattern',
                'pattern': pattern,
                'matched': match.group(),
                'matched_text': match.group(),
                'context': text[start:end],
                'position': match.start(),
            })
            seen_patterns.add(pattern)

    # Second pass: leetspeak transliteration
    leet_text = transliterate_leetspeak(normalised_text)
    if leet_text != normalised_text:
        for pattern in INJECTION_PATTERNS:
            if pattern in seen_patterns:
                continue  # Already matched on normal text
            for match in re.finditer(pattern, leet_text, re.IGNORECASE):
                start = max(0, match.start() - 30)
                end = min(len(text), match.end() + 30)
                threats.append({
                    'type': 'injection_pattern',
                    'pattern': pattern,
                    'matched': match.group(),
                    'matched_text': match.group(),
                    'context': text[start:end],
                    'position': match.start(),
                })
                break  # One match per pattern is enough

    return threats


def detect_base64_blocks(text: str) -> list:
    """Find suspicious base64-encoded blocks (20+ chars) and URL-sharded base64."""
    threats = []
    for match in re.finditer(r'[A-Za-z0-9+/]{20,}={0,2}', text):
        threats.append({
            'type': 'base64_block',
            'length': len(match.group()),
            'position': match.start(),
            'preview': match.group()[:60] + '...',
            'matched_text': match.group()[:60],
            'context': text[max(0, match.start()-20):match.end()+20][:100],
        })

    # Detect multiple URLs carrying base64-encoded query parameter values
    # (shard exfiltration pattern: data split across multiple requests)
    b64_url_params = re.findall(
        r'https?://\S+[?&]\w*=[A-Za-z0-9+/]{4,}={0,2}(?:\s|$)', text
    )
    if len(b64_url_params) >= 3:
        threats.append({
            'type': 'base64_block',
            'length': sum(len(u) for u in b64_url_params),
            'position': text.find(b64_url_params[0]),
            'preview': f'{len(b64_url_params)} URLs with base64 query params',
            'matched_text': f'{len(b64_url_params)} URLs with base64 query params',
            'context': b64_url_params[0][:100] if b64_url_params else '',
        })
        threats.append({
            'type': 'base64_shard_exfil',
            'length': len(b64_url_params),
            'position': text.find(b64_url_params[0]),
            'preview': f'Shard exfiltration: {len(b64_url_params)} URLs',
            'matched_text': f'Shard exfiltration: {len(b64_url_params)} URLs',
            'context': b64_url_params[0][:100] if b64_url_params else '',
        })

    return threats


def detect_rtl_override(text: str) -> list:
    """Detect RTL override attacks that visually reorder text."""
    threats = []
    for i, char in enumerate(text):
        if char in RTL_OVERRIDE_CHARS:
            threats.append({
                'type': 'rtl_override',
                'char': RTL_OVERRIDE_CHARS[char],
                'codepoint': f'U+{ord(char):04X}',
                'position': i,
                'matched_text': RTL_OVERRIDE_CHARS[char],
                'context': repr(text[max(0, i-20):min(len(text), i+20)]),
            })
    return threats


def detect_homoglyphs(text: str) -> list:
    """Detect mixed-script words (potential homoglyph attacks)."""
    threats = []
    words = re.findall(r'\S+', text)
    for word in words:
        scripts = set()
        for char in word:
            if char.isalpha():
                try:
                    script = unicodedata.name(char, '').split()[0]
                    scripts.add(script)
                except (ValueError, IndexError):
                    pass
        if len(scripts) > 1 and 'LATIN' in scripts:
            threats.append({
                'type': 'homoglyph',
                'word': word,
                'scripts': list(scripts),
                'position': text.find(word),
                'matched_text': word,
                'context': word,
            })
    return threats


def detect_repo_metadata_injection(text: str) -> list:
    """Detect injection patterns in repository metadata (issues, PRs, commits)."""
    threats = []
    for match in re.finditer(r'<!--[\s\S]*?-->', text):
        comment_text = match.group()[4:-3].strip()
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, comment_text, re.IGNORECASE):
                threats.append({
                    'type': 'repo_metadata_injection',
                    'mechanism': 'HTML comment with injection pattern',
                    'hidden_text': comment_text[:200],
                    'position': match.start(),
                    'matched_text': comment_text[:200],
                    'context': match.group()[:100],
                })
                break
    for match in re.finditer(r'"\$(?:ref|id)"\s*:\s*"(https?://[^"]+)"', text):
        threats.append({
            'type': 'repo_metadata_injection',
            'mechanism': 'JSON schema external reference',
            'url': match.group(1)[:200],
            'position': match.start(),
            'matched_text': match.group(1)[:200],
            'context': match.group()[:100],
        })
    return threats


def detect_css_class_hiding(html_content: str) -> list:
    """Detect CSS class-based hiding attacks."""
    threats = []

    style_pattern = r'<style[^>]*>(.*?)</style>'
    for match in re.finditer(style_pattern, html_content, re.IGNORECASE | re.DOTALL):
        css_content = match.group(1)

        hiding_patterns = [
            r'display\s*:\s*none',
            r'visibility\s*:\s*hidden',
            r'font-size\s*:\s*0',
            r'opacity\s*:\s*0',
            r'height\s*:\s*0',
            r'width\s*:\s*0',
            r'position\s*:\s*absolute.*?(?:left|top)\s*:\s*-\d+'
        ]

        for hiding_pattern in hiding_patterns:
            if re.search(hiding_pattern, css_content, re.IGNORECASE):
                threats.append({
                    'type': 'css_class_hiding',
                    'mechanism': f'CSS hiding rule: {hiding_pattern}',
                    'position': match.start(),
                    'css_content': css_content[:200],
                    'matched_text': css_content[:60],
                    'context': css_content[:100],
                })
                break

    return threats


def detect_html_attributes(html_content: str) -> list:
    """Extract and scan text from HTML attributes."""
    threats = []

    attribute_patterns = [
        r'alt\s*=\s*["\']([^"\']*)["\']',
        r'title\s*=\s*["\']([^"\']*)["\']',
        r'aria-label\s*=\s*["\']([^"\']*)["\']',
        r'aria-description\s*=\s*["\']([^"\']*)["\']'
    ]

    for pattern in attribute_patterns:
        for match in re.finditer(pattern, html_content, re.IGNORECASE):
            attr_text = match.group(1)
            normalised_text = normalise_unicode(attr_text)
            for injection_pattern in INJECTION_PATTERNS:
                if re.search(injection_pattern, normalised_text, re.IGNORECASE):
                    threats.append({
                        'type': 'attribute_injection',
                        'mechanism': f'HTML attribute injection: {match.group().split("=")[0]}',
                        'hidden_text': attr_text[:200],
                        'position': match.start(),
                        'matched_text': attr_text[:200],
                        'context': match.group()[:100],
                    })
                    break

    return threats


def detect_markdown_injection(text: str) -> list:
    """Detect markdown-specific injection patterns."""
    threats = []

    decoded_text = html.unescape(text)

    normalised_decoded = normalise_unicode(decoded_text)
    if decoded_text != text:
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, normalised_decoded, re.IGNORECASE):
                threats.append({
                    'type': 'markdown_injection',
                    'mechanism': 'HTML entity encoded injection',
                    'hidden_text': decoded_text[:200],
                    'position': 0,
                    'matched_text': decoded_text[:200],
                    'context': text[:100],
                })
                break

    ref_link_pattern = r'\[([^\]]+)\]:\s*[^\s]+\s*"([^"]*)"'
    for match in re.finditer(ref_link_pattern, text, re.MULTILINE):
        title = match.group(2)
        normalised_title = normalise_unicode(html.unescape(title))
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, normalised_title, re.IGNORECASE):
                threats.append({
                    'type': 'markdown_injection',
                    'mechanism': 'Reference link title injection',
                    'hidden_text': title[:200],
                    'position': match.start(),
                    'matched_text': title[:200],
                    'context': match.group()[:100],
                })
                break

    link_title_pattern = r'\[([^\]]*)\]\([^)]*\s+"([^"]*)"\)'
    for match in re.finditer(link_title_pattern, text):
        title = match.group(2)
        normalised_title = normalise_unicode(html.unescape(title))
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, normalised_title, re.IGNORECASE):
                threats.append({
                    'type': 'markdown_injection',
                    'mechanism': 'Link title injection',
                    'hidden_text': title[:200],
                    'position': match.start(),
                    'matched_text': title[:200],
                    'context': match.group()[:100],
                })
                break

    img_alt_pattern = r'!\[([^\]]*)\]\([^)]+\)'
    for match in re.finditer(img_alt_pattern, text):
        alt_text = match.group(1)
        normalised_alt = normalise_unicode(html.unescape(alt_text))
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, normalised_alt, re.IGNORECASE):
                threats.append({
                    'type': 'markdown_injection',
                    'mechanism': 'Image alt text injection',
                    'hidden_text': alt_text[:200],
                    'position': match.start(),
                    'matched_text': alt_text[:200],
                    'context': match.group()[:100],
                })
                break

    return threats


def detect_hidden_html(html_content: str) -> list:
    """Find hidden HTML content."""
    threats = []
    for pattern, description in HIDDEN_HTML_PATTERNS:
        for match in re.finditer(pattern, html_content, re.IGNORECASE):
            content = match.group()
            if description == 'HTML comment':
                text_content = re.sub(r'^<!--\s*', '', content)
                text_content = re.sub(r'\s*-->$', '', text_content).strip()
            else:
                text_content = re.sub(r'<[^>]+>', '', content).strip()
            if text_content:
                threats.append({
                    'type': 'hidden_html',
                    'mechanism': description,
                    'hidden_text': text_content[:200],
                    'position': match.start(),
                    'matched_text': text_content[:200],
                    'context': html_content[max(0, match.start()-20):match.end()+20][:100],
                })

    threats.extend(detect_css_class_hiding(html_content))

    return threats
