"""Proximity-based injection detection for filler word evasion."""

import re
from typing import List


# Each tuple: (list of key terms that must appear, max word gap between consecutive terms, description)
PROXIMITY_RULES = [
    (['ignore', 'previous', 'instructions'], 4, 'ignore...previous...instructions'),
    (['ignore', 'prior', 'instructions'], 4, 'ignore...prior...instructions'),
    (['ignore', 'above', 'instructions'], 4, 'ignore...above...instructions'),
    (['disregard', 'previous', 'instructions'], 4, 'disregard...previous...instructions'),
    (['forget', 'previous', 'instructions'], 4, 'forget...previous...instructions'),
    (['override', 'previous', 'instructions'], 4, 'override...previous...instructions'),
    (['ignore', 'previous', 'directives'], 4, 'ignore...previous...directives'),
    (['ignore', 'system', 'instructions'], 4, 'ignore...system...instructions'),
    (['bypass', 'safety', 'restrictions'], 4, 'bypass...safety...restrictions'),
    (['disable', 'safety', 'filters'], 4, 'disable...safety...filters'),
]


def detect_proximity_injection(text: str) -> List[dict]:
    """Detect injection phrases with filler words between key terms.

    Catches evasions like:
      "ignore absolutely all previously given instructions"
      "ignore the previous system instructions"

    Uses word-proximity matching: all key terms must appear in order
    within N words of each other.
    """
    threats = []
    normalised = text.lower()
    words = re.findall(r'[a-z]+', normalised)

    for terms, max_gap, description in PROXIMITY_RULES:
        positions = _find_term_positions(words, terms)
        if positions is not None:
            # Check that consecutive terms are within max_gap words of each other
            gaps_ok = all(
                positions[i+1] - positions[i] <= max_gap + 1
                for i in range(len(positions) - 1)
            )
            if gaps_ok:
                char_pos = _approx_char_position(normalised, words, positions[0])
                threats.append({
                    'type': 'injection_pattern',
                    'pattern': f'proximity:{description}',
                    'matched': ' '.join(words[positions[0]:positions[-1]+1]),
                    'matched_text': ' '.join(words[positions[0]:positions[-1]+1]),
                    'context': text[max(0, char_pos-30):char_pos+60],
                    'position': char_pos,
                })
                break  # One proximity match is enough per text

    return threats


def _find_term_positions(words: list, terms: list) -> list:
    """Find the first occurrence of terms appearing in order in words.

    Returns list of word indices or None if not all terms found in order.
    Uses startswith matching so "previously" matches term "previous".
    """
    positions = []
    search_from = 0
    for term in terms:
        found = False
        for i in range(search_from, len(words)):
            if words[i].startswith(term):
                positions.append(i)
                search_from = i + 1
                found = True
                break
        if not found:
            return None
    return positions


def _approx_char_position(text: str, words: list, word_index: int) -> int:
    """Approximate the character position of a word by index."""
    count = 0
    for match in re.finditer(r'[a-z]+', text):
        if count == word_index:
            return match.start()
        count += 1
    return 0
