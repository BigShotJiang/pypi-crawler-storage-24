"""
Google Docs hidden content scanner.

Checks a Google Doc for hidden content, injection patterns, and suspicious elements
that could be used for prompt injection via AI agents reading document content.

Requires: pip install sentinel-security[google]
"""

import logging
import re
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

from .patterns import INJECTION_PATTERNS

from .google_auth import _load_credentials
from .sanitiser.scorer import risk_level
from .utils import calculate_threat_risk_score

def scan_google_doc(document_id: str, credentials=None, credentials_path: Optional[str] = None) -> dict:
    """
    Scan a Google Doc for hidden content and injection patterns.

    Args:
        document_id: The Google Docs document ID.
        credentials: A google.oauth2.credentials.Credentials object.
                     If not provided, will attempt to load from credentials_path.
        credentials_path: Path to a JSON credentials file. Used only if
                         credentials is None.

    Returns:
        dict with keys:
            info (dict): Document metadata.
            threats (list): Detected threats with type, severity, detail.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.

    Raises:
        ImportError: If google-api-python-client is not installed.
    """
    try:
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Google API client required. Install with: "
            "pip install sentinel-security[google]"
        )

    if credentials is None:
        credentials = _load_credentials(credentials_path)

    service = build('docs', 'v1', credentials=credentials)
    doc = service.documents().get(documentId=document_id).execute()

    logger.debug("scan_google_doc: start document_id=%s", document_id)
    threats = []
    info = {
        'document_id': document_id,
        'title': doc.get('title', 'Untitled'),
        'page_count': _get_page_count(doc),
    }

    # 1. Scan body content
    body_content = doc.get('body', {}).get('content', [])
    _scan_content(body_content, 'body', doc, threats)

    # 2. Scan footnotes
    footnotes = doc.get('footnotes', {})
    for footnote_id, footnote in footnotes.items():
        footnote_content = footnote.get('content', [])
        _scan_content(footnote_content, f'footnote:{footnote_id}', doc, threats)

    # 3. Scan endnotes (if present)
    endnotes = doc.get('endnotes', {})
    for endnote_id, endnote in endnotes.items():
        endnote_content = endnote.get('content', [])
        _scan_content(endnote_content, f'endnote:{endnote_id}', doc, threats)

    # 4. Scan headers
    headers = doc.get('headers', {})
    for header_id, header in headers.items():
        header_content = header.get('content', [])
        _scan_content(header_content, f'header:{header_id}', doc, threats)

    # 5. Scan footers
    footers = doc.get('footers', {})
    for footer_id, footer in footers.items():
        footer_content = footer.get('content', [])
        _scan_content(footer_content, f'footer:{footer_id}', doc, threats)

    # 6. Scan for hidden text in body
    _scan_hidden_text(body_content, threats)

    # 7. Scan for bookmarks
    _scan_bookmarks(body_content, doc, threats)

    # 8. Scan inline images
    _scan_inline_images(doc, threats)

    # 9. Scan for suspicious links
    _scan_suspicious_links(body_content, threats)

    # 10. Scan for comments/suggestions
    _scan_suggestions(doc, threats)

    logger.debug("scan_google_doc: end document_id=%s threats=%d", document_id, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_google_doc: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_threat_risk_score(threats)

    return {
        'info': info,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }



def _get_page_count(doc: dict) -> int:
    """Estimate page count from document size."""
    # Google Docs API doesn't provide page count directly
    # We can estimate based on content length
    body_texts, _ = _extract_text_from_content(doc.get('body', {}).get('content', []))
    total_chars = sum(len(text) for text in body_texts)
    # Rough estimate: ~3000 chars per page
    return max(1, total_chars // 3000)


def _extract_text_from_content(content_list: List[dict]) -> Tuple[List[str], List[dict]]:
    """Extract text and elements from a Docs API content list."""
    texts = []
    elements = []
    for item in content_list:
        if 'paragraph' in item:
            for elem in item['paragraph'].get('elements', []):
                elements.append(elem)
                if 'textRun' in elem:
                    texts.append(elem['textRun'].get('content', ''))
        if 'table' in item:
            for row in item['table'].get('tableRows', []):
                for cell in row.get('tableCells', []):
                    t, e = _extract_text_from_content(cell.get('content', []))
                    texts.extend(t)
                    elements.extend(e)
    return texts, elements


def _scan_content(content_list: List[dict], location: str, doc: dict, threats: list):
    """Scan content for injection patterns."""
    texts, elements = _extract_text_from_content(content_list)
    
    for text in texts:
        if not text.strip():
            continue
            
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                threats.append({
                    'type': 'injection_pattern',
                    'location': location,
                    'severity': 'CRITICAL',
                    'detail': f'Injection pattern found in {location}: {text[:100]}...',
                })
                break


def _scan_hidden_text(content_list: List[dict], threats: list):
    """Scan for hidden text (tiny font or matching colors)."""
    def _scan_elements(elements: List[dict], location: str):
        for elem in elements:
            if 'textRun' in elem:
                text_run = elem['textRun']
                text = text_run.get('content', '').strip()
                if not text:
                    continue
                    
                text_style = text_run.get('textStyle', {})
                
                # Check for tiny font
                font_size = text_style.get('fontSize', {})
                if font_size:
                    magnitude = font_size.get('magnitude', 12)
                    unit = font_size.get('unit', 'PT')
                    if unit == 'PT' and magnitude < 2:
                        threats.append({
                            'type': 'hidden_text_tiny_font',
                            'location': location,
                            'severity': 'HIGH',
                            'detail': f'Tiny font ({magnitude}pt) hiding text: {text[:100]}...',
                        })
                
                # Check for matching foreground/background colors
                fg_color = text_style.get('foregroundColor', {}).get('color', {}).get('rgbColor', {})
                bg_color = text_style.get('backgroundColor', {}).get('color', {}).get('rgbColor', {})
                
                if fg_color and bg_color:
                    fg_r = fg_color.get('red', 0)
                    fg_g = fg_color.get('green', 0)
                    fg_b = fg_color.get('blue', 0)
                    bg_r = bg_color.get('red', 1)
                    bg_g = bg_color.get('green', 1)
                    bg_b = bg_color.get('blue', 1)
                    
                    if (abs(fg_r - bg_r) < 0.05 and
                        abs(fg_g - bg_g) < 0.05 and
                        abs(fg_b - bg_b) < 0.05):
                        threats.append({
                            'type': 'hidden_text_matching_colors',
                            'location': location,
                            'severity': 'HIGH',
                            'detail': f'Text color matches background (hidden): {text[:100]}...',
                        })
    
    def _scan_content_recursive(content: List[dict], path: str = 'body'):
        for item in content:
            if 'paragraph' in item:
                elements = item['paragraph'].get('elements', [])
                _scan_elements(elements, path)
            elif 'table' in item:
                for row_idx, row in enumerate(item['table'].get('tableRows', [])):
                    for cell_idx, cell in enumerate(row.get('tableCells', [])):
                        cell_path = f'{path}.table[{row_idx}].cell[{cell_idx}]'
                        _scan_content_recursive(cell.get('content', []), cell_path)
    
    _scan_content_recursive(content_list)


def _scan_bookmarks(content_list: List[dict], doc: dict, threats: list):
    """Scan for bookmarks with suspicious content."""
    bookmarks = doc.get('namedRanges', {})
    for bookmark_id, bookmark in bookmarks.items():
        # Check if bookmark has content
        ranges = bookmark.get('ranges', [])
        for rng in ranges:
            # Extract text from the bookmark range
            # This is simplified - in practice would need to extract content from the range
            threats.append({
                'type': 'bookmark_detected',
                'bookmark_id': bookmark_id,
                'severity': 'LOW',
                'detail': f'Bookmark "{bookmark_id}" found. Manual inspection recommended.',
            })


def _scan_inline_images(doc: dict, threats: list):
    """Scan inline images for suspicious titles/descriptions."""
    inline_objects = doc.get('inlineObjects', {})
    
    for obj_id, obj in inline_objects.items():
        inline_object_props = obj.get('inlineObjectProperties', {})
        embedded_object = inline_object_props.get('embeddedObject', {})
        
        title = embedded_object.get('title', '')
        description = embedded_object.get('description', '')
        
        # Check title and description for injection patterns
        for text in [title, description]:
            if not text.strip():
                continue
                
            for pattern in INJECTION_PATTERNS:
                if re.search(pattern, text, re.IGNORECASE):
                    threats.append({
                        'type': 'injection_in_image_metadata',
                        'image_id': obj_id,
                        'severity': 'CRITICAL',
                        'detail': f'Injection pattern in image metadata: {text[:100]}...',
                    })
                    break


def _scan_suspicious_links(content_list: List[dict], threats: list):
    """Scan for suspicious links (javascript:, data:, etc.)."""
    def _scan_elements(elements: List[dict], location: str):
        for elem in elements:
            if 'textRun' in elem:
                text_style = elem['textRun'].get('textStyle', {})
                link = text_style.get('link', {})
                url = link.get('url', '')
                
                if url:
                    url_lower = url.lower()
                    if url_lower.startswith('javascript:'):
                        threats.append({
                            'type': 'suspicious_link_javascript',
                            'location': location,
                            'url': url,
                            'severity': 'HIGH',
                            'detail': f'JavaScript link found: {url[:100]}',
                        })
                    elif url_lower.startswith('data:'):
                        threats.append({
                            'type': 'suspicious_link_data',
                            'location': location,
                            'url': url,
                            'severity': 'HIGH',
                            'detail': f'Data URI link found: {url[:100]}',
                        })
                    elif len(url) > 500:  # Extremely long URL
                        threats.append({
                            'type': 'suspicious_link_long',
                            'location': location,
                            'url_length': len(url),
                            'severity': 'MEDIUM',
                            'detail': f'Extremely long URL ({len(url)} chars)',
                        })
    
    def _scan_content_recursive(content: List[dict], path: str = 'body'):
        for item in content:
            if 'paragraph' in item:
                elements = item['paragraph'].get('elements', [])
                _scan_elements(elements, path)
            elif 'table' in item:
                for row_idx, row in enumerate(item['table'].get('tableRows', [])):
                    for cell_idx, cell in enumerate(row.get('tableCells', [])):
                        cell_path = f'{path}.table[{row_idx}].cell[{cell_idx}]'
                        _scan_content_recursive(cell.get('content', []), cell_path)
    
    _scan_content_recursive(content_list)


def _scan_suggestions(doc: dict, threats: list):
    """Scan for comments and suggestions."""
    # Check for suggested insertions
    suggested_insertions = doc.get('suggestedInsertionIds', {})
    if suggested_insertions:
        threats.append({
            'type': 'suggested_insertions',
            'count': len(suggested_insertions),
            'severity': 'MEDIUM',
            'detail': f'{len(suggested_insertions)} suggested insertions found. May contain hidden content.',
        })
    
    # Check for suggested text style changes
    suggested_changes = doc.get('suggestedTextStyleChanges', {})
    if suggested_changes:
        threats.append({
            'type': 'suggested_text_style_changes',
            'count': len(suggested_changes),
            'severity': 'LOW',
            'detail': f'{len(suggested_changes)} suggested text style changes found.',
        })
