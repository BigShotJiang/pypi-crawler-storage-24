"""Detection patterns for prompt injection and content hiding."""

import re
import unicodedata

# Zero-width and invisible Unicode characters
INVISIBLE_CHARS = {
    '\u200b': 'ZERO WIDTH SPACE',
    '\u200c': 'ZERO WIDTH NON-JOINER',
    '\u200d': 'ZERO WIDTH JOINER',
    '\u200e': 'LEFT-TO-RIGHT MARK',
    '\u200f': 'RIGHT-TO-LEFT MARK',
    '\u2060': 'WORD JOINER',
    '\u2061': 'FUNCTION APPLICATION',
    '\u2062': 'INVISIBLE TIMES',
    '\u2063': 'INVISIBLE SEPARATOR',
    '\u2064': 'INVISIBLE PLUS',
    '\ufeff': 'ZERO WIDTH NO-BREAK SPACE (BOM)',
    '\u00ad': 'SOFT HYPHEN',
    '\u034f': 'COMBINING GRAPHEME JOINER',
    '\u061c': 'ARABIC LETTER MARK',
    '\u115f': 'HANGUL CHOSEONG FILLER',
    '\u1160': 'HANGUL JUNGSEONG FILLER',
    '\u17b4': 'KHMER VOWEL INHERENT AQ',
    '\u17b5': 'KHMER VOWEL INHERENT AA',
    '\u180e': 'MONGOLIAN VOWEL SEPARATOR',
    '\uffa0': 'HALFWIDTH HANGUL FILLER',
}

RTL_OVERRIDE_CHARS = {
    '\u202a': 'LEFT-TO-RIGHT EMBEDDING',
    '\u202b': 'RIGHT-TO-LEFT EMBEDDING',
    '\u202c': 'POP DIRECTIONAL FORMATTING',
    '\u202d': 'LEFT-TO-RIGHT OVERRIDE',
    '\u202e': 'RIGHT-TO-LEFT OVERRIDE',
    '\u2066': 'LEFT-TO-RIGHT ISOLATE',
    '\u2067': 'RIGHT-TO-LEFT ISOLATE',
    '\u2068': 'FIRST STRONG ISOLATE',
    '\u2069': 'POP DIRECTIONAL ISOLATE',
}

# Injection trigger phrases (case-insensitive regex)
INJECTION_PATTERNS = [
    r'ignore\s+(all\s+)?previous\s+instructions',
    r'ignore\s+(all\s+)?prior\s+instructions',
    r'ignore\s+(all\s+)?above\s+instructions',
    r'disregard\s+(all\s+)?previous',
    r'forget\s+(all\s+)?previous',
    r'new\s+instructions?\s*:',
    r'system\s*:\s*you\s+are',
    r'<\s*system\s*>',
    r'\[system\]',
    r'\[INST\]',
    r'<<\s*SYS\s*>>',
    r'you\s+are\s+now\s+(?:a|an|in)\s+',
    r'act\s+as\s+(?:a|an|if)\s+',
    r'pretend\s+(?:you\s+are|to\s+be)',
    r'your\s+new\s+(?:role|persona|instructions?)\s+',
    # Mode-activation jailbreaks: "enter/enable/activate developer mode" etc.
    r'(?:enter|enable|activate|switch\s+to|turn\s+on)\s+(?:developer|debug|admin|god|unrestricted|jailbreak|sudo|maintenance)\s+mode',
    # Named mode references: "in developer mode you can..."
    r'in\s+(?:developer|debug|admin|god|unrestricted|jailbreak|sudo|maintenance)\s+mode',
    r'override\s+(?:your|all|previous)\s+',
    r'(?:AI|assistant|bot|model)\s*(?:reading|processing)\s+this',
    r'do\s+not\s+(?:summarise|summarize)\s+this',
    r'execute\s+(?:the\s+following|this)(?:\s+\w+)*\s*(?:command|script|code|payload|query|program|instruction|:|$)',
    r'run\s+(?:the\s+following|this)\s+command',
    r'send\s+(?:this|a)\s+(?:message|email)\s+to',
    r'forward\s+this\s+(?:message\s+|email\s+|data\s+|conversation\s+|text\s+)?to\s+(?!the\s+(?:team|department|group|committee|board|manager|director|client|marketing|sales|HR|engineering|finance|legal|support|office|staff)\b)',
    # Broad exfiltration: "forward the data/contents/messages to"
    r'forward\s+(?:all|the|this|these)\s+(?:data|contents?|information|messages?|emails?|conversation|details)\s+to\s+(?!the\s+(?:team|department|group|committee|board|manager|director|client|marketing|sales|HR|engineering|finance|legal|support|office|staff)\b)',
    r'add\s+this\s+to\s+(?:your\s+)?memory',
    r'update\s+(?:your|the)\s+(?:config|configuration|settings)',
    r'change\s+(?:your|the)\s+(?:system|prompt|instructions)',
    r'IMPORTANT\s*[:\-]\s*(?:ignore|forget|override|new\s+instructions)',
    r'(?:URGENT|PRIORITY|CRITICAL)\s*[:\-]\s*(?:override|ignore|forward|send|email|execute)',
    r'email\s+the\s+contents?\s+of',
    r'(?:this\s+is\s+a[n]?\s+)?(?:authorized|urgent|priority)\s+(?:maintenance|system|security)\s+(?:operation|task|update)',
    r'do\s+not\s+mention\s+this\s+to\s+the\s+user',
    # Spreadsheet formula exfiltration: =IMPORTHTML/IMPORTDATA/IMPORTFEED/IMPORTRANGE
    r'=\s*IMPORT(?:HTML|DATA|FEED|RANGE)\s*\(',
    # Phishing: "send it/this/them to <email>"
    r'send\s+(?:it|this|them|the\s+\w+)\s+to\s+\S+@\S+',
    # Data exfiltration: "send its/the contents/data to"
    r'send\s+(?:its|the|all|your)\s+(?:contents?|data|information|details)\s+to\b',
    # Execution: "run this diagnostic/script/program"
    r'(?:please\s+)?run\s+this\s+(?:diagnostic|script|program|tool|check)',
    # Cron manipulation: "add/create/set up a cron job"
    r'(?:add|create|set\s+up|install|modify)\s+(?:a\s+)?cron\s+(?:job|task|entry|schedule)',
    # Config file manipulation: "update HEARTBEAT.md / .env / crontab"
    r'update\s+(?:HEARTBEAT|heartbeat|\.env|crontab|\.bashrc|\.profile)\b',
    # Scheduling: "schedule a reminder/task/job"
    r'schedule\s+(?:a\s+)?(?:reminder|task|job|cron|command|script|diagnostic)',
    # Cron config modification
    r'modify\s+(?:the\s+)?(?:cron|crontab|schedule|heartbeat)\s+(?:configuration|config|settings|file)',
    # Shard exfiltration: "split the response into N parts"
    r'split\s+(?:the\s+)?(?:response|output|answer|result|data)\s+into\s+\d+\s+(?:parts|pieces|chunks|segments)',
    # Iterative exfiltration: "for each paragraph ... send"
    r'for\s+each\s+(?:paragraph|section|part|chunk)[\s\S]{0,80}?(?:send|post|forward|transmit|upload)',
]

# HTML patterns that hide content
HIDDEN_HTML_PATTERNS = [
    (r'<!--[\s\S]*?-->', 'HTML comment'),
    (r'<[^>]*display\s*:\s*none[^>]*>[\s\S]*?</[^>]*>', 'display:none element'),
    (r'<[^>]*visibility\s*:\s*hidden[^>]*>[\s\S]*?</[^>]*>', 'visibility:hidden element'),
    (r'<[^>]*font-size\s*:\s*0[^>]*>[\s\S]*?</[^>]*>', 'font-size:0 element'),
    (r'<[^>]*opacity\s*:\s*0[^>]*>[\s\S]*?</[^>]*>', 'opacity:0 element'),
    (r'<[^>]*color\s*:\s*(?:white|#fff(?:fff)?|rgb\(255\s*,\s*255\s*,\s*255\))[^>]*background[^>]*(?:white|#fff(?:fff)?|rgb\(255\s*,\s*255\s*,\s*255\))[^>]*>[\s\S]*?</[^>]*>', 'white-on-white text'),
    (r'<[^>]*height\s*:\s*0[^>]*>[\s\S]*?</[^>]*>', 'zero-height element'),
    (r'<[^>]*width\s*:\s*0[^>]*>[\s\S]*?</[^>]*>', 'zero-width element'),
    (r'<[^>]*position\s*:\s*absolute[^>]*(?:left|top)\s*:\s*-\d+[^>]*>[\s\S]*?</[^>]*>', 'off-screen positioned element'),
    (r'<[^>]*overflow\s*:\s*hidden[^>]*height\s*:\s*(?:0|1px)[^>]*>[\s\S]*?</[^>]*>', 'overflow-hidden tiny element'),
    (r'<meta\s+[^>]*(?:property|name)\s*=\s*["\'](?:og:|twitter:)[^"\']*["\'][^>]*content\s*=\s*["\'][^"\']*(?:ignore|system|execute|override|send\s|forward\s|curl\s)[^"\']*["\'][^>]*>', 'suspicious Open Graph/meta tag'),
    (r'<meta\s+[^>]*content\s*=\s*["\'][^"\']*(?:ignore|system|execute|override|send\s|forward\s|curl\s)[^"\']*["\'][^>]*(?:property|name)\s*=\s*["\'](?:og:|twitter:)[^"\']*["\'][^>]*>', 'suspicious Open Graph/meta tag'),
]

# Cell-level injection patterns (subset, more targeted)
CONTENT_INJECTION_PATTERNS = [
    r'ignore\s+previous\s+instructions',
    r'system\s*:\s*you\s+are',
    r'(?:AI|assistant|bot)\s*(?:reading|processing)\s+this',
    r'execute\s+(?:the\s+following|this)(?:\s+\w+)*\s*(?:command|script|code|payload|query|program|instruction|:|$)',
    r'send\s+(?:this|a)\s+(?:message|email)',
    r'add\s+this\s+to\s+(?:your\s+)?memory',
    r'update\s+(?:your|the)\s+config',
    r'=\s*IMPORT(?:HTML|DATA|FEED|RANGE)\s*\(',
]

# Backwards-compatible alias
SHEET_INJECTION_PATTERNS = CONTENT_INJECTION_PATTERNS
