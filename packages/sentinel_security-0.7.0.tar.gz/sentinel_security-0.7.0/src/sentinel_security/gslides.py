"""
Google Slides hidden content scanner for the sentinel-security package.
Scans presentations for hidden text, injection patterns, and other threats.
"""

import logging
import re
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

from .google_auth import _load_credentials
from .patterns import INJECTION_PATTERNS
from .sanitiser.scorer import risk_level
from .utils import calculate_threat_risk_score


def _extract_text_from_element(element: Dict[str, Any]) -> str:
    """Extract text from a page element."""
    text = ""
    
    # Check for shape with text
    if 'shape' in element:
        shape = element['shape']
        if 'text' in shape and 'textElements' in shape['text']:
            for text_elem in shape['text']['textElements']:
                if 'textRun' in text_elem:
                    text_run = text_elem['textRun']
                    if 'content' in text_run:
                        text += text_run['content']
    
    # Check for table
    elif 'table' in element:
        table = element['table']
        if 'tableRows' in table:
            for row in table['tableRows']:
                if 'tableCells' in row:
                    for cell in row['tableCells']:
                        if 'text' in cell and 'textElements' in cell['text']:
                            for text_elem in cell['text']['textElements']:
                                if 'textRun' in text_elem:
                                    text_run = text_elem['textRun']
                                    if 'content' in text_run:
                                        text += text_run['content']
    
    # Check for image (alt text)
    elif 'image' in element:
        if 'title' in element:
            text += element.get('title', '')
        if 'description' in element:
            text += element.get('description', '')
    
    # Check for video (alt text)
    elif 'video' in element:
        if 'title' in element:
            text += element.get('title', '')
        if 'description' in element:
            text += element.get('description', '')
    
    return text.strip()


def _check_injection_patterns(text: str) -> List[Dict[str, Any]]:
    """Check text for injection patterns."""
    threats = []
    if not text:
        return threats
    
    for pattern in INJECTION_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            threats.append({
                'type': 'injection_pattern',
                'severity': 'CRITICAL',
                'detail': f'Found injection pattern in text: {pattern}',
                'text_snippet': text[:100] + '...' if len(text) > 100 else text
            })
            break  # Only report first match
    
    return threats


def _check_tiny_text(text_style: Dict[str, Any]) -> bool:
    """Check if text is too small to read."""
    if 'fontSize' in text_style and 'magnitude' in text_style['fontSize']:
        return text_style['fontSize']['magnitude'] < 2  # Less than 2pt
    return False


def _check_suspicious_link(link: Dict[str, Any]) -> bool:
    """Check if a link is suspicious."""
    url = link.get('url', '').lower()
    if not url:
        return False
    
    suspicious_prefixes = ['javascript:', 'data:', 'vbscript:', 'file:']
    for prefix in suspicious_prefixes:
        if url.startswith(prefix):
            return True
    
    # Check for very long URLs (potential data exfiltration)
    if len(url) > 500:
        return True
    
    return False


def _check_off_canvas(element: Dict[str, Any], page_width: float, page_height: float) -> bool:
    """Check if element is completely outside page bounds."""
    transform = element.get('transform', {})
    translate_x = transform.get('translateX', 0)
    translate_y = transform.get('translateY', 0)
    
    size = element.get('size', {})
    elem_width = size.get('width', {}).get('magnitude', 0)
    elem_height = size.get('height', {}).get('magnitude', 0)
    
    # Check if element is completely outside page
    if (translate_x + elem_width < 0 or translate_x > page_width or
        translate_y + elem_height < 0 or translate_y > page_height):
        return True
    
    return False


def scan_google_slides(presentation_id: str, credentials=None, credentials_path: Optional[str] = None) -> dict:
    """
    Scan a Google Slides presentation for hidden content and threats.
    
    Args:
        presentation_id: Google Slides presentation ID
        credentials: Optional pre-loaded Google OAuth2 credentials
        credentials_path: Optional path to credentials JSON file
    
    Returns:
        Dict with scan results including threats and risk assessment
    """
    logger.debug("scan_google_slides: start presentation_id=%s", presentation_id)
    threats = []
    
    # Load credentials if not provided
    if credentials is None:
        credentials = _load_credentials(credentials_path)
    
    # Build Google Slides API service
    try:
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Google API client required. Install with: "
            "pip install sentinel-security[google]"
        )

    service = build('slides', 'v1', credentials=credentials)
    
    # Get presentation
    presentation = service.presentations().get(presentationId=presentation_id).execute()
    
    # Extract basic info
    title = presentation.get('title', 'Untitled Presentation')
    slides = presentation.get('slides', [])
    slide_count = len(slides)
    
    # Get page size for off-canvas checks
    page_size = presentation.get('pageSize', {})
    page_width = page_size.get('width', {}).get('magnitude', 0)
    page_height = page_size.get('height', {}).get('magnitude', 0)
    
    # Scan each slide
    for slide_idx, slide in enumerate(slides):
        slide_id = slide.get('objectId', f'slide_{slide_idx}')
        
        # 1. Check for hidden/skipped slides
        slide_props = slide.get('slideProperties', {})
        if slide_props.get('isSkipped', False):
            threats.append({
                'type': 'hidden_slide',
                'severity': 'MEDIUM',
                'detail': f'Slide {slide_idx + 1} is marked as skipped/hidden',
                'slide_index': slide_idx,
                'slide_id': slide_id
            })
        
        # 2. Check speaker notes
        notes_page = slide_props.get('notesPage', {})
        notes_elements = notes_page.get('pageElements', [])
        for elem_idx, element in enumerate(notes_elements):
            text = _extract_text_from_element(element)
            if text:
                # Check for injection patterns in notes
                notes_threats = _check_injection_patterns(text)
                threats.extend(notes_threats)
                
                # Check alt text in notes
                alt_text = element.get('title', '') + element.get('description', '')
                if alt_text:
                    alt_threats = _check_injection_patterns(alt_text)
                    threats.extend(alt_threats)
        
        # 3. Scan slide elements
        slide_elements = slide.get('pageElements', [])
        for elem_idx, element in enumerate(slide_elements):
            element_id = element.get('objectId', f'element_{elem_idx}')
            
            # Check for off-canvas elements
            if _check_off_canvas(element, page_width, page_height):
                threats.append({
                    'type': 'off_canvas_element',
                    'severity': 'MEDIUM',
                    'detail': f'Element positioned completely outside slide bounds',
                    'slide_index': slide_idx,
                    'element_id': element_id
                })
            
            # Extract and check text
            text = _extract_text_from_element(element)
            if text:
                # Check for injection patterns
                text_threats = _check_injection_patterns(text)
                threats.extend(text_threats)
                
                # Check for tiny text (need to examine text runs)
                if 'shape' in element:
                    shape = element['shape']
                    if 'text' in shape and 'textElements' in shape['text']:
                        for text_elem in shape['text']['textElements']:
                            if 'textRun' in text_elem:
                                text_run = text_elem['textRun']
                                text_style = text_run.get('style', {})
                                if _check_tiny_text(text_style):
                                    threats.append({
                                        'type': 'tiny_text',
                                        'severity': 'HIGH',
                                        'detail': f'Text with font size < 2pt found',
                                        'slide_index': slide_idx,
                                        'element_id': element_id,
                                        'text_snippet': text[:50] + '...' if len(text) > 50 else text
                                    })
                
                # Check for suspicious links
                if 'shape' in element:
                    shape = element['shape']
                    if 'text' in shape and 'textElements' in shape['text']:
                        for text_elem in shape['text']['textElements']:
                            if 'textRun' in text_elem:
                                text_run = text_elem['textRun']
                                style = text_run.get('style', {})
                                link = style.get('link', {})
                                if _check_suspicious_link(link):
                                    threats.append({
                                        'type': 'suspicious_link',
                                        'severity': 'HIGH',
                                        'detail': f'Suspicious link found in text',
                                        'slide_index': slide_idx,
                                        'element_id': element_id,
                                        'url': link.get('url', '')[:100]
                                    })
            
            # Check alt text
            alt_text = element.get('title', '') + element.get('description', '')
            if alt_text:
                alt_threats = _check_injection_patterns(alt_text)
                threats.extend(alt_threats)
    
    logger.debug("scan_google_slides: end presentation_id=%s threats=%d", presentation_id, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_google_slides: threats detected count=%d types=%s", len(threats), types)
    # Calculate risk
    risk_score = calculate_threat_risk_score(threats)
    _risk_level = risk_level(risk_score)
    
    return {
        'info': {
            'presentation_id': presentation_id,
            'title': title,
            'slide_count': slide_count
        },
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': _risk_level
    }
