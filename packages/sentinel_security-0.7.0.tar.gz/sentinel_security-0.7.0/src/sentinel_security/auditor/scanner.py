"""
Prompt scanner for security hardening rules.

Port of the JavaScript scanner from prompt-auditor/scanner.js.
"""

import re
import json
from pathlib import Path


def _load_rules():
    """Load rules from rules.json file."""
    
    rules_path = Path(__file__).parent / "rules.json"
    with open(rules_path, 'r', encoding='utf-8') as f:
        return json.load(f)


RULES = _load_rules()


def scan(prompt_text: str):
    """
    Scan a system prompt against all hardening rules.

    Args:
        prompt_text: The system prompt to audit.

    Returns:
        List of scan result objects, one per rule.

    Raises:
        TypeError: If prompt_text is not a string.
    """
    if not isinstance(prompt_text, str):
        raise TypeError('prompt_text must be a string')

    normalised = prompt_text.lower()
    results = []

    for rule in RULES:
        matched_patterns = []
        matched_keywords = []

        # Test each positive regex pattern (case-insensitive)
        for pattern in rule['patterns']:
            try:
                if re.search(pattern, prompt_text, re.IGNORECASE):
                    matched_patterns.append(pattern)
            except re.error:
                # Skip invalid regex patterns
                continue

        # Count semantic keyword hits
        for keyword in rule['keywords']:
            if keyword.lower() in normalised:
                matched_keywords.append(keyword)

        # Determine status
        if (len(matched_patterns) >= 1 and len(matched_keywords) >= 2) or len(matched_patterns) >= 2 or len(matched_keywords) >= 4:
            status = 'pass'
        elif len(matched_patterns) >= 1 or len(matched_keywords) >= 2:
            status = 'partial'
        else:
            status = 'fail'

        results.append({
            'rule_id': rule['id'],
            'name': rule['name'],
            'severity': rule['severity'],
            'status': status,
            'matched_patterns': matched_patterns,
            'matched_keywords': matched_keywords,
            'fix_template_id': rule['fixTemplateId'],
        })

    return results
