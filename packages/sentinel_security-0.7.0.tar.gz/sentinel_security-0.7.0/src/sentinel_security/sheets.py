"""
Google Sheets hidden content scanner.

Checks a spreadsheet for hidden rows, columns, sheets, and suspicious content
that could be used for prompt injection via AI agents reading sheet data.

Requires: pip install sentinel-security[sheets]
"""

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)

from .google_auth import _load_credentials
from .patterns import CONTENT_INJECTION_PATTERNS

from .sanitiser.scorer import risk_level
from .utils import calculate_threat_risk_score

def scan_sheets(spreadsheet_id: str, credentials=None, credentials_path: Optional[str] = None) -> dict:
    """
    Scan a Google Spreadsheet for hidden content and injection patterns.

    Args:
        spreadsheet_id: The Google Sheets spreadsheet ID.
        credentials: A google.oauth2.credentials.Credentials object.
                     If not provided, will attempt to load from credentials_path.
        credentials_path: Path to a JSON credentials file. Used only if
                         credentials is None.

    Returns:
        dict with keys:
            info (dict): Spreadsheet metadata.
            threats (list): Detected threats with type, severity, detail.
            threat_count (int): Number of threats found.
            risk_score (int): 0-10 severity score.
            risk_level (str): CLEAN / LOW / MEDIUM / HIGH / CRITICAL.

    Raises:
        ImportError: If google-api-python-client is not installed.
    """
    try:
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Google API client required. Install with: "
            "pip install sentinel-security[sheets]"
        )

    if credentials is None:
        credentials = _load_credentials(credentials_path)

    service = build('sheets', 'v4', credentials=credentials)
    spreadsheet = service.spreadsheets().get(
        spreadsheetId=spreadsheet_id,
        includeGridData=False,
    ).execute()

    logger.debug("scan_sheets: start spreadsheet_id=%s", spreadsheet_id)
    threats = []
    info = {
        'spreadsheet_id': spreadsheet_id,
        'title': spreadsheet.get('properties', {}).get('title', 'Unknown'),
        'sheet_count': len(spreadsheet.get('sheets', [])),
    }

    for sheet in spreadsheet.get('sheets', []):
        props = sheet.get('properties', {})
        sheet_name = props.get('title', 'Unknown')
        sheet_id = props.get('sheetId')

        if props.get('hidden', False):
            threats.append({
                'type': 'hidden_sheet',
                'sheet_name': sheet_name,
                'sheet_id': sheet_id,
                'severity': 'HIGH',
                'detail': f'Sheet "{sheet_name}" is hidden. May contain injected instructions.',
            })

        try:
            detail = service.spreadsheets().get(
                spreadsheetId=spreadsheet_id,
                includeGridData=True,
                ranges=[f"'{sheet_name}'"],
            ).execute()

            for s in detail.get('sheets', []):
                for grid_data in s.get('data', []):
                    _scan_row_col_metadata(grid_data, sheet_name, threats)
                    _scan_cell_content(grid_data, sheet_name, threats)

        except Exception as e:
            threats.append({
                'type': 'scan_error',
                'sheet_name': sheet_name,
                'severity': 'LOW',
                'detail': f'Could not scan sheet detail: {str(e)}',
            })

    logger.debug("scan_sheets: end spreadsheet_id=%s threats=%d", spreadsheet_id, len(threats))
    if threats:
        types = list({t.get("type") for t in threats})
        logger.info("scan_sheets: threats detected count=%d types=%s", len(threats), types)
    risk_score = calculate_threat_risk_score(threats)

    return {
        'info': info,
        'threats': threats,
        'threat_count': len(threats),
        'risk_score': risk_score,
        'risk_level': risk_level(risk_score),
    }



def _scan_row_col_metadata(grid_data: dict, sheet_name: str, threats: list):
    """Check for hidden rows and columns."""
    for i, row_meta in enumerate(grid_data.get('rowMetadata', [])):
        if row_meta.get('hiddenByUser', False) or row_meta.get('hiddenByFilter', False):
            threats.append({
                'type': 'hidden_row',
                'sheet_name': sheet_name,
                'row': i + 1,
                'severity': 'MEDIUM',
                'detail': f'Row {i + 1} in "{sheet_name}" is hidden.',
            })

    for i, col_meta in enumerate(grid_data.get('columnMetadata', [])):
        if col_meta.get('hiddenByUser', False) or col_meta.get('hiddenByFilter', False):
            threats.append({
                'type': 'hidden_column',
                'sheet_name': sheet_name,
                'column': i + 1,
                'severity': 'MEDIUM',
                'detail': f'Column {i + 1} in "{sheet_name}" is hidden.',
            })


def _scan_cell_content(grid_data: dict, sheet_name: str, threats: list):
    """Scan cell values for injection patterns and hidden text formatting."""
    for row_idx, row_data in enumerate(grid_data.get('rowData', [])):
        for col_idx, cell in enumerate(row_data.get('values', [])):
            value = cell.get('formattedValue', '') or ''
            cell_ref = f'R{row_idx + 1}C{col_idx + 1}'

            # Injection patterns
            for pattern in CONTENT_INJECTION_PATTERNS:
                if re.search(pattern, value, re.IGNORECASE):
                    threats.append({
                        'type': 'injection_in_cell',
                        'sheet_name': sheet_name,
                        'cell': cell_ref,
                        'value_preview': value[:100],
                        'severity': 'CRITICAL',
                        'detail': 'Injection pattern found in cell.',
                    })
                    break

            if not value.strip():
                continue

            # Hidden text (colour matches background)
            fmt = cell.get('effectiveFormat', {})
            text_fmt = fmt.get('textFormat', {})
            bg_color = fmt.get('backgroundColor', {})
            fg_color = text_fmt.get('foregroundColorStyle', {}).get('rgbColor', {})

            bg_r = bg_color.get('red', 1)
            bg_g = bg_color.get('green', 1)
            bg_b = bg_color.get('blue', 1)
            fg_r = fg_color.get('red', 0)
            fg_g = fg_color.get('green', 0)
            fg_b = fg_color.get('blue', 0)

            if (abs(bg_r - fg_r) < 0.05 and
                abs(bg_g - fg_g) < 0.05 and
                abs(bg_b - fg_b) < 0.05):
                threats.append({
                    'type': 'hidden_text_color',
                    'sheet_name': sheet_name,
                    'cell': cell_ref,
                    'value_preview': value[:100],
                    'severity': 'HIGH',
                    'detail': 'Text colour matches background (hidden text).',
                })

            # Tiny font
            font_size = text_fmt.get('fontSize', 10)
            if font_size and font_size < 2:
                threats.append({
                    'type': 'tiny_font',
                    'sheet_name': sheet_name,
                    'cell': cell_ref,
                    'font_size': font_size,
                    'severity': 'HIGH',
                    'detail': f'Extremely small font ({font_size}pt) hiding text.',
                })
