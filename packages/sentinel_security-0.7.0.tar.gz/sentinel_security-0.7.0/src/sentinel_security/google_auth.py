"""Shared Google OAuth2 credential loading for sentinel-security scanners."""

import json
import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)


def _load_credentials(credentials_path: Optional[str] = None):
    """Load Google OAuth2 credentials from a JSON file.

    Args:
        credentials_path: Path to a JSON credentials file. Defaults to
            ~/.google_workspace_mcp/credentials/default.json.

    Returns:
        google.oauth2.credentials.Credentials instance.

    Raises:
        FileNotFoundError: If the credentials file does not exist.
    """
    if credentials_path is None:
        credentials_path = os.path.expanduser(
            '~/.google_workspace_mcp/credentials/default.json'
        )

    if not os.path.exists(credentials_path):
        raise FileNotFoundError(
            f'Credentials not found at {credentials_path}. '
            'Pass credentials directly or set credentials_path.'
        )

    logger.debug("Loading Google credentials from %s", credentials_path)

    with open(credentials_path) as f:
        cred_data = json.load(f)

    from google.oauth2.credentials import Credentials
    return Credentials(
        token=cred_data.get('access_token'),
        refresh_token=cred_data.get('refresh_token'),
        token_uri=cred_data.get('token_uri', 'https://oauth2.googleapis.com/token'),
        client_id=cred_data.get('client_id'),
        client_secret=cred_data.get('client_secret'),
    )
