# src/dworshak_prompt/multiplexer.py
from __future__ import annotations
import pyhabitat as ph
from enum import Enum
from typing import Set, Any
import threading
import traceback
import sys
import os
    
from .gui_prompt import get_tkinter_hint
if ph.tkinter_is_available():
    from .gui_prompt import gui_get_input
else:
    gui_get_input = None
from .web_prompt import browser_get_input
from .keyboard_interrupt import PromptCancelled
from .server import stop_prompt_server
from .prompt_manager_web import PromptManagerWeb
from .helpers import PromptMode, resolve_str_to_list, resolve_str_to_set
from .environment import has_real_tty, get_console_provider, is_likely_ci_or_non_interactive, interactive_terminal_is_available

class DworshakPrompt: 
    def __init__(self,
        config_path: str | None = None,
        secret_path: str | None = None,
        default_priority_interface: list[PromptMode] | None = None,
        default_avoid_interface: set[PromptMode] | None =None,
    ):
        self.config_path = config_path
        self.secret_path = secret_path
        self.default_priority_interface = default_priority_interface
        self.default_avoid_interface = default_avoid_interface

    def ask(
        self,
        message: str = "Enter value",
        suggestion: str | None = None,
        default: Any | None = None,
        hide_input: bool = False, 
        priority_interface: list[PromptMode] | None = None,
        avoid_interface: set[PromptMode] | None = None,
        interrupt_event: threading.Event | None = None,
        debug: bool = False, 
        verbose: bool = False, 
        timeout: int | float | None = None,
        exit_on_interrupt: bool = False,
    ) -> str | None:
        from .logging_setup import setup_logging
        logger = setup_logging(verbose=verbose, debug=debug, initial=True)

        if priority_interface is None:
            priority_interface = self.default_priority_interface
        if avoid_interface is None:
            avoid_interface = self.default_avoid_interface

        # Use existing interrupt_event or create a local one for this call
        if interrupt_event is None:
            interrupt_event = threading.Event()

        '''

        # CI/Headless Detection
        # If we aren't forceing TTY and aren't on a system that can spawn a GUI/Web window,
        # return the default immediately to mitigate a potential Dworshak failure mode in CI.
        if is_likely_ci_or_non_interactive() and os.environ.get("DWORSHAK_FORCE_INTERACTIVE_TTY") != "1":
            logger.debug("CI environment. Returning default to avoid blocking.")
            return default
        
        # TTY detection
        # If we aren't in a TTY.
        # return the default immediately to mitigate a potential Dworshak failure mode in CI.
        # use DWORSHAK_FORCE_INTERACTIVE_TTY=1 when wrapping prompt calls
        # like: DWORSHAK_FORCE_INTERACTIVE_TTY=1 VAR=$(dworshak-prompt ask)
        if not has_real_tty():
            logger.debug("No interactive terminal; checking GUI/Web availability.")
            

        #if not interactive_terminal_is_available() or \
        if not has_real_tty() and \
        not ph.tkinter_is_available() or \
        not ph.web_browser_is_available(): # Hypothetical pyhabitat check
            logger.debug("Non-interactive environment detected. Default value assigned.")
            return default
        '''
        
        # Force interactive check
        logger.debug(f"{os.environ.get("DWORSHAK_FORCE_INTERACTIVE_TTY")=}")
        forced_tty = os.environ.get("DWORSHAK_FORCE_INTERACTIVE_TTY") == "1"
        logger.debug(f"{forced_tty=}")
        logger.debug(f"{os.path.exists("/dev/tty")=}")

        # Early Exit check
        if not forced_tty:
            if is_likely_ci_or_non_interactive():
                logger.debug("CI environment. Returning default.")
                return default

            # If NO path to user exists at all
            if not (interactive_terminal_is_available() or 
                    ph.tkinter_is_available() or 
                    ph.web_browser_is_available() or 
                    os.path.exists("/dev/tty")):
                logger.debug("Non-interactive environment detected.")
                return default

        avoid_interface = avoid_interface or set()
        avoid_interface = resolve_str_to_set(avoid_interface)
        priority_interface = resolve_str_to_list(priority_interface)
         
        if ph.on_wsl():
            raw_val = os.getenv("DWORSHAK_TRY_TKINTER_ON_WSL")
            logger.debug(f"raw DWORSHAK_TRY_TKINTER_ON_WSL = {raw_val!r}")
            
            # Convert common truthy strings to boolean
            if raw_val is not None:
                DWORSHAK_TRY_TKINTER_ON_WSL = raw_val.lower() in ('1', 'true', 'yes', 'on', 'enable')
            else:
                DWORSHAK_TRY_TKINTER_ON_WSL = False
            
            logger.debug(f"DWORSHAK_TRY_TKINTER_ON_WSL interpreted as {DWORSHAK_TRY_TKINTER_ON_WSL}")
            
            if not DWORSHAK_TRY_TKINTER_ON_WSL:
                logger.warning(f"PromptMode.GUI avoided for WSL; to try it, set `export DWORSHAK_TRY_TKINTER_ON_WSL=1` ")
                avoid_interface.add(PromptMode.GUI)
                

        default_order = [PromptMode.CONSOLE, PromptMode.GUI, PromptMode.WEB]
        if priority_interface:
            # User choice first, followed by everything else as a safety net
            effective_priority_interface = priority_interface + [m for m in default_order if m not in priority_interface]
        else:
            effective_priority_interface = default_order

        if timeout:
            # A background timer to fire the interrupt signal
            timer = threading.Timer(timeout, lambda: interrupt_event.set())
            timer.start()

        for interface_mode in effective_priority_interface:
            if interface_mode in avoid_interface:
                logger.debug(f"Skipping {interface_mode} (avoided)")
                continue

            logger.debug(f"\n=== Interface Mode: {interface_mode} ===")
            
            try:
                if interface_mode == PromptMode.CONSOLE:
                    # if not has_real_tty():
                    if not interactive_terminal_is_available() and not forced_tty:
                        logger.debug(f"{interface_mode} skipped: No interactive terminal.")
                        continue

                    console_get_input = get_console_provider(debug=debug)
                    val = console_get_input(message = message, suggestion = suggestion, hide_input = hide_input)
                    log_val = "'********'" if hide_input else repr(val)
                    logger.debug(f"SUCCESS: {interface_mode} returned: {log_val}")
                    return val

                elif interface_mode == PromptMode.GUI:
                    #logger.warning(f"ph.tkinter_is_available() = {ph.tkinter_is_available()}")
                    if not ph.tkinter_is_available():
                        logger.warning(f"{interface_mode} skipped: Tkinter unavailable.")
                        logger.debug(get_tkinter_hint())  
                        continue

                        
                    val = gui_get_input(message = message, suggestion = suggestion, hide_input = hide_input)
                    if val is not None:
                        log_val = "'********'" if hide_input else repr(val)
                        logger.debug(f"SUCCESS: {interface_mode} returned: {log_val}")
                        return val
                    
                    logger.debug(f"GUI cancelled. Raising PromptCancelled.")
                    raise PromptCancelled()

                elif interface_mode == PromptMode.WEB:
                    local_manager = PromptManagerWeb()
                    try:
                        val = browser_get_input(
                            message, 
                            suggestion, 
                            hide_input, 
                            manager = local_manager, 
                            stop_event = interrupt_event
                            )
                        if val is not None:
                            log_val = "'********'" if hide_input else repr(val)
                            logger.debug(f"SUCCESS: {interface_mode} returned: {log_val}")
                            return val
                        logger.debug(f"WEB returned None. Raising PromptCancelled.")
                        raise PromptCancelled()
                    finally:
                        stop_prompt_server()

            
            except BaseException as e:
                import logging
                exc_type = type(e)
                exc_name = exc_type.__name__
                exc_module = exc_type.__module__
                
                logger.debug(f"!!! EXCEPTION TRIGGERED !!!")
                logger.debug(f"Class Name: {exc_name}")
                logger.debug(f"Full Path:  {exc_module}.{exc_name}")
                logger.debug(f"Exception Type: {exc_name}")
                # MASKING LOGIC to prevent secret value leaks
                if hide_input:
                    logger.debug("Repr:       <Masked due to hide_input=True>")
                    logger.debug("Args:       <Masked>")
                else:
                    logger.debug(f"Repr:       {repr(e)}")
                    logger.debug(f"Args:       {e.args}")

                stop_signals = {"KeyboardInterrupt", "Abort", "SystemExit", "EOFError", "PromptCancelled"}
                
                if exc_name in stop_signals or isinstance(e, (KeyboardInterrupt, PromptCancelled)):
                    logger.debug(f">>> MATCHED STOP SIGNAL: {exc_name}. EXITING FUNCTION.")
                    if interrupt_event:
                        interrupt_event.set()
                    if exit_on_interrupt:
                        # We use sys.stderr to ensure the user sees why the program died
                        #logger.debug(f"User Interrupted. Exiting. exit_on_interrupt={exit_on_interrupt}")
                        print("\n[!] Operation cancelled by user.", file=sys.stderr)
                        sys.exit(130) # Standard SIGINT exit code
                    else:
                        return None

                # For technical failures, we log the traceback at DEBUG level
                logger.debug(f">>> TECHNICAL FAILURE detected. Investigating traceback...")
                if logger.isEnabledFor(logging.DEBUG):
                    traceback.print_exc(file=sys.stdout)
                
                logger.debug(f"Continuing to fallback interface mode...")
                continue

            logger.debug("All interface modes exhausted.")
            raise RuntimeError("No input method succeeded.")

def dworshak_ask(
    message: str = "Enter value",
    suggestion: str | None = None,
    default: Any | None = None,
    priority_interface: list[PromptMode] | None = None,
    avoid_interface: set[PromptMode] | None = None,
    exit_on_interrupt: bool = False,
    **kwargs: Any
) -> str | None:
    """
    Convenience function to prompt the user for input using the Dworshak Multiplexer.
    Automatically handles fallback between Console, GUI, and Web interface modes.
    """
    return DworshakPrompt().ask(
        message=message,
        suggestion=suggestion,
        default=default,
        priority_interface=priority_interface,
        avoid_interface=avoid_interface,
        exit_on_interrupt = exit_on_interrupt,
        **kwargs 
    )

# --- Demo entry ---

def main():
    DworshakPrompt().ask(
        "What is your name?",
        suggestion="George",
        debug=True,
    )
