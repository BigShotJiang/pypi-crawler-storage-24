"""Main BioSimulagent client class."""
import asyncio
import logging
import os
import shutil
from pathlib import Path
from typing import Optional, Dict, Any

from ._internal.subprocess_manager import SubprocessManager
from ._internal.mcp_protocol import MCPProtocol
from .exceptions import ConnectionError, TimeoutError

logger = logging.getLogger(__name__)


class BioSimulagent:
    """Main client for bio-simulagent MCP backend.

    Usage:
        async with BioSimulagent.connect() as client:
            results = await client.literature.search("EGFR inhibitors")
    """

    def __init__(
        self,
        subprocess_manager: SubprocessManager,
        mcp_protocol: MCPProtocol,
    ):
        self._subprocess_manager = subprocess_manager
        self._mcp_protocol = mcp_protocol

        # Tool namespaces (will be initialized in subclasses)
        from .tools.literature import Literature
        from .tools.simulation import Simulation
        from .tools.design import Design
        from .tools.neural import Neural
        from .tools.learning import Learning
        from .workflows import WorkflowRunner

        self.literature = Literature(self)
        self.simulation = Simulation(self)
        self.design = Design(self)
        self.neural = Neural(self)
        self.learning = Learning(self)
        self.workflow = WorkflowRunner(self)

    @classmethod
    async def connect(
        cls,
        backend_path: str = "backend.main",
        python_executable: Optional[str] = None,
        timeout: int = 30,
    ) -> "BioSimulagent":
        """Connect to MCP backend.

        Args:
            backend_path: Python module path (default: "backend.main")
            python_executable: Path to Python interpreter (default: auto-detect)
            timeout: Connection timeout in seconds (default: 30)

        Returns:
            BioSimulagent: Connected client instance

        Raises:
            ConnectionError: If subprocess fails to start
            TimeoutError: If connection takes longer than timeout

        Example:
            >>> async with BioSimulagent.connect() as client:
            ...     result = await client.literature.search("EGFR inhibitors")
        """
        # Auto-detect Python executable (prefer .venv/bin/python3)
        if python_executable is None:
            python_executable = cls._detect_python()

        logger.info(f"Connecting to backend: {python_executable} -m {backend_path}")

        # Spawn subprocess
        subprocess_manager = SubprocessManager()
        process = await subprocess_manager.spawn(
            command=python_executable,
            args=["-m", backend_path],
            timeout=timeout,
        )

        # Initialize MCP protocol
        mcp_protocol = MCPProtocol(process)
        await mcp_protocol.initialize(timeout=timeout)

        return cls(subprocess_manager, mcp_protocol)

    async def _call_tool(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Internal method to call MCP tool.

        Args:
            name: Tool name (e.g., "literature.search")
            arguments: Tool arguments

        Returns:
            Dict: Tool result

        Raises:
            ToolExecutionError: If tool execution fails
            TimeoutError: If call times out
        """
        return await self._mcp_protocol.call_tool(name, arguments)

    async def _read_resource(self, uri: str) -> Dict[str, Any]:
        """Internal method to read MCP resource.

        Args:
            uri: Resource URI (e.g., "workflow://templates")

        Returns:
            Dict: Resource contents

        Raises:
            ConnectionError: If read fails
        """
        return await self._mcp_protocol.read_resource(uri)

    async def close(self):
        """Close connection and cleanup."""
        logger.info("Closing BioSimulagent client...")
        await self._mcp_protocol.close()
        await self._subprocess_manager.terminate()
        logger.info("BioSimulagent client closed")

    async def __aenter__(self) -> "BioSimulagent":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit with cleanup."""
        await self.close()

    @staticmethod
    def _detect_python() -> str:
        """Auto-detect Python executable (prefer .venv).

        Returns:
            str: Path to Python executable

        Priority:
            1. .venv/bin/python3 (project virtual environment)
            2. python3 (system)
            3. python (fallback)
        """
        # Check for .venv in current directory
        venv_python = Path(".venv/bin/python3")
        if venv_python.exists():
            logger.debug(f"Using .venv Python: {venv_python}")
            return str(venv_python)

        # Check for python3 in PATH
        python3 = shutil.which("python3")
        if python3:
            logger.debug(f"Using system Python3: {python3}")
            return python3

        # Fallback to python
        python = shutil.which("python")
        if python:
            logger.debug(f"Using system Python: {python}")
            return python

        raise ConnectionError("No Python executable found. Install Python 3.11+")

    def is_connected(self) -> bool:
        """Check if connected to backend.

        Returns:
            bool: True if connected and subprocess is alive
        """
        return self._subprocess_manager.is_alive()
