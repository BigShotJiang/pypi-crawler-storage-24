"""Learning and feedback tools for adaptive optimization."""
from typing import Optional, Dict, Any, TYPE_CHECKING

from .base import BaseTool
from ..types import (
    FeedbackResult,
    ExperimentResult,
    LearningStats,
    OptimizationResult,
    DashboardData,
    PerformanceData,
)

if TYPE_CHECKING:
    from ..client import BioSimulagent


class Learning(BaseTool):
    """Adaptive learning tools for feedback and optimization.

    Provides access to the learning system for submitting feedback,
    running optimization, and viewing performance dashboards.
    """

    tool_prefix = "learning"

    async def submit_feedback(
        self,
        molecule_name: str,
        smiles: str,
        workflow_type: str,
        action: str,
        predicted_score: Optional[float] = None,
        user_rating: Optional[int] = None,
        scenario: str = "default",
        notes: Optional[str] = None,
        **component_scores: float,
    ) -> FeedbackResult:
        """Submit user feedback for adaptive learning.

        Args:
            molecule_name: Name of the molecule
            smiles: SMILES notation
            workflow_type: 'ligand', 'literature', or 'cns'
            action: 'selected', 'rejected', or 'saved'
            predicted_score: Overall predicted score (0-100)
            user_rating: User rating (1-5)
            scenario: Scenario name (e.g., 'tourette')
            notes: Optional notes
            **component_scores: Component scores (drug_likeness_score, etc.)

        Returns:
            FeedbackResult with feedback_id and status

        Example:
            >>> result = await client.learning.submit_feedback(
            ...     molecule_name="TS-001",
            ...     smiles="CC(C)Nc1nc...",
            ...     workflow_type="cns",
            ...     action="selected",
            ...     user_rating=4,
            ...     scenario="tourette",
            ... )
            >>> print(f"Feedback ID: {result.feedback_id}")
        """
        self._validate_not_empty(molecule_name, "molecule_name")
        self._validate_not_empty(smiles, "smiles")

        arguments = {
            "molecule_name": molecule_name,
            "smiles": smiles,
            "workflow_type": workflow_type,
            "action": action,
            "scenario": scenario,
        }
        if predicted_score is not None:
            arguments["predicted_score"] = predicted_score
        if user_rating is not None:
            arguments["user_rating"] = user_rating
        if notes:
            arguments["notes"] = notes
        arguments.update(component_scores)

        result = await self._call_tool("submit_feedback", arguments)
        return FeedbackResult(**result)

    async def submit_experiment(
        self,
        molecule_name: str,
        smiles: str,
        bbb_penetration_actual: Optional[bool] = None,
        binding_affinity_actual: Optional[float] = None,
        toxicity_actual: Optional[str] = None,
        scenario: str = "default",
    ) -> ExperimentResult:
        """Submit experimental result for model validation.

        Args:
            molecule_name: Name of molecule
            smiles: SMILES notation
            bbb_penetration_actual: Actual BBB penetration
            binding_affinity_actual: Actual binding affinity in nM
            toxicity_actual: Toxicity result
            scenario: Scenario name

        Returns:
            ExperimentResult with experiment_id and status

        Example:
            >>> result = await client.learning.submit_experiment(
            ...     molecule_name="TS-001",
            ...     smiles="CC(C)Nc1nc...",
            ...     bbb_penetration_actual=True,
            ...     binding_affinity_actual=15.2,
            ...     scenario="tourette",
            ... )
        """
        self._validate_not_empty(molecule_name, "molecule_name")
        self._validate_not_empty(smiles, "smiles")

        arguments = {
            "molecule_name": molecule_name,
            "smiles": smiles,
            "scenario": scenario,
        }
        if bbb_penetration_actual is not None:
            arguments["bbb_penetration_actual"] = bbb_penetration_actual
        if binding_affinity_actual is not None:
            arguments["binding_affinity_actual"] = binding_affinity_actual
        if toxicity_actual is not None:
            arguments["toxicity_actual"] = toxicity_actual

        result = await self._call_tool("submit_experiment", arguments)
        return ExperimentResult(**result)

    async def get_stats(self, scenario: str = "default") -> LearningStats:
        """Get learning statistics for a scenario.

        Args:
            scenario: Scenario name (default: 'default')

        Returns:
            LearningStats with feedback counts and averages

        Example:
            >>> stats = await client.learning.get_stats("tourette")
            >>> print(f"Total feedback: {stats.total_feedback}")
        """
        result = await self._call_tool("get_stats", {"scenario": scenario})
        return LearningStats(**result)

    async def optimize(
        self,
        scenario: str = "default",
        min_samples: int = 10,
    ) -> OptimizationResult:
        """Run weight optimization for a scenario.

        Args:
            scenario: Scenario name
            min_samples: Minimum feedback samples required

        Returns:
            OptimizationResult with optimized weights

        Example:
            >>> result = await client.learning.optimize("tourette", min_samples=5)
            >>> print(f"R²: {result.r_squared}")
        """
        self._validate_positive(min_samples, "min_samples")
        result = await self._call_tool(
            "optimize", {"scenario": scenario, "min_samples": min_samples}
        )
        return OptimizationResult(**result)

    async def get_dashboard(self, scenario: str = "default") -> DashboardData:
        """Get dashboard overview data.

        Args:
            scenario: Scenario name

        Returns:
            DashboardData with overview and recent feedback
        """
        result = await self._call_tool("get_dashboard", {"scenario": scenario})
        return DashboardData(**result)

    async def get_performance(self, scenario: str = "default") -> PerformanceData:
        """Get performance history for a scenario.

        Args:
            scenario: Scenario name

        Returns:
            PerformanceData with historical metrics
        """
        result = await self._call_tool("get_performance", {"scenario": scenario})
        return PerformanceData(**result)
