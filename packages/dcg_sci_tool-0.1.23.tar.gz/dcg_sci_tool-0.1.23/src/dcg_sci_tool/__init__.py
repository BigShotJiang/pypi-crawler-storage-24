"""
dcg-sci-tool is a Python package that provides utility functions for scientific computing. 
It includes functions for summing numbers to a target value and extracting atom types from molecular data. 
This package is designed to be easy to use and integrate into various scientific workflows.
"""
from .sum_to_n import sum_to_n
from .extract_atom_types import extract_atom_types
from .get_atoms_near_point import get_atoms_near_point
from .indexes2expression import indexes2expression
from .find_matching_files import find_matching_files
from .add_config_to_xyz import add_config_to_xyz
from .merge_xyz import merge_xyz
from .split_xyz_by_elements import split_xyz_by_elements
from .get_xyz_prop_columns import get_xyz_prop_columns
from .resultData2extxyz import resultData2extxyz
from .traj2iniData import traj2iniData
from .get_atoms_with_specific_color import get_atoms_with_specific_color
from .mpirun_lammps import mpirun_lammps
from .atoms2lmps_resultData import atoms2lmps_resultData
from .ovito2atoms import ovito2atoms

from .structures_analysis.detect_O2_molecules import detect_O2_molecules
from .structures_analysis.detect_CO_CO2_molecules import detect_CO_CO2_molecules
from .structures_analysis.detect_CO_coordinating_to_PdAu import detect_CO_coordinating_to_PdAu
from .structures_analysis.detect_single_adsorbed_O import detect_single_adsorbed_O
from .structures_analysis.get_pdau_cluster_center import get_pdau_cluster_center
from .structures_analysis.get_pdau_surface_atoms import get_pdau_surface_atoms
from .structures_analysis.get_pdau_surface_atoms import get_pdau_surface_atoms
from .structures_analysis.find_cluster_surface_hollow_sites import find_cluster_surface_hollow_sites
from .structures_analysis.find_elements_exclusively_frames import find_elements_exclusively_frames

from .structures_modifying.rotate_v1_around_p_to_v2 import rotate_v1_around_p_to_v2
from .structures_modifying.translate_structure_center import translate_structure_center
from .structures_modifying.create_filtered_structure import create_filtered_structure
from .structures_modifying.detect_gas_molecules_for_deletion import detect_gas_molecules_for_deletion
from .structures_modifying.get_traj_focusing_reaction_site import get_traj_focusing_reaction_site
from .structures_modifying.pre_del_gases import pre_del_gases
from .structures_modifying.construct_CO2_formation_FS import construct_CO2_formation_FS


from .reaction.get_hollowSite_outer_neighbors import get_hollowSite_outer_surface_neighbors, get_hollowSite_outer_neighbors_with_subsurface
from .reaction.get_OC_bonded_metal_atoms import get_OC_bonded_metal_atoms
from .reaction.find_nearest_hollow_site import find_nearest_hollow_site
from .reaction.get_reactants_ad_config import get_reactants_ad_config
from .reaction.get_reaction_local_atoms_list import get_reaction_local_atoms_list
from .reaction.get_reaction_local_atoms_list import get_reaction_local_atoms_list
from .reaction.get_struct_focusing_reaction_site import get_struct_focusing_reaction_site
from .reaction.parse_nebTraj_file_name import parse_nebTraj_file_name
from .reaction.get_hollowSite_Au_Disperation import get_hollowSite_Au_Disperation
from .reaction.get_local_minima_sides_of_peak import get_local_minima_sides_of_peak
from .reaction.neb_post_process import neb_get_traj, plot_neb_graph
from .reaction.auto_neb_refine import auto_neb_refine
from .reaction.detect_nearby_ads_for_deletion import detect_nearby_ads_for_deletion
from .reaction.run_neb_from_MD_snapshot import run_neb_from_MD_snapshot

from .plot.plot_scatter_color import plot_scatter_color
from .plot.mark_special_points import mark_special_points
from .plot.plot_basic_graph import plot_basic_graph

from .applications.get_traj_focusing_reaction_site_batches import get_traj_focusing_reaction_site_batches
from .applications.get_target_atoms_from_MD import get_target_atoms_from_MD

__version__ = "0.1.23"

__all__ = [
    "sum_to_n",
    "extract_atom_types",
    "detect_O2_molecules",
    "detect_CO_CO2_molecules",
    "detect_CO_coordinating_to_PdAu",
    "detect_single_adsorbed_O",
    "detect_gas_molecules_for_deletion",
    "get_atoms_near_point",
    "get_reaction_local_atoms_list",
    "indexes2expression",
    "get_pdau_cluster_center",
    "rotate_v1_around_p_to_v2",
    "translate_structure_center",
    "parse_nebTraj_file_name",
    "create_filtered_structure",
    "get_struct_focusing_reaction_site",
    "get_traj_focusing_reaction_site",
    "get_traj_focusing_reaction_site_batches",
    "find_matching_files",
    "get_reactants_ad_config",
    "get_pdau_surface_atoms",
    "get_reaction_local_atoms_list",
    "get_OC_bonded_metal_atoms",
    "find_nearest_hollow_site",
    "get_hollowSite_outer_neighbors_with_subsurface",
    "get_hollowSite_outer_surface_neighbors",
    "find_cluster_surface_hollow_sites",
    "get_hollowSite_Au_Disperation",
    "add_config_to_xyz",
    "merge_xyz",
    "plot_scatter_color",
    "find_elements_exclusively_frames",
    "mark_special_points",
    "split_xyz_by_elements",
    "get_xyz_prop_columns",
    "pre_del_gases",
    "construct_CO2_formation_FS",
    "get_local_minima_sides_of_peak",
    "resultData2extxyz",
    "traj2iniData",
    "get_atoms_with_specific_color",
    "get_target_atoms_from_MD",
    "mpirun_lammps",
    "atoms2lmps_resultData",
    "plot_basic_graph",
    "neb_get_traj",
    "plot_neb_graph",
    "auto_neb_refine",
    "detect_nearby_ads_for_deletion",
    "ovito2atoms",
    "run_neb_from_MD_snapshot"
]
