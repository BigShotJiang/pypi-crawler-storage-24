import os
import shutil
from pathlib import Path
import dcg_sci_tool
from dcg_sci_tool.reaction.neb_post_process import *
from ase.io import write
from dcg_sci_tool.applications.get_target_atoms_from_MD import get_target_atoms_from_MD
from dcg_sci_tool.structures_modifying.pre_del_gases import pre_del_gases
from dcg_sci_tool.reaction.auto_neb_refine import auto_neb_refine
# lammps data文件元素序号顺序
CONFIG = {
    "specorder": ['C', 'O', 'Pd', 'Au'],
}

def setup_logging():
    """设置日志和版本信息"""
    print("=" * 60)
    print(f"dcg_sci_tool version: {dcg_sci_tool.__version__}")
    print("=" * 60)

def find_and_preprocess_input():
    """查找并预处理输入文件"""
    md_files = find_matching_files(".", "CO2_formation_frame*.xyz")
    if not md_files:
        raise FileNotFoundError("未找到符合模式 'CO2_formation_frame*.xyz' 的 MD 快照文件")
    
    md_snapshot_file = md_files[0]
    
    # 获取CO2生成的序号
    co2_indexes = md_snapshot_file.split('.')[0].split('_')[4].split('to')
    print(f"找到 MD 快照文件: {md_snapshot_file}")
    
    # 获取目标原子列表
    old_target_atom_list = get_target_atoms_from_MD(md_snapshot_file)
    
    # 预处理：删除气体原子
    cleaned_atoms, target_atom_list = pre_del_gases(
        input_file=md_snapshot_file,
        old_indexes_to_transfer=old_target_atom_list
    )
    
    # 保存清理后的结构
    write("cleaned_MD_snapshot.xyz", images=cleaned_atoms, format="extxyz")
    print(f"已保存清理后的结构到: cleaned_MD_snapshot.xyz")
    print(f"目标原子列表: {target_atom_list}")
    
    return cleaned_atoms, target_atom_list, md_snapshot_file, co2_indexes

def create_workspace(dir_name, required_files=None):
    """创建工作目录并复制必要文件"""
    if required_files is None:
        required_files = []
    
    workspace = Path(dir_name)
    workspace.mkdir(exist_ok=True)
    print(f"创建/进入工作目录: {workspace}")
    
    # 复制必要文件
    for file in required_files:
        src = Path(file)
        if src.exists():
            shutil.copy2(src, workspace)
            print(f"  复制: {file}")
        else:
            print(f"  警告: 文件不存在 {file}")
    
    return workspace

def run_initial_state_minimization():
    """运行初态结构优化"""
    print("\n" + "=" * 60)
    print("步骤 1: 初态结构优化")
    print("=" * 60)
    
    # 准备工作目录
    is_dir = create_workspace("1.IS_min", ["nep.txt", "in.lammps_min", "cleaned_MD_snapshot.xyz"])
    
    # 保存当前目录
    original_dir = Path.cwd()
    
    try:
        os.chdir(is_dir)
        
        # 转换轨迹为初始数据
        traj2iniData(
            traj_file="cleaned_MD_snapshot.xyz",
            specorder=CONFIG["specorder"],
            start_frame=0,
            end_frame=0
        )
        
        # 重命名数据文件
        data_file = Path("0.data")
        if data_file.exists():
            data_file.rename("ini.data")
            print("已将 0.data 重命名为 ini.data")
        
        # 运行 LAMMPS 最小化
        print("运行 LAMMPS 结构优化...")
        mpirun_lammps(input_file="in.lammps_min")
        
        # 转换结果为可读格式
        resultData2extxyz(input_file="result.data", output_file="minimized_IS.xyz")
        print("优化完成，结果保存为: minimized_IS.xyz")
        
    finally:
        os.chdir(original_dir)
    
    return original_dir / is_dir / "minimized_IS.xyz"

def construct_final_state(minimized_is_path, target_atom_list):
    """构建末态结构"""
    print("\n" + "=" * 60)
    print("步骤 2: 构建末态结构")
    print("=" * 60)
    
    atoms_fs = construct_CO2_formation_FS(str(minimized_is_path), target_atom_list)
    fs_path = minimized_is_path.parent / "constructed_FS.xyz"
    write(str(fs_path), format="extxyz", images=atoms_fs)
    
    print(f"末态结构已保存到: {fs_path}")
    return atoms_fs, fs_path

def run_neb_calculation(minimized_is_path, target_atom_list,mpi_partition="40x1",neb_max_refine_rounds = 3, co2_indexes = None):
    """运行 NEB 计算"""
    print("\n" + "=" * 60)
    print("步骤 3: 运行 NEB 计算")
    print("=" * 60)
    
    # 创建工作目录
    neb_dir = create_workspace("2.neb", ["nep.txt", "in.lammps_neb"])
    original_dir = Path.cwd()
    
    try:
        os.chdir(neb_dir)
        
        # 1. 构建初态数据文件
        print("构建初态数据文件...")
        traj2iniData(
            traj_file=str(minimized_is_path),
            specorder=CONFIG["specorder"],
            start_frame=0,
            end_frame=0
        )
        
        if Path("0.data").exists():
            Path("0.data").rename("IS.data")
            print("已创建 IS.data")
        
        # 2. 构建末态数据文件
        print("构建末态数据文件...")
        atoms_fs = construct_CO2_formation_FS(str(minimized_is_path), target_atom_list)
        atoms2lmps_resultData(atoms=atoms_fs, output_file="FS.data")
        print("已创建 FS.data")
        
        # 3. 运行 NEB 计算
        print("运行 LAMMPS NEB 计算...")
        mpirun_lammps(input_file="in.lammps_neb", partition=mpi_partition)
        
        # 4. 提取轨迹和绘图
        print("提取 NEB 轨迹...")
        neb_get_traj()
        
        print("生成 NEB 能垒图...")
        Ea, dH = plot_neb_graph(src_file="neb_mep.dat", output_file="neb_graph.png")
        

        found_local_minima, left_idx, right_idx = get_local_minima_sides_of_peak(
        mep_data_file="neb_mep.dat", 
        neb_traj_file="result.xyz"
    )

        if found_local_minima:
            # 5. 自动优化 NEB
            print(f"发现中间态，开始 NEB 自动优化 (最多 {neb_max_refine_rounds} 轮)...")

            Ea, dH, final_neb_dir = auto_neb_refine(left_idx, right_idx, max_round_num=neb_max_refine_rounds)
        else:
            
            final_neb_dir = neb_dir
            
        # 将最终neb轨迹和MEP图像复制到主目录
        shutil.copy(f'{final_neb_dir}/result.xyz', f'{original_dir}/{co2_indexes[0]}-{co2_indexes[1]}_{Ea}_{dH}_{target_atom_list[0]}_{target_atom_list[1]}.xyz')
        shutil.copy(f'{final_neb_dir}/neb_graph.png', f'{original_dir}/{co2_indexes[0]}-{co2_indexes[1]}_{Ea}_{dH}_{target_atom_list[0]}_{target_atom_list[1]}.png')


    finally:
        os.chdir(original_dir)
    
    print("NEB 计算完成！")

def run_neb_from_MD_snapshot(mpi_partition="40x1", neb_max_refine_rounds=3):
    """
    提取单个MD反应快照（反应物原子需要染成兰色），计算neb过程的能垒。
    包含气体分子删除、初态优化、末态构建、neb计算、neb单峰优化过程

    Args:
        mpi_partition (str): 跑lammps的neb环境配置参数

        neb_max_refine_rounds (int): neb单峰优化过程最大迭代轮数

    """
    try:
        # 1. 初始化
        setup_logging()
        
        # 2. 查找并预处理输入
        cleaned_atoms, target_atom_list, md_file, co2_indexes = find_and_preprocess_input()
        
        # 3. 初态结构优化
        minimized_is_path = run_initial_state_minimization()
        print(f"minimized_is_path值：{minimized_is_path}")
        
        # 4. 构建末态结构
        atoms_fs, fs_path = construct_final_state(minimized_is_path, target_atom_list)
        
        # 5. 运行 NEB 计算
        run_neb_calculation(minimized_is_path, target_atom_list, mpi_partition, neb_max_refine_rounds, co2_indexes)
        
        print("\n" + "=" * 60)
        print("所有计算步骤完成！")
        print(f"初态优化结果: {minimized_is_path}")
        print(f"末态结构: {fs_path}")
        print(f"NEB 计算结果目录: 2.neb/")
        print("=" * 60)
        
    except FileNotFoundError as e:
        print(f"错误: 文件未找到 - {e}")
        return 1
    except Exception as e:
        print(f"错误: 计算过程中发生异常 - {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0