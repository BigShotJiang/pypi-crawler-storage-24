from dcg_sci_tool import *
import numpy as np
from dcg_sci_tool.reaction.get_reaction_local_atoms_list import get_reaction_local_atoms_list


def detect_nearby_ads_for_deletion(data, type_names_order, c_idx, o_idx,cutoff: float):
    """
    找到距离反应物CO的C和反应物O连线中点一定距离内吸附态的原子序号，
    用于后续删除，分析没有第三方吸附物时的能垒

    Args:
        data : Ovito DataCollection

        type_names_order (list): 元素顺序列表

        c_idx (int): 反应物CO中C原子序号

        o_idx (int): 反应物O原子的序号

        cutoff (float): 


    """
    # 获取局部地区的原子，同时保证CO或O2气体分子的完整加入性
    local_atoms_indexes = get_reaction_local_atoms_list(data, type_names_order,c_idx,o_idx,cutoff)
    
    particles = data.particles
    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])
    
    

    local_c_o_to_delete = []
    # 将Ovito的data对象转化为Atoms对象，用于后续计算距离时考虑周期性边界条件
    atoms = ovito2atoms(data,type_names_order)
    for idx in local_atoms_indexes:
        # 不删除反应物原子
        if idx == c_idx or idx == o_idx:
            continue
        if symbols[idx] == 'O' or symbols[idx] == 'C':
            if symbols[idx] == 'O':
                # 不删除反应物原子
                distance = atoms.get_distance(idx, c_idx, mic=True)
                if distance < 1.5:
                    continue
            local_c_o_to_delete.append(idx)
    
    return local_c_o_to_delete

   

