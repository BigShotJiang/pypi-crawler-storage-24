import os
import re
from typing import List

def find_matching_files(directory: str, pattern: str = None, pattern_type: str = "wildcard") -> List[str]:
    """
    查找目录下所有满足模式的文件名（支持shell通配符和正则表达式）
    注意：正则表达式（regex）与shell的通配符（wildcard）语法完全不同！
    在shell中：*表示任意字符序列
    在正则中：*表示匹配前面的字符0次或多次
    
    Args:

        directory (str): 要搜索的目录路径
        pattern (str): 模式字符串，可以是shell通配符或正则表达式
        pattern_type (str): 模式类型，可选值为："wildcard"（shell通配符）或 "regex"（正则表达式），默认值为"wildcard"

    Returns:

        matching_files (List[str]): 匹配的文件名列表
    """
    if pattern is None:
        print("No pattern provided")
        return []
    
    # 根据模式类型转换shell通配符为正则表达式
    if pattern_type.lower() == "wildcard":
        # 将shell通配符语法转换为正则表达式
        regex_pattern = wildcard_to_regex(pattern)
    elif pattern_type.lower() == "regex":
        regex_pattern = pattern
    else:
        print(f"不支持的pattern_type: {pattern_type}，请使用'wildcard'或'regex'")
        return []
    
    # 编译正则表达式
    try:
        regex = re.compile(regex_pattern)
    except re.error as e:
        print(f"正则表达式编译错误: {e}")
        return []
    
    matching_files = []
    
    # 只搜索当前目录，不使用os.walk
    try:
        # 获取指定目录中的所有文件和子目录
        items = os.listdir(directory)
        
        for item in items:
            # 构建完整路径
            item_path = os.path.join(directory, item)
            
            # 检查是否是文件（不是目录）
            if os.path.isfile(item_path):
                # 检查文件名是否匹配正则表达式
                if regex.fullmatch(item):
                    matching_files.append(item)
    except FileNotFoundError:
        print(f"目录不存在: {directory}")
    except PermissionError:
        print(f"没有权限访问目录: {directory}")
    except Exception as e:
        print(f"读取目录时发生错误: {e}")
    
    return matching_files

def wildcard_to_regex(wildcard_pattern: str) -> str:
    """
    将shell通配符转换为正则表达式
    
    shell通配符语法：
    - * 匹配任意字符序列（包括空序列）
    - ? 匹配任意单个字符
    - [abc] 匹配a、b或c中的任意一个字符
    - [!abc] 匹配除了a、b、c以外的任意字符
    - {a,b,c} 匹配a、b或c
    
    参数:
    ----------
    wildcard_pattern : str
        shell通配符模式
        
    返回:
    -------
    str
        对应的正则表达式
    """
    # 转义正则表达式特殊字符
    regex_pattern = re.escape(wildcard_pattern)
    
    # 将转义后的通配符转换回正则表达式语法
    # 1. 将转义的* (即\*) 转换为 .*
    regex_pattern = regex_pattern.replace(r'\*', '.*')
    
    # 2. 将转义的? (即\?) 转换为 .
    regex_pattern = regex_pattern.replace(r'\?', '.')
    
    # 3. 处理字符集 [abc]
    # 由于re.escape会将方括号转义，我们需要手动处理
    # 更复杂的字符集处理（如范围、取反等）需要更复杂的逻辑
    regex_pattern = regex_pattern.replace(r'\[', '[').replace(r'\]', ']')
    
    # 4. 处理取反字符集 [!abc]
    # 这里简化处理，将[!转换为[^
    regex_pattern = regex_pattern.replace(r'[!', '[^')
    
    return f"^{regex_pattern}$"  # 添加^和$确保完全匹配