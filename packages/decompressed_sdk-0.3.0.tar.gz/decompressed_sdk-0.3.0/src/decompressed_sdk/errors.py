from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class DecompressedError(Exception):
    message: str
    status: Optional[int] = None
    request_id: Optional[str] = None
    details: Any = None

    def __str__(self) -> str:
        return self.message


class AuthenticationError(DecompressedError):
    pass


class PermissionError(DecompressedError):
    pass


class NotFoundError(DecompressedError):
    pass


class ValidationError(DecompressedError):
    pass


class RateLimitError(DecompressedError):
    pass


class QuotaExceededError(DecompressedError):
    """Raised when the SDK embedding quota is exhausted or unavailable on the current plan."""
    pass


class ServerError(DecompressedError):
    pass


def _extract_message(body: Any, status: int) -> str:
    """Extract a human-readable message from an API error response body."""
    if isinstance(body, dict):
        detail = body.get("detail")
        # FastAPI structured errors: {"detail": {"message": "...", "error": "..."}}
        if isinstance(detail, dict):
            return detail.get("message") or detail.get("error") or f"HTTP {status}"
        if isinstance(detail, str):
            return detail
        plain = body.get("message")
        if isinstance(plain, str):
            return plain
    if isinstance(body, str) and body:
        return body
    return f"HTTP {status}"


def raise_for_status(status: int, body: Any, request_id: Optional[str]) -> None:
    message = _extract_message(body, status)

    if status == 401:
        raise AuthenticationError(message, status=status, request_id=request_id, details=body)
    if status == 402:
        raise QuotaExceededError(message, status=status, request_id=request_id, details=body)
    if status == 403:
        raise PermissionError(message, status=status, request_id=request_id, details=body)
    if status == 404:
        raise NotFoundError(message, status=status, request_id=request_id, details=body)
    if status == 422:
        raise ValidationError(message, status=status, request_id=request_id, details=body)
    if status == 429:
        raise RateLimitError(message, status=status, request_id=request_id, details=body)
    if status >= 500:
        raise ServerError(message, status=status, request_id=request_id, details=body)

    raise DecompressedError(message, status=status, request_id=request_id, details=body)
