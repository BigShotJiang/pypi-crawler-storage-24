"""RAG Lab resource — embed texts using saved strategies or built-in presets."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import DecompressedClient


@dataclass
class EmbedResponse:
    """Response from client.lab.embed()."""
    embeddings: List[List[float]]
    model: str
    dimensions: int
    strategy_name: str
    usage: Dict[str, Any]


class LabResource:
    """
    RAG Lab SDK resource for embedding texts with saved strategies.

    Access via client.lab — wraps the /api/v1/lab/sdk/* endpoints.

    Priority order when referencing a strategy:
        preset_id > strategy_id > strategy (name)

    Built-in preset IDs:
        ghost     → Economy         (text-embedding-3-small, 256 dims)
        balanced  → Balanced        (text-embedding-3-small, 1536 dims)
        scholar   → High Accuracy   (pplx-embed-v1-4b, hybrid search)
        hybrid    → Hybrid Search   (text-embedding-3-small, hybrid search)

    Example::

        client = DecompressedClient(api_key="dck_...")

        # Use a built-in preset
        result = client.lab.embed(
            texts=["Document 1", "Document 2"],
            preset_id="balanced",
        )
        print(result.embeddings[0][:5])   # first 5 floats
        print(result.dimensions)           # 1536
        print(result.usage["token_count"])

        # Use a saved strategy by name
        result = client.lab.embed(
            texts=["Document 1"],
            strategy="My High-Accuracy Strategy",
        )

        # List available presets and saved strategies
        available = client.lab.list_strategies()
        for preset in available["presets"]:
            print(preset["id"], preset["name"])
    """

    def __init__(self, client: "DecompressedClient") -> None:
        self._client = client

    def embed(
        self,
        texts: List[str],
        *,
        preset_id: Optional[str] = None,
        strategy_id: Optional[str] = None,
        strategy: Optional[str] = None,
    ) -> EmbedResponse:
        """
        Embed a list of texts using a saved strategy or built-in preset.

        Exactly one of ``preset_id``, ``strategy_id``, or ``strategy`` must be
        supplied. Priority when multiple are given: preset_id > strategy_id >
        strategy.

        Args:
            texts: Texts to embed. Max 100 per call.
            preset_id: Built-in preset ID — ``ghost``, ``balanced``,
                ``scholar``, or ``hybrid``. Highest priority.
            strategy_id: UUID of a saved strategy (from list_strategies).
            strategy: Saved strategy name **or** preset display name
                (case-insensitive). Lowest priority. Preset names take
                precedence over saved strategy names of the same name.

        Returns:
            EmbedResponse with:
                - embeddings (list[list[float]]) — one per input text
                - model (str) — embedding model used
                - dimensions (int) — embedding dimensionality
                - strategy_name (str) — resolved strategy/preset name
                - usage (dict) — token_count, base_cost_usd,
                  billable_cost_usd, remaining_tokens, token_limit

        Raises:
            ValueError: If no strategy selector is provided or inputs are invalid.
            NotFoundError: If the referenced strategy/preset does not exist.
            QuotaExceededError: If the monthly SDK token quota is exhausted or
                SDK embeddings are unavailable on the current plan.
        """
        if not texts:
            raise ValueError("texts must not be empty")
        if len(texts) > 100:
            raise ValueError("Maximum 100 texts per embed() call")
        if not any([preset_id, strategy_id, strategy]):
            raise ValueError(
                "Must provide one of: preset_id, strategy_id, or strategy"
            )

        payload: Dict[str, Any] = {"texts": texts}
        if preset_id:
            payload["preset_id"] = preset_id
        elif strategy_id:
            payload["strategy_id"] = strategy_id
        elif strategy:
            payload["strategy"] = strategy

        data = self._client.request("POST", "/api/v1/lab/sdk/embed", json=payload)
        return EmbedResponse(
            embeddings=data["embeddings"],
            model=data["model"],
            dimensions=data["dimensions"],
            strategy_name=data["strategy_name"],
            usage=data["usage"],
        )

    def list_strategies(self) -> Dict[str, Any]:
        """
        List all available presets and your saved strategies.

        Returns:
            dict with two keys:
                - ``presets`` (list[dict]) — built-in presets, each with:
                  id, name, model, dimensions, chunking_method, search_type
                - ``saved_strategies`` (list[dict]) — your saved strategies,
                  each with: id, name, model, dimensions, chunking_method,
                  search_type, usage_count

        Example::

            available = client.lab.list_strategies()

            for preset in available["presets"]:
                print(f"{preset['id']}: {preset['name']} ({preset['model']})")

            for s in available["saved_strategies"]:
                print(f"{s['name']} — used {s['usage_count']} times")
        """
        return self._client.request("GET", "/api/v1/lab/sdk/strategies")
