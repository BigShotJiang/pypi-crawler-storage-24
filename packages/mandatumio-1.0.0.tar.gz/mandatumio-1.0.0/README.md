# mandatum

> **Spending limits and authorization for AI agents.** One line of code to prevent your AI from overspending.

## Install

```bash
pip install mandatum
```

## Quick Start

```python
from mandatum import Mandatum

m = Mandatum(
    api_key="mdt_live_...",
    base_url="https://mandatum-fbg9.onrender.com"
)

# Register an agent
agent = m.agents.create("ShoppingBot", type="payment", delegator="user@example.com")

# Check spending limits before payment
result = m.agents.spend(agent["id"], {
    "amount": 350,
    "currency": "INR",
    "vendor": "DigitalOcean",
})

if result["allowed"]:
    razorpay.order.create({"amount": 35000})
else:
    print("Blocked:", result["reason"])
```

## Payment Wrappers

```python
from mandatum.payments import MandatumRazorpay

pay = MandatumRazorpay(razorpay_client, m, agent["id"])
result = pay.create_order(amount=50000, currency="INR")

if result["allowed"]:
    print("✅ Order created:", result["order"])
```

## Decorator Guard

```python
from mandatum.integrations import mandatum_guard

@mandatum_guard(m, agent_id="agt_abc123", action="payments:execute")
def buy_groceries(items, amount=0):
    return razorpay.order.create({"amount": amount * 100})

# Automatically checks limits — raises MandatumBlocked if over
buy_groceries(["milk", "bread"], amount=500)
```

## Context Manager

```python
from mandatum.integrations import MandatumGuard

with MandatumGuard(m, "agt_abc123") as guard:
    guard.check_spend(amount=350, vendor="AWS")
    # Only runs if spend was allowed
    aws.create_instance(...)
```

## API Reference

| Method | Description |
|---|---|
| `m.check(token, action, context)` | 1-line permission gate |
| `m.agents.spend(id, params)` | Record spending + check limits |
| `m.agents.spending(id)` | Get spending summary |
| `m.agents.create/list/get/suspend/revoke` | Manage agents |
| `m.tokens.issue/verify/revoke` | Manage tokens |
| `m.policies.create/list/assign` | Manage policies |
| `m.audit.list/verify_chain` | Audit trail |

## License

MIT
