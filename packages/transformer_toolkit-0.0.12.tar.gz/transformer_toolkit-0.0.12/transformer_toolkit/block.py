from .feed_forward  import FFN
from .normalization import LayerNorm
from .attention     import MultiHeadAttention
from torch import nn


class TransformerBlock(nn.Module):
    """
    Default: original 'Attention is All You Need' — MHA + FFN + LayerNorm.
    Swap any component via attn=, ffn=, norm= for modern variants.
    """
    def __init__(
        self,
        dim:     int,
        n_heads: int,
        hidden:  int,
        norm = None,   # default: LayerNorm (original)
        attn = None,   # default: MultiHeadAttention (original)
        ffn  = None,   # default: FFN + ReLU (original)
    ):
        super().__init__()
        self.norm1 = norm or LayerNorm(dim)
        self.norm2 = norm or LayerNorm(dim)
        self.attn  = attn or MultiHeadAttention(dim, n_heads)
        self.ffn   = ffn  or FFN(dim, hidden)

    def forward(self, x, mask=None):
        x = x + self.attn(self.norm1(x), mask)
        x = x + self.ffn(self.norm2(x))
        return x