"""Simple integration tests for hook.py to boost coverage."""

from menard.hook import run_hook


def test_hook_no_config(tmp_path):
    """Test hook with no configuration and some staged files."""
    # Create a dummy file to stage
    src = tmp_path / "src"
    src.mkdir()
    (src / "test.py").write_text("pass")

    result = run_hook(tmp_path, staged_files=["src/test.py"])
    assert result.passed
    assert "not configured" in result.message


def test_hook_no_staged_files(tmp_path):
    """Test hook with no staged files."""
    config = tmp_path / "pyproject.toml"
    config.write_text('[tool.menard]\nrequire_links = ["src/**/*.py"]\n')

    result = run_hook(tmp_path, staged_files=[])
    assert result.passed


def test_hook_with_valid_links(tmp_path):
    """Test hook with valid links."""
    # Create structure
    src = tmp_path / "src"
    src.mkdir()
    (src / "code.py").write_text("pass")

    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "doc.md").write_text("# Doc")

    # Create links
    menard = tmp_path / ".menard"
    menard.mkdir()
    links = menard / "links.toml"
    links.write_text('[[link]]\ncode = "src/code.py"\ndocs = ["docs/doc.md"]\n')

    # Create config
    config = tmp_path / "pyproject.toml"
    config.write_text(
        '[tool.menard]\nrequire_links = ["src/**/*.py"]\ndoc_paths = ["docs/**/*.md"]\n'
    )

    # Initialize git repo to avoid staleness check errors
    import subprocess

    subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
    subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@example.com"], cwd=tmp_path, capture_output=True
    )
    subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
    subprocess.run(["git", "commit", "-m", "initial"], cwd=tmp_path, capture_output=True)

    # Both files staged
    result = run_hook(tmp_path, staged_files=["src/code.py", "docs/doc.md"])

    # Result structure should be valid
    assert hasattr(result, "passed")
    assert hasattr(result, "message")
    assert hasattr(result, "stale_docs")
    assert hasattr(result, "missing_links")


def test_hook_warn_mode(tmp_path):
    """Test hook in warn mode."""
    # Create structure
    src = tmp_path / "src"
    src.mkdir()
    (src / "code.py").write_text("pass")

    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "doc.md").write_text("# Doc")

    menard = tmp_path / ".menard"
    menard.mkdir()
    links = menard / "links.toml"
    links.write_text('[[link]]\ncode = "src/code.py"\ndocs = ["docs/doc.md"]\n')

    config = tmp_path / "pyproject.toml"
    config.write_text('[tool.menard]\nrequire_links = ["src/**/*.py"]\nmode = "warn"\n')

    # In warn mode, should pass even with issues
    result = run_hook(tmp_path, staged_files=["src/code.py"])

    # Warn mode should always pass
    if result.stale_docs or result.missing_links:
        assert result.passed  # Warn mode passes with warnings
