#ifndef __AIDGE_EXPORT_CPP_KERNELS_UNARYWISE__
#define __AIDGE_EXPORT_CPP_KERNELS_UNARYWISE__

#include "utils/cpp/typedefs.hpp"
#include <cmath>
#include <cstddef>

namespace export_cpp {

template <size_t NB_ELTS,
          UnaryWise_T UNARY_OP,
          // Memory mapping: inputs
          int INPUT_MEM_CONT_OFFSET,
          int INPUT_MEM_CONT_SIZE,
          int INPUT_MEM_WRAP_OFFSET,
          int INPUT_MEM_WRAP_SIZE,
          int INPUT_MEM_STRIDE,
          // Memory mapping: outputs
          int OUTPUT_MEM_CONT_OFFSET,
          int OUTPUT_MEM_CONT_SIZE,
          int OUTPUT_MEM_WRAP_OFFSET,
          int OUTPUT_MEM_WRAP_SIZE,
          int OUTPUT_MEM_STRIDE,
          typename Input_T,
          typename Output_T>
__attribute__((always_inline)) inline void
unarywise_forward(const Input_T *__restrict inputs,
                  Output_T *__restrict outputs)
{
    auto apply_op = [](auto x) -> Output_T {
        switch (UNARY_OP) {
        case UnaryWise_T::Asin:
            return static_cast<Output_T>(std::asin(x));
        case UnaryWise_T::Not:
            return static_cast<Output_T>(!x);
        case UnaryWise_T::Ln:
            return static_cast<Output_T>(std::log(x));
        case UnaryWise_T::Sqrt:
            return static_cast<Output_T>(std::sqrt(x));
        case UnaryWise_T::Reciprocal:
            return static_cast<Output_T>(1 / x);
        case UnaryWise_T::Tanh:
            return static_cast<Output_T>(std::tanh(x));
        default:
            return static_cast<Output_T>(x);
        }
    };

    int inOffset = 0;
    int outOffset = 0;

    for (size_t i = 0; i < NB_ELTS; ++i) {
        if (INPUT_MEM_WRAP_SIZE > 0 &&
            i == INPUT_MEM_CONT_SIZE / sizeof(Input_T))
        {
            inOffset = (INPUT_MEM_WRAP_OFFSET - INPUT_MEM_CONT_OFFSET -
                        INPUT_MEM_CONT_SIZE) /
                       static_cast<int>(sizeof(Input_T));
        }

        if (OUTPUT_MEM_WRAP_SIZE > 0 &&
            i == OUTPUT_MEM_CONT_SIZE / sizeof(Output_T))
        {
            outOffset = (OUTPUT_MEM_WRAP_OFFSET - OUTPUT_MEM_CONT_OFFSET -
                         OUTPUT_MEM_CONT_SIZE) /
                        static_cast<int>(sizeof(Output_T));
        }

        outputs[outOffset + i] = apply_op(inputs[inOffset + i]);
    }
}

} // namespace export_cpp

#endif // __AIDGE_EXPORT_CPP_KERNELS_UNARYWISE__
