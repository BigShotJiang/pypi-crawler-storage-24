import aidge_core
from aidge_export_cpp import ExportLibCpp
from aidge_export_cpp.operators.UnaryWise import UnaryWise


@ExportLibCpp.register(
    "Sqrt",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.float32)),
    aidge_core.ProdConso.in_place_model,
)
class SqrtCPP(UnaryWise):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
        self.attributes["unarywise_op"] = "Sqrt"
