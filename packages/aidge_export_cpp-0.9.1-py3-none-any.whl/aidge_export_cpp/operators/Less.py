import aidge_core
from aidge_export_cpp import ExportLibCpp
from aidge_export_cpp.operators.ElemWise import ElemWise


@ExportLibCpp.register(
    "Less",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any)),
    aidge_core.ProdConso.in_place_model,
)
class Less(ElemWise):
    """Export class for the Less operator.

    Reuses the ElemWise broadcasting infrastructure with ``ElemWise_T::Lt``.
    The output accumulation type is ``bool`` to match the ONNX spec.
    """

    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
        self.attributes["elemwise_op"] = "Lt"
        self.attributes["accumulation_type"] = "bool"
