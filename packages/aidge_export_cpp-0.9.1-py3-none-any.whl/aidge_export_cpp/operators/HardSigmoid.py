import aidge_core
from aidge_core.export_utils import ExportNodeCpp, get_node_from_metaop
from aidge_export_cpp import CPP_ROOT, ExportLibCpp, set_scaling_attributes


@ExportLibCpp.register(
    "HardSigmoid",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.float32)),
    aidge_core.ProdConso.in_place_model,
)
class HardSigmoidCPP(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Initialize kernel attributes
        self.attributes["alpha"] = node.get_operator().attr.alpha
        self.attributes["beta"] = node.get_operator().attr.beta

        self.attributes["activation"] = "Linear"
        self.attributes["rescaling"] = "NoScaling"

        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "hardsigmoid_config.jinja"
        )
        self.forward_template = str(
            CPP_ROOT / "templates" / "kernel_forward" / "hardsigmoid_forward.jinja"
        )
        self.include_list = []
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "hardsigmoid.hpp", "include/kernels/cpp"
        )
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "activation.hpp",
            "include/utils/cpp",
            fwd_include=False,
        )
