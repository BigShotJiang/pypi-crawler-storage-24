"""
Copyright (c) 2024 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import aidge_core
from aidge_export_cpp import ExportLibCpp
from aidge_export_cpp.operators.UnaryWise import UnaryWise


@ExportLibCpp.register(
    "Not",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.boolean)),
    aidge_core.ProdConso.in_place_model,
)
class Not(UnaryWise):
    """Export class for the Not operator.

    Reuses the UnaryWise base with ``UnaryWise_T::Not``
    to perform element-wise logical NOT on a boolean input tensor.
    """

    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
        self.attributes["unarywise_op"] = "Not"
