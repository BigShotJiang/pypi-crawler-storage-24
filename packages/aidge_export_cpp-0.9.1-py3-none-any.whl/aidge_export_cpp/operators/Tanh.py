import aidge_core
from aidge_export_cpp import ExportLibCpp
from aidge_export_cpp.operators.UnaryWise import UnaryWise


@ExportLibCpp.register(
    "Tanh",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any)),
    aidge_core.ProdConso.in_place_model,
)
class TanhCPP(UnaryWise):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
        self.attributes["unarywise_op"] = "Tanh"
