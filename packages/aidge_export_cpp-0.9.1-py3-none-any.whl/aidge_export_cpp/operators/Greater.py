import aidge_core
from aidge_export_cpp import ExportLibCpp
from aidge_export_cpp.operators.ElemWise import ElemWise


@ExportLibCpp.register(
    "Greater",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any)),
    aidge_core.ProdConso.in_place_model,
)
class Greater(ElemWise):
    """Export class for the Greater operator.

    Reuses the ElemWise broadcasting infrastructure with ``ElemWise_T::Gt``.
    The output accumulation type is ``bool`` to match the ONNX spec.
    """

    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
        self.attributes["elemwise_op"] = "Gt"
        self.attributes["accumulation_type"] = "bool"
