"""
Copyright (c) 2024 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from aidge_core.export_utils import ExportNodeCpp
from aidge_export_cpp import CPP_ROOT


class UnaryWise(ExportNodeCpp):
    """Base export class for element-wise unary operators.

    Handles a single-input, single-output operator where each output element
    is a function of the corresponding input element (no broadcasting needed).
    Subclasses set ``self.attributes["unarywise_op"]`` to the appropriate
    ``UnaryWise_T`` enum value name (e.g. ``"Asin"``, ``"Not"``).
    """

    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Template for layer configuration file generation
        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "unarywise_config.jinja"
        )

        # Template for layer call function generation within the forward file
        self.forward_template = str(
            CPP_ROOT / "templates" / "kernel_forward" / "unarywise_forward.jinja"
        )

        # Copy the unified unary-wise kernel into the generated project
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "unarywise.hpp", "include/kernels/cpp"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = []

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("utils/cpp/typedefs.hpp")
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")
