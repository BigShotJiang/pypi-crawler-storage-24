# Mem-Brain MCP Troubleshooting

## Authentication failed / No API key provided

1. Ensure your MCP client sends `X-API-Key: mb_live_xxx`.
2. Confirm the key is active in Mem-Brain API (`GET /api/v1/api-keys`).
3. If using Bearer format, value must be an API key: `Authorization: Bearer mb_live_xxx`.

## Connection refused

1. API health: `curl http://localhost:8000/health`
2. MCP health: `curl http://localhost:8100/health`
3. Verify configured URL/path is `http://localhost:8100/mcp`

## Search returns no results

1. Verify data exists with `get_stats()`.
2. Try broader semantic queries.
3. Reduce filtering constraints.

## Debug logs

```bash
export LOG_LEVEL=DEBUG
uv run python -m mem_brain_mcp.server
```
