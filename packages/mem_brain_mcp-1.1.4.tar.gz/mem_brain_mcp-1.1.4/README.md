# Mem-Brain MCP Server

MCP (Model Context Protocol) server that exposes Mem-Brain API functionality as standardized tools for AI agents. Built with [FastMCP](https://gofastmcp.com) for production-ready HTTP/SSE transport.

## Features

- Memory CRUD and semantic search
- Search modes: `raw` (graph-native), `interpreted` (LLM summary), `both` (summary + evidence)
- Graph operations (path + neighborhood)
- Stats and health endpoints
- HTTP/SSE transport for remote MCP clients

## Authentication

Mem-Brain MCP uses **MemBrain API keys**.

- Preferred header in MCP client config: `X-API-Key: mb_live_...`
- Also supported: `Authorization: Bearer mb_live_...`

## Installation

### PyPI

```bash
pip install mem-brain-mcp
mem-brain-mcp
```

### uvx

```bash
uvx mem-brain-mcp
```

## Configuration

```env
API_BASE_URL=https://mem-brain-api-cutover-v4-production.up.railway.app
MEMBRAIN_API_KEY=mb_live_xxx   # optional fallback for single-user local runs
MCP_SERVER_HOST=0.0.0.0
MCP_SERVER_PORT=8100
LOG_LEVEL=INFO
```

## MCP Client Examples

### Cursor (`~/.cursor/mcp.json`)

```json
{
  "mcpServers": {
    "mem-brain": {
      "url": "http://localhost:8100/mcp",
      "headers": {
        "X-API-Key": "mb_live_xxx"
      }
    }
  }
}
```

### Claude Desktop

```json
{
  "mcpServers": {
    "mem-brain": {
      "url": "http://localhost:8100/mcp",
      "headers": {
        "X-API-Key": "mb_live_xxx"
      }
    }
  }
}
```

## Development

```bash
pytest
```

## Build / Publish

```bash
uv build
uv tool run twine upload dist/*
```
