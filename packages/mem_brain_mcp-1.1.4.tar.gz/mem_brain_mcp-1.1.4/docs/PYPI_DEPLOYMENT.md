# Mem-Brain MCP - PyPI Deployment

This guide covers building and publishing the `mem-brain-mcp` package to [PyPI](https://pypi.org).

## Prerequisites

- [PyPI account](https://pypi.org/account/register/)
- [uv](https://github.com/astral-sh/uv) (recommended) or `pip` + `twine` + `build`
- API token from PyPI (for API uploads)

## Setup: PyPI API Token

1. Go to [PyPI Account Settings](https://pypi.org/manage/account/)
2. Create an API token under "API tokens"
3. Configure credentials (choose one):

### Option A: Use token when uploading (recommended)

```bash
# No config needed - twine will prompt for username and password
# Username: __token__
# Password: pypi-AgEIcH...your-token
```

### Option B: Use ~/.pypirc

Create or edit `~/.pypirc`:

```ini
[pypi]
username = __token__
password = pypi-AgEIcH...your-token
```

**Security**: Never commit `.pypirc` to git. Add it to `.gitignore`.

## Deployment Steps

### 1. Update Version

Edit `pyproject.toml` and increment the version:

```toml
[project]
name = "mem-brain-mcp"
version = "1.1.3"  # <- Increment this (e.g., 1.1.2 -> 1.1.3)
```

Follow [semantic versioning](https://semver.org/):
- **Patch** (1.1.2 → 1.1.3): Bug fixes
- **Minor** (1.1.2 → 1.2.0): New features, backward compatible
- **Major** (1.1.2 → 2.0.0): Breaking changes

### 2. Update Default API URL (if changed)

If the production Mem-Brain API URL changes, update `src/mem_brain_mcp/config.py`:

```python
api_base_url: str = "https://mem-brain-api-cutover-v4-production.up.railway.app"
```

And update the example in `README.md` under the Configuration section.

### 3. Build the Package

```bash
cd mem-brain-mcp
uv build
```

Or with standard tools:

```bash
rm -rf dist/*
python -m build
```

This creates:
- `dist/mem_brain_mcp-1.1.3-py3-none-any.whl` (wheel)
- `dist/mem_brain_mcp-1.1.3.tar.gz` (source distribution)

### 4. Upload to PyPI

**Using uv (recommended):**

```bash
uv tool run twine upload dist/*
```

**Using twine directly:**

```bash
twine upload dist/*
```

When prompted:
- Username: `__token__`
- Password: Your PyPI API token

### 5. Verify

```bash
pip index versions mem-brain-mcp
# or
uv pip index versions mem-brain-mcp
```

Or visit: https://pypi.org/project/mem-brain-mcp/

## Quick Deployment (One-Liner)

After updating the version in `pyproject.toml`:

```bash
cd mem-brain-mcp && uv build && uv tool run twine upload dist/*
```

## Full Deployment Checklist

- [ ] Update version in `pyproject.toml`
- [ ] Update `config.py` default API URL if changed
- [ ] Update `README.md` if needed
- [ ] Run tests: `pytest`
- [ ] Build: `uv build`
- [ ] Upload: `uv tool run twine upload dist/*`
- [ ] Verify on PyPI

## Test PyPI (Optional)

Before publishing to production PyPI, test with [TestPyPI](https://test.pypi.org):

```bash
uv tool run twine upload --repository testpypi dist/*
```

Then install from TestPyPI:

```bash
pip install --index-url https://test.pypi.org/simple/ mem-brain-mcp
```

## Troubleshooting

### "Invalid or non-existent authentication information"

- Ensure username is exactly `__token__` (two underscores)
- Use the full API token as password (starts with `pypi-`)

### "File already exists"

- You cannot reuse a version number. Increment the version and rebuild.

### "Version conflict" or "Package already exists"

- PyPI doesn't allow overwriting. Delete the version from PyPI (requires account privileges) or use a new version number.

## CI/CD (GitHub Actions)

For automated publishing on release, add a workflow:

```yaml
# .github/workflows/publish.yml
name: Publish to PyPI
on:
  release:
    types: [published]
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/uv-action@v1
      - run: uv build
      - uses: pypa/gh-action-pypi-publish@release/v1
        with:
          password: ${{ secrets.PYPI_API_TOKEN }}
```

Create `PYPI_API_TOKEN` in your repo's Secrets and add your PyPI token.
