# Mem-Brain MCP Usage

## 1) Start API

```bash
cd /Users/rakshithg/Documents/membrain/mem-brain-api
uvicorn mem_brain_api.main:app --reload
```

## 2) Start MCP server

```bash
cd /Users/rakshithg/Documents/membrain/mem-brain-mcp
export API_BASE_URL=http://localhost:8000
uv run python -m mem_brain_mcp.server
```

## 3) Configure MCP client with API key

```json
{
  "mcpServers": {
    "mem-brain": {
      "url": "http://localhost:8100/mcp",
      "headers": {
        "X-API-Key": "mb_live_xxx"
      }
    }
  }
}
```

## 4) Use tools

- `add_memory`
- `search_memories(query, k=5, keyword_filter?, response_format?)`
  - `response_format`: `"raw"` (default), `"interpreted"` (LLM summary), or `"both"` (summary + raw evidence)
  - Example: `search_memories(query="Who is Maga?", response_format="interpreted")`
- `get_memories`
- `delete_memories`
- `get_stats`
- `find_path`
- `get_neighborhood`

## Notes

- API keys are created from Mem-Brain API: `POST /api/v1/api-keys` with Clerk session auth.
- For CLI-only local runs, you can export `MEMBRAIN_API_KEY=mb_live_xxx`.
