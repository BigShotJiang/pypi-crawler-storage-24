"""Tests for search_memories interpreted/raw/both modes."""

import pytest
from unittest.mock import AsyncMock, patch

from mem_brain_mcp.client import APIClient
from mem_brain_mcp.server import (
    _format_interpreted,
    _format_search_response,
    _format_search_results,
)


# ---------------------------------------------------------------------------
# Client: parameter forwarding
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_client_forwards_response_format():
    """Client passes response_format to API."""
    with patch.object(APIClient, "_request", new_callable=AsyncMock) as mock:
        mock.return_value = {"count": 0, "results": []}
        client = APIClient(api_key="test")
        await client.search_memories("q", k=5, response_format="interpreted")
        mock.assert_called_once()
        call_kw = mock.call_args
        assert call_kw[1]["json"]["response_format"] == "interpreted"


@pytest.mark.asyncio
async def test_client_default_response_format_raw():
    """Client defaults to raw when response_format omitted."""
    with patch.object(APIClient, "_request", new_callable=AsyncMock) as mock:
        mock.return_value = {"count": 0, "results": []}
        client = APIClient(api_key="test")
        await client.search_memories("q")
        call_kw = mock.call_args
        assert call_kw[1]["json"]["response_format"] == "raw"


# ---------------------------------------------------------------------------
# Server formatters
# ---------------------------------------------------------------------------


def test_format_interpreted_success():
    """Interpreted formatter renders summary."""
    interp = {
        "answer_summary": "User likes Python",
        "confidence": "high",
        "key_facts": ["fact1", "fact2"],
        "important_relationships": [],
        "conflicts_or_uncertainties": [],
    }
    out = _format_interpreted(interp, None)
    assert "--- Interpreted Summary ---" in out
    assert "User likes Python" in out
    assert "fact1" in out
    assert "fact2" in out


def test_format_interpreted_error():
    """Interpreted formatter surfaces interpreted_error."""
    out = _format_interpreted(None, "LLM failed")
    assert "⚠ Interpreted summary unavailable" in out
    assert "LLM failed" in out


def test_format_interpreted_empty():
    """Interpreted formatter handles missing interpreted."""
    out = _format_interpreted(None, None)
    assert "No interpreted summary available" in out


def test_format_search_results_raw():
    """Raw formatter renders memory nodes."""
    results = [
        {
            "type": "memory_node",
            "semantic_score": 0.9,
            "id": "m1",
            "content": "test content",
            "tags": [],
            "context": "General",
            "links": [],
        }
    ]
    out = _format_search_results(results)
    assert "Memory Node" in out
    assert "0.900" in out
    assert "test content" in out


# ---------------------------------------------------------------------------
# Server _format_search_response: raw default, both, interpreted_error
# ---------------------------------------------------------------------------


def test_format_search_response_raw_default():
    """Default raw mode returns formatted results."""
    result = {
        "count": 1,
        "results": [
            {
                "type": "memory_node",
                "semantic_score": 0.9,
                "id": "m1",
                "content": "content",
                "tags": [],
                "context": "General",
                "links": [],
            }
        ],
    }
    out = _format_search_response(result, "raw")
    assert "Found 1 results" in out
    assert "Memory Node" in out


def test_format_search_response_both_mode():
    """Both mode returns interpreted first, then raw evidence."""
    result = {
        "count": 1,
        "results": [
            {
                "type": "memory_node",
                "semantic_score": 0.9,
                "id": "m1",
                "content": "raw content",
                "tags": [],
                "context": "General",
                "links": [],
            }
        ],
        "interpreted": {
            "answer_summary": "User likes Python",
            "confidence": "high",
            "key_facts": [],
            "important_relationships": [],
            "conflicts_or_uncertainties": [],
        },
    }
    out = _format_search_response(result, "both")
    assert "--- Interpreted Summary ---" in out
    assert "User likes Python" in out
    assert "--- Raw Evidence ---" in out
    assert "raw content" in out


def test_format_search_response_interpreted_error_surfaces():
    """interpreted_error is surfaced; raw evidence shown when present."""
    result = {
        "count": 1,
        "results": [
            {
                "type": "memory_node",
                "semantic_score": 0.9,
                "id": "m1",
                "content": "fallback raw",
                "tags": [],
                "context": "General",
                "links": [],
            }
        ],
        "interpreted_error": "LLM summarization failed",
    }
    out = _format_search_response(result, "interpreted")
    assert "⚠ Interpreted summary unavailable" in out
    assert "LLM summarization failed" in out
    assert "Raw evidence" in out
    assert "fallback raw" in out


def test_format_search_response_interpreted_no_false_empty():
    """Interpreted mode does not say 'no memories' when interpreted exists (results empty)."""
    result = {
        "count": 0,
        "results": [],
        "interpreted": {
            "answer_summary": "No relevant memories for this query.",
            "confidence": "low",
            "key_facts": [],
            "important_relationships": [],
            "conflicts_or_uncertainties": [],
        },
    }
    out = _format_search_response(result, "interpreted")
    assert "No relevant memories" in out or "Interpreted Summary" in out
    assert "No memories found matching" not in out
