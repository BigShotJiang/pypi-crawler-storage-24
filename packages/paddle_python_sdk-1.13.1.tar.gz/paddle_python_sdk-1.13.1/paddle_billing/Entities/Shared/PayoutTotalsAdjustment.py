from __future__ import annotations
from dataclasses import dataclass
from typing import Any

from paddle_billing.Entities.Shared.ChargebackFee import ChargebackFee
from paddle_billing.Entities.Shared.CurrencyCodePayouts import CurrencyCodePayouts


@dataclass
class PayoutTotalsAdjustment:
    subtotal: str
    tax: str
    total: str
    fee: str
    chargeback_fee: ChargebackFee | None
    earnings: str
    currency_code: CurrencyCodePayouts
    retained_fee: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> PayoutTotalsAdjustment:
        return PayoutTotalsAdjustment(
            subtotal=data["subtotal"],
            tax=data["tax"],
            total=data["total"],
            fee=data["fee"],
            chargeback_fee=ChargebackFee.from_dict(data["chargeback_fee"]) if data.get("chargeback_fee") else None,
            earnings=data["earnings"],
            currency_code=CurrencyCodePayouts(data["currency_code"]),
            retained_fee=data["retained_fee"],
        )
