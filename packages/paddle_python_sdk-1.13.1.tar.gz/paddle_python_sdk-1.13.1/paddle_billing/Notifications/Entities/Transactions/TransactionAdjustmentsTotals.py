from __future__ import annotations
from dataclasses import dataclass
from typing import Any

from paddle_billing.Notifications.Entities.Shared.CurrencyCode import CurrencyCode

from paddle_billing.Notifications.Entities.Transactions.TransactionBreakdown import TransactionBreakdown


@dataclass
class TransactionAdjustmentsTotals:
    subtotal: str
    tax: str
    total: str
    fee: str
    earnings: str
    breakdown: TransactionBreakdown
    currency_code: CurrencyCode

    @staticmethod
    def from_dict(data: dict[str, Any]) -> TransactionAdjustmentsTotals:
        return TransactionAdjustmentsTotals(
            subtotal=data["subtotal"],
            tax=data["tax"],
            total=data["total"],
            fee=data["fee"],
            earnings=data["earnings"],
            breakdown=TransactionBreakdown.from_dict(data["breakdown"]),
            currency_code=CurrencyCode(data["currency_code"]),
        )
