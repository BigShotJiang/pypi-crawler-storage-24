from __future__ import annotations
from dataclasses import dataclass
from typing import Any

from paddle_billing.Notifications.Entities.Shared.CurrencyCode import CurrencyCode


@dataclass
class TransactionTotalsAdjusted:
    subtotal: str
    tax: str
    total: str
    grand_total: str
    fee: str | None
    earnings: str | None
    currency_code: CurrencyCode
    retained_fee: str | None
    grand_total_tax: str | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> TransactionTotalsAdjusted:
        return TransactionTotalsAdjusted(
            subtotal=data["subtotal"],
            tax=data["tax"],
            total=data["total"],
            grand_total=data["grand_total"],
            fee=data.get("fee"),
            earnings=data.get("earnings"),
            currency_code=CurrencyCode(data["currency_code"]),
            retained_fee=data.get("retained_fee"),
            grand_total_tax=data.get("grand_total_tax"),
        )
