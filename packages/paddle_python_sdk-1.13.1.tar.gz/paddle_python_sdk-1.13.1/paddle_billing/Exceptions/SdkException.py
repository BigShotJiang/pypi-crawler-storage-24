class SdkException(Exception):
    pass
