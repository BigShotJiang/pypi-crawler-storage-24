"""Tests for the Menda CodeArtifact keyring backend."""

from unittest.mock import patch

import pytest

from menda.error.exceptions import MendaKeyRingError
from menda.keyring.backend import MendaCodeArtifactKeyring


class TestURLMatching:
    """Test CodeArtifact URL detection."""

    @pytest.fixture
    def backend(self):
        return MendaCodeArtifactKeyring()

    @pytest.mark.parametrize(
        "url",
        [
            "https://menda-private-058264169513.d.codeartifact.eu-west-1.amazonaws.com/pypi/menda-plugins/simple/",
            "https://my-domain-123456789.d.codeartifact.us-east-1.amazonaws.com/pypi/repo/simple/",
        ],
    )
    def test_is_codeartifact_url_matches_valid_urls(self, backend, url):
        assert backend._is_codeartifact_url(url) is True

    @pytest.mark.parametrize(
        "url",
        [
            "https://pypi.org/simple/",
            "https://example.com/pypi/repo/simple/",
            "https://codeartifact.amazonaws.com/wrong-pattern",
        ],
    )
    def test_is_codeartifact_url_rejects_non_codeartifact(self, backend, url):
        assert backend._is_codeartifact_url(url) is False

    def test_get_password_returns_none_for_non_codeartifact_url(self, backend):
        result = backend.get_password("https://pypi.org/simple/", "user")
        assert result is None


class TestTokenExchange:
    """Test the menda auth → CodeArtifact token exchange."""

    @pytest.fixture
    def backend(self):
        return MendaCodeArtifactKeyring()

    @patch("menda.keyring.backend.resolve_and_get_registry_token")
    def test_get_password_returns_codeartifact_token(self, mock_resolve, backend):
        mock_resolve.return_value = "ca-token-xyz"

        url = "https://menda-private-058264169513.d.codeartifact.eu-west-1.amazonaws.com/pypi/menda-plugins/simple/"
        result = backend.get_password(url, "aws")

        assert result == "ca-token-xyz"
        mock_resolve.assert_called_once()

    @patch("menda.keyring.backend.resolve_and_get_registry_token")
    def test_get_password_raises_on_unexpected_auth_failure(self, mock_resolve, backend):
        mock_resolve.side_effect = RuntimeError("Auth failed")

        url = "https://menda-private-058264169513.d.codeartifact.eu-west-1.amazonaws.com/pypi/menda-plugins/simple/"

        with pytest.raises(MendaKeyRingError, match="Auth failed"):
            backend.get_password(url, "aws")


class TestKeyringInterface:
    """Test that the keyring interface contract is satisfied."""

    def test_has_priority(self):
        backend = MendaCodeArtifactKeyring()
        assert hasattr(backend, "priority")

    def test_set_password_is_noop(self):
        backend = MendaCodeArtifactKeyring()
        backend.set_password("https://example.com", "user", "pass")

    def test_delete_password_is_noop(self):
        backend = MendaCodeArtifactKeyring()
        backend.delete_password("https://example.com", "user")
