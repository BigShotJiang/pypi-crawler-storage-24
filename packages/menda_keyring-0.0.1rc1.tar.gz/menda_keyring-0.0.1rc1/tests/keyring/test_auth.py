"""Tests for the lightweight menda auth module."""

import configparser
import os
import time
from unittest.mock import MagicMock, patch

import pytest

from menda.error.exceptions import (
    InvalidCachedTokenError,
    MendaCloudAPIError,
    NoCachedLoginError,
    ProfileNotFoundError,
)
from menda.keyring.auth import (
    _load_cached_token,
    _load_profile,
    exchange_for_registry_token,
    get_menda_access_token,
    resolve_and_get_registry_token,
)


class TestGetMendaAccessToken:
    """Test M2M token acquisition."""

    @patch("menda.keyring.auth.requests.post")
    def test_m2m_flow_returns_access_token(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.json.return_value = {
            "access_token": "menda-access-token-123",
            "token_type": "Bearer",
        }
        mock_post.return_value = mock_resp

        token = get_menda_access_token(
            host="https://api.menda.cloud",
            client_id="test-client-id",
            client_secret="test-client-secret",  # noqa: S106
        )

        assert token == "menda-access-token-123"  # noqa: S105
        mock_post.assert_called_once()
        call_kwargs = mock_post.call_args
        assert "oauth2/token" in call_kwargs[0][0] or "oauth2/token" in str(call_kwargs)

    @patch("menda.keyring.auth.requests.post")
    def test_m2m_flow_raises_on_http_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 401
        mock_resp.text = "Unauthorized"
        mock_post.return_value = mock_resp

        with pytest.raises(MendaCloudAPIError, match="oauth2/token"):
            get_menda_access_token(
                host="https://api.menda.cloud",
                client_id="bad-id",
                client_secret="bad-secret",  # noqa: S106
            )


class TestExchangeForRegistryToken:
    """Test registry token exchange."""

    @patch("menda.keyring.auth.requests.post")
    def test_returns_codeartifact_token(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.json.return_value = {
            "token": "ca-token-xyz",
            "expiry": "2026-03-22T14:30:00+00:00",
            "repositories": [{"name": "menda-plugins", "index_url": "https://..."}],
        }
        mock_post.return_value = mock_resp

        token = exchange_for_registry_token(
            host="https://api.menda.cloud",
            access_token="menda-access-token-123",  # noqa: S106
        )

        assert token == "ca-token-xyz"  # noqa: S105

    @patch("menda.keyring.auth.requests.post")
    def test_raises_on_http_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 403
        mock_resp.text = "Forbidden"
        mock_post.return_value = mock_resp

        with pytest.raises(MendaCloudAPIError, match="registry/token"):
            exchange_for_registry_token(
                host="https://api.menda.cloud",
                access_token="bad-token",  # noqa: S106
            )


class TestLoadProfile:
    """Test profile loading from mendacfg."""

    def test_loads_u2m_profile(self, tmp_path):
        mendacfg = tmp_path / "mendacfg"
        mendacfg.write_text("[default]\nhost = https://api.menda.cloud\nauth_type = u2m\n")

        with patch("menda.keyring.auth.MENDA_CONFIG_FOLDER", tmp_path):
            profile = _load_profile("default")

        assert profile["host"] == "https://api.menda.cloud"
        assert profile["auth_type"] == "u2m"

    def test_loads_m2m_profile(self, tmp_path):
        mendacfg = tmp_path / "mendacfg"
        mendacfg.write_text(
            "[ci-runner]\nhost = https://api.menda.cloud\n"
            "auth_type = m2m\nclient_id = my-id\nclient_secret = my-secret\n"
        )

        with patch("menda.keyring.auth.MENDA_CONFIG_FOLDER", tmp_path):
            profile = _load_profile("ci-runner")

        assert profile["auth_type"] == "m2m"
        assert profile["client_id"] == "my-id"

    def test_raises_when_config_missing(self, tmp_path):
        with (
            patch("menda.keyring.auth.MENDA_CONFIG_FOLDER", tmp_path),
            pytest.raises(FileNotFoundError, match="config file not found"),
        ):
            _load_profile("default")

    def test_raises_when_profile_not_found(self, tmp_path):
        mendacfg = tmp_path / "mendacfg"
        mendacfg.write_text("[other]\nhost = https://api.menda.cloud\n")

        with (
            patch("menda.keyring.auth.MENDA_CONFIG_FOLDER", tmp_path),
            pytest.raises(ProfileNotFoundError, match="No profile"),
        ):
            _load_profile("default")


class TestLoadCachedToken:
    """Test token cache loading."""

    def test_returns_token_when_cached_and_valid(self, tmp_path):
        cache_dir = tmp_path / "tokens" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / ".token"

        parser = configparser.ConfigParser()
        parser["default"] = {
            "access_token": "cached-access-token",
            "expires_in": "3600",
            "cached_at": str(time.time()),
            "token_type": "Bearer",
        }
        with open(cache_file, "w") as f:
            parser.write(f)

        with patch("menda.keyring.auth.TOKENS_CACHE_PATH", cache_file):
            result = _load_cached_token("default")

        assert result == "cached-access-token"

    def test_returns_none_when_expired(self, tmp_path):
        cache_dir = tmp_path / "tokens" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / ".token"

        parser = configparser.ConfigParser()
        parser["default"] = {
            "access_token": "old-token",
            "expires_in": "3600",
            "cached_at": str(time.time() - 4000),
            "token_type": "Bearer",
        }
        with open(cache_file, "w") as f:
            parser.write(f)

        with patch("menda.keyring.auth.TOKENS_CACHE_PATH", cache_file):
            result = _load_cached_token("default")

        assert result is None

    def test_raises_invalid_cached_token_when_timestamps_unparseable(self, tmp_path):
        cache_dir = tmp_path / "tokens" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / ".token"

        parser = configparser.ConfigParser()
        parser["default"] = {
            "access_token": "cached-access-token",
            "expires_in": "not-a-number",
            "cached_at": "also-bad",
            "token_type": "Bearer",
        }
        with open(cache_file, "w") as f:
            parser.write(f)

        with (
            patch("menda.keyring.auth.TOKENS_CACHE_PATH", cache_file),
            pytest.raises(
                InvalidCachedTokenError,
                match="invalid cached_at",
            ),
        ):
            _load_cached_token("default")

    def test_returns_none_when_no_cache_file(self, tmp_path):
        with patch("menda.keyring.auth.TOKENS_CACHE_PATH", tmp_path / "nonexistent"):
            result = _load_cached_token("default")

        assert result is None


class TestResolveAndGetRegistryToken:
    """Test the main entry point that picks M2M env vars / M2M profile / U2M."""

    @patch("menda.keyring.auth._load_cached_token", return_value=None)
    @patch("menda.keyring.auth.exchange_for_registry_token", return_value="ca-token")
    @patch("menda.keyring.auth.get_menda_access_token", return_value="menda-token")
    def test_path1_m2m_env_vars(self, mock_get, mock_exchange, mock_cache):
        env = {
            "MENDA_CLIENT_ID": "id",
            "MENDA_CLIENT_SECRET": "secret",
            "MENDA_HOST": "https://api.menda.cloud",
        }
        with patch.dict(os.environ, env, clear=False):
            result = resolve_and_get_registry_token()

        assert result == "ca-token"
        mock_get.assert_called_once_with("https://api.menda.cloud", "id", "secret")

    @patch("menda.keyring.auth._load_cached_token", return_value=None)
    @patch("menda.keyring.auth.exchange_for_registry_token", return_value="ca-token")
    @patch("menda.keyring.auth.get_menda_access_token", return_value="menda-token")
    @patch("menda.keyring.auth._load_profile")
    def test_path2_m2m_profile(self, mock_profile, mock_get, mock_exchange, mock_cache):
        mock_profile.return_value = {
            "host": "https://api.menda.cloud",
            "auth_type": "m2m",
            "client_id": "profile-id",
            "client_secret": "profile-secret",
        }

        with patch.dict(os.environ, {}, clear=False):
            for k in ("MENDA_CLIENT_ID", "MENDA_CLIENT_SECRET", "MENDA_HOST"):
                os.environ.pop(k, None)
            result = resolve_and_get_registry_token()

        assert result == "ca-token"
        mock_get.assert_called_once_with("https://api.menda.cloud", "profile-id", "profile-secret")

    @patch("menda.keyring.auth._load_cached_token", return_value="cached-u2m-token")
    @patch("menda.keyring.auth.exchange_for_registry_token", return_value="ca-token")
    @patch("menda.keyring.auth._load_profile")
    def test_path3_u2m_cached_token(self, mock_profile, mock_exchange, mock_cache):
        mock_profile.return_value = {
            "host": "https://api.menda.cloud",
            "auth_type": "u2m",
        }

        with patch.dict(os.environ, {}, clear=False):
            for k in ("MENDA_CLIENT_ID", "MENDA_CLIENT_SECRET", "MENDA_HOST"):
                os.environ.pop(k, None)
            result = resolve_and_get_registry_token()

        assert result == "ca-token"
        mock_exchange.assert_called_once_with("https://api.menda.cloud", "cached-u2m-token")

    @patch("menda.keyring.auth._load_cached_token", return_value=None)
    @patch("menda.keyring.auth._load_profile")
    def test_path3_u2m_no_cached_token_raises(self, mock_profile, mock_cache):
        mock_profile.return_value = {
            "host": "https://api.menda.cloud",
            "auth_type": "u2m",
        }

        with patch.dict(os.environ, {}, clear=False):
            for k in ("MENDA_CLIENT_ID", "MENDA_CLIENT_SECRET", "MENDA_HOST"):
                os.environ.pop(k, None)
            with pytest.raises(NoCachedLoginError, match="menda auth login"):
                resolve_and_get_registry_token()
