# menda-keyring
A python package used to bootstrap menda projects authentication with private repositories.
