"""Error types and handling for menda bootstrap package."""
