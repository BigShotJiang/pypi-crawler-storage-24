"""Typed errors for menda-keyring.

Each subclass has a one-line ``__doc__`` used as the default message when ``message``
is omitted. Use ``status_code`` for an optional HTTP status (available as ``.status_code``,
not appended to ``str(exception)``).
"""

from __future__ import annotations


def _first_line_doc(cls: type[Exception]) -> str:
    raw = (cls.__doc__ or "").strip()
    if not raw:
        return cls.__name__.replace("Error", " error").replace("_", " ") + "."
    return raw.split("\n", 1)[0].strip()


class ErrorMixIn(Exception):
    """MixIn for all exceptions in menda-keyring package."""

    def __init__(
        self,
        message: str | None = None,
        *,
        status_code: int | None = None,
    ) -> None:
        """Initialize the exception.

        Args:
            message: Full message; if omitted, the subclass docstring first line is used.
            status_code: Optional HTTP status code (stored on ``self.status_code`` only).

        """
        self.status_code = status_code
        if message is None:
            message = _first_line_doc(type(self))
        super().__init__(message)


class MendaKeyRingError(ErrorMixIn):
    """Could not obtain CodeArtifact credentials for pip or uv via Menda."""


class ProfileWithoutHostError(ErrorMixIn):
    """Profile is missing a 'host' value pointing at your menda-cloud API."""


class M2MProfileWithoutClientCredentialsError(ErrorMixIn):
    """Machine-to-machine profile is missing client_id and/or client_secret."""


class InvalidCachedTokenError(ErrorMixIn):
    """Cached token file is invalid or unreadable."""


class NoCachedLoginError(ErrorMixIn):
    """No valid cached login for this profile; sign in again."""


class MendaCloudAPIError(ErrorMixIn):
    """A request to the menda-cloud API failed."""


class ProfileNotFoundError(ErrorMixIn):
    """That profile name is not defined in your mendacfg file."""
