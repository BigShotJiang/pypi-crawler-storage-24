"""Lightweight authentication for menda-cloud APIs.

This module uses only `requests` — no dependency on menda-core.
Mirrors the resolution logic in menda.auth.task.resolve_auth_config().

Three auth paths:
1. M2M via env vars: MENDA_CLIENT_ID + MENDA_CLIENT_SECRET + MENDA_HOST
2. M2M via profile: mendacfg profile with auth_type=m2m, client_id, client_secret
3. U2M via profile: mendacfg profile with auth_type=u2m, cached device-flow token
"""

from __future__ import annotations

import configparser
import os
import time
from pathlib import Path

import requests

from menda.error.exceptions import (
    InvalidCachedTokenError,
    M2MProfileWithoutClientCredentialsError,
    MendaCloudAPIError,
    NoCachedLoginError,
    ProfileNotFoundError,
    ProfileWithoutHostError,
)

MENDA_CONFIG_FOLDER = Path.home() / ".menda"
TOKENS_CACHE_PATH = MENDA_CONFIG_FOLDER / "tokens" / "cache" / ".token"


def get_menda_access_token(
    host: str,
    client_id: str,
    client_secret: str,
) -> str:
    """Exchange M2M client credentials for a menda access token."""
    url = f"{host.rstrip('/')}/api/v1/auth/oauth2/token"
    resp = requests.post(
        url,
        params={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        },
        timeout=30,
    )
    if not resp.ok:
        snippet = (resp.text or "")[:800]
        raise MendaCloudAPIError(
            message=f"oauth2/token returned HTTP {resp.status_code}: {snippet}",
            status_code=resp.status_code,
        )
    return resp.json()["access_token"]


def _load_profile(profile_id: str) -> dict[str, str]:
    """Load a profile section from ~/.menda/mendacfg."""
    mendacfg_path = MENDA_CONFIG_FOLDER / "mendacfg"
    if not mendacfg_path.exists():
        raise FileNotFoundError(f"Menda config file not found at {mendacfg_path}. Run 'menda auth configure' first.")

    config = configparser.ConfigParser()
    config.read(mendacfg_path)

    if profile_id not in config:
        raise ProfileNotFoundError(
            message=f"No profile {profile_id!r} in {mendacfg_path}. Set MENDA_PROFILE_ID or add a [{profile_id}] section.",
        )

    return dict(config[profile_id])


def _load_cached_token(cache_key: str) -> str | None:
    """Load a non-expired cached token from the token cache file.

    The cache file is a configparser file at ~/.menda/tokens/cache/.token.
    Each section is keyed by profile_id (or client_id for env-var M2M).

    Returns:
        The access token string, or None if not cached or expired.

    """
    if not TOKENS_CACHE_PATH.exists():
        return None

    parser = configparser.ConfigParser()
    parser.read(TOKENS_CACHE_PATH)

    if cache_key not in parser:
        return None

    section = parser[cache_key]
    cached_at = section.get("cached_at", "")
    expires_in = section.get("expires_in", "")

    if cached_at and expires_in:
        try:
            elapsed = time.time() - float(cached_at)
            if elapsed >= (float(expires_in) - 60):
                return None
        except (ValueError, TypeError) as exc:
            raise InvalidCachedTokenError(
                message=f"Token cache key {cache_key!r} in {TOKENS_CACHE_PATH} has invalid cached_at/expires_in; "
                f"delete the file or run 'menda auth login' again.",
            ) from exc

    token = section.get("id_token") or section.get("access_token")
    return token if token else None


def exchange_for_registry_token(host: str, access_token: str) -> str:
    """Exchange a menda access token for a CodeArtifact registry token."""
    url = f"{host.rstrip('/')}/api/v1/auth/registry/token"
    resp = requests.post(
        url,
        headers={
            "authorizationToken": f"Bearer {access_token}",
            "Content-Type": "application/json",
        },
        timeout=30,
    )
    if not resp.ok:
        snippet = (resp.text or "")[:800]
        raise MendaCloudAPIError(
            message=f"registry/token returned HTTP {resp.status_code}: {snippet}",
            status_code=resp.status_code,
        )
    return resp.json()["token"]


def resolve_and_get_registry_token() -> str:
    """Resolve auth method and return a CodeArtifact token.

    Resolution order:
    1. If MENDA_CLIENT_ID, MENDA_CLIENT_SECRET, MENDA_HOST env vars all set → M2M via env vars.
    2. Load profile from mendacfg using MENDA_PROFILE_ID (default: "default"):
       - auth_type=m2m → M2M via profile (on-demand token exchange, with cache).
       - auth_type=u2m → U2M via cached device-flow token.
    """
    client_id = os.environ.get("MENDA_CLIENT_ID")
    client_secret = os.environ.get("MENDA_CLIENT_SECRET")
    host = os.environ.get("MENDA_HOST")

    # Path 1: M2M via env vars
    if client_id and client_secret and host:
        cached = _load_cached_token(client_id)
        if cached:
            return exchange_for_registry_token(host, cached)
        access_token = get_menda_access_token(host, client_id, client_secret)
        return exchange_for_registry_token(host, access_token)

    # Load profile
    profile_id = os.environ.get("MENDA_PROFILE_ID", "default")
    profile = _load_profile(profile_id)

    profile_host = profile.get("host")
    if not profile_host:
        raise ProfileWithoutHostError(
            message=f"Profile {profile_id!r} has no host; set host = https://... in ~/.menda/mendacfg.",
        )

    auth_type = profile.get("auth_type", "u2m")

    # Path 2: M2M via profile
    if auth_type == "m2m":
        profile_client_id = profile.get("client_id")
        profile_client_secret = profile.get("client_secret")
        if not profile_client_id or not profile_client_secret:
            raise M2MProfileWithoutClientCredentialsError(
                message=f"Profile {profile_id!r} has auth_type=m2m but is missing client_id or client_secret in mendacfg.",
            )
        cached = _load_cached_token(profile_id)
        if cached:
            return exchange_for_registry_token(profile_host, cached)
        access_token = get_menda_access_token(profile_host, profile_client_id, profile_client_secret)
        return exchange_for_registry_token(profile_host, access_token)

    # Path 3: U2M via cached token
    cached = _load_cached_token(profile_id)
    if not cached:
        raise NoCachedLoginError(
            message=f"No valid cached token for profile {profile_id!r}. Run `menda auth login` or use M2M (env vars or auth_type=m2m).",
        )
    return exchange_for_registry_token(profile_host, cached)
