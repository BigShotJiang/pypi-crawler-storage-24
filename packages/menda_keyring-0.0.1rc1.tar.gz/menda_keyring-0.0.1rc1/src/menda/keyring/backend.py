"""Menda CodeArtifact keyring backend.

Discovered by the `keyring` library via the entry point in pyproject.toml.
When `uv` needs credentials for a CodeArtifact URL, it calls
`keyring get <url> <username>` which invokes this backend.
"""

from __future__ import annotations

import re

from keyring.backend import KeyringBackend

from menda.error.exceptions import ErrorMixIn, MendaKeyRingError
from menda.keyring.auth import resolve_and_get_registry_token

_CODEARTIFACT_URL_PATTERN = re.compile(r"\.d\.codeartifact\.[a-z0-9-]+\.amazonaws\.com")


class MendaCodeArtifactKeyring(KeyringBackend):
    """Keyring backend that vends CodeArtifact tokens via menda-cloud."""

    priority = 10

    @staticmethod
    def _is_codeartifact_url(url: str) -> bool:
        """Check if the URL is an AWS CodeArtifact URL."""
        return bool(_CODEARTIFACT_URL_PATTERN.search(url))

    def get_password(self, service: str, username: str) -> str | None:
        """Return a CodeArtifact token for the given URL, or None."""
        if not self._is_codeartifact_url(service):
            return None

        try:
            return resolve_and_get_registry_token()
        except ErrorMixIn:
            raise
        except Exception as exc:
            raise MendaKeyRingError(
                message=str(exc) or repr(exc),
            ) from exc

    def set_password(self, service: str, username: str, password: str) -> None:
        """No-op. We never write credentials."""

    def delete_password(self, service: str, username: str) -> None:
        """No-op. We never delete credentials."""
