"""Tests for distance module."""
