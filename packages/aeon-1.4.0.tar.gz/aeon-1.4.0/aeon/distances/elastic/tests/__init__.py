"""Elastic distance tests."""
