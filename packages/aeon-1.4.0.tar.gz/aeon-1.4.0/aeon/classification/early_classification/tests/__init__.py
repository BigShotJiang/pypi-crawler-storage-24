"""Early classification test code."""
