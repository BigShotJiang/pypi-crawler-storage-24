"""Ordinal classifier tests."""
