"""sklearn classifier test code."""
