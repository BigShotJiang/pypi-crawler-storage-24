"""Kernel based test code."""
