"""Deep learning networks tests."""
