"""Tests for pipeline utilities."""
