"""Machine learning forecaster tests."""
