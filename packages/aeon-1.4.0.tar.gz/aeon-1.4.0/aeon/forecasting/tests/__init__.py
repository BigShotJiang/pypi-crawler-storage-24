"""Forecaster tests."""
