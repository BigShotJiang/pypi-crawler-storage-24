"""Stats forecaster tests."""
