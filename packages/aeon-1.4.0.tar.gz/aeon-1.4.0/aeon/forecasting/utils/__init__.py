"""Utils for forecasting."""
