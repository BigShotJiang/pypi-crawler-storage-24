"""£Forecasting utils tests."""
