"""Outlier based test code."""
