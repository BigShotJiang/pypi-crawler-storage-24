"""Distance based test code."""
