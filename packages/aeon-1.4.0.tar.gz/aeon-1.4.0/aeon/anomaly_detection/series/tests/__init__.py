"""Tests for anomaly detection."""
