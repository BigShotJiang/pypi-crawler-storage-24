"""ROCKAD anomaly detector."""

__maintainer__ = []
__all__ = ["ROCKAD"]

import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import PowerTransformer
from sklearn.utils import check_random_state, resample

from aeon.anomaly_detection.collection.base import BaseCollectionAnomalyDetector
from aeon.transformations.collection.convolution_based import Rocket
from aeon.utils.validation import check_n_jobs


class ROCKAD(BaseCollectionAnomalyDetector):
    """
    ROCKET-based whole-series Anomaly Detector (ROCKAD).

    ROCKAD [1]_ leverages the ROCKET transformation for feature extraction from
    time series data and applies the scikit learn k-nearest neighbors (k-NN)
    approach with bootstrap aggregation for robust semi-supervised anomaly detection.
    The data gets transformed into the ROCKET feature space.
    Then the whole-series are compared based on the feature space by
    finding the nearest neighbours.

    This class supports both univariate and multivariate time series and
    provides options for normalizing features, applying power transformations,
    and customizing the distance metric.

    Parameters
    ----------
    n_estimators : int, default=10
        Number of k-NN estimators to use in the bootstrap aggregation.
    n_kernels : int, default=100
        Number of kernels to use in the ROCKET transformation.
    normalise : bool, default=False
        Whether to normalize the ROCKET-transformed features.
    n_neighbors : int, default=5
        Number of neighbors to use for the k-NN algorithm.
    n_jobs : int, default=1
        Number of parallel jobs to use for the k-NN algorithm and ROCKET transformation.
    metric : str, default="euclidean"
        Distance metric to use for the k-NN algorithm.
    power_transform : bool, default=True
        Whether to apply a power transformation (Yeo-Johnson) to the features.
    random_state : int, default=None
        Random seed for reproducibility.

    Attributes
    ----------
    rocket_transformer_ : Optional[Rocket]
        Instance of the ROCKET transformer used to extract features, set after fitting.
    list_baggers_ : Optional[list[NearestNeighbors]]
        List containing k-NN estimators used for anomaly scoring, set after fitting.
    power_transformer_ : PowerTransformer
        Transformer used to apply power transformation to the features.

    References
    ----------
    .. [1] Theissler, A., Wengert, M., Gerschner, F. (2023).
        ROCKAD: Transferring ROCKET to Whole Time Series Anomaly Detection.
        In: Crémilleux, B., Hess, S., Nijssen, S. (eds) Advances in Intelligent
        Data Analysis XXI. IDA 2023. Lecture Notes in Computer Science,
        vol 13876. Springer, Cham. https://doi.org/10.1007/978-3-031-30047-9_33

    Examples
    --------
    >>> import numpy as np
    >>> from aeon.anomaly_detection.collection import ROCKAD
    >>> rng = np.random.default_rng(seed=42)
    >>> X_train = rng.normal(loc=0.0, scale=1.0, size=(10, 100))
    >>> X_test = rng.normal(loc=0.0, scale=1.0, size=(5, 100))
    >>> X_test[4][50:58] -= 5
    >>> detector = ROCKAD() # doctest: +SKIP
    >>> detector.fit(X_train) # doctest: +SKIP
    >>> detector.predict(X_test) # doctest: +SKIP
        array([0.        , 0.00554713, 0.06990941, 0.22881059, 0.32382585,
            0.43652154, 0.43652154, 0.43652154, 0.43652154, 0.43652154,
            0.43652154, 0.43652154, 0.43652154, 0.43652154, 0.43652154,
            0.52382585, 0.65200875, 0.80313368, 0.85194344, 1.        ])
    """

    _tags = {
        "anomaly_output_type": "anomaly_scores",
        "learning_type:semi_supervised": True,
        "capability:univariate": True,
        "capability:multivariate": True,
        "capability:missing_values": False,
        "capability:multithreading": True,
        "fit_is_empty": False,
    }

    def __init__(
        self,
        n_estimators=10,
        n_kernels=100,
        normalise=False,
        n_neighbors=5,
        metric="euclidean",
        power_transform=True,
        n_jobs=1,
        random_state=None,
    ):

        self.n_estimators = n_estimators
        self.n_kernels = n_kernels
        self.normalise = normalise
        self.n_neighbors = n_neighbors
        self.n_jobs = n_jobs
        self.metric = metric
        self.power_transform = power_transform
        self.random_state = random_state

        self.rocket_transformer_: Rocket | None = None
        self.list_baggers_: list[NearestNeighbors] | None = None
        self.power_transformer_: PowerTransformer | None = None

        super().__init__()

    def _fit(self, X: np.ndarray, y: np.ndarray | None = None):
        self._n_jobs = check_n_jobs(self.n_jobs)
        rng = check_random_state(self.random_state)

        self.rocket_transformer_ = Rocket(
            n_kernels=self.n_kernels,
            normalise=self.normalise,
            n_jobs=self._n_jobs,
            random_state=rng.randint(np.iinfo(np.int32).max),
        )
        # XT: (n_cases, n_kernels*2)
        Xt = self.rocket_transformer_.fit_transform(X)
        Xt = Xt.astype(np.float64)

        if self.power_transform:
            self.power_transformer_ = PowerTransformer()
            Xtp = self.power_transformer_.fit_transform(Xt)
        else:
            Xtp = Xt

        self.list_baggers_ = []

        for _ in range(self.n_estimators):
            # Initialize estimator
            estimator = NearestNeighbors(
                n_neighbors=self.n_neighbors,
                n_jobs=self._n_jobs,
                metric=self.metric,
                algorithm="kd_tree",
            )
            # Bootstrap Aggregation
            Xtp_scaled_sample = resample(
                Xtp,
                replace=True,
                n_samples=None,
                random_state=rng.randint(np.iinfo(np.int32).max),
                stratify=None,
            )

            # Fit estimator and append to estimator list
            estimator.fit(Xtp_scaled_sample)
            self.list_baggers_.append(estimator)

    def _predict(self, X) -> np.ndarray:
        """
        Return the anomaly scores for the input data.

        Parameters
        ----------
            X (array-like): The input data.

        Returns
        -------
            np.ndarray: The predicted probabilities.
        """
        y_scores = np.zeros((len(X), self.n_estimators))
        # Transform into rocket feature space
        # XT: (n_cases, n_kernels*2)
        Xt = self.rocket_transformer_.transform(X)

        Xt = Xt.astype(np.float64)

        if self.power_transform:
            Xtp = self.power_transformer_.transform(Xt)
        else:
            Xtp = Xt

        for idx, bagger in enumerate(self.list_baggers_):
            # Get scores from each estimator
            distances, _ = bagger.kneighbors(Xtp)

            # Compute mean distance of nearest points in window
            scores = distances.mean(axis=1).reshape(-1, 1)
            scores = scores.squeeze()

            y_scores[:, idx] = scores

        # Average the scores to get the final score for each whole-series
        collection_anomaly_scores = y_scores.mean(axis=1)

        return collection_anomaly_scores
