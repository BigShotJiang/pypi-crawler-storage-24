"""Test anomaly detection."""
