"""Tests for clustering."""
