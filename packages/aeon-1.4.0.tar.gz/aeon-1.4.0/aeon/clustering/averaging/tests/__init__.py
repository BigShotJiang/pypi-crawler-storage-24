"""Tests for clustering metrics."""
