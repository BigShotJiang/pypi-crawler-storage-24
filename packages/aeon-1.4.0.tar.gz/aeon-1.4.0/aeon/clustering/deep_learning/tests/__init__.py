"""Deep learning clustering tests."""
