"""Tests for benchmarking."""
