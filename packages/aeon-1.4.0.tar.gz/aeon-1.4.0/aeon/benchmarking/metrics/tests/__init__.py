"""Tests for performance metrics."""
