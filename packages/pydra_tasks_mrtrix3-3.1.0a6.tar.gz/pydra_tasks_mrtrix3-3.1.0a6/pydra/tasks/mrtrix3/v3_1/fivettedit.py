# Auto-generated from MRtrix C++ command with '__print_pydra_code__' secret option

from typing import Any
from pathlib import Path  # noqa: F401
from fileformats.generic import File, Directory  # noqa: F401
from fileformats.vendor.mrtrix3.medimage import ImageIn, ImageOut, Tracks  # noqa: F401
from pydra.compose import shell
from pydra.utils.typing import MultiInputObj


@shell.define
class FivettEdit(shell.Task["FivettEdit.Outputs"]):
    """The user-provided images are interpreted as desired partial volume fractions in the output image. For any voxel with a non-zero value in such an image, this will be the value for that tissue in the output 5TT image. For tissues for which the user has not explicitly requested a change to the partial volume fraction, the partial volume fraction may nevertheless change in order to preserve the requirement of a unity sum of partial volume fractions in each voxel.

        Any voxels that are included in the mask provided by the -none option will be erased in the output image; this supersedes all other user inputs.


        References
        ----------

            Tournier, J.-D.; Smith, R. E.; Raffelt, D.; Tabbara, R.; Dhollander, T.; Pietsch, M.; Christiaens, D.; Jeurissen, B.; Yeh, C.-H. & Connelly, A. MRtrix3: A fast, flexible and open software framework for medical image processing and visualisation. NeuroImage, 2019, 202, 116137


        MRtrix
        ------

        Version:3.0.7-1583-g24a09ac5-dirty, built Dec  3 2025

        Author: Robert E. Smith (robert.smith@florey.edu.au)

        Copyright: Copyright (c) 2008-2025 the MRtrix3 contributors.

    This Source Code Form is subject to the terms of the Mozilla Public
    License, v. 2.0. If a copy of the MPL was not distributed with this
    file, You can obtain one at http://mozilla.org/MPL/2.0/.

    Covered Software is provided under this License on an "as is"
    basis, without warranty of any kind, either expressed, implied, or
    statutory, including, without limitation, warranties that the
    Covered Software is free of defects, merchantable, fit for a
    particular purpose or non-infringing.
    See the Mozilla Public License v. 2.0 for more details.

    For more details, see http://www.mrtrix.org/.
    """

    executable = "5ttedit"

    # Arguments
    in_file: ImageIn = shell.arg(
        argstr="",
        position=1,
        help="""the 5TT image to be modified""",
    )

    # Options
    cgm: ImageIn | None = shell.arg(
        default=None,
        argstr="-cgm",
        help="""provide an image of new cortical grey matter partial volume fractions""",
    )
    sgm: ImageIn | None = shell.arg(
        default=None,
        argstr="-sgm",
        help="""provide an image of new sub-cortical grey matter partial volume fractions""",
    )
    wm: ImageIn | None = shell.arg(
        default=None,
        argstr="-wm",
        help="""provide an image of new white matter partial volume fractions""",
    )
    csf: ImageIn | None = shell.arg(
        default=None,
        argstr="-csf",
        help="""provide an image of new CSF partial volume fractions""",
    )
    path: ImageIn | None = shell.arg(
        default=None,
        argstr="-path",
        help="""provide an image of new pathological tissue partial volume fractions""",
    )
    none: ImageIn | None = shell.arg(
        default=None,
        argstr="-none",
        help="""provide a mask of voxels that should be cleared (i.e. are non-brain)""",
    )

    # Standard options
    info: bool = shell.arg(
        default=False,
        argstr="-info",
        help="""display information messages.""",
    )
    quiet: bool = shell.arg(
        default=False,
        argstr="-quiet",
        help="""do not display information messages or progress status; alternatively, this can be achieved by setting the MRTRIX_QUIET environment variable to a non-empty string.""",
    )
    debug: bool = shell.arg(
        default=False,
        argstr="-debug",
        help="""display debugging messages.""",
    )
    force: bool = shell.arg(
        default=False,
        argstr="-force",
        help="""force overwrite of output files (caution: using the same file as input and output might cause unexpected behaviour).""",
    )
    nthreads: int | None = shell.arg(
        default=None,
        argstr="-nthreads",
        help="""use this number of threads in multi-threaded applications (set to 0 to disable multi-threading).""",
    )
    config: MultiInputObj[tuple[str, str]] | None = shell.arg(
        default=None,
        argstr="-config",
        help="""temporarily set the value of an MRtrix config file entry.""",
        sep=" ",
    )

    class Outputs(shell.Outputs):
        out_file: ImageOut = shell.outarg(
            argstr="",
            position=2,
            path_template="out_file.mif",
            help="""the output modified 5TT image""",
        )
