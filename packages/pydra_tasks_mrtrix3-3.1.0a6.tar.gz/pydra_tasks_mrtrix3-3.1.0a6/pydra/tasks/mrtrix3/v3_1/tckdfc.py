# Auto-generated from MRtrix C++ command with '__print_pydra_code__' secret option

from typing import Any
from pathlib import Path  # noqa: F401
from fileformats.generic import File, Directory  # noqa: F401
from fileformats.vendor.mrtrix3.medimage import ImageIn, ImageOut, Tracks  # noqa: F401
from pydra.compose import shell
from pydra.utils.typing import MultiInputObj


@shell.define
class TckDfc(shell.Task["TckDfc.Outputs"]):
    """This command generates a Track-Weighted Image (TWI), where the contribution from each streamline to the image is the Pearson correlation between the fMRI time series at the streamline endpoints.

        The output image can be generated in one of two ways (note that one of these two command-line options MUST be provided):

        - "Static" functional connectivity (-static option): Each streamline contributes to a static 3D output image based on the correlation between the signals at the streamline endpoints using the entirety of the input time series.

        - "Dynamic" functional connectivity (-dynamic option): The output image is a 4D image, with the same number of volumes as the input fMRI time series. For each volume, the contribution from each streamline is calculated based on a finite-width sliding time window, centred at the timepoint corresponding to that volume.

        Note that the -backtrack option in this command is similar, but not precisely equivalent, to back-tracking as can be used with Anatomically-Constrained Tractography (ACT) in the tckgen command. However, here the feature does not change the streamlines trajectories in any way; it simply enables detection of the fact that the input fMRI image may not contain a valid timeseries underneath the streamline endpoint, and where this occurs, searches from the streamline endpoint inwards along the streamline trajectory in search of a valid timeseries to sample from the input image.


        References
        ----------

            Calamante, F.; Smith, R.E.; Liang, X.; Zalesky, A.; Connelly, A. Track-weighted dynamic functional connectivity (TW-dFC): a new method to study time-resolved functional connectivity. Brain Struct Funct, 2017, doi: 10.1007/s00429-017-1431-1

            Tournier, J.-D.; Smith, R. E.; Raffelt, D.; Tabbara, R.; Dhollander, T.; Pietsch, M.; Christiaens, D.; Jeurissen, B.; Yeh, C.-H. & Connelly, A. MRtrix3: A fast, flexible and open software framework for medical image processing and visualisation. NeuroImage, 2019, 202, 116137


        MRtrix
        ------

        Version:3.0.7-1583-g24a09ac5-dirty, built Dec  3 2025

        Author: Robert E. Smith (robert.smith@florey.edu.au)

        Copyright: Copyright (c) 2008-2025 the MRtrix3 contributors.

    This Source Code Form is subject to the terms of the Mozilla Public
    License, v. 2.0. If a copy of the MPL was not distributed with this
    file, You can obtain one at http://mozilla.org/MPL/2.0/.

    Covered Software is provided under this License on an "as is"
    basis, without warranty of any kind, either expressed, implied, or
    statutory, including, without limitation, warranties that the
    Covered Software is free of defects, merchantable, fit for a
    particular purpose or non-infringing.
    See the Mozilla Public License v. 2.0 for more details.

    For more details, see http://www.mrtrix.org/.
    """

    executable = "tckdfc"

    # Arguments
    tracks: File = shell.arg(
        argstr="",
        position=1,
        help="""the input track file.""",
    )
    fmri: ImageIn = shell.arg(
        argstr="",
        position=2,
        help="""the pre-processed fMRI time series""",
    )

    # Options

    # Options for toggling between static and dynamic TW-dFC methods; note that one of these options MUST be provided:
    static: bool = shell.arg(
        default=False,
        argstr="-static",
        help="""generate a "static" (3D) output image.""",
    )
    dynamic: tuple[str, str] | None = shell.arg(
        default=None,
        argstr="-dynamic",
        help="""generate a "dynamic" (4D) output image; must additionally provide the shape and width (in volumes) of the sliding window.""",
        sep=" ",
    )

    # Options for setting the properties of the output image:
    template: ImageIn | None = shell.arg(
        default=None,
        argstr="-template",
        help="""an image file to be used as a template for the output (the output image will have the same transform and field of view).""",
    )
    vox: list[float] | None = shell.arg(
        default=None,
        argstr="-vox",
        help="""provide either an isotropic voxel size (in mm), or comma-separated list of 3 voxel dimensions.""",
        sep=",",
    )
    stat_vox: str | None = shell.arg(
        default=None,
        argstr="-stat_vox",
        help="""define the statistic for choosing the final voxel intensities for a given contrast type given the individual values from the tracks passing through each voxel; options are: sum, min, mean, max (default: mean)""",
        allowed_values=["sum", "min", "mean", "max"],
    )

    # Other options for affecting the streamline sampling & mapping behaviour:
    backtrack: bool = shell.arg(
        default=False,
        argstr="-backtrack",
        help="""if no valid timeseries is found at the streamline endpoint, back-track along the streamline trajectory until a valid timeseries is found""",
    )
    upsample: int | None = shell.arg(
        default=None,
        argstr="-upsample",
        help="""upsample the tracks by some ratio using Hermite interpolation before mapping (if omitted, an appropriate ratio will be determined automatically)""",
    )

    # Standard options
    info: bool = shell.arg(
        default=False,
        argstr="-info",
        help="""display information messages.""",
    )
    quiet: bool = shell.arg(
        default=False,
        argstr="-quiet",
        help="""do not display information messages or progress status; alternatively, this can be achieved by setting the MRTRIX_QUIET environment variable to a non-empty string.""",
    )
    debug: bool = shell.arg(
        default=False,
        argstr="-debug",
        help="""display debugging messages.""",
    )
    force: bool = shell.arg(
        default=False,
        argstr="-force",
        help="""force overwrite of output files (caution: using the same file as input and output might cause unexpected behaviour).""",
    )
    nthreads: int | None = shell.arg(
        default=None,
        argstr="-nthreads",
        help="""use this number of threads in multi-threaded applications (set to 0 to disable multi-threading).""",
    )
    config: MultiInputObj[tuple[str, str]] | None = shell.arg(
        default=None,
        argstr="-config",
        help="""temporarily set the value of an MRtrix config file entry.""",
        sep=" ",
    )

    class Outputs(shell.Outputs):
        out_file: ImageOut = shell.outarg(
            argstr="",
            position=3,
            path_template="out_file.mif",
            help="""the output TW-dFC image""",
        )
