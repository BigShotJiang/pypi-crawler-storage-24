DEVICE_ID = "immichpy"
