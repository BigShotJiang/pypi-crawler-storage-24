"""
tests/test_token_budget.py — Tests for TokenBudgetManager (Issue #18)

Covers:
  - Token counting accuracy
  - Budget creation and state
  - Layer allocation with priority order
  - Cornerstone reservation guarantee
  - Budget exhaustion and truncation
  - Soft cap enforcement
  - Configurable budgets
  - BudgetAllocation properties
  - MemoryLayer enum helpers
  - Edge cases (empty input, zero budget, single item overflow)
"""

from __future__ import annotations

import pytest

from cortex.core.token_budget import TokenBudget, TokenBudgetManager
from cortex.types import BudgetAllocation, MemoryLayer


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def manager() -> TokenBudgetManager:
    """Default manager: 4000 total, 800 cornerstone."""
    return TokenBudgetManager()


@pytest.fixture
def small_manager() -> TokenBudgetManager:
    """Small manager for budget-exhaustion tests."""
    return TokenBudgetManager(total_budget=200, cornerstone_budget=50)


# ---------------------------------------------------------------------------
# MemoryLayer enum
# ---------------------------------------------------------------------------

class TestMemoryLayer:
    def test_values(self):
        assert MemoryLayer.CORNERSTONE.value == "cornerstone"
        assert MemoryLayer.SESSION.value == "session"
        assert MemoryLayer.SEMANTIC.value == "semantic"
        assert MemoryLayer.PROCEDURAL.value == "procedural"

    def test_priority_order(self):
        ordered = MemoryLayer.by_priority()
        assert ordered[0] == MemoryLayer.CORNERSTONE
        assert ordered[-1] == MemoryLayer.PROCEDURAL

    def test_truncation_order_is_lowest_first(self):
        trunc = MemoryLayer.truncation_order()
        assert trunc[0] == MemoryLayer.PROCEDURAL
        assert trunc[-1] == MemoryLayer.CORNERSTONE

    def test_priority_values(self):
        assert MemoryLayer.CORNERSTONE.priority < MemoryLayer.SESSION.priority
        assert MemoryLayer.SESSION.priority < MemoryLayer.SEMANTIC.priority
        assert MemoryLayer.SEMANTIC.priority < MemoryLayer.PROCEDURAL.priority


# ---------------------------------------------------------------------------
# BudgetAllocation dataclass
# ---------------------------------------------------------------------------

class TestBudgetAllocation:
    def test_used_calculation(self):
        alloc = BudgetAllocation(
            total_budget=4000,
            cornerstone_reserved=800,
            allocations={"session": 300, "semantic": 200},
        )
        assert alloc.used == 1300  # 800 + 300 + 200

    def test_remaining(self):
        alloc = BudgetAllocation(
            total_budget=4000,
            cornerstone_reserved=800,
            allocations={"session": 200},
        )
        assert alloc.remaining == 3000  # 4000 - 800 - 200

    def test_utilization(self):
        alloc = BudgetAllocation(
            total_budget=4000,
            cornerstone_reserved=800,
            allocations={"session": 200},
        )
        assert alloc.utilization == pytest.approx(1000 / 4000)

    def test_utilization_zero_budget(self):
        alloc = BudgetAllocation(
            total_budget=0,
            cornerstone_reserved=0,
            allocations={},
        )
        assert alloc.utilization == 0.0

    def test_is_over_budget(self):
        alloc = BudgetAllocation(
            total_budget=100,
            cornerstone_reserved=80,
            allocations={"session": 30},  # 80+30 = 110 > 100
        )
        assert alloc.is_over_budget() is True

    def test_not_over_budget(self):
        alloc = BudgetAllocation(
            total_budget=4000,
            cornerstone_reserved=800,
            allocations={"session": 100},
        )
        assert alloc.is_over_budget() is False


# ---------------------------------------------------------------------------
# TokenBudget (internal state)
# ---------------------------------------------------------------------------

class TestTokenBudget:
    def test_remaining_starts_at_total_minus_reserved(self):
        budget = TokenBudget(total=4000, reserved_cornerstones=800)
        assert budget.remaining() == 3200

    def test_allocate_succeeds_within_budget(self):
        budget = TokenBudget(total=4000, reserved_cornerstones=800)
        assert budget.allocate("session", 500) is True
        assert budget.allocated["session"] == 500

    def test_allocate_fails_over_budget(self):
        budget = TokenBudget(total=1000, reserved_cornerstones=800)
        assert budget.allocate("session", 300) is False  # only 200 remaining
        assert "session" not in budget.allocated

    def test_allocate_accumulates(self):
        budget = TokenBudget(total=4000, reserved_cornerstones=0)
        budget.allocate("session", 200)
        budget.allocate("session", 300)
        assert budget.allocated["session"] == 500

    def test_used(self):
        budget = TokenBudget(total=4000, reserved_cornerstones=800)
        budget.allocate("session", 200)
        assert budget.used() == 1000

    def test_remaining_decreases_after_allocation(self):
        budget = TokenBudget(total=4000, reserved_cornerstones=800)
        budget.allocate("session", 500)
        assert budget.remaining() == 2700


# ---------------------------------------------------------------------------
# TokenBudgetManager construction
# ---------------------------------------------------------------------------

class TestManagerConstruction:
    def test_defaults(self, manager):
        assert manager.total_budget == 4000
        assert manager.cornerstone_budget == 800

    def test_custom_budgets(self):
        m = TokenBudgetManager(total_budget=2000, cornerstone_budget=400)
        assert m.total_budget == 2000
        assert m.cornerstone_budget == 400

    def test_cornerstone_exceeds_total_raises(self):
        with pytest.raises(ValueError, match="cornerstone_budget"):
            TokenBudgetManager(total_budget=500, cornerstone_budget=600)

    def test_config_override(self):
        class FakeConfig:
            total_memory_token_budget = 3000
            cornerstone_token_budget = 600

        m = TokenBudgetManager(config=FakeConfig())
        assert m.total_budget == 3000
        assert m.cornerstone_budget == 600

    def test_explicit_args_take_precedence_over_config(self):
        class FakeConfig:
            total_memory_token_budget = 3000
            cornerstone_token_budget = 600

        m = TokenBudgetManager(config=FakeConfig(), total_budget=5000)
        assert m.total_budget == 5000

    def test_repr(self, manager):
        r = repr(manager)
        assert "TokenBudgetManager" in r
        assert "4000" in r


# ---------------------------------------------------------------------------
# Token counting
# ---------------------------------------------------------------------------

class TestTokenCounting:
    def test_empty_string_is_zero(self, manager):
        assert manager.count_tokens("") == 0

    def test_simple_word(self, manager):
        # "hello" is a single token in cl100k_base
        count = manager.count_tokens("hello")
        assert count >= 1

    def test_longer_text_has_more_tokens(self, manager):
        short = manager.count_tokens("hi")
        long = manager.count_tokens("hi " * 50)
        assert long > short

    def test_batch_counting(self, manager):
        texts = ["hello", "world", "foo bar"]
        counts = manager.count_tokens_batch(texts)
        assert len(counts) == 3
        assert all(c >= 1 for c in counts)
        # Individual counts should match
        for text, count in zip(texts, counts):
            assert manager.count_tokens(text) == count

    def test_whitespace_only(self, manager):
        count = manager.count_tokens("   ")
        assert count >= 1  # whitespace is still tokenized

    def test_known_token_count(self, manager):
        # "The quick brown fox" — known to be 4 tokens in cl100k_base
        count = manager.count_tokens("The quick brown fox")
        assert count == 4


# ---------------------------------------------------------------------------
# Budget creation
# ---------------------------------------------------------------------------

class TestCreateBudget:
    def test_creates_correct_total(self, manager):
        b = manager.create_budget()
        assert b.total == 4000

    def test_creates_correct_cornerstone_reservation(self, manager):
        b = manager.create_budget()
        assert b.reserved_cornerstones == 800

    def test_override_total(self, manager):
        b = manager.create_budget(total=2000)
        assert b.total == 2000

    def test_starts_empty(self, manager):
        b = manager.create_budget()
        assert b.allocated == {}

    def test_remaining_equals_total_minus_cornerstones(self, manager):
        b = manager.create_budget()
        assert b.remaining() == 3200


# ---------------------------------------------------------------------------
# Layer soft caps
# ---------------------------------------------------------------------------

class TestLayerSoftCaps:
    def test_session_cap(self, manager):
        # 40% of non-cornerstone = 40% of (4000 - 800) = 40% of 3200 = 1280
        cap = manager.layer_soft_cap(MemoryLayer.SESSION)
        assert cap == 1280

    def test_semantic_cap(self, manager):
        # 35% of 3200 = 1120
        cap = manager.layer_soft_cap(MemoryLayer.SEMANTIC)
        assert cap == 1120

    def test_procedural_cap(self, manager):
        # 25% of 3200 = 800
        cap = manager.layer_soft_cap(MemoryLayer.PROCEDURAL)
        assert cap == 800

    def test_custom_fractions(self):
        m = TokenBudgetManager(
            total_budget=4000,
            cornerstone_budget=0,
            layer_fractions={MemoryLayer.SESSION.value: 0.5},
        )
        assert m.layer_soft_cap(MemoryLayer.SESSION) == 2000


# ---------------------------------------------------------------------------
# Allocate layers — happy path
# ---------------------------------------------------------------------------

class TestAllocateLayers:
    def test_empty_layers_returns_zero_allocation(self, manager):
        result = manager.allocate_layers({})
        assert result.allocations == {}
        assert result.truncated == {}
        assert result.remaining >= 0

    def test_cornerstones_always_allocated(self, manager):
        layers = {
            MemoryLayer.CORNERSTONE: ["identity memory one", "identity memory two"],
        }
        result = manager.allocate_layers(layers)
        assert MemoryLayer.CORNERSTONE.value in result.allocations
        assert result.allocations[MemoryLayer.CORNERSTONE.value] > 0

    def test_session_allocated_after_cornerstones(self, manager):
        layers = {
            MemoryLayer.CORNERSTONE: ["cornerstone text"],
            MemoryLayer.SESSION: ["recent session content here"],
        }
        result = manager.allocate_layers(layers)
        assert MemoryLayer.SESSION.value in result.allocations

    def test_all_layers_allocated_when_budget_sufficient(self, manager):
        layers = {
            MemoryLayer.CORNERSTONE: ["cornerstone"],
            MemoryLayer.SESSION: ["session memory"],
            MemoryLayer.SEMANTIC: ["semantic memory"],
            MemoryLayer.PROCEDURAL: ["procedural step"],
        }
        result = manager.allocate_layers(layers)
        # All layers should have some allocation
        assert MemoryLayer.CORNERSTONE.value in result.allocations
        assert MemoryLayer.SESSION.value in result.allocations
        assert MemoryLayer.SEMANTIC.value in result.allocations
        assert MemoryLayer.PROCEDURAL.value in result.allocations

    def test_total_budget_not_exceeded(self, manager):
        """Total tokens allocated must never exceed the total budget."""
        layers = {
            MemoryLayer.CORNERSTONE: ["cornerstone " * 30],
            MemoryLayer.SESSION: ["session content " * 100],
            MemoryLayer.SEMANTIC: ["semantic fact " * 100],
            MemoryLayer.PROCEDURAL: ["procedure step " * 100],
        }
        result = manager.allocate_layers(layers)
        assert result.used <= result.total_budget

    def test_budget_allocation_has_correct_total(self, manager):
        layers = {MemoryLayer.SESSION: ["test"]}
        result = manager.allocate_layers(layers)
        assert result.total_budget == 4000
        assert result.cornerstone_reserved == 800


# ---------------------------------------------------------------------------
# Cornerstone reservation guarantee
# ---------------------------------------------------------------------------

class TestCornerstoneReservation:
    def test_cornerstones_fit_within_reserved_budget(self, manager):
        # Build text that fits exactly in cornerstone budget
        text = "word " * 100  # ~100 tokens
        layers = {
            MemoryLayer.CORNERSTONE: [text] * 8,  # ~800 tokens
            MemoryLayer.SESSION: ["session " * 200],  # should NOT eat cornerstone space
        }
        result = manager.allocate_layers(layers)
        # Session tokens should not appear in cornerstone allocation
        cornerstone_used = result.allocations.get(MemoryLayer.CORNERSTONE.value, 0)
        assert cornerstone_used <= 800

    def test_cornerstone_budget_independent_of_other_layers(self, small_manager):
        """Even when other layers overflow, cornerstones get reserved space."""
        # Fill session/semantic with massive content
        big_content = ["token " * 200]  # ~200 tokens each
        layers = {
            MemoryLayer.CORNERSTONE: ["identity"],
            MemoryLayer.SESSION: big_content,
            MemoryLayer.SEMANTIC: big_content,
            MemoryLayer.PROCEDURAL: big_content,
        }
        result = small_manager.allocate_layers(layers)
        # Cornerstones should still be allocated despite budget pressure
        assert MemoryLayer.CORNERSTONE.value in result.allocations

    def test_cornerstone_overflow_recorded_in_truncated(self, small_manager):
        """When cornerstones exceed their own budget, overflow is recorded."""
        # Build content larger than cornerstone_budget (50 tokens)
        huge_cornerstone = "word " * 100  # ~100 tokens, > 50 budget
        layers = {
            MemoryLayer.CORNERSTONE: [huge_cornerstone],
        }
        result = small_manager.allocate_layers(layers)
        # Some should be truncated
        assert MemoryLayer.CORNERSTONE.value in result.truncated


# ---------------------------------------------------------------------------
# Budget exhaustion and truncation
# ---------------------------------------------------------------------------

class TestBudgetExhaustion:
    def test_lowest_priority_truncated_first(self, small_manager):
        """When budget is tight, procedural is truncated before session."""
        medium_content = "word " * 20  # ~20 tokens each
        layers = {
            MemoryLayer.SESSION: [medium_content] * 5,
            MemoryLayer.PROCEDURAL: [medium_content] * 5,
        }
        result = small_manager.allocate_layers(layers)
        # Either procedural is truncated, or it gets less than session
        session_tokens = result.allocations.get(MemoryLayer.SESSION.value, 0)
        procedural_tokens = result.allocations.get(MemoryLayer.PROCEDURAL.value, 0)
        # Session should get at least as much as procedural (higher priority)
        assert session_tokens >= procedural_tokens

    def test_truncated_tokens_recorded(self, small_manager):
        """Overflow tokens should appear in result.truncated."""
        big_content = "word " * 100  # ~100 tokens
        layers = {
            MemoryLayer.SESSION: [big_content, big_content, big_content],
        }
        result = small_manager.allocate_layers(layers)
        # With 200 total - 50 cornerstone = 150 non-cornerstone, 3×100 = 300 tokens
        # Some should be truncated
        assert MemoryLayer.SESSION.value in result.truncated

    def test_total_never_exceeds_budget_under_pressure(self, small_manager):
        """With massively oversized content, budget must still be respected."""
        enormous = "word " * 5000  # thousands of tokens
        layers = {
            MemoryLayer.CORNERSTONE: [enormous],
            MemoryLayer.SESSION: [enormous],
            MemoryLayer.SEMANTIC: [enormous],
            MemoryLayer.PROCEDURAL: [enormous],
        }
        result = small_manager.allocate_layers(layers)
        assert result.used <= result.total_budget


# ---------------------------------------------------------------------------
# Truncation helpers
# ---------------------------------------------------------------------------

class TestTruncateHelpers:
    def test_truncate_to_budget_within_limit(self, manager):
        text = "short text"
        result = manager.truncate_to_budget(text, max_tokens=50)
        assert result == text

    def test_truncate_to_budget_over_limit(self, manager):
        text = "word " * 100  # ~100 tokens
        result = manager.truncate_to_budget(text, max_tokens=20)
        assert manager.count_tokens(result) <= 20

    def test_truncate_to_budget_zero_limit(self, manager):
        result = manager.truncate_to_budget("hello world", max_tokens=0)
        assert result == ""

    def test_truncate_appends_suffix(self, manager):
        text = "word " * 100
        result = manager.truncate_to_budget(text, max_tokens=10)
        assert result.endswith("…")

    def test_truncate_no_suffix_when_fits(self, manager):
        text = "hi"
        result = manager.truncate_to_budget(text, max_tokens=100)
        assert "…" not in result

    def test_fit_items_to_budget_selects_front(self, manager):
        items = ["item one", "item two", "item three", "item four", "item five"]
        # Force a very small budget to limit selection
        selected, used = manager.fit_items_to_budget(items, max_tokens=3)
        # At least some items selected, front items preferred
        assert len(selected) > 0
        assert selected[0] == items[0]
        assert used <= 3

    def test_fit_items_to_budget_empty_list(self, manager):
        selected, used = manager.fit_items_to_budget([], max_tokens=100)
        assert selected == []
        assert used == 0

    def test_fit_items_to_budget_all_fit(self, manager):
        items = ["a", "b", "c"]
        selected, used = manager.fit_items_to_budget(items, max_tokens=1000)
        assert selected == items
        assert used == sum(manager.count_tokens(i) for i in items)

    def test_fit_items_total_within_budget(self, manager):
        items = ["word " * 20 for _ in range(10)]
        selected, used = manager.fit_items_to_budget(items, max_tokens=100)
        assert used <= 100


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_zero_total_budget(self):
        m = TokenBudgetManager(total_budget=0, cornerstone_budget=0)
        result = m.allocate_layers({MemoryLayer.SESSION: ["content"]})
        assert result.used == 0

    def test_no_layers_provided(self, manager):
        result = manager.allocate_layers({})
        assert result.used == result.cornerstone_reserved
        assert result.remaining == manager.total_budget - manager.cornerstone_budget

    def test_single_item_exceeds_total(self):
        m = TokenBudgetManager(total_budget=5, cornerstone_budget=0)
        result = m.allocate_layers({
            MemoryLayer.SESSION: ["this sentence has far more than five tokens total"],
        })
        assert result.used <= 5

    def test_unicode_text_counted(self, manager):
        text = "こんにちは世界"  # Japanese
        count = manager.count_tokens(text)
        assert count >= 1

    def test_layer_fractions_respected(self):
        m = TokenBudgetManager(
            total_budget=1000,
            cornerstone_budget=0,
            layer_fractions={
                MemoryLayer.SESSION.value: 0.5,
                MemoryLayer.SEMANTIC.value: 0.5,
                MemoryLayer.PROCEDURAL.value: 0.0,
            },
        )
        # Procedural cap is 0, so nothing should be allocated there
        big = "word " * 200
        result = m.allocate_layers({
            MemoryLayer.PROCEDURAL: [big],
            MemoryLayer.SESSION: ["short"],
        })
        assert MemoryLayer.PROCEDURAL.value not in result.allocations
        assert MemoryLayer.SESSION.value in result.allocations
