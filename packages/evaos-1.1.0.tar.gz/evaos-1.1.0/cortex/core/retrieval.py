"""
cortex/core/retrieval.py — Retrieval Pipeline (Module 8 / M8).

The read-side counterpart to the remember() pipeline. Given a natural language
query, finds and assembles the most relevant memories from storage.

Phase 1 (current): Basic hybrid retrieval
    - BM25 full-text search via FTS5 virtual tables
    - Vector similarity search via sqlite-vec (or brute-force cosine fallback)
    - Reciprocal Rank Fusion (RRF) to combine both ranked lists
    - Token budget enforcement (trim results to fit context window)

Phase 2 (issue #34): Agentic retrieval
    - Query expansion via LLM
    - Multi-round retrieval with refinement
    - LLM reranking of candidates
    - Brain graph traversal
    - Implemented in cortex.core.agentic_retrieval.AgenticRetrievalPipeline

Retrieval pipeline:
    1. Route query → mode ('lightweight' or 'agentic')
    2. Parallel BM25 + vector search (fetch candidate_multiplier × top_k candidates)
    3. RRF fusion → single ranked list
    4. Token budget trim → final items
    5. Log retrieval metadata for feedback/debugging

Dependencies:
    - cortex.storage.adapter.StorageAdapter (M1) — vector_search, fts_search
    - cortex.core.token_budget.TokenBudgetManager (M9) — budget allocation
    - cortex.config.CortexConfig — retrieval_token_budget, vector/bm25 weights
    - LLMProvider (optional) — for embedding generation and agentic mode

Data flow:
    CortexPlugin.retrieve(query)
      → RetrievalPipeline.retrieve(query, mode, constraints)
          → _bm25_search() + _vector_search() (parallel)
          → rrf_fusion() → sorted candidates
          → _apply_budget() → trimmed to token limit
      → RetrievalResult (items + metadata)
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import math
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from cortex.core.token_budget import TokenBudgetManager
    from cortex.storage.adapter import StorageAdapter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Sensitivity level ordering (lower index = less sensitive)
# ---------------------------------------------------------------------------

SENSITIVITY_ORDER = ["normal", "private", "secret", "restricted"]
_SENSITIVITY_ALIASES = {"sensitive": "secret"}


def _sensitivity_level(value: str) -> int:
    """Return numeric level for a sensitivity string (fail-closed for unknowns)."""
    canonical = _SENSITIVITY_ALIASES.get(value, value)
    try:
        return SENSITIVITY_ORDER.index(canonical)
    except ValueError:
        return len(SENSITIVITY_ORDER)


# ---------------------------------------------------------------------------
# Public data-transfer objects
# ---------------------------------------------------------------------------

@dataclass
class RetrievalConstraints:
    """Configurable constraints for a retrieve() call.

    All fields are optional — unset fields use defaults from CortexConfig.

    Attributes:
        memory_types: Filter by item type — 'claim', 'event', 'procedure', etc.
                      None = all types.
        time_range: ISO 8601 (start, end) tuple for temporal filtering.
        entity_ids: Only return items related to these entity UUIDs.
        sensitivity_max: Maximum sensitivity level to return. Items above this
                         level are excluded. Valid: normal < private < secret <
                         restricted. Default: 'secret' (excludes 'restricted').
        token_budget: Override the global retrieval_token_budget for this call.
        top_k: Maximum number of items to return after fusion. Default: 20.
    """
    memory_types: Optional[List[str]] = None        # filter by item_type
    time_range: Optional[Tuple[str, str]] = None    # (iso_start, iso_end)
    entity_ids: Optional[List[str]] = None
    sensitivity_max: str = "secret"                 # excludes 'restricted' by default
    token_budget: Optional[int] = None              # override global budget
    top_k: int = 20


@dataclass
class RetrievedItem:
    """A single memory item returned from retrieval.

    Attributes:
        item_type: Memory layer type — 'claim', 'event', 'procedure', 'brain_graph_node'.
        item_id: UUID of the source record.
        content: Text content to inject into the prompt.
        score: Hybrid/RRF score — higher = more relevant.
        provenance: Optional trace info (retrieval explanation, Phase 2).
    """
    item_type: str          # 'claim', 'event', 'procedure', 'brain_graph_node'
    item_id: str
    content: str
    score: float
    provenance: Optional[str] = None


@dataclass
class RetrievalResult:
    """Complete result from a retrieve() call.

    Returned by: RetrievalPipeline.retrieve().
    Consumed by: CortexPlugin.retrieve() → returned to caller / MCP / HTTP.

    Attributes:
        items: Ranked list of retrieved memory items.
        retrieval_id: UUID for this retrieval (used in feedback/logging).
        mode: Which retrieval mode was used — 'lightweight', 'agentic', etc.
        latency_ms: End-to-end retrieval time in milliseconds.
        tokens_used: Total tokens consumed by the returned items.
    """
    items: List[RetrievedItem]
    retrieval_id: str
    mode: str
    latency_ms: int
    tokens_used: int


@dataclass
class ContextBlock:
    """Assembled prompt-injection block produced by assemble_context().

    This is the final formatted output ready for system prompt injection.

    Attributes:
        parts: List of (type, text, tokens) tuples in injection order.
        total_tokens: Sum of all part token counts.
        budget_remaining: How many tokens are still available after this block.
        retrieval_id: UUID for tracing/feedback.
    """
    parts: List[Tuple[str, str, int]]  # (type, text, tokens)
    total_tokens: int
    budget_remaining: int
    retrieval_id: str


# ---------------------------------------------------------------------------
# Internal result types that mirror StorageAdapter returns
# (kept here so retrieval.py doesn't import from adapter directly)
# ---------------------------------------------------------------------------

@dataclass
class _VectorResult:
    item_type: str
    item_id: str
    content: str
    score: float


@dataclass
class _FTSResult:
    item_type: str
    item_id: str
    content: str
    rank: float  # BM25 rank (lower is better in SQLite FTS5 bm25())


# ---------------------------------------------------------------------------
# Scoring helpers (pure functions — easy to unit-test)
# ---------------------------------------------------------------------------

def hybrid_score(
    vector_score: float,
    bm25_score: float,
    temporal_decay: float = 1.0,
    recency_bonus: float = 0.0,
    access_count_bonus: float = 0.0,
    vector_weight: float = 0.7,
    bm25_weight: float = 0.3,
    recency_weight: float = 0.0,
) -> float:
    """Combine vector similarity and BM25 keyword scores into a single score.

    The hybrid approach captures both semantic meaning (vector) and exact
    keyword matches (BM25). Default 70/30 weighting favours semantics.

    Args:
        vector_score: Cosine similarity score (0-1, higher = better).
        bm25_score: Normalised BM25 score (0-1, higher = better).
        temporal_decay: Multiplicative decay for old memories (1.0 = no decay).
        recency_bonus: Additive bonus for recent items (Phase 2).
        access_count_bonus: Additive bonus based on access frequency.
        vector_weight: Weight for vector score (default 0.7).
        bm25_weight: Weight for BM25 score (default 0.3).
        recency_weight: Weight for recency bonus (0.0 in Phase 1).

    Returns:
        Combined score (higher = more relevant).
    """
    base = (
        vector_weight * vector_score
        + bm25_weight * bm25_score
        + recency_weight * recency_bonus
    )
    base *= temporal_decay
    base += min(access_count_bonus * 0.01, 0.1)  # cap access bonus
    return base


def rrf_fusion(
    ranked_lists: List[List[Tuple[str, float]]],
    k: int = 60,
) -> List[Tuple[str, float]]:
    """Reciprocal Rank Fusion — combines multiple ranked lists into one.

    RRF is a simple, robust fusion method that's less sensitive to score
    scale differences between rankers than raw score averaging. It works by
    converting scores to reciprocal ranks: score(d) = Σ 1/(k + rank(d)).

    The k parameter controls how much weight top-ranked items get vs. lower-ranked
    ones. k=60 is the standard value from the original RRF paper (Cormack 2009).

    Args:
        ranked_lists: List of ranked lists, each containing (item_id, score)
                      tuples sorted best-first.
        k: Smoothing constant (default 60). Higher k = more uniform weighting.

    Returns:
        Fused list of (item_id, rrf_score) sorted by score descending.
    """
    scores: Dict[str, float] = {}
    for ranked_list in ranked_lists:
        for rank, (item_id, _) in enumerate(ranked_list):
            scores[item_id] = scores.get(item_id, 0.0) + 1.0 / (k + rank + 1)
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


def cosine_similarity(a: List[float], b: List[float]) -> float:
    """
    Brute-force cosine similarity for the sqlite-vec fallback path.
    Returns value in [-1, 1]; higher = more similar.
    """
    if len(a) != len(b):
        raise ValueError(f"Embedding dimension mismatch: {len(a)} vs {len(b)}")
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

class RetrievalPipeline:
    """
    Phase 1 hybrid retrieval: BM25 (FTS5) + vector similarity, fused with RRF.

    Phase 2 additions (issue #34): query expansion, multi-round retrieval,
    LLM rerank, brain-graph traversal.
    """

    def __init__(
        self,
        storage: "StorageAdapter",
        config: Any,           # CortexConfig
        token_budget: Optional["TokenBudgetManager"] = None,
        cornerstone_guardian: Any = None,  # Phase 2
        llm: Any = None,                   # Phase 2 — agentic mode
        *,
        vector_weight: float = 0.7,
        bm25_weight: float = 0.3,
        rrf_k: int = 60,
        candidate_multiplier: int = 3,     # fetch N×top_k candidates before fusion
        recency_weight: Optional[float] = None,
    ) -> None:
        self.storage = storage
        self.config = config
        self.token_budget = token_budget
        self.cornerstone_guardian = cornerstone_guardian
        self.llm = llm

        # Scoring knobs
        self.vector_weight = vector_weight
        self.bm25_weight = bm25_weight
        self.rrf_k = rrf_k
        self.candidate_multiplier = candidate_multiplier
        if recency_weight is not None:
            self.recency_weight = recency_weight
        else:
            self.recency_weight = getattr(config, "retrieval_recency_weight", 0.0)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def retrieve(
        self,
        query: str,
        mode: str = "auto",
        constraints: Optional[RetrievalConstraints] = None,
        owner_id: str = "default",
    ) -> RetrievalResult:
        """Main retrieval entry point — find relevant memories for a query.

        Modes:
            'lightweight': BM25 + vector hybrid, no LLM calls (<200 ms target).
            'auto': Routes to 'lightweight' (Phase 1). Phase 2 may upgrade to 'agentic'.
            'agentic': Multi-round with LLM reranking (delegates to AgenticRetrievalPipeline).
            'brain_graph': Graph-walk retrieval (delegates to AgenticRetrievalPipeline).

        Args:
            query: Natural language search query.
            mode: Retrieval strategy — 'auto', 'lightweight', 'agentic', 'brain_graph'.
            constraints: Optional RetrievalConstraints for filtering/budget.
            owner_id: Multi-tenancy scope key.

        Returns:
            RetrievalResult with ranked items, retrieval_id, latency, and token usage.

        Note:
            Every retrieval is logged to the retrieval_log table for feedback tracking.
        """
        t0 = time.monotonic()
        retrieval_id = _new_id()
        constraints = constraints or RetrievalConstraints()

        if mode == "auto":
            mode = self._route_query(query, constraints)

        if mode == "lightweight":
            items = await self._lightweight_retrieve(query, constraints, owner_id)
        elif mode in ("agentic", "brain_graph"):
            # Agentic/brain_graph modes require Phase 2 pipeline.
            # If llm is available, delegate to AgenticRetrievalPipeline by re-routing
            # through _agentic_retrieve_fallback; otherwise fall back to lightweight.
            if self.llm is not None:
                from cortex.core.agentic_retrieval import AgenticRetrievalPipeline
                # Build a one-shot agentic pipeline reusing this instance's dependencies
                agentic = AgenticRetrievalPipeline(
                    storage=self.storage,
                    config=self.config,
                    token_budget=self.token_budget,
                    cornerstone_guardian=self.cornerstone_guardian,
                    llm=self.llm,
                    vector_weight=self.vector_weight,
                    bm25_weight=self.bm25_weight,
                    rrf_k=self.rrf_k,
                    candidate_multiplier=self.candidate_multiplier,
                )
                return await agentic.retrieve(
                    query, mode=mode, constraints=constraints, owner_id=owner_id
                )
            else:
                logger.warning(
                    "Mode '%s' requested but no LLM provided. Falling back to 'lightweight'.",
                    mode,
                )
                mode = "lightweight"
                items = await self._lightweight_retrieve(query, constraints, owner_id)
        else:
            # Graceful fallback: unsupported modes fall back to lightweight
            logger.warning(
                "Mode '%s' not supported. Falling back to 'lightweight'.", mode
            )
            mode = "lightweight"
            items = await self._lightweight_retrieve(query, constraints, owner_id)

        # Apply token budget
        tokens_used, items = await self._apply_budget(items, constraints)

        latency_ms = int((time.monotonic() - t0) * 1000)

        # Log every retrieval
        await self._log_retrieval(
            retrieval_id=retrieval_id,
            owner_id=owner_id,
            query=query,
            mode=mode,
            constraints=constraints,
            items=items,
            tokens_used=tokens_used,
            latency_ms=latency_ms,
        )

        return RetrievalResult(
            items=items,
            retrieval_id=retrieval_id,
            mode=mode,
            latency_ms=latency_ms,
            tokens_used=tokens_used,
        )

    async def assemble_context(
        self,
        query: str,
        owner_id: str = "default",
        cornerstone_guardian: Any = None,
    ) -> ContextBlock:
        """Assemble a formatted context block ready for system prompt injection.

        Cornerstones are ALWAYS injected first with a reserved token budget.
        Retrieval only uses the budget that remains after cornerstone reservation.

        Args:
            query: Natural language retrieval query.
            owner_id: Multi-tenancy scope key.
            cornerstone_guardian: Optional CornerstoneGuardian override.  When
                None, falls back to ``self.cornerstone_guardian`` (set at
                construction time via the plugin).

        Returns:
            ContextBlock with parts ordered [cornerstones, ...retrieved items],
            total_tokens, and budget_remaining.
        """
        retrieval_id = _new_id()

        # Resolve which guardian to use (call-time arg wins over instance attr)
        guardian = cornerstone_guardian if cornerstone_guardian is not None else self.cornerstone_guardian

        # Determine total budget ceiling
        total_budget = getattr(self.config, "retrieval_token_budget", 3000)

        parts: List[Tuple[str, str, int]] = []
        total_tokens = 0

        # ------------------------------------------------------------------
        # Step 1: Inject cornerstones first with reserved budget
        # ------------------------------------------------------------------
        cornerstone_tokens = 0
        if guardian is not None:
            try:
                cs_text = await guardian.format_injection_block(owner_id=owner_id)
                if cs_text:
                    cornerstone_tokens = self._count_tokens(cs_text)
                    parts.append(("cornerstone", cs_text, cornerstone_tokens))
                    total_tokens += cornerstone_tokens
                    logger.debug(
                        "assemble_context: injected %d cornerstone tokens", cornerstone_tokens
                    )
            except Exception as exc:
                logger.warning("assemble_context: cornerstone injection failed: %s", exc)

        # ------------------------------------------------------------------
        # Step 2: Run retrieval with the remaining budget
        # ------------------------------------------------------------------
        available_for_retrieval = max(0, total_budget - cornerstone_tokens)

        if self.token_budget is not None:
            try:
                budget_obj = self.token_budget.create_budget(total=available_for_retrieval)
                available_for_retrieval = min(available_for_retrieval, budget_obj.remaining)
            except Exception:
                pass  # keep available_for_retrieval as-is

        result = await self.retrieve(
            query,
            constraints=RetrievalConstraints(token_budget=available_for_retrieval),
            owner_id=owner_id,
        )

        # ------------------------------------------------------------------
        # Step 3: Append retrieved items (cornerstones already guaranteed above)
        # ------------------------------------------------------------------
        for item in result.items:
            item_tokens = self._count_tokens(item.content)
            if total_tokens + item_tokens > total_budget:
                break
            parts.append((item.item_type, item.content, item_tokens))
            total_tokens += item_tokens

        return ContextBlock(
            parts=parts,
            total_tokens=total_tokens,
            budget_remaining=total_budget - total_tokens,
            retrieval_id=retrieval_id,
        )

    async def explain(self, retrieval_id: str) -> Dict[str, Any]:
        """Return provenance and scoring details for a retrieval (stub for Phase 1)."""
        return {"retrieval_id": retrieval_id, "note": "Full explain available in Phase 2"}

    # ------------------------------------------------------------------
    # Query routing
    # ------------------------------------------------------------------

    def _route_query(
        self,
        query: str,
        constraints: RetrievalConstraints,
    ) -> str:
        """
        Simple heuristic router for Phase 1.
        - Short queries with no stopwords → lightweight (keyword-only would suffice)
        - Everything else → lightweight (hybrid)

        Phase 2 (AgenticRetrievalPipeline) overrides this to upgrade complex queries
        to 'agentic' when an LLM is available.
        """
        words = query.lower().split()
        has_semantic_cues = any(
            w in words for w in ("explain", "why", "how", "what", "when", "who", "describe")
        )
        return "lightweight"  # Phase 1 base: always lightweight; Phase 2 overrides

    # ------------------------------------------------------------------
    # Lightweight retrieval (BM25 + vector + RRF)
    # ------------------------------------------------------------------

    async def _lightweight_retrieve(
        self,
        query: str,
        constraints: RetrievalConstraints,
        owner_id: str,
    ) -> List[RetrievedItem]:
        """
        Parallel BM25 + vector search, fused with RRF.
        """
        top_k = constraints.top_k
        candidate_k = top_k * self.candidate_multiplier

        # Run BM25 and vector search in parallel
        bm25_task = asyncio.create_task(
            self._bm25_search(query, top_k=candidate_k)
        )
        vector_task = asyncio.create_task(
            self._vector_search(query, top_k=candidate_k, owner_id=owner_id)
        )

        bm25_results, vector_results = await asyncio.gather(bm25_task, vector_task)

        # Build ranked lists for RRF
        # BM25: FTS5 bm25() returns negative values (lower = better), normalise
        bm25_ranked = _normalise_bm25(bm25_results)
        vector_ranked = [(r.item_id, r.score) for r in vector_results]

        # RRF fusion
        fused = rrf_fusion([bm25_ranked, vector_ranked], k=self.rrf_k)

        # Build a content lookup from both result sets.
        # Prefer non-empty content: BM25 results carry full text while
        # vector results may have empty content (VectorResult has no content
        # field), so we only overwrite when the new entry has actual content.
        content_map: Dict[str, Tuple[str, str]] = {}  # item_id → (item_type, content)
        for r in bm25_results:
            content_map[r.item_id] = (r.item_type, r.content)
        for r in vector_results:
            new_content = _get_content(r)
            if r.item_id not in content_map or new_content:
                content_map[r.item_id] = (r.item_type, new_content)

        # Hydrate empty content from DB (vector-only results lack content)
        for item_id, (item_type, content) in list(content_map.items()):
            if not content and item_type == "claim":
                try:
                    claim = await self.storage.get_claim(item_id)
                    if claim:
                        content_map[item_id] = (
                            item_type,
                            f"{claim.subject} {claim.predicate} {claim.object_value}",
                        )
                except Exception as exc:
                    logger.debug("Failed to hydrate claim %s: %s", item_id[:8], exc)

        # --- Sensitivity filtering (issue #272) ---
        claim_ids_in_map = [
            iid for iid, (itype, _) in content_map.items() if itype == "claim"
        ]
        sensitivity_map: Dict[str, str] = {}
        if claim_ids_in_map:
            try:
                sensitivity_map = await self.storage.get_claims_sensitivity_batch(
                    claim_ids_in_map
                )
            except Exception as exc:
                logger.warning(
                    "Sensitivity batch failed (%s); excluding all claims (fail-closed).",
                    exc,
                )

        max_level = _sensitivity_level(constraints.sensitivity_max)

        def _passes_sensitivity(item_id: str, item_type: str) -> bool:
            if item_type != "claim":
                return True
            sens = sensitivity_map.get(item_id)
            return sens is not None and _sensitivity_level(sens) <= max_level

        # Apply memory_types + sensitivity filters
        items: List[RetrievedItem] = []
        for item_id, score in fused[:top_k]:
            if item_id not in content_map:
                continue
            item_type, content = content_map[item_id]
            if constraints.memory_types and item_type not in constraints.memory_types:
                continue
            if not _passes_sensitivity(item_id, item_type):
                continue
            items.append(
                RetrievedItem(
                    item_type=item_type,
                    item_id=item_id,
                    content=content,
                    score=score,
                )
            )

        return items

    # ------------------------------------------------------------------
    # BM25 search via FTS5
    # ------------------------------------------------------------------

    async def _bm25_search(self, query: str, top_k: int) -> List[_FTSResult]:
        """
        Search both fts_claims and fts_episodes, merge, return top_k.
        """
        results: List[_FTSResult] = []
        for table in ("claims", "episodes"):
            try:
                raw = await self.storage.fts_search(query, table=table, top_k=top_k)
                for r in raw:
                    results.append(
                        _FTSResult(
                            item_type=_table_to_item_type(table),
                            item_id=_get_id(r),
                            content=_get_content(r),
                            rank=_get_rank(r),
                        )
                    )
            except Exception as exc:
                logger.warning("BM25 search failed for table=%s: %s", table, exc)

        # Sort by rank (FTS5 bm25() is negative — lower/more-negative = better match)
        results.sort(key=lambda r: r.rank)
        return results[:top_k]

    # ------------------------------------------------------------------
    # Vector search (sqlite-vec or cosine fallback)
    # ------------------------------------------------------------------

    async def _vector_search(
        self,
        query: str,
        top_k: int,
        owner_id: str,
    ) -> List[_VectorResult]:
        """
        Embed the query, then ask storage for nearest neighbours.
        Falls back to brute-force cosine if sqlite-vec unavailable.
        """
        embedding = await self._embed(query)
        if embedding is None:
            # No embedding available — return empty so BM25 carries the load
            logger.info("No embedding available; skipping vector search")
            return []

        try:
            raw = await self.storage.vector_search(
                embedding, top_k=top_k, owner_id=owner_id
            )
            return [
                _VectorResult(
                    item_type=_get_item_type(r),
                    item_id=_get_id(r),
                    content=_get_content(r),
                    score=_get_score(r),
                )
                for r in raw
            ]
        except NotImplementedError:
            # Storage doesn't support vector_search — try cosine fallback
            logger.warning(
                "sqlite-vec not available; falling back to brute-force cosine similarity. "
                "Install sqlite-vec for faster ANN vector search."
            )
            return await self._cosine_fallback(embedding, top_k)
        except Exception as exc:
            logger.warning("Vector search failed: %s", exc)
            return []

    async def _cosine_fallback(
        self,
        query_embedding: List[float],
        top_k: int,
    ) -> List[_VectorResult]:
        """
        Brute-force cosine similarity over embedding_index table.
        Used when sqlite-vec extension is unavailable.
        """
        try:
            raw_embeddings = await self.storage.get_all_embeddings()  # type: ignore[attr-defined]
        except Exception as exc:
            logger.warning("Cosine fallback: get_all_embeddings failed: %s", exc)
            return []

        scored: List[Tuple[float, Any]] = []
        for row in raw_embeddings:
            stored_vec = _decode_embedding(row)
            if stored_vec is None:
                continue
            try:
                sim = cosine_similarity(query_embedding, stored_vec)
            except ValueError:
                continue
            scored.append((sim, row))

        scored.sort(key=lambda x: x[0], reverse=True)
        results = []
        for sim, row in scored[:top_k]:
            results.append(
                _VectorResult(
                    item_type=_get_item_type(row),
                    item_id=_get_id(row),
                    content=_get_content(row),
                    score=sim,
                )
            )
        return results

    # ------------------------------------------------------------------
    # Embedding
    # ------------------------------------------------------------------

    async def _embed(self, text: str) -> Optional[List[float]]:
        """
        Produce an embedding for ``text``.
        Tries the storage adapter's embed helper first (if it has one),
        then the LLM provider. Returns None if unavailable.
        """
        # Try storage-provided embedding (some adapters wrap the embedding model)
        if hasattr(self.storage, "embed"):
            try:
                return await self.storage.embed(text)  # type: ignore[attr-defined]
            except Exception as exc:
                logger.debug("storage.embed failed: %s", exc)

        # Try LLM provider
        if self.llm is not None and hasattr(self.llm, "embed"):
            try:
                _embed_resp = await self.llm.embed(texts=[text])
                return _embed_resp.embeddings[0] if hasattr(_embed_resp, "embeddings") else _embed_resp
            except Exception as exc:
                logger.debug("llm.embed failed: %s", exc)

        return None

    # ------------------------------------------------------------------
    # Token budget enforcement
    # ------------------------------------------------------------------

    async def _apply_budget(
        self,
        items: List[RetrievedItem],
        constraints: RetrievalConstraints,
    ) -> Tuple[int, List[RetrievedItem]]:
        """
        Trim items list so total token count stays within budget.
        Returns (tokens_used, trimmed_items).
        """
        # Determine ceiling
        if constraints.token_budget is not None:
            budget = constraints.token_budget
        else:
            budget = getattr(self.config, "retrieval_token_budget", 3000)

        trimmed: List[RetrievedItem] = []
        tokens_used = 0

        for item in items:
            item_tokens = self._count_tokens(item.content)
            if tokens_used + item_tokens > budget:
                logger.debug(
                    "Budget exhausted at %d/%d tokens — dropping remaining %d items",
                    tokens_used, budget, len(items) - len(trimmed),
                )
                break
            trimmed.append(item)
            tokens_used += item_tokens

        return tokens_used, trimmed

    def _count_tokens(self, text: str) -> int:
        """Count tokens — delegate to TokenBudgetManager if available, else word-approx."""
        if self.token_budget is not None and hasattr(self.token_budget, "count_tokens"):
            try:
                return self.token_budget.count_tokens(text)
            except Exception as e:
                logger.warning("cortex_core_retrieval: unhandled exception: %s", e)
        # Fallback: ~1.3 tokens per word (rough BPE approximation)
        return max(1, int(len(text.split()) * 1.3))

    # ------------------------------------------------------------------
    # Retrieval logging
    # ------------------------------------------------------------------

    async def _log_retrieval(
        self,
        *,
        retrieval_id: str,
        owner_id: str,
        query: str,
        mode: str,
        constraints: RetrievalConstraints,
        items: List[RetrievedItem],
        tokens_used: int,
        latency_ms: int,
    ) -> None:
        """Log retrieval metadata to retrieval_log table."""
        import json

        selected = [
            {"item_id": it.item_id, "item_type": it.item_type, "score": it.score}
            for it in items
        ]
        context_hash = hashlib.sha256(
            json.dumps(selected, sort_keys=True).encode()
        ).hexdigest()[:16]

        try:
            await self.storage.log_retrieval(
                id=retrieval_id,
                owner_id=owner_id,
                query_text=query,
                mode=mode,
                token_budget=constraints.token_budget or getattr(
                    self.config, "retrieval_token_budget", 3000
                ),
                tokens_used=tokens_used,
                selected_json=json.dumps(selected),
                final_context_hash=context_hash,
                latency_ms=latency_ms,
                created_at=datetime.now(timezone.utc).isoformat(),
            )
        except Exception as exc:
            logger.warning("Failed to log retrieval %s: %s", retrieval_id, exc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _new_id() -> str:
    return uuid.uuid4().hex


def _normalise_bm25(
    results: List[_FTSResult],
) -> List[Tuple[str, float]]:
    """Convert FTS5 bm25() scores to [0,1] similarity scores for RRF input.

    SQLite FTS5's bm25() returns negative values where more negative = better match.
    We negate to make larger = better, then min-max normalise to [0, 1] so the
    scores are compatible with vector similarity scores in RRF fusion.

    Args:
        results: List of FTS results with .rank (negative bm25 scores).

    Returns:
        List of (item_id, normalised_score) tuples, higher = better match.
    """
    if not results:
        return []
    # bm25() values are ≤ 0; negate so larger = better, then min-max normalise
    ranks = [-r.rank for r in results]  # now all ≥ 0
    min_r, max_r = min(ranks), max(ranks)
    span = max_r - min_r or 1.0
    normalised = [(r.item_id, (rank - min_r) / span) for r, rank in zip(results, ranks)]
    return normalised


def _table_to_item_type(table: str) -> str:
    return {"claims": "claim", "episodes": "event"}.get(table, table)


# The following helpers handle both dataclass objects and plain dicts/namedtuples
# returned by different StorageAdapter implementations.

def _get_id(obj: Any) -> str:
    if hasattr(obj, "item_id"):
        return obj.item_id
    if hasattr(obj, "claim_id"):
        return obj.claim_id
    if hasattr(obj, "event_id"):
        return obj.event_id
    if isinstance(obj, dict):
        return obj.get("item_id") or obj.get("claim_id") or obj.get("event_id") or ""
    return str(getattr(obj, "id", ""))


def _get_content(obj: Any) -> str:
    if hasattr(obj, "content"):
        return obj.content
    if isinstance(obj, dict):
        return obj.get("content", "")
    return ""


def _get_rank(obj: Any) -> float:
    for attr in ("rank", "bm25_rank", "score"):
        if hasattr(obj, attr):
            return float(getattr(obj, attr))
    if isinstance(obj, dict):
        return float(obj.get("rank", obj.get("score", 0.0)))
    return 0.0


def _get_score(obj: Any) -> float:
    if hasattr(obj, "score"):
        return float(obj.score)
    if isinstance(obj, dict):
        return float(obj.get("score", 0.0))
    return 0.0


def _get_item_type(obj: Any) -> str:
    if hasattr(obj, "item_type"):
        return obj.item_type
    if isinstance(obj, dict):
        return obj.get("item_type", "claim")
    return "claim"


def _decode_embedding(row: Any) -> Optional[List[float]]:
    """Decode a stored embedding blob or list back to a Python float list."""
    raw = getattr(row, "embedding", None) or (
        row.get("embedding") if isinstance(row, dict) else None
    )
    if raw is None:
        return None
    if isinstance(raw, (list, tuple)):
        return [float(x) for x in raw]
    if isinstance(raw, (bytes, bytearray)):
        import struct
        n = len(raw) // 4
        return list(struct.unpack(f"{n}f", raw[:n * 4]))
    return None
