"""
cortex/core/token_budget.py — Token Budget Manager (Module 9 / M9).

Manages token allocation for memory injection into the agent's context window.
This is the "resource scheduler" for memory — it ensures that the most important
memories (cornerstones) are always included, while lower-priority content
competes for the remaining budget.

Priority order (highest → lowest):
    CORNERSTONE (reserved, guaranteed) → SESSION → SEMANTIC → PROCEDURAL

Key design decisions:
    - Cornerstones get a RESERVED allocation that's held regardless of actual
      content size. This ensures cornerstone space is always available.
    - Non-cornerstone layers get soft caps as fractions of the remaining budget:
      SESSION (40%) → SEMANTIC (35%) → PROCEDURAL (25%).
    - Token counting uses tiktoken's cl100k_base encoding (Claude/GPT-4 family).
    - Items within each layer are included greedily from the front (assumed to be
      pre-sorted by relevance from RetrievalPipeline).

Dependencies:
    - tiktoken (cl100k_base encoding for token counting)
    - cortex.types.BudgetAllocation, cortex.types.MemoryLayer

Used by:
    - RetrievalPipeline (M8) — calls count_tokens() and create_budget()
    - CortexPlugin (M13) — assemble_context() uses allocate_layers()

Usage::

    manager = TokenBudgetManager(config)
    budget = manager.create_budget()

    result = manager.allocate_layers(
        layers={
            MemoryLayer.CORNERSTONE: ["cornerstone memory text..."],
            MemoryLayer.SESSION: ["recent conversation..."],
            MemoryLayer.SEMANTIC: ["long-term fact..."],
            MemoryLayer.PROCEDURAL: ["how to do X..."],
        }
    )
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import tiktoken

from cortex.types import BudgetAllocation, MemoryLayer

logger = logging.getLogger(__name__)

# Tiktoken encoding used for token counting.
# cl100k_base is used by Claude/GPT-4 family.
_ENCODING_NAME = "cl100k_base"


@dataclass
class TokenBudget:
    """Live budget state tracking allocation across memory layers.

    Created via TokenBudgetManager.create_budget().
    """

    total: int
    """Total token budget (default 4000)."""

    reserved_cornerstones: int
    """Tokens unconditionally reserved for cornerstones."""

    allocated: Dict[str, int] = field(default_factory=dict)
    """Tokens allocated per category key so far."""

    def remaining(self) -> int:
        """Tokens still available for non-cornerstone allocation."""
        used = self.reserved_cornerstones + sum(self.allocated.values())
        return max(0, self.total - used)

    def allocate(self, category: str, tokens: int) -> bool:
        """Attempt to allocate *tokens* to *category*.

        Returns True if the allocation fits within the remaining budget,
        False if the budget would be exceeded (allocation is NOT recorded).
        """
        if tokens <= self.remaining():
            self.allocated[category] = self.allocated.get(category, 0) + tokens
            return True
        return False

    def used(self) -> int:
        """Total tokens consumed including cornerstone reservation."""
        return self.reserved_cornerstones + sum(self.allocated.values())

    def utilization(self) -> float:
        """Budget utilization as a fraction [0.0, 1.0]."""
        if self.total == 0:
            return 0.0
        return self.used() / self.total


# ---------------------------------------------------------------------------
# Minimal config duck-type (avoids circular import from cortex.config)
# ---------------------------------------------------------------------------

class _ConfigProtocol:
    """Structural type expected from CortexConfig."""
    total_memory_token_budget: int
    cornerstone_token_budget: int


class TokenBudgetManager:
    """Count tokens and manage budget allocation across memory types.

    Responsibilities:
    - Accurate token counting via tiktoken (cl100k_base)
    - Per-layer budget allocation with cornerstone reservation guarantee
    - Truncation of lowest-priority content when budget is exceeded
    - Configurable total budget and per-layer soft limits
    """

    # Default budgets (tokens). Override via CortexConfig or constructor args.
    DEFAULT_TOTAL_BUDGET: int = 4000
    DEFAULT_CORNERSTONE_BUDGET: int = 800

    # Default fractional soft caps for non-cornerstone layers.
    # Applied as a fraction of the non-cornerstone budget (total - cornerstones).
    DEFAULT_LAYER_FRACTIONS: Dict[str, float] = {
        MemoryLayer.SESSION.value: 0.40,      # 40% of non-cornerstone budget
        MemoryLayer.SEMANTIC.value: 0.35,     # 35%
        MemoryLayer.PROCEDURAL.value: 0.25,   # 25%
    }

    def __init__(
        self,
        config: Optional[_ConfigProtocol] = None,
        *,
        total_budget: Optional[int] = None,
        cornerstone_budget: Optional[int] = None,
        layer_fractions: Optional[Dict[str, float]] = None,
    ) -> None:
        """Initialise the manager.

        Args:
            config: CortexConfig instance (reads total_memory_token_budget and
                    cornerstone_token_budget from it).  If None, defaults are used.
            total_budget: Override total token budget (takes precedence over config).
            cornerstone_budget: Override cornerstone reservation.
            layer_fractions: Dict mapping MemoryLayer.value → fraction of
                             non-cornerstone budget.  Must sum to ≤ 1.0.
        """
        if total_budget is not None:
            self._total_budget = total_budget
        elif config is not None:
            self._total_budget = config.total_memory_token_budget
        else:
            self._total_budget = self.DEFAULT_TOTAL_BUDGET

        if cornerstone_budget is not None:
            self._cornerstone_budget = cornerstone_budget
        elif config is not None:
            self._cornerstone_budget = config.cornerstone_token_budget
        else:
            self._cornerstone_budget = self.DEFAULT_CORNERSTONE_BUDGET

        if self._cornerstone_budget > self._total_budget:
            raise ValueError(
                f"cornerstone_budget ({self._cornerstone_budget}) exceeds "
                f"total_budget ({self._total_budget})"
            )

        self._layer_fractions: Dict[str, float] = (
            layer_fractions if layer_fractions is not None
            else dict(self.DEFAULT_LAYER_FRACTIONS)
        )

        # Initialise tiktoken encoder (cl100k_base — Claude/GPT-4 family).
        try:
            self.encoder = tiktoken.get_encoding(_ENCODING_NAME)
        except Exception as exc:  # pragma: no cover
            logger.warning("tiktoken encoding %s unavailable: %s", _ENCODING_NAME, exc)
            raise

    # ------------------------------------------------------------------
    # Token counting
    # ------------------------------------------------------------------

    def count_tokens(self, text: str) -> int:
        """Return the exact token count for *text* using tiktoken."""
        if not text:
            return 0
        return len(self.encoder.encode(text))

    def count_tokens_batch(self, texts: List[str]) -> List[int]:
        """Return token counts for a list of texts."""
        return [self.count_tokens(t) for t in texts]

    # ------------------------------------------------------------------
    # Budget creation
    # ------------------------------------------------------------------

    def create_budget(self, total: Optional[int] = None) -> TokenBudget:
        """Create a fresh TokenBudget with the configured allocations.

        Args:
            total: Override total token budget for this specific budget instance.
                   Defaults to the value set at construction time.
        """
        total_tokens = total if total is not None else self._total_budget
        cornerstone_reserved = min(self._cornerstone_budget, total_tokens)
        return TokenBudget(
            total=total_tokens,
            reserved_cornerstones=cornerstone_reserved,
            allocated={},
        )

    # ------------------------------------------------------------------
    # Soft cap helpers
    # ------------------------------------------------------------------

    def layer_soft_cap(self, layer: MemoryLayer, total: Optional[int] = None) -> int:
        """Return the soft token cap for a non-cornerstone *layer*.

        The cap is a fraction of the non-cornerstone budget.
        """
        total_tokens = total if total is not None else self._total_budget
        non_cornerstone = max(0, total_tokens - self._cornerstone_budget)
        fraction = self._layer_fractions.get(layer.value, 0.0)
        return int(non_cornerstone * fraction)

    # ------------------------------------------------------------------
    # Allocation
    # ------------------------------------------------------------------

    def allocate_layers(
        self,
        layers: Dict[MemoryLayer, List[str]],
        total: Optional[int] = None,
    ) -> BudgetAllocation:
        """Allocate budget across memory layers respecting priority order.

        Args:
            layers: Mapping of MemoryLayer → list of content strings to inject.
            total: Override total budget for this allocation pass.

        Returns:
            BudgetAllocation with per-layer token counts and any truncated content.

        Behaviour:
        - Cornerstones always get their full reserved allocation (guaranteed).
        - Remaining layers are filled in priority order: SESSION → SEMANTIC → PROCEDURAL.
        - If a layer's content exceeds its remaining budget, items are dropped from
          the tail (lowest-relevance items last, consistent with ranked retrieval).
        - Truncated token counts are recorded in BudgetAllocation.truncated.
        """
        total_tokens = total if total is not None else self._total_budget
        budget = self.create_budget(total_tokens)

        allocations: Dict[str, int] = {}
        truncated: Dict[str, int] = {}

        # --- Pass 1: Cornerstones (guaranteed, up to reserved amount) ---
        cornerstone_texts = layers.get(MemoryLayer.CORNERSTONE, [])
        cornerstone_tokens = 0
        cornerstone_truncated = 0

        for text in cornerstone_texts:
            t = self.count_tokens(text)
            if cornerstone_tokens + t <= self._cornerstone_budget:
                cornerstone_tokens += t
            else:
                cornerstone_truncated += t
                logger.debug(
                    "Cornerstone item truncated (exceeded reserved %d tokens)",
                    self._cornerstone_budget,
                )

        if cornerstone_tokens > 0:
            allocations[MemoryLayer.CORNERSTONE.value] = cornerstone_tokens
        if cornerstone_truncated > 0:
            truncated[MemoryLayer.CORNERSTONE.value] = cornerstone_truncated

        # Update budget's cornerstone reservation to actual usage
        # (we still hold reserved_cornerstones as the ceiling)

        # --- Pass 2: Remaining layers in priority order ---
        non_cornerstone_layers = [
            l for l in MemoryLayer.by_priority()
            if l != MemoryLayer.CORNERSTONE
        ]

        # Available tokens = total - cornerstone_reserved (not actual usage —
        # the reservation is held regardless of actual cornerstone content size).
        available = max(0, total_tokens - self._cornerstone_budget)

        for layer in non_cornerstone_layers:
            texts = layers.get(layer, [])
            if not texts:
                continue

            soft_cap = self.layer_soft_cap(layer, total_tokens)
            layer_tokens = 0
            layer_truncated = 0

            for text in texts:
                t = self.count_tokens(text)
                # soft_cap == 0 means the layer has no budget allocation
                fits_in_layer = soft_cap > 0 and (layer_tokens + t) <= soft_cap
                fits_in_budget = (layer_tokens + t) <= available

                if fits_in_layer and fits_in_budget:
                    layer_tokens += t
                else:
                    layer_truncated += t

            if layer_tokens > 0:
                allocations[layer.value] = layer_tokens
                available -= layer_tokens

            if layer_truncated > 0:
                truncated[layer.value] = layer_truncated
                logger.debug(
                    "Layer %s truncated %d tokens (budget exhausted or soft cap hit)",
                    layer.value, layer_truncated,
                )

        return BudgetAllocation(
            total_budget=total_tokens,
            cornerstone_reserved=self._cornerstone_budget,
            allocations=allocations,
            truncated=truncated,
        )

    # ------------------------------------------------------------------
    # Truncation helpers
    # ------------------------------------------------------------------

    def truncate_to_budget(
        self,
        text: str,
        max_tokens: int,
        *,
        truncation_suffix: str = "…",
    ) -> str:
        """Truncate *text* to fit within *max_tokens* tokens.

        Appends *truncation_suffix* when truncation occurs.
        Uses tiktoken for accurate token-level truncation.
        """
        if max_tokens <= 0:
            return ""

        tokens = self.encoder.encode(text)
        if len(tokens) <= max_tokens:
            return text

        suffix_tokens = self.encoder.encode(truncation_suffix)
        keep = max_tokens - len(suffix_tokens)
        if keep <= 0:
            return truncation_suffix

        truncated = self.encoder.decode(tokens[:keep])
        return truncated + truncation_suffix

    def fit_items_to_budget(
        self,
        items: List[str],
        max_tokens: int,
    ) -> tuple[List[str], int]:
        """Select as many items as possible from *items* within *max_tokens*.

        Items are taken in order (highest relevance first); excess items are
        dropped entirely (no partial truncation of individual items).

        Returns:
            (selected_items, total_tokens_used)
        """
        selected: List[str] = []
        used = 0

        for item in items:
            t = self.count_tokens(item)
            if used + t <= max_tokens:
                selected.append(item)
                used += t
            else:
                break  # Remaining items won't fit either (greedy from front)

        return selected, used

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def total_budget(self) -> int:
        return self._total_budget

    @property
    def cornerstone_budget(self) -> int:
        return self._cornerstone_budget

    def __repr__(self) -> str:
        return (
            f"TokenBudgetManager("
            f"total={self._total_budget}, "
            f"cornerstone_reserved={self._cornerstone_budget})"
        )
