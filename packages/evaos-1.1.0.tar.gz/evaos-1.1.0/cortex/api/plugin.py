"""
cortex/api/plugin.py — CortexPlugin: Main Entry Point (Module 13 / M13).

The orchestration layer that wires ALL Cortex modules together into a single,
coherent API. This is the ONLY class that host applications (MCP server, HTTP
server, direct integration) need to interact with.

Modules wired:
    M1:  SQLiteStorageAdapter — persistence
    M2:  ExtractionPipeline — claim extraction from conversation
    M3:  EntityResolver — entity canonicalization
    M4:  ReconciliationEngine — claim dedup/merge/supersede
    M5:  CornerstoneGuardian — identity protection
    M8:  RetrievalPipeline — memory search and context assembly
    M9:  TokenBudgetManager — context window budget allocation
    M11: DriftCalculator — cornerstone integrity monitoring
    M12: FeedbackSystem — retrieval quality tracking

Public API surface (all async):
    remember(messages, session_id)  → extract + reconcile + store claims
    retrieve(query)                 → search + rank + budget-trim memories
    forget(memory_id)               → soft-delete a claim (cornerstone-protected)
    feedback(memory_id, helpful)    → rate a retrieved memory
    wake(session_id)                → start a session, load cornerstones
    sleep(session_id)               → end a session, run dream cycle
    health()                        → system health check

Guard rails:
    - No module failure crashes the plugin — every module call is wrapped in try/except
    - Cornerstone protection on forget() (refuses to delete cornerstones)
    - All public methods return typed result dataclasses (never raw dicts)
    - Graceful degradation: if a module is unavailable, the plugin continues
      with reduced functionality rather than crashing

Dependencies: All Cortex modules (M1-M12).
Used by: cortex.api.mcp_server (MCP tools), cortex.api.http_server (REST API).
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from cortex.validation import (
    validate_conversation,
    validate_retrieve_query,
    validate_cornerstone_fields,
)
from cortex.llm.fallback import build_provider_cascade
from cortex.extraction.dedup import deduplicate_claims
from cortex.logging_utils import install_redaction_filter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result / report types
# ---------------------------------------------------------------------------

@dataclass
class RememberResult:
    """Result of the remember() pipeline (extract → reconcile → store).

    Attributes:
        session_id: Session this remember() call belongs to.
        claims_extracted: How many claims the LLM extracted from the conversation.
        claims_stored: How many claims were actually persisted (after dedup).
        entities_resolved: How many entity mentions were resolved to canonical IDs.
        noise_filtered: How many messages were dropped by the noise filter.
        errors: List of non-fatal error messages (module failures that didn't crash).
        ok: True if the pipeline completed without fatal errors.
    """
    session_id: str
    claims_extracted: int
    claims_stored: int
    entities_resolved: int
    noise_filtered: int
    errors: List[str] = field(default_factory=list)
    ok: bool = True


@dataclass
class ForgetResult:
    """Result of the forget() operation.

    Attributes:
        memory_id: The claim ID that was targeted for deletion.
        deleted: True if the claim was successfully soft-deleted (archived).
                 False if the claim is a cornerstone (deletion blocked) or not found.
    """
    memory_id: str
    deleted: bool
    reason: str = ""
    errors: List[str] = field(default_factory=list)


@dataclass
class HealthReport:
    """Returned by health()."""
    ok: bool
    storage: str = "unknown"
    modules: Dict[str, str] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: _now())


@dataclass
class EvolutionProposalResult:
    """Returned by propose_cornerstone_evolution().

    Attributes:
        action: 'auto_applied' | 'queued'
        proposal_id: ID of the stored proposal.
        proposed_content: The LLM-generated revised golden copy.
        diff: Unified diff between original and proposed content.
        reasoning: LLM explanation for the proposed change.
        confidence: LLM-reported confidence (0.0–1.0).
        requires_operator_review: False only when auto-applied.
        cornerstone: Updated CornerstoneMemory (only when auto-applied).
        errors: Non-fatal errors encountered.
        ok: False if the operation failed entirely.
    """
    action: str
    proposal_id: str
    proposed_content: str
    diff: str
    reasoning: str
    confidence: float
    requires_operator_review: bool = True
    cornerstone: Any = None
    errors: List[str] = field(default_factory=list)
    ok: bool = True


@dataclass
class AskResult:
    """Returned by ask() — synthesised answer from retrieved memories.

    Attributes:
        answer:     LLM-generated answer grounded in stored memories.
        sources:    Memory dicts used to produce the answer.
        confidence: Mean retrieval score of the sources (0.0–1.0).
        reasoning:  Short note on how the answer was derived.
        errors:     Non-fatal errors (empty when everything worked).
        ok:         False only on hard failure (LLM unavailable, etc.).
    """

    answer: str
    sources: List[Dict[str, Any]] = field(default_factory=list)
    confidence: float = 0.0
    reasoning: str = ""
    errors: List[str] = field(default_factory=list)
    ok: bool = True


@dataclass
class WakeReport:
    """Returned by wake()."""
    session_id: str
    cornerstones_loaded: int = 0
    errors: List[str] = field(default_factory=list)


@dataclass
class SleepReport:
    """Returned by sleep()."""
    session_id: str
    memories_summarised: int = 0
    errors: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def _new_session_id() -> str:
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# CortexPlugin
# ---------------------------------------------------------------------------

class CortexPlugin:
    """
    Main plugin class — single entry point for all Cortex operations.

    Usage::

        plugin = CortexPlugin(config_path="~/.config/cortex.toml")
        await plugin.wake()
        result = await plugin.remember(conversation)
        context = await plugin.retrieve("What does the user prefer?")
        await plugin.sleep()
    """

    def __init__(
        self,
        config_path: Optional[str] = None,
        db_path: Optional[str] = None,
    ) -> None:
        """
        Initialize all Cortex modules with dependency injection.

        Modules are initialised in order:
          config → storage → llm → extraction → entity_resolution →
          reconciliation → cornerstone → token_budget → retrieval → feedback

        Any module that fails to initialise is recorded; the plugin remains
        functional with degraded capability rather than crashing.
        """
        self._init_errors: List[str] = []
        self._session_id: Optional[str] = None
        self._llm_call_count: int = 0   # resets on wake()

        # Install API key redaction on root logger (idempotent)
        install_redaction_filter()

        # -- Config ----------------------------------------------------------
        try:
            from cortex.config import CortexConfig
            self.config = CortexConfig.from_toml(config_path)
            if db_path:
                self.config.storage_db_path = db_path
        except Exception as exc:  # pragma: no cover
            logger.error("Failed to load CortexConfig: %s", exc)
            self._init_errors.append(f"config: {exc}")
            # Fall back to defaults inline so other modules can still init
            from cortex.config import CortexConfig
            self.config = CortexConfig()
            if db_path:
                self.config.storage_db_path = db_path

        # -- Storage (M1) ----------------------------------------------------
        self.storage: Any = None
        try:
            from cortex.storage.sqlite_adapter import SQLiteAdapter
            self.storage = SQLiteAdapter(
                db_path=self.config.storage_db_path,
                enable_wal=self.config.storage_enable_wal,
                busy_timeout_ms=self.config.storage_busy_timeout_ms,
            )
        except Exception as exc:
            logger.error("Failed to init SQLiteAdapter: %s", exc)
            self._init_errors.append(f"storage: {exc}")

        # -- LLM Provider (config-driven cascade) ----------------------------
        self.llm: Any = None
        try:
            priority = list(self.config.llm_provider_priority)
            self.llm = build_provider_cascade(
                priority,
                completion_model=self.config.extraction_model,
                embed_model=self.config.embedding_model,
            )
            logger.info(
                "CortexPlugin: LLM cascade initialised — priority: %s, "
                "active providers: %s",
                priority,
                self.llm.provider_names(),
            )
        except Exception as exc:
            logger.error("Failed to init LLM provider cascade: %s", exc)
            self._init_errors.append(f"llm: {exc}")

        # -- Extraction Pipeline (M2) ----------------------------------------
        self.extractor: Any = None
        try:
            from cortex.extraction.extractor import ExtractionPipeline
            self.extractor = ExtractionPipeline(
                llm=self.llm,
                model=self.config.extraction_model,
                custom_instructions=getattr(self.config, "extraction_custom_instructions", ""),
            )
        except Exception as exc:
            logger.error("Failed to init ExtractionPipeline: %s", exc)
            self._init_errors.append(f"extraction: {exc}")

        # -- Entity Resolver (M3) --------------------------------------------
        self.entity_resolver: Any = None
        try:
            from cortex.core.entity_resolution import EntityResolver
            self.entity_resolver = EntityResolver(
                storage=self.storage,
                llm=self.llm,
            )
        except Exception as exc:
            logger.error("Failed to init EntityResolver: %s", exc)
            self._init_errors.append(f"entity_resolution: {exc}")

        # -- Reconciliation Engine (M4) --------------------------------------
        self.reconciler: Any = None
        try:
            from cortex.core.reconciliation import ReconciliationEngine
            self.reconciler = ReconciliationEngine(
                storage=self.storage,
                llm=self.llm,
                entity_resolver=self.entity_resolver,
                config=self.config,
            )
        except Exception as exc:
            logger.error("Failed to init ReconciliationEngine: %s", exc)
            self._init_errors.append(f"reconciliation: {exc}")

        # -- Cornerstone Guardian (M5) ---------------------------------------
        self.cornerstone_guardian: Any = None
        try:
            from cortex.identity.cornerstone import CornerstoneGuardian
            self.cornerstone_guardian = CornerstoneGuardian(
                storage=self.storage,
                config=self.config,
                llm=self.llm,  # pass LLM for propose_evolution()
            )
        except Exception as exc:
            logger.error("Failed to init CornerstoneGuardian: %s", exc)
            self._init_errors.append(f"cornerstone: {exc}")

        # -- Token Budget Manager (M9) ---------------------------------------
        self.token_budget_manager: Any = None
        try:
            from cortex.core.token_budget import TokenBudgetManager
            self.token_budget_manager = TokenBudgetManager(config=self.config)
        except Exception as exc:
            logger.error("Failed to init TokenBudgetManager: %s", exc)
            self._init_errors.append(f"token_budget: {exc}")

        # -- Retrieval Pipeline (M8) -----------------------------------------
        self.retrieval: Any = None
        try:
            from cortex.core.retrieval import RetrievalPipeline
            self.retrieval = RetrievalPipeline(
                storage=self.storage,
                config=self.config,
                token_budget=self.token_budget_manager,
                cornerstone_guardian=self.cornerstone_guardian,
                llm=self.llm,
                vector_weight=self.config.retrieval_vector_weight,
                bm25_weight=self.config.retrieval_bm25_weight,
            )
        except Exception as exc:
            logger.error("Failed to init RetrievalPipeline: %s", exc)
            self._init_errors.append(f"retrieval: {exc}")

        # -- Embedding model switch protection --------------------------------
        self._embedding_model_changed: bool = False
        self._embedding_model_warning_emitted: bool = False
        self._check_embedding_model_consistency()

        # -- Feedback System (M12) -------------------------------------------
        self.feedback_system: Any = None
        try:
            from cortex.core.feedback import FeedbackSystem
            self.feedback_system = FeedbackSystem(
                storage=self.storage,
                owner_id=self.config.owner_id,
            )
        except Exception as exc:
            logger.error("Failed to init FeedbackSystem: %s", exc)
            self._init_errors.append(f"feedback: {exc}")

        # -- Event Emitter (M19 — In-process event bus) ----------------------
        # Wire WebhookDispatcher → EventEmitter so ALL events get outbound delivery
        self.event_emitter: Any = None
        self._webhook_dispatcher: Any = None
        try:
            from cortex.events import EventEmitter
            from cortex.events.webhook import WebhookDispatcher
            self._webhook_dispatcher = WebhookDispatcher(storage=self.storage)
            self.event_emitter = EventEmitter(
                storage=self.storage,
                webhook_dispatcher=self._webhook_dispatcher,
            )
        except Exception as exc:
            logger.error("Failed to init EventEmitter: %s", exc)
            self._init_errors.append(f"event_emitter: {exc}")

        if self._init_errors:
            logger.warning(
                "CortexPlugin initialised with %d error(s): %s",
                len(self._init_errors),
                "; ".join(self._init_errors),
            )
        else:
            logger.info("CortexPlugin initialised successfully")

    # =========================================================================
    # EMBEDDING MODEL CONSISTENCY CHECK
    # =========================================================================

    def _check_embedding_model_consistency(self) -> None:
        """Check if the embedding model has changed since last run.

        Reads the previously used embedding model from the cortex_config table
        and compares it with the current config. If different and embeddings
        exist, logs a loud warning and sets a flag.
        """
        if self.storage is None:
            return

        current_model = self.config.embedding_model

        try:
            # Read previously stored model from DB
            conn = self.storage._get_connection()
            cursor = conn.execute(
                "SELECT value FROM cortex_config WHERE key = 'embedding_model'"
            )
            row = cursor.fetchone()
            previous_model = row[0] if row else None

            # Check if embeddings exist
            embed_cursor = conn.execute(
                "SELECT COUNT(*) FROM embedding_index"
            )
            embed_count = embed_cursor.fetchone()[0]

            if previous_model and previous_model != current_model and embed_count > 0:
                logger.warning(
                    "⚠️  EMBEDDING MODEL CHANGED from '%s' to '%s'. "
                    "%d existing embeddings are INCOMPATIBLE and will produce "
                    "degraded search results. Consider re-indexing or reverting "
                    "the model change.",
                    previous_model,
                    current_model,
                    embed_count,
                )
                self._embedding_model_changed = True

            # Store current model for next startup comparison
            conn.execute(
                "INSERT OR REPLACE INTO cortex_config (key, value) VALUES (?, ?)",
                ("embedding_model", current_model),
            )
            conn.commit()
        except Exception as exc:
            # Table might not exist yet — that's fine, first run
            logger.debug(
                "Embedding model consistency check skipped: %s", exc
            )

    # =========================================================================
    # LLM BUDGET GUARD
    # =========================================================================

    def _budget_check(self, calls_needed: int = 1) -> Optional[str]:
        """Return an error string if *calls_needed* LLM calls would exceed budget.

        Returns None when the budget is sufficient (call is allowed).
        Disabled (returns None always) when max_llm_calls_per_session == 0.
        """
        limit = self.config.max_llm_calls_per_session
        if limit == 0:
            return None  # budget guard disabled
        if self._llm_call_count + calls_needed > limit:
            return (
                f"LLM call budget exhausted: {self._llm_call_count}/{limit} calls "
                f"used this session. Reset on wake()."
            )
        return None

    def _budget_consume(self, n: int = 1) -> None:
        """Consume *n* LLM calls from the session budget and warn at 80%."""
        self._llm_call_count += n
        limit = self.config.max_llm_calls_per_session
        if limit == 0:
            return
        pct = self._llm_call_count / limit
        if pct >= 0.8:
            logger.warning(
                "LLM call budget at %.0f%% (%d/%d calls used this session)",
                pct * 100,
                self._llm_call_count,
                limit,
            )

    # =========================================================================
    # WRITE
    # =========================================================================

    async def remember(
        self,
        conversation: Any,
        session_id: Optional[str] = None,
        scope: str = "user",
    ) -> RememberResult:
        """
        Extract claims from *conversation* and persist them to memory.

        Pipeline: extract → resolve entities → reconcile → (auto-stored in reconcile)

        Args:
            conversation: List of message dicts, raw text string, or any
                          object ExtractionPipeline.extract() accepts.
            session_id:   Associate memories with this session.
            scope:        Owner scope (default: 'user').

        Returns:
            RememberResult with counts and any soft errors encountered.
        """
        sid = session_id or self._session_id or _new_session_id()
        errors: List[str] = []
        claims_extracted = 0
        claims_stored = 0
        entities_resolved = 0
        noise_filtered = 0

        # 0a. Validate conversation input
        conversation = validate_conversation(conversation)

        # 0. Ensure session_record exists (FK constraint on semantic_claim.source_session)
        # The DB PK (session_record.id) is what semantic_claim.source_session references,
        # so we need to use it (not the user-facing session_id) for FK compliance.
        db_session_pk = None
        if self.storage is not None:
            try:
                session_rec = await self.storage.create_session(
                    session_id=sid,
                    owner_id=self.config.owner_id,
                )
                db_session_pk = session_rec.id
            except Exception as exc:
                # Session may already exist (e.g. wake() already created it).
                # Look up the existing record to get its internal PK.
                logger.debug("Session record creation (may already exist): %s", exc)
                try:
                    existing = await self.storage.get_session_by_sid(
                        session_id=sid,
                        owner_id=self.config.owner_id,
                    )
                    if existing is not None:
                        db_session_pk = existing.id
                except Exception as lookup_exc:
                    logger.warning("Failed to look up existing session: %s", lookup_exc)

        # 0b. Check extraction_enabled toggle --------------------------------
        if not getattr(self.config, "extraction_enabled", True):
            logger.info(
                "Extraction disabled (extraction_enabled=False) — skipping extraction for session %s",
                sid,
            )
            return RememberResult(
                session_id=sid,
                claims_extracted=0,
                claims_stored=0,
                entities_resolved=0,
                noise_filtered=0,
                errors=[],
                ok=True,
            )

        # 1. Extraction -------------------------------------------------------
        extraction_result = None
        if self.extractor is None:
            err = "ExtractionPipeline not available — skipping extraction"
            logger.warning(err)
            errors.append(err)
        else:
            budget_err = self._budget_check(1)
            if budget_err:
                logger.error("Skipping extraction: %s", budget_err)
                errors.append(budget_err)
                return RememberResult(
                    session_id=sid,
                    claims_extracted=0,
                    claims_stored=0,
                    entities_resolved=0,
                    noise_filtered=noise_filtered,
                    errors=errors,
                    ok=False,
                )
            try:
                self._budget_consume(1)
                extraction_result = await self.extractor.extract(
                    conversation,
                    session_id=sid,
                )
                claims_extracted = len(extraction_result.claims)
                noise_filtered = extraction_result.noise_filtered
                logger.debug(
                    "Extracted %d claims (noise filtered: %d)",
                    claims_extracted,
                    noise_filtered,
                )
            except Exception as exc:
                err = f"Extraction failed: {exc}"
                logger.error(err, exc_info=True)
                errors.append(err)

        if extraction_result is None or not extraction_result.claims:
            return RememberResult(
                session_id=sid,
                claims_extracted=claims_extracted,
                claims_stored=0,
                entities_resolved=0,
                noise_filtered=noise_filtered,
                errors=errors,
                ok=not errors,
            )

        # 1b. Per-batch extraction cap ----------------------------------------
        batch_limit = self.config.max_extraction_calls_per_batch
        if batch_limit > 0 and len(extraction_result.claims) > batch_limit:
            dropped = len(extraction_result.claims) - batch_limit
            logger.warning(
                "Capping extraction batch: %d claims → %d (max_extraction_calls_per_batch=%d, dropped %d)",
                len(extraction_result.claims),
                batch_limit,
                batch_limit,
                dropped,
            )
            extraction_result.claims = extraction_result.claims[:batch_limit]

        # 1c. Extraction-time deduplication -----------------------------------
        # Filter out exact-hash duplicates and collect near-duplicate merge
        # candidates before any LLM reconciliation calls.
        if extraction_result.claims and self.storage is not None:
            try:
                dedup_result = await deduplicate_claims(
                    storage=self.storage,
                    new_claims=extraction_result.claims,
                    owner_id=self.config.owner_id,
                    threshold=0.85,
                )
                # Apply confidence boosts for near-duplicate merges
                for nc, ec in dedup_result.to_merge:
                    try:
                        new_confidence = min(1.0, ec.confidence + nc.confidence * 0.1)
                        await self.storage.update_claim(
                            ec.id,
                            confidence=new_confidence,
                        )
                        logger.debug(
                            "dedup merge: updated claim id=%s confidence %.2f → %.2f",
                            ec.id,
                            ec.confidence,
                            new_confidence,
                        )
                    except Exception as merge_exc:
                        logger.warning(
                            "dedup: failed to update merged claim id=%s: %s",
                            ec.id,
                            merge_exc,
                        )
                # Replace claims with only the genuinely new ones
                if dedup_result.total_deduped > 0:
                    logger.info(
                        "Extraction dedup: %d skipped (exact), %d merged (similar), %d new",
                        len(dedup_result.skipped),
                        len(dedup_result.to_merge),
                        len(dedup_result.to_store),
                    )
                extraction_result.claims = dedup_result.to_store
            except Exception as dedup_exc:
                logger.warning(
                    "Extraction dedup failed (non-fatal) — proceeding with all claims: %s",
                    dedup_exc,
                )

        if not extraction_result.claims:
            return RememberResult(
                session_id=sid,
                claims_extracted=claims_extracted,
                claims_stored=0,
                entities_resolved=0,
                noise_filtered=noise_filtered,
                errors=errors,
                ok=not errors,
            )

        # 2. Entity resolution ------------------------------------------------
        resolved_claims = extraction_result.claims  # may be updated after resolution
        if self.entity_resolver is None:
            logger.warning("EntityResolver not available — skipping entity resolution")
            errors.append("EntityResolver not available")
        else:
            resolved_count = 0
            for claim in extraction_result.claims:
                for mention in getattr(claim, "entities_mentioned", []):
                    try:
                        entity = await self.entity_resolver.resolve(
                            mention=mention.name,
                            owner_id=self.config.owner_id,
                        )
                        resolved_count += 1
                        # Emit ENTITY_CREATED for newly resolved entities
                        if getattr(self, "event_emitter", None) is not None and entity is not None:
                            try:
                                from cortex.events.emitter import CortexEvent, EventType
                                await self.event_emitter.emit(CortexEvent(
                                    event_type=EventType.ENTITY_CREATED,
                                    owner_id=self.config.owner_id,
                                    payload={
                                        "entity_id": getattr(entity, "id", str(entity)),
                                        "entity_name": mention.name,
                                    },
                                    session_id=sid,
                                ))
                            except Exception as emit_exc:
                                logger.debug("Event emit failed (ENTITY_CREATED): %s", emit_exc)
                    except Exception as exc:
                        err = f"Entity resolution failed for '{mention.name}': {exc}"
                        logger.warning(err)
                        errors.append(err)
            entities_resolved = resolved_count

        # 2b. Peer auto-create — after entity resolution ----------------------
        if self.storage is not None and self.entity_resolver is not None:
            try:
                from cortex.peers import PeerManager
                peer_mgr = PeerManager(
                    storage=self.storage,
                    entity_resolver=self.entity_resolver,
                )
                # Collect all person-type entities that cross the mention threshold
                if hasattr(self.storage, "list_entities"):
                    all_entities = await self.storage.list_entities(
                        owner_id=self.config.owner_id,
                        entity_type="person",
                        limit=500,
                    )
                    await peer_mgr.auto_create_from_entities(
                        owner_id=self.config.owner_id,
                        entities=all_entities,
                    )
            except Exception as exc:
                logger.warning("Peer auto-create failed (non-fatal): %s", exc)

        # 3. Reconciliation (writes to storage) -------------------------------
        reconciliation_report = None
        if self.reconciler is None:
            err = "ReconciliationEngine not available — memories NOT stored"
            logger.error(err)
            errors.append(err)
        else:
            # Each claim typically costs 1 LLM call in reconciliation.
            reconcile_calls = len(resolved_claims)
            budget_err = self._budget_check(reconcile_calls)
            if budget_err:
                logger.error("Skipping reconciliation: %s", budget_err)
                errors.append(budget_err)
            else:
                self._budget_consume(reconcile_calls)
                try:
                    reconciliation_report = await self.reconciler.reconcile(
                        candidates=resolved_claims,
                        owner_id=self.config.owner_id,
                        session_id=db_session_pk or sid,
                    )
                    claims_stored = sum(
                        1 for r in reconciliation_report.results
                        if r.action.value in ("ADD", "UPDATE", "SUPERSEDE")
                    )
                    logger.debug(
                        "Reconciled: %d stored, %d total results",
                        claims_stored,
                        len(reconciliation_report.results),
                    )
                    # Emit memory events for each reconciliation result
                    if getattr(self, "event_emitter", None) is not None:
                        try:
                            from cortex.events.emitter import CortexEvent, EventType
                            for r in reconciliation_report.results:
                                action_val = r.action.value
                                claim_id = getattr(r, "resulting_claim_id", None)
                                if action_val == "ADD" and claim_id:
                                    await self.event_emitter.emit(CortexEvent(
                                        event_type=EventType.MEMORY_CREATED,
                                        owner_id=self.config.owner_id,
                                        payload={
                                            "claim_id": claim_id,
                                            "subject": getattr(r, "subject", ""),
                                            "predicate": getattr(r, "predicate", ""),
                                        },
                                        session_id=sid,
                                    ))
                                elif action_val in ("UPDATE", "SUPERSEDE") and claim_id:
                                    await self.event_emitter.emit(CortexEvent(
                                        event_type=EventType.MEMORY_UPDATED,
                                        owner_id=self.config.owner_id,
                                        payload={
                                            "claim_id": claim_id,
                                            "action": action_val.lower(),
                                            "subject": getattr(r, "subject", ""),
                                            "predicate": getattr(r, "predicate", ""),
                                        },
                                        session_id=sid,
                                    ))
                        except Exception as emit_exc:
                            logger.debug("Event emit failed (memory events): %s", emit_exc)
                except Exception as exc:
                    err = f"Reconciliation failed: {exc}"
                    logger.error(err, exc_info=True)
                    errors.append(err)

        # 4. Embed stored claims for vector retrieval -------------------------
        # After reconciliation, compute embeddings for each newly stored claim
        # so the retrieval pipeline's vector search can find them.
        if (
            self.storage is not None
            and self.llm is not None
            and reconciliation_report is not None
        ):
            embed_model = self.config.embedding_model
            for result in reconciliation_report.results:
                if result.action.value not in ("ADD", "UPDATE", "SUPERSEDE"):
                    continue
                claim_id = getattr(result, "resulting_claim_id", None)
                if not claim_id:
                    continue
                try:
                    # Fetch the stored claim to build embedding text
                    stored_claim = await self.storage.get_claim(claim_id)
                    if stored_claim is None:
                        continue
                    embed_text = (
                        f"{stored_claim.subject} "
                        f"{stored_claim.predicate} "
                        f"{stored_claim.object_value}"
                    )
                    embed_response = await self.llm.embed(
                        texts=[embed_text],
                        input_type="document",
                    )
                    if embed_response and embed_response.embeddings:
                        vector = embed_response.embeddings[0]
                        await self.storage.store_embedding(
                            item_type="claim",
                            item_id=claim_id,
                            embedding=vector,
                            model_id=embed_model,
                        )
                        logger.debug(
                            "Embedded claim %s (%d dims)",
                            claim_id,
                            len(vector),
                        )
                except Exception as exc:
                    # Embedding failure is non-fatal — claim is still stored,
                    # just won't be findable via vector search.
                    err = f"Embedding failed for claim {claim_id}: {exc}"
                    logger.warning(err)
                    errors.append(err)

        return RememberResult(
            session_id=sid,
            claims_extracted=claims_extracted,
            claims_stored=claims_stored,
            entities_resolved=entities_resolved,
            noise_filtered=noise_filtered,
            errors=errors,
            ok=not any(
                ("not available" in e or "budget exhausted" in e)
                for e in errors
            ),
        )

    # =========================================================================
    # READ
    # =========================================================================

    async def retrieve(
        self,
        query: str,
        token_budget: Optional[int] = None,
        constraints: Any = None,
        mode: str = "auto",
        session_id: Optional[str] = None,
    ) -> Any:
        """
        Retrieve relevant memories for *query* within *token_budget*.

        Returns a RetrievalResult (from cortex.core.retrieval) or None on error.
        """
        if self.retrieval is None:
            logger.error("RetrievalPipeline not available")
            return None

        # Warn on first retrieve if embedding model changed
        if getattr(self, "_embedding_model_changed", False) and not getattr(
            self, "_embedding_model_warning_emitted", False
        ):
            logger.warning(
                "⚠️  Retrieving with changed embedding model. Results may be "
                "degraded — existing embeddings were generated with a different model."
            )
            self._embedding_model_warning_emitted = True

        # Validate query string
        query = validate_retrieve_query(query)

        budget = token_budget or self.config.retrieval_token_budget

        # Build constraints if token_budget was explicitly supplied
        if constraints is None and token_budget is not None:
            try:
                from cortex.core.retrieval import RetrievalConstraints
                constraints = RetrievalConstraints(token_budget=budget)
            except ImportError:
                pass

        try:
            result = await self.retrieval.retrieve(
                query=query,
                owner_id=self.config.owner_id,
                mode=mode,
                constraints=constraints,
            )
            return result
        except Exception as exc:
            logger.error("Retrieval failed: %s", exc, exc_info=True)
            return None

    # =========================================================================
    # DELETE
    # =========================================================================

    async def forget(
        self,
        memory_id: str,
        hard_delete: bool = False,
    ) -> ForgetResult:
        """
        Delete a memory by ID, with cornerstone protection.

        If the memory is a sealed cornerstone it will NOT be deleted —
        the caller must unseal_cornerstone() first.
        """
        # 1. Cornerstone protection check ------------------------------------
        if self.cornerstone_guardian is not None:
            try:
                is_cs = await self.cornerstone_guardian.is_cornerstone_subject(
                    subject=memory_id,
                    owner_id=self.config.owner_id,
                )
                if is_cs:
                    return ForgetResult(
                        memory_id=memory_id,
                        deleted=False,
                        reason="Memory is a sealed cornerstone — unseal first",
                    )
            except Exception as exc:
                err = f"Cornerstone check failed: {exc}"
                logger.warning(err)
                # Fail-safe: refuse deletion when protection check fails
                return ForgetResult(
                    memory_id=memory_id,
                    deleted=False,
                    reason=f"Cannot verify cornerstone status: {exc}",
                    errors=[err],
                )

        # 2. Storage delete ---------------------------------------------------
        if self.storage is None:
            return ForgetResult(
                memory_id=memory_id,
                deleted=False,
                reason="Storage not available",
                errors=["SQLiteAdapter not initialised"],
            )

        try:
            await self.storage.delete_claim(
                claim_id=memory_id,
                owner_id=self.config.owner_id,
                hard=hard_delete,
            )
            return ForgetResult(memory_id=memory_id, deleted=True, reason="ok")
        except Exception as exc:
            err = f"Delete failed: {exc}"
            logger.error(err, exc_info=True)
            return ForgetResult(
                memory_id=memory_id,
                deleted=False,
                reason=str(exc),
                errors=[err],
            )

    # =========================================================================
    # ENTITY RESOLUTION (M3) — operator / dream-cycle helpers
    # =========================================================================

    async def suggest_merges(
        self,
        similarity_threshold: float = 80.0,
        confidence_threshold: float = 0.5,
        cross_session_owner_ids: Optional[List[str]] = None,
        use_embedding_prefilter: bool = True,
        embedding_prefilter_threshold: float = 0.60,
    ) -> List[Any]:
        """Return entity pairs that look like duplicates, for human/dream-cycle review.

        Delegates to EntityResolver.suggest_merges() with embedding-based
        pre-filtering and optional cross-session co-reference detection.

        Args:
            similarity_threshold: Minimum fuzzy alias score (0-100).
            confidence_threshold: Minimum normalised confidence (0.0-1.0).
            cross_session_owner_ids: Compare entities from additional owner IDs
                against the plugin's own owner_id.  Enables cross-session
                co-reference linking.
            use_embedding_prefilter: Skip fuzzy comparison for pairs with low
                embedding cosine similarity (faster for large entity sets).
            embedding_prefilter_threshold: Cosine-similarity cutoff (0-1).

        Returns:
            List[MergeSuggestion] sorted by similarity (highest first).
            Returns [] if EntityResolver is not available.
        """
        if self.entity_resolver is None:
            logger.warning("suggest_merges: EntityResolver not available")
            return []
        try:
            return await self.entity_resolver.suggest_merges(
                owner_id=self.config.owner_id,
                similarity_threshold=similarity_threshold,
                confidence_threshold=confidence_threshold,
                cross_session_owner_ids=cross_session_owner_ids,
                use_embedding_prefilter=use_embedding_prefilter,
                embedding_prefilter_threshold=embedding_prefilter_threshold,
            )
        except Exception as exc:
            logger.error("suggest_merges failed: %s", exc, exc_info=True)
            return []

    async def merge_entities(
        self,
        keep_id: str,
        merge_id: str,
    ) -> Optional[Any]:
        """Merge two entities that refer to the same real-world thing.

        All aliases and claim FK references (subject_entity_id / object_entity_id)
        are atomically reassigned from merge_id → keep_id.  The merge_id entity
        is then deleted.  This is typically called after reviewing suggestions
        from suggest_merges().

        Args:
            keep_id: Entity to keep (the canonical one).
            merge_id: Entity to absorb and delete.

        Returns:
            The surviving Entity, or None if EntityResolver is unavailable.

        Raises:
            ValueError: If keep_id == merge_id.
        """
        if self.entity_resolver is None:
            logger.warning("merge_entities: EntityResolver not available")
            return None
        try:
            result = await self.entity_resolver.merge_entities(
                keep_id=keep_id,
                merge_id=merge_id,
            )
            # Emit ENTITY_MERGED event
            if getattr(self, "event_emitter", None) is not None and result is not None:
                try:
                    from cortex.events.emitter import CortexEvent, EventType
                    await self.event_emitter.emit(CortexEvent(
                        event_type=EventType.ENTITY_MERGED,
                        owner_id=self.config.owner_id,
                        payload={
                            "keep_id": keep_id,
                            "merge_id": merge_id,
                            "surviving_entity": getattr(result, "canonical_name", ""),
                        },
                    ))
                except Exception as emit_exc:
                    logger.debug("Event emit failed (ENTITY_MERGED): %s", emit_exc)
            return result
        except ValueError:
            raise
        except Exception as exc:
            logger.error("merge_entities failed: %s", exc, exc_info=True)
            return None

    # =========================================================================
    # CORNERSTONES
    # =========================================================================

    async def get_cornerstones(self) -> List[Any]:
        """Return all sealed cornerstones. Returns [] on error."""
        if self.cornerstone_guardian is None:
            logger.error("CornerstoneGuardian not available")
            return []
        try:
            return await self.cornerstone_guardian.get_all(
                owner_id=self.config.owner_id,
            )
        except Exception as exc:
            logger.error("get_cornerstones failed: %s", exc, exc_info=True)
            return []

    async def seal_cornerstone(
        self,
        memory_id: str,
        label: str = "",
        content: str = "",
        **kwargs: Any,
    ) -> Any:
        """
        Seal *memory_id* as a cornerstone.

        Returns a CornerstoneMemory or None on error.
        """
        if self.cornerstone_guardian is None:
            logger.error("CornerstoneGuardian not available")
            return None

        # Validate and sanitize label and content
        effective_label = label or memory_id
        effective_label, content = validate_cornerstone_fields(effective_label, content)

        try:
            result = await self.cornerstone_guardian.seal(
                label=effective_label,
                content=content,
                owner_id=self.config.owner_id,
                **kwargs,
            )
            # Emit CORNERSTONE_SEALED event
            if getattr(self, "event_emitter", None) is not None and result is not None:
                try:
                    from cortex.events.emitter import CortexEvent, EventType
                    await self.event_emitter.emit(CortexEvent(
                        event_type=EventType.CORNERSTONE_SEALED,
                        owner_id=self.config.owner_id,
                        payload={
                            "cornerstone_id": getattr(result, "id", ""),
                            "label": effective_label,
                        },
                    ))
                except Exception as emit_exc:
                    logger.debug("Event emit failed (CORNERSTONE_SEALED): %s", emit_exc)
            return result
        except Exception as exc:
            logger.error("seal_cornerstone failed: %s", exc, exc_info=True)
            return None

    async def unseal_cornerstone(self, memory_id: str) -> Any:
        """
        Unseal a cornerstone, making it eligible for modification/deletion.

        Returns an updated CornerstoneMemory or None on error.
        """
        if self.cornerstone_guardian is None:
            logger.error("CornerstoneGuardian not available")
            return None
        try:
            return await self.cornerstone_guardian.unseal(cs_id=memory_id)
        except Exception as exc:
            logger.error("unseal_cornerstone failed: %s", exc, exc_info=True)
            return None

    async def propose_cornerstone_evolution(
        self,
        cornerstone_id: str,
        new_evidence: str,
        source: str = "operator",
    ) -> EvolutionProposalResult:
        """
        Propose an LLM-generated evolution for a cornerstone.

        Uses the LLM to generate a revised golden copy that incorporates
        *new_evidence* while preserving core identity.  The proposal is stored
        and returned with its diff/reasoning — it does NOT auto-apply unless
        ``config.cornerstone_auto_apply_threshold`` is met.

        Args:
            cornerstone_id: The cornerstone to evolve.
            new_evidence:   Claims / observations that suggest the update.
            source:         Origin tag ('operator', 'dream_cycle', …).

        Returns:
            EvolutionProposalResult with all proposal details.
        """
        if self.cornerstone_guardian is None:
            err = "CornerstoneGuardian not available"
            logger.error(err)
            return EvolutionProposalResult(
                action="error",
                proposal_id="",
                proposed_content="",
                diff="",
                reasoning="",
                confidence=0.0,
                errors=[err],
                ok=False,
            )
        try:
            result = await self.cornerstone_guardian.propose_evolution(
                cornerstone_id=cornerstone_id,
                new_evidence=new_evidence,
                source=source,
            )
            return EvolutionProposalResult(
                action=result.get("action", "queued"),
                proposal_id=result.get("proposal_id", ""),
                proposed_content=result.get("proposed_content", ""),
                diff=result.get("diff", ""),
                reasoning=result.get("reasoning", ""),
                confidence=result.get("confidence", 0.0),
                requires_operator_review=result.get("requires_operator_review", True),
                cornerstone=result.get("cornerstone"),
                ok=True,
            )
        except ValueError as exc:
            err = str(exc)
            logger.warning("propose_cornerstone_evolution validation error: %s", err)
            return EvolutionProposalResult(
                action="error",
                proposal_id="",
                proposed_content="",
                diff="",
                reasoning="",
                confidence=0.0,
                errors=[err],
                ok=False,
            )
        except Exception as exc:
            err = f"propose_cornerstone_evolution failed: {exc}"
            logger.error(err, exc_info=True)
            return EvolutionProposalResult(
                action="error",
                proposal_id="",
                proposed_content="",
                diff="",
                reasoning="",
                confidence=0.0,
                errors=[err],
                ok=False,
            )

    async def apply_cornerstone_evolution(
        self,
        cornerstone_id: str,
        proposal_id: str,
        applied_by: str = "operator",
    ) -> Any:
        """
        Apply an approved evolution proposal to a cornerstone.

        Fetches the pending proposal, validates it, and calls
        CornerstoneGuardian.apply_evolution() to update the golden copy.

        Args:
            cornerstone_id: The cornerstone to update.
            proposal_id:    ID of the pending proposal to apply.
            applied_by:     Who is authorizing the change.

        Returns:
            Updated CornerstoneMemory on success, or None on error.
        """
        if self.cornerstone_guardian is None:
            logger.error("CornerstoneGuardian not available")
            return None
        try:
            return await self.cornerstone_guardian.apply_evolution(
                cornerstone_id=cornerstone_id,
                proposal_id=proposal_id,
                applied_by=applied_by,
            )
        except ValueError as exc:
            logger.warning("apply_cornerstone_evolution validation error: %s", exc)
            return None
        except Exception as exc:
            logger.error("apply_cornerstone_evolution failed: %s", exc, exc_info=True)
            return None

    # =========================================================================
    # SESSION LIFECYCLE
    # =========================================================================

    async def wake(self, session_id: Optional[str] = None) -> WakeReport:
        """
        Start a new session (wake hook).

        Loads cornerstones and sets the active session_id.
        """
        sid = session_id or _new_session_id()
        self._session_id = sid
        self._llm_call_count = 0   # reset per-session LLM budget
        errors: List[str] = []
        cornerstones_loaded = 0

        # Record session start in storage
        if self.storage is not None:
            try:
                await self.storage.create_session(
                    session_id=sid,
                    owner_id=self.config.owner_id,
                )
            except Exception as exc:
                err = f"Failed to record session start: {exc}"
                logger.warning(err)
                errors.append(err)

        # Pre-load cornerstones
        if self.cornerstone_guardian is not None:
            try:
                cs_list = await self.cornerstone_guardian.load_all(
                    owner_id=self.config.owner_id,
                )
                cornerstones_loaded = len(cs_list)
                logger.info("Woke: session=%s cornerstones=%d", sid, cornerstones_loaded)
            except Exception as exc:
                err = f"Failed to load cornerstones on wake: {exc}"
                logger.warning(err)
                errors.append(err)

        # Emit SESSION_STARTED event
        if getattr(self, "event_emitter", None) is not None:
            try:
                from cortex.events.emitter import CortexEvent, EventType
                await self.event_emitter.emit(CortexEvent(
                    event_type=EventType.SESSION_STARTED,
                    owner_id=self.config.owner_id,
                    payload={"session_id": sid, "cornerstones_loaded": cornerstones_loaded},
                    session_id=sid,
                ))
            except Exception as emit_exc:
                logger.debug("Event emit failed (SESSION_STARTED): %s", emit_exc)

        return WakeReport(
            session_id=sid,
            cornerstones_loaded=cornerstones_loaded,
            errors=errors,
        )

    async def sleep(self, session_id: Optional[str] = None) -> SleepReport:
        """
        End the current session (sleep hook).

        Closes the session record in storage.
        """
        sid = session_id or self._session_id or "unknown"
        errors: List[str] = []
        memories_summarised = 0

        if self.storage is not None:
            try:
                await self.storage.close_session(
                    session_id=sid,
                    owner_id=self.config.owner_id,
                    ended_at=_now(),
                    status="sleeping",
                )
                logger.info("Session %s closed (sleep)", sid)
            except Exception as exc:
                err = f"Failed to close session: {exc}"
                logger.warning(err)
                errors.append(err)

        # Emit SESSION_ENDED event
        if getattr(self, "event_emitter", None) is not None:
            try:
                from cortex.events.emitter import CortexEvent, EventType
                await self.event_emitter.emit(CortexEvent(
                    event_type=EventType.SESSION_ENDED,
                    owner_id=self.config.owner_id,
                    payload={"session_id": sid},
                    session_id=sid,
                ))
            except Exception as emit_exc:
                logger.debug("Event emit failed (SESSION_ENDED): %s", emit_exc)

        self._session_id = None
        return SleepReport(
            session_id=sid,
            memories_summarised=memories_summarised,
            errors=errors,
        )

    # =========================================================================
    # DREAM CYCLE (M6a/M6b full consolidation)
    # =========================================================================

    async def dream(self, owner_id: str = "default") -> Any:
        """Trigger the full nightly dream cycle (Electric Sheep consolidation).

        Wires CircadianEngine + SleepConsolidator and runs the complete dream
        pipeline: orphan recovery, Ebbinghaus decay, claim consolidation,
        contradiction resolution, cornerstone proposals, and journal generation.

        This is the canonical entry point for SDK and HTTP callers; MCP uses
        the same logic internally.

        Args:
            owner_id: Memory owner namespace.

        Returns:
            DreamReport dataclass instance.
        """
        from cortex.circadian.engine import CircadianEngine
        from cortex.circadian.sleep import SleepConsolidator

        consolidator = SleepConsolidator(
            storage=self.storage,
            llm=self.llm,
            config=self.config,
        )
        engine = CircadianEngine(
            storage=self.storage,
            consolidator=consolidator,
            config=self.config,
        )
        return await engine.dream(owner_id=owner_id)

    # =========================================================================
    # FEEDBACK
    # =========================================================================

    async def feedback(
        self,
        memory_id: str,
        helpful: bool,
        context: Optional[str] = None,
        target_type: str = "claim",
    ) -> Any:
        """
        Submit retrieval feedback for a memory.

        Args:
            memory_id:   The memory being rated.
            helpful:     True = helpful, False = harmful.
            context:     Optional free-form context string.
            target_type: 'claim' | 'cornerstone' | 'procedure' | etc.

        Returns:
            MemoryFeedback record or None on error.
        """
        if self.feedback_system is None:
            logger.error("FeedbackSystem not available")
            return None
        try:
            result = await self.feedback_system.submit_feedback(
                memory_id=memory_id,
                helpful=helpful,
                context=context,
                target_type=target_type,
            )
            # Emit FEEDBACK_SUBMITTED event
            if getattr(self, "event_emitter", None) is not None and result is not None:
                try:
                    from cortex.events.emitter import CortexEvent, EventType
                    await self.event_emitter.emit(CortexEvent(
                        event_type=EventType.FEEDBACK_SUBMITTED,
                        owner_id=self.config.owner_id,
                        payload={
                            "memory_id": memory_id,
                            "helpful": helpful,
                            "target_type": target_type,
                            "feedback_id": getattr(result, "id", ""),
                        },
                        session_id=self._session_id,
                    ))
                except Exception as emit_exc:
                    logger.debug("Event emit failed (FEEDBACK_SUBMITTED): %s", emit_exc)
            return result
        except Exception as exc:
            logger.error("feedback submission failed: %s", exc, exc_info=True)
            return None

    # =========================================================================
    # DIALECTIC (M14) — Ask your memory
    # =========================================================================

    async def ask(
        self,
        query: str,
        owner_id: Optional[str] = None,
        history: Optional[List[Dict[str, Any]]] = None,
        mode: str = "fast",
        max_steps: int = 5,
    ) -> "AskResult":
        """
        Ask a question and synthesise an answer from retrieved memories.

        Two modes are supported:
            - ``"fast"`` (default): single-shot retrieval + LLM synthesis.
            - ``"agentic"``: multi-step retrieval loop for complex questions.
              Decomposes the question, retrieves per sub-query, checks
              sufficiency, and synthesises a final grounded answer.

        If *history* is provided (fast mode only), passes it to
        ask_with_history() for follow-up question support.

        Args:
            query:     Natural-language question.
            owner_id:  Memory namespace (defaults to plugin config owner_id).
            history:   Optional prior conversation turns — list of {role, content}.
                       Ignored when mode="agentic".
            mode:      ``"fast"`` (default) or ``"agentic"``.
            max_steps: Maximum retrieval steps for agentic mode (default 5).

        Returns:
            AskResult with synthesised answer, source memories, and confidence.
        """
        effective_owner_id = owner_id or self.config.owner_id
        errors: List[str] = []

        if self.retrieval is None or self.llm is None:
            err = "Dialectic requires retrieval pipeline and LLM — one or both unavailable"
            logger.error(err)
            return AskResult(
                answer="I cannot answer: the memory system is not fully initialised.",
                errors=[err],
                ok=False,
            )

        try:
            from cortex.dialectic.engine import DialecticEngine

            engine = DialecticEngine(
                retrieval_engine=self.retrieval,
                llm_provider=self.llm,
                config=self.config,
            )

            if mode == "agentic":
                response = await engine.ask_agentic(
                    query=query,
                    owner_id=effective_owner_id,
                    max_steps=max_steps,
                )
            elif history:
                response = await engine.ask_with_history(
                    query=query,
                    owner_id=effective_owner_id,
                    history=history,
                )
            else:
                response = await engine.ask(
                    query=query,
                    owner_id=effective_owner_id,
                )

            return AskResult(
                answer=response.answer,
                sources=response.sources,
                confidence=response.confidence,
                reasoning=response.reasoning,
                errors=errors,
                ok=True,
            )

        except Exception as exc:
            err = f"Dialectic ask failed: {exc}"
            logger.error(err, exc_info=True)
            return AskResult(
                answer="An error occurred while answering your question.",
                errors=[err],
                ok=False,
            )

    # =========================================================================
    # HEALTH
    # =========================================================================

    async def health(self) -> HealthReport:
        """
        Return a system status report.

        Checks every module for liveness. Returns HealthReport with per-module
        status strings and a top-level ok flag.
        """
        errors: List[str] = list(self._init_errors)
        modules: Dict[str, str] = {}

        # Storage
        if self.storage is None:
            modules["storage"] = "unavailable"
        else:
            try:
                await self.storage.ping()
                modules["storage"] = "ok"
            except Exception as exc:
                modules["storage"] = f"error: {exc}"
                errors.append(f"storage health: {exc}")

        # All other modules — just check presence
        module_attrs = {
            "extractor": "extraction",
            "entity_resolver": "entity_resolution",
            "reconciler": "reconciliation",
            "cornerstone_guardian": "cornerstone",
            "token_budget_manager": "token_budget",
            "retrieval": "retrieval",
            "feedback_system": "feedback",
            "llm": "llm",
        }
        for attr, label in module_attrs.items():
            obj = getattr(self, attr, None)
            modules[label] = "ok" if obj is not None else "unavailable"

        # Check sqlite-vec availability (informational — does not affect ok status)
        if self.storage is not None:
            vec_loaded = getattr(self.storage, "_vec_loaded", False)
            modules["sqlite_vec_available"] = "ok" if vec_loaded else "unavailable"

        ok = all(
            v == "ok" for k, v in modules.items()
            if k != "sqlite_vec_available"  # optional extension doesn't affect health
        ) and not errors

        return HealthReport(
            ok=ok,
            storage=modules.get("storage", "unknown"),
            modules=modules,
            errors=errors,
        )
