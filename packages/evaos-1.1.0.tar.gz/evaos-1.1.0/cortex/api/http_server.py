"""
cortex/api/http_server.py — FastAPI HTTP Server for Cortex (Module 13 / M13).

Provides a REST API that mirrors the MCP tools, enabling web dashboard
integration (Nexus UI) and external programmatic access to Cortex memory.

Architecture:
    HTTP Server (FastAPI/uvicorn)
      → CortexPlugin (M13)
        → all other modules

Auth:
    Pass ``X-API-Key: <key>`` header when CORTEX_API_KEY env var is set.
    If CORTEX_API_KEY is not set, auth is disabled (open access — for local dev).

Usage::

    # Start with defaults (localhost:8000)
    cortex-http

    # Custom host/port with API key
    CORTEX_API_KEY=secret cortex-http --host 0.0.0.0 --port 8080

    # Programmatic usage
    import uvicorn
    from cortex.api.http_server import create_app
    app = create_app()
    uvicorn.run(app, host="127.0.0.1", port=8000)

Dependencies: FastAPI, uvicorn, cortex.api.plugin.CortexPlugin.
"""

import logging
import os
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional import guard — fastapi/uvicorn may not be installed
# ---------------------------------------------------------------------------
try:
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    import uvicorn
    _FASTAPI_AVAILABLE = True
except ImportError as _e:  # pragma: no cover
    _FASTAPI_AVAILABLE = False
    _IMPORT_ERROR = str(_e)

# Re-export _serialise at module level for backward compatibility
from cortex.api.deps import _serialise  # noqa: F401, E402
from cortex.api.deps import plugin_holder, make_auth_dependency, get_plugin  # noqa: E402

# Re-export models at module level for backward compatibility with tests
# that do: from cortex.api.http_server import SomeModel
try:
    from cortex.api.models import *  # noqa: F401, F403
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------

def create_app(
    config_path: Optional[str] = None,
    db_path: Optional[str] = None,
    api_key: Optional[str] = None,
    cors_origins: Optional[List[str]] = None,
) -> "FastAPI":
    """
    Create and configure the FastAPI application.

    Args:
        config_path:  Path to cortex.toml (default: auto-detect).
        db_path:      Override SQLite database path.
        api_key:      Required API key for X-API-Key header auth.
                      If None, falls back to ``CORTEX_API_KEY`` env var.
                      If that is also empty, auth is disabled.
        cors_origins: List of allowed CORS origins. Default: ["*"].

    Returns:
        Configured FastAPI application instance.
    """
    if not _FASTAPI_AVAILABLE:  # pragma: no cover
        raise ImportError(
            f"FastAPI is required for the HTTP server: {_IMPORT_ERROR}\n"
            "Install with: pip install 'cortex[api]'"
        )

    _api_key = api_key or os.getenv("CORTEX_API_KEY") or None
    # Configure allowed origins explicitly for security; empty list blocks all cross-origin requests by default.
    _cors_origins = cors_origins or []

    # Warn loudly when no API key is configured (#218)
    if _api_key is None:
        logger.warning(
            "=" * 60 + "\n"
            "⚠️  NO API KEY CONFIGURED\n"
            "The server is accessible WITHOUT authentication.\n"
            "Set CORTEX_API_KEY or pass --api-key to enable auth.\n"
            + "=" * 60
        )

    # ---- Lifespan ----------------------------------------------------------

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        """Initialise CortexPlugin on startup; clean up on shutdown."""
        from cortex.api.plugin import CortexPlugin
        from cortex.config import validate_config as _validate_config
        plugin = CortexPlugin(config_path=config_path, db_path=db_path)
        # Config startup validation (#73)
        config_issues = _validate_config(plugin.config)
        for issue in config_issues:
            logger.warning("CortexConfig validation: %s", issue)
        if plugin.storage is not None:
            await plugin.storage.initialize()
        plugin_holder["plugin"] = plugin
        logger.info("CortexPlugin initialised — HTTP server ready")
        yield
        # Teardown: close storage if available
        if getattr(plugin, "storage", None) is not None:
            try:
                await plugin.storage.close()
            except Exception as exc:
                logger.warning("Error closing storage on shutdown: %s", exc)
        logger.info("CortexPlugin shut down")

    # ---- App ---------------------------------------------------------------

    app = FastAPI(
        title="Cortex HTTP API",
        description=(
            "REST interface for Cortex — identity-preserving cognitive "
            "infrastructure for AI agents."
        ),
        version="3.0.0",
        lifespan=lifespan,
    )

    # ---- CORS --------------------------------------------------------------

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ---- Rate-limiting middleware (#71) ------------------------------------

    from cortex.api.rate_limiter import RateLimiterMiddleware as _RLM

    _rl_rpm = int(os.getenv("CORTEX_RATE_LIMIT_RPM", "60"))
    _rl_burst = int(os.getenv("CORTEX_RATE_LIMIT_BURST", "10"))
    _rl_enabled = _rl_rpm > 0

    app.add_middleware(
        _RLM,
        requests_per_minute=_rl_rpm,
        burst=_rl_burst,
        enabled=_rl_enabled,
    )

    # ---- Request-logging middleware (#182) ---------------------------------

    from cortex.api.middleware import RequestLogMiddleware as _RLMBase

    class _LazyRequestLogMiddleware(_RLMBase):
        """Resolves storage lazily from the shared plugin holder."""

        def __init__(self, app: Any, *, _plugin_holder: dict, owner_id: str = "default") -> None:
            from starlette.middleware.base import BaseHTTPMiddleware
            BaseHTTPMiddleware.__init__(self, app)
            self._plugin_holder = _plugin_holder
            self._owner_id = owner_id
            self._storage = None

        async def dispatch(self, request: Any, call_next: Any) -> Any:
            plugin = self._plugin_holder.get("plugin")
            if plugin is not None:
                self._storage = getattr(plugin, "storage", None)
            return await super().dispatch(request, call_next)

    app.add_middleware(
        _LazyRequestLogMiddleware,
        _plugin_holder=plugin_holder,
        owner_id="default",
    )

    # ---- Auth dependency ---------------------------------------------------

    verify_api_key = make_auth_dependency(_api_key)

    # ---- Routes ------------------------------------------------------------

    from cortex.api.routes import register_routes
    register_routes(app, verify_api_key)

    return app


# ---------------------------------------------------------------------------
# CLI entry point  (`cortex-http`)
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Entry point for the ``cortex-http`` CLI command.

    Environment variables:
        CORTEX_API_KEY   — required API key (leave unset for open access)
        CORTEX_DB_PATH   — override SQLite database path
        CORTEX_CONFIG    — path to cortex.toml

    Example::

        CORTEX_API_KEY=secret cortex-http --host 0.0.0.0 --port 8080
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="cortex-http",
        description="Start the Cortex FastAPI HTTP server",
    )
    parser.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (dev mode)")
    parser.add_argument("--workers", type=int, default=1, help="Number of uvicorn workers")
    parser.add_argument(
        "--log-level",
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Log level",
    )
    parser.add_argument("--db-path", default=None, help="Override SQLite DB path")
    parser.add_argument("--config", default=None, help="Path to cortex.toml")
    parser.add_argument(
        "--cors-origins",
        default="*",
        help="Comma-separated CORS origins (default: *)",
    )
    args = parser.parse_args()

    if not _FASTAPI_AVAILABLE:  # pragma: no cover
        raise SystemExit(
            "FastAPI is required: pip install 'cortex[api]'"
        )

    cors_origins = [o.strip() for o in args.cors_origins.split(",") if o.strip()]

    app = create_app(
        config_path=args.config,
        db_path=args.db_path,
        cors_origins=cors_origins,
    )

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=args.workers if not args.reload else 1,
        log_level=args.log_level,
    )


if __name__ == "__main__":
    main()
