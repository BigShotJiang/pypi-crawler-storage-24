"""cortex/api/routes/config.py — Extraction instructions endpoints."""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status

from cortex.api.deps import PREFIX, get_plugin
from cortex.api.models import ExtractionTestRequest, UpdateExtractionInstructionsRequest

logger = logging.getLogger(__name__)

router = APIRouter()


def _make_routes(verify_api_key):
    """Register config routes with the given auth dependency."""

    @router.get(
        f"{PREFIX}/extraction/instructions",
        summary="Get custom extraction instructions",
        tags=["extraction"],
    )
    async def get_extraction_instructions(
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> dict:
        """Return the current custom extraction instructions from config."""
        instructions = getattr(plugin.config, "extraction_custom_instructions", "")
        return {"instructions": instructions}

    @router.put(
        f"{PREFIX}/extraction/instructions",
        summary="Update custom extraction instructions",
        tags=["extraction"],
    )
    async def put_extraction_instructions(
        body: UpdateExtractionInstructionsRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> dict:
        """Update the custom extraction instructions at runtime."""
        from cortex.extraction.extractor import ExtractionPipeline
        from cortex.extraction.prompts import EXTRACTION_SYSTEM_PROMPT

        instructions = body.instructions.strip()
        plugin.config.extraction_custom_instructions = instructions

        extractor = getattr(plugin, "extractor", None)
        if extractor is not None and isinstance(extractor, ExtractionPipeline):
            extractor.custom_instructions = instructions
            if instructions:
                extractor._system_prompt = (
                    EXTRACTION_SYSTEM_PROMPT
                    + "\n\n## Operator Instructions\n"
                    + instructions
                )
            else:
                extractor._system_prompt = EXTRACTION_SYSTEM_PROMPT

        return {"instructions": instructions, "updated": True}

    @router.post(
        f"{PREFIX}/extraction/test",
        summary="Dry-run extraction with custom instructions",
        tags=["extraction"],
    )
    async def post_extraction_test(
        body: ExtractionTestRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> dict:
        """Dry-run extraction: test custom instructions against sample text."""
        from cortex.extraction.extractor import ExtractionPipeline

        instructions = body.instructions.strip()
        sample_text = body.sample_text.strip()

        if not sample_text:
            raise HTTPException(status_code=400, detail="sample_text must not be empty")

        try:
            test_pipeline = ExtractionPipeline(
                llm=plugin.llm,
                model=plugin.config.extraction_model,
                custom_instructions=instructions,
            )
        except Exception as exc:
            raise HTTPException(status_code=503, detail="Extraction pipeline unavailable")

        messages = [{"role": "user", "content": sample_text}]
        try:
            result = await test_pipeline.extract(messages, session_id="dry-run-test")
        except Exception as exc:
            raise HTTPException(status_code=500, detail="Internal server error")

        claims_out = []
        for claim in result.claims:
            claims_out.append({
                "action": claim.action,
                "subject": claim.subject,
                "predicate": claim.predicate,
                "object_value": claim.object_value,
                "confidence": claim.confidence,
                "temporal": claim.temporal,
                "temporal_marker": claim.temporal_marker,
                "sensitivity": claim.sensitivity,
                "category": claim.category,
            })

        return {
            "claims": claims_out,
            "claims_count": len(claims_out),
            "noise_filtered": result.noise_filtered,
        }
