"""
cortex/api/deps.py — Shared dependencies for the Cortex HTTP API.

Provides:
    - verify_api_key: FastAPI dependency for X-API-Key authentication
    - get_plugin: FastAPI dependency for accessing the shared CortexPlugin
    - _serialise: Recursive JSON serialisation helper
    - PREFIX: API version prefix constant
    - plugin_holder: Shared mutable dict for the plugin instance
"""

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

try:
    from fastapi import Depends, Header, HTTPException, status
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False

# API version prefix
PREFIX = "/api/v1"

# Shared plugin instance holder (populated at startup by create_app lifespan)
plugin_holder: Dict[str, Any] = {}


def get_plugin_holder() -> Dict[str, Any]:
    """Return the shared plugin holder dict."""
    return plugin_holder


def _serialise(obj: Any) -> Any:
    """Recursively convert objects to JSON-serialisable types."""
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, dict):
        return {k: _serialise(v) for k, v in obj.items() if not k.startswith("_")}
    if isinstance(obj, (list, tuple)):
        return [_serialise(item) for item in obj]
    if hasattr(obj, "__dict__"):
        return _serialise({k: v for k, v in obj.__dict__.items() if not k.startswith("_")})
    return str(obj)


def make_auth_dependency(api_key: Optional[str]):
    """Create the verify_api_key dependency with a captured API key."""

    async def verify_api_key(x_api_key: Optional[str] = Header(None)):
        """Validate X-API-Key header when auth is configured."""
        if api_key is None:
            return
        if x_api_key != api_key:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or missing X-API-Key",
            )

    return verify_api_key


def get_plugin() -> Any:
    """Retrieve the shared CortexPlugin instance."""
    plugin = plugin_holder.get("plugin")
    if plugin is None:  # pragma: no cover
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Cortex plugin not initialised",
        )
    return plugin
