"""
cortex/extraction/extractor.py — ExtractionPipeline (Module 2 / M2).

The first stage of the remember() pipeline. Converts raw conversation turns
into structured CandidateClaim objects (subject-predicate-object triples)
that downstream modules can reconcile and persist.

Pipeline stages:
    1. CodingNoiseFilter (regex pre-filter — zero LLM cost)
    2. Batch splitting — divide filtered messages into chunks of batch_size
    3. For each batch: format_conversation() + LLM completion (structured JSON)
    4. JSON parse + validation → list of ClaimExtraction dataclasses (per batch)
    5. Aggregate all batch results into ExtractionResult

Does NOT write to storage — output feeds into ReconciliationEngine.reconcile() (M4).

Dependencies:
    - cortex.extraction.coding_noise.CodingNoiseFilter (noise pre-filter)
    - cortex.extraction.prompts (system prompt + conversation formatter)
    - LLMProvider (any implementation — Anthropic, OpenAI, Ollama)

Data flow:
    CortexPlugin.remember()
      → ExtractionPipeline.extract(messages)
          → CodingNoiseFilter.filter_conversation()   (cheap regex)
          → _split_batches()                           (chunking)
          → for each batch:
              → format_conversation()                  (text formatting)
              → LLMProvider.complete()                 (LLM call)
              → _parse_claims()                        (JSON → ClaimExtraction list)
      → ExtractionResult
          → passed to ReconciliationEngine.reconcile() (M4)
"""

from __future__ import annotations

import json
import logging
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from cortex.extraction.coding_noise import CodingNoiseFilter
from cortex.extraction.prompts import EXTRACTION_SYSTEM_PROMPT, format_conversation

# Valid category values. "misc" is the internal fallback for missing/unknown.
_VALID_CATEGORIES = frozenset({"identity", "personal", "preferences", "engineering", "goals", "misc"})

# Alias map: normalise common LLM variants to our canonical category names.
# Keys are lowercase; values must be in _VALID_CATEGORIES.
_CATEGORY_ALIASES: dict[str, str] = {
    # engineering
    "technical": "engineering",
    "tech": "engineering",
    "code": "engineering",
    # personal
    "bio": "personal",
    "biographical": "personal",
    "family": "personal",
    # preferences
    "preference": "preferences",
    "pref": "preferences",
    "setting": "preferences",
    # goals
    "goal": "goals",
    "plan": "goals",
    "strategy": "goals",
    # identity
    "self": "identity",
    "personality": "identity",
    "core": "identity",
}

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output types
# ---------------------------------------------------------------------------

@dataclass
class EntityMention:
    """An entity reference extracted from conversation text.

    These are passed to EntityResolver (M3) for canonicalization — the
    same real-world entity might be mentioned as "Andrew", "Andy", "@andrew".

    Attributes:
        name: Primary name as it appeared in the conversation.
        entity_type: Classification — 'person', 'technology', 'project', etc.
        aliases: Other names/spellings observed in the same context.
    """
    name: str
    entity_type: str
    aliases: List[str] = field(default_factory=list)


@dataclass
class ClaimExtraction:
    """A single extracted memory claim from the conversation.

    This is the intermediate format between LLM extraction and storage.
    The ReconciliationEngine (M4) decides whether each claim should be
    added, merged with an existing claim, or discarded.

    Attributes:
        action: LLM-suggested action — 'ADD' (new fact), 'UPDATE' (revises
                existing), 'DELETE' (negates prior claim), 'NOOP' (no info).
        subject: The entity or concept this claim is about.
        predicate: The relationship or property (verb/adjective).
        object_value: The value or target of the relationship.
        confidence: LLM-assigned confidence (0.0-1.0). Lower for inferred items.
        temporal: Temporal scope — 'current', 'past', 'future', 'permanent'.
        temporal_marker: Explicit time reference extracted verbatim from the
                         source text, or None if no specific time phrase was
                         mentioned.  Examples: "yesterday", "last week",
                         "March 2026", "two years ago", "recently".
        entities_mentioned: All entities referenced in this claim (for M3).
        sensitivity: Privacy classification — 'normal', 'personal', 'sensitive'.

    Note:
        Output feeds into ReconciliationEngine.reconcile() as candidates.
    """
    action: str                           # ADD | UPDATE | DELETE | NOOP
    subject: str
    predicate: str
    object_value: str
    confidence: float
    temporal: str = "current"             # current | past | future | permanent
    temporal_marker: Optional[str] = None # e.g. "yesterday", "March 2026", None
    entities_mentioned: List[EntityMention] = field(default_factory=list)
    sensitivity: str = "normal"           # normal | personal | sensitive
    category: str = "misc"               # identity | personal | preferences | engineering | goals | misc


@dataclass
class ExtractionResult:
    """Full result from the extraction pipeline for one conversation batch.

    Attributes:
        claims: List of extracted ClaimExtraction objects (NOOP claims already filtered).
        noise_filtered: How many input messages were dropped by CodingNoiseFilter.
        raw_message_count: Total input messages before any filtering.
        batches_processed: Number of LLM batch calls made during extraction.
                           A value > 1 means the input was split into multiple
                           batches of batch_size messages each.

    Note:
        Passed to CortexPlugin.remember() which forwards claims to
        ReconciliationEngine.reconcile() (M4).
    """
    claims: List[ClaimExtraction]
    noise_filtered: int      # number of messages dropped by noise filter
    raw_message_count: int
    batches_processed: int = 1  # number of LLM calls made (≥1)


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

class ExtractionPipeline:
    """
    Extracts structured claims from a conversation using LLM + noise filter.

    Supports batch extraction: when more messages than ``batch_size`` are
    provided, the pipeline splits them into chunks and issues one LLM call per
    chunk.  Claims from all batches are aggregated into a single
    ExtractionResult.  This prevents enormous context windows on long
    conversations while keeping per-call latency bounded.

    Usage::

        pipeline = ExtractionPipeline(llm=my_llm_provider, model="gpt-4.1-nano",
                                      batch_size=5)
        result = await pipeline.extract(messages, session_id="abc")
        for claim in result.claims:
            print(claim.action, claim.subject, claim.predicate,
                  claim.object_value, claim.temporal_marker)
    """

    DEFAULT_BATCH_SIZE = 5

    def __init__(
        self,
        llm: Any,
        model: Optional[str] = None,
        noise_filter: Optional[CodingNoiseFilter] = None,
        batch_size: int = DEFAULT_BATCH_SIZE,
        custom_instructions: str = "",
    ) -> None:
        """Initialise the extraction pipeline.

        Args:
            llm: LLMProvider instance used for LLM completions.
            model: Optional model override forwarded to llm.complete().
            noise_filter: CodingNoiseFilter instance; a default is created when
                          None is passed.
            batch_size: Maximum number of messages per LLM call.  Must be ≥ 1.
                        Defaults to 5.  Set to a large number (e.g. 9999) to
                        disable batching and process all messages in one call.
            custom_instructions: Optional deployment-specific rules appended
                                 after EXTRACTION_SYSTEM_PROMPT.  When non-empty,
                                 the string is separated from the base prompt by a
                                 blank line and a section header for readability.
                                 Sourced from CortexConfig.extraction_custom_instructions.
        """
        if batch_size < 1:
            raise ValueError(f"batch_size must be >= 1, got {batch_size}")
        self.llm = llm
        self.model = model
        self.noise_filter = noise_filter or CodingNoiseFilter()
        self.batch_size = batch_size
        raw_instructions = custom_instructions.strip()

        # Sanitize custom_instructions to prevent prompt injection
        if raw_instructions:
            original_len = len(raw_instructions)
            # Cap length to prevent prompt flooding
            if len(raw_instructions) > 2000:
                raw_instructions = raw_instructions[:2000]
                logger.warning(
                    "ExtractionPipeline: custom_instructions truncated from %d to 2000 chars",
                    original_len,
                )

            # Strip common injection patterns (lines starting with control tokens)
            # Note: "Ignore" is only matched when followed by injection keywords to
            # avoid over-blocking legitimate instructions like "Ignore work topics."
            import re as _re
            _INJECTION_RE = _re.compile(
                r'^(##|System:|You are|Ignore\s+(previous|prior|all|above|the above|everything|instructions))',
                _re.IGNORECASE,
            )
            sanitized_lines = []
            removed_lines = []
            for line in raw_instructions.splitlines():
                stripped = line.lstrip()
                if _INJECTION_RE.match(stripped):
                    removed_lines.append(line)
                else:
                    sanitized_lines.append(line)
            if removed_lines:
                logger.warning(
                    "ExtractionPipeline: custom_instructions stripped %d potentially injected line(s): %r",
                    len(removed_lines),
                    removed_lines[:3],  # log up to 3 examples
                )
                raw_instructions = "\n".join(sanitized_lines)

        self.custom_instructions = raw_instructions

        # Build the effective system prompt once (avoids repeated string ops per batch).
        if self.custom_instructions:
            self._system_prompt = (
                EXTRACTION_SYSTEM_PROMPT
                + "\n\n## Operator Instructions\n"
                + self.custom_instructions
            )
        else:
            self._system_prompt = EXTRACTION_SYSTEM_PROMPT

    async def extract(
        self,
        messages: List[Dict[str, Any]],
        session_id: str = "",
    ) -> ExtractionResult:
        """Run the full extraction pipeline on a batch of conversation messages.

        Pipeline stages:
            1. CodingNoiseFilter — remove build output, diffs, stack traces (free)
            2. Batch splitting — divide filtered messages into chunks of batch_size
            3. For each chunk: format_conversation → LLM completion → JSON parse
            4. Aggregate claims from all chunks into a single ExtractionResult

        Args:
            messages: List of message dicts with 'role' and 'content' keys.
                      Accepts any dict shape; missing keys handled gracefully.
            session_id: Session identifier for logging context.

        Returns:
            ExtractionResult containing extracted claims, filter metrics, and
            the number of batches processed.

        Raises:
            Exception: Re-raised from LLM provider if any completion call fails.
                       The caller (CortexPlugin.remember) catches and logs this.

        Note:
            Output feeds into ReconciliationEngine.reconcile() (M4) via
            CortexPlugin.remember().
        """
        raw_count = len(messages)

        # Step 1: filter noise
        filtered = self.noise_filter.filter_conversation(messages)
        noise_filtered = raw_count - len(filtered)

        if not filtered:
            logger.debug("session=%s all messages filtered as noise", session_id)
            return ExtractionResult(
                claims=[],
                noise_filtered=noise_filtered,
                raw_message_count=raw_count,
                batches_processed=0,
            )

        # Step 2: split into batches
        batches = _split_batches(filtered, self.batch_size)
        all_claims: List[ClaimExtraction] = []

        # Step 3: process each batch
        for batch_idx, batch in enumerate(batches):
            conversation_text = format_conversation(batch)
            if not conversation_text.strip():
                logger.debug(
                    "session=%s batch=%d/%d empty after formatting — skipping",
                    session_id, batch_idx + 1, len(batches),
                )
                continue

            kwargs: Dict[str, Any] = {"response_format": "json"}
            if self.model:
                kwargs["model"] = self.model

            try:
                _resp = await self.llm.complete(
                    system=self._system_prompt,
                    user=conversation_text,
                    **kwargs,
                )
                raw_json = _resp.text if hasattr(_resp, "text") else str(_resp)
            except Exception as exc:
                logger.error(
                    "session=%s batch=%d/%d LLM extraction failed: %s",
                    session_id, batch_idx + 1, len(batches), exc,
                )
                raise

            logger.debug(
                "session=%s batch=%d/%d raw_llm_response=%r",
                session_id, batch_idx + 1, len(batches), raw_json,
            )
            batch_claims = self._parse_claims(raw_json, session_id)
            all_claims.extend(batch_claims)

            logger.debug(
                "session=%s batch=%d/%d extracted=%d",
                session_id, batch_idx + 1, len(batches), len(batch_claims),
            )

        logger.debug(
            "session=%s total_extracted=%d noise_filtered=%d batches=%d",
            session_id, len(all_claims), noise_filtered, len(batches),
        )
        return ExtractionResult(
            claims=all_claims,
            noise_filtered=noise_filtered,
            raw_message_count=raw_count,
            batches_processed=len(batches),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _parse_claims(self, raw_json: str, session_id: str) -> List[ClaimExtraction]:
        """Parse LLM JSON output into ClaimExtraction list.

        Tolerant of common LLM output variations:
        - Bare JSON array: [...]
        - Wrapped in dict: {"claims": [...]}
        - Extra fields in claim objects (ignored)
        - Missing optional fields (defaults applied)
        - NOOP claims (silently skipped)

        Args:
            raw_json: Raw JSON string from LLM completion.
            session_id: Session identifier for log context.

        Returns:
            List of valid ClaimExtraction objects (NOOP filtered out).
        """
        try:
            data = json.loads(raw_json)
        except json.JSONDecodeError as exc:
            logger.warning("session=%s JSON parse error: %s | raw=%r",
                           session_id, exc, raw_json[:200])
            return []

        if isinstance(data, dict):
            # Accept {"claims": [...]} wrapper — common LLM output shape
            if "claims" in data and isinstance(data["claims"], list):
                data = data["claims"]
            elif "subject" in data and "predicate" in data:
                # Single claim dict (not wrapped in a list) — wrap it
                data = [data]
            else:
                logger.warning("session=%s unexpected JSON dict shape (no 'claims' key): %r",
                               session_id, list(data.keys())[:5])
                return []

        if not isinstance(data, list):
            logger.warning("session=%s unexpected JSON shape (not a list): %r",
                           session_id, type(data))
            return []

        claims: List[ClaimExtraction] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            try:
                claim = self._dict_to_claim(item)
                if claim.action == "NOOP":
                    continue  # skip NOOP — nothing to persist
                claims.append(claim)
            except (KeyError, TypeError, ValueError) as exc:
                logger.debug("session=%s skipping malformed claim %r: %s",
                             session_id, item, exc)
                continue

        return claims

    @staticmethod
    def _dict_to_claim(d: Dict[str, Any]) -> ClaimExtraction:
        action = str(d.get("action", "ADD")).upper()
        if action not in ("ADD", "UPDATE", "DELETE", "NOOP"):
            action = "ADD"

        entities: List[EntityMention] = []
        for ent in d.get("entities_mentioned", []):
            if isinstance(ent, dict):
                entities.append(EntityMention(
                    name=str(ent.get("name", "")),
                    entity_type=str(ent.get("type", "unknown")),
                    aliases=list(ent.get("aliases", [])),
                ))

        # temporal_marker: accept null / missing → None; non-empty string kept as-is
        raw_marker = d.get("temporal_marker", None)
        temporal_marker: Optional[str] = (
            str(raw_marker).strip() if raw_marker is not None and str(raw_marker).strip()
            else None
        )

        # category: validate against known set, resolving aliases first.
        raw_category = str(d.get("category", "misc")).strip().lower()
        # Resolve alias before validity check (e.g. "technical" → "engineering")
        resolved_category = _CATEGORY_ALIASES.get(raw_category, raw_category)
        category = resolved_category if resolved_category in _VALID_CATEGORIES else "misc"

        return ClaimExtraction(
            action=action,
            subject=str(d["subject"]),
            predicate=str(d["predicate"]),
            object_value=str(d["object_value"]),
            confidence=float(d.get("confidence", 0.5)),
            temporal=str(d.get("temporal", "current")),
            temporal_marker=temporal_marker,
            entities_mentioned=entities,
            sensitivity=str(d.get("sensitivity", "normal")),
            category=category,
        )


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def _split_batches(
    messages: List[Dict[str, Any]],
    batch_size: int,
) -> List[List[Dict[str, Any]]]:
    """Split *messages* into consecutive chunks of at most *batch_size* items.

    Args:
        messages: Flat list of message dicts (already noise-filtered).
        batch_size: Maximum messages per chunk.  Must be ≥ 1.

    Returns:
        List of chunks.  Each chunk is a non-empty sublist of *messages*.
        Returns a list with a single empty list only when *messages* is empty.

    Example:
        >>> _split_batches([m1, m2, m3, m4, m5], batch_size=2)
        [[m1, m2], [m3, m4], [m5]]
    """
    if not messages:
        return [[]]
    n = math.ceil(len(messages) / batch_size)
    return [messages[i * batch_size:(i + 1) * batch_size] for i in range(n)]
