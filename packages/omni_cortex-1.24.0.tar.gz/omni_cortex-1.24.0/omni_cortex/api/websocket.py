"""WebSocket event streaming for real-time updates."""

import asyncio
import json
import logging
from typing import Any

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from .config import ApiConfig

logger = logging.getLogger(__name__)

router = APIRouter()


class EventBus:
    """Simple pub/sub event bus for WebSocket streaming."""

    def __init__(self) -> None:
        self._subscribers: list[asyncio.Queue] = []
        self._lock = asyncio.Lock()

    async def subscribe(self) -> asyncio.Queue:
        """Create a new subscription queue."""
        queue: asyncio.Queue = asyncio.Queue(maxsize=100)
        async with self._lock:
            self._subscribers.append(queue)
        return queue

    async def unsubscribe(self, queue: asyncio.Queue) -> None:
        """Remove a subscription queue."""
        async with self._lock:
            if queue in self._subscribers:
                self._subscribers.remove(queue)

    async def publish(self, event_type: str, data: Any) -> None:
        """Publish an event to all subscribers."""
        event = {"type": event_type, "data": data}
        async with self._lock:
            stale = []
            for queue in self._subscribers:
                try:
                    queue.put_nowait(event)
                except asyncio.QueueFull:
                    stale.append(queue)
            for q in stale:
                self._subscribers.remove(q)

    def publish_sync(self, event_type: str, data: Any) -> None:
        """Publish from synchronous code by scheduling on the event loop."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(self.publish(event_type, data))
            else:
                loop.run_until_complete(self.publish(event_type, data))
        except RuntimeError:
            pass  # No event loop — skip


# Singleton event bus
event_bus = EventBus()

# Module-level config reference
_ws_config: ApiConfig | None = None


def set_ws_config(config: ApiConfig) -> None:
    """Set config for WebSocket auth."""
    global _ws_config
    _ws_config = config


@router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    token: str = Query(...),
) -> None:
    """WebSocket endpoint for real-time event streaming.

    Connect with: ws://host:port/api/v1/ws?token=<api-key>

    Optionally send a JSON message to filter events:
        {"filter": ["memory.created", "memory.updated"]}
    """
    if _ws_config is None or token != _ws_config.api_key:
        await websocket.close(code=4001, reason="Invalid token")
        return

    await websocket.accept()
    queue = await event_bus.subscribe()
    event_filter: set[str] | None = None

    try:
        # Start listening for filter messages in background
        async def listen_for_filters() -> None:
            nonlocal event_filter
            try:
                while True:
                    msg = await websocket.receive_text()
                    try:
                        parsed = json.loads(msg)
                        if "filter" in parsed and isinstance(parsed["filter"], list):
                            event_filter = set(parsed["filter"])
                    except json.JSONDecodeError:
                        pass
            except WebSocketDisconnect:
                pass

        filter_task = asyncio.create_task(listen_for_filters())

        # Push events to client
        while True:
            event = await queue.get()
            if event_filter is None or event["type"] in event_filter:
                await websocket.send_json(event)

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.warning(f"WebSocket error: {e}")
    finally:
        filter_task.cancel()
        await event_bus.unsubscribe(queue)
