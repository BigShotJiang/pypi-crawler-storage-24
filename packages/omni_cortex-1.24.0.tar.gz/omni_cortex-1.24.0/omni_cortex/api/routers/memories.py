"""Memories router — CRUD operations on memories."""

import json

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from ...config import load_config
from ...database.connection import init_database
from ...database.sync import sync_memory_to_global
from ...models.memory import (
    MemoryCreate,
    MemoryUpdate,
    create_memory,
    create_version,
    delete_memory,
    get_memory,
    get_memory_versions,
    get_version_count,
    list_memories,
    update_memory,
)
from ...models.relationship import (
    VALID_RELATIONSHIP_TYPES,
    create_relationship,
)
from ..auth import verify_api_key
from ..schemas import (
    ApiResponse,
    LinkMemoriesRequest,
    MemoryCreateRequest,
    MemoryUpdateRequest,
    PaginationMeta,
    ReviewMemoriesRequest,
)
from ..websocket import event_bus

router = APIRouter(prefix="/memories", tags=["memories"])


def _get_conn(request: Request):
    """Get database connection from request state."""
    db_path = getattr(request.state, "db_path", None)
    return init_database(db_path=db_path) if db_path else init_database()


@router.post("", response_model=ApiResponse)
def create_memory_endpoint(
    body: MemoryCreateRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Create a new memory."""
    project_path = getattr(request.state, "project_path", None)
    conn = _get_conn(request)

    mem_data = MemoryCreate(
        content=body.content,
        context=body.context,
        tags=body.tags or [],
        type=body.type,
        importance=body.importance,
        related_activity_id=body.related_activity_id,
        related_memory_ids=body.related_memory_ids or [],
    )

    memory = create_memory(conn, mem_data, project_path=project_path)

    # Optionally generate embedding
    if body.generate_embedding:
        try:
            from ...embeddings import generate_and_store_embedding

            generate_and_store_embedding(conn, memory.id, memory.content)
        except Exception:
            pass

    # Entity extraction
    config = load_config()
    if config.entity_extraction_enabled:
        try:
            from ...extraction.entities import extract_and_link_entities

            extract_and_link_entities(conn, memory.id, memory.content, config)
        except Exception:
            pass

    # Sync to global
    if config.global_sync_enabled and project_path:
        sync_memory_to_global(
            memory_id=memory.id,
            content=memory.content,
            memory_type=memory.type,
            tags=memory.tags or [],
            context=memory.context,
            importance_score=memory.importance_score,
            status=memory.status,
            project_path=project_path,
            created_at=memory.created_at,
            updated_at=memory.updated_at,
        )

    event_bus.publish_sync("memory.created", {"id": memory.id, "type": memory.type})

    return ApiResponse(data=memory.model_dump(), meta={"id": memory.id})


@router.get("", response_model=ApiResponse)
def list_memories_endpoint(
    request: Request,
    type: str | None = Query(None, description="Filter by memory type"),
    tags: str | None = Query(None, description="Comma-separated tags"),
    status: str | None = Query(None, description="Filter by status"),
    sort_by: str = Query("last_accessed"),
    sort_order: str = Query("desc"),
    limit: int = Query(20, ge=1, le=200),
    offset: int = Query(0, ge=0),
    _key: str = Depends(verify_api_key),
):
    """List memories with optional filters."""
    conn = _get_conn(request)
    tags_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else None

    memories, total = list_memories(
        conn,
        type_filter=type,
        tags_filter=tags_list,
        status_filter=status,
        sort_by=sort_by,
        sort_order=sort_order,
        limit=limit,
        offset=offset,
    )

    return ApiResponse(
        data=[m.model_dump() for m in memories],
        meta=PaginationMeta(
            count=len(memories), total=total, limit=limit, offset=offset
        ).model_dump(),
    )


@router.get("/{memory_id}", response_model=ApiResponse)
def get_memory_endpoint(
    memory_id: str,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Get a single memory by ID."""
    conn = _get_conn(request)

    memory = get_memory(conn, memory_id)
    if not memory:
        raise HTTPException(status_code=404, detail=f"Memory not found: {memory_id}")

    return ApiResponse(data=memory.model_dump())


@router.put("/{memory_id}", response_model=ApiResponse)
def update_memory_endpoint(
    memory_id: str,
    body: MemoryUpdateRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Update a memory. Creates a version history entry."""
    conn = _get_conn(request)

    existing = get_memory(conn, memory_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"Memory not found: {memory_id}")

    # Create version before updating
    config = load_config()
    if config.versioning_enabled:
        content_changing = body.content is not None and body.content != existing.content
        if content_changing or not config.version_content_changes_only:
            create_version(
                conn,
                memory_id,
                old_content=existing.content,
                old_context=existing.context,
                old_tags=json.dumps(existing.tags) if existing.tags else None,
                old_importance=existing.importance_score,
                changed_by="api",
                change_reason="Updated via REST API",
            )

    update_data = MemoryUpdate(
        content=body.content,
        context=body.context,
        tags=body.tags,
        add_tags=body.add_tags,
        remove_tags=body.remove_tags,
        status=body.status,
        importance=body.importance,
    )

    updated = update_memory(conn, memory_id, update_data)
    if not updated:
        raise HTTPException(status_code=500, detail="Failed to update memory")

    event_bus.publish_sync("memory.updated", {"id": memory_id})

    return ApiResponse(data=updated.model_dump())


@router.delete("/{memory_id}", response_model=ApiResponse)
def delete_memory_endpoint(
    memory_id: str,
    request: Request,
    hard: bool = Query(False, description="Hard delete (permanent)"),
    _key: str = Depends(verify_api_key),
):
    """Delete a memory. Soft-delete by default (sets status=archived)."""
    conn = _get_conn(request)

    existing = get_memory(conn, memory_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"Memory not found: {memory_id}")

    if hard:
        deleted = delete_memory(conn, memory_id)
        if not deleted:
            raise HTTPException(status_code=500, detail="Failed to delete memory")
        event_bus.publish_sync("memory.deleted", {"id": memory_id, "hard": True})
        return ApiResponse(data={"deleted": True, "id": memory_id, "hard": True})
    else:
        update_data = MemoryUpdate(status="archived")
        update_memory(conn, memory_id, update_data)
        event_bus.publish_sync("memory.deleted", {"id": memory_id, "hard": False})
        return ApiResponse(data={"deleted": True, "id": memory_id, "hard": False})


@router.post("/{memory_id}/link", response_model=ApiResponse)
def link_memories_endpoint(
    memory_id: str,
    body: LinkMemoriesRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Create a relationship between two memories."""
    conn = _get_conn(request)

    if body.relationship_type not in VALID_RELATIONSHIP_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid relationship type. Valid: {VALID_RELATIONSHIP_TYPES}",
        )

    result = create_relationship(
        conn,
        source_id=memory_id,
        target_id=body.target_id,
        relationship_type=body.relationship_type,
        strength=body.strength,
    )

    if isinstance(result, dict) and result.get("error") == "not_found":
        raise HTTPException(
            status_code=404,
            detail=f"Memory not found: {result['missing_ids']}",
        )

    if result is None:
        raise HTTPException(status_code=409, detail="Relationship already exists")

    data = result.model_dump() if hasattr(result, "model_dump") else result
    return ApiResponse(data=data)


@router.get("/{memory_id}/history", response_model=ApiResponse)
def get_memory_history_endpoint(
    memory_id: str,
    request: Request,
    limit: int = Query(20, ge=1, le=50),
    include_content: bool = Query(True),
    _key: str = Depends(verify_api_key),
):
    """Get version history for a memory."""
    conn = _get_conn(request)

    memory = get_memory(conn, memory_id)
    if not memory:
        raise HTTPException(status_code=404, detail=f"Memory not found: {memory_id}")

    versions = get_memory_versions(conn, memory_id, limit=limit, include_content=include_content)
    total = get_version_count(conn, memory_id)

    return ApiResponse(
        data={
            "current": memory.model_dump(),
            "versions": versions,
        },
        meta={"total_versions": total},
    )


@router.post("/review", response_model=ApiResponse)
def review_memories_endpoint(
    body: ReviewMemoriesRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Bulk review/status update for memories."""
    from ...decay.importance import (
        SESSION_TYPES,
        get_freshness_status,
    )

    valid_actions = ["list", "mark_fresh", "mark_outdated", "mark_archived"]
    if body.action not in valid_actions:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid action. Valid: {valid_actions}",
        )

    conn = _get_conn(request)

    if body.action == "list":
        review_candidates = []
        for session_type in SESSION_TYPES:
            memories, _ = list_memories(conn, type_filter=session_type, limit=500)
            for mem in memories:
                calculated = get_freshness_status(
                    mem.created_at,
                    mem.last_verified,
                    mem.status,
                    review_days=body.days_threshold,
                )
                if calculated != mem.status:
                    review_candidates.append({
                        "id": mem.id,
                        "type": mem.type,
                        "current_status": mem.status,
                        "suggested_status": calculated,
                        "last_accessed": mem.last_accessed,
                        "content_preview": mem.content[:100],
                    })

        return ApiResponse(
            data=review_candidates[:body.limit],
            meta={"total_candidates": len(review_candidates)},
        )
    else:
        if not body.memory_ids:
            raise HTTPException(status_code=400, detail="memory_ids required for update actions")

        status_map = {
            "mark_fresh": "fresh",
            "mark_outdated": "outdated",
            "mark_archived": "archived",
        }
        new_status = status_map[body.action]

        updated = 0
        for mid in body.memory_ids:
            result = update_memory(conn, mid, MemoryUpdate(status=new_status))
            if result:
                updated += 1

        return ApiResponse(
            data={"updated": updated, "status": new_status},
        )
