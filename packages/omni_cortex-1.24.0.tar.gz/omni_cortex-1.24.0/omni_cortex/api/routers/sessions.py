"""Sessions router — session lifecycle management."""

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from ...database.connection import init_database
from ...models.session import (
    SessionCreate,
    create_session,
    end_session,
    get_recent_sessions,
    get_session_summary,
)
from ..auth import verify_api_key
from ..schemas import ApiResponse, SessionCreateRequest, SessionEndRequest
from ..websocket import event_bus

router = APIRouter(prefix="/sessions", tags=["sessions"])


def _get_conn(request: Request):
    db_path = getattr(request.state, "db_path", None)
    return init_database(db_path=db_path) if db_path else init_database()


@router.post("", response_model=ApiResponse)
def start_session(
    body: SessionCreateRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Start a new session."""
    project_path = getattr(request.state, "project_path", None) or "unknown"
    conn = _get_conn(request)

    data = SessionCreate(
        session_id=body.session_id,
        project_path=project_path,
        provide_context=body.provide_context,
        context_depth=body.context_depth,
    )

    session = create_session(conn, data)

    # Optionally provide context from recent sessions
    context = None
    if body.provide_context:
        recent = get_recent_sessions(conn, project_path=project_path, limit=body.context_depth)
        context_items = []
        for s in recent:
            if s.id == session.id:
                continue
            summary = get_session_summary(conn, s.id)
            context_items.append({
                "session_id": s.id,
                "started_at": s.started_at,
                "ended_at": s.ended_at,
                "summary": s.summary,
                "key_learnings": summary.key_learnings if summary else None,
            })
        if context_items:
            context = context_items

    event_bus.publish_sync("session.started", {"id": session.id})

    return ApiResponse(
        data=session.model_dump(),
        meta={"context": context} if context else {},
    )


@router.put("/{session_id}/end", response_model=ApiResponse)
def end_session_endpoint(
    session_id: str,
    body: SessionEndRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """End a session with an optional summary."""
    conn = _get_conn(request)

    session = end_session(
        conn,
        session_id=session_id,
        summary=body.summary,
        key_learnings=body.key_learnings,
    )

    if not session:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")

    event_bus.publish_sync("session.ended", {"id": session_id})

    return ApiResponse(data=session.model_dump())


@router.get("/context", response_model=ApiResponse)
def get_session_context(
    request: Request,
    depth: int = Query(3, ge=1, le=10),
    _key: str = Depends(verify_api_key),
):
    """Get context from recent sessions."""
    project_path = getattr(request.state, "project_path", None)
    conn = _get_conn(request)

    recent = get_recent_sessions(conn, project_path=project_path, limit=depth)

    context = []
    for s in recent:
        summary = get_session_summary(conn, s.id)
        context.append({
            "session": s.model_dump(),
            "summary": summary.model_dump() if summary else None,
        })

    return ApiResponse(data=context, meta={"count": len(context)})
