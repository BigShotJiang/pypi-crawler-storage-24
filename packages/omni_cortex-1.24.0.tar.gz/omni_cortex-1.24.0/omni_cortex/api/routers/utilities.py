"""Utilities router — tags, stats, export, sync, health."""

import json

from fastapi import APIRouter, Depends, Request

from ...database.connection import init_database
from ...database.sync import get_global_stats, sync_all_project_memories
from ...models.activity import get_activities
from ...models.memory import list_memories
from ...utils.timestamps import now_iso
from ..auth import verify_api_key
from ..schemas import ApiResponse, ExportRequest, SyncRequest

router = APIRouter(tags=["utilities"])


def _get_conn(request: Request):
    db_path = getattr(request.state, "db_path", None)
    return init_database(db_path=db_path) if db_path else init_database()


@router.get("/tags", response_model=ApiResponse)
def list_tags(
    request: Request,
    min_count: int = 1,
    limit: int = 50,
    _key: str = Depends(verify_api_key),
):
    """List all tags with usage counts."""
    conn = _get_conn(request)

    cursor = conn.cursor()
    cursor.execute("SELECT tags FROM memories WHERE tags IS NOT NULL AND tags != '[]'")

    tag_counts: dict[str, int] = {}
    for row in cursor.fetchall():
        tags = row["tags"]
        if tags:
            if isinstance(tags, str):
                tags = json.loads(tags)
            for tag in tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1

    filtered = [
        {"tag": tag, "count": count}
        for tag, count in tag_counts.items()
        if count >= min_count
    ]
    filtered.sort(key=lambda x: x["count"], reverse=True)
    filtered = filtered[:limit]

    return ApiResponse(data=filtered, meta={"total_tags": len(tag_counts)})


@router.get("/stats", response_model=ApiResponse)
def get_stats(
    _key: str = Depends(verify_api_key),
):
    """Get global statistics."""
    stats = get_global_stats()
    return ApiResponse(data=stats)


@router.post("/export", response_model=ApiResponse)
def export_data(
    body: ExportRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Export memories and/or activities."""
    conn = _get_conn(request)

    data: dict = {"exported_at": now_iso(), "format": body.format}

    if body.include_memories:
        memories, _ = list_memories(conn, limit=1000)
        data["memories"] = [m.model_dump() for m in memories]

    if body.include_activities:
        activities, _ = get_activities(conn, since=body.since, limit=1000)
        data["activities"] = [a.model_dump() for a in activities]

    if body.format == "markdown":
        lines = [f"# Omni Cortex Export\nExported: {data['exported_at']}\n"]
        if data.get("memories"):
            lines.append("## Memories\n")
            for mem in data["memories"]:
                lines.append(f"### [{mem['type']}] {mem['id']}")
                lines.append(f"**Content:** {mem['content']}")
                if mem.get("tags"):
                    lines.append(f"**Tags:** {', '.join(mem['tags'])}")
                lines.append(f"**Created:** {mem['created_at']}\n")
        return ApiResponse(data={"markdown": "\n".join(lines)}, meta={"format": "markdown"})

    return ApiResponse(data=data, meta={"format": "json"})


@router.post("/sync", response_model=ApiResponse)
def sync_to_global(
    body: SyncRequest,
    _key: str = Depends(verify_api_key),
):
    """Sync project memories to the global database."""
    if body.full_sync:
        count = sync_all_project_memories()
        return ApiResponse(data={"synced": count})

    return ApiResponse(
        data={"message": "Set full_sync=true to sync all project memories."},
    )


@router.get("/health")
def health_check():
    """Health check endpoint — no auth required."""
    return {"status": "ok", "version": "1.0.0"}
