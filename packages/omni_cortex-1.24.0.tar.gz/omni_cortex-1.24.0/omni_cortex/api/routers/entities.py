"""Entities router — entity search and knowledge graph."""

from fastapi import APIRouter, Depends, Query, Request

from ...database.connection import init_database
from ...models.entity import get_entity_graph, search_entities
from ..auth import verify_api_key
from ..schemas import ApiResponse

router = APIRouter(prefix="/entities", tags=["entities"])


def _get_conn(request: Request):
    db_path = getattr(request.state, "db_path", None)
    return init_database(db_path=db_path) if db_path else init_database()


@router.get("", response_model=ApiResponse)
def search_entities_endpoint(
    request: Request,
    query: str = Query(..., min_length=1),
    type_filter: str | None = Query(None),
    min_mentions: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=50),
    _key: str = Depends(verify_api_key),
):
    """Search entities by name with optional type filter."""
    conn = _get_conn(request)

    results = search_entities(
        conn,
        query=query,
        type_filter=type_filter,
        min_mentions=min_mentions,
        limit=limit,
    )

    formatted = []
    for item in results:
        entity = item["entity"]
        formatted.append({
            "id": entity.id,
            "name": entity.name,
            "display_name": entity.display_name,
            "type": entity.type,
            "mention_count": entity.mention_count,
            "first_seen": entity.first_seen,
            "last_seen": entity.last_seen,
            "connected_memories": item["connected_memories"],
            "memory_ids": item["memory_ids"],
        })

    return ApiResponse(data=formatted, meta={"count": len(formatted), "query": query})


@router.get("/graph", response_model=ApiResponse)
def get_entity_graph_endpoint(
    request: Request,
    entity_name: str | None = Query(None),
    entity_type: str | None = Query(None),
    min_mentions: int = Query(2, ge=1),
    limit: int = Query(50, ge=1, le=200),
    _key: str = Depends(verify_api_key),
):
    """Get entity relationship graph in D3-compatible format."""
    conn = _get_conn(request)

    graph = get_entity_graph(
        conn,
        entity_name=entity_name,
        entity_type=entity_type,
        min_mentions=min_mentions,
        limit=limit,
    )

    entity_nodes = [n for n in graph["nodes"] if n["type"] == "entity"]
    memory_nodes = [n for n in graph["nodes"] if n["type"] == "memory"]

    return ApiResponse(
        data=graph,
        meta={
            "total_nodes": len(graph["nodes"]),
            "entity_nodes": len(entity_nodes),
            "memory_nodes": len(memory_nodes),
            "total_edges": len(graph["edges"]),
        },
    )
