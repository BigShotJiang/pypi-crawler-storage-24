"""Search router — keyword, semantic, and hybrid search."""

from fastapi import APIRouter, Depends, Query, Request

from ...database.connection import init_database
from ...database.sync import search_global_memories
from ...search.hybrid import search
from ..auth import verify_api_key
from ..schemas import ApiResponse, SearchRequest

router = APIRouter(prefix="/search", tags=["search"])


def _get_conn(request: Request):
    db_path = getattr(request.state, "db_path", None)
    return init_database(db_path=db_path) if db_path else init_database()


@router.post("", response_model=ApiResponse)
def search_memories(
    body: SearchRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Search memories with keyword, semantic, or hybrid mode."""
    conn = _get_conn(request)

    results = search(
        conn,
        query=body.query,
        mode=body.mode,
        type_filter=body.type_filter,
        tags_filter=body.tags_filter,
        status_filter=body.status_filter,
        min_importance=body.min_importance,
        include_archived=body.include_archived,
        limit=body.limit,
    )

    formatted = []
    for memory, kw_score, sem_score in results:
        entry = memory.model_dump()
        entry["keyword_score"] = round(kw_score, 4)
        entry["semantic_score"] = round(sem_score, 4)
        entry["combined_score"] = round(kw_score * 0.4 + sem_score * 0.6, 4)
        formatted.append(entry)

    return ApiResponse(
        data=formatted,
        meta={"count": len(formatted), "query": body.query, "mode": body.mode},
    )


@router.get("/global", response_model=ApiResponse)
def search_global(
    query: str = Query(..., min_length=1),
    type_filter: str | None = Query(None),
    tags: str | None = Query(None, description="Comma-separated tags"),
    project_filter: str | None = Query(None),
    limit: int = Query(20, ge=1, le=100),
    _key: str = Depends(verify_api_key),
):
    """Search memories across all projects via global index."""
    tags_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else None

    results = search_global_memories(
        query=query,
        type_filter=type_filter,
        tags_filter=tags_list,
        project_filter=project_filter,
        limit=limit,
    )

    return ApiResponse(
        data=results,
        meta={"count": len(results), "query": query},
    )
