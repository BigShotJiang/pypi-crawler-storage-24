"""Activities router — activity logging and timeline."""

from fastapi import APIRouter, Depends, Query, Request

from ...database.connection import init_database
from ...models.activity import ActivityCreate, create_activity, get_activities
from ...models.memory import list_memories
from ..auth import verify_api_key
from ..schemas import ActivityCreateRequest, ApiResponse, PaginationMeta
from ..websocket import event_bus

router = APIRouter(tags=["activities"])


def _get_conn(request: Request):
    db_path = getattr(request.state, "db_path", None)
    return init_database(db_path=db_path) if db_path else init_database()


@router.post("/activities", response_model=ApiResponse)
def log_activity(
    body: ActivityCreateRequest,
    request: Request,
    _key: str = Depends(verify_api_key),
):
    """Log an activity."""
    project_path = getattr(request.state, "project_path", None)
    conn = _get_conn(request)

    data = ActivityCreate(
        event_type=body.event_type,
        tool_name=body.tool_name,
        tool_input=body.tool_input,
        tool_output=body.tool_output,
        duration_ms=body.duration_ms,
        success=body.success,
        error_message=body.error_message,
        file_path=body.file_path,
        agent_id=body.agent_id,
        command_name=body.command_name,
        command_scope=body.command_scope,
        mcp_server=body.mcp_server,
        skill_name=body.skill_name,
    )

    activity = create_activity(conn, data, project_path=project_path)

    event_bus.publish_sync("activity.logged", {
        "id": activity.id,
        "event_type": activity.event_type,
    })

    return ApiResponse(data=activity.model_dump(), meta={"id": activity.id})


@router.get("/activities", response_model=ApiResponse)
def get_activities_endpoint(
    request: Request,
    session_id: str | None = Query(None),
    event_type: str | None = Query(None),
    tool_name: str | None = Query(None),
    since: str | None = Query(None),
    until: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    _key: str = Depends(verify_api_key),
):
    """Query activities with filters."""
    conn = _get_conn(request)

    activities, total = get_activities(
        conn,
        session_id=session_id,
        event_type=event_type,
        tool_name=tool_name,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )

    return ApiResponse(
        data=[a.model_dump() for a in activities],
        meta=PaginationMeta(
            count=len(activities), total=total, limit=limit, offset=offset
        ).model_dump(),
    )


@router.get("/timeline", response_model=ApiResponse)
def get_timeline(
    request: Request,
    limit: int = Query(50, ge=1, le=200),
    since: str | None = Query(None),
    _key: str = Depends(verify_api_key),
):
    """Get a mixed timeline of memories and activities sorted by timestamp."""
    conn = _get_conn(request)

    # Get recent memories
    memories, _ = list_memories(conn, sort_by="created_at", sort_order="desc", limit=limit)

    # Get recent activities
    activities, _ = get_activities(conn, since=since, limit=limit)

    # Merge and sort by timestamp
    timeline = []
    for m in memories:
        timeline.append({
            "kind": "memory",
            "id": m.id,
            "timestamp": m.created_at,
            "type": m.type,
            "content_preview": m.content[:100],
            "tags": m.tags,
            "status": m.status,
        })
    for a in activities:
        timeline.append({
            "kind": "activity",
            "id": a.id,
            "timestamp": a.timestamp,
            "event_type": a.event_type,
            "tool_name": a.tool_name,
            "success": a.success,
        })

    timeline.sort(key=lambda x: x["timestamp"], reverse=True)
    timeline = timeline[:limit]

    return ApiResponse(data=timeline, meta={"count": len(timeline)})
