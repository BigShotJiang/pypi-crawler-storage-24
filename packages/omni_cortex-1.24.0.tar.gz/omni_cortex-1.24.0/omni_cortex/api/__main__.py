"""CLI entrypoint: python -m omni_cortex.api"""

import argparse
import logging
import sys

import uvicorn

from .config import ensure_api_key, load_api_config


def main() -> None:
    parser = argparse.ArgumentParser(description="Omni-Cortex REST API Server")
    parser.add_argument("--host", default=None, help="Host to bind (default: from config or 127.0.0.1)")
    parser.add_argument("--port", type=int, default=None, help="Port to bind (default: from config or 8766)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload for development")
    parser.add_argument("--log-level", default="info", choices=["debug", "info", "warning", "error"])
    args = parser.parse_args()

    logging.basicConfig(level=getattr(logging, args.log_level.upper()))

    config = load_api_config()

    # CLI args override config
    host = args.host or config.host
    port = args.port or config.port

    # Ensure API key exists (prints on first run)
    ensure_api_key(config)

    print(f"\nStarting Omni-Cortex API on http://{host}:{port}")
    print(f"  Docs: http://{host}:{port}/api/v1/docs")
    print(f"  Health: http://{host}:{port}/api/v1/health\n")

    # Use h11 on Windows to avoid httptools compatibility issues
    http_impl = "h11" if sys.platform == "win32" else "auto"

    uvicorn.run(
        "omni_cortex.api:create_app",
        host=host,
        port=port,
        reload=args.reload,
        factory=True,
        log_level=args.log_level,
        http=http_impl,
    )


if __name__ == "__main__":
    main()
