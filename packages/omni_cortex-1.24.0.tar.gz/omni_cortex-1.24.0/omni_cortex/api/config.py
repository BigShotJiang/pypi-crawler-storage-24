"""API-specific configuration."""

import secrets
from dataclasses import dataclass, field
from pathlib import Path

import yaml

DEFAULT_CONFIG_DIR = Path.home() / ".claude" / ".omni-cortex"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "api_config.yaml"


@dataclass
class ApiConfig:
    """Configuration for the standalone REST API."""

    host: str = "127.0.0.1"
    port: int = 8766
    cors_origins: list[str] = field(default_factory=lambda: ["*"])
    rate_limit: str = "60/minute"
    api_key: str = ""
    default_project_path: str = ""


def load_api_config(config_path: Path | None = None) -> ApiConfig:
    """Load API config from YAML file, creating with defaults if missing."""
    path = config_path or DEFAULT_CONFIG_PATH
    config = ApiConfig()

    if path.exists():
        try:
            with open(path) as f:
                data = yaml.safe_load(f) or {}
            for key, value in data.items():
                if hasattr(config, key) and value is not None:
                    setattr(config, key, value)
        except Exception:
            pass

    return config


def save_api_config(config: ApiConfig, config_path: Path | None = None) -> None:
    """Save API config to YAML file."""
    path = config_path or DEFAULT_CONFIG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)

    data = {
        "host": config.host,
        "port": config.port,
        "cors_origins": config.cors_origins,
        "rate_limit": config.rate_limit,
        "api_key": config.api_key,
        "default_project_path": config.default_project_path,
    }

    with open(path, "w") as f:
        yaml.dump(data, f, default_flow_style=False)


def ensure_api_key(config: ApiConfig, config_path: Path | None = None) -> str:
    """Ensure an API key exists, generating one if needed.

    Returns the API key and prints it on first generation.
    """
    if config.api_key:
        return config.api_key

    config.api_key = secrets.token_urlsafe(32)
    save_api_config(config, config_path)

    print("\n" + "=" * 60)
    print("  Omni-Cortex API Key (generated on first run)")
    print("=" * 60)
    print(f"\n  {config.api_key}\n")
    print("  Store this key securely. Use it in requests as:")
    print("    Authorization: Bearer <key>")
    print("    or X-API-Key: <key>")
    print("=" * 60 + "\n")

    return config.api_key
