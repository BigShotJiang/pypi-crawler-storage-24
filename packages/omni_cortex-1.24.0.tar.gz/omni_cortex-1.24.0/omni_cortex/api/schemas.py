"""Pydantic request/response models for the REST API."""

from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class ApiResponse(BaseModel, Generic[T]):
    """Standard response envelope."""

    data: T
    meta: dict[str, Any] = Field(default_factory=dict)


class ApiError(BaseModel):
    """Error response."""

    error: str
    detail: str | None = None
    status_code: int


class PaginationMeta(BaseModel):
    """Pagination metadata."""

    count: int
    total: int
    limit: int
    offset: int


# --- Memory request models ---

class MemoryCreateRequest(BaseModel):
    """Request body for creating a memory."""

    content: str = Field(..., min_length=1)
    context: str | None = None
    tags: list[str] | None = Field(default_factory=list)
    type: str = "general"
    importance: int | None = Field(None, ge=1, le=100)
    related_activity_id: str | None = None
    related_memory_ids: list[str] | None = Field(default_factory=list)
    generate_embedding: bool = False


class MemoryUpdateRequest(BaseModel):
    """Request body for updating a memory."""

    content: str | None = None
    context: str | None = None
    tags: list[str] | None = None
    add_tags: list[str] | None = None
    remove_tags: list[str] | None = None
    status: str | None = None
    importance: int | None = Field(None, ge=1, le=100)


class LinkMemoriesRequest(BaseModel):
    """Request body for linking memories."""

    target_id: str
    relationship_type: str = Field(
        ..., description="related_to, supersedes, derived_from, contradicts"
    )
    strength: float = Field(1.0, ge=0.0, le=1.0)


class ReviewMemoriesRequest(BaseModel):
    """Request body for reviewing memories."""

    action: str = Field(..., description="list, mark_fresh, mark_outdated, mark_archived")
    days_threshold: int = Field(30, ge=1)
    memory_ids: list[str] | None = None
    limit: int = Field(20, ge=1, le=100)


# --- Search request models ---

class SearchRequest(BaseModel):
    """Request body for search."""

    query: str = Field(..., min_length=1)
    mode: str = Field("keyword", description="keyword, semantic, or hybrid")
    type_filter: str | None = None
    tags_filter: list[str] | None = None
    status_filter: str | None = None
    min_importance: int | None = Field(None, ge=0, le=100)
    include_archived: bool = False
    limit: int = Field(10, ge=1, le=100)


# --- Activity request models ---

class ActivityCreateRequest(BaseModel):
    """Request body for logging an activity."""

    event_type: str
    tool_name: str | None = None
    tool_input: str | None = None
    tool_output: str | None = None
    duration_ms: int | None = Field(None, ge=0)
    success: bool = True
    error_message: str | None = None
    file_path: str | None = None
    agent_id: str | None = None
    command_name: str | None = None
    command_scope: str | None = None
    mcp_server: str | None = None
    skill_name: str | None = None


# --- Session request models ---

class SessionCreateRequest(BaseModel):
    """Request body for starting a session."""

    session_id: str | None = None
    provide_context: bool = True
    context_depth: int = Field(3, ge=1, le=10)


class SessionEndRequest(BaseModel):
    """Request body for ending a session."""

    summary: str | None = None
    key_learnings: list[str] | None = None


# --- Export request models ---

class ExportRequest(BaseModel):
    """Request body for exporting data."""

    format: str = Field("json", description="json or markdown")
    include_activities: bool = True
    include_memories: bool = True
    since: str | None = None


# --- Sync request models ---

class SyncRequest(BaseModel):
    """Request body for syncing to global."""

    full_sync: bool = False
