"""Omni-Cortex Standalone REST API."""

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .auth import set_api_config
from .config import ApiConfig, load_api_config
from .websocket import router as ws_router
from .websocket import set_ws_config

logger = logging.getLogger(__name__)


def create_app(config: ApiConfig | None = None) -> FastAPI:
    """Create and configure the FastAPI application."""
    if config is None:
        config = load_api_config()

    # Wire up auth and websocket config
    set_api_config(config)
    set_ws_config(config)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        """Initialize database on startup."""
        from ..database.connection import close_all_connections, init_database

        logger.info("Initializing database...")
        init_database()
        init_database(is_global=True)
        logger.info("Database initialized")
        yield
        close_all_connections()

    app = FastAPI(
        title="Omni-Cortex API",
        version="1.0.0",
        description="REST API for the Omni-Cortex memory system",
        docs_url="/api/v1/docs",
        redoc_url="/api/v1/redoc",
        openapi_url="/api/v1/openapi.json",
        lifespan=lifespan,
    )

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Rate limiting (graceful degradation)
    try:
        from slowapi import Limiter, _rate_limit_exceeded_handler
        from slowapi.errors import RateLimitExceeded
        from slowapi.util import get_remote_address

        limiter = Limiter(key_func=get_remote_address, default_limits=[config.rate_limit])
        app.state.limiter = limiter
        app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
        logger.info(f"Rate limiting enabled: {config.rate_limit}")
    except ImportError:
        logger.info("slowapi not installed, rate limiting disabled")

    # Project path middleware
    @app.middleware("http")
    async def project_path_middleware(request: Request, call_next):
        """Resolve project path from header, query param, or config default."""
        project_path = (
            request.headers.get("X-Project-Path")
            or request.query_params.get("project_path")
            or config.default_project_path
            or None
        )

        if project_path:
            import os

            os.environ["CLAUDE_PROJECT_DIR"] = project_path
            request.state.project_path = project_path
            db_path = Path(project_path) / ".omni-cortex" / "cortex.db"
            request.state.db_path = db_path
        else:
            request.state.project_path = None
            request.state.db_path = None

        return await call_next(request)

    # Exception handlers
    @app.exception_handler(Exception)
    async def generic_exception_handler(request: Request, exc: Exception):
        logger.error(f"Unhandled error: {exc}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error", "detail": str(exc), "status_code": 500},
        )

    # Register routers under /api/v1 prefix
    from .routers.activities import router as activities_router
    from .routers.entities import router as entities_router
    from .routers.memories import router as memories_router
    from .routers.search import router as search_router
    from .routers.sessions import router as sessions_router
    from .routers.utilities import router as utilities_router

    api_prefix = "/api/v1"
    app.include_router(memories_router, prefix=api_prefix)
    app.include_router(search_router, prefix=api_prefix)
    app.include_router(activities_router, prefix=api_prefix)
    app.include_router(sessions_router, prefix=api_prefix)
    app.include_router(entities_router, prefix=api_prefix)
    app.include_router(utilities_router, prefix=api_prefix)
    app.include_router(ws_router, prefix=api_prefix)

    return app
