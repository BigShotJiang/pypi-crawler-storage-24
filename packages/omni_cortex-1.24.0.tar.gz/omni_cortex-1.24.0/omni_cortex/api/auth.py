"""API key authentication dependency."""

from fastapi import HTTPException, Request, Security
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer

from .config import ApiConfig

# Security schemes
_bearer_scheme = HTTPBearer(auto_error=False)
_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

# Module-level config reference set by create_app
_api_config: ApiConfig | None = None


def set_api_config(config: ApiConfig) -> None:
    """Set the API config for auth verification."""
    global _api_config
    _api_config = config


def verify_api_key(
    request: Request,
    bearer: HTTPAuthorizationCredentials | None = Security(_bearer_scheme),
    api_key: str | None = Security(_api_key_header),
) -> str:
    """FastAPI dependency that verifies the API key.

    Accepts either:
      - Authorization: Bearer <key>
      - X-API-Key: <key>

    Skips auth for /api/v1/health and docs paths.
    """
    path = request.url.path
    if path.endswith("/health") or "/docs" in path or "/openapi" in path or "/redoc" in path:
        return "anonymous"

    if _api_config is None:
        raise HTTPException(status_code=500, detail="API not configured")

    expected = _api_config.api_key

    # Check Bearer token first
    if bearer and bearer.credentials == expected:
        return expected

    # Check X-API-Key header
    if api_key and api_key == expected:
        return expected

    raise HTTPException(
        status_code=401,
        detail="Invalid or missing API key",
        headers={"WWW-Authenticate": "Bearer"},
    )
