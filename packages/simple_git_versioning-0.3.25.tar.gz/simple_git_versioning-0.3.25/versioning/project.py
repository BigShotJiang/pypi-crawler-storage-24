# SPDX-License-Identifier: MIT

from __future__ import annotations

import os
import warnings
from abc import abstractmethod
from collections import deque
from collections.abc import Iterable, Iterator
from contextlib import suppress

try:
    from enum import StrEnum
except ImportError:  # pragma: no cover  # python<3.11
    from enum import Enum

    class StrEnum(str, Enum):

        @staticmethod
        def _generate_next_value_(name, start, count, last_values):
            return name.lower()

        def __str__(self):
            return str.__str__(self)


from functools import cached_property
from pathlib import Path
from typing import Protocol, TypeVar
from unittest.mock import patch

from versioning.conventional_commit import (
    ConventionalCommit,
    InvalidConventionalCommitSubject,
)

try:
    from typing import Self
except ImportError:  # pragma: no cover  # python<3.11
    from typing_extensions import Self

from icontract import require
from sh import Command, ErrorReturnCode_128, ErrorReturnCode_129
from sh.contrib import git

from .version import InvalidVersion, Version, VersionBump


class NotAGitWorkTree(RuntimeError):
    """
    Raised when an operation requires a git worktree but there is none
    """

    def __init__(self, path: Path, *args, **kwargs):
        super().__init__(path, *args, **kwargs)

    @property
    def path(self) -> str:
        return self.args[0]


class NoVersion(RuntimeError):
    """
    Raised when no version can be found for a project at a given reference
    """

    def __init__(self, project: Project, reference: str, *args, **kwargs):
        super().__init__(project, reference, *args, **kwargs)

    @property
    def project(self) -> Project:
        return self.args[0]

    @property
    def reference(self) -> str:
        return self.args[1]


class NoVersionInShallowRepository(NoVersion):
    """
    Raised when no version tags are found in a shallow repository
    """

    def __str__(self):
        return f"Unable to locate the last version tag at, or prior to '{self.reference}' in the limited commit history available. Extend the commit history such that it includes as least one version tag or use 'git fetch --unshallow --tags' to ensure the project's version can be accurately calculated."


class AmbiguousReference(RuntimeError):
    """
    Raised when an operation fails due to an ambiguity in the history
    """

    def __init__(self, reference: str, candidates: Iterable[str], *args, **kwargs):
        super().__init__(reference, frozenset(candidates), *args, **kwargs)
        assert len(self.candidates) > 1

    @cached_property
    def reference(self) -> frozenset[str]:
        return self.args[0]

    @cached_property
    def candidates(self) -> frozenset[str]:
        return frozenset(self.args[1])


class AmbiguousRoot(AmbiguousReference):
    """
    Raised when a single root commit cannot be computed due to an ambiguity in the history
    """


class AmbiguousVersion(AmbiguousReference):
    """
    Raised when a version cannot be computed due to an ambiguity in the history
    """


class InvalidReference(ValueError):
    """
    Raised when an operation incurs a lookup on an invalid reference
    """

    def __init__(self, reference: str, *args, **kwargs):
        super().__init__(reference, *args, **kwargs)

    @property
    def reference(self) -> str:
        return self.args[0]


def _is_inside_git_work_tree() -> bool:
    """
    Return `True` if the current directory is inside a git work tree, `False` otherwise
    """
    try:
        return git("rev-parse", "--is-inside-work-tree").rstrip() == "true"
    except ErrorReturnCode_128:
        return False


class InvalidVersionBumpTrailer(ValueError):
    """
    Raised when an invalid version bump is specified as a git trailer
    """

    def __init__(self, bump: str, *args, **kwargs):
        super().__init__(bump, *args, **kwargs)

    @property
    def bump(self) -> str:
        return self.args[0]


class VersionBumpSource(StrEnum):
    TRAILERS = "trailers"
    CONVENTIONAL_COMMITS = "conventional-commits"

    def __str__(self):
        return str.__str__(self)


V = TypeVar("V", bound=Version)


def read_version_bump_source(path: Path) -> tuple[str, ...] | None:
    """
    Read `version-bump-source` from `[tool.simple-git-versioning]` in pyproject.toml
    """
    try:
        import tomllib
    except ImportError:  # pragma: no cover  # python<3.11
        from io import TextIOWrapper

        import toml

        def _load(stream):
            return toml.load(TextIOWrapper(stream))

    else:
        _load = tomllib.load

    try:
        with open(path / "pyproject.toml", "rb") as stream:
            pyproject = _load(stream)
    except FileNotFoundError:
        return None

    try:
        source = pyproject["tool"]["simple-git-versioning"]["version-bump-source"]
    except (KeyError, TypeError):
        return None

    if isinstance(source, str):
        return (source,)
    if isinstance(source, list):
        return tuple(source)
    return None


class Project(Protocol[V]):
    path: Path
    scheme: type[V]
    version_bump_source: tuple[VersionBumpSource, ...]
    _pushed: list[str]

    def __init__(
        self, *args, path: Path, version_bump_source: Iterable[str | VersionBumpSource] = ("trailers",), **kwargs
    ):
        super().__init__(*args, **kwargs)
        self.path = path.resolve()
        self._pushed = []
        self.version_bump_source = (
            *dict.fromkeys(
                VersionBumpSource(_source) if isinstance(_source, str) else _source for _source in version_bump_source
            ),
        )

    def __enter__(self) -> Self:
        self._pushed.append(os.getcwd())
        os.chdir(self.path)
        if not _is_inside_git_work_tree():
            os.chdir(self._pushed.pop())
            raise NotAGitWorkTree(path=self.path)
        return self

    def __exit__(self, *args, **kwargs) -> bool | None:
        os.chdir(self._pushed.pop())

    @property
    @require(lambda self: Path.cwd().resolve() == self.path.resolve())
    def _git(self) -> Command:
        return git

    def is_shallow(self) -> bool:
        return self._git("rev-parse", "--is-shallow-repository").rstrip() == "true"

    def canonical(self, reference: str) -> str:
        try:
            return self._git("rev-list", "--max-count=1", reference, "--").rstrip()
        except ErrorReturnCode_128 as exc:
            raise InvalidReference(reference) from exc

    def _tags(self, reference: str) -> Iterator[str]:
        try:
            yield from self._git.tag("--points-at", reference, "--").rstrip().split("\n")
        except ErrorReturnCode_129 as exc:
            if b"malformed object name" in exc.stderr:
                raise InvalidReference(reference) from exc

    def versions(self, reference: str) -> Iterator[V]:
        for tag in self._tags(reference):
            with suppress(InvalidVersion):
                yield self.scheme.parse(tag)

    def version(self, reference: str = "HEAD") -> V:
        try:
            return max(self.versions(reference))
        except InvalidReference:
            raise
        except ValueError as exc:
            if os.environ.get("SIMPLE_GIT_VERSIONING_RELEASE", "").lower() not in ("", "0", "false"):
                with patch.dict(os.environ, {"SIMPLE_GIT_VERSIONING_RELEASE": ""}):
                    return self.release()
            raise NoVersion(self, reference) from exc

    def roots(self, reference: str) -> Iterator[str]:
        try:
            yield from self._git("rev-list", "--max-parents=0", reference, "--").rstrip().split("\n")
        except ErrorReturnCode_128 as exc:
            if b"bad revision" in exc.stderr:
                raise InvalidReference(reference) from exc

    def root(self, reference: str) -> str:
        try:
            roots = frozenset(self.roots(reference))
        except InvalidReference:
            raise
        assert roots, "every commit has at least one root"

        if len(roots) > 1:
            raise AmbiguousRoot(reference, roots)
        return next(iter(roots))

    def parents(self, reference: str) -> list[str]:
        try:
            return self._git("rev-list", "--max-count=1", "--parents", reference, "--").rstrip().split(" ")[1:]
        except ErrorReturnCode_128 as exc:
            if b"bad revision" in exc.stderr:
                raise InvalidReference(reference) from exc

    def last(self, reference: str = "HEAD") -> V:
        refs = deque((reference,))
        candidates = set()
        while refs:
            ref = refs.popleft()

            try:
                candidates.add(self.version(ref))
            except NoVersion:
                refs.extend(self.parents(ref))

        if not candidates:
            raise NoVersion(self, reference)
        if len(candidates) > 1:
            raise AmbiguousVersion(reference, map(str, candidates))

        return next(iter(candidates))

    def commit_message(self, commit: str) -> str:
        return self._git.show("--format=format:%B", "--no-patch", commit).rstrip()

    def trailers(self, commit: str, *args: str) -> Iterator[tuple[str, str]]:
        trailers = self._git(
            "interpret-trailers",
            "--no-divider",
            "--unfold",
            "--only-trailers",
            *args,
            _in=self._git.show("--format=format:%B", "--no-patch", commit, _piped=True),
        ).rstrip()
        if not trailers:
            return

        for trailer in trailers.split("\n"):
            key, value = trailer.split(":", maxsplit=1)
            yield key.strip(), value.strip()

    def revisions(self, start: str, end: str = "HEAD") -> Iterator[str]:
        yield from (line for line in self._git("rev-list", "--reverse", f"{start}..{end}").rstrip().split("\n") if line)

    def version_bump(self, commit: str) -> VersionBump | None:
        for source in self.version_bump_source:
            match source:
                case VersionBumpSource.TRAILERS:
                    for token, value in self.trailers(commit):
                        if token.casefold() != "version-bump":
                            continue

                        try:
                            return VersionBump(value)
                        except ValueError:
                            raise InvalidVersionBumpTrailer(value)
                case VersionBumpSource.CONVENTIONAL_COMMITS:
                    try:
                        cc = ConventionalCommit.parse(self.commit_message(commit))
                    except InvalidConventionalCommitSubject as exc:
                        warnings.warn(f"invalid conventional-commit subject line: {exc.subject}")
                    else:
                        if cc.breaking_change is not None:
                            return VersionBump.MAJOR
                        # TODO: make this mapping configurable
                        return {
                            "feat": VersionBump.MINOR,
                            "fix": VersionBump.PATCH,
                        }.get(cc.type.lower())
                case _:
                    raise ValueError(f"unsupported version bump source: {self.version_bump_source}")

        return VersionBump.PATCH

    @abstractmethod
    def release(self, reference: str = "HEAD") -> V:
        try:
            version = self.last(reference)
        except NoVersion:
            if self.is_shallow():
                raise NoVersionInShallowRepository(self, reference)
            version = self.scheme()
            root = self.root(reference)
        else:
            root = str(version)

        for commit in self.revisions(root, reference):
            bump = self.version_bump(commit)
            if bump is not None:
                version = version.bump(bump)

        return version
