"""Integration test for the cloud-core -> saturnday governance seam.

Validates the REAL cross-package call: ``ticket_runner._run_governance``
invokes ``saturnday.governance.run_governance_check`` and correctly unpacks
the ``(EvidencePack, Path)`` return value into ``(disposition, findings, evidence_path)``.

Requires the ``saturnday`` package to be installed.  All tests in this module
are skipped automatically when it is not available.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

saturnday = pytest.importorskip("saturnday")


def _create_git_repo(tmp_path: Path) -> Path:
    """Create a temporary git repo with a single empty initial commit.

    A real git repo is required because ``run_governance_check`` runs
    ``git diff`` internally.
    """
    repo = tmp_path / "test-repo"
    repo.mkdir()
    subprocess.run(["git", "init", str(repo)], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(repo), "config", "user.email", "test@test.com"],
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "-C", str(repo), "config", "user.name", "Test"],
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "-C", str(repo), "commit", "--allow-empty", "-m", "init"],
        check=True,
        capture_output=True,
    )
    return repo


@pytest.mark.integration
class TestGovernanceIntegration:
    """Validate the real cross-package governance call at the cloud-core seam."""

    def test_governance_returns_tuple(self, tmp_path: Path) -> None:
        """_run_governance returns a 3-tuple (disposition, findings, evidence_path)."""
        from saturnday.ticket_runner import _run_governance

        repo = _create_git_repo(tmp_path)

        # Write a file that contains a known governance violation: hardcoded JWT secret.
        vuln_file = repo / "auth.py"
        vuln_file.write_text(
            'JWT_SECRET = "hardcoded-secret-key-do-not-use-in-production"\n'
            "import jwt\n"
            'token = jwt.encode({"user": "admin"}, JWT_SECRET, algorithm="HS256")\n',
            encoding="utf-8",
        )

        subprocess.run(
            ["git", "-C", str(repo), "add", "auth.py"],
            check=True,
            capture_output=True,
        )

        result = _run_governance(repo)

        assert isinstance(result, tuple), "Expected a tuple from _run_governance"
        assert len(result) == 3, "Expected exactly 3 elements: (disposition, findings, evidence_path)"

        disposition, findings, evidence_path = result

        assert isinstance(disposition, str), "disposition must be a str"
        assert disposition in ("PASS", "FAIL", "WARN"), (
            f"disposition must be PASS, FAIL, or WARN; got {disposition!r}"
        )
        assert isinstance(findings, list), "findings must be a list"
        assert isinstance(evidence_path, str), "evidence_path must be a str"

    def test_governance_detects_violation(self, tmp_path: Path) -> None:
        """A staged file with a hardcoded JWT secret triggers governance FAIL."""
        from saturnday.ticket_runner import _run_governance

        repo = _create_git_repo(tmp_path)

        vuln_file = repo / "secrets.py"
        vuln_file.write_text(
            'SECRET_KEY = "super-secret-jwt-signing-key-12345"\n'
            "import jwt\n"
            "def make_token(user_id):\n"
            '    return jwt.encode({"sub": user_id}, SECRET_KEY)\n',
            encoding="utf-8",
        )

        subprocess.run(
            ["git", "-C", str(repo), "add", "secrets.py"],
            check=True,
            capture_output=True,
        )

        disposition, findings, evidence_path = _run_governance(repo)

        assert disposition == "FAIL", (
            f"Expected FAIL for hardcoded JWT secret, got {disposition!r}"
        )
        assert len(findings) > 0, "Expected at least one finding for the hardcoded secret"

    def test_clean_file_passes(self, tmp_path: Path) -> None:
        """A staged file with no violations passes governance."""
        from saturnday.ticket_runner import _run_governance

        repo = _create_git_repo(tmp_path)

        clean_file = repo / "utils.py"
        clean_file.write_text(
            "def add(a: int, b: int) -> int:\n"
            '    """Add two numbers."""\n'
            "    return a + b\n",
            encoding="utf-8",
        )

        subprocess.run(
            ["git", "-C", str(repo), "add", "utils.py"],
            check=True,
            capture_output=True,
        )

        disposition, findings, evidence_path = _run_governance(repo)

        assert disposition in ("PASS", "WARN"), (
            f"Expected PASS or WARN for clean file, got {disposition!r}"
        )
