"""Backstage Software Catalog parser and data model.

Parses catalog.yaml (Backstage descriptor format) into typed entities
for validation against compose files and the filesystem.
"""

from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

import yaml


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


class CatalogEntity:
    """A single Backstage entity parsed from catalog.yaml."""

    __slots__ = (
        "kind",
        "name",
        "description",
        "tags",
        "annotations",
        "links",
        "spec_type",
        "lifecycle",
        "system",
        "owner",
        "depends_on",
        "provides_apis",
        "consumes_apis",
    )

    def __init__(self, doc: dict) -> None:
        meta = doc.get("metadata", {})
        spec = doc.get("spec", {})

        self.kind: str = doc.get("kind", "")
        self.name: str = meta.get("name", "")
        self.description: str = meta.get("description", "")
        self.tags: list[str] = meta.get("tags", []) or []
        self.annotations: dict[str, str] = meta.get("annotations", {}) or {}
        self.links: list[dict[str, str]] = meta.get("links", []) or []

        self.spec_type: str = spec.get("type", "")
        self.lifecycle: str = spec.get("lifecycle", "")
        self.system: str = spec.get("system", "")
        self.owner: str = spec.get("owner", "")
        self.depends_on: list[str] = spec.get("dependsOn", []) or []
        self.provides_apis: list[str] = spec.get("providesApis", []) or []
        self.consumes_apis: list[str] = spec.get("consumesApis", []) or []

    def port(self) -> int | None:
        """Extract port from the first link URL, if any."""
        for link in self.links:
            url = link.get("url", "")
            if url:
                parsed = urlparse(url)
                if parsed.port:
                    return parsed.port
        return None

    def techdocs_dir(self) -> str | None:
        """Extract directory from backstage.io/techdocs-ref annotation."""
        ref = self.annotations.get("backstage.io/techdocs-ref", "")
        if ref.startswith("dir:"):
            return ref[4:].rstrip("/")
        return None

    def dependency_refs(self) -> list[tuple[str, str]]:
        """Parse dependsOn into (kind, name) tuples.

        E.g. "component:service-data" -> ("component", "service-data")
             "resource:infra-postgres" -> ("resource", "infra-postgres")
        """
        refs = []
        for dep in self.depends_on:
            if ":" in dep:
                kind, name = dep.split(":", 1)
                refs.append((kind, name))
        return refs

    # ── dx/ annotation helpers ──────────────────────────────────

    def role(self) -> str | None:
        """Return dx/role annotation value, or None."""
        return self.annotations.get("dx/role") or None

    def surface_links(self) -> list[dict[str, str]]:
        """Return links visible as surfaces (all minus dx/hidden-links)."""
        hidden_raw = self.annotations.get("dx/hidden-links", "")
        if not hidden_raw:
            return list(self.links)
        hidden = {t.strip() for t in hidden_raw.split(",") if t.strip()}
        return [link for link in self.links if link.get("title", "") not in hidden]

    def health_path(self, port: int | None = None) -> str:
        """Return the health-check path from dx/health-path, default '/'."""
        return self.annotations.get("dx/health-path", "/")

    def extra_surfaces(self) -> list[tuple[int, str, str]]:
        """Parse dx/extra-surfaces → [(container_port, url_path, label), ...].

        Format: ``<port>:<path>|<label>`` entries, semicolon-separated.
        Example: ``"8005:/docs|API Docs"``
        """
        raw = self.annotations.get("dx/extra-surfaces", "")
        if not raw:
            return []
        results: list[tuple[int, str, str]] = []
        for entry in raw.split(";"):
            entry = entry.strip()
            if not entry:
                continue
            path_part, _, label = entry.partition("|")
            port_str, _, path = path_part.partition(":")
            if port_str.isdigit():
                results.append((int(port_str), path or "/", label.strip()))
        return results

    def connection_info(self) -> tuple[str, str, int] | None:
        """Parse dx/connection-string → (label, template, container_port).

        Uses dx/connection-label for the label (falls back to entity name).
        Uses dx/connection-port to select the port for multi-link entities
        (falls back to first link port).
        """
        raw = self.annotations.get("dx/connection-string", "")
        if not raw:
            return None
        label = self.annotations.get("dx/connection-label", self.name)
        port_override = self.annotations.get("dx/connection-port", "")
        if port_override.isdigit():
            return (label, raw, int(port_override))
        first = self.port()
        return (label, raw, first or 0)

    def all_link_ports(self) -> list[tuple[int, str]]:
        """Return (port, title) for every link."""
        results: list[tuple[int, str]] = []
        for link in self.links:
            parsed = urlparse(link.get("url", ""))
            if parsed.port:
                results.append((parsed.port, link.get("title", "")))
        return results

    def __repr__(self) -> str:
        return f"CatalogEntity({self.kind}:{self.name})"


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------


VALID_SYSTEMS = {"apps", "services", "infra"}


class BackstageCatalog:
    """Parsed representation of a Backstage catalog.yaml file."""

    def __init__(self, entities: list[CatalogEntity]) -> None:
        self.entities = entities
        self.domains: dict[str, CatalogEntity] = {}
        self.systems: dict[str, CatalogEntity] = {}
        self.components: dict[str, CatalogEntity] = {}
        self.resources: dict[str, CatalogEntity] = {}
        self.apis: dict[str, CatalogEntity] = {}

        for e in entities:
            bucket = {
                "Domain": self.domains,
                "System": self.systems,
                "Component": self.components,
                "Resource": self.resources,
                "API": self.apis,
            }.get(e.kind)
            if bucket is not None:
                bucket[e.name] = e

    @classmethod
    def from_file(cls, path: Path) -> BackstageCatalog:
        """Parse a multi-document catalog.yaml file."""
        text = path.read_text()
        docs = list(yaml.safe_load_all(text))
        entities = [CatalogEntity(doc) for doc in docs if doc]
        return cls(entities)

    def deployable_components(self) -> dict[str, CatalogEntity]:
        """Return components that should have compose services (non-library)."""
        return {
            name: e for name, e in self.components.items() if e.spec_type != "library"
        }

    def all_named(self) -> dict[str, CatalogEntity]:
        """Return all components + resources by name."""
        merged: dict[str, CatalogEntity] = {}
        merged.update(self.components)
        merged.update(self.resources)
        return merged

    # ── dx/ annotation lookups ────────────────────────────────

    def find_by_role(self, role: str) -> CatalogEntity | None:
        """Find the first entity whose dx/role matches *role*."""
        for e in self.entities:
            if e.role() == role:
                return e
        return None

    def surface_entities(self) -> list[CatalogEntity]:
        """Return infra entities that should appear in the Key URLs table.

        Includes:
        - Components in system "infra" with surface links
        - Resources in system "infra" with type != "database" that have surface links
        """
        results: list[CatalogEntity] = []
        for e in self.entities:
            if e.system != "infra":
                continue
            if e.kind == "Resource" and e.spec_type == "database":
                continue
            if e.kind not in ("Component", "Resource"):
                continue
            if e.surface_links():
                results.append(e)
        return results

    def connection_entities(self) -> list[CatalogEntity]:
        """Return entities that declare a dx/connection-string."""
        return [e for e in self.entities if e.annotations.get("dx/connection-string")]
