"""Allow running as `python -m dx`."""

from dx.cli import main

main()
