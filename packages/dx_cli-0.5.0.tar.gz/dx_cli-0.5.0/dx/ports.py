"""Port allocation and persistence.

Auto-assigns free host ports to compose services and persists assignments.
"""

from __future__ import annotations

import json
import socket
import sys
from pathlib import Path
from typing import Any

from dx.output import info, warn, error, success, table, header

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_PORT_RETRIES = 100


# ---------------------------------------------------------------------------
# Port allocation
# ---------------------------------------------------------------------------


def is_port_free(port: int) -> bool:
    """Check if a port is available to bind."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", port))
        sock.close()
        return True
    except OSError:
        return False


def allocate_port(reserved: set[int]) -> int:
    """Allocate a single free port by binding to :0, avoiding reserved ports."""
    for _ in range(MAX_PORT_RETRIES):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()
        if port not in reserved:
            return port
    raise RuntimeError("Failed to allocate a free port after retries")


# ---------------------------------------------------------------------------
# Persistent port reservations
# ---------------------------------------------------------------------------


class PortManager:
    """Manages persistent port reservations for compose services."""

    def __init__(self, state_dir: Path) -> None:
        self.state_dir = state_dir
        self.reservations_file = state_dir / "ports.json"

    def _read(self) -> dict[str, dict]:
        """Read reservations: {service_name: {"port": int, "pinned": bool}}."""
        if not self.reservations_file.exists():
            return {}
        try:
            return json.loads(self.reservations_file.read_text())
        except (json.JSONDecodeError, OSError):
            return {}

    def _write(self, data: dict[str, dict]) -> None:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.reservations_file.write_text(json.dumps(data, indent=2) + "\n")

    def resolve(self, service_names: list[str]) -> dict[str, int]:
        """Resolve ports for services. Reuses persistent assignments when possible."""
        reservations = self._read()
        all_reserved = {r["port"] for r in reservations.values()}
        result: dict[str, int] = {}

        for name in service_names:
            existing = reservations.get(name)

            if existing and existing.get("pinned"):
                port = existing["port"]
                if not is_port_free(port):
                    error(f"Pinned port {port} for {name} is in use by another process")
                    sys.exit(1)
                result[name] = port
            elif existing and is_port_free(existing["port"]):
                result[name] = existing["port"]
            else:
                port = allocate_port(all_reserved)
                result[name] = port
                all_reserved.add(port)
                reservations[name] = {"port": port, "pinned": False}

            if name not in reservations:
                reservations[name] = {"port": result[name], "pinned": False}

        self._write(reservations)
        return result

    def pin(self, service: str, port: int) -> None:
        """Pin a service to a specific port."""
        reservations = self._read()
        for k, v in reservations.items():
            if v["port"] == port and k != service:
                error(f"Port {port} is already reserved by {k}")
                sys.exit(1)
        reservations[service] = {"port": port, "pinned": True}
        self._write(reservations)
        success(f"Pinned {service} -> :{port}")

    def clear(self, service: str | None = None) -> None:
        """Clear reservations."""
        if service:
            reservations = self._read()
            if service in reservations:
                del reservations[service]
                self._write(reservations)
                success(f"Cleared reservation for {service}")
            else:
                warn(f"No reservation found for {service}")
        else:
            self._write({})
            success("Cleared all port reservations")

    def status(self, catalog: Any = None) -> None:
        """Print all port reservations, optionally grouped by compose group."""
        reservations = self._read()
        if not reservations:
            info("No port reservations.")
            return

        header("Port Reservations")
        rows = []
        for name, data in sorted(reservations.items()):
            pinned = " (pinned)" if data.get("pinned") else ""
            group = ""
            if catalog:
                g = catalog.service_to_group.get(name, "")
                if g:
                    group = g
            rows.append([name, str(data["port"]), group, pinned])
        if catalog:
            table(rows, headers=["Service", "Port", "Group", "Status"])
        else:
            table(
                [[r[0], r[1], r[3]] for r in rows],
                headers=["Service", "Port", "Status"],
            )

    def write_env_file(self, ports: dict[str, int], env_path: Path) -> None:
        """Write port assignments as VAR=<port> to an env file.

        If the key already looks like an env var (uppercase with _PORT suffix),
        use it directly. Otherwise, convert from service-name to SERVICE_NAME_PORT.
        """
        env_path.parent.mkdir(parents=True, exist_ok=True)
        lines = []
        for name, port in sorted(ports.items()):
            if name == name.upper() and "_" in name:
                # Already an env var name (e.g. CLICKSTACK_APP_8080_PORT)
                var = name
            else:
                var = name.upper().replace("-", "_") + "_PORT"
            lines.append(f"{var}={port}")
        env_path.write_text("\n".join(lines) + "\n")
