"""Command implementations for the dx CLI.

Project-agnostic: uses ComposeCatalog for service discovery and
auto-detects service types from the filesystem.
"""

from __future__ import annotations

import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request, urlopen

from dx.catalog import BackstageCatalog
from dx.compose import ComposeCatalog, ServiceInfo, port_env_var
from dx.output import info, warn, error, success, header, dim, table, bold
from dx.ports import PortManager


def _load_backstage(catalog: ComposeCatalog) -> BackstageCatalog | None:
    """Load the Backstage catalog from catalog.yaml, or None."""
    path = catalog.root / "catalog.yaml"
    if not path.exists():
        return None
    try:
        return BackstageCatalog.from_file(path)
    except Exception:
        return None


def _has_compose_service(catalog: ComposeCatalog, entity_name: str) -> bool:
    """Check if a catalog entity has a matching compose service.

    Handles multi-container entities (e.g. infra-clickstack maps to
    infra-clickstack-app, infra-clickstack-otel, etc.).
    """
    if catalog.has_service(entity_name):
        return True
    prefix = entity_name + "-"
    return any(svc.startswith(prefix) for svc in catalog.all_services)


def _compose_service_for_entity(
    catalog: ComposeCatalog, entity_name: str, container_port: int
) -> str:
    """Find the compose service name that exposes *container_port* for a catalog entity.

    For single-container entities (e.g. infra-gateway) returns the entity name.
    For multi-container entities (e.g. infra-clickstack → infra-clickstack-app)
    searches sub-services for the one exposing the requested port.
    """
    # Direct match
    if entity_name in catalog._port_mappings:
        return entity_name
    # Search sub-services
    prefix = entity_name + "-"
    for svc in catalog.all_services:
        if not svc.startswith(prefix):
            continue
        for _, cp in catalog._port_mappings.get(svc, []):
            if int(cp) == container_port:
                return svc
    # Fallback: first sub-service
    for svc in catalog.all_services:
        if svc.startswith(prefix):
            return svc
    return entity_name


def _run(
    cmd: list[str],
    cwd: str | Path | None = None,
    check: bool = True,
    env: dict[str, str] | None = None,
) -> int:
    """Run a command, forwarding output to the terminal."""
    run_env = None
    if env:
        run_env = {**os.environ, **env}
    try:
        result = subprocess.run(cmd, cwd=cwd, env=run_env)
        if check and result.returncode != 0:
            error(
                f"Command failed (exit {result.returncode}): {' '.join(str(c) for c in cmd[:4])}..."
            )
            sys.exit(result.returncode)
        return result.returncode
    except FileNotFoundError:
        error(f"Command not found: {cmd[0]}")
        sys.exit(1)
    except KeyboardInterrupt:
        return 130


def _exec(cmd: list[str], cwd: str | Path | None = None) -> None:
    """Replace the current process with a command (for long-running commands like logs)."""
    if cwd:
        os.chdir(cwd)
    os.execvp(cmd[0], cmd)


# ---------------------------------------------------------------------------
# Docker lifecycle commands
# ---------------------------------------------------------------------------


def _ensure_nginx_conf(root: Path) -> None:
    """Generate nginx.conf from template if it doesn't exist."""
    conf = root / "infra" / "nginx" / "nginx.conf"
    tpl = root / "infra" / "nginx" / "nginx.conf.tpl"
    if conf.exists() or not tpl.exists():
        return
    api_key = os.environ.get("CLICKSTACK_API_KEY", "placeholder")
    content = tpl.read_text().replace("__CLICKSTACK_API_KEY__", api_key)
    conf.write_text(content)


def _service_in_targets(entity_name: str, targeted: list[str]) -> bool:
    """Check if a catalog entity (possibly multi-container) overlaps with targeted services."""
    if entity_name in targeted:
        return True
    prefix = entity_name + "-"
    return any(svc.startswith(prefix) for svc in targeted)


def _post_up(
    catalog: ComposeCatalog,
    targeted: list[str],
    dev: bool = False,
    port_env: dict[str, str] | None = None,
) -> None:
    """Run post-startup hooks only for services that were actually started."""
    backstage = _load_backstage(catalog)

    # Init observability only if it was part of what we started
    if backstage:
        obs = backstage.find_by_role("observability")
        if obs and _service_in_targets(obs.name, targeted):
            _run_init_clickstack(catalog.root, quiet=True, catalog=catalog)

    # Restart gateway only if it was part of what we started
    if backstage:
        gw = backstage.find_by_role("gateway")
        if gw and gw.name in targeted:
            file_args = catalog.all_compose_file_args(dev=dev)
            restart_cmd = ["docker", "compose"] + file_args + ["restart", gw.name]
            _run(restart_cmd, cwd=catalog.root, check=False, env=port_env)


def _extract_port_var(host_expr: str, service_name: str) -> tuple[str, str | None]:
    """Extract the env var name and default from a port host expression.

    Returns (env_var_name, default_port).
    "${AUTH_SERVICE_PORT:-8180}" -> ("AUTH_SERVICE_PORT", "8180")
    "${SERVICE_DATA_PORT:-8084}" -> ("SERVICE_DATA_PORT", "8084")
    "8084" (hardcoded) -> ("SERVICE_DATA_PORT", None)  (generated from service name)
    """
    m = re.match(r"^\$\{([^:}]+)(?::-([\d]+))?\}$", host_expr)
    if m:
        return m.group(1), m.group(2)
    # Hardcoded port — generate env var name from convention
    return port_env_var(service_name), None


def _all_ports_env(catalog: ComposeCatalog) -> dict[str, str]:
    """Allocate ports for ALL services with port mappings, not just the targeted ones.

    This is needed because compose files reference each other (services -> infra)
    and all env vars must be resolved even for services not being started.

    Respects existing env var names in compose files (e.g. AUTH_SERVICE_PORT).
    Handles services with multiple port mappings (e.g. infra services).
    """
    all_services_with_ports = [
        s for s in catalog.all_services if s in catalog._port_mappings
    ]
    if not all_services_with_ports:
        return {}

    state_dir = catalog.root / ".dx"
    pm = PortManager(state_dir)

    # Build a flat list of (env_var_name, service_name, default_port) for all port mappings
    port_entries: list[tuple[str, str, str | None]] = []
    for svc_name in all_services_with_ports:
        port_list = catalog._port_mappings.get(svc_name, [])
        if not port_list:
            continue
        if len(port_list) == 1:
            # Single port — use the service name as the reservation key
            host_expr = port_list[0][0]
            var_name, default = _extract_port_var(host_expr, svc_name)
            port_entries.append((var_name, svc_name, default))
        else:
            # Multiple ports — use the env var name as the reservation key
            for host_expr, container_port in port_list:
                var_name, default = _extract_port_var(host_expr, svc_name)
                # For hardcoded multi-port services, disambiguate with container port
                if default is None:
                    var_name = (
                        f"{svc_name.upper().replace('-', '_')}_{container_port}_PORT"
                    )
                    default = host_expr if host_expr.isdigit() else None
                port_entries.append((var_name, var_name, default))

    # Resolve ports: single-port services use service name, multi-port use var name
    resolve_keys = list(dict.fromkeys(entry[1] for entry in port_entries))
    port_assignments = pm.resolve(resolve_keys)

    env_vars: dict[str, str] = {}
    for var_name, resolve_key, _ in port_entries:
        if resolve_key in port_assignments:
            env_vars[var_name] = str(port_assignments[resolve_key])

    pm.write_env_file(port_assignments, state_dir / ".env")
    return env_vars


def _print_service_ports(
    services: list[str], port_env: dict[str, str], catalog: ComposeCatalog
) -> None:
    """Print port assignments for a set of targeted services."""
    for svc_name in services:
        port_list = catalog._port_mappings.get(svc_name, [])
        if not port_list:
            continue
        for host_expr, container_port in port_list:
            var_name, _ = _extract_port_var(host_expr, svc_name)
            port = port_env.get(var_name)
            if port:
                info(f"  {svc_name} -> :{port}")
                break  # Only show first port per service in summary


def cmd_up(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Start services in prod mode."""
    follow_logs = "--logs" in targets
    targets = [t for t in targets if t != "--logs"]

    services = catalog.resolve(targets)
    _ensure_nginx_conf(catalog.root)

    # Allocate ports for all services (compose needs all vars resolved)
    port_env = _all_ports_env(catalog)

    # Print assigned ports for targeted services
    _print_service_ports(services, port_env, catalog)

    cmd = catalog.compose_cmd(services, "up", "-d", "--build")
    _run(cmd, cwd=catalog.root, env=port_env)
    _post_up(catalog, services, dev=False, port_env=port_env)

    if follow_logs:
        logs_cmd = catalog.compose_cmd(services, "logs", "-f")
        _exec(logs_cmd, cwd=catalog.root)


def cmd_dev(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Start services in dev mode with hot-reload overlays."""
    follow_logs = "--logs" in targets
    targets = [t for t in targets if t != "--logs"]

    services = catalog.resolve(targets)
    _ensure_nginx_conf(catalog.root)

    port_env = _all_ports_env(catalog)

    _print_service_ports(services, port_env, catalog)

    cmd = catalog.compose_cmd(services, "up", "-d", "--build", dev=True)
    _run(cmd, cwd=catalog.root, env=port_env)
    _post_up(catalog, services, dev=True, port_env=port_env)

    if follow_logs:
        logs_cmd = catalog.compose_cmd(services, "logs", "-f")
        _exec(logs_cmd, cwd=catalog.root)


def cmd_down(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Stop and remove containers."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "down")
    _run(cmd, cwd=catalog.root)


def cmd_reset(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Stop containers and wipe volumes."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "down", "-v", "--remove-orphans")
    _run(cmd, cwd=catalog.root)


def cmd_restart(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Restart containers."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "restart")
    _run(cmd, cwd=catalog.root)


def cmd_logs(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Stream container logs (replaces current process)."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "logs", "-f")
    _exec(cmd, cwd=catalog.root)


def cmd_exec(catalog: ComposeCatalog, args: list[str]) -> None:
    """Execute a command inside a running container.

    Usage: dx exec [--it] <service> [command...]
    The --it flag allocates a pseudo-TTY and keeps stdin open (interactive mode).
    """
    interactive = False
    filtered: list[str] = []
    for a in args:
        if a in ("--it", "-it"):
            interactive = True
        else:
            filtered.append(a)

    if not filtered:
        error("Usage: dx exec [--it] <service> [command...]")
        sys.exit(1)

    service = catalog.resolve([filtered[0]])[0]
    run_cmd = filtered[1:] if len(filtered) > 1 else ["sh"]

    file_args = catalog.all_compose_file_args()
    cmd = ["docker", "compose"] + file_args + ["exec"]
    if interactive:
        cmd += ["-it"]
    cmd += [service] + run_cmd
    _exec(cmd, cwd=catalog.root)


def cmd_sh(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Open an interactive shell in a running container.

    Tries bash first, falls back to sh.
    Usage: dx sh <service>
    """
    if not targets:
        error("Usage: dx sh <service>")
        sys.exit(1)

    service = catalog.resolve([targets[0]])[0]
    file_args = catalog.all_compose_file_args()

    # Try bash first, fall back to sh
    bash_cmd = ["docker", "compose"] + file_args + ["exec", "-it", service, "bash"]
    rc = _run(bash_cmd, cwd=catalog.root, check=False)
    if rc != 0:
        info("bash not available, falling back to sh...")
        sh_cmd = ["docker", "compose"] + file_args + ["exec", "-it", service, "sh"]
        _exec(sh_cmd, cwd=catalog.root)


def cmd_inspect(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Show detailed container information via docker inspect.

    Usage: dx inspect <service> [--format <go-template>]
    """
    fmt = None
    filtered: list[str] = []
    i = 0
    while i < len(targets):
        if targets[i] in ("--format", "-f") and i + 1 < len(targets):
            fmt = targets[i + 1]
            i += 2
        else:
            filtered.append(targets[i])
            i += 1

    if not filtered:
        error("Usage: dx inspect <service> [--format <go-template>]")
        sys.exit(1)

    services = catalog.resolve(filtered)
    file_args = catalog.all_compose_file_args()

    # Get compose container names via `docker compose ps -q`
    for svc in services:
        ps_cmd = ["docker", "compose"] + file_args + ["ps", "-q", svc]
        result = subprocess.run(
            ps_cmd, cwd=catalog.root, capture_output=True, text=True
        )
        container_ids = result.stdout.strip().splitlines()
        if not container_ids:
            warn(f"No running container found for {svc}")
            continue
        inspect_cmd = ["docker", "inspect"]
        if fmt:
            inspect_cmd += ["--format", fmt]
        inspect_cmd += container_ids
        _run(inspect_cmd, cwd=catalog.root)


def cmd_ps(catalog: ComposeCatalog) -> None:
    """Show running containers."""
    cmd = ["docker", "compose"] + catalog.all_compose_file_args() + ["ps"]
    _run(cmd, cwd=catalog.root)


def cmd_pull(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Pull images."""
    services = catalog.resolve(targets)
    cmd = catalog.compose_cmd(services, "pull")
    _run(cmd, cwd=catalog.root)


def cmd_reload(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Recompile a service inside its dev container.

    For Java: runs mvn compile inside the container.
    """
    if not targets:
        error("Usage: dx reload <service>")
        sys.exit(1)

    service = catalog.resolve(targets)[0]
    si = catalog.service_info.get(service)

    if si and si.service_type == "java":
        cmd = (
            ["docker", "compose"]
            + catalog.all_compose_file_args(dev=True)
            + [
                "exec",
                service,
                "mvn",
                "compile",
                "-pl",
                "server",
                "-am",
                "-B",
                "-s",
                "/root/.m2/settings.xml",
            ]
        )
    else:
        # Generic: just restart the container
        warn(f"No reload strategy for {service} — restarting container instead")
        cmd = (
            ["docker", "compose"]
            + catalog.all_compose_file_args(dev=True)
            + [
                "restart",
                service,
            ]
        )

    _run(cmd, cwd=catalog.root)


# ---------------------------------------------------------------------------
# Build / Test / Lint (auto-detected)
# ---------------------------------------------------------------------------


def _find_common_java(root: Path) -> Path | None:
    """Find common Java libs directory if it exists."""
    candidate = root / "common" / "java"
    if candidate.is_dir() and (candidate / "pom.xml").exists():
        return candidate
    return None


def cmd_build(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Build services locally."""
    if not targets:
        targets = ["all"]

    for target in targets:
        if target == "all":
            info("Building all services...")
            common = _find_common_java(catalog.root)
            if common:
                info("Building common Java libs...")
                _run(["mvn", "install", "-DskipTests"], cwd=common)
            for si in catalog.service_info.values():
                if si.service_type and si.service_type != "python":
                    _build_service(si)
            continue

        if target == "common":
            common = _find_common_java(catalog.root)
            if common:
                info("Building common Java libs...")
                _run(["mvn", "install", "-DskipTests"], cwd=common)
            else:
                warn("No common/java directory found")
            continue

        # Resolve and build individual targets
        resolved = catalog.resolve([target])
        for svc_name in resolved:
            si = catalog.service_info.get(svc_name)
            if si and si.service_type:
                _build_service(si)
            elif si:
                warn(f"Skipping {svc_name}: could not detect service type")
            else:
                warn(f"Unknown target: {svc_name}")


def _build_service(si: ServiceInfo) -> None:
    if not si.directory or not si.directory.exists():
        warn(f"Skipping {si.name}: directory not found")
        return

    info(f"Building {si.name} ({si.service_type})...")
    if si.service_type == "java":
        _run(["mvn", "clean", "install", "-DskipTests", "-B"], cwd=si.directory)
    elif si.service_type == "node":
        _run(["pnpm", "install", "--frozen-lockfile"], cwd=si.directory)
        _run(["pnpm", "build"], cwd=si.directory)
    elif si.service_type == "python":
        warn(f"Skipping {si.name}: Python services have no build step")


def cmd_test(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Run tests for services inside Docker containers."""
    if not targets:
        targets = ["all"]

    port_env = _all_ports_env(catalog)

    for target in targets:
        if target == "all":
            info("Running all tests...")
            for si in catalog.service_info.values():
                if si.service_type:
                    _test_service(catalog, si, port_env)
            continue

        # Type-based targets: "python", "java", "node"
        if target in ("python", "java", "node"):
            for si in catalog.services_of_type(target):
                _test_service(catalog, si, port_env)
            continue

        resolved = catalog.resolve([target])
        for svc_name in resolved:
            si = catalog.service_info.get(svc_name)
            if si and si.service_type:
                _test_service(catalog, si, port_env)
            else:
                warn(f"Cannot test {svc_name}: no directory or type detected")


def _test_service(
    catalog: ComposeCatalog, si: ServiceInfo, port_env: dict[str, str]
) -> None:
    if not si.directory or not si.directory.exists():
        warn(f"Skipping {si.name}: directory not found")
        return

    info(f"Testing {si.name} ({si.service_type})...")

    if si.service_type == "java":
        # Run mvn test inside the dev container (has Maven + GCP auth + shared libs)
        file_args = catalog.compose_file_args([si.name], dev=True)
        cmd = (
            ["docker", "compose"]
            + file_args
            + [
                "run",
                "--rm",
                "--build",
                si.name,
                "mvn",
                "test",
                "-B",
                "-s",
                "/root/.m2/settings.xml",
            ]
        )
        _run(cmd, cwd=catalog.root, env=port_env)

    elif si.service_type == "python":
        # Run pytest inside the container (has GDAL, all pip deps).
        # Install test extras (pytest, httpx) before running.
        file_args = catalog.compose_file_args([si.name], dev=True)
        test_script = "pip install -q pytest httpx && python -m pytest"
        cmd = (
            ["docker", "compose"]
            + file_args
            + [
                "run",
                "--rm",
                "--build",
                si.name,
                "sh",
                "-c",
                test_script,
            ]
        )
        _run(cmd, cwd=catalog.root, env=port_env)

    elif si.service_type == "node":
        _run(["pnpm", "test", "--run"], cwd=si.directory)


def cmd_lint(catalog: ComposeCatalog, targets: list[str]) -> None:
    """Run linters."""
    if not targets:
        info("Running all linters...")
        _run(["pre-commit", "run", "--all-files"], cwd=catalog.root, check=False)
        return

    for target in targets:
        if target == "all":
            _run(["pre-commit", "run", "--all-files"], cwd=catalog.root, check=False)

        elif target == "python":
            info("Linting Python services...")
            python_dirs = [
                si.relative_dir
                for si in catalog.services_of_type("python")
                if si.directory and si.directory.exists()
            ]
            if python_dirs:
                _run(["ruff", "check"] + python_dirs, cwd=catalog.root, check=False)
                _run(
                    ["ruff", "format", "--check"] + python_dirs,
                    cwd=catalog.root,
                    check=False,
                )
            else:
                warn("No Python services found")

        elif target in ("frontend", "node"):
            info("Linting Node services...")
            for si in catalog.services_of_type("node"):
                if si.directory and si.directory.exists():
                    _run(["pnpm", "lint"], cwd=si.directory, check=False)

        else:
            resolved = catalog.resolve([target])
            for svc_name in resolved:
                si = catalog.service_info.get(svc_name)
                if si and si.service_type == "node" and si.directory:
                    _run(["pnpm", "lint"], cwd=si.directory, check=False)
                elif si and si.service_type == "python" and si.directory:
                    _run(
                        ["ruff", "check", si.relative_dir],
                        cwd=catalog.root,
                        check=False,
                    )
                    _run(
                        ["ruff", "format", "--check", si.relative_dir],
                        cwd=catalog.root,
                        check=False,
                    )
                else:
                    warn(f"No linter configured for: {svc_name}")


# ---------------------------------------------------------------------------
# Init (ClickStack / HyperDX) — only runs if project uses it
# ---------------------------------------------------------------------------

HDX_DEFAULT_PORT = 8000
HDX_EMAIL = "admin@lepton.local"
HDX_PASSWORD = "L3pt0n!Obs3rv3#2025"


def _http_request(
    url: str, method: str = "GET", data: dict | None = None, cookies: dict | None = None
) -> tuple[int, str, dict]:
    """Make an HTTP request using urllib. Returns (status, body, response_cookies)."""
    body = json.dumps(data).encode() if data else None
    headers = {"Content-Type": "application/json"} if data else {}
    if cookies:
        headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in cookies.items())

    req = Request(url, data=body, headers=headers, method=method)
    try:
        resp = urlopen(req, timeout=10)
        resp_body = resp.read().decode()
        resp_cookies = {}
        for header_val in resp.headers.get_all("Set-Cookie") or []:
            parts = header_val.split(";")[0].split("=", 1)
            if len(parts) == 2:
                resp_cookies[parts[0].strip()] = parts[1].strip()
        return resp.status, resp_body, resp_cookies
    except URLError as e:
        if hasattr(e, "code"):
            return e.code, getattr(e, "read", lambda: b"")(), {}
        raise


def _run_init_clickstack(
    root: Path, quiet: bool = False, catalog: "ComposeCatalog | None" = None
) -> None:
    """Initialize ClickStack/HyperDX — register user, get API key, update config."""
    # Resolve the actual allocated API port
    api_port = HDX_DEFAULT_PORT
    if catalog:
        api_port = _resolve_port(catalog, "infra-clickstack-app", 8000)
    hdx_api = f"http://localhost:{api_port}"

    if not quiet:
        info(f"Waiting for ClickStack API at {hdx_api}...")

    max_attempts = 30
    for attempt in range(max_attempts):
        try:
            status, _, _ = _http_request(f"{hdx_api}/health")
            if status == 200:
                if attempt > 0:
                    sys.stderr.write(" ready\n")
                    sys.stderr.flush()
                break
        except Exception:
            pass
        if attempt == 0 and not quiet:
            sys.stderr.write("  Waiting for ClickStack")
            sys.stderr.flush()
        elif not quiet:
            sys.stderr.write(".")
            sys.stderr.flush()
        time.sleep(2)
    else:
        if not quiet:
            sys.stderr.write(" timed out\n")
            sys.stderr.flush()
            warn("ClickStack API did not become ready — skipping init")
        return

    if not quiet:
        info("ClickStack API is ready.")

    try:
        status, body, _ = _http_request(f"{hdx_api}/installation")
        is_existing = '"isTeamExisting":true' in body
    except Exception:
        if not quiet:
            warn("Could not check ClickStack installation status")
        return

    cookies: dict = {}
    if not is_existing:
        if not quiet:
            info(f"Registering initial user ({HDX_EMAIL})...")
        try:
            status, _, cookies = _http_request(
                f"{hdx_api}/register/password",
                "POST",
                {
                    "email": HDX_EMAIL,
                    "password": HDX_PASSWORD,
                    "confirmPassword": HDX_PASSWORD,
                },
            )
            if status != 200:
                if not quiet:
                    warn(f"Registration returned HTTP {status}")
                return
        except Exception as e:
            if not quiet:
                warn(f"Registration failed: {e}")
            return
    else:
        if not quiet:
            info("Team exists — logging in...")
        try:
            status, _, cookies = _http_request(
                f"{hdx_api}/login/password",
                "POST",
                {"email": HDX_EMAIL, "password": HDX_PASSWORD},
            )
            if not (200 <= status < 400):
                if not quiet:
                    warn(f"Login returned HTTP {status}")
                return
        except Exception as e:
            if not quiet:
                warn(f"Login failed: {e}")
            return

    try:
        status, body, _ = _http_request(f"{hdx_api}/team", cookies=cookies)
        match = re.search(r'"apiKey":"([^"]+)"', body)
        if not match:
            if not quiet:
                warn("Could not extract API key from team response")
            return
        api_key = match.group(1)
    except Exception as e:
        if not quiet:
            warn(f"Failed to fetch team info: {e}")
        return

    if not quiet:
        info(f"Ingestion key: {api_key}")

    env_file = root / ".env"
    if env_file.exists():
        content = env_file.read_text()
        if "CLICKSTACK_API_KEY=" in content:
            content = re.sub(
                r"^CLICKSTACK_API_KEY=.*$",
                f"CLICKSTACK_API_KEY={api_key}",
                content,
                flags=re.MULTILINE,
            )
        else:
            content += f"\nCLICKSTACK_API_KEY={api_key}\n"
        env_file.write_text(content)
    else:
        env_file.write_text(f"CLICKSTACK_API_KEY={api_key}\n")

    tpl = root / "infra" / "nginx" / "nginx.conf.tpl"
    out = root / "infra" / "nginx" / "nginx.conf"
    if tpl.exists():
        out.write_text(tpl.read_text().replace("__CLICKSTACK_API_KEY__", api_key))

    if not quiet:
        ui_port = HDX_DEFAULT_PORT  # fallback
        if catalog:
            ui_port = _resolve_port(catalog, "infra-clickstack-app", 8080)
        success(f"ClickStack initialized — dashboard at http://localhost:{ui_port}")


def cmd_init(catalog: ComposeCatalog) -> None:
    """Run ClickStack initialization."""
    backstage = _load_backstage(catalog)
    if not backstage:
        warn("No catalog.yaml found")
        return

    obs = backstage.find_by_role("observability")
    if not obs:
        warn("No observability service (dx/role: observability) found in catalog")
        return

    _run_init_clickstack(catalog.root, quiet=False, catalog=catalog)

    gw = backstage.find_by_role("gateway")
    if gw and catalog.has_service(gw.name):
        restart_cmd = (
            ["docker", "compose"]
            + catalog.all_compose_file_args()
            + ["restart", gw.name]
        )
        _run(restart_cmd, cwd=catalog.root, check=False)


# ---------------------------------------------------------------------------
# List / Validate / Vite
# ---------------------------------------------------------------------------


def cmd_list(catalog: ComposeCatalog, targets: list[str]) -> None:
    """List all services by group."""
    groups_to_show = targets if targets else list(catalog.groups.keys())
    for group in groups_to_show:
        services = catalog.groups.get(group)
        if services is None:
            canonical = catalog._aliases.get(group)
            if canonical:
                services = catalog.groups.get(canonical)
                group = canonical
        if services is None:
            warn(f"Unknown group: {group}")
            continue
        header(group)
        for svc in services:
            si = catalog.service_info.get(svc)
            svc_dir = si.relative_dir if si else ""
            svc_type = f"[{si.service_type}]" if si and si.service_type else ""
            print(f"  {svc:<35s} {dim(svc_dir):<35s} {dim(svc_type)}")


def cmd_validate(catalog: ComposeCatalog) -> None:
    """Run harness validation."""
    script = catalog.root / "scripts" / "validate-harness.sh"
    if script.exists():
        _run(["bash", str(script)], cwd=catalog.root)
    else:
        error("scripts/validate-harness.sh not found")
        sys.exit(1)


def _vite_state_dir(catalog: ComposeCatalog) -> Path:
    return catalog.root / ".dx" / "vite"


def _vite_resolve_app(catalog: ComposeCatalog, name: str | None) -> ServiceInfo:
    """Resolve a target name to a node app ServiceInfo."""
    node_apps = [si for si in catalog.services_of_type("node") if si.group == "apps"]
    if not node_apps:
        error("No Node.js apps found in this project")
        sys.exit(1)

    if not name:
        if len(node_apps) == 1:
            return node_apps[0]
        names = ", ".join(si.name for si in node_apps)
        error(f"Multiple apps available — specify one: {names}")
        sys.exit(1)

    # Try resolve via catalog (supports aliases, globs, etc.)
    resolved = catalog.resolve([name])
    for r in resolved:
        for si in node_apps:
            if si.name == r:
                return si

    names = ", ".join(si.name for si in node_apps)
    error(f"Unknown app: {name}. Available: {names}")
    sys.exit(1)


def _vite_is_running(pid_file: Path) -> int | None:
    """Return PID if process is alive, else clean up stale PID file."""
    if not pid_file.exists():
        return None
    try:
        pid = int(pid_file.read_text().strip())
        os.kill(pid, 0)
        return pid
    except (OSError, ValueError):
        pid_file.unlink(missing_ok=True)
        return None


def _kill_process_tree(pid: int) -> None:
    """Kill a process and its children (process group)."""
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except (OSError, ProcessLookupError):
        # Fallback: kill just the process
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass


def cmd_vite(catalog: ComposeCatalog, args: list[str]) -> None:
    """Manage vite dev servers as background daemons.

    Usage:
      dx vite start <app> [--logs] [--port <port>]
      dx vite stop [<app>]
      dx vite restart <app> [--logs] [--port <port>]
      dx vite logs <app>
      dx vite ps
    """
    if not args:
        error("Usage: dx vite start|stop|restart|logs|ps [<app>] [--logs] [--port <port>]")
        sys.exit(1)

    action = args[0]
    rest = args[1:]

    if action == "start":
        _vite_start(catalog, rest)
    elif action == "stop":
        _vite_stop(catalog, rest)
    elif action == "restart":
        _vite_restart(catalog, rest)
    elif action == "logs":
        _vite_logs(catalog, rest)
    elif action == "ps":
        _vite_ps(catalog)
    else:
        error(f"Unknown vite action: {action}")
        error("Usage: dx vite start|stop|restart|logs|ps [<app>] [--logs] [--port <port>]")
        sys.exit(1)


def _vite_start(catalog: ComposeCatalog, args: list[str]) -> None:
    """Start a vite dev server for an app."""
    follow_logs = "--logs" in args
    args = [a for a in args if a != "--logs"]

    # Parse --port flag
    explicit_port: int | None = None
    filtered: list[str] = []
    i = 0
    while i < len(args):
        if args[i] == "--port" and i + 1 < len(args):
            try:
                explicit_port = int(args[i + 1])
            except ValueError:
                error("--port value must be a number")
                sys.exit(1)
            i += 2
        else:
            filtered.append(args[i])
            i += 1

    app_name = filtered[0] if filtered else None
    si = _vite_resolve_app(catalog, app_name)

    vite_dir = _vite_state_dir(catalog)
    vite_dir.mkdir(parents=True, exist_ok=True)

    slug = si.name
    pid_file = vite_dir / f"{slug}.pid"
    log_file = vite_dir / f"{slug}.log"
    port_file = vite_dir / f"{slug}.port"

    existing_pid = _vite_is_running(pid_file)
    if existing_pid:
        port = port_file.read_text().strip() if port_file.exists() else "?"
        info(f"{slug} already running (PID {existing_pid}, port {port})")
        if follow_logs:
            _exec(["tail", "-f", str(log_file)])
        return

    # Allocate port
    if explicit_port:
        port = explicit_port
    else:
        pm = PortManager(catalog.root / ".dx")
        vite_key = f"vite-{slug}"
        assigned = pm.resolve([vite_key])
        port = assigned[vite_key]

    # Build environment: inherit current env + all allocated port vars
    port_env = _all_ports_env(catalog)
    proc_env = {**os.environ, **port_env, "PORT": str(port)}

    log_fh = open(log_file, "w")
    proc = subprocess.Popen(
        ["pnpm", "dev", "--port", str(port)],
        cwd=si.directory,
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        start_new_session=True,
        env=proc_env,
    )
    pid_file.write_text(str(proc.pid))
    port_file.write_text(str(port))
    success(f"{slug} started on :{port} (PID {proc.pid})")
    info(f"  logs: dx vite logs {slug}")

    if follow_logs:
        _exec(["tail", "-f", str(log_file)])


def _vite_stop(catalog: ComposeCatalog, args: list[str]) -> None:
    """Stop vite dev server(s)."""
    vite_dir = _vite_state_dir(catalog)
    if not vite_dir.exists():
        warn("No vite servers running")
        return

    if not args:
        # Stop all
        pid_files = list(vite_dir.glob("*.pid"))
        if not pid_files:
            warn("No vite servers running")
            return
        for pf in pid_files:
            slug = pf.stem
            pid = _vite_is_running(pf)
            if pid:
                _kill_process_tree(pid)
                success(f"Stopped {slug} (PID {pid})")
            pf.unlink(missing_ok=True)
            (vite_dir / f"{slug}.port").unlink(missing_ok=True)
        return

    app_name = args[0]
    si = _vite_resolve_app(catalog, app_name)
    slug = si.name
    pid_file = vite_dir / f"{slug}.pid"
    port_file = vite_dir / f"{slug}.port"

    pid = _vite_is_running(pid_file)
    if not pid:
        warn(f"{slug} is not running")
        return
    _kill_process_tree(pid)
    pid_file.unlink(missing_ok=True)
    port_file.unlink(missing_ok=True)
    success(f"Stopped {slug} (PID {pid})")


def _vite_restart(catalog: ComposeCatalog, args: list[str]) -> None:
    """Restart a vite dev server (stop then start)."""
    # Extract app name (without consuming flags) so we can stop the right server
    clean = [a for a in args if not a.startswith("--")]
    if not clean:
        error("Usage: dx vite restart <app> [--logs] [--port <port>]")
        sys.exit(1)

    app_name = clean[0]
    si = _vite_resolve_app(catalog, app_name)
    slug = si.name

    vite_dir = _vite_state_dir(catalog)
    pid_file = vite_dir / f"{slug}.pid"
    port_file = vite_dir / f"{slug}.port"

    pid = _vite_is_running(pid_file)
    if pid:
        _kill_process_tree(pid)
        pid_file.unlink(missing_ok=True)
        port_file.unlink(missing_ok=True)
        info(f"Stopped {slug} (PID {pid})")

    _vite_start(catalog, args)


def _vite_logs(catalog: ComposeCatalog, args: list[str]) -> None:
    """Tail logs for a vite dev server."""
    if not args:
        error("Usage: dx vite logs <app>")
        sys.exit(1)

    app_name = args[0]
    si = _vite_resolve_app(catalog, app_name)
    slug = si.name
    log_file = _vite_state_dir(catalog) / f"{slug}.log"

    if not log_file.exists():
        warn(f"No log file found for {slug}. Is it running?")
        return
    _exec(["tail", "-f", str(log_file)])


def _vite_ps(catalog: ComposeCatalog) -> None:
    """List running vite dev servers."""
    vite_dir = _vite_state_dir(catalog)
    if not vite_dir.exists():
        info("No vite servers running")
        return

    pid_files = sorted(vite_dir.glob("*.pid"))
    if not pid_files:
        info("No vite servers running")
        return

    rows = []
    for pf in pid_files:
        slug = pf.stem
        pid = _vite_is_running(pf)
        port_file = vite_dir / f"{slug}.port"
        port = port_file.read_text().strip() if port_file.exists() else "?"
        status = bold(f"running (PID {pid})") if pid else dim("stopped")
        rows.append([slug, f":{port}", status])

    header("Vite Dev Servers")
    table(rows, headers=["App", "Port", "Status"])


# ---------------------------------------------------------------------------
# Port commands
# ---------------------------------------------------------------------------


def cmd_ports(catalog: ComposeCatalog, args: list[str]) -> None:
    """Port management commands."""
    state_dir = catalog.root / ".dx"
    pm = PortManager(state_dir)

    if not args:
        pm.status(catalog)
        return

    action = args[0]
    if action == "pin":
        if len(args) != 3:
            error("Usage: dx ports pin <service> <port>")
            sys.exit(1)
        try:
            port = int(args[2])
        except ValueError:
            error("Port must be a number")
            sys.exit(1)
        pm.pin(args[1], port)

    elif action == "reset":
        service = args[1] if len(args) > 1 else None
        pm.clear(service)

    else:
        error(f"Unknown ports action: {action}")
        error("Usage: dx ports [pin <service> <port> | reset [service]]")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------


def _resolve_port(
    catalog: ComposeCatalog, service_name: str, container_port: int
) -> int:
    """Get the allocated host port for a service's container port.

    For single-port services the reservation key is the service name.
    For multi-port services the key is the env-var name (e.g. CUBE_SQL_PORT).
    Falls back to the compose-declared default host port if nothing is allocated.
    """
    state_dir = catalog.root / ".dx"
    pm = PortManager(state_dir)
    reservations = pm._read()

    port_list = catalog._port_mappings.get(service_name, [])
    if len(port_list) <= 1:
        # Single-port service — key is service name
        entry = reservations.get(service_name)
        if entry:
            return entry["port"]
        # Fallback: default host port from compose (e.g. 9000 from ${VAR:-9000}:80)
        if port_list:
            _, default = _extract_port_var(port_list[0][0], service_name)
            if default:
                return int(default)
    else:
        # Multi-port service — find the mapping whose container port matches
        for host_expr, cp in port_list:
            if int(cp) != container_port:
                continue
            var_name, default = _extract_port_var(host_expr, service_name)
            # For hardcoded multi-port, the key is the generated var name
            if default is None:
                var_name = f"{service_name.upper().replace('-', '_')}_{cp}_PORT"
            entry = reservations.get(var_name)
            if entry:
                return entry["port"]
            # Fallback: compose-declared default
            if default:
                return int(default)
            break

    return container_port


def _check_health(port: int, path: str = "/", timeout: float = 2) -> bool:
    """Quick HTTP health check against localhost."""
    try:
        req = Request(f"http://localhost:{port}{path}", method="GET")
        resp = urlopen(req, timeout=timeout)
        return 200 <= resp.status < 400
    except Exception:
        return False


def _running_services(catalog: ComposeCatalog) -> set[str]:
    """Get names of currently running compose services."""
    file_args = catalog.all_compose_file_args()
    try:
        result = subprocess.run(
            ["docker", "compose"] + file_args + ["ps", "--format", "{{.Service}}"],
            cwd=catalog.root,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return {s.strip() for s in result.stdout.strip().splitlines() if s.strip()}
    except Exception:
        pass
    return set()


def cmd_status(catalog: ComposeCatalog) -> None:
    """Show instance status: running services, key URLs, and health."""
    backstage = _load_backstage(catalog)
    running = _running_services(catalog)

    # --- Running services summary ---
    header("Running Services")
    if not running:
        warn("No services running. Start with: dx up")
    else:
        for group_name in ("infra", "services", "apps"):
            group_svcs = catalog.groups.get(group_name, [])
            running_in_group = [s for s in group_svcs if s in running]
            stopped_in_group = [s for s in group_svcs if s not in running]
            if running_in_group or stopped_in_group:
                total = len(running_in_group) + len(stopped_in_group)
                info(f"{group_name}: {len(running_in_group)}/{total} running")

    # --- Key URLs (catalog-driven) ---
    header("Key URLs")
    rows: list[list[str]] = []
    if backstage:
        for entity in backstage.surface_entities():
            visible_links = entity.surface_links()
            is_multi = len(visible_links) > 1

            for link in visible_links:
                from urllib.parse import urlparse as _urlparse

                parsed = _urlparse(link.get("url", ""))
                container_port = parsed.port or 80
                link_title = link.get("title", "")
                label = (
                    f"{entity.description} — {link_title}"
                    if is_multi and link_title
                    else entity.description
                )

                compose_svc = _compose_service_for_entity(
                    catalog, entity.name, container_port
                )
                port = _resolve_port(catalog, compose_svc, container_port)
                url_path = parsed.path or "/"
                health = entity.health_path(container_port)

                is_running = compose_svc in running
                if is_running:
                    healthy = _check_health(port, health)
                    status = bold("UP") if healthy else dim("starting")
                else:
                    status = dim("stopped")

                url = (
                    f"http://localhost:{port}{url_path}"
                    if url_path != "/"
                    else f"http://localhost:{port}"
                )
                rows.append([label, url, status])

            # Extra surfaces (e.g. gateway → /docs)
            for extra_port, extra_path, extra_label in entity.extra_surfaces():
                compose_svc = _compose_service_for_entity(
                    catalog, entity.name, extra_port
                )
                port = _resolve_port(catalog, compose_svc, extra_port)
                is_running = compose_svc in running
                if is_running:
                    healthy = _check_health(port, extra_path)
                    status = bold("UP") if healthy else dim("starting")
                else:
                    status = dim("stopped")
                rows.append(
                    [extra_label, f"http://localhost:{port}{extra_path}", status]
                )

    if rows:
        table(rows, headers=["Surface", "URL", "Status"])
    else:
        info("No services configured")

    # --- Apps / Frontends ---
    app_rows: list[list[str]] = []

    # 1) Docker compose apps (from the "apps" group)
    for svc_name in catalog.groups.get("apps", []):
        port_list = catalog._port_mappings.get(svc_name, [])
        if not port_list:
            is_running = svc_name in running
            status = bold("UP") if is_running else dim("stopped")
            app_rows.append(
                [svc_name, "compose", "(via proxy)", status, "dx logs " + svc_name]
            )
            continue
        container_port = int(port_list[0][1])
        port = _resolve_port(catalog, svc_name, container_port)
        is_running = svc_name in running
        if is_running:
            healthy = _check_health(port, "/")
            status = bold("UP") if healthy else dim("starting")
        else:
            status = dim("stopped")
        app_rows.append(
            [
                svc_name,
                "compose",
                f"http://localhost:{port}",
                status,
                "dx logs " + svc_name,
            ]
        )

    # 2) Vite dev servers (from .dx/vite/)
    vite_dir = _vite_state_dir(catalog)
    if vite_dir.exists():
        for pf in sorted(vite_dir.glob("*.pid")):
            slug = pf.stem
            pid = _vite_is_running(pf)
            port_file = vite_dir / f"{slug}.port"
            port_str = port_file.read_text().strip() if port_file.exists() else None
            if pid and port_str:
                healthy = _check_health(int(port_str), "/")
                status = bold("UP") if healthy else dim("starting")
                url = f"http://localhost:{port_str}"
            elif pid:
                status = dim("starting")
                url = "?"
            else:
                status = dim("stopped")
                url = f"http://localhost:{port_str}" if port_str else "?"
            app_rows.append(
                [
                    slug,
                    "vite",
                    url,
                    status,
                    "dx vite logs " + slug,
                ]
            )

    if app_rows:
        header("Apps & Frontends")
        table(app_rows, headers=["App", "Mode", "URL", "Status", "Logs"])

    # --- Service API endpoints (catalog-driven) ---
    if backstage and backstage.apis:
        gw = backstage.find_by_role("gateway")
        gateway_port = (
            _resolve_port(catalog, gw.name, gw.port() or 8005) if gw else 8005
        )

        header("API Endpoints (via gateway)")
        api_rows: list[list[str]] = []
        for api_name, api_entity in sorted(backstage.apis.items()):
            path = f"/api/v1/{api_name.replace('-api', '')}"
            # Try to get actual path from API definition
            try:
                import yaml as _yaml

                defn_str = api_entity.annotations.get("spec_definition", "")
                # The definition is stored in spec.definition but CatalogEntity
                # doesn't capture it directly — re-read from raw YAML.
                catalog_path = catalog.root / "catalog.yaml"
                text = catalog_path.read_text()
                for doc in _yaml.safe_load_all(text):
                    if not doc:
                        continue
                    if (
                        doc.get("kind") == "API"
                        and doc.get("metadata", {}).get("name") == api_name
                    ):
                        defn_str = doc.get("spec", {}).get("definition", "")
                        if defn_str:
                            defn = _yaml.safe_load(defn_str)
                            servers = defn.get("servers", [])
                            if servers:
                                from urllib.parse import urlparse

                                parsed = urlparse(servers[0].get("url", ""))
                                if parsed.path and parsed.path != "/":
                                    path = parsed.path.rstrip("/")
                        break
            except Exception:
                pass

            url = f"http://localhost:{gateway_port}{path}"
            api_rows.append([api_name, url])

        table(api_rows, headers=["API", "Endpoint"])

    # --- Database connections (catalog-driven) ---
    if backstage:
        db_rows: list[list[str]] = []
        for entity in backstage.connection_entities():
            conn = entity.connection_info()
            if not conn:
                continue
            label, template, container_port = conn
            compose_svc = _compose_service_for_entity(
                catalog, entity.name, container_port
            )
            port = _resolve_port(catalog, compose_svc, container_port)
            conn_str = template.replace("{port}", str(port))
            db_rows.append([label, conn_str])

        if db_rows:
            header("Database Connections")
            table(db_rows, headers=["Database", "Connection String"])
