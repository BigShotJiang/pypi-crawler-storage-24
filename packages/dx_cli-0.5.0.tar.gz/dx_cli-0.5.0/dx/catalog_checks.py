"""Catalog validation checks — catalog.yaml vs compose files vs filesystem.

Each check function takes a BackstageCatalog and ComposeCatalog, returning
a list of Issues (reusing doctor.py's Issue class).

Auto-fixes treat catalog.yaml as the source of truth and update compose
files and .env to match.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from urllib.parse import urlparse

import yaml

from dx.catalog import BackstageCatalog, CatalogEntity, VALID_SYSTEMS
from dx.compose import (
    COMPOSE_FILES,
    DEV_OVERLAYS,
    ComposeCatalog,
    port_env_var,
)
from dx.doctor import Issue
from dx.output import error, header, info, success, warn, table


# ---------------------------------------------------------------------------
# Tag -> service type mapping
# ---------------------------------------------------------------------------

TAG_TO_TYPE: dict[str, str] = {
    "java": "java",
    "spring-boot": "java",
    "python": "python",
    "fastapi": "python",
    "react": "node",
    "typescript": "node",
    "nextjs": "node",
}

# Compose services that are sub-components of a single catalog Resource.
COMPOSE_SUB_SERVICES: dict[str, str] = {
    "infra-clickstack-": "infra-clickstack",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _compose_name_for_catalog_entity(name: str) -> str | None:
    """Map a catalog entity name to its expected compose service name."""
    return name


def _is_sub_service(compose_name: str) -> str | None:
    """Check if a compose service is a sub-service of a catalog resource."""
    for prefix, resource in COMPOSE_SUB_SERVICES.items():
        if compose_name.startswith(prefix):
            return resource
    return None


def _all_compose_files(root: Path) -> list[Path]:
    """Return all existing compose file paths."""
    all_filenames = set(COMPOSE_FILES.values()) | set(DEV_OVERLAYS.values())
    return [root / f for f in all_filenames if (root / f).exists()]


def _compose_file_for_group(root: Path, group: str) -> Path | None:
    """Return the compose file path for a group."""
    filename = COMPOSE_FILES.get(group)
    if filename:
        path = root / filename
        return path if path.exists() else None
    return None


def _extract_host_port(host_expr: str) -> int | None:
    """Extract the default port from a host port expression."""
    if host_expr.isdigit():
        return int(host_expr)
    m = re.search(r":-(\d+)", host_expr)
    if m:
        return int(m.group(1))
    return None


def _dep_condition(dep_ref: str) -> str:
    """Determine the depends_on condition from a catalog dependency ref.

    resource:* -> service_healthy (infra services have healthchecks)
    component:* -> service_started
    """
    if dep_ref.startswith("resource:"):
        return "service_healthy"
    return "service_started"


# ---------------------------------------------------------------------------
# Fix functions
# ---------------------------------------------------------------------------


def _fix_rename_compose_service(root: Path, old_name: str, new_name: str) -> bool:
    """Rename a compose service across all compose files."""
    changed_files: list[Path] = []
    for path in _all_compose_files(root):
        content = path.read_text()
        new_content = re.sub(
            rf"^(  ){re.escape(old_name)}(:)",
            rf"\g<1>{new_name}\2",
            content,
            flags=re.MULTILINE,
        )
        new_content = re.sub(
            rf"\b{re.escape(old_name)}\b",
            new_name,
            new_content,
        )
        if new_content != content:
            path.write_text(new_content)
            changed_files.append(path)

    if changed_files:
        files_str = ", ".join(f.name for f in changed_files)
        success(f"Renamed '{old_name}' -> '{new_name}' in {files_str}")
        return True
    return False


def _fix_compose_port_default(
    root: Path, service_name: str, old_default: int, new_default: int
) -> bool:
    """Update the default value in a ${VAR:-default} port expression."""
    changed = False
    for path in _all_compose_files(root):
        content = path.read_text()
        # Match ${VAR:-old_default}:container_port
        new_content = re.sub(
            rf"(\$\{{[A-Z_]+):-{old_default}(\}}:\d+)",
            rf"\g<1>:-{new_default}\2",
            content,
        )
        # Also match hardcoded old_default:container_port
        new_content = re.sub(
            rf'"{old_default}:(\d+)"',
            rf'"{new_default}:\1"',
            new_content,
        )
        if new_content != content:
            path.write_text(new_content)
            success(
                f"  Updated port default {old_default} -> {new_default} in {path.name}"
            )
            changed = True
    return changed


def _fix_add_compose_depends_on(
    root: Path,
    service_name: str,
    group: str,
    dep_name: str,
    condition: str,
) -> bool:
    """Add a depends_on entry to a compose service."""
    path = _compose_file_for_group(root, group)
    if not path:
        return False

    content = path.read_text()
    lines = content.split("\n")
    new_lines: list[str] = []

    in_service = False
    in_depends_on = False
    added = False
    i = 0

    while i < len(lines):
        line = lines[i]

        # Detect target service
        if re.match(rf"^  {re.escape(service_name)}:\s*(?:#.*)?$", line):
            in_service = True
            in_depends_on = False
        elif in_service and re.match(r"^  [a-zA-Z0-9]", line):
            # Next service — if we were in-service but never found depends_on, inject one
            if not added:
                new_lines.append("    depends_on:")
                new_lines.append(f"      {dep_name}:")
                new_lines.append(f"        condition: {condition}")
                added = True
            in_service = False
            in_depends_on = False

        # Detect depends_on block within target service
        if in_service and re.match(r"^    depends_on:\s*$", line):
            in_depends_on = True

        # Find end of depends_on block and insert new entry
        if in_depends_on and not added:
            # Scan ahead for end of depends_on block
            next_i = i + 1
            while next_i < len(lines):
                next_line = lines[next_i]
                if not next_line.strip() or re.match(r"^\s{6,}", next_line):
                    next_i += 1
                    continue
                break

            # End of block found: either next property, next service, or EOF
            is_end = next_i >= len(lines) or (
                re.match(r"^    [a-z]", lines[next_i])
                or re.match(r"^  [a-zA-Z0-9]", lines[next_i])
            )
            if is_end:
                # Add all lines up to insertion point
                for j in range(i, next_i):
                    new_lines.append(lines[j])
                new_lines.append(f"      {dep_name}:")
                new_lines.append(f"        condition: {condition}")
                added = True
                i = next_i
                continue

        new_lines.append(line)
        i += 1

    # Handle case where depends_on is at the very end of the file
    if in_service and not added:
        if in_depends_on:
            new_lines.append(f"      {dep_name}:")
            new_lines.append(f"        condition: {condition}")
        else:
            new_lines.append("    depends_on:")
            new_lines.append(f"      {dep_name}:")
            new_lines.append(f"        condition: {condition}")
        added = True

    if added:
        path.write_text("\n".join(new_lines))
        success(
            f"  Added depends_on '{dep_name}' ({condition}) to {service_name} in {path.name}"
        )
        return True
    return False


# ---------------------------------------------------------------------------
# Check 1: Catalog -> Compose coverage
# ---------------------------------------------------------------------------


def _find_rename_candidate(
    catalog_name: str, compose_services: list[str], catalog_names: set[str]
) -> str | None:
    """Find a compose service that's likely a rename of a catalog component.

    Matches when one name is a substring of the other and the compose service
    has no catalog entry of its own.
    """
    for svc in compose_services:
        if svc in catalog_names:
            continue  # Already matched
        # One is substring of the other
        if catalog_name in svc or svc in catalog_name:
            return svc
    return None


def _check_catalog_to_compose(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Every deployable Component and Resource should have a compose service."""
    issues: list[Issue] = []
    all_catalog_names = set(backstage.components) | set(backstage.resources)

    for name, entity in backstage.deployable_components().items():
        compose_name = _compose_name_for_catalog_entity(name)
        if compose_name and not compose.has_service(compose_name):
            # Try to find a rename candidate
            candidate = _find_rename_candidate(
                name, compose.all_services, all_catalog_names
            )
            if candidate:
                issues.append(
                    Issue(
                        "error",
                        name,
                        f"catalog name '{name}' doesn't match compose service '{candidate}' "
                        f"— rename compose service to match catalog",
                        fix_description=f"rename '{candidate}' -> '{name}' in compose files",
                        fix_fn=lambda root=compose.root, old=candidate, new=name: (
                            _fix_rename_compose_service(root, old, new)
                        ),
                    )
                )
            else:
                issues.append(
                    Issue(
                        "error",
                        name,
                        f"catalog Component has no compose service "
                        f"(expected '{compose_name}' in compose files)",
                    )
                )

    # Check resources
    for name, entity in backstage.resources.items():
        compose_name = _compose_name_for_catalog_entity(name)
        if compose_name and not compose.has_service(compose_name):
            has_sub = any(svc.startswith(f"{name}-") for svc in compose.all_services)
            if not has_sub:
                issues.append(
                    Issue(
                        "warning",
                        name,
                        "catalog Resource has no matching compose service or sub-services",
                    )
                )

    return issues


# ---------------------------------------------------------------------------
# Check 2: Compose -> Catalog coverage
# ---------------------------------------------------------------------------


def _check_compose_to_catalog(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Every compose service should have a catalog Component or Resource."""
    issues: list[Issue] = []
    all_catalog_names = set(backstage.components) | set(backstage.resources)

    # Build set of compose services that will be renamed by check 1 fixes
    # to avoid duplicate warnings
    rename_targets: set[str] = set()
    for name in backstage.deployable_components():
        if not compose.has_service(name):
            candidate = _find_rename_candidate(
                name, compose.all_services, all_catalog_names
            )
            if candidate:
                rename_targets.add(candidate)

    for svc_name in compose.all_services:
        if svc_name in all_catalog_names:
            continue
        if svc_name in rename_targets:
            continue  # Will be fixed by rename in check 1

        parent = _is_sub_service(svc_name)
        if parent and parent in all_catalog_names:
            continue

        issues.append(
            Issue(
                "warning",
                svc_name,
                "compose service has no catalog entry "
                "(add a Component or Resource to catalog.yaml)",
            )
        )

    return issues


# ---------------------------------------------------------------------------
# Check 3: Port consistency
# ---------------------------------------------------------------------------


def _check_port_consistency(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Catalog link URL ports should match compose host port mappings."""
    issues: list[Issue] = []

    for name, entity in {**backstage.components, **backstage.resources}.items():
        catalog_port = entity.port()
        if not catalog_port:
            continue

        compose_name = _compose_name_for_catalog_entity(name)
        if not compose_name or not compose.has_service(compose_name):
            continue

        raw_ports = compose._port_mappings.get(compose_name, [])
        if not raw_ports:
            continue

        host_ports = [_extract_host_port(h) for h, _ in raw_ports]
        host_ports = [p for p in host_ports if p is not None]

        if host_ports and catalog_port not in host_ports:
            old_port = host_ports[0]
            ports_str = ", ".join(str(p) for p in host_ports)
            issues.append(
                Issue(
                    "error",
                    name,
                    f"port mismatch — catalog link says {catalog_port}, "
                    f"compose host port(s): {ports_str}",
                    fix_description=f"update compose port default {old_port} -> {catalog_port}",
                    fix_fn=lambda root=compose.root,
                    svc=compose_name,
                    old=old_port,
                    new=catalog_port: (_fix_compose_port_default(root, svc, old, new)),
                )
            )

    return issues


# ---------------------------------------------------------------------------
# Check 4: Dependency alignment
# ---------------------------------------------------------------------------


def _check_dependency_alignment(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Catalog dependsOn should align with compose depends_on."""
    issues: list[Issue] = []

    for name, entity in backstage.deployable_components().items():
        compose_name = _compose_name_for_catalog_entity(name)
        if not compose_name or not compose.has_service(compose_name):
            continue

        compose_deps = set(compose.depends_on.get(compose_name, []))
        if not compose_deps and not entity.depends_on:
            continue

        catalog_dep_names: set[str] = set()
        catalog_dep_refs: dict[
            str, str
        ] = {}  # dep_name -> full ref (e.g. "resource:infra-postgres")
        for dep in entity.depends_on:
            if ":" in dep:
                _, dep_name = dep.split(":", 1)
                catalog_dep_names.add(dep_name)
                catalog_dep_refs[dep_name] = dep

        # Catalog deps not in compose — fixable
        si = compose.service_info.get(compose_name)
        group = si.group if si else "services"

        for dep_name in sorted(catalog_dep_names):
            if dep_name not in compose_deps:
                dep_entity = backstage.components.get(dep_name)
                if dep_entity and dep_entity.spec_type == "library":
                    continue

                dep_ref = catalog_dep_refs.get(dep_name, f"component:{dep_name}")
                condition = _dep_condition(dep_ref)

                issues.append(
                    Issue(
                        "warning",
                        name,
                        f"catalog depends on '{dep_name}' but compose does not",
                        fix_description=f"add depends_on '{dep_name}' ({condition}) to compose",
                        fix_fn=lambda root=compose.root,
                        svc=compose_name,
                        g=group,
                        dn=dep_name,
                        cond=condition: (
                            _fix_add_compose_depends_on(root, svc, g, dn, cond)
                        ),
                    )
                )

        # Compose deps not in catalog — info only, no fix
        for dep_name in sorted(compose_deps):
            if dep_name not in catalog_dep_names:
                issues.append(
                    Issue(
                        "info",
                        name,
                        f"compose depends on '{dep_name}' but catalog does not "
                        f"(consider adding to dependsOn)",
                    )
                )

    return issues


# ---------------------------------------------------------------------------
# Check 5: Tag <-> type consistency
# ---------------------------------------------------------------------------


def _check_tag_type_consistency(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Catalog tags should match the detected service type."""
    issues: list[Issue] = []

    for name, entity in backstage.deployable_components().items():
        compose_name = _compose_name_for_catalog_entity(name)
        if not compose_name:
            continue

        si = compose.service_info.get(compose_name)
        if not si or not si.service_type:
            continue

        tag_types = {TAG_TO_TYPE[t] for t in entity.tags if t in TAG_TO_TYPE}

        if not tag_types:
            issues.append(
                Issue(
                    "warning",
                    name,
                    f"no technology tags — detected type is '{si.service_type}', "
                    f"consider adding tags like '{si.service_type}'",
                )
            )
        elif si.service_type not in tag_types:
            issues.append(
                Issue(
                    "warning",
                    name,
                    f"tag/type mismatch — tags imply {tag_types}, "
                    f"but detected type is '{si.service_type}'",
                )
            )

    return issues


# ---------------------------------------------------------------------------
# Check 6: System <-> group consistency
# ---------------------------------------------------------------------------


def _check_system_group_consistency(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Catalog system must equal the compose file group (apps, services, infra)."""
    issues: list[Issue] = []

    for name, entity in {**backstage.components, **backstage.resources}.items():
        if not entity.system:
            continue

        if entity.system not in VALID_SYSTEMS:
            issues.append(
                Issue(
                    "error",
                    name,
                    f"invalid system '{entity.system}' — "
                    f"must be one of: {', '.join(sorted(VALID_SYSTEMS))}",
                )
            )
            continue

        if entity.spec_type == "library":
            continue

        compose_name = _compose_name_for_catalog_entity(name)
        if not compose_name or not compose.has_service(compose_name):
            continue

        si = compose.service_info.get(compose_name)
        if si and si.group != entity.system:
            issues.append(
                Issue(
                    "error",
                    name,
                    f"system/group mismatch — catalog system is '{entity.system}', "
                    f"but service is in compose group '{si.group}'",
                )
            )

    return issues


# ---------------------------------------------------------------------------
# Check 7: Lifecycle safety
# ---------------------------------------------------------------------------


def _check_lifecycle_safety(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Production components should not depend on experimental ones."""
    issues: list[Issue] = []
    all_entities = {**backstage.components, **backstage.resources}

    for name, entity in backstage.components.items():
        if entity.lifecycle != "production":
            continue

        for dep_kind, dep_name in entity.dependency_refs():
            dep = all_entities.get(dep_name)
            if dep and dep.lifecycle == "experimental":
                issues.append(
                    Issue(
                        "warning",
                        name,
                        f"production component depends on experimental "
                        f"'{dep_name}' — consider promoting or removing dependency",
                    )
                )

    return issues


# ---------------------------------------------------------------------------
# Check 8: API provider validation
# ---------------------------------------------------------------------------


def _check_api_providers(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Components claiming providesApis should reference existing API entities."""
    issues: list[Issue] = []

    for name, entity in backstage.components.items():
        for api_ref in entity.provides_apis:
            api_name = api_ref.split(":", 1)[-1] if ":" in api_ref else api_ref
            if api_name not in backstage.apis:
                issues.append(
                    Issue(
                        "error",
                        name,
                        f"provides API '{api_name}' which is not defined in catalog",
                    )
                )
                continue

            api_entity = backstage.apis[api_name]
            component_port = entity.port()
            api_port = api_entity.port()
            if component_port and api_port and component_port != api_port:
                issues.append(
                    Issue(
                        "warning",
                        name,
                        f"component port {component_port} != API '{api_name}' "
                        f"server port {api_port}",
                    )
                )

    return issues


# ---------------------------------------------------------------------------
# Check 9: Directory annotations
# ---------------------------------------------------------------------------


def _check_directory_annotations(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Verify that techdocs-ref directory annotations point to existing paths."""
    issues: list[Issue] = []

    for name, entity in {**backstage.components, **backstage.resources}.items():
        dir_ref = entity.techdocs_dir()
        if not dir_ref:
            continue

        full_path = compose.root / dir_ref
        if not full_path.exists():
            issues.append(
                Issue(
                    "warning",
                    name,
                    f"techdocs-ref directory does not exist: {dir_ref}",
                )
            )

    return issues


# ---------------------------------------------------------------------------
# All checks
# ---------------------------------------------------------------------------

ALL_CATALOG_CHECKS = [
    _check_catalog_to_compose,
    _check_compose_to_catalog,
    _check_port_consistency,
    _check_dependency_alignment,
    _check_tag_type_consistency,
    _check_system_group_consistency,
    _check_lifecycle_safety,
    _check_api_providers,
    _check_directory_annotations,
]


def run_catalog_checks(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> list[Issue]:
    """Run all catalog checks and return issues."""
    all_issues: list[Issue] = []
    for check_fn in ALL_CATALOG_CHECKS:
        all_issues.extend(check_fn(backstage, compose))
    return all_issues


# ---------------------------------------------------------------------------
# .env.example generation
# ---------------------------------------------------------------------------


def _generate_env_example(backstage: BackstageCatalog, compose: ComposeCatalog) -> str:
    """Generate .env.example content from catalog port definitions."""
    sections: list[str] = []
    sections.append(
        "# Generated from catalog.yaml — port assignments and service config"
    )
    sections.append("# Copy to .env and customize as needed.\n")

    for system_name, section_label in [
        ("infra", "Infrastructure"),
        ("services", "Services"),
        ("apps", "Apps"),
    ]:
        entities = [
            e
            for e in backstage.entities
            if e.system == system_name
            and e.kind in ("Component", "Resource")
            and e.port()
        ]
        if not entities:
            continue

        lines: list[str] = []
        lines.append(f"# --- {section_label} ports ---")
        for e in sorted(entities, key=lambda x: x.name):
            port = e.port()
            if port:
                var = port_env_var(e.name)
                lines.append(f"{var}={port}")
        lines.append("")
        sections.append("\n".join(lines))

    # Add non-port config from existing .env.example if present
    env_example_path = compose.root / ".env.example"
    if env_example_path.exists():
        existing = env_example_path.read_text()
        # Extract non-port lines (lines that don't end with _PORT=...)
        non_port_lines: list[str] = []
        in_port_section = False
        for line in existing.splitlines():
            if line.strip().startswith("# --- ") and "ports" in line.lower():
                in_port_section = True
                continue
            if in_port_section and (
                not line.strip() or line.strip().startswith("# ---")
            ):
                in_port_section = False
                if line.strip().startswith("# ---"):
                    continue
            if in_port_section:
                continue
            if re.match(r"^[A-Z_]+_PORT=", line):
                continue
            # Skip the old header if present
            if "Generated from catalog" in line or "Copy to .env" in line:
                continue
            non_port_lines.append(line)

        # Trim leading/trailing blank lines
        while non_port_lines and not non_port_lines[0].strip():
            non_port_lines.pop(0)
        while non_port_lines and not non_port_lines[-1].strip():
            non_port_lines.pop()

        if non_port_lines:
            sections.append("# --- Other config ---")
            sections.append("\n".join(non_port_lines))
            sections.append("")

    return "\n".join(sections) + "\n"


# ---------------------------------------------------------------------------
# Gateway config generation from catalog
# ---------------------------------------------------------------------------


def _extract_api_path_prefix(api_entity: CatalogEntity) -> str | None:
    """Extract the API path prefix from the API definition's server URL.

    E.g. definition contains 'url: http://localhost:8084/api/v1/data' -> '/api/v1/data'
    """
    # The definition is embedded YAML in the spec
    for entity in [api_entity]:
        # The definition is stored as a string in the 'definition' field
        # but we access it via the raw spec
        pass

    # Try to extract from links
    for link in api_entity.links:
        url = link.get("url", "")
        if url:
            parsed = urlparse(url)
            if parsed.path and parsed.path != "/":
                return parsed.path.rstrip("/")

    return None


def _build_gateway_config(
    backstage: BackstageCatalog,
    compose: ComposeCatalog,
) -> dict:
    """Build APISIX gateway config (upstreams + routes) from catalog.

    For each API entity:
      - Find the component that provides it (via providesApis)
      - Get the component's compose service name and internal container port
      - Extract the API path prefix from the API definition server URL
      - Generate an upstream and route
    """
    upstreams = []
    routes = []

    # Map API name -> providing component
    api_providers: dict[str, CatalogEntity] = {}
    for comp in backstage.components.values():
        for api_ref in comp.provides_apis:
            api_name = api_ref.split(":", 1)[-1] if ":" in api_ref else api_ref
            api_providers[api_name] = comp

    # Auth is special — it's a resource, not a component with providesApis
    # Add it if infra-auth exists in resources
    auth_resource = backstage.resources.get("infra-auth")

    if auth_resource:
        upstreams.append(
            {
                "id": "auth-service",
                "nodes": {"infra-auth:3000": 1},
            }
        )
        routes.append(
            {
                "id": "auth",
                "uri": "/api/v1/auth*",
                "upstream_id": "auth-service",
                "plugins": {
                    "opentelemetry": {"sampler": {"name": "always_on"}},
                    "proxy-rewrite": {
                        "headers": {
                            "set": {
                                "X-Real-IP": "$remote_addr",
                                "X-Forwarded-For": "$remote_addr",
                                "X-Forwarded-Proto": "$scheme",
                            }
                        }
                    },
                },
            }
        )

    # Process each catalog API
    for api_name, api_entity in sorted(backstage.apis.items()):
        provider = api_providers.get(api_name)
        if not provider:
            continue

        # Get the compose service's internal port
        compose_name = provider.name
        raw_ports = compose._port_mappings.get(compose_name, [])
        if not raw_ports:
            continue
        # Use the container port (second element)
        container_port = raw_ports[0][1]

        # Extract path prefix from API definition server URL
        # The definition field contains embedded YAML with servers[].url
        path_prefix = None
        # Search in API definition for server URL path
        # api_entity doesn't have the raw definition easily, so use convention:
        # API name pattern: <service-short>-api -> path /api/v1/<service-short>
        # Or extract from the definition string in catalog
        # Let's parse the definition from the raw catalog
        catalog_path = compose.root / "catalog.yaml"
        if catalog_path.exists():
            text = catalog_path.read_text()
            docs = list(yaml.safe_load_all(text))
            for doc in docs:
                if not doc:
                    continue
                if (
                    doc.get("kind") == "API"
                    and doc.get("metadata", {}).get("name") == api_name
                ):
                    definition_str = doc.get("spec", {}).get("definition", "")
                    if definition_str:
                        try:
                            defn = yaml.safe_load(definition_str)
                            servers = defn.get("servers", [])
                            if servers:
                                url = servers[0].get("url", "")
                                parsed = urlparse(url)
                                if parsed.path and parsed.path != "/":
                                    path_prefix = parsed.path.rstrip("/")
                        except Exception:
                            pass
                    break

        if not path_prefix:
            # Fallback: derive from API name (data-api -> /api/v1/data)
            short = api_name.replace("-api", "")
            path_prefix = f"/api/v1/{short}"

        # Upstream ID: use service short name
        upstream_id = api_name.replace("-api", "-service")

        upstreams.append(
            {
                "id": upstream_id,
                "nodes": {f"{compose_name}:{container_port}": 1},
            }
        )

        route: dict = {
            "id": api_name.replace("-api", ""),
            "uri": f"{path_prefix}*",
            "upstream_id": upstream_id,
            "plugins": {
                "opentelemetry": {"sampler": {"name": "always_on"}},
                "proxy-rewrite": {
                    "regex_uri": [
                        f"^{re.escape(path_prefix)}(.*)",
                        f"{path_prefix}$1",
                    ],
                    "headers": {
                        "set": {
                            "X-Real-IP": "$remote_addr",
                            "X-Forwarded-For": "$remote_addr",
                        }
                    },
                },
            },
        }

        # Add timeout annotation support
        timeout = provider.annotations.get("dx/gateway-timeout")
        if timeout:
            try:
                t = int(timeout)
                route["timeout"] = {"read": t, "send": t}
            except ValueError:
                pass

        routes.append(route)

    # Add static routes: api-docs and health
    if compose.has_service("infra-api-docs"):
        upstreams.append(
            {
                "id": "api-docs",
                "nodes": {"infra-api-docs:80": 1},
            }
        )
        routes.append(
            {
                "id": "docs-portal",
                "uri": "/docs",
                "upstream_id": "api-docs",
                "plugins": {
                    "proxy-rewrite": {"uri": "/"},
                },
            }
        )

    routes.append(
        {
            "id": "health",
            "uri": "/health",
            "plugins": {
                "response-rewrite": {
                    "status_code": 200,
                    "body": '{"status":"healthy"}',
                    "headers": {"set": {"Content-Type": "application/json"}},
                }
            },
        }
    )

    return {
        "upstreams": upstreams,
        "routes": routes,
    }


def _render_apisix_yaml(config: dict) -> str:
    """Render the APISIX declarative config as YAML."""
    lines = [
        "#",
        "# APISIX Declarative Routes — generated from catalog.yaml",
        "# Re-generate with: dx catalog gateway",
        "#",
        "",
    ]

    # Global rules (static — CORS + real-ip)
    global_rules = {
        "global_rules": [
            {
                "id": 1,
                "plugins": {
                    "cors": {
                        "allow_origins": "**",
                        "allow_methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
                        "allow_headers": "Authorization, Content-Type, X-Requested-With, X-CSRF-Token, Accept, Origin, Referer, User-Agent, Access-Control-Request-Method, Access-Control-Request-Headers",
                        "expose_headers": "Content-Length, Content-Type, X-Requested-With",
                        "allow_credential": True,
                        "max_age": 3600,
                    },
                    "real-ip": {
                        "source": "http_x_forwarded_for",
                    },
                },
            }
        ],
    }

    full = {}
    full["upstreams"] = config["upstreams"]
    full.update(global_rules)
    full["routes"] = config["routes"]

    yaml_str = yaml.dump(
        full, default_flow_style=False, sort_keys=False, allow_unicode=True
    )
    lines.append(yaml_str)
    lines.append("#END")

    return "\n".join(lines) + "\n"


def _cmd_catalog_gateway(
    backstage: BackstageCatalog, compose: ComposeCatalog, write: bool = False
) -> None:
    """Generate or validate APISIX gateway config from catalog."""
    header("dx catalog gateway")

    config = _build_gateway_config(backstage, compose)
    rendered = _render_apisix_yaml(config)

    apisix_path = compose.root / "infra" / "apisix" / "apisix.yaml"

    if write:
        apisix_path.write_text(rendered)
        success(f"Generated {apisix_path}")
        info(f"  {len(config['upstreams'])} upstreams, {len(config['routes'])} routes")
    else:
        # Diff mode — compare with existing
        if apisix_path.exists():
            existing = apisix_path.read_text()
            if existing.strip() == rendered.strip():
                success("Gateway config is up to date with catalog")
            else:
                warn("Gateway config differs from catalog")
                info("  Run 'dx catalog gateway --write' to regenerate")
                info(
                    f"  {len(config['upstreams'])} upstreams, {len(config['routes'])} routes from catalog"
                )
        else:
            warn(f"{apisix_path} does not exist")
            info("  Run 'dx catalog gateway --write' to generate")

        # Print what would be generated
        print()
        header("Routes from catalog")
        rows = []
        for route in config["routes"]:
            upstream = route.get("upstream_id", "(inline)")
            rows.append([route["id"], route["uri"], upstream])
        table(rows, headers=["Route ID", "URI", "Upstream"])


# ---------------------------------------------------------------------------
# CLI command
# ---------------------------------------------------------------------------


def cmd_catalog(compose_catalog: ComposeCatalog, args: list[str]) -> None:
    """Validate catalog.yaml against compose files and filesystem."""
    catalog_path = compose_catalog.root / "catalog.yaml"
    if not catalog_path.exists():
        error("catalog.yaml not found at repo root")
        sys.exit(1)

    backstage = BackstageCatalog.from_file(catalog_path)

    sub = args[0] if args else "check"
    fix = "--fix" in args

    if sub == "list":
        _cmd_catalog_list(backstage, compose_catalog)
    elif sub == "diff":
        _cmd_catalog_diff(backstage, compose_catalog)
    elif sub == "env":
        _cmd_catalog_env(backstage, compose_catalog)
    elif sub == "gateway":
        _cmd_catalog_gateway(backstage, compose_catalog, write="--write" in args)
    elif sub in ("check", "validate"):
        _cmd_catalog_check(backstage, compose_catalog, fix=fix)
    elif sub == "--fix":
        _cmd_catalog_check(backstage, compose_catalog, fix=True)
    else:
        error(f"Unknown catalog subcommand: {sub}")
        info("Usage: dx catalog [check|list|diff|env|gateway] [--fix|--write]")
        sys.exit(1)


def _cmd_catalog_check(
    backstage: BackstageCatalog, compose: ComposeCatalog, fix: bool = False
) -> None:
    """Run all catalog checks and report."""
    header("dx catalog check")
    info(f"Checking catalog.yaml against compose files at {compose.root}")
    info(
        f"Catalog: {len(backstage.components)} components, "
        f"{len(backstage.resources)} resources, {len(backstage.apis)} APIs"
    )
    print()

    issues = run_catalog_checks(backstage, compose)

    if not issues:
        success("All catalog checks passed — catalog matches reality")
        return

    errors = [i for i in issues if i.severity == "error"]
    warnings = [i for i in issues if i.severity == "warning"]
    infos = [i for i in issues if i.severity == "info"]

    if errors:
        header("Errors (must fix)")
        for issue in errors:
            print(issue)
    if warnings:
        header("Warnings")
        for issue in warnings:
            print(issue)
    if infos:
        header("Info")
        for issue in infos:
            print(issue)

    print()
    fixable = [i for i in issues if i.fix_fn]

    if fix and fixable:
        header("Applying fixes...")
        for issue in fixable:
            info(f"Fix: {issue.fix_description}")
            issue.fix_fn()
        print()
        success(
            f"Applied {len(fixable)} fix(es). Run 'dx catalog check' again to verify."
        )
    elif fixable:
        info(
            f"{len(fixable)} issue(s) can be auto-fixed. "
            f"Run 'dx catalog check --fix' to apply."
        )

    info(f"{len(errors)} error(s), {len(warnings)} warning(s), {len(infos)} info(s)")

    if errors and not fix:
        sys.exit(1)


def _cmd_catalog_list(backstage: BackstageCatalog, compose: ComposeCatalog) -> None:
    """List all catalog entities with their status."""
    header("Catalog entities")

    for system_name in ("apps", "services", "infra"):
        system_entities = [
            e
            for e in backstage.entities
            if e.system == system_name and e.kind in ("Component", "Resource")
        ]
        if not system_entities:
            continue

        header(f"  {system_name}")
        rows = []
        for e in sorted(system_entities, key=lambda x: x.name):
            has_compose = "✓" if compose.has_service(e.name) else "—"
            dir_ref = e.techdocs_dir() or ""
            has_dir = "✓" if dir_ref and (compose.root / dir_ref).exists() else "—"
            port = str(e.port() or "—")
            rows.append(
                [e.name, e.kind, e.spec_type, e.lifecycle, has_compose, has_dir, port]
            )

        table(
            rows,
            headers=["Name", "Kind", "Type", "Lifecycle", "Compose", "Dir", "Port"],
        )

    unassigned = [
        e
        for e in backstage.entities
        if e.system not in VALID_SYSTEMS and e.kind in ("Component", "Resource")
    ]
    if unassigned:
        header("  (no system)")
        for e in unassigned:
            info(f"  {e.name} ({e.kind}, system={e.system or '(none)'})")


def _cmd_catalog_diff(backstage: BackstageCatalog, compose: ComposeCatalog) -> None:
    """Show only mismatches between catalog and compose/filesystem."""
    header("dx catalog diff")

    issues = run_catalog_checks(backstage, compose)
    if not issues:
        success("No mismatches found")
        return

    for issue in issues:
        print(issue)

    print()
    info(f"{len(issues)} mismatch(es) found")


def _cmd_catalog_env(backstage: BackstageCatalog, compose: ComposeCatalog) -> None:
    """Generate .env.example from catalog."""
    header("dx catalog env")

    content = _generate_env_example(backstage, compose)
    env_example_path = compose.root / ".env.example"
    env_example_path.write_text(content)
    success(f"Generated {env_example_path}")

    # Validate .env against .env.example
    env_path = compose.root / ".env"
    if env_path.exists():
        env_text = env_path.read_text()
        env_vars = set()
        for line in env_text.splitlines():
            m = re.match(r"^([A-Z_]+)=", line)
            if m:
                env_vars.add(m.group(1))

        missing: list[str] = []
        for line in content.splitlines():
            m = re.match(r"^([A-Z_]+_PORT)=", line)
            if m and m.group(1) not in env_vars:
                missing.append(m.group(1))

        if missing:
            info(f"{len(missing)} port var(s) in .env.example not set in .env:")
            for var in missing:
                print(f"  {var}")
        else:
            success(".env has all port variables defined")
