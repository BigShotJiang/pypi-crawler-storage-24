"""dx doctor — lint and fix project structure and conventions.

Checks:
1. Compose service names follow convention: <group-prefix><dir-slug>
     services/data  -> service-data       (not "data-service", not "my-data")
     apps/web       -> app-web            (not "frontend-web")
2. Every non-infra service has a discoverable source directory
3. Source directories use consistent naming (no mismatched slugs)
4. No orphan directories (dirs in services/ or apps/ not referenced by compose)
5. Required files per service type (Dockerfile, pyproject.toml, pom.xml, etc.)
6. Java Dockerfiles list all modules from pom.xml
7. Python Dockerfiles expose the correct port

With --fix: rewrites compose files and Dockerfiles to fix issues.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from dx.compose import (
    COMPOSE_FILES,
    DEV_OVERLAYS,
    GROUP_PREFIXES,
    ComposeCatalog,
    is_hardcoded_port,
    make_port_env_expr,
)
from dx.output import info, success, header, bold


# ---------------------------------------------------------------------------
# Issue types
# ---------------------------------------------------------------------------


class Issue:
    """A naming/convention issue found by doctor."""

    def __init__(
        self,
        severity: str,
        service: str,
        message: str,
        fix_description: str | None = None,
        fix_fn: callable | None = None,
    ) -> None:
        self.severity = severity  # "error", "warning", "info"
        self.service = service
        self.message = message
        self.fix_description = fix_description
        self.fix_fn = fix_fn

    def __str__(self) -> str:
        icon = {"error": "✗", "warning": "!", "info": "·"}.get(self.severity, "?")
        return f"  {icon} {bold(self.service)}: {self.message}"


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------


def _check_naming_convention(catalog: ComposeCatalog) -> list[Issue]:
    """Check that compose service names follow <group-prefix><dir-slug> convention."""
    issues: list[Issue] = []

    for name, si in catalog.service_info.items():
        if si.group == "infra":
            continue  # infra services have varied naming, no strict convention

        expected = si.expected_name
        if not expected:
            continue  # No directory found, handled by another check

        if name != expected:
            compose_file = COMPOSE_FILES.get(si.group)
            issues.append(
                Issue(
                    "error",
                    name,
                    f"should be named '{expected}' (dir: {si.relative_dir})",
                    fix_description=f"rename '{name}' -> '{expected}' in {compose_file}",
                    fix_fn=lambda root=catalog.root,
                    old=name,
                    new=expected,
                    group=si.group: _fix_rename_service(root, old, new, group),
                )
            )

    return issues


def _check_missing_directories(catalog: ComposeCatalog) -> list[Issue]:
    """Check that non-infra services have discoverable source directories."""
    issues: list[Issue] = []

    for name, si in catalog.service_info.items():
        if si.group == "infra":
            continue
        if not si.directory:
            issues.append(
                Issue(
                    "warning",
                    name,
                    f"no source directory found (expected in {si.group.rstrip('s') + 's'}/)",
                )
            )

    return issues


def _check_orphan_directories(catalog: ComposeCatalog) -> list[Issue]:
    """Check for directories in services/ or apps/ not referenced by any compose service."""
    issues: list[Issue] = []
    referenced_dirs = {
        si.directory for si in catalog.service_info.values() if si.directory
    }

    for parent_name in ("services", "apps"):
        parent = catalog.root / parent_name
        if not parent.is_dir():
            continue
        for child in sorted(parent.iterdir()):
            if not child.is_dir() or child.name.startswith("."):
                continue
            if child not in referenced_dirs:
                group = "services" if parent_name == "services" else "apps"
                prefix = GROUP_PREFIXES.get(group, "")
                expected_name = f"{prefix}{child.name}"
                issues.append(
                    Issue(
                        "info",
                        child.name,
                        f"directory {parent_name}/{child.name}/ is not referenced by any compose service"
                        f" (expected compose service name: {expected_name})",
                    )
                )

    return issues


def _check_hardcoded_ports(catalog: ComposeCatalog) -> list[Issue]:
    """Check that compose port mappings use env vars instead of hardcoded host ports."""
    issues: list[Issue] = []

    for name, si in catalog.service_info.items():
        if not si.container_port:
            continue
        # Look up the raw port mappings from the catalog's parsed data
        ports = catalog._port_mappings.get(name, [])
        hardcoded = [(h, c) for h, c in ports if is_hardcoded_port(h)]
        for host_expr, container_port in hardcoded:
            # For multi-port services, disambiguate with a suffix
            if len(hardcoded) > 1:
                env_expr = _make_multi_port_env_expr(name, host_expr, container_port)
            else:
                env_expr = make_port_env_expr(name, host_expr)
            issues.append(
                Issue(
                    "warning",
                    name,
                    f"hardcoded host port {host_expr}:{container_port} "
                    f'(should use "{env_expr}:{container_port}" for portless mode)',
                    fix_description=f"rewrite port to {env_expr}:{container_port}",
                    fix_fn=lambda root=catalog.root,
                    svc=name,
                    old_host=host_expr,
                    cport=container_port,
                    expr=env_expr: _fix_hardcoded_port(
                        root, svc, old_host, cport, expr
                    ),
                )
            )

    return issues


def _make_multi_port_env_expr(
    service_name: str, default_port: str, container_port: str
) -> str:
    """Build env var expression for a multi-port service.

    Adds a suffix based on the container port to disambiguate.
    E.g. infra-clickstack-app port 8080 -> ${INFRA_CLICKSTACK_APP_8080_PORT:-8080}
         infra-clickstack-app port 8000 -> ${INFRA_CLICKSTACK_APP_8000_PORT:-8000}
    """
    base = service_name.upper().replace("-", "_")
    # Use container port as suffix
    var = f"{base}_{container_port}_PORT"
    return f"${{{var}:-{default_port}}}"


def _check_prefix_consistency(catalog: ComposeCatalog) -> list[Issue]:
    """Check that services use the correct group prefix."""
    issues: list[Issue] = []

    for name, si in catalog.service_info.items():
        if si.group == "infra":
            continue

        expected_prefix = GROUP_PREFIXES.get(si.group, "")
        if expected_prefix and not name.startswith(expected_prefix):
            # Check if it uses a wrong prefix
            wrong_prefix = None
            for group, prefix in GROUP_PREFIXES.items():
                if group != si.group and name.startswith(prefix):
                    wrong_prefix = prefix
                    break

            if wrong_prefix:
                issues.append(
                    Issue(
                        "error",
                        name,
                        f"uses prefix '{wrong_prefix}' but is in the '{si.group}' compose file "
                        f"(should use '{expected_prefix}')",
                    )
                )
            else:
                # Non-standard prefix (e.g. "frontend-" instead of "app-")
                issues.append(
                    Issue(
                        "warning",
                        name,
                        f"does not use the standard '{expected_prefix}' prefix for {si.group} group",
                    )
                )

    return issues


# ---------------------------------------------------------------------------
# File and Dockerfile checks
# ---------------------------------------------------------------------------

# Required files per service type
_REQUIRED_FILES: dict[str, list[tuple[str, str]]] = {
    "python": [
        ("pyproject.toml", "error"),
        ("Dockerfile", "error"),
        ("src/main.py", "warning"),
    ],
    "java": [
        ("pom.xml", "error"),
        ("Dockerfile", "error"),
        ("Dockerfile.dev", "warning"),
        ("server/pom.xml", "error"),
    ],
    "node": [
        ("package.json", "error"),
        ("Dockerfile", "warning"),
    ],
}


def _check_required_files(catalog: ComposeCatalog) -> list[Issue]:
    """Check that services have all required files for their type."""
    issues: list[Issue] = []

    for name, si in catalog.service_info.items():
        if si.group == "infra" or not si.directory or not si.service_type:
            continue

        required = _REQUIRED_FILES.get(si.service_type, [])
        for filename, severity in required:
            filepath = si.directory / filename
            if not filepath.exists():
                issues.append(
                    Issue(
                        severity,
                        name,
                        f"missing {filename} (required for {si.service_type} services)",
                    )
                )

    return issues


def _parse_pom_modules(pom_path: Path) -> list[str]:
    """Extract <module> entries from a pom.xml file."""
    if not pom_path.exists():
        return []
    content = pom_path.read_text()
    return re.findall(r"<module>\s*([^<]+?)\s*</module>", content)


def _parse_dockerfile_modules(dockerfile_path: Path, slug: str) -> list[str]:
    """Extract module names referenced in COPY lines of a Java Dockerfile.

    Looks for patterns like:
      COPY services/data/datasets/pom.xml datasets/
      COPY services/data/datasets/src datasets/src
    and extracts the module names (e.g. 'datasets').
    """
    if not dockerfile_path.exists():
        return []

    content = dockerfile_path.read_text()
    modules: set[str] = set()

    # Match: COPY services/<slug>/<module>/pom.xml <module>/
    for m in re.finditer(
        rf"COPY\s+services/{re.escape(slug)}/([a-zA-Z0-9_-]+)/pom\.xml\s+",
        content,
    ):
        modules.add(m.group(1))

    # Also match: COPY <module>/pom.xml <module>/  (Dockerfile.dev after WORKDIR)
    for m in re.finditer(
        r"COPY\s+(?:services/[^/]+/)?([a-zA-Z0-9_-]+)/pom\.xml\s+\1/",
        content,
    ):
        modules.add(m.group(1))

    return sorted(modules)


def _check_java_dockerfile_modules(catalog: ComposeCatalog) -> list[Issue]:
    """Check that Java Dockerfiles list all modules from pom.xml.

    When a Java service adds a new Maven module, the Dockerfile COPY lines
    must be updated to include pom.xml and src/ for the new module.
    """
    issues: list[Issue] = []

    for name, si in catalog.service_info.items():
        if si.group == "infra" or not si.directory or si.service_type != "java":
            continue

        pom_path = si.directory / "pom.xml"
        pom_modules = set(_parse_pom_modules(pom_path))
        if not pom_modules:
            continue

        slug = si.directory.name

        for df_name in ("Dockerfile", "Dockerfile.dev"):
            # Dockerfile may be in service dir or referenced from root
            df_path = si.directory / df_name
            if not df_path.exists():
                continue

            df_modules = set(_parse_dockerfile_modules(df_path, slug))

            # Modules in pom.xml but missing from Dockerfile
            missing = pom_modules - df_modules
            if missing:
                missing_str = ", ".join(sorted(missing))
                issues.append(
                    Issue(
                        "error",
                        name,
                        f"{df_name} is missing modules: {missing_str} "
                        f"(defined in pom.xml but not copied in Dockerfile)",
                        fix_description=f"add missing module COPY lines to {df_name}",
                        fix_fn=lambda root=catalog.root,
                        svc_dir=si.directory,
                        dockerfile=df_name,
                        mods=sorted(missing),
                        s=slug: _fix_java_dockerfile_modules(
                            svc_dir, dockerfile, mods, s
                        ),
                    )
                )

            # Modules in Dockerfile but removed from pom.xml (stale)
            extra = df_modules - pom_modules
            if extra:
                extra_str = ", ".join(sorted(extra))
                issues.append(
                    Issue(
                        "warning",
                        name,
                        f"{df_name} references modules not in pom.xml: {extra_str} "
                        f"(may be stale COPY lines)",
                    )
                )

    return issues


def _check_python_dockerfile_port(catalog: ComposeCatalog) -> list[Issue]:
    """Check that Python Dockerfiles use the correct port in CMD."""
    issues: list[Issue] = []

    for name, si in catalog.service_info.items():
        if si.group == "infra" or not si.directory or si.service_type != "python":
            continue
        if not si.container_port:
            continue

        dockerfile = si.directory / "Dockerfile"
        if not dockerfile.exists():
            continue

        content = dockerfile.read_text()
        # Look for --port XXXX in CMD line
        port_matches = re.findall(r"--port[\"'\s]+(\d+)", content)
        for port_str in port_matches:
            if port_str != si.container_port:
                issues.append(
                    Issue(
                        "warning",
                        name,
                        f"Dockerfile CMD uses port {port_str} but compose maps to {si.container_port}",
                    )
                )

    return issues


def _check_compose_dockerfile_refs(catalog: ComposeCatalog) -> list[Issue]:
    """Check that Dockerfiles referenced in compose files actually exist."""
    issues: list[Issue] = []

    all_filenames = set(COMPOSE_FILES.values()) | set(DEV_OVERLAYS.values())
    for filename in all_filenames:
        path = catalog.root / filename
        if not path.exists():
            continue

        content = path.read_text()
        lines = content.splitlines()

        # Track current service and its build context
        current_service: str | None = None
        build_context: str | None = None
        in_build = False

        for line in lines:
            # Service-level key
            m = re.match(r"^  ([a-zA-Z0-9][a-zA-Z0-9_-]*):\s*(?:#.*)?$", line)
            if m:
                current_service = m.group(1)
                build_context = None
                in_build = False
                continue

            if not current_service:
                continue

            if re.match(r"^    build:\s*$", line):
                in_build = True
                continue
            if re.match(r"^    [a-z]", line) and not re.match(r"^      ", line):
                if not re.match(r"^    build:", line):
                    in_build = False

            if in_build:
                ctx_m = re.match(r"^\s+context:\s+(.+)$", line)
                if ctx_m:
                    build_context = ctx_m.group(1).strip().strip('"').strip("'")

                df_m = re.match(r"^\s+dockerfile:\s+(.+)$", line)
                if df_m:
                    df_ref = df_m.group(1).strip().strip('"').strip("'")
                    # Resolve relative to build context (default: repo root)
                    ctx = build_context or "."
                    df_path = (catalog.root / ctx / df_ref).resolve()
                    if not df_path.exists():
                        issues.append(
                            Issue(
                                "error",
                                current_service,
                                f"Dockerfile not found: {ctx}/{df_ref} (referenced in {filename})",
                            )
                        )

    return issues


# ---------------------------------------------------------------------------
# Fixes
# ---------------------------------------------------------------------------


def _fix_rename_service(root: Path, old_name: str, new_name: str, group: str) -> bool:
    """Rename a service in all relevant compose files."""
    # Find all compose files that reference this service
    all_filenames = set(COMPOSE_FILES.values()) | set(DEV_OVERLAYS.values())
    all_files = [root / f for f in all_filenames if (root / f).exists()]

    changed_files: list[Path] = []
    for path in all_files:
        content = path.read_text()
        # Replace the service definition key (must be 2-space indented)
        new_content = re.sub(
            rf"^(  ){re.escape(old_name)}(:)",
            rf"\g<1>{new_name}\2",
            content,
            flags=re.MULTILINE,
        )
        # Replace references in depends_on, links, etc.
        new_content = re.sub(
            rf"\b{re.escape(old_name)}\b",
            new_name,
            new_content,
        )
        if new_content != content:
            path.write_text(new_content)
            changed_files.append(path)

    if changed_files:
        files_str = ", ".join(f.name for f in changed_files)
        success(f"Renamed '{old_name}' -> '{new_name}' in {files_str}")
        return True
    return False


def _fix_hardcoded_port(
    root: Path,
    service: str,
    old_host_port: str,
    container_port: str,
    env_expr: str | None = None,
) -> bool:
    """Rewrite a hardcoded port mapping to use an env var with default."""
    if env_expr is None:
        env_expr = make_port_env_expr(service, old_host_port)

    # Search all compose files for this port mapping
    all_filenames = set(COMPOSE_FILES.values()) | set(DEV_OVERLAYS.values())
    all_files = [root / f for f in all_filenames]
    changed = False

    for path in all_files:
        if not path.exists():
            continue
        content = path.read_text()

        # Match both quoted and unquoted forms:
        #   - "8084:8084"
        #   - 8084:8084
        old_patterns = [
            f'"{old_host_port}:{container_port}"',
            f"'{old_host_port}:{container_port}'",
            f"{old_host_port}:{container_port}",
        ]
        new_value = f'"{env_expr}:{container_port}"'

        for pat in old_patterns:
            if pat in content:
                content = content.replace(pat, new_value)
                changed = True

        if changed:
            path.write_text(content)
            success(f"  Rewrote port in {path.name}: {new_value}")

    return changed


def _fix_java_dockerfile_modules(
    svc_dir: Path, dockerfile_name: str, missing_modules: list[str], slug: str
) -> bool:
    """Add missing module COPY lines to a Java Dockerfile.

    Finds the last COPY .../<module>/pom.xml line and adds new ones after it,
    then finds the last COPY .../<module>/src line and adds new ones after it.
    """
    df_path = svc_dir / dockerfile_name
    if not df_path.exists():
        return False

    content = df_path.read_text()
    lines = content.split("\n")
    changed = False

    # --- Add pom.xml COPY lines ---
    # Find the last line matching COPY ... <module>/pom.xml <module>/
    last_pom_idx = -1
    pom_pattern = re.compile(
        r"^COPY\s+(?:services/"
        + re.escape(slug)
        + r"/)?([a-zA-Z0-9_-]+)/pom\.xml\s+\1/"
    )
    for i, line in enumerate(lines):
        if pom_pattern.match(line):
            last_pom_idx = i

    if last_pom_idx >= 0:
        # Determine the COPY style from the existing line
        existing_line = lines[last_pom_idx]
        uses_full_path = f"services/{slug}/" in existing_line

        new_pom_lines = []
        for mod in missing_modules:
            if uses_full_path:
                new_pom_lines.append(f"COPY services/{slug}/{mod}/pom.xml {mod}/")
            else:
                new_pom_lines.append(f"COPY {mod}/pom.xml {mod}/")

        for j, new_line in enumerate(new_pom_lines):
            lines.insert(last_pom_idx + 1 + j, new_line)
        changed = True

    # --- Add src COPY lines ---
    # Re-scan after insertion
    last_src_idx = -1
    src_pattern = re.compile(
        r"^COPY\s+(?:services/" + re.escape(slug) + r"/)?([a-zA-Z0-9_-]+)/src\s+\1/src"
    )
    for i, line in enumerate(lines):
        if src_pattern.match(line):
            last_src_idx = i

    if last_src_idx >= 0:
        existing_line = lines[last_src_idx]
        uses_full_path = f"services/{slug}/" in existing_line

        new_src_lines = []
        for mod in missing_modules:
            if uses_full_path:
                new_src_lines.append(f"COPY services/{slug}/{mod}/src {mod}/src")
            else:
                new_src_lines.append(f"COPY {mod}/src {mod}/src")

        for j, new_line in enumerate(new_src_lines):
            lines.insert(last_src_idx + 1 + j, new_line)
        changed = True

    # --- For Dockerfile.dev CMD, add module to mvn install -pl list ---
    if dockerfile_name == "Dockerfile.dev":
        for i, line in enumerate(lines):
            # Match: mvn install -pl module1,module2 -am
            m = re.search(r"(mvn install -pl )([a-zA-Z0-9_,-]+)( -am)", line)
            if m:
                existing_mods = m.group(2).split(",")
                all_mods = existing_mods + [
                    mod for mod in missing_modules if mod not in existing_mods
                ]
                new_pl = ",".join(all_mods)
                lines[i] = line[: m.start(2)] + new_pl + line[m.end(2) :]
                changed = True

    if changed:
        df_path.write_text("\n".join(lines))
        success(f"  Added modules {missing_modules} to {dockerfile_name}")
    return changed


# ---------------------------------------------------------------------------
# Main doctor command
# ---------------------------------------------------------------------------


def cmd_doctor(catalog: ComposeCatalog, fix: bool = False) -> None:
    """Run all checks and optionally apply fixes."""
    header("dx doctor")
    info(f"Checking project at {catalog.root}")
    print()

    all_issues: list[Issue] = []
    all_issues.extend(_check_prefix_consistency(catalog))
    all_issues.extend(_check_naming_convention(catalog))
    all_issues.extend(_check_missing_directories(catalog))
    all_issues.extend(_check_orphan_directories(catalog))
    all_issues.extend(_check_hardcoded_ports(catalog))
    all_issues.extend(_check_required_files(catalog))
    all_issues.extend(_check_compose_dockerfile_refs(catalog))
    all_issues.extend(_check_java_dockerfile_modules(catalog))
    all_issues.extend(_check_python_dockerfile_port(catalog))

    # Catalog checks (if catalog.yaml exists)
    catalog_path = catalog.root / "catalog.yaml"
    if catalog_path.exists():
        try:
            from dx.catalog import BackstageCatalog
            from dx.catalog_checks import run_catalog_checks

            backstage = BackstageCatalog.from_file(catalog_path)
            catalog_issues = run_catalog_checks(backstage, catalog)
            if catalog_issues:
                header("Catalog checks")
            all_issues.extend(catalog_issues)
        except ImportError:
            info("Install pyyaml to enable catalog checks: pip install pyyaml")

    if not all_issues:
        success("All checks passed — project follows naming conventions")
        return

    # Group by severity
    errors = [i for i in all_issues if i.severity == "error"]
    warnings = [i for i in all_issues if i.severity == "warning"]
    infos = [i for i in all_issues if i.severity == "info"]

    if errors:
        header("Errors (must fix)")
        for issue in errors:
            print(issue)
    if warnings:
        header("Warnings")
        for issue in warnings:
            print(issue)
    if infos:
        header("Info")
        for issue in infos:
            print(issue)

    print()
    fixable = [i for i in all_issues if i.fix_fn]

    if fix and fixable:
        header("Applying fixes...")
        for issue in fixable:
            info(f"Fix: {issue.fix_description}")
            issue.fix_fn()
        print()
        success(f"Applied {len(fixable)} fix(es). Run 'dx doctor' again to verify.")
    elif fixable:
        info(
            f"{len(fixable)} issue(s) can be auto-fixed. Run 'dx doctor --fix' to apply."
        )

    # Exit with error code if there are errors
    if errors and not fix:
        sys.exit(1)
