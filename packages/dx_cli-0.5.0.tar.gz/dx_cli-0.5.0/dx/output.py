"""ANSI color helpers and table formatting."""

from __future__ import annotations

import os
import sys


def _supports_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


_COLOR = _supports_color()

_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RED = "\033[31m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_BLUE = "\033[34m"
_CYAN = "\033[36m"


def _c(code: str, text: str) -> str:
    if not _COLOR:
        return text
    return f"{code}{text}{_RESET}"


def bold(text: str) -> str:
    return _c(_BOLD, text)


def dim(text: str) -> str:
    return _c(_DIM, text)


def info(msg: str) -> None:
    print(f"{_c(_CYAN, '▸')} {msg}")


def success(msg: str) -> None:
    print(f"{_c(_GREEN, '✓')} {msg}")


def warn(msg: str) -> None:
    print(f"{_c(_YELLOW, '!')} {msg}", file=sys.stderr)


def error(msg: str) -> None:
    print(f"{_c(_RED, '✗')} {msg}", file=sys.stderr)


def header(title: str) -> None:
    print(f"\n{_c(_BOLD, title)}")


def table(rows: list[list[str]], headers: list[str] | None = None) -> None:
    """Print a simple aligned table."""
    all_rows = ([headers] if headers else []) + rows
    if not all_rows:
        return
    widths = [0] * max(len(r) for r in all_rows)
    for row in all_rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))
    for i, row in enumerate(all_rows):
        line = "  ".join(cell.ljust(widths[j]) for j, cell in enumerate(row))
        if i == 0 and headers:
            print(f"  {_c(_DIM, line.rstrip())}")
        else:
            print(f"  {line.rstrip()}")
