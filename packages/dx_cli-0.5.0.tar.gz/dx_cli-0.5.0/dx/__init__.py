"""dx — developer experience CLI for Docker Compose projects."""

__version__ = "0.5.0"
