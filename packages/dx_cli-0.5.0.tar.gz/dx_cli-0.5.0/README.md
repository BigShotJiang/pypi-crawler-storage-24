# dx — Developer Experience CLI

A zero-dependency CLI for managing Docker Compose monorepos. Handles service lifecycle, port management, code generation, and project health checks.

## Install

```sh
pip install dx-cli
```

Or install from source:

```sh
pip install -e dx-cli/
```

## Quick Start

```sh
dx up                     # Start all services
dx dev                    # Start with hot-reload
dx down                   # Stop everything
dx ps                     # Show running containers
dx logs service-data      # Stream logs
```

## Commands

### Docker Lifecycle

| Command                   | Description                                 |
| ------------------------- | ------------------------------------------- |
| `dx up [targets...]`      | Start services (prod mode)                  |
| `dx dev [targets...]`     | Start services (dev mode + hot-reload)      |
| `dx down [targets...]`    | Stop and remove containers                  |
| `dx restart [targets...]` | Restart containers                          |
| `dx reset [targets...]`   | Stop + wipe volumes                         |
| `dx ps`                   | Show running containers                     |
| `dx logs [targets...]`    | Stream container logs                       |
| `dx pull [targets...]`    | Pull images                                 |
| `dx reload <service>`     | Recompile Java service for DevTools restart |

### Build / Test / Lint

| Command                 | Description                                |
| ----------------------- | ------------------------------------------ |
| `dx build [targets...]` | Build services (`all`, `common`, or names) |
| `dx test [targets...]`  | Run tests (`all` or service names)         |
| `dx lint [targets...]`  | Run linters (`all`, `frontend`, `python`)  |

### Service Scaffolding

| Command                     | Description                             |
| --------------------------- | --------------------------------------- |
| `dx generate python <name>` | Scaffold a new Python/FastAPI service   |
| `dx generate java <name>`   | Scaffold a new Java/Spring Boot service |

Generated services include Dockerfiles, compose entries, health checks, config, and agent guides.

### Port Management

| Command                     | Description                      |
| --------------------------- | -------------------------------- |
| `dx ports`                  | Show port assignments            |
| `dx ports pin <svc> <port>` | Pin a service to a specific port |
| `dx ports reset [service]`  | Clear port reservations          |

Ports are auto-allocated for all services (infra, services, apps) and persisted in `.dx/ports.json`.

### Project Health

| Command           | Description                                           |
| ----------------- | ----------------------------------------------------- |
| `dx doctor`       | Check project structure, Dockerfiles, and conventions |
| `dx doctor --fix` | Auto-fix issues in compose files and Dockerfiles      |

Checks include:

- Compose service naming conventions
- Required files per service type (Dockerfile, pom.xml, pyproject.toml)
- Java Dockerfile module sync with pom.xml
- Hardcoded ports (auto-fixable)
- Missing Dockerfile references

### Proxy & DNS

| Command          | Description                      |
| ---------------- | -------------------------------- |
| `dx proxy start` | Start reverse proxy on `:7355`   |
| `dx proxy stop`  | Stop reverse proxy               |
| `dx hosts setup` | Add `*.dx.localhost` DNS entries |

Access services at `http://<service>.dx.localhost:7355`.

## Target Resolution

Targets can be:

- **Group names**: `infra`, `services`, `apps`
- **Service names**: `service-data`, `infra-postgres`
- **Shorthand**: `data`, `ai`, `frontend`
- **Glob patterns**: `service-d*`, `app-*-ui`

## Compose File Convention

```
docker-compose.infra.yml          # Infrastructure (prefix: infra-*)
docker-compose.services.yml       # Backend services (prefix: service-*)
docker-compose.apps.yml           # Frontend apps (prefix: app-*)
docker-compose.dev.services.yml   # Dev overlay for services
docker-compose.dev.apps.yml       # Dev overlay for apps
```

## Requirements

- Python 3.11+
- Docker with Compose v2
- No Python dependencies (zero-dependency CLI)

## License

MIT
