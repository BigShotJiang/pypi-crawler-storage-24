"""
GUI Module for GUIBRUSHR

Contains all graphical user interface components including panels, widgets, and layouts.
"""

__version__ = "1.0.6"
__author__ = "GUIBRUSHR Team"
__description__ = "GUI Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import GUI submodules when accessed (prevents circular imports).
    """
    if name in {"DataInterface", "Input_Output_Panels", "LAYOUT", "WIDGET"}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "DataInterface",
    "Input_Output_Panels",
    "LAYOUT",
    "WIDGET"
]
