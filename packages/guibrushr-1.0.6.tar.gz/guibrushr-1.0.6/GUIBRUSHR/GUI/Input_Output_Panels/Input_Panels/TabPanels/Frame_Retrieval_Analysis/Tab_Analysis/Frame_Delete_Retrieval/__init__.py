"""
Frame Delete Retrieval Module

Contains components for deleting and managing retrieval data.
"""

__version__ = "1.0.6"
__author__ = "GUIBRUSHR Team"
__description__ = "Frame Delete Retrieval Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import delete retrieval components when accessed (prevents circular imports).
    """
    if name == "Frame_Delete_Retrieval":
        module = importlib.import_module(".Frame_Delete_Retrieval", package=__name__)
        sys.modules[f"{__name__}.Frame_Delete_Retrieval"] = module
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "Frame_Delete_Retrieval"
]
