"""
Frame Retrieval Analysis Module

Contains retrieval analysis frame components.
"""

__version__ = "1.0.6"
__author__ = "GUIBRUSHR Team"
__description__ = "Frame Retrieval Analysis Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import retrieval analysis components when accessed (prevents circular imports).
    """
    if name == "Tab_Analysis":
        module = importlib.import_module(".Tab_Analysis", package=__name__)
        sys.modules[f"{__name__}.Tab_Analysis"] = module
        return module
    elif name == "FrameFilterTable":
        module = importlib.import_module(".FrameFilterTable", package=__name__)
        sys.modules[f"{__name__}.FrameFilterTable"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "Tab_Analysis",
    "FrameFilterTable"
]
