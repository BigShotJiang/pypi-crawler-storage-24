"""
Frame Model Plot Module

Contains components for creating and displaying model plots.
"""

__version__ = "1.0.6"
__author__ = "GUIBRUSHR Team"
__description__ = "Frame Model Plot Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import model plot components when accessed (prevents circular imports).
    """
    if name == "Frame_Model_Plot":
        module = importlib.import_module(".Frame_Model_Plot", package=__name__)
        sys.modules[f"{__name__}.Frame_Model_Plot"] = module
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "Frame_Model_Plot"
]
