"""
Frame Path Module

Contains components for path configuration and file management.
"""

__version__ = "1.0.6"
__author__ = "GUIBRUSHR Team"
__description__ = "Frame Path Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import path components when accessed (prevents circular imports).
    """
    # Currently no components defined, but structure is ready for future additions
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = []