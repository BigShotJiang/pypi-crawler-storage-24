"""
This module converts Korean Hangul text into Latin alphabet using
the Revised Romanization of Korean rules.

References:
    https://en.wikipedia.org/w/index.php?title=Revised_Romanization_of_Korean&oldid=1064463473
"""

from .const import CONSONANTS, DOUBLES, CHOSUNG, JUNGSEONG, JONGSUNG, PROVISIONS


# ---------------------------------------------------------------------------
# Unicode Hangul syllable range
#
# Hangul syllables occupy a contiguous block in Unicode.
#
#   Start: 0xAC00 (가)
#   End:   0xD7A3 (힣)
#
# Each syllable can be decomposed mathematically into:
#
#   initial consonant (choseong)
#   medial vowel      (jungseong)
#   final consonant   (jongseong)
#
# using the formula defined by the Unicode standard.
# ---------------------------------------------------------------------------

HANGUL_START = 0xAC00
HANGUL_END = 0xD7A3


# ---------------------------------------------------------------------------
# Fast lookup tables
#
# The constants in const.py are dictionaries keyed by Unicode codepoints.
# Dictionary lookup is relatively expensive in tight loops.
#
# We convert them into list tables indexed by small integers to achieve
# constant-time array lookup which is significantly faster.
#
# Example:
#     CHOSUNG[0x1100] → CHO_TABLE[0]
#
# This removes hashing overhead during romanization.
# ---------------------------------------------------------------------------

CHO_TABLE = [CHOSUNG.get(0x1100 + i, ()) for i in range(256)]
JUNG_TABLE = [JUNGSEONG.get(0x1161 + i, "") for i in range(256)]
JONG_TABLE = [JONGSUNG.get(0x11A7 + i, ()) for i in range(256)]

CONS = CONSONANTS
DOUB = set(DOUBLES)
PROV = PROVISIONS


def romanize(text: str) -> str:
    """
    Convert Hangul text into Revised Romanization.

    This function processes the input string and converts all Hangul
    syllables into their Latin romanized form. Non-Hangul characters
    are preserved as-is.

    The function groups consecutive Hangul characters to process them
    efficiently in blocks.

    Args:
        text: Input string containing Hangul or mixed text.

    Returns:
        Romanized string with Hangul converted to Latin characters.

    Example:
        >>> romanize("안녕하세요")
        'annyeonghaseyo'

        >>> romanize("한국 Seoul")
        'hanguk Seoul'
    """

    result = []
    buffer = []

    append = result.append

    for ch in text:

        code = ord(ch)

        # Detect Hangul syllable
        if HANGUL_START <= code <= HANGUL_END:
            buffer.append(code)
            continue

        # Flush buffered Hangul block
        if buffer:
            append(_romanize_block(buffer))
            buffer.clear()

        append(ch)

    if buffer:
        append(_romanize_block(buffer))

    return "".join(result)


def _romanize_block(block: list[int]) -> str:
    """
    Romanize a contiguous block of Hangul syllables.

    This function performs three main steps:

    1. Decompose Hangul syllables into jamo components
    2. Convert jamo to romanized phonemes
    3. Apply assimilation rules between consonants

    Hangul decomposition formula:

        S = syllable codepoint − 0xAC00

        choseong  = S // 588
        jungseong = (S // 28) % 21
        jongseong = S % 28

    Args:
        block: List of Hangul Unicode codepoints.

    Returns:
        Romanized representation of the block.
    """

    stream = []
    extend = stream.extend
    append = stream.append

    # --------------------------------------------------
    # Step 1: Hangul decomposition
    # --------------------------------------------------

    for code in block:

        x = code - HANGUL_START

        jong = x % 28
        jung = (x // 28) % 21
        cho = x // 588

        extend(CHO_TABLE[cho])
        append(JUNG_TABLE[jung])

        if jong:
            extend(JONG_TABLE[jong])

    # --------------------------------------------------
    # Step 2: Group jamo sequence
    #
    # Groups are separated by type:
    #     int  -> consonant
    #     str  -> vowel
    # --------------------------------------------------

    groups = []
    cur = [stream[0]]
    cur_is_int = isinstance(stream[0], int)

    for item in stream[1:]:

        is_int = isinstance(item, int)

        if is_int == cur_is_int:
            cur.append(item)
        else:
            groups.append(cur)
            cur = [item]
            cur_is_int = is_int

    groups.append(cur)

    # --------------------------------------------------
    # Step 3: Convert grouped jamo to romanization
    # --------------------------------------------------

    output = []

    prefix = groups[0]

    if isinstance(prefix[0], int):

        if len(prefix) == 1:
            output.append(CONS[prefix[0]][0])

        elif len(prefix) == 2:
            output.append(CONS[prefix[0]][1])

    for g in groups[1:-1]:

        if not isinstance(g[0], int):
            output.append(g[0])
            continue

        length = len(g)

        if length == 1:
            output.append(CONS[g[0]][0])

        elif length == 2:

            a, b = g

            if a == b and a in DOUB:
                output.append(CONS[a][1])
            else:
                output.append(PROV[(a, b)])

        else:

            a, b, c = g

            if a == b:

                if c == 0x3147:
                    output.append(CONS[a][1])
                else:
                    output.append(PROV[(a, c)])

            else:

                output.append(CONS[a][2])

                if b == c:
                    output.append(CONS[b][1])
                else:
                    output.append(PROV[(b, c)])

    suffix = groups[-1]

    if isinstance(suffix[0], int):
        output.append(CONS[suffix[0]][2])
    else:
        output.append(suffix[0])

    return "".join(output)
