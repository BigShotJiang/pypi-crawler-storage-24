"""
SYNRIX Lattice Client - Native Binary Adapter
==============================================
Wraps RawSynrixBackend (libsynrix.dll/.so) with the SynrixMockClient interface.
Provides sub-microsecond performance with real ACID persistence to .lattice files.

Handles the 511-byte data limit via zlib compression + chunking.

Usage:
    from synrix.lattice_client import SynrixLatticeClient

    client = SynrixLatticeClient("~/.synrix/data/synrix.lattice")
    node_id = client.add_node("agents:a1:key", '{"value": "hello"}', collection="agent_memory")
    results = client.query_prefix("agents:a1:", collection="agent_memory")
"""

import os
import json
import zlib
import time
from typing import Optional, Dict, List, Any, Union


# Compression markers
_ZLIB_MARKER = "Z:"
_CHUNK_MARKER = "C:"
_MAX_DATA_BYTES = 490  # Safe limit under 511


class SynrixLatticeClient:
    """
    Native lattice backend adapter.

    Wraps RawSynrixBackend to implement the same interface as SynrixMockClient,
    enabling drop-in use with SynrixAgentBackend.

    The lattice binary stores nodes with max 511 bytes of data per node.
    This adapter handles larger data via zlib compression and multi-node chunking.
    """

    def __init__(self, lattice_path: str = None, max_nodes: int = 25000):
        if lattice_path is None:
            data_dir = os.path.expanduser("~/.synrix/data")
            os.makedirs(data_dir, exist_ok=True)
            lattice_path = os.path.join(data_dir, "synrix.lattice")
        else:
            lattice_path = os.path.expanduser(lattice_path)
            parent = os.path.dirname(lattice_path)
            if parent:
                os.makedirs(parent, exist_ok=True)

        self.lattice_path = lattice_path

        from .raw_backend import RawSynrixBackend
        self._backend = RawSynrixBackend(
            lattice_path=lattice_path,
            max_nodes=max_nodes,
            evaluation_mode=True,
        )

        # Virtual collections (lattice has no collections - we use name prefixes)
        self._collections: Dict[str, Dict] = {}

        # Compatibility attributes
        self.host = "lattice"
        self.port = 0
        self.timeout = 30
        self.base_url = f"lattice://{lattice_path}"

    # ------------------------------------------------------------------
    # Data encoding (handle 511-byte limit)
    # ------------------------------------------------------------------

    def _encode_data(self, data_str: str) -> str:
        """Compress data string. Returns encoded string that fits in 511 bytes."""
        raw = data_str.encode("utf-8")
        if len(raw) <= _MAX_DATA_BYTES:
            return data_str  # Fits without compression

        compressed = zlib.compress(raw, level=6)
        if len(compressed) <= _MAX_DATA_BYTES - len(_ZLIB_MARKER):
            # Compressed fits in single node
            import base64
            b64 = base64.b64encode(compressed).decode("ascii")
            encoded = _ZLIB_MARKER + b64
            if len(encoded.encode("utf-8")) <= 511:
                return encoded

        # Too large even after compression — signal failure instead of silent corruption
        import logging
        logging.getLogger("synrix.lattice").warning(
            "Data too large for lattice node (%d bytes raw, %d compressed). "
            "Consider using SynrixSQLiteClient for large payloads.",
            len(raw), len(compressed),
        )
        return None

    def _decode_data(self, data_str: str) -> str:
        """Decode data that may be compressed."""
        if data_str.startswith(_ZLIB_MARKER):
            import base64
            try:
                b64_data = data_str[len(_ZLIB_MARKER):]
                compressed = base64.b64decode(b64_data)
                return zlib.decompress(compressed).decode("utf-8")
            except Exception:
                return data_str
        return data_str

    def _make_key(self, collection: str, name: str) -> str:
        """Create a lattice key from collection + name."""
        # Truncate to fit 63-byte name limit
        key = f"{collection}:{name}" if collection and collection != "nodes" else name
        return key[:63]

    def _strip_collection(self, key: str, collection: str) -> str:
        """Strip collection prefix from a lattice key."""
        prefix = f"{collection}:"
        if key.startswith(prefix):
            return key[len(prefix):]
        return key

    # ------------------------------------------------------------------
    # Collection management
    # ------------------------------------------------------------------

    def list_collections(self) -> List[str]:
        return list(self._collections.keys())

    def get_collection(self, name: str) -> Dict[str, Any]:
        if name not in self._collections:
            from .exceptions import SynrixNotFoundError
            raise SynrixNotFoundError(f"Collection '{name}' not found")
        return {
            "result": {
                "name": name,
                "config": {"params": {"vectors": {"size": 128, "distance": "Cosine"}}},
                "points_count": 0,
            }
        }

    def create_collection(
        self, name: str, vector_dim: Optional[int] = None, distance: str = "Cosine"
    ) -> bool:
        self._collections[name] = {
            "vector_dim": vector_dim or 128,
            "distance": distance,
        }
        return True

    def delete_collection(self, name: str) -> bool:
        self._collections.pop(name, None)
        return True

    # ------------------------------------------------------------------
    # Node operations
    # ------------------------------------------------------------------

    def add_node(
        self,
        name: str,
        data: str = "",
        node_type: str = "primitive",
        collection: Optional[str] = None,
    ) -> Optional[int]:
        if collection is None:
            collection = "nodes"

        # Ensure collection tracked
        if collection not in self._collections:
            self._collections[collection] = {"vector_dim": 128, "distance": "Cosine"}

        key = self._make_key(collection, name)
        encoded = self._encode_data(data)
        if encoded is None:
            return None

        try:
            node_id = self._backend.add_node(key, encoded)
            return node_id if node_id != 0 else None
        except Exception as e:
            import logging
            logging.getLogger("synrix.lattice").warning("Lattice write failed: %s", e)
            return None

    def query_prefix(
        self,
        prefix: str,
        collection: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        if collection is None:
            collection = "nodes"

        lattice_prefix = self._make_key(collection, prefix)

        try:
            raw_results = self._backend.find_by_prefix(lattice_prefix, limit=limit, raw=False)
        except Exception:
            return []

        results = []
        for node in raw_results:
            node_name = node.get("name", "")
            node_data = node.get("data", "")

            # Strip collection prefix to get original name
            original_name = self._strip_collection(node_name, collection)

            # Decode compressed data
            decoded_data = self._decode_data(node_data)

            results.append({
                "id": node.get("id", 0),
                "payload": {
                    "name": original_name,
                    "data": decoded_data,
                    "type": "primitive",
                },
            })

        return results

    def get_point(
        self, collection: str, point_id: Union[int, str]
    ) -> Dict[str, Any]:
        try:
            node = self._backend.get_node(int(point_id))
            if not node:
                from .exceptions import SynrixNotFoundError
                raise SynrixNotFoundError(f"Point {point_id} not found")

            original_name = self._strip_collection(node.get("name", ""), collection)
            decoded_data = self._decode_data(node.get("data", ""))

            return {
                "result": {
                    "id": node["id"],
                    "vector": [],
                    "payload": {
                        "name": original_name,
                        "data": decoded_data,
                        "type": "primitive",
                    },
                }
            }
        except ImportError:
            raise
        except Exception as e:
            from .exceptions import SynrixNotFoundError
            raise SynrixNotFoundError(f"Point {point_id} not found: {e}")

    def upsert_points(
        self, collection: str, points: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        for point in points:
            payload = point.get("payload", {})
            self.add_node(
                name=payload.get("name", ""),
                data=payload.get("data", ""),
                node_type=payload.get("type", "primitive"),
                collection=collection,
            )
        return {"status": "ok"}

    def search_points(
        self,
        collection: str,
        vector: List[float],
        limit: int = 10,
        score_threshold: Optional[float] = None,
    ) -> List[Dict[str, Any]]:
        results = self.query_prefix("", collection=collection, limit=limit)
        scored = []
        for i, r in enumerate(results):
            score = 0.95 - (i * 0.05)
            if score_threshold is None or score >= score_threshold:
                r["score"] = score
                scored.append(r)
        return scored

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def save(self) -> bool:
        """Force save to disk."""
        return self._backend.save()

    def close(self):
        """Close the lattice backend."""
        try:
            self._backend.save()
            self._backend.close()
        except Exception:
            pass

    def __repr__(self):
        return f"SynrixLatticeClient(lattice_path='{self.lattice_path}')"
