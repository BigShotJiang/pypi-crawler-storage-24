"""
Synrix Agent Runtime — Persistent Memory Kernel for AI Agents
"""

__version__ = "1.0.0"

from synrix_runtime.api.runtime import AgentRuntime

__all__ = ["AgentRuntime"]
