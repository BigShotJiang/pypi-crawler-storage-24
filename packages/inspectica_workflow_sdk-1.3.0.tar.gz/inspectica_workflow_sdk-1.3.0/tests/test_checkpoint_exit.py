"""Tests for WorkflowCheckpointExit — remote activity checkpoint & resume flow."""

import asyncio
import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from workflow_sdk.workflow import (
    WorkerShutdownError,
    WorkflowCheckpointExit,
    WorkflowContext,
    set_context,
)
from workflow_sdk.worker import (
    CompletedActivity,
    Worker,
    WorkflowResultError,
    WorkflowTask,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_workflow_task(**overrides) -> WorkflowTask:
    defaults = {
        "task_id": "task-001",
        "workflow_id": "wf-001",
        "workflow_name": "TestWorkflow",
        "input": {"key": "value"},
        "timeout_ms": 300_000,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    defaults.update(overrides)
    return WorkflowTask(**defaults)


def _make_worker() -> Worker:
    """Create a Worker with minimal mocks so _execute_workflow can run."""
    worker = Worker.__new__(Worker)
    worker.workflows = {}
    worker.activities = {}
    worker.worker_id = "test-worker-001"
    worker.server_url = "http://localhost:8080"
    worker.api_key = "test-key"
    worker._producer = AsyncMock()
    worker._result_topic = "test-results"
    worker._can_continue_processing = None
    worker._shutting_down = False
    worker._workflow_semaphore = None
    worker._main_loop = None
    return worker


# ---------------------------------------------------------------------------
# 1. WorkflowCheckpointExit exception basics
# ---------------------------------------------------------------------------

class TestWorkflowCheckpointExitException:
    def test_is_exception(self):
        ex = WorkflowCheckpointExit("test")
        assert isinstance(ex, Exception)
        assert str(ex) == "test"

    def test_not_a_worker_shutdown_error(self):
        ex = WorkflowCheckpointExit("test")
        assert not isinstance(ex, WorkerShutdownError)

    def test_catchable_separately(self):
        """WorkflowCheckpointExit must NOT be caught by a bare `except Exception`
        handler before the dedicated handler in _execute_workflow."""
        with pytest.raises(WorkflowCheckpointExit):
            raise WorkflowCheckpointExit("checkpoint")


# ---------------------------------------------------------------------------
# 2. execute_remote_activity raises WorkflowCheckpointExit on completion
# ---------------------------------------------------------------------------

class TestExecuteRemoteActivityCheckpoint:
    @pytest.mark.asyncio
    async def test_raises_checkpoint_on_completed(self):
        """When HTTP poll returns status=completed, WorkflowCheckpointExit is raised."""
        worker = _make_worker()

        mock_response = AsyncMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={"status": "completed", "output": {"result": 42}})
        mock_response.__aenter__ = AsyncMock(return_value=mock_response)
        mock_response.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.get = MagicMock(return_value=mock_response)
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            with pytest.raises(WorkflowCheckpointExit) as exc_info:
                await worker.execute_remote_activity(
                    workflow_id="wf-001",
                    activity_name="remote_activity",
                    activity_index=1,
                    input_data={"x": 1},
                    timeout_ms=60000,
                )

            assert "remote_activity" in str(exc_info.value)
            assert "completed" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_raises_runtime_error_on_failed(self):
        """When HTTP poll returns status=failed, RuntimeError is raised (not checkpoint)."""
        worker = _make_worker()

        mock_response = AsyncMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={"status": "failed", "error": "boom"})
        mock_response.__aenter__ = AsyncMock(return_value=mock_response)
        mock_response.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.get = MagicMock(return_value=mock_response)
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            with pytest.raises(RuntimeError, match="boom"):
                await worker.execute_remote_activity(
                    workflow_id="wf-001",
                    activity_name="remote_activity",
                    activity_index=1,
                    input_data={"x": 1},
                    timeout_ms=60000,
                )

    @pytest.mark.asyncio
    async def test_sends_activity_request_via_kafka(self):
        """The Kafka ActivityRequest is sent before polling starts."""
        worker = _make_worker()

        mock_response = AsyncMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={"status": "completed", "output": None})
        mock_response.__aenter__ = AsyncMock(return_value=mock_response)
        mock_response.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.get = MagicMock(return_value=mock_response)
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            with pytest.raises(WorkflowCheckpointExit):
                await worker.execute_remote_activity(
                    workflow_id="wf-001",
                    activity_name="remote_activity",
                    activity_index=1,
                    input_data={"x": 1},
                    timeout_ms=60000,
                )

        # Verify Kafka send was called with the activity request
        worker._producer.send_and_wait.assert_called_once()
        call_kwargs = worker._producer.send_and_wait.call_args
        payload = call_kwargs.kwargs.get("value") or call_kwargs[1].get("value")
        assert payload["request_type"] == "activity_request"
        assert payload["activity_name"] == "remote_activity"
        assert payload["workflow_id"] == "wf-001"


# ---------------------------------------------------------------------------
# 3. _execute_workflow handles WorkflowCheckpointExit (no result sent)
# ---------------------------------------------------------------------------

class TestExecuteWorkflowCheckpointHandling:
    @pytest.mark.asyncio
    async def test_checkpoint_exit_does_not_send_workflow_result(self):
        """When workflow raises WorkflowCheckpointExit, no workflow result
        should be sent to the server — the server handles the resume."""
        from workflow_sdk import workflow as wf_module

        @wf_module.defn
        class CheckpointWorkflow:
            @wf_module.run
            async def run(self, input_data):
                raise WorkflowCheckpointExit("checkpoint after remote activity")

        worker = _make_worker()
        worker.workflows = {"CheckpointWorkflow": CheckpointWorkflow}
        worker._send_workflow_result = AsyncMock()

        task = _make_workflow_task(workflow_name="CheckpointWorkflow")
        await worker._execute_workflow(task, "test-results")

        # _send_workflow_result should NOT have been called
        worker._send_workflow_result.assert_not_called()

    @pytest.mark.asyncio
    async def test_checkpoint_exit_does_not_set_shutting_down(self):
        """CheckpointExit should not trigger worker shutdown (unlike WorkerShutdownError)."""
        from workflow_sdk import workflow as wf_module

        @wf_module.defn
        class CheckpointWorkflow:
            @wf_module.run
            async def run(self, input_data):
                raise WorkflowCheckpointExit("checkpoint")

        worker = _make_worker()
        worker.workflows = {"CheckpointWorkflow": CheckpointWorkflow}
        worker._send_workflow_result = AsyncMock()

        task = _make_workflow_task(workflow_name="CheckpointWorkflow")
        await worker._execute_workflow(task, "test-results")

        assert worker._shutting_down is False

    @pytest.mark.asyncio
    async def test_worker_shutdown_still_sends_failed_result(self):
        """WorkerShutdownError should still send a failed result (regression guard)."""
        from workflow_sdk import workflow as wf_module

        @wf_module.defn
        class ShutdownWorkflow:
            @wf_module.run
            async def run(self, input_data):
                raise WorkerShutdownError("shutting down")

        worker = _make_worker()
        worker.workflows = {"ShutdownWorkflow": ShutdownWorkflow}
        worker._send_workflow_result = AsyncMock()

        task = _make_workflow_task(workflow_name="ShutdownWorkflow")
        await worker._execute_workflow(task, "test-results")

        # Should have sent a failed result
        worker._send_workflow_result.assert_called_once()
        call_kwargs = worker._send_workflow_result.call_args
        assert call_kwargs.kwargs.get("status") or call_kwargs[1].get("status") == "failed"

    @pytest.mark.asyncio
    async def test_normal_exception_still_sends_failed_result(self):
        """Regular exceptions should still send a failed workflow result."""
        from workflow_sdk import workflow as wf_module

        @wf_module.defn
        class FailingWorkflow:
            @wf_module.run
            async def run(self, input_data):
                raise ValueError("something went wrong")

        worker = _make_worker()
        worker.workflows = {"FailingWorkflow": FailingWorkflow}
        worker._send_workflow_result = AsyncMock()

        task = _make_workflow_task(workflow_name="FailingWorkflow")
        await worker._execute_workflow(task, "test-results")

        worker._send_workflow_result.assert_called_once()

    @pytest.mark.asyncio
    async def test_completed_workflow_sends_completed_result(self):
        """A normally completed workflow should send a completed result."""
        from workflow_sdk import workflow as wf_module

        @wf_module.defn
        class OkWorkflow:
            @wf_module.run
            async def run(self, input_data):
                return {"status": "ok"}

        worker = _make_worker()
        worker.workflows = {"OkWorkflow": OkWorkflow}
        worker._send_workflow_result = AsyncMock()

        task = _make_workflow_task(workflow_name="OkWorkflow")
        await worker._execute_workflow(task, "test-results")

        worker._send_workflow_result.assert_called_once()
        call_kwargs = worker._send_workflow_result.call_args.kwargs
        assert call_kwargs["status"] == "completed"


# ---------------------------------------------------------------------------
# 4. WorkflowContext.execute_activity replay + remote routing
# ---------------------------------------------------------------------------

class TestWorkflowContextReplayAndRemote:
    @pytest.mark.asyncio
    async def test_replay_returns_cached_result(self):
        """In replay mode, execute_activity should return the cached result
        without calling the actual activity."""
        ctx = WorkflowContext(
            activities={"my_activity": AsyncMock()},
            workflow_id="wf-001",
            worker=None,
            completed_activities={1: {"cached": True}},
        )
        result = await ctx.execute_activity("my_activity", {"x": 1})
        assert result == {"cached": True}
        # The actual activity function should not have been called
        ctx.activities["my_activity"].assert_not_called()

    @pytest.mark.asyncio
    async def test_remote_activity_calls_worker(self):
        """When an activity is not registered locally, it delegates to
        worker.execute_remote_activity."""
        mock_worker = MagicMock()
        mock_worker._can_continue_processing = None
        mock_worker.execute_remote_activity = AsyncMock(
            side_effect=WorkflowCheckpointExit("checkpoint")
        )

        ctx = WorkflowContext(
            activities={},  # No local activities
            workflow_id="wf-001",
            worker=mock_worker,
        )

        with pytest.raises(WorkflowCheckpointExit):
            await ctx.execute_activity("remote_activity", {"x": 1}, 60000)

        mock_worker.execute_remote_activity.assert_called_once_with(
            workflow_id="wf-001",
            activity_name="remote_activity",
            activity_index=1,
            input_data={"x": 1},
            timeout_ms=60000,
        )


# ---------------------------------------------------------------------------
# 5. Resume flow: completed_activities are replayed, then new activity runs
# ---------------------------------------------------------------------------

class TestResumeWorkflowFlow:
    @pytest.mark.asyncio
    async def test_resume_replays_completed_then_runs_next(self):
        """When a workflow resumes with completed_activities, the first
        activities should be replayed from cache, and the next activity
        should execute normally."""
        from workflow_sdk import workflow as wf_module

        call_log = []

        async def local_activity_a(input_data):
            call_log.append(("a", input_data))
            return {"a": "result"}

        async def local_activity_b(input_data):
            call_log.append(("b", input_data))
            return {"b": "result"}

        local_activity_a.__activity_name__ = "activity_a"
        local_activity_b.__activity_name__ = "activity_b"

        @wf_module.defn
        class ResumeWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                r1 = await ctx.execute_activity("activity_a", {"step": 1})
                r2 = await ctx.execute_activity("activity_b", {"step": 2})
                return {"r1": r1, "r2": r2}

        worker = _make_worker()
        worker.workflows = {"ResumeWorkflow": ResumeWorkflow}
        worker.activities = {
            "activity_a": local_activity_a,
            "activity_b": local_activity_b,
        }
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        # Resume with activity_a already completed
        task = _make_workflow_task(
            workflow_name="ResumeWorkflow",
            completed_activities=[
                CompletedActivity(index=1, name="activity_a", output={"a": "cached"})
            ],
        )

        await worker._execute_workflow(task, "test-results")

        # activity_a should NOT have been called (replayed from cache)
        assert ("a", {"step": 1}) not in call_log
        # activity_b should have been called
        assert ("b", {"step": 2}) in call_log

        # Workflow should have completed with the cached result for a
        worker._send_workflow_result.assert_called_once()
        call_kwargs = worker._send_workflow_result.call_args.kwargs
        assert call_kwargs["status"] == "completed"
        assert call_kwargs["output"]["r1"] == {"a": "cached"}
        assert call_kwargs["output"]["r2"] == {"b": "result"}
