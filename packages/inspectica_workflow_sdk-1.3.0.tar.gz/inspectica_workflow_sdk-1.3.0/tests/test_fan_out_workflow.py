"""Comprehensive tests for the fan-out workflow mechanism and related flows.

Covers:
1. Normal workflow — local activities run, result sent
2. Error + resume flow — workflow fails, resumes with completed_activities
3. Fan-out workflow — parallel dispatch, checkpoint exit, resume with aggregated results
4. Fan-out partial error — some tasks fail, workflow records error, resume after fix
5. Resume with handover — workflow resumes on a different worker instance

These tests validate both SDK workflow context logic and the server↔SDK
message contract (Kafka payloads, resume tasks, checkpoint exits).
"""

import asyncio
import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, call, patch

import pytest

from workflow_sdk import workflow as wf_module
from workflow_sdk.workflow import (
    WorkerShutdownError,
    WorkflowCheckpointExit,
    WorkflowContext,
    set_context,
)
from workflow_sdk.worker import (
    CompletedActivity,
    Worker,
    WorkflowResultError,
    WorkflowTask,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_workflow_task(**overrides) -> WorkflowTask:
    defaults = {
        "task_id": "task-001",
        "workflow_id": "wf-001",
        "workflow_name": "TestWorkflow",
        "input": {"request_id": "req-1"},
        "timeout_ms": 300_000,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    defaults.update(overrides)
    return WorkflowTask(**defaults)


def _make_worker(worker_id: str = "worker-A") -> Worker:
    """Create a Worker with minimal mocks so _execute_workflow can run."""
    worker = Worker.__new__(Worker)
    worker.workflows = {}
    worker.activities = {}
    worker.worker_id = worker_id
    worker.instance_id = "inst-001"
    worker.server_url = "http://localhost:8080"
    worker.api_key = "test-key"
    worker._producer = AsyncMock()
    worker._result_topic = "test-results"
    worker._can_continue_processing = None
    worker._shutting_down = False
    worker._workflow_semaphore = None
    worker._main_loop = None
    return worker


# ===========================================================================
# 1. Normal workflow — local activities execute and produce completed result
# ===========================================================================

class TestNormalWorkflow:
    """A workflow with only local activities runs to completion."""

    @pytest.mark.asyncio
    async def test_two_local_activities_run_in_order(self):
        call_log = []

        async def activity_a(input_data):
            call_log.append(("a", input_data))
            return {"a_out": 1}

        async def activity_b(input_data):
            call_log.append(("b", input_data))
            return {"b_out": 2}

        activity_a.__activity_name__ = "activity_a"
        activity_b.__activity_name__ = "activity_b"

        @wf_module.defn
        class NormalWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                r1 = await ctx.execute_activity(activity_a, {"step": 1})
                r2 = await ctx.execute_activity(activity_b, {"step": 2})
                return {"r1": r1, "r2": r2}

        worker = _make_worker()
        worker.workflows = {"NormalWorkflow": NormalWorkflow}
        worker.activities = {
            "activity_a": activity_a,
            "activity_b": activity_b,
        }
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        task = _make_workflow_task(workflow_name="NormalWorkflow")
        await worker._execute_workflow(task, "test-results")

        # Both activities called in order
        assert call_log == [("a", {"step": 1}), ("b", {"step": 2})]

        # Workflow completed
        worker._send_workflow_result.assert_called_once()
        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"] == {"r1": {"a_out": 1}, "r2": {"b_out": 2}}

    @pytest.mark.asyncio
    async def test_activity_index_increments(self):
        """Each execute_activity call gets a unique incrementing index."""
        indices = []

        async def spy_activity(input_data):
            return {"ok": True}

        spy_activity.__activity_name__ = "spy"

        @wf_module.defn
        class IndexWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                await ctx.execute_activity(spy_activity, {})
                indices.append(ctx._current_activity_index)
                await ctx.execute_activity(spy_activity, {})
                indices.append(ctx._current_activity_index)
                await ctx.execute_activity(spy_activity, {})
                indices.append(ctx._current_activity_index)
                return {}

        worker = _make_worker()
        worker.workflows = {"IndexWorkflow": IndexWorkflow}
        worker.activities = {"spy": spy_activity}
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        task = _make_workflow_task(workflow_name="IndexWorkflow")
        await worker._execute_workflow(task, "test-results")

        assert indices == [1, 2, 3]


# ===========================================================================
# 2. Error + resume flow — fail on activity, resume with cached results
# ===========================================================================

class TestErrorResumeFlow:
    """Workflow fails mid-execution, then resumes with completed_activities."""

    @pytest.mark.asyncio
    async def test_failure_sends_failed_result(self):
        call_log = []

        async def good_activity(input_data):
            call_log.append("good")
            return {"good": True}

        async def bad_activity(input_data):
            call_log.append("bad")
            raise RuntimeError("disk full")

        good_activity.__activity_name__ = "good_activity"
        bad_activity.__activity_name__ = "bad_activity"

        @wf_module.defn
        class FailingWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                r1 = await ctx.execute_activity(good_activity, {})
                r2 = await ctx.execute_activity(bad_activity, {})
                return {"r1": r1, "r2": r2}

        worker = _make_worker()
        worker.workflows = {"FailingWorkflow": FailingWorkflow}
        worker.activities = {
            "good_activity": good_activity,
            "bad_activity": bad_activity,
        }
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        task = _make_workflow_task(workflow_name="FailingWorkflow")
        await worker._execute_workflow(task, "test-results")

        assert "good" in call_log
        assert "bad" in call_log

        # Should send failed result
        worker._send_workflow_result.assert_called_once()
        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "failed"
        assert "disk full" in kw["error"].message

    @pytest.mark.asyncio
    async def test_resume_replays_completed_skips_to_failed(self):
        """Resume with activity 1 cached → activity 1 is NOT re-executed,
        activity 2 (previously failed) now succeeds."""
        call_log = []

        async def good_activity(input_data):
            call_log.append("good")
            return {"good": True}

        async def fixed_activity(input_data):
            call_log.append("fixed")
            return {"fixed": True}

        good_activity.__activity_name__ = "good_activity"
        fixed_activity.__activity_name__ = "fixed_activity"

        @wf_module.defn
        class ResumableWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                r1 = await ctx.execute_activity(good_activity, {})
                r2 = await ctx.execute_activity(fixed_activity, {})
                return {"r1": r1, "r2": r2}

        worker = _make_worker()
        worker.workflows = {"ResumableWorkflow": ResumableWorkflow}
        worker.activities = {
            "good_activity": good_activity,
            "fixed_activity": fixed_activity,
        }
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        # Resume with activity index 1 already completed
        task = _make_workflow_task(
            workflow_name="ResumableWorkflow",
            completed_activities=[
                CompletedActivity(
                    index=1, name="good_activity", output={"good": "cached"}
                )
            ],
        )
        await worker._execute_workflow(task, "test-results")

        # good_activity was NOT re-executed (replayed from cache)
        assert "good" not in call_log
        # fixed_activity WAS executed
        assert "fixed" in call_log

        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"]["r1"] == {"good": "cached"}  # from cache
        assert kw["output"]["r2"] == {"fixed": True}  # fresh execution


# ===========================================================================
# 3. Fan-out workflow — parallel dispatch via execute_fan_out_activity
# ===========================================================================

class TestFanOutWorkflow:
    """Fan-out dispatches N tasks, checkpoint-exits, resumes with aggregated results."""

    @pytest.mark.asyncio
    async def test_fan_out_sends_request_and_checkpoint_exits(self):
        """execute_fan_out_activity should send a fan_out_request via Kafka
        and immediately raise WorkflowCheckpointExit."""

        @wf_module.defn
        class FanOutWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                # Step 1: local activity
                await ctx.execute_activity("local_prep", {})
                # Step 2: fan-out (3 parallel tasks)
                results = await ctx.execute_fan_out_activity(
                    "remote_process",
                    [{"batch": 0}, {"batch": 1}, {"batch": 2}],
                    start_to_close_timeout_ms=600_000,
                )
                return {"fan_out_results": results}

        async def local_prep(input_data):
            return {"prepared": True}

        local_prep.__activity_name__ = "local_prep"

        worker = _make_worker()
        worker.workflows = {"FanOutWorkflow": FanOutWorkflow}
        worker.activities = {"local_prep": local_prep}
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        task = _make_workflow_task(workflow_name="FanOutWorkflow")
        await worker._execute_workflow(task, "test-results")

        # Workflow should checkpoint-exit (no workflow result sent)
        worker._send_workflow_result.assert_not_called()

        # Verify fan_out_request was sent via Kafka
        worker._producer.send_and_wait.assert_called()
        # First call is from _report_local_activity_result or fan-out
        # Find the fan_out_request call
        fan_out_calls = [
            c for c in worker._producer.send_and_wait.call_args_list
            if c.kwargs.get("value", {}).get("request_type") == "fan_out_request"
        ]
        assert len(fan_out_calls) == 1
        payload = fan_out_calls[0].kwargs["value"]
        assert payload["activity_name"] == "remote_process"
        assert payload["activity_index"] == 2  # local_prep was index 1
        assert payload["inputs"] == [{"batch": 0}, {"batch": 1}, {"batch": 2}]
        assert payload["workflow_id"] == "wf-001"

    @pytest.mark.asyncio
    async def test_fan_out_occupies_single_activity_index(self):
        """The entire fan-out should occupy exactly one activity index,
        not N indices (one per input)."""
        mock_worker = MagicMock()
        mock_worker._can_continue_processing = None
        mock_worker.execute_remote_fan_out_activity = AsyncMock(
            side_effect=WorkflowCheckpointExit("checkpoint")
        )
        mock_worker._report_local_activity_result = AsyncMock()

        ctx = WorkflowContext(
            activities={"local": AsyncMock(return_value={})},
            workflow_id="wf-001",
            worker=mock_worker,
        )

        # activity index 1
        await ctx.execute_activity("local", {})
        assert ctx._current_activity_index == 1

        # fan-out → index 2 (single index for ALL 5 inputs)
        with pytest.raises(WorkflowCheckpointExit):
            await ctx.execute_fan_out_activity(
                "remote",
                [{"i": i} for i in range(5)],
            )
        assert ctx._current_activity_index == 2  # NOT 6

    @pytest.mark.asyncio
    async def test_fan_out_resume_with_aggregated_results(self):
        """After fan-out completes on the server, the workflow resumes with
        the aggregated results as the cached output for that activity index."""

        @wf_module.defn
        class FanOutResumeWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                prep = await ctx.execute_activity("local_prep", {})
                # Fan-out was index 2 — server stores aggregated result here
                results = await ctx.execute_fan_out_activity(
                    "remote_process",
                    [{"batch": 0}, {"batch": 1}, {"batch": 2}],
                )
                # Post-processing after fan-out
                final = await ctx.execute_activity("local_merge", {"results": results})
                return final

        async def local_prep(input_data):
            return {"prepared": True}

        async def local_merge(input_data):
            return {"merged": len(input_data["results"])}

        local_prep.__activity_name__ = "local_prep"
        local_merge.__activity_name__ = "local_merge"

        worker = _make_worker()
        worker.workflows = {"FanOutResumeWorkflow": FanOutResumeWorkflow}
        worker.activities = {"local_prep": local_prep, "local_merge": local_merge}
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        # Simulate server sending resume with completed_activities:
        # index 1 = local_prep (cached)
        # index 2 = fan-out aggregated result (list of 3 outputs, ordered by fan_out_index)
        task = _make_workflow_task(
            workflow_name="FanOutResumeWorkflow",
            completed_activities=[
                CompletedActivity(
                    index=1, name="local_prep", output={"prepared": True}
                ),
                CompletedActivity(
                    index=2,
                    name="remote_process",
                    output=[
                        {"batch_0_result": "ok"},
                        {"batch_1_result": "ok"},
                        {"batch_2_result": "ok"},
                    ],
                    is_remote=True,
                ),
            ],
        )

        await worker._execute_workflow(task, "test-results")

        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        # local_merge received the 3-element list
        assert kw["output"] == {"merged": 3}

    @pytest.mark.asyncio
    async def test_fan_out_request_payload_matches_server_schema(self):
        """The Kafka payload sent by execute_remote_fan_out_activity must
        match the server's FanOutRequest schema exactly."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_fan_out_activity(
                workflow_id="wf-042",
                activity_name="process_batch",
                activity_index=3,
                inputs=[{"i": 0}, {"i": 1}],
                timeout_ms=120_000,
            )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        # Required fields for server FanOutRequest
        assert payload["request_type"] == "fan_out_request"
        assert payload["workflow_id"] == "wf-042"
        assert payload["activity_name"] == "process_batch"
        assert payload["activity_index"] == 3
        assert payload["inputs"] == [{"i": 0}, {"i": 1}]
        assert payload["timeout_ms"] == 120_000
        assert payload["requester_worker_id"] == "worker-A"
        assert "request_id" in payload
        assert "correlation_id" in payload
        assert "created_at" in payload

    @pytest.mark.asyncio
    async def test_fan_out_kafka_key_is_workflow_id(self):
        """Fan-out request should be keyed by workflow_id for Kafka partitioning."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_fan_out_activity(
                workflow_id="wf-099",
                activity_name="x",
                activity_index=1,
                inputs=[{}],
            )

        key = worker._producer.send_and_wait.call_args.kwargs["key"]
        assert key == b"wf-099"


# ===========================================================================
# 4. Fan-out partial error — some tasks fail, error state, resume
# ===========================================================================

class TestFanOutPartialErrorAndResume:
    """When some fan-out tasks fail, the workflow enters error state.
    After the issue is resolved, the workflow can be resumed."""

    @pytest.mark.asyncio
    async def test_fan_out_dispatch_then_error_then_resume(self):
        """Full lifecycle:
        1. First run: local_prep → fan-out → checkpoint-exit
        2. Server records error (some fan-out tasks failed)
        3. Resume: replay local_prep + fan-out (all succeeded this time) → final merge
        """
        execution_count = {"prep": 0, "merge": 0}

        async def local_prep(input_data):
            execution_count["prep"] += 1
            return {"prepared": True}

        async def local_merge(input_data):
            execution_count["merge"] += 1
            return {"total": sum(r.get("score", 0) for r in input_data["results"])}

        local_prep.__activity_name__ = "local_prep"
        local_merge.__activity_name__ = "local_merge"

        @wf_module.defn
        class RetryFanOutWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                await ctx.execute_activity(local_prep, {})
                results = await ctx.execute_fan_out_activity(
                    "remote_process",
                    [{"batch": i} for i in range(3)],
                    start_to_close_timeout_ms=600_000,
                )
                merged = await ctx.execute_activity(
                    local_merge, {"results": results}
                )
                return merged

        worker = _make_worker()
        worker.workflows = {"RetryFanOutWorkflow": RetryFanOutWorkflow}
        worker.activities = {"local_prep": local_prep, "local_merge": local_merge}
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        # --- Run 1: first execution, checkpoint-exits at fan-out ---
        task1 = _make_workflow_task(workflow_name="RetryFanOutWorkflow")
        await worker._execute_workflow(task1, "test-results")

        assert execution_count["prep"] == 1
        assert execution_count["merge"] == 0  # never reached
        worker._send_workflow_result.assert_not_called()  # checkpoint-exit

        # --- Simulated: server dispatched fan-out, batch 1 failed ---
        # Server would set workflow error state. No resume sent yet.
        # After the issue is fixed, admin triggers retry.

        # --- Run 2: resume after fan-out retry succeeded ---
        # Server re-ran the fan-out; all 3 succeeded this time.
        # Resume task includes local_prep + fan-out aggregated as completed.
        worker._send_workflow_result.reset_mock()
        execution_count["prep"] = 0
        execution_count["merge"] = 0

        task2 = _make_workflow_task(
            workflow_name="RetryFanOutWorkflow",
            completed_activities=[
                CompletedActivity(
                    index=1, name="local_prep", output={"prepared": True}
                ),
                CompletedActivity(
                    index=2,
                    name="remote_process",
                    output=[
                        {"score": 10},
                        {"score": 20},
                        {"score": 30},
                    ],
                    is_remote=True,
                ),
            ],
        )
        await worker._execute_workflow(task2, "test-results")

        # local_prep was replayed, not re-executed
        assert execution_count["prep"] == 0
        # local_merge was executed fresh
        assert execution_count["merge"] == 1

        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"] == {"total": 60}

    @pytest.mark.asyncio
    async def test_fan_out_replay_preserves_index_order(self):
        """When fan-out results are replayed, they must be returned in the
        same order (by fan_out_index) as the original inputs."""

        @wf_module.defn
        class OrderedFanOut:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                results = await ctx.execute_fan_out_activity(
                    "process", [{"i": 0}, {"i": 1}, {"i": 2}]
                )
                # Verify order is preserved
                return {"indices": [r["idx"] for r in results]}

        worker = _make_worker()
        worker.workflows = {"OrderedFanOut": OrderedFanOut}
        worker.activities = {}
        worker._send_workflow_result = AsyncMock()

        # Resume with fan-out results in index order
        task = _make_workflow_task(
            workflow_name="OrderedFanOut",
            completed_activities=[
                CompletedActivity(
                    index=1,
                    name="process",
                    output=[
                        {"idx": 0, "data": "a"},
                        {"idx": 1, "data": "b"},
                        {"idx": 2, "data": "c"},
                    ],
                    is_remote=True,
                ),
            ],
        )
        await worker._execute_workflow(task, "test-results")

        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"]["indices"] == [0, 1, 2]


# ===========================================================================
# 5. Resume with handover to a different worker instance
# ===========================================================================

class TestResumeHandoverToNewWorker:
    """When a workflow resumes, it may be picked up by a different worker
    instance in the consumer group. The replay mechanism must work
    regardless of which worker picks it up."""

    @pytest.mark.asyncio
    async def test_resume_on_different_worker_replays_correctly(self):
        """Worker-A ran the workflow originally, Worker-B picks up the resume."""
        call_log = []

        async def step_a(input_data):
            call_log.append("step_a")
            return {"a": 1}

        async def step_b(input_data):
            call_log.append("step_b")
            return {"b": 2}

        async def step_c(input_data):
            call_log.append("step_c")
            return {"c": 3}

        step_a.__activity_name__ = "step_a"
        step_b.__activity_name__ = "step_b"
        step_c.__activity_name__ = "step_c"

        @wf_module.defn
        class HandoverWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                r1 = await ctx.execute_activity(step_a, {})
                # Remote activity → checkpoint-exit on Worker-A
                r2 = await ctx.execute_activity("remote_step", {})
                r3 = await ctx.execute_activity(step_c, {"prev": r2})
                return {"r1": r1, "r2": r2, "r3": r3}

        # Worker-B picks up the resume (different worker_id)
        worker_b = _make_worker(worker_id="worker-B")
        worker_b.workflows = {"HandoverWorkflow": HandoverWorkflow}
        worker_b.activities = {
            "step_a": step_a,
            "step_b": step_b,
            "step_c": step_c,
        }
        worker_b._send_workflow_result = AsyncMock()
        worker_b._report_local_activity_result = AsyncMock()

        # Resume task sent by server to any worker in the consumer group.
        # Worker-A originally ran steps 1-2; server recorded both as completed.
        task = _make_workflow_task(
            workflow_name="HandoverWorkflow",
            completed_activities=[
                CompletedActivity(index=1, name="step_a", output={"a": 1}),
                CompletedActivity(
                    index=2, name="remote_step", output={"remote": "done"},
                    is_remote=True,
                ),
            ],
        )

        await worker_b._execute_workflow(task, "test-results")

        # step_a and remote_step should NOT be re-executed (replayed)
        assert "step_a" not in call_log
        # step_c SHOULD be executed
        assert "step_c" in call_log

        kw = worker_b._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"]["r1"] == {"a": 1}  # replayed
        assert kw["output"]["r2"] == {"remote": "done"}  # replayed
        assert kw["output"]["r3"] == {"c": 3}  # fresh

    @pytest.mark.asyncio
    async def test_resume_handover_with_fan_out(self):
        """Worker-A dispatched fan-out, Worker-B picks up the resume after
        all fan-out tasks completed on the server."""
        call_log = []

        async def init_step(input_data):
            call_log.append("init")
            return {"init": True}

        async def finalize_step(input_data):
            call_log.append("finalize")
            return {"count": len(input_data["fan_results"])}

        init_step.__activity_name__ = "init_step"
        finalize_step.__activity_name__ = "finalize_step"

        @wf_module.defn
        class HandoverFanOutWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                await ctx.execute_activity(init_step, {})
                fan_results = await ctx.execute_fan_out_activity(
                    "batch_process",
                    [{"b": i} for i in range(4)],
                )
                final = await ctx.execute_activity(
                    finalize_step, {"fan_results": fan_results}
                )
                return final

        # Worker-B (different from Worker-A which originally ran)
        worker_b = _make_worker(worker_id="worker-B")
        worker_b.workflows = {"HandoverFanOutWorkflow": HandoverFanOutWorkflow}
        worker_b.activities = {"init_step": init_step, "finalize_step": finalize_step}
        worker_b._send_workflow_result = AsyncMock()
        worker_b._report_local_activity_result = AsyncMock()

        task = _make_workflow_task(
            workflow_name="HandoverFanOutWorkflow",
            completed_activities=[
                CompletedActivity(index=1, name="init_step", output={"init": True}),
                CompletedActivity(
                    index=2,
                    name="batch_process",
                    output=[
                        {"result": "r0"},
                        {"result": "r1"},
                        {"result": "r2"},
                        {"result": "r3"},
                    ],
                    is_remote=True,
                ),
            ],
        )

        await worker_b._execute_workflow(task, "test-results")

        # init_step replayed, finalize_step fresh
        assert "init" not in call_log
        assert "finalize" in call_log

        kw = worker_b._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"] == {"count": 4}

    @pytest.mark.asyncio
    async def test_worker_id_does_not_affect_replay(self):
        """The worker_id of the resuming worker is independent of the
        original worker. Completed activities are identified by index only."""
        ctx = WorkflowContext(
            activities={"local": AsyncMock(return_value={"fresh": True})},
            workflow_id="wf-001",
            worker=None,
            completed_activities={
                1: {"cached_from_worker_a": True},
                2: [{"fan_0": "ok"}, {"fan_1": "ok"}],
            },
        )

        # Index 1 → cached
        r1 = await ctx.execute_activity("local", {})
        assert r1 == {"cached_from_worker_a": True}

        # Index 2 → cached (fan-out aggregated result)
        r2 = await ctx.execute_fan_out_activity("remote", [{"x": 0}, {"x": 1}])
        assert r2 == [{"fan_0": "ok"}, {"fan_1": "ok"}]

        # Index 3 → fresh execution
        r3 = await ctx.execute_activity("local", {})
        assert r3 == {"fresh": True}


# ===========================================================================
# 6. Server↔SDK message contract tests
# ===========================================================================

class TestServerSDKContract:
    """Verify the Kafka message payloads match what the server expects."""

    @pytest.mark.asyncio
    async def test_activity_request_contract(self):
        """Single remote activity request matches server ActivityRequest schema."""
        worker = _make_worker()

        mock_response = AsyncMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={"status": "completed"})
        mock_response.__aenter__ = AsyncMock(return_value=mock_response)
        mock_response.__aexit__ = AsyncMock(return_value=False)

        mock_session = AsyncMock()
        mock_session.get = MagicMock(return_value=mock_response)
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            with pytest.raises(WorkflowCheckpointExit):
                await worker.execute_remote_activity(
                    workflow_id="wf-001",
                    activity_name="remote_act",
                    activity_index=5,
                    input_data={"key": "val"},
                    timeout_ms=30000,
                )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        # Server schema: ActivityRequest
        assert payload["request_type"] == "activity_request"
        assert payload["workflow_id"] == "wf-001"
        assert payload["activity_name"] == "remote_act"
        assert payload["activity_index"] == 5
        assert payload["input"] == {"key": "val"}
        assert payload["timeout_ms"] == 30000
        assert payload["requester_worker_id"] == "worker-A"

    @pytest.mark.asyncio
    async def test_fan_out_request_contract(self):
        """Fan-out request matches server FanOutRequest schema."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_fan_out_activity(
                workflow_id="wf-002",
                activity_name="batch_act",
                activity_index=3,
                inputs=[{"i": 0}, {"i": 1}, {"i": 2}],
                timeout_ms=120000,
            )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        # Server schema: FanOutRequest
        assert payload["request_type"] == "fan_out_request"
        assert payload["workflow_id"] == "wf-002"
        assert payload["activity_name"] == "batch_act"
        assert payload["activity_index"] == 3
        assert payload["inputs"] == [{"i": 0}, {"i": 1}, {"i": 2}]
        assert payload["timeout_ms"] == 120000
        assert payload["requester_worker_id"] == "worker-A"

    @pytest.mark.asyncio
    async def test_resume_task_completed_activities_round_trip(self):
        """The completed_activities in a resume WorkflowTask must be
        parseable by the SDK's WorkflowTask model."""
        # Simulate what the server sends
        server_payload = {
            "task_id": "task-resume",
            "task_type": "workflow",
            "workflow_id": "wf-001",
            "workflow_name": "TestWorkflow",
            "input": {"request_id": "req-1"},
            "timeout_ms": 300000,
            "created_at": "2025-01-01T00:00:00Z",
            "completed_activities": [
                {"index": 1, "name": "local_step", "output": {"a": 1}, "is_remote": False},
                {
                    "index": 2,
                    "name": "fan_out_step",
                    "output": [{"r0": "ok"}, {"r1": "ok"}, {"r2": "ok"}],
                    "is_remote": True,
                },
            ],
        }

        task = WorkflowTask(**server_payload)
        assert len(task.completed_activities) == 2
        assert task.completed_activities[0].index == 1
        assert task.completed_activities[0].output == {"a": 1}
        assert task.completed_activities[1].index == 2
        assert task.completed_activities[1].output == [{"r0": "ok"}, {"r1": "ok"}, {"r2": "ok"}]
        assert task.completed_activities[1].is_remote is True
