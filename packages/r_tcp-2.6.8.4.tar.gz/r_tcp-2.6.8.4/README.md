# R-TCP (HioSW Protocol Stack)

**R-TCP** — это сетевой стек на базе протокола HioSW, предназначенный для защищенной передачи данных и текстовых сообщений (**TnDM**). Библиотека поддерживает автоматическое повышение привилегий в Windows и работу в режимах клиента и сервера (Node).

## 🚀 Основные возможности
*   **TnDM (Text over Data Mode)** — встроенная система обмена текстовыми сообщениями (SMS).
*   **GSM Mode** — передача HTML-файлов и документов.
*   **Auto-Admin** — автоматический запрос прав администратора (UAC) для работы с сетевыми портами.
*   **Hybrid Node** — работа как через интерактивное CLI-меню, так и программно через SDK.

## 🛠 Установка

```bash
pip install r-tcp
## 🛠 Импорты
from rtcp import R_TCP

# 1. Инициализация ноды в режиме клиента
client = R_TCP(target_ip="192.168.1.100").node(False)

# 2. Отправка текстового сообщения через TnDM
client.send_tndm("Привет! Это сообщение через стек R-TCP.")

# 3. Запуск ноды в режиме сервера (Listen)
# server = R_TCP().node(True)

ENG
# R-TCP (HioSW Protocol Stack)

**R-TCP** is a network stack based on the HioSW protocol, designed for secure data and text messaging (**TnDM**). The library supports automatic privilege escalation in Windows and operation in client and server (Node) modes.

## 🚀 Key Features
* **TnDM (Text over Data Mode)** — built-in text messaging (SMS).
* **GSM Mode** — Transferring HTML files and documents.
* **Auto-Admin** — Automatically requesting administrator privileges (UAC) to work with network ports.
* **Hybrid Node** — Works both via the interactive CLI menu and programmatically via the SDK.

## 🛠 Installation

```bash
pip install r-tcp
## 🛠 Imports
from rtcp import R_TCP

# 1. Initializing the node in client mode
client = R_TCP(target_ip="192.168.1.100").node(False)

# 2. Sending a text message via TnDM
client.send_tndm("Hello! This message is sent via the R-TCP stack.")

# 3. Starting the node in server mode (Listen)
# server = R_TCP().node(True)



