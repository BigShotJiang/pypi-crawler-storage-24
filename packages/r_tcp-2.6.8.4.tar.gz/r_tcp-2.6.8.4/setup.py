from setuptools import setup, find_packages
import os

# Читаем README.md для длинного описания в PyPI
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="r-tcp",
    version="2.6.8.4",
    author="R-TCP Developer",
    description="HioSW R-TCP Protocol Stack: TnDM (SMS) & GSM Data System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    # --- [ КЛАССИФИКАТОРЫ / ФИЛЬТРЫ ] ---
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.13",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Topic :: Communications :: Chat",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Intended Audience :: Developers",
    ],
    install_requires=[
        "loguru>=0.7.0",
    ],
    python_requires=">=3.7",
    include_package_data=True,
)
