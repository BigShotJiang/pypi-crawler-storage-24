# rtcp/__init__.py (если файл r_tcp_adtmode.py)
from .r_tcp_adtmode import R_TCP

__version__ = "2.5.0"
__all__ = ["R_TCP"]
