# -*- coding: utf-8 -*-
"""
AgentLoop Memory SDK - A mem0-compatible memory SDK powered by Alibaba Cloud CMS.

This SDK provides an interface compatible with mem0 SDK, allowing users to
manage memories through the AgentLoop (CMS) Memory service.

Example:
    >>> from agentloop_memory import AgentLoopMemoryClient, Config
    >>>
    >>> config = Config(
    ...     access_key_id="your_access_key_id",
    ...     access_key_secret="your_access_key_secret",
    ...     endpoint="cms.cn-shanghai.aliyuncs.com"
    ... )
    >>> client = AgentLoopMemoryClient(config, workspace="my-workspace", memory_store="my-store")
    >>>
    >>> # Add a memory
    >>> client.add("I love playing tennis", user_id="user123")
    >>>
    >>> # Search memories
    >>> results = client.search("tennis", user_id="user123")
    >>> print(results)
"""

from agentloop_memory.client import AgentLoopMemoryClient, AsyncAgentLoopMemoryClient
from agentloop_memory.exceptions import ValidationError

from alibabacloud_tea_openapi.models import Config

__all__ = [
    # Clients
    "AgentLoopMemoryClient",
    "AsyncAgentLoopMemoryClient",
    # Config
    "Config",
    # Exceptions
    "ValidationError",
]

__version__ = "0.2.0"
