# [13.51.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.50.0...v13.51.0) (2026-03-24)


### Bug Fixes

* **02:** remove self-referential Conflicts= from exness-seeder service ([15a9c71](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/15a9c717b7626b61064c1bdd9b7df69a00213454))
* **02:** revise plans based on checker feedback ([d4fce06](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d4fce0675d4d097a0f857bf36bffef6040e5e009))
* align all code + docs to (symbol, threshold) partition key ([c21c8a3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c21c8a3e4f6be802962c1a76d1e5b29c6d40a5e1))
* **ch-clean-slate:** brute force Phase 1 — kill everything, no graceful shutdown ([0d5bfaf](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0d5bfaffb796955e5bfaf0f04030bfc33e100351))
* expose process_trades_arrow_native on Python wrapper class ([4f82e09](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4f82e09c722f61e5a770fb5494f540c15c216f96))
* **heartbeat:** bump TimeoutStartSec 60→180 for daily partitions ([f5707d5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f5707d5660b1e9d5956abfa910a10c651b904508))
* **kintsugi:** exclude open_time_ms=0 bars from partition lookup ([601e896](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/601e8967177b5174330ac7d28a1a5008da077b98))
* **monit:** exclude kernel threads from storm detection ([b7272fb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b7272fb6913d2dcb76b991742ddffff3a23b379b))
* **monit:** raise swap threshold 25→60%, clean report format ([3fff499](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3fff499f295d33427210c6b46934a5f14c86edc2))
* **monit:** reorder report layout + RSS breakdown + storm detection ([54495af](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/54495af44dfb4d32e01678d770e22d74efae3f02))
* **monit:** use /var/tmp for temp files instead of /tmp ([ffb800e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ffb800edbe3c4d429815127fa08e1efbf8eda720))
* **monit:** use $HOME for temp files + fix alert Unicode escaping ([172d7b1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/172d7b199b5a34097d9e3401261474cf42f5fd34))
* **repair:** exclude forex symbols — incompatible data format (bid/ask vs aggTrades) ([30d429a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/30d429a8a838057ced02615dec27401d2bc42988))
* **repair:** mandatory process cleanup + thread validation on exit ([e95daf6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e95daf6b0e479dbd5f4b23749c0484d5fa3c2ac1))
* **repair:** normalize µs→ms timestamps inline before Rust processing ([068370e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/068370ef9a7d824e93a2d372631a92e7941fed5b))
* **repair:** use dataclass attribute access for SymbolEntry (not dict.get) ([b26ead7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b26ead78029e0ef45e26dd1ae4fbf0797102afdd))
* revert kintsugi SQL column names to _ms (CH schema not yet migrated) ([31eabde](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/31eabded0315c5114ecda4f9db64bd96d0817087))
* **seeder:** adopt repair_direct_parquet.py memory discipline patterns ([3f7c4ac](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3f7c4ac9036a99965e443572d0e2fc211fff9242))
* **seeder:** clean per-symbol layout — text names, separator lines, no flags ([59ebdb3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/59ebdb3e21be3e5ddf6b0f9eb0b2aea408b34116))
* **seeder:** correct cache % to exclude weekends + verbose per-symbol reports ([23291b9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/23291b92ff4c5357c78561f9df9a60d53b261877))
* **seeder:** eliminate OOM from RSS accumulation during Exness backfill ([640cd00](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/640cd001c1f64ca34f61a583f154d3fa51fff55a))
* **seeder:** fully self-explanatory Telegram messages, no cryptic notation ([1dad697](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1dad6971d3605204b2d0b66df4a8ebc7515dbb3a))
* **seeder:** touch state file during long runs (every 50 days + each monthly ZIP) ([a285eb7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a285eb75bd1c0ec715326a83b82b799c77a688c0))
* **seeder:** touch state file on every invocation to prevent monit stale alert ([9e893f6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9e893f64032020dd52bfbdd2d372f724a05918a1))
* **sidecar:** exclude non-Binance symbols from Argus liveness monitoring ([4dc52dc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4dc52dc8aeb7a5b6537b0bbe303f8735ff4535de))


### Features

* **02-01:** add 10 Exness forex symbols to unified symbol registry ([6a83974](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6a8397460563a85340784b08457a833085b9bc57))
* **02-01:** create ExnessSeederConfig pydantic-settings class ([2531256](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/25312568adc581ef0bf197e1cfa04cdd2942f47e))
* **02-02:** create Exness forex tick cache seeder script ([1f4df03](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1f4df03d216b3710f263e030b2e23a64748cce66))
* **02-03:** create systemd service + timer and monit monitor for Exness seeder ([b931818](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b93181852c02aeeb729dbf396201923a312e76a2))
* **04-01:** seeder preserves us timestamps, pipeline callers use process_trades_arrow_native ([cf38be2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cf38be2a1741418a09ac12237ba47330b113d938))
* **04-01:** TickStorage microsecond-native storage with auto-detect read filtering ([64f4f6d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/64f4f6d1110e45b4f9cb1117f3aea19d7a097233))
* **04-02:** add --verify mode with us-native Arrow path and Stathera validation ([02777f1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/02777f1b5baebfa32b2dc1516ab6584f0925c2d5))
* **04-02:** create Parquet ms->us reseed migration script ([e440fc1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e440fc11bcdf37cace312158049342381e2bb305))
* **05-01:** migrate Rust dict output and Python contracts to microseconds ([e06d4e7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e06d4e7fff41bef9f2346e98bcfa90d4c6290191))
* **05-02:** migrate ClickHouse schema DDL and all CH Python layer from _ms to _us ([5a98ce2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5a98ce22dd8313534b8ed75eb6bb859923519e13))
* **05-02:** update repair_direct_parquet.py to output us-native columns ([734d475](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/734d475aaefe2b0f46f15e46806dc844e0c46bf7))
* **05-03:** migrate heartbeat checks and production scripts to microsecond timestamps ([1fc3abd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1fc3abdd008a4bd59bdda7bd802afbad53d321ab))
* **05-03:** migrate sidecar and kintsugi modules to microsecond timestamps ([b98db08](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b98db082a728f2196a0233741d2c0c55ff455ba6))
* add ch-clean-slate skill for full ClickHouse rebuild ([cb416ec](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb416ec559da0763648a6da280c7c597ee2483ff))
* **clickhouse:** migrate partition key to (symbol, threshold) only ([2c777dc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2c777dccd7f97d5c9f4b059d281352144d005bc9))
* **monit:** memory map from /proc/meminfo + disable GUI on bigblack ([7729e57](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7729e5701cc8d4bc43273db6fd75ec91a966036c))
* **monit:** rich health spectrum + environment integrity monitoring ([eb19c39](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/eb19c3965fceb63ec8ca866405a6ca3132739fcf))
* **registry:** add tick_cache_key to all symbols in symbols.toml ([323609f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/323609f8422d5a4285eddca38b46e00d2fc75b08))
* **repair:** add --all flag for registry-driven sequential repair ([da9b4bd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/da9b4bd88ec7f1e873727a3bdf52c9f3ff5b0d3c))
* **repair:** order by kintsugi_priority + use tick_cache_key from registry ([c7b0717](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c7b0717663cafc4574a5e049a37e1d1768ccd185))
* **repair:** prioritize crypto before forex in --all ordering ([62127bc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/62127bcda515b47a342b39c6b25dcf986cdad894))
* **seeder:** 1-min timer + silent no-ops + monit 3-min freshness ([fe8a8a9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fe8a8a914cfec3ae86a58681cbf662b628729a92))
* **seeder:** fanciful decorative Telegram report headers ([2fcb6a2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2fcb6a2b61f1d00859f75691c5821b078fd72c44))
* **seeder:** monthly ZIP fallback for full Exness history back to 2020 ([0988d02](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0988d02ba857493b9d83c0e99b115096dc3aa3a3))
* **seeder:** richly decorated Telegram report with flags and dashboards ([111aba8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/111aba8f1fc61def592a419466a422a9c64d0817))
* **seeder:** single-instance lock guard with stale PID cleanup ([6318b04](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6318b04183aa7005a78dc09475c69d190abcbf40))
* **seeder:** store Exness timestamps in microseconds (not milliseconds) ([7a9d871](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7a9d8717f306f65abfb978209826e25b10a6dfa8))
* **seeder:** Telegram lifecycle messaging — startup, per-symbol, errors ([281ef0f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/281ef0f765e71c04d2881f9c2701e0239f8b710b))
* **seeder:** verbose per-symbol Telegram reporting for Exness seeder ([812923b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/812923bac1651116eb07870f5e5295d277ac4644))
* **timer:** increase Exness seeder frequency from 1h to 15min ([6f77cdb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6f77cdb94f9135e950a493b3876e1884d1d7b479))


### Performance Improvements

* **repair:** increase default workers to 1.5x CPU cores (48 on bigblack) ([061798a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/061798a84850e2760f0ed109a5ad3097283d9c24))
* **sidecar): compound DELETE + conditional OPTIMIZE; feat(seeder:** REST-first T-1 ([0986ee4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0986ee47f0613d3f12e8f547fe32f5857ba0cec9))

# [13.50.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.49.0...v13.50.0) (2026-03-23)


### Bug Fixes

* **01-01:** add missing test imports after live_engine modularization ([16dd68f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/16dd68fef622075c780758e98c7200f8360fc85e))
* **01-02:** update mock.patch targets for checkpoint package split ([4f94382](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4f94382a3d178e56b8699f4a95852605d72185e3))
* **01-03:** add missing _WATERMARK_*_RATIO re-exports to backfill.py ([c2af5f8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c2af5f866e6ac2859d16f5578970fbbb79019220))
* remove telegram log sink test that sends real messages ([c30b9d2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c30b9d2e97b8c36f28cdfefec73f0435e37e96ba))


### Features

* **clickhouse:** migrate partition key from toYYYYMM to toYYYYMMDD ([b73f3be](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b73f3be1ca7f78d89a68d54d42021c060feba289))


### Performance Improvements

* **clickhouse:** DELETE IN PARTITION instead of full table scan ([4e06723](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4e06723aa244354dd482f66302d8747830d34d61))

# [13.49.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.48.2...v13.49.0) (2026-03-23)


### Bug Fixes

* **clickhouse:** OPTIMIZE FINAL after every _do_replace DELETE+INSERT ([f9cefb0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f9cefb0ec953417d9221ab1ea7e01812121f88dc))
* **clickhouse:** replace lightweight DELETE FROM with traditional ALTER TABLE DELETE ([65d8236](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/65d82369908651358191417cabdceb0ddf350b2f)), closes [#269](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/269)
* **kintsugi:** has_ticks off-by-one — day_end_ms spans two days ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([bf7864a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bf7864a8ebed9e749cef14fdaca8a8fa5195e913))
* **kintsugi:** set is_genesis=True for yesterday signal shards ([7988830](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/798883019ea8ba12d6a3f6faf1a49ec3e4ec1a08))
* **sidecar:** first-principles midnight crossover — CH seed + REST verification ([df1cb34](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/df1cb34be19d21e672011192e49d624a07d88909))
* **sidecar:** replace hop-based fromId scan with time-bracket crossover ([4d0567a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4d0567af4a99a1756e0d8e065380dd6261a38e1a))
* **tests:** partial watchdog test fixes for sidecar modularization ([0e2f187](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0e2f187775affc80a3fc848a1811bf9ac6185073))
* **tests:** replace hanging watchdog integration tests with recovery unit tests ([5317077](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5317077b58375f41da17eac1a03d76146b0e7cb1))
* **tests:** update mock targets for sidecar modularization + stathera 5-col ([8675db3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8675db33272611d2ba8c4fa58d956f734161020e))


### Features

* **01-01:** add signal.py + _check_yesterday_integrity() with TDD tests ([bdcb289](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bdcb2892f9b57c8b68dbcc8e39581087d588fb5e))
* **01-01:** wire _check_yesterday_integrity into sidecar startup ([89cda4b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/89cda4bf9e6a62f29cbb7d59ff3dccaf234c5482))
* **02-01:** add clear_yesterday_signal + _load_yesterday_priority_shards ([b040880](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b040880eaf7a11edb7a3a1033167aaa3ea8add7d))
* **02-01:** wire yesterday priority queue into kintsugi_pass ([c084771](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c0847715baca8dd8bcadc3e1fa66ed4960a0e773))
* **sidecar:** self-validating midnight crossover with 3-property proof ([9134a24](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9134a2471906697d44dd445f614e48d8e0e6cd59))

## [13.48.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.48.1...v13.48.2) (2026-03-23)

## [13.48.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.48.0...v13.48.1) (2026-03-23)


### Bug Fixes

* **tests:** update Arrow error type + ratelimit_ok warning key ([b73c78d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b73c78db18d7abe7eed6292c26ccf981f4b3e5fd))

# [13.48.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.47.0...v13.48.0) (2026-03-23)


### Features

* **06-04:** MEM-04 skip plugin roundtrip + MEM-05 footer-only row counting ([7937476](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7937476b1dd14c08d614fe7910df5362a47ce2ba))
* **06-04:** MEM-06 REST Arrow streaming + MEM-07 merge with_columns ([79810fb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/79810fb55cd7a2b41f32aa9eed7bac7759409398))

# [13.47.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.46.0...v13.47.0) (2026-03-23)


### Bug Fixes

* replace clone() with copy semantics for AggTrade (clippy clone_on_copy) ([32d649a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/32d649a48cfc64022957d998208c79d288da1a48))
* **sidecar:** verify+repair yesterday before clean-slate today ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([557e1ba](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/557e1bad51bbbf92e9b5e583b98d253c1fa3b4eb))
* use clone() in replay_buffer for crates.io packaging compatibility ([87d562c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/87d562ca16ef1546b0037030d3cf1c553de3fec8))


### Features

* **#300:** MEM-01/02/03 — AggTrade Copy, Arrow iterator adapter, GIL release ([2fd054b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2fd054b6400668ad65c4f732210c01bf6aa7791a)), closes [#300](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/300)
* **#300:** MEM-05 footer row counting, canonical tick schema, state updates ([cc55c83](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cc55c834e20aa5a7e41ad30c1d6b9df3cd8003bb)), closes [#300](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/300)
* **06-02:** MEM-08 FormingBar watch throttle to 1 Hz ([6f2e632](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6f2e632cb718cf53d85f34a2dd6983d1c6d49f74))

# [13.46.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.45.0...v13.46.0) (2026-03-23)


### Bug Fixes

* **sidecar:** per-pair selective DELETE instead of all-or-nothing ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([6159c6a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6159c6aeb16c22a44794c30ee72f3510a90f35d3)), closes [hi#threshold](https://github.com-terrylica/hi/issues/threshold)
* **sidecar:** pre-fill clean slate DELETE replaces post-write cleanup ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([fd6d2b7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fd6d2b79f66a5ce9682fb79bf52f34da2eea43fd))
* **sidecar:** promote sync_flush rejection logging to INFO for root cause tracing ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([158a7bb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/158a7bbc2e6e13209ad56e6d328766ab3cad754d))
* **tests:** update test_heal_scoping for removed _check_and_heal_overlaps ([1fe661f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1fe661f74de008220478229552a6f4b191716292)), closes [#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)


### Features

* **#299:** Arrow zero-copy pipeline for repair_direct_parquet.py ([728f6c6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/728f6c63e45ddf5952d1ccb143d83e1dba064159)), closes [#299](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/299)
* **05-01:** add trade-ID continuity validation and route seeder through write_ticks() ([d085766](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d085766f8ed49f6718aef4503a5ee6a5b6f566e8))
* **05-02:** add RateLimitCoordinator with file-based cross-process state sharing ([43fe4af](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/43fe4af09c1d3769548b1a4c03ee139ba00983b2))
* **05-02:** expose PyAdaptiveRateLimiter via PyO3 and wrap kintsugi REST calls ([4f5ce67](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4f5ce67b1e3bcb67201f192f9809edcc3182cca1))
* **05-03:** add REST fallback, batch rotation, and kintsugi guard to seeder ([92e3e9f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/92e3e9f935eed012d06c4d451ecc7a1cb85a5756))
* **05-04:** add ratelimit heartbeat check for aggregate REST utilization ([5043c3a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5043c3a2861107e16d8527bdf5435649925e06e3))
* **05-04:** add weekly Vision vs REST oracle check (D-10) ([c01e5a5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c01e5a5359227777643a3d8b946b2082111bd16f))
* **05-04:** enhance seeder heartbeat with days-behind, Vision 404, budget metrics ([b15d1ad](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b15d1ad8df0e59503ac7ae2bab4ee3c247581508))

# [13.45.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.44.1...v13.45.0) (2026-03-22)


### Bug Fixes

* **providers:** collapse nested if blocks (clippy) ([4daccdb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4daccdb79aa2879aa1d4d6897828722151b45ec9))
* **sidecar:** remove FORMAT JSON from verification gate queries ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([689de59](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/689de59d9b6b32ec6a311dcc9a5a742093ecfafb))
* **sidecar:** verification gate before DELETE prevents unrecoverable gaps ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([9a4d20d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9a4d20d5831dd0eed4b28dd1471474530c236cef))


### Features

* **04-01:** add ping/pong deadline, ban handling, stream signals, and rate limiter to combined_ws.rs ([11cd837](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/11cd83750c0ae0ed332d37f43b532a2ad9d9669c))
* **04-01:** add WS error variants, keepalive config, stream signal enum, and client-side ping to websocket.rs ([8d51096](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8d51096e081a6851415dd44c8c64428415446bd6))
* **04-02:** add stream signal tracking to sidecar health endpoint ([bf638b8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bf638b87db051140e26680a8835d19a3d0c581e6))
* **04-02:** add WS error classification check to heartbeat ([ad6b154](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad6b1544fb99d263d077d37075285ea1c41f50d1))

## [13.44.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.44.0...v13.44.1) (2026-03-22)


### Bug Fixes

* **sidecar:** lightweight DELETE + immediate KILL + OPTIMIZE for cleanup ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([e45c9a5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e45c9a5bdea55e56c81dc3a01b736cc7b08738ab))


### Performance Improvements

* **streaming:** dynamic chunk sizing + concurrency 5→3 for fill_from_rest ([#297](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/297)) ([6850b3f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6850b3f4a8a0b0e0c370b0e7427868fda130058f))

# [13.44.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.43.3...v13.44.0) (2026-03-22)


### Bug Fixes

* **sidecar:** DELETE-after-INSERT for stale today bars + immediate kill ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([22d2e84](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/22d2e849b29d6f73006fb9c793fb590cc0834d2e))
* **sidecar:** kill all mutations + OPTIMIZE after sync_flush ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([54c3cc1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/54c3cc171be51d306f1cc6ce0ad73818b593ad63))
* **sidecar:** remove _delete_today_bars — INSERT-only restart ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295) P0) ([7cbd767](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7cbd767c84bc848c9f15fb77723f2362338cc157))
* **sidecar:** skip CH seeding in fill_from_rest — midnight preflight only ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([7845182](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7845182ee3417759c4d618c612db39f117315b7c))
* **sidecar:** use ALTER TABLE DELETE (traditional) for stale bar cleanup ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([1c3cf28](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1c3cf28337c5255e1a4d58240abf6d498688b8e8))
* **skills:** odb-ship past tense for removed _delete_today_bars ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([4149808](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4149808a42edf7b5e6161ff142c2cf11fa7018f2))


### Features

* **#297:** heartbeat queue progress, deploy tasks, parallel fetch optimizer, odb-ship hardening ([8b8d18b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8b8d18b27462abb223bf2cb10a98c8aa08c08ef7)), closes [#297](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/297) [#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)

## [13.43.3](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.43.2...v13.43.3) (2026-03-22)


### Bug Fixes

* **sidecar:** skip checkpoint injection in fill_from_rest mode ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([e16b805](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e16b80502f8f5f3a60db73d3996db6ee5c64186b))
* **sidecar:** use fixed date literal in _delete_today_bars instead of today() ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([863effb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/863effbd130e6d6348fbecd56d8404c1b6a52c27))

## [13.43.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.43.1...v13.43.2) (2026-03-22)


### Bug Fixes

* **sidecar:** downgrade stale-checkpoint and no-orphan logs to INFO ([e3899ad](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e3899ada0d60694d08dad74990e7cfb07f5063c6)), closes [#242](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/242)
* **sidecar:** use INSERT-only for sync_flush instead of DELETE+INSERT ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([7ba7c88](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7ba7c88eee356418f04b2e60012c41bf232afbd3))
* **sidecar:** wrong kwarg name bars_df→bars in sync_flush store_bars_batch ([8cdf7e0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8cdf7e092f14be2bfa82bc588052b09c01f3c333))

## [13.43.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.43.0...v13.43.1) (2026-03-22)


### Bug Fixes

* **streaming:** prevent REST→WS junction overlaps/gaps at sidecar restart ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295)) ([e9976b6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e9976b6355b931b71dfc1004bf823da0b02c207f))

# [13.43.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.42.0...v13.43.0) (2026-03-22)


### Bug Fixes

* **clickhouse:** serialize _do_replace() to prevent mutation deadlock ([#296](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/296)) ([0d75fa6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0d75fa6f4cde13e9b4186703f420a25e63239271))
* **heartbeat:** remove double-wrapping in today-anomaly sym_filter ([952bd0f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/952bd0f4b0076c2f6ad9bcebab6857c9b96dd887))
* **schema:** add missing is_orphan column to ClickHouse schema ([#296](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/296)) ([77fec92](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/77fec929698e15ee14696d9c0883d3cb135ccac6))


### Features

* **sidecar:** add /status endpoint for junction telemetry ([6adfc7a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6adfc7a21e3edf51956b4a7f73f23e3824fd655b))

# [13.42.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.41.0...v13.42.0) (2026-03-22)


### Bug Fixes

* **260321-ql9:** P0-1a ring buffer capacity 100K + P0-4 fatal delete-today ([7dd29b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7dd29b4210553f4fa3d91cafa9751741f7228cb6))
* **260321-ql9:** P0-2 dead-letter on INSERT failure in _do_replace ([abf3a94](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/abf3a94114c37b6ec2de03739834a0a6f7b83b33))
* **clickhouse:** disable CH sessions to prevent SESSION_IS_LOCKED cascade ([fd591c7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fd591c7a5fa8ebc1b5f6733380b31172d80a4b7f))
* **clickhouse:** revert to synchronous DELETE-then-INSERT for store_bars_replacing ([49e2ebf](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/49e2ebf5a8eb4a6b6cda5c1fb96975334c56ced7)), closes [#293](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/293)
* **kintsugi:** downgrade fallback logs to INFO + add source tracking to Telegram ([0727a0d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0727a0df9d771046b130776b60f0e877d53803d0)), closes [#242](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/242)
* **sidecar:** disable overlap self-heal — creates mutation cascade with INSERT-only ([2eff178](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2eff1780ba5e99584041a81ebe5e75fb8c3a789a)), closes [#293](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/293)


### Features

* **260321-ql9:** P0-3 heartbeat today-gap awareness with writer-ownership health logic ([affe37a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/affe37aa6fdd98d470e75f7ab1497558a898a333))

# [13.41.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.40.1...v13.41.0) (2026-03-21)


### Bug Fixes

* **260321-n48:** add overflow logging to fill_from_rest ring buffer pushes ([33009a9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/33009a9f6dd20d7add725f4e2bb68cb7127ac592))
* **260321-n48:** make _delete_today_bars DELETE synchronous ([941aabc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/941aabc4c857fffa8019b9363958bece0fa639e3)), closes [#N48](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/N48)


### Features

* **260321-n48:** add diagnostic logging to _sync_flush_rest_bars ([b98cfad](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b98cfad728d8d138d3e988550268fa397e5cf4ad))
* **260321-n48:** add restart diagnostic hint in heartbeat formatter ([23afaca](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/23afaca38de038aa7069e9fa9f2adc45a0cb0375))
* **heartbeat:** 4-tier health levels (CRITICAL/WARNING/DEGRADED/HEALTHY) ([3b80655](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3b8065567eec8e03374f12a6a37ce33bf4129282))

## [13.40.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.40.0...v13.40.1) (2026-03-21)


### Bug Fixes

* **heartbeat:** clarify Stathera delta display (+N new / -N healed) ([cace793](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cace79367cd20f73deeb2cdb1c0923854660508d))
* **sidecar:** seed trade IDs AFTER delete_today to fix restart gaps ([#294](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/294)) ([a79d701](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a79d70137d584731bdbe7e80f6db800cba30afbb)), closes [hi#water](https://github.com-terrylica/hi/issues/water) [hi#water](https://github.com-terrylica/hi/issues/water)

# [13.40.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.39.0...v13.40.0) (2026-03-21)


### Bug Fixes

* **heartbeat:** remove is_orphan column ref, use max(last_agg_trade_id) ([c568325](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c568325688544d365d46ea4d133c53ed819e5917))
* **heartbeat:** today() takes 0 args in stathera today-gap query ([0d77c46](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0d77c468cea9d073fdf2a71b43d4a592a8afa591))
* **heartbeat:** yesterday() takes 0 args + junction unavailable cleanup ([d3c7fd1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d3c7fd1266938913eb35654b63c60e19f188a035))
* **maintenance:** wrap straddle DELETE in try/except to prevent post-INSERT crash ([f3a36c9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f3a36c91e421c8f1cd185aff99fcc249d94c5ed3))
* **tests:** update stale comment referencing removed function ([6ec8fea](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6ec8fea8009fbaf81fa9c6e0440a9b5e71cd8394))
* **tests:** update tests for INSERT-only replace and yesterday query ([2f0391d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2f0391df4933a185cfd3a397573de527f6aab9b6))


### Features

* **heartbeat:** add pending mutations and active parts health check ([a4efb57](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a4efb576d04858b060ff1e9494a288819e9533c9))


### Performance Improvements

* memory efficiency refactoring across Rust core, PyO3 bindings, and Python layer ([da01773](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/da01773baff35ac11dec575fb5cecba89c21550a))

# [13.39.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.38.0...v13.39.0) (2026-03-21)


### Bug Fixes

* **01-02:** wire last_completed_bar_tid into committed_floors and add PyO3 bindings ([416b0c6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/416b0c6e83d4563b75f16597617f90a2d9728654))
* **heartbeat:** replace PyO3 binding with raw HTTP in yesterday check ([8ec103c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8ec103c93d0d259e38177a5374b5dd9ea57afe6d))
* **kintsugi:** filter discovery by registry thresholds, not just min_threshold ([f021428](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f0214281029cfad62f39499e5121fd05300276d7))
* **tests:** exclude benchmark and heavy tests from default pytest run ([e3287cc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e3287cc03aab25cc513137f5ddbec5d133a4b225))


### Features

* **01-01:** add last_completed_bar_tid to processor and checkpoint ([35905d8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/35905d84a8f15c4d3b46f35282253a4aa8c1ec6a))
* **02-01:** add get_yesterday_orphan_tid() ClickHouse query method ([17b5a55](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/17b5a55842727e8e4f9de2d5f0f936f8d807fba6))
* **02-01:** add midnight crossover and orphan verification to sidecar ([bfe6f1f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bfe6f1ff233a58f68d653d0bd638f9c94ca523c1))
* **02-02:** add _run_midnight_preflight and wire into _create_engine ([d15b584](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d15b5842557dc2eb17e39b1a4d4e32b434c21a11))
* **03-01:** unify Stathera check to per-symbol results with today-gap LOUD alert ([534d506](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/534d5067a492d734d97d4a017c6ed73146637c4f))
* **03-01:** update formatter for unified per-symbol Stathera display ([bc71947](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bc71947ab58f7b7cb6a09318923102ba105b8181))
* **03-02:** add yesterday completion and junction telemetry checks ([5d91ebc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5d91ebcdd47f3f477214db6c956af117d57d7742))
* **03-02:** add yesterday completion and junction telemetry sections to formatter ([d7ff788](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d7ff788b39bc7dbfa8ebab55435ad027ba6f95ee))

# [13.38.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.37.0...v13.38.0) (2026-03-21)


### Bug Fixes

* align all 5 blockers with registry SSoT (7-agent audit) ([39ae1a1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/39ae1a1cb3607b9af3dae2d59a5c2cb27439474f))
* remaining 1000 dbps docstring references in threshold.py + orchestration ([d7b0555](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d7b0555a61faf5dabdba1b5b1bdf4fe86114148e))
* remove all hardcoded 1000 dbps references across codebase ([5b0778b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5b0778b5b284e381f8c5609a0f78b79bc6c007df))
* **sidecar:** fresh CH cache per pair in sync_flush — SESSION_IS_LOCKED ([bec0345](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bec0345391e3ed0eaca1cbae0c42c1fc565b5514))
* **sidecar:** single DELETE for clean slate instead of per-pair loop ([d692012](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d692012c4891ceb3512bcf00a60f49b275564b46))


### Features

* **registry:** remove 1000 dbps, add 100 dbps for BTC/ETH/SOL ([98bd56c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/98bd56cdca85a7d1acfa133cd34748550c8eee89)), closes [hi#resolution](https://github.com-terrylica/hi/issues/resolution)
* **sidecar:** clean slate DELETE today before fill_from_rest ([#296](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/296)) ([1eb63d9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1eb63d9ae284856a779ff5038c30775081a3ef52))

# [13.37.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.36.1...v13.37.0) (2026-03-20)


### Bug Fixes

* **sidecar:** add diagnostic logging around sync_flush call site ([ead0f5e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ead0f5ecc3bb2f982d30ca549c107d748440408d))
* **sidecar:** use 500ms timeout in sync_flush ring buffer drain ([7336ebf](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7336ebf16f270ab7a5aeb355faab6cb47dbb9b24))


### Features

* **streaming:** add drain_bars() for synchronous ring buffer drain ([#292](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/292)) ([9f75560](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9f755608d30efeaa2048d542e64b88133f2c29a9))

## [13.36.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.36.0...v13.36.1) (2026-03-20)

# [13.36.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.35.1...v13.36.0) (2026-03-20)


### Features

* **01-01:** replace _write_batch_with_retry with store_bars_replacing in _sync_flush_rest_bars ([f5ccbc5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f5ccbc5bfc44472c72071d92326bb397bc9d90d5))
* **01-02:** scope _heal_day_boundary_gaps to today only (HEAL-01) ([96c6dc5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/96c6dc5177ba25584eed4db1679177d6b934a353))
* **01-02:** use valid_pairs for overlap heal call site (HEAL-02) ([405b4b2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/405b4b204d6b8c0c5c71c5640e1e83e04235f9f2))

## [13.35.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.35.0...v13.35.1) (2026-03-20)


### Bug Fixes

* **sidecar:** filter sync_flush bars by valid_pairs registry gate ([147fcf7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/147fcf7705eed4daa1ef3e08e57adbd16da2d674))

# [13.35.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.34.0...v13.35.0) (2026-03-20)


### Bug Fixes

* **sidecar:** sync flush REST bars to CH before heal runs ([#296](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/296)) ([31691e0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/31691e014511e70427157037baed4d7ad81335c0))
* **tests:** align test mocks with current function signatures ([51fab35](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/51fab352bcb13be364d914e0c41ce8d544cb5d7d))


### Features

* **odb-ship:** add agent team mode for parallel test+build and publish ([57d9f7e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/57d9f7eedf0140fa03f08856c80f1516f5cf724d))

# [13.34.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.33.0...v13.34.0) (2026-03-20)


### Bug Fixes

* **odb-ship:** thorough Phase 4 — OPTIMIZE FINAL, checkpoint clear, Stathera audit ([998c8cb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/998c8cbc62e96bdd0ccb28f145f846186c8a8d07))


### Features

* **01-01:** replace unbounded Thread with bounded ThreadPoolExecutor for Telegram log sink ([e3237c7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e3237c7f9932815c442ce416440fbdf3a9bc876c))
* **02-01:** add 3-tier concurrency control with REST limiting ([7d3102b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7d3102b1a6c26754c6d4013344c407d5d9089327))
* **02-01:** add thread-local CH cache to kintsugi worker functions ([cea48f4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cea48f477f7b87eb323b7487889f14629dcd7f13))
* **03-01:** add FixedPoint::from_f64() and eliminate CSV double-conversion ([bb480d0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bb480d0c5ec6cc8ba581049cafa7255dd755c99b))
* **03-01:** optimize IntraDayChunkIterator with cached CSV decompression ([ff60036](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ff600362a6fd627b9ceda4279e4ae31869af1346))
* **03-02:** reuse burst frame Vec across WS select loop iterations ([065edba](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/065edba44597b1ed4ec1e45c6aae3b6db9b41cdf))
* **04-01:** cache _kintsugi_cfg() in _repair() and add dynamic Vision TTL ([9bcecfc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bcecfc86e9ad1d7e869ac44ba641a885d1fb419))


### Performance Improvements

* **04-01:** remove redundant DataFrame copy in store_bars_bulk() ([8ab09b2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8ab09b220464f43e9caaf8c96ef646fb580fbbad))

# [13.33.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.32.1...v13.33.0) (2026-03-20)


### Features

* Rust-side bar dedup — prevent overlaps at the source ([65a28ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/65a28ae076a7dd53eac79e9c47aae5c055475e88))

## [13.32.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.32.0...v13.32.1) (2026-03-20)


### Bug Fixes

* **deploy:** incorporate playbook patterns into deploy task ([a6af7c1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a6af7c1e0f70ae54046a7cedb54e8c156c48caac))


### Reverts

* overlap_strategy back to "off" — "replace" causes mutation storms ([20d64c8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/20d64c835f1e588a995bc7b08b7e6475b6b91e79))

# [13.32.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.31.0...v13.32.0) (2026-03-20)


### Bug Fixes

* sidecar overlap_strategy "off" → "replace" (auto-delete+rewrite guard) ([e407dca](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e407dca3b38b8ed1aa95fe4f4cecda857dcb0ccd))


### Features

* deploy hardening — safety gates + git SHA logging ([eea0c89](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/eea0c8977b5a90744019d5303cf4d83c15cb06b5))
* sidecar overlap self-heal — detect and repair today's overlaps ([317a3a9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/317a3a94024348d436e12075737a73797b6a03c3))

# [13.31.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.30.0...v13.31.0) (2026-03-20)


### Bug Fixes

* **06-02:** fix trade_count field name and unused policy warning in live_engine ([0f3e004](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0f3e0043c21f6fb12f86d79480bfe93caaeb64f0))
* **kintsugi:** deferred shards don't exhaust budget — prevents tight loop ([bb10135](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bb10135deb5ea31ae9db76ea434ca519c7ef034d))
* rename plan files to match gsd-tools pattern ([4f13a28](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4f13a28e496df8b3a4a80efe26d9a9ecacbe7d65))
* roadmap phase heading format (em-dash → colon) ([893fcf0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/893fcf0d32e0bcfcdfda12852900028fe06bc5f4))
* **sidecar:** fill_from_rest runs when ANY pairs lack checkpoints ([b695580](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b6955809895a9002a68a4c0cb62b16db7e529864))
* **streaming:** fill_from_rest must not break on partial chunks ([979ddcc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/979ddcc1bb755dbf8d7740061fe43e441ea701ea))
* **streaming:** robust fill_from_rest + enable Rust tracing to journal ([1e3084e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1e3084e31b26575a1c5e4e221899fa9d23fda31f))


### Features

* **01-01:** add junction fill between REST and WS in symbol_task ([4d2b9a9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4d2b9a9e12910618a2c914ebbe0ce3e37c1ba605))
* **02-01:** add event_type parameter to puck_fill for junction vs normal differentiation ([ab47293](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ab472931b101c9af3ccdec224efd535016f33630))
* **02-01:** add junction telemetry with gap size, forming bar trades, WS buffer depth ([ff8aac0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ff8aac0f209d48b8475e7d4e1e33a87335621a4d))
* **02-01:** add per-symbol fill_from_rest timing and summary telemetry ([cf6e0dd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cf6e0ddbbbc8250527646c662d177cbf6da6083e))
* **06-01:** add CombinedWebSocketStream with envelope parsing and demux ([c54d686](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c54d686ce22b6d354dd797c4c83774adec9eb4aa))
* **06-02:** remove per-symbol fallback WS creation in symbol_task() ([5ade3f2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5ade3f2a93528aea350ae32b0233a6b0f99246e8))
* **06-02:** replace per-symbol WS spawn in start_ws() with CombinedWebSocketStream ([27b5345](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/27b534597a968457dc9f6b36b3aacfb70c0a7e8d))
* **combined-ws:** add proactive overlapping reconnection at 23h (COMB-05) ([9f8505f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9f8505fed1fa9f00ab85aa9925c612a39c66aff9))
* **rate-limiter:** convert ceiling to AtomicU32 + add set_ceiling() ([657f308](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/657f308418440cd21492e6bb49ac698fe1467221))
* **streaming:** increase WS channel capacity from 1000 to 50000 (PARA-04) ([fd4a0e4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fd4a0e4aa88a32901548030aad59285cab430a17))
* **streaming:** parallel fill_from_rest with JoinSet + Semaphore(4) (PARA-01, PARA-02, PARA-03) ([c247b76](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c247b765066d6a1d11448af8055eb71ee77b62d1))

# [13.30.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.29.0...v13.30.0) (2026-03-19)


### Bug Fixes

* **heartbeat:** classify midnight-boundary gaps separately from backfill ([a5d00fa](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a5d00faa176c0e84e6df07c160dbffe4220c621e))
* **heartbeat:** emergency alert uses HTML parse_mode correctly ([a737b29](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a737b29984bf2f3e52fb70ed490583a3af79b401))
* **heartbeat:** explicit HEALTH_GATE_KEYS instead of fragile all-bools ([1e79928](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1e79928fa05714cb151413c8f6d826c495ee6a27))
* **heartbeat:** use satellite emoji for streaming symbols instead of star ([201b387](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/201b387e40375bc51d035a2b52acac8638404764))
* **sidecar:** remove Python inline backfill — replaced by chunked fill_from_rest ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([a47c2c4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a47c2c4525899bb9d651307f7961097eb30915f7))
* symbols.toml is sole SSoT for streaming symbols ([0132283](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0132283f9463c798fb275839aa45f70ba3ea6565))


### Features

* add full-symbol-streaming-spike skill ([a950546](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a95054675250225d06a3748e172700b4ed29ee5d))
* add heartbeat-refactor-execute skill — autonomous self-validating pipeline ([1062cec](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1062cec2129d2ff1bd203e91aeb3ef17c7e3073c))
* **heartbeat:** add dead letter count check ([18d6d4f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/18d6d4ff4b49b17c50e5ac14ba877c83596b8b7c))

# [13.29.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.28.2...v13.29.0) (2026-03-19)


### Bug Fixes

* **kintsugi:** skip streaming symbols in trailing-edge fill — Writer Ownership [#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280) ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([aa51476](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/aa51476d6d2ffa07b6b590c27cb27afe36d9ff11))
* **sidecar:** re-enable Python inline backfill — Rust fill_from_rest OOMs ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([761fa1f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/761fa1f18ea6d2cca590030f2b9430414d03bd93))


### Features

* add streaming-writer-exclusion-spike skill scaffold ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([437edc9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/437edc97b27dff1e621fae55c108351dd620c015))
* **heartbeat:** classify Stathera gaps — intra-day vs backfill progression ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286) Spike F) ([0651b6c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0651b6cc6473b036724e0f8f97d1686e1f395dde))
* **streaming:** chunked fill_from_rest — 50K trades/chunk eliminates OOM ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([15fbbcc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/15fbbcc39173a99236a7777228161b13bf39d82b))

## [13.28.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.28.1...v13.28.2) (2026-03-19)


### Bug Fixes

* **streaming:** cap fill_from_rest to_id — i64::MAX caused integer overflow ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([ab36bf8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ab36bf81d7deb4f740fd4227701421aac2ff64f5)), closes [hi#volume](https://github.com-terrylica/hi/issues/volume)

## [13.28.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.28.0...v13.28.1) (2026-03-19)


### Bug Fixes

* **streaming:** propagate trade-ID seeds to engine before fill_from_rest ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([0fce196](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0fce196c7a0231b9e49d68f07b242f541b010313))

# [13.28.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.27.0...v13.28.0) (2026-03-19)


### Bug Fixes

* **backfill:** Ariadne end_ms filter used wrong timestamp key — fetched past boundary ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([7169807](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7169807c72d490bc900f5bf85aeb7e040322f05e))


### Features

* **sidecar:** inline startup backfill — zero manual intervention on restart ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([e475d1f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e475d1f71847f15bf2a68692bcd5445e34309ad1))
* **streaming:** Rust fill_from_rest() — zero-gap restart via same-processor REST→WS transition ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([21cf4a6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/21cf4a6f19d0d583f6a687b26c6cde9f207e1d93))

# [13.27.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.26.1...v13.27.0) (2026-03-18)


### Bug Fixes

* **sidecar:** auto-delete stale checkpoint files on rejection ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([562a2dc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/562a2dcb86eb6f0dc8e9cff5e38dadab20fc2aac))
* **sidecar:** autonomous overlap prevention on checkpoint restore ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([6113e0e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6113e0ea242e154a3bf8a03267e646532302c892))
* **sidecar:** preserve checkpoint files on stale rejection + min-TID overlap guard ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([a3d179c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a3d179cd096f4cb6b692a96d9036b4850d599674))
* **sidecar:** reject stale checkpoints that point beyond CH last bar ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([8a78a91](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8a78a910dd731b2a34b686d3093af4ba02b11fd2))
* **sidecar:** remove startup DELETE — RMT overwrites by first_agg_trade_id ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([2961b1e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2961b1e1e517eb1c4622e75320e003be31a6b7f8))
* **sidecar:** revert individual overlap deletion — cascades make it worse ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([8121ee5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8121ee59f32282f1f0367099e14b5a79c8149c1f))


### Features

* **sidecar:** day-boundary healer handles overlaps + gaps autonomously ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([51b8af0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/51b8af0ea75312a35add3fcbb4409b11199b453a))
* **sidecar:** deterministic day-boundary gap heal on startup ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([5c2ec3f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5c2ec3f5b537ff56f896224340dad2ed38750c1a))
* **sidecar:** reinstate clean-slate DELETE on startup ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([715d8f3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/715d8f377f34c647e76d6d246b4244111dad9912))

## [13.26.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.26.0...v13.26.1) (2026-03-18)


### Bug Fixes

* update streaming tests for 6000 rate limit default ([a130440](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a130440c11874083e3a1eb18818934355435bd51))

# [13.26.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.25.0...v13.26.0) (2026-03-18)


### Bug Fixes

* correct comment — checkpoint restore + Puck produces zero overlaps ([a319d2c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a319d2c2ffa755ba890bffd685bd1842ae75f6cc))
* **heartbeat:** clarify Stathera reporting — bar-level artifacts, not data loss ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([cfd3737](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cfd3737c84c8665be68337e2d652e2ae866270cc))
* **sidecar:** remove clean-slate DELETE — keep existing bars for data continuity ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([c712ef1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c712ef106573cfe08c78f2f84f75367a53e40611))
* **streaming:** remove Puck 100K trade limit — fill any gap regardless of size ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([03697e3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/03697e3cbe820b4a3bd806381cd2a9d6633fe914))


### Features

* **sidecar:** clean-slate startup — DELETE today's bars, Puck fills from yesterday ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([17490c1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/17490c11e5b0a47b5207bb77257a5ea8476f5c11))

# [13.26.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.25.0...v13.26.0) (2026-03-18)


### Bug Fixes

* correct comment — checkpoint restore + Puck produces zero overlaps ([a319d2c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a319d2c2ffa755ba890bffd685bd1842ae75f6cc))
* **heartbeat:** clarify Stathera reporting — bar-level artifacts, not data loss ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([cfd3737](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cfd3737c84c8665be68337e2d652e2ae866270cc))
* **sidecar:** remove clean-slate DELETE — keep existing bars for data continuity ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([c712ef1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c712ef106573cfe08c78f2f84f75367a53e40611))
* **streaming:** remove Puck 100K trade limit — fill any gap regardless of size ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([03697e3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/03697e3cbe820b4a3bd806381cd2a9d6633fe914))


### Features

* **sidecar:** clean-slate startup — DELETE today's bars, Puck fills from yesterday ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([17490c1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/17490c11e5b0a47b5207bb77257a5ea8476f5c11))

# [13.25.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.24.0...v13.25.0) (2026-03-18)


### Features

* buffered WS start — zero-gap restart via start_ws() → start() ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([3754c32](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3754c32c4fc1798b4af82b4b229486894072d5e9))

# [13.24.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.23.2...v13.24.0) (2026-03-18)


### Bug Fixes

* **sidecar:** remove startup _gap_fill — fresh processor creates boundary gaps ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([a20e477](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a20e4773a814b79244f4e407a0bac70f2d5f0282))


### Features

* expose fetch_aggtrades_parallel to Python — 5x faster kintsugi REST ([#291](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/291)) ([7b6e50d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7b6e50d4f0a11bf244beb3549d1bc724d5deff42))
* unified REST rate limiting — 6000 budget, OnceLock singleton, per-process ceiling ([#291](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/291)) ([77c8d8f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/77c8d8fc7f2af044e7b24bb6b07b8be375679fe5))

## [13.23.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.23.1...v13.23.2) (2026-03-17)


### Bug Fixes

* **streaming:** propagate CH seeds to gap detector — eliminate startup gaps ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([3457f05](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3457f05920fcae3ae356d8317803d7a2ceff141d))

## [13.23.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.23.0...v13.23.1) (2026-03-17)


### Bug Fixes

* **streaming:** update gap detector after on-demand fill_gap ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([aed6a71](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/aed6a7156b33ba944580f2f7d37435f514568967))

# [13.23.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.22.0...v13.23.0) (2026-03-17)


### Bug Fixes

* **asclepius:** permanently disable — fill_gap() on live engine causes cascade ([#284](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/284)) ([023e947](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/023e947c099d971b9c0e832e63e2f421289ff658))
* **asclepius:** use Puck fill_gap() instead of backfill_gap() ([#284](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/284)) ([37d169b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/37d169b45f6b3b7e6fdbd071534ba7d9a2d6f314))
* **core:** monotonic guards on last_agg_trade_id and close_time ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([338a8b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/338a8b454554353149bc6e62224e65c84b88b2b8))
* **deploy:** disable Asclepius — backfill_gap() produces malformed bars ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([ce73490](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ce73490d519c45bf2b3ef001e6e49bec35d74ab9))
* **heartbeat:** stathera_all_gaps_known should not gate health ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([c53cb15](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c53cb159e3976e5195d9a4d52b04f48738a3e65e))
* **kintsugi:** always try Vision before REST — remove static T-7 cutoff ([#285](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/285)) ([b97dc1b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b97dc1ba6a8b8bc1203654fdb0276f31192d2be1))
* **reconstruct:** use 1-hour chunks to prevent OOM with multi-threshold fan-out ([#285](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/285)) ([2a1ac86](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2a1ac86ba429eae70a260ed2c824d9216c210337))
* **sidecar:** expose Asclepius metrics in /health endpoint ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([02f1e2b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/02f1e2b1c76cf9f345ddb53dafa874dd962ccc61))
* **sidecar:** limit live streaming to BTCUSDT,ETHUSDT until combined WS ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([4715951](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/47159515fd758ddb82dfe2f7b0cdc91315ac7342))
* **sidecar:** remove reconstruct_today + bump MemoryMax 2.5G→4G ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([580f34b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/580f34b46db36f9c48c85315433e7e36ba15416f))
* **write-gate:** reject physically impossible bars before ClickHouse insert ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([d9ba4f9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d9ba4f9d2863e3e8a56a1a1b039bb65db84b6fea))


### Features

* reconstruct_today fetches trades ONCE per symbol, all thresholds simultaneously ([#285](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/285)) ([8f8416a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8f8416ad5c649c2665dfbafd9c1024480af5b5e4))
* **registry:** enable all 16 Tier 1 symbols — Parquet tick cache pre-seeded ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([ae7d2b1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ae7d2b1433c24e71b9b01747ed84e683075136af))
* **sidecar:** reconstruct today's bars on every startup ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([04c4e4d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/04c4e4d1722ac3501cd7a85b09237fcbf6dd56e9))

# [13.22.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.21.0...v13.22.0) (2026-03-16)


### Features

* sidecar owns today, kintsugi owns yesterday — ownership boundary ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([275950b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/275950b852a9ce99591de644e1dbbfe51e664c34)), closes [#281](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/281) [#282](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/282) [#283](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/283)

# [13.21.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.20.0...v13.21.0) (2026-03-16)


### Bug Fixes

* **repair:** combine_chunks() before to_batches() — was processing 3% of trades ([517e200](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/517e200b1c4df83dfbea1eb6bab993d9b7e55fbb))
* **repair:** convert Arrow Table to RecordBatch for process_trades_arrow() ([8b8fbc5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8b8fbc5c7e75363a2e3bae64118ee71483dc765e))
* **repair:** revert to dict path — Arrow schema mismatch needs separate fix ([1a24341](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1a2434171c51950f9a7d49c6ddc9b9b7be0f5488))
* **repair:** write bars and orphan separately (Arrow vs dict schema differ) ([8369cca](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8369cca5d1278a3143fe8f3a14396ae4218b1941))
* **scripts:** thread-local CH cache reuse to prevent fd exhaustion ([0961428](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0961428eedd8a35b30cc9c050c4cf582116f65e2))


### Features

* **seeder:** support Binance Vision UM futures aggTrades ([#278](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/278)) ([8bffc30](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8bffc307c1873eb4b5588a71ec0c12c716e343ff))


### Performance Improvements

* **repair:** Arrow zero-copy + bounded futures + allocator purge ([6fcd796](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6fcd796cbfb2f7010c5cdd94b21b4220b7672a76))
* **repair:** use overlap_strategy=warn instead of replace ([084be64](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/084be64e0de43f53a9d3f55074f5197324bdbe9d))

# [13.20.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.19.0...v13.20.0) (2026-03-14)


### Bug Fixes

* **backfill:** wire OPENDEVIATIONBAR_MEMORY_MAX_BYTES into BackfillConfig ([217ba84](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/217ba8460454ddcfa63bb6bb25fc2cad65de8e37))
* **core:** compute microstructure features for orphan bars ([#275](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/275)) ([48e0674](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/48e0674d995d348e72b29f9260d039237f812e9f))
* **heartbeat:** auto-heal editable .pth shadowing when wheel dist-info is present ([cce4224](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cce4224edbacafed69f1e1b6d5b64370f3246f4c))
* **heartbeat:** distinguish genesis seeding from kintsugi gap repair ([d4865d4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d4865d424d649d9bec77ada6c1018ceb026f9f36))
* **heartbeat:** escape HTML in version_drift_detail to fix Telegram 400 Bad Request ([19fad41](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/19fad410237ea81736dd1f8c6660621776c18158))
* **heartbeat:** notify with sound on auto-heal pth removal, show detail in message ([4b560b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4b560b403c46527b8e1346bfa343f2b4f9020a83))
* **heartbeat:** use direct_url.json to distinguish editable from wheel before auto-heal ([0ea16a6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0ea16a6c606ee82e1a4285c108329b447e4d2649))
* **kintsugi:** downgrade genesis verify_repair log from WARNING to DEBUG ([6501f43](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6501f43ed1c1d4ab2db7ff500c33ac74ef11f663))
* **streaming:** burst-atomic frame processing for same-ms trades ([#273](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/273)) ([9f44a09](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9f44a096a5c1b86a2536cea929bd9e90667eab0f))
* **systemd:** add OPENDEVIATIONBAR_BACKFILL_MEMORY_MAX_BYTES to service files ([2c283f7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2c283f77db8c98a6add799ec915eb395cf166572))


### Features

* **kintsugi:** genesis shard detection for newly-enabled symbols (Issue [#274](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/274)) ([99dc992](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/99dc9929d5415270c7fe12010a14ea78a30fcdba))

# [13.19.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.18.0...v13.19.0) (2026-03-14)


### Bug Fixes

* **providers:** fromId pagination in fetch_aggtrades_rest to prevent same-ms trade drops ([536d61a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/536d61ad2b729c159d56ef5c0f892ac2716e6a5c))


### Features

* **kintsugi:** registry-driven shard priority via kintsugi_priority field ([0b7b9ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0b7b9ae59cfe122c51125f5a0968d571faea9b0c))

# [13.18.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.17.1...v13.18.0) (2026-03-14)


### Bug Fixes

* **heartbeat:** flag symbols with sparse ClickHouse coverage in Freshness section ([81919cd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/81919cd57059bd72e094bbed18f6ed93e65bcb33))
* **heartbeat:** prune dead code and align truth with production state ([889b6b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/889b6b495b00199f98899ab07c823a2084acebdd))
* **heartbeat:** remove 2 dead result keys ([1a575f9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1a575f938cee9d6ea97465ebf1aded7056993120))
* **monitoring:** show live seeder journal progress as fallback during running state ([299a999](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/299a9991b9f1740e3342695ef5975d41416e5c35))
* **monitoring:** show live seeder progress during multi-hour bulk runs ([1739451](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/173945118e9e91d59c7e3593eb00946c135d8970))
* **scripts:** fail-loud hardening for heartbeat and seeder ([37cd820](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/37cd8206695cef1099a56e1d118041604f3dbe1d))
* **seeder:** normalize Vision timestamps from µs to ms (Binance format change ~2025) ([5752f98](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5752f98002bf785682bba11855ec6cfbbe8c1f62))


### Features

* **heartbeat:** fingerprint known Stathera gaps with detailed Telegram diagnostic ([1e60077](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1e6007782e67361153c8800040a0f0071ef8dfe3))
* **monitoring:** add seeder to all monitoring layers ([8c2e613](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8c2e613d8e7acbbdf4848049da76e528187bb77d))
* **registry:** enable ETHUSDT at 250/500/750/1000 dbps ([0f4c1d6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0f4c1d6a9cf8632c67b0e94ce323342743e5882a))

## [13.17.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.17.0...v13.17.1) (2026-03-13)


### Bug Fixes

* **release:** crates publish skips correctly when no new version ([dffa29c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/dffa29ca10e09dd79981962a9030ba44e5d09c80))

# [13.17.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.16.1...v13.17.0) (2026-03-13)


### Bug Fixes

* **cache:** per-threshold error isolation + configurable workers in multi-threshold fan-out ([e32ac14](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e32ac1443decf88a81a3c0ac980cb14320116891))
* **checkpoint:** eliminate 4× redundant Vision downloads in multi-threshold network path ([91f8e17](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/91f8e17cfafb79c573cd273fd72f8590c0f899f2))
* **kintsugi:** add lightweight_mutation_projection_mode=drop for DELETE FROM ([ad43bd1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad43bd1e09119247509e8757b1d34b7d52f149e6))
* **kintsugi:** auto-delete stale left-straddling bars after _do_replace async race ([ad06650](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad06650705b3a1597c8c477c8d2f0e094f3397ad))
* **kintsugi:** reduce batch_days 3650→365 to prevent RSS memory pressure ([8d8c6cc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8d8c6ccf57b73bd85096d83491ff71720abb7c26))
* **kintsugi:** replace heavyweight ALTER TABLE DELETE with lightweight DELETE FROM ([c9cb5c5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c9cb5c5531a8b789fde0b8583ae6db15c6cc6a3b)), closes [#269](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/269)
* **kintsugi:** split Vision exception handling to avoid false negative cache entries ([fa40c9d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fa40c9d85408b2c11510b6c00dc1f523c55921a2))
* **kintsugi:** T-7 Vision cutoff + remove batch-level Redis write lock ([28100f9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/28100f9329e18a39398012d5b89c4e6e24e4a77e))
* **monit:** raise all memory thresholds to 70% of bigblack RAM ([7f11333](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7f11333a9c393eb7ba6d1804244a313616c062d6))
* **monit:** set kintsugi memory alert at 70% of bigblack RAM (42700 MB) ([4e4ae29](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4e4ae29d9f4c293794b97190af06d0d2f37ba7dc))
* **seeder:** 16→8 workers, raise MemoryMax 2G→6G ([191137f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/191137f8875c317c79af8e4eab68a518537ca9be))
* **seeder:** MEM-016v2 — per-day staging files + streaming merge ([0e64dbd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0e64dbd361d495af429f8385a0e303dbb9214273))
* **seeder:** MEM-017 sequential per-day streaming appends ([2f55034](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2f55034741429460f6de1fb1ebdc1052ae7345ad))
* **seeder:** MEM-018 bounded future submission — prevent DataFrame accumulation ([d941fb2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d941fb2f07947b3a40a09db5ea7d3732aea830ac))
* **seeder:** MEM-021 mimalloc + MEM-024 malloc_trim to eliminate glibc arena RSS plateau ([c416024](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c41602446f75cd6a8047501fb451e150510876f9)), closes [hi#water-mark](https://github.com-terrylica/hi/issues/water-mark)
* **seeder:** move state file /tmp → /var/tmp (monit PrivateTmp isolation) ([063c0f8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/063c0f8fddd5e7b83921f1b523fdeef46631d910))
* **seeder:** raise MemoryMax to 2G (4 workers × 300-400MB polars DataFrames) ([14775f3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/14775f3d8f67e3e872c198ec697cf0f41a44341e))
* **seeder:** resilient staging merge — skip corrupt days instead of aborting month ([f8eb374](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f8eb374150ef8baacdb31d42aba1286876f5cc81))
* **seeder:** use httpx for Vision downloads (add as dependency) ([df2ab4e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/df2ab4eb4e758a8b0977699047561d5d042a3ab2))
* **seeder:** use requests instead of httpx for Vision downloads (requests in venv) ([ea5bb40](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ea5bb40fd74db51c4d1d468ab66a7ea34f411cbf))
* **storage:** convert us Int64 timestamps to ms in write_ticks ([bbb1545](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bbb154583c9c8effac87cdad588395a7dfec5213))
* **storage:** use diagonal_relaxed in lazy concat to tolerate schema drift (column_8) ([44d1c09](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/44d1c0978e6b86dbf5a262d94a3f10d126954a21))
* **systemd:** remove LimitNPROC=4096 from all service templates ([9bdb1e1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bdb1e119e6655007581091ae08ec64b9e1fc5a7)), closes [#107](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/107)


### Features

* **audit:** Task 9 cross-cutting synthesis - hardcoded values resolution strategy ([19e70d0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/19e70d0a65e2d1702c68eea2c2af297ea2dd6f98))
* **cache:** multi-threshold single-Parquet-read fast path + populate_range script ([9bf5dd2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bf5dd2d79646e253fd5fa41ac961d101a27c6d8))
* **docs:** add symbol registry implementation plan ([4454b0e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4454b0e8e8b238fc14e6d466eb5715e615f16c3e))
* implement quick-win fixes for symbol registry integration ([21a3d08](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/21a3d088f5861ad61a68e40c22256743a6e9df4c))
* **kintsugi:** add Parquet-first data source priority (local cache > Vision > REST) ([ffebf2e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ffebf2e2621b014673e5e916917d4339ea4fc15c))
* **seeder:** proactive Parquet tick cache seeder for bigblack (Issue [#270](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/270)) ([302717d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/302717d7c7f6305a7c669302a3e701f0dc0785bc))


### Performance Improvements

* **kintsugi:** increase batch_days from 60 to 3650 for single-pass gap closure ([e2db49e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e2db49e0b0e8f61c378b78aabfb37e1299836445))
* **kintsugi:** raise MAX_CONCURRENT_REPAIRS 8→24 based on empirical step-up profiling ([cd881ec](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cd881eca23fd5d24bf5b8158db4aa8494f318066))
* reuse thread-local ClickHouse connection in fatal_cache_write ([9efa17d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9efa17d6770d2feebd417106111aa5507c70d1f7))
* **seeder:** MEM-016 month-level batch writes — eliminate O(N²) file scan accumulation ([7353c5f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7353c5f2567f55acaf6cd6c199218dfa9ad5849c))
* **storage:** MEM-015 anti-join dedup — avoid is_in deprecation path (+1954 MB) ([32aac52](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/32aac52cf5fddf24b0fff45e633e0b17d2bdbac7))
* **storage:** MEM-015 column projection in write_ticks() — 95.7% memory reduction ([8b07931](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8b0793133e72aa73eb9383b7910f7df6dbb4362e))
* **storage:** MEM-015 schema-normalize before sink_parquet to enable streaming engine ([ad3283e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad3283e29b950e0e0a2106e6ff16da1d877e81b6))
* **storage:** MEM-015 streaming sink_parquet — bounded memory for write_ticks() ([3e1cd78](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3e1cd780a4d9edd1bb97b81ccc643941370c82c4))
* **storage:** MEM-015 two-source scan_parquet streaming — write new rows to temp file first ([40f8588](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/40f8588ffcb6636fa34f16df1e110b407488aec0))

## [13.16.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.16.0...v13.16.1) (2026-03-12)


### Bug Fixes

* restore BTCUSDT thresholds [250,500,750,1000] — focus mode complete ([7e5c653](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7e5c65398069c4271d1977a742ccc1cf1f74064a))
* **stathera:** exclude first-bar artifacts from gap count + active repair visibility ([4facb9f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4facb9f074de649da6685fe7f5da5ac4fd861dee)), closes [#269](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/269)

# [13.16.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.4...v13.16.0) (2026-03-12)


### Features

* dynamic Parquet parallelism + peak resource tracking in heartbeat ([79d9512](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/79d9512396d133a82f619e27f1ab8c61f84e9fd0))
* increase max_concurrent_parquet to 64, unleash full 5115-shard backfill ([f19311e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f19311e184a3b179b0d91098a3f4ce309963878f))


### Performance Improvements

* eliminate Redis lock serialization bottleneck in kintsugi ([8f2b7aa](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8f2b7aac198bcaaf70b8aa1126329e35d498a3bf))
* tune MAX_CONCURRENT_REPAIRS=13 (Vision download safe) ([f6ecee9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f6ecee930465b2c42b9ac0cd9de4487c520f53a8))

## [13.15.4](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.3...v13.15.4) (2026-03-12)


### Bug Fixes

* kintsugi override false-positive UNHEALTHY + persist parallelism settings ([ea14a97](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ea14a97d75e565158d57be3b58f9527895331d6a))

## [13.15.3](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.2...v13.15.3) (2026-03-12)


### Bug Fixes

* resolve kintsugi connection pool exhaustion + schema.sql loading resilience ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295), [#296](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/296)) ([d686a49](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d686a4906f0e04db496ac9d0dd64bc5b89c8524d))

## [13.15.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.1...v13.15.2) (2026-03-12)


### Bug Fixes

* **test:** update BTCUSDT threshold expectation to match registry focus mode ([3a20942](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3a20942b43c97ac3fae9018865308338f22a299a))

## [13.15.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.0...v13.15.1) (2026-03-12)


### Bug Fixes

* **test:** update KintsugiResult ariadne_used→had_anchor_tid ([d9cb378](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d9cb37819dbfc506c0f59272b9c7f2ad93e31caf))

# [13.15.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.14.0...v13.15.0) (2026-03-12)


### Bug Fixes

* **kintsugi:** cast incomplete bar column types to match Arrow schema ([0092d26](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0092d26a8f14c6ac8b28242d3f5e8f4a11760f46))
* **kintsugi:** CLI max_repairs falls through to KintsugiConfig env var when unset ([5372dbb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5372dbb0a3b580856bbc2a62aee26686ebcfff7a))
* **kintsugi:** normalize incomplete bar schema to match Arrow frames ([900adad](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/900adadc1e6b62a8842f53a560ac0d4006ab81c8))
* **registry:** filter_pairs_by_registry checks thresholds, not just symbol enabled ([bd90565](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bd905652359847e4d16956723256bf1c16416acb))


### Features

* **registry+kintsugi:** symbols.toml as SSoT (BTCUSDT@250 only); day-start-fill invariant ([#265](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/265)) ([5d5624f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5d5624f8b74470065e2edbee0d492f28919c7dbb))

# [13.14.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.13.0...v13.14.0) (2026-03-11)


### Bug Fixes

* **config:** remove unnecessary lambda in default_factory ([82f2ba5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/82f2ba5e276776b69533506f70e9ed378fd9a104))
* **data-source:** enforce spot-only policy, remove structural gap concept ([89921f5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/89921f5d24fb7a0fd6e7f078c91a6f04877b86fc)), closes [#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264) [#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)
* **monit:** remove kintsugi memory limit, revert workers to 4 ([5164126](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5164126bf819e4b43a1abf1a64331ff0b4da5470))
* restore _is_valid_parquet re-export removed by ruff auto-fix ([2c0f636](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2c0f636da76ad02a73e98f7b5d81e1a95b5c47b7))
* **stathera:** day_boundary_exclusion time-gap check + symbol registry gating ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([0f35ce2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0f35ce28addc66bc64600268b78806906003149d))
* **stathera:** remove day_boundary_exclusion — all tid_delta > 0 are gaps ([26fae60](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/26fae60130d03b8249589ab457d90ec484f7b034))


### Features

* **config:** centralize 60+ hardcoded constants into pydantic-settings ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([2dcc2c5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2dcc2c59d503dc0ed872c4e1fc825e4b3f1e89f4))
* **kintsugi:** outer shard parallelism via ThreadPoolExecutor ([fe8571f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fe8571f6ed3f78e7bb31a2134815dd03305a461b))
* **streaming:** Rust-native UTC midnight processor reset in LiveBarEngine ([47bf2c9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/47bf2c9f29d578d80e92f99aee29da8665a0749c)), closes [#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)

# [13.13.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.12.0...v13.13.0) (2026-03-11)


### Features

* **kintsugi:** parallel day repairs within batch via ThreadPoolExecutor ([db710a7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/db710a7352fcde1101600b3de57ddf0dbd0592a6))

# [13.12.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.2...v13.12.0) (2026-03-11)


### Features

* **kintsugi:** multi-day batch processing per shard repair ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([2340338](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/23403389334dc95b72a0bd79c9030d53223aac40))

## [13.11.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.1...v13.11.2) (2026-03-11)


### Bug Fixes

* improve sidecar_api log clarity — no more exc_info tracebacks for expected fallbacks ([9bb64c2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bb64c2feeb108a07dc03b72ee59ab66f86de318))
* invert cross_midnight health logic — healthy when kintsugi IS healing ([db591d3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/db591d32d099e4eac30264e3303ebf10fe4bf8b5))
* pre-filter disabled symbols in sidecar gap-fill ([857659f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/857659fa75bf6f1b1e316c9b86b485c6eb9a84cd))

## [13.11.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.0...v13.11.1) (2026-03-11)


### Bug Fixes

* make symbol registry tests work with disabled symbols ([cb553d7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb553d79d51b0658403054980a8c82499cf5126b))

# [13.11.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.10.0...v13.11.0) (2026-03-11)


### Bug Fixes

* cross-midnight bars no longer clobber stathera_gaps health check ([5d05a14](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5d05a14a2b312ff410cb6ca06b006421ea553c09))
* day_boundary_exclusion() was hiding 172 real gaps from kintsugi ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([96c5c76](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/96c5c76a55a3df638b8c61773c6b2e77ded9023c))
* enforce symbol registry enabled gate in kintsugi, backfill, detect_gaps ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([a83689a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a83689a75bafd09cc51bf58e1eb4da2834334edc))
* heartbeat Telegram respects symbol registry + reduce lock noise ([0512827](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/05128276cb95beba7c8c8c4ffaa916cb5278a6d1))


### Features

* adaptive sleep in kintsugi daemon — skip idle time when shards remain ([441e7c6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/441e7c6c60057056f2077f5c6f2db7232460099f))

# [13.10.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.9.0...v13.10.0) (2026-03-11)


### Bug Fixes

* filter cross-midnight bars in streaming + dead-letter replay ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([ba02338](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ba023386c8e46e26b9c133bedca48f7db2b082f8)), closes [hi#threshold](https://github.com-terrylica/hi/issues/threshold) [264/#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)


### Features

* add odb-telemetry skill for production monitoring and diagnostics ([264fed3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/264fed3a64fbfa13d5b5ccc0922b7880d473c366))

# [13.9.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.8.0...v13.9.0) (2026-03-11)


### Bug Fixes

* eliminate cross-midnight bar sources causing Sisyphean kintsugi cascade ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264), [#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)) ([7bf3721](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7bf3721a521701b4fe37f4e1d1b41269e59462c6))


### Features

* **skill:** add auto-healing guards to odb-deploy-verification ([#261](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/261)) ([7469d31](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7469d31dd1036cb0b1011ce0385798d3bc7d73c2))

# [13.8.0](https://github.com/terrylica/opendeviationbar-py/compare/v13.7.0...v13.8.0) (2026-03-10)


### Bug Fixes

* allow kintsugi to repair interior intra-day gaps ([#261](https://github.com/terrylica/opendeviationbar-py/issues/261), [#202](https://github.com/terrylica/opendeviationbar-py/issues/202)) ([b26c343](https://github.com/terrylica/opendeviationbar-py/commit/b26c3433df3c7632a1f6baf7682e6a3c63d9fa27))
* **skill:** correct kintsugi_log column names in deploy verification ([df83aee](https://github.com/terrylica/opendeviationbar-py/commit/df83aeef6ce20bb4c08740d41f0ea14b9fc9d041))


### Features

* gap repair acceleration with Puck + Niffler (Issue [#257](https://github.com/terrylica/opendeviationbar-py/issues/257), [#158](https://github.com/terrylica/opendeviationbar-py/issues/158)) ([bf5b2e8](https://github.com/terrylica/opendeviationbar-py/commit/bf5b2e8b49316562fc8acdfa96dbab9b4bec5ac6))

# [13.7.0](https://github.com/terrylica/opendeviationbar-py/compare/v13.6.6...v13.7.0) (2026-03-10)


### Bug Fixes

* prevent sidecar state loss on brief CH blips ([#261](https://github.com/terrylica/opendeviationbar-py/issues/261), [#202](https://github.com/terrylica/opendeviationbar-py/issues/202)) ([bbb53b1](https://github.com/terrylica/opendeviationbar-py/commit/bbb53b14c87f178b043195bd190e837a02f94ac8)), closes [#198](https://github.com/terrylica/opendeviationbar-py/issues/198)


### Features

* add odb-deploy-verification skill (58-point checklist) ([848e46a](https://github.com/terrylica/opendeviationbar-py/commit/848e46afd1710c0b34934569284e45286564c47e))

## [13.6.6](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.5...v13.6.6) (2026-03-10)


### Bug Fixes

* resolve circular import in CLICKHOUSE_TRANSIENT_ERRORS ([25368b9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/25368b914c05ea484d2dfdfc64d3c79ffe42e1df))

## [13.6.5](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.4...v13.6.5) (2026-03-10)


### Bug Fixes

* sync workspace dep versions in semantic-release prepareCmd ([6998d47](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6998d470eab55810463322ecb4e8685335683440))

## [13.6.4](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.3...v13.6.4) (2026-03-10)


### Bug Fixes

* wire internal crate deps to workspace SSoT via inheritance ([c46d8bd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c46d8bd327044e9ac70fee3c7a01e8117ecfba1f))

## [13.6.3](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.2...v13.6.3) (2026-03-10)


### Bug Fixes

* add take_gap_event_watcher mock to all sidecar watchdog tests ([32580cd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/32580cdea482f69d1a000a22d9bedd616bee6000))

## [13.6.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.1...v13.6.2) (2026-03-10)


### Bug Fixes

* mock take_gap_event_watcher in watchdog test to prevent JSON serialization error ([a89d488](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a89d4882c72864d9f70a40d1daffd99905ae8fcc))

## [13.6.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.0...v13.6.1) (2026-03-10)


### Bug Fixes

* test default watchdog timeout (600s, not 300s) ([cb47d6c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb47d6c9ebb2f37b6784c85d3946709a2073790e))

# [13.6.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.5.1...v13.6.0) (2026-03-10)


### Bug Fixes

* **#257 phase 0a:** rate limiter CAS loop, fetch_max, Spot weight=4 for aggTrades ([abac1f8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/abac1f8dc7abaa9d64f804a6acc25fd4fe4c0492)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#259:** critical row-index bug in kintsugi, dangling forex test imports ([c9972a5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c9972a5cdca5204a958e1cbe61de55380ba6ec76)), closes [#259](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/259)
* **heartbeat+kintsugi:** day-boundary gap classification, today-guard sentinel, human-readable Telegram ([1294131](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/12941312b36e2aca9d3e10c311c87969e9849898))
* pre-release formatting and config test fixes ([95ff444](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/95ff444b62f03e8fa47a09f6356786fb68ee2d37))
* use loguru instead of warnings.warn for invalid TELEGRAM_LOG_LEVEL ([5b25f8e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5b25f8e554b13a7571cb6e087300912abe4de0fa))
* validate FLUSH_THRESHOLD env var + add bounded flush tests ([#253](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/253)) ([a06e086](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a06e08649f5a082046be3dc8732e97f8c86eccf2))


### Features

* **#257 phase 1:** SSE gap_detected event broadcast in sidecar ([acb0d0d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/acb0d0d787d07fa08248080c52ac83aafd02b5e6)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phase 2a:** parallel aggTrades fetcher with JoinSet+Semaphore ([78bb30d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/78bb30dd9776db370dcdd611a79c3f8d79ddb9fb)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 1-2a:** gap detection submodule (event, command, detector) ([f8404a7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f8404a7f65778ade75f1fb7bc3d42f522deabf29)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 1,2c:** PyO3 gap bindings (PyGapEventWatcher, fill_gap) ([7080d2a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7080d2ad808af2f7223da132e97e21ab849d6b71)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 2-2c:** live engine gap detection + command channel fill_gap() ([b4f9041](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b4f9041c8d0de1728a01a00ee72876b9c8cd4951)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* bounded ClickHouse INSERT — flush every 10K bars during day processing ([#253](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/253)) ([44f4f54](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/44f4f54cb1a8ad99db71705d20b853c6ddfa97c6)), closes [hi#volume](https://github.com-terrylica/hi/issues/volume)

## [13.5.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.5.0...v13.5.1) (2026-03-09)


### Bug Fixes

* **release:** fetch and reconcile with remote in preflight ([04aedeb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/04aedeb7ea8284c482914bb21813353b11da4c5b))

# [13.5.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.4.0...v13.5.0) (2026-03-09)


### Features

* add ClickHouse password auth support ([#201](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/201)) ([8a70953](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8a70953ddff20f8b2e52bef5493f3d283debbd42))
* add OPENDEVIATIONBAR_TELEGRAM_LOG_LEVEL env var ([#243](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/243)) ([9595fa4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9595fa433b6c7663a284fca3bea2f48c98e7aa22))
* **monit:** detailed Telegram health reports with UUID and LOUD failure alerts ([87e20e0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/87e20e0e9e16de4b127a3675c88deede6bfd4509))

# [13.4.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.3.0...v13.4.0) (2026-03-09)


### Bug Fixes

* **clickhouse:** crash-safe replace with overlapping DELETE predicate ([9b343b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9b343b493c808623953eb46fb6f4340e98194c20))
* **kintsugi:** cap day-recompute to one day per pass in day-mode Ouroboros ([be30451](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/be304519217e81e39e61c9a4cf86826f6b0c639f))
* **vision:** cache ALL failures in Redis negative cache, not just 404s ([51d2d84](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/51d2d847c4db37a938103d9b6e8f9e1e7b6d2a67))


### Features

* **heartbeat:** deterministic hotfix detection via mtime comparison ([31984ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/31984aedb606e41eb0c6d40291541449ce17bce9))
* **kintsugi:** Vision-first data source priority for day-recompute ([d4eaae0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d4eaae01e42788030ae7cb27e09bf0767872e973))

# [13.3.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.2.0...v13.3.0) (2026-03-09)


### Features

* **issue-256:** add write-time registry gate to ClickHouse layer ([969af12](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/969af12f4c367981eecbd140f834e12faa6d4445))
* **monitoring:** add delta tracking to heartbeat for repair progress visibility ([3457e89](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3457e89ebc33f98efb98f125fc8fea7a202a85c0))
