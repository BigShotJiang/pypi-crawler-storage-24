# Feature Landscape: Seeder REST Throughput Maximization

**Domain:** Binance REST API sole-owner optimization
**Researched:** 2026-03-23

## Table Stakes

Features that must work correctly for the seeder to function as sole REST owner.

| Feature                                       | Why Expected                                                   | Complexity | Notes                                      |
| --------------------------------------------- | -------------------------------------------------------------- | ---------- | ------------------------------------------ |
| Budget reallocation (kintsugi=0, seeder=2800) | Seeder cannot use kintsugi's budget without updating constants | Low        | Config change in file_coordinator.py + env |
| Kintsugi REST removal                         | Cannot have two REST consumers if seeder is sole owner         | Med        | Strip REST/Vision paths from kintsugi.py   |
| Kintsugi Parquet-only deferred shards         | Cache miss = defer, not fail                                   | Low        | Return sentinel instead of raising         |
| Seeder REST ceiling env var                   | Each process needs its own ceiling                             | Low        | Already pattern exists in sidecar.env      |

## Differentiators

Features that improve throughput beyond the minimum viable.

| Feature                                   | Value Proposition                             | Complexity | Notes                                                    |
| ----------------------------------------- | --------------------------------------------- | ---------- | -------------------------------------------------------- |
| Cross-symbol REST parallelism             | 3x throughput by pipelining across symbols    | Med        | Requires shared rate limiter across concurrent fetches   |
| Per-symbol concurrency increase (3 to 5)  | Better RTT utilization within budget          | Low        | Config change in parallel_fetch or seeder config         |
| Boundary-finding trade ID cache           | Skip 2 REST calls/day/symbol (8 weight saved) | Low        | Cache last known trade ID per symbol per day             |
| Dynamic ceiling based on sidecar activity | Use full 4800 budget when sidecar is idle     | Med        | Read sidecar health endpoint, adjust ceiling dynamically |

## Anti-Features

Features to explicitly NOT build.

| Anti-Feature                       | Why Avoid                                        | What to Do Instead                                 |
| ---------------------------------- | ------------------------------------------------ | -------------------------------------------------- |
| Multi-IP proxy pool                | Complexity, Binance ToS risk, operational burden | Maximize single-IP throughput; Vision handles bulk |
| Seeder writing to ClickHouse       | Violates writer ownership model                  | Write Parquet only; kintsugi reads Parquet         |
| Seeder seeding today's data        | Today belongs to sidecar                         | REST fallback for T-1 through T-7 only             |
| Redis-based rate coordination      | Adds dependency for marginal improvement         | File-based is proven and already deployed          |
| API key rotation for higher limits | Binance limits are IP-based not key-based        | No benefit from multiple keys on same IP           |

## Feature Dependencies

```
Budget Reallocation -> Seeder Parallelism Increase (needs larger budget)
Kintsugi REST Removal -> Seeder as Sole REST Owner (eliminates competing consumer)
Seeder REST Ceiling -> Cross-Symbol Parallelism (needs proper budget enforcement)
```

## MVP Recommendation

Prioritize:

1. Budget reallocation (table stakes, config-only)
2. Kintsugi REST removal (table stakes, enables sole ownership)
3. Seeder REST ceiling env var (table stakes, enforcement)

Defer: Dynamic ceiling based on sidecar activity -- premature optimization; the 800 reserve is sufficient protection.
Defer: Boundary-finding cache -- minor weight savings (1,008 weight for full week catch-up vs 25,200 total weight).
