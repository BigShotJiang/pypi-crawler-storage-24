# Milestones

## v1.0 v1.0 (Shipped: 2026-03-24)

**Phases completed:** 7 phases, 12 plans, 24 tasks

**Key accomplishments:**

- Split 2,436-line live_engine.rs monolith into 5 focused submodules under live_engine/ directory with zero test regressions
- Split 2,188-line checkpoint.py monolith into 4-file checkpoint/ package (models, storage, engine, orchestrators) with full backward compatibility
- Extracted 3 orthogonal concerns (rectification, memory guard, vision cache) from backfill.py into sibling modules, reducing it from 1423 to 980 lines with full backward compatibility
- 1. [Rule 3 - Blocking] Renamed signal.py to yesterday_signal.py
- 10 Exness forex symbols registered in symbols.toml with ExnessSeederConfig pydantic-settings class for env-driven configuration
- Exness forex tick cache seeder downloading daily ZIPs from ticks.ex2archive.com with 3-column Parquet output, idempotent operation, and Telegram reporting
- systemd oneshot service with 1h timer, monit 2h freshness monitor, and 4 CLAUDE.md files updated for Exness forex seeder deployment infrastructure
- Kintsugi consumes sidecar's yesterday-repair signal file, injects flagged symbols at HEAD of repair queue with dedup, and clears signal after all shards processed
- 4 CLAUDE.md spokes for highest-complexity directories (src/, sidecar/, kintsugi/, checkpoint/) with source-derived file tables, domain-specific flow diagrams, and bidirectional parent links
- 4 new CLAUDE.md spoke files for validation (intermediate parent), processors, heartbeat, and heartbeat/checks (14-module index), plus day_mode parent chain fix
- Three CLAUDE.md spokes for compat (alpha-forge panel/manifest/availability), notify (Telegram @obdpy_bot integration), and ratelimit (file-based 6000 weight/min coordinator) with source-derived content
- Root CLAUDE.md hub table expanded from 13 to 24 entries with source-derived SSoT descriptions, full network verification: 24 files, 0 orphans, 0 broken parent links
- Plan:

---

## v1.4 Zero-Gap Zero-Overlap Guarantee (Shipped: 2026-03-23)

**Phases completed:** 6 phases, 16 plans, 32 tasks

**Key accomplishments:**

- Added last_completed_bar_tid field to OpenDeviationBarProcessor and Checkpoint, tracking completed bar trade IDs separately from forming bar tail for dedup floor initialization
- Fixed committed_floors dedup floor to use last_completed_bar_tid instead of last_agg_trade_id, eliminating junction bar suppression at REST-to-WS transition
- Binance REST midnight crossover query and ClickHouse orphan verification for Stathera continuity at day boundaries
- \_run_midnight_preflight() orchestrator wired into \_create_engine(), overriding CH seeds with verified crossover trade IDs for zero-gap midnight boundaries
- Unified per-symbol Stathera continuity check replacing intra-day/adjacent-day classification, with LOUD Telegram alert on new today gaps
- Per-symbol yesterday orphan completion via crossover TID validation, junction telemetry from sidecar HTTP+journal, both visible in Telegram heartbeat
- Client-side ping with real 10s pong deadline, Binance 429/ban error classification, and CONNECT/FIRST_DATA/DISCONNECT stream signal emission on both per-symbol and combined WebSocket paths
- Sidecar /health endpoint with WS connection lifecycle tracking (CONNECT/FIRST_DATA/DISCONNECT) and heartbeat Telegram alerts with 429-fatal vs transient-disconnect classification
- Trade-ID continuity validation in write_ticks(), seeder routed through dedup path, systemd overlap prevention via Conflicts=
- File-based RateLimitCoordinator + PyAdaptiveRateLimiter PyO3 binding + kintsugi rate limit gating + per-process systemd ceiling env vars
- REST API fallback for yesterday's Vision gaps using two-step fetch, 6-symbol batch rotation with BTCUSDT priority, and kintsugi-processed day guard
- Aggregate REST utilization monitoring with sustained-90% LOUD alert, seeder days-behind metric, and weekly Vision vs REST oracle check
- Captured bit-exact golden snapshot fixtures (46 bars each) for BTCUSDT 2024-01-01 at threshold=250 in both Rust (JSON) and Python (Parquet) before any memory refactoring changes
- AggTrade Copy derive, zero-copy Arrow iterator adapter, and FormingBar 1 Hz throttle -- three Rust-side P0 memory optimizations with bit-exact oracle verification
- GIL released via py.detach() during pure Rust computation in process_trades_arrow() and process_trades_arrow_native() -- Python threads unblocked during 50-200ms bar processing
- Skip plugin Polars-Pandas roundtrip, footer-only Parquet row counting, Arrow REST fallback, and merged with_columns calls

---

## v1.4 v1.4 (Shipped: 2026-03-21)

**Phases completed:** 3 phases, 6 plans, 11 tasks

**Key accomplishments:**

- Added last_completed_bar_tid field to OpenDeviationBarProcessor and Checkpoint, tracking completed bar trade IDs separately from forming bar tail for dedup floor initialization
- Fixed committed_floors dedup floor to use last_completed_bar_tid instead of last_agg_trade_id, eliminating junction bar suppression at REST-to-WS transition
- Binance REST midnight crossover query and ClickHouse orphan verification for Stathera continuity at day boundaries
- \_run_midnight_preflight() orchestrator wired into \_create_engine(), overriding CH seeds with verified crossover trade IDs for zero-gap midnight boundaries
- Unified per-symbol Stathera continuity check replacing intra-day/adjacent-day classification, with LOUD Telegram alert on new today gaps
- Per-symbol yesterday orphan completion via crossover TID validation, junction telemetry from sidecar HTTP+journal, both visible in Telegram heartbeat

---

## v1.4 Zero-Gap Zero-Overlap Guarantee (In Progress)

**Goal:** Eliminate ALL Stathera gaps and overlaps -- both intra-day junction gaps (committed_floors bug) and midnight boundary gaps (multi-processor seam) -- with full telemetry to validate.

**Phases:** 3 phases

| Phase | Name                            | Requirements     |
| ----- | ------------------------------- | ---------------- |
| 1     | Dedup Floor Fix                 | RUST-01, RUST-02 |
| 2     | Midnight Preflight Verification | PREFLIGHT-01..03 |
| 3     | Heartbeat Telemetry Overhaul    | TELEM-01..04     |

---

## v1.3 Atomic Restart Recovery (Shipped: 2026-03-21)

**Phases completed:** 2 phases, 4 plans, 6 tasks

**Key accomplishments:**

- Atomic DELETE+INSERT via store_bars_replacing() in \_sync_flush_rest_bars() with Polars conversion, Redis lock, and \_write_batch_with_retry fallback
- Today-only date filter on \_heal_day_boundary_gaps() Stathera query and valid_pairs passthrough for overlap heal call site
- Verified \_inline_startup_backfill(), \_startup_tid_reconciliation(), and \_gap_fill() watchdog call are already absent from sidecar.py -- all three PRUNE requirements satisfied
- Removed dead gap_fill_on_startup field from SidecarConfig, type stubs, CLI --no-gap-fill flag, and 9 test constructions

---

## v1.2 Performance (Shipped: 2026-03-20)

**Phases completed:** 4 phases, 5 plans, 8 tasks

**Key accomplishments:**

- Bounded ThreadPoolExecutor(max_workers=2) replaces unbounded threading.Thread in Telegram log sink, with dedicated 3s timeout to prevent thread exhaustion during kintsugi batch repairs
- Thread-local CH cache eliminates per-call fd churn in kintsugi workers, and 3-tier concurrency control prevents REST-only shards from diluting Parquet/Vision throughput
- Zero-allocation FixedPoint::from_f64() eliminates 4M allocs/day, cached CSV decompression removes O(N^2) ZIP re-parsing in IntraDayChunkIterator
- Eliminate per-iteration Vec::with_capacity(32) allocation in WS select loop via clear()+reuse pattern (RUST-03)
- Cached kintsugi config per repair (3 instantiations eliminated), dynamic Vision 404 TTL (15min for T-2 dates), and removed redundant DataFrame copy in bulk operations
