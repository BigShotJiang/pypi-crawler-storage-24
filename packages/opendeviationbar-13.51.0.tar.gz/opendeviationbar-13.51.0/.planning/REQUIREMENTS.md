# Requirements: v2.0 Seeder as Sole REST Owner + Microsecond Alignment

## Kintsugi Parquet-Only (KPAQ)

- [ ] **KPAQ-01**: Strip REST API fallback from kintsugi repair path (`_process_gap_fallback_starttime()`, Vision download logic in `_repair_under_lock()`)
- [ ] **KPAQ-02**: Add `deferred_cache_miss` sentinel (-2) that bypasses `kintsugi_log` dismiss window — cache-miss shards are deferred, not failed
- [ ] **KPAQ-03**: Always use 64 Parquet workers — remove 24-worker network-bound path and dynamic parallelism switching in orchestrator.py
- [ ] **KPAQ-04**: Adopt OOM prevention patterns from repair_direct_parquet.py: Arrow zero-copy path (`process_trades_arrow()`), mimalloc allocator purge, bounded futures, gc discipline

## Infrastructure (INFRA)

- [ ] **INFRA-01**: Filter forex/Exness symbols out of kintsugi entirely — kintsugi processes Binance crypto only (forex gap repair is a future Exness-specific reconciler)
- [ ] **INFRA-02**: Reallocate rate limit budget — seeder ceiling 800→3600 weight/min, remove kintsugi REST ceiling (no longer needed), update deploy/opendeviationbar.env
- [ ] **INFRA-03**: Parquet tick cache coverage audit — verify all 18+ enabled symbols have Parquet cache coverage, identify gaps, run seeder backfill sprint before migration

## Microsecond Alignment (USEC)

- [x] **USEC-01**: Stop truncating µs to ms in seeder — Parquet tick cache stores native microsecond timestamps (16-digit) for all post-2025-01-01 data
- [x] **USEC-02**: Reseed pre-2025 Parquet files — upscale ms timestamps to µs (×1000) for uniform precision across all dates
- [x] **USEC-03**: ClickHouse schema migration — all timestamp columns (`open_time_ms`, `close_time_ms`, `first_trade_time_ms`, `last_trade_time_ms`) renamed and stored as µs. Column COMMENTs updated.
- [x] **USEC-04**: Rust processor µs-native — OpenDeviationBarProcessor accepts and outputs µs timestamps throughout
- [x] **USEC-05**: Python API + sidecar + kintsugi µs alignment — all Python code that does timestamp arithmetic updated from ms to µs (DAY_MS → DAY_US, etc.)
- [ ] **USEC-06**: Full ClickHouse rebuild — reconstruct all 35M+ bars with µs timestamps using repair_direct_parquet.py (48 workers, ~3200 days/min)

## Future Requirements

- Rust multi-threshold Arrow API (backlog 999.1) — deferred until v2.0 is stable
- Full 18-symbol streaming — separate milestone

## Out of Scope

- OpenDeviationBar struct split (P9) — major refactor, separate milestone
- Plugin Polars→Pandas — no plugins in production
- ClickHouse column rename (keep `_ms` suffix for backward compat if needed) — decided during USEC-03 implementation

## Traceability

| REQ-ID   | Phase | Plan | Status   |
| -------- | ----- | ---- | -------- |
| INFRA-01 | 1     | TBD  | Pending  |
| INFRA-02 | 1     | TBD  | Pending  |
| INFRA-03 | 1     | TBD  | Pending  |
| KPAQ-01  | 2     | TBD  | Pending  |
| KPAQ-02  | 2     | TBD  | Pending  |
| KPAQ-03  | 2     | TBD  | Pending  |
| KPAQ-04  | 3     | TBD  | Pending  |
| USEC-01  | 4     | 01   | Complete |
| USEC-02  | 4     | TBD  | Pending  |
| USEC-04  | 4     | 01   | Complete |
| USEC-03  | 5     | TBD  | Pending  |
| USEC-05  | 5     | TBD  | Pending  |
| USEC-06  | 5     | TBD  | Pending  |
