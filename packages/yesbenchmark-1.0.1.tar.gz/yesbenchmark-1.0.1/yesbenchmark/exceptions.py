class PlatformNotSupportedError(Exception):
    pass
