import os
import shutil
import json
import yaml
import pytest
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner
from agentic_mindset.cli import app, _format_output
from agentic_mindset.context import ContextBlock
from agentic_mindset.renderer.inject import render_for_runtime

runner = CliRunner(mix_stderr=False)


@pytest.fixture
def gen_registry(minimal_pack_dir, tmp_path):
    """Registry dir with sun-tzu and marcus-aurelius packs."""
    # sun-tzu
    sun = tmp_path / "sun-tzu"
    shutil.copytree(minimal_pack_dir, sun)

    # marcus-aurelius — minimal clone with different id/name
    marcus = tmp_path / "marcus-aurelius"
    shutil.copytree(minimal_pack_dir, marcus)
    meta = yaml.safe_load((marcus / "meta.yaml").read_text())
    meta["id"] = "marcus-aurelius"
    meta["name"] = "Marcus Aurelius"
    (marcus / "meta.yaml").write_text(yaml.dump(meta))
    return tmp_path


def test_validate_valid_pack(minimal_pack_dir):
    result = runner.invoke(app, ["validate", str(minimal_pack_dir)])
    assert result.exit_code == 0
    assert "valid" in result.output.lower()


def test_validate_missing_file(minimal_pack_dir):
    (minimal_pack_dir / "mindset.yaml").unlink()
    result = runner.invoke(app, ["validate", str(minimal_pack_dir)])
    assert result.exit_code != 0
    assert "mindset.yaml" in result.output


def test_preview_single_pack(minimal_pack_dir):
    result = runner.invoke(app, ["preview", str(minimal_pack_dir)])
    assert result.exit_code == 0
    assert "THINKING FRAMEWORK" in result.output
    assert "Sun Tzu" in result.output


def test_init_creates_files(tmp_path):
    result = runner.invoke(app, ["init", "my-hero", "--type", "fictional", "--output", str(tmp_path)])
    assert result.exit_code == 0
    for fname in ["meta.yaml", "mindset.yaml", "personality.yaml", "behavior.yaml", "voice.yaml", "sources.yaml"]:
        assert (tmp_path / "my-hero" / fname).exists()


def test_init_rejects_invalid_type(tmp_path):
    result = runner.invoke(app, ["init", "my-hero", "--type", "living", "--output", str(tmp_path)])
    assert result.exit_code != 0


def test_list_shows_characters(minimal_pack_dir, tmp_path):
    named = tmp_path / "sun-tzu"
    shutil.copytree(minimal_pack_dir, named)
    result = runner.invoke(app, ["list", "--registry", str(tmp_path)])
    assert result.exit_code == 0
    assert "sun-tzu" in result.output


def test_list_empty_registry(tmp_path):
    result = runner.invoke(app, ["list", "--registry", str(tmp_path)])
    assert result.exit_code == 0
    assert "no characters" in result.output.lower()


def test_preview_fusion_respects_registry_flag(minimal_pack_dir, tmp_path):
    """--registry flag must be respected in --fusion preview."""
    named = tmp_path / "sun-tzu"
    shutil.copytree(minimal_pack_dir, named)
    fusion_file = tmp_path / "blend.yaml"
    fusion_file.write_text(yaml.dump({
        "characters": [{"id": "sun-tzu", "weight": 1.0}],
        "fusion_strategy": "blend",
    }))
    result = runner.invoke(app, [
        "preview", "--fusion", str(fusion_file),
        "--registry", str(tmp_path),
    ])
    assert result.exit_code == 0
    assert "Sun Tzu" in result.output


def test_format_output_text():
    assert _format_output("hello", "text") == "hello"


def test_format_output_anthropic_json():
    result = json.loads(_format_output("hello", "anthropic-json"))
    assert result == {"type": "text", "text": "hello"}


def test_format_output_debug_json():
    meta = {"characters": ["sun-tzu"], "weights": [1.0], "strategy": "blend", "schema_version": "1.0"}
    result = json.loads(_format_output("hello", "debug-json", meta=meta))
    assert result["type"] == "text"
    assert result["text"] == "hello"
    assert result["meta"] == meta


def test_format_output_debug_json_no_timestamp():
    """debug-json must not include a timestamp (determinism guarantee)."""
    meta = {"characters": ["sun-tzu"], "weights": [1.0], "strategy": "blend", "schema_version": "1.0"}
    result = json.loads(_format_output("hello", "debug-json", meta=meta))
    assert "timestamp" not in result
    assert "timestamp" not in result.get("meta", {})


def test_format_output_invalid_fmt_raises():
    with pytest.raises(ValueError, match="Unknown output format"):
        _format_output("hello", "xml")


def test_generate_single_character_text(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    assert "THINKING FRAMEWORK" in result.output
    assert "Sun Tzu" in result.output


def test_generate_unknown_character_exits_1(gen_registry):
    result = runner.invoke(app, [
        "generate", "unknown-char",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "unknown-char" in result.stderr
    assert "mindset list" in result.stderr


def test_generate_weights_count_mismatch(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--weights", "6",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "--weights has 1 values but 2 character IDs" in result.stderr


def test_generate_weights_negative(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--weights", "-1",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "positive numbers" in result.stderr


def test_generate_weights_all_zero(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--weights", "0",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "cannot all be zero" in result.stderr


def test_generate_weights_non_numeric(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--weights", "abc",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "comma-separated numbers" in result.stderr


def test_generate_weights_trailing_comma(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--weights", "6,",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "comma-separated numbers" in result.stderr


def test_generate_weights_leading_comma(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--weights", ",6",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "comma-separated numbers" in result.stderr


def test_generate_weights_double_comma(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--weights", "6,,4",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "comma-separated numbers" in result.stderr


def test_generate_unknown_strategy_exits_1(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--strategy", "bogus",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "bogus" in result.stderr


def test_generate_multi_character_blend(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--weights", "6,4",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    assert "Sun Tzu" in result.output or "Marcus Aurelius" in result.output


def test_generate_strategy_dominant(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--strategy", "dominant",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    assert "THINKING FRAMEWORK" in result.output


def test_generate_strategy_sequential_not_supported(gen_registry):
    """sequential is not exposed in v0 — exits 1 with an error message."""
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--strategy", "sequential",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "sequential" in result.stderr


def test_generate_strategy_sequential_with_weights_not_supported(gen_registry):
    """sequential + --weights also exits 1 (sequential blocked regardless of weights)."""
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--strategy", "sequential",
        "--weights", "6,4",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1


def test_generate_equal_weights_by_default(gen_registry):
    """When --weights is omitted, characters receive equal weight."""
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    assert "50%" in result.output or "Sun Tzu" in result.output


def test_generate_format_anthropic_json(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--format", "anthropic-json",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    block = json.loads(result.output)
    assert block["type"] == "text"
    assert "THINKING FRAMEWORK" in block["text"]


def test_generate_format_debug_json(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--format", "debug-json",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["type"] == "text"
    assert "THINKING FRAMEWORK" in data["text"]
    assert data["meta"]["characters"] == ["sun-tzu"]
    assert data["meta"]["strategy"] == "blend"
    assert data["meta"]["schema_version"] == "1.0"
    assert "timestamp" not in data
    assert "timestamp" not in data["meta"]


def test_generate_format_debug_json_weights(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--weights", "6,4",
        "--format", "debug-json",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["meta"]["characters"] == ["sun-tzu", "marcus-aurelius"]
    assert abs(data["meta"]["weights"][0] - 0.6) < 1e-9
    assert abs(data["meta"]["weights"][1] - 0.4) < 1e-9


def test_generate_explain_goes_to_stderr(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--weights", "6,4",
        "--explain",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stderr)
    assert any("sun-tzu" in p for p in data["personas"])
    assert any("marcus-aurelius" in p for p in data["personas"])
    assert "decision_policy" in data["merged"]
    # stdout is the compiled text, not the explain summary
    assert "THINKING FRAMEWORK" in result.output


def test_generate_explain_does_not_pollute_stdout(gen_registry):
    """--explain summary must NOT appear in stdout."""
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--explain",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    assert "Characters:" not in result.output
    assert "Strategy:" not in result.output


def test_generate_output_writes_file(gen_registry, tmp_path):
    out_file = tmp_path / "system_prompt.txt"
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--output", str(out_file),
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    assert result.output.strip() == ""   # stdout is empty on success
    assert out_file.exists()
    content = out_file.read_text()
    assert "THINKING FRAMEWORK" in content


def test_generate_output_with_explain_empty_stdout(gen_registry, tmp_path):
    """--output + --explain: file gets content, stdout empty, stderr has summary."""
    out_file = tmp_path / "out.txt"
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--output", str(out_file),
        "--explain",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    assert result.output.strip() == ""
    data = yaml.safe_load(result.stderr)
    assert "personas" in data
    assert out_file.read_text() != ""


def test_generate_output_unwritable_path(gen_registry):
    result = runner.invoke(app, [
        "generate", "sun-tzu",
        "--output", "/nonexistent_dir/out.txt",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 1
    assert "cannot write to" in result.stderr


def test_generate_duplicate_id_treated_as_single(gen_registry):
    """Duplicate IDs produce same result as single ID (weights summed → normalized to 1.0)."""
    single = runner.invoke(app, [
        "generate", "sun-tzu",
        "--registry", str(gen_registry),
    ])
    duplicate = runner.invoke(app, [
        "generate", "sun-tzu", "sun-tzu",
        "--registry", str(gen_registry),
    ])
    assert single.exit_code == 0
    assert duplicate.exit_code == 0
    assert single.output == duplicate.output


def test_generate_duplicate_id_with_weights_summed(gen_registry):
    """sun-tzu sun-tzu --weights 3,7 → one entry weight 10 → normalized 1.0."""
    result = runner.invoke(app, [
        "generate", "sun-tzu", "sun-tzu",
        "--weights", "3,7",
        "--format", "debug-json",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["meta"]["characters"] == ["sun-tzu"]
    assert abs(data["meta"]["weights"][0] - 1.0) < 1e-9


def test_render_for_runtime_inject(minimal_pack_dir):
    """render_for_runtime from renderer.inject takes BehaviorIR, not ContextBlock."""
    from agentic_mindset.ir.models import BehaviorIR, Preamble, ResolvedSlot, PrimaryValue
    ir = BehaviorIR(
        preamble=Preamble(personas=[("sun-tzu", 1.0)], text="You embody Sun Tzu (100%)."),
        risk_tolerance="high",
        time_horizon="long-term",
        slots={
            "communication": ResolvedSlot(
                primary=PrimaryValue(value="indirect", source="sun-tzu", weight=1.0)
            )
        },
    )
    result = render_for_runtime(ir, "inject")
    assert "Communication: indirect" in result
    assert isinstance(result, str)


def test_render_for_runtime_inject_and_text_differ(minimal_pack_dir):
    """inject format produces 5-section output (text format is no longer supported by renderer.inject)."""
    from agentic_mindset.ir.models import BehaviorIR, Preamble, ResolvedSlot, PrimaryValue
    ir = BehaviorIR(
        preamble=Preamble(personas=[("sun-tzu", 1.0)], text="You embody Sun Tzu (100%)."),
        risk_tolerance="high",
        time_horizon="long-term",
        slots={
            "communication": ResolvedSlot(
                primary=PrimaryValue(value="indirect", source="sun-tzu", weight=1.0)
            )
        },
    )
    inject_result = render_for_runtime(ir, "inject")
    # inject uses 5-section behavioral format
    assert "You embody Sun Tzu" in inject_result
    assert "Communication: indirect" in inject_result


def test_render_for_runtime_unknown_fmt_raises(minimal_pack_dir):
    from agentic_mindset.ir.models import BehaviorIR, Preamble
    ir = BehaviorIR(
        preamble=Preamble(personas=[("sun-tzu", 1.0)], text="You embody Sun Tzu (100%)."),
        risk_tolerance="high",
        time_horizon="long-term",
        slots={},
    )
    with pytest.raises(ValueError, match="Unknown runtime format"):
        render_for_runtime(ir, "xml")


def test_run_single_persona_oneshot(gen_registry):
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run") as mock_sub:
            mock_sub.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--registry", str(gen_registry),
                "Analyze competitor strategy",
            ])
    assert result.exit_code == 0
    mock_sub.assert_called_once()
    call_args = mock_sub.call_args[0][0]
    assert call_args[0] == "claude"
    assert "--append-system-prompt-file" in call_args
    assert "Analyze competitor strategy" in call_args


def test_run_uses_inject_format_by_default(gen_registry):
    """run command defaults to --format inject and uses ConflictResolver."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
            with patch("agentic_mindset.cli.ConflictResolver") as mock_resolver:
                mock_resolver_inst = MagicMock()
                mock_resolver.return_value = mock_resolver_inst
                from agentic_mindset.ir.models import BehaviorIR, Preamble
                mock_ir = BehaviorIR(
                    preamble=Preamble(personas=[("sun-tzu", 1.0)], text="Test"),
                    risk_tolerance="medium",
                    time_horizon="long-term",
                    slots={},
                )
                mock_resolver_inst.resolve.return_value = mock_ir
                result = runner.invoke(app, [
                    "run", "claude",
                    "--persona", "sun-tzu",
                    "--registry", str(gen_registry),
                    "q",
                ])
    assert result.exit_code == 0


def test_run_query_passed_verbatim(gen_registry):
    query = "How do I handle a negotiation under pressure?"
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run") as mock_sub:
            mock_sub.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--registry", str(gen_registry),
                query,
            ])
    assert result.exit_code == 0
    call_args = mock_sub.call_args[0][0]
    assert query in call_args


def test_run_multi_persona_blend(gen_registry):
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run") as mock_sub:
            mock_sub.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--persona", "marcus-aurelius",
                "--weights", "6,4",
                "--registry", str(gen_registry),
                "query",
            ])
    assert result.exit_code == 0
    mock_sub.assert_called_once()

def test_run_interactive_mode(gen_registry):
    """No query argument → interactive mode → subprocess called without query."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run") as mock_sub:
            mock_sub.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--registry", str(gen_registry),
            ])
    assert result.exit_code == 0
    call_args = mock_sub.call_args[0][0]
    # Interactive mode: only 3 elements (runtime, flag, tmpfile) — no query
    assert len(call_args) == 3
    assert call_args[0] == "claude"
    assert call_args[1] == "--append-system-prompt-file"

def test_run_unknown_persona_exits_1(gen_registry):
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run"):
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "nonexistent-char",
                "--registry", str(gen_registry),
                "query",
            ])
    assert result.exit_code == 1
    assert "nonexistent-char" in result.stderr
    assert "mindset list" in result.stderr

def test_run_claude_not_found_exits_1(gen_registry):
    with patch("agentic_mindset.cli.shutil.which", return_value=None):
        with patch("agentic_mindset.cli.subprocess.run"):
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--registry", str(gen_registry),
                "query",
            ])
    assert result.exit_code == 1
    assert "not found" in result.stderr
    assert "claude.ai" in result.stderr

def test_run_tmpfile_cleaned_up(gen_registry):
    """Temp file must not exist after subprocess returns."""
    captured_path = []

    def capture_tmpfile(args, **kwargs):
        captured_path.append(args[2])
        return MagicMock(returncode=0)

    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run", side_effect=capture_tmpfile):
            runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--registry", str(gen_registry),
                "query",
            ])

    assert captured_path, "subprocess was never called"
    assert not os.path.exists(captured_path[0]), "tmpfile was not cleaned up"

def test_run_tmpfile_cleaned_up_on_error(gen_registry):
    """Temp file must be cleaned up even if subprocess raises."""
    captured_path = []

    def capture_and_raise(args, **kwargs):
        captured_path.append(args[2])
        raise RuntimeError("subprocess exploded")

    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run", side_effect=capture_and_raise):
            runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--registry", str(gen_registry),
                "query",
            ])

    assert captured_path, "subprocess was never called"
    assert not os.path.exists(captured_path[0]), "tmpfile was not cleaned up on error"

def test_run_explain_not_in_tmpfile(gen_registry):
    """--explain output must NOT be written to the temp file."""
    tmpfile_content = []

    def capture_content(args, **kwargs):
        path = args[2]
        tmpfile_content.append(open(path).read())
        return MagicMock(returncode=0)

    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run", side_effect=capture_content):
            runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--explain",
                "--registry", str(gen_registry),
                "query",
            ])

    assert tmpfile_content, "subprocess was never called"
    content = tmpfile_content[0]
    assert "Characters:" not in content
    assert "Strategy:" not in content

def test_run_explain_printed_to_stderr(gen_registry):
    """--explain prints compilation summary to stderr (text path has 'merged' structure)."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--format", "text",
                "--explain",
                "--registry", str(gen_registry),
                "query",
            ])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stderr)
    assert "sun-tzu" in str(data["personas"])
    assert "decision_policy" in data["merged"]

def test_run_exit_code_propagated(gen_registry):
    """Claude's exit code is propagated unchanged."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=42)):
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--registry", str(gen_registry),
                "query",
            ])
    assert result.exit_code == 42

def test_run_duplicate_persona_deduplicated(gen_registry):
    """Duplicate --persona flags produce same result as single."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--persona", "sun-tzu",
                "--registry", str(gen_registry),
                "query",
            ])
    assert result.exit_code == 0

def test_run_weights_normalized(gen_registry):
    """--weights 6,4 are normalized to 0.6, 0.4 internally."""
    captured_content = []

    def capture(args, **kwargs):
        path = args[2]
        captured_content.append(open(path).read())
        return MagicMock(returncode=0)

    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"):
        with patch("agentic_mindset.cli.subprocess.run", side_effect=capture):
            result = runner.invoke(app, [
                "run", "claude",
                "--persona", "sun-tzu",
                "--persona", "marcus-aurelius",
                "--weights", "6,4",
                "--registry", str(gen_registry),
                "query",
            ])
    assert result.exit_code == 0
    assert captured_content and len(captured_content[0]) > 0


def test_render_for_runtime_inject_calls_inject_block(minimal_pack_dir):
    """render_for_runtime from renderer.inject with fmt='inject' returns 5-section format."""
    from agentic_mindset.ir.models import BehaviorIR, Preamble, ResolvedSlot, PrimaryValue
    ir = BehaviorIR(
        preamble=Preamble(personas=[("sun-tzu", 1.0)], text="You embody Sun Tzu (100%)."),
        risk_tolerance="high",
        time_horizon="long-term",
        slots={
            "communication": ResolvedSlot(
                primary=PrimaryValue(value="indirect", source="sun-tzu", weight=1.0)
            )
        },
    )
    result = render_for_runtime(ir, "inject")
    assert "You embody Sun Tzu" in result
    assert "Communication: indirect" in result
    assert isinstance(result, str)


def test_render_for_runtime_text_still_plain(minimal_pack_dir):
    """Text format is no longer supported by renderer.inject; it's only for ContextBlock."""
    # This test is now for ContextBlock.to_prompt() instead
    pack = None
    try:
        from agentic_mindset.pack import CharacterPack
        pack = CharacterPack.load(minimal_pack_dir)
    except:
        pytest.skip("pack not available")
    if pack:
        block = ContextBlock.from_packs([(pack, 1.0)])
        result = block.to_prompt("plain_text")
        assert "THINKING FRAMEWORK:" in result
        assert "DECISION POLICY:" not in result


def test_render_for_runtime_inject_requires_weighted_packs(minimal_pack_dir):
    """render_for_runtime from renderer.inject requires BehaviorIR, not ContextBlock."""
    from agentic_mindset.ir.models import BehaviorIR, Preamble
    ir = BehaviorIR(
        preamble=Preamble(personas=[("sun-tzu", 1.0)], text="Test"),
        risk_tolerance="medium",
        time_horizon="long-term",
        slots={},
    )
    # This should work fine with BehaviorIR
    result = render_for_runtime(ir, "inject")
    assert "Test" in result


def test_run_inject_format_produces_5_sections(gen_registry):
    """mindset run with default --format inject writes behavioral block to tempfile."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"), \
         patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
        result = runner.invoke(app, [
            "run", "claude",
            "--persona", "sun-tzu",
            "--registry", str(gen_registry),
            "test query",
        ])
    assert result.exit_code == 0


def test_explain_yaml_generate_single(gen_registry):
    """--explain on single character produces YAML with decision_policy: {id}-only."""
    result = runner.invoke(app, [
        "generate", "sun-tzu", "--explain",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stderr)
    assert len(data["personas"]) == 1
    assert "sun-tzu" in data["personas"][0]
    assert data["merged"]["decision_policy"] == "sun-tzu-only"
    assert data["removed_conflicts"] == []


def test_explain_yaml_generate_multi_dominant(gen_registry):
    """--explain with unequal weights produces decision_policy: {dominant}-dominant."""
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--weights", "6,4", "--explain",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stderr)
    assert len(data["personas"]) == 2
    assert data["merged"]["decision_policy"] == "sun-tzu-dominant"
    assert isinstance(data["removed_conflicts"], list)


def test_explain_yaml_generate_equal_weights(gen_registry):
    """--explain with equal weights produces decision_policy: equal-blend."""
    result = runner.invoke(app, [
        "generate", "sun-tzu", "marcus-aurelius",
        "--explain",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stderr)
    assert data["merged"]["decision_policy"] == "equal-blend"


def test_explain_yaml_generate_has_risk_tolerance(gen_registry):
    """--explain merged block includes risk_tolerance and time_horizon."""
    result = runner.invoke(app, [
        "generate", "sun-tzu", "--explain",
        "--registry", str(gen_registry),
    ])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stderr)
    assert data["merged"]["risk_tolerance"] == "medium"
    assert data["merged"]["time_horizon"] == "long-term"


def test_explain_yaml_run(gen_registry):
    """mindset run --explain outputs YAML to stderr (text path has 'merged' structure)."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/claude"), \
         patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
        result = runner.invoke(app, [
            "run", "claude",
            "--persona", "sun-tzu",
            "--format", "text",
            "--registry", str(gen_registry),
            "--explain",
            "test query",
        ])
    assert result.exit_code == 0
    data = yaml.safe_load(result.stderr)
    assert "personas" in data
    assert "merged" in data
    assert "removed_conflicts" in data
    assert data["merged"]["decision_policy"] == "sun-tzu-only"


# ── inject path end-to-end (mocked runtime) ───────────────────────────────────

def test_run_inject_produces_behavioral_output(conflict_registry):
    """run --format inject should produce INTERACTION RULES section."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/echo"), \
         patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
        result = runner.invoke(app, [
            "run", "echo",
            "--persona", "sun-tzu",
            "--format", "inject",
            "--registry", str(conflict_registry),
        ])
    # echo is not a real runtime; test that inject path doesn't error during compile
    assert result.exit_code in (0, 1)  # 0 if echo succeeds, 1 if echo not found


def test_run_inject_explain_emits_yaml_with_slots(conflict_registry):
    """--explain on inject path should emit YAML with 'slots' key to stderr."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/echo"), \
         patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
        result = runner.invoke(app, [
            "run", "echo",
            "--persona", "sun-tzu",
            "--persona", "marcus-aurelius",
            "--weights", "6,4",
            "--format", "inject",
            "--explain",
            "--registry", str(conflict_registry),
        ])
    # explain goes to stderr
    explain_yaml = result.stderr if hasattr(result, "stderr") else ""
    # If explain output went to stderr, it should be parseable as YAML
    if explain_yaml.strip():
        data = yaml.safe_load(explain_yaml)
        assert "personas" in data
        assert "slots" in data


def test_run_text_path_unchanged(conflict_registry):
    """run --format text should still work (ContextBlock path)."""
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/echo"), \
         patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
        result = runner.invoke(app, [
            "run", "echo",
            "--persona", "sun-tzu",
            "--format", "text",
            "--registry", str(conflict_registry),
        ])
    assert result.exit_code in (0, 1)


def test_run_inject_unknown_format_exits_nonzero(conflict_registry):
    with patch("agentic_mindset.cli.shutil.which", return_value="/usr/bin/echo"), \
         patch("agentic_mindset.cli.subprocess.run", return_value=MagicMock(returncode=0)):
        result = runner.invoke(app, [
            "run", "echo",
            "--persona", "sun-tzu",
            "--format", "xml_tagged",  # not a valid runtime format
            "--registry", str(conflict_registry),
        ])
    assert result.exit_code == 1


# ── render_for_runtime import changed ─────────────────────────────────────────

def test_render_for_runtime_imported_from_renderer(minimal_pack_dir):
    """render_for_runtime in cli should now dispatch to IR renderer for inject."""
    from agentic_mindset.renderer.inject import render_for_runtime
    from agentic_mindset.ir.models import BehaviorIR, Preamble, ResolvedSlot, PrimaryValue
    ir = BehaviorIR(
        preamble=Preamble(personas=[("sun-tzu", 1.0)], text="You embody Sun Tzu (100%)."),
        risk_tolerance="high",
        time_horizon="long-term",
        slots={
            "communication": ResolvedSlot(
                primary=PrimaryValue(value="indirect", source="sun-tzu", weight=1.0)
            )
        },
    )
    result = render_for_runtime(ir, "inject")
    assert "Communication: indirect" in result
