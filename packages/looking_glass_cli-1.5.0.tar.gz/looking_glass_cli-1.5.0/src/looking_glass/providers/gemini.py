"""Gemini image-generation provider for Looking Glass."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from google import genai
from google.genai import types
from PIL import Image

from looking_glass import config
from looking_glass.providers.base import Provider, unique_output_path

MAX_RETRIES = 5
MAX_SAFETY_RETRIES = 1
INITIAL_BACKOFF = 2.0

_SAFETY_FINISH_REASONS = {
    types.FinishReason.SAFETY,
    types.FinishReason.IMAGE_SAFETY,
    types.FinishReason.PROHIBITED_CONTENT,
    types.FinishReason.IMAGE_PROHIBITED_CONTENT,
    types.FinishReason.SPII,
    types.FinishReason.BLOCKLIST,
}

MODEL = "gemini-3.1-flash-image-preview"

# Translate OpenAI's "moderation: low" to permissive Gemini safety settings.
SAFETY_SETTINGS = [
    types.SafetySetting(
        category=types.HarmCategory.HARM_CATEGORY_HATE_SPEECH,
        threshold=types.HarmBlockThreshold.BLOCK_ONLY_HIGH,
    ),
    types.SafetySetting(
        category=types.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
        threshold=types.HarmBlockThreshold.BLOCK_ONLY_HIGH,
    ),
    types.SafetySetting(
        category=types.HarmCategory.HARM_CATEGORY_HARASSMENT,
        threshold=types.HarmBlockThreshold.BLOCK_ONLY_HIGH,
    ),
    types.SafetySetting(
        category=types.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
        threshold=types.HarmBlockThreshold.BLOCK_ONLY_HIGH,
    ),
]


class GeminiProvider(Provider):
    """Image generation via Google Gemini's native image generation."""

    name = "Gemini"
    config_key = "gemini_api_key"

    def __init__(self) -> None:
        self._client: genai.Client | None = None

    def get_client(self) -> genai.Client:
        if self._client is None:
            api_key = config.get(self.config_key)
            if not api_key:
                raise RuntimeError(
                    "Gemini API key not configured. "
                    f"Run: glass config set {self.config_key} <your-key>"
                )
            self._client = genai.Client(api_key=api_key)
        return self._client

    def generate_outfit_image(
        self,
        photo_path: Path,
        outfit_name: str,
        outfit_description: str,
        output_dir: Path,
    ) -> Path:
        client = self.get_client()
        prompt = self.build_prompt(outfit_description)
        photo_name = photo_path.stem

        image = Image.open(photo_path)

        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = unique_output_path(output_dir, f"{photo_name}_{outfit_name}")

        backoff = INITIAL_BACKOFF
        for attempt in range(MAX_RETRIES):
            try:
                result = client.models.generate_content(
                    model=MODEL,
                    contents=[prompt, image],
                    config=types.GenerateContentConfig(
                        safety_settings=SAFETY_SETTINGS,
                    ),
                )
            except Exception as exc:
                if "429" in str(exc) or "resource_exhausted" in str(exc).lower():
                    if attempt == MAX_RETRIES - 1:
                        raise
                    time.sleep(backoff)
                    backoff *= 2
                    continue
                raise

            generated = self._extract_image(result)
            if generated is not None:
                generated.save(output_path)
                return output_path

            # No image in response — check whether it was a safety rejection.
            finish_reason = self._get_finish_reason(result)
            is_safety = finish_reason in _SAFETY_FINISH_REASONS
            allowed_retries = MAX_SAFETY_RETRIES if is_safety else MAX_RETRIES

            if attempt >= allowed_retries:
                if is_safety:
                    raise RuntimeError(
                        f"Image rejected by Gemini safety filter (reason: {finish_reason})."
                    )
                break

            time.sleep(backoff)
            backoff *= 2

        raise RuntimeError(
            "Gemini returned no image after multiple attempts. "
            "This can happen when safety filters intermittently block the request."
        )

    @staticmethod
    def _extract_image(result: Any) -> Image.Image | None:
        """Extract the first generated image from a Gemini response, or None."""
        if not result.candidates:
            return None
        content = result.candidates[0].content
        if content is None or not content.parts:
            return None
        for part in content.parts:
            if part.inline_data is not None:
                return part.as_image()
        return None

    @staticmethod
    def _get_finish_reason(result: Any) -> types.FinishReason | None:
        """Return the finish_reason of the first candidate, or None."""
        if not result.candidates:
            return None
        return result.candidates[0].finish_reason
