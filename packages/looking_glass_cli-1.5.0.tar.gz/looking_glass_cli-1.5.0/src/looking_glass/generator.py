"""Image generation facade for Looking Glass.

This module is kept for backward compatibility. New code should use the
provider classes in ``looking_glass.providers`` directly.
"""

from __future__ import annotations

from pathlib import Path

from looking_glass.providers.base import PROMPT_TEMPLATE  # noqa: F401 — re-export
from looking_glass.providers.openai import OpenAIProvider

# Re-export the prompt template so any external consumers still work.

_openai = OpenAIProvider()


def get_client():
    """Return an OpenAI client (legacy helper)."""
    return _openai.get_client()


def build_prompt(outfit_description: str) -> str:
    """Build the image-edit prompt from an outfit description."""
    return _openai.build_prompt(outfit_description)


def generate_outfit_image(
    photo_path: Path,
    outfit_name: str,
    outfit_description: str,
    output_dir: Path,
    *,
    client=None,
) -> Path:
    """Generate an outfit image using the OpenAI provider (legacy helper)."""
    return _openai.generate_outfit_image(photo_path, outfit_name, outfit_description, output_dir)
