"""Configuration management for Looking Glass.

Reads and writes ~/.looking-glass/config.toml.
"""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

import tomli_w

APP_DIR = Path.home() / ".looking-glass"
PHOTOS_DIR = APP_DIR / "photos"
OUTFITS_DIR = APP_DIR / "outfits"
CONFIG_FILE = APP_DIR / "config.toml"

# All supported configuration options with metadata.
CONFIG_SCHEMA: list[dict[str, Any]] = [
    {
        "key": "openai_api_key",
        "type": str,
        "default": None,
        "required": False,
        "description": "OpenAI API key for image generation.",
    },
    {
        "key": "gemini_api_key",
        "type": str,
        "default": None,
        "required": False,
        "description": "Google Gemini API key for image generation.",
    },
    {
        "key": "max_workers",
        "type": int,
        "default": 4,
        "required": False,
        "description": "Max parallel image generations (higher = faster, but uses more API quota).",
    },
]

# Keys that hold API credentials (used for masking in display).
API_KEY_FIELDS: set[str] = {"openai_api_key", "gemini_api_key"}

_SCHEMA_KEYS: set[str] = {opt["key"] for opt in CONFIG_SCHEMA}


def ensure_dirs() -> None:
    """Create the app directories if they don't exist."""
    for d in (APP_DIR, PHOTOS_DIR, OUTFITS_DIR):
        d.mkdir(parents=True, exist_ok=True)
    APP_DIR.chmod(0o700)


def _read_config() -> dict:
    ensure_dirs()
    if CONFIG_FILE.exists():
        data = tomllib.loads(CONFIG_FILE.read_text())
        data = _migrate_legacy_keys(data)
        return data
    return {}


def _migrate_legacy_keys(data: dict) -> dict:
    """Migrate deprecated config keys to their new names."""
    if "api_key" in data and "openai_api_key" not in data:
        data["openai_api_key"] = data.pop("api_key")
        _write_config(data)
    elif "api_key" in data:
        del data["api_key"]
        _write_config(data)
    return data


def _write_config(data: dict) -> None:
    ensure_dirs()
    CONFIG_FILE.write_bytes(tomli_w.dumps(data).encode())
    CONFIG_FILE.chmod(0o600)


def get(key: str, default=None):
    """Get a config value by key (dot-notation not supported)."""
    return _read_config().get(key, default)


def is_known_key(key: str) -> bool:
    """Return True if *key* is a recognised config option."""
    return key in _SCHEMA_KEYS


def set_value(key: str, value: str) -> None:
    """Set a config value, coercing to the schema type when known."""
    schema_entry = next((o for o in CONFIG_SCHEMA if o["key"] == key), None)
    data = _read_config()
    if schema_entry is not None and schema_entry["type"] is not str:
        try:
            data[key] = schema_entry["type"](value)
        except (ValueError, TypeError):
            data[key] = value
    else:
        data[key] = value
    _write_config(data)


def get_all() -> dict:
    """Return the full config dict."""
    return _read_config()


def has_any_api_key() -> bool:
    """Return True if at least one provider API key is configured."""
    return any(get(k) for k in API_KEY_FIELDS)


def get_max_workers() -> int:
    """Return the max parallel workers for image generation (default 4)."""
    value = get("max_workers")
    if value is None:
        return 4
    return int(value)
