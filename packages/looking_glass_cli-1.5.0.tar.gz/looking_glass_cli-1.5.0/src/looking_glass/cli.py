"""CLI entry point for Looking Glass."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import click
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn

from looking_glass import __version__, config, interactive, storage

console = Console()


@click.group(invoke_without_command=True)
@click.option("--output", "-o", type=click.Path(), default=".", help="Output directory for generated images.")
@click.version_option(__version__, prog_name="glass")
@click.pass_context
def main(ctx: click.Context, output: str) -> None:
    """Looking Glass — Use your photos to design and try on outfits."""
    ctx.ensure_object(dict)
    ctx.obj["output"] = Path(output).resolve()

    if ctx.invoked_subcommand is None:
        _interactive_mode(ctx.obj["output"])


def _interactive_mode(output_dir: Path) -> None:
    """Run the interactive photo + outfit selection and generation flow."""
    console.print("[bold magenta]✨ Looking Glass[/]\n")

    photo = interactive.select_photo()
    if photo is None:
        return

    outfits = interactive.select_outfits()
    if not outfits:
        console.print("[yellow]No outfits selected.[/]")
        return

    provider = interactive.select_provider()
    if provider is None:
        return

    max_workers = min(config.get_max_workers(), len(outfits))

    results: list[tuple[str, Path | None, str | None]] = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        console=console,
    ) as progress:
        task = progress.add_task("Generating outfits…", total=len(outfits))
        futures = {}

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            for outfit in outfits:
                future = pool.submit(
                    provider.generate_outfit_image,
                    photo_path=photo["path"],
                    outfit_name=outfit["name"],
                    outfit_description=outfit["description"],
                    output_dir=output_dir,
                )
                futures[future] = outfit["name"]

            for future in as_completed(futures):
                name = futures[future]
                try:
                    path = future.result()
                    results.append((name, path, None))
                except Exception as e:
                    results.append((name, None, str(e)))
                progress.advance(task)

    console.print()
    for name, path, error in results:
        if path:
            console.print(f"[green]✓[/] Saved: [bold]{path}[/]")
        else:
            console.print(f"[red]✗[/] Failed for {name}: {error}")


# ── Photo commands ──────────────────────────────────────────────


@main.group("photo")
def photo_group() -> None:
    """Manage photos."""


@photo_group.command("add")
@click.argument("file", type=click.Path(exists=True))
@click.option("--name", "-n", default=None, help="Custom name for the photo.")
def photo_add(file: str, name: str | None) -> None:
    """Add a photo to Looking Glass."""
    try:
        dest = storage.add_photo(Path(file), name)
        console.print(f"[green]✓[/] Photo saved as [bold]{dest.stem}[/]")
    except (FileNotFoundError, ValueError) as e:
        console.print(f"[red]✗[/] {e}")
        raise SystemExit(1)


@photo_group.command("list")
def photo_list() -> None:
    """List all stored photos."""
    interactive.show_photos_table()


@photo_group.command("remove")
@click.argument("name")
def photo_remove(name: str) -> None:
    """Remove a stored photo by name."""
    if storage.remove_photo(name):
        console.print(f"[green]✓[/] Removed photo [bold]{name}[/]")
    else:
        console.print(f"[red]✗[/] Photo [bold]{name}[/] not found")
        raise SystemExit(1)


# ── Outfit commands ─────────────────────────────────────────────


@main.group("outfit")
def outfit_group() -> None:
    """Manage outfit descriptions."""


@outfit_group.command("add")
@click.argument("file", type=click.Path(exists=True))
@click.option("--name", "-n", default=None, help="Custom name for the outfit.")
def outfit_add(file: str, name: str | None) -> None:
    """Add an outfit description file to Looking Glass."""
    try:
        dest = storage.add_outfit(Path(file), name)
        console.print(f"[green]✓[/] Outfit saved as [bold]{dest.stem}[/]")
    except FileNotFoundError as e:
        console.print(f"[red]✗[/] {e}")
        raise SystemExit(1)


@outfit_group.command("create")
@click.option("--name", "-n", required=True, help="Name for the outfit.")
def outfit_create(name: str) -> None:
    """Create an outfit description by opening your default editor."""
    text = click.edit(f"# Describe the outfit '{name}' below, then save and close.\n")
    if text is None:
        console.print("[yellow]Cancelled — editor closed without saving.[/]")
        return

    description = text.strip()
    if not description:
        console.print("[yellow]Cancelled — outfit description is empty.[/]")
        return

    dest = storage.create_outfit(name, description)
    console.print(f"[green]✓[/] Outfit saved as [bold]{dest.stem}[/]")


@outfit_group.command("capture")
@click.argument("file", type=click.Path(exists=True))
@click.option("--name", "-n", default=None, help="Name for the outfit.")
@click.option("--instructions", "-i", default=None, help="Custom instructions for the AI (e.g. 'change shirt color to green').")
def outfit_capture(file: str, name: str | None, instructions: str | None) -> None:
    """Capture an outfit from a photo using AI vision (requires OpenAI API key).

    Sends the photo to OpenAI's vision model to extract a structured
    outfit description. Requires openai_api_key to be configured.

    Use --instructions / -i to provide custom text that the AI will merge
    with its visual analysis (e.g. overriding colours or garment types).
    """
    import questionary

    from looking_glass.providers import get_describe_provider

    provider = get_describe_provider()
    if provider is None:
        console.print(
            "[red]✗[/] No provider available for outfit capture. "
            "Set an OpenAI API key: [bold]glass config set openai_api_key <key>[/]"
        )
        raise SystemExit(1)

    photo_path = Path(file).resolve()

    if name is None:
        name = questionary.text(
            "Outfit name:",
            validate=lambda v: len(v.strip()) > 0 or "Name cannot be empty",
        ).unsafe_ask()
        name = name.strip()

    if instructions is None:
        raw = questionary.text(
            "Instructions (optional, press Enter to skip):",
        ).unsafe_ask()
        if raw and raw.strip():
            instructions = raw.strip()

    with console.status(f"[bold cyan]Analysing photo with {provider.name}…"):
        try:
            description = provider.describe_outfit(
                photo_path, instructions=instructions
            )
        except Exception as e:
            console.print(f"[red]✗[/] Failed to describe outfit: {e}")
            raise SystemExit(1)

    console.print(f"\n[bold]Extracted description:[/]\n{description}\n")

    dest = storage.create_outfit(name, description)
    console.print(f"[green]✓[/] Outfit saved as [bold]{dest.stem}[/]")


@outfit_group.command("capturefolder")
@click.argument("folder", type=click.Path(exists=True, file_okay=False), default=".")
@click.option("--overwrite", is_flag=True, default=False, help="Overwrite existing outfits with the same name.")
def outfit_capturefolder(folder: str, overwrite: bool) -> None:
    """Capture outfits from every photo in a folder using AI vision.

    Scans FOLDER (default: current directory) for image files and extracts
    a structured outfit description from each one. Photo filenames are used
    as outfit names. Requires an API key for a vision-capable provider.
    """
    from looking_glass.providers import get_describe_provider
    from looking_glass.storage import SUPPORTED_IMAGE_EXTENSIONS

    provider = get_describe_provider()
    if provider is None:
        console.print(
            "[red]✗[/] No provider available for outfit capture. "
            "Set an OpenAI API key: [bold]glass config set openai_api_key <key>[/]"
        )
        raise SystemExit(1)

    folder_path = Path(folder).resolve()
    images = sorted(
        f for f in folder_path.iterdir()
        if f.is_file() and f.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS
    )

    if not images:
        console.print(f"[yellow]No image files found in {folder_path}[/]")
        return

    console.print(f"[bold cyan]Found {len(images)} image(s) in {folder_path}[/]\n")

    skipped: list[str] = []
    if not overwrite:
        kept: list[Path] = []
        for img in images:
            if storage.get_outfit(img.stem) is not None:
                skipped.append(img.stem)
            else:
                kept.append(img)
        images = kept

    if skipped:
        console.print(f"[yellow]Skipping {len(skipped)} existing outfit(s): {', '.join(skipped)}[/]")
        console.print("[dim]Use --overwrite to replace them.[/]\n")

    if not images:
        console.print("[yellow]Nothing to capture — all outfits already exist.[/]")
        return

    max_workers = min(config.get_max_workers(), len(images))
    results: list[tuple[str, Path | None, str | None]] = []

    # Build a mapping of sidecar .txt instructions keyed by image stem.
    sidecar_instructions: dict[str, str] = {}
    for img in images:
        txt_path = img.with_suffix(".txt")
        if txt_path.is_file():
            content = txt_path.read_text().strip()
            if content:
                sidecar_instructions[img.stem] = content

    if sidecar_instructions:
        console.print(
            f"[cyan]Found instructions for {len(sidecar_instructions)} photo(s): "
            f"{', '.join(sorted(sidecar_instructions))}[/]\n"
        )

    def _capture(photo_path: Path) -> tuple[str, Path]:
        name = photo_path.stem
        instructions = sidecar_instructions.get(name)
        description = provider.describe_outfit(
            photo_path, instructions=instructions
        )
        dest = storage.create_outfit(name, description)
        return name, dest

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        console=console,
    ) as progress:
        task = progress.add_task("Capturing outfits…", total=len(images))
        futures = {}

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            for img in images:
                future = pool.submit(_capture, img)
                futures[future] = img.stem

            for future in as_completed(futures):
                name = futures[future]
                try:
                    _, dest = future.result()
                    results.append((name, dest, None))
                except Exception as e:
                    results.append((name, None, str(e)))
                progress.advance(task)

    console.print()
    success = sum(1 for _, p, _ in results if p)
    failed = sum(1 for _, _, e in results if e)

    for name, path, error in results:
        if path:
            console.print(f"[green]✓[/] Saved outfit [bold]{name}[/]")
        else:
            console.print(f"[red]✗[/] Failed for {name}: {error}")

    console.print(f"\n[bold]Done:[/] {success} captured, {failed} failed, {len(skipped)} skipped")


@outfit_group.command("list")
def outfit_list() -> None:
    """List all stored outfits."""
    interactive.show_outfits_table()


@outfit_group.command("remove")
@click.argument("name")
def outfit_remove(name: str) -> None:
    """Remove a stored outfit by name."""
    if storage.remove_outfit(name):
        console.print(f"[green]✓[/] Removed outfit [bold]{name}[/]")
    else:
        console.print(f"[red]✗[/] Outfit [bold]{name}[/] not found")
        raise SystemExit(1)


# ── Config commands ─────────────────────────────────────────────


@main.group("config")
def config_group() -> None:
    """Manage configuration."""


@config_group.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str) -> None:
    """Set a configuration value (e.g., glass config set openai_api_key sk-...)."""
    if not config.is_known_key(key):
        console.print(f"[yellow]⚠[/]  [bold]{key}[/] is not a recognised config option — saving anyway.")
    config.set_value(key, value)
    display = f"{value[:8]}…" if key in config.API_KEY_FIELDS and len(value) > 8 else value
    console.print(f"[green]✓[/] Set [bold]{key}[/] = {display}")


@config_group.command("show")
def config_show() -> None:
    """Show all available configuration options and their current values."""
    from rich.table import Table

    data = config.get_all()

    table = Table(title="Looking Glass Configuration", show_lines=False, highlight=True)
    table.add_column("Key", style="cyan", no_wrap=True)
    table.add_column("Description", style="white")
    table.add_column("Default", style="dim")
    table.add_column("Current Value", style="green")

    for opt in config.CONFIG_SCHEMA:
        key = opt["key"]
        raw = data.get(key)
        if raw is None:
            current = "[dim]not set[/]"
        elif key in config.API_KEY_FIELDS and len(str(raw)) > 8:
            current = f"{str(raw)[:8]}…"
        else:
            current = str(raw)

        default = str(opt["default"]) if opt["default"] is not None else "[dim]—[/]"
        table.add_row(key, opt["description"], default, current)

    # Show any extra keys the user has set that aren't in the schema.
    for key, value in data.items():
        if not config.is_known_key(key):
            display = f"{str(value)[:8]}…" if key in config.API_KEY_FIELDS and len(str(value)) > 8 else str(value)
            table.add_row(f"[yellow]{key}[/]", "[yellow]unknown option[/]", "—", display)

    console.print(table)
    console.print(
        f"\n[dim]Config file: {config.CONFIG_FILE}[/]"
        "\n[dim]To set a value: [bold]glass config set <key> <value>[/][/]"
    )
