"""Looking Glass — Use your photos to design and try on outfits."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("looking-glass-cli")
except PackageNotFoundError:
    __version__ = "unknown"
