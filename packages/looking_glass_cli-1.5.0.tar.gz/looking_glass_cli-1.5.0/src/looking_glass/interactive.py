"""Interactive selection UI for Looking Glass."""

from __future__ import annotations

import questionary
from rich.console import Console
from rich.table import Table

from looking_glass import storage
from looking_glass.providers import get_all_provider_classes, get_available_providers
from looking_glass.providers.base import Provider

console = Console()

_CHANGE_FILTER = "__change_filter__"


def _match(query: str, name: str) -> bool:
    """Case-insensitive substring match."""
    return query.lower() in name.lower()


def select_photo() -> dict | None:
    """Prompt the user to select a photo, with optional search filtering."""
    photos = storage.list_photos()
    if not photos:
        console.print("[yellow]No photos found.[/] Add one with: [bold]glass photo <file>[/]")
        return None

    query = ""
    while True:
        query = questionary.text(
            "Search photos (enter to show all):",
            default=query,
        ).ask()
        if query is None:
            return None

        filtered = [p for p in photos if _match(query, p["name"])] if query else photos

        if not filtered:
            console.print(f"[yellow]No photos match '{query}'.[/]")
            continue

        choices = [questionary.Choice(title=p["name"], value=p) for p in filtered]
        choices.append(questionary.Choice(title="↩ Change filter", value=_CHANGE_FILTER))

        result = questionary.select(
            "Select a photo:",
            choices=choices,
            use_shortcuts=False,
            use_indicator=True,
        ).ask()

        if result is None:
            return None
        if result == _CHANGE_FILTER:
            continue
        return result


def select_outfits() -> list[dict]:
    """Prompt the user to select outfits, with search filtering and persistent selections."""
    outfits = storage.list_outfits()
    if not outfits:
        console.print(
            "[yellow]No outfits found.[/] Add one with: [bold]glass outfit <file>[/]"
        )
        return []

    selected_names: set[str] = set()

    while True:
        if selected_names:
            console.print(f"[dim]Selected so far: {', '.join(sorted(selected_names))}[/]")

        query = questionary.text("Search outfits (enter to show all):").ask()
        if query is None:
            break

        filtered = [o for o in outfits if _match(query, o["name"])] if query else outfits

        if not filtered:
            console.print(f"[yellow]No outfits match '{query}'.[/]")
            continue

        choices = [
            questionary.Choice(
                title=o["name"],
                value=o["name"],
                checked=o["name"] in selected_names,
            )
            for o in filtered
        ]

        picked = questionary.checkbox(
            "Toggle outfits (space to toggle, enter to confirm):",
            choices=choices,
        ).ask()

        if picked is None:
            break

        # Merge: for visible items, sync with checkbox result
        visible_names = {o["name"] for o in filtered}
        picked_set = set(picked)
        selected_names = (selected_names - visible_names) | picked_set

        if not questionary.confirm("Add more outfits?", default=False).ask():
            break

    return [o for o in outfits if o["name"] in selected_names]


def select_provider() -> Provider | None:
    """Prompt the user to select an image-generation provider.

    Auto-selects when only one provider is available.
    Always prints a hint about unconfigured providers.
    Returns the chosen Provider instance, or None if no providers are available.
    """
    available = get_available_providers()
    all_classes = get_all_provider_classes()

    if not available:
        console.print(
            "[red]No image-generation providers configured.[/]\n"
            "Add at least one API key to get started:"
        )
        for cls in all_classes:
            console.print(f"  [bold]glass config set {cls.config_key} <your-key>[/]")
        return None

    # Build the reminder for unconfigured providers.
    unconfigured = [
        cls for cls in all_classes if cls.config_key not in {p.config_key for p in available}
    ]

    provider: Provider
    if len(available) == 1:
        provider = available[0]
        console.print(f"Using [bold]{provider.name}[/] for image generation.\n")
    else:
        choices = [
            questionary.Choice(title=p.name, value=p) for p in available
        ]
        selected = questionary.select(
            "Select an image generation provider:",
            choices=choices,
            use_shortcuts=False,
            use_indicator=True,
        ).ask()
        if selected is None:
            return None
        provider = selected
        console.print()

    if unconfigured:
        hints = ", ".join(
            f"[bold]{cls.name}[/] ([dim]glass config set {cls.config_key} <key>[/])"
            for cls in unconfigured
        )
        console.print(f"[dim]💡 Enable more providers: {hints}[/]\n")

    return provider


def show_photos_table() -> None:
    """Display a table of all stored photos."""
    photos = storage.list_photos()
    if not photos:
        console.print("[yellow]No photos stored yet.[/]")
        return

    table = Table(title="Photos")
    table.add_column("Name", style="cyan")
    table.add_column("Path", style="dim")
    for p in photos:
        table.add_row(p["name"], str(p["path"]))
    console.print(table)


def show_outfits_table() -> None:
    """Display a table of all stored outfits."""
    outfits = storage.list_outfits()
    if not outfits:
        console.print("[yellow]No outfits stored yet.[/]")
        return

    table = Table(title="Outfits")
    table.add_column("Name", style="cyan")
    for o in outfits:
        table.add_row(o["name"])
    console.print(table)
