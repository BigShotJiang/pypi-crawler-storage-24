import {createApp} from 'vue'
import "@pdn-certic/vue3-jama/dist/style.css";
import {VueJamaPlugin, VueJamaApp} from "@pdn-certic/vue3-jama";
import 'vuetify/styles'

const annotableImages = document.getElementById('app')?.dataset.annotations != undefined &&
    document.getElementById('app')?.dataset.annotations?.toLowerCase()!=='false';

const title = document.getElementById('app')?.dataset.title
let jamaOptions: any = {
    title: title,
    assetsPrefix:'/static/ui/assets/'
};

jamaOptions.annotableImages = annotableImages;
console.debug('Enabled annotations ?', jamaOptions.annotableImages);

const app = createApp(VueJamaApp, jamaOptions);
app.use(VueJamaPlugin, true);
app.mount('#app');
