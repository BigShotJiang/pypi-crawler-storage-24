"""
AI Security Management SDK Exceptions

Exception hierarchy for categorizing SDK errors.
"""

from typing import Optional


class MgmtSdkBaseError(Exception):
    """Base exception class for all AI Security SDK exceptions.

    This is the root exception class from which all other SDK exceptions inherit.
    All SDK exceptions will be instances of this class.

    Attributes:
        message: Human-readable error message describing the exception.

    Example:
        try:
            # SDK operation
            pass
        except MgmtSdkBaseError as e:
            print(f"SDK error: {e}")
    """

    def __init__(self, message: str = "") -> None:
        """Initialize the base exception.

        Args:
            message: Error message describing what went wrong.
        """
        self.message = message
        super().__init__(self.message)

    def __str__(self) -> str:
        """Return string representation of the exception.

        Returns:
            Formatted error message with exception class name.
        """
        return f"{self.__class__.__name__}: {self.message}"


# Configuration Related Exceptions


class MgmtSdkConfigurationError(MgmtSdkBaseError):
    """Exception for SDK configuration errors.

    Raised when there are issues with SDK initialization or configuration.
    This includes missing credentials, invalid URLs, or malformed configuration.

    Example:
        if not client_id:
            raise MgmtSdkConfigurationError("Missing client credentials")
    """


class MissingVariableError(MgmtSdkConfigurationError):
    """Exception for missing required configuration variables.

    Raised when required parameters like client_id, client_secret, or tsg_id are missing
    during SDK initialization or method calls.

    Example:
        if not client_id:
            raise MissingVariableError("client_id is required")
    """


class InvalidConfigurationError(MgmtSdkConfigurationError):
    """Exception for invalid configuration values.

    Raised when configuration parameters have invalid formats or values.
    This includes malformed URLs, invalid credentials format, or out-of-range values.

    Example:
        if not is_valid_url(base_url):
            raise InvalidConfigurationError(f"Invalid base_url: {base_url}")
    """


class PayloadConfigurationError(MgmtSdkConfigurationError):
    """Exception for payload configuration errors.

    Raised when there are issues with request payload configuration,
    such as missing required fields or invalid payload structure.

    Example:
        if not payload.get('required_field'):
            raise PayloadConfigurationError("Missing required field in payload")
    """


# API Request/Response Errors


class MgmtSdkAPIError(MgmtSdkBaseError):
    """Base exception for API-related errors.

    Raised when API requests fail. This is the base class for all HTTP-related
    errors including client errors (4xx) and server errors (5xx).

    Attributes:
        status_code: HTTP status code returned by the API (if available).
        response_body: Response body from the API (if available).

    Example:
        raise MgmtSdkAPIError("API request failed", status_code=500)
    """

    def __init__(
        self,
        message: str = "",
        status_code: Optional[int] = None,
        response_body: Optional[str] = None,
    ) -> None:
        """Initialize the API error.

        Args:
            message: Error message describing what went wrong.
            status_code: HTTP status code from the API response.
            response_body: Raw response body from the API.
        """
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body

    def __str__(self) -> str:
        """Return string representation of the exception.

        Returns:
            Formatted error message with HTTP status code and response body if available.
        """
        parts = [f"{self.__class__.__name__}"]

        if self.status_code:
            parts.append(f"(HTTP {self.status_code})")

        parts.append(f": {self.message}")

        if self.response_body:
            parts.append(f"\nResponse body: {self.response_body}")

        return "".join(parts)


class MgmtSdkServerError(MgmtSdkAPIError):
    """Exception for server-side API errors (HTTP 5xx).

    Raised when the API returns a 5xx status code indicating server errors.
    These are typically temporary issues and can often be resolved by retrying.

    Example:
        raise MgmtSdkServerError("Service unavailable", status_code=503)
    """


class MgmtSdkClientError(MgmtSdkAPIError):
    """Exception for client-side API errors (HTTP 4xx).

    Raised when the API returns a 4xx status code indicating client errors.
    This includes authentication failures, authorization errors, bad requests,
    resource not found, conflicts, and rate limiting.

    Example:
        raise MgmtSdkClientError("Bad request", status_code=400)
    """
