"""
Resource classes for AI Security Management API.

This module provides resource classes for different API endpoint groups,
following a fluent API design pattern.
"""

from .inline.ai_sec_profiles import AISecProfile
from .inline.api_keys import ApiKey
from .inline.custom_topic import CustomTopic
from .inline.customer_app import CustomerApp
from .inline.deployment_profiles import DeploymentProfile
from .inline.dlp_profiles import DlpProfile
from .inline.oauth import OAuth

__all__ = [
    "AISecProfile",
    "ApiKey",
    "CustomTopic",
    "CustomerApp",
    "DeploymentProfile",
    "DlpProfile",
    "OAuth",
]
