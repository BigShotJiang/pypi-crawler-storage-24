from __future__ import annotations

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.sdk.asyncio import ApiException
from airs_api_mgmt.sdk.asyncio.api.oauth_api import OauthApi
from airs_api_mgmt.sdk.models import ClientIdAndCustomerApp
from airs_api_mgmt.sdk.models import Oauth2TokenObject
from airs_api_mgmt.resources.asyncio.base_client import BaseClient
from airs_api_mgmt.exceptions import (
    MgmtSdkAPIError,
    MgmtSdkServerError,
    MgmtSdkClientError,
    MgmtSdkBaseError,
    PayloadConfigurationError,
)
from airs_api_mgmt.utils import get_logger


class OauthAsync(BaseClient):
    """OAuth management class for handling OAuth token operations.

    This class provides methods to manage OAuth tokens including generation
    of OAuth2 access tokens for Apigee applications.
    """

    def __init__(self, config: ClientConfig):
        """Initialize OAuth with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        super().__init__(config)
        self.logger = get_logger(__name__)
        self._api = OauthApi(self.api_client)

    async def get_oauth_token(
        self,
        client_id: str,
        customer_app: str,
        token_ttl_interval: int,
        token_ttl_unit: str,
    ) -> Oauth2TokenObject:
        """Generate an OAuth2 access token for an Apigee application.

        Args:
            client_id: The client ID for the OAuth application
            customer_app: The customer application name
            token_ttl_interval: The time-to-live interval for the token
            token_ttl_unit: The time unit for the TTL (e.g., 'seconds', 'minutes', 'hours')

        Returns:
            Oauth2TokenObject: An OAuth2 token object containing the access token and metadata.

        Raises:
            MgmtSdkClientError: If OAuth token generation fails due to client error (4xx)
            MgmtSdkServerError: If OAuth token generation fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not client_id:
            raise PayloadConfigurationError("client_id is required and cannot be empty")
        if not customer_app:
            raise PayloadConfigurationError(
                "customer_app is required and cannot be empty"
            )

        self.refresh_token_if_expired()

        client_id_and_customer_app = ClientIdAndCustomerApp(
            client_id=client_id, customer_app=customer_app
        )
        try:
            self.logger.info(
                f"event={self.get_oauth_token.__name__} Generating OAuth token for client_id={client_id}, customer_app={customer_app}"
            )
            response = await self._api.get_apigee_oauth_token(
                client_id_and_customer_app=client_id_and_customer_app,
                token_ttl_unit=token_ttl_unit,
                token_ttl_interval=token_ttl_interval,
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to generate OAuth token: {e}"
            self.logger.error(
                f"event={self.get_oauth_token.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while generating OAuth token: {e}"
            self.logger.error(
                f"event={self.get_oauth_token.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)
