"""
Asyncio resource classes for AI Security Management API.

This module provides asyncio resource classes for different API endpoint groups,
following an async/await pattern.
"""

from airs_api_mgmt.resources.asyncio.api_keys import ApiKeyAsync
from airs_api_mgmt.resources.asyncio.ai_sec_profiles import AISecProfileAsync
from airs_api_mgmt.resources.asyncio.custom_topic import CustomTopicAsync
from airs_api_mgmt.resources.asyncio.customer_app import CustomerAppAsync
from airs_api_mgmt.resources.asyncio.deployment_profiles import DeploymentProfilesAsync
from airs_api_mgmt.resources.asyncio.dlp_profiles import DLPProfilesAsync
from airs_api_mgmt.resources.asyncio.oauth import OauthAsync

__all__ = [
    "ApiKeyAsync",
    "AISecProfileAsync",
    "CustomTopicAsync",
    "CustomerAppAsync",
    "DeploymentProfilesAsync",
    "DLPProfilesAsync",
    "OauthAsync",
]
