from __future__ import annotations

from typing import Optional

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.config.constants import (
    MAX_EMAIL_LENGTH,
    MAX_API_KEY_NAME_LENGTH,
)
from airs_api_mgmt.sdk.asyncio import ApiException
from airs_api_mgmt.sdk.asyncio.api.api_key_api import APIKeyApi
from airs_api_mgmt.sdk.models import APIKeyObject
from airs_api_mgmt.sdk.models import APIKeyCreationObject
from airs_api_mgmt.sdk.models import PaginatedAPIKeyObject
from airs_api_mgmt.sdk.models.regenerate_api_key_by_id_request import (
    RegenerateAPIKeyByIdRequest,
)
from airs_api_mgmt.resources.asyncio.base_client import BaseClient
from airs_api_mgmt.exceptions import (
    MgmtSdkAPIError,
    MgmtSdkServerError,
    MgmtSdkClientError,
    MgmtSdkBaseError,
    PayloadConfigurationError,
)
from airs_api_mgmt.utils import get_logger, is_valid_uuid


class ApiKeyAsync(BaseClient):
    """Async API Key management class for handling API key operations.

    This class provides async methods to manage API keys including creation, retrieval,
    regeneration, and deletion operations.
    """

    def __init__(self, config: ClientConfig):
        """Initialize ApiKeyAsync with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        super().__init__(config)
        self.logger = get_logger(__name__)
        self._api = APIKeyApi(self.api_client)

    async def create_new_api_key(
        self,
        api_key_name: str,
        cust_app: str,
        auth_code: str,
        created_by: str,
        rotation_time_interval: int,
        rotation_time_unit: str,
        cust_env: str,
        cust_cloud_provider: str,
        revoked: bool = False,
        dp_name: Optional[str] = None,
        cust_ai_agent_framework: Optional[str] = None,
    ) -> APIKeyObject:
        """Create a new API key with the specified configuration.

        Args:
            api_key_name: The name of the API key.
            cust_app: Customer application identifier.
            auth_code: Authorization code for the API key.
            created_by: Identifier of the user creating the API key.
            rotation_time_interval: Time interval for key rotation.
            rotation_time_unit: Time unit for the rotation interval.
            revoked: Whether the API key is revoked. Defaults to False.
            dp_name: Data plane name. Optional.
            cust_env: Customer environment. Optional.
            cust_cloud_provider: Customer cloud provider. Optional.
            cust_ai_agent_framework: Customer AI agent framework. Optional.

        Returns:
            APIKeyObject: The created API key object.

        Raises:
            MgmtSdkClientError: If API key creation fails due to client error (4xx)
            MgmtSdkServerError: If API key creation fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not api_key_name or len(api_key_name.strip()) == 0:
            raise PayloadConfigurationError(
                "api_key_name is required and cannot be empty"
            )
        elif len(api_key_name.strip()) > MAX_API_KEY_NAME_LENGTH:
            raise PayloadConfigurationError(
                f"api_key_name should not exceed the maximum length of {MAX_API_KEY_NAME_LENGTH} characters"
            )
        if not cust_app:
            raise PayloadConfigurationError("cust_app is required and cannot be empty")
        if not auth_code:
            raise PayloadConfigurationError("auth_code is required and cannot be empty")
        if not created_by or len(created_by.strip()) == 0:
            raise PayloadConfigurationError(
                "created_by is required and cannot be empty"
            )
        elif len(created_by.strip()) > MAX_EMAIL_LENGTH:
            raise PayloadConfigurationError(
                f"created_by cannot exceed {MAX_EMAIL_LENGTH} characters"
            )
        if rotation_time_interval <= 0 or not rotation_time_unit:
            raise PayloadConfigurationError(
                "rotation_time_interval and rotation_time_unit are required"
            )
        if revoked:
            raise PayloadConfigurationError(
                "api_key cannot be created with revoked status"
            )
        if not cust_env:
            raise PayloadConfigurationError("cust env cannot be None")
        if not cust_cloud_provider:
            raise PayloadConfigurationError("cust_cloud_provider cannot be None")

        self.refresh_token_if_expired()

        # Build API key object with only non-None optional parameters
        api_key_data = {
            "api_key_name": api_key_name.strip(),
            "cust_app": cust_app.strip(),
            "auth_code": auth_code.strip(),
            "created_by": created_by.strip(),
            "rotation_time_interval": rotation_time_interval,
            "rotation_time_unit": rotation_time_unit.strip(),
            "revoked": revoked,
        }
        if dp_name is not None:
            api_key_data["dp_name"] = dp_name.strip()
        if cust_env is not None:
            api_key_data["cust_env"] = cust_env.strip()
        if cust_cloud_provider is not None:
            api_key_data["cust_cloud_provider"] = cust_cloud_provider.strip()
        if cust_ai_agent_framework is not None:
            api_key_data["cust_ai_agent_framework"] = cust_ai_agent_framework.strip()

        api_key_object = APIKeyCreationObject(**api_key_data)
        try:
            self.logger.info(
                f"event={self.create_new_api_key.__name__} api_key_name={api_key_name}"
            )
            self.logger.debug(
                f"event={self.create_new_api_key.__name__} cust_app={cust_app!r}"
            )
            response = await self._api.create_new_api_key(api_key_object)
            return response
        except ApiException as e:
            # Convert SDK exception to custom exception
            error_msg = f"Failed to create API key: {e}"
            self.logger.error(
                f"event={self.create_new_api_key.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while creating API key: {e}"
            self.logger.error(
                f"event={self.create_new_api_key.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    async def get_all_api_keys(
        self, offset: int = 0, limit: int = 100
    ) -> PaginatedAPIKeyObject:
        """Retrieve API keys with pagination support.

        Args:
            offset: The starting position for pagination (number of records to skip).
                Defaults to 0.
            limit: The maximum number of API keys to retrieve in a single request.
                Defaults to 100.

        Returns:
            PaginatedAPIKeyObject: A paginated collection of API key objects with
                pagination metadata.

        Raises:
            MgmtSdkClientError: If API key retrieval fails due to client error (4xx)
            MgmtSdkServerError: If API key retrieval fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        if offset < 0 or limit < 0:
            raise PayloadConfigurationError("offset and/or limit not specified")
        self.refresh_token_if_expired()
        try:
            response = await self._api.get_all_api_keys_for_tsg_id(
                offset=offset, limit=limit
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to retrieve API keys: {e}"
            self.logger.error(
                f"event={self.get_all_api_keys.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while retrieving API keys: {e}"
            self.logger.error(
                f"event={self.get_all_api_keys.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    async def delete_api_key(self, api_key_name: str, updated_by: str) -> str:
        """Delete an API key by its name.

        Args:
            api_key_name: The name of the API key to delete.
            updated_by: Identifier of the user performing the deletion.

        Returns:
            RevokeAPIKey200Response: Response object confirming the deletion operation.

        Raises:
            MgmtSdkClientError: If API key deletion fails due to client error (4xx)
            MgmtSdkServerError: If API key deletion fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not api_key_name or len(api_key_name.strip()) == 0:
            raise PayloadConfigurationError(
                "api_key_name is required and cannot be empty"
            )
        if not updated_by or len(updated_by.strip()) == 0:
            raise PayloadConfigurationError(
                "updated_by is required and cannot be empty"
            )
        elif len(updated_by.strip()) > MAX_EMAIL_LENGTH:
            raise PayloadConfigurationError(
                f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
            )

        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.delete_api_key.__name__} api_key_name={api_key_name}"
            )
            response = await self._api.delete_api_key(
                api_key_name=api_key_name.strip(), updated_by=updated_by.strip()
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to delete API key: {e}"
            self.logger.error(f"event={self.delete_api_key.__name__} error={error_msg}")

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while deleting API key: {e}"
            self.logger.error(f"event={self.delete_api_key.__name__} error={error_msg}")
            raise MgmtSdkBaseError(error_msg)

    async def regenerate_api_key(
        self,
        api_key_id: str,
        rotation_time_interval: int,
        rotation_time_unit: str,
        updated_by: Optional[str] = None,
    ) -> APIKeyObject:
        """Regenerate an API key by its ID with updated rotation settings.
        Args:
            api_key_id: The unique identifier of the API key to regenerate.
            rotation_time_interval: New time interval for key rotation.
            rotation_time_unit: New time unit for the rotation interval.
            updated_by: Identifier of the user performing the regeneration.
                Optional, defaults to None.

        Returns:
            APIKeyObject: The regenerated API key object with updated details.

        Raises:
            MgmtSdkClientError: If API key regeneration fails due to client error (4xx)
            MgmtSdkServerError: If API key regeneration fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not api_key_id or len(api_key_id.strip()) == 0:
            raise PayloadConfigurationError(
                "api_key_id is required and cannot be empty"
            )
        elif not is_valid_uuid(api_key_id):
            raise PayloadConfigurationError("Invalid apiKeyId format")
        if rotation_time_interval <= 0 or not rotation_time_unit:
            raise PayloadConfigurationError(
                "rotation_time_interval and rotation_time_unit are required"
            )

        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.regenerate_api_key.__name__} api_key_id={api_key_id}"
            )
            regenerate_api_key_object = RegenerateAPIKeyByIdRequest(
                rotation_time_unit=rotation_time_unit.strip(),
                rotation_time_interval=rotation_time_interval,
                updated_by=updated_by.strip() if updated_by is not None else None,
            )
            response = await self._api.regenerate_api_key_by_id(
                api_key_id=api_key_id.strip(),
                regenerate_api_key_by_id_request=regenerate_api_key_object,
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to regenerate API key: {e}"
            self.logger.error(
                f"event={self.regenerate_api_key.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while regenerating API key: {e}"
            self.logger.error(
                f"event={self.regenerate_api_key.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)
