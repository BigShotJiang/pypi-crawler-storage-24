"""
Palo Alto Networks Prisma AIRS API Management SDK

Provides both synchronous and asynchronous SDKs for the AIRS API.
"""

from airs_api_mgmt._version import __version__

# Shared models - available to all users
from .sdk import models


# High-level clients (if available)
try:
    from airs_api_mgmt.mgmt_client import MgmtClient
except ImportError:
    MgmtClient = None

try:
    from airs_api_mgmt.mgmt_client_async import MgmtClientAsync
except ImportError:
    MgmtClientAsync = None

# Exceptions
from airs_api_mgmt.exceptions import (
    MgmtSdkBaseError,
    MgmtSdkAPIError,
    MgmtSdkClientError,
    MgmtSdkServerError,
    MgmtSdkConfigurationError,
)

# For advanced users who want low-level SDK access
from . import sdk

__all__ = [
    "__version__",
    "models",
    "MgmtClient",
    "MgmtClientAsync",
    "MgmtSdkBaseError",
    "MgmtSdkAPIError",
    "MgmtSdkClientError",
    "MgmtSdkServerError",
    "MgmtSdkConfigurationError",
    "sdk",
]
