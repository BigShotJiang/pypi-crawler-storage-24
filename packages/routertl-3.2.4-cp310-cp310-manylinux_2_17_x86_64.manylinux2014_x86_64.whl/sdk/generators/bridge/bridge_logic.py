# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
bridge_logic.py — Bridge Body FSM Population Functions
======================================================

Logic Layer for the RTL Bridge Generator.  Each public function in this
module receives two bus-interface objects and returns the internal signals
and ``Always``/``Assign`` blocks that implement the protocol translation FSM.

Position in the compiler pipeline::

    Frontend (bus_interfaces)
        → Middle-end (hdl_ast)
            → **Logic Layer (this module)**
                → Backend (emitter_sv / emitter_vhdl)

Usage::

    from bus_interfaces import AXILiteInterface, AvalonMMInterface, InterfaceRole
    from bridge_logic import build_axilite_to_avalon

    axi = AXILiteInterface(data_width=32, addr_width=16)
    avl = AvalonMMInterface(data_width=32, addr_width=14,
                            role=InterfaceRole.MASTER)
    clk = Signal("clk", direction=Direction.INPUT)
    rst = Signal("rst_n", direction=Direction.INPUT)

    signals, blocks = build_axilite_to_avalon(axi, avl, clk, rst)
    for s in signals:
        module.add_signal(s)
    for b in blocks:
        module.add_block(b)
"""

from __future__ import annotations

import math
from enum import IntEnum
from typing import List, Tuple

from bridge_builder import BridgeBuilder
from bus_interfaces import AvalonMMInterface, AXILiteInterface
from hdl_ast import (
    Concat,
    HdlNode,
    If,
    NonBlockingAssign,
    ResetStyle,
    Signal,
    Slice,
)

BB = BridgeBuilder

# ---------------------------------------------------------------------------
# FSM state encoding
# ---------------------------------------------------------------------------


class BridgeState(IntEnum):
    """FSM states for the AXI-Lite → Avalon-MM bridge.

    Encoding uses a 3-bit one-hot-friendly enumeration.
    """

    IDLE = 0  # Waiting for AXI transaction
    WR_ACCEPT = 1  # Accept AW + W channels (awready=1, wready=1)
    WR_AVALON = 2  # Drive Avalon write, wait for !waitrequest
    WR_RESP = 3  # Present bvalid, wait for bready
    RD_ACCEPT = 4  # Accept AR channel (arready=1)
    RD_AVALON = 5  # Drive Avalon read, wait for !waitrequest
    RD_WAIT = 6  # Wait for readdatavalid
    RD_RESP = 7  # Present rvalid, wait for rready


_STATE_WIDTH = 3


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_axilite_to_avalon(
    axi: AXILiteInterface,
    avl: AvalonMMInterface,
    clk: Signal,
    rst: Signal,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build the FSM logic for an AXI-Lite slave → Avalon-MM master bridge.

    Parameters
    ----------
    axi:
        AXI-Lite interface (SLAVE role — signals as seen from the bridge).
    avl:
        Avalon-MM interface (MASTER role — signals as seen from the bridge).
    clk:
        Clock signal.
    rst:
        Reset signal.
    reset_style:
        Synchronous or asynchronous reset.
    active_low_reset:
        If True, reset is active when ``rst == '0'``.

    Returns
    -------
    internal_signals:
        State register + latching registers.  Caller should add them to the
        module via ``module.add_signal()``.
    body_nodes:
        ``Always`` blocks and combinational ``Assign`` nodes.  Caller
        should add them via ``module.add_block()``.
    """
    dw = axi.data_width
    aw = axi.addr_width
    sw = dw // 8
    byte_shift = int(math.log2(dw // 8))

    _, _axi = BB.resolve_signals(axi)
    _, _avl = BB.resolve_signals(avl)

    internal_signals, r = BB.create_registers([
        ("state", _STATE_WIDTH, BridgeState.IDLE),
        ("addr_reg", aw, 0), ("wdata_reg", dw, 0), ("wstrb_reg", sw, 0),
        ("rdata_reg", dw, 0), ("resp_reg", 2, 0),
    ])
    state_reg, addr_reg = r["state"], r["addr_reg"]
    wdata_reg, wstrb_reg = r["wdata_reg"], r["wstrb_reg"]
    rdata_reg, resp_reg = r["rdata_reg"], r["resp_reg"]

    reset_stmts = BB.build_reset_stmts(
        registers=[(s, s.reset_val) for s in internal_signals],
        output_signals=[
            _axi("awready"), _axi("wready"), _axi("bvalid"), _axi("bresp"),
            _axi("arready"), _axi("rvalid"), _axi("rdata"), _axi("rresp"),
            _avl("write"), _avl("read"), _avl("address"),
            _avl("writedata"), _avl("byteenable"),
        ],
    )

    addr_word_slice = Slice(addr_reg, aw - 1, byte_shift)

    idle_body: List[HdlNode] = BB.deassert_outputs([
        _axi("awready"), _axi("wready"), _axi("bvalid"),
        _axi("arready"), _axi("rvalid"), _avl("write"), _avl("read"),
    ]) + [
        If(
            f"{_axi('awvalid').name} & {_axi('wvalid').name}",
            then_body=[
                NonBlockingAssign(addr_reg, _axi("awaddr")),
                NonBlockingAssign(wdata_reg, _axi("wdata")),
                NonBlockingAssign(wstrb_reg, _axi("wstrb")),
                NonBlockingAssign(state_reg, BridgeState.WR_ACCEPT),
            ],
            else_body=[If(
                _axi("arvalid").name,
                then_body=[
                    NonBlockingAssign(addr_reg, _axi("araddr")),
                    NonBlockingAssign(state_reg, BridgeState.RD_ACCEPT),
                ],
            )],
        ),
    ]

    wr_accept_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awready"), 1), NonBlockingAssign(_axi("wready"), 1),
        NonBlockingAssign(_avl("write"), 1), NonBlockingAssign(_avl("address"), addr_word_slice),
        NonBlockingAssign(_avl("writedata"), wdata_reg), NonBlockingAssign(_avl("byteenable"), wstrb_reg),
        NonBlockingAssign(state_reg, BridgeState.WR_AVALON),
    ]

    wr_avalon_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awready"), 0), NonBlockingAssign(_axi("wready"), 0),
        NonBlockingAssign(_avl("write"), 1), NonBlockingAssign(_avl("address"), addr_word_slice),
        NonBlockingAssign(_avl("writedata"), wdata_reg), NonBlockingAssign(_avl("byteenable"), wstrb_reg),
        If(f"!{_avl('waitrequest').name}", then_body=[
            NonBlockingAssign(resp_reg, _avl("response")),
            NonBlockingAssign(_avl("write"), 0),
            NonBlockingAssign(state_reg, BridgeState.WR_RESP),
        ]),
    ]

    wr_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("bvalid"), 1), NonBlockingAssign(_axi("bresp"), resp_reg),
        NonBlockingAssign(_avl("write"), 0),
        If(_axi("bready").name, then_body=[NonBlockingAssign(state_reg, BridgeState.IDLE)]),
    ]

    rd_accept_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arready"), 1), NonBlockingAssign(_avl("read"), 1),
        NonBlockingAssign(_avl("address"), addr_word_slice),
        NonBlockingAssign(state_reg, BridgeState.RD_AVALON),
    ]

    rd_avalon_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arready"), 0), NonBlockingAssign(_avl("read"), 1),
        NonBlockingAssign(_avl("address"), addr_word_slice),
        If(f"!{_avl('waitrequest').name}", then_body=[
            NonBlockingAssign(_avl("read"), 0),
            NonBlockingAssign(state_reg, BridgeState.RD_WAIT),
        ]),
    ]

    rd_wait_body: List[HdlNode] = [
        NonBlockingAssign(_avl("read"), 0),
        If(_avl("readdatavalid").name, then_body=[
            NonBlockingAssign(rdata_reg, _avl("readdata")),
            NonBlockingAssign(resp_reg, _avl("response")),
            NonBlockingAssign(state_reg, BridgeState.RD_RESP),
        ]),
    ]

    rd_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("rvalid"), 1), NonBlockingAssign(_axi("rdata"), rdata_reg),
        NonBlockingAssign(_axi("rresp"), resp_reg),
        If(_axi("rready").name, then_body=[NonBlockingAssign(state_reg, BridgeState.IDLE)]),
    ]

    fsm_always = BB.build_fsm(state_reg, [
        (BridgeState.IDLE, idle_body), (BridgeState.WR_ACCEPT, wr_accept_body),
        (BridgeState.WR_AVALON, wr_avalon_body), (BridgeState.WR_RESP, wr_resp_body),
        (BridgeState.RD_ACCEPT, rd_accept_body), (BridgeState.RD_AVALON, rd_avalon_body),
        (BridgeState.RD_WAIT, rd_wait_body), (BridgeState.RD_RESP, rd_resp_body),
    ], BridgeState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]


# ---------------------------------------------------------------------------
# Reverse bridge: Avalon-MM → AXI-Lite
# ---------------------------------------------------------------------------


class ReverseBridgeState(IntEnum):
    """FSM states for the Avalon-MM → AXI-Lite bridge.

    The bridge sits as an Avalon-MM slave on one side and an AXI-Lite
    master on the other.  An Avalon-MM master issues read/write commands
    which the bridge translates into AXI-Lite transactions.
    """

    IDLE = 0
    AVL_LATCH = 1
    AXI_WR_ADDR = 2
    AXI_WR_DATA = 3
    AXI_WR_RESP = 4
    AXI_RD_ADDR = 5
    AXI_RD_RESP = 6
    AVL_RD_DONE = 7


_REV_STATE_WIDTH = 3


def build_avalon_to_axilite(
    avl: AvalonMMInterface,
    axi: AXILiteInterface,
    clk: Signal,
    rst: Signal,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build the FSM logic for an Avalon-MM slave → AXI-Lite master bridge.

    Parameters
    ----------
    avl:
        Avalon-MM interface (SLAVE role — receiving commands from
        an external Avalon-MM master).
    axi:
        AXI-Lite interface (MASTER role — issuing transactions to
        an external AXI-Lite slave).
    clk:
        Clock signal.
    rst:
        Reset signal.
    reset_style:
        Synchronous or asynchronous reset.
    active_low_reset:
        If True, reset is active when ``rst == '0'``.

    Returns
    -------
    internal_signals:
        State register + latching registers.
    body_nodes:
        ``Always`` blocks that implement the FSM.
    """
    dw = axi.data_width
    aw = axi.addr_width
    sw = dw // 8
    byte_shift = int(math.log2(dw // 8))

    _, _axi = BB.resolve_signals(axi)
    _, _avl = BB.resolve_signals(avl)

    internal_signals, r = BB.create_registers([
        ("state", _REV_STATE_WIDTH, ReverseBridgeState.IDLE),
        ("addr_reg", aw, 0), ("wdata_reg", dw, 0), ("wstrb_reg", sw, 0),
        ("rdata_reg", dw, 0), ("resp_reg", 2, 0), ("is_write_reg", 1, 0),
    ])
    state_reg, addr_reg = r["state"], r["addr_reg"]
    wdata_reg, wstrb_reg = r["wdata_reg"], r["wstrb_reg"]
    rdata_reg, resp_reg = r["rdata_reg"], r["resp_reg"]
    is_write_reg = r["is_write_reg"]

    reset_stmts = BB.build_reset_stmts_raw([
        (state_reg, ReverseBridgeState.IDLE),
        (addr_reg, 0), (wdata_reg, 0), (wstrb_reg, 0),
        (rdata_reg, 0), (resp_reg, 0), (is_write_reg, 0),
        (_axi("awvalid"), 0), (_axi("awaddr"), 0), (_axi("awprot"), 0),
        (_axi("wvalid"), 0), (_axi("wdata"), 0), (_axi("wstrb"), 0),
        (_axi("bready"), 0),
        (_axi("arvalid"), 0), (_axi("araddr"), 0), (_axi("arprot"), 0),
        (_axi("rready"), 0),
        (_avl("waitrequest"), 1),
        (_avl("readdata"), 0), (_avl("readdatavalid"), 0), (_avl("response"), 0),
    ])

    avl_addr_width = avl.addr_width
    zero_pad = "0" * byte_shift

    idle_body: List[HdlNode] = [
        NonBlockingAssign(_avl("waitrequest"), 1), NonBlockingAssign(_avl("readdatavalid"), 0),
    ] + BB.deassert_outputs([
        _axi("awvalid"), _axi("wvalid"), _axi("bready"), _axi("arvalid"), _axi("rready"),
    ]) + [
        If(
            _avl("write").name,
            then_body=[
                NonBlockingAssign(addr_reg, Concat(Slice(_avl("address"), avl_addr_width - 1, 0), zero_pad)),
                NonBlockingAssign(wdata_reg, _avl("writedata")),
                NonBlockingAssign(wstrb_reg, _avl("byteenable")),
                NonBlockingAssign(is_write_reg, 1),
                NonBlockingAssign(state_reg, ReverseBridgeState.AVL_LATCH),
            ],
            else_body=[If(
                _avl("read").name,
                then_body=[
                    NonBlockingAssign(addr_reg, Concat(Slice(_avl("address"), avl_addr_width - 1, 0), zero_pad)),
                    NonBlockingAssign(is_write_reg, 0),
                    NonBlockingAssign(state_reg, ReverseBridgeState.AVL_LATCH),
                ],
            )],
        ),
    ]

    avl_latch_body: List[HdlNode] = [
        NonBlockingAssign(_avl("waitrequest"), 0),
        If(is_write_reg.name,
           then_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_WR_ADDR)],
           else_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_RD_ADDR)]),
    ]

    axi_wr_addr_body: List[HdlNode] = [
        NonBlockingAssign(_avl("waitrequest"), 1),
        NonBlockingAssign(_axi("awvalid"), 1), NonBlockingAssign(_axi("awaddr"), addr_reg),
        NonBlockingAssign(_axi("awprot"), 0),
        If(_axi("awready").name, then_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_WR_DATA)]),
    ]

    axi_wr_data_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awvalid"), 0), NonBlockingAssign(_axi("wvalid"), 1),
        NonBlockingAssign(_axi("wdata"), wdata_reg), NonBlockingAssign(_axi("wstrb"), wstrb_reg),
        If(_axi("wready").name, then_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_WR_RESP)]),
    ]

    axi_wr_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("wvalid"), 0), NonBlockingAssign(_axi("bready"), 1),
        If(_axi("bvalid").name, then_body=[
            NonBlockingAssign(resp_reg, _axi("bresp")),
            NonBlockingAssign(_avl("response"), _axi("bresp")),
            NonBlockingAssign(state_reg, ReverseBridgeState.IDLE),
        ]),
    ]

    axi_rd_addr_body: List[HdlNode] = [
        NonBlockingAssign(_avl("waitrequest"), 1),
        NonBlockingAssign(_axi("arvalid"), 1), NonBlockingAssign(_axi("araddr"), addr_reg),
        NonBlockingAssign(_axi("arprot"), 0),
        If(_axi("arready").name, then_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_RD_RESP)]),
    ]

    axi_rd_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arvalid"), 0), NonBlockingAssign(_axi("rready"), 1),
        If(_axi("rvalid").name, then_body=[
            NonBlockingAssign(rdata_reg, _axi("rdata")),
            NonBlockingAssign(resp_reg, _axi("rresp")),
            NonBlockingAssign(state_reg, ReverseBridgeState.AVL_RD_DONE),
        ]),
    ]

    avl_rd_done_body: List[HdlNode] = [
        NonBlockingAssign(_avl("readdatavalid"), 1), NonBlockingAssign(_avl("readdata"), rdata_reg),
        NonBlockingAssign(_avl("response"), resp_reg),
        NonBlockingAssign(state_reg, ReverseBridgeState.IDLE),
    ]

    fsm_always = BB.build_fsm(state_reg, [
        (ReverseBridgeState.IDLE, idle_body), (ReverseBridgeState.AVL_LATCH, avl_latch_body),
        (ReverseBridgeState.AXI_WR_ADDR, axi_wr_addr_body),
        (ReverseBridgeState.AXI_WR_DATA, axi_wr_data_body),
        (ReverseBridgeState.AXI_WR_RESP, axi_wr_resp_body),
        (ReverseBridgeState.AXI_RD_ADDR, axi_rd_addr_body),
        (ReverseBridgeState.AXI_RD_RESP, axi_rd_resp_body),
        (ReverseBridgeState.AVL_RD_DONE, avl_rd_done_body),
    ], ReverseBridgeState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]


# ---------------------------------------------------------------------------
# AXI4 → Native Memory Bridge
# ---------------------------------------------------------------------------


class Axi4NativeState(IntEnum):
    """FSM states for the AXI4 → Native Memory bridge."""

    IDLE = 0
    WR_ACCEPT = 1
    WR_DATA = 2
    WR_RESP = 3
    RD_ACCEPT = 4
    RD_CMD = 5
    RD_WAIT = 6
    RD_RESP = 7


_AXI4_NATIVE_STATE_WIDTH = 3


def build_axi4_to_native(
    axi: "AXI4Interface",
    mem: "NativeMemInterface",
    clk: Signal,
    rst: Signal,
    read_latency: int = 1,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build an AXI4-to-native-memory bridge module AST."""
    dw = axi.data_width
    aw = axi.addr_width
    iw = axi.id_width
    byte_shift = int(math.log2(dw // 8))

    _, _axi = BB.resolve_signals(axi)
    _, _mem = BB.resolve_signals(mem)

    internal_signals, r = BB.create_registers([
        ("state", _AXI4_NATIVE_STATE_WIDTH, Axi4NativeState.IDLE),
        ("addr_reg", aw, 0), ("beat_reg", 8, 0), ("id_reg", iw, 0), ("lat_reg", 8, 0),
    ])
    state_reg, addr_reg = r["state"], r["addr_reg"]
    beat_reg, id_reg, lat_reg = r["beat_reg"], r["id_reg"], r["lat_reg"]

    reset_stmts = BB.build_reset_stmts(
        registers=[(s, s.reset_val) for s in internal_signals],
        output_signals=[
            _axi("awready"), _axi("wready"), _axi("bvalid"), _axi("bresp"),
            _axi("bid"), _axi("arready"), _axi("rvalid"), _axi("rresp"),
            _axi("rid"), _axi("rlast"), _axi("rdata"),
            _mem("we"), _mem("re"), _mem("cs"), _mem("addr"), _mem("din"),
        ],
    )

    addr_word_slice = Slice(addr_reg, aw - 1, byte_shift)

    idle_body: List[HdlNode] = BB.deassert_outputs([
        _axi("awready"), _axi("wready"), _axi("bvalid"),
        _axi("arready"), _axi("rvalid"), _mem("we"), _mem("re"), _mem("cs"),
    ]) + [
        If(_axi("awvalid").name, then_body=[
            NonBlockingAssign(addr_reg, _axi("awaddr")), NonBlockingAssign(beat_reg, _axi("awlen")),
            NonBlockingAssign(id_reg, _axi("awid")),
            NonBlockingAssign(state_reg, Axi4NativeState.WR_ACCEPT),
        ], else_body=[If(_axi("arvalid").name, then_body=[
            NonBlockingAssign(addr_reg, _axi("araddr")), NonBlockingAssign(beat_reg, _axi("arlen")),
            NonBlockingAssign(id_reg, _axi("arid")),
            NonBlockingAssign(state_reg, Axi4NativeState.RD_ACCEPT),
        ])]),
    ]

    wr_accept_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awready"), 1), NonBlockingAssign(state_reg, Axi4NativeState.WR_DATA),
    ]

    wr_data_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awready"), 0), NonBlockingAssign(_axi("wready"), 1),
        NonBlockingAssign(_mem("we"), 0), NonBlockingAssign(_mem("cs"), 0),
        If(f"{_axi('wvalid').name} & {_axi('wready').name}", then_body=[
            NonBlockingAssign(_mem("we"), _axi("wstrb")), NonBlockingAssign(_mem("cs"), 1),
            NonBlockingAssign(_mem("addr"), addr_word_slice), NonBlockingAssign(_mem("din"), _axi("wdata")),
            NonBlockingAssign(addr_reg, f"{addr_reg.name} + {(dw // 8)}"),
            If(_axi("wlast").name, then_body=[
                NonBlockingAssign(_axi("wready"), 0),
                NonBlockingAssign(state_reg, Axi4NativeState.WR_RESP),
            ], else_body=[NonBlockingAssign(beat_reg, f"{beat_reg.name} - 1")]),
        ]),
    ]

    wr_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("wready"), 0), NonBlockingAssign(_mem("we"), 0),
        NonBlockingAssign(_mem("cs"), 0), NonBlockingAssign(_axi("bvalid"), 1),
        NonBlockingAssign(_axi("bresp"), 0), NonBlockingAssign(_axi("bid"), id_reg),
        If(_axi("bready").name, then_body=[NonBlockingAssign(state_reg, Axi4NativeState.IDLE)]),
    ]

    rd_accept_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arready"), 1), NonBlockingAssign(state_reg, Axi4NativeState.RD_CMD),
    ]

    rd_cmd_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arready"), 0), NonBlockingAssign(_axi("rvalid"), 0),
        NonBlockingAssign(_axi("rlast"), 0),
        NonBlockingAssign(_mem("re"), 1), NonBlockingAssign(_mem("cs"), 1),
        NonBlockingAssign(_mem("addr"), addr_word_slice), NonBlockingAssign(lat_reg, read_latency),
        NonBlockingAssign(state_reg, Axi4NativeState.RD_WAIT),
    ]

    rd_wait_body: List[HdlNode] = [
        NonBlockingAssign(_mem("re"), 0), NonBlockingAssign(_mem("cs"), 0),
        NonBlockingAssign(_axi("rvalid"), 0), NonBlockingAssign(_axi("rlast"), 0),
        If(f"{lat_reg.name} == 0",
           then_body=[NonBlockingAssign(state_reg, Axi4NativeState.RD_RESP)],
           else_body=[NonBlockingAssign(lat_reg, f"{lat_reg.name} - 1")]),
    ]

    r_last_cond = f"({beat_reg.name} == 0)"
    rd_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("rvalid"), 1), NonBlockingAssign(_axi("rresp"), 0),
        NonBlockingAssign(_axi("rid"), id_reg), NonBlockingAssign(_axi("rdata"), _mem("dout")),
        NonBlockingAssign(_axi("rlast"), r_last_cond),
        If(_axi("rready").name, then_body=[
            If(r_last_cond,
               then_body=[NonBlockingAssign(state_reg, Axi4NativeState.IDLE)],
               else_body=[
                   NonBlockingAssign(addr_reg, f"{addr_reg.name} + {(dw // 8)}"),
                   NonBlockingAssign(beat_reg, f"{beat_reg.name} - 1"),
                   NonBlockingAssign(state_reg, Axi4NativeState.RD_CMD),
               ])
        ]),
    ]

    fsm_always = BB.build_fsm(state_reg, [
        (Axi4NativeState.IDLE, idle_body), (Axi4NativeState.WR_ACCEPT, wr_accept_body),
        (Axi4NativeState.WR_DATA, wr_data_body), (Axi4NativeState.WR_RESP, wr_resp_body),
        (Axi4NativeState.RD_ACCEPT, rd_accept_body), (Axi4NativeState.RD_CMD, rd_cmd_body),
        (Axi4NativeState.RD_WAIT, rd_wait_body), (Axi4NativeState.RD_RESP, rd_resp_body),
    ], Axi4NativeState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]


# ---------------------------------------------------------------------------
# AXI4 → Avalon-MM Bridge
# ---------------------------------------------------------------------------


class Axi4AvalonState(IntEnum):
    """FSM states for the AXI4 → Avalon-MM bridge."""

    IDLE = 0
    WR_ACCEPT = 1
    WR_DATA = 2
    WR_AVALON = 3
    WR_RESP = 4
    RD_ACCEPT = 5
    RD_AVALON = 6
    RD_WAIT = 7
    RD_RESP = 8


_AXI4_AVALON_STATE_WIDTH = 4


def build_axi4_to_avalon(
    axi: "AXI4Interface",
    avl: "AvalonMMInterface",
    clk: Signal,
    rst: Signal,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build an AXI4-to-Avalon-MM bridge module AST."""
    dw = axi.data_width
    aw = axi.addr_width
    iw = axi.id_width
    byte_shift = int(math.log2(dw // 8))

    _, _axi = BB.resolve_signals(axi)
    _, _avl = BB.resolve_signals(avl)

    internal_signals, r = BB.create_registers([
        ("state", _AXI4_AVALON_STATE_WIDTH, Axi4AvalonState.IDLE),
        ("addr_reg", aw, 0), ("beat_reg", 8, 0), ("id_reg", iw, 0),
        ("wdata_reg", dw, 0), ("wstrb_reg", dw // 8, 0),
        ("rdata_reg", dw, 0), ("resp_reg", 2, 0), ("last_reg", 1, 0),
    ])
    state_reg, addr_reg = r["state"], r["addr_reg"]
    beat_reg, id_reg = r["beat_reg"], r["id_reg"]
    wdata_reg, wstrb_reg = r["wdata_reg"], r["wstrb_reg"]
    rdata_reg, resp_reg = r["rdata_reg"], r["resp_reg"]
    last_reg = r["last_reg"]

    reset_stmts = BB.build_reset_stmts(
        registers=[(s, s.reset_val) for s in internal_signals],
        output_signals=[
            _axi("awready"), _axi("wready"), _axi("bvalid"), _axi("bresp"),
            _axi("bid"), _axi("arready"), _axi("rvalid"), _axi("rresp"),
            _axi("rid"), _axi("rlast"), _axi("rdata"),
            _avl("write"), _avl("read"), _avl("address"),
            _avl("writedata"), _avl("byteenable"),
        ],
    )

    addr_word_slice = Slice(addr_reg, aw - 1, byte_shift)

    idle_body: List[HdlNode] = BB.deassert_outputs([
        _axi("awready"), _axi("wready"), _axi("bvalid"),
        _axi("arready"), _axi("rvalid"), _avl("write"), _avl("read"),
    ]) + [
        If(_axi("awvalid").name, then_body=[
            NonBlockingAssign(addr_reg, _axi("awaddr")), NonBlockingAssign(beat_reg, _axi("awlen")),
            NonBlockingAssign(id_reg, _axi("awid")),
            NonBlockingAssign(state_reg, Axi4AvalonState.WR_ACCEPT),
        ], else_body=[If(_axi("arvalid").name, then_body=[
            NonBlockingAssign(addr_reg, _axi("araddr")), NonBlockingAssign(beat_reg, _axi("arlen")),
            NonBlockingAssign(id_reg, _axi("arid")),
            NonBlockingAssign(state_reg, Axi4AvalonState.RD_ACCEPT),
        ])]),
    ]

    wr_accept_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awready"), 1), NonBlockingAssign(state_reg, Axi4AvalonState.WR_DATA),
    ]

    wr_data_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awready"), 0), NonBlockingAssign(_axi("wready"), 1),
        If(f"{_axi('wvalid').name} & {_axi('wready').name}", then_body=[
            NonBlockingAssign(wdata_reg, _axi("wdata")), NonBlockingAssign(wstrb_reg, _axi("wstrb")),
            NonBlockingAssign(last_reg, _axi("wlast")), NonBlockingAssign(_axi("wready"), 0),
            NonBlockingAssign(_avl("write"), 1), NonBlockingAssign(_avl("address"), addr_word_slice),
            NonBlockingAssign(_avl("writedata"), _axi("wdata")),
            NonBlockingAssign(_avl("byteenable"), _axi("wstrb")),
            NonBlockingAssign(state_reg, Axi4AvalonState.WR_AVALON),
        ]),
    ]

    wr_avalon_body: List[HdlNode] = [
        If(f"!{_avl('waitrequest').name}", then_body=[
            NonBlockingAssign(_avl("write"), 0),
            NonBlockingAssign(addr_reg, f"{addr_reg.name} + {(dw // 8)}"),
            If(last_reg.name,
               then_body=[NonBlockingAssign(state_reg, Axi4AvalonState.WR_RESP)],
               else_body=[
                   NonBlockingAssign(beat_reg, f"{beat_reg.name} - 1"),
                   NonBlockingAssign(state_reg, Axi4AvalonState.WR_DATA),
               ]),
        ], else_body=[NonBlockingAssign(_avl("write"), 1)]),
    ]

    wr_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("bvalid"), 1), NonBlockingAssign(_axi("bresp"), 0),
        NonBlockingAssign(_axi("bid"), id_reg),
        If(_axi("bready").name, then_body=[NonBlockingAssign(state_reg, Axi4AvalonState.IDLE)]),
    ]

    rd_accept_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arready"), 1), NonBlockingAssign(_avl("read"), 1),
        NonBlockingAssign(_avl("address"), addr_word_slice),
        NonBlockingAssign(state_reg, Axi4AvalonState.RD_AVALON),
    ]

    rd_avalon_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arready"), 0), NonBlockingAssign(_axi("rvalid"), 0),
        NonBlockingAssign(_axi("rlast"), 0),
        If(f"!{_avl('waitrequest').name}", then_body=[
            NonBlockingAssign(_avl("read"), 0),
            NonBlockingAssign(state_reg, Axi4AvalonState.RD_WAIT),
        ], else_body=[NonBlockingAssign(_avl("read"), 1)]),
    ]

    rd_wait_body: List[HdlNode] = [
        NonBlockingAssign(_axi("rvalid"), 0), NonBlockingAssign(_axi("rlast"), 0),
        If(_avl("readdatavalid").name, then_body=[
            NonBlockingAssign(addr_reg, f"{addr_reg.name} + {(dw // 8)}"),
            NonBlockingAssign(rdata_reg, _avl("readdata")),
            NonBlockingAssign(resp_reg, _avl("response")),
            NonBlockingAssign(state_reg, Axi4AvalonState.RD_RESP),
        ]),
    ]

    r_last_cond = f"({beat_reg.name} == 0)"
    rd_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("rvalid"), 1), NonBlockingAssign(_axi("rresp"), resp_reg),
        NonBlockingAssign(_axi("rid"), id_reg), NonBlockingAssign(_axi("rdata"), rdata_reg),
        NonBlockingAssign(_axi("rlast"), r_last_cond),
        If(_axi("rready").name, then_body=[
            If(r_last_cond,
               then_body=[NonBlockingAssign(state_reg, Axi4AvalonState.IDLE)],
               else_body=[
                   NonBlockingAssign(_avl("read"), 1), NonBlockingAssign(_avl("address"), addr_word_slice),
                   NonBlockingAssign(beat_reg, f"{beat_reg.name} - 1"),
                   NonBlockingAssign(state_reg, Axi4AvalonState.RD_AVALON),
               ])
        ]),
    ]

    fsm_always = BB.build_fsm(state_reg, [
        (Axi4AvalonState.IDLE, idle_body), (Axi4AvalonState.WR_ACCEPT, wr_accept_body),
        (Axi4AvalonState.WR_DATA, wr_data_body), (Axi4AvalonState.WR_AVALON, wr_avalon_body),
        (Axi4AvalonState.WR_RESP, wr_resp_body), (Axi4AvalonState.RD_ACCEPT, rd_accept_body),
        (Axi4AvalonState.RD_AVALON, rd_avalon_body), (Axi4AvalonState.RD_WAIT, rd_wait_body),
        (Axi4AvalonState.RD_RESP, rd_resp_body),
    ], Axi4AvalonState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]


def build_avalon_to_axi4(
    avl: "AvalonMMInterface",
    axi: "AXI4Interface",
    clk: Signal,
    rst: Signal,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build an Avalon-MM-to-AXI4 bridge module AST."""
    dw = axi.data_width
    aw = axi.addr_width
    iw = axi.id_width
    sw = dw // 8
    byte_shift = int(math.log2(sw))

    _, _axi = BB.resolve_signals(axi)
    _, _avl = BB.resolve_signals(avl)

    internal_signals, r = BB.create_registers([
        ("state", _REV_STATE_WIDTH, ReverseBridgeState.IDLE),
        ("addr_reg", aw, 0), ("wdata_reg", dw, 0), ("wstrb_reg", sw, 0),
        ("rdata_reg", dw, 0), ("resp_reg", 2, 0), ("is_write_reg", 1, 0),
    ])
    state_reg, addr_reg = r["state"], r["addr_reg"]
    wdata_reg, wstrb_reg = r["wdata_reg"], r["wstrb_reg"]
    rdata_reg, resp_reg = r["rdata_reg"], r["resp_reg"]
    is_write_reg = r["is_write_reg"]

    reset_stmts = BB.build_reset_stmts_raw([
        (state_reg, ReverseBridgeState.IDLE),
        (addr_reg, 0), (wdata_reg, 0), (wstrb_reg, 0),
        (rdata_reg, 0), (resp_reg, 0), (is_write_reg, 0),
        (_axi("awvalid"), 0), (_axi("awaddr"), 0),
        (_axi("awid"), 0), (_axi("awlen"), 0),
        (_axi("awsize"), 0), (_axi("awburst"), 0),
        (_axi("awprot"), 0), (_axi("awcache"), 0), (_axi("awqos"), 0),
        (_axi("wvalid"), 0), (_axi("wdata"), 0),
        (_axi("wstrb"), 0), (_axi("wlast"), 0),
        (_axi("bready"), 0),
        (_axi("arvalid"), 0), (_axi("araddr"), 0),
        (_axi("arid"), 0), (_axi("arlen"), 0),
        (_axi("arsize"), 0), (_axi("arburst"), 0),
        (_axi("arprot"), 0), (_axi("arcache"), 0), (_axi("arqos"), 0),
        (_axi("rready"), 0),
        (_avl("waitrequest"), 1),
        (_avl("readdata"), 0), (_avl("readdatavalid"), 0), (_avl("response"), 0),
    ])

    avl_addr_width = avl.addr_width
    zero_pad = "0" * byte_shift

    idle_body: List[HdlNode] = [
        NonBlockingAssign(_avl("waitrequest"), 1), NonBlockingAssign(_avl("readdatavalid"), 0),
    ] + BB.deassert_outputs([
        _axi("awvalid"), _axi("wvalid"), _axi("bready"), _axi("arvalid"), _axi("rready"),
    ]) + [
        If(_avl("write").name, then_body=[
            NonBlockingAssign(addr_reg, Concat(Slice(_avl("address"), avl_addr_width - 1, 0), zero_pad)),
            NonBlockingAssign(wdata_reg, _avl("writedata")),
            NonBlockingAssign(wstrb_reg, _avl("byteenable")),
            NonBlockingAssign(is_write_reg, 1),
            NonBlockingAssign(state_reg, ReverseBridgeState.AVL_LATCH),
        ], else_body=[If(_avl("read").name, then_body=[
            NonBlockingAssign(addr_reg, Concat(Slice(_avl("address"), avl_addr_width - 1, 0), zero_pad)),
            NonBlockingAssign(is_write_reg, 0),
            NonBlockingAssign(state_reg, ReverseBridgeState.AVL_LATCH),
        ])]),
    ]

    avl_latch_body: List[HdlNode] = [
        NonBlockingAssign(_avl("waitrequest"), 0),
        If(is_write_reg.name,
           then_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_WR_ADDR)],
           else_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_RD_ADDR)]),
    ]

    axi_wr_addr_body: List[HdlNode] = [
        NonBlockingAssign(_avl("waitrequest"), 1),
        NonBlockingAssign(_axi("awvalid"), 1), NonBlockingAssign(_axi("awaddr"), addr_reg),
        NonBlockingAssign(_axi("awid"), 0), NonBlockingAssign(_axi("awlen"), 0),
        NonBlockingAssign(_axi("awsize"), byte_shift), NonBlockingAssign(_axi("awburst"), 1),
        NonBlockingAssign(_axi("awprot"), 0), NonBlockingAssign(_axi("awcache"), 0),
        NonBlockingAssign(_axi("awqos"), 0),
        If(_axi("awready").name, then_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_WR_DATA)]),
    ]

    axi_wr_data_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awvalid"), 0), NonBlockingAssign(_axi("wvalid"), 1),
        NonBlockingAssign(_axi("wdata"), wdata_reg), NonBlockingAssign(_axi("wstrb"), wstrb_reg),
        NonBlockingAssign(_axi("wlast"), 1),
        If(_axi("wready").name, then_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_WR_RESP)]),
    ]

    axi_wr_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("wvalid"), 0), NonBlockingAssign(_axi("wlast"), 0),
        NonBlockingAssign(_axi("bready"), 1),
        If(_axi("bvalid").name, then_body=[
            NonBlockingAssign(resp_reg, _axi("bresp")),
            NonBlockingAssign(_avl("response"), _axi("bresp")),
            NonBlockingAssign(state_reg, ReverseBridgeState.IDLE),
        ]),
    ]

    axi_rd_addr_body: List[HdlNode] = [
        NonBlockingAssign(_avl("waitrequest"), 1),
        NonBlockingAssign(_axi("arvalid"), 1), NonBlockingAssign(_axi("araddr"), addr_reg),
        NonBlockingAssign(_axi("arid"), 0), NonBlockingAssign(_axi("arlen"), 0),
        NonBlockingAssign(_axi("arsize"), byte_shift), NonBlockingAssign(_axi("arburst"), 1),
        NonBlockingAssign(_axi("arprot"), 0), NonBlockingAssign(_axi("arcache"), 0),
        NonBlockingAssign(_axi("arqos"), 0),
        If(_axi("arready").name, then_body=[NonBlockingAssign(state_reg, ReverseBridgeState.AXI_RD_RESP)]),
    ]

    axi_rd_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arvalid"), 0), NonBlockingAssign(_axi("rready"), 1),
        If(_axi("rvalid").name, then_body=[
            NonBlockingAssign(rdata_reg, _axi("rdata")),
            NonBlockingAssign(resp_reg, _axi("rresp")),
            NonBlockingAssign(state_reg, ReverseBridgeState.AVL_RD_DONE),
        ]),
    ]

    avl_rd_done_body: List[HdlNode] = [
        NonBlockingAssign(_axi("rready"), 0),
        NonBlockingAssign(_avl("readdatavalid"), 1), NonBlockingAssign(_avl("readdata"), rdata_reg),
        NonBlockingAssign(_avl("response"), resp_reg),
        NonBlockingAssign(state_reg, ReverseBridgeState.IDLE),
    ]

    fsm_always = BB.build_fsm(state_reg, [
        (ReverseBridgeState.IDLE, idle_body), (ReverseBridgeState.AVL_LATCH, avl_latch_body),
        (ReverseBridgeState.AXI_WR_ADDR, axi_wr_addr_body),
        (ReverseBridgeState.AXI_WR_DATA, axi_wr_data_body),
        (ReverseBridgeState.AXI_WR_RESP, axi_wr_resp_body),
        (ReverseBridgeState.AXI_RD_ADDR, axi_rd_addr_body),
        (ReverseBridgeState.AXI_RD_RESP, axi_rd_resp_body),
        (ReverseBridgeState.AVL_RD_DONE, avl_rd_done_body),
    ], ReverseBridgeState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]


# ---------------------------------------------------------------------------
# AXI-Lite → Native Memory Bridge
# ---------------------------------------------------------------------------


class AxiLiteNativeState(IntEnum):
    """FSM states for the AXI-Lite → Native Memory bridge."""

    IDLE = 0
    WR_ACCEPT = 1
    WR_DATA = 2
    WR_RESP = 3
    RD_ACCEPT = 4
    RD_WAIT = 5
    RD_RESP = 6


_AXILITE_NATIVE_STATE_WIDTH = 3


def build_axilite_to_native(
    axi: AXILiteInterface,
    mem: "NativeMemInterface",
    clk: Signal,
    rst: Signal,
    read_latency: int = 1,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build an AXI-Lite-to-native-memory bridge module AST.

    Single-beat only (no burst support). Uses a fixed read_latency
    counter for SRAM compatibility, consistent with build_axi4_to_native.
    """
    dw = axi.data_width
    aw = axi.addr_width
    byte_shift = int(math.log2(dw // 8))

    _, _axi = BB.resolve_signals(axi)
    _, _mem = BB.resolve_signals(mem)

    internal_signals, r = BB.create_registers([
        ("state", _AXILITE_NATIVE_STATE_WIDTH, AxiLiteNativeState.IDLE),
        ("addr_reg", aw, 0), ("lat_reg", 8, 0),
    ])
    state_reg, addr_reg, lat_reg = r["state"], r["addr_reg"], r["lat_reg"]

    addr_word_slice = Slice(addr_reg, aw - 1, byte_shift)

    reset_stmts = BB.build_reset_stmts(
        registers=[(s, s.reset_val) for s in internal_signals],
        output_signals=[
            _axi("awready"), _axi("wready"), _axi("bvalid"), _axi("bresp"),
            _axi("arready"), _axi("rvalid"), _axi("rresp"), _axi("rdata"),
            _mem("we"), _mem("re"), _mem("cs"), _mem("addr"), _mem("din"),
        ],
    )

    idle_body: List[HdlNode] = BB.deassert_outputs([
        _axi("awready"), _axi("wready"), _axi("bvalid"),
        _axi("arready"), _axi("rvalid"), _mem("we"), _mem("re"), _mem("cs"),
    ]) + [
        If(_axi("awvalid").name, then_body=[
            NonBlockingAssign(addr_reg, _axi("awaddr")),
            NonBlockingAssign(state_reg, AxiLiteNativeState.WR_ACCEPT),
        ], else_body=[If(_axi("arvalid").name, then_body=[
            NonBlockingAssign(addr_reg, _axi("araddr")),
            NonBlockingAssign(state_reg, AxiLiteNativeState.RD_ACCEPT),
        ])]),
    ]

    wr_accept_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awready"), 1),
        NonBlockingAssign(state_reg, AxiLiteNativeState.WR_DATA),
    ]

    wr_data_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awready"), 0), NonBlockingAssign(_axi("wready"), 1),
        NonBlockingAssign(_mem("we"), 0), NonBlockingAssign(_mem("cs"), 0),
        If(f"{_axi('wvalid').name} & {_axi('wready').name}", then_body=[
            NonBlockingAssign(_mem("we"), _axi("wstrb")), NonBlockingAssign(_mem("cs"), 1),
            NonBlockingAssign(_mem("addr"), addr_word_slice), NonBlockingAssign(_mem("din"), _axi("wdata")),
            NonBlockingAssign(_axi("wready"), 0),
            NonBlockingAssign(state_reg, AxiLiteNativeState.WR_RESP),
        ]),
    ]

    wr_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("wready"), 0), NonBlockingAssign(_mem("we"), 0),
        NonBlockingAssign(_mem("cs"), 0), NonBlockingAssign(_axi("bvalid"), 1),
        NonBlockingAssign(_axi("bresp"), 0),
        If(_axi("bready").name, then_body=[NonBlockingAssign(state_reg, AxiLiteNativeState.IDLE)]),
    ]

    rd_accept_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arready"), 1),
        NonBlockingAssign(_mem("re"), 1), NonBlockingAssign(_mem("cs"), 1),
        NonBlockingAssign(_mem("addr"), addr_word_slice), NonBlockingAssign(lat_reg, read_latency),
        NonBlockingAssign(state_reg, AxiLiteNativeState.RD_WAIT),
    ]

    rd_wait_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arready"), 0),
        NonBlockingAssign(_mem("re"), 0), NonBlockingAssign(_mem("cs"), 0),
        NonBlockingAssign(_axi("rvalid"), 0),
        If(f"{lat_reg.name} == 0",
           then_body=[NonBlockingAssign(state_reg, AxiLiteNativeState.RD_RESP)],
           else_body=[NonBlockingAssign(lat_reg, f"{lat_reg.name} - 1")]),
    ]

    rd_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("rvalid"), 1), NonBlockingAssign(_axi("rresp"), 0),
        NonBlockingAssign(_axi("rdata"), _mem("dout")),
        If(_axi("rready").name, then_body=[NonBlockingAssign(state_reg, AxiLiteNativeState.IDLE)]),
    ]

    fsm_always = BB.build_fsm(state_reg, [
        (AxiLiteNativeState.IDLE, idle_body), (AxiLiteNativeState.WR_ACCEPT, wr_accept_body),
        (AxiLiteNativeState.WR_DATA, wr_data_body), (AxiLiteNativeState.WR_RESP, wr_resp_body),
        (AxiLiteNativeState.RD_ACCEPT, rd_accept_body), (AxiLiteNativeState.RD_WAIT, rd_wait_body),
        (AxiLiteNativeState.RD_RESP, rd_resp_body),
    ], AxiLiteNativeState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]


# ---------------------------------------------------------------------------
# Native Memory → Avalon-MM Bridge
# ---------------------------------------------------------------------------


class NativeAvalonState(IntEnum):
    """FSM states for the Native Memory → Avalon-MM bridge."""

    IDLE = 0
    WR_AVALON = 1
    WR_DONE = 2
    RD_AVALON = 3
    RD_WAIT = 4
    RD_DONE = 5


_NATIVE_AVALON_STATE_WIDTH = 3


def build_native_to_avalon(
    mem: "NativeMemInterface",
    avl: "AvalonMMInterface",
    clk: Signal,
    rst: Signal,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build a Native-Memory-to-Avalon-MM bridge module AST.

    The bridge accepts SRAM-style transactions (cs/we/re) on the native
    slave side and translates them into Avalon-MM master transactions
    with waitrequest backpressure handling.

    Parameters
    ----------
    mem:
        Native memory interface (SLAVE role — receiving cs/we/re/addr/din
        from the upstream fabric or register file controller).
    avl:
        Avalon-MM interface (MASTER role — issuing read/write to the
        downstream Avalon-MM interconnect).
    clk:
        Clock signal.
    rst:
        Reset signal.
    reset_style:
        Synchronous or asynchronous reset.
    active_low_reset:
        If True, reset is active when rst=0 (``!rst_n``).
    """
    dw = mem.data_width
    aw = mem.addr_width
    sw = dw // 8

    _, _mem = BB.resolve_signals(mem)
    _, _avl = BB.resolve_signals(avl)

    internal_signals, r = BB.create_registers([
        ("state", _NATIVE_AVALON_STATE_WIDTH, NativeAvalonState.IDLE),
        ("addr_reg", aw, 0), ("wdata_reg", dw, 0), ("wstrb_reg", sw, 0), ("rdata_reg", dw, 0),
    ])
    state_reg, addr_reg = r["state"], r["addr_reg"]
    wdata_reg, wstrb_reg, rdata_reg = r["wdata_reg"], r["wstrb_reg"], r["rdata_reg"]

    reset_stmts = BB.build_reset_stmts(
        registers=[(s, s.reset_val) for s in internal_signals],
        output_signals=[
            _mem("dout"), _mem("ack"),
            _avl("write"), _avl("read"), _avl("address"),
            _avl("writedata"), _avl("byteenable"),
        ],
    )

    idle_body: List[HdlNode] = BB.deassert_outputs([
        _mem("ack"), _mem("dout"), _avl("write"), _avl("read"),
    ]) + [
        If(_mem("cs").name, then_body=[
            NonBlockingAssign(addr_reg, _mem("addr")),
            If(_mem("we").name, then_body=[
                NonBlockingAssign(wdata_reg, _mem("din")),
                NonBlockingAssign(wstrb_reg, _mem("we")),
                NonBlockingAssign(_avl("write"), 1), NonBlockingAssign(_avl("address"), _mem("addr")),
                NonBlockingAssign(_avl("writedata"), _mem("din")),
                NonBlockingAssign(_avl("byteenable"), _mem("we")),
                NonBlockingAssign(state_reg, NativeAvalonState.WR_AVALON),
            ], else_body=[If(_mem("re").name, then_body=[
                NonBlockingAssign(_avl("read"), 1), NonBlockingAssign(_avl("address"), _mem("addr")),
                NonBlockingAssign(_avl("byteenable"), (1 << sw) - 1),
                NonBlockingAssign(state_reg, NativeAvalonState.RD_AVALON),
            ])]),
        ]),
    ]

    wr_avalon_body: List[HdlNode] = [
        If(f"!{_avl('waitrequest').name}", then_body=[
            NonBlockingAssign(_avl("write"), 0),
            NonBlockingAssign(state_reg, NativeAvalonState.WR_DONE),
        ], else_body=[
            NonBlockingAssign(_avl("write"), 1), NonBlockingAssign(_avl("address"), addr_reg),
            NonBlockingAssign(_avl("writedata"), wdata_reg),
            NonBlockingAssign(_avl("byteenable"), wstrb_reg),
        ]),
    ]

    wr_done_body: List[HdlNode] = [
        NonBlockingAssign(_mem("ack"), 1), NonBlockingAssign(state_reg, NativeAvalonState.IDLE),
    ]

    rd_avalon_body: List[HdlNode] = [
        If(f"!{_avl('waitrequest').name}", then_body=[
            NonBlockingAssign(_avl("read"), 0),
            NonBlockingAssign(state_reg, NativeAvalonState.RD_WAIT),
        ], else_body=[
            NonBlockingAssign(_avl("read"), 1), NonBlockingAssign(_avl("address"), addr_reg),
        ]),
    ]

    rd_wait_body: List[HdlNode] = [
        If(_avl("readdatavalid").name, then_body=[
            NonBlockingAssign(rdata_reg, _avl("readdata")),
            NonBlockingAssign(state_reg, NativeAvalonState.RD_DONE),
        ]),
    ]

    rd_done_body: List[HdlNode] = [
        NonBlockingAssign(_mem("dout"), rdata_reg), NonBlockingAssign(_mem("ack"), 1),
        NonBlockingAssign(state_reg, NativeAvalonState.IDLE),
    ]

    fsm_always = BB.build_fsm(state_reg, [
        (NativeAvalonState.IDLE, idle_body), (NativeAvalonState.WR_AVALON, wr_avalon_body),
        (NativeAvalonState.WR_DONE, wr_done_body), (NativeAvalonState.RD_AVALON, rd_avalon_body),
        (NativeAvalonState.RD_WAIT, rd_wait_body), (NativeAvalonState.RD_DONE, rd_done_body),
    ], NativeAvalonState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]


# ---------------------------------------------------------------------------
# Native Memory → AXI-Lite Bridge
# ---------------------------------------------------------------------------


class NativeAxiLiteState(IntEnum):
    """FSM states for the Native Memory → AXI-Lite bridge."""

    IDLE = 0
    AXI_WR_ADDR = 1
    AXI_WR_DATA = 2
    AXI_WR_RESP = 3
    WR_DONE = 4
    AXI_RD_ADDR = 5
    AXI_RD_RESP = 6
    RD_DONE = 7


_NATIVE_AXILITE_STATE_WIDTH = 3


def build_native_to_axilite(
    mem: "NativeMemInterface",
    axi: AXILiteInterface,
    clk: Signal,
    rst: Signal,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
) -> Tuple[List[Signal], List[HdlNode]]:
    """Build a Native-Memory-to-AXI-Lite bridge module AST.

    The bridge accepts SRAM-style transactions (cs/we/re) on the native
    slave side and translates them into AXI-Lite master transactions.
    """
    dw = mem.data_width
    aw = mem.addr_width
    sw = dw // 8
    byte_shift = int(math.log2(sw))

    _, _mem = BB.resolve_signals(mem)
    _, _axi = BB.resolve_signals(axi)

    axi_addr_width = axi.addr_width
    zero_pad = "0" * byte_shift

    internal_signals, r = BB.create_registers([
        ("state", _NATIVE_AXILITE_STATE_WIDTH, NativeAxiLiteState.IDLE),
        ("addr_reg", axi_addr_width, 0), ("wdata_reg", dw, 0), ("wstrb_reg", sw, 0),
        ("rdata_reg", dw, 0), ("is_write_reg", 1, 0),
    ])
    state_reg, addr_reg = r["state"], r["addr_reg"]
    wdata_reg, wstrb_reg = r["wdata_reg"], r["wstrb_reg"]
    rdata_reg, is_write_reg = r["rdata_reg"], r["is_write_reg"]

    reset_stmts = BB.build_reset_stmts_raw([
        (state_reg, NativeAxiLiteState.IDLE),
        (addr_reg, 0), (wdata_reg, 0), (wstrb_reg, 0),
        (rdata_reg, 0), (is_write_reg, 0),
        (_mem("dout"), 0), (_mem("ack"), 0),
        (_axi("awvalid"), 0), (_axi("awaddr"), 0), (_axi("awprot"), 0),
        (_axi("wvalid"), 0), (_axi("wdata"), 0), (_axi("wstrb"), 0),
        (_axi("bready"), 0),
        (_axi("arvalid"), 0), (_axi("araddr"), 0), (_axi("arprot"), 0),
        (_axi("rready"), 0),
    ])

    idle_body: List[HdlNode] = BB.deassert_outputs([
        _mem("ack"), _mem("dout"),
        _axi("awvalid"), _axi("wvalid"), _axi("bready"), _axi("arvalid"), _axi("rready"),
    ]) + [
        If(_mem("cs").name, then_body=[
            NonBlockingAssign(addr_reg, Concat(Slice(_mem("addr"), aw - 1, 0), zero_pad)),
            If(_mem("we").name, then_body=[
                NonBlockingAssign(wdata_reg, _mem("din")),
                NonBlockingAssign(wstrb_reg, _mem("we")),
                NonBlockingAssign(is_write_reg, 1),
                NonBlockingAssign(state_reg, NativeAxiLiteState.AXI_WR_ADDR),
            ], else_body=[If(_mem("re").name, then_body=[
                NonBlockingAssign(is_write_reg, 0),
                NonBlockingAssign(state_reg, NativeAxiLiteState.AXI_RD_ADDR),
            ])]),
        ]),
    ]

    axi_wr_addr_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awvalid"), 1), NonBlockingAssign(_axi("awaddr"), addr_reg),
        NonBlockingAssign(_axi("awprot"), 0),
        If(_axi("awready").name, then_body=[NonBlockingAssign(state_reg, NativeAxiLiteState.AXI_WR_DATA)]),
    ]

    axi_wr_data_body: List[HdlNode] = [
        NonBlockingAssign(_axi("awvalid"), 0), NonBlockingAssign(_axi("wvalid"), 1),
        NonBlockingAssign(_axi("wdata"), wdata_reg), NonBlockingAssign(_axi("wstrb"), wstrb_reg),
        If(_axi("wready").name, then_body=[NonBlockingAssign(state_reg, NativeAxiLiteState.AXI_WR_RESP)]),
    ]

    axi_wr_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("wvalid"), 0), NonBlockingAssign(_axi("bready"), 1),
        If(_axi("bvalid").name, then_body=[NonBlockingAssign(state_reg, NativeAxiLiteState.WR_DONE)]),
    ]

    wr_done_body: List[HdlNode] = [
        NonBlockingAssign(_axi("bready"), 0), NonBlockingAssign(_mem("ack"), 1),
        NonBlockingAssign(state_reg, NativeAxiLiteState.IDLE),
    ]

    axi_rd_addr_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arvalid"), 1), NonBlockingAssign(_axi("araddr"), addr_reg),
        NonBlockingAssign(_axi("arprot"), 0),
        If(_axi("arready").name, then_body=[NonBlockingAssign(state_reg, NativeAxiLiteState.AXI_RD_RESP)]),
    ]

    axi_rd_resp_body: List[HdlNode] = [
        NonBlockingAssign(_axi("arvalid"), 0), NonBlockingAssign(_axi("rready"), 1),
        If(_axi("rvalid").name, then_body=[
            NonBlockingAssign(rdata_reg, _axi("rdata")),
            NonBlockingAssign(state_reg, NativeAxiLiteState.RD_DONE),
        ]),
    ]

    rd_done_body: List[HdlNode] = [
        NonBlockingAssign(_axi("rready"), 0),
        NonBlockingAssign(_mem("dout"), rdata_reg), NonBlockingAssign(_mem("ack"), 1),
        NonBlockingAssign(state_reg, NativeAxiLiteState.IDLE),
    ]

    fsm_always = BB.build_fsm(state_reg, [
        (NativeAxiLiteState.IDLE, idle_body),
        (NativeAxiLiteState.AXI_WR_ADDR, axi_wr_addr_body),
        (NativeAxiLiteState.AXI_WR_DATA, axi_wr_data_body),
        (NativeAxiLiteState.AXI_WR_RESP, axi_wr_resp_body),
        (NativeAxiLiteState.WR_DONE, wr_done_body),
        (NativeAxiLiteState.AXI_RD_ADDR, axi_rd_addr_body),
        (NativeAxiLiteState.AXI_RD_RESP, axi_rd_resp_body),
        (NativeAxiLiteState.RD_DONE, rd_done_body),
    ], NativeAxiLiteState.IDLE, clk, rst, reset_style, active_low_reset, reset_stmts)

    return internal_signals, [fsm_always]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "BridgeBuilder",
    "BridgeState",
    "ReverseBridgeState",
    "Axi4NativeState",
    "Axi4AvalonState",
    "AxiLiteNativeState",
    "NativeAvalonState",
    "NativeAxiLiteState",
    "build_axilite_to_avalon",
    "build_avalon_to_axilite",
    "build_axi4_to_native",
    "build_axi4_to_avalon",
    "build_avalon_to_axi4",
    "build_axilite_to_native",
    "build_native_to_avalon",
    "build_native_to_axilite",
]
