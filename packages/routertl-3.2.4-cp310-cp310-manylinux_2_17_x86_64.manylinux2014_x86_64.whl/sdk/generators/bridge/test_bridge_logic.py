# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
test_bridge_logic.py — Unit tests for bridge_logic.py
=====================================================

Run with:
    python -m pytest sdk/generators/bridge/test_bridge_logic.py -v
"""

from bridge_logic import BridgeState, build_axilite_to_avalon
from bus_interfaces import AvalonMMInterface, AXILiteInterface, InterfaceRole
from hdl_ast import (
    Always,
    Case,
    Direction,
    Edge,
    If,
    Module,
    NonBlockingAssign,
    ResetStyle,
    Signal,
    Slice,
)
from validator import Validator

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build(
    dw: int = 32,
    aw: int = 16,
    avl_aw: int = 14,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
    axi_prefix: str = "s_axi",
    avl_prefix: str = "m_avl",
):
    """Build the FSM and return (signals, blocks, axi, avl, clk, rst)."""
    axi = AXILiteInterface(
        data_width=dw,
        addr_width=aw,
        prefix=axi_prefix,
    )
    avl = AvalonMMInterface(
        data_width=dw,
        addr_width=avl_aw,
        role=InterfaceRole.MASTER,
        prefix=avl_prefix,
    )
    clk = Signal("clk", direction=Direction.INPUT)
    rst = Signal("rst_n", direction=Direction.INPUT)
    signals, blocks = build_axilite_to_avalon(
        axi,
        avl,
        clk,
        rst,
        reset_style=reset_style,
        active_low_reset=active_low_reset,
    )
    return signals, blocks, axi, avl, clk, rst


def _build_module(dw: int = 32, aw: int = 16, avl_aw: int = 14):
    """Build a complete Module with the bridge logic wired in."""
    signals, blocks, axi, avl, clk, rst = _build(dw=dw, aw=aw, avl_aw=avl_aw)
    m = Module("test_bridge")
    m.add_port(clk)
    m.add_port(rst)
    for s in axi.get_signals():
        m.add_port(s)
    for s in avl.get_signals():
        m.add_port(s)
    for s in signals:
        m.add_signal(s)
    for b in blocks:
        m.add_block(b)
    return m, axi, avl


def _find_case(blocks):
    """Extract the Case node from the FSM always block."""
    assert len(blocks) >= 1
    always = blocks[0]
    assert isinstance(always, Always)
    # Body is [If(reset, ..., else=[Case])]
    fsm_if = always.body[0]
    assert isinstance(fsm_if, If)
    case_node = fsm_if.else_body[0]
    assert isinstance(case_node, Case)
    return case_node


def _find_reset_stmts(blocks):
    """Extract the reset branch statements."""
    always = blocks[0]
    fsm_if = always.body[0]
    return fsm_if.then_body


# ===========================================================================
# BridgeState
# ===========================================================================


class TestBridgeState:
    def test_state_count(self):
        assert len(BridgeState) == 8

    def test_idle_is_zero(self):
        assert BridgeState.IDLE == 0

    def test_all_unique(self):
        values = [s.value for s in BridgeState]
        assert len(values) == len(set(values))

    def test_fits_in_3_bits(self):
        for s in BridgeState:
            assert s.value < 8


# ===========================================================================
# build_axilite_to_avalon — Signal creation
# ===========================================================================


class TestInternalSignals:
    def test_returns_six_signals(self):
        signals, _, _, _, _, _ = _build()
        assert len(signals) == 6

    def test_state_register_exists(self):
        signals, _, _, _, _, _ = _build()
        names = [s.name for s in signals]
        assert "state" in names

    def test_state_register_width(self):
        signals, _, _, _, _, _ = _build()
        state = next(s for s in signals if s.name == "state")
        assert state.width == 3

    def test_addr_reg_matches_axi_width(self):
        signals, _, _, _, _, _ = _build(aw=24)
        addr = next(s for s in signals if s.name == "addr_reg")
        assert addr.width == 24

    def test_wdata_reg_matches_data_width(self):
        signals, _, _, _, _, _ = _build(dw=64)
        wdata = next(s for s in signals if s.name == "wdata_reg")
        assert wdata.width == 64

    def test_wstrb_reg_width(self):
        signals, _, _, _, _, _ = _build(dw=32)
        wstrb = next(s for s in signals if s.name == "wstrb_reg")
        assert wstrb.width == 4  # 32 / 8

    def test_wstrb_reg_width_64bit(self):
        signals, _, _, _, _, _ = _build(dw=64)
        wstrb = next(s for s in signals if s.name == "wstrb_reg")
        assert wstrb.width == 8  # 64 / 8

    def test_rdata_reg_matches_data_width(self):
        signals, _, _, _, _, _ = _build(dw=32)
        rdata = next(s for s in signals if s.name == "rdata_reg")
        assert rdata.width == 32

    def test_resp_reg_width(self):
        signals, _, _, _, _, _ = _build()
        resp = next(s for s in signals if s.name == "resp_reg")
        assert resp.width == 2

    def test_all_signals_are_local(self):
        signals, _, _, _, _, _ = _build()
        for s in signals:
            assert s.direction == Direction.LOCAL

    def test_state_reset_val_is_idle(self):
        signals, _, _, _, _, _ = _build()
        state = next(s for s in signals if s.name == "state")
        assert state.reset_val == BridgeState.IDLE


# ===========================================================================
# build_axilite_to_avalon — Always block structure
# ===========================================================================


class TestAlwaysBlock:
    def test_returns_one_block(self):
        _, blocks, _, _, _, _ = _build()
        assert len(blocks) == 1

    def test_block_is_always(self):
        _, blocks, _, _, _, _ = _build()
        assert isinstance(blocks[0], Always)

    def test_sync_reset_sensitivity(self):
        _, blocks, _, _, _, _ = _build(reset_style=ResetStyle.SYNC)
        always = blocks[0]
        assert len(always.sensitivity) == 1
        edge, sig = always.sensitivity[0]
        assert edge == Edge.POSEDGE
        assert sig.name == "clk"

    def test_async_reset_sensitivity_active_low(self):
        _, blocks, _, _, _, _ = _build(reset_style=ResetStyle.ASYNC, active_low_reset=True)
        always = blocks[0]
        assert len(always.sensitivity) == 2
        assert always.sensitivity[1] == (Edge.NEGEDGE, always.sensitivity[1][1])

    def test_async_reset_sensitivity_active_high(self):
        _, blocks, _, _, _, _ = _build(reset_style=ResetStyle.ASYNC, active_low_reset=False)
        always = blocks[0]
        assert len(always.sensitivity) == 2
        assert always.sensitivity[1][0] == Edge.POSEDGE

    def test_body_starts_with_if(self):
        _, blocks, _, _, _, _ = _build()
        always = blocks[0]
        assert isinstance(always.body[0], If)

    def test_if_has_reset_and_else(self):
        _, blocks, _, _, _, _ = _build()
        fsm_if = blocks[0].body[0]
        assert len(fsm_if.then_body) > 0  # reset stmts
        assert len(fsm_if.else_body) > 0  # case stmt


# ===========================================================================
# FSM Case branches
# ===========================================================================


class TestFSMStates:
    def test_case_has_nine_branches(self):
        """8 states + 1 default = 9 branches."""
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        assert len(case.branches) == 9

    def test_all_states_present(self):
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        branch_values = [v for v, _ in case.branches if v is not None]
        for st in BridgeState:
            assert st.value in branch_values, f"State {st.name} missing"

    def test_default_branch_exists(self):
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        defaults = [v for v, _ in case.branches if v is None]
        assert len(defaults) == 1

    def test_default_branch_goes_to_idle(self):
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        default_body = [b for v, b in case.branches if v is None][0]
        assert len(default_body) == 1
        assign = default_body[0]
        assert isinstance(assign, NonBlockingAssign)
        assert assign.source == BridgeState.IDLE

    def test_selector_is_state_reg(self):
        _, blocks, _, _, _, _ = _build()
        case = _find_case(blocks)
        assert isinstance(case.selector, Signal)
        assert case.selector.name == "state"


# ===========================================================================
# Address transformation
# ===========================================================================


class TestAddressTransform:
    def test_word_address_slice_32bit(self):
        """For 32-bit data, strip 2 LSBs: addr[15:2]."""
        _, blocks, _, _, _, _ = _build(dw=32, aw=16)
        case = _find_case(blocks)
        # Find the WR_ACCEPT branch — should contain addr slice
        wr_accept_body = [b for v, b in case.branches if v == BridgeState.WR_ACCEPT][0]
        # Find NonBlockingAssign that writes to avl address
        addr_assigns = [
            stmt
            for stmt in wr_accept_body
            if isinstance(stmt, NonBlockingAssign)
            and isinstance(stmt.target, Signal)
            and stmt.target.name.endswith("address")
        ]
        assert len(addr_assigns) >= 1
        assign = addr_assigns[0]
        assert isinstance(assign.source, Slice)
        assert assign.source.msb == 15  # addr_width - 1
        assert assign.source.lsb == 2  # log2(32/8)

    def test_word_address_slice_64bit(self):
        """For 64-bit data, strip 3 LSBs: addr[15:3]."""
        _, blocks, _, _, _, _ = _build(dw=64, aw=16)
        case = _find_case(blocks)
        wr_accept_body = [b for v, b in case.branches if v == BridgeState.WR_ACCEPT][0]
        addr_assigns = [
            stmt
            for stmt in wr_accept_body
            if isinstance(stmt, NonBlockingAssign)
            and isinstance(stmt.target, Signal)
            and stmt.target.name.endswith("address")
        ]
        assert len(addr_assigns) >= 1
        assert isinstance(addr_assigns[0].source, Slice)
        assert addr_assigns[0].source.lsb == 3  # log2(64/8)


# ===========================================================================
# Reset behavior
# ===========================================================================


class TestResetBehavior:
    def test_reset_deasserts_state(self):
        _, blocks, _, _, _, _ = _build()
        reset_stmts = _find_reset_stmts(blocks)
        state_resets = [
            s
            for s in reset_stmts
            if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal) and s.target.name == "state"
        ]
        assert len(state_resets) == 1
        assert state_resets[0].source == BridgeState.IDLE

    def test_reset_clears_axi_outputs(self):
        _, blocks, axi, _, _, _ = _build()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        # All AXI output handshakes should be reset
        for sig_name in ["awready", "wready", "bvalid", "arready", "rvalid"]:
            prefixed = f"s_axi_{sig_name}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_reset_clears_avalon_outputs(self):
        _, blocks, _, avl, _, _ = _build()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig_name in ["write", "read", "address", "writedata", "byteenable"]:
            prefixed = f"m_avl_{sig_name}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_active_low_reset_condition(self):
        _, blocks, _, _, _, _ = _build(active_low_reset=True)
        fsm_if = blocks[0].body[0]
        assert "!" in str(fsm_if.condition)

    def test_active_high_reset_condition(self):
        _, blocks, _, _, _, _ = _build(active_low_reset=False)
        fsm_if = blocks[0].body[0]
        assert "!" not in str(fsm_if.condition)


# ===========================================================================
# Parameterization
# ===========================================================================


class TestParameterization:
    def test_32bit_data_width(self):
        signals, _, _, _, _, _ = _build(dw=32)
        wdata = next(s for s in signals if s.name == "wdata_reg")
        assert wdata.width == 32

    def test_64bit_data_width(self):
        signals, _, _, _, _, _ = _build(dw=64)
        wdata = next(s for s in signals if s.name == "wdata_reg")
        assert wdata.width == 64

    def test_custom_axi_prefix(self):
        _, blocks, _, _, _, _ = _build(axi_prefix="my_axi")
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        assert "my_axi_awready" in reset_names

    def test_custom_avl_prefix(self):
        _, blocks, _, _, _, _ = _build(avl_prefix="my_avl")
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        assert "my_avl_write" in reset_names


# ===========================================================================
# Validator integration
# ===========================================================================


class TestValidatorIntegration:
    def test_width_check_passes(self):
        m, _, _ = _build_module()
        Validator(m).check_widths()  # must not raise

    def test_handshake_check_passes(self):
        m, axi, _ = _build_module()
        Validator(m).check_handshakes([axi])  # must not raise

    def test_waitrequest_check_passes(self):
        m, _, avl = _build_module()
        Validator(m).check_waitrequest([avl])  # must not raise


# ===========================================================================
# Round-trip: build → emit → inspect output
# ===========================================================================


class TestRoundTrip:
    def test_sv_emitter_produces_output(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        emitter = SystemVerilogEmitter()
        output = emitter.emit(m)
        assert "module test_bridge" in output
        assert "endmodule" in output

    def test_vhdl_emitter_produces_output(self):
        from emitter_vhdl import VHDLEmitter

        m, _, _ = _build_module()
        emitter = VHDLEmitter()
        output = emitter.emit(m)
        assert "entity test_bridge" in output.lower() or "entity" in output.lower()

    def test_sv_output_contains_case(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        output = SystemVerilogEmitter().emit(m)
        assert "case" in output.lower()

    def test_sv_output_contains_state_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        output = SystemVerilogEmitter().emit(m)
        assert "state" in output
        assert "addr_reg" in output

    def test_sv_output_contains_avalon_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        output = SystemVerilogEmitter().emit(m)
        assert "m_avl_write" in output
        assert "m_avl_read" in output
        assert "m_avl_waitrequest" in output

    def test_sv_output_contains_axi_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_module()
        output = SystemVerilogEmitter().emit(m)
        assert "s_axi_awvalid" in output
        assert "s_axi_bvalid" in output
        assert "s_axi_rvalid" in output


# ===========================================================================
# REVERSE BRIDGE: Avalon-MM → AXI-Lite
# ===========================================================================

from bridge_logic import ReverseBridgeState, build_avalon_to_axilite
from hdl_ast import Concat


def _build_reverse(
    dw: int = 32,
    aw: int = 16,
    avl_aw: int = 14,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
    axi_prefix: str = "m_axi",
    avl_prefix: str = "s_avl",
):
    """Build the reverse bridge FSM and return (signals, blocks, avl, axi, clk, rst)."""
    avl = AvalonMMInterface(
        data_width=dw,
        addr_width=avl_aw,
        role=InterfaceRole.SLAVE,
        prefix=avl_prefix,
    )
    axi = AXILiteInterface(
        data_width=dw,
        addr_width=aw,
        prefix=axi_prefix,
    )
    clk = Signal("clk", direction=Direction.INPUT)
    rst = Signal("rst_n", direction=Direction.INPUT)
    signals, blocks = build_avalon_to_axilite(
        avl,
        axi,
        clk,
        rst,
        reset_style=reset_style,
        active_low_reset=active_low_reset,
    )
    return signals, blocks, avl, axi, clk, rst


def _build_reverse_module(dw: int = 32, aw: int = 16, avl_aw: int = 14):
    """Build a complete Module with the reverse bridge logic wired in."""
    signals, blocks, avl, axi, clk, rst = _build_reverse(dw=dw, aw=aw, avl_aw=avl_aw)
    m = Module("test_reverse_bridge")
    m.add_port(clk)
    m.add_port(rst)
    for s in avl.get_signals():
        m.add_port(s)
    for s in axi.get_signals():
        m.add_port(s)
    for s in signals:
        m.add_signal(s)
    for b in blocks:
        m.add_block(b)
    return m, avl, axi


class TestReverseBridgeState:
    def test_state_count(self):
        assert len(ReverseBridgeState) == 8

    def test_idle_is_zero(self):
        assert ReverseBridgeState.IDLE == 0

    def test_all_unique(self):
        values = [s.value for s in ReverseBridgeState]
        assert len(values) == len(set(values))

    def test_fits_in_3_bits(self):
        for s in ReverseBridgeState:
            assert s.value < 8


class TestReverseInternalSignals:
    def test_returns_seven_signals(self):
        """Reverse bridge has 7 signals: state, addr_reg, wdata_reg, wstrb_reg,
        rdata_reg, resp_reg, is_write_reg."""
        signals, _, _, _, _, _ = _build_reverse()
        assert len(signals) == 7

    def test_state_register_exists(self):
        signals, _, _, _, _, _ = _build_reverse()
        names = [s.name for s in signals]
        assert "state" in names

    def test_is_write_reg_exists(self):
        signals, _, _, _, _, _ = _build_reverse()
        names = [s.name for s in signals]
        assert "is_write_reg" in names

    def test_is_write_reg_width(self):
        signals, _, _, _, _, _ = _build_reverse()
        is_wr = next(s for s in signals if s.name == "is_write_reg")
        assert is_wr.width == 1

    def test_addr_reg_matches_axi_width(self):
        signals, _, _, _, _, _ = _build_reverse(aw=24)
        addr = next(s for s in signals if s.name == "addr_reg")
        assert addr.width == 24

    def test_all_signals_are_local(self):
        signals, _, _, _, _, _ = _build_reverse()
        for s in signals:
            assert s.direction == Direction.LOCAL

    def test_state_reset_val_is_idle(self):
        signals, _, _, _, _, _ = _build_reverse()
        state = next(s for s in signals if s.name == "state")
        assert state.reset_val == ReverseBridgeState.IDLE


class TestReverseFSMStates:
    def test_case_has_nine_branches(self):
        """8 states + 1 default = 9 branches."""
        _, blocks, _, _, _, _ = _build_reverse()
        case = _find_case(blocks)
        assert len(case.branches) == 9

    def test_all_states_present(self):
        _, blocks, _, _, _, _ = _build_reverse()
        case = _find_case(blocks)
        branch_values = [v for v, _ in case.branches if v is not None]
        for st in ReverseBridgeState:
            assert st.value in branch_values, f"State {st.name} missing"

    def test_default_branch_goes_to_idle(self):
        _, blocks, _, _, _, _ = _build_reverse()
        case = _find_case(blocks)
        default_body = [b for v, b in case.branches if v is None][0]
        assert len(default_body) == 1
        assert isinstance(default_body[0], NonBlockingAssign)
        assert default_body[0].source == ReverseBridgeState.IDLE


class TestReverseAddressTransform:
    def test_byte_address_uses_concat_32bit(self):
        """For 32-bit data, addr_reg = {avl_address, 2'b00}."""
        _, blocks, _, _, _, _ = _build_reverse(dw=32, aw=16, avl_aw=14)
        case = _find_case(blocks)
        # Find the IDLE branch — address latch is inside the If
        idle_body = [b for v, b in case.branches if v == ReverseBridgeState.IDLE][0]

        # Search recursively for NonBlockingAssign to addr_reg with Concat
        def _find_concat_assigns(nodes):
            found = []
            for node in nodes:
                if isinstance(node, NonBlockingAssign):
                    if (
                        isinstance(node.target, Signal)
                        and node.target.name == "addr_reg"
                        and isinstance(node.source, Concat)
                    ):
                        found.append(node)
                if isinstance(node, If):
                    found.extend(_find_concat_assigns(node.then_body))
                    found.extend(_find_concat_assigns(node.else_body))
            return found

        assigns = _find_concat_assigns(idle_body)
        assert len(assigns) >= 1, "Expected Concat-based addr_reg assignment"
        concat = assigns[0].source
        assert isinstance(concat, Concat)
        # First part should be the Slice of avl_address
        assert isinstance(concat.parts[0], Slice)


class TestReverseResetBehavior:
    def test_reset_drives_waitrequest_high(self):
        """On reset, waitrequest should be driven to 1 (stall the bus)."""
        _, blocks, _, _, _, _ = _build_reverse()
        reset_stmts = _find_reset_stmts(blocks)
        waitrequest_resets = [
            s
            for s in reset_stmts
            if isinstance(s, NonBlockingAssign)
            and isinstance(s.target, Signal)
            and s.target.name.endswith("waitrequest")
        ]
        assert len(waitrequest_resets) == 1
        assert waitrequest_resets[0].source == 1

    def test_reset_clears_axi_master_outputs(self):
        _, blocks, _, _, _, _ = _build_reverse()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig in ["awvalid", "wvalid", "bready", "arvalid", "rready"]:
            prefixed = f"m_axi_{sig}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_reset_clears_avalon_slave_outputs(self):
        _, blocks, _, _, _, _ = _build_reverse()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig in ["waitrequest", "readdata", "readdatavalid", "response"]:
            prefixed = f"s_avl_{sig}"
            assert prefixed in reset_names, f"{prefixed} not in reset"


class TestReverseRoundTrip:
    def test_sv_emitter_produces_output(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_reverse_module()
        output = SystemVerilogEmitter().emit(m)
        assert "module test_reverse_bridge" in output
        assert "endmodule" in output

    def test_vhdl_emitter_produces_output(self):
        from emitter_vhdl import VHDLEmitter

        m, _, _ = _build_reverse_module()
        output = VHDLEmitter().emit(m)
        assert "entity" in output.lower()

    def test_sv_output_contains_axi_master_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_reverse_module()
        output = SystemVerilogEmitter().emit(m)
        assert "m_axi_awvalid" in output
        assert "m_axi_arvalid" in output
        assert "m_axi_bready" in output

    def test_sv_output_contains_avalon_slave_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_reverse_module()
        output = SystemVerilogEmitter().emit(m)
        assert "s_avl_waitrequest" in output
        assert "s_avl_readdatavalid" in output


# ===========================================================================
# NATIVE MEMORY → AVALON-MM BRIDGE
# ===========================================================================

from bridge_logic import NativeAvalonState, build_native_to_avalon
from bus_interfaces import NativeMemInterface


def _build_native_avalon(
    dw: int = 32,
    aw: int = 14,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
    mem_prefix: str = "s_mem",
    avl_prefix: str = "m_avl",
):
    """Build the native→avalon FSM and return (signals, blocks, mem, avl, clk, rst)."""
    mem = NativeMemInterface(
        data_width=dw,
        addr_width=aw,
        role=InterfaceRole.SLAVE,
        prefix=mem_prefix,
    )
    avl = AvalonMMInterface(
        data_width=dw,
        addr_width=aw,
        role=InterfaceRole.MASTER,
        prefix=avl_prefix,
    )
    clk = Signal("clk", direction=Direction.INPUT)
    rst = Signal("rst_n", direction=Direction.INPUT)
    signals, blocks = build_native_to_avalon(
        mem,
        avl,
        clk,
        rst,
        reset_style=reset_style,
        active_low_reset=active_low_reset,
    )
    return signals, blocks, mem, avl, clk, rst


def _build_native_avalon_module(dw: int = 32, aw: int = 14):
    """Build a complete Module with the native→avalon bridge wired in."""
    signals, blocks, mem, avl, clk, rst = _build_native_avalon(dw=dw, aw=aw)
    m = Module("test_native_avalon_bridge")
    m.add_port(clk)
    m.add_port(rst)
    for s in mem.get_signals():
        m.add_port(s)
    for s in avl.get_signals():
        m.add_port(s)
    for s in signals:
        m.add_signal(s)
    for b in blocks:
        m.add_block(b)
    return m, mem, avl


class TestNativeAvalonState:
    def test_state_count(self):
        assert len(NativeAvalonState) == 6

    def test_idle_is_zero(self):
        assert NativeAvalonState.IDLE == 0

    def test_all_unique(self):
        values = [s.value for s in NativeAvalonState]
        assert len(values) == len(set(values))

    def test_fits_in_3_bits(self):
        for s in NativeAvalonState:
            assert s.value < 8


class TestNativeAvalonSignals:
    def test_returns_five_signals(self):
        """state, addr_reg, wdata_reg, wstrb_reg, rdata_reg."""
        signals, _, _, _, _, _ = _build_native_avalon()
        assert len(signals) == 5

    def test_state_register_exists(self):
        signals, _, _, _, _, _ = _build_native_avalon()
        names = [s.name for s in signals]
        assert "state" in names

    def test_state_register_width(self):
        signals, _, _, _, _, _ = _build_native_avalon()
        state = next(s for s in signals if s.name == "state")
        assert state.width == 3

    def test_addr_reg_matches_mem_width(self):
        signals, _, _, _, _, _ = _build_native_avalon(aw=20)
        addr = next(s for s in signals if s.name == "addr_reg")
        assert addr.width == 20

    def test_wdata_reg_matches_data_width(self):
        signals, _, _, _, _, _ = _build_native_avalon(dw=64)
        wdata = next(s for s in signals if s.name == "wdata_reg")
        assert wdata.width == 64

    def test_wstrb_reg_width(self):
        signals, _, _, _, _, _ = _build_native_avalon(dw=32)
        wstrb = next(s for s in signals if s.name == "wstrb_reg")
        assert wstrb.width == 4  # 32 / 8

    def test_wstrb_reg_width_64bit(self):
        signals, _, _, _, _, _ = _build_native_avalon(dw=64)
        wstrb = next(s for s in signals if s.name == "wstrb_reg")
        assert wstrb.width == 8  # 64 / 8

    def test_rdata_reg_matches_data_width(self):
        signals, _, _, _, _, _ = _build_native_avalon(dw=32)
        rdata = next(s for s in signals if s.name == "rdata_reg")
        assert rdata.width == 32

    def test_all_signals_are_local(self):
        signals, _, _, _, _, _ = _build_native_avalon()
        for s in signals:
            assert s.direction == Direction.LOCAL

    def test_state_reset_val_is_idle(self):
        signals, _, _, _, _, _ = _build_native_avalon()
        state = next(s for s in signals if s.name == "state")
        assert state.reset_val == NativeAvalonState.IDLE


class TestNativeAvalonFSM:
    def test_case_has_seven_branches(self):
        """6 states + 1 default = 7 branches."""
        _, blocks, _, _, _, _ = _build_native_avalon()
        case = _find_case(blocks)
        assert len(case.branches) == 7

    def test_all_states_present(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        case = _find_case(blocks)
        branch_values = [v for v, _ in case.branches if v is not None]
        for st in NativeAvalonState:
            assert st.value in branch_values, f"State {st.name} missing"

    def test_default_branch_exists(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        case = _find_case(blocks)
        defaults = [v for v, _ in case.branches if v is None]
        assert len(defaults) == 1

    def test_default_branch_goes_to_idle(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        case = _find_case(blocks)
        default_body = [b for v, b in case.branches if v is None][0]
        assert len(default_body) == 1
        assign = default_body[0]
        assert isinstance(assign, NonBlockingAssign)
        assert assign.source == NativeAvalonState.IDLE

    def test_selector_is_state_reg(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        case = _find_case(blocks)
        assert isinstance(case.selector, Signal)
        assert case.selector.name == "state"


class TestNativeAvalonAlwaysBlock:
    def test_returns_one_block(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        assert len(blocks) == 1

    def test_block_is_always(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        assert isinstance(blocks[0], Always)

    def test_sync_reset_sensitivity(self):
        _, blocks, _, _, _, _ = _build_native_avalon(reset_style=ResetStyle.SYNC)
        always = blocks[0]
        assert len(always.sensitivity) == 1
        edge, sig = always.sensitivity[0]
        assert edge == Edge.POSEDGE
        assert sig.name == "clk"

    def test_async_reset_sensitivity_active_low(self):
        _, blocks, _, _, _, _ = _build_native_avalon(reset_style=ResetStyle.ASYNC, active_low_reset=True)
        always = blocks[0]
        assert len(always.sensitivity) == 2
        assert always.sensitivity[1] == (Edge.NEGEDGE, always.sensitivity[1][1])

    def test_async_reset_sensitivity_active_high(self):
        _, blocks, _, _, _, _ = _build_native_avalon(reset_style=ResetStyle.ASYNC, active_low_reset=False)
        always = blocks[0]
        assert len(always.sensitivity) == 2
        assert always.sensitivity[1][0] == Edge.POSEDGE


class TestNativeAvalonReset:
    def test_reset_deasserts_state(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        reset_stmts = _find_reset_stmts(blocks)
        state_resets = [
            s
            for s in reset_stmts
            if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal) and s.target.name == "state"
        ]
        assert len(state_resets) == 1
        assert state_resets[0].source == NativeAvalonState.IDLE

    def test_reset_clears_native_outputs(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig in ["dout", "ack"]:
            prefixed = f"s_mem_{sig}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_reset_clears_avalon_outputs(self):
        _, blocks, _, _, _, _ = _build_native_avalon()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig in ["write", "read", "address", "writedata", "byteenable"]:
            prefixed = f"m_avl_{sig}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_active_low_reset_condition(self):
        _, blocks, _, _, _, _ = _build_native_avalon(active_low_reset=True)
        fsm_if = blocks[0].body[0]
        assert "!" in str(fsm_if.condition)

    def test_active_high_reset_condition(self):
        _, blocks, _, _, _, _ = _build_native_avalon(active_low_reset=False)
        fsm_if = blocks[0].body[0]
        assert "!" not in str(fsm_if.condition)


class TestNativeAvalonRoundTrip:
    def test_sv_emitter_produces_output(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_native_avalon_module()
        output = SystemVerilogEmitter().emit(m)
        assert "module test_native_avalon_bridge" in output
        assert "endmodule" in output

    def test_vhdl_emitter_produces_output(self):
        from emitter_vhdl import VHDLEmitter

        m, _, _ = _build_native_avalon_module()
        output = VHDLEmitter().emit(m)
        assert "entity" in output.lower()

    def test_sv_output_contains_case(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_native_avalon_module()
        output = SystemVerilogEmitter().emit(m)
        assert "case" in output.lower()

    def test_sv_output_contains_native_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_native_avalon_module()
        output = SystemVerilogEmitter().emit(m)
        assert "s_mem_cs" in output
        assert "s_mem_addr" in output
        assert "s_mem_ack" in output

    def test_sv_output_contains_avalon_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_native_avalon_module()
        output = SystemVerilogEmitter().emit(m)
        assert "m_avl_write" in output
        assert "m_avl_read" in output
        assert "m_avl_waitrequest" in output


# ===========================================================================
# AXI-LITE → NATIVE MEMORY BRIDGE
# ===========================================================================

from bridge_logic import AxiLiteNativeState, build_axilite_to_native


def _build_axilite_native(
    dw: int = 32,
    aw: int = 16,
    read_latency: int = 1,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
    axi_prefix: str = "s_axi",
    mem_prefix: str = "m_mem",
):
    """Build the axilite→native FSM and return (signals, blocks, axi, mem, clk, rst)."""
    byte_shift = int(__import__("math").log2(dw // 8))
    native_aw = aw - byte_shift
    axi = AXILiteInterface(
        data_width=dw,
        addr_width=aw,
        prefix=axi_prefix,
    )
    mem = NativeMemInterface(
        data_width=dw,
        addr_width=native_aw,
        role=InterfaceRole.MASTER,
        prefix=mem_prefix,
    )
    clk = Signal("clk", direction=Direction.INPUT)
    rst = Signal("rst_n", direction=Direction.INPUT)
    signals, blocks = build_axilite_to_native(
        axi,
        mem,
        clk,
        rst,
        read_latency=read_latency,
        reset_style=reset_style,
        active_low_reset=active_low_reset,
    )
    return signals, blocks, axi, mem, clk, rst


def _build_axilite_native_module(dw: int = 32, aw: int = 16, read_latency: int = 1):
    signals, blocks, axi, mem, clk, rst = _build_axilite_native(
        dw=dw, aw=aw, read_latency=read_latency
    )
    m = Module("test_axilite_native_bridge")
    m.add_port(clk)
    m.add_port(rst)
    for s in axi.get_signals():
        m.add_port(s)
    for s in mem.get_signals():
        m.add_port(s)
    for s in signals:
        m.add_signal(s)
    for b in blocks:
        m.add_block(b)
    return m, axi, mem


class TestAxiLiteNativeState:
    def test_state_count(self):
        assert len(AxiLiteNativeState) == 7

    def test_idle_is_zero(self):
        assert AxiLiteNativeState.IDLE == 0

    def test_all_unique(self):
        values = [s.value for s in AxiLiteNativeState]
        assert len(values) == len(set(values))

    def test_fits_in_3_bits(self):
        for s in AxiLiteNativeState:
            assert s.value < 8


class TestAxiLiteNativeSignals:
    def test_returns_three_signals(self):
        """state, addr_reg, lat_reg."""
        signals, _, _, _, _, _ = _build_axilite_native()
        assert len(signals) == 3

    def test_state_register_exists(self):
        signals, _, _, _, _, _ = _build_axilite_native()
        names = [s.name for s in signals]
        assert "state" in names

    def test_state_register_width(self):
        signals, _, _, _, _, _ = _build_axilite_native()
        state = next(s for s in signals if s.name == "state")
        assert state.width == 3

    def test_addr_reg_matches_axi_width(self):
        signals, _, _, _, _, _ = _build_axilite_native(aw=24)
        addr = next(s for s in signals if s.name == "addr_reg")
        assert addr.width == 24

    def test_lat_reg_exists(self):
        signals, _, _, _, _, _ = _build_axilite_native()
        names = [s.name for s in signals]
        assert "lat_reg" in names

    def test_all_signals_are_local(self):
        signals, _, _, _, _, _ = _build_axilite_native()
        for s in signals:
            assert s.direction == Direction.LOCAL

    def test_state_reset_val_is_idle(self):
        signals, _, _, _, _, _ = _build_axilite_native()
        state = next(s for s in signals if s.name == "state")
        assert state.reset_val == AxiLiteNativeState.IDLE


class TestAxiLiteNativeFSM:
    def test_case_has_eight_branches(self):
        """7 states + 1 default = 8 branches."""
        _, blocks, _, _, _, _ = _build_axilite_native()
        case = _find_case(blocks)
        assert len(case.branches) == 8

    def test_all_states_present(self):
        _, blocks, _, _, _, _ = _build_axilite_native()
        case = _find_case(blocks)
        branch_values = [v for v, _ in case.branches if v is not None]
        for st in AxiLiteNativeState:
            assert st.value in branch_values, f"State {st.name} missing"

    def test_default_branch_goes_to_idle(self):
        _, blocks, _, _, _, _ = _build_axilite_native()
        case = _find_case(blocks)
        default_body = [b for v, b in case.branches if v is None][0]
        assert len(default_body) == 1
        assert isinstance(default_body[0], NonBlockingAssign)
        assert default_body[0].source == AxiLiteNativeState.IDLE

    def test_selector_is_state_reg(self):
        _, blocks, _, _, _, _ = _build_axilite_native()
        case = _find_case(blocks)
        assert isinstance(case.selector, Signal)
        assert case.selector.name == "state"


class TestAxiLiteNativeReset:
    def test_reset_deasserts_state(self):
        _, blocks, _, _, _, _ = _build_axilite_native()
        reset_stmts = _find_reset_stmts(blocks)
        state_resets = [
            s
            for s in reset_stmts
            if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal) and s.target.name == "state"
        ]
        assert len(state_resets) == 1
        assert state_resets[0].source == AxiLiteNativeState.IDLE

    def test_reset_clears_axi_outputs(self):
        _, blocks, _, _, _, _ = _build_axilite_native()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig in ["awready", "wready", "bvalid", "bresp", "arready", "rvalid", "rresp", "rdata"]:
            prefixed = f"s_axi_{sig}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_reset_clears_native_outputs(self):
        _, blocks, _, _, _, _ = _build_axilite_native()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig in ["we", "re", "cs", "addr", "din"]:
            prefixed = f"m_mem_{sig}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_active_low_reset_condition(self):
        _, blocks, _, _, _, _ = _build_axilite_native(active_low_reset=True)
        fsm_if = blocks[0].body[0]
        assert "!" in str(fsm_if.condition)


class TestAxiLiteNativeAlwaysBlock:
    def test_returns_one_block(self):
        _, blocks, _, _, _, _ = _build_axilite_native()
        assert len(blocks) == 1

    def test_sync_reset_sensitivity(self):
        _, blocks, _, _, _, _ = _build_axilite_native(reset_style=ResetStyle.SYNC)
        always = blocks[0]
        assert len(always.sensitivity) == 1

    def test_async_reset_sensitivity(self):
        _, blocks, _, _, _, _ = _build_axilite_native(reset_style=ResetStyle.ASYNC)
        always = blocks[0]
        assert len(always.sensitivity) == 2


class TestAxiLiteNativeRoundTrip:
    def test_sv_emitter_produces_output(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_axilite_native_module()
        output = SystemVerilogEmitter().emit(m)
        assert "module test_axilite_native_bridge" in output
        assert "endmodule" in output

    def test_vhdl_emitter_produces_output(self):
        from emitter_vhdl import VHDLEmitter

        m, _, _ = _build_axilite_native_module()
        output = VHDLEmitter().emit(m)
        assert "entity" in output.lower()

    def test_sv_output_contains_axi_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_axilite_native_module()
        output = SystemVerilogEmitter().emit(m)
        assert "s_axi_awvalid" in output
        assert "s_axi_rdata" in output
        assert "s_axi_bvalid" in output

    def test_sv_output_contains_native_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_axilite_native_module()
        output = SystemVerilogEmitter().emit(m)
        assert "m_mem_cs" in output
        assert "m_mem_we" in output
        assert "m_mem_addr" in output

    def test_sv_output_contains_case(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_axilite_native_module()
        output = SystemVerilogEmitter().emit(m)
        assert "case" in output.lower()


# ===========================================================================
# NATIVE MEMORY → AXI-LITE BRIDGE
# ===========================================================================

from bridge_logic import NativeAxiLiteState, build_native_to_axilite


def _build_native_axilite(
    dw: int = 32,
    aw: int = 14,
    reset_style: ResetStyle = ResetStyle.SYNC,
    active_low_reset: bool = True,
    mem_prefix: str = "s_mem",
    axi_prefix: str = "m_axi",
):
    """Build the native→axilite FSM and return (signals, blocks, mem, axi, clk, rst)."""
    import math

    axi_aw = aw + int(math.log2(dw // 8))
    mem = NativeMemInterface(
        data_width=dw,
        addr_width=aw,
        role=InterfaceRole.SLAVE,
        prefix=mem_prefix,
    )
    axi = AXILiteInterface(
        data_width=dw,
        addr_width=axi_aw,
        role=InterfaceRole.MASTER,
        prefix=axi_prefix,
    )
    clk = Signal("clk", direction=Direction.INPUT)
    rst = Signal("rst_n", direction=Direction.INPUT)
    signals, blocks = build_native_to_axilite(
        mem,
        axi,
        clk,
        rst,
        reset_style=reset_style,
        active_low_reset=active_low_reset,
    )
    return signals, blocks, mem, axi, clk, rst


def _build_native_axilite_module(dw: int = 32, aw: int = 14):
    signals, blocks, mem, axi, clk, rst = _build_native_axilite(dw=dw, aw=aw)
    m = Module("test_native_axilite_bridge")
    m.add_port(clk)
    m.add_port(rst)
    for s in mem.get_signals():
        m.add_port(s)
    for s in axi.get_signals():
        m.add_port(s)
    for s in signals:
        m.add_signal(s)
    for b in blocks:
        m.add_block(b)
    return m, mem, axi


class TestNativeAxiLiteState:
    def test_state_count(self):
        assert len(NativeAxiLiteState) == 8

    def test_idle_is_zero(self):
        assert NativeAxiLiteState.IDLE == 0

    def test_all_unique(self):
        values = [s.value for s in NativeAxiLiteState]
        assert len(values) == len(set(values))

    def test_fits_in_3_bits(self):
        for s in NativeAxiLiteState:
            assert s.value < 8


class TestNativeAxiLiteSignals:
    def test_returns_six_signals(self):
        """state, addr_reg, wdata_reg, wstrb_reg, rdata_reg, is_write_reg."""
        signals, _, _, _, _, _ = _build_native_axilite()
        assert len(signals) == 6

    def test_state_register_exists(self):
        signals, _, _, _, _, _ = _build_native_axilite()
        names = [s.name for s in signals]
        assert "state" in names

    def test_is_write_reg_exists(self):
        signals, _, _, _, _, _ = _build_native_axilite()
        names = [s.name for s in signals]
        assert "is_write_reg" in names

    def test_wdata_reg_matches_data_width(self):
        signals, _, _, _, _, _ = _build_native_axilite(dw=64)
        wdata = next(s for s in signals if s.name == "wdata_reg")
        assert wdata.width == 64

    def test_wstrb_reg_width(self):
        signals, _, _, _, _, _ = _build_native_axilite(dw=32)
        wstrb = next(s for s in signals if s.name == "wstrb_reg")
        assert wstrb.width == 4

    def test_all_signals_are_local(self):
        signals, _, _, _, _, _ = _build_native_axilite()
        for s in signals:
            assert s.direction == Direction.LOCAL

    def test_state_reset_val_is_idle(self):
        signals, _, _, _, _, _ = _build_native_axilite()
        state = next(s for s in signals if s.name == "state")
        assert state.reset_val == NativeAxiLiteState.IDLE


class TestNativeAxiLiteFSM:
    def test_case_has_nine_branches(self):
        """8 states + 1 default = 9 branches."""
        _, blocks, _, _, _, _ = _build_native_axilite()
        case = _find_case(blocks)
        assert len(case.branches) == 9

    def test_all_states_present(self):
        _, blocks, _, _, _, _ = _build_native_axilite()
        case = _find_case(blocks)
        branch_values = [v for v, _ in case.branches if v is not None]
        for st in NativeAxiLiteState:
            assert st.value in branch_values, f"State {st.name} missing"

    def test_default_branch_goes_to_idle(self):
        _, blocks, _, _, _, _ = _build_native_axilite()
        case = _find_case(blocks)
        default_body = [b for v, b in case.branches if v is None][0]
        assert len(default_body) == 1
        assert isinstance(default_body[0], NonBlockingAssign)
        assert default_body[0].source == NativeAxiLiteState.IDLE

    def test_selector_is_state_reg(self):
        _, blocks, _, _, _, _ = _build_native_axilite()
        case = _find_case(blocks)
        assert isinstance(case.selector, Signal)
        assert case.selector.name == "state"


class TestNativeAxiLiteReset:
    def test_reset_clears_native_outputs(self):
        _, blocks, _, _, _, _ = _build_native_axilite()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig in ["dout", "ack"]:
            prefixed = f"s_mem_{sig}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_reset_clears_axi_master_outputs(self):
        _, blocks, _, _, _, _ = _build_native_axilite()
        reset_stmts = _find_reset_stmts(blocks)
        reset_names = {
            s.target.name for s in reset_stmts if isinstance(s, NonBlockingAssign) and isinstance(s.target, Signal)
        }
        for sig in ["awvalid", "awaddr", "awprot", "wvalid", "wdata", "wstrb", "bready",
                     "arvalid", "araddr", "arprot", "rready"]:
            prefixed = f"m_axi_{sig}"
            assert prefixed in reset_names, f"{prefixed} not in reset"

    def test_active_low_reset_condition(self):
        _, blocks, _, _, _, _ = _build_native_axilite(active_low_reset=True)
        fsm_if = blocks[0].body[0]
        assert "!" in str(fsm_if.condition)


class TestNativeAxiLiteRoundTrip:
    def test_sv_emitter_produces_output(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_native_axilite_module()
        output = SystemVerilogEmitter().emit(m)
        assert "module test_native_axilite_bridge" in output
        assert "endmodule" in output

    def test_vhdl_emitter_produces_output(self):
        from emitter_vhdl import VHDLEmitter

        m, _, _ = _build_native_axilite_module()
        output = VHDLEmitter().emit(m)
        assert "entity" in output.lower()

    def test_sv_output_contains_native_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_native_axilite_module()
        output = SystemVerilogEmitter().emit(m)
        assert "s_mem_cs" in output
        assert "s_mem_ack" in output
        assert "s_mem_addr" in output

    def test_sv_output_contains_axi_master_signals(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_native_axilite_module()
        output = SystemVerilogEmitter().emit(m)
        assert "m_axi_awvalid" in output
        assert "m_axi_arvalid" in output
        assert "m_axi_bready" in output
        assert "m_axi_rready" in output

    def test_sv_output_contains_case(self):
        from emitter_sv import SystemVerilogEmitter

        m, _, _ = _build_native_axilite_module()
        output = SystemVerilogEmitter().emit(m)
        assert "case" in output.lower()


