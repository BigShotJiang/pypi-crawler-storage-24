# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Vendor tool health checks — synthesis tools, Docker, license server,
licensed families, and vendor-specific simulation libraries.
"""

from __future__ import annotations

import os
from pathlib import Path

from sdk.cli.checks import CheckRegistry, CheckResult
from sdk.cli.checks._helpers import (
    _cli_name,
    _detect_docker_container,
    _load_project_yml,
    _parse_version,
    _run,
    _which,
)
from sdk.cli.resilience import cli_resilient_block

# ──────────────────────────────────────────────────────────────
# check_vendor_tool  (order=20)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Vendor Tool", order=20)
def check_vendor_tool():
    """Check vendor-specific synthesis tool based on project.yml hardware.vendor."""
    # Vendor → (binary, display_name, version_cmd, version_regex, install_hint)
    VENDOR_TOOLS = {
        "xilinx": (
            "vivado",
            "Vivado",
            ["vivado", "-version"],
            r"Vivado v(\d+\.\d+)",
            "Source Vivado settings: source /tools/Xilinx/Vivado/<ver>/settings64.sh",
        ),
        "altera": (
            "quartus_sh",
            "Quartus",
            ["quartus_sh", "--version"],
            r"Version (\d+\.\d+)",
            "Add Quartus to PATH: export PATH=/opt/altera/quartus/bin:$PATH",
        ),
        "lattice": (
            "radiantc",
            "Radiant",
            ["radiantc", "--version"],
            r"(\d+\.\d+)",
            "Source Radiant settings or add to PATH",
        ),
        "microchip": (
            "libero",
            "Libero SoC",
            ["libero", "--version"],
            r"(\d+\.\d+)",
            "Add Libero SoC to PATH",
        ),
    }

    # Docker-aware: if inside a vendor container, show it as running
    docker_env = _detect_docker_container()
    DOCKER_TO_VENDOR = {"dev": "xilinx", "quartus": "altera", "vivado": "xilinx", "radiant": "lattice", "libero": "microchip"}
    if docker_env and docker_env in DOCKER_TO_VENDOR:
        vendor_key = DOCKER_TO_VENDOR[docker_env]
        tool_info = VENDOR_TOOLS[vendor_key]
        _, display_name, ver_cmd, ver_regex, _ = tool_info
        rc, out = _run(ver_cmd)
        ver = _parse_version(out, ver_regex)
        edition = _parse_quartus_edition(out) if vendor_key == "altera" else None
        edition_tag = f" {edition}" if edition else ""
        detail = f"v{ver}{edition_tag} (Docker container)" if ver else "running in Docker container"
        return CheckResult(display_name, CheckResult.OK, detail)

    cfg = _load_project_yml()
    vendor = "xilinx"  # default
    expected_edition = None
    if isinstance(cfg, dict):
        hw = cfg.get("hardware") or {}
        if isinstance(hw, dict):
            vendor = hw.get("vendor") or "xilinx"
            expected_edition = hw.get("edition")

    tool_info = VENDOR_TOOLS.get(vendor, VENDOR_TOOLS["xilinx"])
    binary, display_name, ver_cmd, ver_regex, hint = tool_info

    from sdk.api.tools import resolve_tool_binary

    path = resolve_tool_binary(binary)
    if not path:
        return CheckResult(
            display_name,
            CheckResult.WARN,
            f"'{binary}' not found on PATH",
            fix=hint,
        )

    # Microchip's CLI crashes on headless servers when trying to load Qt plugins,
    # even just for `--version`. If we found the binary, we consider it OK.
    if vendor == "microchip":
        return CheckResult(
            display_name,
            CheckResult.OK,
            f"Found at {path} (version execution bypassed)",
        )

    # Use the resolved path for version check
    resolved_ver_cmd = [path] + ver_cmd[1:]
    rc, out = _run(resolved_ver_cmd)
    ver = _parse_version(out, ver_regex)

    # Quartus edition detection (Pro / Standard / Lite)
    edition = _parse_quartus_edition(out) if vendor == "altera" else None
    edition_tag = f" {edition}" if edition else ""
    detail = f"v{ver}{edition_tag} ({path})" if ver else f"found ({path})"

    # Cross-check edition against project.yml hardware.edition
    if edition and expected_edition:
        expected_norm = expected_edition.lower().replace("_", " ")
        detected_norm = edition.lower()
        if expected_norm not in detected_norm:
            return CheckResult(
                display_name,
                CheckResult.WARN,
                f"v{ver}{edition_tag} — expected {expected_edition} (from project.yml)",
                fix=f"Install Quartus Prime {expected_edition} or update project.yml: "
                f"hardware.edition: {edition.split()[0].lower()}",
            )

    return CheckResult(display_name, CheckResult.OK, detail)


def _parse_quartus_edition(version_output: str) -> str | None:
    """Extract the Quartus edition from ``quartus_sh --version`` output.

    Known edition strings (from Intel documentation):
      - ``SC Pro Edition``  (formerly "Pro Edition")
      - ``Pro Edition``
      - ``Standard Edition``
      - ``Lite Edition``

    Returns:
        Short edition string like "Pro", "Standard", "Lite", or None.
    """
    import re

    m = re.search(r"(SC\s+Pro|Pro|Standard|Lite)\s+Edition", version_output, re.IGNORECASE)
    if m:
        raw = m.group(1).strip()
        # Normalize: "SC Pro" → "Pro"
        if raw.lower().startswith("sc"):
            return "Pro"
        return raw.capitalize()
    return None


# ──────────────────────────────────────────────────────────────
# check_docker  (order=25)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Docker", order=25)
def check_docker():
    """Validate Docker is running."""
    docker_env = _detect_docker_container()
    if docker_env:
        return CheckResult(
            "Docker",
            CheckResult.OK,
            f"inside Docker container (routertl-{docker_env})",
        )
    path = _which("docker")
    if not path:
        return CheckResult(
            "Docker",
            CheckResult.WARN,
            "not installed",
            fix="Install Docker Engine: https://docs.docker.com/engine/install/",
        )
    rc, out = _run(["docker", "info"], timeout=15)
    if rc != 0:
        return CheckResult(
            "Docker",
            CheckResult.WARN,
            "installed but daemon not running",
            fix="Start Docker: sudo systemctl start docker",
        )
    return CheckResult("Docker", CheckResult.OK, f"running ({path})")


# ──────────────────────────────────────────────────────────────
# _check_license_server  (order=30)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("License Server", order=30)
def _check_license_server():
    """Check license server reachability via TCP probe."""
    results = []

    # License server probe
    lic_str = os.environ.get("LM_LICENSE_FILE", "")
    if not lic_str:
        # Check .env file
        env_file = Path(".env")
        if env_file.exists():
            with cli_resilient_block(".env license parsing"):
                for line in env_file.read_text().splitlines():
                    line = line.strip()
                    if line.startswith("LM_LICENSE_FILE="):
                        lic_str = line.split("=", 1)[1].strip()
                        break

    if lic_str:
        try:
            from sdk.cli.commands.docker.status import _probe_license_server

            reachable = _probe_license_server(lic_str)
            if reachable is True:
                results.append(
                    CheckResult(
                        "License Server",
                        CheckResult.OK,
                        f"reachable ({lic_str})",
                    )
                )
            elif reachable is False:
                results.append(
                    CheckResult(
                        "License Server",
                        CheckResult.WARN,
                        f"unreachable ({lic_str})",
                        fix="Check license server is running",
                    )
                )
            else:
                results.append(
                    CheckResult(
                        "License Server",
                        CheckResult.OK,
                        f"configured ({lic_str})",
                    )
                )
        except ImportError:
            results.append(
                CheckResult(
                    "License Server",
                    CheckResult.OK,
                    f"configured ({lic_str})",
                )
            )
    else:
        results.append(
            CheckResult(
                "License Server",
                CheckResult.WARN,
                "LM_LICENSE_FILE not set",
                fix=f"{_cli_name()} docker setup",
                fix_cmd=f"{_cli_name()} docker setup",
            )
        )

    return results


# ──────────────────────────────────────────────────────────────
# check_licensed_families  (order=31)
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Licensed Families", order=31)
def check_licensed_families():
    """Deep license check: query EDA tool for actually-licensed families.

    Goes beyond TCP reachability — invokes quartus_sh or vivado to enumerate
    which device families are licensed, then compares against project.yml.
    """
    results = []

    # Only meaningful when a vendor tool is available
    from sdk.api.tools import resolve_tool_binary

    if not (
        resolve_tool_binary("quartus_sh")
        or resolve_tool_binary("vivado")
        or resolve_tool_binary("libero")
    ):
        # No vendor tool on PATH — skip silently (doctor already checks this)
        return results

    with cli_resilient_block("licensed families query"):
        from sdk.cli.commands.license import (
            _query_licensed_families,
            _resolve_target_family,
        )

        vendor, families = _query_licensed_families()
        if vendor and not families:
            if vendor == "Microchip":
                results.append(
                    CheckResult(
                        "Licensed Families",
                        CheckResult.OK,
                        f"{vendor} (family querying skipped)",
                    )
                )
                return results

            results.append(
                CheckResult(
                    "Licensed Families",
                    CheckResult.WARN,
                    f"{vendor} found but returned no licensed families",
                    fix="Check LM_LICENSE_FILE and license server configuration.\n"
                    "       If device families are not installed, run: "
                    f"{_cli_name()} docker add-device quartus",
                )
            )
            return results

        if not vendor:
            return results

        target_family, target_part = _resolve_target_family()
        if not target_family:
            # No target family in project.yml — just report count
            results.append(
                CheckResult(
                    "Licensed Families",
                    CheckResult.OK,
                    f"{len(families)} families available via {vendor}",
                )
            )
            return results

        target_found = any(f.lower() == target_family.lower() for f in families)
        if target_found:
            results.append(
                CheckResult(
                    "Licensed Families",
                    CheckResult.OK,
                    f"{target_family} licensed ({len(families)} families via {vendor})",
                )
            )
        else:
            avail = ", ".join(families[:5])
            suffix = f" (+{len(families) - 5} more)" if len(families) > 5 else ""
            results.append(
                CheckResult(
                    "Licensed Families",
                    CheckResult.FAIL,
                    f"{target_family} NOT licensed — available: {avail}{suffix}",
                    fix=f"Obtain a {target_family} license, or retarget: "
                    f"{_cli_name()} config set hardware.family <licensed_family>",
                    fix_cmd=f"{_cli_name()} config set hardware.family <licensed_family>",
                )
            )

    return results


# ──────────────────────────────────────────────────────────────
# check_unisim  (order=67)  — Vendor simulation libraries
# ──────────────────────────────────────────────────────────────


@CheckRegistry.register("Unisim", order=67)
def check_unisim():
    """Check Xilinx unisim VHDL source availability.

    Reports:
      OK   — precompiled lib exists or VHDL sources are available
      WARN — sources not found; suggests ``rr eda install-unisim``
      OK   — (skip) non-Xilinx project or no project.yml
    """
    cli = _cli_name()

    # Only relevant for Xilinx projects
    cfg = _load_project_yml()
    if isinstance(cfg, dict):
        hw = cfg.get("hardware") or {}
        if isinstance(hw, dict):
            vendor = (hw.get("vendor") or "xilinx").lower()
            if vendor not in ("xilinx", "amd"):
                return CheckResult(
                    "Unisim",
                    CheckResult.OK,
                    f"not required (vendor: {vendor})",
                )

    # Check precompiled NVC or GHDL libs
    with cli_resilient_block("unisim precompiled check"):
        from routertl_core.sim.vendor_libraries import (
            _resolve_unisim_path,
            ghdl_unisim_available,
            nvc_unisim_available,
        )
        if nvc_unisim_available():
            return CheckResult("Unisim", CheckResult.OK, "NVC precompiled library available")
        if ghdl_unisim_available():
            return CheckResult("Unisim", CheckResult.OK, "GHDL precompiled library available")

        # Check VHDL source availability
        src = _resolve_unisim_path()
        if src:
            return CheckResult("Unisim", CheckResult.OK, f"VHDL sources available ({src})")

    return CheckResult(
        "Unisim",
        CheckResult.WARN,
        "VHDL sources not found — Xilinx simulations will fail",
        fix="Download unisim sources to ~/.routertl/vendor_libs/unisim/",
        fix_cmd=f"{cli} eda install-unisim",
    )
