# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import subprocess
import sys

import rich_click as click

from sdk.cli.console import console


@click.group(name="linux")
def linux_group():
    """Embedded Linux generation and build tools."""
    pass


def _run_make(target):
    """Helper to delegate targets to the Master Makefile"""
    cmd = ["make", target]
    try:
        # We don't capture output because we want the build progress
        # (which can take 10+ minutes for Buildroot) to stream natively.
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            console.print(f"\n❌ [red]Build failed for target '{target}'[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] 'make' not found. Ensure build-essential is installed.")
        sys.exit(1)


@linux_group.command(name="build")
def build_all():
    """Build the full Linux OS Image (U-Boot, Kernel, Rootfs)."""
    console.print("🐧 [blue]Starting full Embedded Linux build pipeline...[/]")
    _run_make("build-bsp")
    _run_make("build-dtb")
    _run_make("build-fsbl")
    _run_make("build-uboot")
    _run_make("build-kernel")
    _run_make("build-bootscr")
    _run_make("build-sdcard")


@linux_group.command(name="gen")
def gen_all():
    """Generate all software bindings (DTBO, C Headers, Python UIO)."""
    console.print("📝 [blue]Code-generating UIO Linux definitions from YAML...[/]")
    _run_make("gen-linux-all")


@linux_group.command(name="dtbo")
def gen_dtbo():
    """Generate Device Tree Overlay (.dts -> .dtbo)."""
    _run_make("gen-dtbo")


@linux_group.command(name="c-headers")
def gen_c_headers():
    """Generate purely C UIO headers."""
    _run_make("gen-uio-header")


@linux_group.command(name="python")
def gen_python():
    """Generate purely Python UIO drivers."""
    _run_make("gen-uio-bindings")


@linux_group.command(name="uboot")
def build_uboot():
    """Cross-compile U-Boot bootloader."""
    _run_make("build-uboot")


@linux_group.command(name="kernel")
def build_kernel():
    """Cross-compile the Linux Kernel."""
    _run_make("build-kernel")


@linux_group.command(name="bsp")
def build_bsp():
    """Generate Board Support Package (xparameters.h) via XSCT."""
    _run_make("build-bsp")


@linux_group.command(name="dtb")
def build_dtb():
    """Generate Base Device Tree (system.dtb) via XSCT & DTG."""
    _run_make("build-dtb")


@linux_group.command(name="sdcard")
def build_sdcard():
    """Assemble BOOT.bin and SD Card image."""
    _run_make("build-sdcard")


@linux_group.command(name="bootscr")
def build_bootscr():
    """Compile U-Boot boot script (boot.txt -> boot.scr)."""
    _run_make("build-bootscr")


@linux_group.command(name="crosscheck")
def crosscheck_hw():
    """Cross-check system_memory_map.yml against Vivado XSA hardware truth."""
    _run_make("crosscheck-hw")


@linux_group.command(name="fetch-sw")
def fetch_sw():
    """Fetch custom software repositories."""
    _run_make("fetch-sw")


@linux_group.command(name="mmap")
def update_mmap():
    """Update Vivado block design address map from system_memory_map.yml."""
    _run_make("update-mmap")
