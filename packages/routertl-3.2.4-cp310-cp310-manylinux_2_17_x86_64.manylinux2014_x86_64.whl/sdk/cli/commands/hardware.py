# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block

# RTL extensions that users might accidentally include in entity names
_RTL_EXTENSIONS = {".vhd", ".vhdl", ".sv", ".v"}


def _clean_top(top):
    """Strip 'TOP=' prefix, file extensions, and validate entity name.

    Rejects shell metacharacters, path traversal, and non-identifier names
    since the value is interpolated into Make variables and subprocess calls.
    """
    import re

    if top.startswith("TOP="):
        top = top[4:]
    # Strip RTL file extension if present (users type filenames naturally)
    p = Path(top)
    if p.suffix.lower() in _RTL_EXTENSIONS:
        clean = p.stem
        console.print(f"   [dim]ℹ️  Using entity name '{clean}' (stripped '{p.suffix}')[/]")
        top = clean

    # Reject path separators (directory traversal)
    if "/" in top or "\\" in top:
        console.print(f"❌ [red]Invalid module name '{top}' — must not contain path separators.[/]")
        sys.exit(1)

    # Only allow VHDL/Verilog identifiers: alphanumeric + underscore
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", top):
        console.print(
            f"❌ [red]Invalid module name '{top}' — only letters, digits, and underscores allowed.[/]"
        )
        sys.exit(1)

    # Sanity length check
    if len(top) > 128:
        console.print(f"❌ [red]Module name too long ({len(top)} chars, max 128).[/]")
        sys.exit(1)

    return top


def _run_make(target, *args):
    """Helper to delegate hardware targets to the Master Makefile.

    Reads ``hardware.tool_path`` from ``project.yml`` (if present) and
    prepends the tool's ``bin`` directory to ``PATH`` so that Make resolves
    the correct EDA binary regardless of system PATH ordering.
    """
    import os

    env = os.environ.copy()

    # Inject tool_path from project.yml so Quartus/Vivado/Radiant resolve correctly
    yml = Path("project.yml")
    if yml.exists():
        with cli_resilient_block("tool_path resolution"):
            import yaml

            with open(yml) as f:
                cfg = yaml.safe_load(f) or {}
            hw = cfg.get("hardware") or {}
            tool_path = hw.get("tool_path") if isinstance(hw, dict) else None
            if tool_path:
                tp = Path(tool_path)
                # Quartus: {tool_path}/quartus/bin
                # Vivado:  {tool_path}/bin
                # Radiant: {tool_path}/bin/lin64
                # Libero:  {tool_path}/Libero/bin
                for sub in ["quartus/bin", "bin", "bin/lin64", "Libero/bin"]:
                    candidate = tp / sub
                    if candidate.is_dir():
                        env["PATH"] = f"{candidate}:{env.get('PATH', '')}"
                        console.print(
                            f"   [dim]ℹ️  Using tool_path: {candidate}[/]"
                        )
                        break

    cmd = ["make", target, *args]
    try:
        result = subprocess.run(
            cmd, check=False, env=env, capture_output=True, text=True,
        )
        if result.returncode != 0:
            stderr = result.stderr or ""
            if "No rule to make target" in stderr:
                console.print(
                    f"\n\u274c [red]Build target '{target}' not available.[/]\n"
                    "   This project's Makefile is missing SDK targets.\n"
                    "   Possible fixes:\n"
                    "   \u2022 Run [cyan]rr init --repair[/] to regenerate the Makefile\n"
                    "   \u2022 Or run inside Docker: [cyan]rr docker shell[/]"
                )
                sys.exit(1)
            # Print captured output so the user still sees errors
            if isinstance(result.stdout, str) and result.stdout:
                sys.stdout.write(result.stdout)
            if isinstance(result.stderr, str) and result.stderr:
                sys.stderr.write(result.stderr)
            console.print(f"\n\u274c [red]Command failed (Make exit code: {result.returncode})[/]")
            sys.exit(result.returncode)
        else:
            if isinstance(result.stdout, str) and result.stdout:
                sys.stdout.write(result.stdout)
    except FileNotFoundError:
        console.print(
            "\u274c [red]'make' not found.[/]\n"
            "   Install build tools: [cyan]sudo apt install build-essential[/]"
        )
        sys.exit(1)


def _clean_build_artifacts(base_dir, module):
    """Remove cached build artifacts for a specific module."""
    import shutil

    artifact_dir = Path(base_dir) / module
    if artifact_dir.exists():
        shutil.rmtree(artifact_dir, ignore_errors=True)
        console.print(f"🗑️  [dim]Removed {artifact_dir}[/]")


@click.group(name="bitstream", invoke_without_command=True)
@click.pass_context
def bitstream_group(ctx):
    """Generate the FPGA Bitstream (Synthesis + Implementation).

    When invoked without a subcommand, runs the full bitstream flow.
    Use subcommands for finer control: run, clean, status, program.
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(bitstream_run)


@bitstream_group.command(name="run")
def bitstream_run():
    """Build the FPGA bitstream (default action)."""
    console.print("🔨 [blue]Starting bitstream generation...[/]")
    try:
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        dispatch = VendorDispatch.from_project()
        rc = dispatch.bitstream()
        if rc != 0:
            sys.exit(rc)
    except (ImportError, VendorToolNotFound):
        _run_make("bitstream")


@bitstream_group.command(name="clean")
def bitstream_clean():
    """Remove cached bitstream artifacts."""
    _clean_build_artifacts("project", "")
    console.print("🗑️  [dim]Bitstream artifacts cleaned.[/]")


@bitstream_group.command(name="status")
def bitstream_status():
    """Show the last bitstream generation result."""
    import os

    # Look for common bitstream output files
    for ext in ["*.sof", "*.pof", "*.bit", "*.bin", "*.jic"]:
        from glob import glob
        matches = glob(f"**/{ext}", recursive=True)
        if matches:
            for m in matches:
                size = os.path.getsize(m)
                mtime = os.path.getmtime(m)
                from datetime import datetime
                ts = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
                console.print(
                    f"  ✅ [cyan]{m}[/]  "
                    f"[dim]{size / 1024 / 1024:.1f} MB · {ts}[/]"
                )
    else:
        console.print("  [dim]No bitstream files found.[/]")


@bitstream_group.command(name="program")
def bitstream_program():
    """Flash the bitstream to the connected FPGA."""
    console.print("⚡ [blue]Programming FPGA...[/]")
    try:
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        dispatch = VendorDispatch.from_project()
        rc = dispatch.program()
        if rc != 0:
            sys.exit(rc)
    except (ImportError, VendorToolNotFound):
        _run_make("program")


@click.command(name="linting")
@click.argument("top", required=False)
@click.option("--clean", "-c", is_flag=True, help="Remove cached artifacts before linting.")
@click.option("--src", multiple=True, help="Source directories to lint (repeatable; default: from project.yml).")
def linting(top, clean, src):
    """Run the RouteRTL Smart Linter for a specific TOP module or all modules."""
    if clean:
        import shutil

        for cache_dir in [".routertl_cache", "work", "e~*"]:
            p = Path(cache_dir)
            if p.exists():
                shutil.rmtree(p, ignore_errors=True)
                console.print(f"🗑️  [dim]Removed {cache_dir}[/]")
        # Also remove GHDL entity directories (e~entity_name pattern)
        for p in Path(".").glob("e~*"):
            if p.is_dir():
                import shutil

                shutil.rmtree(p, ignore_errors=True)
                console.print(f"🗑️  [dim]Removed {p}[/]")

    def _resolve_xpm_from_project_yml() -> str:
        """Resolve XPM stub files from project.yml dependencies.

        Fallback for pip-installed consumers that have no ``build_env.mk``.
        Reads ``project.yml → dependencies``, looks for entries with
        ``library: xpm``, and returns the discovered VHDL file paths as
        a space-separated string suitable for ``--xpm``.
        """
        with cli_resilient_block("XPM auto-resolve from project.yml"):
            import yaml

            from sdk.engine.manage_dependencies import get_dependency_files

            with open("project.yml") as f:
                config = yaml.safe_load(f) or {}
            dep_files = get_dependency_files(config, str(Path.cwd()))
            xpm_list = dep_files.get("xpm", [])
            if xpm_list:
                return " ".join(xpm_list)
        return ""

    def _ensure_unisim_precompiled() -> None:
        """Auto-compile unisim for GHDL if needed.

        Uses the 5-tier resolution cascade from ``vendor_libraries``:
          Tier 1: Already precompiled → skip
          Tier 2: Vivado installed → compile from Vivado sources
          Tier 3: Cached sources → compile from cache
          Tier 4: Download from mirror → cache + compile
          Tier 5: Nothing works → actionable warning

        The smart linter's own vendor-library detection (lines 639-652 in
        ``smart_linter.py``) discovers precompiled GHDL libs and adds ``-P``
        flags automatically.  This function just ensures compilation happens
        *before* the linter runs.
        """
        with cli_resilient_block("unisim auto-precompile"):
            from routertl_core.sim.vendor_libraries import (
                ensure_ghdl_unisim,
                ghdl_unisim_available,
            )

            if ghdl_unisim_available():
                return

            console.print("   [dim]ℹ️  Auto-compiling unisim for GHDL...[/]")
            if ensure_ghdl_unisim(verbose=False):
                console.print("   [dim]✅ Unisim precompiled successfully[/]")
                return

            console.print(
                "   [yellow]⚠️  Unisim not available — files using "
                "'library unisim;' may fail.[/]\n"
                "   [dim]Fix: [cyan]rr eda install-unisim --compile[/][/]"
            )


    # Try direct invocation first
    from sdk.cli.env_setup import resolve_sdk_script, resolve_src_dirs

    script = resolve_sdk_script("project-manager/smart_linter.py")
    if script:
        # Check GHDL availability upfront to avoid cryptic linting.sh failures
        import shutil as _shutil
        if not _shutil.which("ghdl"):
            console.print(
                "\u274c [red]GHDL not found.[/]\n"
                "   The linter needs GHDL for VHDL pre-compilation.\n"
                "   Install: [cyan]sudo apt install ghdl[/]  or  [cyan]rr docker shell[/]"
            )
            sys.exit(1)

        src_dirs = list(src) if src else resolve_src_dirs()
        if top:
            top = _clean_top(top)
            console.print(f"📐 [blue]Linting module: [cyan]{top}[/]")
        else:
            console.print("📐 [blue]Running full project linting...[/]")

        cmd = [sys.executable, str(script), "--root", str(Path.cwd()), "--src"] + src_dirs
        if top:
            cmd.extend(["--top", top])

        # Pass pkg/xpm/utils from build_env.mk if available,
        # otherwise fall back to resolving from project.yml directly.
        if Path("build_env.mk").exists():
            with open("build_env.mk") as f:
                for line in f:
                    s = line.strip()
                    if s.startswith("PKG_FILES"):
                        parts = (s.split("?=") if "?=" in s else s.split("="))
                        if len(parts) == 2 and parts[1].strip():
                            cmd.extend(["--pkgs", parts[1].strip()])
                    elif s.startswith("XPM_FILES"):
                        parts = (s.split("?=") if "?=" in s else s.split("="))
                        if len(parts) == 2 and parts[1].strip():
                            cmd.extend(["--xpm", parts[1].strip()])
                    elif s.startswith("UTILS_FILES"):
                        parts = (s.split("?=") if "?=" in s else s.split("="))
                        if len(parts) == 2 and parts[1].strip():
                            cmd.extend(["--utils", parts[1].strip()])
        elif Path("project.yml").exists():
            # Fallback: resolve XPM/pkg directly from project.yml
            # (pip consumers without build_env.mk)
            xpm_files = _resolve_xpm_from_project_yml()
            if xpm_files:
                cmd.extend(["--xpm", xpm_files])

        # Auto-compile unisim for GHDL (P1.50) — trigger the cascade
        # before the smart linter runs.  The linter's own vendor-library
        # detection (smart_linter.py lines 639-652) adds -P flags for
        # any precompiled GHDL vendor libraries it finds.
        _ensure_unisim_precompiled()

        try:
            result = subprocess.run(cmd, check=False)
            if result.returncode != 0:
                console.print(f"\n❌ [red]Linting failed (exit code: {result.returncode})[/]")
                sys.exit(result.returncode)
        except FileNotFoundError:
            console.print("❌ [red]Error:[/] Python interpreter not found.")
            sys.exit(1)
    else:
        if top:
            top = _clean_top(top)
            console.print(f"📐 [blue]Linting module: [cyan]{top}[/]")
            _run_make("linting", f"TOP={top}")
        else:
            console.print("📐 [blue]Running full project linting...[/]")
            _run_make("linting")


@click.command(name="hierarchy")
@click.argument("top", required=False, default=None)
@click.option("--all", "-a", "show_all", is_flag=True, help="Include submodules (not just top-level trees).")
def hierarchy(top, show_all):
    """View the design hierarchy for a given TOP module.

    When called without a TOP argument, lists all available modules.
    Use --all to include submodules shadowed by top-level modules.
    """
    if top is None:
        _list_synthesis_targets(show_all=show_all)
        return
    top = _clean_top(top)
    console.print(f"🌳 [blue]Extracting hierarchy for: [cyan]{top}[/]")

    from sdk.cli.engine_dispatch import ScriptNotFound, run_engine_script
    from sdk.cli.env_setup import resolve_src_dirs

    src_dirs = resolve_src_dirs()
    try:
        result = run_engine_script(
            "dependency_resolver.py",
            ["--src"] + src_dirs + ["--top", top],
        )
        if result.returncode != 0:
            sys.exit(result.returncode)
    except ScriptNotFound:
        _run_make("hierarchy", f"TOP={top}")


@click.group(name="project", invoke_without_command=True)
@click.pass_context
def project_group(ctx):
    """FPGA Project Management.

    When invoked without a subcommand, generates the project.
    Use 'clean' to remove all FPGA project artifacts.
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(project_run)


@project_group.command(name="run")
def project_run():
    """Generate FPGA Project (default action)."""
    console.print("📁 [blue]Generating FPGA Project...[/]")
    try:
        from sdk.cli.engine_dispatch import check_lfs_guards, run_engine_script
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        # Pre-build steps (mirrors the Make prerequisite chain)
        # 1) update-config
        run_engine_script("project_manager.py", ["project.yml"])
        # 2) check-lfs
        if not check_lfs_guards():
            sys.exit(1)
        # 3) pre-build hooks
        with cli_resilient_block("pre-build hooks"):
            run_engine_script("run_prebuild_hooks.py", ["--project", "project.yml", "--root", "."])
        # 4) vendor project generation
        dispatch = VendorDispatch.from_project()
        rc = dispatch.project()
        if rc != 0:
            sys.exit(rc)
    except (ImportError, VendorToolNotFound):
        _run_make("project")


@project_group.command(name="clean")
def project_clean():
    """Remove ALL FPGA project artifacts.

    Cleans vendor-generated project files, databases, reports,
    build caches, AND generated outputs from project.yml hooks.
    """
    import shutil

    # Directories to remove
    dirs_to_clean = [
        "project",           # generated project workspace
        "db",                # Quartus compilation database
        "incremental_db",    # Quartus incremental compilation
        "dcp",               # NPM synthesis design checkpoints
        "output_files",      # Quartus output directory
        ".Xil",              # Vivado temp files
    ]

    # File glob patterns to clean
    file_patterns = [
        # Quartus
        "*.qpf", "*.qsf", "*.qws", "*.bak", "*.smsg",
        "*.rpt", "*.summary", "*.pin", "*.done", "*.jdi",
        "*.sld", "*.sldq", "*.slds", "*.sof", "*.pof", "*.jic",
        # Vivado
        "*.xpr", "*.bit", "*.ltx", "*.dcp",
        # Lattice
        "*.rdf",
        # Common reports
        "*.sta.rpt", "*.fit.rpt", "*.map.rpt",
    ]

    cleaned = 0

    for d in dirs_to_clean:
        p = Path(d)
        if p.exists() and p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
            console.print(f"  🗑️  [dim]Removed {d}/[/]")
            cleaned += 1

    from glob import glob
    for pattern in file_patterns:
        for match in glob(pattern):
            Path(match).unlink(missing_ok=True)
            console.print(f"  🗑️  [dim]Removed {match}[/]")
            cleaned += 1

    # ── Clean hook-generated outputs from project.yml ──
    # Hooks define expected_outputs (e.g., generated IP wrappers, VHDL
    # packages). Clean those too, matching run_prebuild_hooks.py behavior.
    root_dir = Path.cwd().resolve()
    with cli_resilient_block("hook output cleanup"):
        import yaml

        yml = Path("project.yml")
        if yml.exists():
            with open(yml) as f:
                config = yaml.safe_load(f) or {}
            hooks = config.get("hooks", {}).get("pre_build", [])
            for hook in hooks:
                hook_name = hook.get("name", "unnamed")
                for output in hook.get("expected_outputs", []):
                    output_path = (root_dir / output).resolve()
                    # Safety: never delete outside project root
                    if not output_path.is_relative_to(root_dir):
                        continue
                    if output_path.exists():
                        output_path.unlink()
                        console.print(
                            f"  🗑️  [dim]Hook '{hook_name}': {output}[/]"
                        )
                        cleaned += 1
                    # Also clean parent dir if it's now empty
                    parent = output_path.parent
                    if (parent.exists()
                            and parent != root_dir
                            and not any(parent.iterdir())):
                        parent.rmdir()
                        console.print(
                            f"  🗑️  [dim]Removed empty {parent.relative_to(root_dir)}/[/]"
                        )

    if cleaned == 0:
        console.print("  [dim]No FPGA project artifacts found.[/]")
    else:
        console.print(f"\n  ✅ Cleaned {cleaned} artifact(s).")



@click.command(name="npm-synthesis", deprecated=True, hidden=True)
@click.argument("top", required=False, default=None)
@click.option("--list", "-l", "list_targets", is_flag=True, help="List available synthesis targets.")
@click.option("--all", "-a", "show_all", is_flag=True, help="Include submodules (not just top-level trees).")
@click.option("--clean", "-c", is_flag=True, help="Remove cached NPM artifacts before synthesis.")
@click.pass_context
def npm_synthesis(ctx, top, list_targets, show_all, clean):
    """[Deprecated] Use 'rr synth run <module>' instead."""
    console.print(
        "⚠️  [yellow]npm-synthesis is deprecated. "
        "Use '[cyan]rr synth run <module>[yellow]' instead.[/]\n"
    )
    if list_targets or top is None:
        _list_synthesis_targets(show_all=show_all)
        return
    # Delegate to synth_run so the SynthTracker records the result
    from sdk.cli.commands.synth import synth_run

    ctx.invoke(synth_run, module=top, clean=clean)


@click.command(name="synth-targets", deprecated=True, hidden=True)
@click.option("--all", "-a", "show_all", is_flag=True, help="Include submodules (not just top-level trees).")
def synth_targets(show_all):
    """List available synthesis targets discovered from the source tree."""
    console.print(
        "⚠️  [yellow]synth-targets is deprecated. "
        "Use '[cyan]rr synth list[yellow]' instead.[/]\n"
    )
    _list_synthesis_targets(show_all=show_all)


def _list_synthesis_targets(show_all=False):
    """Discover and display available synthesis targets from the source tree."""
    import json
    import os

    # Resolve SRC_DIR from build_env.mk or default to 'src'
    src_dir = "src"
    if os.path.exists("build_env.mk"):
        with open("build_env.mk") as f:
            for line in f:
                if line.strip().startswith("SRC_DIR"):
                    parts = line.split("?=") if "?=" in line else line.split("=")
                    if len(parts) == 2:
                        src_dir = parts[1].strip()
                        break

    # Locate dependency resolver
    this_dir = Path(__file__).resolve().parent
    tools_dir = this_dir.parent.parent  # sdk/cli/commands -> sdk
    resolver_path = tools_dir / "engine" / "dependency_resolver.py"

    if not resolver_path.exists():
        console.print("❌ [red]Could not find dependency_resolver.py[/]")
        return

    # Resolve CLI name for command suggestions
    CLI_NAME = "routertl"
    with cli_resilient_block("CLI name resolution"):
        from sdk.cli.main import CLI_NAME

    if show_all:
        # Import resolver directly to get ALL entities (including submodules)

        from sdk.engine.dependency_resolver import DependencyResolver

        resolver = DependencyResolver([Path(src_dir)], verbose=False)
        forest = resolver.resolve_forest()
        top_names = {t["top"] for t in (forest.get("trees") or [])}
        all_names = sorted(resolver.entity_map.keys())

        console.print(f"\n🎯 [cyan]All Synthesizable Modules[/] ({len(all_names)} in '{src_dir}'):\n")
        for name in all_names:
            is_top = name in top_names
            bullet = "[green]•" if is_top else "[dim]◦"
            label = f"[cyan]{name}" if is_top else f"[dim]{name}"
            tag = "" if is_top else "  [dim](submodule)[/]"
            console.print(f"  {bullet}[/] {label}[/]{tag}")

        console.print("\n  [green]•[/] = top-level   [dim]◦ = submodule[/]")
    else:
        # Default: show only top-level trees
        try:
            result = subprocess.run(
                ["python3", str(resolver_path), "--src", src_dir, "--forest"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                console.print(f"❌ [red]Dependency resolver failed:[/] {result.stderr.strip()}")
                return

            data = json.loads(result.stdout)
            trees = data.get("trees") or []
        except (OSError, json.JSONDecodeError, subprocess.SubprocessError) as e:
            import logging
            import traceback as _tb

            logging.debug("Target discovery failed:\n%s", _tb.format_exc())
            console.print(f"❌ [red]Error discovering targets:[/] {e}")
            return

        if not trees:
            console.print(f"⚠️  [yellow]No synthesis targets found in '{src_dir}'.[/]")
            return

        console.print(
            f"\n🎯 [cyan]Available Synthesis Targets[/] ({len(trees)} top-level modules in '{src_dir}'):\n"
        )
        for tree in sorted(trees, key=lambda t: t["top"]):
            name = tree["top"]
            dep_count = tree.get("weight") or len(tree.get("files") or [])
            deps_label = f"({dep_count} file{'s' if dep_count != 1 else ''})" if dep_count else ""
            console.print(
                f"  [green]•[/] [cyan]{name:<30}[/] [dim]{deps_label}[/]"
            )

        console.print("\n  [dim]Use --all to include submodules[/]")

    console.print("\n[dim]Usage:[/]")
    click.echo(f"  {CLI_NAME} synth run <module>")
    click.echo(f"  {CLI_NAME} linting <module>")
    click.echo(f"  {CLI_NAME} hierarchy <module>")
    click.echo()


@click.group(name="implementation", invoke_without_command=True)
@click.pass_context
def impl_group(ctx):
    """Run Project Mode Implementation (Place & Route).

    When invoked without a subcommand, runs implementation.
    Use subcommands for finer control: run, clean, status.
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(impl_run)


@impl_group.command(name="run")
def impl_run():
    """Run implementation (default action)."""
    console.print("🔨 [blue]Starting Implementation...[/]")
    try:
        from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

        dispatch = VendorDispatch.from_project()
        rc = dispatch.implementation()
        if rc != 0:
            sys.exit(rc)
    except (ImportError, VendorToolNotFound):
        _run_make("implementation")


@impl_group.command(name="clean")
def impl_clean():
    """Remove cached implementation artifacts."""
    _clean_build_artifacts("project", "")
    console.print("🗑️  [dim]Implementation artifacts cleaned.[/]")


@impl_group.command(name="status")
def impl_status():
    """Show the last implementation result."""
    import os

    # Look for common implementation output files
    for ext in ["*.fit.summary", "*.map.summary", "*.sta.summary",
                "*.route_design.pb", "*_routed.dcp"]:
        from glob import glob
        matches = glob(f"**/{ext}", recursive=True)
        for m in matches:
            size = os.path.getsize(m)
            mtime = os.path.getmtime(m)
            from datetime import datetime
            ts = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
            console.print(
                f"  ✅ [cyan]{m}[/]  "
                f"[dim]{size / 1024:.0f} KB · {ts}[/]"
            )
    console.print("  [dim]Check project/ directory for full reports.[/]")


@click.command(name="schematic")
@click.argument("top", required=True)
@click.option(
    "--skin", "-s", default=None,
    help="Beautifier CSS skin (e.g. cyberpunk, classic). Default: cyberpunk.",
)
def schematic(top, skin):
    """Generate an SVG schematic from RTL for a specific TOP module."""
    import os

    top = _clean_top(top)
    console.print(f"🖼️ [blue]Generating schematic for [cyan]{top}[/]...")

    # Resolve source directories from build_env.mk or fall back to 'src'
    src_dirs = ["src"]
    if os.path.exists("build_env.mk"):
        with open("build_env.mk") as f:
            for line in f:
                if line.strip().startswith("SRC_DIR"):
                    parts = line.split("?=") if "?=" in line else line.split("=")
                    if len(parts) == 2:
                        src_dirs = parts[1].strip().split()
                        break

    # Locate gen_schematic.py relative to this CLI file
    this_dir = Path(__file__).resolve().parent
    tools_dir = this_dir.parent.parent  # sdk/cli/commands -> sdk
    script = tools_dir / "engine" / "gen_schematic.py"

    if not script.exists():
        console.print(f"❌ [red]Could not find gen_schematic.py at {script}[/]")
        sys.exit(1)

    cmd = ["python3", str(script), "--top", top, "--out", "sim/schematics", "--src"] + src_dirs
    if skin:
        cmd.extend(["--skin", skin])

    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            console.print("\n❌ [red]Schematic generation failed.[/]")
            sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("❌ [red]Error:[/] 'python3' not found.")
        sys.exit(1)

