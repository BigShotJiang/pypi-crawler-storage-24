# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command: info — Unified entity information view."""

import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient, cli_resilient_block

# Badge icons for lint (🔍) and synth (🔨) status
_STATUS_ICONS = {
    "PASS": "✅",
    "WARN": "⚠️ ",
    "FAIL": "❌",
    "STALE": "🕐",
    "UNKNOWN": "—",
}


def _load_trackers():
    """Lazily load LintTracker + SynthTracker from project root."""
    lint_t = None
    with cli_resilient_block("LintTracker loading"):
        from sdk.engine.lint_tracker import LintTracker
        lint_t = LintTracker()
    synth_t = None
    with cli_resilient_block("SynthTracker loading"):
        from sdk.engine.synth_tracker import SynthTracker
        synth_t = SynthTracker()
    return lint_t, synth_t


def _get_badges(entity, resolver, lint_tracker, synth_tracker):
    """Return compact badge string for an entity, e.g. ``🔍✅ 🔨—``.

    Returns empty string if both statuses are UNKNOWN.
    """
    # Resolve source files for staleness check
    src_files = []
    src = resolver.entity_map.get(entity)
    if src:
        src_files = [str(src)]

    # Lint status
    if lint_tracker:
        lint_status = lint_tracker.staleness_check(entity, src_files)
    else:
        lint_status = "UNKNOWN"

    # Synth status
    if synth_tracker:
        synth_status = synth_tracker.staleness_check(entity, src_files)
    else:
        synth_status = "UNKNOWN"

    if lint_status == "UNKNOWN" and synth_status == "UNKNOWN":
        return ""

    lint_icon = _STATUS_ICONS.get(lint_status, "—")
    synth_icon = _STATUS_ICONS.get(synth_status, "—")
    return f" [dim]🔍{lint_icon} 🔨{synth_icon}[/]"


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


def _render_tree(node, graph, pkg_set, resolver, prefix="     ",
                 depth=0, max_depth=None, max_children=None, visited=None,
                 lint_tracker=None, synth_tracker=None):
    """Recursively render a hierarchy tree with box-drawing characters.

    Parameters
    ----------
    node : str
        Current entity/module name.
    graph : dict
        Adjacency list: parent → list of children.
    pkg_set : set
        Set of known package names (rendered dimmed, grouped at end).
    resolver : DependencyResolver
        Used for library tag resolution.
    prefix : str
        Box-drawing prefix for current indentation level.
    depth : int
        Current recursion depth (0 = root).
    max_depth : int or None
        Maximum recursion depth (None = unlimited).
    max_children : int or None
        Maximum children to show per node (None = unlimited).
    visited : set or None
        Cycle guard — tracks visited nodes.
    lint_tracker : LintTracker or None
        For lint status badges.
    synth_tracker : SynthTracker or None
        For synth status badges.
    """
    if visited is None:
        visited = set()

    children = graph.get(node, [])
    if not children:
        return

    # Separate entity children from package children
    entity_children = sorted([c for c in children if c not in pkg_set])
    pkg_children = sorted([c for c in children if c in pkg_set])

    # Truncation
    if max_depth is not None and depth >= max_depth:
        total = len(entity_children) + len(pkg_children)
        if total > 0:
            console.print(f"{prefix}[dim]... {total} sub-nodes (use --full)[/]")
        return

    limit = max_children if max_children is not None else len(entity_children)
    shown = entity_children[:limit]
    remaining = len(entity_children) - limit

    for idx, child in enumerate(shown):
        is_last_entity = (idx == len(shown) - 1) and (remaining <= 0) and not pkg_children
        connector = "└── " if is_last_entity else "├── "
        extension = "    " if is_last_entity else "│   "

        # Library tag
        child_path = resolver.entity_map.get(child)
        lib_tag = ""
        if child_path:
            lib = resolver._resolve_file_library(child_path)
            if lib != "work":
                lib_tag = f" [dim][[blue]{lib}[/][dim]][/]"

        # Status badges
        badges = _get_badges(child, resolver, lint_tracker, synth_tracker)

        console.print(f"{prefix}[green]{connector}[/][white]{child}[/]{lib_tag}{badges}")

        if child not in visited:
            visited.add(child)
            _render_tree(child, graph, pkg_set, resolver, prefix=prefix + extension,
                         depth=depth + 1, max_depth=max_depth, max_children=max_children,
                         visited=visited, lint_tracker=lint_tracker, synth_tracker=synth_tracker)

    if remaining > 0:
        connector = "└── " if not pkg_children else "├── "
        console.print(f"{prefix}[dim]{connector}... and {remaining} more entities[/]")

    # Grouped package summary
    if pkg_children:
        pkg_limit = max_children if max_children is not None else len(pkg_children)
        shown_pkgs = pkg_children[:pkg_limit]
        pkg_names = ", ".join(shown_pkgs)
        extra = f", +{len(pkg_children) - pkg_limit}" if len(pkg_children) > pkg_limit else ""
        console.print(f"{prefix}[dim]└── 📦 [{len(pkg_children)} pkgs: {pkg_names}{extra}][/]")


@click.command(name="info")
@click.argument("entity", required=False, default=None)
@click.option("--src", "src_dir", default=None, help="Source directory (default: from project.yml or 'src').")
@click.option("--forest", "show_forest", is_flag=True, help="Show full project hierarchy (all top-level roots).")
@click.option("--full", "show_full", is_flag=True, help="Show all nodes (no truncation).")
@click.option("--flat", "show_flat", is_flag=True, help="Flat file list instead of nested tree.")
@click.option("--discover-libs", "show_libs", is_flag=True, help="Auto-discover VHDL library memberships from source.")
def info_command(entity, src_dir, show_forest, show_full, show_flat, show_libs):
    """Show detailed information about an RTL entity or module.

    When called with an ENTITY argument, shows dependencies, ports, tests,
    and reverse dependents for that entity.

    When called with --forest, shows all top-level hierarchies as nested
    instantiation trees (default) or flat file lists (--flat).
    When called with --discover-libs, shows auto-discovered library memberships.

    \\b
    Examples:
        routertl info frame_drop
        routertl info --forest
        routertl info --forest --full
        routertl info --forest --flat
        routertl info --discover-libs
    """
    import yaml

    # Validate: entity required unless --forest or --discover-libs
    if not entity and not show_forest and not show_libs:
        click.echo(click.get_current_context().get_help())
        console.print(
            "\n[yellow]Hint:[/] provide an entity name, "
            "or use [cyan]--forest[/] / [cyan]--discover-libs[/].\n"
        )
        sys.exit(1)

    # Strip file extension if provided
    if entity and Path(entity).suffix.lower() in {".vhd", ".vhdl", ".sv", ".v"}:
        entity = Path(entity).stem

    # ── Resolve source directories ──
    if not src_dir:
        yml_path = Path("project.yml")
        if yml_path.exists():
            with cli_resilient_block("project.yml source dir parsing"):
                with open(yml_path) as f:
                    config = yaml.safe_load(f) or {}
                paths_cfg = config.get("paths", {})
                src_raw = paths_cfg.get("sources", "src")
                if isinstance(src_raw, list):
                    src_dirs = [Path(d) for d in src_raw]
                else:
                    src_dirs = [Path(src_raw)]
        else:
            console.print("❌ [red]No project.yml found.[/]")
            sys.exit(1)
    else:
        src_dirs = [Path(src_dir)]

    existing = [d for d in src_dirs if d.exists()]
    if not existing:
        console.print("⚠️  [yellow]No source directories found.[/]")
        sys.exit(1)

    # ── Load dependency resolver ──
    try:
        from sdk.engine.dependency_resolver import DependencyResolver
    except ImportError:
        from routertl_core.dependency_resolver import DependencyResolver

    resolver = DependencyResolver(existing, verbose=False)

    # ── Forest mode ──
    if show_forest:
        forest = resolver.resolve_forest()
        trees = forest.get("trees", [])
        orphans = forest.get("orphans", [])
        graph = forest.get("graph", {})

        console.print(f"\n🌲 [cyan]Project Forest[/] — {len(trees)} hierarchy(ies)\n")

        if show_flat:
            # Legacy flat rendering
            for i, tree in enumerate(trees, 1):
                top = tree["top"]
                weight = tree["weight"]
                src_path = Path(tree["path"]).name
                console.print(f"  [green]{i}.[/] [white]{top}[/]"
                            f"  [dim]({src_path}, {weight} files)[/]")
                files = tree.get("files", [])
                limit = len(files) if show_full else 5
                for dep_path in files[:limit]:
                    dep_name = Path(dep_path).stem
                    lib = resolver._resolve_file_library(Path(dep_path))
                    lib_tag = f" [[blue]{lib}[/]]" if lib != "work" else ""
                    console.print(f"      [green]↳[/] {dep_name}{lib_tag}")
                if len(files) > limit:
                    console.print(f"      [dim]... and {len(files) - limit} more[/]")
        else:
            # Tree rendering (default)
            max_depth = None if show_full else 4
            max_children = None if show_full else 5
            pkg_set = set(resolver.package_map.keys())

            # Load status trackers for badges
            lint_tracker, synth_tracker = _load_trackers()

            for i, tree in enumerate(trees, 1):
                top = tree["top"]
                weight = tree["weight"]
                src_path = Path(tree["path"]).name
                badges = _get_badges(top, resolver, lint_tracker, synth_tracker)
                console.print(f"  [green]{i}.[/] [white]{top}[/]"
                            f"  [dim]({src_path}, {weight} files)[/]{badges}")
                _render_tree(top, graph, pkg_set, resolver, prefix="     ",
                             max_depth=max_depth, max_children=max_children,
                             lint_tracker=lint_tracker, synth_tracker=synth_tracker)

        if orphans:
            limit = len(orphans) if show_full else 5
            console.print(f"\n  [yellow]⚠ Orphans:[/] {len(orphans)} file(s) not in any hierarchy")
            for o in orphans[:limit]:
                console.print(f"      [dim]{Path(o).stem}[/]")
            if len(orphans) > limit:
                console.print(f"      [dim]... and {len(orphans) - limit} more[/]")

        click.echo()
        return

    # ── Discover-libs mode ──
    if show_libs:
        libs = resolver.discover_libraries()

        if not libs:
            console.print("\n[dim]No custom VHDL libraries detected in source.[/]\n")
            return

        console.print("\n📚 [cyan]Auto-Discovered Libraries[/]\n")
        for lib_name, files in sorted(libs.items()):
            console.print(f"  [white]{lib_name}[/] ({len(files)} files)")
            for f in sorted(files):
                rel = Path(f).name
                console.print(f"      [green]↳[/] {rel}")

        console.print("\n  [dim]Output as JSON:[/]")
        console.print("  [dim]rr info --discover-libs | python3 -m json.tool[/]\n")
        return

    # ── Single entity mode (original behavior) ──

    # ── Check entity exists ──
    if entity not in resolver.entity_map and entity not in resolver.package_map:
        console.print(f"❌ [red]Entity '{entity}' not found in source tree.[/]")
        console.print(
            f"   [dim]Available: {', '.join(sorted(list(resolver.entity_map.keys())[:10]))}...[/]"
        )
        sys.exit(1)

    # ── Header ──
    console.print(f"\n📋 [cyan]Entity: [white]{entity}[/]")
    click.echo("=" * 50)

    # ── Source file ──
    src_file = resolver.entity_map.get(entity) or resolver.package_map.get(entity)
    if src_file:
        console.print(f"\n   📄 [blue]Source:[/] {src_file}")

        # Show port info from file if VHDL
        src_path = Path(src_file)
        if src_path.exists() and src_path.suffix.lower() in {".vhd", ".vhdl"}:
            import re

            content = src_path.read_text()
            # Count ports
            port_matches = re.findall(r"^\s*(\w+)\s*:\s*(in|out|inout)\s+", content, re.MULTILINE | re.IGNORECASE)
            if port_matches:
                in_count = sum(1 for _, d in port_matches if d.lower() == "in")
                out_count = sum(1 for _, d in port_matches if d.lower() == "out")
                inout_count = sum(1 for _, d in port_matches if d.lower() == "inout")
                parts = []
                if in_count:
                    parts.append(f"{in_count} in")
                if out_count:
                    parts.append(f"{out_count} out")
                if inout_count:
                    parts.append(f"{inout_count} inout")
                console.print(f"   🔌 [blue]Ports:[/] {', '.join(parts)}")

    # ── Dependencies ──
    console.print("\n   🌳 [blue]Dependencies:[/]")
    deps = resolver.resolve_dependencies(entity)
    if deps:
        for dep in deps:
            console.print(f"      [green]↳[/] {Path(dep).stem}")
    else:
        console.print("      [dim](none — leaf entity)[/]")

    # ── Reverse dependents (who uses this entity?) ──
    with cli_resilient_block("reverse dependency lookup"):
        rev_deps = resolver.reverse_dependents(entity)
        console.print("\n   🔄 [blue]Used by:[/]")
        if rev_deps:
            for rd in sorted(rev_deps):
                console.print(f"      [yellow]↳[/] {rd}")
        else:
            console.print("      [dim](top-level — nothing depends on this)[/]")

    # ── Related tests ──
    console.print("\n   🧪 [blue]Related tests:[/]")
    with cli_resilient_block("test discovery"):
        from sdk.cli.commands.diff import _find_affected_tests

        tests = _find_affected_tests([src_file] if src_file else [], resolver)
        if tests:
            for t in sorted(tests):
                console.print(f"      [magenta]↳[/] {t}")
        else:
            console.print("      [dim](no tests reference this entity)[/]")

    click.echo()

