# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Docker setup wizard — interactive .env configuration."""

import rich_click as click

from sdk.cli.commands.docker import docker_group
from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient_block

# Per-tool mapping: which .env variables each EDA tool needs
_SETUP_TOOL_VARS = {
    "quartus": {"QUARTUS_LICENSE", "QUARTUS_INSTALLER_PATH", "EDA_INSTALL_DIR", "EDA_MAC_ADDRESS_OVERRIDE"},
    "vivado": {"VIVADO_INSTALLER_PATH", "EDA_INSTALL_DIR"},
    "riviera": {"ALDEC_LICENSE", "EDA_INSTALL_DIR", "EDA_MAC_ADDRESS_OVERRIDE"},
    "questa": {"ALDEC_LICENSE", "EDA_INSTALL_DIR", "EDA_MAC_ADDRESS_OVERRIDE"},
    "radiant": {"EDA_INSTALL_DIR"},
    "libero": {"EDA_INSTALL_DIR", "EDA_MAC_ADDRESS_OVERRIDE"},
}


@docker_group.command(name="setup")
@click.option(
    "--target", "target",
    type=click.Choice(sorted(_SETUP_TOOL_VARS.keys()), case_sensitive=False),
    default=None,
    help="Configure only the settings needed for a specific tool.",
)
def docker_setup(target):
    """Interactive wizard to configure license and environment variables.

    \\b
    Walks through the settings that Docker EDA containers need and writes
    them to a `.env` file in the project root.  Docker Compose reads this
    file automatically so the values are available inside every container.

    \\b
    Use --target to configure only the prompts relevant to one tool:
      rr docker setup --target quartus
      rr docker setup --target vivado

    \\b
    Variables configured:
      QUARTUS_LICENSE          Intel/Quartus FlexLM license server
      ALDEC_LICENSE            Siemens/Aldec FlexLM license server
      QUARTUS_INSTALLER_PATH   Directory containing Quartus installer files
      VIVADO_INSTALLER_PATH    Directory containing Vivado installer files
      EDA_INSTALL_DIR          Base path for EDA tool installations (optional)
      EDA_MAC_ADDRESS_OVERRIDE Node-locked license MAC — when set,
                               automatically switches containers from
                               host networking to bridge + MAC spoofing
    """
    import re
    from pathlib import Path

    env_path = Path(".env")

    # Determine which keys to prompt for
    if target:
        active_keys = _SETUP_TOOL_VARS[target.lower()]
        tool_label = target.capitalize()
    else:
        active_keys = None  # None = all keys
        tool_label = None

    def _should_prompt(key):
        return active_keys is None or key in active_keys

    if tool_label:
        console.print(f"\n🐳 [cyan]RouteRTL Docker Setup — {tool_label}[/]")
    else:
        console.print("\n🐳 [cyan]RouteRTL Docker Environment Setup[/]")
    console.print("   [dim]This wizard configures .env for Docker EDA containers.[/]\n")

    # ── Read existing .env ──
    env_lines = []
    env_vars = {}
    if env_path.exists():
        with cli_resilient_block(".env configuration reading"):
            raw = env_path.read_text()
            env_lines = raw.splitlines()
            for line in env_lines:
                stripped = line.strip()
                if stripped and not stripped.startswith("#") and "=" in stripped:
                    k, v = stripped.split("=", 1)
                    env_vars[k.strip()] = v.strip()

    # ── Helper: prompt with default from existing .env ──
    _KEEP = object()  # sentinel: user pressed Enter, keep existing value

    def _prompt(label, key, hint="", example=""):
        current = env_vars.get(key)
        if current:
            console.print(f"  [dim]Current: [green]{current}[/]")
            console.print("  [dim](press Enter to keep, type 'none' to clear)[/]")
        if example:
            console.print(f"  [dim](e.g. {example})[/]")

        default = current or ""
        value = click.prompt(
            f"  {label}",
            default=default,
            show_default=bool(default),
        ).strip().strip('"').strip("'")

        # User pressed Enter without typing anything
        if value == (current or ""):
            if current:
                return _KEEP  # existing value unchanged
            return None       # no value, nothing entered

        # User explicitly cleared a value
        if value.lower() in ("none", "clear"):
            return None
        return value

    # ── Intel/Quartus License ──
    quartus_license = None
    if _should_prompt("QUARTUS_LICENSE"):
        console.print("  [cyan]1. Intel/Quartus License Server[/]")
        console.print("     [dim]FlexLM daemon for Quartus (vendor daemon: alterad).[/]")
        console.print("     [dim]Use port@host format.[/]")
        quartus_license = _prompt(
            "QUARTUS_LICENSE",
            "QUARTUS_LICENSE",
            example="27000@lic-server.company.com",
        )
        click.echo()

    # ── Aldec/Riviera License ──
    aldec_license = None
    if _should_prompt("ALDEC_LICENSE"):
        console.print("  [cyan]2. Aldec License Server (Riviera-PRO / Questa IFPGA)[/]")
        console.print("     [dim]FlexLM daemon for Aldec tools (vendor daemon: ALDEC).[/]")
        console.print("     [dim]Often on a different server/port than Intel.[/]")
        aldec_license = _prompt(
            "ALDEC_LICENSE",
            "ALDEC_LICENSE",
            example="27009@lic-server.company.com",
        )
        click.echo()

    # ── Installer Paths ──
    quartus_installer_path = None
    vivado_installer_path = None
    if _should_prompt("QUARTUS_INSTALLER_PATH") or _should_prompt("VIVADO_INSTALLER_PATH"):
        console.print("  [cyan]3. EDA Installer Paths[/]")
        console.print("     [dim]Directories containing EDA installer files (.tar, .bin, setup.sh).[/]")
        console.print("     [dim]Docker mounts these directories to install tools into volumes.[/]")
        console.print()
    if _should_prompt("QUARTUS_INSTALLER_PATH"):
        quartus_installer_path = _prompt(
            "QUARTUS_INSTALLER_PATH",
            "QUARTUS_INSTALLER_PATH",
            example="/mnt/downloads/quartus_pro_25.3",
        )
    if _should_prompt("VIVADO_INSTALLER_PATH"):
        vivado_installer_path = _prompt(
            "VIVADO_INSTALLER_PATH",
            "VIVADO_INSTALLER_PATH",
            example="/mnt/downloads/vivado_2024.2",
        )
    if _should_prompt("QUARTUS_INSTALLER_PATH") or _should_prompt("VIVADO_INSTALLER_PATH"):
        click.echo()

    # ── EDA Install Directory (bind-mount to custom disk) ──
    eda_install_dir = None
    if _should_prompt("EDA_INSTALL_DIR"):
        console.print("  [cyan]4. EDA Install Directory (optional)[/]")
        console.print("     [dim]Base directory on the host where EDA tools will be installed.[/]")
        console.print("     [dim]Useful if you want tools on a separate SSD or large disk.[/]")
        console.print("     [dim]Leave empty to use Docker named volumes (default).[/]")
        console.print()
        console.print("     [dim]When set, each tool gets a subdirectory:[/]")
        console.print("       [dim]<dir>/quartus_pro/  <dir>/quartus_std/  <dir>/vivado/[/]")
        console.print()
        eda_install_dir = _prompt(
            "EDA_INSTALL_DIR",
            "EDA_INSTALL_DIR",
            example="/mnt/data_ssd/eda",
        )
        click.echo()

    # ── MAC Override ──
    mac_override = None
    if _should_prompt("EDA_MAC_ADDRESS_OVERRIDE"):
        console.print("  [cyan]5. MAC Address Override (node-locked licenses)[/]")
        console.print("     [dim]If your license is locked to a specific host MAC address,[/]")
        console.print("     [dim]the Docker container needs to spoof that MAC to validate.[/]")
        console.print()
        console.print("     [dim]How to find your host MAC:[/]")
        console.print("       [cyan]Windows (PowerShell):[/] [dim]Get-NetAdapter | Select Name, MacAddress[/]")
        console.print("       [cyan]Linux:[/]               [dim]ip link show | grep ether[/]")
        console.print()
        console.print("     [dim]How to find your license .dat file:[/]")
        console.print("       [dim]Look for HOSTID= or SERVER lines in .dat files[/]")
        console.print("       [cyan]Windows:[/] [dim]findstr /s /i HOSTID C:\\*.dat[/]")
        console.print("       [cyan]Linux:[/]   [dim]grep -rl HOSTID /opt /usr/local 2>/dev/null[/]")
        console.print()
        console.print("     [yellow]⚠️  Enabling MAC override disables network_mode: host.[/]")
        console.print("     [yellow]   VPN-routed servers typically remain reachable via Docker NAT,[/]")
        console.print("     [yellow]   but some VPN configs may block NAT traffic.[/]")
        console.print("     [dim]Press Enter to skip if you use floating licenses only.[/]")
        mac_override = _prompt(
            "EDA_MAC_ADDRESS_OVERRIDE",
            "EDA_MAC_ADDRESS_OVERRIDE",
            example="00:1A:2B:3C:4D:5E",
        )
        # Basic MAC validation (skip if user kept existing value)
        if mac_override is not _KEEP and mac_override and not re.match(r"^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$", mac_override):
            console.print(
                f"  ⚠️  [yellow]'{mac_override}' doesn't look like a MAC address, "
                f"but saving it anyway.[/]"
            )
        # Normalize: Docker requires colons and lowercase (Windows uses dashes)
        if mac_override is not _KEEP and mac_override:
            mac_override = mac_override.replace("-", ":").lower()
        click.echo()

    # ── Write .env ──
    new_vars = {}
    kept_keys = set()  # keys where user pressed Enter (no change)
    for key, val in [
        ("QUARTUS_LICENSE", quartus_license),
        ("ALDEC_LICENSE", aldec_license),
        ("QUARTUS_INSTALLER_PATH", quartus_installer_path),
        ("VIVADO_INSTALLER_PATH", vivado_installer_path),
        ("EDA_INSTALL_DIR", eda_install_dir),
        ("EDA_MAC_ADDRESS_OVERRIDE", mac_override),
    ]:
        if val is _KEEP:
            kept_keys.add(key)
        elif val:
            new_vars[key] = val

    # Track keys that the user explicitly cleared (typed 'none')
    if active_keys is not None:
        all_managed_keys = active_keys  # Only manage what we prompted for
    else:
        all_managed_keys = {
            "QUARTUS_LICENSE", "ALDEC_LICENSE",
            "QUARTUS_INSTALLER_PATH", "VIVADO_INSTALLER_PATH",
            "EDA_INSTALL_DIR", "EDA_MAC_ADDRESS_OVERRIDE",
        }
    cleared_keys = all_managed_keys - set(new_vars.keys()) - kept_keys
    # Only consider a key "cleared" if it previously existed
    cleared_keys = {k for k in cleared_keys if k in env_vars}

    if not new_vars and not cleared_keys:
        console.print("  [dim]No values entered. Nothing to write.[/]")
        return

    # Merge into existing .env (update existing keys, append new ones)
    updated_keys = set()
    output_lines = []
    for line in env_lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in cleared_keys:
                continue  # Remove cleared keys from output
            if key in new_vars:
                output_lines.append(f"{key}={new_vars[key]}")
                updated_keys.add(key)
                continue
        output_lines.append(line)

    # Append new keys that weren't already in the file
    new_keys = set(new_vars.keys()) - updated_keys
    if new_keys:
        if output_lines and output_lines[-1].strip():
            output_lines.append("")
        output_lines.append("# RouteRTL Docker EDA Environment")
        for key in [
            "QUARTUS_LICENSE", "ALDEC_LICENSE",
            "QUARTUS_INSTALLER_PATH", "VIVADO_INSTALLER_PATH",
            "EDA_INSTALL_DIR", "EDA_MAC_ADDRESS_OVERRIDE",
        ]:
            if key in new_keys:
                output_lines.append(f"{key}={new_vars[key]}")

    env_path.write_text("\n".join(output_lines) + "\n")

    # ── Summary ──
    console.print(f"  [green]✅ Written to {env_path.resolve()}[/]\n")
    for key, val in new_vars.items():
        console.print(f"    [cyan]{key}[/]=[green]{val}[/]")
    click.echo()
    console.print("  [dim]Docker Compose reads .env automatically.[/]")
    console.print("  [dim]Verify with: routertl docker status[/]\n")
