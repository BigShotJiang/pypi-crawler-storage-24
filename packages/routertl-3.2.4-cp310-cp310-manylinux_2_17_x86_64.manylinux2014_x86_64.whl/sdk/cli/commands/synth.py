# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Synthesis Validation Status Board — ``rr synth``.

Provides a dashboard of synthesis results, batch synthesis, and cross-
referencing of ip.yml targets against the source-tree forest.
"""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import rich_click as click
from rich.table import Table

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient, cli_resilient_block

# ── Helpers ───────────────────────────────────────────────────────

def _clean_top(top):
    """Reuse the shared entity-name sanitizer from hardware.py."""
    from sdk.cli.commands.hardware import _clean_top as _hw_clean
    return _hw_clean(top)


def _run_make_capture(target, *args):
    """Run a Make target and return (returncode, duration_s).

    Detects common failure patterns (missing targets, missing make)
    and emits pip-friendly error messages.
    """
    cmd = ["make", target, *args]
    t0 = time.monotonic()
    try:
        result = subprocess.run(
            cmd, check=False, capture_output=True, text=True,
        )
        duration = time.monotonic() - t0
        if result.returncode != 0:
            stderr = result.stderr or ""
            if "No rule to make target" in stderr:
                console.print(
                    f"❌ [red]Build target '{target}' not available.[/]\n"
                    "   This project's Makefile is missing SDK targets.\n"
                    "   Possible fixes:\n"
                    "   • Run [cyan]rr init --repair[/] to regenerate the Makefile\n"
                    "   • Or run inside Docker: [cyan]rr docker shell[/]"
                )
                sys.exit(1)
            # Print captured output so the user still sees make errors
            if isinstance(result.stdout, str) and result.stdout:
                sys.stdout.write(result.stdout)
            if isinstance(result.stderr, str) and result.stderr:
                sys.stderr.write(result.stderr)
        else:
            # Print normal output on success
            if isinstance(result.stdout, str) and result.stdout:
                sys.stdout.write(result.stdout)
        return result.returncode, duration
    except FileNotFoundError:
        console.print(
            "❌ [red]'make' not found.[/]\n"
            "   Install build tools: [cyan]sudo apt install build-essential[/]"
        )
        sys.exit(1)


def _run_synth_direct(module, *extra_args):
    """Run NPM synthesis by calling dependency_resolver.py directly.

    Bypasses Make entirely for pip-installed environments.  Falls back
    to ``_run_make_capture()`` if the resolver script is not found.

    Returns (returncode, duration_s).
    """
    from sdk.cli.env_setup import resolve_sdk_script, resolve_src_dirs

    script = resolve_sdk_script("project-manager/dependency_resolver.py")
    if script is None:
        # Submodule install — fall back to Make
        return _run_make_capture("npm-synthesis", f"TOP={module}", *extra_args)

    src_dirs = resolve_src_dirs()
    src_args = []
    for d in src_dirs:
        src_args.extend(["--src", d])

    t0 = time.monotonic()

    # Step 1: Resolve dependencies for the target module
    resolver_cmd = [
        sys.executable, str(script),
    ] + src_args + ["--top", module, "--list-libs"]

    try:
        res = subprocess.run(
            resolver_cmd, capture_output=True, text=True, check=True,
        )
    except subprocess.CalledProcessError as exc:
        duration = time.monotonic() - t0
        err = (exc.stderr or "").strip()
        console.print(
            f"❌ [red]Dependency resolution failed for {module}.[/]"
        )
        if err:
            console.print(f"   {err}")
        return 1, duration
    except FileNotFoundError:
        console.print("❌ [red]Python interpreter not found.[/]")
        sys.exit(1)

    resolved_files = res.stdout.strip()
    if not resolved_files:
        duration = time.monotonic() - t0
        console.print(
            f"❌ [red]No dependencies found for {module}.[/]\n"
            "   Check entity name and source directories."
        )
        return 1, duration

    console.print(
        f"   [dim]Resolved {len(resolved_files.split())} source file(s)[/]"
    )

    # Step 2: Delegate to Make for vendor TCL invocation (needs EDA tools)
    # The direct path resolved the file list; Make handles the TCL call.
    duration = time.monotonic() - t0
    rc, make_dur = _run_make_capture("npm-synthesis", f"TOP={module}", *extra_args)
    return rc, duration + make_dur


def _get_tracker():
    """Lazy-import and instantiate a SynthTracker for the current directory."""
    from sdk.engine.synth_tracker import SynthTracker
    return SynthTracker()


@cli_resilient("project YAML loading", default=None)
def _load_project_yml():
    """Load project.yml from cwd, or return None."""
    import yaml
    if not os.path.exists("project.yml"):
        return None
    with open("project.yml", "r") as f:
        return yaml.safe_load(f) or {}


def _discover_ip_targets():
    """Return list of (name, source_count) for ip.yml targets with mode=rtl.

    Returns an empty list when project.yml is missing or has no IPs.
    """
    config = _load_project_yml()
    if config is None:
        return []

    with cli_resilient_block("IP target discovery"):
        from sdk.engine.ip_resolver import IpResolver, load_ips_from_project
        ip_paths, vendor, project_root = load_ips_from_project("project.yml")
        if not ip_paths:
            return []
        resolver = IpResolver(project_root, vendor)
        result = resolver.resolve(ip_paths)
        return [
            (m.name, m.source_count)
            for m in result.manifests
            if m.mode == "rtl"
        ]
    return []


def _discover_forest_entities():
    """Return sorted list of (name, is_top, file_count) from the source forest."""
    src_dir = "src"
    if os.path.exists("build_env.mk"):
        with open("build_env.mk") as f:
            for line in f:
                if line.strip().startswith("SRC_DIR"):
                    parts = line.split("?=") if "?=" in line else line.split("=")
                    if len(parts) == 2:
                        src_dir = parts[1].strip()
                        break

    with cli_resilient_block("forest entity discovery"):
        from sdk.engine.dependency_resolver import DependencyResolver
        resolver = DependencyResolver([Path(src_dir)], verbose=False)
        forest = resolver.resolve_forest()
        top_names = {t["top"] for t in (forest.get("trees") or [])}

        results = []
        for name in sorted(resolver.entity_map.keys()):
            is_top = name in top_names
            # Count files via the forest tree data if available
            file_count = 1
            for t in (forest.get("trees") or []):
                if t["top"] == name:
                    file_count = t.get("weight") or len(t.get("files") or [])
                    break
            results.append((name, is_top, file_count))
        return results
    return []


@cli_resilient("CLI name resolution", default="routertl")
def _resolve_cli_name():
    """Get the effective CLI binary name for usage hints."""
    from sdk.cli.main import CLI_NAME
    return CLI_NAME


def _get_vendor_and_part():
    """Read vendor and part from project.yml for result recording."""
    config = _load_project_yml()
    if config is None:
        return "", ""
    hw = config.get("hardware", {})
    return hw.get("vendor", ""), hw.get("part", "")


def _status_style(status):
    """Return (color, icon) for a synthesis status string."""
    styles = {
        "PASS":    ("[green]",  "✅"),
        "FAIL":    ("[red]",    "❌"),
        "STALE":   ("[yellow]", "🔄"),
        "UNKNOWN": ("[dim]",   "⬜"),
    }
    return styles.get(status, ("[dim]", "?"))


# ── Command Group ─────────────────────────────────────────────────

@click.group(name="synth", invoke_without_command=True)
@click.pass_context
def synth_group(ctx):
    """Synthesis Validation Status Board.

    View synthesis results, batch-synthesize ip.yml targets, and cross-
    reference forest entities with registered IP manifests.
    """
    if ctx.invoked_subcommand is None:
        # Default to status when no subcommand is given
        ctx.invoke(synth_status)


# ── rr synth status ───────────────────────────────────────────────

@synth_group.command(name="status")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def synth_status(as_json):
    """Show the synthesis status board.

    Displays all ip.yml targets with ``synthesis.mode: rtl``, overlaid with
    cached PASS/FAIL/STALE status from previous runs.
    """
    tracker = _get_tracker()
    ip_targets = _discover_ip_targets()

    if as_json:
        data = {}
        for name, src_count in ip_targets:
            result = tracker.get(name)
            data[name] = {
                "sources": src_count,
                "status": result.status if result else "UNKNOWN",
                "timestamp": result.timestamp if result else None,
                "resources": result.resources if result else {},
                "warnings": result.warnings if result else 0,
            }
        click.echo(json.dumps(data, indent=2))
        return

    cli_name = _resolve_cli_name()


    if not ip_targets:
        console.print(
            "\n  [dim]No ip.yml targets with synthesis.mode: rtl found.[/]"
        )
        console.print(
            f"  [dim]Use '{cli_name} synth run <module>' for ad-hoc synthesis.[/]\n"
        )
        # Show any cached ad-hoc results
        all_results = tracker.all_results()
        if all_results:
            console.print("  [cyan]Cached ad-hoc results:[/]\n")
            for name, r in sorted(all_results.items()):
                color, icon = _status_style(r.status)
                console.print(
                    f"    {icon} {color}{name:<25}[/] "
                    f"[dim]{r.timestamp[:19] if r.timestamp else '—'}[/]"
                )
            click.echo()
        return

    table = Table(
        title="🔬 Synthesis Status Board",
        title_style="bold cyan",
        show_lines=False,
        padding=(0, 1),
    )
    table.add_column("Status", justify="center", width=6)
    table.add_column("Module", style="cyan", min_width=20)
    table.add_column("Sources", justify="right", width=7)
    table.add_column("Resources", min_width=15)
    table.add_column("Warns", justify="right", width=5)
    table.add_column("Duration", justify="right", width=8)
    table.add_column("Last Run", min_width=12)

    pass_count = 0
    fail_count = 0
    stale_count = 0
    unknown_count = 0

    for name, src_count in sorted(ip_targets):
        result = tracker.get(name)
        if result:
            status = result.status
            if status == "PASS":
                # Quick staleness heuristic — full check requires src_files
                pass_count += 1
            else:
                fail_count += 1

            res_str = ", ".join(f"{k}={v:,}" for k, v in result.resources.items()) if result.resources else "—"
            warn_str = str(result.warnings) if result.warnings else "—"
            dur_str = f"{result.duration_s:.1f}s" if result.duration_s else "—"
            ts_str = result.timestamp[:19].replace("T", " ") if result.timestamp else "—"
        else:
            status = "UNKNOWN"
            unknown_count += 1
            res_str = "—"
            warn_str = "—"
            dur_str = "—"
            ts_str = "—"

        color, icon = _status_style(status)
        table.add_row(
            icon,
            name,
            str(src_count),
            res_str,
            warn_str,
            dur_str,
            ts_str,
        )

    console.print()
    console.print(table)

    total = pass_count + fail_count + stale_count + unknown_count
    summary_parts = []
    if pass_count:
        summary_parts.append(f"[green]{pass_count} passed[/]")
    if fail_count:
        summary_parts.append(f"[red]{fail_count} failed[/]")
    if stale_count:
        summary_parts.append(f"[yellow]{stale_count} stale[/]")
    if unknown_count:
        summary_parts.append(f"[dim]{unknown_count} not run[/]")

    console.print(f"\n  {' · '.join(summary_parts)}  ({total} targets)")
    console.print(
        f"\n  [dim]Run '{cli_name} synth all' to synthesize all targets.[/]\n"
    )


# ── rr synth all ──────────────────────────────────────────────────

@synth_group.command(name="all")
@click.option("--clean", "-c", is_flag=True, help="Remove cached DCP artifacts before each run.")
def synth_all(clean):
    """Batch-synthesize all ip.yml targets with ``synthesis.mode: rtl``."""
    from sdk.cli.commands.hardware import _clean_build_artifacts

    ip_targets = _discover_ip_targets()
    if not ip_targets:
        console.print(
            "\n  [dim]No ip.yml targets with synthesis.mode: rtl found.[/]\n"
        )
        return

    tracker = _get_tracker()
    vendor, part = _get_vendor_and_part()
    total = len(ip_targets)

    console.print(
        f"\n🔍 [cyan]Discovered {total} synthesis target{'s' if total != 1 else ''}"
        f" from ip.yml manifests[/]\n"
    )

    results_summary = []

    for idx, (name, src_count) in enumerate(ip_targets, 1):
        console.print(
            f"🔨 [{idx}/{total}] [cyan]{name}[/] "
            f"({src_count} file{'s' if src_count != 1 else ''})...",
            end="",
        )
        if clean:
            _clean_build_artifacts("dcp", name)

        rc, duration = _run_synth_direct(name)
        status = "PASS" if rc == 0 else "FAIL"

        from datetime import datetime, timezone

        from sdk.engine.synth_tracker import SynthResult
        result = SynthResult(
            module=name,
            status=status,
            timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            duration_s=round(duration, 1),
            vendor=vendor,
            part=part,
        )
        tracker.record(result)

        color, icon = _status_style(status)
        console.print(f" {icon} {color}{status}[/] ({duration:.1f}s)")
        results_summary.append((name, status, duration))

    # Summary
    passed = sum(1 for _, s, _ in results_summary if s == "PASS")
    failed = sum(1 for _, s, _ in results_summary if s == "FAIL")

    click.echo(f"\n{'━' * 56}")
    if failed == 0:
        console.print(
            f"  [green]NPM SYNTHESIS REPORT — {passed}/{total} PASSED[/]"
        )
    else:
        console.print(
            f"  [red]NPM SYNTHESIS REPORT — {passed}/{total} PASSED, "
            f"{failed} FAILED[/]"
        )
    click.echo(f"{'━' * 56}")
    console.print("  [dim]Results cached in .routertl_cache/synth_results.json[/]\n")


# ── rr synth run ──────────────────────────────────────────────────

@synth_group.command(name="run")
@click.argument("module", required=False, default=None)
@click.option("--clean", "-c", is_flag=True, help="Remove cached DCP/Project artifacts first.")
def synth_run(module, clean):
    """Synthesize the project or a single module.

    If <module> is provided, synthesizes a single NPM IP module.
    Without <module>, synthesizes the full project.
    """
    from sdk.cli.commands.hardware import _clean_build_artifacts, _run_make

    if not module:
        # Full project synthesis
        if clean:
            _clean_build_artifacts("project", "")
        console.print("🔨 [blue]Starting Synthesis...[/]")
        try:
            from sdk.cli.vendor_dispatch import VendorDispatch, VendorToolNotFound

            dispatch = VendorDispatch.from_project()
            rc = dispatch.synthesis()
            if rc != 0:
                sys.exit(rc)
        except (ImportError, VendorToolNotFound):
            _run_make("synthesis")
        return

    # IP-level synthesis
    module = _clean_top(module)

    if clean:
        _clean_build_artifacts("dcp", module)

    console.print(
        f"🔨 [blue]Synthesizing [cyan]{module}[/]..."
    )

    rc, duration = _run_synth_direct(module)
    status = "PASS" if rc == 0 else "FAIL"

    vendor, part = _get_vendor_and_part()

    tracker = _get_tracker()
    from datetime import datetime, timezone

    from sdk.engine.synth_tracker import SynthResult
    result = SynthResult(
        module=module,
        status=status,
        timestamp=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        duration_s=round(duration, 1),
        vendor=vendor,
        part=part,
    )
    tracker.record(result)

    color, icon = _status_style(status)
    console.print(
        f"\n  {icon} {color}{status}[/] — "
        f"{module} ({duration:.1f}s)"
    )
    if status == "FAIL":
        sys.exit(1)


# ── rr synth discover ─────────────────────────────────────────────

@synth_group.command(name="discover")
def synth_discover():
    """Cross-reference forest entities with ip.yml targets.

    Shows which source-tree entities are already registered as ip.yml targets
    and which are potential candidates for synthesis validation.
    """

    ip_targets = _discover_ip_targets()
    ip_names = {name for name, _ in ip_targets}
    forest = _discover_forest_entities()

    if not forest:
        console.print(
            "\n  [dim]No entities found in the source tree.[/]\n"
        )
        return

    table = Table(
        title="🔍 Synthesis Target Discovery",
        title_style="bold cyan",
        show_lines=False,
        padding=(0, 1),
    )
    table.add_column("Entity", style="cyan", min_width=25)
    table.add_column("Type", width=12)
    table.add_column("ip.yml", justify="center", width=8)
    table.add_column("Files", justify="right", width=5)

    registered = 0
    candidates = 0

    for name, is_top, file_count in forest:
        type_str = "top-level" if is_top else "[dim]submodule[/]"
        if name in ip_names:
            ip_str = "[green]✅[/]"
            registered += 1
        else:
            ip_str = "[dim]—[/]"
            if is_top:
                candidates += 1

        table.add_row(name, type_str, ip_str, str(file_count))

    console.print()
    console.print(table)

    console.print(
        f"\n  [green]{registered}[/] registered in ip.yml · "
        f"[yellow]{candidates}[/] top-level candidates without ip.yml\n"
    )

    if candidates > 0:
        cli_name = _resolve_cli_name()
        console.print(
            f"  [dim]Tip: use '{cli_name} ip init <name>' to create "
            f"an ip.yml for uncovered entities.[/]\n"
        )


# ── rr synth clear ────────────────────────────────────────────────

@synth_group.command(name="clear")
@click.argument("module", required=False, default=None)
def synth_clear(module):
    """Clear cached synthesis results (one module or all)."""
    tracker = _get_tracker()
    if module:
        tracker.clear(module)
        console.print(f"🗑️  Cleared synthesis cache for [cyan]{module}[/]")
    else:
        tracker.clear()
        click.echo("🗑️  Cleared all synthesis cache entries")
