# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Vendor Dispatch — construct and run vendor-specific TCL commands.

Replaces the Make-level vendor flow logic from ``synthesis.mk`` and
``Common.mk``.  Reads ``project.yml`` and ``build_env.mk`` to construct
the correct ``quartus_sh -t …`` / ``vivado -mode batch -source …`` /
``pnmainc …`` / ``libero SCRIPT:…`` invocations.
"""

import os
import shutil
import subprocess
from pathlib import Path

from sdk.cli.console import console
from sdk.cli.engine_dispatch import ensure_build_env
from sdk.cli.resilience import cli_resilient_block


class VendorToolNotFound(RuntimeError):
    """Raised when the required vendor EDA tool is not on PATH."""


class VendorDispatch:
    """Construct and execute vendor-specific TCL commands.

    Attributes
    ----------
    vendor : str
        One of ``xilinx``, ``altera``, ``lattice``, ``microchip``.
    tool_cmd : str
        The vendor tool command (e.g. ``vivado -mode batch -source``).
    tcl_run : str
        Base command for TCL script execution.
    tcl_flag : str
        Argument separator for TCL args (e.g. ``-tclargs`` for Vivado).
    root_dir : Path
        Project root directory.
    sdk_root : Path
        SDK root directory.
    """

    # Vendor → (tcl_run_builder, tcl_flag)
    _VENDOR_CONFIG = {
        "xilinx": {
            "tcl_flag": "-tclargs",
            "tool_candidates": ["vivado"],
            "tool_suffix": "",
        },
        "altera": {
            "tcl_flag": "",
            "tool_candidates": ["quartus_sh"],
            "tool_suffix": "-t",
        },
        "lattice": {
            "tcl_flag": "",
            "tool_candidates": ["pnmainc"],
            "tool_suffix": "",
        },
        "microchip": {
            "tcl_flag": "SCRIPT_ARGS:",
            "tool_candidates": ["libero"],
            "tool_suffix": "SCRIPT:",
        },
    }

    def __init__(
        self,
        vendor: str,
        tool_cmd: str,
        tcl_flag: str,
        root_dir: Path,
        sdk_root: Path,
        build_env: dict[str, str],
    ):
        self.vendor = vendor
        self.tool_cmd = tool_cmd
        self.tcl_flag = tcl_flag
        self.root_dir = root_dir
        self.sdk_root = sdk_root
        self.build_env = build_env

    @classmethod
    def from_project(
        cls,
        root_dir: Path | None = None,
        project_yml: str = "project.yml",
    ) -> "VendorDispatch":
        """Create a VendorDispatch from project.yml and build_env.mk.

        Parameters
        ----------
        root_dir : Path, optional
            Project root.  Defaults to cwd.
        project_yml : str
            Path to project.yml.
        """
        root_dir = root_dir or Path.cwd()

        # Read build environment
        build_env = ensure_build_env(project_yml)

        # Determine vendor
        vendor = build_env.get("VENDOR", "").lower()
        if not vendor:
            # Fallback: read from project.yml directly
            with cli_resilient_block("vendor detection"):
                import yaml

                yml_path = root_dir / project_yml
                if yml_path.exists():
                    with open(yml_path) as f:
                        cfg = yaml.safe_load(f) or {}
                    hw = cfg.get("hardware") or {}
                    vendor = (hw.get("vendor") or "xilinx").lower()
                else:
                    vendor = "xilinx"

        config = cls._VENDOR_CONFIG.get(vendor, cls._VENDOR_CONFIG["xilinx"])

        # Resolve tool command
        tool_cmd = build_env.get("TOOL_CMD", "")

        # Strip Make variable references like $(QUARTUS_SH) that leak
        # from legacy build_env.mk files (P2.101).  Extract the inner
        # name, lowercase it, and try shutil.which() on that.
        if tool_cmd and tool_cmd.startswith("$("):
            import re as _re

            m = _re.match(r"^\$\((\w+)\)$", tool_cmd)
            inner = m.group(1).lower() if m else ""
            resolved = shutil.which(inner) if inner else None
            tool_cmd = inner if resolved else ""

        if not tool_cmd:
            for candidate in config["tool_candidates"]:
                if shutil.which(candidate):
                    tool_cmd = candidate
                    break
            if not tool_cmd:
                tool_cmd = config["tool_candidates"][0]

        # Inject tool_path from project.yml if available
        with cli_resilient_block("tool_path injection"):
            import yaml

            yml_path = root_dir / project_yml
            if yml_path.exists():
                with open(yml_path) as f:
                    cfg = yaml.safe_load(f) or {}
                hw = cfg.get("hardware") or {}
                tool_path = hw.get("tool_path") if isinstance(hw, dict) else None
                if tool_path:
                    tp = Path(tool_path)
                    for sub in ["quartus/bin", "bin", "bin/lin64", "Libero/bin"]:
                        candidate_path = tp / sub
                        if candidate_path.is_dir():
                            os.environ["PATH"] = f"{candidate_path}:{os.environ.get('PATH', '')}"
                            break

        # Resolve SDK root
        from sdk.cli.sdk_root import resolve_sdk_root

        sdk_root = resolve_sdk_root() or root_dir

        # Build tcl_run command
        suffix = config["tool_suffix"]
        if suffix:
            tool_cmd = f"{tool_cmd} {suffix}"

        return cls(
            vendor=vendor,
            tool_cmd=tool_cmd,
            tcl_flag=config["tcl_flag"],
            root_dir=root_dir,
            sdk_root=sdk_root,
            build_env=build_env,
        )

    def _tcl_path(self, script_name: str) -> Path:
        """Resolve a vendor-specific TCL script path."""
        return self.sdk_root / "tcl" / self.vendor / script_name

    def _check_tool_available(self):
        """Raise VendorToolNotFound if the vendor tool is not on PATH."""
        tool_bin = self.tool_cmd.split()[0]
        if not shutil.which(tool_bin):
            console.print(
                f"❌ [red]Vendor tool '{tool_bin}' not found on PATH.[/]\n"
                f"   VENDOR={self.vendor}\n"
                f"   Hint: Is the {self.vendor} toolchain installed?\n"
                "   Run [cyan]rr doctor[/] to diagnose."
            )
            raise VendorToolNotFound(tool_bin)

    def _run_tcl(self, tcl_script: Path, *tcl_args: str) -> int:
        """Run a vendor TCL script with correct invocation syntax.

        Returns the process exit code.
        """
        self._check_tool_available()

        parts = self.tool_cmd.split()
        cmd = parts + [str(tcl_script)]
        if self.tcl_flag:
            cmd.append(self.tcl_flag)
        cmd.extend(tcl_args)

        console.print(f"   [dim]→ {' '.join(cmd[:4])}…[/]")
        result = subprocess.run(cmd, check=False)
        return result.returncode

    # ── Public API ────────────────────────────────────────────────────

    def synthesis(self) -> int:
        """Run full project synthesis."""
        console.print("🚀 [blue]Synthesizing Project...[/]")
        tcl = self._tcl_path("gen_synthesis.tcl")
        rc = self._run_tcl(tcl, str(self.root_dir))
        if rc == 0:
            self._record_known_part()
        return rc

    def implementation(self) -> int:
        """Run implementation (place & route)."""
        console.print("🚀 [blue]Running Implementation...[/]")
        tcl = self._tcl_path("gen_implementation.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def bitstream(self) -> int:
        """Generate bitstream."""
        console.print("🚀 [blue]Generating Bitstream...[/]")
        tcl = self._tcl_path("gen_bitstream.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def project(
        self,
        syn_files: str = "",
        ip_files: str = "",
        sim_files: str = "",
        tcl_files: str = "",
        xdc_files: str = "",
        netlist_files: str = "",
    ) -> int:
        """Generate vendor project."""
        console.print("🏗  [blue]Building Project...[/]")
        tcl = self._tcl_path("gen_project.tcl")
        return self._run_tcl(
            tcl,
            str(self.root_dir),
            syn_files or self.build_env.get("SYN_FILES", ""),
            ip_files or self.build_env.get("IP_FILES", ""),
            sim_files or self.build_env.get("SIM_FILES", ""),
            tcl_files or self.build_env.get("TCL_FILES", ""),
            xdc_files or self.build_env.get("XDC_FILES", self.build_env.get("SDC_FILES", "")),
            netlist_files or self.build_env.get("NETLIST_FILES", ""),
        )

    def program(self) -> int:
        """Program FPGA device."""
        console.print("🚀 [blue]Programming FPGA device...[/]")
        tcl = self._tcl_path("gen_program.tcl")
        return self._run_tcl(tcl, str(self.root_dir))

    def npm_synthesis(
        self,
        top: str,
        npm_files: str,
        ip_files: str = "",
        xdc_files: str = "",
        netlist_files: str = "",
    ) -> int:
        """Run Non-Project Mode synthesis for a single module."""
        console.print(f"🚀 [blue]Synthesizing {top} (NPM)...[/]")
        tcl = self._tcl_path("non_project_mode.tcl")
        return self._run_tcl(
            tcl,
            str(self.root_dir),
            npm_files,
            ip_files or self.build_env.get("IP_FILES", ""),
            xdc_files or self.build_env.get("XDC_FILES", self.build_env.get("SDC_FILES", "")),
            top,
            netlist_files or self.build_env.get("NETLIST_FILES", ""),
        )

    def _record_known_part(self):
        """Record successfully synthesized FPGA part (mirrors Make behavior)."""
        parts_file = self.root_dir / ".routertl" / "known_parts.txt"
        parts_file.parent.mkdir(parents=True, exist_ok=True)
        fpga_part = self.build_env.get("FPGA_PART", "")
        if not fpga_part:
            return
        entry = f"{self.vendor} {fpga_part}"
        if parts_file.exists():
            existing = parts_file.read_text()
            if entry in existing:
                return
        else:
            # First-time creation: write header
            parts_file.write_text(
                "# RouteRTL — Known FPGA Parts (auto-updated)\n"
                "# Format: <vendor> <part>\n"
            )
        with open(parts_file, "a") as f:
            f.write(f"{entry}\n")
