#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL project initializer — thin orchestrator.

This file was decomposed from a 1,057-line monolith into a sub-package
(P2.67). The heavy lifting is now in sdk/engine/init/:

    scaffold.py   — project.yml, Makefile, .gitignore, VERSION, regbank
    venv.py       — venv setup, resilient wrapper, branding, completion
    templates.py  — template discovery, listing, application
    env_check.py  — environment validation, Git LFS auto-pull

This file retains:
    BANNER          — ASCII art
    _parse_args()   — argparse + early template/list handling
    _collect_config — interactive prompts + config dict assembly
    main()          — orchestrator (~30 lines)
"""

import argparse
import os
import sys

# ── sys.path bootstrap for standalone execution ──
# When run as `python3 vendor/routertl/sdk/engine/init_project.py` the SDK
# repo root is not on sys.path.  Resolve it from __file__ so that absolute
# imports like `from sdk.engine.init import ...` work.
_SDK_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _SDK_ROOT not in sys.path:
    sys.path.insert(0, _SDK_ROOT)

from sdk.engine.init import (  # noqa: F401
    _COMP_SENTINEL_END,
    _COMP_SENTINEL_START,
    PYPROJECT_TEMPLATE,
    TEMPLATE,
    _apply_template,
    _check_lfs,
    _create_branded_symlink,
    _create_shortcut_alias,
    _detect_shell,
    _discover_templates,
    _generate_pyproject_toml,
    _hook_shell_completion,
    _install_resilient_wrapper,
    _list_templates,
    _scaffold_project,
    check_environment,
    setup_python_env,
)

# ASCII Art Banner
BANNER = r"""
 ____             _       ____ _____ _
|  _ \ ___  _   _| |_ ___|  _ \_   _| |
| |_) / _ \| | | | __/ _ \ |_) || | | |
|  _ < (_) | |_| | ||  __/  _ < | | | |___
|_| \_\___/ \__,_|\__\___|_| \_\|_| |_____|
"""


def _parse_args():
    """Build argparse, load vendor DB, parse args, handle early exits.

    Returns the parsed args namespace.  If ``--list-templates`` or
    ``--template`` are used, the function handles them completely
    (including post-init flow) and then returns ``None``.
    """
    # Load Supported Vendors Database
    vendor_db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "supported_vendors.yml")
    vendor_choices = ["xilinx"]  # Fallback
    if os.path.exists(vendor_db_path):
        import yaml

        with open(vendor_db_path, "r") as f:
            vdb = yaml.safe_load(f)
            if vdb:
                vendor_choices = list(vdb.keys())

    parser = argparse.ArgumentParser(description="Initialize a new RouteRTL project.")
    parser.add_argument("--name", help="Project name")
    parser.add_argument("--top", help="Top module name")
    parser.add_argument("--vendor", help="FPGA Vendor", choices=vendor_choices)
    parser.add_argument("--part", help="FPGA Part")
    parser.add_argument("--cicd", help="CI/CD platform", choices=["github", "gitlab", "bitbucket", "none"])
    parser.add_argument("--src-dir", default="src", help="Source directory (default: src)")
    parser.add_argument("--sim-dir", default="sim", help="Simulation directory (default: sim)")
    parser.add_argument("--xdc-dir", default="xdc", help="Constraints directory (default: xdc)")
    parser.add_argument("--verification-dir", default="verif", help="Verification artifacts directory (default: verif)")
    parser.add_argument(
        "--sdk-path", default="vendor/routertl",
        help="Fallback SDK path for generated Makefile (default: vendor/routertl)"
    )
    parser.add_argument("--no-venv", action="store_true", help="Skip Python virtual environment configuration")
    parser.add_argument(
        "--non-interactive", "-y", action="store_true", help="Run in non-interactive mode (use defaults)"
    )
    parser.add_argument("--language", help="HDL language", choices=["vhdl", "verilog", "systemverilog"], default=None)
    parser.add_argument("--linux-target", help="Embedded Linux Target Architecture (e.g., zynq-7000)", default=None)
    parser.add_argument("--linux-board", help="Embedded Linux Board Name (e.g., zybo)", default=None)
    parser.add_argument("--dry-run", action="store_true", help="Print config without writing")
    parser.add_argument(
        "--template", help="Initialize from a template (e.g., blinky, counter, axi)"
    )
    parser.add_argument(
        "--list-templates", action="store_true", help="List available project templates and exit"
    )
    args = parser.parse_args()

    # Store vendor_choices on args so _collect_config can use it for prompts
    args._vendor_choices = vendor_choices

    # Handle --list-templates early
    if args.list_templates:
        _list_templates()
        sys.exit(0)

    # Handle --template mode
    if args.template:
        name = args.name or args.template
        print(BANNER)
        from routertl_core import __copyright__, __version__
        print(f"  v{__version__}  •  {__copyright__}\n")
        print(f"🚀 Initializing project '{name}' from template '{args.template}'...\n")
        _apply_template(args.template, name, args.sdk_path)
        # Run standard post-init flow (venv, hooks, env check)
        if not args.no_venv:
            setup_python_env(args.sdk_path)
        check_environment()
        _check_lfs()
        print("\n" + "=" * 60)
        print(f"✅ Project '{name}' initialized from template '{args.template}'!")
        print("=" * 60)
        print("\nQuick Start:")
        print("  source .venv/bin/activate")
        print("  make linting")
        print("  make simulation")
        return None

    return args


def _collect_config(args):
    """Run interactive prompts and return a config dict with all resolved values.

    The returned dict contains the following keys:
    ``name``, ``top``, ``sim_tb``, ``vendor``, ``part``, ``src_dir``,
    ``sim_dir``, ``xdc_dir``, ``verification_dir``, ``language``,
    ``linux_target``, ``linux_board``, ``content`` (rendered YAML string),
    ``directories`` (list of directory paths to create).
    """
    vendor_choices = getattr(args, "_vendor_choices", ["xilinx"])

    # Helper for input
    def get_input(prompt, default):
        """Prompt the user for input with a default value."""
        if args.non_interactive:
            return default
        return input(prompt).strip() or default

    # Interactive prompts if args not provided
    name = args.name or get_input("Project Name [my_fpga_project]: ", "my_fpga_project")

    default_top = f"{name}_top"
    top = args.top or get_input(f"Top Module Name [{default_top}]: ", default_top)

    sim_tb = f"tb_{top}"

    default_vendor = "xilinx"
    vendor_prompt = f"Vendor ({'/'.join(vendor_choices)}) [{default_vendor}]: "
    vendor = args.vendor or get_input(vendor_prompt, default_vendor)

    default_part = "xc7z020clg400-1"
    part = args.part or get_input(f"FPGA Part [{default_part}]: ", default_part)

    # Path configuration (interactive if not provided)
    default_src = "src"
    default_sim = "sim"
    default_xdc = "xdc"
    default_verification = "verif"

    if args.src_dir != default_src:
        src_dir = args.src_dir
    else:
        src_dir = get_input(f"Source Directory [{default_src}]: ", default_src)

    if args.sim_dir != default_sim:
        sim_dir = args.sim_dir
    else:
        sim_dir = get_input(f"Simulation Directory [{default_sim}]: ", default_sim)

    if args.xdc_dir != default_xdc:
        xdc_dir = args.xdc_dir
    else:
        xdc_dir = get_input(f"Constraints Directory [{default_xdc}]: ", default_xdc)

    if args.verification_dir != default_verification:
        verification_dir = args.verification_dir
    else:
        verification_dir = get_input(f"Verification Directory [{default_verification}]: ", default_verification)

    # CI/CD Platform
    default_cicd = "github"
    cicd_platform = args.cicd or get_input(
        f"CI/CD Platform (github/gitlab/bitbucket/none) [{default_cicd}]: ", default_cicd
    )

    # HDL Language
    default_language = "vhdl"
    language = args.language or get_input(
        f"HDL Language (vhdl/verilog/systemverilog) [{default_language}]: ", default_language
    )
    # Normalize: plain Verilog has no package construct, so it uses the SV path
    if language == "verilog":
        language = "systemverilog"

    # Embedded Linux Configuration
    linux_target = args.linux_target
    if linux_target is None and not args.non_interactive:
        linux_target_input = input("Embedded Linux Target (e.g., zynq-7000) [none]: ").strip()
        if linux_target_input and linux_target_input.lower() != "none":
            linux_target = linux_target_input

    linux_board = args.linux_board
    if linux_target and not linux_board and not args.non_interactive:
        linux_board = input("Embedded Linux Board Name (e.g., zybo) [default]: ").strip()
        if not linux_board:
            linux_board = "default"

    # Linux Configuration Section
    if linux_target:
        linux_board_val = linux_board if linux_board else "default"
        linux_section = f"""linux:
  board: {linux_board_val}
"""
    else:
        linux_section = ""

    if cicd_platform.lower() == "none":
        cicd_section = """# CI/CD Configuration (uncomment and configure to enable)
# cicd:
#   platform: github
#   tests: []
"""
    else:
        cicd_section = f"""cicd:
  platform: {cicd_platform}
  tests: []
"""

    # Only include paths section if non-default values are used
    if src_dir != "src" or sim_dir != "sim" or xdc_dir != "xdc" or verification_dir != "verif":
        paths_section = f"""# Custom directory paths
paths:
  sources: {src_dir}
  simulation: {sim_dir}
  constraints: {xdc_dir}
  verification: {verification_dir}

"""
    else:
        paths_section = """# Custom directory paths (uncomment to override defaults)
# paths:
#   sources: src
#   simulation: sim
#   constraints: xdc
#   verification: verif

"""

    content = TEMPLATE.format(
        name=name,
        top_module=top,
        top_sim=sim_tb,
        vendor=vendor,
        part=part,
        language=language,
        sim_dir=sim_dir,
        paths_section=paths_section,
        linux_section=linux_section,
        cicd_section=cicd_section,
    )

    directories = [
        f"{src_dir}/pkg",
        f"{src_dir}/regbank",
        f"{src_dir}/units",
        f"{sim_dir}/cocotb/tests",
        xdc_dir,
        verification_dir,
    ]

    return {
        "name": name,
        "top": top,
        "sim_tb": sim_tb,
        "vendor": vendor,
        "part": part,
        "src_dir": src_dir,
        "sim_dir": sim_dir,
        "xdc_dir": xdc_dir,
        "verification_dir": verification_dir,
        "language": language,
        "linux_target": linux_target,
        "linux_board": linux_board,
        "content": content,
        "directories": directories,
    }


def _install_hooks_and_guide(args):
    """Install git hooks and symlink/copy the SDK User Guide."""
    import shutil
    from pathlib import Path

    if os.path.exists(".git"):
        # Locate the hook script relative to this script
        script_dir = Path(__file__).resolve().parent
        hook_src = script_dir.parent / "githooks" / "project-pre-commit"

        if hook_src.exists():
            hook_dest_dir = Path(".git") / "hooks"
            hook_dest = hook_dest_dir / "pre-commit"

            try:
                os.makedirs(hook_dest_dir, exist_ok=True)
                shutil.copy2(hook_src, hook_dest)
                os.chmod(hook_dest, 0o755)
                print("✅ Git Hooks installed successfully!")
            except OSError as e:
                import logging
                import traceback as _tb

                logging.debug("Git hooks install failed:\n%s", _tb.format_exc())
                print(f"⚠️  Failed to install git hooks: {e}")
        else:
            print(f"⚠️  Could not find hook script at {hook_src}")
    else:
        print("ℹ️  Not a git repository. Skipping hook installation. Run 'make install-hooks' later.")

    # Symlink/Copy SDK User Guide
    from pathlib import Path as _Path

    from sdk.cli.sdk_root import resolve_sdk_root

    # Resolve SDK root dynamically — works for both submodule and pip installs
    sdk_root = resolve_sdk_root()
    if sdk_root is None:
        # Fallback to args.sdk_path for backward compat
        sdk_root = _Path(args.sdk_path)

    sdk_guide_src = sdk_root / "docs" / "SDK_USER_GUIDE.md"
    # Also check docs/reference/ (current layout)
    if not sdk_guide_src.exists():
        sdk_guide_src = sdk_root / "docs" / "reference" / "SDK_USER_GUIDE.md"

    guide_dest = _Path("SDK_USER_GUIDE.md")

    if sdk_guide_src.exists():
        try:
            if guide_dest.exists() or guide_dest.is_symlink():
                os.remove(guide_dest)

            # Determine if SDK is pip-installed (site-packages) — copy instead of symlink
            sdk_str = str(sdk_root.resolve())
            is_pip = "site-packages" in sdk_str or "dist-packages" in sdk_str

            if os.name == "nt" or is_pip:
                shutil.copy2(sdk_guide_src, guide_dest)
                print("   Copied: SDK_USER_GUIDE.md")
            else:
                os.symlink(sdk_guide_src, guide_dest)
                print(f"   Symlinked: SDK_USER_GUIDE.md -> {sdk_guide_src}")
        except OSError as e:
            import logging
            import traceback as _tb

            logging.debug("SDK User Guide link failed:\n%s", _tb.format_exc())
            print(f"⚠️  Failed to link SDK User Guide: {e}")
    else:
        print(f"ℹ️  Could not find SDK User Guide at {sdk_guide_src}")


def _print_quick_start(config, args):
    """Print the success banner and quick-start hints."""
    print("\n" + "=" * 60)
    print("✅ Project initialized successfully!")
    print("=" * 60)
    print("   Created: project.yml")
    print("   Created: Makefile")
    print(f"   Created directories: {', '.join(config['directories'])}")

    # Resolve branded CLI name for Quick Start hints
    cli_cmd = "routertl"
    try:
        import yaml as _yaml

        with open("project.yml") as _f:
            _cfg = _yaml.safe_load(_f) or {}
        _brand = _cfg.get("branding", {}).get("cli_name")
        if _brand:
            cli_cmd = _brand
    except (OSError, ImportError):
        pass

    print("\n" + "-" * 60)
    print("📖 QUICK START")
    print("-" * 60)
    if not args.no_venv:
        print("\n  0️⃣  Install Python dependencies:")
        print("      source .venv/bin/activate && pip install -r requirements.txt")

    print(f"\n  1️⃣  Activate the {cli_cmd} CLI environment:")
    print("      source .venv/bin/activate")
    print("\n  2️⃣  View your design hierarchy:")
    print(f"      {cli_cmd} hierarchy TOP=my_entity")
    print("\n  3️⃣  Generate test templates:")
    print("      make testgen           # Create Cocotb test stubs")
    print("\n  4️⃣  Run simulations:")
    print(f"      {cli_cmd} sim <testbench_name>")
    print("\n  5️⃣  Build bitstream:")
    print(f"      {cli_cmd} bitstream")
    print("\n  🐚 Tab completion is auto-activated in .venv/bin/activate.")
    print(f'     For system-wide setup: eval "$({cli_cmd} completion bash)"')
    print("\n" + "-" * 60)
    print(f"💡 Run '{cli_cmd} --help' for the full list of available commands.")
    print("-" * 60 + "\n")


def main():
    """CLI entry point for project scaffolding."""
    args = _parse_args()
    if args is None:
        # --list-templates or --template were handled inside _parse_args
        return

    print(BANNER)
    from routertl_core import __copyright__, __version__
    print(f"  v{__version__}  •  {__copyright__}\n")
    print("🚀 Initializing new RouteRTL project...\n")

    if os.path.exists("project.yml") and not args.dry_run:
        print("❌ Error: 'project.yml' already exists in this directory!")
        print("   Aborting to prevent overwriting.")
        sys.exit(1)

    config = _collect_config(args)

    if args.dry_run:
        print("\n--- Dry Run: project.yml content ---")
        print(config["content"])
        print("--- End Dry Run ---")
        return

    _scaffold_project(config, args)
    _install_hooks_and_guide(args)

    if not args.no_venv:
        setup_python_env(args.sdk_path)

    check_environment()
    _check_lfs()
    _print_quick_start(config, args)


if __name__ == "__main__":
    main()
