# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

import logging
import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import pathspec

from sdk.cli.console import console as _dep_con


class DependencyResolver:
    """
    Parses VHDL and Verilog/SystemVerilog files to resolve entity/module and package dependencies.
    """


    def __init__(self, src_paths: List[Path], verbose: bool = False,
                 respect_gitignore: bool = True):
        """Create a dependency resolver for the given project root.

        Parameters
        ----------
        src_paths : list[Path]
            Directories to scan for HDL sources.
        verbose : bool
            Enable debug logging.
        respect_gitignore : bool
            When ``True`` (default), files matched by ``.gitignore`` rules
            are excluded from discovery.  Falls back gracefully (includes
            all files) when not inside a git repository.
        """
        self.src_paths = src_paths
        self.verbose = verbose
        self._log = logging.getLogger(__name__)
        if verbose:
            self._log.setLevel(logging.DEBUG)

        self.entity_map = {}  # Maps Entity/Module Name -> Path
        self.package_map = {}  # Maps Package Name -> Path
        self.filename_map = {}  # Maps Filename -> Path (for includes)

        self.entity_lib_map = {}  # VHDL Specific: Entity -> Library
        self.package_lib_map = {}  # VHDL Specific: Package -> Library (from use clauses)

        # P2.99: Per-file parse caches — keyed by (resolved_path, mtime)
        self._vhdl_pkg_cache: Dict[tuple, List[str]] = {}
        self._vhdl_inst_cache: Dict[tuple, List[Tuple[str, str]]] = {}
        self._verilog_dep_cache: Dict[tuple, Tuple[List[str], List[str], List[str]]] = {}
        # P2.99: Shared forward graph cache
        self._forward_graph_cache: Optional[Dict] = None

        self._gitignore_spec: Optional[pathspec.PathSpec] = None
        self._git_root: Optional[Path] = None
        if respect_gitignore:
            self._gitignore_spec, self._git_root = self._load_gitignore_spec()

        self._build_maps()

    def _load_gitignore_spec(self):
        """Walk up from the first source path to find the repo root and parse ``.gitignore``.

        Returns
        -------
        tuple[pathspec.PathSpec | None, Path | None]
            ``(spec, git_root)`` or ``(None, None)`` when not inside a git repo.
        """
        # Determine a starting point — prefer the first valid src_path
        start = None
        for sp in self.src_paths:
            if sp.exists():
                start = sp.resolve()
                break
        if start is None:
            return None, None

        # Walk up to find .git/
        candidate = start if start.is_dir() else start.parent
        git_root = None
        while True:
            if (candidate / ".git").exists():
                git_root = candidate
                break
            parent = candidate.parent
            if parent == candidate:
                break  # reached filesystem root
            candidate = parent

        if git_root is None:
            self._log.debug("No .git found — gitignore filtering disabled")
            return None, None

        # Collect .gitignore patterns
        gitignore_file = git_root / ".gitignore"
        if not gitignore_file.exists():
            self._log.debug(".gitignore not found at repo root — no patterns to filter")
            return None, None

        lines = gitignore_file.read_text(errors="replace").splitlines()
        spec = pathspec.PathSpec.from_lines("gitignore", lines)
        self._log.debug("Loaded %d gitignore patterns from %s", len(spec.patterns), gitignore_file)
        return spec, git_root

    def _is_gitignored(self, path: Path) -> bool:
        """Check whether *path* is matched by the repo's ``.gitignore``.

        Returns ``False`` when gitignore filtering is disabled (no spec loaded).
        Also returns ``False`` for paths under explicitly-requested source
        directories that are *themselves* gitignored (e.g. ``.venv/…/src/units``).
        This prevents pip-installed SDK files from being skipped while still
        respecting gitignored subdirectories within normal project source trees.
        """
        if self._gitignore_spec is None or self._git_root is None:
            return False
        resolved = path.resolve()
        # Exempt files under --src dirs that are themselves gitignored.
        # Example: --src .venv/lib/.../src/units → .venv is gitignored,
        # so the entire dir is exempt.  But --src hw/rtl with hw/rtl/gen/
        # gitignored → files in gen/ are still filtered.
        for src in self.src_paths:
            src_resolved = src.resolve()
            try:
                resolved.relative_to(src_resolved)
            except ValueError:
                continue
            # This path is under an explicit --src dir.  Check if the
            # src dir itself would be gitignored — if so, exempt.
            try:
                src_rel = src_resolved.relative_to(self._git_root)
                if self._gitignore_spec.match_file(str(src_rel)):
                    return False  # src dir is gitignored → exempt its files
            except ValueError:
                return False  # src dir outside repo → exempt
            break  # src dir is NOT gitignored → apply normal check
        try:
            rel = resolved.relative_to(self._git_root)
        except ValueError:
            return False  # outside repo — not ignored
        return self._gitignore_spec.match_file(str(rel))

    def _build_maps(self):
        """Scans all source paths to build lookup maps for entities, modules, and packages."""
        # VHDL Regex
        # Original simple regexes working for general cases
        VHDL_ENTITY_RE = re.compile(r"(?i)entity\s+(\w+)\s+is")
        # Fix V13: negative lookahead prevents 'package body foo' → name='body'
        VHDL_PACKAGE_RE = re.compile(r"(?i)package\s+(?!body\b)(\w+)\s+is")
        # Match: label : entity lib.ent
        VHDL_dENTITY_INSTANCE_RE = re.compile(
            r"(?P<label>\w+)\s*:\s*entity\s+(?P<lib>\w+)\.(?P<ent>\w+)", re.IGNORECASE
        )
        # Match: use <lib>.<pkg>[.all];
        VHDL_USE_RE = re.compile(r"use\s+(?P<lib>\w+)\.(?P<pkg>\w+)(?:\.all)?\s*;", re.IGNORECASE)
        STANDARD_LIBS = {"ieee", "std", "work", "unisim", "unimacro"}

        # Verilog/SV Regex
        # Module definition: module name ( ...
        VERILOG_MODULE_RE = re.compile(r"^\s*module\s+(\w+)\b", re.MULTILINE)
        # SV Package definition: package name;
        SV_PACKAGE_RE = re.compile(r"^\s*package\s+(\w+)\s*;", re.MULTILINE)
        # Fix S10: SV Interface definition: interface name ...
        SV_INTERFACE_RE = re.compile(r"^\s*interface\s+(\w+)\b", re.MULTILINE)

        for src_dir in self.src_paths:
            if not src_dir.exists():
                self._log.warning("Source directory not found: %s", src_dir)
                continue

            # Scan VHDL
            for vhd_path in src_dir.rglob("*.vhd"):
                if self._is_gitignored(vhd_path):
                    self._log.debug("Skipping gitignored file: %s", vhd_path)
                    continue
                self._parse_vhdl_file(
                    vhd_path, VHDL_ENTITY_RE, VHDL_PACKAGE_RE, VHDL_dENTITY_INSTANCE_RE, VHDL_USE_RE, STANDARD_LIBS
                )

            # Scan Verilog/SV
            for ext in ["*.v", "*.sv", "*.vh", "*.svh"]:
                for v_path in src_dir.rglob(ext):
                    if self._is_gitignored(v_path):
                        self._log.debug("Skipping gitignored file: %s", v_path)
                        continue
                    self._parse_verilog_file(v_path, VERILOG_MODULE_RE, SV_PACKAGE_RE, SV_INTERFACE_RE)

    def _parse_vhdl_file(self, path: Path, entity_re, package_re, instance_re, use_re, standard_libs):
        try:
            text = path.read_text(errors="replace")
        except OSError as e:
            self._log.warning("Could not read %s: %s", path, e)
            self._log.debug("Full traceback:", exc_info=True)
            return

        # Fix V14: Map ALL entities in the file (not just the first)
        for match in entity_re.finditer(text):
            entity_name = match.group(1)
            self.entity_map[entity_name] = path.resolve()

        # Fix V14: Map ALL packages in the file (not just the first)
        for match in package_re.finditer(text):
            pkg_name = match.group(1)
            self.package_map[pkg_name] = path.resolve()

        # Map Entity -> Library (from instantiations) for checking
        for _, lib, ent in instance_re.findall(text):
            if ent not in self.entity_lib_map:
                self.entity_lib_map[ent] = lib

        # Map Package -> Library (from use clauses)
        for m in use_re.finditer(text):
            lib_name = m.group("lib").lower()
            pkg_name = m.group("pkg")
            if lib_name not in standard_libs:
                if pkg_name not in self.package_lib_map:
                    self.package_lib_map[pkg_name] = m.group("lib")

    def _parse_verilog_file(self, path: Path, module_re, package_re, interface_re=None):
        try:
            text = path.read_text(errors="replace")
        except OSError as e:
            self._log.warning("Could not read %s: %s", path, e)
            self._log.debug("Full traceback:", exc_info=True)
            return

        real_path = path.resolve()
        self.filename_map[path.name] = real_path

        # Map Modules
        for match in module_re.finditer(text):
            module_name = match.group(1)
            self.entity_map[module_name] = real_path

        # Fix S10: Map SV interfaces into entity_map
        if interface_re:
            for match in interface_re.finditer(text):
                iface_name = match.group(1)
                self.entity_map[iface_name] = real_path

        # Map Packages
        for match in package_re.finditer(text):
            pkg_name = match.group(1)
            self.package_map[pkg_name] = real_path

    # VHDL keywords to exclude from default-binding heuristic (Fix V3)
    _VHDL_KEYWORDS = frozenset({
        "process", "entity", "component", "architecture", "begin", "end",
        "signal", "variable", "constant", "type", "subtype", "function",
        "procedure", "if", "for", "while", "case", "assert", "report",
        "generate", "block", "port", "generic", "map", "when", "others",
        "is", "of", "in", "out", "inout", "buffer", "downto", "to",
        "loop", "not", "and", "or", "xor", "nand", "nor", "xnor",
        "null", "open", "return", "exit", "next", "then", "else",
        "elsif", "select", "with", "after", "wait", "until", "library",
        "use", "all", "package", "body", "configuration", "attribute",
        "alias", "file", "access", "record", "array", "range",
        "natural", "positive", "integer", "boolean", "bit", "std_logic",
        "std_logic_vector", "unsigned", "signed", "rising_edge",
        "falling_edge", "true", "false",
    })

    def find_instantiated_entities_vhdl(self, vhdl_path: Path) -> List[Tuple[str, str]]:
        """Finds all direct entity, component, and default-binding instantiations in a VHDL file."""
        resolved = vhdl_path.resolve()
        try:
            mtime = resolved.stat().st_mtime
        except OSError:
            mtime = 0
        cache_key = (resolved, mtime)
        if cache_key in self._vhdl_inst_cache:
            return self._vhdl_inst_cache[cache_key]

        text = vhdl_path.read_text(errors="replace")

        # Pattern 1: label : entity lib.ent  (explicit entity instantiation)
        ENTITY_INSTANCE_RE = re.compile(r"(?P<label>\w+)\s*:\s*entity\s+(?P<lib>\w+)\.(?P<ent>\w+)", re.IGNORECASE)
        entity_matches = ENTITY_INSTANCE_RE.findall(text)
        results = {(lib, ent) for _, lib, ent in entity_matches}

        # Pattern 2: label : component Name  (VHDL-2008 component instantiation)
        # Maps to ("work", Name) since no library qualifier is given.
        COMPONENT_INSTANCE_RE = re.compile(r"\w+\s*:\s*component\s+(\w+)", re.IGNORECASE)
        for m in COMPONENT_INSTANCE_RE.finditer(text):
            comp_name = m.group(1)
            # Only add if it's a known entity (avoid matching keywords)
            if comp_name in self.entity_map:
                results.add(("work", comp_name))

        # Fix V3+V4: Default-binding component instantiation
        # Matches: label : ComponentName port map|generic map|(
        # Excludes already-caught patterns (entity/component keyword) and VHDL keywords.
        DEFAULT_BIND_RE = re.compile(
            r"(\w+)\s*:\s*(\w+)\s+(?:generic\s+map|port\s+map)",
            re.IGNORECASE,
        )
        for m in DEFAULT_BIND_RE.finditer(text):
            comp_name = m.group(2)
            if comp_name.lower() not in self._VHDL_KEYWORDS and comp_name in self.entity_map:
                results.add(("work", comp_name))

        result = list(results)
        self._vhdl_inst_cache[cache_key] = result
        return result

    def find_vhdl_packages(self, vhdl_path: Path) -> List[str]:
        """Finds all 'use library.package[.all|.item]' clauses that reference known packages.

        Matches any ``use <lib>.<name>.all;`` or ``use <lib>.<name>.<item>;``
        clause and then filters the results against ``package_map`` so only
        actual project packages are returned.  This handles both the ``_pkg``
        suffix convention (e.g. ``math_pkg``) and prefix conventions used by
        libraries like Open Logic (e.g. ``olo_base_pkg_math``).
        """
        resolved = vhdl_path.resolve()
        try:
            mtime = resolved.stat().st_mtime
        except OSError:
            mtime = 0
        cache_key = (resolved, mtime)
        if cache_key in self._vhdl_pkg_cache:
            return self._vhdl_pkg_cache[cache_key]

        # Fix V12: also match 'use lib.pkg.item;' (not only '.all')
        USE_RE = re.compile(r"use\s+\w+\.(?P<pkg>\w+)(?:\.\w+)?\s*;", re.IGNORECASE)
        text = vhdl_path.read_text(errors="replace")
        matches = []
        seen = set()
        for m in USE_RE.finditer(text):
            pkg_name = m.group("pkg")
            # Only include if it's a known project package (avoids ieee.*, etc.)
            if pkg_name in self.package_map and pkg_name not in seen:
                matches.append(pkg_name)
                seen.add(pkg_name)
            elif f"{pkg_name}_pkg" in self.package_map and f"{pkg_name}_pkg" not in seen:
                matches.append(f"{pkg_name}_pkg")
                seen.add(f"{pkg_name}_pkg")
        self._vhdl_pkg_cache[cache_key] = matches
        return matches

    def find_verilog_dependencies(self, path: Path) -> Tuple[List[str], List[str], List[str]]:
        """
        Parses a Verilog/SV file for dependencies.
        Returns: (List[module_names], List[include_filenames], List[package_imports])
        """
        resolved = path.resolve()
        try:
            mtime = resolved.stat().st_mtime
        except OSError:
            mtime = 0
        cache_key = (resolved, mtime)
        if cache_key in self._verilog_dep_cache:
            return self._verilog_dep_cache[cache_key]

        text = path.read_text(errors="replace")

        # 1. Includes: `include "filename.vh"
        INCLUDE_RE = re.compile(r"`include\s+\"([^\"]+)\"")
        includes = INCLUDE_RE.findall(text)

        # 2. Imports: import pkg::* or import pkg::item;
        IMPORT_RE = re.compile(r"import\s+(\w+)::")
        imports = IMPORT_RE.findall(text)

        # 3. Instantiations
        # Heuristic: looks for "Module Name ( ... )"
        # We find all words that look like identifiers followed by identifiers (instance name) and (
        # Then we filter against known modules (entity_map).

        # Regex explanation:
        # \b(\w+)\s+       -> Capture generic type/module name (Group 1)
        # (?:#\s*\(.*?\)\s*)? -> Optional parameter map assignment #(...)
        #                        Note: .*? is non-greedy but single line. Multi-line params needs re.DOTALL or smarter regex.
        #                        Verilog params can be complex.
        # (\w+)\s*\(       -> Capture instance name (Group 2) and opening paren

        # Since regex for full Verilog parsing is fragile, we verify candidacy against self.entity_map

        POTENTIAL_INST_RE = re.compile(r"\b(\w+)\s+(?:#\s*\(.*?\)\s*)?(\w+)\s*\(", re.DOTALL)

        # This is expensive and potentially inaccurate.
        # Better approach: Find all words that ARE keys in entity_map.
        # If a word appears in the file and it is a known module, it's likely an instantiation
        # (unless it's the module definition itself).

        found_modules = set()

        # Strip comments to avoid false dependency edges from module
        # names appearing in // line comments or /* block comments */.
        stripped = re.sub(r'//[^\n]*', '', text)
        stripped = re.sub(r'/\*.*?\*/', '', stripped, flags=re.DOTALL)

        # Tokenize roughly
        tokens = set(re.findall(r"\w+", stripped))

        # Remove own module definitions from tokens to avoid self-reference cycles if names overlap (unlikely but possible)
        # But simpler: check if token is in entity_map
        for token in tokens:
            if token in self.entity_map:
                # We need to ensure we don't match the current module's name definition
                # But self.entity_map[token] might be THIS file.
                if self.entity_map[token] != resolved:
                    found_modules.add(token)

        # Use imports as well (packages)
        # If import found, add to found_modules (treated same as entities for resolution, just different map lookups later)
        found_packages = imports

        result = list(found_modules), includes, found_packages
        self._verilog_dep_cache[cache_key] = result
        return result

    def resolve_dependencies(self, top_entity: str) -> List[Path]:
        """
        Recursively resolves all dependencies for a top-level entity/module.
        Returns a list of deduplicated Paths in dependency order (leafs first).
        """
        return self._resolve_recursive(top_entity, set())

    def _resolve_recursive(self, entity_name: str, seen: Set[str]) -> List[Path]:
        if entity_name in seen:
            return []
        seen.add(entity_name)

        # Determine if it's a known entity/module
        if entity_name not in self.entity_map:
            # It might be in package map?
            if entity_name in self.package_map:
                path = self.package_map[entity_name]
            else:
                # Standard check for VHDL _pkg suffix convention
                if f"{entity_name}_pkg" in self.package_map:
                    path = self.package_map[f"{entity_name}_pkg"]
                    entity_name = f"{entity_name}_pkg"
                else:
                    self._log.debug("Entity/Module '%s' not found in source map", entity_name)
                    return []
        else:
            path = self.entity_map[entity_name]

        paths = []

        # Dispatch based on file type
        suffix = path.suffix.lower()
        if suffix in [".vhd", ".vhdl"]:
            # VHDL Resolution

            # 1. Packages
            packages = self.find_vhdl_packages(path)
            for pkg in packages:
                # Resolve package path
                pkg_paths = self._resolve_recursive(pkg, seen)
                paths.extend(pkg_paths)

            # 2. Instantiations
            deps = self.find_instantiated_entities_vhdl(path)
            for lib, sub_ent in deps:
                sub_paths = self._resolve_recursive(sub_ent, seen)
                paths.extend(sub_paths)

        elif suffix in [".v", ".sv", ".vh", ".svh"]:
            # Verilog Resolution
            modules, includes, pkgs = self.find_verilog_dependencies(path)

            # 1. Includes (Header files)
            # Fix S6: Recursively resolve include chains
            for inc in includes:
                if inc in self.filename_map:
                    inc_path = self.filename_map[inc]
                    if inc_path not in paths:
                        # Recursively parse the header for its own dependencies
                        try:
                            sub_mods, sub_incs, sub_pkgs = self.find_verilog_dependencies(inc_path)
                            # Resolve nested includes first (depth-first)
                            for sub_inc in sub_incs:
                                if sub_inc in self.filename_map:
                                    sub_inc_path = self.filename_map[sub_inc]
                                    if sub_inc_path not in paths:
                                        paths.append(sub_inc_path)
                            # Resolve nested package imports
                            for sub_pkg in sub_pkgs:
                                pkg_paths = self._resolve_recursive(sub_pkg, seen)
                                paths.extend(pkg_paths)
                        except (OSError, ValueError, KeyError):
                            self._log.debug("Failed to parse included header %s", inc_path, exc_info=True)
                        paths.append(inc_path)

            # 2. Packages (Imports)
            for pkg in pkgs:
                pkg_paths = self._resolve_recursive(pkg, seen)
                paths.extend(pkg_paths)

            # 3. Module Instantiations
            for mod in modules:
                sub_paths = self._resolve_recursive(mod, seen)
                paths.extend(sub_paths)

        # Remove duplicates, keeping LAST occurrence (Dependency Order for compilation: Leaves -> Root)
        # Wait, the previous logic was: [Top, Dep1, Dep2...] then reversed at end.
        # So we want [Top, Dep1, Dep2].
        # If Dep1 depends on Dep1_1, it returns [Dep1, Dep1_1] (recursively added to end)
        # So total: [Top, Dep1, Dep1_1, Dep2...]
        # Reversed: [..., Dep2, Dep1_1, Dep1, Top] -> Correct compilation order.

        paths.append(path)
        # Deduplicate
        return list(dict.fromkeys(paths))

    def get_compilation_order(self, top_entity: str) -> List[Path]:
        """Returns dependencies in correct compilation order (leaves -> root)."""
        deps = self.resolve_dependencies(top_entity)
        return list(deps)

    def _resolve_file_library(self, file_path: Path) -> str:
        """Determine which VHDL library a file's entity/package belongs to.

        Uses a reverse lookup map (Path → library) for O(1) resolution.
        The map is built lazily on first call.
        """
        # Lazy-build reverse map: resolved Path → library name
        if not hasattr(self, '_file_lib_cache'):
            cache: Dict[Path, str] = {}
            for ent_name, ent_path in self.entity_map.items():
                if ent_name in self.entity_lib_map:
                    cache[ent_path] = self.entity_lib_map[ent_name]
            for pkg_name, pkg_path in self.package_map.items():
                if pkg_name in self.package_lib_map:
                    cache[pkg_path] = self.package_lib_map[pkg_name]
            self._file_lib_cache = cache

        return self._file_lib_cache.get(file_path.resolve(), "work")

    def get_compilation_order_with_libs(self, top_entity: str) -> List[Tuple[str, Path]]:
        """Returns dependencies in compilation order with library tags.

        Each element is ``(library_name, path)`` where *library_name* is
        derived from ``entity_lib_map`` / ``package_lib_map``.  Files
        without an explicit library association default to ``'work'``.
        """
        deps = self.get_compilation_order(top_entity)
        result = []
        for dep_path in deps:
            suffix = dep_path.suffix.lower()
            if suffix in [".vhd", ".vhdl"]:
                lib = self._resolve_file_library(dep_path)
            else:
                lib = "work"
            result.append((lib, dep_path))
        return result

    def print_tree(self, entity: str, indent: int = 0, stack: Set[str] = None):
        """Prints the dependency tree to the console."""
        if stack is None:
            stack = set()

        prefix = "  " * indent
        if indent > 0:
            prefix += "└─ "

        # Check existence
        real_name = entity
        path = None

        if entity in self.entity_map:
            path = self.entity_map[entity]
        elif entity in self.package_map:
            path = self.package_map[entity]
        elif f"{entity}_pkg" in self.package_map:
            real_name = f"{entity}_pkg"
            path = self.package_map[real_name]

        if not path:
            _dep_con.print(f"{prefix}{entity} [[red]?[/]] (Not found)")
            return

        rel_path = path.name

        if entity in stack:
            _dep_con.print(f"{prefix}{entity} [{rel_path}] (Cycle)")
            return

        _dep_con.print(f"{prefix}{entity} [[green]{rel_path}[/]]")

        new_stack = stack.copy()
        new_stack.add(entity)

        # Dispatch children finding
        suffix = path.suffix.lower()
        children = []

        if suffix in [".vhd", ".vhdl"]:
            # Packages
            pkgs = self.find_vhdl_packages(path)
            for p in pkgs:
                children.append((p, "package"))
            # Entities
            ents = self.find_instantiated_entities_vhdl(path)
            for _, e in ents:
                children.append((e, "entity"))

        elif suffix in [".v", ".sv", ".vh", ".svh"]:
            mods, incs, pkgs = self.find_verilog_dependencies(path)
            for i in incs:
                children.append((i, "include"))
            for p in pkgs:
                children.append((p, "package"))
            for m in mods:
                children.append((m, "module"))

        for child_name, c_type in children:
            if c_type == "include":
                # Special print for include
                p_prefix = "  " * (indent + 1) + "├─ "
                found_path = self.filename_map.get(child_name)
                FOUND = f"[[green]{found_path.name}[/]]" if found_path else "[[red]?[/]]"
                _dep_con.print(f'{p_prefix}`include "{child_name}" {FOUND}')
            else:
                self.print_tree(child_name, indent + 1, new_stack)

    def _build_forward_graph(self) -> Dict:
        """Build and cache the forward dependency graph.

        Returns a dict with:
        - ``graph``: ``{name: set(children)}``
        - ``in_degree``: ``{name: int}``
        - ``all_nodes``: ``set`` of all entity and package names

        The result is cached for the lifetime of this resolver instance.
        Parse caches on the individual file-reading methods ensure that
        repeated calls to ``resolve_forest``, ``reverse_dependents``, and
        ``export_graph`` within the same invocation avoid redundant disk I/O.
        """
        if self._forward_graph_cache is not None:
            return self._forward_graph_cache

        graph: Dict[str, Set[str]] = defaultdict(set)
        in_degree: Dict[str, int] = defaultdict(int)

        all_nodes = set(self.entity_map.keys()) | set(self.package_map.keys())
        for n in all_nodes:
            in_degree[n] = 0

        # Build edges from entities only (packages are leaf deps)
        for name, path in self.entity_map.items():
            children: list = []
            suffix = path.suffix.lower()
            if suffix in [".vhd", ".vhdl"]:
                children.extend(self.find_vhdl_packages(path))
                children.extend([e for _, e in self.find_instantiated_entities_vhdl(path)])
            elif suffix in [".v", ".sv", ".vh", ".svh"]:
                mods, _incs, pkgs = self.find_verilog_dependencies(path)
                children.extend(mods)
                children.extend(pkgs)

            for child in children:
                real_child = child
                if child not in all_nodes and f"{child}_pkg" in self.package_map:
                    real_child = f"{child}_pkg"
                if real_child in all_nodes:
                    graph[name].add(real_child)
                    in_degree[real_child] += 1

        self._forward_graph_cache = {
            "graph": dict(graph),
            "in_degree": dict(in_degree),
            "all_nodes": all_nodes,
        }
        return self._forward_graph_cache

    def resolve_forest(self) -> Dict:
        """
        Builds a complete forest of the project.

        Returns a dict with:
        - ``trees``: list of root hierarchies, each with ``top``, ``path``, ``files``, ``weight``
        - ``orphans``: list of file paths not covered by any hierarchy
        - ``graph``: dict mapping entity name → set of child entity names (instantiation edges)
        """
        fg = self._build_forward_graph()
        graph = fg["graph"]
        in_degree = fg["in_degree"]
        all_nodes = fg["all_nodes"]

        # Roots
        roots = [n for n in all_nodes if in_degree[n] == 0]

        # Filter: Roots should be likely Top Levels.
        # Packages with 0 in-degree are just unused packages, rarely "roots" in the sense of a Top Module.
        # So we prefer nodes in entity_map over package_map for "Top Level Candidates"
        real_roots = [r for r in roots if r in self.entity_map]

        trees = []
        covered_files = set()

        for root in real_roots:
            # Resolve
            file_paths = self.get_compilation_order(root)
            if not file_paths:
                continue

            weight = len(file_paths)
            str_paths = [str(p) for p in file_paths]
            for p in file_paths:
                covered_files.add(p)

            trees.append({"top": root, "path": str(self.entity_map[root]), "files": str_paths, "weight": weight})

        trees.sort(key=lambda x: x["weight"], reverse=True)

        # Orphans
        all_source_files = set(self.entity_map.values()) | set(self.package_map.values())
        orphans = list(all_source_files - covered_files)
        orphans_str = [str(p) for p in orphans]

        # Convert graph to serializable form (sets → lists)
        graph_serializable = {k: list(v) for k, v in graph.items()}

        return {"trees": trees, "orphans": orphans_str, "graph": graph_serializable}

    def reverse_dependents(self, target_path: Path) -> List[str]:
        """Return all entities/modules that transitively depend on *target_path*.

        Uses the cached forward graph from ``_build_forward_graph()`` and
        walks the reverse edges upward, collecting every entity/module
        whose compilation order includes the given file.
        """
        target_path = target_path.resolve()

        fg = self._build_forward_graph()
        forward = fg["graph"]
        all_nodes = fg["all_nodes"]

        # Also build edges for package nodes (forward graph only has entities)
        full_forward: Dict[str, Set[str]] = defaultdict(set)
        for k, v in forward.items():
            full_forward[k] = set(v)
        for name in all_nodes:
            if name in self.entity_map:
                continue  # already covered by forward graph
            path = self.package_map.get(name)
            if not path:
                continue
            children: list = []
            suffix = path.suffix.lower()
            if suffix in [".vhd", ".vhdl"]:
                children.extend(self.find_vhdl_packages(path))
                children.extend([e for _, e in self.find_instantiated_entities_vhdl(path)])
            elif suffix in [".v", ".sv", ".vh", ".svh"]:
                mods, _incs, pkgs = self.find_verilog_dependencies(path)
                children.extend(mods)
                children.extend(pkgs)
            for child in children:
                real_child = child
                if child not in all_nodes and f"{child}_pkg" in self.package_map:
                    real_child = f"{child}_pkg"
                if real_child in all_nodes:
                    full_forward[name].add(real_child)

        # Reverse graph:  child → {parent, …}
        reverse: Dict[str, Set[str]] = defaultdict(set)
        for parent, kids in full_forward.items():
            for kid in kids:
                reverse[kid].add(parent)

        # Find names whose source file matches target_path
        seeds: Set[str] = set()
        for name, path in {**self.entity_map, **self.package_map}.items():
            if path.resolve() == target_path:
                seeds.add(name)

        if not seeds:
            return []

        # BFS upward through reverse edges
        visited: Set[str] = set()
        queue = deque(seeds)
        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            for parent in reverse.get(current, set()):
                if parent not in visited:
                    queue.append(parent)

        # Remove the seeds themselves — callers want *dependents*, not self
        visited -= seeds
        return sorted(visited)

    def export_graph(self, fmt: str = "mermaid") -> str:
        """Export the dependency forest as Mermaid, HTML, or JSON.

        Parameters
        ----------
        fmt : str
            Output format: ``"mermaid"``, ``"html"``, or ``"json"``.

        Returns
        -------
        str
            The rendered graph string in the requested format.
        """
        import json as _json

        forest = self.resolve_forest()
        trees = forest.get("trees", [])
        orphans = forest.get("orphans", [])

        fg = self._build_forward_graph()
        forward = fg["graph"]
        all_nodes = fg["all_nodes"]

        # Also collect edges from package nodes for complete graph rendering
        edges: list[tuple[str, str]] = []
        node_set: set[str] = set()

        for name in all_nodes:
            path = self.entity_map.get(name) or self.package_map.get(name)
            if not path:
                continue
            children: list[str] = []
            suffix = path.suffix.lower()
            if suffix in [".vhd", ".vhdl"]:
                children.extend(self.find_vhdl_packages(path))
                children.extend([e for _, e in self.find_instantiated_entities_vhdl(path)])
            elif suffix in [".v", ".sv", ".vh", ".svh"]:
                mods, _incs, pkgs = self.find_verilog_dependencies(path)
                children.extend(mods)
                children.extend(pkgs)
            for child in children:
                real_child = child
                if child not in all_nodes and f"{child}_pkg" in self.package_map:
                    real_child = f"{child}_pkg"
                if real_child in all_nodes:
                    edges.append((name, real_child))
                    node_set.update([name, real_child])

        # Track roots for coloring
        root_names = {t["top"] for t in trees}
        pkg_names = set(self.package_map.keys())

        if fmt == "json":
            return _json.dumps(
                {
                    "nodes": sorted(node_set),
                    "edges": [{"from": a, "to": b} for a, b in edges],
                    "roots": sorted(root_names),
                    "packages": sorted(pkg_names & node_set),
                    "orphans": orphans,
                },
                indent=2,
            )

        # ── Mermaid ──
        lines = ["graph TD"]

        # Node declarations with labels
        for node in sorted(node_set):
            safe = node.replace("-", "_")
            if node in root_names:
                lines.append(f'    {safe}["{node}"]')
            elif node in pkg_names:
                lines.append(f'    {safe}(["{node}"])')
            else:
                lines.append(f'    {safe}["{node}"]')

        # Edges
        for a, b in sorted(set(edges)):
            lines.append(f"    {a.replace('-', '_')} --> {b.replace('-', '_')}")

        # Styles — curated palette per user rules
        for node in sorted(node_set):
            safe = node.replace("-", "_")
            if node in root_names:
                lines.append(f"    style {safe} fill:#2d5016,stroke:#4a8c2a,color:#fff")
            elif node in pkg_names:
                lines.append(f"    style {safe} fill:#1a3a5c,stroke:#2980b9,color:#fff")
            else:
                lines.append(f"    style {safe} fill:#4a2d50,stroke:#8e44ad,color:#fff")

        mermaid_src = "\n".join(lines)

        if fmt == "mermaid":
            return mermaid_src

        # ── HTML — self-contained with mermaid.js CDN ──
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>RouteRTL Dependency Graph</title>
  <script src="https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"></script>
  <style>
    body {{ background: #111; color: #eee; font-family: sans-serif; padding: 2rem; }}
    h1 {{ color: #4aa3df; }}
    .mermaid {{ background: #1a1a2e; padding: 1rem; border-radius: 8px; }}
  </style>
</head>
<body>
  <h1>RouteRTL — Dependency Graph</h1>
  <p>{len(node_set)} nodes, {len(edges)} edges, {len(root_names)} top-level root(s)</p>
  <div class="mermaid">
{mermaid_src}
  </div>
  <script>mermaid.initialize({{ startOnLoad: true, theme: 'dark' }});</script>
</body>
</html>"""
        return html

    def resolve_packages(self) -> List[Path]:
        """Returns a list of all packages sorted by dependency."""
        pkg_paths_set = set(self.package_map.values())
        sorted_dict = {}

        # We iterate over all known packages
        for name in self.package_map.keys():
            # Get full dependency chain for this package
            # This returns [leaf, ..., root]
            deps = self.get_compilation_order(name)

            for d in deps:
                if d in pkg_paths_set:
                    sorted_dict[d] = None

        return list(sorted_dict.keys())

    def discover_libraries(self) -> Dict[str, List[str]]:
        """Auto-discover VHDL library memberships from source code.

        Scans ``entity_lib_map`` (from ``entity lib.X`` instantiations) and
        ``package_lib_map`` (from ``use lib.pkg.all`` clauses) to build a
        map of ``{library_name: [absolute_file_paths]}``.

        Standard libraries (ieee, std, work, unisim, unimacro) are excluded.

        Returns
        -------
        dict
            Mapping of library name to list of absolute file path strings.
        """
        STANDARD_LIBS = {"ieee", "std", "work", "unisim", "unimacro"}
        libs: Dict[str, set] = defaultdict(set)

        # Entity -> Library (from instantiations: entity tich.edge_detector)
        for ent_name, lib_name in self.entity_lib_map.items():
            if lib_name.lower() in STANDARD_LIBS:
                continue
            if ent_name in self.entity_map:
                libs[lib_name].add(str(self.entity_map[ent_name]))

        # Package -> Library (from use clauses: use tich.system_config_pkg.all)
        for pkg_name, lib_name in self.package_lib_map.items():
            if lib_name.lower() in STANDARD_LIBS:
                continue
            if pkg_name in self.package_map:
                libs[lib_name].add(str(self.package_map[pkg_name]))

        # Convert sets to sorted lists for deterministic output
        return {lib: sorted(files) for lib, files in libs.items()}


def main():
    """CLI entry point for the dependency resolver."""
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Resolve VHDL/Verilog dependencies and print hierarchy.")
    parser.add_argument("--src", action="append", nargs="+", help="Source directories to scan (default: src)")
    parser.add_argument("--top", help="Top level entity/module name")
    parser.add_argument("--list", action="store_true", help="Print ordered list of source files (space separated)")
    parser.add_argument(
        "--list-libs", action="store_true", help="Print ordered list as lib:path pairs (space separated)"
    )
    parser.add_argument("--forest", action="store_true", help="Output JSON with full project forest (trees only)")
    parser.add_argument("--sort-pkgs", action="store_true", help="Print topologically sorted list of all packages")
    parser.add_argument("--discover-libs", action="store_true", help="Auto-discover VHDL library memberships from source (JSON output)")
    parser.add_argument(
        "--no-respect-gitignore", action="store_true",
        help="Include gitignored files in discovery (default: exclude them)",
    )

    args = parser.parse_args()

    if args.src:
        flat_srcs = [item for sublist in args.src for item in sublist]
        src_dirs = [Path(p) for p in flat_srcs]
    else:
        # Default behavior: look for common dirs
        defaults = ["src", "sim", "ip"]
        src_dirs = []
        for d in defaults:
            if Path(d).exists():
                src_dirs.append(Path(d))

    if not src_dirs:
        import sys
        print("Warning: no source directories found. Use --src to specify, or create src/, sim/, ip/.", file=sys.stderr)

    resolver = DependencyResolver(
        src_dirs,
        respect_gitignore=not getattr(args, "no_respect_gitignore", False),
    )

    if args.forest:
        forest = resolver.resolve_forest()
        print(json.dumps(forest, indent=2))

    elif args.discover_libs:
        libs = resolver.discover_libraries()
        print(json.dumps(libs, indent=2))

    elif args.sort_pkgs:
        pkgs = resolver.resolve_packages()
        print(" ".join([str(p) for p in pkgs]))

    elif args.top:
        if getattr(args, "list_libs", False):
            pairs = resolver.get_compilation_order_with_libs(args.top)
            print(" ".join([f"{lib}:{path}" for lib, path in pairs]))
        elif args.list:
            files = resolver.get_compilation_order(args.top)
            print(" ".join([str(f) for f in files]))
        else:
            print(f"\nDependency Tree for '{args.top}':")
            print("========================================")
            resolver.print_tree(args.top)
            print()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

