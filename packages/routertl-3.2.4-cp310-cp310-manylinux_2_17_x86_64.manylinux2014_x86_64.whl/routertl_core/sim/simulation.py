# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

"""
Unified simulation orchestrator for cocotb testbenches.

Provides a single entry point for running simulations with NVC or GHDL,
handling library compilation, elaboration, and test execution seamlessly.

This module replaces the fragmented setupGhdlSim.py and setup_simulators.py
with a unified, backend-agnostic interface.

Example usage:
    from engine.simulation import run_simulation

    run_simulation(
        top_level="edge_detector",
        module="test_edge_detector",
        generics={"DATA_WIDTH": 32},
        simulator="nvc",
        waves=True,
    )
"""

import os
import sys
from typing import Dict, List, Optional

from engine.paths import (
    COCOTB_ROOT,
    COCOTB_VERBOSE,
    LOGS_DIR,
    PROJECT_ROOT,
    SDK_ROOT,
    TESTS_PATH,
    WAVES_DIR,
    ensure_dir,
    get_build_dir_for_simulator,
)

from .backends import get_backend
from .library_compiler import LibraryCompiler


def run_simulation(
    top_level: str,
    module: str,
    top_level_lang: str = "vhdl",
    generics: Optional[Dict[str, any]] = None,
    hdl_sources: Optional[List[str]] = None,
    custom_libraries: Optional[Dict[str, List[str]]] = None,
    simulator: Optional[str] = None,
    work_lib: str = "work",
    extra_env: Optional[Dict[str, str]] = None,
    waves: bool = True,
    verbose: Optional[bool] = None,
    build_args: Optional[List[str]] = None,
    includes: Optional[List[str]] = None,
    strict_warnings: bool = False,
    seed: Optional[int] = None,
    test_args: Optional[List[str]] = None,
    wave_formats: Optional[List[str]] = None,
) -> None:
    """
    Run a cocotb simulation with automatic library compilation.

    Provides a unified interface to run simulations with different backends
    (GHDL, NVC, etc.). Handles library compilation, caching, elaboration,
    and waveform generation.

    Args:
        top_level: Name of the top-level VHDL entity or Verilog module
        module: Name of the Python test module (e.g., 'test_edge_detector')
                Should match a test file in sim/cocotb/tests/
        top_level_lang: Language of top-level module ('vhdl' or 'verilog').
                       Default: 'vhdl'
        generics: Dict of VHDL generics or Verilog parameters to override.
                 Example: {'DATA_WIDTH': 32, 'ENABLE_DEBUG': True}
                 Default: None (use defaults)
        vhdl_sources: Deprecated, use hdl_sources instead.
                     Default: None (empty list)
        hdl_sources: List of additional HDL source files to compile.
                    Supports VHDL, Verilog, and SystemVerilog.
                    Can be absolute paths or relative to project root.
                    Default: None (empty list)
        custom_libraries: Provide a custom library dict.
                         Format: {'lib_name': ['file1.vhd', 'file2.vhd'], ...}
                         Default: None (empty dictionary)
        simulator: Force specific simulator ('nvc', 'ghdl', etc.).
                  If not specified, reads from $SIM environment variable.
                  Falls back to 'nvc' if not set.
                  Default: None
        extra_env: Extra environment variables to pass to simulator.
                  Example: {'COCOTB_LOG_LEVEL': 'DEBUG'}
                  Default: None
        waves: Generate waveform files (VCD, GHW, FST formats).
              Default: True
        verbose: Enable detailed logging of all steps.
                If not specified, reads from $COCOTB_VERBOSE environment variable.
                Default: None (auto-detect)
        build_args: Extra build arguments forwarded to the simulator
                   (e.g., ['-Wno-WIDTHEXPAND'] for Verilator).
                   Default: None
        includes: List of include directories for Verilog/SV
                 (e.g., ['src/includes/']). Default: None
        strict_warnings: If False (default), Verilator injects -Wno-fatal
                        so benign warnings don't abort compilation.
                        Default: False
        test_args: Extra arguments forwarded to the simulator test/run phase
                  (e.g., ['-t', '1ps'] for Questa timescale resolution).
                  Default: None
        wave_formats: List of waveform formats to produce (e.g., ['fst', 'vcd']).
                     Overrides project.yml ``simulation.waves.formats``.
                     If None, reads from project.yml, then defaults to ['fst'].

    Raises:
        ValueError: If simulator not supported or other configuration error
        RuntimeError: If compilation or simulation fails
        subprocess.CalledProcessError: If backend commands fail

    Returns:
        dict: JSON summary of the simulation results, or None if results
              could not be collected.

    Example:
        # Run NVC simulation with custom generics
        run_simulation(
            top_level="edge_detector",
            module="test_edge_detector",
            generics={
                "CONF_CR_MAX_WINDOW_CNT": 6000,
                "CONF_CR_MIN_WINDOW_CNT": 1400,
            },
            simulator="nvc",
            waves=True,
            verbose=True,
        )

        # Run NVC simulation (auto-detect from $SIM)
        os.environ["SIM"] = "nvc"
        run_simulation(
            top_level="top_module",
            module="test_top",
        )

        # Use custom library set
        my_libs = {
            "work": ["src/my_design.vhd"],
            "utils": ["src/utils_pkg.vhd"],
        }
        run_simulation(
            top_level="tb_top",
            module="test_tb",
            custom_libraries=my_libs,
        )
    """

    # Determine verbose setting
    if verbose is None:
        verbose = COCOTB_VERBOSE

    # Prepare libraries
    libraries = custom_libraries if custom_libraries is not None else {}

    # Auto-infer work_lib from custom_libraries when the caller is using
    # the default "work".  All project tests compile sources into a named
    # library (e.g. "tich"), but the NVC/GHDL elaborate step looks in
    # work_lib for the top-level entity.  If we leave work_lib="work" the
    # entity won't be found after a clean build (COCOTB_CLEAN=1).
    if work_lib == "work" and libraries:
        # Use the first custom library that is NOT a Xilinx/utility lib
        _infra_libs = {"unisim", "xpm", "utils"}
        for lib_name in libraries:
            if lib_name not in _infra_libs:
                work_lib = lib_name
                break

    # 1. Inspect sources for language detection
    has_vhdl = False
    has_verilog = False

    # Check extra sources
    if hdl_sources:
        for src in hdl_sources:
            if src.endswith((".v", ".sv")):
                has_verilog = True
            elif src.endswith(".vhd"):
                has_vhdl = True

    # Check libraries
    for libs in libraries.values():
        for src in libs:
            if src.endswith((".v", ".sv")):
                has_verilog = True
            elif src.endswith(".vhd"):
                has_vhdl = True

    # 2. Mixed-language detection (validated AFTER simulator selection below)
    is_mixed = has_vhdl and has_verilog

    # 3a. Read project.yml simulation config (always, for test_dir + waves).
    yml_test_dir = None
    _yml_sim_cfg = {}
    _yml_waves_cfg = {}
    _yml_logs_cfg = {}
    try:
        import yaml

        _yml_path = PROJECT_ROOT / "project.yml"
        if _yml_path.exists():
            with open(_yml_path) as f:
                _yml_cfg = yaml.safe_load(f) or {}
            _yml_sim_cfg = _yml_cfg.get("simulation") or {}
            if isinstance(_yml_sim_cfg, dict):
                yml_test_dir = _yml_sim_cfg.get("test_dir")
                _yml_waves_cfg = _yml_sim_cfg.get("waves") or {}
                _yml_logs_cfg = _yml_sim_cfg.get("logs") or {}
            else:
                _yml_sim_cfg = {}
    except Exception:
        pass

    # 3a-ii. Resolve wave_formats: kwarg → project.yml → default ['fst']
    if wave_formats is None:
        yml_formats = _yml_waves_cfg.get("formats") if isinstance(_yml_waves_cfg, dict) else None
        if yml_formats and isinstance(yml_formats, list):
            wave_formats = [f.lower().strip() for f in yml_formats]
        else:
            wave_formats = ["fst"]

    # 3a-iii. Resolve waves.enabled from project.yml (default: True)
    if isinstance(_yml_waves_cfg, dict) and "enabled" in _yml_waves_cfg:
        yml_waves_enabled = bool(_yml_waves_cfg["enabled"])
        if not yml_waves_enabled:
            waves = False

    # 3b. Determine simulator — unified precedence chain:
    #     explicit kwarg → $SIM env var → project.yml → language-based default → 'nvc'
    sim_source = "kwarg"  # tracks how simulator was selected
    if simulator is None:
        env_sim = os.environ.get("SIM", "").lower()
        if env_sim:
            simulator = env_sim
            sim_source = "env"
        else:
            yml_sim = _yml_sim_cfg.get("simulator") if _yml_sim_cfg else None

            if yml_sim:
                simulator = yml_sim.lower()
                sim_source = "project.yml"
            elif has_verilog:
                simulator = "verilator"
                sim_source = "auto"
            elif has_vhdl:
                simulator = "nvc"
                sim_source = "auto"
            else:
                simulator = "nvc"
                sim_source = "auto"

    # 4. Validate simulator name
    MIXED_CAPABLE = {"riviera", "questa", "xcelium", "activehdl"}
    VHDL_ONLY = {"ghdl", "nvc"}
    VERILOG_ONLY = {"verilator", "icarus"}
    ALL_SIMS = MIXED_CAPABLE | VHDL_ONLY | VERILOG_ONLY

    if simulator not in ALL_SIMS:
        raise ValueError(f"Unsupported simulator: {simulator}. Supported: {', '.join(sorted(ALL_SIMS))}")

    # 5. Mixed-language handling — check for mixed-capable sims or graceful skip
    is_ci = os.environ.get("CI") or os.environ.get("ROUTERTL_PRECOMMIT")
    if is_mixed:
        if simulator not in MIXED_CAPABLE:
            import shutil

            available_mixed = [s for s in MIXED_CAPABLE if shutil.which(s)]
            if available_mixed:
                old_sim = simulator
                simulator = available_mixed[0]
                print(
                    f"[Simulation] Mixed VHDL+Verilog detected. "
                    f"Auto-switching from '{old_sim}' to '{simulator}'."
                )
            elif is_ci and sim_source in ("env", "auto"):
                print(
                    "[Simulation] WARNING: Mixed VHDL+Verilog sources but no "
                    "mixed-language simulator available. Skipping test gracefully."
                )
                return  # graceful skip in CI/pre-commit
            else:
                raise ValueError(
                    f"Mixed VHDL + Verilog sources detected, but simulator '{simulator}' "
                    f"only supports one language. Install a mixed-language simulator "
                    f"(riviera, questa, xcelium, activehdl) or separate the source sets."
                )

    # 6. Smart override: $SIM env says VHDL-only but sources are pure Verilog
    if sim_source == "env" and simulator in VHDL_ONLY and has_verilog and not has_vhdl:
        print(
            f"[Simulation] Auto-switching from '{simulator}' to 'verilator' "
            f"(pure Verilog sources detected, $SIM override)"
        )
        simulator = "verilator"
    elif simulator in VHDL_ONLY and has_verilog:
        print(
            f"[Simulation] WARNING: Simulator is '{simulator}' but Verilog sources detected."
        )

    if simulator in VERILOG_ONLY and has_vhdl:
        print(f"[Simulation] WARNING: Simulator is '{simulator}' but VHDL sources detected.")

    if verbose:
        print(f"[Simulation] Starting simulation with {simulator}")
        print(f"  Top level: {top_level}")
        print(f"  Test module: {module}")
        print(f"  Language: {top_level_lang}")

    # Setup directories
    build_dir = get_build_dir_for_simulator(simulator)
    ensure_dir(build_dir)

    # Resolve wave output dir: project.yml → env var → engine default
    effective_waves_dir = WAVES_DIR
    if isinstance(_yml_waves_cfg, dict) and "output_dir" in _yml_waves_cfg:
        yml_wave_path = _yml_waves_cfg["output_dir"]
        if yml_wave_path and not os.environ.get("ROUTERTL_WAVES_DIR"):
            effective_waves_dir = (PROJECT_ROOT / yml_wave_path).resolve()

    wave_dir = effective_waves_dir if waves else None
    if wave_dir:
        # Create a subdirectory for this test module to keep outputs organized
        wave_dir = wave_dir / module
        ensure_dir(wave_dir)
        if verbose:
            print(f"  Wave directory: {wave_dir}")
            print(f"  Wave formats: {wave_formats}")

    # Resolve log output dir: project.yml → env var → engine default
    effective_logs_dir = LOGS_DIR
    if isinstance(_yml_logs_cfg, dict) and "output_dir" in _yml_logs_cfg:
        yml_log_path = _yml_logs_cfg["output_dir"]
        if yml_log_path and not os.environ.get("ROUTERTL_LOGS_DIR"):
            effective_logs_dir = (PROJECT_ROOT / yml_log_path).resolve()

    log_dir = effective_logs_dir / module
    ensure_dir(log_dir)
    log_file = log_dir / f"{module}.log"
    if verbose:
        print(f"  Log file: {log_file}")

    if verbose:
        print(f"  Libraries: {list(libraries.keys())}")

    # Get backend
    try:
        backend = get_backend(simulator, verbose=verbose)
    except ValueError as e:
        raise ValueError(f"Failed to initialize simulator: {e}")

    # Compile libraries
    if verbose:
        print(f"[Compilation] Compiling {len(libraries)} VHDL libraries...")

    compiler = LibraryCompiler(backend, verbose=verbose)
    try:
        compiler.compile_all(libraries, str(build_dir))
    except Exception as e:
        print(f"[ERROR] Library compilation failed: {e}")
        raise RuntimeError(f"Failed to compile libraries: {e}")

    # Run simulation
    if verbose:
        print("[Simulation] Running cocotb testbench...")

    # Ensure output log file is passed to backend
    sim_env = extra_env.copy() if extra_env else {}

    # Set random seed for reproducibility
    if seed is not None:
        sim_env["COCOTB_RANDOM_SEED"] = str(seed)
        if verbose:
            print(f"  Random seed: {seed}")

    # Inject paths into sys.path (NOT os.environ["PYTHONPATH"]).
    # cocotb_tools/runner.py:248 overwrites PYTHONPATH from sys.path,
    # so os.environ manipulation is dead code — sys.path is the only
    # way to get paths into the simulator subprocess.
    inject_paths = [str(PROJECT_ROOT), str(COCOTB_ROOT), str(SDK_ROOT.parent)]

    # Client project's cocotb root for dotted test module names (e.g. tests.ip.*).
    # Priority: simulation.test_dir from project.yml → default sim/cocotb/.
    # When test_dir is set (e.g. "hw/sim/cocotb/tests"), strip the trailing
    # /tests segment to get the cocotb root (e.g. "hw/sim/cocotb").
    if yml_test_dir:
        _test_dir_path = (PROJECT_ROOT / yml_test_dir).resolve()
        if _test_dir_path.name == "tests":
            client_cocotb = str(_test_dir_path.parent)
        else:
            client_cocotb = str(_test_dir_path)
    else:
        client_cocotb = str(PROJECT_ROOT / "sim" / "cocotb")
    if client_cocotb != str(COCOTB_ROOT):
        inject_paths.append(client_cocotb)

    # Auto-add test file's parent dir for flat module names (no dots).
    if "." not in module:
        candidates = list(TESTS_PATH.rglob(f"{module}.py"))
        if candidates:
            inject_paths.append(str(candidates[0].parent))

    for p in inject_paths:
        if p not in sys.path:
            sys.path.insert(0, p)

    if verbose:
        print(f"  sys.path injected: {inject_paths}")

    if "TB_LOG_DIR" not in sim_env:
        sim_env["TB_LOG_DIR"] = str(log_dir)

    try:
        backend.elaborate_and_run(
            top_level=top_level,
            module=module,
            work_lib=work_lib,
            build_dir=str(build_dir),
            wave_dir=str(wave_dir) if wave_dir else None,
            top_level_lang=top_level_lang,
            generics=generics or {},
            hdl_sources=hdl_sources or [],
            extra_env=sim_env,
            verbose=verbose,
            build_args=build_args,
            includes=includes,
            test_args=test_args,
            custom_libraries=libraries if libraries else None,
            wave_formats=wave_formats,
        )
    except Exception as e:
        print(f"[ERROR] Simulation failed: {e}")
        # Collect results even on failure (for history tracking)
        try:
            from .result_collector import collect_results

            collect_results(
                module=module,
                simulator=simulator,
                build_dir=str(build_dir),
                wave_dir=str(wave_dir) if wave_dir else None,
                verbose=verbose,
            )
        except Exception:
            pass  # Best-effort collection
        raise RuntimeError(f"Simulation execution failed: {e}")

    # Collect and persist results
    summary = None
    try:
        from .result_collector import collect_results

        summary = collect_results(
            module=module,
            simulator=simulator,
            build_dir=str(build_dir),
            wave_dir=str(wave_dir) if wave_dir else None,
            verbose=verbose,
        )
    except Exception as e:
        if verbose:
            print(f"[Results] Warning: result collection failed: {e}")

    if verbose:
        print("[Simulation] Completed successfully")
        if wave_dir:
            print(f"  Waveforms saved to: {wave_dir}")

    return summary
