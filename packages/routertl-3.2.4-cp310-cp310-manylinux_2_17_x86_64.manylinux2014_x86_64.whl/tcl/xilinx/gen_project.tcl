# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Author: Daniel J.Mazure, Tich
# Date: 09.09.2024
# Description:  Generates a Vivado project from the command line

if { $::argc >= 2} {
    set g_root_dir    [lindex $argv 0]
    set vhd_files     [lindex $argv 1]
    set xci_files     [lindex $argv 2]
    set sim_files     [lindex $argv 3]
    set tcl_files     [lindex $argv 4]
    set xdc_files     [lindex $argv 5]
    set netlist_files [lindex $argv 6] ;# Pre-compiled netlists (.dcp/.edf/.ngc)
    puts "Root dir is $g_root_dir"
} else {
    puts "Error: Not enough arguments \($::argc\), exiting ..."
    exit
}

# Resolve script directory for relative sourcing (SDK Support)
set script_path [file normalize [info script]]
set script_dir  [file dirname $script_path]
source "${script_dir}/environment.tcl"

################################################################
# START
################################################################

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
    create_project $g_project_name $g_project_dir -force -part $g_fpga_part
}
set thisProject [current_project]
set_property target_language VHDL $thisProject

# In case getting into the console later on
# cd [get_property DIRECTORY $thisProject]
# cd $g_root_directory

# This needs to be defined before creating the block design, if any
set ip_dir_list [get_property ip_repo_paths $thisProject]

# Add more IP dirs to the ip_paths variable before next loop

foreach ip_path $g_ip_paths {
  lappend ip_dir_list $ip_path
}
set_property ip_repo_paths $ip_dir_list $thisProject

#set vhd_files [glob ${g_root_dir}/src/*.vhd]; # This is coming from the Makefile as a filelist.
# vhd_files is comming from the Makefile. Same could be done for sim files, xdc files, xci or pkgs.
# Files comming from the Makefile definition is not working with WSL

# set vhd_files [glob ${g_root_dir}/src/*.vhd ${g_root_dir}/src/pkg/*.vhd]
# set xdc_files [glob ${g_root_dir}/xdc/system_*.xdc ]
# set sim_files [glob ${g_root_dir}/sim/tb* ${g_root_dir}/sim/pkg/*.vhd]

if { $xci_files ne "" } {
    import_ip "${xci_files}"
}

if { $vhd_files ne "" } {
    add_files ${vhd_files}
    set_property file_type {VHDL 2008} [get_files ${vhd_files}] 
}

if { $xdc_files ne "" } {
    add_files -fileset constrs_1 ${xdc_files}
    set_property used_in_synthesis false [get_files ${xdc_files}]
}

if { $sim_files ne "" } {
    add_files -fileset sim_1  ${sim_files}
    set_property file_type {VHDL 2008} [get_files ${sim_files}] 
}

set_property top $g_top_mod [current_fileset]

#update_compile_order -fileset sources_1
#update_compile_order -fileset sim_1


# Bring up the IP defined in the tcl files
foreach tcl_file $tcl_files {
    source $tcl_file
}

set_property top $g_top_sim [get_filesets sim_1]

set_property AUTO_INCREMENTAL_CHECKPOINT 0 [get_runs synth_1]
set_property incremental_checkpoint {} [get_runs synth_1]

# ---------------------------------------------------------------------------
# Pre-compiled netlists (.dcp checkpoint, .edf/.edif EDIF, .ngc legacy)
# ---------------------------------------------------------------------------
if {[info exists netlist_files]} {
    foreach f $netlist_files {
        if {[string trim $f] eq ""} { continue }
        if {[file pathtype $f] eq "absolute"} {
            set abs_f $f
        } else {
            set abs_f [file normalize $g_root_dir/$f]
        }
        set ext [string tolower [file extension $f]]
        if {$ext eq ".dcp"} {
            read_checkpoint -quiet $abs_f
            puts "Info: Read DCP checkpoint '$abs_f'"
        } elseif {$ext eq ".edf" || $ext eq ".edif" || $ext eq ".ngc"} {
            read_edif -quiet $abs_f
            puts "Info: Read EDIF netlist '$abs_f'"
        } elseif {$ext eq ".vhd" || $ext eq ".vhdl"} {
            read_vhdl -vhdl2008 $abs_f
        } elseif {$ext eq ".sv"} {
            read_verilog -sv $abs_f
        } elseif {$ext eq ".v"} {
            read_verilog $abs_f
        } else {
            puts "Warning: Unknown netlist extension '$ext' for $f — skipping"
        }
    }
}

# ---------------------------------------------------------------------------
# User Hooks: Source custom TCL scripts defined in project.yml -> tcl_hooks.gen_project
# ---------------------------------------------------------------------------
if {[info exists g_gen_project_hooks]} {
    foreach hook_script $g_gen_project_hooks {
        set full_path "${g_root_dir}/${hook_script}"
        if {[file exists $full_path]} {
            puts "INFO: Sourcing gen_project hook: $hook_script"
            source $full_path
        } else {
            puts "WARNING: gen_project hook not found: $full_path"
        }
    }
}
