# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/drivers/avalon_mm.py
"""
Native Avalon-MM Master / Slave BFMs for Cocotb Testbenches

Provides pure-Python Avalon Memory-Mapped bus functional models for
verifying Avalon-MM interfaces without external dependencies.

Key features:
  - Prefix-based signal auto-discovery (``AvalonMMBus.from_prefix()``)
  - ``waitrequest`` back-pressure handling
  - ``readdatavalid`` variable-latency reads
  - Transaction statistics (count, latency, errors)
  - X/Z guard checks on control signals
  - Timeout-wrapped transactions with clear error messages

Protocol summary (Intel Avalon-MM):

  Write: master asserts ``write`` + ``address`` + ``writedata`` + ``byteenable``.
         Slave stalls with ``waitrequest=1``.  Transfer completes on the
         first rising edge where ``waitrequest=0``.

  Read:  master asserts ``read`` + ``address``.
         Slave stalls with ``waitrequest=1``.  Once accepted, master waits
         for ``readdatavalid=1`` to capture ``readdata`` + ``response``.

Usage::

    master = AvalonMMMaster(env, prefix="avl")
    slave  = AvalonMMSlave(env, prefix="avl")
    cocotb.start_soon(slave.start())

    await master.write(0x00, 0xDEADBEEF)
    val, resp = await master.read(0x00)
    assert val == 0xDEADBEEF
"""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

from cocotb.triggers import RisingEdge, SimTimeoutError, with_timeout
from cocotb.utils import get_sim_time

__all__ = [
    "AvalonMMBus",
    "AvalonMMMaster",
    "AvalonMMSlave",
    "AvalonResp",
    "AvalonRespError",
    "AvalonTimeoutError",
]


# ──────────────────────────────────────────────────────────────
#  Avalon Response Codes (Intel Avalon-MM §3.5.6)
# ──────────────────────────────────────────────────────────────


class AvalonResp(enum.IntEnum):
    """Avalon-MM response codes (2-bit ``response`` field)."""

    OKAY = 0b00
    # 0b01 is reserved
    SLVERR = 0b10
    DECERR = 0b11


class AvalonRespError(Exception):
    """Raised when an Avalon-MM transaction receives a non-OKAY response."""

    def __init__(self, kind: str, addr: int, resp: AvalonResp):
        """Create an Avalon-MM response error.

        Parameters
        ----------
        kind : str
            Transaction type (``"WR"`` or ``"RD"``).
        addr : int
            Address of the failed transaction.
        resp : AvalonResp
            The non-OKAY response code.
        """
        self.kind = kind
        self.addr = addr
        self.resp = resp
        super().__init__(f"Avalon-MM {kind} @0x{addr:08X} returned {resp.name} (0x{resp:02X})")


class AvalonTimeoutError(Exception):
    """Raised when an Avalon-MM transaction times out."""

    def __init__(self, kind: str, addr: int, state: str):
        """Create an Avalon-MM timeout error.

        Parameters
        ----------
        kind : str
            Transaction type (``"WR"`` or ``"RD"``).
        addr : int
            Address of the timed-out transaction.
        state : str
            Description of what was being waited for.
        """
        self.kind = kind
        self.addr = addr
        self.state = state
        super().__init__(f"Avalon-MM {kind} @0x{addr:08X} timed out while {state}")


# ──────────────────────────────────────────────────────────────
#  Bus Signal Container
# ──────────────────────────────────────────────────────────────


def _resolve_signal(dut, prefix: str, name: str):
    """Resolve a signal from the DUT hierarchy by prefix + suffix.

    Tries ``{prefix}_{name}`` first (VHDL-style underscore),
    then ``{prefix}{name}`` (no separator, some IPs use this).
    """
    # Try underscore separator
    try:
        return getattr(dut, f"{prefix}_{name}")
    except AttributeError:
        pass

    # Try no separator
    try:
        return getattr(dut, f"{prefix}{name}")
    except AttributeError:
        pass

    # Try uppercase variants
    upper_name = name.upper()
    try:
        return getattr(dut, f"{prefix}_{upper_name}")
    except AttributeError:
        pass

    try:
        return getattr(dut, f"{prefix}{upper_name}")
    except AttributeError:
        pass

    raise AttributeError(
        f"Cannot find Avalon-MM signal '{name}' with prefix '{prefix}' "
        f"on {dut._name}. Tried: {prefix}_{name}, {prefix}{name}, "
        f"{prefix}_{upper_name}, {prefix}{upper_name}"
    )


@dataclass
class AvalonMMBus:
    """Container for the 9 Avalon-MM interface signals.

    Resolved from a DUT handle and a signal prefix.
    """

    # Command channel (master → slave)
    address: Any
    read: Any
    write: Any
    writedata: Any
    byteenable: Any

    # Response channel (slave → master)
    readdata: Any
    readdatavalid: Any
    waitrequest: Any
    response: Any

    @classmethod
    def from_prefix(cls, dut, prefix: str) -> "AvalonMMBus":
        """Auto-discover all Avalon-MM signals from a DUT using a prefix.

        Parameters
        ----------
        dut : cocotb handle
            Top-level or sub-module handle to search.
        prefix : str
            Signal name prefix, e.g. ``"avl"`` or ``"m_avl"``.
        """
        return cls(
            address=_resolve_signal(dut, prefix, "address"),
            read=_resolve_signal(dut, prefix, "read"),
            write=_resolve_signal(dut, prefix, "write"),
            writedata=_resolve_signal(dut, prefix, "writedata"),
            byteenable=_resolve_signal(dut, prefix, "byteenable"),
            readdata=_resolve_signal(dut, prefix, "readdata"),
            readdatavalid=_resolve_signal(dut, prefix, "readdatavalid"),
            waitrequest=_resolve_signal(dut, prefix, "waitrequest"),
            response=_resolve_signal(dut, prefix, "response"),
        )


# ──────────────────────────────────────────────────────────────
#  Helpers
# ──────────────────────────────────────────────────────────────


def _safe_int(sig, default: int = 0) -> int:
    """Read a signal as int, treating X/Z/U as *default*."""
    try:
        v = sig.value
        if not getattr(v, "is_resolvable", False) or not v.is_resolvable:
            return default
        return int(v)
    except (ValueError, TypeError):
        return default


def _data_width(sig) -> int:
    """Return the bit-width of a data signal."""
    try:
        return len(sig)
    except TypeError:
        return 32  # fallback for 1-bit signals


# ──────────────────────────────────────────────────────────────
#  Avalon-MM Master BFM
# ──────────────────────────────────────────────────────────────


class AvalonMMMaster:
    """Avalon-MM Master Bus Functional Model.

    Generates single-beat read and write transactions on an Avalon-MM
    interface with proper ``waitrequest`` back-pressure handling.

    Parameters
    ----------
    env : TbEnv
        Testbench environment providing ``dut``, ``clk``, ``rst``, ``log``.
    prefix : str
        Signal name prefix for auto-discovery (e.g. ``"avl"``).
    raise_on_resp : bool
        If True, raise ``AvalonRespError`` on non-OKAY responses.
    """

    def __init__(self, env, prefix: str = "avl", raise_on_resp: bool = True):
        """Create an Avalon-MM master BFM.

        See class docstring for parameter details.
        """
        self.env = env
        self.log: logging.Logger = env.log
        self.clk = env.clk
        self.bus = AvalonMMBus.from_prefix(env.dut, prefix)
        self.raise_on_resp = raise_on_resp
        self._data_width = _data_width(self.bus.writedata)
        self._byte_width = self._data_width // 8
        self._prefix = prefix
        self.stats = {
            "num_writes": 0,
            "num_reads": 0,
            "num_errors": 0,
            "total_latency_ns": 0,
        }
        self._protocol_violations: list = []

        # Drive master outputs to idle state
        self._idle_outputs()

    def _idle_outputs(self):
        """Drive all master-driven signals to their idle state."""
        self.bus.read.value = 0
        self.bus.write.value = 0
        self.bus.address.value = 0
        self.bus.writedata.value = 0
        self.bus.byteenable.value = 0

    def get_stats(self) -> Dict[str, Any]:
        """Return transaction statistics."""
        return dict(self.stats)

    def protocol_violations(self) -> list:
        """Return list of detected protocol violations."""
        return list(self._protocol_violations)

    def _check_protocol(self):
        """Perform basic protocol checks (X/Z detection on control signals)."""
        for name in ["read", "write", "waitrequest", "readdatavalid"]:
            sig = getattr(self.bus, name)
            v = sig.value
            if not getattr(v, "is_resolvable", False) or not v.is_resolvable:
                msg = f"Avalon-MM protocol violation: {name} is {v}"
                self.log.critical(msg)
                self._protocol_violations.append(msg)

    # ──────────────────────────────────────────────────────────
    #  Write Transaction
    # ──────────────────────────────────────────────────────────

    async def write(self, addr: int, data: int, byteenable: Optional[int] = None, timeout_ns: int = 1000) -> AvalonResp:
        """Execute a single-beat Avalon-MM write transaction.

        Parameters
        ----------
        addr : int
            Write address (word-addressed for Avalon-MM).
        data : int
            Write data word.
        byteenable : int, optional
            Byte enable mask.  Defaults to all-ones (full word).
        timeout_ns : int
            Transaction timeout in nanoseconds.

        Returns
        -------
        AvalonResp
            The write response code (always OKAY for writes without
            ``response`` support; captured if available).

        Raises
        ------
        AvalonRespError
            If ``raise_on_resp`` is True and response is not OKAY.
        AvalonTimeoutError
            If the transaction times out.
        """
        if byteenable is None:
            byteenable = (1 << self._byte_width) - 1  # all bytes enabled

        t_start = get_sim_time(unit="ns")

        async def _write_logic():
            # Drive command: write + address + data + byteenable
            self.bus.write.value = 1
            self.bus.address.value = addr
            self.bus.writedata.value = data
            self.bus.byteenable.value = byteenable

            # Wait for waitrequest to deassert (transfer accepted)
            while True:
                await RisingEdge(self.clk)
                self._check_protocol()
                if not _safe_int(self.bus.waitrequest):
                    break

            # Deassert command IMMEDIATELY on acceptance — this prevents
            # the slave from seeing a stale write=1 when it loops back.
            self.bus.write.value = 0
            self.bus.address.value = 0
            self.bus.writedata.value = 0
            self.bus.byteenable.value = 0

            # Wait one more cycle for the slave to process the write
            # and drive the response signal.
            await RisingEdge(self.clk)

            # Sample the response (slave drove it after acceptance)
            resp_val = AvalonResp(_safe_int(self.bus.response))

            return resp_val

        try:
            resp = await with_timeout(_write_logic(), timeout_ns, "ns")
        except SimTimeoutError:
            self._idle_outputs()
            raise AvalonTimeoutError("WR", addr, "waiting for waitrequest deassert") from None

        t_end = get_sim_time(unit="ns")
        latency_ns = t_end - t_start

        # Track stats
        self.stats["num_writes"] += 1
        self.stats["total_latency_ns"] += latency_ns
        if resp != AvalonResp.OKAY:
            self.stats["num_errors"] += 1

        self.log.info(
            f"Avalon-MM WR @0x{addr:08X} = 0x{data:0{self._data_width // 4}X} "
            f"be=0x{byteenable:0{self._byte_width * 2}X} [{resp.name}] "
            f"({latency_ns:.0f} ns)"
        )

        if self.raise_on_resp and resp != AvalonResp.OKAY:
            raise AvalonRespError("WR", addr, resp)

        return resp

    # ──────────────────────────────────────────────────────────
    #  Read Transaction
    # ──────────────────────────────────────────────────────────

    async def read(self, addr: int, timeout_ns: int = 1000) -> tuple[int, AvalonResp]:
        """Execute a single-beat Avalon-MM read transaction.

        Parameters
        ----------
        addr : int
            Read address (word-addressed for Avalon-MM).
        timeout_ns : int
            Transaction timeout in nanoseconds.

        Returns
        -------
        tuple[int, AvalonResp]
            The read data word and response code.

        Raises
        ------
        AvalonRespError
            If ``raise_on_resp`` is True and response is not OKAY.
        AvalonTimeoutError
            If the transaction times out.
        """
        t_start = get_sim_time(unit="ns")

        async def _read_logic():
            # Phase 1: Drive read command
            self.bus.read.value = 1
            self.bus.address.value = addr

            # Wait for waitrequest to deassert (command accepted)
            while True:
                await RisingEdge(self.clk)
                self._check_protocol()
                if not _safe_int(self.bus.waitrequest):
                    break

            # Deassert read after acceptance
            self.bus.read.value = 0
            self.bus.address.value = 0

            # Phase 2: Wait for readdatavalid
            while not _safe_int(self.bus.readdatavalid):
                await RisingEdge(self.clk)
                self._check_protocol()

            read_data = _safe_int(self.bus.readdata)
            read_resp = AvalonResp(_safe_int(self.bus.response))

            return read_data, read_resp

        try:
            data, resp = await with_timeout(_read_logic(), timeout_ns, "ns")
        except SimTimeoutError:
            self._idle_outputs()
            raise AvalonTimeoutError("RD", addr, "waiting for readdatavalid") from None

        t_end = get_sim_time(unit="ns")
        latency_ns = t_end - t_start

        # Track stats
        self.stats["num_reads"] += 1
        self.stats["total_latency_ns"] += latency_ns
        if resp != AvalonResp.OKAY:
            self.stats["num_errors"] += 1

        self.log.info(
            f"Avalon-MM RD @0x{addr:08X} = 0x{data:0{self._data_width // 4}X} [{resp.name}] ({latency_ns:.0f} ns)"
        )

        if self.raise_on_resp and resp != AvalonResp.OKAY:
            raise AvalonRespError("RD", addr, resp)

        return data, resp


# ──────────────────────────────────────────────────────────────
#  Avalon-MM Slave BFM (Memory-Mapped Responder)
# ──────────────────────────────────────────────────────────────


class AvalonMMSlave:
    """Avalon-MM Slave Bus Functional Model with sparse memory.

    Responds to Avalon-MM read/write transactions with a dict-backed
    memory model.  Supports configurable response latency,
    ``waitrequest`` stalls, and error address injection.

    Parameters
    ----------
    env : TbEnv
        Testbench environment providing ``dut``, ``clk``, ``rst``, ``log``.
    prefix : str
        Signal name prefix for auto-discovery.
    memory : dict, optional
        Pre-populated memory contents ``{addr: data}``.
    read_latency : int
        Number of cycles between accepting a read and asserting
        ``readdatavalid``.  0 = combinational (same-cycle).
    waitrequest_cycles : int
        Number of cycles to stall each incoming command with
        ``waitrequest=1`` before accepting it.  0 = no stalling.
    default_value : int
        Value returned for reads to uninitialized addresses.
    error_addresses : set, optional
        Addresses that trigger ``SLVERR`` responses.
    """

    def __init__(
        self,
        env,
        prefix: str = "avl",
        memory: Optional[Dict[int, int]] = None,
        read_latency: int = 0,
        waitrequest_cycles: int = 0,
        default_value: int = 0,
        error_addresses: Optional[set] = None,
    ):
        """Create an Avalon-MM slave BFM.

        See class docstring for parameter details.
        """
        self.env = env
        self.log: logging.Logger = env.log
        self.clk = env.clk
        self.bus = AvalonMMBus.from_prefix(env.dut, prefix)
        self._mem: Dict[int, int] = dict(memory) if memory else {}
        self._read_latency = read_latency
        self._waitrequest_cycles = waitrequest_cycles
        self._default_value = default_value
        self._error_addrs: set = error_addresses or set()
        self._data_width = _data_width(self.bus.readdata)
        self._data_mask = (1 << self._data_width) - 1
        self._byte_width = self._data_width // 8
        self._callbacks: Dict[int, Any] = {}
        self._regions: list[tuple[int, int, str]] = []

        # Drive slave outputs to idle
        self._idle_outputs()

    def _idle_outputs(self):
        """Drive all slave-driven signals to idle state."""
        self.bus.readdata.value = 0
        self.bus.readdatavalid.value = 0
        self.bus.waitrequest.value = 0
        self.bus.response.value = 0

    def set_memory(self, addr: int, data: int):
        """Pre-populate memory at a specific address."""
        self._mem[addr] = data & self._data_mask

    def get_memory(self, addr: int) -> int:
        """Read memory contents at address."""
        return self._mem.get(addr, self._default_value)

    def dump(self) -> Dict[int, int]:
        """Return a copy of the entire memory contents."""
        return dict(self._mem)

    def add_error_address(self, addr: int):
        """Mark an address to return SLVERR on access."""
        self._error_addrs.add(addr)

    def on_write(self, addr: int, callback: Any):
        """Register a callback for writes to a specific address.

        The callback is called as ``callback(addr, data)``.
        """
        self._callbacks[addr] = callback

    def add_region(self, base: int, size: int, name: str = "region"):
        """Define a valid address region for this slave."""
        self._regions.append((base, size, name))

    def set_default_value(self, val: int):
        """Set the value returned for uninitialized memory reads."""
        self._default_value = val

    def _is_addr_valid(self, addr: int) -> bool:
        """Check if an address is within any defined region."""
        if not self._regions:
            return True  # No regions defined = all addresses valid
        return any(base <= addr < base + size for base, size, _ in self._regions)

    async def start(self):
        """Main slave coroutine — run with ``cocotb.start_soon()``.

        Handles read and write commands on the shared Avalon-MM bus.

        Timing model (per Intel Avalon-MM spec §3.5):
        - ``waitrequest`` is driven **combinationally**: the slave asserts it
          (=1) on any cycle where it cannot accept a command, and deasserts
          (=0) on the cycle where it accepts.
        - A transfer occurs on the rising edge where the master drives
          ``read`` or ``write`` AND ``waitrequest == 0``.
        - For writes: ``response`` is valid on the acceptance cycle.
        - For reads: ``readdata`` + ``response`` are valid when
          ``readdatavalid == 1`` (variable-latency / pipeline mode).
        """
        self.log.info(f"Avalon-MM Slave started (prefix={self._prefix})")

        if self._waitrequest_cycles > 0:
            await self._start_with_backpressure()
        else:
            await self._start_no_backpressure()

    async def _start_no_backpressure(self):
        """Slave loop for zero-stall mode (waitrequest always 0)."""
        while True:
            self.bus.waitrequest.value = 0
            self.bus.readdatavalid.value = 0
            self.bus.response.value = 0
            self.bus.readdata.value = 0

            await RisingEdge(self.clk)

            is_write = _safe_int(self.bus.write)
            is_read = _safe_int(self.bus.read)

            if not is_write and not is_read:
                continue

            cmd_addr = _safe_int(self.bus.address)
            cmd_writedata = _safe_int(self.bus.writedata)
            cmd_byteenable = _safe_int(self.bus.byteenable)

            if is_write:
                resp = self._compute_write_response(cmd_addr, cmd_writedata, cmd_byteenable)
                self.bus.response.value = int(resp)
                # Hold response for one cycle so master can sample it
                await RisingEdge(self.clk)
            elif is_read:
                await self._handle_read(cmd_addr)

    async def _start_with_backpressure(self):
        """Slave loop for backpressure mode.

        Default idle state is ``waitrequest=1``.  The slave only
        deasserts ``waitrequest`` on the acceptance cycle, preventing
        the cocotb delta-cycle race where the master would see a
        transient ``waitrequest=0`` before the slave can stall.

        After writes, the slave holds ``waitrequest=0`` and ``response``
        for one full cycle so the master can sample the response.
        """
        while True:
            # Hold waitrequest=1 while waiting for a command.
            self.bus.waitrequest.value = 1
            self.bus.readdatavalid.value = 0
            self.bus.response.value = 0
            self.bus.readdata.value = 0

            # Wait for the master to present a command
            await RisingEdge(self.clk)

            is_write = _safe_int(self.bus.write)
            is_read = _safe_int(self.bus.read)

            if not is_write and not is_read:
                continue

            # Master is presenting a command — stall for N-1 more cycles
            # (the first stall cycle is the one we just saw above)
            for _ in range(self._waitrequest_cycles - 1):
                await RisingEdge(self.clk)

            # Re-capture command signals after stall (master held stable)
            cmd_addr = _safe_int(self.bus.address)
            cmd_writedata = _safe_int(self.bus.writedata)
            cmd_byteenable = _safe_int(self.bus.byteenable)

            # Deassert waitrequest — this is the acceptance cycle
            self.bus.waitrequest.value = 0

            if is_write:
                resp = self._compute_write_response(cmd_addr, cmd_writedata, cmd_byteenable)
                self.bus.response.value = int(resp)
                # Hold waitrequest=0 and response for one full cycle
                # so the master can sample response on the next edge.
                await RisingEdge(self.clk)
            elif is_read:
                # Wait one cycle for master to see acceptance and
                # deassert read.
                await RisingEdge(self.clk)
                await self._handle_read(cmd_addr)

    def _compute_write_response(self, addr: int, wdata: int, byteenable: int) -> AvalonResp:
        """Process a write command — update memory and return response code."""
        # Determine response
        if not self._is_addr_valid(addr):
            resp = AvalonResp.DECERR
        elif addr in self._error_addrs:
            resp = AvalonResp.SLVERR
        else:
            resp = AvalonResp.OKAY
            # Apply byte enables
            existing = self._mem.get(addr, 0)
            new_data = 0
            for byte_idx in range(self._byte_width):
                if byteenable & (1 << byte_idx):
                    byte_val = (wdata >> (byte_idx * 8)) & 0xFF
                else:
                    byte_val = (existing >> (byte_idx * 8)) & 0xFF
                new_data |= byte_val << (byte_idx * 8)
            self._mem[addr] = new_data & self._data_mask

            # Trigger callbacks
            if addr in self._callbacks:
                self._callbacks[addr](addr, new_data)

        self.log.debug(
            f"Avalon-MM SLAVE WR @0x{addr:08X} = "
            f"0x{wdata:0{self._data_width // 4}X} "
            f"be=0x{byteenable:02X} [{resp.name}]"
        )
        return resp

    async def _handle_read(self, addr: int):
        """Process a read command — drive readdatavalid after latency."""
        # Determine response
        if not self._is_addr_valid(addr):
            resp = AvalonResp.DECERR
            rdata = 0
        elif addr in self._error_addrs:
            resp = AvalonResp.SLVERR
            rdata = 0
        else:
            resp = AvalonResp.OKAY
            rdata = self._mem.get(addr, self._default_value)

        # Apply read latency
        for _ in range(self._read_latency):
            await RisingEdge(self.clk)

        # Drive read data + valid
        self.bus.readdata.value = rdata & self._data_mask
        self.bus.response.value = int(resp)
        self.bus.readdatavalid.value = 1

        await RisingEdge(self.clk)

        # Deassert
        self.bus.readdatavalid.value = 0
        self.bus.readdata.value = 0
        self.bus.response.value = 0

        self.log.debug(f"Avalon-MM SLAVE RD @0x{addr:08X} = 0x{rdata:0{self._data_width // 4}X} [{resp.name}]")

    @property
    def _prefix(self) -> str:
        """Return the signal prefix for logging."""
        # Extract from the first signal name
        addr_name = self.bus.address._name
        if "_address" in addr_name:
            return addr_name.rsplit("_address", 1)[0]
        return "avl"
