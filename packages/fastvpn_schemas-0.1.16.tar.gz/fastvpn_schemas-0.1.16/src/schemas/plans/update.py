from typing import Optional

from pydantic import BaseModel, Field


class PlanUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=100)
    description: Optional[str] = None
    stars_amount: Optional[int] = Field(default=None, ge=1)
    period_days: Optional[int] = Field(default=None, ge=1)
    vpn_speed_limit_mbps: Optional[int] = Field(default=None, ge=1)
    devices_limit: Optional[int] = Field(default=None, ge=1)
    is_active: Optional[bool] = None
