from typing import Optional

from pydantic import ConfigDict, Field

from schemas.common import ORMBaseSchema


class PlanBase(ORMBaseSchema):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    stars_amount: int = Field(..., gt=0)
    period_days: int = Field(default=30, ge=1)
    vpn_speed_limit_mbps: Optional[int] = Field(default=None, ge=1)
    devices_limit: int = Field(default=1, ge=1)
    is_active: bool = True

    model_config = ConfigDict(
        from_attributes=True,
    )
