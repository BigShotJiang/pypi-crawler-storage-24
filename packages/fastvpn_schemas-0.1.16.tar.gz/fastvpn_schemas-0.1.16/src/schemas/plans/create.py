from .base import PlanBase


class PlanCreate(PlanBase):
    pass
