from schemas.common import IDSchema, TimestampSchema

from .base import PlanBase


class PlanRead(PlanBase, IDSchema, TimestampSchema):
    pass
