import uuid as py_uuid
from datetime import datetime

from pydantic import BaseModel, Field


class ProcessSuccessfulPayment(BaseModel):
    payment_id: py_uuid.UUID
    user_id: int = Field(gt=0)
    telegram_charge_id: str
    amount_stars: int = Field(gt=0)
    paid_at: datetime


class PaymentInvoicePayload(BaseModel):
    kind: str = Field(default="balance")
    user_id: int = Field(gt=0)
    payment_id: py_uuid.UUID
    amount: int = Field(gt=0)

    @classmethod
    def from_raw(cls, raw: str) -> "PaymentInvoicePayload":
        parts = raw.split(":")
        if len(parts) != 4:
            raise ValueError("Invalid payload format")

        kind, user_id, paymet_id, amount = parts

        return cls(
            kind=kind,
            user_id=int(user_id),
            payment_id=py_uuid.UUID(paymet_id),
            amount=int(amount),
        )

    def to_raw(self) -> str:
        return f"{self.kind}:{self.user_id}:{self.payment_id}:{self.amount}"
