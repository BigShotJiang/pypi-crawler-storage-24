import uuid as py_uuid
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from schemas.enums import PaymentStatus


class PaymentCreate(BaseModel):
    # id: py_uuid.UUID = Field(...)
    user_id: int
    subscription_id: Optional[py_uuid.UUID] = None
    amount_stars: int = Field(..., ge=1)
    is_recurring: bool = False
    is_first: bool = True
    status: PaymentStatus = PaymentStatus.PENDING
    telegram_charge_id: Optional[str] = Field(default=None, max_length=100)
    paid_at: Optional[datetime] = None
