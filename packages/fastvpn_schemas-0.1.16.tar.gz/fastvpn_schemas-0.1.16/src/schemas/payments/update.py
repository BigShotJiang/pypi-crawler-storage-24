import uuid as py_uuid
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from schemas.enums import PaymentStatus


class PaymentUpdate(BaseModel):
    subscription_id: Optional[py_uuid.UUID] = None
    amount_stars: Optional[int] = Field(default=None, ge=1)
    invoice_payload: Optional[str] = Field(default=None, min_length=1, max_length=255)
    is_recurring: Optional[bool] = None
    is_first: Optional[bool] = None
    status: Optional[PaymentStatus] = None
    telegram_charge_id: Optional[str] = Field(default=None, max_length=100)
    paid_at: Optional[datetime] = None
