from datetime import datetime
from typing import Optional

from pydantic import Field

from schemas.common import ORMBaseSchema
from schemas.enums import PaymentStatus


class PaymentBase(ORMBaseSchema):
    amount_stars: int = Field(..., ge=1)
    invoice_payload: str = Field(..., min_length=1, max_length=255)
    is_recurring: bool = False
    is_first: bool = True
    status: PaymentStatus = PaymentStatus.PENDING
    telegram_charge_id: Optional[str] = Field(default=None)
    paid_at: Optional[datetime] = None
