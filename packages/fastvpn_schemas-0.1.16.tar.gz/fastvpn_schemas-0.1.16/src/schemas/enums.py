from enum import Enum


class PaymentStatus(str, Enum):
    SUCCESS = "SUCCESS"
    PENDING = "PENDING"
    FAILED = "FAILED"
    REFUNDED = "REFUNDED"


class SubscriptionStatus(str, Enum):
    ACTIVE = "ACTIVE"
    CANCELED = "CANCELED"
    EXPIRED = "EXPIRED"
    GRACE = "GRACE"
    TRIAL = "TRIAL"
    PENDING = "PENDING"
    PAYMENT_FAILED = "PAYMENT_FAILED"


class BalanceTransactionType(str, Enum):
    TOP_UP = "TOP_UP"
    DEBIT = "DEBIT"
    REFUND = "REFUND"
    ADJUSTMENT = "ADJUSTMENT"
    BONUS = "BONUS"
    WITHDRAWAL = "WITHDRAWAL"
