from typing import Optional
from uuid import UUID

from pydantic import Field

from .base import BalanceTransactionBase


class BalanceTransactionCreate(BalanceTransactionBase):
    user_id: int = Field(..., ge=0)
    payment_id: Optional[UUID] = None
