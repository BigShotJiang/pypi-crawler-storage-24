from typing import Optional

from pydantic import Field

from schemas.common import ORMBaseSchema
from schemas.enums import BalanceTransactionType


class BalanceTransactionBase(ORMBaseSchema):
    type: BalanceTransactionType
    amount: int
    description: Optional[str] = Field(default=None, max_length=255)
    reference_type: Optional[str] = Field(default=None, max_length=50)
    reference_id: Optional[str] = Field(default=None, max_length=100)
