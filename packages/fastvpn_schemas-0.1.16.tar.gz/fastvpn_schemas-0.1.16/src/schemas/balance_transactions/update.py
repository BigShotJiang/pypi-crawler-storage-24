from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field

from schemas.enums import BalanceTransactionType


class BalanceTransactionUpdate(BaseModel):
    payment_id: Optional[UUID] = None
    type: Optional[BalanceTransactionType] = None
    amount: Optional[int] = None
    description: Optional[str] = Field(default=None, max_length=255)
    reference_type: Optional[str] = Field(default=None, max_length=50)
    reference_id: Optional[str] = Field(default=None, max_length=100)
