from typing import Optional
from uuid import UUID

from pydantic import Field

from schemas.common import IDSchema, TimestampSchema

from .base import BalanceTransactionBase


class BalanceTransactionRead(BalanceTransactionBase, IDSchema, TimestampSchema):
    user_id: int = Field(..., ge=0)
    payment_id: Optional[UUID] = None
    balance_before: int
    balance_after: int
