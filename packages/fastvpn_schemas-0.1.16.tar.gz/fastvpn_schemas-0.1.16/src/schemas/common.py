import uuid as py_uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ORMBaseSchema(BaseModel):
    model_config = ConfigDict(
        from_attributes=True,
    )


class IDSchema(ORMBaseSchema):
    id: py_uuid.UUID


class TimestampSchema(ORMBaseSchema):
    created_at: datetime
    updated_at: datetime
