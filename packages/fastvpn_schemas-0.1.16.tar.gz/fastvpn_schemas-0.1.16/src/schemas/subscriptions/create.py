import uuid as py_uuid
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from .base import SubscriptionStatus


class SubscriptionCreate(BaseModel):
    user_id: int
    plan_id: py_uuid.UUID
    status: SubscriptionStatus = SubscriptionStatus.PENDING
    current_period_start: datetime
    current_period_end: datetime
    next_billing_attempt: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
