from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from schemas.enums import SubscriptionStatus


class SubscriptionUpdate(BaseModel):
    plan_id: Optional[int] = Field(default=None, ge=1)
    status: Optional[SubscriptionStatus] = None
    current_period_start: Optional[datetime] = None
    current_period_end: Optional[datetime] = None
    next_billing_attempt: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
