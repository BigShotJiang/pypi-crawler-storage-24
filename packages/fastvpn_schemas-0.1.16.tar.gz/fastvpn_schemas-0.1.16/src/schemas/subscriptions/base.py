import uuid as py_uuid
from datetime import datetime
from typing import Optional

from schemas.common import ORMBaseSchema
from schemas.enums import SubscriptionStatus


class SubscriptionBase(ORMBaseSchema):
    plan_id: py_uuid.UUID
    status: SubscriptionStatus = SubscriptionStatus.PENDING
    current_period_start: datetime
    current_period_end: datetime
    next_billing_attempt: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
