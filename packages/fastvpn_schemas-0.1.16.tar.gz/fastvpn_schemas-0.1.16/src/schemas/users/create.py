from .base import UserBase


class UserCreate(UserBase):
    pass
