from typing import Optional

from pydantic import BaseModel, Field


class UserUpdate(BaseModel):
    balance:
