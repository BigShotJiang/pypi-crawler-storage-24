from .base import VpnAccountBase


class VpnAccountCreate(VpnAccountBase):
    user_id: int
