from datetime import datetime
from typing import Optional

from pydantic import Field

from schemas.common import ORMBaseSchema


class VpnAccountBase(ORMBaseSchema):
    flow: str = Field(default="xtls-rprx-vision", max_length=32)
    is_active: bool = True
    expires_at: Optional[datetime] = None
    is_trial: bool = False
