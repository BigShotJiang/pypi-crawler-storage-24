from schemas.common import IDSchema, TimestampSchema

from .base import VpnAccountBase


class VpnAccountRead(VpnAccountBase, IDSchema, TimestampSchema):
    user_id: int
