from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class VpnAccountUpdate(BaseModel):
    flow: Optional[str] = Field(default=None, max_length=32)
    is_active: Optional[bool] = None
    expires_at: Optional[datetime] = None
    is_trial: Optional[bool] = None
