# fastvpn-schemas

Shared Pydantic schemas for FastAPI services.

## Installation

```bash
pip install fastvpn-schemas
