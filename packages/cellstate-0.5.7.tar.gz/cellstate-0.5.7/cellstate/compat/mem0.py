"""
Mem0 drop-in compatibility layer for CELLSTATE.

Swap your import and get event sourcing, audit trails,
and Blake3 receipts for free.

Migration (3 lines)::

    # Before:
    from mem0 import MemoryClient

    # After:
    from cellstate.compat.mem0 import MemoryClient
    # Everything else stays the same.

The ``MemoryClient`` class mirrors Mem0's synchronous API surface exactly.
All methods are synchronous wrappers around CELLSTATE's async internals.
"""

from __future__ import annotations

import asyncio
from typing import Any

from cellstate.simple_memory import SimpleMemory


class MemoryClient:
    """
    Drop-in replacement for Mem0's ``MemoryClient``.

    Provides an identical synchronous API to Mem0 while backing every
    operation with CELLSTATE's event-sourced, Blake3-receipted storage.

    Example::

        # Change only this line:
        from cellstate.compat.mem0 import MemoryClient

        client = MemoryClient(api_key="cst_...")

        client.add(
            [{"role": "user", "content": "I prefer Python"}],
            user_id="alice"
        )

        results = client.search("language preference", user_id="alice")
        print(results["results"][0]["memory"])
        # "I prefer Python"
        # Plus: results["results"][0]["receipt"] ← Blake3 hash (Mem0 doesn't have this)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://cst.batterypack.dev",
        **_kwargs: Any,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url
        # Cache per-user SimpleMemory instances for session reuse
        self._instances: dict[str, SimpleMemory] = {}

    def _get_memory(self, user_id: str = "default") -> SimpleMemory:
        if user_id not in self._instances:
            self._instances[user_id] = SimpleMemory(
                api_key=self._api_key,
                base_url=self._base_url,
                user_id=user_id,
            )
        return self._instances[user_id]

    def add(
        self,
        messages: list[dict[str, Any]] | str,
        user_id: str = "default",
        agent_id: str | None = None,
        **_kwargs: Any,
    ) -> dict[str, Any]:
        """
        Add memories from a message list or plain string.

        Mem0-compatible: accepts ``[{"role": "user", "content": "..."}]``
        or a plain string.
        """
        if isinstance(messages, str):
            content = messages
        else:
            # Extract content from message list — join user/assistant turns
            parts = [
                m["content"]
                for m in messages
                if isinstance(m.get("content"), str) and m.get("content", "").strip()
            ]
            content = "\n".join(parts)

        memory = self._get_memory(user_id)
        result = asyncio.run(memory.add(content))

        return {
            "id": result.id,
            "memory": content,
            "receipt": result.receipt,
            # Mem0-compatible keys
            "results": [{"id": result.id, "memory": content, "event": "ADD"}],
        }

    def search(
        self,
        query: str,
        user_id: str = "default",
        limit: int = 10,
        **_kwargs: Any,
    ) -> dict[str, Any]:
        """
        Search memories for a user.

        Returns Mem0-compatible structure, plus ``receipt`` on each result
        (unique to CELLSTATE — Mem0 cannot provide this).
        """
        memory = self._get_memory(user_id)
        results = asyncio.run(memory.recall(query, limit=limit))

        return {
            "results": [
                {
                    "id": r.id,
                    "memory": r.content,
                    "score": r.score,
                    "level": r.level,
                    # Not in Mem0 — the CELLSTATE differentiator
                    "receipt": memory._receipt_cache.get(r.id, ""),
                }
                for r in results
            ]
        }

    def get_all(
        self,
        user_id: str = "default",
        limit: int = 50,
        **_kwargs: Any,
    ) -> dict[str, Any]:
        """Return all memories for a user."""
        memory = self._get_memory(user_id)
        results = asyncio.run(memory.get_all(limit=limit))

        return {
            "results": [
                {
                    "id": r.id,
                    "memory": r.content,
                    "score": r.score,
                    "receipt": memory._receipt_cache.get(r.id, ""),
                }
                for r in results
            ]
        }

    def delete(self, memory_id: str, user_id: str = "default") -> dict[str, Any]:
        """Delete a memory by ID."""
        memory = self._get_memory(user_id)
        result = asyncio.run(memory.forget(memory_id))
        return {"message": "Memory deleted", "receipt": result.receipt}

    def delete_all(
        self,
        user_id: str = "default",
        query: str = "",
        **_kwargs: Any,
    ) -> dict[str, Any]:
        """Delete all memories for a user (optionally filtered by query)."""
        memory = self._get_memory(user_id)
        result = asyncio.run(memory.forget_all(query))
        return {
            "message": f"Deleted {result.count} memories",
            "count": result.count,
            "receipt": result.receipt,
        }

    def get(self, memory_id: str, user_id: str = "default") -> dict[str, Any]:
        """Get a specific memory by ID."""
        memory = self._get_memory(user_id)
        results = asyncio.run(memory.recall("", limit=100))
        match = next((r for r in results if r.id == memory_id), None)
        if match is None:
            return {}
        return {
            "id": match.id,
            "memory": match.content,
            "score": match.score,
        }

    def history(
        self,
        memory_id: str | None = None,
        user_id: str = "default",
        **_kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Get history of memory operations for a user."""
        memory = self._get_memory(user_id)
        events = memory.history()
        return [
            {
                "id": e.memory_id,
                "event": e.event.upper(),
                "timestamp": e.timestamp.isoformat(),
                "receipt": e.receipt,
            }
            for e in events
            if memory_id is None or e.memory_id == memory_id
        ]
