"""
CELLSTATE compatibility shims for other memory libraries.

Available:
    cellstate.compat.mem0  — Drop-in replacement for Mem0's MemoryClient
"""
