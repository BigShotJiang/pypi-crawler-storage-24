"""Web MCP Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class WebMcpManager(BaseManager):
    """Manager for Web MCP operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/web-mcp")

    async def negotiate(
        self,
        page_url: str,
        discovered_tools: list[dict[str, Any]] | None = None,
        agent_capabilities: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"page_url": page_url}
        if discovered_tools is not None:
            body["discovered_tools"] = discovered_tools
        if agent_capabilities is not None:
            body["agent_capabilities"] = agent_capabilities
        return await self.http.post(f"{self.base_path}/negotiate", body)

    async def execute(
        self,
        tool_call: dict[str, Any],
        origin: str,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "tool_call": tool_call,
            "origin": origin,
        }
        return await self.http.post(f"{self.base_path}/execute", body)

    async def log(
        self,
        tool_name: str,
        origin: str,
        success: bool,
        duration_ms: int,
        arguments: dict[str, Any] | None = None,
        result: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "tool_name": tool_name,
            "origin": origin,
            "success": success,
            "duration_ms": duration_ms,
        }
        if arguments is not None:
            body["arguments"] = arguments
        if result is not None:
            body["result"] = result
        if error is not None:
            body["error"] = error
        return await self.http.post(f"{self.base_path}/log", body)

    async def list_tools(
        self,
        origin: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "origin": origin,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(f"{self.base_path}/tools", params=params)
