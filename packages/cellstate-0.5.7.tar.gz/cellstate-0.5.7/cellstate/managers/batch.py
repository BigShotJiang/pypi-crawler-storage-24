"""Batch Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class BatchManager(BaseManager):
    """Manager for batch operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/batch")

    async def execute(
        self,
        resource_type: str,
        items: list[dict[str, Any]],
        stop_on_error: bool = False,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "items": items,
            "stop_on_error": stop_on_error,
        }
        return await self.http.post(f"{self.base_path}/{resource_type}", body)
