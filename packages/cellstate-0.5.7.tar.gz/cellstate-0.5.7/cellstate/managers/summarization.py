"""Summarization Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class SummarizationManager(BaseManager):
    """Manager for summarization operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/summarization-policies")

    async def create_policy(
        self,
        name: str,
        triggers: list[dict[str, Any]],
        source_level: str,
        target_level: str,
        max_sources: int,
        create_edges: bool,
        trajectory_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "name": name,
            "triggers": triggers,
            "source_level": source_level,
            "target_level": target_level,
            "max_sources": max_sources,
            "create_edges": create_edges,
        }
        if trajectory_id is not None:
            body["trajectory_id"] = trajectory_id
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def list_policies(
        self,
        trajectory_id: str | None = None,
    ) -> dict[str, Any]:
        if trajectory_id is not None:
            return await self.http.get(
                f"/api/v1/trajectories/{trajectory_id}/summarization-policies"
            )
        return await self.http.get(self.base_path)

    async def list_requests(
        self,
        status: str | None = None,
        scope_id: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "status": status,
            "scope_id": scope_id,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get("/api/v1/summarization-requests", params=params)

    async def update_request_status(
        self,
        request_id: str,
        status: str,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"status": status}
        return await self.http.patch(
            f"/api/v1/summarization-requests/{request_id}/status", body
        )

    async def get_policy(self, policy_id: str) -> dict[str, Any]:
        """Get a summarization policy by ID.

        Args:
            policy_id: UUID of the summarization policy.

        Returns:
            Summarization policy data.
        """
        return await self.http.get(self._path(policy_id))

    async def delete_policy(self, policy_id: str) -> None:
        """Delete a summarization policy by ID.

        Args:
            policy_id: UUID of the summarization policy.
        """
        await self.http.delete(self._path(policy_id))

    async def get_request(self, request_id: str) -> dict[str, Any]:
        """Get a summarization request by ID.

        Args:
            request_id: UUID of the summarization request.

        Returns:
            Summarization request data.
        """
        return await self.http.get(
            f"/api/v1/summarization-requests/{request_id}"
        )
