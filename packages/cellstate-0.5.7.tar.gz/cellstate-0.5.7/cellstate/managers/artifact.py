"""
Artifact Manager.

Manages artifacts (extracted valuable outputs) in CELLSTATE.
"""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class ArtifactManager(BaseManager):
    """Manager for artifact operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/artifacts")

    async def create(
        self,
        trajectory_id: str,
        scope_id: str,
        artifact_type: str,
        name: str,
        content: str,
        source_turn: int,
        extraction_method: str = "Explicit",
        ttl: str = "Persistent",
        confidence: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new artifact.

        Args:
            trajectory_id: UUID of the parent trajectory.
            scope_id: UUID of the scope.
            artifact_type: Type of artifact (e.g., "Code", "Fact", "Document").
            name: Name for the artifact.
            content: Content of the artifact.
            source_turn: Turn number that produced this artifact.
            extraction_method: How the artifact was extracted.
            ttl: Time-to-live policy.
            confidence: Optional extraction confidence (0.0-1.0).
            metadata: Optional arbitrary metadata.

        Returns:
            Created artifact data.
        """
        body: dict[str, Any] = {
            "trajectory_id": trajectory_id,
            "scope_id": scope_id,
            "artifact_type": artifact_type,
            "name": name,
            "content": content,
            "source_turn": source_turn,
            "extraction_method": extraction_method,
            "ttl": ttl,
        }
        if confidence is not None:
            body["confidence"] = confidence
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, artifact_id: str) -> dict[str, Any]:
        """Get an artifact by ID.

        Args:
            artifact_id: UUID of the artifact.

        Returns:
            Artifact data.
        """
        return await self.http.get(self._path(artifact_id))

    async def list(
        self,
        trajectory_id: str | None = None,
        scope_id: str | None = None,
        artifact_type: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        """List artifacts with optional filters.

        Args:
            trajectory_id: Filter by trajectory ID.
            scope_id: Filter by scope ID.
            artifact_type: Filter by artifact type.
            limit: Maximum number of results.
            offset: Pagination offset.

        Returns:
            Paginated list of artifacts.
        """
        params = self._clean_params({
            "trajectory_id": trajectory_id,
            "scope_id": scope_id,
            "artifact_type": artifact_type,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def update(
        self,
        artifact_id: str,
        name: str | None = None,
        content: str | None = None,
        artifact_type: str | None = None,
        ttl: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Update an artifact.

        Args:
            artifact_id: UUID of the artifact.
            name: New name.
            content: New content.
            artifact_type: New type.
            ttl: New TTL policy.
            metadata: Updated metadata.

        Returns:
            Updated artifact data.
        """
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if content is not None:
            body["content"] = content
        if artifact_type is not None:
            body["artifact_type"] = artifact_type
        if ttl is not None:
            body["ttl"] = ttl
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.patch(self._path(artifact_id), body)

    async def delete(self, artifact_id: str) -> None:
        """Delete an artifact.

        Args:
            artifact_id: UUID of the artifact.
        """
        await self.http.delete(self._path(artifact_id))

    async def search(
        self,
        query: str,
        trajectory_id: str | None = None,
        limit: int | None = None,
        min_score: float | None = None,
    ) -> dict[str, Any]:
        """Search artifacts by content.

        Args:
            query: Search query string.
            trajectory_id: Optional trajectory filter.
            limit: Maximum number of results.
            min_score: Minimum relevance score.

        Returns:
            Search results with scores.
        """
        body: dict[str, Any] = {"query": query}
        if trajectory_id is not None:
            body["trajectory_id"] = trajectory_id
        if limit is not None:
            body["limit"] = limit
        if min_score is not None:
            body["min_score"] = min_score
        return await self.http.post(f"{self.base_path}/search", body)
