"""
Note Manager.

Manages notes (cross-trajectory knowledge) in CELLSTATE.
"""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class NoteManager(BaseManager):
    """Manager for note operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/notes")

    async def create(
        self,
        note_type: str,
        title: str,
        content: str,
        source_trajectory_ids: list[str] | None = None,
        source_artifact_ids: list[str] | None = None,
        ttl: str = "Persistent",
        abstraction_level: str = "Raw",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new note.

        Args:
            note_type: Type of note (e.g., "Fact", "Insight", "Convention").
            title: Title of the note.
            content: Content of the note.
            source_trajectory_ids: Trajectories this note was derived from.
            source_artifact_ids: Artifacts this note was derived from.
            ttl: Time-to-live policy.
            abstraction_level: Semantic tier ("Raw", "Summary", "Principle").
            metadata: Optional arbitrary metadata.

        Returns:
            Created note data.
        """
        body: dict[str, Any] = {
            "note_type": note_type,
            "title": title,
            "content": content,
            "ttl": ttl,
            "abstraction_level": abstraction_level,
        }
        if source_trajectory_ids is not None:
            body["source_trajectory_ids"] = source_trajectory_ids
        if source_artifact_ids is not None:
            body["source_artifact_ids"] = source_artifact_ids
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, note_id: str) -> dict[str, Any]:
        """Get a note by ID.

        Args:
            note_id: UUID of the note.

        Returns:
            Note data.
        """
        return await self.http.get(self._path(note_id))

    async def list(
        self,
        note_type: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        """List notes with optional filters.

        Args:
            note_type: Filter by note type.
            limit: Maximum number of results.
            offset: Pagination offset.

        Returns:
            Paginated list of notes.
        """
        params = self._clean_params({
            "note_type": note_type,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def update(
        self,
        note_id: str,
        title: str | None = None,
        content: str | None = None,
        note_type: str | None = None,
        ttl: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Update a note.

        Args:
            note_id: UUID of the note.
            title: New title.
            content: New content.
            note_type: New type.
            ttl: New TTL policy.
            metadata: Updated metadata.

        Returns:
            Updated note data.
        """
        body: dict[str, Any] = {}
        if title is not None:
            body["title"] = title
        if content is not None:
            body["content"] = content
        if note_type is not None:
            body["note_type"] = note_type
        if ttl is not None:
            body["ttl"] = ttl
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.patch(self._path(note_id), body)

    async def delete(self, note_id: str) -> None:
        """Delete a note.

        Args:
            note_id: UUID of the note.
        """
        await self.http.delete(self._path(note_id))

    async def search(
        self,
        query: str,
        limit: int | None = None,
        min_score: float | None = None,
    ) -> dict[str, Any]:
        """Search notes by content.

        Args:
            query: Search query string.
            limit: Maximum number of results.
            min_score: Minimum relevance score.

        Returns:
            Search results with scores.
        """
        body: dict[str, Any] = {"query": query}
        if limit is not None:
            body["limit"] = limit
        if min_score is not None:
            body["min_score"] = min_score
        return await self.http.post(f"{self.base_path}/search", body)
