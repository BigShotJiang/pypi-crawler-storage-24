"""Browser Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class BrowserManager(BaseManager):
    """Manager for browser action operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/browser")

    async def report_action(
        self,
        session_id: str,
        action: str,
        url: str,
        success: bool,
        duration_ms: int,
        result_summary: dict[str, Any],
        error: str | None = None,
        screenshot: str | None = None,
        navigation_count: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "session_id": session_id,
            "action": action,
            "url": url,
            "success": success,
            "duration_ms": duration_ms,
            "result_summary": result_summary,
        }
        if error is not None:
            body["error"] = error
        if screenshot is not None:
            body["screenshot"] = screenshot
        if navigation_count is not None:
            body["navigation_count"] = navigation_count
        return await self.http.post(f"{self.base_path}/report", body)
