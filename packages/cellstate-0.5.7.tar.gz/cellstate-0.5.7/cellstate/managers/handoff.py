"""Handoff Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class HandoffManager(BaseManager):
    """Manager for handoff operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/handoffs")

    async def create(
        self,
        from_agent_id: str,
        to_agent_id: str,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "from_agent_id": from_agent_id,
            "to_agent_id": to_agent_id,
        }
        if context is not None:
            body["context"] = context
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, handoff_id: str) -> dict[str, Any]:
        return await self.http.get(self._path(handoff_id))

    async def list(
        self,
        agent_id: str | None = None,
        status: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "agent_id": agent_id,
            "status": status,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def accept(self, handoff_id: str, accepting_agent_id: str) -> None:
        body: dict[str, Any] = {"accepting_agent_id": accepting_agent_id}
        await self.http.post(f"{self._path(handoff_id)}/accept", body)

    async def complete(self, handoff_id: str) -> None:
        await self.http.post(f"{self._path(handoff_id)}/complete")
