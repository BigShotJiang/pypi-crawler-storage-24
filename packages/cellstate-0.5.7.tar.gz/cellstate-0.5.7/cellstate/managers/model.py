"""Model Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class ModelManager(BaseManager):
    """Manager for model operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/models")

    async def list_models(
        self,
        provider: str | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({"provider": provider})
        return await self.http.get(self.base_path, params=params)

    async def list_providers(self) -> dict[str, Any]:
        return await self.http.get(f"{self.base_path}/providers")
