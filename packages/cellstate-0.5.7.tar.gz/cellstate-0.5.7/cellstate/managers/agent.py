"""
Agent Manager.

Manages agent registration and lifecycle in CELLSTATE.
"""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class AgentManager(BaseManager):
    """Manager for agent operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/agents")

    async def register(
        self,
        agent_type: str,
        capabilities: list[str] | None = None,
        can_delegate_to: list[str] | None = None,
        reports_to: str | None = None,
        metadata: dict[str, Any] | None = None,
        memory_access: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Register a new agent.

        Args:
            agent_type: Type of agent (e.g., "coder", "reviewer", "planner").
            capabilities: List of capabilities this agent has.
            can_delegate_to: Agent types this agent can delegate to.
            reports_to: UUID of supervisor agent.
            metadata: Optional arbitrary metadata.
            memory_access: Memory read/write permission configuration.
                Defaults to full read/write access on all memory types.
                Shape: {"read": [{"memory_type": "*", "scope": "tenant"}],
                        "write": [{"memory_type": "*", "scope": "tenant"}]}

        Returns:
            Registered agent data.
        """
        if memory_access is None:
            memory_access = {
                "read": [{"memory_type": "*", "scope": "tenant"}],
                "write": [{"memory_type": "*", "scope": "tenant"}],
            }
        body: dict[str, Any] = {
            "agent_type": agent_type,
            "capabilities": capabilities if capabilities is not None else [],
            "can_delegate_to": can_delegate_to if can_delegate_to is not None else [],
            "memory_access": memory_access,
        }
        if reports_to is not None:
            body["reports_to"] = reports_to
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, agent_id: str) -> dict[str, Any]:
        """Get an agent by ID.

        Args:
            agent_id: UUID of the agent.

        Returns:
            Agent data.
        """
        return await self.http.get(self._path(agent_id))

    async def list(
        self,
        status: str | None = None,
        agent_type: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        """List agents with optional filters.

        Args:
            status: Filter by agent status.
            agent_type: Filter by agent type.
            limit: Maximum number of results.
            offset: Pagination offset.

        Returns:
            Paginated list of agents.
        """
        params = self._clean_params({
            "status": status,
            "agent_type": agent_type,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def update(
        self,
        agent_id: str,
        capabilities: list[str] | None = None,
        status: str | None = None,
        can_delegate_to: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Update an agent.

        Args:
            agent_id: UUID of the agent.
            capabilities: New capabilities list.
            status: New status.
            can_delegate_to: New delegation targets.
            metadata: Updated metadata.

        Returns:
            Updated agent data.
        """
        body: dict[str, Any] = {}
        if capabilities is not None:
            body["capabilities"] = capabilities
        if status is not None:
            body["status"] = status
        if can_delegate_to is not None:
            body["can_delegate_to"] = can_delegate_to
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.patch(self._path(agent_id), body)

    async def unregister(self, agent_id: str) -> None:
        """Unregister an agent.

        Args:
            agent_id: UUID of the agent.
        """
        await self.http.delete(self._path(agent_id))

    async def heartbeat(self, agent_id: str) -> dict[str, Any]:
        """Send heartbeat for an agent.

        Args:
            agent_id: UUID of the agent.

        Returns:
            Heartbeat response with updated status.
        """
        return await self.http.post(f"{self._path(agent_id)}/heartbeat")

    async def kill(self, agent_id: str) -> dict[str, Any]:
        """Kill an agent immediately (emergency off switch).

        Args:
            agent_id: UUID of the agent.

        Returns:
            Updated agent data.
        """
        return await self.http.post(f"{self._path(agent_id)}/kill")

    async def create_goal(
        self,
        agent_id: str,
        goal: dict[str, Any],
    ) -> dict[str, Any]:
        """Create a new goal for an agent.

        Args:
            agent_id: UUID of the agent.
            goal: Goal parameters (e.g. description, priority).

        Returns:
            Created goal data.
        """
        return await self.http.post(f"{self._path(agent_id)}/goals", goal)

    async def activate_goal(
        self,
        agent_id: str,
        goal_id: str,
    ) -> dict[str, Any]:
        """Activate an existing goal.

        Args:
            agent_id: UUID of the agent.
            goal_id: UUID of the goal to activate.

        Returns:
            Updated goal data.
        """
        return await self.http.post(
            f"{self._path(agent_id)}/goals/{goal_id}/activate"
        )

    async def create_plan(
        self,
        agent_id: str,
        goal_id: str,
        plan: dict[str, Any],
    ) -> dict[str, Any]:
        """Create a plan for a goal.

        Args:
            agent_id: UUID of the agent.
            goal_id: UUID of the goal.
            plan: Plan parameters (e.g. steps).

        Returns:
            Created plan data.
        """
        return await self.http.post(
            f"{self._path(agent_id)}/goals/{goal_id}/plans", plan
        )

    async def complete_step(
        self,
        agent_id: str,
        plan_id: str,
        step_id: str,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Complete a plan step.

        Args:
            agent_id: UUID of the agent.
            plan_id: UUID of the plan.
            step_id: UUID of the step.
            params: Completion parameters (e.g. output, status).

        Returns:
            Completed step data.
        """
        return await self.http.post(
            f"{self._path(agent_id)}/plans/{plan_id}/steps/{step_id}/complete",
            params,
        )

    async def deliberate(self, agent_id: str) -> dict[str, Any]:
        """Trigger a deliberation cycle for the agent.

        Args:
            agent_id: UUID of the agent.

        Returns:
            Deliberation response.
        """
        return await self.http.post(f"{self._path(agent_id)}/deliberate")
