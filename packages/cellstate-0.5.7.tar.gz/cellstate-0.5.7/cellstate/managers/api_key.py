"""API Key Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class ApiKeyManager(BaseManager):
    """Manager for API key operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/api-keys")

    async def create(
        self,
        name: str,
        scopes: list[str] | None = None,
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name}
        if scopes is not None:
            body["scopes"] = scopes
        if expires_at is not None:
            body["expires_at"] = expires_at
        return await self.http.post(self.base_path, body)

    async def list(
        self,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def revoke(self, api_key_id: str) -> None:
        await self.http.post(f"{self._path(api_key_id)}/revoke")

    async def admin_list(
        self,
        tenant_id: str,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        """List API keys for a tenant (admin).

        Args:
            tenant_id: UUID of the tenant.
            limit: Maximum number of results.
            offset: Pagination offset.

        Returns:
            Paginated list of API keys for the tenant.
        """
        params = self._clean_params({
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(
            f"{self.base_path}/admin/tenants/{tenant_id}", params=params
        )

    async def admin_revoke(self, tenant_id: str, api_key_id: str) -> None:
        """Revoke an API key for a tenant (admin).

        Args:
            tenant_id: UUID of the tenant.
            api_key_id: UUID of the API key to revoke.
        """
        await self.http.post(
            f"{self.base_path}/admin/tenants/{tenant_id}/{api_key_id}/revoke"
        )
