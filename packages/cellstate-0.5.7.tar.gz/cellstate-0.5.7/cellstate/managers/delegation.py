"""Delegation Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class DelegationManager(BaseManager):
    """Manager for delegation operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/delegations")

    async def create(
        self,
        from_agent_id: str,
        to_agent_id: str,
        task: str,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "from_agent_id": from_agent_id,
            "to_agent_id": to_agent_id,
            "task": task,
        }
        if context is not None:
            body["context"] = context
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, delegation_id: str) -> dict[str, Any]:
        return await self.http.get(self._path(delegation_id))

    async def list(
        self,
        agent_id: str | None = None,
        status: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "agent_id": agent_id,
            "status": status,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def complete(
        self,
        delegation_id: str,
        completing_agent_id: str,
        result: dict[str, Any] | None = None,
        status: str | None = None,
    ) -> None:
        body: dict[str, Any] = {
            "completing_agent_id": completing_agent_id,
        }
        if result is not None:
            body["result"] = result
        if status is not None:
            body["status"] = status
        await self.http.post(f"{self._path(delegation_id)}/complete", body)

    async def reject(
        self,
        delegation_id: str,
        rejecting_agent_id: str,
        reason: str,
    ) -> None:
        await self.http.post(f"{self._path(delegation_id)}/reject", {
            "rejecting_agent_id": rejecting_agent_id,
            "reason": reason,
        })

    async def accept(
        self,
        delegation_id: str,
        accepting_agent_id: str,
    ) -> None:
        await self.http.post(f"{self._path(delegation_id)}/accept", {
            "accepting_agent_id": accepting_agent_id,
        })
