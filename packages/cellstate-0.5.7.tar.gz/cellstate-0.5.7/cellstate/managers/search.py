"""Search Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class SearchManager(BaseManager):
    """Manager for search operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/search")

    async def search(
        self,
        query: str,
        entity_types: list[str] | None = None,
        trajectory_id: str | None = None,
        limit: int | None = None,
        min_score: float | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"query": query}
        if entity_types is not None:
            body["entity_types"] = entity_types
        if trajectory_id is not None:
            body["trajectory_id"] = trajectory_id
        if limit is not None:
            body["limit"] = limit
        if min_score is not None:
            body["min_score"] = min_score
        return await self.http.post(self.base_path, body)
