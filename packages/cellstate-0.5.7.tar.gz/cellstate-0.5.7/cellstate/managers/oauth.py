"""OAuth Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class OAuthManager(BaseManager):
    """Manager for OAuth operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/oauth")

    async def connect(
        self,
        provider: str,
        redirect_uri: str,
        scopes: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "provider": provider,
            "redirect_uri": redirect_uri,
        }
        if scopes is not None:
            body["scopes"] = scopes
        return await self.http.post(f"{self.base_path}/connect", body)

    async def callback(self, code: str, state: str) -> dict[str, Any]:
        params = self._clean_params({"code": code, "state": state})
        return await self.http.get(f"{self.base_path}/callback", params=params)

    async def list_tokens(
        self,
        provider: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "provider": provider,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(f"{self.base_path}/tokens", params=params)

    async def upsert_token(
        self,
        provider: str,
        access_token: str,
        refresh_token: str | None = None,
        expires_at: str | None = None,
        scopes: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "provider": provider,
            "access_token": access_token,
        }
        if refresh_token is not None:
            body["refresh_token"] = refresh_token
        if expires_at is not None:
            body["expires_at"] = expires_at
        if scopes is not None:
            body["scopes"] = scopes
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.put(f"{self.base_path}/tokens", body)

    async def revoke(
        self,
        provider: str,
        agent_id: str | None = None,
    ) -> None:
        body: dict[str, Any] = {"provider": provider}
        if agent_id is not None:
            body["agent_id"] = agent_id
        await self.http.delete(f"{self.base_path}/tokens", data=body)

    async def rotate_token_encryption(self) -> dict[str, Any]:
        """Rotate the token encryption key.

        Returns:
            Rotation result with updated key metadata.
        """
        return await self.http.post(f"{self.base_path}/tokens/rotate")
