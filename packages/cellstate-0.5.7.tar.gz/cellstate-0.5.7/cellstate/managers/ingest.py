"""Ingest Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class IngestManager(BaseManager):
    """Manager for ingest operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/ingest")

    async def ingest(
        self,
        content: str,
        content_type: str | None = None,
        trajectory_id: str | None = None,
        scope_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"content": content}
        if content_type is not None:
            body["content_type"] = content_type
        if trajectory_id is not None:
            body["trajectory_id"] = trajectory_id
        if scope_id is not None:
            body["scope_id"] = scope_id
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)
