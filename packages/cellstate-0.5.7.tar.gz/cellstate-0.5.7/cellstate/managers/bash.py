"""Bash Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class BashManager(BaseManager):
    """Manager for bash execution operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/bash")

    async def report_execution(
        self,
        session_id: str,
        agent_id: str,
        trajectory_id: str,
        scope_id: str,
        command: str,
        exit_code: int,
        duration_ms: int,
        timed_out: bool,
        files_modified: list[str],
        stdout_preview: str,
        stderr_preview: str,
        file_mutations: list[dict[str, Any]] | None = None,
        source_turn: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "session_id": session_id,
            "agent_id": agent_id,
            "trajectory_id": trajectory_id,
            "scope_id": scope_id,
            "command": command,
            "exit_code": exit_code,
            "duration_ms": duration_ms,
            "timed_out": timed_out,
            "files_modified": files_modified,
            "stdout_preview": stdout_preview,
            "stderr_preview": stderr_preview,
        }
        if file_mutations is not None:
            body["file_mutations"] = file_mutations
        if source_turn is not None:
            body["source_turn"] = source_turn
        return await self.http.post(f"{self.base_path}/report", body)

    async def execute(
        self,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        timeout_ms: int | None = None,
        memory_bytes: int | None = None,
        max_output_bytes: int | None = None,
        isolation_level: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"command": command}
        if args is not None:
            body["args"] = args
        if env is not None:
            body["env"] = env
        if timeout_ms is not None:
            body["timeout_ms"] = timeout_ms
        if memory_bytes is not None:
            body["memory_bytes"] = memory_bytes
        if max_output_bytes is not None:
            body["max_output_bytes"] = max_output_bytes
        if isolation_level is not None:
            body["isolation_level"] = isolation_level
        return await self.http.post(f"{self.base_path}/execute", body)

    async def list_executions(
        self,
        trajectory_id: str | None = None,
        scope_id: str | None = None,
        agent_id: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "trajectory_id": trajectory_id,
            "scope_id": scope_id,
            "agent_id": agent_id,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(f"{self.base_path}/executions", params=params)
