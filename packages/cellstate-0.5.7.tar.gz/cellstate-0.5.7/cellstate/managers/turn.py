"""
Turn Manager.

Manages turns (ephemeral conversation messages) in CELLSTATE.
"""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class TurnManager(BaseManager):
    """Manager for turn operations.

    Note: Turns are ephemeral and are deleted when their scope closes.
    Extract important information to artifacts before closing a scope.
    """

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/turns")

    async def create(
        self,
        scope_id: str,
        role: str,
        content: str,
        token_count: int | None = None,
        tool_calls: dict[str, Any] | None = None,
        tool_results: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new turn.

        Args:
            scope_id: UUID of the scope.
            role: Role of the speaker ("User", "Assistant", "System", "Tool").
            content: Message content.
            token_count: Optional token count for the message.
            tool_calls: Optional tool call data.
            tool_results: Optional tool result data.
            metadata: Optional arbitrary metadata.

        Returns:
            Created turn data.
        """
        body: dict[str, Any] = {
            "scope_id": scope_id,
            "role": role,
            "content": content,
        }
        if token_count is not None:
            body["token_count"] = token_count
        if tool_calls is not None:
            body["tool_calls"] = tool_calls
        if tool_results is not None:
            body["tool_results"] = tool_results
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, turn_id: str) -> dict[str, Any]:
        """Get a turn by ID.

        Args:
            turn_id: UUID of the turn.

        Returns:
            Turn data.
        """
        return await self.http.get(self._path(turn_id))
