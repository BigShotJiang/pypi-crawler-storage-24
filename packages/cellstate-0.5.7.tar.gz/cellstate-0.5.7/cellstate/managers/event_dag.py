"""Event DAG Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class EventDagManager(BaseManager):
    """Manager for event DAG operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/event-dag")

    async def get_node(self, event_id: str) -> dict[str, Any]:
        return await self.http.get(self._path(event_id))

    async def traverse(
        self,
        event_id: str,
        direction: str = "ancestors",
        limit: int = 100,
    ) -> dict[str, Any]:
        params = self._clean_params({"limit": limit})
        return await self.http.get(f"{self._path(event_id)}/{direction}", params=params)

    async def lca(
        self,
        event_id: str,
        other_event_id: str,
        limit: int = 100,
    ) -> dict[str, Any]:
        params = self._clean_params({"limit": limit})
        return await self.http.get(f"{self._path(event_id)}/lca/{other_event_id}", params=params)

    async def find_by_kind(
        self,
        kind: int,
        min_depth: int | None = None,
        max_depth: int | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Search events by kind.

        Args:
            kind: Numeric event kind code.
            min_depth: Minimum depth filter.
            max_depth: Maximum depth filter.
            limit: Maximum number of results.

        Returns:
            Traversal response with matching events and count.
        """
        params = self._clean_params({
            "min_depth": min_depth,
            "max_depth": max_depth,
            "limit": limit,
        })
        return await self.http.get(
            f"{self.base_path}/by-kind/{kind}", params=params
        )
