"""Edge Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class EdgeManager(BaseManager):
    """Manager for edge operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/edges")

    async def create(
        self,
        edge_type: str,
        participants: list[dict[str, Any]],
        provenance: str | None = None,
        weight: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "edge_type": edge_type,
            "participants": participants,
        }
        if provenance is not None:
            body["provenance"] = provenance
        if weight is not None:
            body["weight"] = weight
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def create_batch(self, edges: list[dict[str, Any]]) -> dict[str, Any]:
        return await self.http.post(f"{self.base_path}/batch", edges)

    async def get(self, edge_id: str) -> dict[str, Any]:
        return await self.http.get(self._path(edge_id))

    async def list_by_participant(self, entity_id: str) -> dict[str, Any]:
        return await self.http.get(f"{self.base_path}/by-participant/{entity_id}")

    async def delete(self, edge_id: str) -> None:
        await self.http.delete(self._path(edge_id))

    async def traverse(
        self,
        start_id: str,
        max_depth: int | None = None,
        rel_types: list[str] | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "start_id": start_id,
            "max_depth": max_depth,
            "rel_types": ",".join(rel_types) if rel_types is not None else None,
            "limit": limit,
        })
        return await self.http.get(f"{self.base_path}/traverse", params=params)
