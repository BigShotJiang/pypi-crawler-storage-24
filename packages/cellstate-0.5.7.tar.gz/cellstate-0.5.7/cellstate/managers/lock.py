"""Lock Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class LockManager(BaseManager):
    """Manager for lock operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/locks")

    async def acquire(
        self,
        resource_id: str,
        holder_id: str,
        ttl_ms: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "resource_id": resource_id,
            "holder_id": holder_id,
        }
        if ttl_ms is not None:
            body["ttl_ms"] = ttl_ms
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(f"{self.base_path}/acquire", body)

    async def get(self, lock_id: str) -> dict[str, Any]:
        return await self.http.get(self._path(lock_id))

    async def list(
        self,
        resource_id: str | None = None,
        holder_id: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "resource_id": resource_id,
            "holder_id": holder_id,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def release(self, lock_id: str) -> None:
        await self.http.post(f"{self._path(lock_id)}/release")

    async def extend(self, lock_id: str, ttl_ms: int) -> dict[str, Any]:
        body: dict[str, Any] = {"ttl_ms": ttl_ms}
        return await self.http.post(f"{self._path(lock_id)}/extend", body)
