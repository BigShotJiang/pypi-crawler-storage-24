"""
Trajectory Manager.

Manages trajectories (task containers) in CELLSTATE.
"""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class TrajectoryManager(BaseManager):
    """Manager for trajectory operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/trajectories")

    async def create(
        self,
        name: str,
        description: str | None = None,
        agent_id: str | None = None,
        parent_trajectory_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new trajectory.

        Args:
            name: Human-readable trajectory name.
            description: Optional description of the task.
            agent_id: Optional agent identifier.
            parent_trajectory_id: Optional parent for sub-tasks.
            metadata: Optional arbitrary metadata.

        Returns:
            Created trajectory data.
        """
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        if agent_id is not None:
            body["agent_id"] = agent_id
        if parent_trajectory_id is not None:
            body["parent_trajectory_id"] = parent_trajectory_id
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, trajectory_id: str) -> dict[str, Any]:
        """Get a trajectory by ID.

        Args:
            trajectory_id: UUID of the trajectory.

        Returns:
            Trajectory data.
        """
        return await self.http.get(self._path(trajectory_id))

    async def list(
        self,
        status: str | None = None,
        agent_id: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        """List trajectories with optional filters.

        Args:
            status: Filter by trajectory status.
            agent_id: Filter by agent ID.
            limit: Maximum number of results.
            offset: Pagination offset.

        Returns:
            Paginated list of trajectories.
        """
        params = self._clean_params({
            "status": status,
            "agent_id": agent_id,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def update(
        self,
        trajectory_id: str,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Update a trajectory.

        Args:
            trajectory_id: UUID of the trajectory.
            name: New name.
            description: New description.
            status: New status.
            metadata: Updated metadata.

        Returns:
            Updated trajectory data.
        """
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if status is not None:
            body["status"] = status
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.patch(self._path(trajectory_id), body)

    async def report_outcome(
        self,
        trajectory_id: str,
        outcome: dict[str, Any],
    ) -> dict[str, Any]:
        """Report the outcome for a completed trajectory.

        Outcome data must be submitted via the dedicated outcome endpoint,
        not via the general PATCH update route.

        Args:
            trajectory_id: UUID of the trajectory.
            outcome: Outcome data (e.g. status, summary, artifacts produced).

        Returns:
            Updated trajectory data with outcome recorded.
        """
        return await self.http.post(
            f"{self._path(trajectory_id)}/outcome",
            outcome,
        )

    async def delete(self, trajectory_id: str) -> None:
        """Delete a trajectory.

        Args:
            trajectory_id: UUID of the trajectory.
        """
        await self.http.delete(self._path(trajectory_id))

    async def list_scopes(self, trajectory_id: str) -> list[dict[str, Any]]:
        """List scopes for a trajectory.

        Args:
            trajectory_id: UUID of the trajectory.

        Returns:
            List of scope data.
        """
        return await self.http.get(f"{self._path(trajectory_id)}/scopes")

    async def list_children(self, trajectory_id: str) -> dict[str, Any]:
        """List child trajectories.

        Args:
            trajectory_id: UUID of the parent trajectory.

        Returns:
            Paginated list of child trajectories.
        """
        return await self.http.get(f"{self._path(trajectory_id)}/children")

    async def get_outcome_graph(self, trajectory_id: str) -> dict[str, Any]:
        """Get the trajectory outcome graph.

        Args:
            trajectory_id: UUID of the trajectory.

        Returns:
            Outcome graph data.
        """
        return await self.http.get(
            f"{self._path(trajectory_id)}/outcome-graph"
        )
