"""Deployment Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class DeploymentManager(BaseManager):
    """Manager for deployment operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/deployments")

    async def create(
        self,
        pack_name: str,
        config_version: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "pack_name": pack_name,
            "config_version": config_version,
        }
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, deployment_id: str) -> dict[str, Any]:
        return await self.http.get(self._path(deployment_id))

    async def list(self, pack_name: str) -> dict[str, Any]:
        params = self._clean_params({"pack_name": pack_name})
        return await self.http.get(self.base_path, params=params)

    async def activate(self, deployment_id: str, rollout_percentage: int) -> dict[str, Any]:
        body: dict[str, Any] = {"rollout_percentage": rollout_percentage}
        return await self.http.post(f"{self._path(deployment_id)}/activate", body)

    async def rollout(self, deployment_id: str, rollout_percentage: int) -> dict[str, Any]:
        body: dict[str, Any] = {"rollout_percentage": rollout_percentage}
        return await self.http.post(f"{self._path(deployment_id)}/rollout", body)

    async def rollback(self, pack_name: str) -> dict[str, Any]:
        body: dict[str, Any] = {"pack_name": pack_name}
        return await self.http.post(f"{self.base_path}/rollback", body)
