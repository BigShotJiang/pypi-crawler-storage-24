"""Message Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class MessageManager(BaseManager):
    """Manager for message operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/messages")

    async def send(
        self,
        from_agent_id: str,
        to_agent_id: str,
        content: str,
        message_type: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "from_agent_id": from_agent_id,
            "to_agent_id": to_agent_id,
            "content": content,
        }
        if message_type is not None:
            body["message_type"] = message_type
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, message_id: str) -> dict[str, Any]:
        return await self.http.get(self._path(message_id))

    async def list(
        self,
        agent_id: str | None = None,
        direction: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "agent_id": agent_id,
            "direction": direction,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def acknowledge(self, message_id: str, agent_id: str) -> None:
        body: dict[str, Any] = {"agent_id": agent_id}
        await self.http.post(f"{self._path(message_id)}/acknowledge", body)

    async def deliver(self, message_id: str, agent_id: str) -> None:
        body: dict[str, Any] = {"agent_id": agent_id}
        await self.http.post(f"{self._path(message_id)}/deliver", body)
