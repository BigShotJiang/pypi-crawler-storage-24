"""
Pack Config Manager.

Validates and parses CELLSTATE pack configurations.
"""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class PackConfigManager(BaseManager):
    """Manager for pack config operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/pack-config")

    async def validate(self, source: str) -> dict[str, Any]:
        """Validate pack source code (syntax check only).

        Args:
            source: Pack source code string.

        Returns:
            Validation result with ``valid`` flag and any errors.
        """
        return await self.http.post(f"{self.base_path}/validate", {"source": source})

    async def parse(self, source: str) -> dict[str, Any]:
        """Parse pack source code to AST.

        Returns the same structure as validate, but with the ``ast``
        field populated when parsing succeeds.

        Args:
            source: Pack source code string.

        Returns:
            Parse result with ``valid`` flag, errors, and optional AST.
        """
        return await self.http.post(f"{self.base_path}/parse", {"source": source})

    async def list(self) -> dict[str, Any]:
        """List available pack templates.

        Returns:
            Template gallery listing with ``templates`` array.
        """
        return await self.http.get(f"{self.base_path}/templates")

    async def deploy(
        self,
        name: str,
        source: str,
        pack: dict[str, Any],
        activate: bool | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        """Deploy a pack configuration.

        Args:
            name: Pack name.
            source: Pack source identifier.
            pack: Pack payload with ``manifest`` and ``markdowns``.
            activate: Whether to activate immediately.
            notes: Optional deployment notes.

        Returns:
            Deployment result with config_id, version, and status.
        """
        body: dict[str, Any] = {
            "name": name,
            "source": source,
            "pack": pack,
        }
        if activate is not None:
            body["activate"] = activate
        if notes is not None:
            body["notes"] = notes
        return await self.http.post(f"{self.base_path}/deploy", body)

    async def inspect(self) -> dict[str, Any]:
        """Inspect the currently active pack.

        Returns:
            Inspection result with ``has_active`` flag and optional
            ``pack_source`` containing manifest and markdowns.
        """
        return await self.http.get("/api/v1/pack/inspect")

    async def compile(self, source: str) -> dict[str, Any]:
        """Compile pack source to a runtime configuration.

        Args:
            source: Pack source code string.

        Returns:
            Compiled pack configuration.
        """
        return await self.http.post(f"{self.base_path}/compile", {"source": source})

    async def compose(self, form_data: Any) -> dict[str, Any]:
        """Compose a pack from multipart form data (manifest + markdowns).

        Args:
            form_data: Multipart form data payload.

        Returns:
            Composed pack result.
        """
        return await self.http.post(f"{self.base_path}/compose", form_data)
