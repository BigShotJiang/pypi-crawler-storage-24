"""
Scope Manager.

Manages scopes (context windows) in CELLSTATE.
"""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class ScopeManager(BaseManager):
    """Manager for scope operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/scopes")

    async def create(
        self,
        trajectory_id: str,
        name: str,
        purpose: str | None = None,
        token_budget: int = 8000,
        parent_scope_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new scope.

        Args:
            trajectory_id: UUID of the parent trajectory.
            name: Name for the scope.
            purpose: Optional purpose description.
            token_budget: Token budget for this scope.
            parent_scope_id: Optional parent scope for nesting.
            metadata: Optional arbitrary metadata.

        Returns:
            Created scope data.
        """
        body: dict[str, Any] = {
            "trajectory_id": trajectory_id,
            "name": name,
            "token_budget": token_budget,
        }
        if purpose is not None:
            body["purpose"] = purpose
        if parent_scope_id is not None:
            body["parent_scope_id"] = parent_scope_id
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.post(self.base_path, body)

    async def get(self, scope_id: str) -> dict[str, Any]:
        """Get a scope by ID.

        Args:
            scope_id: UUID of the scope.

        Returns:
            Scope data.
        """
        return await self.http.get(self._path(scope_id))

    async def update(
        self,
        scope_id: str,
        name: str | None = None,
        purpose: str | None = None,
        token_budget: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Update a scope.

        Args:
            scope_id: UUID of the scope.
            name: New name.
            purpose: New purpose.
            token_budget: New token budget.
            metadata: Updated metadata.

        Returns:
            Updated scope data.
        """
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if purpose is not None:
            body["purpose"] = purpose
        if token_budget is not None:
            body["token_budget"] = token_budget
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.patch(self._path(scope_id), body)

    async def checkpoint(
        self,
        scope_id: str,
        context_state: str,
        recoverable: bool = True,
    ) -> dict[str, Any]:
        """Create a checkpoint for a scope.

        Args:
            scope_id: UUID of the scope.
            context_state: Base64-encoded context state.
            recoverable: Whether the checkpoint is recoverable.

        Returns:
            Created checkpoint data.
        """
        body = {"context_state": context_state, "recoverable": recoverable}
        return await self.http.post(f"{self._path(scope_id)}/checkpoint", body)

    async def close(self, scope_id: str) -> dict[str, Any]:
        """Close a scope.

        WARNING: Closing a scope deletes all turns within it.
        Extract important information to artifacts before closing.

        Args:
            scope_id: UUID of the scope.

        Returns:
            Closed scope data.
        """
        return await self.http.post(f"{self._path(scope_id)}/close")

    async def list_turns(self, scope_id: str) -> list[dict[str, Any]]:
        """List turns in a scope.

        Args:
            scope_id: UUID of the scope.

        Returns:
            List of turn data.
        """
        return await self.http.get(f"{self._path(scope_id)}/turns")

    async def list_artifacts(self, scope_id: str) -> list[dict[str, Any]]:
        """List artifacts in a scope.

        Args:
            scope_id: UUID of the scope.

        Returns:
            List of artifact data.
        """
        return await self.http.get(f"{self._path(scope_id)}/artifacts")
