"""Config Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class ConfigManager(BaseManager):
    """Manager for config operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/config")

    async def get(self) -> dict[str, Any]:
        return await self.http.get(self.base_path)

    async def update(self, config: dict[str, Any]) -> dict[str, Any]:
        return await self.http.patch(self.base_path, config)

    async def validate(self, config: dict[str, Any]) -> dict[str, Any]:
        return await self.http.post(f"{self.base_path}/validate", config)
