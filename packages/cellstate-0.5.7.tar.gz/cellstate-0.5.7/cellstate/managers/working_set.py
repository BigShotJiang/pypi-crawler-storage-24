"""Working Set Manager."""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from cellstate.managers.base import BaseManager


class WorkingSetManager(BaseManager):
    """Manager for working set operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/working-set")

    async def upsert(
        self,
        agent_id: str,
        key: str,
        value: Any,
        scope_id: str | None = None,
        expires_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "agent_id": agent_id,
            "key": key,
            "value": value,
        }
        if scope_id is not None:
            body["scope_id"] = scope_id
        if expires_at is not None:
            body["expires_at"] = expires_at
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.put(self.base_path, body)

    async def patch(
        self,
        agent_id: str,
        key: str,
        value: Any = None,
        scope_id: str | None = None,
        expires_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if value is not None:
            body["value"] = value
        if scope_id is not None:
            body["scope_id"] = scope_id
        if expires_at is not None:
            body["expires_at"] = expires_at
        if metadata is not None:
            body["metadata"] = metadata
        return await self.http.patch(f"{self.base_path}/{agent_id}/{quote(key, safe='')}", body)

    async def list(
        self,
        agent_id: str | None = None,
        scope_id: str | None = None,
        key_prefix: str | None = None,
        active_only: bool | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "agent_id": agent_id,
            "scope_id": scope_id,
            "key_prefix": key_prefix,
            "active_only": active_only,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def get(self, agent_id: str, key: str) -> dict[str, Any]:
        return await self.http.get(f"{self.base_path}/{agent_id}/{quote(key, safe='')}")

    async def delete(self, agent_id: str, key: str) -> None:
        await self.http.delete(f"{self.base_path}/{agent_id}/{quote(key, safe='')}")
