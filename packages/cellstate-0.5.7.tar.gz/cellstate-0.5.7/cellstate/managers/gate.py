"""Gate Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class GateManager(BaseManager):
    """Manager for gate operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/gates")

    async def list_metadata(self) -> dict[str, Any]:
        return await self.http.get(f"{self.base_path}/metadata")

    async def stats(
        self,
        start_time: str | None = None,
        end_time: str | None = None,
        reasons_limit: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "start_time": start_time,
            "end_time": end_time,
            "reasons_limit": reasons_limit,
        })
        return await self.http.get(f"{self.base_path}/stats", params=params)

    async def get_pack_gates(self, pack_id: str) -> dict[str, Any]:
        """Fetch gate configuration for a specific pack.

        Args:
            pack_id: UUID of the pack.

        Returns:
            Gate configuration data with ``gates`` array.
        """
        return await self.http.get(f"/api/v1/packs/{pack_id}/gates")

    async def get_pack_mutations(
        self,
        pack_id: str,
        mutation_type: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        """Fetch mutation flow history for a specific pack.

        Args:
            pack_id: UUID of the pack.
            mutation_type: Filter by mutation type.
            start_time: Start of time range (ISO 8601).
            end_time: End of time range (ISO 8601).
            limit: Maximum number of results.
            offset: Pagination offset.

        Returns:
            Mutation flow data with ``mutations`` array.
        """
        params = self._clean_params({
            "mutation_type": mutation_type,
            "start_time": start_time,
            "end_time": end_time,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(
            f"/api/v1/packs/{pack_id}/mutations", params=params
        )

    async def get_pack_gate_stats(
        self,
        pack_id: str,
        start_time: str | None = None,
        end_time: str | None = None,
    ) -> dict[str, Any]:
        """Fetch aggregate gate statistics for a specific pack.

        Args:
            pack_id: UUID of the pack.
            start_time: Start of time range (ISO 8601).
            end_time: End of time range (ISO 8601).

        Returns:
            Aggregate gate statistics.
        """
        params = self._clean_params({
            "start_time": start_time,
            "end_time": end_time,
        })
        return await self.http.get(
            f"/api/v1/packs/{pack_id}/gate-stats", params=params
        )
