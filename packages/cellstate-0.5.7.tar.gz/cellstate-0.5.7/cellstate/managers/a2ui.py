"""A2UI Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class A2UIManager(BaseManager):
    """Manager for A2UI operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/a2ui")

    async def catalog(self) -> dict[str, Any]:
        return await self.http.get(f"{self.base_path}/catalog")

    async def render(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self.http.post(f"{self.base_path}/render", request)
