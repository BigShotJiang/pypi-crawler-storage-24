"""Context Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class ContextManager(BaseManager):
    """Manager for context assembly operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/context")

    async def assemble(
        self,
        trajectory_id: str,
        scope_id: str,
        user_input: str | None = None,
        max_tokens: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "trajectory_id": trajectory_id,
            "scope_id": scope_id,
        }
        if user_input is not None:
            body["user_input"] = user_input
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        return await self.http.post(f"{self.base_path}/assemble", body)
