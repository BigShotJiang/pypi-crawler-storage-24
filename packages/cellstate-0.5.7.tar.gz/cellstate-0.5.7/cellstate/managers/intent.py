"""Intent Manager."""

from __future__ import annotations

from typing import Any

from cellstate.managers.base import BaseManager


class IntentManager(BaseManager):
    """Manager for intent operations."""

    def __init__(self, http: Any):
        super().__init__(http, "/api/v1/intents")

    async def create(
        self,
        name: str,
        goals: list[str] | None = None,
        resolution_rules: list[str] | None = None,
        autonomy_level: str | None = None,
        delegation_boundaries: dict[str, Any] | None = None,
        alignment_signals: list[str] | None = None,
        drift_threshold: float | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name}
        if goals is not None:
            body["goals"] = goals
        if resolution_rules is not None:
            body["resolution_rules"] = resolution_rules
        if autonomy_level is not None:
            body["autonomy_level"] = autonomy_level
        if delegation_boundaries is not None:
            body["delegation_boundaries"] = delegation_boundaries
        if alignment_signals is not None:
            body["alignment_signals"] = alignment_signals
        if drift_threshold is not None:
            body["drift_threshold"] = drift_threshold
        return await self.http.post(self.base_path, body)

    async def get(self, intent_name: str) -> dict[str, Any]:
        return await self.http.get(self._path(intent_name))

    async def list(
        self,
        agent_id: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params = self._clean_params({
            "agent_id": agent_id,
            "limit": limit,
            "offset": offset,
        })
        return await self.http.get(self.base_path, params=params)

    async def update(
        self,
        intent_name: str,
        goals: list[str] | None = None,
        resolution_rules: list[str] | None = None,
        autonomy_level: str | None = None,
        delegation_boundaries: dict[str, Any] | None = None,
        alignment_signals: list[str] | None = None,
        drift_threshold: float | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if goals is not None:
            body["goals"] = goals
        if resolution_rules is not None:
            body["resolution_rules"] = resolution_rules
        if autonomy_level is not None:
            body["autonomy_level"] = autonomy_level
        if delegation_boundaries is not None:
            body["delegation_boundaries"] = delegation_boundaries
        if alignment_signals is not None:
            body["alignment_signals"] = alignment_signals
        if drift_threshold is not None:
            body["drift_threshold"] = drift_threshold
        return await self.http.patch(self._path(intent_name), body)

    async def delete(self, intent_name: str) -> None:
        await self.http.delete(self._path(intent_name))

    async def score_alignment(self, agent_id: str) -> dict[str, Any]:
        return await self.http.get(f"{self.base_path}/alignment/{agent_id}")

    async def get_drift_report(self, agent_id: str) -> dict[str, Any]:
        return await self.http.get(f"{self.base_path}/drift/{agent_id}")
