"""
Base manager class.

Provides common functionality for all resource managers.
"""

from __future__ import annotations

from typing import Any

from cellstate.http import HttpClient


class BaseManager:
    """Base class for all resource managers."""

    def __init__(self, http: HttpClient, base_path: str):
        self.http = http
        self.base_path = base_path

    def _path(self, resource_id: str) -> str:
        """Build full path with resource ID."""
        return f"{self.base_path}/{resource_id}"

    @staticmethod
    def _clean_params(params: dict[str, Any]) -> dict[str, Any]:
        """Build query parameters, filtering out None values."""
        return {k: v for k, v in params.items() if v is not None}
