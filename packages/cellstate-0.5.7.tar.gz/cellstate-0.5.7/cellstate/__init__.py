"""
CELLSTATE Python SDK

The memory and orchestration layer for AI agents.

Quickstart::

    from cellstate import SimpleMemory

    memory = SimpleMemory(api_key="cst_...")

    result = await memory.add("User prefers Python and Pydantic")
    print(result.receipt)  # Blake3 hash — tamper-evident proof of every write

    ctx = await memory.context("what does the user prefer?")
    # ctx.text is ready to inject into any LLM prompt
"""

from cellstate.client import CellstateClient
from cellstate.http import HttpClient
from cellstate.managers import (
    A2UIManager,
    AgentManager,
    ApiKeyManager,
    ArtifactManager,
    BashManager,
    BatchManager,
    BrowserManager,
    ConfigManager,
    ContextManager,
    DelegationManager,
    DeploymentManager,
    EdgeManager,
    EventDagManager,
    GateManager,
    HandoffManager,
    IngestManager,
    IntentManager,
    LockManager,
    MessageManager,
    ModelManager,
    NoteManager,
    OAuthManager,
    PackConfigManager,
    ScopeManager,
    SearchManager,
    SummarizationManager,
    TrajectoryManager,
    TurnManager,
    WebMcpManager,
    WorkingSetManager,
)
from cellstate.models import (
    AgentResponse,
    ArtifactResponse,
    NoteResponse,
    ScopeResponse,
    TrajectoryResponse,
    TurnResponse,
)
from cellstate.simple_memory import (
    AddResult,
    ContextResult,
    ForgetAllResult,
    ForgetResult,
    HistoryEvent,
    RecallResult,
    SimpleMemory,
    SimpleMemoryConfig,
)

try:
    from importlib.metadata import version as _meta_version
    __version__ = _meta_version("cellstate")
except Exception:
    __version__ = "0.5.7"

__all__ = [
    # Primary entry point — start here
    "SimpleMemory",
    "SimpleMemoryConfig",
    "AddResult",
    "RecallResult",
    "ContextResult",
    "ForgetResult",
    "ForgetAllResult",
    "HistoryEvent",
    # Full client for advanced use
    "CellstateClient",
    "HttpClient",
    # Response models
    "TrajectoryResponse",
    "ScopeResponse",
    "ArtifactResponse",
    "NoteResponse",
    "TurnResponse",
    "AgentResponse",
    # Managers
    "AgentManager",
    "ArtifactManager",
    "NoteManager",
    "PackConfigManager",
    "ScopeManager",
    "TrajectoryManager",
    "TurnManager",
    "LockManager",
    "MessageManager",
    "DelegationManager",
    "HandoffManager",
    "SearchManager",
    "BatchManager",
    "BashManager",
    "BrowserManager",
    "EventDagManager",
    "GateManager",
    "DeploymentManager",
    "ConfigManager",
    "ContextManager",
    "IngestManager",
    "ApiKeyManager",
    "OAuthManager",
    "EdgeManager",
    "SummarizationManager",
    "WorkingSetManager",
    "WebMcpManager",
    "IntentManager",
    "ModelManager",
    "A2UIManager",
]
