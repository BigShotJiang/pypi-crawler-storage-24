"""
CELLSTATE WebSocket Client.

Provides real-time event streaming from the CELLSTATE API.
Handles automatic reconnection, authentication, and event filtering.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

logger = logging.getLogger(__name__)

# WebSocket event types (matches Rust WsEvent enum)
WsEventType = str

# Connection state
ConnectionState = str  # "disconnected" | "connecting" | "connected" | "reconnecting"

# Event handler callback
EventHandler = Callable[[dict[str, Any]], None]


class CellstateWebSocket:
    """CELLSTATE WebSocket client.

    Provides real-time event streaming with automatic reconnection.

    Example::

        from cellstate.websocket import CellstateWebSocket

        ws = CellstateWebSocket(
            base_url="https://cst.batterypack.dev",
            api_key="cst_...",
            tenant_id="your-tenant-id",
        )

        def on_trajectory_created(event):
            print("New trajectory:", event)

        ws.on("TrajectoryCreated", on_trajectory_created)

        await ws.connect()
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        tenant_id: str,
        auto_reconnect: bool = True,
        max_reconnect_attempts: int = 10,
        reconnect_delay: float = 1.0,
        max_reconnect_delay: float = 30.0,
        heartbeat_interval: float = 30.0,
    ):
        self._base_url = base_url
        self._api_key = api_key
        self._tenant_id = tenant_id
        self._auto_reconnect = auto_reconnect
        self._max_reconnect_attempts = max_reconnect_attempts
        self._reconnect_delay = reconnect_delay
        self._max_reconnect_delay = max_reconnect_delay
        self._heartbeat_interval = heartbeat_interval

        self._state: ConnectionState = "disconnected"
        self._reconnect_attempts = 0
        self._ws: Any = None
        self._event_handlers: dict[str, list[EventHandler]] = {}
        self._state_handlers: list[Callable[[ConnectionState], None]] = []
        self._tasks: list[asyncio.Task[Any]] = []

    @property
    def state(self) -> ConnectionState:
        """Get current connection state."""
        return self._state

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._state == "connected"

    async def connect(self) -> None:
        """Connect to the CELLSTATE WebSocket server.

        Authenticates by first obtaining a short-lived single-use ticket from
        ``POST /api/v1/proxy/ws-ticket``, then opens the WebSocket connection
        with ``GET /api/v1/ws?ticket=<ticket>``.
        """
        if self._state in ("connected", "connecting"):
            return

        try:
            import websockets
        except ImportError as e:
            raise ImportError(
                "websockets is required for CellstateWebSocket. "
                "Install it with: pip install cellstate"
            ) from e

        self._set_state("connecting")

        # Step 1: obtain a single-use WS ticket via authenticated REST call.
        ticket = await self._fetch_ws_ticket()

        # Step 2: open WebSocket using ticket as query parameter (no auth header).
        ws_url = self._build_ws_url(ticket)

        self._ws = await websockets.connect(ws_url)
        self._set_state("connected")
        self._reconnect_attempts = 0

        # Start listener and heartbeat tasks
        self._tasks.append(asyncio.create_task(self._listen()))
        self._tasks.append(asyncio.create_task(self._heartbeat_loop()))

    async def disconnect(self) -> None:
        """Disconnect from the CELLSTATE WebSocket server."""
        for task in self._tasks:
            task.cancel()
        self._tasks.clear()

        if self._ws is not None:
            await self._ws.close()
            self._ws = None

        self._set_state("disconnected")

    def on(self, event_type: str, handler: EventHandler) -> Callable[[], None]:
        """Subscribe to a specific event type.

        Args:
            event_type: The event type to subscribe to, or "*" for all.
            handler: Callback function.

        Returns:
            Unsubscribe function.
        """
        if event_type not in self._event_handlers:
            self._event_handlers[event_type] = []
        self._event_handlers[event_type].append(handler)

        def unsubscribe() -> None:
            handlers = self._event_handlers.get(event_type)
            if handlers and handler in handlers:
                handlers.remove(handler)

        return unsubscribe

    def on_event(self, handler: EventHandler) -> Callable[[], None]:
        """Subscribe to all events.

        Args:
            handler: Callback function.

        Returns:
            Unsubscribe function.
        """
        return self.on("*", handler)

    def on_state_change(self, handler: Callable[[ConnectionState], None]) -> Callable[[], None]:
        """Subscribe to connection state changes.

        Args:
            handler: Callback function.

        Returns:
            Unsubscribe function.
        """
        self._state_handlers.append(handler)

        def unsubscribe() -> None:
            if handler in self._state_handlers:
                self._state_handlers.remove(handler)

        return unsubscribe

    # =========================================================================
    # Private Methods
    # =========================================================================

    async def _fetch_ws_ticket(self) -> str:
        """Obtain a short-lived single-use WebSocket auth ticket.

        Posts to ``POST /api/v1/proxy/ws-ticket`` with the API key and
        returns the ticket string (``wst_...``).
        """
        import httpx

        url = self._base_url.rstrip("/") + "/api/v1/proxy/ws-ticket"
        headers = {
            "X-Api-Key": self._api_key,
            "X-Tenant-ID": self._tenant_id,
            "Content-Type": "application/json",
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json={}, headers=headers)
            response.raise_for_status()
            data = response.json()
        return data["ticket"]

    def _build_ws_url(self, ticket: str) -> str:
        """Build the WebSocket URL with the ticket as a query parameter."""
        ws_url = self._base_url.replace("https://", "wss://").replace("http://", "ws://")
        ws_url = ws_url.rstrip("/")
        return f"{ws_url}/api/v1/ws?ticket={ticket}"

    def _set_state(self, state: ConnectionState) -> None:
        """Update connection state and notify handlers."""
        if self._state != state:
            self._state = state
            for handler in self._state_handlers:
                try:
                    handler(state)
                except Exception:
                    logger.exception("Error in state change handler")

    def _emit(self, event: dict[str, Any]) -> None:
        """Emit an event to registered handlers."""
        event_type = event.get("type", "")

        # Notify type-specific handlers
        for handler in self._event_handlers.get(event_type, []):
            try:
                handler(event)
            except Exception:
                logger.exception("Error in event handler for %s", event_type)

        # Notify wildcard handlers
        for handler in self._event_handlers.get("*", []):
            try:
                handler(event)
            except Exception:
                logger.exception("Error in wildcard event handler")

    async def _listen(self) -> None:
        """Listen for incoming WebSocket messages."""
        try:
            async for message in self._ws:
                try:
                    event = json.loads(message)
                    self._emit(event)
                except json.JSONDecodeError:
                    logger.warning("Failed to parse WebSocket message: %s", message)
        except Exception:
            logger.exception("WebSocket connection lost")
            if self._auto_reconnect and self._reconnect_attempts < self._max_reconnect_attempts:
                await self._schedule_reconnect()
            else:
                self._set_state("disconnected")

    async def _heartbeat_loop(self) -> None:
        """Send periodic heartbeat messages."""
        while self._state == "connected":
            await asyncio.sleep(self._heartbeat_interval)
            if self._ws is not None:
                try:
                    await self._ws.send(json.dumps({"type": "ping"}))
                except Exception:
                    pass  # Connection lost -- listener will handle reconnection

    async def _schedule_reconnect(self) -> None:
        """Schedule a reconnection attempt with exponential backoff."""
        self._set_state("reconnecting")
        self._reconnect_attempts += 1

        delay = min(
            self._reconnect_delay * (2 ** (self._reconnect_attempts - 1)),
            self._max_reconnect_delay,
        )
        await asyncio.sleep(delay)

        try:
            await self.connect()
        except Exception:
            logger.exception("Reconnection attempt %d failed", self._reconnect_attempts)
