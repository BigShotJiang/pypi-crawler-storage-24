"""
CELLSTATE entity models.

Pydantic models mirroring the Rust structs from cellstate-core.
All field names use snake_case to match the API's JSON wire format.
"""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


# =============================================================================
# Enums as string literals (matching Rust serde output)
# =============================================================================

# TrajectoryStatus: "active" | "completed" | "failed" | "suspended"
# TurnRole: "User" | "Assistant" | "System" | "Tool"
# ArtifactType: "Code" | "Fact" | "Document" | ... (PascalCase from Rust)
# ExtractionMethod: "Explicit" | "Inferred" | "UserProvided" | ...
# NoteType: "Convention" | "Strategy" | "Gotcha" | "Fact" | ...
# TTL: "Persistent" | "Session" | "Scope" | "Ephemeral" | ...
# AgentStatus: "Idle" | "Active" | "Blocked" | "Failed" | "Offline"
# AbstractionLevel: "Raw" | "Summary" | "Principle"
# OutcomeStatus: "Success" | "Partial" | "Failure"


# =============================================================================
# Nested / Shared Models
# =============================================================================


class Provenance(BaseModel):
    """Provenance information for an artifact."""

    source_turn: int
    extraction_method: str
    confidence: float | None = None


class TrajectoryOutcome(BaseModel):
    """Outcome of a completed trajectory."""

    status: str  # OutcomeStatus
    summary: str
    produced_artifacts: list[str] = Field(default_factory=list)
    produced_notes: list[str] = Field(default_factory=list)
    error: str | None = None


class Checkpoint(BaseModel):
    """Checkpoint for scope recovery."""

    context_state: str  # base64-encoded bytes
    recoverable: bool


class EmbeddingVector(BaseModel):
    """Embedding vector with dynamic dimensions.

    Matches Rust ``EmbeddingVector`` from ``crates/core/src/embedding.rs``.
    """

    data: list[float]
    model_id: str
    dimensions: int


class MemoryPermission(BaseModel):
    """A single memory permission entry.

    Matches Rust ``MemoryPermission`` from ``crates/core/src/agent.rs``.
    """

    memory_type: str
    scope: str  # PermissionScope: "Own" | "Team" | "Global"
    filter: str | None = None


class MemoryAccess(BaseModel):
    """Memory access configuration for an agent.

    Matches Rust ``MemoryAccess`` from ``crates/core/src/agent.rs``.
    """

    read: list[MemoryPermission] = Field(default_factory=list)
    write: list[MemoryPermission] = Field(default_factory=list)


# =============================================================================
# Entity Response Models
# =============================================================================


class TrajectoryResponse(BaseModel):
    """Trajectory -- top-level task container."""

    trajectory_id: str
    name: str
    description: str | None = None
    status: str  # TrajectoryStatus
    parent_trajectory_id: str | None = None
    root_trajectory_id: str | None = None
    agent_id: str | None = None
    created_at: str
    updated_at: str
    completed_at: str | None = None
    outcome: TrajectoryOutcome | None = None
    metadata: dict[str, Any] | None = None


class ScopeResponse(BaseModel):
    """Scope -- partitioned context window within a trajectory."""

    scope_id: str
    trajectory_id: str
    parent_scope_id: str | None = None
    name: str
    purpose: str | None = None
    is_active: bool
    created_at: str
    closed_at: str | None = None
    checkpoint: Checkpoint | None = None
    token_budget: int
    tokens_used: int
    metadata: dict[str, Any] | None = None


class ArtifactResponse(BaseModel):
    """Artifact -- typed output preserved across scopes."""

    artifact_id: str
    trajectory_id: str
    scope_id: str
    artifact_type: str  # ArtifactType
    name: str
    content: str
    content_hash: str
    embedding: EmbeddingVector | None = None
    provenance: Provenance
    ttl: Any  # TTL enum -- can be string or object like {"Duration": 3600000}
    created_at: str
    updated_at: str
    superseded_by: str | None = None
    metadata: dict[str, Any] | None = None


class NoteResponse(BaseModel):
    """Note -- long-term cross-trajectory knowledge."""

    note_id: str
    note_type: str  # NoteType
    title: str
    content: str
    content_hash: str
    embedding: EmbeddingVector | None = None
    source_trajectory_ids: list[str] = Field(default_factory=list)
    source_artifact_ids: list[str] = Field(default_factory=list)
    ttl: Any  # TTL enum
    created_at: str
    updated_at: str
    accessed_at: Optional[str] = None
    access_count: int
    superseded_by: str | None = None
    metadata: dict[str, Any] | None = None
    abstraction_level: str = "Raw"  # AbstractionLevel
    source_note_ids: list[str] = Field(default_factory=list)


class TurnResponse(BaseModel):
    """Turn -- ephemeral conversation buffer entry."""

    turn_id: str
    scope_id: str
    sequence: int
    role: str  # TurnRole
    content: str
    token_count: int
    created_at: str
    tool_calls: dict[str, Any] | None = None
    tool_results: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None


class AgentResponse(BaseModel):
    """Agent -- registered agent in the multi-agent system."""

    agent_id: str
    agent_type: str
    capabilities: list[str] = Field(default_factory=list)
    memory_access: MemoryAccess = Field(default_factory=MemoryAccess)
    status: str  # AgentStatus
    current_trajectory_id: str | None = None
    current_scope_id: str | None = None
    can_delegate_to: list[str] = Field(default_factory=list)
    reports_to: str | None = None
    owner_principal_id: str
    created_at: str
    last_heartbeat: str


class HeartbeatResponse(BaseModel):
    """Response from agent heartbeat."""

    agent_id: str
    status: str
    last_heartbeat: str


# =============================================================================
# Request Parameter Models
# =============================================================================


class CreateTrajectoryParams(BaseModel):
    """Parameters for creating a trajectory."""

    name: str
    description: str | None = None
    agent_id: str | None = None
    parent_trajectory_id: str | None = None
    metadata: dict[str, Any] | None = None


class UpdateTrajectoryParams(BaseModel):
    """Parameters for updating a trajectory."""

    name: str | None = None
    description: str | None = None
    status: str | None = None
    outcome: TrajectoryOutcome | None = None
    metadata: dict[str, Any] | None = None


class ListTrajectoriesParams(BaseModel):
    """Parameters for listing trajectories."""

    status: str | None = None
    agent_id: str | None = None
    limit: int | None = None
    offset: int | None = None


class CreateScopeParams(BaseModel):
    """Parameters for creating a scope."""

    trajectory_id: str
    name: str
    purpose: str | None = None
    token_budget: int = 8000
    parent_scope_id: str | None = None
    metadata: dict[str, Any] | None = None


class UpdateScopeParams(BaseModel):
    """Parameters for updating a scope."""

    name: str | None = None
    purpose: str | None = None
    token_budget: int | None = None
    metadata: dict[str, Any] | None = None


class CreateCheckpointParams(BaseModel):
    """Parameters for creating a scope checkpoint."""

    context_state: str  # base64-encoded
    recoverable: bool = True


class CreateArtifactParams(BaseModel):
    """Parameters for creating an artifact."""

    trajectory_id: str
    scope_id: str
    artifact_type: str
    name: str
    content: str
    source_turn: int
    extraction_method: str = "Explicit"
    ttl: str = "Persistent"
    confidence: float | None = None
    metadata: dict[str, Any] | None = None


class UpdateArtifactParams(BaseModel):
    """Parameters for updating an artifact."""

    name: str | None = None
    content: str | None = None
    artifact_type: str | None = None
    ttl: str | None = None
    metadata: dict[str, Any] | None = None


class ListArtifactsParams(BaseModel):
    """Parameters for listing artifacts."""

    trajectory_id: str | None = None
    scope_id: str | None = None
    artifact_type: str | None = None
    limit: int | None = None
    offset: int | None = None


class SearchArtifactsParams(BaseModel):
    """Parameters for searching artifacts."""

    query: str
    trajectory_id: str | None = None
    limit: int | None = None
    min_score: float | None = None


class CreateNoteParams(BaseModel):
    """Parameters for creating a note."""

    note_type: str
    title: str
    content: str
    source_trajectory_ids: list[str] = Field(default_factory=list)
    source_artifact_ids: list[str] = Field(default_factory=list)
    ttl: str = "Persistent"
    abstraction_level: str = "Raw"
    metadata: dict[str, Any] | None = None


class UpdateNoteParams(BaseModel):
    """Parameters for updating a note."""

    title: str | None = None
    content: str | None = None
    note_type: str | None = None
    ttl: str | None = None
    metadata: dict[str, Any] | None = None


class ListNotesParams(BaseModel):
    """Parameters for listing notes."""

    note_type: str | None = None
    limit: int | None = None
    offset: int | None = None


class SearchNotesParams(BaseModel):
    """Parameters for searching notes."""

    query: str
    limit: int | None = None
    min_score: float | None = None


class CreateTurnParams(BaseModel):
    """Parameters for creating a turn."""

    scope_id: str
    role: str
    content: str
    token_count: int | None = None
    tool_calls: dict[str, Any] | None = None
    tool_results: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None


class RegisterAgentParams(BaseModel):
    """Parameters for registering an agent."""

    agent_type: str
    capabilities: list[str] = Field(default_factory=list)
    can_delegate_to: list[str] = Field(default_factory=list)
    reports_to: str | None = None
    metadata: dict[str, Any] | None = None


class UpdateAgentParams(BaseModel):
    """Parameters for updating an agent."""

    capabilities: list[str] | None = None
    status: str | None = None
    can_delegate_to: list[str] | None = None
    metadata: dict[str, Any] | None = None


class ListAgentsParams(BaseModel):
    """Parameters for listing agents."""

    status: str | None = None
    agent_type: str | None = None
    limit: int | None = None
    offset: int | None = None


# =============================================================================
# List Response Models
# =============================================================================


class ListTrajectoriesResponse(BaseModel):
    """Paginated trajectory list response."""

    trajectories: list[TrajectoryResponse] = Field(default_factory=list)
    total: int = 0


class ListArtifactsResponse(BaseModel):
    """Paginated artifact list response."""

    artifacts: list[ArtifactResponse] = Field(default_factory=list)
    total: int = 0


class ListNotesResponse(BaseModel):
    """Paginated note list response."""

    notes: list[NoteResponse] = Field(default_factory=list)
    total: int = 0


class ListAgentsResponse(BaseModel):
    """Paginated agent list response."""

    agents: list[AgentResponse] = Field(default_factory=list)
    total: int = 0


class SearchResult(BaseModel):
    """Single search result with score."""

    score: float
    artifact: ArtifactResponse | None = None
    note: NoteResponse | None = None


class SearchResponse(BaseModel):
    """Search response with scored results."""

    results: list[SearchResult] = Field(default_factory=list)
    total: int = 0


# =============================================================================
# Pack Config Models
# =============================================================================


class ParseError(BaseModel):
    """Pack parse error."""

    message: str
    line: int | None = None
    column: int | None = None


class ValidatePackResponse(BaseModel):
    """Response from pack config validate/parse endpoint."""

    valid: bool
    errors: list[ParseError] = Field(default_factory=list)
    ast: dict[str, Any] | None = None
