"""
CELLSTATE Client.

Main entry point for the CELLSTATE Python SDK.
Provides a unified interface to all CELLSTATE resources.
"""

from __future__ import annotations

from typing import Any

from cellstate.constants import DEFAULT_BASE_URL
from cellstate.context import ContextHelper
from cellstate.http import HttpClient
from cellstate.managers.a2ui import A2UIManager
from cellstate.managers.agent import AgentManager
from cellstate.managers.api_key import ApiKeyManager
from cellstate.managers.artifact import ArtifactManager
from cellstate.managers.bash import BashManager
from cellstate.managers.batch import BatchManager
from cellstate.managers.browser import BrowserManager
from cellstate.managers.config import ConfigManager
from cellstate.managers.context import ContextManager
from cellstate.managers.delegation import DelegationManager
from cellstate.managers.deployment import DeploymentManager
from cellstate.managers.edge import EdgeManager
from cellstate.managers.event_dag import EventDagManager
from cellstate.managers.gate import GateManager
from cellstate.managers.handoff import HandoffManager
from cellstate.managers.ingest import IngestManager
from cellstate.managers.intent import IntentManager
from cellstate.managers.lock import LockManager
from cellstate.managers.message import MessageManager
from cellstate.managers.model import ModelManager
from cellstate.managers.note import NoteManager
from cellstate.managers.oauth import OAuthManager
from cellstate.managers.pack_config import PackConfigManager
from cellstate.managers.scope import ScopeManager
from cellstate.managers.search import SearchManager
from cellstate.managers.summarization import SummarizationManager
from cellstate.managers.trajectory import TrajectoryManager
from cellstate.managers.turn import TurnManager
from cellstate.managers.web_mcp import WebMcpManager
from cellstate.managers.working_set import WorkingSetManager


class CellstateClient:
    """Python client for the CELLSTATE API.

    Provides access to all resource managers through a single unified client.

    Example::

        from cellstate import CellstateClient

        client = CellstateClient(
            api_key="cst_...",
            tenant_id="your-tenant-id",
        )

        # Create a trajectory (task container)
        trajectory = await client.trajectories.create(
            name="Build feature X",
            description="Implement new feature",
        )

        # Create a scope (context window)
        scope = await client.scopes.create(
            trajectory_id=trajectory["trajectory_id"],
            name="Implementation",
            token_budget=8000,
        )
    """

    def __init__(
        self,
        api_key: str,
        tenant_id: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
    ):
        self.http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            tenant_id=tenant_id,
            timeout=timeout,
            headers=headers,
        )

        # Initialize all managers
        self.trajectories = TrajectoryManager(self.http)
        self.scopes = ScopeManager(self.http)
        self.artifacts = ArtifactManager(self.http)
        self.notes = NoteManager(self.http)
        self.turns = TurnManager(self.http)
        self.agents = AgentManager(self.http)
        self.pack_config = PackConfigManager(self.http)
        self.locks = LockManager(self.http)
        self.messages = MessageManager(self.http)
        self.delegations = DelegationManager(self.http)
        self.handoffs = HandoffManager(self.http)
        self.search = SearchManager(self.http)
        self.batch = BatchManager(self.http)
        self.bash = BashManager(self.http)
        self.browser = BrowserManager(self.http)
        self.event_dag = EventDagManager(self.http)
        self.gates = GateManager(self.http)
        self.deployments = DeploymentManager(self.http)
        self.config = ConfigManager(self.http)
        self.context = ContextManager(self.http)
        self.ingest = IngestManager(self.http)
        self.api_keys = ApiKeyManager(self.http)
        self.oauth = OAuthManager(self.http)
        self.edges = EdgeManager(self.http)
        self.summarization = SummarizationManager(self.http)
        self.working_set = WorkingSetManager(self.http)
        self.web_mcp = WebMcpManager(self.http)
        self.intents = IntentManager(self.http)
        self.models = ModelManager(self.http)
        self.a2ui = A2UIManager(self.http)

        # Context assembly helper
        self._context_helper = ContextHelper(self.http)

    @property
    def tenant_id(self) -> str:
        """Get the tenant ID for this client."""
        return self.http.tenant_id

    async def assemble_context(
        self,
        trajectory_id: str,
        include_notes: bool = True,
        max_artifacts: int = 10,
        max_notes: int = 5,
        max_turns: int = 20,
        relevance_query: str | None = None,
        min_relevance: float = 0.5,
        include_hierarchy: bool = False,
        scope_id: str | None = None,
    ) -> dict[str, Any]:
        """Assemble context from a trajectory for use in LLM prompts.

        Collects hierarchical memory including trajectory metadata,
        artifacts, notes, and recent turns.

        Args:
            trajectory_id: The trajectory to gather context from.
            include_notes: Whether to include cross-trajectory notes.
            max_artifacts: Maximum number of artifacts to include.
            max_notes: Maximum number of notes to include.
            max_turns: Maximum number of turns to include.
            relevance_query: Optional query for semantic search filtering.
            min_relevance: Minimum relevance score (0-1).
            include_hierarchy: Whether to include parent trajectories.
            scope_id: Specific scope ID (defaults to most recent active).

        Returns:
            Assembled context dictionary.
        """
        return await self._context_helper.assemble_context(
            trajectory_id=trajectory_id,
            include_notes=include_notes,
            max_artifacts=max_artifacts,
            max_notes=max_notes,
            max_turns=max_turns,
            relevance_query=relevance_query,
            min_relevance=min_relevance,
            include_hierarchy=include_hierarchy,
            scope_id=scope_id,
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self.http.close()

    async def __aenter__(self) -> CellstateClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
