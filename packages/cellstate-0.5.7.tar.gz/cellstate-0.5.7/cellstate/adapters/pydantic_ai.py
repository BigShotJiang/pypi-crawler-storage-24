"""
PydanticAI-compatible state backed by CELLSTATE.

Provides a state container that automatically persists to CELLSTATE's
hierarchical memory, giving PydanticAI agents long-term memory
and cross-session context.

Concept mapping:

- ``CellstateState`` -> PydanticAI agent state (deps/context)
- ``get()`` / ``set()`` -> CELLSTATE artifact CRUD within a scope
- ``snapshot()`` -> creates a CELLSTATE scope checkpoint (frozen state)
- ``restore()`` -> recovers state from a named snapshot
- ``keys()`` -> lists all artifact names in the active scope
- ``watch()`` -> subscribes to state changes via WebSocket

Usage::

    from cellstate.adapters.pydantic_ai import CellstateState

    state = CellstateState(
        api_key="cst_...",
        tenant_id="...",
        trajectory_id="...",
    )

    # State automatically syncs with CELLSTATE
    await state.set("user_preference", "dark mode")
    value = await state.get("user_preference")

    # Create a snapshot (scope checkpoint)
    snapshot_id = await state.snapshot("before-migration")

    # Restore from snapshot
    await state.restore(snapshot_id)

    # Watch for changes (WebSocket)
    async for change in state.watch():
        print(f"{change['key']} = {change['value']}")

Requires: ``pip install cellstate[pydantic-ai]``
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
from typing import Any, AsyncIterator, Callable

from cellstate.client import CellstateClient
from cellstate.http import CellstateError, NotFoundError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Conditional imports: PydanticAI types
# ---------------------------------------------------------------------------

try:
    import pydantic_ai  # noqa: F401

    _HAS_PYDANTIC_AI = True
except ImportError:
    _HAS_PYDANTIC_AI = False


# ---------------------------------------------------------------------------
# State change event
# ---------------------------------------------------------------------------


class StateChange:
    """Represents a state change event from the watch stream.

    Attributes:
        key: The state key that changed.
        value: The new value (None for deletions).
        operation: One of 'set', 'delete', 'snapshot', 'restore'.
        timestamp: ISO timestamp of the change.
    """

    __slots__ = ("key", "value", "operation", "timestamp")

    def __init__(
        self,
        key: str,
        value: Any = None,
        operation: str = "set",
        timestamp: str = "",
    ) -> None:
        self.key = key
        self.value = value
        self.operation = operation
        self.timestamp = timestamp

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "key": self.key,
            "value": self.value,
            "operation": self.operation,
            "timestamp": self.timestamp,
        }


# ---------------------------------------------------------------------------
# CellstateState
# ---------------------------------------------------------------------------


class CellstateState:
    """PydanticAI-compatible state backed by CELLSTATE.

    Provides a key-value state interface that persists to CELLSTATE's
    hierarchical memory. State is stored as artifacts within a
    trajectory/scope, giving you:

    - **Persistent state** across agent sessions.
    - **Full audit trail** of state changes via event DAG.
    - **Hierarchical scoping**: trajectory -> scope -> artifacts.
    - **Snapshots and restore**: freeze state at any point and roll back.
    - **Cross-agent state sharing** via memory access controls.
    - **Type-safe serialization**: all values are JSON-serialized with
      round-trip fidelity.
    """

    def __init__(
        self,
        api_key: str,
        tenant_id: str,
        trajectory_id: str,
        scope_id: str | None = None,
        base_url: str = "https://cst.batterypack.dev",
    ) -> None:
        self.client = CellstateClient(
            api_key=api_key,
            tenant_id=tenant_id,
            base_url=base_url,
        )
        self._trajectory_id = trajectory_id
        self._scope_id = scope_id
        self._cache: dict[str, Any] = {}
        self._watchers: list[Callable[[StateChange], Any]] = []

    # ------------------------------------------------------------------
    # Scope management
    # ------------------------------------------------------------------

    async def _ensure_scope(self) -> str:
        """Ensure a scope exists for state storage, creating one if needed.

        Returns:
            The scope_id of the active scope.
        """
        if self._scope_id is not None:
            return self._scope_id

        scope = await self.client.scopes.create(
            trajectory_id=self._trajectory_id,
            name="pydantic-ai-state",
            purpose="PydanticAI state storage",
            metadata={"adapter": "pydantic_ai", "state_scope": True},
        )
        self._scope_id = scope["scope_id"]
        return self._scope_id

    async def _find_artifact(self, key: str) -> dict[str, Any] | None:
        """Find the active (non-superseded) artifact for a given key.

        Args:
            key: The state key (artifact name).

        Returns:
            Artifact dict, or None if not found.
        """
        scope_id = await self._ensure_scope()
        response = await self.client.artifacts.list(
            trajectory_id=self._trajectory_id,
            scope_id=scope_id,
        )
        for artifact in response.get("artifacts", []):
            if artifact.get("name") == key and artifact.get("superseded_by") is None:
                return artifact
        return None

    def _notify_watchers(self, change: StateChange) -> None:
        """Notify all registered watchers of a state change."""
        for watcher in self._watchers:
            try:
                result = watcher(change)
                # Support async watchers
                if asyncio.iscoroutine(result):
                    asyncio.ensure_future(result)
            except Exception as exc:
                logger.warning("State watcher error: %s", exc)

    # ------------------------------------------------------------------
    # CRUD operations
    # ------------------------------------------------------------------

    async def get(self, key: str, default: Any = None) -> Any:
        """Get a state value by key.

        Returns the cached value if available, otherwise fetches from
        CELLSTATE. Values are JSON-deserialized automatically.

        Args:
            key: The state key to retrieve.
            default: Default value if key not found.

        Returns:
            The stored value, or default if not found.
        """
        if key in self._cache:
            return self._cache[key]

        artifact = await self._find_artifact(key)
        if artifact is None:
            return default

        value = json.loads(artifact["content"])
        self._cache[key] = value
        return value

    async def set(self, key: str, value: Any) -> None:
        """Set a state value.

        Stores the value as a CELLSTATE artifact with the key as the artifact
        name. If an artifact with this key already exists, it is updated
        in-place. All values must be JSON-serializable.

        Args:
            key: The state key.
            value: The value to store (must be JSON-serializable).

        Raises:
            TypeError: If value is not JSON-serializable.
            CellstateError: If the API call fails.
        """
        scope_id = await self._ensure_scope()
        content = json.dumps(value)

        existing = await self._find_artifact(key)
        if existing is not None:
            await self.client.artifacts.update(
                artifact_id=existing["artifact_id"],
                content=content,
            )
        else:
            await self.client.artifacts.create(
                trajectory_id=self._trajectory_id,
                scope_id=scope_id,
                artifact_type="Fact",
                name=key,
                content=content,
                source_turn=0,
                extraction_method="Explicit",
                ttl="Persistent",
                metadata={"state_key": True, "adapter": "pydantic_ai"},
            )

        old_value = self._cache.get(key)
        self._cache[key] = value

        # Notify watchers
        from datetime import datetime, timezone

        change = StateChange(
            key=key,
            value=value,
            operation="set",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        self._notify_watchers(change)

    async def delete(self, key: str) -> bool:
        """Delete a state value.

        Removes the artifact from CELLSTATE and clears the cache entry.

        Args:
            key: The state key to delete.

        Returns:
            True if the key existed and was deleted, False if not found.
        """
        artifact = await self._find_artifact(key)
        if artifact is None:
            self._cache.pop(key, None)
            return False

        await self.client.artifacts.delete(artifact["artifact_id"])
        self._cache.pop(key, None)

        from datetime import datetime, timezone

        change = StateChange(
            key=key,
            value=None,
            operation="delete",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        self._notify_watchers(change)
        return True

    # ------------------------------------------------------------------
    # Enumeration
    # ------------------------------------------------------------------

    async def keys(self) -> list[str]:
        """List all active state keys.

        Returns:
            List of state key names (artifact names that are not superseded).
        """
        scope_id = await self._ensure_scope()
        response = await self.client.artifacts.list(
            trajectory_id=self._trajectory_id,
            scope_id=scope_id,
        )
        return [
            a["name"]
            for a in response.get("artifacts", [])
            if a.get("superseded_by") is None
        ]

    async def items(self) -> dict[str, Any]:
        """Get all state key-value pairs.

        Returns:
            Dictionary of all active state entries.
        """
        scope_id = await self._ensure_scope()
        response = await self.client.artifacts.list(
            trajectory_id=self._trajectory_id,
            scope_id=scope_id,
        )
        state: dict[str, Any] = {}
        for artifact in response.get("artifacts", []):
            if artifact.get("superseded_by") is not None:
                continue
            key = artifact["name"]
            state[key] = json.loads(artifact["content"])

        self._cache = dict(state)
        return state

    def __contains__(self, key: str) -> bool:
        """Check if a key exists in state.

        Python's ``in`` operator calls ``__contains__`` synchronously, so this
        method must be sync.  The in-process cache is checked first (O(1), no
        I/O).  If the cache is cold the call falls back to a blocking lookup via
        ``asyncio.get_event_loop().run_until_complete()``.  Prefer calling
        ``await state.get(key)`` or pre-warming the cache with
        ``await state.items()`` from async code to avoid the blocking path.
        """
        if key in self._cache:
            return True
        loop = asyncio.get_event_loop()
        artifact = loop.run_until_complete(self._find_artifact(key))
        return artifact is not None

    # ------------------------------------------------------------------
    # Snapshots
    # ------------------------------------------------------------------

    async def snapshot(self, name: str | None = None) -> str:
        """Create a scope checkpoint (frozen state snapshot).

        Captures the current state of all artifacts and stores it as a
        CELLSTATE scope checkpoint. This can be restored later using
        ``restore()``.

        Args:
            name: Optional human-readable name for the snapshot.
                Defaults to ``snapshot-<timestamp>``.

        Returns:
            The snapshot identifier (scope_id of the checkpoint scope).
        """
        scope_id = await self._ensure_scope()

        # Gather all current state
        current_state = await self.items()

        # Serialize the entire state to base64 for the checkpoint
        state_json = json.dumps(current_state)
        context_state = base64.b64encode(state_json.encode("utf-8")).decode("ascii")

        # Create a checkpoint on the current scope
        await self.client.scopes.checkpoint(
            scope_id=scope_id,
            context_state=context_state,
            recoverable=True,
        )

        # Also create a child scope to hold the snapshot metadata
        from datetime import datetime, timezone

        snapshot_name = name or f"snapshot-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}"

        snapshot_scope = await self.client.scopes.create(
            trajectory_id=self._trajectory_id,
            name=snapshot_name,
            purpose="PydanticAI state snapshot",
            parent_scope_id=scope_id,
            metadata={
                "adapter": "pydantic_ai",
                "snapshot": True,
                "snapshot_name": snapshot_name,
                "source_scope_id": scope_id,
                "key_count": len(current_state),
            },
        )
        snapshot_scope_id: str = snapshot_scope["scope_id"]

        # Copy all current artifacts into the snapshot scope
        for key, value in current_state.items():
            await self.client.artifacts.create(
                trajectory_id=self._trajectory_id,
                scope_id=snapshot_scope_id,
                artifact_type="Fact",
                name=key,
                content=json.dumps(value),
                source_turn=0,
                extraction_method="Explicit",
                ttl="Persistent",
                metadata={"state_key": True, "snapshot": snapshot_name},
            )

        change = StateChange(
            key="__snapshot__",
            value=snapshot_name,
            operation="snapshot",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        self._notify_watchers(change)

        logger.debug("snapshot: created %s (%s)", snapshot_scope_id, snapshot_name)
        return snapshot_scope_id

    async def restore(self, snapshot_id: str) -> dict[str, Any]:
        """Restore state from a previously created snapshot.

        Reads all artifacts from the snapshot scope and replays them
        into the current active scope, replacing existing values.

        Args:
            snapshot_id: The scope_id of the snapshot to restore from.

        Returns:
            The restored state dictionary.

        Raises:
            NotFoundError: If the snapshot scope does not exist.
            CellstateError: If the snapshot scope has no artifacts.
        """
        scope_id = await self._ensure_scope()

        # Fetch artifacts from the snapshot scope
        snapshot_response = await self.client.artifacts.list(
            trajectory_id=self._trajectory_id,
            scope_id=snapshot_id,
        )
        snapshot_artifacts = snapshot_response.get("artifacts", [])

        if not snapshot_artifacts:
            raise CellstateError(
                f"Snapshot {snapshot_id} contains no artifacts",
                code="EMPTY_SNAPSHOT",
            )

        # Build the restored state
        restored_state: dict[str, Any] = {}
        for artifact in snapshot_artifacts:
            if artifact.get("superseded_by") is not None:
                continue
            key = artifact["name"]
            restored_state[key] = json.loads(artifact["content"])

        # Apply to current scope: update existing, create new, delete removed
        current_keys = set(await self.keys())
        restored_keys = set(restored_state.keys())

        # Delete keys that are not in the snapshot
        for key in current_keys - restored_keys:
            await self.delete(key)

        # Set/update all keys from the snapshot
        for key, value in restored_state.items():
            await self.set(key, value)

        self._cache = dict(restored_state)

        from datetime import datetime, timezone

        change = StateChange(
            key="__restore__",
            value=snapshot_id,
            operation="restore",
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        self._notify_watchers(change)

        logger.debug("restore: applied snapshot %s (%d keys)", snapshot_id, len(restored_state))
        return restored_state

    # ------------------------------------------------------------------
    # Watch (state change subscription)
    # ------------------------------------------------------------------

    async def watch(
        self,
        *,
        poll_interval: float = 2.0,
    ) -> AsyncIterator[StateChange]:
        """Subscribe to state changes by polling.

        Yields StateChange events whenever state is modified. Uses periodic
        polling against the CELLSTATE REST API to detect changes.

        Args:
            poll_interval: Seconds between poll cycles (default 2.0).

        Yields:
            StateChange events for each detected change.
        """
        known_state: dict[str, Any] = dict(self._cache)

        while True:
            await asyncio.sleep(poll_interval)

            try:
                current_state = await self.items()
            except CellstateError as exc:
                logger.debug("watch poll error: %s", exc)
                continue

            # Detect new/updated keys
            for key, value in current_state.items():
                old_value = known_state.get(key)
                if key not in known_state or old_value != value:
                    from datetime import datetime, timezone

                    yield StateChange(
                        key=key,
                        value=value,
                        operation="set",
                        timestamp=datetime.now(timezone.utc).isoformat(),
                    )

            # Detect deleted keys
            for key in set(known_state) - set(current_state):
                from datetime import datetime, timezone

                yield StateChange(
                    key=key,
                    value=None,
                    operation="delete",
                    timestamp=datetime.now(timezone.utc).isoformat(),
                )

            known_state = dict(current_state)

    def on_change(self, callback: Callable[[StateChange], Any]) -> Callable[[], None]:
        """Register a synchronous or async callback for state changes.

        The callback will be invoked whenever ``set()``, ``delete()``,
        ``snapshot()``, or ``restore()`` is called on this state object.

        Args:
            callback: Function that receives a StateChange. Can be sync or async.

        Returns:
            An unsubscribe function. Call it to remove the callback.
        """
        self._watchers.append(callback)

        def unsubscribe() -> None:
            try:
                self._watchers.remove(callback)
            except ValueError:
                pass  # Already removed

        return unsubscribe

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @property
    def trajectory_id(self) -> str:
        """The trajectory ID this state is scoped to."""
        return self._trajectory_id

    @property
    def scope_id(self) -> str | None:
        """The current scope ID, or None if not yet initialized."""
        return self._scope_id

    async def close(self) -> None:
        """Close the underlying CELLSTATE client and stop watchers."""
        self._watchers.clear()
        await self.client.close()

    async def __aenter__(self) -> CellstateState:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
