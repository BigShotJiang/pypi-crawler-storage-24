"""
CELLSTATE framework adapters.

Drop-in integrations for LangGraph, LangMem, PydanticAI, Mastra, and CrewAI.

All adapters use lazy imports so they don't fail if the target framework
is not installed. Import the specific adapter you need::

    from cellstate.adapters.langgraph import CellstateCheckpointer
    from cellstate.adapters.langmem import CellstateMemoryStore
    from cellstate.adapters.pydantic_ai import CellstateState
    from cellstate.adapters.mastra import CellstateMastraWorkflow
    from cellstate.adapters.crewai import CellstateCrewMemory
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from cellstate.adapters.crewai import CellstateCrewMemory as CellstateCrewMemory
    from cellstate.adapters.langgraph import CellstateCheckpointer as CellstateCheckpointer
    from cellstate.adapters.langmem import CellstateMemoryStore as CellstateMemoryStore
    from cellstate.adapters.mastra import CellstateMastraWorkflow as CellstateMastraWorkflow
    from cellstate.adapters.pydantic_ai import CellstateState as CellstateState

__all__ = [
    "CellstateCheckpointer",
    "CellstateMemoryStore",
    "CellstateState",
    "CellstateMastraWorkflow",
    "CellstateCrewMemory",
]


def __getattr__(name: str) -> Any:
    """Lazy import adapters to avoid failing when frameworks are not installed."""
    if name == "CellstateCheckpointer":
        from cellstate.adapters.langgraph import CellstateCheckpointer

        return CellstateCheckpointer
    if name == "CellstateMemoryStore":
        from cellstate.adapters.langmem import CellstateMemoryStore

        return CellstateMemoryStore
    if name == "CellstateState":
        from cellstate.adapters.pydantic_ai import CellstateState

        return CellstateState
    if name == "CellstateMastraWorkflow":
        from cellstate.adapters.mastra import CellstateMastraWorkflow

        return CellstateMastraWorkflow
    if name == "CellstateCrewMemory":
        from cellstate.adapters.crewai import CellstateCrewMemory

        return CellstateCrewMemory
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
