"""
LangGraph-compatible checkpointer backed by CELLSTATE event-sourced DAGs.

Instead of opaque state snapshots, checkpoints are event-sourced DAG nodes
with full audit trail, gate results, and scoring metadata.

Concept mapping:

- ``thread_id`` -> CELLSTATE trajectory (task container)
- ``checkpoint_ns`` -> CELLSTATE scope hierarchy (nested context windows)
- ``checkpoint_id`` -> CELLSTATE scope_id (unique scope within trajectory)
- ``channel_values`` -> CELLSTATE artifacts within the scope
- ``channel_versions`` -> stored as metadata on the scope
- ``pending_writes`` -> CELLSTATE artifacts with ``__pending_write__`` prefix

Usage::

    from cellstate.adapters.langgraph import CellstateCheckpointer

    checkpointer = CellstateCheckpointer(
        api_key="cst_...",
        tenant_id="...",
    )
    graph = StateGraph(State)
    graph.compile(checkpointer=checkpointer)

Requires: ``pip install cellstate[langgraph]``
"""

from __future__ import annotations

import base64
import json
import logging
from typing import Any, AsyncIterator, Sequence

from cellstate.client import CellstateClient
from cellstate.http import CellstateError, NotFoundError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Conditional imports: LangGraph types are only needed when actually used.
# We define lightweight stand-ins so the module loads without langgraph.
# ---------------------------------------------------------------------------

try:
    from langgraph.checkpoint.base import (
        BaseCheckpointSaver,
        Checkpoint,
        CheckpointMetadata,
        CheckpointTuple,
    )

    _HAS_LANGGRAPH = True
except ImportError:
    _HAS_LANGGRAPH = False

    # Minimal protocol stand-ins so CellstateCheckpointer can be defined
    # even when langgraph is not installed.
    class BaseCheckpointSaver:  # type: ignore[no-redef]
        """Stand-in base class when langgraph is not installed."""

        class Config:
            arbitrary_types_allowed = True

    Checkpoint = dict  # type: ignore[misc,assignment]
    CheckpointMetadata = dict  # type: ignore[misc,assignment]

    class CheckpointTuple:  # type: ignore[no-redef]
        """Stand-in when langgraph is not installed."""

        def __init__(self, **kwargs: Any) -> None:
            for k, v in kwargs.items():
                setattr(self, k, v)


# ---------------------------------------------------------------------------
# Helper: serialisation round-trip for arbitrary checkpoint payloads
# ---------------------------------------------------------------------------

def _serialize_value(value: Any) -> str:
    """Serialize an arbitrary Python value to a JSON-safe string.

    For values that are not directly JSON-serializable (bytes, sets, etc.),
    we fall back to base64-encoding a repr.
    """
    try:
        return json.dumps(value)
    except (TypeError, ValueError):
        # Fall back to base64 encoding of repr for non-serializable types
        raw = repr(value).encode("utf-8")
        return json.dumps({"__b64__": base64.b64encode(raw).decode("ascii")})


def _deserialize_value(raw: str) -> Any:
    """Inverse of ``_serialize_value``."""
    parsed = json.loads(raw)
    if isinstance(parsed, dict) and "__b64__" in parsed:
        return base64.b64decode(parsed["__b64__"]).decode("utf-8")
    return parsed


# ---------------------------------------------------------------------------
# CellstateCheckpointer
# ---------------------------------------------------------------------------


class CellstateCheckpointer(BaseCheckpointSaver):
    """Drop-in replacement for LangGraph's PostgresSaver / MemorySaver.

    Maps LangGraph's checkpoint model to CELLSTATE's hierarchical memory:

    - ``thread_id`` maps to a CELLSTATE trajectory.
    - Each checkpoint becomes a scope with artifacts holding channel values.
    - ``checkpoint_ns`` maps to nested CELLSTATE scopes (parent_scope_id chain).
    - Checkpoint history is the ordered list of scopes on the trajectory.
    - ``pending_writes`` are stored as separate artifacts with a reserved prefix.

    This gives you event-sourced state with full audit trail instead of
    opaque state blobs.
    """

    def __init__(
        self,
        api_key: str,
        tenant_id: str,
        base_url: str = "https://cst.batterypack.dev",
    ) -> None:
        if _HAS_LANGGRAPH:
            super().__init__()
        self.client = CellstateClient(
            api_key=api_key,
            tenant_id=tenant_id,
            base_url=base_url,
        )
        # In-memory index: thread_id -> trajectory was already ensured
        self._trajectory_cache: dict[str, bool] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _thread_id(config: dict[str, Any]) -> str:
        """Extract thread_id from LangGraph config."""
        configurable = config.get("configurable", {})
        tid = configurable.get("thread_id")
        if tid is None:
            raise ValueError(
                "LangGraph config must contain configurable.thread_id"
            )
        return str(tid)

    @staticmethod
    def _checkpoint_ns(config: dict[str, Any]) -> str:
        """Extract checkpoint_ns (namespace) from LangGraph config, default ''."""
        return config.get("configurable", {}).get("checkpoint_ns", "")

    @staticmethod
    def _checkpoint_id(config: dict[str, Any]) -> str | None:
        """Extract checkpoint_id from LangGraph config, if present."""
        return config.get("configurable", {}).get("checkpoint_id")

    async def _ensure_trajectory(self, thread_id: str) -> str:
        """Ensure a trajectory exists for this thread_id, creating if needed.

        Returns the trajectory_id (which is the same as thread_id -- we use
        thread_id as the CELLSTATE trajectory name and store the mapping).
        """
        if thread_id in self._trajectory_cache:
            return thread_id

        try:
            await self.client.trajectories.get(thread_id)
            self._trajectory_cache[thread_id] = True
            return thread_id
        except NotFoundError:
            pass

        # Create a new trajectory for this LangGraph thread
        result = await self.client.trajectories.create(
            name=f"langgraph-thread-{thread_id}",
            description="Auto-created by CellstateCheckpointer for LangGraph",
            metadata={"langgraph_thread_id": thread_id},
        )
        actual_id = result.get("trajectory_id", thread_id)
        self._trajectory_cache[thread_id] = True
        return actual_id

    async def _resolve_scope(
        self,
        thread_id: str,
        checkpoint_id: str | None,
        checkpoint_ns: str,
    ) -> dict[str, Any] | None:
        """Find the scope matching the given checkpoint_id or latest for ns."""
        scopes = await self.client.trajectories.list_scopes(thread_id)
        scope_list: list[dict[str, Any]] = scopes if isinstance(scopes, list) else []

        if checkpoint_id:
            # Exact match by scope_id
            for s in scope_list:
                if s.get("scope_id") == checkpoint_id:
                    return s
            return None

        # Filter by namespace and find the most recent active
        ns_scopes = [
            s for s in scope_list
            if s.get("metadata", {}).get("checkpoint_ns", "") == checkpoint_ns
        ]
        if not ns_scopes:
            return None

        # Prefer active scopes, then most recently created
        active = [s for s in ns_scopes if s.get("is_active")]
        if active:
            return active[-1]
        return ns_scopes[-1]

    async def _scope_to_tuple(
        self,
        thread_id: str,
        scope: dict[str, Any],
    ) -> CheckpointTuple:
        """Build a CheckpointTuple from a CELLSTATE scope + its artifacts."""
        scope_id = scope["scope_id"]
        scope_metadata = scope.get("metadata") or {}

        # Fetch artifacts in this scope
        artifacts_response = await self.client.artifacts.list(
            trajectory_id=thread_id,
            scope_id=scope_id,
        )
        artifacts: list[dict[str, Any]] = artifacts_response.get("artifacts", [])

        # Reconstruct channel_values from artifacts
        channel_values: dict[str, Any] = {}
        channel_versions: dict[str, Any] = {}
        pending_sends: list[Any] = []

        for artifact in artifacts:
            if artifact.get("superseded_by") is not None:
                continue
            name = artifact.get("name", "")
            if name == "__checkpoint_state__":
                # Legacy format: entire checkpoint stored as one blob
                state = json.loads(artifact["content"])
                channel_values = state.get("channel_values", state)
                channel_versions = state.get("channel_versions", {})
                pending_sends = state.get("pending_sends", [])
                break
            if name == "__channel_versions__":
                channel_versions = json.loads(artifact["content"])
            elif name == "__pending_sends__":
                pending_sends = json.loads(artifact["content"])
            elif name.startswith("__pending_write__"):
                # Collected separately in pending_writes below
                continue
            else:
                # Channel value artifact
                channel_values[name] = _deserialize_value(artifact["content"])

        checkpoint_id = scope_id
        checkpoint_ns = scope_metadata.get("checkpoint_ns", "")

        checkpoint: dict[str, Any] = {
            "v": 1,
            "id": checkpoint_id,
            "ts": scope.get("created_at", ""),
            "channel_values": channel_values,
            "channel_versions": channel_versions,
            "versions_seen": scope_metadata.get("versions_seen", {}),
            "pending_sends": pending_sends,
        }

        metadata: dict[str, Any] = {
            "source": scope_metadata.get("source", "update"),
            "step": scope_metadata.get("step", -1),
            "writes": scope_metadata.get("writes"),
            "parents": scope_metadata.get("parents", {}),
        }

        config = {
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint_id,
            }
        }

        # Parent config from parent_scope_id
        parent_config = None
        parent_scope_id = scope.get("parent_scope_id")
        if parent_scope_id:
            parent_config = {
                "configurable": {
                    "thread_id": thread_id,
                    "checkpoint_ns": checkpoint_ns,
                    "checkpoint_id": parent_scope_id,
                }
            }

        # Collect pending writes
        pending_writes: list[tuple[str, str, Any]] = []
        for artifact in artifacts:
            if artifact.get("superseded_by") is not None:
                continue
            name = artifact.get("name", "")
            if name.startswith("__pending_write__"):
                write_data = json.loads(artifact["content"])
                pending_writes.append((
                    write_data.get("task_id", ""),
                    write_data.get("channel", ""),
                    _deserialize_value(json.dumps(write_data.get("value"))),
                ))

        if _HAS_LANGGRAPH:
            return CheckpointTuple(
                config=config,
                checkpoint=checkpoint,
                metadata=metadata,
                parent_config=parent_config,
                pending_writes=pending_writes,
            )
        # Fallback for non-langgraph environments
        return CheckpointTuple(
            config=config,
            checkpoint=checkpoint,
            metadata=metadata,
            parent_config=parent_config,
            pending_writes=pending_writes,
        )

    # ------------------------------------------------------------------
    # LangGraph BaseCheckpointSaver interface
    # ------------------------------------------------------------------

    async def aget_tuple(self, config: dict[str, Any]) -> CheckpointTuple | None:
        """Get a CheckpointTuple for the given config.

        Maps the LangGraph ``thread_id`` to a CELLSTATE trajectory and finds
        the matching scope by ``checkpoint_id`` (exact) or ``checkpoint_ns``
        (latest active).

        Args:
            config: LangGraph config with ``configurable.thread_id``.
                May also contain ``checkpoint_id`` and ``checkpoint_ns``.

        Returns:
            A CheckpointTuple with config, checkpoint, metadata, parent_config,
            and pending_writes, or None if no checkpoint exists.
        """
        thread_id = self._thread_id(config)
        checkpoint_id = self._checkpoint_id(config)
        checkpoint_ns = self._checkpoint_ns(config)

        try:
            scope = await self._resolve_scope(
                thread_id, checkpoint_id, checkpoint_ns
            )
        except (NotFoundError, CellstateError) as exc:
            logger.debug("aget_tuple: trajectory %s not found: %s", thread_id, exc)
            return None

        if scope is None:
            return None

        return await self._scope_to_tuple(thread_id, scope)

    async def aget(self, config: dict[str, Any]) -> dict[str, Any] | None:
        """Get checkpoint state from CELLSTATE trajectory.

        Convenience wrapper that returns just the checkpoint dict.

        Args:
            config: LangGraph config with ``configurable.thread_id``.

        Returns:
            Checkpoint state dict, or None if not found.
        """
        result = await self.aget_tuple(config)
        if result is None:
            return None
        return result.checkpoint  # type: ignore[union-attr]

    async def aput(
        self,
        config: dict[str, Any],
        checkpoint: dict[str, Any],
        metadata: dict[str, Any],
        new_versions: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Store a checkpoint as a CELLSTATE scope with artifacts.

        Creates a new scope for the checkpoint and stores each channel value
        as a separate CELLSTATE artifact. This means every state key has its own
        provenance, TTL, and audit trail.

        Args:
            config: LangGraph config with ``configurable.thread_id``.
            checkpoint: The checkpoint state to store. Expected to contain
                ``id``, ``channel_values``, ``channel_versions``, and
                optionally ``versions_seen`` and ``pending_sends``.
            metadata: Checkpoint metadata (source, step, writes, parents).
            new_versions: Optional new channel versions for this checkpoint.

        Returns:
            Updated config with the new ``checkpoint_id`` set to the
            CELLSTATE scope_id.
        """
        thread_id = self._thread_id(config)
        checkpoint_ns = self._checkpoint_ns(config)
        checkpoint_id = checkpoint.get("id", "")
        parent_checkpoint_id = self._checkpoint_id(config)

        await self._ensure_trajectory(thread_id)

        # Build scope metadata that preserves LangGraph semantics
        scope_metadata: dict[str, Any] = {
            "checkpoint_ns": checkpoint_ns,
            "langgraph_checkpoint_id": checkpoint_id,
            "source": metadata.get("source", "update"),
            "step": metadata.get("step", -1),
            "writes": metadata.get("writes"),
            "parents": metadata.get("parents", {}),
            "versions_seen": checkpoint.get("versions_seen", {}),
        }

        # Determine parent scope
        parent_scope_id = parent_checkpoint_id

        # Create the scope
        scope = await self.client.scopes.create(
            trajectory_id=thread_id,
            name=f"checkpoint-{checkpoint_id}",
            purpose=f"LangGraph checkpoint (step {metadata.get('step', '?')})",
            parent_scope_id=parent_scope_id,
            metadata=scope_metadata,
        )
        scope_id: str = scope["scope_id"]

        # Store each channel value as a separate artifact
        channel_values = checkpoint.get("channel_values", {})
        for channel_name, value in channel_values.items():
            content = _serialize_value(value)
            try:
                await self.client.artifacts.create(
                    trajectory_id=thread_id,
                    scope_id=scope_id,
                    artifact_type="Document",
                    name=channel_name,
                    content=content,
                    source_turn=metadata.get("step", 0),
                    extraction_method="Explicit",
                    ttl="Persistent",
                    metadata={"channel": channel_name, "checkpoint_id": checkpoint_id},
                )
            except CellstateError as exc:
                logger.warning(
                    "Failed to store channel %s: %s", channel_name, exc
                )

        # Store channel_versions as a separate artifact
        channel_versions = checkpoint.get("channel_versions", {})
        if channel_versions:
            try:
                await self.client.artifacts.create(
                    trajectory_id=thread_id,
                    scope_id=scope_id,
                    artifact_type="Document",
                    name="__channel_versions__",
                    content=json.dumps(channel_versions),
                    source_turn=metadata.get("step", 0),
                    extraction_method="Explicit",
                    ttl="Persistent",
                    metadata={"system": True},
                )
            except CellstateError as exc:
                logger.warning("Failed to store channel_versions: %s", exc)

        # Store pending_sends if any
        pending_sends = checkpoint.get("pending_sends", [])
        if pending_sends:
            try:
                await self.client.artifacts.create(
                    trajectory_id=thread_id,
                    scope_id=scope_id,
                    artifact_type="Document",
                    name="__pending_sends__",
                    content=json.dumps(pending_sends),
                    source_turn=metadata.get("step", 0),
                    extraction_method="Explicit",
                    ttl="Persistent",
                    metadata={"system": True},
                )
            except CellstateError as exc:
                logger.warning("Failed to store pending_sends: %s", exc)

        return {
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": scope_id,
            }
        }

    async def aput_writes(
        self,
        config: dict[str, Any],
        writes: Sequence[tuple[str, Any]],
        task_id: str,
    ) -> None:
        """Store pending writes as CELLSTATE artifacts.

        Each pending write is stored as an artifact with a reserved name
        prefix so it can be distinguished from channel value artifacts.

        Args:
            config: LangGraph config with ``configurable.thread_id``
                and ``checkpoint_id``.
            writes: Sequence of ``(channel, value)`` tuples to persist.
            task_id: The task identifier for these writes.
        """
        thread_id = self._thread_id(config)
        checkpoint_id = self._checkpoint_id(config)

        if not checkpoint_id:
            logger.warning("aput_writes called without checkpoint_id, skipping")
            return

        for idx, (channel, value) in enumerate(writes):
            write_data = {
                "task_id": task_id,
                "channel": channel,
                "value": value,
                "index": idx,
            }
            try:
                await self.client.artifacts.create(
                    trajectory_id=thread_id,
                    scope_id=checkpoint_id,
                    artifact_type="Document",
                    name=f"__pending_write__{task_id}_{idx}",
                    content=json.dumps(write_data, default=str),
                    source_turn=0,
                    extraction_method="Explicit",
                    ttl="Scope",
                    metadata={
                        "pending_write": True,
                        "task_id": task_id,
                        "channel": channel,
                    },
                )
            except CellstateError as exc:
                logger.warning(
                    "Failed to store pending write %s/%d: %s",
                    task_id, idx, exc,
                )

    async def alist(
        self,
        config: dict[str, Any],
        *,
        filter: dict[str, Any] | None = None,
        before: dict[str, Any] | None = None,
        limit: int | None = None,
    ) -> AsyncIterator[CheckpointTuple]:
        """List checkpoint history from CELLSTATE event DAG.

        Returns an async iterator of CheckpointTuples for the trajectory,
        ordered from newest to oldest. Supports filtering and pagination.

        Args:
            config: LangGraph config with ``configurable.thread_id``.
            filter: Optional metadata filter dict.
            before: Optional config whose checkpoint_id sets an upper bound.
            limit: Maximum number of checkpoints to yield.

        Yields:
            CheckpointTuple for each matching checkpoint.
        """
        thread_id = self._thread_id(config)
        checkpoint_ns = self._checkpoint_ns(config)

        try:
            scopes = await self.client.trajectories.list_scopes(thread_id)
        except (NotFoundError, CellstateError) as exc:
            logger.debug("alist: trajectory %s not found: %s", thread_id, exc)
            return

        scope_list: list[dict[str, Any]] = scopes if isinstance(scopes, list) else []

        # Filter by namespace
        ns_scopes = [
            s for s in scope_list
            if s.get("metadata", {}).get("checkpoint_ns", "") == checkpoint_ns
        ]

        # Sort newest first (by created_at descending)
        ns_scopes.sort(key=lambda s: s.get("created_at", ""), reverse=True)

        # Apply 'before' filter
        if before:
            before_id = before.get("configurable", {}).get("checkpoint_id")
            if before_id:
                filtered: list[dict[str, Any]] = []
                found = False
                for s in ns_scopes:
                    if s["scope_id"] == before_id:
                        found = True
                        continue
                    if found:
                        filtered.append(s)
                ns_scopes = filtered if found else ns_scopes

        # Apply metadata filter
        if filter:
            def _matches(scope: dict[str, Any]) -> bool:
                m = scope.get("metadata", {})
                return all(m.get(k) == v for k, v in filter.items())  # type: ignore[union-attr]
            ns_scopes = [s for s in ns_scopes if _matches(s)]

        # Apply limit
        count = 0
        for scope in ns_scopes:
            if limit is not None and count >= limit:
                break
            yield await self._scope_to_tuple(thread_id, scope)
            count += 1

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying CELLSTATE client."""
        await self.client.close()

    async def __aenter__(self) -> CellstateCheckpointer:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
