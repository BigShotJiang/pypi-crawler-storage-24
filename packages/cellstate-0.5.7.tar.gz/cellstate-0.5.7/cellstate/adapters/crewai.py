"""
CrewAI-compatible memory backed by CELLSTATE.

Provides shared memory for CrewAI crews with agent-specific partitioning
and crew-level shared artifacts, all backed by CELLSTATE's hierarchical
event-sourced memory system.

Concept mapping:

- ``Crew`` -> CELLSTATE trajectory (top-level task container)
- ``Agent`` -> CELLSTATE scope (each agent gets its own scope partition)
- ``Task result`` -> CELLSTATE note (cross-trajectory knowledge with metadata)
- ``Shared memory`` -> CELLSTATE artifacts at crew (trajectory) level
- ``Agent memory`` -> CELLSTATE artifacts within agent-specific scopes

Usage::

    from cellstate.adapters.crewai import CellstateCrewMemory

    memory = CellstateCrewMemory(api_key="cst_...", tenant_id="...")

    # Initialize crew memory (creates trajectory)
    crew_id = await memory.init_crew("research-crew", agents=["researcher", "writer"])

    # Store agent-specific memory
    await memory.store_agent_memory(crew_id, "researcher", "findings", {"topic": "AI"})

    # Store crew-level shared artifact
    await memory.store_shared(crew_id, "project_brief", "Build an AI agent...")

    # Store task result as cross-trajectory note
    await memory.store_task_result(
        crew_id, "researcher",
        content="Found 5 relevant papers on AI agents",
        task_name="literature-review",
    )

    # Query agent's memory
    agent_mem = await memory.get_agent_memory(crew_id, "researcher")

    # Query shared crew memory
    shared_mem = await memory.get_shared(crew_id)

    # Search across all crew memory
    results = await memory.search(crew_id, "AI agents")

Requires: ``pip install cellstate``
"""

from __future__ import annotations

import json
import logging
from typing import Any

from cellstate.client import CellstateClient
from cellstate.http import CellstateError, NotFoundError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Conditional imports: CrewAI types
# ---------------------------------------------------------------------------

try:
    import crewai  # noqa: F401

    _HAS_CREWAI = True
except ImportError:
    _HAS_CREWAI = False


# ---------------------------------------------------------------------------
# CellstateCrewMemory
# ---------------------------------------------------------------------------


class CellstateCrewMemory:
    """Shared memory for CrewAI crews backed by CELLSTATE.

    Provides a hierarchical memory system for CrewAI where:

    - Each crew maps to a CELLSTATE trajectory.
    - Each agent in the crew gets its own scope for private memory.
    - Shared crew artifacts are stored in a dedicated "shared" scope.
    - Task results are stored as CELLSTATE notes for cross-trajectory access.
    - All memory operations have full audit trail via the event DAG.

    Memory hierarchy::

        Crew (trajectory)
        +-- shared scope (crew-level artifacts)
        +-- agent: researcher (scope)
        |   +-- artifact: findings
        |   +-- artifact: search_queries
        +-- agent: writer (scope)
        |   +-- artifact: draft
        |   +-- artifact: outline
        +-- notes (cross-trajectory)
            +-- note: task result from researcher
            +-- note: task result from writer
    """

    def __init__(
        self,
        api_key: str,
        tenant_id: str,
        base_url: str = "https://cst.batterypack.dev",
    ) -> None:
        self.client = CellstateClient(
            api_key=api_key,
            tenant_id=tenant_id,
            base_url=base_url,
        )
        # Track scope IDs: crew_id -> {"__shared__": scope_id, agent_name: scope_id}
        self._scope_map: dict[str, dict[str, str]] = {}

    # ------------------------------------------------------------------
    # Crew lifecycle
    # ------------------------------------------------------------------

    async def init_crew(
        self,
        name: str,
        *,
        agents: list[str] | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Initialize a crew (creates a CELLSTATE trajectory + scopes).

        Creates the trajectory and pre-provisions scopes for each agent
        and a shared scope for crew-level artifacts.

        Args:
            name: Human-readable crew name.
            agents: List of agent names to pre-provision scopes for.
            description: Optional crew description.
            metadata: Arbitrary metadata.

        Returns:
            The crew_id (trajectory_id).
        """
        crew_meta: dict[str, Any] = {"adapter": "crewai", "crew_name": name}
        if agents:
            crew_meta["agents"] = agents
        if metadata:
            crew_meta.update(metadata)

        trajectory = await self.client.trajectories.create(
            name=name,
            description=description or f"CrewAI crew: {name}",
            metadata=crew_meta,
        )
        crew_id: str = trajectory["trajectory_id"]
        self._scope_map[crew_id] = {}

        # Create shared scope
        shared_scope = await self.client.scopes.create(
            trajectory_id=crew_id,
            name="shared",
            purpose="Crew-level shared artifacts",
            metadata={"adapter": "crewai", "scope_role": "shared"},
        )
        self._scope_map[crew_id]["__shared__"] = shared_scope["scope_id"]

        # Create agent-specific scopes
        for agent_name in (agents or []):
            agent_scope = await self.client.scopes.create(
                trajectory_id=crew_id,
                name=f"agent-{agent_name}",
                purpose=f"Private memory for agent: {agent_name}",
                metadata={
                    "adapter": "crewai",
                    "scope_role": "agent",
                    "agent_name": agent_name,
                },
            )
            self._scope_map[crew_id][agent_name] = agent_scope["scope_id"]

        logger.debug("init_crew: %s with agents %s", crew_id, agents)
        return crew_id

    async def _ensure_agent_scope(self, crew_id: str, agent_name: str) -> str:
        """Ensure an agent-specific scope exists, creating if needed.

        Args:
            crew_id: The crew (trajectory) ID.
            agent_name: The agent name.

        Returns:
            The scope_id for the agent.
        """
        scopes = self._scope_map.get(crew_id, {})
        if agent_name in scopes:
            return scopes[agent_name]

        # Try to find existing scope by listing trajectory scopes
        all_scopes = await self.client.trajectories.list_scopes(crew_id)
        scope_list: list[dict[str, Any]] = all_scopes if isinstance(all_scopes, list) else []

        for scope in scope_list:
            scope_meta = scope.get("metadata") or {}
            if scope_meta.get("agent_name") == agent_name:
                if crew_id not in self._scope_map:
                    self._scope_map[crew_id] = {}
                self._scope_map[crew_id][agent_name] = scope["scope_id"]
                return scope["scope_id"]

        # Create new scope for the agent
        agent_scope = await self.client.scopes.create(
            trajectory_id=crew_id,
            name=f"agent-{agent_name}",
            purpose=f"Private memory for agent: {agent_name}",
            metadata={
                "adapter": "crewai",
                "scope_role": "agent",
                "agent_name": agent_name,
            },
        )
        if crew_id not in self._scope_map:
            self._scope_map[crew_id] = {}
        self._scope_map[crew_id][agent_name] = agent_scope["scope_id"]
        return agent_scope["scope_id"]

    async def _ensure_shared_scope(self, crew_id: str) -> str:
        """Ensure the shared scope exists for a crew.

        Args:
            crew_id: The crew (trajectory) ID.

        Returns:
            The scope_id for the shared scope.
        """
        scopes = self._scope_map.get(crew_id, {})
        if "__shared__" in scopes:
            return scopes["__shared__"]

        # Try to find existing shared scope
        all_scopes = await self.client.trajectories.list_scopes(crew_id)
        scope_list: list[dict[str, Any]] = all_scopes if isinstance(all_scopes, list) else []

        for scope in scope_list:
            scope_meta = scope.get("metadata") or {}
            if scope_meta.get("scope_role") == "shared":
                if crew_id not in self._scope_map:
                    self._scope_map[crew_id] = {}
                self._scope_map[crew_id]["__shared__"] = scope["scope_id"]
                return scope["scope_id"]

        # Create shared scope
        shared_scope = await self.client.scopes.create(
            trajectory_id=crew_id,
            name="shared",
            purpose="Crew-level shared artifacts",
            metadata={"adapter": "crewai", "scope_role": "shared"},
        )
        if crew_id not in self._scope_map:
            self._scope_map[crew_id] = {}
        self._scope_map[crew_id]["__shared__"] = shared_scope["scope_id"]
        return shared_scope["scope_id"]

    # ------------------------------------------------------------------
    # Agent-specific memory
    # ------------------------------------------------------------------

    async def store_agent_memory(
        self,
        crew_id: str,
        agent_name: str,
        key: str,
        value: Any,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Store a memory entry for a specific agent.

        Creates or updates an artifact in the agent's private scope.

        Args:
            crew_id: The crew (trajectory) ID.
            agent_name: The agent name.
            key: Memory key (artifact name).
            value: Memory value (must be JSON-serializable).
            metadata: Optional metadata.

        Returns:
            The artifact_id.
        """
        scope_id = await self._ensure_agent_scope(crew_id, agent_name)
        content = json.dumps(value, default=str)

        # Check for existing artifact with same key
        artifacts_resp = await self.client.artifacts.list(
            trajectory_id=crew_id,
            scope_id=scope_id,
        )
        for artifact in artifacts_resp.get("artifacts", []):
            if artifact.get("name") == key and artifact.get("superseded_by") is None:
                updated = await self.client.artifacts.update(
                    artifact_id=artifact["artifact_id"],
                    content=content,
                    metadata=metadata,
                )
                return updated.get("artifact_id", artifact["artifact_id"])

        art_meta: dict[str, Any] = {
            "agent_name": agent_name,
            "memory_key": key,
            "adapter": "crewai",
        }
        if metadata:
            art_meta.update(metadata)

        artifact = await self.client.artifacts.create(
            trajectory_id=crew_id,
            scope_id=scope_id,
            artifact_type="Fact",
            name=key,
            content=content,
            source_turn=0,
            extraction_method="Explicit",
            ttl="Persistent",
            metadata=art_meta,
        )
        return artifact["artifact_id"]

    async def get_agent_memory(
        self,
        crew_id: str,
        agent_name: str,
        key: str | None = None,
    ) -> dict[str, Any]:
        """Get agent-specific memory.

        Args:
            crew_id: The crew (trajectory) ID.
            agent_name: The agent name.
            key: Optional specific key. If None, returns all memory.

        Returns:
            Dictionary of memory key-value pairs.
        """
        scope_id = await self._ensure_agent_scope(crew_id, agent_name)
        artifacts_resp = await self.client.artifacts.list(
            trajectory_id=crew_id,
            scope_id=scope_id,
        )

        memory: dict[str, Any] = {}
        for artifact in artifacts_resp.get("artifacts", []):
            if artifact.get("superseded_by") is not None:
                continue
            name = artifact.get("name", "")
            if key is not None and name != key:
                continue
            memory[name] = json.loads(artifact["content"])

        return memory

    async def delete_agent_memory(
        self,
        crew_id: str,
        agent_name: str,
        key: str,
    ) -> bool:
        """Delete a specific agent memory entry.

        Args:
            crew_id: The crew (trajectory) ID.
            agent_name: The agent name.
            key: Memory key to delete.

        Returns:
            True if found and deleted, False if not found.
        """
        scope_id = await self._ensure_agent_scope(crew_id, agent_name)
        artifacts_resp = await self.client.artifacts.list(
            trajectory_id=crew_id,
            scope_id=scope_id,
        )

        for artifact in artifacts_resp.get("artifacts", []):
            if artifact.get("name") == key and artifact.get("superseded_by") is None:
                await self.client.artifacts.delete(artifact["artifact_id"])
                return True

        return False

    # ------------------------------------------------------------------
    # Shared crew memory
    # ------------------------------------------------------------------

    async def store_shared(
        self,
        crew_id: str,
        key: str,
        value: Any,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Store a crew-level shared artifact.

        Shared artifacts are visible to all agents in the crew.

        Args:
            crew_id: The crew (trajectory) ID.
            key: Artifact name/key.
            value: Value (must be JSON-serializable).
            metadata: Optional metadata.

        Returns:
            The artifact_id.
        """
        scope_id = await self._ensure_shared_scope(crew_id)
        content = json.dumps(value, default=str)

        # Check for existing
        artifacts_resp = await self.client.artifacts.list(
            trajectory_id=crew_id,
            scope_id=scope_id,
        )
        for artifact in artifacts_resp.get("artifacts", []):
            if artifact.get("name") == key and artifact.get("superseded_by") is None:
                updated = await self.client.artifacts.update(
                    artifact_id=artifact["artifact_id"],
                    content=content,
                    metadata=metadata,
                )
                return updated.get("artifact_id", artifact["artifact_id"])

        art_meta: dict[str, Any] = {
            "shared": True,
            "memory_key": key,
            "adapter": "crewai",
        }
        if metadata:
            art_meta.update(metadata)

        artifact = await self.client.artifacts.create(
            trajectory_id=crew_id,
            scope_id=scope_id,
            artifact_type="Document",
            name=key,
            content=content,
            source_turn=0,
            extraction_method="Explicit",
            ttl="Persistent",
            metadata=art_meta,
        )
        return artifact["artifact_id"]

    async def get_shared(
        self,
        crew_id: str,
        key: str | None = None,
    ) -> dict[str, Any]:
        """Get crew-level shared memory.

        Args:
            crew_id: The crew (trajectory) ID.
            key: Optional specific key. If None, returns all shared memory.

        Returns:
            Dictionary of shared memory key-value pairs.
        """
        scope_id = await self._ensure_shared_scope(crew_id)
        artifacts_resp = await self.client.artifacts.list(
            trajectory_id=crew_id,
            scope_id=scope_id,
        )

        memory: dict[str, Any] = {}
        for artifact in artifacts_resp.get("artifacts", []):
            if artifact.get("superseded_by") is not None:
                continue
            name = artifact.get("name", "")
            if key is not None and name != key:
                continue
            memory[name] = json.loads(artifact["content"])

        return memory

    async def delete_shared(self, crew_id: str, key: str) -> bool:
        """Delete a crew-level shared artifact.

        Args:
            crew_id: The crew (trajectory) ID.
            key: Artifact name to delete.

        Returns:
            True if found and deleted, False if not found.
        """
        scope_id = await self._ensure_shared_scope(crew_id)
        artifacts_resp = await self.client.artifacts.list(
            trajectory_id=crew_id,
            scope_id=scope_id,
        )

        for artifact in artifacts_resp.get("artifacts", []):
            if artifact.get("name") == key and artifact.get("superseded_by") is None:
                await self.client.artifacts.delete(artifact["artifact_id"])
                return True

        return False

    # ------------------------------------------------------------------
    # Task results (cross-trajectory notes)
    # ------------------------------------------------------------------

    async def store_task_result(
        self,
        crew_id: str,
        agent_name: str,
        *,
        content: str,
        task_name: str,
        note_type: str = "Fact",
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Store a task result as a CELLSTATE note.

        Task results are stored as cross-trajectory notes so they can
        be accessed by other crews and agents.

        Args:
            crew_id: The crew (trajectory) ID.
            agent_name: The agent that produced the result.
            content: The task result content.
            task_name: Name of the task.
            note_type: Type of note (Fact, Insight, Convention, etc.).
            metadata: Optional metadata.

        Returns:
            The note_id.
        """
        note_meta: dict[str, Any] = {
            "adapter": "crewai",
            "crew_id": crew_id,
            "agent_name": agent_name,
            "task_name": task_name,
        }
        if metadata:
            note_meta.update(metadata)

        title = f"[{agent_name}] {task_name}: {content[:60]}"
        if len(content) > 60:
            title = title[:77] + "..."

        note = await self.client.notes.create(
            note_type=note_type,
            title=title,
            content=content,
            source_trajectory_ids=[crew_id],
            metadata=note_meta,
        )

        note_id: str = note["note_id"]
        logger.debug(
            "store_task_result: %s/%s -> note %s",
            agent_name, task_name, note_id,
        )
        return note_id

    async def get_task_results(
        self,
        crew_id: str,
        *,
        agent_name: str | None = None,
        task_name: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List task results for a crew, optionally filtered.

        Args:
            crew_id: The crew (trajectory) ID.
            agent_name: Filter by agent name.
            task_name: Filter by task name.
            limit: Maximum results.

        Returns:
            List of note dicts matching the filters.
        """
        response = await self.client.notes.list(limit=limit)
        results: list[dict[str, Any]] = []

        for note in response.get("notes", []):
            note_meta = note.get("metadata") or {}

            # Filter by crew_id
            if note_meta.get("crew_id") != crew_id:
                continue

            # Filter by agent_name
            if agent_name and note_meta.get("agent_name") != agent_name:
                continue

            # Filter by task_name
            if task_name and note_meta.get("task_name") != task_name:
                continue

            results.append({
                "note_id": note["note_id"],
                "content": note.get("content", ""),
                "agent_name": note_meta.get("agent_name"),
                "task_name": note_meta.get("task_name"),
                "note_type": note.get("note_type"),
                "created_at": note.get("created_at"),
                "metadata": note_meta,
            })

        return results

    # ------------------------------------------------------------------
    # Search across all crew memory
    # ------------------------------------------------------------------

    async def search(
        self,
        crew_id: str,
        query: str,
        *,
        limit: int = 10,
        min_score: float = 0.0,
        search_artifacts: bool = True,
        search_notes: bool = True,
    ) -> list[dict[str, Any]]:
        """Search across all crew memory (artifacts and notes).

        Uses CELLSTATE's 7-factor scoring for relevance ranking.

        Args:
            crew_id: The crew (trajectory) ID.
            query: Search query string.
            limit: Maximum number of results.
            min_score: Minimum relevance score.
            search_artifacts: Whether to search artifacts.
            search_notes: Whether to search notes.

        Returns:
            List of search results with scores, sorted by relevance.
        """
        results: list[dict[str, Any]] = []

        if search_artifacts:
            artifacts_resp = await self.client.artifacts.search(
                query=query,
                trajectory_id=crew_id,
                limit=limit,
                min_score=min_score if min_score > 0 else None,
            )
            for result in artifacts_resp.get("results", []):
                artifact = result.get("artifact")
                if artifact is None:
                    continue
                art_meta = artifact.get("metadata") or {}
                results.append({
                    "type": "artifact",
                    "id": artifact.get("artifact_id"),
                    "name": artifact.get("name"),
                    "content": artifact.get("content"),
                    "score": result.get("score", 0.0),
                    "agent_name": art_meta.get("agent_name"),
                    "scope": "agent" if art_meta.get("agent_name") else "shared",
                    "metadata": art_meta,
                })

        if search_notes:
            notes_resp = await self.client.notes.search(
                query=query,
                limit=limit,
                min_score=min_score if min_score > 0 else None,
            )
            for result in notes_resp.get("results", []):
                note = result.get("note")
                if note is None:
                    continue
                note_meta = note.get("metadata") or {}
                # Only include notes from this crew
                if note_meta.get("crew_id") != crew_id:
                    continue
                results.append({
                    "type": "note",
                    "id": note.get("note_id"),
                    "name": note.get("title"),
                    "content": note.get("content"),
                    "score": result.get("score", 0.0),
                    "agent_name": note_meta.get("agent_name"),
                    "task_name": note_meta.get("task_name"),
                    "metadata": note_meta,
                })

        # Sort by score descending
        results.sort(key=lambda r: r.get("score", 0.0), reverse=True)
        return results[:limit]

    # ------------------------------------------------------------------
    # Crew completion
    # ------------------------------------------------------------------

    async def complete_crew(
        self,
        crew_id: str,
        *,
        outcome: str = "success",
        summary: str | None = None,
    ) -> dict[str, Any]:
        """Mark a crew as completed.

        Closes all active scopes and updates the trajectory status.

        Args:
            crew_id: The crew (trajectory) ID.
            outcome: Outcome status ('success', 'failure', 'partial').
            summary: Optional summary.

        Returns:
            Updated trajectory data.
        """
        scopes = await self.client.trajectories.list_scopes(crew_id)
        scope_list: list[dict[str, Any]] = scopes if isinstance(scopes, list) else []

        for scope in scope_list:
            if scope.get("is_active"):
                try:
                    await self.client.scopes.close(scope["scope_id"])
                except CellstateError as exc:
                    logger.warning("Failed to close scope %s: %s", scope["scope_id"], exc)

        status_map = {
            "success": "completed",
            "failure": "failed",
            "partial": "completed",
        }
        trajectory_status = status_map.get(outcome, "completed")

        outcome_data: dict[str, Any] = {
            "status": outcome.capitalize() if outcome in ("success", "partial") else "Failure",
            "summary": summary or f"Crew completed with outcome: {outcome}",
            "produced_artifacts": [],
            "produced_notes": [],
        }

        result = await self.client.trajectories.update(
            crew_id,
            status=trajectory_status,
            outcome=outcome_data,
        )
        self._scope_map.pop(crew_id, None)
        logger.debug("complete_crew: %s -> %s", crew_id, outcome)
        return result

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying CELLSTATE client."""
        await self.client.close()

    async def __aenter__(self) -> CellstateCrewMemory:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
