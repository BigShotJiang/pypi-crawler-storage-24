"""
Mastra-compatible workflow state backed by CELLSTATE.

Mastra is a TypeScript-based AI agent framework. This adapter provides a
Python bridge for hybrid setups where Python agents participate in Mastra
workflows alongside TypeScript agents.

Concept mapping:

- ``Workflow`` -> CELLSTATE trajectory (task container)
- ``Step`` -> CELLSTATE scope (each step execution creates a scope)
- ``Tool result`` -> CELLSTATE artifact (stored within the step's scope)
- ``Workflow state`` -> aggregated artifacts across all scopes in the trajectory
- ``Step transitions`` -> scope hierarchy (parent_scope_id chain)

Usage::

    from cellstate.adapters.mastra import CellstateMastraWorkflow

    workflow = CellstateMastraWorkflow(
        api_key="cst_...",
        tenant_id="...",
    )

    # Start a workflow (creates a CELLSTATE trajectory)
    workflow_id = await workflow.start("data-pipeline")

    # Execute a step (creates a scope + artifacts)
    result = await workflow.execute_step(
        workflow_id, "fetch-data",
        input_data={"url": "https://example.com"},
    )

    # Store tool results
    await workflow.store_tool_result(
        workflow_id, "fetch-data",
        tool_name="http_fetch",
        result={"status": 200, "body": "..."},
    )

    # Get workflow state (aggregated across all steps)
    state = await workflow.get_state(workflow_id)

    # Complete the workflow
    await workflow.complete(workflow_id, outcome="success")

Requires: ``pip install cellstate``
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from cellstate.client import CellstateClient
from cellstate.http import CellstateError, NotFoundError

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Step result container
# ---------------------------------------------------------------------------


class StepResult:
    """Result of executing a workflow step.

    Attributes:
        step_name: Name of the step that was executed.
        scope_id: CELLSTATE scope_id for this step.
        input_data: Input data provided to the step.
        output_data: Output data produced by the step.
        status: Step status ('running', 'completed', 'failed').
        started_at: ISO timestamp of step start.
        metadata: Arbitrary metadata.
    """

    __slots__ = (
        "step_name",
        "scope_id",
        "input_data",
        "output_data",
        "status",
        "started_at",
        "metadata",
    )

    def __init__(
        self,
        step_name: str,
        scope_id: str,
        input_data: dict[str, Any] | None = None,
        output_data: dict[str, Any] | None = None,
        status: str = "running",
        started_at: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.step_name = step_name
        self.scope_id = scope_id
        self.input_data = input_data or {}
        self.output_data = output_data or {}
        self.status = status
        self.started_at = started_at or datetime.now(timezone.utc).isoformat()
        self.metadata = metadata or {}

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "step_name": self.step_name,
            "scope_id": self.scope_id,
            "input_data": self.input_data,
            "output_data": self.output_data,
            "status": self.status,
            "started_at": self.started_at,
            "metadata": self.metadata,
        }


# ---------------------------------------------------------------------------
# CellstateMastraWorkflow
# ---------------------------------------------------------------------------


class CellstateMastraWorkflow:
    """Wraps CELLSTATE trajectories as Mastra workflow state.

    Provides a Python bridge for hybrid setups where Python agents
    participate in Mastra workflows. Each workflow maps to a CELLSTATE
    trajectory, each step maps to a scope, and tool results are stored
    as artifacts.

    The workflow state is the aggregation of all step artifacts, giving
    you full provenance and audit trail for every piece of data flowing
    through the workflow.
    """

    def __init__(
        self,
        api_key: str,
        tenant_id: str,
        base_url: str = "https://cst.batterypack.dev",
    ) -> None:
        self.client = CellstateClient(
            api_key=api_key,
            tenant_id=tenant_id,
            base_url=base_url,
        )
        # Track active step scopes: workflow_id -> {step_name: scope_id}
        self._step_scopes: dict[str, dict[str, str]] = {}

    # ------------------------------------------------------------------
    # Workflow lifecycle
    # ------------------------------------------------------------------

    async def start(
        self,
        name: str,
        *,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        parent_workflow_id: str | None = None,
    ) -> str:
        """Start a new workflow (creates a CELLSTATE trajectory).

        Args:
            name: Human-readable workflow name.
            description: Optional workflow description.
            metadata: Arbitrary metadata for the workflow.
            parent_workflow_id: Optional parent workflow for sub-workflows.

        Returns:
            The workflow_id (trajectory_id).
        """
        merged_meta: dict[str, Any] = {"adapter": "mastra"}
        if metadata:
            merged_meta.update(metadata)

        trajectory = await self.client.trajectories.create(
            name=name,
            description=description or f"Mastra workflow: {name}",
            parent_trajectory_id=parent_workflow_id,
            metadata=merged_meta,
        )

        workflow_id: str = trajectory["trajectory_id"]
        self._step_scopes[workflow_id] = {}
        logger.debug("start: created workflow %s (%s)", workflow_id, name)
        return workflow_id

    async def execute_step(
        self,
        workflow_id: str,
        step_name: str,
        *,
        input_data: dict[str, Any] | None = None,
        parent_step: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> StepResult:
        """Execute a workflow step (creates a CELLSTATE scope).

        Creates a new scope for this step within the workflow trajectory.
        If ``input_data`` is provided, it is stored as an artifact in
        the scope for provenance tracking.

        Args:
            workflow_id: The workflow (trajectory) ID.
            step_name: Name of the step to execute.
            input_data: Input data for the step.
            parent_step: Optional parent step name for nested workflows.
            metadata: Arbitrary metadata for the step.

        Returns:
            A StepResult with the scope_id and input data.
        """
        step_meta: dict[str, Any] = {
            "adapter": "mastra",
            "step_name": step_name,
            "step_status": "running",
        }
        if metadata:
            step_meta.update(metadata)

        # Resolve parent scope
        parent_scope_id = None
        if parent_step:
            wf_scopes = self._step_scopes.get(workflow_id, {})
            parent_scope_id = wf_scopes.get(parent_step)

        scope = await self.client.scopes.create(
            trajectory_id=workflow_id,
            name=f"step-{step_name}",
            purpose=f"Mastra workflow step: {step_name}",
            parent_scope_id=parent_scope_id,
            metadata=step_meta,
        )
        scope_id: str = scope["scope_id"]

        # Track the scope
        if workflow_id not in self._step_scopes:
            self._step_scopes[workflow_id] = {}
        self._step_scopes[workflow_id][step_name] = scope_id

        # Store input data as an artifact
        if input_data:
            await self.client.artifacts.create(
                trajectory_id=workflow_id,
                scope_id=scope_id,
                artifact_type="Document",
                name=f"step-input-{step_name}",
                content=json.dumps(input_data),
                source_turn=0,
                extraction_method="Explicit",
                ttl="Persistent",
                metadata={"step_name": step_name, "artifact_role": "input"},
            )

        result = StepResult(
            step_name=step_name,
            scope_id=scope_id,
            input_data=input_data,
            status="running",
        )
        logger.debug("execute_step: %s -> scope %s", step_name, scope_id)
        return result

    async def complete_step(
        self,
        workflow_id: str,
        step_name: str,
        *,
        output_data: dict[str, Any] | None = None,
        status: str = "completed",
    ) -> StepResult:
        """Mark a workflow step as completed and store its output.

        Args:
            workflow_id: The workflow (trajectory) ID.
            step_name: Name of the step to complete.
            output_data: Output data produced by the step.
            status: Step status ('completed' or 'failed').

        Returns:
            Updated StepResult with output data and status.

        Raises:
            CellstateError: If the step scope is not found.
        """
        wf_scopes = self._step_scopes.get(workflow_id, {})
        scope_id = wf_scopes.get(step_name)

        if not scope_id:
            raise CellstateError(
                f"Step '{step_name}' not found in workflow {workflow_id}",
                code="STEP_NOT_FOUND",
            )

        # Store output data as artifact
        if output_data:
            await self.client.artifacts.create(
                trajectory_id=workflow_id,
                scope_id=scope_id,
                artifact_type="Document",
                name=f"step-output-{step_name}",
                content=json.dumps(output_data),
                source_turn=0,
                extraction_method="Explicit",
                ttl="Persistent",
                metadata={
                    "step_name": step_name,
                    "artifact_role": "output",
                    "step_status": status,
                },
            )

        # Update scope metadata to reflect completion
        await self.client.scopes.update(
            scope_id=scope_id,
            metadata={
                "adapter": "mastra",
                "step_name": step_name,
                "step_status": status,
            },
        )

        # Fetch input data from scope artifacts
        artifacts_resp = await self.client.artifacts.list(
            trajectory_id=workflow_id,
            scope_id=scope_id,
        )
        input_data: dict[str, Any] = {}
        for artifact in artifacts_resp.get("artifacts", []):
            if artifact.get("name") == f"step-input-{step_name}":
                input_data = json.loads(artifact["content"])
                break

        return StepResult(
            step_name=step_name,
            scope_id=scope_id,
            input_data=input_data,
            output_data=output_data,
            status=status,
        )

    async def store_tool_result(
        self,
        workflow_id: str,
        step_name: str,
        *,
        tool_name: str,
        result: Any,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Store a tool result as a CELLSTATE artifact.

        Args:
            workflow_id: The workflow (trajectory) ID.
            step_name: The step that invoked the tool.
            tool_name: Name of the tool.
            result: Tool result (must be JSON-serializable).
            metadata: Optional metadata for the artifact.

        Returns:
            The artifact_id of the stored result.

        Raises:
            CellstateError: If the step scope is not found.
        """
        wf_scopes = self._step_scopes.get(workflow_id, {})
        scope_id = wf_scopes.get(step_name)

        if not scope_id:
            raise CellstateError(
                f"Step '{step_name}' not found in workflow {workflow_id}",
                code="STEP_NOT_FOUND",
            )

        artifact_meta: dict[str, Any] = {
            "step_name": step_name,
            "tool_name": tool_name,
            "artifact_role": "tool_result",
        }
        if metadata:
            artifact_meta.update(metadata)

        artifact = await self.client.artifacts.create(
            trajectory_id=workflow_id,
            scope_id=scope_id,
            artifact_type="Document",
            name=f"tool-result-{tool_name}",
            content=json.dumps(result, default=str),
            source_turn=0,
            extraction_method="Explicit",
            ttl="Persistent",
            metadata=artifact_meta,
        )

        artifact_id: str = artifact["artifact_id"]
        logger.debug(
            "store_tool_result: %s/%s -> artifact %s",
            step_name, tool_name, artifact_id,
        )
        return artifact_id

    # ------------------------------------------------------------------
    # State retrieval
    # ------------------------------------------------------------------

    async def get_state(self, workflow_id: str) -> dict[str, Any]:
        """Get the aggregated workflow state across all steps.

        Collects artifacts from all scopes in the trajectory and
        organizes them by step name.

        Args:
            workflow_id: The workflow (trajectory) ID.

        Returns:
            Dictionary with step names as keys and their artifacts as values.
        """
        scopes = await self.client.trajectories.list_scopes(workflow_id)
        scope_list: list[dict[str, Any]] = scopes if isinstance(scopes, list) else []

        state: dict[str, Any] = {
            "workflow_id": workflow_id,
            "steps": {},
        }

        for scope in scope_list:
            scope_id = scope["scope_id"]
            scope_meta = scope.get("metadata") or {}
            step_name = scope_meta.get("step_name", scope.get("name", scope_id))

            artifacts_resp = await self.client.artifacts.list(
                trajectory_id=workflow_id,
                scope_id=scope_id,
            )
            artifacts = artifacts_resp.get("artifacts", [])

            step_data: dict[str, Any] = {
                "scope_id": scope_id,
                "status": scope_meta.get("step_status", "unknown"),
                "input": None,
                "output": None,
                "tool_results": {},
            }

            for artifact in artifacts:
                if artifact.get("superseded_by") is not None:
                    continue
                name = artifact.get("name", "")
                content = json.loads(artifact["content"])
                art_meta = artifact.get("metadata") or {}
                role = art_meta.get("artifact_role", "")

                if role == "input":
                    step_data["input"] = content
                elif role == "output":
                    step_data["output"] = content
                elif role == "tool_result":
                    tool = art_meta.get("tool_name", name)
                    step_data["tool_results"][tool] = content
                else:
                    step_data.setdefault("artifacts", {})[name] = content

            state["steps"][step_name] = step_data

        return state

    async def get_step_state(
        self,
        workflow_id: str,
        step_name: str,
    ) -> dict[str, Any] | None:
        """Get the state of a specific step.

        Args:
            workflow_id: The workflow (trajectory) ID.
            step_name: The step name to query.

        Returns:
            Step state dictionary, or None if step not found.
        """
        full_state = await self.get_state(workflow_id)
        return full_state.get("steps", {}).get(step_name)

    # ------------------------------------------------------------------
    # Workflow completion
    # ------------------------------------------------------------------

    async def complete(
        self,
        workflow_id: str,
        *,
        outcome: str = "success",
        summary: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Complete a workflow.

        Closes all active scopes and updates the trajectory status.

        Args:
            workflow_id: The workflow (trajectory) ID.
            outcome: Outcome status ('success', 'failure', 'partial').
            summary: Optional summary of the workflow result.
            metadata: Optional metadata update.

        Returns:
            Updated trajectory data.
        """
        # Close all active scopes for this workflow
        scopes = await self.client.trajectories.list_scopes(workflow_id)
        scope_list: list[dict[str, Any]] = scopes if isinstance(scopes, list) else []

        for scope in scope_list:
            if scope.get("is_active"):
                try:
                    await self.client.scopes.close(scope["scope_id"])
                except CellstateError as exc:
                    logger.warning(
                        "Failed to close scope %s: %s", scope["scope_id"], exc
                    )

        # Map outcome to CELLSTATE trajectory status
        status_map = {
            "success": "completed",
            "failure": "failed",
            "partial": "completed",
        }
        trajectory_status = status_map.get(outcome, "completed")

        outcome_data: dict[str, Any] = {
            "status": outcome.capitalize() if outcome in ("success", "partial") else "Failure",
            "summary": summary or f"Workflow completed with outcome: {outcome}",
            "produced_artifacts": [],
            "produced_notes": [],
        }

        update_kwargs: dict[str, Any] = {
            "status": trajectory_status,
            "outcome": outcome_data,
        }
        if metadata:
            update_kwargs["metadata"] = metadata

        result = await self.client.trajectories.update(workflow_id, **update_kwargs)
        self._step_scopes.pop(workflow_id, None)
        logger.debug("complete: workflow %s -> %s", workflow_id, outcome)
        return result

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying CELLSTATE client."""
        await self.client.close()

    async def __aenter__(self) -> CellstateMastraWorkflow:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
