"""
LangMem-compatible memory store backed by CELLSTATE PCP.

Memories flow through CELLSTATE's mutation pipeline with gate enforcement,
scoring, and event-sourced audit trail.

Concept mapping:

- ``Memory`` -> CELLSTATE Note (cross-trajectory knowledge)
- ``Namespace`` -> CELLSTATE scope hierarchy / note metadata tags
- ``add_memory()`` -> creates a Note through gate pipeline
- ``search_memories()`` -> uses CELLSTATE's 7-factor scoring (vector similarity,
  warmth, recency, abstraction level, graph proximity, keyword match, causal proximity)
- ``get_context()`` -> assembles context using ContextHelper with token budget
- ``update_memory()`` -> updates note content with optional contradiction detection
- ``delete_memory()`` -> soft-deletes note (event tracked in DAG)

Usage::

    from cellstate.adapters.langmem import CellstateMemoryStore

    store = CellstateMemoryStore(api_key="cst_...", tenant_id="...")

    # Add a memory (flows through CELLSTATE's gate pipeline)
    memory_id = await store.add_memory("User prefers dark mode")

    # Search memories (uses CELLSTATE's 7-factor scoring)
    results = await store.search_memories("UI preferences")

    # Get formatted context for LLM injection
    context = await store.get_context("What are the user's preferences?")

    # List with pagination
    memories = await store.list_memories(limit=20, offset=0)

    # Update with contradiction detection
    await store.update_memory(memory_id, "User switched to light mode")

    # Soft delete
    await store.delete_memory(memory_id)

Requires: ``pip install cellstate[langmem]``
"""

from __future__ import annotations

import logging
from typing import Any

from cellstate.client import CellstateClient
from cellstate.http import CellstateError, NotFoundError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Conditional imports: LangMem types
# ---------------------------------------------------------------------------

try:
    import langmem  # noqa: F401

    _HAS_LANGMEM = True
except ImportError:
    _HAS_LANGMEM = False


# ---------------------------------------------------------------------------
# Data types for memory entries
# ---------------------------------------------------------------------------


class MemoryEntry:
    """A single memory entry returned by search/list operations.

    Wraps a CELLSTATE Note with a LangMem-compatible interface.

    Attributes:
        memory_id: Unique identifier (maps to CELLSTATE note_id).
        content: The memory content text.
        score: Relevance score (0.0-1.0) from CELLSTATE's 7-factor scoring.
        metadata: Arbitrary metadata attached to the memory.
        created_at: ISO timestamp of creation.
        updated_at: ISO timestamp of last update.
        namespace: Logical namespace derived from note metadata.
        note_type: CELLSTATE note type (Fact, Convention, Strategy, etc.).
        abstraction_level: Semantic tier (Raw, Summary, Principle).
    """

    __slots__ = (
        "memory_id",
        "content",
        "score",
        "metadata",
        "created_at",
        "updated_at",
        "namespace",
        "note_type",
        "abstraction_level",
    )

    def __init__(
        self,
        memory_id: str,
        content: str,
        score: float = 0.0,
        metadata: dict[str, Any] | None = None,
        created_at: str | None = None,
        updated_at: str | None = None,
        namespace: str = "",
        note_type: str = "Fact",
        abstraction_level: str = "Raw",
    ) -> None:
        self.memory_id = memory_id
        self.content = content
        self.score = score
        self.metadata = metadata or {}
        self.created_at = created_at or ""
        self.updated_at = updated_at or ""
        self.namespace = namespace
        self.note_type = note_type
        self.abstraction_level = abstraction_level

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "memory_id": self.memory_id,
            "content": self.content,
            "score": self.score,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "namespace": self.namespace,
            "note_type": self.note_type,
            "abstraction_level": self.abstraction_level,
        }


# ---------------------------------------------------------------------------
# CellstateMemoryStore
# ---------------------------------------------------------------------------


class CellstateMemoryStore:
    """Drop-in replacement for LangMem's memory stores.

    Memories are stored as CELLSTATE notes (cross-trajectory knowledge)
    and flow through the Persistent Context Protocol pipeline with
    gate enforcement and scoring.

    This gives you:

    - **Gate-enforced memory mutations**: no silent overwrites -- every
      change goes through the PCP pipeline.
    - **7-factor relevance scoring**: vector similarity, warmth, recency,
      abstraction level, graph proximity, keyword match, and causal proximity.
    - **Event-sourced audit trail**: full DAG of all memory operations.
    - **Abstraction levels**: Raw -> Summary -> Principle.
    - **Namespace support**: logical partitioning via note metadata tags.
    """

    def __init__(
        self,
        api_key: str,
        tenant_id: str,
        base_url: str = "https://cst.batterypack.dev",
        default_note_type: str = "Fact",
        default_namespace: str = "",
        default_abstraction_level: str = "Raw",
    ) -> None:
        self.client = CellstateClient(
            api_key=api_key,
            tenant_id=tenant_id,
            base_url=base_url,
        )
        self._default_note_type = default_note_type
        self._default_namespace = default_namespace
        self._default_abstraction_level = default_abstraction_level

    # ------------------------------------------------------------------
    # add_memory
    # ------------------------------------------------------------------

    async def add_memory(
        self,
        content: str,
        *,
        metadata: dict[str, Any] | None = None,
        note_type: str | None = None,
        namespace: str | None = None,
        abstraction_level: str | None = None,
        source_trajectory_ids: list[str] | None = None,
        source_artifact_ids: list[str] | None = None,
    ) -> str:
        """Add a memory through CELLSTATE's pipeline (with gates).

        The memory is stored as a CELLSTATE note and goes through the PCP
        gate pipeline for validation and deduplication.

        Args:
            content: The memory content to store.
            metadata: Optional metadata to attach.
            note_type: Type of note (defaults to configured default_note_type).
                Supported types: Fact, Convention, Strategy, Gotcha, Insight.
            namespace: Logical namespace for partitioning. Stored in metadata.
            abstraction_level: Semantic tier (Raw, Summary, Principle).
            source_trajectory_ids: Trajectories this memory was derived from.
            source_artifact_ids: Artifacts this memory was derived from.

        Returns:
            The note_id of the created memory.

        Raises:
            CellstateError: If the API call fails (auth, validation, etc.).
        """
        resolved_type = note_type or self._default_note_type
        resolved_ns = namespace or self._default_namespace
        resolved_level = abstraction_level or self._default_abstraction_level

        # Build metadata with namespace tag
        merged_meta: dict[str, Any] = {}
        if metadata:
            merged_meta.update(metadata)
        if resolved_ns:
            merged_meta["namespace"] = resolved_ns
        merged_meta["created_via"] = "langmem_adapter"

        # Title: use the first 80 chars of content
        title = content[:80].replace("\n", " ")
        if len(content) > 80:
            title = title[:77] + "..."

        note = await self.client.notes.create(
            note_type=resolved_type,
            title=title,
            content=content,
            source_trajectory_ids=source_trajectory_ids,
            source_artifact_ids=source_artifact_ids,
            abstraction_level=resolved_level,
            metadata=merged_meta if merged_meta else None,
        )

        note_id: str = note["note_id"]
        logger.debug("add_memory: created note %s (type=%s, ns=%s)", note_id, resolved_type, resolved_ns)
        return note_id

    # ------------------------------------------------------------------
    # search_memories
    # ------------------------------------------------------------------

    async def search_memories(
        self,
        query: str,
        *,
        limit: int = 10,
        min_score: float = 0.0,
        namespace: str | None = None,
    ) -> list[MemoryEntry]:
        """Search memories via CELLSTATE's 7-factor scoring.

        Uses CELLSTATE's built-in 7-factor relevance scoring which considers
        vector similarity, warmth, recency, abstraction level,
        graph proximity, keyword match, and causal proximity.

        Args:
            query: Search query string.
            limit: Maximum number of results.
            min_score: Minimum relevance score threshold (0.0-1.0).
            namespace: Filter to a specific namespace.

        Returns:
            List of MemoryEntry objects, sorted by score descending.
        """
        response = await self.client.notes.search(
            query=query,
            limit=limit,
            min_score=min_score if min_score > 0 else None,
        )

        results: list[MemoryEntry] = []
        for result in response.get("results", []):
            note = result.get("note")
            if note is None:
                continue

            note_meta = note.get("metadata") or {}
            note_ns = note_meta.get("namespace", "")

            # Filter by namespace if specified
            if namespace is not None and note_ns != namespace:
                continue

            entry = MemoryEntry(
                memory_id=note["note_id"],
                content=note["content"],
                score=result.get("score", 0.0),
                metadata=note_meta,
                created_at=note.get("created_at"),
                updated_at=note.get("updated_at"),
                namespace=note_ns,
                note_type=note.get("note_type", "Fact"),
                abstraction_level=note.get("abstraction_level", "Raw"),
            )
            results.append(entry)

        return results

    # ------------------------------------------------------------------
    # get_context
    # ------------------------------------------------------------------

    async def get_context(
        self,
        query: str,
        *,
        max_tokens: int | None = None,
        max_memories: int = 20,
        namespace: str | None = None,
        include_metadata: bool = False,
    ) -> str:
        """Get formatted context string for LLM injection.

        Assembles relevant memories into a formatted string suitable for
        injecting into an LLM system prompt or context window.

        Uses CELLSTATE's 7-factor scoring to rank memories by relevance,
        then applies a token budget to truncate.

        Args:
            query: The query to find relevant context for.
            max_tokens: Optional token budget for the context.
                Uses rough 1 token ~ 4 chars estimate.
            max_memories: Maximum number of memories to consider.
            namespace: Filter to a specific namespace.
            include_metadata: Whether to include score and type in output.

        Returns:
            Formatted context string. Empty string if no memories found.
        """
        memories = await self.search_memories(
            query=query,
            limit=max_memories,
            namespace=namespace,
        )

        if not memories:
            return ""

        lines: list[str] = []
        total_chars = 0
        char_budget = max_tokens * 4 if max_tokens else None

        for memory in memories:
            if include_metadata:
                line = (
                    f"- [{memory.note_type}] "
                    f"(score: {memory.score:.2f}) "
                    f"{memory.content}"
                )
            else:
                line = f"- {memory.content}"

            if char_budget is not None and total_chars + len(line) > char_budget:
                break
            lines.append(line)
            total_chars += len(line)

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # update_memory
    # ------------------------------------------------------------------

    async def update_memory(
        self,
        memory_id: str,
        content: str | None = None,
        *,
        metadata: dict[str, Any] | None = None,
        note_type: str | None = None,
        detect_contradiction: bool = False,
    ) -> MemoryEntry:
        """Update an existing memory.

        Optionally performs contradiction detection: if the new content
        contradicts the existing memory, the old memory is superseded
        and a new note is created instead.

        Args:
            memory_id: The note_id of the memory to update.
            content: New content for the memory.
            metadata: New or merged metadata.
            note_type: New note type.
            detect_contradiction: If True, fetches the existing note and
                checks for semantic contradiction. When a contradiction is
                detected, the old note is superseded and a new one created.

        Returns:
            Updated MemoryEntry.

        Raises:
            NotFoundError: If the memory does not exist.
        """
        existing = await self.client.notes.get(memory_id)

        if detect_contradiction and content:
            existing_content = existing.get("content", "")
            if _contents_contradict(existing_content, content):
                logger.info(
                    "Contradiction detected for note %s, superseding", memory_id
                )
                # Create new note that supersedes the old one
                existing_meta = existing.get("metadata") or {}
                merged_meta = {**existing_meta}
                if metadata:
                    merged_meta.update(metadata)
                merged_meta["supersedes"] = memory_id
                merged_meta["contradiction_of"] = existing_content[:200]

                new_title = content[:80].replace("\n", " ")
                if len(content) > 80:
                    new_title = new_title[:77] + "..."

                new_note = await self.client.notes.create(
                    note_type=note_type or existing.get("note_type", self._default_note_type),
                    title=new_title,
                    content=content,
                    abstraction_level=existing.get("abstraction_level", "Raw"),
                    metadata=merged_meta if merged_meta else None,
                )
                new_meta = new_note.get("metadata") or {}
                return MemoryEntry(
                    memory_id=new_note["note_id"],
                    content=new_note.get("content", content),
                    metadata=new_meta,
                    created_at=new_note.get("created_at"),
                    updated_at=new_note.get("updated_at"),
                    namespace=new_meta.get("namespace", ""),
                    note_type=new_note.get("note_type", self._default_note_type),
                    abstraction_level=new_note.get("abstraction_level", "Raw"),
                )

        # Standard update
        update_kwargs: dict[str, Any] = {}
        if content is not None:
            update_kwargs["content"] = content
            title = content[:80].replace("\n", " ")
            if len(content) > 80:
                title = title[:77] + "..."
            update_kwargs["title"] = title
        if metadata is not None:
            # Merge with existing metadata to preserve namespace etc.
            existing_meta = existing.get("metadata") or {}
            merged = {**existing_meta, **metadata}
            update_kwargs["metadata"] = merged
        if note_type is not None:
            update_kwargs["note_type"] = note_type

        if update_kwargs:
            updated = await self.client.notes.update(memory_id, **update_kwargs)
        else:
            updated = existing

        updated_meta = updated.get("metadata") or {}
        return MemoryEntry(
            memory_id=updated.get("note_id", memory_id),
            content=updated.get("content", ""),
            metadata=updated_meta,
            created_at=updated.get("created_at"),
            updated_at=updated.get("updated_at"),
            namespace=updated_meta.get("namespace", ""),
            note_type=updated.get("note_type", self._default_note_type),
            abstraction_level=updated.get("abstraction_level", "Raw"),
        )

    # ------------------------------------------------------------------
    # delete_memory
    # ------------------------------------------------------------------

    async def delete_memory(self, memory_id: str) -> None:
        """Delete a memory by ID.

        This performs a soft delete through CELLSTATE's event DAG, maintaining
        the audit trail. The note is marked as deleted but the history is
        preserved for provenance tracking.

        Args:
            memory_id: The note_id of the memory to delete.

        Raises:
            NotFoundError: If the memory does not exist.
        """
        try:
            await self.client.notes.delete(memory_id)
            logger.debug("delete_memory: deleted note %s", memory_id)
        except NotFoundError:
            logger.warning("delete_memory: note %s not found", memory_id)
            raise

    # ------------------------------------------------------------------
    # list_memories
    # ------------------------------------------------------------------

    async def list_memories(
        self,
        *,
        namespace: str | None = None,
        note_type: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[MemoryEntry]:
        """List memories with optional filtering and pagination.

        Args:
            namespace: Filter to a specific namespace.
            note_type: Filter by note type (Fact, Convention, etc.).
            limit: Maximum number of results per page.
            offset: Pagination offset.

        Returns:
            List of MemoryEntry objects.
        """
        response = await self.client.notes.list(
            note_type=note_type,
            limit=limit,
            offset=offset,
        )

        results: list[MemoryEntry] = []
        for note in response.get("notes", []):
            note_meta = note.get("metadata") or {}
            note_ns = note_meta.get("namespace", "")

            if namespace is not None and note_ns != namespace:
                continue

            results.append(MemoryEntry(
                memory_id=note["note_id"],
                content=note.get("content", ""),
                metadata=note_meta,
                created_at=note.get("created_at"),
                updated_at=note.get("updated_at"),
                namespace=note_ns,
                note_type=note.get("note_type", "Fact"),
                abstraction_level=note.get("abstraction_level", "Raw"),
            ))

        return results

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying CELLSTATE client."""
        await self.client.close()

    async def __aenter__(self) -> CellstateMemoryStore:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


# ---------------------------------------------------------------------------
# Contradiction detection heuristic
# ---------------------------------------------------------------------------


def _contents_contradict(old: str, new: str) -> bool:
    """Simple heuristic for detecting contradictions between memory contents.

    Checks for negation patterns and explicit contradiction signals.
    For production use, this should be replaced with an LLM-based check,
    but we provide a rule-based heuristic as a baseline.

    Args:
        old: Existing memory content.
        new: Proposed new content.

    Returns:
        True if a contradiction is detected.
    """
    old_lower = old.lower().strip()
    new_lower = new.lower().strip()

    # Direct negation patterns
    negation_pairs = [
        ("prefers", "does not prefer"),
        ("prefers", "doesn't prefer"),
        ("likes", "does not like"),
        ("likes", "doesn't like"),
        ("wants", "does not want"),
        ("wants", "doesn't want"),
        ("uses", "does not use"),
        ("uses", "doesn't use"),
        ("is", "is not"),
        ("is", "isn't"),
        ("has", "does not have"),
        ("has", "doesn't have"),
        ("can", "cannot"),
        ("can", "can't"),
        ("will", "will not"),
        ("will", "won't"),
        ("should", "should not"),
        ("should", "shouldn't"),
        ("true", "false"),
        ("enabled", "disabled"),
        ("active", "inactive"),
        ("yes", "no"),
    ]

    for positive, negative in negation_pairs:
        if (positive in old_lower and negative in new_lower) or (
            negative in old_lower and positive in new_lower
        ):
            return True

    # Change-marker heuristic: statements that explicitly announce a state
    # transition ("switched to", "changed to", "no longer", "now") are
    # treated as contradictions with earlier state claims.
    change_markers = ("switched to", "changed to", "no longer", "now ")
    if old_lower != new_lower and any(marker in new_lower for marker in change_markers):
        return True

    return False
