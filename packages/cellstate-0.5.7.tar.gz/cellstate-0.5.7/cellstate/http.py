"""
CELLSTATE HTTP Client.

Wraps httpx with CELLSTATE-specific configuration, authentication,
and error handling.
"""

from __future__ import annotations

from typing import Any, Literal

import httpx
import msgpack


class CellstateError(Exception):
    """Base error for CELLSTATE SDK."""

    def __init__(self, message: str, code: str = "UNKNOWN_ERROR", status_code: int | None = None):
        super().__init__(message)
        self.code = code
        self.status_code = status_code


class NotFoundError(CellstateError):
    """Resource not found."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, code="NOT_FOUND", status_code=404)


class AuthenticationError(CellstateError):
    """Authentication failed."""

    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, code="UNAUTHORIZED", status_code=401)


class AuthorizationError(CellstateError):
    """Authorization failed."""

    def __init__(self, message: str = "Forbidden"):
        super().__init__(message, code="FORBIDDEN", status_code=403)


class ValidationError(CellstateError):
    """Validation error."""

    def __init__(self, message: str = "Validation failed"):
        super().__init__(message, code="VALIDATION_ERROR", status_code=400)


class ConflictError(CellstateError):
    """Conflict error."""

    def __init__(self, message: str = "Conflict"):
        super().__init__(message, code="CONFLICT", status_code=409)


class RateLimitError(CellstateError):
    """Rate limit exceeded."""

    def __init__(self, message: str = "Rate limit exceeded"):
        super().__init__(message, code="RATE_LIMITED", status_code=429)


def _parse_api_error(status_code: int, body: Any) -> CellstateError:
    """Parse an API error response into the appropriate exception."""
    message = "Unknown error"
    server_code: str | None = None
    if isinstance(body, dict):
        message = body.get("error", body.get("message", str(body)))
        server_code = body.get("code")
    elif isinstance(body, str):
        message = body

    error_map: dict[int, type[CellstateError]] = {
        400: ValidationError,
        401: AuthenticationError,
        403: AuthorizationError,
        404: NotFoundError,
        409: ConflictError,
        429: RateLimitError,
    }

    error_class = error_map.get(status_code, CellstateError)
    err = error_class(message)
    if server_code is not None:
        err.code = server_code
    return err


class HttpClient:
    """HTTP client for CELLSTATE API requests."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        tenant_id: str,
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        response_format: Literal["json", "msgpack"] = "json",
    ):
        if not api_key:
            raise AuthenticationError("API key is required")
        if not tenant_id:
            raise CellstateError("Tenant ID is required", code="CONFIGURATION_ERROR")

        self._tenant_id = tenant_id
        self._base_url = base_url.rstrip("/")
        self._response_format = response_format

        default_headers = {
            "Content-Type": "application/json",
            "X-Api-Key": api_key,
            "X-Tenant-ID": tenant_id,
        }
        if response_format == "msgpack":
            default_headers["Accept"] = "application/msgpack, application/json;q=0.9"
        if headers:
            default_headers.update(headers)

        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=default_headers,
            timeout=timeout,
        )

    @property
    def tenant_id(self) -> str:
        """Get the tenant ID for this client."""
        return self._tenant_id

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Perform a GET request."""
        response = await self._client.get(path, params=_clean_params(params))
        return _handle_response(response, self._response_format)

    async def post(self, path: str, data: Any = None, params: dict[str, Any] | None = None) -> Any:
        """Perform a POST request."""
        response = await self._client.post(path, json=data, params=_clean_params(params))
        return _handle_response(response, self._response_format)

    async def patch(self, path: str, data: Any = None) -> Any:
        """Perform a PATCH request."""
        response = await self._client.patch(path, json=data)
        return _handle_response(response, self._response_format)

    async def put(self, path: str, data: Any = None) -> Any:
        """Perform a PUT request."""
        response = await self._client.put(path, json=data)
        return _handle_response(response, self._response_format)

    async def delete(self, path: str, data: Any = None) -> Any:
        """Perform a DELETE request."""
        response = await self._client.delete(path, json=data)
        return _handle_response(response, self._response_format)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> HttpClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


def _clean_params(params: dict[str, Any] | None) -> dict[str, Any] | None:
    """Remove None values from query parameters."""
    if params is None:
        return None
    return {k: v for k, v in params.items() if v is not None}


def _is_msgpack_content_type(content_type: str) -> bool:
    normalized = content_type.lower()
    return "application/msgpack" in normalized or "application/x-msgpack" in normalized


def _decode_msgpack_payload(response: httpx.Response) -> Any:
    if not response.content:
        return None
    return msgpack.unpackb(response.content, raw=False)


def _handle_response(response: httpx.Response, preferred_format: Literal["json", "msgpack"]) -> Any:
    """Handle an HTTP response, raising appropriate errors."""
    if response.is_success:
        if response.status_code == 204:
            return None

        content_type = response.headers.get("content-type", "")
        if _is_msgpack_content_type(content_type):
            try:
                return _decode_msgpack_payload(response)
            except Exception:
                return None

        if preferred_format == "msgpack":
            # Some endpoints may still return JSON while msgpack mode is enabled.
            try:
                return response.json()
            except Exception:
                try:
                    return _decode_msgpack_payload(response)
                except Exception:
                    return None

        try:
            return response.json()
        except Exception:
            return None

    try:
        body = response.json()
    except Exception:
        body = response.text

    raise _parse_api_error(response.status_code, body)
