"""
CELLSTATE Context Assembly Helper.

Provides utilities for assembling context from CELLSTATE memory
for use in LLM prompts.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from cellstate.http import HttpClient


class ContextHelper:
    """Context assembly helper.

    Collects and formats context from CELLSTATE memory for LLM prompts.

    Example::

        helper = ContextHelper(http_client)
        context = await helper.assemble_context(
            trajectory_id="...",
            include_notes=True,
            max_artifacts=5,
            relevance_query="user authentication",
        )
    """

    def __init__(self, http: HttpClient):
        self._http = http

    async def assemble_context(
        self,
        trajectory_id: str,
        include_notes: bool = True,
        max_artifacts: int = 10,
        max_notes: int = 5,
        max_turns: int = 20,
        relevance_query: str | None = None,
        min_relevance: float = 0.5,
        include_hierarchy: bool = False,
        scope_id: str | None = None,
    ) -> dict[str, Any]:
        """Assemble context from a trajectory for use in LLM prompts.

        Collects hierarchical memory including:
        - Trajectory metadata and hierarchy
        - Artifacts (structured outputs from previous interactions)
        - Notes (cross-trajectory knowledge)
        - Recent turns (conversation history)

        Args:
            trajectory_id: The trajectory to gather context from.
            include_notes: Whether to include cross-trajectory notes.
            max_artifacts: Maximum number of artifacts to include.
            max_notes: Maximum number of notes to include.
            max_turns: Maximum number of turns to include.
            relevance_query: Optional query for semantic search.
            min_relevance: Minimum relevance score (0-1).
            include_hierarchy: Whether to include parent trajectories.
            scope_id: Specific scope ID (defaults to most recent active).

        Returns:
            Assembled context dictionary with trajectory, scope,
            artifacts, notes, turns, and metadata.
        """
        # Fetch the trajectory
        trajectory = await self._http.get(f"/api/v1/trajectories/{trajectory_id}")

        # Fetch parent trajectories if requested
        parent_trajectories = None
        if include_hierarchy and trajectory.get("parent_trajectory_id"):
            parent_trajectories = await self._fetch_hierarchy(
                trajectory["parent_trajectory_id"]
            )

        # Fetch scope
        scope = None
        if scope_id:
            scope = await self._http.get(f"/api/v1/scopes/{scope_id}")
        else:
            # The trajectory scopes endpoint returns all scopes (no query filters).
            # Filter client-side for the most recent active scope.
            all_scopes = await self._http.get(
                f"/api/v1/trajectories/{trajectory_id}/scopes",
            )
            # Response is a plain list (not paginated), filter for is_active=true
            active_scopes = [
                s for s in (all_scopes if isinstance(all_scopes, list) else [])
                if s.get("is_active")
            ]
            if active_scopes:
                scope = active_scopes[-1]

        # Fetch artifacts
        artifacts: list[dict[str, Any]] = []
        if relevance_query:
            search_response = await self._http.post(
                "/api/v1/artifacts/search",
                {
                    "query": relevance_query,
                    "trajectory_id": trajectory_id,
                    "limit": max_artifacts,
                    "min_score": min_relevance,
                },
            )
            artifacts = [
                r["artifact"]
                for r in search_response.get("results", [])
                if r.get("score", 0) >= min_relevance
            ]
        else:
            artifacts_response = await self._http.get(
                "/api/v1/artifacts",
                params={"trajectory_id": trajectory_id, "limit": max_artifacts},
            )
            artifacts = artifacts_response.get("artifacts", [])

        # Fetch notes
        notes: list[dict[str, Any]] = []
        if include_notes:
            if relevance_query:
                search_response = await self._http.post(
                    "/api/v1/notes/search",
                    {
                        "query": relevance_query,
                        "limit": max_notes,
                        "min_score": min_relevance,
                    },
                )
                notes = [
                    r["note"]
                    for r in search_response.get("results", [])
                    if r.get("score", 0) >= min_relevance
                ]
            else:
                notes_response = await self._http.get(
                    "/api/v1/notes",
                    params={"limit": max_notes},
                )
                notes = notes_response.get("notes", [])

        # Fetch turns
        turns: list[dict[str, Any]] = []
        if scope:
            turns_response = await self._http.get(
                f"/api/v1/scopes/{scope['scope_id']}/turns",
                params={"limit": max_turns},
            )
            turns = turns_response.get("turns", [])

        total_items = len(artifacts) + len(notes) + len(turns)
        truncated = (
            len(artifacts) >= max_artifacts
            or len(notes) >= max_notes
            or len(turns) >= max_turns
        )

        return {
            "trajectory": trajectory,
            "scope": scope,
            "parent_trajectories": parent_trajectories,
            "artifacts": artifacts,
            "notes": notes,
            "turns": turns,
            "meta": {
                "assembled_at": datetime.now(timezone.utc).isoformat(),
                "total_items": total_items,
                "truncated": truncated,
                "relevance_query": relevance_query,
            },
        }

    async def _fetch_hierarchy(self, trajectory_id: str) -> list[dict[str, Any]]:
        """Fetch parent trajectory hierarchy."""
        hierarchy: list[dict[str, Any]] = []
        current_id: str | None = trajectory_id

        while current_id:
            traj = await self._http.get(f"/api/v1/trajectories/{current_id}")
            hierarchy.append(traj)
            current_id = traj.get("parent_trajectory_id")

            # Safety limit
            if len(hierarchy) > 10:
                break

        return hierarchy
