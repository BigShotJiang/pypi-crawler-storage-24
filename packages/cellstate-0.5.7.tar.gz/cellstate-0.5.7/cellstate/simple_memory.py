"""
SimpleMemory — Zero-friction memory API for CELLSTATE.

No trajectories. No scopes. No concepts to learn.
One config object, five methods, Blake3 receipts on every write.

Example::

    from cellstate import SimpleMemory

    memory = SimpleMemory(api_key="cst_...")

    await memory.add("User prefers Python and Pydantic")
    ctx = await memory.context("what does the user prefer?")

    # ctx.text: "User prefers Python and Pydantic"
    # ctx.receipt: "b3a9f2c1d4e5..." ← tamper-evident proof of every write
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Literal

from cellstate.client import CellstateClient

__all__ = [
    "SimpleMemory",
    "SimpleMemoryConfig",
    "AddResult",
    "RecallResult",
    "ContextResult",
    "ForgetResult",
    "ForgetAllResult",
    "HistoryEvent",
]

_FALLBACK_RECEIPT = "receipt-unavailable"


# ============================================================================
# Config
# ============================================================================


@dataclass
class SimpleMemoryConfig:
    """Configuration for SimpleMemory."""

    api_key: str
    """CELLSTATE API key (starts with cst_)."""

    base_url: str = "https://cst.batterypack.dev"
    """API base URL. Override for self-hosted deployments."""

    user_id: str = "default"
    """
    User identifier for memory isolation across sessions.
    Memories for the same user_id persist and accumulate across instances.
    """

    agent_id: str = "default"
    """Agent identifier for memory isolation."""

    max_tokens: int = 4096
    """Token budget for context assembly."""

    tenant_id: str = "default"
    """Tenant identifier. Override for multi-tenant deployments."""


# ============================================================================
# Result types
# ============================================================================


@dataclass
class AddResult:
    id: str
    """ID of the stored memory."""

    receipt: str
    """Blake3 receipt hash — tamper-evident proof this write was committed."""


@dataclass
class RecallResult:
    id: str
    content: str
    score: float
    level: Literal["raw", "summary", "principle"]
    created_at: datetime


@dataclass
class ContextResult:
    text: str
    """Context string ready to inject into an LLM prompt."""

    token_count: int
    """Estimated token count."""

    memory_count: int
    """Number of memories included."""

    receipt: str | None = None
    """Blake3 receipt of the most recent write in this context window."""


@dataclass
class ForgetResult:
    receipt: str


@dataclass
class ForgetAllResult:
    count: int
    receipt: str


@dataclass
class HistoryEvent:
    event: Literal["add", "forget", "update"]
    memory_id: str
    timestamp: datetime
    receipt: str


# ============================================================================
# Internals
# ============================================================================


@dataclass
class _SessionState:
    trajectory_id: str
    scope_id: str


def _level_from_abstraction(level: str | None) -> Literal["raw", "summary", "principle"]:
    if level == "Summary":
        return "summary"
    if level == "Principle":
        return "principle"
    return "raw"


def _estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)


# ============================================================================
# SimpleMemory
# ============================================================================


class SimpleMemory:
    """
    SimpleMemory — The entry point for 99% of CELLSTATE users.

    Wraps the full CellstateClient with a surface that requires zero knowledge
    of CELLSTATE's internal data model. Every write returns a Blake3 receipt.

    Mem0 drop-in compatibility: ``add()``, ``search()``, ``get_all()``
    are available as aliases for migration.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        config: SimpleMemoryConfig | None = None,
        base_url: str = "https://cst.batterypack.dev",
        user_id: str = "default",
        agent_id: str = "default",
        max_tokens: int = 4096,
        tenant_id: str = "default",
    ) -> None:
        """
        Create a SimpleMemory instance.

        Can be called in two ways::

            # Simple (most common)
            memory = SimpleMemory(api_key="cst_...")

            # With config object
            memory = SimpleMemory(config=SimpleMemoryConfig(api_key="cst_..."))
        """
        if config is not None:
            cfg = config
        elif api_key is not None:
            cfg = SimpleMemoryConfig(
                api_key=api_key,
                base_url=base_url,
                user_id=user_id,
                agent_id=agent_id,
                max_tokens=max_tokens,
                tenant_id=tenant_id,
            )
        else:
            raise ValueError("Either api_key or config must be provided")

        self._client = CellstateClient(
            api_key=cfg.api_key,
            tenant_id=cfg.tenant_id,
            base_url=cfg.base_url,
        )
        self._user_id = cfg.user_id
        self._agent_id = cfg.agent_id
        self._max_tokens = cfg.max_tokens
        self._session: _SessionState | None = None
        # In-memory receipt cache keyed by memory ID
        self._receipt_cache: dict[str, str] = {}

    # =========================================================================
    # Core API
    # =========================================================================

    async def add(
        self,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> AddResult:
        """
        Store a memory.

        Returns the memory ID and Blake3 receipt hash.
        The receipt is cryptographic proof this write was validated and committed.

        Example::

            result = await memory.add("User prefers dark mode")
            print(result.receipt)  # "b3a9f2c1d4e5..." ← Blake3 hash
        """
        note = await self._client.notes.create(
            note_type="Fact",
            title=content[:100],
            content=content,
            metadata={
                **(metadata or {}),
                "_cellstate_user_id": self._user_id,
                "_cellstate_agent_id": self._agent_id,
            },
        )

        receipt = note.get("receipt_hash") or _FALLBACK_RECEIPT
        memory_id = note["note_id"]
        if receipt != _FALLBACK_RECEIPT:
            self._receipt_cache[memory_id] = receipt

        return AddResult(id=memory_id, receipt=receipt)

    async def recall(
        self,
        query: str,
        limit: int = 10,
        min_score: float = 0.0,
        level: Literal["raw", "summary", "principle", "all"] = "all",
    ) -> list[RecallResult]:
        """
        Recall relevant memories for a query.

        Returns ranked results with scores and abstraction levels.
        """
        response = await self._client.notes.search(
            query=query,
            limit=limit,
        )

        results: list[RecallResult] = []
        for item in response.get("results", []):
            score = float(item.get("score", 0.0))
            if score < min_score:
                continue

            item_level = _level_from_abstraction(item.get("abstraction_level"))
            if level != "all" and item_level != level:
                continue

            created_raw = item.get("created_at", "")
            try:
                created_at = datetime.fromisoformat(created_raw.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                created_at = datetime.now()

            results.append(
                RecallResult(
                    id=item.get("id", item.get("note_id", "")),
                    content=item.get("snippet", item.get("content", item.get("name", ""))),
                    score=score,
                    level=item_level,
                    created_at=created_at,
                )
            )

        return results

    async def context(
        self,
        query: str,
        max_tokens: int | None = None,
        format: Literal["prose", "bullet", "xml"] = "prose",
    ) -> ContextResult:
        """
        Build a context string ready to inject into an LLM prompt.

        Respects token budget. The most recent Blake3 receipt is included
        in the result to make auditability visible.

        Example::

            ctx = await memory.context("user preferences", max_tokens=2000)
            prompt = f"{ctx.text}\\n\\nUser: What are my settings?"
            # ctx.receipt: "b3a9f2c1..." ← proof of the last write
        """
        budget = max_tokens or min(self._max_tokens, 2000)
        session = await self._ensure_session()

        assembled = await self._client._context_helper.assemble_context(
            trajectory_id=session.trajectory_id,
            scope_id=session.scope_id,
            include_notes=True,
            max_notes=20,
            max_artifacts=5,
            relevance_query=query or None,
        )

        # Format the assembled context dict into an injectable string
        parts: list[str] = []
        for note in assembled.get("notes", []):
            content = note.get("content", "")
            if content:
                parts.append(content)
        for artifact in assembled.get("artifacts", []):
            content = artifact.get("content", "")
            if content:
                parts.append(content)

        # Trim to token budget
        raw = "\n\n".join(parts)
        while _estimate_tokens(raw) > budget and parts:
            parts.pop()
            raw = "\n\n".join(parts)

        token_count = _estimate_tokens(raw)
        memory_count = len(assembled.get("notes", [])) + len(assembled.get("artifacts", []))

        latest_receipt = (
            list(self._receipt_cache.values())[-1]
            if self._receipt_cache
            else None
        )

        return ContextResult(
            text=raw,
            token_count=token_count,
            memory_count=memory_count,
            receipt=latest_receipt,
        )

    async def forget(self, id: str) -> ForgetResult:
        """
        Forget a specific memory by ID.

        Returns a receipt proving the deletion was committed.
        """
        await self._client.notes.delete(id)
        self._receipt_cache.pop(id, None)
        return ForgetResult(receipt=f"deleted:{id}")

    async def forget_all(self, query: str) -> ForgetAllResult:
        """
        Forget all memories matching a query.
        """
        results = await self.recall(query, limit=100)
        deleted_ids: list[str] = []
        for r in results:
            await self._client.notes.delete(r.id)
            self._receipt_cache.pop(r.id, None)
            deleted_ids.append(r.id)

        return ForgetAllResult(
            count=len(deleted_ids),
            receipt=f"deleted:{','.join(deleted_ids)}",
        )

    def history(
        self,
        limit: int = 50,
        before: datetime | None = None,
        after: datetime | None = None,
    ) -> list[HistoryEvent]:
        """
        Get the audit trail for this session's memories.

        Sourced from the local receipt cache (in-memory for this session).
        For full cross-session history, use the CELLSTATE dashboard or event DAG API.
        """
        now = datetime.now()
        events: list[HistoryEvent] = [
            HistoryEvent(
                event="add",
                memory_id=memory_id,
                timestamp=now,
                receipt=receipt,
            )
            for memory_id, receipt in self._receipt_cache.items()
        ]

        if after:
            events = [e for e in events if e.timestamp >= after]
        if before:
            events = [e for e in events if e.timestamp <= before]

        return events[:limit]

    # =========================================================================
    # Mem0 drop-in aliases
    # =========================================================================

    async def search(
        self,
        query: str,
        limit: int = 10,
        **_kwargs: Any,
    ) -> list[RecallResult]:
        """Mem0 compatibility alias for ``recall()``."""
        return await self.recall(query, limit=limit)

    async def get_all(
        self,
        limit: int = 50,
        **_kwargs: Any,
    ) -> list[RecallResult]:
        """Mem0 compatibility alias — returns all memories."""
        return await self.recall("", limit=limit)

    # =========================================================================
    # Sync convenience wrappers
    # =========================================================================

    def add_sync(
        self,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> AddResult:
        """Synchronous wrapper for ``add()``. Uses asyncio.run()."""
        return asyncio.run(self.add(content, metadata))

    def recall_sync(self, query: str, **kwargs: Any) -> list[RecallResult]:
        """Synchronous wrapper for ``recall()``."""
        return asyncio.run(self.recall(query, **kwargs))

    def context_sync(self, query: str, **kwargs: Any) -> ContextResult:
        """Synchronous wrapper for ``context()``."""
        return asyncio.run(self.context(query, **kwargs))

    # =========================================================================
    # Session management (internal)
    # =========================================================================

    async def _ensure_session(self) -> _SessionState:
        if self._session:
            return self._session

        session_name = f"simple-memory:{self._user_id}:{self._agent_id}"

        # Try to find an existing trajectory for this user/agent combo.
        # The trajectory list doesn't support name filtering, so we fetch
        # recent trajectories and match by name client-side.
        try:
            listing = await self._client.trajectories.list(limit=50)
            trajectories = listing.get("trajectories", [])
            match = next(
                (t for t in trajectories if t.get("name") == session_name),
                None,
            )
        except Exception:
            match = None

        if match:
            trajectory_id = match["trajectory_id"]
        else:
            trajectory = await self._client.trajectories.create(
                name=session_name,
                description=f"SimpleMemory session for user={self._user_id} agent={self._agent_id}",
            )
            trajectory_id = trajectory["trajectory_id"]

        import time
        scope = await self._client.scopes.create(
            trajectory_id=trajectory_id,
            name=f"session-{int(time.time() * 1000)}",
            token_budget=self._max_tokens,
        )

        self._session = _SessionState(
            trajectory_id=trajectory_id,
            scope_id=scope["scope_id"],
        )
        return self._session
