"""CELLSTATE SDK constants."""

DEFAULT_BASE_URL = "https://cst.batterypack.dev"
