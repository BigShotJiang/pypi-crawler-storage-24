from __future__ import annotations

import json
from pathlib import Path

from cellstate.models import (
    ArtifactResponse,
    CreateArtifactParams,
    CreateNoteParams,
    CreateScopeParams,
    CreateTrajectoryParams,
    NoteResponse,
    ScopeResponse,
    TrajectoryResponse,
)


FIXTURE_ROOT = Path(__file__).resolve().parents[3] / "tests" / "contracts" / "fixtures"


def _load_fixture(name: str) -> dict:
    return json.loads((FIXTURE_ROOT / name).read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Trajectory
# ---------------------------------------------------------------------------


def test_create_trajectory_fixture_is_snake_case() -> None:
    payload = _load_fixture("create_trajectory_request.json")
    parsed = CreateTrajectoryParams.model_validate(payload)
    dumped = parsed.model_dump(exclude_none=False)

    assert dumped["name"] == "contract-trajectory"
    assert "description" in dumped
    assert "parent_trajectory_id" in dumped
    assert "parentTrajectoryId" not in dumped


def test_trajectory_response_fixture_is_snake_case() -> None:
    payload = _load_fixture("trajectory_response.json")
    parsed = TrajectoryResponse.model_validate(payload)
    dumped = parsed.model_dump(exclude_none=False)

    assert dumped["trajectory_id"] == "11111111-1111-4111-8111-111111111111"
    assert dumped["status"] == "active"
    assert "parent_trajectory_id" in dumped
    assert "parentTrajectoryId" not in dumped


# ---------------------------------------------------------------------------
# Artifact
# ---------------------------------------------------------------------------


def test_create_artifact_fixture_is_snake_case() -> None:
    payload = _load_fixture("create_artifact_request.json")
    parsed = CreateArtifactParams.model_validate(payload)
    dumped = parsed.model_dump(exclude_none=False)

    assert dumped["name"] == "contract-artifact"
    assert dumped["artifact_type"] == "code"
    assert dumped["source_turn"] == 1
    assert "trajectory_id" in dumped
    assert "scope_id" in dumped
    assert "extraction_method" in dumped
    assert "trajectoryId" not in dumped
    assert "scopeId" not in dumped
    assert "sourceTurn" not in dumped


def test_artifact_response_fixture_is_snake_case() -> None:
    payload = _load_fixture("artifact_response.json")
    parsed = ArtifactResponse.model_validate(payload)
    dumped = parsed.model_dump(exclude_none=False)

    assert dumped["artifact_id"] == "33333333-3333-4333-8333-333333333333"
    assert dumped["artifact_type"] == "code"
    assert dumped["name"] == "contract-artifact"
    assert "trajectory_id" in dumped
    assert "scope_id" in dumped
    assert "content_hash" in dumped
    assert "created_at" in dumped
    assert "artifactId" not in dumped
    assert "contentHash" not in dumped


# ---------------------------------------------------------------------------
# Note
# ---------------------------------------------------------------------------


def test_create_note_fixture_is_snake_case() -> None:
    payload = _load_fixture("create_note_request.json")
    parsed = CreateNoteParams.model_validate(payload)
    dumped = parsed.model_dump(exclude_none=False)

    assert dumped["title"] == "contract-note"
    assert dumped["note_type"] == "observation"
    assert len(dumped["source_trajectory_ids"]) == 1
    assert "note_type" in dumped
    assert "source_trajectory_ids" in dumped
    assert "noteType" not in dumped
    assert "sourceTrajectoryIds" not in dumped


def test_note_response_fixture_is_snake_case() -> None:
    payload = _load_fixture("note_response.json")
    parsed = NoteResponse.model_validate(payload)
    dumped = parsed.model_dump(exclude_none=False)

    assert dumped["note_id"] == "55555555-5555-4555-8555-555555555555"
    assert dumped["note_type"] == "observation"
    assert dumped["title"] == "contract-note"
    assert dumped["access_count"] == 0
    assert "content_hash" in dumped
    assert "source_trajectory_ids" in dumped
    assert "created_at" in dumped
    assert "noteId" not in dumped
    assert "accessCount" not in dumped


# ---------------------------------------------------------------------------
# Scope
# ---------------------------------------------------------------------------


def test_create_scope_fixture_is_snake_case() -> None:
    payload = _load_fixture("create_scope_request.json")
    parsed = CreateScopeParams.model_validate(payload)
    dumped = parsed.model_dump(exclude_none=False)

    assert dumped["name"] == "contract-scope"
    assert dumped["token_budget"] == 8000
    assert "trajectory_id" in dumped
    assert "parent_scope_id" in dumped
    assert "trajectoryId" not in dumped
    assert "parentScopeId" not in dumped
    assert "tokenBudget" not in dumped


def test_scope_response_fixture_is_snake_case() -> None:
    payload = _load_fixture("scope_response.json")
    parsed = ScopeResponse.model_validate(payload)
    dumped = parsed.model_dump(exclude_none=False)

    assert dumped["scope_id"] == "22222222-2222-4222-8222-222222222222"
    assert dumped["name"] == "contract-scope"
    assert dumped["is_active"] is True
    assert dumped["token_budget"] == 8000
    assert dumped["tokens_used"] == 0
    assert "trajectory_id" in dumped
    assert "parent_scope_id" in dumped
    assert "created_at" in dumped
    assert "scopeId" not in dumped
    assert "isActive" not in dumped
    assert "tokensUsed" not in dumped
