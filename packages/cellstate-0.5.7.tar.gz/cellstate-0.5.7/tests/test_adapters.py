"""
Comprehensive tests for CELLSTATE framework adapters.

Tests each adapter's core operations against mocked CELLSTATE client calls.
Verifies serialization/deserialization roundtrips and error handling paths.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Fixtures: Mocked CellstateClient
# ---------------------------------------------------------------------------


def _make_mock_client():
    """Create a fully mocked CellstateClient with all managers."""
    client = AsyncMock()

    # Trajectory manager
    client.trajectories = AsyncMock()
    client.trajectories.create = AsyncMock()
    client.trajectories.get = AsyncMock()
    client.trajectories.list_scopes = AsyncMock(return_value=[])
    client.trajectories.update = AsyncMock()

    # Scope manager
    client.scopes = AsyncMock()
    client.scopes.create = AsyncMock()
    client.scopes.get = AsyncMock()
    client.scopes.update = AsyncMock()
    client.scopes.close = AsyncMock()
    client.scopes.checkpoint = AsyncMock()
    client.scopes.list_turns = AsyncMock(return_value=[])
    client.scopes.list_artifacts = AsyncMock(return_value=[])

    # Artifact manager
    client.artifacts = AsyncMock()
    client.artifacts.create = AsyncMock()
    client.artifacts.get = AsyncMock()
    client.artifacts.list = AsyncMock(return_value={"artifacts": []})
    client.artifacts.update = AsyncMock()
    client.artifacts.delete = AsyncMock()
    client.artifacts.search = AsyncMock(return_value={"results": []})

    # Note manager
    client.notes = AsyncMock()
    client.notes.create = AsyncMock()
    client.notes.get = AsyncMock()
    client.notes.list = AsyncMock(return_value={"notes": []})
    client.notes.update = AsyncMock()
    client.notes.delete = AsyncMock()
    client.notes.search = AsyncMock(return_value={"results": []})

    # Turn manager
    client.turns = AsyncMock()

    # Agent manager
    client.agents = AsyncMock()

    # Lifecycle
    client.close = AsyncMock()

    return client


# ============================================================================
# CellstateCheckpointer tests
# ============================================================================


class TestCellstateCheckpointer:
    """Tests for the LangGraph CellstateCheckpointer adapter."""

    @pytest.fixture
    def mock_client(self):
        return _make_mock_client()

    @pytest.fixture
    def checkpointer(self, mock_client):
        from cellstate.adapters.langgraph import CellstateCheckpointer

        cp = CellstateCheckpointer.__new__(CellstateCheckpointer)
        cp.client = mock_client
        cp._trajectory_cache = {}
        return cp

    @pytest.fixture
    def config(self):
        return {
            "configurable": {
                "thread_id": "thread-001",
                "checkpoint_ns": "",
            }
        }

    # -- aget_tuple --------------------------------------------------------

    @pytest.mark.asyncio
    async def test_aget_tuple_returns_none_when_no_scopes(self, checkpointer, config, mock_client):
        """aget_tuple returns None when no scopes exist for the thread."""
        mock_client.trajectories.list_scopes.return_value = []
        result = await checkpointer.aget_tuple(config)
        assert result is None

    @pytest.mark.asyncio
    async def test_aget_tuple_returns_checkpoint_tuple(self, checkpointer, config, mock_client):
        """aget_tuple returns a proper CheckpointTuple from scope artifacts."""
        mock_client.trajectories.list_scopes.return_value = [
            {
                "scope_id": "scope-001",
                "is_active": True,
                "created_at": "2025-01-01T00:00:00Z",
                "metadata": {"checkpoint_ns": ""},
            }
        ]
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {
                    "name": "messages",
                    "content": json.dumps(["hello", "world"]),
                    "superseded_by": None,
                },
                {
                    "name": "__channel_versions__",
                    "content": json.dumps({"messages": 1}),
                    "superseded_by": None,
                },
            ]
        }

        result = await checkpointer.aget_tuple(config)

        assert result is not None
        assert result.config["configurable"]["thread_id"] == "thread-001"
        assert result.checkpoint["channel_values"]["messages"] == ["hello", "world"]
        assert result.checkpoint["channel_versions"] == {"messages": 1}

    @pytest.mark.asyncio
    async def test_aget_tuple_with_checkpoint_id(self, checkpointer, mock_client):
        """aget_tuple finds exact scope when checkpoint_id is provided."""
        config = {
            "configurable": {
                "thread_id": "thread-001",
                "checkpoint_ns": "",
                "checkpoint_id": "scope-specific",
            }
        }
        mock_client.trajectories.list_scopes.return_value = [
            {
                "scope_id": "scope-other",
                "is_active": True,
                "metadata": {"checkpoint_ns": ""},
            },
            {
                "scope_id": "scope-specific",
                "is_active": True,
                "created_at": "2025-01-01T00:00:00Z",
                "metadata": {"checkpoint_ns": ""},
            },
        ]
        mock_client.artifacts.list.return_value = {"artifacts": []}

        result = await checkpointer.aget_tuple(config)

        assert result is not None
        assert result.config["configurable"]["checkpoint_id"] == "scope-specific"

    @pytest.mark.asyncio
    async def test_aget_tuple_handles_not_found(self, checkpointer, config, mock_client):
        """aget_tuple returns None when trajectory is not found."""
        from cellstate.http import NotFoundError

        mock_client.trajectories.list_scopes.side_effect = NotFoundError()
        result = await checkpointer.aget_tuple(config)
        assert result is None

    # -- aget ---------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_aget_returns_none_when_empty(self, checkpointer, config, mock_client):
        """aget returns None when no checkpoint exists."""
        mock_client.trajectories.list_scopes.return_value = []
        result = await checkpointer.aget(config)
        assert result is None

    # -- aput ---------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_aput_creates_scope_and_artifacts(self, checkpointer, config, mock_client):
        """aput creates a scope and stores each channel as a separate artifact."""
        mock_client.trajectories.get.return_value = {"trajectory_id": "thread-001"}
        mock_client.scopes.create.return_value = {"scope_id": "scope-new"}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-001"}

        checkpoint = {
            "id": "cp-001",
            "channel_values": {"messages": ["hi"], "counter": 5},
            "channel_versions": {"messages": 1, "counter": 1},
            "versions_seen": {},
            "pending_sends": [],
        }
        metadata = {"source": "update", "step": 0}

        result = await checkpointer.aput(config, checkpoint, metadata)

        assert result["configurable"]["checkpoint_id"] == "scope-new"
        assert result["configurable"]["thread_id"] == "thread-001"

        # Should create scope + 2 channel artifacts + 1 channel_versions artifact
        assert mock_client.scopes.create.call_count == 1
        # messages + counter + __channel_versions__ = 3 artifact creates
        assert mock_client.artifacts.create.call_count == 3

    @pytest.mark.asyncio
    async def test_aput_stores_pending_sends(self, checkpointer, config, mock_client):
        """aput stores pending_sends as an artifact when present."""
        mock_client.trajectories.get.return_value = {"trajectory_id": "thread-001"}
        mock_client.scopes.create.return_value = {"scope_id": "scope-new"}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-001"}

        checkpoint = {
            "id": "cp-001",
            "channel_values": {},
            "channel_versions": {},
            "pending_sends": [{"value": "pending-msg"}],
        }
        metadata = {"source": "update", "step": 1}

        await checkpointer.aput(config, checkpoint, metadata)

        # __pending_sends__ artifact should be created
        calls = mock_client.artifacts.create.call_args_list
        names = [c.kwargs.get("name") or c.args[4] if len(c.args) > 4 else c.kwargs.get("name", "") for c in calls]
        # At least __pending_sends__ should be in the names
        artifact_names = [c.kwargs.get("name") for c in calls]
        assert "__pending_sends__" in artifact_names

    # -- aput_writes --------------------------------------------------------

    @pytest.mark.asyncio
    async def test_aput_writes_stores_pending_writes(self, checkpointer, mock_client):
        """aput_writes stores each write as a separate artifact."""
        config = {
            "configurable": {
                "thread_id": "thread-001",
                "checkpoint_id": "scope-001",
            }
        }
        mock_client.artifacts.create.return_value = {"artifact_id": "art-001"}

        writes = [("messages", "hello"), ("counter", 42)]
        await checkpointer.aput_writes(config, writes, task_id="task-001")

        assert mock_client.artifacts.create.call_count == 2
        # Verify names contain the task_id prefix
        for i, call in enumerate(mock_client.artifacts.create.call_args_list):
            assert call.kwargs["name"] == f"__pending_write__task-001_{i}"
            assert call.kwargs["scope_id"] == "scope-001"

    @pytest.mark.asyncio
    async def test_aput_writes_skips_without_checkpoint_id(self, checkpointer, config, mock_client):
        """aput_writes does nothing when no checkpoint_id is in config."""
        writes = [("messages", "hello")]
        await checkpointer.aput_writes(config, writes, task_id="task-001")
        mock_client.artifacts.create.assert_not_called()

    # -- alist --------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_alist_yields_checkpoint_tuples(self, checkpointer, config, mock_client):
        """alist yields CheckpointTuples in reverse chronological order."""
        mock_client.trajectories.list_scopes.return_value = [
            {
                "scope_id": "scope-001",
                "is_active": False,
                "created_at": "2025-01-01T00:00:00Z",
                "metadata": {"checkpoint_ns": ""},
            },
            {
                "scope_id": "scope-002",
                "is_active": True,
                "created_at": "2025-01-02T00:00:00Z",
                "metadata": {"checkpoint_ns": ""},
            },
        ]
        mock_client.artifacts.list.return_value = {"artifacts": []}

        results = []
        async for item in checkpointer.alist(config):
            results.append(item)

        assert len(results) == 2
        # Should be newest first
        assert results[0].config["configurable"]["checkpoint_id"] == "scope-002"
        assert results[1].config["configurable"]["checkpoint_id"] == "scope-001"

    @pytest.mark.asyncio
    async def test_alist_with_limit(self, checkpointer, config, mock_client):
        """alist respects the limit parameter."""
        mock_client.trajectories.list_scopes.return_value = [
            {"scope_id": f"scope-{i}", "is_active": True, "created_at": f"2025-01-0{i}T00:00:00Z", "metadata": {"checkpoint_ns": ""}}
            for i in range(1, 6)
        ]
        mock_client.artifacts.list.return_value = {"artifacts": []}

        results = []
        async for item in checkpointer.alist(config, limit=2):
            results.append(item)

        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_alist_handles_not_found(self, checkpointer, config, mock_client):
        """alist returns empty when trajectory is not found."""
        from cellstate.http import NotFoundError

        mock_client.trajectories.list_scopes.side_effect = NotFoundError()
        results = []
        async for item in checkpointer.alist(config):
            results.append(item)
        assert len(results) == 0

    # -- serialization roundtrip --------------------------------------------

    def test_serialize_deserialize_roundtrip(self):
        """Values survive the serialize/deserialize cycle."""
        from cellstate.adapters.langgraph import _deserialize_value, _serialize_value

        test_values = [
            42,
            3.14,
            "hello",
            True,
            None,
            [1, 2, 3],
            {"key": "value", "nested": {"a": 1}},
        ]
        for value in test_values:
            serialized = _serialize_value(value)
            deserialized = _deserialize_value(serialized)
            assert deserialized == value, f"Roundtrip failed for {value!r}"

    # -- config extraction --------------------------------------------------

    def test_thread_id_extraction(self, checkpointer):
        """_thread_id extracts thread_id from config."""
        config = {"configurable": {"thread_id": "t-123"}}
        assert checkpointer._thread_id(config) == "t-123"

    def test_thread_id_raises_without_configurable(self, checkpointer):
        """_thread_id raises ValueError for missing thread_id."""
        with pytest.raises(ValueError, match="thread_id"):
            checkpointer._thread_id({"configurable": {}})

    def test_checkpoint_ns_defaults_to_empty(self, checkpointer):
        """_checkpoint_ns returns empty string when not present."""
        assert checkpointer._checkpoint_ns({}) == ""
        assert checkpointer._checkpoint_ns({"configurable": {}}) == ""


# ============================================================================
# CellstateMemoryStore tests
# ============================================================================


class TestCellstateMemoryStore:
    """Tests for the LangMem CellstateMemoryStore adapter."""

    @pytest.fixture
    def mock_client(self):
        return _make_mock_client()

    @pytest.fixture
    def store(self, mock_client):
        from cellstate.adapters.langmem import CellstateMemoryStore

        s = CellstateMemoryStore.__new__(CellstateMemoryStore)
        s.client = mock_client
        s._default_note_type = "Fact"
        s._default_namespace = ""
        s._default_abstraction_level = "Raw"
        return s

    # -- add_memory ---------------------------------------------------------

    @pytest.mark.asyncio
    async def test_add_memory_creates_note(self, store, mock_client):
        """add_memory creates a CELLSTATE note with proper fields."""
        mock_client.notes.create.return_value = {"note_id": "note-001"}

        result = await store.add_memory("User prefers dark mode")

        assert result == "note-001"
        mock_client.notes.create.assert_called_once()
        call_kwargs = mock_client.notes.create.call_args.kwargs
        assert call_kwargs["note_type"] == "Fact"
        assert call_kwargs["content"] == "User prefers dark mode"

    @pytest.mark.asyncio
    async def test_add_memory_with_namespace(self, store, mock_client):
        """add_memory stores namespace in metadata."""
        mock_client.notes.create.return_value = {"note_id": "note-001"}

        await store.add_memory(
            "Likes Python",
            namespace="preferences",
            note_type="Convention",
        )

        call_kwargs = mock_client.notes.create.call_args.kwargs
        assert call_kwargs["note_type"] == "Convention"
        meta = call_kwargs["metadata"]
        assert meta["namespace"] == "preferences"

    @pytest.mark.asyncio
    async def test_add_memory_truncates_title(self, store, mock_client):
        """add_memory truncates long content for the title."""
        mock_client.notes.create.return_value = {"note_id": "note-001"}
        long_content = "x" * 200

        await store.add_memory(long_content)

        call_kwargs = mock_client.notes.create.call_args.kwargs
        assert len(call_kwargs["title"]) <= 80

    # -- search_memories ----------------------------------------------------

    @pytest.mark.asyncio
    async def test_search_memories_returns_entries(self, store, mock_client):
        """search_memories returns MemoryEntry objects."""
        mock_client.notes.search.return_value = {
            "results": [
                {
                    "note": {
                        "note_id": "note-001",
                        "content": "User likes dark mode",
                        "note_type": "Fact",
                        "metadata": {"namespace": "prefs"},
                        "created_at": "2025-01-01T00:00:00Z",
                        "updated_at": "2025-01-01T00:00:00Z",
                        "abstraction_level": "Raw",
                    },
                    "score": 0.95,
                },
            ]
        }

        results = await store.search_memories("dark mode")

        assert len(results) == 1
        assert results[0].memory_id == "note-001"
        assert results[0].score == 0.95
        assert results[0].namespace == "prefs"

    @pytest.mark.asyncio
    async def test_search_memories_filters_by_namespace(self, store, mock_client):
        """search_memories filters results by namespace."""
        mock_client.notes.search.return_value = {
            "results": [
                {
                    "note": {
                        "note_id": "note-001",
                        "content": "Match",
                        "metadata": {"namespace": "ns-a"},
                    },
                    "score": 0.9,
                },
                {
                    "note": {
                        "note_id": "note-002",
                        "content": "No match",
                        "metadata": {"namespace": "ns-b"},
                    },
                    "score": 0.8,
                },
            ]
        }

        results = await store.search_memories("query", namespace="ns-a")
        assert len(results) == 1
        assert results[0].memory_id == "note-001"

    @pytest.mark.asyncio
    async def test_search_memories_skips_none_notes(self, store, mock_client):
        """search_memories skips results with None note."""
        mock_client.notes.search.return_value = {
            "results": [
                {"note": None, "score": 0.5},
            ]
        }
        results = await store.search_memories("query")
        assert len(results) == 0

    # -- get_context --------------------------------------------------------

    @pytest.mark.asyncio
    async def test_get_context_returns_formatted_string(self, store, mock_client):
        """get_context returns a formatted string of memories."""
        mock_client.notes.search.return_value = {
            "results": [
                {
                    "note": {
                        "note_id": "n1",
                        "content": "User prefers dark mode",
                        "metadata": {},
                    },
                    "score": 0.9,
                },
                {
                    "note": {
                        "note_id": "n2",
                        "content": "User uses Python",
                        "metadata": {},
                    },
                    "score": 0.8,
                },
            ]
        }

        result = await store.get_context("user preferences")

        assert "User prefers dark mode" in result
        assert "User uses Python" in result
        assert result.startswith("- ")

    @pytest.mark.asyncio
    async def test_get_context_respects_token_budget(self, store, mock_client):
        """get_context truncates when token budget is exceeded."""
        mock_client.notes.search.return_value = {
            "results": [
                {
                    "note": {"note_id": f"n{i}", "content": "x" * 100, "metadata": {}},
                    "score": 0.9,
                }
                for i in range(10)
            ]
        }

        result = await store.get_context("query", max_tokens=10)
        # 10 tokens * 4 chars = 40 char budget; each line is ~100 chars + "- "
        # Should truncate to 0 full lines (since each is >40 chars)
        lines = result.strip().split("\n") if result.strip() else []
        assert len(lines) <= 1

    @pytest.mark.asyncio
    async def test_get_context_empty_when_no_memories(self, store, mock_client):
        """get_context returns empty string when no memories found."""
        mock_client.notes.search.return_value = {"results": []}
        result = await store.get_context("query")
        assert result == ""

    # -- update_memory ------------------------------------------------------

    @pytest.mark.asyncio
    async def test_update_memory_standard(self, store, mock_client):
        """update_memory updates note content and title."""
        mock_client.notes.get.return_value = {
            "note_id": "note-001",
            "content": "old content",
            "note_type": "Fact",
            "metadata": {"namespace": "prefs"},
        }
        mock_client.notes.update.return_value = {
            "note_id": "note-001",
            "content": "new content",
            "note_type": "Fact",
            "metadata": {"namespace": "prefs"},
        }

        result = await store.update_memory("note-001", "new content")

        assert result.content == "new content"
        mock_client.notes.update.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_memory_with_contradiction_detection(self, store, mock_client):
        """update_memory creates new note when contradiction is detected."""
        mock_client.notes.get.return_value = {
            "note_id": "note-001",
            "content": "User prefers dark mode",
            "note_type": "Fact",
            "metadata": {},
            "abstraction_level": "Raw",
        }
        mock_client.notes.create.return_value = {
            "note_id": "note-002",
            "content": "User switched to light mode",
            "note_type": "Fact",
            "metadata": {"supersedes": "note-001"},
        }

        result = await store.update_memory(
            "note-001",
            "User switched to light mode",
            detect_contradiction=True,
        )

        assert result.memory_id == "note-002"
        mock_client.notes.create.assert_called_once()
        # Old note should NOT be updated
        mock_client.notes.update.assert_not_called()

    @pytest.mark.asyncio
    async def test_update_memory_no_change(self, store, mock_client):
        """update_memory returns existing note when no fields to update."""
        existing = {
            "note_id": "note-001",
            "content": "content",
            "note_type": "Fact",
            "metadata": {},
        }
        mock_client.notes.get.return_value = existing

        result = await store.update_memory("note-001")
        assert result.memory_id == "note-001"
        mock_client.notes.update.assert_not_called()

    # -- delete_memory ------------------------------------------------------

    @pytest.mark.asyncio
    async def test_delete_memory_calls_delete(self, store, mock_client):
        """delete_memory calls notes.delete."""
        await store.delete_memory("note-001")
        mock_client.notes.delete.assert_called_once_with("note-001")

    @pytest.mark.asyncio
    async def test_delete_memory_raises_not_found(self, store, mock_client):
        """delete_memory raises NotFoundError for missing notes."""
        from cellstate.http import NotFoundError

        mock_client.notes.delete.side_effect = NotFoundError()
        with pytest.raises(NotFoundError):
            await store.delete_memory("nonexistent")

    # -- list_memories ------------------------------------------------------

    @pytest.mark.asyncio
    async def test_list_memories_returns_entries(self, store, mock_client):
        """list_memories returns MemoryEntry objects."""
        mock_client.notes.list.return_value = {
            "notes": [
                {
                    "note_id": "note-001",
                    "content": "Memory 1",
                    "note_type": "Fact",
                    "metadata": {},
                },
                {
                    "note_id": "note-002",
                    "content": "Memory 2",
                    "note_type": "Convention",
                    "metadata": {"namespace": "ns-a"},
                },
            ]
        }

        results = await store.list_memories()
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_list_memories_filters_namespace(self, store, mock_client):
        """list_memories filters by namespace."""
        mock_client.notes.list.return_value = {
            "notes": [
                {"note_id": "n1", "content": "a", "metadata": {"namespace": "ns-a"}},
                {"note_id": "n2", "content": "b", "metadata": {"namespace": "ns-b"}},
            ]
        }

        results = await store.list_memories(namespace="ns-a")
        assert len(results) == 1
        assert results[0].memory_id == "n1"

    # -- contradiction detection --------------------------------------------

    def test_contradiction_negation(self):
        """_contents_contradict detects negation patterns."""
        from cellstate.adapters.langmem import _contents_contradict

        assert _contents_contradict("User prefers dark mode", "User does not prefer dark mode")
        assert _contents_contradict("Feature is enabled", "Feature is disabled")
        assert not _contents_contradict("User likes Python", "User likes JavaScript")

    def test_contradiction_change_markers(self):
        """_contents_contradict detects change markers."""
        from cellstate.adapters.langmem import _contents_contradict

        assert _contents_contradict("User prefers dark mode", "User switched to light mode")
        assert _contents_contradict("Uses vim", "Now uses vscode")


# ============================================================================
# CellstateState tests
# ============================================================================


class TestCellstateState:
    """Tests for the PydanticAI CellstateState adapter."""

    @pytest.fixture
    def mock_client(self):
        return _make_mock_client()

    @pytest.fixture
    def state(self, mock_client):
        from cellstate.adapters.pydantic_ai import CellstateState

        s = CellstateState.__new__(CellstateState)
        s.client = mock_client
        s._trajectory_id = "traj-001"
        s._scope_id = "scope-001"
        s._cache = {}
        s._watchers = []
        s._ws_task = None
        return s

    # -- get / set ----------------------------------------------------------

    @pytest.mark.asyncio
    async def test_set_creates_artifact(self, state, mock_client):
        """set() creates an artifact when key does not exist."""
        mock_client.artifacts.list.return_value = {"artifacts": []}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-001"}

        await state.set("color", "blue")

        mock_client.artifacts.create.assert_called_once()
        call_kwargs = mock_client.artifacts.create.call_args.kwargs
        assert call_kwargs["name"] == "color"
        assert json.loads(call_kwargs["content"]) == "blue"

    @pytest.mark.asyncio
    async def test_set_updates_existing_artifact(self, state, mock_client):
        """set() updates an existing artifact when key exists."""
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "color", "artifact_id": "art-001", "superseded_by": None, "content": '"red"'},
            ]
        }
        mock_client.artifacts.update.return_value = {"artifact_id": "art-001"}

        await state.set("color", "blue")

        mock_client.artifacts.update.assert_called_once()
        assert mock_client.artifacts.create.call_count == 0

    @pytest.mark.asyncio
    async def test_get_returns_cached_value(self, state, mock_client):
        """get() returns cached value without API call."""
        state._cache["color"] = "blue"

        result = await state.get("color")

        assert result == "blue"
        mock_client.artifacts.list.assert_not_called()

    @pytest.mark.asyncio
    async def test_get_fetches_from_api(self, state, mock_client):
        """get() fetches from API when not cached."""
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "color", "content": '"green"', "superseded_by": None},
            ]
        }

        result = await state.get("color")

        assert result == "green"
        assert state._cache["color"] == "green"

    @pytest.mark.asyncio
    async def test_get_returns_default(self, state, mock_client):
        """get() returns default when key not found."""
        mock_client.artifacts.list.return_value = {"artifacts": []}

        result = await state.get("missing", default="fallback")
        assert result == "fallback"

    # -- delete -------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_delete_removes_artifact(self, state, mock_client):
        """delete() removes the artifact and clears cache."""
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "color", "artifact_id": "art-001", "superseded_by": None},
            ]
        }
        state._cache["color"] = "blue"

        result = await state.delete("color")

        assert result is True
        mock_client.artifacts.delete.assert_called_once_with("art-001")
        assert "color" not in state._cache

    @pytest.mark.asyncio
    async def test_delete_returns_false_when_not_found(self, state, mock_client):
        """delete() returns False when key does not exist."""
        mock_client.artifacts.list.return_value = {"artifacts": []}

        result = await state.delete("missing")
        assert result is False

    # -- keys ---------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_keys_lists_artifact_names(self, state, mock_client):
        """keys() returns list of active artifact names."""
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "color", "superseded_by": None},
                {"name": "theme", "superseded_by": None},
                {"name": "old", "superseded_by": "art-new"},
            ]
        }

        result = await state.keys()

        assert set(result) == {"color", "theme"}

    # -- items --------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_items_returns_all_state(self, state, mock_client):
        """items() returns all key-value pairs."""
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "a", "content": "1", "superseded_by": None},
                {"name": "b", "content": '"hello"', "superseded_by": None},
            ]
        }

        result = await state.items()
        assert result == {"a": 1, "b": "hello"}

    # -- snapshot -----------------------------------------------------------

    @pytest.mark.asyncio
    async def test_snapshot_creates_checkpoint_and_scope(self, state, mock_client):
        """snapshot() creates a checkpoint and child scope with artifacts."""
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "key1", "content": '"val1"', "superseded_by": None},
            ]
        }
        mock_client.scopes.checkpoint.return_value = {}
        mock_client.scopes.create.return_value = {"scope_id": "snap-001"}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-001"}

        result = await state.snapshot("test-snap")

        assert result == "snap-001"
        mock_client.scopes.checkpoint.assert_called_once()
        mock_client.scopes.create.assert_called_once()
        # Should copy 1 artifact into snapshot scope
        mock_client.artifacts.create.assert_called_once()

    # -- restore ------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_restore_replays_artifacts(self, state, mock_client):
        """restore() replays snapshot artifacts into active scope."""
        # Current state has "color" and "theme"
        mock_client.artifacts.list.side_effect = [
            # First call: snapshot artifacts
            {
                "artifacts": [
                    {"name": "color", "content": '"red"', "superseded_by": None},
                    {"name": "size", "content": "42", "superseded_by": None},
                ]
            },
            # Second call: current keys (for delete check)
            {
                "artifacts": [
                    {"name": "color", "superseded_by": None},
                    {"name": "theme", "superseded_by": None, "artifact_id": "art-theme"},
                ]
            },
            # Third call: finding theme artifact for delete
            {
                "artifacts": [
                    {"name": "theme", "superseded_by": None, "artifact_id": "art-theme"},
                ]
            },
            # Subsequent calls for set operations
            {"artifacts": [{"name": "color", "content": '"blue"', "superseded_by": None, "artifact_id": "art-color"}]},
            {"artifacts": []},
        ]
        mock_client.artifacts.create.return_value = {"artifact_id": "art-new"}
        mock_client.artifacts.update.return_value = {"artifact_id": "art-color"}

        result = await state.restore("snap-001")

        assert "color" in result
        assert "size" in result

    # -- watchers -----------------------------------------------------------

    @pytest.mark.asyncio
    async def test_on_change_notifies_watchers(self, state, mock_client):
        """on_change callback fires on set()."""
        mock_client.artifacts.list.return_value = {"artifacts": []}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-001"}

        changes: list[dict[str, Any]] = []
        state.on_change(lambda c: changes.append(c.to_dict()))

        await state.set("key", "value")

        assert len(changes) == 1
        assert changes[0]["key"] == "key"
        assert changes[0]["value"] == "value"
        assert changes[0]["operation"] == "set"

    def test_on_change_unsubscribe(self, state):
        """on_change returns an unsubscribe function."""
        callback = MagicMock()
        unsub = state.on_change(callback)

        assert callback in state._watchers
        unsub()
        assert callback not in state._watchers

    # -- ensure_scope -------------------------------------------------------

    @pytest.mark.asyncio
    async def test_ensure_scope_creates_when_none(self, state, mock_client):
        """_ensure_scope creates a new scope when scope_id is None."""
        state._scope_id = None
        mock_client.scopes.create.return_value = {"scope_id": "new-scope"}

        result = await state._ensure_scope()

        assert result == "new-scope"
        assert state._scope_id == "new-scope"

    @pytest.mark.asyncio
    async def test_ensure_scope_returns_existing(self, state, mock_client):
        """_ensure_scope returns existing scope_id without API call."""
        result = await state._ensure_scope()

        assert result == "scope-001"
        mock_client.scopes.create.assert_not_called()


# ============================================================================
# CellstateMastraWorkflow tests
# ============================================================================


class TestCellstateMastraWorkflow:
    """Tests for the Mastra CellstateMastraWorkflow adapter."""

    @pytest.fixture
    def mock_client(self):
        return _make_mock_client()

    @pytest.fixture
    def workflow(self, mock_client):
        from cellstate.adapters.mastra import CellstateMastraWorkflow

        w = CellstateMastraWorkflow.__new__(CellstateMastraWorkflow)
        w.client = mock_client
        w._step_scopes = {}
        return w

    # -- start --------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_start_creates_trajectory(self, workflow, mock_client):
        """start() creates a CELLSTATE trajectory for the workflow."""
        mock_client.trajectories.create.return_value = {"trajectory_id": "wf-001"}

        result = await workflow.start("data-pipeline")

        assert result == "wf-001"
        mock_client.trajectories.create.assert_called_once()
        call_kwargs = mock_client.trajectories.create.call_args.kwargs
        assert call_kwargs["name"] == "data-pipeline"
        assert call_kwargs["metadata"]["adapter"] == "mastra"

    # -- execute_step -------------------------------------------------------

    @pytest.mark.asyncio
    async def test_execute_step_creates_scope(self, workflow, mock_client):
        """execute_step creates a scope and stores input artifact."""
        mock_client.scopes.create.return_value = {"scope_id": "step-scope-001"}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-001"}

        result = await workflow.execute_step(
            "wf-001", "fetch-data",
            input_data={"url": "https://example.com"},
        )

        assert result.step_name == "fetch-data"
        assert result.scope_id == "step-scope-001"
        assert result.status == "running"
        mock_client.scopes.create.assert_called_once()
        mock_client.artifacts.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_execute_step_without_input(self, workflow, mock_client):
        """execute_step works without input_data."""
        mock_client.scopes.create.return_value = {"scope_id": "step-scope-001"}

        result = await workflow.execute_step("wf-001", "validate")

        assert result.step_name == "validate"
        mock_client.artifacts.create.assert_not_called()

    @pytest.mark.asyncio
    async def test_execute_step_with_parent(self, workflow, mock_client):
        """execute_step links to parent step scope."""
        workflow._step_scopes["wf-001"] = {"parent-step": "parent-scope"}
        mock_client.scopes.create.return_value = {"scope_id": "child-scope"}

        await workflow.execute_step(
            "wf-001", "child-step", parent_step="parent-step",
        )

        call_kwargs = mock_client.scopes.create.call_args.kwargs
        assert call_kwargs["parent_scope_id"] == "parent-scope"

    # -- complete_step ------------------------------------------------------

    @pytest.mark.asyncio
    async def test_complete_step_stores_output(self, workflow, mock_client):
        """complete_step stores output artifact and updates scope metadata."""
        workflow._step_scopes["wf-001"] = {"process": "scope-process"}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-out"}
        mock_client.scopes.update.return_value = {}
        mock_client.artifacts.list.return_value = {"artifacts": []}

        result = await workflow.complete_step(
            "wf-001", "process",
            output_data={"result": "done"},
            status="completed",
        )

        assert result.status == "completed"
        assert result.output_data == {"result": "done"}

    @pytest.mark.asyncio
    async def test_complete_step_raises_for_unknown_step(self, workflow):
        """complete_step raises when step not found."""
        from cellstate.http import CellstateError

        with pytest.raises(CellstateError, match="not found"):
            await workflow.complete_step("wf-001", "unknown-step")

    # -- store_tool_result --------------------------------------------------

    @pytest.mark.asyncio
    async def test_store_tool_result(self, workflow, mock_client):
        """store_tool_result creates an artifact with tool metadata."""
        workflow._step_scopes["wf-001"] = {"fetch": "scope-fetch"}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-tool"}

        result = await workflow.store_tool_result(
            "wf-001", "fetch",
            tool_name="http_get",
            result={"status": 200},
        )

        assert result == "art-tool"
        call_kwargs = mock_client.artifacts.create.call_args.kwargs
        assert call_kwargs["metadata"]["tool_name"] == "http_get"

    # -- get_state ----------------------------------------------------------

    @pytest.mark.asyncio
    async def test_get_state_aggregates_steps(self, workflow, mock_client):
        """get_state returns aggregated state across all steps."""
        mock_client.trajectories.list_scopes.return_value = [
            {
                "scope_id": "scope-a",
                "name": "step-fetch",
                "metadata": {"step_name": "fetch", "step_status": "completed"},
            },
        ]
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {
                    "name": "step-input-fetch",
                    "content": '{"url": "https://example.com"}',
                    "superseded_by": None,
                    "metadata": {"artifact_role": "input"},
                },
                {
                    "name": "step-output-fetch",
                    "content": '{"data": "result"}',
                    "superseded_by": None,
                    "metadata": {"artifact_role": "output"},
                },
            ]
        }

        state = await workflow.get_state("wf-001")

        assert "fetch" in state["steps"]
        assert state["steps"]["fetch"]["status"] == "completed"
        assert state["steps"]["fetch"]["input"] == {"url": "https://example.com"}
        assert state["steps"]["fetch"]["output"] == {"data": "result"}

    # -- complete -----------------------------------------------------------

    @pytest.mark.asyncio
    async def test_complete_closes_scopes(self, workflow, mock_client):
        """complete() closes all active scopes and updates trajectory."""
        workflow._step_scopes["wf-001"] = {"step1": "scope-1"}
        mock_client.trajectories.list_scopes.return_value = [
            {"scope_id": "scope-1", "is_active": True},
            {"scope_id": "scope-2", "is_active": False},
        ]
        mock_client.trajectories.update.return_value = {"trajectory_id": "wf-001"}

        await workflow.complete("wf-001", outcome="success")

        mock_client.scopes.close.assert_called_once_with("scope-1")
        mock_client.trajectories.update.assert_called_once()
        assert "wf-001" not in workflow._step_scopes


# ============================================================================
# CellstateCrewMemory tests
# ============================================================================


class TestCellstateCrewMemory:
    """Tests for the CrewAI CellstateCrewMemory adapter."""

    @pytest.fixture
    def mock_client(self):
        return _make_mock_client()

    @pytest.fixture
    def memory(self, mock_client):
        from cellstate.adapters.crewai import CellstateCrewMemory

        m = CellstateCrewMemory.__new__(CellstateCrewMemory)
        m.client = mock_client
        m._scope_map = {}
        return m

    # -- init_crew ----------------------------------------------------------

    @pytest.mark.asyncio
    async def test_init_crew_creates_trajectory_and_scopes(self, memory, mock_client):
        """init_crew creates trajectory + shared scope + agent scopes."""
        mock_client.trajectories.create.return_value = {"trajectory_id": "crew-001"}
        scope_counter = {"i": 0}

        def make_scope(**kwargs):
            scope_counter["i"] += 1
            return {"scope_id": f"scope-{scope_counter['i']}"}

        mock_client.scopes.create.side_effect = make_scope

        result = await memory.init_crew("research-crew", agents=["researcher", "writer"])

        assert result == "crew-001"
        # 1 shared + 2 agents = 3 scopes
        assert mock_client.scopes.create.call_count == 3
        assert "__shared__" in memory._scope_map["crew-001"]
        assert "researcher" in memory._scope_map["crew-001"]
        assert "writer" in memory._scope_map["crew-001"]

    # -- store_agent_memory -------------------------------------------------

    @pytest.mark.asyncio
    async def test_store_agent_memory_creates_artifact(self, memory, mock_client):
        """store_agent_memory creates an artifact in the agent's scope."""
        memory._scope_map["crew-001"] = {"agent-a": "scope-a"}
        mock_client.artifacts.list.return_value = {"artifacts": []}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-001"}

        result = await memory.store_agent_memory(
            "crew-001", "agent-a", "findings", {"topic": "AI"},
        )

        assert result == "art-001"
        call_kwargs = mock_client.artifacts.create.call_args.kwargs
        assert call_kwargs["scope_id"] == "scope-a"
        assert call_kwargs["name"] == "findings"

    @pytest.mark.asyncio
    async def test_store_agent_memory_updates_existing(self, memory, mock_client):
        """store_agent_memory updates existing artifact with same key."""
        memory._scope_map["crew-001"] = {"agent-a": "scope-a"}
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "findings", "artifact_id": "art-old", "superseded_by": None},
            ]
        }
        mock_client.artifacts.update.return_value = {"artifact_id": "art-old"}

        result = await memory.store_agent_memory(
            "crew-001", "agent-a", "findings", {"topic": "ML"},
        )

        assert result == "art-old"
        mock_client.artifacts.update.assert_called_once()
        mock_client.artifacts.create.assert_not_called()

    # -- get_agent_memory ---------------------------------------------------

    @pytest.mark.asyncio
    async def test_get_agent_memory_returns_all(self, memory, mock_client):
        """get_agent_memory returns all memory for an agent."""
        memory._scope_map["crew-001"] = {"agent-a": "scope-a"}
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "findings", "content": '{"topic": "AI"}', "superseded_by": None},
                {"name": "queries", "content": '["q1", "q2"]', "superseded_by": None},
            ]
        }

        result = await memory.get_agent_memory("crew-001", "agent-a")

        assert result == {
            "findings": {"topic": "AI"},
            "queries": ["q1", "q2"],
        }

    @pytest.mark.asyncio
    async def test_get_agent_memory_filters_by_key(self, memory, mock_client):
        """get_agent_memory filters by specific key."""
        memory._scope_map["crew-001"] = {"agent-a": "scope-a"}
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "findings", "content": '{"topic": "AI"}', "superseded_by": None},
                {"name": "other", "content": '"data"', "superseded_by": None},
            ]
        }

        result = await memory.get_agent_memory("crew-001", "agent-a", key="findings")
        assert result == {"findings": {"topic": "AI"}}

    # -- delete_agent_memory ------------------------------------------------

    @pytest.mark.asyncio
    async def test_delete_agent_memory(self, memory, mock_client):
        """delete_agent_memory deletes the artifact."""
        memory._scope_map["crew-001"] = {"agent-a": "scope-a"}
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "findings", "artifact_id": "art-001", "superseded_by": None},
            ]
        }

        result = await memory.delete_agent_memory("crew-001", "agent-a", "findings")

        assert result is True
        mock_client.artifacts.delete.assert_called_once_with("art-001")

    @pytest.mark.asyncio
    async def test_delete_agent_memory_not_found(self, memory, mock_client):
        """delete_agent_memory returns False when key not found."""
        memory._scope_map["crew-001"] = {"agent-a": "scope-a"}
        mock_client.artifacts.list.return_value = {"artifacts": []}

        result = await memory.delete_agent_memory("crew-001", "agent-a", "missing")
        assert result is False

    # -- shared memory ------------------------------------------------------

    @pytest.mark.asyncio
    async def test_store_shared(self, memory, mock_client):
        """store_shared creates a crew-level artifact."""
        memory._scope_map["crew-001"] = {"__shared__": "scope-shared"}
        mock_client.artifacts.list.return_value = {"artifacts": []}
        mock_client.artifacts.create.return_value = {"artifact_id": "art-shared"}

        result = await memory.store_shared("crew-001", "brief", "Build AI agent")

        assert result == "art-shared"
        call_kwargs = mock_client.artifacts.create.call_args.kwargs
        assert call_kwargs["scope_id"] == "scope-shared"

    @pytest.mark.asyncio
    async def test_get_shared(self, memory, mock_client):
        """get_shared returns crew-level artifacts."""
        memory._scope_map["crew-001"] = {"__shared__": "scope-shared"}
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "brief", "content": '"Build AI agent"', "superseded_by": None},
            ]
        }

        result = await memory.get_shared("crew-001")
        assert result == {"brief": "Build AI agent"}

    @pytest.mark.asyncio
    async def test_delete_shared(self, memory, mock_client):
        """delete_shared deletes a crew-level artifact."""
        memory._scope_map["crew-001"] = {"__shared__": "scope-shared"}
        mock_client.artifacts.list.return_value = {
            "artifacts": [
                {"name": "brief", "artifact_id": "art-001", "superseded_by": None},
            ]
        }

        result = await memory.delete_shared("crew-001", "brief")
        assert result is True

    # -- task results -------------------------------------------------------

    @pytest.mark.asyncio
    async def test_store_task_result(self, memory, mock_client):
        """store_task_result creates a note with crew metadata."""
        mock_client.notes.create.return_value = {"note_id": "note-001"}

        result = await memory.store_task_result(
            "crew-001", "researcher",
            content="Found 5 papers",
            task_name="literature-review",
        )

        assert result == "note-001"
        call_kwargs = mock_client.notes.create.call_args.kwargs
        assert call_kwargs["metadata"]["crew_id"] == "crew-001"
        assert call_kwargs["metadata"]["agent_name"] == "researcher"
        assert call_kwargs["metadata"]["task_name"] == "literature-review"

    @pytest.mark.asyncio
    async def test_get_task_results_filters(self, memory, mock_client):
        """get_task_results filters by crew_id and agent_name."""
        mock_client.notes.list.return_value = {
            "notes": [
                {
                    "note_id": "n1",
                    "content": "Found papers",
                    "note_type": "Fact",
                    "metadata": {
                        "crew_id": "crew-001",
                        "agent_name": "researcher",
                        "task_name": "review",
                    },
                    "created_at": "2025-01-01",
                },
                {
                    "note_id": "n2",
                    "content": "Other crew",
                    "note_type": "Fact",
                    "metadata": {"crew_id": "crew-other"},
                    "created_at": "2025-01-01",
                },
            ]
        }

        results = await memory.get_task_results("crew-001", agent_name="researcher")
        assert len(results) == 1
        assert results[0]["note_id"] == "n1"

    # -- search -------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_search_across_crew(self, memory, mock_client):
        """search returns combined artifact and note results."""
        mock_client.artifacts.search.return_value = {
            "results": [
                {
                    "artifact": {
                        "artifact_id": "art-001",
                        "name": "findings",
                        "content": "AI papers",
                        "metadata": {"agent_name": "researcher"},
                    },
                    "score": 0.9,
                },
            ]
        }
        mock_client.notes.search.return_value = {
            "results": [
                {
                    "note": {
                        "note_id": "note-001",
                        "title": "Task result",
                        "content": "5 papers found",
                        "metadata": {"crew_id": "crew-001", "agent_name": "researcher"},
                    },
                    "score": 0.85,
                },
            ]
        }

        results = await memory.search("crew-001", "AI papers")

        assert len(results) == 2
        # Should be sorted by score
        assert results[0]["score"] >= results[1]["score"]
        types = {r["type"] for r in results}
        assert types == {"artifact", "note"}

    # -- complete_crew ------------------------------------------------------

    @pytest.mark.asyncio
    async def test_complete_crew(self, memory, mock_client):
        """complete_crew closes scopes and updates trajectory."""
        memory._scope_map["crew-001"] = {"__shared__": "scope-s"}
        mock_client.trajectories.list_scopes.return_value = [
            {"scope_id": "scope-s", "is_active": True},
        ]
        mock_client.trajectories.update.return_value = {"trajectory_id": "crew-001"}

        await memory.complete_crew("crew-001")

        mock_client.scopes.close.assert_called_once_with("scope-s")
        mock_client.trajectories.update.assert_called_once()
        assert "crew-001" not in memory._scope_map


# ============================================================================
# Adapter __init__ lazy import tests
# ============================================================================


class TestAdapterLazyImports:
    """Tests that adapter __init__.py lazy imports work correctly."""

    def test_import_checkpointer(self):
        """CellstateCheckpointer can be imported from adapters."""
        from cellstate.adapters import CellstateCheckpointer

        assert CellstateCheckpointer is not None

    def test_import_memory_store(self):
        """CellstateMemoryStore can be imported from adapters."""
        from cellstate.adapters import CellstateMemoryStore

        assert CellstateMemoryStore is not None

    def test_import_state(self):
        """CellstateState can be imported from adapters."""
        from cellstate.adapters import CellstateState

        assert CellstateState is not None

    def test_import_mastra(self):
        """CellstateMastraWorkflow can be imported from adapters."""
        from cellstate.adapters import CellstateMastraWorkflow

        assert CellstateMastraWorkflow is not None

    def test_import_crewai(self):
        """CellstateCrewMemory can be imported from adapters."""
        from cellstate.adapters import CellstateCrewMemory

        assert CellstateCrewMemory is not None

    def test_invalid_import_raises(self):
        """Invalid from-import raises ImportError."""
        with pytest.raises(ImportError):
            from cellstate.adapters import NonexistentAdapter  # noqa: F401

    def test_all_exports(self):
        """__all__ contains all adapter classes."""
        import cellstate.adapters

        assert "CellstateCheckpointer" in cellstate.adapters.__all__
        assert "CellstateMemoryStore" in cellstate.adapters.__all__
        assert "CellstateState" in cellstate.adapters.__all__
        assert "CellstateMastraWorkflow" in cellstate.adapters.__all__
        assert "CellstateCrewMemory" in cellstate.adapters.__all__
