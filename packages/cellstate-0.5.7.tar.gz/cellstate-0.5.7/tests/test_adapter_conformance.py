from __future__ import annotations

import ast
import json
import re
from pathlib import Path
from typing import Any


TEST_ROOT = Path(__file__).resolve().parent
ADAPTER_ROOT = TEST_ROOT.parent / "cellstate" / "adapters"
FIXTURE_PATH = TEST_ROOT / "fixtures" / "adapter_protocol_golden.json"


def _load_fixture() -> dict[str, Any]:
    return json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))


def _adapter_modules() -> list[Path]:
    return sorted(p for p in ADAPTER_ROOT.glob("*.py") if p.name != "__init__.py")


def _public_methods_by_class(tree: ast.AST) -> dict[str, list[str]]:
    class_methods: dict[str, list[str]] = {}
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        methods = [
            item.name
            for item in node.body
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
            and not item.name.startswith("_")
            and item.name not in {"__aenter__", "__aexit__"}
        ]
        if methods:
            class_methods[node.name] = methods
    return class_methods


def _max_function_lines(tree: ast.AST) -> int:
    max_lines = 0
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        end_lineno = getattr(node, "end_lineno", node.lineno)
        max_lines = max(max_lines, end_lineno - node.lineno + 1)
    return max_lines


def _client_managers_used(source: str) -> set[str]:
    return set(re.findall(r"self\.client\.([a-z_]+)\.", source))


def test_adapter_modules_match_conformance_fixture() -> None:
    fixture_modules = sorted(_load_fixture()["modules"].keys())
    source_modules = [module.name for module in _adapter_modules()]
    assert source_modules == fixture_modules


def test_adapter_module_complexity_budgets() -> None:
    fixture = _load_fixture()["modules"]

    for module in _adapter_modules():
        source = module.read_text(encoding="utf-8")
        tree = ast.parse(source)
        budget = fixture[module.name]

        line_count = len(source.splitlines())
        assert line_count <= budget["max_lines"], (
            f"{module.name} exceeds max_lines budget: {line_count} > {budget['max_lines']}"
        )

        longest_function = _max_function_lines(tree)
        assert longest_function <= budget["max_function_lines"], (
            f"{module.name} exceeds max_function_lines budget: "
            f"{longest_function} > {budget['max_function_lines']}"
        )


def test_adapter_public_api_surfaces_match_golden() -> None:
    fixture = _load_fixture()["modules"]

    for module in _adapter_modules():
        source = module.read_text(encoding="utf-8")
        tree = ast.parse(source)
        class_methods = _public_methods_by_class(tree)

        expected_classes = fixture[module.name]["classes"]
        assert set(class_methods.keys()) >= set(expected_classes.keys())

        for class_name, class_spec in expected_classes.items():
            expected_methods = sorted(class_spec["public_methods"])
            actual_methods = sorted(class_methods[class_name])
            assert actual_methods == expected_methods, (
                f"{module.name}:{class_name} public method drift detected. "
                f"Expected {expected_methods}, got {actual_methods}"
            )


def test_adapter_client_manager_usage_matches_golden() -> None:
    fixture = _load_fixture()["modules"]

    for module in _adapter_modules():
        source = module.read_text(encoding="utf-8")
        used_managers = _client_managers_used(source)
        spec = fixture[module.name]

        required = set(spec["required_client_managers"])
        allowed = set(spec["allowed_client_managers"])

        assert required.issubset(used_managers), (
            f"{module.name} missing required client manager usage: "
            f"{sorted(required - used_managers)}"
        )
        assert used_managers.issubset(allowed), (
            f"{module.name} uses managers outside allowed set: "
            f"{sorted(used_managers - allowed)}"
        )
