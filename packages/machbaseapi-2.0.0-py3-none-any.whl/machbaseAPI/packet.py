"""Packet utilities for Machbase binary protocol."""

from __future__ import annotations

import socket
import time
from dataclasses import dataclass
from typing import Deque, List, Optional

from collections import deque


@dataclass
class Packet:
    protocol: int
    flag: int
    adds: int
    stmt_id: int
    body: bytes


class PacketReader:
    HEADER_SIZE = 16

    def __init__(self, sock: socket.socket):
        self._socket = sock
        self._buffer = b""
        self._queue: Deque[Packet] = deque()
        self._closed = False
        self._error: Optional[BaseException] = None

    def next(self, timeout_ms: Optional[int] = None) -> Packet:
        if self._error:
            raise self._error
        if self._queue:
            return self._queue.popleft()

        deadline = None
        if timeout_ms is not None:
            deadline = time.monotonic() + timeout_ms / 1000

        while True:
            if self._queue:
                return self._queue.popleft()
            if self._closed:
                raise ConnectionError("socket closed")
            now = time.monotonic()
            if deadline is not None and now >= deadline:
                raise TimeoutError("timed out waiting packet")

            timeout = None
            if deadline is not None:
                timeout = max(0.0, deadline - now)

            try:
                self._socket.settimeout(timeout)
                chunk = self._socket.recv(65536)
                if not chunk:
                    self._closed = True
                    if not self._queue:
                        raise ConnectionError("connection closed by server")
                    return self._queue.popleft()
                self._buffer += chunk
                self._parse_buffer()
            except TimeoutError as exc:
                raise exc
            except Exception as exc:
                self._error = exc
                raise

    def _parse_buffer(self) -> None:
        while len(self._buffer) >= self.HEADER_SIZE:
            length_field = int.from_bytes(self._buffer[4:8], "big")
            flag = (length_field >> 30) & 0x03
            body_length = length_field & 0x3FFFFFFF
            total_length = self.HEADER_SIZE + body_length
            if len(self._buffer) < total_length:
                return
            header = self._buffer[:self.HEADER_SIZE]
            body = self._buffer[self.HEADER_SIZE : total_length]
            self._buffer = self._buffer[total_length:]

            protocol = header[3]
            adds = int.from_bytes(header[1:3], "big")
            stmt_id = int.from_bytes(header[8:12], "big")
            self._queue.append(Packet(protocol=protocol, flag=flag, adds=adds, stmt_id=stmt_id, body=body))

