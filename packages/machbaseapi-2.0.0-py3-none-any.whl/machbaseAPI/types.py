from __future__ import annotations

import datetime
import ipaddress
from dataclasses import dataclass
from typing import Any

from . import constants as _C


@dataclass(frozen=True)
class AppendType:
    name: str
    spiner_type: int


def spiner_type_from_value(value: Any) -> int:
    if value is None:
        return _C.CMD_VARCHAR_TYPE
    if isinstance(value, bool):
        return _C.CMD_BOOL_TYPE
    if isinstance(value, int):
        if 0 <= value <= 0xFFFF:
            return _C.CMD_UINT16_TYPE
        if -(2 ** 15) <= value <= (2 ** 15) - 1:
            return _C.CMD_INT16_TYPE
        if 0 <= value <= 0xFFFFFFFF:
            return _C.CMD_UINT32_TYPE
        if -(2 ** 31) <= value <= (2 ** 31) - 1:
            return _C.CMD_INT32_TYPE
        if value >= 0:
            return _C.CMD_UINT64_TYPE
        return _C.CMD_INT64_TYPE
    if isinstance(value, float):
        return _C.CMD_FLT64_TYPE
    if isinstance(value, (bytes, bytearray, memoryview)):
        return _C.CMD_BINARY_TYPE
    if isinstance(value, (datetime.datetime, datetime.date)):
        return _C.CMD_DATE_TYPE

    text = str(value)
    if text:
        try:
            addr = ipaddress.ip_address(text)
            return _C.CMD_IPV6_TYPE if addr.version == 6 else _C.CMD_IPV4_TYPE
        except ValueError:
            pass
    return _C.CMD_VARCHAR_TYPE


def spiner_type_from_legacy_sql(sql_type: int) -> int:
    return _C.CMI_APPEND_TYPE_MAP.get(int(sql_type), _C.CMD_VARCHAR_TYPE)
