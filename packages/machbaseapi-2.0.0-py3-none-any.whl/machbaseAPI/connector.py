from __future__ import annotations

import json
import re
from typing import Any, Iterable, List, Optional, Sequence

from .errors import (
    DataError,
    DatabaseError,
    Error,
    IntegrityError,
    InterfaceError,
    NotSupportedError,
    OperationalError,
    ProgrammingError,
    Warning,
)
from .protocol import MachbaseProtocolClient


_SELECT_PREFIX = re.compile(r"^\s*(SELECT|WITH|DESC|DESCRIBE|SHOW)\b", re.IGNORECASE)


def connect(**kwargs: Any) -> "MachbaseConnection":
    return MachbaseConnection(**kwargs)


def _normalize_append_rows(
    rows: Any,
    *,
    strict: bool = False,
) -> List[Sequence[Any]]:
    if rows is None:
        return []
    if isinstance(rows, str):
        raise ProgrammingError("Append rows must be a sequence, not a string.")
    if not isinstance(rows, (list, tuple)):
        raise ProgrammingError("Append rows must be a sequence of rows.")

    normalized = list(rows)
    if len(normalized) == 0:
        return []

    if strict and not isinstance(normalized[0], (list, tuple)):
        raise ProgrammingError("Append rows must be sequence objects when strict mode is enabled.")

    if not isinstance(normalized[0], (list, tuple)):
        return [tuple(normalized)]  # single row

    if any(not isinstance(item, (list, tuple)) for item in normalized):
        if strict:
            raise ProgrammingError("Append rows must be a sequence of sequences when strict mode is enabled.")
        raise ProgrammingError("Mixed append row type is not supported.")

    return [tuple(item) for item in normalized]


class MachbaseConnection:
    _BANNED_POOL_KEYS = {"pool_name", "pool_size", "pool_reset_session"}

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 5656,
        user: str = "SYS",
        password: str = "MANAGER",
        database: str = "data",
        connect_timeout: int = 5,
        query_timeout: int = 60,
        autocommit: bool = True,
        connection_string: str = "",
        client_id: str = "PYMCB",
        **kwargs: Any,
    ):
        for key in self._BANNED_POOL_KEYS:
            if key in kwargs:
                raise NotSupportedError(f"Pooling is not supported. Unsupported option: {key}")
        if kwargs:
            raise InterfaceError(f"Unknown connection option(s): {', '.join(sorted(kwargs.keys()))}")
        if not autocommit:
            raise NotSupportedError("Machbase is auto-commit only.")
        show_hidden = "SHOW_HIDDEN_COLS=1" in connection_string.upper()
        self._client = MachbaseProtocolClient(
            host=host,
            port=int(port),
            user=user,
            password=password,
            database=database,
            timeout_ms=int(connect_timeout) * 1000,
            query_timeout_ms=int(query_timeout) * 1000,
            client_id=client_id,
            show_hidden_columns=show_hidden,
        )
        self._closed = False
        self._result: Any = None
        self._client.connect()

    def close(self) -> None:
        if self._closed:
            return
        self._client.close()
        self._closed = True

    def is_connected(self) -> bool:
        return not self._closed and self._client.connected

    def commit(self) -> None:
        raise NotSupportedError("Machbase transaction APIs are not supported.")

    def rollback(self) -> None:
        raise NotSupportedError("Machbase transaction APIs are not supported.")

    def begin(self) -> None:
        raise NotSupportedError("Machbase transaction APIs are not supported.")

    def cursor(self, dictionary: bool = True, raw: bool = False) -> "MachbaseCursor":
        return MachbaseCursor(self, dictionary=dictionary, raw=raw)

    def execute(self, sql: str, params: Optional[Any] = None) -> "MachbaseCursor":
        cursor = self.cursor()
        cursor.execute(sql, params=params)
        return cursor

    def append(
        self,
        table: str,
        rows: Iterable[Sequence[Any]],
        *,
        types: Optional[Sequence[int]] = None,
        times: Optional[Sequence[Any]] = None,
        date_format: str = "YYYY-MM-DD HH24:MI:SS",
        strict: bool = False,
    ) -> int:
        _ = date_format
        payload = _normalize_append_rows(rows, strict=strict)
        if not payload:
            return 0
        count = self._client.append(table, payload, types=types, times=times)
        self._result = {"table": table, "rows": count}
        return count

    def append_flush(self) -> None:
        return None

    def result(self) -> Any:
        return self._result


class MachbaseCursor:
    def __init__(self, conn: MachbaseConnection, dictionary: bool = True, raw: bool = False):
        self._conn = conn
        self._dictionary = dictionary
        self._raw = raw
        self._rows: List[Any] = []
        self._rowcount = -1
        self._description = None

    def execute(self, operation: str, params: Optional[Any] = None) -> "MachbaseCursor":
        if self._conn._closed:
            raise InterfaceError("Connection is closed.")
        sql = _render_sql(operation, params)
        if _SELECT_PREFIX.match(sql):
            result = self._conn._client.query(sql)
            self._description = tuple((col.name, None, None, None, None, None, None) for col in result.columns)
            if self._raw:
                self._rows = result.rows
            elif self._dictionary:
                self._rows = result.rows
            else:
                self._rows = [tuple(row[col.name] for col in result.columns) for row in result.rows]
            self._rowcount = len(self._rows)
            self._conn._result = result.rows
        else:
            result = self._conn._client.exec_direct(sql)
            self._rows = []
            self._rowcount = result.rows_affected
            self._description = None
            self._conn._result = {"rows_affected": result.rows_affected, "message": result.message}
        return self

    def executemany(self, operation: str, seq_of_params: Iterable[Any]) -> int:
        count = 0
        for params in seq_of_params:
            self.execute(operation, params)
            count += 1
        return count

    def fetchone(self) -> Optional[Any]:
        if not self._rows:
            return None
        return self._rows.pop(0)

    def fetchmany(self, size: int = 1) -> List[Any]:
        out: List[Any] = []
        for _ in range(size):
            row = self.fetchone()
            if row is None:
                break
            out.append(row)
        return out

    def fetchall(self) -> List[Any]:
        rows = list(self._rows)
        self._rows = []
        return rows

    def close(self) -> None:
        self._rows = []

    @property
    def description(self):
        return self._description

    @property
    def rowcount(self) -> int:
        return self._rowcount


def _render_sql(sql: str, params: Optional[Any]) -> str:
    if params is None:
        return sql
    if isinstance(params, dict):
        rendered = sql
        for key, value in params.items():
            rendered = rendered.replace(f"%({key})s", _render_value(value))
        return rendered
    if not isinstance(params, (list, tuple)):
        params = (params,)
    parts = sql.split("%s")
    if len(parts) - 1 != len(params):
        raise ProgrammingError("Parameter count does not match placeholders.")
    chunks: List[str] = []
    for index, part in enumerate(parts[:-1]):
        chunks.append(part)
        chunks.append(_render_value(params[index]))
    chunks.append(parts[-1])
    return "".join(chunks)


def _render_value(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        return "'" + value.replace("'", "''") + "'"
    if isinstance(value, (list, tuple, dict)):
        return "'" + json.dumps(value, ensure_ascii=False).replace("'", "''") + "'"
    return "'" + str(value).replace("'", "''") + "'"
