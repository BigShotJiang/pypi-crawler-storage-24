"""Error hierarchy for the pure-Python Machbase connector."""


class Error(Exception):
    """Base class for all public connector errors."""


class Warning(Error):
    """Warning is kept for compatibility with DB-API style naming."""


class InterfaceError(Error):
    """Invalid public interface usage."""


class DatabaseError(Error):
    """Server-side or protocol error."""


class OperationalError(DatabaseError):
    """Connection / network errors."""


class IntegrityError(DatabaseError):
    """Data integrity violations."""


class DataError(DatabaseError):
    """Data conversion / encoding errors."""


class ProgrammingError(DatabaseError):
    """Invalid arguments or method usage."""


class NotSupportedError(DatabaseError):
    """Unsupported feature requested by caller."""

