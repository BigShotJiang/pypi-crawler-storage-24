from __future__ import annotations

import json
import re
from typing import Any, Callable, Dict, List, Optional, Sequence

from .connector import MachbaseConnection
from .errors import Error, ProgrammingError

gCharset = "UTF-8"
_SELECT_PREFIX = re.compile(r"^\s*(SELECT|WITH|DESC|DESCRIBE|SHOW)\b", re.IGNORECASE)


def _stringify(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (bytes, bytearray, memoryview)):
        value = bytes(value)
        return value.hex().upper()
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() else str(value)
    if isinstance(value, bool):
        return "1" if value else "0"
    return str(value)


def _encode_row(row: Dict[str, Any]) -> str:
    encoded = {str(key).lower(): _stringify(value) for key, value in row.items()}
    if "_arrival_time" in encoded and "_ARRIVAL_TIME" not in encoded:
        encoded["_ARRIVAL_TIME"] = encoded["_arrival_time"]
    return json.dumps(encoded, separators=(",", ":"))


def _encode_rows(rows: Sequence[Dict[str, Any]]) -> str:
    return ",".join(_encode_row(row) for row in rows)


class machbaseAPI(object):
    pass


class machbase(object):
    def __init__(self):
        self._conn: Optional[MachbaseConnection] = None
        self._opened = False
        self._append_session = None
        self._rows: List[Dict[str, Any]] = []
        self._last_result: str = ""
        self._append_types: Optional[List[int]] = None

    def _set_ok(self, text: str) -> int:
        self._last_result = json.dumps({"EXECUTE RESULT": text}, separators=(",", ":"))
        return 1

    def _set_error(self, text: str, detail: str = "") -> int:
        payload = {"EXECUTE ERROR": text}
        if detail:
            payload["MACHBASE_ERROR"] = detail
        self._last_result = json.dumps(payload, separators=(",", ":"))
        return 0

    def _ensure_conn(self) -> MachbaseConnection:
        if self._conn is None:
            raise RuntimeError("Connection is not open")
        return self._conn

    @staticmethod
    def _normalize_append_payload(
        types_or_values: Any,
        explicit_values: Any = None,
    ) -> tuple[Optional[List[int]], List[Sequence[Any]]]:
        if explicit_values is not None:
            if types_or_values is None:
                types = None
            else:
                types = [int(value) for value in types_or_values]
            raw_rows = explicit_values
        else:
            types = None
            raw_rows = types_or_values

        if raw_rows is None:
            return types, []

        if isinstance(raw_rows, (list, tuple)):
            if len(raw_rows) == 0:
                return types, []
            if isinstance(raw_rows[0], (list, tuple)):
                rows = [list(row) for row in raw_rows]
            else:
                rows = [list(raw_rows)]
        else:
            raise ProgrammingError("Append values must be sequence of rows.")

        return types, rows

    def isConnected(self):
        return 1 if self._conn and self._conn.is_connected() else 0

    def isOpened(self):
        return 1 if self._opened else 0

    def open(self, aHost="127.0.0.1", aUser="SYS", aPw="MANAGER", aPort=5656):
        try:
            self._conn = MachbaseConnection(host=aHost, user=aUser.upper(), password=aPw, port=int(aPort))
            self._opened = True
            return 1
        except Exception as exc:
            self._conn = None
            self._opened = False
            return self._set_error("Connection error.", str(exc))

    def openEx(self, aHost="127.0.0.1", aUser="SYS", aPw="MANAGER", aPort=5656, aConnStr=""):
        try:
            self._conn = MachbaseConnection(
                host=aHost,
                user=aUser.upper(),
                password=aPw,
                port=int(aPort),
                connection_string=aConnStr,
            )
            self._opened = True
            return 1
        except Exception as exc:
            self._conn = None
            self._opened = False
            return self._set_error("Connection error.", str(exc))

    def close(self):
        if self._conn is None:
            self._opened = False
            return 1
        try:
            self._conn.close()
            self._opened = False
            self._conn = None
            self._append_session = None
            self._rows = []
            return 1
        except Exception as exc:
            return self._set_error("Connection close error.", str(exc))

    def execute(self, aSql):
        try:
            if _SELECT_PREFIX.match(aSql):
                if self.select(aSql) == 0:
                    return 0
                return 1
            self._ensure_conn()._client.exec_direct(aSql)
            self._rows = []
            return self._set_ok("Execute Success")
        except Exception as exc:
            return self._set_error("SQLPrepare error.", str(exc))

    def select(self, aSql):
        try:
            result = self._ensure_conn()._client.query(aSql)
            self._rows = list(result.rows)
            self._last_result = _encode_rows(self._rows)
            return 1
        except Exception as exc:
            self._rows = []
            return self._set_error("SQLPrepare error.", str(exc))

    def fetch(self):
        if not self._rows:
            return 0, None
        return 1, _encode_row(self._rows.pop(0))

    def selectClose(self):
        self._rows = []
        return 1

    def column(self, aTableName):
        return self.columns(aTableName)

    def statistics(self, aTableName, aUser="SYS"):
        sql = (
            "select name, type, colcount from m$tables "
            "where user_id = (select user_id from m$users where name = '%s') and name = '%s'"
            % (aUser.upper(), aTableName.upper())
        )
        return self.select(sql)

    def schema(self, aSql):
        return self.execute(aSql)

    def tables(self):
        sql = (
            "select t.NAME as name, u.NAME as username, t.COLCOUNT as colcount "
            "from m$sys_tables t, m$sys_users u where u.user_id=t.user_id"
        )
        return self.select(sql)

    def columns(self, aTableName):
        if aTableName is None:
            sql = (
                "select c.name name, c.type type, c.length length "
                "from m$sys_columns c, m$sys_tables t where c.table_id = t.id "
                "and c.id not in(0,65534) order by c.id"
            )
        else:
            name = aTableName.upper()
            if name.startswith("M$"):
                sql = (
                    "select name,type,length from m$columns where table_id = "
                    "(select id from m$tables where name = '%s') and id not in(0,65534) order by id" % name
                )
            elif name.startswith("V$"):
                sql = (
                    "select name,type,length from v$columns where table_id = "
                    "(select id from v$tables where name = '%s') and id not in(0,65534) order by id" % name
                )
            else:
                sql = (
                    "select name,type,length from m$sys_columns where table_id = "
                    "(select id from m$sys_tables where name = '%s') and name not in('_RID','_ARRIVAL_TIME') order by id"
                    % name
                )
        return self.select(sql)

    def appendOpen(self, aTableName, aTypes=None):
        try:
            self._append_session = self._ensure_conn()._client.append_open(aTableName)
            self._append_types = [int(v) for v in aTypes] if aTypes else None
            return 1
        except Exception as exc:
            return self._set_error("Append open error.", str(exc))

    def appendClose(self):
        if self._append_session is None:
            return 0
        try:
            self._ensure_conn()._client.append_close(self._append_session)
            self._append_session = None
            self._append_types = None
            return self._set_ok("Append success")
        except Exception as exc:
            return self._set_error("Append close error.", str(exc))

    def appendData(
        self,
        aTableName,
        aTypes,
        aValues=None,
        aFormat="YYYY-MM-DD HH24:MI:SS",
        on_ack: Optional[Callable[[dict], None]] = None,
    ):
        _ = aTableName, aFormat
        if self._append_session is None:
            return 0
        try:
            types, rows = self._normalize_append_payload(aTypes, aValues)
            self._ensure_conn()._client.append_data(
                self._append_session,
                rows,
                types=types or self._append_types,
                on_ack=on_ack,
            )
            return 1
        except Exception as exc:
            return self._set_error("Append data error.", str(exc))

    def appendDataByTime(
        self,
        aTableName,
        aTypes,
        aValues,
        aFormat="YYYY-MM-DD HH24:MI:SS",
        aTimes=None,
        on_ack: Optional[Callable[[dict], None]] = None,
    ):
        _ = aTableName, aFormat
        if self._append_session is None:
            return 0
        try:
            types, rows = self._normalize_append_payload(aTypes, aValues)
            self._ensure_conn()._client.append_data(
                self._append_session,
                rows,
                types=types or self._append_types,
                times=aTimes,
                on_ack=on_ack,
            )
            return 1
        except Exception as exc:
            return self._set_error("Append data error.", str(exc))

    def appendFlush(self):
        return 1 if self._append_session is not None else 0

    def append(self, aTableName, aTypes, aValues=None, aFormat="YYYY-MM-DD HH24:MI:SS"):
        _ = aFormat
        types, rows = self._normalize_append_payload(aTypes, aValues)
        if not rows:
            return 0
        try:
            count = self._ensure_conn()._client.append(aTableName, rows, types=types)
            self._last_result = json.dumps({"EXECUTE RESULT": "Append success"}, separators=(",", ":"))
            return 1
        except Exception as exc:
            return self._set_error("Append error.", str(exc))

    def appendByTime(self, aTableName, aTypes, aValues=None, aFormat="YYYY-MM-DD HH24:MI:SS", aTimes=None):
        _ = aFormat
        if aValues is None and isinstance(aTypes, (list, tuple)) and aTimes is not None and aTypes and isinstance(aTypes[0], (list, tuple)):
            aValues = aTypes
            aTypes = None
        try:
            types, rows = self._normalize_append_payload(aTypes, aValues)
            count = self._ensure_conn()._client.append(aTableName, rows, types=types, times=aTimes)
            self._last_result = json.dumps({"EXECUTE RESULT": "Append success"}, separators=(",", ":"))
            return 1
        except Exception as exc:
            return self._set_error("Append error.", str(exc))

    def result(self):
        return self._last_result
