# Sample scripts for local testing and migration checks.
