from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Iterator, List, Optional, Union

from .constants import CMI_BINARY_TYPE, CMI_PACKET_MAX_BODY, CMI_ROWS_TYPE, CMI_STRING_TYPE


MarshalPrimitive = Union[int, float, bool, bytes, bytearray, str, None]


@dataclass
class MarshalUnit:
    id: int
    type: int
    length: int
    data: bytes


def _align8(length: int) -> int:
    return (length + 7) & ~7


def _read_u32le(payload: bytes) -> int:
    if len(payload) < 4:
        return 0
    return int.from_bytes(payload[:4], "big")


def _read_fixed_size(type_id: int) -> Optional[int]:
    if type_id in {
        CMI_STRING_TYPE,
        CMI_BINARY_TYPE,
        0x0000000C,
        0x000000F1,
        0x000000F2,
        0x0000000D,
    }:
        return None
    if type_id in {0x00000004, 0x00000005}:
        return 1
    if type_id in {0x00000006, 0x00000007}:  # 16-bit
        return 2
    if type_id in {0x00000008, 0x00000009, 0x00000018, 0x00000019}:  # 32-bit
        return 4
    return 8


def decode_scalar(unit: MarshalUnit) -> MarshalPrimitive:
    if unit.type in {
        CMI_STRING_TYPE,
        0x0000000C,
        0x000000F1,
        0x000000F2,
        0x0000000D,
    }:
        try:
            return unit.data.decode("utf-8")
        except Exception:
            return unit.data.decode("utf-8", errors="replace")
    if unit.type == 0x00000004:
        return unit.data[0] if unit.data else 0
    if unit.type == 0x00000005:
        return unit.data[0] if unit.data else 0
    if unit.type == 0x00000006:
        return int.from_bytes(unit.data[:2], "little", signed=True) if len(unit.data) >= 2 else 0
    if unit.type == 0x00000007:
        return int.from_bytes(unit.data[:2], "little", signed=False) if len(unit.data) >= 2 else 0
    if unit.type == 0x00000008:
        return int.from_bytes(unit.data[:4], "little", signed=True) if len(unit.data) >= 4 else 0
    if unit.type == 0x00000009:
        return int.from_bytes(unit.data[:4], "little", signed=False) if len(unit.data) >= 4 else 0
    if unit.type == 0x0000000A:
        return int.from_bytes(unit.data[:8], "little", signed=True) if len(unit.data) >= 8 else 0
    if unit.type == 0x0000000B:
        return int.from_bytes(unit.data[:8], "little", signed=False) if len(unit.data) >= 8 else 0
    return unit.data


class MarshalWriter:
    """Build marshal units and split them into protocol packets."""

    HEADER_SIZE = 16

    def __init__(self, protocol_id: int, stmt_id: int, adds: int = 0):
        self.protocol_id = protocol_id & 0xFF
        self.stmt_id = stmt_id & 0xFFFFFFFF
        self.adds = adds & 0xFFFF
        self._units: List[bytes] = []
        self._current_length = 0
        self._bodies: List[bytes] = []

    def add_string(self, unit_id: int, value: str) -> None:
        payload = value.encode("utf-8")
        self._add_variable(unit_id, CMI_STRING_TYPE, payload)

    def add_binary(self, unit_id: int, value: Union[bytes, bytearray]) -> None:
        self._add_variable(unit_id, CMI_BINARY_TYPE, bytes(value))

    def add_uint32(self, unit_id: int, value: int) -> None:
        payload = value.to_bytes(4, "little", signed=False)
        self._add_fixed(unit_id, 0x00000009, payload)

    def add_sint32(self, unit_id: int, value: int) -> None:
        payload = value.to_bytes(4, "little", signed=True)
        self._add_fixed(unit_id, 0x00000008, payload)

    def add_uint64(self, unit_id: int, value: int) -> None:
        payload = value.to_bytes(8, "little", signed=False)
        self._add_fixed(unit_id, 0x0000000B, payload)

    def add_sint64(self, unit_id: int, value: int) -> None:
        payload = value.to_bytes(8, "little", signed=True)
        self._add_fixed(unit_id, 0x0000000A, payload)

    def add_boolean(self, unit_id: int, value: bool) -> None:
        payload = b"\x01" if value else b"\x00"
        self._add_fixed(unit_id, 0x00000026, payload)

    def finalize(self) -> List[bytes]:
        self._flush_current()
        if not self._bodies:
            self._bodies = [b""]
        count = len(self._bodies)
        result = []
        for index, body in enumerate(self._bodies):
            if count == 1:
                flag = 0
            elif index == 0:
                flag = 1
            elif index + 1 == count:
                flag = 3
            else:
                flag = 2
            result.append(self._build_packet(body, flag))
        return result

    def _add_variable(self, unit_id: int, type_id: int, payload: bytes) -> None:
        length = _align8(len(payload))
        unit = bytearray(self.HEADER_SIZE + length)
        unit[0:4] = int.to_bytes(unit_id & 0xFFFFFFFF, 4, "little")
        unit[4:8] = int.to_bytes(type_id & 0xFFFFFFFF, 4, "little")
        unit[8:16] = int.to_bytes(len(payload), 8, "little")
        unit[16 : 16 + len(payload)] = payload
        self._enqueue(bytes(unit))

    def _add_fixed(self, unit_id: int, type_id: int, payload: bytes) -> None:
        unit = bytearray(self.HEADER_SIZE)
        unit[0:4] = int.to_bytes(unit_id & 0xFFFFFFFF, 4, "little")
        unit[4:8] = int.to_bytes(type_id & 0xFFFFFFFF, 4, "little")
        fixed = bytes(payload)
        unit[8 : 8 + len(fixed)] = fixed
        self._enqueue(bytes(unit))

    def _enqueue(self, unit: bytes) -> None:
        if len(unit) > CMI_PACKET_MAX_BODY:
            self._flush_current()
            self._bodies.append(unit)
            return
        if self._current_length + len(unit) > CMI_PACKET_MAX_BODY:
            self._flush_current()
        self._units.append(unit)
        self._current_length += len(unit)

    def _flush_current(self) -> None:
        if not self._units:
            self._current_length = 0
            return
        body = b"".join(self._units)
        self._bodies.append(body)
        self._units.clear()
        self._current_length = 0

    def _build_packet(self, body: bytes, flag: int) -> bytes:
        length_with_flag = (flag << 30) | (len(body) & 0x3FFFFFFF)
        header = bytearray(16)
        header[0] = 0
        header[1:3] = self.adds.to_bytes(2, "big")
        header[3] = self.protocol_id & 0xFF
        header[4:8] = length_with_flag.to_bytes(4, "big")
        header[8:12] = self.stmt_id.to_bytes(4, "big")
        return bytes(header) + body


class MarshalReader:
    def __init__(self, payload: bytes):
        self._payload = payload

    def __iter__(self) -> Iterator[MarshalUnit]:
        return self._iter_units()

    def _iter_units(self) -> Iterator[MarshalUnit]:
        offset = 0
        while offset < len(self._payload):
            if offset + 16 > len(self._payload):
                raise ValueError("Incomplete marshal unit header")
            unit_id = int.from_bytes(self._payload[offset : offset + 4], "little")
            type_id = int.from_bytes(self._payload[offset + 4 : offset + 8], "little")
            raw_length = int.from_bytes(self._payload[offset + 8 : offset + 16], "little")
            body_offset = offset + 8

            if type_id in {
                CMI_STRING_TYPE,
                CMI_BINARY_TYPE,
                0x0000000C,
                0x000000F1,
                0x000000F2,
                CMI_ROWS_TYPE,
            }:
                aligned = _align8(raw_length)
                body_offset = offset + 16
                if body_offset + aligned > len(self._payload):
                    raise ValueError("Incomplete variable marshal payload")
                data = self._payload[body_offset : body_offset + raw_length]
                yield MarshalUnit(unit_id, type_id, raw_length, data)
                offset = body_offset + aligned
            else:
                size = _read_fixed_size(type_id)
                if size is None:
                    size = 8
                if body_offset + size > offset + 16:
                    raise ValueError("Incomplete fixed marshal payload")
                data = self._payload[body_offset : body_offset + size]
                yield MarshalUnit(unit_id, type_id, size, data)
                offset = offset + 16
