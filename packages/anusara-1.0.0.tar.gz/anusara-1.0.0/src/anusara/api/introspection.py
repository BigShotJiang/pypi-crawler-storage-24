"""
Anusara Introspection Surface

Exposes lifecycle inspection and snapshot projection controls.
"""

from anusara._contracts.execution_input import ExecutionInput
from anusara._core.execution_status import ExecutionStatus
from anusara._introspection.mode import SnapshotMode
from anusara._introspection.projection import (
    SNAPSHOT_PROJECTION_VERSION,
    snapshot_to_projection,
)

__all__ = [
    "ExecutionStatus",
    "SnapshotMode",
    "ExecutionInput",
    "snapshot_to_projection",
    "SNAPSHOT_PROJECTION_VERSION",
]
