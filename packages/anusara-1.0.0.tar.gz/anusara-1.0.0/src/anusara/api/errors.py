"""
Anusara Public Error Surface.

Only lifecycle-level, user-intended errors should be exposed here.
"""

from anusara._core.errors import (
    ApprovalRequiredError,
    MaxHopExceededError,
    SimulatedHardKillError,
)
from anusara._mutation.compliance import MutationComplianceError

__all__ = [
    "ApprovalRequiredError",
    "MutationComplianceError",
    "SimulatedHardKillError",
    "MaxHopExceededError",
]
