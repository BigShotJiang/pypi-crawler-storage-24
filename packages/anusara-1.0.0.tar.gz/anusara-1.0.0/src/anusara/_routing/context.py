# anusara/_routing/context.py

from __future__ import annotations


class ExecutionContext:
    """
    Lightweight, deterministic context used during routing decisions.

    This context carries execution-scoped information required for
    evaluating conditions and controlling traversal behavior.

    Responsibilities:
    - Provide stable identifiers (request_id)
    - Track execution progress (hop count, trace)
    - Expose metadata for routing decisions

    Design constraints:
    - Must be deterministic and replay-safe
    - Must not contain non-serializable or time-dependent data
    - Mutations must be explicit and controlled

    This context is intentionally minimal and does not include
    execution results or state history (handled by ExecutionState).
    """

    def __init__(
        self,
        request_id: str,
        metadata: dict[str, object] | None = None,
    ) -> None:
        if not request_id or not isinstance(request_id, str):
            raise ValueError("request_id must be a non-empty string.")

        self.request_id: str = request_id
        self.metadata: dict[str, object] = metadata if metadata is not None else {}

        # Structured routing state
        self.current_hop: int = 0
        self.trace: list[str] = []

    # ---------------------------------------------------------

    def increment_hop(self) -> None:
        """
        Advance execution hop counter.

        Used to enforce max_hops and prevent infinite traversal.
        """
        self.current_hop += 1

    def add_trace(self, node_id: str) -> None:
        """
        Append node_id to execution trace.

        Maintains deterministic traversal history.
        """
        self.trace.append(node_id)

    # ---------------------------------------------------------

    def __repr__(self) -> str:
        return f"ExecutionContext(request_id={self.request_id!r})"
