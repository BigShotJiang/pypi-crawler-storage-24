# anusara/_routing/errors.py

from __future__ import annotations

from anusara._core.errors import AnusaraError


class RoutingError(AnusaraError):
    """
    Base exception for all routing-related errors.

    All routing failures should derive from this type to allow
    consistent handling across execution layers.
    """

    pass


# ---------------------------------------------------------
# Circular Routing
# ---------------------------------------------------------


class CircularRoutingError(RoutingError):
    """
    Raised when a cycle is detected in the execution graph.
    """

    def __init__(self, node_id: str) -> None:
        self.node_id = node_id

        super().__init__(f"Circular routing detected involving node '{node_id}'.")


# ---------------------------------------------------------
# Resolution Errors
# ---------------------------------------------------------


class ResolutionError(RoutingError):
    """
    Raised when routing resolution fails for a given identifier.

    Typically used for:
    - Missing nodes
    - Invalid dependencies
    - Unresolvable references
    """

    def __init__(self, identifier: str, message: str) -> None:
        self.identifier = identifier
        self.reason = message

        super().__init__(f"Resolution failed for '{identifier}': {message}")
