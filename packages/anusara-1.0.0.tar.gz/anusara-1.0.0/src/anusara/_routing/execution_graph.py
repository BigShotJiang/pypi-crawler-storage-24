# anusara/_routing/execution_graph.py

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from anusara._routing.errors import CircularRoutingError, ResolutionError

# ============================================================
# Node
# ============================================================


@dataclass(frozen=True)
class ExecutionNode:
    """
    Immutable node definition in the execution graph.

    - agent=None is reserved for synthetic/system nodes
    - metadata must remain JSON-safe and deterministic
    """

    id: str
    agent: str | None  # None for synthetic root
    metadata: dict[str, object] = field(default_factory=dict)


# ============================================================
# Graph
# ============================================================


@dataclass
class ExecutionGraph:
    """
    Deterministic directed acyclic graph (DAG) for execution planning.

    Responsibilities:
    - Maintain node and edge structure
    - Enforce structural invariants
    - Provide dependency and traversal utilities
    - Assign deterministic topological ordering

    Design guarantees:
    - Deterministic ordering (stable across runs)
    - No cycles
    - Single synthetic root
    - Full reachability from root
    """

    nodes: dict[str, ExecutionNode] = field(default_factory=dict)
    forward: dict[str, set[str]] = field(default_factory=dict)
    reverse: dict[str, set[str]] = field(default_factory=dict)

    topo_index: dict[str, int] = field(default_factory=dict)

    _frozen: bool = False

    # ---------------------------------------------------------
    # Lifecycle
    # ---------------------------------------------------------

    def freeze(self) -> None:
        """
        Freeze the graph to prevent further structural mutation.

        This operation is irreversible and marks the graph as
        ready for execution.
        """
        self._frozen = True

    def _assert_mutable(self) -> None:
        if self._frozen:
            raise RuntimeError("ExecutionGraph is frozen and cannot be modified.")

    # ---------------------------------------------------------
    # Graph Construction
    # ---------------------------------------------------------

    def add_node(self, node: ExecutionNode) -> None:
        self._assert_mutable()

        if node.id in self.nodes:
            raise ResolutionError(node.id, "Node already exists")

        self.nodes[node.id] = node
        self.forward.setdefault(node.id, set())
        self.reverse.setdefault(node.id, set())

    # ---------------------------------------------------------

    def add_edge(self, from_node: str, to_node: str) -> None:
        self._assert_mutable()

        if from_node not in self.nodes:
            raise ResolutionError(from_node, "Unknown source node")
        if to_node not in self.nodes:
            raise ResolutionError(to_node, "Unknown target node")

        self.forward[from_node].add(to_node)
        self.reverse[to_node].add(from_node)

    # ---------------------------------------------------------
    # Accessors
    # ---------------------------------------------------------

    def children_of(self, node_id: str) -> set[str]:
        return self.forward.get(node_id, set())

    def dependencies_of(self, node_id: str) -> set[str]:
        return self.reverse.get(node_id, set())

    # ---------------------------------------------------------
    # Validation
    # ---------------------------------------------------------

    def validate_non_empty(self) -> None:
        if not self.nodes:
            raise ResolutionError("graph", "ExecutionGraph cannot be empty")

    # ---------------------------------------------------------

    def validate_single_root(self, synthetic_root: str) -> None:
        if synthetic_root not in self.nodes:
            raise ResolutionError(synthetic_root, "Synthetic root node is missing")

        zero_in_degree = [
            node_id for node_id in self.nodes if len(self.dependencies_of(node_id)) == 0
        ]

        if zero_in_degree != [synthetic_root]:
            raise ResolutionError(
                synthetic_root,
                f"Expected single root but found {zero_in_degree}",
            )

    # ---------------------------------------------------------

    def validate_no_cycles(self) -> None:
        in_degree = {
            node_id: len(self.dependencies_of(node_id)) for node_id in self.nodes
        }

        queue = deque([n for n, d in in_degree.items() if d == 0])
        visited = 0

        while queue:
            node = queue.popleft()
            visited += 1

            for child in self.children_of(node):
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)

        if visited != len(self.nodes):
            raise CircularRoutingError("graph")

    # ---------------------------------------------------------

    def validate_reachable_from(self, root_id: str) -> None:
        visited = set()
        queue = deque([root_id])

        while queue:
            node = queue.popleft()
            if node in visited:
                continue

            visited.add(node)

            for child in self.children_of(node):
                queue.append(child)

        unreachable = set(self.nodes.keys()) - visited

        if unreachable:
            raise ResolutionError(
                "graph",
                f"Unreachable nodes detected: {sorted(unreachable)}",
            )

    # ---------------------------------------------------------

    def validate_structure(self, synthetic_root: str) -> None:
        """
        Enforce full structural invariants before execution.
        """
        self.validate_non_empty()
        self.validate_single_root(synthetic_root)
        self.validate_no_cycles()
        self.validate_reachable_from(synthetic_root)

    # ---------------------------------------------------------
    # Topological Ordering
    # ---------------------------------------------------------

    def assign_topological_order(self) -> None:
        """
        Assign deterministic topological index to each node.

        Guarantees:
        - Stable ordering across runs
        - Required for replay and scheduling
        """

        in_degree = {
            node_id: len(self.reverse.get(node_id, set())) for node_id in self.nodes
        }

        ready = deque(sorted(n for n, d in in_degree.items() if d == 0))

        index = 0
        topo_index: dict[str, int] = {}

        while ready:
            node_id = ready.popleft()

            topo_index[node_id] = index
            index += 1

            for child in sorted(self.children_of(node_id)):
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    ready.append(child)

        if len(topo_index) != len(self.nodes):
            raise CircularRoutingError("graph")

        self.topo_index = topo_index

    # ---------------------------------------------------------
    # Reachability Utility
    # ---------------------------------------------------------

    def reachable_from(self, start_nodes: set[str]) -> set[str]:
        visited = set()
        stack = list(start_nodes)

        while stack:
            node = stack.pop()

            if node in visited:
                continue

            if node not in self.nodes:
                raise ResolutionError(node, "Unknown node")

            visited.add(node)

            for child in self.children_of(node):
                stack.append(child)

        return visited
