# anusara/_routing/conditions.py

from __future__ import annotations

from collections.abc import Callable

from anusara._routing.context import ExecutionContext


class Condition:
    """
    Represents a deterministic routing condition evaluated against ExecutionContext.

    Conditions are used to control dynamic graph traversal by determining
    whether a node or edge should be activated during execution.

    Requirements:
    - Must be deterministic (no time, randomness, or external side effects)
    - Must be pure (no mutation of context)
    - Must be replay-safe

    Typically used for:
    - Conditional branching
    - Guarded execution paths
    - Policy-driven routing decisions
    """

    def __init__(self, predicate: Callable[[ExecutionContext], bool]) -> None:
        self._predicate = predicate

    # -----------------------------------------------------

    def evaluate(self, context: ExecutionContext) -> bool:
        return self._predicate(context)
