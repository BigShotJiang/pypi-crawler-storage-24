"""
Routing layer for execution planning and state management.

This module is responsible for:

- Representing execution structure (ExecutionGraph)
- Tracking execution progress and outcomes (ExecutionState)
- Recording node-level execution results (ExecutionRecord)
- Providing deterministic ordering and dependency resolution

Design principles:
- Deterministic: execution order must be reproducible
- Side-effect free: no direct execution logic
- State-centric: all runtime progress is captured explicitly
- Replay-safe: compatible with event sourcing and reconstruction

This layer acts as the bridge between:
- Static graph definition (contracts)
- Dynamic execution behavior (core runtime)
"""
