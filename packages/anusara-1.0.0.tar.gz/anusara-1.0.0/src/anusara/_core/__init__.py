"""
Internal module: core.

Implements the execution engine, policies, and lifecycle management
for deterministic orchestration.

Not part of the public API.
"""
