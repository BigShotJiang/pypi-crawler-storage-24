import asyncio
from collections.abc import Iterator, Sequence
from datetime import UTC, datetime
from typing import cast

from anusara._aggregation.result_aggregator import ResultAggregator
from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.events import (
    ExecutionCompleted,
    ExecutionFailed,
    ExecutionPaused,
    ExecutionStarted,
    MutationEvaluationMissing,
    NodeExecutionCompleted,
    NodeExecutionStarted,
    OrchestrationEvent,
)
from anusara._contracts.execution_request import (
    ExecutionRequest,
    ExecutionRequestDict,
)
from anusara._contracts.mesh_result import MeshResult
from anusara._core.errors import (
    ApprovalRequiredError,
    ExecutionAlreadyRunningError,
    MaxHopExceededError,
    SimulatedHardKillError,
)
from anusara._core.execution_log_inspector import ExecutionLogInspector
from anusara._core.execution_policy import FailureMode
from anusara._core.execution_reducer import ExecutionReducer
from anusara._core.execution_status import ExecutionStatus
from anusara._core.execution_summary import ExecutionSummary
from anusara._core.node_executor import NodeExecutor
from anusara._core.orchestration_event_emitter import OrchestrationEventEmitter
from anusara._introspection.execution_snapshot import (
    AttemptSnapshot,
    ExecutionSnapshot,
)
from anusara._introspection.mode import SnapshotMode
from anusara._mutation.compliance import (
    MutationComplianceChecker,
    MutationComplianceError,
)
from anusara._mutation.event_log import MutationEventLog
from anusara._observability.in_memory_event_log import InMemoryExecutionEventLog
from anusara._observability.observer import ExecutionObserver
from anusara._registry.agents_registry import AgentRegistry
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState
from anusara._routing.graph_compiler import GraphCompiler


class ExecutionEngine:
    """
    Sole orchestration authority for:

    - Graph compilation & validation
    - Execution lifecycle
    - Replay semantics
    - Snapshot generation
    """

    def __init__(
        self,
        observers: Sequence[ExecutionObserver] | None = None,
        event_log: ExecutionEventLog | None = None,
        mutation_event_log: MutationEventLog | None = None,
    ) -> None:
        self._compiler = GraphCompiler()
        self._aggregator = ResultAggregator()
        self._reducer = ExecutionReducer()

        self._event_log: ExecutionEventLog = (
            event_log if event_log is not None else InMemoryExecutionEventLog()
        )

        self._mutation_event_log = mutation_event_log
        # observers are reused, emitter is NOT
        self._observers = observers or []

        self._active_requests: set[str] = set()

        self._request_guard = asyncio.Lock()

    # ------------------------------------------------------------------
    # PROPERTIES
    # ------------------------------------------------------------------

    @property
    def event_log(self) -> ExecutionEventLog:
        return self._event_log

    @property
    def events(self) -> list[OrchestrationEvent]:
        return self._event_log.read_all()

    # ------------------------------------------------------------------
    # INTERNAL: Create per-execution emitter
    # ------------------------------------------------------------------

    def _create_emitter(
        self, state: ExecutionState, graph: ExecutionGraph
    ) -> OrchestrationEventEmitter:
        emitter = OrchestrationEventEmitter(
            observers=self._observers,
            event_log=self._event_log,
            reducer=self._reducer,
        )
        emitter.bind_runtime(state, graph)
        return emitter

    # ------------------------------------------------------------------
    # PUBLIC GRAPH COMPILATION
    # ------------------------------------------------------------------

    def compile(self, request: ExecutionRequest) -> ExecutionGraph:
        return self._compiler.compile(request)

    # ------------------------------------------------------------------
    # EXECUTE
    # ------------------------------------------------------------------

    async def execute(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
    ) -> tuple[MeshResult, ExecutionState]:

        await self._acquire_request_lock(request.request_id)

        try:
            request.validate()

            # PRECONDITION CHECK
            if request.policy.mutation_evaluation_mode == "required":
                if self._mutation_event_log is None:
                    raise MutationComplianceError("Mutation log not configured")

                MutationComplianceChecker.assert_compliant(
                    request_id=request.request_id,
                    mutation_events=self._mutation_event_log.read_by_request(
                        request.request_id
                    ),
                )

            graph = self._compiler.compile(request)
            graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
            graph.assign_topological_order()

            state = ExecutionState(graph, request)
            emitter = self._create_emitter(state, graph)

            state.mark_started()

            if state.started_at is None:
                raise RuntimeError("Execution started_at not initialized")

            emitter.emit(
                ExecutionStarted(
                    request_id=request.request_id,
                    timestamp=state.started_at,
                    execution_request=request.to_dict(),
                )
            )

            node_executor = NodeExecutor(
                registry=registry,
                retry_policy=request.policy.retry_policy,
                event_emitter=emitter,
                graph=graph,
            )

            semaphore = (
                asyncio.Semaphore(request.policy.max_concurrency)
                if request.policy.max_concurrency
                else None
            )

            async def run_node(nid: str, an: str) -> ExecutionRecord:
                if semaphore is not None:
                    async with semaphore:
                        return await node_executor.execute(
                            nid,
                            an,
                            request,
                            state,
                        )

                return await node_executor.execute(
                    nid,
                    an,
                    request,
                    state,
                )

            in_degree: dict[str, int] = {
                node_id: len(graph.dependencies_of(node_id))
                for node_id in graph.nodes.keys()
            }

            ready: set[str] = set(graph.children_of(GraphCompiler.SYNTHETIC_ROOT))
            hop_count = 0

            try:
                while ready:
                    if request.policy.max_hops and hop_count >= request.policy.max_hops:
                        raise MaxHopExceededError(request.policy.max_hops)

                    current_wave: list[str] = sorted(
                        ready, key=graph.topo_index.__getitem__
                    )
                    ready.clear()

                    tasks = []

                    for node_id in current_wave:
                        node = graph.nodes[node_id]
                        if node.agent is None:
                            continue

                        agent_name = node.agent

                        tasks.append(asyncio.create_task(run_node(node_id, agent_name)))

                    try:
                        records = await asyncio.gather(*tasks)

                    except SimulatedHardKillError:
                        raise

                    except ApprovalRequiredError:
                        raise

                    except Exception as e:
                        emitter.emit(
                            ExecutionFailed(
                                request_id=request.request_id,
                                error=str(e),
                                timestamp=datetime.now(UTC),
                            )
                        )
                        raise

                    for record in records:
                        hop_count += 1

                        if (
                            not record.result.success
                            and request.policy.failure_mode == FailureMode.FAIL_FAST
                        ):
                            ready.clear()
                            break

                        for child_id in graph.children_of(record.node_id):
                            in_degree[child_id] -= 1

                            if in_degree[child_id] == 0:
                                deps = graph.dependencies_of(child_id)

                                all_success = True

                                for dep in deps:
                                    dep_record = state.latest_record(dep)
                                    if dep_record is None:
                                        all_success = False
                                        break

                                    if not dep_record.result.success:
                                        all_success = False
                                        break

                                if all_success:
                                    ready.add(child_id)

                result = self._aggregator.aggregate(
                    graph=graph,
                    state=state,
                    policy=request.policy,
                )

                state.mark_completed()

                if state.completed_at is None:
                    raise RuntimeError("Execution completed_at not initialized")

                emitter.emit(
                    ExecutionCompleted(
                        request_id=request.request_id,
                        timestamp=state.completed_at,
                        success=result.success,
                        total_nodes=len(graph.nodes),
                    )
                )

                self._enforce_mutation_policy(request)

                return result, state

            except SimulatedHardKillError:
                raise

            except ApprovalRequiredError as e:
                state.mark_paused()

                emitter.emit(
                    ExecutionPaused(
                        request_id=request.request_id,
                        timestamp=datetime.now(UTC),
                        reason=str(e),
                    )
                )

                return (
                    self._aggregator.aggregate(
                        graph=graph,
                        state=state,
                        policy=request.policy,
                    ),
                    state,
                )
            except Exception as e:
                emitter.emit(
                    ExecutionFailed(
                        request_id=request.request_id,
                        error=str(e),
                        timestamp=datetime.now(UTC),
                    )
                )
                raise

        finally:
            self._active_requests.remove(request.request_id)

    # ------------------------------------------------------------------
    # REPLAY
    # ------------------------------------------------------------------

    async def replay(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
        state: ExecutionState,
        start_nodes: list[str],
        force: bool = False,
    ) -> MeshResult:

        await self._acquire_request_lock(request.request_id)

        try:
            request.validate()

            graph = self._compiler.compile(request)
            graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
            graph.assign_topological_order()

            emitter = self._create_emitter(state, graph)

            scope = graph.reachable_from(set(start_nodes))

            node_executor = NodeExecutor(
                registry=registry,
                retry_policy=request.policy.retry_policy,
                event_emitter=emitter,
                graph=graph,
            )

            in_degree = {
                node_id: len(
                    [dep for dep in graph.dependencies_of(node_id) if dep in scope]
                )
                for node_id in scope
            }

            ready: set[str] = set(start_nodes)

            while ready:
                current_wave: list[str] = sorted(
                    ready, key=graph.topo_index.__getitem__
                )
                ready.clear()

                records = []

                for node_id in current_wave:
                    if node_id not in scope:
                        continue

                    node = graph.nodes[node_id]

                    if node.agent is None:
                        continue

                    agent_name = node.agent
                    existing = state.latest_record(node_id)

                    if not force and existing and existing.result.success:
                        emitter.emit(
                            NodeExecutionStarted(
                                request_id=request.request_id,
                                timestamp=existing.started_at,
                                is_replay=True,
                                node_id=node_id,
                                agent=node.agent,
                                attempt=existing.attempt,
                            )
                        )

                        emitter.emit(
                            NodeExecutionCompleted(
                                request_id=request.request_id,
                                timestamp=existing.completed_at,
                                is_replay=True,
                                node_id=node_id,
                                agent=node.agent,
                                attempt=existing.attempt,
                                success=existing.result.success,
                                confidence=existing.result.confidence,
                                metadata=existing.result.metadata,
                            )
                        )

                        records.append(existing)
                        continue

                    new_record = await node_executor.execute(
                        node_id,
                        agent_name,
                        request,
                        state,
                    )

                    records.append(new_record)

                for record in records:
                    for child_id in graph.children_of(record.node_id):
                        if child_id not in scope:
                            continue

                        in_degree[child_id] -= 1
                        if in_degree[child_id] == 0:
                            ready.add(child_id)

            result = self._aggregator.aggregate(
                graph=graph,
                state=state,
                policy=request.policy,
            )

            self._enforce_mutation_policy(request)

            return result

        finally:
            self._active_requests.remove(request.request_id)

    # ------------------------------------------------------------------
    # LOCKING
    # ------------------------------------------------------------------

    async def _acquire_request_lock(self, request_id: str) -> None:
        async with self._request_guard:
            if request_id in self._active_requests:
                raise ExecutionAlreadyRunningError(request_id)

            self._active_requests.add(request_id)

    # ---------------------------------------------------------
    # Lifecycle Inspection
    # ---------------------------------------------------------

    def list_executions(self) -> Iterator[ExecutionSummary]:
        inspector = ExecutionLogInspector(self._event_log)
        return inspector.stream_summaries()

    def get_execution_status(self, request_id: str) -> ExecutionStatus:
        for summary in self.list_executions():
            if summary.request_id == request_id:
                return summary.status

        return ExecutionStatus.NOT_FOUND

    def rebuild_state(
        self,
        request: ExecutionRequest,
    ) -> ExecutionState:

        request.validate()

        graph = self._compiler.compile(request)
        graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
        graph.assign_topological_order()

        state = ExecutionState(graph, request)

        self._create_emitter(state, graph)

        events = self._event_log.read_by_request(request.request_id)

        for event in events:
            self._reducer.apply(event, state, graph)

        return state

    async def resume(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
    ) -> MeshResult:

        status = self.get_execution_status(request.request_id)

        if status == ExecutionStatus.NOT_FOUND:
            raise RuntimeError("No persisted execution found")

        if status == ExecutionStatus.COMPLETED:
            raise RuntimeError("Execution already completed")

        if status not in {ExecutionStatus.INCOMPLETE, ExecutionStatus.PAUSED}:
            raise RuntimeError("Execution log corrupted")

        state = self.rebuild_state(request)

        result = await self.replay(
            request=request,
            registry=registry,
            state=state,
            start_nodes=request.entry_nodes,
            force=False,
        )

        # 🔥 THIS IS WHAT YOU WERE MISSING
        emitter = self._create_emitter(state, self._compiler.compile(request))

        state.mark_completed()

        if state.completed_at is None:
            raise RuntimeError("Execution completed_at not initialized")

        emitter.emit(
            ExecutionCompleted(
                request_id=request.request_id,
                timestamp=state.completed_at,
                success=result.success,
                total_nodes=len(state._graph.nodes),
            )
        )

        self._enforce_mutation_policy(request)

        return result

    def snapshot(
        self,
        request: ExecutionRequest,
        graph: ExecutionGraph,
        state: ExecutionState,
        result: MeshResult,
        mode: SnapshotMode = SnapshotMode.FULL_HISTORY,
    ) -> ExecutionSnapshot:
        """
        Create an execution snapshot for introspection.

        Snapshot is a read-only materialized representation
        of execution state.
        """

        records = {}

        for node_id, attempts in state._records.items():
            snapshot_attempts = []

            for record in attempts:
                snapshot_attempts.append(
                    AttemptSnapshot(
                        attempt=record.attempt,
                        sequence_number=record.sequence_number,
                        forced=record.forced,
                        started_at=record.started_at,
                        completed_at=record.completed_at,
                        result=record.result,
                    )
                )

            records[node_id] = snapshot_attempts

        if state.completed_at is None:
            raise RuntimeError("Execution completed_at not initialized")

        return ExecutionSnapshot(
            request_id=state.request_id,
            started_at=state.started_at,
            completed_at=state.completed_at,
            records=records,
            overall_success=result.success,
            confidence=result.confidence,
        )

    def get_snapshot(self, request_id: str) -> ExecutionSnapshot:
        status = self.get_execution_status(request_id)

        if status == ExecutionStatus.NOT_FOUND:
            raise RuntimeError("Execution not found")

        # Read all events
        events = self._event_log.read_by_request(request_id)

        # Find ExecutionStarted event
        started_event = next(
            (e for e in events if isinstance(e, ExecutionStarted)),
            None,
        )

        if started_event is None:
            raise RuntimeError("ExecutionStarted event not found")

        # Reconstruct request from event payload
        request = ExecutionRequest.from_dict(
            cast(ExecutionRequestDict, started_event.execution_request)
        )

        # Rebuild state from full request
        state = self.rebuild_state(request)

        graph = self._compiler.compile(request)
        graph.validate_structure(GraphCompiler.SYNTHETIC_ROOT)
        graph.assign_topological_order()

        result = self._aggregator.aggregate(
            graph=graph,
            state=state,
            policy=request.policy,
        )

        return self.snapshot(request, graph, state, result)

    def rebuild_state_from_log(self, request_id: str) -> ExecutionState:

        events = self._event_log.read_by_request(request_id)

        if not events:
            raise RuntimeError("Execution not found")

        start_event = next(
            (e for e in events if isinstance(e, ExecutionStarted)),
            None,
        )

        if start_event is None:
            raise RuntimeError("ExecutionStarted event not found")

        execution_request = ExecutionRequest.from_dict(
            cast(ExecutionRequestDict, start_event.execution_request)
        )

        return self.rebuild_state(execution_request)

    def _enforce_mutation_policy(self, request: ExecutionRequest) -> None:
        if request.policy.mutation_evaluation_mode != "required":
            return

        if self._mutation_event_log is None:
            raise MutationComplianceError("Mutation log not configured")

        mutation_events = self._mutation_event_log.read_by_request(request.request_id)

        try:
            MutationComplianceChecker.assert_compliant(
                request_id=request.request_id,
                mutation_events=mutation_events,
            )

        except MutationComplianceError as err:
            # This is still an orchestration-level lifecycle signal
            self._event_log.append(
                MutationEvaluationMissing(
                    request_id=request.request_id,
                    timestamp=datetime.now(UTC),
                    policy_mode="required",
                    reason=str(err),
                )
            )
            raise

    async def replay_from_state(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
        state: ExecutionState,
    ) -> MeshResult:
        return await self.replay(
            request,
            registry,
            state,
            request.entry_nodes,
        )

    async def resume_from_snapshot(
        self,
        request: ExecutionRequest,
        registry: AgentRegistry,
        snapshot: bytes,
    ) -> MeshResult:
        state = ExecutionState.restore(snapshot)

        return await self.replay_from_state(
            request,
            registry,
            state,
        )
