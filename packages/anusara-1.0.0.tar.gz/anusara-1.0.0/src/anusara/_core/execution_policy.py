from dataclasses import dataclass, field
from enum import StrEnum
from typing import Literal

from typing_extensions import TypedDict

from anusara._aggregation.mode import AggregationMode
from anusara._runtime.retry_policy import RetryPolicy, RetryPolicyDict

# =========================================================
# Mutation Evaluation Mode
# =========================================================

MutationEvaluationMode = Literal[
    "disabled",
    "optional",
    "required",
]


# =========================================================
# External Dict Contract
# =========================================================


class ExecutionPolicyDict(TypedDict):
    failure_mode: str
    aggregation_mode: str
    retry_policy: RetryPolicyDict
    max_hops: int | None
    max_concurrency: int | None
    mutation_evaluation_mode: MutationEvaluationMode


# =========================================================
# Failure Mode
# =========================================================


class FailureMode(StrEnum):
    """
    Defines how execution behaves when a node fails.
    """

    FAIL_FAST = "fail_fast"
    CONTINUE = "continue"


# =========================================================
# Runtime Policy
# =========================================================


@dataclass
class ExecutionPolicy:
    """
    Execution-level behavior configuration.

    Controls:
    - failure handling strategy
    - retry behavior
    - aggregation semantics
    - execution limits (hops, concurrency)
    - mutation governance enforcement
    """

    # Failure handling
    failure_mode: FailureMode = FailureMode.CONTINUE

    # Retry behavior
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)

    # Result aggregation
    aggregation_mode: AggregationMode = AggregationMode.LATEST_ONLY

    # Execution limits
    max_hops: int | None = None

    # Mutation governance
    mutation_evaluation_mode: MutationEvaluationMode = "optional"

    # Parallel execution
    max_concurrency: int | None = None

    # -----------------------------------------------------
    # Serialization
    # -----------------------------------------------------

    def to_dict(self) -> ExecutionPolicyDict:
        return {
            "failure_mode": self.failure_mode.name,
            "aggregation_mode": self.aggregation_mode.name,
            "retry_policy": self.retry_policy.to_dict(),
            "max_hops": self.max_hops,
            "max_concurrency": self.max_concurrency,
            "mutation_evaluation_mode": self.mutation_evaluation_mode,
        }

    @classmethod
    def from_dict(cls, data: ExecutionPolicyDict) -> "ExecutionPolicy":
        return cls(
            failure_mode=FailureMode[data["failure_mode"]],
            aggregation_mode=AggregationMode[data["aggregation_mode"]],
            retry_policy=RetryPolicy.from_dict(data["retry_policy"]),
            max_hops=data.get("max_hops"),
            max_concurrency=data.get("max_concurrency"),
            mutation_evaluation_mode=data.get(
                "mutation_evaluation_mode",
                "optional",
            ),
        )


__all__ = ["ExecutionPolicy", "FailureMode", "RetryPolicy"]
