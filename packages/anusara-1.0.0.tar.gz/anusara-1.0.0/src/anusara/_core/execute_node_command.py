from dataclasses import dataclass

from anusara._contracts.json_types import JSONValue


@dataclass(frozen=True)
class ExecuteNodeCommand:
    """
    Represents a single unit of node execution work.

    This structure is transport-safe and can be serialized
    and passed across process or machine boundaries.

    It contains all information required to execute a node
    deterministically within the orchestration engine.
    """

    request_id: str
    node_id: str
    agent: str
    attempt: int
    payload: dict[str, JSONValue]
