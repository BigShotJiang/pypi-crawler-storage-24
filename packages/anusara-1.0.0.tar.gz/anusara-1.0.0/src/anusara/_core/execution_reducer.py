from typing import cast

from anusara._contracts.agent_result import AgentResult
from anusara._contracts.events import (
    ExecutionCompleted,
    ExecutionStarted,
    NodeExecutionCompleted,
    NodeExecutionFailed,
    NodeExecutionRetried,
    NodeExecutionStarted,
    OrchestrationEvent,
)
from anusara._contracts.json_types import JSONValue
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


class ExecutionReducer:
    """
    Applies orchestration events to reconstruct execution state.

    This reducer is the core of event-sourced state rebuilding:
    - consumes immutable events
    - mutates in-memory state deterministically
    - enables replay, resume, and inspection

    Important:
    - Must be idempotent for replay safety
    - Must ignore replay-emitted events where required
    """

    def apply(
        self,
        event: OrchestrationEvent,
        state: ExecutionState,
        graph: ExecutionGraph,
    ) -> None:

        # Ignore unrelated events
        if event.request_id != state.request_id:
            return

        # -----------------------------------------------------
        # Execution START
        # -----------------------------------------------------

        if isinstance(event, ExecutionStarted):
            state.mark_started()
            return

        # -----------------------------------------------------
        # Execution COMPLETED
        # -----------------------------------------------------

        if isinstance(event, ExecutionCompleted):
            state.mark_completed()
            return

        # -----------------------------------------------------
        # Node START
        # -----------------------------------------------------

        if isinstance(event, NodeExecutionStarted):
            if event.is_replay:
                return

            state._register_attempt_start(
                event.node_id,
                event.attempt,
                event.timestamp,
            )
            return

        # -----------------------------------------------------
        # Node FAILED
        # -----------------------------------------------------

        if isinstance(event, NodeExecutionFailed):
            started_ts = state._pop_attempt_start(
                event.node_id,
                event.attempt,
            )

            if started_ts is None:
                return  # Defensive

            completed_at = event.timestamp

            record = ExecutionRecord(
                node_id=event.node_id,
                result=AgentResult(
                    success=False,
                    output=None,
                    confidence=0.0,
                    metadata={"error": event.error},
                ),
                attempt=event.attempt,
                sequence_number=graph.topo_index[event.node_id],
                started_at=started_ts,
                completed_at=completed_at,
                forced=False,
            )

            state._append_internal(record)
            return

        # -----------------------------------------------------
        # Node COMPLETED
        # -----------------------------------------------------

        if isinstance(event, NodeExecutionCompleted):
            if event.is_replay:
                return

            started_ts = state._pop_attempt_start(
                event.node_id,
                event.attempt,
            )

            if started_ts is None:
                return  # Defensive

            completed_at = event.timestamp

            metadata = event.metadata if event.metadata is not None else {}

            output = cast(JSONValue | None, event.output)

            record = ExecutionRecord(
                node_id=event.node_id,
                result=AgentResult(
                    success=event.success,
                    output=output,
                    confidence=event.confidence,
                    metadata=metadata,
                ),
                attempt=event.attempt,
                sequence_number=graph.topo_index[event.node_id],
                started_at=started_ts,
                completed_at=completed_at,
                forced=False,
            )

            state._append_internal(record)
            return

        # -----------------------------------------------------
        # Node RETRIED (no-op for state)
        # -----------------------------------------------------

        if isinstance(event, NodeExecutionRetried):
            return
