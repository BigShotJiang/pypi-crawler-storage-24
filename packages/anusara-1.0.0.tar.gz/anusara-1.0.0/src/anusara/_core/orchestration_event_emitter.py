from collections.abc import Sequence

from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.events import OrchestrationEvent
from anusara._core.execution_reducer import ExecutionReducer
from anusara._observability.observer import ExecutionObserver
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_state import ExecutionState


class OrchestrationEventEmitter:
    """
    Central event dispatch pipeline.

    Responsibilities:
    - Append event to authoritative event log
    - Forward event to reducer (state projection)
    - Notify observers (isolated from core execution)

    Ordering is critical:
    1. Event log (source of truth)
    2. Reducer (state projection)
    3. Observers (side effects, monitoring)
    """

    def __init__(
        self,
        observers: Sequence[ExecutionObserver] | None = None,
        event_log: ExecutionEventLog | None = None,
        reducer: ExecutionReducer | None = None,
    ) -> None:
        self._observers = observers or []
        self._event_log = event_log
        self._reducer: ExecutionReducer | None = reducer
        self._state: ExecutionState | None = None
        self._graph: ExecutionGraph | None = None

    # ---------------------------------------------------------

    def bind_runtime(self, state: ExecutionState, graph: ExecutionGraph) -> None:
        """
        Bind runtime context required for reducer application.

        Called by ExecutionEngine at execution start.
        """
        self._state = state
        self._graph = graph

    # ---------------------------------------------------------

    def emit(self, event: OrchestrationEvent) -> None:
        """
        Emit an orchestration event through the pipeline.

        Guarantees:
        - Event is persisted before any projection
        - State is updated deterministically via reducer
        - Observers are isolated (fail-safe)
        """

        # 1️⃣ Append to authoritative event log
        if self._event_log:
            self._event_log.append(event)

        # 2️⃣ Forward to reducer (state projection)
        if self._reducer and self._state and self._graph:
            self._reducer.apply(event, self._state, self._graph)

        # 3️⃣ Notify observers (isolation invariant)
        for observer in self._observers:
            try:
                observer.on_event(event)
            except Exception:
                # Observers must never break execution
                pass
