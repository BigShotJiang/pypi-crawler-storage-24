from datetime import UTC, datetime, timedelta

from anusara._contracts.events import (
    NodeExecutionCompleted,
    NodeExecutionStarted,
)
from anusara._observability.exporters.chrome_trace_exporter import (
    ChromeTraceExporter,
)


def utc_now() -> datetime:
    return datetime.now(UTC)


start = utc_now()

events = [
    NodeExecutionStarted(
        request_id="demo_run",
        timestamp=start,
        node_id="node_A",
        agent="agentA",
        attempt=1,
    ),
    NodeExecutionCompleted(
        request_id="demo_run",
        timestamp=start + timedelta(seconds=1),
        node_id="node_A",
        agent="agentA",
        attempt=1,
        success=True,
        confidence=0.95,
    ),
    NodeExecutionStarted(
        request_id="demo_run",
        timestamp=start + timedelta(seconds=1.2),
        node_id="node_B",
        agent="agentB",
        attempt=1,
    ),
    NodeExecutionCompleted(
        request_id="demo_run",
        timestamp=start + timedelta(seconds=2),
        node_id="node_B",
        agent="agentB",
        attempt=1,
        success=True,
        confidence=0.87,
    ),
]

ChromeTraceExporter().export(events, "trace.json")

print("Trace written to trace.json")
