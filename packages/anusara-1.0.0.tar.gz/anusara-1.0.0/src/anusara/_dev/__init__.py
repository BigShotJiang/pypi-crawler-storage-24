"""
Internal developer utilities for Anusara.

This module contains tooling intended for development and debugging workflows,
including:

- trace generation and inspection
- debugging utilities
- experimental helpers
- local development scripts

⚠️ This is NOT part of the public API.
⚠️ Interfaces may change without notice.
⚠️ Must not be used in production execution paths.
"""
