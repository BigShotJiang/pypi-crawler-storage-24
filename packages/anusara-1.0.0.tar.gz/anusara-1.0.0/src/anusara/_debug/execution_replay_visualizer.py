from __future__ import annotations

import platform
import subprocess
import time

from anusara._contracts.execution_request import ExecutionRequest
from anusara._debug.execution_debugger import ExecutionDebugger
from anusara._debug.execution_graph_animation import ExecutionGraphAnimation
from anusara._debug.execution_timeline_visualizer import ExecutionTimelineVisualizer
from anusara._routing.execution_state import ExecutionState


class ExecutionReplayVisualizer:
    """
    Visual replay of workflow execution step-by-step.

    Combines:
    - execution timeline
    - graph animation (waves)
    - step-by-step playback

    Useful for debugging, demos, and understanding execution flow.
    """

    def __init__(
        self,
        request: ExecutionRequest,
        state: ExecutionState,
    ):
        self.request = request
        self.state = state

    # -----------------------------------------------------

    def _clear_terminal(self) -> None:
        if platform.system() == "Windows":
            subprocess.run(["cls"], shell=True)
        else:
            subprocess.run(["clear"])

    # -----------------------------------------------------

    def replay(self, delay: float = 0.5) -> None:
        debugger = ExecutionDebugger(self.state)

        if not debugger.has_next():
            print()
            print("Anusara Execution Replay")
            print("─" * 40)
            print("No execution history to replay.")
            return

        step = 0

        while debugger.has_next():
            record = debugger.step()
            step += 1

            replay_state = debugger.replay_state()

            timeline_viz = ExecutionTimelineVisualizer(replay_state)
            animation = ExecutionGraphAnimation(self.request, replay_state)

            # Clear screen (portable)
            self._clear_terminal()

            print("Anusara Execution Replay")
            print("─" * 40)

            print()
            print(f"Step {step}")
            print(f"Executed Node: {record.node_id}")

            print()
            print("Execution Waves")
            print("─" * 20)
            print(animation.render_waves(current_node=record.node_id))

            print()
            print("Timeline")
            print("─" * 20)
            print(timeline_viz.render_ascii())

            time.sleep(delay)

        print("\nReplay complete.\n")
