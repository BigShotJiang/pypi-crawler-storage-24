from __future__ import annotations

from anusara._contracts.execution_request import ExecutionRequest
from anusara._debug.execution_analyzer import ExecutionAnalyzer
from anusara._routing.execution_state import ExecutionState


class ExecutionGraphVisualizer:
    """
    Renders execution graphs in multiple visualization formats.

    Supported:
    - GraphViz DOT
    - Mermaid diagrams
    """

    SUCCESS_COLOR = "lightgreen"
    FAILURE_COLOR = "lightcoral"
    PENDING_COLOR = "lightgray"

    def __init__(
        self,
        request: ExecutionRequest,
        state: ExecutionState,
    ):
        self.request = request
        self.state = state
        self._analyzer = ExecutionAnalyzer(request, state)  # ✅ reuse

    # -----------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------

    def _extract_nodes_edges(self) -> tuple[set[str], list[tuple[str, str]]]:
        graph = self.request.graph_definition

        nodes: set[str] = set()
        edges: list[tuple[str, str]] = []

        if graph is None:
            return nodes, edges

        for node in graph.get("nodes", []):
            nodes.add(node["id"])

        for edge in graph.get("edges", []):
            if isinstance(edge, (tuple, list)):
                src, dst = edge
            else:
                src = edge["source"]
                dst = edge["target"]

            nodes.add(src)
            nodes.add(dst)
            edges.append((src, dst))

        return nodes, edges

    # -----------------------------------------------------

    def node_color(self, node_id: str) -> str:
        records = self.state._records.get(node_id)

        if not records:
            return self.PENDING_COLOR

        record = records[-1]

        if record.result.success:
            return self.SUCCESS_COLOR

        return self.FAILURE_COLOR

    # -----------------------------------------------------

    def node_label(self, node_id: str) -> str:
        records = self.state._records.get(node_id)

        if not records:
            return node_id

        record = records[-1]

        if not record.started_at or not record.completed_at:
            duration_ms = 0
        else:
            duration_ms = int(
                (record.completed_at - record.started_at).total_seconds() * 1000
            )

        retry_count = len(records) - 1

        label = f"{node_id}\\n{duration_ms}ms"

        if retry_count > 0:
            label += f"\\n(retry x{retry_count})"

        return label

    # -----------------------------------------------------
    # Wave computation
    # -----------------------------------------------------

    def compute_waves(self) -> dict[str, int]:
        nodes, edges = self._extract_nodes_edges()

        parents: dict[str, set[str]] = {n: set() for n in nodes}

        for src, dst in edges:
            parents.setdefault(dst, set()).add(src)

        waves: dict[str, int] = {}
        remaining = set(nodes)

        while remaining:
            ready = [
                n for n in remaining if all(p in waves for p in parents.get(n, []))
            ]

            for node in ready:
                if not parents[node]:
                    waves[node] = 0
                else:
                    waves[node] = max(waves[p] for p in parents[node]) + 1

            remaining -= set(ready)

        return waves

    # -----------------------------------------------------

    def _group_waves(self, waves: dict[str, int]) -> dict[int, list[str]]:
        groups: dict[int, list[str]] = {}

        for node, wave in waves.items():
            groups.setdefault(wave, []).append(node)

        return groups

    # -----------------------------------------------------
    # DOT rendering
    # -----------------------------------------------------

    def to_dot(self) -> str:
        nodes, edges = self._extract_nodes_edges()

        waves = self.compute_waves()
        groups = self._group_waves(waves)

        lines: list[str] = []
        lines.append("digraph AnusaraExecution {")
        lines.append("    rankdir=LR;")

        for node in sorted(nodes):
            label = self.node_label(node).replace('"', '\\"')
            color = self.node_latency_color(node)

            lines.append(
                f'    "{node}" [label="{label}", style=filled, fillcolor="{color}"];'
            )

        for src, dst in edges:
            lines.append(f'    "{src}" -> "{dst}";')

        for wave in sorted(groups):
            group_nodes = groups[wave]
            lines.append(
                "    { rank=same; " + "; ".join(f'"{n}"' for n in group_nodes) + "; }"
            )

        lines.append("}")

        return "\n".join(lines)

    def export_dot(self, path: str) -> None:
        with open(path, "w") as f:
            f.write(self.to_dot())

    # -----------------------------------------------------
    # Mermaid rendering
    # -----------------------------------------------------

    def to_mermaid(self) -> str:
        nodes, edges = self._extract_nodes_edges()
        waves = self.compute_waves()

        lines: list[str] = []
        lines.append("graph LR")

        for src, dst in edges:
            src_label = self.node_label(src).replace('"', "")
            dst_label = self.node_label(dst).replace('"', "")

            lines.append(f'    {src}["{src_label}"] --> {dst}["{dst_label}"]')

        groups = self._group_waves(waves)

        for wave, wave_nodes in groups.items():
            lines.append(f"    subgraph Wave_{wave}")
            for n in wave_nodes:
                lines.append(f"        {n}")
            lines.append("    end")

        return "\n".join(lines)

    # -----------------------------------------------------
    # Latency coloring
    # -----------------------------------------------------

    def node_latency_color(self, node_id: str) -> str:
        records = self._analyzer.records()

        durations = {r.node_id: self._analyzer.duration_ms(r) for r in records}

        if node_id not in durations:
            return "lightgray"

        max_d = max(durations.values()) if durations else 0
        d = durations[node_id]

        if max_d == 0:
            return "lightgreen"

        if d >= max_d * 0.7:
            return "red"

        if d >= max_d * 0.4:
            return "orange"

        return "lightgreen"
