from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime

from anusara._contracts.agent_result import AgentResult
from anusara._contracts.events import (
    NodeExecutionCompleted,
    NodeExecutionFailed,
    NodeExecutionStarted,
    OrchestrationEvent,
)
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


class ExecutionStateLoader:
    """
    Reconstruct ExecutionState from an event stream.

    Mirrors ExecutionReducer semantics so replay produces
    identical execution state.
    """

    @staticmethod
    def from_events(
        graph: ExecutionGraph,
        events: Iterable[OrchestrationEvent],
    ) -> ExecutionState:

        state = ExecutionState(graph)

        attempt_starts: dict[tuple[str, int], datetime] = {}

        for event in events:

            # -------------------------------------------------
            # START
            # -------------------------------------------------
            if isinstance(event, NodeExecutionStarted):
                if event.is_replay:
                    continue

                attempt_starts[(event.node_id, event.attempt)] = event.timestamp

            # -------------------------------------------------
            # COMPLETED
            # -------------------------------------------------
            elif isinstance(event, NodeExecutionCompleted):
                if event.is_replay:
                    continue

                started_at = attempt_starts.get((event.node_id, event.attempt))
                if started_at is None:
                    continue

                record = ExecutionRecord(
                    node_id=event.node_id,
                    result=AgentResult(
                        success=event.success,
                        output=event.output,  # ✅ FIXED
                        confidence=event.confidence,
                        metadata=event.metadata or {},
                    ),
                    attempt=event.attempt,
                    sequence_number=graph.topo_index[event.node_id],
                    started_at=started_at,
                    completed_at=event.timestamp,
                    forced=False,
                )

                state._append_internal(record)  # ✅ safer

            # -------------------------------------------------
            # FAILED
            # -------------------------------------------------
            elif isinstance(event, NodeExecutionFailed):
                started_at = attempt_starts.get((event.node_id, event.attempt))
                if started_at is None:
                    continue

                record = ExecutionRecord(
                    node_id=event.node_id,
                    result=AgentResult(
                        success=False,
                        output=None,
                        confidence=0.0,
                        metadata={"error": event.error},
                    ),
                    attempt=event.attempt,
                    sequence_number=graph.topo_index[event.node_id],
                    started_at=started_at,
                    completed_at=event.timestamp,
                    forced=False,
                )

                state._append_internal(record)

        return state
