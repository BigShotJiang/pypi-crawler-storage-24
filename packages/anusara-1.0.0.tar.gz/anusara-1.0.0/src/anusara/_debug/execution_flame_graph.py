from __future__ import annotations

import json
from datetime import timedelta
from pathlib import Path

from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


class ExecutionFlameGraph:
    """
    Generates flame graph style latency visualization
    and Speedscope-compatible profiling output.

    Useful for:
    - identifying slow nodes
    - understanding execution distribution
    - exporting to external profiling tools (Speedscope)
    """

    def __init__(self, state: ExecutionState):
        self.state = state

    # -----------------------------------------------------

    def _duration_ms(self, record: ExecutionRecord) -> float:
        if not record.started_at or not record.completed_at:
            return 0.0

        delta: timedelta = record.completed_at - record.started_at
        return delta.total_seconds() * 1000

    # -----------------------------------------------------

    def _seq_key(self, r: ExecutionRecord) -> int:
        return r.sequence_number if r.sequence_number is not None else 0

    def records(self) -> list[ExecutionRecord]:
        records: list[ExecutionRecord] = []

        for r in self.state._records.values():
            records.extend(r)

        return sorted(records, key=self._seq_key)

    # -----------------------------------------------------
    # ASCII Flame Graph
    # -----------------------------------------------------

    def render_ascii(self) -> str:
        lines = []
        lines.append("")
        lines.append("Execution Flame Graph")
        lines.append("─" * 50)

        records = self.records()

        if not records:
            return "\n".join(lines)

        max_duration = max(self._duration_ms(r) for r in records) or 1
        bar_scale = 40 / max_duration

        for r in records:
            duration = self._duration_ms(r)
            bar_len = int(duration * bar_scale)
            bar = "█" * bar_len

            lines.append(f"{r.node_id:<10} {bar:<40} {duration:.2f} ms")

        return "\n".join(lines)

    # -----------------------------------------------------
    # Speedscope Export
    # -----------------------------------------------------

    def export_speedscope(self, path: str | Path) -> None:
        records = self.records()

        if not records:
            return

        frames: list[dict[str, str]] = []
        frame_index: dict[str, int] = {}

        samples: list[list[int]] = []
        weights: list[float] = []

        valid_start_times = [
            r.started_at.timestamp() * 1000 for r in records if r.started_at
        ]

        if not valid_start_times:
            return

        base_time = min(valid_start_times)

        for r in records:
            if not r.started_at or not r.completed_at:
                continue

            name = r.node_id

            if name not in frame_index:
                frame_index[name] = len(frames)
                frames.append({"name": name})

            idx = frame_index[name]

            start = (r.started_at.timestamp() * 1000) - base_time
            end = (r.completed_at.timestamp() * 1000) - base_time

            duration = end - start

            samples.append([idx])
            weights.append(duration)

        profile = {
            "type": "sampled",
            "name": "anusara-execution",  # ✅ UPDATED
            "unit": "milliseconds",
            "samples": samples,
            "weights": weights,
        }

        data = {
            "$schema": "https://www.speedscope.app/file-format-schema.json",
            "shared": {"frames": frames},
            "profiles": [profile],
            "activeProfileIndex": 0,
        }

        Path(path).write_text(json.dumps(data, indent=2))
