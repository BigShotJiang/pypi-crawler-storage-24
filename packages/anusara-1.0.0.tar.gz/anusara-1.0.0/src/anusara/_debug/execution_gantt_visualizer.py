from __future__ import annotations

from datetime import datetime

from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


def _started_at_key(r: ExecutionRecord) -> datetime:
    return r.started_at or datetime.min


class ExecutionGanttVisualizer:
    """
    ASCII Gantt chart for workflow execution.

    Visualizes:
    - relative start times
    - execution durations
    - concurrency patterns

    Useful for quick timeline inspection without external tools.
    """

    def __init__(self, state: ExecutionState):
        self.state = state

    # ---------------------------------------------------------

    def render(self) -> str:
        records: list[ExecutionRecord] = self.state.all_records()

        # Filter only valid timed records
        records = [
            r
            for r in records
            if r.started_at is not None and r.completed_at is not None
        ]

        if not records:
            return "No execution data."

        start = min(r.started_at for r in records)

        lines: list[str] = []

        lines.append("Execution Gantt Chart (ms)")
        lines.append("")

        for r in sorted(records, key=_started_at_key):
            offset = int((r.started_at - start).total_seconds() * 1000)
            duration = int((r.completed_at - r.started_at).total_seconds() * 1000)

            # Scale down for readability
            bar = " " * (offset // 10) + "█" * max(1, duration // 10)

            lines.append(f"{r.node_id}: {bar}")

        return "\n".join(lines)
