from __future__ import annotations

import sys

from anusara._contracts.execution_request import ExecutionRequest
from anusara._debug.execution_graph_animation import ExecutionGraphAnimation
from anusara._debug.execution_timeline_visualizer import ExecutionTimelineVisualizer
from anusara._routing.execution_state import ExecutionState


class LiveExecutionVisualizer:
    """
    Observer that renders workflow progress live in the terminal.

    Designed to be invoked during execution lifecycle events.
    """

    def __init__(self, request: ExecutionRequest, state: ExecutionState):
        self.request = request
        self.state = state

    # ---------------------------------------------------------

    def refresh(self, current_node: str | None = None) -> None:
        animation = ExecutionGraphAnimation(self.request, self.state)
        timeline = ExecutionTimelineVisualizer(self.state)

        # Clear screen (fast ANSI)
        print("\033[2J\033[H", end="")

        print("Anusara Live Execution")
        print("─" * 40)

        print()
        print("Execution Waves")
        print("─" * 20)
        print(animation.render_waves(current_node=current_node))

        print()
        print("Timeline")
        print("─" * 20)
        print(timeline.render_ascii())

        sys.stdout.flush()

    # ---------------------------------------------------------

    def on_node_started(self, node_id: str) -> None:
        self.refresh(current_node=node_id)

    def on_node_completed(self, node_id: str) -> None:
        self.refresh(current_node=None)
