from __future__ import annotations

from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.graph_definition import GraphDefinition
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


class ExecutionAnalyzer:
    """
    Provides analytical insights into execution behavior.

    Capabilities:
    - execution timeline analysis
    - critical path computation
    - bottleneck identification
    - parallelism measurement

    This is a read-only utility and does not modify execution state.
    """

    def __init__(self, request: ExecutionRequest, state: ExecutionState):
        self.request = request
        self.state = state

    # -----------------------------------------------------

    def _seq_key(self, r: ExecutionRecord) -> int:
        return r.sequence_number if r.sequence_number is not None else 0

    def records(self) -> list[ExecutionRecord]:
        records: list[ExecutionRecord] = self.state.all_records()
        return sorted(records, key=self._seq_key)

    # -----------------------------------------------------

    def duration_ms(self, record: ExecutionRecord) -> float:
        if not record.started_at or not record.completed_at:
            return 0.0

        delta = record.completed_at - record.started_at
        return delta.total_seconds() * 1000

    # -----------------------------------------------------

    def total_runtime_ms(self) -> float:
        records = self.records()

        if not records:
            return 0.0

        start = min(r.started_at for r in records if r.started_at)
        end = max(r.completed_at for r in records if r.completed_at)

        return (end - start).total_seconds() * 1000

    # -----------------------------------------------------

    def critical_path(self) -> tuple[list[str], float]:
        graph: GraphDefinition | None = self.request.graph_definition

        if not graph:
            return [], 0.0

        edges = graph["edges"]

        children: dict[str, list[str]] = {}

        for edge in edges:
            if isinstance(edge, tuple):
                src, dst = edge
            else:
                src = edge["source"]
                dst = edge["target"]

            children.setdefault(src, []).append(dst)

        duration_map: dict[str, float] = {}

        for r in self.records():
            duration_map[r.node_id] = self.duration_ms(r)

        memo: dict[str, tuple[float, list[str]]] = {}

        def dfs(node: str) -> tuple[float, list[str]]:
            if node in memo:
                return memo[node]

            max_child_time = 0.0
            max_path: list[str] = []

            for child in children.get(node, []):
                t, p = dfs(child)

                if t > max_child_time:
                    max_child_time = t
                    max_path = p

            total = duration_map.get(node, 0.0) + max_child_time

            memo[node] = (total, [node] + max_path)
            return memo[node]

        best_time = 0.0
        best_path: list[str] = []

        for entry in self.request.entry_nodes:
            t, p = dfs(entry)

            if t > best_time:
                best_time = t
                best_path = p

        return best_path, best_time

    # -----------------------------------------------------

    def slowest_node(self) -> tuple[str | None, float]:
        slowest = None
        max_time = 0.0

        for r in self.records():
            d = self.duration_ms(r)

            if d > max_time:
                max_time = d
                slowest = r.node_id

        return slowest, max_time

    # -----------------------------------------------------

    def parallelism_score(self) -> float:
        total_runtime = self.total_runtime_ms()

        if total_runtime == 0:
            return 0.0

        total_work = sum(self.duration_ms(r) for r in self.records())

        return total_work / total_runtime

    # -----------------------------------------------------

    def render_report(self) -> str:
        lines: list[str] = []

        lines.append("")
        lines.append("Anusara Execution Analysis")
        lines.append("─" * 40)

        total = self.total_runtime_ms()
        path, path_time = self.critical_path()
        slow_node, slow_time = self.slowest_node()
        parallel = self.parallelism_score()

        lines.append(f"Total Runtime        {total:.2f} ms")
        lines.append(f"Critical Path        {' → '.join(path)}")
        lines.append(f"Critical Path Time   {path_time:.2f} ms")

        lines.append("")
        lines.append(f"Slowest Node         {slow_node} ({slow_time:.2f} ms)")
        lines.append(f"Parallelism Score    {parallel:.2f}")

        return "\n".join(lines)

    # -----------------------------------------------------

    def bottleneck_nodes(self) -> dict[str, float]:
        records = self.records()

        durations = {r.node_id: self.duration_ms(r) for r in records}

        if not durations:
            return {}

        max_d = max(durations.values())
        threshold = max_d * 0.7

        return {node: d for node, d in durations.items() if d >= threshold}
