"""
Registry layer for Anusara.

This package provides mechanisms to register, discover, and resolve
agents (and potentially other execution components) at runtime.

Responsibilities:
- Maintain mapping between agent identifiers and implementations
- Provide deterministic lookup during execution
- Act as a boundary between orchestration and concrete agent logic

Design principles:
- Explicit registration (no hidden magic)
- Deterministic and side-effect free lookup
- Lightweight and dependency-free
- Extensible for future registry types (tools, policies, plugins)

This layer is intentionally simple and serves as a foundational
integration point for the execution runtime.
"""
