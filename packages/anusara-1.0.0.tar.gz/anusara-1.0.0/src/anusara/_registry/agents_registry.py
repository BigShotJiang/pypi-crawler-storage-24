# anusara/_registry/agents_registry.py

from __future__ import annotations

from anusara._contracts.agent import Agent
from anusara._registry.errors import AgentNotFoundError


class AgentRegistry:
    """
    Registry for managing agent instances.

    Provides deterministic mapping between agent identifiers and
    concrete agent implementations used during execution.

    Behavior:
    - Non-strict mode (default): duplicate registrations overwrite existing agents
    - Strict mode: duplicate registrations raise KeyError

    Design principles:
    - Explicit registration only (no implicit discovery)
    - Deterministic lookup
    - Lightweight and side-effect free access
    """

    def __init__(self, strict: bool = False) -> None:
        """
        Args:
            strict:
                If True, duplicate registrations raise KeyError.
                If False, later registrations overwrite earlier ones.
        """
        self._agents: dict[str, Agent] = {}
        self._strict = strict

    # ---------------------------------------------------------

    def register(self, name: str, agent: Agent) -> None:
        """
        Register an agent under a unique name.

        Args:
            name: Unique identifier for the agent
            agent: Agent implementation

        Raises:
            ValueError: If name is invalid
            KeyError: If strict mode is enabled and name already exists
        """

        if not isinstance(name, str) or not name:
            raise ValueError("Agent name must be a non-empty string.")

        if self._strict and name in self._agents:
            raise KeyError(f"Agent '{name}' is already registered.")

        self._agents[name] = agent

    # ---------------------------------------------------------

    def get(self, name: str) -> Agent:
        """
        Retrieve a registered agent.

        Args:
            name: Agent identifier

        Returns:
            Agent instance

        Raises:
            AgentNotFoundError: If agent is not registered
        """

        try:
            return self._agents[name]
        except KeyError as exc:
            raise AgentNotFoundError(name) from exc

    # ---------------------------------------------------------

    def unregister(self, name: str) -> None:
        """
        Remove a registered agent.

        Raises:
            AgentNotFoundError: If agent is not registered
        """

        if name not in self._agents:
            raise AgentNotFoundError(name)

        del self._agents[name]

    # ---------------------------------------------------------

    def exists(self, name: str) -> bool:
        """Check if an agent is registered."""
        return name in self._agents

    # ---------------------------------------------------------

    def clear(self) -> None:
        """Remove all registered agents."""
        self._agents.clear()

    # ---------------------------------------------------------

    def __contains__(self, name: str) -> bool:
        return name in self._agents

    def __len__(self) -> int:
        return len(self._agents)
