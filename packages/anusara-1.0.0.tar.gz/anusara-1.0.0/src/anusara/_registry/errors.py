# anusara/_registry/errors.py

from __future__ import annotations

from anusara._core.errors import AnusaraError


class RegistryError(AnusaraError):
    """
    Base exception for registry-related errors.

    All registry failures should derive from this type to allow
    consistent error handling at higher layers.
    """

    pass


class AgentNotFoundError(RegistryError):
    """
    Raised when a requested agent is not registered.
    """

    def __init__(self, agent_name: str) -> None:
        self.agent_name = agent_name

        super().__init__(f"Agent '{agent_name}' is not registered.")
