from __future__ import annotations

from anusara._contracts.execution_request import ExecutionRequest
from anusara._debug.execution_debugger import ExecutionDebugger
from anusara._debug.execution_graph_visualizer import ExecutionGraphVisualizer
from anusara._debug.execution_timeline_visualizer import ExecutionTimelineVisualizer
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


class CLIDebugger:
    """
    Interactive CLI debugger for Anusara execution.

    Provides step-by-step traversal of execution history using
    deterministic replay. This enables:

    - Time-travel debugging
    - State inspection at each step
    - Visual understanding of graph + timeline evolution

    Design:
    - Uses ExecutionDebugger as the core replay engine
    - Purely observational (does NOT mutate execution state)
    - CLI-driven navigation (next / prev)
    """

    # ---------------------------------------------------------

    def run(self, state: ExecutionState, request: ExecutionRequest) -> None:
        """
        Start interactive debugging session.

        Args:
            state:
                Final execution state (source of truth for replay)

            request:
                Original execution request (used for graph visualization)
        """

        debugger = ExecutionDebugger(state)

        print("\nAnusara Time-Travel Debugger")
        print("=" * 40)

        while True:
            cmd = input("\n[n] next  [p] prev  [q] quit > ").strip().lower()

            # -------------------------------------------------
            # Quit
            # -------------------------------------------------
            if cmd == "q":
                break

            # -------------------------------------------------
            # Step forward
            # -------------------------------------------------
            if cmd == "n":
                if debugger.has_next():
                    record = debugger.step()
                    replay_state = debugger.replay_state()
                    self._render(replay_state, request, record)
                else:
                    print("End of execution")

            # -------------------------------------------------
            # Step backward
            # -------------------------------------------------
            elif cmd == "p":
                if debugger.has_prev():
                    debugger.step_back()

                    # Re-step forward to get current record
                    record = debugger.step()
                    replay_state = debugger.replay_state()

                    self._render(replay_state, request, record)
                else:
                    print("Start of execution")

    # ---------------------------------------------------------

    def _render(
        self,
        state: ExecutionState,
        request: ExecutionRequest,
        record: ExecutionRecord,
    ) -> None:
        """
        Render current replay state.

        Displays:
        - Current execution step
        - Graph (Mermaid format)
        - Timeline (ASCII)

        Args:
            state:
                Replay state at current step

            request:
                Original execution request

            record:
                Current execution record
        """

        graph_viz = ExecutionGraphVisualizer(request, state)
        timeline_viz = ExecutionTimelineVisualizer(state)

        print(f"\nStep {record.sequence_number}")
        print(f"Executed Node: {record.node_id}")

        print("\nGraph")
        print("-" * 20)
        print(graph_viz.to_mermaid())

        print("\nTimeline")
        print("-" * 20)
        print(timeline_viz.render_ascii())
