from __future__ import annotations

import argparse
import asyncio

from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.graph_definition import GraphDefinition
from anusara._debug.execution_gantt_visualizer import ExecutionGanttVisualizer
from anusara._debug.execution_replay_visualizer import ExecutionReplayVisualizer
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_state import ExecutionState
from anusara.api.core import AgentRegistry, ExecutionEngine
from anusara.cli.debug import CLIDebugger
from anusara.cli.inspect import inspect_graph
from anusara.cli.visualize import CLIVisualizer
from anusara.testing.agents import SuccessAgent

"""
Anusara CLI entrypoint.

Provides command-line access to runtime capabilities:

- Graph visualization
- Execution replay and analysis
- Interactive debugging
- Graph inspection

This module is intentionally thin and acts as a routing layer
between CLI commands and underlying runtime / debug components.

Invariants:
- No execution logic is implemented here
- All workflows are deterministic
- CLI remains a pure orchestration surface
"""


# ---------------------------------------------------------
# CLI Parser
# ---------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    """
    Construct CLI argument parser.

    Defines command hierarchy and supported flags.
    """

    parser = argparse.ArgumentParser(prog="anusara")

    subparsers = parser.add_subparsers(dest="command")

    # -----------------------------------------------------
    # visualize
    # -----------------------------------------------------

    visualize = subparsers.add_parser("visualize")
    visualize_sub = visualize.add_subparsers(dest="target")

    graph_cmd = visualize_sub.add_parser("graph")
    graph_cmd.add_argument("--output", default=".")

    visualize_sub.add_parser("run")

    flame_cmd = visualize_sub.add_parser("flame")
    flame_cmd.add_argument("--speedscope")

    visualize_sub.add_parser("analysis")
    visualize_sub.add_parser("gantt")

    # -----------------------------------------------------
    # replay
    # -----------------------------------------------------

    replay_cmd = subparsers.add_parser("replay")
    replay_cmd.add_argument("--delay", type=float, default=0.5)

    # -----------------------------------------------------
    # inspect
    # -----------------------------------------------------

    inspect_cmd = subparsers.add_parser("inspect")
    inspect_cmd.add_argument("--graph", required=True)

    # -----------------------------------------------------
    # debug
    # -----------------------------------------------------

    debug_cmd = subparsers.add_parser("debug")
    debug_cmd.add_argument("--run")

    return parser


# ---------------------------------------------------------
# Demo Workflow (Deterministic)
# ---------------------------------------------------------
def execute_demo_workflow() -> tuple[ExecutionRequest, ExecutionState]:
    """
    Execute a simple deterministic workflow.

    Used for:
    - Visualization
    - Replay
    - Debugging

    NOTE:
    This is intentionally self-contained and reproducible.
    """

    graph_definition: GraphDefinition = {
        "nodes": [
            {"id": "A", "agent": "A"},
            {"id": "B", "agent": "B"},
            {"id": "C", "agent": "C"},
        ],
        "edges": [
            {"source": "A", "target": "B"},
            {"source": "A", "target": "C"},
        ],
    }

    request = ExecutionRequest(
        request_id="demo",
        graph_definition=graph_definition,
        entry_nodes=["A"],
    )

    engine = ExecutionEngine()

    registry = AgentRegistry()
    registry.register("A", SuccessAgent())
    registry.register("B", SuccessAgent())
    registry.register("C", SuccessAgent())

    result, state = asyncio.run(engine.execute(request, registry))

    return request, state


# ---------------------------------------------------------
# CLI Entry
# ---------------------------------------------------------
def main() -> None:
    """
    CLI entrypoint.

    Parses arguments and dispatches commands to the appropriate
    runtime, visualization, or debugging workflows.
    """

    parser = build_parser()
    args = parser.parse_args()

    visualizer = CLIVisualizer()

    # Extract arguments (safe defaults)
    command: str | None = args.command
    target: str | None = getattr(args, "target", None)
    output: str = getattr(args, "output", ".")
    delay: float = getattr(args, "delay", 0.5)
    speedscope: str | None = getattr(args, "speedscope", None)
    graph_file: str | None = getattr(args, "graph", None)

    # -----------------------------------------------------
    # VISUALIZE
    # -----------------------------------------------------

    if command == "visualize" and target:
        if target == "graph":
            visualizer.visualize_graph(output)

        elif target == "run":
            request, state = execute_demo_workflow()
            replay = ExecutionReplayVisualizer(request, state)
            replay.replay()

        elif target == "flame":
            request, state = execute_demo_workflow()

            if speedscope:
                visualizer.export_speedscope(state, speedscope)
            else:
                visualizer.visualize_flame_graph(state)

        elif target == "analysis":
            request, state = execute_demo_workflow()
            visualizer.visualize_analysis(state, request)

        elif target == "gantt":
            request, state = execute_demo_workflow()
            gantt = ExecutionGanttVisualizer(state)
            print(gantt.render())

        else:
            parser.print_help()

    # -----------------------------------------------------
    # REPLAY
    # -----------------------------------------------------

    elif command == "replay":
        request, state = execute_demo_workflow()
        replay = ExecutionReplayVisualizer(request, state)
        replay.replay(delay=delay)

    # -----------------------------------------------------
    # INSPECT
    # -----------------------------------------------------

    elif command == "inspect":
        if graph_file is None:
            parser.error("--graph is required")

        inspect_graph(graph_file)

    # -----------------------------------------------------
    # DEBUG
    # -----------------------------------------------------

    elif command == "debug":
        debugger = CLIDebugger()

        graph = ExecutionGraph()
        state = ExecutionState(graph)

        request = ExecutionRequest(
            request_id="demo",
            graph_definition=None,
            entry_nodes=[],
        )

        debugger.run(state, request)

    # -----------------------------------------------------
    # FALLBACK
    # -----------------------------------------------------

    else:
        parser.print_help()


# ---------------------------------------------------------
# Entry Hook
# ---------------------------------------------------------
if __name__ == "__main__":
    main()
