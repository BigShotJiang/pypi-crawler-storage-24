"""
Command-line interface for interacting with Anusara.

This package provides developer-facing utilities to:
- Execute workflows
- Inspect execution state and snapshots
- Debug orchestration behavior
- Visualize execution graphs and traces

Design Principles:
- Thin adapter over core engine
- No business logic
- Focused on developer experience and operability

Modules:
- main: CLI entrypoint and command routing
- runner: Execute workflows from CLI
- inspect: Inspect execution state and snapshots
- debug: Debug helpers and diagnostics
- visualize: Graph and trace visualization utilities
"""
