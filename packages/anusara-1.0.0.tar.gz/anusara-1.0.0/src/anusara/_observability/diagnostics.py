# anusara/_observability/diagnostics.py

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class ExecutionDiagnostics:
    """
    Lightweight execution diagnostics model.

    Tracks:
    - node-level success/failure counts
    - execution lifecycle timestamps
    - derived metrics (success rate, duration)
    """

    request_id: str

    nodes_executed: int = 0
    failures: int = 0
    successes: int = 0

    started_at: datetime | None = None
    completed_at: datetime | None = None

    metadata: dict[str, Any] = field(default_factory=dict)

    # -----------------------------------------------------

    def mark_started(self) -> None:
        if self.started_at is None:
            self.started_at = datetime.now(UTC)

    def mark_completed(self) -> None:
        if self.completed_at is None:
            self.completed_at = datetime.now(UTC)

    # -----------------------------------------------------

    def record_success(self) -> None:
        self.nodes_executed += 1
        self.successes += 1

    def record_failure(self) -> None:
        self.nodes_executed += 1
        self.failures += 1

    # -----------------------------------------------------

    def _duration_ms(self) -> float | None:
        if not self.started_at or not self.completed_at:
            return None

        return (self.completed_at - self.started_at).total_seconds() * 1000

    # -----------------------------------------------------

    def snapshot(self) -> dict[str, Any]:
        success_rate = (
            self.successes / self.nodes_executed if self.nodes_executed > 0 else 0.0
        )

        return {
            "request_id": self.request_id,
            "nodes_executed": self.nodes_executed,
            "successes": self.successes,
            "failures": self.failures,
            "success_rate": success_rate,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": (
                self.completed_at.isoformat() if self.completed_at else None
            ),
            "duration_ms": self._duration_ms(),
        }
