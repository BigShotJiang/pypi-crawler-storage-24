"""
Observability layer for Anusara.

This package provides mechanisms to capture, persist, and expose
execution lifecycle signals for monitoring, debugging, and analysis.

---------------------------------------------------------------------
Responsibilities
---------------------------------------------------------------------
- Event logging (in-memory and pluggable backends)
- Observer interfaces for real-time event consumption
- Exporters for external tools (e.g., tracing, profiling)

---------------------------------------------------------------------
Key Abstractions
---------------------------------------------------------------------
- ExecutionObserver:
    Interface for subscribing to orchestration events.

- OrchestrationEvent:
    Immutable domain events emitted during execution.

- Event logs:
    Persistent or in-memory storage of execution history.

---------------------------------------------------------------------
Design Principles
---------------------------------------------------------------------
- Non-intrusive:
    Observability must not affect execution behavior.

- Event-driven:
    Observers react to emitted orchestration events.

- Extensible:
    Supports custom observers, exporters, and storage backends.

- Replay-compatible:
    Works with event sourcing and deterministic replay.

---------------------------------------------------------------------
Usage
---------------------------------------------------------------------
Observability is optional and can be enabled by attaching observers
to the execution engine.

Example:
    engine.add_observer(ConsoleObserver())
    engine.add_observer(OpenTelemetryObserver())

---------------------------------------------------------------------
Boundaries
---------------------------------------------------------------------
- MUST NOT introduce side effects into execution flow
- MUST NOT mutate orchestration state
- MAY depend on external libraries (kept isolated to this layer)

---------------------------------------------------------------------
Capabilities
---------------------------------------------------------------------
This layer enables visibility into:
- execution progress and outcomes
- node-level behavior and performance
- system-level traces and diagnostics

---------------------------------------------------------------------
Optional Dependencies
---------------------------------------------------------------------
Some observers (e.g., OpenTelemetry) require optional dependencies.

Install via:
    pip install anusara[observability]
"""
