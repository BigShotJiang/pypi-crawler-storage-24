# anusara/_observability/postgres_event_log.py

from __future__ import annotations

import json
from collections.abc import Iterable, Iterator
from typing import Any, cast

from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.events import OrchestrationEvent
from anusara._introspection.serialization import EventSerializer

# ---------------------------------------------------------
# Optional dependency (psycopg)
# ---------------------------------------------------------

# ---------------------------------------------------------
# Optional dependency (psycopg)
# ---------------------------------------------------------


try:
    import psycopg
except ImportError:  # pragma: no cover
    psycopg = cast(Any, None)


class PostgresExecutionEventLog(ExecutionEventLog):
    """
    PostgreSQL-backed event log.


    Characteristics:
    - append-only
    - durable
    - replay-safe
    - supports filtering by request_id

    Events stored as JSONB payloads.
    """

    def __init__(self, dsn: str) -> None:
        if psycopg is None:
            raise RuntimeError(
                "psycopg is required. Install with: pip install anusara[postgres]"
            )

        self._dsn = dsn
        self._conn = psycopg.connect(self._dsn)

        self._initialize_schema()

    # ---------------------------------------------------------

    def _initialize_schema(self) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS execution_events (
                    id BIGSERIAL PRIMARY KEY,
                    request_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    payload JSONB NOT NULL,
                    created_at TIMESTAMP DEFAULT NOW()
                )
                """
            )

            cur.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_execution_events_request
                ON execution_events(request_id)
                """
            )

            cur.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_execution_events_type
                ON execution_events(event_type)
                """
            )

        self._conn.commit()

    # ---------------------------------------------------------

    def append(self, event: OrchestrationEvent) -> None:
        payload = EventSerializer.to_dict(event)

        with self._conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO execution_events (request_id, event_type, payload)
                VALUES (%s, %s, %s)
                """,
                (
                    event.request_id,
                    event.event_type,
                    json.dumps(payload),
                ),
            )

        self._conn.commit()

    # ---------------------------------------------------------

    def read_all(self) -> list[OrchestrationEvent]:
        return list(self.stream())

    # ---------------------------------------------------------

    def read_by_request(self, request_id: str) -> list[OrchestrationEvent]:
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT payload
                FROM execution_events
                WHERE request_id = %s
                ORDER BY id ASC
                """,
                (request_id,),
            )

            rows: Iterable[tuple[Any]] = cur.fetchall()

        return [self._deserialize(payload) for (payload,) in rows]

    # ---------------------------------------------------------

    def stream(self) -> Iterator[OrchestrationEvent]:
        with self._conn.cursor() as cur:
            cur.execute(
                """
                SELECT payload
                FROM execution_events
                ORDER BY id ASC
                """
            )

            for (payload,) in cur:
                try:
                    yield self._deserialize(payload)
                except Exception:
                    continue  # resilience like file log

    def iter(self) -> Iterator[OrchestrationEvent]:
        return self.stream()

    # ---------------------------------------------------------

    def clear(self) -> None:
        with self._conn.cursor() as cur:
            cur.execute("DELETE FROM execution_events")

        self._conn.commit()

    # ---------------------------------------------------------

    def close(self) -> None:
        self._conn.close()

    # ---------------------------------------------------------
    # Internal helpers
    # ---------------------------------------------------------

    def _deserialize(self, payload: Any) -> OrchestrationEvent:
        """
        Handles both JSON string and dict (depending on psycopg config).
        """
        if isinstance(payload, str):
            data = json.loads(payload)
        else:
            data = payload

        return EventSerializer.from_dict(data)
