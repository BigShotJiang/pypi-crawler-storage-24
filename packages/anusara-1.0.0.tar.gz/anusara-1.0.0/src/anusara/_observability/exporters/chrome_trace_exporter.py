from __future__ import annotations

import json
from collections.abc import Iterable
from pathlib import Path

from anusara._contracts.events import (
    NodeExecutionCompleted,
    NodeExecutionFailed,
    NodeExecutionStarted,
    OrchestrationEvent,
)


class ChromeTraceExporter:
    """
    Export orchestration events into Chrome Trace format.

    Produces trace files compatible with:
    - chrome://tracing
    - Perfetto UI

    Notes:
    - Requires well-formed start/end event pairs
    - Events are sorted by timestamp before export
    """

    def export(
        self,
        events: Iterable[OrchestrationEvent],
        path: str | Path,
    ) -> None:

        # -------------------------------------------------
        # Sort events (important for trace correctness)
        # -------------------------------------------------

        sorted_events = sorted(events, key=lambda e: e.timestamp)

        trace_events: list[dict[str, object]] = []

        for event in sorted_events:
            ts = int(event.timestamp.timestamp() * 1_000_000)  # microseconds

            # -------------------------------------------------
            # Node START
            # -------------------------------------------------

            if isinstance(event, NodeExecutionStarted):
                trace_events.append(
                    {
                        "name": event.node_id,
                        "cat": "node",
                        "ph": "B",  # begin
                        "ts": ts,
                        "pid": event.request_id,
                        "tid": event.node_id,
                        "args": {
                            "agent": event.agent,
                            "attempt": event.attempt,
                        },
                    }
                )

            # -------------------------------------------------
            # Node END (success / failure)
            # -------------------------------------------------

            elif isinstance(event, NodeExecutionCompleted):
                trace_events.append(
                    {
                        "name": event.node_id,
                        "cat": "node",
                        "ph": "E",  # end
                        "ts": ts,
                        "pid": event.request_id,
                        "tid": event.node_id,
                        "args": {
                            "success": event.success,
                            "confidence": event.confidence,
                        },
                    }
                )

            elif isinstance(event, NodeExecutionFailed):
                trace_events.append(
                    {
                        "name": event.node_id,
                        "cat": "node",
                        "ph": "E",
                        "ts": ts,
                        "pid": event.request_id,
                        "tid": event.node_id,
                        "args": {
                            "error": event.error,
                        },
                    }
                )

        output = {"traceEvents": trace_events}

        # -------------------------------------------------
        # Write file
        # -------------------------------------------------

        path = Path(path)

        with path.open("w", encoding="utf-8") as f:
            json.dump(output, f, indent=2)
