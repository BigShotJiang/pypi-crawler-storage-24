"""
Exporters for transforming execution events into external formats.

This package provides adapters that convert internal orchestration
events into formats consumable by external tools such as:

- performance profilers
- tracing systems
- visualization tools

Responsibilities:
- transform event streams into structured outputs
- preserve timing and sequencing information
- ensure compatibility with external schemas (e.g., Chrome Trace)

Design principles:
- read-only (no mutation of event data)
- deterministic transformations
- tool-agnostic extensibility
- minimal coupling with core execution logic

Typical use cases:
- generating execution traces for performance analysis
- exporting workflows for visualization
- integrating with observability platforms
"""
