# anusara/_observability/structured_console.py

import json
from typing import Any

from anusara._contracts.events import OrchestrationEvent
from anusara._introspection.serialization import EventSerializer
from anusara._observability.observer import ExecutionObserver


class StructuredConsoleObserver(ExecutionObserver):
    """
    Emits JSON-formatted logs to stdout.

    Characteristics:
    - JSON-safe
    - consistent with event serialization layer
    - suitable for structured logging pipelines
    """

    def __init__(self, *, pretty: bool = False) -> None:
        self._pretty = pretty

    # ---------------------------------------------------------

    def on_event(self, event: OrchestrationEvent) -> None:
        try:
            payload: dict[str, Any] = EventSerializer.to_dict(event)

            if self._pretty:
                print(json.dumps(payload, indent=2))
            else:
                print(json.dumps(payload))

        except Exception:
            # Observers must never break execution
            pass
