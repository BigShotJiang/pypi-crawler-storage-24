# anusara/_observability/metrics.py

from anusara._contracts.events import (
    ExecutionCompleted,
    ExecutionFailed,
    ExecutionStarted,
    OrchestrationEvent,
)
from anusara._observability.observer import ExecutionObserver


class MetricsObserver(ExecutionObserver):
    """
    Collects aggregate execution metrics.

    Tracks:
    - total executions
    - total failures
    - failure rate
    - incomplete executions (implicit failures)
    """

    def __init__(self) -> None:
        self.total_executions = 0
        self.total_failures = 0

        self._seen_executions: set[str] = set()
        self._active_executions: set[str] = set()

    # ---------------------------------------------------------

    def on_event(self, event: OrchestrationEvent) -> None:

        # -------------------------------------------------
        # Execution started
        # -------------------------------------------------

        if isinstance(event, ExecutionStarted):

            if event.request_id in self._active_executions:
                # Previous execution never completed → count as failure
                self.total_failures += 1
            else:
                if event.request_id not in self._seen_executions:
                    self._seen_executions.add(event.request_id)
                    self.total_executions += 1

            self._active_executions.add(event.request_id)

        # -------------------------------------------------
        # Execution completed
        # -------------------------------------------------

        elif isinstance(event, ExecutionCompleted):
            self._active_executions.discard(event.request_id)

            if not event.success:
                self.total_failures += 1

        # -------------------------------------------------
        # Execution failed (explicit failure path)
        # -------------------------------------------------

        elif isinstance(event, ExecutionFailed):
            self._active_executions.discard(event.request_id)
            self.total_failures += 1

    # ---------------------------------------------------------

    def failure_rate(self) -> float:
        if self.total_executions == 0:
            return 0.0
        return self.total_failures / self.total_executions

    # ---------------------------------------------------------

    def snapshot(self) -> dict[str, float]:
        return {
            "total_executions": float(self.total_executions),
            "total_failures": float(self.total_failures),
            "failure_rate": self.failure_rate(),
        }
