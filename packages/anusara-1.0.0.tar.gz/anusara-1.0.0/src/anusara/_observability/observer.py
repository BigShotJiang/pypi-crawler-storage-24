# anusara/_observability/observer.py

from abc import ABC, abstractmethod

from anusara._contracts.events import OrchestrationEvent


class ExecutionObserver(ABC):
    """
    Base contract for execution observers.

    Observers:
    - receive orchestration events in real time
    - must NOT mutate execution state
    - must remain isolated (failures must not affect execution)
    - should be lightweight and non-blocking

    Common use cases:
    - logging
    - metrics collection
    - tracing
    - diagnostics
    """

    @abstractmethod
    def on_event(self, event: OrchestrationEvent) -> None:
        """
        Handle an emitted orchestration event.
        """
        raise NotImplementedError
