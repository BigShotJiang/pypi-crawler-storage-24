# anusara/_observability/memory.py


from anusara._contracts.events import OrchestrationEvent
from anusara._observability.observer import ExecutionObserver

from .models import Metric, MetricsExporter, Trace, TraceExporter

# ---------------------------------------------------------
# Memory Observer (Stores Raw Events)
# ---------------------------------------------------------


class MemoryObserver(ExecutionObserver):
    """
    In-memory event observer.

    Stores all emitted orchestration events.

    Characteristics:
    - deterministic
    - no side effects
    - ideal for testing and debugging
    """

    def __init__(self) -> None:
        self._events: list[OrchestrationEvent] = []

    def on_event(self, event: OrchestrationEvent) -> None:
        self._events.append(event)

    # -----------------------------------------------------

    def events(self) -> list[OrchestrationEvent]:
        """
        Returns a snapshot of captured events.
        """
        return list(self._events)

    def clear(self) -> None:
        self._events.clear()


# ---------------------------------------------------------
# Memory Metrics Exporter
# ---------------------------------------------------------


class MemoryMetricsExporter(MetricsExporter):
    """
    In-memory metrics exporter.

    Stores aggregated metrics for inspection.
    """

    def __init__(self) -> None:
        self._metrics: list[Metric] = []

    def export(self, metric: Metric) -> None:
        self._metrics.append(metric)

    # -----------------------------------------------------

    def metrics(self) -> list[Metric]:
        return list(self._metrics)

    def clear(self) -> None:
        self._metrics.clear()


# ---------------------------------------------------------
# Memory Trace Exporter
# ---------------------------------------------------------


class MemoryTraceExporter(TraceExporter):
    """
    In-memory trace exporter.

    Stores execution traces for inspection.
    """

    def __init__(self) -> None:
        self._traces: list[Trace] = []

    def export(self, trace: Trace) -> None:
        self._traces.append(trace)

    # -----------------------------------------------------

    def traces(self) -> list[Trace]:
        return list(self._traces)

    def clear(self) -> None:
        self._traces.clear()
