# anusara/_observability/tracing.py

from collections import defaultdict
from typing import Any

from anusara._contracts.events import OrchestrationEvent
from anusara._introspection.serialization import EventSerializer
from anusara._observability.observer import ExecutionObserver


class TracingObserver(ExecutionObserver):
    """
    In-memory structured tracing observer.

    Records a chronological sequence of serialized events per request_id.

    Characteristics:
    - deterministic ordering
    - JSON-safe representation
    - no schema assumptions
    - ideal for debugging and inspection
    """

    def __init__(self) -> None:
        self._traces: dict[str, list[dict[str, Any]]] = defaultdict(list)

    # ---------------------------------------------------------

    def on_event(self, event: OrchestrationEvent) -> None:
        try:
            entry: dict[str, Any] = EventSerializer.to_dict(event)

            request_id = entry.get("request_id")

            if isinstance(request_id, str):
                self._traces[request_id].append(entry)

        except Exception:
            # Observer must never break execution
            pass

    # ---------------------------------------------------------

    def trace(self, request_id: str) -> list[dict[str, Any]]:
        """
        Returns a snapshot of trace entries for a request.
        """
        return list(self._traces.get(request_id, []))

    # ---------------------------------------------------------

    def clear(self, request_id: str) -> None:
        """
        Clears trace for a specific request.
        """
        self._traces.pop(request_id, None)

    def clear_all(self) -> None:
        """
        Clears all traces.
        """
        self._traces.clear()
