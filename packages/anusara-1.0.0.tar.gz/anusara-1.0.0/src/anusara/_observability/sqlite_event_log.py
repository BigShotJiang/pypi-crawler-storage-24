# anusara/_observability/sqlite_event_log.py

from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.events import OrchestrationEvent
from anusara._introspection.serialization import EventSerializer


class SQLiteExecutionEventLog(ExecutionEventLog):
    """
    SQLite-backed event log.

    Characteristics:
    - append-only
    - lightweight persistence
    - suitable for local/dev environments
    - replay-safe
    """

    def __init__(self, db_path: str | Path) -> None:
        path = Path(db_path)

        self._connection = sqlite3.connect(
            str(path),
            check_same_thread=False,
        )

        self._initialize_schema()

    # ------------------------------------------------------------------

    def _initialize_schema(self) -> None:
        cursor = self._connection.cursor()

        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS execution_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                payload TEXT NOT NULL
            )
            """
        )

        cursor.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_execution_request
            ON execution_events(request_id)
            """
        )

        self._connection.commit()

    # ------------------------------------------------------------------

    def append(self, event: OrchestrationEvent) -> None:
        payload = EventSerializer.to_dict(event)

        cursor = self._connection.cursor()

        cursor.execute(
            """
            INSERT INTO execution_events (request_id, event_type, payload)
            VALUES (?, ?, ?)
            """,
            (
                event.request_id,
                event.event_type,
                json.dumps(payload),
            ),
        )

        self._connection.commit()

    # ------------------------------------------------------------------

    def read_all(self) -> list[OrchestrationEvent]:
        return list(self.stream())

    # ------------------------------------------------------------------

    def read_by_request(self, request_id: str) -> list[OrchestrationEvent]:
        cursor = self._connection.cursor()

        cursor.execute(
            """
            SELECT payload
            FROM execution_events
            WHERE request_id = ?
            ORDER BY id ASC
            """,
            (request_id,),
        )

        return [self._deserialize(row[0]) for row in cursor.fetchall()]

    # ------------------------------------------------------------------

    def stream(self) -> Iterator[OrchestrationEvent]:
        cursor = self._connection.cursor()

        cursor.execute(
            """
            SELECT payload
            FROM execution_events
            ORDER BY id ASC
            """
        )

        for (payload,) in cursor:
            try:
                yield self._deserialize(payload)
            except Exception:
                continue  # resilience

    def iter(self) -> Iterator[OrchestrationEvent]:
        return self.stream()

    # ------------------------------------------------------------------

    def clear(self) -> None:
        cursor = self._connection.cursor()
        cursor.execute("DELETE FROM execution_events")
        self._connection.commit()

    # ------------------------------------------------------------------

    def close(self) -> None:
        self._connection.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _deserialize(self, payload: Any) -> OrchestrationEvent:
        if isinstance(payload, str):
            data = json.loads(payload)
        else:
            data = payload

        return EventSerializer.from_dict(data)
