# anusara/_runtime/replay_coordinator.py

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from anusara._core.execution_engine import ExecutionEngine
from anusara._introspection.execution_snapshot import ExecutionSnapshot
from anusara._mutation.mutation_snapshot import MutationSnapshot

# =========================================================
# Replay Result
# =========================================================


@dataclass(frozen=True)
class ReplayResult:
    """
    Aggregated replay output across domains.

    - core_snapshot is always present
    - mutation_snapshot is optional (based on replay mode)
    """

    core_snapshot: ExecutionSnapshot
    mutation_snapshot: MutationSnapshot | None


# =========================================================
# Replay Mode
# =========================================================


class ReplayMode(StrEnum):
    """
    Controls replay scope.
    """

    CORE_ONLY = "core_only"
    WITH_MUTATION = "with_mutation"


# =========================================================
# Mutation Replay Interface
# =========================================================


class MutationReplayHandler:
    """
    Mutation subsystem replay contract.

    Implementations must be:
    - Deterministic
    - Snapshot-based
    - Side-effect free
    - Independent of runtime execution
    """

    def replay_mutation_events(
        self,
        *,
        request_id: str,
        core_snapshot: ExecutionSnapshot,
    ) -> MutationSnapshot:
        raise NotImplementedError


# =========================================================
# Replay Coordinator
# =========================================================


class ReplayCoordinator:
    """
    Orchestrates replay across system domains.

    Responsibilities:
    - Perform core execution replay (mandatory)
    - Optionally enrich with mutation replay
    - Maintain strict determinism and isolation

    Design principles:
    - Replay is read-only (no side effects)
    - Core domain is the source of truth
    - Extensions (e.g., mutation) are layered on top
    """

    def __init__(
        self,
        *,
        engine: ExecutionEngine,
        mutation_handler: MutationReplayHandler | None = None,
    ) -> None:
        self._engine = engine
        self._mutation_handler = mutation_handler

    # ---------------------------------------------------------

    def replay(
        self,
        *,
        request_id: str,
        mode: ReplayMode = ReplayMode.CORE_ONLY,
    ) -> ReplayResult:
        """
        Perform replay for a given request_id.

        Returns:
            ReplayResult containing core and optional mutation snapshots.
        """

        # -----------------------------------------------------
        # Core replay (always required)
        # -----------------------------------------------------
        core_snapshot = self._engine.get_snapshot(request_id)

        # -----------------------------------------------------
        # Optional mutation replay
        # -----------------------------------------------------
        mutation_snapshot: MutationSnapshot | None = None

        if mode == ReplayMode.WITH_MUTATION:
            if self._mutation_handler is None:
                raise RuntimeError(
                    "Mutation replay requested but no MutationReplayHandler provided."
                )

            mutation_snapshot = self._mutation_handler.replay_mutation_events(
                request_id=request_id,
                core_snapshot=core_snapshot,
            )

        # -----------------------------------------------------

        return ReplayResult(
            core_snapshot=core_snapshot,
            mutation_snapshot=mutation_snapshot,
        )
