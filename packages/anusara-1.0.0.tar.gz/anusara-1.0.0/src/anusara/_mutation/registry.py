from __future__ import annotations

from typing import Protocol

from anusara._contracts.events import OrchestrationEvent

# ============================================================
# Mutation Registry
# ============================================================


class MutationEventRegistry:
    """
    Local registry for mutation-domain events.

    Provides:
    - isolated registration of mutation events
    - controlled integration with core event registry
    """

    def __init__(self) -> None:
        self._registry: dict[str, type[OrchestrationEvent]] = {}

    # -----------------------------------------------------

    def register(
        self,
        event_cls: type[OrchestrationEvent],
    ) -> type[OrchestrationEvent]:
        """
        Register a mutation event class.

        Can be used as a decorator.
        """

        event_type = event_cls.EVENT_TYPE

        if event_type in self._registry:
            raise ValueError(f"Duplicate mutation event_type: {event_type}")

        self._registry[event_type] = event_cls
        return event_cls

    # -----------------------------------------------------

    def get_registered_events(self) -> list[type[OrchestrationEvent]]:
        return list(self._registry.values())


# ============================================================
# Core Registry Contract
# ============================================================


class _CoreRegistryLike(Protocol):
    def register(
        self, event_cls: type[OrchestrationEvent]
    ) -> type[OrchestrationEvent]: ...


# ============================================================
# Integration Helper
# ============================================================


def register_with_core(
    *,
    mutation_registry: MutationEventRegistry,
    core_registry: _CoreRegistryLike,
) -> None:
    """
    Registers all mutation events into the core event registry.

    This bridges mutation-domain events into the global orchestration system.
    """

    for event_cls in mutation_registry.get_registered_events():
        core_registry.register(event_cls)


__all__ = [
    "MutationEventRegistry",
    "register_with_core",
]
