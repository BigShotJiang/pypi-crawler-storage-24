from __future__ import annotations

import uuid
from typing import cast

from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.json_types import JSONValue
from anusara._mutation.artifact import MutationArtifactStore
from anusara._mutation.event import (
    GraphMutationExecuted,
    GraphMutationExecutionFailed,
)
from anusara._mutation.graph_mutator import GraphMutationEngine
from anusara._mutation.operations import (
    MutationOperation,
    MutationOpType,
)
from anusara._mutation.policy import MutationExecutionPolicy


class MutationExecutionError(Exception):
    """Raised when mutation execution cannot proceed."""


class MutationExecutionBuilder:
    """
    Bridges an accepted mutation proposal into a new ExecutionRequest.

    Responsibilities:
    - load mutation artifact
    - validate and construct mutation operations
    - apply mutation to graph
    - produce new execution request (no execution triggered)

    Guarantees:
    - no implicit execution
    - deterministic mutation application
    - strict lifecycle enforcement
    - clear success/failure event emission

    This is the boundary between:
    - mutation decision
    - execution creation
    """

    def __init__(
        self,
        *,
        artifact_store: MutationArtifactStore,
        execution_policy: MutationExecutionPolicy,
    ) -> None:
        self._store = artifact_store
        self._policy = execution_policy

    # -----------------------------------------------------

    def build_new_execution(
        self,
        *,
        base_request: ExecutionRequest,
        evaluation_id: str,
        observer_id: str,
        proposal_id: str,
    ) -> tuple[
        ExecutionRequest | None,
        GraphMutationExecuted | GraphMutationExecutionFailed,
    ]:

        # -------------------------------------------------
        # Load artifact (must exist)
        # -------------------------------------------------

        if not self._store.exists(proposal_id):
            raise MutationExecutionError(
                f"Artifact not found for proposal_id='{proposal_id}'"
            )

        artifact = self._store.load(proposal_id)

        # -------------------------------------------------
        # Build operations (strict narrowing)
        # -------------------------------------------------

        operations = [
            MutationOperation(
                op_type=cast(MutationOpType, op["op_type"]),
                payload=cast(dict[str, JSONValue], op["payload"]),
            )
            for op in artifact.operations
        ]

        # -------------------------------------------------
        # Apply mutation to graph
        # -------------------------------------------------

        try:
            new_graph = GraphMutationEngine.apply(
                base_graph=base_request.graph_definition,
                operations=operations,
            )

        except Exception as err:
            failure_event = GraphMutationExecutionFailed(
                request_id=base_request.request_id,
                base_request_id=base_request.request_id,
                evaluation_id=evaluation_id,
                observer_id=observer_id,
                proposal_id=proposal_id,
                error_message=str(err),
            )

            return None, failure_event

        # -------------------------------------------------
        # Build new execution (new lineage)
        # -------------------------------------------------

        new_request_id = str(uuid.uuid4())

        new_request = ExecutionRequest(
            request_id=new_request_id,
            entry_nodes=base_request.entry_nodes,
            graph_definition=new_graph,
            payload=base_request.payload,
            metadata=base_request.metadata,
            policy=base_request.policy,
        )

        # -------------------------------------------------
        # Emit success event
        # -------------------------------------------------

        success_event = GraphMutationExecuted(
            request_id=base_request.request_id,
            base_request_id=base_request.request_id,
            new_request_id=new_request_id,
            evaluation_id=evaluation_id,
            observer_id=observer_id,
            proposal_id=proposal_id,
        )

        return new_request, success_event
