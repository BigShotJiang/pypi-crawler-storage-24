from collections.abc import Sequence
from dataclasses import dataclass

from anusara._contracts.json_types import JSONValue


@dataclass(frozen=True)
class GraphMutationProposal:
    """
    Deterministic in-memory mutation proposal.

    Represents a proposal within the mutation lifecycle,
    distinct from its persisted artifact.

    Attributes:
    - proposal_id:
        Deterministically derived identifier

    - evaluation_id:
        Links proposal to evaluation cycle

    - observer_id:
        Source of proposal

    - operations:
        JSON-safe mutation operations (ordered, deterministic)

    - context_hash:
        Hash of evaluation context

    - policy_version:
        Policy used during evaluation

    - schema_version:
        Schema version of proposal structure

    Notes:
    - proposal_id must be derived via identity strategy
    - operations must be deterministic and JSON-serializable
    - ordering of operations is significant
    - nested structures are assumed immutable (caller responsibility)
    """

    proposal_id: str
    evaluation_id: str
    observer_id: str
    operations: Sequence[dict[str, JSONValue]]
    context_hash: str
    policy_version: str
    schema_version: str

    # -----------------------------------------------------

    def __post_init__(self) -> None:
        if not self.proposal_id:
            raise ValueError("proposal_id must not be empty")

        if not self.evaluation_id:
            raise ValueError("evaluation_id must not be empty")

        if not isinstance(self.operations, Sequence):
            raise TypeError("operations must be a sequence")

        if not isinstance(self.context_hash, str):
            raise TypeError("context_hash must be a string")
