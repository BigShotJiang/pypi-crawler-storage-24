from dataclasses import dataclass
from typing import Literal

# ============================================================
# Failure Strategy
# ============================================================

MutationFailureStrategy = Literal[
    "allow_alternate",  # try alternative proposals if available
    "require_new_evaluation",  # trigger fresh mutation evaluation
    "block_execution",  # stop mutation pipeline entirely
]


# ============================================================
# Mutation Execution Policy
# ============================================================


@dataclass(frozen=True)
class MutationExecutionPolicy:
    """
    Controls how mutation execution behaves under failure conditions.

    Attributes:
    - failure_strategy:
        Defines how the system responds when a mutation execution fails.

    - ttl_seconds:
        Optional time-to-live for mutation validity.
        Can be used to:
            - expire stale mutation decisions
            - enforce re-evaluation after time window

    Characteristics:
    - deterministic
    - policy-driven (no implicit behavior)
    - externalized control of mutation lifecycle
    """

    failure_strategy: MutationFailureStrategy = "require_new_evaluation"
    ttl_seconds: int | None = None

    # -----------------------------------------------------

    def __post_init__(self) -> None:
        if self.ttl_seconds is not None and self.ttl_seconds < 0:
            raise ValueError("ttl_seconds must be >= 0 or None")
