from __future__ import annotations

from collections.abc import Sequence
from copy import deepcopy
from typing import cast

from anusara._contracts.graph_definition import (
    EdgeDefinition,
    GraphDefinition,
    NodeDefinition,
)
from anusara._mutation.operations import MutationOperation


class GraphMutationEngine:
    """
    Applies mutation operations to GraphDefinition.

    Guarantees:
    - deterministic
    - pure (no side effects)
    - replay-safe

    Notes:
    - assumes caller ensures semantic correctness
    - performs light structural safeguards
    """

    # -----------------------------------------------------

    @staticmethod
    def apply(
        *,
        base_graph: GraphDefinition | None,
        operations: Sequence[MutationOperation],
    ) -> GraphDefinition:

        if base_graph is None:
            raise ValueError("Cannot mutate None graph")

        graph: GraphDefinition = deepcopy(base_graph)

        for op in operations:
            graph = GraphMutationEngine._apply_single(graph, op)

        return graph

    # -----------------------------------------------------

    @staticmethod
    def _apply_single(
        graph: GraphDefinition,
        operation: MutationOperation,
    ) -> GraphDefinition:

        op_type = operation.op_type
        payload = operation.payload

        nodes: list[NodeDefinition] = list(graph.get("nodes", []))
        edges: list[EdgeDefinition] = list(graph.get("edges", []))

        node_ids = {n["id"] for n in nodes}

        # -----------------------------------------
        # Helpers
        # -----------------------------------------

        def _edge_tuple(e: EdgeDefinition) -> tuple[str, str]:
            if isinstance(e, tuple):
                return e
            return (e["source"], e["target"])

        # -----------------------------------------
        # Node Operations
        # -----------------------------------------

        if op_type == "add_node":
            node = cast(NodeDefinition, payload)

            if node["id"] in node_ids:
                return graph  # idempotent no-op

            nodes.append(node)
            return {"nodes": nodes, "edges": edges}

        if op_type == "remove_node":
            node_id = str(payload["node_id"])

            nodes = [n for n in nodes if n["id"] != node_id]

            edges = [e for e in edges if node_id not in _edge_tuple(e)]

            return {"nodes": nodes, "edges": edges}

        if op_type == "replace_node":
            node = cast(NodeDefinition, payload)
            node_id = node["id"]

            nodes = [node if n["id"] == node_id else n for n in nodes]

            return {"nodes": nodes, "edges": edges}

        # -----------------------------------------
        # Edge Operations
        # -----------------------------------------

        if op_type == "add_edge":
            src = str(payload["from"])
            tgt = str(payload["to"])

            if src not in node_ids or tgt not in node_ids:
                raise ValueError(f"Edge references unknown nodes: {src} → {tgt}")

            edge = (src, tgt)

            if edge in [_edge_tuple(e) for e in edges]:
                return graph  # idempotent

            edges.append(edge)
            return {"nodes": nodes, "edges": edges}

        if op_type == "remove_edge":
            src = str(payload["from"])
            tgt = str(payload["to"])

            edges = [e for e in edges if _edge_tuple(e) != (src, tgt)]

            return {"nodes": nodes, "edges": edges}

        # -----------------------------------------
        # Higher-Level Operations
        # -----------------------------------------

        if op_type == "swap_template":
            return cast(GraphDefinition, payload["graph"])

        if op_type == "policy_transform":
            return cast(GraphDefinition, payload["graph"])

        # -----------------------------------------

        raise ValueError(f"Unsupported mutation operation: {op_type}")
