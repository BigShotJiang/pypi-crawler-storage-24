from collections.abc import Sequence
from typing import Protocol

from .event import MutationEvent


class MutationEventLog(Protocol):
    """
    Append-only event log for mutation lifecycle events.

    Responsibilities:
    - persist mutation events in emission order
    - allow retrieval of events per request_id

    Design constraints:
    - append-only (no mutation or deletion)
    - ordering must be preserved
    - retrieval must be deterministic
    - events must remain immutable after append

    Implementations may include:
    - in-memory (testing)
    - file-based (JSONL)
    - database-backed
    - distributed event stores
    """

    def append(self, event: MutationEvent) -> None:
        """
        Append a mutation event to the log.
        """
        ...

    def read_by_request(self, request_id: str) -> Sequence[MutationEvent]:
        """
        Retrieve all mutation events for a given request_id.

        Must return events in append order.
        """
        ...
