from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Protocol

from anusara._contracts.json_types import JSONValue

# ============================================================
# Mutation Proposal Artifact
# ============================================================


@dataclass(frozen=True)
class MutationProposalArtifact:
    """
    External artifact representing a mutation proposal.

    This artifact contains the full mutation payload and is stored
    outside the event log. The event log only references it via
    proposal_id.

    Design intent:
    - keep event log lightweight and replay-safe
    - enable storage of large or complex mutation payloads
    - ensure immutability of mutation proposals

    Artifacts must be treated as immutable once created.
    """

    proposal_id: str
    evaluation_id: str
    observer_id: str
    schema_version: str
    operations: Sequence[dict[str, JSONValue]]
    metadata: dict[str, JSONValue]


# ============================================================
# Artifact Store Interface
# ============================================================


class MutationArtifactStore(Protocol):
    """
    Storage interface for mutation proposal artifacts.

    Responsibilities:
    - persist and retrieve artifacts by proposal_id
    - guarantee deterministic retrieval
    - preserve immutability (no mutation after save)

    Implementations may include:
    - in-memory store (testing)
    - file-based store (JSON)
    - database-backed store
    - distributed storage systems

    Constraints:
    - proposal_id must not be modified
    - stored artifacts must not be mutated
    """

    def save(self, artifact: MutationProposalArtifact) -> None:
        """
        Persist a mutation proposal artifact.
        """
        ...

    def load(self, proposal_id: str) -> MutationProposalArtifact:
        """
        Retrieve a mutation proposal artifact by ID.
        """
        ...

    def exists(self, proposal_id: str) -> bool:
        """
        Check if an artifact exists for the given proposal_id.
        """
        ...
