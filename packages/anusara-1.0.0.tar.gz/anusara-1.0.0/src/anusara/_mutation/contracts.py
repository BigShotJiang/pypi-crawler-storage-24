from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

# ============================================================
# Canonical Identity Input
# ============================================================


@dataclass(frozen=True)
class CanonicalIdentityInput:
    """
    Canonical input used to derive mutation identities.

    This structure defines the full identity surface for mutation-related
    entities (evaluation, proposal, conflict).

    Requirements:
    - deterministic (same input → same identity)
    - fully serializable (JSON-safe)
    - stable across executions and environments

    Any change to this structure will affect identity generation.
    """

    proposal_content_hash: str
    evaluation_id: str
    schema_version: str
    policy_version: str
    salt: str


# ============================================================
# Mutation Proposal
# ============================================================


@dataclass(frozen=True)
class MutationProposal:
    """
    Represents a single mutation proposal.

    Attributes:
    - proposal_id:
        Unique identifier within system scope.

    - content_hash:
        Deterministic hash of the externalized mutation artifact.

    - schema_version:
        Version of mutation schema used to construct the proposal.

    - policy_version:
        Version of policy logic used during proposal generation.

    - reason:
        Human-readable explanation for the proposal.
    """

    proposal_id: str
    content_hash: str
    schema_version: str
    policy_version: str
    reason: str


# ============================================================
# Mutation Evaluation Result
# ============================================================


@dataclass(frozen=True)
class MutationEvaluationResult:
    """
    Represents the outcome of a mutation evaluation pass.

    Attributes:
    - evaluation_id:
        Unique identifier for this evaluation run.

    - proposals:
        List of mutation proposals (may be empty if no mutation needed).

    - stale_detected:
        Indicates whether schema or snapshot drift was detected
        during evaluation.
    """

    evaluation_id: str
    proposals: Sequence[MutationProposal]
    stale_detected: bool


# ============================================================
# Mutation Artifact Reference
# ============================================================


@dataclass(frozen=True)
class MutationArtifactReference:
    """
    Reference to an externally stored mutation artifact.

    The actual mutation payload is stored outside the event log.
    This structure links event log entries to external artifacts.

    Attributes:
    - proposal_id:
        Identifier of the mutation proposal.

    - content_hash:
        Hash of the artifact content used for integrity verification.
    """

    proposal_id: str
    content_hash: str
