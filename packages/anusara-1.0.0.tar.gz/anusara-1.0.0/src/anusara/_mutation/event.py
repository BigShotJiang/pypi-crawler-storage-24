from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import ClassVar

from anusara._contracts.event_types import MutationEventTypes
from anusara._contracts.events import EventRegistry, OrchestrationEvent
from anusara._utils.time import utc_now

# =========================================================
# Base Mutation Event
# =========================================================


@dataclass(kw_only=True)
class _MutationEvent(OrchestrationEvent):
    """
    Base class for all mutation events.

    Provides:
    - automatic event registration via EventRegistry
    - mutation event type namespace

    All subclasses must define EVENT_TYPE.
    """

    EVENT_TYPE: ClassVar[str] = "mutation_event"

    @property
    def event_type(self) -> str:
        return self.EVENT_TYPE

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)

        # Automatically register all mutation event subclasses
        if hasattr(cls, "EVENT_TYPE"):
            EventRegistry.register(cls)


# =========================================================
# Mutation Evaluation
# =========================================================


@dataclass(kw_only=True)
class MutationEvaluationRequested(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    evaluation_id: str
    observer_id: str
    trigger_source: str
    policy_version: str
    reason: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.MUTATION_EVALUATION_REQUESTED


# =========================================================
# Proposal Events
# =========================================================


@dataclass(kw_only=True)
class GraphMutationProposed(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    evaluation_id: str
    observer_id: str
    proposal_id: str
    proposal_schema_version: str
    context_hash: str
    policy_version: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.GRAPH_MUTATION_PROPOSED


@dataclass(kw_only=True)
class GraphMutationNoProposal(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    evaluation_id: str
    observer_id: str
    reason: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.GRAPH_MUTATION_NO_PROPOSAL


# =========================================================
# Decision Events
# =========================================================


@dataclass(kw_only=True)
class GraphMutationAccepted(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    evaluation_id: str
    observer_id: str
    proposal_id: str
    accepted_by: str
    reason: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.GRAPH_MUTATION_ACCEPTED


@dataclass(kw_only=True)
class GraphMutationRejected(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    evaluation_id: str
    observer_id: str
    proposal_id: str
    rejected_by: str
    reason: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.GRAPH_MUTATION_REJECTED


# =========================================================
# Conflict Events
# =========================================================


@dataclass(kw_only=True)
class GraphMutationConflictDetected(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    evaluation_id: str
    observer_id: str
    conflicting_proposal_ids: Sequence[str]
    conflict_hash: str
    reason: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.GRAPH_MUTATION_CONFLICT_DETECTED


@dataclass(kw_only=True)
class GraphMutationConflictResolved(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    evaluation_id: str
    observer_id: str
    selected_proposal_id: str
    resolved_by: str
    reason: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.GRAPH_MUTATION_CONFLICT_RESOLVED


# =========================================================
# Execution Events
# =========================================================


@dataclass(kw_only=True)
class GraphMutationExecuted(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    base_request_id: str
    new_request_id: str
    evaluation_id: str
    observer_id: str
    proposal_id: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.GRAPH_MUTATION_EXECUTED


@dataclass(kw_only=True)
class GraphMutationExecutionFailed(_MutationEvent):
    request_id: str
    timestamp: datetime = field(default_factory=utc_now)

    base_request_id: str
    evaluation_id: str
    observer_id: str
    proposal_id: str
    error_message: str

    EVENT_TYPE: ClassVar[str] = MutationEventTypes.GRAPH_MUTATION_EXECUTION_FAILED


# ---------------------------------------------------------
# Union Type
# ---------------------------------------------------------

MutationEvent = (
    MutationEvaluationRequested
    | GraphMutationProposed
    | GraphMutationNoProposal
    | GraphMutationAccepted
    | GraphMutationRejected
    | GraphMutationConflictDetected
    | GraphMutationConflictResolved
    | GraphMutationExecuted
    | GraphMutationExecutionFailed
)
