from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from anusara._contracts.json_types import JSONValue

# ============================================================
# Operation Types
# ============================================================

MutationOpType = Literal[
    "add_node",
    "remove_node",
    "add_edge",
    "remove_edge",
    "replace_node",
    "swap_template",
    "policy_transform",
]


# ============================================================
# Base Operation
# ============================================================


@dataclass(frozen=True)
class MutationOperation:
    """
    Represents a single mutation operation.

    Attributes:
    - op_type: type of mutation operation
    - payload: JSON-safe operation data

    Payload expectations:

    add_node:
        { "id": str, "agent": str?, "metadata": dict? }

    remove_node:
        { "node_id": str }

    replace_node:
        { "id": str, ... }

    add_edge:
        { "from": str, "to": str }

    remove_edge:
        { "from": str, "to": str }

    swap_template / policy_transform:
        { "graph": GraphDefinition }

    Notes:
    - must be deterministic
    - must be JSON-serializable
    - must be replay-safe
    """

    op_type: MutationOpType
    payload: dict[str, JSONValue]

    # -----------------------------------------------------

    def __post_init__(self) -> None:
        if not isinstance(self.payload, dict):
            raise TypeError("payload must be a dict")

        # Minimal structural validation (non-exhaustive)
        if self.op_type in {"add_edge", "remove_edge"}:
            if "from" not in self.payload or "to" not in self.payload:
                raise ValueError(f"{self.op_type} requires 'from' and 'to'")

        if self.op_type == "remove_node":
            if "node_id" not in self.payload:
                raise ValueError("remove_node requires 'node_id'")
