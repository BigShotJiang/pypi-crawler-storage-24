from __future__ import annotations

from collections.abc import Sequence
from typing import Literal

from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.json_types import JSONValue
from anusara._introspection.execution_snapshot import ExecutionSnapshot
from anusara._mutation.contracts import CanonicalIdentityInput
from anusara._mutation.event import MutationEvaluationRequested
from anusara._mutation.identity.base import MutationIdentityStrategy
from anusara._utils.hashing import sha256_hex
from anusara._utils.serialization import canonical_json


class DefaultMutationObserver:
    """
    Minimal deterministic mutation observer.

    Responsibilities:
    - evaluates execution context
    - emits a mutation evaluation event
    - does NOT generate mutation proposals

    Design intent:
    - safe default observer (no mutation side effects)
    - deterministic and replay-stable
    - baseline for custom observers

    This observer guarantees:
    - mutation evaluation is recorded
    - compliance requirements are satisfied
    """

    def __init__(
        self,
        *,
        observer_id: str,
        policy_version: str,
        identity_strategy: MutationIdentityStrategy,
        schema_version: str = "v1",
    ) -> None:
        self._observer_id = observer_id
        self._policy_version = policy_version
        self._identity = identity_strategy
        self._schema_version = schema_version

    # ---------------------------------------------------------

    def evaluate(
        self,
        *,
        request: ExecutionRequest,
        snapshot: ExecutionSnapshot,
        trigger_source: Literal["policy", "human", "external"],
        reason: str | None,
    ) -> Sequence[MutationEvaluationRequested]:

        # -----------------------------------------------------
        # Deterministic context hash
        # -----------------------------------------------------

        context_payload: dict[str, JSONValue] = {
            "request_id": request.request_id,
            "overall_success": snapshot.overall_success,
            "confidence": snapshot.confidence,
        }

        context_hash = sha256_hex(canonical_json(context_payload))

        # -----------------------------------------------------
        # Build canonical identity input
        # -----------------------------------------------------

        canonical_input = CanonicalIdentityInput(
            proposal_content_hash=context_hash,
            evaluation_id="",  # not used for evaluation identity
            schema_version=self._schema_version,
            policy_version=self._policy_version,
            salt="",  # deterministic, no randomness
        )

        evaluation_id = self._identity.build_evaluation_id(canonical_input)

        # -----------------------------------------------------
        # Emit evaluation event
        # -----------------------------------------------------

        event = MutationEvaluationRequested(
            request_id=request.request_id,
            evaluation_id=evaluation_id,
            observer_id=self._observer_id,
            trigger_source=trigger_source,
            reason=reason or "",
            policy_version=self._policy_version,
        )

        return [event]
