from __future__ import annotations

import hashlib
import json

from anusara._mutation.contracts import CanonicalIdentityInput
from anusara._mutation.identity.base import MutationIdentityStrategy


class SHA256SaltedIdentityStrategy(MutationIdentityStrategy):
    """
    Deterministic SHA256-based identity strategy.

    Generates stable, collision-resistant identifiers for mutation lifecycle elements.

    ID prefixes:
    - me_ → mutation evaluation
    - mp_ → mutation proposal
    - mc_ → mutation conflict

    Structure:
        <prefix>_<schema_version>_<hash>

    Hash:
        - SHA256 (hex)
        - truncated to configured length

    Design guarantees:
    - deterministic for identical canonical input
    - stable across executions
    - safe for distributed systems
    """

    def __init__(self, hash_length: int = 16) -> None:
        if hash_length <= 0:
            raise ValueError("hash_length must be positive")

        self._hash_length = hash_length

    # -----------------------------------------------------

    def build_evaluation_id(
        self,
        canonical_input: CanonicalIdentityInput,
    ) -> str:
        digest = self._digest(canonical_input)
        return f"me_{canonical_input.schema_version}_{digest}"

    # -----------------------------------------------------

    def build_proposal_id(
        self,
        canonical_input: CanonicalIdentityInput,
    ) -> str:
        digest = self._digest(canonical_input)
        return f"mp_{canonical_input.schema_version}_{digest}"

    # -----------------------------------------------------

    def build_conflict_hash(
        self,
        canonical_input: CanonicalIdentityInput,
    ) -> str:
        digest = self._digest(canonical_input)
        return f"mc_{canonical_input.schema_version}_{digest}"

    # -----------------------------------------------------

    def _digest(self, canonical_input: CanonicalIdentityInput) -> str:
        canonical = self._canonical_string(canonical_input)
        return self._hash(canonical)

    # -----------------------------------------------------

    def _canonical_string(
        self,
        canonical_input: CanonicalIdentityInput,
    ) -> str:
        payload = {
            "proposal_content_hash": canonical_input.proposal_content_hash,
            "evaluation_id": canonical_input.evaluation_id,
            "schema_version": canonical_input.schema_version,
            "policy_version": canonical_input.policy_version,
            "salt": canonical_input.salt,
        }

        return json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
        )

    # -----------------------------------------------------

    def _hash(self, value: str) -> str:
        digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
        return digest[: self._hash_length]
