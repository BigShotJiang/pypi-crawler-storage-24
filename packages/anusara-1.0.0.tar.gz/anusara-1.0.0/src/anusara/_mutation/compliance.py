from __future__ import annotations

from collections.abc import Sequence

from anusara._mutation.event import (
    GraphMutationAccepted,
    GraphMutationNoProposal,
    GraphMutationProposed,
    GraphMutationRejected,
    MutationEvaluationRequested,
    MutationEvent,
)


class MutationComplianceError(Exception):
    """
    Raised when mutation lifecycle invariants are violated.

    Indicates that mutation evaluation and decision flow
    did not complete as required by policy.
    """

    pass


class MutationComplianceChecker:
    """
    Validates mutation lifecycle compliance for a given execution.

    Ensures that:
    - mutation evaluation is performed
    - proposals (or explicit no-proposal) are recorded
    - all proposals are explicitly accepted or rejected

    This enforces deterministic and auditable mutation behavior.
    """

    @staticmethod
    def assert_compliant(
        *,
        request_id: str,
        mutation_events: Sequence[MutationEvent],
    ) -> None:

        # -----------------------------------------------------
        # 1. Evaluation must exist
        # -----------------------------------------------------

        evaluations = [
            e
            for e in mutation_events
            if isinstance(e, MutationEvaluationRequested) and e.request_id == request_id
        ]

        if not evaluations:
            raise MutationComplianceError("Mutation evaluation missing.")

        # -----------------------------------------------------
        # 2. Proposal OR explicit no-proposal must exist
        # -----------------------------------------------------

        proposals = [
            e
            for e in mutation_events
            if isinstance(e, GraphMutationProposed) and e.request_id == request_id
        ]

        no_proposals = [
            e
            for e in mutation_events
            if isinstance(e, GraphMutationNoProposal) and e.request_id == request_id
        ]

        if not proposals and not no_proposals:
            raise MutationComplianceError(
                "Evaluation performed but no proposal or explicit no-proposal recorded."
            )

        # -----------------------------------------------------
        # 3. All proposals must be decided
        # -----------------------------------------------------

        if proposals:
            decisions = [
                e
                for e in mutation_events
                if isinstance(e, (GraphMutationAccepted, GraphMutationRejected))
                and e.request_id == request_id
            ]

            proposal_ids = {p.proposal_id for p in proposals}
            decided_ids = {d.proposal_id for d in decisions}

            if not proposal_ids.issubset(decided_ids):
                raise MutationComplianceError("Not all proposals have been decided.")
