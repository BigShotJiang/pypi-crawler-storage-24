"""
Internal module: aggregation.

Defines result aggregation strategies and modes used by the execution engine
to combine outputs from multiple nodes in a deterministic manner.

Not part of the public API.
"""
