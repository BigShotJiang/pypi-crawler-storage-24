from enum import StrEnum


class AggregationMode(StrEnum):
    """
    Defines how execution attempts for a node are interpreted.

    These modes control how multiple execution records
    of the same node are reduced into a final record.
    """

    # Use only the latest execution record
    LATEST_ONLY = "latest_only"

    # Aggregate all attempts (used for debugging/analysis)
    ALL_ATTEMPTS = "all_attempts"

    # Prefer the latest successful attempt
    SUCCESS_ONLY = "success_only"

    # Ignore forced replays when aggregating
    EXCLUDE_FORCED = "exclude_forced"
