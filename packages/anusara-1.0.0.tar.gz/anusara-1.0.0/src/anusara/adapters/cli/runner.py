# anusara/_adapters/cli/runner.py

from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any

from anusara.api import ExecutionRequest
from anusara.api.core import AgentRegistry, ExecutionEngine


def run_cli(
    *,
    engine: ExecutionEngine,
    registry: AgentRegistry,
    entry_nodes: list[str],
    payload: dict[str, Any] | None = None,
) -> None:
    """
    Execute a workflow via CLI-style invocation.

    Responsibilities:
    - Construct ExecutionRequest
    - Invoke execution engine
    - Print JSON-formatted output

    This is a thin adapter:
    - No business logic
    - No mutation of core behavior
    """

    # ---------------------------------------------------------
    # Build request
    # ---------------------------------------------------------

    request = ExecutionRequest(
        request_id=str(uuid.uuid4()),
        entry_nodes=entry_nodes,
        payload=payload or {},
    )

    # ---------------------------------------------------------
    # Execute
    # ---------------------------------------------------------

    try:
        result, _ = asyncio.run(engine.execute(request, registry))

    except Exception as exc:
        error_output = {
            "success": False,
            "error": str(exc),
        }
        print(json.dumps(error_output, indent=2))
        return

    # ---------------------------------------------------------
    # Output
    # ---------------------------------------------------------

    output: dict[str, Any] = {
        "request_id": request.request_id,
        "success": result.success,
        "confidence": result.confidence,
        "results": result.results,
        "errors": result.errors,
    }

    print(json.dumps(output, indent=2))
