"""
External integration layer for Anusara.

This package provides adapters that expose the core orchestration
engine through different interfaces (CLI, HTTP, etc.).

Responsibilities:
- Translate external inputs into ExecutionRequest
- Invoke runtime execution and replay flows
- Map internal results into user-facing responses
- Maintain clear separation between core logic and I/O boundaries

Design principles:
- Thin translation layer (no business logic)
- Deterministic core interaction
- Extensible for multiple interfaces (CLI, HTTP, future integrations)
- Decoupled from transport/framework specifics

Adapters sit at the system boundary and should remain lightweight.
"""
