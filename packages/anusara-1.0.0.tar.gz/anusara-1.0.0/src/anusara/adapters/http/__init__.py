"""
HTTP adapter for Anusara.

Exposes the orchestration system over a web API.

Responsibilities:
- Define API endpoints for execution, replay, and mutation
- Validate and transform HTTP payloads into internal requests
- Serialize responses into JSON-safe representations
- Integrate with web frameworks (e.g., FastAPI)

Components:
- app.py: application setup and route definitions
- runtime.py: request handling and execution wiring
- schemas.py: request/response models
- utils.py: HTTP-specific helpers

Design principles:
- Stateless request handling
- Clear separation of transport and core logic
- JSON-boundary safety
- Framework-agnostic structure where possible

This adapter enables integration with external systems and services.
"""
