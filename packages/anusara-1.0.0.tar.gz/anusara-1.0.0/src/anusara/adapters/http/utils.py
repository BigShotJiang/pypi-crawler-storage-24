from __future__ import annotations

from typing import Any

# ---------------------------------------------------------
# Root Response
# ---------------------------------------------------------


def default_root(
    *,
    service: str,
    version: str,
    architecture: str | None = None,
    docs_path: str = "/docs",
    health_path: str = "/health",
) -> dict[str, Any]:
    """
    Standard root response for HTTP services.

    Provides a lightweight, stable landing response for `/`.

    Useful for:
    - Service discovery
    - Smoke tests
    - Developer orientation
    """

    response: dict[str, Any] = {
        **service_metadata(
            service=service,
            version=version,
            architecture=architecture,
        ),
        **build_links(
            docs=docs_path,
            health=health_path,
        ),
    }

    return response


# ---------------------------------------------------------
# Metadata
# ---------------------------------------------------------


def service_metadata(
    *,
    service: str,
    version: str,
    architecture: str | None = None,
) -> dict[str, str]:
    """
    Build consistent service metadata.

    Used across:
    - Root endpoint
    - Health endpoint
    - Diagnostics responses
    """

    metadata: dict[str, str] = {
        "service": service,
        "version": version,
    }

    if architecture:
        metadata["architecture"] = architecture

    return metadata


# ---------------------------------------------------------
# Links
# ---------------------------------------------------------


def build_links(
    *,
    docs: str = "/docs",
    health: str = "/health",
    openapi: str = "/openapi.json",
) -> dict[str, str]:
    """
    Construct standard service links.

    Ensures consistent link structure across endpoints.
    """

    return {
        "docs": docs,
        "health": health,
        "openapi": openapi,
    }
