from __future__ import annotations

from enum import StrEnum
from typing import cast

from pydantic import BaseModel, Field, field_validator

from anusara._aggregation.mode import AggregationMode
from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.graph_definition import GraphDefinition
from anusara._contracts.json_types import JSONValue
from anusara._core.execution_policy import ExecutionPolicy, FailureMode
from anusara._runtime.retry_policy import RetryPolicy

# ---------------------------------------------------------
# Enums
# ---------------------------------------------------------


class FailureModeEnum(StrEnum):
    FAIL_FAST = "FAIL_FAST"
    CONTINUE = "CONTINUE"


class AggregationModeEnum(StrEnum):
    LATEST_ONLY = "LATEST_ONLY"
    SUCCESS_ONLY = "SUCCESS_ONLY"
    ALL_ATTEMPTS = "ALL_ATTEMPTS"
    EXCLUDE_FORCED = "EXCLUDE_FORCED"


# ---------------------------------------------------------
# Health
# ---------------------------------------------------------


class HealthResponse(BaseModel):
    status: str
    service: str
    architecture: str
    version: str


# ---------------------------------------------------------
# Graph
# ---------------------------------------------------------


class GraphDefinitionSchema(BaseModel):
    edges: list[tuple[str, str]] = Field(default_factory=list)


# ---------------------------------------------------------
# Policy
# ---------------------------------------------------------


class RetryPolicySchema(BaseModel):
    max_attempts: int = Field(default=1, ge=1)
    base_delay_ms: int = Field(default=100, ge=0)
    max_delay_ms: int = Field(default=2000, ge=0)
    jitter: bool = True


class ExecutionPolicySchema(BaseModel):
    failure_mode: FailureModeEnum = FailureModeEnum.FAIL_FAST
    aggregation_mode: AggregationModeEnum = AggregationModeEnum.LATEST_ONLY
    retry_policy: RetryPolicySchema = Field(default_factory=RetryPolicySchema)
    max_hops: int | None = Field(default=None, ge=1)
    max_concurrency: int | None = Field(default=None, ge=1)


# ---------------------------------------------------------
# Execute Request
# ---------------------------------------------------------


class ExecuteRequest(BaseModel):
    entry_nodes: list[str]
    graph_definition: GraphDefinitionSchema | None = None
    payload: dict[str, object] = Field(default_factory=dict)
    metadata: dict[str, object] = Field(default_factory=dict)
    policy: ExecutionPolicySchema = Field(default_factory=ExecutionPolicySchema)

    # -----------------------------------------------------
    # Validation
    # -----------------------------------------------------

    @field_validator("entry_nodes")
    @classmethod
    def validate_entry_nodes(cls, value: list[str]) -> list[str]:
        if not value:
            raise ValueError("entry_nodes must contain at least one node.")
        return value

    # -----------------------------------------------------
    # Conversion
    # -----------------------------------------------------

    def to_execution_request(self, request_id: str) -> ExecutionRequest:
        """
        Convert API schema into domain ExecutionRequest.

        This is a boundary transformation:
        - API-safe → domain-safe
        - units normalized (ms → seconds)
        """

        failure_mode = FailureMode[self.policy.failure_mode.name]
        aggregation_mode = AggregationMode[self.policy.aggregation_mode.name]

        retry_policy = RetryPolicy(
            max_attempts=self.policy.retry_policy.max_attempts,
            base_delay=self.policy.retry_policy.base_delay_ms / 1000.0,
            max_delay=self.policy.retry_policy.max_delay_ms / 1000.0,
            jitter=self.policy.retry_policy.jitter,
        )

        execution_policy = ExecutionPolicy(
            failure_mode=failure_mode,
            retry_policy=retry_policy,
            aggregation_mode=aggregation_mode,
            max_hops=self.policy.max_hops,
            max_concurrency=self.policy.max_concurrency,
        )

        graph_def: GraphDefinition | None = None

        if self.graph_definition is not None:
            graph_def = cast(
                GraphDefinition,
                {
                    "nodes": [],
                    "edges": self.graph_definition.edges,
                },
            )

        return ExecutionRequest(
            request_id=request_id,
            entry_nodes=self.entry_nodes,
            graph_definition=graph_def,
            payload=cast(dict[str, JSONValue], self.payload),
            metadata=cast(dict[str, JSONValue], self.metadata),
            policy=execution_policy,
        )
