from __future__ import annotations

from abc import ABC, abstractmethod
from typing import final

from anusara._contracts.agent_result import AgentResult
from anusara._contracts.execution_input import ExecutionInput


class Agent(ABC):
    """
    Base contract for all agents.

    Agents must implement an async execute method.
    Synchronous work should be wrapped using asyncio.to_thread().
    """

    @final
    async def run(self, execution_input: ExecutionInput) -> AgentResult:
        return await self.execute(execution_input)

    @abstractmethod
    async def execute(self, execution_input: ExecutionInput) -> AgentResult:
        """
        Execute the agent logic.

        Must return an AgentResult.
        """
        raise NotImplementedError


__all__ = ["Agent"]
