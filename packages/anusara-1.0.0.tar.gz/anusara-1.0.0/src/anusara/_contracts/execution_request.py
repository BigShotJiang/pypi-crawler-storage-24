from dataclasses import dataclass, field
from typing import NotRequired, cast

from typing_extensions import TypedDict

from anusara._contracts.graph_definition import GraphDefinition
from anusara._contracts.json_types import JSONValue
from anusara._core.execution_policy import (
    ExecutionPolicy,
    ExecutionPolicyDict,
)

# =========================================================
# External JSON / Dict Contract
# =========================================================


class ExecutionRequestDict(TypedDict):
    request_id: str
    entry_nodes: list[str]
    policy: dict[str, object]

    graph_definition: NotRequired[GraphDefinition | None]
    payload: NotRequired[dict[str, object]]
    metadata: NotRequired[dict[str, object]]


# =========================================================
# Runtime Contract
# =========================================================


@dataclass
class ExecutionRequest:
    """
    External execution contract.

    Represents a fully-defined execution request.
    """

    request_id: str

    # REQUIRED
    entry_nodes: list[str]

    # Optional graph definition (advanced mode)
    graph_definition: GraphDefinition | None = None

    # Execution data
    payload: dict[str, JSONValue] = field(default_factory=dict)
    metadata: dict[str, JSONValue] = field(default_factory=dict)

    # Execution-level policy
    policy: ExecutionPolicy = field(default_factory=ExecutionPolicy)

    # -----------------------------------------------------

    def validate(self) -> None:
        if not self.entry_nodes and self.graph_definition is None:
            raise ValueError(
                "ExecutionRequest must define entry_nodes or graph_definition."
            )

    # -----------------------------------------------------

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "request_id": self.request_id,
            "entry_nodes": cast(JSONValue, self.entry_nodes),
            "graph_definition": cast(JSONValue, self.graph_definition),
            "payload": self.payload,
            "metadata": self.metadata,
            "policy": cast(JSONValue, self.policy.to_dict()),
        }

    # -----------------------------------------------------

    @classmethod
    def from_dict(cls, data: ExecutionRequestDict) -> "ExecutionRequest":
        policy_raw = data["policy"]

        if not isinstance(policy_raw, dict):
            raise TypeError("policy must be dict")

        return cls(
            request_id=data["request_id"],
            entry_nodes=data["entry_nodes"],
            graph_definition=data.get("graph_definition"),
            payload=cast(dict[str, JSONValue], data.get("payload", {})),
            metadata=cast(dict[str, JSONValue], data.get("metadata", {})),
            policy=ExecutionPolicy.from_dict(cast(ExecutionPolicyDict, policy_raw)),
        )


__all__ = [
    "ExecutionRequest",
    "ExecutionRequestDict",
]
