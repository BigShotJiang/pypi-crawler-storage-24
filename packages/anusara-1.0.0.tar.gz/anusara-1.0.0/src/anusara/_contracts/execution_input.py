from dataclasses import dataclass

from anusara._contracts.json_types import JSONValue


@dataclass
class ExecutionInput:
    """
    Structured input passed to agents.
    """

    request_id: str
    payload: dict[str, JSONValue]
    metadata: dict[str, JSONValue]


__all__ = ["ExecutionInput"]
