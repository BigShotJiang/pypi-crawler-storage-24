"""
Internal module: contracts.

Defines core data structures and execution contracts that form the
foundation of the Anusara runtime, including requests, results,
and agent interaction interfaces.

Not part of the public API.
"""
