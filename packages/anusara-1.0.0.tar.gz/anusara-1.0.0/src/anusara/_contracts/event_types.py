# =========================================================
# Event Types (Wire-Level Contract)
# =========================================================


class MutationEventTypes:
    GRAPH_MUTATION_PROPOSED = "graph_mutation_proposed"
    GRAPH_MUTATION_NO_PROPOSAL = "graph_mutation_no_proposal"
    GRAPH_MUTATION_ACCEPTED = "graph_mutation_accepted"
    GRAPH_MUTATION_REJECTED = "graph_mutation_rejected"
    GRAPH_MUTATION_CONFLICT_DETECTED = "graph_mutation_conflict_detected"
    GRAPH_MUTATION_CONFLICT_RESOLVED = "graph_mutation_conflict_resolved"
    GRAPH_MUTATION_EXECUTED = "graph_mutation_executed"
    GRAPH_MUTATION_EXECUTION_FAILED = "graph_mutation_execution_failed"
    MUTATION_EVALUATION_REQUESTED = "mutation_evaluation_requested"


class CoreEventTypes:
    ORCHESTRATION_EVENT = "orchestration_event"
    MUTATION_EVENT = "mutation_event"


class ExecutionEventTypes:
    MAIN_EXECUTION_STARTED = "main_execution_started"
    MAIN_EXECUTION_COMPLETED = "main_execution_completed"
    MAIN_EXECUTION_FAILED = "main_execution_failed"
    MAIN_EXECUTION_PAUSED = "main_execution_paused"

    NODE_EXECUTION_STARTED = "node_execution_started"
    NODE_EXECUTION_COMPLETED = "node_execution_completed"
    NODE_EXECUTION_FAILED = "node_execution_failed"
    NODE_EXECUTION_RETRIED = "node_execution_retried"


__all__ = [
    "MutationEventTypes",
    "CoreEventTypes",
    "ExecutionEventTypes",
]
