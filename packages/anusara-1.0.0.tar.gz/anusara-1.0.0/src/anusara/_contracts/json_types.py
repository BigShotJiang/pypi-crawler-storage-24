# anusara/_contracts/json_types.py

from __future__ import annotations

from typing import TypeAlias

# ---------------------------------------------------------
# JSON Type System
# ---------------------------------------------------------

# Primitive JSON-safe values
JSONPrimitive: TypeAlias = str | int | float | bool | None

# Recursive JSON-safe structure
JSONValue: TypeAlias = JSONPrimitive | list["JSONValue"] | dict[str, "JSONValue"]

# Convenience aliases
JSONObject: TypeAlias = dict[str, JSONValue]
JSONArray: TypeAlias = list[JSONValue]
