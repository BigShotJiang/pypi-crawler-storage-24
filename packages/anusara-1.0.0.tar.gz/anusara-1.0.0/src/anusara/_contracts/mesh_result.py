from dataclasses import dataclass, field

from anusara._contracts.agent_result import AgentResult  # ✅ ADD THIS


@dataclass
class MeshResult:
    """
    Final execution result returned by engine.
    """

    success: bool
    results: dict[str, AgentResult]

    snapshot: dict[str, object] | None = None
    errors: list[str] | None = None
    confidence: float = 0.0
    metadata: dict[str, object] = field(default_factory=dict)


__all__ = ["MeshResult"]
