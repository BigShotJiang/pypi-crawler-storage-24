# anusara/_utils/hashing.py

from __future__ import annotations

import hashlib


def sha256_hex(data: str) -> str:
    """
    Compute SHA256 hex digest for a UTF-8 string.

    Guarantees:
    - Deterministic output
    - Stable encoding (UTF-8)
    - JSON-safe representation (hex string)
    """
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


# ---------------------------------------------------------
# Generic Hash Helper (Optional but useful)
# ---------------------------------------------------------


def sha256_bytes(data: bytes) -> str:
    """
    Compute SHA256 hex digest for raw bytes.

    Useful when input is already serialized or binary.
    """
    return hashlib.sha256(data).hexdigest()
