# anusara/_utils/serialization.py

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import datetime
from typing import cast

from anusara._contracts.json_types import JSONValue

# ---------------------------------------------------------
# JSON Default Serializer
# ---------------------------------------------------------


def _json_default(value: object) -> JSONValue:
    """
    Fallback serializer for unsupported JSON types.

    Currently supports:
    - datetime → ISO 8601 string

    Raises:
        TypeError for unsupported types
    """

    if isinstance(value, datetime):
        return value.isoformat()

    raise TypeError(f"Type not serializable: {type(value).__name__}")


# ---------------------------------------------------------
# Canonical JSON
# ---------------------------------------------------------


def canonical_json(value: JSONValue) -> str:
    """
    Deterministic JSON serialization.

    Guarantees:
    - Stable key ordering (sort_keys=True)
    - No whitespace (compact separators)
    - UTF-8 safe output (ensure_ascii=False)
    - Controlled fallback serialization

    Used for:
    - Hashing (identity, conflict detection)
    - Replay consistency
    - Snapshot comparison
    """

    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=cast(Callable[[object], object], _json_default),
    )
