```{include} ../../ARCHITECTURE.md
```
