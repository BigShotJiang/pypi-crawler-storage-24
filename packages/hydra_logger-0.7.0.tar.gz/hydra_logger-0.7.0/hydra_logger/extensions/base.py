"""
Role: Implements hydra_logger.extensions.base functionality for Hydra Logger.
Used By:
 - Internal `hydra_logger` modules importing this component.
Depends On:
 - abc
 - dataclasses
 - typing
Notes:
 - Implements extension lifecycle or integration logic for base.
"""

from abc import ABC
from dataclasses import dataclass
from typing import Any, Dict, Optional

from .extension_base import ExtensionBase


@dataclass
class ExtensionConfig:
    """Base configuration for extensions."""

    enabled: bool = False
    name: str = ""
    version: str = "0.7.0"
    description: str = ""


class Extension(ExtensionBase, ABC):
    """
    Abstract base class for all Hydra Logger extensions.

    Extensions follow a plug-in/plug-out design:
    - Default disabled for zero overhead
    - Dynamic loading via configuration
    - Sensible defaults when enabled
    - Clear enable/disable semantics
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the extension with configuration.

        Args:
            config: Extension-specific configuration dictionary
        """
        self.config = config or {}
        self._enabled = bool(self.config.get("enabled", False))
        self._name = self.config.get("name", self.__class__.__name__)
        self._version = self.config.get("version", "0.7.0")
        self._description = self.config.get("description", "")
        extension_config = {k: v for k, v in self.config.items() if k != "enabled"}
        super().__init__(enabled=self._enabled, **extension_config)

    def _setup(self) -> None:
        """Compatibility hook that forwards setup to legacy initializer."""
        self._enabled = self.enabled
        self._initialize_config()

    def _initialize_config(self) -> None:
        """Initialize extension-specific configuration. Override in subclasses."""
        pass

    def process(self, data: Any) -> Any:
        """Compatibility default processing path."""
        return data

    def enable(self) -> None:
        """Enable the extension."""
        super().enable()
        self._enabled = True

    def disable(self) -> None:
        """Disable the extension."""
        super().disable()
        self._enabled = False

    def is_enabled(self) -> bool:
        """Check if the extension is enabled."""
        return self.enabled

    def get_name(self) -> str:
        """Get the extension name."""
        return self._name

    def get_version(self) -> str:
        """Get the extension version."""
        return self._version

    def get_description(self) -> str:
        """Get the extension description."""
        return self._description

    def validate_config(self) -> None:
        """
        Validate the extension configuration.
        Override in subclasses to add specific validation.
        """
        if not isinstance(self.config, dict):
            raise ValueError(
                f"Extension config must be a dictionary, got {type(self.config)}"
            )

    def get_config(self) -> Dict[str, Any]:
        """Get the current configuration."""
        return self.config.copy()

    def update_config(
        self, new_config: Optional[Dict[str, Any]] = None, **updates: Any
    ) -> None:
        """Update the extension configuration."""
        super().update_config(new_config, **updates)
        self._enabled = self.enabled

    def __str__(self) -> str:
        """String representation of the extension."""
        status = "enabled" if self._enabled else "disabled"
        return f"{self._name} v{self._version} ({status})"

    def __repr__(self) -> str:
        """Detailed string representation of the extension."""
        return (
            f"{self.__class__.__name__}(name='{self._name}', enabled={self._enabled})"
        )
