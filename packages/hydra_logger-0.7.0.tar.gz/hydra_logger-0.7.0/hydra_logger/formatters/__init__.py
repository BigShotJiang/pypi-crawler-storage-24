"""
Role: Public exports for hydra_logger.formatters; no runtime logic besides import wiring.
Used By:
 - Importers of `hydra_logger.formatters` public API.
Depends On:
 - hydra_logger
Notes:
 - Re-exports the hydra_logger.formatters public API with stable import paths.
"""

# Core formatters
from .base import BaseFormatter
from .colored_formatter import ColoredFormatter
from .json_formatter import JsonLinesFormatter
from .structured_formatter import (
    CsvFormatter,
    GelfFormatter,
    LogstashFormatter,
    SyslogFormatter,
)
from .text_formatter import PlainTextFormatter


def get_formatter(format_type: str, use_colors: bool = False):
    """
    Get the appropriate formatter for a given format type.

    Args:
        format_type: Format type (e.g., 'plain-text', 'json-lines', 'colored')
        use_colors: Whether to use colors (for console output only)

    Returns:
        Formatter instance or None if not found

    Example:
        # Get colored formatter for console
        formatter = get_formatter('colored', use_colors=True)

        # Get plain formatter for file
        formatter = get_formatter('plain-text', use_colors=False)
    """
    if format_type == "plain-text":
        return PlainTextFormatter()
    elif format_type == "colored":
        return ColoredFormatter(use_colors=use_colors)
    elif format_type == "json-lines":
        return JsonLinesFormatter()
    elif format_type == "json":
        return JsonLinesFormatter()
    elif format_type == "csv":
        return CsvFormatter()
    elif format_type == "syslog":
        return SyslogFormatter()
    elif format_type == "gelf":
        return GelfFormatter()
    elif format_type == "logstash":
        return LogstashFormatter()
    else:
        # Default to plain text
        return PlainTextFormatter()


# Export all formatters
__all__ = [
    # Core formatters
    "BaseFormatter",
    "PlainTextFormatter",
    "ColoredFormatter",
    "JsonLinesFormatter",
    "GelfFormatter",
    "LogstashFormatter",
    "CsvFormatter",
    "SyslogFormatter",
    # Utility functions
    "get_formatter",
]
