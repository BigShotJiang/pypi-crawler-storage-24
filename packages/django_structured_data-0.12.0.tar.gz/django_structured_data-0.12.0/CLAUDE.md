## About

django-structured-data is a Django app that generates structured metadata from a single
source of truth. Models define a `structured_data` property returning a JSON-LD dict, and
template tags automatically render that data as JSON-LD `<script>` blocks, Open Graph meta
tags, HTML meta tags, and Twitter Card tags. Published on PyPI as `django-structured-data`.

## Commands

# lint & format
ruff check .
ruff format .

# test (no external Django project needed)
python -m django test structured_data --settings=structured_data.tests

# build
uv build

## Architecture

Django template tag library — models define a `structured_data` property (JSON-LD dict),
template tags render it as JSON-LD, Open Graph, HTML meta, and Twitter Card tags.

structured_data/
  __init__.py          # version (hatch reads from here)
  util.py              # shared helpers (json_encode, build_og_tags, build_meta_tags, format_time)
  tests.py             # all tests (SimpleTestCase, no DB needed)
  templatetags/
    jsonld.py          # {% json_ld_for obj %}
    opengraph.py       # {% og_for obj %}
    meta.py            # {% meta_for obj %}
    twitter.py         # {% twitter_for obj %}

## Key Patterns

- ARTICLE_TYPES and EVENT_TYPES in util.py control @type-specific behavior
- Image can be a string URL or dict with url/width/height/caption
- Author can be a string or dict with name/url
- XSS protection: json_encode escapes <, >, & in JSON-LD output
- Version: bump __version__ in structured_data/__init__.py (hatchling reads it)
