"""Log widget with hard wrapping based on current viewport width."""

from __future__ import annotations

from rich.cells import cell_len, get_character_cell_size
from textual.widgets import Log


class AutoWrapLog(Log):
    """A ``Log`` widget that inserts line breaks to fit the visible width."""

    def __init__(
        self,
        highlight: bool = False,
        max_lines: int | None = None,
        auto_scroll: bool = True,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
        disabled: bool = False,
    ) -> None:
        super().__init__(
            highlight=highlight,
            max_lines=max_lines,
            auto_scroll=auto_scroll,
            name=name,
            id=id,
            classes=classes,
            disabled=disabled,
        )
        self._raw_text = ""
        self._last_wrap_width = 0
        self._rehydrating = False

    def on_mount(self) -> None:
        self._last_wrap_width = self._wrap_width()
        if self._raw_text and self.max_lines is None:
            self._rewrap_from_raw()

    def on_resize(self, event) -> None:
        _ = event
        wrap_width = self._wrap_width()
        if wrap_width <= 1 or wrap_width == self._last_wrap_width:
            return
        self._last_wrap_width = wrap_width
        if self._raw_text and self.max_lines is None:
            self._rewrap_from_raw()

    def clear(self):
        self._raw_text = ""
        self._last_wrap_width = self._wrap_width()
        return super().clear()

    def write(
        self,
        data: str,
        scroll_end: bool | None = None,
    ):
        if not data:
            return self

        if not self._rehydrating and self.max_lines is None:
            self._raw_text += data

        wrapped = self._wrap_for_current_width(data)
        result = super().write(wrapped, scroll_end=scroll_end)
        self._last_wrap_width = self._wrap_width()
        return result

    def _wrap_width(self) -> int:
        width = int(getattr(self.scrollable_content_region, "width", 0) or 0)
        if width <= 0:
            width = int(getattr(self.size, "width", 0) or 0)
        return max(width, 0)

    def _current_line_cells(self) -> int:
        if not self._lines:
            return 0
        return cell_len(self._process_line(self._lines[-1]))

    @staticmethod
    def _char_cells(char: str) -> int:
        cells = int(get_character_cell_size(char))
        return max(cells, 0)

    def _wrap_for_current_width(self, data: str) -> str:
        wrap_width = self._wrap_width()
        if wrap_width <= 1:
            return data
        start_col = self._current_line_cells()
        wrapped, _ = self._wrap_text(data, width=wrap_width, start_col=start_col)
        return wrapped

    def _rewrap_from_raw(self) -> None:
        wrap_width = self._wrap_width()
        if wrap_width <= 1:
            return
        wrapped, _ = self._wrap_text(self._raw_text, width=wrap_width, start_col=0)
        self._rehydrating = True
        try:
            super().clear()
            if wrapped:
                super().write(wrapped)
        finally:
            self._rehydrating = False

    def _wrap_text(self, data: str, *, width: int, start_col: int) -> tuple[str, int]:
        if width <= 1:
            return data, start_col

        col = max(start_col, 0)
        out: list[str] = []
        for char in data:
            if char == "\r":
                continue
            if char == "\n":
                out.append("\n")
                col = 0
                continue

            char_cells = self._char_cells(char)
            if col > 0 and (col + char_cells) > width:
                out.append("\n")
                col = 0

            out.append(char)
            col += char_cells

        return "".join(out), col
