"""."""

import argparse

from typing import Sequence

from pydantic import BaseModel
from rich_argparse import RawTextRichHelpFormatter


class AssociationStudioCli(BaseModel):
    """Association Studio CLI."""

    verbosity: int = 0


PROG = 'association-studio'


def get_cli(args: Sequence[str] | None = None) -> AssociationStudioCli:
    cli = AssociationStudioCli()

    description = """
    [blue]Usage:[/blue] association-studio \\[[dark_orange]Options[/dark_orange]]

        The application facilitates an interactive exploration of the association metrics.

        The main window offers a top-view of a prediction and detection for which we 
        can compute the association metrics supported in the kinematic tracker.

        The main window responds to several [italic]keystrokes[/italic]:
          - `c` switch between reporting mode for the [italic]c[/italic]oordinates.
          - `m` switch between association [italic]m[/italic]etrics.
          - `O` (Shift + O) move the probe box to [italic]o[/italic]rigin reference box.
          - `R` (Shift + R) [italic]r[/italic]otate the probe box by 30 degrees.
          - `1` set unit size for both bounding boxes: reference and probe.

        The main window implements two [italic]mouse actions[/italic]:
          - move the track (transparent box).
          - rotate the track.
        """
    prs = argparse.ArgumentParser(
        PROG, argparse.SUPPRESS, description, formatter_class=RawTextRichHelpFormatter
    )
    prs.add_argument('--verbosity', '-v', action='count', help=f'Verbosity {{{cli.verbosity}}}')
    prs.parse_args(args=args, namespace=cli)
    return cli
