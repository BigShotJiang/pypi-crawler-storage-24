"""."""

import pytest

from kinematic_tracker.association.association_metric import AssociationMetric
from matplotlib.backend_bases import KeyEvent
from pytest_mock import MockerFixture

from association_studio.app.front import AssociationFrontend
from association_studio.app.show_coo_mode import ShowCooMode


def test_coo_mode(front: AssociationFrontend, key_event: KeyEvent) -> None:
    front.on_key(key_event)
    assert front.back.show_coo_mode == ShowCooMode.TRANSLATION
    assert front.text.get_text() == 'xy 0.300 0.700'


def test_metric(front: AssociationFrontend, key_event: KeyEvent) -> None:
    key_event.key = 'm'
    front.on_key(key_event)
    assert front.back.metric_mode.metric == AssociationMetric.GIOU_YAW
    assert front.ax_boxes.get_title() == 'giou-yaw 0.6254'


def test_origin(front: AssociationFrontend, key_event: KeyEvent, mocker: MockerFixture) -> None:
    key_event.key = 'O'
    mock_update = mocker.patch.object(front.back, 'update_horizontal_bar_container')
    front.on_key(key_event)
    mock_update.assert_called_once_with(front.bar)
    assert front.back.score_driver.scores == pytest.approx(1.0)
    assert front.ax_boxes.get_title() == 'giou-axes-aligned 1.0000'


def test_rotate(front: AssociationFrontend, key_event: KeyEvent, mocker: MockerFixture) -> None:
    key_event.key = 'R'
    mock_update = mocker.patch.object(front.back, 'update_horizontal_bar_container')
    front.on_key(key_event)
    mock_update.assert_called_once_with(front.bar)
    ref = 0.75054467, 0.7380545137863613, 0.98525787, 0.99608083
    assert front.back.score_driver.scores == pytest.approx(ref)
    assert front.ax_boxes.get_title() == 'giou-axes-aligned 0.7505'


def test_set_unit(front: AssociationFrontend, key_event: KeyEvent, mocker: MockerFixture) -> None:
    key_event.key = '1'
    mock_update = mocker.patch.object(front.back, 'update_horizontal_bar_container')
    front.on_key(key_event)
    mock_update.assert_called_once_with(front.bar)
    ref = 0.46363659, 0.50848591, 0.98208623, 0.98493841
    assert front.back.score_driver.scores == pytest.approx(ref)
    assert front.ax_boxes.get_title() == 'giou-axes-aligned 0.4636'
