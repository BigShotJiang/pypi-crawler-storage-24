import setuptools 


with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()


__version__ = "0.0.2"

REPO_NAME = "NexusView"
AUTHOR_USER_NAME = "Musharraf-Bubere"
AUTHOR_EMAIL = "musharrafbubere007@gmail.com"
SRC_REPO = "nexusview-musharraf"

setuptools.setup(
    name=SRC_REPO,
    version=__version__,
    author=AUTHOR_USER_NAME,
    author_email=AUTHOR_EMAIL,
    description="A small python package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url=f"http://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}",
    project_urls={
        "Bug Tracker": f"http://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}/issues",
    },
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src")
)