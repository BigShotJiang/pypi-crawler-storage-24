class GeneratorException(Exception):
    pass
