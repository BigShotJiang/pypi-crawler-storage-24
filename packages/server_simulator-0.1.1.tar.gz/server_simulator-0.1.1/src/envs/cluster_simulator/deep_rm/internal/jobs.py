import typing as tp

import numpy as np
import numpy.typing as npt
from typing import TypeAlias
from typing_extensions import Unpack
from src.envs.cluster_simulator.base.internal.job import (
    Job,
    JobCollection,
    Status,
    JobCollectionConvertor,
)
from src.envs.cluster_simulator.deep_rm.internal.custom_type import (
    _JOB_TYPE,
    _JOBS_TYPE,
)

DeepRMJobsArgs: TypeAlias = tuple[_JOBS_TYPE, npt.NDArray[int], npt.NDArray[int]]


class DeepRMJobSlot(Job[_JOB_TYPE]):
    def __init__(self, usage: _JOB_TYPE, status: Status, arrival_time: int):
        self.status = status
        self._usage = usage
        self.arrival_time = arrival_time
        self.length = self._calculate_job_length(self._usage)
        self.run_time = 0

    @property
    def usage(self) -> _JOB_TYPE:
        return self._usage

    @classmethod
    def _calculate_job_length(cls, job: _JOB_TYPE) -> int:
        active = np.any(job > 0, axis=1)
        idx = np.where(active)[0]
        return int(idx[-1] - idx[0] + 1) if idx.size > 0 else 0


class DeepRMJobs(JobCollection[npt.NDArray[_JOB_TYPE]]):
    def __init__(self, *args: Unpack[DeepRMJobsArgs]) -> None:
        self._job_slots, self._job_status, self._job_arrivals_time = args
        n_jobs_slot, n_job_status, n_arrival = (
            self._job_slots.shape[0],
            self._job_status.shape[0],
            self._job_arrivals_time.shape[0],
        )

        assert n_jobs_slot == n_job_status, (
            f"Number of jobs slot ({n_jobs_slot}) should be equal to number of job status ({n_job_status})"
        )
        assert n_jobs_slot == n_arrival, (
            f"Number of jobs slot ({n_jobs_slot}) should be equal to number of job arrival array ({n_arrival})"
        )

        self._jobs = [
            DeepRMJobSlot(slot_usage, status, arrival_time)
            for slot_usage, status, arrival_time in zip(
                self._job_slots[:], self._job_status, self._job_arrivals_time
            )
        ]

    def __len__(self) -> int:
        return len(self._jobs)

    def __getitem__(self, item: int) -> DeepRMJobSlot:
        return self._jobs[item]

    def __iter__(self) -> tp.Iterable[DeepRMJobSlot]:
        return iter(self._jobs)


class DeepRMJobsConvertor(JobCollectionConvertor[_JOB_TYPE, DeepRMJobsArgs]):
    def to_representation(self, value: DeepRMJobs) -> DeepRMJobsArgs:
        status = np.array([j.status for j in value._jobs])
        arrivals_time = np.array([j.arrival_time for j in value._jobs])
        return (value._job_slots, status, arrivals_time)
