"""Global registry for default sinks and configuration."""

from __future__ import annotations

from ..config import TraceConfig
from ..sinks.base import BaseSink

_global_sinks: tuple[BaseSink, ...] = ()
_global_config: TraceConfig | None = None
_setup_done: bool = False


def set_global_sinks(sinks: tuple[BaseSink, ...]) -> None:
    global _global_sinks
    _global_sinks = sinks


def get_global_sinks() -> tuple[BaseSink, ...]:
    return _global_sinks


def set_global_config(config: TraceConfig | None) -> None:
    global _global_config
    _global_config = config


def get_global_config() -> TraceConfig | None:
    return _global_config


def mark_setup_done() -> None:
    global _setup_done
    _setup_done = True


def is_setup_done() -> bool:
    return _setup_done


def reset_globals() -> None:
    """Reset all global state. Useful for tests."""
    global _global_sinks, _global_config, _setup_done
    _global_sinks = ()
    _global_config = None
    _setup_done = False
