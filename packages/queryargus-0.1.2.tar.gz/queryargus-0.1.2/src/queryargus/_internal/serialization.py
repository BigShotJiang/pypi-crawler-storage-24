"""Trace serialization helpers."""

from __future__ import annotations

from datetime import datetime

from ..models import QueryEvent, ScopeRecord, SourceLocation, Trace


def serialize_trace(trace: Trace) -> dict[str, object]:
    """Serialize a trace into a JSON-friendly dictionary."""

    return {
        "schema_version": trace.schema_version,
        "trace_id": trace.trace_id,
        "name": trace.name,
        "entrypoint": {
            "kind": trace.entrypoint.kind,
            "name": trace.entrypoint.name,
            "module": trace.entrypoint.module,
            "qualname": trace.entrypoint.qualname,
        },
        "status": trace.status,
        "started_at": _serialize_dt(trace.started_at),
        "ended_at": _serialize_dt(trace.ended_at),
        "duration_ms": trace.duration_ms,
        "metadata": dict(trace.metadata),
        "error": trace.error,
        "queries": [serialize_query(query) for query in trace.queries],
        "scopes": [serialize_scope(scope) for scope in trace.scopes],
    }


def serialize_query(query: QueryEvent) -> dict[str, object]:
    """Serialize a query event."""

    return {
        "event_id": query.event_id,
        "ordinal": query.ordinal,
        "adapter": query.adapter,
        "db_system": query.db_system,
        "statement": query.statement,
        "fingerprint": query.fingerprint,
        "operation": query.operation,
        "duration_ms": query.duration_ms,
        "rowcount": query.rowcount,
        "success": query.success,
        "error": query.error,
        "parameter_count": query.parameter_count,
        "parameters": query.parameters,
        "parameters_redacted": query.parameters_redacted,
        "scope_path": list(query.scope_path),
        "scope_kind": query.scope_kind,
        "source": serialize_source(query.source),
    }


def serialize_scope(scope: ScopeRecord) -> dict[str, object]:
    """Serialize a scope record."""

    return {
        "scope_id": scope.scope_id,
        "name": scope.name,
        "parent_id": scope.parent_id,
        "depth": scope.depth,
        "kind": scope.kind,
        "started_at": _serialize_dt(scope.started_at),
        "ended_at": _serialize_dt(scope.ended_at),
        "duration_ms": scope.duration_ms,
        "metadata": dict(scope.metadata),
        "error": scope.error,
    }


def serialize_source(source: SourceLocation | None) -> dict[str, object] | None:
    """Serialize source location data."""

    if source is None:
        return None

    return {"file": source.file, "line": source.line}


def _serialize_dt(value: datetime | None) -> str | None:
    if value is None:
        return None

    return value.isoformat().replace("+00:00", "Z")
