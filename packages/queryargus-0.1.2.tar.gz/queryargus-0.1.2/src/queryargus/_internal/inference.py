"""Best-effort inference for query source and scope."""

from __future__ import annotations

import inspect
import sysconfig
from dataclasses import dataclass
from pathlib import Path
from types import FrameType

from ..models import SourceLocation

_QUERYARGUS_ROOT = Path(__file__).resolve().parents[1]
_STDLIB_ROOT = Path(sysconfig.get_paths()["stdlib"]).resolve()
_KNOWN_INFRA_PREFIXES = (
    "sqlalchemy",
    "fastapi",
    "starlette",
    "uvicorn",
    "asyncpg",
    "psycopg",
)


@dataclass(slots=True, frozen=True)
class InferredQueryContext:
    """Best-effort app frame information for a query event."""

    source: SourceLocation | None
    scope_path: list[str]


def infer_query_context() -> InferredQueryContext:
    """Infer a user-facing source location and scope from the current stack."""

    frame = inspect.currentframe()
    try:
        candidate = _find_user_frame(frame)
        if candidate is None:
            return InferredQueryContext(source=None, scope_path=[])

        return InferredQueryContext(
            source=SourceLocation(file=candidate.f_code.co_filename, line=candidate.f_lineno),
            scope_path=[_build_scope_name(candidate)],
        )
    finally:
        del frame


def _find_user_frame(frame: FrameType | None) -> FrameType | None:
    candidates: list[FrameType] = []
    current = frame.f_back if frame is not None else None

    while current is not None:
        if not _is_queryargus_frame(current):
            candidates.append(current)
        current = current.f_back

    if not candidates:
        return None

    preferred = [
        candidate
        for candidate in candidates
        if not _is_stdlib_frame(candidate) and not _is_site_packages_frame(candidate)
    ]
    if preferred:
        return preferred[0]

    fallback = [candidate for candidate in candidates if not _is_infra_frame(candidate)]
    if fallback:
        return fallback[0]

    return candidates[0]


def _is_queryargus_frame(frame: FrameType) -> bool:
    module_name = str(frame.f_globals.get("__name__") or "")
    filename = frame.f_code.co_filename

    if module_name == "queryargus" or module_name.startswith("queryargus."):
        return True

    return _is_relative_to(filename, _QUERYARGUS_ROOT)


def _is_stdlib_frame(frame: FrameType) -> bool:
    return _is_relative_to(frame.f_code.co_filename, _STDLIB_ROOT)


def _is_site_packages_frame(frame: FrameType) -> bool:
    filename = frame.f_code.co_filename
    return "site-packages" in filename or "dist-packages" in filename


def _is_infra_frame(frame: FrameType) -> bool:
    module_name = str(frame.f_globals.get("__name__") or "")
    return module_name.startswith(_KNOWN_INFRA_PREFIXES)


def _is_relative_to(filename: str, root: Path) -> bool:
    try:
        Path(filename).resolve().relative_to(root)
    except (ValueError, OSError):
        return False

    return True


def _build_scope_name(frame: FrameType) -> str:
    module_name = str(frame.f_globals.get("__name__") or "")
    module_label = (
        module_name.split(".")[-1] if module_name else Path(frame.f_code.co_filename).stem
    )
    callable_label = _callable_name(frame)

    if module_label and callable_label:
        return f"{module_label}.{callable_label}"

    return callable_label or module_label or "unknown"


def _callable_name(frame: FrameType) -> str:
    code_name = frame.f_code.co_name

    instance = frame.f_locals.get("self")
    if instance is not None:
        return f"{type(instance).__name__}.{code_name}"

    cls = frame.f_locals.get("cls")
    if isinstance(cls, type):
        return f"{cls.__name__}.{code_name}"

    return code_name
