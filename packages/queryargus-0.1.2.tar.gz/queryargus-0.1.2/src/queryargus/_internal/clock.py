"""Clock helpers."""

from __future__ import annotations

from datetime import datetime, timezone
from time import perf_counter_ns


def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp."""

    return datetime.now(timezone.utc)


def monotonic_ns() -> int:
    """Return a monotonic nanosecond clock value."""

    return perf_counter_ns()
