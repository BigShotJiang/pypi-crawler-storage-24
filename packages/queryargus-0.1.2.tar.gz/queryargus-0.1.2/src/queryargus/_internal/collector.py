"""Event collection helpers."""

from __future__ import annotations

from ..models import QueryEvent
from .context import current_scope_path, get_current_trace
from .fingerprint import normalize_statement
from .inference import infer_query_context


def record_query(event: QueryEvent) -> QueryEvent | None:
    """Attach a query event to the current trace, if any."""

    trace = get_current_trace()
    if trace is None:
        return None

    should_infer_context = (
        trace.config.capture_source and event.source is None
    ) or not event.scope_path
    if should_infer_context:
        inferred_context = infer_query_context()
        if trace.config.capture_source and event.source is None:
            event.source = inferred_context.source
    else:
        inferred_context = None

    if not event.scope_path:
        event.scope_path = current_scope_path()

    if event.scope_path:
        event.scope_kind = "manual"
    elif inferred_context is not None and inferred_context.scope_path:
        event.scope_path = inferred_context.scope_path
        event.scope_kind = "inferred"
    else:
        event.scope_kind = "none"

    if not event.fingerprint:
        event.fingerprint = normalize_statement(event.statement)

    return trace.add_query(event)
