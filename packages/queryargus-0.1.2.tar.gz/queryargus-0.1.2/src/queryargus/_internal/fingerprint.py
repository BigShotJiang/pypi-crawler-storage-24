"""Statement normalization helpers."""

from __future__ import annotations

import re

_SINGLE_QUOTED = re.compile(r"'(?:''|[^'])*'")
_DOUBLE_QUOTED = re.compile(r'"(?:[""]|[^"])*"')
_NUMBERS = re.compile(r"\b\d+(?:\.\d+)?\b")
_WHITESPACE = re.compile(r"\s+")


def normalize_statement(statement: str) -> str:
    """Return a normalized fingerprint for a SQL statement."""

    normalized = _SINGLE_QUOTED.sub("?", statement)
    normalized = _DOUBLE_QUOTED.sub("?", normalized)
    normalized = _NUMBERS.sub("?", normalized)
    normalized = _WHITESPACE.sub(" ", normalized).strip()
    return normalized.lower()
