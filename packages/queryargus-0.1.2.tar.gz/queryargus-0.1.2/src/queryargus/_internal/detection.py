"""Declarative registry for adapter and framework auto-detection.

New adapters/integrations register themselves here instead of
requiring changes to ``setup.py``.  Detection functions must be
lightweight (no heavy imports) so they can run even when the
underlying dependency is not installed.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass(slots=True, frozen=True)
class AdapterEntry:
    """Pairs a detection predicate with a lazy instrument function."""

    name: str
    can_handle: Callable[[Any], bool]
    import_path: str
    function_name: str = "instrument"


@dataclass(slots=True, frozen=True)
class FrameworkEntry:
    """Pairs a detection predicate with a lazy instrument function."""

    name: str
    can_handle: Callable[[Any], bool]
    import_path: str
    function_name: str


# ── detection helpers (pure, no heavy imports) ───────────────


def _is_sqlalchemy(target: Any) -> bool:
    cls_name = type(target).__name__
    module = type(target).__module__ or ""
    return "sqlalchemy" in module or cls_name in ("Engine", "AsyncEngine")


def _is_fastapi(app: Any) -> bool:
    module = type(app).__module__ or ""
    return "fastapi" in module or type(app).__name__ == "FastAPI"


def _is_starlette(app: Any) -> bool:
    module = type(app).__module__ or ""
    return "starlette" in module or type(app).__name__ == "Starlette"


def _is_psycopg(target: Any) -> bool:
    module = type(target).__module__ or ""
    cls_name = type(target).__name__
    return "psycopg" in module or cls_name in ("Connection", "AsyncConnection")


def _is_asyncpg(target: Any) -> bool:
    module = type(target).__module__ or ""
    cls_name = type(target).__name__
    return "asyncpg" in module or cls_name in ("Connection", "PoolConnectionProxy")


# ── registries ───────────────────────────────────────────────

ADAPTER_REGISTRY: list[AdapterEntry] = [
    AdapterEntry(
        name="sqlalchemy",
        can_handle=_is_sqlalchemy,
        import_path="queryargus.adapters.sqlalchemy",
    ),
    AdapterEntry(
        name="psycopg",
        can_handle=_is_psycopg,
        import_path="queryargus.adapters.psycopg",
    ),
    AdapterEntry(
        name="asyncpg",
        can_handle=_is_asyncpg,
        import_path="queryargus.adapters.asyncpg",
    ),
]

FRAMEWORK_REGISTRY: list[FrameworkEntry] = [
    FrameworkEntry(
        name="fastapi",
        can_handle=_is_fastapi,
        import_path="queryargus.integrations.fastapi",
        function_name="instrument_fastapi",
    ),
    FrameworkEntry(
        name="starlette",
        can_handle=_is_starlette,
        import_path="queryargus.integrations.starlette",
        function_name="instrument_starlette",
    ),
]
