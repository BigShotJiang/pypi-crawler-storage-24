"""Private internals for QueryArgus."""
