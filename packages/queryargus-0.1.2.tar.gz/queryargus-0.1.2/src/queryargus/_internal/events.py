"""Helpers to build normalized events."""

from __future__ import annotations

from typing import Any

from ..models import QueryEvent
from .fingerprint import normalize_statement
from .ids import new_id


def build_query_event(
    *,
    adapter: str,
    statement: str,
    duration_ms: float,
    success: bool,
    db_system: str | None = None,
    operation: str | None = None,
    rowcount: int | None = None,
    error: str | None = None,
    parameters: Any = None,
) -> QueryEvent:
    """Build a normalized query event."""

    return QueryEvent(
        event_id=new_id("qry"),
        adapter=adapter,
        statement=statement,
        fingerprint=normalize_statement(statement),
        duration_ms=duration_ms,
        success=success,
        db_system=db_system,
        operation=operation,
        rowcount=rowcount,
        error=error,
        parameter_count=_parameter_count(parameters),
        parameters=None,
        parameters_redacted=True,
    )


def _parameter_count(parameters: Any) -> int | None:
    if parameters is None:
        return 0

    if isinstance(parameters, dict):
        return len(parameters)

    if isinstance(parameters, (list, tuple)):
        return len(parameters)

    return None
