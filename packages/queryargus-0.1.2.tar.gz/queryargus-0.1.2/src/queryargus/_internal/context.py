"""Execution context storage for traces and scopes."""

from __future__ import annotations

from contextvars import ContextVar, Token
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import ScopeRecord, Trace

_current_trace: ContextVar["Trace | None"] = ContextVar("queryargus_current_trace", default=None)
_current_scopes: ContextVar[tuple["ScopeRecord", ...]] = ContextVar(
    "queryargus_current_scopes",
    default=(),
)


def get_current_trace() -> "Trace | None":
    return _current_trace.get()


def set_current_trace(trace: "Trace | None") -> Token["Trace | None"]:
    return _current_trace.set(trace)


def reset_current_trace(token: Token["Trace | None"]) -> None:
    _current_trace.reset(token)


def get_current_scopes() -> tuple["ScopeRecord", ...]:
    return _current_scopes.get()


def set_current_scopes(scopes: tuple["ScopeRecord", ...]) -> Token[tuple["ScopeRecord", ...]]:
    return _current_scopes.set(scopes)


def reset_current_scopes(token: Token[tuple["ScopeRecord", ...]]) -> None:
    _current_scopes.reset(token)


def current_scope_path() -> list[str]:
    return [scope.name for scope in _current_scopes.get()]
