"""One-liner configuration for QueryArgus."""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import Any

from ._internal.registry import (
    mark_setup_done,
    reset_globals,
    set_global_config,
    set_global_sinks,
)
from .config import TraceConfig
from .sinks.base import BaseSink
from .sinks.jsonl import JsonlSink
from .sinks.memory import MemorySink

_SINK_SHORTCUTS: dict[str, type[BaseSink]] = {
    "jsonl": JsonlSink,
    "memory": MemorySink,
}

_DEFAULT_JSONL_PATH = Path("traces/queryargus.jsonl")


def setup(
    *,
    sink: str | BaseSink | Iterable[BaseSink] | None = None,
    adapter: Any = None,
    framework: Any = None,
    config: TraceConfig | None = None,
    output: str | Path | None = None,
) -> None:
    """Configure QueryArgus in a single call.

    Parameters
    ----------
    sink:
        Where finished traces are persisted.
        Accepts ``"jsonl"``, ``"memory"``, a ``BaseSink`` instance,
        or an iterable of sinks.  Defaults to ``"jsonl"`` when omitted.
    adapter:
        Database engine or connection to instrument.
        A SQLAlchemy ``Engine`` / ``AsyncEngine`` is auto-detected.
    framework:
        Web framework application instance.
        FastAPI and Starlette apps are auto-detected.
    config:
        Optional ``TraceConfig`` applied globally.
    output:
        File path for the JSONL sink.  Only used when ``sink="jsonl"``
        or when *sink* is omitted.
    """
    resolved_sinks = _resolve_sinks(sink, output)
    set_global_sinks(resolved_sinks)
    set_global_config(config)

    if adapter is not None:
        _instrument_adapter(adapter)

    if framework is not None:
        _instrument_framework(framework, resolved_sinks, config)

    mark_setup_done()


def teardown() -> None:
    """Reset all global state set by :func:`setup`.

    Useful for test isolation.
    """
    reset_globals()


# ── sink resolution ─────────────────────────────────────────────


def _resolve_sinks(
    sink: str | BaseSink | Iterable[BaseSink] | None,
    output: str | Path | None,
) -> tuple[BaseSink, ...]:
    if sink is None:
        path = Path(output) if output else _DEFAULT_JSONL_PATH
        return (JsonlSink(path),)

    if isinstance(sink, str):
        return (_sink_from_shortcut(sink, output),)

    if isinstance(sink, BaseSink):
        return (sink,)

    return tuple(sink)


def _sink_from_shortcut(name: str, output: str | Path | None) -> BaseSink:
    lowered = name.lower()

    if lowered not in _SINK_SHORTCUTS:
        valid = ", ".join(sorted(_SINK_SHORTCUTS))
        raise ValueError(f"unknown sink shortcut {name!r}; valid options: {valid}")

    cls = _SINK_SHORTCUTS[lowered]

    if cls is JsonlSink:
        path = Path(output) if output else _DEFAULT_JSONL_PATH
        return JsonlSink(path)

    return cls()


# ── adapter detection ────────────────────────────────────────────


def _instrument_adapter(target: Any) -> None:
    from importlib import import_module

    from ._internal.detection import ADAPTER_REGISTRY

    for entry in ADAPTER_REGISTRY:
        if entry.can_handle(target):
            module = import_module(entry.import_path)
            getattr(module, entry.function_name)(target)
            return

    supported = ", ".join(e.name for e in ADAPTER_REGISTRY)
    raise TypeError(
        f"cannot auto-detect adapter for {type(target).__name__}; supported: {supported}"
    )


# ── framework detection ──────────────────────────────────────────


def _instrument_framework(
    app: Any,
    sinks: tuple[BaseSink, ...],
    config: TraceConfig | None,
) -> None:
    from importlib import import_module

    from ._internal.detection import FRAMEWORK_REGISTRY

    for entry in FRAMEWORK_REGISTRY:
        if entry.can_handle(app):
            module = import_module(entry.import_path)
            getattr(module, entry.function_name)(app, sink=sinks, config=config)
            return

    supported = ", ".join(e.name for e in FRAMEWORK_REGISTRY)
    raise TypeError(
        f"cannot auto-detect framework for {type(app).__name__}; supported: {supported}"
    )
