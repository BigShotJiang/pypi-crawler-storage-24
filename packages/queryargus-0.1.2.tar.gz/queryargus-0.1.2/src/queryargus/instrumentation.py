"""Low-code helpers to add business scopes around object methods."""

from __future__ import annotations

import inspect
from collections.abc import Callable
from functools import wraps
from typing import Any, TypeVar, cast

from .scope import trace_scope

F = TypeVar("F", bound=Callable[..., Any])


def instrument_object_methods(
    instance: object,
    *,
    namespace: str | None = None,
    include_private: bool = False,
) -> object:
    """Wrap public instance methods with `trace_scope()` in place."""

    for attribute_name in dir(instance):
        if not include_private and attribute_name.startswith("_"):
            continue

        attribute = getattr(instance, attribute_name, None)
        if not inspect.ismethod(attribute):
            continue

        if getattr(attribute, "__queryargus_scope_wrapped__", False):
            continue

        scope_name = _resolve_scope_name(instance, attribute_name, namespace=namespace)
        setattr(instance, attribute_name, _wrap_method(attribute, scope_name))

    return instance


def trace_methods(
    namespace: str | None = None,
    *,
    include_private: bool = False,
) -> Callable[[type[Any]], type[Any]]:
    """Class decorator to wrap methods with `trace_scope()` automatically."""

    def decorator(cls: type[Any]) -> type[Any]:
        resolved_namespace = namespace or cls.__name__

        for attribute_name, attribute in list(cls.__dict__.items()):
            if not include_private and attribute_name.startswith("_"):
                continue
            if not callable(attribute):
                continue
            if getattr(attribute, "__queryargus_scope_wrapped__", False):
                continue

            scope_name = f"{resolved_namespace}.{attribute_name}"
            setattr(cls, attribute_name, _wrap_method(attribute, scope_name))

        return cls

    return decorator


def _resolve_scope_name(instance: object, attribute_name: str, *, namespace: str | None) -> str:
    if namespace:
        return f"{namespace}.{attribute_name}"

    return f"{type(instance).__name__}.{attribute_name}"


def _wrap_method(method: F, scope_name: str) -> F:
    if inspect.iscoroutinefunction(method):

        @wraps(method)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            with trace_scope(scope_name):
                return await method(*args, **kwargs)

        cast(Any, async_wrapper).__queryargus_scope_wrapped__ = True
        return async_wrapper  # type: ignore[return-value]

    @wraps(method)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        with trace_scope(scope_name):
            return method(*args, **kwargs)

    cast(Any, wrapper).__queryargus_scope_wrapped__ = True
    return wrapper  # type: ignore[return-value]
