"""psycopg (v3) adapter via monkey-patching."""

from __future__ import annotations

from typing import Any, cast

from .._internal.clock import monotonic_ns
from .._internal.collector import record_query
from .._internal.events import build_query_event


def instrument(connection: Any) -> Any:
    """Patch a psycopg connection so every query is captured.

    Works with both sync ``psycopg.Connection`` and async
    ``psycopg.AsyncConnection`` (patches the underlying cursor
    factories).  Safe to call multiple times on the same connection.
    """

    if getattr(connection, "_queryargus_instrumented", False):
        return connection

    _patch_cursor_class(connection)
    cast(Any, connection)._queryargus_instrumented = True
    return connection


def _patch_cursor_class(connection: Any) -> None:
    """Patch ``execute`` on the connection's cursor class."""

    cursor_factory = getattr(connection, "cursor_factory", None)
    if cursor_factory is None:
        return

    if getattr(cursor_factory, "_queryargus_patched", False):
        return

    original_execute = cursor_factory.execute

    import inspect

    if inspect.iscoroutinefunction(original_execute):

        async def patched_execute_async(
            self: Any,
            query: Any,
            params: Any = None,
            **kwargs: Any,
        ) -> Any:
            start_ns = monotonic_ns()
            success = True
            error_msg: str | None = None
            try:
                result = await original_execute(self, query, params, **kwargs)
                return result
            except Exception as exc:
                success = False
                error_msg = f"{type(exc).__name__}: {exc}"
                raise
            finally:
                duration_ms = (monotonic_ns() - start_ns) / 1_000_000
                event = build_query_event(
                    adapter="psycopg",
                    db_system="postgresql",
                    statement=str(query),
                    duration_ms=duration_ms,
                    success=success,
                    error=error_msg,
                    rowcount=getattr(self, "rowcount", None),
                    parameters=params,
                )
                record_query(event)

        patched_execute: Any = patched_execute_async

    else:

        def patched_execute_sync(
            self: Any,
            query: Any,
            params: Any = None,
            **kwargs: Any,
        ) -> Any:
            start_ns = monotonic_ns()
            success = True
            error_msg: str | None = None
            try:
                result = original_execute(self, query, params, **kwargs)
                return result
            except Exception as exc:
                success = False
                error_msg = f"{type(exc).__name__}: {exc}"
                raise
            finally:
                duration_ms = (monotonic_ns() - start_ns) / 1_000_000
                event = build_query_event(
                    adapter="psycopg",
                    db_system="postgresql",
                    statement=str(query),
                    duration_ms=duration_ms,
                    success=success,
                    error=error_msg,
                    rowcount=getattr(self, "rowcount", None),
                    parameters=params,
                )
                record_query(event)

        patched_execute = patched_execute_sync

    cast(Any, cursor_factory).execute = patched_execute
    cast(Any, cursor_factory)._queryargus_patched = True
