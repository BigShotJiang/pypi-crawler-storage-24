"""asyncpg adapter via monkey-patching."""

from __future__ import annotations

from typing import Any, cast

from .._internal.clock import monotonic_ns
from .._internal.collector import record_query
from .._internal.events import build_query_event

_PATCHED_METHODS = ("fetch", "fetchrow", "fetchval", "execute")


def instrument(connection: Any) -> Any:
    """Patch an asyncpg connection so every query is captured.

    Patches ``fetch``, ``fetchrow``, ``fetchval`` and ``execute``.
    Safe to call multiple times on the same connection.
    """

    if getattr(connection, "_queryargus_instrumented", False):
        return connection

    for method_name in _PATCHED_METHODS:
        original = getattr(connection, method_name, None)
        if original is None:
            continue
        if getattr(original, "_queryargus_wrapped", False):
            continue

        wrapped = _make_wrapper(original, method_name)
        setattr(connection, method_name, wrapped)

    cast(Any, connection)._queryargus_instrumented = True
    return connection


def _make_wrapper(original: Any, method_name: str) -> Any:
    """Create an async wrapper that captures query timing and metadata."""

    operation = "select" if method_name.startswith("fetch") else None

    async def wrapper(query: str, *args: Any, **kwargs: Any) -> Any:
        start_ns = monotonic_ns()
        success = True
        error_msg: str | None = None
        result: Any = None
        try:
            result = await original(query, *args, **kwargs)
            return result
        except Exception as exc:
            success = False
            error_msg = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            duration_ms = (monotonic_ns() - start_ns) / 1_000_000
            rowcount = len(result) if isinstance(result, list) else None
            event = build_query_event(
                adapter="asyncpg",
                db_system="postgresql",
                statement=str(query),
                duration_ms=duration_ms,
                success=success,
                error=error_msg,
                operation=operation,
                rowcount=rowcount,
                parameters=args if args else None,
            )
            record_query(event)

    cast(Any, wrapper)._queryargus_wrapped = True
    wrapper.__name__ = method_name
    wrapper.__qualname__ = f"asyncpg_wrapper.{method_name}"
    return wrapper
