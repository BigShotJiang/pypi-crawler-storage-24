"""SQLAlchemy adapter."""

from __future__ import annotations

from typing import Any

from .._internal.clock import monotonic_ns
from .._internal.collector import record_query
from .._internal.events import build_query_event


def instrument(target: Any) -> Any:
    """Install SQLAlchemy event listeners on an engine or async engine."""

    from sqlalchemy import event

    engine = getattr(target, "sync_engine", target)
    if getattr(engine, "_queryargus_instrumented", False):
        return target

    def before_cursor_execute(
        conn: Any,
        cursor: Any,
        statement: str,
        parameters: Any,
        context: Any,
        executemany: bool,
    ) -> None:
        del conn, cursor, statement, parameters, executemany
        context._queryargus_start_ns = monotonic_ns()

    def after_cursor_execute(
        conn: Any,
        cursor: Any,
        statement: str,
        parameters: Any,
        context: Any,
        executemany: bool,
    ) -> None:
        del executemany
        start_ns = getattr(context, "_queryargus_start_ns", None)
        duration_ms = 0.0 if start_ns is None else (monotonic_ns() - start_ns) / 1_000_000
        event_obj = build_query_event(
            adapter="sqlalchemy",
            db_system=getattr(getattr(conn, "dialect", None), "name", None),
            statement=statement,
            duration_ms=duration_ms,
            success=True,
            rowcount=getattr(cursor, "rowcount", None),
            parameters=parameters,
        )
        record_query(event_obj)

    def handle_error(exception_context: Any) -> None:
        execution_context = getattr(exception_context, "execution_context", None)
        start_ns = getattr(execution_context, "_queryargus_start_ns", None)
        duration_ms = 0.0 if start_ns is None else (monotonic_ns() - start_ns) / 1_000_000
        event_obj = build_query_event(
            adapter="sqlalchemy",
            db_system=getattr(getattr(exception_context.connection, "dialect", None), "name", None),
            statement=exception_context.statement or "",
            duration_ms=duration_ms,
            success=False,
            error=str(exception_context.original_exception),
            parameters=exception_context.parameters,
        )
        record_query(event_obj)

    event.listens_for(engine, "before_cursor_execute")(before_cursor_execute)
    event.listens_for(engine, "after_cursor_execute")(after_cursor_execute)
    event.listens_for(engine, "handle_error")(handle_error)

    engine._queryargus_instrumented = True
    return target
