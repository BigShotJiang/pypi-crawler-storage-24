"""Base classes for adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseAdapter(ABC):
    """Abstract database adapter."""

    name: str

    @abstractmethod
    def instrument(self, target: Any) -> Any:
        """Install query capture on the target."""
