"""Public package interface for QueryArgus."""

from .config import TraceConfig
from .decorators import traced
from .exceptions import NestedTraceError, QueryArgusError
from .instrumentation import instrument_object_methods, trace_methods
from .models import Entrypoint, QueryEvent, ScopeRecord, SourceLocation, Trace
from .scope import trace_scope
from .setup import setup, teardown
from .sinks.jsonl import JsonlSink
from .sinks.memory import MemorySink
from .trace import get_current_trace, start_trace

__all__ = [
    "Entrypoint",
    "JsonlSink",
    "MemorySink",
    "NestedTraceError",
    "QueryArgusError",
    "QueryEvent",
    "ScopeRecord",
    "SourceLocation",
    "Trace",
    "TraceConfig",
    "get_current_trace",
    "instrument_object_methods",
    "setup",
    "start_trace",
    "teardown",
    "trace_scope",
    "trace_methods",
    "traced",
]

__version__ = "0.1.2"
