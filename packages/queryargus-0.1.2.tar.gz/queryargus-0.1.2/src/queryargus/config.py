"""Configuration objects for QueryArgus."""

from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class TraceConfig:
    """Controls capture detail, privacy and runtime cost."""

    capture_parameters: bool = False
    parameter_redaction: str = "drop"
    capture_source: bool = True
    capture_stack: bool = False
    max_statement_length: int = 20_000
    record_rowcount: bool = True
    allow_trace_without_sink: bool = True
