"""Pure-Python SVG chart generators for the HTML coverage report."""

from __future__ import annotations

import html
import math
from typing import Any


def render_donut_chart(
    *,
    manual: int,
    inferred: int,
    unscoped: int,
    width: int = 200,
    height: int = 200,
) -> str:
    """Render a donut chart showing scope coverage distribution."""

    total = manual + inferred + unscoped
    if total == 0:
        return _empty_chart(width, height, "No queries captured")

    radius = min(width, height) / 2 - 10
    inner_radius = radius * 0.6
    cx, cy = width / 2, height / 2

    slices = [
        ("manual", manual, "var(--ok, #059669)"),
        ("inferred", inferred, "var(--accent, #6366f1)"),
        ("unscoped", unscoped, "var(--danger, #dc2626)"),
    ]

    paths: list[str] = []
    cumulative = 0.0

    for label, value, color in slices:
        if value == 0:
            continue
        fraction = value / total
        start_angle = cumulative * 2 * math.pi - math.pi / 2
        end_angle = (cumulative + fraction) * 2 * math.pi - math.pi / 2
        cumulative += fraction

        large_arc = 1 if fraction > 0.5 else 0
        x1_outer = cx + radius * math.cos(start_angle)
        y1_outer = cy + radius * math.sin(start_angle)
        x2_outer = cx + radius * math.cos(end_angle)
        y2_outer = cy + radius * math.sin(end_angle)
        x1_inner = cx + inner_radius * math.cos(end_angle)
        y1_inner = cy + inner_radius * math.sin(end_angle)
        x2_inner = cx + inner_radius * math.cos(start_angle)
        y2_inner = cy + inner_radius * math.sin(start_angle)

        path = (
            f"M {x1_outer:.2f} {y1_outer:.2f} "
            f"A {radius:.2f} {radius:.2f} 0 {large_arc} 1 {x2_outer:.2f} {y2_outer:.2f} "
            f"L {x1_inner:.2f} {y1_inner:.2f} "
            f"A {inner_radius:.2f} {inner_radius:.2f} 0 {large_arc} 0 "
            f"{x2_inner:.2f} {y2_inner:.2f} Z"
        )
        pct = round(fraction * 100, 1)
        paths.append(
            f'<path d="{path}" fill="{color}" opacity="0.85">'
            f"<title>{html.escape(label)}: {value} ({pct}%)</title>"
            f"</path>"
        )

    scoped_pct = round(((manual + inferred) / total) * 100, 1) if total else 0
    center_text = (
        f'<text x="{cx}" y="{cy - 6}" text-anchor="middle" '
        f'font-size="1.6em" font-weight="800" fill="var(--ink, #0f172a)">{scoped_pct}%</text>'
        f'<text x="{cx}" y="{cy + 14}" text-anchor="middle" '
        f'font-size="0.7em" fill="var(--muted, #94a3b8)">scoped</text>'
    )

    legend_items = [
        _legend_dot(label, value, color, index)
        for index, (label, value, color) in enumerate(slices)
        if value > 0
    ]
    legend_y = height + 5
    legend = "\n".join(legend_items)

    view_box_height = height + 20 * len(legend_items) + 10
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'viewBox="0 0 {width} {view_box_height}" '
        f'width="{width}" style="font-family:inherit">\n'
        f"  {''.join(paths)}\n"
        f"  {center_text}\n"
        f'  <g transform="translate(10, {legend_y})">{legend}</g>\n'
        f"</svg>"
    )


def _legend_dot(label: str, value: int, color: str, index: int) -> str:
    y = index * 20
    return (
        f'<rect x="0" y="{y}" width="10" height="10" rx="2" fill="{color}" opacity="0.85"/>'
        f'<text x="16" y="{y + 9}" font-size="0.75em" fill="var(--ink-2, #334155)">'
        f"{html.escape(label)}: {value}</text>"
    )


def render_horizontal_bar_chart(
    items: list[dict[str, Any]],
    *,
    label_key: str = "fingerprint",
    value_key: str = "total_duration_ms",
    title: str = "",
    width: int = 480,
    bar_height: int = 28,
    max_bars: int = 5,
) -> str:
    """Render a horizontal bar chart for hotspot data."""

    items = items[:max_bars]
    if not items:
        return _empty_chart(width, 60, "No data")

    max_value = max(float(item.get(value_key, 0) or 0) for item in items)
    if max_value == 0:
        max_value = 1.0

    label_width = 180
    bar_area_width = width - label_width - 60
    row_height = bar_height + 8
    chart_height = len(items) * row_height + 30

    rows: list[str] = []
    for index, item in enumerate(items):
        y = index * row_height + 25
        label = str(item.get(label_key, ""))
        if len(label) > 30:
            label = label[:27] + "..."
        value = float(item.get(value_key, 0) or 0)
        bar_width = max(2, (value / max_value) * bar_area_width)
        share = item.get("share_of_total_sql_ms", 0)

        rows.append(
            f'<text x="{label_width - 8}" y="{y + bar_height // 2 + 4}" '
            f'text-anchor="end" font-size="0.72em" fill="var(--ink-2, #334155)">'
            f"<title>{html.escape(str(item.get(label_key, '')))}</title>"
            f"{html.escape(label)}</text>"
            f'<rect x="{label_width}" y="{y}" width="{bar_width:.1f}" height="{bar_height}" '
            f'rx="4" fill="var(--accent, #6366f1)" opacity="0.8">'
            f"<title>{value:.1f} ms ({share:.1f}%)</title></rect>"
            f'<text x="{label_width + bar_width + 6}" y="{y + bar_height // 2 + 4}" '
            f'font-size="0.7em" font-weight="600" fill="var(--muted, #94a3b8)">'
            f"{value:.1f} ms</text>"
        )

    title_el = (
        f'<text x="{width // 2}" y="14" text-anchor="middle" '
        f'font-size="0.8em" font-weight="700" fill="var(--ink, #0f172a)">'
        f"{html.escape(title)}</text>"
        if title
        else ""
    )

    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {chart_height}" '
        f'width="100%" style="font-family:inherit">\n'
        f"  {title_el}\n"
        f"  {''.join(rows)}\n"
        f"</svg>"
    )


def render_stacked_bar_chart(
    items: list[dict[str, Any]],
    *,
    width: int = 480,
    bar_height: int = 22,
    max_bars: int = 8,
) -> str:
    """Render a stacked bar chart showing scoped vs unscoped queries per entrypoint."""

    items = items[:max_bars]
    if not items:
        return _empty_chart(width, 60, "No entrypoints")

    max_queries = max(int(item.get("query_count", 0) or 0) for item in items)
    if max_queries == 0:
        max_queries = 1

    label_width = 160
    bar_area_width = width - label_width - 50
    row_height = bar_height + 8
    chart_height = len(items) * row_height + 10

    rows: list[str] = []
    for index, item in enumerate(items):
        y = index * row_height + 5
        name = str(item.get("name", ""))
        if len(name) > 25:
            name = name[:22] + "..."
        scoped = int(item.get("manual_queries", 0)) + int(item.get("inferred_queries", 0))
        unscoped = int(item.get("unscoped_queries", 0))
        total = scoped + unscoped

        scoped_width = max(0, (scoped / max_queries) * bar_area_width) if scoped else 0
        unscoped_width = max(0, (unscoped / max_queries) * bar_area_width) if unscoped else 0

        rows.append(
            f'<text x="{label_width - 8}" y="{y + bar_height // 2 + 4}" '
            f'text-anchor="end" font-size="0.7em" fill="var(--ink-2, #334155)">'
            f"{html.escape(name)}</text>"
            f'<rect x="{label_width}" y="{y}" width="{scoped_width:.1f}" height="{bar_height}" '
            f'rx="3" fill="var(--ok, #059669)" opacity="0.8">'
            f"<title>Scoped: {scoped}</title></rect>"
            f'<rect x="{label_width + scoped_width}" y="{y}" width="{unscoped_width:.1f}" '
            f'height="{bar_height}" rx="3" fill="var(--danger, #dc2626)" opacity="0.6">'
            f"<title>Unscoped: {unscoped}</title></rect>"
            f'<text x="{label_width + scoped_width + unscoped_width + 6}" '
            f'y="{y + bar_height // 2 + 4}" font-size="0.65em" '
            f'fill="var(--muted, #94a3b8)">{total}</text>'
        )

    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {chart_height}" '
        f'width="100%" style="font-family:inherit">\n'
        f"  {''.join(rows)}\n"
        f"</svg>"
    )


def _empty_chart(width: int, height: int, message: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
        f'width="{width}" style="font-family:inherit">'
        f'<text x="{width // 2}" y="{height // 2}" text-anchor="middle" '
        f'font-size="0.85em" fill="var(--muted, #94a3b8)">{html.escape(message)}</text>'
        f"</svg>"
    )
