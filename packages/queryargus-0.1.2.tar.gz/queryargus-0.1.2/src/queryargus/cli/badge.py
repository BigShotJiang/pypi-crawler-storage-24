"""Generates a shields.io-style SVG badge for QueryArgus metrics."""

from __future__ import annotations

from typing import Any


def render_badge(summary: dict[str, Any]) -> str:
    """Return an SVG badge showing scope coverage percentage."""

    total = int(summary.get("total_queries", 0))
    manual = int(summary.get("manual_queries", 0))
    inferred = int(summary.get("inferred_queries", 0))
    scoped = manual + inferred
    pct = round((scoped / total) * 100, 1) if total else 0

    color = _color_for_pct(pct)
    label = "QueryArgus coverage"
    value = f"{pct}%"

    label_width = max(len(label) * 6.5 + 12, 110)
    value_width = max(len(value) * 7 + 12, 50)
    total_width = label_width + value_width

    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_width:.0f}" height="20" role="img"'
        f' aria-label="{label}: {value}">\n'
        f"  <title>{label}: {value}</title>\n"
        f'  <linearGradient id="bg" x2="0" y2="100%">\n'
        f'    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>\n'
        f'    <stop offset="1" stop-opacity=".1"/>\n'
        f"  </linearGradient>\n"
        f'  <clipPath id="r"><rect width="{total_width:.0f}" height="20" rx="3"/></clipPath>\n'
        f'  <g clip-path="url(#r)">\n'
        f'    <rect width="{label_width:.0f}" height="20" fill="#555"/>\n'
        f'    <rect x="{label_width:.0f}" width="{value_width:.0f}" height="20" fill="{color}"/>\n'
        f'    <rect width="{total_width:.0f}" height="20" fill="url(#bg)"/>\n'
        f"  </g>\n"
        '  <g fill="#fff" text-anchor="middle" '
        'font-family="Verdana,Geneva,sans-serif" font-size="11">\n'
        f'    <text x="{label_width / 2:.0f}" y="15" fill="#010101" '
        f'fill-opacity=".3">{label}</text>\n'
        f'    <text x="{label_width / 2:.0f}" y="14">{label}</text>\n'
        f'    <text x="{label_width + value_width / 2:.0f}" y="15" '
        f'fill="#010101" fill-opacity=".3">{value}</text>\n'
        f'    <text x="{label_width + value_width / 2:.0f}" y="14">{value}</text>\n'
        f"  </g>\n"
        f"</svg>"
    )


def render_n_plus_one_badge(summary: dict[str, Any]) -> str:
    """Return an SVG badge showing N+1 sequence count."""

    n_plus_one = summary.get("n_plus_one_sequences", [])
    if isinstance(n_plus_one, list):
        count = len(n_plus_one)
    else:
        count = int(summary.get("n_plus_one_sequences_detected", n_plus_one or 0))
    color = "#4c1" if count == 0 else "#e05d44"
    label = "N+1 queries"
    value = str(count)

    label_width = max(len(label) * 6.5 + 12, 80)
    value_width = max(len(value) * 7 + 12, 36)
    total_width = label_width + value_width

    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_width:.0f}" height="20" role="img"'
        f' aria-label="{label}: {value}">\n'
        f"  <title>{label}: {value}</title>\n"
        f'  <clipPath id="r2"><rect width="{total_width:.0f}" height="20" rx="3"/></clipPath>\n'
        f'  <g clip-path="url(#r2)">\n'
        f'    <rect width="{label_width:.0f}" height="20" fill="#555"/>\n'
        f'    <rect x="{label_width:.0f}" width="{value_width:.0f}" height="20" fill="{color}"/>\n'
        f"  </g>\n"
        '  <g fill="#fff" text-anchor="middle" '
        'font-family="Verdana,Geneva,sans-serif" font-size="11">\n'
        f'    <text x="{label_width / 2:.0f}" y="15" fill="#010101" '
        f'fill-opacity=".3">{label}</text>\n'
        f'    <text x="{label_width / 2:.0f}" y="14">{label}</text>\n'
        f'    <text x="{label_width + value_width / 2:.0f}" y="15" '
        f'fill="#010101" fill-opacity=".3">{value}</text>\n'
        f'    <text x="{label_width + value_width / 2:.0f}" y="14">{value}</text>\n'
        f"  </g>\n"
        f"</svg>"
    )


def _color_for_pct(pct: float) -> str:
    if pct >= 80:
        return "#4c1"
    if pct >= 50:
        return "#dfb317"
    return "#e05d44"
