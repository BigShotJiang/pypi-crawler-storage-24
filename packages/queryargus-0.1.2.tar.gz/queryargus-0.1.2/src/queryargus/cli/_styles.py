"""Design system CSS for the QueryArgus HTML coverage report."""

SHARED_CSS = """
:root {
  --bg: #f4f6fb;
  --bg-grad: linear-gradient(145deg, #f4f6fb, #eef1f8);
  --sidebar-bg: linear-gradient(180deg, #0f172a, #1e293b);
  --card: #fff;
  --card-hover: #f8faff;
  --ink: #0f172a;
  --ink-2: #334155;
  --muted: #94a3b8;
  --accent: #6366f1;
  --accent-h: #4f46e5;
  --accent-bg: rgba(99, 102, 241, .08);
  --accent-bd: rgba(99, 102, 241, .22);
  --ok: #059669;
  --ok-bg: rgba(5, 150, 105, .08);
  --danger: #dc2626;
  --danger-bg: rgba(220, 38, 38, .08);
  --border: #e2e8f0;
  --border-2: #f1f5f9;
  --sh-sm: 0 1px 3px rgba(15, 23, 42, .06), 0 1px 2px rgba(15, 23, 42, .04);
  --sh: 0 4px 6px -1px rgba(15, 23, 42, .07), 0 2px 4px -2px rgba(15, 23, 42, .04);
  --sh-lg: 0 10px 25px -5px rgba(15, 23, 42, .09), 0 8px 10px -6px rgba(15, 23, 42, .04);
  --r: 16px;
  --r-sm: 10px;
  --r-xs: 6px;
  --dur: .25s;
  --ease: cubic-bezier(.4, 0, .2, 1);
}

[data-theme="dark"] {
  --bg: #09090f;
  --bg-grad: linear-gradient(145deg, #09090f, #0f0f1a);
  --sidebar-bg: linear-gradient(180deg, #06060c, #0d0d18);
  --card: #151525;
  --card-hover: #1c1c34;
  --ink: #e2e8f0;
  --ink-2: #94a3b8;
  --muted: #64748b;
  --accent: #818cf8;
  --accent-h: #6366f1;
  --accent-bg: rgba(129, 140, 248, .1);
  --accent-bd: rgba(129, 140, 248, .22);
  --ok: #34d399;
  --ok-bg: rgba(52, 211, 153, .1);
  --danger: #f87171;
  --danger-bg: rgba(248, 113, 113, .1);
  --border: #1e293b;
  --border-2: #1a1a30;
  --sh-sm: 0 1px 3px rgba(0, 0, 0, .2);
  --sh: 0 4px 6px rgba(0, 0, 0, .3);
  --sh-lg: 0 10px 25px rgba(0, 0, 0, .4);
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  scroll-behavior: smooth;
}

body {
  font-family: 'Inter', system-ui, sans-serif;
  color: var(--ink);
  background: var(--bg-grad);
  min-height: 100vh;
}

code,
pre {
  font-family: 'JetBrains Mono', 'Fira Code', monospace;
  font-size: .88em;
  word-break: break-word;
}

a {
  color: var(--accent);
  text-decoration: none;
  transition: color var(--dur) var(--ease);
}

a:hover {
  color: var(--accent-h);
}

/* Layout */
.shell {
  display: grid;
  grid-template-columns: 280px minmax(0, 1fr);
  min-height: 100vh;
}

.sidebar {
  position: sticky;
  top: 0;
  align-self: start;
  min-height: 100vh;
  padding: 24px 18px;
  background: var(--sidebar-bg);
  color: #e2e8f0;
  display: flex;
  flex-direction: column;
  gap: 8px;
  border-right: 1px solid rgba(255, 255, 255, .06);
}

.brand {
  margin-bottom: 8px;
}

.brand h1,
.brand h2 {
  margin: 6px 0 8px;
  font-weight: 700;
  font-size: 1.4rem;
  color: #fff;
  letter-spacing: -.02em;
}

.brand p {
  color: rgba(226, 232, 240, .6);
  line-height: 1.5;
  font-size: .88rem;
}

.eyebrow {
  font-size: .7rem;
  text-transform: uppercase;
  letter-spacing: .14em;
  color: #818cf8;
  font-weight: 700;
  margin-bottom: 2px;
}

.sidebar-card {
  padding: 12px 14px;
  border-radius: var(--r-sm);
  background: rgba(255, 255, 255, .04);
  border: 1px solid rgba(255, 255, 255, .06);
  transition: background var(--dur) var(--ease);
}

.sidebar-card:hover {
  background: rgba(255, 255, 255, .08);
}

.sidebar-card code {
  color: #c7d2fe;
  font-size: .82rem;
}

.mini-label {
  font-size: .68rem;
  text-transform: uppercase;
  letter-spacing: .1em;
  color: rgba(255, 255, 255, .45);
  margin-bottom: 6px;
}

.sidebar-nav {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-top: 8px;
}

.sidebar-nav a,
.backlink {
  display: block;
  color: #e2e8f0;
  padding: 9px 12px;
  border-radius: var(--r-xs);
  background: transparent;
  transition: all var(--dur) var(--ease);
  font-size: .9rem;
}

.sidebar-nav a:hover,
.backlink:hover {
  background: rgba(99, 102, 241, .15);
  color: #c7d2fe;
}

.theme-toggle {
  margin-top: auto;
  padding: 10px 12px;
  border-radius: var(--r-xs);
  background: rgba(255, 255, 255, .04);
  border: 1px solid rgba(255, 255, 255, .06);
  color: #e2e8f0;
  cursor: pointer;
  font-size: .88rem;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all var(--dur) var(--ease);
}

.theme-toggle:hover {
  background: rgba(99, 102, 241, .15);
}

/* Content Area */
.content {
  padding: 28px;
  width: 100%;
  max-width: 1200px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* Hero */
.hero {
  border-radius: var(--r);
  padding: 28px 32px;
  background: linear-gradient(135deg, #6366f1, #8b5cf6 40%, #a78bfa);
  color: #fff;
  box-shadow: var(--sh-lg), 0 0 40px rgba(99, 102, 241, .15);
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 20px;
  animation: fadeIn .5s var(--ease) both;
  position: relative;
  overflow: hidden;
}

.hero::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 80% 20%, rgba(255, 255, 255, .12), transparent 50%);
  pointer-events: none;
}

.hero.compact h2 {
  font-size: 1.5rem;
}

.hero h2 {
  font-size: 1.8rem;
  font-weight: 700;
  margin: 8px 0 10px;
  letter-spacing: -.02em;
  position: relative;
}

.hero p {
  max-width: 640px;
  line-height: 1.55;
  color: rgba(255, 255, 255, .8);
  font-size: .92rem;
  position: relative;
}

.hero-stats {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
  position: relative;
}

.hero-chip {
  padding: 8px 14px;
  border-radius: 999px;
  background: rgba(255, 255, 255, .12);
  border: 1px solid rgba(255, 255, 255, .18);
  white-space: nowrap;
  font-weight: 600;
  font-size: .88rem;
  backdrop-filter: blur(8px);
}

/* Metrics */
.metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
  gap: 12px;
}

.metric-card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 18px 20px;
  box-shadow: var(--sh-sm);
  transition: all var(--dur) var(--ease);
  position: relative;
  overflow: hidden;
  animation: fadeIn .4s var(--ease) both;
}

.metric-card:hover {
  transform: translateY(-2px);
  box-shadow: var(--sh);
}

.metric-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 3px;
  height: 100%;
  background: var(--accent);
  border-radius: 0 3px 3px 0;
}

.metric-card .label {
  font-size: .72rem;
  text-transform: uppercase;
  letter-spacing: .08em;
  color: var(--muted);
  font-weight: 600;
}

.metric-card .value {
  font-size: 1.8rem;
  font-weight: 800;
  margin-top: 6px;
  letter-spacing: -.03em;
}

.metric-card .icon {
  font-size: 1.1rem;
  margin-bottom: 4px;
}

/* Panels */
.panel {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 22px;
  box-shadow: var(--sh-sm);
  animation: fadeIn .4s var(--ease) both;
}

.section-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
  flex-wrap: wrap;
}

h3 {
  font-weight: 700;
  font-size: 1.15rem;
  letter-spacing: -.01em;
}

.muted {
  color: var(--muted);
  font-size: .88rem;
}

/* Pills / Badges */
.pill {
  display: inline-block;
  border-radius: 999px;
  padding: 3px 10px;
  font-size: .78rem;
  font-weight: 600;
  background: var(--accent-bg);
  color: var(--accent);
}

.pill.strong {
  background: var(--accent-bg);
  color: var(--accent);
  font-weight: 700;
  border: 1px solid var(--accent-bd);
}

.pill.manual {
  background: var(--ok-bg);
  color: var(--ok);
  border: 1px solid rgba(5, 150, 105, .18);
}

.pill.inferred {
  background: var(--accent-bg);
  color: var(--accent);
  border: 1px solid var(--accent-bd);
}

.pill.none {
  background: var(--danger-bg);
  color: var(--danger);
  border: 1px solid rgba(220, 38, 38, .18);
}

/* Progress */
.progress {
  width: 100%;
  height: 10px;
  background: var(--border);
  border-radius: 999px;
  overflow: hidden;
  margin-top: 10px;
}

.progress > span {
  display: block;
  height: 100%;
  background: linear-gradient(90deg, var(--ok), #34d399, var(--ok));
  background-size: 200% 100%;
  border-radius: 999px;
  animation: shimmer 2.5s ease-in-out infinite;
  transition: width .6s var(--ease);
}

/* Layout helpers */
.two-col {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 16px;
}

.signal-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 14px;
}

.signal-card {
  background: linear-gradient(180deg, var(--card-hover), var(--card));
  border: 1px solid var(--border);
  border-radius: var(--r-sm);
  padding: 16px;
}

.signal-card .eyebrow {
  margin-bottom: 8px;
}

.signal-card h4 {
  font-size: 1rem;
  line-height: 1.35;
  margin-bottom: 8px;
  letter-spacing: -.02em;
}

.signal-card p {
  color: var(--muted);
  font-size: .9rem;
}

.next-steps {
  margin: 0;
  padding-left: 18px;
  display: grid;
  gap: 10px;
}

.next-steps li {
  color: var(--ink);
  line-height: 1.55;
}

.next-steps code {
  font-size: .9em;
}

/* Tables */
table {
  width: 100%;
  border-collapse: collapse;
}

thead {
  position: sticky;
  top: 0;
  z-index: 2;
}

th {
  text-align: left;
  padding: 10px 12px;
  font-size: .72rem;
  text-transform: uppercase;
  letter-spacing: .08em;
  color: var(--muted);
  font-weight: 600;
  background: var(--card);
  border-bottom: 2px solid var(--border);
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
  transition: color var(--dur) var(--ease);
}

th:hover {
  color: var(--accent);
}

th .sort-arrow {
  margin-left: 4px;
  font-size: .7rem;
  opacity: .4;
}

th.sorted .sort-arrow {
  opacity: 1;
  color: var(--accent);
}

td {
  text-align: left;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border-2);
  vertical-align: top;
  font-size: .9rem;
  transition: background var(--dur) var(--ease);
}

tr:hover td {
  background: var(--card-hover);
}

tr:last-child td {
  border-bottom: 0;
}

/* Search */
.search {
  width: min(300px, 100%);
  padding: 9px 12px 9px 36px;
  border: 1px solid var(--border);
  border-radius: var(--r-sm);
  background: var(--card);
  color: var(--ink);
  font-size: .9rem;
  transition: all var(--dur) var(--ease);
  outline: none;
}

.search:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-bg);
}

.search-wrap {
  position: relative;
  display: inline-block;
}

.search-wrap::before {
  content: '\\1F50D';
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  font-size: .82rem;
  pointer-events: none;
}

/* Buttons */
.link-button {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 6px 14px;
  border-radius: 999px;
  background: var(--accent);
  color: #fff;
  font-size: .82rem;
  font-weight: 600;
  white-space: nowrap;
  transition: all var(--dur) var(--ease);
  border: none;
  cursor: pointer;
}

.link-button:hover {
  background: var(--accent-h);
  color: #fff;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(99, 102, 241, .25);
}

/* Status */
.status-ok {
  color: var(--ok);
  font-weight: 700;
}

.status-error {
  color: var(--danger);
  font-weight: 700;
}

/* Footer */
.footer {
  text-align: center;
  padding: 24px;
  color: var(--muted);
  font-size: .78rem;
  border-top: 1px solid var(--border);
  margin-top: 12px;
}

.footer span {
  color: var(--accent);
  font-weight: 600;
}

/* Animations */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(6px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes shimmer {
  0% {
    background-position: 200% 0;
  }

  100% {
    background-position: -200% 0;
  }
}

/* Responsive */
@media(max-width:900px) {
  .shell {
    grid-template-columns: 1fr;
  }

  .sidebar {
    position: static;
    min-height: auto;
    flex-direction: row;
    flex-wrap: wrap;
    padding: 16px;
  }

  .content {
    padding: 16px;
  }

  .hero {
    flex-direction: column;
  }

  .brand {
    width: 100%;
  }

  .sidebar-nav {
    flex-direction: row;
    flex-wrap: wrap;
  }
}
"""

SHARED_SCRIPTS = """
// Dark mode toggle
function toggleTheme() {
  const html = document.documentElement;
  const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  localStorage.setItem('qa-theme', next);
  updateToggleUI(next);
}

function updateToggleUI(t) {
  const i = document.getElementById('theme-icon');
  const l = document.getElementById('theme-label');
  if (i) i.textContent = t === 'dark' ? 'Light' : 'Dark';
  if (l) l.textContent = t === 'dark' ? 'Light mode' : 'Dark mode';
}

(function() {
  const s = localStorage.getItem('qa-theme');
  if (s) {
    document.documentElement.setAttribute('data-theme', s);
    updateToggleUI(s);
  } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
    document.documentElement.setAttribute('data-theme', 'dark');
    updateToggleUI('dark');
  }
})();

// Table sorting
document.querySelectorAll('th').forEach(function(th) {
  th.innerHTML += ' <span class="sort-arrow">↕</span>';
  th.addEventListener('click', function() {
    const table = th.closest('table');
    const tbody = table.querySelector('tbody');
    if (!tbody) return;

    const idx = Array.from(th.parentNode.children).indexOf(th);
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const dir = th.classList.contains('sorted-asc') ? -1 : 1;

    table.querySelectorAll('th').forEach(function(h) {
      h.classList.remove('sorted', 'sorted-asc', 'sorted-desc');
    });
    th.classList.add('sorted', dir === 1 ? 'sorted-asc' : 'sorted-desc');

    const sortArrow = th.querySelector('.sort-arrow');
    if (sortArrow) {
      sortArrow.textContent = dir === 1 ? '▲' : '▼';
    }

    rows.sort(function(a, b) {
      let va = (a.children[idx] || {}).textContent || '';
      let vb = (b.children[idx] || {}).textContent || '';
      va = va.trim();
      vb = vb.trim();
      const na = parseFloat(va);
      const nb = parseFloat(vb);
      if (!isNaN(na) && !isNaN(nb)) return (na - nb) * dir;
      return va.localeCompare(vb) * dir;
    });

    rows.forEach(function(r) {
      tbody.appendChild(r);
    });
  });
});
"""

FONT_LINKS = (
    '<link rel="preconnect" href="https://fonts.googleapis.com">'
    '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
    "<link "
    'href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800'
    '&family=JetBrains+Mono:wght@400;500&display=swap" '
    'rel="stylesheet">'
)

THEME_TOGGLE_HTML = (
    '<button class="theme-toggle" onclick="toggleTheme()" id="theme-toggle">'
    '<span id="theme-icon">Dark</span> '
    '<span id="theme-label">Dark mode</span>'
    "</button>"
)
