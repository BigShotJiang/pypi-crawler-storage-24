"""Framework integrations."""

from .fastapi import instrument_fastapi
from .starlette import instrument_starlette

__all__ = ["instrument_fastapi", "instrument_starlette"]
