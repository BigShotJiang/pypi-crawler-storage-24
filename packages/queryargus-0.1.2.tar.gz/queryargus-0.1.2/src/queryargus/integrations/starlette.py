"""Starlette integration."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any, Protocol, cast

from .._internal.registry import get_global_config, get_global_sinks
from ..config import TraceConfig
from ..models import Entrypoint
from ..sinks.base import BaseSink
from ..trace import _open_trace, get_current_trace


class _MiddlewareApp(Protocol):
    def middleware(
        self,
        kind: str,
    ) -> Callable[
        [Callable[[Any, Callable[[Any], Awaitable[Any]]], Awaitable[Any]]],
        Callable[[Any, Callable[[Any], Awaitable[Any]]], Awaitable[Any]],
    ]: ...


def instrument_starlette(
    app: object,
    *,
    sink: BaseSink | tuple[BaseSink, ...] | None = None,
    config: TraceConfig | None = None,
) -> object:
    """Attach a tracing middleware to a Starlette app."""

    if getattr(app, "_queryargus_starlette_instrumented", False):
        return app

    middleware_app = cast(_MiddlewareApp, app)

    @middleware_app.middleware("http")
    async def queryargus_middleware(
        request: Any,
        call_next: Callable[[Any], Awaitable[Any]],
    ) -> Any:
        if get_current_trace() is not None:
            return await call_next(request)
        if request.method == "OPTIONS":
            return await call_next(request)

        metadata = {
            "http.method": request.method,
            "http.route": request.url.path,
        }
        name = f"{request.method} {request.url.path}"
        entrypoint = Entrypoint(
            kind="http_endpoint",
            name=name,
        )
        resolved_sink = sink if sink is not None else (get_global_sinks() or None)
        resolved_config = config or get_global_config()

        with _open_trace(
            name=name,
            entrypoint=entrypoint,
            sink=resolved_sink,
            config=resolved_config,
            metadata=metadata,
        ):
            return await call_next(request)

    cast(Any, app)._queryargus_starlette_instrumented = True
    return app
