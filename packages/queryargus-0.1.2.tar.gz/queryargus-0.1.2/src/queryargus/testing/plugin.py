"""Pytest plugin for QueryArgus."""
# mypy: disable-error-code="untyped-decorator"

from __future__ import annotations

from collections.abc import Iterator

import pytest

from ..models import Trace
from ..sinks.memory import MemorySink
from ..trace import start_trace
from .capture import CapturedQueries, capture_queries


@pytest.fixture
def queryargus_memory_sink() -> MemorySink:
    return MemorySink()


@pytest.fixture
def queryargus_trace(queryargus_memory_sink: MemorySink) -> Iterator[Trace]:
    with start_trace("test", sink=queryargus_memory_sink) as trace:
        yield trace


@pytest.fixture
def queryargus_captured() -> Iterator[CapturedQueries]:
    with capture_queries() as captured:
        yield captured
