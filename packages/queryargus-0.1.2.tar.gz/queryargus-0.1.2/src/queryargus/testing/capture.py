"""Context manager for capturing queries in a specific code block."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field

from ..models import QueryEvent, Trace
from ..sinks.memory import MemorySink
from ..trace import get_current_trace, start_trace


@dataclass(slots=True)
class CapturedQueries:
    """Result of a ``capture_queries()`` block."""

    queries: list[QueryEvent] = field(default_factory=list)
    trace: Trace | None = None

    @property
    def count(self) -> int:
        return len(self.queries)

    @property
    def statements(self) -> list[str]:
        return [q.statement for q in self.queries]

    @property
    def total_duration_ms(self) -> float:
        return sum(q.duration_ms for q in self.queries)


@contextmanager
def capture_queries(name: str = "captured") -> Iterator[CapturedQueries]:
    """Capture all queries executed inside a block.

    If a trace is already active, queries are captured from it.
    Otherwise, a temporary trace with a ``MemorySink`` is opened.

    Usage::

        with capture_queries() as captured:
            repository.get_all_stocks()

        assert captured.count <= 3
    """

    result = CapturedQueries()
    existing_trace = get_current_trace()

    if existing_trace is not None:
        initial_count = len(existing_trace.queries)
        try:
            yield result
        finally:
            result.trace = existing_trace
            result.queries = existing_trace.queries[initial_count:]
    else:
        sink = MemorySink()
        with start_trace(name, sink=sink) as trace:
            try:
                yield result
            finally:
                result.trace = trace
                result.queries = list(trace.queries)
