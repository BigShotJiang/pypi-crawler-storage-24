"""Assertion helpers used in tests and CI."""

from __future__ import annotations

from collections import Counter

from ..analysis.heuristics import detect_n_plus_one_sequences
from ..models import Trace


def assert_query_count_at_most(trace: Trace, maximum: int) -> None:
    """Fail when a trace executes more queries than expected."""

    actual = len(trace.queries)
    if actual > maximum:
        raise AssertionError(f"expected at most {maximum} queries, got {actual}")


def assert_no_repeated_queries(trace: Trace) -> None:
    """Fail when any query fingerprint appears more than once."""

    counter = Counter(q.fingerprint for q in trace.queries if q.fingerprint)
    repeated = {fp: count for fp, count in counter.items() if count > 1}

    if repeated:
        details = "; ".join(f"{fp!r} x{count}" for fp, count in repeated.items())
        raise AssertionError(f"repeated queries detected: {details}")


def assert_no_n_plus_one(trace: Trace, *, threshold: int = 2) -> None:
    """Fail when any SELECT-like fingerprint repeats in sequence too many times."""

    if threshold < 1:
        raise ValueError("threshold must be at least 1")

    violations = detect_n_plus_one_sequences(trace, min_run_length=threshold + 1)
    if violations:
        details = "; ".join(
            (
                f"{item['fingerprint']!r} x{item['count']} "
                f"[{item['start_ordinal']}-{item['end_ordinal']}] "
                f"(threshold: {threshold})"
            )
            for item in violations
        )
        raise AssertionError(f"possible N+1 detected: {details}")


def assert_max_duration_ms(trace: Trace, maximum: float) -> None:
    """Fail when total SQL time exceeds *maximum* milliseconds."""

    total = sum(q.duration_ms for q in trace.queries)
    if total > maximum:
        raise AssertionError(f"total SQL duration {total:.1f}ms exceeded limit of {maximum:.1f}ms")


def assert_all_queries_scoped(trace: Trace) -> None:
    """Fail when any query has no associated business scope."""

    unscoped = [q for q in trace.queries if q.scope_kind == "none" or not q.scope_path]

    if unscoped:
        statements = [q.statement[:80] for q in unscoped[:5]]
        details = "; ".join(statements)
        suffix = f" (and {len(unscoped) - 5} more)" if len(unscoped) > 5 else ""
        raise AssertionError(f"{len(unscoped)} queries without scope: {details}{suffix}")
