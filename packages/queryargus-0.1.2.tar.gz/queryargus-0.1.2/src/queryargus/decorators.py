"""Decorators for QueryArgus entrypoint tracing."""

from __future__ import annotations

import inspect
from collections.abc import Callable, Iterable
from functools import wraps
from typing import Any, ParamSpec, TypeVar, cast

from ._internal.registry import get_global_config, get_global_sinks
from .config import TraceConfig
from .models import Entrypoint
from .sinks.base import BaseSink
from .trace import _open_trace, get_current_trace

P = ParamSpec("P")
R = TypeVar("R")


def traced(
    name: str | Callable[P, R] | None = None,
    *,
    sink: BaseSink | Iterable[BaseSink] | None = None,
    config: TraceConfig | None = None,
    metadata: dict[str, object] | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]] | Callable[P, R]:
    """Open a root trace automatically when entering a function."""

    if callable(name) and metadata is None and sink is None and config is None:
        fn = name
        return _decorate(fn, None, None, None, None)

    trace_name = cast(str | None, name)

    def decorator(fn: Callable[P, R]) -> Callable[P, R]:
        return _decorate(fn, trace_name, sink, config, metadata)

    return decorator


def _decorate(
    fn: Callable[P, R],
    trace_name: str | None,
    sink: BaseSink | Iterable[BaseSink] | None,
    config: TraceConfig | None,
    metadata: dict[str, object] | None,
) -> Callable[P, R]:
    resolved_name = trace_name or f"{fn.__module__}.{fn.__qualname__}"

    def _resolve_sink() -> BaseSink | Iterable[BaseSink] | tuple[BaseSink, ...] | None:
        if sink is not None:
            return sink
        return get_global_sinks() or None

    def _resolve_config() -> TraceConfig | None:
        return config or get_global_config()

    entrypoint = Entrypoint(
        kind="function",
        name=resolved_name,
        module=fn.__module__,
        qualname=fn.__qualname__,
    )
    base_metadata = dict(metadata or {})

    if inspect.iscoroutinefunction(fn):

        @wraps(fn)
        async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> Any:
            if get_current_trace() is not None:
                return await cast(Callable[P, Any], fn)(*args, **kwargs)

            with _open_trace(
                name=resolved_name,
                entrypoint=entrypoint,
                sink=_resolve_sink(),
                config=_resolve_config(),
                metadata=base_metadata,
            ):
                return await cast(Callable[P, Any], fn)(*args, **kwargs)

        return cast(Callable[P, R], async_wrapper)

    @wraps(fn)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        if get_current_trace() is not None:
            return fn(*args, **kwargs)

        with _open_trace(
            name=resolved_name,
            entrypoint=entrypoint,
            sink=_resolve_sink(),
            config=_resolve_config(),
            metadata=base_metadata,
        ):
            return fn(*args, **kwargs)

    return wrapper
