"""Custom exceptions for QueryArgus."""


class QueryArgusError(Exception):
    """Base exception for QueryArgus."""


class NestedTraceError(QueryArgusError):
    """Raised when code attempts to open a second root trace."""
