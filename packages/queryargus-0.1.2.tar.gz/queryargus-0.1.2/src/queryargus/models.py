"""Public data models used by QueryArgus."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from ._internal.clock import monotonic_ns, utc_now
from .config import TraceConfig


@dataclass(slots=True, frozen=True)
class Entrypoint:
    """Structured description of the origin of a trace."""

    kind: str
    name: str
    module: str | None = None
    qualname: str | None = None


@dataclass(slots=True, frozen=True)
class SourceLocation:
    """Source file information for a query event."""

    file: str
    line: int


@dataclass(slots=True)
class QueryEvent:
    """Normalized representation of a single SQL query."""

    event_id: str
    adapter: str
    statement: str
    fingerprint: str
    duration_ms: float
    success: bool
    ordinal: int = 0
    db_system: str | None = None
    operation: str | None = None
    rowcount: int | None = None
    error: str | None = None
    parameter_count: int | None = None
    parameters: object | None = None
    parameters_redacted: bool = True
    scope_path: list[str] = field(default_factory=list)
    scope_kind: str = "none"
    source: SourceLocation | None = None


@dataclass(slots=True)
class ScopeRecord:
    """Observed business scope inside a trace."""

    scope_id: str
    name: str
    parent_id: str | None
    depth: int
    kind: str = "manual"
    metadata: dict[str, object] = field(default_factory=dict)
    started_at: datetime = field(default_factory=utc_now)
    ended_at: datetime | None = None
    duration_ms: float | None = None
    error: str | None = None
    _started_ns: int = field(default_factory=monotonic_ns, init=False, repr=False)

    def finish(self, error: BaseException | None = None) -> None:
        if self.ended_at is not None:
            return

        self.ended_at = utc_now()
        self.duration_ms = max(0.0, (monotonic_ns() - self._started_ns) / 1_000_000)

        if error is not None:
            self.error = f"{type(error).__name__}: {error}"


@dataclass(slots=True)
class Trace:
    """Root unit of observed execution."""

    trace_id: str
    name: str
    entrypoint: Entrypoint
    metadata: dict[str, object] = field(default_factory=dict)
    config: TraceConfig = field(default_factory=TraceConfig, repr=False)
    schema_version: int = 1
    status: str = "running"
    started_at: datetime = field(default_factory=utc_now)
    ended_at: datetime | None = None
    duration_ms: float | None = None
    error: str | None = None
    queries: list[QueryEvent] = field(default_factory=list)
    scopes: list[ScopeRecord] = field(default_factory=list)
    _started_ns: int = field(default_factory=monotonic_ns, init=False, repr=False)

    def add_query(self, event: QueryEvent) -> QueryEvent:
        if event.ordinal <= 0:
            event.ordinal = len(self.queries) + 1

        self.queries.append(event)
        return event

    def add_scope(self, scope: ScopeRecord) -> ScopeRecord:
        self.scopes.append(scope)
        return scope

    def finish(self, error: BaseException | None = None) -> "Trace":
        if self.ended_at is not None:
            return self

        self.ended_at = utc_now()
        self.duration_ms = max(0.0, (monotonic_ns() - self._started_ns) / 1_000_000)

        if error is None:
            self.status = "ok"
        else:
            self.status = "error"
            self.error = f"{type(error).__name__}: {error}"

        return self
