"""Business scope helpers."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager

from ._internal.context import get_current_scopes, reset_current_scopes, set_current_scopes
from ._internal.ids import new_id
from .models import ScopeRecord
from .trace import get_current_trace


@contextmanager
def trace_scope(
    name: str,
    *,
    metadata: dict[str, object] | None = None,
    kind: str = "manual",
) -> Iterator[None]:
    """Push a logical scope inside the active trace."""

    trace = get_current_trace()
    if trace is None:
        yield
        return

    current_scopes = get_current_scopes()
    parent = current_scopes[-1] if current_scopes else None
    scope = ScopeRecord(
        scope_id=new_id("scp"),
        name=name,
        parent_id=parent.scope_id if parent is not None else None,
        depth=len(current_scopes) + 1,
        kind=kind,
        metadata=dict(metadata or {}),
    )
    token = set_current_scopes(current_scopes + (scope,))
    error: BaseException | None = None

    try:
        yield
    except BaseException as exc:
        error = exc
        raise
    finally:
        reset_current_scopes(token)
        scope.finish(error=error)
        trace.add_scope(scope)
