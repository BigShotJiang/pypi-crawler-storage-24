"""Basic metrics for traces."""

from __future__ import annotations

from ..models import Trace


def query_count(trace: Trace) -> int:
    """Return the number of queries observed in a trace."""

    return len(trace.queries)


def total_sql_duration_ms(trace: Trace) -> float:
    """Return total SQL time across all queries in a trace."""

    return sum(query.duration_ms for query in trace.queries)
