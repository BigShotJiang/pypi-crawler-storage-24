"""High-level trace reports."""

from __future__ import annotations

from ..models import Trace
from .heuristics import compute_hotspots, detect_n_plus_one_sequences, repeated_queries
from .metrics import query_count, total_sql_duration_ms


def summarize_trace(trace: Trace) -> dict[str, object]:
    """Return a compact report for a single trace."""

    total_sql_ms = total_sql_duration_ms(trace)
    return {
        "trace_id": trace.trace_id,
        "name": trace.name,
        "entrypoint": trace.entrypoint.name,
        "status": trace.status,
        "query_count": query_count(trace),
        "total_sql_duration_ms": total_sql_ms,
        "repeated_queries": repeated_queries(trace),
        "n_plus_one_sequences": detect_n_plus_one_sequences(
            trace,
            total_sql_duration_ms=total_sql_ms,
        ),
        "hotspots": compute_hotspots(trace, total_sql_duration_ms=total_sql_ms),
    }
