"""Coverage-oriented summaries for traces."""

from __future__ import annotations

from ..models import Trace


def build_coverage_snapshot(traces: list[Trace]) -> dict[str, object]:
    """Build a compact coverage snapshot for a set of traces."""

    observed_entrypoints = {trace.entrypoint.name for trace in traces}
    adapters = sorted(
        {query.adapter for trace in traces for query in trace.queries if query.adapter}
    )
    unscoped_queries = sum(1 for trace in traces for query in trace.queries if not query.scope_path)

    return {
        "trace_count": len(traces),
        "observed_entrypoints": sorted(observed_entrypoints),
        "traces_with_queries": sum(1 for trace in traces if trace.queries),
        "unscoped_queries": unscoped_queries,
        "adapters": adapters,
    }
