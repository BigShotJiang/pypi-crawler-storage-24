"""Heuristics for trace analysis."""

from __future__ import annotations

from collections import Counter
from collections.abc import Callable, Mapping, Sequence
from typing import Any, cast

from ..models import QueryEvent, SourceLocation, Trace

QueryLike = QueryEvent | Mapping[str, Any]
LabelGetter = Callable[[QueryLike], str | None]


def repeated_queries(trace: Trace, *, min_occurrences: int = 2) -> dict[str, int]:
    """Return repeated query fingerprints and their counts."""

    counter = Counter(query.fingerprint for query in trace.queries if query.fingerprint)
    return {
        fingerprint: count for fingerprint, count in counter.items() if count >= min_occurrences
    }


def detect_n_plus_one_sequences(
    trace_or_queries: Trace | Sequence[QueryLike],
    *,
    min_run_length: int = 3,
    total_sql_duration_ms: float | None = None,
) -> list[dict[str, object]]:
    """Detect contiguous runs of identical SELECT-like queries."""

    queries = _coerce_queries(trace_or_queries)
    if min_run_length <= 1:
        raise ValueError("min_run_length must be greater than 1")
    if not queries:
        return []

    trace_total_sql = (
        total_sql_duration_ms
        if total_sql_duration_ms is not None
        else sum(_duration_ms(query) for query in queries)
    )
    sequences: list[dict[str, object]] = []
    current_run: list[tuple[int, QueryLike]] = []

    for index, query in enumerate(queries):
        if not _is_n_plus_one_eligible(query):
            _flush_n_plus_one_run(
                current_run,
                sequences,
                min_run_length=min_run_length,
                total_sql_duration_ms=trace_total_sql,
            )
            current_run = []
            continue

        if current_run and _same_n_plus_one_group(current_run[-1][1], query):
            current_run.append((index, query))
            continue

        _flush_n_plus_one_run(
            current_run,
            sequences,
            min_run_length=min_run_length,
            total_sql_duration_ms=trace_total_sql,
        )
        current_run = [(index, query)]

    _flush_n_plus_one_run(
        current_run,
        sequences,
        min_run_length=min_run_length,
        total_sql_duration_ms=trace_total_sql,
    )
    return sorted(
        sequences,
        key=lambda item: (
            -_coerce_int(item["count"]),
            -_coerce_float(item["total_duration_ms"]),
            _coerce_int(item["start_ordinal"]),
        ),
    )


def compute_hotspots(
    trace_or_queries: Trace | Sequence[QueryLike],
    *,
    limit: int = 5,
    total_sql_duration_ms: float | None = None,
) -> dict[str, list[dict[str, object]]]:
    """Return SQL hotspots grouped by fingerprint, scope, and source."""

    queries = _coerce_queries(trace_or_queries)
    trace_total_sql = (
        total_sql_duration_ms
        if total_sql_duration_ms is not None
        else sum(_duration_ms(query) for query in queries)
    )
    return {
        "fingerprints": _aggregate_hotspots(
            queries,
            label_name="fingerprint",
            label_getter=lambda query: _fingerprint(query) or None,
            total_sql_duration_ms=trace_total_sql,
            limit=limit,
        ),
        "scopes": _aggregate_hotspots(
            queries,
            label_name="scope",
            label_getter=lambda query: _scope_label(query) or "<unscoped>",
            total_sql_duration_ms=trace_total_sql,
            limit=limit,
        ),
        "sources": _aggregate_hotspots(
            queries,
            label_name="source",
            label_getter=_source_label,
            total_sql_duration_ms=trace_total_sql,
            limit=limit,
        ),
    }


def _coerce_queries(trace_or_queries: Trace | Sequence[QueryLike]) -> list[QueryLike]:
    if isinstance(trace_or_queries, Trace):
        return list(trace_or_queries.queries)
    return list(trace_or_queries)


def _aggregate_hotspots(
    queries: Sequence[QueryLike],
    *,
    label_name: str,
    label_getter: LabelGetter,
    total_sql_duration_ms: float,
    limit: int,
) -> list[dict[str, object]]:
    buckets: dict[str, dict[str, object]] = {}

    for query in queries:
        label = label_getter(query)
        if not label:
            continue

        duration_ms = _duration_ms(query)
        bucket = buckets.setdefault(
            str(label),
            {
                label_name: str(label),
                "query_count": 0,
                "total_duration_ms": 0.0,
                "avg_duration_ms": 0.0,
                "max_duration_ms": 0.0,
                "share_of_total_sql_ms": 0.0,
                "sample_statement": _statement(query),
            },
        )
        bucket["query_count"] = _coerce_int(bucket["query_count"]) + 1
        bucket["total_duration_ms"] = _coerce_float(bucket["total_duration_ms"]) + duration_ms
        bucket["max_duration_ms"] = max(_coerce_float(bucket["max_duration_ms"]), duration_ms)

    items = list(buckets.values())
    for item in items:
        query_count = _coerce_int(item["query_count"])
        total_duration = _coerce_float(item["total_duration_ms"])
        item["avg_duration_ms"] = total_duration / query_count if query_count else 0.0
        item["share_of_total_sql_ms"] = (
            (total_duration / total_sql_duration_ms) * 100.0 if total_sql_duration_ms > 0 else 0.0
        )

    return sorted(
        items,
        key=lambda item: (
            -_coerce_float(item["total_duration_ms"]),
            -_coerce_int(item["query_count"]),
            str(item[label_name]),
        ),
    )[:limit]


def _flush_n_plus_one_run(
    run: list[tuple[int, QueryLike]],
    sequences: list[dict[str, object]],
    *,
    min_run_length: int,
    total_sql_duration_ms: float,
) -> None:
    if len(run) < min_run_length:
        return

    first_query = run[0][1]
    total_duration = sum(_duration_ms(query) for _, query in run)
    count = len(run)
    source = _source_label(first_query)
    scope = _scope_label(first_query)
    context_type, context_value = _n_plus_one_context(first_query)
    sequences.append(
        {
            "fingerprint": _fingerprint(first_query),
            "count": count,
            "start_ordinal": _ordinal(run[0][1], fallback=run[0][0] + 1),
            "end_ordinal": _ordinal(run[-1][1], fallback=run[-1][0] + 1),
            "total_duration_ms": total_duration,
            "avg_duration_ms": total_duration / count,
            "share_of_total_sql_ms": (
                (total_duration / total_sql_duration_ms) * 100.0
                if total_sql_duration_ms > 0
                else 0.0
            ),
            "scope": scope,
            "source": source,
            "context_type": context_type,
            "context_value": context_value,
            "confidence": _n_plus_one_confidence(first_query),
            "sample_statement": _statement(first_query),
        }
    )


def _same_n_plus_one_group(left: QueryLike, right: QueryLike) -> bool:
    return _fingerprint(left) == _fingerprint(right) and _n_plus_one_context(
        left
    ) == _n_plus_one_context(right)


def _is_n_plus_one_eligible(query: QueryLike) -> bool:
    return bool(_fingerprint(query)) and _is_select_like(query)


def _is_select_like(query: QueryLike) -> bool:
    operation = _operation(query)
    if operation in {"select", "with"}:
        return True
    if operation:
        return False

    statement = _statement(query).lstrip()
    if not statement:
        return False

    first_token = statement.split(None, 1)[0].lower()
    return first_token in {"select", "with"}


def _n_plus_one_context(query: QueryLike) -> tuple[str, str]:
    scope = _scope_label(query)
    if scope:
        return ("scope", scope)

    source = _source_label(query)
    if source:
        return ("source", source)

    return ("unscoped", _operation(query) or "<unknown>")


def _n_plus_one_confidence(query: QueryLike) -> str:
    scope = _scope_label(query)
    source = _source_label(query)
    if scope and source:
        return "high"
    if scope or source:
        return "medium"
    return "low"


def _scope_label(query: QueryLike) -> str | None:
    scope_path = _scope_path(query)
    if not scope_path:
        return None
    return " > ".join(scope_path)


def _scope_path(query: QueryLike) -> list[str]:
    value = _query_value(query, "scope_path", [])
    if not value:
        return []
    return [str(item) for item in value]


def _source_label(query: QueryLike) -> str | None:
    source = _query_value(query, "source")
    if source is None:
        return None

    if isinstance(source, SourceLocation):
        return f"{source.file}:{source.line}"
    if isinstance(source, Mapping):
        file = source.get("file")
        line = source.get("line")
        if not file:
            return None
        return f"{file}:{line}" if line is not None else str(file)
    return None


def _query_value(query: QueryLike, field_name: str, default: Any = None) -> Any:
    if isinstance(query, Mapping):
        return query.get(field_name, default)
    return getattr(query, field_name, default)


def _fingerprint(query: QueryLike) -> str:
    return str(_query_value(query, "fingerprint", "") or "")


def _statement(query: QueryLike) -> str:
    return str(_query_value(query, "statement", "") or "")


def _operation(query: QueryLike) -> str:
    return str(_query_value(query, "operation", "") or "").strip().lower()


def _duration_ms(query: QueryLike) -> float:
    return _coerce_float(_query_value(query, "duration_ms", 0.0) or 0.0)


def _ordinal(query: QueryLike, *, fallback: int) -> int:
    value = _coerce_int(_query_value(query, "ordinal", 0))
    return value if value > 0 else fallback


def _coerce_int(value: object) -> int:
    try:
        return int(cast(Any, value))
    except (TypeError, ValueError):
        return 0


def _coerce_float(value: object) -> float:
    try:
        return float(cast(Any, value))
    except (TypeError, ValueError):
        return 0.0
