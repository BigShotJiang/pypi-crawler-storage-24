"""Offline analysis helpers."""

from .coverage import build_coverage_snapshot
from .heuristics import compute_hotspots, detect_n_plus_one_sequences, repeated_queries
from .metrics import query_count, total_sql_duration_ms
from .report import summarize_trace

__all__ = [
    "build_coverage_snapshot",
    "compute_hotspots",
    "detect_n_plus_one_sequences",
    "query_count",
    "repeated_queries",
    "summarize_trace",
    "total_sql_duration_ms",
]
