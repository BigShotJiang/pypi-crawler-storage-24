"""Trace lifecycle management."""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from contextlib import contextmanager

from ._internal.context import (
    get_current_trace as _get_current_trace,
)
from ._internal.context import (
    reset_current_scopes,
    reset_current_trace,
    set_current_scopes,
    set_current_trace,
)
from ._internal.ids import new_id
from ._internal.registry import get_global_config, get_global_sinks
from .config import TraceConfig
from .exceptions import NestedTraceError
from .models import Entrypoint, Trace
from .sinks.base import BaseSink


def get_current_trace() -> Trace | None:
    """Return the trace active in the current execution context."""

    return _get_current_trace()


def _normalize_sinks(sink: BaseSink | Iterable[BaseSink] | None) -> tuple[BaseSink, ...]:
    if sink is None:
        return ()

    if isinstance(sink, BaseSink):
        return (sink,)

    return tuple(sink)


def _write_sinks(trace: Trace, sinks: tuple[BaseSink, ...]) -> None:
    for item in sinks:
        item.write(trace)


@contextmanager
def _open_trace(
    *,
    name: str,
    entrypoint: Entrypoint,
    sink: BaseSink | Iterable[BaseSink] | None = None,
    config: TraceConfig | None = None,
    metadata: dict[str, object] | None = None,
) -> Iterator[Trace]:
    if not name or not name.strip():
        raise ValueError("trace name must not be empty")

    if get_current_trace() is not None:
        raise NestedTraceError(
            "a root trace is already active; use trace_scope() for nested context"
        )

    trace = Trace(
        trace_id=new_id("trc"),
        name=name,
        entrypoint=entrypoint,
        metadata=dict(metadata or {}),
        config=config or TraceConfig(),
    )
    trace_token = set_current_trace(trace)
    scopes_token = set_current_scopes(())
    sinks = _normalize_sinks(sink)
    error: BaseException | None = None

    try:
        yield trace
    except BaseException as exc:
        error = exc
        raise
    finally:
        try:
            trace.finish(error=error)
            _write_sinks(trace, sinks)
        finally:
            reset_current_scopes(scopes_token)
            reset_current_trace(trace_token)


@contextmanager
def start_trace(
    name: str,
    *,
    sink: BaseSink | Iterable[BaseSink] | None = None,
    config: TraceConfig | None = None,
    metadata: dict[str, object] | None = None,
) -> Iterator[Trace]:
    """Open a root trace for a unit of execution."""

    resolved_sink = sink if sink is not None else (get_global_sinks() or None)
    resolved_config = config or get_global_config()

    entrypoint = Entrypoint(kind="custom", name=name)
    with _open_trace(
        name=name,
        entrypoint=entrypoint,
        sink=resolved_sink,
        config=resolved_config,
        metadata=metadata,
    ) as trace:
        yield trace
