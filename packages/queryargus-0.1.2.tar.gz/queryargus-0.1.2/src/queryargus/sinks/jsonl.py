"""JSONL sink for offline analysis."""

from __future__ import annotations

import json
from pathlib import Path

from .._internal.serialization import serialize_trace
from ..models import Trace
from .base import BaseSink


class JsonlSink(BaseSink):
    """Writes one serialized trace per line."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def write(self, trace: Trace) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(serialize_trace(trace), sort_keys=True)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(payload)
            handle.write("\n")
