"""Base sink protocol."""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..models import Trace


class BaseSink(ABC):
    """Persists finished traces."""

    @abstractmethod
    def write(self, trace: Trace) -> None:
        """Persist a finished trace."""
