"""In-memory sink useful for tests and local experiments."""

from __future__ import annotations

from ..models import Trace
from .base import BaseSink


class MemorySink(BaseSink):
    """Stores traces in memory."""

    def __init__(self) -> None:
        self.traces: list[Trace] = []

    def write(self, trace: Trace) -> None:
        self.traces.append(trace)
