#!/usr/bin/env python3


# Third party modules
from setuptools import setup

setup(name='promptalchemy',
      version='0.0.0',
      description='placeholder',
      url='http://github.com/SK/promptalchemy',
      author='Stephen King',
      author_email='sking@gmail.com',
      license='MIT',
      packages=['promptalchemy'],
      zip_safe=False)