"""Discord Ferry — Migrate Discord servers to Stoat."""

__version__ = "1.4.0"
