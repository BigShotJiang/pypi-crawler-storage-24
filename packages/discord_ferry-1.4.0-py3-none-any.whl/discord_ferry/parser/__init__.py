"""DCE JSON export parser."""
