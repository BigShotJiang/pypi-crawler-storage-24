"""Lightning Memory: Decentralized agent memory for the Lightning economy."""

__version__ = "0.7.0"
