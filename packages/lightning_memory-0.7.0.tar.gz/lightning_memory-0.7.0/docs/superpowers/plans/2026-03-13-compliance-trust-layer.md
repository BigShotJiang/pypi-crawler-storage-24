# Lightning Memory Compliance & Trust Layer Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add budget enforcement, vendor KYC tracking, community reputation aggregation, and a payment pre-flight gate to lightning-memory — positioning it as the trust/compliance layer for L402 agent commerce.

**Architecture:** Three new modules layer on top of the existing `IntelligenceEngine`: (1) `budget.py` stores and enforces per-vendor spending limits in SQLite, (2) `trust.py` aggregates community reputation from Nostr relay-synced memories using NIP-85 Trusted Assertions, (3) `preflight.py` combines budget limits + anomaly detection + vendor trust into a single approve/reject/escalate gate. New MCP tools and gateway endpoints expose these to agents. Existing modules (`db.py`, `intelligence.py`, `server.py`, `gateway.py`) are extended minimally.

**Tech Stack:** Python 3.10+, SQLite/FTS5, MCP (FastMCP), Starlette (gateway), Nostr NIP-78/NIP-85, secp256k1

**Research context:** Based on landscape research (March 2026):
- No L402 + KYA integration exists yet — this is greenfield
- NIP-85 (Trusted Assertions, merged Jan 2026) provides the Nostr standard for trust scores
- ERC-8004 handles on-chain agent identity but nobody bridges it to Lightning
- Coinbase agentic wallets have spending controls; Google AP2 has mandates — but neither is Lightning-native
- EU MiCA full enforcement July 2026; AI Act August 2026 — compliance features are time-sensitive
- The meeting contact (Michael Anton Fischer) needs: enforcement framework, approval processes, KYC/KYT compliance hooks

---

## File Structure

### New Files
| File | Responsibility |
|------|---------------|
| `lightning_memory/budget.py` | Budget rules storage, limit checking, CRUD operations |
| `lightning_memory/trust.py` | Community reputation aggregation, NIP-85 trust assertions, vendor KYC status |
| `lightning_memory/preflight.py` | Payment pre-flight gate: combines budget + anomaly + trust into approve/reject/escalate |
| `tests/test_budget.py` | Budget engine tests |
| `tests/test_trust.py` | Trust/community reputation tests |
| `tests/test_preflight.py` | Pre-flight gate tests |

### Modified Files
| File | Changes |
|------|---------|
| `lightning_memory/db.py` | Add `budget_rules` and `vendor_kyc` tables to schema |
| `lightning_memory/lightning.py` | Add `BudgetRule`, `PreflightDecision`, `VendorTrust` dataclasses |
| `lightning_memory/server.py` | Add 4 new MCP tools: `ln_budget_set`, `ln_budget_status_v2`, `ln_vendor_trust`, `ln_preflight` |
| `lightning_memory/gateway.py` | Add 3 new gateway routes: `/ln/budget`, `/ln/trust/{vendor}`, `/ln/preflight` |
| `lightning_memory/config.py` | Add default pricing for new gateway operations |
| `lightning_memory/nostr.py` | Add NIP-85 event kind constant and trust assertion parsing |
| `tests/test_intelligence.py` | Add budget-aware anomaly tests |
| `tests/test_server.py` | Add tool count assertion update (9 → 13) |
| `tests/test_gateway.py` | Add new route tests |

---

## Chunk 1: Budget Enforcement Engine

### Task 1: Add budget_rules table to schema

**Files:**
- Modify: `lightning_memory/db.py:36-68` (`_ensure_schema`)
- Test: `tests/test_db.py`

- [ ] **Step 1: Write the failing test**

In `tests/test_db.py`, add:

```python
def test_budget_rules_table_exists(tmp_db):
    """Budget rules table should be created by schema init."""
    row = tmp_db.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='budget_rules'"
    ).fetchone()
    assert row is not None, "budget_rules table should exist"


def test_vendor_kyc_table_exists(tmp_db):
    """Vendor KYC table should be created by schema init."""
    row = tmp_db.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='vendor_kyc'"
    ).fetchone()
    assert row is not None, "vendor_kyc table should exist"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_db.py::test_budget_rules_table_exists tests/test_db.py::test_vendor_kyc_table_exists -v`
Expected: FAIL — tables don't exist

- [ ] **Step 3: Add tables to schema**

In `lightning_memory/db.py`, add to the `_ensure_schema` executescript string, after the `idx_memories_nostr` index:

```python
        CREATE TABLE IF NOT EXISTS budget_rules (
            id TEXT PRIMARY KEY,
            vendor TEXT NOT NULL,
            max_sats_per_txn INTEGER,
            max_sats_per_day INTEGER,
            max_sats_per_month INTEGER,
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_budget_vendor ON budget_rules(vendor);

        CREATE TABLE IF NOT EXISTS vendor_kyc (
            vendor TEXT PRIMARY KEY,
            kyc_verified INTEGER NOT NULL DEFAULT 0,
            jurisdiction TEXT DEFAULT '',
            verification_source TEXT DEFAULT '',
            verified_at REAL,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        );
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_db.py::test_budget_rules_table_exists tests/test_db.py::test_vendor_kyc_table_exists -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
cd ~/Projects/lightning-memory
git add lightning_memory/db.py tests/test_db.py
git commit -m "feat: add budget_rules and vendor_kyc tables to schema"
```

---

### Task 2: Add data models for budget, trust, and preflight

**Files:**
- Modify: `lightning_memory/lightning.py`

- [ ] **Step 1: Write the failing test**

In `tests/test_budget.py` (new file):

```python
"""Tests for budget enforcement engine."""

from lightning_memory.lightning import BudgetRule, PreflightDecision, VendorTrust


def test_budget_rule_to_dict():
    rule = BudgetRule(
        vendor="bitrefill.com",
        max_sats_per_txn=1000,
        max_sats_per_day=5000,
    )
    d = rule.to_dict()
    assert d["vendor"] == "bitrefill.com"
    assert d["max_sats_per_txn"] == 1000
    assert d["max_sats_per_day"] == 5000
    assert d["max_sats_per_month"] is None
    assert d["enabled"] is True


def test_preflight_decision_to_dict():
    decision = PreflightDecision(
        verdict="approve",
        vendor="bitrefill.com",
        proposed_sats=500,
    )
    d = decision.to_dict()
    assert d["verdict"] == "approve"
    assert d["reasons"] == []


def test_vendor_trust_to_dict():
    trust = VendorTrust(
        vendor="bitrefill.com",
        kyc_verified=True,
        jurisdiction="US",
        community_score=0.92,
        attestation_count=15,
    )
    d = trust.to_dict()
    assert d["kyc_verified"] is True
    assert d["community_score"] == 0.92
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_budget.py -v`
Expected: FAIL — ImportError, classes don't exist

- [ ] **Step 3: Add dataclasses to lightning.py**

Append to `lightning_memory/lightning.py`:

```python
@dataclass
class BudgetRule:
    """Spending limit rule for a vendor."""

    vendor: str
    max_sats_per_txn: int | None = None
    max_sats_per_day: int | None = None
    max_sats_per_month: int | None = None
    enabled: bool = True

    def to_dict(self) -> dict:
        return {
            "vendor": self.vendor,
            "max_sats_per_txn": self.max_sats_per_txn,
            "max_sats_per_day": self.max_sats_per_day,
            "max_sats_per_month": self.max_sats_per_month,
            "enabled": self.enabled,
        }


@dataclass
class VendorTrust:
    """Combined trust profile for a vendor."""

    vendor: str
    kyc_verified: bool = False
    jurisdiction: str = ""
    community_score: float = 0.0
    attestation_count: int = 0
    local_reputation: VendorReputation | None = None

    def to_dict(self) -> dict:
        return {
            "vendor": self.vendor,
            "kyc_verified": self.kyc_verified,
            "jurisdiction": self.jurisdiction,
            "community_score": self.community_score,
            "attestation_count": self.attestation_count,
            "local_reputation": self.local_reputation.to_dict() if self.local_reputation else None,
        }


@dataclass
class PreflightDecision:
    """Result of a payment pre-flight check."""

    verdict: str = "approve"  # approve | reject | escalate
    vendor: str = ""
    proposed_sats: int = 0
    reasons: list[str] = field(default_factory=list)
    budget_remaining_today: int | None = None
    anomaly_verdict: str = ""
    trust_score: float = 0.0

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "vendor": self.vendor,
            "proposed_sats": self.proposed_sats,
            "reasons": self.reasons,
            "budget_remaining_today": self.budget_remaining_today,
            "anomaly_verdict": self.anomaly_verdict,
            "trust_score": self.trust_score,
        }
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_budget.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
cd ~/Projects/lightning-memory
git add lightning_memory/lightning.py tests/test_budget.py
git commit -m "feat: add BudgetRule, VendorTrust, PreflightDecision dataclasses"
```

---

### Task 3: Implement budget engine (CRUD + limit checking)

**Files:**
- Create: `lightning_memory/budget.py`
- Test: `tests/test_budget.py` (append)

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_budget.py`:

```python
import time
import pytest
from lightning_memory.budget import BudgetEngine
from lightning_memory.db import get_connection


@pytest.fixture
def budget_db():
    conn = get_connection(":memory:")
    yield conn
    conn.close()


@pytest.fixture
def budget_engine(budget_db):
    return BudgetEngine(budget_db)


def test_set_and_get_rule(budget_engine):
    budget_engine.set_rule("bitrefill.com", max_sats_per_txn=1000, max_sats_per_day=5000)
    rule = budget_engine.get_rule("bitrefill.com")
    assert rule is not None
    assert rule.max_sats_per_txn == 1000
    assert rule.max_sats_per_day == 5000


def test_get_rule_nonexistent(budget_engine):
    rule = budget_engine.get_rule("unknown.com")
    assert rule is None


def test_check_txn_limit_ok(budget_engine):
    budget_engine.set_rule("vendor.com", max_sats_per_txn=1000)
    ok, reason = budget_engine.check_limit("vendor.com", 500)
    assert ok is True
    assert reason == ""


def test_check_txn_limit_exceeded(budget_engine):
    budget_engine.set_rule("vendor.com", max_sats_per_txn=1000)
    ok, reason = budget_engine.check_limit("vendor.com", 1500)
    assert ok is False
    assert "per-transaction limit" in reason


def test_check_daily_limit(budget_engine, budget_db):
    budget_engine.set_rule("vendor.com", max_sats_per_day=2000)
    # Simulate prior spending today by inserting transaction memories
    from lightning_memory.db import store_memory
    import json
    store_memory(budget_db, "tx1", "Paid 800 sats to vendor.com", "transaction",
                 {"vendor": "vendor.com", "amount_sats": 800})
    store_memory(budget_db, "tx2", "Paid 700 sats to vendor.com", "transaction",
                 {"vendor": "vendor.com", "amount_sats": 700})
    # 1500 spent today + proposed 600 = 2100 > 2000
    ok, reason = budget_engine.check_limit("vendor.com", 600)
    assert ok is False
    assert "daily limit" in reason


def test_no_rule_means_approve(budget_engine):
    ok, reason = budget_engine.check_limit("norule.com", 99999)
    assert ok is True


def test_delete_rule(budget_engine):
    budget_engine.set_rule("vendor.com", max_sats_per_txn=100)
    assert budget_engine.get_rule("vendor.com") is not None
    budget_engine.delete_rule("vendor.com")
    assert budget_engine.get_rule("vendor.com") is None


def test_list_rules(budget_engine):
    budget_engine.set_rule("a.com", max_sats_per_txn=100)
    budget_engine.set_rule("b.com", max_sats_per_txn=200)
    rules = budget_engine.list_rules()
    assert len(rules) == 2
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_budget.py::test_set_and_get_rule -v`
Expected: FAIL — `budget.py` doesn't exist

- [ ] **Step 3: Implement budget.py**

Create `lightning_memory/budget.py`:

```python
"""Budget enforcement engine.

Stores per-vendor spending limits and checks proposed payments
against those limits using transaction history from the memories table.
"""

from __future__ import annotations

import json
import sqlite3
import time
import uuid

from .lightning import BudgetRule


class BudgetEngine:
    """CRUD and enforcement for vendor spending limits."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def set_rule(
        self,
        vendor: str,
        max_sats_per_txn: int | None = None,
        max_sats_per_day: int | None = None,
        max_sats_per_month: int | None = None,
    ) -> BudgetRule:
        """Create or update a budget rule for a vendor."""
        now = time.time()
        existing = self.get_rule(vendor)
        rule_id = existing.vendor if existing else str(uuid.uuid4())[:8]

        self.conn.execute(
            """INSERT INTO budget_rules (id, vendor, max_sats_per_txn, max_sats_per_day,
                   max_sats_per_month, enabled, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, 1, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                   max_sats_per_txn=excluded.max_sats_per_txn,
                   max_sats_per_day=excluded.max_sats_per_day,
                   max_sats_per_month=excluded.max_sats_per_month,
                   updated_at=excluded.updated_at""",
            (rule_id, vendor, max_sats_per_txn, max_sats_per_day,
             max_sats_per_month, now, now),
        )
        self.conn.commit()
        return BudgetRule(
            vendor=vendor,
            max_sats_per_txn=max_sats_per_txn,
            max_sats_per_day=max_sats_per_day,
            max_sats_per_month=max_sats_per_month,
        )

    def get_rule(self, vendor: str) -> BudgetRule | None:
        """Get the budget rule for a vendor, or None."""
        row = self.conn.execute(
            "SELECT * FROM budget_rules WHERE vendor = ? AND enabled = 1",
            (vendor,),
        ).fetchone()
        if not row:
            return None
        return BudgetRule(
            vendor=row["vendor"],
            max_sats_per_txn=row["max_sats_per_txn"],
            max_sats_per_day=row["max_sats_per_day"],
            max_sats_per_month=row["max_sats_per_month"],
            enabled=bool(row["enabled"]),
        )

    def delete_rule(self, vendor: str) -> bool:
        """Delete a budget rule. Returns True if deleted."""
        cursor = self.conn.execute(
            "DELETE FROM budget_rules WHERE vendor = ?", (vendor,)
        )
        self.conn.commit()
        return cursor.rowcount > 0

    def list_rules(self) -> list[BudgetRule]:
        """List all active budget rules."""
        rows = self.conn.execute(
            "SELECT * FROM budget_rules WHERE enabled = 1 ORDER BY vendor"
        ).fetchall()
        return [
            BudgetRule(
                vendor=r["vendor"],
                max_sats_per_txn=r["max_sats_per_txn"],
                max_sats_per_day=r["max_sats_per_day"],
                max_sats_per_month=r["max_sats_per_month"],
                enabled=bool(r["enabled"]),
            )
            for r in rows
        ]

    def check_limit(self, vendor: str, proposed_sats: int) -> tuple[bool, str]:
        """Check if a proposed payment is within budget limits.

        Returns (ok, reason). If ok is True, reason is empty.
        """
        rule = self.get_rule(vendor)
        if rule is None:
            return True, ""

        # Per-transaction check
        if rule.max_sats_per_txn and proposed_sats > rule.max_sats_per_txn:
            return False, (
                f"{proposed_sats} sats exceeds per-transaction limit "
                f"of {rule.max_sats_per_txn} sats for {vendor}"
            )

        # Daily spending check
        if rule.max_sats_per_day:
            spent_today = self._spent_since(vendor, _start_of_day())
            if spent_today + proposed_sats > rule.max_sats_per_day:
                return False, (
                    f"{proposed_sats} sats would exceed daily limit of "
                    f"{rule.max_sats_per_day} sats for {vendor} "
                    f"({spent_today} already spent today)"
                )

        # Monthly spending check
        if rule.max_sats_per_month:
            spent_month = self._spent_since(vendor, _start_of_month())
            if spent_month + proposed_sats > rule.max_sats_per_month:
                return False, (
                    f"{proposed_sats} sats would exceed monthly limit of "
                    f"{rule.max_sats_per_month} sats for {vendor} "
                    f"({spent_month} already spent this month)"
                )

        return True, ""

    def spent_today(self, vendor: str) -> int:
        """Get total sats spent to a vendor today."""
        return self._spent_since(vendor, _start_of_day())

    def _spent_since(self, vendor: str, since: float) -> int:
        """Sum sats spent to a vendor since a timestamp."""
        rows = self.conn.execute(
            """SELECT metadata FROM memories
               WHERE type = 'transaction' AND created_at >= ?""",
            (since,),
        ).fetchall()

        total = 0
        vendor_lower = vendor.lower()
        for row in rows:
            meta = json.loads(row["metadata"]) if row["metadata"] else {}
            if meta.get("vendor", "").lower() == vendor_lower:
                total += int(meta.get("amount_sats", 0))
        return total


def _start_of_day() -> float:
    """Unix timestamp for start of today (UTC)."""
    import datetime
    now = datetime.datetime.now(datetime.timezone.utc)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return start.timestamp()


def _start_of_month() -> float:
    """Unix timestamp for start of this month (UTC)."""
    import datetime
    now = datetime.datetime.now(datetime.timezone.utc)
    start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    return start.timestamp()
```

- [ ] **Step 4: Run all budget tests**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_budget.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
cd ~/Projects/lightning-memory
git add lightning_memory/budget.py tests/test_budget.py
git commit -m "feat: implement budget enforcement engine with per-txn/day/month limits"
```

---

## Chunk 2: Vendor Trust & Community Reputation

### Task 4: Implement vendor KYC tracking

**Files:**
- Create: `lightning_memory/trust.py`
- Test: `tests/test_trust.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_trust.py`:

```python
"""Tests for vendor trust and community reputation."""

import pytest
from lightning_memory.trust import TrustEngine
from lightning_memory.db import get_connection


@pytest.fixture
def trust_db():
    conn = get_connection(":memory:")
    yield conn
    conn.close()


@pytest.fixture
def trust_engine(trust_db):
    return TrustEngine(trust_db)


def test_set_vendor_kyc(trust_engine):
    trust_engine.set_vendor_kyc("bitrefill.com", verified=True, jurisdiction="EU")
    status = trust_engine.get_vendor_kyc("bitrefill.com")
    assert status["kyc_verified"] is True
    assert status["jurisdiction"] == "EU"


def test_unverified_vendor(trust_engine):
    status = trust_engine.get_vendor_kyc("unknown.com")
    assert status["kyc_verified"] is False


def test_vendor_trust_profile(trust_engine, trust_db):
    """Full trust profile combines KYC + local reputation."""
    from lightning_memory.db import store_memory
    # Add some transaction history
    store_memory(trust_db, "tx1", "Paid 100 sats to vendor.com", "transaction",
                 {"vendor": "vendor.com", "amount_sats": 100})
    store_memory(trust_db, "tx2", "Paid 200 sats to vendor.com", "transaction",
                 {"vendor": "vendor.com", "amount_sats": 200})
    trust_engine.set_vendor_kyc("vendor.com", verified=True, jurisdiction="US")

    profile = trust_engine.vendor_trust_profile("vendor.com")
    assert profile.kyc_verified is True
    assert profile.local_reputation is not None
    assert profile.local_reputation.total_txns == 2


def test_community_score_no_attestations(trust_engine):
    """Community score is 0 when no attestations exist."""
    profile = trust_engine.vendor_trust_profile("new.com")
    assert profile.community_score == 0.0
    assert profile.attestation_count == 0
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_trust.py -v`
Expected: FAIL — `trust.py` doesn't exist

- [ ] **Step 3: Implement trust.py**

Create `lightning_memory/trust.py`:

```python
"""Vendor trust and community reputation engine.

Combines local KYC status, transaction-based reputation, and
community attestations (via Nostr NIP-85 Trusted Assertions)
into a unified trust profile per vendor.
"""

from __future__ import annotations

import json
import sqlite3
import time

from .intelligence import IntelligenceEngine
from .lightning import VendorTrust


class TrustEngine:
    """Vendor trust profiles: KYC + reputation + community attestations."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def set_vendor_kyc(
        self,
        vendor: str,
        verified: bool = False,
        jurisdiction: str = "",
        source: str = "",
    ) -> dict:
        """Set KYC verification status for a vendor."""
        now = time.time()
        self.conn.execute(
            """INSERT INTO vendor_kyc (vendor, kyc_verified, jurisdiction,
                   verification_source, verified_at, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(vendor) DO UPDATE SET
                   kyc_verified=excluded.kyc_verified,
                   jurisdiction=excluded.jurisdiction,
                   verification_source=excluded.verification_source,
                   verified_at=excluded.verified_at,
                   updated_at=excluded.updated_at""",
            (vendor, int(verified), jurisdiction, source,
             now if verified else None, now, now),
        )
        self.conn.commit()
        return {"vendor": vendor, "kyc_verified": verified, "jurisdiction": jurisdiction}

    def get_vendor_kyc(self, vendor: str) -> dict:
        """Get KYC status for a vendor."""
        row = self.conn.execute(
            "SELECT * FROM vendor_kyc WHERE vendor = ?", (vendor,)
        ).fetchone()
        if not row:
            return {"vendor": vendor, "kyc_verified": False, "jurisdiction": ""}
        return {
            "vendor": row["vendor"],
            "kyc_verified": bool(row["kyc_verified"]),
            "jurisdiction": row["jurisdiction"],
            "verification_source": row["verification_source"],
            "verified_at": row["verified_at"],
        }

    def community_reputation(self, vendor: str) -> tuple[float, int]:
        """Aggregate community reputation from synced attestation memories.

        Looks for memories of type 'attestation' referencing this vendor,
        which are synced from Nostr relays (NIP-85 Trusted Assertions).

        Returns (score 0.0-1.0, attestation_count).
        """
        rows = self.conn.execute(
            """SELECT content, metadata FROM memories
               WHERE type = 'attestation'
               ORDER BY created_at DESC""",
        ).fetchall()

        vendor_lower = vendor.lower()
        scores: list[float] = []
        for row in rows:
            meta = json.loads(row["metadata"]) if row["metadata"] else {}
            target = meta.get("vendor", "").lower()
            if target != vendor_lower:
                continue
            score = meta.get("trust_score")
            if score is not None:
                scores.append(float(score))

        if not scores:
            return 0.0, 0
        return sum(scores) / len(scores), len(scores)

    def vendor_trust_profile(self, vendor: str) -> VendorTrust:
        """Build a complete trust profile for a vendor."""
        kyc = self.get_vendor_kyc(vendor)
        intel = IntelligenceEngine(self.conn)
        local_rep = intel.vendor_report(vendor)
        community_score, attestation_count = self.community_reputation(vendor)

        return VendorTrust(
            vendor=vendor,
            kyc_verified=kyc["kyc_verified"],
            jurisdiction=kyc.get("jurisdiction", ""),
            community_score=community_score,
            attestation_count=attestation_count,
            local_reputation=local_rep,
        )
```

- [ ] **Step 4: Run tests**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_trust.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
cd ~/Projects/lightning-memory
git add lightning_memory/trust.py tests/test_trust.py
git commit -m "feat: implement vendor trust engine with KYC tracking and community reputation"
```

---

### Task 5: Add NIP-85 trust assertion support to Nostr module

**Files:**
- Modify: `lightning_memory/nostr.py`
- Test: `tests/test_nostr.py` (append)

- [ ] **Step 1: Write the failing test**

Add to `tests/test_nostr.py`:

```python
from lightning_memory.nostr import NIP85_KIND, parse_trust_assertion


def test_nip85_kind_constant():
    assert NIP85_KIND == 30382


def test_parse_trust_assertion():
    """Parse a NIP-85 Trusted Assertion event into vendor trust data."""
    event = {
        "kind": 30382,
        "content": '{"score": 0.89, "vendor": "bitrefill.com", "basis": "transaction_history"}',
        "tags": [
            ["d", "trust:bitrefill.com"],
            ["p", "target_pubkey_hex"],
        ],
        "pubkey": "attester_pubkey_hex",
        "created_at": 1710000000,
    }
    result = parse_trust_assertion(event)
    assert result["vendor"] == "bitrefill.com"
    assert result["trust_score"] == 0.89
    assert result["attester"] == "attester_pubkey_hex"


def test_parse_trust_assertion_invalid():
    """Invalid event returns None."""
    result = parse_trust_assertion({"kind": 1, "content": "{}"})
    assert result is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_nostr.py::test_nip85_kind_constant -v`
Expected: FAIL — `NIP85_KIND` not defined

- [ ] **Step 3: Add NIP-85 support to nostr.py**

Add to `lightning_memory/nostr.py` (after existing constants/imports):

```python
NIP85_KIND = 30382  # NIP-85 Trusted Assertions


def parse_trust_assertion(event: dict) -> dict | None:
    """Parse a NIP-85 Trusted Assertion event.

    Returns dict with vendor, trust_score, attester, timestamp
    or None if the event is not a valid trust assertion.
    """
    if event.get("kind") != NIP85_KIND:
        return None

    try:
        content = json.loads(event.get("content", "{}"))
    except (json.JSONDecodeError, TypeError):
        return None

    vendor = content.get("vendor")
    score = content.get("score")
    if vendor is None or score is None:
        return None

    return {
        "vendor": vendor,
        "trust_score": float(score),
        "attester": event.get("pubkey", ""),
        "basis": content.get("basis", ""),
        "timestamp": event.get("created_at", 0),
    }
```

Note: check if `json` is already imported in `nostr.py`. If not, add `import json` at the top.

- [ ] **Step 4: Run tests**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_nostr.py::test_nip85_kind_constant tests/test_nostr.py::test_parse_trust_assertion tests/test_nostr.py::test_parse_trust_assertion_invalid -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
cd ~/Projects/lightning-memory
git add lightning_memory/nostr.py tests/test_nostr.py
git commit -m "feat: add NIP-85 Trusted Assertion parsing for community reputation"
```

---

## Chunk 3: Payment Pre-flight Gate

### Task 6: Implement the pre-flight decision engine

**Files:**
- Create: `lightning_memory/preflight.py`
- Test: `tests/test_preflight.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_preflight.py`:

```python
"""Tests for payment pre-flight gate."""

import pytest
from lightning_memory.preflight import PreflightEngine
from lightning_memory.budget import BudgetEngine
from lightning_memory.trust import TrustEngine
from lightning_memory.db import get_connection, store_memory


@pytest.fixture
def pf_db():
    conn = get_connection(":memory:")
    yield conn
    conn.close()


@pytest.fixture
def pf_engine(pf_db):
    return PreflightEngine(pf_db)


def test_approve_no_rules(pf_engine):
    """No budget rules + no history = approve."""
    decision = pf_engine.check("newvendor.com", 100)
    assert decision.verdict == "approve"


def test_reject_over_budget(pf_engine, pf_db):
    """Exceeding per-transaction budget = reject."""
    budget = BudgetEngine(pf_db)
    budget.set_rule("vendor.com", max_sats_per_txn=500)
    decision = pf_engine.check("vendor.com", 1000)
    assert decision.verdict == "reject"
    assert any("per-transaction limit" in r for r in decision.reasons)


def test_escalate_anomaly(pf_engine, pf_db):
    """High anomaly with no budget rule = escalate."""
    # Create history of small payments
    for i in range(5):
        store_memory(pf_db, f"tx{i}", f"Paid 50 sats to vendor.com",
                     "transaction", {"vendor": "vendor.com", "amount_sats": 50})
    decision = pf_engine.check("vendor.com", 5000)
    assert decision.verdict == "escalate"
    assert decision.anomaly_verdict == "high"


def test_approve_normal_payment(pf_engine, pf_db):
    """Normal payment within budget = approve."""
    budget = BudgetEngine(pf_db)
    budget.set_rule("vendor.com", max_sats_per_txn=1000)
    for i in range(3):
        store_memory(pf_db, f"tx{i}", f"Paid 100 sats to vendor.com",
                     "transaction", {"vendor": "vendor.com", "amount_sats": 100})
    decision = pf_engine.check("vendor.com", 120)
    assert decision.verdict == "approve"


def test_escalate_first_time_vendor(pf_engine):
    """First-time vendor with significant amount = escalate."""
    decision = pf_engine.check("neverpaid.com", 500)
    assert decision.verdict == "escalate"
    assert decision.anomaly_verdict == "first_time"


def test_approve_first_time_small_amount(pf_engine):
    """First-time vendor with tiny amount = approve (not worth escalating)."""
    decision = pf_engine.check("neverpaid.com", 5)
    assert decision.verdict == "approve"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_preflight.py -v`
Expected: FAIL — `preflight.py` doesn't exist

- [ ] **Step 3: Implement preflight.py**

Create `lightning_memory/preflight.py`:

```python
"""Payment pre-flight gate.

Combines budget limits, anomaly detection, and vendor trust
into a single approve/reject/escalate decision before payment.
"""

from __future__ import annotations

import sqlite3

from .budget import BudgetEngine
from .intelligence import IntelligenceEngine
from .lightning import PreflightDecision
from .trust import TrustEngine

# Payments under this threshold skip escalation for first-time vendors
SMALL_PAYMENT_THRESHOLD = 10  # sats


class PreflightEngine:
    """Pre-flight check combining budget + anomaly + trust."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.budget = BudgetEngine(conn)
        self.intel = IntelligenceEngine(conn)
        self.trust = TrustEngine(conn)

    def check(self, vendor: str, amount_sats: int) -> PreflightDecision:
        """Run all pre-flight checks and return a decision."""
        decision = PreflightDecision(vendor=vendor, proposed_sats=amount_sats)
        reasons: list[str] = []

        # 1. Budget check (hard limit — reject if exceeded)
        budget_ok, budget_reason = self.budget.check_limit(vendor, amount_sats)
        if not budget_ok:
            decision.verdict = "reject"
            reasons.append(budget_reason)
            decision.reasons = reasons
            return decision

        # Budget remaining info
        rule = self.budget.get_rule(vendor)
        if rule and rule.max_sats_per_day:
            spent = self.budget.spent_today(vendor)
            decision.budget_remaining_today = rule.max_sats_per_day - spent

        # 2. Anomaly check (soft signal — escalate if high)
        anomaly = self.intel.anomaly_check(vendor, amount_sats)
        decision.anomaly_verdict = anomaly.verdict

        if anomaly.verdict == "high":
            decision.verdict = "escalate"
            reasons.append(anomaly.context)

        if anomaly.verdict == "first_time" and amount_sats > SMALL_PAYMENT_THRESHOLD:
            decision.verdict = "escalate"
            reasons.append(f"First-time vendor: {vendor}. Consider starting with a smaller payment.")

        # 3. Trust score (informational, used for escalate/approve edge cases)
        profile = self.trust.vendor_trust_profile(vendor)
        decision.trust_score = profile.community_score

        # If KYC verified and community trusted, downgrade escalate to approve
        if decision.verdict == "escalate" and profile.kyc_verified and profile.community_score >= 0.8:
            decision.verdict = "approve"
            reasons.append(f"Downgraded from escalate: vendor is KYC-verified with community score {profile.community_score:.2f}")

        decision.reasons = reasons
        if not reasons:
            decision.verdict = "approve"
        return decision
```

- [ ] **Step 4: Run tests**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_preflight.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
cd ~/Projects/lightning-memory
git add lightning_memory/preflight.py tests/test_preflight.py
git commit -m "feat: implement payment pre-flight gate combining budget + anomaly + trust"
```

---

## Chunk 4: MCP Tools & Gateway Routes

### Task 7: Add 4 new MCP tools to server.py

**Files:**
- Modify: `lightning_memory/server.py`
- Test: `tests/test_server.py`

- [ ] **Step 1: Write the failing test for tool count**

In `tests/test_server.py`, find the existing tool count assertion and note the current expected count. Add or update:

```python
def test_tool_count():
    """Server should expose exactly 13 tools."""
    from lightning_memory.server import mcp
    tools = mcp._tool_manager._tools  # FastMCP internal
    assert len(tools) == 13, f"Expected 13 tools, got {len(tools)}: {list(tools.keys())}"
```

Note: Check the existing test file for how tool count is currently tested and follow the same pattern. The current count is 9; after adding 4 new tools it should be 13.

- [ ] **Step 2: Run test to verify it fails**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_server.py::test_tool_count -v`
Expected: FAIL — only 9 tools

- [ ] **Step 3: Add new tools to server.py**

Add these imports to the top of `lightning_memory/server.py`:

```python
from .budget import BudgetEngine
from .trust import TrustEngine
from .preflight import PreflightEngine
```

Add helper functions:

```python
def _get_budget() -> BudgetEngine:
    return BudgetEngine(conn=_get_engine().conn)


def _get_trust() -> TrustEngine:
    return TrustEngine(conn=_get_engine().conn)


def _get_preflight() -> PreflightEngine:
    return PreflightEngine(conn=_get_engine().conn)
```

Add 4 new tool definitions:

```python
@mcp.tool()
def ln_budget_set(
    vendor: str,
    max_sats_per_txn: int | None = None,
    max_sats_per_day: int | None = None,
    max_sats_per_month: int | None = None,
) -> dict:
    """Set spending limits for a vendor.

    Creates budget rules that the pre-flight gate enforces.
    Any payment exceeding these limits will be rejected.

    Args:
        vendor: Vendor name or domain (e.g., "bitrefill.com").
        max_sats_per_txn: Maximum sats allowed per single transaction.
        max_sats_per_day: Maximum total sats per day to this vendor.
        max_sats_per_month: Maximum total sats per month to this vendor.

    Returns:
        The created/updated budget rule.
    """
    budget = _get_budget()
    rule = budget.set_rule(
        vendor, max_sats_per_txn=max_sats_per_txn,
        max_sats_per_day=max_sats_per_day, max_sats_per_month=max_sats_per_month,
    )
    return {"status": "set", "rule": rule.to_dict()}


@mcp.tool()
def ln_budget_check(vendor: str | None = None) -> dict:
    """List budget rules and current spending status.

    Shows all active budget rules, or details for a specific vendor
    including how much has been spent today and this month.

    Args:
        vendor: Optional vendor to check. If omitted, lists all rules.

    Returns:
        Budget rules with current spending against limits.
    """
    budget = _get_budget()
    if vendor:
        rule = budget.get_rule(vendor)
        if not rule:
            return {"vendor": vendor, "has_rule": False}
        return {
            "vendor": vendor,
            "has_rule": True,
            "rule": rule.to_dict(),
            "spent_today": budget.spent_today(vendor),
        }
    rules = budget.list_rules()
    return {
        "count": len(rules),
        "rules": [r.to_dict() for r in rules],
    }


@mcp.tool()
def ln_vendor_trust(vendor: str) -> dict:
    """Get a vendor's full trust profile.

    Combines KYC verification status, local transaction reputation,
    and community trust attestations (from Nostr NIP-85) into a
    unified trust profile.

    Args:
        vendor: Vendor name or domain.

    Returns:
        Trust profile: KYC status, jurisdiction, community score,
        attestation count, and local reputation data.
    """
    trust = _get_trust()
    profile = trust.vendor_trust_profile(vendor)
    return {"trust": profile.to_dict()}


@mcp.tool()
def ln_preflight(vendor: str, amount_sats: int) -> dict:
    """Pre-flight check before making a payment.

    Runs budget limits, anomaly detection, and trust verification
    to produce an approve/reject/escalate decision. Use this before
    every payment to catch overspending, price anomalies, and
    unverified vendors.

    Args:
        vendor: Vendor name or domain.
        amount_sats: Proposed payment amount in satoshis.

    Returns:
        Decision: verdict (approve/reject/escalate), reasons,
        budget remaining, anomaly status, and trust score.
    """
    pf = _get_preflight()
    decision = pf.check(vendor, amount_sats)
    return {"decision": decision.to_dict()}
```

- [ ] **Step 4: Run tool count test**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_server.py::test_tool_count -v`
Expected: PASS (13 tools)

- [ ] **Step 5: Run full test suite**

Run: `cd ~/Projects/lightning-memory && python -m pytest -x`
Expected: All PASS. Check for any broken existing tests (especially hardcoded tool counts).

- [ ] **Step 6: Commit**

```bash
cd ~/Projects/lightning-memory
git add lightning_memory/server.py tests/test_server.py
git commit -m "feat: add ln_budget_set, ln_budget_check, ln_vendor_trust, ln_preflight MCP tools"
```

---

### Task 8: Add gateway routes for new tools

**Files:**
- Modify: `lightning_memory/gateway.py`
- Modify: `lightning_memory/config.py` (add pricing)
- Test: `tests/test_gateway.py` (append)

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_gateway.py`:

```python
def test_preflight_route_exists(test_client):
    """POST /ln/preflight should be routed (returns 402 without auth)."""
    resp = test_client.post("/ln/preflight", json={"vendor": "test.com", "amount_sats": 100})
    assert resp.status_code == 402


def test_trust_route_exists(test_client):
    """GET /ln/trust/{vendor} should be routed (returns 402 without auth)."""
    resp = test_client.get("/ln/trust/bitrefill.com")
    assert resp.status_code == 402


def test_budget_route_exists(test_client):
    """GET /ln/budget should be routed (returns 402 without auth)."""
    resp = test_client.get("/ln/budget")
    assert resp.status_code == 402
```

Note: Check how `test_client` fixture is set up in existing `test_gateway.py` — it likely uses Starlette's TestClient with a mock Phoenixd. Follow the same pattern.

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_gateway.py::test_preflight_route_exists -v`
Expected: FAIL — 404 (route doesn't exist)

- [ ] **Step 3: Add routes and handlers to gateway.py**

Add to `_ROUTE_MAP` in `gateway.py`:

```python
"/ln/preflight": "ln_preflight",
"/ln/trust": "ln_vendor_trust",
"/ln/budget": "ln_budget_check",
```

Add handler functions:

```python
async def ln_preflight_handler(request: Request) -> JSONResponse:
    """Pre-flight payment check (L402-gated)."""
    body = await request.json()
    from .preflight import PreflightEngine
    pf = PreflightEngine(conn=_get_engine().conn)
    decision = pf.check(body["vendor"], body["amount_sats"])
    return JSONResponse({"decision": decision.to_dict()})


async def ln_trust_handler(request: Request) -> JSONResponse:
    """Vendor trust profile (L402-gated)."""
    vendor = request.path_params["name"]
    from .trust import TrustEngine
    trust = TrustEngine(conn=_get_engine().conn)
    profile = trust.vendor_trust_profile(vendor)
    return JSONResponse({"trust": profile.to_dict()})


async def ln_budget_handler(request: Request) -> JSONResponse:
    """Budget rules and spending status (L402-gated)."""
    from .budget import BudgetEngine
    budget = BudgetEngine(conn=_get_engine().conn)
    vendor = request.query_params.get("vendor")
    if vendor:
        rule = budget.get_rule(vendor)
        if not rule:
            return JSONResponse({"vendor": vendor, "has_rule": False})
        return JSONResponse({
            "vendor": vendor, "has_rule": True,
            "rule": rule.to_dict(), "spent_today": budget.spent_today(vendor),
        })
    rules = budget.list_rules()
    return JSONResponse({"count": len(rules), "rules": [r.to_dict() for r in rules]})
```

Add to `create_app()` routes list:

```python
Route("/ln/preflight", ln_preflight_handler, methods=["POST"]),
Route("/ln/trust/{name}", ln_trust_handler, methods=["GET"]),
Route("/ln/budget", ln_budget_handler, methods=["GET"]),
```

- [ ] **Step 4: Add pricing for new operations**

In `lightning_memory/config.py`, add to `DEFAULT_PRICING`:

```python
"ln_preflight": 3,
"ln_vendor_trust": 2,
"ln_budget_check": 1,
```

- [ ] **Step 5: Run gateway tests**

Run: `cd ~/Projects/lightning-memory && python -m pytest tests/test_gateway.py -v`
Expected: All PASS

- [ ] **Step 6: Run full test suite**

Run: `cd ~/Projects/lightning-memory && python -m pytest -x`
Expected: All PASS

- [ ] **Step 7: Commit**

```bash
cd ~/Projects/lightning-memory
git add lightning_memory/gateway.py lightning_memory/config.py tests/test_gateway.py
git commit -m "feat: add preflight, trust, and budget gateway routes with L402 pricing"
```

---

## Chunk 5: Update README & Version Bump

### Task 9: Update README with new tools

**Files:**
- Modify: `README.md`
- Modify: `lightning_memory/__init__.py` (version bump)

- [ ] **Step 1: Bump version**

In `pyproject.toml`, change version from `"0.4.1"` to `"0.5.0"`.

In `lightning_memory/__init__.py`, update `__version__` to `"0.5.0"` (check if version is defined there; if not, only update `pyproject.toml`).

- [ ] **Step 2: Add new tools to README**

Add after the `ln_anomaly_check` section in README.md:

```markdown
### `ln_budget_set`

Set spending limits for a vendor.

\```
ln_budget_set(vendor="bitrefill.com", max_sats_per_txn=1000, max_sats_per_day=5000)
# → {status: "set", rule: {vendor: "bitrefill.com", max_sats_per_txn: 1000, ...}}
\```

### `ln_budget_check`

List budget rules and current spending against limits.

\```
ln_budget_check(vendor="bitrefill.com")
# → {vendor: "bitrefill.com", has_rule: true, rule: {...}, spent_today: 350}
\```

### `ln_vendor_trust`

Get a vendor's full trust profile (KYC + reputation + community).

\```
ln_vendor_trust(vendor="bitrefill.com")
# → {trust: {kyc_verified: true, community_score: 0.89, attestation_count: 15, ...}}
\```

### `ln_preflight`

Pre-flight check before making a payment. **Use this before every payment.**

\```
ln_preflight(vendor="bitrefill.com", amount_sats=500)
# → {decision: {verdict: "approve", budget_remaining_today: 4500, trust_score: 0.89}}
\```
```

Add new gateway endpoints to the endpoints table:

```markdown
| `/ln/preflight` | POST | 3 sats | Pre-flight payment gate |
| `/ln/trust/{name}` | GET | 2 sats | Vendor trust profile |
| `/ln/budget` | GET | 1 sat | Budget rules and spending |
```

Update the comparison table to add a row:

```markdown
| Budget enforcement | Yes | No | No | No |
| KYC/trust profiles | Yes | No | No | No |
| Payment pre-flight gate | Yes | No | No | No |
```

Update the Roadmap section:

```markdown
- [x] Phase 5: Compliance & trust layer (budget enforcement, vendor KYC, community reputation, payment pre-flight gate)
```

- [ ] **Step 3: Run full test suite one final time**

Run: `cd ~/Projects/lightning-memory && python -m pytest -x`
Expected: All PASS

- [ ] **Step 4: Commit**

```bash
cd ~/Projects/lightning-memory
git add README.md pyproject.toml lightning_memory/__init__.py
git commit -m "docs: update README with compliance/trust tools, bump to v0.5.0"
```

---

## Summary

| Chunk | Tasks | New Files | Modified Files | New MCP Tools | New Gateway Routes |
|-------|-------|-----------|----------------|---------------|--------------------|
| 1: Budget Engine | 1-3 | `budget.py`, `test_budget.py` | `db.py`, `lightning.py` | — | — |
| 2: Trust & Reputation | 4-5 | `trust.py`, `test_trust.py` | `nostr.py` | — | — |
| 3: Pre-flight Gate | 6 | `preflight.py`, `test_preflight.py` | — | — | — |
| 4: MCP + Gateway | 7-8 | — | `server.py`, `gateway.py`, `config.py` | 4 | 3 |
| 5: README & Version | 9 | — | `README.md`, `pyproject.toml` | — | — |

**Total:** 9 tasks, 6 new files, 9 modified files, 4 new MCP tools (9→13), 3 new gateway routes (6→9), ~600 lines of new code + tests.
