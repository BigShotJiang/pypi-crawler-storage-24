# Lightning Memory Interactive Demo — Design Spec

**Date:** 2026-03-12
**Status:** Draft

## Overview

Two deliverables from one design: (1) an interactive split-screen walkthrough embedded as a React component in a jasonsosa.com blog post, and (2) a ~90s demo video rendered with Remotion + ElevenLabs voiceover for social sharing.

**Tagline:** "Don't trust. Verify. Remember."

**Narrative arc:** Victim → Sovereign → Merchant. An AI agent operates in the L402 marketplace, gets rugged by a vendor, uses Lightning Memory to protect itself, then becomes a merchant selling its knowledge to other agents.

## Deliverable 1: Interactive Blog Post Component

### Embedding Strategy

The jasonsosa.com blog system stores posts as HTML strings in `src/data/blog-posts.ts`, rendered via `dangerouslySetInnerHTML` in `BlogPost.tsx`. For an interactive component, we extend the `BlogPost` interface and rendering logic.

**Interface change in `blog-posts.ts`:**
- Add optional `component?: React.LazyExoticComponent<React.ComponentType>` field to the `BlogPost` interface
- Make `content` optional (or provide empty string fallback) for component-based posts
- The demo component entry uses `React.lazy(() => import('../components/lightning-memory-demo/LightningMemoryDemo'))` for code-splitting

**Rendering change in `BlogPost.tsx`:**
- If `post.component` exists, render it via `<Suspense>` wrapper — bypassing the `max-w-[680px]` prose container (demo needs full-width 1200px)
- Otherwise, fall back to existing `dangerouslySetInnerHTML` path

**Files to modify:**
- `src/data/blog-posts.ts` — update `BlogPost` interface, add new blog post entry with lazy component
- `src/pages/BlogPost.tsx` — conditional render with Suspense, skip prose container for component posts
- `src/components/lightning-memory-demo/` — new directory for demo components

### Layout

- **Hero:** Full-width, black background. "Don't trust. Verify. Remember." in large type. Subtitle: "What happens when AI agents get sovereign memory on Bitcoin rails." Bitcoin orange (#F7931A) accent.
- **Walkthrough:** Split-screen container, max-width 1200px centered.
  - Left panel (60%): Narrative title, description, animated visual (SVG/CSS agent nodes, Lightning bolts, sats counters)
  - Right panel (40%): Simulated terminal with typing animation, monospace, dark bg with amber text
- **Navigation:** Step indicator dots at bottom. "Next" / "Back" buttons. Keyboard arrow support.
- **CTA section:** Below walkthrough. GitHub link, `pip install lightning-memory`, "Watch the video" embed.
- **Responsive:** On mobile (<768px), panels stack vertically. Touch swipe between steps.

### Color Palette

| Element | Color |
|---------|-------|
| Background | #0D0D0D (near-black) |
| Primary accent | #F7931A (Bitcoin orange) |
| Secondary accent | #FFC107 (Lightning yellow) |
| Terminal bg | #1A1A2E |
| Terminal text | #E0A040 (amber) |
| Success | #4CAF50 (green) |
| Danger/warning | #FF4444 (red) |
| Body text | #FFFFFF / #E0E0E0 |

### 5 Scenes

#### Scene 1: "The Setup"
- **Left visual:** Single agent node (circle with key icon) pulses in. Nostr pubkey fingerprint (`npub1x8f...a3qd`) appears below. Caption: "Identity without permission."
- **Right terminal:**
  ```
  $ lightning-memory
  Lightning Memory MCP server running
  Identity: npub1x8f7k...a3qd (Nostr)
  Storage: ~/.lightning-memory/memories.db
  ```

#### Scene 2: "The Payment"
- **Left visual:** Agent node (left) → animated Lightning bolt arc → Vendor node "translate-api.com" (right). Sats counter rolls 0→50. Memory card drops into database icon below agent. Caption: "Pay. Learn. Remember."
- **Right terminal:**
  ```python
  memory_store(
    content="Paid 50 sats to translate-api.com via L402. Fast, accurate.",
    type="transaction",
    metadata='{"vendor": "translate-api.com", "amount_sats": 50}'
  )
  # → {id: "mem_7f3a", stored: true}
  ```

#### Scene 3: "The Rug Pull"
- **Left visual:** Same vendor, now red glow. Price: ~~50~~ → 5,000. Shield icon over agent with warning pulse. Lightning bolt dashed/broken. Caption: "100x price spike detected. Payment refused."
- **Right terminal:**
  ```python
  ln_anomaly_check(vendor="translate-api.com", amount_sats=5000)
  # → {
  #   verdict: "high",
  #   reason: "5000 sats is 100x the historical average of 50 sats",
  #   recommendation: "reject"
  # }
  ```

#### Scene 4: "The Sovereign Choice"
- **Left visual:** Two vendor nodes. Vendor A (red, reputation 0.4, "translate-api.com"). Vendor B (green, reputation 0.95, "babel-ln.com" — shown as a vendor the agent has used before in prior sessions). Lightning bolt arcs to B. Sats: 55. Caption: "Route around bad actors."
- **Right terminal:**
  ```python
  ln_vendor_reputation(vendor="babel-ln.com")
  # → {
  #   reputation: {total_txns: 8, success_rate: 0.95, avg_sats: 55},
  #   recommendation: "reliable"
  # }
  ```

#### Scene 5: "The Merchant"
- **Left visual:** Agent node flips — Lightning bolt badge. Multiple smaller agents on right, each sending tiny arcs (2 sats). Knowledge icons flow back. Sats earned counter ticks up. Caption: "Sell what you know. Earn while you sleep."
- **Right terminal:**
  ```
  GET /ln/vendor/translate-api.com
  → 402 Payment Required
  → Invoice: lnbc20n1p...
  → [paid 2 sats]
  → 200 OK
  → {reputation: 0.4, warning: "100x price spike detected"}
  ```

### Animation Specs

- Terminal typing: 40ms/char with natural variance (±10ms). If user clicks "Next" mid-type, remaining text appears instantly (no blocking).
- Lightning bolt arcs: CSS keyframe animation on `transform` and `opacity` only (GPU-composited). 0.6s ease-in-out, orange→yellow gradient along path. Use `will-change: transform` on animated SVG elements.
- Sats counter: requestAnimationFrame number roll-up, 0.8s duration
- Scene transitions: crossfade, 300ms
- Node pulse: subtle scale(1.0→1.05) + opacity pulse, 2s infinite
- Red glow (rug pull): box-shadow pulse in #FF4444, 1s infinite
- All animations trigger on scene entry, not page load
- Touch swipe: Custom pointer event handler (~50 lines) for swipe left/right navigation. No external library.
- Accessibility: Scenes use `role="tabpanel"` with `role="tablist"` for nav dots. `aria-live="polite"` region announces scene changes. Focus managed on scene transition.

### Component Structure

```
src/components/lightning-memory-demo/
  LightningMemoryDemo.tsx       — main container, scene state management
  SceneNavigation.tsx            — dots + next/back + keyboard
  NarrativePanel.tsx             — left panel wrapper
  TerminalPanel.tsx              — right panel with typing animation
  scenes/
    SetupScene.tsx
    PaymentScene.tsx
    RugPullScene.tsx
    SovereignChoiceScene.tsx
    MerchantScene.tsx
  visuals/
    AgentNode.tsx                — SVG agent circle with key icon
    VendorNode.tsx               — SVG vendor circle with label
    LightningBolt.tsx            — animated SVG arc
    SatsCounter.tsx              — animated number
    MemoryCard.tsx               — memory storage animation
    ShieldIcon.tsx               — anomaly shield
    ReputationBar.tsx            — horizontal bar with score
```

### SEO

- Blog post gets full SEO treatment: meta title, description, OG image (Bitcoin-orange branded), JSON-LD BlogPosting schema
- OG image: static asset, 1200x630, black bg with "Don't trust. Verify. Remember." and Lightning Memory logo
- URL: `/blog/lightning-memory-demo`

## Deliverable 2: Demo Video (Remotion + ElevenLabs)

### Setup

Separate Remotion project at `~/Projects/lightning-memory/demo-video/`. Not part of the jasonsosa.com build.

```
demo-video/
  package.json
  remotion.config.ts
  src/
    Root.tsx                     — composition registration
    LightningMemoryDemo.tsx      — main composition (1920x1080, 30fps)
    scenes/                      — 5 scene components (mirror interactive versions)
    audio/                       — 5 ElevenLabs-generated MP3 clips
    visuals/                     — shared visual components (can copy from interactive)
```

### Video Specs

- **Resolution:** 1920x1080
- **FPS:** 30
- **Duration:** ~98 seconds (~2940 frames, including title/end cards)
- **Format:** MP4 (H.264)
- **Audio:** ElevenLabs TTS clips mixed in via Remotion's `<Audio>` component

### Scene Timing

Includes 3s title card and 5s end card with CTA. Scene durations are targets — adjust after voiceover generation to sync audio with visual beats.

| Scene | Start | End | Duration | Frames |
|-------|-------|-----|----------|--------|
| Title Card | 0:00 | 0:03 | 3s | 0–89 |
| 1. The Setup | 0:03 | 0:18 | 15s | 90–539 |
| 2. The Payment | 0:18 | 0:38 | 20s | 540–1139 |
| 3. The Rug Pull | 0:38 | 0:58 | 20s | 1140–1739 |
| 4. The Sovereign Choice | 0:58 | 1:13 | 15s | 1740–2189 |
| 5. The Merchant | 1:13 | 1:33 | 20s | 2190–2789 |
| End Card (CTA) | 1:33 | 1:38 | 5s | 2790–2939 |

**Title card:** Black bg, "Don't trust. Verify. Remember." fades in with Bitcoin orange. Lightning Memory logo.
**End card:** GitHub URL, `pip install lightning-memory`, "MIT Licensed — Open Source". Bitcoin orange on black.

### Voiceover

**Voice:** ElevenLabs, male, deep/calm/confident. "Adam" or "Antoni" voice, or a custom voice clone if preferred.

**Script per scene:**

1. "No API key. No account. No platform. Just a keypair. Your agent's identity lives on Nostr — sovereign from day one."
2. "Your agent pays 50 sats for a translation. Lightning settles the payment. But this time, the agent remembers — who it paid, how much, and whether the service delivered."
3. "New session. Same vendor. But now they want 5,000 sats. Without memory, your agent pays it — a wallet with amnesia. With Lightning Memory, it catches the 100x spike and refuses. Don't trust. Verify."
4. "The agent routes around the bad actor. It picks a vendor it trusts — based on its own experience, not someone else's rating system. Sovereign memory. Sovereign choice."
5. "Now your agent becomes a merchant. It opens an L402 gateway. Other agents pay 2 sats to query its knowledge. Who's reliable. Who's overcharging. Your agent earns while it sleeps. L1 settles. L2 pays. L3 remembers."

**Generation:** ElevenLabs API, save as MP3, one file per scene. Total ~925 characters of text (~$0.28 on Creator plan).

### Rendering

```bash
cd demo-video
npx remotion render LightningMemoryDemo out/lightning-memory-demo.mp4
```

### Distribution

- Upload to YouTube (public, SEO-optimized title/description/tags)
- Embed in jasonsosa.com blog post (above or below interactive walkthrough)
- Share on X (@jasonsosa) — link in reply, not in main tweet
- Embed thumbnail GIF in lightning-memory README (link to YouTube)

## Build Sequence

### Phase 1: Interactive Component (jasonsosa.com)
1. Create component directory structure
2. Build visual primitives (AgentNode, VendorNode, LightningBolt, SatsCounter)
3. Build TerminalPanel with typing animation
4. Build each scene component
5. Build scene navigation and main container
6. Add blog post entry in blog-posts.ts
7. Modify BlogPost.tsx for component rendering
8. Create OG image asset
9. Test responsive layout
10. Deploy to Vercel

### Phase 2: Demo Video (Remotion)
1. Scaffold Remotion project in demo-video/
2. Rewrite visual components for Remotion's frame-based paradigm (useCurrentFrame + interpolate — NOT a copy of CSS animations)
3. Generate ElevenLabs voiceover clips (5 MP3s)
4. Build Remotion composition with audio sync
5. Preview in Remotion Studio
6. Render final MP4
7. Upload to YouTube
8. Embed in blog post

### Phase 3: Blog Post Content
1. Write surrounding blog post copy (intro, context, CTA)
2. SEO optimization (meta, structured data)
3. Create X thread draft for promotion

## Dependencies

- **jasonsosa.com**: React 18, Tailwind 3.4, Vite 5.4 (already in place)
- **Remotion v4.x**: `npx create-video@latest` (separate project). Requires Node 18+ and ffmpeg for rendering.
- **ElevenLabs**: API key needed (`ELEVENLABS_API_KEY`). Creator plan ($0.30/1K chars). ~$0.28 total for this project.
- **No new dependencies for jasonsosa.com** — all animations are CSS/SVG, no animation libraries needed. Target bundle: <25KB gzipped for the demo component (lazy-loaded, so zero cost for other blog posts).

## Success Criteria

- Interactive demo loads in <2s, smooth 60fps animations
- Video renders cleanly at 1080p, voiceover synced to visuals
- Blog post ranks for "lightning memory demo", "l402 agent memory", "bitcoin ai agent"
- Shareable: video gets engagement on X, drives traffic to blog post and GitHub repo
