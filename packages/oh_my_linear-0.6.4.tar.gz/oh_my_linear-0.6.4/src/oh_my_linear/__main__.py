"""Entry point for running oh-my-linear as a module."""

from .cli import main

if __name__ == "__main__":
    main()
