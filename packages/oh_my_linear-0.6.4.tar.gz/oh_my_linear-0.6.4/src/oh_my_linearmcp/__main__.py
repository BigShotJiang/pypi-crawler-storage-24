"""Entry point for running oh_my_linearmcp as a module."""

from oh_my_linear import main

if __name__ == "__main__":
    main()
