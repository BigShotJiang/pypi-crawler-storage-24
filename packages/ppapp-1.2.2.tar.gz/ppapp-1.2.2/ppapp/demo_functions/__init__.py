"""
Demo functions for ppapp.

These modules demonstrate how to define target functions for the
piecewise Chebyshev approximation generator. Each module defines:

- my_arb_f(X: arb, prec: int) -> arb: The function to approximate
- my_domain: Tuple[float, float]: The domain [a, b)
- my_testcases: List of (x, f_expected, tolerance) tuples

Available demo functions:
- imwofx: Im w(x) = exp(-x^2) * erfi(x)
- erfcx: erfcx(x) = exp(x^2) * erfc(x)
- polynomial: f(x) = x^3 - x^2 + x - 1
- voigt_hwhm: Voigt half-width at half-maximum
"""

from ppapp.demo_functions import erfcx, imwofx, polynomial, voigt_hwhm

__all__ = ["imwofx", "erfcx", "polynomial", "voigt_hwhm"]
