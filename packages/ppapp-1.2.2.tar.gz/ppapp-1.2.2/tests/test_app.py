#!/usr/bin/env python3

"""
Unit tests for the piecewise Chebyshev approximation generator.

Reference: Joachim Wuttke and Alexander Kleinsorge,
           Algorithm 1XXX: Code generation for piecewise Chebyshev approximation

File:      tests/test_app.py

License:   GNU General Public License, version 3 or higher (see LICENSE)
Copyright: Forschungszentrum Jülich GmbH 2025
"""

import unittest

from ppapp.cheb_coeffs import (
    cheb_cn,
    cheb_pm,
    precompute_Tnm,
    ref_f,
    set_reference_function,
    sizeT,
)

# Import modules to test
from ppapp.ppapp import (
    Subdomain,
    analyse_row,
    compute_subdomains,
    error_bound,
    hexfloat,
    n_output_coeffs,
)


class TestSizeT(unittest.TestCase):
    """Tests for the sizeT function that computes OEIS A002620."""

    def test_known_values(self):
        """Test against known OEIS A002620 values."""
        # N = -2,-1,0,1,2,3,4,5,6,7,...
        # result = 0,0,1,2,4,6,9,12,16,20,...
        expected = [(0, 1), (1, 2), (2, 4), (3, 6), (4, 9), (5, 12), (6, 16), (7, 20)]
        for n, exp in expected:
            with self.subTest(n=n):
                self.assertEqual(sizeT(n), exp)


class TestPrecomputeTnm(unittest.TestCase):
    """Tests for the Chebyshev polynomial coefficient computation."""

    def test_first_coefficients(self):
        """Test first few T_nm coefficients against OEIS A008310."""
        # Expected: 1,1,-1,2,-3,4,1,-8,8,5,-20,16,...
        tnm = precompute_Tnm(6)
        expected_start = [1, 1, -1, 2, -3, 4, 1, -8, 8, 5, -20, 16]
        self.assertEqual(tnm[:len(expected_start)], expected_start)

    def test_size(self):
        """Test that result has correct size."""
        for N in range(0, 10):
            tnm = precompute_Tnm(N)
            self.assertEqual(len(tnm), sizeT(N))

    def test_last_coefficient(self):
        """Test that T_nn = 2^{n-1} for n >= 1."""
        for N in range(1, 12):
            tnm = precompute_Tnm(N)
            expected_last = 1 << (N - 1)  # 2^{N-1}
            self.assertEqual(tnm[-1], expected_last)


class TestAnalyseRow(unittest.TestCase):
    """Tests for the power law analysis function."""

    def test_simple_power_law(self):
        """Test with a simple geometric sequence."""
        # y[n] = 2 * 0.5^n = [2, 1, 0.5, 0.25, ...]
        coeffs = [2.0 * (0.5 ** n) for n in range(10)]
        s, r = analyse_row(coeffs)
        # Should get s=2, r=0.5
        self.assertAlmostEqual(s, 2.0, places=10)
        self.assertAlmostEqual(r, 0.5, places=10)

    def test_returns_bounding_power_law(self):
        """Test that returned power law bounds all coefficients."""
        coeffs = [1.0, 0.5, 0.3, 0.1, 0.08, 0.03, 0.01]
        s, r = analyse_row(coeffs)
        # Check that s*r^n >= |coeffs[n]| for all n
        for n in range(len(coeffs)):
            bound = s * (r ** n)
            self.assertGreaterEqual(bound * 1.01, abs(coeffs[n]))  # 1% tolerance


class TestErrorBound(unittest.TestCase):
    """Tests for the error bound computation."""

    def test_positive_error_bound(self):
        """Test that error bound is positive for valid input."""
        d = Subdomain(0, 0, 0.5, 0.515625)
        d.coeffs = [0.5, 0.01, 0.0001, 1e-6, 1e-8, 1e-10, 1e-12]
        d.s = 1.0
        d.r = 0.01
        N = 6
        err = error_bound(d, N)
        self.assertGreater(err, 0)


class TestComputeSubdomains(unittest.TestCase):
    """Tests for the subdomain computation."""

    def test_subdomain_count(self):
        """Test that correct number of subdomains is generated."""
        # For domain [0.5, 12) with M=5, expect 144 subdomains
        j0, l0, D = compute_subdomains(0.5, 12.0, 5)
        self.assertEqual(len(D), 144)

    def test_subdomain_coverage(self):
        """Test that subdomains cover the entire domain."""
        a, b = 0.5, 12.0
        j0, l0, D = compute_subdomains(a, b, 5)

        # First subdomain should start at a
        self.assertLessEqual(D[0].a, a)
        # Last subdomain should extend past b
        self.assertGreaterEqual(D[-1].b, b)

        # Check contiguity
        for i in range(len(D) - 1):
            # End of subdomain i should match or exceed start of i+1
            self.assertLessEqual(D[i].b, D[i + 1].b)

    def test_subdomain_boundaries(self):
        """Test first subdomain boundaries for M=5."""
        j0, l0, D = compute_subdomains(0.5, 12.0, 5)
        self.assertAlmostEqual(D[0].a, 0.5)
        self.assertAlmostEqual(D[0].b, 0.515625)


class TestHexfloat(unittest.TestCase):
    """Tests for hexadecimal floating point formatting."""

    def test_positive_number(self):
        """Test formatting of positive number."""
        result = hexfloat(1.5)
        self.assertEqual(result, "0x1.8000000000000p+0")

    def test_negative_number(self):
        """Test formatting of negative number."""
        result = hexfloat(-1.5)
        self.assertEqual(result, "-0x1.8000000000000p+0")

    def test_zero(self):
        """Test formatting of zero."""
        result = hexfloat(0.0)
        self.assertEqual(result, "0x0.0p+0")


class TestNOutputCoeffs(unittest.TestCase):
    """Tests for the alignment padding computation."""

    def test_alignment_values(self):
        """Test alignment computation for various N values."""
        # From the paper/code:
        # N+1 mod 8 == 0,1,2,4: no padding
        # N+1 mod 8 == 3: pad to 4
        # Otherwise: pad to 8
        test_cases = [
            (5, 8),   # N+1=6, 6%8=6, pad to 8
            (6, 8),   # N+1=7, 7%8=7, pad to 8
            (7, 8),   # N+1=8, 8%8=0, no padding
            (8, 9),   # N+1=9, 9%8=1, no padding
            (9, 10),  # N+1=10, 10%8=2, no padding
            (10, 12), # N+1=11, 11%8=3, pad to 12
            (11, 12), # N+1=12, 12%8=4, no padding
        ]
        for N, expected in test_cases:
            with self.subTest(N=N):
                self.assertEqual(n_output_coeffs(N), expected)


class TestFunctionModules(unittest.TestCase):
    """Tests for the function modules (f_imwofx, f_erfcx)."""

    def test_imwofx_basic(self):
        """Test Im w(x) function for basic values."""
        from ppapp.demo_functions.imwofx import my_arb_f, my_domain, my_testcases
        set_reference_function(my_arb_f)

        # Test domain
        self.assertEqual(my_domain, (0.5, 12.0))

        # Test against expected values
        for x, f_expected, tol in my_testcases:
            f_computed = ref_f(x)
            rel_error = abs(f_computed - f_expected) / f_expected
            self.assertLess(rel_error, tol)

    def test_erfcx_basic(self):
        """Test erfcx function for basic values."""
        from ppapp.demo_functions.erfcx import my_arb_f, my_domain, my_testcases
        set_reference_function(my_arb_f)

        # Test domain
        self.assertEqual(my_domain, (0.125, 12.0))

        # Test against expected values
        for x, f_expected, tol in my_testcases:
            f_computed = ref_f(x)
            rel_error = abs(f_computed - f_expected) / f_expected
            self.assertLess(rel_error, tol)

    def test_polynomial_basic(self):
        """Test polynomial f(x) = x^3 - x^2 + x - 1 for basic values."""
        from ppapp.demo_functions.polynomial import my_arb_f, my_domain, my_testcases
        set_reference_function(my_arb_f)

        # Test domain
        self.assertEqual(my_domain, (1.5, 4.0))

        # Test against expected values
        for x, f_expected, tol in my_testcases:
            f_computed = ref_f(x)
            rel_error = abs(f_computed - f_expected) / abs(f_expected)
            self.assertLess(rel_error, tol)


class TestChebCoeffs(unittest.TestCase):
    """Tests for Chebyshev coefficient computation."""

    def setUp(self):
        """Set up reference function."""
        from ppapp.demo_functions.imwofx import my_arb_f
        set_reference_function(my_arb_f)

    def test_cheb_cn_returns_correct_count(self):
        """Test that cheb_cn returns N+1 coefficients."""
        for N in [5, 7, 10]:
            coeffs = cheb_cn(0.5, 0.515625, N)
            self.assertEqual(len(coeffs), N + 1)

    def test_cheb_pm_returns_correct_count(self):
        """Test that cheb_pm returns N+1 coefficients."""
        for N in [5, 7, 10]:
            coeffs = cheb_pm(0.5, 0.515625, N)
            self.assertEqual(len(coeffs), N + 1)

    def test_first_coeff_approximates_function_value(self):
        """Test that p_0 is close to the function value at the midpoint."""
        a, b = 0.5, 0.515625
        coeffs = cheb_pm(a, b, 10)
        mid = (a + b) / 2
        f_mid = ref_f(mid)
        # p_0 should be close to f(midpoint)
        self.assertAlmostEqual(coeffs[0], f_mid, places=2)


class TestPolynomialApproximation(unittest.TestCase):
    """Tests using f_polynomial to verify exact polynomial approximation."""

    def setUp(self):
        """Set up reference function to polynomial."""
        from ppapp.demo_functions.polynomial import my_arb_f
        set_reference_function(my_arb_f)

    def test_higher_coeffs_negligible(self):
        """For degree-3 polynomial, coefficients p_4 onwards should be negligible."""
        # Use a subdomain within f_polynomial's domain
        a, b = 2.0, 2.0625
        N = 10
        coeffs = cheb_pm(a, b, N)

        # First 4 coefficients (p_0 to p_3) should be significant
        for i in range(4):
            self.assertGreater(abs(coeffs[i]), 1e-10,
                f"Coefficient p_{i} should be significant")

        # Coefficients p_4 onwards should be negligible (numerical noise)
        p0 = abs(coeffs[0])
        for i in range(4, N + 1):
            self.assertLess(abs(coeffs[i]), p0 * 1e-10,
                f"Coefficient p_{i} should be negligible")

    def test_approximation_exact(self):
        """Chebyshev approximation of degree-3 polynomial should be exact."""
        a, b = 2.0, 2.0625
        N = 10
        coeffs = cheb_pm(a, b, N)

        # Test at several points in the subdomain
        test_points = [a, (a + b) / 2, b, a + 0.25 * (b - a), a + 0.75 * (b - a)]
        for x in test_points:
            # Evaluate polynomial using Horner's method
            t = (x - (a + b) / 2) / ((b - a) / 2)
            f_approx = coeffs[-1]
            for m in range(len(coeffs) - 2, -1, -1):
                f_approx *= t
                f_approx += coeffs[m]

            f_exact = ref_f(x)
            rel_error = abs(f_approx - f_exact) / abs(f_exact)
            # Should be exact within machine precision
            self.assertLess(rel_error, 1e-14,
                f"Approximation at x={x} should be exact")

    def test_chebyshev_coeffs_decay(self):
        """Chebyshev coefficients c_n for degree-3 polynomial should be zero for n>3."""
        a, b = 2.0, 2.0625
        N = 10
        coeffs = cheb_cn(a, b, N)

        # c_0 to c_3 should be significant
        for i in range(4):
            self.assertGreater(abs(coeffs[i]), 1e-10,
                f"Chebyshev coefficient c_{i} should be significant")

        # c_4 onwards should be essentially zero (numerical noise)
        c0 = abs(coeffs[0])
        for i in range(4, N + 1):
            self.assertLess(abs(coeffs[i]), c0 * 1e-10,
                f"Chebyshev coefficient c_{i} should be negligible")

    def test_polynomial_coefficients_correct(self):
        """Verify the actual polynomial coefficients match x^3 - x^2 + x - 1."""
        # For f(x) = x^3 - x^2 + x - 1 on a small interval, we can verify
        # the monomial coefficients p_m relate correctly to the original polynomial.
        # With transformation t = (x - mid) / halfrange, we get transformed coefficients.
        a, b = 2.0, 2.0625
        mid = (a + b) / 2
        N = 5
        coeffs = cheb_pm(a, b, N)

        # Verify by evaluating at x = mid (t = 0), should give p_0
        f_mid = ref_f(mid)
        self.assertAlmostEqual(coeffs[0], f_mid, places=12)

        # Verify by evaluating at x = b (t = 1), should give sum of all coeffs
        f_b = ref_f(b)
        f_approx = sum(coeffs[:4])  # Only first 4 matter
        self.assertAlmostEqual(f_approx, f_b, places=12)


class TestIntegration(unittest.TestCase):
    """Integration tests combining multiple components."""

    def setUp(self):
        """Set up reference function."""
        from ppapp.demo_functions.imwofx import my_arb_f
        set_reference_function(my_arb_f)

    def test_full_pipeline(self):
        """Test the full pipeline: compute subdomains, coefficients, and error bound."""
        a, b = 0.5, 12.0
        M = 5
        N = 10

        j0, l0, D = compute_subdomains(a, b, M)

        # Process first few subdomains
        max_err = 0.0
        for d in D[:5]:
            d.coeffs = cheb_pm(d.a, d.b, N)
            s, r = analyse_row(d.coeffs)
            d.s = s
            d.r = r
            err = error_bound(d, N)
            max_err = max(max_err, err)

        # Error should be reasonable (less than 10 epsilon for M=5, N=10)
        self.assertLess(max_err, 10.0)


if __name__ == "__main__":
    unittest.main()
