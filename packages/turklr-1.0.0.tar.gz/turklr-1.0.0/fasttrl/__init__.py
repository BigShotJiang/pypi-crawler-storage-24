"""
FastTRL - Yüksek Performanslı Transformer Reinforcement Learning Kütüphanesi
============================================================================
TRL'nin tamamen yeniden yazılmış, daha hızlı ve güvenilir versiyonu.

Desteklenen eğitim yöntemleri:
  - SFTTrainer   : Supervised Fine-Tuning
  - PPOTrainer   : Proximal Policy Optimization
  - DPOTrainer   : Direct Preference Optimization
  - RewardTrainer: Ödül modeli eğitimi
  - GRPOTrainer  : Group Relative Policy Optimization
"""

from fasttrl.trainers.sft import SFTTrainer
from fasttrl.trainers.ppo import PPOTrainer
from fasttrl.trainers.dpo import DPOTrainer
from fasttrl.trainers.reward import RewardTrainer
from fasttrl.trainers.grpo import GRPOTrainer
from fasttrl.config import (
    SFTConfig,
    PPOConfig,
    DPOConfig,
    RewardConfig,
    GRPOConfig,
)
from fasttrl.data import (
    DataCollatorForLanguageModeling,
    DataCollatorForPreferenceOptimization,
    apply_chat_template,
    pack_sequences,
)
from fasttrl.models import (
    AutoModelForCausalLMWithValueHead,
    create_reference_model,
)
from fasttrl.utils import (
    set_seed,
    get_kl_penalty,
    masked_mean,
    masked_whiten,
    clip_by_value,
    entropy_from_logits,
    logprobs_from_logits,
    flatten_dict,
    compute_accuracy,
    print_trainable_parameters,
)

__version__ = "1.0.0"
__author__ = "FastTRL"

__all__ = [
    # Trainers
    "SFTTrainer",
    "PPOTrainer",
    "DPOTrainer",
    "RewardTrainer",
    "GRPOTrainer",
    # Configs
    "SFTConfig",
    "PPOConfig",
    "DPOConfig",
    "RewardConfig",
    "GRPOConfig",
    # Data
    "DataCollatorForLanguageModeling",
    "DataCollatorForPreferenceOptimization",
    "apply_chat_template",
    "pack_sequences",
    # Models
    "AutoModelForCausalLMWithValueHead",
    "create_reference_model",
    # Utils
    "set_seed",
    "get_kl_penalty",
    "masked_mean",
    "masked_whiten",
    "clip_by_value",
    "entropy_from_logits",
    "logprobs_from_logits",
    "flatten_dict",
    "compute_accuracy",
    "print_trainable_parameters",
]
