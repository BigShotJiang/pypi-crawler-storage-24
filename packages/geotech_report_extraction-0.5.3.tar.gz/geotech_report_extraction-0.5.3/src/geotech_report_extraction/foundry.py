"""Palantir Foundry transform for boring log identification and extraction.

This module provides Foundry-compatible functions that process Azure Document
Intelligence (DI) JSON exports and produce structured boring log datasets.

Designed to work with a Pipeline Builder preprocessing step that flattens
DI JSON files into a per-page tabular dataset. The transform then applies
the XGBoost classifier and boring log parsers to identify and extract data.

Architecture:
    1. Pipeline Builder: DI JSON files → flat per-page dataset
       (columns: source_file, page_number, page_text, page_width, page_height,
        word_count, has_tables)
    2. This transform: per-page dataset → boring log inventory dataset
       Uses groupBy("source_file").applyInPandas() for per-report processing.

Usage in Foundry Code Repository:
    from geotech_report_extraction.foundry import (
        identify_boring_logs,
        extract_boring_log_data,
    )
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from datetime import date
from typing import Optional

import pandas as pd

from geotech_report_extraction.confidence import score_borehole, score_sample
from geotech_report_extraction.di_reader import _detect_firm, _extract_boring_id
from geotech_report_extraction.ml_classifier import classify_page
from geotech_report_extraction.ml_features import FEATURE_NAMES, extract_features
from geotech_report_extraction.models import Borehole
from geotech_report_extraction.parsers.registry import get_di_parser
from geotech_report_extraction.pdf_parser import (
    PageContent,
    PDFContent,
    group_boring_log_pages,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schema definitions for Foundry output datasets
# ---------------------------------------------------------------------------

# Schema for the boring log inventory (Stage 2 output)
INVENTORY_COLUMNS = [
    "report_id",         # str: hash of source_file (FK to GeotechReport)
    "source_file",       # str: DI JSON filename
    "boring_id",         # str: boring designation (e.g., B-01, LB-1)
    "firm",              # str: engineering firm (schnabel, langan)
    "start_page",        # int: first PDF page of this boring log
    "end_page",          # int: last PDF page of this boring log
    "num_pages",         # int: total pages for this boring
    "avg_confidence",    # float: mean ML confidence across pages
    "min_confidence",    # float: lowest ML confidence across pages
]

# Schema for full extraction (Stage 3 output)
EXTRACTION_COLUMNS = [
    "report_id",         # str: hash of source_file (FK to GeotechReport)
    "source_file",       # str: DI JSON filename
    "boring_id",         # str: boring designation
    "firm",              # str: engineering firm
    "start_page",        # int: first PDF page
    "end_page",          # int: last PDF page
    "num_pages",         # int: total pages
    "avg_confidence",    # float: mean ML confidence
    "min_confidence",    # float: lowest ML confidence
    "total_depth_ft",    # float: total boring depth in feet
    "elevation_ft",      # float: ground surface elevation
    "date_started",      # str: date drilling started (ISO format or None)
    "date_completed",    # str: date drilling completed (ISO format or None)
    "num_samples",       # int: number of samples extracted
    "num_soil_layers",   # int: number of soil layers identified
    "num_water_levels",  # int: number of water level observations
    "project_name",      # str: project name from report header
    "project_number",    # str: project number
    "project_location",  # str: project location
    "extraction_warnings",  # str: semicolon-separated warnings
    "extraction_confidence",  # float: overall borehole confidence score (0.0-1.0)
    "confidence_level",       # str: HIGH/MEDIUM/LOW/FLAGGED
    "confidence_checks",      # str: semicolon-separated confidence checks
]

# Schema for flattened samples (Stage 3b output)
SAMPLE_COLUMNS = [
    "report_id",         # str: hash of source_file (ontology PK fragment)
    "source_file",       # str: DI JSON filename
    "boring_id",         # str: boring designation
    "sample_number",     # str: sample designation (S-1, etc.)
    "sample_type",       # str: split_spoon, shelby_tube, etc.
    "depth_top_ft",      # float: top of sample interval
    "depth_bottom_ft",   # float: bottom of sample interval
    "recovery_in",       # float: recovery in inches
    "recovery_pct",      # float: recovery percentage
    "spt_first_6in",     # int: SPT blow count 1st 6in
    "spt_second_6in",    # int: SPT blow count 2nd 6in
    "spt_third_6in",     # int: SPT blow count 3rd 6in
    "spt_n_value",       # int: SPT N-value
    "spt_refusal",       # bool: SPT refusal flag
    "water_content_pct", # float: water content
    "dry_unit_weight_pcf",  # float: dry unit weight
    "liquid_limit",      # int: Atterberg LL
    "plastic_limit",     # int: Atterberg PL
    "plasticity_index",  # int: Atterberg PI
    "fines_pct",         # float: percent fines
    "qu_psf",            # float: unconfined compressive strength
]

# Schema for flattened soil layers (Stage 3b output)
SOIL_LAYER_COLUMNS = [
    "report_id",         # str: hash of source_file
    "source_file",       # str: DI JSON filename
    "boring_id",         # str: boring designation
    "depth_top_ft",      # float: top of layer
    "depth_bottom_ft",   # float: bottom of layer
    "description",       # str: soil/rock description
    "uscs_classification",  # str: USCS symbol
    "color",             # str: soil color
    "moisture",          # str: moisture condition
    "consistency",       # str: consistency (soft, stiff, etc.)
    "relative_density",  # str: relative density (loose, dense, etc.)
]

# Schema for flattened water levels (Stage 3b output)
WATER_LEVEL_COLUMNS = [
    "report_id",         # str: hash of source_file
    "source_file",       # str: DI JSON filename
    "boring_id",         # str: boring designation
    "depth_ft",          # float: depth to water
    "date_observed",     # str: ISO date or None
    "is_during_drilling",  # bool
    "is_stabilized",     # bool
    "notes",             # str: observation notes
]


# Schema for per-page classification (Stage 2b output — GeotechReportPage ontology)
PAGE_COLUMNS = [
    "report_id",               # str: hash of source_file (FK to GeotechReport)
    "source_file",             # str: DI JSON filename
    "page_number",             # int: 1-based page number
    "is_boring_log",           # bool: XGBoost classifier result
    "classification_confidence",  # float: XGBoost confidence score (0.0-1.0)
    "boring_id",               # str: boring ID if this is a boring log page, else None
    "lab_test_type",           # str: detected lab test type (consolidation, grain_size, etc.) or None
    "word_count",              # int: number of words on this page
    "has_tables",              # bool: whether DI detected tables
]


def _report_id(source_file: str) -> str:
    """Generate a deterministic report ID from the source filename."""
    return hashlib.sha256(source_file.encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Page reconstruction from flattened Pipeline Builder data
# ---------------------------------------------------------------------------

def _reconstruct_page(row: pd.Series) -> PageContent:
    """Reconstruct a PageContent object from a flattened Pipeline Builder row.

    Expected columns: page_number, page_text, page_width, page_height,
                      word_count, has_tables, words_json (optional)
    """
    page_text = row.get("page_text") or ""

    # Deserialize word positions if available (v0.5.0+)
    words_json = row.get("words_json")
    if words_json:
        words = json.loads(words_json)
    else:
        # Backward compat: dummy words for pre-v0.5.0 flattened data
        words = [{"text": "w"}] * int(row.get("word_count", 0))

    pc = PageContent(
        page_number=int(row["page_number"]),
        text=page_text,
        words=words,
        lines=[],
        width=float(row.get("page_width", 612.0)) * 72.0,  # inches to points
        height=float(row.get("page_height", 792.0)) * 72.0,
    )

    # Tag DI table detection
    pc._di_has_tables = bool(row.get("has_tables", False))

    return pc


def _classify_and_tag_pages(
    pages: list[PageContent],
) -> list[PageContent]:
    """Run the ML classifier on each page and set boring IDs."""
    for pc in pages:
        pc.is_boring_log, pc.classification_score = classify_page(pc)
        if pc.is_boring_log:
            pc.boring_id = _extract_boring_id(pc.text)
    return pages


def _is_test_pit_group(boring_id: str, group_pages: list[PageContent]) -> bool:
    """Check if a boring log group is actually a test pit.

    Matches by boring ID pattern (TP-X, LTP-X) or by page title
    (LOG OF TEST PIT, TEST PIT LOG).
    """
    if re.match(r"(?i)^L?TP-?\d", boring_id):
        return True
    header = (group_pages[0].text or "")[:300]
    return bool(re.search(
        r"(?i)\bLOG\s+OF\s+TEST\s+PIT\b|\bTEST\s+PIT\s+LOG\b", header
    ))


# ---------------------------------------------------------------------------
# Core processing functions (used by both Foundry transforms and standalone)
# ---------------------------------------------------------------------------

def process_report_inventory(pdf: pd.DataFrame) -> pd.DataFrame:
    """Process all pages from a single report into a boring log inventory.

    This is the applyInPandas function for the inventory transform.

    Args:
        pdf: Pandas DataFrame with all pages from one report.
             Expected columns: source_file, page_number, page_text,
             page_width, page_height, word_count, has_tables

    Returns:
        DataFrame with one row per boring log group (INVENTORY_COLUMNS).
    """
    if pdf.empty:
        return pd.DataFrame(columns=INVENTORY_COLUMNS)

    source_file = pdf["source_file"].iloc[0]
    report_id = _report_id(source_file)

    # Reconstruct PageContent objects
    pages = []
    for _, row in pdf.sort_values("page_number").iterrows():
        pages.append(_reconstruct_page(row))

    # Classify pages
    _classify_and_tag_pages(pages)

    # Build PDFContent and detect firm
    pdf_content = PDFContent(file_path=source_file)
    pdf_content.pages = pages
    pdf_content.total_pages = len(pages)

    for p in pages[:5]:
        firm = _detect_firm(p.text)
        if firm:
            pdf_content.detected_firm = firm
            break
    if pdf_content.detected_firm is None:
        for p in pdf_content.boring_log_pages[:3]:
            firm = _detect_firm(p.text)
            if firm:
                pdf_content.detected_firm = firm
                break

    # Group boring log pages
    groups = group_boring_log_pages(pdf_content)

    # Build output rows
    results = []
    for boring_id, group_pages in groups.items():
        if _is_test_pit_group(boring_id, group_pages):
            continue
        results.append({
            "report_id": report_id,
            "source_file": source_file,
            "boring_id": boring_id,
            "firm": pdf_content.detected_firm or "unknown",
            "start_page": group_pages[0].page_number,
            "end_page": group_pages[-1].page_number,
            "num_pages": len(group_pages),
            "avg_confidence": (
                sum(p.classification_score for p in group_pages)
                / len(group_pages)
            ),
            "min_confidence": min(
                p.classification_score for p in group_pages
            ),
        })

    if not results:
        return pd.DataFrame(columns=INVENTORY_COLUMNS)

    return pd.DataFrame(results, columns=INVENTORY_COLUMNS)


def process_report_extraction(pdf: pd.DataFrame) -> pd.DataFrame:
    """Process all pages from a single report with full data extraction.

    This is the applyInPandas function for the extraction transform.
    Runs the firm-specific parser on each boring group to extract
    samples, soil layers, water levels, etc.

    Args:
        pdf: Pandas DataFrame with all pages from one report.

    Returns:
        DataFrame with one row per boring (EXTRACTION_COLUMNS).
    """
    if pdf.empty:
        return pd.DataFrame(columns=EXTRACTION_COLUMNS)

    source_file = pdf["source_file"].iloc[0]
    report_id = _report_id(source_file)

    # Reconstruct and classify pages
    pages = []
    for _, row in pdf.sort_values("page_number").iterrows():
        pages.append(_reconstruct_page(row))

    _classify_and_tag_pages(pages)

    # Build PDFContent
    pdf_content = PDFContent(file_path=source_file)
    pdf_content.pages = pages
    pdf_content.total_pages = len(pages)

    for p in pages[:5]:
        firm = _detect_firm(p.text)
        if firm:
            pdf_content.detected_firm = firm
            break
    if pdf_content.detected_firm is None:
        for p in pdf_content.boring_log_pages[:3]:
            firm = _detect_firm(p.text)
            if firm:
                pdf_content.detected_firm = firm
                break

    # Report-level firm and project (used as fallback)
    report_firm = pdf_content.detected_firm
    report_parser = get_di_parser(report_firm)
    project = report_parser.parse_project_info(pdf_content)

    # Group and extract
    groups = group_boring_log_pages(pdf_content)
    all_warnings: list[str] = []
    results = []

    for boring_id, group_pages in groups.items():
        # Skip test pits
        if _is_test_pit_group(boring_id, group_pages):
            all_warnings.append(f"Skipped test pit {boring_id}")
            continue

        # Per-boring firm detection: check the group's pages to find
        # the right parser.  Reports often contain borings from multiple
        # firms (e.g. Langan design-build after Schnabel pre-bid).
        boring_firm = None
        for gp in group_pages[:2]:
            boring_firm = _detect_firm(gp.text)
            if boring_firm:
                break
        # Fall back to report-level firm
        if boring_firm is None:
            boring_firm = report_firm

        # Only extract with Schnabel/Langan parsers — other templates
        # (local firms, historic borings) would produce garbage data.
        if boring_firm not in ("schnabel", "langan"):
            all_warnings.append(
                f"Skipped {boring_id}: unsupported template "
                f"(firm={boring_firm or 'unknown'})"
            )
            continue

        parser = get_di_parser(boring_firm)

        avg_conf = sum(p.classification_score for p in group_pages) / len(group_pages)
        min_conf = min(p.classification_score for p in group_pages)

        row_data = {
            "report_id": report_id,
            "source_file": source_file,
            "boring_id": boring_id,
            "firm": boring_firm,
            "start_page": group_pages[0].page_number,
            "end_page": group_pages[-1].page_number,
            "num_pages": len(group_pages),
            "avg_confidence": avg_conf,
            "min_confidence": min_conf,
            "total_depth_ft": None,
            "elevation_ft": None,
            "date_started": None,
            "date_completed": None,
            "num_samples": 0,
            "num_soil_layers": 0,
            "num_water_levels": 0,
            "project_name": project.name,
            "project_number": project.number,
            "project_location": project.location,
            "extraction_warnings": "",
            "extraction_confidence": None,
            "confidence_level": None,
            "confidence_checks": None,
        }

        try:
            borehole: Borehole = parser.parse_boring_log(group_pages)

            row_data["total_depth_ft"] = borehole.depth_ft
            row_data["elevation_ft"] = borehole.elevation_ft
            row_data["date_started"] = (
                borehole.date_started.isoformat()
                if borehole.date_started else None
            )
            row_data["date_completed"] = (
                borehole.date_completed.isoformat()
                if borehole.date_completed else None
            )
            row_data["num_samples"] = len(borehole.samples)
            row_data["num_soil_layers"] = len(borehole.soil_layers)
            row_data["num_water_levels"] = len(borehole.water_levels)

            # Confidence scoring (Schnabel/Langan only — GenericParser
            # output is too sparse for meaningful scoring)
            firm = pdf_content.detected_firm
            if firm in ("schnabel", "langan"):
                for s in borehole.samples:
                    s.confidence = score_sample(s, borehole.depth_ft)
                bh_conf = score_borehole(borehole)
                row_data["extraction_confidence"] = bh_conf.score
                row_data["confidence_level"] = bh_conf.level.value
                row_data["confidence_checks"] = "; ".join(bh_conf.checks)

            if not borehole.samples:
                all_warnings.append(
                    f"{boring_id}: 0 samples extracted"
                )

        except Exception as e:
            all_warnings.append(f"{boring_id}: parse error: {e}")

        row_data["extraction_warnings"] = "; ".join(all_warnings)
        results.append(row_data)

    if not results:
        return pd.DataFrame(columns=EXTRACTION_COLUMNS)

    return pd.DataFrame(results, columns=EXTRACTION_COLUMNS)


# ---------------------------------------------------------------------------
# Stage 3b: Flatten samples, soil layers, water levels for ontology
# ---------------------------------------------------------------------------

def _parse_boreholes_from_pages(
    pdf: pd.DataFrame,
) -> list[tuple[str, str, str, Borehole]]:
    """Shared helper: reconstruct pages, classify, parse boreholes.

    Returns list of (source_file, report_id, firm, Borehole) tuples.
    """
    if pdf.empty:
        return []

    source_file = pdf["source_file"].iloc[0]
    rid = _report_id(source_file)

    pages = []
    for _, row in pdf.sort_values("page_number").iterrows():
        pages.append(_reconstruct_page(row))

    _classify_and_tag_pages(pages)

    pdf_content = PDFContent(file_path=source_file)
    pdf_content.pages = pages
    pdf_content.total_pages = len(pages)

    for p in pages[:5]:
        firm = _detect_firm(p.text)
        if firm:
            pdf_content.detected_firm = firm
            break
    if pdf_content.detected_firm is None:
        for p in pdf_content.boring_log_pages[:3]:
            firm = _detect_firm(p.text)
            if firm:
                pdf_content.detected_firm = firm
                break

    report_firm = pdf_content.detected_firm
    groups = group_boring_log_pages(pdf_content)

    results = []
    for boring_id, group_pages in groups.items():
        if _is_test_pit_group(boring_id, group_pages):
            continue

        # Per-boring firm detection
        boring_firm = None
        for gp in group_pages[:2]:
            boring_firm = _detect_firm(gp.text)
            if boring_firm:
                break
        if boring_firm is None:
            boring_firm = report_firm

        if boring_firm not in ("schnabel", "langan"):
            continue

        parser = get_di_parser(boring_firm)
        try:
            borehole = parser.parse_boring_log(group_pages)
            results.append((source_file, rid, boring_firm, borehole))
        except Exception as e:
            logger.warning("Failed to parse %s in %s: %s", boring_id,
                           source_file, e)
    return results


def process_report_samples(pdf: pd.DataFrame) -> pd.DataFrame:
    """Flatten all samples from a single report into one row per sample.

    This is the applyInPandas function for the samples_flat transform.
    """
    parsed = _parse_boreholes_from_pages(pdf)
    rows = []
    for source_file, rid, _firm, borehole in parsed:
        for sample in borehole.samples:
            rows.append({
                "report_id": rid,
                "source_file": source_file,
                "boring_id": borehole.boring_id,
                "sample_number": sample.sample_number,
                "sample_type": (sample.sample_type.value
                                if sample.sample_type else None),
                "depth_top_ft": sample.depth_top_ft,
                "depth_bottom_ft": sample.depth_bottom_ft,
                "recovery_in": sample.recovery_in,
                "recovery_pct": sample.recovery_pct,
                "spt_first_6in": (sample.spt.first_6in
                                  if sample.spt else None),
                "spt_second_6in": (sample.spt.second_6in
                                   if sample.spt else None),
                "spt_third_6in": (sample.spt.third_6in
                                  if sample.spt else None),
                "spt_n_value": (sample.spt.n_value
                                if sample.spt else None),
                "spt_refusal": (sample.spt.refusal
                                if sample.spt else None),
                "water_content_pct": sample.water_content_pct,
                "dry_unit_weight_pcf": sample.dry_unit_weight_pcf,
                "liquid_limit": sample.liquid_limit,
                "plastic_limit": sample.plastic_limit,
                "plasticity_index": sample.plasticity_index,
                "fines_pct": sample.fines_pct,
                "qu_psf": sample.qu_psf,
            })

    if not rows:
        return pd.DataFrame(columns=SAMPLE_COLUMNS)
    return pd.DataFrame(rows, columns=SAMPLE_COLUMNS)


def process_report_soil_layers(pdf: pd.DataFrame) -> pd.DataFrame:
    """Flatten all soil layers from a single report into one row per layer.

    This is the applyInPandas function for the soil_layers_flat transform.
    """
    parsed = _parse_boreholes_from_pages(pdf)
    rows = []
    for source_file, rid, _firm, borehole in parsed:
        for layer in borehole.soil_layers:
            rows.append({
                "report_id": rid,
                "source_file": source_file,
                "boring_id": borehole.boring_id,
                "depth_top_ft": layer.depth_top_ft,
                "depth_bottom_ft": layer.depth_bottom_ft,
                "description": layer.description,
                "uscs_classification": (layer.uscs_classification.value
                                        if layer.uscs_classification
                                        else None),
                "color": layer.color,
                "moisture": (layer.moisture.value
                             if layer.moisture else None),
                "consistency": (layer.consistency.value
                                if layer.consistency else None),
                "relative_density": (layer.relative_density.value
                                     if layer.relative_density else None),
            })

    if not rows:
        return pd.DataFrame(columns=SOIL_LAYER_COLUMNS)
    return pd.DataFrame(rows, columns=SOIL_LAYER_COLUMNS)


def process_report_water_levels(pdf: pd.DataFrame) -> pd.DataFrame:
    """Flatten all water levels from a single report into one row per observation.

    This is the applyInPandas function for the water_levels_flat transform.
    """
    parsed = _parse_boreholes_from_pages(pdf)
    rows = []
    for source_file, rid, _firm, borehole in parsed:
        for wl in borehole.water_levels:
            rows.append({
                "report_id": rid,
                "source_file": source_file,
                "boring_id": borehole.boring_id,
                "depth_ft": wl.depth_ft,
                "date_observed": (wl.date_observed.isoformat()
                                  if wl.date_observed else None),
                "is_during_drilling": wl.is_during_drilling,
                "is_stabilized": wl.is_stabilized,
                "notes": wl.notes,
            })

    if not rows:
        return pd.DataFrame(columns=WATER_LEVEL_COLUMNS)
    return pd.DataFrame(rows, columns=WATER_LEVEL_COLUMNS)


# ---------------------------------------------------------------------------
# Standalone entry point (for testing outside Foundry)
# ---------------------------------------------------------------------------

def process_di_json_to_inventory(
    di_json_path: str,
    file_label: Optional[str] = None,
) -> pd.DataFrame:
    """Process a single DI JSON file and return a boring log inventory DataFrame.

    This is a convenience function for local testing. In Foundry, the
    Pipeline Builder flattening step replaces this — the transform
    receives pre-flattened page data.

    Args:
        di_json_path: Path to the Azure DI JSON file.
        file_label: Optional label for the source file.

    Returns:
        Pandas DataFrame with INVENTORY_COLUMNS.
    """
    from geotech_report_extraction.di_reader import read_di_json

    pdf_content = read_di_json(di_json_path, file_label=file_label)
    label = file_label or di_json_path

    # Build a flat DataFrame matching Pipeline Builder output
    rows = []
    for page in pdf_content.pages:
        rows.append({
            "source_file": label,
            "page_number": page.page_number,
            "page_text": page.text,
            "page_width": page.width / 72.0,  # points back to inches
            "page_height": page.height / 72.0,
            "word_count": len(page.words),
            "has_tables": getattr(page, '_di_has_tables', False),
            "words_json": json.dumps(page.words),
        })

    pages_df = pd.DataFrame(rows)
    return process_report_inventory(pages_df)


def process_di_json_to_extraction(
    di_json_path: str,
    file_label: Optional[str] = None,
) -> pd.DataFrame:
    """Process a single DI JSON file and return full extraction DataFrame.

    Convenience function for local testing.
    """
    from geotech_report_extraction.di_reader import read_di_json

    pdf_content = read_di_json(di_json_path, file_label=file_label)
    label = file_label or di_json_path

    rows = []
    for page in pdf_content.pages:
        rows.append({
            "source_file": label,
            "page_number": page.page_number,
            "page_text": page.text,
            "page_width": page.width / 72.0,
            "page_height": page.height / 72.0,
            "word_count": len(page.words),
            "has_tables": getattr(page, '_di_has_tables', False),
            "words_json": json.dumps(page.words),
        })

    pages_df = pd.DataFrame(rows)
    return process_report_extraction(pages_df)


def _build_pages_df(di_json_path: str, file_label: Optional[str] = None) -> pd.DataFrame:
    """Build a flattened pages DataFrame from a DI JSON file (shared helper)."""
    from geotech_report_extraction.di_reader import read_di_json

    pdf_content = read_di_json(di_json_path, file_label=file_label)
    label = file_label or di_json_path

    rows = []
    for page in pdf_content.pages:
        rows.append({
            "source_file": label,
            "page_number": page.page_number,
            "page_text": page.text,
            "page_width": page.width / 72.0,
            "page_height": page.height / 72.0,
            "word_count": len(page.words),
            "has_tables": getattr(page, '_di_has_tables', False),
            "words_json": json.dumps(page.words),
        })
    return pd.DataFrame(rows)


def process_di_json_to_samples(
    di_json_path: str, file_label: Optional[str] = None,
) -> pd.DataFrame:
    """Process a DI JSON file and return flattened samples DataFrame."""
    return process_report_samples(_build_pages_df(di_json_path, file_label))


def process_di_json_to_soil_layers(
    di_json_path: str, file_label: Optional[str] = None,
) -> pd.DataFrame:
    """Process a DI JSON file and return flattened soil layers DataFrame."""
    return process_report_soil_layers(_build_pages_df(di_json_path, file_label))


def process_di_json_to_water_levels(
    di_json_path: str, file_label: Optional[str] = None,
) -> pd.DataFrame:
    """Process a DI JSON file and return flattened water levels DataFrame."""
    return process_report_water_levels(_build_pages_df(di_json_path, file_label))


# ---------------------------------------------------------------------------
# Stage 2b: Per-page classification (GeotechReportPage ontology backing)
# ---------------------------------------------------------------------------

def process_report_pages(pdf: pd.DataFrame) -> pd.DataFrame:
    """Classify every page in a report and output per-page metadata.

    Combines XGBoost boring-log classification with regex-based lab test
    detection to produce one row per page — backing the GeotechReportPage
    ontology object.

    Args:
        pdf: Pandas DataFrame with all pages from one report.
             Expected columns: source_file, page_number, page_text,
             page_width, page_height, word_count, has_tables, words_json

    Returns:
        DataFrame with one row per page (PAGE_COLUMNS).
    """
    from geotech_report_extraction.lab_tests import detect_lab_test_type

    if pdf.empty:
        return pd.DataFrame(columns=PAGE_COLUMNS)

    source_file = pdf["source_file"].iloc[0]
    report_id = _report_id(source_file)

    # Reconstruct and classify pages
    pages = []
    for _, row in pdf.sort_values("page_number").iterrows():
        pages.append(_reconstruct_page(row))

    _classify_and_tag_pages(pages)

    # Build output rows
    results = []
    for page in pages:
        results.append({
            "report_id": report_id,
            "source_file": source_file,
            "page_number": page.page_number,
            "is_boring_log": bool(page.is_boring_log),
            "classification_confidence": float(
                getattr(page, "classification_score", 0.0) or 0.0
            ),
            "boring_id": page.boring_id if page.is_boring_log else None,
            "lab_test_type": detect_lab_test_type(page.text or ""),
            "word_count": len(page.words),
            "has_tables": bool(getattr(page, "_di_has_tables", False)),
        })

    return pd.DataFrame(results, columns=PAGE_COLUMNS)
