# status
::: horde_sdk.ai_horde_api.apimodels.generate.status
