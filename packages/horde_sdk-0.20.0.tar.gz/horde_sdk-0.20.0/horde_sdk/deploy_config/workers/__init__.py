"""Worker deployment configuration package."""
