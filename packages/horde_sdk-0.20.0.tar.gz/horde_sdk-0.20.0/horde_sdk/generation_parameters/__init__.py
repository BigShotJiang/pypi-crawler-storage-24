"""Contains class definitions and handling for object models of generation parameters.

For example, the parameters for text generation (inference) are defined in
:class:`horde_sdk.generation_parameters.text.object_models.TextGenerationParameters`
which contains fields such as `prompt`, `max_length`, `temperature`, etc.

"""

from horde_sdk.consts import KNOWN_NSFW_DETECTOR
from horde_sdk.generation_parameters.alchemy import AlchemyParameters, SingleAlchemyParameters
from horde_sdk.generation_parameters.alchemy.consts import (
    KNOWN_ALCHEMY_FORMS,
    KNOWN_ALCHEMY_TYPES,
    KNOWN_CAPTION_MODELS,
    KNOWN_CLIP_BLIP_TYPES,
    KNOWN_FACEFIXERS,
    KNOWN_INTERROGATORS,
    KNOWN_MISC_POST_PROCESSORS,
    KNOWN_UPSCALERS,
    is_caption_form,
    is_facefixer_form,
    is_interrogator_form,
    is_nsfw_detector_form,
    is_strip_background_form,
    is_upscaler_form,
)
from horde_sdk.generation_parameters.generic import (
    CompositeParametersBase,
    GenerationParameterBaseModel,
    GenerationParameterList,
    GenerationWithModelParameters,
)
from horde_sdk.generation_parameters.generic.consts import KNOWN_AUX_MODEL_SOURCE
from horde_sdk.generation_parameters.image.consts import (
    CLIP_SKIP_REPRESENTATION,
    KNOWN_IMAGE_CONTROLNETS,
    KNOWN_IMAGE_SAMPLERS,
    KNOWN_IMAGE_SCHEDULERS,
    KNOWN_IMAGE_SOURCE_PROCESSING,
    KNOWN_IMAGE_WORKFLOWS,
    LORA_TRIGGER_INJECT_CHOICE,
    TI_TRIGGER_INJECT_CHOICE,
)
from horde_sdk.generation_parameters.image.object_models import (
    BasicImageGenerationParameters,
    BasicImageGenerationParametersTemplate,
    ImageGenerationParameters,
    ImageGenerationParametersTemplate,
)
from horde_sdk.generation_parameters.text.object_models import (
    BasicTextGenerationFormatParameters,
    BasicTextGenerationParameters,
    KoboldAITextGenerationParameters,
    TextGenerationParameters,
)

__all__ = [
    "CLIP_SKIP_REPRESENTATION",
    "KNOWN_ALCHEMY_FORMS",
    "KNOWN_ALCHEMY_TYPES",
    "KNOWN_AUX_MODEL_SOURCE",
    "KNOWN_CAPTION_MODELS",
    "KNOWN_CLIP_BLIP_TYPES",
    "KNOWN_FACEFIXERS",
    "KNOWN_IMAGE_CONTROLNETS",
    "KNOWN_IMAGE_SAMPLERS",
    "KNOWN_IMAGE_SCHEDULERS",
    "KNOWN_IMAGE_SOURCE_PROCESSING",
    "KNOWN_IMAGE_WORKFLOWS",
    "KNOWN_INTERROGATORS",
    "KNOWN_MISC_POST_PROCESSORS",
    "KNOWN_NSFW_DETECTOR",
    "KNOWN_UPSCALERS",
    "LORA_TRIGGER_INJECT_CHOICE",
    "TI_TRIGGER_INJECT_CHOICE",
    "AlchemyParameters",
    "BasicImageGenerationParameters",
    "BasicImageGenerationParametersTemplate",
    "BasicTextGenerationFormatParameters",
    "BasicTextGenerationParameters",
    "CompositeParametersBase",
    "GenerationParameterBaseModel",
    "GenerationParameterList",
    "GenerationWithModelParameters",
    "ImageGenerationParameters",
    "ImageGenerationParametersTemplate",
    "KoboldAITextGenerationParameters",
    "SingleAlchemyParameters",
    "TextGenerationParameters",
    "is_caption_form",
    "is_facefixer_form",
    "is_interrogator_form",
    "is_nsfw_detector_form",
    "is_strip_background_form",
    "is_upscaler_form",
]
