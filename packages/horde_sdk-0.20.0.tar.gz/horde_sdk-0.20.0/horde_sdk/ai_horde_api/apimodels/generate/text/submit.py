from __future__ import annotations

from typing import override

from loguru import logger
from pydantic import model_validator

from horde_sdk.ai_horde_api.apimodels.base import (
    BaseAIHordeRequest,
    GenMetadataEntry,
    JobRequestMixin,
    JobSubmitResponse,
)
from horde_sdk.ai_horde_api.consts import GENERATION_STATE
from horde_sdk.ai_horde_api.endpoints import AI_HORDE_API_ENDPOINT_SUBPATH
from horde_sdk.consts import HTTPMethod
from horde_sdk.generic_api.apimodels import APIKeyAllowedInRequestMixin
from horde_sdk.generic_api.decoration import Unequatable, Unhashable


@Unhashable
@Unequatable
class TextGenerationJobSubmitRequest(
    BaseAIHordeRequest,
    JobRequestMixin,
    APIKeyAllowedInRequestMixin,
):
    """Used when a worker submits a generation job. Includes metadata about the generation.

    Represents a POST request to the /v2/generate/text/submit endpoint.

    v2 API Model: `SubmitInputKobold`
    """

    generation: str = ""
    """R2 result was uploaded to R2, else the string of the result."""
    state: GENERATION_STATE
    """The state of this generation."""
    gen_metadata: list[GenMetadataEntry] | None = None
    """Extra metadata about faulted or defaulted components of the generation"""

    @model_validator(mode="after")
    def validate_generation(self) -> TextGenerationJobSubmitRequest:
        """Validate the generation field is not an empty string."""
        if self.generation == "":
            logger.error("Generation cannot be an empty string.")
            logger.error(self.log_safe_model_dump())

        return self

    @override
    @classmethod
    def get_api_model_name(cls) -> str | None:
        return "SubmitInputKobold"

    @override
    @classmethod
    def get_http_method(cls) -> HTTPMethod:
        return HTTPMethod.POST

    @override
    @classmethod
    def get_api_endpoint_subpath(cls) -> AI_HORDE_API_ENDPOINT_SUBPATH:
        return AI_HORDE_API_ENDPOINT_SUBPATH.v2_generate_text_submit

    @override
    @classmethod
    def get_default_success_response_type(cls) -> type[JobSubmitResponse]:
        return JobSubmitResponse
