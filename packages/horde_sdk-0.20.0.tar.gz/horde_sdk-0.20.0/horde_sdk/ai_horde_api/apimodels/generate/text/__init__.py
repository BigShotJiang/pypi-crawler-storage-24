"""Text generation API models."""
