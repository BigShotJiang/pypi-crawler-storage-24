
from romayneutils.helpers_util import dprint

from selenium import webdriver

# A simple set of configuration options to use for creating a chrome webdriver.
def get_driver(verbose:bool = False) -> webdriver.Chrome:
    dprint(verbose, "Loading webdriver...")
    options = webdriver.ChromeOptions()
    #options.add_argument('--remote-debugging-pipe')
    #options.add_argument(rf"--user-data-dir=C:\Users\Romayne\AppData\Local\Google\Chrome\User Data")
    #options.add_argument(rf'--profile-directory=Profile 1')
    #options.add_experimental_option('excludeSwitches', ['enable-logging'])
    #options.binary_location = rf'C:\Program Files\Google\Chrome\Application\chrome.exe'
    driver = webdriver.Chrome(options=options)
    dprint(verbose, "Waiting for webdriver to load...")
    #driver.implicitly_wait(5)
    dprint(verbose, "Successfully loaded webdriver.")
    return driver

driver = get_driver(True)
driver.quit()