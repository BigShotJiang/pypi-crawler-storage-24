
from romayneutils.helpers_util import Path
from romayneutils.user_util import user_confirm

import os, json
from os.path import exists

def delete_file(file_path:str|Path, confirm=True):
    if confirm:
        print(f"Delete {file_path}?")
        if not user_confirm():
            return
    os.remove(str(file_path))

# Returns whether the given file exists. If create is True, creates the file
# Returns True if the file already existed, False otherwise.
def ensure_file_exists(file_path:str, create = False):
    if exists(file_path):
        return True
    else:
        if create:
            with open(file_path, "x"):
                pass
        return False

# Read something from the given file. This returns None if the file doesn't exist.
def read_file_contents(file_path:str,
                       lines = False,
                       encoding = "utf-8",
                       read_mode = "r"):
    if not ensure_file_exists(file_path):
        return None
    if "b" in read_mode:
        encoding = None # Binary files do not take encoding arguments
    else:
        file = open(file = file_path, mode = read_mode, encoding = encoding)
        if lines:
            return file.readlines()
        else:
            return file.read()

def read_file_json(file_path:str|Path):
    if not ensure_file_exists(file_path):
        return {}
    try:
        return json.loads(open(str(file_path), "r").read())
    except TypeError:
        return {}

# Write out some string to the file path given. This will create the file if it does not yet exist.
def write_file_contents(file_path:str,
                        contents:str,
                        write_mode = "w"):
    ensure_file_exists(file_path, create = True)
    if (not "w" in write_mode) and (not "a" in write_mode):
        print(f"WARN: No valid 'w' or 'a' mode passed to write_mode {write_mode}. File writing will probably fail!")
    with open(file = file_path, mode = write_mode) as file:
        file.write(contents)

# Write out a python list to a given file. Will cast each content to a string unless string_method is provided.
# Delimiter is newlines by default
def write_list_contents(file_path:str,
                        py_list:list,
                        delimiter = "\n",
                        string_method = str):
    outfile_contents = ""
    for item in py_list:
        string_item = string_method(item)
        outfile_contents += f"{string_item}{delimiter}"
    write_file_contents(file_path, outfile_contents)

def save(filePath:str, newPath:str):
    if (not ensure_file_exists(str(filePath))):
        print(f"ERROR: {filePath} does not exist.")
        return False
    contents = read_file_contents(str(filePath))
    write_file_contents(str(newPath), contents)
    return True

def try_save(filePath:str, newPath:str):
    if (not save(filePath, newPath)):
        # Save unsuccessful, likely due to filePath not existing. Suggest loading (save in reverse)
        if (not ensure_file_exists(newPath)):
            print(f"Neither {newPath} or {filePath} exists. Uh oh!")
            return False # TODO: Just create a new file at filePath. Not done yet because its 
        print(f"Save of {filePath} failed. Load from {newPath} instead?")
        if (user_confirm()):
            save(newPath, filePath)
        else:
            return False
    return True

def sync_files(path1:str, path2:str, bidirectional=False):
    """
    file1: File to copy to file2 / recieve file1 if bidirectional
    file2: File to recieve copy1 / recieve file2 if bidirectional
    bidirectional: Whether or not to overwrite both ways.
    """
    # Edge case: If file1 is gone, load in file2
    if not ensure_file_exists(path1):
        print(f"Did not detect {path1}. Loading from {path2}")
        return try_save(path2, path1)
    
    file1_mtime = os.path.getmtime(str(path1)) if (ensure_file_exists(str(path1))) else 0
    file2_mtime = os.path.getmtime(str(path2)) if (ensure_file_exists(str(path2))) else 0

    # TODO: comment this tidbit when im not tired
    if file1_mtime > file2_mtime:
        return try_save(path1, path2)
    else:
        if bidirectional:
            return try_save(path2, path1)