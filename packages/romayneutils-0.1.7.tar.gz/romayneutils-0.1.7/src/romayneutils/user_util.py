

def user_confirm(message:str|None = None) -> bool:
    if (message is not None):
        print(message)
    max_tries = 10
    while max_tries > 0:
        max_tries -= 1
        confirm = input("Y/N: ").lower()[0]
        if confirm == 'y':
            return True
        if confirm == 'n':
            return False
    return False

def user_input(message:str = "", conditions:list[function]|None = None, allowed_responses:list[str]|None = None) -> str|None:
    attempts = 100
    user_response = None
    passed_conditions = True
    allowed_response = True
    while attempts > 0:
        attempts -= 1
        user_response = input(message)
        try:
            passed_conditions = (conditions == None) \
                                or all([condition(user_response) for condition in conditions])
        except Exception:
            passed_conditions = False
        allowed_response = (allowed_responses == None) or (user_response in allowed_responses)
        if (not passed_conditions) or (not allowed_response):
            print(f"Invalid response. {passed_conditions}, {allowed_response}")
            continue
        if user_confirm(f"Confirm selection '{user_response}':"):
            return user_response

def user_select(options:list[str], message:str|None = None) -> int:
    if (message is not None):
        print(message)
    max_tries = 10
    options_formatted:list[str] = [f"{i+1}: {option}" for i,option in enumerate(options)]
    options_concat:str = "\n".join(options_formatted)
    print(options_concat)
    while max_tries > 0:
        max_tries -= 1
        try:
            choice = int(input("Enter choice: "))
            if (choice < 1) or (choice > len(options)):
                print("Invalid selection.")
            else:
                return choice
        except ValueError:
            pass
    return 0
