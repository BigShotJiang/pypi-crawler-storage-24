from ._mWinPy import Process


__all__ = [
    "Process"
]