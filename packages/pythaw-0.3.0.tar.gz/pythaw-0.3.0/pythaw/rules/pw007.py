from __future__ import annotations

import ast

from pythaw.rules._base import Rule


class RedisStrictRule(Rule):
    """Detect redis.StrictRedis() calls inside handler functions."""

    code = "PW007"
    message = "redis.StrictRedis() should be called at module scope"

    what = (
        "Detects `redis.StrictRedis()` calls inside Lambda handler functions. "
        "These calls create Redis client connections, which involves "
        "TCP handshake and connection pool setup."
    )

    why = (
        "Creating a StrictRedis client inside the handler means its connection pool "
        "is discarded after every invocation. Moving it to module scope allows AWS "
        "Lambda to reuse established connections across warm invocations, "
        "avoiding repeated TCP handshakes."
    )

    example = (
        "# NG\n"
        "def handler(event, context):\n"
        "    r = redis.StrictRedis(host='...')  # Created every invocation\n"
        "\n"
        "# OK\n"
        "r = redis.StrictRedis(host='...')  # Created once at module load\n"
        "\n"
        "def handler(event, context):\n"
        "    r.get('key')\n"
    )

    def check(self, node: ast.Call) -> bool:
        return (
            isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "redis"
            and node.func.attr == "StrictRedis"
        )
