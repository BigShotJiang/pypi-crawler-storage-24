import os
from setuptools import setup, find_packages

# Read the contents of your README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="marco-dvcs",  # Changed to 'marco-dvcs' as 'marco' might be taken on PyPI
    version="0.1.48",
    author="Your Name",
    author_email="your.email@example.com",
    description="A minimal dataset versioning system for text data with a focus on reproducibility.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Team-Marco-ACM/marco-package",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pandas",
        "numpy",
        "Flask",
    ],
    entry_points={
        "console_scripts": [
            "marco=marco.cli.main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)


