"""
pycrq — A production-quality Open FAIR (Factor Analysis of Information Risk)
library for quantitative cyber risk analysis.

Quick Start
-----------
>>> from pycrq import ScenarioBuilder, pert, FAIRSimulator, scenario_report
>>> scenario = (
...     ScenarioBuilder("Ransomware Attack")
...     .asset("Customer Database", "Information")
...     .threat("External Hacker", "External Adversarial")
...     .tef(pert(1, 3, 8))
...     .vulnerability(pert(0.1, 0.3, 0.6))
...     .primary_loss(pert(50_000, 250_000, 1_500_000))
...     .build()
... )
>>> simulator = FAIRSimulator(n_simulations=10_000, seed=42)
>>> result = simulator.simulate(scenario)
>>> print(scenario_report(result))

Modules
-------
distributions : Probability distributions (PERT, Normal, LogNormal, etc.)
ontology      : FAIR data model (Asset, ThreatAgent, FAIRScenario, RiskRegister)
simulation    : Monte Carlo engine (FAIRSimulator, SimulationResult)
scenarios     : Fluent ScenarioBuilder API
analysis      : Risk metrics, ranking, control ROI, sensitivity analysis
reporting     : Text reports, JSON/CSV export, matplotlib visualisations
utils         : Calibration helpers, validation, unit conversions
"""

from .distributions import (
    Distribution,
    PERTDistribution,
    NormalDistribution,
    LogNormalDistribution,
    UniformDistribution,
    TriangularDistribution,
    ConstantDistribution,
    BetaDistribution,
    PoissonDistribution,
    pert,
    normal,
    lognormal,
    uniform,
    triangular,
    constant,
    beta,
    poisson,
    from_dict,
)

from .ontology import (
    Asset,
    ThreatAgent,
    Control,
    FrequencyFactors,
    LossMagnitudeFactors,
    FAIRScenario,
    RiskRegister,
    AssetType,
    ThreatType,
    LossCategory,
    EffectType,
)

from .simulation import (
    FAIRSimulator,
    SimulationResult,
    AggregateSimulationResult,
)

from .scenarios import ScenarioBuilder

from .analysis import (
    RiskMetrics,
    compute_metrics,
    classify_risk_level,
    rank_scenarios,
    compute_risk_reduction,
    control_roi,
    sensitivity_analysis,
    bootstrap_confidence_interval,
)

from .reporting import (
    format_currency,
    format_frequency,
    scenario_report,
    register_report,
    export_json,
    export_csv,
    plot_ale_distribution,
    plot_scenario_comparison,
    plot_risk_matrix,
)

from .utils import (
    validate_scenario,
    calibrate_pert_from_confidence,
    frequency_to_rate,
    annualize,
    summary_table,
)

__version__ = "1.0.0"
__author__ = "Open FAIR Library"
__license__ = "MIT"

__all__ = [
    # Version
    "__version__",
    # distributions
    "Distribution",
    "PERTDistribution",
    "NormalDistribution",
    "LogNormalDistribution",
    "UniformDistribution",
    "TriangularDistribution",
    "ConstantDistribution",
    "BetaDistribution",
    "PoissonDistribution",
    "pert",
    "normal",
    "lognormal",
    "uniform",
    "triangular",
    "constant",
    "beta",
    "poisson",
    "from_dict",
    # ontology
    "Asset",
    "ThreatAgent",
    "Control",
    "FrequencyFactors",
    "LossMagnitudeFactors",
    "FAIRScenario",
    "RiskRegister",
    "AssetType",
    "ThreatType",
    "LossCategory",
    "EffectType",
    # simulation
    "FAIRSimulator",
    "SimulationResult",
    "AggregateSimulationResult",
    # scenarios
    "ScenarioBuilder",
    # analysis
    "RiskMetrics",
    "compute_metrics",
    "classify_risk_level",
    "rank_scenarios",
    "compute_risk_reduction",
    "control_roi",
    "sensitivity_analysis",
    "bootstrap_confidence_interval",
    # reporting
    "format_currency",
    "format_frequency",
    "scenario_report",
    "register_report",
    "export_json",
    "export_csv",
    "plot_ale_distribution",
    "plot_scenario_comparison",
    "plot_risk_matrix",
    # utils
    "validate_scenario",
    "calibrate_pert_from_confidence",
    "frequency_to_rate",
    "annualize",
    "summary_table",
]
