"""LLM model metadata, provider orchestration, sessions, budget tracking"""

__version__ = "0.0.1"
