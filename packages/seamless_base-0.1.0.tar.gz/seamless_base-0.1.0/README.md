# seamless-base

`seamless-base` contains the core runtime primitives used by the Seamless ecosystem:

- content identity (`Checksum`)
- data buffers (`Buffer`)
- cache and buffer writer infrastructure
- checksum serialization/parsing utilities
- transformer base-level APIs

This package is intended to be a reusable core dependency for higher-level Seamless packages such as `seamless-config`, `seamless-remote`, and `seamless-transformer`.

## Installation

```bash
pip install seamless-base
```

## CLI scripts

Installing `seamless-base` also provides:

- `seamless-checksum`
- `seamless-checksum-file`
- `seamless-checksum-index`

## Development build

```bash
python -m pip install --upgrade build
python -m build
```
