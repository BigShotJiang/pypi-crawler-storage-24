"""codelace CLI - provider daemon for the codelace compute network."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import signal
import subprocess
import sys
import time
from pathlib import Path

import httpx
import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .app_version import get_codelace_version
from .update import (
    DEFAULT_SERVER_URL,
    UpdateManager,
    default_manifest_url,
    restart_current_process,
)

app = typer.Typer(
    name="cddaemon",
    help="codelace provider daemon.",
    no_args_is_help=True,
)

CONFIG_DIR = Path.home() / ".codelace"
CONFIG_FILE = CONFIG_DIR / "config.json"
PID_FILE = CONFIG_DIR / "daemon.pid"
LOG_DIR = CONFIG_DIR / "log"
STDOUT_LOG = LOG_DIR / "daemon.log"
STDERR_LOG = LOG_DIR / "daemon.err"
PLIST_NAME = "com.codelace.daemon"
PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / f"{PLIST_NAME}.plist"

log = logging.getLogger("codelace.cli")
console = Console()


def _short(value: str | None, *, prefix: int = 8, suffix: int = 6) -> str:
    """Shorten a long id or token for compact display."""
    if not value:
        return "not set"
    if len(value) <= prefix + suffix + 3:
        return value
    return f"{value[:prefix]}...{value[-suffix:]}"


def _print_panel(title: str, rows: list[tuple[str, str]], *, style: str = "cyan") -> None:
    """Render a small key/value panel."""
    table = Table(box=box.SIMPLE, show_header=False, pad_edge=False)
    table.add_column("key", style="bold cyan", no_wrap=True)
    table.add_column("value", style="white")
    for key, value in rows:
        table.add_row(key, value)
    console.print(Panel(table, title=title, border_style=style, expand=False))


def _load_optional_config() -> dict:
    """Load config from ~/.codelace/config.json when it exists."""
    if not CONFIG_FILE.exists():
        return {}
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def _load_config() -> dict:
    """Load config from ~/.codelace/config.json."""
    config = _load_optional_config()
    if not config:
        typer.echo("Not initialized. Run: cddaemon init")
        raise typer.Exit(1)
    return config


def _save_config(config: dict) -> None:
    """Save config to ~/.codelace/config.json."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2), encoding="utf-8")


def _read_pid_file() -> int | None:
    """Read the local daemon PID file when it contains a valid integer."""
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return None


def _clear_pid_file(expected_pid: int | None = None) -> None:
    """Remove the local daemon PID file, optionally matching the current PID."""
    if not PID_FILE.exists():
        return
    if expected_pid is not None and _read_pid_file() != expected_pid:
        return
    PID_FILE.unlink(missing_ok=True)


def _write_pid_file(pid: int) -> None:
    """Persist the local daemon PID for stop/status commands."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(f"{pid}\n", encoding="utf-8")


def _ensure_log_dir() -> None:
    """Create the daemon log directory."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)


def _pid_looks_like_codelace(pid: int) -> bool:
    """Return True when the PID still belongs to a codelace CLI process."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True

    result = subprocess.run(
        ["ps", "-p", str(pid), "-o", "command="],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return True
    command = result.stdout.strip()
    return "cddaemon" in command or "cddaemon_cli.main" in command


def _running_daemon_pid() -> int | None:
    """Return the locally running daemon PID, cleaning up stale state as needed."""
    pid = _read_pid_file()
    if pid is None:
        return None
    if _pid_looks_like_codelace(pid):
        return pid
    _clear_pid_file(pid)
    return None


def _unwrap_response(payload: dict) -> dict:
    """Unwrap the backend's standard {success, data} envelope."""
    if isinstance(payload, dict) and "data" in payload:
        data = payload["data"]
        if isinstance(data, dict):
            return data
        return {"items": data}
    return payload


def _build_update_manager(config: dict | None = None) -> UpdateManager:
    """Create the CLI update manager."""
    loaded_config = config if config is not None else _load_optional_config()
    save_config = _save_config if loaded_config else None
    return UpdateManager(loaded_config, save_config)


def _run_preflight_update(config: dict) -> None:
    """Apply a pending CLI update before long-lived commands start."""
    updater = _build_update_manager(config)
    result = updater.check_for_update(force=False)

    if result.status in {"not_due", "up_to_date"}:
        return

    if result.status == "check_failed":
        log.warning(result.message)
        return

    if result.status == "local_install":
        if result.required:
            typer.echo(result.message)
            raise typer.Exit(1)
        log.debug(result.message)
        return

    if result.status == "unknown_version":
        typer.echo(result.message)
        raise typer.Exit(1)

    if result.status != "update_available" or not result.manifest:
        return

    typer.echo(f"Updating codelace CLI to {result.latest_version}...")
    install_result = updater.install_update(result.manifest)
    typer.echo(install_result.message)

    if install_result.applied:
        typer.echo("Restarting into the updated build...")
        restart_current_process()

    if install_result.required:
        raise typer.Exit(1)


def _daemon_command(bin_path: str, *, foreground: bool, verbose: bool) -> list[str]:
    """Build the command used to launch the daemon."""
    command_name = "run" if foreground else "start"
    if bin_path.endswith("codelace"):
        args = [bin_path, command_name]
    else:
        args = [bin_path, "-m", "cddaemon_cli.main", command_name]
    if verbose:
        args.append("--verbose")
    return args


def _validate_token(server: str, token: str) -> dict:
    """Validate a daemon token against the server and return provider info."""
    with httpx.Client(timeout=30) as client:
        response = client.post(
            f"{server}/api/v1/provider/validate-token",
            json={"daemon_token": token},
        )
    if response.status_code != 200:
        typer.echo(
            f"Token validation failed: {response.status_code} {response.text[:300]}"
        )
        raise typer.Exit(1)
    return _unwrap_response(response.json())


@app.command()
def init(
    token: str = typer.Option(
        ...,
        "--token",
        help="Daemon token (dt_ prefix) provided by the codelace dashboard.",
    ),
    server: str = typer.Option(
        DEFAULT_SERVER_URL,
        "--server",
        help="codelace API base URL.",
    ),
) -> None:
    """Initialize this machine as a codelace provider using a daemon token."""
    server = server.rstrip("/")

    if not token.startswith("dt_"):
        typer.echo("Invalid token format. Daemon tokens start with 'dt_'.")
        raise typer.Exit(1)

    console.print(f"[cyan]Validating token against[/cyan] [bold]{server}[/bold]...")

    try:
        provider_info = _validate_token(server, token)
    except httpx.ConnectError:
        typer.echo(f"Cannot connect to {server}. Is the codelace API reachable?")
        raise typer.Exit(1)

    provider_id = str(provider_info["provider_id"])
    console.print(
        f"[green]Token validated.[/green] Provider: [bold]{_short(provider_id)}[/bold]"
    )

    config = {
        "server_url": server,
        "manifest_url": default_manifest_url(server),
        "provider_id": provider_id,
        "daemon_token": token,
    }
    _save_config(config)

    _print_panel(
        "Provider Ready",
        [
            ("Config", str(CONFIG_FILE)),
            ("Provider ID", _short(provider_id)),
            ("Server", server),
            ("Next", "cddaemon start"),
        ],
        style="bright_green",
    )


@app.command()
def start(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable debug logging."
    ),
) -> None:
    """Start the provider daemon in the background."""
    _load_config()
    existing_pid = _running_daemon_pid()
    if existing_pid:
        typer.echo(
            f"cddaemon is already running locally (pid {existing_pid}). "
            "Use 'cddaemon stop' first."
        )
        raise typer.Exit(1)

    bin_path = _find_codelace_bin()
    command = _daemon_command(bin_path, foreground=True, verbose=verbose)
    _ensure_log_dir()

    with STDOUT_LOG.open("a", encoding="utf-8") as stdout_handle, STDERR_LOG.open(
        "a", encoding="utf-8"
    ) as stderr_handle:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=stdout_handle,
            stderr=stderr_handle,
            start_new_session=True,
            cwd=str(Path.cwd()),
        )

    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        pid = _running_daemon_pid()
        if pid is not None:
            _print_panel(
                "Daemon Started",
                [("PID", str(pid)), ("Mode", "background"), ("Logs", str(STDOUT_LOG))],
                style="green",
            )
            return
        if process.poll() is not None:
            break
        time.sleep(0.1)

    typer.echo("Failed to confirm daemon start. Check the daemon logs for details.")
    typer.echo(f"Logs: {STDOUT_LOG}")
    raise typer.Exit(1)


@app.command()
def run(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable debug logging."
    ),
) -> None:
    """Run the provider daemon in the foreground."""
    existing_pid = _running_daemon_pid()
    if existing_pid:
        typer.echo(
            f"cddaemon is already running locally (pid {existing_pid}). "
            "Use 'cddaemon stop' first."
        )
        raise typer.Exit(1)

    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )

    config = _load_config()
    _run_preflight_update(config)

    typer.echo(
        f"Starting codelace daemon {get_codelace_version()} "
        f"(server: {config['server_url']})"
    )

    from .daemon import CodelaceDaemon

    daemon = CodelaceDaemon(config, save_config=_save_config)
    _write_pid_file(os.getpid())
    try:
        asyncio.run(daemon.run())
    except KeyboardInterrupt:
        typer.echo("\nDaemon stopped.")
    finally:
        _clear_pid_file(os.getpid())


@app.command()
def stop() -> None:
    """Stop the locally running daemon process."""
    pid = _running_daemon_pid()
    if pid is None:
        typer.echo("No local cddaemon is running.")
        return

    try:
        os.kill(pid, signal.SIGINT)
    except ProcessLookupError:
        _clear_pid_file(pid)
        typer.echo("No local cddaemon is running.")
        return
    except PermissionError:
        typer.echo(f"Cannot stop daemon process {pid}. Permission denied.")
        raise typer.Exit(1)

    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        if _running_daemon_pid() is None:
            _print_panel(
                "Daemon Stopped",
                [("PID", str(pid)), ("State", "stopped")],
                style="yellow",
            )
            return
        time.sleep(0.1)

    typer.echo(
        f"Sent stop signal to daemon (pid {pid}). It may still be shutting down."
    )


@app.command()
def status() -> None:
    """Show provider connectivity and server health."""
    config = _load_config()
    server = config["server_url"]

    try:
        with httpx.Client(timeout=15) as client:
            try:
                health_response = client.get(f"{server}/health")
                health_ok = health_response.status_code == 200
            except httpx.ConnectError:
                health_ok = False
            if not health_ok:
                raise typer.Exit(1)

            provider_response = client.get(
                f"{server}/api/v1/provider/connected",
                headers={"Authorization": f"Bearer {config.get('daemon_token', '')}"},
            )
            provider_data = (
                _unwrap_response(provider_response.json())
                if provider_response.status_code == 200
                else {"items": []}
            )
            provider_list = provider_data.get("items", [])
            connected = any(
                item.get("provider_id") == config.get("provider_id")
                for item in provider_list
            )

    except httpx.ConnectError:
        typer.echo(f"Cannot connect to {server}")
        raise typer.Exit(1)

    daemon_state = "[green]running[/green]" if connected else "[red]stopped[/red]"
    server_state = "[green]online[/green]" if health_ok else "[red]offline[/red]"

    _print_panel(
        "codelace",
        [
            ("Daemon", daemon_state),
            ("Server", server_state),
            ("Provider ID", _short(config.get("provider_id"))),
        ],
        style="bright_cyan",
    )


@app.command()
def version() -> None:
    """Show the installed CLI version and update endpoint."""
    config = _load_optional_config()
    updater = _build_update_manager(config)

    update_state = config.get("update", {})
    rows = [
        ("Version", get_codelace_version()),
        ("Manifest", updater.manifest_url),
    ]
    if update_state:
        latest_version = update_state.get("latest_version")
        if latest_version:
            rows.append(
                (
                    "Last release seen",
                    f"{latest_version} ({update_state.get('last_status', 'unknown')})",
                )
            )
    _print_panel("cddaemon", rows, style="bright_blue")


@app.command("self-update")
def self_update() -> None:
    """Fetch the release manifest and install the latest packaged CLI."""
    updater = _build_update_manager()
    result = updater.check_for_update(force=True)

    if result.status in {"up_to_date", "not_due"}:
        typer.echo(result.message)
        return

    if result.status in {"check_failed", "unknown_version"}:
        typer.echo(result.message)
        raise typer.Exit(1)

    if result.status == "local_install":
        typer.echo(result.message)
        if result.required:
            raise typer.Exit(1)
        return

    if result.status != "update_available" or not result.manifest:
        typer.echo("No update action was taken.")
        return

    typer.echo(f"Installing codelace CLI {result.latest_version}...")
    install_result = updater.install_update(result.manifest)
    typer.echo(install_result.message)
    if not install_result.applied:
        raise typer.Exit(1)


def _find_codelace_bin() -> str:
    """Find the codelace executable path."""
    result = subprocess.run(["which", "cddaemon"], capture_output=True, text=True)
    if result.returncode == 0:
        return result.stdout.strip()
    return sys.executable


def _generate_plist(bin_path: str) -> str:
    """Generate a macOS LaunchAgent plist for the daemon."""
    _ensure_log_dir()

    path_entries = [
        *os.getenv("PATH", "").split(":"),
        str(Path.home() / ".local" / "bin"),
        str(Path.home() / ".cargo" / "bin"),
        str(Path.home() / ".pyenv" / "bin"),
        str(Path.home() / ".pyenv" / "shim"),
        "/opt/homebrew/bin",
        "/usr/local/bin",
        "/usr/bin",
        "/bin",
        "/usr/sbin",
        "/sbin",
    ]
    launch_path = ":".join(dict.fromkeys(entry for entry in path_entries if entry))

    daemon_args = _daemon_command(bin_path, foreground=True, verbose=False)
    program_args = "    <array>\n" + "\n".join(
        f"      <string>{arg}</string>" for arg in daemon_args
    ) + "\n    </array>"

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{PLIST_NAME}</string>
  <key>ProgramArguments</key>
{program_args}
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <dict>
    <key>NetworkState</key>
    <true/>
  </dict>
  <key>StandardOutPath</key>
  <string>{STDOUT_LOG}</string>
  <key>StandardErrorPath</key>
  <string>{STDERR_LOG}</string>
  <key>ThrottleInterval</key>
  <integer>30</integer>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>{launch_path}</string>
  </dict>
</dict>
</plist>
"""


@app.command()
def install() -> None:
    """Install the daemon to auto-start on login (macOS LaunchAgent)."""
    if platform.system() != "Darwin":
        typer.echo(
            "Auto-start is currently macOS only. Use systemd or another supervisor on Linux."
        )
        raise typer.Exit(1)

    config = _load_config()
    _run_preflight_update(config)

    bin_path = _find_codelace_bin()
    plist_content = _generate_plist(bin_path)

    if PLIST_PATH.exists():
        subprocess.run(["launchctl", "unload", str(PLIST_PATH)], capture_output=True)

    PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    PLIST_PATH.write_text(plist_content, encoding="utf-8")

    result = subprocess.run(
        ["launchctl", "load", str(PLIST_PATH)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        typer.echo(f"Failed to load LaunchAgent: {result.stderr.strip()}")
        raise typer.Exit(1)

    typer.echo("cddaemon installed and started.")
    typer.echo(f"  Plist: {PLIST_PATH}")
    typer.echo(f"  Logs:  {STDOUT_LOG}")
    typer.echo(
        "It will auto-start on login and pick up new CLI releases automatically."
    )
    typer.echo("To remove: cddaemon uninstall")


@app.command()
def uninstall() -> None:
    """Remove the auto-start daemon (macOS LaunchAgent)."""
    if not PLIST_PATH.exists():
        typer.echo("Not installed. Nothing to remove.")
        return

    subprocess.run(["launchctl", "unload", str(PLIST_PATH)], capture_output=True)
    PLIST_PATH.unlink()
    typer.echo("cddaemon uninstalled. It will no longer auto-start.")


if __name__ == "__main__":
    app()
