"""OpenAI provider backed by the local Codex CLI."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from pathlib import Path
from typing import AsyncIterator

from .base import BaseProvider
from ..token.codex import get_auth_status, get_codex_binary, get_subscription_info

log = logging.getLogger("codelace.provider.openai")

CODEX_CLI_CWD = Path.home()
CODEX_SYSTEM_PROMPT = (
    "You are serving an OpenAI-compatible chat completion request. "
    "Return only the assistant's next reply for the conversation transcript below. "
    "Do not add role labels, markdown fences, or explanations unless the user asked for them."
)
DATE_SUFFIX_RE = re.compile(r"-\d{8}$")

# Model families available via Codex
CODEX_MODEL = [
    "gpt-5",
    "gpt-5-codex",
    "gpt-5-codex-mini",
    "gpt-4o",
    "gpt-4o-mini",
    "o3",
    "o3-mini",
    "o4-mini",
]


def _resolve_cli_model(model: str) -> str:
    """Map API-facing model ids to Codex CLI model names."""
    stripped = DATE_SUFFIX_RE.sub("", model or "").strip()
    lowered = stripped.lower()

    if "codex-mini" in lowered:
        return "gpt-5-codex-mini"
    if "codex" in lowered:
        return "gpt-5-codex"
    if lowered.startswith("gpt-5"):
        return "gpt-5"
    if lowered.startswith("gpt-4o-mini"):
        return "gpt-4o-mini"
    if lowered.startswith("gpt-4o"):
        return "gpt-4o"
    if lowered.startswith("o3-mini"):
        return "o3-mini"
    if lowered.startswith("o3"):
        return "o3"
    if lowered.startswith("o4-mini"):
        return "o4-mini"
    return stripped or "gpt-5-codex-mini"


def _content_to_text(content: object) -> str:
    """Flatten OpenAI-style content payloads into plain text for Codex CLI."""
    if isinstance(content, str):
        return content

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            text = _content_to_text(item)
            if text:
                parts.append(text)
        return "\n".join(parts)

    if isinstance(content, dict):
        item_type = content.get("type")
        if item_type in {"text", "input_text", "output_text"}:
            text = content.get("text")
            return text if isinstance(text, str) else ""
        if item_type == "image_url":
            return "[image omitted]"
        if item_type == "input_image":
            return "[image input omitted]"
        if item_type == "tool_result":
            payload = content.get("content")
            return _content_to_text(payload) or "[tool result omitted]"

        if isinstance(content.get("text"), str):
            return content["text"]

    return str(content) if content is not None else ""


def _message_label(message: dict) -> str:
    """Convert an OpenAI chat role to a transcript label."""
    role = message.get("role", "user")
    if role == "assistant":
        return "Assistant"
    if role == "tool":
        name = message.get("name") or message.get("tool_name") or "tool"
        return f"Tool ({name})"
    return "User"


def _build_prompt(body: dict) -> str:
    """Render a chat transcript prompt for Codex CLI."""
    system_parts = [CODEX_SYSTEM_PROMPT]
    transcript: list[str] = []

    for message in body.get("messages", []):
        role = message.get("role", "")
        content = _content_to_text(message.get("content", ""))
        if role in {"system", "developer"}:
            if content:
                system_parts.append(content)
            continue

        if not content and message.get("tool_calls"):
            content = json.dumps(message["tool_calls"], ensure_ascii=False)
        if not content:
            continue

        transcript.append(f"{_message_label(message)}:\n{content}")

    if not transcript:
        transcript.append("User:\nPlease respond to the request.")

    prompt = (
        "\n\n".join(part for part in system_parts if part)
        + "\n\nContinue the conversation below and produce only the next assistant reply.\n\n"
        + "\n\n".join(transcript)
        + "\n\nAssistant:\n"
    )
    return prompt


def _normalize_stop(stop: object) -> list[str]:
    if isinstance(stop, str):
        return [stop]
    if isinstance(stop, list):
        return [item for item in stop if isinstance(item, str) and item]
    return []


def _apply_stop_sequences(text: str, stop: object) -> str:
    """Trim the first configured stop sequence from the response text."""
    stop_sequences = _normalize_stop(stop)
    indexes = [text.find(seq) for seq in stop_sequences if seq and seq in text]
    if not indexes:
        return text
    return text[: min(indexes)]


def _extract_usage(payload: dict) -> dict[str, int]:
    """Normalize Codex CLI usage payloads."""
    if not isinstance(payload, dict):
        return {"input_tokens": 0, "output_tokens": 0}
    return {
        "input_tokens": int(payload.get("input_tokens", 0) or 0),
        "output_tokens": int(payload.get("output_tokens", 0) or 0),
    }


def _role_chunk(request_id: str, model: str) -> dict:
    return {
        "id": f"chatcmpl-{request_id}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": {"role": "assistant"},
                "finish_reason": None,
            }
        ],
    }


def _content_chunk(request_id: str, model: str, text: str) -> dict:
    return {
        "id": f"chatcmpl-{request_id}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": {"content": text},
                "finish_reason": None,
            }
        ],
    }


def _finish_chunk(request_id: str, model: str) -> dict:
    return {
        "id": f"chatcmpl-{request_id}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": {},
                "finish_reason": "stop",
            }
        ],
    }


class OpenAIProvider(BaseProvider):
    async def is_available(self) -> bool:
        status = get_auth_status()
        return bool(get_codex_binary()) and bool(status.get("loggedIn"))

    async def get_capability(self) -> dict:
        info = get_subscription_info()
        return {
            "vendor": "openai",
            "subscription_type": info.get("subscription_type", "unknown"),
            "rate_limit_tier": None,
            "model_family": CODEX_MODEL,
        }

    async def stream_inference(
        self, request_id: str, model: str, body: dict
    ) -> AsyncIterator[dict]:
        binary = get_codex_binary()
        auth = get_auth_status()
        if not binary:
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": "Codex CLI is not installed on this machine",
            }
            return
        if not auth.get("loggedIn"):
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": "Codex is not logged in on this machine",
            }
            return

        prompt = _build_prompt(body)
        cli_model = _resolve_cli_model(model)
        usage = {"input_tokens": 0, "output_tokens": 0}
        response_text = ""
        error_message = ""

        cmd = [
            binary,
            "exec",
            "--json",
            "--skip-git-repo-check",
            "--sandbox",
            "read-only",
            "--ephemeral",
            "--color",
            "never",
            "-C",
            str(CODEX_CLI_CWD),
            "-c",
            'model_reasoning_effort="medium"',
            "-m",
            cli_model,
            "-",
        ]

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=str(CODEX_CLI_CWD),
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )

            assert process.stdin is not None
            process.stdin.write(prompt.encode("utf-8"))
            await process.stdin.drain()
            process.stdin.close()

            assert process.stdout is not None
            while True:
                raw = await process.stdout.readline()
                if not raw:
                    break

                line = raw.decode("utf-8", errors="replace").strip()
                if not line or not line.startswith("{"):
                    continue

                try:
                    event = json.loads(line)
                except ValueError:
                    continue

                event_type = event.get("type")
                if event_type == "item.completed":
                    item = event.get("item") or {}
                    if item.get("type") == "agent_message":
                        response_text = str(item.get("text") or response_text)
                elif event_type == "turn.completed":
                    usage = _extract_usage(event.get("usage") or {})
                elif event_type == "error":
                    error_message = str(event.get("message") or "Codex request failed")
                elif event_type == "turn.failed":
                    error_payload = event.get("error") or {}
                    error_message = str(
                        error_payload.get("message")
                        or error_message
                        or "Codex request failed"
                    )

            returncode = await process.wait()
            if error_message or (returncode != 0 and not response_text):
                yield {
                    "type": "stream_error",
                    "request_id": request_id,
                    "error": error_message or "Codex request failed",
                }
                return

            trimmed = _apply_stop_sequences(response_text, body.get("stop"))
            yield {
                "type": "stream_chunk",
                "request_id": request_id,
                "data": _role_chunk(request_id, cli_model),
            }
            if trimmed:
                yield {
                    "type": "stream_chunk",
                    "request_id": request_id,
                    "data": _content_chunk(request_id, cli_model, trimmed),
                }
            yield {
                "type": "stream_chunk",
                "request_id": request_id,
                "data": _finish_chunk(request_id, cli_model),
            }
            yield {
                "type": "stream_complete",
                "request_id": request_id,
                "vendor": "openai",
                "model_resolved": cli_model,
                "usage": usage,
            }

        except Exception as e:
            log.error("Codex streaming error: %s", e)
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": str(e),
            }
