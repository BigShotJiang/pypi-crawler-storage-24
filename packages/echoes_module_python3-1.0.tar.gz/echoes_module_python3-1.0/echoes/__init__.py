"Echoes."
class wrap:
	"""Example usage:

	x = wrap(10)
	x << 5
	x << 2"""
	__slots__=("history","_b")
	def __init__(s,value):
		s.history=[value]
	def __lshift__(s,value):
		if len(s.history)==10:
			del s.history[0]
		s.history.append(value)
		return s
	def __add__(s,other):
		return s.history[-1]+other
	def __sub__(s,other):
		return s.history[-1]-other
	def __mul__(s,other):
		return s.history[-1]*other
	def __truediv__(s,other):
		return s.history[-1]/other
	def __matmul__(s,other):
		return s.history[-1]@other
	def __str__(s):
		return str(s.history[-1])
	def __repr__(s):
		return repr(s.history[-1])
	def __getattr__(s,n):
		return getattr(s.history[-1],n)
	def __getitem__(s,i):
		return s.history[-1][i]
	def __call__(s):
		return s.history[-1]
	def __enter__(s): s._b=s.history[:]; return s
	def __exit__(s,*a):
		s.history=s._b
	def rewind(s):
		s.history=s.history[1:]+s.history[:1]
	def dewind(s):
		s.history=s.history[-1:]+s.history[:-1]