import os
import time
from dataclasses import dataclass
from http import HTTPStatus
from typing import Any, Optional

from fastapi import HTTPException, Request, Response
from starlette.concurrency import run_in_threadpool
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import HTTPConnection
from starlette.types import ASGIApp, Receive, Scope, Send

from .clients.gateway import (
    EndTaskRequest,
    StartTaskRequest,
)
from .logging import StdoutJsonInterceptor
from .runner.common import config as cfg
from .runner.common import end_task_and_send_callback
from .type import TaskStatus


@dataclass
class TaskLifecycleData:
    status: TaskStatus
    result: Any
    override_callback_url: Optional[str] = None


async def run_task(request, func, func_args):
    start_time = time.time()
    task_id = request.headers.get("X-TASK-ID")
    if not task_id:
        raise HTTPException(status_code=HTTPStatus.BAD_REQUEST, detail="Task ID missing")

    skip_step = request.headers.get("SKIP-STEP", "")
    # SKIP-STEP=no-func: skip handler execution but still do task lifecycle (start_task/end_task)
    skip_handler_execution = skip_step == "no-func"
    # SKIP-STEP=no-lifecycle: skip start_task/end_task but still execute handler
    skip_lifecycle = skip_step == "no-lifecycle"

    os.environ["TASK_ID"] = task_id
    with StdoutJsonInterceptor(task_id=task_id):
        print(f"Received task <{task_id}>")

        if not skip_lifecycle:
            for attempt in range(3):
                try:
                    start_response = await run_in_threadpool(
                        request.app.state.gateway_stub.start_task,
                        StartTaskRequest(task_id=task_id, container_id=cfg.container_id),
                    )
                    if start_response.ok:
                        break
                    else:
                        raise HTTPException(
                            status_code=HTTPStatus.INTERNAL_SERVER_ERROR, detail="Failed to start task"
                        )
                except BaseException:
                    if attempt == 2:
                        raise
        else:
            print(f"Task <{task_id}> start_task skipped (no-lifecycle)")

        task_lifecycle_data = TaskLifecycleData(
            status=TaskStatus.Complete, result=None, override_callback_url=None
        )

        try:
            request.state.task_lifecycle_data = task_lifecycle_data
            handler_start_time = time.time()
            if skip_handler_execution:
                print(f"Task <{task_id}> handler execution skipped")
                if request.scope.get("type") == "http":
                    response = Response(status_code=HTTPStatus.OK)
                else:
                    response = None
            else:
                response = await func(*func_args)
            handler_duration = time.time() - handler_start_time
            print(f"Task <{task_id}> handler duration: {handler_duration:.3f}s")
            print(f"Task <{task_id}> finished")
            return response
        finally:
            if "TASK_ID" in os.environ:
                del os.environ["TASK_ID"]

            if not skip_lifecycle:
                await run_in_threadpool(
                    end_task_and_send_callback,
                    gateway_stub=request.app.state.gateway_stub,
                    payload=task_lifecycle_data.result,
                    end_task_request=EndTaskRequest(
                        task_id=task_id,
                        container_id=cfg.container_id,
                        keep_warm_seconds=cfg.keep_warm_seconds,
                        task_status=task_lifecycle_data.status,
                        task_duration=time.time() - start_time,
                    ),
                    override_callback_url=task_lifecycle_data.override_callback_url,
                )
            else:
                print(f"Task <{task_id}> end_task skipped (no-lifecycle)")


class WebsocketTaskLifecycleMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "websocket":
            await self.app(scope, receive, send)
            return

        request = HTTPConnection(scope, receive)
        return await run_task(request, self.app, (scope, receive, send))


class TaskLifecycleMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path == "/health":
            return await call_next(request)

        return await run_task(request, call_next, (request,))
