import json
import os
import subprocess
import time
from dataclasses import asdict, dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from ... import terminal
from ...abstractions.base.container import Container
from ...abstractions.base.runner import ASGI_DEPLOYMENT_STUB_TYPE, ASGI_SERVE_STUB_TYPE
from ...abstractions.endpoint import ASGI
from ...abstractions.image import Image
from ...abstractions.volume import CloudBucket, Volume
from ...channel import with_grpc_error_handling
from ...clients.endpoint import StartEndpointServeRequest, StartEndpointServeResponse
from ...clients.gateway import DeployStubRequest, DeployStubResponse
from ...config import ConfigContext
from ...type import Autoscaler, GpuTypeAlias, QueueDepthAutoscaler

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None

DEFAULT_SGLANG_IMAGE = "docker.1ms.run/lmsysorg/sglang:v0.5.7-cu130-amd64-runtime"
_LOCK_FILE_HANDLE = None


@dataclass
class SGLangArgs:
    """
    SGLang 服务参数，默认值与 app-asgi-sglang-glm4.5-air.py 对齐。
    """

    served_model_name: str = "wsg/glm-4.5-air"
    model_path: str = "/b-glm-4.5-air-base"
    host: str = "0.0.0.0"
    port: int = 20000
    tensor_parallel_size: int = 2
    pipeline_parallel_size: int = 1
    quantization: Optional[str] = "fp8"
    enable_metrics: bool = True
    preferred_sampling_params: Optional[str] = (
        '{"temperature":0.6,"top_p":0.95,"top_k":50,"max_new_tokens":1024,"repetition_penalty":1.0}'
    )
    extra_cli_args: Optional[Dict[str, Any]] = None

    def to_cli_args(self) -> List[str]:
        args = [
            "--served-model-name",
            self.served_model_name,
            "--model-path",
            self.model_path,
            "--tensor-parallel-size",
            str(self.tensor_parallel_size),
            "--pipeline-parallel-size",
            str(self.pipeline_parallel_size),
            "--port",
            str(self.port),
            "--host",
            self.host,
        ]

        if self.quantization:
            args.extend(["--quantization", self.quantization])

        if self.enable_metrics:
            args.append("--enable-metrics")

        if self.preferred_sampling_params:
            args.extend(["--preferred-sampling-params", self.preferred_sampling_params])

        for key, value in (self.extra_cli_args or {}).items():
            option = f"--{key.replace('_', '-')}"
            if isinstance(value, bool):
                if value:
                    args.append(option)
                continue
            if value is None:
                continue
            args.extend([option, str(value)])

        return args


class SGLang(ASGI):
    """
    SGLang 集成：在同一容器中启动 SGLang，并通过 ASGI 应用代理 OpenAI 兼容接口。

    默认参数对齐示例 app-asgi-sglang-glm4.5-air.py，且支持自定义镜像与参数。
    """

    def __init__(
        self,
        cpu: Union[int, float, str] = 64,
        memory: Union[int, str] = "128Gi",
        gpu: GpuTypeAlias = "H200",
        gpu_count: int = 2,
        image: Optional[Image] = None,
        workers: int = 8,
        concurrent_requests: int = 20000,
        keep_warm_seconds: int = 600,
        max_pending_tasks: int = 20000,
        timeout: int = 600,
        authorized: bool = True,
        name: Optional[str] = None,
        volumes: Optional[List[Union[Volume, CloudBucket]]] = None,
        secrets: Optional[List[str]] = None,
        autoscaler: Autoscaler = QueueDepthAutoscaler(min_containers=1, max_containers=1, tasks_per_container=1),
        sglang_args: Union[SGLangArgs, Dict[str, Any]] = SGLangArgs(),
        env: Optional[Dict[str, str]] = None,
    ):
        if volumes is None:
            volumes = []

        default_image_commands = [
            'pip install "gunicorn>=25.0.0,<26.0.8" -i https://pypi.mirrors.ustc.edu.cn/simple',
            'pip install "bcrypt==3.2.2" -i https://pypi.mirrors.ustc.edu.cn/simple',
            'pip install bore-client -i https://pypi.mirrors.ustc.edu.cn/simple',
        ]

        if image is None:
            image = Image(
                base_image=DEFAULT_SGLANG_IMAGE,
                python_version="python3.12",
                ignore_python=True,
                commands=default_image_commands,
            )
        else:
            if not image.base_image:
                image.base_image = DEFAULT_SGLANG_IMAGE
                image.ignore_python = True
            image.commands = [*default_image_commands, *image.commands]

        runtime_env = {
            "PYTHONUNBUFFERED": "1",
            "SGLANG_LOG_LEVEL": "DEBUG",
            "SGLANG_TRACE_REQUEST": "1",
            "REUSE_PORT": "true",
        }
        if env:
            runtime_env.update(env)

        super().__init__(
            cpu=cpu,
            memory=memory,
            gpu=gpu,
            gpu_count=gpu_count,
            image=image,
            workers=workers,
            concurrent_requests=concurrent_requests,
            keep_warm_seconds=keep_warm_seconds,
            max_pending_tasks=max_pending_tasks,
            timeout=timeout,
            authorized=authorized,
            name=name,
            volumes=volumes,
            secrets=secrets,
            autoscaler=autoscaler,
            env=runtime_env,
            on_start=self._start_sglang_server,
        )

        if isinstance(sglang_args, SGLangArgs):
            self.sglang_args = sglang_args
        elif isinstance(sglang_args, dict):
            payload = dict(sglang_args)
            extra = payload.pop("extra_cli_args", None)
            merged_payload = asdict(SGLangArgs())
            merged_payload.update(payload)
            if extra is not None:
                merged_payload["extra_cli_args"] = extra
            self.sglang_args = SGLangArgs(**merged_payload)
        else:
            raise TypeError("sglang_args must be SGLangArgs or dict")

    def _resolve_model_name(self) -> str:
        return self.sglang_args.served_model_name or self.sglang_args.model_path

    def _wait_for_sglang(self) -> None:
        import requests

        host = self.sglang_args.host
        if host in ("0.0.0.0", "::"):
            host = "127.0.0.1"
        base_url = f"http://{host}:{self.sglang_args.port}"

        while True:
            try:
                resp = requests.get(f"{base_url}/v1/models", timeout=5)
                if resp.status_code == 200:
                    return
            except Exception:  # pragma: no cover
                pass
            time.sleep(1)

    def _do_start_sglang(self) -> Dict[str, Any]:
        cmd = ["python", "-m", "sglang.launch_server", *self.sglang_args.to_cli_args()]

        env = os.environ.copy()
        env.setdefault("PYTHONUNBUFFERED", "1")
        env.setdefault("SGLANG_LOG_LEVEL", "DEBUG")
        env.setdefault("SGLANG_TRACE_REQUEST", "1")

        proc = subprocess.Popen(cmd, env=env)
        self._wait_for_sglang()
        return {"proc": proc}

    def _start_sglang_server(self):
        global _LOCK_FILE_HANDLE

        if fcntl is None:
            return self._do_start_sglang()

        lock_file = open("/tmp/sglang_single_instance.lock", "w")
        try:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            _LOCK_FILE_HANDLE = lock_file
            terminal.detail("SGLang lock acquired, starting server")
            return self._do_start_sglang()
        except OSError:
            lock_file.close()
            terminal.detail("SGLang lock held by another worker, waiting for ready")
            self._wait_for_sglang()
            return None

    def get_invocation_commands(self, url: str) -> Tuple[str, List[str]]:
        header = "Invocation details (OpenAI-compatible API)"
        request_body = {
            "model": self._resolve_model_name(),
            "messages": [{"role": "user", "content": "你好，请介绍一下自己"}],
        }
        formatted_body = json.dumps(request_body, ensure_ascii=False, indent=2)

        chat_url = url.rstrip("/") + "/v1/chat/completions"
        commands = [
            f"curl '{chat_url}' \\",
            "  -H 'Connection: keep-alive' \\",
            "  -H 'Content-Type: application/json' \\",
        ]

        if self.authorized:
            commands.append(f"  -H 'Authorization: Bearer {self.config_context.token}' \\")

        body_lines = formatted_body.split("\n")
        commands.append(f"  -d '{body_lines[0]}")
        for line in body_lines[1:-1]:
            commands.append(f"    {line}")
        commands.append(f"    {body_lines[-1]}'")

        return header, commands

    def set_handler(self, handler: str):
        self.handler = handler

    def func(self, *args: Any, **kwargs: Any):
        pass

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        import httpx
        from fastapi import FastAPI, Request
        from starlette.background import BackgroundTask
        from starlette.responses import Response, StreamingResponse

        context = args[0] if args else None
        start_value = None
        if context is not None:
            start_value = getattr(context, "on_start_value", None)
        if start_value is None:
            start_value = self._start_sglang_server()

        proc = None
        if start_value is not None:
            proc = start_value.get("proc")

        app = FastAPI()

        host = self.sglang_args.host
        if host in ("0.0.0.0", "::"):
            host = "127.0.0.1"
        base_url = f"http://{host}:{self.sglang_args.port}"

        http_client = httpx.AsyncClient(
            base_url=base_url,
            timeout=None,
            limits=httpx.Limits(max_connections=1024, max_keepalive_connections=1024, keepalive_expiry=600),
        )

        @app.on_event("shutdown")
        async def shutdown_event():
            await http_client.aclose()

        @app.get("/health")
        async def health_check():
            if proc is not None:
                ret = proc.poll()
                if ret is not None:
                    cmd_str = " ".join(proc.args) if isinstance(proc.args, list) else str(proc.args)
                    terminal.error(f"SGLang 进程已退出 (exit_code={ret}, cmd={cmd_str})")
                    os._exit(1)
            return {"status": "ok", "worker_pid": os.getpid()}

        @app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
        async def proxy(path: str, request: Request):
            url = f"/{path}"
            if request.url.query:
                url = f"{url}?{request.url.query}"

            headers = dict(request.headers)
            headers.pop("host", None)
            body = await request.body()

            is_stream = False
            if body and request.method == "POST":
                try:
                    is_stream = json.loads(body).get("stream", False)
                except (json.JSONDecodeError, AttributeError):
                    pass

            try:
                if is_stream:
                    req = http_client.build_request(request.method, url, headers=headers, content=body)
                    resp = await http_client.send(req, stream=True)
                    response_headers = self._filtered_response_headers(dict(resp.headers))
                    return StreamingResponse(
                        resp.aiter_raw(),
                        status_code=resp.status_code,
                        headers=response_headers,
                        media_type=resp.headers.get("content-type"),
                        background=BackgroundTask(resp.aclose),
                    )

                resp = await http_client.request(request.method, url, headers=headers, content=body)
                response_headers = self._filtered_response_headers(dict(resp.headers))
                return Response(
                    content=resp.content,
                    status_code=resp.status_code,
                    headers=response_headers,
                    media_type=resp.headers.get("content-type"),
                )
            except Exception as exc:
                return Response(
                    content=json.dumps({"error": str(exc), "worker_pid": os.getpid()}).encode(),
                    status_code=502,
                    media_type="application/json",
                )

        return app

    @staticmethod
    def _filtered_response_headers(headers: Dict[str, str]) -> Dict[str, str]:
        hop_by_hop = {
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailer",
            "transfer-encoding",
            "upgrade",
            "content-length",
        }
        return {k: v for k, v in headers.items() if k.lower() not in hop_by_hop}

    def deploy(
        self,
        name: Optional[str] = None,
        context: Optional[ConfigContext] = None,
        invocation_details_func: Optional[Callable[..., None]] = None,
        **invocation_details_options: Any,
    ) -> Tuple[Dict[str, Any], bool]:
        self.name = name or self.name
        if not self.name:
            terminal.error(
                "You must specify an app name (either in the decorator or via the --name argument)."
            )

        if context is not None:
            self.config_context = context

        if not self.prepare_runtime(
            stub_type=ASGI_DEPLOYMENT_STUB_TYPE,
            force_create_stub=True,
        ):
            return {}, False

        terminal.header("Deploying")
        deploy_name = self.name or "sglang"
        deploy_response: DeployStubResponse = self.gateway_stub.deploy_stub(
            DeployStubRequest(stub_id=self.stub_id, name=deploy_name)
        )

        self.deployment_id = deploy_response.deployment_id
        if deploy_response.ok:
            terminal.header("Deployed 🎉")
            if invocation_details_func:
                invocation_details_func(**invocation_details_options)
            else:
                self.print_invocation_snippet(**invocation_details_options)

        return {
            "deployment_id": deploy_response.deployment_id,
        }, deploy_response.ok

    @with_grpc_error_handling
    def serve(self, timeout: int = 0, url_type: str = ""):
        stub_type = ASGI_SERVE_STUB_TYPE

        if not self.prepare_runtime(func=self.func, stub_type=stub_type, force_create_stub=True):
            return False

        try:
            with terminal.progress("Serving endpoint..."):
                self.print_invocation_snippet(url_type=url_type)
                return self._serve(dir=os.getcwd(), timeout=timeout)
        except KeyboardInterrupt:
            terminal.header("Stopping serve container")
            terminal.print("Goodbye 👋")
            os._exit(0)

    def _serve(self, *, dir: str, timeout: int = 0):
        r: StartEndpointServeResponse = self.endpoint_stub.start_endpoint_serve(
            StartEndpointServeRequest(
                stub_id=self.stub_id,
                timeout=timeout,
            )
        )
        if not r.ok:
            return terminal.error(r.error_msg)

        container = Container(container_id=r.container_id)
        container.attach(container_id=r.container_id, sync_dir=dir)
