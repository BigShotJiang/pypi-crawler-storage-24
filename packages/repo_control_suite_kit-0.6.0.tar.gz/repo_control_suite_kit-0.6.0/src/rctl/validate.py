from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from .catalog import selected_commands
from .merge import has_block
from .state import load_repo_state, sync_manifest_file_hashes
from .utils import read_json, read_text, read_yaml, write_json, write_text


FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)
VALID_SKILL_EVAL_TYPES = {"standard", "adversarial"}


def _load_frontmatter(path: Path) -> dict[str, Any]:
    text = read_text(path)
    match = FRONTMATTER_RE.match(text)
    if not match:
        return {}
    return yaml.safe_load(match.group(1)) or {}


def _validate_schema(data: dict[str, Any], schema_path: Path) -> list[str]:
    schema = read_json(schema_path)
    validator = jsonschema.Draft7Validator(schema)
    return sorted([error.message for error in validator.iter_errors(data)])


def _artifact_age_days(path: Path) -> float:
    stat = path.stat()
    age = datetime.now(timezone.utc).timestamp() - stat.st_mtime
    return age / 86400.0


def _section() -> dict[str, Any]:
    return {"passed": True, "checks": [], "warnings": [], "errors": []}


def _finish(section: dict[str, Any]) -> dict[str, Any]:
    section["passed"] = len(section["errors"]) == 0
    return section


def _check_structure(repo_path: Path, state: dict[str, Any]) -> dict[str, Any]:
    section = _section()
    layout = state["layout_dir"]

    required = [
        "AGENTS.md",
        f"{layout}/control-plane/control-plane.yaml",
        f"{layout}/control-plane/zones/root.zone.yaml",
        f"{layout}/schemas/change.schema.json",
        f"{layout}/registry/commands.yaml",
        f"{layout}/registry/profiles.yaml",
        f"{layout}/registry/skills.yaml",
        f"{layout}/registry/agents.yaml",
    ]
    if "claude" in state.get("agents", []):
        required.append("CLAUDE.md")

    for rel in required:
        if (repo_path / rel).exists():
            section["checks"].append(f"exists:{rel}")
        else:
            section["errors"].append(f"Missing required file: {rel}")

    schema_dir = repo_path / layout / "schemas"
    control_plane = repo_path / layout / "control-plane" / "control-plane.yaml"
    if control_plane.exists() and (schema_dir / "control-plane.schema.json").exists():
        errs = _validate_schema(read_yaml(control_plane), schema_dir / "control-plane.schema.json")
        section["errors"].extend([f"{layout}/control-plane/control-plane.yaml -> {err}" for err in errs])

    zone = repo_path / layout / "control-plane" / "zones" / "root.zone.yaml"
    if zone.exists() and (schema_dir / "zone.schema.json").exists():
        errs = _validate_schema(read_yaml(zone), schema_dir / "zone.schema.json")
        section["errors"].extend([f"{layout}/control-plane/zones/root.zone.yaml -> {err}" for err in errs])

    commands = repo_path / layout / "registry" / "commands.yaml"
    if commands.exists() and (schema_dir / "commands.schema.json").exists():
        errs = _validate_schema(read_yaml(commands), schema_dir / "commands.schema.json")
        section["errors"].extend([f"{layout}/registry/commands.yaml -> {err}" for err in errs])

    profiles = repo_path / layout / "registry" / "profiles.yaml"
    if profiles.exists() and (schema_dir / "profiles.schema.json").exists():
        errs = _validate_schema(read_yaml(profiles), schema_dir / "profiles.schema.json")
        section["errors"].extend([f"{layout}/registry/profiles.yaml -> {err}" for err in errs])

    openspec_dir = repo_path / "openspec"
    bridge_doc = repo_path / layout / "bridges" / "openspec.md"
    if openspec_dir.exists():
        if bridge_doc.exists():
            section["checks"].append("OpenSpec bridge doc exists")
        else:
            section["warnings"].append(f"openspec/ exists but {layout}/bridges/openspec.md is missing.")

    skills_root = repo_path / layout / "skills-src"
    for skill_name in state.get("selected_skills", []):
        skill_dir = skills_root / skill_name
        skill_md = skill_dir / "SKILL.md"
        evals = skill_dir / "evals" / "evals.json"
        if not skill_md.exists():
            section["errors"].append(f"Missing skill source: {skill_md.relative_to(repo_path)}")
            continue
        fm = _load_frontmatter(skill_md)
        if fm.get("name") != skill_name:
            section["errors"].append(f"Skill frontmatter name mismatch: {skill_md.relative_to(repo_path)}")
        if "description" not in fm:
            section["errors"].append(f"Skill missing description frontmatter: {skill_md.relative_to(repo_path)}")
        if not evals.exists():
            section["errors"].append(f"Skill missing evals/evals.json: {evals.relative_to(repo_path)}")
        else:
            data = read_json(evals)
            if data.get("skill_name") != skill_name:
                section["errors"].append(f"Eval skill_name mismatch: {evals.relative_to(repo_path)}")
            entries = data.get("evals")
            if not entries:
                section["warnings"].append(f"No eval prompts in {evals.relative_to(repo_path)}")
            elif not isinstance(entries, list):
                section["errors"].append(f"Eval entries must be a list in {evals.relative_to(repo_path)}")
            else:
                for idx, entry in enumerate(entries, start=1):
                    if not isinstance(entry, dict):
                        section["errors"].append(
                            f"Eval entry {idx} must be an object in {evals.relative_to(repo_path)}"
                        )
                        continue
                    prompt = entry.get("prompt")
                    if not isinstance(prompt, str) or not prompt.strip():
                        section["errors"].append(
                            f"Eval entry {idx} is missing a non-empty prompt in {evals.relative_to(repo_path)}"
                        )
                    entry_type = entry.get("type")
                    if entry_type is not None and entry_type not in VALID_SKILL_EVAL_TYPES:
                        section["errors"].append(
                            f"Eval entry {idx} has unsupported type {entry_type!r} in {evals.relative_to(repo_path)}"
                        )

    return _finish(section)


def _check_discovery(repo_path: Path, state: dict[str, Any]) -> dict[str, Any]:
    section = _section()
    layout = state["layout_dir"]

    agents_path = repo_path / "AGENTS.md"
    if not agents_path.exists():
        section["errors"].append("Missing AGENTS.md.")
    else:
        text = read_text(agents_path)
        if f"{layout}/control-plane/control-plane.yaml" in text:
            section["checks"].append("AGENTS routes to control plane")
        else:
            section["errors"].append("AGENTS.md does not mention the control-plane entrypoint.")
        if not has_block(text, "routing", style="markdown"):
            section["warnings"].append("AGENTS.md is missing the rctl managed routing block markers.")

    if "claude" in state.get("agents", []):
        claude = repo_path / "CLAUDE.md"
        if not claude.exists():
            section["errors"].append("Claude adapter selected but CLAUDE.md is missing.")
        else:
            text = read_text(claude)
            if f"{layout}/control-plane/control-plane.yaml" not in text:
                section["errors"].append("CLAUDE.md does not route to the control-plane entrypoint.")
            if not has_block(text, "routing", style="markdown"):
                section["warnings"].append("CLAUDE.md is missing the rctl managed routing block markers.")

    for skill_name in state.get("selected_skills", []):
        if "codex" in state.get("agents", []):
            if not (repo_path / ".agents" / "skills" / skill_name / "SKILL.md").exists():
                section["errors"].append(f"Codex projection missing for skill: {skill_name}")
        if "claude" in state.get("agents", []):
            if not (repo_path / ".claude" / "skills" / skill_name / "SKILL.md").exists():
                section["errors"].append(f"Claude skill projection missing for skill: {skill_name}")
        if "cursor" in state.get("agents", []):
            if not (repo_path / ".cursor" / "skills" / skill_name / "SKILL.md").exists():
                section["errors"].append(f"Cursor skill projection missing for skill: {skill_name}")
        if "windsurf" in state.get("agents", []):
            if not (repo_path / ".windsurf" / "skills" / skill_name / "SKILL.md").exists():
                section["errors"].append(f"Windsurf skill projection missing for skill: {skill_name}")

    if "cursor" in state.get("agents", []):
        rule = repo_path / ".cursor" / "rules" / "rctl-routing.mdc"
        if rule.exists():
            section["checks"].append("Cursor routing rule exists")
        else:
            section["errors"].append("Cursor adapter selected but .cursor/rules/rctl-routing.mdc is missing.")

    if "windsurf" in state.get("agents", []):
        rule = repo_path / ".windsurf" / "rules" / "rctl-routing.md"
        if rule.exists():
            section["checks"].append("Windsurf routing rule exists")
        else:
            section["errors"].append("Windsurf adapter selected but .windsurf/rules/rctl-routing.md is missing.")

    return _finish(section)


def _check_operational(repo_path: Path, state: dict[str, Any], *, smoke: bool) -> dict[str, Any]:
    section = _section()
    layout = state["layout_dir"]
    commands = selected_commands(state.get("effective_profile", state.get("profile", "core")), state.get("selected_skills"))

    registry = read_yaml(repo_path / layout / "registry" / "commands.yaml")
    registry_aliases = {item["alias"]: item["skill"] for item in registry.get("commands", [])}
    for command in commands:
        if registry_aliases.get(command["alias"]) != command["skill"]:
            section["errors"].append(f"Command registry mismatch for {command['alias']}.")

        if "claude" in state.get("agents", []):
            command_path = repo_path / ".claude" / "commands" / f"{command['alias'].replace(':', '-')}.md"
            if not command_path.exists():
                section["errors"].append(f"Claude command projection missing for {command['alias']}.")

        if "windsurf" in state.get("agents", []):
            workflow_path = repo_path / ".windsurf" / "workflows" / f"{command['alias'].replace(':', '-')}.md"
            if not workflow_path.exists():
                section["errors"].append(f"Windsurf workflow projection missing for {command['alias']}.")

    zone = read_yaml(repo_path / layout / "control-plane" / "zones" / "root.zone.yaml")
    for cmd in zone.get("validation", {}).get("commands", []):
        if "rctl validate" in cmd or "python -m rctl validate" in cmd:
            section["warnings"].append("Zone validation should prefer project-native commands; rctl validation belongs to control-plane checks.")

    active_dir = repo_path / layout / "changes" / "active"
    change_schema = repo_path / layout / "schemas" / "change.schema.json"
    change_dirs = [p for p in active_dir.iterdir() if p.is_dir()] if active_dir.exists() else []
    if not change_dirs:
        section["warnings"].append("No active change artifacts found. This is normal right after bootstrap.")
    else:
        for change_dir in change_dirs:
            required = ["change.yaml", "plan.md", "status.md", "evidence.md", "rollback.md"]
            missing = [name for name in required if not (change_dir / name).exists()]
            if missing:
                section["errors"].append(f"Active change {change_dir.name} is missing: {', '.join(missing)}")
                continue

            change_data = read_yaml(change_dir / "change.yaml")
            if change_schema.exists():
                errs = _validate_schema(change_data, change_schema)
                section["errors"].extend(
                    [f"Active change {change_dir.name} change.yaml -> {err}" for err in errs]
                )
            if "lifecycle" not in change_data:
                section["warnings"].append(
                    f"Active change {change_dir.name} change.yaml is missing lifecycle metadata."
                )

    if smoke:
        # Smoke checks are intentionally lightweight and local-only.
        if state.get("selected_skills"):
            first_skill = state["selected_skills"][0]
            if not (repo_path / layout / "skills-src" / first_skill / "SKILL.md").exists():
                section["errors"].append("Smoke check failed: first selected skill source is missing.")
            else:
                section["checks"].append("Smoke check: first selected skill source exists")
        else:
            section["warnings"].append("Smoke check skipped skill source validation because no skills were selected.")

    return _finish(section)


def _check_freshness(repo_path: Path, state: dict[str, Any]) -> dict[str, Any]:
    section = _section()
    layout = state["layout_dir"]

    validation_report = repo_path / layout / "docs" / "quality" / "validation-report.json"
    if validation_report.exists():
        age = _artifact_age_days(validation_report)
        section["checks"].append(f"validation-report-age:{round(age, 1)}d")
        if age > 30:
            section["warnings"].append("Validation report is older than 30 days.")
    else:
        section["warnings"].append("No validation-report.json artifact found yet.")

    scorecard = repo_path / layout / "docs" / "quality" / "scorecard.json"
    if scorecard.exists():
        age = _artifact_age_days(scorecard)
        section["checks"].append(f"scorecard-age:{round(age, 1)}d")
        if age > 30:
            section["warnings"].append("Scorecard is older than 30 days.")
    else:
        section["warnings"].append("No scorecard.json artifact found yet.")

    zone = read_yaml(repo_path / layout / "control-plane" / "zones" / "root.zone.yaml")
    if zone.get("bootstrap_state") == "scaffolded" and not zone.get("owners"):
        section["warnings"].append("Root zone is still in scaffolded bootstrap state with no owners assigned yet.")
    if not zone.get("canonical_terms"):
        section["warnings"].append("Root zone has no canonical terms yet.")

    return _finish(section)


def _check_enforcement(repo_path: Path, state: dict[str, Any]) -> dict[str, Any]:
    section = _section()
    layout = state["layout_dir"]

    zone = read_yaml(repo_path / layout / "control-plane" / "zones" / "root.zone.yaml")
    enforceable = zone.get("enforceable", [])
    if not enforceable:
        section["warnings"].append("No enforceable checks defined in root zone.")
        return _finish(section)

    section["checks"].append(f"enforceable-count:{len(enforceable)}")

    report_path = repo_path / layout / "docs" / "quality" / "enforce-report.json"
    if not report_path.exists():
        section["warnings"].append("No enforce report found. Run `rctl enforce . --write-artifact`.")
        return _finish(section)

    report = read_json(report_path)
    if report.get("passed"):
        section["checks"].append("enforce-report:passed")
    else:
        error_count = report.get("total_errors", 0)
        section["errors"].append(f"Last enforce report had {error_count} errors.")

    age = _artifact_age_days(report_path)
    if age > 7:
        section["warnings"].append(f"Enforce report is {round(age, 1)} days old.")

    return _finish(section)


def validate_repo(
    repo_path: Path,
    *,
    checks: list[str] | None = None,
    smoke: bool = False,
) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)
    requested = checks or ["structure", "discovery", "operational", "freshness", "enforcement"]

    sections: dict[str, Any] = {}
    if "structure" in requested:
        sections["structure"] = _check_structure(repo_path, state)
    if "discovery" in requested:
        sections["discovery"] = _check_discovery(repo_path, state)
    if "operational" in requested:
        sections["operational"] = _check_operational(repo_path, state, smoke=smoke)
    if "freshness" in requested:
        sections["freshness"] = _check_freshness(repo_path, state)
    if "enforcement" in requested:
        sections["enforcement"] = _check_enforcement(repo_path, state)

    warnings: list[str] = []
    errors: list[str] = []
    for section in sections.values():
        warnings.extend(section["warnings"])
        errors.extend(section["errors"])

    result = {
        "repo": str(repo_path),
        "layout_dir": state["layout_dir"],
        "profile": state.get("profile"),
        "agents": state.get("agents", []),
        "selected_skills": state.get("selected_skills", []),
        "checks_run": requested,
        "passed": len(errors) == 0,
        "sections": sections,
        "warnings": warnings,
        "errors": errors,
    }
    return result


def write_validation_artifact(repo_path: Path, result: dict[str, Any]) -> tuple[Path, Path]:
    repo_path = repo_path.resolve()
    layout = result["layout_dir"]
    json_path = repo_path / layout / "docs" / "quality" / "validation-report.json"
    md_path = repo_path / layout / "docs" / "quality" / "validation-report.md"
    write_json(json_path, result)

    lines = [
        "# Validation report",
        "",
        f"- passed: `{result['passed']}`",
        f"- checks run: `{', '.join(result['checks_run'])}`",
        "",
    ]
    for name, section in result["sections"].items():
        lines.extend([f"## {name}", "", f"- passed: `{section['passed']}`"])
        if section["checks"]:
            lines.append("- checks:")
            lines.extend([f"  - {item}" for item in section["checks"]])
        if section["warnings"]:
            lines.append("- warnings:")
            lines.extend([f"  - {item}" for item in section["warnings"]])
        if section["errors"]:
            lines.append("- errors:")
            lines.extend([f"  - {item}" for item in section["errors"]])
        lines.append("")
    write_text(md_path, "\n".join(lines).rstrip() + "\n")
    sync_manifest_file_hashes(repo_path, [md_path])
    return json_path, md_path
