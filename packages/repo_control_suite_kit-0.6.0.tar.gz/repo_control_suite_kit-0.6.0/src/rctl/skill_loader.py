"""Load skill content from package-bundled SKILL.md and evals.json files.

Skills are stored as standalone Markdown + JSON files under ``src/rctl/skills/``.
This module reads them at import time via :mod:`importlib.resources` and exposes
them as plain dicts that match the legacy ``catalog.SKILLS`` shape.
"""

from __future__ import annotations

import json
from importlib import resources
from typing import Any


def _read_text(skill_name: str, filename: str) -> str:
    """Read a text file from the skills package data."""
    return (
        resources.files("rctl.skills")
        .joinpath(skill_name)
        .joinpath(filename)
        .read_text(encoding="utf-8")
    )


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """Split YAML frontmatter from the markdown body.

    Returns (frontmatter_dict, body_text).  Only handles the two fields
    we care about: ``name`` and ``description``.
    """
    if not text.startswith("---"):
        return {}, text

    end = text.index("---", 3)
    raw = text[3:end].strip()
    body = text[end + 3:].lstrip("\n")

    fm: dict[str, str] = {}
    current_key = ""
    current_val_lines: list[str] = []

    for line in raw.splitlines():
        if line and not line[0].isspace() and ":" in line:
            # flush previous key
            if current_key:
                fm[current_key] = " ".join(current_val_lines).strip()
            key, _, val = line.partition(":")
            current_key = key.strip()
            current_val_lines = [val.strip()]
        else:
            current_val_lines.append(line.strip())

    if current_key:
        fm[current_key] = " ".join(current_val_lines).strip()

    return fm, body


def _skill_names() -> list[str]:
    """List all skill directories inside the package."""
    skills_root = resources.files("rctl.skills")
    return sorted(
        item.name
        for item in skills_root.iterdir()
        if item.is_dir() and not item.name.startswith("_")
    )


def load_skill(name: str) -> dict[str, Any]:
    """Load a single skill's content from its package-bundled files."""
    md_text = _read_text(name, "SKILL.md")
    fm, _body = _parse_frontmatter(md_text)

    evals_text = _read_text(name, "evals.json")
    evals_data = json.loads(evals_text)

    return {
        "name": fm.get("name", name),
        "description": fm.get("description", ""),
        "skill_md": md_text,
        "evals_json": evals_text,
        "evals": [
            entry.get("prompt", "") if isinstance(entry, dict) else entry
            for entry in evals_data.get("evals", [])
        ],
    }


def load_all_skills() -> dict[str, dict[str, Any]]:
    """Load all skills and return a name -> content mapping."""
    return {name: load_skill(name) for name in _skill_names()}
