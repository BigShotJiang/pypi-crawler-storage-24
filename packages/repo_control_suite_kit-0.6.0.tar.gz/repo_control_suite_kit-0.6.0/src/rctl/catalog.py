from __future__ import annotations

from typing import Any

AGENTS: dict[str, dict[str, Any]] = {
    "codex": {
        "label": "Codex",
        "discovery": {
            "guidance_files": ["AGENTS.md"],
            "skill_dir": ".agents/skills",
        },
    },
    "claude": {
        "label": "Claude Code",
        "discovery": {
            "guidance_files": ["CLAUDE.md"],
            "skill_dir": ".claude/skills",
            "command_dir": ".claude/commands",
        },
    },
    "cursor": {
        "label": "Cursor",
        "discovery": {
            "rule_dir": ".cursor/rules",
            "skill_dir": ".cursor/skills",
        },
    },
    "windsurf": {
        "label": "Windsurf",
        "discovery": {
            "guidance_files": ["AGENTS.md"],
            "rule_dir": ".windsurf/rules",
            "skill_dir": ".windsurf/skills",
            "workflow_dir": ".windsurf/workflows",
        },
    },
}

_SKILL_PROFILES: list[dict[str, Any]] = [
    {"name": "rctl-onboard-repo", "profiles": ["minimal", "core", "full"]},
    {"name": "rctl-map-context", "profiles": ["core", "full"]},
    {"name": "rctl-plan-change", "profiles": ["minimal", "core", "full"]},
    {"name": "rctl-implement-change", "profiles": ["minimal", "core", "full"]},
    {"name": "rctl-verify-change", "profiles": ["minimal", "core", "full"]},
    {"name": "rctl-evaluate-change", "profiles": ["core", "full"]},
    {"name": "rctl-sync-memory", "profiles": ["minimal", "core", "full"]},
    {"name": "rctl-archive-change", "profiles": ["core", "full"]},
    {"name": "rctl-permission-review", "profiles": ["core", "full"]},
    {"name": "rctl-scan-drift", "profiles": ["core", "full"]},
    {"name": "rctl-cleanup-pr", "profiles": ["full"]},
    {"name": "rctl-grade-trace", "profiles": ["full"]},
    {"name": "rctl-govern-zone", "profiles": ["full"]},
    {"name": "rctl-incident-to-learning", "profiles": ["full"]},
    {"name": "rctl-create-skill", "profiles": ["core", "full"]},
    {"name": "rctl-validate-repo", "profiles": ["minimal", "core", "full"]},
    {"name": "rctl-score-repo", "profiles": ["core", "full"]},
]

COMMANDS: list[dict[str, Any]] = [
    {"alias": "rctl:onboard", "skill": "rctl-onboard-repo", "profiles": ["minimal", "core", "full"], "summary": "Install or refresh the rctl control plane."},
    {"alias": "rctl:map", "skill": "rctl-map-context", "profiles": ["core", "full"], "summary": "Map repository zones and source-of-truth links."},
    {"alias": "rctl:plan", "skill": "rctl-plan-change", "profiles": ["minimal", "core", "full"], "summary": "Create or refresh a durable change plan."},
    {"alias": "rctl:apply", "skill": "rctl-implement-change", "profiles": ["minimal", "core", "full"], "summary": "Implement the planned change and keep status current."},
    {"alias": "rctl:verify", "skill": "rctl-verify-change", "profiles": ["minimal", "core", "full"], "summary": "Run or summarize validation evidence."},
    {"alias": "rctl:evaluate", "skill": "rctl-evaluate-change", "profiles": ["core", "full"], "summary": "Run an adversarial semantic evaluation pass."},
    {"alias": "rctl:sync", "skill": "rctl-sync-memory", "profiles": ["minimal", "core", "full"], "summary": "Write durable learnings back into the repo."},
    {"alias": "rctl:archive", "skill": "rctl-archive-change", "profiles": ["core", "full"], "summary": "Archive a completed or abandoned change."},
    {"alias": "rctl:permissions", "skill": "rctl-permission-review", "profiles": ["core", "full"], "summary": "Review trust and permission posture."},
    {"alias": "rctl:drift", "skill": "rctl-scan-drift", "profiles": ["core", "full"], "summary": "Scan for drift between repo truth and reality."},
    {"alias": "rctl:cleanup", "skill": "rctl-cleanup-pr", "profiles": ["full"], "summary": "Clean stale residue while preserving history."},
    {"alias": "rctl:grade", "skill": "rctl-grade-trace", "profiles": ["full"], "summary": "Grade a workflow trace or run."},
    {"alias": "rctl:govern", "skill": "rctl-govern-zone", "profiles": ["full"], "summary": "Harden a zone's governance surface."},
    {"alias": "rctl:incident", "skill": "rctl-incident-to-learning", "profiles": ["full"], "summary": "Turn a failure into durable learning."},
    {"alias": "rctl:skill", "skill": "rctl-create-skill", "profiles": ["core", "full"], "summary": "Create or improve a reusable skill."},
    {"alias": "rctl:validate", "skill": "rctl-validate-repo", "profiles": ["minimal", "core", "full"], "summary": "Validate rctl structure and discovery."},
    {"alias": "rctl:score", "skill": "rctl-score-repo", "profiles": ["core", "full"], "summary": "Score repository readiness honestly."},
]

PROFILES: dict[str, dict[str, Any]] = {
    "minimal": {
        "summary": "Smallest useful install: routing, active-change flow, verification, memory sync, validation.",
        "skills": [
            "rctl-onboard-repo",
            "rctl-plan-change",
            "rctl-implement-change",
            "rctl-verify-change",
            "rctl-sync-memory",
            "rctl-validate-repo",
        ],
    },
    "core": {
        "summary": "Everyday operating profile for most repositories.",
        "skills": [
            "rctl-onboard-repo",
            "rctl-map-context",
            "rctl-plan-change",
            "rctl-implement-change",
            "rctl-verify-change",
            "rctl-evaluate-change",
            "rctl-sync-memory",
            "rctl-archive-change",
            "rctl-permission-review",
            "rctl-scan-drift",
            "rctl-create-skill",
            "rctl-validate-repo",
            "rctl-score-repo",
        ],
    },
    "full": {
        "summary": "Wider governance, grading, cleanup, and incident-learning loops.",
        "skills": [
            "rctl-onboard-repo",
            "rctl-map-context",
            "rctl-plan-change",
            "rctl-implement-change",
            "rctl-verify-change",
            "rctl-evaluate-change",
            "rctl-sync-memory",
            "rctl-archive-change",
            "rctl-permission-review",
            "rctl-scan-drift",
            "rctl-cleanup-pr",
            "rctl-grade-trace",
            "rctl-govern-zone",
            "rctl-incident-to-learning",
            "rctl-create-skill",
            "rctl-validate-repo",
            "rctl-score-repo",
        ],
    },
}


def _build_skills() -> list[dict[str, Any]]:
    """Merge structural metadata with content loaded from package-bundled files."""
    from rctl.skill_loader import load_all_skills

    loaded = load_all_skills()
    merged: list[dict[str, Any]] = []
    for entry in _SKILL_PROFILES:
        skill = dict(entry)
        content = loaded.get(skill["name"], {})
        skill.update(content)
        merged.append(skill)
    return merged


SKILLS: list[dict[str, Any]] = _build_skills()


def skill_map() -> dict[str, dict[str, Any]]:
    return {item["name"]: item for item in SKILLS}


def selected_skill_names(profile: str, explicit_skills: list[str] | None = None) -> list[str]:
    if explicit_skills:
        known = set(skill_map().keys())
        names = [name for name in explicit_skills if name in known]
        return sorted(dict.fromkeys(names))
    if profile not in PROFILES:
        raise KeyError(f"Unknown profile: {profile}")
    return list(PROFILES[profile]["skills"])


def selected_skills(profile: str, explicit_skills: list[str] | None = None) -> list[dict[str, Any]]:
    mapping = skill_map()
    return [mapping[name] for name in selected_skill_names(profile, explicit_skills)]


def selected_commands(profile: str, explicit_skills: list[str] | None = None) -> list[dict[str, Any]]:
    names = set(selected_skill_names(profile, explicit_skills))
    return [item for item in COMMANDS if item["skill"] in names]


def profile_names() -> list[str]:
    return list(PROFILES.keys())


def agent_names() -> list[str]:
    return list(AGENTS.keys())
