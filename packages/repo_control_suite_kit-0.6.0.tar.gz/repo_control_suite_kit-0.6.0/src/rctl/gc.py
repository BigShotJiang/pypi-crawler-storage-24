from __future__ import annotations

import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .state import load_repo_state, manifest_path
from .utils import read_json, read_text, read_yaml, sha256_text, write_json, write_text

PROJECTION_ROOTS = {
    "codex": ".agents/skills",
    "claude": ".claude/skills",
    "cursor": ".cursor/skills",
    "windsurf": ".windsurf/skills",
}

BACKTICK_RE = re.compile(r"`([^`\n]+)`")
LINK_SUFFIXES = (".md", ".mdc", ".yaml", ".yml", ".json", ".py", ".txt")
ROOT_FILES = {"AGENTS.md", "CLAUDE.md"}
REPO_PREFIXES = (".agents/", ".claude/", ".cursor/", ".windsurf/", ".rctl/", "src/", "tests/")
QUALITY_THRESHOLDS = {
    "validation-report.json": 30,
    "scorecard.json": 30,
    "enforce-report.json": 7,
}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _isoformat(value: datetime | None = None) -> str:
    value = value or _now()
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _age_days(timestamp: datetime, *, now: datetime | None = None) -> float:
    now = now or _now()
    return (now - timestamp).total_seconds() / 86400.0


def _file_age_days(path: Path, *, now: datetime | None = None) -> float:
    timestamp = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
    return _age_days(timestamp, now=now)


def _issue(
    category: str,
    target: str,
    message: str,
    *,
    auto_fixable: bool,
    **extra: Any,
) -> dict[str, Any]:
    issue = {
        "category": category,
        "target": target,
        "message": message,
        "auto_fixable": auto_fixable,
    }
    issue.update(extra)
    return issue


def _relative(repo_path: Path, path: Path) -> str:
    return str(path.resolve().relative_to(repo_path.resolve()))


def _looks_like_repo_path(token: str, layout: str) -> bool:
    if not token or token.startswith(("/", "http://", "https://")):
        return False
    if " " in token:
        return False
    if any(marker in token for marker in ("<", ">", "{", "}")):
        return False
    if token in ROOT_FILES:
        return True
    if token.startswith((f"{layout}/", *REPO_PREFIXES)):
        return True
    return "/" in token and token.endswith(LINK_SUFFIXES)


def _load_evidence_template(repo_path: Path, layout: str) -> str:
    template = repo_path / layout / "control-plane" / "templates" / "evidence.md"
    return read_text(template).strip() if template.exists() else "# Evidence"


def _load_locked_skill_names(repo_path: Path) -> tuple[set[str], bool]:
    lock_path = repo_path / "skills-lock.json"
    if not lock_path.exists():
        return set(), True
    try:
        data = read_json(lock_path)
    except (OSError, TypeError, ValueError):
        return set(), False
    skills = data.get("skills", {}) if isinstance(data, dict) else {}
    if not isinstance(skills, dict):
        return set(), False
    return {name for name in skills if isinstance(name, str)}, True


def check_stale_changes(
    repo_path: Path,
    layout: str,
    zone_data: dict[str, Any],
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    repo_path = repo_path.resolve()
    active_dir = repo_path / layout / "changes" / "active"
    threshold = zone_data.get("cleanup", {}).get("stale_active_change_after_days", 14)
    issues: list[dict[str, Any]] = []
    if not active_dir.exists():
        return issues

    for change_dir in sorted(p for p in active_dir.iterdir() if p.is_dir()):
        change_path = change_dir / "change.yaml"
        if not change_path.exists():
            continue
        change_data = read_yaml(change_path)
        updated_at = _parse_timestamp(change_data.get("lifecycle", {}).get("updated_at"))
        age = _age_days(updated_at, now=now) if updated_at else _file_age_days(change_path, now=now)
        if age > threshold:
            issues.append(
                _issue(
                    "stale",
                    _relative(repo_path, change_dir),
                    f"Last updated {int(age)} days ago (threshold: {threshold})",
                    auto_fixable=False,
                )
            )
    return issues


def check_orphan_projections(repo_path: Path, state: dict[str, Any]) -> list[dict[str, Any]]:
    repo_path = repo_path.resolve()
    canonical_root = repo_path / state["layout_dir"] / "skills-src"
    canonical_names = {path.name for path in canonical_root.iterdir() if path.is_dir()} if canonical_root.exists() else set()
    locked_skill_names, lockfile_valid = _load_locked_skill_names(repo_path)
    issues: list[dict[str, Any]] = []
    seen_resolved: set[Path] = set()

    for agent in state.get("agents", []):
        projection_root_rel = PROJECTION_ROOTS.get(agent)
        if projection_root_rel is None:
            continue
        projection_root = repo_path / projection_root_rel
        if not projection_root.exists():
            continue
        for skill_dir in sorted(p for p in projection_root.iterdir() if p.is_dir()):
            resolved = skill_dir.resolve()
            if resolved in seen_resolved:
                continue
            seen_resolved.add(resolved)

            if skill_dir.name in canonical_names:
                origin = "canonical"
            elif skill_dir.name in locked_skill_names:
                origin = "locked-external"
            else:
                origin = "unknown"

            if origin == "unknown":
                auto_fixable = lockfile_valid
                message = (
                    f"No canonical source in {state['layout_dir']}/skills-src/ and not tracked in skills-lock.json."
                    if lockfile_valid
                    else f"No canonical source in {state['layout_dir']}/skills-src/. Unable to read skills-lock.json, so auto-fix is disabled."
                )
                issues.append(
                    _issue(
                        "orphan",
                        _relative(repo_path, skill_dir),
                        message,
                        auto_fixable=auto_fixable,
                        origin=origin,
                    )
                )
    return issues


def check_freshness(repo_path: Path, layout: str, *, now: datetime | None = None) -> list[dict[str, Any]]:
    repo_path = repo_path.resolve()
    quality_dir = repo_path / layout / "docs" / "quality"
    issues: list[dict[str, Any]] = []

    for filename, threshold in QUALITY_THRESHOLDS.items():
        path = quality_dir / filename
        if not path.exists():
            continue
        age = _file_age_days(path, now=now)
        if age > threshold:
            issues.append(
                _issue(
                    "freshness",
                    _relative(repo_path, path),
                    f"Artifact is {int(age)} days old (threshold: {threshold})",
                    auto_fixable=False,
                )
            )
    return issues


def check_missing_evidence(repo_path: Path, layout: str) -> list[dict[str, Any]]:
    repo_path = repo_path.resolve()
    active_dir = repo_path / layout / "changes" / "active"
    issues: list[dict[str, Any]] = []
    if not active_dir.exists():
        return issues

    template = _load_evidence_template(repo_path, layout)
    for change_dir in sorted(p for p in active_dir.iterdir() if p.is_dir()):
        evidence_path = change_dir / "evidence.md"
        if not evidence_path.exists():
            issues.append(
                _issue(
                    "evidence",
                    _relative(repo_path, change_dir),
                    "Evidence file is missing.",
                    auto_fixable=False,
                )
            )
            continue
        if read_text(evidence_path).strip() == template:
            issues.append(
                _issue(
                    "evidence",
                    _relative(repo_path, evidence_path),
                    "Evidence file still matches the empty template.",
                    auto_fixable=False,
                )
            )
    return issues


def check_crosslink_integrity(repo_path: Path, layout: str) -> list[dict[str, Any]]:
    repo_path = repo_path.resolve()
    issues: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    for rel in ("AGENTS.md", "CLAUDE.md"):
        path = repo_path / rel
        if not path.exists():
            continue
        for token in BACKTICK_RE.findall(read_text(path)):
            if not _looks_like_repo_path(token, layout):
                continue
            key = (rel, token)
            if key in seen:
                continue
            seen.add(key)
            if not (repo_path / token).exists():
                issues.append(
                    _issue(
                        "crosslink",
                        f"{rel}:{token}",
                        f"Referenced path `{token}` does not exist.",
                        auto_fixable=False,
                    )
                )
    return issues


def check_manifest_drift(repo_path: Path) -> list[dict[str, Any]]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)
    issues: list[dict[str, Any]] = []

    for rel, entry in sorted(state.get("managed_files", {}).items()):
        target = repo_path / rel
        expected = entry.get("sha256") if isinstance(entry, dict) else None
        if not target.exists():
            issues.append(
                _issue(
                    "manifest-drift",
                    rel,
                    "Managed file is missing from the working tree.",
                    auto_fixable=False,
                )
            )
            continue
        current = sha256_text(read_text(target))
        if expected and current != expected:
            issues.append(
                _issue(
                    "manifest-drift",
                    rel,
                    "Manifest hash differs from current file content.",
                    auto_fixable=True,
                )
            )
    return issues


def gc_repo(
    repo_path: Path,
    *,
    fix: bool = False,
    now: datetime | None = None,
) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)
    layout = state["layout_dir"]
    zone_data = read_yaml(repo_path / layout / "control-plane" / "zones" / "root.zone.yaml")

    issues = _collect_issues(repo_path, state, zone_data, now=now)
    fixed = _apply_fixes(repo_path, issues) if fix else []
    if fix:
        state = load_repo_state(repo_path)
        zone_data = read_yaml(repo_path / layout / "control-plane" / "zones" / "root.zone.yaml")
        issues = _collect_issues(repo_path, state, zone_data, now=now)

    return {
        "repo": str(repo_path),
        "issues": issues,
        "total_issues": len(issues),
        "auto_fixable": sum(1 for item in issues if item["auto_fixable"]),
        "fixed_issues": len(fixed),
        "fix": fix,
    }


def _collect_issues(
    repo_path: Path,
    state: dict[str, Any],
    zone_data: dict[str, Any],
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    layout = state["layout_dir"]
    issues: list[dict[str, Any]] = []
    issues.extend(check_stale_changes(repo_path, layout, zone_data, now=now))
    issues.extend(check_orphan_projections(repo_path, state))
    issues.extend(check_freshness(repo_path, layout, now=now))
    issues.extend(check_missing_evidence(repo_path, layout))
    issues.extend(check_crosslink_integrity(repo_path, layout))
    issues.extend(check_manifest_drift(repo_path))
    return issues


def _apply_fixes(repo_path: Path, issues: list[dict[str, Any]]) -> list[str]:
    repo_path = repo_path.resolve()
    applied: list[str] = []
    orphan_targets = [
        item["target"]
        for item in issues
        if item["category"] == "orphan" and item["auto_fixable"] and item.get("origin", "unknown") == "unknown"
    ]
    for target in orphan_targets:
        path = repo_path / target
        if path.exists():
            shutil.rmtree(path)
            applied.append(target)

    drift_targets = [item["target"] for item in issues if item["category"] == "manifest-drift" and item["auto_fixable"]]
    if drift_targets:
        manifest_file = manifest_path(repo_path)
        manifest = read_json(manifest_file)
        managed_files = manifest.get("managed_files", {})
        for rel in drift_targets:
            target = repo_path / rel
            if target.exists() and rel in managed_files:
                managed_files[rel]["sha256"] = sha256_text(read_text(target))
                applied.append(rel)
        manifest["updated_at"] = _isoformat()
        write_json(manifest_file, manifest)

    return applied


def write_gc_artifact(repo_path: Path, result: dict[str, Any]) -> tuple[Path, Path]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)
    layout = state["layout_dir"]
    json_path = repo_path / layout / "docs" / "quality" / "gc-report.json"
    md_path = repo_path / layout / "docs" / "quality" / "gc-report.md"
    write_json(json_path, result)

    lines = [
        "# GC report",
        "",
        f"- total_issues: `{result['total_issues']}`",
        f"- auto_fixable: `{result['auto_fixable']}`",
        f"- fixed_issues: `{result.get('fixed_issues', 0)}`",
        f"- mode: `{'fix' if result.get('fix') else 'dry-run'}`",
        "",
    ]
    if result["issues"]:
        for item in result["issues"]:
            lines.append(
                f"- [{item['category']}] `{item['target']}`: {item['message']} (auto_fixable={item['auto_fixable']})"
            )
    else:
        lines.append("- No gc issues found.")
    lines.append("")

    write_text(md_path, "\n".join(lines))
    return json_path, md_path


def format_gc_text(result: dict[str, Any]) -> str:
    if not result["issues"]:
        return f"No GC issues found.\n\nMode: {'fix' if result.get('fix') else 'dry-run'}"

    lines = ["GC issues:"]
    for item in result["issues"]:
        fixable = "fixable" if item["auto_fixable"] else "manual"
        lines.append(f"- [{item['category']}] {item['target']}: {item['message']} ({fixable})")
    lines.extend(
        [
            "",
            f"Total issues: {result['total_issues']}",
            f"Auto-fixable: {result['auto_fixable']}",
            f"Mode: {'fix' if result.get('fix') else 'dry-run'}",
        ]
    )
    if result.get("fix"):
        lines.append(f"Fixed issues: {result.get('fixed_issues', 0)}")
    return "\n".join(lines)
