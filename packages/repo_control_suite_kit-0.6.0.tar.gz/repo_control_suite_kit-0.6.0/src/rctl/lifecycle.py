from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .state import load_repo_state
from .utils import read_yaml, write_yaml

ARTIFACT_KEYS = ("plan", "implementation", "verification", "rollback")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _isoformat(value: datetime | None = None) -> str:
    value = value or _now()
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _updated_ago(value: str | None, *, now: datetime | None = None) -> str:
    timestamp = _parse_timestamp(value)
    if timestamp is None:
        return "unknown"
    now = now or _now()
    seconds = max(0, int((now - timestamp).total_seconds()))
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m"
    if seconds < 86400:
        return f"{seconds // 3600}h"
    return f"{seconds // 86400}d"


def _stale_threshold_days(repo_path: Path) -> int:
    state = load_repo_state(repo_path)
    zone = read_yaml(repo_path / state["layout_dir"] / "control-plane" / "zones" / "root.zone.yaml")
    return zone.get("cleanup", {}).get("stale_active_change_after_days", 14)


def _is_stale(value: str | None, threshold_days: int, *, now: datetime | None = None) -> bool:
    timestamp = _parse_timestamp(value)
    if timestamp is None:
        return False
    now = now or _now()
    return (now - timestamp).total_seconds() > threshold_days * 86400


def load_change(repo_path: Path, change_id: str) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)
    layout = state["layout_dir"]
    for bucket in ("active", "archive"):
        change_path = repo_path / layout / "changes" / bucket / change_id / "change.yaml"
        if change_path.exists():
            data = read_yaml(change_path)
            data["_bucket"] = bucket
            data["_path"] = str(change_path)
            return data
    raise FileNotFoundError(f"Change not found: {change_id}")


def _normalized_artifacts(artifacts: dict[str, Any] | None) -> dict[str, Any]:
    normalized = {key: "pending" for key in ARTIFACT_KEYS}
    if artifacts:
        normalized.update(artifacts)
    return normalized


def compute_next(change: dict[str, Any]) -> dict[str, Any]:
    lifecycle = change.get("lifecycle") or {}
    artifacts = _normalized_artifacts(lifecycle.get("artifacts"))
    phase = lifecycle.get("phase", "planning") or "planning"

    if artifacts.get("plan") in ("pending", None):
        suggestion = "Create a plan first. Run /rctl-plan."
        suggested_command = "/rctl-plan"
    elif phase == "planning" and artifacts.get("plan") == "done":
        suggestion = "Plan is ready. Start implementing. Run /rctl-apply."
        suggested_command = "/rctl-apply"
    elif phase == "implementing" and artifacts.get("implementation") == "done":
        suggestion = "Implementation complete. Verify the change. Run /rctl-verify."
        suggested_command = "/rctl-verify"
    elif phase == "verifying" and artifacts.get("verification") == "done":
        suggestion = "Verification passed. Archive the change. Run /rctl-archive."
        suggested_command = "/rctl-archive"
    elif artifacts.get("rollback") == "pending" and artifacts.get("implementation") != "pending":
        suggestion = "Rollback notes are missing. Document rollback steps in rollback.md."
        suggested_command = None
    else:
        suggestion = f"Continue {phase}."
        suggested_command = None

    return {
        "current_phase": phase,
        "artifacts": artifacts,
        "suggestion": suggestion,
        "suggested_command": suggested_command,
    }


def change_status(
    repo_path: Path,
    change_id: str,
    *,
    check_stale: bool = False,
    now: datetime | None = None,
) -> dict[str, Any]:
    data = load_change(repo_path, change_id)
    lifecycle = data.get("lifecycle", {})
    updated_at = lifecycle.get("updated_at")
    threshold = _stale_threshold_days(repo_path)
    stale = check_stale and data.get("status") == "active" and _is_stale(updated_at, threshold, now=now)
    return {
        "change_id": data.get("change_id", change_id),
        "title": data.get("title", ""),
        "status": data.get("status", "planned"),
        "phase": lifecycle.get("phase", "unknown"),
        "updated_at": updated_at,
        "updated_ago": _updated_ago(updated_at, now=now),
        "artifacts": lifecycle.get("artifacts", {}),
        "next_step": lifecycle.get("next_step", "Lifecycle metadata missing. Add lifecycle to change.yaml."),
        "stale": stale,
    }


def next_change(
    repo_path: Path,
    change_id: str,
    *,
    update: bool = False,
    now: datetime | None = None,
) -> dict[str, Any]:
    data = load_change(repo_path, change_id)
    result = compute_next(data)
    response = {
        "change_id": data.get("change_id", change_id),
        "current_phase": result["current_phase"],
        "suggestion": result["suggestion"],
        "suggested_command": result["suggested_command"],
        "updated": False,
    }

    if not update:
        return response

    timestamp = _isoformat(now)
    lifecycle = data.setdefault("lifecycle", {})
    lifecycle.setdefault("phase", result["current_phase"])
    lifecycle.setdefault("started_at", lifecycle.get("updated_at") or timestamp)
    lifecycle["updated_at"] = timestamp
    lifecycle["next_step"] = result["suggestion"]
    artifacts = lifecycle.setdefault("artifacts", {})
    for key, value in result["artifacts"].items():
        artifacts.setdefault(key, value)
    stored = {key: value for key, value in data.items() if not key.startswith("_")}
    write_yaml(Path(data["_path"]), stored)

    response["updated"] = True
    response["updated_at"] = timestamp
    return response


def list_active_changes(
    repo_path: Path,
    *,
    check_stale: bool = False,
    now: datetime | None = None,
) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)
    active_dir = repo_path / state["layout_dir"] / "changes" / "active"
    entries: list[dict[str, Any]] = []
    if active_dir.exists():
        for change_dir in sorted(p for p in active_dir.iterdir() if p.is_dir()):
            entry = change_status(repo_path, change_dir.name, check_stale=check_stale, now=now)
            entries.append(
                {
                    "change_id": entry["change_id"],
                    "phase": entry["phase"],
                    "updated_ago": entry["updated_ago"],
                    "stale": entry["stale"],
                }
            )
    return {"active_changes": entries, "stale_count": sum(1 for entry in entries if entry["stale"])}


def format_status_text(result: dict[str, Any]) -> str:
    if "active_changes" in result:
        lines = ["Active changes:"]
        for item in result["active_changes"]:
            lines.append(f"  {item['change_id']:<18} {item['phase']:<13} {item['updated_ago']} ago")
        if not result["active_changes"]:
            lines.append("  (none)")
        lines.append("")
        if result["stale_count"]:
            lines.append(f"Stale changes: {result['stale_count']}.")
        else:
            lines.append("No stale changes.")
        return "\n".join(lines)

    lines = [
        f"Change:      {result['change_id']}",
        f"Title:       {result['title']}",
        f"Phase:       {result['phase']}",
        f"Updated:     {result['updated_ago']} ago",
        "",
    ]
    for key in ("plan", "implementation", "verification", "rollback"):
        if key in result["artifacts"]:
            lines.append(f"  {key:<15} {result['artifacts'][key]}")
    lines.extend(["", f"Next step:   {result['next_step']}"])
    return "\n".join(lines)


def format_next_text(result: dict[str, Any]) -> str:
    if result["updated"]:
        return f'Updated {result["change_id"]} next_step: "{result["suggestion"]}"'
    return result["suggestion"]
