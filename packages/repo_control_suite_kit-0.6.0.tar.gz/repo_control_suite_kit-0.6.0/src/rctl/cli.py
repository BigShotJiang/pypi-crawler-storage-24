from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .bootstrap import init_repo, update_repo
from .catalog import agent_names, profile_names
from .enforce import enforce_repo, format_enforce_text, write_enforce_artifact
from .gc import format_gc_text, gc_repo, write_gc_artifact
from .lifecycle import change_status, format_next_text, format_status_text, list_active_changes, next_change
from .score import format_score_markdown, score_repo, write_score_artifact
from .validate import validate_repo, write_validation_artifact


def _prompt_agents() -> str:
    available = ", ".join(agent_names())
    default = "codex,claude"
    value = input(f"Select agents [{default}] ({available}): ").strip()
    return value or default


def _prompt_profile() -> str:
    available = ", ".join(profile_names())
    default = "core"
    value = input(f"Select profile [{default}] ({available} or custom): ").strip()
    return value or default


def _prompt_skills() -> str | None:
    value = input("Custom skills (comma separated, blank for none): ").strip()
    return value or None


def _print_text_summary(title: str, data: dict) -> None:
    print(title)
    for key, value in data.items():
        if isinstance(value, dict):
            print(f"- {key}:")
            for sub_key, sub_value in value.items():
                print(f"  - {sub_key}: {sub_value}")
        else:
            print(f"- {key}: {value}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="rctl", description="Repo Control Suite CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_p = subparsers.add_parser("init", help="Install the rctl control plane into a repository")
    init_p.add_argument("path", type=Path)
    init_p.add_argument("--stack", default="auto", choices=["auto", "generic", "python", "node", "go", "rust", "java"])
    init_p.add_argument("--profile", default=None)
    init_p.add_argument("--skills", default=None)
    init_p.add_argument("--agents", default=None)
    init_p.add_argument("--ci", choices=["github-actions"], default=None)
    init_p.add_argument("--hooks", choices=["pre-commit"], default=None)
    init_p.add_argument("--layout-dir", default="rctl")
    init_p.add_argument("--repo-name", default=None)
    init_p.add_argument("--force", action="store_true")
    init_p.add_argument("--yes", action="store_true")
    init_p.add_argument("--format", default="json", choices=["json", "text"])

    update_p = subparsers.add_parser("update", help="Refresh rctl-managed files")
    update_p.add_argument("path", type=Path)
    update_p.add_argument("--force", action="store_true")
    update_p.add_argument("--format", default="json", choices=["json", "text"])

    validate_p = subparsers.add_parser("validate", help="Validate an installed control plane")
    validate_p.add_argument("path", nargs="?", type=Path, default=Path("."))
    validate_p.add_argument("--check", action="append", choices=["structure", "discovery", "operational", "freshness", "enforcement"])
    validate_p.add_argument("--smoke", action="store_true")
    validate_p.add_argument("--write-artifact", action="store_true")
    validate_p.add_argument("--format", default="json", choices=["json", "text"])

    score_p = subparsers.add_parser("score", help="Score repository readiness")
    score_p.add_argument("path", nargs="?", type=Path, default=Path("."))
    score_p.add_argument("--write-artifact", action="store_true")
    score_p.add_argument("--format", default="json", choices=["json", "markdown"])

    enforce_p = subparsers.add_parser("enforce", help="Run enforceable zone checks")
    enforce_p.add_argument("path", nargs="?", type=Path, default=Path("."))
    enforce_p.add_argument("--zone")
    enforce_p.add_argument("--severity", choices=["error", "warning"])
    enforce_p.add_argument("--dry-run", action="store_true")
    enforce_p.add_argument("--ci", action="store_true")
    enforce_p.add_argument("--write-artifact", action="store_true")
    enforce_p.add_argument("--timeout", type=int, default=60)
    enforce_p.add_argument("--format", default="json", choices=["json", "text"])

    gc_p = subparsers.add_parser("gc", help="Detect and optionally clean up repository entropy")
    gc_p.add_argument("path", type=Path)
    mode = gc_p.add_mutually_exclusive_group()
    mode.add_argument("--fix", action="store_true")
    mode.add_argument("--dry-run", action="store_true")
    gc_p.add_argument("--write-artifact", action="store_true")
    gc_p.add_argument("--format", default="json", choices=["json", "text"])

    status_p = subparsers.add_parser("status", help="Show active change lifecycle state")
    status_p.add_argument("path", nargs="?", type=Path, default=Path("."))
    status_p.add_argument("change_id", nargs="?")
    status_p.add_argument("--check-stale", action="store_true")
    status_p.add_argument("--format", default="json", choices=["json", "text"])

    next_p = subparsers.add_parser("next", help="Suggest the next lifecycle step for a change")
    next_p.add_argument("path", type=Path)
    next_p.add_argument("change_id")
    next_p.add_argument("--update", action="store_true")
    next_p.add_argument("--format", default="json", choices=["json", "text"])

    args = parser.parse_args(argv)

    if args.command == "init":
        profile = args.profile
        agents = args.agents
        skills = args.skills

        if not args.yes and sys.stdin.isatty():
            if profile is None:
                profile = _prompt_profile()
            if agents is None:
                agents = _prompt_agents()
            if profile == "custom" and skills is None:
                skills = _prompt_skills()

        profile = profile or "core"
        if profile == "custom" and not skills:
            parser.error("`--profile custom` requires `--skills` (or interactive skill input).")

        result = init_repo(
            args.path,
            repo_name=args.repo_name,
            stack=args.stack,
            profile=profile,
            agents=agents,
            ci=args.ci,
            hooks=args.hooks,
            layout_dir=args.layout_dir,
            explicit_skills=skills,
            force=args.force,
        )
        if args.format == "json":
            print(json.dumps(result, indent=2))
        else:
            _print_text_summary("rctl init", result)
        return 0

    if args.command == "update":
        result = update_repo(args.path, force=args.force)
        if args.format == "json":
            print(json.dumps(result, indent=2))
        else:
            _print_text_summary("rctl update", result)
        return 0

    if args.command == "validate":
        result = validate_repo(args.path, checks=args.check, smoke=args.smoke)
        if args.write_artifact:
            json_path, md_path = write_validation_artifact(args.path, result)
            result["artifact_paths"] = {"json": str(json_path), "markdown": str(md_path)}
        if args.format == "json":
            print(json.dumps(result, indent=2))
        else:
            print(f"passed={result['passed']}")
            for name, section in result["sections"].items():
                print(f"[{name}] passed={section['passed']}")
                for item in section["warnings"]:
                    print(f"  warning: {item}")
                for item in section["errors"]:
                    print(f"  error: {item}")
        return 0 if result["passed"] else 1

    if args.command == "score":
        result = score_repo(args.path)
        if args.write_artifact:
            json_path, md_path = write_score_artifact(args.path, result)
            result["artifact_paths"] = {"json": str(json_path), "markdown": str(md_path)}
        if args.format == "markdown":
            print(format_score_markdown(result))
        else:
            print(json.dumps(result, indent=2))
        return 0

    if args.command == "enforce":
        result = enforce_repo(args.path, zone_id=args.zone, severity=args.severity, timeout=args.timeout)
        if args.write_artifact:
            json_path, md_path = write_enforce_artifact(args.path, result)
            result["artifact_paths"] = {"json": str(json_path), "markdown": str(md_path)}
        if args.format == "json":
            print(json.dumps(result, indent=2))
        else:
            print(format_enforce_text(result))
        return 1 if args.ci and result["total_errors"] > 0 else 0

    if args.command == "gc":
        result = gc_repo(args.path, fix=args.fix)
        if args.write_artifact:
            json_path, md_path = write_gc_artifact(args.path, result)
            result["artifact_paths"] = {"json": str(json_path), "markdown": str(md_path)}
        if args.format == "json":
            print(json.dumps(result, indent=2))
        else:
            print(format_gc_text(result))
        return 1 if result["total_issues"] > 0 else 0

    if args.command == "status":
        try:
            result = (
                change_status(args.path, args.change_id, check_stale=args.check_stale)
                if args.change_id
                else list_active_changes(args.path, check_stale=args.check_stale)
            )
        except FileNotFoundError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        if args.format == "json":
            print(json.dumps(result, indent=2))
        else:
            print(format_status_text(result))
        return 0

    if args.command == "next":
        try:
            result = next_change(args.path, args.change_id, update=args.update)
        except FileNotFoundError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        if args.format == "json":
            print(json.dumps(result, indent=2))
        else:
            print(format_next_text(result))
        return 0

    return 2
