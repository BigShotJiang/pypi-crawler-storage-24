from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from .state import load_repo_state
from .utils import read_yaml, write_json, write_text


def _evaluate_check(check: dict[str, Any], returncode: int | None, stdout: str, *, timed_out: bool) -> bool:
    if timed_out:
        return False

    expect = check.get("expect", "exit_zero")
    if expect == "exit_zero":
        return returncode == 0
    if expect == "exit_nonzero":
        return returncode != 0
    if expect == "output_empty":
        return stdout.strip() == ""
    if expect == "output_match":
        pattern = check.get("pattern", "")
        return bool(pattern) and bool(re.search(pattern, stdout))
    return False


def _build_env() -> dict[str, str] | None:
    """Propagate the running Python's venv to subprocesses."""
    venv = sys.prefix
    if venv == sys.base_prefix:
        return None  # not in a venv
    env = os.environ.copy()
    venv_bin = str(Path(venv) / "bin")
    path = env.get("PATH", "")
    if venv_bin not in path.split(os.pathsep):
        env["PATH"] = venv_bin + os.pathsep + path
    env["VIRTUAL_ENV"] = venv
    return env


def run_check(repo_path: Path, check: dict[str, Any], *, timeout: float = 60) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    started = time.perf_counter()
    timed_out = False
    stdout = ""
    stderr = ""
    returncode: int | None = None
    env = _build_env()

    try:
        completed = subprocess.run(
            check["check"],
            cwd=repo_path,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
        )
        stdout = completed.stdout
        stderr = completed.stderr
        returncode = completed.returncode
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""

    duration_ms = round((time.perf_counter() - started) * 1000)
    passed = _evaluate_check(check, returncode, stdout, timed_out=timed_out)
    message = check.get("message", "")
    if timed_out:
        message = f"{message} (timed out after {timeout}s)".strip()

    return {
        "id": check["id"],
        "passed": passed,
        "severity": check.get("severity", "error"),
        "message": message,
        "expect": check.get("expect"),
        "pattern": check.get("pattern"),
        "stdout": stdout,
        "stderr": stderr,
        "returncode": returncode,
        "timed_out": timed_out,
        "duration_ms": duration_ms,
    }


def enforce_zone(
    repo_path: Path,
    zone_data: dict[str, Any],
    *,
    severity: str | None = None,
    timeout: float = 60,
) -> dict[str, Any]:
    checks = zone_data.get("enforceable")
    if checks is None:
        return {
            "zone_id": zone_data.get("id", "unknown"),
            "checks": [],
            "passed": True,
            "error_count": 0,
            "warning_count": 0,
            "warnings": [f"Zone {zone_data.get('id', 'unknown')} has no enforceable checks."],
        }

    filtered = [check for check in checks if severity is None or check.get("severity") == severity]
    if not filtered:
        return {
            "zone_id": zone_data.get("id", "unknown"),
            "checks": [],
            "passed": True,
            "error_count": 0,
            "warning_count": 0,
            "warnings": [f"Zone {zone_data.get('id', 'unknown')} has no enforceable checks."],
        }

    results = [run_check(repo_path, check, timeout=timeout) for check in filtered]
    error_count = sum(1 for item in results if not item["passed"] and item["severity"] == "error")
    warning_count = sum(1 for item in results if not item["passed"] and item["severity"] == "warning")
    return {
        "zone_id": zone_data.get("id", "unknown"),
        "checks": results,
        "passed": error_count == 0,
        "error_count": error_count,
        "warning_count": warning_count,
        "warnings": [],
    }


def enforce_repo(
    repo_path: Path,
    *,
    zone_id: str | None = None,
    severity: str | None = None,
    timeout: float = 60,
) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)
    zones_dir = repo_path / state["layout_dir"] / "control-plane" / "zones"
    zone_paths = sorted(zones_dir.glob("*.yaml"))
    zones: list[dict[str, Any]] = []
    warnings: list[str] = []

    for path in zone_paths:
        zone_data = read_yaml(path)
        if zone_id is not None and zone_data.get("id") != zone_id:
            continue
        zone_result = enforce_zone(repo_path, zone_data, severity=severity, timeout=timeout)
        warnings.extend(zone_result.get("warnings", []))
        zones.append(zone_result)

    total_checks = sum(len(zone["checks"]) for zone in zones)
    total_errors = sum(zone["error_count"] for zone in zones)
    total_warnings = sum(zone["warning_count"] for zone in zones)
    return {
        "repo": str(repo_path),
        "zones": zones,
        "warnings": warnings,
        "passed": total_errors == 0,
        "total_checks": total_checks,
        "total_errors": total_errors,
        "total_warnings": total_warnings,
    }


def write_enforce_artifact(repo_path: Path, result: dict[str, Any]) -> tuple[Path, Path]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)
    layout = state["layout_dir"]
    json_path = repo_path / layout / "docs" / "quality" / "enforce-report.json"
    md_path = repo_path / layout / "docs" / "quality" / "enforce-report.md"
    write_json(json_path, result)

    lines = [
        "# Enforce report",
        "",
        f"- passed: `{result['passed']}`",
        f"- total_checks: `{result['total_checks']}`",
        f"- total_errors: `{result['total_errors']}`",
        f"- total_warnings: `{result['total_warnings']}`",
        "",
    ]
    for zone in result["zones"]:
        lines.extend(
            [
                f"## {zone['zone_id']}",
                "",
                f"- passed: `{zone['passed']}`",
                f"- error_count: `{zone['error_count']}`",
                f"- warning_count: `{zone['warning_count']}`",
            ]
        )
        for item in zone["checks"]:
            lines.append(
                f"- {item['id']}: `{'PASS' if item['passed'] else item['severity'].upper()}` ({item['duration_ms']}ms)"
            )
        if zone.get("warnings"):
            for warning in zone["warnings"]:
                lines.append(f"- warning: {warning}")
        lines.append("")
    if result.get("warnings"):
        lines.append("## Warnings")
        lines.append("")
        for warning in result["warnings"]:
            lines.append(f"- {warning}")
        lines.append("")

    write_text(md_path, "\n".join(lines).rstrip() + "\n")
    return json_path, md_path


def format_enforce_text(result: dict[str, Any]) -> str:
    lines: list[str] = []
    for zone in result["zones"]:
        for item in zone["checks"]:
            status = "PASS" if item["passed"] else ("WARN" if item["severity"] == "warning" else "FAIL")
            suffix = f"  {item['message']}" if not item["passed"] and item.get("message") else ""
            lines.append(
                f"[{zone['zone_id']}] {item['id']:<24} {status:<4} ({item['duration_ms'] / 1000:.1f}s){suffix}"
            )
        for warning in zone.get("warnings", []):
            lines.append(f"[{zone['zone_id']}] warning                 WARN  {warning}")
    if result.get("warnings"):
        for warning in result["warnings"]:
            lines.append(f"[repo] warning                 WARN  {warning}")
    lines.extend(
        [
            "",
            f"Enforced: {result['total_checks']} checks ({result['total_checks'] - result['total_errors'] - result['total_warnings']} passed, {result['total_errors']} errors, {result['total_warnings']} warnings)",
        ]
    )
    return "\n".join(lines)
