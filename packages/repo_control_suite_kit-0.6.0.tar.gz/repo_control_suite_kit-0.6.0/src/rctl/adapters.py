from __future__ import annotations

from pathlib import Path


STACK_MARKERS: list[tuple[str, tuple[str, ...]]] = [
    ("python", ("pyproject.toml", "requirements.txt", "setup.py")),
    ("node", ("package.json", "pnpm-lock.yaml", "yarn.lock")),
    ("go", ("go.mod",)),
    ("rust", ("Cargo.toml",)),
    ("java", ("pom.xml", "build.gradle", "build.gradle.kts")),
]


def detect_stack(repo_path: Path) -> str:
    for stack, markers in STACK_MARKERS:
        if any((repo_path / marker).exists() for marker in markers):
            return stack
    return "generic"


def default_validation_commands(stack: str) -> list[str]:
    mapping = {
        "python": ["pytest -q"],
        "node": ["npm test", "npm run lint --if-present"],
        "go": ["go test ./..."],
        "rust": ["cargo test", "cargo fmt --check"],
        "java": ["./gradlew test"],
        "generic": [],
    }
    return mapping.get(stack, mapping["generic"])


def default_zone_paths(stack: str) -> list[str]:
    mapping = {
        "python": [".", "src/", "tests/"],
        "node": [".", "src/", "test/", "tests/"],
        "go": [".", "cmd/", "internal/", "pkg/"],
        "rust": [".", "src/", "tests/"],
        "java": [".", "src/main/", "src/test/"],
        "generic": ["."],
    }
    return mapping.get(stack, mapping["generic"])


def stack_summary(stack: str) -> str:
    mapping = {
        "python": "Python repository",
        "node": "Node / JavaScript / TypeScript repository",
        "go": "Go repository",
        "rust": "Rust repository",
        "java": "Java / JVM repository",
        "generic": "Generic repository",
    }
    return mapping.get(stack, "Generic repository")
