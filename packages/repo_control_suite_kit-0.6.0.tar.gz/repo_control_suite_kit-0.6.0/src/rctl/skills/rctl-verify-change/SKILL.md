---
name: rctl-verify-change
description: Verify a change by running zone validation commands and recording durable
  evidence. Without this skill, agents run tests, see them pass, and say "tests pass"
  without leaving any reviewable record. Use when code has changed and the user wants
  proof that tests pass, lint is clean, and acceptance criteria are met. Also use when
  the user says 'verify this change', 'run the checks', 'collect evidence', 'prove
  this works', 'run verification', 'does this pass?', or after implementing a change
  to create a durable evidence record in evidence.md. If implementation is done and
  the user wants confidence before merging, this is the right skill.
---

# rctl-verify-change

Run zone validation commands against a change and record the results as durable evidence — so there's a concrete, reviewable record of what was checked, what passed, and what still needs human review. The skill forces durable evidence recording with exact commands and outputs — without it, agents run tests, see them pass, and say "tests pass" without leaving any reviewable record.

## Outputs
- Updated `evidence.md` with command outputs, pass/fail status, and timestamps
- Optional `evaluator-report.md` if adversarial review is requested
- Updated `change.yaml` lifecycle with verification status

## When not to use this skill
- As a substitute for writing a plan — verify after implementing, not before.
- When the user just wants to run a quick test without recording evidence — just run the test directly.

## Mandatory checklist

Complete every row. Do not skip any dimension even if it seems obvious.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| Acceptance criteria extraction | Read `plan.md` and list every acceptance criterion before running anything | Without explicit criteria, verification drifts into "run some tests and hope" |
| Validation command execution | Run every command from the zone manifest and change plan, recording exact commands | Skipping commands means unverified assumptions survive into production |
| Output recording | Capture the exact command, full output (or meaningful excerpt), pass/fail, and timestamp | "Tests pass" is not evidence — the next reviewer needs to see what actually happened |
| `rctl enforce .` execution | Run enforceable checks and include results in evidence | Enforcement catches structural and policy violations that tests miss |
| Unverified criteria flagging | For each acceptance criterion not covered by any command, explicitly mark it as unverified | Silent gaps in coverage are the most dangerous kind of false confidence |
| Evidence append (not overwrite) | Add new findings below existing sections, never replace earlier evidence | Overwriting destroys the verification history and hides regressions |
| Lifecycle update | Set `artifacts.verification` to `done` and `phase` to `verifying` in `change.yaml` | Stale lifecycle state makes `rctl status` unreliable for the next agent |

## Workflow

1. **Read the change context.** Open `change.yaml`, `plan.md`, and `status.md`. Extract every acceptance criterion and list the relevant validation commands.
2. **Check for prior evidence.** If resuming mid-verification, read `evidence.md` to see what was already checked. Do not trust partial evidence from a previous session — re-run any checks that were in progress when a reset occurred.
3. **Run validation commands.** Execute each command from the zone manifest and change plan. For each command: record the exact command run, record the full output (or a meaningful excerpt for verbose output), record pass/fail and timestamp, and if a command fails, record the failure and continue with remaining checks.
4. **Run enforceable checks.** Execute `rctl enforce .` and include the results in evidence.
5. **Check acceptance criteria.** For each criterion in `plan.md`, determine whether the evidence supports it. Directly verified by a passing command: mark as verified. Not covered by any command: mark as unverified, note what human review is needed.
6. **(Optional) Run evaluator.** If evaluator mode is enabled or the user requests deeper review, invoke `rctl-evaluate-change` to produce `evaluator-report.md`. Summarize its verdict in `evidence.md`.
7. **Update evidence.md.** Append new findings — do not overwrite earlier sections. Structure each entry as:
   ```markdown
   ### <Check name> — <pass/fail> — <timestamp>
   **Command:** `<exact command>`
   **Result:** <output excerpt>
   ```
8. **Update change.yaml.** Set `artifacts.verification` to `done` and `phase` to `verifying`.

## Failure patterns to avoid
- Claiming verification without recording the actual commands run or their output — "tests pass" is not evidence.
- Trusting partial evidence from a previous session after a reset — re-run unfinished checks.
- Treating evaluator mode as mandatory — it's an opt-in layer above command-based verification.
- Overwriting earlier evidence sections — append so the full verification history is preserved.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most.

## Example prompts
- Verify the active change and leave a durable evidence summary.
- Run the zone-level checks and tell me what remains unproven.
- Verify this change, then add an evaluator pass for semantic review.
- Does this change actually pass all the checks? Prove it.
