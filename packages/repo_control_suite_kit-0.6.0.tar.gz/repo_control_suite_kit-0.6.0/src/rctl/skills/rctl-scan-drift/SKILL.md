---
name: rctl-scan-drift
description: Scan for drift between code, documentation, plans, and repository structure,
  producing a diagnostic report of mismatches. Use when the user suspects docs
  are stale, guidance files don't match the code, rctl configs no longer reflect
  reality, or a major refactor may have left outdated references behind. Also use
  when the user says 'is anything out of date?', 'check if docs match the code',
  'are there stale references?', 'scan for drift', 'what is out of sync?', or
  wants to catch forgotten updates after changes. This skill forces cross-referencing
  multiple artifact types (guidance, manifests, projections, commands) and classifying
  confidence — without it, agents check one or two files and declare the repo is
  fine. Do not use when the user already knows what is stale and wants to fix or
  clean it up — use rctl-sync-memory for updating docs or rctl-cleanup-pr for
  pruning artifacts.
---

# rctl-scan-drift

Scan the repository for drift — places where documentation, guidance, manifests, or plans no longer match the actual code and structure. The value of this skill over ad hoc checking is breadth and classification: it forces you to cross-reference every artifact type and label each finding as confirmed or suspected, rather than spot-checking one file and declaring the repo clean.

## Outputs
- A drift report with concrete mismatches, each classified as confirmed or suspected
- Proposed fixes for each confirmed drift item
- Summary of what was checked and what wasn't (so the user knows the scan's coverage)

## When not to use this skill
- As a replacement for verifying a specific change — use `rctl-verify-change` for that.
- When the user wants to restructure the repo — this skill finds problems, not solutions.

## Drift categories

| Category | What drifts | How to detect |
|----------|-------------|---------------|
| **Guidance drift** | CLAUDE.md, AGENTS.md reference deleted files or wrong paths | Check that referenced paths exist |
| **Zone manifest drift** | `zone.yaml` lists paths, owners, or commands that no longer apply | Compare `paths` entries against actual directory structure |
| **Change artifact drift** | Active changes reference outdated file paths or completed work | Check `status.md` and `plan.md` against filesystem state |
| **Validation command drift** | Test/lint commands reference moved modules or deleted configs | Dry-run validation commands and check for errors |
| **Skill projection drift** | `.claude/skills/` or `.agents/skills/` don't match `src/rctl/skills/` canonical source | Diff projected vs canonical copies |
| **Control plane drift** | `control-plane.yaml` lists stale zones, skills, or commands | Cross-reference registry entries against actual files |

## Mandatory checklist

Every drift scan must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Guidance file path verification** | For every file path referenced in CLAUDE.md and AGENTS.md, verify the target exists and the reference is accurate. | Broken path references send agents to files that don't exist |
| **Zone manifest path validation** | For every `paths` entry in each zone manifest, confirm the directory exists on disk. | Phantom zone paths cause routing failures and false enforcement results |
| **Validation command dry-run** | Run each `validation_commands` entry with a dry-run or quick check to see if it errors. | Commands referencing moved modules fail silently and give false confidence |
| **Skill projection diff** | Diff each skill in `.claude/skills/` and `.agents/skills/` against its canonical copy in `src/rctl/skills/`. | Stale projections mean agents run outdated skill instructions |
| **Active change staleness** | Check each plan in `rctl/changes/active/` — is it fully verified but not archived? Does it reference moved files? | Stale active changes confuse implementing agents about what work remains |
| **Confirmed vs suspected classification** | For every finding, explicitly label whether you are certain (confirmed) or flagging for human review (suspected). | Mixing facts with guesses erodes trust in the drift report |

## Workflow

1. **Run `rctl gc . --dry-run`** to get a machine view of orphans, stale references, and manifest drift.

2. **Walk the mandatory checklist.** Systematically cover every dimension in the table above, starting with guidance files and zone manifests since those have the highest agent impact.

3. **Check active changes.** Scan `rctl/changes/active/` — are any changes fully verified but not archived? Do any reference files that have moved?

4. **Check skill projections.** Compare each skill in `.claude/skills/` and `.agents/skills/` against its canonical copy in `src/rctl/skills/`. Flag content differences.

5. **Classify findings.** For each mismatch:
   - **Confirmed drift:** The code and the documentation clearly disagree. Include both the stale reference and the current truth.
   - **Suspected drift:** Something looks off but you're not certain. Flag it for human review.

6. **Write the drift report.** List findings grouped by category, with confirmed items first. For each item, suggest the specific fix.

## Failure patterns to avoid
- Mixing confirmed drift with guesses and presenting both as facts — always label your confidence level.
- Producing a huge report that buries real issues in noise — focus on items that will actually mislead agents or humans.
- Scanning only structure without checking content — a file can exist at the right path but contain outdated information.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most.

## Example prompts
- Scan this repo for stale guidance and command drift.
- Tell me what in rctl no longer matches the actual codebase.
- We just finished a big refactor — check if the docs are still accurate.
- Are any skill projections out of sync with their canonical copies?
