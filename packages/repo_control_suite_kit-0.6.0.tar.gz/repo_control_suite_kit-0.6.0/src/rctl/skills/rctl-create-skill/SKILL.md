---
name: rctl-create-skill
description: Create or improve an rctl skill using structured authoring. Use when
  the user wants to turn a repeated workflow into a reusable skill, write a new rctl
  skill from scratch, improve an existing skill's description or instructions, or
  add eval prompts. Also use when the user says 'make this a skill', 'create a skill
  for X', 'improve the skill description', 'add evals to this skill', 'write a new
  skill', or wants to formalize a workflow they keep repeating. If the user describes
  a process and asks to make it repeatable, this is the right skill. This skill
  enforces a triggering-first approach, mandatory eval seeding, and projection to
  agent surfaces — without it, agents write skill bodies that never trigger because
  the description is an afterthought, and forget to project the canonical copy so
  no agent can discover the skill.
---

# rctl-create-skill

Author a new skill or improve an existing one so that it triggers reliably, guides the agent through the right steps, and can be tested with eval prompts. The value of this skill over writing a SKILL.md by hand is the triggering-first discipline — it forces you to write the description (the trigger mechanism) before the body, seed evals immediately, and project to all agent surfaces.

## Outputs
- A skill folder with `SKILL.md` (and optional `evals/evals.json`)
- The canonical copy under `src/rctl/skills/<skill-name>/`
- Projected copies for each agent surface (`.claude/skills/`, `.agents/skills/`)

## When not to use this skill
- The workflow is still too vague to describe concretely. Help the user clarify intent first, then come back.

## Mandatory checklist

Every skill authoring pass must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Trigger phrase coverage** | Description includes 5+ realistic user phrases, synonyms, and edge-case triggers. Test mentally: "Would the agent pick this skill if the user said X?" | Skills that under-trigger are invisible; the body doesn't matter if the skill never activates |
| **Negative boundary definition** | "When not to use" section explicitly lists at least one scenario that sounds similar but should NOT trigger. | Without negative boundaries, skills over-trigger on adjacent tasks and confuse the agent |
| **Eval prompt seeding** | `evals/evals.json` has 2-3 prompts: one happy-path, one edge case, one negative (should NOT trigger). | Skills without evals can't be tested for trigger accuracy or workflow correctness |
| **Canonical-to-projection sync** | After writing `src/rctl/skills/<name>/SKILL.md`, copy to `.claude/skills/<name>/SKILL.md` and `.agents/skills/<name>/SKILL.md`. | A skill that exists only in `src/` is invisible to every agent |

## Skill anatomy

```
skill-name/
├── SKILL.md          # Required: frontmatter (name, description) + instructions
└── evals/
    └── evals.json    # Optional: test prompts for evaluating the skill
```

## Workflow

1. **Capture intent.** Understand what the skill should do, when it should trigger, what the expected outputs are, and what it should NOT do. If converting a conversation workflow, extract the steps, tools used, corrections made, and output format from the conversation history.

2. **Write the description FIRST.** Before writing any body content, write the `description` field in frontmatter. This is the primary trigger mechanism. Include: what the skill does, when to use it, 5+ specific user phrases/synonyms, and a WHY sentence explaining what the agent would miss without the skill. Err on the side of being "pushy" — skills under-trigger far more often than they over-trigger.

3. **Define negative boundaries.** Write the "When not to use" section immediately after the description. Include at least one scenario that sounds similar but should not trigger this skill.

4. **Write the SKILL.md body.** Structure it as:
   - Opening summary (1-2 sentences explaining what the skill does and why it's better than doing this manually)
   - **Outputs** — what the skill produces
   - **When not to use** — guard rails (already written in step 3)
   - **Mandatory checklist** — a table of dimensions the agent must cover
   - **Workflow** — numbered steps with bold labels, concrete enough that an agent can follow without guessing
   - **Failure patterns to avoid** — specific mistakes, including "skipping the skill for simple-seeming tasks"
   - **Example prompts** — 3-4 realistic user requests

5. **Seed eval prompts.** Create `evals/evals.json` with at least 2-3 test prompts: one happy-path trigger, one edge case, and one negative (similar-sounding but should NOT trigger).

6. **Create the canonical copy** under `src/rctl/skills/<skill-name>/SKILL.md`.

7. **Project to agent surfaces.** Copy to `.claude/skills/<skill-name>/SKILL.md` and `.agents/skills/<skill-name>/SKILL.md`. Verify both copies match the canonical.

## Writing guidelines

- **Explain the why.** Instead of heavy-handed MUSTs, explain reasoning so the agent can handle edge cases intelligently.
- **Keep it concrete.** Vague instructions like "handle appropriately" give the agent nothing to work with. Specify exact file paths, field names, and commands.
- **Use imperative form.** "Read the change plan" not "The agent should read the change plan."
- **Include examples.** Show input/output pairs for non-obvious formats.
- **Stay under 500 lines.** If approaching this limit, split into SKILL.md + reference files.

## Failure patterns to avoid
- Writing the body before the description — this produces skills with great instructions that never trigger.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most, because hand-written skills almost always have weak descriptions and no evals.
- Writing a description that only says what the skill IS without saying when to USE it — leads to under-triggering.
- Forgetting to project the canonical copy to agent surfaces — the skill exists in `src/` but no agent can discover it.

## Example prompts
- Turn this repeated review workflow into a new rctl skill.
- Improve the description and eval seeds for our drift-scan skill.
- Create a skill for the deployment checklist we keep running manually.
- Write a skill that formalizes our database migration review process.
