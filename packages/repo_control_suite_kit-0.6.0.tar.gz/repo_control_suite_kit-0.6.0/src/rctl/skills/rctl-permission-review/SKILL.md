---
name: rctl-permission-review
description: Review trust and permission boundaries immediately before executing a risky
  action. Use only when an agent or user is about to perform a specific action
  that touches secrets, API keys, environment variables, production systems, or
  destructive commands (rm, drop, force-push). Also use when the user asks 'is
  this safe to run?', 'what permissions does this need?', 'should I be worried
  about this?', 'check the blast radius', or before any action that crosses a
  trust boundary involving credentials, deployment pipelines, or production data.
  This skill forces trust boundary mapping and blast radius analysis before an
  action executes — without it, agents either approve everything or refuse
  everything without nuanced risk assessment. This skill is for pre-action safety
  checks, not for auditing existing IAM/RBAC policies or reviewing infrastructure
  permissions at rest.
---

# rctl-permission-review

Review the trust and permission boundaries of a proposed action before it executes — identifying what can go wrong, what credentials are involved, and what approval gates should exist. The value of this skill over ad hoc judgment is structure: it forces credential identification, external system mapping, and blast radius estimation that agents skip when eyeballing risk.

## Outputs
- A permission/risk assessment with trust boundary analysis
- Recommended safe execution posture (what to lock down, what to approve explicitly)
- Durable notes in the change or zone policy area if the assessment affects future work

## When not to use this skill
- For routine low-risk local edits with no trust boundary questions (editing a README, running unit tests).
- When the user has already explicitly approved the action and understands the risk.

## Risk taxonomy

| Risk level | Characteristics | Examples |
|-----------|----------------|---------|
| **Low** | Local, reversible, no external systems | Editing source files, running tests |
| **Medium** | Touches shared state but reversible | Pushing a branch, modifying CI config |
| **High** | Hard to reverse or affects production | Force-pushing, dropping tables, modifying secrets |
| **Critical** | Could cause data loss or security breach | Deleting production data, exposing credentials, modifying auth systems |

## Mandatory checklist

Every permission review must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Credential identification** | List every API key, token, password, SSH key, or service account the action touches or could expose. | Missing a credential means missing the highest-impact risk vector |
| **External system mapping** | Identify every production database, cloud API, third-party service, or shared resource the action reaches. | Local-only actions and external-reaching actions have completely different blast radii |
| **Destructive operation detection** | Flag deletions, overwrites, force-pushes, schema drops, and any operation that cannot be undone with a simple revert. | Agents default to treating all writes as equivalent; destructive ops need explicit gates |
| **Blast radius estimation** | Answer: what breaks if this goes wrong? One file, one service, one team, or all users? | Without explicit scoping, agents underestimate cascading failures |
| **Safe execution posture** | Recommend concrete pre-checks (dry-run, backup, staging), scoped permissions, and a rollback plan. | A risk label without an action plan gives the user anxiety but no path forward |
| **Zone governance check** | Read the relevant zone manifest for permission policies, required approval gates, and enforceable checks. | Zone policy may already prohibit or gate the action — skipping this means ignoring existing safety rails |

## Workflow

1. **Identify the action.** What exactly is being proposed? Read the relevant change plan, command, or user request.

2. **Walk the mandatory checklist.** For the proposed action, systematically cover every dimension in the table above. Do not skip blast radius estimation — this is the dimension agents most often omit.

3. **Assess the risk level** using the taxonomy above. Be explicit about what makes it that level.

4. **Recommend a safe execution posture:** what should be approved explicitly, what checks should run first, what permissions should be narrowed, and what rollback plan exists.

5. **Write durable notes** if the assessment reveals something that affects future work — add it to the zone manifest's invariants or to the change's risk notes.

## Failure patterns to avoid
- Treating all read/write/network actions as equivalent risk — a `git push` to a feature branch is not the same as a `git push --force` to main.
- Approving an action just because the user asked for it without explaining the risks — the review's value is in surfacing what the user might not have considered.
- Writing only a risk assessment without recommending a concrete safe execution path.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most.

## Example prompts
- Review the permission posture before this agent touches production credentials.
- Figure out what should require approval in this deployment workflow.
- Is it safe to run this database migration in production right now?
- Check the blast radius of this force-push before I do it.
