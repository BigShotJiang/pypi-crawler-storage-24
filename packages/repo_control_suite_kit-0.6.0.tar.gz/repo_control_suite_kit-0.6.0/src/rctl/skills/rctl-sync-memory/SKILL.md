---
name: rctl-sync-memory
description: Update repository documentation and guidance files after meaningful work
  so future agent sessions start with current knowledge instead of relearning from
  scratch. Without this skill, agents dump chat summaries into CLAUDE.md and create
  duplicated or conflicting guidance. Use when CLAUDE.md, AGENTS.md, zone manifests,
  runbooks, or guidance files need updating after a change. Also use when the user says
  'update the docs', 'make sure this is documented', 'future agents should know about
  this', 'sync the repo memory', 'document what we learned', or after any work that
  changed conventions, architecture, or operational procedures. If a significant decision
  was made or a convention changed during this session, use this skill to persist it.
---

# rctl-sync-memory

Update the repository's durable guidance files so that future agent sessions start with current knowledge — preventing the same questions, wrong assumptions, and wasted exploration from happening again. The skill forces choosing the right artifact type and checking for contradictions — without it, agents dump chat summaries into CLAUDE.md and create duplicated or conflicting guidance.

## Outputs
- Updated guidance files (CLAUDE.md, AGENTS.md, zone manifests, runbooks, or decision notes)
- A short note listing what was updated and why

## When not to use this skill
- When there's nothing new worth preserving — don't create busywork updates.
- When the information is only relevant to the current session (temporary debugging state, one-off commands).

## Mandatory checklist

Complete every row. Do not skip any dimension even if it seems obvious.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| Artifact type selection | Use the "What belongs" table to pick the correct location for each piece of information | Wrong location means the next agent won't find it when it matters |
| Duplication check | Search existing guidance files for the same topic before writing anything new | Adding a second copy creates contradictions the moment one copy gets updated |
| Contradiction detection | After writing, grep for the same topic across CLAUDE.md, AGENTS.md, and zone manifests | Conflicting guidance is worse than missing guidance — the agent follows whichever it finds first |
| Signal extraction | Write only conclusions and actionable rules, never conversation history or reasoning traces | Chat transcripts waste token budget and bury the actual guidance |
| Structured location preference | Prefer zone manifests and decision docs over free-form notes in CLAUDE.md | Structured locations are machine-queryable and survive refactoring better |

## What belongs in repo memory

| Information type | Where it goes | Example |
|-----------------|---------------|---------|
| Architecture decisions | `rctl/docs/decisions/` or zone manifest | "We chose Redis over Memcached because..." |
| Convention changes | CLAUDE.md or AGENTS.md | "Use snake_case for all Python files" |
| Operational procedures | Runbooks under `rctl/docs/` | "Deploy process changed: now requires staging first" |
| Zone ownership changes | Zone manifest `owners` field | New team took over the auth module |
| Validation command updates | Zone manifest `validation_commands` | New linter added, old one removed |
| Canonical terms | Zone manifest `canonical_terms` | "Use 'customer' not 'user' in the billing zone" |
| Lessons learned | Zone invariants or `rctl/docs/lessons/` | "Never run migrations during peak hours" |

## What does NOT belong in repo memory
- Chat transcripts or conversation summaries
- Temporary debugging notes or one-off investigation results
- Information that's already obvious from reading the code
- Git history or commit messages (those are their own memory)

## Workflow

1. **Identify what changed.** Review the work done in this session. What decisions were made? What conventions were established? What did we learn that a future agent would otherwise have to rediscover?
2. **Choose the right artifact.** Use the table above to decide where each piece of information belongs. Prefer structured locations (zone manifests, decision docs) over unstructured ones (free-form notes in CLAUDE.md).
3. **Check for duplication.** Search the target file and related guidance files for existing coverage of the same topic. If found, update in place rather than appending a new section.
4. **Write the minimal durable update.** Keep guidance concise and actionable. A future agent reading this should understand what to do differently — not read a history lesson.
5. **Verify consistency.** After updating, check that the new guidance doesn't contradict existing guidance in other files. If it does, update or remove the stale version.

## Failure patterns to avoid
- Copying chat transcripts into docs instead of extracting only the lasting signal — future agents don't need the conversation, they need the conclusion.
- Adding guidance that's obvious from reading the code — "this function takes a string" adds no value.
- Updating one location but leaving a contradictory version in another — creates confusion for the next agent.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most.

## Example prompts
- Sync the durable repo memory after we changed the deployment process.
- Update the zone docs so future agents know this module owns auth tokens now.
- Document the architecture decision we just made about caching.
- Make sure the next agent knows about the new testing convention we established.
