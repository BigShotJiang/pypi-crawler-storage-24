---
name: rctl-implement-change
description: Implement a planned repository change while keeping rctl change artifacts
  (status.md, evidence.md) current. Use when there is already a change plan under
  rctl/changes/active/ and the user wants to start or continue coding. Also use when
  the user says 'implement the plan', 'start coding', 'carry out the change', 'execute
  this change', 'resume the implementation', or references an active change record
  that needs execution. This skill forces status.md and evidence.md updates at each
  major step, making progress recoverable across resets — without it, agents code
  ahead of their recorded state and the next agent has to start over. If there is
  an active change plan and the user wants code written, this is the right skill.
---

# rctl-implement-change

Execute a planned change while keeping status, evidence, and recovery artifacts current — so that progress is never lost, even across context resets or agent handoffs. The value of this skill over raw coding is recoverability — it forces artifact updates at each step, preventing the default behavior of coding ahead and leaving the next agent with no idea what was done or what remains.

## Outputs
- Code changes aligned to the active plan
- Updated `status.md` with current phase and recovery point
- Updated `evidence.md` with validation results collected during implementation
- Updated `change.yaml` lifecycle fields

## When not to use this skill
- No plan or scope exists for a risky multi-file change. Create one first with `rctl-plan-change`.
- The change is a trivial one-file edit that doesn't need change tracking.

## Mandatory checklist

Every implementation session must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Plan reading** | Read `plan.md` fully before writing any code. List the steps you will implement this session. | Coding without reading the plan causes divergent work that conflicts with the documented scope |
| **Status update** | After each major step (function, migration, config change), update `status.md` with what is done and what is next. | Stale status means a context reset loses all progress — the next agent restarts from scratch |
| **Recovery point refresh** | After each status update, rewrite the `## Recovery point` section with Done, Next, Decisions, and Risks. | A recovery point missing "Next" forces the resuming agent to re-read the entire codebase |
| **Deviation recording** | If you deviate from the plan (different approach, skipped step, new risk), record it in `status.md` immediately. | Unrecorded deviations cause the next agent to follow the stale plan and undo your work |
| **Lifecycle field updates** | After each logical step, set `lifecycle.updated_at` to now. On completion, set `artifacts.implementation` to `done`. | Stale lifecycle makes `rctl status` unreliable and blocks downstream skills |

## Workflow

1. **Read the change context.** Open `change.yaml`, `plan.md`, `status.md`, and `evidence.md`. Also read zone manifests for any governance rules or validation commands that apply. List the steps you will implement this session.

2. **If resuming after a reset:** Read `status.md` Recovery point section. Verify the recorded state matches the actual filesystem (files exist, git status matches). Resume from the documented next step — do not restart from scratch.

3. **Walk the mandatory checklist at each step.** Implement in small coherent steps. After each step:
   - Update `status.md` with what is done and what is next
   - Refresh the `## Recovery point` section
   - Add validation results to `evidence.md` if you ran any checks
   - Update `lifecycle.updated_at` in `change.yaml`

4. **Capture deviations immediately.** If you deviate from the plan, record it in `status.md` before continuing. Do not batch deviation notes for later.

5. **Complete implementation.** When all planned work is done:
   - Set `artifacts.implementation` to `done`
   - Set `phase` to `implementing`
   - Run `rctl next . <change-id> --update` to advance to verification

## Recovery point format

The recovery point in `status.md` is the most critical artifact for agent handoffs:

```markdown
## Recovery point
- **Done:** [list of completed steps]
- **Next:** [exact next action to take]
- **Decisions:** [any session-specific decisions not captured elsewhere]
- **Risks:** [anything that surfaced during implementation]
```

## Failure patterns to avoid
- Coding ahead of the recorded plan and leaving artifacts stale — the next agent will re-do work or make conflicting changes.
- Completing implementation without updating lifecycle state — makes `rctl status` unreliable.
- Crossing major implementation boundaries without refreshing the recovery point — a reset here loses all progress context.
- Starting implementation without reading the plan first — leads to divergent work.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most, because the agent's default behavior is to produce shallow results.

## Example prompts
- Carry out the active change and keep the status/evidence files current.
- Implement the refactor described in rctl/changes/active/cache-rewrite.
- Resume the implementation from where the last agent left off.
- Start coding the auth middleware change — there's already a plan in place.
