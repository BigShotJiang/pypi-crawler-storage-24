---
name: rctl-incident-to-learning
description: Turn a bug, incident, review comment, or failure into a permanent lesson
  in the repository. Use when something went wrong and the user wants to prevent
  it from happening again — by adding test cases, updating runbooks, strengthening
  zone invariants, or improving guidance. Also use when the user says 'write this
  down so we don't repeat it', 'add a lesson learned', 'this bug should become
  a test', 'update the runbook after this outage', 'make sure agents know about
  this gotcha', 'never let this happen again', or 'capture this failure as a
  repo change'. This skill forces at least one durable repo change (test, invariant,
  runbook, or check) — without it, agents write a summary of what went wrong but
  don't actually harden the repo. Do NOT use for writing standalone postmortem
  documents without concrete repo changes. If a failure just happened and the user
  wants to harden the repo against it, this is the right skill.
---

# rctl-incident-to-learning

Convert a failure, bug, incident, or review finding into a durable repository change that prevents the same class of problem from happening again. The goal is not a retrospective document — it's a concrete change to code, tests, guidance, or governance that makes the repo harder to break in the same way. The value of this skill over manual post-mortems is durability — it forces at least one repo change that a machine can verify, preventing the default behavior of writing a summary and moving on.

## Outputs
- At least one durable artifact change (test, runbook update, zone invariant, guidance update, or enforceable check)
- A brief learning note explaining what happened and what was hardened

## When not to use this skill
- The user wants a blameless retrospective or post-mortem document without making repo changes. This skill is about durable fixes, not prose.
- The failure is still being investigated and root cause isn't clear yet.
- The user is writing new tests as part of normal development, not converting a specific failure into a regression test.

## Mandatory checklist

Every incident-to-learning conversion must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Failure classification** | Classify the failure using the learning channels table below. Name the type explicitly. | Wrong classification leads to wrong channel — a test won't fix a runbook gap |
| **Learning channel selection** | Choose at least one durable channel (test, runbook, invariant, check, manifest update). Justify the choice. | Without explicit channel selection, agents default to writing prose that evaporates |
| **Durable fix implementation** | Write the actual fix: the test code, the runbook step, the invariant, or the check definition. Not a note about what should be done — the actual change. | A TODO to "add a test later" is not a durable fix |
| **Fix verification** | Run the new test, check, or validation command. Confirm it would have caught the original failure. | An unverified fix might not actually catch the failure it claims to prevent |
| **Class-of-failure analysis** | Ask: does this specific failure represent a broader pattern? If so, harden the class, not just the instance. | Fixing one null check when the pattern suggests dozens is incomplete hardening |

## Learning channels

| Failure type | Best channel | Example |
|-------------|-------------|---------|
| Bug that slipped past tests | **New test case** | Add a regression test covering the exact scenario |
| Operational procedure gap | **Runbook update** | Add a step to the deployment checklist |
| Agent made a bad decision | **Guidance/zone invariant** | Add an invariant or CLAUDE.md note |
| Repeated manual mistake | **Enforceable check** | Add an `rctl enforce` check that catches it automatically |
| Architecture misunderstanding | **Zone manifest update** | Clarify ownership, canonical terms, or key docs |

## Workflow

1. **Summarize the failure** in 1-2 sentences. What happened, what was the impact, and what was the root cause?

2. **Walk the mandatory checklist.** Classify the failure, select the learning channel, implement the durable fix, verify it, and analyze whether the class of failure needs broader hardening. Do not skip class-of-failure analysis — this is the highest-value dimension that manual incident response almost always misses.

3. **Write the durable fix.** For each selected channel:
   - **Test:** Write the test, run it, confirm it would have caught the original failure
   - **Runbook:** Add or update the specific step that was missing
   - **Guidance:** Add the invariant or note to the appropriate zone manifest, CLAUDE.md, or AGENTS.md
   - **Enforceable check:** Define the check in the zone's `enforceable_checks` and verify it works with `rctl enforce . --dry-run`

4. **Verify the fix works.** Run the new test, check, or validation command to confirm it catches the failure scenario.

5. **Write a learning note.** Brief markdown noting: what broke, why, and what was hardened. This goes in `rctl/docs/lessons/` or inline in the relevant zone manifest's invariants.

## Failure patterns to avoid
- Writing a retrospective that lives only in chat or a standalone document with no repo changes — the lesson evaporates after the conversation ends.
- Adding a vague invariant like "be careful with deployments" instead of a concrete, testable rule.
- Hardening only the exact scenario without considering the class of failure (e.g., adding a test for one missing null check when the pattern suggests many more exist).
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most, because the agent's default behavior is to produce shallow results.

## Example prompts
- Convert this failed deploy into a runbook and policy improvement.
- Make sure the lesson from this review comment becomes durable repo guidance.
- This test was flaky because of a race condition — add a proper regression test and document the pattern.
- An agent accidentally deleted the migrations folder. Make sure that can't happen again.
