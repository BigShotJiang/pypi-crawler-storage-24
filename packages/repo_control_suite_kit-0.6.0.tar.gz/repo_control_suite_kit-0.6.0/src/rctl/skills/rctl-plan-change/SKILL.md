---
name: rctl-plan-change
description: Create or refresh a durable change plan under rctl/changes/active/. Use
  whenever the user asks for a non-trivial implementation, refactor, migration, or
  repository-wide update. Also use when the user says 'plan this before coding', 'what
  is the plan for X?', 'create a change record', 'let's plan this out', 'make a plan
  first', or when a task involves multiple files, risk, or would benefit from documented
  scope, risks, and rollback steps. This skill forces concrete acceptance criteria,
  validation commands, and rollback steps — without it, agents write vague plans
  that say "implement the feature" without defining what done looks like or how to
  undo it. If the user is about to start significant work without a plan, suggest
  using this skill first.
---

# rctl-plan-change

Create or refresh a durable change plan under `rctl/changes/active/<change-id>/` — with enough detail that another agent (or the same agent after a reset) can resume the work without re-reading the entire codebase. The value of this skill over ad hoc planning is rigor: it forces testable acceptance criteria, runnable validation commands, and concrete rollback steps that agents omit when planning informally.

## Outputs
- `change.yaml` — machine-readable change metadata and lifecycle state
- `plan.md` — human-readable plan with goal, scope, risks, validation, and rollback
- `status.md` — current phase and recovery point (initially empty)
- Validation commands and rollback notes

## When not to use this skill
- Trivial formatting-only or single-line edits unless repo policy requires a full change record.
- When a plan already exists and just needs implementation — use `rctl-implement-change` instead.

## Change ID conventions

Choose a change ID that is short, descriptive, and URL-safe:
- For issues: `issue-42-fix-auth-race`
- For features: `feat-user-export-csv`
- For refactors: `refactor-cache-layer`
- For migrations: `migrate-postgres-15`

## Mandatory checklist

Every change plan must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Acceptance criteria concreteness** | Each criterion must be a testable assertion, not a subjective judgment. "API returns 200 for valid input" not "code should be clean". | Vague criteria let agents declare victory without proving the change works |
| **Validation command specificity** | List the exact commands to run (e.g., `pytest tests/auth/`), not generic placeholders like "run tests". | Generic commands don't catch regressions in the affected area |
| **Rollback approach** | Document how to undo: git revert, feature flag, migration down, or manual steps. | Plans without rollback leave the repo stuck if the change breaks something |
| **Risk identification** | Name specific risks with likelihood and impact, not just "things could go wrong". | Unidentified risks become unmitigated surprises |
| **Zone constraint awareness** | Read zone manifests for invariants and validation commands that apply to affected zones. | Ignoring zone constraints means the plan will fail enforcement checks |
| **Duplicate plan check** | Search `rctl/changes/active/` for existing plans covering the same scope before creating a new one. | Duplicate plans cause conflicting instructions for implementing agents |

## Workflow

1. **Choose or create a change ID.** Check `rctl/changes/active/` for existing plans that might cover this work — walk the duplicate plan check dimension first.

2. **Understand constraints.** Run `rctl enforce . --dry-run` to see what enforceable checks exist. Read zone manifests for invariants and validation commands that will apply to this change.

3. **Write `plan.md`** with these sections:
   - **Goal:** What this change achieves (1-2 sentences)
   - **Scope:** Which files, modules, or zones are affected
   - **Acceptance criteria:** Concrete, testable conditions that define "done"
   - **Risks:** What could go wrong and how likely it is
   - **Validation:** Which commands prove the change works (tests, lint, compile, enforce)
   - **Rollback:** How to undo this change if it causes problems
   - **Dependencies:** Other changes or external factors this depends on

4. **Write `change.yaml`** with change_id, title, status, zones, lifecycle (phase, timestamps, artifact states, next_step), and risk_level.

5. **Create empty `status.md`** with a `## Recovery point` section placeholder.

6. **Walk the mandatory checklist.** Before finishing, verify every dimension in the table above is addressed in the plan. Tighten any vague criteria or generic commands.

7. **Set next step.** Run `rctl next . <change-id> --update` to record what should happen next.

## Failure patterns to avoid
- Writing vague plans without validation commands or rollback steps — "test it" is not a validation plan.
- Creating a plan for work that already has an active plan — check first.
- Making acceptance criteria so vague they can't be objectively verified ("code should be clean").
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most.

## Example prompts
- Make a durable plan for migrating auth routes to the new middleware.
- Before coding, create a change record for this caching refactor.
- Plan out the database migration — I want risks and rollback documented.
- What's the plan for the API versioning change? Create a change record.
