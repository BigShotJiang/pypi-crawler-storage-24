---
name: rctl-score-repo
description: Score repository readiness using both structure and operational evidence.
  Without this skill, agents just check if files exist and report "looks good" without
  testing whether the system actually works. Use when the user asks 'how is the repo
  doing?', 'what is our rctl score?', 'is the repo ready?', 'show me the repo health',
  'how mature is our setup?', or wants to understand whether the rctl setup is actually
  working versus just having files in place. Also use when the user wants to fix score
  warnings, improve the readiness score, or assess whether the repo is ready for more
  autonomous agent work. If the user wants a quantitative readiness assessment of how
  well the rctl setup is being used, this is the right skill.
---

# rctl-score-repo

Score repository readiness across two dimensions — structural completeness (do the right files exist?) and operational evidence (has the system actually been used?) — so the user can tell whether rctl is genuinely working or just scaffolded. The skill forces separate structural vs operational scoring with readiness gates — without it, agents just check if files exist and report "looks good" without testing whether the system actually works.

## Outputs
- Structural score with itemized findings
- Operational score with evidence assessment
- Readiness gates (pass/fail checkpoints that block higher scores)
- Overall recommendation with specific next steps to improve

## When not to use this skill
- As the sole go/no-go signal for high-risk decisions — the score is a health indicator, not a certification.
- When the user just wants to run tests — use `rctl-verify-change` instead.

## Mandatory checklist

Complete every row. Do not skip any dimension even if it seems obvious.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| Structural item presence | Check each item in the structural scoring table exists | Establishes the baseline — missing files cannot score points |
| Placeholder detection | Scan zone manifests for `TBD`, `TODO`, empty strings in owners/fields | Files with placeholders look present but carry zero real value |
| Validation command execution | Run every defined validation command and record exit codes | A command that exists but fails is worse than no command — it gives false confidence |
| Evidence gate check | Open `evidence.md` files and verify they contain real outputs, not boilerplate | Placeholder evidence inflates the operational score without proving anything |
| Gate penalty application | For each failed gate, cap the overall score at 40 regardless of points earned | Gates exist to prevent high scores on broken installations |
| Improvement prioritization | Rank the top 3 fixes by impact on score and gates, not by ease | The user needs to know what moves the needle, not what is easy |

## Scoring dimensions

### Structural score (does the right stuff exist?)

| Item | Points | What to check |
|------|--------|---------------|
| `control-plane.yaml` exists and is valid | 10 | Parse YAML, check required fields |
| Root zone manifest exists | 10 | `root.zone.yaml` or equivalent |
| Zone manifests have real owners (not placeholders) | 10 | Check for `TBD`, `TODO`, empty strings |
| Validation commands defined | 10 | At least one command that can actually run |
| Discovery wiring for at least one agent | 10 | CLAUDE.md or AGENTS.md references `rctl/` |
| Skills projected to agent surfaces | 5 | `.claude/skills/` or `.agents/skills/` populated |
| Change lifecycle directories exist | 5 | `active/` and `archive/` under `rctl/changes/` |

### Operational score (has it actually been used?)

| Item | Points | What to check |
|------|--------|---------------|
| At least one archived change with evidence | 15 | `rctl/changes/archive/` has a change with `evidence.md` |
| Validation commands actually pass | 10 | Run them and check exit codes |
| Enforceable checks defined and passing | 5 | `rctl enforce .` succeeds |
| Zone manifests have been updated since bootstrap | 5 | `updated_at` differs from `created_at`, or git history shows edits |
| Active changes follow lifecycle correctly | 5 | `change.yaml` has correct phase and artifact states |

### Readiness gates

These are pass/fail checkpoints. Failing any gate caps the overall score:

- **Discovery gate:** At least one agent surface can find `rctl/`. Without this, nothing else matters.
- **Validation gate:** At least one validation command exists AND passes. Without this, verification is impossible.
- **Evidence gate:** At least one change has real evidence (not just `evidence.md` with placeholder text). Without this, the operational score is bootstrapped, not earned.

## Workflow

1. **Score structure.** Check each structural item and record what's present, missing, or placeholder.
2. **Score operations.** Check each operational item. Run validation commands — don't just check that they're defined.
3. **Check readiness gates.** Report which gates pass and which fail. A failed gate should be the first thing the user sees.
4. **Compute overall score.** Sum points from both dimensions (max 100). Apply gate penalties: each failed gate caps the score at 40.
5. **Write the report.** Structure as: gate status, structural findings, operational findings, overall score, top 3 actions to improve (ordered by impact).

## Failure patterns to avoid
- Over-rewarding field presence while ignoring whether those fields contain real values — a zone manifest with `owners: [TBD]` should not score the same as `owners: ["@backend-team"]`.
- Pretending bootstrap scaffolding equals real readiness — distinguish "installed" from "used."
- Collapsing everything into a single number without explaining what drives it — the breakdown is more useful than the score.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most.

## Example prompts
- Score this repo and tell me whether it is only scaffolded or genuinely usable.
- Give me a readiness score that penalizes missing discovery wiring.
- How is the repo doing? What should I fix first to improve the score?
- Is this repo ready for more autonomous agent work?
