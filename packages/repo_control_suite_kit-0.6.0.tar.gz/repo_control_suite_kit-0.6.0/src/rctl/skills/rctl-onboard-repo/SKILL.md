---
name: rctl-onboard-repo
description: Bootstrap or refresh an agent-first repository control plane. Use whenever
  a repo needs rctl installed for the first time, routing files initially created,
  or the control plane structure refreshed after a repo reorganization. Also use
  when the user says 'set up rctl', 'install the control plane', 'onboard this
  repo', 'run rctl init', 'initialize rctl', 'bootstrap this repo for agents',
  or 'make this repo agent-ready'. This skill forces stack detection, discovery
  wiring for multiple agent surfaces, and merge-not-overwrite for existing guidance
  — without it, agents create a scaffold that no agent can actually discover or
  they overwrite existing CLAUDE.md content. Do not use for normal feature changes
  in an already-onboarded repo. Do not use for validating or scoring an existing
  rctl installation — use rctl-validate-repo or rctl-score-repo for that.
---

# rctl-onboard-repo

Install or refresh the rctl control plane in a repository so that AI agents can discover where plans, evidence, policies, skills, and guidance live — regardless of which agent platform is being used. The value of this skill over manual setup is completeness: it forces stack detection, per-surface discovery wiring, and merge-safe guidance updates that agents skip when onboarding ad hoc.

## Outputs
- Installed or refreshed `rctl/` control plane directory structure
- Bootstrap summary listing created, merged, skipped, and conflicted files
- Discovery wiring for selected agent surfaces (CLAUDE.md, AGENTS.md, codex.md)
- First-pass notes about missing owners, zones, or validation commands

## When not to use this skill
- For normal feature work inside an already-onboarded repo.
- When the user only wants a conceptual discussion about rctl with no repository changes.

## Mandatory checklist

Every onboarding must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Stack marker detection** | Inspect for package.json, pyproject.toml, go.mod, Cargo.toml, etc. and derive validation commands from them. | Without stack detection, validation commands are generic placeholders that never actually run |
| **Existing guidance preservation** | Read existing CLAUDE.md, AGENTS.md, codex.md fully before writing. Merge managed sections; never overwrite user content. | Overwriting destroys project-specific context the user already wrote |
| **Discovery wiring per agent surface** | For each target surface, verify the routing pointer to `rctl/control-plane/control-plane.yaml` is present and correct. | A scaffold that no agent surface can discover is useless |
| **Skill projection** | Copy canonical skills from `src/rctl/skills/` to `.claude/skills/`, `.agents/skills/` as needed. Verify copies match. | Unprojected skills are invisible to the agent platform |
| **Scaffold minimalism** | Every created file must earn its place. No empty placeholder directories or boilerplate-only files. | Maximalist scaffolds teach agents to ignore rctl artifacts as noise |
| **Follow-up action list** | Report what still needs human input: missing owners, TBD zones, placeholder validation commands. | Agents treating placeholders as real values make wrong decisions downstream |

## Workflow

1. **Detect the environment.** Inspect the repo root for stack markers, existing guidance files, existing rctl installation (partial or full), and git configuration. Walk the mandatory checklist's stack marker dimension here.

2. **Choose the scaffold scope.** Install the smallest useful control plane. If rctl already exists partially, fill gaps rather than overwriting.

3. **Create the control plane structure.** Generate `control-plane.yaml` and `root.zone.yaml` with sensible defaults based on the detected stack: validation commands from standard tools, initial zone paths, placeholder owners marked as needing real values.

4. **Wire agent discovery.** For each agent surface the user wants, add a managed section pointing to the control plane entrypoint. Merge into existing files — never overwrite user-owned content. Verify each wiring is reachable.

5. **Project skills.** Copy canonical skills to the appropriate agent surfaces. Verify the copies match their canonical source.

6. **Report results.** Show a summary: what was created, what was merged, what was skipped, and what conflicted. List follow-up actions for missing metadata.

## Failure patterns to avoid
- Silently skipping discovery files — the agent can't find rctl if CLAUDE.md or AGENTS.md doesn't point to it.
- Overwriting user-owned guidance instead of merging managed sections — destroys existing project context.
- Installing a maximalist scaffold with dozens of empty files — each file should earn its place.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most.

## Example prompts
- Turn this repo into an agent-first project and install the rctl control plane.
- Set up this existing service so Codex and Claude can both discover the same repo guidance.
- Run rctl init on this Node.js project.
- Refresh the control plane after we restructured the src/ directory.
