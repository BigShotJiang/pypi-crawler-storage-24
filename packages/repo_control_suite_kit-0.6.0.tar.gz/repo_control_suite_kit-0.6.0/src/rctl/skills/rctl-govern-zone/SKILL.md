---
name: rctl-govern-zone
description: Tighten or revise governance rules for a repository zone. Use when the
  user wants to add validation commands, enforce stricter rules, define who can modify
  a zone, add enforceable checks, or lock down a sensitive area before giving agents
  more autonomy. Also use when the user says 'add a rule for this zone', 'make this
  area stricter', 'set up enforcement', 'update zone permissions', 'lock this down',
  'add a check for X', or wants to edit zone.yaml invariants, enforceable checks,
  or permission policies. This skill forces you to verify that new rules are testable
  and enforceable, not just written — without it, agents add invariants that can never
  be machine-checked. If the user wants to change what agents are allowed to do in
  a specific part of the repo, this is the right skill.
---

# rctl-govern-zone

Add, tighten, or revise governance rules in a zone manifest (`zone.yaml`) so that agents working in that zone operate within explicit boundaries — with clear owners, validation commands, invariants, and permission policies. The value of this skill over manual rule-writing is enforceability — it forces you to pair every invariant with a validation command and verify it actually runs, not just look plausible in YAML.

## Outputs
- Updated `zone.yaml` with new or revised governance rules
- A governance note explaining what changed and why
- Updated enforceable checks if validation commands were added

## When not to use this skill
- For ordinary feature implementation — governance changes are about rules, not code.
- When the user wants to understand zone structure without changing it — use `rctl-map-context` instead.

## Mandatory checklist

Every governance change must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Rule testability** | For each new invariant: can a machine verify it? Write the check command. If you cannot write one, the rule is aspirational, not enforceable. | Invariants without validation commands are ignored by every future agent |
| **Validation command** | For each invariant, add a concrete command to `validation_commands`. Run it once to confirm it succeeds on the current codebase. | A command that has never been run is an untested assumption |
| **Permission scope** | Review `permissions` and ensure agents have the minimum access needed. Remove any broad grants that the new rules make unnecessary. | Over-permissioned zones let agents bypass the rules you just wrote |
| **Dry-run verification** | Run `rctl enforce . --dry-run` after edits. Every new check must appear in the output and pass. | A check that doesn't show up in dry-run will never run in practice |
| **Governance note** | Write a brief note explaining what changed, why, and what the expected impact is on agent behavior. | Future agents need the "why" to know if a rule still applies |

## Workflow

1. **Read the current zone manifest.** Open the target `zone.yaml`, control-plane.yaml, and any parent zone manifests for inherited rules. List current invariants, validation commands, and permissions.

2. **Walk the mandatory checklist.** For each proposed rule change, fill in every dimension from the table above. Do not skip rule testability — this is the highest-value dimension that manual governance almost always misses.

3. **Draft the rule changes.** For each change:
   - Write the invariant in concrete, testable terms (not vague aspirations)
   - Write the validation command that checks it
   - Set the permission level to minimum necessary access

4. **Update `zone.yaml`.** Apply the changes and ensure the YAML is valid.

5. **Run dry-run verification.** Execute `rctl enforce . --dry-run` and confirm every new check appears and passes.

6. **Write the governance note.** Explain what was tightened, why, and what agent behavior should change as a result.

## Failure patterns to avoid
- Adding ceremony (more fields, more invariants) without actually changing what agents can or must do — governance should reduce risk, not just add paperwork.
- Writing invariants so vague they can't be enforced ("code should be good").
- Tightening permissions without adding validation commands — rules without checks are wishful thinking.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most, because the agent's default behavior is to produce shallow results.

## Example prompts
- Harden governance for the payments zone before we let agents touch it more often.
- Update this zone manifest so ownership and validation are explicit.
- Add an enforceable check that prevents agents from modifying the auth config without review.
- Lock down the deployment zone — only the platform team should have write access.
