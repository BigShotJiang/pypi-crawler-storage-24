---
name: rctl-evaluate-change
description: Run a thorough review of a tracked change that goes beyond just running
  tests and lint. Use when the user wants a second opinion on a change, asks
  'does this change actually make sense?', 'review this change for completeness',
  'are there any gaps in this change?', 'look at this change with fresh eyes',
  or when verification passed but the change needs semantic, UX, or logical
  review. Also use after rctl-verify-change when deeper analysis is needed to
  confirm the change truly meets its goals. If the user says 'evaluate this
  change' or 'run the evaluator', this is the right skill. This skill enforces
  adversarial posture and per-criterion evidence checking — without it, agents
  default to praise, rubber-stamp criteria that already passed, and miss the
  gaps that only skeptical review uncovers.
---

# rctl-evaluate-change

Run an adversarial semantic review of a tracked change — challenging whether it actually meets its goals, not just whether tests pass. The value of this skill over a manual review is adversarial discipline — it forces per-criterion verdicts with evidence, cross-checks claims against actual proof, and prevents the agent's natural tendency to praise work it is reviewing.

## Outputs
- `evaluator-report.md` in the active change directory
- Per-acceptance-criterion verdict (pass / fail / unknown) with rationale
- Short summary appended to `evidence.md` referencing the report

## When not to use this skill
- As a replacement for baseline command-based verification (`rctl-verify-change`). Run tests first, evaluate second.
- When the user or change configuration has not opted into evaluator mode and the change is low-risk.
- For GitHub PR reviews or general code reviews — this skill evaluates rctl-tracked changes against their plan and acceptance criteria, not pull requests.

## Mandatory checklist

Every evaluation must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Acceptance criterion extraction** | Pull every acceptance criterion from `plan.md`. If criteria are missing or vague, infer from goal/scope and flag reduced confidence. | Evaluating without explicit criteria produces vague "looks good" assessments |
| **Per-criterion verdict** | For each criterion, assign `pass`, `fail`, or `unknown` with a rationale tied to specific diff lines or evidence outputs. | Aggregate verdicts hide which criteria actually passed vs. were assumed |
| **Adversarial posture verification** | Before writing the report, re-read your findings and check: did you challenge anything, or did you only confirm? If every criterion is `pass`, explicitly justify why. | Agents naturally default to praise; an all-pass evaluation without justification is a red flag |
| **Evidence-vs-claim cross-check** | For each `pass` verdict, verify the evidence actually proves the claim. Check that `evidence.md` outputs match what the diff produces, not just that evidence exists. | Evidence that doesn't actually prove the claim is the most common evaluation failure |
| **Evaluator report structure** | Report must include: overall assessment, confidence level, acceptance check results table, ranked issues, and residual uncertainty. | Unstructured findings are hard for the next agent or human to act on |

## Evaluator posture

The evaluator's job is to challenge, not to praise. Adopt an adversarial mindset: you did not generate this change, and your default should be skepticism. Look for what could go wrong, what's missing, and what the generator might have overlooked.

## Workflow

1. **Read the change context.** Open `change.yaml`, `plan.md`, `status.md`, and `evidence.md`. Understand the goal, scope, and what has already been verified.

2. **Get the diff.** Read `diff.patch` in the change directory if present, or compute it via `git diff` against the relevant base ref.

3. **Extract acceptance criteria.** Pull every criterion from `plan.md` into a numbered list. If criteria are missing or vague, infer from the goal and scope — but flag that confidence is reduced when criteria are inferred rather than explicit.

4. **Walk the mandatory checklist.** Before reviewing individual criteria, confirm you have: the criteria list, the diff, the evidence, and an adversarial mindset. If you catch yourself assuming something passes, stop and find the proof.

5. **Review each acceptance criterion.** For each one, determine:
   - `pass` — the diff and evidence clearly satisfy this criterion
   - `fail` — the diff contradicts or misses this criterion
   - `unknown` — insufficient evidence to judge

   Record a concrete rationale tied to specific lines in the diff, evidence outputs, or observable behavior. Do not write "appears to work" — cite the specific evidence.

6. **Cross-check evidence against claims.** For every `pass` verdict, re-read the evidence and ask: "Does this output actually prove this criterion, or does it just look related?" Flag any evidence that is circumstantial rather than direct.

7. **Apply the evaluator rubric** across these dimensions:
   - **Functional correctness** — does the code do what the plan says?
   - **Acceptance coverage** — are all criteria addressed, not just the easy ones?
   - **Operator/UX clarity** — will a human or agent using this change understand what happened?
   - **Semantic completeness** — are edge cases handled? Are there implicit assumptions?
   - **Craft** — is the implementation maintainable, or does it introduce tech debt?

8. **Verify adversarial posture.** Re-read your findings. If every criterion is `pass` and you found zero issues, explicitly state why this is justified rather than a sign of insufficient scrutiny.

9. **Write `evaluator-report.md`** with:
   - Overall assessment: `pass`, `pass-with-concerns`, `needs-follow-up`, or `blocking`
   - Confidence: `low`, `medium`, or `high`
   - Acceptance check results table (criterion | verdict | rationale)
   - Issues found (ranked by severity)
   - Residual uncertainty

10. **Append summary to `evidence.md`** — reference `evaluator-report.md`, state the overall assessment and confidence, and list top findings.

## Failure patterns to avoid
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most, because agents without adversarial prompting will default to "looks good" confirmations.
- Praising the change by default — the evaluator's value comes from adversarial scrutiny.
- Treating missing evidence as implicit success instead of marking it `fail` or `unknown`.
- Writing vague findings like "looks good overall" — every finding should point to a specific line, file, or behavior.
- Rubber-stamping criteria that already passed verification — verification checks commands, evaluation checks semantics. They are different.

## Example prompts
- Run an adversarial evaluator pass on this high-risk change and write evaluator-report.md.
- Review this user-facing diff for semantic and UX gaps before merge.
- Evaluate whether the current evidence really proves the acceptance criteria.
- This change passed tests but something feels off — give it a second look.
