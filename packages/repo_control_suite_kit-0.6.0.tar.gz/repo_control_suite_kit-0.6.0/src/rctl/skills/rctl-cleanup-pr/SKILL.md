---
name: rctl-cleanup-pr
description: Clean up repository residue after a change or review cycle. Use when
  temporary notes, stale active changes, duplicated guidance, or leftover artifacts
  should be pruned without losing durable history. Also use when the user says 'clean
  up after this PR', 'remove stale files', 'tidy up the repo', 'prune old artifacts',
  or after a PR has been merged and there are leftover rctl artifacts that need pruning.
  Use this skill any time the repo feels cluttered with leftover change artifacts,
  even if the user just says 'clean this up' in the context of rctl work. This skill
  ensures you classify each artifact before removal, check for orphaned projections,
  and preserve change history that has durable value — without it, agents tend to
  rm -rf indiscriminately and destroy historical records that future agents need.
---

# rctl-cleanup-pr

Remove leftover artifacts, stale active changes, duplicated guidance, and temporary notes from the repository after a change cycle — without losing anything that has durable historical value. The value of this skill over manual cleanup is classification discipline — it forces you to decide keep/archive/delete for every item and prevents destructive deletion of change history.

## Outputs
- List of files/directories removed or consolidated
- Brief summary of what was kept and why
- Updated active change list (if stale changes were archived or deleted)

## When not to use this skill
- A change is actively in progress and the user hasn't scoped the cleanup narrowly. Ask before touching active change directories.
- For archiving completed change records, use `rctl-archive-change` instead — this skill prunes residue, not full change histories.

## Mandatory checklist

Every cleanup pass must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Stale change detection** | Scan `rctl/changes/active/` for changes where all artifacts are `done` or the change was merged/abandoned. | Stale active changes mislead agents into thinking work is in progress |
| **Orphan projection check** | For every entry in `.claude/skills/` and `.agents/skills/`, verify a matching canonical exists in `src/rctl/skills/`. | Orphan projections trigger skills that no longer have valid instructions |
| **Duplicate guidance detection** | Search for the same instruction appearing in CLAUDE.md, AGENTS.md, zone manifests, and skill files. | Duplicates drift apart over time, causing agents to follow conflicting rules |
| **git rm tracking** | Use `git rm` (not `rm`) for every deletion so the removal is tracked in version history. | Untracked deletions leave ghost references in other files and break `git log` tracing |
| **Archive-before-delete rule** | Never delete a change directory — archive it first via `rctl-archive-change`. Only delete pure residue (temp files, orphan projections, .bak files). | Deleting change directories destroys the historical record that future agents need for context |

## What counts as residue

| Category | Examples | Action |
|----------|----------|--------|
| Stale active changes | Fully verified changes still in `active/` | Archive via `rctl-archive-change` |
| Orphaned projections | `.claude/skills/` or `.agents/skills/` entries with no matching `src/` canonical | Delete the projection |
| Duplicate guidance | Same instruction in CLAUDE.md, AGENTS.md, and a zone manifest | Consolidate to one source of truth |
| Temporary files | Scratch notes, draft patches, `.bak` files, empty `.gitkeep` in populated dirs | Delete |
| Generated artifacts | Stale `benchmark.json`, old `evaluator-report.md` from past iterations | Delete unless referenced by an archived change |

## Workflow

1. **Survey the repo.** Run `rctl gc . --dry-run` to get a machine view of orphans and stale references. Also list `rctl/changes/active/` to find changes that should be archived.

2. **Walk the mandatory checklist.** For each dimension in the table, run the specific check described. Build a list of items with their classification (keep/archive/delete) before touching any files.

3. **Archive stale changes first.** For every stale active change found in step 2, use the `rctl-archive-change` workflow to move it cleanly. Never `rm -rf` a change directory.

4. **Check for orphan projections.** For every skill directory in `.claude/skills/` and `.agents/skills/`, verify the canonical exists in `src/rctl/skills/`. Delete orphans with `git rm -r`.

5. **Consolidate duplicate guidance.** If the same instruction appears in multiple locations, pick the canonical location (prefer zone manifests for zone-specific rules, CLAUDE.md/AGENTS.md for repo-wide rules). Remove the copies and add a pointer if needed.

6. **Remove true residue.** Delete temporary files, `.bak` files, and stale generated artifacts using `git rm`. Before deleting any generated artifact, check whether it is referenced by an archived change's `evidence.md`.

7. **Record the cleanup.** For non-trivial cleanups (more than 2-3 files), write a brief note explaining what was removed and why, either in the commit message or in `status.md` of a related change.

## Failure patterns to avoid
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most, because agents default to `rm -rf` without classifying what has durable value.
- Deleting an active change directory without archiving it first — destroys the historical record.
- Removing evidence files from archived changes — these are the durable proof that work was done.
- Cleaning up projections that are actually symlinks to canonical sources (check with `ls -la` first).

## Example prompts
- Clean up stale rctl artifacts after this PR landed.
- Prune duplicate notes and close out finished temporary files.
- The repo feels messy after that big refactor — tidy up the rctl artifacts.
- Run rctl gc and clean up whatever it finds.
