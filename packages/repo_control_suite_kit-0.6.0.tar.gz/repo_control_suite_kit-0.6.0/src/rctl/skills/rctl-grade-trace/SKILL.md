---
name: rctl-grade-trace
description: Grade a workflow trace or change run for process compliance and quality.
  Use when the user asks 'did the agent follow the right process?', 'what went wrong
  in this change run?', 'why did the agent loop or thrash?', 'grade this run',
  'review the agent's workflow', or wants to review whether a completed change followed
  the rctl lifecycle correctly. Also use for post-mortem analysis of agent behavior
  during a change. This skill forces per-dimension scoring with evidence citations —
  without it, agents just look at the final diff and say "looks good" without examining
  whether the process was sound. If the user wants to understand why an agent session
  went well or poorly, this is the right skill.
---

# rctl-grade-trace

Grade a completed change run or agent workflow trace for process compliance and quality — understanding not just whether the output was correct, but whether the agent followed the right process to get there. The value of this skill over manual review is rigor — it forces per-dimension scoring with specific evidence citations, preventing the default behavior of glancing at the final diff and declaring it "fine."

## Outputs
- A grading note with scores across key dimensions
- Specific strengths and failures with evidence from the trace
- Concrete recommendations for improving future runs

## When not to use this skill
- For implementing changes — this skill reviews process, not code.
- When the change is still actively in progress — wait until it's done or paused.

## Mandatory checklist

Every trace grade must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Route selection** | List which skills were invoked and in what order. Compare against the optimal sequence for this change type. Flag skipped or out-of-order skills. | Wrong skill order causes rework; skipped skills cause missing artifacts |
| **Plan quality** | Read `plan.md`. Does it have concrete acceptance criteria, validation commands, and rollback steps? Could another agent resume from it? | Vague plans lead to divergent implementations and unverifiable "done" claims |
| **Implementation discipline** | Compare `status.md` timestamps against git log. Were status/evidence updated at each major step, or only at the end? | Stale status means a reset loses all progress context |
| **Verification quality** | Read `evidence.md`. For each acceptance criterion in the plan, is there a matching evidence entry with command output? | "Tests pass" without command output is not evidence |
| **Memory sync** | Check whether durable artifacts (CLAUDE.md, zone manifests, lessons) were updated with session learnings. | Unsynced learnings force the next agent to rediscover the same things |
| **Recovery resilience** | Read the `## Recovery point` section in `status.md`. Does it contain enough detail for a cold-start agent to resume without re-reading the codebase? | Recovery points missing "Next" or "Decisions" fields cause restart-from-scratch |

## Workflow

1. **Gather the trace.** Read all artifacts in the change directory: `change.yaml`, `plan.md`, `status.md`, `evidence.md`, and any `evaluator-report.md`. Also check git log for the commits associated with this change.

2. **Reconstruct the timeline.** From timestamps in `change.yaml`, `status.md`, and git history, understand the sequence of events. Note any resets, restarts, or long gaps.

3. **Walk the mandatory checklist.** For each dimension, assign a rating (`strong`, `adequate`, `weak`, or `missing`) and cite specific evidence — a line in status.md, a missing evidence entry, a commit that skipped verification. Do not assign a rating without a citation.

4. **Identify the critical failure** (if any). What single process improvement would have had the biggest impact on this run? This is the most actionable part of the grade.

5. **Write the grading note.** Structure it as:
   - One-line summary (e.g., "Good implementation discipline, weak verification")
   - Dimension scores table with evidence citations
   - Top 3 strengths with evidence
   - Top 3 failures with evidence
   - Single most impactful recommendation

## Failure patterns to avoid
- Focusing only on the final diff and ignoring process artifacts — the whole point of grading is to evaluate HOW the work was done.
- Giving generic feedback like "could be better" — every finding must cite a specific artifact or timestamp.
- Grading too harshly on dimensions the agent had no control over (e.g., missing plan when no plan skill was available).
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most, because the agent's default behavior is to produce shallow results.

## Example prompts
- Grade this change run and tell me where the agent loop went wrong.
- Review the trace to see whether the right rctl skills were used.
- Post-mortem on the failed deployment change — what process steps were skipped?
- How well did the agent handle the context reset during this implementation?
