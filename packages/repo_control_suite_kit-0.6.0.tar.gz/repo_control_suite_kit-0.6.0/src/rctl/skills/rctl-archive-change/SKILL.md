---
name: rctl-archive-change
description: Archive a completed or abandoned change cleanly. Use when a tracked change
  under rctl/changes/active/ is done, superseded, or paused and needs to be moved
  to archive/. Also use when the user says 'close out this change', 'we are done with
  this', 'clean up finished changes', 'mark this as done', 'this change is complete',
  or when rctl status shows stale active changes that should be archived. Even if the
  user just says 'archive it' or 'wrap this up' in the context of a change, use this
  skill. This skill ensures you cover disposition taxonomy, lifecycle field completeness,
  and breadcrumb links to successor changes that are easy to miss when archiving manually
  — even for changes that seem straightforward, use this skill because agents default
  to moving folders without updating metadata, leaving inconsistent state for future agents.
---

# rctl-archive-change

Move a change record from `rctl/changes/active/<id>/` to `rctl/changes/archive/<id>/` with a clear disposition so the active queue stays clean and the historical record remains useful to future agents. The value of this skill over manual archiving is rigor — it forces you to resolve every lifecycle artifact, pick a proper disposition, and leave breadcrumbs, not just `git mv` a folder.

## Outputs
- Change folder moved to `rctl/changes/archive/<id>/`
- `change.yaml` updated with final status, disposition, and timestamp
- `status.md` updated with a closing summary
- Breadcrumb notes in any successor change, if applicable

## When not to use this skill
- The change still has pending implementation or verification work and the user has not explicitly said to abandon it. Ask first.

## Mandatory checklist

Every archive operation must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Disposition selection** | Pick `completed`, `abandoned`, `superseded`, or `paused` from the taxonomy below. Never leave blank. | Future agents filter archived changes by disposition; a missing value breaks queries |
| **Lifecycle artifact resolution** | Every entry in `change.yaml -> lifecycle -> artifacts` must be `done` or `skipped` (with a note). No `in_progress` allowed. | An archived change with `in_progress` artifacts confuses agents into thinking work remains |
| **change.yaml field updates** | Set `status: archived`, `lifecycle.phase: archived`, `lifecycle.updated_at` to now, `lifecycle.next_step: none`, and add a `notes` entry with disposition + reason. | These fields are the machine-readable record; skipping any one produces inconsistent state |
| **status.md closing summary** | Add a closing section summarizing what happened and why the change is being archived. | Human-readable context for anyone reviewing the archive later |
| **Breadcrumb to successor** | If disposition is `superseded`, add a note in the successor's `plan.md` or `status.md` linking back to this change. | Without breadcrumbs, successor changes lose historical context about prior attempts |

## Dispositions

| Disposition   | When to use |
|---------------|-------------|
| `completed`   | All planned work is done and verified |
| `abandoned`   | Work was intentionally stopped before completion |
| `superseded`  | A newer change replaces this one (link to successor) |
| `paused`      | Work is deferred indefinitely but may resume (rare — prefer `abandoned` with notes) |

## Workflow

1. **Read the change record.** Open `change.yaml`, `status.md`, and `evidence.md` in the active change folder. Understand what was planned, what was done, and what remains.

2. **Walk the mandatory checklist.** For each dimension in the table above, verify the current state and note what needs updating. Do not proceed until you know the disposition and have confirmed lifecycle artifact resolution.

3. **Run `rctl status . <change-id>`** to confirm the CLI agrees the change is ready to archive. If it flags issues, resolve them before continuing.

4. **Choose a disposition** from the taxonomy table. If the change is being replaced, identify the successor change ID now — you will need it for breadcrumbs.

5. **Update `change.yaml`.** Set all five fields listed in the mandatory checklist: `status`, `lifecycle.phase`, `lifecycle.updated_at`, `lifecycle.next_step`, and `notes`. Verify no `in_progress` artifacts remain.

6. **Update `status.md`** with a closing section that states the disposition, summarizes what happened, and explains why the change is leaving the active queue.

7. **Move the folder:** `git mv rctl/changes/active/<id> rctl/changes/archive/<id>`. Never copy — only `git mv`.

8. **Leave breadcrumbs.** If a successor change exists, add a note in the successor's `plan.md` or `status.md` pointing back to this archived change. If no successor, skip this step and note why in the commit message.

## Failure patterns to avoid
- Treating the task as simple folder-moving and skipping the skill — this is exactly when the skill's value matters most, because the metadata updates are what future agents depend on.
- Archiving without updating `change.yaml` status fields — future agents will see inconsistent state.
- Using `paused` as a default instead of making a clear `completed` or `abandoned` decision.
- Forgetting to `git mv` — a manual copy leaves orphaned files in active/.

## Example prompts
- Archive this finished change and leave a clean final summary.
- Close out the abandoned migration with a clear note about why it stopped.
- We shipped the auth rewrite, mark that change as done and move it to archive.
- Clean up stale active changes — anything fully verified should be archived.
