---
name: rctl-validate-repo
description: Validate rctl structure, discovery wiring, and operational completeness.
  Without this skill, agents do a shallow file-existence check and miss that no agent
  can actually find or use the rctl installation. Use when the user asks 'is rctl set
  up correctly?', 'validate the control plane', 'check if rctl is working', 'run rctl
  validate', 'is the installation broken?', or suspects the rctl installation is broken
  or misconfigured. Also use after rctl init or rctl update to confirm everything is
  wired correctly. If something seems off with how agents discover or use rctl in this
  repo, start here.
---

# rctl-validate-repo

Validate the rctl installation across three layers — structure, discovery, and operations — so the user can pinpoint exactly what's broken or misconfigured instead of guessing. The skill forces three-layer validation with severity classification — without it, agents do a shallow file-existence check and miss that no agent can actually find or use the rctl installation.

## Outputs
- Layered validation report: structure, discovery, and operational results
- Per-layer pass/warn/fail status
- Specific fix recommendations for each failure

## When not to use this skill
- As a substitute for domain-specific tests (pytest, eslint, etc.) — this validates the rctl control plane, not the application.
- When the user wants a health score — use `rctl-score-repo` instead.

## Mandatory checklist

Complete every row. Do not skip any dimension even if it seems obvious.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| Structural file existence | Verify `rctl/`, `control-plane.yaml`, `root.zone.yaml` exist | Without structure, nothing else can work — stop early if critical items are missing |
| YAML validity | Parse every YAML file and confirm it loads without errors | A file that exists but contains invalid YAML will silently break all tooling |
| Discovery wiring per agent surface | For each target agent (Claude, Codex), confirm its guidance file references `rctl/control-plane/` | Structure can be perfect but if no agent can find it, the installation is useless |
| Skill projection currency | Diff each projected skill against its canonical `src/rctl/skills/` copy | Stale projections mean agents run outdated skill instructions |
| Validation command execution | Run every defined validation command and check exit codes | Commands that exist but fail give false confidence that checks are in place |
| Enforceable check execution | Run `rctl enforce .` and record the result | Enforcement is the last line of defense — it must actually work |

## Validation layers

### Layer 1: Structure

| Check | What to verify | Severity |
|-------|---------------|----------|
| `rctl/` directory exists | Basic installation | Critical |
| `control-plane.yaml` exists and parses as valid YAML | Machine-readable entrypoint | Critical |
| `root.zone.yaml` exists | Root zone configuration | Critical |
| `rctl/changes/active/` and `archive/` exist | Change tracking directories | Warning |
| `rctl/registry/` exists | Skill/command registration | Warning |
| Active change records have valid `change.yaml` | Correct lifecycle schema | Warning |

### Layer 2: Discovery

| Check | What to verify | Severity |
|-------|---------------|----------|
| CLAUDE.md references `rctl/control-plane/` | Claude Code can discover rctl | Critical (if Claude is a target) |
| AGENTS.md references `rctl/control-plane/` | Codex-compatible agents can discover rctl | Critical (if Codex is a target) |
| Skill projections exist in agent surfaces | `.claude/skills/` and/or `.agents/skills/` populated | Warning |
| Projected skills match canonical source | No stale copies | Warning |

### Layer 3: Operations

| Check | What to verify | Severity |
|-------|---------------|----------|
| At least one validation command is defined | Can run checks | Warning |
| Validation commands execute successfully | Commands aren't stale | Warning |
| `rctl enforce .` runs without errors | Enforceable checks work | Warning |
| At least one archived change exists | System has been used end-to-end | Info |

## Workflow

1. **Validate structure.** Check each structural item. Stop early if critical items are missing — the other layers can't work without structure.
2. **Validate discovery.** For each agent surface the repo targets, verify the discovery file exists and contains a reference to `rctl/control-plane/`. Check that skill projections are current by diffing against canonical source.
3. **Validate operations.** Run validation commands and enforceable checks. Check whether the change lifecycle has been used at least once end-to-end.
4. **Write the report.** Group findings by layer. For each finding: state what was checked, state the result (pass/warn/fail), and for failures explain what's wrong and how to fix it.
5. **Provide a summary.** One-line status per layer, plus the single most important action to take next.

## Failure patterns to avoid
- Collapsing all failures into one generic pass/fail — the user needs to know which layer is broken to fix it efficiently.
- Skipping discovery validation — structure can be perfect but if no agent can find it, it's useless.
- Reporting warnings as critical failures — not everything is equally important.
- Treating the task as simple and skipping the skill — this is exactly when the skill's value matters most.

## Example prompts
- Validate that this repo is really wired for Codex and Claude, not just structurally complete.
- Check whether the rctl install is stale or incomplete.
- I just ran rctl init — did everything get set up correctly?
- Something's off with how agents find the control plane. Validate the discovery wiring.
