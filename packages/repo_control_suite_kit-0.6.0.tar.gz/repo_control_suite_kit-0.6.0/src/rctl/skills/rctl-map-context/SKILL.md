---
name: rctl-map-context
description: Map repository context into clear zones, owners, source-of-truth links,
  and canonical terms. Use when filling in or completing zone YAML files (root.zone.yaml),
  adding owners, paths, canonical_terms, conventions, or key_docs to zone manifests.
  Also use when the user is new to a codebase and wants to understand its structure,
  when rctl score warns about 'bootstrap scaffolding' or missing zone metadata, when
  the user asks 'who owns what?', 'what are the main areas of this project?', or wants
  to set up zone ownership for agent routing. This skill ensures you cover ownership
  models, sub-zone boundaries, and routing decisions that are easy to miss when mapping
  zones with basic tools alone — even for tasks that seem straightforward, use this
  skill because manual zone mapping almost always produces shallow results that omit
  ownership semantics and cross-zone routing.
---

# rctl-map-context

Map a repository's actual structure into zone manifests that future agents can use to route work, check ownership, and avoid editing the wrong files. The value of this skill over manual mapping is depth — it forces you to analyze ownership models, sub-zone boundaries, and agent editability, not just list directories.

## Outputs
- Updated zone manifests with zones, sub-zones, owners, paths, canonical terms, conventions, invariants, and key docs
- An ownership annotation for each zone/sub-zone (who owns it, can agents edit it?)
- A routing decision guide or context-map note (optional but recommended for repos with 3+ zones)
- A concise list of unclear ownership or missing source-of-truth files

## When not to use this skill
- A tiny one-file edit where ownership is already clear and documented.

## Mandatory checklist

Every zone mapping must cover these dimensions. If you skip one, note why.

| Dimension | What to check | Why it matters |
|-----------|---------------|----------------|
| **Paths** | Which directories belong to this zone? Cross-check against actual `ls` output, not assumptions. | Phantom paths (listed but don't exist) cause agent confusion |
| **Ownership model** | For each path: is it repo-owned, rctl-owned, projection, shared, or generated? | Agents need to know if editing a file will be overwritten by a sync |
| **Sub-zones** | Are there meaningful sub-areas with different owners or rules? | Flat zone maps force agents to treat everything the same |
| **Canonical terms** | What domain vocabulary should agents use consistently? | Inconsistent naming causes search failures and ambiguous routing |
| **Conventions** | What patterns must code in this zone follow? | Without explicit conventions, each agent invents its own |
| **Invariants** | What rules must always hold? Can they be machine-checked? | Invariants without validation commands are wishful thinking |
| **Validation commands** | What commands verify this zone is healthy? | Zones without validation can't be scored or verified |
| **Key docs** | Where does authoritative documentation live? | Agents reading the wrong doc make wrong decisions |
| **Agent editability** | For each sub-zone: can an agent freely edit, edit with review, or not edit at all? | Prevents agents from modifying generated/projection files |

## Workflow

1. **Read existing context.** Open `control-plane.yaml`, `root.zone.yaml` (or equivalent), and any existing zone manifests. Also read CLAUDE.md, AGENTS.md, and README for project-level context.

2. **Explore actual structure.** Run `ls` on the repo root and key directories. Compare against paths listed in zone manifests. Flag any phantom paths (listed but missing) or undocumented directories.

3. **Walk the mandatory checklist.** For each zone and sub-zone, fill in every dimension from the table above. Don't skip ownership model — this is the highest-value dimension that manual mapping almost always misses.

4. **Classify ownership.** For each path, determine:
   - **repo-owned** — the project's own code, freely editable
   - **rctl-owned** — managed by rctl, edited via rctl commands only
   - **projection** — copied from a canonical source, never edit directly
   - **shared** — has a managed section (e.g., CLAUDE.md), edit only the non-managed parts
   - **generated** — output of a build/codegen step, do not edit

5. **Write or update zone manifests.** Apply findings to `root.zone.yaml` and any child zone files. For every field you set, ensure it reflects observed reality, not assumptions. Mark uncertain entries with a `# TBD` comment.

6. **Produce a routing guide.** For repos with 3+ zones or complex ownership, write a brief routing note (e.g., `rctl/docs/context-map/zone-routing.md`) that answers: "Given a task, which zone owns it and can an agent edit the relevant files?"

7. **Verify cross-references.** Ensure paths in zone manifests exist, key_docs point to real files, and validation commands actually run.

## Failure patterns to avoid
- Listing directories without checking ownership model — this produces a zone map that looks complete but doesn't tell agents whether they can edit the files.
- Treating the task as "simple directory mapping" and skipping the checklist — this is exactly when the skill's value matters most, because the agent's default behavior is to produce shallow results.
- Inventing owners or terms without noting uncertainty — mark unknowns as TBD so the next agent knows what still needs human input.

## Example prompts
- Map the main domains in this monorepo before we touch anything.
- Create a zone map for this service so future agents stop guessing where truth lives.
- Help me complete root.zone.yaml based on the actual project layout.
- Who owns what in this repo? Set up zone ownership for agent routing.
