from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import __version__
from .adapters import detect_stack
from .catalog import agent_names, profile_names, selected_skill_names
from .merge import has_block, upsert_block, write_patch
from .scaffold import build_files, build_managed_blocks
from .state import manifest_path
from .utils import read_json, read_text, read_yaml, sha256_text, write_json, write_text


PROJECTION_PREFIXES = (
    ".agents/",
    ".claude/",
    ".cursor/",
    ".windsurf/",
)
EXECUTABLE_FILES = {
    ".git/hooks/pre-commit",
}


def normalize_agents(value: str | list[str] | None) -> list[str]:
    if value is None:
        return ["codex", "claude"]
    if isinstance(value, list):
        raw = []
        for item in value:
            raw.extend(item.split(","))
    else:
        raw = value.split(",")
    valid = set(agent_names())
    ordered = []
    for item in raw:
        name = item.strip().lower()
        if name and name in valid and name not in ordered:
            ordered.append(name)
    return ordered


def normalize_skills(value: str | list[str] | None) -> list[str] | None:
    if value in (None, "", []):
        return None
    if isinstance(value, list):
        raw = []
        for item in value:
            raw.extend(item.split(","))
    else:
        raw = value.split(",")
    ordered = []
    for item in raw:
        name = item.strip()
        if name and name not in ordered:
            ordered.append(name)
    return ordered or None


def resolve_hook_target(repo_path: Path, hooks: str | None, existing_target: str | None = None) -> str | None:
    if hooks != "pre-commit":
        return None
    if existing_target in {"pre-commit-config", "git-hook"}:
        return existing_target
    if (repo_path / ".pre-commit-config.yaml").exists():
        return "pre-commit-config"
    return "git-hook"


def default_file_ownership(rel: str) -> str:
    if rel.startswith(PROJECTION_PREFIXES):
        return "projection"
    return "rctl-owned"


def current_file_ownership(managed_files: dict[str, dict[str, str]], rel: str) -> str:
    entry = managed_files.get(rel, {})
    if not isinstance(entry, dict):
        return default_file_ownership(rel)
    return entry.get("ownership", default_file_ownership(rel))


def should_promote_to_repo_owned(rel: str, layout_dir: str) -> bool:
    zone_prefix = f"{layout_dir}/control-plane/zones/"
    return rel.startswith(zone_prefix) and rel.endswith(".yaml")


def _load_project_context_config(repo_path: Path, layout_dir: str) -> dict[str, Any]:
    config: dict[str, Any] = {}
    control_plane_path = repo_path / layout_dir / "control-plane" / "control-plane.yaml"
    if control_plane_path.exists():
        control_plane = read_yaml(control_plane_path)
        if isinstance(control_plane, dict):
            stack = control_plane.get("stack")
            if isinstance(stack, str) and stack:
                config["stack"] = stack
            stack_summary = control_plane.get("stack_summary")
            if isinstance(stack_summary, str) and stack_summary:
                config["stack_summary"] = stack_summary
            context = control_plane.get("context")
            config["control_plane_context"] = context if isinstance(context, dict) else {}

    root_zone_path = repo_path / layout_dir / "control-plane" / "zones" / "root.zone.yaml"
    if root_zone_path.exists():
        zone = read_yaml(root_zone_path)
        if isinstance(zone, dict):
            context = zone.get("context")
            config["zone_context"] = context if isinstance(context, dict) else {}
            invariants = zone.get("invariants")
            config["zone_invariants"] = invariants if isinstance(invariants, list) else []
            validation = zone.get("validation")
            if isinstance(validation, dict):
                commands = validation.get("commands")
                config["validation_commands"] = commands if isinstance(commands, list) else []
            else:
                config["validation_commands"] = []
            enforceable = zone.get("enforceable")
            config["enforceable_count"] = len(enforceable) if isinstance(enforceable, list) else 0

    return config


def build_init_config(
    repo_path: Path,
    *,
    repo_name: str | None = None,
    stack: str = "auto",
    profile: str = "core",
    agents: str | list[str] | None = None,
    ci: str | None = None,
    hooks: str | None = None,
    layout_dir: str = "rctl",
    explicit_skills: str | list[str] | None = None,
) -> dict[str, Any]:
    if profile not in profile_names() and profile != "custom":
        raise ValueError(f"Unknown profile: {profile}")
    normalized_agents = normalize_agents(agents)
    if not normalized_agents:
        raise ValueError("At least one agent must be selected.")
    resolved_stack = detect_stack(repo_path) if stack == "auto" else stack
    normalized_skills = normalize_skills(explicit_skills)
    effective_profile = "core" if profile == "custom" and not normalized_skills else profile
    skill_names = selected_skill_names(effective_profile, normalized_skills)
    config = {
        "repo_name": repo_name or repo_path.name,
        "stack": resolved_stack,
        "profile": profile,
        "effective_profile": effective_profile,
        "agents": normalized_agents,
        "ci": ci,
        "hooks": hooks,
        "hook_target": resolve_hook_target(repo_path, hooks),
        "layout_dir": layout_dir,
        "explicit_skills": normalized_skills,
        "selected_skills": skill_names,
    }
    config.update(_load_project_context_config(repo_path, layout_dir))
    return config


def _write_normal_files(
    repo_path: Path,
    files: dict[str, str],
    *,
    managed_files: dict[str, dict[str, str]],
    layout_dir: str,
    force: bool,
    init_mode: bool,
) -> dict[str, list[str]]:
    created: list[str] = []
    refreshed: list[str] = []
    skipped: list[str] = []
    conflicts: list[str] = []
    promoted: list[str] = []

    def write_normal_file(target: Path, rel: str, content: str) -> None:
        write_text(target, content)
        if rel in EXECUTABLE_FILES:
            target.chmod(target.stat().st_mode | 0o111)

    for rel, content in files.items():
        target = repo_path / rel
        new_hash = sha256_text(content)
        old_hash = managed_files.get(rel, {}).get("sha256")
        ownership = current_file_ownership(managed_files, rel)

        if init_mode:
            existed_before = target.exists()
            if existed_before and not force:
                skipped.append(rel)
                continue
            write_normal_file(target, rel, content)
            if existed_before:
                refreshed.append(rel)
            else:
                created.append(rel)
            managed_files[rel] = {"sha256": new_hash, "ownership": ownership}
            continue

        if not target.exists():
            if ownership == "repo-owned":
                skipped.append(rel)
                continue
            write_normal_file(target, rel, content)
            created.append(rel)
            managed_files[rel] = {"sha256": new_hash, "ownership": ownership}
            continue

        current_hash = sha256_text(read_text(target))
        if ownership == "repo-owned":
            skipped.append(rel)
            managed_files[rel] = {"sha256": current_hash, "ownership": ownership}
            continue

        if ownership == "projection":
            write_normal_file(target, rel, content)
            refreshed.append(rel)
            managed_files[rel] = {"sha256": new_hash, "ownership": ownership}
            continue

        if force or (old_hash is not None and current_hash == old_hash):
            write_normal_file(target, rel, content)
            refreshed.append(rel)
            managed_files[rel] = {"sha256": new_hash, "ownership": ownership}
        elif should_promote_to_repo_owned(rel, layout_dir):
            skipped.append(rel)
            promoted.append(rel)
            managed_files[rel] = {"sha256": current_hash, "ownership": "repo-owned"}
        else:
            conflict_target = target.with_name(target.name + ".rctl.new")
            write_text(conflict_target, content)
            conflicts.append(str(conflict_target.relative_to(repo_path)))

    return {
        "created": created,
        "refreshed": refreshed,
        "skipped": skipped,
        "conflicts": conflicts,
        "promoted": promoted,
    }


def _write_blocks(
    repo_path: Path,
    blocks: dict[str, dict[str, Any]],
    *,
    managed_blocks: dict[str, dict[str, str]],
    force: bool,
    init_mode: bool,
) -> dict[str, list[str]]:
    created: list[str] = []
    merged: list[str] = []
    updated: list[str] = []
    patches: list[str] = []

    for rel, block in blocks.items():
        target = repo_path / rel
        key = f"{rel}#{block['block_name']}"
        style = block["style"]
        content = block["content"]
        content_hash = sha256_text(content)

        if not init_mode and target.exists():
            text = read_text(target)
            indent = block.get("indent", "")
            if not has_block(text, block["block_name"], style=style, indent=indent) and key in managed_blocks and not force:
                patch = write_patch(target, block["block_name"], content, style=style, indent=indent)
                patches.append(str(patch.relative_to(repo_path)))
                continue

        result = upsert_block(
            target,
            block["block_name"],
            content,
            style=style,
            indent=block.get("indent", ""),
            preamble=block.get("preamble"),
            create_if_missing=True,
        )
        if result.status == "created":
            created.append(rel)
        elif result.status == "updated":
            updated.append(rel)
        else:
            merged.append(rel)
        managed_blocks[key] = {"sha256": content_hash, "style": style}

    return {
        "created": created,
        "merged": merged,
        "updated": updated,
        "patches": patches,
    }


def _manifest_base(repo_path: Path, config: dict[str, Any]) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    return {
        "suite": "rctl",
        "version": __version__,
        "installed_at": now,
        "updated_at": now,
        "repo_name": config["repo_name"],
        "stack": config["stack"],
        "profile": config["profile"],
        "effective_profile": config["effective_profile"],
        "agents": config["agents"],
        "ci": config.get("ci"),
        "hooks": config.get("hooks"),
        "hook_target": config.get("hook_target"),
        "layout_dir": config["layout_dir"],
        "selected_skills": config["selected_skills"],
        "managed_files": {},
        "managed_blocks": {},
    }


def init_repo(
    repo_path: Path,
    *,
    repo_name: str | None = None,
    stack: str = "auto",
    profile: str = "core",
    agents: str | list[str] | None = None,
    ci: str | None = None,
    hooks: str | None = None,
    layout_dir: str = "rctl",
    explicit_skills: str | list[str] | None = None,
    force: bool = False,
) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    config = build_init_config(
        repo_path,
        repo_name=repo_name,
        stack=stack,
        profile=profile,
        agents=agents,
        ci=ci,
        hooks=hooks,
        layout_dir=layout_dir,
        explicit_skills=explicit_skills,
    )
    files = build_files(config)
    blocks = build_managed_blocks(config)

    manifest = _manifest_base(repo_path, config)
    normal = _write_normal_files(
        repo_path,
        files,
        managed_files=manifest["managed_files"],
        layout_dir=config["layout_dir"],
        force=force,
        init_mode=True,
    )
    block_summary = _write_blocks(
        repo_path,
        blocks,
        managed_blocks=manifest["managed_blocks"],
        force=force,
        init_mode=True,
    )
    write_json(manifest_path(repo_path), manifest)
    return {
        "repo": str(repo_path),
        "stack": config["stack"],
        "profile": config["profile"],
        "effective_profile": config["effective_profile"],
        "agents": config["agents"],
        "ci": config.get("ci"),
        "hooks": config.get("hooks"),
        "selected_skills": config["selected_skills"],
        "layout_dir": config["layout_dir"],
        "files": normal,
        "blocks": block_summary,
        "manifest": str(manifest_path(repo_path)),
    }


def update_repo(repo_path: Path, *, force: bool = False) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    manifest_file = manifest_path(repo_path)
    if not manifest_file.exists():
        raise FileNotFoundError("No .rctl/manifest.json found. Run `rctl init` first.")

    manifest = read_json(manifest_file)
    config = {
        "repo_name": manifest.get("repo_name", repo_path.name),
        "stack": manifest.get("stack", detect_stack(repo_path)),
        "profile": manifest.get("profile", "core"),
        "effective_profile": manifest.get("effective_profile", manifest.get("profile", "core")),
        "agents": manifest.get("agents", ["codex", "claude"]),
        "ci": manifest.get("ci"),
        "hooks": manifest.get("hooks"),
        "hook_target": resolve_hook_target(
            repo_path,
            manifest.get("hooks"),
            manifest.get("hook_target"),
        ),
        "layout_dir": manifest.get("layout_dir", "rctl"),
        "explicit_skills": manifest.get("selected_skills"),
        "selected_skills": manifest.get("selected_skills", []),
    }
    config.update(_load_project_context_config(repo_path, config["layout_dir"]))

    files = build_files(config)
    blocks = build_managed_blocks(config)

    normal = _write_normal_files(
        repo_path,
        files,
        managed_files=manifest.setdefault("managed_files", {}),
        layout_dir=config["layout_dir"],
        force=force,
        init_mode=False,
    )
    block_summary = _write_blocks(
        repo_path,
        blocks,
        managed_blocks=manifest.setdefault("managed_blocks", {}),
        force=force,
        init_mode=False,
    )
    manifest["version"] = __version__
    manifest["updated_at"] = datetime.now(timezone.utc).isoformat()
    write_json(manifest_file, manifest)

    return {
        "repo": str(repo_path),
        "profile": config["profile"],
        "agents": config["agents"],
        "selected_skills": config["selected_skills"],
        "layout_dir": config["layout_dir"],
        "files": normal,
        "blocks": block_summary,
        "manifest": str(manifest_file),
    }
