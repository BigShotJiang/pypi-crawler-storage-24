from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .adapters import detect_stack
from .catalog import selected_skill_names
from .utils import read_json, read_text, read_yaml, sha256_text, write_json


def manifest_path(repo_path: Path) -> Path:
    return repo_path / ".rctl" / "manifest.json"


def _isoformat_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sync_manifest_file_hashes(repo_path: Path, paths: list[Path]) -> None:
    repo_path = repo_path.resolve()
    manifest_file = manifest_path(repo_path)
    if not manifest_file.exists():
        return

    manifest = read_json(manifest_file)
    managed_files = manifest.get("managed_files")
    if not isinstance(managed_files, dict):
        return

    updated = False
    for path in paths:
        resolved = path.resolve()
        if not resolved.exists():
            continue
        try:
            rel = str(resolved.relative_to(repo_path))
        except ValueError:
            continue
        entry = managed_files.get(rel)
        if not isinstance(entry, dict):
            continue
        entry["sha256"] = sha256_text(read_text(resolved))
        updated = True

    if updated:
        manifest["updated_at"] = _isoformat_now()
        write_json(manifest_file, manifest)


def layout_dir_from_repo(repo_path: Path) -> str:
    candidates = ["rctl"]
    for name in candidates:
        if (repo_path / name / "control-plane" / "control-plane.yaml").exists():
            return name
    manifest = manifest_path(repo_path)
    if manifest.exists():
        return read_json(manifest).get("layout_dir", "rctl")
    return "rctl"


def load_repo_state(repo_path: Path) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    manifest_file = manifest_path(repo_path)
    if manifest_file.exists():
        manifest = read_json(manifest_file)
        manifest["repo"] = str(repo_path)
        return manifest

    layout_dir = layout_dir_from_repo(repo_path)
    control_plane = repo_path / layout_dir / "control-plane" / "control-plane.yaml"
    if control_plane.exists():
        cp = read_yaml(control_plane)
        skills_registry = repo_path / layout_dir / "registry" / "skills.yaml"
        selected = []
        if skills_registry.exists():
            selected = read_yaml(skills_registry).get("selected_skills", [])
        return {
            "repo": str(repo_path),
            "repo_name": cp.get("repo_name", repo_path.name),
            "stack": cp.get("stack", detect_stack(repo_path)),
            "profile": cp.get("profile", "core"),
            "agents": cp.get("agents", []),
            "layout_dir": cp.get("layout_dir", layout_dir),
            "selected_skills": selected or selected_skill_names(cp.get("profile", "core")),
            "managed_files": {},
            "managed_blocks": {},
        }

    raise FileNotFoundError("No rctl manifest or control-plane file found. Run `rctl init` first.")
