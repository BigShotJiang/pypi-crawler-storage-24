from __future__ import annotations

from pathlib import Path
from typing import Any

from .catalog import selected_commands
from .merge import has_block
from .state import load_repo_state, sync_manifest_file_hashes
from .utils import read_json, read_text, read_yaml, write_json, write_text


def _avg(values: list[float | None]) -> float:
    usable = [value for value in values if value is not None]
    if not usable:
        return 0.0
    return round(sum(usable) / len(usable), 3)


def _round(value: float) -> float:
    return round(value, 3)


def _routing_score(repo_path: Path, state: dict[str, Any]) -> float:
    layout = state["layout_dir"]
    score = 0.0
    agents_path = repo_path / "AGENTS.md"
    if agents_path.exists():
        text = read_text(agents_path)
        if f"{layout}/control-plane/control-plane.yaml" in text:
            score += 0.5
        if has_block(text, "routing", style="markdown"):
            score += 0.25
    if "claude" not in state.get("agents", []):
        score += 0.25
    else:
        claude = repo_path / "CLAUDE.md"
        if claude.exists():
            text = read_text(claude)
            if f"{layout}/control-plane/control-plane.yaml" in text:
                score += 0.125
            if has_block(text, "routing", style="markdown"):
                score += 0.125
    return _round(score)


def _control_plane_score(repo_path: Path, state: dict[str, Any]) -> float:
    zone = read_yaml(repo_path / state["layout_dir"] / "control-plane" / "zones" / "root.zone.yaml")
    score = 0.0
    if zone.get("source_of_truth"):
        score += 0.2
    if zone.get("invariants"):
        score += 0.2
    if zone.get("validation", {}).get("commands") is not None:
        score += 0.2
    if zone.get("permissions"):
        score += 0.2
    if zone.get("cleanup"):
        score += 0.2
    return _round(score)


def _skills_source_score(repo_path: Path, state: dict[str, Any]) -> float:
    layout = state["layout_dir"]
    if not state.get("selected_skills"):
        return 0.0
    total = len(state["selected_skills"])
    good = 0
    for name in state["selected_skills"]:
        if (repo_path / layout / "skills-src" / name / "SKILL.md").exists() and (repo_path / layout / "skills-src" / name / "evals" / "evals.json").exists():
            good += 1
    return _round(good / total)


def _registry_score(repo_path: Path, state: dict[str, Any]) -> float:
    layout = state["layout_dir"]
    commands = read_yaml(repo_path / layout / "registry" / "commands.yaml").get("commands", [])
    command_names = {item["skill"] for item in commands}
    expected = {item["skill"] for item in selected_commands(state.get("effective_profile", state["profile"]), state.get("selected_skills"))}
    skills_registry = read_yaml(repo_path / layout / "registry" / "skills.yaml").get("selected_skills", [])
    score = 0.0
    if command_names == expected:
        score += 0.6
    if sorted(skills_registry) == sorted(state.get("selected_skills", [])):
        score += 0.4
    return _round(score)


def _docs_score(repo_path: Path, state: dict[str, Any]) -> float:
    layout = state["layout_dir"]
    required = [
        "project-origin.md",
        "thinking-process.md",
        "agent-first.md",
        "adapters.md",
        "cli-spec.md",
        "roadmap.md",
    ]
    good = sum(1 for name in required if (repo_path / layout / "docs" / name).exists())
    return _round(good / len(required))


def _discovery_score(repo_path: Path, state: dict[str, Any]) -> float:
    checks = []
    layout = state["layout_dir"]
    if (repo_path / "AGENTS.md").exists() and f"{layout}/control-plane/control-plane.yaml" in read_text(repo_path / "AGENTS.md"):
        checks.append(1.0)
    else:
        checks.append(0.0)

    for agent in state.get("agents", []):
        if agent == "codex":
            ok = all((repo_path / ".agents" / "skills" / name / "SKILL.md").exists() for name in state["selected_skills"])
            checks.append(1.0 if ok else 0.0)
        elif agent == "claude":
            ok = (repo_path / "CLAUDE.md").exists() and all((repo_path / ".claude" / "skills" / name / "SKILL.md").exists() for name in state["selected_skills"])
            checks.append(1.0 if ok else 0.0)
        elif agent == "cursor":
            ok = (repo_path / ".cursor" / "rules" / "rctl-routing.mdc").exists() and all((repo_path / ".cursor" / "skills" / name / "SKILL.md").exists() for name in state["selected_skills"])
            checks.append(1.0 if ok else 0.0)
        elif agent == "windsurf":
            ok = (repo_path / ".windsurf" / "rules" / "rctl-routing.md").exists() and all((repo_path / ".windsurf" / "skills" / name / "SKILL.md").exists() for name in state["selected_skills"])
            checks.append(1.0 if ok else 0.0)
    return _avg(checks)


def _command_delivery_score(repo_path: Path, state: dict[str, Any]) -> float | None:
    checks = []
    commands = selected_commands(state.get("effective_profile", state["profile"]), state.get("selected_skills"))
    if "claude" in state.get("agents", []):
        ok = all((repo_path / ".claude" / "commands" / f"{item['alias'].replace(':', '-')}.md").exists() for item in commands)
        checks.append(1.0 if ok else 0.0)
    if "windsurf" in state.get("agents", []):
        ok = all((repo_path / ".windsurf" / "workflows" / f"{item['alias'].replace(':', '-')}.md").exists() for item in commands)
        checks.append(1.0 if ok else 0.0)
    if not checks:
        return None
    return _avg(checks)


def _validation_evidence_score(repo_path: Path, state: dict[str, Any]) -> float:
    path = repo_path / state["layout_dir"] / "docs" / "quality" / "validation-report.json"
    if not path.exists():
        return 0.0
    data = read_json(path)
    return 1.0 if data.get("passed") else 0.0


def _enforcement_score(repo_path: Path, state: dict[str, Any]) -> float:
    layout = state["layout_dir"]
    zone = read_yaml(repo_path / layout / "control-plane" / "zones" / "root.zone.yaml")
    enforceable = zone.get("enforceable", [])
    if not enforceable:
        return 0.0

    report_path = repo_path / layout / "docs" / "quality" / "enforce-report.json"
    if not report_path.exists():
        return 0.25

    report = read_json(report_path)
    if not report:
        return 0.25
    return 1.0 if report.get("passed") else 0.5


def _load_gc_report(repo_path: Path, state: dict[str, Any]) -> dict[str, Any] | None:
    path = repo_path / state["layout_dir"] / "docs" / "quality" / "gc-report.json"
    if not path.exists():
        return None
    try:
        data = read_json(path)
    except (OSError, TypeError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _gc_issue_severities(report: dict[str, Any]) -> list[str]:
    issues = report.get("issues", [])
    if not isinstance(issues, list):
        return []
    severities: list[str] = []
    for item in issues:
        if isinstance(item, dict):
            severities.append(str(item.get("severity", "error")))
    return severities


def _entropy_score(repo_path: Path, state: dict[str, Any]) -> float:
    report = _load_gc_report(repo_path, state)
    if report is None:
        return 0.0
    total_issues = report.get("total_issues")
    if isinstance(total_issues, int) and total_issues == 0:
        return 1.0

    severities = _gc_issue_severities(report)
    if not severities:
        return 1.0 if report.get("issues") == [] else 0.25
    return 0.25 if any(severity == "error" for severity in severities) else 0.5


def _entropy_clean(repo_path: Path, state: dict[str, Any]) -> bool:
    report = _load_gc_report(repo_path, state)
    if report is None:
        return False
    total_issues = report.get("total_issues")
    if isinstance(total_issues, int) and total_issues == 0:
        return True

    severities = _gc_issue_severities(report)
    if not severities:
        return report.get("issues") == []
    return not any(severity == "error" for severity in severities)


def _history_score(repo_path: Path, state: dict[str, Any]) -> float:
    archive = repo_path / state["layout_dir"] / "changes" / "archive"
    if not archive.exists():
        return 0.0
    return 1.0 if any(p.name == "change.yaml" for p in archive.rglob("change.yaml")) else 0.0


def _lifecycle_score(repo_path: Path, state: dict[str, Any]) -> float:
    layout = state["layout_dir"]
    score = 0.0

    template = read_yaml(repo_path / layout / "control-plane" / "templates" / "change.yaml")
    if template.get("lifecycle"):
        score += 1 / 3

    archive_dir = repo_path / layout / "changes" / "archive"
    archived = [read_yaml(path) for path in archive_dir.rglob("change.yaml")] if archive_dir.exists() else []
    if archived:
        score += (sum(1 for item in archived if item.get("lifecycle")) / len(archived)) * (1 / 3)

    active_dir = repo_path / layout / "changes" / "active"
    active = [read_yaml(path) for path in active_dir.rglob("change.yaml")] if active_dir.exists() else []
    if active:
        score += (sum(1 for item in active if item.get("lifecycle")) / len(active)) * (1 / 3)
    else:
        score += 1 / 3  # vacuously true: no active changes violate the rule

    return _round(score)


def _zone_readiness_score(repo_path: Path, state: dict[str, Any]) -> float:
    zone = read_yaml(repo_path / state["layout_dir"] / "control-plane" / "zones" / "root.zone.yaml")
    score = 0.0
    if zone.get("bootstrap_state") != "scaffolded":
        score += 0.25
    if zone.get("owners"):
        score += 0.25
    if zone.get("canonical_terms"):
        score += 0.25
    if zone.get("validation", {}).get("commands"):
        score += 0.25
    return _round(score)


def score_repo(repo_path: Path) -> dict[str, Any]:
    repo_path = repo_path.resolve()
    state = load_repo_state(repo_path)

    structural = {
        "routing": _routing_score(repo_path, state),
        "control_plane": _control_plane_score(repo_path, state),
        "skills_source": _skills_source_score(repo_path, state),
        "registry": _registry_score(repo_path, state),
        "docs": _docs_score(repo_path, state),
        "change_scaffold": 1.0 if (repo_path / state["layout_dir"] / "changes" / "active").exists() and (repo_path / state["layout_dir"] / "changes" / "archive").exists() else 0.0,
    }
    operational = {
        "discovery": _discovery_score(repo_path, state),
        "command_delivery": _command_delivery_score(repo_path, state),
        "validation_evidence": _validation_evidence_score(repo_path, state),
        "history": _history_score(repo_path, state),
        "zone_readiness": _zone_readiness_score(repo_path, state),
        "enforcement": _enforcement_score(repo_path, state),
        "entropy": _entropy_score(repo_path, state),
        "change_lifecycle": _lifecycle_score(repo_path, state),
    }

    structural_score = _avg(list(structural.values()))
    operational_score = _avg(list(operational.values()))

    gates = {
        "discovery_connected": operational["discovery"] >= 1.0,
        "validation_evidence_present": operational["validation_evidence"] >= 1.0,
        "zone_named": operational["zone_readiness"] >= 0.75,
        "enforcement_defined": operational["enforcement"] > 0.0,
        "enforcement_passing": operational["enforcement"] >= 1.0,
        "entropy_clean": _entropy_clean(repo_path, state),
    }

    weighted = _round(structural_score * 0.45 + operational_score * 0.55)
    notes: list[str] = []

    if not gates["discovery_connected"]:
        notes.append("Not all selected assistants appear fully wired to the control plane.")
    if not gates["validation_evidence_present"]:
        notes.append("No passing validation artifact has been written yet.")
    if not gates["enforcement_defined"]:
        notes.append("No enforceable checks are defined in the root zone yet.")
    elif operational["enforcement"] == 0.25:
        notes.append("Enforceable checks are defined but no enforce report has been written yet.")
    elif operational["enforcement"] == 0.5:
        notes.append("Latest enforce report is failing.")
    if operational["entropy"] == 0.0:
        notes.append("No gc report has been written yet.")
    elif operational["entropy"] == 0.5:
        notes.append("Latest gc report contains warning-level entropy issues.")
    elif operational["entropy"] == 0.25:
        notes.append("Latest gc report contains error-level entropy issues.")
    if operational["history"] == 0.0:
        notes.append("No archived change history was found yet.")
    if operational["zone_readiness"] < 0.75:
        notes.append("Root zone still looks like bootstrap scaffolding rather than mature repo metadata.")
    if operational["change_lifecycle"] < 1.0:
        notes.append("Lifecycle metadata is only partially adopted across templates and change records.")

    if not gates["discovery_connected"]:
        recommendation = "bootstrap"
    elif (
        weighted >= 0.8
        and gates["validation_evidence_present"]
        and gates["enforcement_defined"]
        and gates["enforcement_passing"]
        and gates["entropy_clean"]
    ):
        recommendation = "ready-low-risk"
    else:
        recommendation = "watch"

    return {
        "repo": str(repo_path),
        "layout_dir": state["layout_dir"],
        "profile": state.get("profile"),
        "agents": state.get("agents", []),
        "selected_skills": state.get("selected_skills", []),
        "structural": structural,
        "operational": operational,
        "structural_score": structural_score,
        "operational_score": operational_score,
        "weighted_score": weighted,
        "gates": gates,
        "recommendation": recommendation,
        "notes": notes,
    }


def format_score_markdown(score: dict[str, Any]) -> str:
    lines = [
        "# Scorecard",
        "",
        f"- structural_score: `{score['structural_score']}`",
        f"- operational_score: `{score['operational_score']}`",
        f"- weighted_score: `{score['weighted_score']}`",
        f"- recommendation: `{score['recommendation']}`",
        "",
        "## Gates",
        "",
    ]
    for key, value in score["gates"].items():
        lines.append(f"- {key}: `{value}`")
    lines.extend(["", "## Structural", ""])
    for key, value in score["structural"].items():
        lines.append(f"- {key}: `{value}`")
    lines.extend(["", "## Operational", ""])
    for key, value in score["operational"].items():
        lines.append(f"- {key}: `{value}`")
    if score.get("notes"):
        lines.extend(["", "## Notes", ""])
        for note in score["notes"]:
            lines.append(f"- {note}")
    return "\n".join(lines).rstrip() + "\n"


def write_score_artifact(repo_path: Path, score: dict[str, Any]) -> tuple[Path, Path]:
    repo_path = repo_path.resolve()
    layout = score["layout_dir"]
    json_path = repo_path / layout / "docs" / "quality" / "scorecard.json"
    md_path = repo_path / layout / "docs" / "quality" / "scorecard.md"
    write_json(json_path, score)
    write_text(md_path, format_score_markdown(score))
    sync_manifest_file_hashes(repo_path, [md_path])
    return json_path, md_path
