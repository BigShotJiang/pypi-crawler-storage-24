from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .utils import read_text, write_text


@dataclass
class BlockMergeResult:
    path: str
    status: str
    block_name: str
    conflict_path: str | None = None


def _markers(block_name: str, style: str, indent: str = "") -> tuple[str, str]:
    if style == "hash":
        return (f"{indent}# rctl:block:start {block_name}", f"{indent}# rctl:block:end {block_name}")
    return (f"{indent}<!-- rctl:block:start {block_name} -->", f"{indent}<!-- rctl:block:end {block_name} -->")


def has_block(text: str, block_name: str, style: str = "markdown", indent: str = "") -> bool:
    start, end = _markers(block_name, style, indent=indent)
    return start in text and end in text


def wrap_block(block_name: str, content: str, style: str = "markdown", indent: str = "") -> str:
    start, end = _markers(block_name, style, indent=indent)
    body = content.strip("\n") + "\n"
    return f"{start}\n{body}{end}\n"


def upsert_block(
    path: Path,
    block_name: str,
    content: str,
    *,
    style: str = "markdown",
    indent: str = "",
    preamble: str | None = None,
    create_if_missing: bool = True,
) -> BlockMergeResult:
    wrapped = wrap_block(block_name, content, style=style, indent=indent)
    if not path.exists():
        if not create_if_missing:
            return BlockMergeResult(path=str(path), status="missing", block_name=block_name)
        text = (preamble.strip() + "\n\n" if preamble else "") + wrapped
        write_text(path, text)
        return BlockMergeResult(path=str(path), status="created", block_name=block_name)

    text = read_text(path)
    start, end = _markers(block_name, style, indent=indent)
    if start in text and end in text:
        before, rest = text.split(start, 1)
        _, after = rest.split(end, 1)
        replacement = wrapped.rstrip("\n")
        if before and not before.endswith("\n"):
            before += "\n"
        if after and not after.startswith("\n"):
            after = "\n" + after
        new_text = before + replacement + after
        write_text(path, new_text.strip("\n") + "\n")
        return BlockMergeResult(path=str(path), status="updated", block_name=block_name)

    # No marker yet: append safely.
    text = text.rstrip() + "\n\n" + wrapped
    write_text(path, text)
    return BlockMergeResult(path=str(path), status="merged", block_name=block_name)


def write_patch(path: Path, block_name: str, content: str, *, style: str = "markdown", indent: str = "") -> Path:
    patch = path.with_name(path.name + ".rctl.patch")
    write_text(
        patch,
        f"# Apply this rctl patch manually to `{path.name}`.\n\n{wrap_block(block_name, content, style=style, indent=indent)}",
    )
    return patch
