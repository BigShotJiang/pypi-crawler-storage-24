from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


class PublishWorkflowTests(unittest.TestCase):
    def test_publish_workflow_uses_trusted_publishing_shape(self) -> None:
        workflow = (ROOT / ".github" / "workflows" / "publish.yml").read_text(encoding="utf-8")

        self.assertIn("workflow_dispatch:", workflow)
        self.assertIn("release:", workflow)
        self.assertIn("id-token: write", workflow)
        self.assertIn("pypa/gh-action-pypi-publish@release/v1", workflow)
        self.assertIn("repository-url: https://test.pypi.org/legacy/", workflow)
        self.assertIn("actions/upload-artifact@v4", workflow)
        self.assertIn("actions/download-artifact@v4", workflow)

    def test_pypi_runbook_covers_testpypi_and_pypi_verification(self) -> None:
        runbook = (ROOT / "rctl" / "docs" / "runbooks" / "pypi-release.md").read_text(encoding="utf-8")

        self.assertIn("trusted publisher", runbook)
        self.assertIn("target=testpypi", runbook)
        self.assertIn("target=pypi", runbook)
        self.assertIn("/tmp/rctl-testpypi/bin/rctl init", runbook)
        self.assertIn("/tmp/rctl-pypi/bin/rctl --help", runbook)
        self.assertIn("TWINE_USERNAME=__token__", runbook)
