from __future__ import annotations

import io
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rctl.bootstrap import init_repo
from rctl.cli import main
from rctl.gc import gc_repo, write_gc_artifact
from rctl.utils import read_json, read_text, read_yaml, sha256_text, write_json, write_text, write_yaml


class GcTests(unittest.TestCase):
    def make_repo(self, *, agents: str = "codex,claude") -> Path:
        tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(tempdir.cleanup)
        repo = Path(tempdir.name) / "repo"
        repo.mkdir(parents=True, exist_ok=True)
        (repo / "pyproject.toml").write_text("[project]\nname='sample-python'\nversion='0.1.0'\n", encoding="utf-8")
        init_repo(repo, agents=agents, profile="core", stack="python")
        return repo

    def make_change(self, repo: Path, change_id: str, *, updated_at: str = "2026-03-24T12:00:00Z") -> Path:
        change_dir = repo / "rctl" / "changes" / "active" / change_id
        change_dir.mkdir(parents=True)
        write_yaml(
            change_dir / "change.yaml",
            {
                "change_id": change_id,
                "title": change_id,
                "status": "active",
                "zones": ["root"],
                "risk_level": "medium",
                "lifecycle": {
                    "phase": "implementing",
                    "started_at": "2026-03-24T10:00:00Z",
                    "updated_at": updated_at,
                    "artifacts": {
                        "plan": "done",
                        "implementation": "in_progress",
                        "verification": "pending",
                        "rollback": "done",
                    },
                    "next_step": "Continue implementing.",
                },
                "links": {
                    "plan": "plan.md",
                    "status": "status.md",
                    "evidence": "evidence.md",
                    "rollback": "rollback.md",
                },
            },
        )
        for name in ("plan.md", "status.md", "rollback.md"):
            write_text(change_dir / name, "# placeholder\n")
        write_text(change_dir / "evidence.md", "Observed validation evidence.\n")
        return change_dir

    def set_old_age(self, path: Path, *, days: int, now: datetime | None = None) -> None:
        reference = now or datetime.now(timezone.utc)
        timestamp = reference.timestamp() - days * 86400
        os.utime(path, (timestamp, timestamp))

    def test_gc_detects_stale_freshness_evidence_and_crosslinks(self) -> None:
        repo = self.make_repo()
        check_time = datetime(2026, 3, 24, 12, 0, tzinfo=timezone.utc)
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["cleanup"]["stale_active_change_after_days"] = 5
        write_yaml(zone_path, zone)

        self.make_change(repo, "stale-change", updated_at="2026-03-01T12:00:00Z")
        write_text(repo / "rctl" / "changes" / "active" / "stale-change" / "evidence.md", read_text(repo / "rctl" / "control-plane" / "templates" / "evidence.md"))
        write_text(repo / "AGENTS.md", read_text(repo / "AGENTS.md") + "\nBroken link: `rctl/docs/missing.md`\n")

        for name, days in (("validation-report.json", 31), ("scorecard.json", 31), ("enforce-report.json", 8)):
            path = repo / "rctl" / "docs" / "quality" / name
            write_text(path, "{}\n")
            self.set_old_age(path, days=days, now=check_time)

        result = gc_repo(repo, now=check_time)

        categories = {item["category"] for item in result["issues"]}
        self.assertIn("stale", categories)
        self.assertIn("freshness", categories)
        self.assertIn("evidence", categories)
        self.assertIn("crosslink", categories)

    def test_gc_crosslinks_ignore_non_repo_tokens_but_keep_real_repo_paths(self) -> None:
        repo = self.make_repo()
        write_text(
            repo / "AGENTS.md",
            read_text(repo / "AGENTS.md")
            + "\n"
            + "Docs mention `cli.py`, `bootstrap.py`, `.venv/`, and `.venv/bin/python`.\n"
            + "Broken repo links: `rctl/docs/missing.md` and `src/rctl/missing.py`.\n",
        )

        result = gc_repo(repo)
        crosslinks = {item["target"] for item in result["issues"] if item["category"] == "crosslink"}

        self.assertEqual(crosslinks, {"AGENTS.md:rctl/docs/missing.md", "AGENTS.md:src/rctl/missing.py"})

    def test_gc_detects_and_fixes_orphan_projections(self) -> None:
        repo = self.make_repo()
        orphan = repo / ".agents" / "skills" / "orphan-skill"
        orphan.mkdir(parents=True)
        write_text(orphan / "SKILL.md", "# orphan\n")

        result = gc_repo(repo)
        orphan_issues = [item for item in result["issues"] if item["category"] == "orphan"]
        self.assertEqual(len(orphan_issues), 1)
        self.assertTrue(orphan_issues[0]["auto_fixable"])
        self.assertTrue(orphan.exists())

        fixed = gc_repo(repo, fix=True)
        self.assertFalse(orphan.exists())
        self.assertFalse([item for item in fixed["issues"] if item["category"] == "orphan"])

    def test_gc_recognizes_locked_external_skill_and_fix_keeps_it(self) -> None:
        repo = self.make_repo()
        external = repo / ".agents" / "skills" / "readme-craftsman"
        external.mkdir(parents=True)
        write_text(external / "SKILL.md", "# readme-craftsman\n")
        claude_projection = repo / ".claude" / "skills" / "readme-craftsman"
        claude_projection.symlink_to(Path("../../.agents/skills/readme-craftsman"))
        write_json(
            repo / "skills-lock.json",
            {
                "version": 1,
                "skills": {
                    "readme-craftsman": {
                        "source": "liqiongyu/my-skills",
                        "sourceType": "github",
                        "computedHash": "deadbeef",
                    }
                },
            },
        )

        result = gc_repo(repo)
        orphan_issues = [item for item in result["issues"] if item["category"] == "orphan"]
        self.assertFalse([item for item in orphan_issues if item["target"] == ".agents/skills/readme-craftsman"])

        fixed = gc_repo(repo, fix=True)
        self.assertTrue(external.exists())
        self.assertTrue(claude_projection.exists())
        self.assertFalse([item for item in fixed["issues"] if item["category"] == "orphan"])

    def test_gc_deduplicates_symlinked_orphan_projections(self) -> None:
        repo = self.make_repo()
        orphan = repo / ".agents" / "skills" / "orphan-skill"
        orphan.mkdir(parents=True)
        write_text(orphan / "SKILL.md", "# orphan\n")
        claude_projection = repo / ".claude" / "skills" / "orphan-skill"
        claude_projection.symlink_to(Path("../../.agents/skills/orphan-skill"))

        result = gc_repo(repo)
        orphan_issues = [item for item in result["issues"] if item["category"] == "orphan"]

        self.assertEqual(len(orphan_issues), 1)
        self.assertEqual(orphan_issues[0]["target"], ".agents/skills/orphan-skill")
        self.assertEqual(orphan_issues[0]["origin"], "unknown")

    def test_gc_malformed_skills_lock_disables_orphan_autofix(self) -> None:
        repo = self.make_repo()
        external = repo / ".agents" / "skills" / "readme-craftsman"
        external.mkdir(parents=True)
        write_text(external / "SKILL.md", "# readme-craftsman\n")
        write_text(repo / "skills-lock.json", "{not-json}\n")

        result = gc_repo(repo)
        orphan_issues = [item for item in result["issues"] if item["category"] == "orphan"]

        self.assertEqual(len(orphan_issues), 1)
        self.assertEqual(orphan_issues[0]["target"], ".agents/skills/readme-craftsman")
        self.assertFalse(orphan_issues[0]["auto_fixable"])
        self.assertIn("Unable to read skills-lock.json", orphan_issues[0]["message"])

        fixed = gc_repo(repo, fix=True)
        self.assertTrue(external.exists())
        orphan_issues = [item for item in fixed["issues"] if item["category"] == "orphan"]
        self.assertEqual(len(orphan_issues), 1)
        self.assertFalse(orphan_issues[0]["auto_fixable"])

    def test_gc_detects_and_fixes_manifest_drift(self) -> None:
        repo = self.make_repo()
        target = repo / "rctl" / "docs" / "project-origin.md"
        write_text(target, "drifted content\n")

        result = gc_repo(repo)
        drift = [item for item in result["issues"] if item["category"] == "manifest-drift"]
        self.assertEqual(len(drift), 1)
        self.assertTrue(drift[0]["auto_fixable"])

        gc_repo(repo, fix=True)
        manifest = read_json(repo / ".rctl" / "manifest.json")
        self.assertEqual(manifest["managed_files"]["rctl/docs/project-origin.md"]["sha256"], sha256_text("drifted content\n"))

    def test_gc_dry_run_is_default_and_fix_only_resolves_safe_items(self) -> None:
        repo = self.make_repo()
        stale = self.make_change(repo, "old-change", updated_at="2026-03-01T12:00:00Z")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["cleanup"]["stale_active_change_after_days"] = 5
        write_yaml(zone_path, zone)
        orphan = repo / ".agents" / "skills" / "orphan-skill"
        orphan.mkdir(parents=True)
        write_text(orphan / "SKILL.md", "# orphan\n")

        with redirect_stdout(io.StringIO()):
            exit_code = main(["gc", str(repo), "--format", "text"])
        self.assertEqual(exit_code, 1)
        self.assertTrue(orphan.exists())

        with redirect_stdout(io.StringIO()):
            exit_code = main(["gc", str(repo), "--fix", "--format", "text"])
        self.assertEqual(exit_code, 1)
        self.assertFalse(orphan.exists())
        self.assertTrue(stale.exists())

    def test_gc_clean_repo_and_artifact_writer(self) -> None:
        repo = self.make_repo()

        result = gc_repo(repo)
        json_path, md_path = write_gc_artifact(repo, result)

        self.assertEqual(result["total_issues"], 0)
        self.assertTrue(json_path.exists())
        self.assertTrue(md_path.exists())
        self.assertIn("No gc issues found", read_text(md_path))

        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(["gc", str(repo), "--write-artifact", "--format", "text"])
        self.assertEqual(exit_code, 0)
        self.assertIn("No GC issues found.", stdout.getvalue())


if __name__ == "__main__":
    unittest.main()
