from __future__ import annotations

import io
import json
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rctl.bootstrap import init_repo
from rctl.cli import main
from rctl.lifecycle import change_status, compute_next, list_active_changes, next_change
from rctl.utils import read_yaml, write_text, write_yaml


class LifecycleTests(unittest.TestCase):
    def make_repo(self) -> Path:
        tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(tempdir.cleanup)
        repo = Path(tempdir.name) / "repo"
        repo.mkdir(parents=True, exist_ok=True)
        (repo / "pyproject.toml").write_text("[project]\nname='sample-python'\nversion='0.1.0'\n", encoding="utf-8")
        init_repo(repo, agents="codex", profile="core", stack="python")
        return repo

    def make_change(
        self,
        repo: Path,
        change_id: str,
        *,
        updated_at: str,
        lifecycle: bool = True,
        phase: str = "implementing",
        artifacts: dict[str, str] | None = None,
        next_step: str = "Continue implementing.",
    ) -> None:
        change_dir = repo / "rctl" / "changes" / "active" / change_id
        change_dir.mkdir(parents=True)
        data = {
            "change_id": change_id,
            "title": f"Change {change_id}",
            "status": "active",
            "zones": ["root"],
            "risk_level": "medium",
            "links": {
                "plan": "plan.md",
                "status": "status.md",
                "evidence": "evidence.md",
                "rollback": "rollback.md",
            },
        }
        if lifecycle:
            lifecycle_artifacts = {
                "plan": "done",
                "implementation": "in_progress",
                "verification": "pending",
                "rollback": "done",
            }
            if artifacts:
                lifecycle_artifacts.update(artifacts)
            data["lifecycle"] = {
                "phase": phase,
                "started_at": "2026-03-24T10:00:00Z",
                "updated_at": updated_at,
                "artifacts": lifecycle_artifacts,
                "next_step": next_step,
            }
        write_yaml(change_dir / "change.yaml", data)
        for name in ("plan.md", "status.md", "evidence.md", "rollback.md"):
            write_text(change_dir / name, "# placeholder\n")

    def test_change_status_returns_lifecycle_details(self) -> None:
        repo = self.make_repo()
        self.make_change(repo, "fix-auth-timeout", updated_at="2026-03-24T14:30:00Z")

        result = change_status(
            repo,
            "fix-auth-timeout",
            now=datetime(2026, 3, 24, 16, 30, tzinfo=timezone.utc),
        )

        self.assertEqual(result["phase"], "implementing")
        self.assertEqual(result["updated_ago"], "2h")
        self.assertEqual(result["artifacts"]["implementation"], "in_progress")

    def test_list_active_changes_reports_stale_count(self) -> None:
        repo = self.make_repo()
        zone = read_yaml(repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml")
        zone["cleanup"]["stale_active_change_after_days"] = 1
        write_yaml(repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml", zone)
        self.make_change(repo, "fresh-change", updated_at="2026-03-24T12:00:00Z")
        self.make_change(repo, "stale-change", updated_at="2026-03-20T12:00:00Z")

        result = list_active_changes(
            repo,
            check_stale=True,
            now=datetime(2026, 3, 24, 13, 0, tzinfo=timezone.utc),
        )

        self.assertEqual(len(result["active_changes"]), 2)
        self.assertEqual(result["stale_count"], 1)

    def test_change_status_handles_legacy_change_without_lifecycle(self) -> None:
        repo = self.make_repo()
        self.make_change(repo, "legacy-change", updated_at="2026-03-24T12:00:00Z", lifecycle=False)

        result = change_status(repo, "legacy-change")

        self.assertEqual(result["phase"], "unknown")
        self.assertEqual(result["updated_ago"], "unknown")
        self.assertIn("Lifecycle metadata missing", result["next_step"])

    def test_compute_next_covers_state_transitions(self) -> None:
        cases = [
            (
                "legacy change",
                {},
                "planning",
                "Create a plan first. Run /rctl-plan.",
                "/rctl-plan",
            ),
            (
                "planning complete",
                {"lifecycle": {"phase": "planning", "artifacts": {"plan": "done"}}},
                "planning",
                "Plan is ready. Start implementing. Run /rctl-apply.",
                "/rctl-apply",
            ),
            (
                "implementation complete",
                {
                    "lifecycle": {
                        "phase": "implementing",
                        "artifacts": {"plan": "done", "implementation": "done", "rollback": "done"},
                    }
                },
                "implementing",
                "Implementation complete. Verify the change. Run /rctl-verify.",
                "/rctl-verify",
            ),
            (
                "verification complete",
                {
                    "lifecycle": {
                        "phase": "verifying",
                        "artifacts": {
                            "plan": "done",
                            "implementation": "done",
                            "verification": "done",
                            "rollback": "done",
                        },
                    }
                },
                "verifying",
                "Verification passed. Archive the change. Run /rctl-archive.",
                "/rctl-archive",
            ),
            (
                "rollback missing",
                {
                    "lifecycle": {
                        "phase": "implementing",
                        "artifacts": {
                            "plan": "done",
                            "implementation": "in_progress",
                            "verification": "pending",
                            "rollback": "pending",
                        },
                    }
                },
                "implementing",
                "Rollback notes are missing. Document rollback steps in rollback.md.",
                None,
            ),
            (
                "continue current phase",
                {
                    "lifecycle": {
                        "phase": "implementing",
                        "artifacts": {
                            "plan": "done",
                            "implementation": "in_progress",
                            "verification": "pending",
                            "rollback": "done",
                        },
                    }
                },
                "implementing",
                "Continue implementing.",
                None,
            ),
        ]

        for label, change, phase, suggestion, command in cases:
            with self.subTest(label=label):
                result = compute_next(change)
                self.assertEqual(result["current_phase"], phase)
                self.assertEqual(result["suggestion"], suggestion)
                self.assertEqual(result["suggested_command"], command)

    def test_next_change_updates_change_yaml_and_timestamp(self) -> None:
        repo = self.make_repo()
        self.make_change(
            repo,
            "fix-auth-timeout",
            updated_at="2026-03-24T14:30:00Z",
            artifacts={"implementation": "done"},
        )

        result = next_change(
            repo,
            "fix-auth-timeout",
            update=True,
            now=datetime(2026, 3, 24, 16, 30, tzinfo=timezone.utc),
        )

        self.assertTrue(result["updated"])
        self.assertEqual(result["suggested_command"], "/rctl-verify")
        change_data = read_yaml(repo / "rctl" / "changes" / "active" / "fix-auth-timeout" / "change.yaml")
        self.assertEqual(
            change_data["lifecycle"]["next_step"],
            "Implementation complete. Verify the change. Run /rctl-verify.",
        )
        self.assertEqual(change_data["lifecycle"]["updated_at"], "2026-03-24T16:30:00Z")
        self.assertNotIn("_path", change_data)
        self.assertNotIn("_bucket", change_data)

    def test_next_change_legacy_update_creates_lifecycle_defaults(self) -> None:
        repo = self.make_repo()
        self.make_change(repo, "legacy-change", updated_at="2026-03-24T12:00:00Z", lifecycle=False)

        result = next_change(
            repo,
            "legacy-change",
            update=True,
            now=datetime(2026, 3, 24, 16, 30, tzinfo=timezone.utc),
        )

        self.assertTrue(result["updated"])
        self.assertEqual(result["current_phase"], "planning")
        self.assertEqual(result["suggested_command"], "/rctl-plan")
        change_data = read_yaml(repo / "rctl" / "changes" / "active" / "legacy-change" / "change.yaml")
        self.assertEqual(change_data["lifecycle"]["phase"], "planning")
        self.assertEqual(change_data["lifecycle"]["started_at"], "2026-03-24T16:30:00Z")
        self.assertEqual(change_data["lifecycle"]["artifacts"]["plan"], "pending")
        self.assertEqual(change_data["lifecycle"]["next_step"], "Create a plan first. Run /rctl-plan.")

    def test_cli_status_and_next_json_and_text_output(self) -> None:
        repo = self.make_repo()
        self.make_change(repo, "fix-auth-timeout", updated_at="2026-03-24T14:30:00Z")

        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(["status", str(repo), "fix-auth-timeout", "--format", "json"])
        self.assertEqual(exit_code, 0)
        data = json.loads(stdout.getvalue())
        self.assertEqual(data["change_id"], "fix-auth-timeout")

        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(["status", str(repo), "--format", "text"])
        self.assertEqual(exit_code, 0)
        self.assertIn("Active changes:", stdout.getvalue())

        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(["next", str(repo), "fix-auth-timeout", "--format", "json"])
        self.assertEqual(exit_code, 0)
        data = json.loads(stdout.getvalue())
        self.assertEqual(data["suggestion"], "Continue implementing.")
        self.assertIsNone(data["suggested_command"])

        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(["next", str(repo), "fix-auth-timeout", "--update", "--format", "text"])
        self.assertEqual(exit_code, 0)
        self.assertIn('Updated fix-auth-timeout next_step: "Continue implementing."', stdout.getvalue())


if __name__ == "__main__":
    unittest.main()
