from __future__ import annotations

import io
import json
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rctl.bootstrap import init_repo
from rctl.cli import main
from rctl.enforce import enforce_repo, run_check, write_enforce_artifact
from rctl.utils import read_json, read_text, read_yaml, write_text, write_yaml


class EnforceTests(unittest.TestCase):
    def make_repo(self, stack: str = "python") -> Path:
        tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(tempdir.cleanup)
        repo = Path(tempdir.name) / "repo"
        repo.mkdir(parents=True, exist_ok=True)
        if stack == "python":
            (repo / "pyproject.toml").write_text("[project]\nname='sample-python'\nversion='0.1.0'\n", encoding="utf-8")
        init_repo(repo, agents="codex", profile="core", stack=stack)
        return repo

    def test_run_check_supports_expect_types(self) -> None:
        repo = self.make_repo()
        executable = sys.executable

        exit_zero = run_check(repo, {"id": "a", "check": f'{executable} -c "print(1)"', "expect": "exit_zero", "severity": "error", "message": "a"})
        exit_nonzero = run_check(repo, {"id": "b", "check": f'{executable} -c "import sys; sys.exit(2)"', "expect": "exit_nonzero", "severity": "error", "message": "b"})
        output_empty = run_check(repo, {"id": "c", "check": f'{executable} -c "pass"', "expect": "output_empty", "severity": "error", "message": "c"})
        output_match = run_check(repo, {"id": "d", "check": f'{executable} -c "print(\'matched\')"', "expect": "output_match", "pattern": "matched", "severity": "error", "message": "d"})

        self.assertTrue(exit_zero["passed"])
        self.assertTrue(exit_nonzero["passed"])
        self.assertTrue(output_empty["passed"])
        self.assertTrue(output_match["passed"])

    def test_run_check_timeout_fails(self) -> None:
        repo = self.make_repo()
        result = run_check(
            repo,
            {
                "id": "sleep",
                "check": f'{sys.executable} -c "import time; time.sleep(2)"',
                "expect": "exit_zero",
                "severity": "error",
                "message": "Should finish quickly",
            },
            timeout=0.1,
        )

        self.assertFalse(result["passed"])
        self.assertTrue(result["timed_out"])

    def test_enforce_repo_filters_zone_and_severity(self) -> None:
        repo = self.make_repo()
        zones_dir = repo / "rctl" / "control-plane" / "zones"
        root_zone = read_yaml(zones_dir / "root.zone.yaml")
        root_zone["enforceable"] = [
            {"id": "warn-check", "check": f'{sys.executable} -c "import sys; sys.exit(1)"', "expect": "exit_zero", "severity": "warning", "message": "warn"},
            {"id": "error-check", "check": f'{sys.executable} -c "print(1)"', "expect": "exit_zero", "severity": "error", "message": "error"},
        ]
        write_yaml(zones_dir / "root.zone.yaml", root_zone)

        other_zone = dict(root_zone)
        other_zone["id"] = "other"
        other_zone["enforceable"] = [
            {"id": "other-check", "check": f'{sys.executable} -c "print(1)"', "expect": "exit_zero", "severity": "error", "message": "other"}
        ]
        write_yaml(zones_dir / "other.yaml", other_zone)

        result = enforce_repo(repo, zone_id="root", severity="error")

        self.assertEqual(len(result["zones"]), 1)
        self.assertEqual(result["zones"][0]["zone_id"], "root")
        self.assertEqual(result["total_checks"], 1)
        self.assertEqual(result["zones"][0]["checks"][0]["id"], "error-check")

    def test_enforce_repo_warns_when_checks_missing(self) -> None:
        repo = self.make_repo()
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone.pop("enforceable", None)
        write_yaml(zone_path, zone)

        result = enforce_repo(repo)

        self.assertTrue(result["passed"])
        self.assertEqual(result["total_checks"], 0)
        self.assertTrue(result["warnings"])

    def test_write_enforce_artifact_and_cli_exit_codes(self) -> None:
        repo = self.make_repo()
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["enforceable"] = [
            {"id": "fail-check", "check": f'{sys.executable} -c "import sys; sys.exit(1)"', "expect": "exit_zero", "severity": "error", "message": "must pass"}
        ]
        write_yaml(zone_path, zone)

        result = enforce_repo(repo)
        json_path, md_path = write_enforce_artifact(repo, result)

        self.assertTrue(json_path.exists())
        self.assertTrue(md_path.exists())
        self.assertEqual(read_json(json_path)["total_errors"], 1)
        self.assertIn("Enforce report", read_text(md_path))

        with redirect_stdout(io.StringIO()):
            exit_code = main(["enforce", str(repo), "--ci", "--write-artifact", "--format", "text"])

        self.assertEqual(exit_code, 1)

    def test_cli_enforce_accepts_dry_run_alias(self) -> None:
        repo = self.make_repo()

        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(["enforce", str(repo), "--dry-run", "--format", "json"])

        self.assertEqual(exit_code, 0)
        payload = json.loads(stdout.getvalue())
        self.assertIn("total_checks", payload)


if __name__ == "__main__":
    unittest.main()
