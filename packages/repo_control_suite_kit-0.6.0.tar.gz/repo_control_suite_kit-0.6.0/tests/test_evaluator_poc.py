from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from examples.test_evaluator_poc import EvaluatorPocTests

__all__ = ["EvaluatorPocTests"]
