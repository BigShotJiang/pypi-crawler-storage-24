from __future__ import annotations

import io
import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from rctl.bootstrap import init_repo, update_repo
from rctl.cli import main
from rctl.gc import gc_repo
from rctl.score import score_repo, write_score_artifact
from rctl.utils import read_json, read_text, read_yaml, write_json, write_text, write_yaml
from rctl.validate import validate_repo, write_validation_artifact


class RepoControlSuiteE2ETests(unittest.TestCase):
    def make_repo(self, stack: str = "node") -> Path:
        tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(tempdir.cleanup)
        repo = Path(tempdir.name) / "repo"
        repo.mkdir(parents=True, exist_ok=True)
        if stack == "node":
            (repo / "package.json").write_text(
                json.dumps(
                    {
                        "name": "sample-node",
                        "version": "1.0.0",
                        "scripts": {"test": "echo ok", "lint": "echo lint"},
                    }
                )
                + "\n",
                encoding="utf-8",
            )
        elif stack == "python":
            (repo / "pyproject.toml").write_text("[project]\nname='sample-python'\nversion='0.1.0'\n", encoding="utf-8")
        return repo

    def make_change(self, repo: Path, bucket: str, change_id: str, *, lifecycle: bool = True) -> None:
        change_dir = repo / "rctl" / "changes" / bucket / change_id
        change_dir.mkdir(parents=True, exist_ok=True)
        data = {
            "change_id": change_id,
            "title": change_id,
            "status": "archived" if bucket == "archive" else "active",
            "zones": ["root"],
            "risk_level": "medium",
            "links": {
                "plan": "plan.md",
                "status": "status.md",
                "evidence": "evidence.md",
                "rollback": "rollback.md",
            },
        }
        if lifecycle:
            data["lifecycle"] = {
                "phase": "archiving" if bucket == "archive" else "implementing",
                "started_at": "2026-03-24T10:00:00Z",
                "updated_at": "2026-03-24T12:00:00Z",
                "artifacts": {
                    "plan": "done",
                    "implementation": "done" if bucket == "archive" else "in_progress",
                    "verification": "done" if bucket == "archive" else "pending",
                    "rollback": "done",
                },
                "next_step": "Continue.",
            }
        write_yaml(change_dir / "change.yaml", data)
        for name in ("plan.md", "status.md", "evidence.md", "rollback.md"):
            write_text(change_dir / name, "# placeholder\n")

    def run_cli_json(self, argv: list[str], *, expected_exit: int = 0) -> dict[str, object]:
        args = [str(item) for item in argv]
        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(args)
        self.assertEqual(exit_code, expected_exit)
        return json.loads(stdout.getvalue())

    def make_lifecycle_change(
        self,
        repo: Path,
        change_id: str,
        *,
        bucket: str = "active",
        status: str | None = None,
        phase: str = "planning",
        updated_at: str = "2026-03-24T12:00:00Z",
        artifacts: dict[str, str] | None = None,
        next_step: str = "",
    ) -> Path:
        change_dir = repo / "rctl" / "changes" / bucket / change_id
        change_dir.mkdir(parents=True, exist_ok=True)
        lifecycle_artifacts = {
            "plan": "pending",
            "implementation": "pending",
            "verification": "pending",
            "rollback": "done",
        }
        if artifacts:
            lifecycle_artifacts.update(artifacts)
        write_yaml(
            change_dir / "change.yaml",
            {
                "change_id": change_id,
                "title": change_id,
                "status": status or ("archived" if bucket == "archive" else "active"),
                "zones": ["root"],
                "risk_level": "medium",
                "lifecycle": {
                    "phase": phase,
                    "started_at": "2026-03-24T10:00:00Z",
                    "updated_at": updated_at,
                    "artifacts": lifecycle_artifacts,
                    "next_step": next_step,
                },
                "links": {
                    "plan": "plan.md",
                    "status": "status.md",
                    "evidence": "evidence.md",
                    "rollback": "rollback.md",
                },
            },
        )
        write_text(change_dir / "plan.md", "# Plan\n")
        write_text(change_dir / "status.md", "# Status\n")
        write_text(change_dir / "evidence.md", "Observed validation evidence.\n")
        write_text(change_dir / "rollback.md", "# Rollback\n")
        return change_dir

    def update_change_lifecycle(
        self,
        change_dir: Path,
        *,
        phase: str | None = None,
        updated_at: str | None = None,
        next_step: str | None = None,
        **artifacts: str,
    ) -> None:
        change_path = change_dir / "change.yaml"
        data = read_yaml(change_path)
        lifecycle = data.setdefault("lifecycle", {})
        if phase is not None:
            lifecycle["phase"] = phase
        if updated_at is not None:
            lifecycle["updated_at"] = updated_at
        if next_step is not None:
            lifecycle["next_step"] = next_step
        lifecycle.setdefault("artifacts", {}).update(artifacts)
        write_yaml(change_path, data)

    def test_init_merges_existing_guidance_and_groups_assets_under_rctl(self) -> None:
        repo = self.make_repo("node")
        write_text(repo / "AGENTS.md", "# Existing agent notes\nKeep this.\n")
        write_text(repo / "CLAUDE.md", "# Existing claude notes\nKeep this too.\n")

        result = init_repo(repo, agents="codex,claude,cursor,windsurf", profile="core")

        self.assertTrue((repo / "rctl" / "control-plane" / "control-plane.yaml").exists())
        self.assertTrue((repo / ".agents" / "skills").exists())
        self.assertTrue((repo / ".claude" / "skills").exists())
        self.assertTrue((repo / ".cursor" / "rules" / "rctl-routing.mdc").exists())
        self.assertTrue((repo / ".windsurf" / "rules" / "rctl-routing.md").exists())
        self.assertIn("AGENTS.md", result["blocks"]["merged"])
        self.assertIn("CLAUDE.md", result["blocks"]["merged"])

        agents_text = read_text(repo / "AGENTS.md")
        claude_text = read_text(repo / "CLAUDE.md")
        self.assertIn("Keep this.", agents_text)
        self.assertIn("<!-- rctl:block:start routing -->", agents_text)
        self.assertIn("rctl/control-plane/control-plane.yaml", agents_text)
        self.assertIn("Keep this too.", claude_text)
        self.assertIn("<!-- rctl:block:start routing -->", claude_text)

    def test_profile_minimal_installs_smaller_skill_set(self) -> None:
        repo = self.make_repo("node")
        init_repo(repo, agents="codex", profile="minimal")
        skills_registry = read_yaml(repo / "rctl" / "registry" / "skills.yaml")
        selected = skills_registry["selected_skills"]
        self.assertEqual(
            selected,
            [
                "rctl-onboard-repo",
                "rctl-plan-change",
                "rctl-implement-change",
                "rctl-verify-change",
                "rctl-sync-memory",
                "rctl-validate-repo",
            ],
        )
        self.assertFalse((repo / "rctl" / "skills-src" / "rctl-score-repo").exists())
        self.assertFalse((repo / ".claude" / "skills").exists())

    def test_validate_and_score_artifacts_on_healthy_repo(self) -> None:
        repo = self.make_repo("node")
        init_repo(repo, agents="codex,claude,cursor,windsurf", profile="core")

        validation = validate_repo(repo, smoke=True)
        json_path, md_path = write_validation_artifact(repo, validation)
        score = score_repo(repo)
        score_json, score_md = write_score_artifact(repo, score)

        self.assertTrue(validation["passed"])
        self.assertEqual(validation["sections"]["discovery"]["passed"], True)
        self.assertEqual(score["operational"]["discovery"], 1.0)
        self.assertIn("enforcement", score["operational"])
        self.assertIn("change_lifecycle", score["operational"])
        self.assertTrue(json_path.exists())
        self.assertTrue(md_path.exists())
        self.assertTrue(score_json.exists())
        self.assertTrue(score_md.exists())
        self.assertIn("enforcement", read_text(score_md))
        self.assertIn("change_lifecycle", read_text(score_md))

    def test_cli_full_lifecycle_exercises_all_commands(self) -> None:
        repo = self.make_repo("python")
        write_text(repo / "src" / "sample.py", "value = 1\n")

        init_result = self.run_cli_json(
            ["init", repo, "--agents", "claude", "--profile", "core", "--stack", "python", "--yes", "--format", "json"]
        )
        self.assertEqual(init_result["profile"], "core")

        update_result = self.run_cli_json(["update", repo, "--format", "json"])
        self.assertEqual(update_result["files"]["conflicts"], [])

        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["enforceable"] = [
            {
                "id": "compile-check",
                "check": "python3 -m compileall src",
                "expect": "exit_zero",
                "severity": "error",
                "message": "Must compile",
            }
        ]
        write_yaml(zone_path, zone)
        update_after_zone = self.run_cli_json(["update", repo, "--format", "json"])
        self.assertIn("rctl/control-plane/zones/root.zone.yaml", update_after_zone["files"]["promoted"])

        change_dir = self.make_lifecycle_change(
            repo,
            "test-change",
            phase="planning",
            artifacts={
                "plan": "pending",
                "implementation": "pending",
                "verification": "pending",
                "rollback": "done",
            },
        )

        status_result = self.run_cli_json(["status", repo, "test-change", "--format", "json"])
        self.assertEqual(status_result["phase"], "planning")

        next_result = self.run_cli_json(["next", repo, "test-change", "--format", "json"])
        self.assertEqual(next_result["suggested_command"], "/rctl-plan")

        write_text(change_dir / "plan.md", "# Plan\n\n## Goal\n- Test lifecycle flow.\n")
        self.update_change_lifecycle(
            change_dir,
            phase="implementing",
            updated_at="2026-03-24T12:30:00Z",
            next_step="Implement the planned change.",
            plan="done",
            rollback="done",
        )

        enforce_result = self.run_cli_json(["enforce", repo, "--write-artifact", "--format", "json"])
        self.assertTrue(enforce_result["passed"])
        self.assertEqual(enforce_result["total_errors"], 0)

        write_text(change_dir / "status.md", "# Status\n\n- Implementation complete.\n")
        write_text(change_dir / "evidence.md", "# Evidence\n\n- Enforce passed.\n")
        self.update_change_lifecycle(
            change_dir,
            phase="verifying",
            updated_at="2026-03-24T13:00:00Z",
            next_step="Verification complete; archive next.",
            implementation="done",
            verification="done",
        )

        archive_next = self.run_cli_json(["next", repo, "test-change", "--update", "--format", "json"])
        self.assertEqual(archive_next["suggested_command"], "/rctl-archive")

        validate_result = self.run_cli_json(["validate", repo, "--write-artifact", "--format", "json"])
        self.assertTrue(validate_result["passed"])
        self.assertEqual(
            validate_result["checks_run"],
            ["structure", "discovery", "operational", "freshness", "enforcement"],
        )
        self.assertIn("artifact_paths", validate_result)

        score_result = self.run_cli_json(["score", repo, "--write-artifact", "--format", "json"])
        self.assertGreater(score_result["operational"]["enforcement"], 0)
        self.assertIn("artifact_paths", score_result)

        gc_result = self.run_cli_json(["gc", repo, "--write-artifact", "--format", "json"])
        self.assertEqual(gc_result["total_issues"], 0)
        self.assertEqual(gc_result["fixed_issues"], 0)

    def test_init_scaffolds_zone_context_and_enforceable_defaults(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        zone = read_yaml(repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml")
        self.assertEqual(zone["context"]["stack"], "python")
        self.assertEqual(zone["context"]["conventions"], [])
        self.assertEqual(zone["context"]["key_docs"], [])
        self.assertEqual(len(zone["enforceable"]), 1)
        self.assertEqual(
            zone["enforceable"][0],
            {
                "id": "compile-check",
                "check": "python3 -m compileall src",
                "expect": "exit_zero",
                "severity": "error",
                "message": "Source files must compile without syntax errors",
            },
        )

    def test_init_scaffolds_control_plane_context_defaults(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        control_plane = read_yaml(repo / "rctl" / "control-plane" / "control-plane.yaml")
        self.assertEqual(control_plane["context"]["description"], "Python repository")
        self.assertEqual(control_plane["context"]["ci"], "")
        self.assertEqual(control_plane["context"]["deployment"], "")

    def test_init_scaffolds_change_template_with_lifecycle_defaults(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        change_template = read_yaml(repo / "rctl" / "control-plane" / "templates" / "change.yaml")
        self.assertEqual(change_template["lifecycle"]["phase"], "planning")
        self.assertEqual(change_template["lifecycle"]["artifacts"]["plan"], "pending")
        self.assertEqual(change_template["lifecycle"]["artifacts"]["implementation"], "pending")
        self.assertEqual(change_template["lifecycle"]["artifacts"]["verification"], "pending")
        self.assertEqual(change_template["lifecycle"]["artifacts"]["rollback"], "pending")
        self.assertEqual(change_template["lifecycle"]["next_step"], "Create a plan. Run /rctl-plan.")
        self.assertEqual(change_template["links"]["openspec_change"], "")

    def test_bridge_doc_renders_formal_openspec_protocol(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        bridge_doc = read_text(repo / "rctl" / "bridges" / "openspec.md")
        self.assertIn("# OpenSpec bridge protocol", bridge_doc)
        self.assertIn("## Responsibility boundary", bridge_doc)
        self.assertIn("## Directory rules", bridge_doc)
        self.assertIn("## Cross-linking", bridge_doc)
        self.assertIn("links.openspec_change", bridge_doc)
        self.assertIn("rctl never reads from or writes to `openspec/`", bridge_doc)

    def test_init_generates_file_ownership_doc_and_full_cli_spec(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        ownership_doc = read_text(repo / "rctl" / "docs" / "file-ownership.md")
        self.assertIn("# File ownership", ownership_doc)
        self.assertIn("| `rctl-owned` |", ownership_doc)
        self.assertIn("| `repo-owned` |", ownership_doc)
        self.assertIn("| `shared` |", ownership_doc)
        self.assertIn("| `projection` |", ownership_doc)
        self.assertIn("rctl-owned` to `repo-owned`", ownership_doc)
        self.assertIn('jq \'.managed_files["rctl/registry/commands.yaml"].ownership\'', ownership_doc)

        cli_spec = read_text(repo / "rctl" / "docs" / "cli-spec.md")
        self.assertIn("`rctl init <repo>`", cli_spec)
        self.assertIn("`rctl update <repo>`", cli_spec)
        self.assertIn("`rctl validate [repo]`", cli_spec)
        self.assertIn("`rctl score [repo]`", cli_spec)
        self.assertIn("`rctl enforce [repo]`", cli_spec)
        self.assertIn("`rctl status [repo] [change-id]`", cli_spec)
        self.assertIn("`rctl next <repo> <change-id>`", cli_spec)
        self.assertIn("`rctl gc <repo>`", cli_spec)
        self.assertIn("`--dry-run`, `--ci`, `--timeout`, `--write-artifact`, `--format`", cli_spec)
        self.assertIn("`--update`, `--format`", cli_spec)
        self.assertIn("`--dry-run`, `--fix`, `--write-artifact`, `--format`", cli_spec)

    def test_validate_accepts_openspec_coexistence_without_scanning_contents(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        write_text(repo / "openspec" / "changes" / "demo" / "proposal.md", "# proposal\n")
        write_text(repo / "openspec" / "changes" / "demo" / "bad.yaml", ":\n")

        validation = validate_repo(repo)

        self.assertTrue(validation["passed"])
        self.assertIn("OpenSpec bridge doc exists", validation["sections"]["structure"]["checks"])

    def test_validate_warns_when_openspec_exists_but_bridge_doc_is_missing(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        write_text(repo / "openspec" / "changes" / "demo" / "proposal.md", "# proposal\n")
        (repo / "rctl" / "bridges" / "openspec.md").unlink()

        validation = validate_repo(repo)

        self.assertTrue(validation["passed"])
        self.assertIn(
            "openspec/ exists but rctl/bridges/openspec.md is missing.",
            validation["sections"]["structure"]["warnings"],
        )

    def test_validate_accepts_zones_with_and_without_new_optional_fields(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone.pop("context", None)
        zone.pop("enforceable", None)
        write_yaml(zone_path, zone)

        validation = validate_repo(repo)

        self.assertTrue(validation["passed"])
        self.assertTrue(validation["sections"]["structure"]["passed"])

    def test_validate_accepts_control_plane_with_and_without_context(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        control_plane_path = repo / "rctl" / "control-plane" / "control-plane.yaml"
        control_plane = read_yaml(control_plane_path)
        control_plane.pop("context", None)
        write_yaml(control_plane_path, control_plane)

        validation = validate_repo(repo)

        self.assertTrue(validation["passed"])
        self.assertTrue(validation["sections"]["structure"]["passed"])

    def test_validate_warns_on_legacy_change_without_lifecycle(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        change_dir = repo / "rctl" / "changes" / "active" / "legacy-change"
        change_dir.mkdir(parents=True)
        write_yaml(
            change_dir / "change.yaml",
            {
                "change_id": "legacy-change",
                "title": "Legacy change",
                "status": "active",
                "zones": ["root"],
                "risk_level": "medium",
                "links": {
                    "plan": "plan.md",
                    "status": "status.md",
                    "evidence": "evidence.md",
                    "rollback": "rollback.md",
                },
            },
        )
        for name in ("plan.md", "status.md", "evidence.md", "rollback.md"):
            write_text(change_dir / name, "# placeholder\n")

        validation = validate_repo(repo)

        self.assertTrue(validation["passed"])
        self.assertIn(
            "Active change legacy-change change.yaml is missing lifecycle metadata.",
            validation["sections"]["operational"]["warnings"],
        )

    def test_validate_rejects_output_match_enforceable_without_pattern(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["enforceable"] = [
            {
                "id": "match-output",
                "check": "printf ok",
                "expect": "output_match",
                "severity": "error",
                "message": "Output should match the configured pattern",
            }
        ]
        write_yaml(zone_path, zone)

        validation = validate_repo(repo)

        self.assertFalse(validation["passed"])
        self.assertTrue(
            any("pattern" in error for error in validation["sections"]["structure"]["errors"])
        )

    def test_validate_rejects_invalid_change_lifecycle(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        change_dir = repo / "rctl" / "changes" / "active" / "bad-change"
        change_dir.mkdir(parents=True)
        write_yaml(
            change_dir / "change.yaml",
            {
                "change_id": "bad-change",
                "title": "Bad change",
                "status": "active",
                "zones": ["root"],
                "risk_level": "medium",
                "lifecycle": {
                    "phase": "paused",
                    "started_at": "2026-03-24T00:00:00Z",
                    "updated_at": "2026-03-24T00:00:00Z",
                    "artifacts": {
                        "plan": "done",
                        "implementation": "pending",
                        "verification": "pending",
                        "rollback": "pending",
                    },
                    "next_step": "Fix the invalid phase.",
                },
                "links": {
                    "plan": "plan.md",
                    "status": "status.md",
                    "evidence": "evidence.md",
                    "rollback": "rollback.md",
                },
            },
        )
        for name in ("plan.md", "status.md", "evidence.md", "rollback.md"):
            write_text(change_dir / name, "# placeholder\n")

        validation = validate_repo(repo)

        self.assertFalse(validation["passed"])
        self.assertTrue(
            any("paused" in error for error in validation["sections"]["operational"]["errors"])
        )

    def test_score_enforcement_states(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)

        zone["enforceable"] = []
        write_yaml(zone_path, zone)
        score = score_repo(repo)
        self.assertEqual(score["operational"]["enforcement"], 0.0)
        self.assertIn("No enforceable checks are defined in the root zone yet.", score["notes"])

        zone["enforceable"] = [
            {
                "id": "compile-check",
                "check": "python3 -m compileall src",
                "expect": "exit_zero",
                "severity": "error",
                "message": "compile",
            }
        ]
        write_yaml(zone_path, zone)
        score = score_repo(repo)
        self.assertEqual(score["operational"]["enforcement"], 0.25)

        write_json(
            repo / "rctl" / "docs" / "quality" / "enforce-report.json",
            {
                "repo": str(repo),
                "zones": [],
                "warnings": [],
                "passed": False,
                "total_checks": 1,
                "total_errors": 1,
                "total_warnings": 0,
            },
        )
        score = score_repo(repo)
        self.assertEqual(score["operational"]["enforcement"], 0.5)

        write_json(
            repo / "rctl" / "docs" / "quality" / "enforce-report.json",
            {
                "repo": str(repo),
                "zones": [],
                "warnings": [],
                "passed": True,
                "total_checks": 1,
                "total_errors": 0,
                "total_warnings": 0,
            },
        )
        score = score_repo(repo)
        self.assertEqual(score["operational"]["enforcement"], 1.0)

    def test_score_entropy_states(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        score = score_repo(repo)
        self.assertEqual(score["operational"]["entropy"], 0.0)
        self.assertFalse(score["gates"]["entropy_clean"])
        self.assertIn("No gc report has been written yet.", score["notes"])

        write_json(
            repo / "rctl" / "docs" / "quality" / "gc-report.json",
            {"repo": str(repo), "issues": [], "total_issues": 0, "auto_fixable": 0, "fixed_issues": 0, "fix": False},
        )
        score = score_repo(repo)
        self.assertEqual(score["operational"]["entropy"], 1.0)
        self.assertTrue(score["gates"]["entropy_clean"])

        write_json(
            repo / "rctl" / "docs" / "quality" / "gc-report.json",
            {
                "repo": str(repo),
                "issues": [
                    {"category": "freshness", "severity": "warning", "target": "rctl/docs/quality/scorecard.json", "message": "stale", "auto_fixable": False}
                ],
                "total_issues": 1,
                "auto_fixable": 0,
                "fixed_issues": 0,
                "fix": False,
            },
        )
        score = score_repo(repo)
        self.assertEqual(score["operational"]["entropy"], 0.5)
        self.assertTrue(score["gates"]["entropy_clean"])

        write_json(
            repo / "rctl" / "docs" / "quality" / "gc-report.json",
            {
                "repo": str(repo),
                "issues": [
                    {"category": "crosslink", "severity": "error", "target": "AGENTS.md:missing", "message": "missing", "auto_fixable": False}
                ],
                "total_issues": 1,
                "auto_fixable": 0,
                "fixed_issues": 0,
                "fix": False,
            },
        )
        score = score_repo(repo)
        self.assertEqual(score["operational"]["entropy"], 0.25)
        self.assertFalse(score["gates"]["entropy_clean"])
        self.assertIn("Latest gc report contains error-level entropy issues.", score["notes"])

    def test_score_failing_enforce_report_blocks_ready_low_risk(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="claude", profile="core")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["bootstrap_state"] = "operational"
        zone["owners"] = ["platform"]
        zone["canonical_terms"] = ["control plane"]
        zone["enforceable"] = [
            {
                "id": "fail-check",
                "check": f'{sys.executable} -c "import sys; sys.exit(1)"',
                "expect": "exit_zero",
                "severity": "error",
                "message": "must pass",
            }
        ]
        write_yaml(zone_path, zone)
        self.make_lifecycle_change(
            repo,
            "done-change",
            bucket="archive",
            phase="archiving",
            status="archived",
            artifacts={
                "plan": "done",
                "implementation": "done",
                "verification": "done",
                "rollback": "done",
            },
            next_step="Archived.",
        )

        validation = validate_repo(repo)
        write_validation_artifact(repo, validation)
        write_json(
            repo / "rctl" / "docs" / "quality" / "enforce-report.json",
            {
                "repo": str(repo),
                "zones": [],
                "warnings": [],
                "passed": False,
                "total_checks": 1,
                "total_errors": 1,
                "total_warnings": 0,
            },
        )

        score = score_repo(repo)

        self.assertEqual(score["operational"]["enforcement"], 0.5)
        self.assertFalse(score["gates"]["enforcement_passing"])
        self.assertNotEqual(score["recommendation"], "ready-low-risk")
        self.assertIn("Latest enforce report is failing.", score["notes"])

    def test_score_entropy_gate_requires_clean_gc_report(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="claude", profile="core")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["bootstrap_state"] = "operational"
        zone["owners"] = ["platform"]
        zone["canonical_terms"] = ["control plane"]
        zone["enforceable"] = [
            {
                "id": "compile-check",
                "check": f'{sys.executable} -c "print(1)"',
                "expect": "exit_zero",
                "severity": "error",
                "message": "must pass",
            }
        ]
        write_yaml(zone_path, zone)
        self.make_lifecycle_change(
            repo,
            "done-change",
            bucket="archive",
            phase="archiving",
            status="archived",
            artifacts={
                "plan": "done",
                "implementation": "done",
                "verification": "done",
                "rollback": "done",
            },
            next_step="Archived.",
        )

        validation = validate_repo(repo)
        write_validation_artifact(repo, validation)
        write_json(
            repo / "rctl" / "docs" / "quality" / "enforce-report.json",
            {
                "repo": str(repo),
                "zones": [],
                "warnings": [],
                "passed": True,
                "total_checks": 1,
                "total_errors": 0,
                "total_warnings": 0,
            },
        )

        score = score_repo(repo)
        self.assertFalse(score["gates"]["entropy_clean"])
        self.assertNotEqual(score["recommendation"], "ready-low-risk")

        write_json(
            repo / "rctl" / "docs" / "quality" / "gc-report.json",
            {"repo": str(repo), "issues": [], "total_issues": 0, "auto_fixable": 0, "fixed_issues": 0, "fix": False},
        )
        score = score_repo(repo)
        self.assertTrue(score["gates"]["entropy_clean"])
        self.assertEqual(score["recommendation"], "ready-low-risk")

        write_json(
            repo / "rctl" / "docs" / "quality" / "gc-report.json",
            {
                "repo": str(repo),
                "issues": [
                    {"category": "orphan", "severity": "error", "target": ".agents/skills/orphan", "message": "orphan", "auto_fixable": True}
                ],
                "total_issues": 1,
                "auto_fixable": 1,
                "fixed_issues": 0,
                "fix": False,
            },
        )
        score = score_repo(repo)
        self.assertFalse(score["gates"]["entropy_clean"])
        self.assertNotEqual(score["recommendation"], "ready-low-risk")

    def test_gc_detects_stale_change_after_lifecycle_setup(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="claude", profile="core")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["cleanup"]["stale_active_change_after_days"] = 1
        write_yaml(zone_path, zone)
        self.make_lifecycle_change(
            repo,
            "stale-change",
            phase="implementing",
            updated_at="2026-03-20T12:00:00Z",
            artifacts={
                "plan": "done",
                "implementation": "in_progress",
                "verification": "pending",
                "rollback": "done",
            },
            next_step="Continue implementing.",
        )

        result = gc_repo(repo, now=datetime(2026, 3, 24, 12, 0, tzinfo=timezone.utc))
        stale_issues = [item for item in result["issues"] if item["category"] == "stale"]

        self.assertEqual(len(stale_issues), 1)
        self.assertIn("stale-change", stale_issues[0]["target"])

    def test_cli_status_reports_interrupted_change_recovery_state(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="claude", profile="core")
        self.make_lifecycle_change(
            repo,
            "interrupted-change",
            phase="implementing",
            artifacts={
                "plan": "done",
                "implementation": "in_progress",
                "verification": "pending",
                "rollback": "done",
            },
            next_step="Continue implementing.",
        )

        status_result = self.run_cli_json(["status", repo, "interrupted-change", "--format", "json"])

        self.assertEqual(status_result["phase"], "implementing")
        self.assertEqual(status_result["artifacts"]["implementation"], "in_progress")
        self.assertEqual(status_result["next_step"], "Continue implementing.")
        self.assertFalse(status_result["stale"])

    def test_score_lifecycle_dimension_and_gate_requires_enforcement(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        validation = validate_repo(repo)
        write_validation_artifact(repo, validation)
        self.make_change(repo, "archive", "archived-change", lifecycle=True)

        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["enforceable"] = []
        write_yaml(zone_path, zone)

        score = score_repo(repo)

        self.assertGreaterEqual(score["weighted_score"], 0.7)
        self.assertEqual(score["operational"]["change_lifecycle"], 1.0)
        self.assertFalse(score["gates"]["enforcement_defined"])
        self.assertNotEqual(score["recommendation"], "ready-low-risk")

    def test_validate_enforcement_warns_without_enforceable(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["enforceable"] = []
        write_yaml(zone_path, zone)

        validation = validate_repo(repo, checks=["enforcement"])

        self.assertTrue(validation["passed"])
        self.assertEqual(list(validation["sections"]), ["enforcement"])
        self.assertIn(
            "No enforceable checks defined in root zone.",
            validation["sections"]["enforcement"]["warnings"],
        )

    def test_validate_enforcement_warns_without_report(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        validation = validate_repo(repo, checks=["enforcement"])

        self.assertTrue(validation["passed"])
        self.assertIn("enforceable-count:1", validation["sections"]["enforcement"]["checks"])
        self.assertIn(
            "No enforce report found. Run `rctl enforce . --write-artifact`.",
            validation["sections"]["enforcement"]["warnings"],
        )

    def test_validate_enforcement_passes_with_fresh_report(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        write_json(
            repo / "rctl" / "docs" / "quality" / "enforce-report.json",
            {
                "repo": str(repo),
                "zones": [],
                "warnings": [],
                "passed": True,
                "total_checks": 1,
                "total_errors": 0,
                "total_warnings": 0,
            },
        )

        validation = validate_repo(repo, checks=["enforcement"])

        self.assertTrue(validation["passed"])
        self.assertIn("enforce-report:passed", validation["sections"]["enforcement"]["checks"])
        self.assertEqual(validation["sections"]["enforcement"]["errors"], [])

    def test_validate_enforcement_fails_when_report_has_errors(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        write_json(
            repo / "rctl" / "docs" / "quality" / "enforce-report.json",
            {
                "repo": str(repo),
                "zones": [],
                "warnings": [],
                "passed": False,
                "total_checks": 1,
                "total_errors": 2,
                "total_warnings": 0,
            },
        )

        validation = validate_repo(repo, checks=["enforcement"])

        self.assertFalse(validation["passed"])
        self.assertIn(
            "Last enforce report had 2 errors.",
            validation["sections"]["enforcement"]["errors"],
        )

    def test_validate_enforcement_warns_when_report_is_stale(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        report_path = repo / "rctl" / "docs" / "quality" / "enforce-report.json"
        write_json(
            report_path,
            {
                "repo": str(repo),
                "zones": [],
                "warnings": [],
                "passed": True,
                "total_checks": 1,
                "total_errors": 0,
                "total_warnings": 0,
            },
        )
        timestamp = report_path.stat().st_mtime - (8 * 86400)
        os.utime(report_path, (timestamp, timestamp))

        validation = validate_repo(repo, checks=["enforcement"])

        self.assertTrue(validation["passed"])
        self.assertTrue(
            any("Enforce report is" in warning for warning in validation["sections"]["enforcement"]["warnings"])
        )

    def test_cli_validate_enforcement_check_can_run_in_isolation(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(["validate", str(repo), "--check", "enforcement", "--format", "json"])

        self.assertEqual(exit_code, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["checks_run"], ["enforcement"])
        self.assertEqual(list(payload["sections"]), ["enforcement"])

    def test_init_sets_manifest_file_ownership(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex,claude", profile="core")
        manifest = read_json(repo / ".rctl" / "manifest.json")

        self.assertEqual(
            manifest["managed_files"]["rctl/control-plane/zones/root.zone.yaml"]["ownership"],
            "rctl-owned",
        )
        self.assertEqual(
            manifest["managed_files"]["rctl/docs/project-origin.md"]["ownership"],
            "rctl-owned",
        )
        self.assertEqual(
            manifest["managed_files"][".agents/skills/rctl-plan-change/SKILL.md"]["ownership"],
            "projection",
        )
        self.assertEqual(
            manifest["managed_files"][".claude/commands/rctl-plan.md"]["ownership"],
            "projection",
        )

    def test_init_optionally_generates_ci_workflow_and_git_hook(self) -> None:
        repo = self.make_repo("python")

        with redirect_stdout(io.StringIO()) as stdout:
            exit_code = main(
                [
                    "init",
                    str(repo),
                    "--agents",
                    "codex",
                    "--profile",
                    "core",
                    "--ci",
                    "github-actions",
                    "--hooks",
                    "pre-commit",
                    "--yes",
                    "--format",
                    "json",
                ]
            )

        self.assertEqual(exit_code, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["ci"], "github-actions")
        self.assertEqual(payload["hooks"], "pre-commit")

        workflow_path = repo / ".github" / "workflows" / "rctl.yml"
        hook_path = repo / ".git" / "hooks" / "pre-commit"
        self.assertTrue(workflow_path.exists())
        self.assertTrue(hook_path.exists())
        self.assertTrue(os.access(hook_path, os.X_OK))

        workflow = read_yaml(workflow_path)
        self.assertEqual(workflow["name"], "rctl checks")
        self.assertEqual(workflow["jobs"]["rctl"]["steps"][2]["run"], "pip install repo-control-suite-kit")
        runs = [step.get("run") for step in workflow["jobs"]["rctl"]["steps"] if "run" in step]
        self.assertIn("rctl validate . --smoke --format text", runs)
        self.assertIn("rctl enforce . --ci --format text", runs)
        self.assertIn("rctl gc . --format text", runs)
        self.assertIn("python3 -m rctl enforce . --severity error --ci", read_text(hook_path))

        manifest = read_json(repo / ".rctl" / "manifest.json")
        self.assertEqual(manifest["managed_files"][".github/workflows/rctl.yml"]["ownership"], "rctl-owned")
        self.assertEqual(manifest["managed_files"][".git/hooks/pre-commit"]["ownership"], "rctl-owned")

    def test_init_merges_precommit_block_when_framework_config_exists(self) -> None:
        repo = self.make_repo("python")
        write_text(
            repo / ".pre-commit-config.yaml",
            "repos:\n"
            "  - repo: https://example.com/demo\n"
            "    rev: v1.0.0\n"
            "    hooks:\n"
            "      - id: demo\n",
        )

        result = init_repo(repo, agents="codex", profile="core", hooks="pre-commit")

        self.assertIn(".pre-commit-config.yaml", result["blocks"]["merged"])
        self.assertFalse((repo / ".git" / "hooks" / "pre-commit").exists())

        config_text = read_text(repo / ".pre-commit-config.yaml")
        self.assertIn("# rctl:block:start pre-commit", config_text)
        config = read_yaml(repo / ".pre-commit-config.yaml")
        self.assertEqual(config["repos"][0]["repo"], "https://example.com/demo")
        self.assertTrue(
            any(
                item["repo"] == "local"
                and any(hook["id"] == "rctl-enforce" for hook in item["hooks"])
                for item in config["repos"]
            )
        )

        manifest = read_json(repo / ".rctl" / "manifest.json")
        self.assertEqual(manifest["hook_target"], "pre-commit-config")
        self.assertIn(".pre-commit-config.yaml#pre-commit", manifest["managed_blocks"])

    def test_init_does_not_generate_ci_or_hook_templates_by_default(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        self.assertFalse((repo / ".github" / "workflows" / "rctl.yml").exists())
        self.assertFalse((repo / ".git" / "hooks" / "pre-commit").exists())
        self.assertFalse((repo / ".pre-commit-config.yaml").exists())

    def test_update_skips_repo_owned_files_without_conflict(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        manifest_path = repo / ".rctl" / "manifest.json"
        manifest = read_json(manifest_path)
        target = "rctl/docs/project-origin.md"
        manifest["managed_files"][target]["ownership"] = "repo-owned"
        write_json(manifest_path, manifest)
        write_text(repo / target, read_text(repo / target) + "\nLocal edit\n")

        result = update_repo(repo)

        self.assertIn(target, result["files"]["skipped"])
        self.assertNotIn(target + ".rctl.new", result["files"]["conflicts"])
        self.assertFalse((repo / f"{target}.rctl.new").exists())

    def test_update_skips_repo_owned_ci_workflow_without_conflict(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core", ci="github-actions")
        manifest_path = repo / ".rctl" / "manifest.json"
        manifest = read_json(manifest_path)
        target = ".github/workflows/rctl.yml"
        manifest["managed_files"][target]["ownership"] = "repo-owned"
        write_json(manifest_path, manifest)
        write_text(repo / target, read_text(repo / target) + "\n# local edit\n")

        result = update_repo(repo)

        self.assertIn(target, result["files"]["skipped"])
        self.assertNotIn(target + ".rctl.new", result["files"]["conflicts"])
        self.assertFalse((repo / f"{target}.rctl.new").exists())

    def test_update_promotes_modified_zone_to_repo_owned(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["owners"] = ["repo-maintainers"]
        write_yaml(zone_path, zone)

        result = update_repo(repo)
        manifest = read_json(repo / ".rctl" / "manifest.json")
        target = "rctl/control-plane/zones/root.zone.yaml"

        self.assertIn(target, result["files"]["promoted"])
        self.assertIn(target, result["files"]["skipped"])
        self.assertEqual(manifest["managed_files"][target]["ownership"], "repo-owned")
        self.assertFalse((repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml.rctl.new").exists())

    def test_update_regenerates_projection_files_even_when_modified(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        projection_path = repo / ".agents" / "skills" / "rctl-plan-change" / "SKILL.md"
        original = read_text(projection_path)
        write_text(projection_path, "locally modified projection\n")

        result = update_repo(repo)

        self.assertEqual(read_text(projection_path), original)
        self.assertIn(".agents/skills/rctl-plan-change/SKILL.md", result["files"]["refreshed"])

    def test_skill_projections_include_project_context_but_canonical_skills_do_not(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex,claude,cursor,windsurf", profile="core")

        canonical = read_text(repo / "rctl" / "skills-src" / "rctl-plan-change" / "SKILL.md")
        self.assertNotIn("## Project context", canonical)

        projection_paths = [
            repo / ".agents" / "skills" / "rctl-plan-change" / "SKILL.md",
            repo / ".claude" / "skills" / "rctl-plan-change" / "SKILL.md",
            repo / ".cursor" / "skills" / "rctl-plan-change" / "SKILL.md",
            repo / ".windsurf" / "skills" / "rctl-plan-change" / "SKILL.md",
        ]
        for path in projection_paths:
            projection = read_text(path)
            self.assertIn("## Project context", projection)
            self.assertIn("**Stack:** Python repository", projection)
            self.assertIn("**Validation commands:**", projection)
            self.assertIn("**Zone invariants:**", projection)
            self.assertIn("**Enforceable checks:** 1 defined", projection)

    def test_update_regenerates_projection_context_from_current_repo_metadata(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        control_plane_path = repo / "rctl" / "control-plane" / "control-plane.yaml"
        control_plane = read_yaml(control_plane_path)
        control_plane["context"] = {
            "description": "Agent-ready Python control plane",
            "ci": "GitHub Actions",
            "deployment": "PyPI",
        }
        write_yaml(control_plane_path, control_plane)

        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["context"] = {
            "stack": "python",
            "conventions": ["Prefer unittest for regression coverage", "Keep change evidence current"],
            "key_docs": [],
        }
        zone["invariants"] = ["Changes must leave durable artifacts under `rctl/changes/`."]
        zone["validation"]["commands"] = ["python -m unittest discover -s tests -v", "python -m rctl validate . --smoke"]
        zone["enforceable"] = []
        write_yaml(zone_path, zone)

        result = update_repo(repo)

        projection = read_text(repo / ".agents" / "skills" / "rctl-plan-change" / "SKILL.md")
        self.assertIn("## Project context", projection)
        self.assertIn("**Project description:** Agent-ready Python control plane", projection)
        self.assertIn("**CI:** GitHub Actions", projection)
        self.assertIn("**Deployment:** PyPI", projection)
        self.assertIn("Prefer unittest for regression coverage", projection)
        self.assertIn("Keep change evidence current", projection)
        self.assertIn("`python -m unittest discover -s tests -v`", projection)
        self.assertIn("`python -m rctl validate . --smoke`", projection)
        self.assertIn("Changes must leave durable artifacts under `rctl/changes/`.", projection)
        self.assertNotIn("**Enforceable checks:**", projection)
        self.assertIn(".agents/skills/rctl-plan-change/SKILL.md", result["files"]["refreshed"])

    def test_update_keeps_project_context_minimal_when_zone_metadata_is_empty(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        control_plane_path = repo / "rctl" / "control-plane" / "control-plane.yaml"
        control_plane = read_yaml(control_plane_path)
        control_plane["context"] = {"description": "Python repository", "ci": "", "deployment": ""}
        write_yaml(control_plane_path, control_plane)

        zone_path = repo / "rctl" / "control-plane" / "zones" / "root.zone.yaml"
        zone = read_yaml(zone_path)
        zone["context"] = {"stack": "python", "conventions": [], "key_docs": []}
        zone["invariants"] = []
        zone["validation"]["commands"] = []
        zone["enforceable"] = []
        write_yaml(zone_path, zone)

        update_repo(repo)

        projection = read_text(repo / ".agents" / "skills" / "rctl-plan-change" / "SKILL.md")
        self.assertIn("## Project context", projection)
        self.assertIn("**Stack:** Python repository", projection)
        self.assertNotIn("**Project description:**", projection)
        self.assertNotIn("**Conventions:**", projection)
        self.assertNotIn("**Validation commands:**", projection)
        self.assertNotIn("**Zone invariants:**", projection)
        self.assertNotIn("**Enforceable checks:**", projection)

    def test_skill_catalog_renders_enforce_and_lifecycle_guidance(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        canonical_plan = read_text(repo / "rctl" / "skills-src" / "rctl-plan-change" / "SKILL.md")
        self.assertIn("`rctl enforce . --dry-run`", canonical_plan)
        self.assertIn("lifecycle (phase, timestamps, artifact states, next_step)", canonical_plan)
        self.assertIn("`rctl next . <change-id> --update`", canonical_plan)

        projection_plan = read_text(repo / ".agents" / "skills" / "rctl-plan-change" / "SKILL.md")
        self.assertIn("`rctl enforce . --dry-run`", projection_plan)
        self.assertIn("`rctl next . <change-id> --update`", projection_plan)
        self.assertIn("## Project context", projection_plan)

        canonical_implement = read_text(repo / "rctl" / "skills-src" / "rctl-implement-change" / "SKILL.md")
        self.assertIn("`lifecycle.updated_at`", canonical_implement)
        self.assertIn("update `status.md` with what is done and what is next", canonical_implement)
        self.assertIn("Open `change.yaml`, `plan.md`, `status.md`, and `evidence.md`", canonical_implement)
        self.assertIn("Completing implementation without updating lifecycle state", canonical_implement)

        canonical_verify = read_text(repo / "rctl" / "skills-src" / "rctl-verify-change" / "SKILL.md")
        self.assertIn("`rctl enforce .`", canonical_verify)
        self.assertIn("If resuming mid-verification, read `evidence.md`", canonical_verify)
        self.assertIn("Do not trust partial evidence", canonical_verify)
        self.assertIn("Append new findings", canonical_verify)
        self.assertIn("`rctl-evaluate-change`", canonical_verify)
        self.assertIn("`evaluator-report.md`", canonical_verify)
        self.assertIn("`artifacts.verification` to `done`", canonical_verify)
        self.assertIn("invoke `rctl-evaluate-change`", canonical_verify)

        canonical_evaluate = read_text(repo / "rctl" / "skills-src" / "rctl-evaluate-change" / "SKILL.md")
        self.assertIn("Adopt an adversarial mindset", canonical_evaluate)
        self.assertIn("`pass`, `fail`, or `unknown`", canonical_evaluate)
        self.assertIn("Functional correctness", canonical_evaluate)
        self.assertIn("Operator/UX clarity", canonical_evaluate)
        self.assertIn("`evaluator-report.md`", canonical_evaluate)
        self.assertNotIn("claude_agent_sdk", canonical_evaluate)
        self.assertNotIn("sonnet", canonical_evaluate)

        canonical_archive = read_text(repo / "rctl" / "skills-src" / "rctl-archive-change" / "SKILL.md")
        self.assertIn("`rctl status . <change-id>`", canonical_archive)

        canonical_drift = read_text(repo / "rctl" / "skills-src" / "rctl-scan-drift" / "SKILL.md")
        self.assertIn("`rctl gc . --dry-run`", canonical_drift)

    def test_skill_checkpoint_guidance_projects_to_all_agent_surfaces(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex,claude,cursor,windsurf", profile="core")

        projection_paths = [
            repo / ".agents" / "skills" / "rctl-implement-change" / "SKILL.md",
            repo / ".claude" / "skills" / "rctl-implement-change" / "SKILL.md",
            repo / ".cursor" / "skills" / "rctl-implement-change" / "SKILL.md",
            repo / ".windsurf" / "skills" / "rctl-implement-change" / "SKILL.md",
            repo / ".agents" / "skills" / "rctl-verify-change" / "SKILL.md",
            repo / ".claude" / "skills" / "rctl-verify-change" / "SKILL.md",
            repo / ".cursor" / "skills" / "rctl-verify-change" / "SKILL.md",
            repo / ".windsurf" / "skills" / "rctl-verify-change" / "SKILL.md",
            repo / ".agents" / "skills" / "rctl-evaluate-change" / "SKILL.md",
            repo / ".claude" / "skills" / "rctl-evaluate-change" / "SKILL.md",
            repo / ".cursor" / "skills" / "rctl-evaluate-change" / "SKILL.md",
            repo / ".windsurf" / "skills" / "rctl-evaluate-change" / "SKILL.md",
        ]

        for path in projection_paths:
            projection = read_text(path)
            self.assertIn("## Project context", projection)

        for path in projection_paths[:4]:
            projection = read_text(path)
            self.assertIn("update `status.md` with what is done and what is next", projection)
            self.assertIn("`## Recovery point` section", projection)
            self.assertIn("Open `change.yaml`, `plan.md`, `status.md`, and `evidence.md`", projection)

        for path in projection_paths[4:]:
            projection = read_text(path)
            if "rctl-verify-change" in str(path):
                self.assertIn("read `evidence.md` to see what was already checked", projection)
                self.assertIn("Do not trust partial evidence", projection)
                self.assertIn("Append new findings", projection)
            else:
                self.assertIn("Adopt an adversarial mindset", projection)
                self.assertIn("`pass`, `fail`, or `unknown`", projection)
                self.assertIn("Functional correctness", projection)
                self.assertNotIn("claude_agent_sdk", projection)
                self.assertNotIn("sonnet", projection)

    def test_skill_evals_reference_enforce_status_and_next_commands(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        def _eval_text(item: dict) -> str:
            """Concatenate all searchable text fields of an eval item."""
            parts = [item.get("prompt", ""), item.get("expected_output", "")]
            parts.extend(item.get("expectations", []))
            return " ".join(parts)

        plan_evals = read_json(repo / "rctl" / "skills-src" / "rctl-plan-change" / "evals" / "evals.json")
        self.assertTrue(any("rctl next" in _eval_text(item) for item in plan_evals["evals"]))
        self.assertTrue(any("validation commands" in _eval_text(item) for item in plan_evals["evals"]))
        self.assertTrue(any(item["type"] == "adversarial" for item in plan_evals["evals"]))

        implement_evals = read_json(repo / "rctl" / "skills-src" / "rctl-implement-change" / "evals" / "evals.json")
        self.assertTrue(any("status.md" in _eval_text(item) for item in implement_evals["evals"]))
        self.assertTrue(any("change.yaml lifecycle" in _eval_text(item) for item in implement_evals["evals"]))
        self.assertTrue(any(item["type"] == "adversarial" for item in implement_evals["evals"]))

        verify_evals = read_json(repo / "rctl" / "skills-src" / "rctl-verify-change" / "evals" / "evals.json")
        self.assertTrue(any("rctl enforce" in _eval_text(item) for item in verify_evals["evals"]))
        self.assertTrue(any(item["type"] == "adversarial" for item in verify_evals["evals"]))

        archive_evals = read_json(repo / "rctl" / "skills-src" / "rctl-archive-change" / "evals" / "evals.json")
        self.assertTrue(any("archived" in _eval_text(item) for item in archive_evals["evals"]))
        self.assertTrue(any(item["type"] == "adversarial" for item in archive_evals["evals"]))

        drift_evals = read_json(repo / "rctl" / "skills-src" / "rctl-scan-drift" / "evals" / "evals.json")
        self.assertTrue(any("rctl gc" in _eval_text(item) for item in drift_evals["evals"]))
        self.assertTrue(any(item["type"] == "adversarial" for item in drift_evals["evals"]))

        adversarial_counts = [
            sum(1 for item in evals["evals"] if item["type"] == "adversarial")
            for evals in (plan_evals, implement_evals, verify_evals, archive_evals, drift_evals)
        ]
        self.assertGreaterEqual(sum(1 for count in adversarial_counts if count > 0), 5)

    def test_skill_evals_render_standard_and_adversarial_types(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")

        for skill_name in (
            "rctl-onboard-repo",
            "rctl-plan-change",
            "rctl-implement-change",
            "rctl-verify-change",
            "rctl-evaluate-change",
            "rctl-archive-change",
            "rctl-scan-drift",
        ):
            evals = read_json(repo / "rctl" / "skills-src" / skill_name / "evals" / "evals.json")
            self.assertIn("standard", {item["type"] for item in evals["evals"]})
            self.assertIn("adversarial", {item["type"] for item in evals["evals"]})

    def test_validate_accepts_legacy_skill_eval_entries_without_type(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        evals_path = repo / "rctl" / "skills-src" / "rctl-plan-change" / "evals" / "evals.json"
        evals = read_json(evals_path)
        evals["evals"][0].pop("type", None)
        write_json(evals_path, evals)

        validation = validate_repo(repo)

        self.assertTrue(validation["passed"])
        self.assertEqual(validation["sections"]["structure"]["errors"], [])

    def test_validate_rejects_invalid_skill_eval_type(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        evals_path = repo / "rctl" / "skills-src" / "rctl-plan-change" / "evals" / "evals.json"
        evals = read_json(evals_path)
        evals["evals"][0]["type"] = "chaos"
        write_json(evals_path, evals)

        validation = validate_repo(repo)

        self.assertFalse(validation["passed"])
        self.assertTrue(
            any("unsupported type" in error for error in validation["sections"]["structure"]["errors"])
        )

    def test_command_and_rule_projections_reference_enforce_status_and_next(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="claude,cursor,windsurf", profile="core")

        claude_plan = read_text(repo / ".claude" / "commands" / "rctl-plan.md")
        self.assertIn("`rctl/control-plane/zones/`", claude_plan)
        self.assertIn("`rctl enforce . --dry-run`", claude_plan)
        self.assertIn("`rctl status . <change-id>`", claude_plan)
        self.assertIn("`rctl next . <change-id> --update`", claude_plan)

        windsurf_plan = read_text(repo / ".windsurf" / "workflows" / "rctl-plan.md")
        self.assertIn("`rctl/control-plane/zones/`", windsurf_plan)
        self.assertIn("`rctl enforce . --dry-run`", windsurf_plan)
        self.assertIn("`rctl status . <change-id>`", windsurf_plan)
        self.assertIn("`rctl next . <change-id> --update`", windsurf_plan)

        cursor_rule = read_text(repo / ".cursor" / "rules" / "rctl-routing.mdc")
        self.assertIn("`rctl enforce . --dry-run`", cursor_rule)
        self.assertIn("`rctl status .` or `rctl status . <change-id>`", cursor_rule)
        self.assertIn("`rctl next . <change-id> --update`", cursor_rule)

        windsurf_rule = read_text(repo / ".windsurf" / "rules" / "rctl-routing.md")
        self.assertIn("`rctl/control-plane/control-plane.yaml`", windsurf_rule)
        self.assertIn("`rctl enforce . --dry-run`", windsurf_rule)
        self.assertIn("`rctl status .` or `rctl status . <change-id>`", windsurf_rule)
        self.assertIn("`rctl next . <change-id> --update`", windsurf_rule)

    def test_update_defaults_missing_ownership_to_rctl_owned(self) -> None:
        repo = self.make_repo("python")

        init_repo(repo, agents="codex", profile="core")
        manifest_path = repo / ".rctl" / "manifest.json"
        manifest = read_json(manifest_path)
        for entry in manifest["managed_files"].values():
            entry.pop("ownership", None)
        write_json(manifest_path, manifest)
        target = repo / "rctl" / "docs" / "project-origin.md"
        write_text(target, read_text(target) + "\nLocal edit\n")

        result = update_repo(repo)

        self.assertIn("rctl/docs/project-origin.md.rctl.new", result["files"]["conflicts"])
        self.assertTrue((repo / "rctl" / "docs" / "project-origin.md.rctl.new").exists())

    def test_update_preserves_user_guidance_and_emits_conflict_for_modified_managed_file(self) -> None:
        repo = self.make_repo("node")
        write_text(repo / "AGENTS.md", "# Existing agent notes\nKeep this.\n")
        init_repo(repo, agents="codex,claude", profile="core")

        write_text(repo / "rctl" / "docs" / "project-origin.md", read_text(repo / "rctl" / "docs" / "project-origin.md") + "\nLocal edit\n")
        write_text(repo / "AGENTS.md", "User line\n\n" + read_text(repo / "AGENTS.md"))

        result = update_repo(repo)

        self.assertIn("rctl/docs/project-origin.md.rctl.new", result["files"]["conflicts"])
        self.assertTrue((repo / "rctl" / "docs" / "project-origin.md.rctl.new").exists())
        agents_text = read_text(repo / "AGENTS.md")
        self.assertTrue(agents_text.startswith("User line"))
        self.assertIn("<!-- rctl:block:start routing -->", agents_text)


if __name__ == "__main__":
    unittest.main()
