# !/usr/bin/python
# coding=utf-8
from typing import List, Tuple, Dict, ClassVar, Optional, Union, Any, Iterable, Set
import math

try:
    import pymel.core as pm
except ImportError as error:
    print(__file__, error)
try:
    from maya.api import OpenMaya as om
except ImportError:
    om = None

import pythontk as ptk

# from this package:
from mayatk.core_utils._core_utils import CoreUtils
from mayatk.xform_utils._xform_utils import XformUtils


class _AnimUtilsMixin:
    """Helper mixin that contains internal shared logic for AnimUtils"""

    @staticmethod
    def _filter_attributes_by_ignore(
        attributes: Optional[List[Any]], ignore: Optional[Union[str, List[str]]]
    ) -> List[Any]:
        """Filter attribute names based on the ignore list."""

        if not attributes:
            return []

        if not ignore:
            return list(attributes)

        # Parse ignore patterns into full names and simple names (last component)
        ignore_list = [ignore] if isinstance(ignore, str) else ignore
        ignored_full: Set[str] = set()
        ignored_simple: Set[str] = set()

        for pattern in ignore_list:
            if not pattern:
                continue
            pattern_lower = str(pattern).lower()
            ignored_full.add(pattern_lower)
            # Extract simple name (last component after . or |) using func parameter
            if "." in pattern_lower:
                parts = ptk.split_delimited_string(
                    pattern_lower, delimiter=".", func=lambda x: x[-1:]
                )
                ignored_simple.add(parts[0])
            elif "|" in pattern_lower:
                parts = ptk.split_delimited_string(
                    pattern_lower, delimiter="|", func=lambda x: x[-1:]
                )
                ignored_simple.add(parts[0])
            else:
                ignored_simple.add(pattern_lower)

        if not ignored_full and not ignored_simple:
            return list(attributes)

        filtered: List[Any] = []
        for attr in attributes:
            attr_name = str(attr)
            attr_lower = attr_name.lower()
            simple = attr_lower.split(".")[-1]
            if attr_lower in ignored_full or simple in ignored_simple:
                continue
            filtered.append(attr)
        return filtered

    @staticmethod
    def _filter_curves_by_ignore(
        curves: Optional[List[Union[str, "pm.PyNode"]]],
        ignore: Optional[Union[str, List[str]]],
    ) -> List["pm.PyNode"]:
        """Filter animation curves that should be ignored."""

        if not curves:
            return []

        if not ignore:
            return [pm.PyNode(c) for c in curves]

        # Parse ignore patterns into full names and simple names (last component)
        ignore_list = [ignore] if isinstance(ignore, str) else ignore
        ignored_full: Set[str] = set()
        ignored_attrs: Set[str] = set()

        for pattern in ignore_list:
            if not pattern:
                continue
            pattern_lower = str(pattern).lower()
            ignored_full.add(pattern_lower)
            # Extract simple name (last component after . or |) using func parameter
            if "." in pattern_lower:
                parts = ptk.split_delimited_string(
                    pattern_lower, delimiter=".", func=lambda x: x[-1:]
                )
                ignored_attrs.add(parts[0])
            elif "|" in pattern_lower:
                parts = ptk.split_delimited_string(
                    pattern_lower, delimiter="|", func=lambda x: x[-1:]
                )
                ignored_attrs.add(parts[0])
            else:
                ignored_attrs.add(pattern_lower)

        ignored_suffixes: Tuple[str, ...] = tuple(
            list(f"_{attr}" for attr in ignored_attrs)
            + list(f".{attr}" for attr in ignored_attrs)
        )

        filtered: List["pm.PyNode"] = []
        for curve in curves:
            try:
                curve_node = pm.PyNode(curve)
            except Exception:
                continue

            curve_name = str(curve_node).lower()
            if curve_name in ignored_full:
                continue

            connections = list(curve_node.outputs(plugs=True))
            if not connections:
                connections = (
                    pm.listConnections(
                        curve_node, plugs=True, destination=True, source=False
                    )
                    or []
                )

            include_curve = True
            for conn in connections:
                try:
                    full_name = conn.longName()
                except AttributeError:
                    full_name = str(conn)
                full_name = full_name.lower()
                simple_name = full_name.split(".")[-1]

                if full_name in ignored_full or simple_name in ignored_attrs:
                    include_curve = False
                    break

            if include_curve and ignored_suffixes:
                if curve_name.endswith(ignored_suffixes):
                    include_curve = False

            if include_curve:
                filtered.append(curve_node)

        return filtered

    @staticmethod
    def _get_visibility_curves(
        curves: List["pm.PyNode"],
    ) -> Tuple[List["pm.PyNode"], List["pm.PyNode"]]:
        """Split curves into visibility curves and others.

        Returns:
            Tuple of (visibility_curves, other_curves)
        """
        vis_curves = []
        other_curves = []

        for curve in curves:
            is_visibility = False
            try:
                # Check curve name
                curve_name = curve.name().lower()
                if "visibility" in curve_name:
                    is_visibility = True
                else:
                    # Check connections
                    plugs = curve.outputs(plugs=True)
                    for plug in plugs:
                        # Check plug name
                        try:
                            if hasattr(plug, "partialName"):
                                plug_name = plug.partialName(includeNode=False).lower()
                            else:
                                plug_name = plug.longName(fullPath=False).lower()
                        except Exception:
                            plug_name = str(plug).split(".")[-1].lower()

                        if "visibility" in plug_name:
                            is_visibility = True
                            break

                        # Check attribute type (boolean attributes should be stepped)
                        try:
                            # If plug is an Attribute object, we can check it directly
                            if hasattr(plug, "type"):
                                attr_type = plug.type()
                            else:
                                attr = plug.node().attr(plug.longName(fullPath=False))
                                attr_type = attr.type()

                            if attr_type == "bool":
                                is_visibility = True
                                break
                        except Exception:
                            pass

                # Debug print
                # print(f"DEBUG: Curve {curve} (name={curve_name}) is_vis={is_visibility}")
            except Exception as e:
                print(f"DEBUG: Outer exception for {curve}: {e}")
                pass

            if is_visibility:
                vis_curves.append(curve)
            else:
                other_curves.append(curve)

        return vis_curves, other_curves

    @staticmethod
    def _set_smart_tangents(
        curves: List["pm.PyNode"],
        tangent_type: str = "auto",
        time_range: Optional[Tuple[float, float]] = None,
        preserve_stepped: bool = True,
    ) -> None:
        """Apply tangent type to curves, enforcing 'step' for visibility attributes.

        Parameters:
            curves: List of animation curves to modify.
            tangent_type: The tangent type to apply to standard curves (default: 'auto').
            time_range: Optional (start, end) tuple to limit the effect.
            preserve_stepped: If True, existing 'step' tangents on non-visibility curves
                            will be preserved. Default is True.
        """
        if not curves:
            return

        curves_to_step, curves_to_smooth = _AnimUtilsMixin._get_visibility_curves(
            curves
        )

        range_args = {"time": time_range} if time_range else {}

        if curves_to_smooth:
            for curve in curves_to_smooth:
                try:
                    # If preserving stepped tangents, we need to check existing types
                    restore_steps = []
                    if preserve_stepped:
                        # Query existing tangent types
                        # Note: keyTangent query returns list of strings
                        # We must query times first to match them up, as keyTangent might return types for all keys in range
                        times = pm.keyframe(curve, query=True, tc=True, **range_args)
                        if times:
                            types = pm.keyTangent(
                                curve, query=True, outTangentType=True, **range_args
                            )
                            if types and len(types) == len(times):
                                # Identify stepped keys
                                for t, type_name in zip(times, types):
                                    if type_name in ("step", "stepnext"):
                                        restore_steps.append(t)

                    # Apply smoothing to all (bulk operation is faster)
                    pm.keyTangent(
                        curve,
                        edit=True,
                        outTangentType=tangent_type,
                        inTangentType=tangent_type,
                        **range_args,
                    )

                    # Restore stepped tangents if any were found
                    if restore_steps:
                        for t in restore_steps:
                            pm.keyTangent(
                                curve,
                                edit=True,
                                time=(t,),
                                outTangentType="step",
                                inTangentType="clamped",
                            )

                except RuntimeError as e:
                    pm.warning(f"Failed to adjust smooth tangents for {curve}: {e}")

        if curves_to_step:
            try:
                # 'step' is only valid for out-tangents.
                # For in-tangents, we use 'clamped' to avoid errors, though it doesn't affect the step behavior.
                pm.keyTangent(
                    curves_to_step,
                    edit=True,
                    outTangentType="step",
                    inTangentType="clamped",
                    **range_args,
                )
            except RuntimeError as e:
                pm.warning(f"Failed to adjust step tangents: {e}")

    @classmethod
    def _compute_motion_progress(
        cls,
        obj: "pm.PyNode",
        time_range: Tuple[float, float],
        samples: Optional[int] = None,
        include_rotation: Union[bool, str] = False,
    ) -> Tuple[List[float], List[float], float]:
        """Sample an object's motion and return normalized progress values."""

        if obj is None or not pm.objExists(obj):
            return [], [], 0.0

        if not time_range or len(time_range) != 2:
            return [], [], 0.0

        start, end = time_range
        if start is None or end is None or end <= start:
            return [], [], 0.0

        try:
            sample_count = int(samples) if samples is not None else 64
        except (TypeError, ValueError):
            sample_count = 64

        sample_count = max(3, sample_count)

        span = end - start
        if sample_count == 1 or math.isclose(span, 0.0):
            return [], [], 0.0

        sample_times = [
            float(start + (span * index) / (sample_count - 1))
            for index in range(sample_count)
        ]

        current_time = pm.currentTime(query=True)
        positions: List[Tuple[float, float, float]] = []
        rotations: List[Tuple[float, float, float]] = []

        try:
            for time_value in sample_times:
                pm.currentTime(time_value, edit=True)

                # Sample position
                position = pm.xform(obj, query=True, worldSpace=True, translation=True)
                if not position or len(position) < 3:
                    return [], [], 0.0
                positions.append(
                    (float(position[0]), float(position[1]), float(position[2]))
                )

                # Sample rotation if needed
                if include_rotation:
                    rotation = pm.xform(obj, query=True, worldSpace=True, rotation=True)
                    if rotation and len(rotation) >= 3:
                        rotations.append(
                            (float(rotation[0]), float(rotation[1]), float(rotation[2]))
                        )
                    else:
                        rotations.append((0.0, 0.0, 0.0))

        except Exception:
            return [], [], 0.0
        finally:
            pm.currentTime(current_time, edit=True)

        if len(positions) < 2:
            return [], [], 0.0

        cumulative: List[float] = [0.0]
        total_distance = 0.0

        deg_to_rad = math.pi / 180.0

        for index in range(1, len(positions)):
            # Translation distance
            dist_trans = 0.0
            if include_rotation != "only":
                dist_trans = ptk.MathUtils.distance_between_points(
                    positions[index - 1], positions[index]
                )

            dist_rot = 0.0

            # Rotation distance (arc length approximation)
            if include_rotation and index < len(rotations):
                r1_vals = rotations[index - 1]
                r2_vals = rotations[index]

                # Simplified rotation distance: Euclidean distance of Euler angles
                # Treats 1 degree of rotation as equivalent to 1 unit of translation
                d_rx = abs(r2_vals[0] - r1_vals[0])
                d_ry = abs(r2_vals[1] - r1_vals[1])
                d_rz = abs(r2_vals[2] - r1_vals[2])
                dist_rot = math.sqrt(d_rx * d_rx + d_ry * d_ry + d_rz * d_rz)

            # Use the maximum of translation or rotation distance
            step_distance = max(dist_trans, dist_rot)

            total_distance += step_distance
            cumulative.append(total_distance)

        if total_distance <= 1e-8:
            progress = [0.0 for _ in cumulative]
        else:
            progress = [value / total_distance for value in cumulative]

        return sample_times, progress, total_distance

    @staticmethod
    def _get_curve_tangent_data(
        curve: "pm.PyNode", time: float
    ) -> Optional[Dict[str, Any]]:
        """Capture tangent information for a keyframe on the given curve."""

        try:
            return {
                "inTangentType": pm.keyTangent(
                    curve, query=True, time=(time,), inTangentType=True
                )[0],
                "outTangentType": pm.keyTangent(
                    curve, query=True, time=(time,), outTangentType=True
                )[0],
                "inAngle": pm.keyTangent(curve, query=True, time=(time,), inAngle=True)[
                    0
                ],
                "outAngle": pm.keyTangent(
                    curve, query=True, time=(time,), outAngle=True
                )[0],
                "inWeight": pm.keyTangent(
                    curve, query=True, time=(time,), inWeight=True
                )[0],
                "outWeight": pm.keyTangent(
                    curve, query=True, time=(time,), outWeight=True
                )[0],
            }
        except Exception:
            return None

    @staticmethod
    def _apply_curve_tangent_data(
        curve: "pm.PyNode", time: float, data: Optional[Dict[str, Any]]
    ) -> None:
        """Restore tangent information for a keyframe on the given curve."""

        if not data:
            return

        in_type = data.get("inTangentType")
        out_type = data.get("outTangentType")

        try:
            pm.keyTangent(
                curve,
                edit=True,
                time=(time,),
                inTangentType=in_type,
                outTangentType=out_type,
            )
            # Only apply angle/weight for non-step tangents
            # Step tangents are immediate jumps with no adjustable angle/weight
            if in_type not in ("step", "stepnext") or out_type not in (
                "step",
                "stepnext",
            ):
                pm.keyTangent(
                    curve,
                    edit=True,
                    time=(time,),
                    inAngle=data.get("inAngle"),
                    outAngle=data.get("outAngle"),
                    inWeight=data.get("inWeight"),
                    outWeight=data.get("outWeight"),
                )
        except Exception:
            pass

    @staticmethod
    def _curves_to_attributes(curves: List["pm.PyNode"], obj: "pm.PyNode") -> List[str]:
        """Helper method to extract attribute names from animation curves connected to an object."""

        attributes = []
        for curve in curves:
            connections = pm.listConnections(
                curve, plugs=True, destination=True, source=False
            )
            if connections:
                for conn in connections:
                    attr_name = conn.attrName()
                    if attr_name and obj.hasAttr(attr_name):
                        attributes.append(attr_name)
        return list(set(attributes))


def _freeze_adjacent_tangent(fn, idx, is_in, bookend_facing, auto_types, step_types):
    """Freeze an auto tangent to kFixed (preserving its current XY), or set
    the bookend-facing side to kFlat for a constant-value hold.

    Parameters:
        fn (MFnAnimCurve): The animation curve function set.
        idx (int): Key index whose tangent to freeze.
        is_in (bool): True = in-tangent, False = out-tangent.
        bookend_facing (bool): True if this tangent handle faces the bookend
            key (should become flat).  False if it faces the curve interior
            (should lock its current angle via kFixed).
        auto_types (set): Set of MFnAnimCurve tangent type constants that are
            auto-computed (kTangentAuto, kTangentSmooth, kTangentClamped).
        step_types (set): Set of step tangent type constants to skip.
    """
    import maya.api.OpenMayaAnim as oma2

    tt = fn.inTangentType(idx) if is_in else fn.outTangentType(idx)
    if tt in step_types:
        return  # Stepped tangents are never recalculated — nothing to freeze.

    if tt in auto_types:
        if bookend_facing:
            # Set to flat for a clean constant-value hold into the bookend.
            if is_in:
                fn.setInTangentType(idx, oma2.MFnAnimCurve.kTangentFlat)
            else:
                fn.setOutTangentType(idx, oma2.MFnAnimCurve.kTangentFlat)
        else:
            # Interior-facing: snapshot current XY, then convert to kFixed
            # so Maya won't recalculate it when a neighbor key is added.
            xy = fn.getTangentXY(idx, is_in)
            if is_in:
                fn.setInTangentType(idx, oma2.MFnAnimCurve.kTangentFixed)
                fn.setTangent(idx, xy[0], xy[1], True)
            else:
                fn.setOutTangentType(idx, oma2.MFnAnimCurve.kTangentFixed)
                fn.setTangent(idx, xy[0], xy[1], False)


def _find_adjacent_key(fn, frame, n):
    """Find the index of the first key at or after *frame*.

    Returns None if no key is found (all keys are before *frame*).
    """
    for ki in range(n):
        if fn.input(ki).value >= frame - 1e-4:
            return ki
    return None


class AnimUtils(_AnimUtilsMixin, ptk.HelpMixin):
    """Animation utilities for Maya.

    For help on this class use: AnimUtils.help()

    BEST PRACTICES FOR GETTING ANIMATION CURVES:
    ============================================

    When working with animation curves, use these methods to ensure you capture ALL curve types
    (including visibility, custom attributes, etc.):

    1. For simple object-to-curves conversion:
       curves = AnimUtils.objects_to_curves(objects, recursive=False)

    2. For common patterns (scene curves, selected keys, object curves):
       curves = AnimUtils.get_anim_curves(objects=None, selected_keys_only=False, recursive=False)

    3. Both methods use pm.listConnections(type="animCurve") which properly captures all curve types.

    AVOID querying keyframes at the object level for curve operations:
       - pm.keyframe(obj, query=True, timeChange=True) # May miss some attributes

    PREFERRED approach - work with curves directly:
       - Get curves first using objects_to_curves() or get_anim_curves()
       - Then query/modify the curves: pm.keyframe(curve, query=True, timeChange=True)
    """

    @staticmethod
    def _set_key_preserving_tangents(
        plug: str, time: float, value: float, **kwargs
    ) -> None:
        """Set a keyframe while preserving existing tangent types.

        If a key already exists at *time* its in/out tangent types are
        snapshotted before the value is written and restored afterwards.
        If no key exists, the tangent type of the nearest preceding key on
        the same curve is inherited so that stepped (or other non-default)
        tangent styles propagate correctly.

        Any extra *kwargs* are forwarded to ``pm.setKeyframe``.

        Note:
            If *kwargs* includes ``inTangentType`` or ``outTangentType``
            they will override the automatically preserved tangent types.
        """
        import maya.cmds as cmds

        existing_key = cmds.keyframe(
            plug, query=True, time=(time, time), timeChange=True
        )
        tangent_types = None

        if existing_key:
            try:
                itt = cmds.keyTangent(
                    plug, query=True, time=(time, time), inTangentType=True
                )
                ott = cmds.keyTangent(
                    plug, query=True, time=(time, time), outTangentType=True
                )
                if itt and ott:
                    tangent_types = (itt[0], ott[0])
            except Exception:
                pass
        else:
            # No key at this time — inherit from nearest preceding key.
            try:
                all_times = cmds.keyframe(plug, query=True, timeChange=True)
                if all_times:
                    preceding = [kt for kt in all_times if kt < time]
                    if preceding:
                        pt = max(preceding)
                        itt = cmds.keyTangent(
                            plug, query=True, time=(pt, pt), inTangentType=True
                        )
                        ott = cmds.keyTangent(
                            plug, query=True, time=(pt, pt), outTangentType=True
                        )
                        if itt and ott:
                            tangent_types = (itt[0], ott[0])
            except Exception:
                pass

        # Set the keyframe — pass tangent types at creation time when
        # available so Maya doesn't need a second edit pass (which can
        # silently drop "step" in-tangent types).
        #
        # Maya does NOT accept "step" as an inTangentType (only as
        # outTangentType).  The in-tangent equivalent is "stepnext".
        # Types that Maya only accepts as outTangentType.
        # Map them to a sensible in-tangent equivalent.
        _IN_TANGENT_REMAP = {"step": "stepnext", "fixed": "auto"}

        kw = dict(time=time, value=value)
        if tangent_types:
            in_tt = _IN_TANGENT_REMAP.get(tangent_types[0], tangent_types[0])
            kw["inTangentType"] = in_tt
            kw["outTangentType"] = tangent_types[1]
        kw.update(kwargs)
        pm.setKeyframe(plug, **kw)

        # Belt-and-suspenders: re-apply tangent types after creation
        # in case setKeyframe's auto-tangent logic overrode them.
        if tangent_types:
            try:
                cmds.keyTangent(
                    plug,
                    time=(time, time),
                    edit=True,
                    outTangentType=tangent_types[1],
                )
            except Exception:
                pass
            try:
                cmds.keyTangent(
                    plug,
                    time=(time, time),
                    edit=True,
                    inTangentType=in_tt,
                )
            except Exception:
                pass

    @classmethod
    def bake(
        cls,
        objects: Union[str, List[Union[str, "pm.PyNode"]]],
        attributes: Optional[Union[str, List[str]]] = None,
        time_range: Optional[Tuple[float, float]] = None,
        sample_by: float = 1.0,
        preserve_outside_keys: bool = True,
        simulation: bool = False,
        destination_layer: Optional[str] = None,
        remove_baked_attr_from_layer: bool = False,
        bake_on_override_layer: bool = False,
        minimize_rotation: bool = True,
        sparse_anim_curve_bake: bool = False,
        disable_implicit_control: bool = True,
        control_points: bool = False,
        shape: bool = False,
        only_keyed: bool = False,
    ) -> List["pm.PyNode"]:
        """Bake animation on specified objects and attributes with smart grouping.

        Handles filtering valid attributes per object and grouping them for
        efficient batch execution.

        Parameters:
            objects: Object(s) to bake.
            attributes: Attribute name(s) to bake. If None, bakes all keyable.
            time_range: (start, end) tuple. If None, uses current playback range.
            sample_by: Step size for baking keys.
            preserve_outside_keys: Keep keys outside the bake range.
            simulation: Perform simulation bake.
            destination_layer: Target animation layer name.
            remove_baked_attr_from_layer: Remove attributes from source layer.
            bake_on_override_layer: Bake onto the override layer.
            minimize_rotation: Ensure rotation continuity (Euler filter).
            sparse_anim_curve_bake: Use sparse baking.
            disable_implicit_control: Disable implicit control during bake.
            control_points: Bake control points.
            shape: Bake shapes.
            only_keyed: Only bake attributes that already have animation curves.

        Returns:
            List of baked objects/curves (result of pm.bakeResults).
        """
        import collections

        # 1. Normalize objects
        if not objects:
            return []

        if isinstance(objects, (str, pm.PyNode)):
            objects = [objects]

        valid_objects = []
        for o in objects:
            if pm.objExists(o):
                valid_objects.append(
                    pm.PyNode(o) if not isinstance(o, pm.PyNode) else o
                )

        if not valid_objects:
            return []

        # 2. Normalize attributes
        req_attrs = None
        if attributes:
            if isinstance(attributes, str):
                req_attrs = [attributes]
            else:
                req_attrs = attributes

        # 3. Group objects by bakeable attributes to batch efficiently
        # Map: tuple(sorted_attr_names) -> list[objects]
        groups = collections.defaultdict(list)

        for obj in valid_objects:
            attrs_to_bake = []

            # If specific attributes requested
            if req_attrs:
                for attr_name in req_attrs:
                    if not obj.hasAttr(attr_name):
                        continue

                    if only_keyed:
                        if not pm.listConnections(
                            obj.attr(attr_name), type="animCurve"
                        ):
                            continue

                    attrs_to_bake.append(attr_name)

                # If no requested attributes found valid, skip object
                if not attrs_to_bake:
                    continue

                key = tuple(sorted(attrs_to_bake))
                groups[key].append(obj)

            # If no attributes requested (bake all)
            else:
                # If only_keyed demanded for 'all' mode, we rely on bakeResults behavior?
                # bakeResults without -at flag bakes all keyable.
                # If we want to strictly enforce 'only_keyed', we have to find them manually.
                # For now, assuming standard behavior for None attributes unless explicitly requested.
                groups[None].append(obj)

        # 4. Execute Batches
        results = []

        # Build common kwargs
        kwargs = {
            "sampleBy": sample_by,
            "preserveOutsideKeys": preserve_outside_keys,
            "simulation": simulation,
            "minimizeRotation": minimize_rotation,
            "sparseAnimCurveBake": sparse_anim_curve_bake,
            "disableImplicitControl": disable_implicit_control,
            "controlPoints": control_points,
            "shape": shape,
        }
        if time_range:
            kwargs["time"] = time_range
        if destination_layer:
            kwargs["destinationLayer"] = destination_layer
            kwargs["removeBakedAttributeFromLayer"] = remove_baked_attr_from_layer
            kwargs["bakeOnOverrideLayer"] = bake_on_override_layer

        for attr_tuple, objs_in_group in groups.items():
            run_kwargs = kwargs.copy()
            if attr_tuple is not None:
                run_kwargs["attribute"] = list(attr_tuple)

            try:
                pm.bakeResults(objs_in_group, **run_kwargs)
                # pm.bakeResults returns None but does not raise on
                # success.  Record the objects as successfully baked.
                results.extend([str(o) for o in objs_in_group])
            except Exception as e:
                pm.warning(f"AnimUtils.bake batch failed: {e}")

        return results

    @classmethod
    def bake_objects(
        cls,
        objects: List[Union[str, "pm.PyNode"]],
        attributes: Optional[List[str]] = None,
        time_range: Optional[Tuple[float, float]] = None,
        sample_by: float = 1.0,
        preserve_outside_keys: bool = True,
        simulation: bool = False,
        destination_layer: Optional[str] = None,
        remove_baked_attr_from_layer: bool = False,
        bake_on_override_layer: bool = False,
        minimize_rotation: bool = True,
        sparse_anim_curve_bake: bool = False,
        disable_implicit_control: bool = True,
        control_points: bool = False,
        shape: bool = False,
    ) -> List["pm.PyNode"]:
        """Legacy alias for bake()."""
        return cls.bake(
            objects,
            attributes=attributes,
            time_range=time_range,
            sample_by=sample_by,
            preserve_outside_keys=preserve_outside_keys,
            simulation=simulation,
            destination_layer=destination_layer,
            remove_baked_attr_from_layer=remove_baked_attr_from_layer,
            bake_on_override_layer=bake_on_override_layer,
            minimize_rotation=minimize_rotation,
            sparse_anim_curve_bake=sparse_anim_curve_bake,
            disable_implicit_control=disable_implicit_control,
            control_points=control_points,
            shape=shape,
        )

    @staticmethod
    def objects_to_curves(
        objects: Union["pm.PyNode", str, List[Union["pm.PyNode", str]]],
        recursive: bool = False,
        as_strings: bool = False,
    ) -> Union[List["pm.PyNode"], List[str]]:
        """Converts objects into a list of animation curves.
        Optionally recurses through the objects to find animation curves on children.
        Ensures no duplicates are returned.

        Parameters:
            objects: Single object, string, or list of objects (can be keyed objects or curves).
            recursive: Whether to recursively search through children of objects for curves.
            as_strings: If True, returns a list of strings instead of PyNodes.

        Returns:
            A list of unique animation curves.
        """
        import maya.cmds as cmds

        # Use cmds.ls to handle various forms of input (single object, string, list)
        # Ensure input is a list of strings for cmds
        if isinstance(objects, (str, pm.PyNode)):
            objects = [str(objects)]
        elif isinstance(objects, list):
            objects = [str(o) for o in objects]
        elif objects is None:
            objects = []
        else:
            objects = [str(objects)]

        objects = cmds.ls(objects, flatten=True)
        if not objects:
            return []

        anim_curves = set()

        # Batch: separate objects that are already anim curves
        existing_curves = set(cmds.ls(objects, type="animCurve") or [])
        anim_curves.update(existing_curves)

        # Non-curve objects need connection queries
        non_curves = [o for o in objects if o not in existing_curves]
        if non_curves:
            # Batch: single listConnections for all non-curve objects
            connected = (
                cmds.listConnections(
                    non_curves, type="animCurve", source=True, destination=False
                )
                or []
            )
            anim_curves.update(connected)

            if recursive:
                # Batch: get all descendants at once
                descendants = (
                    cmds.listRelatives(
                        non_curves,
                        allDescendents=True,
                        type="transform",
                        fullPath=True,
                    )
                    or []
                )
                if descendants:
                    # Batch: single listConnections for all descendants
                    desc_curves = (
                        cmds.listConnections(
                            descendants,
                            type="animCurve",
                            source=True,
                            destination=False,
                        )
                        or []
                    )
                    anim_curves.update(desc_curves)

        # Return the results as a list, preserving the unique set of animCurves
        result = list(anim_curves)
        if as_strings:
            return result
        return [pm.PyNode(c) for c in result]

    @classmethod
    def get_anim_curves(
        cls,
        objects: Optional[List["pm.PyNode"]] = None,
        selected_keys_only: bool = False,
        recursive: bool = False,
    ) -> List["pm.PyNode"]:
        """Get animation curves from objects, selected keys, or all scene curves.

        This is a higher-level convenience method that handles common patterns for getting
        animation curves. It properly handles visibility and all other attribute types by
        working directly with animation curve nodes rather than querying at the object level.

        This method should be used when you need to:
        - Get all curves in a scene
        - Get curves from selected graph editor keys
        - Get curves from specific objects (with optional recursion)

        Parameters:
            objects: Objects to get curves from. If None, uses all scene curves or selected keys.
            selected_keys_only: If True, gets curves from selected keys in graph editor.
                               Only applies when objects is None.
            recursive: Whether to recursively search through children of objects for curves.

        Returns:
            A list of unique animation curves.

        Example:
            # Get all animation curves in the scene
            all_curves = AnimUtils.get_anim_curves()

            # Get curves from selected keys
            selected_curves = AnimUtils.get_anim_curves(selected_keys_only=True)

            # Get curves from specific objects
            curves = AnimUtils.get_anim_curves(objects=pm.selected())

            # Get curves from objects and their children
            curves = AnimUtils.get_anim_curves(objects=pm.selected(), recursive=True)
        """
        if objects is None:
            if selected_keys_only:
                # Get animation curves from selected keys in graph editor
                anim_curves = pm.keyframe(query=True, sl=True, name=True)
                return list(set(anim_curves)) if anim_curves else []
            else:
                # Get all animation curves in the scene
                return pm.ls(type="animCurve")
        else:
            # Use existing objects_to_curves method for objects
            # This uses pm.listConnections which properly gets ALL curve types including visibility
            return cls.objects_to_curves(objects, recursive=recursive)

    @classmethod
    def get_static_curves(
        cls,
        objects: List["pm.PyNode"],
        value_tolerance: float = 1e-5,
        recursive: bool = False,
        as_strings: bool = False,
    ) -> Union[List["pm.PyNode"], List[str]]:
        """Detects static curves (curves with constant values) that are safe
        to delete.

        A static curve is one where all keyframe values are identical
        (within *value_tolerance*).  However, if the constant value
        differs from the driven attribute's default value, removing the
        curve would change the object's resting state (e.g. a
        constraint-baked constant position would revert to zero).  Such
        curves are **excluded** from the result.

        Parameters:
            objects: List of PyNodes (curves or objects).
            value_tolerance: The value tolerance to consider for static curves (difference between keyframe values).
            recursive: Whether to recursively search through children of objects for curves.
            as_strings: If True, returns a list of strings instead of PyNodes.

        Returns:
            A list of static curves that are safe to delete.
        """
        from math import isclose
        import maya.cmds as cmds
        import maya.api.OpenMaya as om2
        import maya.api.OpenMayaAnim as oma2

        curves = cls.objects_to_curves(objects, recursive=recursive, as_strings=True)
        static_curves = []

        # Use OpenMaya for fast first/last/mid value checks to skip
        # non-static curves before the expensive full-value query.
        sel = om2.MSelectionList()
        for curve in curves:
            sel.clear()
            try:
                sel.add(curve)
            except RuntimeError:
                continue
            fn = oma2.MFnAnimCurve(sel.getDependNode(0))
            n = fn.numKeys
            if n <= 1:
                continue

            # Quick check: first, last, mid values.  fn.value() returns
            # internal units (radians for rotations) but comparisons are
            # within the same curve / same unit, so the tolerance is
            # self-consistent (stricter for radians than degrees).
            first_val = fn.value(0)
            if abs(fn.value(n - 1) - first_val) > value_tolerance:
                continue
            if abs(fn.value(n // 2) - first_val) > value_tolerance:
                continue

            # Full check via om2 (same-unit, fast C++ loop).
            is_static = True
            for i in range(1, n):
                if abs(fn.value(i) - first_val) > value_tolerance:
                    is_static = False
                    break
            if not is_static:
                continue

            # Check whether the constant value matches the driven
            # attribute's default.  Use cmds for both sides so the
            # units agree (e.g. degrees for rotations).
            driven = cmds.listConnections(
                curve, source=False, destination=True, plugs=True
            )
            if not driven:
                continue

            try:
                node, attr = driven[0].split(".", 1)
                defaults = cmds.attributeQuery(attr, node=node, listDefault=True)
                if defaults is not None:
                    default_val = defaults[0]
                    first_ui = cmds.keyframe(
                        curve, index=(0, 0), q=True, valueChange=True
                    )
                    if not first_ui or not isclose(
                        first_ui[0], default_val, abs_tol=value_tolerance
                    ):
                        continue
            except (ValueError, RuntimeError):
                continue

            static_curves.append(curve)

        if as_strings:
            return static_curves
        return [pm.PyNode(c) for c in static_curves]

    @classmethod
    @CoreUtils.undoable
    def get_redundant_flat_keys(
        cls,
        objects: List["pm.PyNode"],
        value_tolerance: float = 1e-5,
        remove: bool = False,
        recursive: bool = False,
        as_strings: bool = False,
    ) -> List[Tuple[Any, List[float]]]:
        """Detects redundant flat keys in curves and optionally deletes them.

        A "flat segment" is a run of 3+ consecutive keys whose values all
        fall within ``value_tolerance`` of the first key in the run.  The
        interior keys are redundant because the boundary pair alone
        reproduces the constant value.

        Parameters:
            objects: List of PyNodes (curves or objects).
            value_tolerance: The value tolerance to consider for redundant flat keys.
            remove: If True, the redundant keys are deleted.
            recursive: Whether to recursively search through children of objects for curves.
            as_strings: If True, returns curve names as strings instead of PyNodes.

        Returns:
            A list of ``(curve, [redundant_times])`` tuples.
        """
        import maya.cmds as cmds

        curves = cls.objects_to_curves(objects, recursive=recursive, as_strings=True)
        redundant = []

        for curve in curves:
            if not cmds.objExists(curve):
                continue
            times = cmds.keyframe(curve, query=True, timeChange=True) or []
            if len(times) < 3:
                continue

            values = cmds.keyframe(curve, query=True, valueChange=True) or []
            if len(values) != len(times):
                continue

            remove_indices, seg_starts, seg_lasts = ptk.find_flat_interior_indices(
                values, value_tolerance
            )
            if len(remove_indices) == 0:
                continue

            if remove:
                # --- Rebuild approach: read surviving keys' data via om2,
                # delete the old curve node, create a new one connected
                # to the same plug, and batch-add surviving keys with
                # addKeysWithTangents.  This is O(surviving) instead of
                # O(removed) and eliminates 165K+ individual fn.remove()
                # calls.  All auto tangents are frozen to kFixed during
                # rebuild (preserving exact XY angles); boundary tangents
                # facing into flat segments are post-set to kFlat so Maya
                # computes proper handle lengths. ---
                import maya.api.OpenMaya as om2
                import maya.api.OpenMayaAnim as oma2

                _auto_set_int = {
                    oma2.MFnAnimCurve.kTangentAuto,
                    oma2.MFnAnimCurve.kTangentSmooth,
                    oma2.MFnAnimCurve.kTangentClamped,
                }
                kFlat = oma2.MFnAnimCurve.kTangentFlat
                kFixed = oma2.MFnAnimCurve.kTangentFixed

                n_keys = len(times)
                bnd_starts = set(int(s) for s in seg_starts)
                bnd_ends = set(int(e) for e in seg_lasts)
                remove_set = set(remove_indices.tolist())
                surviving = sorted(set(range(n_keys)) - remove_set)

                sel = om2.MSelectionList()
                sel.add(curve)
                dep = sel.getDependNode(0)
                fn = oma2.MFnAnimCurve(dep)

                # Read surviving keys' complete data
                s_times = []
                s_values = []
                s_in_tt = []
                s_out_tt = []
                s_in_x = []
                s_in_y = []
                s_out_x = []
                s_out_y = []
                flat_fixups = []  # (surv_idx, is_in_tangent)

                for si, idx in enumerate(surviving):
                    s_times.append(fn.input(idx))
                    s_values.append(fn.value(idx))

                    in_tt = fn.inTangentType(idx)
                    out_tt = fn.outTangentType(idx)
                    in_xy = fn.getTangentXY(idx, True)
                    out_xy = fn.getTangentXY(idx, False)

                    is_start = idx in bnd_starts
                    is_end = idx in bnd_ends

                    # Freeze auto tangents → kFixed (preserve angle).
                    # Boundary tangents into flat segments → kFlat (post-set).
                    if is_end and in_tt in _auto_set_int:
                        in_tt = kFixed
                        in_xy = (in_xy[0], 0.0)
                        flat_fixups.append((si, True))
                    elif in_tt in _auto_set_int:
                        in_tt = kFixed

                    if is_start and out_tt in _auto_set_int:
                        out_tt = kFixed
                        out_xy = (out_xy[0], 0.0)
                        flat_fixups.append((si, False))
                    elif out_tt in _auto_set_int:
                        out_tt = kFixed

                    s_in_tt.append(in_tt)
                    s_out_tt.append(out_tt)
                    s_in_x.append(in_xy[0])
                    s_in_y.append(in_xy[1])
                    s_out_x.append(out_xy[0])
                    s_out_y.append(out_xy[1])

                curve_type = fn.animCurveType
                pre_inf = fn.preInfinityType
                post_inf = fn.postInfinityType
                is_weighted = fn.isWeighted

                # Get output plug before deleting
                fn_dep = om2.MFnDependencyNode(dep)
                out_plug = fn_dep.findPlug("output", True)
                dest_plugs = out_plug.destinations()
                if not dest_plugs:
                    continue
                dest_plug = dest_plugs[0]

                # Delete old curve, create new one on same plug
                mod = om2.MDGModifier()
                mod.deleteNode(dep)
                mod.doIt()

                fn_new = oma2.MFnAnimCurve()
                fn_new.create(dest_plug, curve_type)
                if is_weighted:
                    fn_new.setIsWeighted(True)

                fn_new.addKeysWithTangents(
                    s_times,
                    s_values,
                    tangentInTypeArray=s_in_tt,
                    tangentOutTypeArray=s_out_tt,
                    tangentInXArray=s_in_x,
                    tangentInYArray=s_in_y,
                    tangentOutXArray=s_out_x,
                    tangentOutYArray=s_out_y,
                    convertUnits=False,
                )
                fn_new.setPreInfinityType(pre_inf)
                fn_new.setPostInfinityType(post_inf)

                # Post-set tangent types that addKeysWithTangents ignores
                # when XY data is provided (step, stepNext, flat, linear, etc.)
                for si in range(len(s_in_tt)):
                    if s_in_tt[si] != kFixed:
                        fn_new.setInTangentType(si, s_in_tt[si])
                    if s_out_tt[si] != kFixed:
                        fn_new.setOutTangentType(si, s_out_tt[si])

                # Post-set boundary tangents to kFlat for proper handle length
                for si, is_in in flat_fixups:
                    if is_in:
                        fn_new.setInTangentType(si, kFlat)
                    else:
                        fn_new.setOutTangentType(si, kFlat)

            curve_ref = curve if as_strings else pm.PyNode(curve)
            redundant.append((curve_ref, [times[int(i)] for i in remove_indices]))

        return redundant

    @classmethod
    def simplify_curve(
        cls,
        objects: List["pm.PyNode"],
        value_tolerance: float = 0.001,
        time_tolerance: float = 0.001,
        recursive: bool = False,
        as_strings: bool = False,
    ) -> Union[List["pm.PyNode"], List[str]]:
        """Simplify curves by removing keys that don't contribute to shape.

        Uses Maya's ``filterCurve`` with the ``keyReducer`` filter, which
        evaluates each key's contribution to the overall curve shape and
        removes keys whose absence would change the curve by less than
        *value_tolerance*.  This is far more effective than ``cmds.simplify``
        for post-bake cleanup because it handles smooth transitions (not
        just per-key value differences).

        Parameters:
            objects: List of PyNodes (curves or objects).
            value_tolerance: Maximum allowed value deviation when removing
                a key.  Maps to ``filterCurve -precision``.
            time_tolerance: Unused (kept for API compatibility).
            recursive: Whether to recursively search children for curves.
            as_strings: If True, returns curve names as strings.

        Returns:
            A list of curves that were simplified.
        """
        import maya.cmds as cmds

        curves = cls.objects_to_curves(objects, recursive=recursive, as_strings=True)
        simplified_curves = []

        for curve in curves:
            try:
                before = cmds.keyframe(curve, q=True, keyframeCount=True) or 0
                cmds.filterCurve(
                    curve,
                    filter="keyReducer",
                    precisionMode=0,  # value precision
                    precision=value_tolerance,
                )
                after = cmds.keyframe(curve, q=True, keyframeCount=True) or 0
                if after < before:
                    simplified_curves.append(curve)
            except Exception:
                pass

        if as_strings:
            return simplified_curves
        return [pm.PyNode(c) for c in simplified_curves]

    @classmethod
    @CoreUtils.undoable
    def repair_corrupted_curves(
        cls,
        objects: Optional[
            Union[str, "pm.PyNode", List[Union[str, "pm.PyNode"]]]
        ] = None,
        recursive: bool = True,
        delete_corrupted: bool = False,
        fix_infinite: bool = True,
        fix_invalid_times: bool = True,
        time_range_threshold: float = 1e6,
        value_threshold: float = 1e6,
        quiet: bool = False,
    ) -> Dict[str, Any]:
        """Legacy wrapper maintained for backwards compatibility.

        The implementation now lives in :class:`AnimCurveRepair`.
        """

        from mayatk.core_utils.diagnostic import AnimCurveDiagnostics as AnimCurveRepair

        return AnimCurveRepair.repair_corrupted_curves(
            objects=objects,
            recursive=recursive,
            delete_corrupted=delete_corrupted,
            fix_infinite=fix_infinite,
            fix_invalid_times=fix_invalid_times,
            time_range_threshold=time_range_threshold,
            value_threshold=value_threshold,
            quiet=quiet,
        )

    @classmethod
    @CoreUtils.undoable
    def optimize_keys(
        cls,
        objects: Union[str, "pm.PyNode", List[Union[str, "pm.PyNode"]]],
        value_tolerance: float = 0.001,
        time_tolerance: float = 0.001,
        remove_flat_keys: bool = True,
        remove_static_curves: bool = True,
        simplify_keys: bool = False,
        recursive: bool = True,
        quiet: bool = False,
        stats: Optional[dict] = None,
    ) -> List[str]:
        """Optimize animation keys for the given objects by removing static curves,
        redundant flat keys, and simplifying curves.

        Parameters:
            objects (str, PyNode, or list): The objects to optimize.
            value_tolerance (float): Tolerance for value comparison.
            time_tolerance (float): Tolerance for time comparison.
            remove_flat_keys (bool): Whether to remove redundant flat keys.
            remove_static_curves (bool): Whether to remove static curves.
            simplify_keys (bool): Whether to simplify curves.
            recursive (bool): Whether to search through children of objects.
            quiet (bool): If True, suppress output messages.
            stats (dict, optional): If provided, populated with
                ``keys_before``, ``keys_after``, ``curves_before``,
                ``curves_after``, ``static_deleted``, ``flat_removed``,
                ``simplified``, and ``auto_frozen`` counts.

        Returns:
            list: A list of modified curve names (strings).
        """
        import maya.cmds as cmds

        # Guard: PyMEL's lazy initialization (triggered on first use)
        # runs initialStartup.mel which can reset the scene time-unit
        # to Maya's default (film/24fps), rescaling all keyframe times.
        # Capture the time-unit now (before any pymel call) and restore
        # it at the end if it changed.
        _saved_time_unit = cmds.currentUnit(query=True, time=True)

        # Convert the input objects into curves once (avoid 3 redundant calls)
        if isinstance(objects, (str, pm.PyNode)):
            objects = [str(objects)]
        elif isinstance(objects, list):
            objects = [str(o) for o in objects]
        else:
            objects = []

        targets = cmds.ls(objects, flatten=True)
        anim_curves = cls.objects_to_curves(
            targets, recursive=recursive, as_strings=True
        )

        curves_before_count = len(anim_curves)
        keys_before_count = sum(
            cmds.keyframe(c, q=True, keyframeCount=True) or 0
            for c in anim_curves
            if cmds.objExists(c)
        )

        if not quiet:
            print(f"[optimize] Processing {len(anim_curves)} curves...")

        # Suspend viewport refresh for the duration of the optimization.
        # In interactive Maya this prevents per-operation viewport updates
        # that dominate wall-clock time.
        cmds.refresh(suspend=True)
        try:
            return cls._optimize_keys_inner(
                anim_curves,
                value_tolerance=value_tolerance,
                time_tolerance=time_tolerance,
                remove_flat_keys=remove_flat_keys,
                remove_static_curves=remove_static_curves,
                simplify_keys=simplify_keys,
                quiet=quiet,
                keys_before_count=keys_before_count,
                curves_before_count=curves_before_count,
                stats=stats,
                _saved_time_unit=_saved_time_unit,
            )
        finally:
            cmds.refresh(suspend=False)

    @classmethod
    def _optimize_keys_inner(
        cls,
        anim_curves,
        *,
        value_tolerance,
        time_tolerance,
        remove_flat_keys,
        remove_static_curves,
        simplify_keys,
        quiet,
        keys_before_count,
        curves_before_count,
        stats,
        _saved_time_unit,
    ):
        import maya.cmds as cmds

        # fn.remove() doesn't participate in Maya's undo queue, making
        # the operation non-undoable regardless.  Disable undo for the
        # remaining cmds calls to eliminate per-call overhead in
        # interactive Maya (each recorded entry updates the undo list,
        # attribute editor, channel box, etc.).
        _undo_was_on = cmds.undoInfo(q=True, state=True)
        _autokey_was_on = cmds.autoKeyframe(q=True, state=True)
        try:
            if _undo_was_on:
                cmds.undoInfo(stateWithoutFlush=False)
            if _autokey_was_on:
                cmds.autoKeyframe(state=False)
            return cls.__optimize_keys_body(
                anim_curves,
                value_tolerance=value_tolerance,
                time_tolerance=time_tolerance,
                remove_flat_keys=remove_flat_keys,
                remove_static_curves=remove_static_curves,
                simplify_keys=simplify_keys,
                quiet=quiet,
                keys_before_count=keys_before_count,
                curves_before_count=curves_before_count,
                stats=stats,
                _saved_time_unit=_saved_time_unit,
            )
        finally:
            if _autokey_was_on:
                cmds.autoKeyframe(state=True)
            if _undo_was_on:
                cmds.undoInfo(stateWithoutFlush=True)

    @classmethod
    def __optimize_keys_body(
        cls,
        anim_curves,
        *,
        value_tolerance,
        time_tolerance,
        remove_flat_keys,
        remove_static_curves,
        simplify_keys,
        quiet,
        keys_before_count,
        curves_before_count,
        stats,
        _saved_time_unit,
    ):
        import maya.cmds as cmds

        static_curves_deleted = 0
        flat_keys_deleted = 0
        simplified_curves_count = 0

        # Phase 1: Remove static curves (if remove_static_curves is True)
        if remove_static_curves:
            static_curves = cls.get_static_curves(
                anim_curves, value_tolerance=value_tolerance, as_strings=True
            )
            static_curves_deleted += len(static_curves)
            if static_curves:
                cmds.delete(static_curves)
                # Remove deleted curves from anim_curves list
                static_set = set(static_curves)
                anim_curves = [c for c in anim_curves if c not in static_set]

        # Phase 2: Remove redundant flat keys (if remove_flat_keys is True)
        rebuilt_curves = set()
        if remove_flat_keys:
            redundant_keys_to_delete = cls.get_redundant_flat_keys(
                anim_curves,
                value_tolerance=value_tolerance,
                remove=True,
                as_strings=True,
            )
            flat_keys_deleted += sum(len(keys) for _, keys in redundant_keys_to_delete)
            # The rebuild approach already freezes all auto tangents on
            # rebuilt curves — track them so Phase 3 can skip them.
            rebuilt_curves = set(c for c, keys in redundant_keys_to_delete if keys)

        # Phase 3: Freeze auto tangent types to fixed.
        # Maya's auto tangent recomputes based on neighbors, which
        # produces correct results in Maya.  However FBX maps 'auto'
        # to eTangentAuto — a different algorithm that corrupts
        # sparse curves (after flat-key removal).  Freezing to 'fixed'
        # captures the exact current angle as eTangentUser.
        # This also gives the key reducer explicit angles to work with,
        # allowing it to remove more keys while preserving shape.
        auto_tangents_frozen = 0
        for curve in anim_curves:
            if curve in rebuilt_curves:
                continue  # Already frozen during rebuild
            if not cmds.objExists(curve):
                continue
            times = cmds.keyframe(curve, q=True, timeChange=True) or []
            if not times:
                continue
            out_types = cmds.keyTangent(curve, q=True, outTangentType=True) or []
            in_types = cmds.keyTangent(curve, q=True, inTangentType=True) or []

            for types_list, kw in [
                (out_types, {"outTangentType": "fixed"}),
                (in_types, {"inTangentType": "fixed"}),
            ]:
                # Group consecutive auto keys into time ranges for
                # batch keyTangent calls instead of per-key overhead.
                seg_start = None
                for i, tt in enumerate(types_list):
                    if tt == "auto":
                        if seg_start is None:
                            seg_start = i
                        auto_tangents_frozen += 1
                    elif seg_start is not None:
                        cmds.keyTangent(
                            curve,
                            time=(times[seg_start], times[i - 1]),
                            lock=False,
                            **kw,
                        )
                        seg_start = None
                if seg_start is not None:
                    cmds.keyTangent(
                        curve,
                        time=(times[seg_start], times[len(types_list) - 1]),
                        lock=False,
                        **kw,
                    )

        # Phase 4: Simplify curves (if simplify_keys is True).
        # Uses filterCurve(keyReducer) to remove keys whose absence
        # changes the curve by less than value_tolerance.  Runs after
        # auto-freeze so the reducer has explicit tangent angles.
        if simplify_keys:
            simplified = cls.simplify_curve(
                anim_curves,
                value_tolerance=value_tolerance,
                time_tolerance=time_tolerance,
                as_strings=True,
            )
            simplified_curves_count += len(simplified)

        if not quiet:
            print(f"[optimize] {static_curves_deleted} static curves deleted")
            print(f"[optimize] {flat_keys_deleted} flat keys removed")
            print(f"[optimize] {simplified_curves_count} curves simplified")
            print(f"[optimize] {auto_tangents_frozen} auto tangents frozen")

        # Restore time-unit if pymel init changed it during this call.
        if cmds.currentUnit(query=True, time=True) != _saved_time_unit:
            cmds.currentUnit(time=_saved_time_unit)

        surviving = [c for c in anim_curves if cmds.objExists(c)]

        if stats is not None:
            keys_after_count = sum(
                cmds.keyframe(c, q=True, keyframeCount=True) or 0
                for c in surviving
                if cmds.objExists(c)
            )
            stats.update(
                {
                    "keys_before": keys_before_count,
                    "keys_after": keys_after_count,
                    "curves_before": curves_before_count,
                    "curves_after": len(surviving),
                    "static_deleted": static_curves_deleted,
                    "flat_removed": flat_keys_deleted,
                    "simplified": simplified_curves_count,
                    "auto_frozen": auto_tangents_frozen,
                }
            )

        # Return strings to avoid expensive PyNode construction per curve
        return surviving

    @staticmethod
    def get_keyframe_times(
        sources: Union["pm.PyNode", List["pm.PyNode"]],
        mode: str = "all",
        from_curves: Optional[bool] = None,
        as_range: bool = False,
        time_range: Optional[Tuple[float, float]] = None,
    ) -> Union[List[float], Tuple[float, float], None]:
        """Get keyframe times from objects or curves with flexible filtering options.

        This is a low-level utility for extracting keyframe time values. For getting
        animation curves themselves, use objects_to_curves() or get_anim_curves().

        Parameters:
            sources: Objects or animation curves to get keyframe times from.
            mode: How to select keyframes. Options:
                - "all": Get all keyframes (default)
                - "selected": Get only selected keyframes in graph editor
                - "selected_or_all": Try selected first, fallback to all if none selected
            from_curves: If True, treats sources as curves. If False, treats as objects.
                        If None (default), auto-detects based on node type.
            as_range: If True, returns (min_time, max_time) tuple. If False, returns sorted list.
            time_range: Optional (start, end) tuple to filter keyframes within a range.

        Returns:
            - List[float]: Sorted unique keyframe times (if as_range=False)
            - Tuple[float, float]: (start_time, end_time) range (if as_range=True)
            - None: If no keyframes found
        """
        import maya.cmds as cmds

        # Ensure sources is a list of strings
        if isinstance(sources, (str, pm.PyNode)):
            sources = [str(sources)]
        elif isinstance(sources, list):
            sources = [str(s) for s in sources]
        elif sources is None:
            sources = []
        else:
            sources = [str(sources)]

        sources = cmds.ls(sources, flatten=True)
        if not sources:
            return None

        # Auto-detect if working with curves
        if from_curves is None:
            from_curves = any(cmds.nodeType(s).startswith("animCurve") for s in sources)

        all_times = set()

        if from_curves:
            # Working with animation curves directly
            for curve in sources:
                times = None
                if mode in ("selected", "selected_or_all"):
                    times = (
                        cmds.keyframe(
                            curve,
                            query=True,
                            selected=True,
                            timeChange=True,
                            time=time_range,
                        )
                        if time_range
                        else cmds.keyframe(
                            curve, query=True, selected=True, timeChange=True
                        )
                    )

                # If mode is "all" or "selected_or_all" and no selected times found
                if mode == "all" or (mode == "selected_or_all" and not times):
                    times = (
                        cmds.keyframe(
                            curve, query=True, timeChange=True, time=time_range
                        )
                        if time_range
                        else cmds.keyframe(curve, query=True, timeChange=True)
                    )

                if times:
                    all_times.update(times)
        else:
            # Working with objects - need to check for selected keys first
            selected_times = set()

            if mode in ("selected", "selected_or_all"):
                for obj in sources:
                    # Get selected keyframe times from this object
                    curve_nodes = cmds.keyframe(
                        obj, query=True, name=True, selected=True
                    )
                    if curve_nodes:
                        for curve in curve_nodes:
                            times = (
                                cmds.keyframe(
                                    curve,
                                    query=True,
                                    selected=True,
                                    timeChange=True,
                                    time=time_range,
                                )
                                if time_range
                                else cmds.keyframe(
                                    curve, query=True, selected=True, timeChange=True
                                )
                            )
                            if times:
                                selected_times.update(times)

            # Use selected times if we found any, or get all if mode requires it
            if selected_times:
                all_times = selected_times
            elif mode == "all" or (mode == "selected_or_all" and not selected_times):
                # Batch query all objects at once for performance
                times = (
                    cmds.keyframe(sources, query=True, timeChange=True, time=time_range)
                    if time_range
                    else cmds.keyframe(sources, query=True, timeChange=True)
                )
                if times:
                    all_times.update(times)

        if not all_times:
            return None

        sorted_times = sorted(all_times)

        if as_range:
            return (sorted_times[0], sorted_times[-1])
        else:
            return sorted_times

    @staticmethod
    def get_driver_animation_range(
        node: str,
        driver_type: str = "auto",
    ) -> List[float]:
        """Get keyframe times from a driver node's animation or its targets.

        Traces through different driver types (constraints, driven keys,
        expressions, IK, motion paths) to find the animation range of
        the ultimate source.

        Parameters:
            node: The driver node to query.
            driver_type: The type of driver. Options:
                - "auto": Auto-detect the node type
                - "constraint": Query constraint target animation
                - "driven_key": Query the driver of the SDK
                - "expression": Query expression input animation
                - "ik": Query IK handle/pole vector animation
                - "motion_path": Query uValue animation

        Returns:
            List of keyframe times from the driver's animation.
            Empty list if no animation found.

        Example:
            >>> times = AnimUtils.get_driver_animation_range("pCube1_parentConstraint1")
            >>> print(min(times), max(times))  # 1.0 100.0
        """
        import maya.cmds as cmds
        from mayatk.node_utils._node_utils import NodeUtils

        times: List[float] = []

        # Auto-detect driver type
        if driver_type == "auto":
            if NodeUtils.is_constraint(node):
                driver_type = "constraint"
            elif NodeUtils.is_expression(node):
                driver_type = "expression"
            elif cmds.nodeType(node).startswith("animCurve"):
                if NodeUtils.is_driven_key_curve(node):
                    driver_type = "driven_key"
                else:
                    driver_type = "keyframe"
            elif cmds.nodeType(node) == "ikHandle":
                driver_type = "ik"
            elif NodeUtils.is_ik_effector(node):
                driver_type = "ik"
            elif cmds.nodeType(node) == "motionPath":
                driver_type = "motion_path"
            else:
                driver_type = "unknown"

        if driver_type == "constraint":
            targets = NodeUtils.get_constraint_targets(node)
            for target in targets:
                curves = (
                    cmds.listConnections(
                        target, type="animCurve", source=True, destination=False
                    )
                    or []
                )
                for curve in curves:
                    key_times = cmds.keyframe(curve, query=True, timeChange=True)
                    if key_times:
                        times.extend(key_times)

        elif driver_type == "driven_key":
            input_conn = (
                cmds.listConnections(
                    f"{node}.input", source=True, destination=False, plugs=True
                )
                or []
            )
            for inp in input_conn:
                driver_obj = inp.split(".")[0]
                curves = (
                    cmds.listConnections(
                        driver_obj, type="animCurve", source=True, destination=False
                    )
                    or []
                )
                for curve in curves:
                    key_times = cmds.keyframe(curve, query=True, timeChange=True)
                    if key_times:
                        times.extend(key_times)

        elif driver_type == "expression":
            inputs = cmds.listConnections(node, source=True, destination=False) or []
            for related in inputs:
                curves = (
                    cmds.listConnections(
                        related, type="animCurve", source=True, destination=False
                    )
                    or []
                )
                for curve in curves:
                    key_times = cmds.keyframe(curve, query=True, timeChange=True)
                    if key_times:
                        times.extend(key_times)

        elif driver_type == "ik":
            handles = cmds.listConnections(node, type="ikHandle", source=True) or []
            if cmds.nodeType(node) == "ikHandle":
                handles = [node]
            for handle in handles:
                curves = (
                    cmds.listConnections(
                        handle, type="animCurve", source=True, destination=False
                    )
                    or []
                )
                for curve in curves:
                    key_times = cmds.keyframe(curve, query=True, timeChange=True)
                    if key_times:
                        times.extend(key_times)
                # Check pole vector constraint targets
                pv_constraint = cmds.listConnections(
                    f"{handle}.poleVectorX", source=True, destination=False
                )
                if pv_constraint:
                    for pv in pv_constraint:
                        pv_curves = (
                            cmds.listConnections(
                                pv, type="animCurve", source=True, destination=False
                            )
                            or []
                        )
                        for curve in pv_curves:
                            key_times = cmds.keyframe(
                                curve, query=True, timeChange=True
                            )
                            if key_times:
                                times.extend(key_times)

        elif driver_type == "motion_path":
            u_curves = (
                cmds.listConnections(f"{node}.uValue", type="animCurve", source=True)
                or []
            )
            for curve in u_curves:
                key_times = cmds.keyframe(curve, query=True, timeChange=True)
                if key_times:
                    times.extend(key_times)

        elif driver_type == "keyframe":
            key_times = cmds.keyframe(node, query=True, timeChange=True)
            if key_times:
                times.extend(key_times)

        return times

    @staticmethod
    def get_tangent_info(attr_name: str, time: float) -> Dict[str, Any]:
        """Get tangent information (types, angles, and weights) for a given attribute at a specific time.

        Parameters:
            attr_name (str): The name of the attribute.
            time (float): The time at which to query the tangent information.

        Returns:
            Dict[str, Any]: A dictionary containing tangent information.
        """
        return {
            "inTangentType": pm.keyTangent(
                attr_name, query=True, time=(time,), inTangentType=True
            )[0],
            "outTangentType": pm.keyTangent(
                attr_name, query=True, time=(time,), outTangentType=True
            )[0],
            "inAngle": pm.keyTangent(attr_name, query=True, time=(time,), inAngle=True)[
                0
            ],
            "outAngle": pm.keyTangent(
                attr_name, query=True, time=(time,), outAngle=True
            )[0],
            "inWeight": pm.keyTangent(
                attr_name, query=True, time=(time,), inWeight=True
            )[0],
            "outWeight": pm.keyTangent(
                attr_name, query=True, time=(time,), outWeight=True
            )[0],
        }

    @staticmethod
    def set_tangent_info(
        attr_name: str, time: float, tangent_info: Dict[str, Any]
    ) -> None:
        """Restore tangent information on a keyframe.

        Applies tangent types in a separate call after angles/weights so that
        type-specific tangents (e.g. stepped) are not overridden by the
        angle/weight values which would implicitly force the type to 'fixed'.

        Parameters:
            attr_name (str): The attribute name.
            time (float): The time of the keyframe.
            tangent_info (Dict[str, Any]): Tangent dict from ``get_tangent_info``.
        """
        types = {}
        weights_angles = {}
        for k, v in tangent_info.items():
            if "TangentType" in k:
                types[k] = v
            else:
                weights_angles[k] = v

        # Angles/weights first (these may implicitly set type to 'fixed')
        if weights_angles:
            pm.keyTangent(attr_name, time=(time,), edit=True, **weights_angles)
        # Types last so they take precedence
        if types:
            pm.keyTangent(attr_name, time=(time,), edit=True, **types)

    @staticmethod
    def _resolve_keys(
        objects=None,
        mode: str = "auto",
        resolution_order: Optional[Tuple[str, ...]] = None,
    ) -> Dict[str, Any]:
        """Resolve which animation keys to operate on.

        Provides a unified mechanism for determining target keys.  When
        *mode* is ``"auto"``, each strategy in *resolution_order* is
        tried in sequence; the first strategy that yields results wins.

        .. note::

           This helper lives on ``AnimUtils`` (not on the ``_AnimUtilsMixin``)
           because it calls ``AnimUtils.objects_to_curves`` — placing it on
           the mixin would create a circular reference.

        Strategies
        ----------
        ``"selected"``
            Keys currently selected in the Graph Editor **that belong to
            the resolved** *objects*.  If Channel Box attributes are also
            highlighted, only curves matching those attributes are
            included (with automatic fallback to all selected curves
            when filtering eliminates everything).

        ``"channel_box"``
            All keys on curves whose driven attribute is highlighted in
            the Channel Box.

        ``"current_frame"``
            Keys at the current time on the resolved objects.

        ``"all"``
            Every key on every curve of the resolved objects.

        Parameters:
            objects: Transforms / anim curves to operate on.  Falls back
                to ``pm.selected()`` when *None*.  Accepts pre-resolved
                ``PyNode`` lists to avoid redundant ``pm.ls`` calls by
                callers that already validated their objects.
            mode: Resolution mode.

                - ``"auto"`` — try strategies in *resolution_order*.
                - Any strategy name — use that strategy directly.
            resolution_order: Strategies to try for ``"auto"`` mode.
                Default: ``("selected", "channel_box", "current_frame",
                "all")``.

        Returns:
            dict with:

            ``mode`` (str)
                The concrete strategy that produced results.
            ``curves`` (Dict[str, Optional[List[float]]])
                Mapping of curve names to key times.  ``None`` means
                all keys on that curve.  An empty dict means nothing
                was resolved.
            ``objects`` (list)
                The resolved PyNode objects.
            ``cb_attrs`` (Optional[Set[str]])
                Lowercased Channel Box attribute names when they
                influenced the resolution, else ``None``.
        """
        import maya.cmds as cmds

        DEFAULT_ORDER = ("selected", "channel_box", "current_frame", "all")

        # --- Resolve objects (skip if pre-resolved) ---
        if objects is None:
            objects = pm.selected()
        objects = pm.ls(objects, flatten=True)

        # --- Query context once ---
        sel_curves = cmds.keyframe(query=True, selected=True, name=True) or []
        try:
            channel_box = pm.melGlobals["gChannelBoxName"]
        except KeyError:
            channel_box = "mainChannelBox"
        cb_attrs_raw = pm.channelBox(channel_box, query=True, sma=True) or []
        cb_attrs: Optional[Set[str]] = (
            {a.lower() for a in cb_attrs_raw} if cb_attrs_raw else None
        )

        # Lazy cache for objects_to_curves — computed at most once.
        _obj_curves_cache: List[Optional[List[str]]] = [None]

        def _get_obj_curves() -> List[str]:
            if _obj_curves_cache[0] is None:
                _obj_curves_cache[0] = (
                    AnimUtils.objects_to_curves(objects, as_strings=True)
                    if objects
                    else []
                )
            return _obj_curves_cache[0]

        # Build a set of curve names that belong to *objects* for
        # scoping the "selected" strategy.
        _obj_curve_set_cache: List[Optional[Set[str]]] = [None]

        def _get_obj_curve_set() -> Set[str]:
            if _obj_curve_set_cache[0] is None:
                _obj_curve_set_cache[0] = set(_get_obj_curves())
            return _obj_curve_set_cache[0]

        # --- Strategy implementations ---
        def _try_selected():
            if not sel_curves:
                return None
            # Scope to curves belonging to the resolved objects.
            obj_curve_set = _get_obj_curve_set()
            scoped = (
                [c for c in sel_curves if c in obj_curve_set]
                if obj_curve_set
                else list(sel_curves)
            )
            if not scoped:
                return None

            curves: Dict[str, Optional[List[float]]] = {}
            effective_cb = cb_attrs
            for crv in set(scoped):
                if effective_cb is not None:
                    conns = (
                        cmds.listConnections(crv, destination=True, plugs=True) or []
                    )
                    if not any(p.split(".")[-1].lower() in effective_cb for p in conns):
                        continue
                times = (
                    cmds.keyframe(crv, query=True, selected=True, timeChange=True) or []
                )
                curves[crv] = times if times else None
            # CB filter eliminated everything — fall back to all scoped
            if not curves and effective_cb is not None:
                effective_cb = None
                for crv in set(scoped):
                    times = (
                        cmds.keyframe(crv, query=True, selected=True, timeChange=True)
                        or []
                    )
                    curves[crv] = times if times else None
            return (
                {"mode": "selected", "curves": curves, "cb_attrs": effective_cb}
                if curves
                else None
            )

        def _try_channel_box():
            if not cb_attrs or not objects:
                return None
            all_curves = _get_obj_curves()
            if not all_curves:
                return None
            curves: Dict[str, Optional[List[float]]] = {}
            for crv in all_curves:
                conns = cmds.listConnections(crv, destination=True, plugs=True) or []
                for plug in conns:
                    if plug.split(".")[-1].lower() in cb_attrs:
                        curves[crv] = None
                        break
            return (
                {"mode": "channel_box", "curves": curves, "cb_attrs": cb_attrs}
                if curves
                else None
            )

        def _try_current_frame():
            if not objects:
                return None
            all_curves = _get_obj_curves()
            if not all_curves:
                return None
            current = cmds.currentTime(query=True)
            curves: Dict[str, Optional[List[float]]] = {}
            for crv in all_curves:
                count = cmds.keyframe(
                    crv, query=True, time=(current, current), keyframeCount=True
                )
                if count:
                    curves[crv] = [current]
            return (
                {"mode": "current_frame", "curves": curves, "cb_attrs": None}
                if curves
                else None
            )

        def _try_all():
            if not objects:
                return None
            all_curves = _get_obj_curves()
            if not all_curves:
                return None
            curves = {crv: None for crv in all_curves}
            return {"mode": "all", "curves": curves, "cb_attrs": None}

        strategies = {
            "selected": _try_selected,
            "channel_box": _try_channel_box,
            "current_frame": _try_current_frame,
            "all": _try_all,
        }

        empty: Dict[str, Any] = {
            "mode": mode,
            "curves": {},
            "objects": objects,
            "cb_attrs": None,
        }

        if mode == "auto":
            order = resolution_order or DEFAULT_ORDER
            for name in order:
                func = strategies.get(name)
                if func:
                    result = func()
                    if result and result["curves"]:
                        result["objects"] = objects
                        return result
            return empty
        else:
            func = strategies.get(mode)
            if func:
                result = func()
                if result:
                    result["objects"] = objects
                    return result
            return empty

    @staticmethod
    @CoreUtils.undoable
    def step_keys(
        objects=None,
        keys=None,
        tangent: str = "out",
        resolution_order: Optional[Tuple[str, ...]] = None,
    ) -> dict:
        """Set stepped tangents on animation keys.

        Parameters:
            objects: Transforms / anim curves to operate on.  Falls back
                     to ``pm.selected()`` when *None*.
            keys: Which keys to step.  Accepted values:

                  - ``None`` (default) — step **all** keys on *objects*.
                  - ``"auto"`` — smart cascade via :meth:`_resolve_keys`:
                    uses selected keys if any (narrowed by Channel Box
                    highlights), falls back to Channel Box attributes,
                    then current-frame keys, then all keys.
                  - A ``float`` or ``int`` — treated as a time; only keys
                    at that frame are stepped.
                  - A ``list[str]`` — treated as animation-curve node
                    names (e.g. from ``cmds.keyframe(selected=True,
                    name=True)``); those curves are stepped directly
                    and *objects* is ignored.
                  - A ``dict[str, list[float] | None]`` — mapping of
                    curve names to specific times.  A *None* value means
                    step every key on that curve.
            tangent: Which tangent(s) to set stepped.
                  - ``"out"`` (default) — out-tangent ``step``.
                  - ``"in"`` — in-tangent ``stepnext``.
                  - ``"both"`` — both out ``step`` and in ``stepnext``.
            resolution_order: Strategies to try for ``"auto"`` mode.
                Default: ``("selected", "channel_box", "current_frame",
                "all")``.  See :meth:`_resolve_keys`.

        Returns:
            dict: ``{"curves": int, "objects": int}`` counts.
        """
        import maya.cmds as cmds

        # --- Auto resolution: resolve keys via _resolve_keys helper ---
        if keys == "auto":
            resolved = AnimUtils._resolve_keys(
                objects, mode="auto", resolution_order=resolution_order
            )
            # Empty dict → None so the "step all" path handles no-result.
            keys = resolved["curves"] if resolved["curves"] else None
            objects = resolved["objects"]

        result = {"curves": 0, "objects": 0}

        # Build tangent kwargs from the tangent parameter.
        tan_kw: dict = {}
        if tangent in ("out", "both"):
            tan_kw["outTangentType"] = "step"
        if tangent in ("in", "both"):
            tan_kw["inTangentType"] = "stepnext"
        if not tan_kw:
            tan_kw["outTangentType"] = "step"  # fallback

        # When setting only one side we must preserve the opposite side's
        # type, angle, and weight.  Maya's tangent lock couples the
        # handles geometrically, so a naive ``lock=False`` causes the
        # untouched side's handle to jump.  Instead we snapshot → apply
        # both sides → restore the untouched side.
        _one_side = tangent in ("in", "out")

        def _apply(curve: str, time_arg=None):
            """Apply tangent kwargs to *curve*, optionally at *time_arg*."""
            if _one_side and time_arg is not None:
                # Per-key: snapshot the opposite side, apply, restore.
                _apply_one_side(curve, time_arg, tangent)
                return
            if _one_side and time_arg is None:
                # Whole-curve: iterate every key individually.
                all_times = cmds.keyframe(curve, q=True, timeChange=True) or []
                for t in all_times:
                    _apply_one_side(curve, (t, t), tangent)
                return
            # "both" — set out=step + in=stepnext on current key.
            kw = dict(edit=True, **tan_kw)
            if time_arg is not None:
                kw["time"] = time_arg
            try:
                cmds.keyTangent(curve, **kw)
            except RuntimeError:
                pass
            # For "both" with a specific time, also set out=step on
            # the predecessor key so the incoming segment is stepped.
            # inTangentType="stepnext" alone does NOT produce step
            # interpolation — the predecessor's out-tangent must be
            # "step" for the segment to hold flat.
            if tangent == "both" and time_arg is not None:
                all_times = cmds.keyframe(curve, q=True, timeChange=True) or []
                t = time_arg[0]
                prev_times = [pt for pt in all_times if pt < t]
                if prev_times:
                    prev_t = max(prev_times)
                    ott = cmds.keyTangent(
                        curve,
                        q=True,
                        time=(prev_t, prev_t),
                        outTangentType=True,
                    )
                    if not (ott and ott[0] == "step"):
                        _apply_one_side(curve, (prev_t, prev_t), "out")

        def _apply_one_side(curve: str, time_arg, side: str):
            """Set one tangent side while preserving the other side completely.

            Parameters:
                side: ``"in"`` to set inTangentType=stepnext (preserving out),
                      ``"out"`` to set outTangentType=step (preserving in).

            Angle and weight are only restored when the original tangent type
            is ``"fixed"`` — the only type where those values are user-defined.
            For auto-computed types (auto, spline, linear, flat, plateau,
            clamped) restoring the type alone lets Maya recompute the handle
            geometry.  Restoring angle on an auto tangent would silently
            convert it to ``"fixed"``, breaking auto-computation.
            """
            try:
                if side == "in":
                    # Preserve out-tangent
                    ott = cmds.keyTangent(
                        curve, q=True, time=time_arg, outTangentType=True
                    )
                    restore_geometry = ott and ott[0] == "fixed"
                    if restore_geometry:
                        oa = cmds.keyTangent(
                            curve, q=True, time=time_arg, outAngle=True
                        )
                        ow = cmds.keyTangent(
                            curve, q=True, time=time_arg, outWeight=True
                        )
                    cmds.keyTangent(
                        curve,
                        edit=True,
                        time=time_arg,
                        lock=False,
                        inTangentType="stepnext",
                    )
                    # Restore out-tangent type (always)
                    if ott:
                        cmds.keyTangent(
                            curve, edit=True, time=time_arg, outTangentType=ott[0]
                        )
                    # Restore angle/weight only for "fixed" tangents
                    if restore_geometry:
                        if oa is not None:
                            cmds.keyTangent(
                                curve, edit=True, time=time_arg, outAngle=oa[0]
                            )
                        if ow is not None:
                            cmds.keyTangent(
                                curve, edit=True, time=time_arg, outWeight=ow[0]
                            )
                else:  # side == "out"
                    # Preserve in-tangent
                    itt = cmds.keyTangent(
                        curve, q=True, time=time_arg, inTangentType=True
                    )
                    restore_geometry = itt and itt[0] == "fixed"
                    if restore_geometry:
                        ia = cmds.keyTangent(curve, q=True, time=time_arg, inAngle=True)
                        iw = cmds.keyTangent(
                            curve, q=True, time=time_arg, inWeight=True
                        )
                    cmds.keyTangent(
                        curve,
                        edit=True,
                        time=time_arg,
                        lock=False,
                        outTangentType="step",
                    )
                    # Restore in-tangent type (always)
                    if itt:
                        cmds.keyTangent(
                            curve, edit=True, time=time_arg, inTangentType=itt[0]
                        )
                    # Restore angle/weight only for "fixed" tangents
                    if restore_geometry:
                        if ia is not None:
                            cmds.keyTangent(
                                curve, edit=True, time=time_arg, inAngle=ia[0]
                            )
                        if iw is not None:
                            cmds.keyTangent(
                                curve, edit=True, time=time_arg, inWeight=iw[0]
                            )
            except RuntimeError:
                pass

        # --- Dict: per-curve per-time stepping ---
        if isinstance(keys, dict) and keys:
            for curve, key_times in keys.items():
                if key_times is None:
                    _apply(curve)
                else:
                    for t in key_times:
                        _apply(curve, time_arg=(t, t))
            result["curves"] = len(keys)
            return result

        # --- Curve names passed directly (e.g. graph-editor selection) ---
        # Query the *selected* key times per curve so that only those
        # keys are stepped, not the entire curve.
        if isinstance(keys, (list, tuple)) and keys:
            unique = set(keys)
            for curve in unique:
                sel_times = cmds.keyframe(
                    curve, query=True, selected=True, timeChange=True
                )
                if sel_times:
                    for t in sel_times:
                        _apply(curve, time_arg=(t, t))
                else:
                    # Fallback: no selection info — step the whole curve
                    _apply(curve)
            result["curves"] = len(unique)
            return result

        # --- Resolve objects ---
        if objects is None:
            objects = pm.selected()
        if not objects:
            return result

        curves = AnimUtils.objects_to_curves(objects, as_strings=True)
        if not curves:
            return result

        # --- Time value: step only keys at that frame ---
        if isinstance(keys, (int, float)):
            time_arg = (keys, keys)
            touched = [
                c
                for c in curves
                if cmds.keyframe(c, query=True, time=time_arg, keyframeCount=True)
            ]
            for curve in touched:
                _apply(curve, time_arg=time_arg)
            result["curves"] = len(touched)
            result["objects"] = len(objects)
            return result

        # --- None: step all keys ---
        for curve in curves:
            _apply(curve)
        result["curves"] = len(curves)
        result["objects"] = len(objects)
        return result

    @staticmethod
    def set_current_frame(
        time: Optional[float] = None,
        update: bool = True,
        relative: bool = False,
        snap_mode: Optional[str] = None,
        invert_snap: bool = False,
    ) -> float:
        """Set the current frame on the timeslider with optional snapping.

        Parameters:
            time: The desired frame number or offset. If None, uses current time.
            update: Change the current time, but do not update the world.
            relative: If True, the frame will be moved relative to its current position.
            snap_mode: Snapping mode ('nearest', 'preferred', 'aggressive', etc.).
            invert_snap: If True, inverts the snapping direction (for preferred/aggressive modes).

        Returns:
            float: The final time that was set.
        """
        current_time = pm.currentTime(query=True)

        # Determine base target time
        if time is None:
            target_time = current_time
        elif relative:
            target_time = current_time + time
        else:
            target_time = time

        # Apply snapping
        if snap_mode and snap_mode.lower() != "none":
            # Handle alias for aggressive
            mode = snap_mode.lower()
            if mode == "aggressive":
                mode = "aggressive_preferred"

            # Invert swaps directional modes (floor ↔ ceil)
            if invert_snap:
                if mode == "floor":
                    mode = "ceil"
                elif mode == "ceil":
                    mode = "floor"

            target_time = ptk.MathUtils.round_value(
                target_time,
                mode=mode,
            )

        pm.currentTime(target_time, edit=True, update=update)
        return target_time

    @staticmethod
    @CoreUtils.undoable
    def move_keys_to_frame(
        objects=None,
        frame=None,
        time_range=None,
        selected_keys_only=False,
        retain_spacing=False,
        channel_box_attrs_only=False,
        align: str = "auto",
    ):
        """Move keyframes to the given frame with comprehensive control options.

        Parameters:
            objects (list, optional): Objects to move keys for. If None, uses selection.
            frame (int or float, optional): The frame to move keys to.
                                                   If None, uses the current time.
            time_range (tuple, optional): (start_frame, end_frame) to limit which keys to move.
                                         If None, moves all keys.
            selected_keys_only (bool): If True, only moves selected keys from the graph editor.
                                 If False, moves all keys in the specified time range.
            retain_spacing (bool): If True, maintains relative spacing between objects.
                                   If False, moves each object's first key to the target frame.
            channel_box_attrs_only (bool): If True, only affects attributes selected in the channel box.
                                    Works in combination with selected_keys_only.
            align (str): Which end of the key range lands on *frame*.
                ``"start"`` — the earliest key aligns to *frame*.
                ``"end"`` — the latest key aligns to *frame*.
                ``"auto"`` (default) — if the midpoint of the key range is
                before *frame*, behaves like ``"end"``; otherwise ``"start"``.
        Returns:
            bool: True if keys were moved successfully, False otherwise.
        """
        # Get target frame (use current time if not specified)
        if frame is None:
            frame = pm.currentTime(query=True)

        # Get objects to work with
        if objects is None:
            objects = pm.selected()

        if not objects:
            pm.warning("No objects specified or selected.")
            return False

        objects = pm.ls(objects)  # Ensure we have PyMel objects

        # Get channel box attributes if filtering is requested
        channel_box_attrs = None
        if channel_box_attrs_only:
            channel_box_attrs = pm.channelBox(
                "mainChannelBox", query=True, selectedMainAttributes=True
            )
            if not channel_box_attrs:
                pm.warning("No attributes selected in channel box.")
                return False

        # If working with selected keys, validate there are selected keys
        if selected_keys_only:
            all_active_key_times = pm.keyframe(query=True, sl=True, tc=True)
            if not all_active_key_times:
                pm.warning("No keyframes selected.")
                return False

        # Resolve "auto" align by scanning all relevant key times
        if align == "auto":
            all_times = []
            for obj in objects:
                if selected_keys_only:
                    _keys = pm.keyframe(obj, query=True, name=True, sl=True)
                    for _node in _keys:
                        if time_range:
                            _t = pm.keyframe(
                                _node, query=True, sl=True, tc=True, time=time_range
                            )
                        else:
                            _t = pm.keyframe(_node, query=True, sl=True, tc=True)
                        if _t:
                            all_times.extend(_t)
                else:
                    if time_range:
                        _t = pm.keyframe(
                            obj, query=True, timeChange=True, time=time_range
                        )
                    else:
                        _t = pm.keyframe(obj, query=True, timeChange=True)
                    if _t:
                        all_times.extend(_t)
            if all_times:
                midpoint = (min(all_times) + max(all_times)) / 2.0
                align = "end" if midpoint < frame else "start"
            else:
                align = "start"

        # Pick the anchor function based on align mode
        align_end = align == "end"
        _anchor = max if align_end else min
        # Comparison used for the retain_spacing scan across objects
        _is_better = (
            (lambda new, best: new > best)
            if align_end
            else (lambda new, best: new < best)
        )

        keys_moved = 0

        # If maintaining spacing, calculate the global offset from the anchor key across all objects
        global_offset = None
        if retain_spacing:
            anchor_key_time = None

            # Find the anchor key across all objects
            for obj in objects:
                if selected_keys_only:
                    keys = pm.keyframe(obj, query=True, name=True, sl=True)
                    for node in keys:
                        if time_range:
                            active_key_times = pm.keyframe(
                                node, query=True, sl=True, tc=True, time=time_range
                            )
                        else:
                            active_key_times = pm.keyframe(
                                node, query=True, sl=True, tc=True
                            )

                        if active_key_times:
                            obj_anchor = _anchor(active_key_times)
                            if anchor_key_time is None or _is_better(
                                obj_anchor, anchor_key_time
                            ):
                                anchor_key_time = obj_anchor
                else:
                    if time_range:
                        keys = pm.keyframe(
                            obj, query=True, timeChange=True, time=time_range
                        )
                    else:
                        keys = pm.keyframe(obj, query=True, timeChange=True)

                    if keys:
                        obj_anchor = _anchor(keys)
                        if anchor_key_time is None or _is_better(
                            obj_anchor, anchor_key_time
                        ):
                            anchor_key_time = obj_anchor

            if anchor_key_time is not None:
                global_offset = frame - anchor_key_time

        for obj in objects:
            # Get keyframes based on selection preference and time range
            if selected_keys_only:
                # Use AnimUtils pattern for selected keys
                keys = pm.keyframe(obj, query=True, name=True, sl=True)

                # Filter by channel box attributes if requested
                if channel_box_attrs_only:
                    filtered_keys = []
                    for node in keys:
                        # Get the attribute name from the curve node
                        connections = pm.listConnections(
                            node, plugs=True, destination=True, source=False
                        )
                        if connections:
                            attr_name = connections[0].attrName()
                            if attr_name in channel_box_attrs:
                                filtered_keys.append(node)
                    keys = filtered_keys

                for node in keys:
                    if time_range:
                        active_key_times = pm.keyframe(
                            node, query=True, sl=True, tc=True, time=time_range
                        )
                    else:
                        active_key_times = pm.keyframe(
                            node, query=True, sl=True, tc=True
                        )

                    if active_key_times:
                        # Calculate offset - use global offset if maintaining spacing
                        if retain_spacing and global_offset is not None:
                            offset = global_offset
                        else:
                            anchor_time = _anchor(active_key_times)
                            offset = frame - anchor_time

                        # Move keys using AnimUtils pattern
                        pm.keyframe(
                            node,
                            edit=True,
                            time=(min(active_key_times), max(active_key_times)),
                            relative=True,
                            timeChange=offset,
                        )
                        keys_moved += len(active_key_times)
            else:
                # Handle all keys in time range
                if channel_box_attrs_only:
                    # Move keys only for channel box attributes
                    for attr in channel_box_attrs:
                        if not obj.hasAttr(attr):
                            continue

                        attr_name = f"{obj}.{attr}"
                        if time_range:
                            keys = pm.keyframe(
                                attr_name, query=True, timeChange=True, time=time_range
                            )
                        else:
                            keys = pm.keyframe(attr_name, query=True, timeChange=True)

                        if keys:
                            # Calculate offset - use global offset if maintaining spacing
                            if retain_spacing and global_offset is not None:
                                offset = global_offset
                            else:
                                anchor_time = _anchor(keys)
                                offset = frame - anchor_time

                            # Move the keys
                            if time_range:
                                pm.keyframe(
                                    attr_name,
                                    edit=True,
                                    time=time_range,
                                    relative=True,
                                    timeChange=offset,
                                )
                            else:
                                pm.keyframe(
                                    attr_name,
                                    edit=True,
                                    relative=True,
                                    timeChange=offset,
                                )
                            keys_moved += len(keys)
                else:
                    # Move all keys on object
                    if time_range:
                        keys = pm.keyframe(
                            obj, query=True, timeChange=True, time=time_range
                        )
                    else:
                        keys = pm.keyframe(obj, query=True, timeChange=True)

                    if keys:
                        # Calculate offset - use global offset if maintaining spacing
                        if retain_spacing and global_offset is not None:
                            offset = global_offset
                        else:
                            anchor_time = _anchor(keys)
                            offset = frame - anchor_time

                        # Move the keys using keyframe
                        if time_range:
                            pm.keyframe(
                                obj,
                                edit=True,
                                time=time_range,
                                relative=True,
                                timeChange=offset,
                            )
                        else:
                            pm.keyframe(
                                obj, edit=True, relative=True, timeChange=offset
                            )

                        keys_moved += len(keys)

        if keys_moved > 0:
            selection_type = "selected" if selected_keys_only else "all"
            range_info = f" in range {time_range}" if time_range else ""
            spacing_info = " (maintaining relative spacing)" if retain_spacing else ""
            pm.displayInfo(
                f"Moved {keys_moved} {selection_type} keys to frame {frame}{range_info}{spacing_info}"
            )
            return True
        else:
            pm.warning("No keyframes found to move.")
            return False

    @staticmethod
    @CoreUtils.undoable
    def set_keys_for_attributes(
        objects, target_times=None, refresh_channel_box=False, **kwargs
    ):
        """Sets keyframes for the specified attributes on given objects at given times.

        Automatically detects whether to apply the same values to all objects (shared mode)
        or different values per object (per-object mode) based on the data structure.

        Parameters:
            objects (list): The objects to set the keyframes on.
            target_times (int/list, optional): Frame(s) to set keys at. Default: current time.
            refresh_channel_box (bool, optional): Update channel box after setting keys. Default: False.
            **kwargs: Can be used in two modes:

                SHARED MODE - Same values to all objects:
                    Attribute names as keys with their values.

                PER-OBJECT MODE - Different values per object:
                    Pass the per-object dictionary unpacked. The function auto-detects this mode when
                    the first kwarg value is a dict containing attribute/value pairs.
                    Format when unpacking: {obj_name: {attr: value, ...}, ...}

        Example:
            # Shared mode - same values to all objects
            set_keys_for_attributes([obj1, obj2], translateX=5, translateY=10)
            set_keys_for_attributes(objects, target_times=[10, 15, 20], translateX=5)

            # Per-object mode - different values per object (auto-detected)
            data = {'pCube1': {'translateX': 5.0}, 'pCube2': {'translateX': 10.0}}
            set_keys_for_attributes([obj1, obj2], **data)

            # With times and refresh
            set_keys_for_attributes(objects, target_times=10, refresh_channel_box=True, translateX=5)
        """
        if target_times is None:
            target_times = [pm.currentTime(query=True)]
        elif isinstance(target_times, int):
            target_times = [target_times]

        # Auto-detect per-object mode: if first remaining kwarg value is a dict of attributes
        per_object_mode = False
        if kwargs:
            first_value = next(iter(kwargs.values()))
            # Per-object mode if the value is a dict (and likely contains attribute mappings)
            if isinstance(first_value, dict):
                per_object_mode = True

        if per_object_mode:
            # Per-object mode: Each object gets its specific attribute values
            # kwargs structure: {obj_name: {attr: value, ...}, ...}
            per_object_data = kwargs

            for obj in pm.ls(objects):
                obj_name = str(obj)

                # Try to find matching stored data
                obj_attrs = per_object_data.get(obj_name)

                if not obj_attrs:
                    # Try short name if full path didn't match
                    short_name = obj.nodeName()
                    obj_attrs = per_object_data.get(short_name)

                    # Try matching stored short names against current long name
                    if not obj_attrs:
                        for stored_name in per_object_data.keys():
                            if stored_name.split("|")[-1] == short_name:
                                obj_attrs = per_object_data.get(stored_name)
                                break

                if obj_attrs:
                    for attr, value in obj_attrs.items():
                        attr_full_name = f"{obj}.{attr}"
                        for time in target_times:
                            AnimUtils._set_key_preserving_tangents(
                                attr_full_name, time, value
                            )
        else:
            # Shared mode: All objects get the same attribute values
            # kwargs structure: {attr: value, attr2: value2, ...}
            for obj in pm.ls(objects):
                for attr, value in kwargs.items():
                    attr_full_name = f"{obj}.{attr}"
                    for time in target_times:
                        AnimUtils._set_key_preserving_tangents(
                            attr_full_name, time, value
                        )

        if refresh_channel_box:
            pm.mel.eval("channelBoxCommand -update;")

    @staticmethod
    def filter_objects_with_keys(
        objects: Optional[Union[str, List[str]]] = None,
        keys: Optional[List[str]] = None,
    ) -> List[object]:
        """Filter the given objects for those with specific keys set. If no objects are given, use all scene objects. If no specific keys are given, check all keys.

        Parameters:
            objects: The objects (or their names) to filter. Can be a single object or a list of objects. If None, all scene objects are used.
            keys: Specific keys to check for. If none are provided, all keys are checked.

        Returns:
            List of transforms with the specified keys set.
        """
        if objects is None:
            objects = pm.ls(type="transform")
        else:
            objects = pm.ls(objects, type="transform")

        if keys is None:
            keys = pm.listAttr(objects, keyable=True)

        filtered_objects = []
        for obj in objects:
            for key in ptk.make_iterable(keys):
                if obj.hasAttr(key):
                    attr = obj.attr(key)
                    if pm.keyframe(attr, query=True, name=True):
                        filtered_objects.append(obj)
                        break  # No need to check other keys if one is found

        return filtered_objects

    @classmethod
    @CoreUtils.undoable
    def adjust_key_spacing(
        cls,
        objects: Optional[List[str]] = None,
        spacing: int = 1,
        time: Optional[int] = 0,
        relative: bool = True,
        preserve_keys: bool = False,
        selected_keys_only: bool = False,
        exact_gap: bool = False,
        prevent_collisions: bool = True,
    ):
        """Adjusts the spacing between keyframes for specified objects at a given time,
        with an option to preserve and adjust a keyframe at the specified time.

        Operates on animation curves directly, supporting both object-level and
        graph-editor-selection workflows.

        Parameters:
            objects (Optional[List[str]]): Objects to adjust keyframes for.
                If None, adjusts all scene objects (or selected keys when selected_keys_only is True).
                When selected_keys_only is True, objects is ignored and curves are
                determined entirely from the graph editor selection.
            spacing (int): Spacing to add or remove. Negative values remove spacing.
                When exact_gap is True, this is the desired gap size in frames
                (must be positive) and the actual shift is calculated so the first
                key after the start time lands exactly at (start + spacing).
            time (Optional[int]): Time at which to start adjusting spacing.
                                 If None, uses the current playhead time.
            relative (bool): If True, time is relative to the current frame.
            preserve_keys (bool): Preserves and adjusts a keyframe at the specified time
                if it exists. Only considers keys visible to the current query
                (i.e. when selected_keys_only is True, only selected keys are preserved).
            selected_keys_only (bool): If True, only affects selected keyframes in the graph editor.
                Overrides objects — the curve set comes from the graph editor selection.
            exact_gap (bool): If True, calculates the actual shift amount so that the
                first key after the start time is moved exactly to (start + spacing),
                clearing a precise range. Spacing must be positive in this mode.
            prevent_collisions (bool): If True (default), performs a dry-run
                collision check before moving any keys. If any destination time
                would land on an existing unmoved key, the entire operation is
                aborted and a warning is issued.
        """
        if spacing == 0:
            return

        if exact_gap and spacing < 0:
            pm.warning("exact_gap mode requires a positive spacing value.")
            return

        current_time = pm.currentTime(query=True)

        # Auto-detect: use current playhead time
        if time is None:
            adjusted_time = current_time
        else:
            adjusted_time = time + current_time if relative else time

        # Get animation curves — selected_keys_only overrides objects
        if selected_keys_only:
            anim_curves = cls.get_anim_curves(
                objects=None, selected_keys_only=True, recursive=False
            )
        else:
            anim_curves = cls.get_anim_curves(
                objects=objects, selected_keys_only=False, recursive=False
            )
        if not anim_curves:
            if selected_keys_only:
                pm.warning("No keyframes selected.")
            else:
                pm.warning("No animation found.")
            return

        # In exact_gap mode, find the earliest key after adjusted_time to compute offset
        actual_spacing = spacing
        if exact_gap:
            gap_end = adjusted_time + spacing
            earliest_key = None
            for curve in anim_curves:
                if selected_keys_only:
                    kf = pm.keyframe(curve, query=True, sl=True, timeChange=True)
                else:
                    kf = pm.keyframe(curve, query=True, timeChange=True)
                if kf:
                    after = [k for k in kf if k > adjusted_time + 0.001]
                    if after:
                        curve_min = min(after)
                        if earliest_key is None or curve_min < earliest_key:
                            earliest_key = curve_min
            if earliest_key is None:
                pm.warning(f"No keyframes found after frame {adjusted_time}.")
                return
            actual_spacing = int(gap_end - earliest_key)
            if actual_spacing <= 0:
                # Gap already clear
                return

        # If preserve_keys, save keyframes at adjusted_time before moving them
        preserved_keys = []  # [(attr_name, value, tangent_info)]
        tolerance = 0.0001

        # ---------- Collision pre-flight check ----------
        # Build per-curve move plans so we can detect collisions before
        # touching any keys.
        curve_plans = []  # [(curve, keys_to_move, keyframes)]
        for curve in anim_curves:
            if selected_keys_only:
                keyframes = pm.keyframe(curve, query=True, sl=True, timeChange=True)
            else:
                keyframes = pm.keyframe(curve, query=True, timeChange=True)
            if not keyframes:
                continue

            keys_to_move = sorted(
                [k for k in keyframes if k >= adjusted_time - tolerance],
                reverse=(actual_spacing > 0),
            )
            curve_plans.append((curve, keys_to_move, keyframes))

        if prevent_collisions:
            for curve, keys_to_move, keyframes in curve_plans:
                if not keys_to_move:
                    continue
                moving_set = set(keys_to_move)
                # Keys on this curve that are NOT being moved
                stationary = {k for k in keyframes if k not in moving_set}
                for key in keys_to_move:
                    dest = max(key + actual_spacing, 0)
                    if dest == key:
                        continue
                    # Collision with a stationary key?
                    if any(abs(dest - s) < tolerance for s in stationary):
                        pm.warning(
                            f"Cannot move keys: frame {int(key)} would collide "
                            f"with an existing key at frame {int(dest)}. "
                            f"Reduce the spacing amount or move the blocking key first."
                        )
                        return

        # ---------- Execute moves ----------
        for curve, keys_to_move, keyframes in curve_plans:

            # Get the attribute name connected to this curve for preserve_keys
            if preserve_keys and any(
                abs(k - adjusted_time) < tolerance for k in keyframes
            ):
                connections = pm.listConnections(
                    curve, plugs=True, source=False, destination=True
                )
                if connections:
                    attr_name = str(connections[0])
                    value = pm.getAttr(attr_name, time=adjusted_time)
                    tangent_info = cls.get_tangent_info(attr_name, adjusted_time)
                    preserved_keys.append((attr_name, value, tangent_info))

            if not keys_to_move:
                continue

            # Batch move: group into contiguous ranges where possible
            for key in keys_to_move:
                new_time = max(key + actual_spacing, 0)
                if new_time != key:
                    try:
                        pm.keyframe(
                            curve,
                            edit=True,
                            time=(key,),
                            timeChange=new_time,
                        )
                    except RuntimeError:
                        pass

        # Restore preserved keyframes at the original time
        for attr_name, value, tangent_info in preserved_keys:
            pm.setKeyframe(attr_name, time=(adjusted_time,), value=value)
            cls.set_tangent_info(attr_name, adjusted_time, tangent_info)

    @staticmethod
    def add_intermediate_keys(
        objects: Union[str, "pm.nt.Transform", List[Union[str, "pm.nt.Transform"]]],
        time_range: Optional[Union[int, Tuple[int, int]]] = None,
        percent: Optional[float] = None,
        include_flat: bool = False,
        ignore: Union[str, List[str], None] = None,
    ) -> None:
        """Keys selected or animated attributes on given object(s) within a time range.
        If attributes are selected in the channel box, only those will be keyed.
        If time_range is not specified, automatically detects the first and last keyframe per attribute.

        Parameters:
            objects (str/list): One or more objects to key.
            time_range (int, tuple, or None):
                - None: Auto-detects range from first to last keyframe per attribute
                - int: End frame (starts from first keyframe)
                - tuple (start, end): Explicit start and end frames
            percent (float): Optional percent (0-100) of frames to key, evenly distributed.
            include_flat (bool): If False, skips keys where value doesn't vary across time.
            ignore (str/list, optional): Attribute name(s) to ignore when adding keys.
                E.g., 'visibility' or ['visibility', 'translateX']. Curves connected to these
                attributes will not have intermediate keys added.
        """
        from math import isclose

        targets = pm.ls(objects, flatten=True)
        attrs = pm.channelBox("mainChannelBox", q=True, selectedMainAttributes=True)
        if not attrs:
            attrs = set()
            for obj in targets:
                for plug in obj.listAttr(keyable=True, scalar=True):
                    if plug.isConnected():
                        attrs.add(plug.attrName())
            attrs = list(attrs)

        if not attrs:
            pm.warning("No keyable or connected attributes found.")
            return

        # Filter out ignored attributes
        attrs = AnimUtils._filter_attributes_by_ignore(attrs, ignore)
        if not attrs:
            pm.warning("All attributes were ignored.")
            return

        # Build per-attribute key data with auto-detected or explicit ranges
        attr_key_data = {}
        for obj in targets:
            for attr in attrs:
                plug = obj.attr(attr)
                if not plug.isConnected() or not plug.isKeyable():
                    continue

                # Determine range based on time_range parameter
                if time_range is None:
                    # Auto-detect full range
                    key_times = pm.keyframe(plug, query=True, timeChange=True)
                    if not key_times or len(key_times) < 2:
                        continue
                    attr_start = int(key_times[0])
                    attr_end = int(key_times[-1])
                elif isinstance(time_range, tuple):
                    # Tuple (start, end) - either can be None for auto-detect
                    start_val, end_val = time_range
                    key_times = None

                    if start_val is None or end_val is None:
                        key_times = pm.keyframe(plug, query=True, timeChange=True)
                        if not key_times:
                            continue

                    attr_start = int(key_times[0]) if start_val is None else start_val
                    attr_end = int(key_times[-1]) if end_val is None else end_val
                else:
                    # Single int - start from first key, end at specified frame
                    key_times = pm.keyframe(plug, query=True, timeChange=True)
                    if not key_times:
                        continue
                    attr_start = int(key_times[0])
                    attr_end = time_range

                # Calculate frames to key (excluding bookends)
                frames = list(range(attr_start + 1, attr_end))
                if percent is not None:
                    count = max(1, int(len(frames) * (percent / 100.0)))
                    step = max(1, len(frames) // count)
                    frames = frames[::step]

                if frames:
                    attr_key_data.setdefault((obj, attr), []).extend(frames)

        # Collect values for all frames
        frame_values = {}
        for (obj, attr), frames in attr_key_data.items():
            plug = obj.attr(attr)
            for frame in frames:
                pm.currentTime(frame, edit=True)
                frame_values.setdefault(frame, {}).setdefault(obj, {})[
                    attr
                ] = plug.get()

        # Set keys
        for frame, obj_data in frame_values.items():
            pm.currentTime(frame, edit=True)
            for obj, attr_values in obj_data.items():
                for attr, value in attr_values.items():
                    plug = obj.attr(attr)
                    if not include_flat:
                        try:
                            val_prev = plug.get(time=frame - 1)
                            val_next = plug.get(time=frame + 1)
                            if isclose(value, val_prev, abs_tol=1e-6) and isclose(
                                value, val_next, abs_tol=1e-6
                            ):
                                continue
                        except Exception:
                            continue
                    plug.set(value)
                    plug.setKey()

    @staticmethod
    @CoreUtils.undoable
    def remove_intermediate_keys(
        objects: Union[str, "pm.nt.Transform", List[Union[str, "pm.nt.Transform"]]],
        time_range: Optional[Union[int, Tuple[int, int]]] = None,
        ignore: Union[str, List[str], None] = None,
    ) -> int:
        """Removes all intermediate keyframes, keeping only the first and last key on each attribute.
        If attributes are selected in the channel box, only those will be affected.
        Automatically detects the keyframe range for each attribute if time_range is not specified.

        Parameters:
            objects (str/list): One or more objects to remove intermediate keys from.
            time_range (int, tuple, or None):
                - None: Auto-detects range from first to last keyframe per attribute
                - int: End frame (starts from first keyframe)
                - tuple (start, end): Explicit start and end frames
            ignore (str/list, optional): Attribute name(s) to ignore when removing keys.
                E.g., 'visibility' or ['visibility', 'translateX']. Curves connected to these
                attributes will not have intermediate keys removed.

        Returns:
            int: Number of keyframes removed.

        Example:
            # Remove all intermediate keys, keeping only first and last
            remove_intermediate_keys(pm.selected())

            # Remove intermediate keys for channel box selected attributes only
            remove_intermediate_keys([obj1, obj2])

            # Remove intermediate keys except for visibility
            remove_intermediate_keys(pm.selected(), ignore='visibility')

            # Remove intermediate keys within specific range
            remove_intermediate_keys(pm.selected(), time_range=(10, 50))
        """
        targets = pm.ls(objects, flatten=True)
        if not targets:
            pm.warning("No valid objects provided.")
            return 0

        # Check for channel box selected attributes
        cb_attrs = pm.channelBox("mainChannelBox", q=True, selectedMainAttributes=True)

        # Filter out ignored attributes
        if cb_attrs:
            cb_attrs = AnimUtils._filter_attributes_by_ignore(cb_attrs, ignore)

        keys_removed = 0

        for obj in targets:
            if cb_attrs:
                # Remove keys only for channel box selected attributes
                for attr in cb_attrs:
                    if obj.hasAttr(attr):
                        attr_name = f"{obj}.{attr}"

                        # Determine range based on time_range parameter
                        if time_range is None:
                            # Auto-detect full range
                            keyframe_times = pm.keyframe(
                                attr_name, query=True, timeChange=True
                            )
                            if not keyframe_times or len(keyframe_times) < 2:
                                continue
                            start = sorted(keyframe_times)[0]
                            end = sorted(keyframe_times)[-1]
                        elif isinstance(time_range, tuple):
                            # Tuple (start, end) - either can be None for auto-detect
                            start_val, end_val = time_range
                            key_times = None

                            if start_val is None or end_val is None:
                                key_times = pm.keyframe(
                                    attr_name, query=True, timeChange=True
                                )
                                if not key_times:
                                    continue

                            start = (
                                sorted(key_times)[0] if start_val is None else start_val
                            )
                            end = sorted(key_times)[-1] if end_val is None else end_val
                        else:
                            # Single int - start from first key, end at specified frame
                            key_times = pm.keyframe(
                                attr_name, query=True, timeChange=True
                            )
                            if not key_times:
                                continue
                            start = sorted(key_times)[0]
                            end = time_range

                        # Count keys that will be removed
                        intermediate_keys = pm.keyframe(
                            attr_name,
                            query=True,
                            timeChange=True,
                            time=(start + 0.001, end - 0.001),
                        )
                        if intermediate_keys:
                            keys_removed += len(intermediate_keys)
                            # Remove intermediate keys (exclusive of start and end)
                            pm.cutKey(
                                attr_name,
                                time=(start + 0.001, end - 0.001),
                                clear=True,
                            )
            else:
                # Get all keyed attributes on the object
                keyed_attrs = pm.keyframe(obj, query=True, name=True)

                if keyed_attrs:
                    # Filter out ignored curves
                    keyed_attrs = AnimUtils._filter_curves_by_ignore(
                        keyed_attrs, ignore
                    )

                    for attr in keyed_attrs:
                        # Determine range based on time_range parameter
                        if time_range is None:
                            # Auto-detect full range
                            keyframe_times = pm.keyframe(
                                attr, query=True, timeChange=True
                            )
                            if not keyframe_times or len(keyframe_times) < 2:
                                continue
                            start = sorted(keyframe_times)[0]
                            end = sorted(keyframe_times)[-1]
                        elif isinstance(time_range, tuple):
                            # Tuple (start, end) - either can be None for auto-detect
                            start_val, end_val = time_range
                            key_times = None

                            if start_val is None or end_val is None:
                                key_times = pm.keyframe(
                                    attr, query=True, timeChange=True
                                )
                                if not key_times:
                                    continue

                            start = (
                                sorted(key_times)[0] if start_val is None else start_val
                            )
                            end = sorted(key_times)[-1] if end_val is None else end_val
                        else:
                            # Single int - start from first key, end at specified frame
                            key_times = pm.keyframe(attr, query=True, timeChange=True)
                            if not key_times:
                                continue
                            start = sorted(key_times)[0]
                            end = time_range

                        # Count and remove intermediate keys
                        intermediate_keys = pm.keyframe(
                            attr,
                            query=True,
                            timeChange=True,
                            time=(start + 0.001, end - 0.001),
                        )
                        if intermediate_keys:
                            keys_removed += len(intermediate_keys)
                            pm.cutKey(
                                attr, time=(start + 0.001, end - 0.001), clear=True
                            )

        if keys_removed > 0:
            pm.displayInfo(f"Removed {keys_removed} intermediate keyframe(s).")
        else:
            pm.displayInfo("No intermediate keyframes found to remove.")

        return keys_removed

    @staticmethod
    @CoreUtils.undoable
    def invert_keys(
        time=None,
        relative=True,
        delete_original=False,
        mode="horizontal",
        value_pivot=0.0,
    ):
        """Invert keyframes around the last key, preferring selected keys but falling back to all keys.

        Parameters:
            time (int, optional): Desired start time for inverted keys.
                If None, uses the current time as an absolute start position.
            relative (bool): When True, time is treated as an offset from the last key.
                Ignored when time is None (auto mode always uses absolute positioning).
                Defaults to True.
            delete_original (bool): Delete the source keyframes after inversion. Defaults to False.
            mode (str): Inversion mode. "horizontal" (time), "vertical" (value), or "both". Defaults to "horizontal".
            value_pivot (float): Pivot value for vertical inversion. Defaults to 0.0.
        """

        selection = pm.selected()
        if not selection:
            raise RuntimeError("No objects selected.")

        selected_key_times = pm.keyframe(query=True, sl=True, tc=True) or []
        use_selected = bool(selected_key_times)

        key_entries: List[Tuple[Any, float]] = []
        seen_entries: Set[Tuple[str, float]] = set()
        all_key_times: List[float] = []

        for obj in selection:
            key_nodes = (
                pm.keyframe(obj, query=True, name=True, selected=True) or []
                if use_selected
                else pm.keyframe(obj, query=True, name=True) or []
            )

            for node in key_nodes:
                times = (
                    pm.keyframe(node, query=True, selected=True, timeChange=True)
                    if use_selected
                    else pm.keyframe(node, query=True, timeChange=True)
                )
                if not times:
                    continue

                for t in times:
                    identifier = (str(node), float(t))
                    if identifier in seen_entries:
                        continue
                    seen_entries.add(identifier)
                    key_entries.append((node, float(t)))
                    all_key_times.append(float(t))

        if not all_key_times:
            raise RuntimeError("No keyframes selected or found to invert.")

        max_time = max(all_key_times)
        min_time = min(all_key_times)

        if time is None:
            time = pm.currentTime(q=True)
            relative = False

        inversion_point = max_time + time if relative else time

        keyframe_data: List[
            Tuple[Any, float, float, float, float, Optional[float], Optional[float]]
        ] = []
        for node, key_time in key_entries:
            key_value = pm.keyframe(node, query=True, time=(key_time,), eval=True)[0]

            # Calculate inverted time
            if mode in ("horizontal", "both"):
                inverted_time = inversion_point - (key_time - max_time)
            else:
                inverted_time = key_time

            # Calculate inverted value
            if mode in ("vertical", "both"):
                inverted_value = value_pivot - (key_value - value_pivot)
            else:
                inverted_value = key_value

            in_angle = None
            out_angle = None
            try:
                in_angles = pm.keyTangent(
                    node, query=True, time=(key_time,), inAngle=True
                )
                out_angles = pm.keyTangent(
                    node, query=True, time=(key_time,), outAngle=True
                )
                if in_angles and out_angles:
                    in_angle = in_angles[0]
                    out_angle = out_angles[0]
            except Exception:
                pass

            keyframe_data.append(
                (
                    node,
                    key_time,
                    key_value,
                    inverted_time,
                    inverted_value,
                    in_angle,
                    out_angle,
                )
            )

        for (
            node,
            key_time,
            key_value,
            inverted_time,
            inverted_value,
            in_angle,
            out_angle,
        ) in keyframe_data:
            pm.setKeyframe(node, time=inverted_time, value=inverted_value)

            if in_angle is not None and out_angle is not None:
                new_in = in_angle
                new_out = out_angle

                if mode == "horizontal":
                    new_in = -out_angle
                    new_out = -in_angle
                elif mode == "vertical":
                    new_in = -in_angle
                    new_out = -out_angle
                elif mode == "both":
                    new_in = out_angle
                    new_out = in_angle

                pm.keyTangent(
                    node,
                    edit=True,
                    time=(inverted_time,),
                    inAngle=new_in,
                    outAngle=new_out,
                )

        if delete_original:
            inverted_positions = {
                (str(node), round(inverted_time, 3))
                for node, key_time, key_value, inverted_time, inverted_value, in_angle, out_angle in keyframe_data
            }

            for (
                node,
                key_time,
                key_value,
                inverted_time,
                inverted_value,
                in_angle,
                out_angle,
            ) in keyframe_data:
                rounded_time = round(key_time, 3)
                if (str(node), rounded_time) not in inverted_positions:
                    pm.cutKey(node, time=(key_time, key_time))

    @classmethod
    def _apply_stagger(
        cls,
        groups_data: List[dict],
        start_frame: float,
        spacing: Union[int, float] = 0,
        use_intervals: bool = False,
        avoid_overlap: bool = False,
        preserve_gaps: bool = False,
    ) -> int:
        """Apply staggering logic to a list of grouped keyframe data.

        Shared logic used by stagger_keys and scale_keys (for overlap prevention).
        Delegates to SegmentKeys.execute_stagger which implements safe execution order.

        Parameters:
            groups_data: List of dicts with 'start', 'duration', 'curves' keys.
            start_frame: The frame to start the sequence from.
            spacing: Gap/overlap amount.
            use_intervals: Fixed interval mode.
            avoid_overlap: Skip intervals to avoid overlap (interval mode only).
            preserve_gaps: If True, only shifts forward to prevent overlap, never backward (sequential mode only).

        Returns:
            int: Number of groups shifted.
        """
        from mayatk.anim_utils.segment_keys import SegmentKeys

        return SegmentKeys.execute_stagger(
            groups_data,
            start_frame=start_frame,
            spacing=spacing,
            use_intervals=use_intervals,
            avoid_overlap=avoid_overlap,
            preserve_gaps=preserve_gaps,
        )

    @staticmethod
    def _move_curve_keys(
        curve: "pm.PyNode",
        time_pairs: List[Tuple[float, float]],
        tolerance: float = 1e-4,
        allow_merge: bool = False,
    ) -> int:
        """Move keys on a curve to new times, preserving value and tangents.

        Uses a read-cut-set approach to avoid keyframe collisions during retiming.

        Parameters:
            curve: The animation curve to modify.
            time_pairs: List of (old_time, new_time) tuples.
            tolerance: Tolerance for floating point comparisons.
            allow_merge: If True, keys moved to the same time will overwrite each other.
                         If False (default), keys are nudged to avoid collision.
        """

        if not time_pairs:
            return 0

        # 1. Collect data for all keys that need moving
        keys_to_move = []
        for old_time, new_time in time_pairs:
            if abs(new_time - old_time) <= tolerance:
                continue

            # Maya's keyframe query is most reliable when the time argument is a
            # (start, end) pair, even when targeting a single key time.
            # Use a small epsilon to ensure we catch the key even with float precision issues
            eps = 0.5
            values = pm.keyframe(
                curve,
                query=True,
                time=(old_time - eps, old_time + eps),
                valueChange=True,
            )
            # print(f"DEBUG: _move_curve_keys query old_time={old_time} range={old_time-eps}-{old_time+eps} found={values}")
            if not values:
                continue

            tangent_data = AnimUtils._get_curve_tangent_data(curve, old_time)
            keys_to_move.append((old_time, new_time, values[0], tangent_data))

        if not keys_to_move:
            return 0

        # Add a temporary key to prevent the curve from being deleted if we cut all keys
        # Use a very large time value that is unlikely to conflict with actual animation
        temp_time = 1000000.0
        pm.setKeyframe(curve, time=temp_time, value=0)

        # 2. Cut all old keys to clear the way (prevents overwriting/collisions)
        # Process in reverse order to maintain index stability if needed, though time-based cut is robust
        for old_time, _, _, _ in sorted(keys_to_move, key=lambda x: x[0], reverse=True):
            try:
                pm.cutKey(curve, time=(old_time, old_time), option="keys")
            except RuntimeError as error:
                pm.warning(f"Failed to cut key on {curve} at {old_time}: {error}")

        # 3. Set keys at new positions
        moved_count = 0
        # Collect remaining key times (keys not being moved) to avoid overwriting them.
        try:
            remaining_times = pm.keyframe(curve, query=True, timeChange=True) or []
        except Exception:
            remaining_times = []

        # Use an epsilon that's small but larger than tolerance so we can escape collisions.
        epsilon = max(1e-3, tolerance * 10.0)

        def _is_time_taken(candidate: float, taken: List[float]) -> bool:
            for t in taken:
                if abs(candidate - t) <= tolerance:
                    return True
            return False

        taken_times: List[float] = list(remaining_times)

        for _, new_time, value, tangent_data in keys_to_move:
            try:
                candidate_time = float(new_time)

                # Avoid collisions with existing keys and other moved keys.
                # If the time is taken, nudge forward by a tiny epsilon until free.
                # This preserves key count and prevents segments collapsing to 0 duration.
                if not allow_merge:
                    safety = 0
                    while _is_time_taken(candidate_time, taken_times) and safety < 1000:
                        candidate_time += epsilon
                        safety += 1

                pm.setKeyframe(curve, time=candidate_time, value=value)
                AnimUtils._apply_curve_tangent_data(curve, candidate_time, tangent_data)
                taken_times.append(candidate_time)
                moved_count += 1
            except RuntimeError as error:
                pm.warning(f"Failed to set key on {curve} at {new_time}: {error}")

        # Remove the temporary key
        try:
            pm.cutKey(curve, time=(temp_time, temp_time), option="keys")
        except Exception:
            pass

        return moved_count

    @staticmethod
    def _shift_curves_by_amount(
        curves: List["pm.PyNode"],
        shift_amount: float,
        time_range: Optional[Tuple[float, float]] = None,
    ) -> int:
        """Helper method to shift a list of animation curves by a given amount.

        Parameters:
            curves (List[pm.PyNode]): List of animation curve nodes to shift.
            shift_amount (float): Number of frames to shift the curves by.
            time_range (Tuple[float, float], optional): Specific range of keys to shift.

        Returns:
            int: Number of curves successfully shifted.
        """
        shifted_count = 0
        for curve in curves:
            # Determine range to shift
            if time_range:
                # Use specified range
                range_args = {"time": time_range}
            else:
                # Use full curve range
                curve_keyframes = pm.keyframe(curve, query=True, timeChange=True)
                if not curve_keyframes:
                    continue
                range_args = {"time": (min(curve_keyframes), max(curve_keyframes))}

            try:
                pm.keyframe(
                    curve,
                    edit=True,
                    relative=True,
                    timeChange=shift_amount,
                    **range_args,
                )
                shifted_count += 1
            except RuntimeError as e:
                pm.warning(f"Failed to move keys for {curve}: {e}")
        return shifted_count

    @staticmethod
    def _calculate_speed_profile(
        obj: "pm.PyNode", time_range: Tuple[float, float]
    ) -> Tuple[List[float], List[float]]:
        """Calculate per-frame speed profile for an object's positional movement.

        Measures the distance traveled between consecutive frames to determine speed.
        Returns both the raw speed values and normalized (0-1) speed values.

        Parameters:
            obj (pm.PyNode): The object to measure speed for.
            time_range (Tuple[float, float]): (start_frame, end_frame) range to measure.

        Returns:
            Tuple[List[float], List[float]]: (speeds, normalized_speeds)
                - speeds: Raw distance traveled per frame
                - normalized_speeds: Normalized to 0-1 range where 1.0 = fastest movement

        Example:
            speeds, norm_speeds = AnimUtils._calculate_speed_profile(obj, (1, 100))
        """
        sample_times, progress, total_distance = AnimUtils._compute_motion_progress(
            obj, time_range
        )

        if not sample_times or len(progress) < 2:
            return [], []

        speeds: List[float] = []
        for index in range(1, len(progress)):
            delta_progress = progress[index] - progress[index - 1]
            speeds.append(delta_progress * total_distance)

        if speeds:
            max_speed = max(speeds)
            normalized_speeds = [
                s / max_speed if max_speed > 0 else 0.0 for s in speeds
            ]
        else:
            normalized_speeds = []

        return speeds, normalized_speeds

    @staticmethod
    def _group_overlapping_keyframes(obj_keyframe_data: List[dict]) -> List[dict]:
        """Helper method to group objects with overlapping keyframe ranges into single blocks.

        Objects are considered overlapping if their keyframe time ranges intersect.
        Grouped objects are treated as a single unit during staggering operations.

        Parameters:
            obj_keyframe_data (List[dict]): List of dictionaries containing object keyframe data.
                Each dict should have 'obj', 'keyframes', 'start', 'end', and 'duration' keys.

        Returns:
            List[dict]: List of grouped object data. Each group contains:
                - 'objects': List of objects in the group
                - 'keyframes': Combined keyframe times
                - 'start': Earliest keyframe in the group
                - 'end': Latest keyframe in the group
                - 'duration': Total duration of the group
                - 'obj': Representative object (for backward compatibility)
                - 'sub_groups': List of original data dicts in the group

        Example:
            # Objects with overlapping keyframes [1-10], [5-15], [20-30]
            # Would be grouped as: [[obj1, obj2]], [[obj3]]
        """
        if not obj_keyframe_data:
            return []

        # Sort by start frame
        sorted_data = sorted(obj_keyframe_data, key=lambda x: x["start"])

        groups = []
        current_group = {
            "objects": [sorted_data[0]["obj"]],
            "keyframes": sorted_data[0]["keyframes"],
            "start": sorted_data[0]["start"],
            "end": sorted_data[0]["end"],
            "duration": sorted_data[0]["duration"],
            "curves": list(sorted_data[0].get("curves", [])),  # Preserve curves data
            "obj": sorted_data[0][
                "obj"
            ],  # Representative object for backward compatibility
            "sub_groups": [sorted_data[0]],
        }

        for i in range(1, len(sorted_data)):
            data = sorted_data[i]

            # Check if this object overlaps with the current group
            # Use strict inequality (<) to treat touching keys (end == start) as separate groups
            # This ensures sequential animations are not grouped and can be staggered independently
            if data["start"] < current_group["end"]:
                # Overlapping - add to current group
                current_group["objects"].append(data["obj"])
                # Merge keyframes
                current_group["keyframes"] = sorted(
                    set(current_group["keyframes"] + data["keyframes"])
                )
                # Merge curves from all objects in the group
                current_group["curves"].extend(data.get("curves", []))
                # Add to sub_groups
                current_group["sub_groups"].append(data)
                # Update group boundaries
                current_group["end"] = max(current_group["end"], data["end"])
                current_group["duration"] = (
                    current_group["end"] - current_group["start"]
                )
            else:
                # Not overlapping - start new group
                groups.append(current_group)
                current_group = {
                    "objects": [data["obj"]],
                    "keyframes": data["keyframes"],
                    "start": data["start"],
                    "end": data["end"],
                    "duration": data["duration"],
                    "curves": list(data.get("curves", [])),  # Preserve curves data
                    "obj": data["obj"],
                    "sub_groups": [data],
                }

        # Add the last group
        groups.append(current_group)

        return groups

    @staticmethod
    @CoreUtils.undoable
    def align_selected_keyframes(
        objects: Optional[List[Union[str, "pm.PyNode"]]] = None,
        target_frame: Optional[float] = None,
        use_earliest: bool = True,
    ) -> bool:
        """Aligns the starting keyframes of selected keyframes in the graph editor across multiple objects.

        This method finds the earliest (or latest) selected keyframe across all objects and shifts
        each object's selected keyframes so they start at the same frame. Only processes selected
        keyframes from the graph editor.

        Parameters:
            objects (Optional[List[Union[str, pm.PyNode]]]): Objects to align. If None, uses current selection.
            target_frame (Optional[float]): Specific frame to align to. If None, aligns to the earliest
                                           (or latest if use_earliest=False) selected keyframe.
            use_earliest (bool): If True, aligns to the earliest selected keyframe. If False, aligns
                                to the latest. Only used when target_frame is None. Default is True.

        Returns:
            bool: True if keyframes were successfully aligned, False otherwise.

        Example:
            # Align selected keyframes to their earliest frame
            align_selected_keyframes()

            # Align selected keyframes to frame 10
            align_selected_keyframes(target_frame=10)

            # Align selected keyframes to their latest frame
            align_selected_keyframes(use_earliest=False)
        """
        # Get objects to work with
        if objects is None:
            objects = pm.selected()

        if not objects:
            pm.warning("No objects specified or selected.")
            return False

        # Ensure we have transform nodes, not shape nodes
        objects = pm.ls(objects, type="transform", flatten=True)

        if not objects:
            pm.warning("No valid transform nodes found.")
            return False

        # Collect selected keyframe data for each object
        obj_keyframe_data = []

        for obj in objects:
            # Get animation curve nodes with selected keyframes
            curve_nodes = pm.keyframe(obj, query=True, name=True, selected=True)

            if not curve_nodes:
                continue

            # Get the selected keyframe times
            obj_selected_times = AnimUtils.get_keyframe_times(
                curve_nodes, mode="selected", from_curves=True
            )

            if obj_selected_times:
                obj_keyframe_data.append(
                    {
                        "obj": obj,
                        "curve_nodes": curve_nodes,
                        "times": obj_selected_times,
                        "start": obj_selected_times[0],
                        "end": obj_selected_times[-1],
                    }
                )

        if not obj_keyframe_data:
            pm.warning("No selected keyframes found on any objects.")
            return False

        # Determine the alignment target frame
        if target_frame is None:
            if use_earliest:
                target_frame = min(data["start"] for data in obj_keyframe_data)
            else:
                target_frame = max(data["start"] for data in obj_keyframe_data)

        # Align each object's selected keyframes
        for data in obj_keyframe_data:
            obj = data["obj"]
            curve_nodes = data["curve_nodes"]
            times = data["times"]
            current_start = data["start"]

            # Calculate the shift amount
            shift_amount = target_frame - current_start

            if abs(shift_amount) < 1e-6:  # Skip if already aligned (within tolerance)
                continue

            # Shift the selected keyframes for this object
            # Use the time range of selected keys to target only those keys
            min_time = min(times)
            max_time = max(times)

            # Move the keyframes - must target the object, not individual curve nodes
            # to ensure all selected keys move together
            pm.keyframe(
                obj,
                edit=True,
                time=(min_time, max_time),
                relative=True,
                timeChange=shift_amount,
                option="over",  # Only affect keyframes in the time range
            )

        pm.displayInfo(
            f"Aligned selected keyframes for {len(obj_keyframe_data)} object(s) to frame {target_frame:.2f}"
        )
        return True

    @staticmethod
    @CoreUtils.undoable
    def set_visibility_keys(
        objects: Optional[List[Union[str, "pm.PyNode"]]] = None,
        visible: bool = True,
        when: str = "start",
        offset: int = 0,
        group_overlapping: bool = False,
    ) -> int:
        """Sets visibility keyframes for objects with options for timing and grouping.

        This method creates visibility keyframes at specific points in the animation timeline,
        with support for grouping objects that have overlapping keyframe ranges.

        Parameters:
            objects (Optional[List[Union[str, pm.PyNode]]]): Objects to set visibility keys on.
                If None, uses current selection.
            visible (bool): Visibility state to set (True = visible, False = hidden). Default is True.
            when (str): When to set the visibility key. Options:
                - "start": At the start of each object's keyframe range
                - "end": At the end of each object's keyframe range
                - "both": At both start and end
                - "before_start": One frame before the start
                - "after_end": One frame after the end
                Default is "start".
            offset (int): Frame offset to apply to the keyframe timing. Positive values move
                keys later, negative values move keys earlier. Default is 0.
            group_overlapping (bool): If True, treats objects with overlapping keyframe ranges
                as a single group, setting visibility keys based on the group's combined range.
                Default is False.

        Returns:
            int: Number of visibility keyframes created.

        Example:
            # Hide objects at the start of their animation
            set_visibility_keys(visible=False, when="start")

            # Make objects visible at the end of their animation with 5 frame offset
            set_visibility_keys(visible=True, when="end", offset=5)

            # Set visibility for grouped overlapping animations
            set_visibility_keys(visible=True, when="both", group_overlapping=True)
        """
        # Get objects to work with
        if objects is None:
            objects = pm.selected()

        if not objects:
            pm.warning("No objects specified or selected.")
            return 0

        # Ensure we have transform nodes
        objects = pm.ls(objects, type="transform", flatten=True)

        if not objects:
            pm.warning("No valid transform nodes found.")
            return 0

        # Collect keyframe data for each object
        obj_keyframe_data = []

        for obj in objects:
            keyframes = AnimUtils.get_keyframe_times(obj)

            if keyframes:
                obj_keyframe_data.append(
                    {
                        "obj": obj,
                        "keyframes": keyframes,
                        "start": keyframes[0],
                        "end": keyframes[-1],
                        "duration": keyframes[-1] - keyframes[0],
                    }
                )

        if not obj_keyframe_data:
            pm.warning("No keyframes found on the provided objects.")
            return 0

        # Group overlapping objects if requested
        if group_overlapping:
            obj_keyframe_data = AnimUtils._group_overlapping_keyframes(
                obj_keyframe_data
            )

        # Determine visibility value (0 or 1)
        visibility_value = 1 if visible else 0

        # Set visibility keyframes based on 'when' parameter
        keys_created = 0

        for data in obj_keyframe_data:
            objects_in_group = data.get("objects", [data["obj"]])
            start_frame = data["start"]
            end_frame = data["end"]

            # Determine target frames based on 'when' parameter
            target_frames = []

            if when == "start":
                target_frames = [start_frame + offset]
            elif when == "end":
                target_frames = [end_frame + offset]
            elif when == "both":
                target_frames = [start_frame + offset, end_frame + offset]
            elif when == "before_start":
                target_frames = [start_frame - 1 + offset]
            elif when == "after_end":
                target_frames = [end_frame + 1 + offset]
            else:
                pm.warning(f"Invalid 'when' parameter: {when}. Using 'start'.")
                target_frames = [start_frame + offset]

            # Set visibility keys for each object in the group
            for obj in objects_in_group:
                for frame in target_frames:
                    pm.setKeyframe(
                        obj, attribute="visibility", time=frame, value=visibility_value
                    )
                    keys_created += 1

        pm.displayInfo(
            f"Created {keys_created} visibility keyframe(s) for {len(obj_keyframe_data)} object(s)/group(s)"
        )
        return keys_created

    @staticmethod
    @CoreUtils.undoable
    def snap_keys_to_frames(
        objects: Optional[List[Union[str, "pm.PyNode"]]] = None,
        method: str = "nearest",
        selected_only: bool = False,
        time_range: Optional[Tuple[float, float]] = None,
    ) -> int:
        """Snaps keyframes with decimal time values to whole frame numbers.

        This method rounds keyframe times to the nearest whole number, useful for cleaning up
        keyframes that have been scaled, retimed, or imported with fractional frame values.

        Parameters:
            objects (Optional[List[Union[str, pm.PyNode]]]): Objects to process keyframes for.
                If None, uses current selection.
            method (str): Rounding method to use. Options:
                - "nearest": Round to nearest whole number (default)
                - "floor": Always round down
                - "ceil": Always round up
                - "half_up": Round .5 and above up, below .5 down (standard rounding)
                - "preferred": Round to aesthetically pleasing numbers when very close (within ~1 frame).
                  Examples: 24→25, 19→20, 18→20, 99→100. Conservative approach.
                - "aggressive_preferred": Round to preferred numbers even when farther away.
                  Examples: 48.x→50, 73.x→75, 88.x→90, 23.x→25, 7.x→10. More aggressive rounding.
            selected_only (bool): If True, only snap selected keyframes. If False, snap all
                keyframes on the objects. Default is False.
            time_range (Optional[Tuple[float, float]]): (start_time, end_time) to limit which
                keyframes to snap. If None, processes all keyframes. Default is None.

        Returns:
            int: Number of keyframes that were snapped to whole frames.

        Example:
            # Snap all keyframes to nearest whole frame
            snap_keys_to_frames()

            # Snap only selected keyframes, always rounding down
            snap_keys_to_frames(method="floor", selected_only=True)

            # Snap keyframes in a specific time range
            snap_keys_to_frames(time_range=(10, 100))

            # Snap to preferred round numbers (conservative)
            snap_keys_to_frames(method="preferred")

            # Snap to preferred round numbers (aggressive)
            snap_keys_to_frames(method="aggressive_preferred")
        """
        import maya.cmds as cmds

        # Get objects to work with
        if objects is None:
            objects = cmds.ls(selection=True)
        else:
            if isinstance(objects, (str, pm.PyNode)):
                objects = [str(objects)]
            elif isinstance(objects, list):
                objects = [str(o) for o in objects]
            else:
                objects = []

        if not objects:
            pm.warning("No objects specified or selected.")
            return 0

        objects = cmds.ls(objects, flatten=True)

        # Optimization: Batch query all curves
        if selected_only:
            all_curves = (
                cmds.keyframe(objects, query=True, name=True, selected=True) or []
            )
        else:
            all_curves = (
                cmds.listConnections(
                    objects, type="animCurve", source=True, destination=False
                )
                or []
            )

        all_curves = list(set(all_curves))

        keys_snapped = 0

        for curve in all_curves:
            # Query keyframe times
            if selected_only:
                kw = {"selected": True}
            else:
                kw = {}
            if time_range:
                kw["time"] = time_range

            keyframe_times = cmds.keyframe(curve, query=True, timeChange=True, **kw)
            if not keyframe_times:
                continue

            # Collect fractional keys for this curve and snap them in one pass
            # Process in reverse time order to avoid time-shift collisions
            moves = []
            for t in keyframe_times:
                if t != int(t):
                    new_time = ptk.MathUtils.round_value(t, mode=method)
                    moves.append((t, new_time))

            if not moves:
                continue

            # Move keys in reverse order (highest time first) to avoid collisions
            moves.sort(key=lambda x: x[0], reverse=True)

            # Build a set of occupied times for collision detection.
            # Start with all whole-frame times already on the curve.
            occupied = set(t for t in keyframe_times if t == int(t))

            for old_time, new_time in moves:
                # Skip if another key already occupies the target time
                # (either an original whole-frame key or a previously
                # snapped key).  Moving would overwrite/merge and lose
                # the existing key's tangent data.
                if new_time in occupied:
                    continue

                try:
                    # Use keyframe -edit -timeChange to move in-place,
                    # preserving values and tangent data without
                    # delete+recreate overhead (~1 cmd vs ~8 cmds per key)
                    cmds.keyframe(
                        curve,
                        edit=True,
                        time=(old_time, old_time),
                        timeChange=new_time,
                    )
                    occupied.add(new_time)
                    keys_snapped += 1
                except Exception as e:
                    pm.warning(
                        f"Failed to snap keyframe on {curve} at time {old_time}: {e}"
                    )

        if keys_snapped > 0:
            pm.displayInfo(
                f"Snapped {keys_snapped} keyframe(s) to whole frames using '{method}' method"
            )
        else:
            pm.displayInfo("No keyframes with decimal values found to snap")

        return keys_snapped

    @classmethod
    @CoreUtils.undoable
    def transfer_keyframes(
        cls,
        objects: List[Union[str, object]],
        relative: bool = False,
        transfer_tangents: bool = False,
        optimize: bool = False,
    ):
        """Transfer keyframes from the first selected object to the subsequent objects.

        If keyframes are selected in the graph editor, only those keyframes and their
        associated attributes will be transferred. Otherwise, all keyframes are transferred.

        Parameters:
            objects (List[Union[str, object]]): List of objects. The first object is the source, and the rest are targets.
            relative (bool): If True, apply keyframes relative to the current values of the target objects.
            transfer_tangents (bool): If True, transfer the tangent handles along with the keyframes.
            optimize (bool): If True, run optimize_keys on the source before transferring.
        """
        resolved_objects = pm.ls(objects)
        if len(resolved_objects) < 2:
            pm.warning("Please provide at least one source and one target object.")
            return

        source_obj = resolved_objects[0]
        target_objs = resolved_objects[1:]

        if optimize:
            cls.optimize_keys([source_obj], quiet=True)

        # Check if keyframes are selected, if not use all keyframes
        selected_curves = pm.keyframe(source_obj, query=True, name=True, selected=True)

        if selected_curves:
            # Use only selected keyframes and their attributes
            keyframe_times = cls.get_keyframe_times(
                selected_curves, mode="selected", from_curves=True
            )
            keyframe_attributes = cls._curves_to_attributes(selected_curves, source_obj)
        else:
            # Use all animation curves and keyframes from the source object
            all_curves = cls.objects_to_curves([source_obj])
            if not all_curves:
                pm.warning(f"No keyframes found on source object '{source_obj}'.")
                return

            keyframe_times = cls.get_keyframe_times(all_curves, from_curves=True)
            keyframe_attributes = cls._curves_to_attributes(all_curves, source_obj)

        if not keyframe_times or not keyframe_attributes:
            pm.warning(f"No keyframes found on source object '{source_obj}'.")
            return

        # Store initial values for target objects (for relative mode)
        initial_values = {
            target: {
                attr: target.attr(attr).get()
                for attr in keyframe_attributes
                if target.hasAttr(attr)
            }
            for target in target_objs
        }

        # Copy keyframes from source to each target
        for target_obj in target_objs:
            for attr in keyframe_attributes:
                try:
                    if not target_obj.hasAttr(attr):
                        pm.warning(
                            f"Skipping attribute '{attr}': not found on '{target_obj}'."
                        )
                        continue

                    initial_value = initial_values[target_obj].get(attr)
                    if initial_value is None:
                        continue

                    # Pre-compute the relative offset once per attribute using
                    # this attribute's own first key (not the global earliest).
                    relative_offset = 0.0
                    if relative:
                        attr_first_val = pm.keyframe(
                            source_obj.attr(attr),
                            query=True,
                            time=(keyframe_times[0], keyframe_times[-1]),
                            valueChange=True,
                        )
                        if attr_first_val:
                            relative_offset = initial_value - attr_first_val[0]

                    for time in keyframe_times:
                        values = pm.keyframe(
                            source_obj.attr(attr),
                            query=True,
                            time=(time,),
                            valueChange=True,
                        )
                        if values:
                            value = values[0]
                            if relative:
                                value += relative_offset

                            pm.setKeyframe(
                                target_obj.attr(attr), time=time, value=value
                            )

                            if transfer_tangents:
                                tangent_info = cls.get_tangent_info(
                                    source_obj.attr(attr), time
                                )
                                cls.set_tangent_info(
                                    target_obj.attr(attr), time, tangent_info
                                )
                except Exception as e:
                    pm.warning(
                        f"Could not transfer attribute '{attr}' to '{target_obj}': {e}"
                    )

    @staticmethod
    def parse_time_range(
        time: Union[None, int, str, Tuple, List],
        recursive_callback: Optional[callable] = None,
    ) -> Union[Tuple[float, float], None, List]:
        """Parse time specification into a time range tuple for keyframe operations.

        This helper method handles various time specifications and converts them into
        time ranges suitable for Maya keyframe operations. It supports recursive processing
        for complex time specifications like pipe-separated strings or multi-element sequences.

        Parameters:
            time (None, int, str, tuple, list): Time specification to parse.
                Accepts:
                - None or 'all': Returns None (entire timeline)
                - int: Returns (time, time) for specific frame
                - 'current': Returns (current_time, current_time)
                - 'before': Returns (-1000000, current_time - 1)
                - 'after': Returns (current_time + 1, 1000000)
                - tuple/list of 2 elements: Returns (start, end) range
                - tuple/list of 3+ elements: Returns list for recursive processing
                - Pipe-separated strings: Returns list for recursive processing
            recursive_callback (callable, optional): Function to call for recursive processing
                of pipe-separated strings or multi-element sequences. Should accept the same
                parameters as the calling function.

        Returns:
            Union[Tuple[float, float], None, List]:
                - None: Process entire timeline
                - Tuple[float, float]: (start_time, end_time) range
                - List: Multiple time values/ranges requiring recursive processing

        Example:
            # Single frame
            time_range = parse_time_range(10)  # Returns (10, 10)

            # Current frame
            time_range = parse_time_range('current')  # Returns (current_time, current_time)

            # Before current frame
            time_range = parse_time_range('before')  # Returns (-1000000, current_time - 1)

            # Range
            time_range = parse_time_range((5, 15))  # Returns (5, 15)

            # Multiple frames (returns list for recursive processing)
            time_values = parse_time_range((1, 5, 10, 20))  # Returns [1, 5, 10, 20]

            # Pipe-separated (returns list for recursive processing)
            time_values = parse_time_range('before|current')  # Returns ['before', 'current']
        """
        # Handle pipe-separated time strings - return list for recursive processing
        if isinstance(time, str) and "|" in time:
            return [p.strip() for p in time.split("|")]

        # Handle tuples/lists with more than 2 values - return list for recursive processing
        if isinstance(time, (list, tuple)) and len(time) > 2:
            return list(time)

        # Determine time range for single time specification
        time_range = None

        if isinstance(time, str):
            time_lower = time.lower()
            current_time = pm.currentTime(query=True)

            if time_lower == "current":
                time_range = (current_time, current_time)
            elif time_lower == "before":
                # From very early time to just before current
                time_range = (-1000000, current_time - 1)
            elif time_lower == "after":
                # From just after current to very late time
                time_range = (current_time + 1, 1000000)
            elif time_lower == "all":
                time_range = None  # Process all
        elif isinstance(time, (list, tuple)) and len(time) == 2:
            time_range = (time[0], time[1])
        elif isinstance(time, int):
            time_range = (time, time)

        return time_range

    @staticmethod
    @CoreUtils.undoable
    def delete_keys(objects=None, *attributes, time=None, channel_box_only=False):
        """Deletes keyframes for specified attributes on given objects, optionally within a time range.

        This function can delete keyframes for all attributes or specified attributes, and within the entire timeline
        or a specified time range. Supports flexible time specification including single frames, ranges, and
        combinations using pipe separators or sequences.

        Parameters:
            objects (list): The list of objects from which to delete keyframes.
            *attributes (str): Variable length argument list of attribute names.
                            If empty, keyframes for all attributes will be deleted (unless channel_box_only=True).
                            Can accept a list by unpacking when calling the function using *
            time (None, int, str, tuple, list): Specifies the time range for keyframe deletion.
                    Accepts:
                    - None or 'all': Delete all keyframes (entire timeline)
                    - int: Delete keyframes at specific frame
                    - 'current': Delete keyframes at current frame
                    - 'before': Delete all keyframes before current frame (excluding current)
                    - 'after': Delete all keyframes after current frame (excluding current)
                    - Pipe-separated combinations: 'before|current', 'after|current', etc.
                    - tuple/list of 2 elements: (start, end) - Delete keyframes in range
                    - tuple/list of 3+ elements: (t1, t2, t3, ...) - Delete at each frame recursively
            channel_box_only (bool): If True, only deletes keys for attributes selected in the channel box.
                                    Ignores the *attributes parameter. Default is False.

        Notes:
            - Pipe-separated strings are processed recursively (e.g., 'before|current' deletes both ranges)
            - Tuples with more than 2 elements are processed as individual frames recursively
            - All string values are case-insensitive
            - When channel_box_only=True, no attributes are selected in channel box will result in no deletion

        Example Usage:
            delete_keys([obj1, obj2], 'translateX', 'translateY', time=10) # Delete keyframes at frame 10
            delete_keys([obj1, obj2], time='current') # Delete keyframes at current frame
            delete_keys([obj1, obj2], time='before') # Delete all keyframes before current (excluding current)
            delete_keys([obj1, obj2], time='after') # Delete all keyframes after current (excluding current)
            delete_keys([obj1, obj2], time='before|current') # Delete up to and including current
            delete_keys([obj1, obj2], time='after|current') # Delete from and after current
            delete_keys([obj1, obj2], time='before|current|after') # Delete all keyframes (equivalent to 'all')
            delete_keys([obj1, obj2], time=(5, 15)) # Delete all keyframes between frames 5 and 15
            delete_keys([obj1, obj2], time=(1, 5, 10, 20)) # Delete keyframes at frames 1, 5, 10, and 20
            delete_keys([obj1, obj2], 'rotateX', 'rotateY') # Delete all keyframes for specified attributes
            delete_keys([obj1, obj2], channel_box_only=True) # Delete only for channel box selected attributes
        """
        if objects is None:
            objects = pm.selected()

        objects = pm.ls(objects, flatten=True)

        if not objects:
            pm.warning("No objects specified or selected.")
            return

        # Handle channel box filtering
        if channel_box_only:
            cb_attrs = pm.channelBox(
                "mainChannelBox", query=True, selectedMainAttributes=True
            )
            if not cb_attrs:
                pm.warning("No attributes selected in channel box.")
                return
            # Override attributes with channel box selection
            attributes = cb_attrs

        # Parse time range using helper method
        time_range = AnimUtils.parse_time_range(time)

        # Handle recursive cases (pipe-separated or multi-element sequences)
        if isinstance(time_range, list):
            for t in time_range:
                AnimUtils.delete_keys(
                    objects, *attributes, time=t, channel_box_only=False
                )
            return

        # Optimized: batch cutKey operations
        if attributes:
            # Build list of attribute plugs for all objects
            attr_plugs = [f"{obj}.{attr}" for obj in objects for attr in attributes]
            if attr_plugs:
                if time_range:
                    pm.cutKey(attr_plugs, time=time_range, clear=True)
                else:
                    pm.cutKey(attr_plugs, clear=True)
        else:
            # Delete keyframes for all attributes - pass all objects at once
            if time_range:
                pm.cutKey(objects, time=time_range, clear=True)
            else:
                pm.cutKey(objects, clear=True)

    @staticmethod
    def select_keys(
        objects: Optional[List[Union[str, "pm.PyNode"]]] = None,
        *attributes: str,
        time: Union[None, int, str, Tuple, List] = None,
        channel_box_only: bool = False,
        add_to_selection: bool = False,
    ) -> int:
        """Selects keyframes for specified attributes on given objects, optionally within a time range.

        This function selects keyframes for all attributes or specified attributes, and within the entire timeline
        or a specified time range. Supports flexible time specification including single frames, ranges, and
        combinations using pipe separators or sequences.

        Parameters:
            objects (list, optional): The list of objects from which to select keyframes. If None, uses selection.
            *attributes (str): Variable length argument list of attribute names.
                            If empty, keyframes for all attributes will be selected (unless channel_box_only=True).
                            Can accept a list by unpacking when calling the function using *
            time (None, int, str, tuple, list): Specifies the time range for keyframe selection.
                    Accepts:
                    - None or 'all': Select all keyframes (entire timeline)
                    - int: Select keyframes at specific frame
                    - 'current': Select keyframes at current frame
                    - 'before': Select all keyframes before current frame (excluding current)
                    - 'after': Select all keyframes after current frame (excluding current)
                    - Pipe-separated combinations: 'before|current', 'after|current', etc.
                    - tuple/list of 2 elements: (start, end) - Select keyframes in range
                    - tuple/list of 3+ elements: (t1, t2, t3, ...) - Select at each frame recursively
            channel_box_only (bool): If True, only selects keys for attributes selected in the channel box.
                                    Ignores the *attributes parameter. Default is False.
            add_to_selection (bool): If True, adds to existing keyframe selection. If False, replaces selection.
                                    Default is False.

        Returns:
            int: Number of keyframes selected.

        Notes:
            - Pipe-separated strings are processed recursively (e.g., 'before|current' selects both ranges)
            - Tuples with more than 2 elements are processed as individual frames recursively
            - All string values are case-insensitive
            - When channel_box_only=True, no attributes selected in channel box will result in no selection

        Example Usage:
            select_keys([obj1, obj2], 'translateX', 'translateY', time=10) # Select keyframes at frame 10
            select_keys([obj1, obj2], time='current') # Select keyframes at current frame
            select_keys([obj1, obj2], time='before') # Select all keyframes before current (excluding current)
            select_keys([obj1, obj2], time='after') # Select all keyframes after current (excluding current)
            select_keys([obj1, obj2], time='before|current') # Select up to and including current
            select_keys([obj1, obj2], time='after|current') # Select from and after current
            select_keys([obj1, obj2], time='before|current|after') # Select all keyframes (equivalent to 'all')
            select_keys([obj1, obj2], time=(5, 15)) # Select all keyframes between frames 5 and 15
            select_keys([obj1, obj2], time=(1, 5, 10, 20)) # Select keyframes at frames 1, 5, 10, and 20
            select_keys([obj1, obj2], 'rotateX', 'rotateY') # Select all keyframes for specified attributes
            select_keys([obj1, obj2], channel_box_only=True) # Select only for channel box selected attributes
            select_keys([obj1, obj2], time='current', add_to_selection=True) # Add current frame keys to selection
        """
        if objects is None:
            objects = pm.selected()

        objects = pm.ls(objects, flatten=True)

        if not objects:
            pm.warning("No objects specified or selected.")
            return 0

        # Handle channel box filtering
        if channel_box_only:
            cb_attrs = pm.channelBox(
                "mainChannelBox", query=True, selectedMainAttributes=True
            )
            if not cb_attrs:
                pm.warning("No attributes selected in channel box.")
                return 0
            # Override attributes with channel box selection
            attributes = cb_attrs

        # Parse time range using helper method
        time_range = AnimUtils.parse_time_range(time)

        # Handle recursive cases (pipe-separated or multi-element sequences)
        if isinstance(time_range, list):
            total_selected = 0
            for i, t in enumerate(time_range):
                # Only replace selection on first iteration, add to selection afterward
                add = add_to_selection or (i > 0)
                count = AnimUtils.select_keys(
                    objects,
                    *attributes,
                    time=t,
                    channel_box_only=False,
                    add_to_selection=add,
                )
                total_selected += count
            return total_selected

        # Clear selection if not adding to it
        if not add_to_selection:
            pm.selectKey(clear=True)

        keys_selected = 0

        for obj in objects:
            if attributes:  # Select keyframes for specified attributes
                for attr in attributes:
                    if time_range:
                        pm.selectKey(f"{obj}.{attr}", time=time_range, add=True)
                        # Count selected keys
                        selected = pm.keyframe(
                            f"{obj}.{attr}", query=True, selected=True, timeChange=True
                        )
                        if selected:
                            keys_selected += len(selected)
                    else:
                        pm.selectKey(f"{obj}.{attr}", add=True)
                        # Count selected keys
                        selected = pm.keyframe(
                            f"{obj}.{attr}", query=True, selected=True, timeChange=True
                        )
                        if selected:
                            keys_selected += len(selected)
            else:  # Select keyframes for all attributes
                if time_range:
                    pm.selectKey(obj, time=time_range, add=True)
                    # Count selected keys
                    selected = pm.keyframe(
                        obj, query=True, selected=True, timeChange=True
                    )
                    if selected:
                        keys_selected += len(selected)
                else:
                    pm.selectKey(obj, add=True)
                    # Count selected keys
                    selected = pm.keyframe(
                        obj, query=True, selected=True, timeChange=True
                    )
                    if selected:
                        keys_selected += len(selected)

        return keys_selected

    @staticmethod
    def get_frame_ranges(
        objects: List[str],
        precision: Optional[int] = None,
        gap: Optional[int] = None,
    ) -> Dict[str, List[Tuple[int, int]]]:
        """Calculate frame ranges for a list of objects based on their keyframes.

        This method analyzes the keyframes of given objects and determines continuous
        frame ranges. It supports optional rounding of frame numbers to a specified precision
        and allows for specifying a gap threshold to split ranges.

        Parameters:
            objects (List[str]): List of object names to analyze.
            precision (Optional[int]): Precision for rounding frame numbers. If provided,
                                    frame numbers will be rounded to the nearest multiple
                                    of this value.
            gap (Optional[int]): Maximum allowed gap between consecutive keyframes in a
                                range. If the gap between two consecutive keyframes exceeds
                                this value, a new range will be started.
        Returns:
            Dict[str, List[Tuple[int, int]]]: Dictionary mapping object names to lists of
                                            frame ranges. Each frame range is represented
                                            as a tuple (start_frame, end_frame). If an
                                            object has no keyframes, the range will be
                                            [(None, None)].
        """

        def round_to_nearest(value: float, base: int) -> int:
            return int(base * round(value / base))

        frame_ranges = {}
        for obj in objects:
            keyframes = AnimUtils.get_keyframe_times(obj)
            if keyframes:
                ranges = []
                start_frame = keyframes[0]
                last_frame = keyframes[0]

                for kf in keyframes[1:]:
                    if gap is not None and kf - last_frame > gap:
                        end_frame = last_frame
                        if precision:
                            start_frame = round_to_nearest(start_frame, precision)
                            end_frame = round_to_nearest(end_frame, precision)
                        ranges.append((start_frame, end_frame))
                        start_frame = kf
                    last_frame = kf

                end_frame = last_frame
                if precision is not None:
                    start_frame = round_to_nearest(start_frame, precision)
                    end_frame = round_to_nearest(end_frame, precision)
                ranges.append((start_frame, end_frame))

                frame_ranges[obj] = ranges
            else:
                frame_ranges[obj] = [(None, None)]  # No keyframes, no range

        return frame_ranges

    @staticmethod
    def get_tied_keyframes(
        objects: Optional[List["pm.PyNode"]] = None,
        tolerance: float = 1e-5,
    ) -> Dict["pm.PyNode", Dict[str, List[float]]]:
        """Detects tied (bookend) keyframes for given objects.

        A tied keyframe is identified as a keyframe at the start or end of an attribute's
        keyframe range that has the same value as the adjacent keyframe, indicating it's
        likely a hold/bookend key rather than actual animation.

        This is useful for:
        - Identifying keys added by tie_keyframes()
        - Filtering out bookend keys from operations
        - Validating animation data

        Parameters:
            objects (Optional[List[pm.PyNode]]): Objects to check for tied keyframes.
                If None, checks all keyed objects in the scene.
            tolerance (float): Tolerance for comparing keyframe values. Two values are
                considered the same if their difference is less than this value.
                Default is 1e-5.

        Returns:
            Dict[pm.PyNode, Dict[str, List[float]]]: Dictionary mapping objects to their
                tied keyframes. For each object, maps attribute names (curve names) to
                lists of tied keyframe times.

        Example:
            # Get all tied keyframes in the scene
            tied_keys = AnimUtils.get_tied_keyframes()
            # Returns: {obj1: {'pCube1_translateX': [1.0, 100.0]}, obj2: {...}}

            # Get tied keyframes for selected objects
            tied_keys = AnimUtils.get_tied_keyframes(pm.selected())

            # Check if a specific object has tied keyframes
            tied_keys = AnimUtils.get_tied_keyframes([my_obj])
            if my_obj in tied_keys:
                print(f"Object has tied keys: {tied_keys[my_obj]}")
        """
        import maya.cmds as cmds

        # Get objects to check
        if objects is None:
            objects = cmds.ls(type="transform")
            # Filter objects that have keyframes
            objects = [
                obj
                for obj in objects
                if cmds.keyframe(obj, query=True, timeChange=True)
            ]
        else:
            if isinstance(objects, (str, pm.PyNode)):
                objects = [str(objects)]
            elif isinstance(objects, list):
                objects = [str(o) for o in objects]
            else:
                objects = []

        if not objects:
            return {}

        tied_keyframes = {}

        for obj in objects:
            # Get all animation curves for this object
            keyed_attrs = cmds.keyframe(obj, query=True, name=True)

            if not keyed_attrs:
                continue

            obj_tied_keys = {}

            for attr in keyed_attrs:
                # Get all keyframe times for this attribute
                keyframe_times = cmds.keyframe(attr, query=True, timeChange=True)

                if not keyframe_times or len(keyframe_times) < 2:
                    continue  # Need at least 2 keys to have potential ties

                keyframe_times = sorted(keyframe_times)
                tied_times = []

                # Check start keyframe - is it a tie (same value as next key)?
                if len(keyframe_times) > 1:
                    start_value = cmds.keyframe(
                        attr,
                        query=True,
                        time=(keyframe_times[0],),
                        valueChange=True,
                    )[0]
                    next_value = cmds.keyframe(
                        attr,
                        query=True,
                        time=(keyframe_times[1],),
                        valueChange=True,
                    )[0]

                    # If values are the same, this is a tied keyframe
                    if abs(start_value - next_value) < tolerance:
                        tied_times.append(keyframe_times[0])

                # Check end keyframe - is it a tie (same value as previous key)?
                if len(keyframe_times) > 1:
                    end_value = cmds.keyframe(
                        attr,
                        query=True,
                        time=(keyframe_times[-1],),
                        valueChange=True,
                    )[0]
                    prev_value = cmds.keyframe(
                        attr,
                        query=True,
                        time=(keyframe_times[-2],),
                        valueChange=True,
                    )[0]

                    # If values are the same, this is a tied keyframe
                    if abs(end_value - prev_value) < tolerance:
                        tied_times.append(keyframe_times[-1])

                # Store tied keyframes for this attribute if any were found
                if tied_times:
                    obj_tied_keys[attr] = tied_times

            # Store object's tied keyframes if any were found
            if obj_tied_keys:
                tied_keyframes[pm.PyNode(obj)] = obj_tied_keys

        return tied_keyframes

    @staticmethod
    @CoreUtils.undoable
    def tie_keyframes(
        objects: List["pm.nt.Transform"] = None,
        absolute: bool = False,
        padding: int = 0,
        custom_range: Optional[Tuple[float, float]] = None,
    ):
        """Ties the keyframes of all given objects (or all keyed objects in the scene if none are provided)
        by setting keyframes only on the attributes that already have keyframes,
        at the start and end of the specified animation range.

        Uses OpenMaya 2.0 (MFnAnimCurve) to freeze auto tangents on adjacent
        keys BEFORE inserting bookend keys, preventing Maya from recalculating
        them.  This eliminates the need for post-insertion tangent restoration
        and is O(curves) with only fast C++ calls per curve.

        Parameters:
            objects (List[pm.nt.Transform], optional): List of PyMel transform nodes to process.
                If None, all keyed objects in the scene will be used.
            absolute (bool, optional): If True, uses the absolute start and end keyframes
                across all objects as the range. If False, uses the scene's playback range. Default is False.
            padding (int, optional): Number of frames to extend the tie keyframes beyond the range.
                Positive values add padding (e.g., 5 = tie 5 frames before start and 5 frames after end).
                Negative values shrink the range inward. Default is 0.
            custom_range (Tuple[float, float], optional): Explicit (start, end) range to use.
                If provided, overrides absolute and scene range settings.

        Example:
            # Tie keyframes at the exact playback range (e.g., 10-100)
            tie_keyframes()  # Ties at 10 and 100

            # Add 5 frames of padding on both ends
            tie_keyframes(padding=5)  # Ties at 5 and 105 (if playback is 10-100)

            # Use with absolute=True to add padding around actual keyframes
            tie_keyframes(absolute=True, padding=10)  # Adds 10 frame hold before/after animation
        """
        import maya.cmds as cmds
        import maya.api.OpenMaya as om2
        import maya.api.OpenMayaAnim as oma2

        if objects is None:  # Get all objects that have keyframes
            objects = cmds.ls(type="transform")
            objects = [
                obj
                for obj in objects
                if cmds.keyframe(obj, query=True, timeChange=True)
            ]
        else:
            if isinstance(objects, (str, pm.PyNode)):
                objects = [str(objects)]
            elif isinstance(objects, list):
                objects = [str(o) for o in objects]
            else:
                objects = []

        if not objects:
            pm.warning("No keyed objects found.")
            return

        # Determine the keyframe range
        if custom_range:
            start_frame, end_frame = custom_range
        elif absolute:
            range_result = AnimUtils.get_keyframe_times(objects, as_range=True)
            if range_result is None:
                pm.warning("No keyframes found on any objects.")
                return
            start_frame, end_frame = range_result
        else:
            start_frame = cmds.playbackOptions(query=True, minTime=True)
            end_frame = cmds.playbackOptions(query=True, maxTime=True)

        tie_start_frame = start_frame - padding
        tie_end_frame = end_frame + padding

        # Collect unique animation curves
        all_keyed_curves = list(
            set(
                cmds.listConnections(
                    objects, type="animCurve", source=True, destination=False
                )
                or []
            )
        )

        if not all_keyed_curves:
            pm.displayInfo(
                f"Keyframes tied to frames {tie_start_frame} and {tie_end_frame} for keyed attributes."
            )
            return

        # Tangent type constants
        kStep = oma2.MFnAnimCurve.kTangentStep
        kStepNext = oma2.MFnAnimCurve.kTangentStepNext
        kFlat = oma2.MFnAnimCurve.kTangentFlat
        kFixed = oma2.MFnAnimCurve.kTangentFixed
        _step_types = {kStep, kStepNext}
        _auto_types = {
            oma2.MFnAnimCurve.kTangentAuto,
            oma2.MFnAnimCurve.kTangentSmooth,
            oma2.MFnAnimCurve.kTangentClamped,
        }

        start_mtime = om2.MTime(tie_start_frame, om2.MTime.uiUnit())
        end_mtime = om2.MTime(tie_end_frame, om2.MTime.uiUnit())

        # Build MSelectionList for all curves at once
        sel = om2.MSelectionList()
        for curve_name in all_keyed_curves:
            try:
                sel.add(curve_name)
            except RuntimeError:
                continue  # Curve may have been deleted

        for i in range(sel.length()):
            dep = sel.getDependNode(i)
            fn = oma2.MFnAnimCurve(dep)
            n = fn.numKeys
            if n == 0:
                continue

            first_t = fn.input(0).value
            last_t = fn.input(n - 1).value

            # Determine if curve is fully stepped (early-exit check)
            is_fully_stepped = True
            for ki in range(n):
                if fn.outTangentType(ki) not in _step_types:
                    is_fully_stepped = False
                    break

            bookend_tt = kStep if is_fully_stepped else kFlat

            # --- Start bookend ---
            if abs(tie_start_frame - first_t) < 1e-4:
                # Bookend overlaps first key — skip to avoid corrupting it
                pass
            else:
                if tie_start_frame < first_t:
                    # Bookend is BEFORE the curve range.
                    # Freeze first key's auto tangents before inserting.
                    if not is_fully_stepped:
                        _freeze_adjacent_tangent(
                            fn,
                            0,
                            is_in=True,
                            bookend_facing=True,
                            auto_types=_auto_types,
                            step_types=_step_types,
                        )
                        _freeze_adjacent_tangent(
                            fn,
                            0,
                            is_in=False,
                            bookend_facing=False,
                            auto_types=_auto_types,
                            step_types=_step_types,
                        )
                else:
                    # Bookend is INSIDE the curve range — freeze neighbors.
                    if not is_fully_stepped:
                        adj_idx = _find_adjacent_key(fn, tie_start_frame, n)
                        if adj_idx is not None:
                            # Key after insertion: freeze its in-tangent
                            _freeze_adjacent_tangent(
                                fn,
                                adj_idx,
                                is_in=True,
                                bookend_facing=False,
                                auto_types=_auto_types,
                                step_types=_step_types,
                            )
                            # Key before insertion: freeze its out-tangent
                            if adj_idx > 0:
                                _freeze_adjacent_tangent(
                                    fn,
                                    adj_idx - 1,
                                    is_in=False,
                                    bookend_facing=False,
                                    auto_types=_auto_types,
                                    step_types=_step_types,
                                )

                # Evaluate curve value at the bookend time and insert
                start_val = fn.evaluate(start_mtime)
                fn.addKey(start_mtime, start_val, bookend_tt, bookend_tt)

            # --- End bookend ---
            # Re-read numKeys since we may have added a key
            n = fn.numKeys
            # Re-read last_t from the actual last key
            last_t = fn.input(n - 1).value

            if abs(tie_end_frame - last_t) < 1e-4:
                # Bookend overlaps last key — skip
                pass
            else:
                if tie_end_frame > last_t:
                    # Bookend is AFTER the curve range.
                    last_idx = n - 1
                    if not is_fully_stepped:
                        _freeze_adjacent_tangent(
                            fn,
                            last_idx,
                            is_in=False,
                            bookend_facing=True,
                            auto_types=_auto_types,
                            step_types=_step_types,
                        )
                        _freeze_adjacent_tangent(
                            fn,
                            last_idx,
                            is_in=True,
                            bookend_facing=False,
                            auto_types=_auto_types,
                            step_types=_step_types,
                        )
                else:
                    # Bookend is INSIDE the curve range — freeze neighbors.
                    if not is_fully_stepped:
                        adj_idx = _find_adjacent_key(fn, tie_end_frame, n)
                        if adj_idx is not None:
                            _freeze_adjacent_tangent(
                                fn,
                                adj_idx,
                                is_in=True,
                                bookend_facing=False,
                                auto_types=_auto_types,
                                step_types=_step_types,
                            )
                            if adj_idx > 0:
                                _freeze_adjacent_tangent(
                                    fn,
                                    adj_idx - 1,
                                    is_in=False,
                                    bookend_facing=False,
                                    auto_types=_auto_types,
                                    step_types=_step_types,
                                )

                end_val = fn.evaluate(end_mtime)
                fn.addKey(end_mtime, end_val, bookend_tt, bookend_tt)

        pm.displayInfo(
            f"Keyframes tied to frames {tie_start_frame} and {tie_end_frame} for keyed attributes."
        )

    @staticmethod
    @CoreUtils.undoable
    def untie_keyframes(
        objects: List["pm.nt.Transform"] = None,
        absolute: bool = False,
    ):
        """Removes bookend keyframes added by tie_keyframes, but preserves genuine animation keys.

        This method intelligently removes keyframes at the start and end of each attribute's
        keyframe range that were likely added by tie_keyframes. It automatically detects
        bookend keys by checking if the first/last keyframe has the same value as the
        next/previous keyframe (indicating a hold rather than actual animation).

        Parameters:
            objects (List[pm.nt.Transform], optional): List of PyMel transform nodes to process.
                If None, all keyed objects in the scene will be used.
            absolute (bool, optional): Reserved for future use. Currently not used as untie
                automatically detects bookend keys per attribute.

        Example:
            # Remove bookend keys added by tie_keyframes
            untie_keyframes()

            # Remove bookend keys for specific objects
            untie_keyframes([obj1, obj2])
        """
        # Use the helper method to detect tied keyframes
        tied_keyframes = AnimUtils.get_tied_keyframes(objects)

        if not tied_keyframes:
            pm.displayInfo("No bookend keyframes found to remove.")
            return

        keys_removed = 0

        # Remove all detected tied keyframes
        for obj, attr_dict in tied_keyframes.items():
            for attr, tied_times in attr_dict.items():
                for time in tied_times:
                    pm.cutKey(attr, time=(time, time), clear=True)
                    keys_removed += 1

        if keys_removed > 0:
            pm.displayInfo(f"Removed {keys_removed} bookend keyframe(s).")
        else:
            pm.displayInfo("No bookend keyframes found to remove.")

    @staticmethod
    def create_animation_layer(
        name: str = "AnimLayer",
        override: bool = True,
        additive: bool = False,
        attributes: Optional[List[str]] = None,
        objects: Optional[List[str]] = None,
        weight: float = 1.0,
        mute: bool = False,
        solo: bool = False,
        lock: bool = False,
        preferred: bool = True,
        parent: Optional[str] = None,
        unique_name: bool = True,
        timestamp_suffix: bool = False,
        color: Optional[Tuple[float, float, float]] = None,
    ) -> str:
        """Create an animation layer with flexible configuration options.

        Creates a new animation layer and optionally adds attributes/objects to it.
        Handles unique naming, hierarchy, and layer properties.

        Parameters:
            name: Base name for the layer. Will be made unique if unique_name=True.
            override: If True, creates an override layer (replaces base animation).
                If False, creates an additive layer (adds to base animation).
            additive: Explicit additive mode. If True, sets override=False.
            attributes: List of attribute paths (e.g., ["pCube1.tx", "pCube1.ry"])
                to add to the layer. These attributes will be animatable on this layer.
            objects: List of objects to add all keyable attributes from.
                Shorthand for adding all keyable attrs of each object.
            weight: Layer weight (0.0 to 1.0). Default is 1.0 (full influence).
            mute: If True, mute the layer (disable its effect).
            solo: If True, solo the layer (only this layer affects playback).
            lock: If True, lock the layer (prevent editing).
            preferred: If True, set as the preferred/selected layer for editing.
            parent: Name of parent layer. If None, uses the root (BaseAnimation).
            unique_name: If True, ensures layer name is unique by appending
                a counter if necessary (e.g., "MyLayer", "MyLayer_1", "MyLayer_2").
            timestamp_suffix: If True, appends timestamp to name for uniqueness
                (e.g., "MyLayer_20260203_143052"). Overrides unique_name counter.
            color: Optional RGB tuple (0-1 range) for layer display color in editor.

        Returns:
            The actual name of the created layer (may differ from input if
            unique_name=True and name collision occurred).

        Raises:
            RuntimeError: If layer creation fails.

        Example:
            >>> # Simple override layer
            >>> layer = AnimUtils.create_animation_layer("BakeLayer", override=True)

            >>> # Additive layer with specific attributes
            >>> layer = AnimUtils.create_animation_layer(
            ...     "Offset",
            ...     additive=True,
            ...     attributes=["pCube1.translateY", "pCube1.rotateZ"],
            ...     weight=0.5,
            ... )

            >>> # Layer for multiple objects
            >>> layer = AnimUtils.create_animation_layer(
            ...     "CharacterLayer",
            ...     objects=["joint1", "joint2", "joint3"],
            ...     timestamp_suffix=True,
            ... )

            >>> # Muted layer for comparison
            >>> layer = AnimUtils.create_animation_layer(
            ...     "Alternate", mute=True, preferred=False
            ... )
        """
        import maya.cmds as cmds
        import time as time_module

        # Handle additive shorthand
        if additive:
            override = False

        # Build unique layer name
        layer_name = name
        if timestamp_suffix:
            timestamp = time_module.strftime("%Y%m%d_%H%M%S")
            layer_name = f"{name}_{timestamp}"

        if unique_name:
            base_name = layer_name
            counter = 1
            while cmds.objExists(layer_name):
                layer_name = f"{base_name}_{counter}"
                counter += 1

        # Create the layer
        layer = cmds.animLayer(layer_name, override=override)

        # Set layer properties
        if weight != 1.0:
            cmds.animLayer(layer, edit=True, weight=weight)

        if mute:
            cmds.animLayer(layer, edit=True, mute=True)

        if solo:
            cmds.animLayer(layer, edit=True, solo=True)

        if lock:
            cmds.animLayer(layer, edit=True, lock=True)

        if preferred:
            cmds.animLayer(layer, edit=True, preferred=True)

        if parent:
            cmds.animLayer(layer, edit=True, parent=parent)

        if color:
            try:
                cmds.animLayer(layer, edit=True, override=override)
                # Note: animLayer doesn't directly support color, but we can
                # set it via the node's attribute if it exists
                if cmds.attributeQuery("ghostColor", node=layer, exists=True):
                    cmds.setAttr(f"{layer}.ghostColor", *color, type="float3")
            except RuntimeError:
                pass  # Color setting may not be supported

        # Add attributes from objects (all keyable attributes)
        if objects:
            for obj in objects:
                if not cmds.objExists(obj):
                    continue
                keyable_attrs = cmds.listAttr(obj, keyable=True) or []
                for attr in keyable_attrs:
                    attr_path = f"{obj}.{attr}"
                    try:
                        cmds.animLayer(layer, edit=True, attribute=attr_path)
                    except RuntimeError:
                        pass  # Attribute may not be animatable

        # Add explicit attributes
        if attributes:
            for attr_path in attributes:
                try:
                    cmds.animLayer(layer, edit=True, attribute=attr_path)
                except RuntimeError:
                    pass  # Attribute may not exist or not be animatable

        return layer

    @staticmethod
    def get_animation_layers(
        include_base: bool = False,
        muted_only: bool = False,
        active_only: bool = False,
    ) -> List[str]:
        """Get all animation layers in the scene.

        Parameters:
            include_base: If True, includes the BaseAnimation layer.
            muted_only: If True, returns only muted layers.
            active_only: If True, returns only non-muted layers.

        Returns:
            List of animation layer names.
        """
        import maya.cmds as cmds

        layers = cmds.ls(type="animLayer") or []

        if not include_base:
            layers = [l for l in layers if l != "BaseAnimation"]

        if muted_only:
            layers = [l for l in layers if cmds.animLayer(l, query=True, mute=True)]
        elif active_only:
            layers = [l for l in layers if not cmds.animLayer(l, query=True, mute=True)]

        return layers

    @staticmethod
    def copy_keys(
        objects=None,
        mode: str = "auto",
        resolution_order: Optional[Tuple[str, ...]] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """Copy attribute values from objects for later pasting as keys.

        Parameters:
            objects: Objects to copy from. Defaults to selection.
            mode: Copy mode — one of:
                - ``"auto"`` (default): Smart cascade via
                  :meth:`_resolve_keys` — uses selected keys if any
                  (narrowed to Channel Box highlights when they overlap,
                  otherwise all selected keys are used), falls back to
                  Channel Box values, then to all keyed attributes at
                  the current frame.
                - ``"current_frame"``: Copy all keyed attribute values at the
                  current time for each object.
                - ``"selected"``: Copy values of keys currently selected in the
                  Graph Editor.
                - ``"channel_box"``: Copy values of attributes highlighted in
                  the Channel Box.
            resolution_order: Strategies to try for ``"auto"`` mode.
                Default: ``("selected", "channel_box", "current_frame")``.
                See :meth:`_resolve_keys` for available strategies.

        Returns:
            Nested dict ``{object_name: {attr: data, ...}, ...}``.

            For ``"current_frame"`` and ``"channel_box"`` modes, *data* is a
            single ``float``.

            For ``"selected"`` mode, *data* is a list of key dicts::

                [{"time": float, "value": float,
                  "inTangentType": str, "outTangentType": str}, ...]

            Empty dict when nothing could be copied.
        """
        import maya.cmds as cmds

        if objects is None:
            objects = pm.selected()
        objects = pm.ls(objects, flatten=True)
        if not objects:
            pm.warning("No objects specified or selected.")
            return {}

        # Resolve "auto" into the best concrete mode, with optional CB filter.
        # Pass pre-resolved *objects* so _resolve_keys skips redundant pm.ls.
        cb_filter: Optional[Set[str]] = None
        if mode == "auto":
            resolved = AnimUtils._resolve_keys(
                objects,
                mode="auto",
                resolution_order=resolution_order
                or ("selected", "channel_box", "current_frame"),
            )
            mode = resolved["mode"]
            cb_filter = resolved["cb_attrs"]

        result: Dict[str, Dict[str, float]] = {}

        if mode == "current_frame":
            current = cmds.currentTime(query=True)
            for obj in objects:
                curves = cmds.listConnections(str(obj), type="animCurve") or []
                if not curves:
                    continue
                obj_data: Dict[str, float] = {}
                for crv in curves:
                    # Get the attribute this curve drives
                    conns = (
                        cmds.listConnections(crv, destination=True, plugs=True) or []
                    )
                    for plug in conns:
                        attr = plug.split(".")[-1]
                        val = cmds.getAttr(f"{obj}.{attr}", time=current)
                        obj_data[attr] = val
                if obj_data:
                    result[str(obj)] = obj_data

        elif mode == "selected":
            # Get curves with selected keys
            sel_curves = cmds.keyframe(query=True, selected=True, name=True) or []
            if not sel_curves:
                pm.warning("No keys selected in the Graph Editor.")
                return {}

            def _collect_selected_keys(curves, attr_filter):
                """Collect key data from *curves*, optionally filtering by attrs."""
                collected: Dict[str, Dict[str, Any]] = {}
                for crv in curves:
                    conns = (
                        cmds.listConnections(crv, destination=True, plugs=True) or []
                    )
                    if not conns:
                        continue
                    plug = conns[0]
                    parts = plug.split(".", 1)
                    obj_name = parts[0]
                    attr = parts[1] if len(parts) > 1 else ""
                    if not attr:
                        continue
                    if attr_filter is not None and attr.lower() not in attr_filter:
                        continue
                    times = (
                        cmds.keyframe(crv, query=True, selected=True, timeChange=True)
                        or []
                    )
                    values = (
                        cmds.keyframe(crv, query=True, selected=True, valueChange=True)
                        or []
                    )
                    if times and values:
                        key_list = []
                        for t, v in zip(times, values):
                            itt = cmds.keyTangent(
                                crv, q=True, time=(t, t), inTangentType=True
                            )
                            ott = cmds.keyTangent(
                                crv, q=True, time=(t, t), outTangentType=True
                            )
                            key_list.append(
                                {
                                    "time": t,
                                    "value": v,
                                    "inTangentType": itt[0] if itt else "auto",
                                    "outTangentType": ott[0] if ott else "auto",
                                }
                            )
                        collected.setdefault(obj_name, {})[attr] = key_list
                return collected

            result = _collect_selected_keys(sel_curves, cb_filter)
            # If the CB filter eliminated everything, fall back to all
            # selected keys so the user isn't silently blocked.
            if not result and cb_filter is not None:
                result = _collect_selected_keys(sel_curves, None)

        else:  # channel_box (default)
            channel_box = pm.melGlobals["gChannelBoxName"]
            for obj in objects:
                attrs = pm.channelBox(channel_box, query=True, sma=True) or []
                if not attrs:
                    continue
                obj_data = {}
                for attr in attrs:
                    try:
                        obj_data[attr] = pm.getAttr(f"{obj}.{attr}")
                    except Exception:
                        pass
                if obj_data:
                    result[str(obj)] = obj_data

        return result

    @staticmethod
    @CoreUtils.undoable
    def paste_keys(
        objects=None,
        copied_data: Optional[Dict[str, Dict[str, Any]]] = None,
        target_time=None,
        match_source: bool = True,
        refresh_channel_box: bool = True,
        **kwargs,
    ) -> int:
        """Paste previously copied attribute values as keyframes.

        Supports two data formats produced by :meth:`copy_keys`:

        * **Scalar** (``current_frame`` / ``channel_box``): a single float
          per attribute is keyed at *target_time*.
        * **Multi-key** (``selected``): a list of key dicts with time,
          value and tangent types.  Keys are offset so the earliest
          copied time aligns with *target_time* and tangent types are
          applied exactly as stored.

        Parameters:
            objects: Objects to paste onto. Defaults to selection.
            copied_data: Nested dict from :meth:`copy_keys`.
            target_time: Frame at which to paste.  Defaults to current time.
                For multi-key data the earliest copied key aligns here;
                later keys are offset accordingly.
            match_source: When True (default), each target object is
                matched to its corresponding source entry in *copied_data*
                by name.  When False, all attribute data from every source
                in *copied_data* is merged and applied to each target
                object — useful for pasting one object's animation onto
                a different object.
            refresh_channel_box: Update the Channel Box after keying.
            **kwargs: Extra flags forwarded to ``pm.setKeyframe``
                (e.g. ``breakdown``, ``hierarchy``, ``shape``,
                ``controlPoints``, ``animLayer``).

        Returns:
            Number of objects that received keys.
        """
        import maya.cmds as cmds

        if not copied_data:
            pm.warning("No copied data to paste.")
            return 0

        if objects is None:
            objects = pm.selected()
        objects = pm.ls(objects, flatten=True)
        if not objects:
            pm.warning("No objects specified or selected.")
            return 0

        if target_time is None:
            target_time = pm.currentTime(query=True)

        # When not matching by name, merge all source attrs into one dict
        merged_attrs: Optional[Dict[str, Any]] = None
        if not match_source:
            merged_attrs = {}
            for src_attrs in copied_data.values():
                merged_attrs.update(src_attrs)

        keys_set = 0

        for obj in objects:
            if not match_source:
                obj_attrs = merged_attrs
            else:
                obj_name = str(obj)
                short_name = obj.nodeName()

                # Try to find matching stored data
                obj_attrs = copied_data.get(obj_name)
                if not obj_attrs:
                    obj_attrs = copied_data.get(short_name)
                if not obj_attrs:
                    for stored_name in copied_data:
                        if stored_name.split("|")[-1] == short_name:
                            obj_attrs = copied_data[stored_name]
                            break

            if obj_attrs:
                for attr, data in obj_attrs.items():
                    plug = f"{obj}.{attr}"
                    if isinstance(data, list):
                        # --- Multi-key paste (selected mode) ---
                        if not data:
                            continue
                        base_time = data[0]["time"]
                        offset = float(target_time) - base_time
                        # Types that Maya only accepts as outTangentType.
                        # Map them to a sensible in-tangent equivalent.
                        _IN_TANGENT_REMAP = {"step": "stepnext", "fixed": "auto"}

                        for kd in data:
                            t = kd["time"] + offset
                            v = kd["value"]
                            itt = kd.get("inTangentType", "auto")
                            ott = kd.get("outTangentType", "auto")
                            itt = _IN_TANGENT_REMAP.get(itt, itt)
                            kw = dict(
                                time=t,
                                value=v,
                                inTangentType=itt,
                                outTangentType=ott,
                            )
                            kw.update(kwargs)
                            pm.setKeyframe(plug, **kw)
                            # Belt-and-suspenders: re-apply tangent
                            # types in case setKeyframe overrode them.
                            try:
                                cmds.keyTangent(
                                    plug,
                                    edit=True,
                                    time=(t, t),
                                    inTangentType=itt,
                                    outTangentType=ott,
                                )
                            except Exception:
                                pass
                    else:
                        # --- Scalar paste (current_frame / channel_box) ---
                        times = (
                            [target_time]
                            if not isinstance(target_time, (list, tuple))
                            else list(target_time)
                        )
                        for t in times:
                            AnimUtils._set_key_preserving_tangents(
                                plug, t, data, **kwargs
                            )
                keys_set += 1

        if refresh_channel_box:
            pm.mel.eval("channelBoxCommand -update;")

        return keys_set

    @staticmethod
    def delete_animation_layer(
        layer: str,
        merge_to_base: bool = False,
    ) -> bool:
        """Delete an animation layer.

        Parameters:
            layer: Name of the layer to delete.
            merge_to_base: If True, merges the layer's animation to the base
                layer before deleting. If False, animation is discarded.

        Returns:
            True if layer was deleted successfully, False otherwise.
        """
        import maya.cmds as cmds

        if not cmds.objExists(layer):
            return False

        try:
            if merge_to_base:
                cmds.bakeResults(
                    cmds.animLayer(layer, query=True, affectedLayers=True) or [],
                    destinationLayer="BaseAnimation",
                    removeBakedAttributeFromLayer=True,
                )
            cmds.delete(layer)
            return True
        except RuntimeError:
            return False

    @staticmethod
    def fit_playback_range(
        objects=None,
        padding: float = 0,
    ) -> bool:
        """Set the playback range to encompass keyframes on all (or given) scene objects.

        Queries every keyed object in the scene (or a supplied list) and adjusts
        Maya's playback-range and animation-range to span from the earliest to
        the latest keyframe, optionally padded.

        Parameters:
            objects: Objects to consider. If None, all keyed DAG transforms are used.
            padding: Extra frames to add before the first and after the last key.

        Returns:
            True if the range was updated, False if no keyframes were found.
        """
        import maya.cmds as cmds

        if objects is None:
            curves = cmds.ls(type="animCurve")
            if not curves:
                pm.warning("No animation curves in the scene.")
                return False
            connected = (
                cmds.listConnections(curves, destination=True, source=False) or []
            )
            objects = list(
                set(cmds.ls(connected, long=True, dagObjects=True, transforms=True))
            )
            if not objects:
                pm.warning("No keyed DAG objects found.")
                return False

        result = AnimUtils.get_keyframe_times(objects, as_range=True)
        if result is None:
            pm.warning("No keyframes found on the given objects.")
            return False

        start, end = result
        start -= padding
        end += padding

        cmds.playbackOptions(
            minTime=start,
            maxTime=end,
            animationStartTime=start,
            animationEndTime=end,
        )
        return True


# -----------------------------------------------------------------------------

if __name__ == "__main__":
    pass

# -----------------------------------------------------------------------------
# Notes
# -----------------------------------------------------------------------------
