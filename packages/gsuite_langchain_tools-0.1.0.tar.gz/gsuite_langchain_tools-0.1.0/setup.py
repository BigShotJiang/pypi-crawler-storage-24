from setuptools import setup, find_packages

setup(
    name="gsuite-langchain-tools",
    version="0.1.0",
    description="A LangChain toolkit for integrating Google Workspace (Gmail, Calendar, Tasks, Sheets, Drive)",
    author="Kasa Harendra",
    author_email="harendrakasa@gmail.com",
    url="https://github.com/Kasa-Harendra/langchain-gsuite",
    packages=find_packages(),
    install_requires=[
        "langchain",
        "langchain-core",
        "langchain-google-community",
        "google-api-python-client",
        "pydantic"
    ],
    python_requires=">=3.8",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    include_package_data=True,
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)