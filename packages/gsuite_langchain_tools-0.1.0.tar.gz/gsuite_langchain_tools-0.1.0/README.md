# GoogleSuiteToolkit for LangChain

A unified toolkit for integrating Google Workspace (Gmail, Calendar, Tasks, Sheets) with LangChain agents.

## Features
- Access Gmail, Google Calendar, Google Tasks, and Google Sheets via LangChain tools
- Easy authentication using OAuth2 credentials
- Simple API for tool retrieval and usage

## Installation

1. Clone this repository or copy the toolkit files into your project.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Set up your Google Cloud project and download `credentials.json` for OAuth2.


## Usage

```python
from langchain_gsuite import GoogleSuiteToolkit, build_gsuite_service, DEFAULT_SCOPES

# Basic usage
toolkit = GoogleSuiteToolkit()
print(toolkit.get_tools())
print(toolkit.get_tools_dict())

# Advanced: Customizing Google API resource
from google.oauth2.credentials import Credentials

# Example: Use custom scopes and credentials
custom_scopes = [
	"https://www.googleapis.com/auth/gmail.readonly",
	"https://www.googleapis.com/auth/calendar",
]
creds = Credentials.from_authorized_user_file("path/to/credentials.json", custom_scopes)
api_resource = build_gsuite_service(
	credentials=creds,
	service_name="gmail",  # or 'calendar', 'sheets', 'tasks'
	service_version="v1",
	scopes=custom_scopes
)
```

## Required OAuth Scopes

Depending on the Google Workspace services you want to access, you must provide the appropriate OAuth scopes. Here are some common scopes:

- Gmail: `https://mail.google.com/` or `https://www.googleapis.com/auth/gmail.readonly`
- Calendar: `https://www.googleapis.com/auth/calendar`
- Sheets: `https://www.googleapis.com/auth/spreadsheets`
- Drive (readonly): `https://www.googleapis.com/auth/drive.readonly`
- Tasks: `https://www.googleapis.com/auth/tasks`

The toolkit provides two lists for convenience:
- `DEFAULT_SCOPES`: Full access for all supported services
- `DEFAULT_SERVICE_SCOPES`: Read-only access for all supported services

You can pass your own list of scopes to `build_gsuite_service` if you want to restrict or expand permissions.

## Customizing build_gsuite_service

The `build_gsuite_service` function supports the following parameters:

- `credentials`: (Optional) A `google.oauth2.credentials.Credentials` object. If not provided, credentials will be loaded automatically.
- `service_name`: (str) The Google API service name (e.g., 'gmail', 'calendar', 'sheets', 'tasks').
- `service_version`: (str) The API version (default: 'v1').
- `use_domain_wide`: (bool) Use domain-wide delegation (for service accounts).
- `delegated_user`: (Optional[str]) User to delegate domain-wide authority to.
- `service_account_file`: (Optional[str]) Path to service account file.
- `scopes`: (Optional[List[str]]) List of OAuth2 scopes. If not provided, defaults to `DEFAULT_SCOPES` or `DEFAULT_SERVICE_SCOPES`.

See the docstring in `utils.py` for more details.


