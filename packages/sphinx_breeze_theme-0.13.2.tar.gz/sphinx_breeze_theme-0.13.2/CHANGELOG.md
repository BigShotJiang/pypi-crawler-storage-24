# Changelog

All notable changes to this project will be documented in this file.

<!-- version list -->

## v0.13.2 (2026-03-22)

### 🪲 Bug fixes

- **styles**: Fix page-actions button height alignment
  ([`19da688`](https://github.com/aksiome/breeze/commit/19da6884e76e9d6c30549966f0eacdd609a40472))

### 📖 Documentation

- Change toctree from hidden to titlesonly
  ([`3dd04cb`](https://github.com/aksiome/breeze/commit/3dd04cb3bbac3ccef3213873297f2b2a10821d6d))
- Use local qr code image in markup guide
  ([`7c3d3f5`](https://github.com/aksiome/breeze/commit/7c3d3f58c0ceedcc830a305b029469e2a47cbe04))
- Add theme origin story and update tagline
  ([`08a7270`](https://github.com/aksiome/breeze/commit/08a7270d914f29f30f97b85ad6baf82def043857))

## v0.13.1 (2026-02-22)

### 🪲 Bug fixes

- **a11y**: Show focus outline on keyboard navigation only
  ([`e6f5bce`](https://github.com/aksiome/breeze/commit/e6f5bce4a293068b0bbffac13831cb5f50b55cd8))

## v0.13.0 (2026-02-22)

### ✨ Features

- Add page-actions component
  ([`8a3e7e9`](https://github.com/aksiome/breeze/commit/8a3e7e9f242d0f647d3dae21aeb9146b2df01a22))
- Add light/dark logo support
  ([`e6f33e0`](https://github.com/aksiome/breeze/commit/e6f33e085cf93d36b8ab9a361506e6eda200e13f))
- Add invert-dark and invert-light utility classes
  ([`35a9837`](https://github.com/aksiome/breeze/commit/35a9837e02680a53d258bf992ec14b945409c095))
- Add myst-nb extension support
  ([`19e0a5d`](https://github.com/aksiome/breeze/commit/19e0a5db05d95fcc67474285e6a017aff0728c29))
- Add click-extra support
  ([`8a82931`](https://github.com/aksiome/breeze/commit/8a82931a71c4773911f2e2073a7b42fa5174425e))
- Add page actions component
  ([`49427cb`](https://github.com/aksiome/breeze/commit/49427cb511b4d0c2a1ee23d463ca825562fb73a5))
- Add sphinx-gallery support
  ([`9345365`](https://github.com/aksiome/breeze/commit/93453652a59b950195970dbec1435c0416093bcf))

### 🎨 Appearance

- **styles**: Update sphinx content styles
  ([`6d05435`](https://github.com/aksiome/breeze/commit/6d05435c29739318ddfa1ac20f9e182632dbafcd))
- **styles**: Update extension styles
  ([`7f2b1ba`](https://github.com/aksiome/breeze/commit/7f2b1ba5395c9b43518c7feb8f148aa1d6ed30a6))
- **styles**: Minor design refinements
  ([`db22e8c`](https://github.com/aksiome/breeze/commit/db22e8c9156d9d0dd1c96f594971476ea6418a1a))

### 📖 Documentation

- Update repo-stats styling
  ([`a301186`](https://github.com/aksiome/breeze/commit/a301186d97a020d3d37762d58378325aa078f256))
- Update edit-this-page styling
  ([`b520db1`](https://github.com/aksiome/breeze/commit/b520db1ed76272997664507236d00a583567001e))
- Update user guide index
  ([`035e76a`](https://github.com/aksiome/breeze/commit/035e76a9d6cb8747375ec311d64f4f0c911dc5c5))
- Add contributing guide
  ([`8e73c9c`](https://github.com/aksiome/breeze/commit/8e73c9c0d28f66b64cc091da3c4f7bd7a0132aa5))
- Add accessibility page
  ([`3604860`](https://github.com/aksiome/breeze/commit/3604860ee88b7bdacd2550313224fc48f6c56b2f))
- Expand jupyter-sphinx examples
  ([`569bcb4`](https://github.com/aksiome/breeze/commit/569bcb49688f49d1f6c2ee0479f8e2542ba00c62))

## v0.12.0 (2026-02-09)

### ✨ Features

- **theme**: Rename version_slug to version_id
  ([`7393d70`](https://github.com/aksiome/breeze/commit/7393d701d38f6a99aea3f53323a2ff4ca5233a38))
- Add jupyter-sphinx support
  ([`79ade20`](https://github.com/aksiome/breeze/commit/79ade20736097d20cd24b8ff96d0ac31f753d2fb))

## v0.11.1 (2026-02-07)

### 🪲 Bug fixes

- **a11y**: Adjust nbsphinx color contrast
  ([`bc03e04`](https://github.com/aksiome/breeze/commit/bc03e04b24b56b4bb663752146e045c80fc2aa51))

## v0.11.0 (2026-02-07)

### ✨ Features

- Add sphinx-click and nbsphinx support
  ([`1828ed5`](https://github.com/aksiome/breeze/commit/1828ed55746c2debb5f9f5a0efc67bd3c87f962b))
- **theme**: Rename version config variables for clarity
  ([`8c7354c`](https://github.com/aksiome/breeze/commit/8c7354cc2634515bbebd6b154ae1fe0b7d0b2bba))
- Add sphinx-datatables support
  ([`9674b86`](https://github.com/aksiome/breeze/commit/9674b861be58826428f10923f7d4c8396c67083a))
- Add sphinx-docsearch support
  ([`977788d`](https://github.com/aksiome/breeze/commit/977788d9fc380208afa070f8d098d1eca2e85e3d))

### 🎨 Appearance

- **styles**: Minor design refinements and consistency improvements
  ([`802d9bf`](https://github.com/aksiome/breeze/commit/802d9bf878ed490a972928ae6c140fe589228656))

### 🪲 Bug fixes

- **vite**: Output separate breeze.css and disable asset inlining
  ([`f654b53`](https://github.com/aksiome/breeze/commit/f654b5395f8c5ff5ad6685fcbd17f0223d7b7a1f))
- **theme**: Wrap js in an iife to avoid global scope pollution
  ([`4a0c3be`](https://github.com/aksiome/breeze/commit/4a0c3bebca08747941dec7e82a3113881927bed8))
- **opengraph**: Strip emojis for reliable social card rendering
  ([`19a07cf`](https://github.com/aksiome/breeze/commit/19a07cf5feb01c5ebe83c29a7c543c6055239b08))

### 📖 Documentation

- Reorganize toctree for clearer structure
  ([`215a891`](https://github.com/aksiome/breeze/commit/215a891746d12bba4b071b33547d818f884d61d6))

## v0.10.0 (2026-02-01)

### ✨ Features

- Add sphinx-contributors support
  ([`e6da568`](https://github.com/aksiome/breeze/commit/e6da568c8e787f7486484c65c8f6c45a7cb2a954))
- Add numpydoc support
  ([`06babc2`](https://github.com/aksiome/breeze/commit/06babc26ee4ce753c7242d2d472497580819dd93))
- Add sphinx-togglebutton support
  ([`1dff45d`](https://github.com/aksiome/breeze/commit/1dff45d74fea28885cb5d2ce5b98ba60dc227b47))
- Add sphinxcontrib-mermaid support
  ([`291f9f3`](https://github.com/aksiome/breeze/commit/291f9f325001a62ff05d1fba8259c3b6b4858b16))
- **repo-stats**: Improve long repository name handling
  ([`85b8294`](https://github.com/aksiome/breeze/commit/85b82943071715e323da2afb43816057ba78a116))
- **fonts**: Refine typography for improved readability
  ([`1e28fe5`](https://github.com/aksiome/breeze/commit/1e28fe5e59777f34761f10fac89fdb7b0c0aa95c))

### 🪲 Bug fixes

- Move tooltip up for elements inside the footer
  ([`2d33ae0`](https://github.com/aksiome/breeze/commit/2d33ae0d9b49e33757da3c32c7c3b090b9d64b13))

### 📖 Documentation

- Consolidate extensions into their own section
  ([`c45e3de`](https://github.com/aksiome/breeze/commit/c45e3de1e9c3f847b991b5481f52defec8232bbf))
- Better components slots defaults and collapse entries into tabs
  ([`015c12f`](https://github.com/aksiome/breeze/commit/015c12f4b0b38fd9dda313843191137f2b1c57f2))
- Add sphinx-copybutton
  ([`3c7a983`](https://github.com/aksiome/breeze/commit/3c7a9832192d3827e842e53279becad2c38a53c1))
- Add theme markup page
  ([`3fcd8fd`](https://github.com/aksiome/breeze/commit/3fcd8fdbc96fe45aa7dcd3fa600f1b07909af4f1))

## v0.9.0 (2026-01-29)

### ✨ Features

- Add default_mode theme option
  ([`377d29e`](https://github.com/aksiome/breeze/commit/377d29eff1e6c2d7200ca2aa7828058aa4675546))
- Add repository stats component
  ([`4d4380a`](https://github.com/aksiome/breeze/commit/4d4380aa950b6ec03a3a015a9385096d4ea8aaf3))
- Bundle theme fonts for consistent typography
  ([`0d005e5`](https://github.com/aksiome/breeze/commit/0d005e510e5781db0ceadc4661e736683108535e))

### 🎨 Appearance

- Apply frosted glass effect to tiles
  ([`fa6ff53`](https://github.com/aksiome/breeze/commit/fa6ff5379b5c05a79f94fd4efc0d0822ec94a7f2))
- **layout**: Increase spacing between header and content
  ([`47e1866`](https://github.com/aksiome/breeze/commit/47e18666a7cfe2490773086c482dad17e137a0e4))

### 🪲 Bug fixes

- **a11y**: Add aria labels to navigation elements and adjust colors
  ([`9f64981`](https://github.com/aksiome/breeze/commit/9f64981609715fa3e7e6df20c0e314091f2ccff7))
- Default emojis_sidebar_nav to false for consistency
  ([`2470948`](https://github.com/aksiome/breeze/commit/2470948da455484dcf22a6bf91838f8fde47d33d))

### 📖 Documentation

- Restructure user guide
  ([`ce4bd80`](https://github.com/aksiome/breeze/commit/ce4bd80229cfd5632f174b6889ccb92c4a66ff37))

## v0.8.0 (2026-01-27)

### ✨ Features

- Update external links known domains
  ([`e14c24c`](https://github.com/aksiome/breeze/commit/e14c24c79e710d3caff596b1234a4226cb2d0aca))

### 🎨 Appearance

- **api**: Scrollable signature blocks and source icon
  ([`e090e4a`](https://github.com/aksiome/breeze/commit/e090e4ae8c7371f0c3467f9e1165efd20e469b4b))
- **layout**: Slightly improve the frosted glass effect
  ([`35d0c51`](https://github.com/aksiome/breeze/commit/35d0c5148bc01b65e122a15c38edf2b0241ddc38))

### 🪲 Bug fixes

- **sidebar**: Correct chevron alignment
  ([`c3c2878`](https://github.com/aksiome/breeze/commit/c3c2878586e79bbbd5f091182b4601faafff2e81))

### 📖 Documentation

- Improve readme structure and visuals
  ([`bc23101`](https://github.com/aksiome/breeze/commit/bc231018d6e4fe78ba8dba49764817d44fe61c2b))

## v0.7.3 (2026-01-26)

### 🪲 Bug fixes

- Header separator z-index
  ([`1171ada`](https://github.com/aksiome/breeze/commit/1171ada3df2f44c40923f0c6429a181df05c3cb2))

## v0.7.2 (2026-01-26)

### 🎨 Appearance

- **layout**: Add frosted glass effect
  ([`43da22d`](https://github.com/aksiome/breeze/commit/43da22d7fb75387ff56870b02008f5c8052c770b))

### 🪲 Bug fixes

- **breadcrumbs**: Prevent overflow on large paths
  ([`338a284`](https://github.com/aksiome/breeze/commit/338a284ae4c3bbc02c2f431c9babfac0679c0ac0))

### 📖 Documentation

- Add edit this page component
  ([`c1cda1c`](https://github.com/aksiome/breeze/commit/c1cda1c730baa238fc72e64a3bd5bd7ce3827b1f))
- Clarify layout component usage
  ([`7579441`](https://github.com/aksiome/breeze/commit/75794411e40afbaa507a5ececbc34bdc7efc8852))

## v0.7.1 (2026-01-26)

### 🪲 Bug fixes

- Type hint causing build failure
  ([`9a3fa82`](https://github.com/aksiome/breeze/commit/9a3fa8239751a0c2887ccfa892d620d8b46dd90a))

## v0.7.0 (2026-01-26)

### ✨ Features

- Add external link icon
  ([`fae7ba0`](https://github.com/aksiome/breeze/commit/fae7ba0905e273ecd4e627333e5dd5b5a02f9ab7))
- Auto-detect external links icons and names
  ([`285989c`](https://github.com/aksiome/breeze/commit/285989c53ffc8700b85d09b4d0acf13a13ff6a11))
- **layout**: Add hide-header-tabs page option
  ([`eeb6bde`](https://github.com/aksiome/breeze/commit/eeb6bdee3e63525e7ed0bf5eb28e8fc8f20c9340))

### 🎨 Appearance

- **theme**: Adjust light theme colors
  ([`c021dac`](https://github.com/aksiome/breeze/commit/c021dac70880c3a93a44ac300d3df1daf20a4275))
- **table**: Add small padding to better center the scrollbar on wide tables
  ([`1e00066`](https://github.com/aksiome/breeze/commit/1e00066bf2a5e2e9f3f6c81a63b99308bea27e02))

### 🪲 Bug fixes

- **ui**: Show mobile burger icon when tabs are disabled
  ([`57697d1`](https://github.com/aksiome/breeze/commit/57697d10aaea6eeb10d47d9a931f9939ca52ddd2))

### 📖 Documentation

- Fix include path errors
  ([`a07d232`](https://github.com/aksiome/breeze/commit/a07d2329b159baebdf9a116dfc191ea2a4d26075))
- Add logo and improve index
  ([`e2b860f`](https://github.com/aksiome/breeze/commit/e2b860fcf1fc656036f60be6be105cc66a65f75c))

## v0.6.1 (2026-01-23)

### 🎨 Appearance

- **sphinx-design**: Update badges and dropdown colors to match the theme
  ([`d96c301`](https://github.com/aksiome/breeze/commit/d96c301124c22bc0112f44e17952083d3d9f32b8))
- **footer**: Wrap and center content on mobile devices
  ([`172a885`](https://github.com/aksiome/breeze/commit/172a8855d7b40b132a4ea55a1f77ed03d3bc100e))
- **theme**: Adjust color contrast
  ([`f5bf64c`](https://github.com/aksiome/breeze/commit/f5bf64cca33ef75020284e0f12a4f1e1b031c061))
- **layout**: Spacing and size tweaks
  ([`b7fad54`](https://github.com/aksiome/breeze/commit/b7fad5424de53f32364f88e1928c145b7822b646))

### 📖 Documentation

- Minor layout and naming tweaks
  ([`c7abd8e`](https://github.com/aksiome/breeze/commit/c7abd8e1274dfb4f7d913b6a3fc775ae85512626))
- Simple user guide
  ([`b3fdb05`](https://github.com/aksiome/breeze/commit/b3fdb05166352fcfc632d572a4ea4d30875f8dca))

## v0.6.0 (2025-11-14)

### ✨ Features

- Add content-width meta option
  ([`369be71`](https://github.com/aksiome/breeze/commit/369be71bb5f9e5d6c878e046fb312c6b0546199a))
- Add hide-sidebar-[primary|secondary] option
  ([`72f63ef`](https://github.com/aksiome/breeze/commit/72f63ef9d5ad1be36d6858d29629fe20b37e0cde))

### 🪲 Bug fixes

- Rename breadcrumb to breadcrumbs
  ([`4e8081c`](https://github.com/aksiome/breeze/commit/4e8081c9fcc8496731a9c26eb503b6b0311d562b))
- Secondary sidebar inline padding
  ([`80bd4aa`](https://github.com/aksiome/breeze/commit/80bd4aa2413ce19ca5f4e8c39d416e179dd78117))

## v0.5.5 (2025-11-02)

### 🪲 Bug fixes

- Sphinx treeview version dependency
  ([`8ead4c5`](https://github.com/aksiome/breeze/commit/8ead4c53b942ad95bee0e13a752d3ccb3eb15c4c))

## v0.5.4 (2025-11-02)

### 🪲 Bug fixes

- Rtd config for real and add project metadata
  ([`f22d5b5`](https://github.com/aksiome/breeze/commit/f22d5b56099cdb60f38f40f5e76ec962341da47e))

## v0.5.3 (2025-11-02)

### 🪲 Bug fixes

- Update python version in rtd configuration
  ([`36ed1d4`](https://github.com/aksiome/breeze/commit/36ed1d4bf4fbb721150dd9d8f856ade1304228fe))

## v0.5.2 (2025-10-30)

### 🪲 Bug fixes

- Build with lower sphinx versions
  ([`4cd5b6b`](https://github.com/aksiome/breeze/commit/4cd5b6b053e9526fef6fe24e9f9cddfcb91e2ade))

## v0.5.1 (2025-10-30)

### 🪲 Bug fixes

- Improve layout and components spacing
  ([`adbd94a`](https://github.com/aksiome/breeze/commit/adbd94a9b017145fc602f86676295c83061b77e1))

## v0.5.0 (2025-10-29)

### ✨ Features

- Support lower sphinx and python versions
  ([`143094b`](https://github.com/aksiome/breeze/commit/143094b2fd665032ffbf60a2509ddf4822e3a852))

## v0.4.2 (2025-10-26)

### 🪲 Bug fixes

- Content min height when not using tabs
  ([`a9c77ab`](https://github.com/aksiome/breeze/commit/a9c77abd492351ff76d05cff3bb3aa844c1ce4bb))

## v0.4.1 (2025-10-26)

### 🪲 Bug fixes

- Small style issues (api, sidebar, and header without tabs)
  ([`150d7c9`](https://github.com/aksiome/breeze/commit/150d7c9fa4cb3685ce710a7e313886b30cb2937f))

## v0.4.0 (2025-10-26)

### ✨ Features

- Add a header tabs option to put the whole toctree in the sidebar
  ([`46fc604`](https://github.com/aksiome/breeze/commit/46fc604c632c7782c096db555d77d55533c9b2bb))
- Style the edit this page component
  ([`052a62c`](https://github.com/aksiome/breeze/commit/052a62ccce142c26a6addd563daebdc2d7db1089))

### 🪲 Bug fixes

- Vanilla pre style
  ([`555aed8`](https://github.com/aksiome/breeze/commit/555aed897b1fc68e2af6bae0f3851c318cb65819))
- Margin below components in mobile secondary sidebar
  ([`5dbc211`](https://github.com/aksiome/breeze/commit/5dbc21198f7193813754d74a91930ac75c8431db))
- Remove logo img if logo is missing
  ([`0113afd`](https://github.com/aksiome/breeze/commit/0113afdd5036840c843d10d42ff864f8455a5043))

## v0.3.2 (2025-10-26)

### 🪲 Bug fixes

- Ensure main navigation collapses to a single toctree
  ([`0585da7`](https://github.com/aksiome/breeze/commit/0585da7c3c0a05a3e8929fe36e795c710211b66c))

## v0.3.1 (2025-10-24)

### 🪲 Bug fixes

- Page title emoji stripping
  ([`9a7af9f`](https://github.com/aksiome/breeze/commit/9a7af9fa0018e6744f333a87d971e13cd160a2bd))

## v0.3.0 (2025-10-24)

### ✨ Features

- Add option to strip emojis from titles
  ([`1aaa449`](https://github.com/aksiome/breeze/commit/1aaa44960d937eb9b99f0131d39a2cdb1c70d943))

## v0.2.3 (2025-10-22)

### 🪲 Bug fixes

- Wrong sphinx design text color
  ([`9c4d2c0`](https://github.com/aksiome/breeze/commit/9c4d2c032179890417195ee9b485f5842ced64c4))

## v0.2.2 (2025-10-21)

### 🪲 Bug fixes

- Style ethical ad components
  ([`851b15b`](https://github.com/aksiome/breeze/commit/851b15b96f580652ea057605102eca7634afc554))

## v0.2.1 (2025-10-21)

### 🪲 Bug fixes

- Start styling rtd components
  ([`0c0bd9d`](https://github.com/aksiome/breeze/commit/0c0bd9d567b4fbb65d44700415ad055989808870))

## v0.2.0 (2025-10-21)

### ✨ Features

- Cleanup and stabilize css variable names
  ([`fce183b`](https://github.com/aksiome/breeze/commit/fce183b298bdede502b2c400420b9047741200d4))

### 📖 Documentation

- Fix lang switcher links
  ([`081ddbc`](https://github.com/aksiome/breeze/commit/081ddbcd7294365e68969c765fa807a2f5835f5c))

## v0.1.2 (2025-10-05)

### 🪲 Bug fixes

- Secondary sidebar padding with scrollbar
  ([`be76082`](https://github.com/aksiome/breeze/commit/be76082f4040357311dc97f9a9e2b5e50d6573c4))

### 📖 Documentation

- Fix index grid responsiveness
  ([`60d982b`](https://github.com/aksiome/breeze/commit/60d982b8c269caea3c2bffbdaf6a96f6e29f3168))

## v0.1.1 (2025-09-27)

### 🪲 Bug fixes

- Setup the correct version switcher
  ([`ebab69c`](https://github.com/aksiome/breeze/commit/ebab69cd17e81feb445e87ff483d6ce76c462910))

### 📖 Documentation

- Include the changelog
  ([`943eb48`](https://github.com/aksiome/breeze/commit/943eb489b74d1925ed8ed8e77827162ded3961d9))

## v0.1.0 (2025-09-27)

### ✨ Features

- Improve and add rtd search
  ([`3ae18f6`](https://github.com/aksiome/breeze/commit/3ae18f69ced78ac0345985d002c7d1d683e48f79))
- Add ethical-ads and edit-this-page components
  ([`f3fa574`](https://github.com/aksiome/breeze/commit/f3fa574d2fc3fd4a327fa08c78486962a05c1dec))

### 🪲 Bug fixes

- Avoid broken label link when sidebar is not rendered
  ([`56389fb`](https://github.com/aksiome/breeze/commit/56389fb198df5186967b79c13f428eed6c85f917))
- Add primary sidebar bottom padding
  ([`449e02e`](https://github.com/aksiome/breeze/commit/449e02e41096085e64f9263bbc3364e5f87834ff))
- Logo and text vertical alignment
  ([`05c538e`](https://github.com/aksiome/breeze/commit/05c538eda3f96a26b0a8b9fdbb202e420461c6b5))

## v0.0.1 (2025-09-25)

### 🪲 Bug fixes

- Preserve current page when switching versions
  ([`7db3831`](https://github.com/aksiome/breeze/commit/7db3831be11ca03c51f53a87631e83f613d6f4bc))
- Unify component and option names
  ([`52544cb`](https://github.com/aksiome/breeze/commit/52544cb440a592cc8697a6e4b2eceb6ae9439461))

## v0.0.0 (2025-09-21)

- Initial release
