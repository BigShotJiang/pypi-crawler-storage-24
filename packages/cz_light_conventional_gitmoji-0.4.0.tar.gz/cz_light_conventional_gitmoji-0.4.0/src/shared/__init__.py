"""Module for shared."""
