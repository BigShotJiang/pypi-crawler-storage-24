"""Module for gitmojify."""
