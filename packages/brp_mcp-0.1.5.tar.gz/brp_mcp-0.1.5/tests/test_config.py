from brp_mcp.config import load_settings, resolve_config_path


def test_load_settings_uses_explicit_env_profile(monkeypatch):
    monkeypatch.setenv("BRP_ENV", "stage")
    monkeypatch.delenv("BRP_OPENAPI_URL", raising=False)
    monkeypatch.delenv("BRP_GATEWAY_BASE_URL", raising=False)

    settings = load_settings()

    assert settings.brp_env == "stage"
    assert settings.openapi_url == "https://stage-api.lanternbrp.com/api/docs/swagger.json"
    assert settings.gateway_base_url == "https://stage-api.lanternbrp.com"
    assert settings.inferred_env is False
    assert settings.used_url_override is False


def test_load_settings_infers_env_from_url_override(monkeypatch):
    monkeypatch.delenv("BRP_ENV", raising=False)
    monkeypatch.setenv("BRP_OPENAPI_URL", "https://api.lanternbrp.com/api/docs/swagger.json")
    monkeypatch.delenv("BRP_GATEWAY_BASE_URL", raising=False)

    settings = load_settings()

    assert settings.brp_env == "prod"
    assert settings.inferred_env is True
    assert settings.used_url_override is True


def test_load_settings_supports_default_visibility_flag(monkeypatch):
    monkeypatch.setenv("BRP_ENV", "dev")
    monkeypatch.setenv("BRP_DEFAULT_VISIBILITY", "true")

    settings = load_settings()

    assert settings.default_visibility is True


def test_resolve_config_path_finds_project_config_outside_cwd(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    resolved = resolve_config_path(".config/mcp_visibility_policy.json")

    assert resolved.exists()
    assert resolved.name == "mcp_visibility_policy.json"
