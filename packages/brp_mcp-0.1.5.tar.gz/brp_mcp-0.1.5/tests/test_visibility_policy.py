import json

from brp_mcp.visibility_policy import load_visibility_policy


def test_load_visibility_policy_missing_file(tmp_path):
    policy = load_visibility_policy(tmp_path / "missing.json")
    assert policy.is_empty is True
    assert policy.services == {}
    assert policy.operations == {}


def test_load_visibility_policy_parses_services_and_operations(tmp_path):
    policy_file = tmp_path / "policy.json"
    policy_file.write_text(
        json.dumps(
            {
                "defaultVisible": False,
                "services": {
                    "BOMs": {"visible": True},
                    "Users": False,
                },
                "operations": {
                    "GET /api/boms": {"visible": True},
                    "createUser": False,
                },
            }
        ),
        encoding="utf-8",
    )

    policy = load_visibility_policy(policy_file)
    assert policy.default_visible is False
    assert policy.services["BOMs"] is True
    assert policy.services["Users"] is False
    assert policy.operations["GET /api/boms"] is True
    assert policy.operations["createUser"] is False
    assert policy.is_empty is False
