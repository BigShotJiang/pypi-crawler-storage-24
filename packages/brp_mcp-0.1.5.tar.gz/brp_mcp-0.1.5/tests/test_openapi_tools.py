from brp_mcp.openapi_tools import Operation, _iter_operations, build_tool_description
from brp_mcp.visibility_policy import VisibilityPolicy


def test_tool_description_includes_required_inputs():
    op = Operation(
        method="post",
        path="/api/orders",
        tag="Orders",
        operation_id="createOrder",
        summary="Create order",
        description="Creates a new order.",
        parameters=[
            {"name": "tenantId", "in": "query", "required": True},
            {"name": "id", "in": "path", "required": False},
        ],
        request_body={"required": True},
        responses={"201": {}, "400": {}, "401": {}},
        security=[{"bearerAuth": []}],
    )

    desc = build_tool_description(op)

    assert "Create order." in desc
    assert "Endpoint: POST /api/orders." in desc
    assert "Authentication/security: bearerAuth." in desc
    assert "Required params: query:tenantId (any)." in desc
    assert "Body required: yes;" in desc
    assert "Returns HTTP codes: 201, 400, 401." in desc


def test_iter_operations_honors_openapi_visibility_with_default_deny():
    spec = {
        "tags": [
            {"name": "Orders", "x-mcp-visible": True},
            {"name": "Users", "x-mcp-visible": False},
        ],
        "paths": {
            "/api/orders": {
                "get": {
                    "tags": ["Orders"],
                    "operationId": "listOrders",
                    "x-mcp-visible": True,
                    "responses": {"200": {}},
                },
            },
            "/api/users": {
                "get": {
                    "tags": ["Users"],
                    "operationId": "listUsers",
                    "x-mcp-visible": True,
                    "responses": {"200": {}},
                },
            },
        },
    }
    policy = VisibilityPolicy(default_visible=None, services={}, operations={})
    operations, stats = _iter_operations(spec, visibility_policy=policy, default_visibility=False)

    assert len(operations) == 1
    assert operations[0].operation_id == "listOrders"
    assert stats.total_operations == 2
    assert stats.filtered_by_service_visibility == 1
    assert stats.filtered_by_operation_visibility == 0


def test_iter_operations_policy_override_can_enable_specific_operation():
    spec = {
        "tags": [{"name": "Orders"}],
        "paths": {
            "/api/orders": {
                "get": {
                    "tags": ["Orders"],
                    "operationId": "listOrders",
                    "responses": {"200": {}},
                },
            },
        },
    }
    policy = VisibilityPolicy(
        default_visible=None,
        services={"Orders": True},
        operations={"GET /api/orders": True},
    )
    operations, stats = _iter_operations(spec, visibility_policy=policy, default_visibility=False)

    assert len(operations) == 1
    assert operations[0].operation_id == "listOrders"
    assert stats.filtered_by_service_visibility == 0
    assert stats.filtered_by_operation_visibility == 0
