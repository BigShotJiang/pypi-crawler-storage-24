"""BRP MCP package."""
