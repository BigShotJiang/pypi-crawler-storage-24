"""
ClevAgentRunner — two responsibilities:

  1. Heartbeat proxy: check local process/container state, send heartbeat on behalf
     of each watched target (Mode A — no code changes needed in customer's agent).
  2. Command executor: poll /api/v1/commands, execute restart/stop, report result.

Security model:
  - Server sends {"action": "restart", "type": "docker", "target": "my-bot"}
  - Runner validates target is in --watch whitelist before executing anything
  - Commands are assembled from hardcoded safe templates (no shell=True, no arbitrary strings)
"""

import logging
import os
import subprocess
import time
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger("clevagent_runner")


class ClevAgentRunner:
    COMMAND_POLL_INTERVAL = 10  # seconds between command polls
    RESTART_COOLDOWN = 300  # 5-minute cooldown between auto-restart attempts per target

    def __init__(
        self,
        api_key: str,
        watches: List[Dict[str, str]],
        endpoint: str = "https://clevagent.io",
        heartbeat_interval: int = 30,
    ) -> None:
        """
        Args:
            api_key: ClevAgent project API key (cv_xxx).
            watches: list of {"type": "docker"|"systemd"|"launchd"|"process", "target": "name"}.
            endpoint: ClevAgent server base URL.
            heartbeat_interval: Seconds between per-watch heartbeats (default: 30).
        """
        self.api_key = api_key
        self.endpoint = endpoint.rstrip("/")
        self.watches = watches
        self.heartbeat_interval = heartbeat_interval
        # Security whitelist: only targets registered via --watch can be restarted
        self.whitelist = {f"{w['type']}:{w['target']}" for w in watches}
        self._session = requests.Session()
        self._session.headers.update({
            "X-API-Key": api_key,
            "Content-Type": "application/json",
        })
        self._last_heartbeat = 0.0
        self._last_command_poll = 0.0
        self._restart_cooldowns: Dict[str, float] = {}  # {type:target → last restart monotonic}

    # ── Main loop ─────────────────────────────────────────────────────────────

    def run(self) -> None:
        """Block forever: heartbeat proxy + command polling loop."""
        logger.info("ClevAgentRunner started — watching %d target(s)", len(self.watches))
        for w in self.watches:
            logger.info("  → %s:%s", w["type"], w["target"])

        while True:
            now = time.monotonic()

            if now - self._last_heartbeat >= self.heartbeat_interval:
                self._send_all_heartbeats()
                self._last_heartbeat = now

            if now - self._last_command_poll >= self.COMMAND_POLL_INTERVAL:
                self._poll_and_execute_commands()
                self._last_command_poll = now

            time.sleep(1)

    # ── Heartbeat proxy ───────────────────────────────────────────────────────

    def _send_all_heartbeats(self) -> None:
        for watch in self.watches:
            alive = self._check_alive(watch)
            key = f"{watch['type']}:{watch['target']}"
            status = "ok" if alive else "error"
            message: Optional[str] = None

            if not alive:
                message = f"{watch['target']} is not responding"
                now = time.monotonic()
                last_restart = self._restart_cooldowns.get(key, 0.0)

                # 11a: Send error heartbeat IMMEDIATELY so server records the down event
                agent_name = ".".join(watch["target"].split(".")[-2:]) if watch["target"].count(".") >= 2 else watch["target"]
                self._send_heartbeat(agent_name=agent_name, status="error", message=message)

                if now - last_restart >= self.RESTART_COOLDOWN:
                    logger.warning("Target %s down — attempting local auto-restart", key)
                    self._restart_cooldowns[key] = now
                    success, msg = self._restart(watch["type"], watch["target"])
                    if success:
                        logger.info("Auto-restart succeeded: %s", msg)
                        time.sleep(2)
                        if self._check_alive(watch):
                            status = "ok"
                            message = "Auto-restarted successfully"
                        else:
                            message = "Restart attempted — still not responding"
                    else:
                        logger.warning("Auto-restart failed: %s", msg)
                        message = "Not responding — auto-restart failed"
                else:
                    remaining = int(self.RESTART_COOLDOWN - (now - last_restart))
                    message = f"{watch['target']} is not responding — checking again shortly"
                    # Skip duplicate heartbeat — already sent error above
                    continue

            # Strip reverse-DNS prefix (e.g. "com.sean.crypto-paper-trade" → "crypto-paper-trade")
            target = watch["target"]
            agent_name = ".".join(target.split(".")[-2:]) if target.count(".") >= 2 else target
            # 11d: Include restart config so server auto-sets agent.restart_type/target
            self._send_heartbeat(
                agent_name=agent_name, status=status, message=message,
                restart_type=watch["type"], restart_target=watch["target"],
            )

    def _send_heartbeat(
        self,
        agent_name: str,
        status: str = "ok",
        message: Optional[str] = None,
        restart_type: Optional[str] = None,
        restart_target: Optional[str] = None,
    ) -> None:
        payload: Dict[str, Any] = {"agent": agent_name, "status": status}
        if message:
            payload["message"] = message
        # 11d: Send restart config so server can auto-populate agent fields
        if restart_type:
            payload["restart_type"] = restart_type
        if restart_target:
            payload["restart_target"] = restart_target
        try:
            resp = self._session.post(
                f"{self.endpoint}/api/v1/heartbeat",
                json=payload,
                timeout=10,
            )
            if resp.status_code in (200, 201):
                logger.debug("Heartbeat sent: %s status=%s", agent_name, status)
            else:
                logger.warning("Heartbeat failed for %s: HTTP %s", agent_name, resp.status_code)
        except Exception as e:
            logger.warning("Heartbeat error for %s: %s", agent_name, e)

    # ── Command polling + execution ───────────────────────────────────────────

    def _poll_and_execute_commands(self) -> None:
        try:
            resp = self._session.get(
                f"{self.endpoint}/api/v1/commands",
                timeout=10,
            )
            if resp.status_code != 200:
                logger.warning("Command poll returned HTTP %s", resp.status_code)
                return
            commands = resp.json()
        except Exception as e:
            logger.warning("Command poll error: %s", e)
            return

        for cmd in commands:
            self._execute_command(cmd)

    def _execute_command(self, cmd: Dict[str, Any]) -> None:
        cmd_id = cmd.get("id")
        action = cmd.get("action")
        cmd_type = cmd.get("type")
        target = cmd.get("target")

        # Security: reject anything not in the whitelist
        key = f"{cmd_type}:{target}"
        if key not in self.whitelist:
            logger.warning("Rejected command %s — target not in whitelist: %s", cmd_id, key)
            self._report(cmd_id, "rejected", f"target '{key}' not registered with --watch")
            return

        logger.info("Executing command %s: %s %s:%s", cmd_id, action, cmd_type, target)

        if action == "restart":
            result, msg = self._restart(cmd_type, target)
        elif action == "stop":
            result, msg = self._stop(cmd_type, target)
        else:
            self._report(cmd_id, "rejected", f"unknown action '{action}'")
            return

        status = "completed" if result else "failed"
        self._report(cmd_id, status, msg)

    def _restart(self, cmd_type: str, target: str):
        """Execute restart. Returns (success: bool, message: str)."""
        try:
            if cmd_type == "docker":
                subprocess.run(["docker", "restart", target], check=True, timeout=60)
            elif cmd_type == "systemd":
                subprocess.run(["systemctl", "restart", target], check=True, timeout=60)
            elif cmd_type == "launchd":
                uid = os.getuid()
                try:
                    subprocess.run(
                        ["launchctl", "kickstart", "-k", f"gui/{uid}/{target}"],
                        check=True, timeout=60,
                    )
                except subprocess.CalledProcessError:
                    # Service not loaded in domain (e.g. after bootout) — bootstrap from plist
                    plist_path = os.path.expanduser(f"~/Library/LaunchAgents/{target}.plist")
                    if os.path.exists(plist_path):
                        logger.info("kickstart failed (exit 113?), bootstrapping: %s", plist_path)
                        subprocess.run(
                            ["launchctl", "bootstrap", f"gui/{uid}", plist_path],
                            check=True, timeout=60,
                        )
                    else:
                        raise  # no plist found — re-raise original error
            elif cmd_type == "k8s":
                # Delete pod → Deployment controller recreates it automatically
                subprocess.run(["kubectl", "delete", "pod", target], check=True, timeout=60)
            elif cmd_type == "process":
                # Cannot safely restart a bare process — runner doesn't know the start command
                return False, "process type cannot be restarted by runner (use docker/systemd/launchd)"
            else:
                return False, f"unknown type '{cmd_type}'"
            logger.info("Restart succeeded: %s:%s", cmd_type, target)
            return True, f"Restarted {cmd_type}:{target}"
        except subprocess.CalledProcessError as e:
            msg = f"Restart command failed (exit {e.returncode}): {e}"
            logger.warning(msg)
            return False, msg
        except subprocess.TimeoutExpired:
            msg = f"Restart timed out for {cmd_type}:{target}"
            logger.warning(msg)
            return False, msg
        except Exception as e:
            msg = f"Restart error: {e}"
            logger.warning(msg)
            return False, msg

    def _stop(self, cmd_type: str, target: str):
        """Execute stop. Returns (success: bool, message: str)."""
        try:
            if cmd_type == "docker":
                subprocess.run(["docker", "stop", target], check=True, timeout=60)
            elif cmd_type == "systemd":
                subprocess.run(["systemctl", "stop", target], check=True, timeout=60)
            elif cmd_type == "launchd":
                uid = os.getuid()
                subprocess.run(
                    ["launchctl", "stop", f"gui/{uid}/{target}"],
                    check=True, timeout=60,
                )
            elif cmd_type == "k8s":
                # Scale deployment to 0 replicas — target is the deployment name
                subprocess.run(
                    ["kubectl", "scale", "deployment", target, "--replicas=0"],
                    check=True, timeout=60,
                )
            elif cmd_type == "process":
                # GA-1: PID file required — pkill -f removed for safety (can kill unrelated processes)
                import os as _os
                if _os.path.isfile(target):
                    try:
                        pid = int(open(target).read().strip())
                        _os.kill(pid, 15)  # SIGTERM
                    except (ValueError, ProcessLookupError, FileNotFoundError) as exc:
                        return False, f"PID file stop failed: {exc}"
                else:
                    return False, f"process stop requires a PID file path (got '{target}')"
            else:
                return False, f"unknown type '{cmd_type}'"
            return True, f"Stopped {cmd_type}:{target}"
        except Exception as e:
            msg = f"Stop error: {e}"
            logger.warning(msg)
            return False, msg

    def _report(self, cmd_id: int, status: str, message: Optional[str] = None) -> None:
        payload = {"status": status}
        if message:
            payload["message"] = message
        try:
            self._session.post(
                f"{self.endpoint}/api/v1/commands/{cmd_id}/result",
                json=payload,
                timeout=10,
            )
        except Exception as e:
            logger.warning("Failed to report command result (id=%s): %s", cmd_id, e)

    # ── Process state checks ──────────────────────────────────────────────────

    def _check_alive(self, watch: Dict[str, str]) -> bool:
        """Check if a watched target is currently running."""
        cmd_type = watch["type"]
        target = watch["target"]
        try:
            if cmd_type == "docker":
                result = subprocess.run(
                    ["docker", "inspect", "-f", "{{.State.Running}}", target],
                    capture_output=True, text=True, timeout=5,
                )
                return result.stdout.strip() == "true"
            elif cmd_type == "process":
                import os as _os
                if _os.path.isfile(target):
                    # PID file — check if process is alive
                    try:
                        pid = int(open(target).read().strip())
                        _os.kill(pid, 0)  # signal 0 = check existence
                        return True
                    except (ValueError, ProcessLookupError, FileNotFoundError):
                        return False
                else:
                    # GA-1: pgrep -f removed — PID file required for process type
                    logger.warning("process check_alive requires PID file path, got '%s'", target)
                    return False
            elif cmd_type == "launchd":
                result = subprocess.run(
                    ["launchctl", "list", target],
                    capture_output=True, timeout=5,
                )
                return result.returncode == 0
            elif cmd_type == "systemd":
                result = subprocess.run(
                    ["systemctl", "is-active", "--quiet", target],
                    capture_output=True, timeout=5,
                )
                return result.returncode == 0
            elif cmd_type == "k8s":
                result = subprocess.run(
                    ["kubectl", "get", "pod", target, "--no-headers",
                     "-o", "custom-columns=STATUS:.status.phase"],
                    capture_output=True, text=True, timeout=5,
                )
                return result.returncode == 0 and "Running" in result.stdout
            else:
                logger.warning("Unknown watch type '%s' — assuming alive", cmd_type)
                return True
        except Exception as e:
            logger.warning("_check_alive error for %s:%s: %s", cmd_type, target, e)
            return False
