"""
CLI entry point for clevagent-runner.

Usage:
  clevagent-runner start \
    --api-key "cv_xxx" \
    --watch "docker:my-trading-bot" \
    --watch "launchd:com.sean.crypto-paper-trade"

Each --watch entry is "type:target" where type is one of:
  docker    → Docker container name
  systemd   → systemd service name
  launchd   → launchd label (macOS)
  process   → process command substring (for pgrep -f)
  k8s       → Kubernetes pod name (check/restart) / deployment name (stop)
"""

import argparse
import logging
import os
import sys

from .runner import ClevAgentRunner


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="clevagent-runner",
        description="ClevAgent local runner — heartbeat proxy and remote restart executor.",
    )
    subparsers = parser.add_subparsers(dest="command")

    start = subparsers.add_parser("start", help="Start the runner daemon")
    start.add_argument("--api-key", default=None, help="ClevAgent project API key (cv_xxx). Falls back to CLEVAGENT_API_KEY env var.")
    start.add_argument(
        "--watch", action="append", metavar="TYPE:TARGET",
        help="Process to watch, e.g. 'docker:my-bot'. Repeatable.",
    )
    start.add_argument(
        "--endpoint", default="https://clevagent.io",
        help="ClevAgent server URL (default: https://clevagent.io)",
    )
    start.add_argument(
        "--heartbeat-interval", type=int, default=30,
        help="Heartbeat interval in seconds (default: 30)",
    )
    start.add_argument(
        "--log-level", default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s — %(message)s",
        stream=sys.stderr,  # launchd captures stderr to ErrorLogPath
    )

    # Resolve API key: --api-key flag → CLEVAGENT_API_KEY env var
    api_key = args.api_key or os.environ.get("CLEVAGENT_API_KEY")
    if not api_key:
        print("Error: --api-key or CLEVAGENT_API_KEY environment variable is required", file=sys.stderr)
        sys.exit(1)

    if not args.watch:
        print("Error: at least one --watch target is required", file=sys.stderr)
        sys.exit(1)

    watches = []
    for w in args.watch:
        if ":" not in w:
            print(f"Error: --watch '{w}' must be 'type:target' (e.g. docker:my-bot)", file=sys.stderr)
            sys.exit(1)
        watch_type, _, target = w.partition(":")
        if watch_type not in ("docker", "systemd", "launchd", "process", "k8s"):
            print(
                f"Error: unknown watch type '{watch_type}'. "
                "Must be docker, systemd, launchd, process, or k8s.",
                file=sys.stderr,
            )
            sys.exit(1)
        watches.append({"type": watch_type, "target": target})

    runner = ClevAgentRunner(
        api_key=api_key,
        watches=watches,
        endpoint=args.endpoint,
        heartbeat_interval=args.heartbeat_interval,
    )
    try:
        runner.run()
    except KeyboardInterrupt:
        print("\n[clevagent-runner] Stopped.")


if __name__ == "__main__":
    main()
