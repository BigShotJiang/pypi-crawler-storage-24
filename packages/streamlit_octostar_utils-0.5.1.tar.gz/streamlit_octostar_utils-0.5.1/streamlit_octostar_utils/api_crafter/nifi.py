from copy import deepcopy
import hashlib
import uuid
from functools import wraps
from contextlib import contextmanager
import json
import jwt
from typing import List, Union, Optional, Callable
from pydantic import BaseModel, ConfigDict, Field
import itertools
from enum import Enum
from typing import Dict, Any, Literal
from datetime import datetime, timezone, timedelta
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from octostar.utils.workspace import upsert_entities
from octostar.utils.ontology import fetch_ontology_data
from octostar.utils.pipeline import update_processing_status

from octostar.client import make_client

from ..core.dict import recursive_update_dict, travel_dict, jsondict_hash
from ..core.timestamp import now, string_to_datetime
from .fastapi import DefaultErrorRoute, Route
from ..ontology.inheritance import is_child_concept as is_child_concept_fn, get_label, get_label_keys
from .contents import Contents, WorkspaceAttachmentContents, TemporaryAttachmentContents, MemoryContents


class RelationshipName(BaseModel):
    name: str
    type: Literal["mtm", "otm"]


RELATIONSHIP_ENTITY_NAME = "os_relationship"
LOCAL_RELATIONSHIP_ENTITY_NAME = "os_workspace_relationship"
FILE_ENTITY_NAME = "os_file"
TAG_ENTITY_NAME = "os_tag"
FRAGMENT_ENTITY_NAME = "os_fragment"
GENERIC_RELATIONSHIP = RelationshipName(name="related_to", type="mtm")
FILE_RELATIONSHIP = RelationshipName(name="generator_of", type="mtm")
TAG_RELATIONSHIP = RelationshipName(name="has_tag", type="mtm")
FRAGMENT_RELATIONSHIP = RelationshipName(name="is_fragment_of", type="otm")
PREVIOUS_FRAGMENT_RELATIONSHIP = RelationshipName(name="has_previous_fragment", type="otm")
NEXT_FRAGMENT_RELATIONSHIP = RelationshipName(name="has_next_fragment", type="otm")
SOURCE_FRAGMENT_ENTITY_RELATIONSHIP = RelationshipName(name="is_child_fragment_of", type="otm")
OS_RESERVED_FIELDS = [
    "os_entity_uid", "entity_id", "entity_type", "os_concept",
    "entity_label", "os_created_at", "os_created_by",
    "os_last_updated_at", "os_last_updated_by",
]
MAX_IN_MEMORY_SIZE_BYTES = 5_242_880


class NifiProxyEntityModel(BaseModel):
    entity_id: str
    entity_type: str


class NifiOTMRelationshipProxyModel(BaseModel):
    os_entity_uid_from: str
    os_entity_type_from: str
    os_entity_uid_to: str
    os_entity_type_to: str
    os_relationship_name: str


class NifiEntityModel(BaseModel):
    class RequestModel(BaseModel):
        class OntologyInfoModel(BaseModel):
            parents: List[str]
            relationships: List[str]
            label_keys: List[str]

        jwt: Optional[str] = None
        ontology_name: str
        ontology_info: OntologyInfoModel
        entity_timestamp: Optional[str]
        sync_params: dict = Field(default_factory=dict)
        nifi_attributes: dict = Field(default_factory=dict)
        config: dict = Field(default_factory=dict)
        metrics: dict = Field(default_factory=dict)
        is_temporary: bool = False
        exception: dict = Field(default_factory=dict)
        last_processor_name: Optional[str] = None

    class RecordModel(BaseModel):
        model_config = ConfigDict(extra="allow")
        entity_id: str
        os_entity_uid: str
        entity_type: str
        os_concept: str
        os_workspace: Optional[str] = None
        entity_label: Optional[str] = None

    request: RequestModel
    record: RecordModel
    annotations: Dict[str, Any] = Field(default_factory=dict)
    children: List[Union[NifiOTMRelationshipProxyModel, NifiProxyEntityModel]] = []
    contents: Optional[Dict[str, Any]] = None


NifiEntityModel.model_rebuild()


class NifiOTMRelationshipProxy(object):
    def __init__(
        self,
        os_entity_uid_from,
        os_entity_type_from,
        os_entity_uid_to,
        os_entity_type_to,
        os_relationship_name,
        drop_on_output=False,
    ):
        self.record = {
            "os_entity_uid_from": os_entity_uid_from,
            "os_entity_type_from": os_entity_type_from,
            "os_entity_uid_to": os_entity_uid_to,
            "os_entity_type_to": os_entity_type_to,
            "os_relationship_name": os_relationship_name,
        }
        self.drop_on_output = drop_on_output


class NifiEntityProxy(object):
    def __init__(
        self,
        context,
        uid,
        entity_type,
        output_as_child,
        output_as_independent,
        drop_on_output,
        proxy=None,
    ):
        self.context = context
        self.uid = uid
        self.entity_type = entity_type
        self.output_as_child = output_as_child
        self.output_as_independent = output_as_independent
        self.drop_on_output = drop_on_output
        self._proxy = proxy

    def __eq__(self, other):
        if isinstance(other, NifiEntity):
            return self.uid == other.record["entity_id"]
        elif isinstance(other, NifiEntityProxy):
            return self.uid == other.uid
        else:
            return False

    def fetch_proxy(self):
        def _recursive_search_expanded_proxy(entity, uid_to_search):
            found_entity = None
            for child_entity in entity.children_entities:
                if child_entity._proxy:
                    if child_entity.uid == uid_to_search:
                        found_entity = child_entity
                    else:
                        found_entity = _recursive_search_expanded_proxy(child_entity._proxy, uid_to_search)
                if found_entity:
                    return found_entity

        if not self._proxy:
            main_entities = itertools.chain(*[b.entities for b in self.context.in_batches])
            main_entities = {e.record["entity_id"]: e for e in main_entities}
            if main_entities.get(self.uid):
                self._proxy = main_entities.get(self.uid)
                return self._proxy
            for entity in main_entities.values():
                found_entity = _recursive_search_expanded_proxy(entity, self.uid)
                if found_entity:
                    self._proxy = found_entity._proxy
                    return self._proxy
            ## TODO: Try to get the entity from the database with query_ontology()
            raise AttributeError(f"Cannot find children with UUID {self.uid}! It may exist in the database?")

    def __getattr__(self, name):
        if name in self.__dict__:
            return self.__dict__[name]
        else:
            if not self._proxy:
                self.fetch_proxy()
            return getattr(self._proxy, name)

    def __setattr__(self, name, value):
        if name in (
            "context",
            "uid",
            "entity_type",
            "output_as_child",
            "output_as_independent",
            "drop_on_output",
            "_proxy",
        ):
            super().__setattr__(name, value)
        else:
            if not self._proxy:
                self.fetch_proxy()
            setattr(self._proxy, name, value)


class NifiFragmenter(object):
    def as_nifi_fragments(fragments, fragmenter_keylist):
        count = len(fragments)
        if count < 2:
            raise ValueError("Must have at least 2 entities for fragmentation")
        if count > 100_000:
            raise ValueError("Cannot have more than 100k entities for fragmentation")
        identifier = str(uuid.uuid4())
        root_uid = fragments[0].record["os_entity_uid"]
        root_type = fragments[0].record["os_concept"]
        for i, entity in enumerate(fragments):
            travel_dict(entity.request["nifi_attributes"], fragmenter_keylist.split("."), "w")(
                {"identifier": identifier, "count": count, "index": i}
            )
            if "fragment" not in entity.request["config"]:
                entity.request["config"]["fragment"] = {}
            if "fragments_stack" not in entity.request["config"]["fragment"]:
                entity.request["config"]["fragment"]["fragments_stack"] = []
            entity.request["config"]["fragment"]["fragments_stack"].insert(0, fragmenter_keylist)
            entity.request["nifi_attributes"]["fragments_stack"] = entity.request["config"]["fragment"][
                "fragments_stack"
            ]
            travel_dict(entity.request["config"]["fragment"], fragmenter_keylist.split("."), "w")(
                {"identifier": identifier, "count": count, "index": i, "root_uid": root_uid, "root_type": root_type}
            )

    def push_defragment_strategy(fragment, defragmenter_config):
        pointer = fragment.request["config"]
        last_fragmenter_keylist = fragment.request["config"]["fragment"]["fragments_stack"][0]
        for k in ("fragment." + last_fragmenter_keylist).split("."):
            if not pointer.get(k):
                pointer[k] = {}
            pointer = pointer[k]
        pointer["merge_params"] = recursive_update_dict(
            pointer.get("merge_params") or {}, defragmenter_config, lambda _, v2: v2
        )

    _REQUIRED_FRAGMENT_FIELDS = ("index", "count", "identifier")

    @staticmethod
    def get_fragment_info(entity, fragmenter_keylist):
        """Read fragment metadata (identifier, count, index, root_uid, merge_params)
        for a given fragmenter level. Read-only -- does not mutate the entity.

        Args:
            entity: A NifiEntity or NifiEntityProxy.
            fragmenter_keylist: Dot-separated key path into the fragment config
                (e.g. "document_pages" or "audio_split").

        Returns:
            dict with keys like identifier, count, index, root_uid, merge_params.
            Empty dict if fragmenter_keylist is empty or intermediate keys are
            missing (entity not fragmented at this level).

        Raises:
            KeyError: If the final fragment key is missing from the config.
            ValueError: If the fragment info exists but lacks required fields
                (index, count, identifier).
        """
        if not fragmenter_keylist:
            return {}
        pointer = entity.request["config"]["fragment"]
        for k in fragmenter_keylist.split(".")[:-1]:
            if not pointer.get(k):
                return {}
            pointer = pointer[k]
        info = pointer[fragmenter_keylist.split(".")[-1]]
        missing = [f for f in NifiFragmenter._REQUIRED_FRAGMENT_FIELDS if f not in info]
        if missing:
            raise RuntimeError(
                f"Fragment info for '{fragmenter_keylist}' is missing required "
                f"field(s): {', '.join(missing)}"
            )
        return info

    @staticmethod
    def identify_fragment_groups(nifi_batches):
        """Find all fragmented entities grouped by their active fragmenter level.

        Args:
            nifi_batches: List of NifiEntityBatch objects.

        Returns:
            dict mapping fragmenter_keylist to list of entities at that level.
            Empty dict if no fragments found. Callers use get_fragment_info()
            to fetch metadata per entity, and filter by index==0 to find roots.
        """
        all_entities = list(itertools.chain(*[b.entities for b in nifi_batches]))
        groups = {}
        for e in all_entities:
            stack = e.request["config"].get("fragment", {}).get("fragments_stack", [])
            if stack:
                groups.setdefault(stack[0], []).append(e)
        return groups

    @staticmethod
    def build_fragment_tree_from_children_entities(root_entity, fragmenter_keylist):
        """Recursively build a tree from a root fragment entity by walking
        its children_entities.

        Args:
            root_entity: The root entity (index 0) to start from.
            fragmenter_keylist: The fragmenter level to build for.

        Returns:
            Nested dict with keys:
                "entity": NifiEntity/NifiEntityProxy
                "index": int
                "merge_params": dict or None
                "children": list of child trees
        """
        info = NifiFragmenter.get_fragment_info(root_entity, fragmenter_keylist)
        child_fragments = []
        for e in root_entity.children_entities:
            try:
                child_info = NifiFragmenter.get_fragment_info(e, fragmenter_keylist)
                if child_info:
                    child_fragments.append(e)
            except (AttributeError, KeyError):
                pass
        return {
            "entity": root_entity,
            "index": info.get("index"),
            "merge_params": info.get("merge_params"),
            "children": [
                NifiFragmenter.build_fragment_tree_from_children_entities(child, fragmenter_keylist)
                for child in child_fragments
            ],
        }

    @staticmethod
    def extract_tree_entities(tree):
        """Flatten a fragment tree into a list of all entities (pre-order).

        Args:
            tree: Fragment tree node (from build_fragment_tree_from_children_entities).

        Returns:
            List of entities in pre-order traversal.
        """
        entities = [tree["entity"]]
        for child in tree.get("children", []):
            entities.extend(NifiFragmenter.extract_tree_entities(child))
        return entities

    @staticmethod
    def iterate_fragments_tree(tree, order="post"):
        """Yield tree nodes in traversal order.

        Args:
            tree: Fragment tree node (from build_fragment_tree_from_children_entities).
            order: "post" (children first, default) or "pre" (parent first).

        Yields:
            dict nodes with "entity", "index", "merge_params", "children" keys.
        """
        children = sorted(tree.get("children", []), key=lambda x: x["index"])
        if order == "pre":
            yield tree
        for child in children:
            yield from NifiFragmenter.iterate_fragments_tree(child, order)
        if order == "post":
            yield tree

    @staticmethod
    def reduce_fragments_tree(tree, leaf_fn, parent_fn):
        """Bottom-up tree reduction. Processes leaves first, then folds results up.

        Args:
            tree: Fragment tree node (from build_fragment_tree_from_children_entities).
            leaf_fn: Callable(node) -> result, called on nodes with no children.
            parent_fn: Callable(node, child_results) -> result, called on
                nodes with children. child_results is a list of results from
                child nodes, sorted by index.

        Returns:
            The result from the root node.
        """
        children = sorted(tree.get("children", []), key=lambda x: x["index"])
        if not children:
            return leaf_fn(tree)
        child_results = [
            NifiFragmenter.reduce_fragments_tree(child, leaf_fn, parent_fn)
            for child in children
        ]
        return parent_fn(tree, child_results)

    _FRAGMENTS_NAMESPACE = b"octostar.pipeline.fragments"

    @staticmethod
    def _create_deterministic_uuid(namespace: bytes, data: bytes):
        return str(
            uuid.uuid5(
                uuid.UUID(bytes=hashlib.md5(namespace).digest()),
                hashlib.md5(data).hexdigest(),
            )
        )

    @staticmethod
    def create_fragment_uuid(os_entity_uid, stable_fragment_identifier, processor_name, os_workspace):
        """Create a deterministic UUID for a fragment.

        The UUID is stable across re-runs for the same entity, fragment
        identifier, processor, and workspace -- enabling idempotent fragment
        creation while ensuring uniqueness across workspaces.

        Args:
            os_entity_uid: The parent entity UID.
            stable_fragment_identifier: A unique and stable identifier within
                the fragmentation (e.g. page range, keyframe number, face index).
            processor_name: Name of the NiFi processor.
            os_workspace: The workspace UID the fragment will be written to.

        Returns:
            A deterministic UUID string.
        """
        return NifiFragmenter._create_deterministic_uuid(
            NifiFragmenter._FRAGMENTS_NAMESPACE,
            (processor_name + "::" + os_workspace + "::" + os_entity_uid + "::" + stable_fragment_identifier).encode("utf-8"),
        )

    @staticmethod
    def resolve_source_entity(entity, fragment_root_source=None) -> tuple:
        """Resolve the source entity (recursive originator) for child fragments.

        When fragment_root_source is set (a fragment name or stack index),
        the root is looked up via entity.get_fragment_root().  When it is
        None and the entity is already fragmented, the oldest fragmentation
        level's root is used (the original non-fragment ancestor).  Otherwise
        falls back to the entity itself.

        Args:
            entity: A NifiEntity or NifiEntityProxy.
            fragment_root_source: None for automatic resolution, an int
                to index into the fragments stack, or a string fragmenter
                keylist name.

        Returns:
            (source_entity_uid, source_entity_type) tuple.
        """
        if fragment_root_source is not None:
            try:
                idx = int(fragment_root_source)
                return entity.get_fragment_root(idx)
            except (ValueError, TypeError):
                return entity.get_fragment_root(fragment_root_source)
        stack = entity.request.get("config", {}).get("fragment", {}).get("fragments_stack", [])
        if stack:
            return entity.get_fragment_root(-1)
        return (entity.record["os_entity_uid"], entity.record["os_concept"])


class NifiEntityBatch(object):
    def __init__(self, entities, config, config_key):
        self.config = config
        self.entities = entities
        self.config_key = config_key


class NifiContextManager(object):
    HEADLESS_PROCESSOR_NAME = "headless"

    class SyncFlag(Enum):
        UPSERT_ENTITY_ALL = 0  # bool
        UPSERT_ENTITY_SPECIFIC_FIELDS = 1  # 'fields': list of record fields
        WRITE_CONTENTS = 10  # bool
        FETCH_RELATIONSHIPS = 20  # 'relationships': list of relationship names

    def __init__(self, json_data, lazy_sync=True):
        if not json_data:
            raise ValueError("Nifi context manager received list of 0 entities")
        self.in_batches = None
        self.out_entities = None
        self.nonlazy_sync_ids = set()
        self.lazy_sync = lazy_sync
        self.client, self.ontology_name = self.get_client(json_data)
        self._ontology = None

    @property
    def ontology(self):
        if not self._ontology:
            self._ontology = fetch_ontology_data.sync(ontology_name=self.ontology_name, client=self.client)
        return self._ontology

    def _config_get(entity, keylist):
        if keylist == NifiContextManager.HEADLESS_PROCESSOR_NAME:
            return {}
        config = entity.request["config"]
        return travel_dict(config, keylist.split("."), mode="r", default={})

    def get_client(self, json_data):
        all_jwts = [e["request"].get("jwt") for e in json_data]
        all_jwts = [j for j in all_jwts if j]
        assert len(set(all_jwts)) == 1  # jwt must be unique
        all_ontology_names = [e["request"].get("ontology_name") for e in json_data]
        all_ontology_names = [j for j in all_ontology_names if j]
        assert len(set(all_ontology_names)) == 1  # ontology name must be unique
        curr_user_jwt = all_jwts[0]
        curr_user_ontology = all_ontology_names[0]
        client = make_client(fixed_jwt=curr_user_jwt, ontology_name=curr_user_ontology)
        return client, curr_user_ontology

    def receive_input(self, json_data, processor_name) -> List["NifiEntityBatch"]:
        entities = []
        all_independent_uids = [e["record"]["entity_id"] for e in json_data]
        for elem in json_data:
            contents = Contents.from_locator(elem.get("contents"), client=self.client)
            entities.append(
                NifiEntity(
                    self,
                    elem["request"],
                    elem["record"],
                    elem["annotations"],
                    all_independent_uids,
                    elem["children"],
                    contents,
                )
            )
        entities = sorted(
            entities,
            key=lambda x: string_to_datetime(x.request.get("entity_timestamp")),
        )
        entities = list({e.record["entity_id"]: e for e in entities}.values())
        entities = [
            (
                jsondict_hash(NifiContextManager._config_get(entity, processor_name)),
                entity,
            )
            for entity in entities
        ]
        entities = sorted(entities, key=lambda x: x[0])
        grouped_entities = []
        for _, group in itertools.groupby(entities, key=lambda x: x[0]):
            group = [e[1] for e in group]
            grouped_entities.append(
                NifiEntityBatch(
                    group,
                    NifiContextManager._config_get(group[0], processor_name),
                    processor_name,
                )
            )
        self.in_batches = grouped_entities
        return self.in_batches

    def __enter__(self):
        return self

    def request_entity_sync(
        self,
        entity,
        parametrized_flags: Dict[SyncFlag, Any],
        merge_method=lambda _, v2: v2,
        now=False,
    ):
        entity.sync_params = recursive_update_dict(
            entity.request.get("sync_params") or {}, parametrized_flags, merge_method
        )
        if now:
            self.nonlazy_sync_ids.add(entity.record["entity_id"])

    def send_output(self, entity_batches, processor_name):
        def _process_entity(entity, processor_name):
            entities = []
            if processor_name != NifiContextManager.HEADLESS_PROCESSOR_NAME:
                entity.request["last_processor_name"] = processor_name
            entities.append(entity)
            for child_entity in entity.children_entities:
                if not child_entity.drop_on_output:
                    if child_entity.output_as_independent or child_entity.output_as_child:
                        if processor_name != NifiContextManager.HEADLESS_PROCESSOR_NAME:
                            child_entity.request["last_processor_name"] = processor_name
                    if child_entity.output_as_independent:
                        if not child_entity._proxy:
                            child_entity.fetch_proxy()
                        entities.extend(_process_entity(child_entity._proxy, processor_name))
            return entities

        entities = itertools.chain(*[b.entities for b in entity_batches])
        all_entities = []
        for entity in entities:
            all_entities.extend(_process_entity(entity, processor_name))
        all_entities = sorted(
            all_entities,
            key=lambda x: string_to_datetime(x.request.get("entity_timestamp")),
        )
        self.out_entities = list({e.record["entity_id"]: e for e in all_entities}.values())
        self.sync_entities()
        return [entity for entity in self.jsonify(self.out_entities)["content"]]

    def raise_exception(self, entity, exc):
        error_response = DefaultErrorRoute.format_error(exc, internal=True)
        error_body = json.loads(error_response.body)
        entity.request["exception"]["code"] = error_response.status_code
        entity.request["exception"]["body"] = error_body["message"]
        entity.request["exception"]["exception_class"] = error_body.get("exception_class")
        entity.request["exception"]["traceback"] = error_body.get("traceback")
        travel_dict(entity.request["nifi_attributes"], ["invokehttp", "response", "body"], "w")(
            entity.request["exception"]["body"]
        )
        travel_dict(entity.request["nifi_attributes"], ["invokehttp", "response", "code"], "w")(
            entity.request["exception"]["code"]
        )
        entity.request["nifi_attributes"]["raised_exc"] = True

    @contextmanager
    def reindex_lock(self, entities: List[Union[dict, "NifiEntity"]], timeout: int = 7200):
        if not entities:
            yield True
            return

        import logging
        _lock_logger = logging.getLogger(__name__)

        records = []
        for e in entities:
            if isinstance(e, dict):
                records.append(
                    (e, e.get("entity_timestamp"))
                )
            else:
                records.append(
                    (e.record, e.request.get("entity_timestamp") if e.request else None)
                )

        long_expiry = (datetime.now(timezone.utc) + timedelta(seconds=timeout)).strftime("%Y-%m-%dT%H:%M:%SZ")
        statuses = [
            {
                "entity_id": rec["os_entity_uid"],
                "entity_type": rec["os_concept"],
                "do_not_update_before": ts,
                "do_not_reindex_before": long_expiry,
            }
            for rec, ts in records
            if ts is not None
        ]
        if len(statuses) < len(records):
            missing = [rec["os_entity_uid"] for rec, ts in records if ts is None]
            _lock_logger.warning(
                f"reindex_lock: {len(missing)} entities have no entity_timestamp, cannot set lock: {missing}"
            )
        if not statuses:
            yield True
            return

        result = update_processing_status.sync(statuses, client=self.client)
        skipped_ids = result.get("skipped_entity_ids", []) if isinstance(result, dict) else []
        if skipped_ids:
            _lock_logger.warning(
                f"reindex_lock: {len(skipped_ids)} entities have a newer pipeline run, aborting sync: {skipped_ids}"
            )
            yield False
            return

        try:
            yield True
        finally:
            short_expiry = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            statuses = [
                {
                    "entity_id": rec["os_entity_uid"],
                    "entity_type": rec["os_concept"],
                    "do_not_update_before": ts,
                    "do_not_reindex_before": short_expiry,
                }
                for rec, ts in records
                if ts is not None
            ]
            if statuses:
                update_processing_status.sync(statuses, client=self.client)

    def sync_entities(self):
        if not self.lazy_sync:
            entities = self.out_entities
        else:
            entities = [e for e in self.out_entities if e.record["entity_id"] in self.nonlazy_sync_ids]
        if not entities:
            return

        attachables_to_write = self._find_attachables_to_write(entities)
        entities_to_upsert = self._find_entities_to_upsert(entities)
        fetch_rel_entities, fetch_concept_rels = self._find_relationships_to_fetch(entities)

        all_entities_to_modify = attachables_to_write + [e[0] for e in entities_to_upsert]
        with self.reindex_lock(all_entities_to_modify) as locked:
            if not locked:
                return
            self._sync_write_attachables(attachables_to_write)
            self._sync_upsert_entities(entities_to_upsert)
        self._sync_fetch_relationships(entities, fetch_rel_entities, fetch_concept_rels)

        now_ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        for entity in all_entities_to_modify:
            entity.request["is_temporary"] = False
            entity.request["entity_timestamp"] = now_ts

        for entity in entities:
            entity.sync_params = {}

    def _find_attachables_to_write(self, entities) -> list:
        attachables_to_write = []
        for entity in entities:
            if entity.sync_params.get(NifiContextManager.SyncFlag.WRITE_CONTENTS):
                if entity.contents:
                    attachables_to_write.append(entity)
        return attachables_to_write

    def _sync_write_attachables(self, attachables_to_write):
        for file in attachables_to_write:
            if not file.contents:
                continue
            old_contents = file._contents
            record = file.record
            ws = file.write_os_workspace
            entity_uid = record["os_entity_uid"]
            entity_type = record["os_concept"]
            filetype = record.get("os_item_content_type")
            data = old_contents.getvalue()
            target = WorkspaceAttachmentContents(
                workspace_id=ws,
                entity_id=entity_uid,
                client=self.client,
                entity_type=entity_type,
                filetype=filetype,
                fields=record,
            )
            target.truncate(0)
            target.write(data)
            target.flush()
            file._contents = target
            if isinstance(old_contents, TemporaryAttachmentContents):
                try:
                    old_contents.delete()
                except Exception:
                    pass
            new_entity = target.last_flush_result
            if new_entity:
                file.record = {**record, **new_entity}
                file.record["entity_id"] = file.record["os_entity_uid"]
                file.record["entity_type"] = file.record["os_concept"]
                file.record["entity_label"] = file.label
            file.request["entity_timestamp"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            file.request["is_temporary"] = False

    def _sync_upsert_entities(self, entities_to_upsert):
        if not entities_to_upsert:
            return
        new_entities = upsert_entities.sync(
            [entity.write_os_workspace for entity, _ in entities_to_upsert],
            [
                {
                    "entity_type": entity.record["os_concept"],
                    "os_entity_uid": entity.record["os_entity_uid"],
                    "fields": {k: entity.record.get(k) for k in fields},
                }
                for entity, fields in entities_to_upsert
            ],
            client=self.client,
        )
        new_entities = {e["os_entity_uid"]: e for e in new_entities}
        for entity, _ in entities_to_upsert:
            entity.record = {**entity.record, **new_entities[entity.record["os_entity_uid"]]}
            entity.record["entity_id"] = entity.record["os_entity_uid"]
            entity.record["entity_type"] = entity.record["os_concept"]
            entity.record["entity_label"] = entity.label
            entity.request["entity_timestamp"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            entity.request["is_temporary"] = False

    def _find_relationships_to_fetch(self, entities) -> dict:
        fetch_relationships_entities = {}
        fetch_concept_relationships = {}
        for entity in entities:
            if entity.sync_params.get(NifiContextManager.SyncFlag.FETCH_RELATIONSHIPS):
                concept_name = entity.record["entity_type"]
                rels_to_fetch = entity.sync_params.get(NifiContextManager.SyncFlag.FETCH_RELATIONSHIPS, [])
                for rel in rels_to_fetch:
                    if rel not in fetch_relationships_entities:
                        fetch_relationships_entities[rel] = []
                    fetch_relationships_entities[rel].append(entity)
                if concept_name not in fetch_concept_relationships:
                    fetch_concept_relationships[concept_name] = set()
                fetch_concept_relationships[concept_name] = fetch_concept_relationships[concept_name].union(
                    set(rels_to_fetch)
                )
        for k in fetch_concept_relationships.keys():
            fetch_concept_relationships[k] = list(fetch_concept_relationships[k])
        return fetch_relationships_entities, fetch_concept_relationships

    def _sync_fetch_relationships(self, entities, fetch_relationships_entities, fetch_concept_relationships):
        if not fetch_relationships_entities:
            return
        raise NotImplementedError("Relationship fetching is not yet implemented")

    def _find_entities_to_upsert(self, entities) -> list:
        entities_to_upsert = []
        for entity in entities:
            fields = set()

            if entity.sync_params.get(NifiContextManager.SyncFlag.UPSERT_ENTITY_ALL):
                fields = fields.union(set(list(entity.record.keys())))

            if entity.sync_params.get(NifiContextManager.SyncFlag.UPSERT_ENTITY_SPECIFIC_FIELDS):
                fields = fields.union(
                    set(
                        entity.sync_params.get(
                            NifiContextManager.SyncFlag.UPSERT_ENTITY_SPECIFIC_FIELDS,
                            {},
                        ).get("fields")
                        or []
                    )
                )
            if fields:
                entities_to_upsert.append((entity, [f for f in list(fields) if f not in OS_RESERVED_FIELDS]))
        return entities_to_upsert

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_val is not None:
            return False
        if self.out_entities is None:
            raise AssertionError("Entities must be returned to the nifi context!")

    def jsonify(self, entities):
        def _recursive_collect_proxies(entities):
            children = []
            for entity in entities:
                if isinstance(entity, NifiEntityProxy):
                    children.extend(entity.children_entities)
                    children.extend(_recursive_collect_proxies(entity.children_entities))
            return children

        all_proxies = _recursive_collect_proxies(entities)
        banned_entities = [e for e in all_proxies if not e.output_as_independent]
        entities = [e for e in entities if e not in banned_entities]
        return {
            "content": [e for e in [entity.to_json() for entity in entities] if e],
            "media_type": "application/json",
        }


class NifiEntity(object):
    def __init__(self, context, request, record, annotations, all_independent_uids, children=[], contents=None):
        self.context = context
        self.request = request
        self.record = record
        self._annotations = annotations
        assert (
            self.record.get("os_entity_uid")
            and self.record.get("entity_id")
            and self.record["os_entity_uid"] == self.record["entity_id"]
        )
        assert (
            self.record.get("os_concept")
            and self.record.get("entity_type")
            and self.record["os_concept"] == self.record["entity_type"]
        )
        if "entity_label" not in self.record:
            self.record["entity_label"] = self.label
        children = [c for c in children if isinstance(c, (str, dict))]
        full_entity_children = []
        proxy_otm_children = []
        proxy_entity_children = []
        for child in children:
            if "os_relationship_name" in child:
                proxy_otm_children.append(child)
            elif "request" in child:
                full_entity_children.append(child)
            else:
                proxy_entity_children.append(child)
        child_uids = [c["entity_id"] for c in proxy_entity_children] + [
            c["record"]["entity_id"] for c in full_entity_children
        ]
        child_types = [c["entity_type"] for c in proxy_entity_children] + [
            c["record"]["entity_type"] for c in full_entity_children
        ]
        output_as_child = [False] * len(proxy_entity_children) + [True] * len(full_entity_children)
        output_as_independent = [uid in all_independent_uids for uid in child_uids]
        full_entity_children = [
            NifiEntity(
                self.context,
                c["request"],
                c["record"],
                c["annotations"],
                all_independent_uids,
                c["children"],
                Contents.from_locator(c.get("contents"), client=self.context.client),
            )
            for c in full_entity_children
        ]
        proxy_otm_children = [NifiOTMRelationshipProxy(**otm_child) for otm_child in proxy_otm_children]
        child_proxies = [None] * len(proxy_entity_children) + full_entity_children
        self.children = [
            NifiEntityProxy(
                self.context,
                child_uids[i],
                child_types[i],
                output_as_child[i],
                output_as_independent[i],
                False,
                child_proxies[i],
            )
            for i in range(len(child_uids))
        ]
        self.children.extend(proxy_otm_children)
        self._contents: Optional[Contents] = contents
        self.drop_on_output = False

    def __eq__(self, other):
        if isinstance(other, NifiEntity):
            return self.record["entity_id"] == other.record["entity_id"]
        elif isinstance(other, NifiEntityProxy):
            return self.record["entity_id"] == other.uid
        else:
            return False

    @property
    def sync_params(self):
        return {NifiContextManager.SyncFlag[k]: v for k, v in (self.request.get("sync_params") or {}).items()}

    @sync_params.setter
    def sync_params(self, new_params):
        self.request["sync_params"] = {
            (k.name if isinstance(k, NifiContextManager.SyncFlag) else k): v for k, v in new_params.items()
        }

    @property
    def annotations(self):
        return self._annotations

    @annotations.setter
    def annotations(self, new_annotations):
        self._annotations = new_annotations

    @property
    def contents(self) -> Optional[Contents]:
        return self._contents

    @contents.setter
    def contents(self, new_contents: Optional[Contents]):
        self._contents = new_contents

    @property
    def children_entities(self):
        return list(filter(lambda x: isinstance(x, NifiEntityProxy), self.children))

    @property
    def relationships(self):
        return list(
            filter(
                lambda x: isinstance(x, NifiOTMRelationshipProxy)
                or is_child_concept_fn(x.entity_type, RELATIONSHIP_ENTITY_NAME, self.context.ontology),
                self.children,
            )
        )

    @property
    def write_os_workspace(self):
        return self.record.get("os_workspace")

    @property
    def label(self):
        entity_type = self.record["entity_type"]
        parents = self.request["ontology_info"]["parents"]
        label_keys = self.request["ontology_info"]["label_keys"]
        # dummy ontology from our cached data, compatible with get_label()
        ontology = {
            "concepts": {
                **{p: {"parents": [], "labelKeys": []} for p in parents},
                entity_type: {"parents": parents, "labelKeys": label_keys},
            }
        }
        return get_label(self.record, ontology)

    @property
    def filepath(self):
        return self.record.get("#path") or self.label

    @property
    def jwt_data(self):
        return jwt.decode(
            self.request["jwt"],
            algorithms=["ES256"],
            options={"verify_signature": False},
        )

    def update_last_timestamp(self):
        self.record["os_last_updated_at"] = now()

    def is_child_concept(self, type):
        entity_type = None
        if isinstance(self, NifiEntityProxy):
            entity_type = self.entity_type
            return entity_type == type or is_child_concept_fn(entity_type, type, self.context.ontology)
        else:
            entity_type = self.record["entity_type"]
            return entity_type == type or type in self.request["ontology_info"]["parents"]

    def is_fragmented(self, fragment_name_or_idx=None) -> bool:
        """Check whether this entity is part of a fragmentation.

        Args:
            fragment_name_or_idx: If None (default), returns True if the entity
                belongs to any fragmentation level. If an int, checks whether the
                fragments_stack has an entry at that index. If a string, checks
                whether that fragmenter keylist is present in the stack.

        Returns:
            True if the entity is fragmented (at the specified level, if given).
        """
        stack = self.request["config"].get("fragment", {}).get("fragments_stack", [])
        if fragment_name_or_idx is None:
            return bool(stack)
        if isinstance(fragment_name_or_idx, int):
            return abs(fragment_name_or_idx) <= len(stack)
        return fragment_name_or_idx in stack

    def is_root_fragment(self, fragment_name_or_idx=-1, recurse=True) -> bool:
        """Check whether this entity is a root fragment (index == 0).

        Args:
            fragment_name_or_idx: Which fragmentation level to check. An int
                indexes into fragments_stack (default -1 = oldest level),
                a string matches by fragmenter keylist name.
            recurse: If True (default), check from the starting level towards
                index 0 (most recent) and return True only if the entity is
                root at every checked level. If False, only check the single
                specified level.

        Returns:
            True if the entity is a root fragment at the specified level(s),
            or if the entity is not fragmented at all.
        """
        if not self.is_fragmented():
            return True
        fragments_stack = self.request["config"]["fragment"]["fragments_stack"]

        if isinstance(fragment_name_or_idx, int):
            try:
                resolved = (
                    fragment_name_or_idx
                    if fragment_name_or_idx >= 0
                    else len(fragments_stack) + fragment_name_or_idx
                )
                key = fragments_stack[resolved]
            except (IndexError, ValueError):
                return True
        else:
            key = fragment_name_or_idx
            if key not in fragments_stack:
                return True
            resolved = fragments_stack.index(key)

        if recurse:
            keys_to_check = fragments_stack[:resolved + 1]
            return all(
                NifiFragmenter.get_fragment_info(self, k).get("index", 0) == 0
                for k in keys_to_check
            )
        return NifiFragmenter.get_fragment_info(self, key).get("index", 0) == 0

    def get_fragment_root(self, fragment_name_or_idx) -> tuple:
        """Return (root_uid, root_type) for a given fragmentation level.

        Args:
            fragment_name_or_idx: An int to index into fragments_stack
                (e.g. -1 for the oldest fragmentation), or a string
                fragmenter keylist name.

        Returns:
            (root_uid, root_type) tuple for the root entity at that level.
        """
        fragment_config = self.request.get("config", {}).get("fragment", {})
        fragments_stack = fragment_config.get("fragments_stack", [])
        if isinstance(fragment_name_or_idx, int):
            try:
                fragment_key = fragments_stack[fragment_name_or_idx]
            except IndexError:
                raise IndexError(
                    f"Fragment stack index {fragment_name_or_idx} out of range "
                    f"(stack size: {len(fragments_stack)})"
                )
        else:
            fragment_key = fragment_name_or_idx
            if fragment_key not in fragments_stack:
                raise KeyError(
                    f"Fragment '{fragment_key}' not found in "
                    f"fragments_stack: {fragments_stack}"
                )
        fragment_data = travel_dict(
            fragment_config, fragment_key.split("."), mode="r"
        )
        if not isinstance(fragment_data, dict) or "root_uid" not in fragment_data:
            raise KeyError(
                f"No root_uid found in fragment config for '{fragment_key}'"
            )
        return (
            fragment_data["root_uid"],
            fragment_data.get("root_type", "os_fragment"),
        )

    def to_json(self):
        if self.drop_on_output:
            return
        proxy_entity_children = []
        proxy_otm_children = []
        full_entity_children = []
        for child in self.children:
            if isinstance(child, NifiOTMRelationshipProxy):
                proxy_otm_children.append(child)
            else:
                if child.drop_on_output:
                    pass
                elif child.output_as_child:
                    child.fetch_proxy()
                    full_entity_children.append(child)
                else:
                    proxy_entity_children.append(child)
        proxy_entity_children = list({c.uid: c for c in proxy_entity_children}.values())
        proxy_entity_children = [{"entity_id": c.uid, "entity_type": c.entity_type} for c in proxy_entity_children]
        proxy_otm_children = list(
            {
                c.record["os_entity_uid_from"]
                + "|"
                + c.record["os_relationship_name"]
                + "|"
                + c.record["os_entity_uid_to"]: c
                for c in proxy_otm_children
            }.values()
        )
        proxy_otm_children = [c.record for c in proxy_otm_children]
        full_entity_children = sorted(
            full_entity_children,
            key=lambda x: string_to_datetime(x.request.get("entity_timestamp")),
        )
        full_entity_children = list({c.uid: c.to_json() for c in full_entity_children}.values())
        children = full_entity_children + proxy_entity_children + proxy_otm_children
        return {
            "request": self.request,
            "record": self.record,
            "children": children,
            "annotations": self.annotations,
            "contents": self._contents.to_locator() if self._contents is not None else None,
        }

    def _add_entity(self, os_workspace, entity_type, fields, os_entity_uid=None):
        now_time = now()
        if not os_entity_uid:
            os_entity_uid = str(uuid.uuid4())
        username = self.jwt_data["username"]
        if entity_type == self.record["entity_type"]:
            ont_parents = self.request["ontology_info"]["parents"]
            ont_relationships = self.request["ontology_info"]["relationships"]
            ont_label_keys = self.request["ontology_info"]["label_keys"]
        else:
            ont_parents = self.context.ontology["concepts"][entity_type]["parents"]
            ont_relationships = self.context.ontology["concepts"][entity_type]["relationships"]
            ont_label_keys = get_label_keys(entity_type, self.context.ontology)
        child_request = {
            "jwt": self.request["jwt"],
            "ontology_name": self.request["ontology_name"],
            "ontology_info": {
                "parents": ont_parents,
                "relationships": ont_relationships,
                "label_keys": ont_label_keys,
            },
            "entity_timestamp": self.request.get("entity_timestamp"),
            "sync_params": {
                NifiContextManager.SyncFlag.UPSERT_ENTITY_ALL.name: True,
            },
            "nifi_attributes": {},
            "config": deepcopy(self.request["config"]),
            "metrics": {},
            "is_temporary": True,
            "exception": {},
            "last_processor_name": None,
        }
        child_entity = NifiEntity(
            self.context,
            child_request,
            {
                **fields,
                "os_workspace": os_workspace,
                "os_concept": entity_type,
                "entity_type": entity_type,
                "os_entity_uid": os_entity_uid,
                "entity_id": os_entity_uid,
                "os_created_at": now_time,
                "os_created_by": username,
                "os_last_updated_at": now_time,
                "os_last_updated_by": username,
            },
            {},
            [],
        )
        child_entity.record["entity_label"] = child_entity.label
        child_entity_proxy = NifiEntityProxy(
            self.context,
            child_entity.record["entity_id"],
            child_entity.record["entity_type"],
            True,
            False,
            False,
            child_entity,
        )
        self.children.append(child_entity_proxy)
        return child_entity_proxy

    def prepare_contents(
        self,
        file: Union[Contents, bytes],
        entity_type: str,
        filetype: str,
        temp_blob_key: Optional[str] = None,
    ) -> Contents:
        """Build a Contents object from raw bytes, mirroring the same
        MemoryContents / TemporaryAttachmentContents logic used internally.

        Thread-safe: each call creates independent objects keyed by
        *temp_blob_key* (for large blobs) and does not mutate the entity tree.
        The returned Contents can later be passed to ``add_child_fragment``
        or ``add_child_file`` to skip the redundant bytes→Contents conversion.

        Args:
            file: A Contents object (returned as-is) or raw bytes.
            entity_type: Concept / entity type for the contents metadata.
            filetype: MIME type for the contents metadata.
            temp_blob_key: Unique key for the temporary blob when the data
                exceeds the in-memory threshold.  Defaults to a random UUID.
        """
        if isinstance(file, Contents):
            return file
        if len(file) <= MAX_IN_MEMORY_SIZE_BYTES:
            return MemoryContents(
                entity_type=entity_type,
                filetype=filetype,
                initial_data=file,
            )
        temp_filename = temp_blob_key or f"tmp_{uuid.uuid4()}"
        temp_contents = TemporaryAttachmentContents(
            entity_type=entity_type,
            filetype=filetype,
            filename=temp_filename,
            client=self.context.client,
        )
        temp_contents.truncate(0)
        temp_contents.write(file)
        temp_contents.flush()
        return temp_contents

    def _add_child_attachable(
        self,
        os_workspace,
        filename,
        filetype,
        file: Union[Contents, bytes],
        fields={},
        relationship: RelationshipName = FILE_RELATIONSHIP,
        os_entity_uid=None,
        os_relationship_uid=None,
        os_entity_type=FILE_ENTITY_NAME,
    ):
        child_entity, child_rel = self.add_child_entity(
            os_workspace,
            os_entity_type,
            {
                **fields,
                "os_item_name": filename,
                "os_item_content_type": filetype,
                "os_has_attachment": True,
            },
            relationship,
            os_entity_uid,
            os_relationship_uid,
        )
        if isinstance(file, Contents):
            child_entity._contents = file
        else:
            child_entity._contents = self.prepare_contents(
                file, os_entity_type, filetype,
                temp_blob_key=f"tmp_{child_entity.record['os_entity_uid']}",
            )
        child_entity.sync_params = recursive_update_dict(
            child_entity.sync_params,
            {NifiContextManager.SyncFlag.WRITE_CONTENTS: True},
            lambda _, v2: v2
        )
        return child_entity, child_rel

    def add_mtm_relationship(
        self,
        os_entity_uid_from,
        entity_type_from,
        os_entity_uid_to,
        entity_type_to,
        os_relationship_name,
        os_relationship_workspace,
        relationship_fields,
        os_relationship_uid=None,
    ):
        return self._add_entity(
            os_relationship_workspace,
            LOCAL_RELATIONSHIP_ENTITY_NAME,
            {
                **relationship_fields,
                "os_entity_uid_from": os_entity_uid_from,
                "os_entity_type_from": entity_type_from,
                "os_entity_uid_to": os_entity_uid_to,
                "os_entity_type_to": entity_type_to,
                "os_relationship_name": os_relationship_name,
            },
            os_relationship_uid
        )

    def add_otm_relationship(
        self,
        os_entity_uid_from,
        entity_type_from,
        os_entity_uid_to,
        entity_type_to,
        os_relationship_name,
    ):
        new_rel = NifiOTMRelationshipProxy(
            os_entity_uid_from,
            entity_type_from,
            os_entity_uid_to,
            entity_type_to,
            os_relationship_name,
        )
        self.children.append(new_rel)
        return new_rel

    def add_child_entity(
        self,
        os_workspace,
        entity_type,
        fields,
        relationship: RelationshipName = GENERIC_RELATIONSHIP,
        os_entity_uid=None,
        os_relationship_uid=None,
        relationship_fields={},
    ):
        child_entity = self._add_entity(os_workspace, entity_type, fields, os_entity_uid)
        child_rel = self._add_relationship(
            os_workspace,
            self.record["os_entity_uid"],
            self.record["os_concept"],
            child_entity.record["os_entity_uid"],
            child_entity.record["os_concept"],
            relationship,
            relationship_fields,
            os_relationship_uid,
        )
        return child_entity, child_rel

    def add_child_file(
        self,
        os_workspace,
        os_parent_folder,
        filename,
        filetype,
        file: Union[Contents, bytes],
        fields={},
        relationship: RelationshipName = FILE_RELATIONSHIP,
        os_entity_uid=None,
        os_relationship_uid=None,
        os_entity_type=FILE_ENTITY_NAME,
    ):
        return self._add_child_attachable(
            os_workspace,
            filename,
            filetype,
            file,
            {**fields, "os_parent_folder": os_parent_folder},
            relationship,
            os_entity_uid,
            os_relationship_uid,
            os_entity_type
        )

    def _add_relationship(self, os_workspace, from_uid, from_type, to_uid, to_type, rel, relationship_fields={}, rel_uid=None):
        if rel.type == "mtm":
            return self.add_mtm_relationship(from_uid, from_type, to_uid, to_type, rel.name, os_workspace, relationship_fields, rel_uid)
        elif rel.type == "otm":
            return self.add_otm_relationship(from_uid, from_type, to_uid, to_type, rel.name)
        else:
            raise ValueError(f"relationship.type is invalid! {rel.type}")

    def add_child_fragment(
        self,
        os_workspace,
        source_entity_uid,
        source_entity_type,
        filename,
        filetype,
        file: Union[Contents, bytes],
        fields={},
        relationship: RelationshipName = FRAGMENT_RELATIONSHIP,
        os_entity_uid=None,
        os_relationship_uid=None,
        os_entity_type=FRAGMENT_ENTITY_NAME,
        previous_fragment_uid=None,
        previous_fragment_relationship_uid=None,
        previous_fragment_relationship=PREVIOUS_FRAGMENT_RELATIONSHIP,
        next_fragment_uid=None,
        next_fragment_relationship_uid=None,
        next_fragment_relationship=NEXT_FRAGMENT_RELATIONSHIP,
        source_entity_relationship_uid=None,
        source_entity_relationship=SOURCE_FRAGMENT_ENTITY_RELATIONSHIP,
    ):
        fields = {
            **{k: v for k, v in self.record.items() if k.startswith("fragment") and v is not None},
            **fields,
            "os_parent_uid": self.record["os_entity_uid"],
            "source_entity_uid": source_entity_uid,
            "previous_entity_uid": previous_fragment_uid,
            "next_entity_uid": next_fragment_uid,
        }
        child_entity, child_rel = self._add_child_attachable(
            os_workspace,
            filename,
            filetype,
            file,
            fields,
            relationship,
            os_entity_uid,
            os_relationship_uid,
            os_entity_type,
        )
        fragment_uid = child_entity.record["os_entity_uid"]
        fragment_type = child_entity.record["os_concept"]
        source_rel = self._add_relationship(
            os_workspace, fragment_uid, fragment_type,
            source_entity_uid, source_entity_type,
            source_entity_relationship, {}, source_entity_relationship_uid,
        )
        prev_rel, next_rel = None, None
        if previous_fragment_uid:
            prev_rel = self._add_relationship(
                os_workspace, fragment_uid, fragment_type,
                previous_fragment_uid, os_entity_type,
                previous_fragment_relationship, {}, previous_fragment_relationship_uid,
            )
        if next_fragment_uid:
            next_rel = self._add_relationship(
                os_workspace, fragment_uid, fragment_type,
                next_fragment_uid, os_entity_type,
                next_fragment_relationship, {}, next_fragment_relationship_uid,
            )
        return child_entity, child_rel, source_rel, prev_rel, next_rel

    def add_tag(self, os_workspace, name, group, order, color, fields={}):
        return self.add_child_entity(
            os_workspace,
            TAG_ENTITY_NAME,
            {**fields, "name": name, "group": group, "order": order, "color": color},
            TAG_RELATIONSHIP,
        )

    def add_annotations(
        self,
        json,
        merge_method: Callable[[Any, Any], Any],
        recurse: Union[bool, int] = False,
    ):
        if not self.annotations:
            self.annotations = {}
        self.annotations = recursive_update_dict(self.annotations, json, merge_method, recurse)

    def propagate_annotations(self, to_entity, fields=None, merge_method=lambda _, v2: v2):
        annotations_to_propagate = deepcopy(self.annotations)
        if fields:
            annotations_to_propagate = {k: v for k, v in self.annotations if k in fields}
        to_entity.annotations = recursive_update_dict(to_entity.annotations, annotations_to_propagate, merge_method)


class NifiRoute(Route):
    def __init__(self, app, tasks_routes, processor_name, celery_executor, router=None):
        self.app = app
        self._router = router
        self.routed_funcs = []
        self.tasks_routes = tasks_routes
        self.processor_name = processor_name
        self.celery_executor = celery_executor
        self.endpoints = {}
        self.define_routes()

    def register_route(self, op, nifi_task):
        self.endpoints[op.strip("/")] = nifi_task

    def define_routes(self):
        @Route.route(
            self,
            path="/task-state/{task_id}",
            summary="Get NiFi task state.",
            description="Return the current state of a task as a plain string (e.g. AWAITING, STARTED, SUCCESS).",
        )
        async def get_task_status(task_id: str) -> JSONResponse:
            try:
                task_status = await self.tasks_routes.get_task(task_id, pop=False)
                task_status = task_status.model_dump(mode="json")["data"]["task_state"]
            except BaseException as e:
                raise ValueError(f"Could not fetch task state for task id {task_id}!\n{e}")
            return JSONResponse(task_status)

        @Route.route(
            self,
            path="/task-result/{task_id}",
            summary="Get NiFi task result.",
            description="Return the result payload of a completed task and remove it from the backend.",
        )
        async def get_task_result(task_id: str) -> JSONResponse:
            try:
                return_data = await self.tasks_routes.get_task(task_id, pop=True)
                return_data = return_data.model_dump(mode="json")["data"]["data"]
            except BaseException as e:
                raise ValueError(f"Could not fetch task result for task id {task_id}\n{e}!")
            return JSONResponse(return_data)

        @Route.route(
            self,
            path="/{op}",
            methods=["POST"],
            summary="Submit a NiFi processing task.",
            description=(
                "Entry point for NiFi requests. The 'op' path parameter "
                "selects the processing route (e.g. extract-text, summarize). "
                "The body is a list of entities in NiFi format. Query "
                "parameters are read from the entity config at "
                "'request.config.<<processor_name>>.<<route_name>>.<<suffix_name>>'."
            ),
        )
        async def send_task(op: str, request: Request) -> str:
            path_params = []
            op = op.split("/")
            if len(op) > 1:
                path_params = op[1:]
            op = op[0]
            query_params = request.query_params
            processor_suffix = query_params["processor_suffix"]
            processor_name = "processor." + self.processor_name + "." + op + "." + processor_suffix
            if op not in self.endpoints.keys():
                raise StarletteHTTPException(403, f"Route {op} is forbidden for NiFi.")
            task_id = await self.celery_executor.send_task(
                self.endpoints[op], args=[processor_name], part=request.stream()
            )
            return task_id

    @staticmethod
    def nifi_task(celery_executor, *args, **opts):
        def decorator(func):
            @wraps(func)
            def nifi_func(task, body_bytes, processor_name, *args, **kwargs):
                body = json.loads(body_bytes)
                with NifiContextManager(body) as nifi_context:
                    entity_batches = nifi_context.receive_input(body, processor_name)
                    entity_batches = func(
                        task,
                        nifi_context,
                        entity_batches,
                        processor_name,
                        *args,
                        **kwargs,
                    )
                    return nifi_context.send_output(entity_batches, processor_name)

            serialized_func = celery_executor.serialized_io(nifi_func)
            task_func = celery_executor.app.task(*args, **opts)(serialized_func)
            return task_func

        return decorator
