# text-digest — Reference Guide

Complete syntax, API reference, and coding examples for every library used in the project.
Master these to become an expert on the full stack.

\---

## Table of Contents

1. [UV — Python Package Manager](#1-uv--python-package-manager)
2. [Typer — CLI Framework](#2-typer--cli-framework)
3. [Rich — Terminal Formatting](#3-rich--terminal-formatting)
4. [Anthropic Python SDK](#4-anthropic-python-sdk)
5. [httpx — HTTP Client](#5-httpx--http-client)
6. [BeautifulSoup4 — HTML Parsing](#6-beautifulsoup4--html-parsing)
7. [pypdf — PDF Reading](#7-pypdf--pdf-reading)
8. [python-docx — Word Documents](#8-python-docx--word-documents)
9. [striprtf — RTF Parsing](#9-striprtf--rtf-parsing)
10. [ReportLab — PDF Generation](#10-reportlab--pdf-generation)
11. [python-dotenv — Environment Variables](#11-python-dotenv--environment-variables)
12. [Pathlib — File System](#12-pathlib--file-system)
13. [pytest — Testing](#13-pytest--testing)
14. [Prompt Engineering Patterns](#14-prompt-engineering-patterns)

\---

## 1\. UV — Python Package Manager

UV is an ultra-fast Python project manager that replaces pip, venv, and Poetry.

### Installation

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh   # macOS / Linux
winget install --id=astral-sh.uv                   # Windows
```

### Project Lifecycle

```bash
uv init myproject              # Create project with pyproject.toml
uv init --lib mylib            # Create a library project
uv init --app myapp            # Create an app project (adds entry point)
cd myproject

echo "3.12" > .python-version  # Pin Python version
uv python install 3.12         # Install that Python version if missing
uv python list                 # List available Python versions
```

### Managing Dependencies

```bash
uv add requests                # Add to \[project.dependencies]
uv add "requests>=2.31"        # Add with version constraint
uv add --dev pytest            # Add to \[tool.uv.dev-dependencies]
uv remove requests             # Remove a dependency
uv sync                        # Install all deps (creates venv if needed)
uv lock                        # Regenerate uv.lock
uv lock --upgrade              # Upgrade all packages
uv lock --upgrade-package httpx  # Upgrade one package
```

### Running Code

```bash
uv run python script.py        # Run with the project venv
uv run pytest                  # Run pytest
uv run myapp arg1 arg2         # Run the project's entry point
uv pip install -e .            # Editable install
uv pip list                    # List installed packages
```

### Building and Publishing

```bash
uv build                       # Build wheel + sdist into dist/
uv publish                     # Publish to PyPI (prompts for credentials)
uv publish --token $PYPI\_TOKEN # Publish with token
```

### pyproject.toml Structure

```toml
\[project]
name = "text-digest"
version = "0.1.0"
description = "A short description"
readme = "README.md"
requires-python = ">=3.12"
license = { text = "MIT" }
authors = \[{ name = "Your Name", email = "you@example.com" }]
dependencies = \[
    "anthropic>=0.25.0",
    "typer>=0.12.0",
    "rich>=13.0.0",
]

\[project.scripts]
text-digest = "text\_digest.main:app"   # CLI entry point

\[project.optional-dependencies]
http = \["httpx>=0.27.0"]

\[build-system]
requires = \["hatchling"]
build-backend = "hatchling.build"

\[tool.hatch.build.targets.wheel]
packages = \["src/text\_digest"]

\[tool.uv]
dev-dependencies = \["pytest>=8.0", "pytest-asyncio>=0.23"]
```

\---

## 2\. Typer — CLI Framework

Typer builds CLIs from Python type hints. Based on Click.

### Basic App

```python
import typer

app = typer.Typer()

@app.command()
def main(name: str):
    typer.echo(f"Hello, {name}")

if \_\_name\_\_ == "\_\_main\_\_":
    app()
```

### Arguments vs Options

```python
@app.command()
def run(
    # Positional argument — required
    source: str = typer.Argument(..., help="Input file or URL"),

    # Option with short form
    output: str = typer.Option(None, "--output", "-o", help="Output file"),

    # Flag (boolean option)
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose mode"),

    # Option with choices
    fmt: str = typer.Option("txt", "--format", "-f",
                             help="Output format",
                             show\_default=True),
):
    typer.echo(f"source={source}, output={output}, verbose={verbose}, fmt={fmt}")
```

### Validation with Callbacks

```python
def validate\_source(value: str) -> str:
    if not value.startswith("http") and not Path(value).exists():
        raise typer.BadParameter(f"File not found: {value}")
    return value

@app.command()
def run(
    source: str = typer.Argument(..., callback=validate\_source),
):
    ...
```

### Multiple Commands (Sub-commands)

```python
app = typer.Typer()

@app.command("digest")
def digest\_cmd(source: str):
    """Create a digest."""
    ...

@app.command("info")
def info\_cmd():
    """Show app info."""
    typer.echo("text-digest v0.1")

if \_\_name\_\_ == "\_\_main\_\_":
    app()
```

### Exit Codes

```python
# Success (code 0)
raise typer.Exit()

# Failure (code 1)
raise typer.Exit(code=1)

# Abort (prints "Aborted!", code 1)
raise typer.Abort()
```

### Prompting Within Commands

```python
@app.command()
def run():
    name = typer.prompt("What is your name?")
    confirmed = typer.confirm("Are you sure?")
    if not confirmed:
        raise typer.Abort()
```

\---

## 3\. Rich — Terminal Formatting

Rich makes beautiful CLI output with zero effort.

### Console Basics

```python
from rich.console import Console
console = Console()

# Markup syntax: \[style]text\[/style]
console.print("\[bold]Bold text\[/bold]")
console.print("\[italic red]Red italic\[/italic red]")
console.print("\[bold green]✓ Success\[/bold green]")
console.print("\[yellow]Warning\[/yellow]")
console.print("\[red]Error\[/red]")
console.print("\[blue on white]Blue on white background\[/blue on white]")

# Print to stderr
console.print("\[red]Error\[/red]", style="bold", file=console.stderr)

# Print without newline
console.print("Loading", end="")
```

### Panels

```python
from rich.panel import Panel

console.print(Panel("text-digest", title="App", subtitle="v0.1"))
console.print(Panel.fit("\[green]Done!\[/green]", border\_style="green"))
```

### Tables

```python
from rich.table import Table

table = Table(title="Results", show\_header=True)
table.add\_column("Field", style="cyan", no\_wrap=True)
table.add\_column("Value", style="magenta")
table.add\_row("Words (original)", "12,500")
table.add\_row("Words (digest)", "2,400")
table.add\_row("Reduction", "81%")
console.print(table)
```

### Progress Bars and Spinners

```python
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn

# Spinner (indeterminate)
with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
    task = p.add\_task("Processing…")
    do\_work()

# Progress bar (determinate)
with Progress(BarColumn(), TextColumn("{task.percentage:.0f}%"), TimeElapsedColumn()) as p:
    task = p.add\_task("Uploading", total=100)
    for i in range(100):
        p.update(task, advance=1)
        time.sleep(0.1)
```

### Prompt (Interactive Input)

```python
from rich.prompt import Prompt, Confirm, IntPrompt

name = Prompt.ask("Enter your name")
fmt = Prompt.ask("Format", choices=\["txt", "pdf", "doc"], default="txt")
count = IntPrompt.ask("How many?", default=1)
ok = Confirm.ask("Continue?")
```

### Syntax Highlighting

```python
from rich.syntax import Syntax

code = """
def hello():
    print("Hello, World!")
"""
syntax = Syntax(code, "python", theme="monokai", line\_numbers=True)
console.print(syntax)
```

### Logging with Rich

```python
import logging
from rich.logging import RichHandler

logging.basicConfig(
    level=logging.DEBUG,
    format="%(message)s",
    handlers=\[RichHandler(rich\_tracebacks=True)]
)
log = logging.getLogger("text-digest")
log.info("Starting")
log.error("Something failed")
```

\---

## 4\. Anthropic Python SDK

The official Python client for the Claude API.

### Installation

```bash
uv add anthropic
```

### Client Setup

```python
import anthropic

# From env var ANTHROPIC\_API\_KEY automatically
client = anthropic.Anthropic()

# Or explicit
client = anthropic.Anthropic(api\_key="sk-ant-...")
```

### Basic Message (Non-Streaming)

```python
response = client.messages.create(
    model="claude-opus-4-5",
    max\_tokens=1024,
    messages=\[
        {"role": "user", "content": "What is the capital of France?"}
    ]
)
print(response.content\[0].text)   # "Paris"
print(response.usage.input\_tokens)
print(response.usage.output\_tokens)
```

### System Prompt

```python
response = client.messages.create(
    model="claude-opus-4-5",
    max\_tokens=2048,
    system="You are a professional editor who writes in a concise, formal style.",
    messages=\[
        {"role": "user", "content": "Summarize this article: ..."}
    ]
)
```

### Multi-Turn Conversation

```python
messages = \[]

def chat(user\_input: str) -> str:
    messages.append({"role": "user", "content": user\_input})
    response = client.messages.create(
        model="claude-opus-4-5",
        max\_tokens=1024,
        messages=messages
    )
    reply = response.content\[0].text
    messages.append({"role": "assistant", "content": reply})
    return reply

print(chat("My name is Alice."))
print(chat("What is my name?"))   # Remembers "Alice"
```

### Streaming

```python
# Stream text chunks as they arrive
with client.messages.stream(
    model="claude-opus-4-5",
    max\_tokens=1024,
    messages=\[{"role": "user", "content": "Tell me a story."}]
) as stream:
    for text in stream.text\_stream:
        print(text, end="", flush=True)
    print()
    final = stream.get\_final\_message()
    print(f"Total tokens: {final.usage.input\_tokens + final.usage.output\_tokens}")
```

### JSON / Structured Output

```python
import json

response = client.messages.create(
    model="claude-opus-4-5",
    max\_tokens=512,
    system="Respond ONLY with valid JSON. No markdown, no explanation.",
    messages=\[{
        "role": "user",
        "content": "Extract title and author from: 'Moby Dick by Herman Melville'"
    }]
)
data = json.loads(response.content\[0].text)
print(data\["title"])   # "Moby Dick"
print(data\["author"])  # "Herman Melville"
```

### Model Names (as of 2025)

|Model|Alias|Use Case|
|-|-|-|
|`claude-opus-4-5`|Best quality|Long docs, complex reasoning|
|`claude-sonnet-4-5`|Balanced|General use|
|`claude-haiku-4-5`|Fastest/cheapest|Simple tasks, guardrails|

### Error Handling

```python
from anthropic import (
    APIConnectionError,
    AuthenticationError,
    RateLimitError,
    APIStatusError,
)

try:
    response = client.messages.create(...)
except AuthenticationError:
    print("Invalid API key")
except RateLimitError:
    print("Rate limited — wait and retry")
except APIConnectionError:
    print("Network error")
except APIStatusError as e:
    print(f"API error {e.status\_code}: {e.message}")
```

### Token Counting (Before Sending)

```python
count = client.messages.count\_tokens(
    model="claude-opus-4-5",
    messages=\[{"role": "user", "content": "Hello world"}]
)
print(count.input\_tokens)  # e.g. 10
```

\---

## 5\. httpx — HTTP Client

Modern, async-capable HTTP client (like `requests` but better).

### Synchronous GET

```python
import httpx

response = httpx.get("https://example.com")
print(response.status\_code)   # 200
print(response.text)          # HTML string
print(response.json())        # Parsed JSON dict
print(response.headers)       # Response headers
print(response.url)           # Final URL (after redirects)
```

### With Options

```python
response = httpx.get(
    "https://api.example.com/data",
    headers={"Authorization": "Bearer token123"},
    params={"page": 1, "limit": 50},
    timeout=30,
    follow\_redirects=True,
)
response.raise\_for\_status()   # Raises on 4xx/5xx
```

### POST with JSON

```python
response = httpx.post(
    "https://api.example.com/submit",
    json={"key": "value"},
    headers={"Content-Type": "application/json"},
)
```

### Error Handling

```python
try:
    response = httpx.get("https://example.com", timeout=10)
    response.raise\_for\_status()
except httpx.ConnectError:
    print("Cannot connect")
except httpx.TimeoutException:
    print("Request timed out")
except httpx.HTTPStatusError as e:
    print(f"HTTP error {e.response.status\_code}")
```

### Async Client

```python
import asyncio
import httpx

async def fetch(url: str) -> str:
    async with httpx.AsyncClient() as client:
        response = await client.get(url, follow\_redirects=True)
        response.raise\_for\_status()
        return response.text

text = asyncio.run(fetch("https://example.com"))
```

\---

## 6\. BeautifulSoup4 — HTML Parsing

Parse and navigate HTML/XML documents.

### Basic Parsing

```python
from bs4 import BeautifulSoup

html = "<html><body><h1>Title</h1><p>Hello</p></body></html>"
soup = BeautifulSoup(html, "html.parser")

print(soup.h1.text)           # "Title"
print(soup.find("p").text)    # "Hello"
print(soup.get\_text())        # "TitleHello"
```

### Finding Elements

```python
# Find first match
tag = soup.find("h1")
tag = soup.find("div", class\_="content")
tag = soup.find("a", href=True)

# Find all matches
tags = soup.find\_all("p")
tags = soup.find\_all("a", class\_="link")

# CSS selector
tag = soup.select\_one("div.content > p")
tags = soup.select("article p")
```

### Extracting Text from Webpage

```python
import httpx
from bs4 import BeautifulSoup

def fetch\_text(url: str) -> str:
    html = httpx.get(url, follow\_redirects=True, timeout=30).text
    soup = BeautifulSoup(html, "html.parser")

    # Remove boilerplate
    for tag in soup(\["script", "style", "nav", "footer", "header", "aside"]):
        tag.decompose()

    # Get main content
    main = soup.find("main") or soup.find("article") or soup.body
    return main.get\_text(separator="\\n", strip=True)
```

### Attributes

```python
tag = soup.find("a")
href = tag.get("href")             # None if missing
href = tag\["href"]                 # KeyError if missing
classes = tag.get("class", \[])     # List of class names
```

\---

## 7\. pypdf — PDF Reading

Pure-Python PDF parser.

### Extract Text

```python
import pypdf

reader = pypdf.PdfReader("document.pdf")
print(f"Pages: {len(reader.pages)}")

# All pages
full\_text = "\\n".join(
    page.extract\_text() or ""
    for page in reader.pages
)

# Specific page (0-indexed)
page\_text = reader.pages\[0].extract\_text()
```

### Metadata

```python
meta = reader.metadata
print(meta.title)
print(meta.author)
print(meta.creation\_date)
```

### Encrypted PDF

```python
reader = pypdf.PdfReader("locked.pdf")
if reader.is\_encrypted:
    reader.decrypt("password123")
text = reader.pages\[0].extract\_text()
```

### Write / Merge PDFs

```python
from pypdf import PdfWriter, PdfReader

writer = PdfWriter()
r1 = PdfReader("file1.pdf")
r2 = PdfReader("file2.pdf")
for page in r1.pages:
    writer.add\_page(page)
for page in r2.pages:
    writer.add\_page(page)

with open("merged.pdf", "wb") as f:
    writer.write(f)
```

\---

## 8\. python-docx — Word Documents

Read and write `.docx` files.

### Reading

```python
from docx import Document

doc = Document("file.docx")

# All paragraphs
for para in doc.paragraphs:
    print(para.text)
    print(para.style.name)   # "Heading 1", "Normal", etc.

# Tables
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            print(cell.text)
```

### Creating a Document

```python
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD\_ALIGN\_PARAGRAPH

doc = Document()

# Title
title = doc.add\_heading("My Document", level=0)
title.alignment = WD\_ALIGN\_PARAGRAPH.CENTER

# Heading
doc.add\_heading("Introduction", level=1)

# Paragraph
p = doc.add\_paragraph("This is normal text.")

# Run with formatting
run = p.add\_run(" Bold part.")
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(0xFF, 0x00, 0x00)

# Bullet list
doc.add\_paragraph("Item one", style="List Bullet")
doc.add\_paragraph("Item two", style="List Bullet")

# Page break
doc.add\_page\_break()

# Table
table = doc.add\_table(rows=2, cols=3)
table.style = "Table Grid"
table.cell(0, 0).text = "Header A"
table.cell(0, 1).text = "Header B"
table.cell(1, 0).text = "Value 1"

# Image
doc.add\_picture("logo.png", width=Inches(2))

doc.save("output.docx")
```

### Modifying Existing Document

```python
doc = Document("existing.docx")

# Change first paragraph
doc.paragraphs\[0].text = "New first paragraph"

# Add to end
doc.add\_paragraph("New paragraph at end.")

doc.save("modified.docx")
```

\---

## 9\. striprtf — RTF Parsing

Convert RTF to plain text.

```python
from striprtf.striprtf import rtf\_to\_text
from pathlib import Path

raw = Path("document.rtf").read\_text(encoding="utf-8", errors="ignore")
text = rtf\_to\_text(raw)
print(text)
```

### Handling Encoding Issues

```python
# RTF files may use different encodings; try multiple
for enc in \["utf-8", "latin-1", "cp1252"]:
    try:
        raw = Path("doc.rtf").read\_text(encoding=enc)
        break
    except UnicodeDecodeError:
        continue

text = rtf\_to\_text(raw)
```

\---

## 10\. ReportLab — PDF Generation

Create PDFs programmatically with full layout control.

### Simple PDF

```python
from reportlab.pdfgen import canvas

c = canvas.Canvas("simple.pdf")
c.setFont("Helvetica", 12)
c.drawString(72, 750, "Hello, World!")  # x, y in points (72pt = 1 inch)
c.save()
```

### Flowable Document (Recommended)

```python
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import inch
from reportlab.lib import colors

# Styles
styles = getSampleStyleSheet()
title\_style = ParagraphStyle(
    "CustomTitle",
    parent=styles\["Title"],
    fontSize=24,
    textColor=colors.HexColor("#1a1a2e"),
    spaceAfter=30,
)
body\_style = styles\["BodyText"]
body\_style.fontSize = 11
body\_style.leading = 16

# Build content
story = \[]
story.append(Paragraph("My Report Title", title\_style))
story.append(Spacer(1, 0.2 \* inch))
story.append(Paragraph("This is body text. It wraps automatically.", body\_style))
story.append(PageBreak())
story.append(Paragraph("Page 2 content", body\_style))

# Create PDF
doc = SimpleDocTemplate(
    "report.pdf",
    pagesize=letter,
    rightMargin=inch,
    leftMargin=inch,
    topMargin=inch,
    bottomMargin=inch,
)
doc.build(story)
```

### Table in ReportLab

```python
from reportlab.platypus import Table, TableStyle
from reportlab.lib import colors

data = \[
    \["Name", "Score", "Grade"],      # Header row
    \["Alice", "95", "A"],
    \["Bob", "82", "B"],
]

table = Table(data, colWidths=\[2\*inch, 1.5\*inch, 1.5\*inch])
table.setStyle(TableStyle(\[
    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4472C4")),
    ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
    ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
    ("FONTSIZE",   (0, 0), (-1, -1), 11),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), \[colors.white, colors.HexColor("#F2F2F2")]),
    ("GRID",       (0, 0), (-1, -1), 0.5, colors.grey),
    ("ALIGN",      (0, 0), (-1, -1), "CENTER"),
    ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
    ("TOPPADDING", (0, 0), (-1, -1), 8),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
]))
story.append(table)
```

### Converting Text to PDF Paragraphs

```python
def text\_to\_story(text: str, style) -> list:
    """Convert multi-line text to a list of ReportLab Paragraphs."""
    story = \[]
    for line in text.split("\\n"):
        if line.strip():
            story.append(Paragraph(line, style))
        else:
            story.append(Spacer(1, 0.1 \* inch))
    return story
```

\---

## 11\. python-dotenv — Environment Variables

Load `.env` files into `os.environ`.

### .env File Format

```
# Comment
ANTHROPIC\_API\_KEY=sk-ant-xxxx
DEBUG=true
MAX\_TOKENS=4096
DATABASE\_URL=postgresql://user:pass@localhost/db
```

### Loading

```python
from dotenv import load\_dotenv
import os

load\_dotenv()                        # Load .env from current dir
load\_dotenv(".env.production")       # Load specific file
load\_dotenv(override=True)           # Override existing env vars

api\_key = os.getenv("ANTHROPIC\_API\_KEY")
api\_key = os.getenv("ANTHROPIC\_API\_KEY", "default-value")
api\_key = os.environ\["ANTHROPIC\_API\_KEY"]  # KeyError if missing
```

### Validation Pattern

```python
from dotenv import load\_dotenv
import os

load\_dotenv()

REQUIRED\_VARS = \["ANTHROPIC\_API\_KEY"]

def validate\_env():
    missing = \[v for v in REQUIRED\_VARS if not os.getenv(v)]
    if missing:
        raise EnvironmentError(f"Missing env vars: {', '.join(missing)}")

validate\_env()
```

\---

## 12\. Pathlib — File System

Modern, object-oriented file and path handling.

### Path Operations

```python
from pathlib import Path

p = Path("src/text\_digest/main.py")

p.name          # "main.py"
p.stem          # "main"
p.suffix        # ".py"
p.suffixes      # \[".py"]
p.parent        # Path("src/text\_digest")
p.parents\[1]    # Path("src")
p.parts         # ("src", "text\_digest", "main.py")

p.exists()      # True / False
p.is\_file()     # True
p.is\_dir()      # False

p.resolve()     # Absolute path
```

### Reading and Writing

```python
# Text
text = Path("file.txt").read\_text(encoding="utf-8")
Path("output.txt").write\_text("hello\\nworld", encoding="utf-8")

# Bytes
data = Path("image.png").read\_bytes()
Path("copy.png").write\_bytes(data)

# Line by line
for line in Path("file.txt").read\_text().splitlines():
    print(line)
```

### Creating Directories and Files

```python
Path("output/digests").mkdir(parents=True, exist\_ok=True)
Path("output/result.txt").touch()
```

### Globbing

```python
# All .txt files in current dir
txts = list(Path(".").glob("\*.txt"))

# All .py files recursively
pys = list(Path("src").rglob("\*.py"))
```

### Joining Paths

```python
base = Path("/home/user/project")
full = base / "src" / "main.py"   # /home/user/project/src/main.py
```

\---

## 13\. pytest — Testing

The standard Python testing framework.

### Test Structure

```python
# tests/test\_example.py

import pytest

def test\_addition():
    assert 1 + 1 == 2

def test\_raises\_value\_error():
    with pytest.raises(ValueError, match="invalid"):
        raise ValueError("invalid input")

def test\_approximately\_equal():
    assert 3.14159 == pytest.approx(3.14, rel=1e-2)
```

### Fixtures

```python
import pytest
from pathlib import Path

@pytest.fixture
def sample\_txt(tmp\_path) -> Path:
    """Create a temporary .txt file for testing."""
    f = tmp\_path / "sample.txt"
    f.write\_text("Hello world. This is test content.")
    return f

def test\_ingest\_reads\_txt(sample\_txt):
    from text\_digest.ingest import ingest
    result = ingest(str(sample\_txt))
    assert "Hello world" in result
```

### Parametrize

```python
@pytest.mark.parametrize("style,expected", \[
    ("professional", True),
    ("modern", True),
    ("vulgar obscene", False),
])
def test\_style\_guard(style, expected, mock\_client):
    # ...
    assert check\_style\_safety(style) == expected
```

### Mocking

```python
from unittest.mock import patch, MagicMock

def test\_create\_digest\_calls\_api():
    mock\_response = MagicMock()
    mock\_response.content = \[MagicMock(text="This is the digest.")]

    with patch("text\_digest.digest.anthropic.Anthropic") as MockAnthropic:
        instance = MockAnthropic.return\_value
        instance.messages.create.return\_value = mock\_response

        from text\_digest.digest import create\_digest
        result = create\_digest("Long text here.", "professional")

    assert result == "This is the digest."
    instance.messages.create.assert\_called\_once()
```

### Running Tests

```bash
uv run pytest                    # All tests
uv run pytest tests/test\_ingest.py        # One file
uv run pytest -v                 # Verbose output
uv run pytest -s                 # Show print statements
uv run pytest -k "test\_safe"     # Tests matching pattern
uv run pytest --tb=short         # Shorter tracebacks
uv run pytest --cov=text\_digest  # Coverage (needs pytest-cov)
```

\---

## 14\. Prompt Engineering Patterns

Techniques used in `digest.py` and `prompts.py`.

### System Prompt Best Practices

```
You are \[role].
Your task is \[specific task].

Rules:
1. \[Explicit constraint]
2. \[Explicit constraint]
3. \[Safety rule]

Output format: \[describe exactly what to return]
```

### Binary Classification Guard

```python
GUARD\_PROMPT = """
Classify whether the following content is SAFE or UNSAFE.
UNSAFE means: profanity, sexual content, hate speech, graphic violence.
Reply with exactly one word: SAFE or UNSAFE.

INPUT: {content}
""".strip()

response = client.messages.create(
    model="claude-haiku-4-5",  # Use fast/cheap model for guards
    max\_tokens=5,
    messages=\[{"role": "user", "content": GUARD\_PROMPT.format(content=user\_input)}]
)
verdict = response.content\[0].text.strip().upper()
is\_safe = verdict == "SAFE"
```

### JSON Extraction Pattern

```python
EXTRACT\_PROMPT = """
Extract the following fields from the text below.
Return ONLY valid JSON with keys: title, author, year.
No markdown code fences. No explanation. Only the JSON object.

TEXT: {text}
""".strip()

response = client.messages.create(
    model="claude-opus-4-5",
    max\_tokens=200,
    messages=\[{"role": "user", "content": EXTRACT\_PROMPT.format(text=raw)}]
)
import json
data = json.loads(response.content\[0].text)
```

### Length Control Pattern

```python
# Ask model to target a specific word count
DIGEST\_PROMPT = """
Summarize the following text in approximately {target\_words} words.
Preserve the main ideas and key facts.
Style: {style}

TEXT:
{text}
""".strip()

target = len(raw\_text.split()) // 5  # 20% of original
prompt = DIGEST\_PROMPT.format(
    target\_words=target,
    style="professional",
    text=raw\_text
)
```

### Few-Shot Examples Pattern

```python
SYSTEM = """
You convert text to the requested style.

EXAMPLES:

Original: "The experiment failed due to insufficient funding."
Style: humorous
Result: "The experiment went up in smoke — mostly because someone forgot to pay the lab bill."

Original: "She walked slowly to the door."
Style: dramatic
Result: "Each step toward the door felt like a march toward destiny itself."
""".strip()
```

### Chain-of-Thought for Complex Tasks

```python
SYSTEM = """
You are a text analyst. For complex summarization:
1. First identify the main theme (1 sentence)
2. List the 3-5 key points
3. Write the final digest incorporating all points

Think step by step before writing the digest.
""".strip()
```

### Retry with Exponential Backoff

```python
import time
import anthropic

def create\_with\_retry(client, max\_retries=3, \*\*kwargs):
    for attempt in range(max\_retries):
        try:
            return client.messages.create(\*\*kwargs)
        except anthropic.RateLimitError:
            wait = 2 \*\* attempt
            print(f"Rate limited. Waiting {wait}s...")
            time.sleep(wait)
        except anthropic.APIConnectionError:
            if attempt == max\_retries - 1:
                raise
            time.sleep(1)
    raise RuntimeError("Max retries exceeded")
```

\---

## Quick Reference: Format Decision Matrix

|Input Format|Library|Key Function|
|-|-|-|
|`.txt`|`pathlib`|`Path.read\_text()`|
|`.pdf`|`pypdf`|`PdfReader.pages\[i].extract\_text()`|
|`.docx`|`python-docx`|`Document.paragraphs`|
|`.doc`|LibreOffice → `python-docx`|Convert first|
|`.rtf`|`striprtf`|`rtf\_to\_text()`|
|URL|`httpx` + `beautifulsoup4`|`get()` + `.get\_text()`|

|Output Format|Library|Key Function|
|-|-|-|
|`.txt`|`pathlib`|`Path.write\_text()`|
|`.pdf`|`reportlab`|`SimpleDocTemplate.build()`|
|`.docx`|`python-docx`|`Document.save()`|
|`.rtf`|Manual RTF wrapper|`Path.write\_text()`|
|HTTP|`http.server`|`HTTPServer` thread|



