# src/text_digest/digest.py

import anthropic
from .prompts import DIGEST_SYSTEM_PROMPT, DIGEST_USER_TEMPLATE, STYLE_GUARD_PROMPT
from .utils import get_api_key


def check_style_safety(style: str) -> bool:
    """Returns True if the style is safe, False if inappropriate."""
    client = anthropic.Anthropic(api_key=get_api_key())
    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=10,
        messages=[
            {"role": "user", "content": STYLE_GUARD_PROMPT.format(style=style)}
        ],
    )
    verdict = response.content[0].text.strip().upper()
    return verdict == "SAFE"


def create_digest(text: str, style: str) -> str:
    """
    Summarize `text` in the given `style`.
    Returns the digest string.
    Raises ValueError if style is rejected.
    """
    if not check_style_safety(style):
        raise ValueError(
            f"The requested style '{style}' was flagged as inappropriate. "
            "Please choose a different style (e.g. original, modern, professional, humorous)."
        )

    client = anthropic.Anthropic(api_key=get_api_key())
    user_message = DIGEST_USER_TEMPLATE.format(style=style, text=text)

    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=4096,
        system=DIGEST_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_message}],
    )

    digest_text = response.content[0].text.strip()

    # Secondary guard: model may return STYLE_REJECTED token
    if digest_text == "STYLE_REJECTED":
        raise ValueError(
            f"The style '{style}' was rejected by the content filter."
        )

    return digest_text