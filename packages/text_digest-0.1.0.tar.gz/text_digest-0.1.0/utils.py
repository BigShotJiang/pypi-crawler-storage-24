# src/text_digest/utils.py

import os
from dotenv import load_dotenv

load_dotenv()

def get_api_key() -> str:
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        raise EnvironmentError(
            "ANTHROPIC_API_KEY is not set. Add it to your .env file."
        )
    return key

SUPPORTED_INPUT_FORMATS = [".txt", ".pdf", ".doc", ".docx", ".rtf"]
SUPPORTED_OUTPUT_FORMATS = ["txt", "pdf", "doc", "rtf", "http"]