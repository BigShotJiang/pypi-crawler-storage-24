# src/text_digest/main.py

import typer
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from .ingest import ingest
from .digest import create_digest
from .export import export
from .utils import SUPPORTED_OUTPUT_FORMATS

app = typer.Typer(
    name="text-digest",
    help="Convert any long text into a condensed, styled digest.",
    add_completion=False,
)
console = Console()


@app.command()
def run(
    source: str = typer.Argument(
        ..., help="Path to .txt/.pdf/.doc/.rtf file, or an HTTP/HTTPS URL."
    ),
    output: str = typer.Option(
        None, "--output", "-o", help="Output file path (optional)."
    ),
):
    """
    Read SOURCE, ask for output format and style, then produce a digest.
    """
    console.print(Panel("[bold cyan]text-digest[/bold cyan]", subtitle="MVP v0.1"))

    # ── 1. Ingest ──────────────────────────────────────────────────
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        p.add_task("Reading source…")
        try:
            raw_text = ingest(source)
        except Exception as e:
            console.print(f"[red]Error reading source:[/red] {e}")
            raise typer.Exit(1)

    word_count = len(raw_text.split())
    console.print(f"[green]✓[/green] Loaded {word_count:,} words from source.\n")

    # ── 2. Output Format ───────────────────────────────────────────
    fmt_choices = ", ".join(SUPPORTED_OUTPUT_FORMATS)
    fmt = Prompt.ask(
        f"[bold]Preferred output format[/bold] ({fmt_choices})",
        choices=SUPPORTED_OUTPUT_FORMATS,
        default="txt",
    )

    # ── 3. Style ───────────────────────────────────────────────────
    style = Prompt.ask(
        "[bold]Preferred output style[/bold] "
        "(e.g. original, modern, humorous, professional, academic…)"
    )

    # ── 4. Digest ──────────────────────────────────────────────────
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        p.add_task("Generating digest with Claude…")
        try:
            digest_text = create_digest(raw_text, style)
        except ValueError as e:
            console.print(f"[red]Content policy error:[/red] {e}")
            raise typer.Exit(1)
        except Exception as e:
            console.print(f"[red]API error:[/red] {e}")
            raise typer.Exit(1)

    digest_word_count = len(digest_text.split())
    reduction = 100 - round(digest_word_count / word_count * 100)
    console.print(
        f"[green]✓[/green] Digest created: "
        f"{digest_word_count:,} words ({reduction}% reduction).\n"
    )

    # ── 5. Export ──────────────────────────────────────────────────
    try:
        result = export(digest_text, fmt, output)
    except Exception as e:
        console.print(f"[red]Export error:[/red] {e}")
        raise typer.Exit(1)

    if fmt == "http":
        console.print(f"[bold green]✓ Digest served at:[/bold green] {result}")
        console.print("Open the URL in your browser. Press Ctrl+C to exit.")
        input()  # Keep process alive for the HTTP server thread
    else:
        console.print(f"[bold green]✓ Digest saved to:[/bold green] {result}")


if __name__ == "__main__":
    app()