"""Content-safety check — ensures output is free of foul/inappropriate language."""
import anthropic


def is_content_safe(client: anthropic.Anthropic, text: str) -> tuple[bool, str]:
    """
    Check whether the given text is appropriate (no foul language, hate speech, etc.).

    Returns:
        (is_safe: bool, reason: str)
    """
    system_prompt = (
        "You are a strict content moderator. "
        "Analyse the provided text and decide whether it contains foul language, "
        "hate speech, explicit sexual content, graphic violence, or any other content "
        "that would be inappropriate in a professional or general-audience context. "
        "Reply with ONLY a JSON object in this exact format: "
        '{"safe": true, "reason": "brief explanation"} '
        "or "
        '{"safe": false, "reason": "brief explanation of what was found"}. '
        "No other text."
    )

    response = client.messages.create(
        model="claude-opus-4-6",
        max_tokens=200,
        system=system_prompt,
        messages=[{"role": "user", "content": text}],
    )

    import json
    raw = response.content[0].text.strip()
    try:
        result = json.loads(raw)
        return bool(result.get("safe", False)), result.get("reason", "")
    except json.JSONDecodeError:
        # Fallback: treat unexpected response as unsafe
        return False, "Moderation response could not be parsed."