# src/text_digest/ingest.py

from pathlib import Path
import httpx
from bs4 import BeautifulSoup
import pypdf
from docx import Document
from striprtf.striprtf import rtf_to_text


def ingest(source: str) -> str:
    """
    Accept a file path or URL and return its plain text content.
    """
    if source.startswith("http://") or source.startswith("https://"):
        return _from_url(source)

    path = Path(source)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {source}")

    suffix = path.suffix.lower()
    if suffix == ".txt":
        return path.read_text(encoding="utf-8")
    elif suffix == ".pdf":
        return _from_pdf(path)
    elif suffix in (".doc", ".docx"):
        return _from_docx(path)
    elif suffix == ".rtf":
        return _from_rtf(path)
    else:
        raise ValueError(f"Unsupported file format: {suffix}")


def _from_url(url: str) -> str:
    response = httpx.get(url, follow_redirects=True, timeout=30)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    # Remove scripts and styles
    for tag in soup(["script", "style", "nav", "footer", "header"]):
        tag.decompose()
    return soup.get_text(separator="\n", strip=True)


def _from_pdf(path: Path) -> str:
    reader = pypdf.PdfReader(str(path))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages)


def _from_docx(path: Path) -> str:
    doc = Document(str(path))
    return "\n".join(p.text for p in doc.paragraphs)


def _from_rtf(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    return rtf_to_text(raw)