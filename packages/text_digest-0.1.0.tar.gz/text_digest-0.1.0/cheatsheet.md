# text-digest — Cheatsheet

Quick-reference card for day-to-day development.

---

## UV Commands

```bash
uv init text-digest          # Create new project
uv sync                      # Install all deps from pyproject.toml
uv add <package>             # Add a dependency
uv remove <package>          # Remove a dependency
uv run <command>             # Run a command in the project venv
uv run text-digest <source>  # Run the CLI
uv run pytest                # Run tests
uv build                     # Build wheel + sdist
uv publish                   # Publish to PyPI
uv pip install -e .          # Editable install (dev mode)
uv lock --upgrade            # Upgrade all packages
```

---

## CLI Usage

```bash
# Basic usage — interactive prompts for format and style
text-digest myfile.txt
text-digest mybook.pdf
text-digest document.docx
text-digest notes.rtf
text-digest https://example.com/article

# Specify output path
text-digest myfile.txt --output digest.txt
text-digest mybook.pdf -o summary.pdf

# When prompted:
# Format: txt | pdf | doc | rtf | http
# Style:  original | modern | humorous | professional | academic | (any custom style)
```

---

## Project Structure (Quick View)

```
text-digest/
├── pyproject.toml        ← deps + entry point
├── .env                  ← ANTHROPIC_API_KEY=sk-ant-...
├── src/text_digest/
│   ├── main.py           ← CLI (Typer)
│   ├── ingest.py         ← read .txt/.pdf/.doc/.rtf/URL
│   ├── digest.py         ← Claude summarize + style guard
│   ├── export.py         ← write .txt/.pdf/.doc/.rtf/http
│   ├── prompts.py        ← all prompt strings
│   └── utils.py          ← API key, constants
└── tests/
```

---

## Anthropic API — Key Patterns

```python
import anthropic
client = anthropic.Anthropic(api_key="sk-ant-...")

# Basic message
response = client.messages.create(
    model="claude-opus-4-5",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Summarize this: ..."}]
)
print(response.content[0].text)

# With system prompt
response = client.messages.create(
    model="claude-opus-4-5",
    max_tokens=4096,
    system="You are a professional editor.",
    messages=[{"role": "user", "content": "..."}]
)

# Streaming (real-time output)
with client.messages.stream(
    model="claude-opus-4-5",
    max_tokens=1024,
    messages=[{"role": "user", "content": "..."}]
) as stream:
    for text in stream.text_stream:
        print(text, end="", flush=True)
```

---

## Ingest — One-Liners

```python
from text_digest.ingest import ingest

text = ingest("book.txt")          # .txt file
text = ingest("report.pdf")        # PDF
text = ingest("memo.docx")         # Word doc
text = ingest("letter.rtf")        # RTF
text = ingest("https://...")       # Web page (HTML stripped)
```

---

## File Parsing — Raw Snippets

```python
# TXT
text = Path("file.txt").read_text(encoding="utf-8")

# PDF
import pypdf
reader = pypdf.PdfReader("file.pdf")
text = "\n".join(p.extract_text() for p in reader.pages)

# DOCX
from docx import Document
doc = Document("file.docx")
text = "\n".join(p.text for p in doc.paragraphs)

# RTF
from striprtf.striprtf import rtf_to_text
raw = Path("file.rtf").read_text(encoding="utf-8", errors="ignore")
text = rtf_to_text(raw)

# URL
import httpx
from bs4 import BeautifulSoup
html = httpx.get("https://...").text
soup = BeautifulSoup(html, "html.parser")
text = soup.get_text(separator="\n", strip=True)
```

---

## Export — Raw Snippets

```python
# TXT
Path("out.txt").write_text(text, encoding="utf-8")

# PDF
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import letter
doc = SimpleDocTemplate("out.pdf", pagesize=letter)
styles = getSampleStyleSheet()
doc.build([Paragraph(line, styles["Normal"]) for line in text.split("\n")])

# DOCX
from docx import Document
doc = Document()
for line in text.split("\n"):
    doc.add_paragraph(line)
doc.save("out.docx")

# HTML (for http output)
html = f"<html><body><p>{text}</p></body></html>"
Path("digest.html").write_text(html)
```

---

## Typer CLI Patterns

```python
import typer
app = typer.Typer()

@app.command()
def run(
    source: str = typer.Argument(..., help="File or URL"),
    output: str = typer.Option(None, "--output", "-o"),
):
    typer.echo(f"Processing {source}")

if __name__ == "__main__":
    app()
```

---

## Rich Console Patterns

```python
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

# Print styled text
console.print("[bold green]✓ Done[/bold green]")
console.print("[red]Error:[/red] something failed")
console.print(Panel("text-digest", subtitle="v0.1"))

# Ask user for input
fmt = Prompt.ask("Output format", choices=["txt", "pdf"], default="txt")
style = Prompt.ask("Style")

# Spinner while working
with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
    p.add_task("Processing…")
    do_slow_work()
```

---

## Content Guard Pattern

```python
# Check style before calling the main API
def is_safe(style: str) -> bool:
    resp = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=10,
        messages=[{"role": "user", "content": f"Is this style SAFE or UNSAFE? {style}"}]
    )
    return resp.content[0].text.strip().upper() == "SAFE"

if not is_safe(user_style):
    raise ValueError("Style rejected by content filter.")
```

---

## Environment / .env Pattern

```python
# .env file
ANTHROPIC_API_KEY=sk-ant-xxxx

# Load in code
from dotenv import load_dotenv
import os
load_dotenv()
key = os.getenv("ANTHROPIC_API_KEY")
```

---

## Running Tests

```bash
uv run pytest tests/ -v             # Run all tests with output
uv run pytest tests/test_ingest.py  # Run one file
uv run pytest -k "test_safe"        # Run matching tests
uv run pytest --tb=short            # Shorter tracebacks
```

---

## Common Errors & Fixes

| Error | Fix |
|---|---|
| `ANTHROPIC_API_KEY not set` | Add key to `.env` and call `load_dotenv()` |
| `FileNotFoundError` | Check source path exists |
| `ValueError: Unsupported format` | Use `.txt .pdf .docx .rtf` or a URL |
| `ValueError: Style rejected` | Use a clean style name (e.g. professional) |
| `httpx.ConnectError` | Check URL is reachable; add `follow_redirects=True` |
| `pypdf` blank text | PDF may be scanned image — add OCR library (`pytesseract`) |
| `python-docx` won't open `.doc` | Convert with LibreOffice first |
