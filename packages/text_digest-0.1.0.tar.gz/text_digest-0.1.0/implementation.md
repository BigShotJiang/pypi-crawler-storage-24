# text_digest — Implementation Plan

## Project Overview

**text_digest** is a UV Python CLI application that condenses full-length texts (fiction and non-fiction) into styled digests. It accepts input from `.txt`, `.pdf`, `.doc`, `.rtf`, or HTTP URLs, and outputs in the user's preferred format and writing style.

---

## Tech Stack

| Layer | Tool |
|---|---|
| Runtime / Package Manager | `uv` (Astral) |
| LLM Summarization | `anthropic` (Claude API) |
| PDF Parsing | `pypdf` |
| DOC/RTF Parsing | `python-docx`, `striprtf` |
| HTTP Fetching | `httpx` |
| HTML Stripping | `beautifulsoup4` |
| Output PDF Generation | `reportlab` |
| Output DOCX Generation | `python-docx` |
| Output RTF Generation | `pyrtf-ng` |
| Content Moderation | Claude prompt guard (built-in) |
| CLI Interface | `typer` + `rich` |

---

## Project Structure

```
text_digest/
├── pyproject.toml
├── README.md
├── implementation.md
├── cheatsheet.md
├── reference.md
├── .env                        # ANTHROPIC_API_KEY
├── .python-version             # e.g. 3.12
├── src/
│   └── text_digest/
│       ├── __init__.py
│       ├── main.py             # CLI entry point (Typer)
│       ├── ingest.py           # Input parsing (.txt, .pdf, .doc, .rtf, URL)
│       ├── digest.py           # Claude summarization + style + guard
│       ├── export.py           # Output formatting (.txt, .pdf, .doc, .rtf, http)
│       ├── prompts.py          # All prompt templates
│       └── utils.py            # Shared helpers
└── tests/
    ├── test_ingest.py
    ├── test_digest.py
    └── test_export.py
```

---

## Step-by-Step Implementation

### Step 1 — Bootstrap the project with UV

```bash
# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Create the project
uv init text_digest
cd text_digest

# Pin Python version
echo "3.12" > .python-version

# Create the source package structure
mkdir -p src\text_digest, tests

New-Item src\text_digest\__init__.py
New-Item src\text_digest\main.py
New-Item src\text_digest\ingest.py
New-Item src\text_digest\digest.py
New-Item src\text_digest\export.py
New-Item src\text_digest\prompts.py
New-Item src\text_digest\utils.py
```

---

### Step 2 — Configure pyproject.toml

Replace the generated `pyproject.toml` with:

```toml
[project]
name = "text_digest"
version = "0.1.0"
description = "Convert long texts into styled digests"
requires-python = ">=3.12"
dependencies = [
    "anthropic>=0.25.0",
    "typer>=0.12.0",
    "rich>=13.0.0",
    "httpx>=0.27.0",
    "beautifulsoup4>=4.12.0",
    "pypdf>=4.0.0",
    "python-docx>=1.1.0",
    "striprtf>=0.0.26",
    "reportlab>=4.1.0",
    "pyrtf-ng>=0.1.0",
    "python-dotenv>=1.0.0",
]

[project.scripts]
text_digest = "text_digest.main:app"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/text_digest"]

[tool.uv]
dev-dependencies = [
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
]
```

Install all dependencies:

```bash
uv sync
```

---

### Step 3 — Environment Setup

Create `.env` in the project root:

```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxxxxx
```

Add `.env` to `.gitignore`:

```bash
echo ".env" >> .gitignore
```

---

### Step 4 — Implement `utils.py`

```python
# src/text_digest/utils.py

import os
from dotenv import load_dotenv

load_dotenv()

def get_api_key() -> str:
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        raise EnvironmentError(
            "ANTHROPIC_API_KEY is not set. Add it to your .env file."
        )
    return key

SUPPORTED_INPUT_FORMATS = [".txt", ".pdf", ".doc", ".docx", ".rtf"]
SUPPORTED_OUTPUT_FORMATS = ["txt", "pdf", "doc", "rtf", "http"]
```

---

### Step 5 — Implement `ingest.py`

This module reads text from any supported input source.

```python
# src/text_digest/ingest.py

from pathlib import Path
import httpx
from bs4 import BeautifulSoup
import pypdf
from docx import Document
from striprtf.striprtf import rtf_to_text


def ingest(source: str) -> str:
    """
    Accept a file path or URL and return its plain text content.
    """
    if source.startswith("http://") or source.startswith("https://"):
        return _from_url(source)

    path = Path(source)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {source}")

    suffix = path.suffix.lower()
    if suffix == ".txt":
        return path.read_text(encoding="utf-8")
    elif suffix == ".pdf":
        return _from_pdf(path)
    elif suffix in (".doc", ".docx"):
        return _from_docx(path)
    elif suffix == ".rtf":
        return _from_rtf(path)
    else:
        raise ValueError(f"Unsupported file format: {suffix}")


def _from_url(url: str) -> str:
    response = httpx.get(url, follow_redirects=True, timeout=30)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    # Remove scripts and styles
    for tag in soup(["script", "style", "nav", "footer", "header"]):
        tag.decompose()
    return soup.get_text(separator="\n", strip=True)


def _from_pdf(path: Path) -> str:
    reader = pypdf.PdfReader(str(path))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages)


def _from_docx(path: Path) -> str:
    doc = Document(str(path))
    return "\n".join(p.text for p in doc.paragraphs)


def _from_rtf(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    return rtf_to_text(raw)
```

---

### Step 6 — Implement `prompts.py`

```python
# src/text_digest/prompts.py

DIGEST_SYSTEM_PROMPT = """
You are a professional editor and summarizer.
Your job is to create a condensed digest of a text provided by the user.

Rules:
1. Preserve the core ideas, narrative arc, and key facts.
2. The digest should be approximately 20% of the original length.
3. Match the requested writing style exactly.
4. Never use profanity, vulgarity, hate speech, or explicit content,
   regardless of the requested style. If the style description contains
   inappropriate language, respond only with: STYLE_REJECTED
5. Do not add your own opinions or commentary.
6. Output only the digest text — no headers, no metadata.
""".strip()

DIGEST_USER_TEMPLATE = """
STYLE: {style}

ORIGINAL TEXT:
{text}
""".strip()

STYLE_GUARD_PROMPT = """
You are a content policy checker.
Evaluate whether the following style description is appropriate for a general audience.
A style is inappropriate if it explicitly requests: profanity, sexual content,
hate speech, graphic violence, or targeted harassment.
Reply with exactly one word: SAFE or UNSAFE.

STYLE: {style}
""".strip()
```

---

### Step 7 — Implement `digest.py`

```python
# src/text_digest/digest.py

import anthropic
from .prompts import DIGEST_SYSTEM_PROMPT, DIGEST_USER_TEMPLATE, STYLE_GUARD_PROMPT
from .utils import get_api_key


def check_style_safety(style: str) -> bool:
    """Returns True if the style is safe, False if inappropriate."""
    client = anthropic.Anthropic(api_key=get_api_key())
    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=10,
        messages=[
            {"role": "user", "content": STYLE_GUARD_PROMPT.format(style=style)}
        ],
    )
    verdict = response.content[0].text.strip().upper()
    return verdict == "SAFE"


def create_digest(text: str, style: str) -> str:
    """
    Summarize `text` in the given `style`.
    Returns the digest string.
    Raises ValueError if style is rejected.
    """
    if not check_style_safety(style):
        raise ValueError(
            f"The requested style '{style}' was flagged as inappropriate. "
            "Please choose a different style (e.g. original, modern, professional, humorous)."
        )

    client = anthropic.Anthropic(api_key=get_api_key())
    user_message = DIGEST_USER_TEMPLATE.format(style=style, text=text)

    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=4096,
        system=DIGEST_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_message}],
    )

    digest_text = response.content[0].text.strip()

    # Secondary guard: model may return STYLE_REJECTED token
    if digest_text == "STYLE_REJECTED":
        raise ValueError(
            f"The style '{style}' was rejected by the content filter."
        )

    return digest_text
```

---

### Step 8 — Implement `export.py`

```python
# src/text_digest/export.py

from pathlib import Path
from docx import Document
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import http.server
import threading


def export(text: str, fmt: str, output_path: str | None = None) -> str:
    """
    Export `text` to the specified format.
    Returns the output path or a status message.
    """
    fmt = fmt.lower()
    if fmt == "txt":
        return _to_txt(text, output_path or "digest.txt")
    elif fmt == "pdf":
        return _to_pdf(text, output_path or "digest.pdf")
    elif fmt in ("doc", "docx"):
        return _to_docx(text, output_path or "digest.docx")
    elif fmt == "rtf":
        return _to_rtf(text, output_path or "digest.rtf")
    elif fmt == "http":
        return _to_http(text)
    else:
        raise ValueError(f"Unsupported output format: {fmt}")


def _to_txt(text: str, path: str) -> str:
    Path(path).write_text(text, encoding="utf-8")
    return path


def _to_pdf(text: str, path: str) -> str:
    doc = SimpleDocTemplate(path, pagesize=letter)
    styles = getSampleStyleSheet()
    story = [Paragraph(line or "&nbsp;", styles["Normal"]) for line in text.split("\n")]
    doc.build(story)
    return path


def _to_docx(text: str, path: str) -> str:
    doc = Document()
    for line in text.split("\n"):
        doc.add_paragraph(line)
    doc.save(path)
    return path


def _to_rtf(text: str, path: str) -> str:
    # Simple RTF wrapper — for rich RTF, use pyrtf-ng
    escaped = text.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")
    rtf_content = (
        "{\\rtf1\\ansi\\deff0\n"
        "{\\fonttbl{\\f0 Times New Roman;}}\n"
        "\\f0\\fs24 "
        + escaped.replace("\n", "\\par\n")
        + "\n}"
    )
    Path(path).write_text(rtf_content, encoding="ascii", errors="replace")
    return path


def _to_http(text: str) -> str:
    html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Text Digest</title>
<style>
  body {{ font-family: Georgia, serif; max-width: 760px; margin: 2rem auto;
         padding: 0 1rem; line-height: 1.7; color: #222; }}
  h1 {{ font-size: 1.4rem; color: #444; }}
</style>
</head>
<body>
<h1>Text Digest</h1>
<p>{"</p><p>".join(line for line in text.split(chr(10)) if line.strip())}</p>
</body>
</html>"""

    html_path = "digest.html"
    Path(html_path).write_text(html, encoding="utf-8")

    # Start a local HTTP server on port 8765
    port = 8765
    handler = http.server.SimpleHTTPRequestHandler

    def serve():
        with http.server.HTTPServer(("", port), handler) as httpd:
            httpd.handle_request()  # Serve one request then stop

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    return f"http://localhost:{port}/{html_path}"
```

---

### Step 9 — Implement `main.py` (CLI Entry Point)

```python
# src/text_digest/main.py

import typer
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from .ingest import ingest
from .digest import create_digest
from .export import export
from .utils import SUPPORTED_OUTPUT_FORMATS

app = typer.Typer(
    name="text_digest",
    help="Convert any long text into a condensed, styled digest.",
    add_completion=False,
)
console = Console()


@app.command()
def run(
    source: str = typer.Argument(
        ..., help="Path to .txt/.pdf/.doc/.rtf file, or an HTTP/HTTPS URL."
    ),
    output: str = typer.Option(
        None, "--output", "-o", help="Output file path (optional)."
    ),
):
    """
    Read SOURCE, ask for output format and style, then produce a digest.
    """
    console.print(Panel("[bold cyan]text_digest[/bold cyan]", subtitle="MVP v0.1"))

    # ── 1. Ingest ──────────────────────────────────────────────────
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        p.add_task("Reading source…")
        try:
            raw_text = ingest(source)
        except Exception as e:
            console.print(f"[red]Error reading source:[/red] {e}")
            raise typer.Exit(1)

    word_count = len(raw_text.split())
    console.print(f"[green]✓[/green] Loaded {word_count:,} words from source.\n")

    # ── 2. Output Format ───────────────────────────────────────────
    fmt_choices = ", ".join(SUPPORTED_OUTPUT_FORMATS)
    fmt = Prompt.ask(
        f"[bold]Preferred output format[/bold] ({fmt_choices})",
        choices=SUPPORTED_OUTPUT_FORMATS,
        default="txt",
    )

    # ── 3. Style ───────────────────────────────────────────────────
    style = Prompt.ask(
        "[bold]Preferred output style[/bold] "
        "(e.g. original, modern, humorous, professional, academic…)"
    )

    # ── 4. Digest ──────────────────────────────────────────────────
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        p.add_task("Generating digest with Claude…")
        try:
            digest_text = create_digest(raw_text, style)
        except ValueError as e:
            console.print(f"[red]Content policy error:[/red] {e}")
            raise typer.Exit(1)
        except Exception as e:
            console.print(f"[red]API error:[/red] {e}")
            raise typer.Exit(1)

    digest_word_count = len(digest_text.split())
    reduction = 100 - round(digest_word_count / word_count * 100)
    console.print(
        f"[green]✓[/green] Digest created: "
        f"{digest_word_count:,} words ({reduction}% reduction).\n"
    )

    # ── 5. Export ──────────────────────────────────────────────────
    try:
        result = export(digest_text, fmt, output)
    except Exception as e:
        console.print(f"[red]Export error:[/red] {e}")
        raise typer.Exit(1)

    if fmt == "http":
        console.print(f"[bold green]✓ Digest served at:[/bold green] {result}")
        console.print("Open the URL in your browser. Press Ctrl+C to exit.")
        input()  # Keep process alive for the HTTP server thread
    else:
        console.print(f"[bold green]✓ Digest saved to:[/bold green] {result}")


if __name__ == "__main__":
    app()
```

---

### Step 10 — Install in Development Mode and Test

```bash
# Install the project in editable mode
uv pip install -e .

# Run with a local text file
uv run text_digest mybook.txt

# Run with a URL
uv run text_digest https://en.wikipedia.org/wiki/Python_(programming_language)

# Run with a specific output path
uv run text_digest mybook.pdf --output digest.txt
```

---

### Step 11 — Add Basic Tests

```python
# tests/test_ingest.py
from text_digest.ingest import ingest
from pathlib import Path
import pytest

def test_ingest_txt(tmp_path):
    f = tmp_path / "sample.txt"
    f.write_text("Hello world. This is a test.")
    result = ingest(str(f))
    assert "Hello world" in result

def test_ingest_missing_file():
    with pytest.raises(FileNotFoundError):
        ingest("nonexistent.txt")

def test_ingest_unsupported_format(tmp_path):
    f = tmp_path / "sample.xyz"
    f.write_text("data")
    with pytest.raises(ValueError):
        ingest(str(f))
```

```python
# tests/test_digest.py
from unittest.mock import patch, MagicMock
from text_digest.digest import check_style_safety, create_digest

def _mock_response(text):
    msg = MagicMock()
    msg.content = [MagicMock(text=text)]
    return msg

def test_safe_style():
    with patch("text_digest.digest.anthropic.Anthropic") as MockClient:
        MockClient.return_value.messages.create.return_value = _mock_response("SAFE")
        assert check_style_safety("professional") is True

def test_unsafe_style():
    with patch("text_digest.digest.anthropic.Anthropic") as MockClient:
        MockClient.return_value.messages.create.return_value = _mock_response("UNSAFE")
        assert check_style_safety("vulgar") is False
```

Run tests:

```bash
uv run pytest tests/ -v
```

---

### Step 12 — Build and Distribute (Optional)

```bash
# Build a wheel
uv build

# Install globally from wheel
pip install dist/text_digest-0.1.0-py3-none-any.whl

# Or publish to PyPI
uv publish
```

---

## Full Data Flow

```
User runs: text_digest source.pdf
    │
    ▼
ingest.py   → reads source → plain text string
    │
    ▼
main.py     → prompts user: output format + style
    │
    ▼
digest.py   → check_style_safety(style)    [Claude API call 1]
            → create_digest(text, style)   [Claude API call 2]
    │
    ▼
export.py   → writes .txt / .pdf / .doc / .rtf / serves HTML
    │
    ▼
User gets the digest file or URL
```

---

## Content Moderation Strategy

Two-layer guard:

1. **Pre-flight style check** (`check_style_safety`): A fast, low-token Claude call that returns `SAFE` or `UNSAFE` before any summarization begins.
2. **In-prompt system instruction**: The summarization system prompt instructs the model to return `STYLE_REJECTED` if the style is problematic, as a redundant fallback.

This prevents inappropriate output even if a borderline style slips through layer 1.

---

## Environment Variables

| Variable | Description |
|---|---|
| `ANTHROPIC_API_KEY` | Required. Your Anthropic API key. |

---

## MVP Limitations & Future Improvements

- The HTTP output mode is a local preview server, not a hosted URL. Future: integrate with a hosting service.
- `.doc` (legacy binary Word) should be pre-converted with `LibreOffice`; `python-docx` only handles `.docx`.
- Digest length is fixed at ~20%. Future: allow user to set a target length.
- No streaming output yet. Future: use `client.messages.stream()` for real-time output.
