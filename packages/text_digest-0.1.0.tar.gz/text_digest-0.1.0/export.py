# src/text_digest/export.py

from pathlib import Path
from docx import Document
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import http.server
import threading


def export(text: str, fmt: str, output_path: str | None = None) -> str:
    """
    Export `text` to the specified format.
    Returns the output path or a status message.
    """
    fmt = fmt.lower()
    if fmt == "txt":
        return _to_txt(text, output_path or "digest.txt")
    elif fmt == "pdf":
        return _to_pdf(text, output_path or "digest.pdf")
    elif fmt in ("doc", "docx"):
        return _to_docx(text, output_path or "digest.docx")
    elif fmt == "rtf":
        return _to_rtf(text, output_path or "digest.rtf")
    elif fmt == "http":
        return _to_http(text)
    else:
        raise ValueError(f"Unsupported output format: {fmt}")


def _to_txt(text: str, path: str) -> str:
    Path(path).write_text(text, encoding="utf-8")
    return path


def _to_pdf(text: str, path: str) -> str:
    doc = SimpleDocTemplate(path, pagesize=letter)
    styles = getSampleStyleSheet()
    story = [Paragraph(line or "&nbsp;", styles["Normal"]) for line in text.split("\n")]
    doc.build(story)
    return path


def _to_docx(text: str, path: str) -> str:
    doc = Document()
    for line in text.split("\n"):
        doc.add_paragraph(line)
    doc.save(path)
    return path


def _to_rtf(text: str, path: str) -> str:
    # Simple RTF wrapper — for rich RTF, use pyrtf-ng
    escaped = text.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")
    rtf_content = (
        "{\\rtf1\\ansi\\deff0\n"
        "{\\fonttbl{\\f0 Times New Roman;}}\n"
        "\\f0\\fs24 "
        + escaped.replace("\n", "\\par\n")
        + "\n}"
    )
    Path(path).write_text(rtf_content, encoding="ascii", errors="replace")
    return path


def _to_http(text: str) -> str:
    html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Text Digest</title>
<style>
  body {{ font-family: Georgia, serif; max-width: 760px; margin: 2rem auto;
         padding: 0 1rem; line-height: 1.7; color: #222; }}
  h1 {{ font-size: 1.4rem; color: #444; }}
</style>
</head>
<body>
<h1>Text Digest</h1>
<p>{"</p><p>".join(line for line in text.split(chr(10)) if line.strip())}</p>
</body>
</html>"""

    html_path = "digest.html"
    Path(html_path).write_text(html, encoding="utf-8")

    # Start a local HTTP server on port 8765
    port = 8765
    handler = http.server.SimpleHTTPRequestHandler

    def serve():
        with http.server.HTTPServer(("", port), handler) as httpd:
            httpd.handle_request()  # Serve one request then stop

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    return f"http://localhost:{port}/{html_path}"