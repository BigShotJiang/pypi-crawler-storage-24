"""
MK-AI  ·  Free Tier  v2.3.0  ·  Powered by MKDEVAPI
═════════════════════════════════════════════════════

No API key required.  3 models.  10 requests/hour.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  USE AS A MODULE (import this file)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    from noapi import chat, gemini, gpt4o_mini

    # Simplest
    print(chat("What is Python?"))

    # Specific model
    print(gemini.chat("Hello!"))
    print(gpt4o_mini.chat("Hello!"))

    # Stateful bot (remembers conversation)
    from noapi import FreeChatBot
    bot = FreeChatBot()
    bot.chat("My name is Ali")
    bot.chat("What's my name?")   # → "Your name is Ali"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  VIA mkdevai (if installed)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    import mkdevai
    print(mkdevai.free.chat("Hello!"))
    print(mkdevai.free.gemini.chat("Hello!"))

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  STANDALONE  (run directly)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    python noapi.py
"""

from __future__ import annotations
import requests
import time
from typing import Optional, List, Dict

# ══════════════════════════════════════════════════════
#  CONFIGURATION  (do not edit)
# ══════════════════════════════════════════════════════
_API_URL    = "https://api.puter.com/puterai/openai/v1/chat/completions"
_AUTH_TOKEN = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
    "eyJ0IjoicyIsInYiOiIwLjAuMCIsInUiOiJ0K2JxRE5ycVEzNnY0SWdobnpTSjRRPT0iLCJ1dSI6"
    "IkFvZXYzNCs1U0R5VXZLaXN4bmZ5enc9PSIsImlhdCI6MTc2ODE4ODAzMn0."
    "1pG9Zb2xV9X-98nT-BnLKnzfq_2PwSsHDQxwhpzXFQI"
)

# ══════════════════════════════════════════════════════
#  FREE-TIER LIMITS
# ══════════════════════════════════════════════════════
RATE_LIMIT_REQUESTS = 10     # requests allowed per hour
RATE_LIMIT_WINDOW   = 3600   # seconds in 1 hour
MAX_TOKENS          = 500    # max AI reply tokens per request
MAX_HISTORY_TURNS   = 6      # conversation turns kept in memory

# ══════════════════════════════════════════════════════
#  AVAILABLE MODELS
# ══════════════════════════════════════════════════════
MODELS = {
    "gpt-4o-mini":           "GPT-4o Mini           (OpenAI)  — default",
    "gpt-4.1-nano":          "GPT-4.1 Nano          (OpenAI)  — fastest",
    "gemini-2.5-flash-lite": "Gemini 2.5 Flash Lite (Google)  — versatile",
}
MODEL_IDS = list(MODELS.keys())
DEFAULT_MODEL = MODEL_IDS[0]

# ══════════════════════════════════════════════════════
#  RATE LIMITER  (per-instance, in-memory)
# ══════════════════════════════════════════════════════
_global_hits: List[float] = []   # shared across all instances in this process


def _check_rate_limit() -> bool:
    """Sliding-window rate check. Returns True if allowed."""
    now = time.monotonic()
    global _global_hits
    _global_hits = [t for t in _global_hits if now - t < RATE_LIMIT_WINDOW]
    if len(_global_hits) >= RATE_LIMIT_REQUESTS:
        return False
    _global_hits.append(now)
    return True


def _requests_remaining() -> int:
    now = time.monotonic()
    used = sum(1 for t in _global_hits if now - t < RATE_LIMIT_WINDOW)
    return max(0, RATE_LIMIT_REQUESTS - used)


# ══════════════════════════════════════════════════════
#  FREE CHAT BOT CLASS
# ══════════════════════════════════════════════════════

class FreeChatBot:
    """
    A free-tier MK-AI chatbot. No API key needed.

    Remembers the last 6 turns of your conversation.

    Parameters
    ----------
    model : str, optional
        AI model to use.  Default: gpt-4o-mini
        Options: 'gpt-4o-mini', 'gpt-4.1-nano', 'gemini-2.5-flash-lite'

    Example
    -------
        from noapi import FreeChatBot

        bot = FreeChatBot()
        print(bot.chat("Hello! I'm learning Python."))
        print(bot.chat("What should I learn first?"))  # remembers context
    """

    def __init__(self, model: str = DEFAULT_MODEL):
        if model not in MODELS:
            raise ValueError(
                f"Unknown model: '{model}'\n"
                f"Available: {', '.join(MODEL_IDS)}"
            )
        self.model   = model
        self.history: List[Dict] = []

    @property
    def requests_remaining(self) -> int:
        """Free requests left in the current hour."""
        return _requests_remaining()

    def set_model(self, model_id: str) -> None:
        """Switch to a different model."""
        if model_id not in MODELS:
            raise ValueError(
                f"Unknown model: '{model_id}'\n"
                f"Available: {', '.join(MODEL_IDS)}"
            )
        self.model = model_id

    def clear_history(self) -> None:
        """Forget the conversation."""
        self.history = []

    def chat(self, message: str, system: Optional[str] = None) -> str:
        """
        Send a message and get a reply.

        Parameters
        ----------
        message : str
            Your message.
        system : str, optional
            Custom instructions for the AI.

        Returns
        -------
        str
            The AI's reply.

        Raises
        ------
        RuntimeError
            If rate limit exceeded or network error.

        Example
        -------
            bot = FreeChatBot()
            print(bot.chat("What is machine learning?"))
        """
        if not message or not message.strip():
            raise ValueError("Message cannot be empty.")

        if not _check_rate_limit():
            raise RuntimeError(
                f"Rate limit reached ({RATE_LIMIT_REQUESTS} requests/hour).\n"
                f"Wait ~1 hour or get an API key for higher limits."
            )

        sys_prompt = system or (
            "You are MK-AI, a helpful AI assistant powered by MKDEVAPI. "
            "Be helpful, friendly, and concise."
        )
        messages = [{"role": "system", "content": sys_prompt}]
        for m in self.history[-MAX_HISTORY_TURNS:]:
            messages.append(m)
        messages.append({"role": "user", "content": str(message)[:2048]})

        headers = {
            "Authorization": f"Bearer {_AUTH_TOKEN}",
            "Content-Type":  "application/json",
        }
        payload = {
            "model":       self.model,
            "messages":    messages,
            "max_tokens":  MAX_TOKENS,
            "temperature": 0.7,
        }

        try:
            resp = requests.post(_API_URL, headers=headers, json=payload, timeout=30)
            resp.raise_for_status()
            reply = resp.json()["choices"][0]["message"]["content"]
        except requests.exceptions.ConnectionError:
            raise RuntimeError("No internet connection. Check your network.")
        except requests.exceptions.HTTPError as e:
            code = e.response.status_code if e.response is not None else "?"
            raise RuntimeError(f"Server error ({code}). Please try again.")
        except Exception:
            raise RuntimeError("Request failed. Please try again.")

        self.history.append({"role": "user",      "content": message})
        self.history.append({"role": "assistant",  "content": reply})
        return reply

    def ask(self, question: str) -> str:
        """One-shot question — no memory used."""
        self.clear_history()
        reply = self.chat(question)
        self.clear_history()
        return reply

    def __repr__(self) -> str:
        return (
            f"FreeChatBot(\n"
            f"  model              = '{self.model}',\n"
            f"  requests_remaining = {self.requests_remaining}/{RATE_LIMIT_REQUESTS} per hour,\n"
            f"  history_turns      = {len(self.history) // 2},\n"
            f")"
        )


# ══════════════════════════════════════════════════════
#  MODULE-LEVEL CONVENIENCE SINGLETONS
# ══════════════════════════════════════════════════════

# Ready-to-use model bots
gpt4o_mini = FreeChatBot(model="gpt-4o-mini")
gpt4_nano  = FreeChatBot(model="gpt-4.1-nano")
gemini     = FreeChatBot(model="gemini-2.5-flash-lite")


def chat(message: str, model: Optional[str] = None) -> str:
    """
    One-shot free-tier chat. No API key needed.

    Parameters
    ----------
    message : str
        Your message.
    model : str, optional
        Model to use. Default: gpt-4o-mini.

    Returns
    -------
    str
        AI reply.

    Example
    -------
        from noapi import chat
        print(chat("What is Python?"))
        print(chat("Hello!", model="gemini-2.5-flash-lite"))
    """
    bot = FreeChatBot(model=model) if model else FreeChatBot()
    return bot.chat(message)


def ask(question: str, model: Optional[str] = None) -> str:
    """One-shot question, no memory."""
    bot = FreeChatBot(model=model) if model else FreeChatBot()
    return bot.ask(question)


def remaining() -> int:
    """Free requests left this hour."""
    return _requests_remaining()


# ══════════════════════════════════════════════════════
#  INTERACTIVE CLI  (python noapi.py)
# ══════════════════════════════════════════════════════

def _model_menu() -> str:
    print("\n\033[96m\033[1m  ── Choose a Model ──────────────────────────────\033[0m")
    for i, (mid, label) in enumerate(MODELS.items(), 1):
        print(f"  \033[93m{i}\033[0m.  {label}")
    print("\033[96m\033[1m  ─────────────────────────────────────────────────\033[0m")
    choice = input("  Enter number (or press Enter to keep current): ").strip()
    mapping = {str(i): mid for i, mid in enumerate(MODEL_IDS, 1)}
    return mapping.get(choice, "")


def start_chat() -> None:
    """Interactive free-tier chat session."""
    bot = FreeChatBot()

    # Banner
    print()
    print("\033[96m\033[1m  ╔═══════════════════════════════════════════════════════╗\033[0m")
    print("\033[96m\033[1m  ║   ⚡  MK-AI Free Tier  v2.3.0  ·  MKDEVAPI           ║\033[0m")
    print("\033[96m\033[1m  ╠═══════════════════════════════════════════════════════╣\033[0m")
    print(f"\033[96m\033[1m  ║\033[0m  Models: GPT-4o Mini · GPT-4.1 Nano · Gemini Flash   \033[96m\033[1m║\033[0m")
    print(f"\033[96m\033[1m  ║\033[0m  Limits: {RATE_LIMIT_REQUESTS} req/hr · {MAX_TOKENS} tokens/reply · No key needed  \033[96m\033[1m║\033[0m")
    print("\033[96m\033[1m  ╚═══════════════════════════════════════════════════════╝\033[0m")
    print()
    print("  Commands:  /model · /clear · /usage · /help · exit")
    print()

    while True:
        model_short = bot.model.split("/")[-1][:14]
        try:
            raw = input(f"\033[92m\033[1m  [{model_short}] You › \033[0m").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\033[2m  Goodbye!\033[0m\n")
            break

        if not raw:
            continue

        # ── Commands ───────────────────────────────────────────────────────
        if raw.lower() in ("exit", "quit", "bye"):
            print("\033[2m  Goodbye!\033[0m\n")
            break

        if raw.lower() == "/help":
            print()
            print("  \033[1mCommands:\033[0m")
            print("  /model   — switch AI model")
            print("  /clear   — clear conversation memory")
            print("  /usage   — show requests left this hour")
            print("  /help    — show this help")
            print("  exit     — quit")
            print()
            continue

        if raw.lower() == "/model":
            new = _model_menu()
            if new:
                bot.set_model(new)
                print(f"\n\033[2m  Switched to {new}\033[0m\n")
            continue

        if raw.lower() == "/clear":
            bot.clear_history()
            print("\n\033[93m  Conversation cleared.\033[0m\n")
            continue

        if raw.lower() == "/usage":
            rem = bot.requests_remaining
            used = RATE_LIMIT_REQUESTS - rem
            bar_filled = "█" * used
            bar_empty  = "░" * rem
            print(f"\n  Requests this hour:  [{bar_filled}{bar_empty}]  {used}/{RATE_LIMIT_REQUESTS} used  ({rem} left)\n")
            continue

        # ── Chat ───────────────────────────────────────────────────────────
        try:
            print(f"\033[95m\033[1m  AI › \033[0m", end="", flush=True)
            reply = bot.chat(raw)
            print(reply)
            print()
        except RuntimeError as e:
            print(f"\n\033[91m  ✗ {e}\033[0m\n")
        except Exception as e:
            print(f"\n\033[91m  ✗ Error: {e}\033[0m\n")


if __name__ == "__main__":
    start_chat()
