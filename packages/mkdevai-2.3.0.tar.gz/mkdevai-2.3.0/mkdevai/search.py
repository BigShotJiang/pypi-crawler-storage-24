"""
MK-AI  ·  Web Search  (multi-engine, MKAI branded)
Powered by MKDEVAPI

All search results branded as "MKAI Search".
No DuckDuckGo / Brave / Puter branding exposed.
"""

import re
import requests
from bs4 import BeautifulSoup


def _ddg_api(query: str, max_results: int = 5) -> list:
    try:
        r = requests.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
            headers={"User-Agent": "MKAI/1.0 (Powered by MKDEVAPI)"},
            timeout=10,
        )
        data    = r.json()
        results = []
        if data.get("AbstractText"):
            results.append({
                "title":   data.get("Heading", query),
                "link":    data.get("AbstractURL", ""),
                "snippet": data["AbstractText"],
                "source":  "MKAI Search",
            })
        for topic in data.get("RelatedTopics", []):
            if len(results) >= max_results:
                break
            if isinstance(topic, dict) and topic.get("Text"):
                results.append({
                    "title":   topic["Text"][:80],
                    "link":    topic.get("FirstURL", ""),
                    "snippet": topic["Text"],
                    "source":  "MKAI Search",
                })
        return results
    except Exception:
        return []


def _ddg_html(query: str, max_results: int = 5) -> list:
    try:
        r = requests.post(
            "https://html.duckduckgo.com/html/",
            data={"q": query},
            headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"},
            timeout=12,
        )
        soup    = BeautifulSoup(r.text, "html.parser")
        results = []
        for item in soup.select(".result__body"):
            title_el   = item.select_one(".result__a")
            snippet_el = item.select_one(".result__snippet")
            if not title_el:
                continue
            href = title_el.get("href", "")
            uddg = re.search(r"uddg=([^&]+)", href)
            url  = requests.utils.unquote(uddg.group(1)) if uddg else href
            results.append({
                "title":   title_el.get_text(strip=True),
                "link":    url,
                "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
                "source":  "MKAI Search",
            })
            if len(results) >= max_results:
                break
        return results
    except Exception:
        return []


def _brave(query: str, max_results: int = 5) -> list:
    try:
        r = requests.get(
            "https://search.brave.com/search",
            params={"q": query, "source": "web"},
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0",
                "Accept-Language": "en-US,en;q=0.9",
            },
            timeout=12,
        )
        soup    = BeautifulSoup(r.text, "html.parser")
        results = []
        for div in soup.select("[data-type='web'] .snippet"):
            title_el   = div.select_one(".snippet-title")
            snippet_el = div.select_one(".snippet-description")
            if not title_el:
                continue
            parent = div.find_parent("a")
            link   = parent.get("href", "") if parent else ""
            results.append({
                "title":   title_el.get_text(strip=True),
                "link":    link,
                "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
                "source":  "MKAI Search",   # ← always MKAI, never "Brave"
            })
            if len(results) >= max_results:
                break
        return results
    except Exception:
        return []


def web_search(query: str, max_results: int = 5) -> list:
    """
    Try search engines in order, always returning results branded as MKAI Search.
    Falls back silently — no engine names exposed.
    """
    for fn in (_ddg_api, _brave, _ddg_html):
        try:
            results = fn(query, max_results)
            if results:
                return results
        except Exception:
            continue
    return []
