"""
MK-AI  ·  Constants & Configuration  v2.3.0
Powered by MKDEVAPI
"""

from .security import obfuscate, deobfuscate, hash_secret, generate_salt

# ── Puter backend (token stored obfuscated — never plaintext) ──────────────────
_RAW = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
    "eyJ0IjoicyIsInYiOiIwLjAuMCIsInUiOiJ0K2JxRE5ycVEzNnY0SWdobnpTSjRRPT0iLCJ1dSI6"
    "IkFvZXYzNCs1U0R5VXZLaXN4bmZ5enc9PSIsImlhdCI6MTc2ODE4ODAzMn0."
    "1pG9Zb2xV9X-98nT-BnLKnzfq_2PwSsHDQxwhpzXFQI"
)
_OBFUSCATED_TOKEN = obfuscate(_RAW)
del _RAW   # scrub plaintext immediately

PUTER_API_URL = "https://api.puter.com/puterai/openai/v1/chat/completions"


def get_puter_token() -> str:
    """Deobfuscate and return the backend token (never cached in a global)."""
    return deobfuscate(_OBFUSCATED_TOKEN)


# ── Admin password (PBKDF2-SHA256, never stored plaintext) ────────────────────
# Change password: update _ADMIN_PASS_SALT, then recompute _ADMIN_PASS_HASH.
# Use admin panel option 29 to generate a new hash safely.
_ADMIN_PASS_SALT = "jZ3K9mPqR2sXvYwLnBdFtCuHeGaOkIjZ3K9mPqR2sXvYwLnB"
_ADMIN_PASS_HASH = hash_secret("MKMAHABBAT", _ADMIN_PASS_SALT)

# ── Rate limits ────────────────────────────────────────────────────────────────
ADMIN_RATE_LIMIT_CALLS   = 10    # admin login attempts per window
ADMIN_RATE_LIMIT_WINDOW  = 60    # seconds
USER_RATE_LIMIT_CALLS    = 60    # API calls per window
USER_RATE_LIMIT_WINDOW   = 60

# ── Full model catalogue ───────────────────────────────────────────────────────
FREE_MODELS = [
    ("gpt-4o-mini",                       "GPT-4o Mini           (OpenAI)"),
    ("gpt-4.1-nano",                      "GPT-4.1 Nano          (OpenAI)"),
    ("claude-haiku-4-5",                  "Claude Haiku 4.5      (Anthropic)"),
    ("gemini-2.5-flash-lite",             "Gemini 2.5 Flash Lite (Google)"),
    ("meta-llama/llama-3.3-70b-instruct", "LLaMA 3.3 70B         (Meta)"),
    ("mistral-small-3.2",                 "Mistral Small 3.2     (Mistral AI)"),
    ("deepseek/deepseek-r1",              "DeepSeek R1           (DeepSeek)"),
    ("grok-4-1-fast",                     "Grok 4.1 Fast         (xAI)"),
    ("moonshotai/kimi-k2",                "Kimi K2               (Moonshot AI)"),
    ("qwen/qwen3-8b",                     "Qwen 3 8B             (Alibaba)"),
]

MODEL_IDS = [m[0] for m in FREE_MODELS]

MODEL_PRICES = {
    "gpt-4o-mini":                        {"input": 0.15,  "output": 0.60},
    "gpt-4.1-nano":                       {"input": 0.10,  "output": 0.40},
    "claude-haiku-4-5":                   {"input": 0.25,  "output": 1.25},
    "gemini-2.5-flash-lite":              {"input": 0.075, "output": 0.30},
    "meta-llama/llama-3.3-70b-instruct":  {"input": 0.20,  "output": 0.60},
    "mistral-small-3.2":                  {"input": 0.20,  "output": 0.60},
    "deepseek/deepseek-r1":               {"input": 0.55,  "output": 2.19},
    "grok-4-1-fast":                      {"input": 5.00,  "output": 15.0},
    "moonshotai/kimi-k2":                 {"input": 0.15,  "output": 0.60},
    "qwen/qwen3-8b":                      {"input": 0.06,  "output": 0.18},
}

# ── Free-tier catalogue (no API key) ──────────────────────────────────────────
FREE_TIER_MODELS = [
    ("gpt-4o-mini",          "GPT-4o Mini           (OpenAI)"),
    ("gpt-4.1-nano",         "GPT-4.1 Nano          (OpenAI)"),
    ("gemini-2.5-flash-lite","Gemini 2.5 Flash Lite (Google)"),
]
FREE_TIER_MODEL_IDS         = [m[0] for m in FREE_TIER_MODELS]
FREE_TIER_RATE_LIMIT_CALLS  = 10     # requests per hour
FREE_TIER_RATE_LIMIT_WINDOW = 3600   # 1 hour in seconds
FREE_TIER_MAX_TOKENS        = 500    # max output tokens per request

# ── ANSI colour palette ────────────────────────────────────────────────────────
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    ITALIC  = "\033[3m"
    CYAN    = "\033[96m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    MAGENTA = "\033[95m"
    RED     = "\033[91m"
    BLUE    = "\033[94m"
    WHITE   = "\033[97m"
    ORANGE  = "\033[38;5;208m"
