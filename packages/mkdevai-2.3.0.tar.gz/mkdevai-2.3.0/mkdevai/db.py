"""
MK-AI  ·  Secure Database Layer
Powered by MKDEVAPI

Security features:
  - API keys stored as PBKDF2-SHA256 hashes (never plaintext)
  - Each DB write includes an HMAC integrity tag
  - Audit log uses SHA-256 chain hashing (tamper-evident)
  - File permissions set to 0o600 (owner read/write only)
  - Atomic writes (write to temp → rename) to prevent corruption
"""

import json
import os
import stat
import tempfile
import datetime
import time
from typing import Optional

from .security import (
    generate_api_key, generate_admin_key, generate_salt,
    hash_secret, verify_secret, compute_log_chain_hash,
    verify_audit_chain, sanitize_string, validate_api_key_format,
    sign_request, verify_signature
)
from .constants import MODEL_PRICES

# ── Paths ──────────────────────────────────────────────────────────────────────
_HOME    = os.path.expanduser("~")
DB_FILE  = os.path.join(_HOME, ".mkai_db.json")
LOG_FILE = os.path.join(_HOME, ".mkai_audit.json")

# Internal HMAC signing key for DB integrity (derived from machine-specific data)
_DB_SIGN_KEY = "MKDEVAPI-DB-INTEGRITY-" + str(os.getuid() if hasattr(os, "getuid") else 0)


# ── Atomic file write ──────────────────────────────────────────────────────────

def _atomic_write(path: str, data: str):
    """Write to a temp file then rename — prevents partial-write corruption."""
    dir_  = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=dir_, prefix=".mkai_tmp_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data)
        os.replace(tmp, path)
        # Restrict permissions: owner read/write only (Unix)
        try:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        except Exception:
            pass
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise


# ── Load / save with integrity check ──────────────────────────────────────────

def _load() -> dict:
    if not os.path.exists(DB_FILE):
        return {"users": {}, "admin_keys": [], "settings": {}, "_sig": ""}

    with open(DB_FILE, "r", encoding="utf-8") as f:
        try:
            db = json.load(f)
        except json.JSONDecodeError:
            # Corrupted — return empty, will be overwritten on next save
            return {"users": {}, "admin_keys": [], "settings": {}, "_sig": ""}

    # Verify HMAC integrity tag
    stored_sig = db.pop("_sig", "")
    expected   = sign_request(db, _DB_SIGN_KEY)
    if stored_sig and stored_sig != expected:
        # DB was tampered — log and continue (don't crash, just warn)
        _raw_audit("DB_TAMPER_DETECTED", "HMAC mismatch on load")

    db["_sig"] = stored_sig
    return db


def _save(db: dict):
    payload       = {k: v for k, v in db.items() if k != "_sig"}
    payload["_sig"] = sign_request(payload, _DB_SIGN_KEY)
    _atomic_write(DB_FILE, json.dumps(payload, indent=2, ensure_ascii=False))


# ── Helpers ────────────────────────────────────────────────────────────────────

def _now() -> str:
    return datetime.datetime.utcnow().isoformat() + "Z"


# ── Audit log (tamper-evident chain) ──────────────────────────────────────────

def _raw_audit(action: str, detail: str = ""):
    """Write directly without loading the rest of the DB — safe for error paths."""
    logs     = []
    prev_hash = "GENESIS"

    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                logs = json.load(f)
            if logs:
                prev_hash = logs[-1].get("_chain_hash", "GENESIS")
        except Exception:
            pass

    entry = {
        "ts":     _now(),
        "action": sanitize_string(action, 64),
        "detail": sanitize_string(detail, 256),
    }
    entry["_chain_hash"] = compute_log_chain_hash(prev_hash, entry)

    logs.append(entry)
    logs = logs[-2000:]   # keep last 2000 entries

    _atomic_write(LOG_FILE, json.dumps(logs, indent=2, ensure_ascii=False))


def audit(action: str, detail: str = ""):
    _raw_audit(action, detail)


def get_audit_log(n: int = 50) -> list:
    if not os.path.exists(LOG_FILE):
        return []
    try:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            logs = json.load(f)
        return logs[-n:]
    except Exception:
        return []


def verify_log_integrity() -> dict:
    logs = get_audit_log(9999)
    ok, bad_idx = verify_audit_chain(logs)
    return {"valid": ok, "entries": len(logs), "first_bad_index": bad_idx}


# ── User management ────────────────────────────────────────────────────────────

def create_user(name, daily_limit=1000, model_access=None, expires_on='never'):
    """
    Creates a new user. Returns dict with plaintext key (shown ONCE).
    The key is stored as a PBKDF2-SHA256 hash — never in plaintext.
    """
    name = sanitize_string(name, 64)
    db   = _load()

    # Generate cryptographically secure key
    plaintext_key = generate_api_key()
    salt          = generate_salt()
    key_hash      = hash_secret(plaintext_key, salt)

    # Use a short lookup ID (first 14 chars) for indexing
    key_id = plaintext_key  # stored as index key in DB (only hash inside)

    user = {
        "key_id":       key_id,               # full key used as dict key
        "key_hash":     key_hash,             # PBKDF2 hash
        "key_salt":     salt,                 # random salt
        "name":         name,
        "created":      _now(),
        # -1=unlimited, 0=blocked, N=daily cap
        "daily_limit":  -1 if int(daily_limit) == 0 else int(daily_limit),
        "model_access": model_access or ["gpt-4o-mini", "gpt-4.1-nano", "gemini-2.5-flash-lite"],
        "usage": {
            "prompt_tokens":     0,
            "completion_tokens": 0,
            "total_tokens":      0,
            "total_cost_usd":    0.0,
            "requests":          0,
        },
        "daily_usage": {"date": _now()[:10], "tokens": 0},
        "banned":       False,
        "revoked":      False,
        "expires_on":   expires_on,
        "messages":     0,
        "last_seen":    None,
    }

    db["users"][key_id] = user
    _save(db)
    audit("create_user", f"name={name} key_prefix={plaintext_key[:14]}")

    # Return a copy that includes the plaintext key ONCE
    result = dict(user)
    result["key"] = plaintext_key   # shown once, never stored plaintext
    return result


def authenticate_user(api_key: str) -> dict:
    """
    Verify an API key. Returns user dict (without key_hash/salt) or None.
    Uses constant-time comparison to prevent timing attacks.
    """
    if not validate_api_key_format(api_key):
        return None

    db   = _load()
    user = db["users"].get(api_key)
    if not user:
        return None

    # Verify hash
    if not verify_secret(api_key, user["key_salt"], user["key_hash"]):
        return None

    # Update last seen
    db["users"][api_key]["last_seen"] = _now()
    _save(db)

    # Return safe copy (strip hash/salt)
    safe = {k: v for k, v in user.items() if k not in ("key_hash", "key_salt")}
    safe["key"] = api_key
    return safe


def get_user(api_key: str) -> dict:
    """Fast user lookup for internal use (no hash verification needed — key IS the ID)."""
    if not validate_api_key_format(api_key):
        return None
    db   = _load()
    user = db["users"].get(api_key)
    if not user:
        return None
    safe = {k: v for k, v in user.items() if k not in ("key_hash", "key_salt")}
    safe["key"] = api_key
    return safe


def list_users() -> list:
    db = _load()
    result = []
    for key_id, u in db["users"].items():
        safe = {k: v for k, v in u.items() if k not in ("key_hash", "key_salt")}
        safe["key"] = key_id
        result.append(safe)
    return result


def update_user(api_key: str, **kwargs) -> bool:
    if not validate_api_key_format(api_key):
        return False
    # Strip protected fields from kwargs
    for protected in ("key_hash", "key_salt", "key_id", "created"):
        kwargs.pop(protected, None)
    db = _load()
    if api_key not in db["users"]:
        return False
    db["users"][api_key].update(kwargs)
    _save(db)
    return True


def record_usage(api_key: str, prompt_tokens: int, completion_tokens: int, model: str) -> dict:
    db   = _load()
    user = db["users"].get(api_key)
    if not user:
        return {}

    total = prompt_tokens + completion_tokens
    price = MODEL_PRICES.get(model, {"input": 0.0, "output": 0.0})
    cost  = (prompt_tokens * price["input"] + completion_tokens * price["output"]) / 1_000_000

    user["usage"]["prompt_tokens"]     += int(prompt_tokens)
    user["usage"]["completion_tokens"] += int(completion_tokens)
    user["usage"]["total_tokens"]      += int(total)
    user["usage"]["total_cost_usd"]    += cost
    user["usage"]["requests"]          += 1
    user["messages"]                   += 1
    user["last_seen"]                   = _now()

    today = _now()[:10]
    if user["daily_usage"]["date"] != today:
        user["daily_usage"] = {"date": today, "tokens": 0}
    user["daily_usage"]["tokens"] += int(total)

    _save(db)
    return {
        "usage": {
            "prompt_tokens":     int(prompt_tokens),
            "completion_tokens": int(completion_tokens),
            "total_tokens":      int(total),
        },
        "cost_usd":   round(cost, 8),
        "model":      model,
        "powered_by": "MKDEVAPI",
    }


def reset_daily_usage(api_key: str) -> bool:
    db = _load()
    if api_key not in db["users"]:
        return False
    db["users"][api_key]["daily_usage"] = {"date": _now()[:10], "tokens": 0}
    _save(db)
    audit("reset_daily", api_key[:14])
    return True


def regenerate_key(old_key: str) -> str:
    """Generate a new key for a user, invalidating the old one."""
    if not validate_api_key_format(old_key):
        return None
    db = _load()
    if old_key not in db["users"]:
        return None

    user      = db["users"].pop(old_key)
    new_plain = generate_api_key()
    new_salt  = generate_salt()
    new_hash  = hash_secret(new_plain, new_salt)

    user["key_id"]   = new_plain
    user["key_hash"] = new_hash
    user["key_salt"] = new_salt

    db["users"][new_plain] = user
    _save(db)
    audit("regenerate_key", f"old_prefix={old_key[:14]} new_prefix={new_plain[:14]}")
    return new_plain


def search_users(query: str) -> list:
    query = sanitize_string(query, 64).lower()
    return [u for u in list_users() if query in u.get("name", "").lower() or query in u.get("key", "").lower()]


def ban_user(api_key: str) -> bool:
    ok = update_user(api_key, banned=True)
    if ok:
        audit("ban_user", api_key[:14])
    return ok


def unban_user(api_key: str) -> bool:
    ok = update_user(api_key, banned=False)
    if ok:
        audit("unban_user", api_key[:14])
    return ok


def revoke_user(api_key: str) -> bool:
    ok = update_user(api_key, revoked=True)
    if ok:
        audit("revoke_user", api_key[:14])
    return ok


def export_users_json() -> str:
    return json.dumps(list_users(), indent=2, ensure_ascii=False)


# ── Admin keys ─────────────────────────────────────────────────────────────────

def create_admin_key() -> str:
    db       = _load()
    key      = generate_admin_key()
    salt     = generate_salt()
    key_hash = hash_secret(key, salt)
    db.setdefault("admin_keys", []).append({
        "key_hash": key_hash,
        "key_salt": salt,
        "key_preview": key[:16] + "...",
        "created": _now(),
    })
    _save(db)
    audit("create_admin_key")
    return key   # shown ONCE


def is_valid_admin_key(key: str) -> bool:
    db = _load()
    for a in db.get("admin_keys", []):
        if verify_secret(key, a["key_salt"], a["key_hash"]):
            return True
    return False


def list_admin_key_previews() -> list:
    db = _load()
    return [{"preview": a["key_preview"], "created": a["created"]}
            for a in db.get("admin_keys", [])]


# ── Analytics ──────────────────────────────────────────────────────────────────

def analytics() -> dict:
    users = list_users()
    return {
        "total_users":    len(users),
        "active_users":   sum(1 for u in users if not u["banned"] and not u["revoked"]),
        "banned_users":   sum(1 for u in users if u["banned"]),
        "revoked_users":  sum(1 for u in users if u["revoked"]),
        "total_tokens":   sum(u["usage"]["total_tokens"] for u in users),
        "total_cost_usd": round(sum(u["usage"]["total_cost_usd"] for u in users), 6),
        "total_requests": sum(u["usage"]["requests"] for u in users),
    }


def top_users(n: int = 10) -> list:
    return sorted(list_users(), key=lambda u: u["usage"]["total_tokens"], reverse=True)[:n]
