"""
MK-AI  ·  Security Layer  v2.3.0
Powered by MKDEVAPI

Features:
  - New API key format:  mk-{random10}-dev-{random2}-ai
  - PBKDF2-SHA256 hashing  (390k iterations, OWASP 2023)
  - HMAC-SHA256 DB integrity signing
  - Sliding-window rate limiting (in-memory)
  - Brute-force lockout with exponential back-off
  - Tamper-evident audit chain (SHA-256 linked hashes)
  - XOR+base64 obfuscation for at-rest secrets
  - Constant-time comparison everywhere (no timing attacks)
  - Input sanitisation + length caps
"""

import hashlib
import hmac
import re
import secrets
import string
import base64
import time
import json
import os
from typing import Tuple, Optional

# ── Constants ──────────────────────────────────────────────────────────────────
PBKDF2_ITERATIONS   = 390_000          # OWASP 2023 for PBKDF2-HMAC-SHA256
KEY_SALT_LEN        = 32               # bytes for random salt
MAX_FAILED_ATTEMPTS = 5                # before lockout
LOCKOUT_SECONDS     = 300              # 5-minute lockout window

# Key format:  mk-{10 alphanum}-dev-{2 alphanum}-ai
# Example:     mk-aB3xZ9kL2p-dev-q7-ai
_KEY_CHARSET  = string.ascii_letters + string.digits   # [A-Za-z0-9]
_KEY_RE       = re.compile(
    r"^mk-[A-Za-z0-9]{10}-dev-[A-Za-z0-9]{2}-ai$"
)
_ADMIN_KEY_RE = re.compile(
    r"^mk-admin-[A-Za-z0-9_-]{32,}$"
)

# XOR obfuscation key  (MKDEVAPI_SECURE!)
_OBF_KEY = bytes([
    0x4D, 0x4B, 0x44, 0x45, 0x56, 0x41, 0x50, 0x49,
    0x5F, 0x53, 0x45, 0x43, 0x55, 0x52, 0x45, 0x21,
])


# ══════════════════════════════════════════════════════════════════════════════
#  KEY GENERATION
# ══════════════════════════════════════════════════════════════════════════════

def generate_api_key() -> str:
    """
    Generate a cryptographically secure API key.

    Format:  mk-{10 chars}-dev-{2 chars}-ai
    Example: mk-aB3xZ9kL2p-dev-q7-ai

    Uses secrets.choice (CSPRNG) — never random.random().
    """
    part1 = "".join(secrets.choice(_KEY_CHARSET) for _ in range(10))
    part2 = "".join(secrets.choice(_KEY_CHARSET) for _ in range(2))
    return f"mk-{part1}-dev-{part2}-ai"


def generate_admin_key() -> str:
    """Format: mk-admin-{43 url-safe base64 chars}"""
    raw    = secrets.token_bytes(32)
    suffix = base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
    return f"mk-admin-{suffix}"


def generate_salt() -> str:
    """32 cryptographically random bytes, base64-encoded."""
    return base64.b64encode(os.urandom(KEY_SALT_LEN)).decode("ascii")


# ══════════════════════════════════════════════════════════════════════════════
#  HASHING & VERIFICATION
# ══════════════════════════════════════════════════════════════════════════════

def hash_secret(secret: str, salt: str) -> str:
    """
    PBKDF2-HMAC-SHA256, 390k iterations.
    Returns lowercase hex digest (64 chars).
    """
    dk = hashlib.pbkdf2_hmac(
        "sha256",
        secret.encode("utf-8"),
        base64.b64decode(salt),
        PBKDF2_ITERATIONS,
        dklen=32,
    )
    return dk.hex()


def verify_secret(secret: str, salt: str, stored_hash: str) -> bool:
    """Constant-time comparison — immune to timing attacks."""
    candidate = hash_secret(secret, salt)
    return hmac.compare_digest(candidate, stored_hash)


# ══════════════════════════════════════════════════════════════════════════════
#  AT-REST OBFUSCATION  (XOR + base64)
# ══════════════════════════════════════════════════════════════════════════════

def obfuscate(plaintext: str) -> str:
    """XOR-obfuscate a string so it doesn't appear in plaintext source."""
    data = plaintext.encode("utf-8")
    xord = bytes(b ^ _OBF_KEY[i % len(_OBF_KEY)] for i, b in enumerate(data))
    return base64.b64encode(xord).decode("ascii")


def deobfuscate(ciphertext: str) -> str:
    """Reverse of obfuscate()."""
    xord = base64.b64decode(ciphertext.encode("ascii"))
    data = bytes(b ^ _OBF_KEY[i % len(_OBF_KEY)] for i, b in enumerate(xord))
    return data.decode("utf-8")


# ══════════════════════════════════════════════════════════════════════════════
#  HMAC REQUEST SIGNING
# ══════════════════════════════════════════════════════════════════════════════

def sign_request(payload: dict, secret_key: str) -> str:
    """HMAC-SHA256 of a canonical JSON representation."""
    body = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    sig  = hmac.new(secret_key.encode("utf-8"), body.encode("utf-8"), hashlib.sha256)
    return sig.hexdigest()


def verify_signature(payload: dict, secret_key: str, signature: str) -> bool:
    return hmac.compare_digest(sign_request(payload, secret_key), signature)


# ══════════════════════════════════════════════════════════════════════════════
#  RATE LIMITING  (sliding window, in-memory)
# ══════════════════════════════════════════════════════════════════════════════

_rate_store: dict = {}   # identifier → [timestamps]


def check_rate_limit(identifier: str, max_calls: int, window_seconds: int) -> bool:
    """
    Returns True (allow) or False (deny) using a sliding-window counter.
    Thread-safe for single-process deployments.
    """
    now  = time.monotonic()
    hits = [t for t in _rate_store.get(identifier, []) if now - t < window_seconds]
    if len(hits) >= max_calls:
        _rate_store[identifier] = hits
        return False
    hits.append(now)
    _rate_store[identifier] = hits
    return True


def rate_limit_remaining(identifier: str, max_calls: int, window_seconds: int) -> int:
    """How many calls are still allowed in the current window."""
    now  = time.monotonic()
    hits = [t for t in _rate_store.get(identifier, []) if now - t < window_seconds]
    return max(0, max_calls - len(hits))


# ══════════════════════════════════════════════════════════════════════════════
#  BRUTE-FORCE LOCKOUT  (exponential back-off)
# ══════════════════════════════════════════════════════════════════════════════

_failed_attempts: dict = {}   # identifier → {count, locked_until}


def record_failed_attempt(identifier: str) -> dict:
    """
    Track a failed auth attempt.
    Returns {'locked': bool, 'remaining_seconds': int, 'attempts': int}.
    Back-off doubles each lockout:  300s → 600s → 1200s … (cap 3600s).
    """
    now  = time.time()
    info = _failed_attempts.get(identifier, {"count": 0, "locked_until": 0, "lockouts": 0})

    if info["locked_until"] > now:
        return {
            "locked":            True,
            "remaining_seconds": int(info["locked_until"] - now),
            "attempts":          info["count"],
        }

    info["count"] += 1
    if info["count"] >= MAX_FAILED_ATTEMPTS:
        lockouts        = info.get("lockouts", 0) + 1
        duration        = min(LOCKOUT_SECONDS * (2 ** (lockouts - 1)), 3600)
        info["locked_until"] = now + duration
        info["count"]        = 0
        info["lockouts"]     = lockouts
        _failed_attempts[identifier] = info
        return {"locked": True, "remaining_seconds": int(duration), "attempts": 0}

    _failed_attempts[identifier] = info
    return {"locked": False, "remaining_seconds": 0, "attempts": info["count"]}


def clear_failed_attempts(identifier: str) -> None:
    _failed_attempts.pop(identifier, None)


def is_locked_out(identifier: str) -> Tuple[bool, int]:
    """Returns (is_locked, seconds_remaining)."""
    now  = time.time()
    info = _failed_attempts.get(identifier, {"count": 0, "locked_until": 0})
    if info["locked_until"] > now:
        return True, int(info["locked_until"] - now)
    return False, 0


# ══════════════════════════════════════════════════════════════════════════════
#  TAMPER-EVIDENT AUDIT CHAIN
# ══════════════════════════════════════════════════════════════════════════════

def compute_log_chain_hash(previous_hash: str, entry: dict) -> str:
    """
    SHA-256 of (previous_hash + canonical JSON of entry).
    Changing any entry invalidates all subsequent hashes.
    """
    data = previous_hash + json.dumps(entry, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def verify_audit_chain(logs: list) -> Tuple[bool, int]:
    """
    Walk the audit chain and verify every link.
    Returns (is_valid, first_bad_index) — index is -1 if all good.
    """
    if not logs:
        return True, -1
    prev = "GENESIS"
    for i, entry in enumerate(logs):
        stored = entry.get("_chain_hash", "")
        body   = {k: v for k, v in entry.items() if k != "_chain_hash"}
        if not hmac.compare_digest(compute_log_chain_hash(prev, body), stored):
            return False, i
        prev = stored
    return True, -1


# ══════════════════════════════════════════════════════════════════════════════
#  INPUT VALIDATION
# ══════════════════════════════════════════════════════════════════════════════

def validate_api_key_format(key: str) -> bool:
    """
    Validate new key format:  mk-{10}-dev-{2}-ai

    Examples of valid keys:
        mk-aB3xZ9kL2p-dev-q7-ai
        mk-Zz0000aaAA-dev-Bb-ai

    Returns True only if the key matches exactly.
    """
    if not isinstance(key, str):
        return False
    return bool(_KEY_RE.match(key))


def validate_admin_key_format(key: str) -> bool:
    if not isinstance(key, str):
        return False
    return bool(_ADMIN_KEY_RE.match(key))


def sanitize_string(s: str, max_len: int = 256) -> str:
    """Strip non-printable characters and cap length."""
    if not isinstance(s, str):
        return ""
    return "".join(c for c in s if c.isprintable())[:max_len]


def describe_key_format() -> str:
    """Human-readable description of the expected key format."""
    return (
        "mk-{10 chars}-dev-{2 chars}-ai\n"
        "Example: mk-aB3xZ9kL2p-dev-q7-ai\n"
        "Characters: A-Z, a-z, 0-9 only"
    )
