"""
MKDEVAI  v2.3.0  ·  Powered by MKDEVAPI
========================================

Install
-------
    pip install mkdevai

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FREE TIER  —  No API key needed
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    import mkdevai

    # Simplest possible usage — one line!
    print(mkdevai.free.chat("What is Python?"))

    # Choose a model
    print(mkdevai.free.gemini.chat("Hello!"))
    print(mkdevai.free.gpt4o_mini.chat("Hello!"))
    print(mkdevai.free.gpt4_nano.chat("Hello!"))

    # Stateful bot (remembers conversation)
    bot = mkdevai.MKAIFree()
    bot.chat("My name is Sara")
    bot.chat("What's my name?")   # → "Your name is Sara"

    # New bot from free module
    bot = mkdevai.free.bot()

    # Check remaining requests
    print(mkdevai.free.remaining())

    Free tier limits:
      • 3 models available
      • 10 requests per hour
      • 500 tokens per reply

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  WITH API KEY  —  Full access
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    import mkdevai

    bot = mkdevai.MKAI(api_key="mk-aB3xZ9kL2p-dev-q7-ai")
    print(bot.chat("Hello!"))

    # See all models
    print(bot.models)

    # Switch model
    bot.set_model("gemini-2.5-flash-lite")

    # One-shot question (no memory)
    print(bot.ask("What is 2 + 2?"))

    # Image analysis
    desc = bot.analyze_image("photo.jpg", "What is in this image?")

    # Web search
    results = bot.search("Python 3.13 new features")

    # Token usage
    print(bot.usage())

    # Account info
    print(bot.account)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  CLI
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    python -m mkdevai
    mkdevai

API key format:  mk-{10 chars}-dev-{2 chars}-ai
Example:         mk-aB3xZ9kL2p-dev-q7-ai
"""

from .client import MKAI, MKAIFree, _FreeTierModule
from .auth   import mkai, mkaadmin, mkmahabbatt

__version__ = "2.3.0"
__author__  = "MKDEVAPI"
__all__     = [
    "MKAI",
    "MKAIFree",
    "free",
    "mkai",
    "mkaadmin",
    "mkmahabbatt",
    "__version__",
]

# ── Free tier singleton  ───────────────────────────────────────────────────────
#
#   import mkdevai
#   mkdevai.free.chat("Hello!")            ← simplest
#   mkdevai.free.gemini.chat("Hello!")     ← specific model
#   mkdevai.free.bot()                     ← stateful bot
#   mkdevai.free.remaining()               ← requests left
#
free = _FreeTierModule()
