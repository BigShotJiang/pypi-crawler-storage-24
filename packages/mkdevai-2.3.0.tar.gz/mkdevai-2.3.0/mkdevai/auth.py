"""
MKDEVAI  Authentication & Advanced Admin Panel v2.3.0
Powered by MKDEVAPI  ·  Max Security Edition
"""

import os
import time
import datetime
import getpass
import secrets
import string

from .constants import (
    C, _ADMIN_PASS_SALT, _ADMIN_PASS_HASH,
    ADMIN_RATE_LIMIT_CALLS, ADMIN_RATE_LIMIT_WINDOW,
    FREE_MODELS, MODEL_PRICES,
)
from .security import (
    verify_secret, is_locked_out, record_failed_attempt,
    clear_failed_attempts, check_rate_limit,
    validate_api_key_format, sanitize_string,
    generate_salt, hash_secret,
)
from .db import (
    authenticate_user, get_user, create_user, list_users,
    update_user, ban_user, unban_user, revoke_user,
    regenerate_key, search_users, reset_daily_usage,
    create_admin_key, list_admin_key_previews,
    export_users_json, analytics, top_users,
    get_audit_log, verify_log_integrity, audit,
    DB_FILE, LOG_FILE,
)

ALL_MODEL_IDS     = [m[0] for m in FREE_MODELS]
VERSION           = "2.3.0"
_SESSION_TOKEN    = None        # set after login
_SESSION_STARTED  = 0.0         # epoch timestamp
_SESSION_TIMEOUT  = 1800        # 30 min auto-logout
_SESSION_MAX_OPS  = 200         # max operations per session


def _session_valid():
    """Returns True if admin session is still active."""
    if _SESSION_TOKEN is None:
        return False
    if time.time() - _SESSION_STARTED > _SESSION_TIMEOUT:
        return False
    return True


def _session_touch():
    """Refresh session timestamp on each operation."""
    global _SESSION_STARTED
    _SESSION_STARTED = time.time()


def _secure_input(prompt_text):
    """
    Read password securely on any terminal type.
    Uses termios on real TTY (shows ****), falls back to plain readline.
    Never calls getpass.getpass or /dev/tty.
    """
    import sys
    sys.stdout.write("  " + str(prompt_text) + " ")
    sys.stdout.flush()
    try:
        import termios, tty
        fd  = sys.stdin.fileno()
        old_attrs = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            chars = []
            while True:
                ch = sys.stdin.read(1)
                if ch in ("\n", "\r"):
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    break
                elif ch in ("\x7f", "\x08"):
                    if chars:
                        chars.pop()
                        sys.stdout.write("\b \b")
                        sys.stdout.flush()
                elif ch == "\x03":
                    sys.stdout.write("\n")
                    raise KeyboardInterrupt
                elif ch == "\x04":
                    sys.stdout.write("\n")
                    raise EOFError
                else:
                    chars.append(ch)
                    sys.stdout.write("*")
                    sys.stdout.flush()
            return "".join(chars)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_attrs)
    except Exception:
        # Non-TTY / no termios — read from stdin directly
        try:
            val = sys.stdin.readline()
            return val.rstrip("\n\r") if val else ""
        except Exception:
            return ""


def _inp(prompt, secret=False):
    try:
        if secret:
            return _secure_input(prompt)
        return input("  " + C.YELLOW + prompt + C.RESET + " ").strip()
    except (KeyboardInterrupt, EOFError):
        return ""


def _now_date():
    return datetime.datetime.utcnow().strftime("%Y-%m-%d")


def _days_until_expiry(expires_on):
    if not expires_on or expires_on == "never":
        return None
    try:
        exp = datetime.datetime.strptime(expires_on, "%Y-%m-%d")
        return (exp - datetime.datetime.utcnow()).days
    except Exception:
        return None


# ── User auth ──────────────────────────────────────────────────────────────────
def mkai(api_key, caller_id="default"):
    if not validate_api_key_format(api_key):
        raise ValueError("Invalid API key. Contact admins.")
    if not check_rate_limit("auth:" + caller_id, max_calls=20, window_seconds=60):
        raise ValueError("Too many requests. Please wait.")
    locked, remaining = is_locked_out("auth:" + api_key[:14])
    if locked:
        raise ValueError(f"Too many failed attempts. Try again in {remaining}s.")
    user = authenticate_user(api_key)
    if not user:
        status = record_failed_attempt("auth:" + api_key[:14])
        if status["locked"]:
            raise ValueError(f"Locked for {status['remaining_seconds']}s.")
        raise ValueError("Invalid API key. Contact admins.")
    clear_failed_attempts("auth:" + api_key[:14])
    if user.get("revoked"):
        raise ValueError("API key revoked. Contact admins.")
    if user.get("banned"):
        raise ValueError("Account suspended. Contact admins.")
    expires_on = user.get("expires_on", "never")
    if expires_on and expires_on != "never":
        dl = _days_until_expiry(expires_on)
        if dl is not None and dl < 0:
            raise ValueError("API key expired. Contact admins.")

    # Enforce daily token limit
    # -1 = unlimited, 0 = blocked (no tokens allowed), N = daily cap
    daily_limit = user.get("daily_limit", -1)   # -1=unlimited, 0=blocked, N=cap
    daily_used  = user.get("daily_usage", {}).get("tokens", 0)
    if daily_limit == 0:
        raise ValueError(
            "Token allowance is 0. No requests are permitted. Contact admins."
        )
    if daily_limit > 0 and daily_used >= daily_limit:
        raise ValueError(
            f"Daily token limit reached ({daily_used:,}/{daily_limit:,} tokens). "
            "Limit resets at UTC midnight."
        )

    audit("user_auth_ok", f"name={user.get('name','?')} key={api_key[:14]}")
    return {
        "authenticated": True,
        "name":          user.get("name", "User"),
        "key":           api_key,
        "daily_limit":   0 if daily_limit == -1 else daily_limit,
        "daily_used":    daily_used,
        "model_access":  user.get("model_access", ALL_MODEL_IDS),
        "expires_on":    expires_on,
        "note":          user.get("note", ""),
        "powered_by":    "MKDEVAPI",
    }


def mkmahabbatt():
    # Internal function — not documented publicly
    print(f"\n  {C.DIM}MKDEVAPI — Powered by MK-AI v{VERSION}{C.RESET}\n")


# ── Admin banner ───────────────────────────────────────────────────────────────
def _admin_banner():
    print()
    print(C.CYAN + C.BOLD)
    print("  ╔════════════════════════════════════════════════════╗")
    print("  ║   MK-AI Admin Panel  ·  Powered by MKDEVAPI       ║")
    print(f"  ║   v{VERSION}  ·  Max Security Edition                  ║")
    print("  ╚════════════════════════════════════════════════════╝")
    print(C.RESET)


# ── Security verification ──────────────────────────────────────────────────────
def _verify_admin_password(attempt_id="admin_panel"):
    global _SESSION_TOKEN, _SESSION_STARTED

    if not check_rate_limit(f"admin_login:{attempt_id}", ADMIN_RATE_LIMIT_CALLS, ADMIN_RATE_LIMIT_WINDOW):
        print(f"\n{C.RED}  ⛔ Too many login attempts. Please wait.{C.RESET}\n")
        return False

    locked, remaining = is_locked_out(f"admin_login:{attempt_id}")
    if locked:
        print(f"\n{C.RED}  🔒 Admin panel locked. Try again in {remaining}s.{C.RESET}\n")
        return False

    # Plain prompt — ANSI codes corrupt getpass display on many terminals
    try:
        pwd = _secure_input("Admin Password:")
    except (KeyboardInterrupt, EOFError):
        print()
        return False

    if not pwd:
        return False

    ok = verify_secret(pwd, _ADMIN_PASS_SALT, _ADMIN_PASS_HASH)
    if ok:
        clear_failed_attempts(f"admin_login:{attempt_id}")
        _SESSION_TOKEN   = secrets.token_hex(24)
        _SESSION_STARTED = time.time()
        audit("admin_login_ok")
        return True

    status = record_failed_attempt(f"admin_login:{attempt_id}")
    audit("admin_login_fail")
    if status["locked"]:
        print(f"\n{C.RED}  🔒 Too many failures. Locked for {status['remaining_seconds']}s.{C.RESET}\n")
    else:
        print(f"\n{C.RED}  ✗ Incorrect password.{C.RESET}\n")
    return False


# ── Admin menu ─────────────────────────────────────────────────────────────────
def _admin_menu():
    g  = C.GREEN;  r  = C.RESET
    cy = C.CYAN;   bo = C.BOLD
    di = C.DIM;    rd = C.RED
    ye = C.YELLOW

    print(cy + bo + "\n  ┌─ User Management ───────────────────────────────────────────┐" + r)
    print(f"   {g} 1{r}.  Create user              {di}(generates mk-ai-... key){r}")
    print(f"   {g} 2{r}.  List all users")
    print(f"   {g} 3{r}.  View user details         {di}(shows masked key){r}")
    print(f"   {g} 4{r}.  View user full API key    {ye}⚠ shows plaintext{r}")
    print(f"   {g} 5{r}.  Edit user  {di}(limit / models / expiry){r}")
    print(f"   {g} 6{r}.  Regenerate user API key")
    print(f"   {g} 7{r}.  Search users")
    print(f"   {g} 8{r}.  Delete / permanently remove user  {rd}(irreversible){r}")
    print(f"   {g} 9{r}.  Revoke user API key       {di}(permanent){r}")
    print(f"   {g}10{r}.  Ban user                  {di}(reversible){r}")
    print(f"   {g}11{r}.  Unban user")
    print(f"   {g}12{r}.  Reset daily usage")
    print(f"   {g}20{r}.  Bulk create users         {di}(up to 50){r}")
    print(f"   {g}21{r}.  Set user note / tag")
    print(f"   {g}22{r}.  List banned users")
    print(f"   {g}23{r}.  List revoked users")
    print(f"   {g}31{r}.  Set user expiry date")
    print(f"   {g}32{r}.  List expiring users       {di}(within 7 days){r}")

    print(cy + bo + "\n  ├─ Analytics & Logs ──────────────────────────────────────────┤" + r)
    print(f"   {g}13{r}.  Analytics dashboard")
    print(f"   {g}14{r}.  Audit log")
    print(f"   {g}15{r}.  Verify audit log integrity")
    print(f"   {g}16{r}.  Token usage & costs")
    print(f"   {g}17{r}.  Top users by usage")
    print(f"   {g}18{r}.  Export users to JSON")
    print(f"   {g}24{r}.  Daily usage report")
    print(f"   {g}25{r}.  Cost summary by model")
    print(f"   {g}26{r}.  Inactive users")
    print(f"   {g}33{r}.  User activity summary")

    print(cy + bo + "\n  ├─ Admin & Security ──────────────────────────────────────────┤" + r)
    print(f"   {g}19{r}.  View Puter token")
    print(f"   {g}27{r}.  Create new admin key")
    print(f"   {g}28{r}.  Show admin key previews")
    print(f"   {g}29{r}.  Generate new password hash")
    print(f"   {g}30{r}.  Security status")
    print(f"   {g}34{r}.  Set broadcast notice")
    print(f"   {g}35{r}.  Wipe database  {rd}(DANGER: deletes everything){r}")

    print(cy + bo + "\n  └─────────────────────────────────────────────────────────────┘" + r)
    print(f"   {rd} 0{r}.  Exit admin panel\n")


def _create_user_flow():
    name = sanitize_string(_inp("User name:"), 64)
    if not name:
        return None
    lim_s  = _inp("Daily token limit (0=unlimited, default 1000):")
    limit  = 0 if lim_s == "0" else (int(lim_s) if lim_s.isdigit() else 1000)
    print(f"\n  {C.DIM}Available models:{C.RESET}")
    for i, (mid, lbl) in enumerate(FREE_MODELS, 1):
        print(f"  {C.YELLOW}{i}{C.RESET}.  {lbl}")
    sel = _inp("Model numbers (0=ALL, Enter=defaults 1,2,4):")
    if sel == "0":
        models = ALL_MODEL_IDS
    elif sel:
        try:
            indices = [int(x.strip()) - 1 for x in sel.split(",") if x.strip().isdigit()]
            models  = [FREE_MODELS[i][0] for i in indices if 0 <= i < len(FREE_MODELS)]
            if not models:
                models = ["gpt-4o-mini", "gpt-4.1-nano", "gemini-2.5-flash-lite"]
        except Exception:
            models = ["gpt-4o-mini", "gpt-4.1-nano", "gemini-2.5-flash-lite"]
    else:
        models = ["gpt-4o-mini", "gpt-4.1-nano", "gemini-2.5-flash-lite"]
    exp_s = _inp("Expires in how many days? (0=never):")
    if not exp_s or exp_s == "0":
        expires_on = "never"
    elif exp_s.isdigit():
        exp_date   = datetime.datetime.utcnow() + datetime.timedelta(days=int(exp_s))
        expires_on = exp_date.strftime("%Y-%m-%d")
    else:
        expires_on = "never"
    return create_user(name, daily_limit=limit, model_access=models, expires_on=expires_on)


# ── Confirm destructive action with re-auth ────────────────────────────────────
def _confirm_destructive(action_label, require_reauth=True):
    """Extra confirmation for destructive actions with optional re-auth."""
    print(f"\n  {C.RED}{C.BOLD}⚠  DESTRUCTIVE ACTION: {action_label}{C.RESET}")
    confirm = _inp("Type  YES  to confirm:")
    if confirm.strip() != "YES":
        print(f"  {C.YELLOW}Cancelled.{C.RESET}\n")
        return False
    if require_reauth:
        try:
            pwd = _secure_input("Re-enter admin password:")
        except (KeyboardInterrupt, EOFError):
            print(f"\n  {C.YELLOW}Cancelled.{C.RESET}\n")
            return False
        if not verify_secret(pwd, _ADMIN_PASS_SALT, _ADMIN_PASS_HASH):
            print(f"  {C.RED}Wrong password. Action aborted.{C.RESET}\n")
            audit("destructive_action_denied", action_label)
            return False
    return True


# ── Fully delete user ──────────────────────────────────────────────────────────
def _delete_user(api_key: str) -> bool:
    """Permanently remove a user from the database."""
    import json, os
    from pathlib import Path

    db_path = Path(DB_FILE)
    if not db_path.exists():
        return False
    with open(db_path, "r", encoding="utf-8") as f:
        db = json.load(f)
    if api_key not in db.get("users", {}):
        return False
    del db["users"][api_key]
    # Re-sign
    from .security import sign_request
    db_sign_key = "MKDEVAPI-DB-INTEGRITY-" + str(os.getuid() if hasattr(os, "getuid") else 0)
    payload = {k: v for k, v in db.items() if k != "_sig"}
    payload["_sig"] = sign_request(payload, db_sign_key)
    import tempfile, stat as _stat
    dir_ = str(db_path.parent)
    fd, tmp = tempfile.mkstemp(dir=dir_, prefix=".mkai_tmp_")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    os.replace(tmp, str(db_path))
    try:
        os.chmod(str(db_path), _stat.S_IRUSR | _stat.S_IWUSR)
    except Exception:
        pass
    audit("delete_user_permanent", api_key[:14])
    return True


# ── View full API key (requires re-auth) ──────────────────────────────────────
def _view_full_key_flow():
    q     = _inp("Name or key prefix:")
    found = search_users(q)
    if not found:
        print(f"  {C.RED}Not found.{C.RESET}\n")
        return
    u = found[0]
    print(f"\n  {C.YELLOW}⚠  About to view FULL API key for: {C.BOLD}{u['name']}{C.RESET}")
    print(f"  {C.DIM}This action is permanently logged in the audit trail.{C.RESET}")
    try:
        pwd = _secure_input("Re-enter admin password:")
    except (KeyboardInterrupt, EOFError):
        print(f"\n  {C.YELLOW}Cancelled.{C.RESET}\n")
        return
    if not verify_secret(pwd, _ADMIN_PASS_SALT, _ADMIN_PASS_HASH):
        print(f"  {C.RED}Wrong password. Access denied.{C.RESET}\n")
        audit("view_full_key_denied", u["key"][:14])
        return
    audit("view_full_key", f"name={u['name']} prefix={u['key'][:14]}")
    print(f"\n  {C.CYAN}{C.BOLD}Full API Key — {u['name']}:{C.RESET}")
    print(f"\n  {C.GREEN}{C.BOLD}  {u['key']}  {C.RESET}\n")
    print(f"  {C.DIM}⚠ Logged. This view is recorded permanently.{C.RESET}\n")


# ── Main admin panel ───────────────────────────────────────────────────────────
def mkaadmin():
    global _SESSION_TOKEN, _SESSION_STARTED
    _admin_banner()
    if not _verify_admin_password():
        return

    elapsed_allowed = _SESSION_TIMEOUT // 60
    print(f"  {C.GREEN}✓ Access granted.{C.RESET}")
    print(f"  {C.DIM}Session: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC  ·  "
          f"Auto-logout after {elapsed_allowed}min inactivity{C.RESET}\n")

    from .constants import get_puter_token

    while True:
        # ── Session timeout check ─────────────────────────────────────
        if not _session_valid():
            print(f"\n{C.YELLOW}  🔒 Session expired. Please re-authenticate.{C.RESET}\n")
            audit("admin_session_expired")
            _SESSION_TOKEN = None
            # Allow re-auth once
            if not _verify_admin_password():
                return
            print(f"  {C.GREEN}✓ Re-authenticated.{C.RESET}\n")

        _session_touch()
        _admin_menu()
        choice = _inp("Select option [0-35]:")
        if not choice:
            continue

        # ── 0  Exit ──────────────────────────────────────────────────
        if choice == "0":
            print(f"  {C.DIM}Session ended.{C.RESET}")
            _SESSION_TOKEN = None
            audit("admin_logout")
            break

        # ── 1  Create user ───────────────────────────────────────────
        elif choice == "1":
            user = _create_user_flow()
            if not user:
                continue
            lim_d  = "Unlimited" if user.get("daily_limit") == 0 else f"{user['daily_limit']:,} tokens/day"
            exp    = user.get("expires_on", "never")
            dl     = _days_until_expiry(exp)
            exp_str = "Never" if exp == "never" else f"{exp} ({dl} days)"
            print(f"\n{C.GREEN}  ✓ User Created!{C.RESET}")
            print(f"  Name    : {C.BOLD}{user['name']}{C.RESET}")
            print(f"  API Key : {C.CYAN}{C.BOLD}{user['key']}{C.RESET}")
            print(f"  Limit   : {lim_d}")
            print(f"  Models  : {', '.join(user['model_access'][:3])}{'…' if len(user['model_access'])>3 else ''}")
            print(f"  Expires : {exp_str}")
            print(f"  {C.RED}⚠ Key shown ONCE. Save it now!{C.RESET}\n")

        # ── 2  List users ────────────────────────────────────────────
        elif choice == "2":
            users = list_users()
            if not users:
                print(f"  {C.DIM}No users yet.{C.RESET}\n")
                continue
            print(f"\n{C.CYAN}{C.BOLD}  {'Name':<22}{'Key (masked)':<24}{'Tokens':>9}  {'Expires':<13}Status{C.RESET}")
            print(f"  {'─'*78}")
            for u in users:
                exp   = u.get("expires_on", "never")
                days  = _days_until_expiry(exp)
                exp_s = "never" if exp == "never" else f"{exp[:10]} ({days}d)"
                if u["banned"]:       st = C.RED    + "BANNED"   + C.RESET
                elif u["revoked"]:    st = C.YELLOW + "REVOKED"  + C.RESET
                elif days is not None and days < 0:  st = C.RED    + "EXPIRED"  + C.RESET
                elif days is not None and days <= 3: st = C.YELLOW + "expiring" + C.RESET
                else:                 st = C.GREEN  + "active"   + C.RESET
                key_masked = u["key"][:14] + "…" + u["key"][-4:]
                print(f"  {u['name'][:22]:<22}{key_masked:<24}{u['usage']['total_tokens']:>9}  {exp_s[:13]:<13}{st}")
            print()

        # ── 3  View user details (masked key) ────────────────────────
        elif choice == "3":
            q     = _inp("Name or key prefix:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n")
                continue
            u   = found[0]
            exp = u.get("expires_on", "never")
            dl  = _days_until_expiry(exp)
            lim = "Unlimited" if u.get("daily_limit") == 0 else f"{u.get('daily_limit', 0):,} tokens/day"
            print(f"\n{C.CYAN}{C.BOLD}  User Details{C.RESET}")
            print(f"  Name        : {u['name']}")
            print(f"  Key (masked): {u['key'][:14]}…{u['key'][-6:]}")
            print(f"  Created     : {str(u.get('created','?'))[:19]}")
            print(f"  Last seen   : {str(u.get('last_seen') or 'never')[:19]}")
            status = "BANNED" if u["banned"] else ("REVOKED" if u["revoked"] else "Active")
            print(f"  Status      : {status}")
            print(f"  Daily limit : {lim}")
            print(f"  Today used  : {u['daily_usage']['tokens']:,} tokens")
            print(f"  Expires     : {'never' if exp=='never' else exp+' ('+str(dl)+' days left)'}")
            print(f"  Note        : {u.get('note') or '(none)'}")
            print(f"  Models      : {', '.join(u.get('model_access', []))}")
            g = u["usage"]
            print(f"  {C.BOLD}Lifetime:{C.RESET}")
            print(f"    Prompt    : {g['prompt_tokens']:,}")
            print(f"    Completion: {g['completion_tokens']:,}")
            print(f"    Total     : {g['total_tokens']:,}")
            print(f"    Requests  : {g['requests']:,}")
            print(f"    Cost USD  : ${g['total_cost_usd']:.6f}")
            print(f"  {C.DIM}Use option 4 to view the full API key (requires re-auth).{C.RESET}\n")

        # ── 4  View FULL API key (re-auth required) ───────────────────
        elif choice == "4":
            _view_full_key_flow()

        # ── 5  Edit user ─────────────────────────────────────────────
        elif choice == "5":
            q     = _inp("Name or key prefix:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n")
                continue
            u    = found[0]
            akey = u["key"]
            cur  = "unlimited" if u.get("daily_limit") == 0 else str(u.get("daily_limit", 1000))
            lim_s = _inp(f"New daily limit (0=unlimited, Enter=skip, current={cur}):")
            if lim_s == "0":   update_user(akey, daily_limit=0);          print(f"  {C.GREEN}Set unlimited.{C.RESET}")
            elif lim_s.isdigit(): update_user(akey, daily_limit=int(lim_s)); print(f"  {C.GREEN}Limit updated.{C.RESET}")
            print(f"  Current models: {C.DIM}{', '.join(u.get('model_access',[]))}{C.RESET}")
            for i, (mid, lbl) in enumerate(FREE_MODELS, 1):
                cur2 = "v" if mid in u.get("model_access", []) else " "
                print(f"  [{cur2}] {C.YELLOW}{i}{C.RESET}. {lbl}")
            sel = _inp("Model numbers (0=all, Enter=skip):")
            if sel == "0":
                update_user(akey, model_access=ALL_MODEL_IDS); print(f"  {C.GREEN}All models.{C.RESET}")
            elif sel:
                idxs = [int(x.strip()) - 1 for x in sel.split(",") if x.strip().isdigit()]
                mods = [FREE_MODELS[i][0] for i in idxs if 0 <= i < len(FREE_MODELS)]
                if mods:
                    update_user(akey, model_access=mods); print(f"  {C.GREEN}Models updated.{C.RESET}")
            exp_s = _inp("New expiry days (0=never, Enter=skip):")
            if exp_s == "0":
                update_user(akey, expires_on="never"); print(f"  {C.GREEN}Expiry removed.{C.RESET}")
            elif exp_s.isdigit():
                ed = datetime.datetime.utcnow() + datetime.timedelta(days=int(exp_s))
                update_user(akey, expires_on=ed.strftime("%Y-%m-%d"))
                print(f"  {C.GREEN}Expiry: {ed.strftime('%Y-%m-%d')}{C.RESET}")
            audit("edit_user", akey[:14])
            print(f"  {C.GREEN}Done.{C.RESET}\n")

        # ── 6  Regenerate key ─────────────────────────────────────────
        elif choice == "6":
            q     = _inp("Name or key prefix:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n")
                continue
            new_key = regenerate_key(found[0]["key"])
            if new_key:
                print(f"\n  {C.GREEN}✓ New API key:{C.RESET}")
                print(f"  {C.CYAN}{C.BOLD}{new_key}{C.RESET}")
                print(f"  {C.RED}Old key is now invalid.{C.RESET}\n")
            else:
                print(f"  {C.RED}Failed.{C.RESET}\n")

        # ── 7  Search users ───────────────────────────────────────────
        elif choice == "7":
            q     = sanitize_string(_inp("Search:"), 64)
            found = search_users(q)
            if not found:
                print(f"  {C.DIM}No results.{C.RESET}\n")
            for u in found:
                st = "BANNED" if u["banned"] else ("REVOKED" if u["revoked"] else "active")
                print(f"  {C.GREEN}{u['name']:<22}{C.RESET}  {u['key'][:20]}…  {st}  tokens={u['usage']['total_tokens']:,}")
            print()

        # ── 8  DELETE user (permanent, re-auth) ───────────────────────
        elif choice == "8":
            q     = _inp("Name or key prefix:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n")
                continue
            u = found[0]
            print(f"\n  {C.RED}{C.BOLD}⚠  PERMANENT DELETE: {u['name']}{C.RESET}")
            print(f"  {C.DIM}This will permanently remove the user and all their data.{C.RESET}")
            if _confirm_destructive(f"DELETE user '{u['name']}'", require_reauth=True):
                ok = _delete_user(u["key"])
                if ok:
                    print(f"  {C.RED}✓ User '{u['name']}' permanently deleted.{C.RESET}\n")
                else:
                    print(f"  {C.RED}Failed to delete.{C.RESET}\n")

        # ── 9  Revoke ─────────────────────────────────────────────────
        elif choice == "9":
            q     = _inp("Name or key:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n")
                continue
            confirm = _inp(f"Revoke {found[0]['name']}? (yes/no):")
            if confirm.lower() == "yes":
                revoke_user(found[0]["key"])
                print(f"  {C.YELLOW}✓ Revoked.{C.RESET}\n")

        # ── 10 Ban ────────────────────────────────────────────────────
        elif choice == "10":
            q     = _inp("Name or key:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n")
                continue
            if ban_user(found[0]["key"]):
                print(f"  {C.RED}✓ Banned: {found[0]['name']}{C.RESET}\n")

        # ── 11 Unban ──────────────────────────────────────────────────
        elif choice == "11":
            q     = _inp("Name or key:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n")
                continue
            if unban_user(found[0]["key"]):
                print(f"  {C.GREEN}✓ Unbanned: {found[0]['name']}{C.RESET}\n")

        # ── 12 Reset daily usage ──────────────────────────────────────
        elif choice == "12":
            q     = _inp("Name or key:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n")
                continue
            if reset_daily_usage(found[0]["key"]):
                print(f"  {C.GREEN}✓ Daily reset for {found[0]['name']}.{C.RESET}\n")

        # ── 13 Analytics ──────────────────────────────────────────────
        elif choice == "13":
            a = analytics()
            print(f"\n{C.CYAN}{C.BOLD}  Analytics  ·  MKDEVAPI{C.RESET}")
            print(f"  Total users    : {a['total_users']}")
            print(f"  Active         : {C.GREEN}{a['active_users']}{C.RESET}")
            print(f"  Banned         : {C.RED}{a['banned_users']}{C.RESET}")
            print(f"  Revoked        : {C.YELLOW}{a['revoked_users']}{C.RESET}")
            print(f"  Total requests : {a['total_requests']:,}")
            print(f"  Total tokens   : {a['total_tokens']:,}")
            print(f"  Est. cost      : ${a['total_cost_usd']:.6f}\n")

        # ── 14 Audit log ──────────────────────────────────────────────
        elif choice == "14":
            n_s  = _inp("How many entries? (default 30):")
            n    = int(n_s) if n_s.isdigit() else 30
            logs = get_audit_log(n)
            if not logs:
                print(f"  {C.DIM}No audit entries.{C.RESET}\n")
                continue
            print(f"\n{C.CYAN}{C.BOLD}  Audit Log ({len(logs)} entries){C.RESET}")
            for e in logs:
                print(f"  {C.DIM}{e['ts'][:19]}{C.RESET}  {C.YELLOW}{e['action']:<28}{C.RESET}  {e.get('detail','')}")
            print()

        # ── 15 Verify log integrity ───────────────────────────────────
        elif choice == "15":
            result = verify_log_integrity()
            if result["valid"]:
                print(f"  {C.GREEN}✓ Audit log INTACT ({result['entries']} entries){C.RESET}\n")
            else:
                print(f"  {C.RED}⚠ TAMPER detected at entry #{result['first_bad_index']}!{C.RESET}\n")

        # ── 16 Token usage ────────────────────────────────────────────
        elif choice == "16":
            users = list_users()
            print(f"\n{C.CYAN}{C.BOLD}  {'Name':<20}{'Prompt':>10}{'Complete':>10}{'Total':>9}{'Req':>7}{'Cost':>12}{C.RESET}")
            print(f"  {'─'*70}")
            for u in sorted(users, key=lambda x: x["usage"]["total_tokens"], reverse=True):
                g = u["usage"]
                print(f"  {u['name'][:20]:<20}{g['prompt_tokens']:>10,}{g['completion_tokens']:>10,}{g['total_tokens']:>9,}{g['requests']:>7,}{'$'+format(g['total_cost_usd'],'.4f'):>12}")
            print()

        # ── 17 Top users ──────────────────────────────────────────────
        elif choice == "17":
            print(f"\n{C.CYAN}{C.BOLD}  Top 10 Users by Token Usage{C.RESET}")
            for i, u in enumerate(top_users(10), 1):
                print(f"  {C.YELLOW}{i:2}{C.RESET}.  {u['name']:<24}  {u['usage']['total_tokens']:>12,} tokens")
            print()

        # ── 18 Export users ───────────────────────────────────────────
        elif choice == "18":
            path = os.path.join(os.path.expanduser("~"), "mkai_users_export.json")
            with open(path, "w", encoding="utf-8") as f:
                f.write(export_users_json())
            try:
                import stat as _s; os.chmod(path, _s.S_IRUSR | _s.S_IWUSR)
            except Exception:
                pass
            print(f"  {C.GREEN}✓ Exported to {path}{C.RESET}\n")
            audit("export_users")

        # ── 19 View Puter token ───────────────────────────────────────
        elif choice == "19":
            tok = get_puter_token()
            print(f"  Token: {C.CYAN}{tok[:14]}…{tok[-8:]}{C.RESET}\n")

        # ── 20 Bulk create ────────────────────────────────────────────
        elif choice == "20":
            count_s = _inp("How many users? (max 50):")
            if not count_s.isdigit() or int(count_s) < 1:
                print(f"  {C.RED}Invalid.{C.RESET}\n"); continue
            count  = min(int(count_s), 50)
            prefix = _inp("Name prefix (Enter=user1,user2…):")
            lim_s  = _inp("Daily limit (0=unlimited, default 1000):")
            limit  = 0 if lim_s == "0" else (int(lim_s) if lim_s.isdigit() else 1000)
            exp_s  = _inp("Expires in days (0=never):")
            expires_on = "never"
            if exp_s and exp_s != "0" and exp_s.isdigit():
                expires_on = (datetime.datetime.utcnow() + datetime.timedelta(days=int(exp_s))).strftime("%Y-%m-%d")
            print(f"{C.GREEN}  Creating {count} users…{C.RESET}")
            for i in range(1, count + 1):
                name = sanitize_string((prefix + str(i)) if prefix else (f"user{i}"), 64)
                u    = create_user(name, daily_limit=limit, model_access=ALL_MODEL_IDS, expires_on=expires_on)
                print(f"  {C.YELLOW}{i:2}{C.RESET}.  {u['name']:<22}  {C.CYAN}{u['key']}{C.RESET}")
            print(f"{C.RED}  ⚠ Save all keys — shown once!{C.RESET}\n")
            audit("bulk_create", f"count={count}")

        # ── 21 Set note ───────────────────────────────────────────────
        elif choice == "21":
            q     = _inp("Name or key:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n"); continue
            u    = found[0]
            note = sanitize_string(_inp(f"Note for {u['name']}:"), 256)
            update_user(u["key"], note=note)
            print(f"  {C.GREEN}✓ Note saved.{C.RESET}\n")

        # ── 22 Banned ─────────────────────────────────────────────────
        elif choice == "22":
            banned = [u for u in list_users() if u["banned"]]
            if not banned:
                print(f"  {C.DIM}No banned users.{C.RESET}\n")
            else:
                print(f"\n{C.RED}{C.BOLD}  Banned ({len(banned)}){C.RESET}")
                for u in banned:
                    print(f"  {C.RED}✗{C.RESET}  {u['name']:<24}  {u['key'][:20]}…")
            print()

        # ── 23 Revoked ────────────────────────────────────────────────
        elif choice == "23":
            revoked = [u for u in list_users() if u["revoked"]]
            if not revoked:
                print(f"  {C.DIM}No revoked users.{C.RESET}\n")
            else:
                print(f"\n{C.YELLOW}{C.BOLD}  Revoked ({len(revoked)}){C.RESET}")
                for u in revoked:
                    print(f"  {C.YELLOW}✗{C.RESET}  {u['name']:<24}  {u['key'][:20]}…")
            print()

        # ── 24 Daily report ───────────────────────────────────────────
        elif choice == "24":
            today  = _now_date()
            users  = list_users()
            active = [u for u in users if u["daily_usage"]["date"] == today and u["daily_usage"]["tokens"] > 0]
            total  = sum(u["daily_usage"]["tokens"] for u in active)
            print(f"\n{C.CYAN}{C.BOLD}  Daily Report — {today} UTC{C.RESET}")
            print(f"  Active today : {len(active)} users  |  Total tokens: {total:,}")
            print(f"\n  {'Name':<22}{'Used':>9}{'Limit':>11}{'Pct':>7}")
            print(f"  {'─'*52}")
            for u in sorted(active, key=lambda x: x["daily_usage"]["tokens"], reverse=True):
                used  = u["daily_usage"]["tokens"]
                lim   = u.get("daily_limit", 0)
                if lim == 0: pct_s = "unlim"; bar = C.GREEN
                else:
                    pct = used / lim * 100
                    pct_s = f"{pct:.1f}%"
                    bar = C.RED if pct > 80 else (C.YELLOW if pct > 50 else C.GREEN)
                lim_s = "unlimited" if lim == 0 else f"{lim:,}"
                print(f"  {u['name'][:22]:<22}{used:>9,}{lim_s:>11}  {bar}{pct_s:>5}{C.RESET}")
            print()

        # ── 25 Cost by model ──────────────────────────────────────────
        elif choice == "25":
            users = list_users()
            total_cost = sum(u["usage"]["total_cost_usd"] for u in users)
            print(f"\n{C.CYAN}{C.BOLD}  Model Pricing (per 1M tokens){C.RESET}")
            for mid, lbl in FREE_MODELS:
                p = MODEL_PRICES.get(mid, {})
                print(f"  {lbl[:38]:<38}  in=${p.get('input',0):.3f}  out=${p.get('output',0):.3f}")
            print(f"\n  Total all users: ${total_cost:.6f}\n")

        # ── 26 Inactive ───────────────────────────────────────────────
        elif choice == "26":
            inactive = [u for u in list_users() if u["usage"]["requests"] == 0 and not u["banned"] and not u["revoked"]]
            if not inactive:
                print(f"  {C.DIM}All users have made at least one request.{C.RESET}\n")
            else:
                print(f"\n{C.YELLOW}{C.BOLD}  Inactive Users ({len(inactive)}){C.RESET}")
                for u in inactive:
                    print(f"  {u['name']:<24}  created {str(u.get('created','?'))[:10]}  {u['key'][:20]}…")
            print()

        # ── 27 Create admin key ───────────────────────────────────────
        elif choice == "27":
            new_key = create_admin_key()
            print(f"\n  {C.GREEN}✓ New admin key:{C.RESET}")
            print(f"  {C.CYAN}{C.BOLD}{new_key}{C.RESET}")
            print(f"  {C.RED}⚠ Stored as hash — never shown again. Copy now!{C.RESET}\n")

        # ── 28 Show admin key previews ────────────────────────────────
        elif choice == "28":
            previews = list_admin_key_previews()
            if not previews:
                print(f"  {C.DIM}No extra admin keys.{C.RESET}\n")
            for p in previews:
                print(f"  {C.CYAN}{p['preview']}{C.RESET}  created {p['created'][:10]}")
            print()

        # ── 29 Generate password hash ─────────────────────────────────
        elif choice == "29":
            new_pw = _inp("New admin password (min 8 chars):", secret=True)
            if len(new_pw) < 8:
                print(f"  {C.RED}Too short.{C.RESET}\n"); continue
            salt = generate_salt()
            hsh  = hash_secret(new_pw, salt)
            print(f"\n  {C.GREEN}Add to mk_ai/constants.py:{C.RESET}")
            print(f"  _ADMIN_PASS_SALT = {repr(salt)}")
            print(f"  _ADMIN_PASS_HASH = hash_secret({repr(new_pw)}, _ADMIN_PASS_SALT)")
            audit("password_hash_generated")
            print()

        # ── 30 Security status ────────────────────────────────────────
        elif choice == "30":
            from .security import _failed_attempts, _rate_store
            print(f"\n{C.CYAN}{C.BOLD}  Security Status{C.RESET}")
            print(f"  Rate-limit buckets : {len(_rate_store)}")
            print(f"  Failed attempt keys: {len(_failed_attempts)}")
            now    = time.time()
            locked = [(k, v) for k, v in _failed_attempts.items() if v.get("locked_until", 0) > now]
            if locked:
                print(f"  {C.RED}Locked ({len(locked)}):{C.RESET}")
                for k, v in locked:
                    print(f"    {k}  {int(v['locked_until'] - now)}s remaining")
            else:
                print(f"  {C.GREEN}No active lockouts.{C.RESET}")
            result = verify_log_integrity()
            st = (C.GREEN + "INTACT" + C.RESET) if result["valid"] else (C.RED + "TAMPERED" + C.RESET)
            print(f"  Audit log: {st}  ({result['entries']} entries)\n")

        # ── 31 Set expiry ─────────────────────────────────────────────
        elif choice == "31":
            q     = _inp("Name or key:")
            found = search_users(q)
            if not found:
                print(f"  {C.RED}Not found.{C.RESET}\n"); continue
            u     = found[0]
            exp_s = _inp("Expires in days (0=never):")
            if exp_s == "0":
                update_user(u["key"], expires_on="never")
                print(f"  {C.GREEN}✓ Expiry removed.{C.RESET}")
            elif exp_s.isdigit():
                ed = datetime.datetime.utcnow() + datetime.timedelta(days=int(exp_s))
                update_user(u["key"], expires_on=ed.strftime("%Y-%m-%d"))
                print(f"  {C.GREEN}✓ Expiry: {ed.strftime('%Y-%m-%d')}{C.RESET}")
            audit("set_expiry", u["key"][:14])
            print()

        # ── 32 Expiring soon ──────────────────────────────────────────
        elif choice == "32":
            expiring = []
            for u in list_users():
                exp  = u.get("expires_on", "never")
                days = _days_until_expiry(exp)
                if days is not None and days <= 7:
                    expiring.append((u, days))
            if not expiring:
                print(f"  {C.DIM}No users expiring within 7 days.{C.RESET}\n")
            else:
                print(f"\n{C.YELLOW}{C.BOLD}  Expiring soon ({len(expiring)}){C.RESET}")
                for u, days in sorted(expiring, key=lambda x: x[1]):
                    color = C.RED if days <= 0 else C.YELLOW
                    label = "EXPIRED" if days < 0 else ("TODAY" if days == 0 else f"{days} days")
                    print(f"  {C.GREEN}{u['name']:<24}{C.RESET}  expires {u.get('expires_on','?')}  {color}{label}{C.RESET}")
            print()

        # ── 33 User activity summary ──────────────────────────────────
        elif choice == "33":
            users = list_users()
            print(f"\n{C.CYAN}{C.BOLD}  User Activity Summary{C.RESET}")
            print(f"  {'Name':<22}{'Last Seen':<14}{'Req':>7}{'Tokens':>12}  Status")
            print(f"  {'─'*62}")
            for u in sorted(users, key=lambda x: x.get("last_seen") or "", reverse=True):
                last   = str(u.get("last_seen") or "never")[:10]
                status = "banned" if u["banned"] else ("revoked" if u["revoked"] else "active")
                print(f"  {u['name'][:22]:<22}{last:<14}{u['usage']['requests']:>7,}{u['usage']['total_tokens']:>12,}  {status}")
            print()

        # ── 34 Broadcast notice ───────────────────────────────────────
        elif choice == "34":
            notice_path = os.path.join(os.path.expanduser("~"), ".mkai_notice.txt")
            if os.path.exists(notice_path):
                print(f"  Current: {open(notice_path).read()[:80]}")
            msg = sanitize_string(_inp("New notice (Enter=clear):"), 512)
            with open(notice_path, "w", encoding="utf-8") as f:
                f.write(msg)
            print(f"  {C.GREEN}{'Saved' if msg else 'Cleared'}.{C.RESET}")
            audit("broadcast", msg[:60])
            print()

        # ── 35 Wipe database (DANGER) ─────────────────────────────────
        elif choice == "35":
            print(f"\n{C.RED}{C.BOLD}  ⚠  DANGER: This deletes ALL users and logs permanently!{C.RESET}")
            if _confirm_destructive("WIPE ENTIRE DATABASE", require_reauth=True):
                for fp in (DB_FILE, LOG_FILE):
                    try: os.remove(fp)
                    except Exception: pass
                print(f"  {C.RED}✓ Database wiped.{C.RESET}\n")

        else:
            print(f"  {C.RED}Invalid option. Enter a number 0-35.{C.RESET}\n")
