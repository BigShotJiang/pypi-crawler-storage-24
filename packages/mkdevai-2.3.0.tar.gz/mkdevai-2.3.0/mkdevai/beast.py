import requests
from bs4 import BeautifulSoup
import json
import re
import datetime
import os
import sys

# ─────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────
CONFIG_FILE    = "config.json"
PUTER_API_URL  = "https://api.puter.com/puterai/openai/v1/chat/completions"
MEMORY_FILE    = "memory.json"


# Free models via Puter (OpenAI-compatible endpoint — no API key needed)
FREE_MODELS = [
    ("gpt-4o-mini",              "GPT-4o Mini            (OpenAI) ⚡"),
    ("gpt-4.1-nano",             "GPT-4.1 Nano           (OpenAI) ⚡"),
    ("claude-haiku-4-5",         "Claude Haiku 4.5       (Anthropic)"),
    ("gemini-2.5-flash-lite",    "Gemini 2.5 Flash Lite  (Google) ⚡"),
    ("meta-llama/llama-3.3-70b-instruct", "LLaMA 3.3 70B (Meta)"),
    ("mistral-small-3.2",        "Mistral Small 3.2      (Mistral AI)"),
    ("deepseek/deepseek-r1",     "DeepSeek R1            (DeepSeek)"),
    ("grok-4-1-fast",            "Grok 4.1 Fast          (xAI)"),
    ("moonshotai/kimi-k2",       "Kimi K2                (Moonshot AI)"),
    ("qwen/qwen3-8b",            "Qwen 3 8B              (Alibaba)"),
]

DEFAULT_MODEL = FREE_MODELS[0][0]
MODEL         = DEFAULT_MODEL

def load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_config(cfg: dict):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

def _get_puter_token() -> str:
    """Load saved Puter token from config, or prompt user to paste one."""
    cfg = load_config()
    token = cfg.get("puter_token", "").strip()

    # Also check environment variable
    if not token:
        token = os.environ.get("PUTER_TOKEN", "").strip()

    if token:
        return token

    # First-time setup — guide user to get their token
    print(f"\n{C.CYAN}{C.BOLD}  ⚙  Puter Setup  (one-time only){C.RESET}")
    print(f"""
{C.YELLOW}  To use the free Puter AI API, you need your Puter auth token.
  It takes 30 seconds:{C.RESET}

  {C.BOLD}1.{C.RESET} Go to  {C.CYAN}https://puter.com{C.RESET}  and create a FREE account
  {C.BOLD}2.{C.RESET} After signing in, go to  {C.CYAN}https://puter.com/dashboard{C.RESET}
  {C.BOLD}3.{C.RESET} Click {C.BOLD}"Copy"{C.RESET} next to your auth token
  {C.BOLD}4.{C.RESET} Paste it below

{C.DIM}  Your token is saved locally — you won't be asked again.{C.RESET}
""")

    try:
        token = input(f"  Paste your Puter token: ").strip()
    except (KeyboardInterrupt, EOFError):
        print()
        sys.exit(0)

    if not token:
        print(f"{C.RED}  No token provided. Exiting.{C.RESET}")
        sys.exit(1)

    cfg["puter_token"] = token
    save_config(cfg)
    print(f"{C.GREEN}  ✓ Token saved to {CONFIG_FILE}{C.RESET}\n")
    return token

OR_API_KEY = ""   # holds puter token, loaded after C class is defined

# Keywords / patterns that hint a web search is needed
SEARCH_TRIGGERS = [
    r"\b(today|tonight|this week|this month|this year|right now|currently|latest|recent|live)\b",
    r"\b(news|headline|update|price|stock|weather|score|result|event)\b",
    r"\b(who is|who are|what is|what are|where is|when is|when did|when will)\b",
    r"\b(20[2-9]\d)\b",          # years like 2024, 2025 …
    r"\b(announce|launch|release|happen|occur)\b",
    r"\b(search|find|look up|google|browse)\b",
]

SEARCH_TRIGGER_RE = re.compile("|".join(SEARCH_TRIGGERS), re.IGNORECASE)

# ─────────────────────────────────────────────
#  COLORS  (ANSI)
# ─────────────────────────────────────────────
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    CYAN    = "\033[96m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    MAGENTA = "\033[95m"
    RED     = "\033[91m"
    BLUE    = "\033[94m"
    WHITE   = "\033[97m"
    BG_DARK = "\033[40m"

# ─────────────────────────────────────────────
#  MEMORY
# ─────────────────────────────────────────────
def load_memory() -> list:
    if os.path.exists(MEMORY_FILE):
        try:
            with open(MEMORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []

def save_memory(history: list):
    try:
        with open(MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history[-60:], f, ensure_ascii=False, indent=2)   # keep last 60 turns
    except Exception as e:
        print(f"{C.RED}Memory save failed: {e}{C.RESET}")

def add_to_memory(history: list, role: str, content: str):
    history.append({
        "role": role,
        "content": content,
        "timestamp": datetime.datetime.now().isoformat()
    })

# ─────────────────────────────────────────────
#  SMART SEARCH DECISION
# ─────────────────────────────────────────────
def needs_search(query: str, history: list) -> bool:
    """Ask the LLM itself whether a web search is needed."""
    recent = [{"role": m["role"], "content": m["content"]} for m in history[-6:]]
    recent.append({
        "role": "user",
        "content": (
            f'Does this question require a live web search to answer accurately? '
            f'Reply with only "YES" or "NO".\n\nQuestion: {query}'
        )
    })

    try:
        r = requests.post(
            PUTER_API_URL,
            headers={"Authorization": f"Bearer {OR_API_KEY}", "Content-Type": "application/json"},
            json={"model": MODEL, "messages": recent, "max_tokens": 5, "temperature": 0},
            timeout=10
        )
        decision = r.json()["choices"][0]["message"]["content"].strip().upper()
        return "YES" in decision
    except Exception:
        # Fallback: regex heuristic
        return bool(SEARCH_TRIGGER_RE.search(query))

# ─────────────────────────────────────────────
#  WEB SEARCH  (3 engines with fallback)
# ─────────────────────────────────────────────
def search_duckduckgo_api(query: str, max_results: int = 5) -> list:
    """DuckDuckGo Instant Answer API (no scraping, always works)."""
    try:
        resp = requests.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=10
        )
        data = resp.json()
        results = []

        # Abstract (top answer)
        if data.get("AbstractText"):
            results.append({
                "title":   data.get("Heading", query),
                "link":    data.get("AbstractURL", ""),
                "snippet": data["AbstractText"],
                "domain":  data.get("AbstractSource", ""),
            })

        # Related topics
        for topic in data.get("RelatedTopics", []):
            if len(results) >= max_results:
                break
            if isinstance(topic, dict) and topic.get("Text"):
                url = topic.get("FirstURL", "")
                results.append({
                    "title":   topic["Text"][:80],
                    "link":    url,
                    "snippet": topic["Text"],
                    "domain":  "duckduckgo.com",
                })

        return results
    except Exception:
        return []


def search_brave(query: str, max_results: int = 5) -> list:
    """Brave Search scraper fallback."""
    try:
        resp = requests.get(
            "https://search.brave.com/search",
            params={"q": query, "source": "web"},
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0",
                "Accept-Language": "en-US,en;q=0.9",
            },
            timeout=12
        )
        soup    = BeautifulSoup(resp.text, "html.parser")
        results = []

        for div in soup.select("[data-type='web'] .snippet"):
            title_el   = div.select_one(".snippet-title")
            snippet_el = div.select_one(".snippet-description")
            url_el     = div.select_one(".snippet-url")

            if not title_el:
                continue

            link = ""
            parent = div.find_parent("a")
            if parent:
                link = parent.get("href", "")

            results.append({
                "title":   title_el.get_text(strip=True),
                "link":    link,
                "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
                "domain":  url_el.get_text(strip=True) if url_el else "",
            })

            if len(results) >= max_results:
                break

        return results
    except Exception:
        return []


def search_duckduckgo_html(query: str, max_results: int = 5) -> list:
    """DuckDuckGo HTML scraper (last resort)."""
    try:
        resp = requests.post(
            "https://html.duckduckgo.com/html/",
            data={"q": query},
            headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0"},
            timeout=12
        )
        soup    = BeautifulSoup(resp.text, "html.parser")
        results = []

        for item in soup.select(".result__body"):
            title_el   = item.select_one(".result__a")
            snippet_el = item.select_one(".result__snippet")
            if not title_el:
                continue
            href = title_el.get("href", "")
            uddg = re.search(r"uddg=([^&]+)", href)
            real_url = requests.utils.unquote(uddg.group(1)) if uddg else href
            results.append({
                "title":   title_el.get_text(strip=True),
                "link":    real_url,
                "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
                "domain":  real_url,
            })
            if len(results) >= max_results:
                break
        return results
    except Exception:
        return []


def web_search(query: str, max_results: int = 5) -> list:
    """Try multiple search engines, return first non-empty result."""
    engines = [
        ("DuckDuckGo API", search_duckduckgo_api),
        ("Brave",          search_brave),
        ("DuckDuckGo HTML", search_duckduckgo_html),
    ]
    for name, fn in engines:
        print(f"{C.DIM}  Trying {name}…{C.RESET}", end="\r")
        results = fn(query, max_results)
        if results:
            print(f"{C.DIM}  {name} ✓ ({len(results)} results)          {C.RESET}")
            return results

    print(f"{C.YELLOW}  All search engines returned no results.{C.RESET}")
    return []


# ─────────────────────────────────────────────
#  URL DETECTION & FETCHING
# ─────────────────────────────────────────────
URL_RE = re.compile(
    r"https?://[^\s\)\]\,\"\'<>]+|"
    r"(?<!\w)www\.[^\s\)\]\,\"\'<>]+",
    re.IGNORECASE
)

def extract_urls(text: str) -> list:
    """Extract all URLs from a message."""
    urls = URL_RE.findall(text)
    # Ensure they all have a scheme
    result = []
    for u in urls:
        if not u.startswith("http"):
            u = "https://" + u
        result.append(u)
    return result


def fetch_url_content(url: str) -> dict:
    """Fetch a URL and extract readable text content."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0",
        "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
        "Accept-Language": "en-US,en;q=0.9",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        resp.raise_for_status()
        final_url = resp.url

        soup = BeautifulSoup(resp.text, "html.parser")

        # Remove noise tags
        for tag in soup(["script", "style", "nav", "footer", "header",
                          "aside", "iframe", "noscript", "svg", "form"]):
            tag.decompose()

        # Title
        title = ""
        if soup.title:
            title = soup.title.get_text(strip=True)

        # Meta description
        meta_desc = ""
        meta = soup.find("meta", attrs={"name": re.compile("description", re.I)})
        if meta:
            meta_desc = meta.get("content", "")

        # Main content — prefer article/main, fallback to body
        content_el = (
            soup.find("article") or
            soup.find("main") or
            soup.find(id=re.compile("content|main|post|article", re.I)) or
            soup.find(class_=re.compile("content|main|post|article|entry", re.I)) or
            soup.body
        )

        raw_text = content_el.get_text(separator="\n", strip=True) if content_el else ""

        # Clean up excessive blank lines
        lines = [l.strip() for l in raw_text.splitlines() if l.strip()]
        clean_text = "\n".join(lines)

        # Limit to ~4000 chars to stay within token budget
        if len(clean_text) > 4000:
            clean_text = clean_text[:4000] + "\n\n[...content truncated...]"

        return {
            "url":         final_url,
            "title":       title,
            "description": meta_desc,
            "content":     clean_text,
            "ok":          True,
        }

    except requests.exceptions.Timeout:
        return {"url": url, "ok": False, "error": "Request timed out"}
    except requests.exceptions.HTTPError as e:
        return {"url": url, "ok": False, "error": f"HTTP {e.response.status_code}"}
    except Exception as e:
        return {"url": url, "ok": False, "error": str(e)}


def answer_with_url_content(user_msg: str, url_data: list, history: list) -> str:
    """Answer using fetched webpage content."""
    context = ""
    for d in url_data:
        if d["ok"]:
            context += f"=== URL: {d['url']} ===\n"
            context += f"Title: {d['title']}\n"
            if d["description"]:
                context += f"Description: {d['description']}\n"
            context += f"\nContent:\n{d['content']}\n\n"
        else:
            context += f"=== URL: {d['url']} ===\nFailed to fetch: {d['error']}\n\n"

    system = (
        "You are an advanced AI assistant that can read and analyze web pages. "
        "You have been given the content of one or more URLs. "
        "Answer the user's request based on the actual page content. "
        "Be thorough and specific. Mention the page title and key details."
    )

    messages = [{"role": "system", "content": system}]
    for m in history[-6:]:
        messages.append({"role": m["role"], "content": m["content"]})
    messages.append({
        "role": "user",
        "content": f"Webpage content:\n\n{context}\n\nUser request: {user_msg}"
    })

    return call_openrouter(messages)

# ─────────────────────────────────────────────
#  PUTER LLM CALL  (with auto-fallback + token refresh)
# ─────────────────────────────────────────────
def _try_model(model_id: str, messages: list, stream: bool) -> tuple:
    """Returns (response_text, status) where status is 'ok','rate_limit','auth_fail','error'."""
    headers = {
        "Authorization": f"Bearer {OR_API_KEY}",
        "Content-Type":  "application/json",
    }
    payload = {
        "model":       model_id,
        "messages":    messages,
        "max_tokens":  1024,
        "temperature": 0.7,
        "stream":      stream,
    }

    if stream:
        with requests.post(PUTER_API_URL, headers=headers, json=payload,
                           stream=True, timeout=60) as resp:
            if resp.status_code == 429:
                return None, "rate_limit"
            if resp.status_code == 401:
                return None, "auth_fail"
            resp.raise_for_status()
            full = ""
            for line in resp.iter_lines():
                if not line:
                    continue
                line = line.decode("utf-8")
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                        token = chunk["choices"][0]["delta"].get("content", "")
                        if token:
                            print(token, end="", flush=True)
                            full += token
                    except Exception:
                        pass
            print()
            return full, "ok"
    else:
        resp = requests.post(PUTER_API_URL, headers=headers, json=payload, timeout=60)
        if resp.status_code == 429:
            return None, "rate_limit"
        if resp.status_code == 401:
            return None, "auth_fail"
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"], "ok"


def call_openrouter(messages: list, stream: bool = True) -> str:
    global MODEL, OR_API_KEY

    # Build fallback order: current model first, then others
    model_ids = [m[0] for m in FREE_MODELS]
    order = [MODEL] + [m for m in model_ids if m != MODEL]

    auth_refreshed = False

    for model_id in order:
        label = next((lbl for mid, lbl in FREE_MODELS if mid == model_id), model_id)
        try:
            result, status = _try_model(model_id, messages, stream)

            if status == "auth_fail":
                if not auth_refreshed:
                    # Token may be expired — try clearing it
                    print(f"\r{C.YELLOW}  🔑 Token rejected (401). Try /resetauth to enter a new token.{C.RESET}    ")
                    auth_refreshed = True
                print(f"\n{C.RED}  Auth failed. Run /resetauth and paste a fresh token from puter.com/dashboard{C.RESET}\n")
                return "[Error]: Auth failed"

            if status == "rate_limit":
                short = label.split("(")[0].strip()
                print(f"\r{C.YELLOW}  ⚠ {short} busy, trying next model…{C.RESET}    ", flush=True)
                continue

            if model_id != MODEL:
                print(f"{C.DIM}  (answered by {label.split('(')[0].strip()}){C.RESET}")
            return result

        except requests.exceptions.HTTPError as e:
            code = e.response.status_code
            body = e.response.text[:200]
            print(f"\n{C.RED}  API error {code}: {body[:80]}{C.RESET}\n")
            continue
        except requests.exceptions.ConnectionError:
            print(f"\n{C.RED}  No internet connection.{C.RESET}\n")
            return "[Error]: No internet connection"
        except Exception as e:
            print(f"\n{C.RED}  Unexpected error: {e}{C.RESET}\n")
            return f"[Error]: {e}"

    print(f"\n{C.RED}  All models unavailable. Please wait a moment and try again.{C.RESET}\n")
    return "[Error]: All models unavailable"

# ─────────────────────────────────────────────
#  ANSWER WITH SEARCH CONTEXT
# ─────────────────────────────────────────────
def answer_with_search(query: str, results: list, history: list) -> str:
    sources_block = ""
    for i, r in enumerate(results, 1):
        sources_block += f"[{i}] {r['title']}\n{r['snippet']}\n\n"

    system = (
        "You are an advanced AI assistant with web search capability. "
        "Use the provided web results to answer accurately. "
        "Cite sources as [1], [2] etc. Be concise but thorough."
    )

    messages = [{"role": "system", "content": system}]
    # Add recent history (without timestamps for the API)
    for m in history[-8:]:
        messages.append({"role": m["role"], "content": m["content"]})

    messages.append({
        "role": "user",
        "content": f"Web search results:\n\n{sources_block}\n\nQuestion: {query}"
    })

    return call_openrouter(messages)

# ─────────────────────────────────────────────
#  ANSWER WITHOUT SEARCH
# ─────────────────────────────────────────────
def answer_without_search(query: str, history: list) -> str:
    system = (
        "You are an advanced, helpful AI assistant. "
        "You have memory of this conversation. "
        "Answer clearly and helpfully. If you're uncertain about recent facts, say so."
    )

    messages = [{"role": "system", "content": system}]
    for m in history[-12:]:
        messages.append({"role": m["role"], "content": m["content"]})
    messages.append({"role": "user", "content": query})

    return call_openrouter(messages)

# ─────────────────────────────────────────────
#  UI HELPERS
# ─────────────────────────────────────────────
def print_banner():
    # Find short label for current model
    model_label = next((lbl for mid, lbl in FREE_MODELS if mid == MODEL), MODEL)
    banner = f"""
{C.CYAN}{C.BOLD}
  ╔══════════════════════════════════════════════╗
  ║   🤖  AI Assistant  ·  Smart Search + Memory ║
  ╚══════════════════════════════════════════════╝{C.RESET}
{C.DIM}  Powered by Puter.js · Free & Unlimited · DuckDuckGo{C.RESET}
{C.DIM}  Model: {model_label}{C.RESET}
{C.DIM}  Type  /help  for commands  ·  /model  to switch model  ·  Ctrl+C to exit{C.RESET}
"""
    print(banner)

def print_sources(results: list):
    print(f"\n{C.DIM}{'─'*52}{C.RESET}")
    print(f"{C.YELLOW}{C.BOLD}  📎 Sources{C.RESET}")
    for i, r in enumerate(results, 1):
        print(f"{C.DIM}  [{i}] {C.RESET}{C.BLUE}{r['title'][:60]}{C.RESET}")
        print(f"{C.DIM}      {r['link'][:72]}{C.RESET}")
    print(f"{C.DIM}{'─'*52}{C.RESET}\n")

def print_help():
    print(f"""
{C.CYAN}{C.BOLD}Commands:{C.RESET}
  {C.GREEN}/model{C.RESET}       – list & switch AI model (GPT, Claude, Gemini, and more)
  {C.GREEN}/memory{C.RESET}      – show conversation history summary
  {C.GREEN}/clear{C.RESET}       – clear conversation memory
  {C.GREEN}/search <q>{C.RESET}  – force a web search
  {C.GREEN}/nosearch <q>{C.RESET} – force no search
  {C.GREEN}/resetauth{C.RESET}   – reset Puter session (get a fresh account)
  {C.GREEN}/help{C.RESET}        – show this message
  {C.GREEN}exit / quit{C.RESET}  – exit the assistant

{C.DIM}  Powered by Puter.js – free & unlimited, no API key needed{C.RESET}
""")

def show_model_menu() -> bool:
    """Interactive model picker. Returns True if model was changed."""
    global MODEL
    print(f"\n{C.CYAN}{C.BOLD}  🤖 Available Free Models{C.RESET}")
    print(f"{C.DIM}  {'─'*50}{C.RESET}")
    for i, (model_id, label) in enumerate(FREE_MODELS, 1):
        active = f"  {C.GREEN}▶ {C.RESET}" if model_id == MODEL else "    "
        print(f"{active}{C.YELLOW}{i}{C.RESET}. {label}")
        print(f"     {C.DIM}{model_id}{C.RESET}")
    print(f"\n{C.DIM}  Current: {MODEL}{C.RESET}")
    print(f"{C.DIM}  Enter a number to switch, or press Enter to cancel.{C.RESET}")

    try:
        choice = input(f"\n  Select model (1-{len(FREE_MODELS)}): ").strip()
    except (KeyboardInterrupt, EOFError):
        print()
        return False

    if not choice:
        return False

    try:
        idx = int(choice) - 1
        if 0 <= idx < len(FREE_MODELS):
            MODEL = FREE_MODELS[idx][0]
            label = FREE_MODELS[idx][1]
            cfg = load_config()
            cfg["model"] = MODEL
            save_config(cfg)
            print(f"\n{C.GREEN}  ✓ Switched to: {label}{C.RESET}")
            print(f"{C.DIM}  Model ID: {MODEL}{C.RESET}\n")
            return True
        else:
            print(f"{C.RED}  Invalid selection.{C.RESET}\n")
    except ValueError:
        print(f"{C.RED}  Please enter a number.{C.RESET}\n")
    return False

def show_memory_summary(history: list):
    if not history:
        print(f"{C.DIM}  No conversation history yet.{C.RESET}\n")
        return
    print(f"\n{C.CYAN}{C.BOLD}  🧠 Memory ({len(history)} messages){C.RESET}")
    for m in history[-10:]:
        role  = "You" if m["role"] == "user" else "AI"
        color = C.GREEN if m["role"] == "user" else C.MAGENTA
        ts    = m.get("timestamp", "")[:16].replace("T", " ")
        snippet = m["content"][:80].replace("\n", " ")
        print(f"  {color}{role}{C.RESET} {C.DIM}[{ts}]{C.RESET}  {snippet}…")
    print()

# ─────────────────────────────────────────────
#  MAIN LOOP
# ─────────────────────────────────────────────
def main():
    global OR_API_KEY, MODEL
    # Load saved model preference
    cfg = load_config()
    saved_model = cfg.get("model", DEFAULT_MODEL)
    if any(mid == saved_model for mid, _ in FREE_MODELS):
        MODEL = saved_model

    print_banner()

    print(f"{C.DIM}  Connecting to Puter…{C.RESET}", end="\r")
    OR_API_KEY = _get_puter_token()
    if OR_API_KEY:
        print(f"{C.GREEN}  ✓ Puter token loaded — free & unlimited!         {C.RESET}\n")
    else:
        print(f"{C.RED}  No token found. Please restart to set up.{C.RESET}\n")

    history = load_memory()
    if history:
        print(f"{C.DIM}  ↩  Loaded {len(history)} messages from previous session.{C.RESET}\n")

    while True:
        try:
            user_input = input(f"{C.GREEN}{C.BOLD}  You › {C.RESET}").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{C.DIM}  Goodbye! Memory saved.{C.RESET}\n")
            save_memory(history)
            break

        if not user_input:
            continue

        # ── Commands ──────────────────────────────
        if user_input.lower() in ("exit", "quit", "bye"):
            save_memory(history)
            print(f"\n{C.DIM}  Goodbye! Memory saved.{C.RESET}\n")
            break

        if user_input.lower() == "/help":
            print_help()
            continue

        if user_input.lower() == "/model":
            show_model_menu()
            continue

        if user_input.lower() == "/memory":
            show_memory_summary(history)
            continue

        if user_input.lower() == "/clear":
            history.clear()
            save_memory(history)
            print(f"{C.YELLOW}  Memory cleared.{C.RESET}\n")
            continue

        if user_input.lower() == "/resetauth":
            cfg = load_config()
            cfg.pop("puter_token", None)
            save_config(cfg)
            print(f"{C.YELLOW}  Token cleared. Getting a new one…{C.RESET}\n")
            OR_API_KEY = _get_puter_token()
            if OR_API_KEY:
                print(f"{C.GREEN}  ✓ New token saved and ready.{C.RESET}\n")
            continue

        # Force search
        force_search   = user_input.lower().startswith("/search ")
        force_nosearch = user_input.lower().startswith("/nosearch ")

        if force_search:
            query = user_input[8:].strip()
        elif force_nosearch:
            query = user_input[10:].strip()
        else:
            query = user_input

        # ── Detect URLs in message ─────────────────
        urls = extract_urls(query) if not force_nosearch else []

        add_to_memory(history, "user", query)

        # ── URL mode: fetch & analyze pages ───────
        if urls:
            print(f"{C.CYAN}  🔗 Fetching {len(urls)} URL(s)…{C.RESET}")
            url_data = []
            for u in urls:
                print(f"{C.DIM}  ↳ {u[:70]}{C.RESET}", end="\r")
                data = fetch_url_content(u)
                if data["ok"]:
                    print(f"{C.GREEN}  ✓ {data['title'][:60] or u[:60]}          {C.RESET}")
                else:
                    print(f"{C.RED}  ✗ {u[:60]} — {data['error']}          {C.RESET}")
                url_data.append(data)

            print(f"\n{C.MAGENTA}{C.BOLD}  AI › {C.RESET}", end="", flush=True)
            answer = answer_with_url_content(query, url_data, history)
            # Show fetched URLs as sources
            print(f"\n{C.DIM}{'─'*52}{C.RESET}")
            print(f"{C.YELLOW}{C.BOLD}  🔗 Fetched Pages{C.RESET}")
            for d in url_data:
                status = f"{C.GREEN}✓{C.RESET}" if d["ok"] else f"{C.RED}✗{C.RESET}"
                title  = d.get("title", "")[:55] or d["url"][:55]
                print(f"  {status} {C.BLUE}{title}{C.RESET}")
                print(f"{C.DIM}     {d['url'][:72]}{C.RESET}")
            print(f"{C.DIM}{'─'*52}{C.RESET}\n")

        # ── Search / chat mode ─────────────────────
        else:
            # ── Decide search ─────────────────────────
            do_search = False
            if force_search:
                do_search = True
            elif force_nosearch:
                do_search = False
            else:
                # Quick regex pre-check before calling LLM
                if SEARCH_TRIGGER_RE.search(query):
                    print(f"{C.DIM}  ⚡ Checking if search needed…{C.RESET}", end="\r")
                    do_search = needs_search(query, history)
                else:
                    do_search = False

            # ── Execute ───────────────────────────────
            search_results: list = []

            if do_search:
                print(f"{C.CYAN}  🌐 Searching…{C.RESET}", flush=True)
                search_results = web_search(query, max_results=5)

                if search_results:
                    print(f"{C.DIM}  Found {len(search_results)} results  →  generating answer…{C.RESET}\n")
                    print(f"{C.MAGENTA}{C.BOLD}  AI › {C.RESET}", end="", flush=True)
                    answer = answer_with_search(query, search_results, history)
                    print_sources(search_results)
                else:
                    print(f"{C.YELLOW}  No search results. Answering from knowledge…{C.RESET}\n")
                    print(f"{C.MAGENTA}{C.BOLD}  AI › {C.RESET}", end="", flush=True)
                    answer = answer_without_search(query, history)
                    print()
            else:
                print(f"{C.MAGENTA}{C.BOLD}  AI › {C.RESET}", end="", flush=True)
                answer = answer_without_search(query, history)
                print()

        add_to_memory(history, "assistant", answer)
        save_memory(history)

if __name__ == "__main__":
    main()
