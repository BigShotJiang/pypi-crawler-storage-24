"""
MKDEVAI  v2.3.0  —  Powered by MKDEVAPI
"""

import sys
import os
import datetime

from .constants import C, FREE_MODELS, get_puter_token, PUTER_API_URL
from .security  import validate_api_key_format
from .db        import get_user, record_usage
from .auth      import mkai as _auth, mkaadmin

from . import beast

VERSION = "2.3.0"

# Admin tokens — silent, never shown in UI
_ADMIN_TOKENS = frozenset({"mkaadmin", "mkadmin", "mkai-admin", "__mkai_admin__"})


def _show_startup_banner():
    """Clean login screen — no admin hints, no entry point info."""
    try:
        w = min(os.get_terminal_size().columns, 100)
    except Exception:
        w = 80
    inner = w - 4
    now   = datetime.datetime.utcnow()
    print()
    print(C.CYAN + C.BOLD + "  ╔" + "═"*inner + "╗" + C.RESET)
    print(C.CYAN + C.BOLD + "  ║" + C.RESET
          + C.BOLD + C.YELLOW
          + f"  ⚡  MK-AI  v{VERSION}  ·  Powered by MKDEVAPI  ".center(inner)
          + C.RESET + C.CYAN + C.BOLD + "║" + C.RESET)
    print(C.CYAN + C.BOLD + "  ╠" + "═"*inner + "╣" + C.RESET)
    print(C.CYAN + C.BOLD + "  ║" + C.RESET
          + C.DIM
          + f"  Advanced AI Terminal  ·  {now.strftime('%Y-%m-%d  %H:%M')} UTC  ".center(inner)
          + C.RESET + C.CYAN + C.BOLD + "║" + C.RESET)
    print(C.CYAN + C.BOLD + "  ╚" + "═"*inner + "╝" + C.RESET)
    print()


def _show_session_banner(info, model_label):
    """Post-login dashboard banner."""
    try:
        w = min(os.get_terminal_size().columns, 100)
    except Exception:
        w = 80
    inner       = w - 4
    daily_used  = info.get("daily_used", 0)
    daily_limit = info.get("daily_limit", 0)
    lim_str     = "Unlimited" if daily_limit == 0 else f"{daily_limit:,}"
    pct_str     = "" if daily_limit == 0 else f"  ({daily_used/daily_limit*100:.1f}%)"

    def row(text, color=C.RESET):
        print(C.CYAN + C.BOLD + "  ║" + C.RESET
              + color + ("  " + text).ljust(inner) + C.RESET
              + C.CYAN + C.BOLD + "║" + C.RESET)

    print()
    print(C.CYAN + C.BOLD + "  ╔" + "═"*inner + "╗" + C.RESET)
    print(C.CYAN + C.BOLD + "  ║" + C.RESET
          + C.BOLD + C.YELLOW
          + f"  ⚡  MK-AI  v{VERSION}  ·  Powered by MKDEVAPI  ".center(inner)
          + C.RESET + C.CYAN + C.BOLD + "║" + C.RESET)
    print(C.CYAN + C.BOLD + "  ╠" + "═"*inner + "╣" + C.RESET)
    row(f"  User   : {info['name']}      Model : {model_label}")
    row(f"  Tokens : {daily_used:,} / {lim_str}{pct_str}"
        f"      {datetime.datetime.utcnow().strftime('%Y-%m-%d  %H:%M')} UTC")
    print(C.CYAN + C.BOLD + "  ╚" + "═"*inner + "╝" + C.RESET)
    print()


def main():
    _show_startup_banner()

    try:
        api_key = input(f"  {C.YELLOW}API Key:{C.RESET} ").strip()
    except (KeyboardInterrupt, EOFError):
        print(); sys.exit(0)

    if not api_key:
        print(f"\n{C.RED}  ✗ No API key entered.{C.RESET}\n")
        sys.exit(1)

    # Silent admin route — no hint in UI
    if api_key in _ADMIN_TOKENS:
        mkaadmin()
        return

    # Authenticate
    try:
        info = _auth(api_key, caller_id="cli")
    except ValueError as e:
        print(f"\n{C.RED}  ✗ {e}{C.RESET}\n")
        sys.exit(1)

    print(f"\n{C.GREEN}  ✓ Welcome, {info['name']}!{C.RESET}")

    allowed       = info["model_access"]
    default_model = "grok-4-1-fast"
    start_model   = default_model if default_model in allowed else allowed[0]
    model_label   = next((lbl for mid, lbl in FREE_MODELS if mid == start_model), start_model)

    _show_session_banner(info, model_label)

    # Inject into beast
    beast.OR_API_KEY    = get_puter_token()
    beast.PUTER_API_URL = PUTER_API_URL
    beast.MODEL         = start_model
    beast.FREE_MODELS   = [(mid, lbl) for mid, lbl in FREE_MODELS if mid in allowed]

    key_prefix        = api_key[:14].replace("-", "_")
    home              = os.path.expanduser("~")
    beast.MEMORY_FILE = os.path.join(home, f".mkai_memory_{key_prefix}.json")
    beast.CONFIG_FILE = os.path.join(home, f".mkai_config_{key_prefix}.json")

    cfg         = beast.load_config()
    saved_model = cfg.get("model", beast.MODEL)
    if any(mid == saved_model for mid, _ in beast.FREE_MODELS):
        beast.MODEL = saved_model

    history = beast.load_memory()
    if history:
        print(f"{C.DIM}  ↩  Loaded {len(history)} messages from previous session.{C.RESET}\n")

    # ── Chat loop ─────────────────────────────────────────────────────────────
    while True:
        try:
            user_input = input(f"{C.GREEN}{C.BOLD}  Me › {C.RESET}").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{C.DIM}  Goodbye! Memory saved.{C.RESET}\n")
            beast.save_memory(history)
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit", "bye"):
            beast.save_memory(history)
            print(f"\n{C.DIM}  Goodbye! Memory saved.{C.RESET}\n")
            break

        if user_input.lower() == "/help":
            beast.print_help()
            continue

        if user_input.lower() == "/model":
            beast.show_model_menu()
            continue

        if user_input.lower() == "/memory":
            beast.show_memory_summary(history)
            continue

        if user_input.lower() == "/clear":
            history.clear()
            beast.save_memory(history)
            print(f"{C.YELLOW}  Memory cleared.{C.RESET}\n")
            continue

        if user_input.lower() == "/resetauth":
            cfg2 = beast.load_config()
            cfg2.pop("puter_token", None)
            beast.save_config(cfg2)
            beast.OR_API_KEY = get_puter_token()
            if beast.OR_API_KEY:
                print(f"{C.GREEN}  ✓ Token refreshed.{C.RESET}\n")
            continue

        # Re-check daily limit before each message
        user_db = get_user(api_key)
        if user_db:
            dl = user_db.get("daily_limit", -1)
            du = user_db.get("daily_usage", {}).get("tokens", 0)
            if dl != -1 and dl > 0 and du >= dl:
                print(f"\n{C.RED}  ✗ Daily token limit reached ({du:,}/{dl:,}). "
                      f"Limit resets at UTC midnight.{C.RESET}\n")
                break

        force_search   = user_input.lower().startswith("/search ")
        force_nosearch = user_input.lower().startswith("/nosearch ")

        if force_search:
            query = user_input[8:].strip()
        elif force_nosearch:
            query = user_input[10:].strip()
        else:
            query = user_input

        urls = beast.extract_urls(query) if not force_nosearch else []
        beast.add_to_memory(history, "user", query)

        # URL mode
        if urls:
            print(f"{C.CYAN}  🔗 Fetching {len(urls)} URL(s)…{C.RESET}")
            url_data = []
            for u in urls:
                print(f"{C.DIM}  ↳ {u[:70]}{C.RESET}", end="\r")
                data = beast.fetch_url_content(u)
                if data["ok"]:
                    print(f"  {C.DIM}  ↳ {u[:65]}{C.RESET}  "
                          f"{C.GREEN}✓{C.RESET} {C.WHITE}{data['title'][:55]}{C.RESET}          ")
                else:
                    print(f"  {C.DIM}  ↳ {u[:65]}{C.RESET}  "
                          f"{C.RED}✗{C.RESET} {data['error']}          ")
                url_data.append(data)

            print(f"\n{C.MAGENTA}{C.BOLD}  AI › {C.RESET}", end="", flush=True)
            answer = beast.answer_with_url_content(query, url_data, history)

            try:
                w = min(60, os.get_terminal_size().columns)
            except Exception:
                w = 60
            line = "─" * w
            print(f"\n{C.DIM}  {line}{C.RESET}")
            print(f"{C.DIM}  🔗 Fetched Pages{C.RESET}")
            for d in url_data:
                icon  = f"{C.GREEN}✓{C.RESET}" if d["ok"] else f"{C.RED}✗{C.RESET}"
                title = d.get("title", "")[:52] or d["url"][:52]
                print(f"  {icon} {C.WHITE}{title}{C.RESET}")
                print(f"     {C.DIM}{d['url'][:68].lower()}{C.RESET}")
            print(f"{C.DIM}  {line}{C.RESET}\n")

        # Search / chat mode
        else:
            do_search = False
            if force_search:
                do_search = True
            elif not force_nosearch:
                if beast.SEARCH_TRIGGER_RE.search(query):
                    print(f"{C.DIM}  ⚡ Checking if search needed…{C.RESET}", end="\r")
                    do_search = beast.needs_search(query, history)

            search_results = []
            if do_search:
                print(f"{C.CYAN}  🌐 Searching…{C.RESET}", flush=True)
                search_results = beast.web_search(query, max_results=5)

                if search_results:
                    print(f"{C.DIM}  Found {len(search_results)} results → generating answer…{C.RESET}\n")
                    print(f"{C.MAGENTA}{C.BOLD}  AI › {C.RESET}", end="", flush=True)
                    answer = beast.answer_with_search(query, search_results, history)
                    beast.print_sources(search_results)
                else:
                    print(f"{C.YELLOW}  No search results. Answering from knowledge…{C.RESET}\n")
                    print(f"{C.MAGENTA}{C.BOLD}  AI › {C.RESET}", end="", flush=True)
                    answer = beast.answer_without_search(query, history)
                    print()
            else:
                print(f"{C.MAGENTA}{C.BOLD}  AI › {C.RESET}", end="", flush=True)
                answer = beast.answer_without_search(query, history)
                print()

        beast.add_to_memory(history, "assistant", answer)
        beast.save_memory(history)


if __name__ == "__main__":
    main()
