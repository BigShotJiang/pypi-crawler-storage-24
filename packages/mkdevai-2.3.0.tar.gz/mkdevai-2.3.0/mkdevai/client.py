"""
MKDEVAI  ·  Core Client  v2.3.0
Powered by MKDEVAPI

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  WITH API KEY  (full access, all models, high limits)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    import mkdevai

    # Create your AI bot
    bot = mkdevai.MKAI(api_key="mk-aB3xZ9kL2p-dev-q7-ai")

    # Chat
    reply = bot.chat("Hello! How are you?")
    print(reply)

    # Change model
    bot.set_model("gpt-4o-mini")

    # See all available models
    print(bot.models)

    # See token usage for this session
    print(bot.usage())

    # Clear conversation memory
    bot.clear_history()

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FREE TIER  (no key needed, 3 models, 10 req/hour)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    import mkdevai

    # Easiest — one-liner chat
    reply = mkdevai.free.chat("What is Python?")
    print(reply)

    # Choose a model
    reply = mkdevai.free.gpt4o_mini.chat("Hello!")
    reply = mkdevai.free.gemini.chat("Hello!")
    reply = mkdevai.free.gpt4_nano.chat("Hello!")

    # Or use the full class
    bot = mkdevai.MKAIFree()
    print(bot.chat("Tell me a joke"))
    print(bot.chat("Another one?"))   # remembers context!
"""

from __future__ import annotations

import re
import json
import base64
import datetime
import requests
from pathlib import Path
from typing import Optional, List, Dict

from .constants import (
    C, FREE_MODELS, MODEL_PRICES, PUTER_API_URL, get_puter_token,
    FREE_TIER_MODELS, FREE_TIER_MODEL_IDS,
    FREE_TIER_RATE_LIMIT_CALLS, FREE_TIER_RATE_LIMIT_WINDOW,
    FREE_TIER_MAX_TOKENS,
)
from .security import (
    validate_api_key_format, sanitize_string, check_rate_limit,
    rate_limit_remaining, describe_key_format,
)
from .search import web_search
from .db import authenticate_user, record_usage, get_user

# ── Internal ───────────────────────────────────────────────────────────────────
_SEARCH_RE = re.compile(
    r"\b(today|tonight|this week|right now|currently|latest|recent|live|"
    r"news|headline|update|price|stock|weather|score|"
    r"who is|who are|what is|what are|where is|when is|when did|when will|"
    r"20[2-9]\d|announce|launch|release|search|find|look up|breaking)\b",
    re.IGNORECASE,
)

ALL_MODEL_IDS = [m[0] for m in FREE_MODELS]

# Friendly model name lookup
_MODEL_LABELS: Dict[str, str] = {mid: lbl.strip() for mid, lbl in FREE_MODELS}


def _friendly_key_error(key: str) -> str:
    """Return a human-readable error for a bad key."""
    if not isinstance(key, str) or not key:
        return (
            "❌  No API key provided.\n\n"
            "  How to fix:\n"
            "  1. Contact your admin to get an API key.\n"
            f"  2. Keys look like this: mk-aB3xZ9kL2p-dev-q7-ai\n"
            "  3. Then use:  bot = mkdevai.MKAI(api_key=\"your-key-here\")"
        )
    if not key.startswith("mk-"):
        return (
            f"❌  Your key doesn't start with 'mk-'.\n\n"
            f"  You entered:  {key[:30]}{'...' if len(key)>30 else ''}\n\n"
            f"  Correct format:\n"
            f"  {describe_key_format()}\n\n"
            f"  Contact your admin if you don't have a key."
        )
    if not validate_api_key_format(key):
        return (
            f"❌  Your key has the wrong format.\n\n"
            f"  You entered:  {key[:40]}{'...' if len(key)>40 else ''}\n\n"
            f"  Expected format:\n"
            f"  {describe_key_format()}\n\n"
            f"  Make sure you copied the full key without extra spaces.\n"
            f"  Contact your admin if you need a new key."
        )
    return (
        f"❌  This API key is not recognised.\n\n"
        f"  Key prefix:  {key[:20]}...\n\n"
        f"  Possible reasons:\n"
        f"  • The key was typed/copied incorrectly\n"
        f"  • The key has been revoked by an admin\n"
        f"  • The key doesn't exist in the system\n\n"
        f"  Contact your admin to get a valid key."
    )


# ══════════════════════════════════════════════════════════════════════════════
#  FULL-ACCESS CLIENT  (requires API key)
# ══════════════════════════════════════════════════════════════════════════════

class MKAI:
    """
    MK-AI with full access.  Requires an API key from your admin.

    ┌─────────────────────────────────────────────────────┐
    │  Quick start (copy & paste this):                   │
    │                                                     │
    │    import mkdevai                                   │
    │                                                     │
    │    bot = mkdevai.MKAI(                              │
    │        api_key = "mk-aB3xZ9kL2p-dev-q7-ai"         │
    │    )                                                │
    │    print(bot.chat("Hello!"))                        │
    └─────────────────────────────────────────────────────┘

    Parameters
    ----------
    api_key : str
        Your API key.  Format: mk-XXXXXXXXXX-dev-XX-ai
    model : str, optional
        Which AI model to use.  Default: gpt-4o-mini
        See bot.models for the full list.
    verbose : bool, optional
        Print token usage after every reply.  Default: False
    stream : bool, optional
        Stream the reply word-by-word.  Default: True

    Raises
    ------
    ValueError
        If the API key is missing, wrong format, or not in the system.
    """

    def __init__(
        self,
        api_key: str,
        model:   Optional[str] = None,
        verbose: bool = False,
        stream:  bool = True,
    ):
        # ── 1. Format validation ───────────────────────────────────────────
        if not api_key or not isinstance(api_key, str):
            raise ValueError(_friendly_key_error(""))

        api_key = api_key.strip()

        if not validate_api_key_format(api_key):
            raise ValueError(_friendly_key_error(api_key))

        # ── 2. Database lookup ─────────────────────────────────────────────
        user = authenticate_user(api_key)
        if not user:
            raise ValueError(_friendly_key_error(api_key))

        # ── 3. Account status checks ───────────────────────────────────────
        if user.get("revoked"):
            raise ValueError(
                "🚫  This API key has been revoked.\n\n"
                "  Your access has been permanently disabled.\n"
                "  Contact your admin to get a new key."
            )
        if user.get("banned"):
            raise ValueError(
                "🚫  This account has been suspended.\n\n"
                "  Contact your admin for more information."
            )

        # ── 4. Expiry check ────────────────────────────────────────────────
        expires_on = user.get("expires_on", "never")
        if expires_on and expires_on != "never":
            try:
                import datetime as _dt
                exp = _dt.datetime.strptime(expires_on, "%Y-%m-%d")
                if exp < _dt.datetime.utcnow():
                    raise ValueError(
                        f"⏰  This API key expired on {expires_on}.\n\n"
                        f"  Contact your admin to renew your access."
                    )
            except ValueError as e:
                if "expired" in str(e):
                    raise

        # ── 5. Daily token limit check ─────────────────────────────────────
        daily_limit = user.get("daily_limit", -1)
        daily_used  = user.get("daily_usage", {}).get("tokens", 0)

        if daily_limit == 0:
            raise ValueError(
                "⛔  Your token allowance is set to 0.\n\n"
                "  No requests are permitted with this key.\n"
                "  Contact your admin to increase your limit."
            )
        if daily_limit > 0 and daily_used >= daily_limit:
            raise ValueError(
                f"📊  Daily token limit reached.\n\n"
                f"  Used today:  {daily_used:,} tokens\n"
                f"  Your limit:  {daily_limit:,} tokens\n\n"
                f"  Your limit resets at UTC midnight.\n"
                f"  Contact your admin to increase your limit."
            )

        # ── Store state ────────────────────────────────────────────────────
        self._api_key      = api_key
        self._user         = user
        self.verbose       = verbose
        self.stream        = stream
        self.history: List[Dict] = []
        self._model_access = user.get("model_access", ALL_MODEL_IDS)

        # Model selection
        if model and model in self._model_access:
            self.model = model
        elif "gpt-4o-mini" in self._model_access:
            self.model = "gpt-4o-mini"
        else:
            self.model = self._model_access[0] if self._model_access else "gpt-4o-mini"

        # Session counters
        self._session_prompt_tokens     = 0
        self._session_completion_tokens = 0
        self._session_requests          = 0

    # ── Public properties ──────────────────────────────────────────────────────

    @property
    def models(self) -> List[str]:
        """
        List of AI models available to you.

        Example
        -------
        >>> bot.models
        ['gpt-4o-mini', 'gpt-4.1-nano', 'gemini-2.5-flash-lite', ...]
        """
        return list(self._model_access)

    @property
    def model_names(self) -> Dict[str, str]:
        """
        Dict of  model_id → friendly_name  for all your models.

        Example
        -------
        >>> bot.model_names
        {'gpt-4o-mini': 'GPT-4o Mini (OpenAI)', ...}
        """
        return {mid: _MODEL_LABELS.get(mid, mid) for mid in self._model_access}

    @property
    def account(self) -> Dict:
        """
        Your account info and today's usage at a glance.

        Example
        -------
        >>> bot.account
        {'name': 'Alice', 'model': 'gpt-4o-mini', 'used_today': 1234, ...}
        """
        user = get_user(self._api_key) or self._user
        dl   = user.get("daily_limit", -1)
        du   = user.get("daily_usage", {}).get("tokens", 0)
        return {
            "name":        user.get("name", "?"),
            "model":       self.model,
            "used_today":  du,
            "daily_limit": "Unlimited" if dl in (-1, 0) else dl,
            "expires_on":  user.get("expires_on", "never"),
            "powered_by":  "MKDEVAPI",
        }

    # ── Model management ───────────────────────────────────────────────────────

    def set_model(self, model_id: str) -> None:
        """
        Switch to a different AI model.

        Parameters
        ----------
        model_id : str
            The model ID.  Use bot.models to see what's available.

        Raises
        ------
        ValueError
            If the model is not on your plan.

        Example
        -------
        >>> bot.set_model("gemini-2.5-flash-lite")
        """
        if model_id not in self._model_access:
            available = "\n  ".join(
                f"• {mid}  →  {_MODEL_LABELS.get(mid, mid)}"
                for mid in self._model_access
            )
            raise ValueError(
                f"❌  Model '{model_id}' is not on your plan.\n\n"
                f"  Your available models:\n  {available}"
            )
        self.model = model_id

    def clear_history(self) -> None:
        """
        Erase conversation memory.
        The bot will forget everything said so far.

        Example
        -------
        >>> bot.clear_history()
        """
        self.history = []

    # ── Usage ──────────────────────────────────────────────────────────────────

    def usage(self) -> Dict:
        """
        Token usage for this session.

        Returns
        -------
        dict
            prompt_tokens, completion_tokens, total_tokens,
            requests, estimated_cost_usd, model, powered_by

        Example
        -------
        >>> info = bot.usage()
        >>> print(f"Used {info['usage']['total_tokens']} tokens this session")
        """
        total = self._session_prompt_tokens + self._session_completion_tokens
        price = MODEL_PRICES.get(self.model, {"input": 0.0, "output": 0.0})
        cost  = (
            self._session_prompt_tokens * price["input"] +
            self._session_completion_tokens * price["output"]
        ) / 1_000_000
        return {
            "usage": {
                "prompt_tokens":     self._session_prompt_tokens,
                "completion_tokens": self._session_completion_tokens,
                "total_tokens":      total,
            },
            "requests":           self._session_requests,
            "estimated_cost_usd": round(cost, 8),
            "model":              self.model,
            "powered_by":         "MKDEVAPI",
        }

    # ── Internal call machinery ────────────────────────────────────────────────

    def _check_daily_limit(self) -> None:
        """Re-read the DB and raise if over the limit."""
        user = get_user(self._api_key)
        if not user:
            return
        dl = user.get("daily_limit", -1)
        du = user.get("daily_usage", {}).get("tokens", 0)
        if dl == 0:
            raise RuntimeError(
                "⛔  Your token allowance is 0. Contact your admin."
            )
        if dl > 0 and du >= dl:
            raise RuntimeError(
                f"📊  Daily limit reached ({du:,}/{dl:,} tokens). "
                f"Resets at UTC midnight."
            )

    def _call(self, messages: List[Dict]) -> str:
        """Send messages to the AI. Tries preferred model, falls back on 429."""
        token   = get_puter_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type":  "application/json",
        }
        # Try preferred model first, then fallbacks
        order = [self.model] + [m for m in self._model_access if m != self.model]

        last_error = "No response received."
        for mid in order:
            payload = {
                "model":       mid,
                "messages":    messages,
                "max_tokens":  1024,
                "temperature": 0.7,
                "stream":      self.stream,
            }
            try:
                if self.stream:
                    text, pt, ct = self._stream_call(headers, payload)
                else:
                    text, pt, ct = self._sync_call(headers, payload)

                # Counters
                self._session_prompt_tokens     += pt
                self._session_completion_tokens += ct
                self._session_requests          += 1

                # Persist to DB
                try:
                    record_usage(self._api_key, pt, ct, mid)
                except Exception:
                    pass

                # Optional verbose output
                if self.verbose:
                    self._print_usage(mid, pt, ct)

                return text

            except requests.exceptions.ConnectionError:
                raise RuntimeError(
                    "🌐  No internet connection.\n"
                    "  Please check your network and try again."
                )
            except requests.exceptions.HTTPError as exc:
                if exc.response is not None and exc.response.status_code == 429:
                    last_error = f"Model '{mid}' is busy. Trying next…"
                    continue
                last_error = "Server error. Please try again."
                break
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as exc:
                last_error = str(exc)
                continue

        raise RuntimeError(
            f"❌  Could not get a response.\n\n"
            f"  Reason: {last_error}\n"
            f"  Try again in a moment, or switch models with bot.set_model(...)."
        )

    def _stream_call(self, headers, payload):
        """Send a streaming request; print tokens as they arrive."""
        full = ""
        with requests.post(
            PUTER_API_URL, headers=headers, json=payload,
            stream=True, timeout=90,
        ) as resp:
            if resp.status_code == 429:
                raise requests.exceptions.HTTPError(response=resp)
            resp.raise_for_status()
            for raw_line in resp.iter_lines():
                if not raw_line:
                    continue
                line = raw_line.decode("utf-8")
                if not line.startswith("data: "):
                    continue
                data = line[6:]
                if data == "[DONE]":
                    break
                try:
                    chunk = json.loads(data)["choices"][0]["delta"].get("content", "")
                    if chunk:
                        print(chunk, end="", flush=True)
                        full += chunk
                except Exception:
                    pass
            print()   # newline after streamed output

        msgs = payload.get("messages", [])
        pt   = max(1, sum(len(str(m.get("content", ""))) for m in msgs) // 4)
        ct   = max(1, len(full) // 4)
        return full, pt, ct

    def _sync_call(self, headers, payload):
        """Send a non-streaming request."""
        resp = requests.post(PUTER_API_URL, headers=headers, json=payload, timeout=90)
        if resp.status_code == 429:
            raise requests.exceptions.HTTPError(response=resp)
        resp.raise_for_status()
        data = resp.json()
        text = data["choices"][0]["message"]["content"]
        u    = data.get("usage", {})
        msgs = payload.get("messages", [])
        pt   = u.get("prompt_tokens")    or max(1, sum(len(str(m.get("content", ""))) for m in msgs) // 4)
        ct   = u.get("completion_tokens") or max(1, len(text) // 4)
        return text, int(pt), int(ct)

    def _print_usage(self, model_id: str, pt: int, ct: int) -> None:
        total = pt + ct
        price = MODEL_PRICES.get(model_id, {"input": 0.0, "output": 0.0})
        cost  = (pt * price["input"] + ct * price["output"]) / 1_000_000
        print(
            f"\n{C.DIM}"
            f"  ┌── Token Usage ────────────────────────────────┐\n"
            f"  │  Prompt    : {pt:>10,} tokens               │\n"
            f"  │  Reply     : {ct:>10,} tokens               │\n"
            f"  │  Total     : {total:>10,} tokens               │\n"
            f"  │  Model     : {model_id[:38]:<38} │\n"
            f"  │  Est. cost : ${cost:.8f}                   │\n"
            f"  └───────────────────────────────────────────────┘"
            f"{C.RESET}\n"
        )

    # ── Public API ─────────────────────────────────────────────────────────────

    def chat(
        self,
        message:     str,
        auto_search: bool = True,
        system:      Optional[str] = None,
    ) -> str:
        """
        Send a message and get a reply.

        Automatically searches the web when your question needs live data
        (news, prices, weather, etc.).

        Parameters
        ----------
        message : str
            Your message or question.
        auto_search : bool, optional
            Automatically search the web for current info.  Default: True
        system : str, optional
            Custom system prompt to change the AI's behaviour.

        Returns
        -------
        str
            The AI's reply.

        Raises
        ------
        RuntimeError
            If the daily token limit is reached or the AI can't respond.

        Example
        -------
        >>> bot = mkdevai.MKAI(api_key="mk-aB3xZ9kL2p-dev-q7-ai")
        >>> print(bot.chat("What is machine learning?"))
        >>> print(bot.chat("Give me an example."))   # remembers context!
        """
        self._check_daily_limit()

        message = sanitize_string(str(message), 8192)
        if not message:
            raise ValueError("Message cannot be empty.")

        # Optional web search for live info
        search_results = []
        if auto_search and _SEARCH_RE.search(message):
            try:
                search_results = web_search(message, max_results=5)
            except Exception:
                pass   # web search failing should not block chat

        # Build system prompt
        sys_prompt = system or (
            "You are MK-AI, an advanced AI assistant powered by MKDEVAPI. "
            "Be helpful, accurate, and concise. "
            "You remember the full conversation context."
        )
        if search_results:
            sources = "\n".join(
                f"[{i}] {r['title']}\n{r['snippet']}"
                for i, r in enumerate(search_results, 1)
            )
            sys_prompt += (
                f"\n\nCurrent web search results (use these for up-to-date info):\n"
                f"{sources}\n"
                f"Cite sources as [1], [2] etc. when using this data."
            )

        # Build message list (system + last 16 turns + current message)
        messages = [{"role": "system", "content": sys_prompt}]
        for m in self.history[-16:]:
            messages.append({"role": m["role"], "content": m["content"]})
        messages.append({"role": "user", "content": message})

        reply = self._call(messages)

        # Store in history
        self.history.append({"role": "user",      "content": message})
        self.history.append({"role": "assistant",  "content": reply})

        return reply

    def ask(self, question: str) -> str:
        """
        Alias for chat() — one-shot question with no memory.
        Clears history before and after.

        Example
        -------
        >>> answer = bot.ask("What is 2 + 2?")
        """
        self.clear_history()
        reply = self.chat(question)
        self.clear_history()
        return reply

    def search(self, query: str, max_results: int = 5) -> List[Dict]:
        """
        Run an MK-AI web search.

        Parameters
        ----------
        query : str
            What to search for.
        max_results : int, optional
            How many results to return (1-10).  Default: 5

        Returns
        -------
        list of dict
            Each dict has: title, link, snippet, source

        Example
        -------
        >>> results = bot.search("latest Python version")
        >>> for r in results:
        ...     print(r["title"], r["link"])
        """
        return web_search(
            sanitize_string(str(query), 256),
            max(1, min(int(max_results), 10)),
        )

    def analyze_image(
        self,
        image_path: str,
        prompt: str = "Describe this image in detail.",
    ) -> str:
        """
        Analyze a local image (JPG, PNG, GIF, WEBP).

        Parameters
        ----------
        image_path : str
            Path to the image file on your computer.
        prompt : str, optional
            What to ask about the image.

        Returns
        -------
        str
            The AI's description or answer.

        Example
        -------
        >>> desc = bot.analyze_image("photo.jpg", "What is in this picture?")
        >>> print(desc)
        """
        path = Path(str(image_path))
        if not path.exists():
            raise FileNotFoundError(
                f"Image file not found: {image_path}\n"
                f"Make sure the path is correct."
            )

        ext_map = {
            ".jpg":  "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png":  "image/png",
            ".gif":  "image/gif",
            ".webp": "image/webp",
        }
        media_type = ext_map.get(path.suffix.lower())
        if not media_type:
            raise ValueError(
                f"Unsupported image type: {path.suffix}\n"
                f"Supported: JPG, PNG, GIF, WEBP"
            )
        if path.stat().st_size > 20 * 1024 * 1024:
            raise ValueError("Image is too large (max 20 MB).")

        with open(path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")

        messages = [
            {"role": "system", "content": "You are MK-AI Vision. Powered by MKDEVAPI."},
            {
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": f"data:{media_type};base64,{b64}"}},
                    {"type": "text",      "text": sanitize_string(str(prompt), 512)},
                ],
            },
        ]

        orig_model, orig_stream = self.model, self.stream
        self.model  = "gpt-4o-mini" if "gpt-4o-mini" in self._model_access else self._model_access[0]
        self.stream = False
        try:
            return self._call(messages)
        finally:
            self.model  = orig_model
            self.stream = orig_stream

    # ── Dunder helpers ─────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        masked = self._api_key[:16] + "…"
        return (
            f"MKAI(\n"
            f"  api_key    = '{masked}',\n"
            f"  model      = '{self.model}',\n"
            f"  models     = {len(self._model_access)} available,\n"
            f"  powered_by = 'MKDEVAPI',\n"
            f")"
        )

    def __str__(self) -> str:
        return (
            f"MK-AI  ·  {self._user.get('name', 'User')}  ·  "
            f"Model: {self.model}  ·  Powered by MKDEVAPI"
        )


# ══════════════════════════════════════════════════════════════════════════════
#  FREE TIER CLIENT  (no API key required)
# ══════════════════════════════════════════════════════════════════════════════

class MKAIFree:
    """
    MK-AI Free Tier — no API key needed.

    ┌───────────────────────────────────────────────────────┐
    │  Available models:                                    │
    │    • gpt-4o-mini      (default, fast, smart)          │
    │    • gpt-4.1-nano     (lightweight, very fast)        │
    │    • gemini-2.5-flash-lite  (Google, great at tasks)  │
    │                                                       │
    │  Limits:                                              │
    │    • 10 requests per hour                             │
    │    • 500 tokens per reply                             │
    │    • No web search                                    │
    │    • Conversation memory (last 6 turns)               │
    └───────────────────────────────────────────────────────┘

    Quick start
    -----------
        import mkdevai

        # Easiest way:
        reply = mkdevai.free.chat("What is Python?")
        print(reply)

        # With a specific model:
        reply = mkdevai.free.gemini.chat("Hello!")

        # Stateful bot (remembers conversation):
        bot = mkdevai.MKAIFree()
        print(bot.chat("My name is Ali"))
        print(bot.chat("What is my name?"))   # → "Your name is Ali"
    """

    def __init__(self, model: Optional[str] = None):
        if model:
            if model not in FREE_TIER_MODEL_IDS:
                models_str = ", ".join(FREE_TIER_MODEL_IDS)
                raise ValueError(
                    f"❌  Model '{model}' is not available on the free tier.\n\n"
                    f"  Free-tier models: {models_str}\n\n"
                    f"  Get an API key for access to all 10 models."
                )
            self.model = model
        else:
            self.model = FREE_TIER_MODEL_IDS[0]   # gpt-4o-mini

        self.history: List[Dict] = []
        self._session_id = f"free_{id(self)}"

    # ── Properties ─────────────────────────────────────────────────────────────

    @property
    def models(self) -> List[str]:
        """Free-tier model IDs."""
        return list(FREE_TIER_MODEL_IDS)

    @property
    def requests_remaining(self) -> int:
        """How many requests you have left in the current hour."""
        return rate_limit_remaining(
            self._session_id,
            FREE_TIER_RATE_LIMIT_CALLS,
            FREE_TIER_RATE_LIMIT_WINDOW,
        )

    # ── Model & history ────────────────────────────────────────────────────────

    def set_model(self, model_id: str) -> None:
        """
        Switch model.

        Example
        -------
        >>> bot = mkdevai.MKAIFree()
        >>> bot.set_model("gemini-2.5-flash-lite")
        """
        if model_id not in FREE_TIER_MODEL_IDS:
            raise ValueError(
                f"❌  '{model_id}' is not a free-tier model.\n"
                f"  Available: {', '.join(FREE_TIER_MODEL_IDS)}"
            )
        self.model = model_id

    def clear_history(self) -> None:
        """Forget the conversation so far."""
        self.history = []

    # ── Internal call ──────────────────────────────────────────────────────────

    def _call(self, messages: List[Dict]) -> str:
        # Rate limit
        if not check_rate_limit(
            self._session_id,
            FREE_TIER_RATE_LIMIT_CALLS,
            FREE_TIER_RATE_LIMIT_WINDOW,
        ):
            rem = 60  # approximate
            raise RuntimeError(
                f"⏱️   Free-tier rate limit reached.\n\n"
                f"  You've used all {FREE_TIER_RATE_LIMIT_CALLS} "
                f"free requests for this hour.\n\n"
                f"  Options:\n"
                f"  • Wait ~1 hour for the limit to reset\n"
                f"  • Get an API key for higher limits (contact admin)"
            )

        token   = get_puter_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type":  "application/json",
        }
        payload = {
            "model":       self.model,
            "messages":    messages,
            "max_tokens":  FREE_TIER_MAX_TOKENS,
            "temperature": 0.7,
            "stream":      False,
        }

        try:
            resp = requests.post(PUTER_API_URL, headers=headers, json=payload, timeout=30)
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]
        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                "🌐  No internet connection.\n"
                "  Check your network and try again."
            )
        except requests.exceptions.HTTPError as exc:
            code = exc.response.status_code if exc.response is not None else "?"
            raise RuntimeError(
                f"❌  Server error ({code}). Please try again in a moment."
            )
        except Exception:
            raise RuntimeError(
                "❌  Request failed. Please try again."
            )

    # ── Public chat ────────────────────────────────────────────────────────────

    def chat(
        self,
        message: str,
        system:  Optional[str] = None,
    ) -> str:
        """
        Send a message and get a reply.

        Remembers the last 6 turns of conversation.

        Parameters
        ----------
        message : str
            Your message.
        system : str, optional
            Custom instructions for the AI.

        Returns
        -------
        str
            The AI's reply.

        Example
        -------
        >>> bot = mkdevai.MKAIFree()
        >>> print(bot.chat("Hi! My name is Sara"))
        >>> print(bot.chat("What's my name?"))  # remembers!
        """
        message = sanitize_string(str(message), 2048)
        if not message:
            raise ValueError("Message cannot be empty.")

        sys_prompt = system or (
            "You are MK-AI, a helpful AI assistant powered by MKDEVAPI. "
            "Be helpful, friendly, and concise."
        )
        messages = [{"role": "system", "content": sys_prompt}]
        for m in self.history[-6:]:
            messages.append({"role": m["role"], "content": m["content"]})
        messages.append({"role": "user", "content": message})

        reply = self._call(messages)

        self.history.append({"role": "user",      "content": message})
        self.history.append({"role": "assistant",  "content": reply})
        return reply

    def ask(self, question: str) -> str:
        """
        One-shot question — no memory.

        Example
        -------
        >>> answer = mkdevai.MKAIFree().ask("What is 5 * 6?")
        """
        self.clear_history()
        reply = self.chat(question)
        self.clear_history()
        return reply

    # ── Dunder ─────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"MKAIFree(\n"
            f"  model             = '{self.model}',\n"
            f"  requests_left     = {self.requests_remaining}/{FREE_TIER_RATE_LIMIT_CALLS} per hour,\n"
            f"  max_tokens        = {FREE_TIER_MAX_TOKENS},\n"
            f"  powered_by        = 'MKDEVAPI',\n"
            f")"
        )

    def __str__(self) -> str:
        return (
            f"MK-AI Free  ·  Model: {self.model}  ·  "
            f"{self.requests_remaining} requests left  ·  Powered by MKDEVAPI"
        )


# ══════════════════════════════════════════════════════════════════════════════
#  FREE TIER MODULE  (mkdevai.free.chat / mkdevai.free.gemini.chat etc.)
# ══════════════════════════════════════════════════════════════════════════════

class _FreeTierModule:
    """
    The mkdevai.free namespace.

    Usage
    -----
        import mkdevai

        # Simplest — one line
        print(mkdevai.free.chat("Hello!"))

        # Specific model
        print(mkdevai.free.gemini.chat("Hello!"))
        print(mkdevai.free.gpt4o_mini.chat("Hello!"))
        print(mkdevai.free.gpt4_nano.chat("Hello!"))

        # Stateful bot via free
        bot = mkdevai.free.bot()          # new MKAIFree instance
        bot.chat("Hello")

        # Check remaining requests
        print(mkdevai.free.remaining())
    """

    def __init__(self) -> None:
        # Model-specific stateful bots
        self.gpt4o_mini = MKAIFree(model="gpt-4o-mini")
        self.gpt4_nano  = MKAIFree(model="gpt-4.1-nano")
        self.gemini     = MKAIFree(model="gemini-2.5-flash-lite")
        self._default   = MKAIFree()

    # ── One-shot helpers ───────────────────────────────────────────────────────

    def chat(
        self,
        message: str,
        model:   Optional[str] = None,
        system:  Optional[str] = None,
    ) -> str:
        """
        One-shot free chat.  No API key needed.

        Parameters
        ----------
        message : str
            Your message.
        model : str, optional
            Which model to use.  Defaults to gpt-4o-mini.
            Options: 'gpt-4o-mini', 'gpt-4.1-nano', 'gemini-2.5-flash-lite'
        system : str, optional
            Custom instructions for the AI.

        Returns
        -------
        str
            The AI's reply.

        Example
        -------
        >>> import mkdevai
        >>> print(mkdevai.free.chat("What is Python?"))
        >>> print(mkdevai.free.chat("Hello!", model="gemini-2.5-flash-lite"))
        """
        if model:
            return MKAIFree(model=model).chat(message, system=system)
        return self._default.chat(message, system=system)

    def ask(self, question: str, model: Optional[str] = None) -> str:
        """
        One-shot question — clears history before and after.

        Example
        -------
        >>> answer = mkdevai.free.ask("What is the capital of France?")
        """
        b = MKAIFree(model=model) if model else MKAIFree()
        return b.ask(question)

    def bot(self, model: Optional[str] = None) -> MKAIFree:
        """
        Create a fresh MKAIFree bot with its own conversation memory.

        Example
        -------
        >>> b = mkdevai.free.bot()
        >>> b.chat("My name is Ahmed")
        >>> b.chat("What is my name?")
        """
        return MKAIFree(model=model)

    def remaining(self) -> int:
        """
        How many free requests are left in the current hour.

        Example
        -------
        >>> print(mkdevai.free.remaining())
        9
        """
        return self._default.requests_remaining

    # ── Convenience model aliases ──────────────────────────────────────────────

    def __getitem__(self, model_id: str) -> MKAIFree:
        """mkdevai.free['gemini-2.5-flash-lite'].chat('hi')"""
        return MKAIFree(model=model_id)

    def __call__(self, message: str, **kwargs) -> str:
        """mkdevai.free('Hello!') — shortcut for free.chat()"""
        return self.chat(message, **kwargs)

    def __repr__(self) -> str:
        return (
            f"MKAIFreeTier(\n"
            f"  models     = {FREE_TIER_MODEL_IDS},\n"
            f"  rate_limit = {FREE_TIER_RATE_LIMIT_CALLS} requests/hour,\n"
            f"  max_tokens = {FREE_TIER_MAX_TOKENS},\n"
            f")"
        )

    def __str__(self) -> str:
        return f"MK-AI Free Tier  ·  {len(FREE_TIER_MODEL_IDS)} models  ·  {FREE_TIER_RATE_LIMIT_CALLS} req/hr  ·  Powered by MKDEVAPI"
