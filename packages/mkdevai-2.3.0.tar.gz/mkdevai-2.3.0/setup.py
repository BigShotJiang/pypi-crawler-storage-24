from setuptools import setup, find_packages

setup(
    name="mkdevai",
    version="2.3.0",
    author="MKDEVAPI",
    description="MKDEVAI – Advanced AI Terminal Assistant Powered by MKDEVAPI",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    py_modules=["noapi"],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28",
        "beautifulsoup4>=4.11",
    ],
    entry_points={
        "console_scripts": [
            "mkdevai=mkdevai.__main__:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
