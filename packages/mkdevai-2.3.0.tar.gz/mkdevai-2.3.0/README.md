# MKDEVAI v2.0.1
### Advanced AI Terminal Assistant · Powered by MKDEVAPI

```bash
pip install mkdevai
mkdevai
```

## Features

- 10+ AI models (Grok default, GPT-4o, Claude Haiku, Gemini, LLaMA, Mistral, DeepSeek…)
- File support: `.py .js .ts .html .css .json .xml .yaml .csv .sql .md .sh` and 30+ more
- Image analysis (local files: jpg, png, gif, webp)
- URL fetch & analysis — paste any URL in chat
- Multi-URL compare & summarize
- Auto web search (DuckDuckGo)
- Prompt templates: analyze, code, fix, explain, translate, summarize…
- Persistent conversation memory
- Secure admin panel

## Quick Start

```python
import mkdevai
bot = mkdevai.MKAI(api_key="mk-ai-...")
print(bot.chat("Hello!"))
```

---
*Powered by MKDEVAPI*
