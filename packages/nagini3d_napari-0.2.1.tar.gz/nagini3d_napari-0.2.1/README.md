# nagini3d-napari

[![License GNU GPL v3.0](https://img.shields.io/pypi/l/nagini3d-napari.svg?color=green)](https://github.com/QuentinRapilly/nagini3d-napari/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/nagini3d-napari.svg?color=green)](https://pypi.org/project/nagini3d-napari)
[![Python Version](https://img.shields.io/pypi/pyversions/nagini3d-napari.svg?color=green)](https://python.org)
[![tests](https://github.com/QuentinRapilly/nagini3d-napari/workflows/tests/badge.svg)](https://github.com/QuentinRapilly/nagini3d-napari/actions)
[![codecov](https://codecov.io/gh/QuentinRapilly/nagini3d-napari/branch/main/graph/badge.svg)](https://codecov.io/gh/QuentinRapilly/nagini3d-napari)
[![napari hub](https://img.shields.io/endpoint?url=https://api.napari-hub.org/shields/nagini3d-napari)](https://napari-hub.org/plugins/nagini3d-napari)
[![npe2](https://img.shields.io/badge/plugin-npe2-blue?link=https://napari.org/stable/plugins/index.html)](https://napari.org/stable/plugins/index.html)
[![Copier](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/copier-org/copier/master/img/badge/badge-grayscale-inverted-border-purple.json)](https://github.com/copier-org/copier)

A simple plugin that implements Nagini3D inference tools for segmenting 3D biological images.

----------------------------------

This [napari] plugin was generated with [copier] using the [napari-plugin-template] (None).

<!--
Don't miss the full getting started guide to set up your new package:
https://github.com/napari/napari-plugin-template#getting-started

and review the napari docs for plugin developers:
https://napari.org/stable/plugins/index.html
-->

## Installation

You can install `nagini3d-napari` via [pip]:

```
pip install nagini3d-napari
```

If napari is not already installed, you can install `nagini3d-napari` with napari and Qt via:

```
pip install "nagini3d-napari[all]"
```

### Installation advice

We recommend installing our plugin on a clean Python environment (Python 3.9 to 3.11 prefered), to avoid any conflict with other packages.

- Create and activate the environment with:

```
python -m venv <path-to-new-virtual-environment>
source <path-to-new-virtual-environment>/bin/activate
```

- Download the package in the new env with

```
pip install "nagini3d-napari[all]"
```

- Launch Napari

```
napari
```

- Activate NAGINI3D in the plugin manager.

## Models weights and testing images

An archive containing model weigths trained on different datasets and testing images are available on
zenodo at [https://zenodo.org/records/17909858](https://zenodo.org/records/17909858).

## Documentation

The GitHub project containing all the documentation is available at [https://github.com/QuentinRapilly/NAGINI-3D](https://github.com/QuentinRapilly/NAGINI-3D).
## Contributing

Contributions are very welcome. Tests can be run with [tox], please ensure
the coverage at least stays the same before you submit a pull request.

## License

Distributed under the terms of the [GNU GPL v3.0] license,
"nagini3d-napari" is free and open source software

## Issues

If you encounter any problems, please [file an issue] along with a detailed description.

[napari]: https://github.com/napari/napari
[copier]: https://copier.readthedocs.io/en/stable/
[@napari]: https://github.com/napari
[MIT]: http://opensource.org/licenses/MIT
[BSD-3]: http://opensource.org/licenses/BSD-3-Clause
[GNU GPL v3.0]: http://www.gnu.org/licenses/gpl-3.0.txt
[GNU LGPL v3.0]: http://www.gnu.org/licenses/lgpl-3.0.txt
[Apache Software License 2.0]: http://www.apache.org/licenses/LICENSE-2.0
[Mozilla Public License 2.0]: https://www.mozilla.org/media/MPL/2.0/index.txt
[napari-plugin-template]: https://github.com/napari/napari-plugin-template

[file an issue]: https://github.com/QuentinRapilly/nagini3d-napari/issues

[napari]: https://github.com/napari/napari
[tox]: https://tox.readthedocs.io/en/latest/
[pip]: https://pypi.org/project/pip/
[PyPI]: https://pypi.org/
