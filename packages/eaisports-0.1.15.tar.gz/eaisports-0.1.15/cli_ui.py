"""Chat console adapter and compact banner builder for the CLI.

Extracted from cli.py to reduce file size. Contains the ChatConsole class
(Rich Console adapter for prompt_toolkit) and the compact banner builder.
"""

import shutil

from rich.console import Console

from prompt_toolkit import print_formatted_text as _pt_print
from prompt_toolkit.formatted_text import ANSI as _PT_ANSI


def _cprint(text: str):
    """Print ANSI-colored text through prompt_toolkit's native renderer.

    Raw ANSI escapes written via print() are swallowed by patch_stdout's
    StdoutProxy.  Routing through print_formatted_text(ANSI(...)) lets
    prompt_toolkit parse the escapes and render real colors.
    """
    _pt_print(_PT_ANSI(text))


class ChatConsole:
    """Rich Console adapter for prompt_toolkit's patch_stdout context.

    Captures Rich's rendered ANSI output and routes it through _cprint
    so colors and markup render correctly inside the interactive chat loop.
    Drop-in replacement for Rich Console -- just pass this to any function
    that expects a console.print() interface.
    """

    def __init__(self):
        from io import StringIO
        self._buffer = StringIO()
        self._inner = Console(file=self._buffer, force_terminal=True, highlight=False)

    def print(self, *args, **kwargs):
        self._buffer.seek(0)
        self._buffer.truncate()
        self._inner.print(*args, **kwargs)
        output = self._buffer.getvalue()
        for line in output.rstrip("\n").split("\n"):
            _cprint(line)


def _build_compact_banner() -> str:
    """Build a compact banner that fits the current terminal width."""
    w = min(shutil.get_terminal_size().columns - 2, 64)
    if w < 30:
        return "\n[#87FF00]EAISPORTS[/] [dim #006B3A]- AI-Powered Game Builder[/]\n"
    inner = w - 2  # inside the box border
    bar = "\u2550" * w
    line1 = "EAISPORTS - AI-Powered Game Builder"
    line2 = "Build games. Push live. Earn tokens."
    # Truncate and pad to fit
    line1 = line1[:inner - 2].ljust(inner - 2)
    line2 = line2[:inner - 2].ljust(inner - 2)
    return (
        f"\n[bold #00FF87]\u2554{bar}\u2557[/]\n"
        f"[bold #00FF87]\u2551[/] [#87FF00]{line1}[/] [bold #00FF87]\u2551[/]\n"
        f"[bold #00FF87]\u2551[/] [dim #006B3A]{line2}[/] [bold #00FF87]\u2551[/]\n"
        f"[bold #00FF87]\u255a{bar}\u255d[/]\n"
    )
