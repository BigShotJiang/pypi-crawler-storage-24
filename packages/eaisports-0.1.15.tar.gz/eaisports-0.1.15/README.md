# EAISports CLI

AI-powered game building CLI. Creators use their own AI compute (via OpenRouter) to build browser games, then publish to [eaisports.ai](https://eaisports.ai).

> **Fork notice:** This project is a respectful fork of [Hermes Agent](https://github.com/NousResearch/hermes-agent) by [Nous Research](https://x.com/NousResearch), released under the MIT License. The agent runtime, tool-calling architecture, and session management originate from their work. We built the game-building CLI, skills system, and deployment pipeline on top of their excellent foundation.

## Install

```bash
pip install eaisports
```

Requires Python 3.11+.

## Quickstart

```bash
# 1. Set up your API key and wallet
eaisports init

# 2. Build a game (AI-powered)
eaisports build my-trivia-game

# 3. Preview locally
eaisports preview my-trivia-game

# 4. Deploy to eaisports.ai
eaisports push my-trivia-game
```

## Configuration

Config lives in `~/.eaisports/`. Run `eaisports init` for interactive setup, or set environment variables:

```bash
# Required: OpenRouter API key (https://openrouter.ai/keys)
export OPENROUTER_API_KEY=sk-or-...

# Optional: default model (default: anthropic/claude-opus-4.6)
export LLM_MODEL=anthropic/claude-opus-4.6
```

Copy `.env.example` to `~/.eaisports/.env` for the full list of options.

## Command Reference

| Command | Description |
|---------|-------------|
| `eaisports init` | Interactive setup wizard (API key, wallet, model) |
| `eaisports build [slug]` | Build a game with AI assistance |
| `eaisports build --skill trivia` | Build using a skill template |
| `eaisports build --resume my-game` | Resume a previous build session |
| `eaisports preview [slug]` | Launch local Vite dev server |
| `eaisports push [slug]` | Deploy game to eaisports.ai |
| `eaisports stats` | View creator dashboard (games, visitors, tokens) |
| `eaisports skills list` | List installed game skills |
| `eaisports skills info <name>` | Show skill details |
| `eaisports skills init <name>` | Create a new skill template |
| `eaisports skills search <query>` | Search available skills |
| `eaisports config` | View current configuration |
| `eaisports sessions browse` | Browse and resume past sessions |
| `eaisports doctor` | Check configuration and dependencies |
| `eaisports version` | Show version |

## Skills

Skills are reusable game templates that seed the AI build process. Bundled skills:

- **interactive-fiction** — Text-based narrative games with branching storylines
- **trivia** — Quiz games with categories, scoring, and timers
- **puzzle-logic** — Logic puzzles, pattern matching, and brain teasers
- **game-ui** — Reusable UI components (menus, HUDs, leaderboards)

Skills live in `~/.eaisports/skills/{name}/SKILL.md` with YAML frontmatter.

After building a game, the CLI can auto-extract reusable patterns (components, themes, mechanics) and save them as new local skills.

## Architecture

```
eaisports_cli/     — CLI commands (init, build, preview, push, stats, skills, config)
agent/             — AI agent runtime (prompt building, context compression)
tools/             — Tool suite (file, terminal, memory, skills, browser, etc.)
skills/            — Bundled game skill templates
run_agent.py       — AIAgent class (OpenAI-compatible tool calling loop)
cli.py             — Interactive terminal UI (Rich + prompt_toolkit)
eaisports_state.py — Session management (SQLite + FTS5)
```

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
python -m pytest tests/ -x

# Import check
python -c "import eaisports_cli"

# Smoke test
python -m eaisports_cli.main --help
```

## Acknowledgments

EAISports is built on the shoulders of [Hermes Agent](https://github.com/NousResearch/hermes-agent) by [Nous Research](https://nousresearch.com/). The core agent runtime, OpenAI-compatible tool-calling loop, memory system, and session management are derived from their open-source work.

We are grateful to the Nous Research team for making Hermes Agent available under the MIT License, enabling projects like this to exist.

## License

MIT — see [LICENSE](./LICENSE) for details.
