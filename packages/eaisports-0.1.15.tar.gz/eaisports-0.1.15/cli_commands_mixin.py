"""
CommandHandlerMixin — slash-command dispatch extracted from EAISportsCLI.

All methods access ``self.*`` attributes set in ``EAISportsCLI.__init__``.
"""

import os
import shutil

from cli_config import save_config_value
from eaisports_cli.banner import (
    cprint as _cprint, _GOLD, _GREEN, _BOLD, _DIM, _RST,
)
from eaisports_cli.commands import COMMANDS
from model_tools import get_tool_definitions
from cli_ui import ChatConsole, _build_compact_banner
from eaisports_cli.banner import build_welcome_banner
from agent.skill_commands import get_skill_commands, build_skill_invocation_message

# Lazily loaded at module-import time (same as cli.py top-level)
from agent.skill_commands import scan_skill_commands
_skill_commands = scan_skill_commands()

from cron import create_job, list_jobs, remove_job, get_job


class CommandHandlerMixin:
    """Slash-command handlers extracted from EAISportsCLI."""

    def process_command(self, command: str) -> bool:
        """
        Process a slash command.

        Args:
            command: The command string (starting with /)

        Returns:
            bool: True to continue, False to exit
        """
        # Lowercase only for dispatch matching; preserve original case for arguments
        cmd_lower = command.lower().strip()
        cmd_original = command.strip()

        if cmd_lower in ("/quit", "/exit", "/q"):
            return False
        elif cmd_lower == "/help":
            self.show_help()
        elif cmd_lower == "/tools":
            self.show_tools()
        elif cmd_lower == "/toolsets":
            self.show_toolsets()
        elif cmd_lower == "/config":
            self.show_config()
        elif cmd_lower == "/clear":
            # Flush memories before clearing
            if self.agent and self.conversation_history:
                try:
                    self.agent.flush_memories(self.conversation_history)
                except Exception:
                    pass
            # Clear terminal screen.  Inside the TUI, Rich's console.clear()
            # goes through patch_stdout's StdoutProxy which swallows the
            # screen-clear escape sequences.  Use prompt_toolkit's output
            # object directly to actually clear the terminal.
            if self._app:
                out = self._app.output
                out.erase_screen()
                out.cursor_goto(0, 0)
                out.flush()
            else:
                self.console.clear()
            # Reset conversation
            self.conversation_history = []
            # Show fresh banner.  Inside the TUI we must route Rich output
            # through ChatConsole (which uses prompt_toolkit's native ANSI
            # renderer) instead of self.console (which writes raw to stdout
            # and gets mangled by patch_stdout).
            if self._app:
                cc = ChatConsole()
                term_w = shutil.get_terminal_size().columns
                if self.compact or term_w < 80:
                    cc.print(_build_compact_banner())
                else:
                    tools = get_tool_definitions(enabled_toolsets=self.enabled_toolsets, quiet_mode=True)
                    cwd = os.getenv("TERMINAL_CWD", os.getcwd())
                    ctx_len = None
                    if hasattr(self, 'agent') and self.agent and hasattr(self.agent, 'context_compressor'):
                        ctx_len = self.agent.context_compressor.context_length
                    build_welcome_banner(
                        console=cc,
                        model=self.model,
                        cwd=cwd,
                        tools=tools,
                        enabled_toolsets=self.enabled_toolsets,
                        session_id=self.session_id,
                        context_length=ctx_len,
                    )
                _cprint("  ✨ (◕‿◕)✨ Fresh start! Screen cleared and conversation reset.\n")
            else:
                self.show_banner()
                print("  ✨ (◕‿◕)✨ Fresh start! Screen cleared and conversation reset.\n")
        elif cmd_lower == "/history":
            self.show_history()
        elif cmd_lower.startswith("/title"):
            parts = cmd_original.split(maxsplit=1)
            if len(parts) > 1:
                raw_title = parts[1].strip()
                if raw_title:
                    if self._session_db:
                        # Sanitize the title early so feedback matches what gets stored
                        try:
                            from eaisports_state import SessionDB
                            new_title = SessionDB.sanitize_title(raw_title)
                        except ValueError as e:
                            _cprint(f"  {e}")
                            new_title = None
                        if not new_title:
                            _cprint("  Title is empty after cleanup. Please use printable characters.")
                        elif self._session_db.get_session(self.session_id):
                            # Session exists in DB — set title directly
                            try:
                                if self._session_db.set_session_title(self.session_id, new_title):
                                    _cprint(f"  Session title set: {new_title}")
                                else:
                                    _cprint("  Session not found in database.")
                            except ValueError as e:
                                _cprint(f"  {e}")
                        else:
                            # Session not created yet — defer the title
                            # Check uniqueness proactively with the sanitized title
                            existing = self._session_db.get_session_by_title(new_title)
                            if existing:
                                _cprint(f"  Title '{new_title}' is already in use by session {existing['id']}")
                            else:
                                self._pending_title = new_title
                                _cprint(f"  Session title queued: {new_title} (will be saved on first message)")
                    else:
                        _cprint("  Session database not available.")
                else:
                    _cprint("  Usage: /title <your session title>")
            else:
                # Show current title if no argument given
                if self._session_db:
                    session = self._session_db.get_session(self.session_id)
                    if session and session.get("title"):
                        _cprint(f"  Session title: {session['title']}")
                    elif self._pending_title:
                        _cprint(f"  Session title (pending): {self._pending_title}")
                    else:
                        _cprint(f"  No title set. Usage: /title <your session title>")
                else:
                    _cprint("  Session database not available.")
        elif cmd_lower in ("/reset", "/new"):
            self.reset_conversation()
        elif cmd_lower.startswith("/model"):
            # Use original case so model names like "Anthropic/Claude-Opus-4" are preserved
            parts = cmd_original.split(maxsplit=1)
            if len(parts) > 1:
                from eaisports_cli.auth import resolve_provider
                from eaisports_cli.models import (
                    parse_model_input,
                    validate_requested_model,
                    _PROVIDER_LABELS,
                )

                raw_input = parts[1].strip()

                # Parse provider:model syntax (e.g. "openrouter:anthropic/claude-sonnet-4.5")
                current_provider = self.provider or self.requested_provider or "openrouter"
                target_provider, new_model = parse_model_input(raw_input, current_provider)
                provider_changed = target_provider != current_provider

                # If provider is changing, re-resolve credentials for the new provider
                api_key_for_probe = self.api_key
                base_url_for_probe = self.base_url
                if provider_changed:
                    try:
                        from eaisports_cli.runtime_provider import resolve_runtime_provider
                        runtime = resolve_runtime_provider(requested=target_provider)
                        api_key_for_probe = runtime.get("api_key", "")
                        base_url_for_probe = runtime.get("base_url", "")
                    except Exception as e:
                        provider_label = _PROVIDER_LABELS.get(target_provider, target_provider)
                        print(f"(>_<) Could not resolve credentials for provider '{provider_label}': {e}")
                        print(f"(^_^) Current model unchanged: {self.model}")
                        return True

                try:
                    validation = validate_requested_model(
                        new_model,
                        target_provider,
                        api_key=api_key_for_probe,
                        base_url=base_url_for_probe,
                    )
                except Exception:
                    validation = {"accepted": True, "persist": True, "recognized": False, "message": None}

                if not validation.get("accepted"):
                    print(f"(>_<) {validation.get('message')}")
                    print(f"  Model unchanged: {self.model}")
                    if "Did you mean" not in (validation.get("message") or ""):
                        print("  Tip: Use /model to see available models, /provider to see providers")
                else:
                    self.model = new_model
                    self.agent = None  # Force re-init

                    if provider_changed:
                        self.requested_provider = target_provider
                        self.provider = target_provider
                        self.api_key = api_key_for_probe
                        self.base_url = base_url_for_probe

                    provider_label = _PROVIDER_LABELS.get(target_provider, target_provider)
                    provider_note = f" [provider: {provider_label}]" if provider_changed else ""

                    if validation.get("persist"):
                        saved_model = save_config_value("model.default", new_model)
                        if provider_changed:
                            save_config_value("model.provider", target_provider)
                        if saved_model:
                            print(f"(^_^)b Model changed to: {new_model}{provider_note} (saved to config)")
                        else:
                            print(f"(^_^) Model changed to: {new_model}{provider_note} (this session only)")
                    else:
                        message = validation.get("message") or ""
                        print(f"(^_^) Model changed to: {new_model}{provider_note} (this session only)")
                        if message:
                            print(f"  Reason: {message}")
                        print("  Note: Model will revert on restart. Use a verified model to save to config.")
            else:
                from eaisports_cli.models import curated_models_for_provider, normalize_provider, _PROVIDER_LABELS
                from eaisports_cli.auth import resolve_provider as _resolve_provider
                # Resolve "auto" to the actual provider using credential detection
                raw_provider = normalize_provider(self.provider)
                if raw_provider == "auto":
                    try:
                        display_provider = _resolve_provider(
                            self.requested_provider,
                            explicit_api_key=self._explicit_api_key,
                            explicit_base_url=self._explicit_base_url,
                        )
                    except Exception:
                        display_provider = "openrouter"
                else:
                    display_provider = raw_provider
                provider_label = _PROVIDER_LABELS.get(display_provider, display_provider)
                print(f"\n  Current model:    {self.model}")
                print(f"  Current provider: {provider_label}")
                print()
                curated = curated_models_for_provider(display_provider)
                if curated:
                    print(f"  Available models ({provider_label}):")
                    for mid, desc in curated:
                        marker = " ←" if mid == self.model else ""
                        label = f"  {desc}" if desc else ""
                        print(f"    {mid}{label}{marker}")
                    print()
                print("  Usage: /model <model-name>")
                print("         /model provider:model-name  (to switch provider)")
                print("  Example: /model openrouter:anthropic/claude-sonnet-4.5")
                print("  See /provider for available providers")
        elif cmd_lower == "/provider":
            from eaisports_cli.models import list_available_providers, normalize_provider, _PROVIDER_LABELS
            from eaisports_cli.auth import resolve_provider as _resolve_provider
            # Resolve current provider
            raw_provider = normalize_provider(self.provider)
            if raw_provider == "auto":
                try:
                    current = _resolve_provider(
                        self.requested_provider,
                        explicit_api_key=self._explicit_api_key,
                        explicit_base_url=self._explicit_base_url,
                    )
                except Exception:
                    current = "openrouter"
            else:
                current = raw_provider
            current_label = _PROVIDER_LABELS.get(current, current)
            print(f"\n  Current provider: {current_label} ({current})\n")
            providers = list_available_providers()
            print("  Available providers:")
            for p in providers:
                marker = " ← active" if p["id"] == current else ""
                auth = "✓" if p["authenticated"] else "✗"
                aliases = f"  (also: {', '.join(p['aliases'])})" if p["aliases"] else ""
                print(f"    [{auth}] {p['id']:<14} {p['label']}{aliases}{marker}")
            print()
            print("  Switch: /model provider:model-name")
            print("  Setup:  eaisports setup")
        elif cmd_lower.startswith("/prompt"):
            # Use original case so prompt text isn't lowercased
            self._handle_prompt_command(cmd_original)
        elif cmd_lower.startswith("/personality"):
            # Use original case (handler lowercases the personality name itself)
            self._handle_personality_command(cmd_original)
        elif cmd_lower == "/retry":
            retry_msg = self.retry_last()
            if retry_msg and hasattr(self, '_pending_input'):
                # Re-queue the message so process_loop sends it to the agent
                self._pending_input.put(retry_msg)
        elif cmd_lower == "/undo":
            self.undo_last()
        elif cmd_lower == "/save":
            self.save_conversation()
        elif cmd_lower.startswith("/cron"):
            self._handle_cron_command(cmd_original)
        elif cmd_lower.startswith("/skills"):
            self._handle_skills_command(cmd_original)
        elif cmd_lower == "/platforms" or cmd_lower == "/gateway":
            self._show_gateway_status()
        elif cmd_lower == "/verbose":
            self._toggle_verbose()
        elif cmd_lower == "/compress":
            self._manual_compress()
        elif cmd_lower == "/usage":
            self._show_usage()
        elif cmd_lower.startswith("/insights"):
            self._show_insights(cmd_original)
        elif cmd_lower == "/paste":
            self._handle_paste_command()
        elif cmd_lower == "/reload-mcp":
            self._reload_mcp()
        elif cmd_lower.startswith("/rollback"):
            self._handle_rollback_command(cmd_original)
        elif cmd_lower.startswith("/skin"):
            self._handle_skin_command(cmd_original)
        else:
            # Check for skill slash commands (/gif-search, /axolotl, etc.)
            base_cmd = cmd_lower.split()[0]
            if base_cmd in _skill_commands:
                user_instruction = cmd_original[len(base_cmd):].strip()
                msg = build_skill_invocation_message(base_cmd, user_instruction)
                if msg:
                    skill_name = _skill_commands[base_cmd]["name"]
                    print(f"\n⚡ Loading skill: {skill_name}")
                    if hasattr(self, '_pending_input'):
                        self._pending_input.put(msg)
                else:
                    self.console.print(f"[bold red]Failed to load skill for {base_cmd}[/]")
            else:
                self.console.print(f"[bold red]Unknown command: {cmd_lower}[/]")
                self.console.print("[dim #006B3A]Type /help for available commands[/]")

        return True

    def _handle_rollback_command(self, command: str):
        """Handle /rollback — list or restore filesystem checkpoints."""
        from tools.checkpoint_manager import CheckpointManager, format_checkpoint_list

        if not hasattr(self, 'agent') or not self.agent:
            print("  No active agent session.")
            return

        mgr = self.agent._checkpoint_mgr
        if not mgr.enabled:
            print("  Checkpoints are not enabled.")
            print("  Enable with: eaisports --checkpoints")
            print("  Or in config.yaml: checkpoints: { enabled: true }")
            return

        cwd = os.getenv("TERMINAL_CWD", os.getcwd())
        parts = command.split(maxsplit=1)
        arg = parts[1].strip() if len(parts) > 1 else ""

        if not arg:
            # List checkpoints
            checkpoints = mgr.list_checkpoints(cwd)
            print(format_checkpoint_list(checkpoints, cwd))
        else:
            # Restore by number or hash
            checkpoints = mgr.list_checkpoints(cwd)
            if not checkpoints:
                print(f"  No checkpoints found for {cwd}")
                return

            target_hash = None
            try:
                idx = int(arg) - 1  # 1-indexed for user
                if 0 <= idx < len(checkpoints):
                    target_hash = checkpoints[idx]["hash"]
                else:
                    print(f"  Invalid checkpoint number. Use 1-{len(checkpoints)}.")
                    return
            except ValueError:
                # Try as a git hash
                target_hash = arg

            result = mgr.restore(cwd, target_hash)
            if result["success"]:
                print(f"  ✅ Restored to checkpoint {result['restored_to']}: {result['reason']}")
                print(f"  A pre-rollback snapshot was saved automatically.")
            else:
                print(f"  ❌ {result['error']}")

    def _handle_paste_command(self):
        """Handle /paste — explicitly check clipboard for an image.

        This is the reliable fallback for terminals where BracketedPaste
        doesn't fire for image-only clipboard content (e.g., VSCode terminal,
        Windows Terminal with WSL2).
        """
        from eaisports_cli.clipboard import has_clipboard_image
        if has_clipboard_image():
            if self._try_attach_clipboard_image():
                n = len(self._attached_images)
                _cprint(f"  📎 Image #{n} attached from clipboard")
            else:
                _cprint(f"  {_DIM}(>_<) Clipboard has an image but extraction failed{_RST}")
        else:
            _cprint(f"  {_DIM}(._.) No image found in clipboard{_RST}")

    def _handle_prompt_command(self, cmd: str):
        """Handle the /prompt command to view or set system prompt."""
        parts = cmd.split(maxsplit=1)

        if len(parts) > 1:
            # Set new prompt
            new_prompt = parts[1].strip()

            if new_prompt.lower() == "clear":
                self.system_prompt = ""
                self.agent = None  # Force re-init
                if save_config_value("agent.system_prompt", ""):
                    print("(^_^)b System prompt cleared (saved to config)")
                else:
                    print("(^_^) System prompt cleared (session only)")
            else:
                self.system_prompt = new_prompt
                self.agent = None  # Force re-init
                if save_config_value("agent.system_prompt", new_prompt):
                    print(f"(^_^)b System prompt set (saved to config)")
                else:
                    print(f"(^_^) System prompt set (session only)")
                print(f"  \"{new_prompt[:60]}{'...' if len(new_prompt) > 60 else ''}\"")
        else:
            # Show current prompt
            print()
            print("+" + "-" * 50 + "+")
            print("|" + " " * 15 + "(^_^) System Prompt" + " " * 15 + "|")
            print("+" + "-" * 50 + "+")
            print()
            if self.system_prompt:
                # Word wrap the prompt for display
                words = self.system_prompt.split()
                lines = []
                current_line = ""
                for word in words:
                    if len(current_line) + len(word) + 1 <= 50:
                        current_line += (" " if current_line else "") + word
                    else:
                        lines.append(current_line)
                        current_line = word
                if current_line:
                    lines.append(current_line)
                for line in lines:
                    print(f"  {line}")
            else:
                print("  (no custom prompt set - using default)")
            print()
            print("  Usage:")
            print("    /prompt <text>  - Set a custom system prompt")
            print("    /prompt clear   - Remove custom prompt")
            print("    /personality    - Use a predefined personality")
            print()

    def _handle_personality_command(self, cmd: str):
        """Handle the /personality command to set predefined personalities."""
        parts = cmd.split(maxsplit=1)

        if len(parts) > 1:
            # Set personality
            personality_name = parts[1].strip().lower()

            if personality_name in self.personalities:
                self.system_prompt = self.personalities[personality_name]
                self.agent = None  # Force re-init
                if save_config_value("agent.system_prompt", self.system_prompt):
                    print(f"(^_^)b Personality set to '{personality_name}' (saved to config)")
                else:
                    print(f"(^_^) Personality set to '{personality_name}' (session only)")
                print(f"  \"{self.system_prompt[:60]}{'...' if len(self.system_prompt) > 60 else ''}\"")
            else:
                print(f"(._.) Unknown personality: {personality_name}")
                print(f"  Available: {', '.join(self.personalities.keys())}")
        else:
            # Show available personalities
            print()
            print("+" + "-" * 50 + "+")
            print("|" + " " * 12 + "(^o^)/ Personalities" + " " * 15 + "|")
            print("+" + "-" * 50 + "+")
            print()
            for name, prompt in self.personalities.items():
                print(f"  {name:<12} - \"{prompt}\"")
            print()
            print("  Usage: /personality <name>")
            print()

    def _handle_cron_command(self, cmd: str):
        """Handle the /cron command to manage scheduled tasks."""
        parts = cmd.split(maxsplit=2)

        if len(parts) == 1:
            # /cron - show help and list
            print()
            print("+" + "-" * 60 + "+")
            print("|" + " " * 18 + "(^_^) Scheduled Tasks" + " " * 19 + "|")
            print("+" + "-" * 60 + "+")
            print()
            print("  Commands:")
            print("    /cron                     - List scheduled jobs")
            print("    /cron list                - List scheduled jobs")
            print('    /cron add <schedule> <prompt>  - Add a new job')
            print("    /cron remove <job_id>     - Remove a job")
            print()
            print("  Schedule formats:")
            print("    30m, 2h, 1d              - One-shot delay")
            print('    "every 30m", "every 2h"  - Recurring interval')
            print('    "0 9 * * *"              - Cron expression')
            print()

            # Show current jobs
            jobs = list_jobs()
            if jobs:
                print("  Current Jobs:")
                print("  " + "-" * 55)
                for job in jobs:
                    # Format repeat status
                    times = job["repeat"].get("times")
                    completed = job["repeat"].get("completed", 0)
                    if times is None:
                        repeat_str = "forever"
                    else:
                        repeat_str = f"{completed}/{times}"

                    print(f"    {job['id'][:12]:<12} | {job['schedule_display']:<15} | {repeat_str:<8}")
                    prompt_preview = job['prompt'][:45] + "..." if len(job['prompt']) > 45 else job['prompt']
                    print(f"      {prompt_preview}")
                    if job.get("next_run_at"):
                        from datetime import datetime
                        next_run = datetime.fromisoformat(job["next_run_at"])
                        print(f"      Next: {next_run.strftime('%Y-%m-%d %H:%M')}")
                    print()
            else:
                print("  No scheduled jobs. Use '/cron add' to create one.")
            print()
            return

        subcommand = parts[1].lower()

        if subcommand == "list":
            # /cron list - just show jobs
            jobs = list_jobs()
            if not jobs:
                print("(._.) No scheduled jobs.")
                return

            print()
            print("Scheduled Jobs:")
            print("-" * 70)
            for job in jobs:
                times = job["repeat"].get("times")
                completed = job["repeat"].get("completed", 0)
                repeat_str = "forever" if times is None else f"{completed}/{times}"

                print(f"  ID: {job['id']}")
                print(f"  Name: {job['name']}")
                print(f"  Schedule: {job['schedule_display']} ({repeat_str})")
                print(f"  Next run: {job.get('next_run_at', 'N/A')}")
                print(f"  Prompt: {job['prompt'][:80]}{'...' if len(job['prompt']) > 80 else ''}")
                if job.get("last_run_at"):
                    print(f"  Last run: {job['last_run_at']} ({job.get('last_status', '?')})")
                print()

        elif subcommand == "add":
            # /cron add <schedule> <prompt>
            if len(parts) < 3:
                print("(._.) Usage: /cron add <schedule> <prompt>")
                print("  Example: /cron add 30m Remind me to take a break")
                print('  Example: /cron add "every 2h" Check server status at 192.168.1.1')
                return

            # Parse schedule and prompt
            rest = parts[2].strip()

            # Handle quoted schedule (e.g., "every 30m" or "0 9 * * *")
            if rest.startswith('"'):
                # Find closing quote
                close_quote = rest.find('"', 1)
                if close_quote == -1:
                    print("(._.) Unmatched quote in schedule")
                    return
                schedule = rest[1:close_quote]
                prompt = rest[close_quote + 1:].strip()
            else:
                # First word is schedule
                schedule_parts = rest.split(maxsplit=1)
                schedule = schedule_parts[0]
                prompt = schedule_parts[1] if len(schedule_parts) > 1 else ""

            if not prompt:
                print("(._.) Please provide a prompt for the job")
                return

            try:
                job = create_job(prompt=prompt, schedule=schedule)
                print(f"(^_^)b Created job: {job['id']}")
                print(f"  Schedule: {job['schedule_display']}")
                print(f"  Next run: {job['next_run_at']}")
            except Exception as e:
                print(f"(x_x) Failed to create job: {e}")

        elif subcommand == "remove" or subcommand == "rm" or subcommand == "delete":
            # /cron remove <job_id>
            if len(parts) < 3:
                print("(._.) Usage: /cron remove <job_id>")
                return

            job_id = parts[2].strip()
            job = get_job(job_id)

            if not job:
                print(f"(._.) Job not found: {job_id}")
                return

            if remove_job(job_id):
                print(f"(^_^)b Removed job: {job['name']} ({job_id})")
            else:
                print(f"(x_x) Failed to remove job: {job_id}")

        else:
            print(f"(._.) Unknown cron command: {subcommand}")
            print("  Available: list, add, remove")

    def _handle_skills_command(self, cmd: str):
        """Handle /skills slash command — delegates to eaisports_cli.skills_hub."""
        from eaisports_cli.skills_hub import handle_skills_slash
        handle_skills_slash(cmd, ChatConsole())

    def _handle_skin_command(self, cmd: str):
        """Handle /skin [name] — show or change the display skin."""
        try:
            from eaisports_cli.skin_engine import list_skins, set_active_skin, get_active_skin_name
        except ImportError:
            print("Skin engine not available.")
            return

        parts = cmd.strip().split(maxsplit=1)
        if len(parts) < 2 or not parts[1].strip():
            # Show current skin and list available
            current = get_active_skin_name()
            skins = list_skins()
            print(f"\n  Current skin: {current}")
            print(f"  Available skins:")
            for s in skins:
                marker = " ●" if s["name"] == current else "  "
                source = f" ({s['source']})" if s["source"] == "user" else ""
                print(f"   {marker} {s['name']}{source} — {s['description']}")
            print(f"\n  Usage: /skin <name>")
            print(f"  Custom skins: drop a YAML file in ~/.eaisports/skins/\n")
            return

        new_skin = parts[1].strip().lower()
        available = {s["name"] for s in list_skins()}
        if new_skin not in available:
            print(f"  Unknown skin: {new_skin}")
            print(f"  Available: {', '.join(sorted(available))}")
            return

        set_active_skin(new_skin)
        if save_config_value("display.skin", new_skin):
            print(f"  Skin set to: {new_skin} (saved)")
        else:
            print(f"  Skin set to: {new_skin}")
        print("  Note: banner colors will update on next session start.")
