#!/usr/bin/env python3
"""
Toolset Distributions Module

This module defines distributions of toolsets for data generation runs.
Each distribution specifies which toolsets should be used and their probability
of being selected for any given prompt during the batch processing.

A distribution is a dictionary mapping toolset names to their selection probability (%).
Probabilities should sum to 100, but the system will normalize if they don't.

Usage:
    from toolset_distributions import get_distribution, list_distributions

    # Get a specific distribution
    dist = get_distribution("development")

    # List all available distributions
    all_dists = list_distributions()
"""

from typing import Dict, List, Optional
import random
from toolsets import validate_toolset


# Distribution definitions
# Each key is a distribution name, and the value is a dict of toolset_name: probability_percentage
DISTRIBUTIONS = {
    # Default: All tools available 100% of the time
    "default": {
        "description": "All available tools, all the time",
        "toolsets": {
            "web": 100,
            "terminal": 100,
            "file": 100,
            "browser": 100,
            "skills": 100
        }
    },

    # Research-focused distribution
    "research": {
        "description": "Web research with browser for deep exploration",
        "toolsets": {
            "web": 90,
            "browser": 70,
            "terminal": 10
        }
    },

    # Development-focused distribution
    "development": {
        "description": "Terminal and file tools with occasional web lookup",
        "toolsets": {
            "terminal": 80,
            "file": 80,
            "web": 30,
            "skills": 50
        }
    },

    # Safe mode (no terminal)
    "safe": {
        "description": "All tools except terminal for safety",
        "toolsets": {
            "web": 80,
            "browser": 70,
            "skills": 50
        }
    },

    # Balanced distribution
    "balanced": {
        "description": "Equal probability of all toolsets",
        "toolsets": {
            "web": 50,
            "terminal": 50,
            "file": 50,
            "browser": 50,
            "skills": 50
        }
    },

    # Minimal (web only)
    "minimal": {
        "description": "Only web tools for basic research",
        "toolsets": {
            "web": 100
        }
    },

    # Terminal only
    "terminal_only": {
        "description": "Terminal and file tools for code execution tasks",
        "toolsets": {
            "terminal": 100,
            "file": 100
        }
    },

    # Terminal + web (common for coding tasks that need docs)
    "terminal_web": {
        "description": "Terminal and file tools with web search for documentation lookup",
        "toolsets": {
            "terminal": 100,
            "file": 100,
            "web": 100
        }
    },

    # Browser-based web interaction
    "browser_use": {
        "description": "Full browser-based web interaction with search and page control",
        "toolsets": {
            "browser": 100,
            "web": 80
        }
    },

    # Browser only (no other tools)
    "browser_only": {
        "description": "Only browser automation tools for pure web interaction tasks",
        "toolsets": {
            "browser": 100
        }
    },

    # Browser-focused tasks distribution
    "browser_tasks": {
        "description": "Browser-focused distribution for web interaction tasks",
        "toolsets": {
            "browser": 97,
            "terminal": 15
        }
    },

    # Terminal-focused tasks distribution
    "terminal_tasks": {
        "description": "Terminal-focused distribution with high terminal/file availability",
        "toolsets": {
            "terminal": 97,
            "file": 97,
            "web": 97,
            "browser": 75
        }
    },

    # Mixed browser+terminal tasks distribution
    "mixed_tasks": {
        "description": "Mixed distribution with high browser, terminal, and file availability",
        "toolsets": {
            "browser": 92,
            "terminal": 92,
            "file": 92,
            "web": 35
        }
    }
}


def get_distribution(name: str) -> Optional[Dict[str, any]]:
    """Get a toolset distribution by name."""
    return DISTRIBUTIONS.get(name)


def list_distributions() -> Dict[str, Dict]:
    """List all available distributions."""
    return DISTRIBUTIONS.copy()


def sample_toolsets_from_distribution(distribution_name: str) -> List[str]:
    """
    Sample toolsets based on a distribution's probabilities.

    Each toolset in the distribution has a % chance of being included.
    This allows multiple toolsets to be active simultaneously.

    Raises:
        ValueError: If distribution name is not found
    """
    dist = get_distribution(distribution_name)
    if not dist:
        raise ValueError(f"Unknown distribution: {distribution_name}")

    selected_toolsets = []

    for toolset_name, probability in dist["toolsets"].items():
        if not validate_toolset(toolset_name):
            print(f"Warning: Toolset '{toolset_name}' in distribution '{distribution_name}' is not valid")
            continue

        if random.random() * 100 < probability:
            selected_toolsets.append(toolset_name)

    # Ensure at least one toolset is selected
    if not selected_toolsets and dist["toolsets"]:
        highest_prob_toolset = max(dist["toolsets"].items(), key=lambda x: x[1])[0]
        if validate_toolset(highest_prob_toolset):
            selected_toolsets.append(highest_prob_toolset)

    return selected_toolsets


def validate_distribution(distribution_name: str) -> bool:
    """Check if a distribution name is valid."""
    return distribution_name in DISTRIBUTIONS


def print_distribution_info(distribution_name: str) -> None:
    """Print detailed information about a distribution."""
    dist = get_distribution(distribution_name)
    if not dist:
        print(f"Unknown distribution: {distribution_name}")
        return

    print(f"\nDistribution: {distribution_name}")
    print(f"   Description: {dist['description']}")
    print(f"   Toolsets:")
    for toolset, prob in sorted(dist["toolsets"].items(), key=lambda x: x[1], reverse=True):
        print(f"     {toolset:15} : {prob:3}% chance")
