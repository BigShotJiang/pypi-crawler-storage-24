"""Shared text-processing utilities."""

import re


def slugify(text: str, fallback: str = "untitled") -> str:
    """Convert arbitrary text into a URL-safe slug.

    Lowercase, replace spaces/underscores with hyphens, strip anything
    that isn't alphanumeric or a hyphen, collapse repeated hyphens.
    """
    text = text.lower().strip()
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"[^a-z0-9-]", "", text)
    text = re.sub(r"-{2,}", "-", text)
    return text.strip("-") or fallback
