"""
Browser Cleanup and Lifecycle Management

Handles session cleanup, inactivity monitoring, signal handling, and
resource management for browser sessions.
"""

import atexit
import logging
import os
import signal
import shutil
import subprocess
import sys
import time
import threading
from pathlib import Path
from typing import Dict, Optional

import requests

from tools.browser.config import (
    _active_sessions,
    _cleanup_done,
    _cleanup_lock,
    _cleanup_running,
    _cleanup_thread,
    _is_local_mode,
    _recording_sessions,
    _session_last_activity,
    _socket_safe_tmpdir,
    BROWSER_SESSION_INACTIVITY_TIMEOUT,
)

logger = logging.getLogger(__name__)


# ============================================================================
# Module-level references to mutable config globals
# ============================================================================
# Python rebinds module-level names on assignment, so we import the *module*
# to mutate its attributes directly when we need to flip flags like
# _cleanup_done, _cleanup_running, _cleanup_thread.
import tools.browser.config as _cfg


def _update_session_activity(task_id: str):
    """Update the last activity timestamp for a session."""
    with _cleanup_lock:
        _session_last_activity[task_id] = time.time()


# ============================================================================
# Emergency / atexit cleanup
# ============================================================================

def _emergency_cleanup_all_sessions():
    """
    Emergency cleanup of all active browser sessions.
    Called on process exit or interrupt to prevent orphaned sessions.
    """
    if _cfg._cleanup_done:
        return
    _cfg._cleanup_done = True

    if not _active_sessions:
        return

    logger.info("Emergency cleanup: closing %s active session(s)...", len(_active_sessions))

    try:
        if _is_local_mode():
            # Local mode: just close agent-browser sessions via CLI
            for task_id, session_info in list(_active_sessions.items()):
                session_name = session_info.get("session_name")
                if session_name:
                    try:
                        from tools.browser.session import _find_agent_browser
                        browser_cmd = _find_agent_browser()
                        task_socket_dir = os.path.join(
                            _socket_safe_tmpdir(),
                            f"agent-browser-{session_name}"
                        )
                        env = {**os.environ, "AGENT_BROWSER_SOCKET_DIR": task_socket_dir}
                        subprocess.run(
                            browser_cmd.split() + ["--session", session_name, "--json", "close"],
                            capture_output=True, timeout=5, env=env,
                        )
                        logger.info("Closed local session %s", session_name)
                    except Exception as e:
                        logger.debug("Error closing local session %s: %s", session_name, e)
        else:
            # Cloud mode: release Browserbase sessions via API
            api_key = os.environ.get("BROWSERBASE_API_KEY")
            project_id = os.environ.get("BROWSERBASE_PROJECT_ID")

            if not api_key or not project_id:
                logger.warning("Cannot cleanup - missing BROWSERBASE credentials")
                return

            for task_id, session_info in list(_active_sessions.items()):
                bb_session_id = session_info.get("bb_session_id")
                if bb_session_id:
                    try:
                        response = requests.post(
                            f"https://api.browserbase.com/v1/sessions/{bb_session_id}",
                            headers={
                                "X-BB-API-Key": api_key,
                                "Content-Type": "application/json"
                            },
                            json={
                                "projectId": project_id,
                                "status": "REQUEST_RELEASE"
                            },
                            timeout=5  # Short timeout for cleanup
                        )
                        if response.status_code in (200, 201, 204):
                            logger.info("Closed session %s", bb_session_id)
                        else:
                            logger.warning("Failed to close session %s: HTTP %s", bb_session_id, response.status_code)
                    except Exception as e:
                        logger.error("Error closing session %s: %s", bb_session_id, e)

        _active_sessions.clear()
    except Exception as e:
        logger.error("Emergency cleanup error: %s", e)


def _signal_handler(signum, frame):
    """Handle interrupt signals to cleanup sessions before exit."""
    logger.warning("Received signal %s, cleaning up...", signum)
    _emergency_cleanup_all_sessions()
    sys.exit(128 + signum)


# ============================================================================
# Inactivity Cleanup Functions
# ============================================================================

def _cleanup_inactive_browser_sessions():
    """
    Clean up browser sessions that have been inactive for longer than the timeout.

    This function is called periodically by the background cleanup thread to
    automatically close sessions that haven't been used recently, preventing
    orphaned sessions (local or Browserbase) from accumulating.
    """
    current_time = time.time()
    sessions_to_cleanup = []

    with _cleanup_lock:
        for task_id, last_time in list(_session_last_activity.items()):
            if current_time - last_time > BROWSER_SESSION_INACTIVITY_TIMEOUT:
                sessions_to_cleanup.append(task_id)

    for task_id in sessions_to_cleanup:
        try:
            elapsed = int(current_time - _session_last_activity.get(task_id, current_time))
            logger.info("Cleaning up inactive session for task: %s (inactive for %ss)", task_id, elapsed)
            cleanup_browser(task_id)
            with _cleanup_lock:
                if task_id in _session_last_activity:
                    del _session_last_activity[task_id]
        except Exception as e:
            logger.warning("Error cleaning up inactive session %s: %s", task_id, e)


def _browser_cleanup_thread_worker():
    """
    Background thread that periodically cleans up inactive browser sessions.

    Runs every 30 seconds and checks for sessions that haven't been used
    within the BROWSER_SESSION_INACTIVITY_TIMEOUT period.
    """
    while _cfg._cleanup_running:
        try:
            _cleanup_inactive_browser_sessions()
        except Exception as e:
            logger.warning("Cleanup thread error: %s", e)

        # Sleep in 1-second intervals so we can stop quickly if needed
        for _ in range(30):
            if not _cfg._cleanup_running:
                break
            time.sleep(1)


def _start_browser_cleanup_thread():
    """Start the background cleanup thread if not already running."""
    with _cleanup_lock:
        if _cfg._cleanup_thread is None or not _cfg._cleanup_thread.is_alive():
            _cfg._cleanup_running = True
            _cfg._cleanup_thread = threading.Thread(
                target=_browser_cleanup_thread_worker,
                daemon=True,
                name="browser-cleanup"
            )
            _cfg._cleanup_thread.start()
            logger.info("Started inactivity cleanup thread (timeout: %ss)", BROWSER_SESSION_INACTIVITY_TIMEOUT)


def _stop_browser_cleanup_thread():
    """Stop the background cleanup thread."""
    _cfg._cleanup_running = False
    if _cfg._cleanup_thread is not None:
        _cfg._cleanup_thread.join(timeout=5)


# ============================================================================
# Browserbase session close helper
# ============================================================================

def _close_browserbase_session(session_id: str, api_key: str, project_id: str) -> bool:
    """
    Close a Browserbase session immediately via the API.

    Uses POST /v1/sessions/{id} with status=REQUEST_RELEASE to immediately
    terminate the session without waiting for keepAlive timeout.

    Args:
        session_id: The Browserbase session ID
        api_key: Browserbase API key
        project_id: Browserbase project ID

    Returns:
        True if session was successfully closed, False otherwise
    """
    try:
        # POST to update session status to REQUEST_RELEASE
        response = requests.post(
            f"https://api.browserbase.com/v1/sessions/{session_id}",
            headers={
                "X-BB-API-Key": api_key,
                "Content-Type": "application/json"
            },
            json={
                "projectId": project_id,
                "status": "REQUEST_RELEASE"
            },
            timeout=10
        )

        if response.status_code in (200, 201, 204):
            logger.debug("Successfully closed BrowserBase session %s", session_id)
            return True
        else:
            logger.warning("Failed to close session %s: HTTP %s - %s", session_id, response.status_code, response.text[:200])
            return False

    except Exception as e:
        logger.error("Exception closing session %s: %s", session_id, e)
        return False


# ============================================================================
# Public cleanup functions
# ============================================================================

def cleanup_browser(task_id: Optional[str] = None) -> None:
    """
    Clean up browser session for a task.

    Called automatically when a task completes or when inactivity timeout is reached.
    Closes both the agent-browser session and the Browserbase session.

    Args:
        task_id: Task identifier to clean up
    """
    if task_id is None:
        task_id = "default"

    logger.debug("cleanup_browser called for task_id: %s", task_id)
    logger.debug("Active sessions: %s", list(_active_sessions.keys()))

    # Check if session exists (under lock), but don't remove yet -
    # _run_browser_command needs it to build the close command.
    with _cleanup_lock:
        session_info = _active_sessions.get(task_id)

    if session_info:
        bb_session_id = session_info.get("bb_session_id", "unknown")
        logger.debug("Found session for task %s: bb_session_id=%s", task_id, bb_session_id)

        # Stop auto-recording before closing (saves the file)
        # Import here to avoid circular dependency
        from tools.browser_tool import _maybe_stop_recording
        _maybe_stop_recording(task_id)

        # Try to close via agent-browser first (needs session in _active_sessions)
        try:
            from tools.browser_tool import _run_browser_command
            _run_browser_command(task_id, "close", [], timeout=10)
            logger.debug("agent-browser close command completed for task %s", task_id)
        except Exception as e:
            logger.warning("agent-browser close failed for task %s: %s", task_id, e)

        # Now remove from tracking under lock
        with _cleanup_lock:
            _active_sessions.pop(task_id, None)
            _session_last_activity.pop(task_id, None)

        # Cloud mode: close the Browserbase session via API
        if bb_session_id and not _is_local_mode():
            try:
                from tools.browser.session import _get_browserbase_config
                config = _get_browserbase_config()
                success = _close_browserbase_session(bb_session_id, config["api_key"], config["project_id"])
                if not success:
                    logger.warning("Could not close BrowserBase session %s", bb_session_id)
            except Exception as e:
                logger.error("Exception during BrowserBase session close: %s", e)

        # Kill the daemon process and clean up socket directory
        session_name = session_info.get("session_name", "")
        if session_name:
            socket_dir = os.path.join(_socket_safe_tmpdir(), f"agent-browser-{session_name}")
            if os.path.exists(socket_dir):
                # agent-browser writes {session}.pid in the socket dir
                pid_file = os.path.join(socket_dir, f"{session_name}.pid")
                if os.path.isfile(pid_file):
                    try:
                        daemon_pid = int(open(pid_file).read().strip())
                        os.kill(daemon_pid, signal.SIGTERM)
                        logger.debug("Killed daemon pid %s for %s", daemon_pid, session_name)
                    except (ProcessLookupError, ValueError, PermissionError, OSError):
                        pass
                shutil.rmtree(socket_dir, ignore_errors=True)

        logger.debug("Removed task %s from active sessions", task_id)
    else:
        logger.debug("No active session found for task_id: %s", task_id)


def cleanup_all_browsers() -> None:
    """
    Clean up all active browser sessions.

    Useful for cleanup on shutdown.
    """
    with _cleanup_lock:
        task_ids = list(_active_sessions.keys())
    for task_id in task_ids:
        cleanup_browser(task_id)


def get_active_browser_sessions() -> Dict[str, Dict[str, str]]:
    """
    Get information about active browser sessions.

    Returns:
        Dict mapping task_id to session info (session_name, bb_session_id, cdp_url)
    """
    with _cleanup_lock:
        return _active_sessions.copy()


# ============================================================================
# File / recording cleanup helpers
# ============================================================================

def _cleanup_old_screenshots(screenshots_dir, max_age_hours=24):
    """Remove browser screenshots older than max_age_hours to prevent disk bloat."""
    try:
        cutoff = time.time() - (max_age_hours * 3600)
        for f in screenshots_dir.glob("browser_screenshot_*.png"):
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
            except Exception:
                pass
    except Exception:
        pass  # Non-critical -- don't fail the screenshot operation


def _cleanup_old_recordings(max_age_hours=72):
    """Remove browser recordings older than max_age_hours to prevent disk bloat."""
    try:
        eaisports_home = Path(os.environ.get("EAISPORTS_HOME", Path.home() / ".eaisports"))
        recordings_dir = eaisports_home / "browser_recordings"
        if not recordings_dir.exists():
            return
        cutoff = time.time() - (max_age_hours * 3600)
        for f in recordings_dir.glob("session_*.webm"):
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
            except Exception:
                pass
    except Exception:
        pass


# ============================================================================
# Requirements Check
# ============================================================================

def check_browser_requirements() -> bool:
    """
    Check if browser tool requirements are met.

    In **local mode** (no Browserbase credentials): only the ``agent-browser``
    CLI must be findable.

    In **cloud mode** (BROWSERBASE_API_KEY set): the CLI *and* both
    ``BROWSERBASE_API_KEY`` / ``BROWSERBASE_PROJECT_ID`` must be present.

    Returns:
        True if all requirements are met, False otherwise
    """
    # The agent-browser CLI is always required
    try:
        from tools.browser.session import _find_agent_browser
        _find_agent_browser()
    except FileNotFoundError:
        return False

    # In cloud mode, also require Browserbase credentials
    if not _is_local_mode():
        api_key = os.environ.get("BROWSERBASE_API_KEY")
        project_id = os.environ.get("BROWSERBASE_PROJECT_ID")
        if not api_key or not project_id:
            return False

    return True


# ============================================================================
# Register cleanup handlers (runs when this module is first imported)
# ============================================================================

atexit.register(_emergency_cleanup_all_sessions)
atexit.register(_stop_browser_cleanup_thread)

# Only register signal handlers in main process (not in multiprocessing workers)
try:
    if os.getpid() == os.getpgrp():  # Main process check
        signal.signal(signal.SIGINT, _signal_handler)
        signal.signal(signal.SIGTERM, _signal_handler)
except (OSError, AttributeError):
    pass  # Signal handling not available (e.g., Windows or worker process)
