"""
Browser Tool Package

Re-exports all public symbols so that ``from tools.browser import ...`` works
identically to the old ``from tools.browser_tool import ...``.
"""

from tools.browser.config import (
    DEFAULT_COMMAND_TIMEOUT,
    DEFAULT_SESSION_TIMEOUT,
    SNAPSHOT_SUMMARIZE_THRESHOLD,
    BROWSER_SESSION_INACTIVITY_TIMEOUT,
    EXTRACTION_MODEL,
    _aux_vision_client,
    _aux_text_client,
    _DEFAULT_VISION_MODEL,
    _DEFAULT_TEXT_MODEL,
    _get_vision_model,
    _get_extraction_model,
    _is_local_mode,
    _socket_safe_tmpdir,
    _active_sessions,
    _recording_sessions,
    _cleanup_done,
    _session_last_activity,
    _cleanup_thread,
    _cleanup_running,
    _cleanup_lock,
)

from tools.browser.session import (
    _create_browserbase_session,
    _create_local_session,
    _get_session_info,
    _get_session_name,
    _get_browserbase_config,
    _find_agent_browser,
)

from tools.browser.cleanup import (
    _emergency_cleanup_all_sessions,
    _signal_handler,
    _cleanup_inactive_browser_sessions,
    _browser_cleanup_thread_worker,
    _start_browser_cleanup_thread,
    _stop_browser_cleanup_thread,
    _update_session_activity,
    _close_browserbase_session,
    cleanup_browser,
    cleanup_all_browsers,
    get_active_browser_sessions,
    _cleanup_old_screenshots,
    _cleanup_old_recordings,
    check_browser_requirements,
)

__all__ = [
    # config
    "DEFAULT_COMMAND_TIMEOUT",
    "DEFAULT_SESSION_TIMEOUT",
    "SNAPSHOT_SUMMARIZE_THRESHOLD",
    "BROWSER_SESSION_INACTIVITY_TIMEOUT",
    "EXTRACTION_MODEL",
    "_aux_vision_client",
    "_aux_text_client",
    "_DEFAULT_VISION_MODEL",
    "_DEFAULT_TEXT_MODEL",
    "_get_vision_model",
    "_get_extraction_model",
    "_is_local_mode",
    "_socket_safe_tmpdir",
    "_active_sessions",
    "_recording_sessions",
    "_cleanup_done",
    "_session_last_activity",
    "_cleanup_thread",
    "_cleanup_running",
    "_cleanup_lock",
    # session
    "_create_browserbase_session",
    "_create_local_session",
    "_get_session_info",
    "_get_session_name",
    "_get_browserbase_config",
    "_find_agent_browser",
    # cleanup
    "_emergency_cleanup_all_sessions",
    "_signal_handler",
    "_cleanup_inactive_browser_sessions",
    "_browser_cleanup_thread_worker",
    "_start_browser_cleanup_thread",
    "_stop_browser_cleanup_thread",
    "_update_session_activity",
    "_close_browserbase_session",
    "cleanup_browser",
    "cleanup_all_browsers",
    "get_active_browser_sessions",
    "_cleanup_old_screenshots",
    "_cleanup_old_recordings",
    "check_browser_requirements",
]
