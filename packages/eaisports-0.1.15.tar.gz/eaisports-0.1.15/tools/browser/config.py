"""
Browser Tool Configuration

Constants, client initialization, helper functions, and global state for the
browser tool subsystem.
"""

import logging
import os
import sys
import tempfile
import threading
from typing import Dict

from agent.auxiliary_client import get_vision_auxiliary_client, get_text_auxiliary_client

logger = logging.getLogger(__name__)

# ============================================================================
# Constants
# ============================================================================

# Default timeout for browser commands (seconds)
DEFAULT_COMMAND_TIMEOUT = 30

# Default session timeout (seconds)
DEFAULT_SESSION_TIMEOUT = 300

# Max tokens for snapshot content before summarization
SNAPSHOT_SUMMARIZE_THRESHOLD = 8000

# Session inactivity timeout (seconds) - cleanup if no activity for this long
# Default: 5 minutes. Needs headroom for LLM reasoning between browser commands,
# especially when subagents are doing multi-step browser tasks.
BROWSER_SESSION_INACTIVITY_TIMEOUT = int(os.environ.get("BROWSER_INACTIVITY_TIMEOUT", "300"))

# ============================================================================
# Client initialization
# ============================================================================

# Vision client -- for browser_vision (screenshot analysis)
# Wrapped in try/except so a broken auxiliary config doesn't prevent the entire
# browser_tool module from importing (which would disable all 10 browser tools).
try:
    _aux_vision_client, _DEFAULT_VISION_MODEL = get_vision_auxiliary_client()
except Exception as _init_err:
    logger.debug("Could not initialise vision auxiliary client: %s", _init_err)
    _aux_vision_client, _DEFAULT_VISION_MODEL = None, None

# Text client -- for page snapshot summarization (same config as web_extract)
try:
    _aux_text_client, _DEFAULT_TEXT_MODEL = get_text_auxiliary_client("web_extract")
except Exception as _init_err:
    logger.debug("Could not initialise text auxiliary client: %s", _init_err)
    _aux_text_client, _DEFAULT_TEXT_MODEL = None, None

# Module-level alias for availability checks
EXTRACTION_MODEL = _DEFAULT_TEXT_MODEL or _DEFAULT_VISION_MODEL

# ============================================================================
# Helper functions
# ============================================================================


def _get_vision_model() -> str:
    """Model for browser_vision (screenshot analysis -- multimodal)."""
    return (os.getenv("AUXILIARY_VISION_MODEL", "").strip()
            or _DEFAULT_VISION_MODEL
            or "google/gemini-3-flash-preview")


def _get_extraction_model() -> str:
    """Model for page snapshot text summarization -- same as web_extract."""
    return (os.getenv("AUXILIARY_WEB_EXTRACT_MODEL", "").strip()
            or _DEFAULT_TEXT_MODEL
            or "google/gemini-3-flash-preview")


def _is_local_mode() -> bool:
    """Return True when no Browserbase credentials are configured.

    In local mode the browser tools launch a headless Chromium instance via
    ``agent-browser --session`` instead of connecting to a remote Browserbase
    session via ``--cdp``.
    """
    return not (os.environ.get("BROWSERBASE_API_KEY") and os.environ.get("BROWSERBASE_PROJECT_ID"))


def _socket_safe_tmpdir() -> str:
    """Return a short temp directory path suitable for Unix domain sockets.

    macOS sets ``TMPDIR`` to ``/var/folders/xx/.../T/`` (~51 chars).  When we
    append ``agent-browser-eaisports_...`` the resulting socket path exceeds the
    104-byte macOS limit for ``AF_UNIX`` addresses, causing agent-browser to
    fail with "Failed to create socket directory" or silent screenshot failures.

    Linux ``tempfile.gettempdir()`` already returns ``/tmp``, so this is a
    no-op there.  On macOS we bypass ``TMPDIR`` and use ``/tmp`` directly
    (symlink to ``/private/tmp``, sticky-bit protected, always available).
    """
    if sys.platform == "darwin":
        return "/tmp"
    return tempfile.gettempdir()


# ============================================================================
# Global state variables
# ============================================================================

# Track active sessions per task
# Stores: session_name (always), bb_session_id + cdp_url (cloud mode only)
_active_sessions: Dict[str, Dict[str, str]] = {}  # task_id -> {session_name, ...}
_recording_sessions: set = set()  # task_ids with active recordings

# Flag to track if cleanup has been done
_cleanup_done = False

# Track last activity time per session
_session_last_activity: Dict[str, float] = {}

# Background cleanup thread state
_cleanup_thread = None
_cleanup_running = False
# Protects _session_last_activity AND _active_sessions for thread safety
# (subagents run concurrently via ThreadPoolExecutor)
_cleanup_lock = threading.Lock()
