#!/usr/bin/env python3
"""
Tools Package

This package contains all the specific tool implementations for the EAISports.
Each module provides specialized functionality for different capabilities:

- web_tools: Web search, content extraction, and crawling
- terminal_tool: Command execution using mini-swe-agent (local/docker/modal/daytona backends)
- vision_tools: Image analysis and understanding
- mixture_of_agents_tool: Multi-model collaborative reasoning
- image_generation_tool: Text-to-image generation with upscaling

The tools are imported into model_tools.py which provides a unified interface
for the AI agent to access all capabilities.
"""

# Export all tools for easy importing
from .web_tools import (
    web_search_tool,
    web_extract_tool,
    web_crawl_tool,
    check_firecrawl_api_key
)

# Primary terminal tool (mini-swe-agent backend: local/docker/singularity/modal/daytona)
from .terminal_tool import (
    terminal_tool,
    check_terminal_requirements,
    cleanup_vm,
    cleanup_all_environments,
    get_active_environments_info,
    register_task_env_overrides,
    clear_task_env_overrides,
    TERMINAL_TOOL_DESCRIPTION
)

# vision_tools, mixture_of_agents_tool, and image_generation_tool
# were removed during the EAISports rebrand (not needed for game building CLI)

from .skills_tool import (
    skills_list,
    skill_view,
    check_skills_requirements,
    SKILLS_TOOL_DESCRIPTION
)

from .skill_manager_tool import (
    skill_manage,
    check_skill_manage_requirements,
    SKILL_MANAGE_SCHEMA
)

# Browser automation tools (agent-browser + Browserbase)
from .browser_tool import (
    browser_navigate,
    browser_snapshot,
    browser_click,
    browser_type,
    browser_scroll,
    browser_back,
    browser_press,
    browser_close,
    browser_get_images,
    browser_vision,
    cleanup_browser,
    cleanup_all_browsers,
    get_active_browser_sessions,
    check_browser_requirements,
    BROWSER_TOOL_SCHEMAS
)

# Cronjob management tools (CLI-only, eaisports-cli toolset)
from .cronjob_tools import (
    schedule_cronjob,
    list_cronjobs,
    remove_cronjob,
    check_cronjob_requirements,
    get_cronjob_tool_definitions,
    SCHEDULE_CRONJOB_SCHEMA,
    LIST_CRONJOBS_SCHEMA,
    REMOVE_CRONJOB_SCHEMA
)

# rl_training_tool was removed during the EAISports rebrand

# File manipulation tools (read, write, patch, search)
from .file_tools import (
    read_file_tool,
    write_file_tool,
    patch_tool,
    search_tool,
    get_file_tools,
    clear_file_ops_cache,
)

# tts_tool was removed during the EAISports rebrand

# Planning & task management tool
from .todo_tool import (
    todo_tool,
    check_todo_requirements,
    TODO_SCHEMA,
    TodoStore,
)

# Clarifying questions tool (interactive Q&A with the user)
from .clarify_tool import (
    clarify_tool,
    check_clarify_requirements,
    CLARIFY_SCHEMA,
)

# Code execution sandbox (programmatic tool calling)
from .code_execution_tool import (
    execute_code,
    check_sandbox_requirements,
    EXECUTE_CODE_SCHEMA,
)

# Subagent delegation (spawn child agents with isolated context)
from .delegate_tool import (
    delegate_task,
    check_delegate_requirements,
    DELEGATE_TASK_SCHEMA,
)

# File tools have no external requirements - they use the terminal backend
def check_file_requirements():
    """File tools only require terminal backend to be available."""
    from .terminal_tool import check_terminal_requirements
    return check_terminal_requirements()

__all__ = [
    # Web tools
    'web_search_tool',
    'web_extract_tool',
    'web_crawl_tool',
    'check_firecrawl_api_key',
    # Terminal tools (mini-swe-agent backend)
    'terminal_tool',
    'check_terminal_requirements',
    'cleanup_vm',
    'cleanup_all_environments',
    'get_active_environments_info',
    'register_task_env_overrides',
    'clear_task_env_overrides',
    'TERMINAL_TOOL_DESCRIPTION',
    # Skills tools
    'skills_list',
    'skill_view',
    'check_skills_requirements',
    'SKILLS_TOOL_DESCRIPTION',
    # Skill management
    'skill_manage',
    'check_skill_manage_requirements',
    'SKILL_MANAGE_SCHEMA',
    # Browser automation tools
    'browser_navigate',
    'browser_snapshot',
    'browser_click',
    'browser_type',
    'browser_scroll',
    'browser_back',
    'browser_press',
    'browser_close',
    'browser_get_images',
    'browser_vision',
    'cleanup_browser',
    'cleanup_all_browsers',
    'get_active_browser_sessions',
    'check_browser_requirements',
    'BROWSER_TOOL_SCHEMAS',
    # Cronjob management tools (CLI-only)
    'schedule_cronjob',
    'list_cronjobs',
    'remove_cronjob',
    'check_cronjob_requirements',
    'get_cronjob_tool_definitions',
    'SCHEDULE_CRONJOB_SCHEMA',
    'LIST_CRONJOBS_SCHEMA',
    'REMOVE_CRONJOB_SCHEMA',
    # File manipulation tools
    'read_file_tool',
    'write_file_tool',
    'patch_tool',
    'search_tool',
    'get_file_tools',
    'clear_file_ops_cache',
    'check_file_requirements',
    # Planning & task management tool
    'todo_tool',
    'check_todo_requirements',
    'TODO_SCHEMA',
    'TodoStore',
    # Clarifying questions tool
    'clarify_tool',
    'check_clarify_requirements',
    'CLARIFY_SCHEMA',
    # Code execution sandbox
    'execute_code',
    'check_sandbox_requirements',
    'EXECUTE_CODE_SCHEMA',
    # Subagent delegation
    'delegate_task',
    'check_delegate_requirements',
    'DELEGATE_TASK_SCHEMA',
]

