"""
EAISports Game Tools -- sandboxed tools for building, previewing, and deploying games.

These tools wrap the existing Python functions from eaisports_cli so the chat
agent can create, inspect, modify, preview, and deploy games without raw
terminal access.

Tools:
    game_list     -- list all games in ~/.eaisports/games/
    game_info     -- get file tree, metadata, and deps for a game
    game_build    -- scaffold a new React + Vite game project
    game_preview  -- start/stop a local Vite dev server
    game_push     -- build and deploy a game to eaisports.ai
"""

import json
import logging
import os
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# =========================================================================
# Helpers
# =========================================================================

def _get_games_dir() -> Path:
    """Return the games directory, creating it if needed."""
    from eaisports_cli.config import get_eaisports_home
    games_dir = get_eaisports_home() / "games"
    games_dir.mkdir(parents=True, exist_ok=True)
    return games_dir


def _resolve_game_dir(slug: str) -> tuple[Optional[Path], Optional[str]]:
    """Resolve a game directory by slug. Returns (game_dir, error_message)."""
    games_dir = _get_games_dir()
    game_dir = games_dir / slug
    if not game_dir.exists():
        return None, f"Game '{slug}' not found in {games_dir}"
    if not (game_dir / "package.json").exists():
        return None, f"Game '{slug}' has no package.json — not a valid project"
    return game_dir, None


# =========================================================================
# Tool 1: game_list
# =========================================================================

def handle_game_list(args: dict, **kw) -> str:
    """List all games in ~/.eaisports/games/."""
    try:
        games_dir = _get_games_dir()
        games = []

        if games_dir.exists():
            for entry in sorted(games_dir.iterdir(), key=lambda d: d.stat().st_mtime, reverse=True):
                if entry.is_dir() and (entry / "package.json").exists():
                    has_meta = (entry / ".build_meta.json").exists()
                    stat = entry.stat()
                    games.append({
                        "slug": entry.name,
                        "path": str(entry),
                        "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                        "has_build_meta": has_meta,
                    })

        return json.dumps({
            "games": games,
            "count": len(games),
            "games_dir": str(games_dir),
        }, ensure_ascii=False)

    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


GAME_LIST_SCHEMA = {
    "name": "game_list",
    "description": (
        "List all games in the EAISports games directory (~/.eaisports/games/). "
        "Returns slug, path, last modified time, and whether build metadata exists. "
        "Use this to discover existing games before modifying or previewing them."
    ),
    "parameters": {
        "type": "object",
        "properties": {},
        "required": [],
    },
}


# =========================================================================
# Tool 2: game_info
# =========================================================================

def handle_game_info(args: dict, **kw) -> str:
    """Get detailed info about a specific game."""
    slug = args.get("slug", "").strip()
    if not slug:
        return json.dumps({"error": "slug is required"}, ensure_ascii=False)

    try:
        game_dir, err = _resolve_game_dir(slug)
        if err:
            return json.dumps({"error": err}, ensure_ascii=False)

        # File tree (src/ and top-level)
        files = []
        for path in sorted(game_dir.rglob("*")):
            if path.is_file() and "node_modules" not in path.parts and ".git" not in path.parts:
                rel = str(path.relative_to(game_dir))
                files.append({
                    "path": rel,
                    "size": path.stat().st_size,
                })

        # Build metadata
        build_meta = None
        meta_path = game_dir / ".build_meta.json"
        if meta_path.exists():
            try:
                build_meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass

        # Package.json
        pkg = None
        pkg_path = game_dir / "package.json"
        if pkg_path.exists():
            try:
                pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass

        return json.dumps({
            "slug": slug,
            "game_dir": str(game_dir),
            "files": files,
            "file_count": len(files),
            "build_meta": build_meta,
            "package_json": pkg,
        }, ensure_ascii=False)

    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


GAME_INFO_SCHEMA = {
    "name": "game_info",
    "description": (
        "Get detailed information about a specific game including file structure, "
        "build metadata, and dependencies. Use this before modifying an existing "
        "game to understand its current state. Returns file tree, .build_meta.json "
        "contents, and package.json info."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "slug": {
                "type": "string",
                "description": "Game slug (directory name under ~/.eaisports/games/)",
            },
        },
        "required": ["slug"],
    },
}


# =========================================================================
# Tool 3: game_build
# =========================================================================

def handle_game_build(args: dict, **kw) -> str:
    """Scaffold a new React + Vite game project."""
    slug = args.get("slug", "").strip()
    if not slug:
        return json.dumps({"error": "slug is required"}, ensure_ascii=False)

    description = args.get("description", "")

    try:
        from eaisports_cli.build import _slugify, _scaffold_project

        slug = _slugify(slug)
        games_dir = _get_games_dir()
        game_dir = games_dir / slug

        already_exists = game_dir.exists() and (game_dir / "package.json").exists()
        game_dir.mkdir(parents=True, exist_ok=True)

        _scaffold_project(game_dir, slug)

        # Write initial build metadata
        meta_path = game_dir / ".build_meta.json"
        meta = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        meta.update({
            "slug": slug,
            "description": description or None,
            "scaffolded_at": datetime.now().isoformat(),
            "source": "chat",
        })
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

        # List created files
        files = []
        for path in sorted(game_dir.rglob("*")):
            if path.is_file() and "node_modules" not in path.parts:
                files.append(str(path.relative_to(game_dir)))

        return json.dumps({
            "slug": slug,
            "game_dir": str(game_dir),
            "files_created": files,
            "already_existed": already_exists,
            "message": (
                f"Game '{slug}' already exists — scaffold preserved existing files."
                if already_exists else
                f"Game '{slug}' scaffolded at {game_dir}. "
                f"Edit src/App.jsx to build the game, then use game_preview to test."
            ),
        }, ensure_ascii=False)

    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


GAME_BUILD_SCHEMA = {
    "name": "game_build",
    "description": (
        "Create a new game project by scaffolding a React + Vite project structure. "
        "This creates the directory and base files (package.json, vite.config.js, "
        "main.jsx, App.jsx, index.css) in ~/.eaisports/games/{slug}/. "
        "After scaffolding, use read_file and write_file/patch to implement the game. "
        "Use game_preview to test, and game_push to deploy.\n\n"
        "The scaffolded project includes:\n"
        "- React 18 + Vite 5 setup\n"
        "- src/App.jsx (main component to edit)\n"
        "- src/main.jsx (entry point)\n"
        "- src/styles/index.css (global styles)\n"
        "- src/components/ (for game components)\n"
        "- src/data/ (for game data/config)"
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "slug": {
                "type": "string",
                "description": "URL-safe game name (e.g. 'duck-shooter', 'space-trivia'). Will be slugified.",
            },
            "description": {
                "type": "string",
                "description": "Brief description of the game to build. Saved to build metadata.",
            },
        },
        "required": ["slug"],
    },
}


# =========================================================================
# Tool 4: game_preview
# =========================================================================

def handle_game_preview(args: dict, **kw) -> str:
    """Start, stop, or check status of a Vite dev server for a game."""
    action = args.get("action", "").strip().lower()
    if action not in ("start", "stop", "status"):
        return json.dumps({"error": "action must be 'start', 'stop', or 'status'"}, ensure_ascii=False)

    try:
        if action == "stop":
            session_id = args.get("session_id", "").strip()
            if not session_id:
                return json.dumps({"error": "session_id is required for stop"}, ensure_ascii=False)
            from tools.process_registry import process_registry
            process_registry.kill(session_id)
            return json.dumps({"status": "stopped", "session_id": session_id}, ensure_ascii=False)

        slug = args.get("slug", "").strip()
        if not slug:
            return json.dumps({"error": "slug is required for start/status"}, ensure_ascii=False)

        game_dir, err = _resolve_game_dir(slug)
        if err:
            return json.dumps({"error": err}, ensure_ascii=False)

        if action == "status":
            from tools.process_registry import process_registry
            running = []
            with process_registry._lock:
                for sid, session in process_registry._running.items():
                    if slug in session.command and not session.exited:
                        running.append({
                            "session_id": sid,
                            "command": session.command,
                            "pid": session.pid,
                            "uptime_seconds": int(time.time() - session.started_at),
                        })
            return json.dumps({
                "slug": slug,
                "running": running,
                "count": len(running),
            }, ensure_ascii=False)

        # action == "start"
        port = args.get("port", 5173)

        # Install dependencies if needed
        if not (game_dir / "node_modules").exists():
            result = subprocess.run(
                ["npm", "install"],
                cwd=str(game_dir),
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                return json.dumps({
                    "error": "npm install failed",
                    "stderr": result.stderr[:2000],
                }, ensure_ascii=False)

        # Spawn dev server via process registry
        from tools.process_registry import process_registry
        task_id = kw.get("task_id", "")
        command = f"npx vite --port {port} --host 0.0.0.0"
        session = process_registry.spawn_local(
            command=command,
            cwd=str(game_dir),
            task_id=task_id,
        )

        # Wait briefly for server to start
        time.sleep(2)

        return json.dumps({
            "status": "started",
            "url": f"http://localhost:{port}",
            "session_id": session.id,
            "slug": slug,
            "game_dir": str(game_dir),
            "message": f"Dev server running at http://localhost:{port} — session_id: {session.id}",
        }, ensure_ascii=False)

    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


GAME_PREVIEW_SCHEMA = {
    "name": "game_preview",
    "description": (
        "Start or stop a local Vite dev server to preview a game in the browser. "
        "Actions:\n"
        "- 'start': Install deps (if needed) and launch dev server. Returns URL and session_id.\n"
        "- 'stop': Stop a running preview by session_id.\n"
        "- 'status': Check if a preview is running for a game.\n\n"
        "The dev server runs in the background. Use the process tool to check logs."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["start", "stop", "status"],
                "description": "Action to perform",
            },
            "slug": {
                "type": "string",
                "description": "Game slug (required for 'start' and 'status')",
            },
            "port": {
                "type": "integer",
                "description": "Port for dev server (default: 5173)",
                "default": 5173,
            },
            "session_id": {
                "type": "string",
                "description": "Process session ID (required for 'stop')",
            },
        },
        "required": ["action"],
    },
}


# =========================================================================
# Tool 5: game_push
# =========================================================================

def handle_game_push(args: dict, **kw) -> str:
    """Build and deploy a game to the EAISports platform."""
    slug = args.get("slug", "").strip()
    if not slug:
        return json.dumps({"error": "slug is required"}, ensure_ascii=False)

    skip_verify = args.get("skip_verify", False)

    try:
        from eaisports_cli.config import load_config
        from eaisports_cli.push import _verify_build, _create_bundle, DEFAULT_API_URL

        game_dir, err = _resolve_game_dir(slug)
        if err:
            return json.dumps({"error": err}, ensure_ascii=False)

        # Check wallet
        config = load_config()
        wallet_address = config.get("wallet_address")
        if not wallet_address:
            return json.dumps({
                "error": "No wallet configured. Run 'eaisports init' to set up your wallet address.",
            }, ensure_ascii=False)

        # Build
        build_result = subprocess.run(
            ["npm", "run", "build"],
            cwd=str(game_dir),
            capture_output=True,
            text=True,
            timeout=120,
        )
        if build_result.returncode != 0:
            return json.dumps({
                "error": "Build failed",
                "stderr": build_result.stderr[:2000],
            }, ensure_ascii=False)

        # Verify
        if not skip_verify:
            errors, warnings = _verify_build(game_dir)
            if errors:
                return json.dumps({
                    "error": "Pre-push verification failed",
                    "errors": errors,
                    "warnings": warnings,
                }, ensure_ascii=False)

        # Bundle
        try:
            bundle_path = _create_bundle(game_dir)
        except FileNotFoundError:
            return json.dumps({"error": "No dist/ directory — build may have failed"}, ensure_ascii=False)

        # Upload
        import requests

        api_url = config.get("api_url", DEFAULT_API_URL)
        deploy_url = f"{api_url}/api/games/deploy"

        try:
            with open(bundle_path, "rb") as bundle_file:
                resp = requests.post(
                    deploy_url,
                    headers={"X-Wallet-Address": wallet_address},
                    files={"bundle": ("bundle.tar.gz", bundle_file, "application/gzip")},
                    data={"slug": slug, "wallet_address": wallet_address},
                    timeout=120,
                )

            if resp.status_code == 200:
                data = resp.json()
                live_url = data.get("url", f"https://eaisports.ai/games/{slug}")
                tokens = data.get("tokens_earned", 0)

                # Best-effort icon generation
                try:
                    requests.post(
                        f"{api_url}/api/games/{slug}/generate-icon",
                        headers={"X-Wallet-Address": wallet_address},
                        timeout=60,
                    )
                except Exception:
                    pass

                return json.dumps({
                    "status": "deployed",
                    "live_url": live_url,
                    "tokens_earned": tokens,
                    "slug": slug,
                }, ensure_ascii=False)
            else:
                error_msg = ""
                try:
                    error_msg = resp.json().get("error", resp.text)
                except Exception:
                    error_msg = resp.text
                return json.dumps({
                    "error": f"Deploy failed ({resp.status_code}): {error_msg}",
                }, ensure_ascii=False)

        except requests.ConnectionError:
            return json.dumps({"error": "Could not reach the EAISports API. Check your connection."}, ensure_ascii=False)
        except requests.Timeout:
            return json.dumps({"error": "Request timed out. Try again later."}, ensure_ascii=False)
        except requests.RequestException as exc:
            return json.dumps({"error": f"Network error: {exc}"}, ensure_ascii=False)
        finally:
            try:
                bundle_path.unlink(missing_ok=True)
            except OSError:
                pass

    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


GAME_PUSH_SCHEMA = {
    "name": "game_push",
    "description": (
        "Build and deploy a game to the EAISports platform. "
        "Runs 'npm run build', verifies the output, bundles it, and uploads "
        "to the EAISports deploy API. Requires a configured wallet address "
        "(from 'eaisports init').\n\n"
        "Returns the live URL on success."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "slug": {
                "type": "string",
                "description": "Game slug to deploy",
            },
            "skip_verify": {
                "type": "boolean",
                "description": "Skip pre-push build verification checks (default: false)",
                "default": False,
            },
        },
        "required": ["slug"],
    },
}


# =========================================================================
# Check function (shared)
# =========================================================================

def check_eaisports_requirements() -> bool:
    """EAISports game tools are always available — they're sandboxed by design."""
    return True


# =========================================================================
# Registry
# =========================================================================

from tools.registry import registry

registry.register(
    name="game_list",
    toolset="eaisports",
    schema=GAME_LIST_SCHEMA,
    handler=handle_game_list,
    check_fn=check_eaisports_requirements,
)

registry.register(
    name="game_info",
    toolset="eaisports",
    schema=GAME_INFO_SCHEMA,
    handler=handle_game_info,
    check_fn=check_eaisports_requirements,
)

registry.register(
    name="game_build",
    toolset="eaisports",
    schema=GAME_BUILD_SCHEMA,
    handler=handle_game_build,
    check_fn=check_eaisports_requirements,
)

registry.register(
    name="game_preview",
    toolset="eaisports",
    schema=GAME_PREVIEW_SCHEMA,
    handler=handle_game_preview,
    check_fn=check_eaisports_requirements,
)

registry.register(
    name="game_push",
    toolset="eaisports",
    schema=GAME_PUSH_SCHEMA,
    handler=handle_game_push,
    check_fn=check_eaisports_requirements,
)
