"""Build-specific system prompt for the EAISports game builder agent.

Constructs the system prompt used during `eaisports build` sessions.
The prompt gives the agent identity, context about the target game
directory, React/Vite conventions, and optionally injects a skill's
SKILL.md + template listing so the agent can follow a known pattern.

Usage:
    from agent.build_prompt import build_game_prompt, GAME_BUILD_IDENTITY

    prompt = build_game_prompt(slug="trivia-quest", game_dir="/path/to/game")
"""

import logging
import os
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# =========================================================================
# Constants
# =========================================================================

GAME_BUILD_IDENTITY = (
    "You are EAISports Build Agent, a specialized AI for creating browser-based "
    "games using React and Vite. You write clean, functional React components, "
    "produce polished game UIs, and ensure every game you build is immediately "
    "playable in a browser via `npm run dev`."
)


# =========================================================================
# Skill loader
# =========================================================================

def _load_skill_context(skill_name: str) -> str:
    """Load a skill's SKILL.md and list its template files.

    Returns a formatted string to inject into the system prompt, or an
    empty string if the skill cannot be found.
    """
    eaisports_home = Path(os.getenv("EAISPORTS_HOME", Path.home() / ".eaisports"))
    skill_dir = eaisports_home / "skills" / skill_name

    if not skill_dir.exists():
        logger.warning("Skill directory not found: %s", skill_dir)
        return ""

    parts: list[str] = []

    # Read SKILL.md
    skill_md = skill_dir / "SKILL.md"
    if skill_md.exists():
        try:
            content = skill_md.read_text(encoding="utf-8")
            parts.append(f"## Skill: {skill_name}\n\n{content}")
        except Exception as exc:
            logger.warning("Failed to read %s: %s", skill_md, exc)

    # List template files
    templates_dir = skill_dir / "templates"
    if templates_dir.exists():
        template_files = sorted(
            p.relative_to(templates_dir)
            for p in templates_dir.rglob("*")
            if p.is_file()
        )
        if template_files:
            listing = "\n".join(f"  - {f}" for f in template_files)
            parts.append(f"### Available Templates\n{listing}")

    return "\n\n".join(parts)


# =========================================================================
# Prompt builder
# =========================================================================

def build_game_prompt(
    slug: str,
    game_dir: str,
    skill_name: Optional[str] = None,
    description: Optional[str] = None,
) -> str:
    """Build the full system prompt for a game-building session.

    Parameters
    ----------
    slug:
        URL-safe game identifier (e.g. ``"trivia-quest"``).
    game_dir:
        Absolute path to the game's output directory.
    skill_name:
        Optional skill to pre-load (e.g. ``"trivia"``).
    description:
        Optional free-text description of the game the creator wants.

    Returns
    -------
    str
        The assembled system prompt string.
    """
    sections: list[str] = []

    # -- Identity
    sections.append(GAME_BUILD_IDENTITY)

    # -- Context
    sections.append(
        f"## Build Context\n"
        f"- Game slug: `{slug}`\n"
        f"- Output directory: `{game_dir}`\n"
        f"- Stack: React 18 + Vite 5 (already scaffolded)\n"
        f"- The project has been scaffolded with a basic React+Vite setup. "
        f"All source files live under `{game_dir}/src/`."
    )

    # -- Creator's vision (when description provided)
    if description:
        sections.append(
            f"## Creator's Vision\n"
            f"The creator described their game as: \"{description}\"\n"
            f"Use this as your primary design direction. You may ask 1-2 follow-up "
            f"questions to refine details, but do NOT ask what kind of game to build — "
            f"the creator has already told you."
        )

    # -- Instructions
    instructions: list[str] = []

    # Mandatory clarify gate when no description and no skill
    if not description and not skill_name:
        instructions.append(
            "**MANDATORY**: Before writing ANY code, you MUST use the `clarify` tool to ask "
            "the creator at least 2 questions about their game: genre/type, core mechanic, "
            "visual style, or special features. Do NOT skip this step. Do NOT guess."
        )

    instructions.extend([
        "Write all game code as **functional React components** in the `src/` directory.",
        "Use the **file tools** to create and edit files inside the game directory.",
        "Use the **terminal tool** to run `npm install` and `npm run dev` when needed.",
        "Keep styles co-located: use inline styles, CSS modules, or add rules to "
        "`src/styles/index.css`.",
        "Place reusable components in `src/components/` and data/config files in "
        "`src/data/`.",
        "Make the game **playable in the browser** at http://localhost:5173 after "
        "`npm run dev`.",
        "If the user asks for assets (images, sounds), prefer free CDN links or "
        "simple SVG/CSS art over downloading files.",
        "Build creative, original games from scratch. Skills are optional reference "
        "patterns - never copy a skill template wholesale. If the user asks for a "
        "roller coaster game, build an actual interactive game with animations and "
        "gameplay, not a dashboard or data display.",
        "After building, ask the user if they want changes. Support iterative "
        "refinement - the user may want to adjust gameplay, visuals, or difficulty.",
        "**Mobile-first**: Every game must be playable on mobile browsers. Use "
        "responsive layouts (flexbox/grid, no fixed pixel widths), touch-friendly "
        "controls (min 44px tap targets), and `100dvh` for full-screen layouts. "
        "Test at 375px wide. Never rely on hover for essential interactions.",
    ])

    numbered = "\n".join(f"{i+1}. {inst}" for i, inst in enumerate(instructions))
    sections.append(f"## Instructions\n{numbered}")

    # -- Output rules
    sections.append(
        "## Output Rules\n"
        f"- ALL files must be written inside `{game_dir}/`.\n"
        "- Use functional React components with hooks (useState, useEffect, etc.).\n"
        "- Export components as default exports.\n"
        "- Keep the entry point at `src/main.jsx` (already created).\n"
        "- The main app component is `src/App.jsx` -- update it to render your game.\n"
        "- Do NOT modify `vite.config.js` or `index.html` unless strictly necessary.\n"
        "- Prefer simple, readable code over clever abstractions."
    )

    # -- Skill context (optional)
    if skill_name:
        skill_ctx = _load_skill_context(skill_name)
        if skill_ctx:
            sections.append(skill_ctx)

    # -- Budget awareness
    sections.append(
        "## Budget\n"
        "You have a limited number of iterations for this build session. "
        "Be efficient: plan your approach before writing code, batch related "
        "file writes, and avoid unnecessary tool calls."
    )

    return "\n\n".join(sections)


def build_scaffold_prompt(
    slug: str,
    game_dir: str,
    skill_name: Optional[str] = None,
    description: Optional[str] = None,
) -> str:
    """Build the phase-1 scaffold prompt."""
    return build_game_prompt(slug=slug, game_dir=game_dir, skill_name=skill_name, description=description)


def build_polish_prompt(slug: str, game_dir: str, phase_context: str) -> str:
    """Build the system prompt for the polish phase."""
    sections: list[str] = []

    sections.append(
        "You are EAISports Polish Agent, specialized in making browser games "
        "visually polished and mobile-ready."
    )

    sections.append(
        f"## Build Context\n"
        f"- Game slug: `{slug}`\n"
        f"- Output directory: `{game_dir}`\n"
        f"- Stack: React 18 + Vite 5 (already scaffolded)\n"
        f"- The project has been scaffolded with a basic React+Vite setup. "
        f"All source files live under `{game_dir}/src/`."
    )

    sections.append(f"## Prior Phase Output\n{phase_context}")

    sections.append(
        "## Instructions\n"
        "1. Review all components and improve visual design (colors, spacing, "
        "typography, transitions).\n"
        "2. Add CSS animations/transitions for state changes (score updates, "
        "screen transitions, button presses).\n"
        "3. Ensure responsive layout works at 375px width (mobile-first).\n"
        "4. All interactive elements must have min 44px tap targets.\n"
        "5. Use `100dvh` for full-screen layouts.\n"
        "6. Improve the color palette - consistent, accessible, and appealing.\n"
        "7. Add loading states and smooth transitions between game screens.\n"
        "8. Do NOT rewrite game logic, restructure components, or change gameplay.\n"
        "9. Do NOT modify `vite.config.js` or `index.html`.\n"
        "10. Focus on making the game feel polished and professional."
    )

    sections.append(
        "## Output Rules\n"
        f"- ALL files must be written inside `{game_dir}/`.\n"
        "- Use functional React components with hooks (useState, useEffect, etc.).\n"
        "- Export components as default exports.\n"
        "- Keep the entry point at `src/main.jsx` (already created).\n"
        "- The main app component is `src/App.jsx` -- update it to render your game.\n"
        "- Do NOT modify `vite.config.js` or `index.html` unless strictly necessary.\n"
        "- Prefer simple, readable code over clever abstractions."
    )

    return "\n\n".join(sections)


def build_verify_prompt(slug: str, game_dir: str, phase_context: str) -> str:
    """Build the system prompt for the verification phase."""
    sections: list[str] = []

    sections.append(
        "You are EAISports Verify Agent, specialized in ensuring browser games "
        "build and run correctly."
    )

    sections.append(
        f"## Build Context\n"
        f"- Game slug: `{slug}`\n"
        f"- Output directory: `{game_dir}`\n"
        f"- Stack: React 18 + Vite 5 (already scaffolded)\n"
        f"- The project has been scaffolded with a basic React+Vite setup. "
        f"All source files live under `{game_dir}/src/`."
    )

    sections.append(f"## Prior Phase Output\n{phase_context}")

    sections.append(
        "## Instructions\n"
        "1. Run `npm run build` in the game directory. If it fails, fix errors.\n"
        "2. Check for import errors - ensure all imported files/modules exist.\n"
        "3. Check for undefined variable references in components.\n"
        "4. Ensure `src/App.jsx` has a valid default export.\n"
        "5. Verify the game has interactive elements (buttons, handlers, state).\n"
        "6. Fix any console errors or warnings visible in the code.\n"
        "7. Ensure all React components return valid JSX.\n"
        "8. Run `npm run build` again after fixes to confirm clean build.\n"
        "9. Do NOT add new features or change game design.\n"
        "10. Do NOT modify `vite.config.js` or `index.html` unless necessary for build."
    )

    sections.append(
        "## Output Rules\n"
        f"- ALL files must be written inside `{game_dir}/`.\n"
        "- Use functional React components with hooks (useState, useEffect, etc.).\n"
        "- Export components as default exports.\n"
        "- Keep the entry point at `src/main.jsx` (already created).\n"
        "- The main app component is `src/App.jsx` -- update it to render your game.\n"
        "- Do NOT modify `vite.config.js` or `index.html` unless strictly necessary.\n"
        "- Prefer simple, readable code over clever abstractions."
    )

    return "\n\n".join(sections)


def collect_phase_context(game_dir: str) -> str:
    """Collect the current file listing and an App.jsx excerpt for later phases."""
    game_path = Path(game_dir)
    src_dir = game_path / "src"

    file_lines: list[str] = []
    if src_dir.exists():
        for path in sorted(p for p in src_dir.rglob("*") if p.is_file()):
            try:
                size_text = f"{path.stat().st_size} bytes"
            except OSError:
                size_text = "unknown size"
            rel_path = path.relative_to(game_path).as_posix()
            file_lines.append(f"- `{rel_path}` ({size_text})")

    app_excerpt = ""
    app_path = src_dir / "App.jsx"
    if app_path.exists():
        try:
            app_excerpt = "\n".join(
                app_path.read_text(encoding="utf-8").splitlines()[:80]
            )
        except Exception as exc:
            logger.warning("Failed to read %s: %s", app_path, exc)

    files_section = "\n".join(file_lines)
    return (
        "## Current Game Files\n"
        f"{files_section}\n\n"
        "## App.jsx (first 80 lines)\n"
        f"```jsx\n{app_excerpt}\n```"
    )
