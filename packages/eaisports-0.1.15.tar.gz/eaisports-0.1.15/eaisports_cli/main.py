#!/usr/bin/env python3
"""
EAISports CLI - Main entry point.

Usage:
    eaisports                     # Interactive chat (default)
    eaisports chat                # Interactive chat
    eaisports setup               # Interactive setup wizard
    eaisports logout              # Clear stored authentication
    eaisports status              # Show status of all components
    eaisports cron                # Manage cron jobs
    eaisports cron list           # List cron jobs
    eaisports cron status         # Check if cron scheduler is running
    eaisports skills list         # List installed game skills
    eaisports skills info <name>  # Show skill details
    eaisports skills init <name>  # Create a new skill
    eaisports skills search <q>   # Search skills
    eaisports doctor              # Check configuration and dependencies
    eaisports version             # Show version
    eaisports update              # Update to latest version
    eaisports uninstall           # Uninstall EAISports
    eaisports sessions browse     # Interactive session picker with search
"""

import argparse
import os
import sys
from pathlib import Path
from typing import Optional

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

# Load .env from ~/.eaisports/.env first, then project root as dev fallback
from dotenv import load_dotenv
from eaisports_cli.config import get_env_path, get_eaisports_home
_user_env = get_env_path()
if _user_env.exists():
    try:
        load_dotenv(dotenv_path=_user_env, encoding="utf-8")
    except UnicodeDecodeError:
        load_dotenv(dotenv_path=_user_env, encoding="latin-1")
load_dotenv(dotenv_path=PROJECT_ROOT / '.env', override=False)

# Point mini-swe-agent at ~/.eaisports/ so it shares our config
os.environ.setdefault("MSWEA_GLOBAL_CONFIG_DIR", str(get_eaisports_home()))
os.environ.setdefault("MSWEA_SILENT_STARTUP", "1")

import logging

from eaisports_cli import __version__

logger = logging.getLogger(__name__)


# ── Session helpers (extracted to eaisports_cli.session_helpers) ──────────────
from eaisports_cli.session_helpers import (  # noqa: E402
    _has_any_provider_configured,
    _session_browse_picker,
    _resolve_last_cli_session,
    _resolve_session_by_name_or_id,
)


def cmd_chat(args):
    """Run interactive chat CLI."""
    # Resolve --continue into --resume with the latest CLI session or by name
    continue_val = getattr(args, "continue_last", None)
    if continue_val and not getattr(args, "resume", None):
        if isinstance(continue_val, str):
            # -c "session name" — resolve by title or ID
            resolved = _resolve_session_by_name_or_id(continue_val)
            if resolved:
                args.resume = resolved
            else:
                print(f"No session found matching '{continue_val}'.")
                print("Use 'eaisports sessions list' to see available sessions.")
                sys.exit(1)
        else:
            # -c with no argument — continue the most recent session
            last_id = _resolve_last_cli_session()
            if last_id:
                args.resume = last_id
            else:
                print("No previous CLI session found to continue.")
                sys.exit(1)

    # Resolve --resume by title if it's not a direct session ID
    resume_val = getattr(args, "resume", None)
    if resume_val:
        resolved = _resolve_session_by_name_or_id(resume_val)
        if resolved:
            args.resume = resolved
        # If resolution fails, keep the original value — _init_agent will
        # report "Session not found" with the original input

    # First-run guard: check if any provider is configured before launching
    if not _has_any_provider_configured():
        print()
        print("It looks like EAISports isn't configured yet -- no API keys or providers found.")
        print()
        print("  Run:  eaisports setup")
        print()
        try:
            reply = input("Run setup now? [Y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            reply = "n"
        if reply in ("", "y", "yes"):
            cmd_setup(args)
            return
        print()
        print("You can run 'eaisports setup' at any time to configure.")
        sys.exit(1)

    # Sync bundled skills on every CLI launch (fast -- skips unchanged skills)
    try:
        from tools.skills_sync import sync_skills
        sync_skills(quiet=True)
    except Exception:
        pass

    # Import and run the CLI
    from cli import main as cli_main
    
    # Build kwargs from args
    kwargs = {
        "model": args.model,
        "provider": getattr(args, "provider", None),
        "toolsets": args.toolsets,
        "verbose": args.verbose,
        "query": args.query,
        "resume": getattr(args, "resume", None),
        "worktree": getattr(args, "worktree", False),
        "checkpoints": getattr(args, "checkpoints", False),
    }
    # Filter out None values
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    
    cli_main(**kwargs)


def cmd_init(args):
    """Run the EAISports initialization wizard."""
    from eaisports_cli.init_wizard import run_init_wizard
    run_init_wizard()


def cmd_build(args):
    """Run a game build session."""
    from eaisports_cli.build import run_build_session
    run_build_session(
        slug=getattr(args, 'slug', None),
        budget=getattr(args, 'budget', None),
        resume_slug=getattr(args, 'resume', None),
        skill_name=getattr(args, 'skill', None),
        model=getattr(args, 'model', None),
        phases=not getattr(args, 'no_phases', False),
        cost_limit=getattr(args, 'cost_limit', None),
        description=getattr(args, 'description', None),
    )


def cmd_preview(args):
    """Preview a built game in the browser."""
    from eaisports_cli.preview import run_preview
    run_preview(
        slug=getattr(args, 'slug', None),
        port=getattr(args, 'port', 5173),
    )


def cmd_push(args):
    """Push a game to the EAISports platform."""
    from eaisports_cli.push import run_push
    run_push(
        slug=getattr(args, 'slug', None),
        skip_verify=getattr(args, 'skip_verify', False),
    )


def cmd_stats(args):
    """Show creator statistics."""
    from eaisports_cli.stats import run_stats
    run_stats()


def cmd_setup(args):
    """Interactive setup wizard."""
    from eaisports_cli.setup import run_setup_wizard
    run_setup_wizard(args)


# ── Provider setup (extracted to eaisports_cli.provider_setup) ───────────────
from eaisports_cli.provider_setup import (  # noqa: E402
    cmd_model,
    _prompt_provider_choice,
    _model_flow_openrouter,
    _model_flow_nous,
    _model_flow_openai_codex,
    _model_flow_custom,
    _save_custom_provider,
    _remove_custom_provider,
    _model_flow_named_custom,
    _model_flow_api_key_provider,
    _PROVIDER_MODELS,
)


def cmd_login(args):
    """Authenticate EAISports CLI with a provider."""
    from eaisports_cli.auth import login_command
    login_command(args)


def cmd_logout(args):
    """Clear provider authentication."""
    from eaisports_cli.auth import logout_command
    logout_command(args)


def cmd_status(args):
    """Show status of all components."""
    from eaisports_cli.status import show_status
    show_status(args)


def cmd_cron(args):
    """Cron job management."""
    from eaisports_cli.cron import cron_command
    cron_command(args)


def cmd_doctor(args):
    """Check configuration and dependencies."""
    from eaisports_cli.doctor import run_doctor
    run_doctor(args)


def cmd_config(args):
    """Configuration management."""
    from eaisports_cli.config import config_command
    config_command(args)


def cmd_version(args):
    """Show version."""
    print(f"EAISports v{__version__}")
    print(f"Project: {PROJECT_ROOT}")
    
    # Show Python version
    print(f"Python: {sys.version.split()[0]}")
    
    # Check for key dependencies
    try:
        import openai
        print(f"OpenAI SDK: {openai.__version__}")
    except ImportError:
        print("OpenAI SDK: Not installed")


def cmd_uninstall(args):
    """Uninstall EAISports."""
    from eaisports_cli.uninstall import run_uninstall
    run_uninstall(args)


# ── Update commands (extracted to eaisports_cli.update) ──────────────────────
from eaisports_cli.update import (  # noqa: E402
    _update_via_zip,
    _update_via_pip,
    cmd_update,
)


def _coalesce_session_name_args(argv: list) -> list:
    """Join unquoted multi-word session names after -c/--continue and -r/--resume.

    When a user types ``eaisports -c Pokemon Agent Dev`` without quoting the
    session name, argparse sees three separate tokens.  This function merges
    them into a single argument so argparse receives
    ``['-c', 'Pokemon Agent Dev']`` instead.

    Tokens are collected after the flag until we hit another flag (``-*``)
    or a known top-level subcommand.
    """
    _SUBCOMMANDS = {
        "chat", "model", "setup", "login", "logout",
        "status", "cron", "doctor", "config", "skills", "tools",
        "sessions", "insights", "version", "update", "uninstall",
    }
    _SESSION_FLAGS = {"-c", "--continue", "-r", "--resume"}

    result = []
    i = 0
    while i < len(argv):
        token = argv[i]
        if token in _SESSION_FLAGS:
            result.append(token)
            i += 1
            # Collect subsequent non-flag, non-subcommand tokens as one name
            parts: list = []
            while i < len(argv) and not argv[i].startswith("-") and argv[i] not in _SUBCOMMANDS:
                parts.append(argv[i])
                i += 1
            if parts:
                result.append(" ".join(parts))
        else:
            result.append(token)
            i += 1
    return result


def main():
    """Main entry point for eaisports CLI."""
    parser = argparse.ArgumentParser(
        prog="eaisports",
        description="EAISports - AI-Powered Game Builder",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Core commands:
    eaisports init                   Set up your environment
    eaisports build my-game          Build a new game
    eaisports build -d 'space game'  Build with a description
    eaisports preview my-game        Preview in browser
    eaisports push my-game           Deploy to eaisports.ai
    eaisports stats                  Show creator statistics

Configuration:
    eaisports setup                  Interactive setup wizard
    eaisports model                  Select default model
    eaisports config                 View and edit configuration
    eaisports login / logout         Manage authentication

Advanced:
    eaisports chat                   Interactive chat with the agent
    eaisports skills list            Browse game skills
    eaisports sessions browse        Manage session history
    eaisports doctor                 Check configuration
    eaisports insights               Show usage analytics

For more help on a command:
    eaisports <command> --help
"""
    )
    
    parser.add_argument(
        "--version", "-V",
        action="store_true",
        help="Show version and exit"
    )
    parser.add_argument(
        "--resume", "-r",
        metavar="SESSION",
        default=None,
        help="Resume a previous session by ID or title"
    )
    parser.add_argument(
        "--continue", "-c",
        dest="continue_last",
        nargs="?",
        const=True,
        default=None,
        metavar="SESSION_NAME",
        help="Resume a session by name, or the most recent if no name given"
    )
    parser.add_argument(
        "--worktree", "-w",
        action="store_true",
        default=False,
        help="Run in an isolated git worktree (for parallel agents)"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # =========================================================================
    # chat command
    # =========================================================================
    chat_parser = subparsers.add_parser(
        "chat",
        help="Interactive chat with the agent",
        description="Start an interactive chat session with EAISports"
    )
    chat_parser.add_argument(
        "-q", "--query",
        help="Single query (non-interactive mode)"
    )
    chat_parser.add_argument(
        "-m", "--model",
        help="Model to use (e.g., anthropic/claude-sonnet-4)"
    )
    chat_parser.add_argument(
        "-t", "--toolsets",
        help="Comma-separated toolsets to enable"
    )
    chat_parser.add_argument(
        "--provider",
        choices=["auto", "openrouter", "nous", "openai-codex", "zai", "kimi-coding", "minimax", "minimax-cn"],
        default=None,
        help="Inference provider (default: auto)"
    )
    chat_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output"
    )
    chat_parser.add_argument(
        "--resume", "-r",
        metavar="SESSION_ID",
        help="Resume a previous session by ID (shown on exit)"
    )
    chat_parser.add_argument(
        "--continue", "-c",
        dest="continue_last",
        nargs="?",
        const=True,
        default=None,
        metavar="SESSION_NAME",
        help="Resume a session by name, or the most recent if no name given"
    )
    chat_parser.add_argument(
        "--worktree", "-w",
        action="store_true",
        default=False,
        help="Run in an isolated git worktree (for parallel agents on the same repo)"
    )
    chat_parser.add_argument(
        "--checkpoints",
        action="store_true",
        default=False,
        help="Enable filesystem checkpoints before destructive file operations (use /rollback to restore)"
    )
    chat_parser.set_defaults(func=cmd_chat)

    # =========================================================================
    # model command
    # =========================================================================
    model_parser = subparsers.add_parser(
        "model",
        help="Select default model and provider",
        description="Interactively select your inference provider and default model"
    )
    model_parser.set_defaults(func=cmd_model)

    # =========================================================================
    # init command
    # =========================================================================
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize EAISports for first-time setup",
        description="Run the EAISports initialization wizard — sets up API keys, "
                    "models, wallet, and workspace."
    )
    init_parser.set_defaults(func=cmd_init)

    # =========================================================================
    # build command
    # =========================================================================
    build_parser = subparsers.add_parser(
        "build",
        help="Start a game build session",
        description="Launch an AI-powered game building session. The agent will "
                    "create a React+Vite game in ~/.eaisports/games/{slug}/."
    )
    build_parser.add_argument(
        "slug",
        nargs="?",
        default=None,
        help="Game slug (directory name). Auto-generated if not provided."
    )
    build_parser.add_argument(
        "--budget", "-b",
        type=int,
        default=None,
        help="Max iterations for the build session (default: from config or 50)"
    )
    build_parser.add_argument(
        "--resume", "-r",
        default=None,
        metavar="SLUG",
        help="Resume a previous build session by slug"
    )
    build_parser.add_argument(
        "--skill", "-s",
        default=None,
        help="Start with a specific skill (e.g., trivia, interactive-fiction)"
    )
    build_parser.add_argument(
        "--model", "-m",
        default=None,
        help="Override the model for this build session"
    )
    build_parser.add_argument(
        "--cost-limit",
        type=float,
        default=None,
        help="Max build cost in dollars"
    )
    build_parser.add_argument(
        "--no-phases",
        action="store_true",
        help="Single conversation mode"
    )
    build_parser.add_argument(
        "--description", "-d",
        default=None,
        help="Describe your game idea (e.g., -d 'a space shooter with power-ups')"
    )
    build_parser.set_defaults(func=cmd_build)

    # =========================================================================
    # preview command
    # =========================================================================
    preview_parser = subparsers.add_parser(
        "preview",
        help="Preview a built game locally",
        description="Launch a local Vite dev server to preview a game in the browser."
    )
    preview_parser.add_argument(
        "slug",
        nargs="?",
        default=None,
        help="Game slug to preview. Shows picker if not provided."
    )
    preview_parser.add_argument(
        "--port", "-p",
        type=int,
        default=5173,
        help="Port for the Vite dev server (default: 5173)"
    )
    preview_parser.set_defaults(func=cmd_preview)

    # =========================================================================
    # push command
    # =========================================================================
    push_parser = subparsers.add_parser(
        "push",
        help="Deploy a game to eaisports.ai",
        description="Bundle and deploy a built game to the EAISports platform."
    )
    push_parser.add_argument(
        "slug",
        nargs="?",
        default=None,
        help="Game slug to deploy"
    )
    push_parser.add_argument(
        "--skip-verify",
        action="store_true",
        help="Skip pre-push verification"
    )
    push_parser.set_defaults(func=cmd_push)

    # =========================================================================
    # stats command
    # =========================================================================
    stats_parser = subparsers.add_parser(
        "stats",
        help="Show your creator statistics",
        description="Display your published games, visitor counts, and token balance."
    )
    stats_parser.set_defaults(func=cmd_stats)

    # =========================================================================
    # setup command
    # =========================================================================
    setup_parser = subparsers.add_parser(
        "setup",
        help="Interactive setup wizard",
        description="Configure EAISports with an interactive wizard. "
                    "Run a specific section: eaisports setup model|terminal|tools|agent"
    )
    setup_parser.add_argument(
        "section",
        nargs="?",
        choices=["model", "terminal", "tools", "agent"],
        default=None,
        help="Run a specific setup section instead of the full wizard"
    )
    setup_parser.add_argument(
        "--non-interactive",
        action="store_true",
        help="Non-interactive mode (use defaults/env vars)"
    )
    setup_parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset configuration to defaults"
    )
    setup_parser.set_defaults(func=cmd_setup)

    # =========================================================================
    # login command
    # =========================================================================
    login_parser = subparsers.add_parser(
        "login",
        help="Authenticate with an inference provider",
        description="Run OAuth device authorization flow for EAISports CLI"
    )
    login_parser.add_argument(
        "--provider",
        choices=["nous", "openai-codex"],
        default=None,
        help="Provider to authenticate with (default: nous)"
    )
    login_parser.add_argument(
        "--portal-url",
        help="Portal base URL (default: production portal)"
    )
    login_parser.add_argument(
        "--inference-url",
        help="Inference API base URL (default: production inference API)"
    )
    login_parser.add_argument(
        "--client-id",
        default=None,
        help="OAuth client id to use (default: eaisports-cli)"
    )
    login_parser.add_argument(
        "--scope",
        default=None,
        help="OAuth scope to request"
    )
    login_parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not attempt to open the browser automatically"
    )
    login_parser.add_argument(
        "--timeout",
        type=float,
        default=15.0,
        help="HTTP request timeout in seconds (default: 15)"
    )
    login_parser.add_argument(
        "--ca-bundle",
        help="Path to CA bundle PEM file for TLS verification"
    )
    login_parser.add_argument(
        "--insecure",
        action="store_true",
        help="Disable TLS verification (testing only)"
    )
    login_parser.set_defaults(func=cmd_login)

    # =========================================================================
    # logout command
    # =========================================================================
    logout_parser = subparsers.add_parser(
        "logout",
        help="Clear authentication for an inference provider",
        description="Remove stored credentials and reset provider config"
    )
    logout_parser.add_argument(
        "--provider",
        choices=["nous", "openai-codex"],
        default=None,
        help="Provider to log out from (default: active provider)"
    )
    logout_parser.set_defaults(func=cmd_logout)

    # =========================================================================
    # status command
    # =========================================================================
    status_parser = subparsers.add_parser(
        "status",
        help="Show status of all components",
        description="Display status of EAISports components"
    )
    status_parser.add_argument(
        "--all",
        action="store_true",
        help="Show all details (redacted for sharing)"
    )
    status_parser.add_argument(
        "--deep",
        action="store_true",
        help="Run deep checks (may take longer)"
    )
    status_parser.set_defaults(func=cmd_status)
    
    # =========================================================================
    # cron command
    # =========================================================================
    cron_parser = subparsers.add_parser(
        "cron",
        help="Cron job management",
        description="Manage scheduled tasks"
    )
    cron_subparsers = cron_parser.add_subparsers(dest="cron_command")
    
    # cron list
    cron_list = cron_subparsers.add_parser("list", help="List scheduled jobs")
    cron_list.add_argument("--all", action="store_true", help="Include disabled jobs")
    
    # cron status
    cron_subparsers.add_parser("status", help="Check if cron scheduler is running")
    
    # cron tick (mostly for debugging)
    cron_subparsers.add_parser("tick", help="Run due jobs once and exit")
    
    cron_parser.set_defaults(func=cmd_cron)
    
    # =========================================================================
    # doctor command
    # =========================================================================
    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Check configuration and dependencies",
        description="Diagnose issues with EAISports setup"
    )
    doctor_parser.add_argument(
        "--fix",
        action="store_true",
        help="Attempt to fix issues automatically"
    )
    doctor_parser.set_defaults(func=cmd_doctor)
    
    # =========================================================================
    # config command
    # =========================================================================
    config_parser = subparsers.add_parser(
        "config",
        help="View and edit configuration",
        description="Manage EAISports configuration"
    )
    config_subparsers = config_parser.add_subparsers(dest="config_command")
    
    # config show (default)
    config_show = config_subparsers.add_parser("show", help="Show current configuration")
    
    # config edit
    config_edit = config_subparsers.add_parser("edit", help="Open config file in editor")
    
    # config set
    config_set = config_subparsers.add_parser("set", help="Set a configuration value")
    config_set.add_argument("key", nargs="?", help="Configuration key (e.g., model, terminal.backend)")
    config_set.add_argument("value", nargs="?", help="Value to set")
    
    # config path
    config_path = config_subparsers.add_parser("path", help="Print config file path")
    
    # config env-path
    config_env = config_subparsers.add_parser("env-path", help="Print .env file path")
    
    # config check
    config_check = config_subparsers.add_parser("check", help="Check for missing/outdated config")
    
    # config migrate
    config_migrate = config_subparsers.add_parser("migrate", help="Update config with new options")
    
    config_parser.set_defaults(func=cmd_config)
    
    # =========================================================================
    # skills command
    # =========================================================================
    skills_parser = subparsers.add_parser(
        "skills",
        help="Manage game skills — list, view, search, create, and install",
        description="List, view, search, and create game skills. Also install from online registries."
    )
    skills_subparsers = skills_parser.add_subparsers(dest="skills_action")

    skills_browse = skills_subparsers.add_parser("browse", help="Browse all available skills (paginated)")
    skills_browse.add_argument("--page", type=int, default=1, help="Page number (default: 1)")
    skills_browse.add_argument("--size", type=int, default=20, help="Results per page (default: 20)")
    skills_browse.add_argument("--source", default="all",
                               choices=["all", "official", "github", "clawhub", "lobehub"],
                               help="Filter by source (default: all)")

    skills_search = skills_subparsers.add_parser("search", help="Search skill registries")
    skills_search.add_argument("query", help="Search query")
    skills_search.add_argument("--source", default="all", choices=["all", "official", "github", "clawhub", "lobehub"])
    skills_search.add_argument("--limit", type=int, default=10, help="Max results")

    skills_install = skills_subparsers.add_parser("install", help="Install a skill")
    skills_install.add_argument("identifier", help="Skill identifier (e.g. openai/skills/skill-creator)")
    skills_install.add_argument("--category", default="", help="Category folder to install into")
    skills_install.add_argument("--force", action="store_true", help="Install despite caution verdict")

    skills_inspect = skills_subparsers.add_parser("inspect", help="Preview a skill without installing")
    skills_inspect.add_argument("identifier", help="Skill identifier")

    skills_list = skills_subparsers.add_parser("list", help="List installed skills")
    skills_list.add_argument("--source", default="all", choices=["all", "hub", "builtin"])
    skills_list.add_argument("--category", "-c", default=None, help="Filter by category")
    skills_list.add_argument("--verbose", "-v", action="store_true", help="Show detailed info")

    skills_info_p = skills_subparsers.add_parser("info", help="Show detailed skill info")
    skills_info_p.add_argument("name", help="Skill name")

    skills_init_p = skills_subparsers.add_parser("init", help="Create a new skill")
    skills_init_p.add_argument("name", help="Name for the new skill")

    skills_audit = skills_subparsers.add_parser("audit", help="Re-scan installed hub skills")
    skills_audit.add_argument("name", nargs="?", help="Specific skill to audit (default: all)")

    skills_uninstall = skills_subparsers.add_parser("uninstall", help="Remove a hub-installed skill")
    skills_uninstall.add_argument("name", help="Skill name to remove")

    skills_publish = skills_subparsers.add_parser("publish", help="Publish a skill to a registry")
    skills_publish.add_argument("skill_path", help="Path to skill directory")
    skills_publish.add_argument("--to", default="github", choices=["github", "clawhub"], help="Target registry")
    skills_publish.add_argument("--repo", default="", help="Target GitHub repo (e.g. openai/skills)")

    skills_snapshot = skills_subparsers.add_parser("snapshot", help="Export/import skill configurations")
    snapshot_subparsers = skills_snapshot.add_subparsers(dest="snapshot_action")
    snap_export = snapshot_subparsers.add_parser("export", help="Export installed skills to a file")
    snap_export.add_argument("output", help="Output JSON file path")
    snap_import = snapshot_subparsers.add_parser("import", help="Import and install skills from a file")
    snap_import.add_argument("input", help="Input JSON file path")
    snap_import.add_argument("--force", action="store_true", help="Force install despite caution verdict")

    skills_tap = skills_subparsers.add_parser("tap", help="Manage skill sources")
    tap_subparsers = skills_tap.add_subparsers(dest="tap_action")
    tap_subparsers.add_parser("list", help="List configured taps")
    tap_add = tap_subparsers.add_parser("add", help="Add a GitHub repo as skill source")
    tap_add.add_argument("repo", help="GitHub repo (e.g. owner/repo)")
    tap_rm = tap_subparsers.add_parser("remove", help="Remove a tap")
    tap_rm.add_argument("name", help="Tap name to remove")

    def cmd_skills(args):
        """Manage game skills."""
        action = getattr(args, "skills_action", None)
        # Route local skill commands to skills_cli
        if action in ("info", "init"):
            from eaisports_cli.skills_cli import skills_command as local_skills_command
            # Map skills_action -> skills_command for the dispatcher
            args.skills_command = action
            local_skills_command(args)
        elif action == "list" and (getattr(args, "category", None) or getattr(args, "verbose", False)):
            # Enhanced local list with --category or --verbose
            from eaisports_cli.skills_cli import skills_list
            skills_list(
                category=getattr(args, "category", None),
                verbose=getattr(args, "verbose", False),
            )
        elif action == "search" and getattr(args, "source", "all") == "all":
            # When no --source filter, also search local skills
            from eaisports_cli.skills_cli import skills_search as local_search
            local_search(args.query)
        else:
            from eaisports_cli.skills_hub import skills_command
            skills_command(args)

    skills_parser.set_defaults(func=cmd_skills)

    # =========================================================================
    # tools command
    # =========================================================================
    tools_parser = subparsers.add_parser(
        "tools",
        help="Configure which tools are enabled per platform",
        description="Interactive tool configuration — enable/disable tools for CLI"
    )

    def cmd_tools(args):
        from eaisports_cli.tools_config import tools_command
        tools_command(args)

    tools_parser.set_defaults(func=cmd_tools)

    # =========================================================================
    # sessions command
    # =========================================================================
    sessions_parser = subparsers.add_parser(
        "sessions",
        help="Manage session history (list, rename, export, prune, delete)",
        description="View and manage the SQLite session store"
    )
    sessions_subparsers = sessions_parser.add_subparsers(dest="sessions_action")

    sessions_list = sessions_subparsers.add_parser("list", help="List recent sessions")
    sessions_list.add_argument("--source", help="Filter by source (e.g. cli)")
    sessions_list.add_argument("--limit", type=int, default=20, help="Max sessions to show")

    sessions_export = sessions_subparsers.add_parser("export", help="Export sessions to a JSONL file")
    sessions_export.add_argument("output", help="Output JSONL file path")
    sessions_export.add_argument("--source", help="Filter by source")
    sessions_export.add_argument("--session-id", help="Export a specific session")

    sessions_delete = sessions_subparsers.add_parser("delete", help="Delete a specific session")
    sessions_delete.add_argument("session_id", help="Session ID to delete")
    sessions_delete.add_argument("--yes", "-y", action="store_true", help="Skip confirmation")

    sessions_prune = sessions_subparsers.add_parser("prune", help="Delete old sessions")
    sessions_prune.add_argument("--older-than", type=int, default=90, help="Delete sessions older than N days (default: 90)")
    sessions_prune.add_argument("--source", help="Only prune sessions from this source")
    sessions_prune.add_argument("--yes", "-y", action="store_true", help="Skip confirmation")

    sessions_stats = sessions_subparsers.add_parser("stats", help="Show session store statistics")

    sessions_rename = sessions_subparsers.add_parser("rename", help="Set or change a session's title")
    sessions_rename.add_argument("session_id", help="Session ID to rename")
    sessions_rename.add_argument("title", nargs="+", help="New title for the session")

    sessions_browse = sessions_subparsers.add_parser(
        "browse",
        help="Interactive session picker — browse, search, and resume sessions",
    )
    sessions_browse.add_argument("--source", help="Filter by source (e.g. cli)")
    sessions_browse.add_argument("--limit", type=int, default=50, help="Max sessions to load (default: 50)")

    def cmd_sessions(args):
        import json as _json
        try:
            from eaisports_state import SessionDB
            db = SessionDB()
        except Exception as e:
            print(f"Error: Could not open session database: {e}")
            return

        action = args.sessions_action

        if action == "list":
            sessions = db.list_sessions_rich(source=args.source, limit=args.limit)
            if not sessions:
                print("No sessions found.")
                return
            from datetime import datetime
            import time as _time

            def _relative_time(ts):
                """Format a timestamp as relative time (e.g., '2h ago', 'yesterday')."""
                if not ts:
                    return "?"
                delta = _time.time() - ts
                if delta < 60:
                    return "just now"
                elif delta < 3600:
                    mins = int(delta / 60)
                    return f"{mins}m ago"
                elif delta < 86400:
                    hours = int(delta / 3600)
                    return f"{hours}h ago"
                elif delta < 172800:
                    return "yesterday"
                elif delta < 604800:
                    days = int(delta / 86400)
                    return f"{days}d ago"
                else:
                    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")

            has_titles = any(s.get("title") for s in sessions)
            if has_titles:
                print(f"{'Title':<22} {'Preview':<40} {'Last Active':<13} {'ID'}")
                print("─" * 100)
            else:
                print(f"{'Preview':<50} {'Last Active':<13} {'Src':<6} {'ID'}")
                print("─" * 90)
            for s in sessions:
                last_active = _relative_time(s.get("last_active"))
                preview = s.get("preview", "")[:38] if has_titles else s.get("preview", "")[:48]
                if has_titles:
                    title = (s.get("title") or "—")[:20]
                    sid = s["id"][:20]
                    print(f"{title:<22} {preview:<40} {last_active:<13} {sid}")
                else:
                    sid = s["id"][:20]
                    print(f"{preview:<50} {last_active:<13} {s['source']:<6} {sid}")

        elif action == "export":
            if args.session_id:
                data = db.export_session(args.session_id)
                if not data:
                    print(f"Session '{args.session_id}' not found.")
                    return
                with open(args.output, "w", encoding="utf-8") as f:
                    f.write(_json.dumps(data, ensure_ascii=False) + "\n")
                print(f"Exported 1 session to {args.output}")
            else:
                sessions = db.export_all(source=args.source)
                with open(args.output, "w", encoding="utf-8") as f:
                    for s in sessions:
                        f.write(_json.dumps(s, ensure_ascii=False) + "\n")
                print(f"Exported {len(sessions)} sessions to {args.output}")

        elif action == "delete":
            if not args.yes:
                confirm = input(f"Delete session '{args.session_id}' and all its messages? [y/N] ")
                if confirm.lower() not in ("y", "yes"):
                    print("Cancelled.")
                    return
            if db.delete_session(args.session_id):
                print(f"Deleted session '{args.session_id}'.")
            else:
                print(f"Session '{args.session_id}' not found.")

        elif action == "prune":
            days = args.older_than
            source_msg = f" from '{args.source}'" if args.source else ""
            if not args.yes:
                confirm = input(f"Delete all ended sessions older than {days} days{source_msg}? [y/N] ")
                if confirm.lower() not in ("y", "yes"):
                    print("Cancelled.")
                    return
            count = db.prune_sessions(older_than_days=days, source=args.source)
            print(f"Pruned {count} session(s).")

        elif action == "rename":
            title = " ".join(args.title)
            try:
                if db.set_session_title(args.session_id, title):
                    print(f"Session '{args.session_id}' renamed to: {title}")
                else:
                    print(f"Session '{args.session_id}' not found.")
            except ValueError as e:
                print(f"Error: {e}")

        elif action == "browse":
            limit = getattr(args, "limit", 50) or 50
            source = getattr(args, "source", None)
            sessions = db.list_sessions_rich(source=source, limit=limit)
            db.close()
            if not sessions:
                print("No sessions found.")
                return

            selected_id = _session_browse_picker(sessions)
            if not selected_id:
                print("Cancelled.")
                return

            # Launch eaisports --resume <id> by replacing the current process
            print(f"Resuming session: {selected_id}")
            import shutil
            eaisports_bin = shutil.which("eaisports")
            if eaisports_bin:
                os.execvp(eaisports_bin, ["eaisports", "--resume", selected_id])
            else:
                # Fallback: re-invoke via python -m
                os.execvp(
                    sys.executable,
                    [sys.executable, "-m", "eaisports_cli.main", "--resume", selected_id],
                )
            return  # won't reach here after execvp

        elif action == "stats":
            total = db.session_count()
            msgs = db.message_count()
            print(f"Total sessions: {total}")
            print(f"Total messages: {msgs}")
            for src in ["cli"]:
                c = db.session_count(source=src)
                if c > 0:
                    print(f"  {src}: {c} sessions")
            db_path = db.db_path
            if db_path.exists():
                size_mb = os.path.getsize(db_path) / (1024 * 1024)
                print(f"Database size: {size_mb:.1f} MB")

        else:
            sessions_parser.print_help()

        db.close()

    sessions_parser.set_defaults(func=cmd_sessions)

    # =========================================================================
    # insights command
    # =========================================================================
    insights_parser = subparsers.add_parser(
        "insights",
        help="Show usage insights and analytics",
        description="Analyze session history to show token usage, costs, tool patterns, and activity trends"
    )
    insights_parser.add_argument("--days", type=int, default=30, help="Number of days to analyze (default: 30)")
    insights_parser.add_argument("--source", help="Filter by platform (e.g. cli)")

    def cmd_insights(args):
        try:
            from eaisports_state import SessionDB
            from agent.insights import InsightsEngine

            db = SessionDB()
            engine = InsightsEngine(db)
            report = engine.generate(days=args.days, source=args.source)
            print(engine.format_terminal(report))
            db.close()
        except Exception as e:
            print(f"Error generating insights: {e}")

    insights_parser.set_defaults(func=cmd_insights)

    # =========================================================================
    # version command
    # =========================================================================
    version_parser = subparsers.add_parser(
        "version",
        help="Show version information"
    )
    version_parser.set_defaults(func=cmd_version)
    
    # =========================================================================
    # update command
    # =========================================================================
    update_parser = subparsers.add_parser(
        "update",
        help="Update EAISports to the latest version",
        description="Pull the latest changes from git and reinstall dependencies"
    )
    update_parser.set_defaults(func=cmd_update)
    
    # =========================================================================
    # uninstall command
    # =========================================================================
    uninstall_parser = subparsers.add_parser(
        "uninstall",
        help="Uninstall EAISports",
        description="Remove EAISports from your system. Can keep configs/data for reinstall."
    )
    uninstall_parser.add_argument(
        "--full",
        action="store_true",
        help="Full uninstall - remove everything including configs and data"
    )
    uninstall_parser.add_argument(
        "--yes", "-y",
        action="store_true",
        help="Skip confirmation prompts"
    )
    uninstall_parser.set_defaults(func=cmd_uninstall)
    
    # =========================================================================
    # Parse and execute
    # =========================================================================
    # Pre-process argv so unquoted multi-word session names after -c / -r
    # are merged into a single token before argparse sees them.
    # e.g. ``eaisports -c Pokemon Agent Dev`` → ``eaisports -c 'Pokemon Agent Dev'``
    _processed_argv = _coalesce_session_name_args(sys.argv[1:])
    args = parser.parse_args(_processed_argv)
    
    # Handle --version flag
    if args.version:
        cmd_version(args)
        return
    
    # Handle top-level --resume / --continue as shortcut to chat
    if (args.resume or args.continue_last) and args.command is None:
        args.command = "chat"
        args.query = None
        args.model = None
        args.provider = None
        args.toolsets = None
        args.verbose = False
        if not hasattr(args, "worktree"):
            args.worktree = False
        cmd_chat(args)
        return
    
    # Default: show welcome with core commands
    if args.command is None:
        from eaisports_cli.colors import Colors, color
        print()
        print(color("  EAISports -- AI-Powered Game Builder", Colors.CYAN + Colors.BOLD))
        print()
        print(color("  Quick start:", Colors.BOLD))
        print(color("    eaisports init                   Set up your environment", Colors.DIM))
        print(color("    eaisports build my-game           Build a new game", Colors.DIM))
        print(color("    eaisports build -d 'space game'   Build with a description", Colors.DIM))
        print(color("    eaisports preview                 Preview in browser", Colors.DIM))
        print(color("    eaisports push                    Deploy to eaisports.ai", Colors.DIM))
        print()
        print(color("  Run 'eaisports chat' for interactive chat.", Colors.DIM))
        print(color("  Run 'eaisports --help' for all commands.", Colors.DIM))
        print()
        return
    
    # Execute the command
    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
