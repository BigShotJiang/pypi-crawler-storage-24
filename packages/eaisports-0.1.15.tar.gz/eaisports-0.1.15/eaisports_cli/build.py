"""
EAISports Build Command -- game-building orchestrator.

Launches an AI-powered build session that:
1. Creates a game output directory under ~/.eaisports/games/{slug}/
2. Scaffolds a React + Vite project structure
3. Spins up an AIAgent with build-specific system prompt
4. Runs the agent conversation loop
5. On completion, attempts nudge (skill extraction) and flush (memory flush)

Usage (from CLI):
    eaisports build                       # interactive -- asks what to build
    eaisports build my-trivia-game        # provide slug upfront
    eaisports build --skill trivia        # start with a skill template
    eaisports build --resume my-game      # resume previous session
"""

import json
import logging
import os
import re
import signal
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

from utils.text import slugify

logger = logging.getLogger(__name__)


# =========================================================================
# Slug helpers
# =========================================================================

def _prompt_for_slug() -> str:
    """Interactively ask the user for a game name and slugify it."""
    try:
        from prompt_toolkit import prompt as pt_prompt
        raw = pt_prompt("  Game name (e.g. 'Space Trivia'): ").strip()
    except (ImportError, KeyboardInterrupt, EOFError):
        raw = input("  Game name (e.g. 'Space Trivia'): ").strip()
    if not raw:
        raw = "untitled-game"
    return slugify(raw, fallback="untitled-game")


def _get_last_assistant_message(messages: list[dict]) -> Optional[dict]:
    """Return the most recent assistant message from *messages*."""
    for message in reversed(messages or []):
        if isinstance(message, dict) and message.get("role") == "assistant":
            return message
    return None


def _last_assistant_message_is_text_only(messages: list[dict]) -> bool:
    """True when the latest assistant turn is plain text, not a tool call."""
    last_assistant = _get_last_assistant_message(messages)
    if not last_assistant:
        return False
    if last_assistant.get("tool_calls"):
        return False
    return bool((last_assistant.get("content") or "").strip())


def _prompt_for_next_build_message(slug: str) -> Optional[str]:
    """Prompt for freeform follow-up input between agent turns."""
    from eaisports_cli.colors import Colors, color
    from eaisports_cli.preview import run_preview

    while True:
        try:
            user_input = input(
                color("  Next step (`preview`, `done`, or feedback): ", Colors.CYAN)
            ).strip()
        except EOFError:
            return None

        if not user_input:
            continue

        command = user_input.lower()
        if command == "done":
            return None

        if command == "preview":
            previous_handler = signal.getsignal(signal.SIGINT)
            try:
                print()
                run_preview(slug=slug)
            except SystemExit:
                pass
            finally:
                signal.signal(signal.SIGINT, previous_handler)
                print()
            continue

        return user_input


# =========================================================================
# Project scaffolding
# =========================================================================

_INDEX_HTML = """\
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{slug}</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
"""

_PACKAGE_JSON = """\
{{
  "name": "{slug}",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {{
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  }},
  "dependencies": {{
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  }},
  "devDependencies": {{
    "vite": "^5.0.0",
    "@vitejs/plugin-react": "^4.2.0"
  }}
}}
"""

_VITE_CONFIG = """\
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: './',
  plugins: [react()],
  server: {
    port: 5173,
  },
});
"""

_MAIN_JSX = """\
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
"""

_APP_JSX = """\
import React from 'react';

function App() {{
  return (
    <div style={{{{ textAlign: 'center', padding: '2rem' }}}}>
      <h1>Hello from {slug}</h1>
      <p>Start building your game!</p>
    </div>
  );
}}

export default App;
"""

_INDEX_CSS = """\
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
    Oxygen, Ubuntu, Cantarell, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  min-height: 100vh;
  background: #0a0a0a;
  color: #ededed;
}

#root {
  min-height: 100vh;
}
"""


def _scaffold_project(game_dir: Path, slug: str) -> None:
    """Create the React + Vite project skeleton in *game_dir*.

    Writes only files that don't already exist so that ``--resume``
    doesn't clobber user edits.
    """
    files = {
        "index.html": _INDEX_HTML.format(slug=slug),
        "package.json": _PACKAGE_JSON.format(slug=slug),
        "vite.config.js": _VITE_CONFIG,
        "src/main.jsx": _MAIN_JSX,
        "src/App.jsx": _APP_JSX.format(slug=slug),
        "src/styles/index.css": _INDEX_CSS,
    }

    # Create directories (including empty placeholder dirs)
    for d in ("src/components", "src/data", "src/styles"):
        (game_dir / d).mkdir(parents=True, exist_ok=True)

    # Write files (skip existing for resume safety)
    for rel_path, content in files.items():
        target = game_dir / rel_path
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            logger.debug("Wrote %s", target)
        else:
            logger.debug("Skipped existing %s", target)


# =========================================================================
# Phase checkpoint helpers
# =========================================================================

_PHASE_ORDER = ["scaffold", "polish", "verify"]


def _save_phase_checkpoint(game_dir, phase_name, status, cumulative_usage):
    """Update .build_meta.json with phase completion data."""
    meta_path = Path(game_dir) / ".build_meta.json"
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        meta = {}

    phases = meta.setdefault("phases", {})
    total_tokens = cumulative_usage.get("prompt_tokens", 0) + cumulative_usage.get("completion_tokens", 0)
    phases[phase_name] = {
        "status": status,
        "timestamp": datetime.now().isoformat(),
        "tokens": total_tokens,
    }
    if status == "completed":
        meta["last_completed_phase"] = phase_name
    meta["cumulative_cost"] = cumulative_usage.get("cost", 0.0)
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")


def _get_resume_phase(game_dir) -> str:
    """Return first incomplete phase, or 'scaffold' if all done."""
    meta_path = Path(game_dir) / ".build_meta.json"
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return "scaffold"

    phases = meta.get("phases", {})
    for phase in _PHASE_ORDER:
        info = phases.get(phase, {})
        if info.get("status") != "completed":
            return phase
    return "scaffold"


# =========================================================================
# Phase runner
# =========================================================================

def _run_phase(phase_name, system_prompt, initial_message, effective_model,
               phase_budget, runtime, session_db, game_dir, slug,
               interactive=False, usage_callback=None, clarify_callback=None,
               agent_ref=None):
    """Run a single build phase via AIAgent."""
    from run_agent import AIAgent

    agent = AIAgent(
        model=effective_model,
        base_url=runtime.get("base_url") or None,
        api_key=runtime.get("api_key") or None,
        provider=runtime.get("provider") or None,
        api_mode=runtime.get("api_mode") or None,
        max_iterations=phase_budget,
        enabled_toolsets=["file", "terminal", "web", "skills", "clarify"],
        save_trajectories=True,
        platform="cli",
        ephemeral_system_prompt=system_prompt,
        session_db=session_db,
        usage_callback=usage_callback,
        clarify_callback=clarify_callback,
    )

    # Allow cost-limit callback to interrupt this agent mid-phase
    if agent_ref is not None:
        agent_ref[0] = agent

    conversation_history = None
    next_user_message = initial_message

    if interactive:
        while next_user_message is not None:
            result = agent.run_conversation(
                user_message=next_user_message,
                conversation_history=conversation_history,
            )
            conversation_history = result.get("messages") or conversation_history
            if not _last_assistant_message_is_text_only(conversation_history):
                break
            next_user_message = _prompt_for_next_build_message(slug)
    else:
        result = agent.run_conversation(user_message=initial_message)
        conversation_history = result.get("messages") or conversation_history

    return {
        "messages": conversation_history,
        "prompt_tokens": agent.session_prompt_tokens,
        "completion_tokens": agent.session_completion_tokens,
        "total_tokens": agent.session_total_tokens,
    }


# =========================================================================
# Build session
# =========================================================================

def _prompt_for_description() -> Optional[str]:
    """Ask the user to describe their game idea. Returns None if skipped."""
    from eaisports_cli.colors import Colors, color

    print(color("  Describe your game (or press Enter to skip):", Colors.DIM))
    try:
        raw = input("  > ").strip()
    except (EOFError, KeyboardInterrupt):
        return None
    return raw if raw else None


def _offer_skill_picker() -> Optional[str]:
    """Show available skills and let user pick one. Returns None if skipped."""
    from eaisports_cli.colors import Colors, color

    try:
        from eaisports_cli.skills_cli import _iter_skills
    except ImportError:
        return None

    skills: list[tuple[str, str]] = []
    try:
        for skill_dir, fm, _body in _iter_skills():
            name = fm.get("name", skill_dir.name)
            desc = fm.get("description", "")[:60]
            skills.append((name, desc))
    except Exception:
        return None

    if not skills:
        return None

    print()
    print(color("  Start from a skill template? (improves quality)", Colors.CYAN))
    for i, (name, desc) in enumerate(skills, 1):
        print(color(f"    {i}. {name}", Colors.GREEN) + color(f" -- {desc}", Colors.DIM))
    print(color(f"    {len(skills) + 1}. No template (build from scratch)", Colors.DIM))

    try:
        raw = input(color("  Choice [skip]: ", Colors.CYAN)).strip()
    except (EOFError, KeyboardInterrupt):
        return None

    if raw.isdigit() and 1 <= int(raw) <= len(skills):
        selected = skills[int(raw) - 1][0]
        print(color(f"  Using skill: {selected}", Colors.GREEN))
        return selected
    return None


def run_build_session(
    slug: Optional[str] = None,
    budget: Optional[int] = None,
    resume_slug: Optional[str] = None,
    skill_name: Optional[str] = None,
    model: Optional[str] = None,
    phases: bool = True,
    cost_limit: float = None,
    description: Optional[str] = None,
) -> None:
    """Run an end-to-end game build session.

    Parameters
    ----------
    slug:
        Game directory name. If *None*, the user is prompted interactively.
    budget:
        Max agent iterations. Falls back to config value or 50.
    resume_slug:
        If set, resume a previous build in ``~/.eaisports/games/{resume_slug}/``.
    skill_name:
        Optional skill to seed the build with.
    model:
        Model override for this session.
    """
    from eaisports_cli.config import load_config, get_eaisports_home
    from eaisports_cli.colors import Colors, color

    config = load_config()
    home = get_eaisports_home()

    # -- Resolve slug
    if resume_slug:
        slug = resume_slug
        game_dir = home / "games" / slug
        if not game_dir.exists():
            print(color(f"  No game found at {game_dir}", Colors.RED))
            sys.exit(1)
        print(color(f"  Resuming build: {slug}", Colors.CYAN))
    else:
        if not slug:
            slug = _prompt_for_slug()
        slug = slugify(slug, fallback="untitled-game")
        game_dir = home / "games" / slug
        game_dir.mkdir(parents=True, exist_ok=True)
        print(color(f"  Creating game: {slug}", Colors.CYAN))

    # -- Interactive prompts (skip for resume)
    if not resume_slug:
        if not description:
            description = _prompt_for_description()
        if not skill_name:
            skill_name = _offer_skill_picker()

    # -- Scaffold
    _scaffold_project(game_dir, slug)
    print(color(f"  Game directory: {game_dir}", Colors.DIM))

    # -- Session tracking
    from eaisports_state import SessionDB

    session_db = SessionDB()
    parent_session_id = None
    session_id = str(uuid.uuid4())

    meta_path = game_dir / ".build_meta.json"
    if resume_slug and meta_path.exists():
        try:
            prev_meta = json.loads(meta_path.read_text(encoding="utf-8"))
            parent_session_id = prev_meta.get("session_id")
            if parent_session_id:
                print(color(f"  Resuming session: {parent_session_id[:8]}...", Colors.DIM))
        except (json.JSONDecodeError, KeyError):
            logger.debug("Could not read previous build meta, starting fresh session")

    # -- Resolve model
    effective_model = model or config.get("model", "anthropic/claude-opus-4.6")

    # -- Resolve budget
    effective_budget = budget or config.get("build_budget", 50)

    # -- Build system prompt
    from agent.build_prompt import build_game_prompt

    build_prompt = build_game_prompt(
        slug=slug,
        game_dir=str(game_dir),
        skill_name=skill_name,
        description=description,
    )

    # -- Register session in DB (before AIAgent, which also tries create_session
    #    but silently skips if it already exists due to duplicate primary key)
    try:
        session_db.create_session(
            session_id=session_id,
            source="build",
            model=effective_model,
            system_prompt=build_prompt,
            parent_session_id=parent_session_id,
        )
    except Exception as exc:
        logger.debug("Session DB create_session failed: %s", exc)

    # -- Resolve provider credentials (OAuth, API key, etc.)
    from eaisports_cli.runtime_provider import resolve_runtime_provider

    runtime = resolve_runtime_provider()
    runtime_api_key = runtime.get("api_key", "")
    runtime_base_url = runtime.get("base_url", "")
    runtime_provider = runtime.get("provider", "")
    runtime_api_mode = runtime.get("api_mode", "")

    # -- Clarify callback so the agent can ask the user questions mid-build
    def _build_clarify_callback(question, choices):
        """Simple stdin-based clarify callback for build sessions."""
        from eaisports_cli.colors import Colors, color
        print()
        print(color(f"  🤔 {question}", Colors.CYAN))
        if choices:
            for i, choice in enumerate(choices, 1):
                print(color(f"     {i}. {choice}", Colors.DIM))
            print(color(f"     {len(choices) + 1}. Other (type your answer)", Colors.DIM))
            try:
                raw = input(color("  Your choice: ", Colors.CYAN)).strip()
                if raw.isdigit():
                    idx = int(raw)
                    if 1 <= idx <= len(choices):
                        return choices[idx - 1]
                # Treat as freetext
                return raw if raw else choices[0]
            except (EOFError, KeyboardInterrupt):
                return choices[0] if choices else "just decide for me"
        else:
            try:
                return input(color("  Your answer: ", Colors.CYAN)).strip() or "just decide for me"
            except (EOFError, KeyboardInterrupt):
                return "just decide for me"

    # -- Prepare initial message
    if skill_name and description:
        initial_message = (
            f"Build a game called '{slug}' using the '{skill_name}' skill template. "
            f"The creator's vision: \"{description}\". "
            f"All files go in {game_dir}. The project is already scaffolded with "
            f"React + Vite. Start by examining the skill template, then implement "
            f"the game matching the creator's description."
        )
    elif skill_name:
        initial_message = (
            f"Build a game called '{slug}' using the '{skill_name}' skill template. "
            f"All files go in {game_dir}. The project is already scaffolded with "
            f"React + Vite. Start by examining the skill template, then implement "
            f"the game."
        )
    elif description:
        initial_message = (
            f"Build a game called '{slug}'. The creator's vision: \"{description}\". "
            f"All files go in {game_dir}. The project is already scaffolded with "
            f"React + Vite. Build the game as described. "
            f"After the first version is ready, let me know so I can preview and request changes."
        )
    else:
        initial_message = (
            f"Build a game called '{slug}'. All files go in {game_dir}. "
            f"The project is already scaffolded with React + Vite. "
            f"Use the clarify tool to ask what kind of game to build, then implement it. "
            f"After the first version is ready, let me know so I can preview and request changes."
        )

    # -- Cost tracking
    from agent.insights import estimate_cost, has_known_pricing

    _cumulative = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "cost": 0.0}
    _cost_limit_agent = [None]  # mutable ref for the callback to set interrupt

    def _on_usage(prompt_tokens, completion_tokens, total_tokens):
        _cumulative["prompt_tokens"] += prompt_tokens
        _cumulative["completion_tokens"] += completion_tokens
        _cumulative["total_tokens"] += total_tokens
        call_cost = estimate_cost(effective_model, prompt_tokens, completion_tokens)
        _cumulative["cost"] += call_cost
        print(color(
            f"  [{_cumulative['total_tokens']:,} tokens | ~${_cumulative['cost']:.4f}]",
            Colors.DIM,
        ))
        if cost_limit and _cumulative["cost"] >= cost_limit:
            print(color(f"  Cost limit ${cost_limit:.2f} reached.", Colors.YELLOW))
            agent_ref = _cost_limit_agent[0]
            if agent_ref is not None:
                agent_ref._interrupt_requested = True

    print(color(f"  Model: {effective_model}", Colors.DIM))
    print(color(f"  Budget: {effective_budget} iterations", Colors.DIM))
    if cost_limit:
        print(color(f"  Cost limit: ${cost_limit:.2f}", Colors.DIM))
    print()

    # -- Run the conversation
    end_reason = "completed"

    try:
        if phases:
            # -- Phased build (scaffold -> polish -> verify)
            from agent.build_prompt import (
                build_scaffold_prompt, build_polish_prompt,
                build_verify_prompt, collect_phase_context,
            )

            resume_from = _get_resume_phase(game_dir) if resume_slug else "scaffold"
            phase_budgets = {
                "scaffold": int(effective_budget * 0.60),
                "polish": int(effective_budget * 0.25),
                "verify": max(1, effective_budget - int(effective_budget * 0.60) - int(effective_budget * 0.25)),
            }

            started = False
            for phase_name in _PHASE_ORDER:
                if not started:
                    if phase_name == resume_from:
                        started = True
                    else:
                        continue

                phase_budget = phase_budgets[phase_name]
                print(color(f"  ── Phase: {phase_name} ({phase_budget} iterations) ──", Colors.CYAN))
                _save_phase_checkpoint(game_dir, phase_name, "in_progress", _cumulative)

                # Build phase-specific prompt and settings
                if phase_name == "scaffold":
                    system_prompt = build_scaffold_prompt(slug=slug, game_dir=str(game_dir), skill_name=skill_name, description=description)
                    phase_message = initial_message
                    interactive = True
                elif phase_name == "polish":
                    phase_context = collect_phase_context(str(game_dir))
                    system_prompt = build_polish_prompt(slug=slug, game_dir=str(game_dir), phase_context=phase_context)
                    phase_message = (
                        f"Polish the game in {game_dir}. Improve visuals, "
                        f"animations, and mobile responsiveness."
                    )
                    interactive = False
                else:  # verify
                    phase_context = collect_phase_context(str(game_dir))
                    system_prompt = build_verify_prompt(slug=slug, game_dir=str(game_dir), phase_context=phase_context)
                    phase_message = (
                        f"Verify the game in {game_dir} builds and runs correctly. "
                        f"Fix any errors."
                    )
                    interactive = False

                result = _run_phase(
                    phase_name=phase_name,
                    system_prompt=system_prompt,
                    initial_message=phase_message,
                    effective_model=effective_model,
                    phase_budget=phase_budget,
                    runtime=runtime,
                    session_db=session_db,
                    game_dir=game_dir,
                    slug=slug,
                    interactive=interactive,
                    usage_callback=_on_usage,
                    clarify_callback=_build_clarify_callback,
                    agent_ref=_cost_limit_agent,
                )

                _save_phase_checkpoint(game_dir, phase_name, "completed", _cumulative)
                print(color(f"  ✓ Phase {phase_name} complete", Colors.GREEN))
                print()

                # Check cost limit
                if cost_limit and _cumulative["cost"] >= cost_limit:
                    break

            # Final cost summary
            print(color(
                f"  Total: {_cumulative['total_tokens']:,} tokens | ~${_cumulative['cost']:.4f}",
                Colors.CYAN,
            ))

        else:
            # -- Single-agent mode (original behavior)
            from run_agent import AIAgent
            agent = AIAgent(
                model=effective_model,
                base_url=runtime_base_url or None,
                api_key=runtime_api_key or None,
                provider=runtime_provider or None,
                api_mode=runtime_api_mode or None,
                max_iterations=effective_budget,
                enabled_toolsets=["file", "terminal", "web", "skills", "clarify"],
                save_trajectories=True,
                platform="cli",
                ephemeral_system_prompt=build_prompt,
                session_id=session_id,
                session_db=session_db,
                clarify_callback=_build_clarify_callback,
                usage_callback=_on_usage,
            )
            _cost_limit_agent[0] = agent

            conversation_history = None
            next_user_message = initial_message
            while next_user_message is not None:
                result = agent.run_conversation(
                    user_message=next_user_message,
                    conversation_history=conversation_history,
                )
                conversation_history = result.get("messages") or conversation_history
                if not _last_assistant_message_is_text_only(conversation_history):
                    break
                next_user_message = _prompt_for_next_build_message(slug)

        print()
        print(color("  Build session complete.", Colors.GREEN))
    except KeyboardInterrupt:
        print()
        print(color("  Build session interrupted.", Colors.YELLOW))
        end_reason = "interrupted"

    # -- End session in DB
    try:
        session_db.end_session(session_id, end_reason)
    except Exception as exc:
        logger.debug("Session DB end_session failed: %s", exc)

    # -- Save build metadata (merge with existing phase data)
    try:
        meta = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        meta.update({
            "session_id": session_id,
            "built_at": datetime.now().isoformat(),
            "slug": slug,
            "skill_used": skill_name,
            "model": effective_model,
        })
        if parent_session_id:
            meta["parent_session_id"] = parent_session_id
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    except Exception as exc:
        logger.debug("Failed to write build meta: %s", exc)

    # -- Post-build: nudge (skill extraction) and flush (memory)
    try:
        from eaisports_cli.nudge import run_nudge
        run_nudge(slug=slug, game_dir=str(game_dir))
    except (ImportError, Exception) as exc:
        logger.debug("Nudge skipped: %s", exc)

    try:
        from eaisports_cli.flush import run_flush
        run_flush(slug=slug)
    except (ImportError, Exception) as exc:
        logger.debug("Flush skipped: %s", exc)
