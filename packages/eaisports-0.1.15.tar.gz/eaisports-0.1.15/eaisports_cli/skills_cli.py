"""
Skills CLI — Local skill management for EAISports.

Handles: eaisports skills [list|info|init|search]

Thin CLI layer over the skills infrastructure in tools/skills_tool.py.
Skills live as directories with SKILL.md files in ~/.eaisports/skills/.
"""

import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

from eaisports_cli.colors import Colors, color
from eaisports_cli.config import get_eaisports_home
from utils.skills import parse_frontmatter

SKILLS_DIR = get_eaisports_home() / "skills"
REGISTRY_URL = "https://registry.eaisports.ai"


def _parse_tags(tags_value):
    """Parse tags from frontmatter value (list or string)."""
    if not tags_value:
        return []
    if isinstance(tags_value, list):
        return [str(t).strip() for t in tags_value if t]
    tags_value = str(tags_value).strip()
    if tags_value.startswith('[') and tags_value.endswith(']'):
        tags_value = tags_value[1:-1]
    return [t.strip().strip('"\'') for t in tags_value.split(',') if t.strip()]


def _read_skill(skill_dir: Path):
    """Read and parse a SKILL.md from a skill directory.

    Returns (frontmatter, body) or (None, None) on failure.
    """
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        return None, None
    try:
        content = skill_md.read_text(encoding='utf-8')
        return parse_frontmatter(content)
    except (UnicodeDecodeError, PermissionError, OSError):
        return None, None


def _iter_skills():
    """Yield (skill_dir, frontmatter, body) for every installed skill."""
    if not SKILLS_DIR.exists():
        return

    for entry in sorted(SKILLS_DIR.iterdir()):
        if not entry.is_dir() or entry.name.startswith('.'):
            continue

        # Direct skill directory (has SKILL.md)
        skill_md = entry / "SKILL.md"
        if skill_md.exists():
            fm, body = _read_skill(entry)
            if fm is not None:
                yield entry, fm, body
            continue

        # Category directory — look one level deeper
        for sub in sorted(entry.iterdir()):
            if sub.is_dir() and (sub / "SKILL.md").exists():
                fm, body = _read_skill(sub)
                if fm is not None:
                    yield sub, fm, body


# ---------------------------------------------------------------------------
# skills list
# ---------------------------------------------------------------------------

def skills_list(category: str = None, verbose: bool = False):
    """List installed skills from ~/.eaisports/skills/.

    Reads SKILL.md frontmatter for name and description.
    Groups by category if available.
    """
    skills = []
    for skill_dir, fm, _body in _iter_skills():
        name = fm.get('name', skill_dir.name)
        desc = fm.get('description', '')
        cat = fm.get('category', None)
        tags = _parse_tags(fm.get('tags'))
        version = fm.get('version', '')

        # Derive category from parent dir if not in frontmatter
        if not cat:
            try:
                rel = skill_dir.relative_to(SKILLS_DIR)
                if len(rel.parts) >= 2:
                    cat = rel.parts[0]
            except ValueError:
                pass

        skills.append({
            'name': name,
            'description': desc,
            'category': cat,
            'tags': tags,
            'version': version,
            'path': str(skill_dir),
        })

    if category:
        skills = [s for s in skills if (s.get('category') or '').lower() == category.lower()]

    if not skills:
        if category:
            print(color(f"No skills found in category '{category}'.", Colors.DIM))
        else:
            print(color("No skills installed.", Colors.DIM))
            print(color(f"Browse the registry: {REGISTRY_URL}", Colors.DIM))
        return

    print()
    print(color("Installed Skills", Colors.BOLD + Colors.CYAN))
    print(color("-" * 60, Colors.DIM))

    if category:
        # Flat list when filtering by category
        for s in skills:
            _print_skill_row(s, verbose)
    else:
        # Group by category
        categorized = {}
        uncategorized = []
        for s in skills:
            cat = s.get('category')
            if cat:
                categorized.setdefault(cat, []).append(s)
            else:
                uncategorized.append(s)

        for cat_name in sorted(categorized.keys()):
            print(color(f"\n  [{cat_name}]", Colors.YELLOW))
            for s in categorized[cat_name]:
                _print_skill_row(s, verbose)

        if uncategorized:
            if categorized:
                print(color("\n  [uncategorized]", Colors.YELLOW))
            for s in uncategorized:
                _print_skill_row(s, verbose)

    print()
    print(color(f"  {len(skills)} skill(s) installed", Colors.DIM))
    print()


def _print_skill_row(skill: dict, verbose: bool = False):
    """Print a single skill row."""
    name = skill['name']
    desc = skill.get('description', '')

    # Truncate description to fit terminal width
    max_desc = 50
    if len(desc) > max_desc:
        desc = desc[:max_desc - 3] + "..."

    name_col = color(f"  {name:<22}", Colors.GREEN)
    print(f"{name_col} {desc}")

    if verbose:
        version = skill.get('version', '')
        tags = skill.get('tags', [])
        path = skill.get('path', '')
        if version:
            print(color(f"{'':>24}version: {version}", Colors.DIM))
        if tags:
            print(color(f"{'':>24}tags: {', '.join(tags)}", Colors.DIM))
        if path:
            print(color(f"{'':>24}path: {path}", Colors.DIM))


# ---------------------------------------------------------------------------
# skills info
# ---------------------------------------------------------------------------

def skills_info(skill_name: str):
    """Show detailed info about a skill."""
    skill_dir = _find_skill_dir(skill_name)
    if not skill_dir:
        print(color(f"Skill '{skill_name}' not found.", Colors.RED))
        print(color("Run 'eaisports skills list' to see installed skills.", Colors.DIM))
        return

    fm, body = _read_skill(skill_dir)
    if fm is None:
        print(color(f"Could not read SKILL.md in {skill_dir}", Colors.RED))
        return

    name = fm.get('name', skill_dir.name)
    desc = fm.get('description', '')
    version = fm.get('version', '')
    author = fm.get('author', '')
    tags = _parse_tags(fm.get('tags'))
    category = fm.get('category', '')

    print()
    print(color(f"  {name}", Colors.BOLD + Colors.CYAN))
    if desc:
        print(color(f"  {desc}", Colors.DIM))
    print(color("  " + "-" * 56, Colors.DIM))

    if version:
        print(f"  {color('Version:', Colors.YELLOW)}  {version}")
    if author:
        print(f"  {color('Author:', Colors.YELLOW)}   {author}")
    if category:
        print(f"  {color('Category:', Colors.YELLOW)} {category}")
    if tags:
        print(f"  {color('Tags:', Colors.YELLOW)}     {', '.join(tags)}")

    print(f"  {color('Path:', Colors.YELLOW)}     {skill_dir}")

    # List template files
    templates_dir = skill_dir / "templates"
    if templates_dir.exists():
        template_files = sorted(templates_dir.iterdir())
        if template_files:
            print(f"\n  {color('Templates:', Colors.YELLOW)}")
            for tf in template_files:
                if tf.is_file():
                    print(f"    - {tf.name}")

    # List reference files
    refs_dir = skill_dir / "references"
    if refs_dir.exists():
        ref_files = sorted(refs_dir.iterdir())
        if ref_files:
            print(f"\n  {color('References:', Colors.YELLOW)}")
            for rf in ref_files:
                if rf.is_file():
                    print(f"    - {rf.name}")

    # Show SKILL.md body content
    if body and body.strip():
        print(f"\n  {color('Content:', Colors.YELLOW)}")
        print(color("  " + "-" * 56, Colors.DIM))
        for line in body.strip().split('\n'):
            print(f"  {line}")

    print()


def _find_skill_dir(skill_name: str):
    """Find a skill directory by name (case-insensitive).

    Searches both direct skill dirs and category subdirs.
    """
    if not SKILLS_DIR.exists():
        return None

    # Exact match by directory name
    direct = SKILLS_DIR / skill_name
    if direct.is_dir() and (direct / "SKILL.md").exists():
        return direct

    # Search all skills by frontmatter name or directory name
    for skill_dir, fm, _body in _iter_skills():
        fm_name = fm.get('name', skill_dir.name)
        if fm_name.lower() == skill_name.lower() or skill_dir.name.lower() == skill_name.lower():
            return skill_dir

    return None


# ---------------------------------------------------------------------------
# skills init
# ---------------------------------------------------------------------------

def skills_init(name: str):
    """Scaffold a new skill directory with template SKILL.md."""
    skill_dir = SKILLS_DIR / name

    if skill_dir.exists():
        print(color(f"Skill directory already exists: {skill_dir}", Colors.RED))
        return

    # Create directory structure
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    skill_dir.mkdir(parents=True)
    (skill_dir / "templates").mkdir()
    (skill_dir / "references").mkdir()

    # Generate template SKILL.md with authoring guide
    title = name.replace('-', ' ').title()
    skill_md_content = f"""---
name: {name}
version: 0.1.0
description: "TODO: What kind of game does this skill build?"
author: ""
tags: []
category: ""
---

# {title}

TODO: Describe what kind of game this skill creates. Be specific about
genre, mechanics, and what makes it unique.

## What This Skill Creates

- **Genre**: TODO (e.g., trivia, platformer, puzzle, story)
- **Core Mechanic**: TODO (e.g., answer questions, jump between platforms)
- **Player Goal**: TODO (e.g., get the highest score, complete all levels)

## Build Instructions

1. **Ask the creator** (use the clarify tool):
   - TODO: List 3-5 questions (theme, difficulty, visual style, etc.)
2. **Generate content**:
   - TODO: What data to create (questions, levels, story nodes)
3. **Build the game**:
   - TODO: Component structure and build order
4. **Polish**:
   - TODO: Visual and interaction expectations

## Patterns

TODO: Document code patterns that produce good results for this game type.
Example: "Using useReducer for game state prevents sync bugs in turn-based games."

## Quality Checklist

- [ ] Playable on mobile (375px width)
- [ ] All tap targets >= 44px
- [ ] Clear start, play, and end screens
- [ ] Score or progress is tracked and displayed
- [ ] No console errors or warnings
- [ ] Keyboard navigation works for all controls
"""
    (skill_dir / "SKILL.md").write_text(skill_md_content, encoding='utf-8')

    print()
    print(color(f"  Created skill: {name}", Colors.GREEN + Colors.BOLD))
    print()
    print(f"  {skill_dir}/")
    print(f"    SKILL.md          (edit this -- the TODOs guide you)")
    print(f"    templates/        (add reference components here)")
    print(f"    references/       (add reference docs here)")
    print()
    print(color("  Fill in the TODOs, then use it:", Colors.DIM))
    print(color(f"    eaisports build my-game --skill {name}", Colors.CYAN))
    print()


# ---------------------------------------------------------------------------
# skills search
# ---------------------------------------------------------------------------

def skills_search(query: str):
    """Search installed skills by name, description, or tags."""
    query_lower = query.lower()
    matches = []

    for skill_dir, fm, _body in _iter_skills():
        name = fm.get('name', skill_dir.name)
        desc = fm.get('description', '')
        tags = _parse_tags(fm.get('tags'))

        # Match against name, description, or tags
        searchable = f"{name} {desc} {' '.join(tags)}".lower()
        if query_lower in searchable:
            matches.append({
                'name': name,
                'description': desc,
                'tags': tags,
                'path': str(skill_dir),
            })

    if not matches:
        print(color(f"No local skills matching '{query}'.", Colors.DIM))
        print(color(f"Search the online registry: {REGISTRY_URL}", Colors.DIM))
        return

    print()
    print(color(f"  Local skills matching '{query}':", Colors.BOLD + Colors.CYAN))
    print(color("  " + "-" * 56, Colors.DIM))

    for s in matches:
        name_col = color(f"  {s['name']:<22}", Colors.GREEN)
        desc = s.get('description', '')
        if len(desc) > 50:
            desc = desc[:47] + "..."
        print(f"{name_col} {desc}")

    print()
    print(color(f"  {len(matches)} result(s)", Colors.DIM))
    print(color(f"  Online registry: {REGISTRY_URL}", Colors.DIM))
    print()


# ---------------------------------------------------------------------------
# Main dispatcher
# ---------------------------------------------------------------------------

def skills_command(args):
    """Handle skills subcommands dispatched from main.py."""
    subcmd = getattr(args, 'skills_command', None)

    if subcmd == "list":
        category = getattr(args, 'category', None)
        verbose = getattr(args, 'verbose', False)
        skills_list(category=category, verbose=verbose)

    elif subcmd == "info":
        skills_info(args.name)

    elif subcmd == "init":
        skills_init(args.name)

    elif subcmd == "search":
        skills_search(args.query)

    else:
        print("Usage: eaisports skills [list|info|init|search]")
        print()
        print("  list    List installed skills")
        print("  info    Show detailed skill info")
        print("  init    Create a new skill")
        print("  search  Search skills by name/tag")
        sys.exit(1)
