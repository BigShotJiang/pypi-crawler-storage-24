"""
EAISports initialization wizard.

Runs on `eaisports init` — guides creators through first-time setup:
1. API provider & model selection (reuses full provider flow from setup.py)
2. Wallet connect
3. Workspace setup (default skills + memory file creation)
"""

import os
from pathlib import Path

from eaisports_cli.colors import Colors, color


def run_init_wizard():
    """Run the full EAISports init wizard."""
    _print_welcome()

    # Step 1: Check if already initialized
    from eaisports_cli.config import load_config, save_config, get_config_path
    config = load_config()
    config_path = get_config_path()

    if config_path.exists():
        print(color("  EAISports is already initialized.", Colors.YELLOW))
        print(color(f"  Config: {config_path}", Colors.DIM))
        print()

        try:
            from prompt_toolkit import prompt
            answer = prompt("  Re-run setup? (y/N): ").strip().lower()
            if answer not in ("y", "yes"):
                print(color("  → No changes made.", Colors.DIM))
                return
        except (KeyboardInterrupt, EOFError):
            print()
            return

    print()

    # Step 1: API Provider & Model Selection (reuses the full provider flow)
    print(color("  Step 1/3: API Provider & Model", Colors.CYAN + Colors.BOLD))
    from eaisports_cli.setup import setup_model_provider
    setup_model_provider(config)

    # Step 2: Wallet Connect
    print()
    print(color("  Step 2/3: Wallet Connect", Colors.CYAN + Colors.BOLD))
    _setup_wallet(config)

    # Step 3: Create memory files + install default skills
    print()
    print(color("  Step 3/3: Workspace Setup", Colors.CYAN + Colors.BOLD))
    _setup_workspace(config)

    # Save config
    save_config(config)

    # Done
    print()
    print(color("  ┌─────────────────────────────────────────────────┐", Colors.GREEN))
    print(color("  │         EAISports is ready to go!               │", Colors.GREEN))
    print(color("  └─────────────────────────────────────────────────┘", Colors.GREEN))
    print()
    print(color("  Build your first game!", Colors.BOLD))
    print()

    try:
        answer = input("  Start building now? (Y/n): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        answer = "n"

    if answer in ("", "y", "yes"):
        print()
        from eaisports_cli.build import run_build_session
        run_build_session()
    else:
        print()
        print(color("  When you're ready:", Colors.DIM))
        print(color("    eaisports build my-game      Build a game", Colors.DIM))
        print(color("    eaisports skills list         Browse templates", Colors.DIM))
        print()


def _print_welcome():
    """Print the welcome banner."""
    print()
    print(color("  ╔═══════════════════════════════════════════════════╗", Colors.CYAN))
    print(color("  ║                                                   ║", Colors.CYAN))
    print(color("  ║        Welcome to EAISports                       ║", Colors.CYAN))
    print(color("  ║        AI-Powered Game Building CLI                ║", Colors.CYAN))
    print(color("  ║                                                   ║", Colors.CYAN))
    print(color("  ╚═══════════════════════════════════════════════════╝", Colors.CYAN))
    print()
    print(color("  This wizard will set up your environment in 3 quick steps.", Colors.DIM))


def _setup_wallet(config: dict):
    """Set up Solana wallet."""
    from eaisports_cli.wallet import prompt_wallet_connect

    address = prompt_wallet_connect()
    if address:
        config["wallet_address"] = address


def _setup_workspace(config: dict):
    """Create memory files and install default skills."""
    home = Path(os.environ.get("EAISPORTS_HOME", Path.home() / ".eaisports"))

    # Create directories
    agent_dir = home / "agent"
    agent_dir.mkdir(parents=True, exist_ok=True)

    games_dir = home / "games"
    games_dir.mkdir(parents=True, exist_ok=True)

    # Create memory file
    memory_file = agent_dir / "memory.md"
    if not memory_file.exists():
        memory_file.write_text(
            "# Creator Memory\n\n"
            "This file stores what the EAISports agent learns about you and your preferences.\n"
            "It's updated automatically after each build session.\n\n"
            "## Preferences\n\n"
            "## Past Games\n\n"
            "## Patterns\n\n"
        )
        print(color(f"  ✓ Created {memory_file}", Colors.GREEN))
    else:
        print(color(f"  → Memory file exists: {memory_file}", Colors.DIM))

    # Create creator profile
    creator_file = home / "creator.md"
    if not creator_file.exists():
        wallet = config.get("wallet_address", "not connected")
        creator_file.write_text(
            f"# Creator Profile\n\n"
            f"Wallet: {wallet}\n\n"
            f"## About\n\n"
            f"## Style Preferences\n\n"
            f"## Favorite Skills\n\n"
        )
        print(color(f"  ✓ Created {creator_file}", Colors.GREEN))
    else:
        print(color(f"  → Creator profile exists: {creator_file}", Colors.DIM))

    # Note about skills
    print(color("  ✓ Default skills (interactive-fiction, trivia, puzzle-logic, game-ui) are bundled.", Colors.GREEN))

    # Set output dir
    config.setdefault("build", {})["output_dir"] = str(games_dir)
    print(color(f"  ✓ Game output directory: {games_dir}", Colors.GREEN))
