"""
Wallet management for EAISports.

Handles Solana wallet address validation and interactive prompting.
Wallet address is used as creator identity on the EAISports platform.
"""

import re
from typing import Optional


# Solana addresses are base58-encoded, 32-44 characters
_SOLANA_ADDRESS_RE = re.compile(r'^[1-9A-HJ-NP-Za-km-z]{32,44}$')


def validate_wallet_address(address: str) -> bool:
    """Validate a Solana wallet address format.

    Checks base58 encoding and length. Does not verify on-chain existence.
    """
    if not address or not isinstance(address, str):
        return False
    return bool(_SOLANA_ADDRESS_RE.match(address.strip()))


def prompt_wallet_connect() -> Optional[str]:
    """Interactive prompt to enter a Solana wallet address.

    Returns the validated address, or None if skipped.
    """
    from prompt_toolkit import prompt as pt_prompt
    from prompt_toolkit.validation import Validator, ValidationError
    from eaisports_cli.colors import Colors, color

    print()
    print(color("  Wallet Connect", Colors.BOLD))
    print(color("  Your Solana wallet address is your creator identity on EAISports.", Colors.DIM))
    print(color("  You can get one from Phantom (phantom.app) or Solflare (solflare.com).", Colors.DIM))
    print()

    class WalletValidator(Validator):
        def validate(self, document):
            text = document.text.strip()
            if text == "":
                return  # Allow empty to skip
            if not validate_wallet_address(text):
                raise ValidationError(message="Invalid Solana address (expected base58, 32-44 chars)")

    try:
        address = pt_prompt(
            "  Wallet address (Enter to skip): ",
            validator=WalletValidator(),
            validate_while_typing=False,
        ).strip()

        if address:
            print(color(f"  ✓ Wallet connected: {address[:8]}...{address[-4:]}", Colors.GREEN))
            return address
        else:
            print(color("  → Skipped. You can add it later with: eaisports config set wallet_address <ADDRESS>", Colors.DIM))
            return None
    except (KeyboardInterrupt, EOFError):
        print()
        return None
