"""
Post-build memory, profile, and trajectory flush for EAISports.

After a build session ends, flushes important context to persistent storage:
- Memory flush:     Appends build summary to ~/.eaisports/agent/memory.md
- Creator profile:  Updates ~/.eaisports/creator.md with build stats
- Trajectory:       Archives session metadata in the game's .build_meta.json
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def _append_to_file(path: Path, content: str) -> None:
    """Append content to a file, creating parent dirs if needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(content)


def _flush_memory(
    home: Path,
    game_slug: str,
    game_dir: Path,
    session_id: Optional[str],
    skill_used: Optional[str],
    date_str: str,
) -> None:
    """Append a build summary to the agent memory file."""
    memory_path = home / "agent" / "memory.md"
    memory_path.parent.mkdir(parents=True, exist_ok=True)

    skill_note = skill_used if skill_used else "none"
    session_note = session_id if session_id else "unknown"

    entry = (
        f"\n## Build: {game_slug} ({date_str})\n"
        f"- Skills used: {skill_note}\n"
        f"- Output: {game_dir}\n"
        f"- Session: {session_note}\n"
    )

    _append_to_file(memory_path, entry)


def _flush_creator_profile(
    home: Path,
    game_slug: str,
    date_str: str,
) -> None:
    """Update the creator profile with a recent build entry."""
    creator_path = home / "creator.md"

    # If the file doesn't exist yet, create it with a header
    if not creator_path.exists():
        creator_path.parent.mkdir(parents=True, exist_ok=True)
        creator_path.write_text("# Creator Profile\n\n## Recent Builds\n")

    entry = f"- {game_slug} ({date_str})\n"

    # Check if "## Recent Builds" section exists; if not, append it
    existing = creator_path.read_text(encoding="utf-8")
    if "## Recent Builds" not in existing:
        _append_to_file(creator_path, f"\n## Recent Builds\n{entry}")
    else:
        _append_to_file(creator_path, entry)


def _flush_trajectory(
    home: Path,
    game_dir: Path,
    game_slug: str,
    session_id: Optional[str],
    skill_used: Optional[str],
) -> None:
    """Write build metadata to the game's .build_meta.json."""
    # Use the game directory itself for the meta file
    meta_dir = home / "games" / game_slug
    meta_dir.mkdir(parents=True, exist_ok=True)

    meta_path = meta_dir / ".build_meta.json"

    meta = {
        "session_id": session_id,
        "built_at": datetime.now().isoformat(),
        "slug": game_slug,
        "skill_used": skill_used,
    }

    meta_path.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")


def run_flush(
    game_dir: Path,
    session_id: Optional[str] = None,
    game_slug: Optional[str] = None,
    skill_used: Optional[str] = None,
) -> None:
    """Flush post-build context to persistent storage.

    This function never raises. All operations are wrapped in try/except
    so a flush failure cannot break the build.

    Args:
        game_dir: Path to the built game's output directory.
        session_id: Optional unique session identifier.
        game_slug: Optional game slug; derived from game_dir name if not given.
        skill_used: Optional name of the skill used in the build.
    """
    from eaisports_cli.config import get_eaisports_home

    home = get_eaisports_home()
    date_str = datetime.now().strftime("%Y-%m-%d")

    if not game_slug:
        game_slug = game_dir.name

    # a) Memory flush
    try:
        _flush_memory(home, game_slug, game_dir, session_id, skill_used, date_str)
    except Exception as exc:
        logger.debug("Memory flush failed: %s", exc)

    # b) Creator profile update
    try:
        _flush_creator_profile(home, game_slug, date_str)
    except Exception as exc:
        logger.debug("Creator profile flush failed: %s", exc)

    # c) Trajectory archive
    try:
        _flush_trajectory(home, game_dir, game_slug, session_id, skill_used)
    except Exception as exc:
        logger.debug("Trajectory flush failed: %s", exc)
