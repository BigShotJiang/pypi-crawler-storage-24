"""Welcome banner, ASCII art, skills summary, and update check for the CLI.

Pure display functions with no EAISportsCLI state dependency.
"""

import json
import logging
import os
import subprocess
import time
from pathlib import Path
from typing import Dict, List, Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from prompt_toolkit import print_formatted_text as _pt_print
from prompt_toolkit.formatted_text import ANSI as _PT_ANSI

logger = logging.getLogger(__name__)


# =========================================================================
# ANSI building blocks for conversation display
# =========================================================================

# Color palette (hex colors for Rich markup):
# - Emerald: #00FF87 (headers, highlights, primary accent)
# - Lime:    #87FF00 (secondary highlights, interactive elements)
# - Forest:  #006B3A (muted text, dim elements)
# - Jade:    #00CC6A (medium accent, borders)
# - Mint:    #E0FFE0 (light text)

_GREEN = "\033[1;32m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RST = "\033[0m"

# Backward-compat alias — old code may reference _GOLD
_GOLD = _GREEN


def cprint(text: str):
    """Print ANSI-colored text through prompt_toolkit's renderer."""
    _pt_print(_PT_ANSI(text))


# =========================================================================
# Skin-aware color helpers
# =========================================================================

def _skin_color(key: str, fallback: str) -> str:
    """Get a color from the active skin, or return fallback."""
    try:
        from eaisports_cli.skin_engine import get_active_skin
        return get_active_skin().get_color(key, fallback)
    except Exception:
        return fallback


def _skin_branding(key: str, fallback: str) -> str:
    """Get a branding string from the active skin, or return fallback."""
    try:
        from eaisports_cli.skin_engine import get_active_skin
        return get_active_skin().get_branding(key, fallback)
    except Exception:
        return fallback


# =========================================================================
# ASCII Art & Branding
# =========================================================================

from eaisports_cli import __version__ as VERSION

EAISPORTS_AGENT_LOGO = """[bold #00FF87]███████╗ █████╗ ██╗███████╗██████╗  ██████╗ ██████╗ ████████╗███████╗[/]
[bold #00FF87]██╔════╝██╔══██╗██║██╔════╝██╔══██╗██╔═══██╗██╔══██╗╚══██╔══╝██╔════╝[/]
[#87FF00]█████╗  ███████║██║███████╗██████╔╝██║   ██║██████╔╝   ██║   ███████╗[/]
[#87FF00]██╔══╝  ██╔══██║██║╚════██║██╔═══╝ ██║   ██║██╔══██╗   ██║   ╚════██║[/]
[#00CC6A]███████╗██║  ██║██║███████║██║     ╚██████╔╝██║  ██║   ██║   ███████║[/]
[#00CC6A]╚══════╝╚═╝  ╚═╝╚═╝╚══════╝╚═╝      ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝[/]"""

EAISPORTS_CONTROLLER = """[#00CC6A]      ╭──────────────────────────╮[/]
[#00CC6A]     ╱[/]  [#87FF00]┌───┐[/]            [bold #00FF87](X)[/]    [#00CC6A]╲[/]
[#00CC6A]    │[/]   [#87FF00]│ + │[/]         [bold #00FF87](Y)   (A)[/]  [#00CC6A]│[/]
[#00CC6A]    │[/]   [#87FF00]└───┘[/]            [bold #00FF87](B)[/]    [#00CC6A]│[/]
[#00CC6A]    │[/]        [dim #006B3A]◉  ══  ══  ◉[/]     [#00CC6A]│[/]
[#00CC6A]     ╲[/]    [#87FF00]╱╱[/]              [#87FF00]╲╲[/]   [#00CC6A]╱[/]
[#00CC6A]      ╰───╯[/]                [#00CC6A]╰───╯[/]"""

# Backward-compat alias
EAISPORTS_CADUCEUS = EAISPORTS_CONTROLLER

COMPACT_BANNER = """
[bold #00FF87]╔══════════════════════════════════════════════════════════════╗[/]
[bold #00FF87]║[/]  [#87FF00]EAISPORTS[/] [dim #006B3A]- AI-Powered Game Builder[/]                [bold #00FF87]║[/]
[bold #00FF87]║[/]  [#00CC6A]Build games. Push live. Earn tokens.[/]                   [bold #00FF87]║[/]
[bold #00FF87]╚══════════════════════════════════════════════════════════════╝[/]
"""


# =========================================================================
# Skills scanning
# =========================================================================

def get_available_skills() -> Dict[str, List[str]]:
    """Scan ~/.eaisports/skills/ and return skills grouped by category."""
    import os

    eaisports_home = Path(os.getenv("EAISPORTS_HOME", Path.home() / ".eaisports"))
    skills_dir = eaisports_home / "skills"
    skills_by_category = {}

    if not skills_dir.exists():
        return skills_by_category

    for skill_file in skills_dir.rglob("SKILL.md"):
        rel_path = skill_file.relative_to(skills_dir)
        parts = rel_path.parts
        if len(parts) >= 2:
            category = parts[0]
            skill_name = parts[-2]
        else:
            category = "general"
            skill_name = skill_file.parent.name
        skills_by_category.setdefault(category, []).append(skill_name)

    return skills_by_category


# =========================================================================
# Update check
# =========================================================================

# Cache update check results for 6 hours to avoid repeated git fetches
_UPDATE_CHECK_CACHE_SECONDS = 6 * 3600


def check_for_updates() -> Optional[int]:
    """Check how many commits behind origin/main the local repo is.

    Does a ``git fetch`` at most once every 6 hours (cached to
    ``~/.eaisports/.update_check``).  Returns the number of commits behind,
    or ``None`` if the check fails or isn't applicable.
    """
    eaisports_home = Path(os.getenv("EAISPORTS_HOME", Path.home() / ".eaisports"))
    repo_dir = eaisports_home / "eaisports"
    cache_file = eaisports_home / ".update_check"

    # Must be a git repo
    if not (repo_dir / ".git").exists():
        return None

    # Read cache
    now = time.time()
    try:
        if cache_file.exists():
            cached = json.loads(cache_file.read_text())
            if now - cached.get("ts", 0) < _UPDATE_CHECK_CACHE_SECONDS:
                return cached.get("behind")
    except Exception:
        pass

    # Fetch latest refs (fast — only downloads ref metadata, no files)
    try:
        subprocess.run(
            ["git", "fetch", "origin", "--quiet"],
            capture_output=True, timeout=10,
            cwd=str(repo_dir),
        )
    except Exception:
        pass  # Offline or timeout — use stale refs, that's fine

    # Count commits behind
    try:
        result = subprocess.run(
            ["git", "rev-list", "--count", "HEAD..origin/main"],
            capture_output=True, text=True, timeout=5,
            cwd=str(repo_dir),
        )
        if result.returncode == 0:
            behind = int(result.stdout.strip())
        else:
            behind = None
    except Exception:
        behind = None

    # Write cache
    try:
        cache_file.write_text(json.dumps({"ts": now, "behind": behind}))
    except Exception:
        pass

    return behind


# =========================================================================
# Welcome banner
# =========================================================================

def _format_context_length(tokens: int) -> str:
    """Format a token count for display (e.g. 128000 → '128K', 1048576 → '1M')."""
    if tokens >= 1_000_000:
        val = tokens / 1_000_000
        return f"{val:g}M"
    elif tokens >= 1_000:
        val = tokens / 1_000
        return f"{val:g}K"
    return str(tokens)


def build_welcome_banner(console: Console, model: str, cwd: str,
                         tools: List[dict] = None,
                         enabled_toolsets: List[str] = None,
                         session_id: str = None,
                         get_toolset_for_tool=None,
                         context_length: int = None):
    """Build and print a welcome banner with controller on left and info on right.

    Args:
        console: Rich Console instance.
        model: Current model name.
        cwd: Current working directory.
        tools: List of tool definitions.
        enabled_toolsets: List of enabled toolset names.
        session_id: Session identifier.
        get_toolset_for_tool: Callable to map tool name -> toolset name.
        context_length: Model's context window size in tokens.
    """
    from model_tools import check_tool_availability, TOOLSET_REQUIREMENTS
    if get_toolset_for_tool is None:
        from model_tools import get_toolset_for_tool

    tools = tools or []
    enabled_toolsets = enabled_toolsets or []

    _, unavailable_toolsets = check_tool_availability(quiet=True)
    disabled_tools = set()
    for item in unavailable_toolsets:
        disabled_tools.update(item.get("tools", []))

    layout_table = Table.grid(padding=(0, 2))
    layout_table.add_column("left", justify="center")
    layout_table.add_column("right", justify="left")

    # Resolve skin colors once for the entire banner
    accent = _skin_color("banner_accent", "#87FF00")
    dim = _skin_color("banner_dim", "#006B3A")
    text = _skin_color("banner_text", "#E0FFE0")
    session_color = _skin_color("session_border", "#8B8682")

    left_lines = ["", EAISPORTS_CONTROLLER, ""]
    model_short = model.split("/")[-1] if "/" in model else model
    if len(model_short) > 28:
        model_short = model_short[:25] + "..."
    ctx_str = f" [dim {dim}]·[/] [dim {dim}]{_format_context_length(context_length)} context[/]" if context_length else ""
    left_lines.append(f"[{accent}]{model_short}[/]{ctx_str} [dim {dim}]·[/] [dim {dim}]EAISports[/]")
    left_lines.append(f"[dim {dim}]{cwd}[/]")
    if session_id:
        left_lines.append(f"[dim {session_color}]Session: {session_id}[/]")
    left_content = "\n".join(left_lines)

    right_lines = [f"[bold {accent}]Available Tools[/]"]
    toolsets_dict: Dict[str, list] = {}

    for tool in tools:
        tool_name = tool["function"]["name"]
        toolset = get_toolset_for_tool(tool_name) or "other"
        toolsets_dict.setdefault(toolset, []).append(tool_name)

    for item in unavailable_toolsets:
        toolset_id = item.get("id", item.get("name", "unknown"))
        display_name = f"{toolset_id}_tools" if not toolset_id.endswith("_tools") else toolset_id
        if display_name not in toolsets_dict:
            toolsets_dict[display_name] = []
        for tool_name in item.get("tools", []):
            if tool_name not in toolsets_dict[display_name]:
                toolsets_dict[display_name].append(tool_name)

    sorted_toolsets = sorted(toolsets_dict.keys())
    display_toolsets = sorted_toolsets[:8]
    remaining_toolsets = len(sorted_toolsets) - 8

    for toolset in display_toolsets:
        tool_names = toolsets_dict[toolset]
        colored_names = []
        for name in sorted(tool_names):
            if name in disabled_tools:
                colored_names.append(f"[red]{name}[/]")
            else:
                colored_names.append(f"[{text}]{name}[/]")

        tools_str = ", ".join(colored_names)
        if len(", ".join(sorted(tool_names))) > 45:
            short_names = []
            length = 0
            for name in sorted(tool_names):
                if length + len(name) + 2 > 42:
                    short_names.append("...")
                    break
                short_names.append(name)
                length += len(name) + 2
            colored_names = []
            for name in short_names:
                if name == "...":
                    colored_names.append("[dim]...[/]")
                elif name in disabled_tools:
                    colored_names.append(f"[red]{name}[/]")
                else:
                    colored_names.append(f"[{text}]{name}[/]")
            tools_str = ", ".join(colored_names)

        right_lines.append(f"[dim #006B3A]{toolset}:[/] {tools_str}")

    if remaining_toolsets > 0:
        right_lines.append(f"[dim #006B3A](and {remaining_toolsets} more toolsets...)[/]")

    # MCP Servers section (only if configured)
    try:
        from tools.mcp_tool import get_mcp_status
        mcp_status = get_mcp_status()
    except Exception:
        mcp_status = []

    if mcp_status:
        right_lines.append("")
        right_lines.append("[bold #87FF00]MCP Servers[/]")
        for srv in mcp_status:
            if srv["connected"]:
                right_lines.append(
                    f"[dim #006B3A]{srv['name']}[/] [#E0FFE0]({srv['transport']})[/] "
                    f"[dim #006B3A]—[/] [#E0FFE0]{srv['tools']} tool(s)[/]"
                )
            else:
                right_lines.append(
                    f"[red]{srv['name']}[/] [dim]({srv['transport']})[/] "
                    f"[red]— failed[/]"
                )

    right_lines.append("")
    right_lines.append(f"[bold {accent}]Available Skills[/]")
    skills_by_category = get_available_skills()
    total_skills = sum(len(s) for s in skills_by_category.values())

    if skills_by_category:
        for category in sorted(skills_by_category.keys()):
            skill_names = sorted(skills_by_category[category])
            if len(skill_names) > 8:
                display_names = skill_names[:8]
                skills_str = ", ".join(display_names) + f" +{len(skill_names) - 8} more"
            else:
                skills_str = ", ".join(skill_names)
            if len(skills_str) > 50:
                skills_str = skills_str[:47] + "..."
            right_lines.append(f"[dim {dim}]{category}:[/] [{text}]{skills_str}[/]")
    else:
        right_lines.append(f"[dim {dim}]No skills installed[/]")

    right_lines.append("")
    mcp_connected = sum(1 for s in mcp_status if s["connected"]) if mcp_status else 0
    summary_parts = [f"{len(tools)} tools", f"{total_skills} skills"]
    if mcp_connected:
        summary_parts.append(f"{mcp_connected} MCP servers")
    summary_parts.append("/help for commands")
    right_lines.append(f"[dim {dim}]{' · '.join(summary_parts)}[/]")

    # Update check — show if behind origin/main
    try:
        behind = check_for_updates()
        if behind and behind > 0:
            commits_word = "commit" if behind == 1 else "commits"
            right_lines.append(
                f"[bold yellow]⚠ {behind} {commits_word} behind[/]"
                f"[dim yellow] — run [bold]eaisports update[/bold] to update[/]"
            )
    except Exception:
        pass  # Never break the banner over an update check

    right_content = "\n".join(right_lines)
    layout_table.add_row(left_content, right_content)

    agent_name = _skin_branding("agent_name", "EAISports")
    title_color = _skin_color("banner_title", "#00FF87")
    border_color = _skin_color("banner_border", "#00CC6A")
    outer_panel = Panel(
        layout_table,
        title=f"[bold {title_color}]{agent_name} {VERSION}[/]",
        border_style=border_color,
        padding=(0, 2),
    )

    console.print()
    console.print(EAISPORTS_AGENT_LOGO)
    console.print()
    console.print(outer_panel)
