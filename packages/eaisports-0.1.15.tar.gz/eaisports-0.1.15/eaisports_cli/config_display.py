"""
Rich display for EAISports configuration.

Provides a formatted summary of the current EAISports config, env values,
installed skills, and relevant paths.
"""

from pathlib import Path
from typing import Dict, List

from eaisports_cli.colors import Colors, color
from eaisports_cli.config import (
    load_config,
    get_eaisports_home,
    get_config_path,
    get_env_path,
    get_env_value,
)


def _mask_key(value: str) -> str:
    """Mask an API key, showing first 6 and last 4 chars."""
    if not value:
        return color("not configured", Colors.DIM)
    if len(value) <= 12:
        return value[:2] + "..." + value[-2:]
    return value[:6] + "..." + value[-4:]


def _truncate_wallet(address: str) -> str:
    """Truncate a wallet address to first 4 and last 4 chars."""
    if not address:
        return color("not configured", Colors.DIM)
    if len(address) <= 10:
        return address
    return address[:4] + "..." + address[-4:]


def _detect_api_provider() -> str:
    """Detect which API provider is configured."""
    if get_env_value("OPENROUTER_API_KEY"):
        return "OpenRouter"
    if get_env_value("ANTHROPIC_API_KEY"):
        return "Anthropic (direct)"
    if get_env_value("OPENAI_API_KEY"):
        return "OpenAI"
    return color("not configured", Colors.DIM)


def _count_skills(eaisports_home: Path) -> tuple:
    """Count installed skills and return (count, list_of_names)."""
    skills_dir = eaisports_home / "skills"
    if not skills_dir.exists():
        return 0, []

    names = []
    for skill_file in skills_dir.rglob("SKILL.md"):
        rel_path = skill_file.relative_to(skills_dir)
        parts = rel_path.parts
        if len(parts) >= 2:
            names.append(parts[-2])
        else:
            names.append(skill_file.parent.name)
    return len(names), sorted(set(names))


def _primary_api_key() -> str:
    """Return the masked value of the first configured API key."""
    for key in ("OPENROUTER_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY"):
        val = get_env_value(key)
        if val:
            return _mask_key(val)
    return color("not configured", Colors.DIM)


def show_config_summary():
    """Print a rich summary of the current EAISports configuration."""
    config = load_config()
    home = get_eaisports_home()

    # Header
    print()
    print(color("  EAISports Configuration", Colors.CYAN, Colors.BOLD))
    print(color("  " + "\u2550" * 27, Colors.CYAN))
    print()

    # Core settings
    model = config.get("model", config.get("models", {}).get("primary", "not set"))
    wallet = config.get("wallet_address", "")
    provider = _detect_api_provider()
    api_key_display = _primary_api_key()

    print(f"  {color('Model:', Colors.BOLD):<26} {model}")
    print(f"  {color('Wallet:', Colors.BOLD):<26} {_truncate_wallet(wallet)}")
    print(f"  {color('API Provider:', Colors.BOLD):<26} {provider}")
    print(f"  {color('API Key:', Colors.BOLD):<26} {api_key_display}")

    # Build config
    build = config.get("build", {})
    budget = build.get("default_budget", 100)
    output_dir = build.get("output_dir", "games")
    # Resolve output_dir relative to home if it's not absolute
    if not Path(output_dir).is_absolute():
        output_display = f"~/.eaisports/{output_dir}/"
    else:
        output_display = output_dir

    print()
    print(f"  {color('Build Config:', Colors.BOLD)}")
    print(f"    Default budget:  {budget} iterations")
    print(f"    Output dir:      {output_display}")

    # Skills
    count, names = _count_skills(home)
    print()
    print(f"  {color('Skills:', Colors.BOLD)}")
    if count > 0:
        names_str = ", ".join(names)
        print(f"    {count} installed ({names_str})")
    else:
        print(f"    {color('none installed', Colors.DIM)}")

    # Paths
    config_path = get_config_path()
    env_path = get_env_path()
    games_dir = home / build.get("output_dir", "games")
    skills_dir = home / "skills"

    print()
    print(f"  {color('Paths:', Colors.BOLD)}")
    print(f"    Config:    {config_path}")
    print(f"    Env:       {env_path}")
    print(f"    Games:     {games_dir}/")
    print(f"    Skills:    {skills_dir}/")
    print()
