"""
EAISports Preview Command -- local Vite dev server launcher.

Launches a local Vite dev server to preview a built game in the browser.

Usage (from CLI):
    eaisports preview                  # pick from available games
    eaisports preview my-trivia-game   # preview a specific game
    eaisports preview --port 3000      # custom port
"""

import os
import signal
import subprocess
import sys
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Optional

from eaisports_cli.colors import Colors, color
from eaisports_cli.config import get_eaisports_home


# =========================================================================
# Helpers
# =========================================================================

def list_games() -> list[dict]:
    """Scan ~/.eaisports/games/ and return available games.

    Returns a list of dicts with keys: slug, path, modified.
    Sorted by most recently modified first.
    """
    games_dir = get_eaisports_home() / "games"
    if not games_dir.exists():
        return []

    games = []
    for entry in games_dir.iterdir():
        if entry.is_dir() and (entry / "package.json").exists():
            stat = entry.stat()
            games.append({
                "slug": entry.name,
                "path": entry,
                "modified": datetime.fromtimestamp(stat.st_mtime),
            })

    games.sort(key=lambda g: g["modified"], reverse=True)
    return games


# =========================================================================
# Preview runner
# =========================================================================

def run_preview(slug: Optional[str] = None, port: int = 5173) -> None:
    """Launch a local Vite dev server to preview a game.

    Parameters
    ----------
    slug:
        Game directory name under ~/.eaisports/games/.
        If None, lists available games and lets the user pick
        (or uses the most recently modified).
    port:
        Port for the Vite dev server. Defaults to 5173.
    """
    home = get_eaisports_home()
    games_dir = home / "games"

    # -- Resolve game directory
    if slug:
        game_dir = games_dir / slug
        if not game_dir.exists():
            print(color(f"  Game not found: {game_dir}", Colors.RED))
            sys.exit(1)
    else:
        games = list_games()
        if not games:
            print(color("  No games found in ~/.eaisports/games/", Colors.RED))
            print(color("  Run 'eaisports build' to create a game first.", Colors.DIM))
            sys.exit(1)

        if len(games) == 1:
            game_dir = games[0]["path"]
            slug = games[0]["slug"]
            print(color(f"  Auto-selected: {slug}", Colors.CYAN))
        else:
            print(color("  Available games:", Colors.BOLD))
            for i, g in enumerate(games, 1):
                mod = g["modified"].strftime("%Y-%m-%d %H:%M")
                print(color(f"    {i}. {g['slug']}", Colors.CYAN) + color(f"  ({mod})", Colors.DIM))
            print()
            try:
                choice = input("  Select a game (number) or press Enter for most recent: ").strip()
                if not choice:
                    idx = 0
                else:
                    idx = int(choice) - 1
                    if idx < 0 or idx >= len(games):
                        print(color("  Invalid selection.", Colors.RED))
                        sys.exit(1)
            except (ValueError, KeyboardInterrupt, EOFError):
                print()
                sys.exit(0)
            game_dir = games[idx]["path"]
            slug = games[idx]["slug"]

    # -- Verify package.json exists
    if not (game_dir / "package.json").exists():
        print(color(f"  No package.json found in {game_dir}", Colors.RED))
        print(color("  This directory does not appear to be a valid game project.", Colors.DIM))
        sys.exit(1)

    print(color(f"  Previewing: {slug}", Colors.CYAN))
    print(color(f"  Directory:  {game_dir}", Colors.DIM))

    # -- Install dependencies if needed
    if not (game_dir / "node_modules").exists():
        print(color("  Installing dependencies (npm install)...", Colors.YELLOW))
        result = subprocess.run(
            ["npm", "install"],
            cwd=str(game_dir),
            stdout=sys.stdout,
            stderr=sys.stderr,
        )
        if result.returncode != 0:
            print(color("  npm install failed.", Colors.RED))
            sys.exit(1)
        print()

    # -- Launch Vite dev server
    url = f"http://localhost:{port}"
    print(color(f"  Starting Vite dev server on {url}", Colors.GREEN))
    print(color("  Press Ctrl+C to stop.", Colors.DIM))
    print()

    proc = subprocess.Popen(
        ["npx", "vite", "--port", str(port)],
        cwd=str(game_dir),
        stdout=sys.stdout,
        stderr=sys.stderr,
    )

    # Attempt to open the browser
    try:
        webbrowser.open(url)
    except Exception:
        pass  # Non-fatal -- user can open manually

    # Wait for Ctrl+C, then terminate
    def _handle_sigint(signum, frame):
        print()
        print(color("  Stopping dev server...", Colors.YELLOW))
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        sys.exit(0)

    signal.signal(signal.SIGINT, _handle_sigint)

    try:
        proc.wait()
    except KeyboardInterrupt:
        _handle_sigint(None, None)
