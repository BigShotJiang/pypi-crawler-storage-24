"""
ConversationMixin — chat loop and conversation management extracted from EAISportsCLI.

All methods access ``self.*`` attributes set in ``EAISportsCLI.__init__``.
"""

import json
import shutil
import sys
import threading
import queue
from datetime import datetime
from typing import Optional

from eaisports_cli.banner import (
    cprint as _cprint, _GOLD, _GREEN, _BOLD, _DIM, _RST,
)


class ConversationMixin:
    """Chat loop and conversation management methods extracted from EAISportsCLI."""

    def chat(self, message, images: list = None) -> Optional[str]:
        """
        Send a message to the agent and get a response.

        Handles streaming output, interrupt detection (user typing while agent
        is working), and re-queueing of interrupted messages.

        Uses a dedicated _interrupt_queue (separate from _pending_input) to avoid
        race conditions between the process_loop and interrupt monitoring. Messages
        typed while the agent is running go to _interrupt_queue; messages typed while
        idle go to _pending_input.

        Args:
            message: The user's message (str or multimodal content list)
            images: Optional list of Path objects for attached images

        Returns:
            The agent's response, or None on error
        """
        # Refresh provider credentials if needed (handles key rotation transparently)
        if not self._ensure_runtime_credentials():
            return None

        # Initialize agent if needed
        if not self._init_agent():
            return None

        # Pre-process images through the vision tool (Gemini Flash) so the
        # main model receives text descriptions instead of raw base64 image
        # content — works with any model, not just vision-capable ones.
        if images:
            message = self._preprocess_images_with_vision(
                message if isinstance(message, str) else "", images
            )

        # Add user message to history
        self.conversation_history.append({"role": "user", "content": message})

        w = shutil.get_terminal_size().columns
        _cprint(f"{_GOLD}{'─' * w}{_RST}")
        print(flush=True)

        try:
            # Run the conversation with interrupt monitoring
            result = None

            def run_agent():
                nonlocal result
                result = self.agent.run_conversation(
                    user_message=message,
                    conversation_history=self.conversation_history[:-1],  # Exclude the message we just added
                    task_id=self.session_id,
                )

            # Start agent in background thread
            agent_thread = threading.Thread(target=run_agent)
            agent_thread.start()

            # Monitor the dedicated interrupt queue while the agent runs.
            # _interrupt_queue is separate from _pending_input, so process_loop
            # and chat() never compete for the same queue.
            # When a clarify question is active, user input is handled entirely
            # by the Enter key binding (routed to the clarify response queue),
            # so we skip interrupt processing to avoid stealing that input.
            interrupt_msg = None
            while agent_thread.is_alive():
                if hasattr(self, '_interrupt_queue'):
                    try:
                        interrupt_msg = self._interrupt_queue.get(timeout=0.1)
                        if interrupt_msg:
                            # If clarify is active, the Enter handler routes
                            # input directly; this queue shouldn't have anything.
                            # But if it does (race condition), don't interrupt.
                            if self._clarify_state or self._clarify_freetext:
                                continue
                            print(f"\n⚡ New message detected, interrupting...")
                            self.agent.interrupt(interrupt_msg)
                            break
                    except queue.Empty:
                        pass  # Queue empty or timeout, continue waiting
                else:
                    # Fallback for non-interactive mode (e.g., single-query)
                    agent_thread.join(0.1)

            agent_thread.join()  # Ensure agent thread completes

            # Drain any remaining agent output still in the StdoutProxy
            # buffer so tool/status lines render ABOVE our response box.
            # The flush pushes data into the renderer queue; the short
            # sleep lets the renderer actually paint it before we draw.
            import time as _time
            sys.stdout.flush()
            _time.sleep(0.15)

            # Update history with full conversation
            self.conversation_history = result.get("messages", self.conversation_history) if result else self.conversation_history

            # Get the final response
            response = result.get("final_response", "") if result else ""

            # Handle failed results (e.g., non-retryable errors like invalid model)
            if result and result.get("failed") and not response:
                error_detail = result.get("error", "Unknown error")
                response = f"Error: {error_detail}"

            # Handle interrupt - check if we were interrupted
            pending_message = None
            if result and result.get("interrupted"):
                pending_message = result.get("interrupt_message") or interrupt_msg
                # Add indicator that we were interrupted
                if response and pending_message:
                    response = response + "\n\n---\n_[Interrupted - processing new message]_"

            if response:
                w = shutil.get_terminal_size().columns
                # Use skin branding for response box label
                try:
                    from eaisports_cli.skin_engine import get_active_skin
                    _skin = get_active_skin()
                    label = _skin.get_branding("response_label", " ⚕ EAISports ")
                    _resp_color = _skin.get_color("response_border", "")
                    if _resp_color:
                        _resp_start = f"\033[38;2;{int(_resp_color[1:3], 16)};{int(_resp_color[3:5], 16)};{int(_resp_color[5:7], 16)}m"
                    else:
                        _resp_start = _GOLD
                except Exception:
                    label = " ⚕ EAISports "
                    _resp_start = _GOLD
                fill = w - 2 - len(label)  # 2 for ╭ and ╮
                top = f"{_resp_start}╭─{label}{'─' * max(fill - 1, 0)}╮{_RST}"
                bot = f"{_resp_start}╰{'─' * (w - 2)}╯{_RST}"

                # Render box + response as a single _cprint call so
                # nothing can interleave between the box borders.
                _cprint(f"\n{top}\n{response}\n\n{bot}")

            # Play terminal bell when agent finishes (if enabled).
            # Works over SSH — the bell propagates to the user's terminal.
            if self.bell_on_complete:
                sys.stdout.write("\a")
                sys.stdout.flush()

            # Combine all interrupt messages (user may have typed multiple while waiting)
            # and re-queue as one prompt for process_loop
            if pending_message and hasattr(self, '_pending_input'):
                all_parts = [pending_message]
                while not self._interrupt_queue.empty():
                    try:
                        extra = self._interrupt_queue.get_nowait()
                        if extra:
                            all_parts.append(extra)
                    except queue.Empty:
                        break
                combined = "\n".join(all_parts)
                print(f"\n📨 Queued: '{combined[:50]}{'...' if len(combined) > 50 else ''}'")
                self._pending_input.put(combined)

            return response

        except Exception as e:
            print(f"Error: {e}")
            return None

    def reset_conversation(self):
        """Reset the conversation history."""
        if self.agent and self.conversation_history:
            try:
                self.agent.flush_memories(self.conversation_history)
            except Exception:
                pass
        self.conversation_history = []
        print("(^_^)b Conversation reset!")

    def save_conversation(self):
        """Save the current conversation to a file."""
        if not self.conversation_history:
            print("(;_;) No conversation to save.")
            return

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"eaisports_conversation_{timestamp}.json"

        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump({
                    "model": self.model,
                    "session_start": self.session_start.isoformat(),
                    "messages": self.conversation_history,
                }, f, indent=2, ensure_ascii=False)
            print(f"(^_^)v Conversation saved to: {filename}")
        except Exception as e:
            print(f"(x_x) Failed to save: {e}")

    def retry_last(self):
        """Retry the last user message by removing the last exchange and re-sending.

        Removes the last assistant response (and any tool-call messages) and
        the last user message, then re-sends that user message to the agent.
        Returns the message to re-send, or None if there's nothing to retry.
        """
        if not self.conversation_history:
            print("(._.) No messages to retry.")
            return None

        # Walk backwards to find the last user message
        last_user_idx = None
        for i in range(len(self.conversation_history) - 1, -1, -1):
            if self.conversation_history[i].get("role") == "user":
                last_user_idx = i
                break

        if last_user_idx is None:
            print("(._.) No user message found to retry.")
            return None

        # Extract the message text and remove everything from that point forward
        last_message = self.conversation_history[last_user_idx].get("content", "")
        self.conversation_history = self.conversation_history[:last_user_idx]

        print(f"(^_^)b Retrying: \"{last_message[:60]}{'...' if len(last_message) > 60 else ''}\"")
        return last_message

    def undo_last(self):
        """Remove the last user/assistant exchange from conversation history.

        Walks backwards and removes all messages from the last user message
        onward (including assistant responses, tool calls, etc.).
        """
        if not self.conversation_history:
            print("(._.) No messages to undo.")
            return

        # Walk backwards to find the last user message
        last_user_idx = None
        for i in range(len(self.conversation_history) - 1, -1, -1):
            if self.conversation_history[i].get("role") == "user":
                last_user_idx = i
                break

        if last_user_idx is None:
            print("(._.) No user message found to undo.")
            return

        # Count how many messages we're removing
        removed_count = len(self.conversation_history) - last_user_idx
        removed_msg = self.conversation_history[last_user_idx].get("content", "")

        # Truncate history to before the last user message
        self.conversation_history = self.conversation_history[:last_user_idx]

        print(f"(^_^)b Undid {removed_count} message(s). Removed: \"{removed_msg[:60]}{'...' if len(removed_msg) > 60 else ''}\"")
        remaining = len(self.conversation_history)
        print(f"  {remaining} message(s) remaining in history.")

    def _print_exit_summary(self):
        """Print session resume info on exit, similar to Claude Code."""
        print()
        msg_count = len(self.conversation_history)
        if msg_count > 0:
            user_msgs = len([m for m in self.conversation_history if m.get("role") == "user"])
            tool_calls = len([m for m in self.conversation_history if m.get("role") == "tool" or m.get("tool_calls")])
            elapsed = datetime.now() - self.session_start
            hours, remainder = divmod(int(elapsed.total_seconds()), 3600)
            minutes, seconds = divmod(remainder, 60)
            if hours > 0:
                duration_str = f"{hours}h {minutes}m {seconds}s"
            elif minutes > 0:
                duration_str = f"{minutes}m {seconds}s"
            else:
                duration_str = f"{seconds}s"

            print(f"Resume this session with:")
            print(f"  eaisports --resume {self.session_id}")
            print()
            print(f"Session:        {self.session_id}")
            print(f"Duration:       {duration_str}")
            print(f"Messages:       {msg_count} ({user_msgs} user, {tool_calls} tool calls)")
        else:
            print("Goodbye! ⚕")
