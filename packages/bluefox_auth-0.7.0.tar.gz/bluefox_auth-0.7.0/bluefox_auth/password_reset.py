from collections.abc import Awaitable, Callable
from datetime import UTC, datetime

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bluefox_auth.models import BluefoxUser
from bluefox_auth.passwords import hash_password
from bluefox_auth.settings import AuthSettings
from bluefox_auth.tokens import InvalidTokenError, create_special_token, decode_token
from bluefox_auth.utils import normalize_email

# Type alias for the send function hook
SendResetFn = Callable[[str, str], Awaitable[None]]

PASSWORD_RESET_EXPIRE_MINUTES = 60


async def request_password_reset(
    session: AsyncSession,
    email: str,
    send_fn: SendResetFn,
    settings: AuthSettings,
    user_model: type[BluefoxUser] = BluefoxUser,
) -> None:
    """Request a password reset. Always returns silently to avoid email enumeration."""
    email = normalize_email(email)
    result = await session.execute(select(user_model).where(user_model.email == email))
    user = result.scalar_one_or_none()

    if user is None or not user.is_active:
        return

    token = create_special_token(
        user_id=user.id,
        token_type="password_reset",
        expire_minutes=PASSWORD_RESET_EXPIRE_MINUTES,
        settings=settings,
    )
    await send_fn(email, token)


async def confirm_password_reset(
    session: AsyncSession,
    token: str,
    new_password: str,
    settings: AuthSettings,
    user_model: type[BluefoxUser] = BluefoxUser,
) -> None:
    """Confirm a password reset by decoding the token and updating the password."""
    try:
        payload = decode_token(token, settings, expected_type="password_reset")
    except InvalidTokenError as err:
        raise HTTPException(400, "Invalid or expired reset token") from err

    result = await session.execute(select(user_model).where(user_model.id == payload.sub))
    user = result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise HTTPException(400, "Invalid or expired reset token")

    # One-time use: reject if user record was modified after token was issued.
    # We check updated_at > created_at to ignore the initial insert timestamp,
    # then verify the modification happened after the token's iat.
    if (
        user.updated_at
        and user.created_at
        and user.updated_at > user.created_at
        and user.updated_at >= payload.iat
    ):
        raise HTTPException(400, "Invalid or expired reset token")

    user.password_hash = hash_password(new_password)
    user.updated_at = datetime.now(UTC)
    await session.flush()
