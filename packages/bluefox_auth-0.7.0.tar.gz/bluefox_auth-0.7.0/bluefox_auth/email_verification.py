from collections.abc import Awaitable, Callable

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bluefox_auth.models import BluefoxUser
from bluefox_auth.settings import AuthSettings
from bluefox_auth.tokens import InvalidTokenError, create_special_token, decode_token

# Type alias for the send function hook
SendVerifyFn = Callable[[str, str], Awaitable[None]]

EMAIL_VERIFY_EXPIRE_MINUTES = 60 * 24  # 24 hours


async def request_email_verification(
    user: BluefoxUser,
    send_fn: SendVerifyFn,
    settings: AuthSettings,
) -> None:
    """Generate an email verification token and send it via the provided hook."""
    token = create_special_token(
        user_id=user.id,
        token_type="email_verify",
        expire_minutes=EMAIL_VERIFY_EXPIRE_MINUTES,
        settings=settings,
    )
    await send_fn(user.email, token)


async def confirm_email_verification(
    session: AsyncSession,
    token: str,
    settings: AuthSettings,
    user_model: type[BluefoxUser] = BluefoxUser,
) -> BluefoxUser:
    """Confirm email verification by decoding the token and setting email_verified."""
    try:
        payload = decode_token(token, settings, expected_type="email_verify")
    except InvalidTokenError as err:
        raise HTTPException(400, "Invalid or expired verification token") from err

    result = await session.execute(select(user_model).where(user_model.id == payload.sub))
    user = result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise HTTPException(400, "Invalid or expired verification token")

    # Reject if already verified (one-time use)
    if user.email_verified:
        raise HTTPException(400, "Invalid or expired verification token")

    user.email_verified = True
    await session.flush()
    return user
