from datetime import UTC, datetime, timedelta

from bluefox_core.database import get_session
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy.ext.asyncio import AsyncSession

from bluefox_auth.cookies import clear_auth_cookies, set_auth_cookies
from bluefox_auth.csrf import validate_csrf
from bluefox_auth.dependencies import _get_auth_settings, _get_user_model, current_active_user
from bluefox_auth.email_verification import confirm_email_verification, request_email_verification
from bluefox_auth.models import BluefoxUser
from bluefox_auth.password_reset import confirm_password_reset, request_password_reset
from bluefox_auth.schemas import (
    EmailVerificationRequest,
    LoginRequest,
    LogoutRequest,
    MessageResponse,
    PasswordResetConfirm,
    PasswordResetRequest,
    RefreshRequest,
    RegisterRequest,
    TokenResponse,
    UserResponse,
)
from bluefox_auth.service import (
    authenticate_user,
    create_refresh_token_record,
    refresh_tokens,
    register_user,
    revoke_token_family,
)
from bluefox_auth.tokens import InvalidTokenError, create_token_pair, decode_token

router = APIRouter()


@router.post("/register", response_model=UserResponse, status_code=201)
async def register(
    data: RegisterRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> BluefoxUser:
    settings = _get_auth_settings(request)
    user_model = _get_user_model(request)
    user = await register_user(session, data, settings, user_model)
    await session.commit()
    return user


@router.post("/login", response_model=TokenResponse)
async def login(
    data: LoginRequest,
    request: Request,
    response: Response,
    session: AsyncSession = Depends(get_session),
) -> TokenResponse:
    settings = _get_auth_settings(request)
    user_model = _get_user_model(request)
    user = await authenticate_user(session, data, settings, user_model)

    token_pair, refresh_jti, family_id = create_token_pair(user.id, settings)
    expires_at = datetime.now(UTC) + timedelta(days=settings.refresh_token_expire_days)
    await create_refresh_token_record(session, user.id, refresh_jti, family_id, expires_at)
    await session.commit()

    set_auth_cookies(response, token_pair.access_token, token_pair.refresh_token, settings)
    return TokenResponse(
        access_token=token_pair.access_token,
        refresh_token=token_pair.refresh_token,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh(
    request: Request,
    response: Response,
    session: AsyncSession = Depends(get_session),
    data: RefreshRequest | None = None,
) -> TokenResponse:
    settings = _get_auth_settings(request)
    user_model = _get_user_model(request)

    raw_token = data.refresh_token if data else None
    from_cookie = False
    if not raw_token:
        raw_token = request.cookies.get(settings.cookie_name_refresh)
        from_cookie = True
    if not raw_token:
        raise HTTPException(401, "No refresh token provided")

    # CSRF validation when token came from cookie
    if from_cookie:
        validate_csrf(request, settings.cookie_name_csrf)

    token_pair, _new_jti, _new_family = await refresh_tokens(
        session, raw_token, settings, user_model
    )
    await session.commit()

    set_auth_cookies(response, token_pair.access_token, token_pair.refresh_token, settings)
    return TokenResponse(
        access_token=token_pair.access_token,
        refresh_token=token_pair.refresh_token,
    )


@router.post("/logout")
async def logout(
    request: Request,
    response: Response,
    session: AsyncSession = Depends(get_session),
    data: LogoutRequest | None = None,
) -> dict[str, str]:
    settings = _get_auth_settings(request)

    raw_refresh = (
        data.refresh_token if data and data.refresh_token else None
    ) or request.cookies.get(settings.cookie_name_refresh)

    if raw_refresh:
        try:
            payload = decode_token(raw_refresh, settings, expected_type="refresh")
            await revoke_token_family(session, payload.jti)
            await session.commit()
        except InvalidTokenError:
            pass

    clear_auth_cookies(response, settings)
    return {"message": "Logged out"}


@router.get("/me", response_model=UserResponse)
async def me(user: BluefoxUser = Depends(current_active_user)) -> BluefoxUser:
    return user


@router.post("/password-reset", response_model=MessageResponse)
async def password_reset_request(
    data: PasswordResetRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> MessageResponse:
    settings = _get_auth_settings(request)
    user_model = _get_user_model(request)
    send_fn = getattr(request.app.state, "password_reset_send_fn", None)
    if send_fn is None:
        raise HTTPException(501, "Password reset is not configured")

    await request_password_reset(session, data.email, send_fn, settings, user_model)
    return MessageResponse(message="If that email exists, a reset link has been sent.")


@router.post("/password-reset/confirm", response_model=MessageResponse)
async def password_reset_confirm(
    data: PasswordResetConfirm,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> MessageResponse:
    settings = _get_auth_settings(request)
    user_model = _get_user_model(request)
    await confirm_password_reset(session, data.token, data.new_password, settings, user_model)
    await session.commit()
    return MessageResponse(message="Password has been reset.")


@router.post("/email-verification", response_model=MessageResponse)
async def email_verification_request(
    request: Request,
    user: BluefoxUser = Depends(current_active_user),
) -> MessageResponse:
    settings = _get_auth_settings(request)
    if user.email_verified:
        return MessageResponse(message="Email is already verified.")
    send_fn = getattr(request.app.state, "email_verify_send_fn", None)
    if send_fn is None:
        raise HTTPException(501, "Email verification is not configured")

    await request_email_verification(user, send_fn, settings)
    return MessageResponse(message="Verification email sent.")


@router.post("/email-verification/confirm", response_model=MessageResponse)
async def email_verification_confirm(
    data: EmailVerificationRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> MessageResponse:
    settings = _get_auth_settings(request)
    user_model = _get_user_model(request)
    await confirm_email_verification(session, data.token, settings, user_model)
    await session.commit()
    return MessageResponse(message="Email verified.")
