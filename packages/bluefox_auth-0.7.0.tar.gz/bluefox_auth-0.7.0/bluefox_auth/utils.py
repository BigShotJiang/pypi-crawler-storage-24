def normalize_email(email: str) -> str:
    """Normalize an email: strip whitespace, lowercase."""
    return email.strip().lower()
