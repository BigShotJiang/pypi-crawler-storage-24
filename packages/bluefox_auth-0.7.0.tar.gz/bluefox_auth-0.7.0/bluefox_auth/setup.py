from collections.abc import Awaitable, Callable
from typing import Any

from fastapi import FastAPI

from bluefox_auth.models import BluefoxUser
from bluefox_auth.routes import router
from bluefox_auth.settings import AuthSettings


class BluefoxAuth:
    """One-liner auth setup for Bluefox apps.

    Usage::

        from bluefox_auth import BluefoxAuth

        app = create_bluefox_app(settings)
        BluefoxAuth(app, settings)
    """

    def __init__(
        self,
        app: FastAPI,
        settings: Any,
        *,
        user_model: type[BluefoxUser] | None = None,
        prefix: str = "/auth",
        password_reset_send_fn: Callable[[str, str], Awaitable[None]] | None = None,
        email_verify_send_fn: Callable[[str, str], Awaitable[None]] | None = None,
        cookie_secure: bool | None = None,
        cookie_domain: str | None = None,
    ) -> None:
        secret_key = getattr(settings, "SECRET_KEY", None)
        if secret_key is None:
            raise ValueError(
                "settings must have a SECRET_KEY attribute. "
                "Use BluefoxSettings or pass an object with SECRET_KEY."
            )

        auth_kwargs: dict[str, Any] = {"secret_key": secret_key, "auth_prefix": prefix}
        if cookie_secure is not None:
            auth_kwargs["cookie_secure"] = cookie_secure
        if cookie_domain is not None:
            auth_kwargs["cookie_domain"] = cookie_domain

        auth_settings = AuthSettings(**auth_kwargs)

        app.state.auth_settings = auth_settings
        app.state.user_model = user_model or BluefoxUser

        if password_reset_send_fn is not None:
            app.state.password_reset_send_fn = password_reset_send_fn
        if email_verify_send_fn is not None:
            app.state.email_verify_send_fn = email_verify_send_fn

        app.include_router(router, prefix=prefix)

        self.app = app
        self.settings = auth_settings
