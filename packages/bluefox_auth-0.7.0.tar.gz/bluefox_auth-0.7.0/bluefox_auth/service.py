from datetime import UTC, datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from bluefox_auth.models import BluefoxUser, RefreshToken
from bluefox_auth.passwords import hash_password, verify_password_timing_safe
from bluefox_auth.schemas import LoginRequest, RegisterRequest
from bluefox_auth.settings import AuthSettings
from bluefox_auth.tokens import (
    InvalidTokenError,
    TokenPair,
    create_access_token,
    create_rotated_refresh_token,
    decode_token,
)
from bluefox_auth.utils import normalize_email


async def register_user(
    session: AsyncSession,
    data: RegisterRequest,
    settings: AuthSettings,
    user_model: type[BluefoxUser] = BluefoxUser,
) -> BluefoxUser:
    email = normalize_email(data.email)
    result = await session.execute(select(user_model).where(user_model.email == email))
    if result.scalar_one_or_none() is not None:
        raise HTTPException(409, "Email already registered")

    user = user_model(
        email=email,
        password_hash=hash_password(data.password),
    )
    session.add(user)
    await session.flush()
    await session.refresh(user)
    return user


async def authenticate_user(
    session: AsyncSession,
    data: LoginRequest,
    settings: AuthSettings,
    user_model: type[BluefoxUser] = BluefoxUser,
) -> BluefoxUser:
    email = normalize_email(data.email)
    result = await session.execute(select(user_model).where(user_model.email == email))
    user = result.scalar_one_or_none()

    if user is None:
        verify_password_timing_safe(data.password, None)
        raise HTTPException(401, "Invalid credentials")

    if not verify_password_timing_safe(data.password, user.password_hash):
        raise HTTPException(401, "Invalid credentials")

    if not user.is_active:
        raise HTTPException(401, "Invalid credentials")

    return user


async def create_refresh_token_record(
    session: AsyncSession,
    user_id: int,
    jti: str,
    family_id: str,
    expires_at: datetime,
) -> RefreshToken:
    record = RefreshToken(
        jti=jti,
        user_id=user_id,
        family_id=family_id,
        expires_at=expires_at,
    )
    session.add(record)
    await session.flush()
    return record


async def rotate_refresh_token(
    session: AsyncSession,
    old_jti: str,
    user_id: int,
    settings: AuthSettings,
) -> tuple[RefreshToken, str]:
    """Rotate a refresh token. Returns (new_db_record, new_jwt_string)."""
    result = await session.execute(select(RefreshToken).where(RefreshToken.jti == old_jti))
    old_record = result.scalar_one_or_none()

    if old_record is None:
        raise InvalidTokenError("Refresh token not found")

    if old_record.is_revoked:
        # Reuse detected — revoke entire family
        await session.execute(
            update(RefreshToken)
            .where(RefreshToken.family_id == old_record.family_id)
            .values(is_revoked=True)
        )
        await session.flush()
        raise HTTPException(401, "Token reuse detected")

    old_record.is_revoked = True

    new_token, new_jti = create_rotated_refresh_token(user_id, old_record.family_id, settings)
    new_expires_at = datetime.now(UTC) + timedelta(days=settings.refresh_token_expire_days)

    new_record = RefreshToken(
        jti=new_jti,
        user_id=user_id,
        family_id=old_record.family_id,
        expires_at=new_expires_at,
    )
    session.add(new_record)
    await session.flush()
    return new_record, new_token


async def refresh_tokens(
    session: AsyncSession,
    refresh_token_str: str,
    settings: AuthSettings,
    user_model: type[BluefoxUser] = BluefoxUser,
) -> tuple[TokenPair, str, str]:
    try:
        payload = decode_token(refresh_token_str, settings, expected_type="refresh")
    except InvalidTokenError as err:
        raise HTTPException(401, str(err)) from err

    result = await session.execute(select(user_model).where(user_model.id == payload.sub))
    user = result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise HTTPException(401, "User not found or inactive")

    new_record, new_refresh_token = await rotate_refresh_token(
        session, payload.jti, user.id, settings
    )

    access_token = create_access_token(user.id, settings)
    pair = TokenPair(access_token=access_token, refresh_token=new_refresh_token)
    return pair, new_record.jti, new_record.family_id


async def revoke_token_family(session: AsyncSession, jti: str) -> None:
    result = await session.execute(select(RefreshToken).where(RefreshToken.jti == jti))
    record = result.scalar_one_or_none()
    if record is None:
        return

    await session.execute(
        update(RefreshToken)
        .where(RefreshToken.family_id == record.family_id)
        .values(is_revoked=True)
    )
    await session.flush()
