from datetime import UTC, datetime, timedelta

from httpx import ASGITransport, AsyncClient

from bluefox_auth.models import BluefoxUser
from bluefox_auth.passwords import hash_password
from bluefox_auth.service import create_refresh_token_record
from bluefox_auth.tokens import create_access_token, create_token_pair


async def _create_user(
    db, email="test@example.com", password="correct-password", is_active=True, is_superuser=False
):
    user = BluefoxUser(
        email=email,
        password_hash=hash_password(password),
        is_active=is_active,
        is_superuser=is_superuser,
    )
    db.add(user)
    await db.flush()
    await db.refresh(user)
    return user


# --- Registration ---


async def test_register__creates_user(auth_client):
    resp = await auth_client.post(
        "/auth/register",
        json={"email": "new@example.com", "password": "strong-password"},
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["email"] == "new@example.com"
    assert data["is_active"] is True
    assert data["is_superuser"] is False


async def test_register__rejects_duplicate_email(auth_client, db):
    await _create_user(db)
    resp = await auth_client.post(
        "/auth/register",
        json={"email": "test@example.com", "password": "strong-password"},
    )
    assert resp.status_code == 409


async def test_register__rejects_invalid_email(auth_client):
    resp = await auth_client.post(
        "/auth/register",
        json={"email": "not-an-email", "password": "strong-password"},
    )
    assert resp.status_code == 422


async def test_register__rejects_short_password(auth_client):
    resp = await auth_client.post(
        "/auth/register",
        json={"email": "new@example.com", "password": "short"},
    )
    assert resp.status_code == 422


async def test_register__rejects_password_exceeding_72_bytes(auth_client):
    resp = await auth_client.post(
        "/auth/register",
        json={"email": "new@example.com", "password": "a" * 73},
    )
    assert resp.status_code == 422


async def test_register__hashes_password(auth_client, db):
    resp = await auth_client.post(
        "/auth/register",
        json={"email": "new@example.com", "password": "strong-password"},
    )
    assert resp.status_code == 201
    from sqlalchemy import select

    result = await db.execute(select(BluefoxUser).where(BluefoxUser.email == "new@example.com"))
    user = result.scalar_one()
    assert user.password_hash != "strong-password"
    assert user.password_hash.startswith("$2b$")


async def test_register__normalizes_email(auth_client):
    resp = await auth_client.post(
        "/auth/register",
        json={"email": "  Test@Example.COM  ", "password": "strong-password"},
    )
    assert resp.status_code == 201
    assert resp.json()["email"] == "test@example.com"


# --- Login ---


async def test_login__returns_tokens(auth_client, db):
    await _create_user(db)
    resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["token_type"] == "bearer"


async def test_login__sets_auth_cookies(auth_client, db, auth_settings):
    await _create_user(db)
    resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    assert resp.status_code == 200
    cookies = resp.cookies
    assert auth_settings.cookie_name_access in cookies
    assert auth_settings.cookie_name_csrf in cookies


async def test_login__rejects_wrong_password(auth_client, db):
    await _create_user(db)
    resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "wrong-password"},
    )
    assert resp.status_code == 401


async def test_login__rejects_unknown_email(auth_client):
    resp = await auth_client.post(
        "/auth/login",
        json={"email": "unknown@example.com", "password": "any-password"},
    )
    assert resp.status_code == 401


async def test_login__same_error_for_wrong_email_and_wrong_password(auth_client, db):
    await _create_user(db)
    resp_wrong_email = await auth_client.post(
        "/auth/login",
        json={"email": "unknown@example.com", "password": "any-password"},
    )
    resp_wrong_pw = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "wrong-password"},
    )
    assert resp_wrong_email.status_code == resp_wrong_pw.status_code == 401
    assert resp_wrong_email.json()["detail"] == resp_wrong_pw.json()["detail"]


async def test_login__rejects_inactive_user(auth_client, db):
    await _create_user(db, is_active=False)
    resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    assert resp.status_code == 401


async def test_login__normalizes_email(auth_client, db):
    await _create_user(db)
    resp = await auth_client.post(
        "/auth/login",
        json={"email": "  Test@Example.COM  ", "password": "correct-password"},
    )
    assert resp.status_code == 200


async def test_login__creates_refresh_token_record(auth_client, db):
    await _create_user(db)
    resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    assert resp.status_code == 200
    from sqlalchemy import select

    from bluefox_auth.models import RefreshToken

    result = await db.execute(select(RefreshToken))
    records = result.scalars().all()
    assert len(records) == 1
    assert records[0].is_revoked is False


# --- Refresh ---


async def test_refresh__returns_new_token_pair_from_json(auth_client, db, auth_settings):
    await _create_user(db)
    login_resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    old_refresh = login_resp.json()["refresh_token"]

    resp = await auth_client.post(
        "/auth/refresh",
        json={"refresh_token": old_refresh},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["access_token"] != login_resp.json()["access_token"]
    assert data["refresh_token"] != old_refresh


async def test_refresh__returns_new_token_pair_from_cookie(auth_app, db, auth_settings):
    async with AsyncClient(
        transport=ASGITransport(app=auth_app), base_url="http://testserver"
    ) as ac:
        await _create_user(db)
        login_resp = await ac.post(
            "/auth/login",
            json={"email": "test@example.com", "password": "correct-password"},
        )

        # Extract refresh and CSRF cookies
        refresh_cookie = login_resp.cookies.get(auth_settings.cookie_name_refresh)
        csrf_cookie = login_resp.cookies.get(auth_settings.cookie_name_csrf)
        assert refresh_cookie is not None
        assert csrf_cookie is not None

        ac.cookies.set(auth_settings.cookie_name_refresh, refresh_cookie)
        ac.cookies.set(auth_settings.cookie_name_csrf, csrf_cookie)
        resp = await ac.post("/auth/refresh", headers={"X-CSRF-Token": csrf_cookie})
    assert resp.status_code == 200


async def test_refresh__cookie_requires_csrf(auth_app, db, auth_settings):
    """POST /refresh with cookie transport must include CSRF token."""
    async with AsyncClient(
        transport=ASGITransport(app=auth_app), base_url="http://testserver"
    ) as ac:
        await _create_user(db)
        login_resp = await ac.post(
            "/auth/login",
            json={"email": "test@example.com", "password": "correct-password"},
        )
        refresh_cookie = login_resp.cookies.get(auth_settings.cookie_name_refresh)
        assert refresh_cookie is not None

        ac.cookies.set(auth_settings.cookie_name_refresh, refresh_cookie)
        resp = await ac.post("/auth/refresh")
    assert resp.status_code == 403


async def test_refresh__rotates_token(auth_client, db, auth_settings):
    await _create_user(db)
    login_resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    old_refresh = login_resp.json()["refresh_token"]

    await auth_client.post("/auth/refresh", json={"refresh_token": old_refresh})

    from sqlalchemy import select

    from bluefox_auth.models import RefreshToken

    result = await db.execute(select(RefreshToken).order_by(RefreshToken.id))
    records = result.scalars().all()
    assert len(records) == 2
    assert records[0].is_revoked is True  # old
    assert records[1].is_revoked is False  # new


async def test_refresh__old_token_invalid_after_rotation(auth_client, db, auth_settings):
    await _create_user(db)
    login_resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    old_refresh = login_resp.json()["refresh_token"]

    # First refresh succeeds
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": old_refresh})
    assert resp.status_code == 200

    # Replay old token — should fail
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": old_refresh})
    assert resp.status_code == 401


async def test_refresh__reuse_detection_revokes_family(auth_client, db, auth_settings):
    await _create_user(db)
    login_resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    old_refresh = login_resp.json()["refresh_token"]

    # Rotate once: A -> B
    resp_b = await auth_client.post("/auth/refresh", json={"refresh_token": old_refresh})
    assert resp_b.status_code == 200
    new_refresh = resp_b.json()["refresh_token"]

    # Replay A — reuse detected, family revoked
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": old_refresh})
    assert resp.status_code == 401

    # B should also be invalid now (family revoked)
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": new_refresh})
    assert resp.status_code == 401


async def test_refresh__rejects_access_token(auth_client, db, auth_settings):
    await _create_user(db)
    login_resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    access_token = login_resp.json()["access_token"]

    resp = await auth_client.post("/auth/refresh", json={"refresh_token": access_token})
    assert resp.status_code == 401


async def test_refresh__rejects_expired_token(auth_client, db, auth_settings):
    user = await _create_user(db)

    # Create a token pair with negative expiry
    from bluefox_auth.settings import AuthSettings

    expired_settings = AuthSettings(
        secret_key=auth_settings.secret_key,
        refresh_token_expire_days=-1,
        cookie_secure=False,
    )
    pair, jti, family_id = create_token_pair(user.id, expired_settings)
    expires_at = datetime.now(UTC) - timedelta(days=1)
    await create_refresh_token_record(db, user.id, jti, family_id, expires_at)
    await db.flush()

    resp = await auth_client.post("/auth/refresh", json={"refresh_token": pair.refresh_token})
    assert resp.status_code == 401


# --- Logout ---


async def test_logout__clears_cookies(auth_client, auth_settings):
    resp = await auth_client.post("/auth/logout")
    assert resp.status_code == 200
    # Check that deletion cookies are set
    raw_headers = [(k, v) for k, v in resp.headers.multi_items() if k == "set-cookie"]
    cookie_names = [v.split("=")[0] for _, v in raw_headers]
    assert auth_settings.cookie_name_access in cookie_names
    assert auth_settings.cookie_name_refresh in cookie_names
    assert auth_settings.cookie_name_csrf in cookie_names


async def test_logout__revokes_token_family(auth_client, db, auth_settings):
    await _create_user(db)
    login_resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    refresh_token = login_resp.json()["refresh_token"]

    resp = await auth_client.post("/auth/logout", json={"refresh_token": refresh_token})
    assert resp.status_code == 200

    from sqlalchemy import select

    from bluefox_auth.models import RefreshToken

    result = await db.execute(select(RefreshToken))
    records = result.scalars().all()
    assert all(r.is_revoked for r in records)


async def test_logout__works_without_auth(auth_client):
    resp = await auth_client.post("/auth/logout")
    assert resp.status_code == 200
    assert resp.json()["message"] == "Logged out"


async def test_logout__json_body_revokes_token(auth_client, db, auth_settings):
    await _create_user(db)
    login_resp = await auth_client.post(
        "/auth/login",
        json={"email": "test@example.com", "password": "correct-password"},
    )
    refresh_token = login_resp.json()["refresh_token"]

    resp = await auth_client.post("/auth/logout", json={"refresh_token": refresh_token})
    assert resp.status_code == 200

    # Token should no longer work for refresh
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": refresh_token})
    assert resp.status_code == 401


# --- Me ---


async def test_me__returns_user_with_bearer(auth_client, db, auth_settings):
    user = await _create_user(db)
    token = create_access_token(user.id, auth_settings)

    resp = await auth_client.get("/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert resp.status_code == 200
    assert resp.json()["email"] == "test@example.com"


async def test_me__returns_user_with_cookie(auth_app, db, auth_settings):
    async with AsyncClient(
        transport=ASGITransport(app=auth_app), base_url="http://testserver"
    ) as ac:
        await _create_user(db)
        login_resp = await ac.post(
            "/auth/login",
            json={"email": "test@example.com", "password": "correct-password"},
        )
        access_cookie = login_resp.cookies.get(auth_settings.cookie_name_access)
        assert access_cookie is not None

        ac.cookies.set(auth_settings.cookie_name_access, access_cookie)
        resp = await ac.get("/auth/me")
    assert resp.status_code == 200
    assert resp.json()["email"] == "test@example.com"


async def test_me__rejects_unauthenticated(auth_client):
    resp = await auth_client.get("/auth/me")
    assert resp.status_code == 401
