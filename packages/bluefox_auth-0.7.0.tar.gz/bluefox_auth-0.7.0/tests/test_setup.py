from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from fastapi import FastAPI

from bluefox_auth.models import BluefoxUser
from bluefox_auth.setup import BluefoxAuth

TEST_SECRET = "test-secret-key-that-is-long-enough-for-validation"


def _make_settings(**overrides):
    defaults = {"SECRET_KEY": TEST_SECRET}
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


# --- Mounting and state ---


def test_bluefox_auth__mounts_auth_routes():
    app = FastAPI()
    BluefoxAuth(app, _make_settings())
    paths = [route.path for route in app.routes if hasattr(route, "path")]
    assert "/auth/login" in paths
    assert "/auth/register" in paths
    assert "/auth/refresh" in paths
    assert "/auth/logout" in paths
    assert "/auth/me" in paths
    assert "/auth/password-reset" in paths
    assert "/auth/email-verification/confirm" in paths


def test_bluefox_auth__stores_settings_in_state():
    app = FastAPI()
    auth = BluefoxAuth(app, _make_settings())
    assert app.state.auth_settings is auth.settings
    assert app.state.auth_settings.secret_key == TEST_SECRET


def test_bluefox_auth__secret_key_excluded_from_repr_and_dump():
    app = FastAPI()
    auth = BluefoxAuth(app, _make_settings())
    assert TEST_SECRET not in repr(auth.settings)
    assert "secret_key" not in auth.settings.model_dump()


def test_bluefox_auth__stores_default_user_model():
    app = FastAPI()
    BluefoxAuth(app, _make_settings())
    assert app.state.user_model is BluefoxUser


# --- Secret key validation ---


def test_bluefox_auth__rejects_missing_secret_key():
    app = FastAPI()
    with pytest.raises(ValueError, match="SECRET_KEY"):
        BluefoxAuth(app, SimpleNamespace())


def test_bluefox_auth__rejects_placeholder_secret_key():
    app = FastAPI()
    with pytest.raises(ValueError, match="secret_key must be explicitly set"):
        BluefoxAuth(app, _make_settings(SECRET_KEY="change-me-in-production"))


def test_bluefox_auth__rejects_short_secret_key():
    app = FastAPI()
    with pytest.raises(ValueError, match="at least 32"):
        BluefoxAuth(app, _make_settings(SECRET_KEY="too-short"))


# --- Custom configuration ---


def test_bluefox_auth__custom_prefix():
    app = FastAPI()
    auth = BluefoxAuth(app, _make_settings(), prefix="/api/auth")
    paths = [route.path for route in app.routes if hasattr(route, "path")]
    assert "/api/auth/login" in paths
    assert "/auth/login" not in paths
    assert auth.settings.auth_prefix == "/api/auth"


def test_bluefox_auth__custom_user_model():
    """When user_model is passed, it's stored on app.state instead of the default."""
    app = FastAPI()
    # In real usage, this would be a subclass of BluefoxUser with extra columns.
    # We verify the passed model is stored, not the default.
    BluefoxAuth(app, _make_settings(), user_model=BluefoxUser)
    assert app.state.user_model is BluefoxUser


def test_bluefox_auth__cookie_secure_override():
    app = FastAPI()
    auth = BluefoxAuth(app, _make_settings(), cookie_secure=False)
    assert auth.settings.cookie_secure is False


def test_bluefox_auth__cookie_domain_override():
    app = FastAPI()
    auth = BluefoxAuth(app, _make_settings(), cookie_domain=".example.com")
    assert auth.settings.cookie_domain == ".example.com"


# --- Password reset / email verify hooks ---


def test_bluefox_auth__password_reset_disabled_by_default():
    app = FastAPI()
    BluefoxAuth(app, _make_settings())
    assert not hasattr(app.state, "password_reset_send_fn")


def test_bluefox_auth__password_reset_enabled_with_hook():
    app = FastAPI()
    send_fn = AsyncMock()
    BluefoxAuth(app, _make_settings(), password_reset_send_fn=send_fn)
    assert app.state.password_reset_send_fn is send_fn


def test_bluefox_auth__email_verify_disabled_by_default():
    app = FastAPI()
    BluefoxAuth(app, _make_settings())
    assert not hasattr(app.state, "email_verify_send_fn")


def test_bluefox_auth__email_verify_enabled_with_hook():
    app = FastAPI()
    send_fn = AsyncMock()
    BluefoxAuth(app, _make_settings(), email_verify_send_fn=send_fn)
    assert app.state.email_verify_send_fn is send_fn
