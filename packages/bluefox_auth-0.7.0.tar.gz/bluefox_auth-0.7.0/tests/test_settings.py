import pytest

from bluefox_auth.settings import AuthSettings

VALID_KEY = "a" * 32


def test_auth_settings__accepts_valid_key():
    s = AuthSettings(secret_key=VALID_KEY)
    assert s.secret_key == VALID_KEY


def test_auth_settings__defaults():
    s = AuthSettings(secret_key=VALID_KEY)
    assert s.algorithm == "HS256"
    assert s.access_token_expire_minutes == 30
    assert s.refresh_token_expire_days == 7
    assert s.token_audience == "bluefox"
    assert s.cookie_secure is True
    assert s.cookie_samesite == "lax"
    assert s.password_min_length == 8
    assert s.password_max_bytes == 72


def test_auth_settings__rejects_empty_key():
    with pytest.raises(ValueError, match="strong, unique value"):
        AuthSettings(secret_key="")


def test_auth_settings__rejects_placeholder_keys():
    for placeholder in ["change-me-in-production", "secret", "changeme"]:
        with pytest.raises(ValueError, match="strong, unique value"):
            AuthSettings(secret_key=placeholder)


def test_auth_settings__rejects_short_key():
    with pytest.raises(ValueError, match="at least 32 characters"):
        AuthSettings(secret_key="too-short")
