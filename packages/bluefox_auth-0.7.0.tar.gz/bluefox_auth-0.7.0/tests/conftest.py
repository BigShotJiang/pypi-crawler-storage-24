import pytest
import pytest_asyncio
from bluefox_core.database import BluefoxBase, get_session
from bluefox_test import bluefox_test_setup
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from bluefox_auth.settings import AuthSettings

globals().update(
    bluefox_test_setup(
        base=BluefoxBase,
        app_factory=None,
        session_dependency=None,
    )
)

TEST_SECRET = "test-secret-key-that-is-long-enough-for-validation"


@pytest.fixture
def auth_settings():
    return AuthSettings(secret_key=TEST_SECRET, cookie_secure=False)


@pytest.fixture
def app(db, auth_settings):
    """FastAPI app with auth settings and session override (no routes mounted)."""
    from bluefox_auth.models import BluefoxUser

    application = FastAPI()
    application.state.auth_settings = auth_settings
    application.state.user_model = BluefoxUser

    async def _override_session():
        yield db

    application.dependency_overrides[get_session] = _override_session
    yield application
    application.dependency_overrides.clear()


@pytest.fixture
def auth_app(db, auth_settings):
    """FastAPI app with auth router mounted."""
    from bluefox_auth.models import BluefoxUser
    from bluefox_auth.routes import router

    application = FastAPI()
    application.state.auth_settings = auth_settings
    application.state.user_model = BluefoxUser
    application.include_router(router, prefix="/auth")

    async def _override_session():
        yield db

    application.dependency_overrides[get_session] = _override_session
    yield application
    application.dependency_overrides.clear()


@pytest_asyncio.fixture
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac


@pytest_asyncio.fixture
async def auth_client(auth_app):
    transport = ASGITransport(app=auth_app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac
