from bluefox_auth.passwords import hash_password, verify_password, verify_password_timing_safe


def test_hash_password__returns_bcrypt_hash():
    hashed = hash_password("my-password")
    assert hashed.startswith("$2b$")


def test_verify_password__correct_password():
    hashed = hash_password("correct-horse")
    assert verify_password("correct-horse", hashed) is True


def test_verify_password__wrong_password():
    hashed = hash_password("correct-horse")
    assert verify_password("wrong-horse", hashed) is False


def test_hash_password__different_salts():
    h1 = hash_password("same-password")
    h2 = hash_password("same-password")
    assert h1 != h2


def test_hash_password__rejects_over_72_bytes():
    """Documents the bcrypt limitation: passwords over 72 bytes raise ValueError."""
    import pytest

    over_limit = "a" * 73
    with pytest.raises(ValueError, match="72 bytes"):
        hash_password(over_limit)


def test_verify_password_timing_safe__correct_password():
    hashed = hash_password("safe-pass")
    assert verify_password_timing_safe("safe-pass", hashed) is True


def test_verify_password_timing_safe__wrong_password():
    hashed = hash_password("safe-pass")
    assert verify_password_timing_safe("wrong-pass", hashed) is False


def test_verify_password_timing_safe__none_hash_returns_false():
    # Should still run bcrypt (against dummy hash) but return False
    assert verify_password_timing_safe("any-password", None) is False
