"""Phase 7: Full lifecycle integration tests.

These tests exercise complete auth flows end-to-end, as a real client would use them.
"""

from httpx import ASGITransport, AsyncClient

EMAIL = "integration@example.com"
PASSWORD = "integration-password-123"


async def _register(client: AsyncClient) -> dict:
    resp = await client.post("/auth/register", json={"email": EMAIL, "password": PASSWORD})
    assert resp.status_code == 201
    return resp.json()


async def _login(client: AsyncClient) -> dict:
    resp = await client.post("/auth/login", json={"email": EMAIL, "password": PASSWORD})
    assert resp.status_code == 200
    return resp.json()


# --- Bearer transport lifecycle ---


async def test_full_lifecycle__bearer(auth_client):
    """Register → Login → /me → Refresh → old token rejected → /me with new token → Logout."""
    # 1. Register
    user_data = await _register(auth_client)
    assert user_data["email"] == EMAIL
    assert user_data["is_active"] is True

    # 2. Login — get tokens
    tokens = await _login(auth_client)
    access = tokens["access_token"]
    refresh = tokens["refresh_token"]

    # 3. /me with access token
    resp = await auth_client.get("/auth/me", headers={"Authorization": f"Bearer {access}"})
    assert resp.status_code == 200
    assert resp.json()["email"] == EMAIL

    # 4. Refresh — get new tokens
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": refresh})
    assert resp.status_code == 200
    new_tokens = resp.json()
    new_access = new_tokens["access_token"]
    new_refresh = new_tokens["refresh_token"]
    assert new_access != access
    assert new_refresh != refresh

    # 5. Old refresh token is now invalid
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": refresh})
    assert resp.status_code == 401

    # 6. /me works with new access token
    resp = await auth_client.get("/auth/me", headers={"Authorization": f"Bearer {new_access}"})
    assert resp.status_code == 200
    assert resp.json()["email"] == EMAIL

    # 7. Logout with new refresh token
    resp = await auth_client.post("/auth/logout", json={"refresh_token": new_refresh})
    assert resp.status_code == 200

    # 8. Refresh with new token fails after logout (family revoked)
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": new_refresh})
    assert resp.status_code == 401


# --- Cookie transport lifecycle ---


async def test_full_lifecycle__cookie(auth_app, db, auth_settings):
    """Register → Login (cookies) → GET /me (no CSRF) → POST refresh (CSRF) → Logout."""
    async with AsyncClient(
        transport=ASGITransport(app=auth_app), base_url="http://testserver"
    ) as ac:
        # 1. Register
        resp = await ac.post("/auth/register", json={"email": EMAIL, "password": PASSWORD})
        assert resp.status_code == 201

        # 2. Login — cookies are set in response
        login_resp = await ac.post("/auth/login", json={"email": EMAIL, "password": PASSWORD})
        assert login_resp.status_code == 200

        access_cookie = login_resp.cookies.get(auth_settings.cookie_name_access)
        refresh_cookie = login_resp.cookies.get(auth_settings.cookie_name_refresh)
        csrf_cookie = login_resp.cookies.get(auth_settings.cookie_name_csrf)
        assert access_cookie is not None
        assert refresh_cookie is not None
        assert csrf_cookie is not None

        # 3. GET /me — works with cookie, no CSRF needed for safe methods
        ac.cookies.set(auth_settings.cookie_name_access, access_cookie)
        resp = await ac.get("/auth/me")
        assert resp.status_code == 200
        assert resp.json()["email"] == EMAIL

        # 4. POST /refresh via cookie — requires CSRF
        ac.cookies.set(auth_settings.cookie_name_refresh, refresh_cookie)
        ac.cookies.set(auth_settings.cookie_name_csrf, csrf_cookie)

        # 4a. Without CSRF header → 403
        resp = await ac.post("/auth/refresh")
        assert resp.status_code == 403

        # 4b. With CSRF header → 200
        resp = await ac.post("/auth/refresh", headers={"X-CSRF-Token": csrf_cookie})
        assert resp.status_code == 200

        # Extract new cookies from refresh response
        new_access = resp.cookies.get(auth_settings.cookie_name_access)
        new_refresh = resp.cookies.get(auth_settings.cookie_name_refresh)
        new_csrf = resp.cookies.get(auth_settings.cookie_name_csrf)
        assert new_access is not None
        assert new_refresh is not None
        assert new_csrf is not None
        assert new_access != access_cookie
        assert new_refresh != refresh_cookie

        # 5. /me with new access cookie
        ac.cookies.set(auth_settings.cookie_name_access, new_access)
        resp = await ac.get("/auth/me")
        assert resp.status_code == 200
        assert resp.json()["email"] == EMAIL

        # 6. Logout — clears cookies
        ac.cookies.set(auth_settings.cookie_name_csrf, new_csrf)
        resp = await ac.post("/auth/logout", headers={"X-CSRF-Token": new_csrf})
        assert resp.status_code == 200

        # 7. Old refresh cookie no longer works after logout
        ac.cookies.set(auth_settings.cookie_name_refresh, new_refresh)
        ac.cookies.set(auth_settings.cookie_name_csrf, new_csrf)
        resp = await ac.post("/auth/refresh", headers={"X-CSRF-Token": new_csrf})
        assert resp.status_code == 401


# --- Refresh token reuse detection (full flow) ---


async def test_refresh_token_reuse_detection(auth_client):
    """Login → Refresh (A→B) → Replay A → Family revoked → B also invalid."""
    await _register(auth_client)
    tokens = await _login(auth_client)
    token_a = tokens["refresh_token"]

    # Rotate: A → B
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": token_a})
    assert resp.status_code == 200
    token_b = resp.json()["refresh_token"]

    # Rotate: B → C (proves B works)
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": token_b})
    assert resp.status_code == 200
    token_c = resp.json()["refresh_token"]

    # Replay A — reuse detected, entire family revoked
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": token_a})
    assert resp.status_code == 401

    # B is now invalid (already revoked from rotation)
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": token_b})
    assert resp.status_code == 401

    # C is also invalid (family revoked)
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": token_c})
    assert resp.status_code == 401


# --- Cross-transport: login via API, access via cookie ---


async def test_cross_transport__bearer_login_cookie_access(auth_app, db, auth_settings):
    """Login via Bearer (JSON body) → use access token as cookie for /me."""
    async with AsyncClient(
        transport=ASGITransport(app=auth_app), base_url="http://testserver"
    ) as ac:
        # Register and login via JSON
        await ac.post("/auth/register", json={"email": EMAIL, "password": PASSWORD})
        login_resp = await ac.post("/auth/login", json={"email": EMAIL, "password": PASSWORD})
        assert login_resp.status_code == 200

        # Login returns both JSON tokens AND cookies
        access_token_json = login_resp.json()["access_token"]
        access_cookie = login_resp.cookies.get(auth_settings.cookie_name_access)
        assert access_cookie is not None
        # The cookie value should be the same token
        assert access_cookie == access_token_json

        # Use cookie transport for /me
        ac.cookies.set(auth_settings.cookie_name_access, access_cookie)
        resp = await ac.get("/auth/me")
        assert resp.status_code == 200
        assert resp.json()["email"] == EMAIL


# --- Multiple users don't interfere ---


async def test_independent_sessions(auth_client):
    """Two users' refresh tokens are in separate families."""
    # Register and login user 1
    await auth_client.post(
        "/auth/register", json={"email": "user1@example.com", "password": "password-one-123"}
    )
    login1 = await auth_client.post(
        "/auth/login", json={"email": "user1@example.com", "password": "password-one-123"}
    )
    refresh1 = login1.json()["refresh_token"]

    # Register and login user 2
    await auth_client.post(
        "/auth/register", json={"email": "user2@example.com", "password": "password-two-456"}
    )
    login2 = await auth_client.post(
        "/auth/login", json={"email": "user2@example.com", "password": "password-two-456"}
    )
    refresh2 = login2.json()["refresh_token"]

    # Refresh user 1 — should not affect user 2
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": refresh1})
    assert resp.status_code == 200

    # User 2's token still works
    resp = await auth_client.post("/auth/refresh", json={"refresh_token": refresh2})
    assert resp.status_code == 200


# --- Logout then login again ---


async def test_relogin_after_logout(auth_client):
    """After logout, a fresh login produces working tokens."""
    await _register(auth_client)

    # First session
    tokens1 = await _login(auth_client)
    resp = await auth_client.post("/auth/logout", json={"refresh_token": tokens1["refresh_token"]})
    assert resp.status_code == 200

    # Old tokens don't work
    resp = await auth_client.post(
        "/auth/refresh", json={"refresh_token": tokens1["refresh_token"]}
    )
    assert resp.status_code == 401

    # New login produces fresh working tokens
    tokens2 = await _login(auth_client)
    assert tokens2["refresh_token"] != tokens1["refresh_token"]

    resp = await auth_client.get(
        "/auth/me", headers={"Authorization": f"Bearer {tokens2['access_token']}"}
    )
    assert resp.status_code == 200
    assert resp.json()["email"] == EMAIL
