from unittest.mock import AsyncMock

from bluefox_auth.models import BluefoxUser
from bluefox_auth.passwords import hash_password, verify_password
from bluefox_auth.settings import AuthSettings
from bluefox_auth.tokens import create_special_token


async def _create_user(db, email="test@example.com", password="correct-password", is_active=True):
    user = BluefoxUser(
        email=email,
        password_hash=hash_password(password),
        is_active=is_active,
    )
    db.add(user)
    await db.flush()
    await db.refresh(user)
    return user


# --- Request password reset ---


async def test_password_reset__generates_token_and_calls_send_fn(auth_client, db, auth_settings):
    await _create_user(db)
    send_fn = AsyncMock()
    auth_client._transport.app.state.password_reset_send_fn = send_fn

    resp = await auth_client.post(
        "/auth/password-reset",
        json={"email": "test@example.com"},
    )
    assert resp.status_code == 200
    assert "reset link has been sent" in resp.json()["message"]
    send_fn.assert_awaited_once()
    call_args = send_fn.call_args
    assert call_args[0][0] == "test@example.com"
    assert isinstance(call_args[0][1], str)  # token


async def test_password_reset__silent_on_unknown_email(auth_client, db, auth_settings):
    send_fn = AsyncMock()
    auth_client._transport.app.state.password_reset_send_fn = send_fn

    resp = await auth_client.post(
        "/auth/password-reset",
        json={"email": "unknown@example.com"},
    )
    assert resp.status_code == 200
    assert "reset link has been sent" in resp.json()["message"]
    send_fn.assert_not_awaited()


async def test_password_reset__silent_on_inactive_user(auth_client, db, auth_settings):
    await _create_user(db, is_active=False)
    send_fn = AsyncMock()
    auth_client._transport.app.state.password_reset_send_fn = send_fn

    resp = await auth_client.post(
        "/auth/password-reset",
        json={"email": "test@example.com"},
    )
    assert resp.status_code == 200
    send_fn.assert_not_awaited()


async def test_password_reset__501_when_not_configured(auth_client):
    resp = await auth_client.post(
        "/auth/password-reset",
        json={"email": "test@example.com"},
    )
    assert resp.status_code == 501


async def test_password_reset__normalizes_email(auth_client, db, auth_settings):
    await _create_user(db)
    send_fn = AsyncMock()
    auth_client._transport.app.state.password_reset_send_fn = send_fn

    resp = await auth_client.post(
        "/auth/password-reset",
        json={"email": "  Test@Example.COM  "},
    )
    assert resp.status_code == 200
    send_fn.assert_awaited_once()


# --- Confirm password reset ---


async def test_password_reset_confirm__updates_password(auth_client, db, auth_settings):
    user = await _create_user(db)
    token = create_special_token(user.id, "password_reset", 60, auth_settings)
    auth_client._transport.app.state.password_reset_send_fn = AsyncMock()

    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": token, "new_password": "new-strong-password"},
    )
    assert resp.status_code == 200

    await db.refresh(user)
    assert verify_password("new-strong-password", user.password_hash)
    assert not verify_password("correct-password", user.password_hash)


async def test_password_reset_confirm__rejects_expired_token(auth_client, db, auth_settings):
    user = await _create_user(db)
    expired_settings = AuthSettings(
        secret_key=auth_settings.secret_key,
        cookie_secure=False,
    )
    token = create_special_token(user.id, "password_reset", -1, expired_settings)

    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": token, "new_password": "new-strong-password"},
    )
    assert resp.status_code == 400


async def test_password_reset_confirm__rejects_invalid_token(auth_client):
    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": "invalid-token", "new_password": "new-strong-password"},
    )
    assert resp.status_code == 400


async def test_password_reset_confirm__rejects_access_token(auth_client, db, auth_settings):
    """A regular access token should not work for password reset."""
    user = await _create_user(db)
    token = create_special_token(user.id, "access", 60, auth_settings)

    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": token, "new_password": "new-strong-password"},
    )
    assert resp.status_code == 400


async def test_password_reset_confirm__rejects_short_password(auth_client, db, auth_settings):
    user = await _create_user(db)
    token = create_special_token(user.id, "password_reset", 60, auth_settings)

    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": token, "new_password": "short"},
    )
    assert resp.status_code == 422


async def test_password_reset_confirm__rejects_inactive_user(auth_client, db, auth_settings):
    user = await _create_user(db, is_active=False)
    token = create_special_token(user.id, "password_reset", 60, auth_settings)

    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": token, "new_password": "new-strong-password"},
    )
    assert resp.status_code == 400


async def test_password_reset_confirm__rejects_replayed_token(auth_client, db, auth_settings):
    """A token used once should not work a second time."""
    user = await _create_user(db)
    token = create_special_token(user.id, "password_reset", 60, auth_settings)

    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": token, "new_password": "new-strong-password"},
    )
    assert resp.status_code == 200

    # Replay the same token
    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": token, "new_password": "another-password"},
    )
    assert resp.status_code == 400


async def test_password_reset_confirm__rejects_email_verify_token(auth_client, db, auth_settings):
    """An email_verify token should not work for password reset."""
    user = await _create_user(db)
    token = create_special_token(user.id, "email_verify", 60, auth_settings)

    resp = await auth_client.post(
        "/auth/password-reset/confirm",
        json={"token": token, "new_password": "new-strong-password"},
    )
    assert resp.status_code == 400
