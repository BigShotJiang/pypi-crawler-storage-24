import pytest
from pydantic import ValidationError

from bluefox_auth.schemas import RegisterRequest


def test_register_request__valid():
    req = RegisterRequest(email="Test@Example.com", password="validpass")
    # EmailStr normalizes domain but preserves local part case;
    # full normalization happens in the service layer via normalize_email()
    assert req.email == "Test@example.com"


def test_register_request__rejects_short_password():
    with pytest.raises(ValidationError, match="at least 8"):
        RegisterRequest(email="a@b.com", password="short")


def test_register_request__rejects_password_exceeding_72_bytes():
    # 73 ASCII chars = 73 bytes
    long_pw = "a" * 73
    with pytest.raises(ValidationError, match="72 bytes"):
        RegisterRequest(email="a@b.com", password=long_pw)


def test_register_request__rejects_invalid_email():
    with pytest.raises(ValidationError):
        RegisterRequest(email="not-an-email", password="validpass")
