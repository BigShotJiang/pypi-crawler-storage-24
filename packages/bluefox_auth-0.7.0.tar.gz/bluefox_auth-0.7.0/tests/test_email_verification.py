from unittest.mock import AsyncMock

from bluefox_auth.models import BluefoxUser
from bluefox_auth.passwords import hash_password
from bluefox_auth.settings import AuthSettings
from bluefox_auth.tokens import create_access_token, create_special_token


async def _create_user(db, email="test@example.com", email_verified=False):
    user = BluefoxUser(
        email=email,
        password_hash=hash_password("test-password"),
        email_verified=email_verified,
    )
    db.add(user)
    await db.flush()
    await db.refresh(user)
    return user


# --- Request email verification ---


async def test_email_verification__sends_token(auth_client, db, auth_settings):
    user = await _create_user(db)
    send_fn = AsyncMock()
    auth_client._transport.app.state.email_verify_send_fn = send_fn
    token = create_access_token(user.id, auth_settings)

    resp = await auth_client.post(
        "/auth/email-verification",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200
    assert resp.json()["message"] == "Verification email sent."
    send_fn.assert_awaited_once()
    call_args = send_fn.call_args
    assert call_args[0][0] == "test@example.com"
    assert isinstance(call_args[0][1], str)  # token


async def test_email_verification__requires_auth(auth_client):
    resp = await auth_client.post("/auth/email-verification")
    assert resp.status_code == 401


async def test_email_verification__501_when_not_configured(auth_client, db, auth_settings):
    user = await _create_user(db)
    token = create_access_token(user.id, auth_settings)

    resp = await auth_client.post(
        "/auth/email-verification",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 501


# --- Confirm email verification ---


async def test_email_verification_confirm__sets_verified(auth_client, db, auth_settings):
    user = await _create_user(db)
    token = create_special_token(user.id, "email_verify", 60 * 24, auth_settings)

    resp = await auth_client.post(
        "/auth/email-verification/confirm",
        json={"token": token},
    )
    assert resp.status_code == 200
    assert resp.json()["message"] == "Email verified."

    await db.refresh(user)
    assert user.email_verified is True


async def test_email_verification_confirm__rejects_invalid_token(auth_client):
    resp = await auth_client.post(
        "/auth/email-verification/confirm",
        json={"token": "invalid-token"},
    )
    assert resp.status_code == 400


async def test_email_verification_confirm__rejects_expired_token(auth_client, db, auth_settings):
    user = await _create_user(db)
    expired_settings = AuthSettings(
        secret_key=auth_settings.secret_key,
        cookie_secure=False,
    )
    token = create_special_token(user.id, "email_verify", -1, expired_settings)

    resp = await auth_client.post(
        "/auth/email-verification/confirm",
        json={"token": token},
    )
    assert resp.status_code == 400


async def test_email_verification_confirm__rejects_wrong_token_type(
    auth_client, db, auth_settings
):
    """A password_reset token should not work for email verification."""
    user = await _create_user(db)
    token = create_special_token(user.id, "password_reset", 60, auth_settings)

    resp = await auth_client.post(
        "/auth/email-verification/confirm",
        json={"token": token},
    )
    assert resp.status_code == 400


async def test_email_verification_confirm__rejects_inactive_user(auth_client, db, auth_settings):
    user = await _create_user(db)
    user.is_active = False
    await db.flush()
    token = create_special_token(user.id, "email_verify", 60 * 24, auth_settings)

    resp = await auth_client.post(
        "/auth/email-verification/confirm",
        json={"token": token},
    )
    assert resp.status_code == 400


async def test_email_verification_confirm__rejects_already_verified(
    auth_client, db, auth_settings
):
    """A token used once should not work a second time."""
    user = await _create_user(db)
    token = create_special_token(user.id, "email_verify", 60 * 24, auth_settings)

    resp = await auth_client.post(
        "/auth/email-verification/confirm",
        json={"token": token},
    )
    assert resp.status_code == 200

    # Replay the same token
    resp = await auth_client.post(
        "/auth/email-verification/confirm",
        json={"token": token},
    )
    assert resp.status_code == 400


async def test_email_verification__skips_send_if_already_verified(auth_client, db, auth_settings):
    user = await _create_user(db, email_verified=True)
    send_fn = AsyncMock()
    auth_client._transport.app.state.email_verify_send_fn = send_fn
    token = create_access_token(user.id, auth_settings)

    resp = await auth_client.post(
        "/auth/email-verification",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200
    assert resp.json()["message"] == "Email is already verified."
    send_fn.assert_not_awaited()
