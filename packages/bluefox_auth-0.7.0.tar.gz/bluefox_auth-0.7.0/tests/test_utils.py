from bluefox_auth.utils import normalize_email


def test_normalize_email__lowercases():
    assert normalize_email("Hugo@Example.COM") == "hugo@example.com"


def test_normalize_email__strips_whitespace():
    assert normalize_email("  user@example.com  ") == "user@example.com"


def test_normalize_email__combined():
    assert normalize_email("  Hugo@Example.COM  ") == "hugo@example.com"
