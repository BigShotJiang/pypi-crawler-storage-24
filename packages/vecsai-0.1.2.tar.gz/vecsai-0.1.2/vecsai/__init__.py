from .client import VecsaiClient


def client(host="localhost", port=8137):
	return VecsaiClient(host=host, port=port)


__all__ = ["VecsaiClient", "client"]
