"""Inscript — universal agent activity ledger.

Records what AI agents do: which project they're in, what files they
touch, what they change. Any tool reads ~/.inscript/ for context.

Usage:
    from inscript_pkg import active_project, active_session

    project = active_project()   # Path or None
    session = active_session()   # session ID or None
"""
from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

__version__ = "0.7.0"

INSCRIPT_DIR = Path.home() / ".inscript"
ACTIVE_PROJECT_FILE = INSCRIPT_DIR / "active_project"
ACTIVE_SESSION_FILE = INSCRIPT_DIR / "active_session"
SESSIONS_DIR = INSCRIPT_DIR / "sessions"
OVERLAP_DIR = INSCRIPT_DIR / "overlap"
CONFIG_FILE = INSCRIPT_DIR / "config.toml"

DEFAULT_CONFIG = {
    "retention": {"policy": "30d", "max_storage": "1GB", "store_diffs": True},
    "overlap": {"enabled": True},
}


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def _load_config() -> dict:
    if not CONFIG_FILE.exists():
        return DEFAULT_CONFIG
    try:
        import tomllib
        return tomllib.loads(CONFIG_FILE.read_text())
    except Exception:
        return DEFAULT_CONFIG


def store_diffs() -> bool:
    return _load_config().get("retention", {}).get("store_diffs", True)


# ---------------------------------------------------------------------------
# Active project
# ---------------------------------------------------------------------------

def active_project() -> Path | None:
    try:
        text = ACTIVE_PROJECT_FILE.read_text().strip()
        if text:
            p = Path(text)
            if p.is_dir():
                return p
    except (OSError, ValueError):
        pass
    return None


def set_active_project(path: str | Path) -> None:
    INSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
    ACTIVE_PROJECT_FILE.write_text(str(Path(path).resolve()) + "\n")


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------

def active_session() -> str | None:
    try:
        return ACTIVE_SESSION_FILE.read_text().strip() or None
    except OSError:
        return None


def session_dir(session_id: str) -> Path:
    return SESSIONS_DIR / session_id


def _format_tokens(n: int) -> str:
    """Format token count: 1234 -> 1.2k, 1234567 -> 1.2M."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    elif n >= 1_000:
        return f"{n / 1_000:.1f}k"
    return str(n)


def list_sessions() -> list[dict]:
    sessions = []
    if not SESSIONS_DIR.exists():
        return sessions
    for d in sorted(SESSIONS_DIR.iterdir(), reverse=True):
        meta_file = d / "meta.json"
        if meta_file.exists():
            try:
                meta = json.loads(meta_file.read_text())
                meta["session_id"] = d.name
                sessions.append(meta)
            except (json.JSONDecodeError, OSError):
                pass
    return sessions


def active_sessions() -> list[dict]:
    return [s for s in list_sessions() if s.get("status") == "active"]


# ---------------------------------------------------------------------------
# Overlap
# ---------------------------------------------------------------------------

def project_hash(project_path: str) -> str:
    return hashlib.sha256(project_path.encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli() -> None:
    import sys
    args = sys.argv[1:]
    if not args:
        _cmd_status()
        return

    commands = {
        "init": _cmd_init,
        "status": lambda: _cmd_status(),
        "log": lambda: _cmd_log(args[1] if len(args) > 1 else None),
        "overlap": _cmd_overlap,
        "cleanup": _cmd_cleanup,
        "export": lambda: _cmd_export(args[1]) if len(args) > 1 else print("Usage: inscript export <session-id>", file=sys.stderr),
        "set": lambda: (set_active_project(args[1]), print(f"Active project: {Path(args[1]).resolve()}")) if len(args) > 1 else print("Usage: inscript set <path>", file=sys.stderr),
        "tag": lambda: _cmd_tag(args[1] if len(args) > 1 else None),
        "untag": lambda: _cmd_tag(None),
        "time": lambda: _cmd_time(args[1] if len(args) > 1 else None),
        "help": _cmd_help, "--help": _cmd_help, "-h": _cmd_help,
    }

    handler = commands.get(args[0])
    if handler:
        handler()
    else:
        print(f"Unknown command: {args[0]}", file=sys.stderr)
        _cmd_help()
        sys.exit(1)


def _cmd_help():
    print("""inscript — universal agent activity ledger

Commands:
  inscript              Show status
  inscript init         Set up retention and storage options
  inscript log [id]     Activity log for a session (latest if omitted)
  inscript overlap      File collisions across concurrent sessions
  inscript cleanup      Enforce retention policy
  inscript export <id>  Export session as markdown
  inscript set <path>   Manually set active project
  inscript tag <name>   Tag current work with a feature/task name
  inscript untag        Clear the current tag
  inscript time [tag]   Show time spent, optionally filtered by tag""")


def _cmd_init():
    INSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
    print("inscript setup\n")
    sd = input("Store raw diffs? [Y/n]: ").strip().lower()
    policy = input("Retention [forever/30d/7d] (default 30d): ").strip() or "30d"
    max_storage = input("Max storage [unlimited/1GB/500MB] (default 1GB): ").strip() or "1GB"

    CONFIG_FILE.write_text(f"""[retention]
policy = "{policy}"
max_storage = "{max_storage}"
store_diffs = {'true' if sd != 'n' else 'false'}

[overlap]
enabled = true
""")
    print(f"\nConfig written to {CONFIG_FILE}")


def _cmd_status():
    proj = active_project()
    sess = active_session()

    print(f"Project: {proj or 'none'}")

    if sess:
        sdir = session_dir(sess)
        meta_file = sdir / "meta.json"
        if meta_file.exists():
            meta = json.loads(meta_file.read_text())
            touches_file = sdir / "touches.jsonl"
            touch_count = sum(1 for _ in touches_file.open()) if touches_file.exists() else 0
            print(f"Session: {sess} (started {meta.get('start_time', '?')}, {touch_count} touches)")
        else:
            print(f"Session: {sess}")
    else:
        print("Session: none")

    others = [s for s in active_sessions() if s.get("session_id") != sess]
    if others:
        print(f"\nOther active sessions: {len(others)}")
        for s in others[:5]:
            print(f"  {s['session_id']} — {s.get('project', '?')}")


def _load_prompts(sdir: Path) -> list[dict]:
    """Load prompts for a session."""
    prompts_file = sdir / "prompts.jsonl"
    if not prompts_file.exists():
        return []
    prompts = []
    for line in prompts_file.open():
        try:
            prompts.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return prompts


def _cmd_log(session_id: str | None):
    if session_id is None:
        session_id = active_session()
    if session_id is None:
        sessions = list_sessions()
        if not sessions:
            print("No sessions found", file=__import__("sys").stderr)
            return
        session_id = sessions[0]["session_id"]

    sdir = session_dir(session_id)
    touches_file = sdir / "touches.jsonl"
    if not touches_file.exists():
        print(f"No activity log for {session_id}", file=__import__("sys").stderr)
        return

    prompts = _load_prompts(sdir)

    # Group touches by prompt_idx
    touches_by_prompt: dict[int | None, list[dict]] = {}
    files_seen = set()
    edits = 0
    for line in touches_file.open():
        try:
            e = json.loads(line)
            pidx = e.get("prompt_idx")
            touches_by_prompt.setdefault(pidx, []).append(e)
            files_seen.add(e.get("file"))
            if e.get("action") in ("edit", "write"):
                edits += 1
        except json.JSONDecodeError:
            pass

    print(f"Session: {session_id}\n")

    if prompts:
        for p in prompts:
            idx = p.get("idx", 0)
            prompt_text = p.get("prompt", "")
            # Truncate long prompts
            if len(prompt_text) > 80:
                prompt_text = prompt_text[:77] + "..."
            print(f"  [{p.get('ts', '?')}] \"{prompt_text}\"")
            for t in touches_by_prompt.get(idx, []):
                extra = f" ({t['lines_changed']} lines)" if t.get("lines_changed") else ""
                print(f"    {t.get('action', '?'):6s}  {t.get('file', '?')}{extra}")
            print()
    else:
        # No prompts recorded — flat list
        for line in touches_file.open():
            try:
                e = json.loads(line)
                extra = f" ({e['lines_changed']} lines)" if e.get("lines_changed") else ""
                print(f"  {e.get('ts', '?')}  {e.get('action', '?'):6s}  {e.get('file', '?')}{extra}")
            except json.JSONDecodeError:
                pass

    # Show token usage if summary exists
    summary_file = sdir / "summary.json"
    token_str = ""
    if summary_file.exists():
        try:
            s = json.loads(summary_file.read_text())
            tokens = s.get("tokens")
            if tokens:
                total = tokens.get("total_tokens", 0)
                token_str = f", {_format_tokens(total)} tokens"
        except (json.JSONDecodeError, OSError):
            pass

    print(f"  {len(files_seen)} files, {edits} edits, {len(prompts)} prompts{token_str}")


def _cmd_tag(tag_name: str | None):
    """Set or clear the active tag for the current session."""
    sess = active_session()
    if not sess:
        print("No active session", file=__import__("sys").stderr)
        __import__("sys").exit(1)

    sdir = session_dir(sess)
    tag_file = sdir / "active_tag"

    if tag_name is None:
        # Clear tag
        try:
            tag_file.unlink()
        except OSError:
            pass
        print("Tag cleared")
    else:
        tag_file.write_text(tag_name + "\n")
        print(f"Tagged: {tag_name}")


def _format_duration(seconds: int) -> str:
    """Format seconds into human-readable duration."""
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        m, s = divmod(seconds, 60)
        return f"{m}m {s}s"
    else:
        h, remainder = divmod(seconds, 3600)
        m, s = divmod(remainder, 60)
        return f"{h}h {m}m"


def _cmd_time(tag_filter: str | None):
    """Show time spent, optionally filtered by tag."""
    all_sessions = list_sessions()
    if not all_sessions:
        print("No sessions found")
        return

    # Collect timing data from prompts across all sessions
    tag_data: dict[str | None, dict] = {}  # tag -> {sessions, prompts, first_ts, last_ts, active_seconds, files, edits}

    for s in all_sessions:
        sid = s["session_id"]
        sdir = session_dir(sid)
        prompts = _load_prompts(sdir)
        touches_file = sdir / "touches.jsonl"

        # Load touches
        touches: list[dict] = []
        if touches_file.exists():
            for line in touches_file.open():
                try:
                    touches.append(json.loads(line))
                except json.JSONDecodeError:
                    pass

        if not prompts:
            continue

        # Compute time per prompt block
        for i, p in enumerate(prompts):
            tag = p.get("tag")
            if tag_filter and tag != tag_filter:
                continue

            # Parse this prompt's timestamp
            prompt_ts = p.get("ts", "")

            # Find next prompt's timestamp (or session end) for duration
            if i + 1 < len(prompts):
                next_ts = prompts[i + 1].get("ts", "")
            else:
                # Use last touch timestamp or summary end_time
                summary_file = sdir / "summary.json"
                if summary_file.exists():
                    try:
                        summary = json.loads(summary_file.read_text())
                        end = summary.get("end_time", "")
                        next_ts = end.split("T")[-1] if "T" in end else ""
                    except (json.JSONDecodeError, OSError):
                        next_ts = ""
                else:
                    # Use last touch
                    block_touches = [t for t in touches if t.get("prompt_idx") == p.get("idx")]
                    next_ts = block_touches[-1].get("ts", "") if block_touches else ""

            # Compute duration for this prompt block
            block_seconds = _ts_diff(prompt_ts, next_ts)

            # Count files and edits for this block
            block_touches = [t for t in touches if t.get("prompt_idx") == p.get("idx")]
            block_files = {t.get("file") for t in block_touches}
            block_edits = sum(1 for t in block_touches if t.get("action") in ("edit", "write"))

            # Aggregate by tag
            if tag not in tag_data:
                tag_data[tag] = {
                    "sessions": set(),
                    "prompts": 0,
                    "active_seconds": 0,
                    "first_ts": s.get("start_time", ""),
                    "last_ts": s.get("start_time", ""),
                    "files": set(),
                    "edits": 0,
                    "prompt_texts": [],
                }

            td = tag_data[tag]
            td["sessions"].add(sid)
            td["prompts"] += 1
            td["active_seconds"] += block_seconds
            td["files"].update(block_files)
            td["edits"] += block_edits
            td["prompt_texts"].append(p.get("prompt", ""))
            # Track first/last
            session_time = s.get("start_time", "")
            if session_time < td["first_ts"] or not td["first_ts"]:
                td["first_ts"] = session_time
            if session_time > td["last_ts"]:
                td["last_ts"] = session_time

    if not tag_data:
        if tag_filter:
            print(f"No data for tag: {tag_filter}")
        else:
            print("No prompt data found")
        return

    # Display
    if tag_filter:
        # Single tag detail view
        td = tag_data.get(tag_filter)
        if not td:
            print(f"No data for tag: {tag_filter}")
            return
        print(f"Feature: {tag_filter}\n")
        print(f"  Sessions:     {len(td['sessions'])}")
        print(f"  Prompts:      {td['prompts']}")
        print(f"  Active time:  {_format_duration(td['active_seconds'])}")
        print(f"  Files:        {len(td['files'])}")
        print(f"  Edits:        {td['edits']}")
        print(f"  First:        {td['first_ts']}")
        print(f"  Last:         {td['last_ts']}")
        print(f"\n  Prompts:")
        for pt in td["prompt_texts"]:
            display = pt[:70] + "..." if len(pt) > 70 else pt
            print(f"    - \"{display}\"")
    else:
        # Overview of all tags
        print("Time by tag:\n")
        # Sort: tagged first (alphabetical), then untagged
        sorted_tags = sorted(
            tag_data.keys(),
            key=lambda t: (t is None, t or "")
        )
        for tag in sorted_tags:
            td = tag_data[tag]
            label = tag or "(untagged)"
            print(f"  {label}")
            print(f"    {_format_duration(td['active_seconds'])} active, {td['prompts']} prompts, {td['edits']} edits, {len(td['sessions'])} sessions")
            print()


def _ts_diff(ts1: str, ts2: str) -> int:
    """Compute seconds between two HH:MM:SS timestamps. Returns 0 on failure."""
    try:
        parts1 = [int(x) for x in ts1.split(":")]
        parts2 = [int(x) for x in ts2.split(":")]
        s1 = parts1[0] * 3600 + parts1[1] * 60 + parts1[2]
        s2 = parts2[0] * 3600 + parts2[1] * 60 + parts2[2]
        diff = s2 - s1
        return max(0, diff)  # Clamp negative (midnight crossing edge case)
    except (ValueError, IndexError):
        return 0


def _cmd_overlap():
    if not OVERLAP_DIR.exists():
        print("No overlap data")
        return
    for f in sorted(OVERLAP_DIR.iterdir()):
        if f.suffix != ".jsonl":
            continue
        entries = []
        for line in f.open():
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        if entries:
            print(f"Project: {entries[0].get('project', f.stem)}")
            for e in entries[-10:]:
                print(f"  {e.get('ts', '?')}  {e.get('file', '?')}  sessions: {e.get('sessions', [])}")
            print()


def _cmd_cleanup():
    config = _load_config()
    policy = config.get("retention", {}).get("policy", "30d")
    if policy == "forever":
        print("Retention: forever. Nothing to clean.")
        return

    days = 30
    if policy.endswith("d"):
        try:
            days = int(policy[:-1])
        except ValueError:
            pass

    cutoff = time.time() - (days * 86400)
    removed = 0
    if SESSIONS_DIR.exists():
        import shutil
        for d in list(SESSIONS_DIR.iterdir()):
            try:
                if d.stat().st_mtime < cutoff:
                    shutil.rmtree(d)
                    removed += 1
            except OSError:
                pass
    print(f"Removed {removed} sessions older than {days} days")


def _cmd_export(session_id: str):
    sdir = session_dir(session_id)
    meta_file = sdir / "meta.json"
    if not meta_file.exists():
        print(f"Session {session_id} not found", file=__import__("sys").stderr)
        __import__("sys").exit(1)

    meta = json.loads(meta_file.read_text())
    summary_file = sdir / "summary.json"
    touches_file = sdir / "touches.jsonl"
    diffs_file = sdir / "diffs.jsonl"

    print(f"# Session {session_id}\n")
    print(f"- **Project**: {meta.get('project', '?')}")
    print(f"- **Started**: {meta.get('start_time', '?')}")

    if summary_file.exists():
        s = json.loads(summary_file.read_text())
        print(f"- **Ended**: {s.get('end_time', '?')}")
        if s.get("duration_seconds"):
            print(f"- **Duration**: {_format_duration(s['duration_seconds'])}")
        print(f"- **Prompts**: {s.get('prompts', '?')}")
        print(f"- **Files read**: {s.get('files_read', '?')}")
        print(f"- **Files written**: {s.get('files_written', '?')}")
        print(f"- **Total edits**: {s.get('total_edits', '?')}")
        tokens = s.get("tokens")
        if tokens:
            print(f"- **Model**: {tokens.get('model', '?')}")
            print(f"- **Tokens**: {_format_tokens(tokens.get('total_tokens', 0))} total ({_format_tokens(tokens.get('input_tokens', 0))} in, {_format_tokens(tokens.get('output_tokens', 0))} out)")
            if tokens.get("cache_read_tokens"):
                print(f"- **Cache**: {_format_tokens(tokens['cache_read_tokens'])} read, {_format_tokens(tokens.get('cache_write_tokens', 0))} written")

    # Load prompts, touches, and diffs
    prompts = _load_prompts(sdir)

    touches_by_prompt: dict[int | None, list[dict]] = {}
    if touches_file.exists():
        for line in touches_file.open():
            try:
                e = json.loads(line)
                touches_by_prompt.setdefault(e.get("prompt_idx"), []).append(e)
            except json.JSONDecodeError:
                pass

    diffs_by_prompt: dict[int | None, list[dict]] = {}
    if diffs_file.exists():
        for line in diffs_file.open():
            try:
                d = json.loads(line)
                diffs_by_prompt.setdefault(d.get("prompt_idx"), []).append(d)
            except json.JSONDecodeError:
                pass

    if prompts:
        # Group output by prompt
        for p in prompts:
            idx = p.get("idx", 0)
            print(f"\n## \"{p.get('prompt', '?')}\"\n")
            print(f"*{p.get('ts', '')}*\n")

            touches = touches_by_prompt.get(idx, [])
            if touches:
                print("| Action | File | Details |")
                print("|--------|------|---------|")
                for t in touches:
                    details = ""
                    if t.get("lines_changed"):
                        details = f"{t['lines_changed']} lines"
                    elif t.get("lines"):
                        details = f"{t['lines']} lines"
                    print(f"| {t.get('action', '')} | `{t.get('file', '')}` | {details} |")
                print()

            diffs = diffs_by_prompt.get(idx, [])
            for d in diffs:
                if d.get("old_string") is not None:
                    print(f"**`{d.get('file', '?')}`**")
                    print(f"```diff\n- {d['old_string']}\n+ {d.get('new_string', '')}\n```\n")
                elif d.get("is_new"):
                    print(f"**`{d.get('file', '?')}`** — new file ({d.get('lines', '?')} lines)\n")
    else:
        # No prompts — flat output
        if touches_by_prompt:
            print(f"\n## Activity\n")
            print("| Time | Action | File |")
            print("|------|--------|------|")
            for touches in touches_by_prompt.values():
                for e in touches:
                    print(f"| {e.get('ts', '')} | {e.get('action', '')} | `{e.get('file', '')}` |")

        if diffs_by_prompt:
            print(f"\n## Changes\n")
            for diffs in diffs_by_prompt.values():
                for d in diffs:
                    if d.get("old_string") is not None:
                        print(f"### `{d.get('file', '?')}` ({d.get('ts', '')})\n")
                        print(f"```diff\n- {d['old_string']}\n+ {d.get('new_string', '')}\n```\n")
                    elif d.get("is_new"):
                        print(f"New file `{d.get('file', '?')}` ({d.get('lines', '?')} lines)\n")
