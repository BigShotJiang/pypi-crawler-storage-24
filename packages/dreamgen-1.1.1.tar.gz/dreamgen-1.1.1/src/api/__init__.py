"""FastAPI backend for continuous image generation."""
