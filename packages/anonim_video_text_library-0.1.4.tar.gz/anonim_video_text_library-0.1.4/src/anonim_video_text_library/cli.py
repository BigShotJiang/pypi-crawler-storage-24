from __future__ import annotations

import os
from pathlib import Path

from . import constants


def build_runtime_readme_text(runtime_root: Path) -> str:
    runtime_root_display = runtime_root.as_posix()
    return f"""# Рабочая папка анонимайзера

Эта папка была автоматически создана библиотекой `anonim_video_text_library`
при первом запуске.

## Что здесь находится

- `files/pii/people.json` — словарь всех найденных тегов (`PERSON_*`, `ORG_*`, `EMAIL_*`, `PHONE_*` и т.д.)
- `files/pii/person_blocklist.txt` — blacklist для полных персон
- `files/pii/person_name_blocklist.txt` — blacklist для одиночных имен
- `files/pii/org_blocklist.txt` — blacklist для организаций
- `files/pii_anonymized/` — сюда можно писать анонимизированные результаты

## Как использовать

Если вы запускаете библиотеку из Python, указывайте этот `runtime_root`:

```python
from pathlib import Path
from anonim_video_text_library import TextAnonymizationSession

session = TextAnonymizationSession.from_defaults(
    runtime_root=Path("{runtime_root_display}"),
    device="auto",
)
```

Если вы запускаете CLI:

```bash
python -m anonim_video_text_library --help
```

или

```bash
python text_anonim/anonimizer.py --help
```

## Важно

- `people.json` пополняется по мере работы пайплайна
- если удалить `people.json`, он будет собран заново при следующем запуске
- этот `README.md` создается только один раз и дальше не перезаписывается
"""


def ensure_runtime_readme(runtime_root: Path) -> Path:
    runtime_root.mkdir(parents=True, exist_ok=True)
    readme_path = runtime_root / "README.md"
    if readme_path.exists():
        return readme_path
    readme_path.write_text(build_runtime_readme_text(runtime_root), encoding="utf-8")
    return readme_path


def discover_runtime_root(explicit_root: str | Path | None = None) -> Path:
    if explicit_root is not None:
        return Path(explicit_root).resolve()

    env_root = os.environ.get("ANONIM_VIDEO_TEXT_ROOT")
    if env_root:
        return Path(env_root).resolve()

    project_root = Path(__file__).resolve().parents[2]
    local_text_root = project_root / "text_anonim"
    if local_text_root.exists():
        return local_text_root.resolve()

    return Path.cwd().resolve()


def configure_default_paths(base_dir: str | Path | None = None) -> Path:
    runtime_root = discover_runtime_root(base_dir)
    ensure_runtime_readme(runtime_root)
    constants.DEFAULT_INPUT_ROOT = runtime_root / "files" / "pii"
    constants.DEFAULT_OUTPUT_ROOT = runtime_root / "files" / "pii_anonymized"
    constants.DEFAULT_PEOPLE_FILE = constants.DEFAULT_INPUT_ROOT / "people.json"
    constants.DEFAULT_PERSON_BLOCKLIST_FILE = constants.DEFAULT_INPUT_ROOT / "person_blocklist.txt"
    constants.DEFAULT_PERSON_NAME_BLOCKLIST_FILE = constants.DEFAULT_INPUT_ROOT / "person_name_blocklist.txt"
    constants.DEFAULT_ORG_BLOCKLIST_FILE = constants.DEFAULT_INPUT_ROOT / "org_blocklist.txt"
    return runtime_root


def main() -> None:
    configure_default_paths()
    from .app import main as app_main

    app_main()


if __name__ == '__main__':
    main()
