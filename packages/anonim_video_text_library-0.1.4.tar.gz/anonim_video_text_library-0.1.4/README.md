# Anonim Video Text Library

Самостоятельный проект для двух задач:
- транскрибация видео/аудио с диаризацией
- анонимизация текста, `JSON/JSONL/CSV/Markdown` с постоянным словарем `people.json`

`Anonim_video_text_Library` не зависит от `Anonim_video_text`. Эту папку можно использовать отдельно.

## Структура проекта

- `main.py` — входная точка для транскрибации видео/аудио
- `gpu_backends/` — вспомогательные скрипты для GPU-бэкендов транскрибации
- `text_anonim/` — скрипты анонимизации текста, blocklist-файлы, рабочие данные
- `src/anonim_video_text_library/` — импортируемый Python-пакет анонимайзера
- `examples/` — примеры использования из Python
- `whisper.cpp/` — локальная копия исходников `whisper.cpp`

## Установка для другого человека

Если нужен только текстовый анонимайзер как библиотека или CLI:

```bash
cd Anonim_video_text_Library
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

Если дополнительно нужна транскрибация видео/аудио:

```bash
pip install -r requirements.txt
```

## CLI анонимайзера

Локальный wrapper:

```bash
python3 text_anonim/anonimizer.py --help
```

Запуск как пакета:

```bash
python3 -m anonim_video_text_library --help
```

## Рабочая папка (`runtime_root`)

По умолчанию библиотека использует локальный `runtime_root` внутри проекта:

```text
Anonim_video_text_Library/text_anonim
```

Значит по умолчанию она будет работать с:
- `text_anonim/files/pii`
- `text_anonim/files/pii_anonymized`
- `text_anonim/files/pii/people.json`

При первом запуске библиотека автоматически создает в `runtime_root` файл:

```text
README.md
```

Этот файл создается один раз и объясняет, что лежит в рабочей папке.

## Использование из Python

Самый удобный внешний API — `TextAnonymizationSession`.

```python
from pathlib import Path
from anonim_video_text_library import TextAnonymizationSession

project_root = Path('/path/to/Anonim_video_text_Library')
runtime_root = project_root / 'my_runtime'

session = TextAnonymizationSession.from_defaults(
    runtime_root=runtime_root,
    device='auto',
    ner_batch_size=16,
)

text, text_stats = session.anonymize_text(
    'Anton from Doubletapp wrote to do.doubletapp@gmail.com',
    file_id='demo.txt',
)
print(text)
print(text_stats)

payload, stats = session.anonymize_value(
    {
        'title': 'Anton Riabykh',
        'body': 'Doubletapp contact: do.doubletapp@gmail.com',
    },
    file_id='demo.json',
)
print(payload)
print(stats)

session.save_people()
print(session.people_file)
```

Важные моменты:
- `anonymize_text()` запускает полный пайплайн, а не только сырой NER
- итоговый `people.json` сохраняется в `session.people_file`
- если workspace-папки еще не существуют, `from_defaults()` создаст их сам
- для чистого демо лучше использовать отдельный пустой `runtime_root`, а не рабочую папку с реальными данными

Готовый пример:

```bash
python3 examples/use_text_anonymizer.py
```

По умолчанию пример использует:

```text
<текущая_директория>/examples/_demo_runtime
```

поэтому не трогает рабочие данные в `text_anonim/files`.

Если нужен явный путь:

```bash
python3 examples/use_text_anonymizer.py --runtime-root /path/to/my_runtime
```

## Низкоуровневый API

Если нужен более детальный контроль, пакет разбит на модули:
- `constants.py` — regex, default-пути и общие константы
- `utils.py` — нормализация, валидация и мелкие helper-функции
- `registry.py` — `NameDictionary`, `TagRegistry`
- `anonymizer.py` — `PersonAnonymizer`, NER-логика, name-pass'ы
- `pipeline.py` — части текстового пайплайна замен
- `processors.py` — обработчики `json/jsonl/csv/md`
- `people.py` — `people.json` load/save/merge helper'ы
- `session.py` — high-level session API для внешних пользователей
- `app.py` — CLI-аргументы и основной runner
- `cli.py` — package entrypoint и настройка `runtime_root`

## Транскрибация видео/аудио

Часть для транскрибации по-прежнему доступна из этой же папки:

```bash
python3 main.py /path/to/call.mp4
```

Для нее также смотри:
- `requirements.txt`
- `gpu_backends/README.md`
- `whisper.cpp/README.md`

## Примечания

- `text_anonim/files` может содержать большие рабочие датасеты
- `whisper.cpp/models/*.bin` не копировались автоматически при переносе проекта
- `fairseq_env` намеренно не переносился; при необходимости создай локальное окружение заново
