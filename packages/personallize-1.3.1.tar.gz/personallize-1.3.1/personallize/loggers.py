# type: ignore
"""
Oferece personalização de ícones, controle de debug e formatação de arquivos.

Exemplo de Uso:
    from personallize.loggers import LogManager, ConsoleFormats, FileFormats, RetentionOptions

    # Instancia o gerenciador
    manager = LogManager()

    # Configuração fluente
    manager.config.console({
        "icon_status": "active",
        "show_debug": True,
        "format": ConsoleFormats.MEDIUM,
        "enqueue": True
    }).file({
        "log_file": "logs/my_app",
        "format": FileFormats.FULL,
        "retention": RetentionOptions.ONE_WEEK,
        "rotation": "00:00",
        "enqueue": True
    })

    log = manager.get_logger()
    console = logger.bind(sink="console")
    file = logger.bind(sink="file")

    console.info("Terminal")
    file.info("Apenas file")
    log.info("Vai pros dois")

"""

import contextlib
import sys
from enum import Enum
from pathlib import Path
from typing import Literal, TypedDict

from loguru import logger

IconStatus = Literal["active", "deactive"]
ShowDebug = Literal[True, False]


class IconSets(Enum):
    """Definições de conjuntos de ícones para os logs."""

    active: dict[str, str] = {
        "TRACE": "·",
        "DEBUG": "?",
        "INFO": "i",
        "SUCCESS": "✔",
        "WARNING": "⁉",
        "ERROR": "X",
        "CRITICAL": "!!!",
    }

    deactive: dict[str, str] = {
        "TRACE": "",
        "DEBUG": "",
        "INFO": "",
        "SUCCESS": "",
        "WARNING": "",
        "ERROR": "",
        "CRITICAL": "",
    }


class ConsoleFormats(Enum):
    """Formatos predefinidos para o console."""

    MINIMAL = "<level>{message}</level>"
    MEDIUM = "<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level><white>{message}</white></level>"
    FULL = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level.icon} {level: <8}</level> | "
        "<magenta>P:{process.name}:{process.id}</magenta> | "
        "<magenta>T:{thread.name}:{thread.id}</magenta> | "
        "<cyan>{file.path}:{line}</cyan> | "
        "<cyan>{module}:{function}</cyan> | "
        "<level><white>{message}</white></level>"
    )


class FileFormats(Enum):
    """Formatos predefinidos para arquivos de log."""

    MINIMAL = "{time:HH:mm:ss} | {level: <8} | {message}"
    MEDIUM = "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}"
    FULL = "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}"
    TOTAL = (
        "{time:YYYY-MM-DD HH:mm:ss.SSS} | "
        "{level: <8} | "
        "P:{process.name}:{process.id} | "
        "T:{thread.name}:{thread.id} | "
        "{file.path}:{line} | "
        "{module}:{function} | "
        "{message}"
    )


class RetentionOptions(Enum):
    """Opções de retenção de logs."""

    ONE_WEEK = "7 days"
    TWO_WEEKS = "15 days"
    ONE_MONTH = "30 days"


class ConsoleConfigDict(TypedDict, total=False):
    """Configurações para o console."""

    icon_status: IconStatus
    show_debug: ShowDebug
    format: str | ConsoleFormats
    enqueue: bool
    enable: bool


class FileConfigDict(TypedDict, total=False):
    """Configurações para o arquivo de log."""

    log_file: str | Path | None
    format: str | FileFormats
    rotation: str | None
    retention: str | RetentionOptions
    enqueue: bool
    enable: bool


class LogConfig:
    """Gerenciador de configurações de log."""

    def __init__(self):
        self.param_console: ConsoleConfigDict = {
            "icon_status": "deactive",
            "show_debug": True,
            "format": ConsoleFormats.MEDIUM.value,
            "enqueue": True,
            "enable": True,
        }
        self.param_file: FileConfigDict = {
            "log_file": "logs",  # Diretório base por padrão
            "format": FileFormats.FULL.value,
            "rotation": None,
            "retention": RetentionOptions.ONE_MONTH.value,
            "enqueue": True,
            "enable": True,
        }

    def console(self, settings: ConsoleConfigDict) -> "LogConfig":
        """Atualiza as configurações do console."""
        # Se for um Enum, pega o valor
        if "format" in settings and isinstance(settings["format"], ConsoleFormats):
            settings["format"] = settings["format"].value

        self.param_console.update(settings)
        return self

    def file(self, settings: FileConfigDict) -> "LogConfig":
        """Atualiza as configurações do arquivo."""
        # Se for um Enum, pega o valor
        if "format" in settings and isinstance(settings["format"], FileFormats):
            settings["format"] = settings["format"].value

        if "retention" in settings and isinstance(settings["retention"], RetentionOptions):
            settings["retention"] = settings["retention"].value

        self.param_file.update(settings)
        return self


class LogManager:
    """
    Gerenciador de logs simplificado e poderoso usando Loguru.
    Permite configuração fácil de ícones, níveis e saídas.
    """

    def __init__(self):
        """Inicializa o LogManager com configurações padrão."""
        self.config = LogConfig()

    def _get_icons(self) -> dict[str, str]:
        """Retorna o dicionário de ícones selecionado."""
        status = self.config.param_console.get("icon_status", "active")
        if status == "active":
            return IconSets.active.value
        return IconSets.deactive.value

    def _configure(self) -> None:
        """Aplica as configurações ao Loguru."""

        # Remove handlers padrão
        logger.remove()

        # Configura ícones para cada nível
        icons = self._get_icons()
        for level, icon in icons.items():
            with contextlib.suppress(Exception):
                logger.level(level, icon=icon)

        # Configurações do Console
        show_debug = self.config.param_console.get("show_debug", True)
        console_fmt = self.config.param_console.get("format")
        console_enqueue = self.config.param_console.get("enqueue", True)

        # Nível mínimo para o console
        console_level = "DEBUG" if show_debug else "INFO"

        # Adiciona handler do console
        enable_console = self.config.param_console.get("enable")
        if enable_console:
            logger.add(
                sys.stderr,
                format=console_fmt,
                level=console_level,
                colorize=True,
                enqueue=console_enqueue,
                filter=lambda r: r["extra"].get("sink") in (None, "console")
            )

        # Configurações de Arquivo
        log_file_path = self.config.param_file.get("log_file")
        enable_file = self.config.param_file.get("enable")

        if log_file_path and enable_file:
            base_path = Path(log_file_path)

            # Se o caminho termina com .log, usa como arquivo fixo (modo legado/específico)
            rotation = self.config.param_file.get("rotation")
            suffix_log = base_path.suffix == ".log"
            if rotation:
                final_path = base_path if suffix_log else base_path / "rpa.log"
            else:
                final_path = base_path if suffix_log else base_path / "{time:YYYY-MM-DD}" / "{time:HH_mm_ss}.log"

            # O Loguru cria diretórios automaticamente.
            file_enqueue = self.config.param_file.get("enqueue", True)

            logger.add(
                str(final_path),
                format=self.config.param_file.get("format"),
                level="TRACE",  # Arquivo sempre pega tudo
                rotation=rotation,
                retention=self.config.param_file.get("retention"),
                encoding="utf-8",
                enqueue=file_enqueue,
                filter=lambda r: r["extra"].get("sink") in (None, "file")
            )

    def get_logger(self):
        """Aplica as configurações e retorna a instância do logger."""
        self._configure()
        return logger
