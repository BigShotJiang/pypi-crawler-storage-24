"""
Módulo de registro complexo para personalização.
Fornece recursos avançados de registro em log com gerenciamento de configuração.

Usage Examples:

    Uso básico com LogManager:
        >>> from personallize.complex_log import LogManager, LogConfig
        >>> manager = LogManager()
        >>> logger, exception_decorator = manager.get_logger()
        >>> logger.info("Hello World!")

    Usando LogConfig para configuração personalizada:
        >>> from personallize.complex_log import LogManager, LogConfig
        >>> config = LogConfig.simple()  # Simple console-only logging
        >>> manager = LogManager(config)
        >>> logger, decorator = manager.get_simple_logger("my_app")
        >>> logger.info("Application started")

    Registro de arquivos com configuração personalizada:
        >>> config = LogConfig.file_only(level="DEBUG", log_dir="my_logs")
        >>> manager = LogManager(config)
        >>> logger, decorator = manager.get_simple_logger("debug_app", "debug.log")
        >>> logger.debug("Debug information")

    Configuração avançada:
        >>> config = LogConfig(
        ...     level="INFO",
        ...     log_dir="logs",
        ...     console_enabled=True,
        ...     file_enabled=True,
        ...     json_format=False,
        ...     colored_console=True
        ... )
        >>> manager = LogManager(config)
        >>> logger, decorator = manager.get_simple_logger("advanced_app")

    Usando decorador de exceção:
        >>> manager = LogManager()
        >>> logger, exception_decorator = manager.get_logger()
        >>> @exception_decorator
        ... def my_function():
        ...     raise ValueError("Something went wrong")
        >>> my_function()  # Exception will be logged automatically

Predefinições de LogConfig disponíveis:
    - LogConfig.simple(): Registro somente de console com formatação básica
    - LogConfig.file_only(): Registro somente de arquivo com formato JSON
    - LogConfig(): Registro completo com console e saída de arquivo

Opções de configuração:
    - level: Nível de registro ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
    - log_dir: Diretório para arquivos de log (padrão: "logs")
    - console_enabled: Habilitar saída no console (padrão: True)
    - file_enabled: Habilitar saída em arquivo (padrão: True)
    - json_format: Usar formatação JSON para logs (padrão: True)
    - colored_console: Habilitar saída colorida no console (padrão: True)
    - max_file_size: Tamanho máximo de arquivo de log em MB (padrão: 10)
    - backup_count: Número de arquivos de backup a manter (padrão: 5)
    - queue_enabled: Habilitar registro assíncrono (padrão: True)
    - rich_handler: Usar manipulador Rich para saída de console aprimorada (padrão: True)
"""

from .config import LogConfig
from .manager import LogManager

__all__ = ["LogConfig", "LogManager"]
