import pyperclip
import typer

from beni import bcolor, btask
from beni.bfunc import sync_call


@btask.command()
@sync_call
async def upgrade(
    name: str = typer.Argument('bcmd', help='要更新的包名'),
):
    "使用 uv 官方源更新指定包到最新版本"
    cmd = f'uv tool upgrade {name} --index https://pypi.org/simple'
    pyperclip.copy(cmd + '\n')
    bcolor.print_green(cmd)
    bcolor.print_green(f'命令已复制{bcolor.yellow("（需要手动执行才会生效）")}')
    bcolor.print_green('OK')
