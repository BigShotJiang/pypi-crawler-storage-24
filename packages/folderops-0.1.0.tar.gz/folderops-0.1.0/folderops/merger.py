from __future__ import annotations

from pathlib import Path
from typing import Sequence

from .utils import ensure_directory, list_image_files, normalize_extensions, transfer_file, unique_destination_path, validate_operation


def merge_folders(
    folders: Sequence[str | Path],
    output: str | Path,
    mode: str = 'copy',
    extensions: Sequence[str] | None = None,
) -> list[Path]:
    """Merge image files from multiple folders into a single output folder.

    Args:
        folders: Input directories containing images.
        output: Destination directory.
        mode: File transfer mode, either 'copy' or 'move'.
        extensions: Iterable of allowed image extensions.

    Returns:
        A list of output file paths created in the merged directory.

    Raises:
        ValueError: If no folders are provided.
        FileNotFoundError: If an input folder does not exist.
    """
    if not folders:
        raise ValueError('folders must contain at least one directory.')

    mode = validate_operation(mode)
    normalize_extensions(extensions)
    output_dir = ensure_directory(output)
    merged_paths: list[Path] = []

    for folder in folders:
        for image_path in list_image_files(folder, extensions):
            destination = unique_destination_path(output_dir, image_path.name)
            merged_paths.append(transfer_file(image_path, destination, operation=mode))

    return merged_paths
