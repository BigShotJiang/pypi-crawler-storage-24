from __future__ import annotations

from pathlib import Path

from .utils import ensure_directory, iter_structure_paths


def create_structure(structure: dict, root: str | Path | None = None) -> list[Path]:
    """Create nested directories from a dictionary template.

    Args:
        structure: Nested dictionary describing folder names.
        root: Optional base directory under which the structure is created.

    Returns:
        A list of created or ensured directory paths.

    Raises:
        TypeError: If the structure is not a valid nested dictionary.
        ValueError: If any folder name is invalid.
    """
    base = Path(root) if root is not None else Path()
    created_paths: list[Path] = []
    for relative_path in iter_structure_paths(structure):
        directory = ensure_directory(base / relative_path)
        created_paths.append(directory)
    return created_paths
