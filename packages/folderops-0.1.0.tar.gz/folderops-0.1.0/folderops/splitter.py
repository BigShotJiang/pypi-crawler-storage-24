from __future__ import annotations

import random
from pathlib import Path
from typing import Sequence

from .utils import ensure_directory, normalize_extensions, transfer_file, validate_operation


def split_dataset(
    source: str | Path,
    output: str | Path,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int | None = 42,
    mode: str = "copy",
    extensions: Sequence[str] | None = None,
) -> dict[str, dict[str, list[Path]]]:
    mode = validate_operation(mode)
    extensions = normalize_extensions(extensions)

    total_ratio = train_ratio + val_ratio + test_ratio
    if any(r < 0 for r in (train_ratio, val_ratio, test_ratio)):
        raise ValueError("Split ratios must be non-negative.")
    if abs(total_ratio - 1.0) > 1e-9:
        raise ValueError("train_ratio, val_ratio, and test_ratio must sum to 1.0.")

    source_path = Path(source)
    if not source_path.exists():
        raise FileNotFoundError(f"Source directory not found: {source}")

    class_dirs = [d for d in source_path.iterdir() if d.is_dir()]
    if not class_dirs:
        raise ValueError("No class folders found inside source directory.")

    rng = random.Random(seed)

    output_path = ensure_directory(output)

    result: dict[str, dict[str, list[Path]]] = {
        "train": {},
        "val": {},
        "test": {},
    }

    for class_dir in class_dirs:
        class_name = class_dir.name

        images = [
            p for p in class_dir.iterdir()
            if p.is_file() and (extensions is None or p.suffix.lower() in extensions)
        ]

        if not images:
            continue

        rng.shuffle(images)

        total = len(images)
        train_end = int(total * train_ratio)
        val_end = train_end + int(total * val_ratio)

        split_map = {
            "train": images[:train_end],
            "val": images[train_end:val_end],
            "test": images[val_end:],
        }

        for split_name, files in split_map.items():
            split_class_dir = ensure_directory(output_path / split_name / class_name)

            result[split_name][class_name] = []

            for file_path in files:
                destination = split_class_dir / file_path.name
                transferred = transfer_file(file_path, destination, operation=mode)
                result[split_name][class_name].append(transferred)

    return result