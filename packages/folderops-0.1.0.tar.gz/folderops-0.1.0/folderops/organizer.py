from __future__ import annotations

import csv
from pathlib import Path
from typing import Sequence

from .utils import ensure_directory, normalize_extensions, transfer_file, validate_directory, validate_file, validate_operation


def organize_by_labels(
    image_dir: str | Path,
    label_file: str | Path,
    output: str | Path,
    mode: str = 'copy',
    extensions: Sequence[str] | None = None,
    delimiter: str = ',',
) -> dict[str, list[Path]]:
    """Organize images into class folders based on a CSV mapping file.

    Args:
        image_dir: Directory containing images.
        label_file: CSV file with rows formatted as filename,label.
        output: Directory where class folders will be created.
        mode: File transfer mode, either 'copy' or 'move'.
        extensions: Iterable of allowed image extensions.
        delimiter: CSV delimiter used in the label file.

    Returns:
        A dictionary mapping class labels to transferred file paths.

    Raises:
        FileNotFoundError: If the image directory or label file does not exist.
        ValueError: If rows are malformed or files are missing.
    """
    mode = validate_operation(mode)
    allowed = set(normalize_extensions(extensions))
    image_root = validate_directory(image_dir, 'Image directory')
    labels_path = validate_file(label_file, 'Label file')
    output_dir = ensure_directory(output)

    organized: dict[str, list[Path]] = {}

    with labels_path.open('r', encoding='utf-8', newline='') as handle:
        reader = csv.reader(handle, delimiter=delimiter)
        for row_number, row in enumerate(reader, start=1):
            if not row:
                continue
            if len(row) < 2:
                raise ValueError(f'Malformed row {row_number} in label file: expected filename and label.')
            filename = row[0].strip()
            label = row[1].strip()
            if not filename or not label:
                raise ValueError(f'Row {row_number} contains an empty filename or label.')

            image_path = image_root / filename
            if not image_path.exists() or not image_path.is_file():
                raise FileNotFoundError(f'Image listed in label file not found: {image_path}')
            if image_path.suffix.lower() not in allowed:
                raise ValueError(f'Unsupported file extension for image: {image_path.name}')

            class_dir = ensure_directory(output_dir / label)
            destination = class_dir / image_path.name
            organized.setdefault(label, []).append(transfer_file(image_path, destination, operation=mode))

    return organized
