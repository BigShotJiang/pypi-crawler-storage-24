import contextlib
import io
import math
import multiprocessing
import os
import shutil
import sys
import threading
import time
import tempfile
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple, Union

import networkx as nx
import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from shapely.geometry import LineString, Point, box
from shapely.strtree import STRtree
from tqdm import tqdm

from mapmatcher4gmns.networkclass.macronet import Link, Network
from mapmatcher4gmns.utils.progress_timer import (
    log_progress_line,
    set_elapsed_timer_position,
    start_elapsed_timer,
    stop_elapsed_timer,
)

_FIXED_CHUNKSIZE = 200000
_FIXED_CLEAR_CACHE_EVERY = 1
_FIXED_JOURNEY_BATCH_SIZE = 256


@dataclass
class Candidate:
    link: Link
    proj_point_xy: Point
    proj_position: float
    link_length: float
    distance: float
    emission_logp: float


class _ShortestPathCache:
    def __init__(self, graph: nx.DiGraph, *, weight_key: str = 'weight', cutoff: Optional[float] = None):
        self.graph = graph
        self.weight_key = weight_key
        self.cutoff = cutoff
        # Cache shortest paths by (source, target) pair to avoid all-target
        # Dijkstra expansion on large graphs.
        self._dist_cache: Dict[Tuple[int, int], float] = {}
        self._path_cache: Dict[Tuple[int, int], List[int]] = {}

    def _ensure_pair(self, source: int, target: int) -> None:
        key = (int(source), int(target))
        if key in self._dist_cache:
            return
        if source == target:
            self._dist_cache[key] = 0.0
            self._path_cache[key] = [source]
            return
        if source not in self.graph or target not in self.graph:
            self._dist_cache[key] = float('inf')
            self._path_cache[key] = []
            return
        try:
            dist, path = nx.single_source_dijkstra(
                self.graph,
                source=source,
                target=target,
                weight=self.weight_key,
                cutoff=self.cutoff,
            )
            self._dist_cache[key] = float(dist)
            self._path_cache[key] = list(path) if path else []
        except Exception:
            self._dist_cache[key] = float('inf')
            self._path_cache[key] = []

    def get_distance(self, source: int, target: int) -> float:
        key = (int(source), int(target))
        self._ensure_pair(source, target)
        return self._dist_cache.get(key, float('inf'))

    def get_path(self, source: int, target: int) -> List[int]:
        key = (int(source), int(target))
        self._ensure_pair(source, target)
        return self._path_cache.get(key, [])

    def clear(self) -> None:
        self._dist_cache.clear()
        self._path_cache.clear()


class MapMatcher:
    def __init__(self,
                 network: Network,
                 *,
                 # Data field configuration
                 agent_field: str = 'journey_id',
                 lng_field: str = 'longitude',
                 lat_field: str = 'latitude',
                 time_field: Optional[str] = 'local_time',
                 speed_field: Optional[str] = 'speed_mph',
                 heading_field: Optional[str] = 'heading',
                 # Time gap filtering
                 max_gap_seconds: float = 45.0,
                 # Core matching parameters
                 search_radius: float = 15.0,
                 noise_sigma: float = 8.0,
                 trans_weight: float = 12.0,
                 dist_penalty: float = 0.1,
                 max_candidates: int = 10,
                 use_heading: bool = True,
                 heading_sigma: float = 30.0,
                 time_format: Optional[str] = None,
                 extra_fields: Optional[List[str]] = None,
                 # Movement consistency parameters
                 turn_sigma: float = 45.0,
                 heading_len: float = 15.0,
                 route_gap: float = 15.0,
                 use_node_restrict: bool = False,
                 # Stationary point filtering
                 filter_dwell: bool = True,
                 dwell_dist: float = 5.0,
                 dwell_count: int = 2,
                 # Output configuration
                 export_csv: bool = True,
                 export_geo: bool = False,
                 out_dir: str = 'mapmatching',
                 export_route: bool = True,
                 result_file: str = 'matched_result.csv',
                 route_file: str = 'matched_route.csv',
                 # Processing constraints
                 min_link_len: float = 6.0,
                 # Speed and direction parameters
                 speed_limit: float = 200.0,
                 heading_weights: Optional[List[float]] = None,
                 max_agents: Optional[int] = None,
                 # Debug and control
                 debug: bool = False,
                 verbose: bool = True,
                 show_progress: bool = True,
                 # Parallel defaults
                 core_num: Optional[int] = None,
                 stop_event: Optional[threading.Event] = None,
                 ):
        self.net: Network = network
        
        # Core matching parameters
        self.search_radius = float(search_radius)
        self.noise_sigma = noise_sigma
        self.trans_weight = trans_weight
        self.dist_penalty = float(dist_penalty)
        self.max_candidates = max_candidates
        self.use_heading = use_heading
        self.heading_sigma = heading_sigma
        self.time_format = time_format
        self.extra_fields = [f for f in (extra_fields or []) if isinstance(f, str)]
        
        # Movement consistency parameters
        self.turn_sigma = max(1e-6, float(turn_sigma))
        self.heading_len = float(heading_len)
        self.route_gap = float(route_gap)
        self.use_node_restrict = bool(use_node_restrict)
        
        # Stationary point filtering
        self.filter_dwell = filter_dwell
        self.dwell_dist = dwell_dist
        self.dwell_count = int(max(1, dwell_count))
        
        # Output configuration
        self.export_csv = export_csv
        self.export_geo = export_geo
        self.out_dir = out_dir
        self.export_route = export_route
        self.route_file = route_file
        self.result_file = result_file
        
        # Processing constraints
        self.min_link_len = min_link_len
        self.max_agents = max_agents if (max_agents is None or max_agents > 0) else None
        
        # Speed and direction parameters
        self.speed_limit = float(speed_limit)
        self.heading_weights = None
        self.angle_slice = None
        if heading_weights is not None and isinstance(heading_weights, list) and len(heading_weights) > 0:
            self.heading_weights = [float(x) for x in heading_weights]
            self.angle_slice = 180.0 / float(len(self.heading_weights))
        # node restrict default
        self.gps_node_field = 'node_id'
        # debug / verbosity
        self.debug = bool(debug)
        self.verbose = bool(verbose)
        self.show_progress = bool(show_progress)
        # parallel defaults
        self.default_core_num: Optional[int] = None if (core_num is None or (isinstance(core_num, int) and core_num <= 0)) else int(core_num)

        # cache: mapping (from_link_id, to_link_id) -> node sequence used in transition
        self._ft_node_path: Dict[Tuple[int, int], List[int]] = {}
        start_elapsed_timer(self.show_progress)

        if self.verbose:
            log_progress_line(f"Building spatial index from {self.net.number_of_links} links ...")
        _t0 = time.perf_counter()
        self._build_spatial_index()
        if self.verbose:
            log_progress_line(f"Spatial index ready: {len(self._geoms)} geometries ({time.perf_counter() - _t0:.2f}s)")

        if self.verbose:
            log_progress_line(f"Building routing graph from {self.net.number_of_nodes} nodes / {self.net.number_of_links} links ...")
        _t1 = time.perf_counter()
        self._build_graph()
        if self.verbose:
            log_progress_line(f"Routing graph ready: {self._G.number_of_nodes()} nodes / {self._G.number_of_edges()} edges ({time.perf_counter() - _t1:.2f}s)")
        self._full_graph = self._G
        self._active_graph = self._G
        self._path_cutoff: Optional[float] = None
        self._full_path_cache = _ShortestPathCache(self._G, cutoff=self._path_cutoff)
        self._path_cache: _ShortestPathCache = self._full_path_cache
        self._xy_columns: Tuple[str, str] = ('__m4g_x', '__m4g_y')
        self._node_pair_cost: Dict[Tuple[int, int], float] = {}
        # cooperative cancel support
        self.stop_event = stop_event
        
        # Data field configuration
        self.agent_field = agent_field
        self.lng_field = lng_field
        self.lat_field = lat_field
        self.time_field = time_field
        self.heading_field = heading_field
        self.speed_field = speed_field
        self.max_gap_seconds = max_gap_seconds

    def _filter_dwell_points(self, sub: pd.DataFrame, lng_col: str, lat_col: str) -> pd.DataFrame:
        if (not self.filter_dwell) or (self.dwell_count <= 1) or (self.dwell_dist <= 0) or (len(sub) <= 2):
            return sub
        # compute XY
        pts: List[Point] = []
        for i in range(len(sub)):
            x, y = self.net.GT.from_latlon(float(sub.loc[i, lng_col]), float(sub.loc[i, lat_col]))
            pts.append(Point(x, y))
        # distances between consecutive points (index aligned to point i)
        dist = [0.0]
        for i in range(1, len(pts)):
            dist.append(float(pts[i].distance(pts[i-1])))
        small = pd.Series([d < self.dwell_dist for d in dist])
        # mark drops where last dwell_n moves are small
        drops = set()
        for i in range(len(sub)):
            if i == 0:
                continue
            ok = True
            for k in range(self.dwell_count):
                j = i - k
                if j < 1:
                    ok = False
                    break
                if not small.iloc[j]:
                    ok = False
                    break
            if ok:
                drops.add(i)
        # always keep first/last
        if len(sub) - 1 in drops:
            drops.remove(len(sub) - 1)
        keep_idx = [i for i in range(len(sub)) if i not in drops]
        if len(keep_idx) < 2:
            return sub
        out = sub.iloc[keep_idx].reset_index(drop=True)
        return out

    def _build_spatial_index(self):
        # use XY (meter) geometries for spatial search
        self._links: List[Link] = []
        self._geoms: List[LineString] = []
        self._linkid_to_index: Dict[int, int] = {}
        for _, link in self.net.link_dict.items():
            geom_xy = getattr(link, 'geometry_xy', None)
            if geom_xy is None:
                # fallback to create XY via GT if only lonlat geometry exists
                if link.geometry is not None:
                    geom_xy = self.net.GT.geo_from_latlon(link.geometry)
                    link.geometry_xy = geom_xy
            if geom_xy is not None and not geom_xy.is_empty:
                self._links.append(link)
                self._geoms.append(geom_xy)
        self._strtree = STRtree(self._geoms)
        # index -> link / geometry mappings
        self._index_to_link: List[Link] = list(self._links)
        self._wkb_to_index: Dict[bytes, int] = {g.wkb: i for i, g in enumerate(self._geoms)}
        for idx, lk in enumerate(self._index_to_link):
            try:
                self._linkid_to_index[int(lk.link_id)] = idx
            except Exception:
                continue
        # node -> link indices for node restriction
        self._node_to_indices: Dict[int, Set[int]] = {}
        for idx, lk in enumerate(self._index_to_link):
            if getattr(lk, 'from_node', None) is not None:
                self._node_to_indices.setdefault(int(lk.from_node.node_id), set()).add(idx)
            if getattr(lk, 'to_node', None) is not None:
                self._node_to_indices.setdefault(int(lk.to_node.node_id), set()).add(idx)

    def _build_graph(self):
        G = nx.DiGraph()
        for node_id, node in self.net.node_dict.items():
            G.add_node(node_id)
        for link_id, link in self.net.link_dict.items():
            if (link.from_node is None) or (link.to_node is None):
                continue
            u = link.from_node.node_id
            v = link.to_node.node_id
            length = getattr(link, 'length', None)
            if length is None:
                geom_xy = getattr(link, 'geometry_xy', None)
                if geom_xy is None and link.geometry is not None:
                    geom_xy = self.net.GT.geo_from_latlon(link.geometry)
                length = geom_xy.length if geom_xy is not None else 1.0
            G.add_edge(u, v, weight=float(length), link=link)
        self._G = G

    def _get_active_graph(self) -> nx.DiGraph:
        return self._active_graph if self._active_graph is not None else self._G

    def _make_path_cache(self, graph: nx.DiGraph) -> _ShortestPathCache:
        return _ShortestPathCache(graph, cutoff=self._path_cutoff)

    def _restore_full_graph(self) -> None:
        self._active_graph = self._full_graph
        self._path_cache = self._full_path_cache

    def _build_agent_graph(self, link_indices: Optional[Set[int]]) -> nx.DiGraph:
        if not link_indices:
            return self._full_graph
        indices = {idx for idx in link_indices if 0 <= idx < len(self._index_to_link)}
        if not indices:
            return self._full_graph
        # Avoid unnecessary subgraph creation when nearly all links are included
        if len(indices) >= max(1, int(0.9 * len(self._index_to_link))):
            return self._full_graph
        G = nx.DiGraph()
        for idx in indices:
            link = self._index_to_link[idx]
            if link is None:
                continue
            if getattr(link, 'from_node', None) is None or getattr(link, 'to_node', None) is None:
                continue
            u = int(link.from_node.node_id)
            v = int(link.to_node.node_id)
            length = getattr(link, 'length', None)
            if length is None:
                geom_xy = getattr(link, 'geometry_xy', None)
                length = geom_xy.length if geom_xy is not None else 1.0
            G.add_node(u)
            G.add_node(v)
            G.add_edge(u, v, weight=float(length), link=link)
        if G.number_of_edges() == 0:
            return self._full_graph
        return G

    @contextlib.contextmanager
    def _use_agent_graph(self, link_indices: Optional[Set[int]]):
        new_graph = self._build_agent_graph(link_indices)
        if new_graph is self._active_graph:
            yield
            return
        prev_graph = self._active_graph
        prev_cache = self._path_cache
        try:
            if new_graph is self._full_graph:
                self._restore_full_graph()
            else:
                self._active_graph = new_graph
                self._path_cache = self._make_path_cache(new_graph)
            yield
        finally:
            self._active_graph = prev_graph
            self._path_cache = prev_cache

    def _edge_data(self, u: int, v: int) -> Optional[Dict]:
        graph = self._get_active_graph()
        data = graph.get_edge_data(u, v)
        if data is None and graph is not self._full_graph:
            data = self._full_graph.get_edge_data(u, v)
        if data is None:
            data = graph.get_edge_data(v, u)
            if data is None and graph is not self._full_graph:
                data = self._full_graph.get_edge_data(v, u)
        return data

    def _node_path_to_links(self, node_path: List[int]) -> List[Link]:
        if not node_path or len(node_path) < 2:
            return []
        links: List[Link] = []
        for a, b in zip(node_path[:-1], node_path[1:]):
            data = self._edge_data(a, b)
            if not data:
                continue
            lk = data.get('link')
            if lk is not None:
                links.append(lk)
        return links

    def _project_point_onto_line(self, point_xy: Point, line_xy: LineString) -> Tuple[Point, float, float, float]:
        # distance in meters (XY)
        s = line_xy.project(point_xy)
        p = line_xy.interpolate(s)
        d = p.distance(point_xy)
        L = float(line_xy.length) if line_xy.length is not None else 0.0
        return p, float(d), float(s), L

    def _bearing_of_line(self, line_xy: LineString) -> float:
        x0, y0 = line_xy.coords[0]
        x1, y1 = line_xy.coords[-1]
        ang = math.degrees(math.atan2(y1 - y0, x1 - x0)) % 360.0
        return ang

    def _local_bearing(self, line_xy: LineString, at_point_xy: Point) -> float:
        try:
            L = float(line_xy.length)
            if L <= 0.0:
                return self._bearing_of_line(line_xy)
            s = line_xy.project(at_point_xy)
            # choose a small window around s to compute tangent
            delta = min(5.0, max(1.0, 0.05 * L))
            s1 = max(0.0, s - delta)
            s2 = min(L, s + delta)
            if abs(s2 - s1) < 1e-6:
                return self._bearing_of_line(line_xy)
            p1 = line_xy.interpolate(s1)
            p2 = line_xy.interpolate(s2)
            ang = math.degrees(math.atan2(p2.y - p1.y, p2.x - p1.x)) % 360.0
            return float(ang)
        except Exception:
            return self._bearing_of_line(line_xy)

    def _angle_diff(self, a: float, b: float) -> float:
        d = abs(a - b) % 360.0
        return d if d <= 180.0 else 360.0 - d

    def _emission_logp(self, distance: float, heading_deg: Optional[float], link_bearing: Optional[float],
                       est_speed_mph: Optional[float]) -> float:
        # Distance term: -0.5 * (dist_penalty * d / noise_sigma)^2
        logp = -0.5 * ((self.dist_penalty * distance) / max(self.noise_sigma, 1e-6)) ** 2
        # heading term
        if self.use_heading and heading_deg is not None and link_bearing is not None:
            dh = self._angle_diff(heading_deg, link_bearing)
            # If heading weights are provided, use them; otherwise use Gaussian
            if self.heading_weights is not None and self.angle_slice is not None:
                bin_idx = int(min(len(self.heading_weights) - 1, max(0, dh // self.angle_slice)))
                w = max(1e-8, self.heading_weights[bin_idx])
                logp += float(np.log(w))
            else:
                logp += - (dh * dh) / (2.0 * self.heading_sigma * self.heading_sigma)
        # Speed consistency (threshold): apply strong penalty only when exceeding threshold
        if est_speed_mph is not None and est_speed_mph >= 0:
            if est_speed_mph > self.speed_limit:
                logp += -10.0
        return float(logp)

    def _prefilter_link_indices_by_route_band(self, points_xy: List[Point]) -> Set[int]:
        if not points_xy:
            return set(range(len(self._geoms)))
        try:
            gap = float(self.route_gap)
            if len(points_xy) == 1:
                p = points_xy[0]
                band = p.buffer(gap) if gap > 0 else box(p.x, p.y, p.x, p.y)
            else:
                line = LineString([(p.x, p.y) for p in points_xy])
                if gap > 0:
                    # Use a true route buffer instead of bbox envelope to keep
                    # candidate links local on large city-scale networks.
                    band = line.buffer(gap, cap_style=2, join_style=2)
                else:
                    band = line.envelope
            items = self._strtree.query(band)
            idx_set: Set[int] = set()
            for it in items:
                if hasattr(it, 'wkb'):
                    idx = self._wkb_to_index.get(it.wkb)
                    if idx is None:
                        continue
                else:
                    try:
                        idx = int(it)
                    except Exception:
                        continue
                if 0 <= idx < len(self._geoms):
                    idx_set.add(idx)
            return idx_set if idx_set else set(range(len(self._geoms)))
        except Exception:
            return set(range(len(self._geoms)))

    def _candidates_from_point_xy(self, point_xy: Optional[Point],
                                  *, allowed_indices: Optional[Set[int]] = None) -> List[Candidate]:
        if point_xy is None:
            return []
        idx_list = self._candidate_indices_for_point(point_xy, allowed_indices)
        cand_pairs: List[Tuple[float, Candidate]] = []
        gap = float(self.search_radius)
        for idx in idx_list:
            geom = self._geoms[idx]
            link = self._index_to_link[idx]
            proj_p, dist, proj_s, link_len = self._project_point_onto_line(point_xy, geom)
            if dist > gap:
                continue
            cand_pairs.append((dist, Candidate(link=link,
                                               proj_point_xy=proj_p,
                                               proj_position=proj_s,
                                               link_length=link_len,
                                               distance=dist,
                                               emission_logp=0.0)))
        if not cand_pairs:
            return []
        cand_pairs.sort(key=lambda x: x[0])
        return [c for _, c in cand_pairs[: self.max_candidates]]

    def _candidates_for_point(self, lon: float, lat: float, heading_deg: Optional[float],
                              *, allowed_indices: Optional[Set[int]] = None) -> List[Candidate]:
        x, y = self.net.GT.from_latlon(lon, lat)
        point_xy = Point(x, y)
        return self._candidates_from_point_xy(point_xy, allowed_indices=allowed_indices)

    def _batch_candidates(self,
                          points_xy: List[Optional[Point]],
                          per_point_allowed: List[Optional[Set[int]]]) -> List[List[Candidate]]:
        results: List[List[Candidate]] = [[] for _ in points_xy]
        valid: List[Tuple[int, Point]] = [(idx, p) for idx, p in enumerate(points_xy) if p is not None]
        if not valid:
            return results
        gap = float(self.search_radius)
        for orig_idx, point_xy in valid:
            allowed = per_point_allowed[orig_idx]
            idx_list = self._candidate_indices_for_point(point_xy, allowed)
            for idx in idx_list:
                geom = self._geoms[idx]
                link = self._index_to_link[idx]
                proj_p, dist, proj_s, link_len = self._project_point_onto_line(point_xy, geom)
                if dist > gap:
                    continue
                results[orig_idx].append((dist, Candidate(link=link,
                                                          proj_point_xy=proj_p,
                                                          proj_position=proj_s,
                                                          link_length=link_len,
                                                          distance=dist,
                                                          emission_logp=0.0)))
        for idx in range(len(results)):
            cand_pairs = results[idx]
            if not cand_pairs:
                results[idx] = []
                continue
            cand_pairs.sort(key=lambda x: x[0])
            results[idx] = [c for _, c in cand_pairs[: self.max_candidates]]
        return results

    def _candidate_indices_for_point(self,
                                     point_xy: Point,
                                     allowed_indices: Optional[Set[int]]) -> List[int]:
        gap = float(self.search_radius)
        rect = box(point_xy.x - gap, point_xy.y - gap, point_xy.x + gap, point_xy.y + gap)
        try:
            items = self._strtree.query(rect)
        except Exception:
            items = []
        idx_list: List[int] = []
        for it in items:
            if hasattr(it, 'wkb'):
                idx = self._wkb_to_index.get(it.wkb)
                if idx is None:
                    continue
            else:
                try:
                    idx = int(it)
                except Exception:
                    continue
            if idx < 0 or idx >= len(self._geoms):
                continue
            if allowed_indices is not None and idx not in allowed_indices:
                continue
            idx_list.append(idx)
        return idx_list

    def _compute_transition_scores(self,
                                   prev_states: List[Candidate],
                                   curr_states: List[Candidate],
                                   adj_dis: float,
                                   prev_dp: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        m = len(prev_states)
        n = len(curr_states)
        if m == 0 or n == 0:
            return np.full((n,), -np.inf, dtype=float), np.full((n,), -1, dtype=int)

        prev_proj = np.array([c.proj_position for c in prev_states], dtype=float)
        curr_proj = np.array([c.proj_position for c in curr_states], dtype=float)
        prev_tail = np.array([max(0.0, c.link_length - c.proj_position) for c in prev_states], dtype=float)
        curr_head = np.array([max(0.0, c.proj_position) for c in curr_states], dtype=float)
        prev_link_ids = np.array([int(getattr(c.link, 'link_id', -1)) for c in prev_states], dtype=int)
        curr_link_ids = np.array([int(getattr(c.link, 'link_id', -1)) for c in curr_states], dtype=int)
        prev_to_nodes = np.array([int(c.link.to_node.node_id) if c.link and c.link.to_node else -1 for c in prev_states], dtype=int)
        curr_from_nodes = np.array([int(c.link.from_node.node_id) if c.link and c.link.from_node else -1 for c in curr_states], dtype=int)

        route_len = np.full((m, n), np.inf, dtype=float)

        same_mask = prev_link_ids[:, None] == curr_link_ids[None, :]
        if np.any(same_mask):
            route_len[same_mask] = np.abs(prev_proj[:, None] - curr_proj[None, :])[same_mask]

        for i in range(m):
            u = prev_to_nodes[i]
            if u < 0:
                continue
            tail_val = prev_tail[i]
            for j in range(n):
                if same_mask[i, j]:
                    continue
                v = curr_from_nodes[j]
                if v < 0:
                    continue
                key = (u, v)
                mid_cost = self._node_pair_cost.get(key)
                if mid_cost is None:
                    mid_cost = self._shortest_path_length(u, v)
                    self._node_pair_cost[key] = mid_cost
                if math.isinf(mid_cost):
                    continue
                route_len[i, j] = tail_val + mid_cost + curr_head[j]

        trans_matrix = np.full((m, n), -1e12, dtype=float)
        valid_mask = np.isfinite(route_len)
        if np.any(valid_mask):
            beta = max(self.trans_weight, 1e-6)
            gap_vals = np.abs(adj_dis - route_len[valid_mask])
            trans_matrix[valid_mask] = - self.dist_penalty * gap_vals / beta

        scores = prev_dp[:, None] + trans_matrix
        best_indices = np.argmax(scores, axis=0)
        best_scores = scores[best_indices, np.arange(n)]

        invalid_mask = ~np.isfinite(best_scores) | (best_scores <= -1e11)
        best_scores = best_scores.astype(float)
        best_scores[invalid_mask] = -np.inf
        best_indices = best_indices.astype(int)
        # Don't set best_indices to -1 for invalid scores - keep the best available transition
        # This ensures backtracking continuity even when probabilities are very low
        return best_scores, best_indices

    def _ensure_xy_columns(self, df: pd.DataFrame, lng_col: str, lat_col: str) -> Tuple[str, str]:
        x_col, y_col = self._xy_columns
        if x_col in df.columns and y_col in df.columns:
            return x_col, y_col
        xs: List[float] = []
        ys: List[float] = []
        lng_vals = df[lng_col].to_numpy()
        lat_vals = df[lat_col].to_numpy()
        for lon, lat in zip(lng_vals, lat_vals):
            try:
                if pd.isna(lon) or pd.isna(lat):
                    xs.append(np.nan)
                    ys.append(np.nan)
                else:
                    x, y = self.net.GT.from_latlon(float(lon), float(lat))
                    xs.append(float(x))
                    ys.append(float(y))
            except Exception:
                xs.append(np.nan)
                ys.append(np.nan)
        df[x_col] = xs
        df[y_col] = ys
        return x_col, y_col

    def _mask_points_within_buffer(self,
                                   points_xy: List[Optional[Point]],
                                   per_point_allowed: List[Optional[Set[int]]]) -> List[bool]:
        mask = [False] * len(points_xy)
        valid: List[Tuple[int, Point]] = [(idx, p) for idx, p in enumerate(points_xy) if p is not None]
        if not valid:
            return mask
        gap = float(self.search_radius)
        for orig_idx, point_xy in valid:
            allowed = per_point_allowed[orig_idx] if per_point_allowed else None
            idx_list = self._candidate_indices_for_point(point_xy, allowed)
            if not idx_list:
                continue
            for idx in idx_list:
                geom = self._geoms[idx]
                _, dist, _, _ = self._project_point_onto_line(point_xy, geom)
                if dist <= gap:
                    mask[orig_idx] = True
                    break
        return mask

    def _shortest_path_length(self, u: int, v: int) -> float:
        caches = (self._path_cache,) if self._path_cache is self._full_path_cache else (self._path_cache, self._full_path_cache)
        for cache in caches:
            try:
                length = cache.get_distance(u, v)
            except KeyError:
                continue
            if length is None or math.isinf(length):
                continue
            return float(length)
        return float('inf')

    def _shortest_path_nodes(self, u: int, v: int) -> List[int]:
        caches = (self._path_cache,) if self._path_cache is self._full_path_cache else (self._path_cache, self._full_path_cache)
        for cache in caches:
            try:
                path = cache.get_path(u, v)
            except KeyError:
                continue
            if path:
                return list(path)
        return []

    def _shortest_path_links(self, u: int, v: int) -> List[Link]:
        node_path = self._shortest_path_nodes(u, v)
        return self._node_path_to_links(node_path)

    def _shortest_path_links_undirected(self, u: int, v: int) -> List[Link]:
        graph = self._get_active_graph()
        try:
            UG = graph.to_undirected()
            node_path = nx.shortest_path(UG, u, v, weight='weight')
            return self._node_path_to_links(node_path)
        except Exception:
            pass
        if graph is not self._full_graph:
            try:
                UG = self._full_graph.to_undirected()
                node_path = nx.shortest_path(UG, u, v, weight='weight')
                return self._node_path_to_links(node_path)
            except Exception:
                pass
        return []

    def _connect_links_with_mids(self, prev_link: Link, curr_link: Link) -> List[Link]:
        candidates: List[Tuple[List[Link], float]] = []
        pairs: List[Tuple[Optional[int], Optional[int]]] = []
        u1 = prev_link.to_node.node_id if prev_link and prev_link.to_node else None
        u2 = prev_link.from_node.node_id if prev_link and prev_link.from_node else None
        v1 = curr_link.from_node.node_id if curr_link and curr_link.from_node else None
        v2 = curr_link.to_node.node_id if curr_link and curr_link.to_node else None
        for u in (u1, u2):
            for v in (v1, v2):
                if (u is not None) and (v is not None):
                    pairs.append((u, v))

        def path_cost(ls: List[Link]) -> float:
            total = 0.0
            for lk in ls:
                L = getattr(lk, 'length', None)
                if L is None:
                    geom = getattr(lk, 'geometry_xy', None)
                    if geom is not None:
                        L = float(geom.length)
                    else:
                        L = 1.0
                total += float(L)
            return total

        for (u, v) in pairs:
            ls = self._shortest_path_links(u, v)
            if ls:
                candidates.append((ls, path_cost(ls)))
            else:
                ls2 = self._shortest_path_links_undirected(u, v)
                if ls2:
                    candidates.append((ls2, path_cost(ls2)))
        if not candidates:
            return []
        candidates.sort(key=lambda x: x[1])
        return candidates[0][0]

    def _nearest_endpoint_node_id(self, link: Link, lon: float, lat: float) -> Optional[int]:
        try:
            x, y = self.net.GT.from_latlon(lon, lat)
            p = Point(x, y)
            line = link.geometry_xy
            if line is None:
                if link.geometry is not None:
                    line = self.net.GT.geo_from_latlon(link.geometry)
                else:
                    return None
            s = line.project(p)
            L = float(line.length) if line.length is not None else 0.0
            if (link.from_node is None) or (link.to_node is None):
                return None
            # choose nearest endpoint by along-line distance
            if L <= 0.0:
                return link.from_node.node_id
            return link.from_node.node_id if s <= (L - s) else link.to_node.node_id
        except Exception:
            return None

    def _transition_logp(self, prev_c: Candidate, curr_c: Candidate, adj_dis: float) -> float:
        # Compute route length (including tail/head partials) and straight-line gap (dis_gap)
        if prev_c.link is curr_c.link:
            route_len = abs(curr_c.proj_position - prev_c.proj_position)
        else:
            # Strictly from prev.to_node -> curr.from_node
            try:
                u = int(prev_c.link.to_node.node_id)
                v = int(curr_c.link.from_node.node_id)
            except Exception:
                return -1e12
            key = (u, v)
            mid_cost = self._node_pair_cost.get(key)
            if mid_cost is None:
                mid_cost = self._shortest_path_length(u, v)
                self._node_pair_cost[key] = mid_cost
            if math.isinf(mid_cost):
                return -1e12
            # Remaining tail of previous + middle shortest path + head of next
            route_len = max(0.0, prev_c.link_length - prev_c.proj_position) + mid_cost + max(0.0, curr_c.proj_position)

        dis_gap = abs(float(adj_dis) - float(route_len))
        # Transition log p = - dist_penalty * dis_gap / trans_weight
        return - self.dist_penalty * dis_gap / max(self.trans_weight, 1e-6)

    def _filter_journeys_with_large_time_gaps(self, gps_df: pd.DataFrame, agent_field: str, time_field: str, max_gap_seconds: float = 60.0, return_stats: bool = False):
        """
        Filter out journeys that have time gaps larger than max_gap_seconds between consecutive points.
        
        Args:
            gps_df: GPS DataFrame sorted by agent and time
            max_gap_seconds: Maximum allowed time gap in seconds (default: 60.0)
            
        Returns:
            Filtered GPS DataFrame with problematic journeys removed
        """
        if gps_df.empty:
            if return_stats:
                return gps_df, 0, 0
            return gps_df
            
        # Create a temporary time column for calculation
        tmp_time_col = '__temp_time__'
        
        try:
            try:
                input_journeys = int(gps_df[agent_field].nunique())
            except Exception:
                input_journeys = 0
            # Parse time column
            if self.time_format:
                gps_df[tmp_time_col] = pd.to_datetime(gps_df[self.time_field], errors='coerce', format=self.time_format)
            else:
                gps_df[tmp_time_col] = pd.to_datetime(gps_df[self.time_field], errors='coerce')
            
            # Get valid journeys (those with valid timestamps)
            valid_mask = gps_df[tmp_time_col].notna()
            valid_df = gps_df[valid_mask].copy()
            
            if valid_df.empty:
                del gps_df[tmp_time_col]
                if return_stats:
                    return gps_df, 0, input_journeys
                return gps_df
            
            # Group by journey and check time gaps
            journeys_to_keep = []
            journeys_to_remove = []
            
            for journey_id, journey_data in valid_df.groupby(agent_field):
                if len(journey_data) <= 1:
                    # Single point journeys are always kept
                    journeys_to_keep.append(journey_id)
                    continue
                
                # Sort by time to ensure proper order
                journey_sorted = journey_data.sort_values(by=tmp_time_col)
                
                # Calculate time differences between consecutive points
                time_diffs = journey_sorted[tmp_time_col].diff().dt.total_seconds()
                
                # Check if any time gap exceeds the threshold
                max_gap = time_diffs.max()
                if pd.isna(max_gap) or max_gap <= max_gap_seconds:
                    journeys_to_keep.append(journey_id)
                else:
                    journeys_to_remove.append(journey_id)
            
            # Filter the original DataFrame
            if journeys_to_remove:
                # Keep only journeys without large time gaps
                filtered_df = gps_df[gps_df[agent_field].isin(journeys_to_keep)].copy()
                
                # Also remove journeys with invalid timestamps (if any)
                invalid_journeys = gps_df[~valid_mask][agent_field].unique()
                if len(invalid_journeys) > 0:
                    filtered_df = filtered_df[~filtered_df[agent_field].isin(invalid_journeys)]
                
                del filtered_df[tmp_time_col]
                if return_stats:
                    try:
                        kept_journeys = int(filtered_df[agent_field].nunique())
                    except Exception:
                        kept_journeys = 0
                    dropped_journeys = max(0, input_journeys - kept_journeys)
                    return filtered_df, dropped_journeys, kept_journeys
                return filtered_df
            else:
                del gps_df[tmp_time_col]
                if return_stats:
                    return gps_df, 0, input_journeys
                return gps_df
                
        except Exception:
            # Return original data if filtering fails
            if tmp_time_col in gps_df.columns:
                del gps_df[tmp_time_col]
            if return_stats:
                try:
                    kept_journeys = int(gps_df[agent_field].nunique())
                except Exception:
                    kept_journeys = 0
                return gps_df, 0, kept_journeys
            return gps_df

    def match(self, gps_csv_path: str) -> Tuple[pd.DataFrame, Dict, List]:
        if not isinstance(gps_csv_path, str):
            raise TypeError('match() expects a CSV file path string')

        # Always use chunk pipeline for consistent output format with fixed internals.
        return self._match_csv_in_chunks(
            gps_csv_path=gps_csv_path,
            chunksize=_FIXED_CHUNKSIZE,
            core_num=self.default_core_num,
        )

    def _match_dataframe(self, gps_df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict, List]:
        res, warn_info, err_agents, _meta = self._match_dataframe_with_meta(gps_df)
        return res, warn_info, err_agents

    def _match_dataframe_with_meta(self, gps_df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict, List, Dict[str, int]]:
        journey_stats = {
            'input_journeys': 0,
            'dropped_journeys': 0,
            'kept_journeys': 0,
        }
        try:
            if self.agent_field in gps_df.columns:
                journey_stats['input_journeys'] = int(gps_df[self.agent_field].nunique())
        except Exception:
            pass

        # Sort GPS data by agent and time first - CRITICAL for proper matching
        if self.time_field and self.time_field in gps_df.columns:
            tmp_col = '__time_sort__'
            
            if self.time_format:
                # Use the specified format strictly
                try:
                    gps_df[tmp_col] = pd.to_datetime(gps_df[self.time_field], errors='coerce', format=self.time_format)
                    valid_time_count = gps_df[tmp_col].notna().sum()
                    
                    if valid_time_count == 0:
                        # Keep all data but sort by agent only
                        gps_df = gps_df.sort_values(by=[self.agent_field], ascending=True, ignore_index=True)
                    else:
                        # Remove rows with invalid time and sort by agent and time
                        gps_df = gps_df.dropna(subset=[tmp_col])
                        if not gps_df.empty:
                            gps_df = gps_df.sort_values(by=[self.agent_field, tmp_col], ascending=[True, True], ignore_index=True)
                except Exception:
                    # Keep all data but sort by agent only
                    gps_df = gps_df.sort_values(by=[self.agent_field], ascending=True, ignore_index=True)
            else:
                # No format specified, use auto-detection
                try:
                    gps_df[tmp_col] = pd.to_datetime(gps_df[self.time_field], errors='coerce', infer_datetime_format=True)
                    valid_time_count = gps_df[tmp_col].notna().sum()
                    
                    if valid_time_count == 0:
                        # Keep all data but sort by agent only
                        gps_df = gps_df.sort_values(by=[self.agent_field], ascending=True, ignore_index=True)
                    else:
                        # Remove rows with invalid time and sort by agent and time
                        gps_df = gps_df.dropna(subset=[tmp_col])
                        if not gps_df.empty:
                            gps_df = gps_df.sort_values(by=[self.agent_field, tmp_col], ascending=[True, True], ignore_index=True)
                except Exception:
                    # Keep all data but sort by agent only
                    gps_df = gps_df.sort_values(by=[self.agent_field], ascending=True, ignore_index=True)
            
            del gps_df[tmp_col]
        else:
            # Sort by agent only if no time field
            gps_df = gps_df.sort_values(by=[self.agent_field], ascending=True, ignore_index=True)
        
        # Filter out journeys with large time gaps
        if self.time_field and self.time_field in gps_df.columns:
            gps_df, dropped_journeys, kept_journeys = self._filter_journeys_with_large_time_gaps(
                gps_df,
                self.agent_field,
                self.time_field,
                self.max_gap_seconds,
                return_stats=True,
            )
            journey_stats['dropped_journeys'] = int(dropped_journeys)
            journey_stats['kept_journeys'] = int(kept_journeys)
        else:
            journey_stats['kept_journeys'] = journey_stats['input_journeys']
        
        # group by agent
        assert self.agent_field in gps_df.columns
        x_col, y_col = self._ensure_xy_columns(gps_df, self.lng_field, self.lat_field)
        agents_all = gps_df[self.agent_field].unique().tolist()
        agents = list(agents_all)
        if self.max_agents is not None:
            try:
                limit = int(self.max_agents)
                if limit > 0:
                    agents = agents[:limit]
            except Exception:
                pass
        results: List[pd.DataFrame] = []
        warn_info: Dict = {}
        err_agents: List = []
        def _finalize_results(current_results: List[pd.DataFrame]) -> pd.DataFrame:
            base_desired = [self.agent_field, 'seq', 'time', 'link_id', 'from_node_id', 'to_node_id', 'longitude', 'latitude', 'speed_mph', 'match_heading', 'route_dis']
            user_keep = [c for c in self.extra_fields if (c not in base_desired and c in gps_df.columns)]
            desired_cols = base_desired + user_keep
            if current_results:
                non_empty = [df for df in current_results if isinstance(df, pd.DataFrame) and not df.empty and df.columns.size > 0]
                if non_empty:
                    # Filter out empty DataFrames and DataFrames with all-NA columns to avoid FutureWarning
                    filtered_dfs = []
                    for df in non_empty:
                        if not df.empty:
                            # Remove columns that are all NA
                            df_clean = df.dropna(axis=1, how='all')
                            if not df_clean.empty:
                                filtered_dfs.append(df_clean)
                    
                    if filtered_dfs:
                        res_local = pd.concat(filtered_dfs, ignore_index=True)
                    else:
                        res_local = pd.DataFrame(columns=desired_cols)
                else:
                    res_local = pd.DataFrame(columns=desired_cols)
            else:
                res_local = pd.DataFrame(columns=desired_cols)
            # reorder columns if present
            for c in desired_cols:
                if c not in res_local.columns:
                    res_local[c] = None
            res_local = res_local[desired_cols]
            # Keep existing per-journey row order from matching results.
            # A global journey order pass is applied later in chunk mode.
            group_order = None
            try:
                if not res_local.empty and (self.agent_field in res_local.columns):
                    group_order = res_local[self.agent_field].dropna().unique().tolist()
            except Exception:
                group_order = None
            # optional export
            try:
                import os
                if self.export_csv:
                    os.makedirs(self.out_dir, exist_ok=True)
                    res_local.to_csv(os.path.join(self.out_dir, self.result_file), index=False)
                    if self.export_route and not res_local.empty:
                        # build expanded route per agent using recorded ft_node_path (4gmns-like)
                        route_rows = []
                        if group_order is None:
                            group_order = res_local[self.agent_field].dropna().unique().tolist()
                        for agent in group_order:
                            df_g = res_local[res_local[self.agent_field] == agent].copy()
                            if df_g.empty:
                                continue
                            df_g = df_g.sort_values(by=['seq' if 'seq' in df_g.columns else 'time'], ascending=True)
                            df_g = df_g.reset_index(drop=True)
                            expanded: List[int] = []
                            def _append_link_id(lid: int):
                                if not expanded or expanded[-1] != int(lid):
                                    expanded.append(int(lid))
                            first_link = self.net.link_dict.get(int(df_g.at[0, 'link_id']))
                            if first_link is None:
                                continue
                            _append_link_id(int(first_link.link_id))
                            for i in range(len(df_g) - 1):
                                cur_lk = self.net.link_dict.get(int(df_g.at[i, 'link_id']))
                                nxt_lk = self.net.link_dict.get(int(df_g.at[i+1, 'link_id']))
                                if cur_lk is None or nxt_lk is None:
                                    continue
                                # if already continuous or same link
                                if (int(cur_lk.link_id) == int(nxt_lk.link_id)) or \
                                   (getattr(cur_lk, 'to_node', None) and getattr(nxt_lk, 'from_node', None) and \
                                    int(cur_lk.to_node.node_id) == int(nxt_lk.from_node.node_id)):
                                    _append_link_id(int(nxt_lk.link_id))
                                    continue
                                key = (int(cur_lk.link_id), int(nxt_lk.link_id))
                                nodes = self._ft_node_path.get(key, [])
                                if not nodes:
                                    try:
                                        u = int(cur_lk.to_node.node_id)
                                        v = int(nxt_lk.from_node.node_id)
                                        nodes = self._shortest_path_nodes(u, v)
                                    except Exception:
                                        nodes = []
                                if nodes:
                                    # map nodes to links along path
                                    for j in range(len(nodes) - 1):
                                        data = self._edge_data(nodes[j], nodes[j+1])
                                        if not data:
                                            continue
                                        lk = data.get('link')
                                        if lk is None:
                                            continue
                                        _append_link_id(int(lk.link_id))
                                _append_link_id(int(nxt_lk.link_id))
                            # emit rows
                            for step_idx, lid in enumerate(expanded):
                                lk = self.net.link_dict.get(int(lid))
                                route_rows.append({
                                    self.agent_field: agent,
                                    'step': step_idx,
                                    'link_id': int(lid),
                                    'from_node_id': int(lk.from_node.node_id) if lk and lk.from_node else None,
                                    'to_node_id': int(lk.to_node.node_id) if lk and lk.to_node else None,
                                })
                        if route_rows:
                            route_df = pd.DataFrame(route_rows)
                            route_df = route_df.sort_values(by=[self.agent_field, 'step'], ascending=[True, True], ignore_index=True)
                            
                            grouped_routes = []
                            if group_order is None:
                                group_order = route_df[self.agent_field].dropna().unique().tolist()
                            for journey_id in group_order:
                                group = route_df[route_df[self.agent_field] == journey_id]
                                if group.empty:
                                    continue
                                link_ids = group['link_id'].astype(str).tolist()
                                grouped_routes.append({
                                    'journey_id': journey_id,
                                    'link_ids': ','.join(link_ids)
                                })
                            
                            grouped_route_df = pd.DataFrame(grouped_routes)
                            grouped_route_df.to_csv(os.path.join(self.out_dir, self.route_file), index=False)
                if self.export_geo and not res_local.empty:
                    try:
                        import geopandas as gpd
                        rows = []
                        for _, r in res_local.iterrows():
                            lk = self.net.link_dict.get(int(r['link_id']))
                            if lk is None or lk.geometry is None:
                                continue
                            rows.append({'journey_id': r[self.agent_field], 'seq': int(r['seq']), 'link_id': int(r['link_id']), 'geometry': lk.geometry})
                        if rows:
                            gdf = gpd.GeoDataFrame(rows, geometry='geometry', crs='EPSG:4326')
                            gdf.to_file(os.path.join(self.out_dir, 'matched_result.geojson'), driver='GeoJSON')
                    except Exception:
                        pass
            except Exception:
                pass
            return res_local

        for a in agents:
            if self.stop_event is not None and self.stop_event.is_set():
                res = _finalize_results(results)
                return res, warn_info, err_agents, journey_stats
            try:
                sub = gps_df[gps_df[self.agent_field] == a].copy()
                self._current_agent = a
                sub = sub.reset_index(drop=True)
                if self.filter_dwell:
                    sub = self._filter_dwell_points(sub, self.lng_field, self.lat_field)
                base_cols = {'seq','time','link_id','from_node_id','to_node_id','longitude','latitude','speed_mph','dis_to_next','match_heading','route_dis', self.agent_field}
                keep_user_fields = [c for c in self.extra_fields if (c in sub.columns and c not in base_cols)]
                allowed_idx: Optional[Set[int]] = None
                if self.route_gap and self.route_gap > 0:
                    pts_xy: List[Point] = []
                    for _, r in sub.iterrows():
                        try:
                            x, y = float(r[x_col]), float(r[y_col])
                            pts_xy.append(Point(x, y))
                        except Exception:
                            continue
                    allowed_idx = self._prefilter_link_indices_by_route_band(pts_xy)
                path_df = self._match_one_agent(sub, self.lng_field, self.lat_field, self.time_field, self.heading_field, self.speed_field, keep_user_fields, allowed_idx, x_col, y_col)
                path_df[self.agent_field] = a
                results.append(path_df)
            except Exception as e:
                err_agents.append(a)
                warn_info[str(a)] = repr(e)

        res = _finalize_results(results)
        return res, warn_info, err_agents, journey_stats

    def _match_one_agent(self, sub: pd.DataFrame,
                          lng_col: str,
                          lat_col: str,
                          time_col: Optional[str],
                          heading_col: Optional[str],
                          speed_col: Optional[str],
                          keep_user_fields: Optional[List[str]],
                          allowed_indices: Optional[Set[int]],
                          x_col: str,
                          y_col: str) -> pd.DataFrame:
        base_allowed = None if allowed_indices is None else set(allowed_indices)
        node_restrict_active = self.use_node_restrict and (self.gps_node_field in sub.columns)

        def _build_allowed_list(df: pd.DataFrame) -> List[Optional[Set[int]]]:
            if not node_restrict_active:
                if base_allowed is None:
                    return [None] * len(df)
                # Reuse the same immutable membership set to avoid O(n_points)
                # copying of large per-agent link sets.
                return [base_allowed] * len(df)
            res: List[Optional[Set[int]]] = []
            for idx in range(len(df)):
                allowed_t = base_allowed
                if node_restrict_active:
                    try:
                        nid_val = df.iloc[idx][self.gps_node_field]
                    except Exception:
                        nid_val = None
                    if pd.notna(nid_val):
                        node_set = self._node_to_indices.get(int(nid_val), set())
                        if node_set:
                            if allowed_t is None:
                                allowed_t = set(node_set)
                            else:
                                allowed_t = allowed_t.intersection(node_set)
                        else:
                            allowed_t = set()
                res.append(allowed_t if allowed_t is not None else None)
            return res

        def _build_points(df: pd.DataFrame) -> List[Optional[Point]]:
            xs = df[x_col].to_numpy()
            ys = df[y_col].to_numpy()
            pts: List[Optional[Point]] = []
            for xv, yv in zip(xs, ys):
                if np.isnan(xv) or np.isnan(yv):
                    pts.append(None)
                else:
                    pts.append(Point(float(xv), float(yv)))
            return pts

        per_point_allowed = _build_allowed_list(sub)
        gps_xy_all = _build_points(sub)
        candidate_lists = self._batch_candidates(gps_xy_all, per_point_allowed)
        keep_indices = [i for i, cands in enumerate(candidate_lists) if cands]
        if not keep_indices:
            return pd.DataFrame(columns=['seq', 'time', 'link_id', 'from_node_id', 'to_node_id', 'longitude', 'latitude', 'speed_mph', 'dis_to_next', 'match_heading', 'route_dis'])
        if len(keep_indices) != len(sub):
            sub = sub.iloc[keep_indices].reset_index(drop=True)
            per_point_allowed = [per_point_allowed[i] for i in keep_indices]
            gps_xy_all = [gps_xy_all[i] for i in keep_indices]
            candidate_lists = [candidate_lists[i] for i in keep_indices]
        else:
            sub = sub.reset_index(drop=True)

        obs = []
        prev_xy: Optional[Point] = None
        prev_time = None
        for i, row in sub.iterrows():
            lon = float(row[lng_col])
            lat = float(row[lat_col])
            heading_deg = None
            if heading_col and heading_col in sub.columns:
                try:
                    heading_deg = float(row[heading_col])
                except Exception:
                    heading_deg = None
            point_xy = gps_xy_all[i]
            # estimate speed mph from consecutive points
            est_speed_mph = None
            if prev_xy is not None and prev_time is not None and time_col and time_col in sub.columns:
                try:
                    t_curr = pd.to_datetime(row[time_col], errors='coerce')
                    if pd.notna(t_curr) and pd.notna(prev_time):
                        dt = (t_curr.value - prev_time.value) / 1e9
                        if dt > 0 and point_xy is not None and prev_xy is not None:
                            d = point_xy.distance(prev_xy)
                            est_speed_mph = d / dt * 2.23693629
                            prev_xy = point_xy
                            prev_time = t_curr
                        else:
                            pass
                    else:
                        prev_xy = None
                        prev_time = None
                except Exception:
                    prev_xy = None
                    prev_time = None
            else:
                prev_xy = point_xy
                try:
                    prev_time = pd.to_datetime(row[time_col], errors='coerce') if (time_col and time_col in sub.columns) else None
                except Exception:
                    prev_time = None
            obs.append((lon, lat, heading_deg, est_speed_mph))

        with self._use_agent_graph(allowed_indices):
            backptr: List[Dict[int, int]] = []
            states: List[List[Candidate]] = []
            dp: List[np.ndarray] = []
            kept_indices: List[int] = []
            segments: List[List[Tuple[int, Candidate]]] = []
            min_segment_points = 3
            dead_end_split_threshold = 2
            rollback_tail_points = 2
            dead_end_streak = 0
            restart_attempts: Dict[int, int] = {}
            initialized = False

            def _finalize_segment(reason: str, trim_tail: int = 0) -> None:
                nonlocal backptr, states, dp, kept_indices, initialized, segments
                if not states:
                    initialized = False
                    return

                final_dp = dp[-1]
                finite_mask_local = np.isfinite(final_dp)
                if np.any(finite_mask_local):
                    finite_indices = np.where(finite_mask_local)[0]
                    finite_values = final_dp[finite_mask_local]
                    seq_idx_local = int(finite_indices[np.argmax(finite_values)])
                else:
                    seq_idx_local = 0

                seq_local: List[Tuple[int, Candidate]] = []
                for step_local in reversed(range(len(states))):
                    seq_local.append((step_local, states[step_local][seq_idx_local]))
                    seq_idx_local = backptr[step_local].get(seq_idx_local, -1)
                    if seq_idx_local < 0 and step_local > 0:
                        break
                seq_local.reverse()

                seg_pairs: List[Tuple[int, Candidate]] = []
                for step_local, cand_local in seq_local:
                    if 0 <= step_local < len(kept_indices):
                        seg_pairs.append((kept_indices[step_local], cand_local))

                if trim_tail > 0 and seg_pairs:
                    if trim_tail >= len(seg_pairs):
                        seg_pairs = []
                    else:
                        seg_pairs = seg_pairs[:-int(trim_tail)]

                if len(seg_pairs) >= min_segment_points:
                    segments.append(seg_pairs)
                elif self.debug and seg_pairs:
                    print(
                        f"[m4g-debug] drop short segment: journey={getattr(self, '_current_agent', 'unknown')}, "
                        f"len={len(seg_pairs)}, reason={reason}"
                    )

                backptr = []
                states = []
                dp = []
                kept_indices = []
                initialized = False

            t = 0
            while t < len(obs):
                _lont, _latt, hdt, vt = obs[t]
                candt = candidate_lists[t]
                if not candt:
                    dead_end_streak = 0
                    t += 1
                    continue

                for j in range(len(candt)):
                    bearing = self._bearing_of_line(candt[j].link.geometry_xy)
                    candt[j].emission_logp = self._emission_logp(
                        candt[j].distance,
                        (None if not initialized else hdt),
                        bearing,
                        vt,
                    )
                emission_arr = np.array([c.emission_logp for c in candt], dtype=float)

                if not initialized:
                    states.append(candt)
                    dp.append(emission_arr)
                    backptr.append({i: -1 for i in range(len(candt))})
                    kept_indices.append(t)
                    initialized = True
                    dead_end_streak = 0
                    t += 1
                    continue

                prev_states = states[-1]
                prev_dp = dp[-1]
                m, n = len(prev_states), len(candt)
                if m == 0 or n == 0:
                    t += 1
                    continue

                try:
                    prev_orig_idx = kept_indices[-1]
                    p_prev = gps_xy_all[prev_orig_idx]
                    p_curr = gps_xy_all[t]
                    adj_dis = float(p_prev.distance(p_curr)) if (p_prev is not None and p_curr is not None) else prev_states[0].proj_point_xy.distance(candt[0].proj_point_xy)
                except Exception:
                    adj_dis = prev_states[0].proj_point_xy.distance(candt[0].proj_point_xy)

                best_scores, best_indices = self._compute_transition_scores(prev_states, candt, adj_dis, prev_dp)
                cur_dp = best_scores + emission_arr
                cur_bp: Dict[int, int] = {j: (int(best_indices[j]) if best_indices[j] >= 0 else -1) for j in range(n)}
                finite_mask = np.isfinite(cur_dp)

                if not np.any(finite_mask):
                    dead_end_streak += 1
                    if dead_end_streak < int(dead_end_split_threshold):
                        t += 1
                        continue

                    dead_end_streak = 0
                    trim_tail = 0
                    restart_t = t
                    if rollback_tail_points > 0 and kept_indices:
                        tail_n = min(int(rollback_tail_points), len(kept_indices))
                        trim_tail = tail_n
                        # Restart from current failed point as a fresh segment
                        # (do not jump back into already-kept prefix).
                        restart_t = t

                    _finalize_segment('no valid transition', trim_tail=trim_tail)

                    attempts = int(restart_attempts.get(restart_t, 0)) + 1
                    restart_attempts[restart_t] = attempts
                    # Retry once at the same failed point; on the second failure
                    # at the same restart point, move forward to avoid stalls.
                    if attempts >= 2:
                        restart_t = min(len(obs) - 1, t + 1)
                    t = restart_t
                    continue

                for j2 in range(n):
                    bi = cur_bp[j2]
                    if bi is not None and 0 <= bi < m:
                        prev_lk = prev_states[bi].link
                        cur_lk = candt[j2].link
                        u = int(prev_lk.to_node.node_id) if prev_lk.to_node is not None else None
                        v = int(cur_lk.from_node.node_id) if cur_lk.from_node is not None else None
                        if (u is not None) and (v is not None):
                            key = (int(prev_lk.link_id), int(cur_lk.link_id))
                            if key not in self._ft_node_path:
                                nodes = self._shortest_path_nodes(u, v)
                                if nodes:
                                    self._ft_node_path[key] = nodes

                max_val = np.max(cur_dp[finite_mask])
                cur_dp = cur_dp - max_val
                states.append(candt)
                dp.append(cur_dp)
                backptr.append(cur_bp)
                kept_indices.append(t)
                dead_end_streak = 0
                if restart_attempts:
                    restart_attempts.clear()
                t += 1

            _finalize_segment('end')

            if not segments:
                return pd.DataFrame(columns=['seq', 'time', 'link_id', 'from_node_id', 'to_node_id', 'longitude', 'latitude', 'speed_mph', 'dis_to_next', 'match_heading', 'route_dis'])

            rows = []
            out_seq = 0
            for seg in segments:
                cumulative_route = 0.0
                for idx in range(len(seg)):
                    orig_t, cand = seg[idx]
                    link = cand.link
                    time_val = sub.loc[orig_t, time_col] if (time_col and time_col in sub.columns) else None
                    speed_mph = None
                    if speed_col and speed_col in sub.columns:
                        val = sub.loc[orig_t, speed_col]
                        speed_mph = float(val) if pd.notna(val) else None

                    if idx == 0:
                        route_dis = 0.0
                    else:
                        _, cand_prev = seg[idx - 1]
                        if cand.link is cand_prev.link:
                            line = cand.link.geometry_xy
                            s1 = line.project(cand_prev.proj_point_xy)
                            s2 = line.project(cand.proj_point_xy)
                            inc = abs(s2 - s1)
                        else:
                            try:
                                line_prev = cand_prev.link.geometry_xy
                                s_prev = line_prev.project(cand_prev.proj_point_xy)
                                L_prev = float(line_prev.length) if line_prev.length is not None else 0.0
                                tail = max(0.0, L_prev - s_prev)
                            except Exception:
                                tail = 0.0
                            try:
                                line_curr = cand.link.geometry_xy
                                s_curr = line_curr.project(cand.proj_point_xy)
                                head = max(0.0, s_curr)
                            except Exception:
                                head = 0.0
                            try:
                                u = cand_prev.link.to_node.node_id
                                v = cand.link.from_node.node_id
                                mid = self._shortest_path_length(u, v)
                            except Exception:
                                mid = float('inf')
                            if math.isinf(mid):
                                inc = cand_prev.proj_point_xy.distance(cand.proj_point_xy)
                            else:
                                inc = tail + mid + head
                        cumulative_route += inc
                        route_dis = cumulative_route

                    row = {
                        'seq': int(out_seq),
                        'time': time_val if time_val is not None else None,
                        'link_id': int(link.link_id),
                        'from_node_id': int(link.from_node.node_id) if link.from_node is not None else None,
                        'to_node_id': int(link.to_node.node_id) if link.to_node is not None else None,
                        'longitude': float(sub.loc[orig_t, lng_col]),
                        'latitude': float(sub.loc[orig_t, lat_col]),
                        'speed_mph': speed_mph,
                        'match_heading': self._bearing_of_line(link.geometry_xy) if hasattr(link, 'geometry_xy') and link.geometry_xy is not None else None,
                        'route_dis': route_dis,
                    }
                    if keep_user_fields:
                        for uf in keep_user_fields:
                            try:
                                row[uf] = sub.loc[orig_t, uf]
                            except Exception:
                                row[uf] = None
                    rows.append(row)
                    out_seq += 1

        df = pd.DataFrame(rows)
        # ensure column order
        cols = ['seq', 'time', 'link_id', 'from_node_id', 'to_node_id', 'longitude', 'latitude', 'speed_mph', 'match_heading', 'route_dis']
        # Append user fields in the specified order if any
        if keep_user_fields:
            for uf in keep_user_fields:
                if uf not in df.columns:
                    df[uf] = None
            cols = cols + [uf for uf in keep_user_fields if uf in df.columns]
        return df[cols]


# ----------------------------
# Multiprocessing helpers
# ----------------------------
def _split_groups(items: List, n: int) -> List[List]:
    if n <= 1 or len(items) <= 1:
        return [list(items)]
    n = max(1, int(n))
    size = max(1, (len(items) + n - 1) // n)
    groups: List[List] = []
    for i in range(0, len(items), size):
        groups.append(items[i:i+size])
    return groups


def _m4g_worker_match(args) -> Tuple[pd.DataFrame, Dict, List]:
    network, gps_chunk_df, init_kwargs = args
    # Ensure workers do not write files; the parent will export once
    init_kwargs = dict(init_kwargs)
    init_kwargs['export_csv'] = False
    init_kwargs['export_geo'] = False
    init_kwargs['export_route'] = False
    matcher = MapMatcher(network=network, **init_kwargs)
    # Silence stdout/stderr inside worker to avoid interleaved logs
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        res_df, warn_info, err_agents = matcher._match_dataframe(gps_chunk_df)
    return res_df, warn_info, err_agents


# Persistent worker matcher for per-agent streaming
_WK_MATCHER = None
_WK_JOBLIB_KEY = None


def _m4g_worker_init(network: Network, init_kwargs: Dict):
    global _WK_MATCHER
    init_kwargs = dict(init_kwargs)
    init_kwargs['export_csv'] = False
    init_kwargs['export_geo'] = False
    init_kwargs['export_route'] = False
    # force single-core inside worker to avoid nested parallelism
    init_kwargs['core_num'] = 1
    # Silence construction-time prints for worker
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        _WK_MATCHER = MapMatcher(network=network, **init_kwargs)


def _m4g_worker_init_from_source(source_cfg: Dict, init_kwargs: Dict):
    global _WK_MATCHER
    from mapmatcher4gmns.io.load_from_csv import LoadNetFromCSV

    init_kwargs = dict(init_kwargs)
    init_kwargs['export_csv'] = False
    init_kwargs['export_geo'] = False
    init_kwargs['export_route'] = False
    init_kwargs['core_num'] = 1
    init_kwargs['verbose'] = False
    init_kwargs['show_progress'] = False

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        network = LoadNetFromCSV(
            folder=source_cfg.get('folder', ''),
            node_file=source_cfg.get('node_file'),
            link_file=source_cfg.get('link_file'),
            movement_file=source_cfg.get('movement_file'),
            segment_file=source_cfg.get('segment_file'),
            geometry_file=source_cfg.get('geometry_file'),
            POI_file=source_cfg.get('POI_file'),
            coordinate_type=source_cfg.get('coordinate_type', 'lonlat'),
            encoding=source_cfg.get('encoding'),
        )
        _WK_MATCHER = MapMatcher(network=network, **init_kwargs)


def _m4g_joblib_match_stream_batch(args) -> Tuple[pd.DataFrame, int, int, Dict, List]:
    """
    Joblib worker entrypoint with per-process matcher cache.
    """
    global _WK_MATCHER, _WK_JOBLIB_KEY
    try:
        chunk_df, source_cfg, init_kwargs = args
        if chunk_df is None or chunk_df.empty:
            return pd.DataFrame(), 0, 0, {}, []

        key = repr((source_cfg, init_kwargs))
        if (_WK_MATCHER is None) or (_WK_JOBLIB_KEY != key):
            _m4g_worker_init_from_source(source_cfg, init_kwargs)
            _WK_JOBLIB_KEY = key

        return _m4g_worker_match_stream_batch(chunk_df)
    except Exception as e:
        return pd.DataFrame(), 0, 0, {}, [repr(e)]


def _m4g_worker_match_agent(args) -> Tuple[pd.DataFrame, Optional[str]]:
    sub_df, agent_field = args
    try:
        matcher = _WK_MATCHER
        if matcher is None:
            return pd.DataFrame(), 'worker not initialized'
        # ensure xy
        x_col, y_col = matcher._ensure_xy_columns(sub_df, matcher.lng_field, matcher.lat_field)
        # optional route band allowed indices
        allowed_idx: Optional[Set[int]] = None
        if matcher.route_gap and matcher.route_gap > 0:
            pts_xy: List[Point] = []
            for _, r in sub_df.iterrows():
                try:
                    x, y = float(r[x_col]), float(r[y_col])
                    pts_xy.append(Point(x, y))
                except Exception:
                    continue
            allowed_idx = matcher._prefilter_link_indices_by_route_band(pts_xy)
        base_cols = {'seq','time','link_id','from_node_id','to_node_id','longitude','latitude','speed_mph','dis_to_next','match_heading','route_dis', agent_field}
        keep_user_fields = [c for c in matcher.extra_fields if (c in sub_df.columns and c not in base_cols)]
        path_df = matcher._match_one_agent(sub_df.reset_index(drop=True), matcher.lng_field, matcher.lat_field, matcher.time_field, matcher.heading_field, matcher.speed_field, keep_user_fields, allowed_idx, x_col, y_col)
        if not path_df.empty:
            a = sub_df.iloc[0][agent_field]
            path_df[agent_field] = a
        return path_df, None
    except Exception as e:
        return pd.DataFrame(), repr(e)


def _m4g_worker_match_batch(chunk_df: pd.DataFrame) -> Tuple[pd.DataFrame, int, Dict, List]:
    try:
        matcher = _WK_MATCHER
        if matcher is None:
            return pd.DataFrame(), 0, {}, []
        # Run full match quietly inside worker on this chunk (multiple agents)
        import io as _io
        from contextlib import redirect_stdout as _rs, redirect_stderr as _re
        _buf = _io.StringIO()
        with _rs(_buf), _re(_buf):
            res_df, warn_info, err_agents = matcher._match_dataframe(chunk_df)
        try:
            processed = int(chunk_df[matcher.agent_field].nunique())
        except Exception:
            processed = 0
        return res_df, processed, warn_info or {}, err_agents or []
    except Exception:
        return pd.DataFrame(), 0, {}, []


def _m4g_worker_match_partition_file(args) -> Tuple[pd.DataFrame, int, int, Dict, List]:
    part_path, usecols, csv_dtypes = args
    try:
        matcher = _WK_MATCHER
        if matcher is None:
            return pd.DataFrame(), 0, 0, {}, ['worker not initialized']
        df = pd.read_csv(part_path, usecols=usecols, dtype=csv_dtypes, low_memory=True)
        if df is None or df.empty:
            return pd.DataFrame(), 0, 0, {}, []
        rows_in = int(len(df))
        try:
            agents_in = int(df[matcher.agent_field].nunique())
        except Exception:
            agents_in = 0
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            res_df, warn_info, err_agents = matcher._match_dataframe(df)
        return res_df, rows_in, agents_in, (warn_info or {}), (err_agents or [])
    except Exception as e:
        return pd.DataFrame(), 0, 0, {}, [repr(e)]


def _m4g_worker_match_stream_batch(chunk_df: pd.DataFrame) -> Tuple[pd.DataFrame, int, int, Dict, List]:
    try:
        matcher = _WK_MATCHER
        if matcher is None:
            return pd.DataFrame(), 0, 0, {}, ['worker not initialized']
        if chunk_df is None or chunk_df.empty:
            return pd.DataFrame(), 0, 0, {}, []
        rows_in = int(len(chunk_df))
        try:
            agents_in = int(chunk_df[matcher.agent_field].nunique())
        except Exception:
            agents_in = 0
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            res_df, warn_info, err_agents, chunk_meta = matcher._match_dataframe_with_meta(chunk_df)
        warn_info = dict(warn_info or {})
        warn_info['__m4g_stats__'] = dict(chunk_meta or {})
        return res_df, rows_in, agents_in, warn_info, (err_agents or [])
    except Exception as e:
        return pd.DataFrame(), 0, 0, {}, [repr(e)]


def _m4g_worker_ping(_arg: int = 0) -> int:
    try:
        matcher = _WK_MATCHER
        if matcher is None:
            return -1
        return int(os.getpid())
    except Exception:
        return -1


class MapMatcher(MapMatcher):
    def multi_core_match(self, gps_df: pd.DataFrame, core_num: Optional[int] = None, batch_size: Optional[int] = None) -> Tuple[pd.DataFrame, Dict, List]:
        # Legacy entrypoint kept for compatibility.
        # All matching now uses the unified dataframe matcher logic.
        return self._match_dataframe(gps_df)

    def _match_csv_in_chunks(self,
                             gps_csv_path: str,
                             *,
                             chunksize: int = 200000,
                             csv_usecols: Optional[List[str]] = None,
                             csv_dtypes: Optional[Dict[str, str]] = None,
                             core_num: Optional[int] = None) -> Tuple[pd.DataFrame, Dict, List]:
        """
        Memory-safe matcher for very large CSV files.
        Results are appended directly to output CSV on disk.
        """
        if chunksize is None or int(chunksize) <= 0:
            raise ValueError('chunksize must be a positive integer')
        stream_start_ts = time.perf_counter()
        start_elapsed_timer(self.show_progress)

        required_cols = {self.agent_field, self.lng_field, self.lat_field}
        optional_cols = []
        if self.time_field:
            optional_cols.append(self.time_field)
        if self.speed_field:
            optional_cols.append(self.speed_field)
        if self.heading_field:
            optional_cols.append(self.heading_field)
        optional_cols.extend([c for c in self.extra_fields if isinstance(c, str)])
        if self.use_node_restrict:
            optional_cols.append(self.gps_node_field)
        header_cols = pd.read_csv(gps_csv_path, nrows=0).columns.tolist()
        missing_required = [c for c in required_cols if c not in header_cols]
        if missing_required:
            raise ValueError(f'missing required columns in CSV: {missing_required}')
        all_cols = list(required_cols.union(optional_cols))
        if csv_usecols is not None:
            usecols = [c for c in csv_usecols if c in header_cols]
        else:
            usecols = [c for c in all_cols if c in header_cols]

        os.makedirs(self.out_dir, exist_ok=True)
        result_path = os.path.join(self.out_dir, self.result_file)
        route_path = os.path.join(self.out_dir, self.route_file)

        if os.path.exists(result_path):
            os.remove(result_path)
        if self.export_route and os.path.exists(route_path):
            os.remove(route_path)

        prev_export_csv = self.export_csv
        prev_export_geo = self.export_geo
        prev_export_route = self.export_route
        prev_core_num = self.default_core_num

        self.export_csv = False
        self.export_geo = False
        # Route expansion can explode memory/time on very large files.
        self.export_route = False
        requested_core = 1 if core_num is None else max(1, int(core_num))
        cpu_cores = max(1, int(os.cpu_count() or 1))
        req_core = min(requested_core, cpu_cores)
        if requested_core > cpu_cores and self.verbose:
            log_progress_line(
                f"Requested workers ({requested_core}) exceed CPU cores ({cpu_cores}); using {req_core} workers."
            )
        if req_core > 1 and self.verbose:
            log_progress_line(f"Multiprocessing enabled: {req_core} workers")
        # Parent-side matching (fallback path) stays single-core.
        self.default_core_num = 1

        rows_read = 0
        rows_submitted = 0
        rows_matched = 0
        agents_processed = 0
        journeys_input = 0
        journeys_dropped = 0
        journeys_kept = 0
        journeys_matched = 0
        chunks_total = 0
        chunks_submitted = 0
        warn_info_all: Dict = {}
        err_agents_all: List = []
        wrote_header = False
        wrote_route_header = False
        partition_count = 1024
        partition_dir: Optional[str] = None
        partition_paths: List[str] = []
        partition_headers: List[bool] = []
        partition_rows: List[int] = []
        route_export_requested = bool(prev_export_route)
        parallel_workers_effective = 1
        parallel_fallback_reason = ""

        def _count_csv_data_rows(path: str) -> Optional[int]:
            # Fast line counting in binary mode; assumes one record per line.
            # If parsing edge-cases exist (embedded newlines in quoted fields),
            # this can be approximate.
            try:
                cnt = 0
                with open(path, 'rb') as fin:
                    while True:
                        blk = fin.read(8 * 1024 * 1024)
                        if not blk:
                            break
                        cnt += blk.count(b'\n')
                if cnt <= 0:
                    return 0
                return max(0, cnt - 1)  # subtract header line
            except Exception:
                return None

        def _run_chunk(df_chunk: pd.DataFrame) -> None:
            nonlocal rows_submitted, rows_matched, chunks_submitted, wrote_header, wrote_route_header, agents_processed
            nonlocal journeys_input, journeys_dropped, journeys_kept, journeys_matched
            if df_chunk is None or df_chunk.empty:
                return
            rows_in = int(len(df_chunk))
            try:
                agents_in = int(df_chunk[self.agent_field].nunique())
            except Exception:
                agents_in = 0
            prev_show_progress = self.show_progress
            self.show_progress = False
            try:
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    res_df, warn_info, err_agents, chunk_meta = self._match_dataframe_with_meta(df_chunk)
            finally:
                self.show_progress = prev_show_progress

            chunks_submitted += 1
            rows_submitted += rows_in
            agents_processed += agents_in
            journeys_input += int(chunk_meta.get('input_journeys', agents_in))
            journeys_dropped += int(chunk_meta.get('dropped_journeys', 0))
            journeys_kept += int(chunk_meta.get('kept_journeys', max(0, agents_in)))
            if warn_info:
                warn_info_all.update(warn_info)
            if err_agents:
                err_agents_all.extend(err_agents)
            if isinstance(res_df, pd.DataFrame) and not res_df.empty:
                rows_matched += len(res_df)
                try:
                    journeys_matched += int(res_df[self.agent_field].nunique())
                except Exception:
                    pass
                res_df.to_csv(result_path, mode='a', index=False, header=not wrote_header)
                wrote_header = True
                if route_export_requested:
                    route_chunk_df = _build_grouped_route_df(res_df)
                    if not route_chunk_df.empty:
                        route_chunk_df.to_csv(route_path, mode='a', index=False, header=not wrote_route_header)
                        wrote_route_header = True

        def _build_grouped_route_df(res_local: pd.DataFrame) -> pd.DataFrame:
            if res_local is None or res_local.empty:
                return pd.DataFrame(columns=['journey_id', 'link_ids'])
            if self.agent_field not in res_local.columns or 'link_id' not in res_local.columns:
                return pd.DataFrame(columns=['journey_id', 'link_ids'])

            group_order = None
            try:
                if 'time' in res_local.columns and res_local['time'].notna().any():
                    tmpc = '__sort_time__'
                    if self.time_format:
                        res_local[tmpc] = pd.to_datetime(res_local['time'], errors='coerce', format=self.time_format)
                    else:
                        res_local[tmpc] = pd.to_datetime(res_local['time'], errors='coerce', infer_datetime_format=True)
                    group_start = res_local.groupby(self.agent_field, dropna=False)[tmpc].min().reset_index()
                    group_start = group_start.sort_values(by=[tmpc, self.agent_field], ascending=[True, True], ignore_index=True)
                    group_order = group_start[self.agent_field].tolist()
                    del res_local[tmpc]
            except Exception:
                group_order = None

            if group_order is None:
                try:
                    group_order = res_local[self.agent_field].dropna().unique().tolist()
                except Exception:
                    group_order = []

            grouped_routes = []
            for agent in group_order:
                try:
                    df_g = res_local[res_local[self.agent_field] == agent].copy()
                    if df_g.empty:
                        continue
                    if 'seq' in df_g.columns:
                        df_g = df_g.sort_values(by='seq', ascending=True)
                    elif 'time' in df_g.columns:
                        df_g = df_g.sort_values(by='time', ascending=True)
                    df_g = df_g.reset_index(drop=True)

                    expanded: List[int] = []

                    def _append_link_id(lid: int):
                        if not expanded or expanded[-1] != int(lid):
                            expanded.append(int(lid))

                    first_link = self.net.link_dict.get(int(df_g.at[0, 'link_id']))
                    if first_link is None:
                        continue
                    _append_link_id(int(first_link.link_id))

                    for i in range(len(df_g) - 1):
                        cur_lk = self.net.link_dict.get(int(df_g.at[i, 'link_id']))
                        nxt_lk = self.net.link_dict.get(int(df_g.at[i + 1, 'link_id']))
                        if cur_lk is None or nxt_lk is None:
                            continue
                        if (int(cur_lk.link_id) == int(nxt_lk.link_id)) or \
                           (getattr(cur_lk, 'to_node', None) and getattr(nxt_lk, 'from_node', None) and
                            int(cur_lk.to_node.node_id) == int(nxt_lk.from_node.node_id)):
                            _append_link_id(int(nxt_lk.link_id))
                            continue

                        key = (int(cur_lk.link_id), int(nxt_lk.link_id))
                        nodes = self._ft_node_path.get(key, [])
                        if not nodes:
                            try:
                                u = int(cur_lk.to_node.node_id)
                                v = int(nxt_lk.from_node.node_id)
                                nodes = self._shortest_path_nodes(u, v)
                            except Exception:
                                nodes = []
                        if nodes:
                            for j in range(len(nodes) - 1):
                                data = self._edge_data(nodes[j], nodes[j + 1])
                                if not data:
                                    continue
                                lk = data.get('link')
                                if lk is None:
                                    continue
                                _append_link_id(int(lk.link_id))
                        _append_link_id(int(nxt_lk.link_id))

                    if expanded:
                        grouped_routes.append({
                            'journey_id': agent,
                            'link_ids': ','.join(str(lid) for lid in expanded)
                        })
                except Exception:
                    continue

            if not grouped_routes:
                return pd.DataFrame(columns=['journey_id', 'link_ids'])
            return pd.DataFrame(grouped_routes)

        def _sort_outputs_by_journey_first_time() -> None:
            if not os.path.exists(result_path):
                return
            if self.verbose:
                log_progress_line("Sorting outputs by journey first timestamp ...")

            tmp_sort_dir = tempfile.mkdtemp(prefix='m4g_sort_', dir=self.out_dir)
            try:
                # Pass 1: journey -> first valid matched time
                result_header = pd.read_csv(result_path, nrows=0).columns.tolist()
                has_time_col = ('time' in result_header)
                read_cols = [self.agent_field] + (['time'] if has_time_col else [])
                seen_jids: Set[str] = set()
                first_time_by_jid: Dict[str, pd.Timestamp] = {}

                reader = pd.read_csv(
                    result_path,
                    usecols=read_cols,
                    chunksize=int(chunksize),
                    low_memory=True,
                )
                for chunk in reader:
                    if chunk is None or chunk.empty:
                        continue
                    jid_str = chunk[self.agent_field].astype(str)
                    seen_jids.update(jid_str.dropna().unique().tolist())
                    if not has_time_col:
                        continue
                    if self.time_format:
                        tser = pd.to_datetime(chunk['time'], errors='coerce', format=self.time_format)
                    else:
                        tser = pd.to_datetime(chunk['time'], errors='coerce', infer_datetime_format=True)
                    tmp = pd.DataFrame({'__jid': jid_str, '__t': tser}).dropna(subset=['__t'])
                    if tmp.empty:
                        continue
                    grp = tmp.groupby('__jid', sort=False)['__t'].min()
                    for jid, tmin in grp.items():
                        prev = first_time_by_jid.get(jid)
                        if prev is None or tmin < prev:
                            first_time_by_jid[jid] = tmin

                if not seen_jids:
                    return

                if has_time_col:
                    max_ts = pd.Timestamp.max
                    ordered_jids = sorted(
                        seen_jids,
                        key=lambda j: (first_time_by_jid.get(j, max_ts), j),
                    )
                else:
                    ordered_jids = sorted(seen_jids)
                rank_map = {jid: idx for idx, jid in enumerate(ordered_jids)}
                n_rank = len(rank_map)
                if n_rank <= 0:
                    return

                # Reorder route output to match result journey order.
                if route_export_requested and os.path.exists(route_path):
                    try:
                        route_df = pd.read_csv(route_path, low_memory=True)
                        if not route_df.empty and 'journey_id' in route_df.columns:
                            route_df['__rank'] = route_df['journey_id'].astype(str).map(rank_map).fillna(n_rank + 1).astype(np.int64)
                            route_df = route_df.sort_values(by='__rank', kind='mergesort', ignore_index=True)
                            route_df = route_df.drop(columns=['__rank'])
                            route_df.to_csv(route_path, index=False)
                    except Exception:
                        pass

                # Pass 2/3: external reorder matched_result by journey rank.
                bucket_count = min(1024, max(1, n_rank))
                bucket_span = max(1, int(math.ceil(float(n_rank) / float(bucket_count))))
                bucket_paths = [os.path.join(tmp_sort_dir, f'res_bucket_{i:04d}.csv') for i in range(bucket_count)]
                bucket_written = [False] * bucket_count
                fallback_rank = n_rank + 1

                reader = pd.read_csv(result_path, chunksize=int(chunksize), low_memory=True)
                for chunk in reader:
                    if chunk is None or chunk.empty:
                        continue
                    ranks = chunk[self.agent_field].astype(str).map(rank_map).fillna(fallback_rank).astype(np.int64)
                    chunk['__rank'] = ranks
                    chunk['__bucket'] = np.minimum((ranks // bucket_span).to_numpy(dtype=np.int64), bucket_count - 1)
                    for bval, grp in chunk.groupby('__bucket', sort=False):
                        bidx = int(bval)
                        outp = bucket_paths[bidx]
                        grp = grp.drop(columns=['__bucket'])
                        grp.to_csv(outp, mode='a', index=False, header=not bucket_written[bidx])
                        bucket_written[bidx] = True

                sorted_result_path = os.path.join(tmp_sort_dir, 'matched_result_sorted.csv')
                wrote_sorted = False
                for bidx, bpath in enumerate(bucket_paths):
                    if not bucket_written[bidx] or not os.path.exists(bpath):
                        continue
                    bdf = pd.read_csv(bpath, low_memory=True)
                    if bdf.empty:
                        continue
                    bdf = bdf.sort_values(by='__rank', kind='mergesort', ignore_index=True)
                    bdf = bdf.drop(columns=['__rank'])
                    bdf.to_csv(sorted_result_path, mode='a', index=False, header=not wrote_sorted)
                    wrote_sorted = True

                if wrote_sorted and os.path.exists(sorted_result_path):
                    os.replace(sorted_result_path, result_path)
            finally:
                shutil.rmtree(tmp_sort_dir, ignore_errors=True)

        def _build_stream_worker_kwargs() -> Dict:
            return {
                'agent_field': self.agent_field,
                'lng_field': self.lng_field,
                'lat_field': self.lat_field,
                'time_field': self.time_field,
                'speed_field': self.speed_field,
                'heading_field': self.heading_field,
                'max_gap_seconds': self.max_gap_seconds,
                'search_radius': self.search_radius,
                'noise_sigma': self.noise_sigma,
                'trans_weight': self.trans_weight,
                'dist_penalty': self.dist_penalty,
                'max_candidates': self.max_candidates,
                'use_heading': self.use_heading,
                'heading_sigma': self.heading_sigma,
                'time_format': self.time_format,
                'extra_fields': self.extra_fields,
                'turn_sigma': self.turn_sigma,
                'heading_len': self.heading_len,
                'route_gap': self.route_gap,
                'use_node_restrict': self.use_node_restrict,
                'filter_dwell': self.filter_dwell,
                'dwell_dist': self.dwell_dist,
                'dwell_count': self.dwell_count,
                'out_dir': self.out_dir,
                'min_link_len': self.min_link_len,
                'speed_limit': self.speed_limit,
                'heading_weights': self.heading_weights,
                'max_agents': None,
                'debug': False,
                'verbose': False,
                'show_progress': False,
                'stop_event': None,
            }

        try:
            total_input_rows = _count_csv_data_rows(gps_csv_path)

            partition_dir = tempfile.mkdtemp(prefix='m4g_partitions_', dir=self.out_dir)
            partition_paths = [os.path.join(partition_dir, f'part_{i:04d}.csv') for i in range(partition_count)]
            partition_headers = [False] * partition_count
            partition_rows = [0] * partition_count

            load_pbar = None
            if self.show_progress:
                set_elapsed_timer_position(2)
                load_bar_fmt = "{desc}: {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]"
                if total_input_rows is None:
                    load_bar_fmt = "{desc}: {n_fmt} [{elapsed}, {rate_fmt}]"
                load_pbar = tqdm(total=total_input_rows,
                                 desc="Loading data",
                                 dynamic_ncols=True,
                                 ascii=True,
                                 bar_format=load_bar_fmt,
                                 mininterval=1.0,
                                 maxinterval=1.0,
                                 miniters=1,
                                 position=0,
                                 file=sys.stdout)

            reader = pd.read_csv(
                gps_csv_path,
                chunksize=int(chunksize),
                usecols=usecols,
                dtype=csv_dtypes,
                low_memory=True,
            )
            try:
                for chunk in reader:
                    chunks_total += 1
                    if chunk is None or chunk.empty:
                        continue
                    rows_read += len(chunk)
                    if load_pbar is not None:
                        load_pbar.update(len(chunk))
                    pids = (pd.util.hash_pandas_object(chunk[self.agent_field].astype(str), index=False).to_numpy(dtype='uint64') % np.uint64(partition_count)).astype(np.int64)
                    chunk['__m4g_pid__'] = pids
                    for pid_val, grp in chunk.groupby('__m4g_pid__', sort=False):
                        pid = int(pid_val)
                        out_path = partition_paths[pid]
                        out_df = grp.drop(columns=['__m4g_pid__'])
                        out_df.to_csv(out_path, mode='a', index=False, header=not partition_headers[pid])
                        partition_headers[pid] = True
                        partition_rows[pid] += len(out_df)
            finally:
                if load_pbar is not None:
                    load_pbar.close()
                    set_elapsed_timer_position(1)

            # Start from smaller partitions so progress appears earlier instead of
            # waiting on a very large first partition.
            non_empty_pids = sorted(
                [i for i, cnt in enumerate(partition_rows) if cnt > 0],
                key=lambda i: partition_rows[i]
            )
            total_rows_to_match = int(sum(partition_rows))
            # Smaller journey batches provide more frequent progress updates
            # and better load balancing for uneven trajectory lengths.
            journey_batch_size = _FIXED_JOURNEY_BATCH_SIZE

            def _iter_partition_batches():
                # Yield small journey-coherent batches to increase progress update frequency.
                for pid in non_empty_pids:
                    part_path = partition_paths[pid]
                    part_df = pd.read_csv(part_path, usecols=usecols, dtype=csv_dtypes, low_memory=True)
                    groups: List[pd.DataFrame] = []
                    gcount = 0
                    for _, grp in part_df.groupby(self.agent_field, sort=False):
                        groups.append(grp)
                        gcount += 1
                        if gcount >= journey_batch_size:
                            yield pd.concat(groups, ignore_index=True)
                            groups = []
                            gcount = 0
                    if groups:
                        yield pd.concat(groups, ignore_index=True)

            def _iter_partition_batches_with_submit_progress():
                # Update row progress when a batch starts processing (dispatched).
                for batch_df in _iter_partition_batches():
                    _advance_processing_pbar(int(len(batch_df)))
                    yield batch_df

            pbar = None
            def _advance_processing_pbar(rows_inc: int):
                nonlocal pbar
                if not self.show_progress:
                    return
                inc = int(rows_inc) if rows_inc is not None else 0
                if inc < 0:
                    inc = 0
                if pbar is None:
                    set_elapsed_timer_position(2)
                    init_n = min(inc, total_rows_to_match) if total_rows_to_match is not None else inc
                    pbar = tqdm(total=total_rows_to_match,
                                initial=init_n,
                                desc="Processing data",
                                dynamic_ncols=True,
                                ascii=True,
                                bar_format="{desc}: {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]{postfix}",
                                mininterval=1.0,
                                maxinterval=1.0,
                                miniters=1,
                                position=0,
                                file=sys.stdout)
                    if inc > init_n:
                        pbar.update(inc - init_n)
                else:
                    pbar.update(inc)

            def _consume_worker_result(res_df, rows_in, agents_in, warn_info, err_agents) -> None:
                nonlocal chunks_submitted, rows_submitted, agents_processed, rows_matched
                nonlocal journeys_input, journeys_dropped, journeys_kept, journeys_matched
                nonlocal wrote_header, wrote_route_header
                chunks_submitted += 1
                rows_submitted += int(rows_in)
                agents_processed += int(agents_in)
                chunk_meta = {}
                if isinstance(warn_info, dict):
                    chunk_meta = dict(warn_info.pop('__m4g_stats__', {}) or {})
                    if warn_info:
                        warn_info_all.update(warn_info)
                journeys_input += int(chunk_meta.get('input_journeys', agents_in))
                journeys_dropped += int(chunk_meta.get('dropped_journeys', 0))
                journeys_kept += int(chunk_meta.get('kept_journeys', max(0, int(agents_in))))
                if err_agents:
                    err_agents_all.extend(err_agents)
                if isinstance(res_df, pd.DataFrame) and not res_df.empty:
                    rows_matched += len(res_df)
                    try:
                        journeys_matched += int(res_df[self.agent_field].nunique())
                    except Exception:
                        pass
                    res_df.to_csv(result_path, mode='a', index=False, header=not wrote_header)
                    wrote_header = True
                    if route_export_requested:
                        route_chunk_df = _build_grouped_route_df(res_df)
                        if not route_chunk_df.empty:
                            route_chunk_df.to_csv(route_path, mode='a', index=False, header=not wrote_route_header)
                            wrote_route_header = True
                if pbar is not None:
                    pbar.set_postfix_str(f"Processed agents: {agents_processed:,}", refresh=False)

            try:
                used_multi_pool = False
                if req_core > 1 and len(non_empty_pids) > 1:
                    init_kwargs = _build_stream_worker_kwargs()
                    source_cfg = getattr(self.net, '_m4g_source', None)
                    try:
                        init_t0 = time.perf_counter()
                        if source_cfg is None:
                            parallel_fallback_reason = 'network source metadata unavailable for joblib streaming multiprocessing'
                            raise RuntimeError(parallel_fallback_reason)
                        if self.verbose:
                            log_progress_line(f"Initializing joblib pool ({req_core} workers) ...")
                        used_multi_pool = True
                        parallel_workers_effective = int(req_core)

                        def _joblib_task_iter():
                            for batch_df in _iter_partition_batches_with_submit_progress():
                                yield delayed(_m4g_joblib_match_stream_batch)((batch_df, source_cfg, init_kwargs))

                        try:
                            results_iter = Parallel(
                                n_jobs=req_core,
                                backend='loky',
                                return_as='generator_unordered',
                            )(_joblib_task_iter())
                            if self.verbose:
                                log_progress_line(f"Joblib pool ready ({time.perf_counter() - init_t0:.2f}s)")
                            for res_df, rows_in, agents_in, warn_info, err_agents in results_iter:
                                _consume_worker_result(res_df, rows_in, agents_in, warn_info, err_agents)
                        except TypeError:
                            # Older joblib versions may not support return_as generator.
                            # Use bounded block dispatch to avoid materializing all results.
                            if self.verbose:
                                log_progress_line("Joblib generator mode unsupported; using bounded block dispatch.")
                            block_size = max(8, int(req_core) * 2)
                            pending: List[pd.DataFrame] = []
                            first_ready_logged = False
                            with Parallel(n_jobs=req_core, backend='loky') as parallel:
                                for batch_df in _iter_partition_batches_with_submit_progress():
                                    pending.append(batch_df)
                                    if len(pending) < block_size:
                                        continue
                                    block_tasks = [
                                        delayed(_m4g_joblib_match_stream_batch)((dfb, source_cfg, init_kwargs))
                                        for dfb in pending
                                    ]
                                    block_results = parallel(block_tasks)
                                    if self.verbose and (not first_ready_logged):
                                        log_progress_line(f"Joblib pool ready ({time.perf_counter() - init_t0:.2f}s)")
                                        first_ready_logged = True
                                    for res_df, rows_in, agents_in, warn_info, err_agents in block_results:
                                        _consume_worker_result(res_df, rows_in, agents_in, warn_info, err_agents)
                                    pending = []
                                if pending:
                                    block_tasks = [
                                        delayed(_m4g_joblib_match_stream_batch)((dfb, source_cfg, init_kwargs))
                                        for dfb in pending
                                    ]
                                    block_results = parallel(block_tasks)
                                    if self.verbose and (not first_ready_logged):
                                        log_progress_line(f"Joblib pool ready ({time.perf_counter() - init_t0:.2f}s)")
                                    for res_df, rows_in, agents_in, warn_info, err_agents in block_results:
                                        _consume_worker_result(res_df, rows_in, agents_in, warn_info, err_agents)
                    except Exception as e:
                        used_multi_pool = False
                        parallel_workers_effective = 1
                        if not parallel_fallback_reason:
                            parallel_fallback_reason = str(e)
                        if self.verbose:
                            log_progress_line(f"Warning: streaming joblib multiprocessing failed ({e}); falling back to single-core.")

                if not used_multi_pool:
                    for batch_df in _iter_partition_batches():
                        _advance_processing_pbar(len(batch_df))
                        _run_chunk(batch_df)
                        if pbar is not None:
                            pbar.set_postfix_str(f"Processed agents: {agents_processed:,}", refresh=False)
                        if _FIXED_CLEAR_CACHE_EVERY > 0 and chunks_submitted % _FIXED_CLEAR_CACHE_EVERY == 0:
                            self._node_pair_cost.clear()
                            self._ft_node_path.clear()
                            self._path_cache.clear()
                            if self._full_path_cache is not self._path_cache:
                                self._full_path_cache.clear()
            finally:
                if pbar is not None:
                    pbar.close()
                    set_elapsed_timer_position(1)

            if wrote_header:
                _sort_outputs_by_journey_first_time()

        finally:
            self.export_csv = prev_export_csv
            self.export_geo = prev_export_geo
            self.export_route = prev_export_route
            self.default_core_num = prev_core_num
            if partition_dir:
                shutil.rmtree(partition_dir, ignore_errors=True)
            stop_elapsed_timer(clear_output_line=True)

        elapsed_sec = float(time.perf_counter() - stream_start_ts)
        elapsed_total_sec = max(0, int(round(elapsed_sec)))
        elapsed_h = elapsed_total_sec // 3600
        elapsed_m = (elapsed_total_sec % 3600) // 60
        elapsed_s = elapsed_total_sec % 60
        if elapsed_h > 0:
            elapsed_str = f"{elapsed_h:02d}:{elapsed_m:02d}:{elapsed_s:02d}"
        else:
            elapsed_str = f"{elapsed_m:02d}:{elapsed_s:02d}"
        input_j = int(max(0, journeys_input))
        dropped_j = int(max(0, journeys_dropped))
        kept_j = int(max(0, journeys_kept))
        matched_j = int(max(0, journeys_matched))
        input_pts = int(max(0, rows_read))
        matched_pts = int(max(0, rows_matched))
        matched_j_rate = (100.0 * matched_j / kept_j) if kept_j > 0 else 0.0
        matched_pt_rate = (100.0 * matched_pts / input_pts) if input_pts > 0 else 0.0

        summary_lines = [
            "Summary:",
            f"- Input journeys: {input_j:,}",
            f"- Dropped journeys (time-gap/invalid-time): {dropped_j:,}",
            f"- Kept journeys: {kept_j:,}",
            f"- Matched journeys: {matched_j:,} ({matched_j_rate:.2f}%)",
            f"- Input data points: {input_pts:,}",
            f"- Matched data points: {matched_pts:,} ({matched_pt_rate:.2f}%)",
        ]
        summary_path = os.path.join(self.out_dir, 'summary.txt')
        try:
            with open(summary_path, 'w', encoding='utf-8') as fout:
                fout.write('\n'.join(summary_lines))
                fout.write('\n\n')
                fout.write(f"Total elapsed time: {elapsed_str}\n")
        except Exception:
            summary_path = ""

        if self.verbose:
            for line in summary_lines:
                log_progress_line(line)
            log_progress_line("Map Matching Completed")
            log_progress_line("")
            log_progress_line(f"Total elapsed time: {elapsed_str}")

        stats = {
            'result_path': result_path,
            'rows_read': int(rows_read),
            'rows_submitted': int(rows_submitted),
            'rows_matched': int(rows_matched),
            'input_journeys': int(max(0, journeys_input)),
            'dropped_journeys': int(max(0, journeys_dropped)),
            'kept_journeys': int(max(0, journeys_kept)),
            'matched_journeys': int(max(0, journeys_matched)),
            'agents_processed': int(agents_processed),
            'summary_path': summary_path,
            'elapsed_seconds': elapsed_sec,
            'elapsed_readable': elapsed_str,
            'chunks_read': int(chunks_total),
            'chunks_submitted': int(chunks_submitted),
            'partitions': int(partition_count),
            'warnings': int(len(warn_info_all)),
            'error_agents': int(len(err_agents_all)),
            'parallel_backend': 'joblib',
            'parallel_workers_requested': int(max(1, requested_core)),
            'parallel_workers_effective': int(max(1, parallel_workers_effective)),
            'parallel_fallback_reason': str(parallel_fallback_reason or ''),
        }
        warn_info_all = dict(warn_info_all or {})
        warn_info_all['__stream_stats__'] = stats
        if parallel_fallback_reason:
            warn_info_all['__parallel_warning__'] = str(parallel_fallback_reason)
        return pd.DataFrame(), warn_info_all, err_agents_all
