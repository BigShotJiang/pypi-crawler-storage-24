"""Auto-generated at build time — do not edit."""

VERSION = 'v0.14.0'
GIT_SHA_SHORT = '45489c5'
GIT_SHA_FULL = '45489c5cb706663db86e62882da92d170f2c20ff'
