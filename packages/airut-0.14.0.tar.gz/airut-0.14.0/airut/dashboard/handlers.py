# Copyright (c) 2026 Pyry Haulos
#
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT

"""HTTP request handlers for dashboard server.

Provides handler functions for all dashboard HTTP endpoints.
"""

import json
import logging
from collections.abc import Callable, Iterable
from datetime import datetime
from pathlib import Path
from typing import Any

from werkzeug.wrappers import Request, Response

from airut.claude_output.types import StreamEvent
from airut.conversation import (
    ConversationMetadata,
    ConversationStore,
)
from airut.dashboard import views
from airut.dashboard.formatters import VersionInfo
from airut.dashboard.sse import (
    SSEConnectionManager,
    render_events_html,
    render_network_lines_html,
    sse_events_log_stream,
    sse_network_log_stream,
    sse_state_stream,
)
from airut.dashboard.tracker import (
    ACTIVE_STATUSES,
    BootState,
    CompletionReason,
    RepoState,
    TaskState,
    TaskStatus,
    TaskTracker,
)
from airut.dashboard.versioned import VersionClock, VersionedStore
from airut.dashboard.views import get_favicon_svg
from airut.gateway.conversation import CONVERSATION_ID_PATTERN
from airut.sandbox import NETWORK_LOG_FILENAME, EventLog, NetworkLog
from airut.version import (
    GitVersionInfo,
    check_upstream_version,
    github_commit_url,
    github_release_url,
)


logger = logging.getLogger(__name__)


class RequestHandlers:
    """Container for HTTP request handlers.

    Encapsulates all handler logic and dependencies needed to process
    dashboard HTTP requests.
    """

    def __init__(
        self,
        tracker: TaskTracker,
        version_info: VersionInfo | None = None,
        work_dirs: Callable[[], list[Path]] | None = None,
        stop_callback: Callable[[str], bool] | None = None,
        boot_store: VersionedStore[BootState] | None = None,
        repos_store: VersionedStore[tuple[RepoState, ...]] | None = None,
        clock: VersionClock | None = None,
        sse_manager: SSEConnectionManager | None = None,
        git_version_info: GitVersionInfo | None = None,
    ) -> None:
        """Initialize request handlers.

        Args:
            tracker: Task tracker to query for state.
            version_info: Optional version information to display.
            work_dirs: Callable returning directories where conversation data
                is stored.  Called on each request to get current state.
            stop_callback: Optional callable to stop an execution.
            boot_store: Versioned boot state store.
            repos_store: Versioned repo states store.
            clock: Shared version clock for SSE streaming.
            sse_manager: SSE connection manager for enforcing limits.
            git_version_info: Git version info for upstream update checks.
        """
        self.tracker = tracker
        self.version_info = version_info
        self._work_dirs = work_dirs or (lambda: [])
        self.stop_callback = stop_callback
        self._boot_store = boot_store
        self._repos_store = repos_store
        self._clock = clock
        self._sse_manager = sse_manager or SSEConnectionManager()
        self._git_version_info = git_version_info

    def _get_boot_state(self) -> BootState | None:
        """Read current boot state from versioned store."""
        if self._boot_store is None:
            return None
        return self._boot_store.get().value

    def _get_repo_states(self) -> list[RepoState]:
        """Read current repo states from versioned store."""
        if self._repos_store is None:
            return []
        return list(self._repos_store.get().value)

    def handle_favicon(self, request: Request) -> Response:
        """Handle favicon request.

        Serves the logo SVG as favicon.

        Args:
            request: Incoming request.

        Returns:
            SVG response with logo.
        """
        return Response(
            get_favicon_svg(),
            content_type="image/svg+xml",
            headers={
                "Cache-Control": "public, max-age=86400",
            },
        )

    def handle_index(self, request: Request) -> Response:
        """Handle main dashboard page.

        Args:
            request: Incoming request.

        Returns:
            HTML response with dashboard.
        """
        counts = self.tracker.get_counts()
        # Pending column: QUEUED + AUTHENTICATING + PENDING
        pending = (
            self.tracker.get_tasks_by_status(TaskStatus.QUEUED)
            + self.tracker.get_tasks_by_status(TaskStatus.AUTHENTICATING)
            + self.tracker.get_tasks_by_status(TaskStatus.PENDING)
        )
        executing = self.tracker.get_tasks_by_status(TaskStatus.EXECUTING)
        completed = self.tracker.get_tasks_by_status(TaskStatus.COMPLETED)
        boot_state = self._get_boot_state()

        return Response(
            views.render_dashboard(
                counts,
                pending,
                executing,
                completed,
                self.version_info,
                self._get_repo_states(),
                boot_state=boot_state,
            ),
            content_type="text/html; charset=utf-8",
        )

    def handle_version(self, request: Request) -> Response:
        """Handle version info endpoint.

        Args:
            request: Incoming request.

        Returns:
            JSON response with structured version info.
        """
        if not self.version_info:
            return Response(
                json.dumps({"error": "Version info not available"}),
                status=404,
                content_type="application/json",
            )

        data = {
            "version": self.version_info.version,
            "sha_short": self.version_info.git_sha,
            "sha_full": self.version_info.git_sha_full,
        }

        return Response(
            json.dumps(data),
            content_type="application/json",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
            },
        )

    def handle_update(self, request: Request) -> Response:
        """Handle update check endpoint.

        Returns the current version and the latest upstream version.
        The upstream check may involve an HTTP request to PyPI or GitHub,
        so this endpoint is separate from /api/version to avoid blocking
        dashboard load.

        Args:
            request: Incoming request.

        Returns:
            JSON response with current and latest version info.
        """
        if not self._git_version_info:
            return Response(
                json.dumps({"error": "Version info not available"}),
                status=404,
                content_type="application/json",
            )

        upstream = check_upstream_version(self._git_version_info)

        data: dict[str, Any] = {
            "current": (
                self._git_version_info.version
                or self._git_version_info.sha_short
            ),
        }

        if upstream is not None:
            data["latest"] = upstream.latest
            data["update_available"] = upstream.update_available
            data["source"] = upstream.source
            # Provide a direct link to the new release/commit page.
            if upstream.update_available:
                if upstream.source == "pypi":
                    data["release_url"] = github_release_url(upstream.latest)
                else:
                    data["release_url"] = github_commit_url(upstream.latest)
            else:
                data["release_url"] = None
        else:
            data["latest"] = None
            data["update_available"] = False
            data["source"] = None
            data["release_url"] = None

        return Response(
            json.dumps(data),
            content_type="application/json",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
            },
        )

    def handle_task_detail_by_id(
        self, request: Request, task_id: str
    ) -> Response:
        """Handle task detail page (by task_id).

        Args:
            request: Incoming request.
            task_id: Task ID to show.

        Returns:
            HTML response with task details.
        """
        task = self.tracker.get_task(task_id)
        if task is None:
            return Response("Task not found", status=404)

        conversation = None
        if task.conversation_id:
            conversation = self._load_conversation(task.conversation_id)

        return Response(
            views.render_task_detail(task, conversation),
            content_type="text/html; charset=utf-8",
        )

    def handle_conversation_detail(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle conversation overview page.

        Shows all tasks for a conversation with links to individual
        task pages, plus aggregate stats and full reply history.

        Args:
            request: Incoming request.
            conversation_id: Conversation ID to show.

        Returns:
            HTML response with conversation overview.
        """
        tasks = self.tracker.get_tasks_for_conversation(conversation_id)
        conversation = self._load_conversation(conversation_id)

        # Fall back to disk for past conversations.  Both
        # _load_conversation and _load_task_from_disk resolve the same
        # directory, so if the disk result exists the conversation is
        # already loaded above.
        if not tasks:
            disk_result = self._load_task_from_disk(conversation_id)
            if disk_result is not None:
                task, _conv = disk_result
                tasks = [task]

        if not tasks and conversation is None:
            return Response("Conversation not found", status=404)

        return Response(
            views.render_conversation_detail(
                conversation_id, tasks, conversation
            ),
            content_type="text/html; charset=utf-8",
        )

    def handle_task_actions(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle actions viewer page.

        Args:
            request: Incoming request.
            conversation_id: Conversation ID to show actions for.

        Returns:
            HTML response with actions viewer.
        """
        result = self._load_task_with_conversation(conversation_id)
        if result is None:
            return Response("Conversation not found", status=404)
        task, conversation = result

        # Load events from event log for the actions view
        conversation_dir = self._find_conversation_dir(conversation_id)
        event_groups = None
        event_log_offset = 0
        if conversation_dir is not None:
            event_log = EventLog(conversation_dir)
            event_groups = event_log.read_all()
            # Capture byte offset so SSE starts after already-rendered events
            if event_log.file_path.exists():
                event_log_offset = event_log.file_path.stat().st_size

        return Response(
            views.render_actions_page(
                task,
                conversation,
                event_groups,
                event_log_offset=event_log_offset,
            ),
            content_type="text/html; charset=utf-8",
        )

    def handle_task_network(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle network logs viewer page.

        Args:
            request: Incoming request.
            conversation_id: Conversation ID to show network logs for.

        Returns:
            HTML response with network logs viewer.
        """
        result = self._load_task_with_conversation(conversation_id)
        if result is None:
            return Response("Conversation not found", status=404)
        task, _ = result

        # Load network logs from conversation directory
        conversation_dir = self._find_conversation_dir(conversation_id)
        log_content: str | None = None
        network_log_offset = 0
        if conversation_dir is not None:
            log_path = conversation_dir / NETWORK_LOG_FILENAME
            if log_path.exists():
                try:
                    log_content = log_path.read_text()
                    # Capture byte offset so SSE starts after rendered lines
                    network_log_offset = log_path.stat().st_size
                except OSError as e:
                    logger.warning(
                        "Failed to read network log %s: %s", log_path, e
                    )

        return Response(
            views.render_network_page(
                task, log_content, network_log_offset=network_log_offset
            ),
            content_type="text/html; charset=utf-8",
        )

    def handle_api_task_by_id(self, request: Request, task_id: str) -> Response:
        """Handle JSON API for single task by task_id.

        Args:
            request: Incoming request.
            task_id: Task ID to return.

        Returns:
            JSON response with task details.
        """
        task = self.tracker.get_task(task_id)
        if task is None:
            return Response(
                json.dumps({"error": "Task not found"}),
                status=404,
                content_type="application/json",
            )

        conversation = None
        if task.conversation_id:
            conversation = self._load_conversation(task.conversation_id)

        return Response(
            json.dumps(
                self._task_to_dict(
                    task,
                    include_conversation=True,
                    conversation=conversation,
                )
            ),
            content_type="application/json",
        )

    def handle_api_tasks(self, request: Request) -> Response:
        """Handle JSON API for all tasks.

        Supports ETag-based conditional requests. If the client sends
        an ``If-None-Match`` header matching the current version, returns
        304 Not Modified.

        Args:
            request: Incoming request.

        Returns:
            JSON response with task list, or 304 if unchanged.
        """
        version = self._get_clock_version()
        etag = f'"v{version}"'

        if request.headers.get("If-None-Match") == etag:
            return Response(status=304, headers={"ETag": etag})

        tasks = self.tracker.get_all_tasks()
        return Response(
            json.dumps([self._task_to_dict(t) for t in tasks]),
            content_type="application/json",
            headers={"ETag": etag, "Cache-Control": "no-cache"},
        )

    def handle_api_task(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle JSON API for single conversation.

        Args:
            request: Incoming request.
            conversation_id: Conversation ID to return.

        Returns:
            JSON response with conversation details.
        """
        result = self._load_task_with_conversation(conversation_id)
        if result is None:
            return Response(
                json.dumps({"error": "Conversation not found"}),
                status=404,
                content_type="application/json",
            )
        task, conversation = result

        # Load events for the API response
        conversation_dir = self._find_conversation_dir(conversation_id)
        event_groups = None
        if conversation_dir is not None:
            event_log = EventLog(conversation_dir)
            event_groups = event_log.read_all()

        return Response(
            json.dumps(
                self._task_to_dict(
                    task,
                    include_conversation=True,
                    conversation=conversation,
                    event_groups=event_groups,
                )
            ),
            content_type="application/json",
        )

    def handle_repo_detail(self, request: Request, repo_id: str) -> Response:
        """Handle repository detail page.

        Args:
            request: Incoming request.
            repo_id: Repository ID to show.

        Returns:
            HTML response with repository details.
        """
        repo_state = next(
            (r for r in self._get_repo_states() if r.repo_id == repo_id), None
        )
        if repo_state is None:
            return Response("Repository not found", status=404)

        return Response(
            views.render_repo_detail(repo_state),
            content_type="text/html; charset=utf-8",
        )

    def handle_api_repos(self, request: Request) -> Response:
        """Handle JSON API for repository status.

        Supports ETag-based conditional requests.

        Args:
            request: Incoming request.

        Returns:
            JSON response with repository status list, or 304.
        """
        version = self._get_clock_version()
        etag = f'"v{version}"'

        if request.headers.get("If-None-Match") == etag:
            return Response(status=304, headers={"ETag": etag})

        repos = [
            {
                "repo_id": r.repo_id,
                "status": r.status.value,
                "error_message": r.error_message,
                "error_type": r.error_type,
                "git_repo_url": r.git_repo_url,
                "channels": [
                    {"type": ch.channel_type, "info": ch.info}
                    for ch in r.channels
                ],
                "storage_dir": r.storage_dir,
                "initialized_at": r.initialized_at,
            }
            for r in self._get_repo_states()
        ]
        return Response(
            json.dumps(repos),
            content_type="application/json",
            headers={"ETag": etag, "Cache-Control": "no-cache"},
        )

    def handle_health(self, request: Request) -> Response:
        """Handle health check endpoint.

        Supports ETag-based conditional requests.

        Args:
            request: Incoming request.

        Returns:
            JSON response indicating server health, or 304.
        """
        from airut.dashboard.tracker import BootPhase

        version = self._get_clock_version()
        etag = f'"v{version}"'

        if request.headers.get("If-None-Match") == etag:
            return Response(status=304, headers={"ETag": etag})

        counts = self.tracker.get_counts()
        boot_state = self._get_boot_state()

        # Include repo status in health check
        repo_states = self._get_repo_states()
        live_repos = sum(1 for r in repo_states if r.status.value == "live")
        failed_repos = sum(1 for r in repo_states if r.status.value == "failed")

        # Determine overall status based on boot state
        if boot_state and boot_state.phase == BootPhase.FAILED:
            status = "error"
        elif boot_state and boot_state.phase != BootPhase.READY:
            status = "booting"
        elif live_repos > 0:
            status = "ok"
        else:
            status = "degraded"

        result: dict[str, Any] = {
            "status": status,
            "tasks": counts,
            "repos": {
                "live": live_repos,
                "failed": failed_repos,
                "total": len(repo_states),
            },
        }

        if boot_state:
            result["boot"] = {
                "phase": boot_state.phase.value,
                "message": boot_state.message,
            }
            if boot_state.error_message:
                result["boot"]["error"] = boot_state.error_message

        return Response(
            json.dumps(result),
            content_type="application/json",
            headers={"ETag": etag, "Cache-Control": "no-cache"},
        )

    def handle_api_task_stop(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle conversation stop API endpoint.

        Requires a ``X-Requested-With`` header to prevent cross-origin
        CSRF.  Browsers will not send custom headers on a cross-origin
        POST without a CORS preflight, and this server does not set any
        ``Access-Control-Allow-*`` headers, so the preflight is denied.

        Args:
            request: Incoming request.
            conversation_id: Conversation ID to stop.

        Returns:
            JSON response with stop result.
        """
        if not request.headers.get("X-Requested-With"):
            return Response(
                json.dumps({"error": "Missing X-Requested-With header"}),
                status=403,
                content_type="application/json",
            )

        if self.stop_callback is None:
            return Response(
                json.dumps({"error": "Stop functionality not available"}),
                status=503,
                content_type="application/json",
            )

        # Find the executing task for this conversation
        tasks = self.tracker.get_tasks_for_conversation(conversation_id)
        if not tasks:
            return Response(
                json.dumps({"error": "Task not found"}),
                status=404,
                content_type="application/json",
            )

        executing = [t for t in tasks if t.status == TaskStatus.EXECUTING]
        if not executing:
            # Summarize the actual statuses present so the caller
            # understands why stop was rejected.
            statuses = sorted({t.status.value for t in tasks})
            error_msg = f"Task is not running (statuses: {', '.join(statuses)})"
            return Response(
                json.dumps({"error": error_msg}),
                status=400,
                content_type="application/json",
            )

        # Call stop callback
        try:
            success = self.stop_callback(conversation_id)
            if success:
                return Response(
                    json.dumps(
                        {"success": True, "message": "Stop signal sent"}
                    ),
                    content_type="application/json",
                )
            else:
                return Response(
                    json.dumps(
                        {"success": False, "message": "Task not running"}
                    ),
                    status=404,
                    content_type="application/json",
                )
        except Exception as e:
            logger.exception("Failed to stop task %s: %s", conversation_id, e)
            return Response(
                json.dumps({"error": f"Failed to stop task: {e}"}),
                status=500,
                content_type="application/json",
            )

    def handle_events_stream(self, request: Request) -> Response:
        """Handle SSE state stream endpoint.

        Pushes composite state snapshots whenever any versioned state
        changes. Falls back to 429 when the SSE connection limit is
        reached.

        Args:
            request: Incoming request.

        Returns:
            SSE streaming response, or 429 if at connection limit.
        """
        if self._clock is None:
            return Response(
                json.dumps({"error": "SSE not available"}),
                status=503,
                content_type="application/json",
            )

        if not self._sse_manager.try_acquire():
            return Response(
                json.dumps({"error": "Too many SSE connections"}),
                status=429,
                content_type="application/json",
                headers={"Retry-After": "5"},
            )

        # Parse client version from query string or Last-Event-ID header
        client_version = 0
        last_event_id = request.headers.get("Last-Event-ID")
        if last_event_id is not None:
            try:
                client_version = int(last_event_id)
            except ValueError:
                pass
        else:
            version_param = request.args.get("version")
            if version_param is not None:
                try:
                    client_version = int(version_param)
                except ValueError:
                    pass

        clock = self._clock

        def generate() -> Iterable[str]:
            try:
                yield from sse_state_stream(
                    clock,
                    self.tracker,
                    self._boot_store,
                    self._repos_store,
                    client_version,
                )
            finally:
                self._sse_manager.release()

        return Response(
            generate(),
            content_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    def handle_events_log_stream(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle SSE stream for a conversation's event log.

        Streams new events from ``events.jsonl`` as they are appended.
        Sends a terminal ``done`` event when the task completes.

        Args:
            request: Incoming request.
            conversation_id: Conversation to stream events for.

        Returns:
            SSE streaming response, or error response.
        """
        conversation_dir = self._find_conversation_dir(conversation_id)
        if conversation_dir is None:
            return Response(
                json.dumps({"error": "Conversation not found"}),
                status=404,
                content_type="application/json",
            )

        if not self._sse_manager.try_acquire():
            return Response(
                json.dumps({"error": "Too many SSE connections"}),
                status=429,
                content_type="application/json",
                headers={"Retry-After": "5"},
            )

        client_offset = 0
        offset_param = request.args.get("offset")
        if offset_param is not None:
            try:
                client_offset = int(offset_param)
            except ValueError:
                pass

        event_log = EventLog(conversation_dir)

        def generate() -> Iterable[str]:
            try:
                yield from sse_events_log_stream(
                    event_log,
                    self.tracker,
                    conversation_id,
                    client_offset,
                )
            finally:
                self._sse_manager.release()

        return Response(
            generate(),
            content_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    def handle_network_log_stream(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle SSE stream for a conversation's network log.

        Streams new lines from ``network-sandbox.log`` as they are
        appended. Sends a terminal ``done`` event when the task
        completes.

        Args:
            request: Incoming request.
            conversation_id: Conversation to stream network logs for.

        Returns:
            SSE streaming response, or error response.
        """
        conversation_dir = self._find_conversation_dir(conversation_id)
        if conversation_dir is None:
            return Response(
                json.dumps({"error": "Conversation not found"}),
                status=404,
                content_type="application/json",
            )

        if not self._sse_manager.try_acquire():
            return Response(
                json.dumps({"error": "Too many SSE connections"}),
                status=429,
                content_type="application/json",
                headers={"Retry-After": "5"},
            )

        client_offset = 0
        offset_param = request.args.get("offset")
        if offset_param is not None:
            try:
                client_offset = int(offset_param)
            except ValueError:
                pass

        network_log = NetworkLog(conversation_dir / NETWORK_LOG_FILENAME)

        def generate() -> Iterable[str]:
            try:
                yield from sse_network_log_stream(
                    network_log,
                    self.tracker,
                    conversation_id,
                    client_offset,
                )
            finally:
                self._sse_manager.release()

        return Response(
            generate(),
            content_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    def handle_api_events_poll(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle polling endpoint for a conversation's event log.

        Returns new events since the given offset as pre-rendered HTML.
        Supports ETag-based conditional requests using the byte offset.

        Args:
            request: Incoming request.
            conversation_id: Conversation to poll events for.

        Returns:
            JSON response with ``{offset, html, done}``, or 304.
        """
        conversation_dir = self._find_conversation_dir(conversation_id)
        if conversation_dir is None:
            return Response(
                json.dumps({"error": "Conversation not found"}),
                status=404,
                content_type="application/json",
            )

        client_offset = 0
        offset_param = request.args.get("offset")
        if offset_param is not None:
            try:
                client_offset = int(offset_param)
            except ValueError:
                pass

        event_log = EventLog(conversation_dir)
        events, new_offset = event_log.tail(client_offset)

        etag = f'"o{new_offset}"'
        if not events and request.headers.get("If-None-Match") == etag:
            return Response(status=304, headers={"ETag": etag})

        html = render_events_html(events) if events else ""

        # Check if all tasks for this conversation are done
        tasks = self.tracker.get_tasks_for_conversation(conversation_id)
        done = not tasks or all(t.status == TaskStatus.COMPLETED for t in tasks)

        return Response(
            json.dumps({"offset": new_offset, "html": html, "done": done}),
            content_type="application/json",
            headers={"ETag": etag, "Cache-Control": "no-cache"},
        )

    def handle_api_network_poll(
        self, request: Request, conversation_id: str
    ) -> Response:
        """Handle polling endpoint for a conversation's network log.

        Returns new network log lines since the given offset as
        pre-rendered HTML. Supports ETag-based conditional requests.

        Args:
            request: Incoming request.
            conversation_id: Conversation to poll network logs for.

        Returns:
            JSON response with ``{offset, html, done}``, or 304.
        """
        conversation_dir = self._find_conversation_dir(conversation_id)
        if conversation_dir is None:
            return Response(
                json.dumps({"error": "Conversation not found"}),
                status=404,
                content_type="application/json",
            )

        client_offset = 0
        offset_param = request.args.get("offset")
        if offset_param is not None:
            try:
                client_offset = int(offset_param)
            except ValueError:
                pass

        network_log = NetworkLog(conversation_dir / NETWORK_LOG_FILENAME)
        lines, new_offset = network_log.tail(client_offset)

        etag = f'"o{new_offset}"'
        if not lines and request.headers.get("If-None-Match") == etag:
            return Response(status=304, headers={"ETag": etag})

        html = render_network_lines_html(lines) if lines else ""

        # Check if all tasks for this conversation are done
        tasks = self.tracker.get_tasks_for_conversation(conversation_id)
        done = not tasks or all(t.status == TaskStatus.COMPLETED for t in tasks)

        return Response(
            json.dumps({"offset": new_offset, "html": html, "done": done}),
            content_type="application/json",
            headers={"ETag": etag, "Cache-Control": "no-cache"},
        )

    def handle_api_tracker(self, request: Request) -> Response:
        """Handle JSON API for full task tracker state.

        Returns the complete tracker state including all tasks with their
        full details, counts by status, and version clock value.  Designed
        for integration tests and monitoring tools that need a single
        atomic snapshot of the tracker.

        Supports ETag-based conditional requests.

        Args:
            request: Incoming request.

        Returns:
            JSON response with tracker snapshot, or 304 if unchanged.
        """
        version = self._get_clock_version()
        etag = f'"v{version}"'

        if request.headers.get("If-None-Match") == etag:
            return Response(status=304, headers={"ETag": etag})

        snapshot = self.tracker.get_snapshot()
        tasks_data = [
            {
                "task_id": t.task_id,
                "conversation_id": t.conversation_id,
                "display_title": t.display_title,
                "repo_id": t.repo_id,
                "sender": t.sender,
                "authenticated_sender": t.authenticated_sender,
                "status": t.status.value,
                "completion_reason": (
                    t.completion_reason.value if t.completion_reason else None
                ),
                "completion_detail": t.completion_detail,
                "queued_at": t.queued_at,
                "started_at": t.started_at,
                "completed_at": t.completed_at,
                "model": t.model,
                "reply_index": t.reply_index,
            }
            for t in snapshot.value
        ]

        counts = self.tracker.get_counts()

        data = {
            "version": snapshot.version,
            "counts": counts,
            "tasks": tasks_data,
        }

        return Response(
            json.dumps(data),
            content_type="application/json",
            headers={"ETag": etag, "Cache-Control": "no-cache"},
        )

    def _get_clock_version(self) -> int:
        """Get the current version clock value.

        Returns:
            Current version number, or 0 if no clock is configured.
        """
        if self._clock is None:
            return 0
        return self._clock.version

    def _find_conversation_dir(self, conversation_id: str) -> Path | None:
        """Find the conversation directory across all repos.

        Args:
            conversation_id: Conversation ID to locate.

        Returns:
            Path to the conversation directory, or None if not found.
        """
        for work_dir in self._work_dirs():
            candidate = work_dir / conversation_id
            if candidate.exists():
                return candidate
        return None

    def _load_conversation(
        self, conversation_id: str
    ) -> ConversationMetadata | None:
        """Load conversation metadata.

        Args:
            conversation_id: Conversation ID to load.

        Returns:
            ConversationMetadata if available, None otherwise.
        """
        conversation_dir = self._find_conversation_dir(conversation_id)
        if conversation_dir is None:
            return None

        store = ConversationStore(conversation_dir)
        return store.load()

    def _load_task_from_disk(
        self, conversation_id: str
    ) -> tuple[TaskState, ConversationMetadata] | None:
        """Load a task from disk when not in memory.

        Constructs a minimal TaskState from conversation metadata stored on
        disk. This enables viewing past tasks that were active before the
        current process started.

        Args:
            conversation_id: 8-character hex conversation ID.

        Returns:
            Tuple of (TaskState, ConversationMetadata) if found,
            None otherwise.
        """
        # Validate conversation ID format
        if not CONVERSATION_ID_PATTERN.match(conversation_id):
            return None

        conversation_path = self._find_conversation_dir(conversation_id)
        if conversation_path is None or not conversation_path.exists():
            return None

        # Load conversation metadata
        store = ConversationStore(conversation_path)
        conversation = store.load()
        if conversation is None:
            return None

        # Construct TaskState from conversation data
        # We mark it as COMPLETED since it's a past task not currently active
        # Use the last reply's timestamp to estimate completion time
        completed_at: float | None = None
        if conversation.replies:
            try:
                # Parse ISO 8601 timestamp from last reply
                last_timestamp = conversation.replies[-1].timestamp
                # Handle both timezone-aware and naive timestamps
                normalized = last_timestamp.replace("Z", "+00:00")
                dt = datetime.fromisoformat(normalized)
                completed_at = dt.timestamp()
            except (ValueError, AttributeError):
                pass

        has_errors = any(r.is_error for r in conversation.replies)
        task = TaskState(
            task_id=f"disk-{conversation_id}",
            conversation_id=conversation_id,
            display_title=f"[Past conversation {conversation_id}]",
            status=TaskStatus.COMPLETED,
            completion_reason=(
                CompletionReason.EXECUTION_FAILED
                if has_errors
                else CompletionReason.SUCCESS
            ),
            queued_at=completed_at or 0.0,
            started_at=completed_at,
            completed_at=completed_at,
            model=conversation.model,
        )

        return task, conversation

    def _load_task_with_conversation(
        self, conversation_id: str
    ) -> tuple[TaskState, ConversationMetadata | None] | None:
        """Load task and conversation metadata from memory or disk.

        Tries to load from in-memory tracker first (using
        ``get_tasks_for_conversation`` to find the most relevant task),
        then falls back to disk for past tasks.

        Args:
            conversation_id: Conversation ID to load.

        Returns:
            Tuple of (TaskState, ConversationMetadata or None) if found,
            None if task not found in memory or on disk.
        """
        tasks = self.tracker.get_tasks_for_conversation(conversation_id)

        if tasks:
            # Prefer EXECUTING over other active states, then any
            # active over completed, then fall back to newest.
            executing = next(
                (t for t in tasks if t.status == TaskStatus.EXECUTING),
                None,
            )
            task = executing or next(
                (t for t in tasks if t.status in ACTIVE_STATUSES),
                tasks[0],
            )
            conversation = self._load_conversation(conversation_id)
            return task, conversation

        # Try loading from disk for past tasks
        disk_result = self._load_task_from_disk(conversation_id)
        if disk_result is not None:
            return disk_result

        return None

    def _task_to_dict(
        self,
        task: TaskState,
        include_conversation: bool = False,
        conversation: ConversationMetadata | None = None,
        event_groups: list[list[StreamEvent]] | None = None,
    ) -> dict[str, Any]:
        """Convert TaskState to JSON-serializable dict.

        Args:
            task: Task to convert.
            include_conversation: If True, include conversation metadata.
            conversation: Pre-loaded conversation metadata.
            event_groups: Pre-loaded event groups from EventLog.

        Returns:
            Dict representation of task.
        """
        result: dict[str, Any] = {
            "task_id": task.task_id,
            "conversation_id": task.conversation_id,
            "display_title": task.display_title,
            "repo_id": task.repo_id,
            "status": task.status.value,
            "completion_reason": (
                task.completion_reason.value if task.completion_reason else None
            ),
            "completion_detail": task.completion_detail,
            "sender": task.sender,
            "authenticated_sender": task.authenticated_sender,
            "queued_at": task.queued_at,
            "started_at": task.started_at,
            "completed_at": task.completed_at,
            "model": task.model,
            "reply_index": task.reply_index,
            "queue_duration": task.queue_duration(),
            "execution_duration": task.execution_duration(),
            "total_duration": task.total_duration(),
        }
        if task.todos is not None:
            result["todos"] = [t.to_dict() for t in task.todos]

        if include_conversation:
            if conversation is None:
                conversation = self._load_conversation(task.conversation_id)
            if conversation:
                replies_data = []
                for i, r in enumerate(conversation.replies):
                    reply_dict: dict[str, Any] = {
                        "session_id": r.session_id,
                        "timestamp": r.timestamp,
                        "duration_ms": r.duration_ms,
                        "total_cost_usd": r.total_cost_usd,
                        "num_turns": r.num_turns,
                        "is_error": r.is_error,
                        "usage": {
                            "input_tokens": r.usage.input_tokens,
                            "output_tokens": r.usage.output_tokens,
                            "cache_creation_input_tokens": (
                                r.usage.cache_creation_input_tokens
                            ),
                            "cache_read_input_tokens": (
                                r.usage.cache_read_input_tokens
                            ),
                        },
                        "request_text": r.request_text,
                        "response_text": r.response_text,
                    }

                    # Include events from event log if available
                    if event_groups is not None and i < len(event_groups):
                        reply_dict["events"] = [
                            json.loads(e.raw) for e in event_groups[i]
                        ]
                    else:
                        reply_dict["events"] = []

                    replies_data.append(reply_dict)

                result["conversation"] = {
                    "total_cost_usd": conversation.total_cost_usd,
                    "total_turns": conversation.total_turns,
                    "reply_count": len(conversation.replies),
                    "replies": replies_data,
                }
            else:
                result["conversation"] = None

        return result
