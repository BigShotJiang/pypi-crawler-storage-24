Otoolbox Addon: workspace
==========================
