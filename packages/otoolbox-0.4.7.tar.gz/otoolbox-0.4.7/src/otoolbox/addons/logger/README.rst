Otoolbox Addon: Logger
==========================
