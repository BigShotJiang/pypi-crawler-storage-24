import pytest

from pyapi_service_kit.service.config import ServiceConfig


class TestServiceConfig:
    def test_valid_instance_id(self):
        cfg = ServiceConfig(instance_id="my-service-01")
        assert cfg.instance_id == "my-service-01"

    def test_with_nats_subject(self):
        cfg = ServiceConfig(instance_id="svc-1", nats_subject_time="time.updates")
        assert cfg.nats_subject_time == "time.updates"

    def test_invalid_instance_id_raises(self):
        with pytest.raises(ValueError):
            ServiceConfig(instance_id="has spaces")

    def test_strips_whitespace(self):
        cfg = ServiceConfig(instance_id="  svc-1  ")
        assert cfg.instance_id == "svc-1"
