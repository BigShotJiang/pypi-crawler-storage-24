from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from flask import Request, Response, g

from flaskapi_guard.core.checks.base import SecurityCheck
from flaskapi_guard.utils import log_activity


class TimeWindowCheck(SecurityCheck):
    """Check time window restrictions."""

    @property
    def check_name(self) -> str:
        return "time_window"

    def _check_time_window(self, time_restrictions: dict[str, str]) -> bool:
        """Check if current time is within allowed time window."""
        try:
            start_time = time_restrictions["start"]
            end_time = time_restrictions["end"]

            timezone_str = time_restrictions.get("timezone", "UTC")
            try:
                tz: ZoneInfo | timezone = ZoneInfo(timezone_str)
            except (KeyError, Exception):
                tz = timezone.utc
            current_time = datetime.now(tz)
            current_hour_minute = current_time.strftime("%H:%M")

            if start_time > end_time:
                return (
                    current_hour_minute >= start_time or current_hour_minute <= end_time
                )
            else:
                return start_time <= current_hour_minute <= end_time

        except Exception as e:
            self.logger.error(f"Error checking time window: {str(e)}")
            return True

    def check(self, request: Request) -> Response | None:
        """Check time window restrictions."""
        route_config = getattr(g, "route_config", None)
        if not route_config or not route_config.time_restrictions:
            return None

        time_allowed = self._check_time_window(route_config.time_restrictions)
        if not time_allowed:
            log_activity(
                request,
                self.logger,
                log_type="suspicious",
                reason="Access outside allowed time window",
                level=self.config.log_suspicious_level,
                passive_mode=self.config.passive_mode,
            )
            if self.middleware.event_bus is not None:
                self.middleware.event_bus.send_middleware_event(
                    event_type="decorator_violation",
                    request=request,
                    action_taken="request_blocked"
                    if not self.config.passive_mode
                    else "logged_only",
                    reason="Access outside allowed time window",
                    decorator_type="advanced",
                    violation_type="time_restriction",
                )
            if not self.config.passive_mode:
                return self.middleware.create_error_response(
                    status_code=403,
                    default_message="Access not allowed at this time",
                )
        return None
