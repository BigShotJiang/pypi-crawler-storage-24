"""
AiCippy WebSocket module for real-time streaming communication.

Provides a production-grade WebSocket client that connects to the
API Gateway endpoint at wss://ws.aicippy.com/prod with JWT authentication,
automatic reconnection, and async token streaming.
"""

from __future__ import annotations

from aicippy.websocket.client import WebSocketClient
from aicippy.websocket.models import (
    ChatRequest,
    ConnectionState,
    StreamToken,
    WebSocketMessage,
)

__all__ = [
    "ChatRequest",
    "ConnectionState",
    "StreamToken",
    "WebSocketClient",
    "WebSocketMessage",
]
