"""Built-in implementations of the :class:`modelity.interface.IModelVisitor`
interface.

.. versionadded:: 0.17.0
"""

import base64
import collections
import datetime
import enum
import functools
from typing import Any, Callable, Literal, Mapping, MutableSequence, Optional, Sequence, Set, TypeVar

from modelity import _utils, _hooks, _export_list
from modelity.base import Model, Field, ModelVisitor, TypeHandlerWithValidation
from modelity.error import Error, ErrorFactory
from modelity.loc import Loc
from modelity.unset import Unset, UnsetType, is_unset

__all__ = export = _export_list.ExportList()  # type: ignore

T = TypeVar("T")


@export
class EmptyVisitor(ModelVisitor):
    """A visitor that simply implements
    :class:`modelity.interface.IModelVisitor` interface with methods doing
    nothing.

    It is meant to be used as a base for other visitors, especially ones that
    do not need to overload all methods.

    .. versionchanged:: 0.34.0
        Restored the whole set of :class:`modelity.interface.IModelVisitor`
        interface methods to get rid of linter warnings in subclasses.
    """

    def visit_model_begin(self, loc: Loc, value: Model) -> Optional[bool]: ...

    def visit_model_end(self, loc: Loc, value: Model): ...

    def visit_model_field_begin(self, loc: Loc, value: Any, field: Field) -> Optional[bool]: ...

    def visit_model_field_end(self, loc: Loc, value: Any, field: Field): ...

    def visit_mapping_begin(self, loc: Loc, value: Mapping) -> Optional[bool]: ...

    def visit_mapping_end(self, loc: Loc, value: Mapping): ...

    def visit_sequence_begin(self, loc: Loc, value: Sequence) -> Optional[bool]: ...

    def visit_sequence_end(self, loc: Loc, value: Sequence): ...

    def visit_set_begin(self, loc: Loc, value: Set) -> Optional[bool]: ...

    def visit_set_end(self, loc: Loc, value: Set): ...

    def visit_none(self, loc: Loc, value: None): ...

    def visit_unset(self, loc: Loc, value: UnsetType): ...

    def visit_scalar(self, loc: Loc, value: Any): ...

    def visit_any(self, loc: Loc, value: Any): ...


@export
class DumpVisitor(EmptyVisitor):
    """Visitor that dumps model to dict without type narrowing or any kind of
    value formatting.

    It basically produces same structure as the model has, but based on Python
    collection types (dicts, lists, tuples and sets) instead of Modelity
    built-in ones.

    .. important::
        This visitor assumes that use of its API is done by
        :meth:`modelity.model.Model.accept` method that keeps the right order
        of method calling. It may not work correctly if used manually.

    .. versionadded:: 0.31.0
    """

    def __init__(self, out: dict):
        self._out = out
        self._stack: list[DumpVisitor._StackItem] = []
        self._model_depth = 0

    def visit_model_begin(self, loc: Loc, value: Model):
        if self._model_depth == 0:
            self._push_dict(self._out)
        else:
            self._push_dict({})
        self._model_depth += 1

    def visit_model_end(self, loc: Loc, value: Model):
        self._model_depth -= 1
        if self._model_depth > 0:
            self._pop_and_add(loc)

    def visit_mapping_begin(self, loc: Loc, value: Mapping):
        self._push_dict({})

    def visit_mapping_end(self, loc: Loc, value: Mapping):
        self._pop_and_add(loc)

    def visit_sequence_begin(self, loc: Loc, value: Sequence):
        self._push_list([])

    def visit_sequence_end(self, loc: Loc, value: Sequence):
        obj = self._pop()
        if not isinstance(value, MutableSequence):
            obj = tuple(obj)
        self._add(loc, obj)

    def visit_set_begin(self, loc: Loc, value: Set):
        self._push_set(set())

    def visit_set_end(self, loc: Loc, value: Set):
        self._pop_and_add(loc)

    def visit_scalar(self, loc: Loc, value: Any):
        self._add(loc, value)

    def visit_any(self, loc: Loc, value: Any):
        self._add(loc, value)

    def visit_unset(self, loc: Loc, value: UnsetType):
        self._add(loc, value)

    def visit_none(self, loc: Loc, value: None):
        self._add(loc, value)

    def _add(self, loc: Loc, value: Any):
        _, add = self._stack[-1]
        add(loc, value)

    def _pop(self) -> Any:
        return self._stack.pop()[0]

    def _pop_and_add(self, loc: Loc):
        current_top = self._pop()
        self._add(loc, current_top)

    _AddFunc = Callable[[Loc, Any], None]

    _StackItem = tuple[Any, _AddFunc]

    def _push_dict(self, obj: dict):
        self._stack.append((obj, functools.partial(self._add_dict, obj)))

    def _push_list(self, obj: list):
        self._stack.append((obj, functools.partial(self._add_list, obj)))

    def _push_set(self, obj: set):
        self._stack.append((obj, functools.partial(self._add_set, obj)))

    @staticmethod
    def _add_dict(obj: dict, loc: Loc, value: Any):
        obj[loc.last] = value

    @staticmethod
    def _add_list(obj: list, loc: Loc, value: Any):
        obj.append(value)

    @staticmethod
    def _add_set(obj: set, loc: Loc, value: Any):
        obj.add(value)


@export
class JsonDumpVisitorProxy:
    """Proxy visitor that narrows down value types to closest JSON-compatible
    type: dict, list, str, int, float, bool or None.

    .. versionadded:: 0.31.0

    :param target:
        Target dump visitor, e.g. :class:`DumpVisitor` object.

    :param exclude_unset:
        Exclude model fields equal to :obj:`modelity.unset.Unset` object.

    :param exclude_none:
        Exclude model fields equal to :obj:`None`.

        This does not affect ``None`` values used in nested containers, only
        model fields, typed with e.g. ``Optional[T]``, are affected.

    :param bytes_format:
        The format used to encode :class:`bytes` objects.

        Supports either encoding name (f.e. ``utf-8`` or ``ascii``) or one of
        predefined encodings (f.e. ``base64``).

    :param datetime_format:
        The format to use to encode :class:`datetime.datetime` objects.

        Following placeholders are supported:

        * **YYYY** for 4-digit years
        * **MM** for 2-digit months in range [01..12]
        * **DD** for 2-digit days in range [01..31]
        * **hh** for 2-digit hours in range [00..23]
        * **mm** for 2-digit minutes in range [00..59]
        * **ss** for 2-digit seconds in range [00..59]
        * **ffffff** for 6-digit microseconds in range [000000..999999]
        * **ZZZZ** for timezone

    :param date_format:
        The format to use to encode :class:`datetime.date` objects.

        Following placeholders are supported:

        * **YYYY** for 4-digit years
        * **MM** for 2-digit months in range [01..12]
        * **DD** for 2-digit days in range [01..31]

    :param default_encoder:
        The default encoder to use if there is no dedicated type encoder found.

        If not given, then :class:`str` is used as a default.

        .. versionchanged:: 0.34.0
            Parameter was renamed from *default_converter*.
    """

    def __init__(
        self,
        target: ModelVisitor,
        /,
        exclude_unset: bool = False,
        exclude_none: bool = False,
        bytes_format: str | Literal["base64"] = "utf-8",
        datetime_format: str = "YYYY-MM-DDThh:mm:ss.ffffffZZZZ",
        date_format: str = "YYYY-MM-DD",
        default_encoder: Optional[Callable[[Loc, Any], Any]] = None,
    ):
        self._target = target
        self._exclude_unset = exclude_unset
        self._exclude_none = exclude_none
        self._bytes_format = bytes_format
        if bytes_format == "base64":
            bytes_formatter = self._encode_bytes_as_base64_str
        else:
            bytes_formatter = self._encode_bytes_as_str
        self._datetime_format = _utils.compile_datetime_format(datetime_format)
        self._date_format = _utils.compile_date_format(date_format)
        self._default_encoder = default_encoder or (lambda loc, value: str(value))
        self._stack: list = []
        self._type_encoders: dict[type, Callable[[Loc, Any], Any]] = {
            datetime.datetime: self._encode_datetime,
            datetime.date: self._encode_date,
            bytes: bytes_formatter,
            str: self._unchanged,
            int: self._unchanged,
            float: self._unchanged,
            bool: self._unchanged,
        }

    def __getattr__(self, name):
        return getattr(self._target, name)

    def register_type_encoder(self, typ: type[T], func: Callable[[Loc, T], Any]):
        """Register or override type encoder.

        .. important::
            Only model field values, nested model instances or container
            elements encoding can be customized using this method. Containers
            like dicts, sets or lists cannot be customized.

        .. versionadded:: 0.34.0

        :param typ:
            The type to set converter function for.

        :param func:
            The conversion function.

            Takes ``(loc, value)`` as input and returns encoded value.
        """
        self._type_encoders[typ] = func

    def visit_model_begin(self, loc: Loc, value: Model):
        encoder = self._type_encoders.get(type(value))
        if encoder is None:
            return self._target.visit_model_begin(loc, value)
        self.visit_any(loc, encoder(loc, value))
        return True

    def visit_set_begin(self, loc: Loc, value: Set):
        list_value = list(value)
        self._stack.append(list_value)
        return self._target.visit_sequence_begin(loc, list_value)

    def visit_set_end(self, loc: Loc, value: Set):
        list_value = self._stack.pop()
        return self._target.visit_sequence_end(loc, list_value)

    def visit_sequence_begin(self, loc: Loc, value: Sequence):
        list_value = list(value)
        self._stack.append(list_value)
        return self._target.visit_sequence_begin(loc, list_value)

    def visit_sequence_end(self, loc: Loc, value: Sequence):
        list_value = self._stack.pop()
        return self._target.visit_sequence_end(loc, list_value)

    def visit_scalar(self, loc: Loc, value: Any):
        value_type = type(value)
        encoder = self._type_encoders.get(value_type)
        if encoder is not None:
            self._target.visit_scalar(loc, encoder(loc, value))
        elif isinstance(value, enum.Enum):
            self.visit_any(loc, value.value)
        else:
            self._target.visit_scalar(loc, self._default_encoder(loc, value))

    def visit_any(self, loc: Loc, value: Any):
        if isinstance(value, Set):
            self._visit_any_sequence(loc, sorted(value, key=lambda x: repr(x)))
        elif _utils.is_neither_str_nor_bytes_sequence(value):
            self._visit_any_sequence(loc, list(value))
        elif isinstance(value, Mapping):
            self._visit_any_mapping(loc, value)
        else:
            return self.visit_scalar(loc, value)

    def visit_unset(self, loc: Loc, value: UnsetType):
        if not self._exclude_unset:
            self._target.visit_unset(loc, value)

    def visit_none(self, loc: Loc, value: None):
        if not self._exclude_none:
            self._target.visit_none(loc, value)

    def _visit_any_sequence(self, loc: Loc, value: Sequence):
        if self._target.visit_sequence_begin(loc, value) is not True:
            for i, el in enumerate(value):
                self.visit_any(loc + Loc(i), el)
            self._target.visit_sequence_end(loc, value)

    def _visit_any_mapping(self, loc: Loc, value: Mapping):
        if self._target.visit_mapping_begin(loc, value) is not True:
            for k, v in value.items():
                self.visit_any(loc + Loc(k), v)
            self._target.visit_mapping_end(loc, value)

    def _encode_datetime(self, loc: Loc, value: datetime.datetime) -> str:
        return value.strftime(self._datetime_format)

    def _encode_date(self, loc: Loc, value: datetime.date) -> str:
        return value.strftime(self._date_format)

    def _encode_bytes_as_str(self, loc: Loc, value: bytes) -> str:
        return value.decode(self._bytes_format)

    def _encode_bytes_as_base64_str(self, loc: Loc, value: bytes) -> str:
        return base64.b64encode(value).decode()

    def _unchanged(self, loc: Loc, value: Any) -> Any:
        return value


@export
class ValidationVisitor(EmptyVisitor):
    """Visitor that performs model validation.

    .. versionadded:: 0.31.0
        Replaced **DefaultValidationVisitor** used earlier.

    :param root:
        The root model.

    :param errors:
        The list of errors.

        Will be populated with validation errors (if any).

    :param ctx:
        User-defined validation context.

        It is shared across all validation hooks and can be used as a source of
        external data needed during validation but not directly available in
        the model.
    """

    def __init__(self, root: Model, errors: list[Error], ctx: Any = None):
        self._root = root
        self._errors = errors
        self._ctx = ctx
        self._memo: dict[Loc, dict] = {}
        self._location_validators_stack = collections.deque[tuple[Loc, Model]]()  # type: ignore
        self._model_stack = collections.deque[Model]()

    def visit_model_begin(self, loc: Loc, value: Model):
        status = _hooks.run_model_prevalidators(value.__class__, value, self._root, self._ctx, self._errors, loc)
        if status is True:
            return True
        self._location_validators_stack.append((loc, value))
        self._push_model(value)

    def visit_model_end(self, loc: Loc, value: Model):
        if len(loc) >= 1:
            self._run_location_validators(loc, value)
        _hooks.run_model_postvalidators(value.__class__, value, self._root, self._ctx, self._errors, loc)
        self._location_validators_stack.pop()
        self._pop_model()

    def visit_model_field_begin(self, loc: Loc, value: Any, field: Field):
        if value is Unset:
            if field.deferred:
                self._errors.append(ErrorFactory.required_missing(loc))
            elif not field.unsettable:
                self._errors.append(ErrorFactory.unset_not_allowed(loc, field.typ))
            return True  # Skip other validators

    def visit_model_field_end(self, loc: Loc, value: Any, field: Field):
        if value is not Unset:
            model = self._current_model()
            model_type = model.__class__
            _hooks.run_field_validators(field, model_type, model, self._root, self._ctx, self._errors, loc, value)
            if isinstance(field.type_handler, TypeHandlerWithValidation):
                field.type_handler.validate(self._errors, loc, value)

    def visit_mapping_end(self, loc: Loc, value: Mapping):
        self._run_location_validators(loc, value)

    def visit_sequence_end(self, loc: Loc, value: Sequence):
        self._run_location_validators(loc, value)

    def visit_set_end(self, loc: Loc, value: Set):
        self._run_location_validators(loc, value)

    def visit_none(self, loc: Loc, value: None):
        self._run_location_validators(loc, value)

    def visit_scalar(self, loc: Loc, value: Any):
        self._run_location_validators(loc, value)

    def visit_any(self, loc: Loc, value: Any):
        self._run_location_validators(loc, value)

    def _push_model(self, model: Model):
        self._model_stack.append(model)

    def _pop_model(self):
        self._model_stack.pop()

    def _current_model(self) -> Model:
        return self._model_stack[-1]

    def _run_location_validators(self, loc: Loc, value: Any):
        for base_loc, model in self._location_validators_stack:
            _hooks.run_location_validators(model.__class__, model, self._root, self._ctx, self._errors, base_loc, loc, value)


@export
class FixupVisitor(EmptyVisitor):
    """Visitor performing model fixups by executing fixup hooks.

    .. versionadded:: 0.36.0
    """

    def __init__(self) -> None:
        self._model_stack: list[tuple[type[Model], Model]] = []

    def visit_model_begin(self, loc: Loc, value: Model) -> bool | None:
        self._model_stack.append((value.__class__, value))
        return None

    def visit_model_end(self, loc: Loc, value: Model):
        _hooks.run_model_fixups(value.__class__, value, loc)
        self._model_stack.pop()

    def visit_model_field_end(self, loc: Loc, value: Any, field: Field):
        if not is_unset(value):
            model_type, model = self._model_stack[-1]
            _hooks.run_field_fixups(field, model_type, model, loc, value)


@export
class ModelFieldPruningVisitorProxy:
    """Visitor proxy that skips model fields if provided exclude function
    returns ``True``.

    .. important::
        This proxy only skips model fields and does not affect container
        elements in any way.

    :param target:
        The wrapped model visitor.

    :param exclude_if:
        The exclusion function.

        Takes ``(loc, value)`` as arguments and must return ``True`` to skip
        the matched model field or ``False`` to leave it.
    """

    def __init__(self, target: ModelVisitor, /, exclude_if: Callable[[Loc, Any], bool]):
        self._target = target
        self._exclude_if = exclude_if

    def __getattr__(self, name):
        return getattr(self._target, name)

    def visit_model_field_begin(self, loc: Loc, value: Any, field: Field) -> Optional[bool]:
        if self._exclude_if(loc, value):
            return True
        return self._target.visit_model_field_begin(loc, value, field)
