"""Framework integrations for debouncer."""
