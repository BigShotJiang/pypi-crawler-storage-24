# exoarmor
> Hardened exocortex SaaS platform
**Official package by Colin McNamara LLC.** Namespace reservation.
- Website: https://github.com/colinmcnamara/exoarmor
- License: Proprietary
